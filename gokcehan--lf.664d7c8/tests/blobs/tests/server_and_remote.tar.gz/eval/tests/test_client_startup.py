"""Client start-up and shut-down: ``-single`` mode, fatal start-up errors and
the ``-last-dir-path``/``-print-last-dir``/``-selection-path``/``-print-selection``
output channels that a client uses when it exits.
"""

import os
import signal
import time

from conftest import run_lf, socket_path, strip_log_ts


def make_files_dir(root, name, files):
    """Create a directory full of regular files and return its path."""
    path = os.path.join(root, name)
    os.makedirs(path, exist_ok=True)
    for fname in files:
        with open(os.path.join(path, fname), "w") as fh:
            fh.write("x\n")
    return path


def test_single_mode_starts_no_server(lf):
    """``-single`` runs a stand-alone client: no socket is ever created and
    remote commands keep failing while it runs."""
    # CATCHES: -single skips both the server check and the server connection,
    # so the client neither spawns nor contacts a server and still quits
    # normally on ``q``.
    client = lf.client(args=["-single"])
    time.sleep(1.5)
    assert not os.path.exists(socket_path(lf.env))
    result = lf.remote("list")
    assert result.returncode == 1
    assert strip_log_ts(result.stderr.decode()) == (
        "remote command: connecting to server: dial unix %s: "
        "connect: no such file or directory\n" % socket_path(lf.env)
    )
    client.send_keys("q")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    assert not os.path.exists(socket_path(lf.env))


def test_single_client_is_invisible_to_a_running_server(server, lf):
    """Even with a live server on the socket, a ``-single`` client never
    registers and stays absent from ``list``."""
    # CATCHES: single mode does not merely skip spawning the server, it also
    # skips connecting to one that already exists.
    client = lf.client(args=["-single"])
    time.sleep(1.5)
    assert lf.list_ids() == []
    client.send_keys("q")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    assert server.server.poll() is None


def test_client_log_path_that_cannot_be_opened_is_fatal(lf):
    """A client whose ``-log`` path cannot be opened dies with status 1 and
    the error on stderr (before the log output is redirected)."""
    # CATCHES: the failure happens before log output is redirected, so the
    # ``log.Fatalf`` message appears on stderr with a log timestamp.
    result = run_lf(["-single", "-log", lf.root], lf.env, cwd=lf.env["HOME"])
    assert result.returncode == 1
    assert result.stdout == b""
    assert strip_log_ts(result.stderr.decode()) == (
        "opening log file: open %s: is a directory\n" % lf.root
    )


def test_client_without_a_controlling_terminal_fails_to_start(lf):
    """Without a terminal a client cannot initialize its screen: it exits 1,
    silently, and records the reason in its log file."""
    # CATCHES: the screen initialization error is fatal (exit status 1) and
    # only visible through ``-log`` because stderr stays empty.
    log = os.path.join(lf.root, "notty.log")
    result = run_lf(["-single", "-log", log], lf.env, cwd=lf.workdir)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b""
    with open(log, "r", errors="surrogateescape") as fh:
        text = strip_log_ts(fh.read())
    assert "initializing screen: open /dev/tty: no such device or address" in text


def test_last_dir_path_and_print_last_dir_on_quit(server, lf):
    """On quit the client writes its last directory to ``-last-dir-path``
    (no trailing newline) and prints it to stdout with ``-print-last-dir``."""
    # CATCHES: both channels report the directory the client *ended up in*
    # (after navigation), the file without a trailing newline while stdout
    # gets one from Println.
    lastdir = os.path.join(lf.root, "lastdir")
    client = lf.client(args=["-last-dir-path", lastdir, "-print-last-dir"], stdout_pipe=True)
    assert lf.wait_registered(client)
    time.sleep(1.0)
    client.send_keys("l")  # open adir -> cd into it
    time.sleep(1.0)
    client.send_keys("q")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    with open(lastdir, "r") as fh:
        assert fh.read() == os.path.join(lf.workdir, "adir")
    assert client.pipe_output == (os.path.join(lf.workdir, "adir") + "\n").encode()


def test_last_dir_with_a_newline_in_the_name_is_skipped(server, lf):
    """A last directory whose path contains a newline is refused on both
    output channels and the skip is logged once per channel."""
    # CATCHES: newline paths would corrupt the line-oriented output, so both
    # the file and the stdout channel are skipped (file never created, no
    # stdout) with a Go-quoted path in the log.
    nldir = os.path.join(lf.root, "a\nb")
    os.makedirs(nldir, exist_ok=True)
    lastdir = os.path.join(lf.root, "lastdir-nl")
    client = lf.client(
        cwd=nldir, args=["-last-dir-path", lastdir, "-print-last-dir"], stdout_pipe=True
    )
    assert lf.wait_registered(client)
    time.sleep(1.0)
    client.send_keys("q")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    assert not os.path.exists(lastdir)
    assert client.pipe_output == b""
    expected = 'last-dir: skipping path with newline: "%s"' % nldir.replace("\n", "\\n")
    assert strip_log_ts(client.log_text()).count(expected) == 2


def test_unwritable_output_paths_are_logged_not_fatal(server, lf):
    """Unwritable ``-last-dir-path``/``-selection-path`` locations only
    produce a log line; the client still exits with status 0."""
    # CATCHES: output problems at shutdown are not fatal and never change
    # the exit status, unlike start-up errors such as a bad ``-log``.
    missing = os.path.join(lf.root, "nodir")
    client = lf.client(args=["-last-dir-path", os.path.join(missing, "f")])
    assert lf.wait_registered(client)
    client.send_keys("q")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    assert (
        "opening last dir file: open %s: no such file or directory\n"
        % os.path.join(missing, "f")
    ) in strip_log_ts(client.log_text())

    work = make_files_dir(lf.root, "selwork", ["afile.txt"])
    client = lf.client(cwd=work, args=["-selection-path", os.path.join(missing, "g")])
    assert lf.wait_registered(client)
    time.sleep(1.0)
    client.send_keys("l")  # open the only (regular) file
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    assert (
        "opening selection file: open %s: no such file or directory\n"
        % os.path.join(missing, "g")
    ) in strip_log_ts(client.log_text())


def test_selection_path_and_print_selection_on_open(server, lf):
    """Opening a file with selections active writes them to
    ``-selection-path`` (newline-joined, no trailing newline) and prints each
    to stdout with ``-print-selection``."""
    # CATCHES: when selections exist the whole selection is output, not just
    # the opened file, and the file channel omits the trailing newline that
    # the stdout channel has.
    work = make_files_dir(lf.root, "selwork", ["afile.txt", "bfile.txt", "cfile.txt"])
    selfile = os.path.join(lf.root, "selection")
    client = lf.client(
        cwd=work, args=["-selection-path", selfile, "-print-selection"], stdout_pipe=True
    )
    assert lf.wait_registered(client)
    time.sleep(1.0)
    client.send_keys("v")  # invert: select every file
    time.sleep(0.8)
    client.send_keys("l")  # open the current file -> quit with the selection
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    expected = "\n".join(os.path.join(work, n) for n in ("afile.txt", "bfile.txt", "cfile.txt"))
    with open(selfile, "r") as fh:
        assert fh.read() == expected
    assert client.pipe_output == (expected + "\n").encode()


def test_selection_skips_paths_containing_newlines(server, lf):
    """Selected paths that contain a newline are filtered from both the
    selection file and stdout, and each skip is logged."""
    # CATCHES: the selection file joins the surviving paths with newlines so
    # a newline-named entry would be ambiguous; it is dropped and the skip
    # logged once for the file channel and once for stdout.
    work = make_files_dir(
        lf.root, "selwork", ["afile.txt", "bfile.txt", "cfile.txt", "nl\nx.txt"]
    )
    selfile = os.path.join(lf.root, "selection")
    client = lf.client(
        cwd=work, args=["-selection-path", selfile, "-print-selection"], stdout_pipe=True
    )
    assert lf.wait_registered(client)
    time.sleep(1.0)
    client.send_keys("v")
    time.sleep(0.8)
    client.send_keys("l")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    expected = "\n".join(os.path.join(work, n) for n in ("afile.txt", "bfile.txt", "cfile.txt"))
    with open(selfile, "r") as fh:
        assert fh.read() == expected
    assert client.pipe_output == (expected + "\n").encode()
    skipped = 'selection: skipping path with newline: "%s"' % os.path.join(
        work, "nl\nx.txt"
    ).replace("\n", "\\n")
    assert strip_log_ts(client.log_text()).count(skipped) == 2


def test_print_last_dir_sanitizes_control_bytes_on_a_terminal(server, lf):
    """``-print-last-dir`` sanitizes control bytes in the path when stdout is
    the terminal, replacing them with U+FFFD."""
    # CATCHES: the terminal output path (unlike the file channel) runs the
    # path through the control-character sanitizer, so a BEL in a directory
    # name becomes the replacement character.
    weird = os.path.join(lf.root, "we\x07ird")
    os.makedirs(weird, exist_ok=True)
    client = lf.client(cwd=weird, args=["-print-last-dir"])
    assert lf.wait_registered(client)
    time.sleep(1.0)
    client.send_keys("q")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    sanitized = weird.encode().replace(b"\x07", b"\xef\xbf\xbd") + b"\r\n"
    assert client.output.endswith(sanitized)


def test_unreadable_history_file_is_reported_in_the_log(server, lf):
    """A history file that cannot be read produces an ``error:`` log line but
    does not stop the client."""
    # CATCHES: the history file location comes from XDG_DATA_HOME and a bad
    # one is reported through the client log while the client keeps running.
    history = os.path.join(lf.env["XDG_DATA_HOME"], "lf", "history")
    os.makedirs(history, exist_ok=True)  # a directory where a file is expected
    client = lf.client()
    assert lf.wait_registered(client)
    time.sleep(1.0)
    assert (
        "error: reading history file: reading history file: read %s: is a directory" % history
        in strip_log_ts(client.log_text())
    )


def test_command_flag_runs_commands_at_init(server, lf):
    """Each ``-command`` flag is executed at client initialization, in order,
    before the client starts its event loop."""
    # CATCHES: ``-command`` accepts repeated flags, they run like lfrc
    # statements during start-up, and ``quit`` there ends the client with
    # status 0 before any interaction.
    lastdir = os.path.join(lf.root, "lastdir-cmd")
    client = lf.client(
        args=["-command", "cd adir", "-command", "quit", "-last-dir-path", lastdir]
    )
    assert client.wait_exit(15)
    assert client.proc.returncode == 0
    with open(lastdir, "r") as fh:
        assert fh.read() == os.path.join(lf.workdir, "adir")


def test_invalid_lf_level_is_reported_on_stderr(server, lf):
    """A non-numeric inherited ``$LF_LEVEL`` is logged to stderr exactly once
    and does not prevent the client from starting and registering."""
    # CATCHES: the warning is printed before the client redirects its log
    # output, so it lands on stderr with the strconv error text verbatim.
    client = lf.client(extra_env={"LF_LEVEL": "abc"})
    assert lf.wait_registered(client)
    time.sleep(1.0)
    assert strip_log_ts(client.stderr.decode()) == (
        'parsing $LF_LEVEL: strconv.Atoi: parsing "abc": invalid syntax\n'
    )


def test_quit_drops_dead_connections_and_shuts_down(server, lf):
    """``quit`` writes an empty line to every client to probe it, drops the
    connections that fail, and then shuts down once none remain."""
    # CATCHES: a SIGKILLed client stays in ``list`` (no ``drop`` was sent),
    # and the graceful ``quit`` only exits the server because writing to the
    # dead connection fails and removes it first.
    client = lf.client()
    assert lf.wait_registered(client)
    client.proc.send_signal(signal.SIGKILL)
    assert client.wait_exit(5)
    time.sleep(1.0)
    assert lf.list_ids() == [client.id]
    result = server.remote("quit")
    assert result.returncode == 0
    assert result.stdout == b""
    assert server.server.wait(10) == 0
