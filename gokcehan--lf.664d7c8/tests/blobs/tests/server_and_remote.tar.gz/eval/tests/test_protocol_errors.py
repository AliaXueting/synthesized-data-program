"""Error handling of the server's line protocol (``lf -remote``)."""

import pytest

from conftest import strip_log_ts

# (command, exact stdout) pairs recorded from the reference binary.
UNKNOWN_WORDS = ["hello", "connx", "quit-extra", "LIST", "Send", "listen", "SeNd"]


@pytest.mark.parametrize("word", UNKNOWN_WORDS)
def test_unknown_first_word(server, word):
    """An unrecognised first word is echoed back as ``unexpected command``.

    CATCHES: the whole first word is echoed verbatim, the match is
    case-sensitive, and prefixes such as ``quit-`` are *not* treated as quit.
    """
    result = server.remote(word)
    assert result.returncode == 0
    assert result.stderr == b""
    assert result.stdout.decode() == "listen: unexpected command: %s\n" % word


@pytest.mark.parametrize(
    "command, expected",
    [
        ("conn", "listen: conn: requires a client ID\n"),
        ("conn abc", "listen: conn: client ID must be a number\n"),
        ("conn 12x", "listen: conn: client ID must be a number\n"),
        ("drop", "listen: drop: requires a client ID\n"),
        ("drop abc", "listen: drop: client ID must be a number\n"),
        ("query", "listen: query: requires a client ID\n"),
        ("query abc", "listen: query: client ID must be a number\n"),
        ("query 1 maps", "listen: query: no client with ID 1 connected\n"),
        ("send 1 echo", "listen: send: no client with ID 1 connected\n"),
        ("query 99999999999999999999 x", "listen: query: client ID must be a number\n"),
        ("conn 99999999999999999999", "listen: conn: client ID must be a number\n"),
        ("drop 99999999999999999999", "listen: drop: client ID must be a number\n"),
    ],
)
def test_protocol_error_messages(server, command, expected):
    """Each malformed command has its own exact diagnostic on stdout.

    CATCHES: the server distinguishes a missing ID, a non-numeric ID, an
    out-of-range ID and an unknown-but-numeric ID, and all of them are written
    back over the socket (stdout) with exit status 0.
    """
    result = server.remote(command)
    assert result.returncode == 0
    assert result.stderr == b""
    assert result.stdout.decode() == expected


def test_protocol_errors_are_logged(server):
    """Server-side errors are also written to the server log.

    CATCHES: echoerr logs every diagnostic, so a headless server leaves a
    trace of rejected commands.
    """
    server.remote("hello")
    server.remote("query 1 maps")
    text = server.server_log_text()
    assert "listen: unexpected command: hello\n" in text
    assert "listen: query: no client with ID 1 connected\n" in text


def test_send_without_arguments_is_silent(server):
    """``send`` with nothing after it sends nothing and reports nothing.

    CATCHES: an empty rest is silently ignored rather than diagnosed, unlike
    conn/drop/query which require an ID.
    """
    result = server.remote("send")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""


def test_list_tolerates_trailing_arguments(server):
    """``list`` ignores everything after the first word."""
    result = server.remote("list extra arguments here")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""


def test_leading_whitespace_is_stripped(server, lf):
    """Leading blanks before the command word are ignored.

    CATCHES: splitWord trims leading whitespace, so ``'  send echo hi'`` is a
    broadcast and not an ``unexpected command:`` error.
    """
    client = lf.client()
    assert lf.wait_registered(client)
    result = server.remote("   send echo indented-command")
    assert result.returncode == 0
    assert result.stdout == b""
    assert "recv: echo indented-command" in client.recv_lines()


def test_empty_command_is_not_a_remote_call(server):
    """An empty ``-remote`` value never reaches the server at all.

    CATCHES: only a non-empty ``-remote`` selects the remote branch, so the
    empty string is handled by the normal client code path instead.
    """
    result = server.remote("")
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b""


def test_remote_error_output_is_not_on_stderr(server):
    """Protocol diagnostics never leak into stderr and never change the status.

    CATCHES: a re-implementation that prints server-side errors to stderr (or
    exits non-zero) would break every scripted ``lf -remote`` caller.
    """
    for command in ("hello", "conn", "query 3 x"):
        result = server.remote(command)
        assert result.returncode == 0
        assert result.stderr == b""
        assert result.stdout.endswith(b"\n")


def test_only_the_first_word_is_reported(server):
    """Only the leading word of an unknown command is echoed back.

    CATCHES: the diagnostic names the command word, not the whole line, so the
    remainder of a malformed command is not echoed to the caller.
    """
    result = server.remote("bogus rest of the line")
    assert result.stdout.decode() == "listen: unexpected command: bogus\n"


def test_drop_of_unknown_id_is_silent(server):
    """Dropping an ID that is not connected succeeds silently."""
    result = server.remote("drop 4242")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""


def test_send_broadcast_to_dead_connection(server, lf):
    """A broadcast that hits a closed client reports the write failure.

    CATCHES: the server reports the per-client write error and drops the dead
    connection from its list as a side effect.
    """
    import os
    import socket

    dead = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    dead.connect(__import__("conftest").socket_path(lf.env))
    dead.sendall(b"conn 4242\n")
    time_wait = 0.4
    import time

    time.sleep(time_wait)
    dead.close()
    time.sleep(0.4)
    assert 4242 in lf.list_ids()

    result = server.remote("send echo hello")
    assert result.returncode == 0
    out = strip_log_ts(result.stdout.decode())
    assert out.startswith("sending command to client 4242: write unix ")
    assert out.endswith("write: broken pipe\n")
    assert 4242 not in lf.list_ids()
