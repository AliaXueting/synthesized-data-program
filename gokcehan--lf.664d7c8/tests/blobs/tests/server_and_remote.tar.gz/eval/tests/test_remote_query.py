"""``lf -remote 'query <id> <key>'``: reading live client state over the socket.

The client only snapshots its state when it runs a shell command, so these
tests drive a registered client with the ``refresh`` user command (``$true``)
before querying it, exactly like the round-1 harness helper does.
"""

import os
import time


def make_files_dir(root, name, files):
    """Create a directory full of regular files and return its path."""
    path = os.path.join(root, name)
    os.makedirs(path, exist_ok=True)
    for fname in files:
        with open(os.path.join(path, fname), "w") as fh:
            fh.write("x\n")
    return path


def start_refreshed(lf, cwd=None, config=None, settle=1.0):
    """Start a client, wait for registration and snapshot its state once."""
    client = lf.client(cwd=cwd, config=config)
    assert lf.wait_registered(client)
    time.sleep(settle)
    lf.refresh_state(client, settle)
    return client


def test_query_files_lists_current_directory(server, lf):
    """``query <id> files`` returns one absolute path per line, sorted, with a
    trailing newline and with newline-named entries silently excluded."""
    # CATCHES: the listing uses full paths joined by newlines and drops any
    # entry whose name itself contains a newline, so the response stays a
    # well-formed line-per-file document.
    work = make_files_dir(lf.root, "qfiles", ["afile.txt", "bfile.txt", "nl\nx.txt"])
    client = start_refreshed(lf, cwd=work)
    assert lf.query(client, "files") == (
        "%s/afile.txt\n%s/bfile.txt\n" % (work, work)
    ).encode()


def test_query_jumps_lists_navigation_history(server, lf):
    """``query <id> jumps`` reports the jump list with the current directory
    marked by ``>`` and earlier directories numbered downwards."""
    # CATCHES: jumps are printed most-recent-first with a ``> 0`` marker for
    # the current position, not a plain list of visited directories.
    client = lf.client()  # cwd is lf.workdir, which has adir/ as first entry
    assert lf.wait_registered(client)
    time.sleep(1.0)
    client.send_keys("l")  # open adir -> cd into it
    time.sleep(1.0)
    lf.refresh_state(client, 1.0)
    assert lf.query(client, "jumps") == (
        "  jump\tpath\n> 0\t%s/adir\n  1\t%s\n" % (lf.workdir, lf.workdir)
    ).encode()


def test_query_cmds_lists_user_commands(server, lf):
    """``query <id> cmds`` lists the built-in and lfrc-defined commands of
    that client as a two-column table."""
    # CATCHES: the table is produced by the *client* from its own config, so
    # user commands defined in the lfrc appear next to the built-ins with the
    # exact ``${{ ... }}`` spelling of their body.
    config = os.path.join(lf.root, "cmds.lfrc")
    with open(config, "w") as fh:
        fh.write("cmd refresh $true\ncmd poke $touch poked\n")
    client = start_refreshed(lf, config=config)
    assert lf.query(client, "cmds") == (
        "name\t\tcommand\n"
        'cmaps\t\t${{ "$lf" -remote "query $id cmaps" | $PAGER }}\n'
        'cmds\t\t${{ "$lf" -remote "query $id cmds" | $PAGER }}\n'
        "help\t\t${{ \"$lf\" -doc | $PAGER }}\n"
        'maps\t\t${{ "$lf" -remote "query $id maps" | $PAGER }}\n'
        'nmaps\t\t${{ "$lf" -remote "query $id nmaps" | $PAGER }}\n'
        'open\t\t&{{ $OPENER "$f" }}\n'
        "poke\t\t${{ touch poked }}\n"
        "refresh\t\t${{ true }}\n"
        'vmaps\t\t${{ "$lf" -remote "query $id vmaps" | $PAGER }}\n'
    ).encode()


def test_query_maps_reports_merged_keybindings(server, lf):
    """``query <id> maps`` returns the merged normal+visual binding table with
    a ``mode`` column of ``n``/``v`` combinations."""
    # CATCHES: bindings shared by both modes are merged into ``nv`` rows and
    # the table is tab-aligned with a two-tab gap, not one tab.
    client = start_refreshed(lf)
    out = lf.query(client, "maps")
    assert out.startswith(b"mode\tkey\t\tcommand\n")
    for fragment in (
        b"nv\t<down>\t\tdown\n",
        b"v\t<esc>\t\tvisual-discard\n",
        b"nv\tza\t\tset info size:time\n",
    ):
        assert fragment in out
    modes = {line.split(b"\t")[0] for line in out.split(b"\n")[1:] if line}
    assert modes == {b"nv", b"n", b"v"}


def test_query_mode_specific_maps(server, lf):
    """``nmaps``/``vmaps`` report single-mode tables that only contain their
    own mode letter and their own mode-exclusive bindings."""
    # CATCHES: the mode column of nmaps is only ``n`` and of vmaps only ``v``,
    # and visual-only bindings never leak into the normal-mode table.
    client = start_refreshed(lf)
    nmaps = lf.query(client, "nmaps")
    vmaps = lf.query(client, "vmaps")
    assert nmaps.startswith(b"mode\tkey\t\tcommand\n")
    assert vmaps.startswith(b"mode\tkey\t\tcommand\n")
    n_modes = {line.split(b"\t")[0] for line in nmaps.split(b"\n")[1:] if line}
    v_modes = {line.split(b"\t")[0] for line in vmaps.split(b"\n")[1:] if line}
    assert n_modes == {b"n"}
    assert v_modes == {b"v"}
    assert b"v\tV\t\tvisual-accept\n" in vmaps
    assert b"v\tV\t\tvisual-accept\n" not in nmaps


def test_query_cmaps_lists_command_mode_bindings(server, lf):
    """``query <id> cmaps`` returns the command-line-mode bindings table."""
    # CATCHES: command mode has its own binding set (cmd-* commands) with the
    # single mode letter ``c`` and the same tab-aligned header as the others.
    client = start_refreshed(lf)
    out = lf.query(client, "cmaps")
    assert out.startswith(b"mode\tkey\t\tcommand\n")
    for fragment in (
        b"c\t<enter>\t\tcmd-enter\n",
        b"c\t<tab>\t\tcmd-complete\n",
        b"c\t<esc>\t\tcmd-escape\n",
    ):
        assert fragment in out
    modes = {line.split(b"\t")[0] for line in out.split(b"\n")[1:] if line}
    assert modes == {b"c"}


def test_query_history_records_read_commands(server, lf):
    """``query <id> history`` lists commands executed from the ``:`` prompt,
    keeping the leading prompt character in the recorded line."""
    # CATCHES: history lines are stored with their ``:`` prefix and printed
    # as a numbered table, ``number\tcommand`` header first.
    client = lf.client()
    assert lf.wait_registered(client)
    time.sleep(1.0)
    client.send_keys(":")
    time.sleep(0.5)
    client.send_keys("set hidden")
    time.sleep(0.5)
    client.send_keys("\r")
    time.sleep(1.0)
    lf.refresh_state(client, 1.0)
    assert lf.query(client, "history") == b"number\tcommand\n1\t:set hidden\n"


def test_query_state_exists_only_after_a_shell_command_ran(server, lf):
    """Before the client runs any shell command every key queries empty, and
    unknown or ``lf_``-prefixed keys stay empty even afterwards."""
    # CATCHES: the state map is populated by shell-command execution only, so
    # a freshly connected client answers every query with an empty (but
    # successful) response, and unknown keys never error out.
    client = lf.client()
    assert lf.wait_registered(client)
    time.sleep(1.0)
    assert lf.query(client, "maps") == b""
    assert lf.query(client, "files") == b""
    lf.refresh_state(client, 1.0)
    assert lf.query(client, "files") == (
        "%s/adir\n%s/bfile.txt\n" % (lf.workdir, lf.workdir)
    ).encode()
    assert lf.query(client, "nosuchkey") == b""
    assert lf.query(client, "lf_user_x") == b""


def test_query_state_updates_only_when_a_shell_command_runs(server, lf):
    """The reported state is the snapshot taken at the last shell command:
    navigating afterwards does not change the answer until the next refresh."""
    # CATCHES: ``query`` reads a cached snapshot rather than live state, so a
    # remote ``cd`` is invisible to it until the client runs a shell command.
    client = start_refreshed(lf)
    before = lf.query(client, "files")
    assert before == ("%s/adir\n%s/bfile.txt\n" % (lf.workdir, lf.workdir)).encode()
    result = server.remote("send %d cd %s" % (client.id, os.path.join(lf.workdir, "adir")))
    assert result.returncode == 0
    time.sleep(1.0)
    assert lf.query(client, "files") == before
    lf.refresh_state(client, 1.0)
    assert lf.query(client, "files") == b""  # adir is empty


def test_query_sanitizes_control_bytes_only_on_a_terminal(server, lf):
    """``query`` output keeps raw control bytes when stdout is a pipe but
    replaces them with U+FFFD when stdout is a terminal."""
    # CATCHES: the -remote process sanitizes untrusted names (here a file
    # named with BEL and ESC bytes) only when writing to a terminal, and the
    # pty also turns the final newline into CRLF.
    work = make_files_dir(lf.root, "qevil", ["evil\x07na\x1bme.txt"])
    client = start_refreshed(lf, cwd=work)
    piped = lf.remote("query %d files" % client.id)
    assert piped.returncode == 0
    raw = ("%s/evil\x07na\x1bme.txt\n" % work).encode()
    assert piped.stdout == raw
    tty = lf.remote("query %d files" % client.id, stdout_tty=True)
    assert tty.returncode == 0
    sanitized = raw.replace(b"\x07", b"\xef\xbf\xbd").replace(b"\x1b", b"\xef\xbf\xbd")
    assert tty.stdout == sanitized[:-1] + b"\r\n"  # the pty turns final LF into CRLF
