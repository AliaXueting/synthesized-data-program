"""``lf -remote`` when no server is listening on the socket."""

import os
import socket

from conftest import run_lf, socket_path, strip_log_ts


def test_remote_list_without_socket(lf):
    """``-remote list`` with no socket at all fails loudly on stderr.

    CATCHES: the remote command must fail with exit status 1 and a
    ``remote command: connecting to server: dial unix ...`` message on stderr
    instead of silently succeeding with empty output.
    """
    result = lf.remote("list")
    assert result.returncode == 1
    assert result.stdout == b""
    assert strip_log_ts(result.stderr.decode()) == (
        "remote command: connecting to server: dial unix %s: "
        "connect: no such file or directory\n" % socket_path(lf.env)
    )


def test_remote_send_without_socket(lf):
    """``send`` reports the same dial failure as any other remote command.

    CATCHES: the connection error is produced before the command word is
    inspected, so an unknown/valid command makes no difference.
    """
    result = lf.remote("send echo hi")
    assert result.returncode == 1
    assert result.stdout == b""
    assert "remote command: connecting to server: dial unix" in result.stderr.decode()


def test_remote_quit_without_socket(lf):
    """``quit`` without a server also exits 1 with the dial error.

    CATCHES: even a server-shutdown command is routed through the same
    connection path and never reports success when the socket is missing.
    """
    result = lf.remote("quit!")
    assert result.returncode == 1
    assert result.stdout == b""
    assert strip_log_ts(result.stderr.decode()).startswith(
        "remote command: connecting to server: dial unix"
    )


def test_remote_against_stale_socket(lf):
    """A socket file that nothing is bound to yields ``connection refused``.

    CATCHES: the dial error text distinguishes a missing socket file from a
    leftover socket file, which is exactly what checkServer repairs.
    """
    path = socket_path(lf.env)
    stale = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    stale.bind(path)
    stale.close()
    assert os.path.exists(path)

    result = lf.remote("list")
    assert result.returncode == 1
    assert result.stdout == b""
    assert strip_log_ts(result.stderr.decode()) == (
        "remote command: connecting to server: dial unix %s: "
        "connect: connection refused\n" % path
    )


def test_remote_against_plain_file_socket(lf):
    """A regular file sitting on the socket path is treated as a dead socket.

    CATCHES: the client only needs the dial to fail to consider the socket
    stale, so any non-listening path produces ``connection refused``.
    """
    path = socket_path(lf.env)
    with open(path, "w") as fh:
        fh.write("not a socket\n")

    result = lf.remote("list")
    assert result.returncode == 1
    assert "connect: connection refused" in strip_log_ts(result.stderr.decode())


def test_remote_empty_argument_starts_a_client(lf):
    """``-remote ''`` is *not* a remote command: it falls through to the client.

    CATCHES: only a non-empty ``-remote`` value selects the remote branch, so
    an empty string makes lf behave like a plain client invocation (which
    fails here because there is no terminal) while still spawning a server.
    """
    result = run_lf(["-remote", ""], lf.env, cwd=lf.env["HOME"])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b""
    # checkServer() ran before the client failed, so a detached server exists.
    from conftest import wait_socket

    assert wait_socket(lf.env)
    assert lf.remote("list").returncode == 0


def test_remote_ignores_log_flag(lf):
    """``-remote`` never opens a log file; only servers and clients do.

    CATCHES: the ``-log`` flag is only honoured by serve()/run(), so a remote
    command must not create the file.
    """
    lf.start_server()
    log = os.path.join(lf.root, "remote.log")
    result = run_lf(["-remote", "list", "-log", log], lf.env, cwd=lf.env["HOME"])
    assert result.returncode == 0
    assert not os.path.exists(log)


def test_remote_after_server_quit(lf):
    """Once the server quits the socket file is unlinked, not just closed.

    CATCHES: closing a unix listener removes its socket file, so a later
    remote command reports ``no such file or directory`` rather than
    ``connection refused``.
    """
    lf.start_server()
    assert lf.remote("quit!").returncode == 0
    result = lf.remote("list")
    assert result.returncode == 1
    assert "connect: no such file or directory" in strip_log_ts(result.stderr.decode())
    assert not os.path.exists(socket_path(lf.env))
