"""Client lifecycle on the socket: registration, list, drop and autoquit."""

import signal
import time

from conftest import socket_path


def test_client_registers_with_its_pid(server, lf):
    """A client connects using its PID as the client ID.

    CATCHES: the ID is the process id, so ``list`` output is predictable from
    the spawned process and not a random counter.
    """
    client = lf.client()
    assert lf.wait_registered(client)
    assert lf.list_ids() == [client.id]
    assert client.log_text().startswith(
        "*************** starting client, PID: %d ***************\n" % client.id
    )


def test_list_is_sorted_by_id(server, lf):
    """``list`` prints the connected IDs in ascending numeric order."""
    first = lf.client()
    assert lf.wait_registered(first)
    second = lf.client()
    assert lf.wait_registered(second)
    ids = lf.list_ids()
    assert sorted(ids) == ids
    assert set(ids) == {first.id, second.id}


def test_list_output_format(server, lf):
    """``list`` writes one ID per line, newline terminated."""
    client = lf.client()
    assert lf.wait_registered(client)
    result = server.remote("list")
    assert result.stdout == ("%d\n" % client.id).encode()
    assert result.stderr == b""


def test_client_sends_drop_when_it_quits(server, lf):
    """A client that quits normally deregisters itself before autoquitting.

    CATCHES: the client sends ``drop <pid>`` and then ``quit`` on exit, both
    of which are visible in the server log in that order.
    """
    client = lf.client()
    assert lf.wait_registered(client)
    client.send_keys("q")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0
    time.sleep(0.5)
    text = server.server_log_text()
    assert "listen: drop %d\n" % client.id in text
    assert text.index("listen: drop %d\n" % client.id) < text.index("listen: quit\n")


def test_autoquit_stops_server_with_last_client(server, lf):
    """With the default autoquit the server dies with its last client."""
    client = lf.client()
    assert lf.wait_registered(client)
    client.send_keys("q")
    assert client.wait_exit(10)
    assert server.server.wait(10) == 0
    assert not __import__("os").path.exists(socket_path(lf.env))


def test_noautoquit_keeps_server_alive(server, lf):
    """``set noautoquit`` leaves the server running after the client exits."""
    config = lf.root + "/noautoquit.lfrc"
    with open(config, "w") as fh:
        fh.write("set noautoquit\n")
    client = lf.client(config=config)
    assert lf.wait_registered(client)
    client.send_keys("q")
    assert client.wait_exit(10)
    time.sleep(1.0)
    assert server.server.poll() is None
    assert lf.wait_ids([])
    assert "listen: drop %d\n" % client.id in server.server_log_text()


def test_server_survives_while_another_client_remains(server, lf):
    """Autoquit only triggers when the *last* client disconnects."""
    first = lf.client()
    assert lf.wait_registered(first)
    second = lf.client()
    assert lf.wait_registered(second)
    second.send_keys("q")
    assert second.wait_exit(10)
    assert lf.wait_ids([first.id])
    assert server.server.poll() is None


def test_client_killed_by_signal_exits_three(server, lf):
    """SIGTERM makes the client exit with status 3 after deregistering.

    CATCHES: the signal handler runs the normal quit path (drop + autoquit)
    and then exits with the dedicated status 3 instead of 0.
    """
    client = lf.client()
    assert lf.wait_registered(client)
    client.proc.send_signal(signal.SIGTERM)
    assert client.wait_exit(10)
    assert client.proc.returncode == 3
    assert "received termination signal: terminated\n" in client.log_text()
    assert "listen: drop %d\n" % client.id in server.server_log_text()


def test_drop_command_disconnects_a_client(server, lf):
    """``drop <id>`` closes the client's connection and removes it from list.

    CATCHES: dropping does not stop the client process, but the server forgets
    the ID so later sends to it fail with ``no client with ID``.
    """
    client = lf.client()
    assert lf.wait_registered(client)
    result = server.remote("drop %d" % client.id)
    assert result.returncode == 0
    assert result.stdout == b""
    time.sleep(0.5)
    assert lf.list_ids() == []
    result = server.remote("send %d echo hi" % client.id)
    assert result.stdout.decode() == "listen: send: no client with ID %d connected\n" % client.id
    assert client.proc.poll() is None


def test_graceful_quit_keeps_connected_clients(server, lf):
    """``quit`` only shuts the server down once no client is connected.

    CATCHES: with a client attached the server stays alive and sends an empty
    line to every client, which clients must ignore.
    """
    client = lf.client()
    assert lf.wait_registered(client)
    result = server.remote("quit")
    assert result.returncode == 0
    assert result.stdout == b""
    time.sleep(0.8)
    assert server.server.poll() is None
    assert lf.list_ids() == [client.id]
    assert "recv: " in client.recv_lines()
    assert client.proc.poll() is None


def test_force_quit_notifies_and_disconnects_clients(server, lf):
    """``quit!`` closes the server immediately and tells the clients why.

    CATCHES: every client receives ``echo server is quitting...`` and the
    server process exits with status 0 while the client keeps running.
    """
    client = lf.client()
    assert lf.wait_registered(client)
    result = server.remote("quit!")
    assert result.returncode == 0
    assert result.stdout == b""
    assert server.server.wait(10) == 0
    time.sleep(0.8)
    assert "recv: echo server is quitting..." in client.recv_lines()
    assert client.proc.poll() is None
    # the client is now offline: a new server can be started on the same path
    server.server = None
    lf.start_server(log=lf.server_log)
    assert lf.list_ids() == []


def test_selection_change_is_broadcast_to_all_clients(server, lf):
    """``copy`` in one client broadcasts ``sync`` to every connected client.

    CATCHES: cross-client synchronisation goes through the server, so both the
    originating client and the other one receive the ``sync`` line.
    """
    first = lf.client()
    assert lf.wait_registered(first)
    second = lf.client()
    assert lf.wait_registered(second)
    first.send_keys("y")
    time.sleep(1.5)
    assert "recv: sync" in first.recv_lines()
    assert "recv: sync" in second.recv_lines()
