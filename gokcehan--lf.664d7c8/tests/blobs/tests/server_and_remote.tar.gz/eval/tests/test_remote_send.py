"""``lf -remote 'send ...'``: driving one or all connected clients.

``send <command>`` broadcasts to every connected client while
``send <id> <command>`` targets one; the command line is parsed by the client
exactly like an lfrc statement (built-ins, ``set``/``map`` and user commands).
"""

import os
import time


def test_targeted_send_runs_a_builtin_command_on_one_client(server, lf):
    """``send <id> cd <dir>`` navigates only the addressed client."""
    # CATCHES: the command is delivered to exactly one client, visible in its
    # jump list, while the other client's jump list is untouched.
    first = lf.client()
    assert lf.wait_registered(first)
    second = lf.client()
    assert lf.wait_registered(second)
    result = server.remote("send %d cd %s" % (second.id, os.path.join(lf.workdir, "adir")))
    assert result.returncode == 0
    assert result.stdout == b""
    time.sleep(1.0)
    lf.refresh_state(second, 1.0)
    lf.refresh_state(first, 1.0)
    assert lf.query(second, "jumps") == (
        "  jump\tpath\n> 0\t%s/adir\n  1\t%s\n" % (lf.workdir, lf.workdir)
    ).encode()
    assert lf.query(first, "jumps") == ("  jump\tpath\n> 0\t%s\n" % lf.workdir).encode()


def test_targeted_send_quit_exits_only_that_client(server, lf):
    """``send <id> quit`` terminates just the addressed client, which exits
    with status 0 and is removed from the server's list."""
    # CATCHES: a remotely quit client deregisters itself like a locally quit
    # one, while every other client keeps running and stays connected.
    first = lf.client()
    assert lf.wait_registered(first)
    second = lf.client()
    assert lf.wait_registered(second)
    result = server.remote("send %d quit" % second.id)
    assert result.returncode == 0
    assert result.stdout == b""
    assert second.wait_exit(10)
    assert second.proc.returncode == 0
    assert lf.wait_ids([first.id])
    assert first.proc.poll() is None


def test_targeted_send_set_statement_is_evaluated(server, lf):
    """``send <id> set hidden`` toggles an option in the addressed client,
    observable through the ``files`` state snapshot."""
    # CATCHES: ``set`` statements sent over the socket are evaluated like
    # lfrc statements, and the effect shows up in later query responses
    # (here the dotfile appears between the directory and the plain file).
    with open(os.path.join(lf.workdir, ".hidden.txt"), "w") as fh:
        fh.write("x\n")
    client = lf.client()
    assert lf.wait_registered(client)
    time.sleep(1.0)
    lf.refresh_state(client, 1.0)
    assert lf.query(client, "files") == (
        "%s/adir\n%s/bfile.txt\n" % (lf.workdir, lf.workdir)
    ).encode()
    result = server.remote("send %d set hidden" % client.id)
    assert result.returncode == 0
    time.sleep(1.0)
    lf.refresh_state(client, 1.0)
    assert lf.query(client, "files") == (
        "%s/adir\n%s/.hidden.txt\n%s/bfile.txt\n" % (lf.workdir, lf.workdir, lf.workdir)
    ).encode()


def test_targeted_send_map_statement_defines_a_binding(server, lf):
    """``send <id> map Z quit`` installs a new key binding in the client."""
    # CATCHES: ``map`` statements sent remotely are evaluated immediately, so
    # a freshly mapped key quits the client when pressed afterwards.
    client = lf.client()
    assert lf.wait_registered(client)
    result = server.remote("send %d map Z quit" % client.id)
    assert result.returncode == 0
    assert result.stdout == b""
    time.sleep(1.2)
    client.send_keys("Z")
    assert client.wait_exit(10)
    assert client.proc.returncode == 0


def test_targeted_send_invokes_a_user_command(server, lf):
    """``send <id> <usercmd>`` runs an lfrc-defined command in that client."""
    # CATCHES: user commands reach the client through the same channel and
    # execute with the client's working directory, not the caller's.
    config = os.path.join(lf.root, "poke.lfrc")
    with open(config, "w") as fh:
        fh.write("cmd refresh $true\ncmd poke $touch poked\n")
    client = lf.client(config=config)
    assert lf.wait_registered(client)
    result = server.remote("send %d poke" % client.id)
    assert result.returncode == 0
    assert result.stdout == b""
    time.sleep(1.2)
    assert os.path.exists(os.path.join(lf.workdir, "poked"))


def test_broadcast_send_runs_a_user_command_on_every_client(server, lf):
    """``send <usercmd>`` (no ID) runs the command in every connected client,
    each with its own working directory."""
    # CATCHES: the broadcast reaches all clients simultaneously, so side
    # effects appear in every client's directory, not just the first one.
    config = os.path.join(lf.root, "poke.lfrc")
    with open(config, "w") as fh:
        fh.write("cmd refresh $true\ncmd poke $touch poked\n")
    first_dir = os.path.join(lf.root, "b-one")
    second_dir = os.path.join(lf.root, "b-two")
    os.makedirs(first_dir, exist_ok=True)
    os.makedirs(second_dir, exist_ok=True)
    first = lf.client(config=config, cwd=first_dir)
    assert lf.wait_registered(first)
    second = lf.client(config=config, cwd=second_dir)
    assert lf.wait_registered(second)
    result = server.remote("send poke")
    assert result.returncode == 0
    assert result.stdout == b""
    time.sleep(1.5)
    assert os.path.exists(os.path.join(first_dir, "poked"))
    assert os.path.exists(os.path.join(second_dir, "poked"))
