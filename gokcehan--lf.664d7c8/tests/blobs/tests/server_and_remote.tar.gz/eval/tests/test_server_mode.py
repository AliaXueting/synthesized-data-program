"""``lf -server``: the headless foreground server process."""

import os
import stat
import subprocess
import time

from conftest import run_lf, socket_path, wait_socket


def test_server_creates_socket(lf):
    """``-server`` listens on ${XDG_RUNTIME_DIR}/lf.sock and keeps running.

    CATCHES: the socket path is resolved from the environment at start-up and
    the server must stay in the foreground instead of daemonising.
    """
    lf.start_server()
    assert os.path.exists(socket_path(lf.env))
    time.sleep(1.0)
    assert lf.server.poll() is None


def test_socket_permissions(lf):
    """The socket is created 0700 because the server sets a 0077 umask.

    CATCHES: the server applies a restrictive umask so other users cannot talk
    to (or inject commands into) a running lf session.
    """
    lf.start_server()
    mode = stat.S_IMODE(os.stat(socket_path(lf.env)).st_mode)
    assert mode == 0o700


def test_server_writes_start_line_to_log(lf):
    """The server log starts with the fixed banner line.

    CATCHES: the server opens (and appends to) ``-log`` and records its own
    start-up, which is the only observable trace of a headless server.
    """
    lf.start_server(log=lf.server_log)
    assert lf.server_log_text().startswith(
        "*************** starting server ***************\n"
    )


def test_server_logs_every_received_command(lf):
    """Every line received on the socket is logged as ``listen: <line>``.

    CATCHES: the server logs the raw command text before validation, so even
    rejected commands appear in the log in arrival order.
    """
    lf.start_server(log=lf.server_log)
    lf.remote("list")
    lf.remote("hello")
    lf.remote("query 7 maps")
    time.sleep(0.3)
    text = lf.server_log_text()
    assert "listen: list\n" in text
    assert "listen: hello\n" in text
    assert "listen: query 7 maps\n" in text


def test_second_server_cannot_bind(lf):
    """A second server on the same socket fails, logs, and exits with 0.

    CATCHES: the bind failure is only reported through the log file, and the
    process still exits successfully, leaving the first server untouched.
    """
    lf.start_server(log=lf.server_log)
    second_log = os.path.join(lf.root, "second.log")
    result = run_lf(["-server", "-log", second_log], lf.env, cwd=lf.env["HOME"])
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    with open(second_log) as fh:
        text = fh.read()
    assert "listening socket: listen unix %s: bind: address already in use\n" % socket_path(
        lf.env
    ) in text
    # the original server keeps serving
    assert lf.server.poll() is None
    assert lf.remote("list").returncode == 0


def test_server_exits_zero_on_force_quit(lf):
    """``quit!`` makes the foreground server process return exit status 0."""
    lf.start_server()
    assert lf.remote("quit!").returncode == 0
    assert lf.server.wait(10) == 0


def test_server_unlinks_socket_on_quit(lf):
    """Quitting removes the socket file from the runtime directory."""
    lf.start_server()
    lf.remote("quit!")
    lf.server.wait(10)
    assert not os.path.exists(socket_path(lf.env))


def test_server_log_is_appended(lf):
    """Restarting the server appends to an existing log file.

    CATCHES: the log is opened with O_APPEND, so the second run adds a second
    start/close banner pair instead of truncating the file.
    """
    lf.start_server(log=lf.server_log)
    lf.remote("quit!")
    lf.server.wait(10)
    lf.start_server(log=lf.server_log)
    lf.remote("quit!")
    lf.server.wait(10)
    text = lf.server_log_text()
    assert text.count("*************** starting server ***************") == 2
    assert text.count("*************** closing server ***************") == 2


def test_server_bad_log_path(lf):
    """A log file that cannot be created is fatal before the socket is made.

    CATCHES: the log file is opened first, so an unusable path aborts the
    server with exit status 1 and an ``opening log file:`` message on stderr.
    """
    bad = os.path.join(lf.root, "no", "such", "dir", "lf.log")
    result = run_lf(["-server", "-log", bad], lf.env, cwd=lf.env["HOME"])
    assert result.returncode == 1
    assert result.stdout == b""
    from conftest import strip_log_ts

    assert strip_log_ts(result.stderr.decode()) == (
        "opening log file: open %s: no such file or directory\n" % bad
    )
    assert not os.path.exists(socket_path(lf.env))


def test_server_without_xdg_runtime_dir(lf, tmp_path):
    """Without XDG_RUNTIME_DIR the socket lives in $TMPDIR/lf-<uid>/lf.sock.

    CATCHES: the per-user 0700 fallback directory is created on demand under
    the temporary directory, so the socket address changes but works.
    """
    import conftest

    env = conftest.make_env(
        tmp_path, XDG_RUNTIME_DIR=None, TMPDIR=os.path.join(str(tmp_path), "tmp")
    )
    proc = subprocess.Popen(
        [conftest.lf_binary(), "-server"],
        env=conftest.child_env(env),
        cwd=env["HOME"],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    try:
        expected = os.path.join(env["TMPDIR"], "lf-%d" % os.getuid(), "lf.sock")
        deadline = time.time() + 20
        while time.time() < deadline and not os.path.exists(expected):
            time.sleep(0.05)
        assert os.path.exists(expected)
        import stat as stat_mod

        assert stat_mod.S_IMODE(os.stat(os.path.dirname(expected)).st_mode) == 0o700
        result = run_lf(["-remote", "list"], env, cwd=env["HOME"])
        assert result.returncode == 0
        assert result.stdout == b""
    finally:
        run_lf(["-remote", "quit!"], env, cwd=env["HOME"])
        proc.wait(10)


def test_client_run_spawns_a_detached_server(lf):
    """A normal client automatically starts a server when the socket is absent.

    CATCHES: checkServer() spawns ``$lf -server`` detached, so even a client
    that dies immediately (no terminal here) leaves a usable server behind.
    """
    assert not os.path.exists(socket_path(lf.env))
    result = run_lf([], lf.env, cwd=lf.env["HOME"])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b""
    assert wait_socket(lf.env)
    assert lf.remote("list").stdout == b""


def test_client_repairs_a_stale_socket(lf):
    """A leftover socket file is removed and replaced by a live one.

    CATCHES: the client dials the socket, and on failure deletes the stale
    file before spawning the replacement server.
    """
    import socket as socket_mod

    path = socket_path(lf.env)
    stale = socket_mod.socket(socket_mod.AF_UNIX, socket_mod.SOCK_STREAM)
    stale.bind(path)
    stale.close()

    result = run_lf([], lf.env, cwd=lf.env["HOME"])
    assert result.returncode == 1
    assert wait_socket(lf.env)
    assert lf.remote("list").returncode == 0


def test_client_reuses_a_live_server(lf):
    """A working server is never restarted by an additional client."""
    lf.start_server(log=lf.server_log)
    run_lf([], lf.env, cwd=lf.env["HOME"])
    time.sleep(0.5)
    assert lf.server_log_text().count("*************** starting server ***************") == 1
    assert lf.server.poll() is None
