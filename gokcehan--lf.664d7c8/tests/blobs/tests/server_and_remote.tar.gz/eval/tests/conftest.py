"""Shared helpers for the `server_and_remote` module tests.

Every test drives the reference binary through ``PROGRAMGYM_EXECUTABLE``.  The
helpers below pin a hermetic child environment (private ``XDG_RUNTIME_DIR`` so
the unix socket lives inside ``tmp_path``), start/stop servers and spawn real
lf clients on a private pseudo terminal so the server<->client protocol can be
observed exactly as a user would exercise it.
"""

import fcntl
import os
import pty
import re
import select
import signal
import socket
import struct
import subprocess
import termios
import time

import pytest

# ``log`` prefixes every message with "YYYY/MM/DD HH:MM:SS ".
LOG_TIMESTAMP = re.compile(r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ", re.M)

SOCKET_TIMEOUT = 20.0
REGISTER_TIMEOUT = 20.0


def lf_binary():
    """Absolute path of the program under test."""
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not exe:
        raise RuntimeError("PROGRAMGYM_EXECUTABLE is not set")
    return exe


def coverage_env():
    """Extra environment that must reach the child for coverage collection."""
    return {k: v for k, v in (("GOCOVERDIR", os.environ.get("GOCOVERDIR")),) if v}


def child_env(base):
    """Merge the pinned base environment with the coverage variables."""
    env = dict(base)
    env.update(coverage_env())
    return env


def strip_log_ts(text):
    """Drop the volatile ``log`` timestamp prefix from every line."""
    return LOG_TIMESTAMP.sub("", text)


def run_lf(args, env, cwd=None, timeout=30, stdout_tty=False):
    """Run the lf binary once and capture stdout/stderr/exit status.

    The child is started in a new session so it never inherits (or creates) a
    controlling terminal, which keeps the non-TTY code paths deterministic.
    With ``stdout_tty`` the child's stdout is a pseudo terminal instead of a
    pipe, so terminal-only behaviours (e.g. sanitizing output) can be observed.
    """
    if stdout_tty:
        master, slave = pty.openpty()
        proc = subprocess.Popen(
            [lf_binary()] + list(args),
            env=child_env(env),
            cwd=cwd,
            stdin=subprocess.DEVNULL,
            stdout=slave,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
        os.close(slave)
        try:
            proc.wait(timeout)
            out = b""
            while True:
                ready, _, _ = select.select([master], [], [], 0.2)
                if not ready:
                    break
                try:
                    data = os.read(master, 65536)
                except OSError:
                    break
                if not data:
                    break
                out += data
        finally:
            os.close(master)
        return subprocess.CompletedProcess(
            list(args), proc.returncode, out, proc.stderr.read()
        )
    return subprocess.run(
        [lf_binary()] + list(args),
        env=child_env(env),
        cwd=cwd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        start_new_session=True,
    )


def make_env(root, **overrides):
    """A fully pinned environment rooted at ``root`` (inside tmp_path)."""
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": os.path.join(str(root), "home"),
        "TERM": "screen",
        "SHELL": "/bin/sh",
        "TMPDIR": os.path.join(str(root), "tmp"),
        "XDG_RUNTIME_DIR": os.path.join(str(root), "runtime"),
        "XDG_CONFIG_HOME": os.path.join(str(root), "config"),
        "XDG_DATA_HOME": os.path.join(str(root), "data"),
        "LANG": "C",
        "LC_ALL": "C",
    }
    for key, value in overrides.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    for name in ("home", "tmp", "runtime", "config", "data"):
        os.makedirs(os.path.join(str(root), name), exist_ok=True)
    return env


def socket_path(env):
    return os.path.join(env["XDG_RUNTIME_DIR"], "lf.sock")


def wait_socket(env, timeout=SOCKET_TIMEOUT):
    """Wait until the lf socket exists *and* accepts connections."""
    path = socket_path(env)
    deadline = time.time() + timeout
    while time.time() < deadline:
        if os.path.exists(path):
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                s.connect(path)
                return True
            except OSError:
                pass
            finally:
                s.close()
        time.sleep(0.05)
    return False


class PtyClient:
    """A live lf client running on its own pseudo terminal.

    lf's tcell screen needs a controlling terminal, so the slave side of the
    pty is made the session's controlling terminal.  A background thread keeps
    draining the terminal so the client never blocks on write.
    """

    def __init__(self, env, args=(), cwd=None, config=None, log=None, cols=90, rows=25,
                 stdout_pipe=False, extra_env=None):
        self.env = env
        argv = [lf_binary()]
        if config is not None:
            argv += ["-config", config]
        if log is not None:
            argv += ["-log", log]
        argv += list(args)
        self.argv = argv
        self.cwd = cwd or env["HOME"]
        self.log_path = log
        self._out = b""
        self._err = b""
        self._pipe_out = b""
        self._lock = __import__("threading").Lock()
        self._alive = True

        master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        self._master = master
        child = dict(env)
        if extra_env:
            child.update(extra_env)
        self.proc = subprocess.Popen(
            argv,
            stdin=slave,
            stdout=subprocess.PIPE if stdout_pipe else slave,
            stderr=subprocess.PIPE,
            env=child_env(child),
            cwd=self.cwd,
            preexec_fn=lambda: _set_controlling_tty(slave),
        )
        os.close(slave)
        import threading

        self._thread = threading.Thread(target=self._pump, daemon=True)
        self._thread.start()

    @property
    def id(self):
        """The client ID, which is the PID of the client process."""
        return self.proc.pid

    def _pump(self):
        import threading

        watched = [self._master, self.proc.stderr.fileno()]
        if self.proc.stdout is not None:
            watched.append(self.proc.stdout.fileno())
        while self._alive:
            try:
                ready, _, _ = select.select(watched, [], [], 0.05)
            except (OSError, ValueError):
                break
            for fd in ready:
                try:
                    data = os.read(fd, 65536)
                except OSError:
                    self._alive = False
                    continue
                if not data:
                    self._alive = False
                    continue
                with self._lock:
                    if fd == self._master:
                        self._out += data
                    elif self.proc.stdout is not None and fd == self.proc.stdout.fileno():
                        self._pipe_out += data
                    else:
                        self._err += data

    @property
    def output(self):
        with self._lock:
            return self._out

    @property
    def pipe_output(self):
        """Bytes written to the client's stdout when it is a pipe."""
        with self._lock:
            return self._pipe_out

    @property
    def stderr(self):
        """Bytes written to the client's stderr pipe."""
        with self._lock:
            return self._err

    def send_keys(self, data):
        if isinstance(data, str):
            data = data.encode()
        try:
            os.write(self._master, data)
        except OSError:
            pass

    def wait_exit(self, timeout=10):
        try:
            self.proc.wait(timeout)
        except subprocess.TimeoutExpired:
            return False
        return True

    def log_text(self):
        if not self.log_path or not os.path.exists(self.log_path):
            return ""
        with open(self.log_path, "r", errors="surrogateescape") as fh:
            return strip_log_ts(fh.read())

    def recv_lines(self):
        """The ``recv:`` log lines, i.e. everything the server sent us."""
        return [line for line in self.log_text().splitlines() if line.startswith("recv: ")]

    def stop(self):
        if self.proc.poll() is None:
            try:
                self.proc.send_signal(signal.SIGTERM)
            except OSError:
                pass
            if not self.wait_exit(5):
                self.proc.kill()
                self.wait_exit(5)
        self._alive = False
        try:
            os.close(self._master)
        except OSError:
            pass
        return self.proc.returncode


def _set_controlling_tty(slave_fd):
    """Make ``slave_fd`` the controlling terminal of the new session."""
    os.setsid()
    try:
        fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)
    except Exception:
        pass


class Harness:
    """One hermetic lf world: environment + server + clients."""

    def __init__(self, root):
        self.root = str(root)
        self.env = make_env(root)
        self.workdir = os.path.join(self.root, "work")
        os.makedirs(self.workdir, exist_ok=True)
        # a couple of entries so that navigation/selection commands have
        # something to work on
        os.makedirs(os.path.join(self.workdir, "adir"), exist_ok=True)
        with open(os.path.join(self.workdir, "bfile.txt"), "w") as fh:
            fh.write("content\n")
        self.config = os.path.join(self.root, "lfrc")
        with open(self.config, "w") as fh:
            fh.write("cmd refresh $true\n")
        self.server_log = os.path.join(self.root, "server.log")
        self.server = None
        self.clients = []

    # -- server -----------------------------------------------------------
    def start_server(self, log=None):
        self.server = subprocess.Popen(
            [lf_binary(), "-server"] + (["-log", log] if log else []),
            env=child_env(self.env),
            cwd=self.env["HOME"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        assert wait_socket(self.env), "server did not create a connectable socket"
        return self.server

    def server_log_text(self):
        if not os.path.exists(self.server_log):
            return ""
        with open(self.server_log, "r", errors="surrogateescape") as fh:
            return strip_log_ts(fh.read())

    # -- remote -----------------------------------------------------------
    def remote(self, command, timeout=30, stdout_tty=False):
        return run_lf(
            ["-remote", command],
            self.env,
            cwd=self.env["HOME"],
            timeout=timeout,
            stdout_tty=stdout_tty,
        )

    def remote_out(self, command):
        """stdout of ``lf -remote <command>`` decoded as text."""
        return self.remote(command).stdout.decode(errors="surrogateescape")

    def list_ids(self):
        return [int(x) for x in self.remote_out("list").split()]

    def wait_ids(self, expected, timeout=REGISTER_TIMEOUT):
        """Poll ``list`` until the connected IDs equal ``expected``."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                if self.list_ids() == sorted(expected):
                    return True
            except Exception:
                pass
            time.sleep(0.05)
        return False

    def wait_registered(self, client, timeout=REGISTER_TIMEOUT):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                if client.id in self.list_ids():
                    return True
            except Exception:
                pass
            time.sleep(0.05)
        return False

    # -- clients ----------------------------------------------------------
    def client(self, args=(), config=None, log=None, cwd=None, stdout_pipe=False, extra_env=None):
        c = PtyClient(
            self.env,
            args=args,
            config=self.config if config is None else config,
            log=log if log is not None else os.path.join(self.root, "client-%d.log" % len(self.clients)),
            cwd=cwd or self.workdir,
            stdout_pipe=stdout_pipe,
            extra_env=extra_env,
        )
        self.clients.append(c)
        return c

    def query(self, client, key):
        """stdout bytes of ``lf -remote 'query <id> <key>'`` for a live client."""
        return self.remote("query %d %s" % (client.id, key)).stdout

    def refresh_state(self, client, settle=0.5):
        """Make the client run a shell command so it snapshots its state.

        ``query`` only reports the state captured the last time the client ran
        a shell command, so tests that change state remotely ask the client to
        re-run ``cmd refresh`` (defined as ``$true``) before querying.
        """
        self.remote("send refresh")
        time.sleep(settle)

    # -- teardown ---------------------------------------------------------
    def shutdown(self):
        for client in self.clients:
            try:
                client.stop()
            except Exception:
                pass
        if self.server is not None and self.server.poll() is None:
            try:
                run_lf(["-remote", "quit!"], self.env, cwd=self.env["HOME"], timeout=10)
            except Exception:
                pass
            try:
                self.server.wait(5)
            except subprocess.TimeoutExpired:
                self.server.kill()
                self.server.wait(5)
        # Any server spawned indirectly (checkServer) is best-effort stopped.
        try:
            if os.path.exists(socket_path(self.env)):
                run_lf(["-remote", "quit!"], self.env, cwd=self.env["HOME"], timeout=10)
        except Exception:
            pass


@pytest.fixture
def lf(tmp_path):
    """A hermetic environment; a server is started on demand."""
    h = Harness(tmp_path)
    yield h
    h.shutdown()


@pytest.fixture
def server(lf):
    """A harness with a server already listening on the private socket."""
    lf.start_server(log=lf.server_log)
    yield lf
