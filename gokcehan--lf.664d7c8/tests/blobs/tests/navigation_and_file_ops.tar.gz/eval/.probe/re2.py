"""Probe F: quit-refusal, progress, paste overwrite semantics, misc."""
import sys, os, time, shutil, stat, subprocess, re
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree, run_lf
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    return LfEnv(root / name)


# ---- F1: quit refused during copy + progress ruler ---------------------------
env = fresh("f1")
w = root / "f1w"
make_tree(w, {"src/": None, "dst/": None})
big = w / "src" / "big.bin"
t0 = time.time()
with open(big, "wb") as f:
    f.write(b"\0" * (400 * 1024 * 1024))
print("F1 write time  : %.2fs" % (time.time() - t0))
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.send("set rulerfile %s" % c.ruler_paths["progress"])
c.drain(0.1)
t0 = time.time()
c.send("paste")
c.send("quit")
# sample the ruler quickly during the copy
samples = []
while time.time() - t0 < 2.0:
    c.send("redraw")
    time.sleep(0.03)
    rows = c.drain(0.03)
    from conftest import render_rows
    rr = render_rows(rows, c.rows, c.cols)
    if rr[-1].strip():
        samples.append(rr[-1].strip())
    if (w / "dst" / "big.bin").exists() and (w / "dst" / "big.bin").stat().st_size == 400 * 1024 * 1024:
        break
print("F1 samples     :", samples[:6])
print("F1 quit err    :", c.errors()[-1:])
print("F1 alive       :", os.kill(c.pid, 0) is None)
c.wait_for(lambda: (w / "dst" / "big.bin").stat().st_size == 400 * 1024 * 1024, 25)
print("F1 copy took   : %.2fs" % (time.time() - t0))
print("F1 final prog  :", c.ruler("progress"))
c.send("quit")
print("F1 quit after  :", "exited" if c.wait_exit(5) is not None else "STILL ALIVE")
env.shutdown()

# ---- F2: paste dup numbering + move onto existing ----------------------------
env = fresh("f2")
w = root / "f2w"
make_tree(w, {"src/": None, "dst/": None})
(w / "src" / "f.txt").write_text("v1\n")
(w / "dst" / "f.txt").write_text("existing\n")
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "f.txt.~1~").exists(), 8)
print("F2 copy onto   :", sorted(os.listdir(w / "dst")))
print("F2 msgs        :", c.messages()[-3:])
env.shutdown()

env = fresh("f2b")
w = root / "f2bw"
make_tree(w, {"src/": None, "dst/": None})
(w / "src" / "m.txt").write_text("moving\n")
(w / "dst" / "m.txt").write_text("existing\n")
c = env.client(w / "src")
c.cmd("cut")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "m.txt.~1~").exists(), 8)
print("F2 move onto   :", sorted(os.listdir(w / "dst")))
print("F2 move msgs   :", c.messages()[-3:])
print("F2 src left    :", sorted(os.listdir(w / "src")))
env.shutdown()

# ---- F3: move onto itself (same file) -----------------------------------------
env = fresh("f3")
w = root / "f3w"
make_tree(w, {"f.txt": "x\n"})
c = env.client(w)
c.cmd("cut")
c.cmd("paste")
time.sleep(0.5)
print("F3 same file   :", sorted(os.listdir(w)), "| err:", [e for e in c.errors() if "same" in e][:1])
print("F3 msgs        :", c.messages()[-2:])
env.shutdown()

# ---- F4: searchmethod regex error ---------------------------------------------
env = fresh("f4")
w = root / "f4w"
make_tree(w, {"apple": None, "banana": None})
c = env.client(w)
c.cmd("set searchmethod regex")
c.send("search")
c.push("[<enter>")
time.sleep(0.2)
print("F4 regex err   :", c.errors()[-1:])
env.shutdown()

# ---- F5: cd - with no previous dir ---------------------------------------------
env = fresh("f5")
w = root / "f5w"
make_tree(w, {"a": None})
c = env.client(w)
c.cmd("cd -")
time.sleep(0.2)
print("F5 cd - err    :", c.errors()[-1:])
c.cmd("cd %s" % w)
c.cmd("cd -")
time.sleep(0.2)
print("F5 cd - after  :", c.state()["pwd"], "| err:", c.errors()[-1:])
env.shutdown()

# ---- F6: calcdirsize on multiple dirs ------------------------------------------
env = fresh("f6")
w = root / "f6w"
make_tree(w, {"d1/": None, "d2/": None, "d3/": None})
(w / "d1" / "a").write_text("x" * 100)
(w / "d2" / "b").write_text("y" * 200)
(w / "d2" / "c").write_text("z" * 300)
(w / "d3" / "d").write_text("q" * 50)
c = env.client(w, config="set dircounts\n")
c.cmd("glob-select d*")
c.cmd("calcdirsize")
time.sleep(0.5)
c.state()
r = c.ruler("stat")
print("F6 calc d1     :", r)
c.cmd("select d2")
print("F6 calc d2     :", c.ruler("stat"))
c.cmd("select d3")
print("F6 calc d3     :", c.ruler("stat"))
env.shutdown()

# ---- F7: visual-unselect --------------------------------------------------------
env = fresh("f7")
w = root / "f7w"
make_tree(w, {("f%d" % i): None for i in range(6)})
c = env.client(w)
c.cmd("visual")
c.cmd("down"); c.cmd("down")
c.cmd("visual-accept")
print("F7 accepted    :", c.ruler("state"))
c.cmd("visual")
c.cmd("down")
c.cmd("visual-unselect")
print("F7 unselect    :", c.ruler("state"), "| fx:", [os.path.basename(x) for x in c.state()["fx"].split("\n") if x])
env.shutdown()

# ---- F8: move progress message + clear -----------------------------------------
env = fresh("f8")
w = root / "f8w"
make_tree(w, {"src/": None, "dst/": None})
(w / "src" / "a.txt").write_text("a\n")
(w / "src" / "b.txt").write_text("b\n")
c = env.client(w / "src")
c.cmd("glob-select *")
c.cmd("cut")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: sorted(os.listdir(w / "dst")) == ["a.txt", "b.txt"], 8)
print("F8 moved       :", sorted(os.listdir(w / "dst")))
print("F8 clipboard   :", repr((root / "f8" / "data" / "lf" / "files").read_text()))
print("F8 ruler clip  :", c.ruler("clip"))
print("F8 errors      :", c.errors())
env.shutdown()
print("DONE F")
