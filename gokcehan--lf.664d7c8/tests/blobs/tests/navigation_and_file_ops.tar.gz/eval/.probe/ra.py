"""Probe A: directory listing, hiddenfiles, sorting, filtering."""
import sys, os, time, shutil
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh():
    env = LfEnv(root / ("e%d" % fresh.n))
    fresh.n += 1
    return env
fresh.n = 0

# ---- A1: hidden / hiddenfiles -------------------------------------------
env = fresh()
w = root / "a1"
make_tree(w, {".git/": None, ".env": "x\n", "a.txt": "1\n", "b.TXT": "2\n", "keep.md": "3\n"})
c = env.client(w)
print("A1 default        :", c.files(), "|", c.ruler("state"))
c.cmd("set hidden")
print("A1 hidden         :", c.files())
c.cmd("set nohidden")
c.cmd("set hiddenfiles *.txt")
print("A1 hf=*.txt       :", c.files(), "|", c.ruler("state"))
c.cmd('set hiddenfiles "*.txt:*.*"')
print("A1 hf=*.txt:*.*   :", c.files())
c.cmd("set hidden")
print("A1 hf+hidden      :", c.files())
c.cmd('set hiddenfiles ".*:!.git"')
print("A1 hf=.*:!.git    :", c.files())
c.cmd('set hiddenfiles "["')
print("A1 hf=[           :", c.files(), "errors:", c.errors())
c.cmd('set hiddenfiles ""')
print("A1 hf=''          :", c.files(), "errors:", c.errors()[-1:])
env.shutdown()

# ---- A2: dironly / dircounts --------------------------------------------
env = fresh()
w = root / "a2"
make_tree(w, {"d1/": None, "d2/d2x/": None, "d2/f1.txt": "1\n", "d2/f2.txt": "2\n",
              "plain": "12345\n", "z.txt": "z\n"})
c = env.client(w)
print("A2 default        :", c.files())
c.cmd("set dironly")
print("A2 dironly        :", c.files())
c.cmd("set nodironly")
c.cmd("set dircounts")
print("A2 dircounts stat :", c.cmd("select d1") and None or c.ruler("stat"))
print("A2 dircounts d2   :", (c.cmd("select d2"), c.ruler("stat"))[1])
c.cmd("select d2")
c.cmd("calcdirsize")
time.sleep(0.3)
c.state()
print("A2 d2 after calc  :", c.ruler("stat"))
env.shutdown()

# ---- A3: sorting ----------------------------------------------------------
env = fresh()
w = root / "a3"
make_tree(w, {"file1": None, "file2": None, "file10": None, "file20": None, "File3": None})
c = env.client(w)
print("A3 natural        :", c.files())
c.cmd("set sortby name")
print("A3 name           :", c.files())
c.cmd("set sortby invalid")
print("A3 sortby invalid :", c.files(), "errors:", c.errors()[-1:])
c.cmd("set sortby natural")
c.cmd("set reverse")
print("A3 reverse        :", c.files())
c.cmd("set noreverse")
c.cmd("set sortignorecase!")
print("A3 sortignorecase :", c.files())
c.cmd("set sortignorecase!")
env.shutdown()

env = fresh()
w = root / "a3b"
make_tree(w, {"a.md": None, "b.txt": None, "c": None, "d.md": None, "e.TXT": None})
c = env.client(w)
c.cmd("set sortby ext")
print("A3 ext            :", c.files())
c.cmd("set sortby natural")
env.shutdown()

# size sort
env = fresh()
w = root / "a3c"
make_tree(w, {"big": "x" * 5000, "small": "x" * 10, "mid": "x" * 100, "dir/": None})
c = env.client(w)
c.cmd("set sortby size")
print("A3 size           :", c.files())
c.cmd("set reverse")
print("A3 size reverse   :", c.files())
env.shutdown()

# time sort with explicit mtimes
env = fresh()
w = root / "a3d"
make_tree(w, {"old.txt": None, "new.txt": None, "mid.txt": None})
os.utime(w / "old.txt", (1000000000, 1000000000))
os.utime(w / "mid.txt", (1500000000, 1500000000))
os.utime(w / "new.txt", (2000000000, 2000000000))
c = env.client(w)
c.cmd("set sortby time")
print("A3 time           :", c.files())
c.cmd("set sortby ctime")
print("A3 ctime          :", c.files())
env.shutdown()

# diacritics
env = fresh()
w = root / "a3e"
make_tree(w, {"eclair.txt": None, "éclair.txt": None, "zebra.txt": None, "eiffel.txt": None})
c = env.client(w)
print("A3 dia default    :", c.files())
c.cmd("set nosortignoredia")
print("A3 dia off        :", c.files())
env.shutdown()

# custom sort via addcustominfo
env = fresh()
w = root / "a3f"
make_tree(w, {"one.txt": None, "two.txt": None, "three.txt": None})
c = env.client(w)
c.cmd("addcustominfo one.txt 3")
c.cmd("addcustominfo two.txt 1")
c.cmd("addcustominfo three.txt 2")
c.state()
print("A3 custominfo stat:", c.cmd("select one.txt") and None or c.ruler("stat"))
c.cmd("set sortby custom")
print("A3 custom sort    :", c.files())
c.cmd("addcustominfo nosuch.txt 0")
print("A3 custom err     :", c.errors()[-1:])
env.shutdown()

# re-sort when option changes without reload
env = fresh()
w = root / "a3g"
make_tree(w, {"b1": None, "a2": None, "a10": None})
c = env.client(w)
print("A3 before         :", c.files())
c.cmd("set sortby name")
print("A3 after sortby   :", c.files())
c.cmd("setlocal %s sortby name" % w)
c.cmd("setlocal %s reverse true" % w)
print("A3 setlocal       :", c.files())
env.shutdown()

# ---- A4: filtering ---------------------------------------------------------
env = fresh()
w = root / "a4"
make_tree(w, {"foo.txt": None, "bar.txt": None, "foobar.md": None, "other": None})
c = env.client(w)
c.cmd("setfilter foo")
print("A4 filter foo     :", c.files(), "|", c.ruler("state"))
c.cmd("setfilter bar foo")
print("A4 filter bar foo :", c.files())
c.cmd("setfilter !foo")
print("A4 filter !foo    :", c.files())
c.cmd("setfilter")
print("A4 setfilter none :", c.files())
c.cmd("set filtermethod glob")
c.cmd("setfilter *.txt")
print("A4 glob *.txt     :", c.files())
c.cmd("setfilter *.md")
print("A4 glob *.md      :", c.files())
c.cmd("set filtermethod regex")
c.cmd("setfilter ^foo")
print("A4 regex ^foo     :", c.files())
c.cmd("setfilter [")
print("A4 regex [        :", c.files(), "errors:", c.errors()[-1:])
c.cmd("setfilter (a|b)")
print("A4 regex (a|b)    :", c.files())
env.shutdown()

# filter reset on cd + filter prompt display
env = fresh()
w = root / "a5"
make_tree(w, {"sub/": None, "f1.txt": None, "f2.md": None})
(w / "sub" / "inner.txt").write_text("x\n")
c = env.client(w)
c.cmd("setfilter txt")
print("A5 filtered       :", c.files())
c.cmd("cd %s" % (w / "sub"))
print("A5 after cd       :", c.files(), "|", c.ruler("state"))
c.cmd("cd -")
print("A5 back           :", c.files(), "|", c.ruler("state"))
env.shutdown()

# incfilter via prompt
env = fresh()
w = root / "a6"
make_tree(w, {"apple.txt": None, "apricot.txt": None, "banana.txt": None})
c = env.client(w, config="set incfilter\n")
c.cmd("filter")
c.push("ap")
c.state()
print("A6 incfilter ap   :", c.files(), "|", c.ruler("state"))
c.push("p")
c.state()
print("A6 incfilter app  :", c.files())
c.push("<enter>")
c.state()
print("A6 after enter    :", c.files(), "|", c.ruler("state"))
env.shutdown()
print("DONE A")
