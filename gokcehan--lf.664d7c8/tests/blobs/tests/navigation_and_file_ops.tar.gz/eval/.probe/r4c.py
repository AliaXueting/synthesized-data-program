"""Round-4 probe C: previewer/cleaner, find-single, search-back, reload,
quit-refusal and progress during a long copy, symlink watch alias."""
import sys, os, time, shutil, stat, subprocess, re
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    return LfEnv(root / name)


def sec(title):
    print("\n========== %s ==========" % title, flush=True)


# ---- C1: previewer and cleaner ------------------------------------------------
sec("C1 previewer/cleaner")
env = fresh("c1")
w = make_tree(root / "c1w", {"one.txt": "1\n", "two.txt": "2\n", "three.txt": "3\n", "zz_empty/": None})
args = root / "c1" / "prev-args"
clean = root / "c1" / "clean-args"
prev = root / "c1" / "prev.sh"
prev.write_text('#!/bin/sh\nprintf \'%%s\\n\' "$*" >> %s\necho "PREVIEWMARK $1"\n' % args)
prev.chmod(0o755)
cleaner = root / "c1" / "clean.sh"
cleaner.write_text('#!/bin/sh\nprintf \'%%s\\n\' "$*" >> %s\n' % clean)
cleaner.chmod(0o755)
c = env.client(w, config="set previewer %s\n" % prev, rows=24, cols=100)
c.cmd("select one.txt")
c.wait_for(lambda: args.exists() and "one.txt" in args.read_text(), 8)
time.sleep(0.3)
print("previewer args: %r" % args.read_text())
rows = c.screen()
print("rows with marker: %r" % [r for r in rows if "PREVIEWMARK" in r])
c.cmd("select two.txt")
c.wait_for(lambda: "two.txt" in args.read_text(), 8)
time.sleep(0.2)
print("previewer args after move: %r" % args.read_text())
prev2 = root / "c1" / "prev2.sh"
prev2.write_text('#!/bin/sh\nprintf \'%%s\\n\' "$*" >> %s\nexit 1\n' % args)
prev2.chmod(0o755)
c.cmd("set cleaner %s" % cleaner)
c.cmd("set previewer %s" % prev2)
c.cmd("select three.txt")
c.wait_for(lambda: "three.txt" in args.read_text(), 8)
time.sleep(0.3)
print("args after volatile previewer: %r" % args.read_text())
c.cmd("cd %s" % (w / "zz_empty"))
c.wait_for(lambda: clean.exists() and clean.read_text() != "", 8)
print("cleaner args: %r" % clean.read_text())

# ---- C2: preload mode ---------------------------------------------------------
sec("C2 preload")
env = fresh("c2")
w = make_tree(root / "c2w", {"a1": None, "a2": None, "a3": None, "a4": None})
args = root / "c2" / "prev-args"
prev = root / "c2" / "prev.sh"
prev.write_text('#!/bin/sh\nprintf \'%%s\\n\' "$*" >> %s\n' % args)
prev.chmod(0o755)
c = env.client(w, config="set previewer %s\nset preload\n" % prev, rows=24, cols=100)
time.sleep(1.0)
print("args with preload: %r" % args.read_text())

# ---- C3: find single match jumps immediately ----------------------------------
sec("C3 find single")
env = fresh("c3")
w = make_tree(root / "c3w", {"apple": None, "apricot": None, "banana": None})
c = env.client(w)
c.send("find")
c.push("b")
print("cursor after typing b (no enter): %r" % os.path.basename(c.state()["f"]))
c.push("<escape>")
time.sleep(0.2)
print("errors: %r" % c.errors())

# ---- C4: search-back ----------------------------------------------------------
sec("C4 search-back")
env = fresh("c4")
w = make_tree(root / "c4w", {"apple": None, "Apricot": None, "banana": None})
c = env.client(w)
c.cmd("select banana")
c.send("search-back")
c.push("an<enter>")
print("cursor after search-back an from banana: %r" % os.path.basename(c.state()["f"]))
c.cmd("select apple")
c.send("search-back")
c.push("an<enter>")
print("cursor after search-back an from top: %r" % os.path.basename(c.state()["f"]))
print("errors: %r" % c.errors())

# ---- C5: reload ---------------------------------------------------------------
sec("C5 reload")
env = fresh("c5")
w = make_tree(root / "c5w", {"a": None})
c = env.client(w)
(w / "newfile").write_text("x")
c.cmd("reload")
c.wait_for(lambda: "newfile" in c.files(), 5)
print("after reload: %r" % c.files())
print("errors: %r" % c.errors())

# ---- C6: quit refused while copy in progress + progress ruler -----------------
sec("C6 quit during copy")
env = fresh("c6")
w = make_tree(root / "c6w", {"src/": None, "dst/": None})
big = w / "src" / "big.bin"
with open(big, "wb") as f:
    f.seek(200 * 1024 * 1024 - 1)
    f.write(b"\0")
t0 = time.time()
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.send("paste")
c.send("quit")
seen = []
deadline = time.time() + 15
while time.time() < deadline:
    r = c.ruler("progress")
    seen.append(r)
    if not (w / "dst" / "big.bin").exists() or (w / "dst" / "big.bin").stat().st_size == 200 * 1024 * 1024:
        break
print("copy took %.2fs" % (time.time() - t0))
print("progress samples: %r" % seen[:12])
print("errors: %r" % c.errors())
print("client still alive: %r" % (c.wait_exit(0.5) is None))
c.wait_for(lambda: (w / "dst" / "big.bin").stat().st_size == 200 * 1024 * 1024, 20)
print("final size: %d" % (w / "dst" / "big.bin").stat().st_size)
c.cmd("quit")
print("exited after op done: %r" % (c.wait_exit(5) is not None))

# ---- C7: watch symlink alias fan-out -------------------------------------------
sec("C7 watch alias")
env = fresh("c7")
real = make_tree(root / "c7w", {"real/": None})
alias_parent = make_tree(root / "c7ap", {})
(alias_parent / "alias").symlink_to(real / "real", target_is_directory=True)
c1 = env.client(real / "real", config="set watch\n")
c2 = env.client(alias_parent / "alias", config="set watch\n")
print("c1 pwd: %r  c2 pwd: %r" % (c1.state()["pwd"], c2.state()["pwd"]))
(real / "real" / "via-real").write_text("x")
c1.wait_for(lambda: "via-real" in c1.files(), 6)
print("c1 sees: %r" % c1.files())
c2.wait_for(lambda: "via-real" in c2.files(), 6)
print("c2 (symlinked cwd) sees: %r" % c2.files())

# ---- C8: move progress and quit during move ------------------------------------
sec("C8 quit during move")
env = fresh("c8")
w = make_tree(root / "c8w", {"src/": None, "dst/": None})
for i in range(400):
    (w / "src" / ("f%03d" % i)).write_text("x" * 10)
c = env.client(w / "src")
c.cmd("invert")
c.cmd("cut")
c.cmd("cd %s" % (w / "dst"))
c.send("paste")
c.send("quit")
time.sleep(0.8)
print("errors: %r" % c.errors())
print("alive: %r" % (c.wait_exit(0.3) is None))
c.wait_for(lambda: len(os.listdir(w / "dst")) == 400, 20)
print("moved %d files" % len(os.listdir(w / "dst")))
c.cmd("quit")
print("exited: %r" % (c.wait_exit(5) is not None))

print("\nPROBE C DONE")
