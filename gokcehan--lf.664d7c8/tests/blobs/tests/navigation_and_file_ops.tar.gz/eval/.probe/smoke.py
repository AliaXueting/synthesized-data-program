import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree
from pathlib import Path

exe = sys.argv[1]
os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(exe)
root = Path(sys.argv[2])
import shutil
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)
env = LfEnv(root / "env")
work = root / "work"
make_tree(work, {"f1.txt": "one\n", "f2.txt": "twotwo\n", "sub/": None, ".hidden": "h\n"})
c = env.client(work)
print("files:", c.files())
print("state:", c.state())
print("ruler:", c.ruler("state"))
print("ruler stat:", c.ruler("stat"))
print("ruler df:", c.ruler("df"))
c.cmd("set hidden")
print("files hidden:", c.files())
print("ruler hidden:", c.ruler("state"))
c.cmd("setfilter f1")
print("files filtered:", c.files())
print("ruler filtered:", c.ruler("state"))
print("screen rows 0..3:", c.screen()[:4])
print("errors:", c.errors())
env.shutdown()
print("OK")
