"""Probe B: cursor/navigation, selection, visual mode, jump list."""
import sys, os, time, shutil, stat
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    env = LfEnv(root / name)
    return env


# ---- B1: btime / atime ordering ------------------------------------------
env = fresh("b1")
w = root / "b1w"
make_tree(w, {"a": None, "b": None, "c": None})
os.utime(w / "a", (1600000000, 1600000000))   # atime+mtime
os.utime(w / "b", (1700000000, 1700000000))
os.utime(w / "c", (1500000000, 1500000000))
c = env.client(w)
c.cmd("set sortby atime")
print("B1 atime  :", c.files())
c.cmd("set sortby btime")
print("B1 btime  :", c.files())
c.cmd("set sortby natural")
env.shutdown()

# ---- B2: counts and movement ----------------------------------------------
env = fresh("b2")
w = root / "b2w"
make_tree(w, {("f%02d" % i): None for i in range(12)})
c = env.client(w, rows=20, cols=110)
def f():
    return os.path.basename(c.state()["f"])
print("B2 start       :", f())
for keys in ["5j", "3k", "10j", "G", "gg", "2G", "M", "L", "H"]:
    c.push(keys)
    print("B2 push %-4s  ->" % keys, f())
# half/page/scroll with counts
c.push("gg")
c.push("5<c-d>")
print("B2 5<c-d>      :", f())
c.push("2<c-f>")
print("B2 2<c-f>      :", f())
c.push("3<c-e>")
print("B2 3<c-e>      :", f())
c.push("3<c-y>")
print("B2 3<c-y>      :", f())
c.push("2<c-u>")
print("B2 2<c-u>      :", f())
c.push("2<c-b>")
print("B2 2<c-b>      :", f())
print("B2 scroll ruler:", c.ruler("state"))
env.shutdown()

# ---- B3: scrolloff / wrapscroll --------------------------------------------
env = fresh("b3")
w = root / "b3w"
make_tree(w, {("f%02d" % i): None for i in range(30)})
c = env.client(w, rows=20, cols=110)
c.cmd("set scrolloff 5")
def f():
    return os.path.basename(c.state()["f"])
c.push("10j")
print("B3 scrolloff 10j:", f(), "|", c.ruler("state"))
c.push("gg")
print("B3 gg           :", f())
c.cmd("set wrapscroll")
c.push("k")
print("B3 wrapscroll k :", f(), "|", c.ruler("state"))
c.push("Gj")
print("B3 G+ j (wrap)  :", f())
c.cmd("set noscrolloff")
env.shutdown()

# ---- B4: updir / cd --------------------------------------------------------
env = fresh("b4")
w = root / "b4w"
make_tree(w, {"sub/": None, "x.txt": None})
(w / "sub" / "inner.txt").write_text("i\n")
c = env.client(w / "sub")
print("B4 start       :", c.files())
c.cmd("updir")
st = c.state()
print("B4 updir       :", c.files(), "| f:", os.path.basename(st["f"]), "| pwd:", st["pwd"])
c.cmd("open")
st = c.state()
print("B4 open dir    :", c.files(), "| f:", os.path.basename(st["f"]))
c.cmd("cd %s" % w)
print("B4 cd abs      :", c.state()["pwd"])
c.cmd("cd sub")
print("B4 cd rel      :", c.state()["pwd"])
c.cmd("cd ~")
print("B4 cd ~        :", c.state()["pwd"])
c.cmd("cd -")
print("B4 cd -        :", c.state()["pwd"])
c.cmd("cd /etc/passwd")
c.cmd("cd /does/not/exist")
time.sleep(0.2)
print("B4 cd errors   :", c.errors())
env.shutdown()

# ---- B5: jump list ----------------------------------------------------------
env = fresh("b5")
w = root / "b5w"
make_tree(w, {"a/": None, "b/": None, "c/": None})
c = env.client(w)
print("B5 jumps init  :", repr(c.query("jumps")))
c.cmd("cd a")
print("B5 jumps cda   :", repr(c.query("jumps")))
c.cmd("cd ../b")
print("B5 jumps cdb   :", repr(c.query("jumps")))
c.cmd("jump-prev")
print("B5 jump-prev   :", c.state()["pwd"])
print("B5 jumps now   :", repr(c.query("jumps")))
c.cmd("jump-next")
print("B5 jump-next   :", c.state()["pwd"])
c.cmd("jump-prev")
c.cmd("jump-prev")
print("B5 prev twice  :", c.state()["pwd"])
c.cmd("jump-prev")
print("B5 prev at end :", c.state()["pwd"], "| errors:", c.errors())
env.shutdown()

# ---- B6: cursor restore on return ------------------------------------------
env = fresh("b6")
w = root / "b6w"
make_tree(w, {"a1": None, "a2": None, "a3": None, "sub/": None})
c = env.client(w)
c.push("3j")
print("B6 cursor      :", os.path.basename(c.state()["f"]))
c.cmd("cd sub")
c.cmd("cd ..")
print("B6 restored    :", os.path.basename(c.state()["f"]), "|", c.ruler("state"))
c.cmd("select a3")
print("B6 select a3   :", os.path.basename(c.state()["f"]), "|", c.ruler("state"))
c.cmd("select nosuch")
print("B6 select err  :", c.errors())
env.shutdown()

# ---- B7: selection ----------------------------------------------------------
env = fresh("b7")
w = root / "b7w"
make_tree(w, {"a": None, "b": None, "c": None, "d/": None})
c = env.client(w)
c.cmd("toggle")
print("B7 toggle      :", c.state())
c.cmd("down")
c.cmd("toggle")
print("B7 toggle 2    :", repr(c.state()["fx"]))
c.cmd("invert")
print("B7 invert      :", sorted(c.state()["fx"].split("\n")))
c.cmd("invert")
c.cmd("glob-select *")
print("B7 glob-select :", sorted(os.path.basename(x) for x in c.state()["fx"].split("\n")))
c.cmd("glob-unselect b")
print("B7 glob-unsel  :", sorted(os.path.basename(x) for x in c.state()["fx"].split("\n")))
c.cmd("glob-select [")
print("B7 glob err    :", c.errors()[-1:])
c.cmd("unselect")
print("B7 unselect    :", repr(c.state()["fx"]))
env.shutdown()

# ---- B8: selmode -------------------------------------------------------------
env = fresh("b8")
w = root / "b8w"
make_tree(w, {"a": None, "b": None, "d/": None, "e/": None})
c = env.client(w)
c.cmd("set selmode dir")
c.cmd("invert")
print("B8 selmode dir :", sorted(os.path.basename(x) for x in c.state()["fx"].split("\n")))
c.cmd("unselect")
c.cmd("set selmode none")
c.cmd("invert")
print("B8 selmode none:", repr(c.state()["fx"]), "| errors:", c.errors())
env.shutdown()

# ---- B9: visual mode ---------------------------------------------------------
env = fresh("b9")
w = root / "b9w"
make_tree(w, {("f%d" % i): None for i in range(6)})
c = env.client(w)
c.cmd("visual")
print("B9 visual      :", "|", c.ruler("state"))
c.cmd("down")
c.cmd("down")
print("B9 visual +2   :", c.ruler("state"))
print("B9 fv visual   :", sorted(os.path.basename(x) for x in c.state()["fv"].split("\n")))
c.cmd("visual-change")
c.cmd("up")
print("B9 change+up   :", c.ruler("state"), "| fv:", sorted(os.path.basename(x) for x in c.state()["fv"].split("\n")))
c.cmd("visual-accept")
print("B9 accepted    :", c.ruler("state"))
print("B9 fx accepted :", sorted(os.path.basename(x) for x in c.state()["fx"].split("\n")))
c.cmd("visual")
c.cmd("down")
c.cmd("visual-discard")
print("B9 discarded   :", c.ruler("state"), "| fx:", repr(c.state()["fx"]))
env.shutdown()
print("DONE B")
