import os, pty, select, struct, fcntl, termios, sys, time, subprocess, re

class LF:
    def __init__(self, exe, root, cwd, config="", args=(), rows=30, cols=100, env_extra=None):
        self.exe = os.path.abspath(exe)
        self.root = str(root)
        self.env = {
            'PATH': '/usr/bin:/bin:/usr/local/bin',
            'HOME': self.root + '/home', 'TERM': 'xterm-256color',
            'XDG_RUNTIME_DIR': self.root + '/run', 'LF_DATA_HOME': self.root + '/data',
            'LF_CONFIG_HOME': self.root + '/config', 'SHELL': '/bin/sh',
            'OPENER': 'true', 'EDITOR': 'true', 'PAGER': 'cat',
        }
        if env_extra:
            self.env.update(env_extra)
        for d in ('home', 'run', 'data', 'config/lf'):
            os.makedirs(self.root + '/' + d, exist_ok=True)
        self.cfg = self.root + '/config/lf/lfrc'
        with open(self.cfg, 'w') as f:
            f.write(config)
        self.marker = self.root + '/marker'
        open(self.marker, 'w').close()
        self.args = ['-config', self.cfg] + list(args)
        self.cwd = str(cwd)
        self.pid, self.master = pty.fork()
        if self.pid == 0:
            try:
                os.chdir(self.cwd)
                os.environ.clear()
                os.environ.update(self.env)
                os.execv(self.exe, [self.exe] + self.args)
            except Exception:
                os._exit(99)
        fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))
        self.wait_ready()
        # wait until the initial directory has been read from disk
        deadline = time.time() + 10
        while time.time() < deadline:
            if self.refresh().strip():
                break
            time.sleep(0.03)

    def drain(self, timeout=0.2):
        out = b''
        end = time.time() + timeout
        while time.time() < end:
            r, _, _ = select.select([self.master], [], [], max(0.0, end - time.time()))
            if not r:
                break
            try:
                d = os.read(self.master, 65536)
            except OSError:
                break
            if not d:
                break
            out += d
        return out

    def remote(self, req, check=True):
        p = subprocess.run([self.exe, '-remote', req], env=self.env,
                           capture_output=True, timeout=20)
        if check and p.returncode != 0:
            raise RuntimeError("remote %r failed: %s %s" % (req, p.stdout, p.stderr))
        return p.stdout.decode()

    def wait_ready(self, timeout=15):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                out = self.remote('list', check=False)
                if str(self.pid) in out.split():
                    return
            except Exception:
                pass
            time.sleep(0.05)
        raise RuntimeError('client never registered with server')

    def send(self, cmd, wait=False):
        n0 = self.marker_count()
        self.remote('send %d %s' % (self.pid, cmd))
        if wait:
            self.wait_marker(n0)

    def marker_count(self):
        try:
            return len(open(self.marker).read())
        except FileNotFoundError:
            return 0

    def wait_marker(self, old, timeout=10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.marker_count() > old:
                return True
            self.drain(0.02)
            time.sleep(0.02)
        raise RuntimeError('marker did not advance')

    def shell(self, cmd, timeout=10):
        n0 = self.marker_count()
        self.remote('send %d &%s; printf x >> %s' % (self.pid, cmd, self.marker))
        self.wait_marker(n0, timeout)

    def refresh(self):
        self.send('&printf x >> %s' % self.marker)
        return self.remote('query %d files' % self.pid)

    def quit(self, timeout=10):
        self.remote('send %d quit' % self.pid, check=False)
        deadline = time.time() + timeout
        while time.time() < deadline:
            p, st = os.waitpid(self.pid, os.WNOHANG)
            if p == self.pid:
                return st
            time.sleep(0.02)
        os.kill(self.pid, 9)
        return os.waitpid(self.pid, 0)[1]
