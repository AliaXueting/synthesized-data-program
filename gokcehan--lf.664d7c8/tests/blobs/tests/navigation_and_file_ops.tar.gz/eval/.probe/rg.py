"""Probe G: precise movement, stat fields for special files, misc edges."""
import sys, os, time, shutil, stat
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    return LfEnv(root / name)


def cur(c):
    return os.path.basename(c.state()["f"])


# ---- G1: movement with a controlled window -------------------------------------
env = fresh("g1")
w = root / "g1w"
make_tree(w, {("f%02d" % i): None for i in range(30)})
c = env.client(w, rows=10, cols=100, config="set nopreview\n")
print("G1 start       :", cur(c), "|", c.ruler("state"))
for cmd in ["down", "down 3", "up", "up 2", "half-down", "half-down",
            "half-up", "page-down", "page-up", "scroll-down", "scroll-down 2",
            "scroll-up", "bottom", "top", "5G"]:
    c.cmd(cmd)
    print("G1 %-12s ->" % cmd, cur(c), "|", c.ruler("state").split("S[")[1].split("]")[0])
env.shutdown()

# ---- G2: scrolloff ---------------------------------------------------------------
env = fresh("g2")
w = root / "g2w"
make_tree(w, {("f%02d" % i): None for i in range(30)})
c = env.client(w, rows=10, cols=100, config="set nopreview\nset scrolloff 2\n")
c.cmd("down 5")
print("G2 down 5      :", cur(c))
c.cmd("down 3")
print("G2 down 8      :", cur(c))
c.cmd("bottom")
print("G2 bottom      :", cur(c), "|", c.ruler("state").split("S[")[1].split("]")[0])
c.cmd("up 3")
print("G2 up from bot :", cur(c))
env.shutdown()

# ---- G3: stat fields ---------------------------------------------------------------
env = fresh("g3")
w = root / "g3w"
make_tree(w, {
    "reg.txt": "hello\n",
    "sub/": None,
    "sub/deep/": None,
    "exec.sh": "#!/bin/sh\n",
    "@link.txt": "reg.txt",
    "@broken": "nowhere",
    "noext": "x\n",
    ".dotfile": "d\n",
    "archive.tar.gz": "x\n",
})
os.chmod(w / "exec.sh", 0o755)
c = env.client(w, config="set hidden\n")
for name in ["reg.txt", "sub", "exec.sh", "link.txt", "broken", "noext", ".dotfile", "archive.tar.gz"]:
    c.cmd("select %s" % name)
    print("G3 %-15s:" % name, c.ruler("stat"))
print("G3 sub linkcnt :", end=" ")
c.cmd("select sub")
env.shutdown()

env = fresh("g3b")
w = root / "g3bw"
make_tree(w, {"d/": None})
(w / "d" / "x").write_text("y\n")
(w / "d" / "e").mkdir()
c = env.client(w)
c.cmd("select d")
print("G3b dir w/sub  :", c.ruler("stat"))
env.shutdown()

# ---- G4: toggle preserves selection; invert order -----------------------------------
env = fresh("g4")
w = root / "g4w"
make_tree(w, {"a": None, "b": None, "c": None})
c = env.client(w)
c.cmd("toggle")
c.cmd("down")
c.cmd("toggle")
c.cmd("down")
print("G4 toggles     :", [os.path.basename(x) for x in c.state()["fs"].split("\n") if x])
c.cmd("toggle")  # toggle c off
print("G4 untoggle    :", [os.path.basename(x) for x in c.state()["fs"].split("\n") if x])
c.cmd("invert")
print("G4 invert      :", [os.path.basename(x) for x in c.state()["fs"].split("\n") if x])
env.shutdown()

# ---- G5: filtered movement -----------------------------------------------------------
env = fresh("g5")
w = root / "g5w"
make_tree(w, {"a1": None, "a2": None, "b1": None, "b2": None, "b3": None})
c = env.client(w)
c.cmd("setfilter a")
print("G5 filtered    :", c.files(), "|", c.ruler("state"))
c.cmd("down")
print("G5 down        :", cur(c), "|", c.ruler("state"))
c.cmd("down")
print("G5 down past   :", cur(c), "| err:", c.errors()[-1:])
env.shutdown()

# ---- G6: cd to file / cd errors --------------------------------------------------------
env = fresh("g6")
w = root / "g6w"
make_tree(w, {"f.txt": "x\n", "sub/": None})
c = env.client(w)
c.cmd("cd f.txt")
time.sleep(0.2)
print("G6 cd file     :", c.state()["pwd"], "| err:", c.errors()[-1:])
c.cmd("cd sub/../sub")
print("G6 cd rel dot  :", c.state()["pwd"])
c.cmd("cd")
time.sleep(0.2)
print("G6 cd noarg    :", c.state()["pwd"], "| err:", c.errors()[-1:])
env.shutdown()
print("DONE G")
