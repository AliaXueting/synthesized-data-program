import sys, os, shutil, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import LF
exe = sys.argv[1]; root = sys.argv[2]
shutil.rmtree(root, ignore_errors=True); os.makedirs(root)
d = root + '/work'; os.makedirs(d)
open(d + '/one.txt','w').write('1\n'); open(d + '/two.txt','w').write('2\n')
prev = root + '/prev.sh'
open(prev,'w').write('#!/bin/sh\nprintf "PREV %s\\n" "$*" >> ' + root + '/prev.log\n')
clean = root + '/clean.sh'
open(clean,'w').write('#!/bin/sh\nprintf "CLEAN %s\\n" "$*" >> ' + root + '/prev.log\n')
os.chmod(prev, 0o755); os.chmod(clean, 0o755)
lf = LF(exe, root, d, rows=14, cols=110,
        config='set nohistory\nset previewer %s\nset cleaner %s\n' % (prev, clean),
        args=['-log', root+'/lf.log', '-print-last-dir', '-print-selection', '-selection-path', root+'/sel.txt'])
time.sleep(0.6)
print("prev.log:", open(root+'/prev.log').read() if os.path.exists(root+'/prev.log') else '(none)')
lf.send('toggle'); lf.send('down')
lf.send('open')
time.sleep(1.0)
print("sel.txt:", repr(open(root+'/sel.txt').read()))
p, st = os.waitpid(lf.pid, os.WNOHANG)
print("exited:", p != 0, "status", st)
try:
    os.kill(lf.pid, 0); lf.quit()
except Exception: pass
