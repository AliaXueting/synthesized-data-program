import re
CSI_H = re.compile(rb'\x1b\[(\d+);(\d+)H')
STRIP = re.compile(
    rb'\x1b\[[0-9;?<>!]*[a-zA-Z]'
    rb'|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)'
    rb'|\x1b[()][A-Za-z0-9]'
    rb'|\x1b[=>78MDEHc]'
    rb'|[\x00-\x08\x0b-\x1f\x7f]'
)
def render_rows(data, rows, cols):
    idx = data.rfind(b'\x1b[H\x1b[J')
    if idx >= 0:
        data = data[idx + 4:]
    screen = [[' '] * cols for _ in range(rows)]
    matches = list(CSI_H.finditer(data))
    for i, m in enumerate(matches):
        r, c = int(m.group(1)), int(m.group(2))
        end = matches[i + 1].start() if i + 1 < len(matches) else len(data)
        text = STRIP.sub(b'', data[m.end():end]).decode('utf-8', 'replace')
        if 1 <= r <= rows:
            for k, ch in enumerate(text):
                if c - 1 + k < cols:
                    screen[r - 1][c - 1 + k] = ch
    return [''.join(r).rstrip() for r in screen]
