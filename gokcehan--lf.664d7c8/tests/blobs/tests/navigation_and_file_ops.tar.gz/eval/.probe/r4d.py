"""Round-4 probe D: quit-refusal during copy, copy progress ruler, watch alias."""
import sys, os, time, shutil, re
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    return LfEnv(root / name)


def sec(title):
    print("\n========== %s ==========" % title, flush=True)


# ---- D1: quit refused during copy, progress visible ----------------------------
sec("D1 quit during copy + progress")
env = fresh("d1")
w = make_tree(root / "d1w", {"src/": None, "dst/": None})
big = w / "src" / "big.bin"
with open(big, "wb") as f:
    f.seek(800 * 1024 * 1024 - 1)
    f.write(b"\0")
t0 = time.time()
c = env.client(w / "src", config="set nopreview\n")
print("startup took %.2fs" % (time.time() - t0))
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.send("set rulerfile %s" % (root / "d1" / "ruler" / "progress"))
c.drain(0.3)
c.send("paste")
c.send("quit")
raw = b""
deadline = time.time() + 30
while time.time() < deadline:
    c.send("redraw")
    raw += c.drain(0.06)
    if (w / "dst" / "big.bin").stat().st_size == 800 * 1024 * 1024:
        c.send("redraw")
        raw += c.drain(0.5)
        break
found = re.findall(rb"P\[\[(\[?\d+%\]?)\]\]", raw)
print("copy+drain took %.2fs, raw bytes %d" % (time.time() - t0, len(raw)))
print("progress samples: %r" % sorted({int(x.strip(b"[]%")) for x in found}))
print("copy-list in ruler seen: %r" % (b"C[[%s]]" % str(big).encode() in raw))
print("errors: %r" % c.errors())
print("alive: %r" % (c.wait_exit(0.3) is None))
r = c.ruler("progress")
print("final ruler: %r" % r)

# ---- D2: watch symlink alias fan-out -------------------------------------------
sec("D2 watch alias")
env = fresh("d2")
real = make_tree(root / "d2w", {"real/": None})
alias_parent = root / "d2ap"
alias_parent.mkdir()
(alias_parent / "alias").symlink_to(real / "real", target_is_directory=True)
c1 = env.client(real / "real", config="set watch\n")
c2 = env.client(alias_parent, config="set watch\n")
c2.cmd("cd alias")
print("c1 pwd: %r  c2 pwd: %r" % (c1.state()["pwd"], c2.state()["pwd"]))
(real / "real" / "via-real").write_text("x")
c1.wait_for(lambda: "via-real" in c1.files(), 6)
print("c1 sees: %r" % c1.files())
try:
    c2.wait_for(lambda: "via-real" in c2.files(), 6)
    print("c2 (symlinked cwd) sees: %r" % c2.files())
except RuntimeError as e:
    print("c2 did NOT see it: %s" % e)

print("\nPROBE D DONE")
