import sys, os, shutil, time, pwd, stat
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import LF
from screen import render_rows
exe = sys.argv[1]; root = sys.argv[2]
shutil.rmtree(root, ignore_errors=True); os.makedirs(root)
d = root + '/work'; os.makedirs(d)
os.makedirs(d + '/sub1'); os.makedirs(d + '/sub2')
open(d + '/a.txt','w').write('hello world\n')
os.symlink('a.txt', d + '/lnk')
os.symlink('nowhere', d + '/broken')
os.chmod(d + '/a.txt', 0o750)
tmpls = {
 'state': 'I[{{.Index}}/{{.Total}}] H[{{.Hidden}}] A[{{.All}}] S[{{.ScrollPercentage}}] F[{{.Filter}}] M[{{.Mode}}] L[{{len .Select}}] V[{{len .Visual}}] P[{{.Progress}}]',
 'stat': 'N[{{.Stat.Name}}] P[{{.Stat.Permissions}}] U[{{.Stat.User}}] G[{{.Stat.Group}}] C[{{.Stat.LinkCount}}] Z[{{.Stat.Size}}] D[{{.Stat.DirSize}}] N2[{{.Stat.DirCount}}] T[{{.Stat.Target}}] E[{{.Stat.Extension}}]',
 'df': 'DF[{{df}}] HZ[{{humanize .Stat.Size}}] HZD[{{humanize .Stat.DirSize}}]',
}
for k, v in tmpls.items():
    open(root + '/r_' + k, 'w').write(v + '\n')
lf = LF(exe, root, d, rows=14, cols=140,
        config='set nohistory\n', args=['-log', root+'/lf.log'])
def snap():
    lf.drain(0.1); lf.send('redraw'); time.sleep(0.3)
    return render_rows(lf.drain(0.4), 14, 140)
def ruler(name):
    lf.send('set rulerfile %s/r_%s' % (root, name))
    return snap()[-1]
lf.refresh()
print("state:", ruler('state'))
lf.send('set hidden')
lf.refresh()
print("state hidden:", ruler('state'))
print("df:", ruler('df'))
for f in ['sub1', 'a.txt', 'lnk', 'broken']:
    lf.send('select %s/%s' % (d, f))
    lf.refresh()
    print("stat %-8s:" % f, ruler('stat'))
print("state after select:", ruler('state'))
lf.send('visual')
print("state visual:", ruler('state'))
lf.send('down')
lf.refresh()
print("state visual+down:", ruler('state'))
lf.send('visual-accept')
lf.refresh()
print("state after accept:", ruler('state'))
lf.quit()
