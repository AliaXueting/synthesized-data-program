"""Probe C part 2: paste, preserve, delete, rename, quit-refusal."""
import sys, os, time, shutil, stat
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    return LfEnv(root / name)


# ---- C6: paste ---------------------------------------------------------------
env = fresh("c6")
w = root / "c6w"
make_tree(w, {"dst/": None})
src = w / "src"
make_tree(src, {"f1.txt": "one\n", "inner/": None, "sym": None})
os.unlink(src / "sym")
os.symlink("f1.txt", src / "sym")
(src / "inner" / "f2.txt").write_text("two\n")
c = env.client(src)
c.cmd("glob-select *")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: sorted(os.listdir(w / "dst")) == ["f1.txt", "inner", "sym"], 8)
print("C6 dst listing :", sorted(os.listdir(w / "dst")))
print("C6 f1 content  :", repr((w / "dst" / "f1.txt").read_text()))
print("C6 sym         :", os.path.islink(w / "dst" / "sym"), "->", os.readlink(w / "dst" / "sym"))
print("C6 inner       :", sorted(os.listdir(w / "dst" / "inner")))
c.cmd("paste")
c.wait_for(lambda: len(os.listdir(w / "dst")) == 6, 8)
print("C6 dup names   :", sorted(os.listdir(w / "dst")))
env.shutdown()

# ---- C7: custom dupfilefmt ---------------------------------------------------
env = fresh("c7")
w = root / "c7w"
make_tree(w, {"src/": None, "dst/": None})
(w / "src" / "data.bin").write_bytes(b"x" * 10)
c = env.client(w / "src", config="set dupfilefmt %f_%n\n")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: os.path.exists(w / "dst" / "data.bin"), 8)
c.cmd("paste")
c.wait_for(lambda: len(os.listdir(w / "dst")) == 2, 8)
print("C7 dupfilefmt   :", sorted(os.listdir(w / "dst")))
env.shutdown()

# ---- C8: move (cut+paste) ----------------------------------------------------
env = fresh("c8")
w = root / "c8w"
make_tree(w, {"src/": None, "dst/": None})
(w / "src" / "m.txt").write_text("moving\n")
(w / "src" / "d").mkdir()
(w / "src" / "d" / "x.txt").write_text("deep\n")
c = env.client(w / "src")
c.cmd("glob-select *")
c.cmd("cut")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: sorted(os.listdir(w / "dst")) == ["d", "m.txt"], 8)
print("C8 moved        :", sorted(os.listdir(w / "dst")))
print("C8 src left     :", sorted(os.listdir(w / "src")))
print("C8 content      :", repr((w / "dst" / "m.txt").read_text()))
env.shutdown()

# ---- C9: preserve ------------------------------------------------------------
env = fresh("c9")
w = root / "c9w"
make_tree(w, {"src/": None, "dst/": None})
p = w / "src" / "p.txt"
p.write_text("preserve me\n")
os.chmod(p, 0o751)
os.utime(p, (1400000000, 1400000000))
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "p.txt").exists(), 8)
q = w / "dst" / "p.txt"
print("C9 default mode :", oct(stat.S_IMODE(q.stat().st_mode)))
print("C9 default mtime:", int(q.stat().st_mtime))
env.shutdown()

env = fresh("c9b")
w = root / "c9bw"
make_tree(w, {"src/": None, "dst/": None})
p = w / "src" / "p.txt"
p.write_text("preserve me\n")
os.chmod(p, 0o751)
os.utime(p, (1400000000, 1400000000))
c = env.client(w / "src", config="set preserve mode:timestamps\n")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "p.txt").exists(), 8)
q = w / "dst" / "p.txt"
print("C9b mode        :", oct(stat.S_IMODE(q.stat().st_mode)))
print("C9b mtime       :", int(q.stat().st_mtime))
env.shutdown()

# ---- C10: paste failures -----------------------------------------------------
env = fresh("c10")
w = root / "c10w"
make_tree(w, {"src/": None, "dst/": None})
(w / "src" / "gone.txt").write_text("will be deleted\n")
c = env.client(w / "src")
c.cmd("copy")
os.unlink(w / "src" / "gone.txt")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
time.sleep(1.0)
c.state()
print("C10 missing src :", c.errors())
env.shutdown()

# ---- C11: delete --------------------------------------------------------------
env = fresh("c11")
w = root / "c11w"
make_tree(w, {"gone.txt": "x\n", "keep.txt": "y\n", "dirtree/": None})
(w / "dirtree" / "inner.txt").write_text("z\n")
c = env.client(w)
c.cmd("select gone.txt")
c.send("delete")
c.cmd("cmd-insert y")
c.wait_for(lambda: not (w / "gone.txt").exists(), 8)
print("C11 after delete:", sorted(os.listdir(w)))
c.cmd("select dirtree")
c.send("delete")
c.cmd("cmd-insert y")
c.wait_for(lambda: not (w / "dirtree").exists(), 8)
print("C11 dir deleted :", sorted(os.listdir(w)))
c.cmd("select keep.txt")
c.send("delete")
c.cmd("cmd-insert n")
time.sleep(0.3)
print("C11 cancel      :", sorted(os.listdir(w)), "| err:", c.errors())
env.shutdown()

# ---- C12: rename ---------------------------------------------------------------
env = fresh("c12")
w = root / "c12w"
make_tree(w, {"old.txt": "content\n", "existing.txt": "keep me\n"})
c = env.client(w)
c.cmd("select old.txt")
c.send("rename new.txt")
c.push("<enter>")
c.wait_for(lambda: (w / "new.txt").exists(), 8)
print("C12 renamed     :", sorted(os.listdir(w)))
c.cmd("select new.txt")
c.send("rename existing.txt")
c.push("<enter>")
time.sleep(0.3)
print("C12 replace?    :", repr(c.screen()[-1].strip()))
c.push("y")
c.wait_for(lambda: (w / "existing.txt").read_text() == "content\n", 8)
print("C12 replaced    :", sorted(os.listdir(w)), "| existing:", repr((w / "existing.txt").read_text()))
c.cmd("select existing.txt")
c.send("rename %s" % (w / "nodir" / "x.txt"))
c.push("<enter>")
time.sleep(0.3)
print("C12 create?     :", repr(c.screen()[-1].strip()))
c.push("n")
time.sleep(0.2)
print("C12 cancel create:", sorted(os.listdir(w)))
env.shutdown()

# ---- C13: quit refused during copy --------------------------------------------
env = fresh("c13")
w = root / "c13w"
make_tree(w, {"src/": None, "dst/": None})
big = w / "src" / "big.bin"
with open(big, "wb") as f:
    f.write(b"\0" * (60 * 1024 * 1024))
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
time.sleep(0.4)
c.send("quit")
time.sleep(0.3)
c.state()
print("C13 quit err    :", c.errors()[-1:])
print("C13 progress    :", c.ruler("progress"))
c.wait_for(lambda: (w / "dst" / "big.bin").exists() and (w / "dst" / "big.bin").stat().st_size == 60 * 1024 * 1024, 25)
print("C13 done        :", (w / "dst" / "big.bin").stat().st_size)
print("C13 final prog  :", c.ruler("progress"))
env.shutdown()
print("DONE C2")
