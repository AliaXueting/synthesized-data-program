"""Probe E: search/find errors, tag details, quit-refusal, progress, edge cases."""
import sys, os, time, shutil, stat, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree, run_lf
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    return LfEnv(root / name)


# ---- E1: search errors and options -------------------------------------------
env = fresh("e1")
w = root / "e1w"
make_tree(w, {"apple": None, "Apricot": None, "banana": None})
c = env.client(w)
c.send("search")
c.push("zz<enter>")
time.sleep(0.2)
print("E1 search zz   :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
c.send("search")
c.push("an<enter>")
time.sleep(0.2)
print("E1 search an   :", os.path.basename(c.state()["f"]))
c.cmd("search-next")
print("E1 search-next :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
c.cmd("set nowrapscan")
c.cmd("search-next")
print("E1 nowrap next :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
c.cmd("set wrapscan")
c.cmd("set ignorecase")
c.send("search")
c.push("AP<enter>")
time.sleep(0.2)
print("E1 icase AP    :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
c.cmd("set noignorecase")
c.send("search")
c.push("AP<enter>")
time.sleep(0.2)
print("E1 case AP     :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
env.shutdown()

# ---- E2: find errors -----------------------------------------------------------
env = fresh("e2")
w = root / "e2w"
make_tree(w, {"apple": None, "apricot": None, "banana": None})
c = env.client(w)
c.send("find")
c.push("z")
time.sleep(0.2)
print("E2 find z      :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
c.send("find")
c.push("a")
time.sleep(0.2)
print("E2 find a      :", os.path.basename(c.state()["f"]))
c.send("find-back")
c.push("a")
time.sleep(0.2)
print("E2 find-back a :", os.path.basename(c.state()["f"]))
env.shutdown()

# ---- E3: tag details ------------------------------------------------------------
env = fresh("e3")
w = root / "e3w"
make_tree(w, {"a.txt": None, "b.txt": None})
tags = root / "e3" / "data" / "lf" / "tags"
c = env.client(w)
c.cmd("select a.txt")
c.cmd("tag")
time.sleep(0.2)
print("E3 tag noarg   :", repr(tags.read_text() if tags.exists() else None), "| err:", c.errors()[-1:])
c.cmd("tag X")
print("E3 tag X       :", repr(tags.read_text()))
c.cmd("tag YY")
print("E3 tag YY      :", repr(tags.read_text()), "| err:", c.errors()[-1:])
c.cmd("tag-toggle Y")
print("E3 toggle Y    :", repr(tags.read_text()))
c.cmd("select b.txt")
c.cmd("tag-toggle *")
print("E3 toggle star :", repr(tags.read_text()))
c.cmd("tag-toggle *")
print("E3 untoggle    :", repr(tags.read_text()))
env.shutdown()

# ---- E4: ifs / filesep -----------------------------------------------------------
env = fresh("e4")
w = root / "e4w"
make_tree(w, {"a.txt": None})
log = root / "ifs.log"
c = env.client(w)
c.shell("printf 'ifs=[%%s]\\n' \"$ifs\" | od -c | head -2 >> %s" % log)
c.shell("printf 'sel=[%%s]\\n' \"$lf_selmode\" >> %s" % log)
print("E4 ifs log     :", log.read_text())
env.shutdown()

# ---- E5: CLI bad dir ---------------------------------------------------------------
p = run_lf([str(root / "nope")])
print("E5 bad dir rc  :", p.returncode)
print("E5 bad dir out :", repr(p.stdout.decode()[:200]))
print("E5 bad dir err :", repr(p.stderr.decode()[:200]))

# ---- E6: dupfilefmt unquoted repro --------------------------------------------------
env = fresh("e6")
w = root / "e6w"
make_tree(w, {"src/": None, "dst/": None})
(w / "src" / "data.bin").write_bytes(b"x" * 10)
try:
    c = env.client(w / "src", config="set dupfilefmt %f_%n\n")
    c.cmd("copy")
    c.cmd("cd %s" % (w / "dst"))
    c.cmd("paste")
    c.wait_for(lambda: os.path.exists(w / "dst" / "data.bin"), 8)
    c.cmd("paste")
    c.wait_for(lambda: len(os.listdir(w / "dst")) == 2, 8)
    print("E6 unquoted    :", sorted(os.listdir(w / "dst")))
except Exception as ex:
    print("E6 unquoted ERR:", ex)
env.shutdown()

# ---- E7: quit refused during copy + progress ---------------------------------------
env = fresh("e7")
w = root / "e7w"
make_tree(w, {"src/": None, "dst/": None})
big = w / "src" / "big.bin"
with open(big, "wb") as f:
    f.write(b"\0" * (300 * 1024 * 1024))
t0 = time.time()
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
time.sleep(0.3)
prog = c.ruler("progress")
c.send("quit")
time.sleep(0.3)
st = c.state()
print("E7 quit err    :", c.errors()[-1:])
print("E7 progress    :", prog)
print("E7 still alive :", os.kill(c.pid, 0) is None)
c.wait_for(lambda: (w / "dst" / "big.bin").exists() and (w / "dst" / "big.bin").stat().st_size == 300 * 1024 * 1024, 25)
print("E7 copy done   :", (w / "dst" / "big.bin").stat().st_size, "in %.1fs" % (time.time() - t0))
print("E7 final prog  :", c.ruler("progress"))
c.send("quit")
time.sleep(0.5)
print("E7 quit after  :", os.kill(c.pid, 0) is None)
env.shutdown()

# ---- E8: newline in filename for copy/cut ------------------------------------------
env = fresh("e8")
w = root / "e8w"
bad = w / "nl\nx.txt"
bad.write_text("n\n")
c = env.client(w)
c.cmd("select %s" % ("'nl\nx.txt'"))
print("E8 f           :", repr(c.state()["f"]))
c.cmd("copy")
time.sleep(0.3)
print("E8 copy err    :", c.errors()[-1:])
print("E8 clipboard   :", repr((root / "e8" / "data" / "lf" / "files").read_text()) if (root / "e8" / "data" / "lf" / "files").exists() else "(none)")
env.shutdown()

# ---- E9: updir at root ---------------------------------------------------------------
env = fresh("e9")
c = env.client("/")
print("E9 root files  :", c.files()[:4])
c.cmd("updir")
time.sleep(0.2)
print("E9 updir @root :", c.state()["pwd"], "| err:", c.errors()[-1:])
env.shutdown()

# ---- E10: selmode all vs dir ----------------------------------------------------------
env = fresh("e10")
w = root / "e10w"
make_tree(w, {"d1/": None, "d2/": None})
(w / "d1" / "in1.txt").write_text("1\n")
(w / "d2" / "in2.txt").write_text("2\n")
c = env.client(w / "d1")
c.cmd("toggle")
c.cmd("cd %s" % (w / "d2"))
c.cmd("toggle")
c.cmd("copy")
files = root / "e10" / "data" / "lf" / "files"
print("E10 selmode all:", files.read_text())
c.cmd("set selmode dir")
c.cmd("copy")
print("E10 selmode dir:", files.read_text())
env.shutdown()

# ---- E11: dirfirst / reverse ----------------------------------------------------------
env = fresh("e11")
w = root / "e11w"
make_tree(w, {"b/": None, "a.txt": None, "c/": None, "d.txt": None})
c = env.client(w)
print("E11 default    :", c.files())
c.cmd("set nodirfirst")
print("E11 nodirfirst :", c.files())
c.cmd("set dirfirst")
c.cmd("set reverse")
print("E11 dir+rev    :", c.files())
env.shutdown()

# ---- E12: select with spaces / df ------------------------------------------------------
env = fresh("e12")
w = root / "e12w"
make_tree(w, {"sp ace.txt": None, "plain": None})
c = env.client(w)
c.cmd('select "sp ace.txt"')
print("E12 select sp  :", repr(c.state()["f"]), "| err:", c.errors()[-1:])
print("E12 df ruler   :", c.ruler("df"))
env.shutdown()
print("DONE E")
