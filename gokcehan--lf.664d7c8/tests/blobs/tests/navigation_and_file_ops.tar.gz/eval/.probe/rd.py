"""Probe D: rename prompts, watch/period, open, find/search, unreadable dirs, shell, CLI."""
import sys, os, time, shutil, stat, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree, run_lf
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    return LfEnv(root / name)


# ---- D1: rename via prompt ---------------------------------------------------
env = fresh("d1")
w = root / "d1w"
make_tree(w, {"old.txt": "content\n", "existing.txt": "keep me\n"})
c = env.client(w)
c.cmd("select old.txt")
c.send("rename")
c.cmd("cmd-delete-home")
c.cmd("cmd-insert new")
c.push("<enter>")
c.wait_for(lambda: (w / "new.txt").exists(), 8)
print("D1 renamed      :", sorted(os.listdir(w)))
print("D1 content      :", repr((w / "new.txt").read_text()))
# rename onto existing -> replace prompt
c.cmd("select new.txt")
c.send("rename")
c.cmd("cmd-delete-home")
c.cmd("cmd-insert existing")
c.push("<enter>")
time.sleep(0.3)
print("D1 replace line :", repr(c.screen()[-1].strip()))
c.push("y")
c.wait_for(lambda: (w / "existing.txt").read_text() == "content\n", 8)
print("D1 replaced     :", sorted(os.listdir(w)))
# rename into missing subdir -> create prompt, answer n
c.cmd("select existing.txt")
c.send("rename")
c.cmd("cmd-delete-home")
c.cmd("cmd-delete-end")
c.cmd("cmd-insert %s" % (w / "nodir" / "x.txt"))
c.push("<enter>")
time.sleep(0.3)
print("D1 create line  :", repr(c.screen()[-1].strip()))
c.push("n")
time.sleep(0.2)
print("D1 create cancel:", sorted(os.listdir(w)))
# rename into missing subdir -> create prompt, answer y
c.cmd("select existing.txt")
c.send("rename")
c.cmd("cmd-delete-home")
c.cmd("cmd-delete-end")
c.cmd("cmd-insert %s" % (w / "nodir2" / "x.txt"))
c.push("<enter>")
time.sleep(0.3)
print("D1 create line2 :", repr(c.screen()[-1].strip()))
c.push("y")
c.wait_for(lambda: (w / "nodir2" / "x.txt").exists(), 8)
print("D1 created      :", sorted(os.listdir(w)), sorted(os.listdir(w / "nodir2")))
env.shutdown()

# ---- D2: watch ---------------------------------------------------------------
env = fresh("d2")
w = root / "d2w"
make_tree(w, {"a.txt": None})
c = env.client(w)
(w / "b.txt").write_text("new\n")
time.sleep(0.6)
print("D2 nowatch      :", c.files())
c.cmd("reload")
print("D2 after reload :", c.files())
c.cmd("set watch")
(w / "c.txt").write_text("newer\n")
c.wait_for(lambda: "c.txt" in c.files(), 6)
print("D2 watch        :", c.files())
(w / "c.txt").unlink()
c.wait_for(lambda: "c.txt" not in c.files(), 6)
print("D2 watch unlink :", c.files())
env.shutdown()

# ---- D3: period --------------------------------------------------------------
env = fresh("d3")
w = root / "d3w"
make_tree(w, {"a.txt": None})
c = env.client(w, config="set period 1\n")
(w / "p.txt").write_text("p\n")
c.wait_for(lambda: "p.txt" in c.files(), 6)
print("D3 period       :", c.files())
env.shutdown()

# ---- D4: open ----------------------------------------------------------------
env = fresh("d4")
w = root / "d4w"
make_tree(w, {"sub/": None, "file.txt": "F\n", "sp ace.txt": "S\n"})
opener = root / "opener.sh"
opener.write_text('#!/bin/sh\nprintf "OPEN %%s\\n" "$*" >> %s\n' % (root / "open.log"))
os.chmod(opener, 0o755)
c = env.client(w, env_extra={"OPENER": str(opener)})
c.cmd("select file.txt")
c.cmd("open")
c.wait_for(lambda: (root / "open.log").exists(), 6)
time.sleep(0.2)
print("D4 open file    :", (root / "open.log").read_text().strip())
c.cmd("select sp ace.txt")
c.cmd("open")
time.sleep(0.4)
print("D4 open space   :", (root / "open.log").read_text().strip().splitlines()[-1])
c.cmd("select sub")
c.cmd("open")
st = c.state()
print("D4 open dir     :", st["pwd"], "|", c.files())
env.shutdown()

# ---- D5: find ----------------------------------------------------------------
env = fresh("d5")
w = root / "d5w"
make_tree(w, {"apple": None, "apricot": None, "banana": None, "cherry": None})
c = env.client(w)
c.cmd("find a")
time.sleep(0.2)
print("D5 find a       :", os.path.basename(c.state()["f"]), "| errors:", c.errors())
c.cmd("find-next")
print("D5 find-next    :", os.path.basename(c.state()["f"]))
c.cmd("find zz")
time.sleep(0.2)
print("D5 find zz      :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
env.shutdown()

# ---- D6: search --------------------------------------------------------------
env = fresh("d6")
w = root / "d6w"
make_tree(w, {"apple": None, "Apricot": None, "banana": None})
c = env.client(w)
c.cmd("search an")   # opens prompt; then insert+enter via push
c.push("an<enter>")
time.sleep(0.2)
print("D6 search an    :", os.path.basename(c.state()["f"]), "| err:", c.errors())
c.cmd("search-next")
print("D6 search-next  :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
c.cmd("set ignorecase")
c.cmd("search ap<enter>")
time.sleep(0.2)
print("D6 icase ap     :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
c.cmd("set noignorecase")
c.cmd("set smartcase")
c.cmd("search Ap<enter>")
time.sleep(0.2)
print("D6 smartcase Ap :", os.path.basename(c.state()["f"]), "| err:", c.errors()[-1:])
env.shutdown()

# ---- D7: unreadable directory -------------------------------------------------
env = fresh("d7")
w = root / "d7w"
make_tree(w, {"ok.txt": None, "locked/": None})
(w / "locked" / "secret.txt").write_text("s\n")
os.chmod(w / "locked", 0o000)
c = env.client(w)
print("D7 files        :", c.files())
c.cmd("cd %s" % (w / "locked"))
time.sleep(0.3)
print("D7 locked pwd   :", c.state()["pwd"])
print("D7 locked files :", c.files())
print("D7 locked err   :", [e for e in c.errors() if "locked" in e][:2])
env.shutdown()

# ---- D8: shell escaping / exported vars ---------------------------------------
env = fresh("d8")
w = root / "d8w"
make_tree(w, {"plain.txt": "p\n", "sp ace.txt": "s\n", "quote'.txt": "q\n"})
log = root / "sh.log"
c = env.client(w)
c.shell("printf 'f=[%%s]\\n' \"$f\" >> %s" % log)
c.cmd("select sp ace.txt")
c.shell("printf 'f=[%%s]\\n' \"$f\" >> %s" % log)
c.cmd("select quote'.txt")
c.shell("printf 'f=[%%s]\\n' \"$f\" >> %s" % log)
c.cmd("glob-select *")
c.shell("printf 'fx=[%%s]\\n' \"$fx\" >> %s" % log)
c.shell("printf 'ifs=[%%s]\\n' \"$ifs\" >> %s" % log)
print("D8 shell log    :", log.read_text())
env.shutdown()

# ---- D9: CLI ------------------------------------------------------------------
print("D9 version rc   :", run_lf(["-version"]).returncode)
print("D9 version out  :", run_lf(["-version"]).stdout.decode().strip())
p = run_lf(["-badflag"])
print("D9 badflag rc   :", p.returncode)
print("D9 badflag err  :", p.stderr.decode().strip().splitlines()[0])
p = run_lf(["-remote", "badrequest"])
print("D9 remote bad   :", p.returncode, repr(p.stderr.decode().strip()))
p = run_lf([str(root / "nope")])
print("D9 bad dir rc   :", p.returncode, repr(p.stderr.decode().strip().splitlines()[:1]))
p = run_lf(["-remote", "version"])
print("D9 remote ver   :", p.returncode, repr(p.stdout.decode().strip()))

# print-last-dir
env = fresh("d9")
w = root / "d9w"
make_tree(w, {"sub1/": None, "sub2/": None})
lastdir = root / "d9" / "lastdir"
p = subprocess.run([env.exe, "-config", "/dev/null", "-print-last-dir", str(w)],
                   env=env.env, capture_output=True, input=b"q", timeout=30)
print("D9 lastdir out  :", repr(p.stdout.decode()), "rc:", p.returncode)

# print-selection with selection-path
selpath = root / "d9" / "sel.txt"
selpath.write_text("")
cfg = root / "d9" / "cfg"
cfg.write_text("set nohistory\n")
import pty as _pty, fcntl as _fcntl, termios as _termios, struct as _struct
pid, master = _pty.fork()
if pid == 0:
    os.chdir(str(w))
    os.environ.clear(); os.environ.update(env.env)
    os.execv(env.exe, [env.exe, "-config", str(cfg), "-selection-path", str(selpath), "-print-selection", str(w)])
    os._exit(99)
_fcntl.ioctl(master, _termios.TIOCSWINSZ, _struct.pack("HHHH", 20, 100, 0, 0))
time.sleep(0.8)
subprocess.run([env.exe, "-remote", "send %d toggle" % pid], env=env.env, capture_output=True)
time.sleep(0.3)
subprocess.run([env.exe, "-remote", "send %d quit" % pid], env=env.env, capture_output=True)
deadline = time.time() + 8
while time.time() < deadline:
    try:
        if os.waitpid(pid, os.WNOHANG)[0] == pid:
            break
    except OSError:
        break
    time.sleep(0.05)
print("D9 selpath      :", repr(selpath.read_text()))
env.shutdown()

# ---- D10: clipboard shared between clients ------------------------------------
env = fresh("d10")
w = root / "d10w"
make_tree(w, {"a.txt": None, "b.txt": None})
c1 = env.client(w)
c1.cmd("select b.txt")
c1.cmd("toggle")
c1.cmd("copy")
c2 = env.client(w)
time.sleep(0.5)
print("D10 c2 ruler    :", c2.ruler("clip"))
print("D10 c1 ruler    :", c1.ruler("clip"))
env.shutdown()
print("DONE D")
