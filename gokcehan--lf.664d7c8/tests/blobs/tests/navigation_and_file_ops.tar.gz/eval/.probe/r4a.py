"""Round-4 probe A: clipboard/copy/paste/delete/rename behaviors."""
import sys, os, time, shutil, stat, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests'))
from conftest import LfEnv, make_tree, run_lf
from pathlib import Path

os.environ["PROGRAMGYM_EXECUTABLE"] = os.path.abspath(sys.argv[1])
root = Path(sys.argv[2])
shutil.rmtree(root, ignore_errors=True)
root.mkdir(parents=True)


def fresh(name):
    return LfEnv(root / name)


def sec(title):
    print("\n========== %s ==========" % title, flush=True)


# ---- A1: clipboard file format for copy and cut ------------------------------
sec("A1 clipboard format")
env = fresh("a1")
w = make_tree(root / "a1w", {"one.txt": "1\n", "two.txt": "2\n", "d/": None})
c = env.client(w)
c.cmd("toggle")
c.cmd("down")
c.cmd("toggle")
c.cmd("copy")
clip = (root / "a1" / "data" / "lf" / "files").read_bytes()
print("copy clipboard bytes: %r" % clip)
c.cmd("toggle")
c.cmd("cut")
clip = (root / "a1" / "data" / "lf" / "files").read_bytes()
print("cut clipboard bytes: %r" % clip)
st = c.state()
print("fx after copy/cut (unselected): %r" % st["fx"])
print("errors: %r" % c.errors())

# ---- A2: fx/fs/fv exports with selections ------------------------------------
sec("A2 exports")
env = fresh("a2")
w = make_tree(root / "a2w", {"b.txt": None, "a.txt": None, "c.txt": None})
c = env.client(w)
c.cmd("select c.txt")
c.cmd("toggle")
c.cmd("select a.txt")
c.cmd("toggle")
st = c.state()
print("f=%r fx=%r fs=%r fv=%r" % (st["f"], st["fx"], st["fs"], st["fv"]))
print("ruler state: %r" % c.ruler("state"))
c.cmd("unselect")
st = c.state()
print("after unselect fx=%r fs=%r" % (st["fx"], st["fs"]))

# ---- A3: paste copies content and mode, mtime not preserved by default ------
sec("A3 paste content/mode/mtime")
env = fresh("a3")
w = make_tree(root / "a3w", {"src/": None, "dst/": None})
p = w / "src" / "data.bin"
p.write_bytes(b"x" * 1000)
os.chmod(p, 0o741)
old = time.time() - 5000
os.utime(p, (old, old))
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "data.bin").exists(), 10)
time.sleep(0.3)
q = w / "dst" / "data.bin"
print("content ok: %r" % (q.read_bytes() == b"x" * 1000))
print("mode: %o (src %o)" % (stat.S_IMODE(q.stat().st_mode), stat.S_IMODE(p.stat().st_mode)))
print("mtime delta: %.1f (src is %d s old)" % (q.stat().st_mtime - p.stat().st_mtime, 5000))
print("screen bottom: %r" % c.screen()[-1].strip())
print("messages: %r" % c.messages())

# ---- A4: preserve timestamps -------------------------------------------------
sec("A4 preserve mode:timestamps")
env = fresh("a4")
w = make_tree(root / "a4w", {"src/": None, "dst/": None})
p = w / "src" / "keep.bin"
p.write_bytes(b"y" * 10)
os.chmod(p, 0o600)
old = time.time() - 12345
os.utime(p, (old, old))
c = env.client(w / "src", config="set preserve mode:timestamps\n")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "keep.bin").exists(), 10)
time.sleep(0.3)
q = w / "dst" / "keep.bin"
print("mode: %o" % stat.S_IMODE(q.stat().st_mode))
print("mtime preserved: %r (delta %.6f)" % (abs(q.stat().st_mtime - old) < 2,
                                            q.stat().st_mtime - old))
print("atime preserved: %r (delta %.6f)" % (abs(q.stat().st_atime - old) < 2,
                                            q.stat().st_atime - old))

# ---- A5: dupfilefmt default duplicates ---------------------------------------
sec("A5 dupfilefmt default")
env = fresh("a5")
w = make_tree(root / "a5w", {"src/": None, "dst/": None})
(w / "src" / "f.txt").write_text("new\n")
(w / "dst" / "f.txt").write_text("old\n")
(w / "dst" / "f.txt.~1~").write_text("one\n")
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "f.txt.~2~").exists(), 10)
time.sleep(0.3)
print("listing: %r" % sorted(os.listdir(w / "dst")))
print("f.txt content: %r (must stay old)" % (w / "dst" / "f.txt").read_text())
print("f.txt.~2~ content: %r" % (w / "dst" / "f.txt.~2~").read_text())

# ---- A6: custom dupfilefmt ---------------------------------------------------
sec("A6 custom dupfilefmt")
env = fresh("a6")
w = make_tree(root / "a6w", {"src/": None, "dst/": None})
(w / "src" / "img.tar.gz").write_text("n\n")
(w / "dst" / "img.tar.gz").write_text("o\n")
c = env.client(w / "src", config='set dupfilefmt "%b_copy%n%e"\n')
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: any("copy1" in n for n in os.listdir(w / "dst")), 10)
time.sleep(0.3)
print("listing: %r" % sorted(os.listdir(w / "dst")))

# ---- A7: existing dir duplicated, not merged ---------------------------------
sec("A7 dir duplicate")
env = fresh("a7")
w = make_tree(root / "a7w", {"src/d/x.txt": "x\n", "dst/d/y.txt": "y\n"})
c = env.client(w / "src")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "d.~1~" / "x.txt").exists(), 10)
time.sleep(0.3)
print("dst listing: %r" % sorted(os.listdir(w / "dst")))
print("d contents: %r  d.~1~ contents: %r" % (sorted(os.listdir(w / "dst" / "d")),
                                              sorted(os.listdir(w / "dst" / "d.~1~"))))

# ---- A8: cut + paste moves; message -------------------------------------------
sec("A8 cut/paste move")
env = fresh("a8")
w = make_tree(root / "a8w", {"src/m.txt": "m\n", "dst/": None})
c = env.client(w / "src")
c.cmd("cut")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: (w / "dst" / "m.txt").exists(), 10)
time.sleep(0.3)
print("src exists: %r" % (w / "src" / "m.txt").exists())
print("dst content: %r" % (w / "dst" / "m.txt").read_text())
print("screen bottom: %r" % c.screen()[-1].strip())

# ---- A9: cut and paste in the same directory ----------------------------------
sec("A9 cut+paste same dir")
env = fresh("a9")
w = make_tree(root / "a9w", {"a.txt": "a\n", "b.txt": None})
c = env.client(w)
c.cmd("select a.txt")
c.cmd("cut")
c.cmd("paste")
time.sleep(0.6)
print("errors: %r" % c.errors())
print("a.txt still there: %r" % (w / "a.txt").exists())

# ---- A10: paste with empty/corrupt clipboard ----------------------------------
sec("A10 paste errors")
env = fresh("a10")
w = make_tree(root / "a10w", {"a": None})
c = env.client(w)
c.cmd("paste")
time.sleep(0.3)
print("empty clipboard error: %r" % c.errors())
data = root / "a10" / "data" / "lf" / "files"
data.parent.mkdir(parents=True, exist_ok=True)
data.write_text("bogus\n%s\n" % (w / "a"))
c.cmd("paste")
time.sleep(0.3)
print("bad header error: %r" % c.errors())
data.write_text("copy\n")
c.cmd("paste")
time.sleep(0.3)
print("empty list error: %r" % c.errors())

# ---- A11: copy into subdirectory of itself ------------------------------------
sec("A11 self-copy")
env = fresh("a11")
w = make_tree(root / "a11w", {"d/inner.txt": "i\n"})
c = env.client(w)
c.cmd("select d")
c.cmd("copy")
c.cmd("cd d")
c.cmd("paste")
time.sleep(0.8)
print("errors: %r" % c.errors())
print("d listing: %r" % sorted(os.listdir(w / "d")))

# ---- A12: newline in name rejected --------------------------------------------
sec("A12 newline name")
env = fresh("a12")
w = root / "a12w"
w.mkdir()
(w / "bad\nname").write_text("x")
c = env.client(w)
c.cmd("toggle")
c.cmd("copy")
time.sleep(0.3)
print("errors: %r" % c.errors())
print("clipboard exists: %r" % (root / "a12" / "data" / "lf" / "files").exists())

# ---- A13: symlink copy --------------------------------------------------------
sec("A13 symlink")
env = fresh("a13")
w = make_tree(root / "a13w", {"src/": None, "dst/": None,
                              "@src/link.txt": "target.txt"})
(w / "src" / "target.txt").write_text("t\n")
c = env.client(w / "src")
c.cmd("select link.txt")
c.cmd("copy")
c.cmd("cd %s" % (w / "dst"))
c.cmd("paste")
c.wait_for(lambda: os.path.lexists(w / "dst" / "link.txt"), 10)
time.sleep(0.3)
q = w / "dst" / "link.txt"
print("is symlink: %r -> %r" % (q.is_symlink(), os.readlink(q) if q.is_symlink() else None))

# ---- A14: delete prompt and effect --------------------------------------------
sec("A14 delete")
env = fresh("a14")
w = make_tree(root / "a14w", {"gone.txt": None, "d/": None, "keep.txt": None})
(w / "d" / "x").write_text("x")
c = env.client(w)
print("initial cursor: %r" % os.path.basename(c.state()["f"]))
c.cmd("delete")
time.sleep(0.3)
print("screen rows: %r" % c.screen()[-2:])
c.push("y")
c.wait_for(lambda: not (w / "d").exists(), 10)
print("deleted d: %r; gone.txt still: %r" % (not (w / "d").exists(),
                                             (w / "gone.txt").exists()))
print("listing after: %r" % c.files())
c.cmd("select gone.txt")
c.cmd("toggle")
c.cmd("select keep.txt")
c.cmd("toggle")
c.cmd("delete")
time.sleep(0.3)
print("screen prompt multi: %r" % c.screen()[-1].strip())
c.push("n")
time.sleep(0.3)
print("after n: d exists %r keep exists %r errors %r" % (
    (w / "d").exists(), (w / "keep.txt").exists(), c.errors()))
c.cmd("delete")
time.sleep(0.3)
c.push("y")
c.wait_for(lambda: not (w / "d").exists() and not (w / "keep.txt").exists(), 10)
print("after y: d exists %r keep exists %r" % ((w / "d").exists(),
                                               (w / "keep.txt").exists()))

# ---- A15: rename via prompt ---------------------------------------------------
sec("A15 rename")
env = fresh("a15")
w = make_tree(root / "a15w", {"a.txt": "A\n", "other.txt": "O\n", "sub/": None})
c = env.client(w, config="cmap <c-u> cmd-delete-home\ncmap <c-k> cmd-delete-end\n")
c.cmd("select a.txt")
c.send("rename")
time.sleep(0.3)
rows = c.screen()
print("prompt row: %r" % rows[-1].strip())
c.push("<c-u><c-k>renamed.txt<enter>")
c.wait_for(lambda: (w / "renamed.txt").exists(), 10)
time.sleep(0.3)
print("renamed: %r content %r" % ((w / "renamed.txt").exists(),
                                  (w / "renamed.txt").read_text()))
print("old gone: %r" % (not (w / "a.txt").exists()))
print("listing: %r" % c.files())
print("cursor: %r" % os.path.basename(c.state()["f"]))
print("errors: %r" % c.errors())

# ---- A16: rename onto existing -> replace prompt ------------------------------
sec("A16 rename replace")
env = fresh("a16")
w = make_tree(root / "a16w", {"a.txt": "A\n", "other.txt": "O\n"})
c = env.client(w, config="cmap <c-u> cmd-delete-home\ncmap <c-k> cmd-delete-end\n")
c.cmd("select a.txt")
c.send("rename")
time.sleep(0.2)
c.push("<c-u><c-k>other.txt<enter>")
time.sleep(0.4)
print("replace prompt: %r" % c.screen()[-1].strip())
c.push("n")
time.sleep(0.3)
print("after n: a.txt %r other.txt content %r" % ((w / "a.txt").exists(),
                                                  (w / "other.txt").read_text()))
c.send("rename")
time.sleep(0.2)
c.push("<c-u><c-k>other.txt<enter>")
time.sleep(0.4)
c.push("y")
c.wait_for(lambda: not (w / "a.txt").exists(), 10)
time.sleep(0.3)
print("after y: a gone %r other content %r" % (not (w / "a.txt").exists(),
                                               (w / "other.txt").read_text()))
print("listing: %r" % c.files())

# ---- A17: rename into missing dir -> create prompt ----------------------------
sec("A17 rename create")
env = fresh("a17")
w = make_tree(root / "a17w", {"a.txt": "A\n"})
c = env.client(w, config="cmap <c-u> cmd-delete-home\ncmap <c-k> cmd-delete-end\n")
c.cmd("select a.txt")
c.send("rename")
time.sleep(0.2)
c.push("<c-u><c-k>newdir/a.txt<enter>")
time.sleep(0.4)
print("create prompt: %r" % c.screen()[-1].strip())
c.push("y")
c.wait_for(lambda: (w / "newdir" / "a.txt").exists(), 10)
time.sleep(0.3)
print("moved into newdir: %r listing %r" % ((w / "newdir" / "a.txt").exists(),
                                            sorted(os.listdir(w))))

# ---- A18: two clients share the clipboard -------------------------------------
sec("A18 shared clipboard")
env = fresh("a18")
w = make_tree(root / "a18w", {"d1/shared.txt": "S\n", "d2/": None})
c1 = env.client(w / "d1")
c2 = env.client(w / "d2")
c1.cmd("copy")
time.sleep(0.3)
print("c2 ruler clip: %r" % c2.ruler("clip"))
c2.cmd("paste")
c2.wait_for(lambda: (w / "d2" / "shared.txt").exists(), 10)
time.sleep(0.3)
print("pasted in d2: %r" % (w / "d2" / "shared.txt").read_text())
print("d1 still has it: %r" % (w / "d1" / "shared.txt").exists())
print("c2 errors: %r" % c2.errors())

print("\nPROBE A DONE")
