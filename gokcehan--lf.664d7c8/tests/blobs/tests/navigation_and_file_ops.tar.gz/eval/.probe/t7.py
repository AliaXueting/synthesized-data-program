import sys, os, shutil, time, pwd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import LF
exe = sys.argv[1]; root = sys.argv[2]
shutil.rmtree(root, ignore_errors=True); os.makedirs(root)
d = root + '/work'; os.makedirs(d)
for i in range(12): open(os.path.join(d,'f%02d' % i),'w').write('x')
lf = LF(exe, root, d, rows=20, cols=110, args=['-log', root+'/lf.log'])
def st():
    lf.shell('printf "f=%%s\\npwd=%%s\\n" "$f" "$PWD" > %s/st.txt' % root)
    return open(root+'/st.txt').read().strip().replace('\n', ' | ')
print("start:", st())
for keys in ['5j', '3k', '10j', 'G', 'gg', '2G', 'M', 'L', 'H']:
    lf.send('push ' + keys)
    print("push %-4s ->" % keys, st())
home = pwd.getpwuid(os.getuid()).pw_dir
lf.send('cd ~')
print("cd ~ ->", st(), "(real home: %s)" % home)
lf.send('cd -')
print("cd - ->", st())
lf.send('cd /etc/passwd')
lf.send('cd /does/not/exist')
lf.send('cd -x')
time.sleep(0.3)
print("errors:")
for l in open(root+'/lf.log'):
    if 'error: ' in l: print("   ", l.split('error: ',1)[1].rstrip())
lf.quit()
