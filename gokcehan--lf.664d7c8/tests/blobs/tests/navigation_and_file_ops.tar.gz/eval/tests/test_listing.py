"""Directory listing: hidden files, hiddenfiles globs, dironly, dircounts.

Recorded against the reference binary: every expected value below was
observed by driving ``./executable`` through ``-remote`` on a pty.
"""

import os

import pytest

from conftest import make_tree


class TestHidden:
    def test_default_hides_dotfiles(self, lf_env, tmp_path):
        """By default dotfiles are excluded from the listing."""
        # CATCHES: a re-implementation that shows dotfiles without `set hidden`
        # or miscounts the hidden/total numbers in the ruler.
        w = make_tree(tmp_path / "w", {
            ".git/": None, ".env": "x\n", "a.txt": "1\n", "b.TXT": "2\n", "keep.md": "3\n",
        })
        c = lf_env.client(w)
        assert c.files() == ["a.txt", "b.TXT", "keep.md"]
        assert c.ruler("state") == \
            "I[1/3] H[2] A[5] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"

    def test_set_hidden_shows_dotfiles(self, lf_env, tmp_path):
        """``set hidden`` reveals dotfiles, including dot-directories."""
        # CATCHES: forgetting directories when unhiding, or losing the cursor
        # file (a.txt stays under the cursor at its new index 3).
        w = make_tree(tmp_path / "w", {
            ".git/": None, ".env": "x\n", "a.txt": "1\n", "b.TXT": "2\n", "keep.md": "3\n",
        })
        c = lf_env.client(w)
        c.cmd("set hidden")
        assert c.files() == [".git", ".env", "a.txt", "b.TXT", "keep.md"]
        assert c.state()["f"] == str(w / "a.txt")
        assert c.observe(lambda: c.ruler("state"),
                         "I[3/5] H[0] A[5] S[All] F[[]] M[NORMAL] "
                         "L[0] V[0] P[[]] C[0] T[0]") == \
            "I[3/5] H[0] A[5] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"

    def test_hiddenfiles_replaces_default_patterns(self, lf_env, tmp_path):
        """``set hiddenfiles`` replaces (not extends) the default ``.*`` list."""
        # CATCHES: appending to the default patterns instead of replacing them
        # would keep .git/.env hidden here.
        w = make_tree(tmp_path / "w", {
            ".git/": None, ".env": "x\n", "a.txt": "1\n", "b.TXT": "2\n", "keep.md": "3\n",
        })
        c = lf_env.client(w)
        c.cmd("set hiddenfiles *.txt")
        assert c.files() == [".git", ".env", "b.TXT", "keep.md"]
        assert c.ruler("state") == \
            "I[1/4] H[1] A[5] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"

    def test_hiddenfiles_glob_is_case_sensitive(self, lf_env, tmp_path):
        """``*.txt`` hides ``a.txt`` but not ``b.TXT`` (no case folding)."""
        # CATCHES: case-insensitive glob matching would hide b.TXT too.
        w = make_tree(tmp_path / "w", {"a.txt": "1\n", "b.TXT": "2\n"})
        c = lf_env.client(w)
        c.cmd("set hiddenfiles *.txt")
        assert c.files() == ["b.TXT"]

    def test_hiddenfiles_negation_unhides(self, lf_env, tmp_path):
        """A ``!``-prefixed pattern re-shows files matched earlier in the list."""
        # CATCHES: treating ``!`` patterns as additional hide patterns instead
        # of negations.
        w = make_tree(tmp_path / "w", {".git/": None, ".env": "x\n", "a.txt": "1\n"})
        c = lf_env.client(w)
        c.cmd('set hiddenfiles ".*:!.git"')
        assert c.files() == [".git", "a.txt"]
        c.cmd('set hiddenfiles ".*:!*.env"')
        assert c.files() == [".env", "a.txt"]

    def test_hiddenfiles_can_hide_everything(self, lf_env, tmp_path):
        """Hiding every entry yields an empty listing without any error."""
        # CATCHES: erroring out (or crashing) when the filtered list is empty.
        w = make_tree(tmp_path / "w", {"a.txt": "1\n", "b.TXT": "2\n", "keep.md": "3\n"})
        c = lf_env.client(w)
        c.cmd('set hiddenfiles "*.txt:*.*"')
        assert c.files() == []
        assert c.errors() == []

    def test_hiddenfiles_invalid_pattern_error(self, lf_env, tmp_path):
        """A syntactically invalid glob is reported and the list untouched."""
        # CATCHES: silently ignoring bad glob syntax instead of reporting it.
        w = make_tree(tmp_path / "w", {"a.txt": "1\n"})
        c = lf_env.client(w)
        c.cmd('set hiddenfiles "["')
        assert c.files() == ["a.txt"]
        assert c.errors()[-1] == "hiddenfiles: syntax error in pattern"

    def test_hiddenfiles_empty_glob_error(self, lf_env, tmp_path):
        """An empty hiddenfiles glob is rejected with a specific message."""
        # CATCHES: accepting an empty pattern (which would match nothing).
        w = make_tree(tmp_path / "w", {"a.txt": "1\n"})
        c = lf_env.client(w)
        c.cmd('set hiddenfiles ""')
        assert c.errors()[-1] == "hiddenfiles: glob should be non-empty"


class TestDirOnly:
    def test_dironly_restricts_listing(self, lf_env, tmp_path):
        """``set dironly`` keeps only directories."""
        # CATCHES: keeping plain files (or dropping dirs) when dironly is set.
        w = make_tree(tmp_path / "w", {
            "d1/": None, "d2/d2x/": None, "d2/f1.txt": "1\n", "plain": "12345\n", "z.txt": "z\n",
        })
        c = lf_env.client(w)
        assert c.files() == ["d1", "d2", "plain", "z.txt"]
        c.cmd("set dironly")
        assert c.files() == ["d1", "d2"]
        c.cmd("set nodironly")
        assert c.files() == ["d1", "d2", "plain", "z.txt"]


class TestDirCounts:
    def test_dircounts_ruler_counts_entries(self, lf_env, tmp_path):
        """``dircounts`` shows entry counts (K) and unknown size (D=-1)."""
        # CATCHES: counting only regular files (d2 holds a subdir + 2 files)
        # or showing a byte size before calcdirsize.
        w = make_tree(tmp_path / "w", {
            "d1/": None, "d2/d2x/": None, "d2/f1.txt": "1\n", "d2/f2.txt": "2\n",
        })
        c = lf_env.client(w, config="set dircounts\n")
        c.cmd("select d1")
        assert c.observe(lambda: c.ruler("stat"),
                         "N[d1] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] "
                         "D[-1] K[0] T[] E[] I[]") == \
            "N[d1] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] D[-1] K[0] T[] E[] I[]"
        c.cmd("select d2")
        assert c.observe(lambda: c.ruler("stat"),
                         "N[d2] P[drwxr-xr-x] U[root] G[root] C[3] Z[4096] "
                         "D[-1] K[3] T[] E[] I[]") == \
            "N[d2] P[drwxr-xr-x] U[root] G[root] C[3] Z[4096] D[-1] K[3] T[] E[] I[]"

    def test_calcdirsize_fills_dirsize_and_count(self, lf_env, tmp_path):
        """``calcdirsize`` computes D (recursive bytes) for selected dirs."""
        # CATCHES: wrong recursive size (must include the dir block itself)
        # or only computing the cursor dir when several are selected.
        w = make_tree(tmp_path / "w", {"d1/": None, "d2/": None, "d3/": None})
        (w / "d1" / "a").write_text("x" * 100)
        (w / "d2" / "b").write_text("y" * 200)
        (w / "d2" / "c").write_text("z" * 300)
        (w / "d3" / "d").write_text("q" * 50)
        c = lf_env.client(w, config="set dircounts\n")
        c.cmd("glob-select d*")
        c.cmd("calcdirsize")
        assert c.observe(lambda: _stat_ruler(c, "d1"),
                         "N[d1] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] "
                         "D[4196] K[1] T[] E[] I[]") == \
            "N[d1] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] D[4196] K[1] T[] E[] I[]"
        assert c.observe(lambda: _stat_ruler(c, "d2"),
                         "N[d2] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] "
                         "D[4596] K[2] T[] E[] I[]") == \
            "N[d2] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] D[4596] K[2] T[] E[] I[]"
        assert c.observe(lambda: _stat_ruler(c, "d3"),
                         "N[d3] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] "
                         "D[4146] K[1] T[] E[] I[]") == \
            "N[d3] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] D[4146] K[1] T[] E[] I[]"

    def test_calcdirsize_single_dir_4096_plus_files(self, lf_env, tmp_path):
        """calcdirsize on one dir: size = 4096 (dir block) + file bytes."""
        # CATCHES: forgetting the directory's own block size in the total.
        w = make_tree(tmp_path / "w", {"d2/d2x/": None, "d2/f1.txt": "1\n", "d2/f2.txt": "2\n"})
        c = lf_env.client(w, config="set dircounts\n")
        c.cmd("select d2")
        c.cmd("calcdirsize")
        assert c.observe(lambda: c.ruler("stat"),
                         "N[d2] P[drwxr-xr-x] U[root] G[root] C[3] Z[4096] "
                         "D[8196] K[3] T[] E[] I[]") == \
            "N[d2] P[drwxr-xr-x] U[root] G[root] C[3] Z[4096] D[8196] K[3] T[] E[] I[]"


def _stat_ruler(c, name):
    c.cmd("select %s" % name)
    return c.ruler("stat")
