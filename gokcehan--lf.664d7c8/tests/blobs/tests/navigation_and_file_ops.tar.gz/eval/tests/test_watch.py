"""Directory monitoring: the ``watch`` and ``period`` options.

Every expectation below was recorded by driving ``./executable`` on a pty.

Observations deliberately avoid the harness's ``&``-shell state dump: an
async shell command makes lf evaluate ``load`` when it finishes (which
re-reads directories), so a listing that refreshed "by itself" could have
been caused by the observation itself.  All automatic-refresh assertions
therefore read the ruler or the screen, which are repainted without
touching the directory cache.
"""

import os
import shutil
import time

import pytest

from conftest import make_tree


def _field(ruler_text, key):
    """Extract ``KEY[value]`` from a rendered ruler template."""
    return ruler_text.split(key + "[", 1)[1].split("]", 1)[0]


def _ruler_field(c, template, key):
    return _field(c.ruler(template), key)


class TestWatchUpdates:
    def test_watch_external_create_appears(self, lf_env, tmp_path):
        """A file created by another process shows up without any key press."""
        # CATCHES: not watching the current directory at all, or only
        # refreshing the listing after a user-initiated reload.
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n", "b.txt": "bbb\n",
                                       "c.txt": "ccc\n"})
        c = lf_env.client(w, config="set watch\n")
        assert c.ruler("state") == \
            "I[1/3] H[0] A[3] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        (w / "zzz-new.txt").write_text("hi\n")
        assert c.observe(lambda: _ruler_field(c, "state", "A"), "4") == "4"
        assert c.ruler("state") == \
            "I[1/4] H[0] A[4] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        c.push("G")
        expected = ("N[zzz-new.txt] P[-rw-r--r--] U[root] G[root] C[1] Z[3] "
                    "D[-1] K[-1] T[] E[.txt] I[]")
        assert c.observe(lambda: c.ruler("stat"), expected) == expected
        assert c.errors() == []

    def test_watch_external_remove_updates_listing(self, lf_env, tmp_path):
        """A file removed by another process disappears and the index shrinks."""
        # CATCHES: keeping the stale entry (and its old index/total) after the
        # file is gone from disk.
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n", "b.txt": "bbb\n",
                                       "c.txt": "ccc\n"})
        c = lf_env.client(w, config="set watch\n")
        os.remove(w / "b.txt")
        assert c.observe(lambda: _ruler_field(c, "state", "A"), "2") == "2"
        assert c.ruler("state") == \
            "I[1/2] H[0] A[2] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        assert c.errors() == []

    def test_watch_external_rename_updates_listing(self, lf_env, tmp_path):
        """An external rename keeps the entry count but shows the new name."""
        # CATCHES: dropping the entry on the rename event without picking the
        # new name up again.
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n", "b.txt": "bbb\n"})
        c = lf_env.client(w, config="set watch\n")
        os.rename(w / "a.txt", w / "zz-renamed.txt")
        assert c.observe(lambda: _ruler_field(c, "state", "A"), "2") == "2"
        c.push("G")
        expected = ("N[zz-renamed.txt] P[-rw-r--r--] U[root] G[root] C[1] Z[4] "
                    "D[-1] K[-1] T[] E[.txt] I[]")
        assert c.observe(lambda: c.ruler("stat"), expected) == expected

    def test_watch_external_write_updates_size(self, lf_env, tmp_path):
        """Rewriting the current file refreshes its size in the stat ruler."""
        # CATCHES: only re-reading whole directories, so a modified file keeps
        # its stale size until the user moves the cursor.
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n"})
        c = lf_env.client(w, config="set watch\n")
        c.cmd("select a.txt")
        assert _ruler_field(c, "stat", "Z") == "4"
        (w / "a.txt").write_text("a" * 300 + "\n")
        assert c.observe(lambda: _ruler_field(c, "stat", "Z"), "301") == "301"
        assert c.errors() == []

    def test_watch_external_chmod_updates_permissions(self, lf_env, tmp_path):
        """An external chmod refreshes the permission string in the ruler."""
        # CATCHES: ignoring Chmod events, so the mode string goes stale.
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n"})
        c = lf_env.client(w, config="set watch\n")
        c.cmd("select a.txt")
        assert _ruler_field(c, "stat", "P") == "-rw-r--r--"
        os.chmod(w / "a.txt", 0o700)
        assert c.observe(lambda: _ruler_field(c, "stat", "P"),
                         "-rwx------") == "-rwx------"
        assert c.errors() == []

    def test_watch_child_dircount_updates(self, lf_env, tmp_path):
        """Creating a file inside a subdirectory refreshes its entry count."""
        # CATCHES: only watching the current directory, so child directories
        # (whose counts are shown with dircounts) never refresh.
        w = make_tree(tmp_path / "w", {"sub/": None, "sub/i1.txt": None,
                                       "a.txt": "x\n"})
        c = lf_env.client(w, config="set watch\nset dircounts\n")
        c.cmd("select sub")
        assert _ruler_field(c, "stat", "K") == "1"
        (w / "sub" / "i2.txt").write_text("x\n")
        expected = ("N[sub] P[drwxr-xr-x] U[root] G[root] C[2] Z[4096] "
                    "D[-1] K[2] T[] E[] I[]")
        assert c.observe(lambda: c.ruler("stat"), expected) == expected

    def test_watch_parent_directory_updates(self, lf_env, tmp_path):
        """Ancestor directories are watched, so the parent pane refreshes."""
        # CATCHES: watching only the current directory and leaving the parent
        # pane (drawn from the cached parent listing) stale.
        w = make_tree(tmp_path / "w", {"sub/": None, "sub/inner.txt": "x\n",
                                       "other.txt": "o\n"})
        c = lf_env.client(w / "sub", config="set watch\nset nopreview\n",
                          rows=10, cols=100)
        assert not any("parent-new-file.txt" in r for r in c.screen())
        (w / "parent-new-file.txt").write_text("p\n")
        c.wait_for(lambda: any("parent-new-file.txt" in r for r in c.screen()),
                   timeout=8, what="parent pane listing")
        assert any("parent-new-file.txt" in r for r in c.screen())
        assert c.errors() == []

    def test_watch_deleted_cwd_cds_to_parent(self, lf_env, tmp_path):
        """Removing the current directory from outside moves lf to its parent."""
        # CATCHES: staying in a deleted directory (or erroring) instead of
        # falling back to the parent directory.
        w = make_tree(tmp_path / "w", {"sub/": None, "sub/inner.txt": "x\n",
                                       "top.txt": None})
        c = lf_env.client(w / "sub", config="set watch\n")
        shutil.rmtree(w / "sub")
        c.wait_for(lambda: c.state()["pwd"] == str(w), timeout=8,
                   what="cd to parent after rmdir")
        assert c.state()["pwd"] == str(w)
        assert c.files() == ["top.txt"]
        assert c.ruler("state") == \
            "I[1/1] H[0] A[1] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        assert c.errors() == []

    def test_watch_symlinked_cwd_updates_via_alias(self, lf_env, tmp_path):
        """A change made through the real path refreshes the symlinked cwd."""
        # CATCHES: matching watch events by path string only, so an event
        # reported for the real directory never updates the same directory
        # reached through a symlink.
        w = make_tree(tmp_path / "w", {"real/": None, "real/orig.txt": "x\n"})
        (w / "link").symlink_to(w / "real", target_is_directory=True)
        c = lf_env.client(w / "real", config="set watch\n")
        c.cmd("cd ../link")
        assert c.state()["pwd"] == str(w / "link")
        assert _ruler_field(c, "state", "A") == "1"
        (w / "real" / "added-file.txt").write_text("y\n")
        assert c.observe(lambda: _ruler_field(c, "state", "A"), "2") == "2"

    def test_watch_toggle_at_runtime(self, lf_env, tmp_path):
        """``set watch`` starts watching cached dirs; ``set nowatch`` stops."""
        # CATCHES: only honouring the option at startup, or failing to stop
        # watching (and refreshing) after it is turned off.
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n"})
        c = lf_env.client(w)
        c.cmd("set watch")
        (w / "zz-one.txt").write_text("1\n")
        assert c.observe(lambda: _ruler_field(c, "state", "A"), "2") == "2"
        c.cmd("set nowatch")
        (w / "zz-two.txt").write_text("2\n")
        time.sleep(1.5)
        assert _ruler_field(c, "state", "A") == "2"
        c.cmd("reload")
        assert c.observe(lambda: _ruler_field(c, "state", "A"), "3") == "3"


class TestNoWatch:
    @pytest.mark.parametrize("change,key,template,stale,fresh", [
        # CATCHES: refreshing listings/stats on a timer or on every draw even
        # though neither `watch` nor `period` is enabled.
        ("create", "A", "state", "3", "4"),
        ("write", "Z", "stat", "4", "301"),
        ("chmod", "P", "stat", "-rw-r--r--", "-rwx------"),
    ])
    def test_without_watch_no_automatic_refresh(self, lf_env, tmp_path, change,
                                                key, template, stale, fresh):
        """Without watch/period an external change stays invisible until reload."""
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n", "b.txt": "bbb\n",
                                       "c.txt": "ccc\n"})
        c = lf_env.client(w)
        if change != "create":
            c.cmd("select a.txt")
        if change == "create":
            (w / "zz-new.txt").write_text("hi\n")
        elif change == "write":
            (w / "a.txt").write_text("a" * 300 + "\n")
        else:
            os.chmod(w / "a.txt", 0o700)
        time.sleep(1.5)
        assert _ruler_field(c, template, key) == stale
        c.cmd("reload")
        assert c.observe(lambda: _ruler_field(c, template, key),
                         fresh) == fresh
        assert c.errors() == []


class TestPeriod:
    def test_period_refreshes_listing(self, lf_env, tmp_path):
        """``set period 1`` re-reads the directory about once a second."""
        # CATCHES: never firing the periodic refresh (or only firing it once).
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n", "b.txt": "bbb\n"})
        c = lf_env.client(w, config="set period 1\n")
        assert c.ruler("state") == \
            "I[1/2] H[0] A[2] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        (w / "zz-new.txt").write_text("hi\n")
        assert c.observe(lambda: _ruler_field(c, "state", "A"), "3",
                         timeout=8) == "3"
        assert c.ruler("state") == \
            "I[1/3] H[0] A[3] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        assert c.errors() == []

    def test_period_invalid_values_error(self, lf_env, tmp_path):
        """Non-numeric and negative period values are rejected."""
        # CATCHES: accepting a negative period (or hiding the parse error).
        w = make_tree(tmp_path / "w", {"a.txt": "aaa\n"})
        c = lf_env.client(w)
        c.cmd("set period -1")
        assert c.errors()[-1] == "period: value should be a non-negative number"
        c.cmd("set period abc")
        assert c.errors()[-1] == \
            'period: strconv.Atoi: parsing "abc": invalid syntax'
