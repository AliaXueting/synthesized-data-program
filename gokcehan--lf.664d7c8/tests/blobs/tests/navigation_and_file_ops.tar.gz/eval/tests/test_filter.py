"""Filtering: setfilter, filtermethod text/glob/regex, incfilter, reset on cd."""

from conftest import make_tree


class TestSetFilter:
    def test_multiple_patterns_intersect(self, lf_env, tmp_path):
        """Space-separated patterns are ANDed (all must match)."""
        # CATCHES: treating the argument as a single pattern with a space.
        w = make_tree(tmp_path / "w", {"foo.txt": None, "bar.txt": None,
                                       "foobar.md": None, "other": None})
        c = lf_env.client(w)
        c.cmd("setfilter foo")
        assert c.files() == ["foo.txt", "foobar.md"]
        c.cmd("setfilter bar foo")
        assert c.files() == ["foobar.md"]

    def test_negated_pattern(self, lf_env, tmp_path):
        """A ``!``-prefixed pattern excludes matching files."""
        # CATCHES: treating ! as a literal character to match.
        w = make_tree(tmp_path / "w", {"foo.txt": None, "bar.txt": None,
                                       "foobar.md": None, "other": None})
        c = lf_env.client(w)
        c.cmd("setfilter !foo")
        assert c.files() == []

    def test_clear_filter_with_no_args(self, lf_env, tmp_path):
        """``setfilter`` with no argument removes the filter."""
        # CATCHES: keeping a stale filter or erroring on the empty call.
        w = make_tree(tmp_path / "w", {"foo.txt": None, "bar.txt": None,
                                       "foobar.md": None, "other": None})
        c = lf_env.client(w)
        c.cmd("setfilter foo")
        assert c.files() == ["foo.txt", "foobar.md"]
        c.cmd("setfilter")
        assert c.files() == ["bar.txt", "foo.txt", "foobar.md", "other"]

    def test_filter_ruler_counts(self, lf_env, tmp_path):
        """The ruler reports filter, hidden and total counts."""
        # CATCHES: miscounting hidden files (filtered-out ones are hidden:
        # here both "sub" and "f2.md" fail the "txt" filter).
        w = make_tree(tmp_path / "w", {"sub/": None, "f1.txt": None, "f2.md": None})
        (w / "sub" / "inner.txt").write_text("x\n")
        c = lf_env.client(w)
        c.cmd("setfilter txt")
        assert c.files() == ["f1.txt"]
        assert c.observe(lambda: c.ruler("state"),
                         "I[1/1] H[2] A[3] S[All] F[[txt]] M[NORMAL] "
                         "L[0] V[0] P[[]] C[0] T[0]") == \
            "I[1/1] H[2] A[3] S[All] F[[txt]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"


class TestFilterMethod:
    def test_glob_method(self, lf_env, tmp_path):
        """``filtermethod glob`` matches shell globs."""
        # CATCHES: substring matching when glob semantics are required (the
        # listing itself stays alphabetically sorted).
        w = make_tree(tmp_path / "w", {"foo.txt": None, "bar.txt": None, "foobar.md": None})
        c = lf_env.client(w)
        c.cmd("set filtermethod glob")
        c.cmd("setfilter *.txt")
        assert c.files() == ["bar.txt", "foo.txt"]
        c.cmd("setfilter *.md")
        assert c.files() == ["foobar.md"]

    def test_regex_method_and_invalid_regex(self, lf_env, tmp_path):
        """``filtermethod regex`` matches regexes; bad ones report an error."""
        # CATCHES: falling back to text matching instead of surfacing the
        # regexp parse error.
        w = make_tree(tmp_path / "w", {"foo.txt": None, "bar.txt": None, "foobar.md": None})
        c = lf_env.client(w)
        c.cmd("set filtermethod regex")
        c.cmd("setfilter ^foo")
        assert c.files() == ["foo.txt", "foobar.md"]
        c.cmd("setfilter [")
        assert c.files() == ["foo.txt", "foobar.md"]
        assert c.errors()[-1] == "filter: error parsing regexp: missing closing ]: `[`"
        c.cmd("setfilter (a|b)")
        assert c.files() == ["bar.txt", "foobar.md"]


class TestFilterLifecycle:
    def test_filter_reset_on_cd_and_restored_on_back(self, lf_env, tmp_path):
        """Entering a directory clears the filter; ``cd -`` restores it."""
        # CATCHES: leaking the filter into the new directory or losing the
        # saved filter when returning.
        w = make_tree(tmp_path / "w", {"sub/": None, "f1.txt": None, "f2.md": None})
        (w / "sub" / "inner.txt").write_text("x\n")
        c = lf_env.client(w)
        c.cmd("setfilter txt")
        assert c.files() == ["f1.txt"]
        c.cmd("cd %s" % (w / "sub"))
        assert c.files() == ["inner.txt"]
        assert c.ruler("state") == \
            "I[1/1] H[0] A[1] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        c.cmd("cd -")
        assert c.files() == ["f1.txt"]
        assert c.ruler("state") == \
            "I[1/1] H[2] A[3] S[All] F[[txt]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"

    def test_incfilter_updates_while_typing(self, lf_env, tmp_path):
        """With incfilter the list narrows per keystroke in the prompt."""
        # CATCHES: only applying the filter after Enter, or not showing the
        # prompt text on the message line.
        w = make_tree(tmp_path / "w", {"apple.txt": None, "apricot.txt": None,
                                       "banana.txt": None})
        c = lf_env.client(w, config="set incfilter\n")
        c.cmd("filter")
        c.push("ap")
        assert c.files(expected=["apple.txt", "apricot.txt"]) == \
            ["apple.txt", "apricot.txt"]
        assert c.observe(lambda: c.screen()[-1].strip(), "filter: ap") == \
            "filter: ap"
        c.push("p")
        assert c.files(expected=["apple.txt"]) == ["apple.txt"]
        c.push("<enter>")
        assert c.files(expected=["apple.txt"]) == ["apple.txt"]
        assert c.observe(lambda: c.ruler("state"),
                         "I[1/1] H[2] A[3] S[All] F[[app]] M[NORMAL] "
                         "L[0] V[0] P[[]] C[0] T[0]") == \
            "I[1/1] H[2] A[3] S[All] F[[app]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"

    def test_filter_prompt_prefilled_from_argument(self, lf_env, tmp_path):
        """``filter <arg>`` seeds the prompt; the list filters on Enter."""
        # CATCHES: applying the prefilled pattern immediately (without a
        # keystroke) or losing the given pattern when opening the prompt.
        w = make_tree(tmp_path / "w", {"apple.txt": None, "banana.txt": None})
        c = lf_env.client(w, config="set incfilter\n")
        c.cmd("filter ap")
        assert c.observe(lambda: c.screen()[-1].strip(), "filter: ap") == \
            "filter: ap"
        assert c.files() == ["apple.txt", "banana.txt"]
        c.push("<enter>")
        assert c.files(expected=["apple.txt"]) == ["apple.txt"]
        assert c.observe(lambda: c.ruler("state"),
                         "I[1/1] H[1] A[2] S[All] F[[ap]] M[NORMAL] "
                         "L[0] V[0] P[[]] C[0] T[0]") == \
            "I[1/1] H[1] A[2] S[All] F[[ap]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
