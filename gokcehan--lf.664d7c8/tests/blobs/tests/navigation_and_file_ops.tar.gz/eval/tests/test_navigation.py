"""Cursor movement, cd/updir, jump list, cursor restore, find and search."""

import os
import pwd

from conftest import make_tree


def _cur(c):
    return os.path.basename(c.state()["f"])


def _passwd_home():
    return pwd.getpwuid(os.getuid()).pw_dir


class TestMovement:
    def test_movement_keys_with_counts(self, lf_env, tmp_path):
        """j/k with counts, G/gg, count-G, M/L/H land on recorded entries."""
        # CATCHES: off-by-one in count movement or middle/low/high targets.
        w = make_tree(tmp_path / "w", {("f%02d" % i): None for i in range(12)})
        c = lf_env.client(w, rows=20, cols=110)
        assert _cur(c) == "f00"
        for keys, expected in [("5j", "f05"), ("3k", "f02"), ("10j", "f11"),
                               ("G", "f11"), ("gg", "f00"), ("2G", "f01"),
                               ("M", "f06"), ("L", "f11"), ("H", "f00")]:
            c.push(keys)
            assert c.observe(lambda: _cur(c), expected) == expected, keys

    def test_half_and_page_movement(self, lf_env, tmp_path):
        """half/page up/down move by half/a full window; scroll pct updates."""
        # CATCHES: wrong window size (must be rows-2 with nopreview) or wrong
        # ScrollPercentage formatting (right-aligned width 2).
        w = make_tree(tmp_path / "w", {("f%02d" % i): None for i in range(30)})
        c = lf_env.client(w, rows=10, cols=100, config="set nopreview\n")
        for cmd, expected, pct in [
                ("down", "f01", "Top"), ("half-down", "f05", "Top"),
                ("half-down", "f09", " 9%"), ("half-up", "f05", " 9%"),
                ("page-down", "f13", "27%"), ("page-up", "f05", "22%"),
                ("bottom", "f29", "Bot"), ("top", "f00", "Top")]:
            c.cmd(cmd)
            assert _cur(c) == expected, cmd
            got = c.ruler("state").split("S[")[1].split("]")[0]
            assert got == pct, (cmd, got)

    def test_scroll_commands_move_view_not_cursor(self, lf_env, tmp_path):
        """scroll-down/up shift the view; the cursor entry stays put."""
        # CATCHES: moving the cursor by the scroll amount instead of only
        # scrolling the window.
        w = make_tree(tmp_path / "w", {("f%02d" % i): None for i in range(30)})
        c = lf_env.client(w, rows=10, cols=100, config="set nopreview\n")
        c.push("4j")
        assert c.observe(lambda: _cur(c), "f04") == "f04"
        c.cmd("scroll-down")
        assert _cur(c) == "f04"
        assert "S[ 4%]" in c.ruler("state")
        c.cmd("scroll-down")
        assert _cur(c) == "f04"
        assert "S[ 9%]" in c.ruler("state")
        c.cmd("scroll-up")
        assert _cur(c) == "f04"
        assert "S[ 4%]" in c.ruler("state")

    def test_down_beyond_end_is_clamped(self, lf_env, tmp_path):
        """Moving past the last entry stops there without an error."""
        # CATCHES: wrapping by default or emitting an error at the boundary.
        w = make_tree(tmp_path / "w", {"a1": None, "a2": None, "b1": None})
        c = lf_env.client(w)
        c.cmd("setfilter a")
        c.cmd("down")
        assert _cur(c) == "a2"
        c.cmd("down")
        assert _cur(c) == "a2"
        assert c.errors() == []

    def test_scrolloff_keeps_cursor_off_edges(self, lf_env, tmp_path):
        """With scrolloff 2 the view scrolls once the cursor nears the edge."""
        # CATCHES: scrolling immediately from the top instead of after the
        # scrolloff margin is reached.
        w = make_tree(tmp_path / "w", {("f%02d" % i): None for i in range(30)})
        c = lf_env.client(w, rows=10, cols=100,
                          config="set nopreview\nset scrolloff 2\n")
        for keys, expected, pct in [("6j", "f06", " 4%"), ("j", "f07", " 9%"),
                                    ("j", "f08", "13%"), ("G", "f29", "Bot"),
                                    ("k", "f28", "Bot"), ("gg", "f00", "Top"),
                                    ("k", "f00", "Top")]:
            c.push(keys)
            assert c.observe(lambda: _cur(c), expected) == expected, keys
            got = c.observe(
                lambda: c.ruler("state").split("S[")[1].split("]")[0], pct)
            assert got == pct, (keys, got)

    def test_wrapscroll_wraps_at_edges(self, lf_env, tmp_path):
        """wrapscroll wraps at both ends; without it movement clamps."""
        # CATCHES: wrapping when the option is off, or not wrapping at the
        # bottom with it on.
        w = make_tree(tmp_path / "w", {("f%02d" % i): None for i in range(30)})
        c = lf_env.client(w, rows=20, cols=110, config="set scrolloff 5\n")
        c.push("10j")
        assert c.observe(lambda: _cur(c), "f10") == "f10"
        assert "S[Top]" in c.ruler("state")
        c.push("gg")
        c.cmd("set wrapscroll")
        c.push("k")
        assert c.observe(lambda: _cur(c), "f29") == "f29"
        assert c.observe(lambda: "S[Bot]" in c.ruler("state"), True) is True
        c.push("Gj")
        assert c.observe(lambda: _cur(c), "f00") == "f00"


class TestCd:
    def test_updir_positions_on_child(self, lf_env, tmp_path):
        """updir moves to the parent with the cursor on the visited child."""
        # CATCHES: resetting the parent cursor to the first entry instead of
        # the directory just left.
        w = make_tree(tmp_path / "w", {"sub/": None, "x.txt": None})
        (w / "sub" / "inner.txt").write_text("i\n")
        c = lf_env.client(w / "sub")
        assert c.files() == ["inner.txt"]
        c.cmd("updir")
        st = c.state()
        assert st["pwd"] == str(w)
        assert os.path.basename(st["f"]) == "sub"
        c.cmd("open")
        st = c.state()
        assert st["pwd"] == str(w / "sub")
        assert os.path.basename(st["f"]) == "inner.txt"

    def test_cd_into_child_selects_child_in_parent(self, lf_env, tmp_path):
        """cd <child> moves the parent's cursor onto that child."""
        # CATCHES: leaving the parent cursor wherever it was before the cd.
        w = make_tree(tmp_path / "w", {"a1": None, "a2": None, "a3": None,
                                       "a4": None, "sub/": None})
        c = lf_env.client(w)
        c.cmd("select a3")
        assert _cur(c) == "a3"
        c.cmd("cd sub")
        c.cmd("cd %s" % w)
        assert _cur(c) == "sub"

    def test_cursor_restored_when_returning(self, lf_env, tmp_path):
        """Returning to a directory restores the remembered cursor entry."""
        # CATCHES: resetting the cursor to the top when re-entering a dir.
        w = make_tree(tmp_path / "w", {"a1": None, "a2": None, "a3": None,
                                       "a4": None, "sub/": None})
        elsewhere = make_tree(tmp_path / "elsewhere", {"other.txt": None})
        c = lf_env.client(w)
        c.cmd("select a3")
        assert _cur(c) == "a3"
        assert c.ruler("state") == \
            "I[4/5] H[0] A[5] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        c.cmd("cd %s" % elsewhere)
        assert c.files() == ["other.txt"]
        c.cmd("cd %s" % w)
        assert _cur(c) == "a3"
        assert c.ruler("state") == \
            "I[4/5] H[0] A[5] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"

    def test_updir_at_root_stays(self, lf_env, tmp_path):
        """updir in / keeps the cwd and reports no error."""
        # CATCHES: erroring or moving somewhere else at the filesystem root.
        c = lf_env.client("/")
        c.cmd("updir")
        assert c.state()["pwd"] == "/"
        assert c.errors() == []

    def test_cd_relative_absolute_tilde_prev(self, lf_env, tmp_path):
        """cd handles relative paths, absolute paths, ~ and ``-``."""
        # CATCHES: ~ resolved from $HOME instead of the passwd database (the
        # client env overrides $HOME to a scratch dir, but ~ goes to the real
        # home), or cd - not tracking the previous directory.
        w = make_tree(tmp_path / "w", {"sub/": None, "x.txt": None})
        (w / "sub" / "inner.txt").write_text("i\n")
        c = lf_env.client(w / "sub")
        c.cmd("cd %s" % w)
        assert c.state()["pwd"] == str(w)
        c.cmd("cd sub")
        assert c.state()["pwd"] == str(w / "sub")
        c.cmd("cd ~")
        assert c.state()["pwd"] == _passwd_home()
        c.cmd("cd -")
        assert c.state()["pwd"] == str(w / "sub")

    def test_cd_errors(self, lf_env, tmp_path):
        """cd to a file or a missing dir reports chdir errors."""
        # CATCHES: generic error text or no error at all.
        w = make_tree(tmp_path / "w", {"f.txt": "x\n"})
        c = lf_env.client(w)
        c.cmd("cd f.txt")
        assert c.errors()[-1] == "cd: chdir %s: not a directory" % (w / "f.txt")
        c.cmd("cd /does/not/exist")
        assert c.errors()[-1] == \
            "cd: chdir /does/not/exist: no such file or directory"

    def test_cd_no_argument_goes_home(self, lf_env, tmp_path):
        """``cd`` without arguments changes to the user's home directory."""
        # CATCHES: treating a missing argument as an error or as ``.``.
        w = make_tree(tmp_path / "w", {"f.txt": "x\n"})
        c = lf_env.client(w)
        c.cmd("cd")
        assert c.state()["pwd"] == _passwd_home()

    def test_cd_minus_without_previous_errors(self, lf_env, tmp_path):
        """``cd -`` with no previous directory reports an error."""
        # CATCHES: silently ignoring cd - instead of reporting it.
        w = make_tree(tmp_path / "w", {"a": None})
        c = lf_env.client(w)
        c.cmd("cd -")
        assert c.errors()[-1] == "cd: no previous directory"


class TestJumpList:
    def test_jump_list_and_navigation(self, lf_env, tmp_path):
        """cd pushes entries; jump-prev/next move through the jump list."""
        # CATCHES: wrong jump-list table format, missing the ``>`` current
        # marker, not seeding the list with the starting directory, or an
        # off-by-one in the jump index.
        w = make_tree(tmp_path / "w", {"a/": None, "b/": None, "c/": None})
        c = lf_env.client(w)
        # the starting directory is recorded as the first jump (the state
        # dump makes the client refresh its exported jump table)
        c.state()
        assert c.query("jumps") == \
            "  jump\tpath\n> 0\t%s\n" % (w,)
        c.cmd("cd a")
        assert c.query("jumps") == \
            "  jump\tpath\n> 0\t%s\n  1\t%s\n" % (w / "a", w)
        c.cmd("cd ../b")
        assert c.query("jumps") == \
            "  jump\tpath\n> 0\t%s\n  1\t%s\n  2\t%s\n" % (w / "b", w / "a", w)
        c.cmd("jump-prev")
        assert c.state()["pwd"] == str(w / "a")
        assert c.query("jumps") == \
            "  jump\tpath\n  1\t%s\n> 0\t%s\n  1\t%s\n" % (w / "b", w / "a", w)
        c.cmd("jump-next")
        assert c.state()["pwd"] == str(w / "b")
        c.cmd("jump-prev")
        c.cmd("jump-prev")
        assert c.state()["pwd"] == str(w)
        c.cmd("jump-prev")
        assert c.state()["pwd"] == str(w)
        assert c.errors() == []


class TestSelect:
    def test_select_moves_cursor_and_errors(self, lf_env, tmp_path):
        """select jumps to the file; missing files and missing args error."""
        # CATCHES: select not erroring for nonexistent paths or wrong index
        # reporting after the jump.
        w = make_tree(tmp_path / "w", {"a1": None, "a2": None, "a3": None,
                                       "a4": None, "sub/": None})
        c = lf_env.client(w)
        c.cmd("select a3")
        assert _cur(c) == "a3"
        assert c.ruler("state") == \
            "I[4/5] H[0] A[5] S[All] F[[]] M[NORMAL] L[0] V[0] P[[]] C[0] T[0]"
        c.cmd("select nosuch")
        assert c.errors()[-1] == "select: lstat nosuch: no such file or directory"
        c.cmd("select")
        assert c.errors()[-1] == "select: requires an argument"

    def test_select_path_with_spaces(self, lf_env, tmp_path):
        """select accepts quoted names containing spaces."""
        # CATCHES: splitting the argument on spaces before lstat.
        w = make_tree(tmp_path / "w", {"sp ace.txt": None, "plain": None})
        c = lf_env.client(w)
        c.cmd('select "sp ace.txt"')
        assert os.path.basename(c.state()["f"]) == "sp ace.txt"


class TestFind:
    def test_find_and_find_next_wrap(self, lf_env, tmp_path):
        """find jumps to the next prefix match and wraps around the list."""
        # CATCHES: matching the current entry, substring matching instead of
        # prefix matching, or not wrapping on find-next.
        w = make_tree(tmp_path / "w", {"apple": None, "apricot": None,
                                       "banana": None, "cherry": None})
        c = lf_env.client(w)
        c.send("find")
        c.push("a")
        assert c.observe(lambda: _cur(c), "apricot") == "apricot"
        c.cmd("find-next")
        assert _cur(c) == "apple"
        c.cmd("find-next")
        assert _cur(c) == "apricot"
        assert c.errors() == []

    def test_find_not_found_error(self, lf_env, tmp_path):
        """find with no match leaves the cursor and reports an error."""
        # CATCHES: silently doing nothing instead of reporting the pattern.
        w = make_tree(tmp_path / "w", {"apple": None, "banana": None})
        c = lf_env.client(w)
        c.send("find")
        c.push("z")
        assert c.observe(lambda: _cur(c), "apple") == "apple"
        expected = "find: pattern not found: z"
        assert c.observe(lambda: c.errors()[-1] if c.errors() else None,
                         expected) == expected

    def test_find_back(self, lf_env, tmp_path):
        """find-back searches upwards for the prefix."""
        # CATCHES: find-back behaving like find (forward).
        w = make_tree(tmp_path / "w", {"apple": None, "apricot": None, "banana": None})
        c = lf_env.client(w)
        c.cmd("select banana")
        c.send("find-back")
        c.push("b")
        assert c.observe(lambda: _cur(c), "banana") == "banana"
        c.cmd("select banana")
        c.send("find-back")
        c.push("a")
        assert c.observe(lambda: _cur(c), "apricot") == "apricot"


class TestSearch:
    def test_search_no_match_is_silent(self, lf_env, tmp_path):
        """A search pattern with no match moves nothing and errors nothing."""
        # CATCHES: reporting "pattern not found" like find does (search is
        # deliberately silent here).
        w = make_tree(tmp_path / "w", {"apple": None, "Apricot": None, "banana": None})
        c = lf_env.client(w)
        c.send("search")
        c.push("zz<enter>")
        assert c.observe(lambda: _cur(c), "apple") == "apple"
        assert c.errors() == []

    def test_search_next_without_further_match(self, lf_env, tmp_path):
        """search lands on the next match; search-next stays put silently."""
        # CATCHES: search-next erroring or moving when no further match exists
        # (wrapscan is on but only one entry matches).
        w = make_tree(tmp_path / "w", {"apple": None, "Apricot": None, "banana": None})
        c = lf_env.client(w)
        c.send("search")
        c.push("an<enter>")
        assert c.observe(lambda: _cur(c), "banana") == "banana"
        c.cmd("search-next")
        assert _cur(c) == "banana"
        assert c.errors() == []

    def test_search_regex_method_error(self, lf_env, tmp_path):
        """With searchmethod regex an invalid pattern reports the parse error."""
        # CATCHES: not surfacing regexp compile errors for search.
        w = make_tree(tmp_path / "w", {"apple": None, "banana": None})
        c = lf_env.client(w)
        c.cmd("set searchmethod regex")
        c.send("search")
        c.push("[<enter>")
        expected = "search: error parsing regexp: missing closing ]: `[`: ["
        assert c.observe(lambda: c.errors()[-1] if c.errors() else None,
                         expected) == expected
