"""Sorting: sortby variants, dirfirst, reverse, case/diacritics, custom info.

All expected orderings and error strings were recorded from the reference
binary via ``lf -remote`` queries.
"""

import os

import pytest

from conftest import make_tree


class TestSortBy:
    def test_natural_orders_numbers_by_value(self, lf_env, tmp_path):
        """Default natural sort orders embedded numbers by numeric value."""
        # CATCHES: plain lexicographic ordering (file10 before file2).
        w = make_tree(tmp_path / "w", {"file1": None, "file2": None, "file10": None,
                                       "file20": None, "File3": None})
        c = lf_env.client(w)
        assert c.files() == ["file1", "file2", "File3", "file10", "file20"]

    def test_sortby_name_is_plain_string_compare(self, lf_env, tmp_path):
        """``sortby name`` compares whole names (no number awareness)."""
        # CATCHES: using natural comparison for the name method (file2 would
        # come before file10).
        w = make_tree(tmp_path / "w", {"file1": None, "file2": None, "file10": None,
                                       "file20": None, "File3": None})
        c = lf_env.client(w)
        c.cmd("set sortby name")
        assert c.files() == ["file1", "file10", "file2", "file20", "File3"]

    def test_sortby_invalid_value_error(self, lf_env, tmp_path):
        """An unknown sortby value is rejected and the listing unchanged."""
        # CATCHES: silently falling back to another sort for bad values.
        w = make_tree(tmp_path / "w", {"file1": None, "file2": None})
        c = lf_env.client(w)
        c.cmd("set sortby name")
        c.cmd("set sortby invalid")
        assert c.files() == ["file1", "file2"]
        assert c.errors()[-1] == \
            "sortby: value should either be 'natural', 'name', 'size', 'time', " \
            "'atime', 'btime', 'ctime', 'ext' or 'custom'"

    def test_sortby_size_and_reverse(self, lf_env, tmp_path):
        """``sortby size`` orders by byte size; reverse flips it (dirs last)."""
        # CATCHES: sorting by block size instead of byte length, or dropping
        # the directory entry from the list.
        w = make_tree(tmp_path / "w", {"dir/": None})
        (w / "big").write_text("x" * 5000)
        (w / "small").write_text("x" * 10)
        (w / "mid").write_text("x" * 100)
        c = lf_env.client(w)
        c.cmd("set sortby size")
        assert c.files() == ["dir", "small", "mid", "big"]
        c.cmd("set reverse")
        assert c.files() == ["dir", "big", "mid", "small"]

    def test_sortby_time_uses_mtime(self, lf_env, tmp_path):
        """``sortby time`` orders oldest first by modification time."""
        # CATCHES: newest-first ordering or using ctime instead of mtime.
        w = make_tree(tmp_path / "w", {"old.txt": None, "new.txt": None, "mid.txt": None})
        os.utime(w / "old.txt", (1000000000, 1000000000))
        os.utime(w / "mid.txt", (1500000000, 1500000000))
        os.utime(w / "new.txt", (2000000000, 2000000000))
        c = lf_env.client(w)
        c.cmd("set sortby time")
        assert c.files() == ["old.txt", "mid.txt", "new.txt"]
        c.cmd("set sortby ctime")
        assert c.files() == ["old.txt", "mid.txt", "new.txt"]

    def test_sortby_atime(self, lf_env, tmp_path):
        """``sortby atime`` orders by access time (oldest first)."""
        # CATCHES: ignoring atime and falling back to mtime/name order.
        w = make_tree(tmp_path / "w", {"a": None, "b": None, "c": None})
        os.utime(w / "a", (1600000000, 1000000000))  # atime 1600, mtime 1000
        os.utime(w / "b", (1700000000, 1700000000))
        os.utime(w / "c", (1500000000, 1500000000))
        c = lf_env.client(w)
        c.cmd("set sortby atime")
        assert c.files() == ["c", "a", "b"]

    def test_sortby_btime_falls_back_to_mtime(self, lf_env, tmp_path):
        """btime sorts like mtime on filesystems without birth time."""
        # CATCHES: crashing or ordering by name when birth time is unavailable.
        w = make_tree(tmp_path / "w", {"a": None, "b": None, "c": None})
        os.utime(w / "a", (1600000000, 1600000000))
        os.utime(w / "b", (1700000000, 1700000000))
        os.utime(w / "c", (1500000000, 1500000000))
        c = lf_env.client(w)
        c.cmd("set sortby btime")
        assert c.files() == ["c", "a", "b"]

    def test_sortby_ext_groups_by_extension(self, lf_env, tmp_path):
        """``sortby ext`` orders by extension, no-ext files first, then name."""
        # CATCHES: comparing full names instead of extensions, or wrong
        # tie-breaking between a.md and d.md.
        w = make_tree(tmp_path / "w", {"a.md": None, "b.txt": None, "c": None,
                                       "d.md": None, "e.TXT": None})
        c = lf_env.client(w)
        c.cmd("set sortby ext")
        assert c.files() == ["c", "a.md", "d.md", "b.txt", "e.TXT"]

    def test_sortignorecase_toggle(self, lf_env, tmp_path):
        """Default ignores case; ``set nosortignorecase`` compares raw bytes."""
        # CATCHES: wrong default for sortignorecase or no re-sort on toggle.
        w = make_tree(tmp_path / "w", {"file1": None, "file2": None, "file10": None,
                                       "file20": None, "File3": None})
        c = lf_env.client(w)
        c.cmd("set sortignorecase!")
        assert c.files() == ["File3", "file1", "file2", "file10", "file20"]

    def test_sortignoredia_removes_diacritics(self, lf_env, tmp_path):
        """Diacritics are stripped before comparing unless disabled."""
        # CATCHES: byte-comparing UTF-8 é (0xC3...) which sorts after z.
        w = make_tree(tmp_path / "w", {"éclair.txt": None, "eclair.txt": None,
                                       "eiffel.txt": None, "zebra.txt": None})
        c = lf_env.client(w)
        names = c.files()
        assert names.index("éclair.txt") < names.index("eiffel.txt")
        assert names.index("eclair.txt") < names.index("eiffel.txt")
        c.cmd("set nosortignoredia")
        assert c.files() == ["eclair.txt", "eiffel.txt", "zebra.txt", "éclair.txt"]


class TestCustomSort:
    def test_addcustominfo_and_sortby_custom(self, lf_env, tmp_path):
        """``addcustominfo`` attaches a key; sortby custom sorts naturally."""
        # CATCHES: custom info not visible in the ruler or ignored by sort.
        w = make_tree(tmp_path / "w", {"one.txt": None, "two.txt": None, "three.txt": None})
        c = lf_env.client(w)
        c.cmd("addcustominfo one.txt 3")
        c.cmd("addcustominfo two.txt 1")
        c.cmd("addcustominfo three.txt 2")
        c.cmd("select one.txt")
        assert c.observe(lambda: c.ruler("stat"),
                         "N[one.txt] P[-rw-r--r--] U[root] G[root] C[1] Z[0] "
                         "D[-1] K[-1] T[] E[.txt] I[3]") == \
            "N[one.txt] P[-rw-r--r--] U[root] G[root] C[1] Z[0] D[-1] K[-1] T[] E[.txt] I[3]"
        c.cmd("set sortby custom")
        assert c.files(expected=["two.txt", "three.txt", "one.txt"]) == \
            ["two.txt", "three.txt", "one.txt"]

    def test_addcustominfo_missing_file(self, lf_env, tmp_path):
        """Adding custom info for a nonexistent file reports an error."""
        # CATCHES: silently creating state for a file that does not exist.
        w = make_tree(tmp_path / "w", {"one.txt": None})
        c = lf_env.client(w)
        c.cmd("addcustominfo nosuch.txt 0")
        assert c.errors()[-1] == "addcustominfo: file not found: %s" % (w / "nosuch.txt")


class TestDirFirst:
    def test_dirfirst_default_and_disable(self, lf_env, tmp_path):
        """Directories precede files by default; ``nodirfirst`` merges them."""
        # CATCHES: no re-sort when the option changes, or dirs mixed in by
        # default.
        w = make_tree(tmp_path / "w", {"b/": None, "a.txt": None, "c/": None, "d.txt": None})
        c = lf_env.client(w)
        assert c.files() == ["b", "c", "a.txt", "d.txt"]
        c.cmd("set nodirfirst")
        assert c.files() == ["a.txt", "b", "c", "d.txt"]

    def test_dirfirst_survives_reverse(self, lf_env, tmp_path):
        """With reverse, dirs stay first but reverse among themselves."""
        # CATCHES: applying reverse to the whole list (dirs would sink).
        w = make_tree(tmp_path / "w", {"b/": None, "a.txt": None, "c/": None, "d.txt": None})
        c = lf_env.client(w)
        c.cmd("set reverse")
        assert c.files() == ["c", "b", "d.txt", "a.txt"]


class TestReSort:
    def test_resort_when_option_changes(self, lf_env, tmp_path):
        """Changing sortby/reverse re-sorts the live listing immediately."""
        # CATCHES: only applying the new order after a manual reload.
        w = make_tree(tmp_path / "w", {"b1": None, "a2": None, "a10": None})
        c = lf_env.client(w)
        assert c.files() == ["a2", "a10", "b1"]
        c.cmd("set sortby name")
        assert c.files() == ["a10", "a2", "b1"]
        c.cmd("setlocal %s reverse true" % w)
        assert c.files() == ["b1", "a2", "a10"]
