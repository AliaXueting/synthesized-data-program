"""Black-box test harness for the ``lf`` terminal file manager.

The candidate binary is a TUI program, so tests drive it the way a user does:

* a client is started on a pseudo-terminal (``pty.fork``) with a fully pinned
  environment, its own socket directory, data directory and config file;
* commands are injected with ``lf -remote "send <pid> <cmd>"``;
* state is observed through ``lf -remote "query <pid> files"``, exported
  environment variables of ``&``-shell commands, the ``-log`` file (every
  ``echoerr`` is logged as ``error: <msg>``), ruler templates rendered via
  ``set rulerfile``, the on-disk clipboard/marks/tags files and the real
  filesystem effects of copy/move/delete/rename.

Every observation helper synchronises with the client through a marker file:
an ``&``-shell command appends to the marker after it runs, so a growing
marker means the client has evaluated everything sent before it (the server
relays messages to the client in order).
"""

import fcntl
import os
import pty
import re
import select
import shutil
import struct
import subprocess
import tempfile
import termios
import time
from pathlib import Path

import pytest

# The pipeline runner executes the suite under ``umask 0002``; the recorded
# expectations for file/dir permission strings assume the common ``umask 022``
# (dirs 0755, files 0644).  Pin the umask for this process and every child
# (lf clients, ``-remote`` helpers and shell commands) so the observations are
# hermetic with respect to the runner's umask.
os.umask(0o022)

# ---------------------------------------------------------------------------
# executable resolution
# ---------------------------------------------------------------------------

_COVPROBE_CACHE = {}


def _writes_counters(exe):
    """Return True if the binary was built with Go coverage instrumentation.

    Runs ``<exe> -version`` with a fresh ``GOCOVERDIR`` and checks whether
    counter files were written into it.
    """
    exe = str(exe)
    if exe in _COVPROBE_CACHE:
        return _COVPROBE_CACHE[exe]
    result = False
    with tempfile.TemporaryDirectory(prefix="lf-covprobe-") as d:
        env = {"PATH": "/usr/bin:/bin", "GOCOVERDIR": d}
        try:
            subprocess.run([exe, "-version"], env=env,
                           capture_output=True, timeout=60)
        except (OSError, subprocess.TimeoutExpired):
            result = False
        else:
            result = any(f.startswith("covcounters.")
                         for f in os.listdir(d))
    _COVPROBE_CACHE[exe] = result
    return result


def lf_executable():
    """Resolve the lf binary under test from PROGRAMGYM_EXECUTABLE.

    When the pipeline asks for coverage (GOCOVERDIR set) and the assigned
    binary is not instrumented, fall back to the staged instrumented build
    so the module's coverage report is not empty.
    """
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    assert exe, "PROGRAMGYM_EXECUTABLE is not set"
    exe = os.path.abspath(exe)
    if os.environ.get("GOCOVERDIR") and not _writes_counters(exe):
        alt = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if alt.exists() and _writes_counters(alt):
            return str(alt)
    return exe


def run_lf(args, cwd=None, env=None, input=b"", timeout=60):
    """Run the lf executable once, headless, with a pinned environment."""
    child_env = dict(LfEnv.BASE_ENV)
    if env:
        child_env.update(env)
    return subprocess.run([lf_executable(), *args],
                          cwd=str(cwd) if cwd else None,
                          env=child_env, input=input,
                          capture_output=True, timeout=timeout)


# ---------------------------------------------------------------------------
# pty screen reconstruction
# ---------------------------------------------------------------------------

_CSI_H = re.compile(rb"\x1b\[(\d+);(\d+)H")
_ANSI_STRIP = re.compile(
    rb"\x1b\[[0-9;?<>! ]*[a-zA-Z]"
    rb"|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)"
    rb"|\x1b[()][A-Za-z0-9]"
    rb"|\x1b[=>78MDEHc]"
    rb"|[\x00-\x08\x0b-\x1f\x7f]"
)


def render_rows(data, rows, cols):
    """Reconstruct screen rows from the ANSI output of a ``redraw``.

    ``redraw`` (tcell ``screen.Sync``) repaints the whole screen: everything
    after the last ``\\x1b[H\\x1b[J`` is positioned text at ``\\x1b[r;cH``.
    """
    idx = data.rfind(b"\x1b[H\x1b[J")
    if idx >= 0:
        data = data[idx + 4:]
    screen = [[" "] * cols for _ in range(rows)]
    matches = list(_CSI_H.finditer(data))
    for i, m in enumerate(matches):
        r, c = int(m.group(1)), int(m.group(2))
        end = matches[i + 1].start() if i + 1 < len(matches) else len(data)
        text = _ANSI_STRIP.sub(b"", data[m.end():end]).decode("utf-8", "replace")
        if 1 <= r <= rows:
            for k, ch in enumerate(text):
                if c - 1 + k < cols:
                    screen[r - 1][c - 1 + k] = ch
    return ["".join(r).rstrip() for r in screen]


# ---------------------------------------------------------------------------
# state dump parsing
#
# The harness installs an ``lf-dump`` command in the client config:
#     cmd lf-dump &printf 'F\n%s\nX\n%s\nS\n%s\nV\n%s\nD\n%s\nZ\n' \
#         "$f" "$fx" "$fs" "$fv" "$PWD" >> <state>; printf x >> <marker>
# A dump record therefore looks like:
#     F /current/file
#     X <fx: one path per line>
#     S <fs: one path per line>
#     V <fv: one path per line>
#     D <cwd>
#     Z
# and the marker write proves the client has finished evaluating everything
# sent before the dump.
# ---------------------------------------------------------------------------

_SENTINELS = {"X": "fx", "S": "fs", "V": "fv", "D": "pwd"}


def parse_state_dump(text):
    """Parse all records written by ``lf-dump``; returns a list of dicts."""
    records = []
    for chunk in text.split("\nZ\n"):
        lines = chunk.split("\n")
        if not lines or lines[0] != "F":
            continue
        fields = {}
        cur, buf = "f", []
        for line in lines[1:]:
            if line in _SENTINELS:
                fields[cur] = "\n".join(buf)
                cur, buf = _SENTINELS[line], []
            else:
                buf.append(line)
        fields[cur] = "\n".join(buf)
        if "pwd" in fields:
            records.append(fields)
    return records


# ---------------------------------------------------------------------------


class LfEnv:
    """A hermetic lf environment: env vars, socket, data dir, clients."""

    BASE_ENV = {
        "PATH": "/usr/bin:/bin",
        "TERM": "xterm-256color",
        "SHELL": "/bin/sh",
        "OPENER": "true",
        "EDITOR": "true",
        "PAGER": "cat",
    }

    def __init__(self, tmp_path):
        self.exe = lf_executable()
        self.root = Path(tmp_path)
        self.home = self.root / "home"
        self.runtime = self.root / "run"
        self.data = self.root / "data" / "lf"
        self.cfgdir = self.root / "config" / "lf"
        for d in (self.home, self.runtime, self.data, self.cfgdir):
            d.mkdir(parents=True, exist_ok=True)
        os.chmod(self.runtime, 0o700)
        self.env = dict(self.BASE_ENV)
        self.env.update({
            "HOME": str(self.home),
            "XDG_RUNTIME_DIR": str(self.runtime),
            "LF_DATA_HOME": str(self.root / "data"),
            "LF_CONFIG_HOME": str(self.root / "config"),
        })
        # required coverage hook: forward GOCOVERDIR into the child env
        for passthrough in ("GOCOVERDIR",):
            if os.environ.get(passthrough):
                self.env[passthrough] = os.environ[passthrough]
        self.clients = []
        self._seq = 0

    # -- one-shot helpers ---------------------------------------------------

    def remote(self, request, check=True, timeout=60):
        """Run ``lf -remote <request>`` against this environment's server."""
        p = subprocess.run([self.exe, "-remote", request], env=self.env,
                           capture_output=True, timeout=timeout)
        if check and p.returncode != 0:
            raise RuntimeError("remote %r failed (%d): %s %s" % (
                request, p.returncode, p.stdout, p.stderr))
        return p.stdout.decode()

    def client(self, cwd, config="", args=(), rows=24, cols=100, env_extra=None):
        """Start a TUI client on a pty in ``cwd``; returns LfClient."""
        c = LfClient(self, cwd, config, args, rows, cols, env_extra)
        self.clients.append(c)
        return c

    def shutdown(self):
        """Tear down every client and the server."""
        for c in self.clients:
            c.kill()
        try:
            self.remote("quit!", check=False, timeout=10)
        except Exception:
            pass
        sock = self.runtime / "lf.sock"
        for _ in range(50):
            if not sock.exists():
                break
            time.sleep(0.02)
        if sock.exists():
            try:
                sock.unlink()
            except OSError:
                pass


class LfClient:
    """One live lf TUI process attached to a pseudo-terminal."""

    def __init__(self, env, cwd, config, args, rows, cols, env_extra):
        self.env_obj = env
        self.exe = env.exe
        self.cwd = str(cwd)
        self.rows, self.cols = rows, cols
        self.root = env.root
        seq = env._seq
        env._seq += 1
        self.marker = self.root / ("marker-%d" % seq)
        self.marker.touch()
        self.statefile = self.root / ("state-%d.txt" % seq)
        self.statefile.touch()
        self.log = self.root / ("lf-%d.log" % seq)
        self._write_ruler_templates()
        self.rulerfile = self.ruler_paths["state"]

        dump_cmd = (
            "cmd lf-dump &printf 'F\\n%s\\nX\\n%s\\nS\\n%s\\nV\\n%s\\nD\\n%s\\nZ\\n'"
            ' "$f" "$fx" "$fs" "$fv" "$PWD" >> ' + str(self.statefile) +
            "; printf x >> " + str(self.marker)
        )
        body = "set nohistory\nset rulerfile %s\n" % self.rulerfile \
            + config + "\n" + dump_cmd + "\n"
        cfg = self.root / ("lfrc-%d" % seq)
        cfg.write_text(body)

        self.args = ["-config", str(cfg), "-log", str(self.log), *args]
        self.env = dict(env.env)
        if env_extra:
            for k, v in env_extra.items():
                if v is None:
                    self.env.pop(k, None)
                else:
                    self.env[k] = v

        self.pid, self.master = pty.fork()
        if self.pid == 0:  # child
            try:
                os.chdir(self.cwd)
                os.environ.clear()
                os.environ.update(self.env)
                os.execv(self.exe, [self.exe] + self.args)
            except Exception:
                os._exit(99)
        fcntl.ioctl(self.master, termios.TIOCSWINSZ,
                    struct.pack("HHHH", rows, cols, 0, 0))
        self._wait_ready()
        # wait for the initial directory to be read from disk
        self._wait_ready_files()

    # -- setup helpers --------------------------------------------------------

    RULER_TEMPLATES = {
        "state": "I[{{.Index}}/{{.Total}}] H[{{.Hidden}}] A[{{.All}}] "
                 "S[{{.ScrollPercentage}}] F[{{.Filter}}] M[{{.Mode}}] "
                 "L[{{len .Select}}] V[{{len .Visual}}] P[{{.Progress}}] "
                 "C[{{len .Copy}}] T[{{len .Cut}}]",
        "stat": "N[{{.Stat.Name}}] P[{{.Stat.Permissions}}] "
                "U[{{.Stat.User}}] G[{{.Stat.Group}}] C[{{.Stat.LinkCount}}] "
                "Z[{{.Stat.Size}}] D[{{.Stat.DirSize}}] K[{{.Stat.DirCount}}] "
                "T[{{.Stat.Target}}] E[{{.Stat.Extension}}] "
                "I[{{.Stat.CustomInfo}}]",
        "df": "DF[{{df}}]",
        "progress": "P[{{.Progress}}] C[{{.Copy}}] T[{{.Cut}}]",
        "clip": "C[{{range .Copy}}{{.}}|{{end}}] T[{{range .Cut}}{{.}}|{{end}}]",
        "msg": "{{.Message}}",
    }

    def _write_ruler_templates(self):
        self.ruler_paths = {}
        ruler_dir = self.root / "ruler"
        ruler_dir.mkdir(exist_ok=True)
        for name, tmpl in self.RULER_TEMPLATES.items():
            p = ruler_dir / name
            p.write_text(tmpl + "\n")
            self.ruler_paths[name] = p

    def _wait_ready(self, timeout=20):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                out = self.remote("list", check=False)
                if str(self.pid) in out.split():
                    return
            except Exception:
                pass
            time.sleep(0.05)
        raise RuntimeError("lf client %d never registered with the server" % self.pid)

    def _wait_ready_files(self, timeout=10):
        # The "files" state table is only refreshed when a shell command runs
        # in the client, so nudge the client with a state dump while polling
        # instead of waiting out the whole timeout.
        try:
            visible = [n for n in os.listdir(self.cwd) if not n.startswith(".")]
        except OSError:
            visible = None
        if visible is not None and not visible:
            # nothing can be listed (hidden by default); settle and continue
            time.sleep(0.3)
            return
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.query("files").strip():
                return
            try:
                self.state(timeout=min(5, max(1.0, deadline - time.time())))
            except RuntimeError:
                pass
            time.sleep(0.02)
        # an empty directory legitimately lists no files; settle and continue
        time.sleep(0.2)

    # -- primitives -----------------------------------------------------------

    def remote(self, request, check=True, timeout=60):
        return self.env_obj.remote(request, check, timeout)

    def drain(self, timeout=0.2):
        """Read pending bytes from the pty master."""
        out = b""
        end = time.time() + timeout
        while time.time() < end:
            r, _, _ = select.select([self.master], [], [],
                                    max(0.0, end - time.time()))
            if not r:
                break
            try:
                d = os.read(self.master, 65536)
            except OSError:
                break
            if not d:
                break
            out += d
        return out

    def marker_size(self):
        return self.marker.stat().st_size

    def _wait_marker(self, old, timeout=15):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.marker_size() > old:
                return
            self.drain(0.02)
            time.sleep(0.02)
        raise RuntimeError("marker did not advance (client %d stuck?)" % self.pid)

    # -- driving the client ---------------------------------------------------

    def send(self, cmd):
        """Send an expression without waiting for it to be evaluated."""
        self.remote("send %d %s" % (self.pid, cmd))

    def shell(self, cmd, timeout=15):
        """Run an async (``&``) shell command in the client and wait for it."""
        old = self.marker_size()
        self.remote("send %d &%s; printf x >> %s" % (self.pid, cmd, self.marker))
        self._wait_marker(old, timeout)

    def push(self, keys):
        """Feed a key sequence (e.g. ``5j``) to the client."""
        self.remote("send %d push %s" % (self.pid, keys))
        time.sleep(0.05)

    def cmd(self, cmd, timeout=15):
        """Evaluate an expression and return the state after it.

        The dump command sent right after is relayed after ``cmd`` and its
        marker write proves ``cmd`` has been evaluated.
        """
        self.send(cmd)
        return self.state(timeout=timeout)

    def state(self, timeout=15):
        """Dump f/fx/fs/fv/PWD via the client's exported environment."""
        old = self.marker_size()
        self.remote("send %d lf-dump" % self.pid)
        self._wait_marker(old, timeout)
        return parse_state_dump(self.statefile.read_text())[-1]

    def query(self, key):
        """Query a live client's state table (``files``, ``jumps``, ...)."""
        return self.remote("query %d %s" % (self.pid, key))

    def files(self, expected=None, timeout=8):
        """Return the displayed file names of the current directory.

        With ``expected`` (a list of names), poll until the async directory
        load has produced exactly that list (or the timeout expires).
        """
        deadline = time.time() + timeout
        names = []
        while True:
            self.state()
            names = [os.path.basename(p) for p in self.query("files").split("\n") if p]
            if expected is None or names == expected or time.time() >= deadline:
                return names
            time.sleep(0.05)

    # -- observation channels ---------------------------------------------------

    def errors(self):
        """All error messages echoed so far (from the ``-log`` file)."""
        out = []
        try:
            text = self.log.read_text()
        except FileNotFoundError:
            return out
        for line in text.splitlines():
            m = re.match(r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} error: (.*)$", line)
            if m:
                out.append(m.group(1))
        return out

    def messages(self):
        """All ``echomsg`` messages echoed so far (from the ``-log`` file)."""
        out = []
        try:
            text = self.log.read_text()
        except FileNotFoundError:
            return out
        for line in text.splitlines():
            m = re.match(r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} (.+)$", line)
            if not m:
                continue
            rest = m.group(1)
            if not rest.startswith(("error: ", "recv:", "shell-async:", "loading", "listFiles")):
                out.append(rest)
        return out

    def screen(self, wait=0.25):
        """Force a full repaint and return the reconstructed screen rows.

        Drains the pty until the repaint output settles (two consecutive
        quiet windows after the first bytes arrive) instead of a fixed
        sleep, so a heavily loaded client is still given time to paint.
        """
        self.drain(0.1)
        self.send("redraw")
        out = b""
        seen = False
        quiet = 0
        deadline = time.time() + 6.0
        while time.time() < deadline:
            d = self.drain(0.15)
            if d:
                out += d
                seen = True
                quiet = 0
            elif seen:
                quiet += 1
                if quiet >= 2:
                    break
        return render_rows(out, self.rows, self.cols)

    def ruler(self, name="state"):
        """Render a harness ruler template on the last screen line."""
        self.send("set rulerfile %s" % self.ruler_paths[name])
        return self.screen()[-1].strip()

    def wait_for(self, predicate, timeout=10, what="condition"):
        """Poll ``predicate()`` until it is true or the timeout expires."""
        deadline = time.time() + timeout
        last = None
        while time.time() < deadline:
            last = predicate()
            if last:
                return last
            time.sleep(0.05)
        raise RuntimeError("timed out waiting for %s (last: %r)" % (what, last))

    def observe(self, fn, expected, timeout=10):
        """Poll an observation until it returns ``expected``; return the value.

        Effects driven by ``push``-injected keys or async operations are not
        synchronised with the ``lf-dump`` marker, so every exact-match
        assertion on them must first poll for the recorded value; the value
        returned here is a fresh observation the caller asserts against.
        """
        self.wait_for(lambda: fn() == expected, timeout,
                      what="observation %r" % (expected,))
        return fn()

    def wait_exit(self, timeout=10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            p, st = os.waitpid(self.pid, os.WNOHANG)
            if p == self.pid:
                self.drain(0.1)
                return st
            time.sleep(0.02)
        return None

    def kill(self):
        """Terminate the client process if it is still running."""
        try:
            os.kill(self.pid, 0)
        except OSError:
            return
        try:
            self.remote("send %d quit" % self.pid, check=False)
        except Exception:
            pass
        if self.wait_exit(2) is not None:
            return
        try:
            os.kill(self.pid, 9)
        except OSError:
            pass
        try:
            os.waitpid(self.pid, 0)
        except OSError:
            pass


# ---------------------------------------------------------------------------


@pytest.fixture
def lf_env(tmp_path):
    """A hermetic lf environment (socket dir, data dir, home, config)."""
    env = LfEnv(tmp_path)
    yield env
    env.shutdown()


@pytest.fixture
def workdir(tmp_path):
    """A scratch working directory under tmp_path."""
    d = tmp_path / "work"
    d.mkdir()
    return d


def make_tree(base, spec):
    """Create files/dirs from a spec dict mapping relative paths to content.

    A trailing ``/`` in a key creates a directory; ``@`` prefix marks a
    symlink whose value is the link target; ``None`` content creates an
    empty file.
    """
    for rel, content in spec.items():
        if rel.endswith("/"):
            (base / rel).mkdir(parents=True, exist_ok=True)
        elif rel.startswith("@"):
            (base / rel[1:]).symlink_to(content)
        else:
            p = base / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            if content is None:
                p.touch()
            else:
                p.write_text(content)
    return base
