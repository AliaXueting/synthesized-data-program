"""The ':' setlocal command: per-directory options and their scoping."""

import pytest


def _names(s, count=6, start=15):
    """Names shown in the current-directory pane, top to bottom.

    `start` is the first column of the name field, which sits at a
    different offset when the session runs on a wider terminal.
    """
    return [s.lines()[1 + i][start:start + 15].strip() for i in range(count)]


def test_setlocal_hidden_scoped_to_directory(run_lf):
    """A local hidden option only reveals dotfiles inside that directory."""
    # CATCHES: candidates that apply setlocal options globally; the dotfile
    # must appear in the target directory but not in its parent.
    s = run_lf(files=(".dotfile", "a.txt", "b.txt", "c.txt", "zeta.md"))
    sub = s.cwd / "sub"
    (sub / ".dotsub").write_text("x\n")
    (sub / "zz.dat").write_text("z")
    s.send(":setlocal %s hidden\r" % sub)
    s.wait(quiet=0.4)
    s.send(":cd %s\r" % sub)
    s.wait(quiet=0.5)
    assert _names(s, 3) == [".dotsub", "deep.txt", "zz.dat"]
    assert s.bottom().endswith("1/3")
    assert s.top().endswith("/.dotsub")
    s.send(":cd %s\r" % s.cwd)
    s.wait(quiet=0.5)
    assert _names(s) == ["other", "sub", "a.txt", "b.txt", "c.txt", "zeta.md"]
    assert s.bottom().endswith("2/6")


def test_setlocal_dironly_resolves_dot_to_viewed_dir(run_lf):
    """setlocal '.' applies to the directory currently being viewed."""
    # CATCHES: candidates that resolve '.' to the startup directory instead
    # of the viewed one; the option must land on sub, not on the parent.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[(":cd sub\r", 0.5)], cols=140)
    s.send(":setlocal . dironly\r")
    s.wait_for(lambda t: t.bottom().endswith("0/0"), timeout=4.0)
    assert s.top().endswith("/sub/")
    s.send(":cd %s\r" % s.cwd)
    s.wait_for(lambda t: t.bottom().endswith("2/6"), timeout=4.0)
    assert _names(s, start=26) == ["other", "sub", "a.txt", "b.txt", "c.txt", "zeta.md"]
    assert s.top().endswith(str(s.cwd / "sub"))


def test_setlocal_reverse_reorders_only_that_dir(run_lf):
    """A local reverse flips the target directory and nothing else."""
    # CATCHES: candidates that apply the local sort options globally; the
    # parent listing must keep its natural order after leaving the dir.
    s = run_lf(script=[])
    sub = s.cwd / "sub"
    (sub / ".dotsub").write_text("x\n")
    (sub / "mm.dat").write_text("m")
    (sub / "zz.dat").write_text("123456789")
    s.send(":setlocal %s reverse\r" % sub)
    s.wait(quiet=0.4)
    s.send(":cd %s\r" % sub)
    s.wait(quiet=0.3)
    s.send(":reload\r")
    s.wait(quiet=0.5)
    assert _names(s, 3) == ["zz.dat", "mm.dat", "deep.txt"]
    assert s.bottom().endswith("1/3")
    assert s.top().endswith("/zz.dat")
    s.send(":cd %s\r" % s.cwd)
    s.wait(quiet=0.5)
    assert _names(s) == ["other", "sub", "a.txt", "b.txt", "c.txt", "zeta.md"]


def test_setlocal_sortby_size_ascending(run_lf):
    """A local sortby size orders that directory by ascending size."""
    # CATCHES: candidates that sort sizes descending or that ignore the
    # local sortby override; smallest file first, largest last.
    s = run_lf(script=[])
    sub = s.cwd / "sub"
    (sub / ".dotsub").write_text("x\n")
    (sub / "mm.dat").write_text("m")
    (sub / "zz.dat").write_text("123456789")
    s.send(":setlocal %s sortby size\r" % sub)
    s.wait(quiet=0.4)
    s.send(":cd %s\r" % sub)
    s.wait(quiet=0.3)
    s.send(":reload\r")
    s.wait(quiet=0.5)
    assert _names(s, 3) == ["mm.dat", "deep.txt", "zz.dat"]
    assert s.bottom().endswith("1/3")
    assert s.top().endswith("/mm.dat")


def test_setlocal_info_size(run_lf):
    """A local info option adds the info column in that directory only."""
    # CATCHES: candidates that apply the local info list everywhere; the
    # parent pane must stay without a size column after returning.
    s = run_lf(script=[])
    sub = s.cwd / "sub"
    (sub / "zz.dat").write_text("z")
    s.send(":setlocal %s info size\r" % sub)
    s.wait(quiet=0.4)
    s.send(":cd %s\r" % sub)
    s.wait(quiet=0.5)
    assert s.lines()[1] == "  other         deep.txt             5B  deep"
    assert s.lines()[2] == "  sub           zz.dat               1B"
    s.send(":cd %s\r" % s.cwd)
    s.wait(quiet=0.5)
    assert s.lines()[3] == "                a.txt"


def test_setlocal_unknown_option(run_lf):
    """An unknown local option name reports the same error as ':set'."""
    # CATCHES: candidates that skip validating option names in setlocal
    # and silently store (or mis-apply) the bogus option.
    s = run_lf(script=[])
    s.send(":setlocal %s nosuchopt\r" % (s.cwd / "sub"))
    s.wait(quiet=0.5)
    assert s.bottom().startswith("unknown option: nosuchopt")
    assert s.bottom().endswith("1/6")
