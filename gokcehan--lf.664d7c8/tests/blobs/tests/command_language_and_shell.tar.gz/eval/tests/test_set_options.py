"""The ':' set command: value forms, validation errors and visible effects."""

import pytest


def _names(s, count=6):
    """Names shown in the current-directory pane, top to bottom."""
    return [s.lines()[1 + i][15:30].strip() for i in range(count)]


def test_set_hidden_value_forms(run_lf):
    """hidden accepts the bare, no-, bang and true/false spellings."""
    # CATCHES: candidates that only implement the bare ':set hidden' form;
    # nohidden/!/true/false must all flip the same dotfile visibility.
    s = run_lf(files=(".dotfile", "a.txt", "b.txt", "c.txt", "zeta.md"))
    s.send(":set hidden\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/7")
    s.send(":set nohidden\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")
    s.send(":set hidden!\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/7")
    s.send(":set hidden false\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")
    s.send(":set hidden true\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/7")


@pytest.mark.parametrize("line,expected", [
    (":set nohidden true\r", "nohidden: unexpected value: true"),
    (":set hidden! x\r", "hidden!: unexpected value: x"),
    (":set hidden maybe\r", "hidden: value should be empty, 'true', or 'false'"),
    (":set nosuchoption\r", "unknown option: nosuchoption"),
])
def test_set_argument_errors(run_lf, line, expected):
    """Negated/bang options reject values; unknown names are reported."""
    # CATCHES: candidates that silently ignore the argument after 'no'/'!'
    # forms or that skip validating the option name entirely.
    s = run_lf(script=[(line, 0.5)])
    assert s.bottom().startswith(expected)
    assert s.bottom().endswith("1/6")


@pytest.mark.parametrize("line,expected", [
    (":set borderstyle bogus\r", "borderstyle: value should either be"),
    (":set filtermethod bogus\r", "filtermethod: value should either be 'text'"),
    (":set searchmethod bogus\r",
     "searchmethod: value should either be 'text', 'glob' or 'regex'"),
    (":set selmode bogus\r", "selmode: value should either be 'all' or 'dir'"),
    (":set sizeunits bogus\r",
     "sizeunits: value should either be 'binary' or 'decimal'"),
    (":set sortby bogus\r", "sortby: value should either be 'natural'"),
    (":set terminalcursor bogus\r", "terminalcursor: value should either be"),
])
def test_set_enum_value_errors(run_lf, line, expected):
    """Choice-valued options list their legal values on a bad word."""
    # CATCHES: candidates that accept any word for choice options or that
    # report a generic error instead of enumerating the allowed values.
    s = run_lf(script=[(line, 0.5)])
    assert s.bottom().startswith(expected)


@pytest.mark.parametrize("line,expected", [
    (":set findlen -1\r", "findlen: value should be a non-negative number"),
    (":set findlen x\r", 'findlen: strconv.Atoi: parsing "x": invalid syntax'),
    (":set period -1\r", "period: value should be a non-negative number"),
    (":set period x\r", 'period: strconv.Atoi: parsing "x": invalid syntax'),
    (":set scrolloff -2\r", "scrolloff: value should be a non-negative number"),
    (":set tabstop 0\r", "tabstop: value should be a positive number"),
    (":set ratios 1\r",
     "ratios: should consist of at least two numbers when 'preview' is enabled"),
    (":set ratios 1:0\r", "ratios: value should be a positive number"),
    (":set ratios a\r", 'ratios: strconv.Atoi: parsing "a": invalid syntax'),
])
def test_set_numeric_option_errors(run_lf, line, expected):
    """Numeric options reject negatives, zeros and non-numbers."""
    # CATCHES: candidates that clamp bad numbers silently or that parse
    # with a different error than Go's strconv (the message must match).
    s = run_lf(script=[(line, 0.5)])
    assert s.bottom().startswith(expected)


def test_set_ratios_needs_two_panes_for_preview(run_lf):
    """A single ratio is legal only while preview is disabled."""
    # CATCHES: candidates that validate 'ratios' without consulting the
    # current 'preview' state, or that re-enable 'preview' unchecked.
    s = run_lf(script=[(":set nopreview\r", 0.4), (":set ratios 1\r", 0.4)])
    assert s.bottom().endswith("1/6")
    s.send(":set preview\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("preview: 'ratios' should consist of")


def test_set_dironly_and_dirfirst(run_lf):
    """dironly keeps only directories; nodirfirst interleaves by name."""
    # CATCHES: candidates that treat dironly as a dotfile filter or that
    # keep floating directories to the top after ':set nodirfirst'.
    s = run_lf(script=[(":set dironly\r", 0.5)])
    assert s.bottom().endswith("1/2")
    assert _names(s, 2) == ["other", "sub"]
    s.send(":set nodironly\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")
    s.send(":set nodirfirst\r")
    s.wait(quiet=0.5)
    assert _names(s) == ["a.txt", "b.txt", "c.txt", "other", "sub", "zeta.md"]
    assert s.bottom().endswith("4/6")
    s.send(":set dirfirst\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")


def test_set_reverse(run_lf):
    """:set reverse flips the listing but keeps the cursor on its file."""
    # CATCHES: candidates that only reverse the visible rows or that move
    # the cursor to the mirrored index instead of keeping it on the file.
    s = run_lf(script=[(":set reverse\r", 0.5)])
    assert _names(s) == ["sub", "other", "zeta.md", "c.txt", "b.txt", "a.txt"]
    assert s.bottom().endswith("2/6")
    s.send(":set noreverse\r")
    s.wait(quiet=0.5)
    assert _names(s) == ["other", "sub", "a.txt", "b.txt", "c.txt", "zeta.md"]
    assert s.bottom().endswith("1/6")


def test_set_number_and_relativenumber(run_lf):
    """number draws absolute indexes; relativenumber draws offsets."""
    # CATCHES: candidates that number view rows instead of directory
    # entries, or that keep absolute numbers after ':set nonumber'.
    s = run_lf(script=[(":set number\r", 0.5)])
    assert s.lines()[1] == "  cwd         1  other                    empty"
    assert s.lines()[2] == "              2  sub"
    assert s.lines()[3] == "              3  a.txt"
    s.send(":set relativenumber\r")
    s.wait(quiet=0.5)
    assert s.lines()[1] == "  cwd         1   other                   empty"
    assert s.lines()[2] == "               1  sub"
    assert s.lines()[3] == "               2  a.txt"
    s.send(":set nonumber\r")
    s.wait(quiet=0.5)
    assert s.lines()[1] == "  cwd         0  other                    empty"
    assert s.lines()[2] == "              1  sub"
    s.send(":set norelativenumber\r")
    s.wait(quiet=0.5)
    assert s.lines()[2] == "                sub"
    assert s.lines()[3] == "                a.txt"


def test_set_drawbox(run_lf):
    """drawbox redraws the panes with box-drawing borders."""
    # CATCHES: candidates that ignore drawbox or pick different border
    # glyphs; the border must join pane edges with 'w' and end in 'k'.
    s = run_lf(script=[(":set drawbox\r", 0.5)])
    assert s.lines()[1] == ("lqqqqqqqqqqqqqwqqqqqqqqqqqqqqqqqqqqqqqqq"
                            "wqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk")
    assert s.lines()[2] == ("x  cwd        x  other                  "
                            "x empty                                x")
    s.send(":set nodrawbox\r")
    s.wait(quiet=0.5)
    assert s.lines()[1] == "  cwd           other                     empty"


def test_set_promptfmt(run_lf):
    """promptfmt replaces the whole header line."""
    # CATCHES: candidates that append the format string to the default
    # prompt or that keep expanding the default escape sequences.
    s = run_lf(script=[(":set promptfmt PROMPT-\r", 0.5)])
    assert s.top() == "PROMPT-"


def test_set_info_size_and_errors(run_lf):
    """info size adds a size column and rejects unknown keywords."""
    # CATCHES: candidates that omit the '-' placeholder for directories
    # or that accept arbitrary info tokens without complaining.
    s = run_lf(script=[(":set info size\r", 0.5)])
    assert s.lines()[1] == "  cwd           other                 -   empty"
    assert s.lines()[3] == "                a.txt                8B"
    s.send(":set info bogus\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("info: should consist of 'size', 'time'")
    s.send(":set info\r")
    s.wait(quiet=0.5)
    assert s.lines()[3] == "                a.txt"


def test_set_hiddenfiles(run_lf):
    """hiddenfiles replaces the hide patterns; bad patterns error out."""
    # CATCHES: candidates that add to the default '.*' pattern instead of
    # replacing it, or that accept an uncompiled glob silently.
    s = run_lf(script=[(":set hiddenfiles *.txt\r", 0.5)])
    assert _names(s, 3) == ["other", "sub", "zeta.md"]
    assert s.bottom().endswith("1/3")
    s.send(":set hiddenfiles [\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("hiddenfiles: syntax error in pattern")
    s.send(":set hiddenfiles a:\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("hiddenfiles: glob should be non-empty")


def test_set_preserve_invalid(run_lf):
    """:set preserve rejects words outside mode/timestamps."""
    # CATCHES: candidates that accept any colon-separated word for the
    # preserve list; only 'mode' and 'timestamps' are legal.
    s = run_lf(script=[(":set preserve bogus\r", 0.5)])
    assert s.bottom().startswith(
        "preserve: should consist of 'mode' or 'timestamps' separated with colon")


def test_set_deprecated_options(run_lf):
    """rulerfmt and statfmt are deprecated in favor of rulerfile."""
    # CATCHES: candidates that still honor the old option names silently
    # instead of printing the deprecation notice on the message line.
    s = run_lf(script=[(":set rulerfmt x\r", 0.5)])
    assert s.bottom().startswith("option 'rulerfmt' is deprecated and will be"
                                 " replaced")
    s.send(":set statfmt x\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("option 'statfmt' is deprecated and will be"
                                 " replaced")


def test_set_user_option_exports_env(run_lf):
    """A user-defined option becomes an lf_<name> environment variable."""
    # CATCHES: candidates that store user options without exporting them
    # to child processes; the shell must see $lf_user_greet.
    s = run_lf(script=[(":set user_greet hello\r", 0.4)])
    s.send("$printf 'GREET=<%s>' \"$lf_user_greet\"\r")
    s.wait(quiet=0.8)
    assert "GREET=<hello>" in s.raw_text()


def test_set_sortby_size_and_ext(run_lf):
    """sortby size orders ascending; sortby ext groups by extension."""
    # CATCHES: candidates that sort sizes descending or that sort by the
    # whole name under 'ext' instead of the extension alone.
    s = run_lf(files=("big.bin", "tiny", "a.txt", "b.txt", "c.txt", "zeta.md"))
    (s.cwd / "big.bin").write_text("x" * 1000)
    (s.cwd / "tiny").write_text("x")
    s.send(":reload\r")
    s.wait(quiet=0.5)
    assert _names(s, 7) == ["other", "sub", "a.txt", "b.txt", "big.bin",
                            "c.txt", "tiny"]
    s.send(":set sortby size\r")
    s.wait(quiet=0.5)
    assert _names(s, 7) == ["other", "sub", "tiny", "a.txt", "b.txt",
                            "c.txt", "zeta.md"]
    assert s.bottom().endswith("1/8")
    s.send(":set sortby ext\r")
    s.wait(quiet=0.5)
    assert _names(s, 7) == ["other", "sub", "tiny", "big.bin", "zeta.md",
                            "a.txt", "b.txt"]


def test_set_sortby_custom_uses_addcustominfo(run_lf):
    """sortby custom orders files by their addcustominfo value."""
    # CATCHES: candidates that ignore per-file custom info when sorting
    # or that sort it descending; unset files come first, then ascending.
    s = run_lf(script=[(":set sortby custom\r", 0.3),
                       (":addcustominfo c.txt 1\r", 0.2),
                       (":addcustominfo a.txt 3\r", 0.2),
                       (":addcustominfo b.txt 2\r", 0.5)])
    assert _names(s) == ["other", "sub", "zeta.md", "c.txt", "b.txt", "a.txt"]
    assert s.bottom().endswith("1/6")


def test_set_smartcase_and_ignorecase_differential(run_lf):
    """smartcase makes uppercase patterns case-sensitive; ignorecase off
    makes every pattern case-sensitive."""
    # CATCHES: candidates that always search case-insensitively (the
    # uppercase /BETA must miss by default) or that ignore ignorecase.
    s = run_lf(files=("Alpha.txt", "beta.txt", "GAMMA.txt"))
    s.send("/alpha\r")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("3/5")
    s.send("/BETA\r")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("3/5")
    s.close()

    s = run_lf(files=("Alpha.txt", "beta.txt", "GAMMA.txt"),
               cfg="set nosmartcase")
    s.send("/BETA\r")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("4/5")
    s.close()

    s = run_lf(files=("Alpha.txt", "beta.txt", "GAMMA.txt"),
               cfg="set noignorecase")
    s.send("/alpha\r")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("1/5")


def test_set_wrapscroll_wraps_cursor(run_lf):
    """wrapscroll makes j/k wrap around at the list ends."""
    # CATCHES: candidates that stop at the last/first entry despite the
    # option, or that wrap the view without moving the cursor.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[("G", 0.3), ("j", 0.5)], cfg="set wrapscroll", cols=140)
    assert s.bottom().endswith("1/6")
    s.send("gg")
    s.wait(quiet=0.3)
    s.send("k")
    s.wait_for(lambda t: t.bottom().endswith("6/6"), timeout=4.0)
    assert s.top().endswith(str(s.cwd / "zeta.md"))
