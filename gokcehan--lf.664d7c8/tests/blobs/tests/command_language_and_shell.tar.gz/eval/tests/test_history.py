"""Command history: the persistent file under $XDG_DATA_HOME/lf and the
cmd-history-prev/next navigation inside the prompts."""

import pytest


def test_no_history_without_commands(run_lf):
    """Quitting without running commands never creates the history file."""
    # CATCHES: candidates that create an empty history file on startup or
    # that record plain navigation keys as history entries; the second
    # session proves the file would have been written for a real command.
    s = run_lf(script=[("jj", 0.3), ("/a\r", 0.3), (" ", 0.3), ("q", 0.5)])
    assert s.exit_code() == 0
    assert not (s.data_dir / "history").exists()
    s.close()

    s = run_lf(script=[("jj", 0.3), (":echo marked\r", 0.4), ("q", 0.5)])
    assert s.exit_code() == 0
    assert (s.data_dir / "history").read_text() == ":echo marked\n"


def test_history_records_commands(run_lf):
    """Executed ':' commands are appended to the history file on quit."""
    # CATCHES: candidates that never write history, or write the command
    # without its ':' prefix.
    s = run_lf(script=[(":echo one\r", 0.4), ("q", 0.5)])
    assert s.exit_code() == 0
    assert (s.data_dir / "history").read_text() == ":echo one\n"


def test_history_merges_with_existing_file(run_lf):
    """New entries are appended after the pre-existing ones, in order."""
    # CATCHES: candidates that overwrite the seeded file instead of loading
    # and extending it, or that reverse the entry order.
    s = run_lf(script=[(":echo fresh\r", 0.4), ("q", 0.5)],
               seed_history=[":echo seeded", "$ echo seededsh"])
    assert (s.data_dir / "history").read_text() == (
        ":echo seeded\n$ echo seededsh\n:echo fresh\n")


def test_history_skips_unprefixed_lines(run_lf):
    """Lines without a command prefix are dropped when reloading history."""
    # CATCHES: candidates that merge arbitrary seeded lines back verbatim;
    # only lines starting with a prompt character are kept.
    s = run_lf(script=[(":echo ok\r", 0.4), ("q", 0.5)],
               seed_history=["garbage line", ":x"])
    assert (s.data_dir / "history").read_text() == ":x\n:echo ok\n"


def test_history_is_capped_at_1000(run_lf):
    """The history file keeps at most the newest 1000 entries."""
    # CATCHES: candidates without a cap (1006 lines) or that trim the wrong
    # end (the newest entries must survive).
    seed = [":echo n%03d" % i for i in range(1005)]
    s = run_lf(script=[(":echo fresh\r", 0.4), ("q", 0.5)], seed_history=seed)
    lines = (s.data_dir / "history").read_text().splitlines()
    assert len(lines) == 1000
    assert lines[0] == ":echo n006"
    assert lines[-1] == ":echo fresh"


def test_nohistory_option_disables_recording(run_lf):
    """set nohistory leaves the history file untouched."""
    # CATCHES: candidates that ignore the option and append anyway; the
    # first session (without the option) shows what appending would look
    # like, so a candidate that never writes history at all also fails.
    s = run_lf(script=[(":echo fresh\r", 0.4), ("q", 0.5)],
               seed_history=[":echo seeded"])
    assert (s.data_dir / "history").read_text() == ":echo seeded\n:echo fresh\n"
    s.close()

    s = run_lf(script=[(":echo fresh\r", 0.4), ("q", 0.5)],
               cfg="set nohistory", seed_history=[":echo seeded"])
    assert (s.data_dir / "history").read_text() == ":echo seeded\n"


def test_history_records_all_shell_prefixes(run_lf):
    """'$', '!', '&' and '%' command lines all land in the history file."""
    # CATCHES: candidates that only record ':' commands; the '!' entry also
    # proves the wait-for-keypress does not swallow the following keys.
    s = run_lf(script=[("$ echo d\r", 0.4), ("! echo w\r", 0.6), ("x", 0.4),
                       ("& echo a\r", 0.4), ("q", 0.5)])
    assert (s.data_dir / "history").read_text() == "$ echo d\n! echo w\n& echo a\n"
    s.close()

    s = run_lf(script=[("% echo p\r", 0.4), ("<c-c>", 0.5), ("q", 0.5)])
    assert (s.data_dir / "history").read_text() == "% echo p\n"


def test_cmd_history_prev_and_next(run_lf):
    """Up/Down walk the history; Down past the newest restores the input."""
    # CATCHES: candidates whose history navigation is off by one (first Up
    # must show the newest entry) or whose Down skips straight to the empty
    # line instead of stepping through the newer entries first.
    s = run_lf(script=[(":echo one\r", 0.4), (":echo two\r", 0.4)])
    s.send(":")
    s.wait(quiet=0.3)
    s.send("<up>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":echo two"
    s.send("<up>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":echo one"
    s.send("<down>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":echo two"
    s.send("<down>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":"
    s.send("<down>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":"


def test_cmd_history_filters_by_prefix(run_lf):
    """History navigation only offers entries sharing the prompt character."""
    # CATCHES: candidates that ignore the current prefix; the '$' entry must
    # be skipped when navigating from the ':' prompt.
    s = run_lf(script=[(":echo one\r", 0.4), ("$ echo two\r", 0.5), (":ec", 0.4)])
    s.send("<up>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":echo one"


def test_cmd_history_empty(run_lf):
    """Up with no history at all keeps the empty prompt."""
    # CATCHES: candidates that crash or insert something when the history
    # list is empty.
    s = run_lf(script=[(":", 0.3), ("<up>", 0.5)])
    assert s.bottom() == ":"
