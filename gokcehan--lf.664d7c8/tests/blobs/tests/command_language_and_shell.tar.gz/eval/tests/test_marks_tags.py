"""Mark bookmarks (m/'/" keys), file tags, and :sync reloading shared state."""

import pytest


def test_mark_save_load_roundtrip(run_lf):
    """A saved mark stores the current directory and mark-load cds back to it."""
    # CATCHES: candidates that store the cursor file instead of the directory,
    # or that never persist marks; loading must land back in the saved dir.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[("m", 0.4), ("z", 0.5)], cols=140)
    assert (s.data_dir / "marks").read_text() == "z:%s\n" % s.cwd
    s.send("h")
    s.wait(quiet=0.6)
    assert s.top().endswith(str(s.cwd))
    assert s.bottom().endswith("1/1")
    s.send("'")
    s.wait(quiet=0.4)
    s.send("z")
    s.wait(quiet=0.6)
    assert s.top().endswith(str(s.cwd / "other"))
    assert s.bottom().endswith("1/6")


def test_mark_load_menu_and_unknown_mark(run_lf):
    """mark-load lists saved marks with a header; unknown marks error out."""
    # CATCHES: candidates without the mark menu (header 'mark    path' plus
    # one row per mark) or that silently ignore an unknown mark letter.
    # A wide terminal keeps the mark's absolute path on one menu row.
    s = run_lf(script=[("m", 0.4), ("z", 0.5)], cols=140)
    s.send("'")
    s.wait(quiet=0.5)
    assert s.lines()[21] == "mark    path"
    assert s.menu() == "z       %s" % s.cwd
    s.send("q")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("mark-load: no such mark")
    assert s.bottom().endswith("1/6")


def test_mark_remove(run_lf):
    """mark-remove deletes the mark and empties the persistent marks file."""
    # CATCHES: candidates that only remove the mark in memory; the file must
    # be rewritten without the entry and loading it afterwards must fail.
    s = run_lf(script=[("m", 0.4), ("z", 0.5)])
    assert (s.data_dir / "marks").read_text() == "z:%s\n" % s.cwd
    s.send('"')
    s.wait(quiet=0.4)
    s.send("z")
    s.wait(quiet=0.5)
    assert (s.data_dir / "marks").read_text() == ""
    s.send("'")
    s.wait(quiet=0.4)
    s.send("z")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("mark-load: no such mark")


def test_tag_and_tag_toggle(run_lf):
    """:tag labels the current file; t toggles a tag on and off again."""
    # CATCHES: candidates that do not draw the tag character in front of the
    # name, that never write the tags file, or whose toggle only sets tags.
    s = run_lf(script=[("jj", 0.4)])
    s.send(":tag x\r")
    s.wait(quiet=0.6)
    assert (s.data_dir / "tags").read_text() == "%s:x\n" % (s.cwd / "a.txt")
    assert s.lines()[3] == "               xa.txt"
    s.send("t")
    s.wait(quiet=0.6)
    assert (s.data_dir / "tags").read_text() == ""
    assert s.lines()[3] == "                a.txt"
    s.send("t")
    s.wait(quiet=0.6)
    assert (s.data_dir / "tags").read_text() == "%s:*\n" % (s.cwd / "a.txt")
    assert s.lines()[3] == "               *a.txt"


def test_sync_reloads_marks_and_clipboard(run_lf):
    """:sync re-reads the marks and clipboard files from $LF_DATA_HOME."""
    # CATCHES: candidates whose sync only refreshes directory listings; a
    # mark and a clipboard written behind lf's back must both become active.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[(":sync\r", 0.6)], cols=140)
    # seed both files after startup, then sync again
    (s.data_dir / "marks").write_text("q:%s\n" % (s.cwd / "sub"))
    (s.data_dir / "files").write_text("copy\n%s\n" % (s.cwd / "a.txt"))
    s.send(":sync\r")
    s.wait(quiet=0.6)
    s.send(":cd sub\r")
    s.wait(quiet=0.5)
    s.send(":paste\r")
    s.wait(quiet=0.9)
    assert s.bottom().startswith("Copied successfully")
    assert (s.cwd / "sub" / "a.txt").exists()
    s.send("h")
    s.wait(quiet=0.5)
    s.send("'")
    s.wait(quiet=0.4)
    s.send("q")
    s.wait(quiet=0.6)
    assert s.top().endswith(str(s.cwd / "sub" / "deep.txt"))
    # the pasted a.txt stays selected, so the ruler shows 1 selection, 2/2
    assert s.bottom().endswith("2/2")
