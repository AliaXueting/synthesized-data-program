"""Shell prefixes ($ ! % &), the shell/shellflag/shellopts/ifs options,
and the lf/f/fs/fx/fv variables exported to shell commands."""

import pytest


def test_dollar_success_is_silent(run_lf):
    """A succeeding '$' command leaves the stat line untouched."""
    # CATCHES: candidates that report success (or failure) for every shell
    # command instead of only when the exit status is non-zero.
    s = run_lf(script=[("$ true\r", 0.5)])
    assert s.bottom().endswith("1/6")
    assert not s.bottom().startswith("running shell")


def test_dollar_failure_reports_status(run_lf):
    """A failing '$' command reports the exit status on the message line."""
    # CATCHES: candidates that swallow the exit status of synchronous shell
    # commands or phrase the error differently.
    s = run_lf(script=[("$ exit 3\r", 0.6)])
    assert s.bottom().startswith("running shell: exit status 3")
    assert s.bottom().endswith("1/6")


def test_dollar_output_reaches_terminal(run_lf):
    """Output of a '$' command is written straight to the terminal."""
    # CATCHES: candidates that capture or discard stdout of shell commands;
    # the marker must appear in the raw terminal stream.
    s = run_lf(script=[("$ echo SHELL-OUTPUT-MARKER\r", 0.8)])
    assert "SHELL-OUTPUT-MARKER" in s.raw_text()


def test_wait_prefix_pauses_for_keypress(run_lf):
    """A '!' command shows output plus a wait message until a key arrives."""
    # CATCHES: candidates that run '!' without pausing (the UI would redraw
    # over the shell output immediately), or that never print the wait
    # message, or that do not resume the UI after the keypress.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[("! echo WAITING-MARKER-OUT\r", 1.0)], cols=140)
    assert "WAITING-MARKER-OUT" in s.raw_text()
    # while paused the screen still shows the shell output, not the UI
    assert s.top() == "WAITING-MARKER-OUT"
    assert any(l.startswith("Press any key to continue") for l in s.lines())
    s.send("x")
    s.wait(quiet=0.6)
    # the keypress resumes the UI: header and stat line are back
    assert s.top().endswith(str(s.cwd / "other"))
    assert s.bottom().endswith("1/6")


def test_wait_message_is_configurable(run_lf):
    """set waitmsg replaces the text shown while a '!' command pauses."""
    # CATCHES: candidates that hardcode the wait message and ignore the
    # waitmsg option.
    s = run_lf(script=[("! true\r", 0.7)], cfg="set waitmsg 'PRESS ANY KEY'")
    assert s.top() == "PRESS ANY KEY"


def test_async_output_is_discarded(run_lf):
    """An '&' command runs in the background and its output never shows."""
    # CATCHES: candidates that wire async stdout to the terminal; the marker
    # must be absent from the raw stream even after waiting.
    s = run_lf(script=[("& sh -c 'echo ASYNC-DISCARDED-MARKER'\r", 0.9)])
    assert "ASYNC-DISCARDED-MARKER" not in s.raw_text()
    assert s.bottom().endswith("1/6")


def test_pipe_prefix_reads_and_echoes(run_lf):
    """A '%' command pipes keystrokes in and shows the output inline."""
    # CATCHES: candidates that run '%' like '$' (no '>' prompt, no echo of
    # the typed input on the bottom row).
    s = run_lf(script=[("% cat\r", 0.5), ("hello\r", 0.6)])
    assert s.bottom() == ">hello"


def test_pipe_interrupt_message(run_lf):
    """Ctrl-C while a pipe command runs reports 'process interrupt'."""
    # CATCHES: candidates that cannot interrupt a running pipe command or
    # that leave the '>' prompt up after the interrupt.
    s = run_lf(script=[("% cat\r", 0.4), ("hello\r", 0.4), ("<c-c>", 0.6)])
    assert s.bottom().startswith("process interrupt")
    assert s.bottom().endswith("1/6")


@pytest.mark.parametrize(
    "cmd,prefix",
    [
        (":shell\r", "$"),
        (":shell-pipe\r", "%"),
        (":shell-wait\r", "!"),
        (":shell-async\r", "&"),
    ],
)
def test_shell_command_prompts(run_lf, cmd, prefix):
    """The shell commands open the prompt matching their prefix character."""
    # CATCHES: candidates that mix up which prompt each shell command opens
    # (wait must show '!', async must show '&', and so on).
    s = run_lf(script=[(cmd, 0.4)])
    assert s.bottom() == prefix


def test_shell_option_builds_argv(run_lf):
    """set shell changes the interpreter; args follow a '--' terminator."""
    # CATCHES: candidates that run the configured shell without the flag,
    # the '--' terminator, or that pass the command in another position.
    s = run_lf(script=[("$", 0.3), ("hello-verification-marker\r", 0.9)],
               cfg="set shell /bin/echo")
    assert "-c hello-verification-marker --" in s.raw_text()


def test_shellflag_option(run_lf):
    """set shellflag replaces the '-c' flag passed to the shell."""
    # CATCHES: candidates that ignore shellflag and always pass '-c'.
    s = run_lf(script=[("$", 0.3), ("hello-verification-marker\r", 0.9)],
               cfg="set shell /bin/echo\nset shellflag -x")
    assert "-x hello-verification-marker --" in s.raw_text()


def test_shellopts_option(run_lf):
    """set shellopts inserts extra arguments before the shell flag."""
    # CATCHES: candidates that append shellopts after the command string
    # instead of in front of the flag.
    s = run_lf(script=[("$", 0.3), ("hello-verification-marker\r", 0.9)],
               cfg='set shell /bin/echo\nset shellopts "-a -b"')
    assert "-a -b -c hello-verification-marker --" in s.raw_text()


def test_ifs_option_prepends_assignment(run_lf):
    """set ifs prefixes the command with an IFS assignment."""
    # CATCHES: candidates that export IFS as an environment variable rather
    # than prefixing the assignment to the command string.
    s = run_lf(script=[("$", 0.3), ("hello-verification-marker\r", 0.9)],
               cfg="set shell /bin/echo\nset ifs ','")
    assert "-c IFS=','; hello-verification-marker --" in s.raw_text()


def test_exported_selection_variables(run_lf):
    """$fs/$fx export selections; $f the current file; $fv the visual range."""
    # CATCHES: candidates that export nothing (empty output), only the
    # current file, or that join multi-file values with something other
    # than newlines.
    # one session for the selection-less cases: cursor starts on 'other'
    # (dirfirst) and no selection is ever made
    s = run_lf(script=[("$", 0.25), ('echo "NOSELFS=[$fs]FS-END"\r', 0.45),
                       ("$", 0.25), ('echo "NOSELFX=[$fx]FX-END"\r', 0.45),
                       ("3j", 0.2), ("$", 0.25), ('echo "CURF=[$f]"\r', 0.45)])
    assert "NOSELFS=[]FS-END" in s.raw_text()
    assert "NOSELFX=[%s]FX-END" % (s.cwd / "other") in s.raw_text()
    assert "CURF=[%s]" % (s.cwd / "b.txt") in s.raw_text()
    s.close()

    # selections first, then 'u' clears them, 'gg' returns to the top and the
    # visual range can be exported in the same session
    s = run_lf(script=[(" ", 0.25), (" ", 0.25), ("$", 0.25),
                       ('echo "TWOSEL=[$fs]TWO-END"\r', 0.5),
                       ("u", 0.3), ("gg", 0.3), ("V", 0.2), ("j", 0.2), ("$", 0.25),
                       ('echo "VIS=[$fv]VIS-END"\r', 0.5)])
    flat = s.raw_text().replace("\r\n", "\n")
    assert "TWOSEL=[%s\n%s]TWO-END" % (s.cwd / "other", s.cwd / "sub") in flat
    assert "VIS=[%s\n%s]VIS-END" % (s.cwd / "other", s.cwd / "sub") in flat
