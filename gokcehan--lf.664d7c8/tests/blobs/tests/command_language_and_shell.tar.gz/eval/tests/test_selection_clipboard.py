"""Selection commands, visual mode, and the copy/cut/paste clipboard."""

import pytest


def test_space_toggles_selection(run_lf):
    """The space key toggles the selection of the entry under the cursor."""
    # CATCHES: candidates that drop the selection counter from the ruler or
    # fail to advance the cursor while toggling (position must reach 3/6).
    s = run_lf(script=[(" ", 0.3), (" ", 0.4)])
    assert s.bottom().endswith("2   3/6")


def test_invert_and_unselect(run_lf):
    """:invert selects every entry, :unselect clears all selections."""
    # CATCHES: candidates that invert only the current entry or that leave
    # the selection counter behind after :unselect.
    s = run_lf(script=[(":invert\r", 0.4)])
    assert s.bottom().endswith("6   1/6")
    s.send(":unselect\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")


def test_toggle_with_file_arguments(run_lf):
    """:toggle re-toggles each named file without moving the cursor."""
    # CATCHES: candidates that treat :toggle arguments as a plain select
    # (both files would stay selected) or that move the cursor; toggling
    # a.txt again must drop it while c.txt becomes selected.
    s = run_lf(script=[(":toggle a.txt\r", 0.4)])
    assert s.bottom().endswith("1   1/6")
    s.send(":toggle a.txt c.txt\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1   1/6")
    s.send(":copy\r")
    s.wait(quiet=0.5)
    assert (s.data_dir / "files").read_text() == "copy\n%s\n" % (s.cwd / "c.txt")


def test_glob_select_and_unselect(run_lf):
    """:glob-select/:glob-unselect toggle selections matching a pattern."""
    # CATCHES: candidates that match the pattern against the full path (the
    # dirs would match nothing) or that report success on a missed pattern.
    s = run_lf(script=[(":glob-select *.txt\r", 0.4)])
    assert s.bottom().endswith("3   1/6")
    s.send(":glob-unselect *.txt\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")
    s.send(":glob-select *.zzz\r")
    s.wait(quiet=0.4)
    assert s.bottom().startswith("glob-select: pattern not found: *.zzz")


def test_select_argument_requirements(run_lf):
    """:select requires exactly one argument that must exist."""
    # CATCHES: candidates that accept zero or multiple arguments, or that
    # swallow the lstat failure for a file that does not exist.
    s = run_lf(script=[(":select\r", 0.4)])
    assert s.bottom().startswith("select: requires an argument")
    s.send(":select a.txt b.txt\r")
    s.wait(quiet=0.4)
    assert s.bottom().startswith("select: requires an argument")
    s.send(":select nope.txt\r")
    s.wait(quiet=0.4)
    assert s.bottom().startswith("select: lstat nope.txt: no such file or directory")


def test_select_moves_cursor_without_selecting(run_lf):
    """:select with a path only moves the cursor onto that entry."""
    # CATCHES: candidates that also add the entry to the selection (the
    # ruler must show no selection counter) or that do not move at all.
    s = run_lf(script=[(":select sub\r", 0.5)])
    assert s.bottom().endswith("2/6")
    s.send(":select %s\r" % (s.cwd / "zeta.md"))
    s.wait(quiet=0.5)
    assert s.bottom().endswith("6/6")


def test_visual_mode_selections(run_lf):
    """Visual mode selects from the anchor to the cursor position."""
    # CATCHES: candidates whose visual mode selects only single entries, or
    # whose second V press in visual mode restarts the range instead of
    # accepting it (the selections must persist after the mode ends).
    s = run_lf(script=[("V", 0.4)])
    assert s.bottom().endswith("1   1/6")
    s.send("j")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("2   2/6")
    s.send("<esc>")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("2/6")
    s.send("V")
    s.wait(quiet=0.3)
    s.send("j")
    s.wait(quiet=0.3)
    s.send("V")
    s.wait(quiet=0.4)
    # V in visual mode accepts the range: 2 persistent selections, mode off
    assert s.bottom().endswith("2   3/6")
    s.send("j")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("2   4/6")


def test_visual_accept_unselect_discard(run_lf):
    """:visual-accept keeps the range; -unselect/-discard drop it."""
    # CATCHES: candidates that treat the three visual commands as aliases;
    # only :visual-accept may leave the selection counter in the ruler.
    s = run_lf(script=[("V", 0.2), ("j", 0.2), ("k", 0.2), (":visual-accept\r", 0.4)])
    assert s.bottom().endswith("1   1/6")
    s.close()
    s2 = run_lf(script=[("V", 0.2), ("j", 0.2), (":visual-unselect\r", 0.4)])
    assert s2.bottom().endswith("2/6")
    s2.close()
    s3 = run_lf(script=[("V", 0.2), ("j", 0.2), (":visual-discard\r", 0.4)])
    assert s3.bottom().endswith("2/6")


def test_visual_change_flips_anchor(run_lf):
    """:visual-change moves the visual anchor to the other range end."""
    # CATCHES: candidates where 'o' does nothing: the selection count stays 2
    # but the cursor must move back to the first entry (2   1/6).
    s = run_lf(script=[("V", 0.2), ("j", 0.2), ("o", 0.2), ("k", 0.4)])
    assert s.bottom().endswith("2   1/6")


def test_copy_cut_clear_write_files_file(run_lf):
    """:copy/:cut/:clear maintain the persistent file list under $XDG_DATA_HOME."""
    # CATCHES: candidates that keep the clipboard only in memory (the files
    # file is never written) or forget the copy/move mode header line.
    s = run_lf(script=[(":copy\r", 0.5)])
    assert (s.data_dir / "files").read_text() == "copy\n%s\n" % (s.cwd / "other")
    assert s.bottom().endswith("1   1/6")
    s.send(":cut\r")
    s.wait(quiet=0.5)
    assert (s.data_dir / "files").read_text() == "move\n%s\n" % (s.cwd / "other")
    s.send(":clear\r")
    s.wait(quiet=0.5)
    assert (s.data_dir / "files").read_text() == "move\n"


def test_copy_multiple_selections(run_lf):
    """Copying several selections records them in selection order."""
    # CATCHES: candidates that copy only the current entry or reorder the
    # paths in the persistent file list.
    s = run_lf(script=[(" ", 0.3), (" ", 0.3), (":copy\r", 0.5)])
    assert (s.data_dir / "files").read_text() == "copy\n%s\n%s\n" % (
        s.cwd / "other", s.cwd / "sub")
    assert s.bottom().endswith("2   3/6")


def test_paste_into_directory(run_lf):
    """Pasting a copied directory reports success and copies it."""
    # CATCHES: candidates whose paste is a no-op or reports errors: the
    # message and the 2/2 listing of sub must both appear.
    s = run_lf(script=[(":copy\r", 0.4), (":cd sub\r", 0.4), (":paste\r", 0.8)])
    assert s.bottom().startswith("Copied successfully")
    assert s.bottom().endswith("1   2/2")
    assert (s.cwd / "sub" / "other").is_dir()


def test_paste_empty_clipboard_error(run_lf):
    """:paste with an empty clipboard reports an error."""
    # CATCHES: candidates that silently ignore an empty clipboard instead of
    # showing the exact recorded message.
    s = run_lf(script=[(":paste\r", 0.4)])
    assert s.bottom().startswith("paste: no files in clipboard")
    assert s.bottom().endswith("1/6")
