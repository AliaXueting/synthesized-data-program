"""Completion engine paths of complete.go not exercised elsewhere: file
completion with directory prefixes, symlinks and case folding, the per-option
value tables (choice, list and path-valued options), setlocal names and
values, PATH-wide executable completion, per-prompt escaping and the search
prompt matcher."""

import os

import pytest


def _nested(root):
    """Add a 'nested' directory inside the default 'sub' directory."""
    (root / "tree" / "cwd" / "sub" / "nested").mkdir(exist_ok=True)
    return ""


def _symlink(root):
    """Add a symlink 'link' pointing at the directory 'sub'."""
    os.symlink("sub", root / "tree" / "cwd" / "link")
    return ""


def test_file_completion_with_directory_prefix(run_lf):
    """Completing 'sub/de' yields the file inside that subdirectory."""
    # CATCHES: candidates that complete only basenames of the working
    # directory instead of honoring the typed 'sub/' path prefix.
    s = run_lf(script=[(":toggle sub/de", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":toggle sub/deep.txt"
    assert s.menu() == ""


def test_cd_completion_descends_into_subdirectory(run_lf):
    """':cd sub/<tab>' completes the only directory inside sub/ directly."""
    # CATCHES: candidates that ignore the typed prefix, offer the regular
    # file deep.txt to :cd, or fail to append the trailing separator.
    s = run_lf(script=[(":cd sub/", 0.4), ("<tab>", 0.5)], cfg=_nested)
    assert s.bottom() == ":cd sub/nested/"
    assert s.menu() == ""


def test_cd_completion_prefix_inside_subdirectory(run_lf):
    """A partial name after a directory prefix completes within that directory."""
    # CATCHES: candidates that only match names in the current directory and
    # cannot complete 'ne' to 'nested/' behind the 'sub/' prefix.
    s = run_lf(script=[(":cd sub/ne", 0.4), ("<tab>", 0.5)], cfg=_nested)
    assert s.bottom() == ":cd sub/nested/"
    assert s.menu() == ""


def test_file_completion_matches_case_insensitively(run_lf):
    """A lowercase prefix completes a differently-cased file name."""
    # CATCHES: candidates whose file completion compares prefixes
    # case-sensitively, so 'ze' would not match 'Zebra.txt'.
    s = run_lf(script=[(":toggle ze", 0.4), ("<tab>", 0.5)],
               files=["Zebra.txt", "a.txt"])
    assert s.bottom() == ":toggle Zebra.txt"
    assert s.menu() == ""


def test_common_prefix_keeps_first_match_case(run_lf):
    """The shared prefix of mixed-case matches keeps the first match's case."""
    # CATCHES: candidates that compute the common prefix case-sensitively
    # (empty here) or lowercase it, instead of keeping 'ALPHA' from the
    # first candidate 'ALPHA2.txt'.
    s = run_lf(script=[(":toggle al", 0.4), ("<tab>", 0.5)],
               files=["Alpha.txt", "ALPHA2.txt", "a.txt"])
    assert s.bottom() == ":toggle ALPHA"
    assert s.menu() == "ALPHA2.txt      Alpha.txt"


def test_completion_without_matches_is_a_noop(run_lf):
    """Neither a missing name nor an unreadable directory disturbs the prompt."""
    # CATCHES: candidates that clear the prompt, move the cursor or print an
    # error on the message line when no file matches or the directory in the
    # typed prefix does not exist.
    s = run_lf(script=[(":toggle qq", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":toggle qq"
    assert s.menu() == ""
    s.close()

    s = run_lf(script=[(":toggle nodir/x", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":toggle nodir/x"
    assert s.menu() == ""


def test_symlink_to_directory_completes_with_separator(run_lf):
    """A symlink pointing at a directory is completed with a trailing slash."""
    # CATCHES: candidates that look at the link itself instead of stat-ing
    # its target and therefore complete 'link' without the '/' suffix.
    s = run_lf(script=[(":cd li", 0.4), ("<tab>", 0.5)], cfg=_symlink)
    assert s.bottom() == ":cd link/"
    assert s.menu() == ""
    s.close()

    s = run_lf(script=[(":toggle li", 0.4), ("<tab>", 0.5)], cfg=_symlink)
    assert s.bottom() == ":toggle link/"
    assert s.menu() == ""


def test_completion_escaping_differs_between_prompts(run_lf):
    """A comma is escaped after '$' but left alone after ':'."""
    # CATCHES: candidates that use a single escape table in every prompt;
    # shell completion must backslash the comma, command completion must not.
    s = run_lf(script=[(":toggle we,", 0.4), ("<tab>", 0.5)],
               files=["we,ird.txt", "a.txt"])
    assert s.bottom() == ":toggle we,ird.txt"
    assert s.menu() == ""
    s.close()

    s = run_lf(script=[("$ echo we,", 0.4), ("<tab>", 0.5)],
               files=["we,ird.txt", "a.txt"])
    assert s.bottom() == "$ echo we\\,ird.txt"
    assert s.menu() == ""


def test_preserve_option_list_completion(run_lf):
    """:set preserve completes its colon-joined list values."""
    # CATCHES: candidates that cannot complete list-valued options other
    # than 'info', or that re-offer 'mode' after it was already given.
    s = run_lf(script=[(":set preserve ", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set preserve"
    assert s.menu() == "mode            timestamps"
    s.close()

    # a fully typed segment is completed with a trailing space; a segment
    # that gets extended is not
    s = run_lf(script=[(":set preserve mode", 0.4), ("<tab>", 0.4), ("x", 0.4)])
    assert s.bottom() == ":set preserve mode x"
    s.close()

    s = run_lf(script=[(":set preserve mode:", 0.4), ("<tab>", 0.4), ("x", 0.4)])
    assert s.bottom() == ":set preserve mode:timestampsx"
    assert s.menu() == ""


def test_info_list_tail_completion(run_lf):
    """A partial segment of a colon-joined list value completes."""
    # CATCHES: candidates that can only append whole new segments and cannot
    # complete 'size:t' to 'size:time' inside the info list.
    s = run_lf(script=[(":set info size:t", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set info size:time"
    assert s.menu() == ""


@pytest.mark.parametrize("option,expected", [
    ("filtermethod", "glob    regex   text"),
    ("searchmethod", "glob    regex   text"),
    ("selmode", "all     dir"),
    ("sizeunits", "binary  decimal"),
])
def test_choice_option_value_completion(run_lf, option, expected):
    """Choice-valued options list exactly their allowed values."""
    # CATCHES: candidates with wrong or missing value tables for the choice
    # options, or that list the values in a different order.
    s = run_lf(script=[(f":set {option} ", 0.4), ("<tab>", 0.5)])
    assert s.menu() == expected
    assert s.bottom() == f":set {option}"


def test_terminalcursor_value_completion_spans_rows(run_lf):
    """The seven terminalcursor values fill a two-row menu."""
    # CATCHES: candidates with a shorter cursor-style list, or whose menu
    # grid does not wrap into a second row above the first one.
    s = run_lf(script=[(":set terminalcursor ", 0.4), ("<tab>", 0.5)])
    assert s.lines()[20] == "possible matches"
    assert s.lines()[21] == ("default         block           underline       "
                             "bar             blinkblock")
    assert s.menu() == "blinkunderline  blinkbar"


@pytest.mark.parametrize("typed,expected_bottom", [
    (":set previewer ", None),
    (":set cleaner a", ":set cleaner a.txt"),
    (":set rulerfile ze", ":set rulerfile zeta.md"),
])
def test_path_option_values_complete_files(run_lf, typed, expected_bottom):
    """previewer, cleaner and rulerfile complete file paths as values."""
    # CATCHES: candidates that offer no completion (or boolean values) after
    # options whose value is a command or file path.
    s = run_lf(script=[(typed, 0.4), ("<tab>", 0.5)])
    if expected_bottom is None:
        assert s.menu() == "a.txt   b.txt   c.txt   other/  sub/    zeta.md"
        assert s.bottom() == ":set previewer"
    else:
        assert s.bottom() == expected_bottom
        assert s.menu() == ""


def test_non_list_option_value_has_no_completion(run_lf):
    """Free-form option values offer neither a menu nor a change."""
    # CATCHES: candidates that offer false/true after any option name, or
    # that complete something after numeric or string options like tabstop.
    s = run_lf(script=[(":set tabstop ", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set tabstop"
    assert s.menu() == ""
    s.close()

    s = run_lf(script=[(":set timefmt x", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set timefmt x"
    assert s.menu() == ""


def test_option_value_prefix_completion(run_lf):
    """An ambiguous value prefix keeps only the shared prefix."""
    # CATCHES: candidates that pick one full value instead of the longest
    # common prefix of the matching values.
    s = run_lf(script=[(":set sortby na", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set sortby na"
    assert s.menu() == "name    natural"
    s.close()

    s = run_lf(script=[(":set borderstyle round", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set borderstyle round"
    assert s.menu() == "roundbox        roundoutline"


def test_set_with_extra_arguments_stops_completing(run_lf):
    """:set stops completing once too many arguments are present."""
    # CATCHES: candidates that keep completing option values for the fourth
    # token of a :set command line.
    s = run_lf(script=[(":set hidden true mor", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set hidden true mor"
    assert s.menu() == ""


def test_cmd_definition_body_is_not_completed(run_lf):
    """The body of a command defined with :cmd gets no completion."""
    # CATCHES: candidates that complete command names inside the body of a
    # cmd definition, turning ':ech' into ':echo'.
    s = run_lf(script=[(":cmd foo :ech", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":cmd foo :ech"
    assert s.menu() == ""


@pytest.mark.parametrize("mapper", ["vmap", "cmap", "nmap"])
def test_mode_map_expression_completion(run_lf, mapper):
    """vmap/cmap/nmap complete the mapped expression like plain map."""
    # CATCHES: candidates that complete the expression only for ':map' and
    # not for the mode-specific mapping commands.
    s = run_lf(script=[(f":{mapper} X se", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == f":{mapper} X se"
    assert s.menu() == "set             setfilter       setlocal"


def test_map_expression_lists_all_commands(run_lf):
    """An empty map expression lists the whole command catalog."""
    # CATCHES: candidates whose command word list is missing built-ins (the
    # grid of all command names wraps across the menu rows shown here).
    s = run_lf(script=[(":map X ", 0.4), ("<tab>", 0.6)])
    assert s.lines()[20] == ("visual                  visual-accept           "
                             "visual-change")
    assert s.lines()[21] == ("visual-discard          visual-unselect         "
                             "vmap")
    assert s.menu() == "vmaps"


def test_executable_completion_skips_non_executables(run_lf):
    """Only executable files in $PATH directories are offered."""
    # CATCHES: candidates that offer every file in the PATH directories, so
    # the non-executable zznoexec would appear and completion would stop at
    # the common prefix 'zz' instead of the unique zzmytool.
    s = run_lf(script=[("$zz", 0.4), ("<tab>", 0.5)],
               path_bins=[("zznoexec", 0o644), "zzmytool"])
    assert s.bottom() == "$zzmytool"
    assert s.menu() == ""


def test_executable_completion_scans_every_path_entry(run_lf):
    """Executable completion walks all entries of $PATH, not just the first."""
    # CATCHES: candidates that only scan the first PATH directory and
    # therefore miss zztoolb from the second entry.
    s = run_lf(script=[("$zz", 0.4), ("<tab>", 0.5)],
               path_bins=["zztoola"], path2_bins=["zztoolb"])
    assert s.bottom() == "$zztool"
    assert s.menu() == "zztoola zztoolb"


def test_executable_completion_without_match(run_lf):
    """A shell prefix matching no executable is left untouched."""
    # CATCHES: candidates that clear the prompt or insert something when no
    # executable in $PATH matches the typed prefix.
    s = run_lf(script=[("$zzqq", 0.4), ("<tab>", 0.5)], path_bins=["zztoola"])
    assert s.bottom() == "$zzqq"
    assert s.menu() == ""


def test_executable_completion_skips_broken_path_entries(run_lf):
    """A PATH entry that is a regular file is skipped, later ones scanned."""
    # CATCHES: candidates that abort the whole $PATH scan when reading an
    # entry fails (here the first entry is a regular file) instead of
    # continuing with the remaining entries.
    s = run_lf(script=[("$zz", 0.4), ("<tab>", 0.5)],
               path_bins=["zzmytool"], path_file=True)
    assert s.bottom() == "$zzmytool"
    assert s.menu() == ""


def test_search_completion_is_case_insensitive(run_lf):
    """The search prompt completes file names ignoring case."""
    # CATCHES: candidates whose search-prompt completion matches
    # case-sensitively, so '/de' would find neither Delta.txt nor delta2.log.
    s = run_lf(script=[("/de", 0.4), ("<tab>", 0.5)],
               files=["Delta.txt", "delta2.log", "a.txt"])
    assert s.bottom() == "/Delta"
    assert s.menu() == "Delta.txt       delta2.log"


def test_search_completion_without_match(run_lf):
    """A search pattern matching nothing keeps the prompt as typed."""
    # CATCHES: candidates that clear the search prompt or echo an error when
    # no file name matches the pattern.
    s = run_lf(script=[("/zzq", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == "/zzq"
    assert s.menu() == ""


@pytest.mark.parametrize("prefix", ["$", "!", "%", "&"])
def test_shell_prompts_complete_file_arguments(run_lf, prefix):
    """Every shell prefix completes file names for later words."""
    # CATCHES: candidates that wire file completion into the '$' prompt only
    # and not into the '!', '%' and '&' prompts.
    s = run_lf(script=[(f"{prefix}echo a", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == f"{prefix}echo a.txt"
    assert s.menu() == ""


def test_shell_file_completion_with_directory_prefix(run_lf):
    """Shell file completion honors a directory prefix in the argument."""
    # CATCHES: candidates whose shell-side file completer ignores the
    # 'sub/' prefix and completes only names in the working directory.
    s = run_lf(script=[("$ cat sub/de", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == "$ cat sub/deep.txt"
    assert s.menu() == ""


def test_setlocal_completes_local_option_names(run_lf):
    """setlocal completes only local option names, with their '!' forms."""
    # CATCHES: candidates that offer global option names (like history) to
    # setlocal, or miss the hidden! toggle form of the boolean local options.
    s = run_lf(script=[(":setlocal . hi", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":setlocal . hidden"
    assert s.menu() == "hidden  hidden!"


@pytest.mark.parametrize("tail,expected", [
    ("sortby ", "atime   btime   ctime   custom  ext     name    natural size    time"),
    ("info ", "atime   btime   ctime   custom  group   perm    size    time    user"),
    ("hidden ", "false   true"),
])
def test_setlocal_value_completion(run_lf, tail, expected):
    """setlocal completes the values of its list, choice and bool options."""
    # CATCHES: candidates that complete setlocal option names but not their
    # values, or that use the global option table for the values.
    s = run_lf(script=[(f":setlocal . {tail}", 0.4), ("<tab>", 0.5)])
    assert s.menu() == expected
