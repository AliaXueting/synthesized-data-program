"""Edge behaviors of the ':' command dispatch, prompts and insert paths:
prompt-prefix switching, argument errors of path/pattern commands, modal
built-ins consulting user commands, shell prefixes inside user command
bodies, marks/tags failures, history navigation edges and cmd-line guards."""

import pytest


def _names(s, count=6):
    """Names shown in the current-directory pane, top to bottom."""
    return [s.lines()[1 + i][15:30].strip() for i in range(count)]


def test_colon_prompt_prefix_switch(run_lf):
    """Typing a prefix character at the empty ':' prompt switches modes."""
    # CATCHES: candidates that insert '!' or '&' as literal text instead
    # of switching the prompt to the wait/async shell prefixes.
    s = run_lf(script=[(":", 0.4)])
    s.send("!")
    s.wait(quiet=0.4)
    assert s.bottom() == "!"
    s.send("<esc>")
    s.wait(quiet=0.3)
    s.send(":")
    s.wait(quiet=0.3)
    s.send("&")
    s.wait(quiet=0.4)
    assert s.bottom() == "&"
    s.send("<esc>")
    s.wait(quiet=0.3)
    s.send(":$echo PREFIX-SWITCH-MARK\r")
    s.wait(quiet=0.8)
    assert "PREFIX-SWITCH-MARK" in s.raw_text()


def test_backspace_keeps_pipe_and_filter_prompts_open(run_lf):
    """Backspace on empty input spares the pipe and filter prompts."""
    # CATCHES: candidates that close the '>' pipe prompt or revert it to
    # ':' on backspace; only the $ ! % & prefixes degrade to ':'.
    s = run_lf(script=[("%cat\r", 0.8)])
    assert s.bottom() == ">"
    s.send("<backspace>")
    s.wait(quiet=0.4)
    assert s.bottom() == ">"
    s.send("<c-c>")
    s.wait(quiet=0.5)
    s.send(":filter\r")
    s.wait(quiet=0.4)
    assert s.bottom() == "filter:"
    s.send("<backspace>")
    s.wait(quiet=0.4)
    assert s.bottom() == "filter:"


@pytest.mark.parametrize("line,expected", [
    (":push\r", "push: requires an argument"),
    (":glob-select\r", "glob-select: requires a pattern to match"),
    (":glob-unselect\r", "glob-unselect: requires a pattern to match"),
    (":source\r", "source: requires an argument"),
    (":tty-write\r", "tty-write: requires an argument"),
])
def test_commands_requiring_arguments(run_lf, line, expected):
    """Commands with mandatory arguments report what is missing."""
    # CATCHES: candidates that silently ignore a missing argument instead
    # of naming the requirement on the message line.
    s = run_lf(script=[(line, 0.5)])
    assert s.bottom().startswith(expected)
    assert s.bottom().endswith("1/6")


def test_toggle_resolves_argument_against_cwd(run_lf):
    """:toggle lstats its argument resolved to an absolute path."""
    # CATCHES: candidates that lstat the raw argument (the message must
    # carry the resolved path) or that swallow the lstat failure.
    # A wide terminal keeps the long temporary path inside the message.
    s = run_lf(cols=140, script=[])
    s.send(":toggle nope\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith(
        "toggle: lstat %s/nope: no such file or directory" % s.cwd)


@pytest.mark.parametrize("line", [
    ":addcustominfo\r",
    ":addcustominfo a.txt 1 extra\r",
])
def test_addcustominfo_argument_count(run_lf, line):
    """addcustominfo accepts only one or two arguments."""
    # CATCHES: candidates that index the argument list without checking
    # its length first (zero or three arguments would misbehave).
    s = run_lf(script=[(line, 0.5)])
    assert s.bottom().startswith(
        "addcustominfo: requires either 1 or 2 arguments")


def test_addcustominfo_missing_file(run_lf):
    """addcustominfo rejects paths that do not exist in the directory."""
    # CATCHES: candidates that store custom info for nonexistent files
    # instead of reporting the missing path.
    s = run_lf(script=[])
    s.send(":addcustominfo %s/nope 1\r" % s.cwd)
    s.wait(quiet=0.5)
    assert s.bottom().startswith("addcustominfo: file not found:")


def test_rename_in_empty_directory(run_lf):
    """:rename without any file under the cursor reports an error."""
    # CATCHES: candidates that open an empty rename prompt (or crash)
    # when the directory has nothing to rename.
    s = run_lf(script=[(":cd other\r", 0.5)])
    s.send(":rename\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("rename: empty directory")
    assert s.bottom().endswith("0/0")


def test_rename_prefills_directory_name(run_lf):
    """:rename on a directory prefills its whole name unchanged."""
    # CATCHES: candidates that strip an 'extension' from directory names
    # when prefilling; 'other' must appear verbatim after the prefix.
    s = run_lf(script=[(":rename\r", 0.5)])
    assert s.bottom() == "rename: other"


def test_user_commands_override_modal_builtins(run_lf):
    """paste/delete/rename run a user command defined for that name."""
    # CATCHES: candidates that dispatch these three built-ins directly;
    # unlike other built-ins they must consult user commands first.
    s = run_lf(script=[(":paste\r", 0.5)], cfg=(
        "cmd paste :echo CUSTOM-PASTE\n"
        "cmd delete :echo CUSTOM-DELETE\n"
        "cmd rename :echo CUSTOM-RENAME\n"))
    assert s.bottom().startswith("CUSTOM-PASTE")
    s.send(":delete\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("CUSTOM-DELETE")
    s.send(":rename\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("CUSTOM-RENAME")
    assert _names(s) == ["other", "sub", "a.txt", "b.txt", "c.txt", "zeta.md"]


def test_wait_and_pipe_prefixes_via_user_commands(run_lf):
    """User command bodies starting with '!' or '%' run as shell prefixes."""
    # CATCHES: candidates that run such bodies as normal commands; the
    # '!' body must produce the wait pause, the '%' body the pipe prompt.
    s = run_lf(script=[(":w\r", 0.8)], cfg=(
        "cmd w !echo WAIT-BY-CMD\n"
        "cmd pcat %cat\n"))
    assert s.top() == "WAIT-BY-CMD"
    assert s.lines()[1].startswith("Press any key to continue")
    s.send("x")
    s.wait(quiet=0.5)
    s.send(":pcat\r")
    s.wait(quiet=0.6)
    assert s.bottom() == ">"
    s.send("hello")
    s.wait(quiet=0.5)
    assert s.bottom() == ">hello"


def test_visual_commands_outside_visual_mode(run_lf):
    """visual-change/visual-accept without a visual range are silent."""
    # CATCHES: candidates that error out (or clear the listing) when the
    # visual commands run with no active visual selection.
    s = run_lf(script=[(":echo MARKER-STRING-LONG\r", 0.5)])
    assert s.bottom().startswith("MARKER-STRING-LONG")
    s.send(":visual-change\r")
    s.wait(quiet=0.5)
    assert not s.bottom().startswith("MARKER-STRING-LONG")
    assert not s.bottom().startswith("visual-")
    assert s.bottom().endswith("1/6")
    s.send(":visual-accept\r")
    s.wait(quiet=0.5)
    assert not s.bottom().startswith("visual-")
    assert s.bottom().endswith("1/6")
    assert _names(s) == ["other", "sub", "a.txt", "b.txt", "c.txt", "zeta.md"]


def test_history_navigation_edges(run_lf):
    """Down past the newest entry empties the prompt; an unmatched
    history prefix leaves the search prompt untouched."""
    # CATCHES: candidates that clamp history navigation at the newest
    # entry instead of wrapping back to the empty input line.
    s = run_lf(script=[(":echo one\r", 0.3), (":echo two\r", 0.3), (":", 0.4)])
    s.send("<up><up><down>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":echo two"
    s.send("<down>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":"
    s.send("<esc>")
    s.wait(quiet=0.3)
    s.send("/xy")
    s.wait(quiet=0.4)
    s.send("<up>")
    s.wait(quiet=0.4)
    assert s.bottom() == "/xy"


def test_cmd_motion_guards(run_lf):
    """Left/right on an empty line and delete at the end change nothing;
    backspace at the start of the text closes the prompt."""
    # CATCHES: candidates whose motion commands wrap or close the prompt
    # when there is nothing to move over, or whose delete key eats the
    # last character when pressed at the end of the line.
    s = run_lf(script=[(":", 0.4)])
    s.send("<left><right>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":"
    s.send("ab<end><delete>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":ab"
    s.send("<home><backspace>")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("1/6")
    s.send(":")
    s.wait(quiet=0.3)
    s.send("ab<a-b><a-f>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":ab"
    s.send("<home><a-d>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":"


def test_cmd_guards_on_empty_input(run_lf):
    """Word, case, transpose and yank commands are no-ops when empty."""
    # CATCHES: candidates that close the prompt, crash or insert junk
    # when an editing command has no text to act on.
    s = run_lf(script=[(":", 0.4)])
    for keys in ("<a-c>", "<a-t>", "<c-t>", "<c-w>", "<c-y>"):
        s.send(keys)
        s.wait(quiet=0.3)
        assert s.bottom() == ":"


def test_cmd_insert_without_arguments(run_lf):
    """cmd-insert bound without arguments inserts nothing."""
    # CATCHES: candidates that treat a missing cmd-insert argument as an
    # escape or an error; the prompt must stay open and empty.
    s = run_lf(script=[(":cmap <f-3> cmd-insert\r", 0.4)])
    s.send(":")
    s.wait(quiet=0.3)
    s.send("<f-3>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":"
    s.send("xy")
    s.wait(quiet=0.4)
    assert s.bottom() == ":xy"


def test_selection_path_flag_writes_on_open(run_lf, tmp_path):
    """-selection-path makes opening a file write its path to the file."""
    # CATCHES: candidates that print to stdout instead of the given file,
    # or that append a trailing newline to the written path.
    sel = tmp_path / "selection"
    s = run_lf(args=("-selection-path", str(sel)),
               script=[("2j", 0.4), ("l", 1.2)])
    assert s.exit_code() == 0
    assert sel.read_text() == "%s/a.txt" % s.cwd


def test_print_selection_flag_prints_on_open(run_lf):
    """-print-selection prints the opened file's path on stdout."""
    # CATCHES: candidates that print nothing in single mode or that print
    # a relative path; the absolute path must reach the terminal.
    s = run_lf(args=("-print-selection",),
               script=[("2j", 0.4), ("l", 1.2)])
    assert s.exit_code() == 0
    assert s.raw_text().endswith("%s/a.txt\r\n" % s.cwd)


def test_open_directory_and_updir(run_lf):
    """Opening a directory shows its (empty) contents; h returns."""
    # CATCHES: candidates that cannot descend into a directory with the
    # open key or that lose the parent listing on the way back up.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(cols=140)
    s.send("l")
    s.wait_for(lambda t: t.bottom().endswith("0/0"), timeout=4.0)
    assert s.top().endswith("/other/")
    assert s.lines()[1] == "  other                  empty"
    s.send("h")
    s.wait_for(lambda t: t.bottom().endswith("1/6"), timeout=4.0)
    assert s.top().endswith("/other")


def test_findlen_zero_waits_for_unique_pattern(run_lf):
    """findlen 0 keeps the prompt open until the pattern is unambiguous."""
    # CATCHES: candidates that jump on the first typed character despite
    # findlen 0, or that never accept a unique one-character pattern.
    s = run_lf(files=("a1.txt", "a2.txt", "b.txt"), cfg="set findlen 0")
    s.send("f")
    s.wait(quiet=0.3)
    s.send("a")
    s.wait(quiet=0.5)
    assert s.bottom() == "find: a"
    s.send("1")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("3/5")
    assert s.top().endswith("/a1.txt")
    s.send("f")
    s.wait(quiet=0.3)
    s.send("q")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("find: pattern not found: q")
    s.send(":find-back\r")
    s.wait(quiet=0.3)
    s.send("a")
    s.wait(quiet=0.5)
    assert s.bottom() == "find-back: a"


def test_find_back_reverses_semicolon_and_comma(run_lf):
    """After find-back, ';' continues backward and ',' goes forward."""
    # CATCHES: candidates that hard-wire ';' to forward find-next; the
    # search direction must carry over from the find-back before it.
    s = run_lf(files=("a1.txt", "a2.txt", "a3.txt", "b.txt"))
    s.send("3j")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("4/6")
    s.send(":find-back\r")
    s.wait(quiet=0.3)
    s.send("a")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("3/6")
    assert s.top().endswith("/a1.txt")
    s.send(";")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("5/6")
    assert s.top().endswith("/a3.txt")
    s.send(",")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("3/6")
    assert s.top().endswith("/a1.txt")


def test_search_back_reverses_n_and_N(run_lf):
    """After '?', n searches backward and N forward; a miss stays put."""
    # CATCHES: candidates that bind n/N to fixed directions instead of
    # the direction of the last search, or that move on a failed search.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(cols=140)
    s.send("G")
    s.wait_for(lambda t: t.bottom().endswith("6/6"), timeout=4.0)
    s.send("?txt\r")
    s.wait_for(lambda t: t.bottom().endswith("5/6"), timeout=4.0)
    s.send("n")
    s.wait_for(lambda t: t.bottom().endswith("4/6"), timeout=4.0)
    s.send("N")
    s.wait_for(lambda t: t.bottom().endswith("5/6"), timeout=4.0)
    s.send("?zzz\r")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("5/6")
    assert s.top().endswith("/c.txt")


def test_incsearch_back_restores_on_escape(run_lf):
    """Incremental search-back jumps while typing and restores on escape."""
    # CATCHES: candidates that keep the moved cursor after aborting the
    # search, or that only implement incsearch in the forward direction.
    s = run_lf(files=("a.txt", "bx.txt", "c.txt", "cb.txt"),
               cfg="set incsearch")
    s.send("G")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("6/6")
    s.send("?")
    s.wait(quiet=0.3)
    s.send("b")
    s.wait(quiet=0.5)
    assert s.bottom() == "?b"
    assert s.top().endswith("/bx.txt")
    s.send("<esc>")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("6/6")
    assert s.top().endswith("/cb.txt")


def test_scroll_keys_clamp_at_view_edges(run_lf):
    """scroll-up/scroll-down do nothing at the top/bottom of the view."""
    # CATCHES: candidates whose scroll keys wrap the view around like
    # wrapscroll does for the cursor.
    s = run_lf(files=["f%02d.txt" % i for i in range(26)])
    s.send("G")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("28/28")
    s.send("<c-e>")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("28/28")
    assert _names(s)[0] == "f04.txt"
    s.send("gg")
    s.wait(quiet=0.4)
    s.send("<c-y>")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/28")
    assert _names(s)[0] == "other"


def test_mark_save_write_error(run_lf):
    """A marks file that cannot be created reports the failure."""
    # CATCHES: candidates that swallow mark-save write errors; the message
    # must name the failing 'creating marks file' operation.
    s = run_lf(script=[])
    (s.data_dir / "marks").mkdir()
    s.send("m")
    s.wait(quiet=0.3)
    s.send("z")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("mark-save: creating marks file:")
    assert s.bottom().endswith("1/6")


def test_mark_load_removed_directory(run_lf):
    """Loading a mark whose directory is gone reports the chdir failure."""
    # CATCHES: candidates that drop the mark or silently ignore the
    # missing directory instead of surfacing the chdir error.
    # A wide terminal keeps the whole message (path + errno text) visible.
    s = run_lf(script=[(":cd sub\r", 0.4), ("m", 0.3), ("z", 0.4)], cols=140)
    s.send(":cd %s\r" % s.cwd)
    s.wait(quiet=0.4)
    s.send("$rm -rf %s/sub\r" % s.cwd)
    s.wait(quiet=0.8)
    s.send("'")
    s.wait(quiet=0.4)
    s.send("z")
    s.wait_for(
        lambda t: t.bottom().startswith("mark-load: chdir %s/sub" % t.cwd),
        timeout=4.0)
    assert "no such file or directory" in s.bottom()
    assert s.bottom().endswith("2/5")


def test_mark_remove_unknown_mark(run_lf):
    """Removing a mark letter that was never saved reports an error."""
    # CATCHES: candidates that treat mark-remove of an unknown letter as
    # a silent success.
    s = run_lf(script=[(":mark-remove\r", 0.4), ("z", 0.5)])
    assert s.bottom().startswith("mark-remove: no such mark")
    assert s.bottom().endswith("1/6")


def test_tag_unreadable_tags_file(run_lf):
    """A tags file that cannot be read reports the failure."""
    # CATCHES: candidates that silently ignore an unreadable tags file
    # instead of surfacing the read error on the message line.
    s = run_lf(script=[])
    (s.data_dir / "tags").mkdir()
    s.send(":tag x\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("tag: reading tags file:")
    assert s.bottom().endswith("1/6")
