"""TEMPORARY probe file - deleted after recording."""

import os


def test_probe_dircounts(run_lf):
    s = run_lf(cfg="set dircounts\nset info size")
    s.wait(quiet=1.0)
    for i in range(1, 5):
        print("row%d: %r" % (i, s.lines()[i]))
    print("bottom:", repr(s.bottom()[-10:]))


def test_probe_watch_delete_selection(run_lf):
    s = run_lf(cfg="set watch")
    s.send("2j")
    s.wait(quiet=0.4)
    s.send(" ")
    s.wait(quiet=0.5)
    print("selected:", repr(s.bottom()[-14:]))
    os.remove(s.cwd / "a.txt")
    s.wait_for(lambda t: "a.txt" not in t.lines()[3], timeout=4.0)
    s.wait(quiet=0.5)
    print("rows:", [s.lines()[i][15:30].strip() for i in range(1, 6)])
    print("bottom:", repr(s.bottom()[-14:]))


def test_probe_fifo_copy_quit(run_lf):
    def mk(root):
        cwd = root / "tree" / "cwd"
        os.mkfifo(cwd / "pipe")
        (cwd / "dst").mkdir()
        return ""
    s = run_lf(cfg=mk, cols=140)
    s.send("4j")
    s.wait_for(lambda t: t.bottom().endswith("5/7"), timeout=4.0)
    s.send(":copy\r")
    s.wait(quiet=0.5)
    s.send(":cd dst\r")
    s.wait_for(lambda t: t.bottom().endswith("0/0"), timeout=4.0)
    s.send(":paste\r")
    s.wait(quiet=0.8)
    s.send("q")
    s.wait(quiet=0.8)
    print("guard bottom:", repr(s.bottom()[:60]))
    with open(s.cwd / "pipe", "w") as f:
        f.write("data\n")
    s.wait_for(lambda t: "Copied successfully" in t.bottom(), timeout=5.0)
    print("copied bottom:", repr(s.bottom()[:60]))
    print("dst/pipe:", repr((s.cwd / "dst" / "pipe").read_text()))
    s.send("q")
    print("exit:", s.exit_code(timeout=4.0))


def test_probe_copy_newline_name(run_lf):
    s = run_lf(files=("we\nird.txt", "a.txt"), cols=140)
    s.send("3j")
    s.wait_for(lambda t: t.bottom().endswith("4/4"), timeout=4.0)
    s.send(":copy\r")
    s.wait(quiet=0.6)
    print("copy bottom:", repr(s.bottom()))
    print("row above:", repr(s.lines()[-2]))
    print("raw has msg:", "name contains a newline" in s.raw_text())
