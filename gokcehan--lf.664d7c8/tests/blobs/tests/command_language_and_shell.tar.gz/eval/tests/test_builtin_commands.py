"""Built-in ':' commands: messages, movement counts, cd, and misc utilities."""

import pytest


@pytest.mark.parametrize("cmd", [":echo", ":echomsg", ":echoerr"])
def test_echo_family_shows_message(run_lf, cmd):
    """echo, echomsg and echoerr print their argument on the message line."""
    # CATCHES: a candidate that drops, renames or mis-renders any of the three
    # message commands leaves the plain stat line on the bottom row instead.
    s = run_lf(script=[(cmd + " hello\r", 0.4)])
    assert s.bottom().startswith("hello")
    assert s.bottom().endswith("1/6")


def test_echo_quoted_argument(run_lf):
    """A quoted argument keeps its spaces instead of being split."""
    # CATCHES: candidates whose tokenizer splits inside double quotes print
    # 'hello" world"' or 'hello world"' rather than the full quoted phrase.
    s = run_lf(script=[(':echo "hello world"\r', 0.4)])
    assert s.bottom().startswith("hello world")
    assert s.bottom().endswith("1/6")


def test_unknown_command_error(run_lf):
    """An unknown ':' command reports 'command not found' with its name."""
    # CATCHES: a candidate that silently ignores unknown commands, or formats
    # the error differently, fails to match the exact message prefix.
    s = run_lf(script=[(":nosuchcmd\r", 0.4)])
    assert s.bottom().startswith("command not found: nosuchcmd")
    assert s.bottom().endswith("1/6")


def test_empty_command_line_stays_open(run_lf):
    """Pressing enter on an empty ':' prompt keeps the prompt open."""
    # CATCHES: a candidate that closes the prompt or executes something on
    # empty input would return to the stat line instead of the bare ':'.
    s = run_lf(script=[(":", 0.3), ("\r", 0.4)])
    assert s.bottom() == ":"


def test_typed_counts_and_clamping(run_lf):
    """Typed count prefixes move several steps and clamp at the last entry."""
    # CATCHES: candidates that ignore the digit prefix (moving one step) or
    # fail to clamp movement at the end of the listing.
    s = run_lf(script=[("3j", 0.4)])
    assert s.bottom().endswith("4/6")
    s.send("99j")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("6/6")
    s.send("gg")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")
    s.send("3G")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("3/6")
    s.send("G")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("6/6")


def test_push_moves_cursor(run_lf):
    """:push types keys as if pressed, including count prefixes."""
    # CATCHES: a candidate whose push executes the string as one command or
    # ignores counts moves differently than the recorded positions.
    s = run_lf(script=[(":push 2j\r", 0.4)])
    assert s.bottom().endswith("3/6")
    s.send(":push j\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("4/6")


def test_push_special_keys_literal(run_lf):
    """:push understands special key syntax like <down> with a count."""
    # CATCHES: candidates that treat '<down>' as plain text or do not combine
    # a pushed count with a pushed special key.
    s = run_lf(script=[])
    s.send_literal(":push <down>\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("2/6")
    s.send_literal(":push 2<down>\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("4/6")


def test_command_arguments_are_not_counts(run_lf):
    """:up and :down ignore their arguments and move a single step."""
    # CATCHES: candidates that read the movement count from the command
    # argument instead of the typed key count prefix.
    s = run_lf(script=[(":down 2\r", 0.4)])
    assert s.bottom().endswith("2/6")
    s.send(":up 3\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")


def test_half_and_page_movement(run_lf):
    """:half-down/:half-up/:page-down/:page-up move by screen fractions."""
    # CATCHES: candidates that treat these as single-line moves or that read
    # counts from the arguments (both recorded as single steps here).
    s = run_lf(script=[(":half-down 2\r", 0.4)])
    assert s.bottom().endswith("6/6")
    s.send(":half-up 1\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")
    s.send(":page-down\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("6/6")
    s.send(":page-up\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")


def test_top_bottom_and_counted_jumps(run_lf):
    """:top/:bottom jump to the ends; 5gg and 3G land on counted lines."""
    # CATCHES: candidates that mix up gg/G count semantics (5gg must land on
    # the 5th entry, 3G on the 3rd) or ignore :top/:bottom entirely.
    s = run_lf(script=[("3j", 0.3), (":bottom\r", 0.4)])
    assert s.bottom().endswith("6/6")
    s.send(":top\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")
    s.send(":push 5gg\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("5/6")
    s.send(":push 3G\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("3/6")


def test_cd_errors(run_lf):
    """:cd reports chdir failures for missing dirs and non-dirs."""
    # CATCHES: candidates that silently ignore failed chdirs or word the
    # error differently (missing 'no such file or directory' suffix).
    # A wide terminal is used so the long absolute path is not truncated.
    s = run_lf(script=[(":cd /no/such/dir\r", 0.4)], cols=140)
    assert s.bottom().startswith("cd: chdir /no/such/dir: no such file or directory")
    s.send(":cd a.txt\r")
    s.wait(quiet=0.4)
    assert s.bottom().startswith("cd: chdir %s/a.txt: not a directory" % s.cwd)


def test_cd_dash_swaps_with_previous(run_lf):
    """:cd - alternates between the current and previous directory."""
    # CATCHES: candidates without a directory history that error out or stay
    # in place when asked to go back; the header must show the cursor file of
    # the directory returned to (sub/deep.txt vs the sub entry in cwd).
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[(":cd sub\r", 0.5)], cols=140)
    assert s.top().endswith(str(s.cwd / "sub" / "deep.txt"))
    assert s.bottom().endswith("1/1")
    s.send(":cd -\r")
    s.wait(quiet=0.5)
    # returning to cwd places the cursor on the entry we came from (sub)
    assert s.top().endswith(str(s.cwd / "sub"))
    assert s.bottom().endswith("2/6")
    s.send(":cd -\r")
    s.wait(quiet=0.5)
    assert s.top().endswith(str(s.cwd / "sub" / "deep.txt"))
    assert s.bottom().endswith("1/1")


def test_cd_dash_without_previous(run_lf):
    """:cd - with no previous directory reports an error."""
    # CATCHES: candidates that treat a missing previous directory as a no-op
    # or crash instead of showing the recorded message.
    s = run_lf(script=[(":cd -\r", 0.4)])
    assert s.bottom().startswith("cd: no previous directory")
    assert s.bottom().endswith("1/6")


def test_tty_write_goes_to_the_terminal(run_lf):
    """:tty-write prints its argument straight to the terminal."""
    # CATCHES: candidates that echo the text into the message line (which
    # never reaches the raw output stream) instead of writing to the tty.
    s = run_lf(script=[(":tty-write XYZZY-VERIFY-TOKEN\r", 0.5)])
    assert "XYZZY-VERIFY-TOKEN" in s.raw_text()


def test_draw_and_redraw_are_silent(run_lf):
    """:draw and :redraw repaint without errors or cursor movement."""
    # CATCHES: candidates that implement draw/redraw as navigation or emit
    # an error message; the stat line must stay exactly as it was.
    s = run_lf(script=[(":draw\r", 0.4)])
    assert s.bottom().endswith("1/6")
    assert "draw" not in s.bottom()
    s.send(":redraw\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")


def test_reload_and_load_refresh_listing(run_lf):
    """:reload and :load pick up files created behind lf's back."""
    # CATCHES: candidates whose reload/load only re-read cached state; the
    # file created by the shell command must appear (count 1/7).
    s = run_lf(script=[("$ touch newf2.txt\r", 0.6), (":reload\r", 0.6)])
    assert s.bottom().endswith("1/7")
    s.close()
    s2 = run_lf(script=[("$ touch newf3.txt\r", 0.6), (":load\r", 0.6)])
    assert s2.bottom().endswith("1/7")
