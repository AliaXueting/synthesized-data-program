"""Tab completion: command names, option names and values, file paths in
every prompt kind, and the cmd-menu-complete family."""

import pytest

MENU_CFG = (
    "cmap <f-5> cmd-menu-complete\n"
    "cmap <f-6> cmd-menu-complete-back\n"
    "cmap <f-7> cmd-menu-accept\n"
    "cmap <f-8> cmd-menu-discard\n"
)


def test_command_name_completion(run_lf):
    """Tab completes a unique ':' command name without a menu."""
    # CATCHES: candidates that do not complete command names at all (the
    # prompt stays ':a') or that open a menu even for a unique match.
    s = run_lf(script=[(":a", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":addcustominfo"
    assert s.menu() == ""


def test_command_name_completion_ambiguous(run_lf):
    """An ambiguous command prefix keeps the shared prefix and lists matches."""
    # CATCHES: candidates that pick one match instead of the common prefix,
    # or that render the match list with different column spacing.
    s = run_lf(script=[(":se", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":se"
    assert s.menu() == "set             setfilter       setlocal"


def test_option_name_completion(run_lf):
    """Option names complete; the 'no' prefix lists negatable options."""
    # CATCHES: candidates that cannot complete inside ':set', or that forget
    # the hidden/hidden!/hiddenfiles options in the match list.
    s = run_lf(script=[(":set hid", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set hidden"
    assert s.menu() == "hidden          hidden!         hiddenfiles"
    s.close()

    s = run_lf(script=[(":set noh", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set nohi"
    assert s.menu() == "nohidden        nohistory"
    s.close()

    s = run_lf(script=[(":set time", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":set timefmt"
    assert s.menu() == ""


def test_option_value_completion(run_lf):
    """Tab after an option name lists the allowed values."""
    # CATCHES: candidates that only complete option names but not their
    # values, or that list values in a different order.
    s = run_lf(script=[(":set sortby ", 0.4), ("<tab>", 0.5)])
    assert s.menu() == "atime   btime   ctime   custom  ext     name    natural size    time"


def test_file_completion_respects_command(run_lf):
    """:cd completes only directories while :toggle completes everything."""
    # CATCHES: candidates that reuse one file completer for all commands;
    # ':cd' must not offer regular files.
    s = run_lf(script=[(":cd ", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":cd"
    assert s.menu() == "other/  sub/"
    s.send("<esc>")
    s.wait(quiet=0.3)
    s.send(":toggle ")
    s.wait(quiet=0.4)
    s.send("<tab>")
    s.wait(quiet=0.5)
    assert s.menu() == "a.txt   b.txt   c.txt   other/  sub/    zeta.md"
    s.send("<esc>")
    s.wait(quiet=0.3)
    s.send(":cd s")
    s.wait(quiet=0.4)
    s.send("<tab>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":cd sub/"
    assert s.menu() == ""
    s.close()

    s = run_lf(script=[(":cd my", 0.4), ("<tab>", 0.5)], files=["my file.txt", "a.txt"])
    assert s.bottom() == ":cd my"
    assert s.menu() == ""


def test_file_completion_escaping_differs_by_prompt(run_lf):
    """File completion escapes spaces after ':' but not after '/'."""
    # CATCHES: candidates that quote or do not escape spaces uniformly; the
    # command prompt must backslash-escape, the search prompt must not.
    s = run_lf(script=[(":toggle my", 0.4), ("<tab>", 0.5)], files=["my file.txt", "a.txt"])
    assert s.bottom() == ":toggle my\\ file.txt"
    s.close()

    s = run_lf(script=[("/my", 0.4), ("<tab>", 0.5)], files=["my file.txt", "a.txt"])
    assert s.bottom() == "/my file.txt"
    s.close()

    s = run_lf(script=[("$ cat my", 0.4), ("<tab>", 0.5)], files=["my file.txt", "a.txt"])
    assert s.bottom() == "$ cat my\\ file.txt"


def test_completion_in_other_prompts(run_lf):
    """Search-back and shell prompts complete file names too."""
    # CATCHES: candidates that wire completion only into the ':' prompt.
    s = run_lf(script=[("?a", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == "?a.txt"


def test_hidden_file_completion(run_lf):
    """Hidden files are offered for completion even when not listed."""
    # CATCHES: candidates that complete from the (filtered) listing instead
    # of reading the directory, hiding dotfiles unless 'set hidden'.
    s = run_lf(script=[(":toggle .h", 0.4), ("<tab>", 0.5)], files=["a.txt", ".hidden"])
    assert s.bottom() == ":toggle .hidden"


def test_executable_completion_from_path(run_lf):
    """The first word of a shell command completes from $PATH."""
    # CATCHES: candidates that complete the first shell word as a file in
    # the current directory instead of searching $PATH.
    s = run_lf(script=[("$mytoo", 0.4), ("<tab>", 0.5)], path_bins=["mytool"])
    assert s.bottom() == "$mytool"


def test_menu_complete_family(run_lf):
    """cmd-menu-complete cycles entries; -back steps; accept/discard close."""
    # CATCHES: candidates that lack the cycling menu (plain tab completion
    # cannot walk through 'other/' then 'sub/' one press at a time).
    s = run_lf(script=[(":cd ", 0.4), ("<f-5>", 0.3)], cfg=MENU_CFG)
    assert s.bottom() == ":cd"
    assert s.menu() == "other/  sub/"
    s.send("<f-5>")
    s.wait(quiet=0.3)
    assert s.bottom() == ":cd other/"
    s.send("<f-5>")
    s.wait(quiet=0.3)
    assert s.bottom() == ":cd sub/"
    s.send("<f-6>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":cd other/"
    assert s.menu() == "other/  sub/"


def test_menu_complete_wraps_to_last(run_lf):
    """cmd-menu-complete-back wraps around to the last candidate."""
    # CATCHES: candidates whose back-cycling clamps at the first entry
    # instead of wrapping to 'sub/'.
    s = run_lf(script=[(":cd ", 0.4), ("<f-5>", 0.3), ("<f-6>", 0.5)], cfg=MENU_CFG)
    assert s.bottom() == ":cd sub/"
    assert s.menu() == "other/  sub/"


def test_menu_complete_accept_and_discard(run_lf):
    """cmd-menu-accept keeps the choice; -discard restores the typed text."""
    # CATCHES: candidates where accept discards the selection, or where
    # discard leaves the completed word instead of the original ':cd'.
    s = run_lf(script=[(":cd ", 0.4), ("<f-5>", 0.3), ("<f-5>", 0.3), ("<f-7>", 0.5)],
               cfg=MENU_CFG)
    assert s.bottom() == ":cd other/"
    assert s.menu() == ""
    s.close()

    s = run_lf(script=[(":cd ", 0.4), ("<f-5>", 0.3), ("<f-5>", 0.3), ("<f-8>", 0.5)],
               cfg=MENU_CFG)
    assert s.bottom() == ":cd"
    assert s.menu() == ""


def test_menu_complete_unique_match(run_lf):
    """cmd-menu-complete with one candidate completes without a menu."""
    # CATCHES: candidates that open a menu even when only one entry matches
    # the ':cd o' prefix.
    s = run_lf(script=[(":cd o", 0.4), ("<f-5>", 0.5)], cfg=MENU_CFG)
    assert s.bottom() == ":cd other/"
    assert s.menu() == ""
