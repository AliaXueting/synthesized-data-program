"""The :delete and :rename confirmation modals, including the replace and
create-directory escalations of the rename flow."""

import pytest


def test_delete_modal_single_file(run_lf):
    """:delete asks for confirmation and only 'y' actually removes the file."""
    # CATCHES: candidates that delete immediately without the [y/N] prompt,
    # or whose 'N'/other keys still remove the file.
    # A wide terminal keeps the full absolute path inside the prompt.
    s = run_lf(script=[(":delete\r", 0.5)], cols=140)
    assert s.bottom().startswith("delete '%s'? [y/N]" % (s.cwd / "other"))
    s.send("N")
    s.wait(quiet=0.5)
    assert (s.cwd / "other").is_dir()
    assert s.bottom().endswith("1/6")
    s.send(":delete\r")
    s.wait(quiet=0.4)
    s.send("y")
    s.wait(quiet=0.8)
    assert not (s.cwd / "other").exists()
    assert s.bottom().endswith("1/5")


def test_delete_modal_with_selections(run_lf):
    """With selections :delete summarizes the count and removes them all."""
    # CATCHES: candidates that only delete the file under the cursor instead
    # of every selection, or that miscount the 'delete N items' summary.
    s = run_lf(script=[(" ", 0.3), (" ", 0.3), (":delete\r", 0.5)])
    assert s.bottom().startswith("delete 2 items? [y/N]")
    s.send("y")
    s.wait(quiet=0.9)
    assert not (s.cwd / "other").exists()
    assert not (s.cwd / "sub").exists()
    assert s.bottom().endswith("1/4")


def test_rename_modal_prefill_and_extension(run_lf):
    """:rename prefills the name with the cursor left of the extension."""
    # CATCHES: candidates that place the cursor at the end of the name (the
    # typed X would append after '.txt') or prefill the whole path.
    s = run_lf(script=[("jj", 0.3), (":rename\r", 0.5)])
    assert s.bottom() == "rename: a.txt"
    s.send("X")
    s.wait(quiet=0.3)
    s.send("\r")
    s.wait(quiet=0.7)
    assert (s.cwd / "aX.txt").exists()
    assert not (s.cwd / "a.txt").exists()


def test_rename_replace_confirmation(run_lf):
    """Renaming onto an existing file asks 'replace' and overwrites on 'y'."""
    # CATCHES: candidates that overwrite without asking, or whose confirmation
    # loop leaves both files (a.txt must be gone after renaming it to b.txt).
    # A wide terminal keeps the full absolute path inside the prompt.
    s = run_lf(script=[("jj", 0.3), (":rename\r", 0.4)], cols=140)
    s.send("<c-u>")
    s.wait(quiet=0.2)
    s.send("b")
    s.wait(quiet=0.3)
    s.send("\r")
    s.wait(quiet=0.6)
    assert s.bottom().startswith("replace '%s'? [y/N]" % (s.cwd / "b.txt"))
    s.send("y")
    s.wait(quiet=0.8)
    assert not (s.cwd / "a.txt").exists()
    assert (s.cwd / "b.txt").exists()


def test_rename_create_directory(run_lf):
    """Renaming into a missing directory asks 'create' and builds the path."""
    # CATCHES: candidates that error out instead of offering to create the
    # target directory; on 'y' the file must move into the new directory.
    # A wide terminal keeps the full absolute path inside the prompt.
    s = run_lf(script=[("jj", 0.3), (":rename\r", 0.4)], cols=140)
    s.send("<c-u>")
    s.wait(quiet=0.2)
    s.send_literal("newdir/x")
    s.wait(quiet=0.3)
    s.send("\r")
    s.wait(quiet=0.6)
    # the '.txt' extension after the cursor is kept, so the target is x.txt
    assert s.bottom().startswith("create '%s'? [y/N]" % (s.cwd / "newdir"))
    s.send("y")
    s.wait(quiet=0.9)
    assert (s.cwd / "newdir" / "x.txt").exists()
    assert not (s.cwd / "a.txt").exists()
