"""Hook commands: pre-cd, on-cd, on-load, on-select, on-quit, on-redraw,
on-init and the focus hooks, plus the -remote server commands."""

import os
import subprocess

import pytest


def test_pre_cd_and_on_cd(run_lf):
    """pre-cd sees the old directory, on-cd the new one."""
    # CATCHES: candidates that fire both hooks with the same (new) working
    # directory, or that fire them in the opposite order.
    s = run_lf(script=[(":cd sub\r", 0.7)],
               cfg=lambda root: (
                   'cmd pre-cd ${{ echo "PRE[$PWD]" >> %s }}\n'
                   'cmd on-cd ${{ echo "CD[$PWD]" >> %s }}' % (root / "hook.log",
                                                                root / "hook.log")))
    assert (s.root / "hook.log").read_text() == (
        "PRE[%s]\nCD[%s]\n" % (s.cwd, s.cwd / "sub"))


def test_on_load_receives_loaded_files(run_lf):
    """on-load fires with the files of the directory being loaded."""
    # CATCHES: candidates that never run on-load or pass it an empty file
    # list; the last event must describe the directory entered.
    s = run_lf(script=[(":cd sub\r", 0.7)],
               cfg=lambda root: 'cmd on-load ${{ echo "LOAD[$fx]" >> %s }}'
                                % (root / "hook.log"))
    lines = (s.root / "hook.log").read_text().splitlines()
    assert lines[-1] == "LOAD[%s]" % (s.cwd / "sub" / "deep.txt")


def test_on_select_follows_cursor(run_lf):
    """on-select runs once per cursor position, including the initial one."""
    # CATCHES: candidates that fire on-select on every redraw (many lines)
    # or not at all; exactly one line per visited file must appear.
    s = run_lf(script=[("jj", 0.7)],
               cfg=lambda root: 'cmd on-select ${{ echo "S $f" >> %s }}'
                                % (root / "hook.log"))
    assert (s.root / "hook.log").read_text() == (
        "S %s\nS %s\nS %s\n" % (s.cwd / "other", s.cwd / "sub", s.cwd / "a.txt"))


def test_on_quit_runs_before_exit(run_lf):
    """on-quit runs when quitting and the process still exits cleanly."""
    # CATCHES: candidates that skip the hook on quit, or that cannot run a
    # synchronous hook while tearing down (missing log / non-zero exit).
    s = run_lf(script=[("q", 0.7)],
               cfg=lambda root: 'cmd on-quit ${{ echo QUIT >> %s }}'
                                % (root / "hook.log"))
    assert s.exit_code() == 0
    assert (s.root / "hook.log").read_text() == "QUIT\n"


def test_on_redraw_fires_twice(run_lf):
    """:redraw triggers on-redraw twice (resize and command redraw)."""
    # CATCHES: candidates that redraw once (a single R) or flood the hook
    # on every draw; the recorded count is exactly two.
    s = run_lf(script=[(":redraw\r", 0.8)],
               cfg=lambda root: 'cmd on-redraw ${{ echo R >> %s }}'
                                % (root / "hook.log"))
    assert (s.root / "hook.log").read_text() == "R\nR\n"


def test_on_init_and_query_commands_in_server_mode(run_lf):
    """on-init runs in server mode, where :maps and :cmds print listings."""
    # CATCHES: candidates that never run on-init, or whose :maps/:cmds fail
    # without a server (the custom map and command names must be listed).
    cfg = lambda root: (
        "cmd on-init &{{ echo init >> %s }}\n"
        "map Z :echo maps-custom-marker-Z\n"
        "cmd a-long-cmd-name :echo x\n" % (root / "hook.log"))
    s = run_lf(script=[(":maps\r", 1.5), (":cmds\r", 1.2)], cfg=cfg, single=False)
    assert (s.root / "hook.log").read_text() == "init\n"
    assert "maps-custom-marker-Z" in s.raw_text()
    assert "a-long-cmd-name" in s.raw_text()


def test_focus_hooks(run_lf):
    """on-focus-gained/on-focus-lost react to terminal focus events."""
    # CATCHES: candidates that do not enable focus reporting; the two hook
    # commands must fire in order for the gained and lost sequences.
    s = run_lf(script=[],
               cfg=lambda root: (
                   "cmd on-focus-gained ${{ echo GAINED >> %s }}\n"
                   "cmd on-focus-lost ${{ echo LOST >> %s }}" % (root / "hook.log",
                                                                  root / "hook.log")))
    s.wait(quiet=0.6)
    s.send("\x1b[I")
    s.wait(quiet=0.5)
    s.send("\x1b[O")
    s.wait(quiet=0.7)
    assert (s.root / "hook.log").read_text() == "GAINED\nLOST\n"


def test_remote_send_and_quit(run_lf):
    """-remote send forwards a command to the running instance over the socket."""
    # CATCHES: candidates with a different socket path or protocol; send must
    # execute the command in the connected client (its message and its
    # 'command not found' errors appear on the TUI), while 'quit' from a
    # remote client only drops that connection - the server still accepts
    # later sends and the TUI keeps processing input.
    s = run_lf(script=[], single=False)
    exe = os.environ["PROGRAMGYM_EXECUTABLE"]

    def remote(arg):
        return subprocess.run([exe, "-remote", arg], env=s.env,
                              capture_output=True, timeout=10)

    assert remote("send :echo REMOTE-SENT-MARKER").returncode == 0
    s.wait(quiet=0.8)
    assert s.bottom().startswith("REMOTE-SENT-MARKER")
    assert s.bottom().endswith("1/6")
    assert remote("send notacommand").returncode == 0
    s.wait(quiet=0.8)
    assert s.bottom().startswith("command not found: notacommand")
    assert remote("quit").returncode == 0
    assert remote("send :echo AFTER-REMOTE-QUIT").returncode == 0
    s.wait(quiet=0.8)
    assert s.bottom().startswith("AFTER-REMOTE-QUIT")
    s.send("j")
    s.wait(quiet=0.6)
    assert s.bottom().endswith("2/6")
    assert s.exit_code(timeout=2.0) is None
