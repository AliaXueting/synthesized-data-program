"""Command-line editing: the cmd-* operations bound in the cmap table."""

import pytest


def _type_prompt(s, text, quiet=0.35):
    s.send(":" + text)
    s.wait(quiet=quiet)


def test_escape_and_interrupt_close_prompt(run_lf):
    """Escape and Ctrl-C both abandon the command line and redraw."""
    # CATCHES: candidates where the prompt survives escape/interrupt, or
    # where the normal mode stat line is not restored afterwards.
    s = run_lf(script=[])
    _type_prompt(s, "abc")
    s.send("<esc>")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")
    _type_prompt(s, "abc")
    s.send("<c-c>")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("1/6")


def test_ctrl_g_keeps_prompt(run_lf):
    """Ctrl-G is not bound in the command prompt and does nothing."""
    # CATCHES: candidates that bind Ctrl-G to escape/interrupt; the typed
    # text must survive the keystroke untouched.
    s = run_lf(script=[])
    _type_prompt(s, "abc")
    s.send("<c-g>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":abc"


def test_backspace_edits_and_eats_prefix(run_lf):
    """Backspace deletes a character, and the '$' prefix when line is empty."""
    # CATCHES: candidates whose backspace cannot delete the prompt prefix
    # character (the '$' prompt must degrade to the ':' prompt).
    s = run_lf(script=[("$", 0.3)])
    s.send("<backspace>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":"
    s.send("abc")
    s.wait(quiet=0.3)
    s.send("<backspace>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":ab"


def test_transpose_chars(run_lf):
    """Ctrl-T swaps the two characters before the cursor."""
    # CATCHES: candidates that transpose around the wrong position or do
    # nothing at all on Ctrl-T.
    s = run_lf(script=[])
    _type_prompt(s, "ab")
    s.send("<c-t>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":ba"


def test_delete_word_and_yank_back(run_lf):
    """Ctrl-W deletes the word before the cursor; Ctrl-Y yanks it back."""
    # CATCHES: candidates without a kill/yank ring: after Ctrl-W the word is
    # gone, and Ctrl-Y must restore exactly what was deleted.
    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<c-w>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":one"
    s.send("<c-y>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":one two"


def test_home_end_and_insert(run_lf):
    """Home/Ctrl-A move to the start; Ctrl-E back to the end of the line."""
    # CATCHES: candidates whose cursor motion commands are missing, so the
    # inserted X lands at the wrong end of the line.
    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":Xone two"
    s.close()

    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<c-a>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":Xone two"
    s.close()

    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><c-e>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":one twoX"


def test_delete_key_forward(run_lf):
    """The delete key removes the character under the cursor."""
    # CATCHES: candidates that treat <delete> like backspace; from the start
    # of the line it must remove the first character, not do nothing.
    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><delete>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":Xne two"


def test_ctrl_k_kills_to_end(run_lf):
    """Ctrl-K deletes from the cursor to the end of the line."""
    # CATCHES: candidates that kill the wrong direction (like Ctrl-U) or do
    # nothing; after moving one word forward only 'one' may remain.
    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><a-f><c-k>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":one"


def test_ctrl_u_noop_at_home(run_lf):
    """Ctrl-U deletes to the start, so at the start it changes nothing."""
    # CATCHES: candidates that bind Ctrl-U to something destructive from the
    # home position (the line must stay exactly as typed).
    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><c-u>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":one two"


def test_word_motion_forward_and_back(run_lf):
    """Alt-F/Alt-B move by words; inserted text marks the position."""
    # CATCHES: candidates whose word motion skips punctuation or whole lines;
    # X must land right after 'one' and right before 'two' respectively.
    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><a-f>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":oneX two"
    s.close()

    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<a-b>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":one Xtwo"
    s.close()

    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><a-f><a-f>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":one twoX"


def test_word_deletion_alt_keys(run_lf):
    """Alt-backspace deletes the word before; Alt-D the word after."""
    # CATCHES: candidates that only implement Ctrl-W style deletion; both
    # alt keys must remove exactly one word from the right position.
    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><a-f><a-backspace>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":X two"
    s.close()

    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><a-f><a-d>X")
    s.wait(quiet=0.4)
    assert s.bottom() == ":oneX"


def test_case_operations(run_lf):
    """Alt-U uppercases, Alt-C capitalizes, Alt-L lowercases a word."""
    # CATCHES: candidates missing the case-changing commands; the whole word
    # (not just one character) must change case from the cursor.
    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><a-u>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":ONE two"
    s.close()

    s = run_lf(script=[])
    _type_prompt(s, "one two")
    s.send("<home><a-c>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":One two"
    s.close()

    s = run_lf(script=[])
    _type_prompt(s, "ONE TWO")
    s.send("<home><a-l>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":one TWO"


def test_ctrl_h_is_backspace(run_lf):
    """Ctrl-H behaves exactly like the backspace key in the prompt."""
    # CATCHES: candidates that leave Ctrl-H unbound; the last character of
    # the typed text must be removed.
    s = run_lf(script=[])
    _type_prompt(s, "abc")
    s.send("<c-h>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":ab"
