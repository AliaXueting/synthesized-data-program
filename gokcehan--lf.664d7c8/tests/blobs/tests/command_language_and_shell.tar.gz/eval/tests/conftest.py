"""Shared harness for black-box tests of lf's command language and shell.

The candidate binary is driven through a pseudo terminal so that the full
TUI is exercised: keys are written to the pty master, the terminal output
is replayed into a small VT100 screen emulator, and assertions read the
scraped screen (top row = prompt, bottom row = message/stat + counts,
row above the bottom = completion menu), the raw output stream, or the
side-effect files lf keeps under $XDG_DATA_HOME.
"""
from __future__ import annotations

import fcntl
import os
import pty
import re
import select
import struct
import termios
import time

import pytest

# Coverage counters of the instrumented candidate are only flushed on clean
# process exit, so GOCOVERDIR must be copied from the test process env into
# the child env (and the child is asked to quit before it is killed).
PASSTHROUGH_ENV = ("GOCOVERDIR",)

# Fully pinned child environment: no dependence on the invoking shell.
PINNED_ENV = {
    "TERM": "xterm",
    "LANG": "C",
    "LC_ALL": "C",
    "SHELL": "/bin/sh",
    "EDITOR": "vi",
    "PAGER": "cat",
    "OPENER": "true",
    "LF_LEVEL": "1",
    "PATH": "/usr/bin:/bin",
}

DEFAULT_FILES = ("a.txt", "b.txt", "c.txt", "zeta.md")

ROWS = 24
COLS = 80
MENU_ROW = 22  # first menu line, right above the bottom ruler row


def lf_executable() -> str:
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not exe:
        raise RuntimeError("PROGRAMGYM_EXECUTABLE is not set")
    return exe


# --------------------------------------------------------------------------
# key translation: readable tokens -> bytes a terminal would send
# --------------------------------------------------------------------------

KEYMAP = {
    "<enter>": "\r",
    "<cr>": "\r",
    "<lf>": "\n",
    "<tab>": "\t",
    "<esc>": "\x1b",
    "<backspace>": "\x7f",
    "<delete>": "\x1b[3~",
    "<up>": "\x1b[A",
    "<down>": "\x1b[B",
    "<right>": "\x1b[C",
    "<left>": "\x1b[D",
    "<home>": "\x1b[H",
    "<end>": "\x1b[F",
    "<pgup>": "\x1b[5~",
    "<pgdn>": "\x1b[6~",
    "<f-1>": "\x1bOP",
    "<f-2>": "\x1bOQ",
    "<f-3>": "\x1bOR",
    "<f-4>": "\x1bOS",
    "<f-5>": "\x1b[15~",
    "<f-6>": "\x1b[17~",
    "<f-7>": "\x1b[18~",
    "<f-8>": "\x1b[19~",
    "<a-backspace>": "\x1b\x7f",
}

TOKEN_RE = re.compile(r"<(c|a)-([A-Za-z0-9])>")


def key_bytes(s: str) -> bytes:
    """Translate a readable key string into the byte sequence to write."""
    for name, val in KEYMAP.items():
        s = s.replace(name, val)
    out = []
    i = 0
    while i < len(s):
        m = TOKEN_RE.match(s, i)
        if m:
            ch = m.group(2).lower()
            if m.group(1) == "c":
                out.append(chr(ord(ch) - 96))
            else:
                out.append("\x1b" + ch)
            i = m.end()
        else:
            out.append(s[i])
            i += 1
    return "".join(out).encode()


# --------------------------------------------------------------------------
# minimal VT100 screen emulation (enough for lf's drawing)
# --------------------------------------------------------------------------

CSI_RE = re.compile(r"\x1b\[([0-9;?<>=!$#\"' ]*)([A-Za-z@~])")
OSC_RE = re.compile(r"\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")
STR_RE = re.compile(r"\x1b[PX^_][^\x07\x1b]*(?:\x07|\x1b\\)")
SIMPLE_RE = re.compile(r"\x1b[=>78MDEHc%]")
SS3_RE = re.compile(r"\x1bO[A-Za-z]")


class Screen:
    def __init__(self, rows, cols):
        self.rows, self.cols = rows, cols
        self.buf = [[" "] * cols for _ in range(rows)]
        self.r = self.c = 0
        self.pending = ""

    def _put(self, ch):
        if self.r < self.rows and self.c < self.cols:
            self.buf[self.r][self.c] = ch
        self.c = min(self.c + 1, self.cols - 1)

    def _nums(self, params, default=1):
        out = []
        for part in params.replace("?", "").split(";"):
            digits = ""
            for ch in part:
                if ch.isdigit():
                    digits += ch
                else:
                    break
            out.append(int(digits) if digits else default)
        return out or [default]

    def _csi(self, params, fin):
        n = self._nums(params)
        if fin in "Hf":
            self.r = max(0, min(self.rows - 1, n[0] - 1))
            self.c = max(0, min(self.cols - 1, (n[1] if len(n) > 1 else 1) - 1))
        elif fin == "A":
            self.r = max(0, self.r - n[0])
        elif fin == "B":
            self.r = min(self.rows - 1, self.r + n[0])
        elif fin == "C":
            self.c = min(self.cols - 1, self.c + n[0])
        elif fin == "D":
            self.c = max(0, self.c - n[0])
        elif fin == "G":
            self.c = max(0, min(self.cols - 1, n[0] - 1))
        elif fin == "d":
            self.r = max(0, min(self.rows - 1, n[0] - 1))
        elif fin == "E":
            self.r = min(self.rows - 1, self.r + n[0])
            self.c = 0
        elif fin == "F":
            self.r = max(0, self.r - n[0])
            self.c = 0
        elif fin == "J":
            mode = n[0]
            if mode == 0:
                for c in range(self.c, self.cols):
                    self.buf[self.r][c] = " "
                for r in range(self.r + 1, self.rows):
                    self.buf[r] = [" "] * self.cols
            elif mode in (2, 3):
                self.buf = [[" "] * self.cols for _ in range(self.rows)]
            else:
                for r in range(0, self.r + 1):
                    self.buf[r] = [" "] * self.cols
        elif fin == "K":
            mode = n[0]
            if mode == 0:
                for c in range(self.c, self.cols):
                    self.buf[self.r][c] = " "
            elif mode == 1:
                for c in range(0, self.c + 1):
                    self.buf[self.r][c] = " "
            else:
                self.buf[self.r] = [" "] * self.cols
        elif fin == "L":
            for _ in range(n[0]):
                self.buf.insert(self.r, [" "] * self.cols)
                del self.buf[-1]
        elif fin == "M":
            for _ in range(n[0]):
                del self.buf[self.r]
                self.buf.append([" "] * self.cols)
        elif fin == "P":
            row = self.buf[self.r]
            del row[self.c:self.c + n[0]]
            row.extend([" "] * n[0])
        elif fin == "@":
            row = self.buf[self.r]
            for _ in range(n[0]):
                row.insert(self.c, " ")
            del row[self.cols:]
        elif fin == "X":
            row = self.buf[self.r]
            for i in range(n[0]):
                if self.c + i < self.cols:
                    row[self.c + i] = " "

    def feed(self, data):
        self.pending += data
        i = 0
        s = self.pending
        while i < len(s):
            ch = s[i]
            if ch == "\x1b":
                m = (CSI_RE.match(s, i) or OSC_RE.match(s, i) or STR_RE.match(s, i)
                     or SIMPLE_RE.match(s, i) or SS3_RE.match(s, i))
                if m:
                    if m.re is CSI_RE:
                        self._csi(m.group(1), m.group(2))
                    i = m.end()
                    continue
                if i == len(s) - 1:
                    break  # incomplete escape sequence
                i += 1
                continue
            if ch == "\r":
                self.c = 0
            elif ch == "\n":
                self.r = min(self.rows - 1, self.r + 1)
            elif ch == "\b":
                self.c = max(0, self.c - 1)
            elif ch >= " ":
                self._put(ch)
            i += 1
        self.pending = s[i:]

    def lines(self):
        return ["".join(r).rstrip() for r in self.buf]


class LfSession:
    """One lf process on a pty plus everything needed to inspect it."""

    def __init__(self, argv, cwd, env, rows=ROWS, cols=COLS):
        self.rows, self.cols = rows, cols
        self.screen = Screen(rows, cols)
        self.raw = bytearray()
        self.alive = True
        self.exited = False
        self.status = None
        self.root = None
        self.data_dir = None
        self.cwd = None
        self.pid, self.fd = pty.fork()
        if self.pid == 0:  # child
            try:
                os.chdir(str(cwd))
                e = dict(os.environ)
                e.update(env)
                os.execve(argv[0], list(argv), e)
            except Exception:
                os._exit(127)
        fcntl.ioctl(self.fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        # tcell probes the terminal at startup and only draws after the probe
        # reply times out, so wait for a substantial chunk of output first.
        self.wait_for(lambda s: len(s.raw) > 400, timeout=5.0)
        self.wait_ready()

    def wait_ready(self, timeout=5.0):
        """Wait until the initial directory listing (with counts) is drawn."""
        end = time.time() + 1.0
        while time.time() < end:
            m = re.search(r"(\d+)/(\d+)\s*$", self.bottom())
            if m and m.group(2) != "0":
                break
            self._read(0.05)
        self.wait(quiet=0.25, timeout=3.0)

    # -- plumbing ----------------------------------------------------------
    def _read(self, timeout):
        try:
            r, _, _ = select.select([self.fd], [], [], timeout)
        except OSError:
            self.alive = False
            return False
        if not r:
            return False
        try:
            data = os.read(self.fd, 65536)
        except OSError:
            self.alive = False
            return False
        if not data:
            self.alive = False
            return False
        self.raw.extend(data)
        self.screen.feed(data.decode("utf-8", "replace"))
        return True

    def wait(self, quiet=0.25, timeout=8.0):
        """Read until no new output arrives for `quiet` seconds."""
        end = time.time() + timeout
        while time.time() < end:
            if not self._read(quiet):
                return

    def wait_for(self, pred, timeout=6.0):
        end = time.time() + timeout
        while time.time() < end:
            if pred(self):
                return True
            self._read(0.05)
        return pred(self)

    def send(self, s):
        """Send keys, expanding readable tokens like <tab> and <c-c>."""
        data = key_bytes(s) if isinstance(s, str) else s
        try:
            os.write(self.fd, data)
        except OSError:
            self.alive = False

    def send_literal(self, text):
        """Send text verbatim, so '<down>' reaches lf as six characters."""
        try:
            os.write(self.fd, text.encode())
        except OSError:
            self.alive = False

    # -- inspection --------------------------------------------------------
    def lines(self):
        return self.screen.lines()

    def bottom(self):
        return self.lines()[-1]

    def top(self):
        return self.lines()[0]

    def menu(self):
        return self.lines()[MENU_ROW]

    def raw_text(self):
        return bytes(self.raw).decode("utf-8", "replace")

    def exit_code(self, timeout=6.0):
        end = time.time() + timeout
        while time.time() < end:
            self._read(0.05)
            try:
                pid, st = os.waitpid(self.pid, os.WNOHANG)
            except ChildProcessError:
                return self.status
            if pid:
                self.status = st
                self.exited = True
                return st
            time.sleep(0.02)
        return None

    def close(self):
        """Try to quit cleanly (flushes coverage), then make sure it is dead."""
        if self.exited:
            return
        # A bare 'q' is typed into the command line when a prompt, completion
        # menu, visual mode or modal is still open, so lf would have to be
        # SIGKILLed and its Go coverage counters would never be flushed.
        # Escaping first returns lf to normal mode where 'q' quits; '<c-c>'
        # additionally interrupts a running pipe ('%') command. Tests that
        # end after ':clearmaps' have no 'q' binding left, so ':quit' is the
        # last resort before the kill.
        for prefix in ("<esc>", "<c-c><esc>"):
            self.send(prefix)
            self.wait(quiet=0.15, timeout=1.0)
            self.send("q")
            self.exit_code(timeout=1.2)
            if self.exited:
                return
        self.send(":quit\r")
        self.exit_code(timeout=1.5)
        if self.exited:
            return
        try:
            os.close(self.fd)
        except OSError:
            pass
        try:
            os.kill(self.pid, 9)
        except OSError:
            pass
        try:
            os.waitpid(self.pid, 0)
        except Exception:
            pass
        self.exited = True


def _child_env(root, extra_env, extra_path):
    env = dict(PINNED_ENV)
    env["HOME"] = str(root / "home")
    env["XDG_CONFIG_HOME"] = str(root / "home" / ".config")
    env["XDG_DATA_HOME"] = str(root / "home" / ".local" / "share")
    env["XDG_RUNTIME_DIR"] = str(root / "run")
    env["XDG_CACHE_HOME"] = str(root / "home" / ".cache")
    # GOCOVERDIR from the test process env must reach the candidate binary.
    cov_env = {"GOCOVERDIR": v} if (v := os.environ.get("GOCOVERDIR")) else {}
    env.update(cov_env)
    if extra_path:
        env["PATH"] = extra_path + ":" + env["PATH"]
    if extra_env:
        env.update(extra_env)
    return env


@pytest.fixture
def run_lf(tmp_path_factory):
    """Factory that starts lf on a fresh, deterministic directory tree."""
    sessions = []

    def _run(
        script=(),
        files=None,
        cfg=None,
        args=(),
        extra_env=None,
        extra_path=None,
        seed_history=None,
        seed_files=None,
        xdg_lfrc=None,
        rows=ROWS,
        cols=COLS,
        single=True,
        path_bins=(),
        path2_bins=(),
        path_file=False,
        tools=None,
    ):
        root = tmp_path_factory.mktemp("lfrun")
        home = root / "home"
        data = home / ".local" / "share" / "lf"
        data.mkdir(parents=True, exist_ok=True)
        # XDG_RUNTIME_DIR must exist: in server mode (no -single) lf listens
        # on $XDG_RUNTIME_DIR/lf.sock and never finishes connecting otherwise.
        (root / "run").mkdir(parents=True, exist_ok=True)
        cwd = root / "tree" / "cwd"
        (cwd / "sub").mkdir(parents=True)
        (cwd / "sub" / "deep.txt").write_text("deep\n")
        (cwd / "other").mkdir()
        names = DEFAULT_FILES if files is None else files
        for name in names:
            (cwd / name).write_text("content\n")
        if seed_history is not None:
            data.mkdir(parents=True, exist_ok=True)
            (data / "history").write_text("".join(l + "\n" for l in seed_history))
        if seed_files is not None:
            # pre-seeded clipboard file: a bad first line or an empty file
            # exercises the startup error paths of the files file
            data.mkdir(parents=True, exist_ok=True)
            (data / "files").write_text(seed_files)
        if xdg_lfrc is not None:
            # config picked up when no -config is passed on the command line
            xdg_cfg = home / ".config" / "lf"
            xdg_cfg.mkdir(parents=True, exist_ok=True)
            (xdg_cfg / "lfrc").write_text(xdg_lfrc)

        extra_path = None
        if path_bins:
            bindir = root / "bin"
            bindir.mkdir()
            # entries are tool names; a (name, mode) tuple creates the tool
            # with that file mode (e.g. 0o644 for a non-executable file)
            for entry in path_bins:
                name, mode = entry if isinstance(entry, tuple) else (entry, 0o755)
                tool = bindir / name
                tool.write_text("#!/bin/sh\nexit 0\n")
                tool.chmod(mode)
            extra_path = str(bindir)
        if path2_bins:
            bindir2 = root / "bin2"
            bindir2.mkdir()
            for name in path2_bins:
                tool = bindir2 / name
                tool.write_text("#!/bin/sh\nexit 0\n")
                tool.chmod(0o755)
            extra_path = ":".join(filter(None, [extra_path, str(bindir2)]))
        if path_file:
            # a regular file placed in PATH: reading it as a directory fails
            # (ENOTDIR), unlike a nonexistent entry
            block = root / "blockfile"
            block.write_text("not a directory\n")
            extra_path = ":".join(filter(None, [str(block), extra_path]))

        tool_env = {}
        if tools:
            tdir = root / "tools"
            tdir.mkdir()
            for var, body in tools.items():
                text = body(root) if callable(body) else body
                tool_path = tdir / (var.lower() + ".sh")
                tool_path.write_text(text)
                tool_path.chmod(0o755)
                tool_env[var] = str(tool_path)
        if tool_env:
            extra_env = dict(extra_env or {})
            extra_env.update(tool_env)

        argv = [lf_executable()]
        if single:
            argv.append("-single")
        if cfg is not None:
            cfg_path = root / "lfrc"
            cfg_path.write_text(cfg(root) if callable(cfg) else cfg)
            argv += ["-config", str(cfg_path)]
        # args may be a callable (or contain callables) receiving the run
        # root, so tests can pass flags (e.g. -log) pointing at files
        # inside the sandbox
        if callable(args):
            args = args(root)
            if isinstance(args, str):
                args = [args]
        else:
            args = [a(root) if callable(a) else a for a in args]
        argv += list(args)

        env = _child_env(root, extra_env, extra_path)
        sess = LfSession(argv, cwd, env, rows=rows, cols=cols)
        sess.root = root
        sess.data_dir = data
        sess.cwd = cwd
        # kept for tests that spawn extra processes (e.g. -remote clients)
        # that must see exactly the same environment as the TUI
        sess.env = env
        sessions.append(sess)
        for keys_, quiet in script:
            sess.send(keys_)
            sess.wait(quiet=quiet)
        return sess

    yield _run

    for s in sessions:
        s.close()
