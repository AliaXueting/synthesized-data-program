"""User commands defined with cmd, their arguments, the built-in defaults
(open/editor/pager/help/maps), and the map/nmap/vmap commands."""

import pytest


def test_user_command_receives_arguments(run_lf):
    """Arguments of a user command arrive as $1.. after a '--' $0."""
    # CATCHES: candidates that expand $#/$0/$1 inside lf (instead of letting
    # the shell see them) or that drop the '--' separator ($0 differs).
    s = run_lf(script=[(":myecho one two\r", 0.9)],
               cfg='cmd myecho ${{ echo "n=$# a0=$0 a1=$1 a2=$2" }}')
    assert "n=2 a0=-- a1=one a2=two" in s.raw_text()


def test_user_command_quoted_arguments(run_lf):
    """Quoted arguments keep their spaces as a single $1."""
    # CATCHES: candidates whose tokenizer splits quoted arguments, which
    # would print arg1=[a] arg2=[b] arg3=[c] instead.
    s = run_lf(script=[(':pc "a b" c\r', 0.9)],
               cfg='cmd pc ${{ echo "arg1=[$1] arg2=[$2]" }}')
    assert "arg1=[a b] arg2=[c]" in s.raw_text()


def test_user_command_argv_composition(run_lf):
    """A '{{ }}' body is passed as the shell script, args follow '--'."""
    # CATCHES: candidates that substitute $1 themselves before running the
    # body (the literal $1 must survive into /bin/echo's output) or that
    # forget the spaces padding the multi-line body.
    s = run_lf(script=[(":show one two\r", 0.9)],
               cfg="set shell /bin/echo\ncmd show ${{ BEGIN-$1-MID-$2-END }}")
    assert "-c  BEGIN-$1-MID-$2-END  -- one two" in s.raw_text()
    s.close()

    s = run_lf(script=[(":show\r", 0.9)],
               cfg="set shell /bin/echo\ncmd show ${{ BEGIN-$1-MID-$2-END }}")
    assert "-c  BEGIN-$1-MID-$2-END  --" in s.raw_text()


def test_user_command_single_line_body(run_lf):
    """A single-line '$' body is passed through verbatim."""
    # CATCHES: candidates that pad single-line bodies with spaces like the
    # multi-line form, or that strip the '$' incorrectly.
    s = run_lf(script=[(":dollar one\r", 0.9)],
               cfg="set shell /bin/echo\ncmd dollar $ DOLLAR-$1-DOLLAR")
    assert "-c DOLLAR-$1-DOLLAR -- one" in s.raw_text()


def test_command_redefinition_without_body_deletes(run_lf):
    """Redefining a command with no body removes it again."""
    # CATCHES: candidates that treat the empty redefinition as a no-op;
    # invoking the deleted command must report it as unknown.
    s = run_lf(script=[(":foo\r", 0.5)],
               cfg="cmd foo :echo fromfoo\ncmd foo\n")
    assert s.bottom().startswith("command not found: foo")


def test_builtin_commands_shadow_user_commands(run_lf):
    """A user command cannot override a built-in command name."""
    # CATCHES: candidates that look up user commands before built-ins; the
    # built-in :echo must run and print its own argument.
    s = run_lf(script=[(":echo hello\r", 0.7)],
               cfg="cmd echo ${{ echo OVERRIDDEN }}")
    assert s.bottom().startswith("hello")
    assert "OVERRIDDEN" not in s.raw_text()


def test_colon_body_passes_arguments_literally(run_lf):
    """A ':' body runs nested commands with '$1' left untouched."""
    # CATCHES: candidates that substitute $1 inside ':' bodies (the message
    # must show the literal string, not the passed argument).
    s = run_lf(script=[(":outer PASSED\r", 0.6)],
               cfg="cmd inner :echo inner-$1\ncmd outer :inner \"$1\"\n")
    assert s.bottom().startswith("inner-$1")


def test_default_open_editor_and_pager(run_lf):
    """The default open/e/i commands call $OPENER, $EDITOR and $PAGER."""
    # CATCHES: candidates that hardcode xdg-open/vi/less instead of the
    # environment variables, or that mix up which key invokes which tool.
    def opener(root):
        return "#!/bin/sh\necho \"OPENER $*\" >> %s\n" % (root / "tools.log")

    def editor(root):
        return "#!/bin/sh\necho \"EDITOR $*\" >> %s\n" % (root / "tools.log")

    def pager(root):
        return "#!/bin/sh\necho \"PAGER $*\" >> %s\n" % (root / "tools.log")

    s = run_lf(script=[("3j", 0.3), ("l", 0.8), ("e", 0.8), ("i", 0.8)],
               tools={"OPENER": opener, "EDITOR": editor, "PAGER": pager})
    log = (s.root / "tools.log").read_text()
    assert log == ("OPENER %s\nEDITOR %s\nPAGER %s\n"
                   % (s.cwd / "b.txt", s.cwd / "b.txt", s.cwd / "b.txt"))


def test_help_prints_documentation(run_lf):
    """:help pipes the full documentation through $PAGER to the terminal."""
    # CATCHES: candidates whose :help prints nothing (or a short message);
    # the raw stream must contain the documented cmap bindings section.
    s = run_lf(script=[(":help\r", 2.5)])
    assert "cmd-menu-complete" in s.raw_text()
    assert "on-focus-gained" in s.raw_text()


def test_maps_without_server_errors(run_lf):
    """:maps without a server reports a connection failure."""
    # CATCHES: candidates that print a maps listing even in single mode
    # instead of trying (and failing) to reach the remote server.
    s = run_lf(script=[(":maps\r", 1.2)])
    assert "remote command: connecting to server" in s.raw_text()


def test_map_define_and_undefine(run_lf):
    """map with no expression removes the binding again."""
    # CATCHES: candidates whose bare 'map X' is a no-op; the key must be
    # unbound afterwards and report the unknown mapping.
    s = run_lf(script=[("X", 0.5)], cfg="map X :echo mappedX\nmap X\n")
    assert s.bottom().startswith("unknown mapping: X")
    s.close()

    s = run_lf(script=[("Y", 0.5)])
    assert s.bottom().startswith("unknown mapping: Y")


def test_nmap_and_vmap_are_mode_scoped(run_lf):
    """nmap binds only in normal mode, vmap only in visual mode."""
    # CATCHES: candidates that install mode maps globally; the vmap key must
    # stay unbound in normal mode and the nmap key must work without V.
    s = run_lf(script=[("J", 0.5)], cfg="nmap J :echo nmapJ\n")
    assert s.bottom().startswith("nmapJ")
    s.close()

    s = run_lf(script=[("V", 0.3), ("K", 0.5)], cfg="vmap K :echo vmapK\n")
    assert s.bottom().startswith("vmapK")
    assert s.bottom().endswith("1   1/6")
    s.close()

    s = run_lf(script=[("K", 0.5)], cfg="vmap K :echo vmapK\n")
    assert s.bottom().startswith("unknown mapping: K")


def test_map_with_special_key_syntax(run_lf):
    """map accepts special key names like <f-2> typed in the command line."""
    # CATCHES: candidates whose scanner mangles '<f-2>' when the command is
    # typed interactively (only config-file definitions working).
    s = run_lf(script=[])
    s.send_literal(":map <f-2> :echo fx2\r")
    s.wait(quiet=0.5)
    s.send("<f-2>")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("fx2")
