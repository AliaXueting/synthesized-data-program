"""Completion engine paths not covered elsewhere: list-valued options,
boolean option values, the map expression word, setlocal, file arguments of
select/source, user command names and per-argument file completion."""

import pytest


def test_info_option_list_completion(run_lf):
    """Tab after ':set info ' lists values; already-given ones are excluded."""
    # CATCHES: candidates that cannot complete colon-joined list values or
    # that offer 'size' again although it is already part of the value.
    s = run_lf(script=[(":set info ", 0.4), ("<tab>", 0.5)])
    assert s.menu() == ("atime   btime   ctime   custom  group   perm    size"
                        "    time    user")
    s.send("\x1b")
    s.wait(quiet=0.3)
    s.send_literal(":set info size:")
    s.wait(quiet=0.4)
    s.send("<tab>")
    s.wait(quiet=0.5)
    assert s.bottom() == ":set info size:"
    assert s.menu() == "atime   btime   ctime   custom  group   perm    time    user"


def test_bool_option_value_completion(run_lf):
    """Tab after a boolean option name offers false and true."""
    # CATCHES: candidates that complete nothing after plain boolean option
    # names (only the '!' form shows no menu in the reference).
    s = run_lf(script=[(":set hidden ", 0.4), ("<tab>", 0.5)])
    assert s.menu() == "false   true"
    assert s.bottom() == ":set hidden"


def test_borderstyle_value_completion(run_lf):
    """Tab after ':set borderstyle ' lists the border style names."""
    # CATCHES: candidates with a different set of style names or ordering.
    s = run_lf(script=[(":set borderstyle ", 0.4), ("<tab>", 0.5)])
    assert s.menu() == "box             roundbox        outline         roundoutline    separators"


def test_map_expression_completion(run_lf):
    """The word after 'map X ' completes command names, including user ones."""
    # CATCHES: candidates that only complete the map key but not the mapped
    # expression, or that leave user-defined commands out of the list.
    s = run_lf(script=[(":map X se", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":map X se"
    assert s.menu() == "set             setfilter       setlocal"
    s.close()

    s = run_lf(script=[(":map X myc", 0.4), ("<tab>", 0.5)],
               cfg="cmd mycmd :echo hi")
    assert s.bottom() == ":map X mycmd"
    assert s.menu() == ""


def test_setlocal_completes_directories(run_lf):
    """The first setlocal argument completes directories only."""
    # CATCHES: candidates that reuse the plain file completer for setlocal
    # (regular files like a.txt must not be offered).
    s = run_lf(script=[(":setlocal ", 0.4), ("<tab>", 0.5)])
    assert s.menu() == "other/  sub/"


@pytest.mark.parametrize("cmd", [":select ", ":source "])
def test_select_and_source_complete_files(run_lf, cmd):
    """select and source complete both files and directories."""
    # CATCHES: candidates that complete nothing for these commands while
    # still completing paths for cd or toggle.
    s = run_lf(script=[(cmd, 0.4), ("<tab>", 0.5)])
    assert s.menu() == "a.txt   b.txt   c.txt   other/  sub/    zeta.md"


def test_user_command_name_completion(run_lf):
    """A user-defined command name is completed like a built-in one."""
    # CATCHES: candidates whose command completion only knows the built-in
    # word list and misses names defined with cmd.
    s = run_lf(script=[(":my", 0.4), ("<tab>", 0.5)], cfg="cmd mytool :echo hi")
    assert s.bottom() == ":mytool"
    assert s.menu() == ""


def test_toggle_completes_each_argument(run_lf):
    """File completion in :toggle works for every argument position."""
    # CATCHES: candidates that only complete the first argument of a command
    # with variable argument counts.
    s = run_lf(script=[(":toggle a.txt b", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":toggle a.txt b.txt"
    assert s.menu() == ""


def test_unknown_command_completes_files(run_lf):
    """An unknown first word falls back to file completion for its argument."""
    # CATCHES: candidates that refuse to complete anything after a word that
    # is neither a known command nor a defined user command.
    s = run_lf(script=[(":nosuchcmd ze", 0.4), ("<tab>", 0.5)])
    assert s.bottom() == ":nosuchcmd zeta.md"
    assert s.menu() == ""
