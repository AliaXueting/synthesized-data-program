"""Remaining ':' commands and prompt behaviors: clearmaps, source,
calcdirsize, addcustominfo, updir, jumps, view scrolling, cmd-transpose-word,
the $lf_mode export, incremental search/filter, and the *maps listing
commands in single mode."""

import pytest

MANY_FILES = ["f%02d.txt" % i for i in range(26)]


def _pane_names(s, row, count=4):
    """Names shown in the current-directory pane starting at `row`."""
    return [s.lines()[row + i][15:30].strip() for i in range(count)]


def test_clearmaps_unbinds_all_keys(run_lf):
    """:clearmaps removes every normal and visual binding except ':'."""
    # CATCHES: candidates that keep default bindings alive (j would still
    # move the cursor) or that also clear the ':' command prompt.
    s = run_lf(script=[(":clearmaps\r", 0.5)])
    s.send("j")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("unknown mapping: j")
    assert s.bottom().endswith("1/6")
    s.send("V")
    s.wait(quiet=0.4)
    assert s.bottom().startswith("unknown mapping: V")
    s.send(":echo stillworks\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("stillworks")


def test_source_reads_extra_config(run_lf):
    """:source evaluates another config file mid-session."""
    # CATCHES: candidates that ignore sourced files (the command and mapping
    # defined in it must become active) or that accept it without an argument.
    s = run_lf(script=[])
    extra = s.root / "extra.rc"
    extra.write_text("cmd sourced :echo FROM-SOURCE\n"
                     "map S :echo mappedS\n")
    s.send(":source %s\r" % extra)
    s.wait(quiet=0.6)
    s.send(":sourced\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("FROM-SOURCE")
    s.send("S")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("mappedS")
    s.close()

    s = run_lf(script=[(":source\r", 0.5)])
    assert s.bottom().startswith("source: requires an argument")
    s.send(":source /no/such/file\r")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("opening file: open /no/such/file: no such file or directory")


def test_calcdirsize(run_lf):
    """:calcdirsize computes the disk usage of the directory under the cursor."""
    # CATCHES: candidates that calculate every directory at once (other would
    # also show a size) or that never calculate (sub would stay '-').
    s = run_lf(script=[("j", 0.4), (":calcdirsize\r", 0.9)], cfg="set info size")
    assert s.lines()[2].split() == ["sub", "4.0K"]
    # row 1 also shows the parent entry in the left pane, hence [1:3]
    assert s.lines()[1].split()[1:3] == ["other", "-"]


def test_addcustominfo(run_lf):
    """:addcustominfo attaches a custom string to a file's info line."""
    # CATCHES: candidates that never render the custom info column, that
    # cannot clear it again, or that skip the argument validation errors.
    # a wide terminal so the long 'file not found' path is not truncated
    s = run_lf(script=[("jj", 0.3), (":addcustominfo a.txt MARKER-99\r", 0.6)],
               cfg="set info custom", cols=140)
    assert s.lines()[3].split() == ["a.txt", "MARKER-99"]
    s.send(":addcustominfo a.txt\r")
    s.wait(quiet=0.5)
    assert s.lines()[3].split() == ["a.txt"]
    s.send(":addcustominfo\r")
    s.wait(quiet=0.4)
    assert s.bottom().startswith("addcustominfo: requires either 1 or 2 arguments")
    s.send(":addcustominfo nope.txt x\r")
    s.wait(quiet=0.4)
    assert s.bottom().startswith("addcustominfo: file not found: %s" % (s.cwd / "nope.txt"))


def test_updir_moves_to_parent(run_lf):
    """h (:updir) changes to the parent and puts the cursor on the old dir."""
    # CATCHES: candidates that stay in place at the filesystem root edge or
    # that lose the cursor position when going up one directory.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[("h", 0.6)], cols=140)
    assert s.top().endswith(str(s.cwd))
    assert s.bottom().endswith("1/1")


def test_jump_prev_and_next(run_lf):
    """[ and ] walk back and forward through the directory jump list."""
    # CATCHES: candidates without a jump list, or whose ] does not redo the
    # jump that [ just undid.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[("h", 0.5)], cols=140)
    assert s.top().endswith(str(s.cwd))
    s.send("[")
    s.wait(quiet=0.5)
    assert s.top().endswith(str(s.cwd / "other"))
    assert s.bottom().endswith("1/6")
    s.send("]")
    s.wait(quiet=0.5)
    assert s.top().endswith(str(s.cwd))
    assert s.bottom().endswith("1/1")


def test_high_middle_low(run_lf):
    """H/M/L move the cursor to the top, middle and bottom of the view."""
    # CATCHES: candidates that treat these as plain first/last-entry jumps;
    # the recorded positions are relative to the visible window.
    s = run_lf(script=[("G", 0.4)], files=MANY_FILES)
    assert s.bottom().endswith("28/28")
    s.send("H")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("7/28")
    s.send("M")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("18/28")
    s.send("L")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("28/28")


def test_scroll_moves_view_not_cursor(run_lf):
    """Ctrl-Y/Ctrl-E scroll the view while the cursor keeps its entry."""
    # CATCHES: candidates that implement scrolling as plain cursor movement
    # (the index would change) or that cannot scroll with the cursor mid-view.
    s = run_lf(script=[("G", 0.3), ("kkk", 0.4)], files=MANY_FILES)
    assert s.bottom().endswith("25/28")
    assert _pane_names(s, 1)[0] == "f04.txt"
    s.send("<c-y>")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("25/28")
    assert _pane_names(s, 1)[0] == "f03.txt"
    s.send("<c-e>")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("25/28")
    assert _pane_names(s, 1)[0] == "f04.txt"
    s.send("gg")
    s.wait(quiet=0.3)
    s.send("jj")
    s.wait(quiet=0.4)
    assert _pane_names(s, 1)[0] == "other"
    s.send("<c-e>")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("3/28")
    assert _pane_names(s, 1)[0] == "sub"


def test_transpose_word(run_lf):
    """Alt-T swaps the two words before the cursor in the command line."""
    # CATCHES: candidates that leave Alt-T unbound or transpose characters
    # instead of whole words.
    s = run_lf(script=[])
    s.send_literal(":one two")
    s.wait(quiet=0.3)
    s.send("<a-t>")
    s.wait(quiet=0.4)
    assert s.bottom() == ":two one"


def test_lf_mode_variable(run_lf):
    """$lf_mode exported to shell commands reflects the current mode."""
    # CATCHES: candidates that never export lf_mode, or that report the
    # command-line mode for key-mapped shell commands.
    cfg = ('cmd showmode ${{ echo "LFMODE-VALUE=[$lf_mode]" }}\n'
           'map M ${{ echo "LFMODE-VALUE=[$lf_mode]" }}\n'
           'vmap M ${{ echo "LFMODE-VALUE=[$lf_mode]" }}\n')
    s = run_lf(script=[("M", 0.8)], cfg=cfg)
    assert "LFMODE-VALUE=[normal]" in s.raw_text()
    s.send("V")
    s.wait(quiet=0.3)
    s.send("M")
    s.wait(quiet=0.8)
    assert "LFMODE-VALUE=[visual]" in s.raw_text()
    s.send("<esc>")
    s.wait(quiet=0.3)
    s.send(":showmode\r")
    s.wait(quiet=0.8)
    assert s.raw_text().count("LFMODE-VALUE=[normal]") == 2


def test_incsearch_moves_cursor_while_typing(run_lf):
    """set incsearch jumps to matches while the pattern is being typed."""
    # CATCHES: candidates that wait for Enter before searching; the header
    # must show the matched file while the prompt still contains the pattern.
    # A wide terminal keeps the absolute path in the header un-abbreviated.
    s = run_lf(script=[], cfg="set incsearch", cols=140)
    s.send("/")
    s.wait(quiet=0.3)
    s.send("z")
    s.wait(quiet=0.6)
    assert s.bottom() == "/z"
    assert s.top().endswith(str(s.cwd / "zeta.md"))
    s.send("\r")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("6/6")


def test_incfilter_filters_listing_while_typing(run_lf):
    """set incfilter narrows the listing while the filter prompt is open."""
    # CATCHES: candidates that only apply the filter on Enter; the pane must
    # drop non-matching entries while 'filter: ' still shows the pattern.
    s = run_lf(script=[], cfg="set incfilter")
    s.send(":filter\r")
    s.wait(quiet=0.4)
    assert s.bottom() == "filter:"
    s.send(".")
    s.wait(quiet=0.6)
    assert s.bottom() == "filter: ."
    assert _pane_names(s, 1) == ["a.txt", "b.txt", "c.txt", "zeta.md"]
    s.send("txt")
    s.wait(quiet=0.7)
    assert s.bottom() == "filter: .txt"
    assert _pane_names(s, 1) == ["a.txt", "b.txt", "c.txt", ""]
    s.send("\r")
    s.wait(quiet=0.5)
    assert s.bottom().endswith(".txt   1/3")


@pytest.mark.parametrize("cmd", [":nmaps\r", ":vmaps\r", ":cmaps\r"])
def test_mode_map_listings_need_a_server(run_lf, cmd):
    """The default nmaps/vmaps/cmaps commands query the server and fail."""
    # CATCHES: candidates that print a local listing in single mode instead
    # of going through the remote command interface like :maps does.
    s = run_lf(script=[(cmd, 1.2)])
    assert "remote command: connecting to server" in s.raw_text()
