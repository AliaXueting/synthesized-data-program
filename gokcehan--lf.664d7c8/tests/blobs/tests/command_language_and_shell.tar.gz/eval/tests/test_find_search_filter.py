"""find/find-back/find-next/find-prev, the search family, and filtering."""

import pytest

FFILES = ["f1.txt", "f2.txt", "f3.txt"]


def test_find_prompt_moves_and_reports_miss(run_lf):
    """The find prompt jumps to prefix matches and reports misses."""
    # CATCHES: candidates that treat find as substring search (the 'z'
    # match must be found by prefix) or that stay silent on a miss.
    s = run_lf(script=[(":find\r", 0.3), ("z", 0.6)])
    assert s.bottom().endswith("6/6")
    s.send(":find\r")
    s.wait(quiet=0.3)
    s.send("q")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("find: pattern not found: q")
    s.send("G")
    s.wait(quiet=0.3)
    s.send(":find-back\r")
    s.wait(quiet=0.3)
    s.send("t")
    s.wait(quiet=0.5)
    assert s.bottom().startswith("find-back: pattern not found: t")


def test_find_next_cycles_with_wrapscan(run_lf):
    """find-next steps through matches and wraps around at the end."""
    # CATCHES: candidates whose find-next stops at the last match or whose
    # wrap lands on a non-matching entry.
    s = run_lf(script=[(":find\r", 0.3), ("f", 0.3), (";", 0.3), (";", 0.3),
                       (";", 0.5)], files=FFILES)
    assert s.bottom().endswith("3/5")
    s.close()

    s = run_lf(script=[(":find\r", 0.3), ("f", 0.3), (";", 0.5)], files=FFILES)
    assert s.bottom().endswith("4/5")
    s.close()

    s = run_lf(script=[(":find\r", 0.3), ("f", 0.3), (";", 0.3), (";", 0.5)],
               files=FFILES)
    assert s.bottom().endswith("5/5")


def test_find_prev_steps_back(run_lf):
    """find-prev (comma) walks back to the previous match."""
    # CATCHES: candidates that bind comma to find-next as well; after one
    # forward step the comma must return to the first match.
    s = run_lf(script=[(":find\r", 0.3), ("f", 0.3), (";", 0.3), (",", 0.5)],
               files=FFILES)
    assert s.bottom().endswith("3/5")


def test_find_next_stops_without_wrapscan(run_lf):
    """set nowrapscan stops find-next at the last match."""
    # CATCHES: candidates that always wrap; the cursor must stay on the
    # last match after running out of entries.
    s = run_lf(script=[(":find\r", 0.3), ("f", 0.3), (";", 0.3), (";", 0.3),
                       (";", 0.3), (";", 0.5)],
               cfg="set nowrapscan", files=FFILES)
    assert s.bottom().endswith("5/5")


def test_anchorfind_controls_prefix_matching(run_lf):
    """Default find anchors at the name start; noanchorfind uses substrings."""
    # CATCHES: candidates that always do substring matching (the 'e' find
    # would succeed without the anchor option being disabled).
    s = run_lf(script=[(":find\r", 0.3), ("e", 0.5)])
    assert s.bottom().startswith("find: pattern not found: e")
    s.send(":set noanchorfind\r")
    s.wait(quiet=0.3)
    s.send(":find\r")
    s.wait(quiet=0.3)
    s.send("e")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("6/6")


def test_findlen_waits_for_full_pattern(run_lf):
    """set findlen 2 keeps the find prompt open until two keys arrive."""
    # CATCHES: candidates that execute find after every keystroke; after one
    # key the prompt must still show the partial pattern.
    s = run_lf(script=[(":set findlen 2\r", 0.3), (":find\r", 0.3), ("z", 0.5)])
    assert s.bottom() == "find: z"
    s.send("e")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("6/6")


def test_search_and_search_next_prev(run_lf):
    """Search is substring based; n/N step forward and backward."""
    # CATCHES: candidates whose search is prefix-anchored (nothing would
    # match 'txt') or whose N moves in the same direction as n or skips two
    # matches instead of stepping back exactly one entry.
    s = run_lf(script=[("/txt\r", 0.5)])
    assert s.bottom().endswith("3/6")
    s.send("n")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("4/6")
    s.send("n")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("5/6")
    s.send("N")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("4/6")
    s.send("N")
    s.wait(quiet=0.4)
    assert s.bottom().endswith("3/6")


def test_search_back_and_unmatched_pattern(run_lf):
    """'?'' searches backwards; a pattern without matches is not an error."""
    # CATCHES: candidates that report an error for unmatched searches (the
    # cursor must simply stay put), or that search forward for '?'.
    s = run_lf(script=[("G", 0.3), ("?txt\r", 0.5)])
    assert s.bottom().endswith("5/6")
    s.send("/nomatch\r")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("5/6")
    assert not s.bottom().startswith("search:")


def test_search_regex_method(run_lf):
    """set searchmethod regex changes matching and reports regexp errors."""
    # CATCHES: candidates that ignore searchmethod (the '.' wildcard would
    # not match) or that hide the Go regexp parse error.
    s = run_lf(script=[(":set searchmethod regex\r", 0.3), ("/[\r", 0.5)], cols=140)
    assert s.bottom().startswith("search: error parsing regexp: missing closing ]: `[`: [")
    s.send("/z.ta\r")
    s.wait(quiet=0.5)
    assert s.bottom().endswith("6/6")


def test_setfilter_and_filter_prompt(run_lf):
    """:setfilter filters the listing and prefills the :filter prompt."""
    # CATCHES: candidates that do not show the active filter in the ruler,
    # that open an empty filter prompt while a filter is active, or that
    # reset the cursor to the top instead of keeping it on the same file
    # when the filter is cleared again.
    s = run_lf(script=[(":setfilter .txt\r", 0.6)])
    assert s.bottom().endswith(".txt   1/3")
    s.send(":filter\r")
    s.wait(quiet=0.5)
    assert s.bottom() == "filter: .txt"
    s.send("<esc>")
    s.wait(quiet=0.3)
    s.send(":setfilter\r")
    s.wait(quiet=0.6)
    # clearing keeps the cursor on the file it was on (a.txt -> 3/6)
    assert s.bottom().endswith("3/6")
    s.close()

    s = run_lf(script=[("G", 0.3), (":setfilter .txt\r", 0.6)])
    # the cursor clamps to the last matching entry (c.txt -> 3/3)
    assert s.bottom().endswith(".txt   3/3")
    s.close()

    s = run_lf(script=[(":setfilter zzz\r", 0.6)])
    assert s.bottom().endswith("zzz   0/0")


def test_filtermethod_glob(run_lf):
    """set filtermethod glob interprets filter patterns as globs."""
    # CATCHES: candidates that always use substring filtering; the bracket
    # expression must match a.txt, b.txt and c.txt as a glob only.
    s = run_lf(script=[(":setfilter [abc].txt\r", 0.5)], cfg="set filtermethod glob")
    assert s.bottom().endswith("1/3")
