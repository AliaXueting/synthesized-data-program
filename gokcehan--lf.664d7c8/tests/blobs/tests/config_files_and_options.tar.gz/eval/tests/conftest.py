"""Shared helpers for driving the lf reference binary as a black box.

lf is a terminal file manager, so every observable behaviour lives behind a
full-screen ``tcell`` UI.  The helpers below give the child process a private
pseudo-terminal of a fixed size (created by the test itself, so nothing about
the ambient terminal is relied upon), capture the byte stream it writes and
replay it through a small ANSI interpreter to recover the rendered screen.

Two independent observation channels are exposed on the result object:

``res.log``    the ``-log`` file with timestamps/PIDs normalised away.  Every
               message-line error (option validation, parse errors) is copied
               there by ``ui.echoerr`` as ``error: <message>``.
``res.screen`` the rendered text of the terminal, as a list of row strings.

Shell commands reachable from the configuration are used as a third channel:
a ``$``-prefixed command inherits ``lf_<option>`` variables, so writing them to
a file inside ``tmp_path`` records the exact option state.
"""

from __future__ import annotations

import os
import re
import select
import struct
import subprocess
import time
import unicodedata

import fcntl
import termios
import pty

# --------------------------------------------------------------------------
# minimal ANSI/VT interpreter
# --------------------------------------------------------------------------

_CSI_FINAL = set("@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")


def _char_width(ch: str) -> int:
    if unicodedata.combining(ch):
        return 0
    return 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1


class TermScreen:
    """Replay a terminal byte stream and keep the final screen contents.

    lf draws on the alternate screen and clears it while shutting down, so a
    plain "final state" replay would always be blank.  Instead the screen is
    snapshotted every time tcell finishes a draw (it hides the cursor / ends
    its synchronized-update block at that point); those snapshots are what the
    tests look at.
    """

    def __init__(self, rows: int, cols: int):
        self.rows = rows
        self.cols = cols
        self.text = [[" "] * cols for _ in range(rows)]
        self.style = [[""] * cols for _ in range(rows)]
        self.cy = 0
        self.cx = 0
        self.fg = "-"
        self.bg = "-"
        self.attrs: set[str] = set()
        self.snap_text = [row[:] for row in self.text]
        self.snap_style = [row[:] for row in self.style]
        self.saved_text = None
        self.saved_style = None

    def snapshot(self):
        self.snap_text = [row[:] for row in self.text]
        self.snap_style = [row[:] for row in self.style]

    # -- styling ----------------------------------------------------------
    def _cur_style(self) -> str:
        bits = []
        if self.fg != "-":
            bits.append("fg" + self.fg)
        if self.bg != "-":
            bits.append("bg" + self.bg)
        bits.extend(sorted(self.attrs))
        return ",".join(bits)

    def _sgr(self, params: str) -> None:
        if params == "":
            params = "0"
        fields = [p for p in params.split(";")]
        i = 0
        nums: list[int] = []
        for f in fields:
            nums.append(int(f) if f else 0)
        while i < len(nums):
            n = nums[i]
            if n == 0:
                self.fg = self.bg = "-"
                self.attrs = set()
            elif n == 1:
                self.attrs.add("bold")
            elif n == 2:
                self.attrs.add("dim")
            elif n == 3:
                self.attrs.add("italic")
            elif n == 4:
                self.attrs.add("underline")
            elif n == 5 or n == 6:
                self.attrs.add("blink")
            elif n == 7:
                self.attrs.add("reverse")
            elif n == 9:
                self.attrs.add("strike")
            elif n in (22,):
                self.attrs.discard("bold")
                self.attrs.discard("dim")
            elif n == 23:
                self.attrs.discard("italic")
            elif n == 24:
                self.attrs.discard("underline")
            elif n == 25:
                self.attrs.discard("blink")
            elif n == 27:
                self.attrs.discard("reverse")
            elif n == 29:
                self.attrs.discard("strike")
            elif 30 <= n <= 37:
                self.fg = str(n - 30)
            elif n == 39:
                self.fg = "-"
            elif 40 <= n <= 47:
                self.bg = str(n - 40)
            elif n == 49:
                self.bg = "-"
            elif 90 <= n <= 97:
                self.fg = str(n - 90 + 8)
            elif 100 <= n <= 107:
                self.bg = str(n - 100 + 8)
            elif n in (38, 48) and i + 1 < len(nums):
                if nums[i + 1] == 5 and i + 2 < len(nums):
                    tag = str(nums[i + 2])
                    i += 2
                elif nums[i + 1] == 2 and i + 4 < len(nums):
                    tag = "#%02x%02x%02x" % tuple(nums[i + 2 : i + 5])
                    i += 4
                else:
                    tag = "?"
                    i = len(nums)
                if n == 38:
                    self.fg = tag
                else:
                    self.bg = tag
            i += 1

    # -- editing ----------------------------------------------------------
    def _put(self, ch: str) -> None:
        if self.cy < 0 or self.cy >= self.rows or self.cx < 0 or self.cx >= self.cols:
            self.cx += max(_char_width(ch), 1)
            return
        self.text[self.cy][self.cx] = ch
        self.style[self.cy][self.cx] = self._cur_style()
        w = _char_width(ch)
        for k in range(1, max(w, 1)):
            if self.cx + k < self.cols:
                self.text[self.cy][self.cx + k] = ""
        self.cx += max(w, 1)

    def _erase(self, row: int, start: int, end: int) -> None:
        if row < 0 or row >= self.rows:
            return
        for c in range(max(start, 0), min(end, self.cols)):
            self.text[row][c] = " "
            self.style[row][c] = ""

    def _scroll(self) -> None:
        if self.rows:
            self.text.pop(0)
            self.style.pop(0)
            self.text.append([" "] * self.cols)
            self.style.append([""] * self.cols)

    def feed(self, data: str) -> None:
        i = 0
        n = len(data)
        while i < n:
            ch = data[i]
            if ch != "\x1b":
                if ch == "\r":
                    self.cx = 0
                elif ch == "\n":
                    self.cy += 1
                    if self.cy >= self.rows:
                        self.cy = self.rows - 1
                        self._scroll()
                elif ch == "\b":
                    self.cx = max(self.cx - 1, 0)
                elif ch == "\t":
                    self.cx = min((self.cx // 8 + 1) * 8, self.cols - 1)
                elif ord(ch) < 32:
                    pass
                else:
                    self._put(ch)
                i += 1
                continue
            if i + 1 >= n:
                break
            kind = data[i + 1]
            if kind == "[":
                j = i + 2
                while j < n and data[j] not in _CSI_FINAL:
                    j += 1
                if j >= n:
                    break
                self._csi(data[i + 2 : j], data[j])
                i = j + 1
            elif kind == "]":
                j = data.find("\x07", i)
                k = data.find("\x1b\\", i)
                ends = [x for x in (j, k) if x != -1]
                if not ends:
                    break
                i = min(ends) + (1 if min(ends) == j else 2)
            elif kind in "()*+":
                i += 3
            else:
                i += 2

    def _csi(self, params: str, final: str) -> None:
        priv = params.startswith("?") or params.startswith(">")
        # intermediate bytes (0x20-0x2f) such as the '$' of DECRQM are not
        # parameters; drop them along with everything that follows
        cut = len(params)
        for k, ch in enumerate(params):
            if " " <= ch <= "/":
                cut = k
                break
        params = params[:cut]
        body = params.lstrip("?>")
        args = []
        for p in body.split(";") if body else []:
            p = p.strip()
            args.append(int(p) if p.isdigit() or (p[:1] == "-" and p[1:].isdigit()) else 0)

        def a(idx: int, default: int = 1) -> int:
            if idx < len(args) and args[idx] != 0:
                return args[idx]
            return default

        if final in "Hf":
            self.cy = max(0, min(a(0) - 1, self.rows - 1))
            self.cx = max(0, min(a(1) - 1, self.cols - 1))
        elif final == "A":
            self.cy = max(0, self.cy - a(0))
        elif final in "B":
            self.cy = min(self.rows - 1, self.cy + a(0))
        elif final == "C":
            self.cx = min(self.cols - 1, self.cx + a(0))
        elif final == "D":
            self.cx = max(0, self.cx - a(0))
        elif final == "E":
            self.cy = min(self.rows - 1, self.cy + a(0))
            self.cx = 0
        elif final == "F":
            self.cy = max(0, self.cy - a(0))
            self.cx = 0
        elif final in "G`":
            self.cx = max(0, min(a(0) - 1, self.cols - 1))
        elif final == "d":
            self.cy = max(0, min(a(0) - 1, self.rows - 1))
        elif final == "J":
            mode = args[0] if args else 0
            if mode == 0:
                self._erase(self.cy, self.cx, self.cols)
                for r in range(self.cy + 1, self.rows):
                    self._erase(r, 0, self.cols)
            elif mode == 1:
                self._erase(self.cy, 0, self.cx + 1)
                for r in range(0, self.cy):
                    self._erase(r, 0, self.cols)
            else:
                for r in range(self.rows):
                    self._erase(r, 0, self.cols)
        elif final == "K":
            mode = args[0] if args else 0
            if mode == 0:
                self._erase(self.cy, self.cx, self.cols)
            elif mode == 1:
                self._erase(self.cy, 0, self.cx + 1)
            else:
                self._erase(self.cy, 0, self.cols)
        elif final == "X":
            self._erase(self.cy, self.cx, self.cx + a(0))
        elif final == "m" and not priv:
            self._sgr(body)
        elif priv and final in "hl":
            self._mode(body, final == "h")
        # everything else (window ops, ...) is ignored

    def _mode(self, body: str, on: bool) -> None:
        for m in body.split(";"):
            if m in ("1049", "47", "1047"):
                if on:
                    self.saved_text = [r[:] for r in self.text]
                    self.saved_style = [r[:] for r in self.style]
                    for r in range(self.rows):
                        self._erase(r, 0, self.cols)
                    self.cy = self.cx = 0
                else:
                    if self.saved_text is not None:
                        self.text = [r[:] for r in self.saved_text]
                        self.style = [r[:] for r in self.saved_style]
            elif m in ("25", "2026"):
                if not on:
                    self.snapshot()


# --------------------------------------------------------------------------
# process driver
# --------------------------------------------------------------------------

TS = re.compile(r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ")
SKIP_LOG = re.compile(r"\*\*\*\*\*|received termination signal")


class Result:
    """Everything one lf invocation tells us."""

    def __init__(self, raw: bytes, returncode, log_text: str, screen: TermScreen, tmp):
        self.raw = raw
        self.returncode = returncode
        self._log = log_text
        self.screen = screen
        self.tmp = tmp

    @property
    def log(self) -> str:
        out = []
        for line in self._log.splitlines():
            if SKIP_LOG.search(line):
                continue
            out.append(TS.sub("", line))
        return "\n".join(out)

    @property
    def errors(self) -> list:
        """The message-line errors, in order, without the log decoration."""
        return [l[len("error: ") :] for l in self.log.splitlines() if l.startswith("error: ")]

    def lines(self) -> list:
        return ["".join(r).rstrip() for r in self.screen.snap_text]

    def line(self, idx: int) -> str:
        return "".join(self.screen.snap_text[idx]).rstrip()

    def styles(self, row: int) -> list:
        return self.screen.snap_style[row]

    def row_styles(self, row: int) -> str:
        """Compact per-column style signature of a rendered row."""
        out = []
        for st in self.screen.snap_style[row]:
            out.append(st if st else ".")
        return "".join(s[0] if s != "." else "." for s in out)

    def find_row(self, needle: str) -> int:
        for i, line in enumerate(self.lines()):
            if needle in line:
                return i
        return -1

    def runs(self, row: int) -> list:
        """(start_col, style, text) runs of one rendered row, spaces squeezed.

        tcell repaints a whole row in one style at a time, so compressing
        consecutive equal-style cells recovers exactly which SGR sequence
        lf put around which fragment of the row.
        """
        text = self.screen.snap_text[row]
        style = self.screen.snap_style[row]
        out = []
        prev = None
        start = 0
        for x in range(self.screen.cols):
            st = style[x]
            if st != prev:
                if prev is not None:
                    out.append((start, prev, "".join(text[start:x]).rstrip()))
                prev = st
                start = x
        out.append((start, prev, "".join(text[start:]).rstrip()))
        return [(a, b, c) for a, b, c in out if c]

    def pane(self, row: int, col: int, width: int) -> str:
        """Text of one pane cell of a rendered row."""
        return "".join(self.screen.snap_text[row][col : col + width]).rstrip()

    def norm(self, s: str) -> str:
        """Replace the volatile tmp path so expectations stay exact."""
        return s.replace(str(self.tmp), "<TMP>")


def _pinned_env(tmp) -> dict:
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": str(tmp / "home"),
        "TERM": "xterm",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "XDG_CONFIG_HOME": str(tmp / "config"),
        "XDG_DATA_HOME": str(tmp / "data"),
        "XDG_RUNTIME_DIR": str(tmp / "runtime"),
        "OPENER": "true",
        "EDITOR": "true",
        "PAGER": "cat",
        "SHELL": "/bin/sh",
    }
    for d in ("home", "config", "data", "runtime"):
        (tmp / d).mkdir(parents=True, exist_ok=True)
    return env


def prepare(tmp, lfrc=None, colors=None, icons=None) -> dict:
    """Create the XDG tree lf reads its configuration from.

    Returns the pinned child environment; ``lfrc``/``colors``/``icons`` are
    written to ``$XDG_CONFIG_HOME/lf/`` so the usual discovery path is used.
    """
    env = _pinned_env(tmp)
    cfgdir = tmp / "config" / "lf"
    cfgdir.mkdir(parents=True, exist_ok=True)
    if lfrc is not None:
        (cfgdir / "lfrc").write_text(lfrc, encoding="utf-8")
    if colors is not None:
        (cfgdir / "colors").write_text(colors, encoding="utf-8")
    if icons is not None:
        (cfgdir / "icons").write_text(icons, encoding="utf-8")
    return env


def run_lf(
    tmp,
    args=(),
    commands=(),
    keys=b"",
    cwd=None,
    env=None,
    rows=30,
    cols=100,
    quiet=0.4,
    min_wait=0.2,
    timeout=25.0,
    single=True,
    wait_exit=False,
    during=None,
):
    """Run the reference binary on a private pty and collect what it did.

    ``args`` are extra command line flags, ``commands`` become ``-command``
    flags in order, ``keys`` is written to the terminal once the output has
    settled.  ``single=False`` lets lf start its own server, which is what
    makes ``lf -remote "query $id ..."`` answer.  ``during`` is a callable
    invoked at that same settled moment instead of sending keys, so the test
    process can change the outside world (create a file, ...) while lf sits
    in its event loop waiting for something to happen.
    """
    binary = os.environ["PROGRAMGYM_EXECUTABLE"]
    log_path = tmp / "lf.log"
    # lf opens its log with O_APPEND, so a second run in the same directory
    # would see the first run's lines too: always start from an empty log.
    try:
        log_path.unlink()
    except OSError:
        pass

    argv = [binary]
    if single:
        argv.append("-single")
    argv += ["-log", str(log_path)]
    for c in commands:
        argv += ["-command", c]
    argv += [str(a) for a in args]

    child_env = _pinned_env(tmp)
    if env:
        child_env.update({k: v for k, v in env.items() if v is not None})
        for k, v in env.items():
            if v is None:
                child_env.pop(k, None)
    # Coverage instrumentation hook: the pipeline builds the reference with
    # -cover, so GOCOVERDIR has to survive the pinned environment.
    cov = {"GOCOVERDIR": os.path.abspath(v) for v in [os.environ.get("GOCOVERDIR")] if v}
    child_env.update(cov)

    screen = TermScreen(rows, cols)
    raw = b""

    mfd, sfd = pty.openpty()
    fcntl.ioctl(sfd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))

    def _child():
        os.setsid()
        fcntl.ioctl(sfd, termios.TIOCSCTTY, 0)

    proc = subprocess.Popen(
        argv,
        stdin=sfd,
        stdout=sfd,
        stderr=sfd,
        cwd=str(cwd if cwd is not None else tmp),
        env=child_env,
        preexec_fn=_child,
        close_fds=True,
    )
    os.close(sfd)

    deadline = time.time() + timeout
    start = time.time()
    last_out = time.time()
    drawn = b"\x1b[?25l" in raw

    def _drain(wait):
        """Read whatever shows up within ``wait`` seconds; False on EOF."""
        nonlocal raw, last_out, drawn
        try:
            r, _, _ = select.select([mfd], [], [], wait)
        except OSError:
            return False
        if not r:
            return True
        try:
            chunk = os.read(mfd, 65536)
        except OSError:
            return False
        if not chunk:
            return False
        raw += chunk
        drawn = drawn or b"\x1b[?25l" in chunk
        last_out = time.time()
        return True

    # phase 1: let the client start up and settle on a stable rendering.
    # tcell probes the terminal at startup and waits for answers that never
    # come, so "output went quiet" alone is not a signal that the UI is up;
    # wait for the first completed frame as well.
    while time.time() < deadline:
        if not _drain(0.05):
            break
        if proc.poll() is not None:
            break
        if not wait_exit and drawn and (time.time() - last_out) >= quiet and (time.time() - start) >= min_wait:
            if during is not None:
                during()
                during = None
                last_out = time.time()
                break
            if keys:
                try:
                    os.write(mfd, keys)
                except OSError:
                    pass
                keys = b""
                last_out = time.time()
            else:
                break
        if wait_exit and keys and drawn and (time.time() - start) >= min_wait:
            try:
                os.write(mfd, keys)
            except OSError:
                pass
            keys = b""
            last_out = time.time()

    # phase 2: the client exited on its own before the keys could be sent
    if keys:
        try:
            os.write(mfd, keys)
        except OSError:
            pass
        keys = b""
        last_out = time.time()

    # phase 3: wait for the effect of the keys / the client to finish
    end = min(deadline, time.time() + 6.0)
    while time.time() < end:
        if not _drain(0.05):
            break
        if proc.poll() is not None:
            break
        if not wait_exit and (time.time() - last_out) >= quiet:
            break

    alive = proc.poll() is None
    if alive:
        # nothing quit the client: terminate it the way lf expects (exit code 3)
        proc.terminate()
        end = time.time() + 3.0
        while time.time() < end:
            if not _drain(0.05):
                break
            if proc.poll() is not None:
                break
    if proc.poll() is None:
        proc.kill()
    proc.wait()
    try:
        os.close(mfd)
    except OSError:
        pass

    screen.feed(raw.decode("utf-8", errors="replace"))
    log_text = ""
    try:
        log_text = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        pass
    res = Result(raw, proc.returncode, log_text, screen, tmp)
    res.alive = alive
    return res


def out_file(tmp, name="out"):
    """Path a configured shell command is told to write its dump to."""
    p = tmp / name
    return p


def dump_cmd(var, path):
    """A ``$`` command that records one ``lf_*`` variable to a file.

    The redirection is kept outside the quotes because ``$`` commands are run
    through the shell, so the redirect must be parsed by it, not by lf.
    """
    return '$ printf %s "${%s}" > %s' % (var, var, path)


def write_var(var, path):
    """Shell fragment appending ``var=value`` plus newline to ``path``."""
    return 'printf "%%s\\n" "${%s}" >> %s' % (var, path)


# --------------------------------------------------------------------------
# config-module helpers (added in round 2)
# --------------------------------------------------------------------------

def opt_value(tmp, lfrc="", var="lf_hidden", commands=(), env=None, args=()):
    """Run lf with ``lfrc`` and return (value, result) of the ``lf_<var>`` export.

    A ``$`` shell command inherits every option as an ``lf_<option>``
    environment variable, so dumping one to a file records the exact option
    state the reference binary reached.
    """
    out = tmp / "optval"
    prepare(tmp, lfrc=lfrc)
    cmds = list(commands) + ['$ printf %s "$' + var + '" > ' + str(out), "quit"]
    res = run_lf(tmp, commands=cmds, env=env, args=args)
    return (out.read_text() if out.exists() else "<missing>"), res


def norm_runs(res, row):
    """(style, squeezed-text) pairs of one rendered row.

    Whitespace inside a run is squeezed so expectations do not depend on how
    the neighbouring panes split the row into runs.
    """
    return [(s, " ".join(t.split())) for _, s, t in res.runs(row)]


def row_of(res, name):
    """Row index of the pane-1 listing entry ``name``, or -1.

    Row 0 (the prompt) and the last row (ruler/preview stat) are skipped, and
    the entry is matched on whole tokens so pane-0 directory names that merely
    contain the same letters cannot collide.
    """
    for row in range(1, res.screen.rows - 1):
        for _, _style, text in res.runs(row):
            toks = text.split()
            if toks and toks[-1] == name:
                return row
    return -1


def entry_style(res, name):
    """Style signature of the listing entry ``name`` (empty string if none)."""
    row = row_of(res, name)
    if row < 0:
        return None
    for _, style, text in res.runs(row):
        toks = text.split()
        if toks and toks[-1] == name:
            return style
    return None
