"""Option registry: defaults, bool/int/string/list/enum validation, user options.

CATCHES: a re-implementation with different defaults, different bool forms
('no...', '...!' toggling), missing integer bounds checks, different list
parsing, different enum value sets or different error wording would fail
these exact value and message-line assertions.
"""

import os
import pwd

import pytest

from conftest import prepare, run_lf


def dump_vars(tmp_path, lfrc, vars, commands=()):
    """Run lf once with ``lfrc`` and return ({var: value}, result).

    Each variable is exported to its own file by a single ``$`` shell command
    so a whole family of options is observed in one session.
    """
    prepare(tmp_path, lfrc=lfrc)
    outs = {v: tmp_path / v.replace("_", "") for v in vars}
    cmds = list(commands)
    for v, p in outs.items():
        cmds.append('$ printf %s "$' + v + '" > ' + str(p))
    cmds.append("quit")
    res = run_lf(tmp_path, commands=cmds)
    return {v: (p.read_text() if p.exists() else "<missing>") for v, p in outs.items()}, res


def chain_values(tmp_path, pairs, lfrc=""):
    """Run (statement, variable) pairs in order, recording each variable.

    ``$`` commands are executed synchronously (the client blocks until the
    shell exits), so the recorded lines are in exactly the order the
    statements were evaluated — a whole family of values from one session.
    """
    out = tmp_path / "chain"
    prepare(tmp_path, lfrc=lfrc)
    cmds = []
    for st, var in pairs:
        cmds.append(st)
        cmds.append('$ echo "$' + var + '" >> ' + str(out))
    cmds.append("quit")
    res = run_lf(tmp_path, commands=cmds)
    return (out.read_text().splitlines() if out.exists() else []), res


def test_option_defaults(tmp_path):
    # CATCHES: every default comes from the option registry; a single
    # different default value fails this snapshot.
    vals, res = dump_vars(tmp_path, "", [
        "lf_hidden", "lf_dirfirst", "lf_preview", "lf_smartcase",
        "lf_ratios", "lf_tabstop", "lf_scrolloff", "lf_findlen", "lf_period",
        "lf_truncatepct", "lf_sortby", "lf_borderstyle", "lf_searchmethod",
        "lf_selmode", "lf_sizeunits", "lf_terminalcursor", "lf_info",
        "lf_hiddenfiles", "lf_preserve", "lf_shellopts", "lf_ifs",
        "lf_filesep", "lf_tempmarks", "lf_timefmt", "lf_shell",
        "lf_shellflag", "lf_truncatechar", "lf_incsearch", "lf_wrapscroll",
        "lf_mouse",
    ])
    assert vals == {
        "lf_hidden": "false", "lf_dirfirst": "true", "lf_preview": "true",
        "lf_smartcase": "true", "lf_ratios": "1:2:3", "lf_tabstop": "8",
        "lf_scrolloff": "0", "lf_findlen": "1", "lf_period": "0",
        "lf_truncatepct": "100", "lf_sortby": "natural",
        "lf_borderstyle": "box", "lf_searchmethod": "text",
        "lf_selmode": "all", "lf_sizeunits": "binary",
        "lf_terminalcursor": "default", "lf_info": "",
        "lf_hiddenfiles": ".*", "lf_preserve": "mode", "lf_shellopts": "",
        "lf_ifs": "", "lf_filesep": "\n", "lf_tempmarks": "'",
        "lf_timefmt": "Mon Jan _2 15:04:05 2006", "lf_shell": "sh",
        "lf_shellflag": "-c", "lf_truncatechar": "~", "lf_incsearch": "false",
        "lf_wrapscroll": "false", "lf_mouse": "false",
    }
    assert res.errors == []


def test_bool_forms(tmp_path):
    # CATCHES: bare (true), explicit, negated 'no...' and '!' toggling forms
    # must all be honoured in sequence.
    vals, res = dump_vars(tmp_path, "set hidden\nset nohidden\nset hidden!\nset hidden!\n",
                          ["lf_hidden"])
    assert vals == {"lf_hidden": "false"}
    assert res.errors == []


def test_bool_and_unknown_option_errors(tmp_path):
    # CATCHES: unknown option names and non-boolean values report on the
    # message line in statement order and leave the value untouched.
    vals, res = dump_vars(tmp_path, "set nosuchoption\nset hidden bogus\n", ["lf_hidden"])
    assert vals == {"lf_hidden": "false"}
    assert res.errors == ["unknown option: nosuchoption",
                          "hidden: value should be empty, 'true', or 'false'"]


def test_bool_value_forms_rejected(tmp_path):
    # CATCHES: 'no<option>' and '<option>!' refuse an explicit value.
    vals, res = dump_vars(tmp_path, "set nohidden true\nset hidden! x\n", ["lf_hidden"])
    assert vals == {"lf_hidden": "false"}
    assert res.errors == ["nohidden: unexpected value: true",
                          "hidden!: unexpected value: x"]


def test_bool_error_does_not_block_later_set(tmp_path):
    # CATCHES: after a rejected form a later valid statement still applies.
    vals, res = dump_vars(tmp_path, "set hidden! x\nset hidden true\n", ["lf_hidden"])
    assert vals == {"lf_hidden": "true"}
    assert res.errors == ["hidden!: unexpected value: x"]


def test_int_options_accept_valid_values(tmp_path):
    # CATCHES: the integer options all accept and store plain values.
    vals, res = dump_vars(tmp_path,
                          "set tabstop 4\nset scrolloff 5\nset findlen 2\n"
                          "set period 3\nset truncatepct 50\nset ratios 1:2\n",
                          ["lf_tabstop", "lf_scrolloff", "lf_findlen", "lf_period",
                           "lf_truncatepct", "lf_ratios"])
    assert vals == {"lf_tabstop": "4", "lf_scrolloff": "5", "lf_findlen": "2",
                    "lf_period": "3", "lf_truncatepct": "50", "lf_ratios": "1:2"}
    assert res.errors == []


def test_int_options_reject_bad_values(tmp_path):
    # CATCHES: zero/negative/non-numeric values keep the previous value and
    # produce the exact per-option error strings.
    vals, res = dump_vars(tmp_path,
                          "set tabstop 0\nset tabstop -3\nset tabstop abc\nset scrolloff -1\n",
                          ["lf_tabstop", "lf_scrolloff"])
    assert vals == {"lf_tabstop": "8", "lf_scrolloff": "0"}
    assert res.errors == [
        "tabstop: value should be a positive number",
        "tabstop: value should be a positive number",
        'tabstop: strconv.Atoi: parsing "abc": invalid syntax',
        "scrolloff: value should be a non-negative number",
    ]


def test_int_bounds_and_parse_errors(tmp_path):
    # CATCHES: findlen/period keep non-negative bounds and truncatepct has
    # an inclusive 0..100 range with its own message.
    vals, res = dump_vars(tmp_path,
                          "set findlen -1\nset period abc\nset truncatepct 101\n",
                          ["lf_findlen", "lf_period", "lf_truncatepct"])
    assert vals == {"lf_findlen": "1", "lf_period": "0", "lf_truncatepct": "100"}
    assert res.errors == [
        "findlen: value should be a non-negative number",
        'period: strconv.Atoi: parsing "abc": invalid syntax',
        "truncatepct: must be between 0 and 100 (both inclusive), got 101",
    ]


def test_int_overflow_message(tmp_path):
    # CATCHES: numbers beyond int range surface Go's strconv overflow text.
    vals, res = dump_vars(tmp_path, "set ratios 99999999999999999999\n", ["lf_ratios"])
    assert vals == {"lf_ratios": "1:2:3"}
    assert res.errors == ['ratios: strconv.Atoi: parsing "99999999999999999999": value out of range']


def test_ratios_and_preview_interplay(tmp_path):
    # CATCHES: 'ratios' needs >= 2 numbers; a single ratio only sticks while
    # preview is off, and re-enabling preview reports the guard message.
    vals, res = dump_vars(tmp_path, "set nopreview\nset ratios 5\nset preview\n",
                          ["lf_ratios"])
    assert vals == {"lf_ratios": "5"}
    assert res.errors == [
        "preview: 'ratios' should consist of at least two numbers before enabling 'preview'"
    ]


def test_ratios_single_rejected_while_preview_on(tmp_path):
    # CATCHES: with preview on (the default) a single-number ratio is refused.
    vals, res = dump_vars(tmp_path, "set ratios 5\n", ["lf_ratios"])
    assert vals == {"lf_ratios": "1:2:3"}
    assert res.errors == ["ratios: should consist of at least two numbers when 'preview' is enabled"]


def test_list_options_accept_values(tmp_path):
    # CATCHES: the colon-separated list options round-trip their values;
    # tempmarks gains its leading quote marker.
    vals, res = dump_vars(tmp_path,
                          "set info size:time\nset hiddenfiles *.o:*.tmp\n"
                          "set preserve timestamps:mode\nset shellopts -x:-v\n"
                          "set tempmarks abc\n",
                          ["lf_info", "lf_hiddenfiles", "lf_preserve",
                           "lf_shellopts", "lf_tempmarks"])
    assert vals == {"lf_info": "size:time", "lf_hiddenfiles": "*.o:*.tmp",
                    "lf_preserve": "timestamps:mode", "lf_shellopts": "-x:-v",
                    "lf_tempmarks": "'abc"}
    assert res.errors == []


def test_list_options_cleared_by_empty_set(tmp_path):
    # CATCHES: 'set <list>' with no value empties info/preserve/shellopts.
    vals, res = dump_vars(tmp_path, "set info\nset preserve\nset shellopts\n",
                          ["lf_info", "lf_preserve", "lf_shellopts"])
    assert vals == {"lf_info": "", "lf_preserve": "", "lf_shellopts": ""}
    assert res.errors == []


def test_list_options_reject_bad_values(tmp_path):
    # CATCHES: unknown info/preserve keywords, empty globs and invalid glob
    # syntax all report while keeping the old value.
    vals, res = dump_vars(tmp_path,
                          "set info bogus\nset hiddenfiles a::b\nset hiddenfiles [\n"
                          "set preserve bogus\n",
                          ["lf_info", "lf_hiddenfiles", "lf_preserve"])
    assert vals == {"lf_info": "", "lf_hiddenfiles": ".*", "lf_preserve": "mode"}
    assert res.errors == [
        "info: should consist of 'size', 'time', 'atime', 'btime', 'ctime', "
        "'perm', 'user', 'group' or 'custom' separated with colon",
        "hiddenfiles: glob should be non-empty",
        "hiddenfiles: syntax error in pattern",
        "preserve: should consist of 'mode' or 'timestamps' separated with colon",
    ]


def test_string_options_accept_values(tmp_path):
    # CATCHES: quoted timefmt keeps inner spacing, truncatechar takes any
    # single character (including a multi-byte one) and ifs round-trips.
    vals, res = dump_vars(tmp_path,
                          "set timefmt 'a b  c'\nset truncatechar *\nset ifs /\n"
                          "set truncatechar é\n",
                          ["lf_timefmt", "lf_truncatechar", "lf_ifs"])
    assert vals == {"lf_timefmt": "a b  c", "lf_truncatechar": "é", "lf_ifs": "/"}
    assert res.errors == []


def test_truncatechar_single_character_rule(tmp_path):
    # CATCHES: multi-character or missing values are refused with the exact
    # message and the default tilde stays.
    vals, res = dump_vars(tmp_path, "set truncatechar ab\nset truncatechar\n",
                          ["lf_truncatechar"])
    assert vals == {"lf_truncatechar": "~"}
    assert res.errors == ["truncatechar: value should be a single character",
                          "truncatechar: value should be a single character"]


def test_filesep_colon_quirk(tmp_path):
    # CATCHES: ':' is the statement token, so 'set filesep :' stores the
    # colon but also leaves an 'unexpected token' error behind.
    vals, res = dump_vars(tmp_path, "set filesep :\n", ["lf_filesep"])
    assert vals == {"lf_filesep": ":"}
    assert res.errors == ["unexpected token: "]


def test_enum_options_accept_values(tmp_path):
    # CATCHES: every enumerated option stores each of its documented values.
    vals, res = dump_vars(tmp_path,
                          "set sortby name\nset borderstyle roundbox\n"
                          "set searchmethod glob\nset selmode dir\n"
                          "set sizeunits decimal\nset terminalcursor blinkbar\n",
                          ["lf_sortby", "lf_borderstyle", "lf_searchmethod",
                           "lf_selmode", "lf_sizeunits", "lf_terminalcursor"])
    assert vals == {"lf_sortby": "name", "lf_borderstyle": "roundbox",
                    "lf_searchmethod": "glob", "lf_selmode": "dir",
                    "lf_sizeunits": "decimal", "lf_terminalcursor": "blinkbar"}
    assert res.errors == []
    vals, res = dump_vars(tmp_path,
                          "set sortby ext\nset filtermethod regex\n"
                          "set borderstyle separators\nset terminalcursor bar\n",
                          ["lf_sortby", "lf_filtermethod", "lf_borderstyle",
                           "lf_terminalcursor"])
    assert vals == {"lf_sortby": "ext", "lf_filtermethod": "regex",
                    "lf_borderstyle": "separators", "lf_terminalcursor": "bar"}
    assert res.errors == []


def test_enum_options_reject_bad_values(tmp_path):
    # CATCHES: invalid enum values keep the default and print the option's
    # full value list (filtermethod's message is missing its closing quote).
    vals, res = dump_vars(tmp_path,
                          "set sortby bogus\nset borderstyle none\n"
                          "set searchmethod bogus\nset selmode none\n",
                          ["lf_sortby", "lf_borderstyle", "lf_searchmethod", "lf_selmode"])
    assert vals == {"lf_sortby": "natural", "lf_borderstyle": "box",
                    "lf_searchmethod": "text", "lf_selmode": "all"}
    assert res.errors == [
        "sortby: value should either be 'natural', 'name', 'size', 'time', "
        "'atime', 'btime', 'ctime', 'ext' or 'custom'",
        "borderstyle: value should either be 'box', 'roundbox', 'outline', "
        "'roundoutline' or 'separators'",
        "searchmethod: value should either be 'text', 'glob' or 'regex'",
        "selmode: value should either be 'all' or 'dir'",
    ]
    vals, res = dump_vars(tmp_path,
                          "set sizeunits bogus\nset terminalcursor bogus\n"
                          "set filtermethod bogus\n",
                          ["lf_sizeunits", "lf_terminalcursor", "lf_filtermethod"])
    assert vals == {"lf_sizeunits": "binary", "lf_terminalcursor": "default",
                    "lf_filtermethod": "text"}
    assert res.errors == [
        "sizeunits: value should either be 'binary' or 'decimal'",
        "terminalcursor: value should either be 'default', 'block', 'underline', "
        "'bar', 'blinkblock', 'blinkunderline' or 'blinkbar'",
        "filtermethod: value should either be 'text', 'glob' or 'regex",
    ]


def test_deprecated_options_still_report(tmp_path):
    # CATCHES: rulerfmt/statfmt warn about their replacement; the unquoted
    # '%' value also trips the parser exactly as observed.
    vals, res = dump_vars(tmp_path, "set rulerfmt %m\n", ["lf_rulerfmt"])
    assert vals == {"lf_rulerfmt": "%"}
    assert res.errors == [
        "option 'rulerfmt' is deprecated and will be replaced by the 'rulerfile' option",
        "unexpected token: ",
    ]
    vals, res = dump_vars(tmp_path, "set statfmt %f\n", ["lf_statfmt"])
    assert vals == {"lf_statfmt": "%"}
    assert res.errors == [
        "option 'statfmt' is deprecated and will be replaced by the 'rulerfile' option",
        "unexpected token: ",
    ]


def test_user_options(tmp_path):
    # CATCHES: user_ options accept any value, are redefined by later sets,
    # survive quoting, allow an empty name and export as lf_user_*.
    vals, res = dump_vars(tmp_path,
                          "set user_x hello\nset user_x b\nset user_y 'a b'\n"
                          "set user_ v\nset user_z\n",
                          ["lf_user_x", "lf_user_y", "lf_user_", "lf_user_z"])
    assert vals == {"lf_user_x": "b", "lf_user_y": "a b", "lf_user_": "v",
                    "lf_user_z": ""}
    assert res.errors == []


def test_user_option_set_via_command_flag(tmp_path):
    # CATCHES: user options can be created after startup by -command.
    vals, res = dump_vars(tmp_path, "", ["lf_user_x"], commands=["set user_x later"])
    assert vals == {"lf_user_x": "later"}
    assert res.errors == []


BOOL_OPTIONS = [
    "anchorfind", "autoquit", "dircounts", "dirfirst", "dironly", "dirpreviews",
    "drawbox", "hidden", "history", "icons", "ignorecase", "ignoredia",
    "incfilter", "incsearch", "mergeindicators", "mouse", "number", "preload",
    "relativenumber", "reverse", "showbinds", "smartcase", "smartdia",
    "sortignorecase", "sortignoredia", "wrapscan", "wrapscroll",
]
# 'watch' is deliberately absent: turning it off while the watched directory
# is being written to can block the reference's watch loop, so the value can
# not be observed reliably through a shell command.

FORMAT_OPTIONS = [
    "borderfmt", "copyfmt", "cursoractivefmt", "cursorparentfmt",
    "cursorpreviewfmt", "cutfmt", "dupfilefmt", "errorfmt", "infotimefmtnew",
    "infotimefmtold", "menufmt", "menuheaderfmt", "menuselectfmt",
    "numbercursorfmt", "numberfmt", "promptfmt", "selectfmt", "tagfmt",
    "visualfmt", "waitmsg",
]


def test_bool_option_registry_sweep(tmp_path):
    # CATCHES: every boolean option name must exist and round-trip through its
    # lf_* export, both when switched on with the bare form and when switched
    # off again with an explicit 'false' value.
    pairs = [("set " + o, "lf_" + o) for o in BOOL_OPTIONS]
    pairs += [("set " + o + " false", "lf_" + o) for o in BOOL_OPTIONS]
    got, res = chain_values(tmp_path, pairs)
    assert got == ["true"] * len(BOOL_OPTIONS) + ["false"] * len(BOOL_OPTIONS)
    assert res.errors == []


def test_bool_explicit_true_and_false_values(tmp_path):
    # CATCHES: the value forms 'true' and 'false' are accepted alongside the
    # bare, 'no...' and '!' forms (an empty value also means true).
    pairs = [
        ("set hidden false", "lf_hidden"),
        ("set hidden true", "lf_hidden"),
        ("set hidden", "lf_hidden"),
        ("set nohidden", "lf_hidden"),
        ("set hidden!", "lf_hidden"),
    ]
    got, res = chain_values(tmp_path, pairs)
    assert got == ["false", "true", "true", "false", "true"]
    assert res.errors == []


def test_format_string_options_accept_values(tmp_path):
    # CATCHES: the *fmt and other free-form string options store their value
    # verbatim, including the surrounding spaces the quoting preserved.
    pairs = [("set %s ' %s '" % (o, o[:5]), "lf_" + o) for o in FORMAT_OPTIONS]
    got, res = chain_values(tmp_path, pairs)
    assert got == [" %s " % o[:5] for o in FORMAT_OPTIONS]
    assert res.errors == []


def test_borderstyle_accepts_every_documented_value(tmp_path):
    # CATCHES: all five border styles round-trip, an invalid one keeps the
    # previous value (not the default) and reports the full value list.
    values = ["box", "roundbox", "outline", "roundoutline", "separators", "bogus", "box"]
    pairs = [("set borderstyle " + v, "lf_borderstyle") for v in values]
    got, res = chain_values(tmp_path, pairs)
    assert got == ["box", "roundbox", "outline", "roundoutline", "separators",
                   "separators", "box"]
    assert res.errors == [
        "borderstyle: value should either be 'box', 'roundbox', 'outline', "
        "'roundoutline' or 'separators'"
    ]


def test_terminalcursor_accepts_every_documented_style(tmp_path):
    # CATCHES: all seven cursor styles are accepted and exported, and an
    # unknown one keeps the previous style while reporting the value list.
    values = ["default", "block", "underline", "bar", "blinkblock",
              "blinkunderline", "blinkbar", "bogus", "blinkbar"]
    pairs = [("set terminalcursor " + v, "lf_terminalcursor") for v in values]
    got, res = chain_values(tmp_path, pairs)
    assert got == ["default", "block", "underline", "bar", "blinkblock",
                   "blinkunderline", "blinkbar", "blinkbar", "blinkbar"]
    assert res.errors == [
        "terminalcursor: value should either be 'default', 'block', 'underline', "
        "'bar', 'blinkblock', 'blinkunderline' or 'blinkbar'"
    ]


def test_int_option_parse_and_range_errors(tmp_path):
    # CATCHES: each integer option reports Go's strconv message for junk and
    # its own wording for out-of-range values, keeping the previous value.
    pairs = [
        ("set findlen abc", "lf_findlen"),
        ("set scrolloff abc", "lf_scrolloff"),
        ("set period -1", "lf_period"),
        ("set truncatepct abc", "lf_truncatepct"),
        ("set ratios 0", "lf_ratios"),
        ("set ratios 3:0", "lf_ratios"),
        ("set findlen 4", "lf_findlen"),
    ]
    got, res = chain_values(tmp_path, pairs)
    assert got == ["1", "0", "0", "100", "1:2:3", "1:2:3", "4"]
    assert res.errors == [
        'findlen: strconv.Atoi: parsing "abc": invalid syntax',
        'scrolloff: strconv.Atoi: parsing "abc": invalid syntax',
        "period: value should be a non-negative number",
        'truncatepct: strconv.Atoi: parsing "abc": invalid syntax',
        "ratios: value should be a positive number",
        "ratios: value should be a positive number",
    ]


def test_shell_and_shellflag_options(tmp_path):
    # CATCHES: 'shell' replaces the interpreter while 'shellflag' replaces the
    # '-c' argument, which makes a following shell command fail because the
    # command string is no longer passed as an option argument.
    out = tmp_path / "shellout"
    prepare(tmp_path, lfrc="set shell /bin/bash\n")
    res = run_lf(tmp_path, commands=['$ echo "$lf_shell $lf_shellflag" > ' + str(out), "quit"])
    assert out.read_text() == "/bin/bash -c\n"
    assert res.errors == []
    out2 = tmp_path / "shellout2"
    prepare(tmp_path, lfrc="set shellflag -x\n")
    res = run_lf(tmp_path, commands=['$ echo "$lf_shellflag" > ' + str(out2), "quit"])
    assert not out2.exists()
    assert res.errors == ["running shell: exit status 2"]


def test_path_options_expand_the_os_user_home(tmp_path):
    # CATCHES: '~' in cleaner/previewer/rulerfile is expanded with the passwd
    # home directory of the current user, not with the $HOME the child sees.
    userhome = pwd.getpwuid(os.getuid()).pw_dir
    pairs = [
        ("set cleaner ~/bin/cleaner", "lf_cleaner"),
        ("set previewer ~/bin/previewer", "lf_previewer"),
        ("set rulerfile ~/ruler", "lf_rulerfile"),
    ]
    got, res = chain_values(tmp_path, pairs)
    assert got == [userhome + "/bin/cleaner", userhome + "/bin/previewer",
                   userhome + "/ruler"]
    assert res.errors == []

