"""User command hooks and focus reporting.

CATCHES: the reference runs the 'pre-cd'/'on-cd' hook pair around every
directory change, 'on-quit' when the client quits, 'on-select'/'on-load' as
the cursor and directory contents settle, and 'on-init' only in the
client-server mode; focus events reach the 'on-focus-gained'/'on-focus-lost'
commands only while focus reporting is enabled, which itself follows whether
those commands are defined.  A re-implementation that fires these hooks at
the wrong moments, not at all, or that reports focus unconditionally would
fail the exact hook-ordering, file-content and marker assertions here.
"""

from conftest import prepare, run_lf


def lists(res, name):
    """True when some rendered row lists ``name`` as a whole token."""
    return any(any(t == name for t in line.split()) for line in res.lines())


def hookdir(tmp_path, name):
    d = tmp_path / name
    d.mkdir()
    return d


class TestDirectoryHooks:
    def test_pre_cd_and_on_cd_run_around_each_change(self, tmp_path):
        # CATCHES: pressing 'l' and 'h' changes directory twice, and each
        # change is wrapped in exactly one 'pre-cd' followed by one 'on-cd'
        # hook, in that order; nothing fires at startup.
        d = hookdir(tmp_path, "cd")
        (d / "sub").mkdir()
        (d / "sub" / "marker").write_text("x")
        (d / "afile").write_text("x")
        out = tmp_path / "cd" / "hooks"
        prepare(
            tmp_path / "cd",
            lfrc="cmd pre-cd $ printf 'pre-cd-hook-fired\\n' >> {o}\n"
            "cmd on-cd $ printf 'on-cd-hook-fired\\n' >> {o}\n".format(o=out),
        )
        res = run_lf(tmp_path / "cd", cwd=d, keys=b"lh", quiet=0.6)
        assert out.read_text() == (
            "pre-cd-hook-fired\non-cd-hook-fired\npre-cd-hook-fired\non-cd-hook-fired\n"
        )
        assert lists(res, "afile")
        assert res.errors == []

    def test_on_quit_runs_when_quitting_with_q(self, tmp_path):
        # CATCHES: the 'on-quit' command runs when the client quits by
        # itself, before the process is gone.
        d = hookdir(tmp_path, "quit")
        (d / "aa").write_text("x")
        out = tmp_path / "quit" / "hooks"
        prepare(
            tmp_path / "quit",
            lfrc="cmd on-quit $ printf 'on-quit-hook-fired\\n' > {o}\n".format(o=out),
        )
        res = run_lf(tmp_path / "quit", cwd=d, keys=b"q", quiet=0.6)
        assert out.read_text() == "on-quit-hook-fired\n"
        assert not res.alive
        assert res.errors == []

    def test_on_select_and_on_load_fire(self, tmp_path):
        # CATCHES: moving the cursor down twice fires 'on-select' at least
        # once per move, and loading the directory fires 'on-load'.
        d = hookdir(tmp_path, "selload")
        for n in ("aa", "bb", "cc"):
            (d / n).write_text("x")
        out = tmp_path / "selload" / "hooks"
        prepare(
            tmp_path / "selload",
            lfrc="cmd on-select $ printf 'on-select-hook-fired\\n' >> {o}\n"
            "cmd on-load $ printf 'on-load-hook-fired\\n' >> {o}\n".format(o=out),
        )
        res = run_lf(tmp_path / "selload", cwd=d, keys=b"jj", quiet=0.6)
        lines = out.read_text().splitlines()
        assert lines.count("on-select-hook-fired") >= 2
        assert lines.count("on-load-hook-fired") >= 1
        assert res.errors == []

    def test_on_init_runs_only_with_a_server(self, tmp_path):
        # CATCHES: 'on-init' is sent through the client-server handshake, so
        # it fires in the default server mode but never in '-single' mode.
        d = hookdir(tmp_path, "init")
        (d / "aa").write_text("x")
        out = tmp_path / "init" / "hooks"
        prepare(
            tmp_path / "init",
            lfrc="cmd on-init $ printf 'on-init-hook-fired\\n' > {o}\n".format(o=out),
        )
        res = run_lf(tmp_path / "init", cwd=d, single=False, quiet=0.6)
        assert out.read_text() == "on-init-hook-fired\n"
        assert lists(res, "aa")
        assert res.errors == []
        out.unlink()
        res = run_lf(tmp_path / "init", cwd=d, quiet=0.6)
        assert not out.exists()
        assert lists(res, "aa")
        assert res.errors == []


class TestFocus:
    def test_focus_reporting_follows_the_on_focus_commands(self, tmp_path):
        # CATCHES: with both focus commands defined, the terminal focus
        # sequences '\\x1b[I' and '\\x1b[O' reach the hooks; deleting both
        # commands afterwards turns focus reporting off again, so the same
        # sequences are ignored.
        d = hookdir(tmp_path, "focus")
        (d / "aa").write_text("x")
        base = tmp_path / "focus"
        gained, lost = base / "gained", base / "lost"
        define = (
            "cmd on-focus-gained $ printf 'gained-hook-fired\\n' > {g}\n"
            "cmd on-focus-lost $ printf 'lost-hook-fired\\n' > {l}\n"
        ).format(g=gained, l=lost)
        prepare(base, lfrc=define)
        res = run_lf(base, cwd=d, keys=b"\x1b[I\x1b[O", quiet=0.8)
        assert gained.read_text() == "gained-hook-fired\n"
        assert lost.read_text() == "lost-hook-fired\n"
        assert res.errors == []
        gained.unlink()
        lost.unlink()
        prepare(base, lfrc=define + "cmd on-focus-gained\ncmd on-focus-lost\n")
        res = run_lf(base, cwd=d, keys=b"\x1b[I\x1b[O", quiet=0.8)
        assert not gained.exists()
        assert not lost.exists()
        assert lists(res, "aa")
        assert res.errors == []
