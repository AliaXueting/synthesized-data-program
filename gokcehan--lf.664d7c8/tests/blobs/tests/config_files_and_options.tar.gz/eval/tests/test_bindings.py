"""map/nmap/vmap/cmap/cmd/clearmaps: key and command definitions.

CATCHES: a re-implementation that scopes bindings to the wrong modes (map must
cover normal and visual, nmap/vmap/cmap only their own), that does not delete a
binding when the expression is omitted, that treats '<f-x>'/'<a-x>' sequences
as several keys, or that keeps a deleted command callable would fail these
exact listing, file and message-line assertions.

The pushed keys are queued for the UI loop, so no test here quits the session
from a -command flag: 'quit' and the queued keys would race and the effect of
the key could be lost.  Cursor movements have the same weakness — a queued
movement can be processed before the first directory listing has arrived and
then be lost — so the tests that observe where the cursor ends up send their
keys to the terminal directly, after the first frame has settled.
"""

import pytest

from conftest import prepare, run_lf, row_of


def mkfiles(tmp):
    """A dot file, a plain file and a subdirectory to observe option effects."""
    (tmp / ".dot").write_text("x")
    (tmp / "plain.txt").write_text("x")
    (tmp / "sub").mkdir()


def keys(tmp, lfrc, commands):
    """Run the reference in ``tmp`` with ``lfrc`` and the given pushed keys."""
    prepare(tmp, lfrc=lfrc)
    return run_lf(tmp, cwd=tmp, commands=commands)


def raw_keys(tmp, lfrc, pressed):
    """Run the reference in ``tmp`` with ``lfrc`` and raw terminal keys.

    The keys reach the pty only after the first frame has settled, so a
    cursor movement cannot be lost the way a queued 'push' can.
    """
    prepare(tmp, lfrc=lfrc)
    return run_lf(tmp, cwd=tmp, keys=pressed)


class TestModeScoping:
    def test_map_binds_normal_and_visual_mode(self, tmp_path):
        # CATCHES: 'map' enters the binding in both key tables.
        mkfiles(tmp_path)
        res = keys(tmp_path, "map x :set hidden\n", ["push x"])
        assert row_of(res, ".dot") > 0
        assert res.errors == []
        res = keys(tmp_path, "map x :set hidden\n", ["push V", "push x"])
        assert row_of(res, ".dot") > 0
        assert res.errors == []

    def test_nmap_binds_normal_mode_only(self, tmp_path):
        # CATCHES: an 'nmap' binding is unknown in visual mode.
        mkfiles(tmp_path)
        res = keys(tmp_path, "nmap x :set hidden\n", ["push x"])
        assert row_of(res, ".dot") > 0
        assert res.errors == []
        res = keys(tmp_path, "nmap x :set hidden\n", ["push V", "push x"])
        assert row_of(res, ".dot") < 0
        assert res.errors == ["unknown mapping: x"]

    def test_vmap_binds_visual_mode_only(self, tmp_path):
        # CATCHES: a 'vmap' binding is unknown in normal mode and fires once
        # the visual mode is entered.
        mkfiles(tmp_path)
        res = keys(tmp_path, "vmap x :set dironly\n", ["push x"])
        assert row_of(res, "plain.txt") > 0
        assert res.errors == ["unknown mapping: x"]
        res = keys(tmp_path, "vmap x :set dironly\n", ["push V", "push x"])
        assert row_of(res, "sub") > 0
        assert row_of(res, "plain.txt") < 0
        assert res.errors == []

    def test_vmap_without_expression_deletes_the_binding(self, tmp_path):
        # CATCHES: 'vmap j' with no expression removes the movement key from
        # the visual mode table only: entering visual mode on the first entry
        # ('config') and pressing 'j' leaves the cursor there and reports the
        # key as unknown, while without the deletion the same keys move it
        # down to the second entry ('data').
        mkfiles(tmp_path)
        res = raw_keys(tmp_path, "set promptfmt 'p:%f'\nvmap j\n", b"Vj")
        assert res.line(0) == "p:config"
        assert res.errors == ["unknown mapping: j"]
        res = raw_keys(tmp_path, "set promptfmt 'p:%f'\n", b"Vj")
        assert res.line(0) == "p:data"
        assert res.errors == []


class TestBindingTable:
    def test_map_without_expression_deletes_the_binding(self, tmp_path):
        # CATCHES: omitting the expression removes the binding again, so the
        # key becomes unknown ('x' has no default binding).
        mkfiles(tmp_path)
        res = keys(tmp_path, "map x :set hidden\nmap x\n", ["push x"])
        assert row_of(res, ".dot") < 0
        assert res.errors == ["unknown mapping: x"]

    def test_nmap_without_expression_deletes_a_default_binding(self, tmp_path):
        # CATCHES: 'nmap h' with no expression removes the default 'h'
        # (up-directory) binding from the normal mode table: after entering
        # the first subdirectory ('config', the one the cursor starts on,
        # holding only 'lf') the key is only reported as unknown and the
        # directory is left unchanged, while without the deletion it returns
        # to the start directory with the cursor back on 'config'.
        mkfiles(tmp_path)
        res = raw_keys(tmp_path, "set promptfmt 'p:%f'\nnmap h\n", b"lh")
        assert res.line(0) == "p:lf"
        assert res.errors == ["unknown mapping: h"]
        res = raw_keys(tmp_path, "set promptfmt 'p:%f'\n", b"lh")
        assert res.line(0) == "p:config"
        assert res.errors == []

    def test_map_rebinding_keeps_the_last_expression(self, tmp_path):
        # CATCHES: a second binding for the same key replaces the first.
        mkfiles(tmp_path)
        res = keys(tmp_path, "map x :set hidden\nmap x :set dironly\n", ["push x"])
        assert row_of(res, ".dot") < 0
        assert row_of(res, "sub") > 0
        assert row_of(res, "plain.txt") < 0
        assert res.errors == []

    def test_multiline_key_sequence_waits_for_the_tail(self, tmp_path):
        # CATCHES: 'xy' is one two-key sequence: the prefix alone does nothing
        # and reports nothing, the full sequence triggers it.
        mkfiles(tmp_path)
        res = keys(tmp_path, "map xy :set hidden\n", ["push x"])
        assert row_of(res, ".dot") < 0
        assert res.errors == []
        res = keys(tmp_path, "map xy :set hidden\n", ["push xy"])
        assert row_of(res, ".dot") > 0
        assert res.errors == []

    def test_function_and_alt_key_syntax(self, tmp_path):
        # CATCHES: '<f5>' and '<a-x>' are single keys, not five characters.
        mkfiles(tmp_path)
        res = keys(tmp_path, "map <f5> :set hidden\n", ["push <f5>"])
        assert row_of(res, ".dot") > 0
        assert res.errors == []
        res = keys(tmp_path, "map <a-x> :set dironly\n", ["push <a-x>"])
        assert row_of(res, "sub") > 0
        assert row_of(res, "plain.txt") < 0
        assert res.errors == []

    def test_clearmaps_removes_all_but_the_colon_binding(self, tmp_path):
        # CATCHES: clearmaps empties both key tables but keeps ':' bound, and
        # bindings defined afterwards still work.
        mkfiles(tmp_path)
        res = keys(tmp_path, "clearmaps\n", ["push j"])
        assert res.errors == ["unknown mapping: j"]
        res = keys(tmp_path, "clearmaps\nmap x :set hidden\n", ["push x"])
        assert row_of(res, ".dot") > 0
        assert res.errors == []
        res = keys(tmp_path, "clearmaps\n", ["push :"])
        assert res.line(res.screen.rows - 1) == ":"


class TestCommandMode:
    def test_cmap_binds_keys_of_the_command_line(self, tmp_path):
        # CATCHES: a 'cmap' binding fires while the prompt is open and leaves
        # the prompt on the screen.
        mkfiles(tmp_path)
        res = keys(tmp_path, "cmap <c-a> :set hidden\n", ["push :", "push <c-a>"])
        assert row_of(res, ".dot") > 0
        assert res.errors == []
        assert res.line(res.screen.rows - 1) == ":"

    def test_cmap_is_not_visible_in_normal_mode(self, tmp_path):
        # CATCHES: 'cmap' does not touch the normal mode table, so the same
        # key is unknown outside the prompt.
        mkfiles(tmp_path)
        res = keys(tmp_path, "cmap <c-a> :set hidden\n", ["push <c-a>"])
        assert row_of(res, ".dot") < 0
        assert res.errors == ["unknown mapping: <c-a>"]

    def test_cmap_ignores_plain_rune_keys(self, tmp_path):
        # CATCHES: rune keys are inserted into the prompt before the cmap
        # table is consulted, so 'cmap a' never fires and 'a' is typed in.
        mkfiles(tmp_path)
        res = keys(tmp_path, "cmap a :set hidden\n", ["push :", "push a"])
        assert row_of(res, ".dot") < 0
        assert res.errors == []
        assert res.line(res.screen.rows - 1) == ":a"

    def test_cmap_without_expression_deletes_the_binding(self, tmp_path):
        # CATCHES: 'cmap <c-x>' with no expression removes the command line
        # binding again: the key does nothing while the prompt stays open,
        # whereas the still-bound key runs its shell command.
        out = tmp_path / "cmapout"
        mkfiles(tmp_path)
        prepare(tmp_path, lfrc="cmap <c-x> $ printf fired > %s\n" % out)
        res = run_lf(tmp_path, cwd=tmp_path, commands=["push :", "push <c-x>"])
        assert out.read_text() == "fired"
        assert res.errors == []
        assert res.line(res.screen.rows - 1) == ":"
        out.unlink()
        prepare(tmp_path, lfrc="cmap <c-x> $ printf fired > %s\ncmap <c-x>\n" % out)
        res = run_lf(tmp_path, cwd=tmp_path, commands=["push :", "push <c-x>"])
        assert not out.exists()
        assert res.errors == []
        assert res.line(res.screen.rows - 1) == ":"


class TestUserCommands:
    def test_cmd_define_invoke_and_redefine(self, tmp_path):
        # CATCHES: a command defined in the lfrc can be called from a later
        # -command flag, and redefining it keeps only the last body.
        first, second = tmp_path / "first", tmp_path / "second"
        prepare(tmp_path, lfrc="cmd hello $ printf A > %s\ncmd hello $ printf B > %s\n" % (first, second))
        res = run_lf(tmp_path, commands=["hello", "quit"])
        assert not first.exists()
        assert second.read_text() == "B"
        assert res.errors == []

    def test_cmd_without_expression_deletes_the_command(self, tmp_path):
        # CATCHES: 'cmd name' with no body removes it, so calling it reports
        # 'command not found' and the old body never runs.
        out = tmp_path / "out"
        prepare(tmp_path, lfrc="cmd hello $ printf A > %s\ncmd hello\n" % out)
        res = run_lf(tmp_path, commands=["hello", "quit"])
        assert not out.exists()
        assert res.errors == ["command not found: hello"]

    def test_cmd_invoked_through_a_binding(self, tmp_path):
        # CATCHES: a binding can call a user command by name and the shell
        # command it runs has completed before the client is terminated.
        out = tmp_path / "out"
        mkfiles(tmp_path)
        prepare(tmp_path, lfrc="cmd hi $ printf HI > %s\nmap x hi\n" % out)
        res = run_lf(tmp_path, cwd=tmp_path, commands=["push x"])
        assert out.read_text() == "HI"
        assert res.errors == []
