"""Config file discovery: search paths, -config, -command ordering.

CATCHES: a re-implementation that reads the wrong set of files (e.g. only the
XDG file, or still reading the default files when -config is given), that
reports a missing -config file as an error instead of a log line, or that
evaluates -command flags before the config files.
"""

import os
import pwd

import pytest

from conftest import entry_style, norm_runs, prepare, row_of, run_lf


def read_out(path):
    return path.read_text() if path.exists() else "<missing>"


def reading_lines(res):
    return [res.norm(l) for l in res.log.splitlines() if l.startswith("reading file: ")]


def test_xdg_config_home_lfrc_is_read(tmp_path):
    # CATCHES: the lfrc under $XDG_CONFIG_HOME/lf must be discovered and read.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set tabstop 4\n")
    res = run_lf(tmp_path, commands=['$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert read_out(out) == "4"
    assert reading_lines(res) == ["reading file: <TMP>/config/lf/lfrc"]


def test_missing_default_files_silently_ignored(tmp_path):
    # CATCHES: absent lfrc/colors/icons must not produce errors or log reads.
    out = tmp_path / "o"
    prepare(tmp_path)  # no lfrc, no colors, no icons anywhere
    res = run_lf(tmp_path, commands=['$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert res.errors == []
    assert reading_lines(res) == []
    assert read_out(out) == "8"


def test_lf_config_home_overrides_xdg(tmp_path):
    # CATCHES: $LF_CONFIG_HOME replaces $XDG_CONFIG_HOME for the whole search.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set tabstop 4\n")
    lch = tmp_path / "lch" / "lf"
    lch.mkdir(parents=True)
    (lch / "lfrc").write_text("set tabstop 6\n")
    res = run_lf(tmp_path, env={"LF_CONFIG_HOME": str(tmp_path / "lch")},
                 commands=['$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert read_out(out) == "6"
    assert reading_lines(res) == ["reading file: <TMP>/lch/lf/lfrc"]


def test_lf_config_home_empty_falls_back_to_xdg(tmp_path):
    # CATCHES: an empty $LF_CONFIG_HOME is treated as unset, not as a path.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set tabstop 4\n")
    res = run_lf(tmp_path, env={"LF_CONFIG_HOME": ""},
                 commands=['$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert read_out(out) == "4"
    assert reading_lines(res) == ["reading file: <TMP>/config/lf/lfrc"]


def test_lf_config_home_redirects_colors_and_icons(tmp_path):
    # CATCHES: LF_CONFIG_HOME moves the whole lookup: colors and icons are
    # searched there too (and read before the lfrc), while the XDG-side files
    # are ignored.
    (tmp_path / "sub").mkdir()
    (tmp_path / "plain.txt").write_text("x")
    prepare(tmp_path, colors="fi 31\n", icons="fi X\n")
    lch = tmp_path / "lch" / "lf"
    lch.mkdir(parents=True)
    (lch / "lfrc").write_text("set icons\n")
    (lch / "colors").write_text("fi 01;33\n")
    (lch / "icons").write_text("fi Y\n")
    res = run_lf(tmp_path, env={"LF_CONFIG_HOME": str(tmp_path / "lch")}, cwd=tmp_path)
    assert reading_lines(res) == [
        "reading file: <TMP>/lch/lf/colors",
        "reading file: <TMP>/lch/lf/icons",
        "reading file: <TMP>/lch/lf/lfrc",
    ]
    assert res.errors == []
    # fi colored bold yellow by the lch colors file, icon Y by the lch icons
    # file; the XDG-side colors (fi 31) and icons (fi X) must NOT apply
    row = row_of(res, "plain.txt")
    assert row > 0
    assert entry_style(res, "plain.txt") == "fg3,bold"
    assert ("fg3,bold", "Y plain.txt") in norm_runs(res, row)


def test_config_flag_replaces_search(tmp_path):
    # CATCHES: -config must be used exclusively; the XDG lfrc is not read.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set tabstop 4\n")
    alt = tmp_path / "altrc"
    alt.write_text("set tabstop 9\n")
    res = run_lf(tmp_path, args=["-config", str(alt)],
                 commands=['$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert read_out(out) == "9"
    assert reading_lines(res) == ["reading file: <TMP>/altrc"]


def test_config_flag_missing_file_only_logged(tmp_path):
    # CATCHES: a missing -config target is logged (not an error line) and the
    # default search paths are NOT used as a fallback.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set tabstop 4\n")
    res = run_lf(tmp_path, args=["-config", str(tmp_path / "nope" / "lfrc")],
                 commands=['$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert res.errors == []
    assert read_out(out) == "8"
    assert [res.norm(l) for l in res.log.splitlines() if "exist" in l] == [
        "config file does not exist: stat <TMP>/nope/lfrc: no such file or directory"
    ]
    assert reading_lines(res) == []


def test_command_flags_run_after_config_file(tmp_path):
    # CATCHES: -command is evaluated after the lfrc so it can override it.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set tabstop 4\n")
    res = run_lf(tmp_path, commands=["set tabstop 9",
                                     '$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert read_out(out) == "9"
    assert res.errors == []


def test_command_flags_evaluated_in_order(tmp_path):
    # CATCHES: multiple -command flags apply in the order given.
    out = tmp_path / "o"
    prepare(tmp_path)
    run_lf(tmp_path, commands=["set findlen 3", "set findlen 5",
                               '$ printf %s "$lf_findlen" > ' + str(out), "quit"])
    assert read_out(out) == "5"


def test_lfrc_error_survives_into_session(tmp_path):
    # CATCHES: an error while reading the lfrc is echoed on the message line
    # and does not abort the session: the next statement still applies.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set nosuchopt\nset tabstop 3\n")
    res = run_lf(tmp_path, commands=['$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert res.errors == ["unknown option: nosuchopt"]
    assert read_out(out) == "3"


def test_source_reads_an_extra_config_file(tmp_path):
    # CATCHES: 'source' evaluates another file like a second lfrc, and the
    # file is logged with the same 'reading file:' line as the lfrc itself.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set tabstop 4\n")
    extra = tmp_path / "extra"
    extra.write_text("set tabstop 9\nset scrolloff 2\n")
    res = run_lf(tmp_path, commands=["source " + str(extra),
                                     '$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert read_out(out) == "9"
    assert res.errors == []
    assert reading_lines(res) == [
        "reading file: <TMP>/config/lf/lfrc",
        "reading file: <TMP>/extra",
    ]


def test_source_relative_and_missing_argument(tmp_path):
    # CATCHES: a relative path is opened against the working directory and
    # 'source' without an argument is a message-line error.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="source\n")
    extra = tmp_path / "extra"
    extra.write_text("set tabstop 7\n")
    res = run_lf(tmp_path, commands=["source ./extra",
                                     '$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert read_out(out) == "7"
    assert res.errors == ["source: requires an argument"]


def test_source_missing_file_is_an_error_but_not_fatal(tmp_path):
    # CATCHES: a missing file is reported as an 'opening file:' error, is
    # still logged as read, and the session keeps going.
    out = tmp_path / "o"
    prepare(tmp_path, lfrc="set tabstop 4\n")
    res = run_lf(tmp_path, commands=["source " + str(tmp_path / "nope"),
                                     'set tabstop 5',
                                     '$ printf %s "$lf_tabstop" > ' + str(out), "quit"])
    assert read_out(out) == "5"
    assert res.errors == ["opening file: open " + str(tmp_path / "nope") + ": no such file or directory"]
    assert reading_lines(res) == [
        "reading file: <TMP>/config/lf/lfrc",
        "reading file: <TMP>/nope",
    ]


def test_source_expands_the_os_user_home(tmp_path):
    # CATCHES: '~' in a source path is the passwd home directory, not $HOME,
    # so the reported path names the OS user's home.
    userhome = pwd.getpwuid(os.getuid()).pw_dir
    prepare(tmp_path)
    res = run_lf(tmp_path, commands=["source ~/no-such-lfrc-file", "quit"])
    assert res.errors == [
        "opening file: open %s/no-such-lfrc-file: no such file or directory" % userhome
    ]


def test_source_nests_and_surfaces_inner_errors(tmp_path):
    # CATCHES: a sourced file can source another one, all three are logged,
    # and an error in the innermost file reaches the message line.
    out = tmp_path / "o"
    inner = tmp_path / "inner"
    inner.write_text("set scrolloff 3\nset nosuchopt\n")
    outer = tmp_path / "outer"
    outer.write_text("source %s\nset tabstop 5\n" % inner)
    prepare(tmp_path, lfrc="source %s\n" % outer)
    res = run_lf(tmp_path, commands=['$ printf %s "$lf_tabstop" > ' + str(out),
                                     '$ printf %s "$lf_scrolloff" > ' + str(tmp_path / "s"),
                                     "quit"])
    assert read_out(out) == "5"
    assert read_out(tmp_path / "s") == "3"
    assert res.errors == ["unknown option: nosuchopt"]
    assert reading_lines(res) == [
        "reading file: <TMP>/config/lf/lfrc",
        "reading file: <TMP>/outer",
        "reading file: <TMP>/inner",
    ]
