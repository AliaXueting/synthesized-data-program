"""setlocal: per-directory option overrides.

CATCHES: a re-implementation that keys local options by the raw directory
string instead of the tilde-expanded absolute path, that lets a local value
leak into other directories, that starts a '<option>!' toggle from an
existing local value instead of the global one, or that accepts options the
reference does not support locally would fail these ordering, listing and
message-line assertions.
"""

import pytest

from conftest import prepare, run_lf, row_of


def listing(tmp, lfrc, cwd):
    """Run the reference with ``lfrc`` installed and ``cwd`` as start dir."""
    prepare(tmp, lfrc=lfrc)
    return run_lf(tmp, cwd=cwd)


def row_with(res, name):
    """Row index of the line that lists ``name`` as a whole token (-1 if none).

    Unlike ``row_of`` this also finds entries that are followed by an info
    column, where the name is no longer the last token of the row.
    """
    for i, line in enumerate(res.lines()):
        if any(t == name for t in line.split()):
            return i
    return -1


def mkab(tmp):
    """Two directories holding the same files, so local options can diverge."""
    a, b = tmp / "a", tmp / "b"
    a.mkdir()
    b.mkdir()
    for d in (a, b):
        (d / ".dot").write_text("x")
    return a, b


class TestPaths:
    def test_local_hidden_only_in_the_matching_directory(self, tmp_path):
        # CATCHES: the local value applies to the directory given and to no
        # other directory, while the global default stays in effect elsewhere.
        a, b = mkab(tmp_path)
        res_a = listing(tmp_path, "setlocal %s hidden\n" % a, a)
        res_b = listing(tmp_path, "setlocal %s hidden\n" % a, b)
        assert row_of(res_a, ".dot") > 0
        assert row_of(res_b, ".dot") < 0
        assert res_a.errors == []
        assert res_b.errors == []

    def test_local_directory_is_made_absolute(self, tmp_path):
        # CATCHES: the directory is resolved with filepath.Abs against the
        # process working directory: '.' names the start directory, the bare
        # name 'a' names <start>/a (which does not exist) and a trailing
        # slash is cleaned away.
        a, b = mkab(tmp_path)
        res = listing(tmp_path, "setlocal a hidden\n", a)
        assert row_of(res, ".dot") < 0
        assert res.errors == []
        res = listing(tmp_path, "setlocal . hidden\n", a)
        assert row_of(res, ".dot") > 0
        assert res.errors == []
        res = listing(tmp_path, "setlocal %s/ hidden\n" % a, a)
        assert row_of(res, ".dot") > 0
        assert res.errors == []

    def test_local_tilde_is_not_the_home_environment_variable(self, tmp_path):
        # CATCHES: '~' is expanded with the home directory of the OS user
        # (the passwd database), not with $HOME, which the pinned child
        # environment points at a scratch directory.  With 'set hidden'
        # showing dotfiles globally, a local 'nohidden' keyed at '~' leaves
        # '.dot' listed in that $HOME directory, while spelling the same
        # directory out does hide it.
        prepare(tmp_path)
        home = tmp_path / "home"
        (home / ".dot").write_text("x")
        (home / "plain").write_text("x")
        res = listing(tmp_path, "set hidden\nsetlocal ~ nohidden\n", home)
        assert row_with(res, ".dot") > 0
        assert row_with(res, "plain") > 0
        assert res.errors == []
        res = listing(tmp_path, "set hidden\nsetlocal %s nohidden\n" % home, home)
        assert row_with(res, ".dot") < 0
        assert row_with(res, "plain") > 0
        assert res.errors == []


class TestBools:
    def test_local_bool_toggle_starts_from_the_global_value(self, tmp_path):
        # CATCHES: '<option>!' inherits the global value the first time the
        # directory is seen, then toggles that directory's own value; a
        # second directory starts from the global value again.
        a, b = mkab(tmp_path)
        res = listing(tmp_path, "setlocal %s hidden!\n" % a, a)
        assert row_of(res, ".dot") > 0
        res = listing(tmp_path, "setlocal %s hidden!\nsetlocal %s hidden!\n" % (a, a), a)
        assert row_of(res, ".dot") < 0
        res = listing(tmp_path, "setlocal %s hidden!\n" % a, b)
        assert row_of(res, ".dot") < 0
        assert res.errors == []

    def test_local_bool_value_forms_rejected(self, tmp_path):
        # CATCHES: the plain form refuses a value and the negated form
        # refuses one too, both keeping the global value.
        a, _ = mkab(tmp_path)
        res = listing(tmp_path, "setlocal %s hidden bogus\nsetlocal %s nohidden true\n" % (a, a), a)
        assert res.errors == ["hidden: value should be empty, 'true', or 'false'",
                              "nohidden: unexpected value: true"]
        assert row_of(res, ".dot") < 0

    def test_local_unknown_option_is_rejected(self, tmp_path):
        # CATCHES: setlocal supports a smaller option set than set, so an
        # otherwise valid global option is 'unknown option' here.
        a, _ = mkab(tmp_path)
        res = listing(tmp_path, "setlocal %s tabstop 4\nsetlocal %s nosuchopt\n" % (a, a), a)
        assert res.errors == ["unknown option: tabstop", "unknown option: nosuchopt"]

    def test_local_bool_overrides_a_global_set(self, tmp_path):
        # CATCHES: a local 'no<option>' beats an explicit global 'set hidden'
        # (which lists dotfiles): the dotfile disappears in the matching
        # directory only, while the global value keeps listing it in every
        # other directory.
        a, b = mkab(tmp_path)
        for d in (a, b):
            (d / "plain").write_text("x")
        lfrc = "set hidden\nsetlocal %s nohidden\n" % a
        res_a = listing(tmp_path, lfrc, a)
        res_b = listing(tmp_path, lfrc, b)
        assert row_with(res_a, ".dot") < 0
        assert row_with(res_a, "plain") > 0
        assert row_with(res_b, ".dot") > 0
        assert res_a.errors == []
        assert res_b.errors == []


class TestInfo:
    def test_local_info_size_only_in_the_matching_directory(self, tmp_path):
        # CATCHES: 'info size' adds the size column in the one directory it
        # was set for, leaving the other directory without any info column.
        a, b = tmp_path / "a", tmp_path / "b"
        a.mkdir()
        b.mkdir()
        for d in (a, b):
            (d / "aaa").write_text("x")
            (d / "zzz").write_text("x" * 3000)
        res_a = listing(tmp_path, "setlocal %s info size\n" % a, a)
        res_b = listing(tmp_path, "setlocal %s info size\n" % a, b)
        assert res_a.line(row_with(res_a, "zzz")) == "  b                zzz                       2.9K"
        assert res_a.line(row_with(res_a, "aaa")) == "  a                aaa                         1B  x"
        assert res_b.line(row_with(res_b, "zzz")) == "  b                zzz"
        assert res_a.errors == []
        assert res_b.errors == []

    def test_local_info_cleared_by_an_empty_value(self, tmp_path):
        # CATCHES: 'setlocal <dir> info' with no value stores an empty local
        # list, which still hides the global info column for that directory
        # instead of falling back to it (the parent pane keeps the global
        # column, showing '-' as the size of a directory).
        a, _ = mkab(tmp_path)
        (a / "aaa").write_text("x")
        res = listing(tmp_path, "set info size\nsetlocal %s info\n" % a, a)
        assert res.line(row_with(res, "aaa")) == "  a           -    aaa                             x"
        res = listing(tmp_path, "set info size\n", a)
        assert res.line(row_with(res, "aaa")) == "  a           -    aaa                         1B  x"
        assert res.errors == []

    def test_local_invalid_info_and_sortby_values(self, tmp_path):
        # CATCHES: the local variants reuse the global validation messages
        # and keep the previous state.
        a, _ = mkab(tmp_path)
        res = listing(tmp_path, "setlocal %s info bogus\nsetlocal %s sortby bogus\n" % (a, a), a)
        assert res.errors == [
            "info: should consist of 'size', 'time', 'atime', 'btime', 'ctime', "
            "'perm', 'user', 'group' or 'custom' separated with colon",
            "sortby: value should either be 'natural', 'name', 'size', 'time', "
            "'atime', 'btime', 'ctime', 'ext' or 'custom'",
        ]
        assert row_of(res, ".dot") < 0


class TestDirCounts:
    def dirs(self, tmp):
        """Two directories with subdirectories of distinct entry counts."""
        a, b = tmp / "a", tmp / "b"
        for d in (a, b):
            d.mkdir(parents=True)
            (d / "sub").mkdir()
            for n in ("f1", "f2", "f3"):
                (d / "sub" / n).write_text("x")
            (d / "solo").mkdir()
            (d / "solo" / "one").write_text("x")
            (d / "plain").write_text("y" * 10)
        return a, b

    def pane1(self, res, name):
        """Squeezed text of the styled run that lists ``name`` in pane 1.

        The run is found by the name it contains instead of by screen column:
        when the parent pane holds a long name in the same row ('config' in
        the scratch tree), the run of an unstyled file entry starts a column
        or two left of the pane border.
        """
        for row in range(1, res.screen.rows):
            for _c, _s, text in res.runs(row):
                toks = text.split()
                if name in toks:
                    return " ".join(toks)
        return "<no run for %s>" % name

    def test_local_dircounts_shows_entry_counts_in_the_matching_directory(self, tmp_path):
        # CATCHES: 'setlocal <dir> dircounts' replaces the '-' placeholder of
        # the info column with the number of entries of each subdirectory in
        # that one directory only (1 for 'solo', 3 for 'sub'), leaving the
        # plain sizes of files and the untouched directories as they were.
        a, b = self.dirs(tmp_path)
        lfrc = "set info size\nsetlocal %s dircounts\n" % a
        res_a = listing(tmp_path, lfrc, a)
        res_b = listing(tmp_path, lfrc, b)
        assert self.pane1(res_a, "solo") == "solo 1"
        assert self.pane1(res_a, "sub") == "sub 3"
        assert self.pane1(res_a, "plain") == "plain 10B"
        assert self.pane1(res_b, "solo") == "solo -"
        assert self.pane1(res_b, "sub") == "sub -"
        assert self.pane1(res_b, "plain") == "plain 10B"
        assert res_a.errors == []
        assert res_b.errors == []

    def test_local_dircounts_negated_restores_the_placeholder(self, tmp_path):
        # CATCHES: 'set nodircounts' for the same directory wins over an
        # earlier local 'dircounts' and restores the '-' placeholder, while
        # the toggle form flips the directory's own local value in place
        # (true, then false, then true again).
        a, _ = self.dirs(tmp_path)
        lfrc = "set info size\nsetlocal %s dircounts\nsetlocal %s nodircounts\n" % (a, a)
        res = listing(tmp_path, lfrc, a)
        assert self.pane1(res, "solo") == "solo -"
        assert res.errors == []
        lfrc = "set info size\nsetlocal %s dircounts\nsetlocal %s dircounts!\n" % (a, a)
        res = listing(tmp_path, lfrc, a)
        assert self.pane1(res, "solo") == "solo -"
        assert res.errors == []
        lfrc = (
            "set info size\nsetlocal %s dircounts\nsetlocal %s dircounts!\nsetlocal %s dircounts!\n"
            % (a, a, a)
        )
        res = listing(tmp_path, lfrc, a)
        assert self.pane1(res, "solo") == "solo 1"
        assert res.errors == []


class TestSorting:
    def mkfiles(self, d, names):
        d.mkdir(parents=True, exist_ok=True)
        for n in names:
            (d / n).write_text("x")

    def test_local_sortby_name_and_reverse(self, tmp_path):
        # CATCHES: 'natural' sorts f1,f2,f10 numerically while 'name' sorts
        # them lexically, and a local 'reverse' flips the same directory only.
        a, b = tmp_path / "a", tmp_path / "b"
        self.mkfiles(a, ["f1", "f2", "f10", "zzz"])
        self.mkfiles(b, ["f1", "f2", "f10", "zzz"])
        res = listing(tmp_path, "", a)
        assert row_of(res, "f1") < row_of(res, "f2") < row_of(res, "f10") < row_of(res, "zzz")
        res = listing(tmp_path, "setlocal %s sortby name\n" % a, a)
        assert row_of(res, "f1") < row_of(res, "f10") < row_of(res, "f2") < row_of(res, "zzz")
        res = listing(tmp_path, "setlocal %s sortby name\nsetlocal %s reverse\n" % (a, a), a)
        assert row_of(res, "zzz") < row_of(res, "f2") < row_of(res, "f10") < row_of(res, "f1")
        res = listing(tmp_path, "setlocal %s sortby name\nsetlocal %s reverse\n" % (a, a), b)
        assert row_of(res, "f1") < row_of(res, "f2") < row_of(res, "f10") < row_of(res, "zzz")
        assert res.errors == []

    def test_local_dirfirst_and_dironly(self, tmp_path):
        # CATCHES: 'nodirfirst' mixes the directory into the files by name and
        # a local 'nodironly' undoes a global 'set dironly'.
        a = tmp_path / "a"
        self.mkfiles(a, ["afile", "zfile"])
        (a / "sub").mkdir()
        res = listing(tmp_path, "", a)
        assert row_of(res, "sub") < row_of(res, "afile") < row_of(res, "zfile")
        res = listing(tmp_path, "setlocal %s nodirfirst\n" % a, a)
        assert row_of(res, "afile") < row_of(res, "sub") < row_of(res, "zfile")
        res = listing(tmp_path, "setlocal %s dironly\n" % a, a)
        assert row_of(res, "sub") > 0
        assert row_of(res, "afile") < 0
        assert row_of(res, "zfile") < 0
        res = listing(tmp_path, "set dironly\nsetlocal %s nodironly\n" % a, a)
        assert row_of(res, "sub") > 0
        assert row_of(res, "afile") > 0
        assert res.errors == []

    def test_local_sortignorecase(self, tmp_path):
        # CATCHES: the default ignores case (alpha before Bravo); turning it
        # off locally sorts by code point (Bravo before alpha).
        a, b = tmp_path / "a", tmp_path / "b"
        self.mkfiles(a, ["Bravo", "alpha", "Charlie"])
        self.mkfiles(b, ["Bravo", "alpha", "Charlie"])
        res = listing(tmp_path, "setlocal %s nosortignorecase\n" % a, a)
        assert row_of(res, "Bravo") < row_of(res, "Charlie") < row_of(res, "alpha")
        res = listing(tmp_path, "setlocal %s nosortignorecase\n" % a, b)
        assert row_of(res, "alpha") < row_of(res, "Bravo") < row_of(res, "Charlie")
        assert res.errors == []

    def test_local_sortignoredia(self, tmp_path):
        # CATCHES: with diacritics ignored 'ua'-like names sort before 'zz';
        # 'nosortignoredia' compares the raw code points instead.
        a, b = tmp_path / "a", tmp_path / "b"
        self.mkfiles(a, ["űa", "zz"])
        self.mkfiles(b, ["űa", "zz"])
        res = listing(tmp_path, "setlocal %s nosortignoredia\n" % a, a)
        assert row_of(res, "zz") < row_of(res, "űa")
        res = listing(tmp_path, "setlocal %s nosortignoredia\n" % a, b)
        assert row_of(res, "űa") < row_of(res, "zz")
        assert res.errors == []
