"""Background refresh options: 'watch' and 'period'.

CATCHES: a re-implementation that never starts the file watcher for
'set watch', that leaves the watcher running after 'set nowatch', or whose
'period' ticker keeps firing after being reset to zero would show (or fail
to show) externally created files in these listings.  The test process
itself creates the file while lf sits idle in its event loop, so no key
press or shell command of lf's own can be the cause of a reload.
"""

import time

from conftest import prepare, run_lf


def lists(res, name):
    """True when some rendered row lists ``name`` as a whole token."""
    return any(any(t == name for t in line.split()) for line in res.lines())


def watch_run(tmp_path, name, lfrc="", commands=(), sleep=0.8, quiet=0.6):
    """Start lf in a directory holding 'orig', then create 'newfile' outside.

    The creation happens from the test process once the first frame has
    settled; ``sleep`` keeps the run alive long enough for a watcher or a
    ticker to react before the final screen is taken.
    """
    tmp_path = tmp_path / name
    tmp_path.mkdir()
    d = tmp_path / "d"
    d.mkdir()
    (d / "orig").write_text("x")
    prepare(tmp_path, lfrc=lfrc)

    def during():
        (d / "newfile").write_text("x")
        time.sleep(sleep)

    return run_lf(tmp_path, cwd=d, quiet=quiet, during=during, commands=commands)


class TestWatch:
    def test_watch_option_refreshes_the_listing(self, tmp_path):
        # CATCHES: with 'set watch' an externally created file shows up in
        # the directory listing by itself, while without the option the
        # listing stays on the state it had drawn before.
        res = watch_run(tmp_path, "on", lfrc="set watch\n")
        assert lists(res, "orig")
        assert lists(res, "newfile")
        assert res.errors == []
        res = watch_run(tmp_path, "off", lfrc="")
        assert lists(res, "orig")
        assert not lists(res, "newfile")
        assert res.errors == []

    def test_nowatch_stops_refreshing_after_watch_was_enabled(self, tmp_path):
        # CATCHES: enabling the watcher with a '-command' flag and disabling
        # it again with 'set nowatch' leaves the directory unwatched, so the
        # external change is never picked up.
        res = watch_run(tmp_path, "stop", commands=("set watch", "set nowatch"))
        assert lists(res, "orig")
        assert not lists(res, "newfile")
        assert res.errors == []


class TestPeriod:
    def test_period_option_polls_the_directory(self, tmp_path):
        # CATCHES: 'set period 1' makes lf re-check the current directory
        # every second, so the file created by the test process appears in
        # the listing without any interaction.
        res = watch_run(tmp_path, "tick", lfrc="set period 1\n", sleep=1.4, quiet=0.7)
        assert lists(res, "orig")
        assert lists(res, "newfile")
        assert res.errors == []

    def test_period_zero_stops_polling(self, tmp_path):
        # CATCHES: the default 'period 0' never reloads, and resetting a
        # running 'period 1' back to zero stops the ticker, so in both runs
        # the listing keeps missing the new file while staying usable.
        res = watch_run(tmp_path, "zero", lfrc="", sleep=1.4, quiet=0.7)
        assert lists(res, "orig")
        assert not lists(res, "newfile")
        assert res.errors == []
        res = watch_run(
            tmp_path,
            "reset",
            lfrc="set period 1\nset period 0\n",
            sleep=1.4,
            quiet=0.7,
        )
        assert lists(res, "orig")
        assert not lists(res, "newfile")
        assert res.errors == []
