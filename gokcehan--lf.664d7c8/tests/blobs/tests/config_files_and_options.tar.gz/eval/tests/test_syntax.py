"""lfrc lexer/parser syntax: quoting, escapes, comments, grouping, errors.

CATCHES: a re-implementation with a different tokenizer would diverge on
escape handling inside quotes, on '#' starting a comment mid-token, on the
one-line ':{{ ... }}' form (broken upstream and pinned as such), or on the
exact wording of parse errors shown on the message line.
"""

import pytest

from conftest import opt_value, run_lf, prepare, row_of


class TestComments:
    def test_full_line_comment_ignored(self, tmp_path):
        # CATCHES: a whole line starting with '#' must be skipped entirely.
        val, _ = opt_value(tmp_path, "# nothing here\nset tabstop 7\n", "lf_tabstop")
        assert val == "7"

    def test_trailing_comment_stripped(self, tmp_path):
        # CATCHES: a comment may follow a statement on the same line.
        val, _ = opt_value(tmp_path, "set tabstop 7 # note\n", "lf_tabstop")
        assert val == "7"

    def test_comment_starts_mid_token(self, tmp_path):
        # CATCHES: '#' terminates an unquoted token, so '7#note' scans as '7'.
        val, _ = opt_value(tmp_path, "set tabstop 7#note\n", "lf_tabstop")
        assert val == "7"

    def test_hash_inside_quotes_is_literal(self, tmp_path):
        # CATCHES: quoting protects '#'; it must not start a comment there.
        val, _ = opt_value(tmp_path, "set timefmt 'a #b'\n", "lf_timefmt")
        assert val == "a #b"


class TestQuoting:
    def test_single_quotes_preserve_spaces(self, tmp_path):
        # CATCHES: single-quoted values keep inner whitespace verbatim.
        val, _ = opt_value(tmp_path, "set timefmt 'a b  c'\n", "lf_timefmt")
        assert val == "a b  c"

    def test_single_quotes_no_escape_processing(self, tmp_path):
        # CATCHES: single quotes do NOT process backslash escapes.
        val, _ = opt_value(tmp_path, "set timefmt 'a\\nb'\n", "lf_timefmt")
        assert val == "a\\nb"

    def test_double_quote_newline_escape(self, tmp_path):
        # CATCHES: "\\n" inside double quotes produces a real newline.
        val, _ = opt_value(tmp_path, 'set timefmt "a\\nb"\n', "lf_timefmt")
        assert val == "a\nb"

    def test_double_quote_tab_escape(self, tmp_path):
        # CATCHES: "\\t" inside double quotes produces a real tab.
        val, _ = opt_value(tmp_path, 'set timefmt "a\\tb"\n', "lf_timefmt")
        assert val == "a\tb"

    def test_double_quote_octal_escape(self, tmp_path):
        # CATCHES: octal escapes like \\101 decode to the character 'A'.
        val, _ = opt_value(tmp_path, 'set timefmt "\\101"\n', "lf_timefmt")
        assert val == "A"

    def test_double_quote_unknown_escape_kept(self, tmp_path):
        # CATCHES: an unknown escape keeps the backslash literally.
        val, _ = opt_value(tmp_path, 'set timefmt "a\\qb"\n', "lf_timefmt")
        assert val == "a\\qb"

    def test_double_quote_escaped_quote(self, tmp_path):
        # CATCHES: '\\"' is a literal quote and does not end the string.
        val, _ = opt_value(tmp_path, 'set timefmt "a\\"b"\n', "lf_timefmt")
        assert val == 'a"b'

    def test_empty_quoted_value(self, tmp_path):
        # CATCHES: '' and "" both produce an empty string value.
        val, _ = opt_value(tmp_path, 'set timefmt ""\n', "lf_timefmt")
        assert val == ""
        val, _ = opt_value(tmp_path, "set timefmt ''\n", "lf_timefmt")
        assert val == ""

    def test_unquoted_backslash_space(self, tmp_path):
        # CATCHES: an escaped space does not split an unquoted token.
        val, _ = opt_value(tmp_path, "set timefmt a\\ b\n", "lf_timefmt")
        assert val == "a b"

    def test_unquoted_backslash_semicolon(self, tmp_path):
        # CATCHES: an escaped ';' does not terminate the statement.
        val, _ = opt_value(tmp_path, "set timefmt a\\;b\n", "lf_timefmt")
        assert val == "a;b"

    def test_percent_is_prefix_token_in_values(self, tmp_path):
        # CATCHES: an unquoted '%' is scanned as a shell-pipe prefix, so
        # 'set promptfmt %f' stores only '%' and then fails to parse.
        val, res = opt_value(tmp_path, "set promptfmt %f\n", "lf_promptfmt")
        assert val == "%"
        assert res.errors == ["unexpected token: "]


class TestSeparators:
    def test_two_statements_one_line(self, tmp_path):
        # CATCHES: ';' separates statements on a single line.
        val, _ = opt_value(tmp_path, "set tabstop 4; set scrolloff 2\n",
                           "lf_scrolloff")
        assert val == "2"

    def test_tab_whitespace(self, tmp_path):
        # CATCHES: tabs are whitespace just like spaces.
        val, _ = opt_value(tmp_path, "set\ttabstop\t4\n", "lf_tabstop")
        assert val == "4"

    def test_missing_trailing_newline(self, tmp_path):
        # CATCHES: the last statement needs no trailing newline.
        val, _ = opt_value(tmp_path, "set tabstop 4", "lf_tabstop")
        assert val == "4"

    def test_crlf_line_endings(self, tmp_path):
        # CATCHES: '\\r' is whitespace; CRLF files parse like LF files.
        val, _ = opt_value(tmp_path, "set tabstop 4\r\nset scrolloff 2\r\n",
                           "lf_scrolloff")
        assert val == "2"


class TestColonGroups:
    def test_colon_group_multiline(self, tmp_path):
        # CATCHES: ':' groups statements until end of line.
        val, _ = opt_value(tmp_path, ":set tabstop 4\nset scrolloff 2\n",
                           "lf_scrolloff")
        assert val == "2"

    def test_colon_group_one_line(self, tmp_path):
        # CATCHES: a ':' group can hold ';'-separated statements on one line.
        val, _ = opt_value(tmp_path, ":set tabstop 4; set scrolloff 2\n",
                           "lf_scrolloff")
        assert val == "2"

    def test_colon_braces_multiline(self, tmp_path):
        # CATCHES: ':{{ ... }}' groups statements across several lines.
        val, _ = opt_value(tmp_path,
                           ":{{\nset tabstop 4\nset scrolloff 2\n}}\n",
                           "lf_scrolloff")
        assert val == "2"

    def test_colon_braces_one_line_is_broken(self, tmp_path):
        # CATCHES: ':{{ a; b }}' on ONE line fails upstream: the last value
        # swallows '}}', nothing is evaluated and 'unexpected token' shows.
        val, res = opt_value(tmp_path, ":{{ set tabstop 4; set scrolloff 2 }}\n",
                             "lf_scrolloff")
        assert val == "0"
        assert res.errors == ["unexpected token: "]

    def test_unclosed_braces_silent(self, tmp_path):
        # CATCHES: an unbalanced ':{{' stops parsing without any error.
        val, res = opt_value(tmp_path, ":{{ set tabstop 4\n", "lf_tabstop")
        assert val == "8"
        assert res.errors == []


class TestParseErrors:
    def test_bare_set(self, tmp_path):
        # CATCHES: 'set' with no option both errors in the parser AND
        # evaluates a broken statement ('unknown option' with empty name).
        val, res = opt_value(tmp_path, "set\n", "lf_tabstop")
        assert val == "8"
        assert res.errors == ["unknown option: ", "expected identifier: "]

    def test_setlocal_missing_directory(self, tmp_path):
        # CATCHES: 'setlocal' alone reports the EOF token in its errors.
        _, res = opt_value(tmp_path, "setlocal\n", "lf_tabstop")
        assert res.errors == ["unknown option: EOF", "expected identifier: EOF"]

    def test_setlocal_missing_option(self, tmp_path):
        # CATCHES: 'setlocal /tmp' evaluates an option named after the newline.
        _, res = opt_value(tmp_path, "setlocal /tmp\n", "lf_tabstop")
        assert res.errors == ["unknown option: ", "expected identifier: "]

    def test_bare_semicolon(self, tmp_path):
        # CATCHES: a stray ';' is an unexpected token.
        _, res = opt_value(tmp_path, ";\n", "lf_tabstop")
        assert res.errors == ["unexpected token: ;"]

    def test_bare_closing_braces(self, tmp_path):
        # CATCHES: a stray '}}' is an unexpected token.
        _, res = opt_value(tmp_path, "}}\n", "lf_tabstop")
        assert res.errors == ["unexpected token: }}"]

    def test_bare_colon(self, tmp_path):
        # CATCHES: ':' with nothing after it is an unexpected token (newline).
        _, res = opt_value(tmp_path, ":\n", "lf_tabstop")
        assert res.errors == ["unexpected token: "]

    def test_colon_then_semicolon(self, tmp_path):
        # CATCHES: ': ;' reports the ';' token itself.
        _, res = opt_value(tmp_path, ": ;\n", "lf_tabstop")
        assert res.errors == ["unexpected token: ;"]

    def test_unknown_command(self, tmp_path):
        # CATCHES: a bare word is a call expression and fails at eval time.
        _, res = opt_value(tmp_path, "~\n", "lf_tabstop")
        assert res.errors == ["command not found: ~"]

    def test_double_prefix(self, tmp_path):
        # CATCHES: '$$ cmd' makes the second '$' part of the command text,
        # so the shell fails to run it.
        _, res = opt_value(tmp_path, "$$ echo hi\n", "lf_tabstop")
        assert res.errors == ["running shell: exit status 127"]

    def test_map_without_keys_is_harmless(self, tmp_path):
        # CATCHES: 'map' with no keys deletes a binding named 'EOF' and
        # produces no error at all.
        val, res = opt_value(tmp_path, "map\n", "lf_tabstop")
        assert val == "8"
        assert res.errors == []


class TestPushKeyMode:
    def test_push_hash_is_not_comment(self, tmp_path):
        # CATCHES: after 'push' the scanner is in key mode, so '#x' is a key
        # sequence (both keys unknown) rather than a comment.
        # The keys are queued for the UI loop, so the session must NOT be
        # asked to quit from a -command flag: 'quit' and the queued keys would
        # race (Go picks either ready channel) and the mapping errors could be
        # lost.  Letting the harness terminate lf keeps the ordering stable.
        prepare(tmp_path)
        res = run_lf(tmp_path, commands=["push #x"])
        assert res.errors == ["unknown mapping: #", "unknown mapping: x"]

    def test_push_colon_opens_prompt(self, tmp_path):
        # CATCHES: 'push :' feeds ':' as a key, opening the command prompt
        # (a non-key-mode scanner would treat ':' as a token instead).
        prepare(tmp_path)
        res = run_lf(tmp_path, commands=["push :"])
        assert res.line(res.screen.rows - 1) == ":"

    def test_push_rejects_extra_arguments(self, tmp_path):
        # CATCHES: 'push x;set ...' keeps 'x;set' as one key token, so the
        # following words make push see more than one argument.
        _, res = opt_value(tmp_path, "", "lf_tabstop",
                           commands=["push x;set tabstop 3"])
        assert res.errors == ["push: requires an argument"]

    def test_push_mapped_control_key(self, tmp_path):
        # CATCHES: pushed '<c-x>' reaches the key handler and triggers the
        # binding mapped to it — a dummy binary with no output cannot fake
        # the directory-only listing the mapping produces.
        (tmp_path / "sub").mkdir()
        (tmp_path / "plain.txt").write_text("x")
        prepare(tmp_path, lfrc="map <c-x> :set dironly\n")
        res = run_lf(tmp_path, cwd=tmp_path, commands=["push <c-x>"])
        assert res.errors == []
        assert row_of(res, "sub") > 0
        assert row_of(res, "plain.txt") < 0
