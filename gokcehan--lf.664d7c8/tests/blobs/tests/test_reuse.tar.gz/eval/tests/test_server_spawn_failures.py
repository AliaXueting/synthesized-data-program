"""Auto-started server spawn failures (main.go ``startServer``).

``checkServer()`` starts the detached server with ``detachedCommand(os.Args[0],
"-server")`` -- an ``exec.Command`` over the path the binary was *invoked as*,
not the real executable file behind it.  A process can be launched with an
arbitrary ``argv[0]`` (that is how a shell resolves ``PATH`` entries), so lf
also has to cope with an ``argv[0]`` that no longer names a runnable program.

These tests launch the reference binary through ``run_lf(argv0=...)``: the
real executable runs, but it sees the given string as ``argv[0]``.  The
resulting ``cmd.Start()`` failure is *not fatal* -- ``startServer()`` only
logs it (``starting server: ...``, Go ``log`` prefix, on stderr, because the
client's ``-log`` redirect has not happened yet) and the client carries on to
``client.go::run()`` where it dies on the missing terminal.  The exit status
therefore still comes from the screen failure, and the log file still holds
only the client banner plus that failure.

Everything below was recorded by running ``./executable`` with a fake
``argv[0]``.
"""

import re

import pytest

from conftest import Server, run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: What ``run()`` logs before it touches the terminal.
CLIENT_BANNER = (LOG_PREFIX + r"\*{15} starting client, PID: \d+ \*{15}\n")

#: The tcell failure recorded in a process without a controlling terminal.
SCREEN_FAILURE = (LOG_PREFIX + r"initializing screen: "
                  r"open /dev/tty: no such device or address\n")


@pytest.mark.parametrize("argv0,spawn_error", [
    ("/nonexistent/lf-xyz",
     r"starting server: fork/exec /nonexistent/lf-xyz: no such file or directory\n"),
    ("lf-nonexistent",
     r'starting server: exec: "lf-nonexistent": executable file not found in \$PATH\n'),
])
def test_unrunnable_argv0_logs_starting_server_and_is_not_fatal(
        tmp_path, runtime_dir, home, argv0, spawn_error):
    """A bad ``argv[0]`` only logs; the client still dies at the screen.

    ``startServer()`` reports the exec failure through the ``log`` package
    (date/time prefix, stderr) and returns, so the client reaches its normal
    terminal-less death: exit status 1 with the message on stderr alone.
    """
    # CATCHES: a re-implementation that treats a failed server spawn as fatal
    # would exit with a different status or skip the client log banner
    res = run_lf([], argv0=argv0, runtime_dir=runtime_dir, home=home)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + spawn_error, res.err), res.err
    assert not (runtime_dir / "lf.sock").exists()


def test_argv0_without_exec_bit_reports_permission_denied(tmp_path, runtime_dir,
                                                          home):
    """An ``argv[0]`` naming an existing but unexecutable file fails with EACCES.

    A file that exists but carries no execute permission makes ``fork/exec``
    fail with ``permission denied`` -- a third, distinct diagnostic.
    """
    # CATCHES: the exec error must distinguish a missing file from a present
    # but unexecutable one, and must still not abort the client
    notexec = tmp_path / "not-a-program"
    notexec.write_text("#!not a program\n")
    res = run_lf([], argv0=str(notexec), runtime_dir=runtime_dir, home=home)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(
        LOG_PREFIX + r"starting server: fork/exec %s: permission denied\n"
        % re.escape(str(notexec)), res.err), res.err
    assert not (runtime_dir / "lf.sock").exists()


def test_starting_server_error_is_not_written_to_the_client_log(tmp_path,
                                                                runtime_dir,
                                                                home):
    """The spawn error predates the log redirect: stderr only, log untouched.

    ``log.SetOutput`` happens inside ``run()``, while ``checkServer()`` runs
    earlier in ``main()``, so with ``-log`` the ``starting server`` line must
    appear on stderr and the log file must hold exactly the banner plus the
    screen failure -- nothing about the server.
    """
    # CATCHES: a re-implementation that starts the log (or the server) in a
    # different order puts the spawn error in the wrong stream
    log = tmp_path / "client.log"
    res = run_lf(["-log", str(log)], argv0="/nonexistent/lf-xyz",
                 runtime_dir=runtime_dir, home=home)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(
        LOG_PREFIX + r"starting server: fork/exec /nonexistent/lf-xyz: "
        r"no such file or directory\n", res.err), res.err
    assert re.fullmatch(CLIENT_BANNER + SCREEN_FAILURE, log.read_text())


def test_single_mode_never_spawns_a_server_for_a_bad_argv0(runtime_dir, home):
    """With ``-single`` there is no ``checkServer()``, hence no spawn error.

    The ``starting server`` diagnostic can only come from the auto-start
    path; ``-single`` skips it, so a bogus ``argv[0]`` is never even noticed.
    """
    # CATCHES: a re-implementation that spawns (or probes for) a server even
    # in single mode would print the diagnostic the reference keeps silent
    res = run_lf(["-single"], argv0="/nonexistent/lf-xyz",
                 runtime_dir=runtime_dir, home=home)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    assert not (runtime_dir / "lf.sock").exists()


def test_spawn_failure_is_not_retried_while_the_client_runs(tmp_path,
                                                            runtime_dir,
                                                            home):
    """One failed spawn leaves no socket and no second attempt behind.

    ``checkServer()`` tries exactly once and ``run()`` never re-dials (the
    retry loop lives in ``readExpr()``, which only runs after a screen is
    up), so nothing ever listens on the socket and no extra process outlives
    the client.
    """
    # CATCHES: a re-implementation retrying the spawn or dialing from main
    # would either print repeated errors or leave a socket file behind
    res = run_lf([], argv0="/nonexistent/lf-xyz", runtime_dir=runtime_dir,
                 home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert len(res.err.strip().split("\n")) == 1
    probe = Server(tmp_path)
    probe.runtime_dir = str(runtime_dir)
    probe.home = str(home)
    assert probe.wait(timeout=3) is False
    assert not (runtime_dir / "lf.sock").exists()
