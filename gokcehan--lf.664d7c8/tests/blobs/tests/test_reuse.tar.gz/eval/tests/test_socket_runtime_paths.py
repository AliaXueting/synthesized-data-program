"""Where lf's unix socket lives: XDG_RUNTIME_DIR and its TMPDIR fallback (os.go).

``os.go``'s package ``init()`` decides the socket path before ``main()``
parses a single flag: ``$XDG_RUNTIME_DIR/lf.sock`` when the variable is set
and non-empty, and otherwise a per-user ``lf-<uid>`` directory created inside
``os.TempDir()`` (which follows ``$TMPDIR``).  The fallback directory is
created with owner-only permissions and must be owned by the invoking user;
violations are ``log.Fatalf`` aborts that kill every mode of the program --
``-doc``, ``-help`` and ``-version`` included.  ``checkServer()`` adds one
more wrinkle on the client side: a leftover entry at the socket path is
unlinked before a server is started, which fails for a non-empty directory.
Every expectation below was recorded by running ``./executable`` with TMPDIR
pointing at a private directory inside ``tmp_path``.
"""

import os
import re
import socket
import stat
import subprocess
import time

import pytest

from conftest import EXE, Server, child_env, quit_server, run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: The banner ``serve()`` logs as its very first message.
BANNER = r"\*{15} starting server \*{15}\n"


class TmpdirServer:
    """A headless ``lf -server`` that resolves its socket via the TMPDIR fallback.

    The child is started without ``XDG_RUNTIME_DIR`` and with ``TMPDIR``
    pointing at a private directory, so the per-user fallback directory is
    created there and both the server and the ``-remote`` client agree on
    the same derived socket path.
    """

    def __init__(self, root, tmpdir):
        self.root = str(root)
        self.tmpdir = str(tmpdir)
        self.home = os.path.join(self.root, "home")
        self.proc = None
        self.stderr_path = os.path.join(self.root, "fallback-server.err")
        self._stderr = None

    @property
    def fallback_dir(self):
        """Per-user directory the fallback creates inside TMPDIR."""
        return os.path.join(self.tmpdir, "lf-%d" % os.getuid())

    @property
    def socket_path(self):
        """Socket path the fallback computes: $TMPDIR/lf-<uid>/lf.sock."""
        return os.path.join(self.fallback_dir, "lf.sock")

    def spawn(self):
        """Start the process without waiting for it to become reachable."""
        os.makedirs(self.home, exist_ok=True)
        self._stderr = open(self.stderr_path, "wb")
        self.proc = subprocess.Popen(
            [EXE, "-server"], cwd=self.root,
            stdout=subprocess.DEVNULL, stderr=self._stderr,
            env=child_env(self.home, None, {"TMPDIR": self.tmpdir}))
        return self

    def wait(self, timeout=5):
        """Poll until the fallback socket exists and accepts a connection."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if os.path.exists(self.socket_path):
                try:
                    probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    probe.connect(self.socket_path)
                    probe.close()
                    return True
                except OSError:
                    pass
            if self.proc is not None and self.proc.poll() is not None:
                return False
            time.sleep(0.02)
        return False

    def remote(self, command, timeout=8):
        """Run ``lf -remote <command>`` through the same TMPDIR fallback."""
        return run_lf(["-remote", command], cwd=self.root, home=self.home,
                      env={"TMPDIR": self.tmpdir}, timeout=timeout)

    def stop(self):
        """Tear the server process and its stderr redirect down."""
        if self.proc is not None and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=3)
        if self._stderr is not None:
            self._stderr.close()
            self._stderr = None

    def stderr_text(self):
        """Read back everything the server has written to stderr so far."""
        if not os.path.exists(self.stderr_path):
            return ""
        with open(self.stderr_path, "rb") as fh:
            return fh.read().decode("utf-8", errors="surrogateescape")


def test_socket_falls_back_to_a_per_user_tmpdir(tmp_path, home):
    """Without XDG_RUNTIME_DIR the socket lives in $TMPDIR/lf-<uid>/lf.sock."""
    # CATCHES: the fallback directory is created with owner-only permissions
    # and the server and -remote independently agree on the derived path
    tmpdir = tmp_path / "tmp"
    tmpdir.mkdir()
    srv = TmpdirServer(tmp_path, tmpdir).spawn()
    try:
        assert srv.wait(timeout=5)
        assert stat.S_ISSOCK(os.stat(srv.socket_path).st_mode)
        assert os.stat(srv.fallback_dir).st_mode & 0o777 == 0o700
        listed = srv.remote("list")
        assert listed.rc == 0
        assert listed.out == ""
        assert listed.err == ""
        assert srv.remote("quit").rc == 0
        assert srv.proc.wait(timeout=5) == 0
        assert not os.path.exists(srv.socket_path)
    finally:
        srv.stop()
    assert re.fullmatch(
        LOG_PREFIX + BANNER
        + LOG_PREFIX + r"listen: list\n"
        + LOG_PREFIX + r"listen: quit\n"
        + LOG_PREFIX + r"\*{15} closing server \*{15}\n",
        srv.stderr_text())


@pytest.mark.parametrize("args", [
    ["-version"],
    ["-doc"],
    ["-help"],
    ["-remote", "list"],
    ["-server"],
    ["-single"],
])
def test_tmpdir_pointing_at_a_file_is_fatal_before_any_mode(tmp_path, home, args):
    """A TMPDIR that is a regular file kills the program before flags are read."""
    # CATCHES: the runtime-dir setup runs in package init, so even -doc and
    # -version exit 1 with the mkdir error instead of printing anything
    notadir = tmp_path / "afile"
    notadir.write_text("x")
    res = run_lf(args, home=home, env={"TMPDIR": str(notadir)}, timeout=6)
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"creating runtime dir: mkdir "
                        + re.escape(str(notadir)) + r": not a directory\n",
                        res.err)


@pytest.mark.skipif(os.geteuid() != 0, reason="changing the owner needs root")
def test_fallback_dir_owned_by_another_user_is_fatal(tmp_path, home):
    """A fallback directory owned by someone else is refused with log.Fatal."""
    # CATCHES: os.go verifies the runtime dir's owner after creating it, so
    # a foreign-owned directory aborts startup instead of hosting the socket
    tmpdir = tmp_path / "t"
    fallback = tmpdir / ("lf-%d" % os.getuid())
    fallback.mkdir(parents=True)
    os.chown(fallback, 65534, 65534)
    res = run_lf(["-version"], home=home, env={"TMPDIR": str(tmpdir)},
                 timeout=6)
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"runtime dir not owned by current user: "
                        + re.escape(str(fallback)) + r"\n", res.err)


def test_socket_path_held_by_a_nonempty_directory_is_reported(tmp_path,
                                                              runtime_dir,
                                                              home):
    """A non-empty directory at the socket path cannot be unlinked or replaced."""
    # CATCHES: checkServer logs the failed unlink on stderr before the client
    # still dies on the missing terminal, and the directory is left untouched
    occupied = runtime_dir / "lf.sock"
    (occupied / "keepme").mkdir(parents=True)
    res = run_lf([], runtime_dir=runtime_dir, home=home, timeout=6)
    try:
        assert res.rc == 1
        assert res.out == ""
        assert re.fullmatch(LOG_PREFIX + r"removing socket: remove "
                            + re.escape(str(occupied)) + r": directory not empty\n",
                            res.err)
        assert occupied.is_dir()
        assert (occupied / "keepme").exists()
    finally:
        # the unlink failed, so checkServer() still tried to start a server;
        # it cannot bind over the directory and exits on its own, but reap
        # regardless so this test can never leak a process
        quit_server(runtime_dir)


def test_socket_path_held_by_an_empty_directory_is_replaced(tmp_path,
                                                            runtime_dir, home):
    """An empty directory at the socket path is removed so a server can bind."""
    # CATCHES: unlinking an empty directory succeeds, so startup continues
    # exactly like the stale-regular-file case and leaves a live server
    occupied = runtime_dir / "lf.sock"
    occupied.mkdir()
    res = run_lf([], runtime_dir=runtime_dir, home=home, timeout=6)
    try:
        assert res.rc == 1
        assert res.out == ""
        assert res.err == ""
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        try:
            assert probe.wait(timeout=8)
        finally:
            probe.stop()
        assert stat.S_ISSOCK(os.stat(str(occupied)).st_mode)
        listed = run_lf(["-remote", "list"], runtime_dir=runtime_dir, home=home)
        assert listed.rc == 0
        assert listed.out == ""
        quit_res = run_lf(["-remote", "quit"], runtime_dir=runtime_dir, home=home)
        assert quit_res.rc == 0
    finally:
        # reap the server checkServer() detached after removing the directory
        quit_server(runtime_dir)


@pytest.mark.parametrize("kind", ["file", "directory"])
def test_remote_against_a_non_socket_at_the_socket_path(tmp_path, runtime_dir,
                                                        home, kind):
    """-remote only dials: a non-socket entry yields ECONNREFUSED, not a fix."""
    # CATCHES: unlike client startup, -remote never removes or replaces the
    # offending entry, and both a stale file and a directory dial the same
    occupant = runtime_dir / "lf.sock"
    if kind == "file":
        occupant.write_text("not a socket")
    else:
        occupant.mkdir()
    res = run_lf(["-remote", "list"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"remote command: connecting to server: "
                        r"dial unix " + re.escape(str(occupant))
                        + r": connect: connection refused\n", res.err)
    assert occupant.exists()
