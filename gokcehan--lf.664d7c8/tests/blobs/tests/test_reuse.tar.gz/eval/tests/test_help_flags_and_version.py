"""Usage text, version output and flag-parsing diagnostics (main.go).

``main.go`` replaces the standard ``flag.Usage`` with a hand-written banner
that goes to ``flag.CommandLine.Output()`` -- i.e. stderr -- and lets the
``flag`` package handle everything else.  These tests pin the exact usage
bytes, the ``-version`` line, and the diagnostics the flag package emits for
unknown flags, missing values and malformed booleans, together with the
exit status 2 that goes with them.
"""

import re

import pytest

from conftest import EXE, run_lf

#: Usage banner: everything after the ``Usage: <argv0> [options] [path]``
#: line, exactly as ``flag.PrintDefaults`` renders the option table.
USAGE_BODY = """Arguments:
  path
    \tset the initial directory or select the given file

Options:
  -command command
    \tcommand to execute on client initialization
  -config path
    \tpath to the config file (instead of the usual paths)
  -cpuprofile path
    \tpath to the file to write the CPU profile
  -doc
    \tshow documentation
  -help
    \tshow help
  -last-dir-path path
    \tpath to the file to write the last dir on exit (to use for cd)
  -log path
    \tpath to the log file to write messages
  -memprofile path
    \tpath to the file to write the memory profile
  -print-last-dir
    \tprint the last dir to stdout on exit (to use for cd)
  -print-selection
    \tprint the selected files to stdout on open (to use as open file dialog)
  -remote command
    \tsend remote command to server
  -selection-path path
    \tpath to the file to write selected files on open (to use as open file dialog)
  -server
    \tstart server (automatic)
  -single
    \tstart a client without server
  -version
    \tshow version
"""

#: Full expected stderr of ``-help``.
USAGE_TEXT = ("lf - Terminal file manager\n\nUsage: %s [options] [path]\n\n"
              % EXE) + USAGE_BODY

#: Recorded output of ``-version`` (the value injected at build time).
VERSION_LINE = "r42-664d7c8\n"


def test_help_prints_usage_on_stderr(runtime_dir, home):
    """-help writes the complete usage banner to stderr and exits zero."""
    # CATCHES: the banner, the argv[0] interpolation and every option
    # blurb with its tab indentation must match byte for byte
    res = run_lf(["-help"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == USAGE_TEXT


def test_help_reports_the_invoked_executable_path(runtime_dir, home):
    """The Usage line interpolates the path the binary was invoked with."""
    # CATCHES: the usage line must embed os.Args[0], so a re-implementation
    # hardcoding its own binary name prints a different path
    res = run_lf(["-help"], runtime_dir=runtime_dir, home=home)
    lines = res.err.split("\n")
    assert lines[0] == "lf - Terminal file manager"
    assert lines[1] == ""
    assert lines[2] == "Usage: %s [options] [path]" % EXE
    assert lines[3] == ""
    assert lines[4] == "Arguments:"


@pytest.mark.parametrize("args", [
    ["-help"],
    ["-h"],
    ["-version", "-help"],
    ["-single", "-help"],
    ["-remote", "quit", "-help"],
])
def test_help_variants_and_precedence(runtime_dir, home, args):
    """-help (and the builtin -h) print the usage and win over other modes."""
    # CATCHES: -h is not a declared flag, so it travels through the flag
    # package's ErrHelp path and must still exit 0 with usage on stderr
    res = run_lf(args, runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 0
    assert res.out == ""
    assert res.err == USAGE_TEXT


def test_help_wins_over_doc_when_flag_parsing_fails(runtime_dir, home):
    """``-doc -h`` prints usage, because -h aborts flag parsing first."""
    # CATCHES: the flag package gives up on -h before main() ever sees the
    # -doc value, so the manual must not be printed
    res = run_lf(["-doc", "-h"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == USAGE_TEXT


def test_version_prints_recorded_line_on_stdout(runtime_dir, home):
    """-version writes the build version to stdout and nothing else."""
    # CATCHES: version text, stream and trailing newline are all pinned so
    # a re-implementation cannot emit extra lines or use stderr
    res = run_lf(["-version"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 0
    assert res.out == VERSION_LINE
    assert res.err == ""


def test_version_wins_over_remote_and_server(runtime_dir, home):
    """-version short-circuits -remote and -server without side effects."""
    # CATCHES: a re-implementation that starts a server or dials a socket
    # before honouring -version would fail or leave a socket file behind
    res = run_lf(["-version", "-remote", "quit", "-server"],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 0
    assert res.out == VERSION_LINE
    assert res.err == ""
    assert not (runtime_dir / "lf.sock").exists()


def test_unknown_flag_is_rejected_with_usage(runtime_dir, home):
    """An undefined flag exits 2 with the flag error followed by the usage."""
    # CATCHES: the diagnostic must precede the usage banner on stderr and
    # the process must exit with status 2, not 1
    res = run_lf(["-nosuchflag"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == "flag provided but not defined: -nosuchflag\n" + USAGE_TEXT


@pytest.mark.parametrize("flag", [
    "-remote", "-command", "-config", "-log", "-cpuprofile", "-memprofile",
    "-last-dir-path", "-selection-path",
])
def test_flag_without_argument_is_rejected(runtime_dir, home, flag):
    """A value-taking flag given last exits 2 with ``flag needs an argument``."""
    # CATCHES: every string flag must consume the following argument; the
    # error names the flag and is followed by the usage banner
    res = run_lf([flag], runtime_dir=runtime_dir, home=home)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == ("flag needs an argument: %s\n" % flag) + USAGE_TEXT


@pytest.mark.parametrize("flag", ["-doc", "-help", "-version", "-server",
                                  "-single", "-print-last-dir",
                                  "-print-selection"])
def test_invalid_boolean_value_is_rejected(runtime_dir, home, flag):
    """``-flag=notabool`` exits 2 with the boolean parse diagnostic."""
    # CATCHES: only true/false (and 1/0/t/f) are accepted for boolean
    # flags, and the diagnostic quotes the offending value
    res = run_lf(["%s=notabool" % flag], runtime_dir=runtime_dir, home=home)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == ('invalid boolean value "notabool" for %s: parse error\n'
                       % flag) + USAGE_TEXT


@pytest.mark.parametrize("args", [
    ["-print-last-dir=1", "-single"],
    ["-single=true"],
    ["-single", "--"],
    ["-print-selection=0", "-single"],
    ["-doc=false", "-single"],
])
def test_accepted_boolean_values_reach_the_client(runtime_dir, home, args):
    """Well-formed boolean spellings parse and fall through to the client.

    ``-print-last-dir=1``, ``-single=true`` and a bare ``--`` are all
    accepted by the flag package, so execution continues into the client
    branch, which cannot initialise a screen here and exits 1.
    """
    # CATCHES: a re-implementation that treats "1" as an invalid boolean
    # would exit 2 instead of reaching the client startup failure
    res = run_lf(args, runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""


def test_flag_diagnostics_go_to_stderr_only(runtime_dir, home):
    """Flag errors never leak a partial usage banner onto stdout."""
    # CATCHES: both the diagnostic and the usage belong on stderr; stdout
    # must stay empty even on the failure path
    res = run_lf(["-log"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 2
    assert res.out == ""
    assert res.err.startswith("flag needs an argument: -log\n")
    assert re.match(r"flag needs an argument: -log\n"
                    r"lf - Terminal file manager\n\n"
                    r"Usage: \S+ \[options\] \[path\]\n\n"
                    r"Arguments:\n  path\n"
                    r"    \tset the initial directory or select the given file\n",
                    res.err)
