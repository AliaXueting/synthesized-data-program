"""Unicode behaviour of the server's request tokenizer (``src/misc.go``).

``misc.go`` is this round's prime coverage target, and ``splitWord`` is the
one function in it that the headless CLI reaches: ``server.go`` splits every
``-remote`` request line with it, and ``client.go`` uses it to recognise
``query`` responses.  The native suite pins its ASCII behaviour
(``src/misc_test.go::TestSplitWord``) and the earlier rounds of this module
pinned spaces, tabs and carriage returns.  What none of them cover is that
``splitWord`` trims and splits with Go's ``unicode.IsSpace``, which accepts
far more than ASCII blanks: the vertical tab (U+000B), the form feed
(U+000C), the next line character (U+0085) and the no-break space (U+00A0)
all act as request whitespace, and multi-byte runes pass through the word
untouched because the scan is rune-oriented, not byte-oriented.

Every expectation below was recorded by driving ``./executable -remote``
against a live ``-server``.
"""

import pytest

from conftest import Server, run_lf

#: Whitespace runes accepted by Go's ``unicode.IsSpace`` beyond the ASCII
#: blanks already pinned in ``test_remote_server_protocol.py``.  ids stay
#: ASCII so pytest's parametrize ids remain readable in reports.
UNICODE_SEPARATORS = [
    pytest.param("\x0b", id="vertical-tab"),
    pytest.param("\x0c", id="form-feed"),
    pytest.param("\u0085", id="next-line"),
    pytest.param("\u00a0", id="no-break-space"),
]

#: The four separators above, concatenated into one run.
MIXED_RUN = "\x0b\x0c\u0085\u00a0"


@pytest.mark.parametrize("ws", UNICODE_SEPARATORS)
@pytest.mark.parametrize("command,expected", [
    ("drop", "listen: drop: client ID must be a number\n"),
    ("query", "listen: query: client ID must be a number\n"),
])
def test_unicode_separator_yields_the_same_diagnostic_as_a_space(server, ws,
                                                                 command,
                                                                 expected):
    """A Unicode space between command and argument splits like an ASCII one.

    ``drop <U+000B> xyz`` and ``query <U+00A0> abc`` reach the id-parsing
    branch exactly like ``drop xyz`` does, proving the separator rune was
    consumed while extracting the first word and the argument.
    """
    # CATCHES: splitWord uses unicode.IsSpace, so \v \f U+0085 and U+00A0
    # are request whitespace; an ASCII-only tokenizer would instead report
    # "unexpected command: drop<...>" and never parse the client id
    res = server.remote(command + ws + "xyz")
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


@pytest.mark.parametrize("ws", UNICODE_SEPARATORS)
def test_trailing_unicode_whitespace_lets_the_command_run(server, ws):
    """Trailing Unicode whitespace is trimmed and the command still runs."""
    # CATCHES: "list" followed by \v \f U+0085 or U+00A0 must execute the
    # list command (word "list", empty rest) instead of producing an
    # "unexpected command" echo that still carries the separator rune
    server.connect(4)
    res = server.remote("list" + ws)
    assert res.rc == 0
    assert res.out == "4\n"
    assert res.err == ""
    # the request must not have taken the server down
    assert server.remote("list").out == "4\n"


@pytest.mark.parametrize("ws", UNICODE_SEPARATORS)
def test_leading_unicode_whitespace_is_trimmed_from_the_request(server, ws):
    """A request may start with any Unicode whitespace rune."""
    # CATCHES: splitWord left-trims with unicode.IsSpace, so a leading
    # no-break space or vertical tab vanishes before the command word is
    # scanned; an implementation that only left-trims ASCII blanks would
    # echo "unexpected command: <ws>foo" with the rune still embedded
    res = server.remote(ws + "foo")
    assert res.rc == 0
    assert res.out == "listen: unexpected command: foo\n"
    assert res.err == ""


@pytest.mark.parametrize("ws", UNICODE_SEPARATORS)
def test_unicode_whitespace_splits_a_word_from_within(server, ws):
    """A Unicode space inside a token cuts the word at that rune."""
    # CATCHES: "li<U+00A0>st" is split into the word "li" with "st" as the
    # rest, so the echo names only "li"; treating U+00A0 or U+0085 as a
    # printable glyph (as ls-style displays do) would echo "li...st" whole
    res = server.remote("li" + ws + "st")
    assert res.rc == 0
    assert res.out == "listen: unexpected command: li\n"
    assert res.err == ""


def test_a_run_of_mixed_unicode_whitespace_collapses(server):
    """Runs of mixed Unicode whitespace collapse into one separator."""
    # CATCHES: both the word separator and the left edge of the rest trim
    # whole runs, so "list<VT><FF><NEL><NBSP>" is the plain "list" request
    # and a broadcast payload keeps its interior spacing
    server.connect(4)
    res = server.remote("list" + MIXED_RUN)
    assert res.rc == 0
    assert res.out == "4\n"
    assert res.err == ""
    assert server.remote("list").out == "4\n"


def test_broadcast_payload_keeps_interior_spacing_after_unicode_separators(
        server):
    """A Unicode separator run before a broadcast message is fully trimmed.

    ``send`` with a non-numeric second word broadcasts the rest of the
    request; reaching that rest through no-break spaces must strip every
    separator rune while preserving the payload's interior double space.
    """
    # CATCHES: the rest after the command word is left-trimmed with
    # unicode.IsSpace, so the delivered message is "hello  world" and not
    # one that still starts with U+00A0 runes or lost its inner spacing
    conn = server.connect(4)
    res = server.remote("send" + "\u00a0\u00a0" + "hello  world")
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""
    assert conn.recv(200) == b"hello  world\n"


@pytest.mark.parametrize("word", [
    pytest.param("listé", id="latin-1-supplement"),
    pytest.param("li你st", id="cjk-inside"),
    pytest.param("你好", id="cjk-only"),
])
def test_multibyte_runes_pass_through_the_word_unchanged(server, word):
    """The word scan is rune-oriented, so multi-byte runes survive intact.

    The unexpected-command echo names the extracted word; for inputs made
    of multi-byte UTF-8 runes the echo must carry them back unchanged.
    """
    # CATCHES: a byte-oriented scanner (or a strconv cut at the wrong
    # offset) would split the two-byte é or the three-byte 你 mid-rune and
    # echo a mangled replacement-character word instead of the exact input
    res = server.remote(word)
    assert res.rc == 0
    assert res.out == "listen: unexpected command: " + word + "\n"
    assert res.err == ""


@pytest.mark.parametrize("ws", UNICODE_SEPARATORS)
def test_request_of_only_unicode_whitespace_has_an_empty_word(server, ws):
    """A request consisting of one Unicode whitespace rune is empty."""
    # CATCHES: the whole rune is trimmed away, leaving the empty word that
    # the unexpected-command branch echoes as "command: " with nothing
    # after the colon -- exactly like a plain ASCII space request
    res = server.remote(ws)
    assert res.rc == 0
    assert res.out == "listen: unexpected command: \n"
    assert res.err == ""
