"""Client environment handling and working-directory failures (main.go).

Three corners of ``main.go``'s default (client) branch are observable even
without a terminal:

* ``exportEnvVars()`` runs before ``client.go::run()`` redirects the log, so
  a ``$LF_LEVEL`` that is not a number is reported on stderr with Go's
  ``log`` prefix while the client otherwise fails exactly as usual.
* the current directory is read twice -- once for the zero-argument arity
  check (exit 2) and once inside ``exportEnvVars()`` (exit 1 when a
  positional argument was given) -- and a relative ``-log`` value is made
  absolute even earlier, so a deleted working directory produces three
  distinct outcomes.
* the detached server started by ``checkServer()`` is launched as just
  ``argv[0] -server``, without the client's ``-log``, so it never writes
  into the client's log file.

Every expectation below was recorded by running ``./executable``.
"""

import os
import re
import shutil

from conftest import Server, quit_server, run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: What ``run()`` logs before it touches the terminal.
CLIENT_BANNER = (LOG_PREFIX + r"\*{15} starting client, PID: \d+ \*{15}\n")

#: The tcell failure recorded in a process without a controlling terminal.
SCREEN_FAILURE = (LOG_PREFIX + r"initializing screen: "
                  r"open /dev/tty: no such device or address\n")

#: The plain (untimestamped) diagnostic main.go prints for a lost cwd.
NO_CWD = "getting current directory: getwd: no such file or directory\n"


def run_in_deleted_cwd(args, runtime_dir, home, tmp_path):
    """Run lf once with a working directory that was removed underneath it.

    The directory is created, made the process cwd and unlinked, so the
    child inherits a deleted cwd and every ``getwd`` inside it fails; the
    original cwd is restored afterwards.
    """
    gone = tmp_path / "gone"
    gone.mkdir()
    outer = os.getcwd()
    os.chdir(gone)
    try:
        os.rmdir(gone)
        return run_lf(args, runtime_dir=runtime_dir, home=home, timeout=6)
    finally:
        os.chdir(outer)
        shutil.rmtree(gone, ignore_errors=True)


def test_invalid_lf_level_is_logged_to_stderr(tmp_path, runtime_dir, home):
    """A non-numeric $LF_LEVEL is reported on stderr and then ignored."""
    # CATCHES: the message keeps Go's strconv wording and appears before the
    # log is redirected, so it must land on stderr, not in the -log file
    log = tmp_path / "client.log"
    res = run_lf(["-single", "-log", str(log)], runtime_dir=runtime_dir,
                 home=home, env={"LF_LEVEL": "abc"}, timeout=6)
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r'parsing \$LF_LEVEL: strconv\.Atoi: '
                        r'parsing "abc": invalid syntax\n', res.err)
    assert re.fullmatch(CLIENT_BANNER + SCREEN_FAILURE, log.read_text())


def test_missing_cwd_without_arguments_exits_two(tmp_path, runtime_dir, home):
    """A deleted working directory and no argument is an arity-check failure."""
    # CATCHES: the zero-argument branch reads the cwd before anything else
    # and exits 2 with a plain, untimestamped diagnostic on stderr
    res = run_in_deleted_cwd(["-single"], runtime_dir, home, tmp_path)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == NO_CWD


def test_missing_cwd_with_a_positional_argument_exits_one(tmp_path,
                                                          runtime_dir, home):
    """With a positional argument the cwd is only read by exportEnvVars()."""
    # CATCHES: the arity check is skipped, so the same getwd error is printed
    # by exportEnvVars and the client carries on to die on the terminal
    res = run_in_deleted_cwd(["-single", "somefile"], runtime_dir, home,
                             tmp_path)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == NO_CWD


def test_relative_log_path_with_a_missing_cwd_is_fatal(tmp_path, runtime_dir,
                                                       home):
    """A relative -log value cannot be made absolute without a cwd."""
    # CATCHES: main() absolutises the log path before the client starts, and
    # that failure is a log.Fatal: status 1 with a timestamped stderr line
    res = run_in_deleted_cwd(["-single", "-log", "rel.log"], runtime_dir,
                             home, tmp_path)
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"getting log path: getwd: no such file "
                        r"or directory\n", res.err)


def test_auto_started_server_does_not_write_into_the_client_log(tmp_path,
                                                                runtime_dir,
                                                                home):
    """The server spawned by checkServer() does not inherit the -log path."""
    # CATCHES: startServer execs only ``argv[0] -server``, so the client's
    # log file records exactly the client's own banner and screen failure
    # while the detached server still answers on the socket
    log = tmp_path / "client.log"
    res = run_lf(["-log", str(log)], runtime_dir=runtime_dir, home=home,
                 timeout=6)
    try:
        assert res.rc == 1
        assert res.out == ""
        assert res.err == ""
        assert re.fullmatch(CLIENT_BANNER + SCREEN_FAILURE, log.read_text())
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        try:
            assert probe.wait(timeout=8)
            listed = run_lf(["-remote", "list"], runtime_dir=runtime_dir,
                            home=home)
            assert listed.rc == 0
            assert listed.out == ""
        finally:
            probe.stop()
        quit_res = run_lf(["-remote", "quit"], runtime_dir=runtime_dir, home=home)
        assert quit_res.rc == 0
        assert not (runtime_dir / "lf.sock").exists()
    finally:
        # checkServer() detached the server before the client died: reap it
        # even when an assertion above failed, so the test cannot leak it
        quit_server(runtime_dir)
