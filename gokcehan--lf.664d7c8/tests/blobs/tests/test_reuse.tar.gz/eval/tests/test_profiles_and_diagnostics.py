"""CPU/memory profile flags and their failure ordering (main.go).

``-cpuprofile`` and ``-memprofile`` are handled at opposite ends of
``main()``: the CPU profile file is created (and a failure is fatal)
*before* any meta flag is honoured, while the memory profile is written at
the very end, after ``-doc`` has already printed the manual.  Both files
are gzip-compressed pprof streams, which makes their magic bytes a stable
thing to assert on.  Expectations recorded from ``./executable``.
"""

import os
import re

import pytest

from conftest import run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: pprof streams are gzip members, so they always start with these bytes.
PPROF_MAGIC = b"\x1f\x8b\x08"

#: Exact size of the ``-doc`` output, used to prove it was fully printed.
DOC_BYTES = 88898


def test_cpuprofile_writes_a_gzip_stream(tmp_path, runtime_dir, home):
    """``-cpuprofile path`` produces a non-empty pprof file and exit 0."""
    # CATCHES: the flag must create the file even when lf only prints the
    # documentation, and the result must be a real gzip pprof member
    profile = tmp_path / "cpu.prof"
    res = run_lf(["-doc", "-cpuprofile", str(profile)],
                 runtime_dir=runtime_dir, home=home)
    assert res.rc == 0
    assert res.err == ""
    data = profile.read_bytes()
    assert len(data) > 100
    assert data.startswith(PPROF_MAGIC)


def test_memprofile_writes_a_gzip_stream(tmp_path, runtime_dir, home):
    """``-memprofile path`` produces a non-empty pprof file and exit 0."""
    # CATCHES: the heap profile is flushed after the main body returns, so
    # a re-implementation that forgets the deferred write leaves no file
    profile = tmp_path / "mem.prof"
    res = run_lf(["-doc", "-memprofile", str(profile)],
                 runtime_dir=runtime_dir, home=home)
    assert res.rc == 0
    assert res.err == ""
    data = profile.read_bytes()
    assert len(data) > 100
    assert data.startswith(PPROF_MAGIC)


def test_memprofile_is_skipped_when_the_client_dies(tmp_path, runtime_dir,
                                                    home):
    """A dying client never reaches the memory-profile block in ``main()``.

    The client aborts with ``log.Fatal`` (which calls ``os.Exit``), so the
    heap-profile code that normally runs after the dispatch switch is
    skipped: no file is created, unlike on the ``-doc`` path.
    """
    # CATCHES: a re-implementation that writes the profile from a defer, or
    # that returns from the client instead of exiting, would create the file
    profile = tmp_path / "mem.prof"
    res = run_lf(["-single", "-memprofile", str(profile)],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    assert not profile.exists()


def test_cpuprofile_failure_is_fatal_before_any_output(tmp_path, runtime_dir,
                                                       home):
    """A bad ``-cpuprofile`` path exits 1 before the manual is printed."""
    # CATCHES: the CPU profile file is opened before the meta-flag switch,
    # so stdout must stay empty even though -doc was requested
    res = run_lf(["-doc", "-cpuprofile", str(tmp_path)],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"could not create CPU profile: open "
                        r"\S+: is a directory\n", res.err)


def test_memprofile_failure_is_fatal_after_the_output(tmp_path, runtime_dir,
                                                      home):
    """A bad ``-memprofile`` path exits 1 only after the manual was printed.

    The heap profile is written at the end of ``main()``, so the full
    documentation has already reached stdout when the fatal error appears.
    """
    # CATCHES: swapping the order of the two profile flags' error handling
    # changes whether stdout is empty or holds the whole manual
    res = run_lf(["-doc", "-memprofile", str(tmp_path)],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert len(res.out.encode("utf-8")) == DOC_BYTES
    assert res.out.startswith("NAME\n\nlf - terminal file manager\n")
    assert re.fullmatch(LOG_PREFIX + r"could not create memory profile: open "
                        r"\S+: is a directory\n", res.err)


def test_both_profiles_can_be_written_together(tmp_path, runtime_dir, home):
    """``-cpuprofile`` and ``-memprofile`` coexist and both get filled."""
    # CATCHES: the two flags must not share a file handle or clobber each
    # other, and neither may change the program's exit status
    cpu = tmp_path / "cpu.prof"
    mem = tmp_path / "mem.prof"
    res = run_lf(["-doc", "-cpuprofile", str(cpu), "-memprofile", str(mem)],
                 runtime_dir=runtime_dir, home=home)
    assert res.rc == 0
    assert res.err == ""
    assert len(res.out.encode("utf-8")) == DOC_BYTES
    assert cpu.read_bytes().startswith(PPROF_MAGIC)
    assert mem.read_bytes().startswith(PPROF_MAGIC)
    assert os.path.getsize(str(cpu)) != os.path.getsize(str(mem))


def test_cpuprofile_in_a_missing_directory_is_fatal(tmp_path, runtime_dir,
                                                    home):
    """A ``-cpuprofile`` below a nonexistent directory reports ENOENT."""
    # CATCHES: the profile directory is never created implicitly and the
    # diagnostic is Go's standard open error wording
    res = run_lf(["-doc", "-cpuprofile", str(tmp_path / "nope" / "p.prof")],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"could not create CPU profile: open "
                        r"\S+/nope/p\.prof: no such file or directory\n",
                        res.err)


@pytest.mark.parametrize("companion,flag,rc", [
    ("-single", "-cpuprofile", 1),   # created before the dispatch switch
    ("-single", "-log", 1),          # opened by the client itself
    ("-doc", "-memprofile", 0),      # written after -doc printed the manual
])
def test_profile_flags_accept_relative_paths(tmp_path, runtime_dir, home,
                                             companion, flag, rc):
    """Relative profile/log paths resolve against the working directory."""
    # CATCHES: main() absolutises each of these paths with filepath.Abs
    # before doing anything else, so each file lands in the directory lf was
    # started from and never in the home directory a server would chdir to
    workdir = tmp_path / "work"
    workdir.mkdir()
    res = run_lf([companion, flag, "out.bin"], cwd=workdir,
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == rc
    assert res.err == ""
    assert (workdir / "out.bin").exists()
    assert not (home / "out.bin").exists()
