"""Flag-package ordering rules as seen from the command line (main.go).

``main.go`` hands argument parsing to Go's ``flag`` package and then switches
on the parsed values.  Three of its ordering decisions are observable from
the outside:

* parsing stops at the first non-flag argument, so everything after the
  positional looks like more positionals -- ``lf . -doc`` is an arity error,
  never a manual request, and an undefined flag sitting behind a positional
  is never even diagnosed;
* ``--`` terminates the flags, so ``lf -- -doc`` treats ``-doc`` as the
  positional path (and, without ``-single``, still auto-starts a server);
* string flags take the next argument verbatim, dash or not, so
  ``-remote -version`` sends the command ``-version`` to the server instead
  of printing the version, and ``-log -version`` creates a log file literally
  named ``-version``.

The tests also pin where ``checkServer()`` sits relative to the arity check
(it runs first, so even an exit-2 arity failure leaves a working server
behind) and that a bad ``-config`` path is not validated at startup.

Every expectation below was recorded by running ``./executable``.
"""

import re

import pytest

from conftest import Server, quit_server, run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: The arity diagnostic of the default branch, printed to stderr.
TOO_MANY = "only one file or directory may be specified\n"

#: What ``run()`` logs before it touches the terminal.
CLIENT_BANNER = (LOG_PREFIX + r"\*{15} starting client, PID: \d+ \*{15}\n")

#: The tcell failure recorded in a process without a controlling terminal.
SCREEN_FAILURE = (LOG_PREFIX + r"initializing screen: "
                  r"open /dev/tty: no such device or address\n")


@pytest.mark.parametrize("args", [
    [".", "-doc"],
    [".", "-version"],
    [".", "-nosuchflag"],
    ["--", "-doc", "extra"],
])
def test_parsing_stops_at_the_first_positional_argument(tmp_path, runtime_dir,
                                                        home, args):
    """Anything after the positional is another positional: exit 2, no flags.

    Whether the leftover argument is a valid flag (``-doc``, ``-version``),
    an undefined one (``-nosuchflag``) or a second path, the flag package
    never sees it, so main reports the arity error and exits 2 with no other
    diagnostic and no output on stdout.
    """
    # CATCHES: a re-implementation that parses flags anywhere in the command
    # line (GNU-style permutation) would print the manual or a flag error
    # where the reference rejects the argument count
    try:
        res = run_lf(args, runtime_dir=runtime_dir, home=home, timeout=6)
        assert res.timed_out is False
        assert res.rc == 2
        assert res.out == ""
        assert res.err == TOO_MANY
    finally:
        # checkServer() runs before the arity check, so each of these runs
        # detaches a server; wait for it to bind before telling it to quit,
        # or the reaping below could race a socket that is not there yet
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        probe.wait(timeout=8)
        quit_server(runtime_dir)


def test_arity_failure_still_leaves_a_live_server_behind(tmp_path,
                                                         runtime_dir, home):
    """``checkServer()`` runs before the arity check, so a server survives it.

    The client branch starts the detached server *first* and only then counts
    its positional arguments, so ``lf . -doc`` exits 2 but the auto-started
    server still binds the socket and answers ``-remote`` until it is told
    to quit.
    """
    # CATCHES: a re-implementation validating the argument count before
    # starting the server leaves no socket behind and fails the -remote call
    try:
        res = run_lf([".", "-doc"], runtime_dir=runtime_dir, home=home,
                     timeout=6)
        assert res.timed_out is False
        assert res.rc == 2
        assert res.err == TOO_MANY
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        assert probe.wait(timeout=8)
        listed = run_lf(["-remote", "list"], runtime_dir=runtime_dir,
                        home=home)
        assert listed.rc == 0
        assert listed.out == ""
        assert listed.err == ""
    finally:
        # the arity path really did detach a server: reap it even when an
        # assertion above failed, so the test can never leak the process
        quit_server(runtime_dir)


def test_double_dash_makes_the_next_argument_a_positional(tmp_path,
                                                          runtime_dir, home):
    """``lf -- -doc`` runs the client with ``-doc`` as the initial path.

    The ``--`` terminator ends flag parsing, so the manual is never printed:
    stdout stays empty, the client takes ``-doc`` as its positional argument
    and dies on the missing terminal with exit status 1.
    """
    # CATCHES: a re-implementation treating -doc after -- as the doc request
    # would print the manual and exit 0 instead of failing like a client
    res = run_lf(["--", "-doc"], runtime_dir=runtime_dir, home=home,
                 timeout=6)
    try:
        assert res.timed_out is False
        assert res.rc == 1
        assert res.out == ""
        assert res.err == ""
        # without -single the same run still auto-started a detached server
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        assert probe.wait(timeout=8)
    finally:
        quit_server(runtime_dir)


def test_double_dash_also_neutralises_single(tmp_path, runtime_dir, home):
    """``lf -- -single`` is a plain positional, so a server is started.

    ``-single`` after ``--`` is the positional path, not a flag, so the
    default branch runs with single mode off: a detached server binds the
    socket and the client exits 1 as usual.
    """
    # CATCHES: a re-implementation that keeps scanning for flags after --
    # would skip checkServer() and leave the runtime dir without a socket
    res = run_lf(["--", "-single"], runtime_dir=runtime_dir, home=home,
                 timeout=6)
    try:
        assert res.timed_out is False
        assert res.rc == 1
        assert res.out == ""
        assert res.err == ""
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        assert probe.wait(timeout=8)
    finally:
        quit_server(runtime_dir)


def test_server_wins_over_single_mode(runtime_dir, home):
    """``-server -single`` starts a server; the client branch never runs.

    ``serverMode`` is matched before the default branch, and ``-single`` only
    takes effect inside the latter, so the combination binds the socket and
    keeps serving instead of failing on the missing terminal.
    """
    # CATCHES: a re-implementation that lets -single short-circuit -server
    # would exit 1 immediately instead of staying alive and answering
    srv = Server(runtime_dir)
    srv.runtime_dir = str(runtime_dir)
    srv.home = str(home)
    srv.spawn()
    try:
        assert srv.wait(timeout=8)
        listed = srv.remote("list")
        assert listed.rc == 0
        assert listed.out == ""
        assert listed.err == ""
    finally:
        srv.stop()


def test_string_flags_swallow_a_dash_prefixed_value(server, tmp_path):
    """A string flag takes the next argument verbatim, even a ``-flag``.

    ``-remote -version`` does not print the version: the flag package assigns
    the literal string ``-version`` to ``-remote``, which the server answers
    like any other unknown command -- a response on stdout, exit status 0.
    """
    # CATCHES: a re-implementation that treats -version after -remote as a
    # flag (or rejects a dash value) never delivers "unexpected command"
    res = run_lf(["-remote", "-version"], cwd=str(tmp_path),
                 home=server.home, runtime_dir=server.runtime_dir)
    assert res.timed_out is False
    assert res.rc == 0
    assert res.out == "listen: unexpected command: -version\n"
    assert res.err == ""


def test_log_flag_swallowing_a_dash_value_names_the_file(tmp_path,
                                                         runtime_dir, home):
    """``-log -version`` creates a log file literally named ``-version``.

    The dash-prefixed argument is the log path, so the version is never
    printed: the client runs instead, exits 1, and its banner plus the screen
    failure land in a file called ``-version`` inside the working directory.
    """
    # CATCHES: a re-implementation that parses -version as a flag after -log
    # prints the version and never creates the oddly named log file
    res = run_lf(["-log", "-version", "-single"], cwd=str(tmp_path),
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    odd = tmp_path / "-version"
    assert odd.exists()
    assert re.fullmatch(CLIENT_BANNER + SCREEN_FAILURE, odd.read_text())


def test_missing_config_path_is_not_validated_at_startup(tmp_path,
                                                         runtime_dir, home):
    """A nonexistent ``-config`` path produces no startup diagnostic.

    The config file is only read by the UI loop, which a terminal-less client
    never reaches, so the run fails exactly like any other client start: exit
    status 1, empty streams, and a log file holding only the client banner
    and the screen failure.
    """
    # CATCHES: a re-implementation that stats the -config path eagerly
    # reports a missing file here where the reference stays silent
    log = tmp_path / "client.log"
    res = run_lf(["-config", "/nonexistent/lfrc", "-log", str(log), "-single"],
                 cwd=str(tmp_path), runtime_dir=runtime_dir, home=home,
                 timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    assert re.fullmatch(CLIENT_BANNER + SCREEN_FAILURE, log.read_text())
