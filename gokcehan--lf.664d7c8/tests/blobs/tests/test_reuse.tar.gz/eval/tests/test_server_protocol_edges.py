"""Edge cases of the headless server protocol (server.go, client.go).

This file pushes the ``-remote``/socket protocol from the round-one tests
into its corners: how ``strconv.Atoi`` accepts and rejects client-id
spellings, what happens when a registered connection has vanished (send and
query report the broken pipe but keep the id registered, while the ping
``quit`` sends removes it), how ``quit`` finally exits a server whose whole
client table is dead, what the server's line scanner does with oversized
requests, and the exact framing of ``query`` responses.  A hand-rolled unix
socket acts as the registered lf client wherever the response of a real
client matters.  Every expected byte was recorded from the reference binary.
"""

import os
import re
import socket
import threading
import time

import pytest

from conftest import Server, run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: The banner ``serve()`` logs as its very first message.
BANNER = r"\*{15} starting server \*{15}\n"

#: The write failure the server reports for a vanished client connection.
BROKEN_PIPE = r"write unix \S+/lf\.sock->@: write: broken pipe"


def test_server_log_in_a_missing_directory_is_fatal(tmp_path):
    """``-server -log`` below a nonexistent directory exits 1 before binding."""
    # CATCHES: the server's log file is opened before anything else, so the
    # process dies with the same log.Fatal wording as the client and never
    # creates its socket
    srv = Server(tmp_path, log=tmp_path / "nodir" / "s.log").spawn()
    try:
        assert srv.proc.wait(timeout=5) == 1
        assert re.fullmatch(LOG_PREFIX + r"opening log file: open "
                            r"\S+/nodir/s\.log: no such file or directory\n",
                            srv.stderr_text())
    finally:
        srv.stop()
    assert not os.path.exists(srv.socket_path)


def connect_spelling(server, spelling, identifier):
    """Register a raw socket client whose id is spelled ``spelling``."""
    conn = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    conn.connect(server.socket_path)
    conn.sendall(("conn %s\n" % spelling).encode("utf-8"))
    conn.settimeout(3)
    server.clients.append(conn)
    deadline = time.time() + 3
    while time.time() < deadline:
        if str(identifier) in server.remote("list").out.split():
            return conn
        time.sleep(0.02)
    return conn


@pytest.mark.parametrize("spelling,identifier", [
    ("-5", -5),
    ("+5", 5),
    ("007", 7),
    ("0", 0),
    ("9223372036854775807", 9223372036854775807),
])
def test_conn_id_spellings_register_equivalently(server, spelling, identifier):
    """Client ids go through strconv.Atoi, so odd spellings all register."""
    # CATCHES: signed, zero-padded, zero and int64-max spellings are all
    # accepted and normalised, and list prints them back in canonical form
    connect_spelling(server, spelling, identifier)
    assert server.remote("list").out == "%d\n" % identifier


@pytest.mark.parametrize("spelling", [
    "9223372036854775808",
    "0x10",
    "1.5",
])
def test_conn_id_spellings_beyond_int64_are_rejected(server, spelling):
    """One above int64-max, hex and float spellings are not numbers."""
    # CATCHES: the id must fit Go's int64 -- the exact overflow boundary is
    # pinned, and no other base or decimal notation is accepted
    res = server.remote("conn %s" % spelling)
    assert res.rc == 0
    assert res.out == "listen: conn: client ID must be a number\n"
    assert res.err == ""
    assert server.remote("list").out == ""


def test_send_to_a_vanished_client_keeps_it_registered(server):
    """send to a dead connection reports the broken pipe but keeps the id."""
    # CATCHES: unlike a broadcast, a targeted send only echoes the write
    # error to the requester -- the id stays in the client table, so the
    # next broadcast still finds (and finally drops) it
    conn = server.connect(31)
    conn.close()
    time.sleep(0.2)
    res = server.remote("send 31 hi")
    assert res.rc == 0
    assert re.fullmatch(r"sending command to client 31: " + BROKEN_PIPE
                        + r"\n", res.out)
    assert res.err == ""
    assert server.remote("list").out == "31\n"
    again = server.remote("send anything goes")
    assert again.rc == 0
    assert again.out.startswith("sending command to client 31: ")
    assert server.remote("list").out == ""


def test_query_to_a_vanished_client_keeps_it_registered(server):
    """query to a dead connection reports the broken pipe and keeps the id."""
    # CATCHES: the query write failure reaches the requester as one line
    # with the same broken-pipe wording as send, and the id survives
    conn = server.connect(41)
    conn.close()
    time.sleep(0.2)
    res = server.remote("query 41 files")
    assert res.rc == 0
    assert re.fullmatch(r"sending query to client 41: " + BROKEN_PIPE
                        + r"\n", res.out)
    assert res.err == ""
    assert server.remote("list").out == "41\n"


def test_quit_with_only_a_vanished_client_exits_the_server(server):
    """The quit ping that fails also unregisters, so a dead table quits."""
    # CATCHES: quit only stays alive while the ping succeeds somewhere --
    # with every connection dead the failed ping empties the table and the
    # server shuts down with status 0 and removes its socket
    conn = server.connect(51)
    conn.close()
    time.sleep(0.2)
    res = server.remote("quit")
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""
    assert server.proc.wait(timeout=5) == 0
    assert not os.path.exists(server.socket_path)


def test_quit_pings_live_clients_and_drops_the_dead_ones(server):
    """A mixed table: the live client is pinged, the dead id is forgotten."""
    # CATCHES: quit's ping failure removes exactly the dead id, the live
    # client receives the empty line, and the server keeps serving until
    # the live id is dropped and quit is asked again
    dead = server.connect(21)
    dead.close()
    time.sleep(0.2)
    live = server.connect(22)
    res = server.remote("quit")
    assert res.rc == 0
    assert res.out == ""
    assert live.recv(200) == b"\n"
    assert server.proc.poll() is None
    assert server.remote("list").out == "22\n"
    assert server.remote("drop 22").out == ""
    assert server.remote("quit").rc == 0
    assert server.proc.wait(timeout=5) == 0


def test_quit_force_with_a_vanished_client_still_exits(server):
    """quit! does not care that its farewell write fails on a dead client."""
    # CATCHES: the forced quit closes every connection unconditionally and
    # exits 0 even when the only registered client has already vanished
    conn = server.connect(5)
    conn.close()
    time.sleep(0.2)
    res = server.remote("quit!")
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""
    assert server.proc.wait(timeout=5) == 0


@pytest.mark.parametrize("size", [65536, 70000])
def test_oversized_request_line_resets_the_connection(tmp_path, size):
    """A request line above the server's scanner limit kills only the client."""
    # CATCHES: the server's line scanner gives up on the over-long line and
    # closes the connection with unread data, so -remote itself dies with
    # status 1 -- while the server logs the scanner error and keeps serving
    log = tmp_path / "server.log"
    srv = Server(tmp_path, log=log).start()
    try:
        res = srv.remote("x" * size, timeout=8)
        assert res.rc == 1
        assert res.out == ""
        assert re.fullmatch(LOG_PREFIX + r"remote command: reading response "
                            r"from server: read unix @->\S+/lf\.sock: read: "
                            r"connection reset by peer\n", res.err)
        after = srv.remote("list")
        assert after.rc == 0
        assert after.out == ""
        assert srv.remote("quit").rc == 0
        assert srv.proc.wait(timeout=5) == 0
    finally:
        srv.stop()
    assert re.fullmatch(
        LOG_PREFIX + BANNER
        + LOG_PREFIX + r"listening: bufio\.Scanner: token too long\n"
        + LOG_PREFIX + r"listen: list\n"
        + LOG_PREFIX + r"listen: quit\n"
        + LOG_PREFIX + r"\*{15} closing server \*{15}\n",
        log.read_text())


def test_request_line_at_the_scanner_limit_is_answered(server):
    """A 65535-byte request line still fits the server's line scanner."""
    # CATCHES: the whole line comes back inside the unexpected-command
    # diagnostic, so the echo is neither truncated nor reset
    payload = "z" * 65535
    res = server.remote(payload, timeout=8)
    assert res.rc == 0
    assert res.out == "listen: unexpected command: " + payload + "\n"
    assert res.err == ""
    assert server.remote("list").rc == 0


@pytest.mark.parametrize("cmd", [" ", "\t"])
def test_whitespace_only_requests_are_unexpected_commands(server, cmd):
    """A request of only whitespace has an empty command word."""
    # CATCHES: splitWord trims everything, so the diagnostic echoes an empty
    # word and the response line ends with a space before its newline
    res = server.remote(cmd)
    assert res.rc == 0
    assert res.out == "listen: unexpected command: \n"
    assert res.err == ""


def test_trailing_newline_appends_an_empty_request(server):
    """lf -remote adds its own newline, so a trailing one makes a blank line."""
    # CATCHES: the blank line is itself a (rejected) request, so the reply
    # for the real command is followed by the empty-word diagnostic
    server.connect(4)
    res = server.remote("list\n")
    assert res.rc == 0
    assert res.out == "4\nlisten: unexpected command: \n"
    assert res.err == ""


def test_duplicate_registration_routes_to_the_newest_connection(server):
    """Registering the same id twice keeps only the newest connection."""
    # CATCHES: the client table maps id to connection, so the older socket
    # is silently orphaned -- a send reaches only the most recent one
    first = server.connect(7)
    second = server.connect(7)
    time.sleep(0.2)
    res = server.remote("send 7 hi")
    assert res.rc == 0
    assert res.out == ""
    first.setblocking(False)
    with pytest.raises(Exception):
        first.recv(100)
    assert second.recv(200) == b"hi\n"
    assert server.remote("list").out == "7\n"


def test_query_without_a_key_sends_a_bare_query_line(server):
    """``query <id>`` forwards ``"query "`` with a trailing space to the client."""
    # CATCHES: the state key is the empty string, and the wire line the
    # registered client receives is exactly ``query`` plus one space
    conn = server.connect(9)
    received = {}

    def answer():
        conn.settimeout(5)
        received["data"] = conn.recv(200)
        conn.sendall(b"the-value\n\n")

    worker = threading.Thread(target=answer)
    worker.start()
    res = server.remote("query 9", timeout=6)
    worker.join()
    assert res.rc == 0
    assert res.out == "the-value\n"
    assert res.err == ""
    assert received["data"] == b"query \n"


def test_query_response_may_end_with_eof_instead_of_a_blank_line(server):
    """A client that half-closes ends the response without a blank line."""
    # CATCHES: the forwarding loop also stops at EOF, so the reply is
    # delivered in full and -remote still exits with status 0
    conn = server.connect(10)

    def answer():
        conn.settimeout(5)
        conn.recv(200)
        conn.sendall(b"only-line\n")
        conn.shutdown(socket.SHUT_WR)

    worker = threading.Thread(target=answer)
    worker.start()
    res = server.remote("query 10 files", timeout=6)
    worker.join()
    assert res.rc == 0
    assert res.out == "only-line\n"
    assert res.err == ""


def test_query_response_stops_at_the_first_blank_line(server):
    """Lines after the terminating blank line are never forwarded."""
    # CATCHES: the first empty line ends the response, so anything the
    # client sends afterwards stays unread by the server
    conn = server.connect(11)

    def answer():
        conn.settimeout(5)
        conn.recv(200)
        conn.sendall(b"before\n\nafter\n")

    worker = threading.Thread(target=answer)
    worker.start()
    res = server.remote("query 11 files", timeout=6)
    worker.join()
    assert res.rc == 0
    assert res.out == "before\n"
    assert res.err == ""
    conn.settimeout(0.5)
    with pytest.raises(Exception):
        conn.recv(200)


def test_query_with_an_immediately_blank_response_prints_nothing(server):
    """A client that answers with just the blank line yields empty stdout."""
    # CATCHES: the terminator is consumed by the protocol, so -remote
    # finishes successfully having printed no bytes at all
    conn = server.connect(12)

    def answer():
        conn.settimeout(5)
        conn.recv(200)
        conn.sendall(b"\n")

    worker = threading.Thread(target=answer)
    worker.start()
    res = server.remote("query 12 files", timeout=6)
    worker.join()
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""


def test_send_to_a_negative_client_id_delivers(server):
    """A negative id is a perfectly usable client identifier."""
    # CATCHES: send parses its operand with the same leniency as conn, and
    # list reports the negative id like any other
    conn = server.connect(-3)
    assert server.remote("list").out == "-3\n"
    res = server.remote("send -3 hi")
    assert res.rc == 0
    assert res.out == ""
    assert conn.recv(200) == b"hi\n"
