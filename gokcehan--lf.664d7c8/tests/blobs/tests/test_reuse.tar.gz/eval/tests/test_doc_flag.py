"""The ``-doc`` meta flag: exact documentation bytes on stdout (main.go).

``main.go`` embeds ``doc.txt`` with ``go:embed`` and prints it verbatim with
``fmt.Print`` when ``-doc`` is given, so the whole manual -- including the
option, command and setting tables that the native suite exercises only
through internal helpers -- is part of the program's observable stdout.
Every constant below was recorded by running ``./executable -doc``.
"""

import hashlib

import pytest

from conftest import run_lf

#: Exact size of the ``-doc`` output, in bytes.
DOC_BYTES = 88898

#: SHA-256 of the full ``-doc`` output (recorded from the reference).
DOC_SHA256 = "fcf6edb5dab58c028ad814970108e8c8a2f098dbe0b3d78bfc2512cafd1963ce"

#: First eleven lines of the manual, ending on the DESCRIPTION header.
DOC_HEAD = """NAME

lf - terminal file manager

SYNOPSIS

lf [-command command] [-config path] [-cpuprofile path] [-doc] [-help]
[-last-dir-path path] [-log path] [-memprofile path] [-print-last-dir]
[-print-selection] [-remote command] [-selection-path path] [-server]
[-single] [-version] [path]

DESCRIPTION
"""

#: Last eight lines of the manual: the ruler epilogue.
DOC_TAIL = """The special identifier {{.SPACER}} can be used to divide the ruler into
sections that are spaced evenly from each other.

The default ruler file can be found at
https://github.com/gokcehan/lf/blob/master/etc/ruler.default
"""

#: Every top-level section header, in order.  A header here is a line that
#: is non-empty, starts in column 0, is entirely upper case, contains a
#: letter, and is either the first line or preceded by a blank line.
DOC_HEADERS = [
    "NAME", "SYNOPSIS", "DESCRIPTION", "OPTIONS", "POSITIONAL ARGUMENTS",
    "META OPTIONS", "STARTUP & CONFIGURATION", "SHELL INTEGRATION", "SERVER",
    "DIAGNOSTICS", "EXAMPLES", "QUICK REFERENCE", "CONFIGURATION", "COMMANDS",
    "VISUAL MODE COMMANDS", "COMMAND-LINE MODE COMMANDS", "SETTINGS",
    "ENVIRONMENT VARIABLES", "PWD", "OLDPWD", "LF_LEVEL", "OPENER", "EDITOR",
    "PAGER", "SHELL", "SPECIAL COMMANDS", "PREFIXES", "SYNTAX",
    "KEY MAPPINGS", "PUSH MAPPINGS", "SHELL COMMANDS",
    "PIPING SHELL COMMANDS", "WAITING SHELL COMMANDS",
    "ASYNCHRONOUS SHELL COMMANDS", "REMOTE COMMANDS", "FILE OPERATIONS",
    "SEARCHING FILES", "OPENING FILES", "PREVIEWING FILES",
    "CHANGING DIRECTORY", "LOADING DIRECTORY", "COLORS", "ICONS", "RULER",
]

#: Verbatim manual fragments, each pinned byte for byte.
DOC_EXCERPTS = {
    "positional-arguments": """POSITIONAL ARGUMENTS

path

    Set the starting location. If path is a directory, start in there.
    If it's a file, start in the file's parent directory and select the
    file. When no path is supplied, lf uses the current directory. Only
    accepts one argument.
""",
    "meta-options": """META OPTIONS

-doc

    Show lf's documentation (same content as this file) and exit.

-help

    Show command-line usage and exit.
""",
    "server": """SERVER

-remote command

    Send command to the running server (i.e. send, query, list, quit, or
    quit!). See REMOTE COMMANDS for more details.

-server

    Start the (headless) server process explicitly. Runs in the
    foreground and writes server logs to stderr (or the file set with
    -log). Clients auto-start a server if none is running unless -single
    is used.
""",
    "diagnostics": """DIAGNOSTICS

-log path

    Append runtime log messages to path.

-cpuprofile path

    Write a CPU profile to path. The profile can be used by
    go tool pprof.
""",
    "remote-example": """    lf -remote 'send 1234 echo hello world'
""",
    "lf-level": """LF_LEVEL

The value of this variable is set to the current nesting level when you
run lf from a shell spawned inside lf. You can add the value of this
variable to your shell prompt to make it clear that your shell runs
inside lf. For example, with POSIX shells, you can use
[ -n "$LF_LEVEL" ] && PS1="$PS1""(lf level: $LF_LEVEL) " in your shell
configuration file (e.g. ~/.bashrc).
""",
    "colors-order": """1.  default
2.  LSCOLORS (macOS/BSD ls)
3.  LS_COLORS (GNU ls)
4.  LF_COLORS (lf specific)
5.  colors file (lf specific)
""",
    "startup-configuration": """STARTUP & CONFIGURATION

-command command

    Execute command during client initialization (i.e. after reading
    configuration, before on-init). To execute more than one command,
    you can either use the -command flag multiple times or pass multiple
    commands at once by chaining them with ";".

-config path

    Use the config file at path instead of the normal search locations.
    This only affects which lfrc is read at startup.
""",
    "shell-integration": """SHELL INTEGRATION

-print-last-dir

    Print the last directory to stdout when lf exits. This can be used
    to let lf change your shell's working directory. See
    CHANGING DIRECTORY for more details.

-last-dir-path path

    Same as -print-last-dir, but write the directory to path instead of
    stdout.
""",
}


def test_doc_size_and_digest(runtime_dir, home):
    """-doc writes exactly 88898 bytes of the manual to stdout, exit 0.

    The output is compared by length and SHA-256 so a re-implementation
    cannot drift by a single byte anywhere in the embedded manual.
    """
    # CATCHES: a manual that differs by even one byte (or trailing
    # newline) changes the digest and the recorded byte count
    res = run_lf(["-doc"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 0
    assert res.err == ""
    assert len(res.out.encode("utf-8")) == DOC_BYTES
    assert hashlib.sha256(res.out.encode("utf-8")).hexdigest() == DOC_SHA256


def test_doc_begins_with_name_synopsis_description(runtime_dir, home):
    """The manual opens with the NAME/SYNOPSIS/DESCRIPTION headers verbatim."""
    # CATCHES: the embedded manual must start with the man-page style
    # headers and the exact four-line synopsis, not a usage dump
    res = run_lf(["-doc"], runtime_dir=runtime_dir, home=home)
    assert res.out.startswith(DOC_HEAD)


def test_doc_ends_with_ruler_section_epilogue(runtime_dir, home):
    """The manual ends with the ruler epilogue and a single trailing newline."""
    # CATCHES: no extra blank line or missing newline at the very end of
    # the embedded documentation
    res = run_lf(["-doc"], runtime_dir=runtime_dir, home=home)
    assert res.out.endswith(DOC_TAIL)
    assert not res.out.endswith("\n\n")


def test_doc_section_headers_in_order(runtime_dir, home):
    """All 44 top-level section headers appear, in the recorded order."""
    # CATCHES: reordering, renaming, adding or dropping a section of the
    # manual is visible in the extracted header sequence
    res = run_lf(["-doc"], runtime_dir=runtime_dir, home=home)
    lines = res.out.split("\n")
    headers = [
        line
        for i, line in enumerate(lines)
        if (line and not line[0].isspace() and line == line.upper()
            and any(c.isalpha() for c in line)
            and (i == 0 or lines[i - 1] == ""))
    ]
    assert len(lines) > 2000  # the whole manual was printed, not a stub
    assert headers == DOC_HEADERS


@pytest.mark.parametrize("name", sorted(DOC_EXCERPTS))
def test_doc_verbatim_sections(runtime_dir, home, name):
    """Selected manual sections are reproduced byte for byte."""
    # CATCHES: wording, indentation or wrapping drift inside the manual's
    # positional-argument, server, diagnostics, colors and env-var sections
    res = run_lf(["-doc"], runtime_dir=runtime_dir, home=home)
    assert DOC_EXCERPTS[name] in res.out


@pytest.mark.parametrize("args", [
    ["-doc"],
    ["--doc"],
    ["-doc", "-help"],
    ["-doc", "-version"],
    ["-doc", "-remote", "quit"],
    ["-doc", "-server"],
    ["-doc", "-single"],
    ["-doc", "."],
])
def test_doc_wins_over_every_other_mode(runtime_dir, home, args):
    """-doc short-circuits help, version, remote, server and the client.

    ``main.go`` evaluates the meta flags in a fixed order (doc, help,
    version, remote, server, client), so -doc always wins and, crucially,
    no server is started and no socket file is left behind.
    """
    # CATCHES: a re-implementation that checks -server or -remote before
    # -doc would hang, print the wrong stream or create a socket file
    res = run_lf(args, runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 0
    assert res.err == ""
    assert res.out.startswith("NAME\n\nlf - terminal file manager\n\nSYNOPSIS\n")
    assert len(res.out.encode("utf-8")) == DOC_BYTES
    assert not (runtime_dir / "lf.sock").exists()


def test_doc_is_not_written_to_stderr(runtime_dir, home):
    """-doc keeps the manual on stdout; stderr stays completely empty."""
    # CATCHES: -help writes its usage to stderr while -doc writes the
    # manual to stdout, so the two meta flags must not share a stream
    res = run_lf(["-doc"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 0
    assert res.err == ""
    assert res.out.count("\n") == 2592
    # the usage banner belongs to -help, never to -doc
    assert "lf - Terminal file manager" not in res.out
    assert "flag provided but not defined" not in res.out


def test_doc_synopsis_lists_every_flag_in_order(runtime_dir, home):
    """The four-line synopsis enumerates all 15 flags in canonical order."""
    # CATCHES: a flag that is added, dropped or reordered in the synopsis
    # no longer matches the recorded four-line block
    res = run_lf(["-doc"], runtime_dir=runtime_dir, home=home)
    lines = res.out.split("\n")
    start = lines.index("SYNOPSIS") + 2
    synopsis = lines[start:start + 4]
    assert synopsis == [
        "lf [-command command] [-config path] [-cpuprofile path] [-doc] [-help]",
        "[-last-dir-path path] [-log path] [-memprofile path] [-print-last-dir]",
        "[-print-selection] [-remote command] [-selection-path path] [-server]",
        "[-single] [-version] [path]",
    ]
    assert lines[start + 4] == ""
    assert lines[start + 5] == "DESCRIPTION"
