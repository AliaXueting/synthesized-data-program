"""Startup against a user that is absent from the user database (os.go).

lf resolves the current user during package initialization, before any
flag is parsed.  The reference build uses Go's pure-Go ``os/user`` stub,
which cannot look a uid up in ``/etc/passwd`` and instead falls back to
the environment: with ``$HOME`` and ``$USER`` both set the fallback
succeeds silently, while a missing variable is a hard ``panic`` that
kills every mode (``-version``, ``-server``, ``-remote`` alike) with
exit status 2 before anything else runs.

The fallback is also what ``-server`` uses for its working directory:
``main()`` chdirs to ``$HOME`` before binding the socket, and a chdir
failure is only logged -- the server still starts and answers.

These paths need a uid that maps to no passwd entry, so the tests copy
the binary into ``tmp_path`` and drop privileges to an unused uid (4242)
via ``preexec_fn``.  Everything the demoted process touches is addressed
RELATIVE to a working directory inside ``tmp_path`` (the chdir happens
as root before the uid drop), so the demoted child never has to traverse
the mode-0700 pytest temporary-directory chain above it; ``HOME=.`` is
used for the healthy case because the server binds its socket relative
to ``$HOME`` after the chdir.

Every expectation below was recorded by running ``./executable``.
"""

import collections
import grp
import os
import pwd
import re
import shutil
import socket
import subprocess
import time

import pytest

from conftest import EXE

#: Outcome of one demoted lf invocation, mirroring conftest.RunResult.
Run = collections.namedtuple("Run", "rc out err")

#: An unused uid/gid pair: the demoted user must not exist in the user
#: database, otherwise ``user.Current()`` would succeed the normal way.
DEMOTED_UID = 4242

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: Server banner written to the log/stderr when ``serve()`` starts.
BANNER = r"\*{15} starting server \*{15}\n"

#: Recorded wording of the pure-Go stub's error for a missing $HOME.
HOME_STUB_ERROR = ("user: user: Current requires cgo or $HOME set in "
                   "environment\npanic: $HOME variable is empty or not set\n")

#: Recorded wording of the pure-Go stub's error for a missing $USER.
USER_STUB_ERROR = ("user: user: Current requires cgo or $USER set in "
                   "environment\npanic: $USER variable is empty or not set\n")

#: The pinned environment handed to the demoted child; ``HOME`` and
#: ``USER`` are added per case.  ``XDG_RUNTIME_DIR`` stays relative (and
#: is always set) so the fallback never tries to create ``/tmp/lf-<uid>``.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "TERM": "xterm",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "XDG_RUNTIME_DIR": "runtime",
}


def demoted_env(home, user):
    """Build the demoted child's environment, passing GOCOVERDIR through.

    ``home``/``user`` of ``None`` leave the variable unset, which is how
    the panic cases are arranged.  The coverage variable is merged in for
    the same reason ``conftest.child_env`` does it: an instrumented build
    warns on stderr when it is missing, and emits no counters.
    """
    env = dict(BASE_ENV)
    if home is not None:
        env["HOME"] = home
    if user is not None:
        env["USER"] = user
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env["GOCOVERDIR"] = value
    return env

pytestmark = pytest.mark.skipif(
    os.geteuid() != 0,
    reason="dropping to an unused uid to defeat the passwd lookup needs root")


class DemotedWorld:
    """A ``tmp_path`` subtree fully owned by the demoted uid.

    The binary is copied to ``bin/lf`` (the reference under ``/root`` is
    unreachable for the demoted uid) and every directory the child needs
    is chowned to it, so the whole scenario stays inside ``tmp_path``.
    """

    def __init__(self, root):
        self.root = root
        self.world = root / "world"
        for sub in ("bin", "home", "runtime"):
            (self.world / sub).mkdir(parents=True)
        self.binary = self.world / "bin" / "lf"
        shutil.copy(EXE, str(self.binary))
        os.chmod(str(self.binary), 0o755)
        for sub in ("", "bin", "home", "runtime"):
            path = self.world / sub if sub else self.world
            os.chown(str(path), DEMOTED_UID, DEMOTED_UID)
        os.chmod(str(self.world / "runtime"), 0o700)
        self.socket_path = self.world / "runtime" / "lf.sock"
        self.proc = None
        self._stderr_path = None
        self._stderr_file = None

    @staticmethod
    def _demote():
        os.setgid(DEMOTED_UID)
        os.setuid(DEMOTED_UID)

    def _popen(self, args, home):
        return subprocess.Popen(
            ["./bin/lf"] + args,
            cwd=str(self.world),
            env=demoted_env(home, "looser"),
            stdout=subprocess.DEVNULL,
            stderr=self._stderr_file,
            preexec_fn=self._demote)

    def run(self, args, home=".", user="looser"):
        """Run the demoted binary once; ``home``/``user`` of ``None`` unset it."""
        proc = subprocess.run(
            ["./bin/lf"] + args,
            cwd=str(self.world),
            env=demoted_env(home, user),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
            preexec_fn=self._demote)
        return Run(proc.returncode,
                   proc.stdout.decode("utf-8", errors="surrogateescape"),
                   proc.stderr.decode("utf-8", errors="surrogateescape"))

    def start_server(self, home):
        """Spawn ``-server`` with the given ``$HOME`` and wait for the socket."""
        self._stderr_path = self.root / "server.err"
        self._stderr_file = open(str(self._stderr_path), "wb")
        self.proc = self._popen(["-server"], home)
        deadline = time.time() + 5
        while time.time() < deadline:
            if self.socket_path.exists():
                probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                try:
                    probe.connect(str(self.socket_path))
                    probe.close()
                    return self
                except OSError:
                    pass
            if self.proc.poll() is not None:
                break
            time.sleep(0.02)
        self.stop()
        raise RuntimeError("demoted lf -server did not start listening")

    def stderr_text(self):
        """Everything the spawned server has written to stderr so far."""
        if self._stderr_file is not None:
            self._stderr_file.flush()
        if self._stderr_path is None or not self._stderr_path.exists():
            return ""
        return self._stderr_path.read_bytes().decode(
            "utf-8", errors="surrogateescape")

    def stop(self):
        """Quit the spawned server, falling back to a signal if needed."""
        if self.proc is not None and self.proc.poll() is None:
            try:
                self.run(["-remote", "quit"], home=".")
            except subprocess.SubprocessError:
                pass
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.terminate()
                self.proc.wait(timeout=3)
        if self._stderr_file is not None:
            self._stderr_file.close()
            self._stderr_file = None
            self._stderr_path = None


@pytest.fixture
def world(tmp_path):
    """A demoted-uid sandbox; a live server is reaped on teardown."""
    try:
        pwd.getpwuid(DEMOTED_UID)
        pytest.skip("uid %d already maps to a real user" % DEMOTED_UID)
    except KeyError:
        pass
    try:
        grp.getgrgid(DEMOTED_UID)
        pytest.skip("gid %d already maps to a real group" % DEMOTED_UID)
    except KeyError:
        pass
    sandbox = DemotedWorld(tmp_path)
    yield sandbox
    sandbox.stop()


def test_server_with_a_usable_home_directory_starts_cleanly(world):
    """With $HOME and $USER set the user fallback succeeds silently."""
    # CATCHES: the passwd miss must not log anything -- the server's stderr
    # holds only the banner, and the socket answers normally
    world.start_server(home=".")
    assert re.fullmatch(LOG_PREFIX + BANNER, world.stderr_text())
    listed = world.run(["-remote", "list"], home=".")
    assert listed.rc == 0
    assert listed.out == ""
    assert listed.err == ""
    assert re.fullmatch(LOG_PREFIX + BANNER + LOG_PREFIX + "listen: list\n",
                        world.stderr_text())
    quit_run = world.run(["-remote", "quit"], home=".")
    assert quit_run.rc == 0
    assert world.proc.wait(timeout=5) == 0
    assert not world.socket_path.exists()


@pytest.mark.parametrize("home,reason", [
    ("missing-home", "no such file or directory"),
    ("homefile", "not a directory"),
])
def test_server_with_an_unusable_home_directory_still_serves(world, home, reason):
    """A chdir failure is logged once and the server starts anyway."""
    # CATCHES: -server chdirs to $HOME before binding; the failure must be
    # non-fatal, logged with the plain chdir wording, ahead of the banner
    if home == "homefile":
        path = world.world / "homefile"
        path.write_text("i am not a directory\n")
        os.chown(str(path), DEMOTED_UID, DEMOTED_UID)
    world.start_server(home=home)
    assert re.fullmatch(LOG_PREFIX + "chdir " + re.escape(home) + ": "
                        + re.escape(reason) + "\n" + LOG_PREFIX + BANNER,
                        world.stderr_text())
    listed = world.run(["-remote", "list"], home=home)
    assert listed.rc == 0
    assert listed.out == ""
    assert listed.err == ""
    quit_run = world.run(["-remote", "quit"], home=home)
    assert quit_run.rc == 0
    assert world.proc.wait(timeout=5) == 0
    assert not world.socket_path.exists()


@pytest.mark.parametrize("mode", [
    ["-version"],
    ["-server"],
    ["-remote", "list"],
])
def test_missing_home_variable_panics_before_any_mode_runs(world, mode):
    """Without $HOME the pure-Go user stub panics during initialization."""
    # CATCHES: the panic precedes flag handling, so every mode dies with
    # status 2 and the same doubled "user:" line plus the panic message
    res = world.run(mode, home=None)
    assert res.rc == 2
    assert res.out == ""
    assert re.match(LOG_PREFIX + re.escape(HOME_STUB_ERROR), res.err)
    assert "goroutine 1 [running]:" in res.err
    assert not world.socket_path.exists()


@pytest.mark.parametrize("mode", [
    ["-version"],
    ["-server"],
    ["-remote", "list"],
])
def test_missing_user_variable_panics_before_any_mode_runs(world, mode):
    """Without $USER the pure-Go user stub panics during initialization."""
    # CATCHES: the stub demands $USER just like $HOME, with its own message
    # and panic line, again before any mode-specific code can run
    res = world.run(mode, user=None)
    assert res.rc == 2
    assert res.out == ""
    assert re.match(LOG_PREFIX + re.escape(USER_STUB_ERROR), res.err)
    assert "goroutine 1 [running]:" in res.err
    assert not world.socket_path.exists()
