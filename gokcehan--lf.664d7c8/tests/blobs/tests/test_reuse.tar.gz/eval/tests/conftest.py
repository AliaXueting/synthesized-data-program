"""Black-box CLI test helpers for the lf reference binary (test_reuse module).

Every test in this suite drives the reference implementation exclusively
through its command line interface.  The behaviors pinned here were mined
from the repository's native Go test suite -- most notably
``src/misc_test.go::TestSplitWord``, whose word/rest splitting rules are
what the server applies to every ``-remote`` request it reads from the
socket -- together with the ``-doc``/``-help``/``-version``/``-server``
code paths in ``src/main.go``, ``src/server.go`` and ``src/os.go``.

lf is a terminal file manager, so its interactive half needs a controlling
terminal.  These tests therefore target the parts of the program that are
observable without one: the meta flags, the argument/flag diagnostics, the
log and profile files it writes, and the headless server together with the
``-remote`` client used to talk to it.

The child process environment is fully pinned (``PATH``, ``HOME``,
``TERM``, ``XDG_RUNTIME_DIR``) so host settings cannot change the recorded
behavior, and every run happens inside the test's ``tmp_path`` so the unix
socket lf uses for client/server IPC is created in a private directory
instead of the real ``/run/user/<uid>/lf.sock``.
"""

import os
import socket
import subprocess
import time

import pytest

#: Resolved through PROGRAMGYM_EXECUTABLE (set by eval/run.sh) so the same
#: tests run unchanged against the reference binary and any candidate build.
EXE = os.environ.get("PROGRAMGYM_EXECUTABLE", "executable")

#: Per-run timeout: the whole suite must stay well under the harness budget.
TIMEOUT_SECONDS = 10

#: How long to wait for a freshly started server to begin listening.
SERVER_START_TIMEOUT = 4

#: Minimal, deterministic environment for the child process.  ``HOME`` and
#: ``XDG_RUNTIME_DIR`` are filled in per run from the test's ``tmp_path``.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "TERM": "xterm-256color",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
}


def child_env(home=None, runtime_dir=None, extra=None):
    """Build the pinned child environment, merging case-specific overrides."""
    env = dict(BASE_ENV)
    if home is not None:
        env["HOME"] = str(home)
    if runtime_dir is not None:
        env["XDG_RUNTIME_DIR"] = str(runtime_dir)
    env.update(extra or {})
    # Coverage instrumentation hook: the pipeline rebuilds the reference with
    # ``go build -cover`` and points ``GOCOVERDIR`` at a counter directory.
    # Pass the variable through so reference-source coverage is measured.
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env.update({"GOCOVERDIR": value})
    return env


class RunResult:
    """Outcome of one lf invocation: exit status plus decoded output."""

    __slots__ = ("rc", "out", "err", "timed_out")

    def __init__(self, rc, out, err, timed_out=False):
        self.rc = rc
        self.out = (out or b"").decode("utf-8", errors="surrogateescape")
        self.err = (err or b"").decode("utf-8", errors="surrogateescape")
        #: True when the invocation had to be killed after ``timeout``.
        self.timed_out = timed_out

    def __repr__(self):
        return "RunResult(rc=%r, out=%r, err=%r, timed_out=%r)" % (
            self.rc, self.out, self.err, self.timed_out)


def run_lf(args, stdin="", cwd=None, home=None, runtime_dir=None, env=None,
           timeout=TIMEOUT_SECONDS, argv0=None):
    """Run the reference lf binary once and return a :class:`RunResult`.

    :param args:        CLI arguments; non-strings are converted with ``str()``.
    :param stdin:       text (or bytes) fed to the child's standard input.
    :param cwd:         working directory for the child process.
    :param home:        directory used as ``HOME`` (created when missing).
    :param runtime_dir: directory used as ``XDG_RUNTIME_DIR``; this is where
                        the ``lf.sock`` unix socket is created.
    :param env:         extra environment variables overriding the pinned base.
    :param timeout:     seconds before the child is killed; a killed child is
                        reported through ``RunResult.timed_out``.
    :param argv0:       override for the child's ``argv[0]``: the real
                        executable still runs, but lf sees this string as the
                        path it was invoked as (used to exercise the
                        ``startServer()`` code path, which re-execs
                        ``argv[0] -server``).
    """
    if home is not None:
        os.makedirs(home, exist_ok=True)
    if runtime_dir is not None:
        os.makedirs(runtime_dir, exist_ok=True)
        os.chmod(runtime_dir, 0o700)
    argv = [argv0 if argv0 is not None else EXE] + [str(a) for a in args]
    try:
        proc = subprocess.run(
            argv,
            input=stdin.encode("utf-8") if isinstance(stdin, str) else stdin,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(cwd) if cwd is not None else None,
            env=child_env(home, runtime_dir, env),
            timeout=timeout,
            executable=EXE if argv0 is not None else None,
        )
    except subprocess.TimeoutExpired as exc:
        return RunResult(None, exc.stdout or b"", exc.stderr or b"", True)
    return RunResult(proc.returncode, proc.stdout, proc.stderr, False)


def quit_server(runtime_dir, timeout=2):
    """Ask whatever server listens in ``runtime_dir`` to quit, best-effort.

    A client run without ``-single`` leaves a detached ``lf -server`` behind
    (started by ``checkServer()``), and a ``quit`` request is the only handle
    on it.  Tests that trigger such a start call this in a ``finally`` so the
    server is reaped even when an assertion fails halfway through.  The
    request goes over a raw socket (no extra process to spawn) and is
    silently ignored when nothing is listening.
    """
    path = os.path.join(str(runtime_dir), "lf.sock")
    if not os.path.exists(path):
        return
    conn = None
    try:
        conn = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        conn.settimeout(timeout)
        conn.connect(path)
        conn.sendall(b"quit\n")
        while conn.recv(4096):
            pass  # drain until the exiting server closes the connection
    except OSError:
        pass
    finally:
        if conn is not None:
            try:
                conn.close()
            except OSError:
                pass


class Server:
    """A headless ``lf -server`` bound to a private unix socket.

    The server is the only long-lived lf process that does not need a
    terminal, so it (plus the ``-remote`` client and hand-rolled socket
    clients that speak the same protocol) is the main window onto the
    program's behavior.
    """

    #: Distinguishes the redirect files of servers sharing one tmp_path.
    _sequence = 0

    def __init__(self, root, log=None, create_runtime=True):
        self.root = str(root)
        self.runtime_dir = os.path.join(self.root, "runtime")
        self.home = os.path.join(self.root, "home")
        self.log = log
        self.create_runtime = create_runtime
        self.proc = None
        self.clients = []
        Server._sequence += 1
        tag = Server._sequence
        self.stdout_path = os.path.join(self.root, "server-%d.out" % tag)
        self.stderr_path = os.path.join(self.root, "server-%d.err" % tag)
        self._stdout = None
        self._stderr = None

    @property
    def socket_path(self):
        """Path of the unix socket the server listens on."""
        return os.path.join(self.runtime_dir, "lf.sock")

    def spawn(self):
        """Start the process without waiting for it to become reachable."""
        if self.create_runtime:
            os.makedirs(self.runtime_dir, exist_ok=True)
            os.chmod(self.runtime_dir, 0o700)
        os.makedirs(self.home, exist_ok=True)
        argv = [EXE, "-server"]
        if self.log is not None:
            argv += ["-log", str(self.log)]
        # Redirect to files (not pipes) so a chatty server can never block on
        # a full pipe, and so tests can inspect what it printed.
        self._stdout = open(self.stdout_path, "wb")
        self._stderr = open(self.stderr_path, "wb")
        self.proc = subprocess.Popen(
            argv,
            cwd=self.root,
            stdout=self._stdout,
            stderr=self._stderr,
            env=child_env(self.home, self.runtime_dir),
        )
        return self

    def start(self):
        """Spawn the server and block until its socket accepts connections."""
        self.spawn()
        if not self.wait():
            self.stop()
            raise RuntimeError("lf -server did not start listening on %s"
                               % self.socket_path)
        return self

    def wait(self, timeout=SERVER_START_TIMEOUT):
        """Poll until the socket both exists and accepts a connection."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if os.path.exists(self.socket_path):
                try:
                    probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    probe.connect(self.socket_path)
                    probe.close()
                    return True
                except OSError:
                    pass
            if self.proc is not None and self.proc.poll() is not None:
                return False
            time.sleep(0.02)
        return False

    def remote(self, command, timeout=TIMEOUT_SECONDS):
        """Run ``lf -remote <command>`` against this server."""
        return run_lf(["-remote", command], cwd=self.root, home=self.home,
                      runtime_dir=self.runtime_dir, timeout=timeout)

    def connect(self, client_id):
        """Open a socket client and register it with ``conn <id>``."""
        conn = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        conn.connect(self.socket_path)
        conn.sendall(("conn %d\n" % client_id).encode("utf-8"))
        conn.settimeout(3)
        self.clients.append(conn)
        # give the server's manage() goroutine a moment to record the id
        deadline = time.time() + 3
        while time.time() < deadline:
            if str(client_id) in self.remote("list").out.split():
                return conn
            time.sleep(0.02)
        return conn

    def stop(self):
        """Tear the server and every socket client we opened down.

        The server is asked to quit over its socket before anything else: a
        graceful exit is the behavior the tests themselves pin, and it is
        also what lets a coverage-instrumented build flush its counters to
        ``GOCOVERDIR`` (a SIGTERM kills the process before they are
        written, which would silently understate server coverage).  Only
        when the server ignores the request do we fall back to signals.
        """
        for conn in self.clients:
            try:
                conn.close()
            except OSError:
                pass
        self.clients = []
        if self.proc is not None and self.proc.poll() is None:
            self._request_quit()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
                    self.proc.wait(timeout=3)
        for handle in (self._stdout, self._stderr):
            if handle is not None:
                try:
                    handle.close()
                except OSError:
                    pass
        self._stdout = None
        self._stderr = None

    def _request_quit(self, timeout=2):
        """Best-effort ``quit!`` so a live server exits and unlinks its socket.

        ``quit!`` (unlike ``quit``) exits even while client ids are still
        registered, which is exactly what a teardown needs.  The request is
        silently dropped when nothing accepts on the socket anymore.
        """
        conn = None
        try:
            conn = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            conn.settimeout(timeout)
            conn.connect(self.socket_path)
            conn.sendall(b"quit!\n")
            while conn.recv(4096):
                pass  # drain until the exiting server closes the connection
        except OSError:
            pass
        finally:
            if conn is not None:
                try:
                    conn.close()
                except OSError:
                    pass

    def stderr_text(self):
        """Read back everything the server has written to stderr so far."""
        if not os.path.exists(self.stderr_path):
            return ""
        with open(self.stderr_path, "rb") as fh:
            return fh.read().decode("utf-8", errors="surrogateescape")


@pytest.fixture
def runtime_dir(tmp_path):
    """Private XDG_RUNTIME_DIR so no test ever touches a real lf socket."""
    path = tmp_path / "runtime"
    path.mkdir()
    os.chmod(str(path), 0o700)
    return path


@pytest.fixture
def home(tmp_path):
    """Private HOME directory handed to every child process."""
    path = tmp_path / "home"
    path.mkdir()
    return path


@pytest.fixture
def server(tmp_path):
    """A running ``lf -server``; automatically torn down after the test."""
    srv = Server(tmp_path).start()
    yield srv
    srv.stop()
