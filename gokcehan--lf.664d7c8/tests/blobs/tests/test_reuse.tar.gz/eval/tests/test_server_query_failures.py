"""Failure paths of the ``query`` round-trip and of broadcasts (server.go).

``manage()`` is the single goroutine that owns the server's client table,
so every way a ``query`` can go wrong is also a way the table can be left
in an inconsistent state.  Three such failures are observable through the
CLI and pinned here:

* a response line longer than the server's 64 KiB scanner limit kills the
  response reader (``bufio.Scanner: token too long``) -- the error is sent
  to the requester *and* logged, while the queried id stays registered;
* a client that closes its connection with the ``query`` line still unread
  aborts the pending read with ``connection reset by peer`` -- again the
  id stays registered, because only ``broadcast`` prunes dead ids;
* a requester that vanishes while its response is being forwarded makes
  every forwarded line fail with ``write: broken pipe`` -- the server logs
  one line per failure and keeps serving the next request.

A ``send`` whose first word is not a number is a broadcast, and a
broadcast to an empty client table must be completely silent.

Every expectation below was recorded by running ``./executable``.
"""

import re
import socket
import threading
import time

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: Server banner written to the log/stderr when ``serve()`` starts.
BANNER = r"\*{15} starting server \*{15}\n"


def remote_in_thread(server, command):
    """Run ``lf -remote <command>`` in the background; return a result dict.

    A ``query`` blocks its requester until the queried client answers, so
    the test has to keep driving the client sockets while the ``-remote``
    process is waiting for its response.
    """
    result = {}

    def runner():
        result["res"] = server.remote(command)

    thread = threading.Thread(target=runner)
    thread.start()
    return result, thread


def test_query_response_with_an_oversized_line_reports_the_scanner_error(server):
    """A response line past the 64 KiB scanner limit ends the query with an error."""
    # CATCHES: the reader error is forwarded to the requester (mixed with the
    # lines already received) while the queried id remains registered
    c5 = server.connect(5)
    result, thread = remote_in_thread(server, "query 5 key")
    try:
        assert c5.recv(100) == b"query key\n"
        c5.sendall(b"value\n")
        c5.sendall(b"A" * 70000 + b"\n")
        c5.sendall(b"tail\n")
        thread.join(10)
        res = result["res"]
        assert res.rc == 0
        assert res.out == ("value\nreading query response from client 5: "
                           "bufio.Scanner: token too long\n")
        assert res.err == ""
    finally:
        thread.join(10)
        c5.close()
    listed = server.remote("list")
    assert listed.rc == 0
    assert listed.out == "5\n"
    assert re.search(LOG_PREFIX + re.escape(
        "reading query response from client 5: bufio.Scanner: token too long\n"),
        server.stderr_text())


def test_query_response_aborted_by_the_client_keeps_the_id_registered(server):
    """A client closing with the query line unread resets the pending read."""
    # CATCHES: the read error names the reset and, unlike a broadcast, a
    # failed query must NOT prune the id from the client table
    c5 = server.connect(5)
    result, thread = remote_in_thread(server, "query 5 key")
    try:
        # give the server time to write "query key" into c5's buffer; the
        # client then closes without ever reading it, which aborts the
        # server's blocked read instead of ending it cleanly
        time.sleep(1.0)
        c5.close()
        thread.join(10)
        res = result["res"]
        assert res.rc == 0
        pattern = (re.escape("reading query response from client 5: read unix ")
                   + re.escape(server.socket_path) + re.escape("->@: read: ")
                   + "connection reset by peer\n")
        assert re.fullmatch(pattern, res.out)
        assert res.err == ""
    finally:
        thread.join(10)
        c5.close()
    listed = server.remote("list")
    assert listed.rc == 0
    assert listed.out == "5\n"


def test_query_to_a_requester_that_vanishes_logs_forwarding_errors(server):
    """A requester that disappears gets one broken-pipe log line per answer."""
    # CATCHES: forwarding failures are logged (not sent anywhere), one line
    # per response line, and the server keeps serving later queries
    c5 = server.connect(5)
    try:
        # raw requester: asks for the query, then hangs up without reading
        requester = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        requester.connect(server.socket_path)
        requester.sendall(b"query 5 key\n")
        requester.close()

        assert c5.recv(100) == b"query key\n"
        c5.sendall(b"one\ntwo\nthree\n\n")

        # manage() is serial: once "list" answers, the query is fully done
        # and every forwarding failure has been written to the log
        listed = server.remote("list")
        assert listed.rc == 0
        assert listed.out == "5\n"

        broken = re.findall(LOG_PREFIX + re.escape(
            "forwarding query response from client 5: write unix ")
            + re.escape(server.socket_path)
            + re.escape("->@: write: broken pipe\n"), server.stderr_text())
        assert len(broken) == 3

        # the server and the client id both survive the failed forwarding
        result, thread = remote_in_thread(server, "query 5 other")
        try:
            assert c5.recv(100) == b"query other\n"
            # a query response is terminated by a blank line; without it the
            # server keeps scanning the client and the requester blocks
            c5.sendall(b"ok\n\n")
            thread.join(15)
            assert "res" in result and result["res"].timed_out is False
            assert result["res"].rc == 0
            assert result["res"].out == "ok\n"
            assert result["res"].err == ""
        finally:
            thread.join(15)
    finally:
        c5.close()


def test_broadcast_with_no_registered_clients_is_silent(server):
    """A broadcast to an empty client table produces no output at all."""
    # CATCHES: "send <non-number>" degrades to a broadcast, which must be a
    # no-op -- no error, no newline -- when nobody is connected
    first = server.remote("send hello world")
    assert first.rc == 0
    assert first.out == ""
    assert first.err == ""
    second = server.remote("send xyz")
    assert second.rc == 0
    assert second.out == ""
    assert second.err == ""
    text = server.stderr_text()
    assert re.search(LOG_PREFIX + "listen: send hello world\n", text)
    assert re.search(LOG_PREFIX + "listen: send xyz\n", text)
