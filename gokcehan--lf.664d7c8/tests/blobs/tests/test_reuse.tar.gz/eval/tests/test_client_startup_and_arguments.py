"""Client startup, positional arguments and log files (main.go, client.go).

``main.go`` validates its single positional argument and the ``-log`` path
before anything else, then either hands control to ``checkServer()`` (which
silently starts a detached ``lf -server`` when the socket is missing or
dead) or, with ``-single``, goes straight into ``client.go::run()``.  The
client opens its log file first, logs its banner and the PID, and only then
tries to create the terminal screen -- which is where it stops in a
terminal-less environment, so the observable behavior is the exit status 1
plus whatever landed in the log file.  All expectations below were recorded
by running ``./executable``.
"""

import os
import re
import stat

import pytest

from conftest import Server, quit_server, run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: What ``run()`` logs before it touches the terminal.
CLIENT_BANNER = (LOG_PREFIX + r"\*{15} starting client, PID: \d+ \*{15}\n")

#: The tcell failure recorded in a process without a controlling terminal.
SCREEN_FAILURE = (LOG_PREFIX + r"initializing screen: "
                  r"open /dev/tty: no such device or address\n")


@pytest.mark.parametrize("args", [
    ["-single", "a", "b"],
    ["-single", "a", "b", "c"],
    ["-single", ".", ".."],
])
def test_more_than_one_positional_argument_is_rejected(runtime_dir, home, args):
    """Two or more positional arguments exit 2 with a single stderr line."""
    # CATCHES: the arity check runs before the client starts, so the
    # diagnostic and status 2 appear with no log file and no server
    res = run_lf(args, runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 2
    assert res.out == ""
    assert res.err == "only one file or directory may be specified\n"
    assert not (runtime_dir / "lf.sock").exists()


def test_single_mode_never_touches_the_socket(runtime_dir, home):
    """``-single`` skips checkServer(), so no socket file is ever created."""
    # CATCHES: a re-implementation that always starts a server would leave
    # an lf.sock behind in the runtime directory
    res = run_lf(["-single"], runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    assert not (runtime_dir / "lf.sock").exists()


def test_print_flags_produce_no_output_when_client_fails(runtime_dir, home):
    """``-print-last-dir``/``-print-selection`` stay silent on a dead client.

    Both flags only write to stdout from the exit path of a client that got
    as far as rendering a directory listing, so nothing is printed here.
    """
    # CATCHES: a re-implementation printing an empty line or the cwd on the
    # failure path would emit bytes where the reference emits none
    res = run_lf(["-single", "-print-last-dir", "-print-selection"],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""


def test_default_mode_auto_starts_a_detached_server(tmp_path, runtime_dir,
                                                    home):
    """Without ``-single`` the client spawns a server and leaves it running.

    ``checkServer()`` starts ``os.Args[0] -server`` as a detached process
    when the socket is absent; the client itself still fails, but the
    socket now exists and answers ``-remote`` until it is told to quit.
    """
    # CATCHES: a re-implementation that only checks for the socket, or that
    # kills the server when the client dies, would fail the later -remote
    res = run_lf([], runtime_dir=runtime_dir, home=home, timeout=6)
    try:
        assert res.timed_out is False
        assert res.rc == 1
        assert res.out == ""
        assert res.err == ""
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        assert probe.wait(timeout=8)
        listed = run_lf(["-remote", "list"], runtime_dir=runtime_dir, home=home)
        assert listed.rc == 0
        assert listed.out == ""
        assert listed.err == ""
        quit_res = run_lf(["-remote", "quit"], runtime_dir=runtime_dir, home=home)
        assert quit_res.rc == 0
        assert quit_res.out == ""
        assert not (runtime_dir / "lf.sock").exists()
    finally:
        # checkServer() detached the server: reap it even when an assertion
        # above failed, so the test can never leak the process
        quit_server(runtime_dir)


def test_stale_regular_file_at_socket_path_is_replaced(tmp_path, runtime_dir,
                                                       home):
    """A leftover non-socket file at the socket path is removed and replaced.

    ``checkServer()`` dials the path, fails, unlinks the stale file and
    starts a fresh server that binds the same path.
    """
    # CATCHES: a re-implementation that only stats the path (instead of
    # trying to connect) would keep the stale file and never bind
    stale = runtime_dir / "lf.sock"
    stale.write_text("this is not a socket")
    res = run_lf([], runtime_dir=runtime_dir, home=home, timeout=6)
    try:
        assert res.rc == 1
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        assert probe.wait(timeout=8)
        assert stat.S_ISSOCK(os.stat(str(stale)).st_mode)
        quit_res = run_lf(["-remote", "quit"], runtime_dir=runtime_dir, home=home)
        assert quit_res.rc == 0
    finally:
        # the replacement server was also detached by checkServer()
        quit_server(runtime_dir)


def test_stale_socket_of_a_dead_server_is_replaced(tmp_path, runtime_dir,
                                                   home):
    """A socket file left by a killed server is reused for a new server."""
    # CATCHES: dialling a dead socket must trigger removal plus restart,
    # otherwise every later -remote would fail with "connection refused"
    old = Server(tmp_path)
    old.runtime_dir = str(runtime_dir)
    old.home = str(home)
    old.start()
    try:
        old.proc.kill()
        old.proc.wait()
    finally:
        old.stop()
    assert (runtime_dir / "lf.sock").exists()
    res = run_lf([], runtime_dir=runtime_dir, home=home, timeout=6)
    try:
        assert res.rc == 1
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        assert probe.wait(timeout=8)
        listed = run_lf(["-remote", "list"], runtime_dir=runtime_dir, home=home)
        assert listed.rc == 0
        assert listed.out == ""
        quit_res = run_lf(["-remote", "quit"], runtime_dir=runtime_dir, home=home)
        assert quit_res.rc == 0
    finally:
        # reap the replacement server the client detached here as well
        quit_server(runtime_dir)


def test_client_log_records_banner_and_screen_failure(tmp_path, runtime_dir,
                                                      home):
    """``-log`` captures the client banner and the tcell init error."""
    # CATCHES: the banner embeds the client PID (which equals the process
    # id), and the screen failure text is pinned so a re-implementation
    # cannot log a different reason
    log = tmp_path / "client.log"
    res = run_lf(["-single", "-log", str(log)], runtime_dir=runtime_dir,
                 home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    text = log.read_text()
    assert re.fullmatch(CLIENT_BANNER + SCREEN_FAILURE, text)
    pid = int(re.search(r"PID: (\d+)", text).group(1))
    assert pid > 1


def test_client_log_is_appended_across_runs(tmp_path, runtime_dir, home):
    """Two client runs leave two banners in the same log file."""
    # CATCHES: the log is opened with O_APPEND, so the second run must not
    # truncate the first
    log = tmp_path / "client.log"
    for _ in range(2):
        res = run_lf(["-single", "-log", str(log)], runtime_dir=runtime_dir,
                     home=home, timeout=6)
        assert res.rc == 1
        assert res.out == ""
        assert res.err == ""
    text = log.read_text()
    assert re.fullmatch((CLIENT_BANNER + SCREEN_FAILURE) * 2, text)
    assert text.count("starting client, PID:") == 2


def test_client_log_with_relative_path_is_created_in_cwd(tmp_path,
                                                         runtime_dir, home):
    """A relative ``-log`` value is resolved against the working directory."""
    # CATCHES: main() absolutises the log path before the server chdirs to
    # the user's home, so the file must land next to the original cwd
    workdir = tmp_path / "work"
    workdir.mkdir()
    res = run_lf(["-single", "-log", "rel.log"], cwd=workdir,
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.rc == 1
    assert (workdir / "rel.log").exists()
    assert re.fullmatch(CLIENT_BANNER + SCREEN_FAILURE,
                        (workdir / "rel.log").read_text())


def test_server_log_with_relative_path_stays_in_cwd(tmp_path):
    """``-server -log rel.log`` also resolves before chdir'ing to $HOME."""
    # CATCHES: serve() chdirs to the user's home directory, so a relative
    # log path would silently move unless it was made absolute first
    log = tmp_path / "server.log"
    srv = Server(tmp_path, log=log).start()
    try:
        srv.remote("list")
        text = log.read_text()
    finally:
        srv.stop()
    assert re.fullmatch(LOG_PREFIX + r"\*{15} starting server \*{15}\n"
                        + LOG_PREFIX + r"listen: list\n", text)
    assert (tmp_path / "home").exists()


def test_client_log_pointing_at_a_directory_is_fatal(tmp_path, runtime_dir,
                                                     home):
    """A ``-log`` path that is a directory exits 1 with a log.Fatal message."""
    # CATCHES: the diagnostic goes to stderr with a timestamp, the exit
    # status is 1, and the client banner is never written anywhere
    target = tmp_path / "adirectory"
    target.mkdir()
    res = run_lf(["-single", "-log", str(target)], runtime_dir=runtime_dir,
                 home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"opening log file: open \S+: "
                        r"is a directory\n", res.err)


def test_client_log_in_a_missing_directory_is_fatal(tmp_path, runtime_dir,
                                                    home):
    """A ``-log`` path below a nonexistent directory exits 1 the same way."""
    # CATCHES: the log directory is not created implicitly, and the error
    # text is Go's ENOENT wording
    res = run_lf(["-single", "-log", str(tmp_path / "nope" / "x.log")],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"opening log file: open \S+/nope/x\.log: "
                        r"no such file or directory\n", res.err)


def test_client_ignores_extra_meta_flags_when_failing(runtime_dir, home,
                                                      tmp_path):
    """``-config`` and ``-command`` do not change the terminal-less failure."""
    # CATCHES: a missing config file is only logged (not fatal) once the
    # client reaches its event loop, so startup still fails on the screen
    log = tmp_path / "client.log"
    res = run_lf(["-single", "-config", str(tmp_path / "absent-rc"),
                  "-command", "echo hi", "-command", "quit",
                  "-log", str(log)],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    assert re.fullmatch(CLIENT_BANNER + SCREEN_FAILURE, log.read_text())
