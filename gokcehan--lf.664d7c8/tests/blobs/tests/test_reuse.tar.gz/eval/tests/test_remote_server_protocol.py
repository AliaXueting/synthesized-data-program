"""The ``-remote`` client and the headless server protocol (server.go).

``server.go`` reads one request per line from the socket, splits it with
``splitWord`` (the helper whose trimming rules ``src/misc_test.go::
TestSplitWord`` pins natively) and dispatches on the first word: ``conn``,
``drop``, ``list``, ``send``, ``query``, ``quit`` and ``quit!``.  This file
rewrites those cases as black-box tests: ``lf -server`` is started on a
private socket, plain ``lf -remote`` invocations act as the command-line
client, and a hand-rolled unix-socket connection acts as a registered lf
client so that ``send``/``query``/``list``/``quit`` have something to talk
to.  Every expected byte was recorded from the reference binary.
"""

import os
import re
import stat
import threading
import time

import pytest

from conftest import Server, quit_server, run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: The banner ``serve()`` logs as its very first message.
BANNER = r"\*{15} starting server \*{15}\n"


def test_remote_without_server_is_fatal(runtime_dir, home):
    """-remote with no server listening exits 1 with a dial error on stderr."""
    # CATCHES: the failure must be a log.Fatal-style message on stderr that
    # names the socket path, not a silent success or a stdout message
    res = run_lf(["-remote", "list"], runtime_dir=runtime_dir, home=home)
    assert res.rc == 1
    assert res.out == ""
    assert re.fullmatch(LOG_PREFIX + r"remote command: connecting to server: "
                        r"dial unix \S+/lf\.sock: connect: no such file or "
                        r"directory\n", res.err)


def test_remote_with_empty_value_runs_the_client(tmp_path, runtime_dir, home):
    """``-remote ""`` is indistinguishable from no -remote at all.

    ``main.go`` dispatches on ``*remoteCmd != ""`` so an empty value falls
    through to the client branch, which fails to open the terminal -- after
    ``checkServer()`` has started a detached server.
    """
    # CATCHES: a re-implementation that treats an empty -remote value as a
    # request would try to dial the socket instead of starting a client (and
    # one that skips checkServer would leave no server to quit here)
    res = run_lf(["-remote", ""], runtime_dir=runtime_dir, home=home, timeout=6)
    try:
        assert res.timed_out is False
        assert res.rc == 1
        assert res.out == ""
        assert res.err == ""
        probe = Server(tmp_path)
        probe.runtime_dir = str(runtime_dir)
        probe.home = str(home)
        try:
            assert probe.wait(timeout=8)
        finally:
            probe.stop()
        quit_res = run_lf(["-remote", "quit"], runtime_dir=runtime_dir, home=home)
        assert quit_res.rc == 0
        assert not (runtime_dir / "lf.sock").exists()
    finally:
        # checkServer() detached a server before the client died: reap it
        # even when an assertion above failed, so the test cannot leak it
        quit_server(runtime_dir)


@pytest.mark.parametrize("command,expected", [
    ("foo", "listen: unexpected command: foo\n"),
    ("LIST", "listen: unexpected command: LIST\n"),
    ("nosuchcommand", "listen: unexpected command: nosuchcommand\n"),
    ("conn", "listen: conn: requires a client ID\n"),
    ("conn abc", "listen: conn: client ID must be a number\n"),
    ("conn 3x", "listen: conn: client ID must be a number\n"),
    ("conn 99999999999999999999",
     "listen: conn: client ID must be a number\n"),
    ("drop", "listen: drop: requires a client ID\n"),
    ("drop xyz", "listen: drop: client ID must be a number\n"),
    ("query", "listen: query: requires a client ID\n"),
    ("query abc", "listen: query: client ID must be a number\n"),
    ("query 7 files", "listen: query: no client with ID 7 connected\n"),
    ("send 7 hello", "listen: send: no client with ID 7 connected\n"),
])
def test_remote_diagnostics(server, command, expected):
    """Malformed or unactionable requests answer with one error line."""
    # CATCHES: the exact ``listen:`` diagnostics, including the numeric
    # overflow case and the "no client with ID" wording for both send and
    # query, are pinned so a re-implementation cannot reword them
    res = server.remote(command)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


@pytest.mark.parametrize("command,expected", [
    # splitWord trims leading whitespace of both the word and the rest, so
    # these all reduce to the same request as their trimmed spelling
    ("  foo  ", "listen: unexpected command: foo\n"),
    ("\tfoo\t", "listen: unexpected command: foo\n"),
    ("  \t conn abc \t ", "listen: conn: client ID must be a number\n"),
    ("   drop    xyz   ", "listen: drop: client ID must be a number\n"),
    ("  query   xyz ", "listen: query: client ID must be a number\n"),
    ("  send   9   hi", "listen: send: no client with ID 9 connected\n"),
    ("list\r", "4\n"),  # a stray CR is whitespace to splitWord
    ("\tlist\t", "4\n"),
    ("    list    ", "4\n"),
    ("send", ""),   # no operand at all: nothing is echoed back
    ("drop 99", ""),  # dropping an unknown id is silent
])
def test_remote_word_splitting(server, command, expected):
    """Requests are tokenised exactly like ``misc_test.go::TestSplitWord``.

    Leading and embedded runs of spaces, tabs and even a carriage return
    are collapsed when the word and its first argument are extracted,
    while the command itself stays case sensitive.
    """
    # CATCHES: a re-implementation using strings.Fields on the whole line,
    # or one that only accepts a single space, mishandles these spellings
    server.connect(4)
    res = server.remote(command)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""
    # the request must not have taken the server down
    assert server.remote("list").out == "4\n"


def test_remote_list_reports_registered_clients(server):
    """``list`` prints the ids of connected clients in numeric order."""
    # CATCHES: ids are sorted as integers, so 3 < 20 < 100; a string sort
    # would print them as 100, 20, 3
    server.connect(20)
    server.connect(3)
    server.connect(100)
    res = server.remote("list")
    assert res.rc == 0
    assert res.out == "3\n20\n100\n"
    assert res.err == ""


def test_remote_list_is_empty_with_no_clients(server):
    """``list`` with nothing connected writes no bytes at all."""
    # CATCHES: an empty client table must yield a truly empty response,
    # not a newline, a placeholder or an error
    res = server.remote("list")
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""


def test_remote_send_delivers_message_to_one_client(server):
    """``send <id> <msg>`` delivers ``<msg>`` plus a newline to that id."""
    # CATCHES: only the addressed client sees the message, and the payload
    # keeps its interior spacing while gaining a trailing newline
    first = server.connect(11)
    second = server.connect(12)
    res = server.remote("send 12 hello  world")
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""
    assert second.recv(200) == b"hello  world\n"
    # the other client must not have been written to
    first.setblocking(False)
    with pytest.raises(Exception):
        first.recv(200)


def test_remote_send_trailing_whitespace_is_preserved(server):
    """Trailing blanks in the payload survive, because only the left is trimmed."""
    # CATCHES: splitWord only left-trims the rest, so the message handed to
    # the server keeps its trailing spaces before the appended newline
    conn = server.connect(21)
    res = server.remote("send 21   padded payload   ")
    assert res.rc == 0
    assert res.out == ""
    assert conn.recv(200) == b"padded payload   \n"


def test_remote_send_without_message_writes_blank_line(server):
    """``send <id>`` with no payload delivers an empty line."""
    # CATCHES: the id is still consumed, so the client receives a lone
    # newline rather than an error
    conn = server.connect(31)
    res = server.remote("send 31")
    assert res.rc == 0
    assert res.out == ""
    assert conn.recv(200) == b"\n"


def test_remote_send_to_non_numeric_id_broadcasts(server):
    """``send <word> <msg>`` broadcasts ``<word> <msg>`` to every client."""
    # CATCHES: when the first operand is not a number the whole remainder
    # (including that operand) becomes the broadcast text
    first = server.connect(41)
    second = server.connect(42)
    res = server.remote("send announce hello there")
    assert res.rc == 0
    assert res.out == ""
    assert first.recv(200) == b"announce hello there\n"
    assert second.recv(200) == b"announce hello there\n"


def test_remote_drop_removes_a_registered_client(server):
    """``drop <id>`` unregisters the client, so list stops reporting it."""
    # CATCHES: dropping must remove exactly one id and leave the others
    # listed, and must itself produce no output
    server.connect(51)
    server.connect(52)
    assert server.remote("list").out == "51\n52\n"
    res = server.remote("drop 51")
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""
    assert server.remote("list").out == "52\n"


def test_remote_conn_never_returns(server):
    """``conn <id>`` registers the connection and then blocks forever.

    Registering hands the socket's lifetime to the server, so the
    ``-remote`` process keeps waiting for a response that never comes and
    has to be killed; the id nevertheless shows up in ``list``.
    """
    # CATCHES: a re-implementation that answers ``conn`` would return
    # instead of hanging, and one that never registers would leave the id
    # out of the client list
    res = server.remote("conn 61", timeout=1.5)
    assert res.timed_out is True
    assert res.out == ""
    assert server.remote("list").out == "61\n"


def test_remote_query_roundtrip(server):
    """``query <id> <key>`` relays the client's reply back to stdout."""
    # CATCHES: the server writes ``query <key>`` to the client, forwards
    # every line it gets back until a blank line, and only then lets the
    # -remote process finish
    conn = server.connect(71)

    def answer():
        conn.settimeout(5)
        data = conn.recv(200)
        if data.startswith(b"query "):
            conn.sendall(b"line-one\nline-two\n\n")

    worker = threading.Thread(target=answer)
    worker.start()
    res = server.remote("query 71 files", timeout=6)
    worker.join()
    assert res.rc == 0
    assert res.out == "line-one\nline-two\n"
    assert res.err == ""
    # the server is still healthy afterwards
    assert server.remote("list").out == "71\n"


def test_remote_quit_leaves_server_alive_while_clients_exist(server):
    """``quit`` only exits once every client has gone, and pings them first."""
    # CATCHES: with a client connected, quit sends an empty line (which lf
    # clients ignore) and the server keeps serving further requests
    conn = server.connect(81)
    res = server.remote("quit")
    assert res.rc == 0
    assert res.out == ""
    assert conn.recv(200) == b"\n"
    assert server.proc.poll() is None
    assert server.remote("list").out == "81\n"


def test_remote_quit_force_notifies_clients_and_exits(server):
    """``quit!`` tells every client the server is quitting, then exits 0."""
    # CATCHES: the exact notice line and the zero exit status of the
    # server process are both pinned here
    conn = server.connect(91)
    res = server.remote("quit!")
    assert res.rc == 0
    assert res.out == ""
    assert conn.recv(200) == b"echo server is quitting...\n"
    assert server.proc.wait(timeout=5) == 0


def test_remote_quit_exits_a_server_with_no_clients(server):
    """``quit`` with an empty client table shuts the server down cleanly."""
    # CATCHES: the server must exit 0 and remove its socket file, so a
    # later -remote fails with "no such file or directory"
    res = server.remote("quit")
    assert res.rc == 0
    assert res.out == ""
    assert server.proc.wait(timeout=5) == 0
    assert not os.path.exists(server.socket_path)
    after = run_lf(["-remote", "list"], cwd=server.root, home=server.home,
                   runtime_dir=server.runtime_dir)
    assert after.rc == 1
    assert re.fullmatch(LOG_PREFIX + r"remote command: connecting to server: "
                        r"dial unix \S+/lf\.sock: connect: no such file or "
                        r"directory\n", after.err)


def test_remote_request_may_contain_several_lines(server):
    """A newline inside the -remote value is sent as two separate requests."""
    # CATCHES: the server answers each line in turn, so the reply for
    # ``list`` and the error for the bogus second line are concatenated
    server.connect(101)
    res = server.remote("list\nnosuchword")
    assert res.rc == 0
    assert res.out == "101\nlisten: unexpected command: nosuchword\n"
    assert res.err == ""


def test_server_writes_banner_and_logs_to_stderr(tmp_path):
    """``-server`` announces itself on stderr and keeps logging requests there."""
    # CATCHES: the banner is the very first stderr line, every request the
    # server reads is echoed back as a ``listen:`` log line, and every
    # diagnostic sent to a client is logged as well
    srv = Server(tmp_path).start()
    try:
        res = srv.remote("bogus")
        after = srv.remote("list")
        text = srv.stderr_text()
    finally:
        srv.stop()
    assert res.rc == 0
    assert res.out == "listen: unexpected command: bogus\n"
    assert res.err == ""
    assert after.rc == 0
    assert after.out == ""
    assert re.fullmatch(
        LOG_PREFIX + BANNER
        + LOG_PREFIX + r"listen: bogus\n"
        + LOG_PREFIX + r"listen: unexpected command: bogus\n"
        + LOG_PREFIX + r"listen: list\n",
        text)


def test_server_log_file_receives_the_same_messages(tmp_path):
    """``-server -log path`` redirects the banner and the diagnostics there."""
    # CATCHES: with -log the server must not write to stderr, and the file
    # gets both the banner and the ``listen:``/error lines
    log = tmp_path / "server.log"
    srv = Server(tmp_path, log=log).start()
    try:
        srv.remote("conn abc")
        srv.remote("send 5 x")
        text = log.read_text()
        stderr = srv.stderr_text()
    finally:
        srv.stop()
    assert stderr == ""
    assert re.fullmatch(
        LOG_PREFIX + BANNER
        + LOG_PREFIX + r"listen: conn abc\n"
        + LOG_PREFIX + r"listen: conn: client ID must be a number\n"
        + LOG_PREFIX + r"listen: send 5 x\n"
        + LOG_PREFIX + r"listen: send: no client with ID 5 connected\n",
        text)


def test_server_creates_socket_with_owner_only_permissions(server):
    """The socket is created with mode 0700 thanks to setUserUmask()."""
    # CATCHES: the server applies umask 0077 before listening, so the
    # socket file must be a socket readable only by its owner
    info = os.stat(server.socket_path)
    assert stat.S_ISSOCK(info.st_mode)
    assert os.stat(server.socket_path).st_mode & 0o777 == 0o700
    assert info.st_mode & 0o077 == 0


def test_second_server_cannot_bind_and_exits_zero(tmp_path):
    """A second ``-server`` on the same socket logs a bind error and exits 0."""
    # CATCHES: the bind failure is only logged (log.Printf, not Fatal), so
    # the process still exits with status 0 and leaves the first server
    # untouched and still answering
    srv = Server(tmp_path).start()
    try:
        second = Server(tmp_path / "second")
        second.runtime_dir = srv.runtime_dir
        second.spawn()
        try:
            assert second.proc.wait(timeout=5) == 0
            assert re.fullmatch(
                LOG_PREFIX + BANNER
                + LOG_PREFIX + r"listening socket: listen unix \S+/lf\.sock: "
                r"bind: address already in use\n",
                second.stderr_text())
        finally:
            second.stop()
        assert srv.remote("list").rc == 0
    finally:
        srv.stop()


def test_server_with_missing_runtime_dir_logs_bind_error(tmp_path):
    """A socket path whose directory does not exist is a non-fatal bind error."""
    # CATCHES: net.Listen fails with ENOENT, the server logs it and exits
    # with status 0 instead of crashing
    srv = Server(tmp_path, create_runtime=False)
    srv.runtime_dir = str(tmp_path / "absent")
    srv.spawn()
    try:
        assert srv.proc.wait(timeout=5) == 0
        assert re.fullmatch(
            LOG_PREFIX + BANNER
            + LOG_PREFIX + r"listening socket: listen unix "
            r"\S+/absent/lf\.sock: bind: no such file or directory\n",
            srv.stderr_text())
    finally:
        srv.stop()


def test_server_broadcast_to_dead_connection_reports_write_error(server):
    """Writing to a client that has vanished reports a broken pipe per id."""
    # CATCHES: a broadcast to a dead connection must report one line per
    # dead id and drop those ids from the client table
    conn = server.connect(111)
    conn.close()  # the server still thinks 111 is connected
    time.sleep(0.2)
    res = server.remote("send anything goes")
    assert res.rc == 0
    assert res.out.count("\n") == 1
    assert res.out.startswith("sending command to client 111: ")
    assert server.remote("list").out == ""
