"""When lf reads its configuration: only after the screen comes up.

The client's startup order is the boundary this file pins.  ``client.go``
opens the log, writes its banner, and dies at tcell's ``screen.Init()``
when there is no controlling terminal; the configuration file, the
``-command`` values and the history file are only touched later, inside
``app.loop()`` (``app.go``).  So a run without a terminal must fail with
exactly the same two log lines no matter what the config contains, how it
is found, or which commands were passed on the command line.

This is also the boundary that keeps ``key.go`` (``map`` bindings),
``complete.go`` and the whole ``eval.go`` parser out of reach for a
headless CLI: a re-implementation that eagerly reads the config before
initialising the screen would surface ``unknown option`` or parse
diagnostics here, where the reference stays silent.  Every expectation
below was recorded by running ``./executable`` with the corresponding
files in place.
"""

import os
import re

import pytest

from conftest import run_lf

#: Go's ``log`` package prefix: ``2006/01/02 15:04:05 `` (local time).
LOG_PREFIX = r"\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "

#: What ``run()`` logs before it touches the terminal.
CLIENT_BANNER = (LOG_PREFIX + r"\*{15} starting client, PID: \d+ \*{15}\n")

#: The tcell failure recorded in a process without a controlling terminal.
SCREEN_FAILURE = (LOG_PREFIX + r"initializing screen: "
                  r"open /dev/tty: no such device or address\n")

#: The complete client log of a terminal-less run: nothing else may ever
#: appear in it, whatever the configuration or the ``-command`` values are.
GATED_LOG = CLIENT_BANNER + SCREEN_FAILURE


def write_config(path, content):
    """Create a config file (with parents) and return its path."""
    os.makedirs(os.path.dirname(str(path)), exist_ok=True)
    with open(str(path), "w", encoding="utf-8") as fh:
        fh.write(content)
    return str(path)


def assert_gated_failure(res, log):
    """The run died at the screen, and the log shows nothing else."""
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    text = log.read_text()
    assert re.fullmatch(GATED_LOG, text)


@pytest.mark.parametrize("content", [
    pytest.param("set nosuchoption true\n", id="unknown-option"),
    pytest.param("map <nosuchkey> :quit\n", id="unknown-key"),
    pytest.param("{{{\n", id="unparseable"),
    pytest.param("set hidden true\n", id="valid-option"),
])
def test_existing_config_is_not_evaluated_before_the_screen(tmp_path,
                                                            runtime_dir,
                                                            home, content):
    """An existing config file changes nothing about a terminal-less run.

    Unknown options, unparsable lines and even a perfectly valid ``set``
    are all invisible: the file is never read before the screen failure.
    """
    # CATCHES: config parsing (and with it the map/eval machinery) happens
    # only after screen.Init(); an eager implementation would log or print
    # "unknown option: nosuchoption" diagnostics for the same file
    config = write_config(tmp_path / "lfrc", content)
    log = tmp_path / "client.log"
    res = run_lf(["-single", "-log", str(log), "-config", config],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert_gated_failure(res, log)


@pytest.mark.parametrize("commands", [
    pytest.param(["set nosuchoption"], id="unknown-option"),
    pytest.param(["nosuchcmd"], id="unknown-command"),
    pytest.param(["echo hi"], id="valid-command"),
    pytest.param(["set nosuchoption", "map <nosuchkey> :quit"],
                 id="several-values"),
])
def test_command_flag_values_are_not_evaluated_before_the_screen(
        tmp_path, runtime_dir, home, commands):
    """``-command`` values, valid or not, are stored until the UI exists."""
    # CATCHES: the commands run inside app.loop() after the screen is up;
    # evaluating them earlier would print "unknown option" or even the
    # "hi" of `echo hi` to stdout, which stays empty in the reference
    log = tmp_path / "client.log"
    args = ["-single", "-log", str(log)]
    for command in commands:
        args += ["-command", command]
    res = run_lf(args, runtime_dir=runtime_dir, home=home, timeout=6)
    assert_gated_failure(res, log)


@pytest.mark.parametrize("env_name", [
    pytest.param("LF_CONFIG_HOME", id="lf-config-home"),
    pytest.param("XDG_CONFIG_HOME", id="xdg-config-home"),
    pytest.param("HOME", id="home-dot-config"),
])
def test_default_config_paths_are_not_consulted_before_the_screen(
        tmp_path, runtime_dir, home, env_name):
    """The config-path discovery machinery stays silent pre-screen.

    ``os.go`` builds ``gConfigPaths`` from ``$LF_CONFIG_HOME`` (winning
    over ``$XDG_CONFIG_HOME``, which wins over ``$HOME/.config``); none of
    the discovered files is opened before the screen failure.
    """
    # CATCHES: a re-implementation that locates and parses the default
    # lfrc during startup would emit diagnostics for this garbage config,
    # while the reference dies at the screen without touching the file
    if env_name == "HOME":
        # route the discovery through the home fixture directory
        write_config(home / ".config" / "lf" / "lfrc",
                     "set nosuchoption true\n")
        env = {}
    else:
        config_root = tmp_path / "cfgroot"
        write_config(config_root / "lf" / "lfrc", "set nosuchoption true\n")
        env = {env_name: str(config_root)}
    log = tmp_path / "client.log"
    res = run_lf(["-single", "-log", str(log)], runtime_dir=runtime_dir,
                 home=home, env=env, timeout=6)
    assert_gated_failure(res, log)


@pytest.mark.parametrize("kind", [
    pytest.param("unreadable-file", id="unreadable"),
    pytest.param("directory", id="directory"),
])
def test_unusable_config_is_not_reported_before_the_screen(tmp_path,
                                                           runtime_dir,
                                                           home, kind):
    """Even a config that cannot be read at all goes unmentioned.

    An unreadable file or a directory in place of the config would fail
    the moment it is opened -- which never happens before the screen.
    """
    # CATCHES: opening the config eagerly would fail with "permission
    # denied" or "is a directory" in the log; the reference logs only the
    # banner and the screen failure, whatever sits at the config path
    target = tmp_path / "unusable"
    if kind == "unreadable-file":
        target.write_text("set nosuchoption true\n")
        target.chmod(0o000)
    else:
        target.mkdir()
    log = tmp_path / "client.log"
    res = run_lf(["-single", "-log", str(log), "-config", str(target)],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert_gated_failure(res, log)


def test_history_file_troubles_are_invisible_before_the_screen(tmp_path,
                                                                runtime_dir,
                                                                home):
    """The history file is only opened after the screen exists.

    A directory where ``$XDG_DATA_HOME/lf/history`` should be would make
    ``readHistory()`` fail -- but that runs after ``screen.Init()``, so a
    terminal-less startup never reports it.
    """
    # CATCHES: the history path is derived at init but only opened in
    # app.loop(); reading it earlier would log "reading history file:
    # ... is a directory" for this setup, which the reference never does
    data_home = tmp_path / "datahome"
    os.makedirs(str(data_home / "lf" / "history"))
    log = tmp_path / "client.log"
    res = run_lf(["-single", "-log", str(log)], runtime_dir=runtime_dir,
                 home=home, env={"XDG_DATA_HOME": str(data_home)}, timeout=6)
    assert_gated_failure(res, log)


def test_the_gate_is_silent_without_a_log_file(tmp_path, runtime_dir, home):
    """Without ``-log`` the same startup produces no output at all.

    The log output is discarded (not sent to stderr), so a terminal-less
    run with a garbage config and failing commands writes nothing to
    either stream and simply exits 1.
    """
    # CATCHES: log messages default to io.Discard, so the screen failure
    # must not leak to stderr either; an implementation routing log lines
    # to stderr would print the banner and the tcell error here
    config = write_config(tmp_path / "lfrc", "set nosuchoption true\n")
    res = run_lf(["-single", "-command", "set nosuchoption",
                  "-config", config],
                 runtime_dir=runtime_dir, home=home, timeout=6)
    assert res.timed_out is False
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
