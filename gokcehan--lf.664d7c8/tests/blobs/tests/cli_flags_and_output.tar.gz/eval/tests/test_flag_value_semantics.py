"""How flag VALUES are parsed beyond the plain '-flag value' form: the
'-flag=value' spelling for the custom -command flag, string flags consuming
the next argument even when it looks like a flag, empty string values
behaving exactly like an unset flag, a repeated string flag keeping only the
last value, the flag package's -h/ErrHelp handling firing during Parse
(before main()'s meta dispatch), and the usage header interpolating argv[0]
verbatim when the binary is invoked through a symlink."""

import os

import pytest

from conftest import (
    EXE,
    VERSION_LINE,
    expected_usage,
    run_argv,
    run_lf,
    run_lf_tty,
    run_pty,
    strip_log_timestamps,
)


def test_command_flag_accepts_the_equals_spelling(make_tree, lf_env):
    """'-command=cd sub' works like '-command cd sub' and stacks with it."""
    # CATCHES: the custom -command flag (a flag.Var, not a StringVar) still
    # supports the '-flag=value' spelling, and both spellings append to the
    # same command list: the equals-form 'cd sub' runs first, the space-form
    # 'quit' second, so the session ends in the subdirectory with no input
    # and -print-last-dir reports it.
    tree = make_tree()
    res = run_lf_tty(["-single", "-command=cd sub", "-command", "quit",
                      "-print-last-dir"], cwd=str(tree), env=lf_env, keys=[])
    assert res.exit == 0
    assert res.out.decode() == "%s/sub\n" % tree


@pytest.mark.parametrize("value", ["-version", ""])
def test_command_consumes_a_flaglike_value(value, make_tree, lf_env, sandbox):
    """-command swallows the next argument even when it looks like a flag."""
    # CATCHES: a Go string/Var flag consumes the following argv entry
    # unconditionally as its value: '-command -version' stores the literal
    # text '-version' as a startup command instead of letting it dispatch the
    # -version meta flag, so the headless client dies the usual silent
    # exit-1 death and the log holds only the two standard lines (the
    # startup command never gets to run because the loop never starts).
    tree = make_tree()
    log = sandbox / "consumed.log"
    res = run_lf(["-single", "-command", value, "-log", str(log)],
                 cwd=str(tree), env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("initializing screen: open /dev/tty: ")
    assert len(lines) == 2


def test_empty_log_value_is_not_a_log_path(make_tree, lf_env):
    """'-log=' with an empty value behaves as if no -log was given."""
    # CATCHES: only a non-empty -log value is opened inside run(); an empty
    # one must not be treated as a file name (opening '' would fail and be
    # FATAL with 'opening log file: open : no such file or directory' on
    # stderr): the headless client instead dies the usual silent exit-1
    # death with nothing on stderr.
    tree = make_tree()
    res = run_lf(["-single", "-log="], cwd=str(tree), env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""


def test_empty_last_dir_path_value_writes_no_file(make_tree, lf_env, sandbox):
    """'-last-dir-path=' is unset-like: no file write is ever attempted."""
    # CATCHES: an empty -last-dir-path value is not a path to create: the
    # client runs and quits normally, -print-last-dir still prints the
    # directory, and the -log keeps only the two client banners -- an
    # implementation treating '' as a file name would log an 'opening last
    # dir file' error at quit time.
    tree = make_tree()
    log = sandbox / "real.log"
    res = run_lf_tty(["-single", "-log", str(log), "-last-dir-path=",
                      "-print-last-dir"], cwd=str(tree), env=lf_env,
                     keys=[b"q"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("*************** closing client, PID: ")
    assert len(lines) == 2


def test_empty_selection_path_value_writes_no_file(make_tree, lf_env,
                                                    sandbox):
    """'-selection-path=' is unset-like: a confirmed open writes no file."""
    # CATCHES: with an empty -selection-path value the confirmed open still
    # prints the selection on stdout, and the -log keeps only the two client
    # banners -- no 'opening selection file' error that an implementation
    # treating '' as a file name would produce when the selection is written.
    tree = make_tree()
    log = sandbox / "real.log"
    res = run_lf_tty(["-single", "-log", str(log), "-selection-path=",
                      "-print-selection"], cwd=str(tree), env=lf_env,
                     keys=[b"j", b"l"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % (tree / "a.txt")
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("*************** closing client, PID: ")
    assert len(lines) == 2


def test_empty_config_value_uses_the_default_config_paths(make_tree, lf_env,
                                                           sandbox):
    """'-config=' with an empty value falls back to the default paths."""
    # CATCHES: an empty -config value is indistinguishable from not passing
    # the flag: the usual per-user config paths are consulted (none exist in
    # the sandbox) and the -log holds only the two client banners -- in
    # particular no 'config file does not exist' line, which a non-empty
    # missing -config target would produce.
    tree = make_tree()
    log = sandbox / "real.log"
    res = run_lf_tty(["-single", "-log", str(log), "-config=",
                      "-print-last-dir"], cwd=str(tree), env=lf_env,
                     keys=[b"q"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("*************** closing client, PID: ")
    assert len(lines) == 2


def test_empty_remote_value_via_equals_starts_the_client(make_tree, lf_env):
    """'-remote=' falls through to the client like '-remote \"\"' does."""
    # CATCHES: the equals spelling with an empty value also produces an empty
    # remote command string, which the meta dispatch treats as 'no remote':
    # the normal client starts instead and, headless, dies the silent exit-1
    # death with no dial error and no usage on stderr.
    tree = make_tree()
    res = run_lf(["-single", "-remote="], cwd=str(tree), env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""


def test_repeated_log_flag_keeps_only_the_last_value(make_tree, lf_env):
    """A second -log overwrites the first: only the last file is created."""
    # CATCHES: -log registers a plain flag.StringVar, so repeated
    # occurrences REPLACE the value (unlike the accumulating -command array
    # flag): a.log is never created and the whole run's log goes to b.log,
    # holding the two standard headless lines.
    tree = make_tree()
    a = tree / "a.log"
    b = tree / "b.log"
    res = run_lf(["-single", "-log", str(a), "-log", str(b)],
                 cwd=str(tree), env=lf_env)
    assert res.rc == 1
    assert not a.exists()
    lines = strip_log_timestamps(b.read_text()).splitlines()
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("initializing screen: open /dev/tty: ")
    assert len(lines) == 2


@pytest.mark.parametrize("meta", [["-doc"], ["-version"]])
def test_h_is_handled_during_parsing_before_the_meta_dispatch(meta, lf_env):
    """-h prints usage even when -doc or -version was given first."""
    # CATCHES: -h is not a registered flag; the flag package handles it as
    # ErrHelp DURING Parse (print usage, exit 0), which happens before
    # main()'s meta dispatch -- so neither the documentation nor the version
    # line is printed even though -doc/-version precede -h on the command
    # line, and stdout stays empty.
    res = run_lf(meta + ["-h"], env=lf_env)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == expected_usage()


def test_usage_header_shows_argv0_verbatim(sandbox, lf_env):
    """Invoked through a symlink, the usage header names the symlink path."""
    # CATCHES: flag.Usage interpolates os.Args[0] exactly as the process was
    # invoked: running the binary through a 'lfy' symlink prints
    # 'Usage: <sandbox>/lfy [options] [path]' while every other byte of the
    # usage block is unchanged, and -version output stays argv0-independent.
    link = sandbox / "lfy"
    os.symlink(EXE, str(link))
    res = run_argv([str(link), "-help"], env=lf_env)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == expected_usage(argv0=str(link))
    ver = run_argv([str(link), "-version"], env=lf_env)
    assert ver.rc == 0
    assert ver.out == VERSION_LINE
    assert ver.err == ""


def test_lf_env_var_resolves_the_symlink_to_the_real_binary(make_tree,
                                                            lf_env, sandbox):
    """The 'lf' variable is the resolved binary path, not the symlink."""
    # CATCHES: exportLfPath uses os.Executable, which resolves symlinks: a
    # client started through a 'lfy' symlink still exports the REAL binary
    # path in the 'lf' variable (so nested $lf calls run the actual binary),
    # even though the usage header keeps naming the symlink.
    link = sandbox / "lfy"
    os.symlink(EXE, str(link))
    tree = make_tree()
    dump_name = "env-dump.txt"
    res = run_pty([str(link), "-single", "-command",
                   "$env > %s" % dump_name], cwd=str(tree), env=lf_env,
                  keys=[b"q"])
    assert res.exit == 0
    dumped = {}
    for line in (tree / dump_name).read_text().splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            dumped[key] = value
    assert dumped["lf"] == os.path.realpath(EXE)
