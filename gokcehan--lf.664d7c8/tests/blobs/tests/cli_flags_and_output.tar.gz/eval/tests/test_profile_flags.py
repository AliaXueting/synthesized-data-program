"""The profiling flags -cpuprofile and -memprofile: a CPU profile is started
before the meta-flag dispatch (and flushed whenever the process returns from
main normally), while the heap profile is only written at the very end --
after the meta flag already printed its output -- and never when a headless
client aborts inside run()."""

import pytest

from conftest import (
    VERSION_LINE,
    expected_usage,
    run_lf,
    strip_log_timestamps,
)

#: pprof profiles are gzip streams; the reference binary writes gzip data
#: even for a run as short as `-version`.
GZIP_MAGIC = b"\x1f\x8b"


def _assert_gzip_profile(path):
    """The file at ``path`` must hold a non-empty gzip pprof stream."""
    data = path.read_bytes()
    assert len(data) > 0
    assert data[:2] == GZIP_MAGIC


@pytest.mark.parametrize("meta_args", [
    ["-version"],
    ["-help"],
    ["-doc"],
])
def test_meta_flag_writes_cpu_profile(meta_args, lf_env, sandbox):
    """A meta-flag run writes the CPU profile file before exiting 0."""
    # CATCHES: -cpuprofile takes effect even when lf never starts a client:
    # the profile is started in main() before the meta dispatch, and the
    # deferred flush runs because -version/-help/-doc return normally, so a
    # non-empty gzip profile file is left behind next to exit code 0.
    profile = sandbox / "cpu.prof"
    res = run_lf(meta_args + ["-cpuprofile", str(profile)], env=lf_env)
    assert res.rc == 0
    assert profile.is_file()
    _assert_gzip_profile(profile)


@pytest.mark.parametrize("meta_args", [
    ["-version"],
    ["-doc"],
])
def test_meta_flag_writes_mem_profile(meta_args, lf_env, sandbox):
    """A meta-flag run also writes the heap profile on normal return."""
    # CATCHES: the -memprofile block sits after the meta dispatch in main(),
    # so -version and -doc print their output AND still write a heap profile
    # file (non-empty gzip) before the process exits 0.
    profile = sandbox / "mem.prof"
    res = run_lf(meta_args + ["-memprofile", str(profile)], env=lf_env)
    assert res.rc == 0
    assert profile.is_file()
    _assert_gzip_profile(profile)


def test_unopenable_cpuprofile_is_fatal_before_any_output(lf_env, sandbox):
    """-cpuprofile pointing at a directory aborts before anything prints."""
    # CATCHES: the CPU profile file is created (and started) in main() ahead
    # of the meta dispatch, so an uncreatable path is fatal immediately:
    # exit 1 with 'could not create CPU profile: open ...: is a directory'
    # on stderr and -- unlike -memprofile -- no version line on stdout.
    bad = sandbox / "a-dir"
    bad.mkdir()
    res = run_lf(["-version", "-cpuprofile", str(bad)], env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert strip_log_timestamps(res.err) == (
        "could not create CPU profile: open %s: is a directory\n" % bad)


def test_unopenable_memprofile_is_fatal_after_the_meta_output(lf_env, sandbox):
    """-memprofile failures happen after -version already printed."""
    # CATCHES: the heap profile is written at the END of main(), after the
    # meta flag already produced its output: with an uncreatable -memprofile
    # path the version line is on stdout, the error on stderr, and the
    # process still ends up failing with exit code 1.
    bad = sandbox / "a-dir"
    bad.mkdir()
    res = run_lf(["-version", "-memprofile", str(bad)], env=lf_env)
    assert res.rc == 1
    assert res.out == VERSION_LINE
    assert strip_log_timestamps(res.err) == (
        "could not create memory profile: open %s: is a directory\n" % bad)


def test_headless_client_leaves_cpu_profile_empty(make_tree, lf_env, sandbox):
    """A headless client creates the CPU profile file but never flushes it."""
    # CATCHES: without a terminal the client dies inside run() via a fatal
    # log call, which exits the process without running main()'s deferred
    # profile flush -- the -cpuprofile file exists (created before the
    # client started) but stays EMPTY, and the exit code is 1.
    tree = make_tree()
    profile = sandbox / "cpu.prof"
    res = run_lf(["-single", "-cpuprofile", str(profile)], cwd=str(tree),
                 env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    assert profile.is_file()
    assert profile.read_bytes() == b""


def test_headless_client_never_writes_mem_profile(make_tree, lf_env, sandbox):
    """A headless client never reaches the heap profile block at all."""
    # CATCHES: -memprofile is handled after the client switch in main();
    # when the headless client aborts inside run() the process exits before
    # that block runs, so unlike -cpuprofile no file is even created.
    tree = make_tree()
    profile = sandbox / "mem.prof"
    res = run_lf(["-single", "-memprofile", str(profile)], cwd=str(tree),
                 env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""
    assert not profile.exists()


def test_help_and_version_profile_flags_do_not_change_the_meta_output(
        lf_env, sandbox):
    """Profiling flags leave the usage and version output byte-identical."""
    # CATCHES: adding -cpuprofile/-memprofile must not leak into the meta
    # flags' output: -help still prints the exact usage block to stderr and
    # -version the version line to stdout, both with exit 0.
    cpu = sandbox / "cpu.prof"
    mem = sandbox / "mem.prof"
    res_help = run_lf(["-help", "-cpuprofile", str(cpu),
                       "-memprofile", str(mem)], env=lf_env)
    assert res_help.rc == 0
    assert res_help.out == ""
    assert res_help.err == expected_usage()
    res_version = run_lf(["-version", "-cpuprofile", str(cpu),
                          "-memprofile", str(mem)], env=lf_env)
    assert res_version.rc == 0
    assert res_version.out == VERSION_LINE
    assert res_version.err == ""
    _assert_gzip_profile(cpu)
    _assert_gzip_profile(mem)
