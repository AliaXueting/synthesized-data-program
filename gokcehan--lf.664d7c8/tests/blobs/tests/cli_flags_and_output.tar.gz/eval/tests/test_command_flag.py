"""The -command flag: lf commands given on the command line run during client
initialization (after the config file), repeated flags accumulate in order,
and a failing startup command is reported as a TUI/log error without
preventing the client from running."""

import re

from conftest import BANNER_RE, run_lf_tty, strip_log_timestamps


def test_command_quit_exits_without_input(make_tree, lf_env):
    """'lf -command quit' quits during initialization, no key pressed."""
    # CATCHES: -command is evaluated when the client comes up, so 'quit'
    # ends the session before any user input; combined with -print-last-dir
    # the still-running lifecycle prints the startup directory and exits 0
    # with the TUI never waiting for a key.
    tree = make_tree()
    res = run_lf_tty(["-single", "-command", "quit", "-print-last-dir"],
                     cwd=str(tree), env=lf_env, keys=[])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % tree


def test_repeated_command_flags_run_in_order(make_tree, lf_env):
    """Two -command flags accumulate and execute in the given order."""
    # CATCHES: -command is a repeatable (array) flag, not a single-value
    # one: each occurrence is kept and evaluated in command-line order, so
    # 'cd <sub>' followed by 'quit' navigates into the directory and only
    # then quits -- -print-last-dir reports the subdirectory, proving both
    # commands ran.
    tree = make_tree()
    res = run_lf_tty(
        ["-single", "-command", "cd %s" % (tree / "sub"),
         "-command", "quit", "-print-last-dir"],
        cwd=str(tree), env=lf_env, keys=[])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % (tree / "sub")


def test_invalid_startup_command_is_reported_but_not_fatal(make_tree, lf_env,
                                                            sandbox):
    """An unknown startup command logs an error but the client keeps running."""
    # CATCHES: -command failures are reported like interactive command
    # errors ('command not found: ...' in the log/TUI error line) instead of
    # aborting startup: the client stays alive, a later 'q' still quits with
    # exit code 0 and the log holds the error between the two banners.
    tree = make_tree()
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-command", "totally-bogus",
                      "-log", str(log)],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 3
    assert re.match(BANNER_RE, lines[0]) is not None
    assert lines[1] == "error: command not found: totally-bogus"
    assert re.match(BANNER_RE, lines[2]) is not None


def test_empty_startup_command_is_a_silent_noop(make_tree, lf_env, sandbox):
    """'-command \"\"' parses to nothing: no error, later commands still run."""
    # CATCHES: an empty command string produces no expression at all (not a
    # 'command not found' error and not a parse error), so evaluation simply
    # continues with the next startup command: 'quit' still ends the session
    # without any key, -print-last-dir reports the startup directory, and the
    # log holds only the two client banners.
    tree = make_tree()
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-command", "", "-command", "quit",
                      "-print-last-dir", "-log", str(log)],
                     cwd=str(tree), env=lf_env, keys=[])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 2
    assert re.match(BANNER_RE, lines[0]) is not None
    assert re.match(BANNER_RE, lines[1]) is not None


def test_startup_command_parse_error_is_reported_but_not_fatal(make_tree,
                                                               lf_env,
                                                               sandbox):
    """A syntactically invalid startup command logs a parser error only."""
    # CATCHES: startup commands go through lf's expression parser and a parse
    # failure is reported like a runtime failure (an 'error: ...' line between
    # the banners) without aborting the client: 'map x :' (a mapping with an
    # empty command) logs exactly 'error: unexpected token: ' -- the empty
    # token leaves a trailing space -- and a later 'q' still quits with 0.
    tree = make_tree()
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-command", "map x :", "-log", str(log)],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 3
    assert re.match(BANNER_RE, lines[0]) is not None
    assert lines[1] == "error: unexpected token: "
    assert re.match(BANNER_RE, lines[2]) is not None
