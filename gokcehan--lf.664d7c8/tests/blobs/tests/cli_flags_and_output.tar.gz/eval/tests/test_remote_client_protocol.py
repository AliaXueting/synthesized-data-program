"""The CLIENT half of the -remote flag (main()'s dispatch branch plus
client.go's remote()): lf dials the unix socket at $XDG_RUNTIME_DIR/lf.sock,
sends the command as a single newline-terminated line, and prints the
server's response to stdout -- byte-verbatim on a pipe, with control
characters sanitized per line when stdout is a terminal.

The socket is served by a one-shot fake listener inside the sandbox, so no
real 'lf -server' process is ever spawned (the server side itself -- client
registration, command evaluation, connection multiplexing -- belongs to the
server_and_remote module; what is pinned here is only what the -remote
client puts on the wire and how it prints the reply)."""

import os
import socket
import threading

from conftest import EXE, run_lf, run_pty


class FakeServer:
    """One-shot unix socket server standing in for ``lf -server``.

    Binds ``sock_path`` immediately (so the client's dial cannot race the
    listen), accepts a single connection, records the request bytes up to
    the first newline, replies with a fixed response and closes.
    """

    def __init__(self, sock_path, response):
        self.sock_path = str(sock_path)
        self.response = response
        #: raw request bytes the client sent (one entry per connection).
        self.received = []
        self.listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.listener.bind(self.sock_path)
        self.listener.listen(1)
        self.listener.settimeout(5.0)
        self.thread = threading.Thread(target=self._serve, daemon=True)
        self.thread.start()

    def _serve(self):
        try:
            conn, _ = self.listener.accept()
        except OSError:
            return
        data = b""
        while not data.endswith(b"\n"):
            chunk = conn.recv(4096)
            if not chunk:
                break
            data += chunk
        self.received.append(data)
        conn.sendall(self.response)
        conn.close()
        self.listener.close()

    def wait(self):
        """Wait for the served connection to finish (accept included)."""
        self.thread.join(10.0)


def test_remote_sends_one_line_and_prints_the_response_verbatim(lf_env,
                                                                sandbox):
    """-remote writes 'cmd\\n' to the socket and prints the reply verbatim."""
    # CATCHES: the -remote client sends exactly one newline-terminated
    # request line (no length prefix, no quoting) and prints the server's
    # response bytes to stdout unchanged -- a raw \\x01 control character
    # passes through when stdout is a pipe -- exiting 0 without drawing
    # anything.
    sock = sandbox / "runtime" / "lf.sock"
    server = FakeServer(sock, b"hello\x01world\nsecond line\n")
    try:
        res = run_lf(["-remote", "send :echo hi"], env=lf_env)
    finally:
        server.wait()
    assert res.rc == 0
    assert res.err == ""
    assert res.out == "hello\x01world\nsecond line\n"
    assert server.received == [b"send :echo hi\n"]


def test_remote_sanitizes_the_response_when_stdout_is_a_terminal(lf_env,
                                                                 sandbox):
    """On a terminal each response line is sanitized before printing."""
    # CATCHES: main() applies sanitizeName to every line of the -remote
    # response only when stdout is a terminal: the \\x01 byte is replaced by
    # U+FFFD while the line structure survives (\\n rendered as CRLF by the
    # tty), and nothing else is drawn -- a -remote run starts no TUI.
    sock = sandbox / "runtime" / "lf.sock"
    server = FakeServer(sock, b"hello\x01world\nsecond line\n")
    try:
        res = run_pty([EXE, "-remote", "send :echo hi"], cwd=str(sandbox),
                      env=lf_env, keys=[], stdout="tty")
    finally:
        server.wait()
    assert res.exit == 0
    assert res.tty == b"hello\xef\xbf\xbdworld\r\nsecond line\r\n"


def test_remote_with_an_empty_response_prints_nothing(lf_env, sandbox):
    """An empty server reply produces empty output and exit 0."""
    # CATCHES: the reply is read to EOF and printed with no byte added: an
    # empty response means literally nothing on stdout (no newline), the
    # request line still goes out as 'list\\n', and the exit code is 0.
    sock = sandbox / "runtime" / "lf.sock"
    server = FakeServer(sock, b"")
    try:
        res = run_lf(["-remote", "list"], env=lf_env)
    finally:
        server.wait()
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""
    assert server.received == [b"list\n"]


def test_remote_prints_an_unterminated_response_without_adding_a_newline(
        lf_env, sandbox):
    """A response not ending in '\\n' is printed as-is, with no terminator."""
    # CATCHES: the reply is written with a plain fmt.Print (not Println), so
    # a partial response is printed without any added trailing newline --
    # consumers of -remote output cannot assume line-terminated replies --
    # while the request line still goes out newline-terminated and the exit
    # code stays 0.
    sock = sandbox / "runtime" / "lf.sock"
    server = FakeServer(sock, b"partial response")
    try:
        res = run_lf(["-remote", "send :echo hi"], env=lf_env)
    finally:
        server.wait()
    assert res.rc == 0
    assert res.err == ""
    assert res.out == "partial response"
    assert server.received == [b"send :echo hi\n"]
