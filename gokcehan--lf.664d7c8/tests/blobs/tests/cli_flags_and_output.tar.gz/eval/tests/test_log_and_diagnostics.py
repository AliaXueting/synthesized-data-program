"""The -log runtime log and lf's headless diagnostics: a client started
without a terminal fails silently with exit 1, its log records the startup
banner plus the screen-init failure, logs append across runs, an unopenable
-log path is fatal before anything runs, and a clean terminal session logs
nothing but the two banner lines."""

import os
import re

import pytest

from conftest import BANNER_RE, run_lf, run_lf_tty, strip_log_timestamps

#: Recorded screen-init failure on a controlling-terminal-less stdin.
SCREEN_FAILURE = "initializing screen: open /dev/tty: no such device or address"


def test_headless_client_fails_silently(make_tree, lf_env):
    """A client without a controlling terminal exits 1 with no output."""
    # CATCHES: the interactive client needs /dev/tty; when there is none it
    # dies during startup printing nothing at all (the reason only appears
    # in the -log), with exit code 1.
    tree = make_tree()
    res = run_lf(["-single"], cwd=str(tree), env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""


def test_log_records_the_screen_failure(make_tree, lf_env, sandbox):
    """-log captures the startup banner and the screen failure, mode 0600."""
    # CATCHES: the log gets the 'starting client, PID:' banner line and the
    # exact screen-init error, and is created with owner-only permissions
    # (0600) even under a permissive umask.
    tree = make_tree()
    log = sandbox / "client.log"
    res = run_lf(["-single", "-log", str(log)], cwd=str(tree), env=lf_env)
    assert res.rc == 1
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 2
    banner = re.match(BANNER_RE, lines[0])
    assert banner is not None and banner.group(1) == "starting"
    assert lines[1] == SCREEN_FAILURE
    assert os.stat(str(log)).st_mode & 0o777 == 0o600


def test_log_is_appended_across_runs(make_tree, lf_env, sandbox):
    """A second run appends to an existing log instead of truncating it."""
    # CATCHES: the log file is opened for append, so two runs leave both
    # sessions' banner+failure pairs in one file (four lines).
    tree = make_tree()
    log = sandbox / "client.log"
    for _ in range(2):
        res = run_lf(["-single", "-log", str(log)], cwd=str(tree),
                     env=lf_env)
        assert res.rc == 1
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 4
    assert re.match(BANNER_RE, lines[0]) is not None
    assert lines[1] == SCREEN_FAILURE
    assert re.match(BANNER_RE, lines[2]) is not None
    assert lines[3] == SCREEN_FAILURE


@pytest.mark.parametrize("bad_path,reason", [
    ("missing-dir/x.log", "no such file or directory"),
    ("a-dir", "is a directory"),
])
def test_unopenable_log_path_is_fatal(bad_path, reason, make_tree, lf_env,
                                      sandbox):
    """An -log that cannot be opened aborts startup with exit 1."""
    # CATCHES: the log is opened in main() before any client starts, so a
    # missing parent directory (or a directory as the path) is fatal: the
    # errno text is printed with a log timestamp on stderr and the process
    # exits 1 with empty stdout.
    tree = make_tree()
    (sandbox / "a-dir").mkdir()
    bad = sandbox / bad_path
    res = run_lf(["-single", "-log", str(bad)], cwd=str(tree), env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert strip_log_timestamps(res.err) == (
        "opening log file: open %s: %s\n" % (bad, reason))


def test_clean_session_log_has_only_the_two_banners(make_tree, lf_env,
                                                    sandbox):
    """A normal TUI session logs exactly the starting/closing banners."""
    # CATCHES: an uneventful client run logs nothing beyond the two banner
    # lines -- same PID in both, equal to the client's own process id.
    tree = make_tree()
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-log", str(log)], cwd=str(tree),
                     env=lf_env, keys=[b"q"])
    assert res.exit == 0
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 2
    start = re.match(BANNER_RE, lines[0])
    close = re.match(BANNER_RE, lines[1])
    assert start is not None and start.group(1) == "starting"
    assert close is not None and close.group(1) == "closing"
    assert start.group(2) == close.group(2) == str(res.pid)


def test_relative_log_path_resolves_against_the_cwd(make_tree, lf_env):
    """A relative -log value is resolved against the starting directory."""
    # CATCHES: main() absolutizes -log against the process working
    # directory at startup, so 'rel.log' appears inside the tree the client
    # was started in (unlike -config, which stays verbatim).
    tree = make_tree()
    res = run_lf(["-single", "-log", "rel.log"], cwd=str(tree), env=lf_env)
    assert res.rc == 1
    log = tree / "rel.log"
    assert log.is_file()
    first = strip_log_timestamps(log.read_text()).splitlines()[0]
    assert re.match(BANNER_RE, first) is not None


def test_unresolvable_cwd_with_relative_log_is_fatal(tmp_path, lf_env):
    """A relative -log path cannot be absolutized without a cwd: exit 1."""
    # CATCHES: absolutizing -log needs getwd(); with the working directory
    # deleted a RELATIVE -log aborts startup right there (log.Fatalf,
    # 'getting log path: getwd: ...', exit 1) -- earlier and with a
    # different message than the client's 'getting current directory:'
    # diagnostic -- and nothing is printed on stdout.
    inner = tmp_path / "gone" / "inner"
    inner.mkdir(parents=True)
    old_cwd = os.getcwd()
    os.chdir(str(inner))
    try:
        os.rmdir(str(inner))
        res = run_lf(["-single", "-log", "rel.log"], env=lf_env)
    finally:
        os.chdir(old_cwd)
    assert res.rc == 1
    assert res.out == ""
    assert strip_log_timestamps(res.err) == (
        "getting log path: getwd: no such file or directory\n")


def test_lf_level_parse_failure_goes_to_stderr_not_the_log(make_tree, lf_env,
                                                            sandbox):
    """A non-numeric $LF_LEVEL is logged before the log file is opened."""
    # CATCHES: exportEnvVars parses $LF_LEVEL in main(), before run()
    # redirects the Go logger into the -log file, so the parse error goes
    # to STDERR (with the logger timestamp) even when -log is given, while
    # the log file itself only holds the banner and screen failure -- and
    # the value is still treated as zero (client dies with exit 1).
    tree = make_tree()
    log = sandbox / "client.log"
    env = dict(lf_env)
    env["LF_LEVEL"] = "abc"
    res = run_lf(["-single", "-log", str(log)], cwd=str(tree), env=env)
    assert res.rc == 1
    assert strip_log_timestamps(res.err) == (
        'parsing $LF_LEVEL: strconv.Atoi: parsing "abc": invalid syntax\n')
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 2
    assert re.match(BANNER_RE, lines[0]) is not None
    assert lines[1] == SCREEN_FAILURE


def test_unreadable_history_file_is_reported_but_not_fatal(make_tree, lf_env,
                                                            sandbox):
    """A history file that cannot be read logs an error, the client runs on."""
    # CATCHES: run() reads the history file before the event loop; when it
    # cannot be read (a directory sits at $XDG_DATA_HOME/lf/history) the
    # error is surfaced as an 'error:' log line between the two banners and
    # the client still starts and quits normally with exit 0.
    tree = make_tree()
    hist = lf_env["XDG_DATA_HOME"] + "/lf/history"
    os.makedirs(hist)  # a directory where the history file would be
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-log", str(log)], cwd=str(tree),
                     env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 3
    assert re.match(BANNER_RE, lines[0]) is not None
    assert lines[1] == (
        "error: reading history file: reading history file: "
        "read %s: is a directory" % hist)
    assert re.match(BANNER_RE, lines[2]) is not None
