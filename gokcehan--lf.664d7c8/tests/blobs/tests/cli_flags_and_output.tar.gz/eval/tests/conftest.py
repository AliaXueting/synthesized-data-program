"""Black-box CLI test helpers for the lf reference binary (cli_flags_and_output).

This module pins lf's command-line interface and process lifecycle: the flag
surface (only long names are registered), the meta-flag dispatch order
(-doc > -help > -version > -remote > -server > client), the positional path
argument handling, the output written on exit (-print-last-dir /
-print-selection / -last-dir-path / -selection-path), the -log runtime log,
the environment lf exports for shell commands, and the signal behavior of a
running client.

The interactive client needs a terminal, so the harness drives it through a
private pty: lf's own stdout is a pipe (so -print-last-dir output can be
asserted byte-exactly and terminal sanitization can be told apart from the
raw path), while stdin/stderr and the controlling terminal are the pty where
the tcell TUI draws.  A second mode keeps stdout on the pty to exercise the
"stdout is a terminal" branch of path printing.

The child environment is fully pinned (PATH, HOME, TERM, XDG_* under the
test's tmp_path) so host settings cannot change the recorded behavior, and
the unix socket directory lf would use is redirected into the same sandbox.
Every client run uses -single so no detached server is ever spawned.
"""

import fcntl
import hashlib
import os
import pty
import re
import select
import signal
import struct
import subprocess
import termios
import time

import pytest

#: Resolved through PROGRAMGYM_EXECUTABLE (set by eval/run.sh) so the same
#: tests run unchanged against the reference binary and any candidate build.
EXE = os.environ.get("PROGRAMGYM_EXECUTABLE", "executable")

#: Per-run wall-clock budget for one child; well under the harness timeout.
TIMEOUT_SECONDS = 10

#: Exact usage block printed by flag.Usage(); {argv0} is os.Args[0].
USAGE_TEMPLATE = (
    "lf - Terminal file manager\n"
    "\n"
    "Usage: {argv0} [options] [path]\n"
    "\n"
    "Arguments:\n"
    "  path\n"
    "    \tset the initial directory or select the given file\n"
    "\n"
    "Options:\n"
    "  -command command\n"
    "    \tcommand to execute on client initialization\n"
    "  -config path\n"
    "    \tpath to the config file (instead of the usual paths)\n"
    "  -cpuprofile path\n"
    "    \tpath to the file to write the CPU profile\n"
    "  -doc\n"
    "    \tshow documentation\n"
    "  -help\n"
    "    \tshow help\n"
    "  -last-dir-path path\n"
    "    \tpath to the file to write the last dir on exit (to use for cd)\n"
    "  -log path\n"
    "    \tpath to the log file to write messages\n"
    "  -memprofile path\n"
    "    \tpath to the file to write the memory profile\n"
    "  -print-last-dir\n"
    "    \tprint the last dir to stdout on exit (to use for cd)\n"
    "  -print-selection\n"
    "    \tprint the selected files to stdout on open (to use as open file dialog)\n"
    "  -remote command\n"
    "    \tsend remote command to server\n"
    "  -selection-path path\n"
    "    \tpath to the file to write selected files on open (to use as open file dialog)\n"
    "  -server\n"
    "    \tstart server (automatic)\n"
    "  -single\n"
    "    \tstart a client without server\n"
    "  -version\n"
    "    \tshow version\n"
)


def expected_usage(argv0=None):
    """The exact usage text for a given invocation path."""
    return USAGE_TEMPLATE.format(argv0=argv0 or EXE)


#: Recorded reference values (observed from ./executable, r42-664d7c8).
VERSION_LINE = "r42-664d7c8\n"
DOC_SHA256 = "fcf6edb5dab58c028ad814970108e8c8a2f098dbe0b3d78bfc2512cafd1963ce"
DOC_LENGTH = 88898

#: Base environment handed to every child process.  HOME/XDG_* point into the
#: test sandbox so no host configuration file is ever picked up.
PINNED_ENV = {
    "TERM": "xterm",
    "PATH": "/usr/bin:/bin",
    "LANG": "C",
    "LC_ALL": "C",
    "SHELL": "/bin/sh",
    "USER": "root",
}


def build_env(sandbox, **extra):
    """Pinned child environment for a run inside ``sandbox``.

    ``sandbox`` is the test's private directory; HOME, XDG_RUNTIME_DIR (where
    lf's unix socket would live), XDG_CONFIG_HOME and XDG_DATA_HOME all point
    below it.  ``extra`` overrides/adds variables (e.g. VISUAL, LF_LEVEL).
    """
    sandbox = str(sandbox)
    env = dict(PINNED_ENV)
    env["HOME"] = os.path.join(sandbox, "home")
    env["XDG_RUNTIME_DIR"] = os.path.join(sandbox, "runtime")
    env["XDG_CONFIG_HOME"] = os.path.join(sandbox, "home", ".config")
    env["XDG_DATA_HOME"] = os.path.join(sandbox, "home", ".local", "share")
    env.update(extra)
    # Coverage instrumentation hook: the pipeline rebuilds the reference with
    # ``go build -cover`` and points GOCOVERDIR at a counter directory; pass
    # it through so reference-source coverage is measured.
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env.update({"GOCOVERDIR": value})
    return env


class RunResult:
    """Outcome of one headless lf invocation: exit status plus output."""

    __slots__ = ("rc", "out", "err", "timed_out")

    def __init__(self, rc, out, err, timed_out=False):
        self.rc = rc
        self.out = (out or b"").decode("utf-8", "surrogateescape")
        self.err = (err or b"").decode("utf-8", "surrogateescape")
        #: True when the invocation had to be killed after ``timeout``.
        self.timed_out = timed_out

    def __repr__(self):
        return "RunResult(rc=%r, out=%r, err=%r)" % (self.rc, self.out, self.err)


def run_lf(args, cwd=None, env=None, timeout=TIMEOUT_SECONDS, stdin=b""):
    """Run the binary once WITHOUT a terminal and return a RunResult.

    The subprocess gets no controlling terminal (the pytest process has
    none), so the interactive client fails at screen init exactly like it
    does in the pipeline; meta flags and diagnostics work normally.
    """
    return run_argv([EXE] + [str(a) for a in args], cwd=cwd, env=env,
                    timeout=timeout, stdin=stdin)


def run_argv(argv, cwd=None, env=None, timeout=TIMEOUT_SECONDS, stdin=b""):
    """Run an explicit argv headless (any argv[0]) and return a RunResult.

    Unlike :func:`run_lf` the command line is given in full, so tests can
    invoke the binary through a symlink (or any other name) and pin
    argv[0]-dependent output such as the usage header.
    """
    try:
        proc = subprocess.run(
            [str(a) for a in argv],
            input=stdin,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(cwd) if cwd is not None else None,
            env=env,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        return RunResult(None, exc.stdout or b"", exc.stderr or b"", True)
    return RunResult(proc.returncode, proc.stdout, proc.stderr, False)


class PtyResult:
    """Outcome of one pty-driven lf run."""

    __slots__ = ("exit", "signaled", "termsig", "out", "tty", "pid")

    def __init__(self, pid, exit_code, signaled, termsig, out, tty):
        self.pid = pid
        #: Exit code when the process exited normally, else None.
        self.exit = exit_code
        #: True when the process died from a signal (incl. our cleanup kill).
        self.signaled = signaled
        self.termsig = termsig
        #: Bytes lf wrote to its own stdout (a pipe in "pipe" mode).
        self.out = out
        #: Everything the TUI drew on the pty.
        self.tty = tty

    def __repr__(self):
        return "PtyResult(exit=%r, signaled=%r, out=%r, tty=%d bytes)" % (
            self.exit, self.signaled, self.out, len(self.tty))


def _drain(readable, sink, timeout=1.0):
    """Read the given fds until EOF or timeout; append to bytearrays."""
    deadline = time.time() + timeout
    open_fds = list(readable)
    while open_fds and time.time() < deadline:
        r, _, _ = select.select(open_fds, [], [], 0.05)
        for fd in r:
            try:
                data = os.read(fd, 65536)
            except OSError:
                data = b""
            if not data:
                open_fds.remove(fd)
                continue
            sink(fd, data)


def run_pty(argv, cwd, env, keys=(), stdout="pipe", rows=24, cols=80,
            timeout=9.0, key_delay=0.6):
    """Run a full argv on a private pty and return a :class:`PtyResult`.

    Unlike :func:`run_lf_tty` this takes the complete command line, so it can
    also drive a shell wrapper around the binary (etc/lfcd.sh under test).

    :param argv:   full command line, argv[0] included.
    :param cwd:    working directory for the child.
    :param env:    full child environment (see :func:`build_env`).
    :param keys:   sequence of byte chunks typed into the pty; each chunk is
                   sent only after the TUI has drawn and output settled.
    :param stdout: "pipe" -> fd 1 is a pipe (NOT a terminal, so path printing
                   is unsanitized); "tty" -> fd 1 stays on the pty (the
                   terminal branch of printPath is exercised).
    """
    r_pipe, w_pipe = os.pipe()
    pid, mfd = pty.fork()
    if pid == 0:  # child: controlling terminal + stdin/stderr = pty slave
        try:
            if stdout == "pipe":
                os.dup2(w_pipe, 1)
            os.close(r_pipe)
            os.close(w_pipe)
            os.chdir(str(cwd))
            os.execve(str(argv[0]), [str(a) for a in argv], env)
        except Exception:
            os._exit(127)
    os.close(w_pipe)
    fcntl.ioctl(mfd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))

    out = bytearray()
    tty = bytearray()
    status = None
    eof = {"pipe": False, "tty": False}
    pending = list(keys)
    next_key_at = None
    deadline = time.time() + timeout
    while time.time() < deadline:
        fds = []
        if stdout == "pipe" and not eof["pipe"]:
            fds.append(r_pipe)
        if not eof["tty"]:
            fds.append(mfd)
        if not fds:
            break
        r, _, _ = select.select(fds, [], [], 0.05)
        for fd in r:
            try:
                data = os.read(fd, 65536)
            except OSError:
                data = b""
            if not data:
                if fd == r_pipe:
                    eof["pipe"] = True
                else:
                    eof["tty"] = True
                continue
            if fd == r_pipe:
                out.extend(data)
            else:
                tty.extend(data)
        # The TUI is up once it drew a screenful; then type the queued chunks.
        if next_key_at is None and len(tty) > 300:
            next_key_at = time.time() + key_delay
        if pending and next_key_at is not None and time.time() >= next_key_at:
            try:
                os.write(mfd, pending.pop(0))
            except OSError:
                pass
            next_key_at = time.time() + key_delay
        try:
            wpid, st = os.waitpid(pid, os.WNOHANG)
            if wpid:
                status = st
                break
        except ChildProcessError:
            break
    # Drain whatever the child wrote between its last write and the reap:
    # -print-last-dir output lands here right before process exit.
    sinks = {r_pipe: out, mfd: tty}
    _drain([fd for fd in (r_pipe, mfd)], lambda fd, d: sinks[fd].extend(d),
           timeout=1.0)
    if status is None:
        try:
            os.kill(pid, signal.SIGKILL)
            _, status = os.waitpid(pid, 0)
        except Exception:
            status = 0
    for fd in (mfd, r_pipe):
        try:
            os.close(fd)
        except OSError:
            pass
    if os.WIFSIGNALED(status):
        return PtyResult(pid, None, True, os.WTERMSIG(status),
                         bytes(out), bytes(tty))
    return PtyResult(pid, os.WEXITSTATUS(status), False, None,
                     bytes(out), bytes(tty))


def run_lf_tty(args, cwd, env, keys=(b"q",), stdout="pipe", rows=24, cols=80,
               timeout=9.0, key_delay=0.6, extra_env=None):
    """Run lf on a private pty and return a :class:`PtyResult`.

    Convenience wrapper around :func:`run_pty` that prepends the binary and
    merges ``extra_env`` into the child environment.
    """
    child_env = dict(env)
    child_env.update(extra_env or {})
    return run_pty([EXE] + [str(a) for a in args], cwd=cwd, env=child_env,
                   keys=keys, stdout=stdout, rows=rows, cols=cols,
                   timeout=timeout, key_delay=key_delay)


def spawn_client(args, cwd, env, rows=24, cols=80, stdout="tty"):
    """Start a live lf client on its own pty and return a ClientProcess.

    Used by tests that need to poke a *running* client (signals, liveness)
    instead of a completed run; the caller must :meth:`ClientProcess.close`.
    ``stdout="pipe"`` keeps the child's fd 1 on a pipe so what lf prints on
    exit (e.g. -print-last-dir) can be asserted byte-exactly while the TUI
    still draws on the pty.
    """
    return ClientProcess([str(a) for a in args], cwd=str(cwd), env=env,
                         rows=rows, cols=cols, stdout=stdout)


class ClientProcess:
    """A running lf client on a pty, for tests that poke it with signals."""

    def __init__(self, args, cwd, env, rows=24, cols=80, stdout="tty"):
        self.env = dict(env)
        #: read end of the stdout pipe (pipe mode only); closed at EOF.
        self.out_r = None
        pipe_w = None
        if stdout == "pipe":
            self.out_r, pipe_w = os.pipe()
        self.pid, self.mfd = pty.fork()
        if self.pid == 0:  # child
            try:
                if pipe_w is not None:
                    os.dup2(pipe_w, 1)
                    os.close(self.out_r)
                    os.close(pipe_w)
                os.chdir(str(cwd))
                os.execve(EXE, [EXE] + [str(a) for a in args], self.env)
            except Exception:
                os._exit(127)
        if pipe_w is not None:
            os.close(pipe_w)
        fcntl.ioctl(self.mfd, termios.TIOCSWINSZ,
                    struct.pack("HHHH", rows, cols, 0, 0))
        self.tty = bytearray()
        #: Bytes lf wrote to its own stdout (populated in pipe mode).
        self.out = bytearray()
        self.exited = False
        self.status = None

    def _read(self, timeout):
        fds = [self.mfd]
        if self.out_r is not None:
            fds.append(self.out_r)
        r, _, _ = select.select(fds, [], [], timeout)
        if not r:
            return False
        got_tty = False
        for fd in r:
            try:
                data = os.read(fd, 65536)
            except OSError:
                continue
            if not data:
                if fd == self.out_r:
                    try:
                        os.close(self.out_r)
                    except OSError:
                        pass
                    self.out_r = None
                continue
            if fd == self.mfd:
                self.tty.extend(data)
                got_tty = True
            else:
                self.out.extend(data)
        return got_tty

    def wait_drawn(self, timeout=4.0):
        """Block until the TUI produced a full screenful of output."""
        deadline = time.time() + timeout
        while time.time() < deadline and len(self.tty) < 300:
            self._read(0.05)
            self._poll()
        return len(self.tty) >= 300

    def wait_quiet(self, quiet=1.0, timeout=5.0):
        """Read until no output has arrived for ``quiet`` seconds."""
        deadline = time.time() + timeout
        last = time.time()
        while time.time() < deadline:
            if not self._read(0.05):
                if time.time() - last >= quiet:
                    return
            else:
                last = time.time()

    def send(self, data):
        try:
            os.write(self.mfd, data)
        except OSError:
            pass

    def raise_signal(self, sig):
        os.kill(self.pid, sig)

    def _poll(self):
        if self.exited:
            return True
        try:
            wpid, st = os.waitpid(self.pid, os.WNOHANG)
        except ChildProcessError:
            self.exited = True
            return True
        if wpid:
            self.status = st
            self.exited = True
            return True
        return False

    def alive(self):
        return not self._poll()

    def wait_exit(self, timeout=4.0):
        """Wait for exit; returns (exit_code, signaled, termsig)."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._read(0.05)
            if self._poll():
                break
            time.sleep(0.02)
        # Final drain: -print-last-dir bytes land in the pipe right before
        # the process exits, after the last poll above.
        self._read(0.1)
        if not self.exited:
            return (None, False, None)
        if os.WIFSIGNALED(self.status):
            return (None, True, os.WTERMSIG(self.status))
        return (os.WEXITSTATUS(self.status), False, None)

    def close(self):
        """Make sure the child is dead and reaped (coverage flush on exit)."""
        if not self.exited:
            try:
                os.kill(self.pid, signal.SIGTERM)
                self.wait_exit(1.0)
            except OSError:
                pass
        if not self.exited:
            try:
                os.kill(self.pid, signal.SIGKILL)
                os.waitpid(self.pid, 0)
            except Exception:
                pass
            self.exited = True
        for fd in (self.mfd, self.out_r):
            if fd is None:
                continue
            try:
                os.close(fd)
            except OSError:
                pass
        self.out_r = None


LOG_TS_RE = re.compile(r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ", re.M)

#: One log banner line: '*************** starting client, PID: N ***********'
BANNER_RE = r"^\*{15} (starting|closing) client, PID: (\d+) \*{15}$"


def strip_log_timestamps(text):
    """Drop the ``YYYY/MM/DD HH:MM:SS `` prefix the Go logger puts on lines."""
    return LOG_TS_RE.sub("", text)


def sha256_hex(data):
    """SHA-256 hex digest of bytes (used to pin the embedded -doc text)."""
    return hashlib.sha256(data).hexdigest()


@pytest.fixture
def sandbox(tmp_path):
    """Private sandbox dir with the HOME/runtime/config/data layout inside."""
    for sub in ("home", "runtime", "home/.config", "home/.local/share"):
        (tmp_path / sub).mkdir(parents=True, exist_ok=True)
    os.chmod(str(tmp_path / "runtime"), 0o700)
    return tmp_path


@pytest.fixture
def lf_env(sandbox):
    """Pinned child environment rooted in the sandbox."""
    return build_env(sandbox)


@pytest.fixture
def make_tree(tmp_path):
    """Factory building a directory tree for a client run.

    Default layout is one directory plus three files, so the lf listing is
    ``sub, a.txt, b.txt, c.txt`` (directories first) and cursor movement is
    deterministic.
    """
    def _make(files=("a.txt", "b.txt", "c.txt"), dirs=("sub",), name="tree"):
        root = tmp_path / name
        root.mkdir(parents=True, exist_ok=True)
        for d in dirs:
            (root / d).mkdir(parents=True, exist_ok=True)
        for f in files:
            (root / f).write_text("content\n")
        return root
    return _make
