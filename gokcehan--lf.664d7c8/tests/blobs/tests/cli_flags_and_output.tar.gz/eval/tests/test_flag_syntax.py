"""Flag syntax: only the long flag names are registered, and the Go flag
package's diagnostics (usage on stderr + exit 2) fire for unknown flags,
missing values and invalid boolean values."""

import pytest

from conftest import DOC_LENGTH, expected_usage, run_lf, run_lf_tty


@pytest.mark.parametrize("flag,name", [
    ("-frobnicate", "-frobnicate"),
    ("--nope", "-nope"),
    ("-DOC", "-DOC"),
])
def test_unknown_flag_prints_error_and_usage(flag, name, lf_env):
    """An unregistered flag name exits 2 with the flag error plus usage."""
    # CATCHES: only the documented long names exist; any other flag (even a
    # case variant or a double-dashed unknown) is rejected with exit 2 and
    # the full usage block on stderr, nothing on stdout.
    res = run_lf([flag], env=lf_env)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == "flag provided but not defined: %s\n%s" % (name, expected_usage())


@pytest.mark.parametrize("flag", [
    "-command", "-config", "-log", "-remote", "-selection-path",
])
def test_missing_flag_value_is_an_error(flag, lf_env):
    """A value-taking flag given last exits 2 with 'flag needs an argument'."""
    # CATCHES: every string flag requires its value; omitting it must fail
    # with the flag package's 'flag needs an argument' diagnostic on stderr
    # followed by the usage block, before any client or server starts.
    res = run_lf([flag], env=lf_env)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == "flag needs an argument: %s\n%s" % (flag, expected_usage())


@pytest.mark.parametrize("flag", [
    "-last-dir-path", "-cpuprofile", "-memprofile",
])
def test_missing_value_for_path_and_profile_flags(flag, lf_env):
    """The output-path and profile flags also require a value argument."""
    # CATCHES: -last-dir-path, -cpuprofile and -memprofile are plain string
    # flags like the others: given last on the command line they fail with
    # the flag package's 'flag needs an argument' diagnostic plus the full
    # usage block on stderr and exit 2, before any file is ever touched.
    res = run_lf([flag], env=lf_env)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == "flag needs an argument: %s\n%s" % (flag, expected_usage())


@pytest.mark.parametrize("flag", [
    "-doc", "-help", "-version", "-single",
])
def test_invalid_boolean_value_is_rejected(flag, lf_env):
    """Boolean flags reject non-boolean values with a parse error + usage."""
    # CATCHES: the seven boolean flags go through strconv.ParseBool, so
    # '-flag=x' must exit 2 with 'invalid boolean value "x" for -flag:
    # parse error' plus usage instead of being treated as a positional arg.
    res = run_lf([flag + "=x"], env=lf_env)
    assert res.rc == 2
    assert res.out == ""
    expected = 'invalid boolean value "x" for %s: parse error\n%s' % (
        flag, expected_usage())
    assert res.err == expected


@pytest.mark.parametrize("flag", [
    "-print-last-dir", "-print-selection", "-server",
])
def test_invalid_boolean_value_for_output_and_server_flags(flag, lf_env):
    """The remaining boolean flags also reject bad values via ParseBool."""
    # CATCHES: -print-last-dir, -print-selection and -server are boolean
    # flags like -doc/-help/-version/-single: '=x' must exit 2 with
    # 'invalid boolean value "x" for -flag: parse error' plus the usage
    # block, the value never being treated as a positional path.
    res = run_lf([flag + "=x"], env=lf_env)
    assert res.rc == 2
    assert res.out == ""
    expected = 'invalid boolean value "x" for %s: parse error\n%s' % (
        flag, expected_usage())
    assert res.err == expected


def test_dash_h_is_not_a_registered_boolean_flag(lf_env):
    """-h and even -h=false print usage and exit 0 via the flag package."""
    # CATCHES: -h is not a registered alias: it only works through Go's
    # ErrHelp special case, so a value ('-h=false') is ignored and usage is
    # still printed to stderr with exit 0, unlike a real boolean flag which
    # would accept the value and start the client.
    res = run_lf(["-h"], env=lf_env)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == expected_usage()
    res2 = run_lf(["-h=false"], env=lf_env)
    assert res2.rc == 0
    assert res2.out == ""
    assert res2.err == expected_usage()


@pytest.mark.parametrize("value", ["1", "t", "TRUE"])
def test_boolean_value_forms_are_accepted(value, lf_env):
    """All strconv.ParseBool truthy spellings enable a boolean flag."""
    # CATCHES: -doc accepts 1/t/T/TRUE/True (not just 'true'), each printing
    # the whole embedded documentation to stdout with exit 0.
    res = run_lf(["-doc=%s" % value], env=lf_env)
    assert res.rc == 0
    assert res.err == ""
    raw = res.out.encode("utf-8", "surrogateescape")
    assert len(raw) == DOC_LENGTH
    assert raw.startswith(b"NAME\n\nlf - terminal file manager\n\nSYNOPSIS\n")


def test_double_dash_prefix_is_accepted(lf_env):
    """Both -flag and --flag spellings reach the same flag."""
    # CATCHES: the Go flag package treats one or two leading dashes alike,
    # so --version must behave exactly like -version.
    res = run_lf(["--version"], env=lf_env)
    assert res.rc == 0
    assert res.out == "r42-664d7c8\n"
    assert res.err == ""


def test_false_boolean_form_starts_the_client(lf_env, make_tree):
    """-doc=false disables the meta flag and falls through to the client."""
    # CATCHES: an explicit false value means the meta flag no longer wins;
    # the client branch runs and, without a terminal, dies with exit 1 and
    # no output at all (rather than printing documentation).
    tree = make_tree()
    res = run_lf(["-doc=false", "-single"], cwd=str(tree), env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""


def test_flags_after_the_positional_argument_are_not_parsed(make_tree, lf_env):
    """Flag parsing stops at the first positional argument."""
    # CATCHES: 'lf <dir> -print-last-dir' does not enable the flag; the text
    # after the directory becomes a second positional argument, which is the
    # 'only one file or directory may be specified' error with exit 2.
    tree = make_tree()
    res = run_lf(["-single", str(tree), "-print-last-dir"], cwd=str(tree),
                 env=lf_env)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == "only one file or directory may be specified\n"


def test_empty_remote_value_falls_through_to_the_client(make_tree, lf_env):
    """'-remote \"\"' does not dispatch to the remote branch."""
    # CATCHES: the meta dispatch tests the -remote VALUE for emptiness, so
    # an explicitly empty string is not a remote command: the normal client
    # starts instead and, headless, dies the usual silent exit-1 death with
    # no output at all (no dial error, no usage).
    tree = make_tree()
    res = run_lf(["-single", "-remote", ""], cwd=str(tree), env=lf_env)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ""


def test_double_dash_terminator_treats_flaglike_name_as_path(make_tree, lf_env):
    """'--' makes lf treat a flag-looking name as the positional path."""
    # CATCHES: after '--' the '-weird.txt' argument is a file to select, not
    # a flag: the client starts in the parent directory with that file under
    # the cursor, so opening it confirms and prints exactly that path.
    tree = make_tree(files=("a.txt", "-weird.txt"))
    res = run_lf_tty(["-single", "-print-selection", "--", "-weird.txt"],
                     cwd=str(tree), env=lf_env, keys=[b"l"])
    assert res.exit == 0
    assert res.signaled is False
    expected = (str(tree / "-weird.txt") + "\n").encode()
    assert res.out == expected
