"""The environment lf exports for the shell commands it runs (exportEnvVars,
exportFlags and the option mirrors): EDITOR/VISUAL/OPENER/PAGER/SHELL
resolution, the lf variable, LF_LEVEL nesting, the lf_flag_* mirrors of the
command line, and the lf_<option> / lf_user_<option> variables."""

import os
import shutil

import pytest

from conftest import EXE, run_lf_tty, run_pty

#: File the probed client writes its environment to (inside its cwd).
ENV_DUMP_NAME = "env-dump.txt"


def run_env_dump(tree, env, args=(), config_text=None):
    """Run a client that dumps its exported environment; return (dict, pid).

    The dump is produced by a ``-command '$env > env-dump.txt'`` startup
    command, i.e. exactly the environment lf hands to the shell commands it
    spawns.  ``config_text`` (if given) is written to ``lfrc`` in the tree
    and loaded through a *relative* ``-config lfrc``.
    """
    full_args = ["-single", "-command", "$env > %s" % ENV_DUMP_NAME]
    if config_text is not None:
        (tree / "lfrc").write_text(config_text)
        full_args += ["-config", "lfrc"]
    full_args += [str(a) for a in args]
    res = run_lf_tty(full_args, cwd=str(tree), env=env, keys=[b"q"])
    assert res.exit == 0
    dumped = {}
    for line in (tree / ENV_DUMP_NAME).read_text().splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            dumped[key] = value
    return dumped, res.pid


@pytest.mark.parametrize("overrides,expected", [
    ({}, "vi"),
    ({"EDITOR": "/bin/ed"}, "/bin/ed"),
    ({"VISUAL": "/bin/visual", "EDITOR": "/bin/ed"}, "/bin/visual"),
])
def test_editor_resolution_order(overrides, expected, make_tree, lf_env):
    """EDITOR resolves as VISUAL over EDITOR over the 'vi' default."""
    # CATCHES: exportEnvVars only exports EDITOR (never VISUAL), computing
    # it as VISUAL when set, else EDITOR when set, else the built-in 'vi'.
    tree = make_tree()
    env = dict(lf_env)
    env.update(overrides)
    dumped, _ = run_env_dump(tree, env)
    assert dumped["EDITOR"] == expected


def test_opener_pager_shell_defaults_and_passthrough(make_tree, lf_env):
    """OPENER/PAGER/SHELL default to xdg-open/less/sh and pass through."""
    # CATCHES: without OPENER/PAGER (and even with SHELL removed from the
    # environment) lf exports its own defaults; when the variables ARE set
    # they are passed through verbatim.
    tree = make_tree()
    bare = dict(lf_env)
    del bare["SHELL"]
    dumped, _ = run_env_dump(tree, bare)
    assert dumped["OPENER"] == "xdg-open"
    assert dumped["PAGER"] == "less"
    assert dumped["SHELL"] == "sh"
    custom = dict(lf_env)
    custom.update({"OPENER": "custom-opener", "PAGER": "custom-pager",
                   "SHELL": "/bin/zsh"})
    passed, _ = run_env_dump(tree, custom)
    assert passed["OPENER"] == "custom-opener"
    assert passed["PAGER"] == "custom-pager"
    assert passed["SHELL"] == "/bin/zsh"


@pytest.mark.parametrize("initial,expected", [
    (None, "1"),
    ("5", "6"),
])
def test_lf_level_increments_per_nesting(initial, expected, make_tree, lf_env):
    """LF_LEVEL counts nested lf instances, defaulting to 1."""
    # CATCHES: an unset (or non-numeric) LF_LEVEL starts at 1 and an
    # existing number is incremented by one, so nested instances can tell
    # their depth.
    tree = make_tree()
    env = dict(lf_env)
    if initial is not None:
        env["LF_LEVEL"] = initial
    dumped, _ = run_env_dump(tree, env)
    assert dumped["LF_LEVEL"] == expected


@pytest.mark.parametrize("initial,expected", [
    ("abc", "1"),
    ("-3", "-2"),
])
def test_lf_level_parse_edge_values(initial, expected, make_tree, lf_env):
    """A non-numeric $LF_LEVEL resets to 1; negatives keep decrementing."""
    # CATCHES: the nesting counter goes through strconv.Atoi: garbage
    # parses as zero (and is then incremented to 1) while a NEGATIVE value
    # parses fine and is decremented one further (-3 becomes -2), so the
    # exported LF_LEVEL is not clamped to positive numbers.
    tree = make_tree()
    env = dict(lf_env)
    env["LF_LEVEL"] = initial
    dumped, _ = run_env_dump(tree, env)
    assert dumped["LF_LEVEL"] == expected


def test_lf_variable_and_oldpwd_and_id(make_tree, lf_env):
    """'lf' is the binary's real path, OLDPWD the startup cwd, id the pid."""
    # CATCHES: exportEnvVars sets 'lf' to the resolved executable path (for
    # nested calls), OLDPWD to the directory lf started in, and 'id' to the
    # client's own PID (used to address this client over the socket).
    tree = make_tree()
    dumped, pid = run_env_dump(tree, lf_env)
    assert dumped["lf"] == os.path.realpath(EXE)
    assert dumped["OLDPWD"] == str(tree)
    assert dumped["id"] == str(pid)


def test_flag_variables_mirror_the_command_line(make_tree, lf_env):
    """lf_flag_* mirrors the flags; -log is absolutized, others verbatim."""
    # CATCHES: exportFlags exports exactly six lf_flag_* variables: the
    # booleans as true/false, the -log value absolutized against the
    # startup directory, -selection-path/-last-dir-path verbatim -- and no
    # lf_flag_command / lf_flag_remote even though both were involved.
    tree = make_tree()
    dumped, _ = run_env_dump(
        tree, lf_env,
        args=["-log", "rel.log", "-selection-path", "sel.out",
              "-last-dir-path", "last.out", "-print-last-dir"])
    assert dumped["lf_flag_single"] == "true"
    assert dumped["lf_flag_print_last_dir"] == "true"
    assert dumped["lf_flag_print_selection"] == "false"
    assert dumped["lf_flag_log"] == str(tree / "rel.log")
    assert dumped["lf_flag_selection_path"] == "sel.out"
    assert dumped["lf_flag_last_dir_path"] == "last.out"
    assert "lf_flag_command" not in dumped
    assert "lf_flag_remote" not in dumped
    # The absolutized log location is where the log really went.
    assert (tree / "rel.log").is_file()


def test_option_defaults_are_exported(make_tree, lf_env):
    """Every lf_<option> variable carries the option's default value."""
    # CATCHES: exportOpts publishes the whole option table as lf_* env
    # variables; pinning a sample of defaults (ratios, preview, sortby,
    # tabstop, autoquit, period, wrapscan, number, height, width, ...)
    # catches a rebuilt option set with different defaults.
    tree = make_tree()
    dumped, _ = run_env_dump(tree, lf_env)
    expected = {
        "lf_ratios": "1:2:3",
        "lf_hidden": "false",
        "lf_preview": "true",
        "lf_number": "false",
        "lf_sortby": "natural",
        "lf_shell": "sh",
        "lf_tabstop": "8",
        "lf_autoquit": "true",
        "lf_period": "0",
        "lf_wrapscan": "true",
        "lf_scrolloff": "0",
        "lf_selmode": "all",
        "lf_height": "24",
        "lf_width": "80",
    }
    for name, value in expected.items():
        assert dumped.get(name) == value, name


def test_config_options_and_user_variables(make_tree, lf_env):
    """A config file's options and user_* definitions become lf_* vars."""
    # CATCHES: loading 'set hidden' flips the mirrored lf_hidden option,
    # 'set user_x v' defines lf_user_x, and the relative -config value is
    # exported verbatim in lf_flag_config.
    tree = make_tree()
    dumped, _ = run_env_dump(
        tree, lf_env,
        config_text="set hidden\nset user_myopt myval\n"
                    "set user_multi x:y\n")
    assert dumped["lf_hidden"] == "true"
    assert dumped["lf_user_myopt"] == "myval"
    assert dumped["lf_user_multi"] == "x:y"
    assert dumped["lf_flag_config"] == "lfrc"


def test_lf_env_var_keeps_spaces_unquoted(make_tree, lf_env, sandbox):
    """The 'lf' variable is the raw binary path even when it has spaces."""
    # CATCHES: exportLfPath stores os.Executable's result through
    # quoteString, which on Unix is the identity function: a binary living at
    # a path with spaces exports that path VERBATIM (no shell quoting, no
    # backslash escapes), so nested '$lf' invocations still resolve -- an
    # implementation that escapes the path would export quotes or backslashes.
    spaced_dir = sandbox / "lf dir"
    spaced_dir.mkdir()
    spaced = spaced_dir / "lf binary"
    shutil.copy2(EXE, str(spaced))
    spaced.chmod(0o755)
    tree = make_tree()
    dump_name = "env-dump.txt"
    res = run_pty([str(spaced), "-single", "-command",
                   "$env > %s" % dump_name], cwd=str(tree), env=lf_env,
                  keys=[b"q"])
    assert res.exit == 0
    dumped = {}
    for line in (tree / dump_name).read_text().splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            dumped[key] = value
    assert dumped["lf"] == str(spaced)


def test_oldpwd_is_the_startup_cwd_not_the_navigated_directory(make_tree,
                                                               lf_env):
    """OLDPWD stays the process startup cwd even after lf navigates away."""
    # CATCHES: OLDPWD is exported once, before the client (and its shell
    # commands) run: a startup 'cd' into another directory changes where the
    # '$env' dump lands but not OLDPWD, which still names the directory lf
    # was STARTED from -- so OLDPWD and the -print-last-dir output disagree
    # after any navigation.
    tree = make_tree()
    res = run_lf_tty(["-single", "-command", "cd %s" % tree,
                      "-command", "$env > env-dump.txt",
                      "-print-last-dir"],
                     cwd=str(tree / "sub"), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % tree
    dumped = {}
    for line in (tree / "env-dump.txt").read_text().splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            dumped[key] = value
    assert dumped["OLDPWD"] == str(tree / "sub")
