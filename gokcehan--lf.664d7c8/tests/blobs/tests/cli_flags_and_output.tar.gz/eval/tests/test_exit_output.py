"""lf's exit-time output: what -print-last-dir / -print-selection write to
stdout and what -last-dir-path / -selection-path write to files -- the
newline-skip rule, the terminal-only sanitization of control characters,
and the logged (non-fatal) errors when a path file cannot be written."""

import signal
import time

import pytest

from conftest import run_lf_tty, spawn_client, strip_log_timestamps

#: Key sequence that marks a.txt and c.txt in the default tree (listing is
#: ``sub, a.txt, b.txt, c.txt``) and then opens a.txt to confirm.
MARK_A_AND_C = [b"j", b" ", b"j", b" ", b"j", b"l"]


def test_print_last_dir_reports_the_cwd_on_quit(make_tree, lf_env):
    """Quitting prints the current directory with a trailing newline."""
    # CATCHES: -print-last-dir prints the client's cwd (not the startup dir
    # if navigation happened) as one absolute path line on stdout, and the
    # client still exits 0.
    tree = make_tree()
    res = run_lf_tty(["-single", "-print-last-dir"], cwd=str(tree),
                     env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % tree


def test_print_last_dir_follows_navigation_up(make_tree, lf_env):
    """Navigating with 'h' changes the directory printed on exit."""
    # CATCHES: printPath reports the directory the client ended up in, so
    # going up from a subdirectory prints the parent, not the startup cwd.
    tree = make_tree()
    res = run_lf_tty(["-single", "-print-last-dir"], cwd=str(tree / "sub"),
                     env=lf_env, keys=[b"h", b"q"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % tree


def test_print_selection_prints_the_opened_file(make_tree, lf_env):
    """Opening a file with -print-selection prints exactly that path."""
    # CATCHES: 'l' on a file under -print-selection confirms the dialog:
    # the file's path is printed to stdout and the client quits with 0.
    tree = make_tree()
    res = run_lf_tty(["-single", "-print-selection"], cwd=str(tree),
                     env=lf_env, keys=[b"j", b"l"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % (tree / "a.txt")


def test_opening_a_directory_does_not_confirm(make_tree, lf_env):
    """Opening a directory navigates instead of confirming the dialog."""
    # CATCHES: -print-selection only fires for files; opening the directory
    # under the cursor must NOT quit the client (it navigates into it), so
    # the process is still alive afterwards and only 'q' ends it with 0.
    tree = make_tree()
    client = spawn_client(["-single", "-print-selection"], cwd=str(tree),
                          env=lf_env)
    try:
        assert client.wait_drawn(4.0)
        client.wait_quiet()
        client.send(b"l")  # cursor is on 'sub': navigate, not confirm
        time.sleep(1.0)
        assert client.alive()
        client.send(b"q")
        code, signaled, _ = client.wait_exit(4.0)
        assert code == 0
        assert not signaled
    finally:
        client.close()


def test_marked_files_are_printed_one_per_line(make_tree, lf_env):
    """Every marked file is printed on its own line, in listing order."""
    # CATCHES: printSelection prints the whole selection set (not just the
    # opened file) with one Println per entry, so marking a.txt and c.txt
    # and opening a.txt yields both paths in listing order.
    tree = make_tree()
    res = run_lf_tty(["-single", "-print-selection"], cwd=str(tree),
                     env=lf_env, keys=MARK_A_AND_C)
    assert res.exit == 0
    assert res.out.decode() == "%s\n%s\n" % (tree / "a.txt", tree / "c.txt")


def test_both_output_flags_print_dir_then_selection(make_tree, lf_env):
    """With both flags, the last dir line precedes the selection lines."""
    # CATCHES: main() writes the last dir first and the selection second,
    # so a confirmed open prints the directory line followed by the file
    # line -- both through their respective output paths.
    tree = make_tree()
    res = run_lf_tty(["-single", "-print-last-dir", "-print-selection"],
                     cwd=str(tree), env=lf_env, keys=[b"j", b"l"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n%s\n" % (tree, tree / "a.txt")


def test_last_dir_path_file_has_no_trailing_newline_and_truncates(
        make_tree, lf_env, sandbox):
    """-last-dir-path overwrites the file with the bare path, no newline."""
    # CATCHES: writeLastDir truncates any previous content and stores the
    # directory path without a trailing newline (shell wrappers rely on
    # that exact byte layout).
    tree = make_tree()
    last = sandbox / "last.out"
    last.write_text("PREVIOUS CONTENT THAT MUST BE TRUNCATED\n")
    res = run_lf_tty(["-single", "-last-dir-path", str(last)],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert last.read_text() == str(tree)


def test_selection_path_file_gets_newline_joined_paths(make_tree, lf_env,
                                                       sandbox):
    """-selection-path stores the selection joined by newlines, no tail."""
    # CATCHES: writeSelection joins multiple entries with '\n' and adds no
    # trailing newline -- different from the stdout form, which prints one
    # entry per line.
    tree = make_tree()
    sel = sandbox / "sel.out"
    res = run_lf_tty(["-single", "-selection-path", str(sel)],
                     cwd=str(tree), env=lf_env, keys=MARK_A_AND_C)
    assert res.exit == 0
    assert sel.read_text() == "%s\n%s" % (tree / "a.txt", tree / "c.txt")


def test_quitting_discards_the_selection_everywhere(make_tree, lf_env,
                                                    sandbox):
    """Quitting prints no selection and creates no selection file."""
    # CATCHES: only a confirmed open (not a plain quit) produces selection
    # output: stdout stays empty and the -selection-path file is never
    # created, while the client still exits 0 after drawing the TUI.
    tree = make_tree()
    sel = sandbox / "sel.out"
    res = run_lf_tty(["-single", "-print-selection", "-selection-path",
                      str(sel)], cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.out == b""
    assert not sel.exists()
    assert len(res.tty) > 300


def test_paths_containing_newlines_are_skipped(make_tree, lf_env, sandbox):
    """A last dir whose path contains a newline is skipped, not printed."""
    # CATCHES: paths with '\\n' would corrupt both the stdout protocol and
    # the last-dir file, so lf refuses them: nothing is printed, the file
    # keeps its old content, and the skip is logged (with Go %q quoting)
    # once per output path -- after the two client banner lines.
    tree = make_tree(dirs=("sub", "nl\nd"))
    last = sandbox / "last.out"
    sentinel = "SENTINEL" * 10
    last.write_text(sentinel)
    log = sandbox / "log.txt"
    res = run_lf_tty(["-single", "-print-last-dir", "-last-dir-path",
                      str(last), "-log", str(log)],
                     cwd=str(tree), env=lf_env, keys=[b"l", b"q"])
    assert res.exit == 0
    assert res.out == b""
    assert last.read_text() == sentinel
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("*************** closing client, PID: ")
    skip = 'last-dir: skipping path with newline: "%s/nl\\nd"' % tree
    assert lines[2] == skip
    assert lines[3] == skip


def test_control_characters_in_paths_depend_on_stdout_type(make_tree, lf_env):
    """Control characters pass through raw on a pipe but are replaced on a
    terminal."""
    # CATCHES: sanitizeName (U+FFFD replacement) applies ONLY when stdout is
    # a terminal: on the pipe the raw \\x01 byte is printed, while on the
    # pty the path is sanitized and newline-terminated (ONLCR -> CRLF).
    tree = make_tree(dirs=("ct\x01d", "sub"))
    keys = [b"l", b"q"]
    raw = run_lf_tty(["-single", "-print-last-dir"], cwd=str(tree),
                     env=lf_env, keys=keys)
    assert raw.exit == 0
    assert raw.out == ("%s/ct\x01d\n" % tree).encode("utf-8", "surrogateescape")
    term = run_lf_tty(["-single", "-print-last-dir"], cwd=str(tree),
                      env=lf_env, keys=keys, stdout="tty")
    assert term.exit == 0
    assert term.tty.endswith(b"ct\xef\xbf\xbdd\r\n")
    assert b"\x01" not in term.tty[-40:]
    assert len(term.tty) > 300


def test_last_dir_path_write_error_is_logged(make_tree, lf_env, sandbox):
    """An unwritable -last-dir-path is logged and the client still exits 0."""
    # CATCHES: failing to open the last-dir file is not fatal (the run
    # already finished): -print-last-dir still prints to stdout, the client
    # exits 0, and the open error is appended to the -log after the two
    # client banner lines.
    tree = make_tree()
    log = sandbox / "log.txt"
    bad = sandbox / "missing-dir" / "last.out"
    res = run_lf_tty(["-single", "-print-last-dir", "-last-dir-path",
                      str(bad), "-log", str(log)],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[2] == ("opening last dir file: open %s: "
                        "no such file or directory" % bad)


def test_selection_path_write_error_is_logged(make_tree, lf_env, sandbox):
    """A -selection-path that is a directory logs an error but still
    prints the selection to stdout."""
    # CATCHES: pointing -selection-path at an existing directory fails the
    # file open ('is a directory'), yet the stdout copy of the selection is
    # unaffected and the client exits 0 after a confirmed open.
    tree = make_tree()
    log = sandbox / "log.txt"
    sel_dir = tree / "sub"
    res = run_lf_tty(["-single", "-print-selection", "-selection-path",
                      str(sel_dir), "-log", str(log)],
                     cwd=str(tree), env=lf_env, keys=[b"j", b"l"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % (tree / "a.txt")
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[2] == ("opening selection file: open %s: is a directory"
                        % sel_dir)


def test_invert_marks_every_entry_but_newline_names(make_tree, lf_env,
                                                    sandbox):
    """'v' marks directories too; newline-named entries are filtered out."""
    # CATCHES: invert selects every listing entry (including the directory),
    # and the newline-named file is dropped from BOTH the stdout selection
    # and the -selection-path file, keeping both outputs line-safe.
    tree = make_tree(files=("a.txt", "b.txt", "c.txt", "we\nird.txt"))
    sel = sandbox / "sel.out"
    res = run_lf_tty(["-single", "-print-selection", "-selection-path",
                      str(sel)], cwd=str(tree), env=lf_env,
                     keys=[b"j", b"v", b"l"])
    assert res.exit == 0
    kept = [str(tree / n) for n in ("sub", "a.txt", "b.txt", "c.txt")]
    assert res.out.decode() == "".join(p + "\n" for p in kept)
    assert sel.read_text() == "\n".join(kept)


def test_carriage_return_paths_are_skipped_like_newlines(make_tree, lf_env,
                                                          sandbox):
    """A '\\r' in the last dir suppresses both outputs, logged as 'newline'."""
    # CATCHES: the skip rule rejects '\\r' just like '\\n' (and the log still
    # calls it a 'newline'): with the cursor entering a directory named
    # 'cr\\rd', nothing is printed on stdout, the -last-dir-path file keeps
    # its old content, and the skip line -- with Go %q quoting the '\\r' --
    # appears twice after the banners, once per output path.
    tree = make_tree(dirs=("sub", "cr\rd"))
    last = sandbox / "last.out"
    sentinel = "SENTINEL" * 10
    last.write_text(sentinel)
    log = sandbox / "log.txt"
    res = run_lf_tty(["-single", "-print-last-dir", "-last-dir-path",
                      str(last), "-log", str(log)],
                     cwd=str(tree), env=lf_env, keys=[b"l", b"q"])
    assert res.exit == 0
    assert res.out == b""
    assert last.read_text() == sentinel
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("*************** closing client, PID: ")
    skip = 'last-dir: skipping path with newline: "%s/cr\\rd"' % tree
    assert lines[2] == skip
    assert lines[3] == skip


def test_selection_newline_skip_is_logged_for_file_and_stdout(make_tree, lf_env,
                                                              sandbox):
    """Opening with a newline-named file marked logs one skip per output."""
    # CATCHES: each newline-named selection entry is dropped twice -- once by
    # the -selection-path writer and once by the stdout printer -- producing
    # two identical 'selection: skipping path with newline' log lines after
    # the closing banner, while both outputs keep the line-safe entries (the
    # file write happens before the stdout print in the exit epilogue).
    tree = make_tree(files=("a.txt", "b.txt", "c.txt", "we\nird.txt"))
    sel = sandbox / "sel.out"
    log = sandbox / "log.txt"
    res = run_lf_tty(["-single", "-print-selection", "-selection-path",
                      str(sel), "-log", str(log)],
                     cwd=str(tree), env=lf_env, keys=[b"j", b"v", b"l"])
    assert res.exit == 0
    kept = [str(tree / n) for n in ("sub", "a.txt", "b.txt", "c.txt")]
    assert res.out.decode() == "".join(p + "\n" for p in kept)
    assert sel.read_text() == "\n".join(kept)
    lines = strip_log_timestamps(log.read_text()).splitlines()
    skip = 'selection: skipping path with newline: "%s/we\\nird.txt"' % tree
    assert len(lines) == 4
    assert lines[2] == skip
    assert lines[3] == skip


@pytest.mark.parametrize("name,tty_suffix,forbidden", [
    ("del\x7flete", b"del\xef\xbf\xbdlete\r\n", b"\x7f"),
    ("c1\x85x", b"c1\xef\xbf\xbdx\r\n", b"\xc2\x85"),
    ("caf\xe9", b"caf\xc3\xa9\r\n", None),
], ids=["del", "c1-control", "accent"])
def test_terminal_sanitization_covers_del_and_c1_not_printable_unicode(
        name, tty_suffix, forbidden, tmp_path, lf_env):
    """On a terminal DEL and C1 control runes become U+FFFD; accents do not."""
    # CATCHES: sanitizeName replaces the whole control range -- C0, DEL
    # (0x7F) and the C1 range (U+0080..U+009F) -- with U+FFFD when stdout is
    # a terminal, while printable non-ASCII (an accented letter) passes
    # through untouched; on a pipe the raw bytes are printed unchanged.
    tree = tmp_path / "tree"
    tree.mkdir()
    (tree / name).mkdir()
    args = ["-single", "-print-last-dir", "-command", "cd %s" % name]
    raw = run_lf_tty(args, cwd=str(tree), env=lf_env, keys=[b"q"])
    assert raw.exit == 0
    assert raw.out == ("%s/%s\n" % (tree, name)).encode(
        "utf-8", "surrogateescape")
    term = run_lf_tty(args, cwd=str(tree), env=lf_env, keys=[b"q"],
                      stdout="tty")
    assert term.exit == 0
    suffix = str(tree).encode() + b"/" + tty_suffix
    assert len(term.tty) > 300
    assert term.tty.endswith(suffix)
    if forbidden is not None:
        assert forbidden not in term.tty[-len(suffix):]
    else:
        assert b"\xef\xbf\xbd" not in term.tty[-len(suffix):]


def test_termination_signal_skips_all_exit_output(make_tree, lf_env, sandbox):
    """SIGTERM exits with code 3 and writes neither stdout nor path files."""
    # CATCHES: the termination-signal path ends the client with os.Exit(3)
    # from inside the event loop, bypassing run()'s exit-output epilogue
    # entirely: with -print-last-dir AND -last-dir-path active nothing is
    # printed on stdout and no path file is created -- unlike a 'q' quit,
    # which prints the directory.
    tree = make_tree()
    last = sandbox / "last.out"
    client = spawn_client(
        ["-single", "-print-last-dir", "-last-dir-path", str(last)],
        cwd=str(tree), env=lf_env, stdout="pipe")
    try:
        assert client.wait_drawn(4.0)
        client.wait_quiet(quiet=1.2)
        client.raise_signal(signal.SIGTERM)
        code, signaled, _ = client.wait_exit(4.0)
    finally:
        client.close()
    assert code == 3
    assert not signaled
    assert bytes(client.out) == b""
    assert not last.exists()
