"""The etc/lfcd.sh shell wrapper consumed end-to-end: a bash process on a
pty sources the wrapper, runs lf through it, and the directory lf reports
via -print-last-dir becomes the shell's working directory."""

import os
import shlex

from conftest import EXE, run_pty

#: The lfcd function from etc/lfcd.sh, embedded verbatim (the file's comment
#: header is usage documentation only).
LFCD_FUNCTION = """lfcd () {
    # `command` is needed in case `lfcd` is aliased to `lf`
    cd "$(command lf -print-last-dir "$@")"
}"""


def _bash_env(lf_env, sandbox):
    """Child env for bash, with a private bin/ holding an 'lf' symlink."""
    bin_dir = sandbox / "bin"
    bin_dir.mkdir(exist_ok=True)
    link = bin_dir / "lf"
    if not link.exists():
        os.symlink(os.path.realpath(EXE), str(link))
    env = dict(lf_env)
    env["PATH"] = "%s:/usr/bin:/bin" % bin_dir
    return env


def _run_lfcd_bash(lf_env, sandbox, script_body, keys):
    """Source lfcd.sh in bash, run the given body, return (PtyResult, pwd)."""
    script = sandbox / "lfcd.sh"
    script.write_text(LFCD_FUNCTION + "\n")
    pwd_file = sandbox / "pwd.txt"
    command = "source %s; %s; pwd > %s" % (
        shlex.quote(str(script)), script_body, shlex.quote(str(pwd_file)))
    res = run_pty(["/bin/bash", "-c", command], cwd=str(sandbox),
                  env=_bash_env(lf_env, sandbox), keys=keys)
    return res, pwd_file


def test_lfcd_changes_the_shell_cwd_to_the_last_dir(make_tree, lf_env,
                                                    sandbox):
    """lfcd cds the shell to wherever lf was when it quit."""
    # CATCHES: the wrapper feeds lf's -print-last-dir stdout to 'cd', so
    # navigating into a subdirectory and quitting leaves the *shell* (not
    # just lf) in that subdirectory.
    tree = make_tree()
    res, pwd_file = _run_lfcd_bash(
        lf_env, sandbox,
        "cd %s; lfcd -single" % shlex.quote(str(tree)),
        keys=[b"l", b"q"])  # l: enter 'sub' (first entry), then quit
    assert res.exit == 0
    assert res.signaled is False
    assert pwd_file.read_text() == "%s\n" % (tree / "sub")


def test_lfcd_passes_arguments_through_to_lf(make_tree, lf_env, sandbox):
    """lfcd forwards its arguments ("$@") to the lf invocation."""
    # CATCHES: the wrapper quotes "$@" through to lf, so a directory
    # argument makes lf start there and quitting cds the shell straight to
    # that directory without any navigation.
    tree = make_tree()
    res, pwd_file = _run_lfcd_bash(
        lf_env, sandbox,
        "lfcd -single %s" % shlex.quote(str(tree / "sub")),
        keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert pwd_file.read_text() == "%s\n" % (tree / "sub")
