"""Round-4 additions across main.go/client.go behaviors that earlier rounds
left unpinned: WHEN startup commands run relative to the first directory
listing (a startup 'open' is a no-op), the -config flag's verbatim
lf_flag_config mirror and its missing-file log line, meta flags never
opening the -log file, -cpuprofile's non-absolutized relative path, the
owner-only permissions of the -log file, the write order when
-last-dir-path and -selection-path share one file, and startup being
independent of the TERM value."""

import os
import stat

import pytest

from conftest import (
    DOC_LENGTH,
    VERSION_LINE,
    expected_usage,
    run_lf,
    run_lf_tty,
    strip_log_timestamps,
)


def test_startup_open_command_confirms_nothing(make_tree, lf_env):
    """'-command open' does not confirm the -print-selection dialog."""
    # CATCHES: startup commands are evaluated before the first directory
    # listing has arrived (it is loaded asynchronously and consumed by the
    # event loop afterwards), so 'open' finds no current file and is a
    # no-op: the client keeps running (the TUI draws) and only 'q' ends it,
    # with -print-selection printing nothing -- an implementation that
    # awaits the listing before running startup commands would quit and
    # print the selected file instead.
    tree = make_tree(files=("a.txt", "b.txt"), dirs=())
    res = run_lf_tty(["-single", "-command", "open", "-print-selection"],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.out == b""
    assert len(res.tty) > 300


def test_startup_open_command_does_not_navigate(make_tree, lf_env):
    """'-command open' on the cursor directory neither enters it nor quits."""
    # CATCHES: with the cursor on 'sub', a startup 'open' that ran after the
    # listing loaded would navigate into the directory and make
    # -print-last-dir report tree/sub on quit; instead the startup command
    # no-ops on the still-empty listing, so quitting reports the startup
    # directory itself.
    tree = make_tree()
    res = run_lf_tty(["-single", "-command", "open", "-print-last-dir"],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % tree


def test_missing_config_file_is_logged_but_not_fatal(make_tree, lf_env,
                                                     sandbox):
    """A nonexistent -config target is one log line, not an error exit."""
    # CATCHES: the -config path is stat'ed when the client loop starts; a
    # missing file only logs 'config file does not exist: stat <path>: no
    # such file or directory' BETWEEN the two client banners -- the client
    # runs normally, -print-last-dir prints, and the exit code stays 0 (no
    # echoerr on the TUI, no fatal exit).
    tree = make_tree()
    log = sandbox / "log.txt"
    res = run_lf_tty(["-single", "-config", "missing-dir/rc", "-log",
                      str(log), "-print-last-dir"], cwd=str(tree),
                     env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1] == ("config file does not exist: stat missing-dir/rc: "
                        "no such file or directory")
    assert lines[2].startswith("*************** closing client, PID: ")
    assert len(lines) == 3


def test_lf_flag_config_mirrors_the_value_verbatim(make_tree, lf_env):
    """lf_flag_config holds the -config argument as given, not absolutized."""
    # CATCHES: unlike -log (absolutized against the startup directory before
    # being exported), the -config value is mirrored verbatim: a relative
    # 'lfrc' stays 'lfrc' in lf_flag_config, while the file itself IS loaded
    # -- its 'set hidden' flips the mirrored lf_hidden option to true before
    # any startup command runs.
    tree = make_tree()
    (tree / "lfrc").write_text("set hidden\n")
    res = run_lf_tty(["-single", "-config", "lfrc", "-command",
                      "$env > env-dump.txt"], cwd=str(tree), env=lf_env,
                     keys=[b"q"])
    assert res.exit == 0
    dumped = {}
    for line in (tree / "env-dump.txt").read_text().splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            dumped[key] = value
    assert dumped["lf_flag_config"] == "lfrc"
    assert dumped["lf_hidden"] == "true"


@pytest.mark.parametrize("meta", ["-version", "-help", "-doc"])
def test_meta_flags_never_open_the_log_file(meta, lf_env, sandbox):
    """-version/-help/-doc exit before the -log file is ever opened."""
    # CATCHES: the -log file is only opened inside run() (the client), so a
    # meta-flag run combined with -log must not create the file at all,
    # while still printing its own meta output and exiting 0 -- an
    # implementation that opens the log right after parsing flags would
    # leave an empty file behind.
    log = sandbox / "meta.log"
    res = run_lf([meta, "-log", str(log)], env=lf_env)
    assert res.rc == 0
    assert not log.exists()
    if meta == "-version":
        assert res.out == VERSION_LINE
        assert res.err == ""
    elif meta == "-doc":
        assert res.err == ""
        raw = res.out.encode("utf-8", "surrogateescape")
        assert len(raw) == DOC_LENGTH
        assert raw.startswith(b"NAME\n\nlf - terminal file manager\n")
    else:
        assert res.out == ""
        assert res.err == expected_usage()


def test_relative_cpuprofile_resolves_against_the_cwd(make_tree, lf_env):
    """A relative -cpuprofile is created in the working directory."""
    # CATCHES: unlike -log, -cpuprofile is NOT absolutized: os.Create
    # resolves the relative name against the process working directory, so
    # 'rel.out' lands in the startup directory as a gzip pprof stream while
    # -version still prints its normal output (an implementation that
    # absolutized it against the binary's directory would write elsewhere).
    tree = make_tree()
    res = run_lf(["-version", "-cpuprofile", "rel.out"], cwd=str(tree),
                 env=lf_env)
    assert res.rc == 0
    assert res.out == VERSION_LINE
    assert res.err == ""
    prof = tree / "rel.out"
    assert prof.is_file()
    raw = prof.read_bytes()
    assert raw[:2] == b"\x1f\x8b"
    assert len(raw) > 0


def test_log_file_is_created_owner_read_write_only(make_tree, lf_env,
                                                   sandbox):
    """The -log file is created with mode 0600 (owner read/write only)."""
    # CATCHES: the log is opened with os.OpenFile(..., 0o600) -- private to
    # the owner -- unlike the -last-dir-path/-selection-path files, which go
    # through os.Create and end up group/world-readable; a rebuild that
    # creates the log with default permissions fails this.
    tree = make_tree()
    log = sandbox / "mode.log"
    res = run_lf_tty(["-single", "-log", str(log)], cwd=str(tree),
                     env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert stat.S_IMODE(os.stat(str(log)).st_mode) == 0o600


def test_shared_path_file_ends_up_holding_the_selection(make_tree, lf_env,
                                                         sandbox):
    """One file for both flags: the selection write happens last."""
    # CATCHES: run()'s epilogue writes the last dir first and the selection
    # second, each truncating the target; when -last-dir-path and
    # -selection-path name the SAME file, the final content is just the
    # newline-free selection path -- pinning that write order (a rebuild
    # writing the selection first would leave the directory path behind).
    tree = make_tree()
    same = sandbox / "same.out"
    res = run_lf_tty(["-single", "-last-dir-path", str(same),
                      "-selection-path", str(same)], cwd=str(tree),
                     env=lf_env, keys=[b"j", b"l"])
    assert res.exit == 0
    assert same.read_text() == str(tree / "a.txt")


@pytest.mark.parametrize("term", ["", "lf-not-a-term"])
def test_client_starts_with_an_unusual_term(term, make_tree, lf_env):
    """Startup does not depend on a known TERM value."""
    # CATCHES: the terminal library falls back for an empty or unregistered
    # TERM: the client still draws its TUI, quits cleanly on 'q' with exit
    # 0, and -print-last-dir prints -- a rebuild that validates TERM at
    # startup (or refuses to create the screen for an unknown terminal
    # type) breaks this.
    tree = make_tree()
    env = dict(lf_env)
    env["TERM"] = term
    res = run_lf_tty(["-single", "-print-last-dir"], cwd=str(tree),
                     env=env, keys=[b"q"])
    assert res.exit == 0
    assert res.out.decode() == "%s\n" % tree
    assert len(res.tty) > 300
