"""Signal behavior of a running client: SIGINT is ignored so the terminal's
interrupt key cannot kill the file manager, while SIGHUP, SIGQUIT and
SIGTERM terminate the client with exit code 3."""

import signal
import time

import pytest

from conftest import spawn_client


def test_sigint_is_ignored_by_the_client(make_tree, lf_env):
    """SIGINT does not kill or quit a running client."""
    # CATCHES: lf installs a no-op SIGINT handler (so Ctrl-C in the
    # terminal never quits the file manager): after the signal the client
    # is still alive and responds to 'q' with a clean exit 0.
    tree = make_tree()
    client = spawn_client(["-single"], cwd=str(tree), env=lf_env)
    try:
        assert client.wait_drawn(4.0)
        client.wait_quiet()
        client.raise_signal(signal.SIGINT)
        time.sleep(0.8)
        assert client.alive()
        client.send(b"q")
        code, signaled, _ = client.wait_exit(4.0)
        assert code == 0
        assert not signaled
    finally:
        client.close()


def test_client_survives_sigint_and_still_prints_the_last_dir(make_tree,
                                                              lf_env):
    """After an ignored SIGINT the normal quit path still prints the last dir."""
    # CATCHES: the no-op SIGINT handler leaves the client fully functional:
    # not only does it stay alive, the later 'q' also runs the usual exit
    # epilogue, printing the current directory on stdout and exiting 0 -- the
    # signal neither kills the process (signal death) nor corrupts the
    # -print-last-dir output.
    tree = make_tree()
    client = spawn_client(["-single", "-print-last-dir"], cwd=str(tree),
                          env=lf_env, stdout="pipe")
    try:
        assert client.wait_drawn(4.0)
        client.wait_quiet()
        client.raise_signal(signal.SIGINT)
        time.sleep(0.8)
        assert client.alive()
        client.send(b"q")
        code, signaled, _ = client.wait_exit(4.0)
    finally:
        client.close()
    assert code == 0
    assert not signaled
    assert bytes(client.out) == ("%s\n" % tree).encode()


@pytest.mark.parametrize("sig", [
    signal.SIGHUP,
    signal.SIGQUIT,
    signal.SIGTERM,
])
def test_termination_signals_exit_with_code_3(sig, make_tree, lf_env):
    """SIGHUP, SIGQUIT and SIGTERM all make the client exit with code 3."""
    # CATCHES: these three signals are caught and terminate the client via
    # the dedicated exit code 3 (not the default signal death and not 0);
    # the client is allowed to settle first, because a signal racing the
    # draw loop can instead crash the tcell teardown with exit 2 -- so a
    # single such racing outcome is retried once on a fresh client.
    tree = make_tree()
    code = None
    signaled = None
    for _attempt in (1, 2):
        client = spawn_client(["-single"], cwd=str(tree), env=lf_env)
        try:
            assert client.wait_drawn(4.0)
            client.wait_quiet(quiet=1.2)
            client.raise_signal(sig)
            code, signaled, termsig = client.wait_exit(4.0)
        finally:
            client.close()
        if code == 3:
            break
    assert code == 3
    assert not signaled
