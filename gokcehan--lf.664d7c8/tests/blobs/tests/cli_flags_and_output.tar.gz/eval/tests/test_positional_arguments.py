"""The positional path argument: no argument means the current directory,
a directory argument starts inside it, a file argument selects the file in
its parent, two or more arguments are rejected, and an unresolvable current
directory is fatal before anything else happens."""

import os

import pytest

from conftest import run_lf, run_lf_tty, strip_log_timestamps

NO_CWD_ERROR = "getting current directory: getwd: no such file or directory\n"


@pytest.mark.parametrize("args", [
    ["-single", "a.txt", "b.txt"],
])
def test_more_than_one_positional_argument_is_rejected(args, lf_env):
    """Two positional arguments abort startup with the 'only one' error."""
    # CATCHES: exactly one file-or-directory operand is allowed; a second
    # one is the usage-level error 'only one file or directory may be
    # specified' on stderr with exit code 2, before any client starts.
    res = run_lf(args, env=lf_env)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == "only one file or directory may be specified\n"


def test_directory_argument_starts_inside_it(make_tree, lf_env):
    """A directory operand becomes the initial working directory."""
    # CATCHES: the positional directory is resolved at startup (independent
    # of the process cwd), so quitting immediately must print that very
    # directory through -print-last-dir, not the cwd the client was started
    # from.
    tree = make_tree()
    res = run_lf_tty(["-single", "-print-last-dir", str(tree / "sub")],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % (tree / "sub")


def test_file_argument_selects_the_file_in_its_parent(make_tree, lf_env):
    """A file operand starts in the parent directory with the file selected."""
    # CATCHES: for a file operand lf chdirs into the containing directory
    # and puts the cursor on that file, so opening it immediately confirms
    # with -print-selection and prints exactly that file's path.
    tree = make_tree()
    res = run_lf_tty(["-single", "-print-selection", str(tree / "b.txt")],
                     cwd=str(tree), env=lf_env, keys=[b"l"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % (tree / "b.txt")


def test_file_argument_reports_the_parent_as_last_dir(make_tree, lf_env):
    """With a file operand the last directory on exit is its parent."""
    # CATCHES: -print-last-dir after a file operand reports the directory
    # lf changed into (the parent), proving the chdir happened even though
    # the client was started from elsewhere.
    tree = make_tree()
    res = run_lf_tty(["-single", "-print-last-dir", str(tree / "c.txt")],
                     cwd=str(tree / "sub"), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % tree


def test_nonexistent_argument_falls_back_to_the_cwd(make_tree, lf_env,
                                                     sandbox):
    """A nonexistent path operand reports 'lstat' but starts in the cwd."""
    # CATCHES: the positional operand is only resolved once the client is
    # up: a path that does not exist produces a non-fatal 'lstat' error
    # line in the log (echoed on the TUI), the client starts in the
    # process working directory instead, and quitting exits 0 with that
    # directory as the last dir.
    tree = make_tree()
    missing = sandbox / "no-such-dir"
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-print-last-dir", "-log", str(log),
                      str(missing)],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert lines[1] == (
        "error: lstat %s: no such file or directory" % missing)


def test_unresolvable_cwd_without_arguments_exits_2(tmp_path, lf_env):
    """A deleted working directory is fatal with exit 2 before anything."""
    # CATCHES: with no positional argument lf needs getwd(); when the cwd
    # has been removed the startup fails with the plain (unprefixed, no
    # usage) diagnostic on stderr and exit code 2, and nothing is printed
    # on stdout.
    outer = tmp_path / "outer"
    inner = outer / "inner"
    inner.mkdir(parents=True)
    old_cwd = os.getcwd()
    os.chdir(str(inner))
    try:
        os.rmdir(str(inner))  # the process cwd is gone but still usable
        res = run_lf([], env=lf_env)
    finally:
        os.chdir(old_cwd)
    assert res.rc == 2
    assert res.out == ""
    assert res.err == NO_CWD_ERROR


def test_symlink_to_directory_operand_selects_it_instead_of_entering(
        make_tree, lf_env, sandbox):
    """A symlink operand pointing at a directory is selected, not entered."""
    # CATCHES: the operand is classified with os.Lstat, which does NOT follow
    # symlinks: a symlink to a directory counts as a file, so no 'cd' happens
    # and quitting reports the plain startup directory -- an implementation
    # using os.Stat would navigate into the link target and print that path
    # instead.  The log holds only the two client banners because the lstat
    # itself succeeded silently.
    tree = make_tree()
    os.symlink("sub", str(tree / "link"))
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-print-last-dir", "-log", str(log),
                      "link"], cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 2
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("*************** closing client, PID: ")


@pytest.mark.parametrize("operand,start_in_sub,expected_in_sub", [
    (".", False, False),
    ("sub/", False, True),
    ("..", True, False),
])
def test_dot_dotdot_and_trailing_slash_dir_operands(operand, start_in_sub,
                                                    expected_in_sub, make_tree,
                                                    lf_env):
    """'.', '..' and 'dir/' operands resolve to clean absolute directories."""
    # CATCHES: the operand goes through lstat plus 'cd' and is then reported
    # as an ABSOLUTE, cleaned path: '.' means the current directory, '..'
    # the parent, and a trailing slash on 'sub/' is dropped -- the directory
    # printed by -print-last-dir is never the operand text itself.
    tree = make_tree()
    start = tree / "sub" if start_in_sub else tree
    want = tree / "sub" if expected_in_sub else tree
    res = run_lf_tty(["-single", "-print-last-dir", operand],
                     cwd=str(start), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % want


def test_trailing_slash_on_a_file_operand_is_an_lstat_error(make_tree, lf_env,
                                                             sandbox):
    """'a.txt/' fails lstat with ENOTDIR and falls back to the cwd."""
    # CATCHES: a trailing slash makes a file operand un-stat-able, which is
    # reported like any other operand problem -- a non-fatal
    # 'error: lstat a.txt/: not a directory' line between the two banners,
    # echoing the operand verbatim (relative, slash kept) -- after which the
    # client starts in the process working directory and quits with exit 0.
    tree = make_tree()
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-print-last-dir", "-log", str(log),
                      "a.txt/"], cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 3
    assert lines[1] == "error: lstat a.txt/: not a directory"


def test_empty_operand_behaves_like_no_operand(make_tree, lf_env, sandbox):
    """An explicitly empty operand is indistinguishable from none at all."""
    # CATCHES: an empty positional argument sets the select path to '' which
    # lf treats as 'nothing to select': no lstat is attempted (so, unlike a
    # nonexistent path, NO error line is logged) and the client simply starts
    # in the current directory, quitting with exit 0.
    tree = make_tree()
    log = sandbox / "client.log"
    res = run_lf_tty(["-single", "-print-last-dir", "-log", str(log), ""],
                     cwd=str(tree), env=lf_env, keys=[b"q"])
    assert res.exit == 0
    assert res.signaled is False
    assert res.out.decode() == "%s\n" % tree
    lines = strip_log_timestamps(log.read_text()).splitlines()
    assert len(lines) == 2
    assert lines[0].startswith("*************** starting client, PID: ")
    assert lines[1].startswith("*************** closing client, PID: ")


def test_unresolvable_cwd_with_directory_argument_exits_1(tmp_path, lf_env,
                                                          make_tree):
    """A directory operand skips the getwd check but the client still dies."""
    # CATCHES: with a positional directory the initial dir comes from the
    # operand, so the getwd failure happens later, inside client startup:
    # the same diagnostic is logged but the process exits 1 (the client's
    # failure path) instead of the argument-validation exit 2.
    tree = make_tree()
    outer = tmp_path / "outer"
    inner = outer / "inner"
    inner.mkdir(parents=True)
    old_cwd = os.getcwd()
    os.chdir(str(inner))
    try:
        os.rmdir(str(inner))
        res = run_lf(["-single", "-print-last-dir", str(tree / "sub")],
                     env=lf_env)
    finally:
        os.chdir(old_cwd)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == NO_CWD_ERROR
