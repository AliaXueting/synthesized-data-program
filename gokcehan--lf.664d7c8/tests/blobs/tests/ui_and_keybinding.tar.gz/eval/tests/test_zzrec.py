"""TEMPORARY recording probe -- deleted after recording, never collected."""


def test_rec_more_sgr(run_lf):
    entries = [("i23", "3;23"), ("b25", "5;25"), ("s29", "9;29"),
               ("b48", "44;48"), ("u58", "4;58")]
    colors = "".join("*.%s %s\n" % (e, s) for e, s in entries)
    files = {"a%02d.%s" % (i + 1, e): {"data": b""} for i, (e, _) in enumerate(entries)}
    files["zzz"] = {"data": b""}
    r = run_lf(files=files, colors=colors, keys=[b"G"])
    lines = r.lines()
    for i, (e, s) in enumerate(entries):
        name = "a%02d.%s" % (i + 1, e)
        print("MORE %-4s sgr=%-6r x=%d row=%r style=%r" % (
            e, s, lines[i + 1].index(name), lines[i + 1],
            r.screen.style(i + 1, lines[i + 1].index(name))))


def test_rec_esc_other(run_lf):
    cfg = ('cmd e :echo "P\\033[Q Q\\033]8;;http://x R\\033]8 S\\033T\\033S U'
           '\\033]8;id=1\\aV"\n'
           'map e e\n')
    r = run_lf(files={"a": {}}, config=cfg, keys=[b"e"])
    print("ESC row23=%r" % r.lines()[23])
