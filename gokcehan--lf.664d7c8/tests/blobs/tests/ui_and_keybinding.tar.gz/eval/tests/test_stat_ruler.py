"""Statline and ruler rendering: deprecated statfmt/rulerfmt plus the
Go-template rulerfile (variables, helper funcs, SPACER, error paths)."""

import pytest


def test_statfmt_default_symlink(run_lf):
    """Default statfmt shows mode, size, mtime and symlink targets."""
    # CATCHES: the symlink target is appended as " -> a" after the mtime,
    # the permission block is cyan, and the rest of the row is unstyled.
    files = {"a": {}, "slink": {"link": "a"}}
    r = run_lf(files=files, config='set rulerfmt " RUL"\n', keys=[b"j"])
    assert r.lines()[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                             " -> a                   RUL")
    assert r.screen.style(23, 0) == (6, None, ())
    assert r.screen.style(23, 11) == (None, None, ())


def test_statfmt_all_placeholders(run_lf):
    """Every statfmt placeholder expands; empty sections are dropped."""
    # CATCHES: statfmt pipes separate sections and an empty section (like
    # %m in normal mode) vanishes entirely instead of leaving a separator,
    # so "-rw-r--r--" lands directly next to "rootroot5B".
    files = {"a": {"data": b"12345"}, "d/": {}}
    r = run_lf(files=files,
               config=('set rulerfmt " RUL"\n'
                       'set statfmt "%p|%u|%g|%s|%S|%t|%m|%M|%l"\n'),
               keys=[b"j"])
    assert r.lines()[23] == ("-rw-r--r--rootroot5B   5B"
                             "Sun Sep 13 12:26:40 2020NORMAL"
                             "                      RUL")


def test_statfmt_selection_counts(run_lf):
    """%M names the mode and %c the selection count for marked files."""
    # CATCHES: after toggling a selection %M renders NORMAL, %c the count
    # of selected files (1) and %s their total size (5B) concatenated.
    files = {"a": {"data": b"12345"}, "d/": {}}
    r = run_lf(files=files, config='set rulerfmt " RUL"\nset statfmt "%m|%M|%c|%s"\n',
               keys=[b" ", b"j"])
    assert r.lines()[23] == ("NORMAL15B"
                             "                                                                    RUL")


def test_statfmt_sgr_styles(run_lf):
    """SGR sequences inside statfmt color parts of the statline."""
    # CATCHES: statfmt accepts embedded escapes -- the permission block is
    # red while the size/time part after the reset stays default; the
    # deprecation warning is cleared by the keypress before the snapshot.
    files = {"a": {"data": b"12345"}, "d/": {}}
    r = run_lf(files=files,
               config=('set rulerfmt " R"\n'
                       'set statfmt "\\033[31m%p\\033[0m %s %t"\n'),
               keys=[b"j"])
    assert r.lines()[23] == ("-rw-r--r-- 5B Sun Sep 13 12:26:40 2020"
                             "                                         R")
    assert r.screen.style(23, 0) == (1, None, ())
    assert r.screen.style(23, 10) == (None, None, ())


def test_statfmt_deprecation_warning(run_lf):
    """Setting statfmt shows a deprecation warning until a key is pressed."""
    # CATCHES: the deprecation message replaces the statline immediately
    # (before any keypress) and is styled with the default error colors.
    files = {"a": {"data": b"12345"}}
    r = run_lf(files=files,
               config='set rulerfmt " R"\nset statfmt "\\033[31m%p\\033[0m %s %t"\n')
    assert r.lines()[23] == ("option 'statfmt' is deprecated and will be "
                             "replaced by the 'rulerfile' option  R")
    assert r.screen.style(23, 0) == (1, 7, ("reverse",))


@pytest.mark.parametrize("config,style", [
    ("", (1, 7, ("reverse",))),
    ('set errorfmt "\\033[7;32m"\n', (2, None, ("reverse",))),
])
def test_errorfmt_styles(run_lf, config, style):
    """Unknown commands echo an error rendered with errorfmt."""
    # CATCHES: the default error style is red on reverse video (fg=1 bg=7)
    # and a custom errorfmt replaces exactly that span on the msg line.
    r = run_lf(files={"a": {}}, config=config,
               keys=[b":", b"nosuchcmd", b"\r"])
    assert r.lines()[23] == ("command not found: nosuchcmd"
                             "                                                 1/1")
    assert r.screen.style(23, 0) == style


def test_message_line_precedence(run_lf):
    """Messages and errors replace the statline until the next keypress."""
    # CATCHES: `echo` output renders unstyled while `echoerr` reuses the
    # errorfmt style; both right-align the 1/1 counter like the statline.
    r = run_lf(files={"a": {}}, keys=[b":", b"echo hello-msg", b"\r"])
    assert r.lines()[23] == ("hello-msg"
                             "                                                                    1/1")
    assert r.screen.style(23, 0) == (None, None, ())
    r2 = run_lf(files={"a": {}},
                keys=[b":", b"echo first", b"\r", b":", b"echoerr second", b"\r"])
    assert r2.lines()[23] == ("second"
                              "                                                                       1/1")
    assert r2.screen.style(23, 0) == (1, 7, ("reverse",))


def test_rulerfile_vars(run_lf):
    """rulerfile exposes mode, index, totals, percentages and typed keys."""
    # CATCHES: .Index is 1-based, .All counts hidden files too, .Keys shows
    # a still-pending count prefix ("3" typed but no command run yet).
    r = run_lf(files={"a": {}, "b": {}},
               ruler=("M={{.Mode}} I={{.Index}} T={{.Total}} H={{.Hidden}} "
                      "A={{.All}} L={{.LinePercentage}} S={{.ScrollPercentage}} "
                      "K=[{{.Keys}}]"),
               keys=[b"j", b"3"])
    assert r.lines()[23] == "M=NORMAL I=2 T=2 H=0 A=2 L=100% S=All K=[3]"


def test_rulerfile_helper_funcs(run_lf):
    """Template helper funcs work on .Stat and the environment."""
    # CATCHES: humanize formats the raw byte count (14 -> 14B), env reads
    # the child environment, and join renders an empty filter as nothing.
    r = run_lf(files={"a.txt": {"data": b"12345678901234"}},
               ruler=('SZ={{humanize .Stat.Size}} U={{upper .Stat.Name}} '
                      'Lo={{lower .Stat.Name}} SUB={{substr .Stat.Name 0 3}} '
                      'E={{env "LF_PROBE_ENV"}} J=[{{join .Filter " "}}]'),
               env={"LF_PROBE_ENV": "envval"})
    assert r.lines()[23] == "SZ=14B U=A.TXT Lo=a.txt SUB=a.t E=envval J=[]"


def test_rulerfile_stat_fields(run_lf):
    """.Stat carries full stat metadata for the current file."""
    # CATCHES: Target renders empty (two adjacent spaces) for regular
    # files and Path is the absolute fixture path; humanize on the already
    # humanized .Stat.Size passes the string through unchanged.
    r = run_lf(files={"a": {}}, cols=200,
               ruler=("{{.Stat.Permissions}} {{.Stat.LinkCount}} {{.Stat.User}} "
                      "{{.Stat.Group}} {{.Stat.ModTime}} {{.Stat.Target}} "
                      "{{.Stat.Name}} {{.Stat.Extension}} {{.Stat.Path}}"))
    assert r.lines()[23] == ("-rw-r--r-- 1 root root Sun Sep 13 12:26:40 2020"
                             "  a  %s/a" % r.root)
    r2 = run_lf(files={"a": {}}, cols=200, ruler="{{humanize .Stat.Size}}")
    assert r2.lines()[23] == "0B"


@pytest.mark.parametrize("cols,ruler,expected", [
    (80, "LEFT{{.SPACER}}MID{{.SPACER}}RIGHT",
     "LEFT                                  MID                                  RIGHT"),
    (40, "LEFT{{.SPACER}}MID{{.SPACER}}RIGHT",
     "LEFT              MID              RIGHT"),
    (80, "A{{.SPACER}}B", "A" + " " * 78 + "B"),
])
def test_rulerfile_spacer(run_lf, cols, ruler, expected):
    """.SPACER distributes leftover width between the marked sections."""
    # CATCHES: the remaining width is split evenly between SPACERs (34
    # columns each at width 80, 14 at width 40) and a single SPACER
    # absorbs everything, pushing B flush against the right edge.
    r = run_lf(files={"a": {}}, ruler=ruler, cols=cols)
    assert r.lines()[23] == expected


def test_rulerfile_message_and_index(run_lf):
    """.Message mirrors the msg line and .Index tracks the cursor."""
    # CATCHES: the ruler template sees the transient echo message, so a
    # message set via :echo is visible in the ruler on the same frame.
    r = run_lf(files={"a": {}}, ruler="MSG=[{{.Message}}] I={{.Index}}",
               keys=[b":", b"echo hi-there", b"\r"])
    assert r.lines()[23] == "MSG=[hi-there] I=1"


@pytest.mark.parametrize("ruler,expected", [
    ("{{.NoSuchField}}",
     "rendering ruler: template: ruler:1:2: executing \"ruler\" at <.NoSuchField>: can't"),
    ("{{.Bad", "parsing ruler: template: ruler:1: unclosed action"),
])
def test_rulerfile_errors(run_lf, ruler, expected):
    """Broken ruler templates report parse or render errors on the msg line."""
    # CATCHES: a field error surfaces as "rendering ruler: template: ..."
    # while an unclosed action reports at parse time; both replace the
    # ruler with the errorfmt-styled message.
    r = run_lf(files={"a": {}}, ruler=ruler)
    assert r.lines()[23] == expected
    if "rendering" in expected:
        assert r.screen.style(23, 0) == (1, 7, ("reverse",))


def test_rulerfile_clipboard(run_lf):
    """Copy/Cut/Select/Visual expose clipboard state to the ruler."""
    # CATCHES: yank then cut shows the cut replacing the copy buffer
    # (C=0 X=1) and the selection itself stays empty after the commands.
    r = run_lf(files={"a": {}, "b": {}, "c": {}},
               ruler=('C={{len .Copy}} X={{len .Cut}} S={{len .Select}} '
                      'V={{len .Visual}} P=[{{join .Progress " "}}] '
                      'F=[{{join .Filter " "}}]'),
               keys=[b" ", b"y", b"j", b" ", b"d"])
    assert r.lines()[23] == "C=0 X=1 S=0 V=0 P=[] F=[]"


def test_rulerfile_user_options(run_lf):
    """UserOptions and Options maps expose live option values."""
    # CATCHES: `set user_x` lands in .UserOptions while .Options reflects
    # runtime changes made through :set after startup (tabstop 2 -> 4).
    r = run_lf(files={"a": {}},
               ruler=('U={{index .UserOptions "x"}} P={{.Options.preview}} '
                      'T={{.Options.tabstop}}'),
               config="set user_x userval\n",
               keys=[b":", b"set tabstop 4", b"\r"])
    assert r.lines()[23] == "U=userval P=true T=4"


@pytest.mark.parametrize("config,expected", [
    ("", "T=2 H=1 A=3"),
    ("set hidden\n", "T=3 H=0 A=3"),
])
def test_rulerfile_hidden_counts(run_lf, config, expected):
    """Hidden dot files are excluded from .Total until `set hidden`."""
    # CATCHES: .Total counts only visible entries while .All always counts
    # everything, so enabling hidden flips H to 0 and T to 3.
    files = {".dot": {}, "a": {}, "b": {}}
    r = run_lf(files=files, ruler="T={{.Total}} H={{.Hidden}} A={{.All}}",
               config=config)
    assert r.lines()[23] == expected


@pytest.mark.parametrize("keys,expected", [
    ([b"G"], "L=100% S=Bot I=40"),
    ([b"2", b"5", b"j"], "L=65% S=22% I=26"),
])
def test_rulerfile_scroll_percentages(run_lf, keys, expected):
    """Line/scroll percentages track the viewport over a long listing."""
    # CATCHES: G jumps to the bottom (S=Bot), and 25j from the top lands
    # at index 26 with the scroll fraction computed from the offset.
    files = {("f%02d" % i): {"data": b""} for i in range(40)}
    r = run_lf(files=files,
               ruler="L={{.LinePercentage}} S={{.ScrollPercentage}} I={{.Index}}",
               keys=keys)
    assert r.lines()[23] == expected


def test_rulerfile_visual_mode(run_lf):
    """The ruler sees VISUAL mode and the growing visual selection."""
    # CATCHES: entering visual mode and moving down twice selects 3 rows
    # (anchor + 2) and .Index reports the 1-based cursor position.
    files = {("f%02d" % i): {"data": b""} for i in range(4)}
    r = run_lf(files=files, ruler="MODE={{.Mode}} SELV={{len .Visual}} IDX={{.Index}}",
               keys=[b"V", b"j", b"j"])
    assert r.lines()[23] == "MODE=VISUAL SELV=3 IDX=3"
    assert r.screen.style(1, 14) == (6, None, ("reverse",))
    assert r.screen.style(3, 14) == (6, None, ("reverse",))
    assert r.screen.style(3, 16) == (None, None, ("reverse",))


def test_rulerfmt_deprecated_placeholders(run_lf):
    """Legacy rulerfmt still renders counters, keys and disk free."""
    # CATCHES: %a accumulates the typed keys ("5" after selecting), %h
    # shows the hidden count even when zero (blank here), %P the scroll
    # state (All) and %d the df free-space value which depends on the
    # machine, so only the stable prefix is asserted.
    files = {("f%02d" % i): {"data": b""} for i in range(10)}
    r = run_lf(files=files, config='set rulerfmt "%a|%s|%i/%t|%h|%P|%d"\n',
               keys=[b" ", b"j", b"5"])
    row = r.lines()[23]
    assert row.startswith("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40"
                          " 2020         513/100All")
    assert len(row) == 80
