"""termseq.go: ANSI escape-sequence parsing (SGR/OSC) and the sanitization
of untrusted text -- echo messages, filenames, link targets, prompt paths,
preview content and custom info columns.

Every expectation here was recorded by running the reference binary: the
escape sequences are injected through lfrc strings (the config scanner
decodes \\033-style octal escapes in double quotes), a colors file, previewer
scripts, or raw-byte fixture filenames created by the harness.
"""

import os


def _msg_row(msg):
    """A message line: message, padding, counter right-aligned on 80 cols."""
    return msg + " " * (77 - len(msg)) + "1/1"


def _script(base, name, text):
    """Write an executable helper script inside the fixture base dir."""
    p = os.path.join(base, name)
    with open(p, "w") as f:
        f.write(text)
    os.chmod(p, 0o755)
    return p


def _zoo(run_lf, entries):
    """Boot lf with one `*.ext` colors entry per (ext, sgr) pair.

    Files are named a01.<ext>.. so the alphabetical listing order equals the
    entry order; a plain `zzz` sentinel is added last and the cursor is
    parked on it with G so no zoo row carries the cursor style.
    """
    colors = "".join("*.%s %s\n" % (e, s) for e, s in entries)
    files = {"a%02d.%s" % (i + 1, e): {"data": b""} for i, (e, _) in enumerate(entries)}
    files["zzz"] = {"data": b""}
    return run_lf(files=files, colors=colors, keys=[b"G"])


def test_colors_sgr_attribute_codes(run_lf):
    """A colors file maps raw SGR attribute codes onto file names."""
    # CATCHES: applySGR handles the whole attribute family -- dim/italic/
    # blink/strike, the 4:2-4:5 underline styles, 4;24 and 4:0 switching
    # underline back off -- so a regression in token parsing loses or
    # misclassifies the style of the name column.
    entries = [("dim", "2"), ("ital", "3"), ("blink", "5"), ("strike", "9"),
               ("ud2", "4:2"), ("ud3", "4:3"), ("ud4", "4:4"), ("ud5", "4:5"),
               ("u24", "4;24"), ("ud0", "1;4:0")]
    r = _zoo(run_lf, entries)
    lines = r.lines()
    for i, (ext, _) in enumerate(entries):
        # every zoo row shows its file name in the name column (x=16); the
        # parent pane's "root" row only paints the first screen row
        assert lines[i + 1][16:] == "a%02d.%s" % (i + 1, ext)
        assert r.screen.style(i + 1, 16) == {
            "dim": (None, None, ("dim",)),
            "ital": (None, None, ("italic",)),
            "blink": (None, None, ("blink",)),
            "strike": (None, None, ("strikethrough",)),
            "ud2": (None, None, ("underline",)),
            "ud3": (None, None, ("underline",)),
            "ud4": (None, None, ("underline",)),
            "ud5": (None, None, ("underline",)),
            "u24": (None, None, ()),
            "ud0": (None, None, ("bold",)),
        }[ext]
    assert lines[len(entries) + 1] == "                zzz"
    # the 4:x dotted styles survive to the terminal: tcell re-emits each
    # distinct underline style (double/curly/dotted/dashed)
    raw = bytes(r.raw)
    for tok in (b"4:2m", b"4:3m", b"4:4m", b"4:5m"):
        assert tok in raw


def test_colors_sgr_color_codes(run_lf):
    """Color SGR codes, resets and malformed tokens behave as recorded."""
    # CATCHES: 38;5/48;5 palette and bright 9x/10x codes land on the right
    # fg/bg slots, an RGB color degrades to palette 233 without truecolor,
    # an empty token resets mid-sequence, "032" is read as "32" (leading
    # zeros are trimmed), "31;;32" ends plain green, and a broken "1;38"
    # aborts the rest of the sequence leaving only bold.
    entries = [("p256", "38;5;200"), ("rgb", "38;2;10;20;30"),
               ("bg256", "48;5;140"), ("bfg", "91"), ("bbg", "101"),
               ("fgbg", "31;44"), ("conceal", "44;8"), ("b22", "1;31;22"),
               ("rev27", "7;27"), ("midrst", "31;;32"), ("lead0", "032"),
               ("brk38", "1;38"), ("rst0", "0"), ("ulc", "4;58;5;99")]
    r = _zoo(run_lf, entries)
    expected = {
        "p256": (200, None, ()),
        "rgb": (233, None, ()),
        "bg256": (None, 140, ()),
        "bfg": (9, None, ()),
        "bbg": (None, 9, ()),
        "fgbg": (1, 4, ()),
        "conceal": (4, 4, ()),
        "b22": (1, None, ()),
        "rev27": (None, None, ()),
        "midrst": (2, None, ()),
        "lead0": (2, None, ()),
        "brk38": (None, None, ("bold",)),
        "rst0": (None, None, ()),
        "ulc": (None, None, ("underline",)),
    }
    for i, (ext, _) in enumerate(entries):
        assert r.screen.style(i + 1, 16) == expected[ext], ext
    # 58;5;n (underline color) is parsed and re-emitted by tcell
    assert b"58:5:99" in bytes(r.raw)


def test_echo_message_sanitization(run_lf):
    """:echo keeps lf's own SGR/OSC8 but defuses every other control byte."""
    # CATCHES: sanitizeMessage replaces C0 controls (SOH, TAB) with U+FFFD,
    # keeps the SGR pair so "RED" is actually red, consumes the EL sequence,
    # turns an unsupported CSI final (2J) into U+FFFD plus literal text, and
    # consumes a whole OSC 8 hyperlink pair leaving only the label visible
    # while the URL still reaches the terminal raw stream.
    cfg = ('cmd e :echo "A\\01B\\tC\\033[31mRED\\033[0m D\\033[2J E\\033[K F'
           '\\033]8;;http://ex.com\\033\\\\LNK\\033]8;;\\033\\\\"\n'
           'map e e\n')
    r = run_lf(files={"a": {}}, config=cfg, keys=[b"e"])
    msg = "A\ufffdB\ufffdCRED D\ufffd[2J E FLNK"
    assert r.lines()[23] == _msg_row(msg)
    assert r.screen.style(23, 5) == (1, None, ())
    assert b"http://ex.com" in bytes(r.raw)


def test_echo_hyperlink_bel_and_osc_title(run_lf):
    """BEL-terminated OSC 8 works; other OSC codes are not recognized."""
    # CATCHES: readTermSequence accepts BEL as an OSC 8 terminator just like
    # ESC\\ (the URL is swallowed from the text but re-emitted raw), while an
    # OSC 0 title sequence is NOT supported: its ESC and BEL both collapse
    # to U+FFFD and the body stays as literal text.
    cfg = ('cmd e :echo "U\\033]8;;http://bel.example\\aBEL-LNK\\033]8;;\\a V'
           '\\033]0title\\a W"\n'
           'map e e\n')
    r = run_lf(files={"a": {}}, config=cfg, keys=[b"e"])
    msg = "UBEL-LNK V\ufffd]0title\ufffd W"
    assert r.lines()[23] == _msg_row(msg)
    assert b"http://bel.example" in bytes(r.raw)


def test_echo_unterminated_long_sequences(run_lf):
    """A CSI final byte past offset 64 is never recognized as a sequence."""
    # CATCHES: readTermSequence only scans the first 64 bytes of a CSI, so
    # a 62-byte parameter list ending in `m` is NOT an SGR -- the ESC
    # becomes U+FFFD and the whole parameter text prints literally -- while
    # the same-length list ending in `K` (EL, at offset 62) still counts and
    # is consumed silently.
    cfg = ('cmd e :echo "A\\033[' + '0;' * 30 + 'KB\\033[' + '0;' * 31 +
           'mC"\nmap e e\n')
    r = run_lf(files={"a": {}}, config=cfg, keys=[b"e"])
    msg = "AB\ufffd[" + "0;" * 31 + "mC"
    assert r.lines()[23] == _msg_row(msg)


def test_echo_broken_sequences(run_lf):
    """Malformed escapes surface as U+FFFD plus their literal bytes."""
    # CATCHES: ESC[Q (unsupported final), an unterminated OSC 8, an OSC
    # body too short to be a hyperlink ("]8" without the params) and a lone
    # trailing ESC all fail readTermSequence, so each ESC is replaced by
    # U+FFFD and the remaining bytes render as plain text.
    cfg = ('cmd e :echo "P\\033[Q Q\\033]8;;http://x R\\033]8 S\\033"\n'
           'map e e\n')
    r = run_lf(files={"a": {}}, config=cfg, keys=[b"e"])
    msg = "P\ufffd[Q Q\ufffd]8;;http://x R\ufffd]8 S\ufffd"
    assert r.lines()[23] == _msg_row(msg)


def test_control_char_filenames(run_lf):
    """Names with control or invalid-UTF-8 bytes list as U+FFFD escapes."""
    # CATCHES: sanitizeName replaces C0 controls (SOH, TAB, DEL, BEL), C1
    # bytes (U+0080) and invalid UTF-8 with U+FFFD, so a name carrying a
    # forged "\x1b[31m" cannot style the listing -- the ESC dies and only
    # the literal "[31mx" tail remains, in byte-sorted order.
    files = {b"bad\x01name": {"data": b""}, b"tab\tname": {"data": b""},
             b"del\x7fname": {"data": b""}, b"c1\xc2\x80name": {"data": b""},
             b"inv\xffname": {"data": b""}, b"esc\x1b[31mx": {"data": b""},
             b"bel\aend": {"data": b""}, b"plain": {"data": b""}}
    r = run_lf(files=files, cols=120)
    assert r.lines()[1:9] == [
        "  root                 bad\ufffdname",
        "                       bel\ufffdend",
        "                       c1\ufffdname",
        "                       del\ufffdname",
        "                       esc\ufffd[31mx",
        "                       inv\ufffdname",
        "                       plain",
        "                       tab\ufffdname",
    ]


def test_prompt_pwd_control_char_dir(run_lf):
    """The prompt path sanitizes a directory name with a control byte."""
    # CATCHES: %d expands the working directory through sanitizeName, so
    # entering a directory whose name holds a raw SOH shows U+FFFD in the
    # prompt instead of a control character corrupting the prompt row.
    r = run_lf(files={b"d\x01x/": {}, "a": {"data": b""}},
               config='set promptfmt "P=[%d]"\n', keys=[b"l"], cols=120)
    assert r.lines()[0] == "P=[%s/d\ufffdx/]" % r.root


def test_ruler_symlink_target_sanitized(run_lf):
    """A ruler template prints a sanitized symlink target and name."""
    # CATCHES: {{.Stat.Target}} and {{.Stat.Name}} pass through sanitizeName,
    # so a symlink whose raw target bytes contain SOH renders as "bad<U+FFFD>x"
    # in the ruler instead of leaking the control byte into the bottom line.
    r = run_lf(files={"a": {"data": b""}, b"lnk": {"link": b"bad\x01x"}},
               ruler="T=[{{.Stat.Target}}] N=[{{.Stat.Name}}]", keys=[b"G"])
    assert r.lines()[23] == "T=[bad\ufffdx] N=[lnk]"


def test_internal_preview_tab_and_controls(run_lf):
    """Internal previews kill escapes but keep tabs expanded to tabstops."""
    # CATCHES: sanitizePreview replaces BEL/ESC/VT with U+FFFD (so the SGR
    # in file content renders as dead text, never styling) while the TAB
    # survives and the renderer expands it to the next tabstop column --
    # the exact opposite of sanitizeName, which also kills tabs.
    r = run_lf(files={"p.txt": {"data": b"X\aY\x1b[31mZ\tW\x0bV"}})
    assert r.lines()[1] == ("  root          p.txt                    "
                            "X\ufffdY\ufffd[31mZ       W\ufffdV")


def test_previewer_sequence_rendering(run_lf):
    """Previewer output is rendered through the sequence-aware printer."""
    # CATCHES: with a previewer, output keeps working sequences -- the SGR
    # pair really colors "R" red and the EL is skipped -- while CSI finals
    # lf does not support (2J cursor-jump, G column set) turn into U+FFFD
    # followed by their literal parameter text inside the preview pane.
    def setup(base):
        prev = _script(base, "prev.sh",
                       '#!/bin/sh\nprintf "A\\033[2JB\\033[31mR\\033[0mC\\033[KD\\033[G E\\n"\n')
        return 'set previewer "%s"\n' % prev
    r = run_lf(files={"a.txt": {"data": b""}}, setup=setup)
    assert r.lines()[1] == ("  root          a.txt                    "
                            "A\ufffd[2JBRCD\ufffd[G E")
    assert r.screen.style(1, r.lines()[1].index("R")) == (1, None, ())


def test_previewer_hyperlink_invalid_utf8(run_lf):
    """OSC 8 hyperlinks from a previewer carry URL and id to the terminal."""
    # CATCHES: applyOSC consumes the hyperlink pair so only the label text
    # "INK" shows, tcell re-emits the URL and the id=x1 parameter in the raw
    # byte stream, and invalid UTF-8 (0xff) plus a C1 byte (U+0080) in the
    # output each collapse to U+FFFD in the preview pane.
    def setup(base):
        prev = _script(base, "prev.sh",
                       '#!/bin/sh\nprintf "L\\033]8;id=x1;http://ex.com/doc\\033\\\\INK'
                       '\\033]8;;\\033\\\\ tail\\377\\302\\200q\\n"\n')
        return 'set previewer "%s"\n' % prev
    r = run_lf(files={"a.txt": {"data": b""}}, setup=setup)
    assert r.lines()[1] == ("  root          a.txt                    "
                            "LINK tail\ufffd\ufffdq")
    raw = bytes(r.raw)
    assert b"http://ex.com/doc" in raw
    assert b"id=x1" in raw


def test_custominfo_sgr_cursor_strip(run_lf):
    """Custom info keeps its SGR off-cursor but is stripped on the cursor."""
    # CATCHES: a non-cursor row renders the custom info with its color (fg 1
    # on RED-INFO), while the cursor row prints the same column through
    # stripTermSequence -- plain text under the cursor format's reverse
    # video -- so a styled info string can never fight the cursor style.
    cfg = ('set info custom\n'
           'cmd ci addcustominfo a "\\033[31mRED-INFO\\033[0m"\n'
           'map X ci\n')
    files = {"a": {}, "b": {}, "c": {}}
    r = run_lf(files=files, config=cfg, keys=[b"X"])
    lines = r.lines()
    assert lines[1] == "  root          a              RED-INFO"
    assert lines[2] == "                b"
    assert r.screen.style(1, lines[1].index("RED")) == (None, None, ("reverse",))
    r2 = run_lf(files=files, config=cfg, keys=[b"X", b"j"])
    assert r2.lines()[1] == "  root          a              RED-INFO"
    assert r2.screen.style(1, r2.lines()[1].index("RED")) == (1, None, ())


def test_sortby_custom_strips_sequences(run_lf):
    """sortby custom orders by the info text with sequences stripped."""
    # CATCHES: sorting compares stripTermSequence(customInfo), so a's
    # "\033[31mzz\033[0m" sorts as plain "zz" and b's "aa" wins the top row;
    # the styled zz still renders red on the non-cursor row below it.
    cfg = ('set info custom\nset sortby custom\n'
           'cmd ca addcustominfo a "\\033[31mzz\\033[0m"\n'
           'cmd cb addcustominfo b "aa"\n'
           'map X ca\nmap Y cb\n')
    r = run_lf(files={"a": {}, "b": {}}, config=cfg, keys=[b"X", b"Y"])
    lines = r.lines()
    assert lines[1] == "  root          b                    aa"
    assert lines[2] == "                a                    zz"
    assert r.screen.style(2, lines[2].index("zz")) == (1, None, ())
    assert r.screen.style(1, lines[1].index("aa")) == (None, None, ("reverse",))


def test_cursorfmts_percent_s(run_lf):
    """cursorfmts containing %s wrap both the tag and the padded name."""
    # CATCHES: optionToFmtstr passes a format with %s through untouched, so
    # the cursor row renders the tag slot AND the space-padded name inside
    # the user's brackets ("[[a" .. "]") while plain rows stay unbracketed;
    # the parent pane gets its own "<%s>" wrap and the padded name of the
    # cursor row overflows into the preview pane's first columns.
    cfg = ('set cursoractivefmt "\\033[7m[%s]"\n'
           'set cursorparentfmt "<%s>"\n'
           'set cursorpreviewfmt "\\033[4m{%s}"\n')
    r = run_lf(files={"a/": {}, "b/": {}, "f.txt": {"data": b""}}, config=cfg)
    lines = r.lines()
    assert lines[1] == " <<root       >[[a                       ]empty"
    assert lines[2] == "                b"
    assert lines[3] == "                f.txt"
    assert r.screen.style(1, 3) == (4, None, ("bold",))
    assert r.screen.style(1, 17) == (4, None, ("bold", "reverse"))
    assert r.screen.style(1, 42) == (None, None, ("reverse",))
