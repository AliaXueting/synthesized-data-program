"""Directory listing rendering: number columns, info columns, indicators,
icons, colors, cursor formats and name truncation."""

import pytest


def _files(count):
    return {("f%02d" % i): {"data": b""} for i in range(count)}


def test_number_column(run_lf):
    """`set number` shows absolute 1-based line numbers for every entry."""
    # CATCHES: numbers are right-aligned in a fixed column at x=15 and are
    # yellow by default (numberfmt), while the cursor row name is reversed.
    r = run_lf(files=_files(12), config="set number\n", keys=[b"j", b"j", b"j"])
    lines = r.lines()
    assert lines[1] == "  root         1  f00"
    assert lines[2] == "               2  f01"
    assert lines[3] == "               3  f02"
    assert lines[4] == "               4  f03"
    assert lines[5] == "               5  f04"
    assert lines[6] == "               6  f05"
    assert lines[7] == "               7  f06"
    assert r.screen.style(4, 15) == (3, None, ())
    assert r.screen.style(4, 18) == (None, None, ("reverse",))


def test_relativenumber_column(run_lf):
    """`set relativenumber` shows distance from the cursor line."""
    # CATCHES: the cursor line itself shows 0 and neighbours count upwards
    # in both directions (3 2 1 0 1 2 3 around the 4th entry).
    r = run_lf(files=_files(12), config="set relativenumber\n",
               keys=[b"j", b"j", b"j"])
    lines = r.lines()
    assert lines[1] == "  root         3  f00"
    assert lines[2] == "               2  f01"
    assert lines[3] == "               1  f02"
    assert lines[4] == "               0  f03"
    assert lines[5] == "               1  f04"
    assert lines[6] == "               2  f05"
    assert lines[7] == "               3  f06"


def test_number_and_relativenumber(run_lf):
    """Both options together show the absolute number only on the cursor."""
    # CATCHES: with number+relativenumber the cursor row shows the absolute
    # index pushed one column right ("4   f03") while other rows stay
    # relative and aligned with the plain relativenumber layout.
    r = run_lf(files=_files(12), config="set number\nset relativenumber\n",
               keys=[b"j", b"j", b"j"])
    lines = r.lines()
    assert lines[1] == "  root         3  f00"
    assert lines[2] == "               2  f01"
    assert lines[3] == "               1  f02"
    assert lines[4] == "              4   f03"
    assert lines[5] == "               1  f04"
    assert lines[6] == "               2  f05"
    assert lines[7] == "               3  f06"


def test_numberfmt_numbercursorfmt_styles(run_lf):
    """numberfmt/numbercursorfmt restyle the number column per row type."""
    # CATCHES: numberfmt colors non-cursor numbers (here blue) and
    # numbercursorfmt overrides the number on the cursor row only.
    r = run_lf(files=_files(12),
               config=('set number\nset numberfmt "\\033[34m"\n'
                       'set numbercursorfmt "\\033[7;32m"\n'),
               keys=[b"j", b"j", b"j"])
    assert r.screen.style(3, 15) == (4, None, ())
    assert r.screen.style(4, 15) == (2, None, ("reverse",))
    assert r.screen.style(5, 15) == (4, None, ())


def test_numberfmt_prefix(run_lf):
    """numberfmt wraps the number with arbitrary text around %s."""
    # CATCHES: numberfmt is a full format string -- "N%s" prepends N before
    # every number, shifting the filename column right by one character.
    r = run_lf(files=_files(12), config='set number\nset numberfmt "N%s"\n',
               keys=[b"j", b"j"])
    lines = r.lines()
    assert lines[1] == "  root        N 1 f00"
    assert lines[2] == "              N 2 f01"
    assert lines[3] == "              N 3 f02"
    assert lines[4] == "              N 4 f03"
    assert lines[5] == "              N 5 f04"


def test_info_size_binary_units(run_lf):
    """info size renders humanized binary sizes; directories show a dash."""
    # CATCHES: sizes use binary units (2048 bytes -> 2.0K, 3 MiB -> 3.0M),
    # directories get "-" and the preview column still lines up after them.
    files = {"tiny": {"data": b"x"}, "k": {"data": b"a" * 2048},
             "m": {"data": b"a" * (3 * 1024 * 1024)}, "d/": {},
             "plain": {"data": b"y"}}
    r = run_lf(files=files, config="set info size\n", keys=[b"j", b"j"])
    lines = r.lines()
    assert lines[1] == ("  root          d                     -  "
                        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert lines[2] == ("                k                  2.0K  "
                        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert lines[3] == ("                m                  3.0M  "
                        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert lines[4] == ("                plain                1B  "
                        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert lines[5] == ("                tiny                 1B  "
                        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert lines[6] == ("                                         "
                        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")


def test_info_size_decimal_units(run_lf):
    """sizeunits decimal changes the divisor for humanized sizes."""
    # CATCHES: with `set sizeunits decimal` 3 MiB becomes 3.1M (10^6 base)
    # while small sizes keep their exact byte count.
    files = {"tiny": {"data": b"x"}, "k": {"data": b"a" * 2048},
             "m": {"data": b"a" * (3 * 1024 * 1024)}}
    r = run_lf(files=files, config="set info size\nset sizeunits decimal\n")
    lines = r.lines()
    assert lines[1] == ("  root          k                  2.0K  "
                        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert lines[2] == "                m                  3.1M"
    assert lines[3] == "                tiny                 1B"


def test_info_time_columns(run_lf):
    """info time right-aligns mtimes using the old-year time format."""
    # CATCHES: mtimes outside the current year render as "Mon DD  YYYY"
    # with the day-of-month zero padded to two columns.
    files = {"new": {"mtime": 1700000000}, "old": {"mtime": 1000000000}}
    r = run_lf(files=files, config="set info time\n", cols=120)
    lines = r.lines()
    assert lines[1] == "  root                 new                     Nov 14  2023"
    assert lines[2] == "                       old                     Sep  9  2001"


def test_info_perm_special_bits(run_lf):
    """info perm renders suid/sgid/sticky letters and symlink targets."""
    # CATCHES: setuid renders as "rws", setgid as "r-s", sticky as "r-t",
    # and a symlink to a directory shows the directory's drwxr-xr-x mode.
    files = {"d/": {}, "slink": {"link": "d"}, "suid": {"mode": 0o4755},
             "sgid": {"mode": 0o2755}, "sticky": {"mode": 0o1755},
             "plain": {"mode": 0o644}}
    r = run_lf(files=files, config="set info perm\n", cols=120)
    lines = r.lines()
    assert lines[1] == "  root                 d                         drwxr-xr-x   empty"
    assert lines[2] == "                       slink                     drwxr-xr-x"
    assert lines[3] == "                       plain                     -rw-r--r--"
    assert lines[4] == "                       sgid                      -rwxr-sr-x"
    assert lines[5] == "                       sticky                    -rwxr-xr-t"
    assert lines[6] == "                       suid                      -rwsr-xr-x"


def test_info_perm_user_group(run_lf):
    """info perm:user:group appends owner and group after the mode."""
    # CATCHES: the info column accepts a colon separated list and renders
    # each field left-aligned; symlinks resolve the target's owner/group.
    files = {"d/": {}, "slink": {"link": "d"}, "afile": {"mode": 0o644}}
    r = run_lf(files=files, config="set info perm:user:group\n", cols=160)
    lines = r.lines()
    assert lines[1] == ("  root                       d                             "
                        "drwxr-xr-x root root   empty")
    assert lines[2] == ("                             slink                         "
                        "drwxr-xr-x root root")
    assert lines[3] == ("                             afile                         "
                        "-rw-r--r-- root root")


def test_info_custom_column(run_lf):
    """`set info custom` shows per-file strings from addcustominfo."""
    # CATCHES: addcustominfo attaches arbitrary text that appears in the
    # info column only for the matching file; other rows stay blank.
    files = {"a": {}, "b": {}}
    r = run_lf(files=files, config="set info custom\n",
               keys=[b":", b"addcustominfo a XX-INFO", b"\r"])
    lines = r.lines()
    assert lines[1] == "  root          a               XX-INFO"
    assert lines[2] == "                b"
    assert r.screen.style(1, 16) == (None, None, ("reverse",))
    assert r.screen.style(2, 16) == (None, None, ())


@pytest.mark.parametrize("config,expected", [
    ("set info size\nset truncatepct 50\n", "  r~t    av~ame.txt"),
    ('set info size\nset truncatechar "…"\n', "  ro…    avery….txt"),
])
def test_truncation_options(run_lf, config, expected):
    """truncatepct and truncatechar change how overlong names are cut."""
    # CATCHES: truncatepct 50 keeps only half of each name ("r~t", "av~ame")
    # and truncatechar swaps the tilde for a real ellipsis character.
    files = {"averyveryverylongfilename.txt": {"data": b""},
             "short.txt": {"data": b""}}
    r = run_lf(files=files, config=config, cols=40)
    assert r.lines()[1] == expected


def test_cjk_filenames(run_lf):
    """Wide CJK filenames truncate by display width, not rune count."""
    # CATCHES: a 9-rune Japanese name occupying 18 columns is truncated to
    # "日本語のファ~.txt" (wide runes kept, tilde inserted) and still lines
    # up with the size column next to single-width names.
    files = {"ascii.txt": {"data": b""}, "日本語のファイル.txt": {"data": b""},
             "한국어1": {"data": b""}}
    r = run_lf(files=files, config="set info size\n")
    lines = r.lines()
    assert lines[1] == "  root          ascii.txt            0B"
    assert lines[2] == "                日本語のファ~.txt    0B"
    assert lines[3] == "                한국어1              0B"


def test_selectfmt_indicator(run_lf):
    """Selections paint the indicator column magenta+reverse."""
    # CATCHES: the selectfmt style lands only on the 2-column indicator at
    # x=14, leaving the filename unstyled; the cursor row keeps its own
    # reverse video on top of the selection marker.
    files = {"a": {}, "b": {}, "c": {}}
    r = run_lf(files=files, keys=[b" ", b"j", b" ", b"j"])
    lines = r.lines()
    assert lines[1] == "  root          a"
    assert lines[2] == "                b"
    assert lines[3] == "                c"
    assert r.screen.style(1, 14) == (5, None, ("reverse",))
    assert r.screen.style(1, 16) == (None, None, ())
    assert r.screen.style(3, 14) == (5, None, ("reverse",))
    assert r.screen.style(3, 16) == (None, None, ("reverse",))


@pytest.mark.parametrize("keys,cut_row", [
    ([b" ", b"y", b"d"], 2),
    ([b" ", b"j", b" ", b"y", b"G", b" ", b"d"], 4),
])
def test_copy_cut_indicator(run_lf, keys, cut_row):
    """cutfmt highlights the indicator; copied files show no styling."""
    # CATCHES: only the file under the cursor when `d` runs gets the red
    # reversed cut indicator; previously yanked (copy) files render plain,
    # showing that cut replaces the whole clipboard.
    files = {"a": {}, "b": {}, "c": {}, "d": {}}
    r = run_lf(files=files, keys=keys)
    lines = r.lines()
    assert lines[1] == "  root          a"
    assert lines[2] == "                b"
    assert lines[3] == "                c"
    assert lines[4] == "                d"
    assert r.screen.style(1, 14) == (None, None, ())
    assert r.screen.style(cut_row, 14) == (1, None, ("reverse",))
    assert r.screen.style(cut_row, 16) == (None, None, ("reverse",))


def test_mergeindicators(run_lf):
    """mergeindicators merges select/tag markers into the filename column."""
    # CATCHES: with mergeindicators the marker moves from the indicator
    # column onto the name ("*a") and keeps the selectfmt magenta style.
    files = {"a": {}, "b": {}, "c": {}}
    r = run_lf(files=files, config="set mergeindicators\n",
               keys=[b" ", b"j", b" ", b"j", b"t"])
    lines = r.lines()
    assert lines[1] == " root         *a"
    assert lines[2] == "               b"
    assert lines[3] == "              *c"
    star = lines[1].index("*")
    assert r.screen.style(1, star) == (5, None, ("reverse",))


def test_visual_mode_rows(run_lf):
    """Visual mode paints the indicator column cyan+reverse on the range."""
    # CATCHES: every row from the visual anchor to the cursor gets the
    # visualfmt-styled indicator at x=14, and the cursor row additionally
    # reverses the filename itself.
    files = {"a": {}, "b": {}, "c": {}, "d": {}}
    r = run_lf(files=files, keys=[b"V", b"j", b"j"])
    lines = r.lines()
    assert lines[1] == "  root          a"
    assert lines[2] == "                b"
    assert lines[3] == "                c"
    assert r.screen.style(1, 14) == (6, None, ("reverse",))
    assert r.screen.style(1, 16) == (None, None, ())
    assert r.screen.style(2, 14) == (6, None, ("reverse",))
    assert r.screen.style(3, 14) == (6, None, ("reverse",))
    assert r.screen.style(3, 16) == (None, None, ("reverse",))


def test_tag_marker(run_lf):
    """Tagged files show a red * which the cursor row absorbs into reverse."""
    # CATCHES: the tagfmt red asterisk sits immediately before the name on
    # plain rows, but on the cursor row the whole "*b" span goes reverse.
    files = {"a": {}, "b": {}}
    r = run_lf(files=files, keys=[b"t", b"j", b"t"])
    lines = r.lines()
    assert lines[1] == "  root         *a"
    assert lines[2] == "               *b"
    star = lines[1].index("*")
    assert r.screen.style(1, star) == (1, None, ())
    assert r.screen.style(2, lines[2].index("*")) == (None, None, ("reverse",))
    assert r.screen.style(2, 16) == (None, None, ("reverse",))


def test_icons_file(run_lf):
    """An icons file maps glob patterns to icon text and directory glyphs."""
    # CATCHES: icons add a glyph column before each name ("d" for dirs,
    # pattern-matched text for files) at every pane level, including the
    # parent pane; an unknown style token in the icons file is ignored.
    icons = "\n*.txt  txt  blue\n*.md   md\n"
    files = {"a.txt": {"data": b""}, "b.md": {"data": b""}, "c/": {}}
    r = run_lf(files=files, config="set icons\n", icons=icons)
    lines = r.lines()
    assert lines[1] == "  d root        d c                       empty"
    assert lines[2] == "                txt a.txt"
    assert lines[3] == "                md b.md"
    assert r.screen.style(2, 16) == (None, None, ())


def test_icon_styles(run_lf):
    """Icon style columns apply SGR only to non-cursor rows."""
    # CATCHES: the icon's style (bold green / underline) is dropped on the
    # cursor row, which shows the plain reversed row style instead.
    icons = "*.txt\tTXT\t01;32\n*.md\tMD\t04\n"
    files = {"a.txt": {"data": b""}, "b.txt": {"data": b""},
             "c.md": {"data": b""}}
    r = run_lf(files=files, config="set icons\n", icons=icons, keys=[b"j"])
    lines = r.lines()
    assert lines[1] == "  d root        TXT a.txt"
    assert lines[2] == "                TXT b.txt"
    assert lines[3] == "                MD c.md"
    assert r.screen.style(1, 16) == (2, None, ("bold",))
    assert r.screen.style(2, 16) == (None, None, ("reverse",))
    assert r.screen.style(3, 16) == (None, None, ("underline",))


def test_colors_file(run_lf):
    """A colors file applies SGR styles to matching filenames."""
    # CATCHES: colors entries style the whole filename cell (01;34 -> bold
    # blue) on non-cursor rows; the cursor row keeps its cursor style.
    colors = "\n*.txt 01;34\n*.md  31\n"
    files = {"a.txt": {"data": b""}, "b.md": {"data": b""}, "c/": {}}
    r = run_lf(files=files, colors=colors)
    lines = r.lines()
    assert lines[1] == "  root          c                         empty"
    assert lines[2] == "                a.txt"
    assert lines[3] == "                b.md"
    assert r.screen.style(2, 16) == (4, None, ("bold",))
    assert r.screen.style(3, 16) == (1, None, ())


def test_cursorfmts_custom(run_lf):
    """cursoractivefmt/parentfmt/previewfmt restyle the three cursor kinds."""
    # CATCHES: the active cursor gets the full custom SGR (fg+bg+attrs),
    # the parent cursor only its own fmt plus the directory color, and the
    # preview "empty" placeholder stays reversed regardless.
    files = {"a/": {}, "b/": {}, "f.txt": {"data": b""}}
    config = ('set cursoractivefmt "\\033[7;33;44m"\n'
              'set cursorparentfmt "\\033[1m"\n'
              'set cursorpreviewfmt "\\033[4;35m"\n')
    r = run_lf(files=files, config=config)
    lines = r.lines()
    assert lines[1] == "  root          a                         empty"
    assert lines[2] == "                b"
    assert lines[3] == "                f.txt"
    assert r.screen.style(1, 2) == (4, None, ("bold",))
    assert r.screen.style(1, 16) == (3, 4, ("bold", "reverse"))
    assert r.screen.style(1, 42) == (None, None, ("reverse",))
    assert r.screen.style(2, 16) == (4, None, ("bold",))
    assert r.screen.style(3, 16) == (None, None, ())


def test_cursorfmts_default(run_lf):
    """Default cursor formats: reverse everywhere the cursor lands."""
    # CATCHES: by default parent, active and dir-preview cursors are all
    # plain reverse video merged with the directory's blue+bold color.
    files = {"a/": {}, "b/": {}, "f.txt": {"data": b""}}
    r = run_lf(files=files)
    lines = r.lines()
    assert lines[1] == "  root          a                         empty"
    assert lines[2] == "                b"
    assert lines[3] == "                f.txt"
    assert lines[23] == ("drwxr-xr-x 2 root root  4.0K Sun Sep 13 12:26:40 2020"
                         "                        1/3")
    assert r.screen.style(1, 2) == (4, None, ("bold", "reverse"))
    assert r.screen.style(1, 16) == (4, None, ("bold", "reverse"))
    assert r.screen.style(1, 42) == (None, None, ("reverse",))
    assert r.screen.style(2, 16) == (4, None, ("bold",))
    assert r.screen.style(3, 16) == (None, None, ())
