"""Key and mouse input: mappings, counts, menus, command mode editing,
completion, history, bracketed paste, focus events and shell escapes."""

import pytest


def _files(count):
    return {("f%02d" % i): {"data": b""} for i in range(count)}


def _msg_row(msg):
    """A msg line: message, padding, counter right-aligned on an 80-col row."""
    return msg + " " * (77 - len(msg)) + "1/1"


@pytest.mark.parametrize("keys,expected", [
    (b"\x1a", "unknown mapping: <c-z>"),
    (b"\x1b[25~", "unknown mapping: <f-13>"),
])
def test_unknown_mapping(run_lf, keys, expected):
    """Unbound keys report themselves with lf's key syntax."""
    # CATCHES: control bytes are named <c-z> and unmapped CSI sequences
    # become <f-13> style function keys in the error message.
    r = run_lf(files={"a": {}}, keys=[keys])
    assert r.lines()[23] == _msg_row(expected)
    assert r.screen.style(23, 0) == (1, 7, ("reverse",))


def test_showbinds_menu(run_lf):
    """A partial multi-key binding pops the matching binds menu."""
    # CATCHES: after `g` the menu lists the remaining keys in two columns
    # ("key     command") and the pending key appears in the statline.
    r = run_lf(files={"a": {}}, keys=[b"g"])
    lines = r.lines()
    assert lines[20] == "key     command"
    assert lines[21] == "g       top"
    assert lines[22] == "h       cd ~"
    assert lines[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                         "                     g  1/1")


def test_showbinds_disabled(run_lf):
    """`set showbinds false` suppresses the binds menu entirely."""
    # CATCHES: the pending `g` still shows in the statline corner even
    # though no menu rows are drawn.
    r = run_lf(files={"a": {}}, config="set showbinds false\n", keys=[b"g"])
    lines = r.lines()
    assert lines[20] == ""
    assert lines[21] == ""
    assert lines[22] == ""
    assert lines[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                         "                     g  1/1")


def test_showbinds_esc_clears(run_lf):
    """Escape aborts the pending key sequence and clears the menu."""
    # CATCHES: after g + Esc the menu rows vanish and the statline loses
    # the pending-key marker, returning to the plain 1/1 counter.
    r = run_lf(files={"a": {}}, keys=[b"g", b"\x1b"])
    lines = r.lines()
    assert lines[21] == ""
    assert lines[22] == ""
    assert lines[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                         "                        1/1")


def test_multibind_menu(run_lf):
    """User-defined multi-key maps appear in the binds menu."""
    # CATCHES: custom `map xy` bindings show their expansion as a shell
    # template (":{{ echo XY-BOUND; }}") sorted by the next key.
    config = "map xy :echo XY-BOUND\nmap xj :echo XJ-BOUND\n"
    r = run_lf(files=_files(5), config=config, keys=[b"x"])
    lines = r.lines()
    assert lines[20] == "key     command"
    assert lines[21] == "j       :{{ echo XJ-BOUND; }}"
    assert lines[22] == "y       :{{ echo XY-BOUND; }}"
    assert lines[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                         "                     x  1/5")


@pytest.mark.parametrize("second,expected", [
    (b"y", "XY-BOUND"),
    (b"z", "unknown mapping: xz"),
])
def test_multibind_execute(run_lf, second, expected):
    """Completing or breaking a multi-key map runs it or errors."""
    # CATCHES: the full sequence xy executes the bound command, while an
    # impossible continuation reports the whole typed sequence "xz".
    config = "map xy :echo XY-BOUND\nmap xj :echo XJ-BOUND\n"
    r = run_lf(files=_files(5), config=config, keys=[b"x", second])
    assert r.lines()[23] == _msg_row(expected).replace("1/1", "1/5")


@pytest.mark.parametrize("keys,cursor_line,expected_count", [
    ([b"5", b"j"], 6, "6/10"),
    ([b"0", b"j"], 2, "2/10"),
])
def test_count_prefix(run_lf, keys, cursor_line, expected_count):
    """Numeric prefixes multiply movement commands."""
    # CATCHES: 5j moves five entries down, while a leading 0 is treated
    # as no count at all (a single step to the second entry).
    r = run_lf(files=_files(10), keys=keys)
    lines = r.lines()
    assert lines[1] == "  root          f00"
    assert lines[cursor_line] == "                f%02d" % (cursor_line - 1)
    assert lines[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                         "                       " + expected_count)


ENV_CFG = ("cmd showenv %echo w=$lf_width h=$lf_height m=$lf_mode c=$lf_count\n"
           "map x showenv\nvmap x showenv\nset user_x userval\n"
           "cmd showuser %echo u=$lf_user_x\nmap z showuser\n")


@pytest.mark.parametrize("keys,expected", [
    ([b"x"], "w=80 h=24 m=normal c=1"),
    ([b"7", b"x"], "w=80 h=24 m=normal c=7"),
    ([b"z"], "u=userval"),
])
def test_shell_env_exports(run_lf, keys, expected):
    """Shell commands see terminal size, mode, count and user options."""
    # CATCHES: %echo commands export lf_width/lf_height/lf_mode, the typed
    # count (default 1), and every `set user_*` option as lf_user_*.
    r = run_lf(files={"a": {}}, config=ENV_CFG, keys=keys)
    assert r.lines()[23] == _msg_row(expected)


def test_shell_env_exports_visual(run_lf):
    """lf_mode switches to visual for commands run from visual mode."""
    # CATCHES: in visual mode the statline also grows a selection-count
    # column ("1   1/1") next to the index counter.
    r = run_lf(files={"a": {}}, config=ENV_CFG, keys=[b"V", b"x"])
    row = r.lines()[23]
    assert row == ("w=80 h=24 m=visual c=1" + " " * 51 + "1   1/1")
    assert len(row) == 80


KEY_CFG = ("map <f-5> :echo F5-BOUND\nmap <c-x> :echo CX-BOUND\n"
           "map <a-x> :echo AX-BOUND\nmap <lt> :echo LT-BOUND\n"
           "map <s-x> :echo SX-BOUND\n")


@pytest.mark.parametrize("keys,expected", [
    (b"\x1b[15~", "F5-BOUND"),
    (b"\x18", "CX-BOUND"),
    (b"\x1bx", "AX-BOUND"),
    (b"<", "LT-BOUND"),
    (b"X", "unknown mapping: X"),
])
def test_special_key_names(run_lf, keys, expected):
    """Function/ctrl/alt/lt keys map via lf's named key syntax."""
    # CATCHES: <f-5> is the CSI ~ sequence, <a-x> is ESC-prefixed x, and
    # a capital X does NOT trigger <s-x> -- it is simply unmapped.
    r = run_lf(files={"a": {}}, config=KEY_CFG, keys=[keys])
    assert r.lines()[23] == _msg_row(expected)


def test_cmap_insert(run_lf):
    """cmap binds keys inside the command-line prompt."""
    # CATCHES: cmap <c-x> cmd-insert types the bound text straight into
    # the prompt at the cursor position.
    r = run_lf(files={"a": {}}, config="cmap <c-x> cmd-insert INSERTED\n",
               keys=[b":", b"echo hi", b"\x18"])
    assert r.lines()[23] == ":echo hiINSERTED"


@pytest.mark.parametrize("keys,expected", [
    ([b":"], ":"),
    ([b"$"], "$"),
    ([b"%"], "%"),
    ([b"!"], "!"),
    ([b"&"], "&"),
    ([b":", b"echo hi"], ":echo hi"),
])
def test_cmd_prompt_prefixes(run_lf, keys, expected):
    """Each command-mode prefix key opens its prompt character."""
    # CATCHES: the prompt shows just the prefix and typed text echoes
    # after it on the msg line with no other decoration.
    r = run_lf(files={"a": {}}, keys=keys)
    assert r.lines()[23] == expected


@pytest.mark.parametrize("keys,expected", [
    ([b":", b"echo hello world", b"\x7f\x7f\x7f"], ":echo hello wo"),
    ([b":", b"echo hello", b"\x15"], ":"),
    ([b":", b"echo hello world", b"\x17"], ":echo hello"),
    ([b":", b"echo hello world", b"\x1b[1~", b"X"], ":Xecho hello world"),
    ([b":", b"echo hello", b"\x1b[1;5D", b"Z"], ":echo helloZ"),
])
def test_cmd_line_editing(run_lf, keys, expected):
    """Command-mode editing keys: backspace, kill line/word, cursor moves."""
    # CATCHES: ctrl-u wipes the whole line (prompt stays), ctrl-w kills
    # back to the word start, Home jumps to column 0, and ctrl-left moves
    # by words so Z inserts at the previous word boundary.
    r = run_lf(files={"a": {}}, keys=keys)
    assert r.lines()[23] == expected


def test_completion_menu(run_lf):
    """Tab completion lists matching `set` options in a menu."""
    # CATCHES: the header "possible matches" is bold while the option
    # rows are plain, and the prompt keeps the typed prefix ":set t".
    r = run_lf(files={"a": {}}, keys=[b":", b"set t", b"\t"])
    lines = r.lines()
    assert lines[20] == "possible matches"
    assert lines[21] == ("tabstop         tagfmt          tempmarks       "
                         "terminalcursor  timefmt")
    assert lines[22] == "truncatechar    truncatepct"
    assert lines[23] == ":set t"
    assert r.screen.style(20, 0) == (None, None, ("bold",))
    assert r.screen.style(21, 0) == (None, None, ())


def test_completion_menufmt(run_lf):
    """menufmt/menuheaderfmt restyle the completion menu rows."""
    # CATCHES: menuheaderfmt colors only the header line and menufmt the
    # match rows, here blue header and green options.
    r = run_lf(files={"a": {}},
               config='set menufmt "\\033[32m"\nset menuheaderfmt "\\033[34m"\n',
               keys=[b":", b"set t", b"\t"])
    assert r.screen.style(20, 0) == (4, None, ())
    assert r.screen.style(21, 0) == (2, None, ())


def test_marks_menu(run_lf):
    """The mark-load menu shows a mark/path table with no marks set."""
    # CATCHES: the menu renders "mark    path" as its header and the
    # mark-load prompt with an empty mark name on the msg line.
    r = run_lf(files={"a": {}}, keys=[b"'"])
    lines = r.lines()
    assert lines[20] == ""
    assert lines[21] == ""
    assert lines[22] == "mark    path"
    assert lines[23] == "mark-load:"


@pytest.mark.parametrize("ups,expected", [
    (1, ":echo two"),
    (2, ":echo one"),
])
def test_cmd_history(run_lf, ups, expected):
    """Up-arrow walks the command history newest first."""
    # CATCHES: history is per-session and ordered, so one up-arrow shows
    # the last command and a second one reaches back further.
    keys = [b":", b"echo one", b"\r", b":", b"echo two", b"\r", b":"]
    keys += [b"\x1b[A"] * ups
    r = run_lf(files={"a": {}}, keys=keys)
    assert r.lines()[23] == expected


MOUSE_CFG = ("map <m-1> :echo M1\nmap <m-2> :echo M2\nmap <m-3> :echo M3\n"
             "map <m-4> :echo M4\nmap <m-5> :echo M5\n")


@pytest.mark.parametrize("code,expected", [
    (0, "M1"),
    (1, "M3"),
    (2, "M2"),
    (3, None),
])
def test_mouse_buttons(run_lf, code, expected):
    """SGR mouse buttons map to <m-N> bindings by button number."""
    # CATCHES: SGR button codes 0/1/2 map to <m-1>/<m-3>/<m-2> (the xterm
    # button numbering differs from lf's), and a release event (3) runs
    # nothing, leaving the plain statline.
    r = run_lf(files=_files(8), config="set mouse\n" + MOUSE_CFG,
               keys=[b"\x1b[<%d;20;3M" % code])
    row = r.lines()[23]
    if expected is None:
        assert row == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                       "                        1/8")
    else:
        assert row == _msg_row(expected).replace("1/1", "1/8")


@pytest.mark.parametrize("code,expected_count", [
    (64, "1/8"),
    (65, "2/8"),
])
def test_mouse_wheel(run_lf, code, expected_count):
    """Wheel events scroll the listing; wheel-down moves the cursor."""
    # CATCHES: SGR code 65 (wheel down) advances the selection to 2/8
    # while code 64 (wheel up) stays put at the first entry.
    r = run_lf(files=_files(8), config="set mouse\n" + MOUSE_CFG,
               keys=[b"\x1b[<%d;20;3M" % code])
    assert r.lines()[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40"
                             " 2020                        " + expected_count)


def test_mouse_click_moves_cursor(run_lf):
    """With mouse on and no <m-1> map, a click moves the cursor there."""
    # CATCHES: a press-only SGR click at row 5 selects the 4th entry
    # (4/10) -- the click-to-move behavior only applies when the button
    # is not user-bound.
    r = run_lf(files=_files(10), config="set mouse\n",
               keys=[b"\x1b[<0;20;5M"])
    lines = r.lines()
    assert lines[1] == "  root          f00"
    assert lines[5] == "                f04"
    assert lines[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                         "                       4/10")


def test_mouse_events_without_mouse_option(run_lf):
    """<m-N> mappings fire even without `set mouse`."""
    # CATCHES: lf parses SGR mouse sequences regardless of the mouse
    # option, so the mapped command runs with `set mouse` never issued.
    r = run_lf(files=_files(8), config=MOUSE_CFG, keys=[b"\x1b[<0;20;3M"])
    assert r.lines()[23] == _msg_row("M1").replace("1/1", "1/8")


def test_bracketed_paste_ignored(run_lf):
    """Bracketed paste payloads are swallowed in normal mode."""
    # CATCHES: the pasted bytes inside 200~/201~ do not run as keys, so
    # the cursor stays on the first entry (1/5).
    r = run_lf(files=_files(5), keys=[b"\x1b[200~jj\x1b[201~"])
    lines = r.lines()
    assert lines[1] == "  root          f00"
    assert lines[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                         "                        1/5")


def test_keys_after_paste(run_lf):
    """Keys sent after a paste sequence still work normally."""
    # CATCHES: the paste terminator restores normal processing, so a
    # following plain `j` moves the cursor (2/5).
    r = run_lf(files=_files(5),
               keys=[b"\x1b[200~j\x1b[201~", b"j"])
    assert r.lines()[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40"
                             " 2020                        2/5")


@pytest.mark.parametrize("keys,expected", [
    (b"\x1b[I", "FOCUS-GAINED"),
    (b"\x1b[O", "FOCUS-LOST"),
])
def test_focus_events(run_lf, keys, expected):
    """Focus in/out CSI sequences trigger the focus hooks."""
    # CATCHES: ESC[I / ESC[O are delivered as on-focus-gained/lost
    # commands, not as unknown mappings.
    config = ("cmd on-focus-gained %echo FOCUS-GAINED\n"
              "cmd on-focus-lost %echo FOCUS-LOST\n")
    r = run_lf(files={"a": {}}, config=config, keys=[keys])
    assert r.lines()[23] == _msg_row(expected)


def test_shell_wait_and_async(run_lf):
    """`!` suspends the UI for the command; `&` runs it asynchronously."""
    # CATCHES: the shell-wait output is streamed to the terminal (visible
    # in the raw bytes) and after dismissing it the statline is restored,
    # while the async command output arrives without suspending.
    r = run_lf(files={"a": {}},
               keys=[b"!", b"printf SW1", b"\r", b"k", b"&", b"printf AS1", b"\r"])
    assert r.lines()[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40"
                             " 2020                        1/1")
    raw = bytes(r.raw)
    assert b"SW1" in raw
    assert b"AS1" in raw
