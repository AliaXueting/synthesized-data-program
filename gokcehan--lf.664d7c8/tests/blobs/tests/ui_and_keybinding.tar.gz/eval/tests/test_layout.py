"""Window layout: pane widths (ratios), borders, drawbox, resize, truncation.

Every expectation in this file was recorded by running the reference binary
through the same pty harness and copying the rendered rows verbatim.
"""

import pytest

# file tree used by the ratios tests (Q1-Q4 recordings)
RAT_FILES = {"a/": {}, "b/": {}, "c/": {}, "f.txt": {"data": b"PREVIEW-TEXT\n"}}

# recorded at 40 columns for the default truncatepct (probe_a)
NARROW_FILES = {"averyveryverylongfilename.txt": {"data": b""},
                "short.txt": {"data": b""}}


def test_default_pane_layout(run_lf):
    """Default 1:2:3 ratios give parent/cwd/preview panes at fixed columns."""
    # CATCHES: pane contents start at columns 2/16/42 and the statline keeps
    # the 1-based "cursor/total" counter right-aligned on the last row.
    files = {"alpha.txt": {"data": b"hello\n"}, "beta/": {},
             "gamma.md": {"data": b"x"}, "with space.txt": {"data": b""}}
    r = run_lf(files=files, keys=[b"j"])
    lines = r.lines()
    assert lines[1] == "  root          beta                     hello"
    assert lines[2] == "                alpha.txt"
    assert lines[3] == "                gamma.md"
    assert lines[4] == "                with space.txt"
    assert lines[23] == ("-rw-r--r-- 1 root root    6B Sun Sep 13 12:26:40 2020"
                         "                        2/4")
    # parent dir entry is blue+bold+reversed, plain dir entries blue+bold,
    # the active cursor row reversed, the preview unstyled
    assert r.screen.style(1, 2) == (4, None, ("bold", "reverse"))
    assert r.screen.style(1, 16) == (4, None, ("bold",))
    assert r.screen.style(1, 42) == (None, None, ())
    assert r.screen.style(2, 16) == (None, None, ("reverse",))


@pytest.mark.parametrize("config,expected", [
    ("set ratios 1:1:1\n",
     ["  a                         empty",
      "  b",
      "  c",
      "  f.txt"]),
    ("set ratios 1:1:1:1\n",
     ["  root                a                   empty",
      "                      b",
      "                      c",
      "                      f.txt"]),
])
def test_ratios_colon_syntax(run_lf, config, expected):
    """`set ratios` takes colon-separated values and redraws pane columns."""
    # CATCHES: ratios must be colon separated; 1:1:1 makes three equal panes
    # (contents at columns 2/28/54) while 1:1:1:1 adds a fourth pane.
    r = run_lf(files=dict(RAT_FILES), config=config, keys=[b"j", b"l", b"j", b"l"])
    lines = r.lines()
    for i, row in enumerate(expected):
        assert lines[i + 1] == row
    # empty cwd after the last `l` leaves a 0/0 counter right-aligned
    assert lines[23] == "                                                                             0/0"


@pytest.mark.parametrize("config,expected", [
    ("set ratios 1:1:1\nset drawbox\n",
     ["┌─────────────────────────┬──────────────────────────┬─────────────────────────┐",
      "│  a                      │ empty                    │                         │",
      "│  b                      │                          │                         │",
      "│  c                      │                          │                         │",
      "│  f.txt                  │                          │                         │"]),
    ("set ratios 1:1:1:1\nset drawbox\n",
     ["┌───────────────────┬───────────────────┬──────────────────┬───────────────────┐",
      "│  root             │  a                │ empty            │                   │",
      "│                   │  b                │                  │                   │",
      "│                   │  c                │                  │                   │",
      "│                   │  f.txt            │                  │                   │"]),
])
def test_ratios_with_drawbox(run_lf, config, expected):
    """drawbox draws a border row plus per-pane separators around each pane."""
    # CATCHES: with drawbox the top border uses ┌/┬/┐ corners and every pane
    # gets its own │ separator; empty dirs still show "empty" inside the box.
    r = run_lf(files=dict(RAT_FILES), config=config, keys=[b"j", b"l", b"j", b"l"])
    lines = r.lines()
    for i, row in enumerate(expected):
        assert lines[i + 1] == row
    assert lines[23] == "                                                                             0/0"


def test_ratios_space_syntax_rejected(run_lf):
    """Space-separated ratios values are unknown commands; defaults survive."""
    # CATCHES: `set ratios 1 1 1` only parses the first number and reports
    # "command not found: 1" for the rest while keeping the default layout.
    files = {"a/": {}, "b/": {}}
    r = run_lf(files=files, config="set ratios 1 1 1\n")
    assert r.lines()[23] == ("command not found: 1"
                             "                                                         1/2")
    r2 = run_lf(files=dict(RAT_FILES), config="set ratios 1 1 1\n",
                keys=[b"j", b"l", b"j", b"l"])
    lines = r2.lines()
    assert lines[1] == "  a            empty"
    assert lines[2] == "  b"
    assert lines[3] == "  c"
    assert lines[4] == "  f.txt"


def test_preview_false_panes(run_lf):
    """With preview off the last pane becomes a directory listing."""
    # CATCHES: `set preview false` replaces the preview pane with the next
    # directory in the chain, so an empty dir shows "empty" as a pane body.
    files = {"d/": {}, "e/": {}, "f.txt": {"data": b"P\n"}}
    r = run_lf(files=files, config="set preview false\n", keys=[b"j", b"l"])
    lines = r.lines()
    assert lines[1] == "  root          d                         empty"
    assert lines[2] == "                e"
    assert lines[3] == "                f.txt"
    assert lines[23] == "                                                                             0/0"


def test_resize_relayout(run_lf):
    """A SIGWINCH resize to 40x20 reflows panes and re-truncates everything."""
    # CATCHES: after resizing the parent pane shrinks to 6 columns ("ro~"),
    # the statline is cut mid-timestamp at exactly 40 chars and "empty"
    # moves to column 25 in the narrowed preview pane.
    files = {"a": {"data": b""}, "b/": {}, "c.txt": {"data": b"P\n"}}
    r = run_lf(files=files)
    r.resize(20, 40)
    lines = r.lines()
    assert lines[1] == "  ro~    b            empty"
    assert lines[2] == "         a"
    assert lines[3] == "         c.txt"
    assert lines[19] == "drwxr-xr-x 2 root root  4.0K Sun Se  1/3"
    assert len(lines[19]) == 40


@pytest.mark.parametrize("config,files,expected", [
    ("set drawbox\n", {"a": {}, "b/": {}, "c.txt": {}},
     ["┌─────────────┬─────────────────────────┬──────────────────────────────────────┐",
      "│  root       │  b                      │ empty                                │",
      "│             │  a                      │                                      │"]),
    ("set drawbox\nset borderstyle roundbox\n", {"a": {}, "b/": {}},
     ["╭─────────────┬─────────────────────────┬──────────────────────────────────────╮",
      "│  root       │  b                      │ empty                                │",
      "│             │  a                      │                                      │"]),
    ("set drawbox\nset borderstyle outline\n", {"a": {}, "b/": {}},
     ["┌──────────────────────────────────────────────────────────────────────────────┐",
      "│  root          b                        empty                                │",
      "│                a                                                             │"]),
    ("set drawbox\nset borderstyle separators\n", {"a": {}, "b/": {}},
     ["  root       │  b                       │ empty",
      "             │  a                       │",
      "             │                          │"]),
    ("set drawbox\nset borderstyle roundoutline\n", {"a": {}, "b/": {}},
     ["╭──────────────────────────────────────────────────────────────────────────────╮",
      "│  root          b                        empty                                │",
      "│                a                                                             │"]),
])
def test_borderstyle_variants(run_lf, config, files, expected):
    """borderstyle picks which box characters frame the window."""
    # CATCHES: box draws separators+frame, roundbox swaps corners for ╭╮,
    # outline/roundoutline drop separators keeping one frame, and separators
    # draws only the pane dividers with no outer frame at all.
    r = run_lf(files=dict(files), config=config)
    lines = r.lines()
    for i, row in enumerate(expected):
        assert lines[i + 1] == row


def test_drawbox_full_frame(run_lf):
    """The full drawbox frame plus the styled directory-mode statline."""
    # CATCHES: default drawbox paints └┴┘ on the second-to-last row and the
    # statline permission block stays cyan while the border stays unstyled.
    files = {"a": {}, "b/": {}, "c.txt": {}}
    r = run_lf(files=files, config="set drawbox\n")
    lines = r.lines()
    assert lines[1] == ("┌─────────────┬─────────────────────────"
                        "┬──────────────────────────────────────┐")
    assert lines[22] == ("└─────────────┴─────────────────────────"
                         "┴──────────────────────────────────────┘")
    assert lines[23] == ("drwxr-xr-x 2 root root  4.0K Sun Sep 13 12:26:40 2020"
                         "                        1/3")
    assert r.screen.style(2, 0) == (None, None, ())
    assert r.screen.style(2, 3) == (4, None, ("bold", "reverse"))
    assert r.screen.style(2, 17) == (4, None, ("bold", "reverse"))
    assert r.screen.style(2, 42) == (None, None, ("reverse",))
    assert r.screen.style(23, 0) == (6, None, ())


def test_borderfmt_colors_frame(run_lf):
    """borderfmt recolors every border cell, including pane separators."""
    # CATCHES: borderfmt applies to the whole frame row, so even the middle
    # separator column at x=40 turns magenta while pane content is untouched.
    files = {"a": {}, "b/": {}, "c.txt": {}}
    r = run_lf(files=files,
               config='set drawbox\nset borderfmt "\\033[35m"\n')
    lines = r.lines()
    assert lines[1] == ("┌─────────────┬─────────────────────────"
                        "┬──────────────────────────────────────┐")
    assert r.screen.style(1, 0) == (5, None, ())
    assert r.screen.style(1, 40) == (5, None, ())
    assert r.screen.style(1, 79) == (5, None, ())
    assert r.screen.style(2, 3) == (4, None, ("bold", "reverse"))
    assert lines[23] == ("drwxr-xr-x 2 root root  4.0K Sun Sep 13 12:26:40 2020"
                         "                        1/3")


def test_borderstyle_without_drawbox(run_lf):
    """borderstyle alone draws nothing until drawbox is enabled."""
    # CATCHES: `set borderstyle separators` without `set drawbox` renders a
    # completely plain layout -- drawbox is the master switch for borders.
    files = {"a/": {}, "b/": {}}
    r = run_lf(files=files, config="set borderstyle separators\n")
    lines = r.lines()
    assert lines[1] == "  root          a                         empty"
    assert lines[2] == "                b"


def test_narrow_pane_name_truncation(run_lf):
    """At 40 columns long names truncate with ~ and keep the extension."""
    # CATCHES: the parent pane name truncates to "ro~" and a long filename
    # becomes "avery~.txt" -- the extension always survives truncation.
    r = run_lf(files=dict(NARROW_FILES), config="set info size\n", cols=40)
    lines = r.lines()
    assert lines[1] == "  ro~    avery~.txt"
    assert lines[2] == "         short.txt"
