"""Prompt line rendering (promptfmt placeholders, home shortening, spacers).

All expected rows were recorded from the reference binary; path-dependent
expectations are computed from the fixture root at runtime.
"""

import pytest


def test_default_prompt_format(run_lf):
    """Default prompt is user@host:pwd/basename-of-selection."""
    # CATCHES: %u comes from the passwd database ("root"), the hostname is
    # the machine name, and the prompt appends the current file's basename.
    files = {"alpha-long.txt": {"data": b""}, "beta.md": {"data": b""}}
    r = run_lf(files=files)
    row = r.lines()[0]
    assert row.startswith("root@DataResearch:")
    assert row.endswith("/alpha-long.txt")


def test_promptfmt_placeholders(run_lf):
    """%u/%f/%F expand to user, selection basename and active filter."""
    # CATCHES: %f is empty-safe (no selection -> empty) and %F renders the
    # filter wrapped in double brackets only while a filter is active.
    files = {"alpha.txt": {"data": b""}, "beta.md": {"data": b""},
             "gamma.txt": {"data": b""}}
    r = run_lf(files=files, config='set promptfmt "u=[%u] f=[%f] F=[%F]"\n')
    assert r.lines()[0] == "u=[root] f=[alpha.txt] F=[]"


def test_promptfmt_filter_placeholder(run_lf):
    """After setfilter the prompt shows the filter and the pane re-filters."""
    # CATCHES: `setfilter beta` updates %F to [[beta]], narrows the listing
    # to beta.md and the statline gains the filter name before the counter.
    files = {"alpha.txt": {"data": b""}, "beta.md": {"data": b""},
             "gamma.txt": {"data": b""}}
    r = run_lf(files=files, config='set promptfmt "u=[%u] f=[%f] F=[%F]"\n',
               keys=[b":", b"setfilter beta", b"\r"])
    lines = r.lines()
    assert lines[0] == "u=[root] f=[beta.md] F=[[beta]]"
    assert lines[1] == "  root          beta.md"
    assert lines[2] == ""
    assert lines[3] == ""
    assert lines[23] == ("-rw-r--r-- 1 root root    0B Sun Sep 13 12:26:40 2020"
                         "                 beta   1/1")


@pytest.mark.parametrize("fmt,suffix", [
    ("WONLY=%w", "/a"),
    ("DONLY=%d", "/a/"),
])
def test_prompt_pwd_placeholders(run_lf, fmt, suffix):
    """%w is the working directory and %d the same path with a trailing /."""
    # CATCHES: %w and %d print the absolute fixture path, and %d always
    # appends a trailing separator even for nested directories.
    files = {"a/": {}, "x.txt": {"data": b""}}
    r = run_lf(files=files, config='set promptfmt "%s"\n' % fmt,
               keys=[b"l"], cols=120)
    assert r.lines()[0] == fmt.replace("%w", r.root + suffix).replace("%d", r.root + suffix)


def test_prompt_in_empty_dir(run_lf):
    """In an empty directory %f is empty and the pane shows "empty"."""
    # CATCHES: the pane body for an empty directory is the word "empty" at
    # column 15, and the parent pane truncates its name to "empty-dir~".
    files = {"empty-dirname/": {}, "zzz.txt": {"data": b""}}
    r = run_lf(files=files, config='set promptfmt "N=[%f] %d"\n', keys=[b"l"])
    lines = r.lines()
    assert lines[1] == "  empty-dir~   empty"
    assert lines[2] == "  zzz.txt"
    r2 = run_lf(files=files, config='set promptfmt "N=[%f] %d"\n',
                keys=[b"l"], cols=120)
    assert r2.lines()[0] == "N=[] %s/empty-dirname/" % r2.root


def test_prompt_home_shortening(run_lf):
    """Paths under the home directory are shortened with ~ (gh binding)."""
    # CATCHES: after `gh` (cd ~) both %w and %d use the tilde abbreviation,
    # and %d keeps its trailing slash after shortening.
    r = run_lf(files={"a": {"data": b""}}, config='set promptfmt "HOMEW=%w HOMED=%d"\n',
               keys=[b"g", b"h"])
    assert r.lines()[0] == "HOMEW=~ HOMED=~/"


def test_prompt_spacer(run_lf):
    """%S expands to whatever space is left on the prompt row."""
    # CATCHES: %S absorbs the remaining width exactly, so the fixed parts
    # "SPACERMARK" and "-END" end up flush with both window edges.
    r = run_lf(files={"a": {"data": b""}}, config='set promptfmt "SPACERMARK%S-END"\n')
    row = r.lines()[0]
    assert row == "SPACERMARK" + " " * 66 + "-END"
    assert len(row) == 80


def test_prompt_truncation_narrow(run_lf):
    """An over-long prompt shortens path components to their first letter."""
    # CATCHES: when the prompt exceeds the width each path component is
    # replaced by its first rune (left to right) until it fits, then the
    # row is cut at exactly the terminal width.
    files = {"averyveryverylongfilename.txt": {"data": b""},
             "short.txt": {"data": b""}}
    r = run_lf(files=files, cols=40)
    lines = r.lines()
    shortened = "/" + "/".join(p[:1] for p in r.root.strip("/").split("/"))
    expected = ("root@DataResearch:" + shortened +
                "/averyveryverylongfilename.txt")[:40]
    assert lines[0] == expected
    assert len(lines[0]) == 40
    # exact anchors that hold for any fixture depth: the first components
    # shrink to single letters while the file name stays unshortened and
    # the row is cut mid-name at the terminal edge
    assert lines[0].startswith("root@DataResearch:/t/p/p/")
    assert "/averyve" in lines[0]
    assert lines[1] == "  ro~    avery~.txt"
    assert lines[2] == "         short.txt"
