"""Black-box pty harness for the lf terminal file manager (ui_and_keybinding).

lf is a full-screen TUI: it draws everything (panes, borders, prompt, ruler,
preview, menus) with ANSI escape sequences on the terminal.  The harness boots
the reference binary behind a pseudo terminal with a fully pinned environment,
feeds every byte the process writes into a small VT100/xterm screen emulator,
and exposes the resulting cell grid (row text plus per-cell SGR style) so the
tests can assert on what a user would actually see.

Timing notes (observed on the reference binary): tcell's terminal capability
queries (DA1/DECRQM/XTGETTCAP) block for exactly 1.00s at startup when nothing
answers them, so the first draw lands at ~1.0s; the quiet-wait below therefore
enforces a minimum startup duration before snapshotting the screen.  lf draws
one frame before its config and directory listings are loaded; under load that
first frame can be followed by a silence longer than the settle window, so the
harness additionally forces <c-l> redraws until the screen stops changing (the
redraw event is only processed once the config has been read, which guarantees
the snapshot reflects the fully initialized UI).
"""

import fcntl
import os
import pty
import select
import signal
import struct
import termios
import time
import unicodedata

import pytest

# Fixed timestamp used for every fixture file so stat/time columns and the
# statfmt/ruler output are byte-for-byte reproducible (2020-09-13 12:26:40 UTC).
T0 = 1600000000

# lf only formats times of the current year with infotimefmtnew, everything
# older with infotimefmtold; T0 is deliberately in the past so the "old" branch
# is the deterministic one.


def _rune_width(ch):
    """Terminal cell width of a rune (East Asian Wide/Fullwidth -> 2)."""
    if unicodedata.combining(ch):
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    return 1


class Cell:
    __slots__ = ("ch", "fg", "bg", "attrs")

    def __init__(self):
        self.ch = " "
        self.fg = None
        self.bg = None
        self.attrs = frozenset()


class Screen:
    """A minimal VT100/xterm screen emulator (text + SGR style per cell).

    Handles the subset of control sequences lf/tcell emits: CUP, CUU/CUD/
    CUF/CUB/CHA/VPA, ED/EL, SGR (incl. 38;5/38;2/48;5/48;2 and 4:x underline
    styles), OSC (BEL and ESC\\ terminated), DCS skipping (sixel passthrough),
    charset designation, DECSC/DECRC, CR/LF/BS/TAB and UTF-8.  Unknown private
    mode set/reset sequences are ignored.  The buffer is NOT switched on
    1049 (alternate screen): tcell redraws with absolute addressing, so the
    grid accumulates every frame from process start.
    """

    def __init__(self, rows, cols):
        self.rows = rows
        self.cols = cols
        self.cx = 0
        self.cy = 0
        self.saved = (0, 0)
        self.fg = None
        self.bg = None
        self.attrs = frozenset()
        self.grid = [[Cell() for _ in range(cols)] for _ in range(rows)]
        self._buf = bytearray()

    # ------------------------------------------------------------- rendering

    def _cell(self, y, x):
        if 0 <= y < self.rows and 0 <= x < self.cols:
            return self.grid[y][x]
        return None

    def _put(self, ch, w):
        if self.cy >= self.rows:
            self._scroll()
        if not (0 <= self.cy < self.rows):
            return
        if w == 0:  # combining mark: attach to the cell on the left
            if self.cx > 0:
                c = self.grid[self.cy][self.cx - 1]
                c.ch += ch
            return
        if self.cx >= self.cols:
            self.cx = 0
            self.cy += 1
            if self.cy >= self.rows:
                self._scroll()
                if self.cy >= self.rows:
                    return
        c = self.grid[self.cy][self.cx]
        c.ch = ch
        c.fg = self.fg
        c.bg = self.bg
        c.attrs = self.attrs
        if w == 2 and self.cx + 1 < self.cols:
            d = self.grid[self.cy][self.cx + 1]
            d.ch = ""
            d.fg = self.fg
            d.bg = self.bg
            d.attrs = self.attrs
        self.cx += w

    def _scroll(self):
        if self.cy >= self.rows:
            self.grid.pop(0)
            self.grid.append([Cell() for _ in range(self.cols)])
            self.cy = self.rows - 1

    def _linefeed(self):
        self.cy += 1
        if self.cy >= self.rows:
            self._scroll()

    def _tab(self):
        nxt = (self.cx // 8 + 1) * 8
        self.cx = min(nxt, self.cols - 1)

    def _erase(self, y, x0, x1):
        row = self.grid[y]
        for x in range(max(0, x0), min(self.cols, x1)):
            row[x] = Cell()

    # ------------------------------------------------------------- sequences

    def _sgr(self, paramstr):
        toks = paramstr.lstrip(">").split(";") or ["0"]
        if paramstr == "":
            toks = ["0"]

        def reset():
            self.fg = None
            self.bg = None
            self.attrs = frozenset()

        i = 0
        n = len(toks)
        while i < n:
            t = toks[i]
            head, _, sub = t.partition(":")
            p = int(head) if head.isdigit() else 0
            if p == 0:
                reset()
            elif p == 1:
                self.attrs = self.attrs | {"bold"}
            elif p == 2:
                self.attrs = self.attrs | {"dim"}
            elif p == 3:
                self.attrs = self.attrs | {"italic"}
            elif p == 4:
                # 4 / 4:1 plain, 4:0 off; other dotted styles still underline
                if sub not in ("0",):
                    self.attrs = self.attrs | {"underline"}
            elif p == 5 or p == 6:
                self.attrs = self.attrs | {"blink"}
            elif p == 7:
                self.attrs = self.attrs | {"reverse"}
            elif p == 9:
                self.attrs = self.attrs | {"strikethrough"}
            elif p == 22:
                self.attrs = self.attrs - {"bold", "dim"}
            elif p == 23:
                self.attrs = self.attrs - {"italic"}
            elif p == 24:
                self.attrs = self.attrs - {"underline"}
            elif p == 25:
                self.attrs = self.attrs - {"blink"}
            elif p == 27:
                self.attrs = self.attrs - {"reverse"}
            elif p == 29:
                self.attrs = self.attrs - {"strikethrough"}
            elif 30 <= p <= 37:
                self.fg = p - 30
            elif p == 39:
                self.fg = None
            elif 40 <= p <= 47:
                self.bg = p - 40
            elif p == 49:
                self.bg = None
            elif 90 <= p <= 97:
                self.fg = p - 82
            elif 100 <= p <= 107:
                self.bg = p - 92
            elif p in (38, 48, 58):
                if sub:  # dotted 38:5:n / 38:2:r:g:b form
                    parts = (head,) + tuple(sub.split(":"))
                else:
                    parts = tuple(toks[i:])
                color = None
                if len(parts) > 2 and parts[1] == "5" and parts[2].isdigit():
                    color = int(parts[2])
                    i += 2
                elif len(parts) > 4 and parts[1] == "2":
                    color = tuple(int(x) if x.isdigit() else 0 for x in parts[2:5])
                    i += 4
                if p == 38:
                    self.fg = color
                elif p == 48:
                    self.bg = color
            i += 1

    def _csi(self, paramstr, final):
        priv = paramstr.startswith("?") or paramstr.startswith(">")
        params = []
        for p in paramstr.lstrip("?><!").split(";"):
            # dotted subparameters (SGR 4:3) only matter for m, which is
            # dispatched to _sgr with the raw string
            params.append(int(p) if p.isdigit() else None)
        default = lambda idx, d: params[idx] if idx < len(params) and params[idx] is not None else d

        if final in ("H", "f"):
            self.cy = max(0, default(0, 1) - 1)
            self.cx = max(0, default(1, 1) - 1)
        elif final == "A":
            self.cy = max(0, self.cy - max(1, default(0, 1)))
        elif final == "B":
            self.cy = min(self.rows - 1, self.cy + max(1, default(0, 1)))
        elif final == "C":
            self.cx = min(self.cols - 1, self.cx + max(1, default(0, 1)))
        elif final == "D":
            self.cx = max(0, self.cx - max(1, default(0, 1)))
        elif final == "G":
            self.cx = max(0, default(0, 1) - 1)
        elif final == "d":
            self.cy = max(0, default(0, 1) - 1)
        elif final == "J":
            mode = default(0, 0)
            if mode == 0:
                self._erase(self.cy, self.cx, self.cols)
                for y in range(self.cy + 1, self.rows):
                    self._erase(y, 0, self.cols)
            elif mode == 1:
                self._erase(self.cy, 0, self.cx + 1)
                for y in range(0, self.cy):
                    self._erase(y, 0, self.cols)
            else:
                for y in range(self.rows):
                    self._erase(y, 0, self.cols)
        elif final == "K":
            mode = default(0, 0)
            if mode == 0:
                self._erase(self.cy, self.cx, self.cols)
            elif mode == 1:
                self._erase(self.cy, 0, self.cx + 1)
            else:
                self._erase(self.cy, 0, self.cols)
        elif final == "m" and not priv:
            self._sgr(paramstr)
        # everything else (h/l/n/q/r/s/t/u/...) ignored

    def feed(self, data):
        self._buf += data
        buf = self._buf
        i, n = 0, len(buf)
        while i < n:
            b = buf[i]
            if b == 0x1B:
                if i + 1 >= n:
                    break
                c = buf[i + 1]
                if c == 0x5B:  # CSI
                    j = i + 2
                    while j < n and not (0x40 <= buf[j] <= 0x7E):
                        j += 1
                    if j >= n:
                        break
                    self._csi(bytes(buf[i + 2:j]).decode("latin-1"), chr(buf[j]))
                    i = j + 1
                elif c == 0x5D:  # OSC ... BEL / ESC \
                    j = i + 2
                    end = -1
                    while j < n:
                        if buf[j] == 0x07:
                            end = j + 1
                            break
                        if buf[j] == 0x1B and j + 1 < n and buf[j + 1] == 0x5C:
                            end = j + 2
                            break
                        j += 1
                    if end < 0:
                        break
                    i = end
                elif c in (0x50, 0x58, 0x5E, 0x5F):  # DCS/SOS/PM/APC ... ESC \
                    j = i + 2
                    end = -1
                    while j < n:
                        if buf[j] == 0x1B and j + 1 < n and buf[j + 1] == 0x5C:
                            end = j + 2
                            break
                        j += 1
                    if end < 0:
                        break
                    i = end
                elif c in (0x28, 0x29, 0x2A, 0x2B, 0x23, 0x25):
                    if i + 2 >= n:
                        break
                    i += 3
                elif c == 0x37:  # DECSC
                    self.saved = (self.cx, self.cy)
                    i += 2
                elif c == 0x38:  # DECRC
                    self.cx, self.cy = self.saved
                    i += 2
                elif c == 0x63:  # RIS
                    self.__init__(self.rows, self.cols)
                    i += 2
                else:
                    i += 2
            elif b == 0x0D:
                self.cx = 0
                i += 1
            elif b == 0x0A:
                self._linefeed()
                i += 1
            elif b == 0x08:
                self.cx = max(0, self.cx - 1)
                i += 1
            elif b == 0x09:
                self._tab()
                i += 1
            elif b < 0x20 or b == 0x7F:
                i += 1
            else:
                if b < 0x80:
                    w = 1
                elif b < 0xC0:
                    i += 1  # stray continuation byte
                    continue
                elif b < 0xE0:
                    w = 2
                elif b < 0xF0:
                    w = 3
                else:
                    w = 4
                if i + w > n:
                    break
                try:
                    ch = bytes(buf[i:i + w]).decode("utf-8")
                except UnicodeDecodeError:
                    ch = "�"
                for r in ch:
                    self._put(r, _rune_width(r))
                i += w
        del self._buf[:i]

    # ------------------------------------------------------------- accessors

    def rows_text(self):
        out = []
        for row in self.grid:
            out.append("".join(c.ch for c in row).rstrip())
        return out

    def text(self):
        return "\n".join(self.rows_text())

    def style(self, y, x):
        """(fg, bg, attrs) of one cell; fg/bg are palette indices, RGB tuples
        or None for default; attrs is a sorted tuple of attribute names."""
        c = self._cell(y, x)
        if c is None:
            return None
        return (c.fg, c.bg, tuple(sorted(c.attrs)))


class LFRun:
    """A single lf invocation driving a pseudo terminal."""

    def __init__(self, exe, cwd, config=None, rows=24, cols=80, env=None, args=()):
        self.exe = exe
        self.cwd = cwd
        self.rows, self.cols = rows, cols
        self.raw = bytearray()
        self.screen = Screen(rows, cols)
        self.dead = False
        self.status = None

        e = {
            "TERM": "xterm-256color",
            "PATH": "/usr/bin:/bin",
            "HOME": cwd,
            "USER": "tester",
            "TZ": "UTC",
            "LANG": "C.UTF-8",
            "XDG_CONFIG_HOME": os.path.join(cwd, ".config"),
            "XDG_DATA_HOME": os.path.join(cwd, ".local/share"),
            "XDG_CACHE_HOME": os.path.join(cwd, ".cache"),
            "XDG_RUNTIME_DIR": os.path.join(cwd, ".runtime"),
            "LF_CONFIG_HOME": os.path.join(cwd, ".config"),
            "LF_DATA_HOME": os.path.join(cwd, ".local/share"),
            "SHELL": "/bin/sh",
            "EDITOR": "/bin/true",
            "PAGER": "cat",
            "OPENER": "/bin/true",
        }
        if env:
            e.update(env)
        # Coverage instrumentation hook: the pipeline measures source coverage
        # of the reference binary through GOCOVERDIR, so it must reach the
        # child even though the rest of the environment is fully pinned.
        cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
        e.update(cov_env)

        argv = [exe, "-single"] + list(args)
        if config:
            argv += ["-config", config]

        master, slave = pty.openpty()
        # set the window size before the child can possibly read it
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))

        pid = os.fork()
        if pid == 0:  # child
            try:
                os.setsid()
                fcntl.ioctl(slave, termios.TIOCSCTTY, 0)
                os.dup2(slave, 0)
                os.dup2(slave, 1)
                os.dup2(slave, 2)
                if slave > 2:
                    os.close(slave)
                os.close(master)
                os.chdir(cwd)
                os.environ.clear()
                os.environ.update(e)
                os.execv(exe, argv)
            except BaseException:
                os._exit(127)
        os.close(slave)
        self.pid = pid
        self.master = master
        self._wait_quiet(settle=0.45, min_dur=1.2, max_dur=8.0)
        self._stabilize()

    def _stabilize(self, rounds=3):
        """Force full redraws until the screen stops changing.

        Returns early when two consecutive screens match, which rules out
        the transitional startup frames (pre-config draw, "loading..."
        panes).  <c-l> is `redraw` in the default bindings and renews the
        window layout, so the final comparison happens against a complete
        repaint of the initialized state.
        """
        for _ in range(rounds):
            if self.dead:
                return
            prev = self.screen.text()
            try:
                os.write(self.master, b"\x0c")
            except OSError:
                self.dead = True
                return
            self._wait_quiet(settle=0.55, max_dur=6.0)
            if self.dead or self.screen.text() == prev:
                return

    # ------------------------------------------------------------- pumping

    def _wait_quiet(self, settle=0.45, min_dur=0.0, max_dur=10.0):
        t0 = time.monotonic()
        last = t0
        while True:
            now = time.monotonic()
            elapsed = now - t0
            quiet = now - last
            if (quiet >= settle and elapsed >= min_dur) or elapsed >= max_dur:
                return
            timeout = min(settle, max(0.01, max_dur - elapsed))
            if quiet < settle:
                timeout = min(settle - quiet, max(0.01, max_dur - elapsed))
            try:
                r, _, _ = select.select([self.master], [], [], timeout)
            except OSError:
                self.dead = True
                return
            if r:
                try:
                    data = os.read(self.master, 65536)
                except OSError:
                    self.dead = True
                    return
                if not data:
                    self.dead = True
                    return
                self.raw += data
                self.screen.feed(data)
                last = time.monotonic()

    def send(self, keys, settle=0.55):
        if isinstance(keys, str):
            keys = keys.encode()
        if not self.dead:
            try:
                os.write(self.master, keys)
            except OSError:
                self.dead = True
                return
            self._wait_quiet(settle=settle, max_dur=6.0)

    def wait(self, settle=0.55):
        """Pump output without sending anything (async previewers etc.)."""
        if not self.dead:
            self._wait_quiet(settle=settle, max_dur=6.0)

    def resize(self, rows, cols):
        self.rows, self.cols = rows, cols
        try:
            fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        except OSError:
            pass
        # replay the whole byte history into a fresh grid: tcell repaints with
        # absolute addressing so the accumulated view survives a resize
        self.screen = Screen(rows, cols)
        self.screen.feed(bytes(self.raw))
        self._wait_quiet(settle=0.6, min_dur=0.2, max_dur=6.0)

    # ------------------------------------------------------------- accessors

    def lines(self):
        return self.screen.rows_text()

    def close(self, quit_keys=b"q"):
        if not self.dead:
            for k in (quit_keys, b"\x1b", b"q"):
                try:
                    os.write(self.master, k)
                except OSError:
                    break
                deadline = time.monotonic() + 0.8
                while time.monotonic() < deadline:
                    try:
                        pid, status = os.waitpid(self.pid, os.WNOHANG)
                    except ChildProcessError:
                        pid, status = self.pid, 0
                    if pid == self.pid:
                        self.status = status
                        break
                    # drain (into raw only: the exit sequence must not wipe
                    # the snapshot the test may still read)
                    r, _, _ = select.select([self.master], [], [], 0.05)
                    if r:
                        try:
                            d = os.read(self.master, 65536)
                        except OSError:
                            d = b""
                        self.raw += d
                        if not d:
                            break
                if self.status is not None:
                    break
        if self.status is None:
            try:
                os.kill(self.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                os.waitpid(self.pid, 0)
            except ChildProcessError:
                pass
        try:
            os.close(self.master)
        except OSError:
            pass


# ------------------------------------------------------------------- fixtures


def _write_tree(root, files):
    # Two passes: creating an entry inside a directory updates the
    # directory's own mtime, so all timestamps are applied after every
    # path exists (utime never touches the parent).
    #
    # Permission bits are pinned (regular files 0644 unless the spec asks
    # for another mode, directories 0755) so listings show the same
    # "-rw-r--r--"/"drwxr-xr-x" strings no matter which umask the suite
    # itself runs under.  A name may also be raw `bytes`, which creates
    # fixtures whose names contain control or invalid-UTF-8 bytes.
    created = []
    broot = os.fsencode(root)
    os.makedirs(root, exist_ok=True)
    for name in sorted(files or {}, key=lambda n: n if isinstance(n, str) else os.fsdecode(n)):
        spec = files[name] or {}
        if isinstance(name, bytes):
            path = os.path.join(broot, name)
        else:
            path = os.path.join(root, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if name.endswith(b"/" if isinstance(name, bytes) else "/"):
            os.makedirs(path, exist_ok=True)
        elif "link" in spec:
            link = spec["link"]
            if isinstance(path, bytes) and isinstance(link, str):
                link = os.fsencode(link)
            os.symlink(link, path)
        else:
            with open(path, "wb") as f:
                f.write(spec.get("data", b""))
            mode = spec.get("mode")
            os.chmod(path, 0o644 if mode is None else mode)
        created.append((path, spec.get("mtime", T0)))
    for path, mt in created:
        if mt is not None:
            try:
                os.utime(path, (mt, mt))
            except FileNotFoundError:
                # dangling symlink target: stamp the link itself
                os.utime(path, (mt, mt), follow_symlinks=False)
    for dirpath, _, _ in os.walk(root):
        os.chmod(dirpath, 0o755)


@pytest.fixture
def run_lf(tmp_path):
    """Factory booting lf in an isolated fixture directory under tmp_path.

    Keyword arguments:
      files  -- {name: spec} tree created inside the listing directory; a name
                ending in "/" makes a directory, spec keys are data/mtime/
                mode/link; a bytes name creates a fixture whose name holds
                raw control/invalid-UTF-8 bytes (link targets may be bytes
                too); without an explicit mode files land on 0644 and
                directories on 0755 whatever the suite's umask is
      config -- lfrc contents (written to <base>/.lfrc, a dot file so it never
                shows up in a pane listing)
      ruler  -- rulerfile template, written to <base>/ruler and wired up with
                `set rulerfile` (the file name is part of template error
                messages, hence the fixed base name)
      colors / icons -- contents of <base>/.config/lf/{colors,icons}
      setup -- callable(str base) returning extra config text; called before
              lf boots so a test can install helper scripts (previewer,
              cleaner, ...) inside <base> where they never pollute a pane
              listing, and have the returned lines appended to the lfrc
      keys   -- byte sequences sent to the terminal after startup, in order
      rows/cols -- terminal size (default 24x80)
      env    -- extra child environment overrides
      args   -- extra lf command line arguments
    """
    runs = []
    n = [0]

    def factory(files=None, config="", ruler=None, colors=None, icons=None,
                setup=None, keys=(), rows=24, cols=80, env=None, args=()):
        n[0] += 1
        base = tmp_path / ("w%d" % n[0])
        root = base / "root"
        _write_tree(str(root), files)
        cfg = base / ".lfrc"
        text = ""
        if setup is not None:
            extra = setup(str(base))
            if extra:
                text += extra
        if ruler is not None:
            (base / "ruler").write_text(ruler)
            text += 'set rulerfile "%s"\n' % (base / "ruler")
        text += config
        cfg.write_text(text)
        if colors is not None:
            (base / ".config/lf").mkdir(parents=True, exist_ok=True)
            (base / ".config/lf/colors").write_text(colors)
        if icons is not None:
            (base / ".config/lf").mkdir(parents=True, exist_ok=True)
            (base / ".config/lf/icons").write_text(icons)
        if colors is not None or icons is not None:
            # the default child env pins LF_CONFIG_HOME inside the listing
            # root; point it at the base dir the files were written to
            env = dict(env or {})
            env["LF_CONFIG_HOME"] = str(base / ".config")
            env["XDG_CONFIG_HOME"] = str(base / ".config")
        r = LFRun(
            os.environ["PROGRAMGYM_EXECUTABLE"],
            str(root),
            config=str(cfg),
            rows=rows,
            cols=cols,
            env=env,
            args=args,
        )
        for k in keys:
            r.send(k)
        runs.append(r)
        r.base = str(base)
        r.root = str(root)
        return r

    yield factory
    for r in runs:
        r.close()
