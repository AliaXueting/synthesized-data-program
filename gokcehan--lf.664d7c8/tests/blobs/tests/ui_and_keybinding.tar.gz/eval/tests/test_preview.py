"""Preview pane: internal text preview, external previewer protocol,
binary/loading placeholders, sixel passthrough and the cleaner hook."""

import os

import pytest


def _script(base, name, body):
    """Write an executable helper script under base and return its path."""
    path = os.path.join(base, name)
    with open(path, "w") as f:
        f.write(body)
    os.chmod(path, 0o755)
    return path


def test_internal_preview_multiline(run_lf):
    """Multi-line files render one preview line per file line."""
    # CATCHES: each source line maps to its own screen row aligned under
    # the preview column (x=42) even when the pane row above is a filename.
    files = {"a.txt": {"data": b"line-one\nline-two\nline-three\n"}}
    r = run_lf(files=files, rows=10)
    lines = r.lines()
    assert lines[1] == "  root          a.txt                    line-one"
    assert lines[2] == "                                         line-two"
    assert lines[3] == "                                         line-three"


def test_preview_tabstop(run_lf):
    """tabstop controls the tab width inside text previews."""
    # CATCHES: with `set tabstop 4` each tab advances to the next multiple
    # of 4 columns, not the terminal's default 8.
    files = {"f.txt": {"data": b"a\tb\tc\n1\t2\n"}}
    r = run_lf(files=files, config="set tabstop 4\n")
    lines = r.lines()
    assert lines[1] == "  root          f.txt                    a   b   c"
    assert lines[2] == "                                         1   2"


def test_internal_preview_sanitized(run_lf):
    """Escape bytes in previewed files are replaced, not interpreted."""
    # CATCHES: a raw ESC byte becomes U+FFFD so SGR sequences in file
    # contents can never style the preview; the pane stays unstyled.
    files = {"a.txt": {"data": b"\x1b[31mred\x1b[0m plain\n"}}
    r = run_lf(files=files)
    lines = r.lines()
    assert lines[1] == "  root          a.txt                    �[31mred�[0m plain"
    assert r.screen.style(1, 16) == (None, None, ("reverse",))
    assert r.screen.style(1, 42) == (None, None, ())


def test_binary_preview(run_lf):
    """NUL bytes make the preview collapse to the word "binary"."""
    # CATCHES: the "binary" placeholder is drawn in reverse video in the
    # preview column and the file still lists normally next to text files.
    files = {"a.bin": {"data": b"\x00\x01bin"}, "b.txt": {"data": b"text"}}
    r = run_lf(files=files)
    lines = r.lines()
    assert lines[1] == "  root          a.bin                    binary"
    assert lines[2] == "                b.txt"
    assert r.screen.style(1, 16) == (None, None, ("reverse",))
    assert r.screen.style(1, 42) == (None, None, ("reverse",))


def test_loading_indicator(run_lf):
    """A slow previewer leaves a reversed "loading..." placeholder."""
    # CATCHES: while the previewer is still running the pane shows
    # "loading..." in reverse video, and the sibling file lists normally.
    def setup(base):
        prev = _script(base, "prev.sh",
                       '#!/bin/sh\nsleep 5\nprintf "SLOW-DONE\\n"\n')
        return 'set previewer "%s"\n' % prev
    files = {"a.txt": {"data": b"x"}}
    r = run_lf(files=files, setup=setup)
    lines = r.lines()
    assert lines[1] == "  root          a.txt                     loading..."
    assert lines[2] == "  prev.sh"
    assert r.screen.style(1, 16) == (None, None, ("reverse",))
    assert r.screen.style(1, 42) == (None, None, ("reverse",))


@pytest.mark.parametrize("rows,cols,expected", [
    (24, 80, ["  root          a.txt                    p1=a.txt mode= w=39 h=22",
              "  prev.sh       b.txt                    lf_width= lf_height= lf_mode="]),
    (30, 120, ["  root                 a.txt                                 p1=a.txt mode= w=59 h=28",
               "  prev.sh              b.txt                                 lf_width= lf_height= lf_mode="]),
])
def test_previewer_args_and_env(run_lf, rows, cols, expected):
    """The previewer gets positional args but no lf_* environment."""
    # CATCHES: $1 is the file path, $2/$3 the preview pane width/height
    # (which follow the terminal size), $7 (mode) is empty at startup, and
    # lf_width/lf_height/lf_mode are NOT exported to previewers.
    def setup(base):
        prev = _script(base, "prev.sh",
                       '#!/bin/sh\n'
                       'printf "p1=%s mode=%s w=%s h=%s\\n" "$(basename "$1")" "$7" "$2" "$3"\n'
                       'printf "lf_width=%s lf_height=%s lf_mode=%s\\n" '
                       '"$lf_width" "$lf_height" "$lf_mode"\n')
        return 'set previewer "%s"\n' % prev
    files = {"a.txt": {"data": b"x"}, "b.txt": {"data": b"y"}}
    r = run_lf(files=files, setup=setup, rows=rows, cols=cols)
    lines = r.lines()
    assert lines[1] == expected[0]
    assert lines[2] == expected[1]


def test_previewer_sgr_styles(run_lf):
    """SGR output from a previewer is applied to the preview cells."""
    # CATCHES: previewer escapes style the pane (RED red fg, BLUEBG blue
    # bg+bold) exactly like internal previews would never do.
    def setup(base):
        prev = _script(base, "prev.sh",
                       '#!/bin/sh\nprintf "\\033[31mRED\\033[0m \\033[1;44mBLUEBG\\033[0m end\\n"\n')
        return 'set previewer "%s"\n' % prev
    files = {"a.txt": {"data": b""}}
    r = run_lf(files=files, setup=setup)
    assert r.lines()[1] == "  root          a.txt                    RED BLUEBG end"
    assert r.screen.style(1, 16) == (None, None, ("reverse",))
    assert r.screen.style(1, 42) == (1, None, ())
    assert r.screen.style(1, 46) == (None, 4, ("bold",))


def test_previewer_rerun_on_move(run_lf):
    """Moving the cursor re-runs the previewer for the new selection."""
    # CATCHES: after j (to b.txt) and k (back to a.txt) the preview shows
    # a.txt's fresh output again -- previewers are re-invoked per file.
    def setup(base):
        prev = _script(base, "prev.sh",
                       '#!/bin/sh\nprintf "w=%s h=%s\\n" "$lf_width" "$lf_height"\n')
        return 'set previewer "%s"\n' % prev
    files = {"a.txt": {"data": b"x"}, "b.txt": {"data": b"y"}}
    r = run_lf(files=files, setup=setup, keys=[b"j", b"k"])
    lines = r.lines()
    assert lines[1] == "  root          a.txt                    w= h="
    assert lines[2] == "  prev.sh       b.txt"


def test_dirpreviews(run_lf):
    """dirpreviews sends directories to the external previewer too."""
    # CATCHES: with `set dirpreviews` a directory entry (d) is previewed
    # by the script instead of being listed inline in the preview pane.
    def setup(base):
        prev = _script(base, "prev.sh",
                       '#!/bin/sh\nprintf "DIRPREV %s\\n" "$(basename "$1")"\n')
        return 'set previewer "%s"\nset dirpreviews\n' % prev
    files = {"d/": {}, "x.txt": {"data": b""}}
    r = run_lf(files=files, setup=setup)
    lines = r.lines()
    assert lines[1] == "  root          d                        DIRPREV d"
    assert lines[2] == "  prev.sh       x.txt"


def test_sixel_passthrough(run_lf):
    """Sixel data from a previewer is passed through with sync wraps."""
    # CATCHES: the raw DCS payload survives to the terminal byte stream
    # wrapped in DECSET 2026 (sync start/stop) and DECSC/DECRC around the
    # image, while the surrounding text lines render normally.
    def setup(base):
        prev = _script(base, "prev.sh",
                       "#!/bin/sh\nprintf '%b' 'before\\n\\033Pq\"1;1;20;10"
                       "#0;2;0;0;0-~~\\033\\\\after\\n'\n")
        return 'set previewer "%s"\n' % prev
    files = {"a.txt": {"data": b""}}
    r = run_lf(files=files, setup=setup)
    lines = r.lines()
    assert lines[1] == "  root          a.txt                    before"
    assert lines[2] == "  prev.sh"
    assert lines[3] == "                                         after"
    raw = bytes(r.raw)
    for needle in (b"\x1bPq", b'"1;1;20;10', b"\x1b[?2026h",
                   b"\x1b[?2026l", b"\x1b7"):
        assert needle in raw


def test_cleaner_invocation(run_lf):
    """The cleaner runs for volatile previews on the next full reload."""
    # CATCHES: a previewer exiting non-zero marks the file volatile; the
    # cleaner then receives old path, pane geometry and new path (here a
    # reload triggered by toggling an option with :set ignorecase!).
    def setup(base):
        prev = _script(base, "prev.sh", '#!/bin/sh\ncat "$1"\nexit 1\n')
        clean = _script(
            base, "clean.sh",
            '#!/bin/sh\nprintf "c1=%s c2=%s c3=%s c4=%s c5=%s c6=%s\\n" '
            '"$1" "$2" "$3" "$4" "$5" "$6" > "' + base + '/cleaner.log"\n')
        return ('set previewer "%s"\nset cleaner "%s"\n' % (prev, clean))
    files = {"a.txt": {"data": b"A\n"}, "d/": {}}
    r = run_lf(files=files, setup=setup,
               keys=[b"j", b":", b"set ignorecase!", b"\r"])
    r.wait(settle=1.0)
    log = os.path.join(r.base, "cleaner.log")
    with open(log) as f:
        assert f.read() == ("c1=%s/a.txt c2=39 c3=22 c4=41 c5=1 c6=%s/a.txt\n"
                            % (r.root, r.root))
    lines = r.lines()
    assert lines[1] == "  root          d                        A"
    assert lines[2] == "  clean.sh      a.txt"
