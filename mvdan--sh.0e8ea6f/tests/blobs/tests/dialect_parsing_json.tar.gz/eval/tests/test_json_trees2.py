"""Deep --from-json decoding and --to-json encoding of the typed trees.

Round 1 pinned the basic decode errors and round trips.  These tests
cover the position-object validation (which only applies to embedded
position fields, not the method-derived "Pos"/"End" keys), the operator
enums decoded from their syntax strings, and the trees of the clause
nodes introduced in the second dialect-gating wave.
"""

import json

import pytest


def _tree(run_shfmt, flags, source):
    """Encode source to a typed tree and return it as a dict."""
    proc = run_shfmt([*flags, "--to-json"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout)


def _decode(run_shfmt, tree):
    """Feed a (possibly mutated) tree to --from-json."""
    return run_shfmt(["--from-json"], input_text=json.dumps(tree))


@pytest.mark.parametrize(
    ("oppos", "expected_err"),
    [
        (1, "cannot decode JSON number into a position\n"),
        ("x", "cannot decode JSON string into a position\n"),
        (
            {"Offset": 0, "Line": 1},
            "a position must contain exactly the fields [Offset Line Col]\n",
        ),
        (
            {"Offset": 0, "Line": 1, "Col": "x"},
            'cannot decode JSON string into the position field "Col"\n',
        ),
        (
            {"Offset": 0, "Line": 1, "Col": -1},
            'the position field "Col" is out of range: -1\n',
        ),
        (
            {"Offset": 0, "Line": 1, "Col": 0.5},
            'the position field "Col" is out of range: 0.5\n',
        ),
    ],
)
def test_from_json_position_decode_errors(run_shfmt, oppos, expected_err):
    """Embedded position fields validate their shape exactly."""
    # CATCHES: OpPos must be an object holding exactly Offset, Line and
    # Col as unsigned integers; each violation has its own wording.
    tree = _tree(run_shfmt, ["-ln=bash"], "echo a > f\n")
    tree["Stmts"][0]["Redirs"][0]["OpPos"] = oppos
    proc = _decode(run_shfmt, tree)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


def test_from_json_nested_type_mismatch_errors(run_shfmt):
    """Wrong JSON types for node fields fail naming the Go type."""
    # CATCHES: the decoder names the Go type it could not fill, from
    # the []*syntax.Word slice down to a single syntax.WordPart.
    args = _tree(run_shfmt, ["-ln=bash"], "echo hi\n")
    args["Stmts"][0]["Cmd"]["Args"] = "nope"
    proc = _decode(run_shfmt, args)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "cannot decode JSON string into []*syntax.Word\n"

    parts = _tree(run_shfmt, ["-ln=bash"], "echo hi\n")
    parts["Stmts"][0]["Cmd"]["Args"][0]["Parts"] = [5]
    proc = _decode(run_shfmt, parts)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "cannot decode JSON number into syntax.WordPart\n"


def test_from_json_missing_and_wrong_type_keys(run_shfmt):
    """A Cmd object needs its "Type", and it must be a command node."""
    # CATCHES: an object without "Type" cannot fill the Command
    # interface, and a File is not assignable to it.
    missing = _tree(run_shfmt, ["-ln=bash"], "echo hi\n")
    missing["Stmts"][0]["Cmd"] = {}
    proc = _decode(run_shfmt, missing)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == 'missing "Type" to decode a JSON object into syntax.Command\n'

    wrong = _tree(run_shfmt, ["-ln=bash"], "echo hi\n")
    wrong["Stmts"][0]["Cmd"] = {"Type": "File"}
    proc = _decode(run_shfmt, wrong)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "cannot decode File into syntax.Command\n"


def test_from_json_bool_field_type(run_shfmt):
    """A string for a bool field is rejected."""
    # CATCHES: Stmt.Negated is a plain bool, so the error names the Go
    # kind rather than a syntax node type.
    tree = _tree(run_shfmt, ["-ln=bash"], "echo hi\n")
    tree["Stmts"][0]["Negated"] = "yes"
    proc = _decode(run_shfmt, tree)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "cannot decode JSON string into bool\n"


@pytest.mark.parametrize(
    ("node_path", "expected_err"),
    [
        ([], 'unknown field for syntax.File: "Bogus"\n'),
        (["Stmts", 0, "Cmd"], 'unknown field for syntax.CallExpr: "Bogus"\n'),
    ],
)
def test_from_json_unknown_fields(run_shfmt, node_path, expected_err):
    """Unknown keys are rejected with the offending node's Go type."""
    # CATCHES: the decoder is strict: a key that matches no field of
    # the node type is an error naming that type.
    tree = _tree(run_shfmt, ["-ln=bash"], "echo hi\n")
    node = tree
    for key in node_path:
        node = node[key]
    node["Bogus"] = 1
    proc = _decode(run_shfmt, tree)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


def test_from_json_operator_enum_errors(run_shfmt):
    """Operator fields decode from their syntax strings, strictly."""
    # CATCHES: a numeric Op is refused because operators are strings on
    # the wire, and an unknown string names the enum type.
    numeric = _tree(run_shfmt, ["-ln=bash"], "echo a > f\n")
    numeric["Stmts"][0]["Redirs"][0]["Op"] = 5
    proc = _decode(run_shfmt, numeric)
    assert proc.returncode == 1
    assert proc.stderr == (
        "cannot decode JSON number into syntax.RedirOperator; a string is required\n"
    )
    bogus = _tree(run_shfmt, ["-ln=bash"], "echo a > f\n")
    bogus["Stmts"][0]["Redirs"][0]["Op"] = "Bogus"
    proc = _decode(run_shfmt, bogus)
    assert proc.returncode == 1
    assert proc.stderr == 'invalid RedirOperator: "Bogus"\n'


def test_from_json_operator_enum_decodes(run_shfmt):
    """A rewritten Op string changes the printed redirect operator."""
    # CATCHES: the enum decoder accepts the real operator spellings, so
    # swapping > for >> in the tree changes the formatted output.
    tree = _tree(run_shfmt, ["-ln=bash"], "echo a > f\n")
    tree["Stmts"][0]["Redirs"][0]["Op"] = ">>"
    proc = _decode(run_shfmt, tree)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo a >>f\n"


def test_from_json_null_root(run_shfmt):
    """A JSON null at the root is not a node."""
    # CATCHES: null is the one JSON value that decodes into a nil node,
    # and the decoder rejects it instead of formatting nothing.
    proc = run_shfmt(["--from-json"], input_text="null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "cannot decode JSON null into a syntax node\n"


def test_from_json_ignores_pos_and_end_keys(run_shfmt):
    """The method-derived Pos/End keys are skipped while decoding."""
    # CATCHES: only embedded position fields like OpPos are validated;
    # garbage under "Pos" or "End" is ignored and the file still
    # formats, because those keys never reach the decoder.
    tree = _tree(run_shfmt, ["-ln=bash"], "echo hi\n")
    tree["Stmts"][0]["Pos"] = 1
    tree["Stmts"][0]["End"] = "bogus"
    proc = _decode(run_shfmt, tree)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo hi\n"


@pytest.mark.parametrize(
    ("expr", "ops"),
    [
        ("a ? b : c", [("BinaryArithm", "?"), ("BinaryArithm", ":")]),
        ("a += 2", [("BinaryArithm", "+=")]),
        ("2 ** 3", [("BinaryArithm", "**")]),
        ("a, b", [("BinaryArithm", ",")]),
        ("!a", [("UnaryArithm", "!")]),
        ("~a", [("UnaryArithm", "~")]),
        ("++a", [("UnaryArithm", "++")]),
        ("1 != 2", [("BinaryArithm", "!=")]),
        ("a << 2", [("BinaryArithm", "<<")]),
    ],
)
def test_to_json_arith_operator_strings(run_shfmt, expr, ops):
    """Arithmetic operators encode as their syntax spellings."""
    # CATCHES: the ternary ?: pair, the comma, the power operator and
    # the unary operators all appear as string "Op" values, not as
    # integers, so the wire format stays textual.
    proc = run_shfmt(["-ln=bash", "--to-json"], input_text="echo $((%s))\n" % expr)
    assert proc.returncode == 0, proc.stderr
    tree = json.loads(proc.stdout)

    def walk(node):
        if isinstance(node, dict):
            if "Op" in node and "Type" in node and "Arithm" in node["Type"]:
                yield (node["Type"], node["Op"])
            for value in node.values():
                yield from walk(value)
        elif isinstance(node, list):
            for value in node:
                yield from walk(value)

    assert list(walk(tree)) == ops


@pytest.mark.parametrize(
    ("flags", "source", "expected"),
    [
        (["-ln=bash"], "let a=1 b=2\n", "let a=1 b=2\n"),
        (["-ln=bash"], "coproc name { echo; }\n", "coproc name { echo; }\n"),
        (["-ln=bash"], "time -p ls\n", "time -p ls\n"),
        (["-ln=bash"], "declare -a x\n", "declare -a x\n"),
        (["-ln=bash"], "echo $((a ? b : c))\n", "echo $((a ? b : c))\n"),
        (["-ln=bash"], "echo !(x)\n", "echo !(x)\n"),
        (["-ln=bash"], "x=${|foo;}\n", "x=${|foo;}\n"),
        (["-ln=bash"], "case $a in x) echo; ;;& esac\n", "case $a in x) echo ;;& esac\n"),
        (["-ln=zsh"], "echo ${a:#pat}\n", "echo ${a:#pat}\n"),
        (["-ln=zsh"], 'echo ${(f)"$(x)"}\n', 'echo ${(f)"$(x)"}\n'),
        (["-ln=zsh"], "echo ${${a}}\n", "echo ${${a}}\n"),
        (["-ln=mksh"], "echo $((# a))\n", "echo $((# a))\n"),
        (["-ln=mksh"], "echo ${%a}\n", "echo ${%a}\n"),
        (["-ln=mksh"], "case $a in x) echo; ;| esac\n", "case $a in x) echo ;| esac\n"),
    ],
)
def test_new_constructs_round_trip(run_shfmt, flags, source, expected):
    """Every new clause and operator tree decodes and prints back."""
    # CATCHES: the decode side must understand LetClause, CoprocClause,
    # TimeClause, DeclClause, ternaries, extglobs, the mksh value-of
    # and unsigned forms, and zsh nested expansions without any
    # dialect flag, or the round trip would fail.  The case terminators
    # still print canonically with a space before them.
    tree = _tree(run_shfmt, flags, source)
    proc = _decode(run_shfmt, tree)
    assert proc.returncode == 0, proc.stderr
    assert proc.stderr == ""
    assert proc.stdout == expected


def test_backquotes_canonicalized_from_json(run_shfmt):
    """A tree parsed from backquotes still prints with $()."""
    # CATCHES: the printer (not the parser) turns `ls` into $(ls), so
    # even a decoded tree loses the backquotes when formatted.
    tree = _tree(run_shfmt, ["-ln=bash"], "echo `ls`\n")
    proc = _decode(run_shfmt, tree)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $(ls)\n"


def test_test_clause_paren_node(run_shfmt):
    """A parenthesised test encodes as a ParenTest node."""
    # CATCHES: the TestClause X field holds a typed ParenTest rather
    # than an inline copy of the inner expression.
    proc = run_shfmt(["-ln=bash", "--to-json"], input_text="[[ (a == b) ]]\n")
    assert proc.returncode == 0, proc.stderr
    tree = json.loads(proc.stdout)
    test = tree["Stmts"][0]["Cmd"]
    assert test["Type"] == "TestClause"
    assert test["X"]["Type"] == "ParenTest"
    assert test["X"]["X"]["Type"] == "BinaryTest"
    assert test["X"]["X"]["Op"] == "=="
