"""--from-json decode failures: bogus operators and wrongly-shaped values.

The typed JSON decoder validates every operator spelling against its
generated UnmarshalText table and every JSON value against the Go type it
is decoded into.  These tests pin the exact rejection message for each
kind of bad input, and the lenient arms where a missing or null field is
accepted, so a re-implementation that silently accepts a bogus operator or
coerces a wrongly-shaped value fails.
"""

import json

import pytest


def _find_by_type(obj, node_type, found):
    """Collect every dict carrying the given "Type" tag."""
    if isinstance(obj, dict):
        if obj.get("Type") == node_type:
            found.append(obj)
        for value in obj.values():
            _find_by_type(value, node_type, found)
    elif isinstance(obj, list):
        for value in obj:
            _find_by_type(value, node_type, found)


# template key -> (source, locator, operator field); the locator is either a
# path from the tree root or a node "Type" tag to search for.
TEMPLATES = {
    "redir": ("x > f\n", ("Stmts", 0, "Redirs", 0), "Op"),
    "proc": ("echo <(y)\n", "ProcSubst", "Op"),
    "glob": ("echo !(x)\n", "ExtGlob", "Op"),
    "bincmd": ("a && b\n", "BinaryCmd", "Op"),
    "case": ("case x in a) b;; esac\n", ("Stmts", 0, "Cmd", "Items", 0), "Op"),
    "parnames": ("echo ${!a*}\n", "ParamExp", "Names"),
    "parexp": ("echo ${a-b}\n", "ParamExp", "Exp"),
    "unarit": ("echo $((!a))\n", "UnaryArithm", "Op"),
    "binarit": ("echo $((a + b))\n", "BinaryArithm", "Op"),
    "untest": ("[[ -e f ]]\n", "UnaryTest", "Op"),
    "bintest": ("[[ a = b ]]\n", "BinaryTest", "Op"),
}


def _decode_mutated(run_shfmt, template, value):
    """Encode the template, overwrite its operator field, decode it back."""
    source, locator, field = TEMPLATES[template]
    proc = run_shfmt(["-ln=bash", "--to-json"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    tree = json.loads(proc.stdout)
    if isinstance(locator, tuple):
        node = tree
        for step in locator:
            node = node[step]
    else:
        found = []
        _find_by_type(tree, locator, found)
        node = found[0]
    if field == "Exp":
        node["Exp"]["Op"] = value
    else:
        node[field] = value
    return run_shfmt(["--from-json"], input_text=json.dumps(tree))


@pytest.mark.parametrize(
    ("template", "message"),
    [
        ("redir", 'invalid RedirOperator: "Bogus"\n'),
        ("proc", 'invalid ProcOperator: "Bogus"\n'),
        ("glob", 'invalid GlobOperator: "Bogus"\n'),
        ("bincmd", 'invalid BinCmdOperator: "Bogus"\n'),
        ("case", 'invalid CaseOperator: "Bogus"\n'),
        ("parnames", 'invalid ParNamesOperator: "Bogus"\n'),
        ("parexp", 'invalid ParExpOperator: "Bogus"\n'),
        ("unarit", 'invalid UnAritOperator: "Bogus"\n'),
        ("binarit", 'invalid BinAritOperator: "Bogus"\n'),
        ("untest", 'invalid UnTestOperator: "Bogus"\n'),
        ("bintest", 'invalid BinTestOperator: "Bogus"\n'),
    ],
)
def test_bogus_operator_spelling_rejected(run_shfmt, template, message):
    """An unknown operator spelling fails decode with its enum's name."""
    # CATCHES: each operator field has its own generated UnmarshalText
    # table; the error names the exact enum type, so a decoder that
    # accepts any string or reports the wrong enum name fails.
    proc = _decode_mutated(run_shfmt, template, "Bogus")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == message


MISSING_TYPE = 'missing "Type" to decode a JSON object into syntax.Node\n'


@pytest.mark.parametrize(
    ("document", "message"),
    [
        pytest.param('{"Type": 123}', MISSING_TYPE, id="type-number"),
        pytest.param('{"Type": null}', MISSING_TYPE, id="type-null"),
        pytest.param('{"Type": ["x"]}', MISSING_TYPE, id="type-array"),
        pytest.param('{"Type": {"x": 1}}', MISSING_TYPE, id="type-object"),
        pytest.param('{"Type": true}', MISSING_TYPE, id="type-bool"),
        pytest.param("{}", MISSING_TYPE, id="type-missing"),
        pytest.param('{"Type": "Bogus"}', 'unknown type: "Bogus"\n',
                     id="type-unknown"),
        pytest.param("[]", "cannot decode JSON array into syntax.Node\n",
                     id="top-array"),
        pytest.param('"hello"', "cannot decode JSON string into syntax.Node\n",
                     id="top-string"),
        pytest.param("{", "unexpected EOF\n", id="truncated"),
    ],
)
def test_malformed_documents(run_shfmt, document, message):
    """Documents that are not a typed node object are rejected verbatim."""
    # CATCHES: the decoder needs a string "Type" on a JSON object; any
    # other top-level shape, an unknown type name, or truncated JSON gets
    # a distinct message naming the expected Go type.
    proc = run_shfmt(["--from-json"], input_text=document)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == message


@pytest.mark.parametrize(
    ("document", "message"),
    [
        pytest.param('{"Type": "File", "Stmts": {}}',
                     "cannot decode JSON object into []*syntax.Stmt\n",
                     id="stmts-object"),
        pytest.param('{"Type": "File", "Stmts": [123]}',
                     "cannot decode JSON number into *syntax.Stmt\n",
                     id="stmt-number"),
        pytest.param('{"Type": "File", "Stmts": ["x"]}',
                     "cannot decode JSON string into *syntax.Stmt\n",
                     id="stmt-string"),
        pytest.param('{"Type": "File", "Stmts": [true]}',
                     "cannot decode JSON boolean into *syntax.Stmt\n",
                     id="stmt-bool"),
        pytest.param(
            '{"Type": "File", "Stmts": '
            '[{"Cmd": {"Type": "CallExpr", "Args": {}}}]}',
            "cannot decode JSON object into []*syntax.Word\n",
            id="args-object"),
        pytest.param(
            '{"Type": "File", "Stmts": [{"Cmd": {"Type": "CallExpr", '
            '"Args": [{"Parts": [{"Type": "DblQuoted", "Parts": 3}]}]}}]}',
            "cannot decode JSON number into []syntax.WordPart\n",
            id="parts-number"),
    ],
)
def test_wrong_container_shapes(run_shfmt, document, message):
    """A JSON value of the wrong kind for a slice field fails to decode."""
    # CATCHES: slice-typed fields (Stmts, Args, quoted Parts) demand a
    # JSON array of the right element type; the error spells the exact Go
    # slice type it wanted.
    proc = run_shfmt(["--from-json"], input_text=document)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == message


@pytest.mark.parametrize(
    ("value", "kind"),
    [
        (5, "number"),
        ({}, "object"),
        ([], "array"),
        (True, "boolean"),
    ],
)
def test_wrong_scalar_shapes(run_shfmt, value, kind):
    """A non-string where a Lit value belongs fails with 'into string'."""
    # CATCHES: the Lit Value field is a plain Go string, so numbers,
    # objects, arrays and booleans all fail decode with the same target
    # type in the message.
    document = json.dumps(
        {
            "Type": "File",
            "Stmts": [
                {
                    "Cmd": {
                        "Type": "CallExpr",
                        "Args": [{"Parts": [{"Type": "Lit", "Value": value}]}],
                    }
                }
            ],
        }
    )
    proc = run_shfmt(["--from-json"], input_text=document)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == f"cannot decode JSON {kind} into string\n"


@pytest.mark.parametrize(
    ("document", "expected"),
    [
        pytest.param(
            '{"Type": "File", "Stmts": [{"Cmd": {"Type": "CallExpr", '
            '"Args": [{"Parts": [{"Type": "Lit", "Value": null}, '
            '{"Type": "Lit", "Value": "b"}]}]}}]}',
            "b\n",
            id="null-lit-empty"),
        pytest.param('{"Type": "File"}', "\n", id="file-without-stmts"),
        pytest.param('{"Type": "File", "Stmts": []}', "\n", id="empty-stmts"),
        pytest.param(
            '{"Type": "File", "Pos": 5, "Stmts": [{"Cmd": {"Type": "CallExpr", '
            '"Args": [{"Parts": [{"Type": "Lit", "Value": "a"}]}]}}]}',
            "a\n",
            id="positions-ignored"),
    ],
)
def test_lenient_decode_arms(run_shfmt, document, expected):
    """Missing or null fields decode leniently instead of failing."""
    # CATCHES: a null Lit value decodes as the empty string, Stmts is
    # optional, and the Pos/End objects are skipped entirely, so a strict
    # decoder that rejects these documents is not behavior-compatible.
    proc = run_shfmt(["--from-json"], input_text=document)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
