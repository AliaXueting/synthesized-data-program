"""A second wave of dialect-gated constructs.

Round 1 pinned the headline gates (arrays, function, select, ...).  These
tests cover the mksh value-of forms, the @ expansion operators, extglobs,
for-loop braces, zsh-only redirects and modifiers, declare/let/time/coproc
clauses, and the reserved-word errors that only fire in some dialects.
"""

import json

import pytest


@pytest.mark.parametrize("dialect", ["bash", "mksh"])
def test_mksh_value_of_forms_accepted(run_shfmt, dialect):
    """${|stmts;} and ${ stmts;} parse in bash and mksh only."""
    # CATCHES: the value-of expansion is a bash/mksh feature; zsh and
    # posix reject it, so accepting it here proves the gate direction.
    for script, expected in [
        ("x=${|foo;}\n", "x=${|foo;}\n"),
        ("x=${ foo; }\n", "x=${ foo;}\n"),
    ]:
        proc = run_shfmt(["-ln=%s" % dialect], input_text=script)
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == expected


@pytest.mark.parametrize("dialect", ["zsh", "posix"])
def test_mksh_value_of_forms_rejected(run_shfmt, dialect):
    """zsh and posix reject the ${|...} value-of expansion."""
    # CATCHES: the LangError names both the feature and the dialect.
    proc = run_shfmt(["-ln=%s" % dialect], input_text="x=${|foo;}\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:3: `${|stmts;}` is a bash/mksh feature; "
        "tried parsing as %s\n" % dialect
    )


def test_mksh_value_of_multiline_printing(run_shfmt):
    """Multiple statements inside ${|...} print one per line, indented."""
    # CATCHES: the printer keeps the multi-statement body but reindents
    # it with tabs, and distinguishes ${| from ${ by the first line.
    pipe = run_shfmt(["-ln=bash"], input_text="x=${|foo; bar;}\n")
    assert pipe.returncode == 0, pipe.stderr
    assert pipe.stdout == "x=${|\n\tfoo\n\tbar\n}\n"
    space = run_shfmt(["-ln=bash"], input_text="x=${ foo; bar ;}\n")
    assert space.returncode == 0, space.stderr
    assert space.stdout == "x=${\n\tfoo\n\tbar\n}\n"


def test_value_of_json_fields(run_shfmt):
    """${|...} sets ReplyVar on the CmdSubst; ${ ...; } sets TempFile."""
    # CATCHES: the two spellings differ by a JSON field on the shared
    # CmdSubst node, which the typed encoder must preserve.
    pipe = run_shfmt(["-ln=bash", "--to-json"], input_text="x=${|foo;}\n")
    assert pipe.returncode == 0, pipe.stderr
    node = json.loads(pipe.stdout)["Stmts"][0]["Cmd"]["Assigns"][0]["Value"]["Parts"][0]
    assert node["Type"] == "CmdSubst"
    assert node["ReplyVar"] is True
    space = run_shfmt(["-ln=bash", "--to-json"], input_text="x=${ foo; }\n")
    assert space.returncode == 0, space.stderr
    node = json.loads(space.stdout)["Stmts"][0]["Cmd"]["Assigns"][0]["Value"]["Parts"][0]
    assert node["Type"] == "CmdSubst"
    assert node["TempFile"] is True


def test_mksh_width_prefix(run_shfmt):
    """${%foo} (width) is accepted by mksh and rejected by bash."""
    # CATCHES: the LangError text renders the mksh-only form `${%foo}`
    # even though the check fires for the single-percent spelling.
    ok = run_shfmt(["-ln=mksh"], input_text="echo ${%a}\n")
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == "echo ${%a}\n"
    bad = run_shfmt(["-ln=bash"], input_text="echo ${%a}\n")
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == (
        "<standard input>:1:6: `${%foo}` is a mksh feature; "
        "tried parsing as bash\n"
    )


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        (
            "echo ${!a^}\n",
            "<standard input>:1:10: this expansion operator is a bash "
            "feature; tried parsing as mksh\n",
        ),
        (
            "echo ${!a*}\n",
            "<standard input>:1:6: `${!foo*}` is a bash feature; "
            "tried parsing as mksh\n",
        ),
    ],
)
def test_indirection_names_bash_only(run_shfmt, script, expected_err):
    """mksh allows ${!foo} but not the bash-only name-list suffixes."""
    # CATCHES: ${!foo^} and ${!foo*} pass the shared ${!foo} gate but
    # fail the stricter bash-only operator gate with distinct columns.
    ok = run_shfmt(["-ln=bash"], input_text=script)
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == script
    bad = run_shfmt(["-ln=mksh"], input_text=script)
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == expected_err


def test_zsh_array_operators(run_shfmt):
    """:#, :| and :* inside ${...} are zsh-only array operators."""
    # CATCHES: bash reports ${name:#arg} with the operator spelled out,
    # while zsh accepts all three spellings unchanged.
    for script in ["echo ${a:#pat}\n", "echo ${a:|x}\n", "echo ${a:*x}\n"]:
        ok = run_shfmt(["-ln=zsh"], input_text=script)
        assert ok.returncode == 0, ok.stderr
        assert ok.stdout == script
    bad = run_shfmt(["-ln=bash"], input_text="echo ${a:#pat}\n")
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == (
        "<standard input>:1:9: ${name:#arg} is a zsh feature; "
        "tried parsing as bash\n"
    )


@pytest.mark.parametrize(
    ("dialect", "script", "accepted"),
    [
        ("bash", "echo ${a@Q}\n", True),
        ("mksh", "echo ${a@Q}\n", True),
        ("zsh", "echo ${a@Q}\n", False),
        ("posix", "echo ${a@Q}\n", False),
        ("bash", "echo ${a@E}\n", True),
        ("zsh", "echo ${a@E}\n", False),
        ("mksh", "echo ${a@#}\n", True),
        ("bash", "echo ${a@#}\n", False),
    ],
)
def test_at_expansion_ops(run_shfmt, dialect, script, accepted):
    """The ${x@op} operators are gated: Q anywhere but zsh/posix, E not
    zsh, # only mksh."""
    # CATCHES: each rejected pair keeps its own column (9 for the @ in
    # zsh/posix, 10 for the # in bash) and its own feature list.
    proc = run_shfmt(["-ln=%s" % dialect], input_text=script)
    if accepted:
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == script
    else:
        assert proc.returncode == 1
        assert proc.stdout == ""
        if dialect == "bash":
            expected = (
                "<standard input>:1:10: this expansion operator is a mksh "
                "feature; tried parsing as bash\n"
            )
        else:
            expected = (
                "<standard input>:1:9: this expansion operator is a "
                "bash/mksh feature; tried parsing as %s\n" % dialect
            )
        assert proc.stderr == expected


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        (
            "echo ${a@b}\n",
            "<standard input>:1:10: invalid @ expansion operator `b`\n",
        ),
        (
            "echo ${a@$x}\n",
            "<standard input>:1:10: @ expansion operator requires a literal\n",
        ),
    ],
)
def test_at_expansion_op_errors(run_shfmt, script, expected_err):
    """The @ operator needs a valid literal argument."""
    # CATCHES: these are plain parse errors (not LangErrors) reported at
    # the operator position with backquoted operands.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


def test_extended_globs(run_shfmt):
    """!(...) extglobs parse in bash/mksh, fail in posix, stay literal
    in zsh."""
    # CATCHES: zsh reuses !(x) for glob qualifiers, so its JSON holds a
    # Lit part where bash holds an ExtGlob with Op "!(".
    for dialect in ["bash", "mksh"]:
        proc = run_shfmt(["-ln=%s" % dialect], input_text="echo !(x)\n")
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == "echo !(x)\n"
    posix = run_shfmt(["-ln=posix"], input_text="echo !(x)\n")
    assert posix.returncode == 1
    assert posix.stdout == ""
    assert posix.stderr == (
        "<standard input>:1:6: extended globs are a bash/mksh feature; "
        "tried parsing as posix\n"
    )
    bash_tree = json.loads(
        run_shfmt(["-ln=bash", "--to-json"], input_text="echo !(x)\n").stdout
    )
    part = bash_tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert part["Type"] == "ExtGlob"
    assert part["Op"] == "!("
    zsh_tree = json.loads(
        run_shfmt(["-ln=zsh", "--to-json"], input_text="echo !(x)\n").stdout
    )
    part = zsh_tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert part["Type"] == "Lit"


@pytest.mark.parametrize("dialect", ["bash", "mksh"])
def test_for_loop_braces_accepted(run_shfmt, dialect):
    """`for x in ...; { ...; }` canonicalizes to do/done in bash and mksh."""
    # CATCHES: the braces form is accepted but the printer always emits
    # the portable do/done spelling.
    proc = run_shfmt(["-ln=%s" % dialect], input_text="for i in 1 2; { echo; }\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "for i in 1 2; do echo; done\n"


def test_for_loop_braces_rejected_by_zsh(run_shfmt):
    """zsh rejects the brace form of for loops."""
    # CATCHES: the error points at the opening brace (col 15).
    proc = run_shfmt(["-ln=zsh"], input_text="for i in 1 2; { echo; }\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:15: for loops with braces are a bash/mksh "
        "feature; tried parsing as zsh\n"
    )


def test_zsh_empty_block(run_shfmt):
    """{} is an empty Block in zsh but a plain word in bash."""
    # CATCHES: only zsh treats a bare {} as a compound command; the
    # printer renders it with spaces while bash echoes the word back.
    zsh = run_shfmt(["-ln=zsh"], input_text="{}\n")
    assert zsh.returncode == 0, zsh.stderr
    assert zsh.stdout == "{ }\n"
    bash = run_shfmt(["-ln=bash"], input_text="{}\n")
    assert bash.returncode == 0, bash.stderr
    assert bash.stdout == "{}\n"
    tree = json.loads(run_shfmt(["-ln=zsh", "--to-json"], input_text="{}\n").stdout)
    assert tree["Stmts"][0]["Cmd"]["Type"] == "Block"


@pytest.mark.parametrize("op", [">>|", "&>|", "&>>|"])
def test_zsh_clobber_redirects(run_shfmt, op):
    """The three clobber-and-append redirects are zsh-only."""
    # CATCHES: zsh accepts them and prints them without a space before
    # the target, while bash rejects each with a `%#q`-quoted operator.
    zsh = run_shfmt(["-ln=zsh"], input_text="cmd %s f\n" % op)
    assert zsh.returncode == 0, zsh.stderr
    assert zsh.stdout == "cmd %sf\n" % op
    bash = run_shfmt(["-ln=bash"], input_text="cmd %s f\n" % op)
    assert bash.returncode == 1
    assert bash.stdout == ""
    assert bash.stderr == (
        "<standard input>:1:5: `%s` redirects are a zsh feature; "
        "tried parsing as bash\n" % op
    )


def test_posix_rejects_append_all_redirect(run_shfmt):
    """posix rejects &>> as a bash/mksh/zsh redirect."""
    # CATCHES: &> was pinned in round 1; the double >> form has its own
    # operator token and its own rejection message.
    proc = run_shfmt(["-ln=posix"], input_text="cmd &>> f\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:5: `&>>` redirects are a bash/mksh/zsh "
        "feature; tried parsing as posix\n"
    )


def test_zsh_temp_file_procsubst(run_shfmt):
    """=(cmd) is a zsh process substitution spelling."""
    # CATCHES: bash reports the `=(` operator itself as a zsh feature.
    zsh = run_shfmt(["-ln=zsh"], input_text="echo =(cmd)\n")
    assert zsh.returncode == 0, zsh.stderr
    assert zsh.stdout == "echo =(cmd)\n"
    bash = run_shfmt(["-ln=bash"], input_text="echo =(cmd)\n")
    assert bash.returncode == 1
    assert bash.stdout == ""
    assert bash.stderr == (
        "<standard input>:1:6: `=(` process substitutions are a zsh "
        "feature; tried parsing as bash\n"
    )


def test_declare_clause_variants(run_shfmt):
    """declare/local/typeset/export/readonly/nameref parse as DeclClause."""
    # CATCHES: the builtin list is dialect-gated (declare and nameref
    # are not in mksh) and each keeps its flags and assignment intact.
    for script in [
        "declare -a x\n",
        "local -r x\n",
        "typeset -i x=5\n",
        "export x=1\n",
        "readonly x\n",
        "nameref x y\n",
    ]:
        proc = run_shfmt(["-ln=bash"], input_text=script)
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == script
    tree = json.loads(
        run_shfmt(["-ln=bash", "--to-json"], input_text="declare -a x\n").stdout
    )
    cmd = tree["Stmts"][0]["Cmd"]
    assert cmd["Type"] == "DeclClause"
    assert cmd["Variant"]["Value"] == "declare"
    assert cmd["Args"][0]["Naked"] is True


def test_declare_not_special_in_mksh(run_shfmt):
    """mksh lacks declare, so it parses there as a plain CallExpr."""
    # CATCHES: the formatted output is identical, so only the typed tree
    # shows that mksh did not enter the declaration grammar.
    mksh = run_shfmt(["-ln=mksh"], input_text="declare -a x\n")
    assert mksh.returncode == 0, mksh.stderr
    assert mksh.stdout == "declare -a x\n"
    tree = json.loads(
        run_shfmt(["-ln=mksh", "--to-json"], input_text="declare -a x\n").stdout
    )
    assert tree["Stmts"][0]["Cmd"]["Type"] == "CallExpr"


def test_coproc_clause(run_shfmt):
    """coproc is bash-only: a clause there, a plain command in zsh."""
    # CATCHES: coproc without a command is an error; with a name and a
    # block both the Name and Stmt fields appear in the JSON.
    ok = run_shfmt(["-ln=bash"], input_text="coproc name { echo; }\n")
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == "coproc name { echo; }\n"
    tree = json.loads(
        run_shfmt(["-ln=bash", "--to-json"], input_text="coproc name { echo; }\n").stdout
    )
    cmd = tree["Stmts"][0]["Cmd"]
    assert cmd["Type"] == "CoprocClause"
    assert cmd["Name"]["Parts"][0]["Value"] == "name"
    zsh_tree = json.loads(
        run_shfmt(["-ln=zsh", "--to-json"], input_text="coproc ls\n").stdout
    )
    assert zsh_tree["Stmts"][0]["Cmd"]["Type"] == "CallExpr"


def test_coproc_requires_a_command(run_shfmt):
    """A bare coproc keyword is an error in bash."""
    # CATCHES: the message points at the coproc keyword itself (col 1).
    proc = run_shfmt(["-ln=bash"], input_text="coproc\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "<standard input>:1:1: coproc clause requires a command\n"


def test_let_clause(run_shfmt):
    """let parses its words as arithmetic expressions."""
    # CATCHES: let builds a LetClause with one expression per argument,
    # and a bare let is rejected; posix just sees a command word.
    ok = run_shfmt(["-ln=bash"], input_text="let a=1 b=2\n")
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == "let a=1 b=2\n"
    tree = json.loads(
        run_shfmt(["-ln=bash", "--to-json"], input_text="let a=1 b=2\n").stdout
    )
    cmd = tree["Stmts"][0]["Cmd"]
    assert cmd["Type"] == "LetClause"
    assert len(cmd["Exprs"]) == 2
    posix_tree = json.loads(
        run_shfmt(["-ln=posix", "--to-json"], input_text="let a=1\n").stdout
    )
    assert posix_tree["Stmts"][0]["Cmd"]["Type"] == "CallExpr"
    bad = run_shfmt(["-ln=bash"], input_text="let\n")
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == "<standard input>:1:1: `let` must be followed by an expression\n"


def test_time_clause(run_shfmt):
    """time builds a TimeClause in bash and stays a word in posix."""
    # CATCHES: time -p sets the PosixFormat field of the clause, visible
    # only in the typed JSON, not in the formatted output.
    for script in ["time ls\n", "time -p ls\n", "time { ls; }\n"]:
        proc = run_shfmt(["-ln=bash"], input_text=script)
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == script
    tree = json.loads(
        run_shfmt(["-ln=bash", "--to-json"], input_text="time -p ls\n").stdout
    )
    cmd = tree["Stmts"][0]["Cmd"]
    assert cmd["Type"] == "TimeClause"
    assert cmd["PosixFormat"] is True
    plain = json.loads(
        run_shfmt(["-ln=bash", "--to-json"], input_text="time ls\n").stdout
    )
    assert "PosixFormat" not in plain["Stmts"][0]["Cmd"]
    posix_tree = json.loads(
        run_shfmt(["-ln=posix", "--to-json"], input_text="time ls\n").stdout
    )
    assert posix_tree["Stmts"][0]["Cmd"]["Type"] == "CallExpr"


@pytest.mark.parametrize("dialect", ["mksh", "zsh"])
def test_select_in_ksh_dialects(run_shfmt, dialect):
    """select loops parse in mksh and zsh, not just bash."""
    # CATCHES: round 1 pinned the posix rejection; the ksh family also
    # accepts select and prints it with the same do/done body.
    proc = run_shfmt(["-ln=%s" % dialect], input_text="select x in a b; do echo; done\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "select x in a b; do echo; done\n"


def test_mksh_unsigned_arithmetic(run_shfmt):
    """$((#expr)) is mksh's unsigned arithmetic form."""
    # CATCHES: mksh reprints the # with a following space, while bash
    # and zsh reject the form at the $(( position.
    ok = run_shfmt(["-ln=mksh"], input_text="echo $((#a))\n")
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == "echo $((# a))\n"
    tree = json.loads(
        run_shfmt(["-ln=mksh", "--to-json"], input_text="echo $((# a))\n").stdout
    )
    node = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert node["Type"] == "ArithmExp"
    assert node["Unsigned"] is True
    for dialect, suffix in [("bash", "bash"), ("zsh", "zsh")]:
        bad = run_shfmt(["-ln=%s" % dialect], input_text="echo $((#a))\n")
        assert bad.returncode == 1
        assert bad.stdout == ""
        assert bad.stderr == (
            "<standard input>:1:6: unsigned expressions are a mksh "
            "feature; tried parsing as %s\n" % suffix
        )


def test_mksh_double_brackets(run_shfmt):
    """mksh accepts [[ ]] tests but not the stray ]]."""
    # CATCHES: the extended test is in the bash/mksh/zsh set, so both
    # the accepted clause and the stray-closer error apply to mksh.
    ok = run_shfmt(["-ln=mksh"], input_text="[[ a == b ]]\n")
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == "[[ a == b ]]\n"
    bad = run_shfmt(["-ln=mksh"], input_text="]]\n")
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == "<standard input>:1:1: `]]` can only be used to close a test\n"


def test_stray_closer_is_a_word_in_posix(run_shfmt):
    """In posix ]] is an ordinary word because [[ is not a keyword."""
    # CATCHES: the same input that errors in bash formats unchanged in
    # posix since extended tests are entirely absent there.
    proc = run_shfmt(["-ln=posix"], input_text="]]\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "]]\n"


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        ("elif\n", "<standard input>:1:1: `elif` can only be used in an `if`\n"),
        ("esac\n", "<standard input>:1:1: `esac` can only be used to end a `case`\n"),
        ("}\n", "<standard input>:1:1: `}` can only be used to close a block\n"),
        ("! ! true\n", "<standard input>:1:1: cannot negate a command multiple times\n"),
    ],
)
def test_stray_reserved_word_errors(run_shfmt, script, expected_err):
    """Each stray keyword has its own error message at column 1."""
    # CATCHES: elif/esac/} and double negation are distinct reserved
    # word errors beyond the then/fi/do/done set pinned in round 1.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


def test_double_negation_still_formats_single(run_shfmt):
    """A single negation formats fine; only doubling is an error."""
    # CATCHES: the negation gate allows ! once per statement, including
    # after && (where it negates the right-hand statement).
    for script in ["! true\n", "true && ! true\n"]:
        proc = run_shfmt(["-ln=bash"], input_text=script)
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == script


@pytest.mark.parametrize(
    ("dialect", "script", "expected"),
    [
        ("posix", "a.b() { echo; }\n", "<standard input>:1:1: invalid func name\n"),
        ("bash", '"x y"() { echo; }\n', "<standard input>:1:1: invalid func name\n"),
    ],
)
def test_invalid_func_names(run_shfmt, dialect, script, expected):
    """Function names must be valid POSIX names in posix mode."""
    # CATCHES: bash happily declares a.b as a function while posix
    # rejects it, and a quoted name is invalid everywhere.
    bad = run_shfmt(["-ln=%s" % dialect], input_text=script)
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == expected
    ok = run_shfmt(["-ln=bash"], input_text="a.b() { echo; }\n")
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == "a.b() { echo; }\n"


def test_zsh_empty_param_name(run_shfmt):
    """zsh allows the parameter name to be omitted, bash does not."""
    # CATCHES: ${:-word} parses as a default-value expansion in zsh but
    # hits "invalid parameter name" at the operator in bash.
    zsh = run_shfmt(["-ln=zsh"], input_text="echo ${:-word}\n")
    assert zsh.returncode == 0, zsh.stderr
    assert zsh.stdout == "echo ${:-word}\n"
    bash = run_shfmt(["-ln=bash"], input_text="echo ${:-word}\n")
    assert bash.returncode == 1
    assert bash.stdout == ""
    assert bash.stderr == "<standard input>:1:8: invalid parameter name\n"


def test_zsh_short_indexing(run_shfmt):
    """$foo[1] is an indexed parameter in zsh, plain text in bash."""
    # CATCHES: the formatted output is identical; only the zsh tree has
    # an Index field inside the ParamExp.
    zsh_proc = run_shfmt(["-ln=zsh", "--to-json"], input_text="echo $a[1]\n")
    assert zsh_proc.returncode == 0, zsh_proc.stderr
    zsh_tree = json.loads(zsh_proc.stdout)
    part = zsh_tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert part["Type"] == "ParamExp"
    assert part["Index"]["Parts"][0]["Value"] == "1"
    bash_proc = run_shfmt(["-ln=bash", "--to-json"], input_text="echo $a[1]\n")
    assert bash_proc.returncode == 0, bash_proc.stderr
    bash_tree = json.loads(bash_proc.stdout)
    part = bash_tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert part["Type"] == "ParamExp"
    assert "Index" not in part


def test_zsh_modifiers_vs_bash_slice(run_shfmt):
    """${a:u} is a modifier list in zsh but a slice in bash."""
    # CATCHES: the colon is ambiguous; the dialect decides between the
    # zsh Modifiers array and the bash Slice with a Word offset.
    zsh_proc = run_shfmt(["-ln=zsh", "--to-json"], input_text="echo ${a:u}\n")
    assert zsh_proc.returncode == 0, zsh_proc.stderr
    zsh_tree = json.loads(zsh_proc.stdout)
    part = zsh_tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert [lit["Value"] for lit in part["Modifiers"]] == ["u"]
    assert "Slice" not in part
    bash_proc = run_shfmt(["-ln=bash", "--to-json"], input_text="echo ${a:u}\n")
    assert bash_proc.returncode == 0, bash_proc.stderr
    bash_tree = json.loads(bash_proc.stdout)
    part = bash_tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert part["Slice"]["Offset"]["Parts"][0]["Value"] == "u"
    assert "Modifiers" not in part


def test_special_parameter_indexing(run_shfmt):
    """Indexing $@ fails in bash with a dedicated error but works in zsh."""
    # CATCHES: the "cannot index a special parameter name" check runs
    # after the arrays gate, so it only fires in the non-zsh dialects.
    bad = run_shfmt(["-ln=bash"], input_text="echo ${@[0]}\n")
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == "<standard input>:1:9: cannot index a special parameter name\n"
    ok = run_shfmt(["-ln=zsh"], input_text="echo ${@[-1]}\n")
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == "echo ${@[-1]}\n"


def test_zsh_nested_param_expansions(run_shfmt):
    """${${a}}, ${#$(cmd)} and ${(f)"$(x)"} only parse in zsh."""
    # CATCHES: nesting a parameter expansion inside another is rejected
    # by bash with the nested-expansion LangError before any other gate.
    for script in ["echo ${${a}}\n", "echo ${#$(echo hi)}\n", 'echo ${(f)"$(x)"}\n']:
        ok = run_shfmt(["-ln=zsh"], input_text=script)
        assert ok.returncode == 0, ok.stderr
        assert ok.stdout == script
    bad = run_shfmt(["-ln=bash"], input_text="echo ${${a}}\n")
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == (
        "<standard input>:1:8: nested parameter expansions are a zsh "
        "feature; tried parsing as bash\n"
    )


def test_zsh_glob_qualifiers(run_shfmt):
    """zsh parses (...) after a word as a glob qualifier literal."""
    # CATCHES: *(N) and *.(:a) survive formatting because the whole
    # parenthesised suffix becomes one literal part in zsh.
    for script in ["echo *(N)\n", "echo *.(:a)\n"]:
        proc = run_shfmt(["-ln=zsh"], input_text=script)
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == script


def test_unclosed_heredoc_rejected_only_by_mksh(run_shfmt):
    """mksh rejects an unterminated heredoc; bash completes it at EOF."""
    # CATCHES: the same stdin is an error under -ln=mksh but a silent
    # completion under bash, mirroring mksh's stricter heredoc rule.
    script = "cat << EOF\nbody\n"
    mksh = run_shfmt(["-ln=mksh"], input_text=script)
    assert mksh.returncode == 1
    assert mksh.stdout == ""
    assert mksh.stderr == "<standard input>:1:5: unclosed here-document `EOF`\n"
    bash = run_shfmt(["-ln=bash"], input_text=script)
    assert bash.returncode == 0, bash.stderr
    assert bash.stdout == "cat <<EOF\nbody\nEOF\n"
