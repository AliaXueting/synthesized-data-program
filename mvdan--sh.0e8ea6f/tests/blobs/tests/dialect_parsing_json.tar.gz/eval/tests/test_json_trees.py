"""Tests for the --to-json and --from-json typed syntax trees.

--to-json prints the parsed tree as indented typed JSON; --from-json
decodes such a tree from stdin and formats it.  Node objects carry a
"Type" key whenever the Go field they fill is an interface.
"""

import json

import pytest

# Exact bytes of `echo hi` encoded with --to-json (tab-indented).
ECHO_HI_JSON = """{
	"Type": "File",
	"Pos": {
		"Offset": 0,
		"Line": 1,
		"Col": 1
	},
	"End": {
		"Offset": 7,
		"Line": 1,
		"Col": 8
	},
	"Stmts": [
		{
			"Pos": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			},
			"End": {
				"Offset": 7,
				"Line": 1,
				"Col": 8
			},
			"Cmd": {
				"Type": "CallExpr",
				"Pos": {
					"Offset": 0,
					"Line": 1,
					"Col": 1
				},
				"End": {
					"Offset": 7,
					"Line": 1,
					"Col": 8
				},
				"Args": [
					{
						"Pos": {
							"Offset": 0,
							"Line": 1,
							"Col": 1
						},
						"End": {
							"Offset": 4,
							"Line": 1,
							"Col": 5
						},
						"Parts": [
							{
								"Type": "Lit",
								"Pos": {
									"Offset": 0,
									"Line": 1,
									"Col": 1
								},
								"End": {
									"Offset": 4,
									"Line": 1,
									"Col": 5
								},
								"ValuePos": {
									"Offset": 0,
									"Line": 1,
									"Col": 1
								},
								"ValueEnd": {
									"Offset": 4,
									"Line": 1,
									"Col": 5
								},
								"Value": "echo"
							}
						]
					},
					{
						"Pos": {
							"Offset": 5,
							"Line": 1,
							"Col": 6
						},
						"End": {
							"Offset": 7,
							"Line": 1,
							"Col": 8
						},
						"Parts": [
							{
								"Type": "Lit",
								"Pos": {
									"Offset": 5,
									"Line": 1,
									"Col": 6
								},
								"End": {
									"Offset": 7,
									"Line": 1,
									"Col": 8
								},
								"ValuePos": {
									"Offset": 5,
									"Line": 1,
									"Col": 6
								},
								"ValueEnd": {
									"Offset": 7,
									"Line": 1,
									"Col": 8
								},
								"Value": "hi"
							}
						]
					}
				]
			},
			"Position": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			}
		}
	]
}
"""


def test_to_json_exact_bytes(run_shfmt):
    """`echo hi` encodes to this exact tab-indented typed JSON."""
    # CATCHES: the whole tree is pinned byte for byte: "Type" first in
    # each object, Offset/Line/Col position objects, and Words nested
    # as Parts arrays.
    proc = run_shfmt(["--to-json"], input_text="echo hi\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stderr == ""
    assert proc.stdout == ECHO_HI_JSON


def test_to_json_empty_input(run_shfmt):
    """Empty input encodes to a File with no position or statements."""
    # CATCHES: an empty program is still a File node, printed as the
    # three-line object with only the "Type" key.
    proc = run_shfmt(["--to-json"], input_text="")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n\t"Type": "File"\n}\n'


def test_to_json_dialect_specific_fields(run_shfmt):
    """zsh-only syntax round trips its dialect-specific node fields."""
    # CATCHES: ${=a} is only valid zsh, and its ParamExp carries a
    # "Split" field with value 1 that a generic tree would miss.
    proc = run_shfmt(["-ln=zsh", "--to-json"], input_text="echo ${=a}\n")
    assert proc.returncode == 0, proc.stderr
    tree = json.loads(proc.stdout)
    param = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert param["Type"] == "ParamExp"
    assert param["Split"] == 1
    assert param["Param"]["Value"] == "a"
    assert param["Rbrace"]["Col"] == 10


def test_to_json_positions_track_the_source(run_shfmt):
    """Position objects carry byte offsets and line/column for each node."""
    # CATCHES: the second word starts at offset 5 (after "echo ") and
    # the file End is at offset 10, proving offsets count bytes.
    proc = run_shfmt(["-ln=zsh", "--to-json"], input_text="echo ${=a}\n")
    tree = json.loads(proc.stdout)
    assert tree["End"]["Offset"] == 10
    assert tree["End"]["Line"] == 1
    assert tree["End"]["Col"] == 11


def test_json_round_trip_formats(run_shfmt):
    """A tree from --to-json formats back to canonical shell via --from-json."""
    # CATCHES: the extra spaces in "echo   hi" are not part of the
    # tree, so formatting the decoded tree yields the canonical form.
    tree = run_shfmt(["--to-json"], input_text="echo   hi\n")
    assert tree.returncode == 0, tree.stderr
    proc = run_shfmt(["--from-json"], input_text=tree.stdout)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo hi\n"


def test_json_round_trip_zsh_construct(run_shfmt):
    """A zsh tree decodes and prints the zsh-only construct unchanged."""
    # CATCHES: decoding must not require the dialect flag again; the
    # Split field in the tree is enough to print ${=a} back.
    tree = run_shfmt(["-ln=zsh", "--to-json"], input_text="echo ${=a}\n")
    assert tree.returncode == 0, tree.stderr
    proc = run_shfmt(["--from-json"], input_text=tree.stdout)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo ${=a}\n"


def test_json_round_trip_is_stable(run_shfmt):
    """Re-encoding a decoded tree reproduces the identical JSON."""
    # CATCHES: the encode/decode pair must be a bijection on the tree,
    # so the second encode equals the first byte for byte.
    first = run_shfmt(["--to-json"], input_text="if true; then echo; fi\n")
    assert first.returncode == 0, first.stderr
    formatted = run_shfmt(["--from-json"], input_text=first.stdout)
    assert formatted.returncode == 0, formatted.stderr
    second = run_shfmt(["--to-json"], input_text=formatted.stdout)
    assert second.returncode == 0, second.stderr
    assert second.stdout == first.stdout
    assert formatted.stdout == "if true; then echo; fi\n"


def test_from_json_simplifies_with_s(run_shfmt):
    """-s applies to a tree loaded from JSON, not just to parsed source."""
    # CATCHES: simplification runs after the --from-json decode, so
    # the redundant parentheses are removed from the decoded tree.
    tree = run_shfmt(["--to-json"], input_text="echo $((a + ((b - c))))\n")
    assert tree.returncode == 0, tree.stderr
    proc = run_shfmt(["--from-json", "-s"], input_text=tree.stdout)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $((a + (b - c)))\n"


def test_to_json_simplifies_with_s(run_shfmt):
    """--to-json -s prints the already simplified tree."""
    # CATCHES: with -s, the encoded tree itself contains the simplified
    # arithmetic, which shows up when the tree is formatted again
    # without -s.
    tree = run_shfmt(["-s", "--to-json"], input_text="echo $((a + ((b - c))))\n")
    assert tree.returncode == 0, tree.stderr
    proc = run_shfmt(["--from-json"], input_text=tree.stdout)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $((a + (b - c)))\n"


@pytest.mark.parametrize(
    ("payload", "expected_err"),
    [
        ("not json", "invalid character 'o' in literal null (expecting 'u')\n"),
        ("", "EOF\n"),
        ('{"Type": "Bogus"}', 'unknown type: "Bogus"\n'),
        ("[]", "cannot decode JSON array into syntax.Node\n"),
    ],
)
def test_from_json_decode_errors(run_shfmt, payload, expected_err):
    """Malformed typed JSON fails with the decoder's exact message."""
    # CATCHES: each failure mode has its own wording, from the stdlib
    # JSON errors to the typed-decoder's "unknown type" message.
    proc = run_shfmt(["--from-json"], input_text=payload)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


def test_to_json_requires_stdin(run_shfmt, tmp_path):
    """--to-json refuses to run on a file argument."""
    # CATCHES: the typed JSON writer only supports the stdin path; a
    # file argument is rejected before any file is read.
    script = tmp_path / "f.sh"
    script.write_text("echo hi\n", encoding="utf-8")
    proc = run_shfmt(["--to-json", str(script)])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "--to-json can only be used with stdin\n"


def test_from_json_requires_stdin(run_shfmt, tmp_path):
    """--from-json refuses to run on a file argument."""
    # CATCHES: like --to-json, decoding is limited to stdin.
    script = tmp_path / "f.sh"
    script.write_text("echo hi\n", encoding="utf-8")
    proc = run_shfmt(["--from-json", str(script)])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "--from-json can only be used with stdin\n"


def test_to_json_and_from_json_conflict(run_shfmt):
    """Both JSON flags at once make shfmt decode stdin as JSON."""
    # CATCHES: --from-json wins for reading stdin, so plain shell input
    # is rejected with a JSON decode error rather than formatted.
    proc = run_shfmt(["--to-json", "--from-json"], input_text="echo hi\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "invalid character 'e' looking for beginning of value\n"


def test_tojson_legacy_alias(run_shfmt):
    """The undocumented --tojson spelling behaves like --to-json."""
    # CATCHES: the flag was registered under both names for backwards
    # compatibility, and the legacy name still prints the typed tree.
    proc = run_shfmt(["--tojson"], input_text="echo hi\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == ECHO_HI_JSON


def test_to_json_with_filename(run_shfmt):
    """--filename names the tree for parsing but changes the JSON none."""
    # CATCHES: with --to-json the default file name is empty, so an
    # explicit --filename only affects which dialect is detected; here
    # .zsh enables zsh parsing of ${+a} and the tree still encodes.
    proc = run_shfmt(["--to-json", "--filename", "s.zsh"], input_text="echo ${+a}\n")
    assert proc.returncode == 0, proc.stderr
    tree = json.loads(proc.stdout)
    param = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert param["Type"] == "ParamExp"
    assert param["IsSet"] is True


def test_to_json_parse_error_has_no_filename(run_shfmt):
    """Parse errors under --to-json lack the "<standard input>" prefix."""
    # CATCHES: when --to-json is active the parser runs with an empty
    # file name, so the position prefix disappears entirely.
    proc = run_shfmt(["--to-json"], input_text="if true\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "1:1: `if <cond>` must be followed by `then`\n"
