"""The simplify walker over node kinds the earlier -s tests never visited.

syntax.Simplify runs syntax.Walk over the whole tree, so every node kind
has a Walk arm that only runs when a construct of that shape is actually
simplified.  Each case here pairs the construct under test with a
redundant-parenthesis marker that -s must still rewrite, proving the
walk reached (and left intact) the construct next to it.
"""

import pytest

# A statement -s always rewrites; its presence proves simplify ran.
MARKER = "echo $((a + ((b - c))))\n"
MARKED = "echo $((a + (b - c)))\n"


@pytest.mark.parametrize(
    ("flags", "construct", "expected"),
    [
        pytest.param(
            ["-s"],
            "echo ${a/b/c}\n",
            "echo ${a/b/c}\n",
            id="repl-paramexp",
        ),
        pytest.param(
            ["-ln=zsh", "-s"],
            "echo $((a[(k)i]))\n",
            "echo $((a[(k)i]))\n",
            id="flags-arithm",
        ),
        pytest.param(
            ["-s"],
            "case $x in\n# lead\na) ;;\nesac\n",
            "case $x in\n# lead\na) ;;\nesac\n",
            id="case-item-comment",
        ),
        pytest.param(
            ["-s"],
            "arr=(\n\tone # first\n\ttwo\n)\n",
            "arr=(\n\tone # first\n\ttwo\n)\n",
            id="array-elem-comment",
        ),
        pytest.param(
            ["-s"],
            "arr=(\n\t# lead\n\tone\n)\n",
            "arr=(\n\t# lead\n\tone\n)\n",
            id="array-elem-leading-comment",
        ),
        pytest.param(
            ["-s"],
            "arr=(\n\t[2]=x # trail\n\tthree\n)\n",
            "arr=(\n\t[2]=x # trail\n\tthree\n)\n",
            id="array-elem-index",
        ),
        pytest.param(
            ["-ln=bats", "-s"],
            '@test "x" {\n\techo\n}\n',
            '@test "x" {\n\techo\n}\n',
            id="bats-testdecl",
        ),
        pytest.param(
            ["-s"],
            "echo !(x)\n",
            "echo !(x)\n",
            id="extglob",
        ),
        pytest.param(
            ["-s"],
            "coproc c { echo; }\n",
            "coproc c { echo; }\n",
            id="coproc-name",
        ),
    ],
)
def test_simplify_walks_the_construct_untouched(run_shfmt, flags, construct,
                                                expected):
    """-s visits each construct and prints it back byte-identical."""
    # CATCHES: the walker must descend through search-and-replace
    # expansions, zsh subscript flags, case-item and array-element
    # comments (kept in place), bats declarations, extglobs and coprocess
    # names without mangling any of them, while the marker statement
    # next to it still loses its redundant parentheses.
    proc = run_shfmt(flags, input_text=construct + MARKER)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected + MARKED
    assert proc.stderr == ""
