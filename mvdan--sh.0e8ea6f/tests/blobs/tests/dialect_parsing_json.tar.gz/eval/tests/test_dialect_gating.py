"""Tests for dialect-dependent acceptance and rejection of syntax.

The same input can format under one -ln value and be a parse error
under another.  The LangError messages name the feature, the dialects
that support it, and the dialect that was used.
"""

import pytest

# (input, exact stderr) for constructs the POSIX dialect rejects.
POSIX_REJECTIONS = [
    (
        "function f { echo; }\n",
        '<standard input>:1:12: the "function" builtin is a bash feature; '
        "tried parsing as posix\n",
    ),
    (
        "a=(1 2)\n",
        "<standard input>:1:3: arrays are a bash/mksh/zsh feature; "
        "tried parsing as posix\n",
    ),
    (
        "echo ${a[0]}\n",
        "<standard input>:1:9: arrays are a bash/mksh/zsh feature; "
        "tried parsing as posix\n",
    ),
    (
        "cat <<< hi\n",
        "<standard input>:1:5: herestrings are a bash/mksh/zsh feature; "
        "tried parsing as posix\n",
    ),
    (
        "cmd &> file\n",
        "<standard input>:1:5: `&>` redirects are a bash/mksh/zsh feature; "
        "tried parsing as posix\n",
    ),
    (
        "echo ${a:1:2}\n",
        "<standard input>:1:9: slicing is a bash/mksh/zsh feature; "
        "tried parsing as posix\n",
    ),
    (
        "echo ${!a}\n",
        "<standard input>:1:6: `${!foo}` is a bash/mksh feature; "
        "tried parsing as posix\n",
    ),
    (
        "echo ${a/b/c}\n",
        "<standard input>:1:9: search and replace is a bash/mksh/zsh feature; "
        "tried parsing as posix\n",
    ),
    (
        "for ((i=0; i<3; i++)); do echo $i; done\n",
        "<standard input>:1:5: c-style fors are a bash/zsh feature; "
        "tried parsing as posix\n",
    ),
    (
        "exec {fd}> file\n",
        "<standard input>:1:6: `{varname}` redirects are a bash/zsh feature; "
        "tried parsing as posix\n",
    ),
    (
        "select x in a b; do echo; done\n",
        "<standard input>:1:18: `do` can only be used in a loop\n",
    ),
]


@pytest.mark.parametrize(("script", "expected_err"), POSIX_REJECTIONS)
def test_posix_rejects_bash_features(run_shfmt, script, expected_err):
    """POSIX mode rejects each bash/ksh extension with its own message."""
    # CATCHES: each feature has its own wording and column position; a
    # re-implementation must reproduce every message and offset exactly.
    proc = run_shfmt(["-ln=posix"], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("script", "expected_out"),
    [
        ("function f { echo; }\n", "function f { echo; }\n"),
        ("a=(1 2)\n", "a=(1 2)\n"),
        ("echo ${a[0]}\n", "echo ${a[0]}\n"),
        ("cat <<< hi\n", "cat <<<hi\n"),
        ("cmd &> file\n", "cmd &>file\n"),
        ("echo ${a:1:2}\n", "echo ${a:1:2}\n"),
        ("echo ${!a}\n", "echo ${!a}\n"),
        ("echo ${a/b/c}\n", "echo ${a/b/c}\n"),
        (
            "for ((i=0; i<3; i++)); do echo $i; done\n",
            "for ((i = 0; i < 3; i++)); do echo $i; done\n",
        ),
        ("exec {fd}> file\n", "exec {fd}>file\n"),
        ("select x in a b; do echo; done\n", "select x in a b; do echo; done\n"),
    ],
)
def test_bash_accepts_the_same_constructs(run_shfmt, script, expected_out):
    """Every construct rejected by posix is accepted under -ln=bash."""
    # CATCHES: the dialect gate is the only difference; the identical
    # inputs must succeed under bash and print the recorded output,
    # including the printer's normalizations like "<<< hi" to "<<<hi".
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stderr == ""
    assert proc.stdout == expected_out


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        (
            "echo ${=a}\n",
            "<standard input>:1:8: invalid parameter name\n",
        ),
        (
            "echo ${(e)a}\n",
            "<standard input>:1:6: parameter expansion flags are a zsh feature; "
            "tried parsing as bash\n",
        ),
        (
            "echo ${+a}\n",
            "<standard input>:1:6: `${+foo}` is a zsh feature; "
            "tried parsing as bash\n",
        ),
        (
            "function a b { echo; }\n",
            "<standard input>:1:1: multi-name functions are a zsh feature; "
            "tried parsing as bash\n",
        ),
        (
            "() { a; }\n",
            "<standard input>:1:1: anonymous functions are a zsh feature; "
            "tried parsing as bash\n",
        ),
        (
            "function { echo hi; }\n",
            "<standard input>:1:1: anonymous functions are a zsh feature; "
            "tried parsing as bash\n",
        ),
        (
            "foo &|\nbar\n",
            "<standard input>:1:6: `|` can only immediately follow a statement\n",
        ),
        (
            "echo $((1.5 + 1))\n",
            "<standard input>:1:10: floating point arithmetic is a zsh feature; "
            "tried parsing as bash\n",
        ),
    ],
)
def test_zsh_only_constructs_rejected_by_bash(run_shfmt, script, expected_err):
    """zsh-specific syntax fails under bash with exact error positions."""
    # CATCHES: zsh extensions each have their own failure mode; note
    # ${=a} yields a plain parse error, not a dialect-suggestion error.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("script", "expected_out"),
    [
        ("echo ${=a}\n", "echo ${=a}\n"),
        ("echo ${(e)a}\n", "echo ${(e)a}\n"),
        ("echo ${+a}\n", "echo ${+a}\n"),
        ("function a b { echo; }\n", "function a b { echo; }\n"),
        ("() { a; }\n", "() { a; }\n"),
        ("foo &!\n", "foo &|\n"),
    ],
)
def test_zsh_accepts_its_own_constructs(run_shfmt, script, expected_out):
    """The same zsh constructs are accepted (and normalized) under -ln=zsh."""
    # CATCHES: zsh mode must accept every construct bash rejected, and
    # the disown operator &! is even normalized to its &| spelling.
    proc = run_shfmt(["-ln=zsh"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected_out


def test_mksh_case_braces_are_canonicalized(run_shfmt):
    """mksh's `case name {` form is accepted and printed as `in`/`esac`."""
    # CATCHES: mksh is the only dialect accepting the brace form, and
    # the printer always emits the canonical in/esac spelling.
    proc = run_shfmt(["-ln=mksh"], input_text="case $a { x) echo;; }\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "case $a in x) echo ;; esac\n"


def test_mksh_case_braces_rejected_elsewhere(run_shfmt):
    """The mksh `case name {` form is a dialect error under bash."""
    # CATCHES: the message names mksh alone as the supporting dialect,
    # and the feature check happens at the very first token (1:1).
    proc = run_shfmt(["-ln=bash"], input_text="case $a { x) echo;; }\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:1:1: `case i {` is a mksh feature; "
        "tried parsing as bash\n"
    )


def test_mksh_coprocess_pipe(run_shfmt):
    """A trailing `|&` is mksh's coprocess syntax and formats unchanged."""
    # CATCHES: under mksh `foo |&` is a complete coprocess statement,
    # while bash and zsh demand a right-hand side for the pipe.
    proc = run_shfmt(["-ln=mksh"], input_text="foo |&\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "foo |&\n"


def test_bash_pipe_all_requires_a_statement(run_shfmt):
    """In bash, `|&` is a pipe-all operator and needs a right-hand side."""
    # CATCHES: bash rejects the bare `foo |&` that mksh accepts, and
    # even a complete `a |& b` is printed on one line under bash.
    proc = run_shfmt(["-ln=bash"], input_text="foo |&\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:1:5: `|&` must be followed by a statement\n"
    )
    proc2 = run_shfmt(["-ln=bash"], input_text="echo a |& cat\n")
    assert proc2.returncode == 0, proc2.stderr
    assert proc2.stdout == "echo a |& cat\n"


def test_mksh_pipe_all_splits_lines(run_shfmt):
    """Under mksh, `a |& b` parses as a coprocess followed by a command."""
    # CATCHES: the same input is formatted completely differently under
    # mksh: the pipe-all operator becomes a coprocess and a new line.
    proc = run_shfmt(["-ln=mksh"], input_text="echo a |& cat\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo a |&\ncat\n"


def test_bats_test_declaration(run_shfmt):
    """The @test declaration is accepted only by the bats dialect."""
    # CATCHES: bats is a small extension of bash; only it accepts the
    # `@test "name" { ... }` compound declaration.
    proc = run_shfmt(["-ln=bats"], input_text='@test "n" { echo; }\n')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '@test "n" { echo; }\n'


def test_bats_test_declaration_rejected_by_bash(run_shfmt):
    """Under bash, the @test body's closing brace is the first error seen."""
    # CATCHES: without the bats extension the `}` of the test body is
    # unmatched, so the error is about the brace, not about @test.
    proc = run_shfmt(["-ln=bash"], input_text='@test "n" { echo; }\n')
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:1:19: `}` can only be used to close a block\n"
    )


def test_bash_case_modification_operator(run_shfmt):
    """The ${a^} case-modification operator is bash-only."""
    # CATCHES: mksh and zsh reject it too, each naming bash as the
    # dialect that supports "this expansion operator".
    for dialect in ("posix", "mksh", "zsh"):
        proc = run_shfmt(["-ln=" + dialect], input_text="echo ${a^}\n")
        assert proc.returncode == 1, dialect
        assert proc.stderr == (
            "<standard input>:1:9: this expansion operator is a bash feature; "
            "tried parsing as %s\n" % dialect
        )
    proc = run_shfmt(["-ln=bash"], input_text="echo ${a^}\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo ${a^}\n"


def test_zsh_rejects_bash_indirection(run_shfmt):
    """The ${!a} indirection works in bash and mksh but not zsh."""
    # CATCHES: zsh rejects a bash construct, showing the gate matrix is
    # not a simple "bash is the superset" relation.
    proc = run_shfmt(["-ln=zsh"], input_text="echo ${!a}\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:1:6: `${!foo}` is a bash/mksh feature; "
        "tried parsing as zsh\n"
    )


def test_mksh_lacks_regex_matching(run_shfmt):
    """The =~ regex test works in bash and zsh but is rejected by mksh."""
    # CATCHES: mksh does not support =~ inside test blocks; the error
    # is reported at the operator position (1:7).
    proc = run_shfmt(["-ln=mksh"], input_text="[[ $a =~ ^b$ ]]\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:1:7: regex tests are a bash/zsh feature; "
        "tried parsing as mksh\n"
    )


@pytest.mark.parametrize("dialect", ["bash", "zsh"])
def test_regex_matching_accepted(run_shfmt, dialect):
    """bash and zsh accept the =~ regex test and keep it unchanged."""
    # CATCHES: the dialect matrix must accept =~ exactly where mksh
    # rejects it.
    proc = run_shfmt(["-ln=" + dialect], input_text="[[ $a =~ ^b$ ]]\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[[ $a =~ ^b$ ]]\n"


@pytest.mark.parametrize("dialect", ["posix", "mksh"])
def test_process_substitution_rejected(run_shfmt, dialect):
    """posix and mksh treat `(` after `<` as an invalid redirect target."""
    # CATCHES: the rejection is a plain parse error about the redirect,
    # not a LangError naming the dialects that support it.
    proc = run_shfmt(["-ln=" + dialect], input_text="cat <(echo hi)\n")
    assert proc.returncode == 1
    assert proc.stderr == "<standard input>:1:5: `<` must be followed by a word\n"


@pytest.mark.parametrize("dialect", ["bash", "zsh"])
def test_process_substitution_accepted(run_shfmt, dialect):
    """bash and zsh parse process substitution without complaint."""
    # CATCHES: the same input that posix rejects must pass here.
    proc = run_shfmt(["-ln=" + dialect], input_text="cat <(echo hi)\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "cat <(echo hi)\n"


def test_double_brackets_are_words_in_posix(run_shfmt):
    """`[[ -n $a ]]` is not gated: posix parses it as a plain command."""
    # CATCHES: the [[ ]] delimiters are only special in the dialects
    # that support them; in posix the line is a normal command call and
    # formats identically under every dialect.
    for dialect in ("bash", "posix", "mksh", "zsh"):
        proc = run_shfmt(["-ln=" + dialect], input_text="[[ -n $a ]]\n")
        assert proc.returncode == 0, dialect
        assert proc.stdout == "[[ -n $a ]]\n"


def test_posix_redirect_before_block_is_zsh_only(run_shfmt):
    """A redirect in front of a block is zsh syntax, rejected elsewhere."""
    # CATCHES: zsh moves the redirect after the block when printing,
    # while other dialects report it at position 1:1.
    proc = run_shfmt(["-ln=bash"], input_text="> file { echo hi; }\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:1:1: redirects before compound commands are a zsh "
        "feature; tried parsing as bash\n"
    )
    proc2 = run_shfmt(["-ln=zsh"], input_text="> file { echo hi; }\n")
    assert proc2.returncode == 0, proc2.stderr
    assert proc2.stdout == "{ echo hi; } >file\n"


def test_bash_error_mentions_bash_not_bats(run_shfmt):
    """A bash-like feature error names bash, hiding the bats variant."""
    # CATCHES: bash and bats form one "bash-like" group internally, but
    # the user-facing message only ever says "bash" and never "bats";
    # the exact-match assertion pins the whole string.
    proc = run_shfmt(["-ln=posix"], input_text="function f { echo; }\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        '<standard input>:1:12: the "function" builtin is a bash feature; '
        "tried parsing as posix\n"
    )
