"""Tests for the --exp.recover parser option.

RecoverErrors lets the parser skip up to N syntax errors on a best
effort basis, printing recovered output instead of failing.  Recovered
positions print as "??:??" when they do not exist in the input.
"""

import json

import pytest


def test_recover_unterminated_quote(run_shfmt):
    """One recoverable error: the missing closing quote is filled in."""
    # CATCHES: recovery rewrites the output by appending the closing
    # quote after the final newline, and the run succeeds with exit 0.
    proc = run_shfmt(["--exp.recover", "1"], input_text='echo "unterminated\n')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == 'echo "unterminated\n"\n'
    assert proc.stderr == ""


def test_recover_missing_case_terminators(run_shfmt):
    """A case clause missing ';;' and 'esac' is completed by recovery."""
    # CATCHES: both terminators are synthesized in the output
    # ("x) ;; esac"), showing multiple mandatory tokens recovered at
    # once from a single error budget of one.
    proc = run_shfmt(["--exp.recover", "1"], input_text="case $a in x)\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "case $a in x) ;; esac\n"


def test_recover_subshell_and_pipe(run_shfmt):
    """Recovering both the pipe target and the closing paren prints "(foo |)"."""
    # CATCHES: two errors need a budget of two; the synthesized ")"
    # appears in the printed statement even though it is not in the
    # input.
    proc = run_shfmt(["--exp.recover", "2"], input_text="(foo |\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "(foo |)\n"


def test_recover_budget_too_small_for_subshell(run_shfmt):
    """With a budget of one, the second error still fails the run."""
    # CATCHES: recovery is bounded; the pipe is recovered but the
    # unclosed subshell then aborts with a different message than
    # without any recovery at all.
    proc = run_shfmt(["--exp.recover", "1"], input_text="(foo |\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:1: reached EOF without matching `(` with `)`\n"
    )


def test_recover_changes_the_error_message(run_shfmt):
    """A recovered "if" reports the follow-up error at a ??:?? position."""
    # CATCHES: recovering the missing `then` moves the failure to the
    # statement list, and the synthesized position prints as "?:?:"
    # because no real position exists for it.
    proc = run_shfmt(["--exp.recover", "1"], input_text="if true\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:?:?: `then` must be followed by a statement list\n"
    )


def test_recover_while_missing_done(run_shfmt):
    """Recovering a missing `done` still fails on the statement list."""
    # CATCHES: like the if case, the error moves past the recovered
    # token; here the position stays real (1:1) pointing at `while`.
    proc = run_shfmt(["--exp.recover", "1"], input_text="while true\ndo\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:1:1: `while` statement must end with `done`\n"
    )


def test_recover_covers_a_later_statement(run_shfmt):
    """An error on the second statement is recovered like the first."""
    # CATCHES: recovery is not limited to the first statement; the
    # unterminated quote on line two is closed and both lines print.
    proc = run_shfmt(
        ["--exp.recover", "1"], input_text='echo one\necho "two\n'
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == 'echo one\necho "two\n"\n'


def test_recover_zero_behaves_like_default(run_shfmt):
    """--exp.recover 0 keeps the normal first-error behavior."""
    # CATCHES: the default budget is zero, so passing 0 explicitly must
    # produce the unrecovered message and exit code.
    for args in ([], ["--exp.recover", "0"]):
        proc = run_shfmt(args, input_text="if true\n")
        assert proc.returncode == 1
        assert proc.stderr == (
            "<standard input>:1:1: `if <cond>` must be followed by `then`\n"
        )


def test_recover_negative_is_ignored(run_shfmt):
    """A negative budget behaves like zero instead of being an error."""
    # CATCHES: the flag is a plain int, so -1 is accepted and the
    # comparison "recovered < maximum" simply never recovers.
    proc = run_shfmt(["--exp.recover", "-1"], input_text="if true\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:1:1: `if <cond>` must be followed by `then`\n"
    )


def test_recover_non_numeric_value(run_shfmt):
    """A non-numeric --exp.recover value is a flag parse error."""
    # CATCHES: the value is parsed as an int by the flag package, which
    # yields the exact "parse error" wording and exit code 2.
    proc = run_shfmt(["--exp.recover=abc"], input_text="echo hi\n")
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr.startswith(
        'invalid value "abc" for flag -exp.recover: parse error\n'
    )
    assert "usage: shfmt [flags] [path ...]" in proc.stderr


def test_recover_does_not_recover_lang_errors(run_shfmt):
    """Dialect errors are not recoverable, whatever the budget."""
    # CATCHES: recovery only covers missing mandatory tokens; the
    # arrays-under-posix LangError is fatal even with a large budget.
    proc = run_shfmt(
        ["--exp.recover", "5", "-ln=posix"], input_text="a=(1 2)\n"
    )
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:3: arrays are a bash/mksh/zsh feature; "
        "tried parsing as posix\n"
    )


def test_recovered_nodes_in_json(run_shfmt):
    """Recovered positions and missing nodes show up in the typed JSON."""
    # CATCHES: the recovered pipe target is an empty Y command object,
    # and the synthesized closing paren keeps the subshell node intact.
    proc = run_shfmt(["--exp.recover", "2", "--to-json"], input_text="(foo |\n")
    assert proc.returncode == 0, proc.stderr
    tree = json.loads(proc.stdout)
    assert tree["Type"] == "File"
    subshell = tree["Stmts"][0]["Cmd"]
    assert subshell["Type"] == "Subshell"
    pipe = subshell["Stmts"][0]["Cmd"]
    assert pipe["Type"] == "BinaryCmd"
    assert pipe["Op"] == "|"
    assert pipe["X"]["Cmd"]["Type"] == "CallExpr"
    assert pipe["Y"] == {}


def test_recover_keeps_editorconfig_active(run_shfmt, tmp_path):
    """--exp.recover does not count as a parser flag, so EditorConfig applies."""
    # CATCHES: only -ln/-p/-s and the printer flags disable the
    # EditorConfig lookup; a shell_variant=zsh section must still take
    # effect together with --exp.recover.
    (tmp_path / ".editorconfig").write_text(
        "[[shell]]\nshell_variant = zsh\n", encoding="utf-8"
    )
    proc = run_shfmt(["--exp.recover", "1", "--filename", "s.sh"], input_text="echo ${+a}\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo ${+a}\n"
