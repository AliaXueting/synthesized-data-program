"""Construct "zoo" scripts: every node type through format, -s and JSON.

One script per dialect exercises (nearly) every syntax node the parser
can build.  Pinning the exact formatted output, the node-type set of the
--to-json encoding, and the --from-json round trip forces a
re-implementation to handle each construct's parse, tree and print path
together, and runs the simplify walker over every node-type arm.
"""

import json


BASH_ZOO = """\
#!/bin/bash
# leading comment
if [ -e x ]; then
\techo a
elif [ -e y ]; then
\techo b
else
\techo c
fi
while read -r line; do
\techo "$line"
done <f
until false; do
\tbreak
done
for i in 1 2 3; do
\techo "$i"
done
for ((i = 0; i < 3; i++)); do
\techo "$i"
done
case $x in
\ta) echo a ;;
\tb | c) echo bc ;; # case comment
\t*) echo other ;;
esac
select opt in a b; do
\techo "$opt"
done
foo() (
\techo subshell
)
function bar {
\techo block # trailing comment
}
{ echo braced; }
a=1 b=$((1 + 2)) cmd arg
a[0]=x
arr=(one two [2]=three)
echo ${arr[@]:1:2} ${!arr[@]} ${arr#o} "${arr[*]}"
echo $((1 + 2 * 3))
[[ -n $x && $y == z ]] && echo yes || echo no
echo hi | tr a-z A-Z |& cat
time ls
coproc c { echo hi; }
let "a = 1 + 2"
declare -i x=1
export z=3
readonly w=4
echo !(x) @(y) ?(z) *(w) +(v)
echo <(cmd) >(cmd2)
cat <<EOF
heredoc $x
EOF
cat <<-TAB
\ttabbed
\tTAB
cat <<<word
! true
echo `backquote`
echo $'raw\\n' $"localized"
{
\techo nested
} | tee out
if [ -e x ]; then echo one; fi
echo $((a + ((b - c))))
# trailing comment
"""

BASH_ZOO_FORMATTED = """\
#!/bin/bash
# leading comment
if [ -e x ]; then
\techo a
elif [ -e y ]; then
\techo b
else
\techo c
fi
while read -r line; do
\techo "$line"
done <f
until false; do
\tbreak
done
for i in 1 2 3; do
\techo "$i"
done
for ((i = 0; i < 3; i++)); do
\techo "$i"
done
case $x in
a) echo a ;;
b | c) echo bc ;; # case comment
*) echo other ;;
esac
select opt in a b; do
\techo "$opt"
done
foo() (
\techo subshell
)
function bar {
\techo block # trailing comment
}
{ echo braced; }
a=1 b=$((1 + 2)) cmd arg
a[0]=x
arr=(one two [2]=three)
echo ${arr[@]:1:2} ${!arr[@]} ${arr#o} "${arr[*]}"
echo $((1 + 2 * 3))
[[ -n $x && $y == z ]] && echo yes || echo no
echo hi | tr a-z A-Z |& cat
time ls
coproc c { echo hi; }
let "a = 1 + 2"
declare -i x=1
export z=3
readonly w=4
echo !(x) @(y) ?(z) *(w) +(v)
echo <(cmd) >(cmd2)
cat <<EOF
heredoc $x
EOF
cat <<-TAB
\ttabbed
TAB
cat <<<word
! true
echo $(backquote)
echo $'raw\\n' $"localized"
{
\techo nested
} | tee out
if [ -e x ]; then echo one; fi
echo $((a + ((b - c))))
# trailing comment
"""

# -s output differs from the plain output only in the last echo.
BASH_ZOO_SIMPLIFIED = BASH_ZOO_FORMATTED.replace(
    "echo $((a + ((b - c))))", "echo $((a + (b - c)))"
)

ZSH_ZOO = """\
#!/bin/zsh
foo() { echo hi; }
function multi one two { echo hi; }
function { echo anon; }
() { echo anon2; }
echo ${+a} ${=a} ${(e)a} ${a:u} ${a:#pat}
echo ${a[1,2]} ${a[(k)x]}
echo ${(j.:.)a} ${(s.:.)a} ${(@)a}
echo $((1.5 + 1)) $((a[(k)i]))
echo <1-10> <->
case $x in <1-5>) echo num ;; esac
foo &!
exec {fd}>file
echo ${a:|b} ${a:*b}
"""

ZSH_ZOO_FORMATTED = """\
#!/bin/zsh
foo() { echo hi; }
function multi one two { echo hi; }
function { echo anon; }
() { echo anon2; }
echo ${+a} ${=a} ${(e)a} ${a:u} ${a:#pat}
echo ${a[1,2]} ${a[(k)x]}
echo ${(j.:.)a} ${(s.:.)a} ${(@)a}
echo $((1.5 + 1)) $((a[(k)i]))
echo <1-10> <->
case $x in <1-5>) echo num ;; esac
foo &|
exec {fd}>file
echo ${a:|b} ${a:*b}
"""

BATS_ZOO = """\
#!/usr/bin/env bats
@test "first" {
\techo body
}
@test "second" {
\t[ -e x ]
\tskip
}
"""

BATS_ZOO_FORMATTED = """\
#!/usr/bin/env bats
@test "first" {
\techo body
}
@test "second" {
\t[ -e x ]
\tskip
}
"""

MKSH_ZOO = """\
#!/bin/mksh
case $a {
\tx) echo ;;
}
echo ${|foo;}
foo |& bar
echo $((# a))
echo ${a%b} ${a[#]}
"""

MKSH_ZOO_FORMATTED = """\
#!/bin/mksh
case $a in
x) echo ;;
esac
echo ${|foo;}
foo |&
bar
echo $((# a))
echo ${a%b} ${a[#]}
"""


def _node_types(tree):
    """Every "Type" tag used in the encoded tree, as a sorted list."""
    found = set()

    def walk(obj):
        if isinstance(obj, dict):
            if "Type" in obj:
                found.add(obj["Type"])
            for value in obj.values():
                walk(value)
        elif isinstance(obj, list):
            for value in obj:
                walk(value)

    walk(tree)
    return sorted(found)


def test_bash_zoo_formats(run_shfmt):
    """A bash script using every construct formats byte-for-byte."""
    # CATCHES: case bodies print unindented by default, <<- drops the
    # closing delimiter's tab, backquotes canonicalize to $(), and the
    # shebang line survives as a comment.
    proc = run_shfmt(["-"], input_text=BASH_ZOO)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == BASH_ZOO_FORMATTED


def test_bash_zoo_simplify_walks_every_node(run_shfmt):
    """-s traverses the whole tree; only the redundant parens change."""
    # CATCHES: simplify runs a full-tree walk, so the only diff between
    # the plain and simplified output is $((a + ((b - c)))) losing one
    # pair of parentheses.
    proc = run_shfmt(["-s", "-"], input_text=BASH_ZOO)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == BASH_ZOO_SIMPLIFIED


def test_bash_zoo_json_type_names(run_shfmt):
    """--to-json emits the type name of every bash construct in the zoo."""
    # CATCHES: each node type has its own "Type" tag; a re-implementation
    # missing a node kind (or renaming it) changes this exact set.
    proc = run_shfmt(["--to-json"], input_text=BASH_ZOO)
    assert proc.returncode == 0, proc.stderr
    assert _node_types(json.loads(proc.stdout)) == [
        "ArithmExp", "BinaryArithm", "BinaryCmd", "BinaryTest", "Block",
        "CStyleLoop", "CallExpr", "CaseClause", "CmdSubst", "CoprocClause",
        "DblQuoted", "DeclClause", "ExtGlob", "File", "ForClause",
        "FuncDecl", "IfClause", "LetClause", "Lit", "ParamExp",
        "ParenArithm", "ProcSubst", "SglQuoted", "Subshell", "TestClause",
        "TimeClause", "UnaryArithm", "UnaryTest", "WhileClause", "Word",
        "WordIter",
    ]


def test_bash_zoo_json_round_trip(run_shfmt):
    """Encoding the zoo and decoding it formats to the same bytes."""
    # CATCHES: every node's fields must survive the typed JSON round trip;
    # a lost position or operator field changes the printed output.
    encoded = run_shfmt(["--to-json"], input_text=BASH_ZOO)
    assert encoded.returncode == 0, encoded.stderr
    decoded = run_shfmt(["--from-json"], input_text=encoded.stdout)
    assert decoded.returncode == 0, decoded.stderr
    assert decoded.stdout == BASH_ZOO_FORMATTED


def test_zsh_zoo_formats_via_stdin_shebang(run_shfmt):
    """A zsh zoo script formats after shebang auto-detection from stdin."""
    # CATCHES: zsh-only constructs (multi-name/anon functions, ${+a},
    # subscript flags, float arithmetic, <1-10> ranges, &! clobbers) all
    # survive, with &! canonicalized to &| and the shebang picked up from
    # the stdin bytes without any flag.
    proc = run_shfmt(["-"], input_text=ZSH_ZOO)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == ZSH_ZOO_FORMATTED


def test_zsh_zoo_json_type_names(run_shfmt):
    """The zsh zoo encodes the zsh-only node kinds FlagsArithm."""
    # CATCHES: $((a[(k)i])) builds a FlagsArithm node, which has no bash
    # counterpart; its "Type" tag must be emitted for the tree to decode.
    proc = run_shfmt(["-ln=zsh", "--to-json"], input_text=ZSH_ZOO)
    assert proc.returncode == 0, proc.stderr
    assert _node_types(json.loads(proc.stdout)) == [
        "ArithmExp", "BinaryArithm", "Block", "CallExpr", "CaseClause",
        "File", "FlagsArithm", "FuncDecl", "Lit", "ParamExp", "Word",
    ]


def test_zsh_zoo_json_round_trip(run_shfmt):
    """The zsh zoo survives a typed JSON encode/decode round trip."""
    # CATCHES: zsh-only fields (subscript flags, modifiers, numrange
    # globs) must round trip or the formatted output changes.
    encoded = run_shfmt(["-ln=zsh", "--to-json"], input_text=ZSH_ZOO)
    assert encoded.returncode == 0, encoded.stderr
    decoded = run_shfmt(["--from-json"], input_text=encoded.stdout)
    assert decoded.returncode == 0, decoded.stderr
    assert decoded.stdout == ZSH_ZOO_FORMATTED


def test_bats_zoo_formats_via_env_shebang(run_shfmt):
    """A bats zoo script formats after '#!/usr/bin/env bats' detection."""
    # CATCHES: the env-form shebang selects the bats dialect, under which
    # @test declarations are TestDecl nodes rather than syntax errors.
    proc = run_shfmt(["-"], input_text=BATS_ZOO)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == BATS_ZOO_FORMATTED


def test_bats_zoo_json_type_names(run_shfmt):
    """The bats zoo encodes the bats-only TestDecl node type."""
    # CATCHES: @test bodies are TestDecl nodes with a Description word;
    # the type tag must exist or the tree cannot be decoded back.
    proc = run_shfmt(["-ln=bats", "--to-json"], input_text=BATS_ZOO)
    assert proc.returncode == 0, proc.stderr
    assert _node_types(json.loads(proc.stdout)) == [
        "Block", "CallExpr", "DblQuoted", "File", "Lit", "TestDecl",
    ]


def test_bats_zoo_json_round_trip(run_shfmt):
    """The bats zoo survives a typed JSON encode/decode round trip."""
    # CATCHES: the TestDecl Description string must round trip or the
    # @test line prints with the wrong quoted body.
    encoded = run_shfmt(["-ln=bats", "--to-json"], input_text=BATS_ZOO)
    assert encoded.returncode == 0, encoded.stderr
    decoded = run_shfmt(["--from-json"], input_text=encoded.stdout)
    assert decoded.returncode == 0, decoded.stderr
    assert decoded.stdout == BATS_ZOO_FORMATTED


def test_mksh_zoo_formats(run_shfmt):
    """A mksh zoo script canonicalizes the Korn case and coprocess pipe."""
    # CATCHES: 'case $a {' reprints with in/esac, the value-of ${|foo;}
    # and unsigned $((# a)) parse only under mksh, and 'foo |& bar' is a
    # coprocess pipe that splits into two statements.
    proc = run_shfmt(["-ln=mksh", "-"], input_text=MKSH_ZOO)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == MKSH_ZOO_FORMATTED


def test_mksh_zoo_json_round_trip(run_shfmt):
    """The mksh zoo survives a typed JSON encode/decode round trip."""
    # CATCHES: the CoprocClause built from 'foo |&' and the value-of
    # CmdSubst must round trip, including their mksh-only spellings.
    encoded = run_shfmt(["-ln=mksh", "--to-json"], input_text=MKSH_ZOO)
    assert encoded.returncode == 0, encoded.stderr
    decoded = run_shfmt(["--from-json"], input_text=encoded.stdout)
    assert decoded.returncode == 0, decoded.stderr
    assert decoded.stdout == MKSH_ZOO_FORMATTED
