"""Remaining syntax corners: alias spellings, buried heredocs, EOF arms.

Each test here pins a construct family the earlier files do not reach:
the zsh '!'-spelled clobber redirects and their aliases, the procsubst
dialect gate, heredocs buried inside case items and subshell bodies,
comments inside array literals, special parameter names, extglob case
patterns, brace and regex literals, parenthesised function names, deeply
nested backquotes, and the parse errors that fire at end of input.
"""

import pytest


def test_zsh_clobber_bang_spellings(run_shfmt):
    """Zsh '!'-spelled clobbers canonicalize to their '|' spellings."""
    # CATCHES: >&! >>! >>& &>! &>>! >>&| >>&! >&| >! are nine distinct
    # lexer arms that all reuse an existing token; the printer then emits
    # only the '|' spellings of each clobber operator.
    proc = run_shfmt(
        ["-ln=zsh", "-"],
        input_text="a >&!f\ng >>!h\ni >>&j\nk &>!l\nm &>>!n\n"
        "o >>&|p\nq >>&!r\ns >&|t\nu >!v\n",
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        "a &>|f\ng >>|h\ni &>>j\nk &>|l\nm &>>|n\n"
        "o &>>|p\nq &>>|r\ns &>|t\nu >|v\n"
    )


@pytest.mark.parametrize("dialect", ["posix", "mksh"])
def test_procsubst_dialect_gate(run_shfmt, dialect):
    """Process substitution only lexes under bash-like dialects and zsh."""
    # CATCHES: after '>' the '(' arm is gated on the language, so under
    # posix and mksh the '>' has no word after it and the error blames
    # the '>' itself, not the '('.
    proc = run_shfmt([f"-ln={dialect}", "-"], input_text="echo >(x)\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "<standard input>:1:6: `>` must be followed by a word\n"


def test_heredoc_buried_in_case_item(run_shfmt):
    """A heredoc inside a case item forces the item onto multiple lines."""
    # CATCHES: the heredoc body is collected while the case clause is
    # still open (a "buried" heredoc), so the item must print the body
    # inline between the pattern and its ;; terminator.
    proc = run_shfmt(
        ["-"],
        input_text="case $x in\na) cat <<EOF\nbody\nEOF\n\t;;\nesac\n",
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "case $x in\na)\n\tcat <<EOF\nbody\nEOF\n\t;;\nesac\n"


def test_heredoc_buried_in_subshell_body(run_shfmt):
    """A heredoc inside a subshell function body survives verbatim."""
    # CATCHES: the subshell body keeps the heredoc bytes attached to the
    # statement that owns them, including the terminator line.
    proc = run_shfmt(
        ["-"], input_text="foo() (\n\tcat <<EOF\nbody\nEOF\n)\n"
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "foo() (\n\tcat <<EOF\nbody\nEOF\n)\n"


@pytest.mark.parametrize(
    ("source", "expected"),
    [
        pytest.param(
            "arr=(\n\tone # first\n\ttwo\n\t# standalone\n)\n",
            "arr=(\n\tone # first\n\ttwo\n\t# standalone\n)\n",
            id="array-comments",
        ),
        pytest.param(
            "a\n# standalone comment\nb\n",
            "a\n# standalone comment\nb\n",
            id="between-stmts",
        ),
        pytest.param(
            "case $x in # c\na) ;;\nesac\n",
            "case $x in # c\na) ;;\nesac\n",
            id="after-in",
        ),
    ],
)
def test_comments_in_unusual_slots(run_shfmt, source, expected):
    """Comments attach to array elements, statements and case headers."""
    # CATCHES: comment collection runs while filling array literals and
    # after 'case ... in', so those comments must be reprinted verbatim
    # rather than dropped.
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "source",
    [
        "echo ${#} ${?} ${$} ${!} ${-} ${*} ${@}\n",
        "echo ${#?} ${#-}\n",
    ],
)
def test_special_parameter_names(run_shfmt, source):
    """Single-character special parameter names expand inside braces."""
    # CATCHES: '#', '?', '$', '!', '-', '*' and '@' are the only
    # non-identifier parameter names, and '${#?}' / '${#-}' keep the
    # special name after the length operator.
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


def test_extglob_case_patterns(run_shfmt):
    """Extended globs are valid case patterns and print unchanged."""
    # CATCHES: the lexer detects an extglob while reading a case pattern,
    # not only in plain words, so '!(a)' and '@(b|c)' stay patterns.
    proc = run_shfmt(
        ["-"], input_text="case $x in\n!(a)) echo ;;\n@(b|c)) echo ;;\nesac\n"
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "case $x in\n!(a)) echo ;;\n@(b|c)) echo ;;\nesac\n"


def test_brace_literal_words(run_shfmt):
    """Brace-expansion-looking words are literals and pass through."""
    # CATCHES: the lexer marks a word starting '{' under bash-like
    # dialects, but the parser keeps the braces as plain literal text.
    proc = run_shfmt(["-"], input_text="echo a{1,2}b {x,y}\necho {a,b}{c,d}\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo a{1,2}b {x,y}\necho {a,b}{c,d}\n"


def test_regex_operand_forms(run_shfmt):
    """A =~ regex takes escapes, quotes, expansions and nested groups."""
    # CATCHES: the regex operand is read as a raw literal that honors
    # backslash escapes and quotes, while backquotes still turn into $();
    # nested parentheses must all reach the pattern.
    proc = run_shfmt(
        ["-"],
        input_text='[[ $x =~ a\\.b ]]\n[[ $x =~ \'a|b\' ]]\n[[ $x =~ "re" ]]\n'
        "[[ $x =~ $re ]]\n[[ $x =~ `re` ]]\n[[ $x =~ (a|(b|c)) ]]\n",
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '[[ $x =~ a\\.b ]]\n[[ $x =~ \'a|b\' ]]\n[[ $x =~ "re" ]]\n'
        "[[ $x =~ $re ]]\n[[ $x =~ $(re) ]]\n[[ $x =~ (a|(b|c)) ]]\n"
    )


def test_function_name_parens_normalized(run_shfmt):
    """'function f()' and 'function g ()' both print without the space."""
    # CATCHES: after the 'function' keyword an optional '()' is lexed
    # separately from the name, and the printer always emits it tight.
    proc = run_shfmt(
        ["-"], input_text="function f() { echo; }\nfunction g () { echo; }\n"
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "function f() { echo; }\nfunction g() { echo; }\n"


def test_triply_nested_backquotes(run_shfmt):
    """Three levels of escaped backquotes flatten to nested $( )."""
    # CATCHES: each nesting level needs one more backslash before its
    # backquote, and only the outer two levels become command
    # substitutions; the innermost escapes are left as literal text.
    proc = run_shfmt(
        ["-"], input_text="echo `echo \\`echo \\\\\\`x\\\\\\` y\\` z`\n"
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $(echo $(echo \\`x\\` y) z)\n"


@pytest.mark.parametrize(
    ("source", "message"),
    [
        pytest.param(
            "echo $((a[))\n",
            "<standard input>:1:10: `[` must be followed by an expression\n",
            id="arith-open-bracket",
        ),
        pytest.param(
            "echo ${\n",
            "<standard input>:1:6: reached EOF without matching `${` with `}`\n",
            id="param-exp-eof",
        ),
        pytest.param(
            "echo ${a:\n",
            "<standard input>:1:9: `:` must be followed by an expression\n",
            id="param-colon-eof",
        ),
        pytest.param(
            "echo ${a*} ${a@}\n",
            "<standard input>:1:9: not a valid parameter expansion operator: `*`\n",
            id="bare-star",
        ),
        pytest.param(
            "case $x in\n) ;;\nesac\n",
            "<standard input>:2:1: case patterns must consist of words\n",
            id="empty-case-pattern",
        ),
        pytest.param(
            "! ! ! true\n",
            "<standard input>:1:1: cannot negate a command multiple times\n",
            id="double-negation",
        ),
    ],
)
def test_parse_error_corners(run_shfmt, source, message):
    """Malformed and end-of-input constructs fail at the recorded spot."""
    # CATCHES: each error names the construct and its exact position:
    # the '[' and ':' operators blame the offending token, an unterminated
    # '${' blames EOF, '*' after a parameter name is rejected, and '!'
    # cannot stack.
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == message


def test_zsh_word_subscripts(run_shfmt):
    """Bare 'a[1]' words keep their subscript under zsh."""
    # CATCHES: a literal ending in ']' is lexed as an indexed name under
    # zsh only, so 'echo a[1]' is one word, not an error or a glob.
    proc = run_shfmt(["-ln=zsh", "-"], input_text="echo a[1]\necho $a[1,2]\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo a[1]\necho $a[1,2]\n"


@pytest.mark.parametrize(
    ("source", "expected"),
    [
        pytest.param('echo "a\\\nb"\n', 'echo "a\\\nb"\n', id="dquote"),
        pytest.param("echo ${a\\\nb}\n", "echo ${ab}\n", id="param-exp-dropped"),
        pytest.param("echo $((a +\\\nb))\n", "echo $((a + \\\nb))\n", id="arith"),
    ],
)
def test_line_continuations(run_shfmt, source, expected):
    """Escaped newlines survive in some contexts and vanish in others."""
    # CATCHES: the escape is kept inside double quotes and arithmetic,
    # but a parameter name swallows it, so '${a\<newline>b}' becomes
    # one name while the others keep the backslash-newline bytes.
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "source",
    ["a=\n", "a+=\n"],
)
def test_empty_assignments(run_shfmt, source):
    """Assignments with no value at all are valid statements."""
    # CATCHES: the lexer accepts '=' or '+=' at end of input without a
    # value, so nothing demands a word after the operator.
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source
