"""Tests for parse error positions, wording and output routing.

Every parse error is reported as "name:line:col: message" on stderr,
with stdout left empty and exit status 1.
"""

import pytest


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        ("if true\n", "<standard input>:1:1: `if <cond>` must be followed by `then`\n"),
        ("until false\n", "<standard input>:1:1: `until <cond>` must be followed by `do`\n"),
        (
            "for i in 1 2\n",
            "<standard input>:1:1: `for foo [in words]` must be followed by `do`\n",
        ),
        (
            "if true; then echo; \n",
            "<standard input>:1:1: `if` statement must end with `fi`\n",
        ),
        (
            "while true\ndo\n",
            "<standard input>:2:1: `do` must be followed by a statement list\n",
        ),
        (
            "case $a in\n",
            "<standard input>:1:1: `case` statement must end with `esac`\n",
        ),
    ],
)
def test_missing_block_keywords(run_shfmt, script, expected_err):
    """Incomplete compound statements each produce their own message."""
    # CATCHES: the wording differs per construct ("must be followed by"
    # versus "must end with") and the position points at the opening
    # keyword, except for `do` where it points into the next line.
    proc = run_shfmt([], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        ("((a\n", "<standard input>:1:1: reached EOF without matching `((` with `))`\n"),
        ("echo $(a\n", "<standard input>:1:6: reached EOF without matching `$(` with `)`\n"),
        ("{ echo hi\n", "<standard input>:1:1: reached EOF without matching `{` with `}`\n"),
        (
            'echo "a$(b\n',
            "<standard input>:1:8: reached EOF without matching `$(` with `)`\n",
        ),
        (
            'echo "unterminated\n',
            "<standard input>:1:6: reached EOF without closing quote `\"`\n",
        ),
        (
            "echo 'unterminated\n",
            "<standard input>:1:6: reached EOF without closing quote `'`\n",
        ),
    ],
)
def test_reached_eof_without_matching(run_shfmt, script, expected_err):
    """Unterminated constructs report "reached EOF without matching X with Y"."""
    # CATCHES: the message pairs the opener with its closer and the
    # position is that of the innermost unclosed opener.
    proc = run_shfmt([], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        (
            "echo $((1 ~ 2))\n",
            "<standard input>:1:11: not a valid arithmetic operator: `~`\n",
        ),
        (
            "echo $((1 ! 2))\n",
            "<standard input>:1:11: not a valid arithmetic operator: `!`\n",
        ),
        (
            "echo $((1 2))\n",
            "<standard input>:1:11: not a valid arithmetic operator: `2`\n",
        ),
        ("echo $((1 +))\n", "<standard input>:1:11: `+` must be followed by an expression\n"),
        ("echo $((a =+= 1))\n", "<standard input>:1:12: `+=` must follow a name\n"),
        ("((\n", "<standard input>:1:1: `((` must be followed by an expression\n"),
        ("echo ${a[}\n", "<standard input>:1:9: `[` must be followed by an expression\n"),
    ],
)
def test_arithmetic_and_index_errors(run_shfmt, script, expected_err):
    """Arithmetic and subscript errors carry exact operator positions."""
    # CATCHES: "not a valid arithmetic operator" back-quotes the bad
    # token, and the column points at the token after the operands.
    proc = run_shfmt([], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        (
            "echo ${a\n",
            '<standard input>:1:9: not a valid parameter expansion operator: "\\n"\n',
        ),
        (
            "echo ${a{b}}\n",
            "<standard input>:1:9: not a valid parameter expansion operator: `{`\n",
        ),
    ],
)
def test_parameter_expansion_operator_errors(run_shfmt, script, expected_err):
    """A bad ${ parameter operator is reported with its Go %q quoting."""
    # CATCHES: the offending character is rendered with Go quoting, so
    # a newline appears as the two characters \\n inside double quotes.
    proc = run_shfmt([], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        ("fi\n", "<standard input>:1:1: `fi` can only be used to end an `if`\n"),
        ("then\n", "<standard input>:1:1: `then` can only be used in an `if`\n"),
        ("done\n", "<standard input>:1:1: `done` can only be used to end a loop\n"),
        ("do echo; done\n", "<standard input>:1:1: `do` can only be used in a loop\n"),
        ("echo hi ;;\n", "<standard input>:1:9: `;;` can only be used in a case clause\n"),
        ("if true; then echo; fi; fi\n", "<standard input>:1:25: `fi` can only be used to end an `if`\n"),
        ("echo hi )\n", "<standard input>:1:9: a command can only contain words and redirects; encountered `)`\n"),
        ("echo $(`ls)\n", "<standard input>:1:11: a command can only contain words and redirects; encountered `)`\n"),
    ],
)
def test_stray_keyword_errors(run_shfmt, script, expected_err):
    """Keywords appearing outside their construct produce fixed messages."""
    # CATCHES: each stray keyword has its own one-line message and the
    # exact column where the stray token was found.
    proc = run_shfmt([], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


def test_error_positions_are_line_col(run_shfmt):
    """Positions count lines and columns from one across the whole input."""
    # CATCHES: the shebang on line 1 pushes the error to line 2, and
    # the column counts bytes from the start of that line.
    proc = run_shfmt([], input_text="#!/bin/bash\necho ${+a}\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "<standard input>:2:6: `${+foo}` is a zsh feature; tried parsing as bash "
        "(parsed as bash via -ln=auto)\n"
    )


def test_parse_error_routing(run_shfmt):
    """Parse errors go to stderr only; stdout stays empty; exit is 1."""
    # CATCHES: a re-implementation that prints errors to stdout or uses
    # a different exit status would break callers inspecting streams.
    proc = run_shfmt([], input_text="if true\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "<standard input>:1:1: `if <cond>` must be followed by `then`\n"
    assert len(proc.stderr.splitlines()) == 1


def test_first_error_is_reported(run_shfmt):
    """Only the first parse error is printed, even with two bad lines."""
    # CATCHES: an unterminated `if` swallows the rest of the input, so
    # the reported error is the one for the last construct seen: the
    # case statement on line 2 that was consumed as the if body.
    proc = run_shfmt([], input_text="if true\ncase $a in\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:2:1: `case` statement must end with `esac`\n"
    )


def test_heredoc_missing_delimiter_is_completed(run_shfmt):
    """A heredoc whose delimiter never arrives still formats, exit 0."""
    # CATCHES: the lexer treats end-of-input as closing an open heredoc
    # and the printer emits the missing delimiter line, rather than
    # reporting an error like other unterminated constructs.
    proc = run_shfmt([], input_text="cat << EOF\nbody\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "cat <<EOF\nbody\nEOF\n"


def test_heredoc_dash_strips_the_delimiters_tab(run_shfmt):
    """With <<-, the closing delimiter is printed without its tab."""
    # CATCHES: the body keeps its leading tab but the closing delimiter
    # loses it, and the operator spacing is normalized to <<-EOF.
    proc = run_shfmt([], input_text="cat <<- EOF\n\tbody\n\tEOF\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "cat <<-EOF\n\tbody\nEOF\n"


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        ("cat <<\n", "<standard input>:1:5: `<<` must be followed by a word\n"),
        ("cat <<<\n", "<standard input>:1:5: `<<<` must be followed by a word\n"),
    ],
)
def test_heredoc_operator_requires_a_word(run_shfmt, script, expected_err):
    """A heredoc operator with no delimiter word is a parse error."""
    # CATCHES: the redirect lexer distinguishes << from <<< in the
    # error text and reports the position of the operator itself.
    proc = run_shfmt([], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


def test_statement_after_heredoc_word(run_shfmt):
    """A command after the heredoc word prints after the heredoc body."""
    # CATCHES: the heredoc body starts after the current line, so
    # "echo next" belongs to the original line and is printed after the
    # body, with the operator spacing normalized to <<EOF.
    proc = run_shfmt([], input_text="cat << EOF; echo next\nbody\nEOF\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "cat <<EOF\nbody\nEOF\necho next\n"


def test_errors_from_file_arguments_use_the_path(run_shfmt, tmp_path):
    """A file argument's errors are prefixed with the path as given."""
    # CATCHES: unlike stdin, the error name is the path string passed
    # on the command line, verbatim.
    script = tmp_path / "bad.sh"
    script.write_text("if true\n", encoding="utf-8")
    proc = run_shfmt([str(script)])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "%s:1:1: `if <cond>` must be followed by `then`\n" % script
