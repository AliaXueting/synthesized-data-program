"""Operator and token torture tests for the lexer and sub-parsers.

Each test feeds one dense construct family through stdin and pins the
exact formatted output (or the exact parse error).  These exercise the
token-classification tables in the lexer (arithmetic operators, test
operators, parameter-expansion operators, heredoc delimiters, quoting)
far beyond what the gating tests reach.
"""

import pytest


def test_arithmetic_operator_torture(run_shfmt):
    """Every binary arithmetic operator lexes and prints with spacing."""
    # CATCHES: each operator token is classified separately; unary '!'
    # is the only one printed with a following space ('! b').
    source = (
        "echo $((a + b - c * d / e % f ** g))\n"
        "echo $((a << 2 >> 3))\n"
        "echo $((a < b && c > d || e <= f))\n"
        "echo $((a == b != c >= d))\n"
        "echo $((a & b | c ^ d))\n"
        "echo $((~a + !b))\n"
        "echo $((+a - -b))\n"
        "echo $((++a + b-- + ++c))\n"
        "echo $((a += 1, b -= 2, c *= 3, d /= 4, e %= 5))\n"
        "echo $((a <<= 1, b >>= 2, c &= 3, d |= 4, e ^= 5))\n"
        "echo $((a = b ? c : d))\n"
        "echo $((a[0] + b[i + 1]))\n"
        "echo $((0x10 + 16#ff + 011))\n"
        "echo $((1 + $((2 + 3))))\n"
        "echo $((a ** b ** c))\n"
    )
    expected = source.replace("!b))", "! b))")
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_arithmetic_in_other_contexts(run_shfmt):
    """Arithmetic lexes inside (( )), let, c-style for and ${} nesting."""
    # CATCHES: the same operator table serves four different syntactic
    # contexts; let keeps its quoted arguments verbatim.
    source = (
        "((a += 2))\n"
        "let \"a + 1\" 'b = 2'\n"
        "for ((i = 0; i < 10; i += 2)); do :; done\n"
        "echo $((${a:-1} + ${b[0]} + $# + $1 + $@ + $*))\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


def test_arithmetic_negation_spacing(run_shfmt):
    """Unary ! gains a space while ~ does not, even mid-expression."""
    # CATCHES: the printer distinguishes the '!' token from other unary
    # operators when deciding on spacing.
    source = "echo $((a > b ? a : b))\necho $((!a == ~b))\necho $((a, b, c))\n"
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        "echo $((a > b ? a : b))\necho $((! a == ~b))\necho $((a, b, c))\n"
    )


def test_zsh_float_and_subscript_arithmetic(run_shfmt):
    """zsh accepts float literals and subscript flags in arithmetic."""
    # CATCHES: '(k)' inside $((a[(k)i])) builds a FlagsArithm node and a
    # comma allows a second subscript pattern, both zsh-only.
    source = "echo $((1.5 + 1)) $((a[(k)i])) $((a[(i)pat,(k)key]))\n"
    proc = run_shfmt(["-ln=zsh", "-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


@pytest.mark.parametrize(
    ("expr", "token"),
    [
        ("$((a **= b))", "**"),
        ("$((a &&= b))", "&&"),
        ("$((a ||= b))", "||"),
        ("$((a ^^= b))", "^^"),
    ],
)
def test_bash_rejects_json_only_arith_assign_ops(run_shfmt, expr, token):
    """The compound logical/xor/pow assignments do not lex in bash source.

    The --from-json decoder accepts these spellings (see
    test_from_json_operators), but writing them as shell source fails.
    """
    # CATCHES: the arithmetic lexer only builds the plain compound
    # assignments, so '**=' splits into '**' plus '=' and errors.
    proc = run_shfmt(["-"], input_text=f"echo {expr}\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        f"<standard input>:1:11: `{token}` must be followed by an expression\n"
    )


def test_bash_accepts_xor_xor_arith(run_shfmt):
    """'a ^^ b' is a valid binary arithmetic operator in bash."""
    # CATCHES: '^^' is valid as a binary operator even though '^^=' is
    # not; the lexer must stop the operator at two carets.
    proc = run_shfmt(["-"], input_text="echo $((a ^^ b))\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $((a ^^ b))\n"


def test_param_expansion_operator_torture(run_shfmt):
    """All parameter-expansion operator spellings lex and print back."""
    # CATCHES: each of the ~30 expansion forms is its own token sequence;
    # a lexer that merges or drops one changes the printed expansion.
    source = (
        "echo ${a-b} ${a:-b} ${a+b} ${a:+b} ${a=b} ${a:=b} ${a?b} ${a:?b}\n"
        "echo ${a#b} ${a##b} ${a%b} ${a%%b} ${a/b/c} ${a//b/c} "
        "${a/#b/c} ${a/%b/c}\n"
        "echo ${a^} ${a^^} ${a,} ${a,,} ${a^pat} ${a,pat}\n"
        "echo ${a:2} ${a:2:3} ${a[@]:2:3} ${a[*]:2}\n"
        "echo ${a[@]/b/c} ${a[*]/%/c}\n"
        "echo ${!a} ${!a[0]} ${!a*} ${!a@}\n"
        "echo ${#a} ${#@} ${#*} ${##}\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


def test_param_index_and_slice_forms(run_shfmt):
    """Index and slice forms pass through, including negative offsets."""
    # CATCHES: ': -1' and ':1:-1' are distinct slice spellings that must
    # not be re-normalized into something else.
    source = (
        "a[(1)]=2\n"
        "a[$b]=2\n"
        "echo ${a[\"x\"]} ${a[x,$b]} ${a[@]} ${a[0]}\n"
        "echo ${a:1} ${a: -1} ${a:1:-1}\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


def test_at_expansion_operator_full_set(run_shfmt):
    """Ten @ expansion operators are valid in bash and print back."""
    # CATCHES: the @ operator set is a fixed table; Q/E/P/A/K/a/k/u/U/L
    # are the accepted spellings while R/r/l are not.
    source = "echo ${a@Q} ${a@E} ${a@P} ${a@A} ${a@K} ${a@a} ${a@k} ${a@u} ${a@U} ${a@L}\n"
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


@pytest.mark.parametrize("op", ["R", "r", "l"])
def test_at_expansion_rejects_case_ops(run_shfmt, op):
    """The case-transformation @ operators R, r and l are not in the table."""
    # CATCHES: only lowercase u/U/L (and the rest of the mksh set) decode;
    # the mirrored R/r/l spellings error with the invalid operator name.
    proc = run_shfmt(["-"], input_text=f"echo ${{a@{op}}}\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        f"<standard input>:1:10: invalid @ expansion operator `{op}`\n"
    )


def test_test_operator_torture(run_shfmt):
    """Every unary and binary [[ ]] test operator prints back verbatim."""
    # CATCHES: the test-operator table has one entry per flag spelling
    # (case-sensitive: -S vs -s) plus the file-age and numeric pairs.
    source = (
        "[[ -e f && -f f && -d f && -c f && -b f && -p f && -S f && -L f "
        "&& -k f && -g f && -u f && -G f && -O f && -N f && -r f && -w f "
        "&& -x f && -s f && -t 0 && -z f && -n f ]]\n"
        "[[ a -nt b || a -ot b || a -ef b ]]\n"
        "[[ a -eq b && a -ne b && a -le b && a -ge b && a -lt b && a -gt b ]]\n"
        "[[ a = b && a == b && a != b && a < b && a > b ]]\n"
        "[[ a =~ b ]]\n"
        "[[ ! -e f ]]\n"
        "[[ (a = b) ]]\n"
        "[[ -o errexit && -v a && -R b ]]\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


def test_heredoc_delimiter_styles(run_shfmt):
    """Every heredoc delimiter quoting style round trips."""
    # CATCHES: quoted ('EOF', "EOF"), backslash-escaped (\\EOF) and mixed
    # ('E'OF, E\\OF) delimiters all survive; <<- strips the tab before the
    # closing delimiter on output; a quoted-empty delimiter heredoc gets
    # its missing closing word appended as an empty line.
    source = (
        "cat <<EOF\n$body\nEOF\n"
        "cat <<'EOF'\n$body\nEOF\n"
        'cat <<"EOF"\n$body\nEOF\n'
        "cat <<\\EOF\n$body\nEOF\n"
        "cat <<'E'OF\nx\nEOF\n"
        "cat <<E\\OF\nx\nEOF\n"
        "cat <<EOF\nEOF\n"
        "cat <<-EOF\n\ttab\n\tEOF\n"
        "cat <<-'EOF'\n\ttab\n\tEOF\n"
        'cat <<"" ""\nx\n\n'
    )
    expected = (
        "cat <<EOF\n$body\nEOF\n"
        "cat <<'EOF'\n$body\nEOF\n"
        'cat <<"EOF"\n$body\nEOF\n'
        "cat <<\\EOF\n$body\nEOF\n"
        "cat <<'E'OF\nx\nEOF\n"
        "cat <<E\\OF\nx\nEOF\n"
        "cat <<EOF\nEOF\n"
        "cat <<-EOF\n\ttab\nEOF\n"
        "cat <<-'EOF'\n\ttab\nEOF\n"
        'cat "" <<""\nx\n\n'
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_heredoc_strips_crlf(run_shfmt):
    """CRLF line endings inside heredocs are dropped on output."""
    # CATCHES: the heredoc body lexer treats '\\r' as part of the line
    # terminator, so neither the body nor the delimiter keeps one.
    proc = run_shfmt(["-"], input_text="cat <<'EOF'\r\nCRLF\r\nEOF\r\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "cat <<'EOF'\nCRLF\nEOF\n"


def test_redirect_operator_torture(run_shfmt):
    """Every redirect spelling round trips and keeps fd prefixes."""
    # CATCHES: 'a>&1' is re-spaced to 'a >&1' (word boundary before the
    # glued redirect) while the operator itself never gains a space.
    source = (
        "x >f >>g <h <>i <&j >&k >|l\n"
        "exec {fd}>m\n"
        "y 2>err 1>&2 0<&3\n"
        "z &>all &>>more\n"
        "echo a>&1\n"
    )
    expected = source.replace("echo a>&1", "echo a >&1")
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_zsh_clobber_redirect_spellings(run_shfmt):
    """zsh's four clobber redirect spellings all survive."""
    # CATCHES: >| >>| &>| &>>| are distinct tokens under zsh; elsewhere
    # most of them are parse errors, so this pins the zsh lexer table.
    source = "x >|f >>|g &>|h &>>|i\n"
    proc = run_shfmt(["-ln=zsh", "-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


def test_quoting_torture(run_shfmt):
    """Escapes, $'...' bytes, backquotes and bangs print back exactly."""
    # CATCHES: backquotes canonicalize to $( ) even inside double quotes,
    # escaped backquotes nest, a backslash-newline joins lines, and the
    # history-expansion bangs stay quoted.
    source = (
        "echo $'\\a\\b\\e\\f\\v\\r\\t\\\\\\'\"\\n'\n"
        "echo $'\\x41\\101\\cX\\C'\n"
        "echo $'\\0'\n"
        'echo "a$b" "a${b}c" "a$(cmd)d" "a`cmd`e" "a\\"b" "a\\\\$b"\n'
        "echo 'a'\\''b' 'a\\\"b'\n"
        "echo a\\\nb\n"
        'echo $"str" $"a$b"\n'
        "echo `echo \\`x\\``\n"
        "echo foo\\<bar\n"
        "echo a\\ b\n"
        'echo "!"\n'
        "echo '!'!\n"
    )
    expected = (
        "echo $'\\a\\b\\e\\f\\v\\r\\t\\\\\\'\"\\n'\n"
        "echo $'\\x41\\101\\cX\\C'\n"
        "echo $'\\0'\n"
        'echo "a$b" "a${b}c" "a$(cmd)d" "a$(cmd)e" "a\\"b" "a\\\\$b"\n'
        "echo 'a'\\''b' 'a\\\"b'\n"
        "echo ab\n"
        'echo $"str" $"a$b"\n'
        "echo $(echo $(x))\n"
        "echo foo\\<bar\n"
        "echo a\\ b\n"
        'echo "!"\n'
        "echo '!'!\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_assignment_quoting_torture(run_shfmt):
    """A semicolon-separated assignment list splits onto its own lines."""
    # CATCHES: the printer breaks ';'-joined statements into lines, so the
    # three assignments each get a line while nested quotes stay intact.
    source = (
        "x='single'; y=\"double\"; z=$'raw'\n"
        'echo "${x}" "${!y}" "${x:-d}" "$(echo "$(nested)")"\n'
        "echo $x${y}$z\n"
    )
    expected = (
        "x='single'\ny=\"double\"\nz=$'raw'\n"
        'echo "${x}" "${!y}" "${x:-d}" "$(echo "$(nested)")"\n'
        "echo $x${y}$z\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_assignment_forms(run_shfmt):
    """Plain, appending, indexed and array assignments all print back."""
    # CATCHES: 'a+=(3 4)' keeps its appending equals and the array with a
    # keyed element [2]=three is preserved verbatim.
    source = (
        "a=b\n"
        "a+=b\n"
        "a[0]=b\n"
        "a[0]+=b\n"
        "a=(1 2)\n"
        "a+=(3 4)\n"
        "a=b cmd\n"
        "a+=b cmd\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


def test_declaration_assignment_forms(run_shfmt):
    """Declaration builtins keep their flags and array initializers."""
    # CATCHES: 'declare -a arr=(1 2)' holds both a flag word and an array
    # initializer inside the DeclClause arguments.
    source = (
        "export a=b\n"
        "local -i x=1\n"
        "declare -a arr=(1 2)\n"
        "readonly c=d\n"
        "typeset -i e=5\n"
        "let a=1\n"
        "((a = 2))\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


@pytest.mark.parametrize(
    "assign",
    ["a$b=c", "$(x)=y", '"x y"=z', "{a..b}=c"],
)
def test_lenient_assignment_names(run_shfmt, assign):
    """Non-literal assignment names lex as words and print back as-is."""
    # CATCHES: the parser accepts expansions, quoted words and brace
    # patterns as the left side of an assignment without rewriting them.
    proc = run_shfmt(["-"], input_text=assign + "\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == assign + "\n"


def test_inline_indexed_assign_is_rejected(run_shfmt):
    """An indexed assignment cannot prefix a command."""
    # CATCHES: 'a=b cmd' is fine but 'a[0]=b cmd' is an inline array,
    # which the parser rejects before any formatting happens.
    proc = run_shfmt(["-"], input_text="a[0]=b cmd\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:1: inline variables cannot be arrays\n"
    )


def test_glob_and_regex_patterns(run_shfmt):
    """Globs, bracket expressions and regexes print back unchanged."""
    # CATCHES: the lexer must not treat *, ? or [...] specially inside
    # plain words or regex operands; only case items parse them as
    # patterns, and even then they print identically.
    source = (
        "echo a*b?c[d-f] !g [!h] \\*\n"
        "[[ $x =~ ^a+b$ ]]\n"
        "[[ $x =~ a{2,3} ]]\n"
        "[[ $x =~ (a|b)*.c ]]\n"
        "case $x in\n"
        "a*b) ;;\n"
        "[0-9]?) ;;\n"
        "?(x|y)) ;;\n"
        "esac\n"
    )
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source


def test_unicode_passthrough(run_shfmt):
    """Multi-byte UTF-8 in words and comments passes through unchanged."""
    # CATCHES: the lexer counts columns in runes, so the emoji and
    # accented letters keep their byte sequences and positions.
    source = "echo héllo \"wörld\"\n# ünïcödé comment\n"
    proc = run_shfmt(["-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source

    proc = run_shfmt(["-"], input_text="echo 🚀 rocket\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo 🚀 rocket\n"


def test_unicode_param_name_is_rejected(run_shfmt):
    """A multi-byte rune is not a valid parameter name."""
    # CATCHES: parameter names are ASCII-only, and the error position is
    # the column of the offending rune, counted in runes not bytes.
    proc = run_shfmt(["-"], input_text="echo héllo ${ä}\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "<standard input>:1:15: invalid parameter name\n"


def test_zsh_subscripts_flags_and_numranges(run_shfmt):
    """zsh subscript flags, expansion flags and <n-m> globs all parse."""
    # CATCHES: '(k)'/'(R)' subscripts, the comma-separated subscript
    # pattern list, the <1-10>/<->/<-5> numeric range globs (also in case
    # patterns) and the ${(flags)...} letters are zsh-only lexing.
    source = (
        "echo ${a[(k)x]} ${a[(R)y]} ${a[(i)pat]} ${a[(r)pat]}\n"
        "echo $((a[(k)i] + b[(i)j,(k)l]))\n"
        "echo <1-10> <-> <1-> <-5> <10-20>\n"
        "case $x in <1-5>) echo num ;; esac\n"
        "echo ${(U)a} ${(L)b} ${(j.:.)c} ${(s.:.)d} ${(@)e} ${(k)f} "
        "${(v)g} ${(A)h}\n"
    )
    proc = run_shfmt(["-ln=zsh", "-"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == source
