"""Tests for automatic dialect detection when -ln is left at "auto".

Detection order: the --filename extension, then well-known shell config
file names, then the shebang line of the input, and finally a fallback
to bash.  The error suffix "(parsed as ... via -ln=auto)" marks errors
raised for a guessed dialect.
"""

import pytest

# One construct that only the given dialect accepts, used as a probe.
ZSH_ONLY = "echo ${+a}\n"
BASH_ONLY = "function f { echo; }\n"
MKSH_ONLY = "case $a { x) echo;; }\n"
BATS_ONLY = '@test "n" { echo; }\n'


@pytest.mark.parametrize(
    ("filename", "script", "expected_out"),
    [
        ("s.bash", BASH_ONLY, BASH_ONLY),
        ("s.zsh", ZSH_ONLY, ZSH_ONLY),
        ("s.mksh", MKSH_ONLY, "case $a in x) echo ;; esac\n"),
        ("s.bats", BATS_ONLY, BATS_ONLY),
    ],
)
def test_filename_extension_selects_dialect(run_shfmt, filename, script, expected_out):
    """A .bash/.zsh/.mksh/.bats --filename enables that dialect's syntax."""
    # CATCHES: extensions are mapped through LangVariant.Set, so the
    # same --filename value must switch on exactly these four dialects;
    # the mksh brace-case input is printed in its canonical in/esac form.
    proc = run_shfmt(["--filename", filename], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected_out
    assert proc.stderr == ""


def test_sh_extension_does_not_mean_posix(run_shfmt):
    """A .sh name leaves detection to the shebang and then falls back to bash."""
    # CATCHES: ".sh" is deliberately skipped by extension detection; the
    # zsh-only construct below is rejected as bash, with the auto suffix.
    proc = run_shfmt(["--filename", "s.sh"], input_text=ZSH_ONLY)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "s.sh:1:6: `${+foo}` is a zsh feature; tried parsing as bash "
        "(parsed as bash via -ln=auto)\n"
    )


@pytest.mark.parametrize(
    "filename", [".bashrc", ".bash_profile", ".bash_logout", "bashrc"]
)
def test_bash_config_filenames(run_shfmt, filename):
    """Well-known bash config names select bash, with or without the dot."""
    # CATCHES: the base name has its leading dot trimmed before the
    # lookup, so both ".bashrc" and "bashrc" must map to bash.
    proc = run_shfmt(["--filename", filename], input_text=BASH_ONLY)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == BASH_ONLY


@pytest.mark.parametrize(
    "filename", [".zshenv", ".zprofile", ".zshrc", ".zlogin", ".zlogout", "zshrc"]
)
def test_zsh_config_filenames(run_shfmt, filename):
    """Well-known zsh config names select zsh, with or without the dot."""
    # CATCHES: all five zsh config names (plus the dotless spelling)
    # must switch the parser to zsh before any shebang is considered.
    proc = run_shfmt(["--filename", filename], input_text=ZSH_ONLY)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == ZSH_ONLY


def test_other_dotted_name_falls_back_to_bash(run_shfmt):
    """An unknown extension like .rc leaves auto mode and falls back to bash."""
    # CATCHES: ".rc" is not a dialect, so detection continues to the
    # shebang and then the bash fallback, which the suffix records.
    proc = run_shfmt(["--filename", "other.rc"], input_text=ZSH_ONLY)
    assert proc.returncode == 1
    assert "tried parsing as bash (parsed as bash via -ln=auto)" in proc.stderr


@pytest.mark.parametrize(
    "shebang", ["#!/bin/zsh\n", "#!/usr/bin/env zsh\n", "#! /bin/zsh\n"]
)
def test_shebang_selects_dialect(run_shfmt, shebang):
    """Shebang forms with /usr and env spellings and a space all detect zsh."""
    # CATCHES: the shebang regex tolerates "#! " spacing and the
    # /usr/bin and /usr/bin/env prefixes; all must resolve to zsh.
    proc = run_shfmt([], input_text=shebang + ZSH_ONLY)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == shebang + ZSH_ONLY


@pytest.mark.parametrize("shebang", ["#!/bin/sh\n", "#!/bin/dash\n"])
def test_shebang_posix_detection(run_shfmt, shebang):
    """A #!/bin/sh or #!/bin/dash shebang parses the file as posix."""
    # CATCHES: "sh" and "dash" shebangs resolve to the POSIX dialect,
    # so bash arrays fail and the error names posix as the guess.
    proc = run_shfmt([], input_text=shebang + "a=(1 2)\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr.endswith(
        "arrays are a bash/mksh/zsh feature; tried parsing as posix "
        "(parsed as posix via -ln=auto)\n"
    )


@pytest.mark.parametrize("shebang", ["#!/usr/bin/perl\n", "#!/bin/zsh5\n", "echo hi\n"])
def test_unknown_shebang_falls_back_to_bash(run_shfmt, shebang):
    """A non-shell or malformed shebang leaves the fallback dialect bash."""
    # CATCHES: "zsh5" does not match the shebang pattern (no trailing
    # characters are allowed after the shell name), so bash is guessed.
    proc = run_shfmt([], input_text=shebang + ZSH_ONLY)
    assert proc.returncode == 1
    assert "tried parsing as bash (parsed as bash via -ln=auto)" in proc.stderr


def test_shebang_only_counts_on_the_first_line(run_shfmt):
    """A #! line that is not the first line is not a shebang."""
    # CATCHES: Shebang() anchors at the start of the input, so a shell
    # comment-looking line later must not switch the dialect to zsh.
    proc = run_shfmt([], input_text="echo hi\n#!/bin/zsh\n" + ZSH_ONLY)
    assert proc.returncode == 1
    assert "tried parsing as bash (parsed as bash via -ln=auto)" in proc.stderr


def test_extension_beats_shebang(run_shfmt):
    """A .bash --filename wins over a zsh shebang in the contents."""
    # CATCHES: detection order is extension first, shebang second; the
    # recorded error proves the shebang was never consulted here.
    proc = run_shfmt(
        ["--filename", "s.bash"], input_text="#!/bin/zsh\n" + ZSH_ONLY
    )
    assert proc.returncode == 1
    assert proc.stderr == (
        "s.bash:2:6: `${+foo}` is a zsh feature; tried parsing as bash "
        "(parsed as bash via -ln=auto)\n"
    )


def test_config_name_beats_shebang(run_shfmt):
    """A .bashrc --filename wins over a zsh shebang in the contents."""
    # CATCHES: the well-known config name lookup runs before the
    # shebang is read, so the zsh shebang below has no effect.
    proc = run_shfmt(
        ["--filename", ".bashrc"], input_text="#!/bin/zsh\n" + ZSH_ONLY
    )
    assert proc.returncode == 1
    assert "parsed as bash via -ln=auto" in proc.stderr


def test_sh_extension_still_uses_the_shebang(run_shfmt):
    """A .sh name does not decide the dialect, so the zsh shebang applies."""
    # CATCHES: because ".sh" is skipped, a .sh file with a zsh shebang
    # is parsed as zsh and the zsh-only construct is accepted.
    proc = run_shfmt(
        ["--filename", "s.sh"], input_text="#!/bin/zsh\n" + ZSH_ONLY
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "#!/bin/zsh\n" + ZSH_ONLY


def test_unknown_extension_falls_through_to_the_shebang(run_shfmt):
    """A .txt name fails dialect lookup, so the shebang decides."""
    # CATCHES: extensions that are not dialects do not stop detection;
    # the zsh shebang in the contents still selects the zsh parser.
    proc = run_shfmt(
        ["--filename", "other.txt"], input_text="#!/bin/zsh\n" + ZSH_ONLY
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "#!/bin/zsh\n" + ZSH_ONLY


def test_stdin_default_name_in_errors(run_shfmt):
    """Without --filename, parse errors are reported for "<standard input>"."""
    # CATCHES: the placeholder file name "<standard input>" appears in
    # every stdin error position prefix.
    proc = run_shfmt([], input_text="if true\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:1: `if <cond>` must be followed by `then`\n"
    )


def test_filename_prefixes_error_positions(run_shfmt):
    """The --filename value is used verbatim as the error position prefix."""
    # CATCHES: the given name is echoed into the "name:line:col:" error
    # prefix, including subdirectory parts when the input is stdin.
    proc = run_shfmt(["--filename", "sub/s.sh"], input_text="if true\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "sub/s.sh:1:1: `if <cond>` must be followed by `then`\n"
    )


def test_explicit_file_uses_its_own_extension(run_shfmt, tmp_path):
    """A file argument detects its dialect from the file name alone."""
    # CATCHES: formatting a real file (not stdin) applies the same
    # extension-based detection, here selecting zsh from ".zsh".
    script = tmp_path / "h.zsh"
    script.write_text(ZSH_ONLY, encoding="utf-8")
    proc = run_shfmt([str(script)])
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == ZSH_ONLY


def test_explicit_extensionless_file_uses_its_shebang(run_shfmt, tmp_path):
    """An extension-less file argument is detected through its shebang."""
    # CATCHES: with no extension to go by, the file's own contents are
    # read for a shebang and the zsh dialect is selected.
    script = tmp_path / "i"
    script.write_text("#!/bin/zsh\n" + ZSH_ONLY, encoding="utf-8")
    proc = run_shfmt([str(script)])
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "#!/bin/zsh\n" + ZSH_ONLY


def test_explicit_file_bash_fallback(run_shfmt, tmp_path):
    """An extension-less file without a shebang is treated as bash."""
    # CATCHES: the last resort of auto detection is bash, and the error
    # suffix still says "via -ln=auto" for a real file argument.
    script = tmp_path / "j"
    script.write_text(ZSH_ONLY, encoding="utf-8")
    proc = run_shfmt([str(script)])
    assert proc.returncode == 1
    assert proc.stderr == (
        "%s:1:6: `${+foo}` is a zsh feature; tried parsing as bash "
        "(parsed as bash via -ln=auto)\n" % script
    )
