"""Coloring of the -d diff output, selected by the environment.

shfmt decides once, from FORCE_COLOR / NO_COLOR / TERM and whether stdout
is a terminal, whether the unified diff gets ANSI colors; FORCE_COLOR
wins outright.  The pinned child environment uses TERM=dumb, so these
tests override individual variables through the run helper's env argument.
"""

BOLD = "\x1b[1m"
CYAN = "\x1b[36m"
RED = "\x1b[31m"
GREEN = "\x1b[32m"
RESET = "\x1b[0m"

PLAIN_DIFF = (
    "diff <standard input>.orig <standard input>\n"
    "--- <standard input>.orig\n"
    "+++ <standard input>\n"
    "@@ -1,1 +1,1 @@\n"
    "- echo  hi\n"
    "+echo hi\n"
)

COLORED_DIFF = (
    f"{BOLD}diff <standard input>.orig <standard input>\n"
    "--- <standard input>.orig\n"
    f"+++ <standard input>\n"
    f"{CYAN}@@ -1,1 +1,1 @@\n"
    f"{RED}- echo  hi\n"
    f"{GREEN}+echo hi\n"
    f"{RESET}"
)


def test_force_color_colors_the_diff(run_shfmt):
    """FORCE_COLOR turns the diff into ANSI-colored hunks."""
    # CATCHES: the three header lines are bold, the @@ hunk line cyan,
    # the removed line red and the added line green, with a final reset
    # and no trailing newline after it.
    proc = run_shfmt(["-d", "-"], input_text=" echo  hi\n",
                     env={"FORCE_COLOR": "1"})
    assert proc.returncode == 1
    assert proc.stdout == COLORED_DIFF
    assert proc.stderr == ""


def test_force_color_beats_no_color(run_shfmt):
    """FORCE_COLOR wins even when NO_COLOR is set at the same time."""
    # CATCHES: the decision checks FORCE_COLOR first, so NO_COLOR cannot
    # turn the coloring back off once FORCE_COLOR asked for it.
    proc = run_shfmt(["-d", "-"], input_text=" echo  hi\n",
                     env={"FORCE_COLOR": "1", "NO_COLOR": "1"})
    assert proc.returncode == 1
    assert proc.stdout == COLORED_DIFF
    assert proc.stderr == ""


def test_no_color_keeps_the_diff_plain(run_shfmt):
    """NO_COLOR alone never enables coloring."""
    # CATCHES: NO_COLOR only ever disables color, so the diff stays the
    # plain byte-for-byte unified diff with a trailing newline.
    proc = run_shfmt(["-d", "-"], input_text=" echo  hi\n",
                     env={"NO_COLOR": "1"})
    assert proc.returncode == 1
    assert proc.stdout == PLAIN_DIFF
    assert proc.stderr == ""
