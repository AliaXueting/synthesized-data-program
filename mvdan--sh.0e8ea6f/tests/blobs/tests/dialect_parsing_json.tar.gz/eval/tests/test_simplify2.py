"""A second wave of -s simplification edge cases.

Round 1 pinned the main rewrites.  These tests pin the cases that must
NOT be rewritten (non-simple parameter expansions, nested arithmetic,
negated or multi-statement subshells, words with single quotes) plus
the long --simplify spelling of the flag.
"""

import pytest


def test_single_quote_blocks_requoting(run_shfmt):
    """A double-quoted word containing a single quote is not requoted."""
    # CATCHES: re-quoting "fo'o" as 'fo'o' would be wrong, so the
    # simplifier bails out on any embedded single quote.
    proc = run_shfmt(["-s"], input_text="echo \"fo'o\"\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo \"fo'o\"\n"


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        # complex parameter expansions are not inlined into arithmetic
        ("echo $(( ${a[0]} + 1 ))\n", "echo $((${a[0]} + 1))\n"),
        ("echo $(( ${#a} + 1 ))\n", "echo $((${#a} + 1))\n"),
        # nested arithmetic is not flattened
        ("echo $((1 + $((2))))\n", "echo $((1 + $((2))))\n"),
    ],
)
def test_simplify_keeps_complex_params(run_shfmt, script, expected):
    """Indexed, length and nested expansions survive -s unchanged."""
    # CATCHES: only simple ${name} expansions are inlined; ${a[0]},
    # ${#a} and $((2)) all stay, while the outer spacing is still
    # canonicalized to single spaces around the operator.
    proc = run_shfmt(["-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_simplify_keeps_negated_subshell(run_shfmt):
    """A negated inner subshell is unwrapped only of its parens."""
    # CATCHES: $( !(a)) keeps the parentheses because the statement is
    # negated, but the stray space before ( is dropped.
    proc = run_shfmt(["-s"], input_text="echo $( !(a))\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $(!(a))\n"


def test_simplify_keeps_multi_statement_subshell(run_shfmt):
    """A subshell holding several statements is not inlined."""
    # CATCHES: only a single inner statement can be promoted, so the
    # two statements stay in a $( ) reindented one per line.
    proc = run_shfmt(["-s"], input_text="echo $( (a); (b))\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $(\n\t(a)\n\t(b)\n)\n"


def test_simplify_indices_in_assignments_and_expansions(run_shfmt):
    """Redundant parens come out of array indices in both positions."""
    # CATCHES: a[(b)]=2 and ${a[(c)]} lose only the parentheses, both
    # in the assignment target and inside the expansion.
    proc = run_shfmt(["-s"], input_text="a[(b)]=2; echo ${a[(c)]}\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "a[b]=2\necho ${a[c]}\n"


def test_simplify_long_flag(run_shfmt):
    """--simplify is the long spelling of -s."""
    # CATCHES: the flag is registered under both names, and the long
    # form performs the same arithmetic paren removal.
    proc = run_shfmt(["--simplify"], input_text="echo $((a + ((b - c))))\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $((a + (b - c)))\n"
