"""Tests for the -s/--simplify code transformations.

Simplify rewrites the parsed tree before printing: redundant
parentheses and quotes are dropped and some test expressions are
rewritten, while constructs whose simplification would change the
meaning of the program must be left untouched.
"""

import pytest


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        ("echo $((a + ((b - c))))\n", "echo $((a + (b - c)))\n"),
        ("echo $((a + (((b - c)))))\n", "echo $((a + (b - c)))\n"),
        ("echo $(((b - c)))\n", "echo $((b - c))\n"),
        ("(((b - c)))\n", "((b - c))\n"),
        ("echo $(($a + ${b}))\n", "echo $((a + b))\n"),
    ],
)
def test_simplify_arithmetic_parens(run_shfmt, script, expected):
    """Redundant arithmetic parentheses are removed layer by layer."""
    # CATCHES: nesting is collapsed from the inside out and parameter
    # expansions inside arithmetic become bare names.
    proc = run_shfmt(["-ln=bash", "-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        ("echo ${foo[(1)]}\n", "echo ${foo[1]}\n"),
        ("echo ${foo:(1):(2)}\n", "echo ${foo:1:2}\n"),
        ("a[(1)]=2\n", "a[1]=2\n"),
    ],
)
def test_simplify_parameter_indices(run_shfmt, script, expected):
    """Parenthesized literal indices and slice widths are unwrapped."""
    # CATCHES: only redundant parentheses around literals are removed,
    # both in array subscripts and in ${name:x:y} slices.
    proc = run_shfmt(["-ln=bash", "-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "script",
    [
        "a[$b]=2\n",
        "echo ${a[$b]}\n",
        "echo ${a[x,$b]}\n",
        "echo ${a[@]}\n",
        "echo ${a[0]}\n",
        'echo ${a["x"]}\n',
    ],
)
def test_simplify_keeps_meaningful_indices(run_shfmt, script):
    """Indices that are not redundant parentheses are left alone."""
    # CATCHES: variables or quoted strings in subscripts must survive;
    # removing the quotes around "x" or $b would change evaluation.
    proc = run_shfmt(["-ln=bash", "-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == script


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        ('[[ "$foo" == "bar" ]]\n', '[[ $foo == "bar" ]]\n'),
        ('[[ (-z "$foo") ]]\n', "[[ -z $foo ]]\n"),
        ('[[ "a b" > "$c" ]]\n', '[[ "a b" > $c ]]\n'),
        ("[[ ! -n $foo ]]\n", "[[ -z $foo ]]\n"),
        ("[[ ! ! -e a && ! -z $b ]]\n", "[[ -e a && -n $b ]]\n"),
        ("[[ (! a == b) || (! c != d) ]]\n", "[[ (a != b) || (c == d) ]]\n"),
        ("[[ foo = bar ]]\n", "[[ foo == bar ]]\n"),
        ('[[ "$foo" =~ bar ]]\n', "[[ $foo =~ bar ]]\n"),
        ('[[ -z "$empty" || -n "$set" ]]\n', "[[ -z $empty || -n $set ]]\n"),
    ],
)
def test_simplify_test_expressions(run_shfmt, script, expected):
    """[[ ]] tests are simplified: quotes dropped, negations folded, = to ==."""
    # CATCHES: only the left side of == loses its quotes (the right
    # side is a pattern), double negation cancels, ! -n becomes -z, and
    # the single = is normalized to ==.
    proc = run_shfmt(["-ln=bash", "-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "script",
    [
        "[[ ! -e foo ]]\n",
        "[[ foo == bar ]]\n",
        ('[[ foo =~ "$bar" ]]\n'),
        ("[[ -n a$b && -n $c ]]\n"),
    ],
)
def test_simplify_keeps_meaningful_tests(run_shfmt, script):
    """Test expressions that must not be rewritten stay unchanged."""
    # CATCHES: ! -e has no positive equivalent, unquoted expansions in
    # tests stay as they are, and a quoted regex right-hand side must
    # keep its quotes.
    proc = run_shfmt(["-ln=bash", "-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == script


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        ("echo $( (sts))\n", "echo $(sts)\n"),
        ("( ( (sts)))\n", "(sts)\n"),
    ],
)
def test_simplify_nested_subshells(run_shfmt, script, expected):
    """Subshells nested without any other content are collapsed."""
    # CATCHES: $( (sts)) prints as "$( (sts) )" without -s (the printer
    # re-adds the space), so this pins both the simplification and the
    # contrast with the unsimplified rendering.
    plain = run_shfmt(["-ln=bash"], input_text=script)
    assert plain.returncode == 0, plain.stderr
    assert plain.stdout != expected
    proc = run_shfmt(["-ln=bash", "-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_simplify_keeps_redirected_subshell(run_shfmt):
    """A nested subshell that carries a redirect is not collapsed."""
    # CATCHES: ( (sts) >f) has a redirect on the inner subshell, so
    # removing the nesting would move the redirect's scope.
    proc = run_shfmt(["-ln=bash", "-s"], input_text="( (sts) >f)\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "( (sts) >f)\n"


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        ('echo "fo\\$o"\n', "echo 'fo$o'\n"),
        ('echo "fo\\"o"\n', 'echo \'fo"o\'\n'),
    ],
)
def test_simplify_requotes_strings(run_shfmt, script, expected):
    """Double quotes holding only escapes become single quotes."""
    # CATCHES: "fo\$o" and "fo\"o" have no expansions left once the
    # escapes are resolved, so they are re-quoted with single quotes.
    proc = run_shfmt(["-ln=bash", "-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "script",
    [
        'echo "foo"\n',
        'echo "foo$bar"\n',
        'echo "$bar"\n',
        'echo fo"o"bar\n',
        'echo foo""bar\n',
    ],
)
def test_simplify_keeps_other_strings(run_shfmt, script):
    """Strings with expansions or partial quoting are not re-quoted."""
    # CATCHES: re-quoting "foo$bar" with single quotes would stop the
    # expansion, and partial quotes inside a word cannot be removed.
    proc = run_shfmt(["-ln=bash", "-s"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == script


def test_simplify_off_by_default(run_shfmt):
    """Without -s, redundant parentheses and quotes are preserved."""
    # CATCHES: the same inputs that -s rewrites must pass through
    # unchanged by default, proving -s is opt-in.
    script = 'echo $((a + ((b - c))))\n[[ "$foo" == "bar" ]]\n'
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == script


def test_simplify_is_idempotent(run_shfmt):
    """Simplified output run through -s again is unchanged."""
    # CATCHES: a second simplification must not remove the remaining
    # (b - c) parentheses, which are semantically required.
    once = run_shfmt(["-ln=bash", "-s"], input_text="echo $((a + ((b - c))))\n")
    assert once.returncode == 0, once.stderr
    twice = run_shfmt(["-ln=bash", "-s"], input_text=once.stdout)
    assert twice.returncode == 0, twice.stderr
    assert twice.stdout == "echo $((a + (b - c)))\n"


def test_simplify_with_posix_and_error(run_shfmt):
    """-s does not mask dialect errors; the parse still fails."""
    # CATCHES: simplification happens after parsing, so a posix
    # rejection of arrays is reported exactly as without -s.
    proc = run_shfmt(["-ln=posix", "-s"], input_text="a=(1 2)\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:3: arrays are a bash/mksh/zsh feature; "
        "tried parsing as posix\n"
    )


def test_minify_implies_simplify(run_shfmt):
    """-mn implies -s: the redundant arithmetic parens disappear too."""
    # CATCHES: minify is documented to imply --simplify, so the inner
    # parentheses are dropped, but the spaces around the arithmetic
    # operators themselves survive minification.
    proc = run_shfmt(["-ln=bash", "-mn"], input_text="echo $((a + ((b - c))))\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $((a+(b - c)))\n"


def test_editorconfig_simplify_applied(run_shfmt, tmp_path):
    """simplify=true in .editorconfig is honored without the -s flag."""
    # CATCHES: when no parser flag is passed, shfmt reads its options
    # from EditorConfig, and simplify=true turns simplification on.
    (tmp_path / ".editorconfig").write_text(
        "[[shell]]\nsimplify = true\n", encoding="utf-8"
    )
    proc = run_shfmt(["--filename", "s.sh"], input_text="echo $((a + ((b - c))))\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $((a + (b - c)))\n"


def test_editorconfig_simplify_disabled_by_ln(run_shfmt, tmp_path):
    """Passing -ln disables the EditorConfig lookup, including simplify."""
    # CATCHES: any parser flag (here -ln=bash) turns EditorConfig off,
    # so the same .editorconfig no longer enables simplification.
    (tmp_path / ".editorconfig").write_text(
        "[[shell]]\nsimplify = true\n", encoding="utf-8"
    )
    proc = run_shfmt(
        ["-ln=bash", "--filename", "s.sh"], input_text="echo $((a + ((b - c))))\n"
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo $((a + ((b - c))))\n"
