"""Shared helpers for the dialect_parsing_json test module.

The program under test is shfmt.  These tests pin its shell-dialect
behavior: the -ln/-p dialect flags, auto-detection of the dialect from
--filename extensions, well-known config file names and shebangs,
dialect-gated syntax acceptance and its error messages, --exp.recover,
-s code simplification, and the --to-json/--from-json typed syntax
trees.
"""

import functools
import os
import subprocess
import tempfile
from pathlib import Path

import pytest


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--version' once against a throwaway GOCOVERDIR, so
    the check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="shfmt-covprobe-") as probe_dir:
        env = {"PATH": "/usr/bin:/bin", "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def _shfmt_bin():
    """Resolve the reference binary through PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the shfmt binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but
    # the pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to
    # this module's uninstrumented copy before pytest starts, so the counters
    # would never be written and this module's coverage report would stay
    # empty.  During a coverage run (GOCOVERDIR present), when the assigned
    # binary is not itself instrumented, fall back to the instrumented build
    # the driver stages next to the module workspaces.  That file only exists
    # in the pipeline layout, so ordinary validation runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(str(staged)):
            return str(staged)
    return path


# Pinned child environment: no network, no locale or color surprises.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "dumb",
}


def _child_env():
    """The pinned child environment plus the coverage forwarding vars."""
    env = dict(CHILD_ENV)
    # The pipeline measures source coverage of the reference binary through
    # GOCOVERDIR; forward it when the test process itself was started with
    # it so an instrumented binary can write its covermeta files.  Read at
    # call time so a per-test override is honored too.
    for key in ("GOCOVERDIR",):
        value = os.environ.get(key)
        if value:
            env[key] = value
    return env


def _invoke(args, input_text, cwd, timeout, env=None):
    """Spawn shfmt with the given argv and capture both output streams."""
    child_env = _child_env()
    if env:
        # A per-test override (e.g. FORCE_COLOR) layers on top of the
        # pinned environment; everything not named stays pinned.
        child_env.update(env)
    return subprocess.run(
        [_shfmt_bin(), *args],
        input=input_text,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=cwd,
        env=child_env,
        timeout=timeout,
    )


def run_shfmt(args, input_text=None, cwd=None, timeout=10, env=None):
    """Run shfmt with the given argv and return the completed process.

    The child gets a pinned environment and, when ``cwd`` is given, runs
    inside that directory so tests can control which .editorconfig files
    are visible to it (shfmt consults EditorConfig when no parser or
    printer flag was passed).  ``env`` adds or overrides individual
    variables in that pinned environment.
    """
    return _invoke(args, input_text, cwd, timeout, env)


@pytest.fixture(name="run_shfmt")
def run_shfmt_fixture(tmp_path):
    """The run_shfmt helper, defaulting to an isolated empty cwd.

    The default cwd is an empty per-test directory, so no .editorconfig
    file can influence a run unless the test writes one there.
    """

    def _run(args, input_text=None, cwd=None, timeout=10, env=None):
        return _invoke(args, input_text, cwd or str(tmp_path), timeout, env)

    return _run
