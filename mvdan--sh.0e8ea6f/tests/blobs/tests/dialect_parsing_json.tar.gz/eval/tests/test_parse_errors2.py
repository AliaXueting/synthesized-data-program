"""A second wave of parse-error and canonicalization behaviors.

Round 1 pinned the missing-keyword and unmatched-delimiter families.
These tests cover the arithmetic ternary/comma/index errors, the test
expression operator errors, array and case-pattern validation, the
heredoc delimiter rules, lexer-level errors (invalid UTF-8, nesting
depth), and lexer canonicalizations like backquotes and line
continuations.
"""

import pytest


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        (
            "echo $((a ? b))\n",
            "<standard input>:1:11: ternary operator missing `:` after `?`\n",
        ),
        (
            "echo $((a ? : c))\n",
            "<standard input>:1:11: `?` must be followed by an expression\n",
        ),
        (
            "echo $((a : b))\n",
            "<standard input>:1:11: ternary operator missing `?` before `:`\n",
        ),
        (
            "echo $(([x] = 1))\n",
            "<standard input>:1:9: `[` must follow a name like a[i]\n",
        ),
        (
            "echo $((,b))\n",
            "<standard input>:1:9: `,` must follow an expression\n",
        ),
        (
            "echo $((1 + 2 *))\n",
            "<standard input>:1:15: `*` must be followed by an expression\n",
        ),
        (
            "echo $((a++);\n",
            "<standard input>:1:6: reached `)` without matching `$((` with `))`\n",
        ),
    ],
)
def test_arithmetic_expression_errors(run_shfmt, script, expected_err):
    """Each malformed arithmetic expression has its own message."""
    # CATCHES: the ternary pair, the index-before-name rule, the comma
    # operator and the "reached `)`" mismatch variant are all distinct
    # error paths with exact columns.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        ("echo $((a ? b : c))\n", "echo $((a ? b : c))\n"),
        ("echo $((x = y > 1 ? 2 : 3))\n", "echo $((x = y > 1 ? 2 : 3))\n"),
        ("echo $((a[i] = 1))\n", "echo $((a[i] = 1))\n"),
        ("echo $((a += 2, b = 3))\n", "echo $((a += 2, b = 3))\n"),
        ("echo $((2 ** 10))\n", "echo $((2 ** 10))\n"),
        ("echo $((16#ff))\n", "echo $((16#ff))\n"),
    ],
)
def test_arithmetic_expressions_format(run_shfmt, script, expected):
    """Valid ternary, comma, index and base literals format unchanged."""
    # CATCHES: the printer keeps the operator spacing of the arithmetic
    # grammar, including the comma and the # in 16#ff.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        (
            "[[ a foo b ]]\n",
            "<standard input>:1:6: not a valid test operator: `foo`\n",
        ),
        (
            "[[ a -qq b ]]\n",
            "<standard input>:1:6: not a valid test operator: `-qq`\n",
        ),
        (
            "[[ a == ! b ]]\n",
            "<standard input>:1:11: not a valid test operator: `b`\n",
        ),
        (
            "[[ a ==n b ]]\n",
            "<standard input>:1:6: not a valid test operator: `==n`\n",
        ),
        ("[[ ]]\n", "<standard input>:1:1: `[[` must be followed by an expression\n"),
        (
            "[[ (a) == b ]]\n",
            "<standard input>:1:8: expected `&&`, `||` or `]]` after complex expr\n",
        ),
        (
            "[[ a == (b) ]]\n",
            "<standard input>:1:6: `==` must be followed by a word\n",
        ),
    ],
)
def test_test_expression_errors(run_shfmt, script, expected_err):
    """The [[ ]] grammar rejects invalid operators at precise columns."""
    # CATCHES: a word where an operator belongs, an operator glued to
    # its operand (==n), a parenthesised operand after ==, and an empty
    # test are four different failures.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        ("[[ (a == b) ]]\n", "[[ (a == b) ]]\n"),
        ("[[ a < b ]]\n", "[[ a < b ]]\n"),
        ("[[ a -eq b && c -lt d ]]\n", "[[ a -eq b && c -lt d ]]\n"),
    ],
)
def test_test_expressions_format(run_shfmt, script, expected):
    """Parenthesised tests and the numeric/string operators format back."""
    # CATCHES: < is a string comparison inside [[ ]] (not a redirect),
    # and the numeric operators keep single spaces.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("script", "expected_err"),
    [
        (
            "a=((1 2))\n",
            "<standard input>:1:3: `((` can only be used to open an arithmetic cmd\n",
        ),
        (
            "a=([0]=(1 2))\n",
            "<standard input>:1:7: arrays cannot be nested\n",
        ),
        (
            "a=(1 <2)\n",
            "<standard input>:1:6: array element values must be words\n",
        ),
        (
            "a=(1 2) ls\n",
            "<standard input>:1:1: inline variables cannot be arrays\n",
        ),
        (
            "case $a in x y) ;; esac\n",
            "<standard input>:1:14: case patterns must be separated with `|`\n",
        ),
        (
            "case $a in <) ;; esac\n",
            "<standard input>:1:12: case patterns must consist of words\n",
        ),
        (
            "cat << E$(x)OF\n",
            "<standard input>:1:9: expansions not allowed in heredoc words\n",
        ),
    ],
)
def test_array_and_case_validation_errors(run_shfmt, script, expected_err):
    """Array literals and case patterns validate their element shapes."""
    # CATCHES: nested arrays, non-word elements, inline array variables,
    # unseparated case patterns and expansions in heredoc delimiters
    # each produce a distinct message at a distinct column.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == expected_err


@pytest.mark.parametrize(
    ("dialect", "script", "expected"),
    [
        (
            "mksh",
            "case $a in x) echo; ;| y) echo; ;| esac\n",
            "case $a in x) echo ;| y) echo ;| esac\n",
        ),
        (
            "bash",
            "case $a in x) echo; ;;& y) echo; ;;& esac\n",
            "case $a in x) echo ;;& y) echo ;;& esac\n",
        ),
        (
            "bash",
            "case $a in x) echo;& y) echo;& esac\n",
            "case $a in x) echo ;& y) echo ;& esac\n",
        ),
    ],
)
def test_case_terminators_canonicalized(run_shfmt, dialect, script, expected):
    """Case terminators get a space before them, and ;| is mksh-only."""
    # CATCHES: ;;& and ;& are bash terminators while ;| belongs to mksh
    # alone, and the printer inserts the missing space after each one.
    proc = run_shfmt(["-ln=%s" % dialect], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_korn_case_terminator_rejected_by_bash(run_shfmt):
    """bash does not know the ;| case terminator."""
    # CATCHES: bash lexes ;| as a plain semicolon, so the error is the
    # generic "can only immediately follow a statement" at the `;`.
    proc = run_shfmt(
        ["-ln=bash"], input_text="case $a in x) echo; ;| y) echo; ;| esac\n"
    )
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "<standard input>:1:21: `;` can only immediately follow a statement\n"


def test_invalid_utf8_input(run_shfmt, tmp_path):
    """A file with invalid UTF-8 bytes is rejected by the lexer."""
    # CATCHES: the lexer validates UTF-8 while scanning and reports the
    # byte position in the file's path-prefixed error.
    script = tmp_path / "bad.sh"
    script.write_bytes(b"echo \xff\n")
    proc = run_shfmt([str(script)])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "%s:1:6: invalid UTF-8 encoding\n" % script


def test_valid_utf8_passes_through(run_shfmt):
    """Multi-byte UTF-8 text formats unchanged."""
    # CATCHES: the lexer accepts valid UTF-8 and the writer keeps the
    # bytes (héllo) as they were read.
    proc = run_shfmt(["-ln=bash"], input_text="echo héllo\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo héllo\n"


def test_nesting_depth_limit(run_shfmt):
    """More than 10000 nested subshells is a dedicated parse error."""
    # CATCHES: the parser has a hard node-depth limit of 10000; going
    # one over reports at the column of the offending parenthesis.
    deep = "(" * 10001 + "true" + ")" * 10001 + "\n"
    proc = run_shfmt(["-ln=bash"], input_text=deep)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "<standard input>:1:10002: nesting is deeper than 10000 levels\n"


def test_nesting_depth_just_under_limit(run_shfmt):
    """9999 nested subshells still parse and format."""
    # CATCHES: the depth limit is exactly 10000, so 9999 levels must
    # still succeed and be printed back verbatim.
    deep = "(" * 9999 + "true" + ")" * 9999 + "\n"
    proc = run_shfmt(["-ln=bash"], input_text=deep)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == deep


@pytest.mark.parametrize(
    ("script", "expected"),
    [
        ("echo `ls`\n", "echo $(ls)\n"),
        ("echo `ls -l`\n", "echo $(ls -l)\n"),
        ("echo $'a\\tb'\n", "echo $'a\\tb'\n"),
        ("echo $\"foo\"\n", "echo $\"foo\"\n"),
        ("echo $(<file)\n", "echo $(<file)\n"),
    ],
)
def test_lexer_canonicalizations(run_shfmt, script, expected):
    """Backquotes become $(), while $'...' and $\"...\" stay."""
    # CATCHES: the printer normalizes legacy backquote command
    # substitution but must keep the ANSI-C and locale string forms.
    proc = run_shfmt(["-ln=bash"], input_text=script)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_backslash_newline_continuation(run_shfmt):
    """A backslash-newline inside a word joins the two lines."""
    # CATCHES: the line continuation is removed by the lexer, so the
    # two-line input formats as one word on one line.
    proc = run_shfmt(["-ln=bash"], input_text="echo a\\\nb\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo ab\n"


def test_comments_are_preserved(run_shfmt):
    """A comment-only input formats with its text intact."""
    # CATCHES: comments live in the tree and are reprinted; they are
    # not stripped by the parser even when alone in the file.
    proc = run_shfmt(["-ln=bash"], input_text="# just a comment\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "# just a comment\n"
