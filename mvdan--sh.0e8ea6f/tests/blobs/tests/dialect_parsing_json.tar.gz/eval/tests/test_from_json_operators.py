"""--from-json decoding of every operator enum value.

The typed JSON decoder maps operator spellings ("Op", "Names" fields) to
their enum values through generated UnmarshalText methods.  These tests
decode each legal spelling of every operator enum and pin the exact
formatted output, so a re-implementation that misses a spelling or maps
it to the wrong operator fails.
"""

import json

import pytest


def _tree(run_shfmt, flags, source):
    """Encode source to a typed tree and return it as a dict."""
    proc = run_shfmt([*flags, "--to-json"], input_text=source)
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout)


def _decode(run_shfmt, tree):
    """Feed a (possibly mutated) tree to --from-json."""
    return run_shfmt(["--from-json"], input_text=json.dumps(tree))


def _find_by_type(obj, node_type, found):
    """Collect every dict carrying the given "Type" tag."""
    if isinstance(obj, dict):
        if obj.get("Type") == node_type:
            found.append(obj)
        for value in obj.values():
            _find_by_type(value, node_type, found)
    elif isinstance(obj, list):
        for value in obj:
            _find_by_type(value, node_type, found)


# How to reach the operator field of each template: either by node type
# tag or by a fixed path from the tree root.
TEMPLATES = {
    "redir": ("x > f\n", ("Stmts", 0, "Redirs", 0), "Op"),
    "redir_hdoc": ("x << f\nbody\nf\n", ("Stmts", 0, "Redirs", 0), "Op"),
    "proc": ("echo <(y)\n", "ProcSubst", "Op"),
    "glob": ("echo !(x)\n", "ExtGlob", "Op"),
    "bincmd": ("a && b\n", "BinaryCmd", "Op"),
    "case": ("case x in a) b;; esac\n", ("Stmts", 0, "Cmd", "Items", 0), "Op"),
    "parnames": ("echo ${!a*}\n", "ParamExp", "Names"),
    "parexp": ("echo ${a-b}\n", "ParamExp", "Exp"),
    "unarit": ("echo $((!a))\n", "UnaryArithm", "Op"),
    "binarit": ("echo $((a + b))\n", "BinaryArithm", "Op"),
    "untest": ("[[ -e f ]]\n", "UnaryTest", "Op"),
    "bintest": ("[[ a = b ]]\n", "BinaryTest", "Op"),
}


def _mutate(run_shfmt, template_key, op):
    """Return the decode result of the template with its operator set to op."""
    source, locator, field = TEMPLATES[template_key]
    tree = _tree(run_shfmt, ["-ln=bash"], source)
    if isinstance(locator, tuple):
        node = tree
        for step in locator:
            node = node[step]
    else:
        found = []
        _find_by_type(tree, locator, found)
        node = found[0]
    if field == "Exp":
        node["Exp"]["Op"] = op
    else:
        node[field] = op
    return _decode(run_shfmt, tree)


@pytest.mark.parametrize(
    ("template", "op", "expected"),
    [
        pytest.param("redir", ">", "x >f\n", id="redir->"),
        pytest.param("redir", ">>", "x >>f\n", id="redir->>"),
        pytest.param("redir", "<", "x <f\n", id="redir-<"),
        pytest.param("redir", "<>", "x <>f\n", id="redir-<>"),
        pytest.param("redir", "<&", "x <&f\n", id="redir-<&"),
        pytest.param("redir", ">&", "x >&f\n", id="redir->&"),
        pytest.param("redir", ">|", "x >|f\n", id="redir->|"),
        pytest.param("redir", ">>|", "x >>|f\n", id="redir->>|"),
        pytest.param("redir", "<<<", "x <<<f\n", id="redir-<<<"),
        pytest.param("redir", "&>", "x &>f\n", id="redir-&>"),
        pytest.param("redir", "&>|", "x &>|f\n", id="redir-&>|"),
        pytest.param("redir", "&>>", "x &>>f\n", id="redir-&>>"),
        pytest.param("redir", "&>>|", "x &>>|f\n", id="redir-&>>|"),
        pytest.param("redir_hdoc", "<<", "x <<f\nbody\nf\n", id="redir-<<"),
        pytest.param(
            "redir_hdoc", "<<-", "x <<-f\n\tbody\nf\n", id="redir-<<-"
        ),
        pytest.param("proc", "<(", "echo <(y)\n", id="proc-<("),
        pytest.param("proc", "=(", "echo =(y)\n", id="proc-=("),
        pytest.param("proc", ">(", "echo >(y)\n", id="proc->("),
        pytest.param("glob", "?(", "echo ?(x)\n", id="glob-?("),
        pytest.param("glob", "*(", "echo *(x)\n", id="glob-*("),
        pytest.param("glob", "+(", "echo +(x)\n", id="glob-+("),
        pytest.param("glob", "@(", "echo @(x)\n", id="glob-@("),
        pytest.param("glob", "!(", "echo !(x)\n", id="glob-!("),
        pytest.param("bincmd", "&&", "a && b\n", id="bincmd-&&"),
        pytest.param("bincmd", "||", "a || b\n", id="bincmd-||"),
        pytest.param("bincmd", "|", "a | b\n", id="bincmd-|"),
        pytest.param("bincmd", "|&", "a |& b\n", id="bincmd-|&"),
        pytest.param("case", ";;", "case x in a) b ;; esac\n", id="case-;;"),
        pytest.param("case", ";&", "case x in a) b ;& esac\n", id="case-;&"),
        pytest.param("case", ";;&", "case x in a) b ;;& esac\n", id="case-;;&"),
        pytest.param("case", ";|", "case x in a) b ;| esac\n", id="case-;|"),
        pytest.param("parnames", "*", "echo ${!a*}\n", id="parnames-*"),
        pytest.param("parnames", "@", "echo ${!a@}\n", id="parnames-@"),
    ],
)
def test_operator_enum_decodes(run_shfmt, template, op, expected):
    """Every redirect, procsubst, glob, bincmd, case and names operator
    spelled in a typed JSON tree decodes and prints back canonically."""
    # CATCHES: the enum UnmarshalText tables accept each real operator
    # spelling, so a missing or mis-mapped spelling formats the wrong
    # operator or fails to decode at all.
    proc = _mutate(run_shfmt, template, op)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("op", "expected"),
    [
        pytest.param("+", "echo ${a+b}\n", id="parexp-+"),
        pytest.param(":+", "echo ${a:+b}\n", id="parexp-:+"),
        pytest.param("-", "echo ${a-b}\n", id="parexp--"),
        pytest.param(":-", "echo ${a:-b}\n", id="parexp-:-"),
        pytest.param("?", "echo ${a?b}\n", id="parexp-?"),
        pytest.param(":?", "echo ${a:?b}\n", id="parexp-:?"),
        pytest.param("=", "echo ${a=b}\n", id="parexp-="),
        pytest.param(":=", "echo ${a:=b}\n", id="parexp-:="),
        pytest.param("%", "echo ${a%b}\n", id="parexp-%"),
        pytest.param("%%", "echo ${a%%b}\n", id="parexp-%%"),
        pytest.param("#", "echo ${a#b}\n", id="parexp-#"),
        pytest.param("##", "echo ${a##b}\n", id="parexp-##"),
        pytest.param(":#", "echo ${a:#b}\n", id="parexp-:#"),
        pytest.param(":|", "echo ${a:|b}\n", id="parexp-:|"),
        pytest.param(":*", "echo ${a:*b}\n", id="parexp-:*"),
        pytest.param("^", "echo ${a^b}\n", id="parexp-^"),
        pytest.param("^^", "echo ${a^^b}\n", id="parexp-^^"),
        pytest.param(",", "echo ${a,b}\n", id="parexp-,"),
        pytest.param(",,", "echo ${a,,b}\n", id="parexp-,,"),
        pytest.param("@", "echo ${a@b}\n", id="parexp-@"),
    ],
)
def test_parexp_operator_enum_decodes(run_shfmt, op, expected):
    """All twenty parameter-expansion operator spellings decode from JSON."""
    # CATCHES: the ParExpOperator table covers the colon and case-operator
    # spellings; a re-implementation that misses one formats the wrong
    # expansion operator.
    proc = _mutate(run_shfmt, "parexp", op)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("op", "expected"),
    [
        pytest.param("!", "echo $((! a))\n", id="unarit-!"),
        pytest.param("~", "echo $((~a))\n", id="unarit-~"),
        pytest.param("++", "echo $((++a))\n", id="unarit-++"),
        pytest.param("--", "echo $((--a))\n", id="unarit---"),
        pytest.param("+", "echo $((+a))\n", id="unarit-+"),
        pytest.param("-", "echo $((-a))\n", id="unarit--"),
    ],
)
def test_unary_arith_operator_enum_decodes(run_shfmt, op, expected):
    """The six unary arithmetic operator spellings decode from JSON.

    The printer puts a space after '!' but not after the other five, since
    the reference lexer classifies '!' specially.
    """
    # CATCHES: unary operator spellings map to distinct enum values and
    # '!' is the one printed with a following space.
    proc = _mutate(run_shfmt, "unarit", op)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("op", "expected"),
    [
        pytest.param("+", "echo $((a + b))\n", id="binarit-+"),
        pytest.param("-", "echo $((a - b))\n", id="binarit--"),
        pytest.param("*", "echo $((a * b))\n", id="binarit-*"),
        pytest.param("/", "echo $((a / b))\n", id="binarit-/"),
        pytest.param("%", "echo $((a % b))\n", id="binarit-%"),
        pytest.param("**", "echo $((a ** b))\n", id="binarit-**"),
        pytest.param("==", "echo $((a == b))\n", id="binarit-=="),
        pytest.param(">", "echo $((a > b))\n", id="binarit->"),
        pytest.param("<", "echo $((a < b))\n", id="binarit-<"),
        pytest.param("!=", "echo $((a != b))\n", id="binarit-!="),
        pytest.param("<=", "echo $((a <= b))\n", id="binarit-<="),
        pytest.param(">=", "echo $((a >= b))\n", id="binarit->="),
        pytest.param("&", "echo $((a & b))\n", id="binarit-&"),
        pytest.param("|", "echo $((a | b))\n", id="binarit-|"),
        pytest.param("^", "echo $((a ^ b))\n", id="binarit-^"),
        pytest.param(">>", "echo $((a >> b))\n", id="binarit->>"),
        pytest.param("<<", "echo $((a << b))\n", id="binarit-<<"),
        pytest.param("&&", "echo $((a && b))\n", id="binarit-&&"),
        pytest.param("||", "echo $((a || b))\n", id="binarit-||"),
        pytest.param("^^", "echo $((a ^^ b))\n", id="binarit-^^"),
        pytest.param(",", "echo $((a, b))\n", id="binarit-,"),
        pytest.param("?", "echo $((a ? b))\n", id="binarit-?"),
        pytest.param(":", "echo $((a : b))\n", id="binarit-:"),
        pytest.param("=", "echo $((a = b))\n", id="binarit-="),
        pytest.param("+=", "echo $((a += b))\n", id="binarit-+="),
        pytest.param("-=", "echo $((a -= b))\n", id="binarit--="),
        pytest.param("*=", "echo $((a *= b))\n", id="binarit-*="),
        pytest.param("/=", "echo $((a /= b))\n", id="binarit-/="),
        pytest.param("%=", "echo $((a %= b))\n", id="binarit-%="),
        pytest.param("&=", "echo $((a &= b))\n", id="binarit-&="),
        pytest.param("|=", "echo $((a |= b))\n", id="binarit-|="),
        pytest.param("^=", "echo $((a ^= b))\n", id="binarit-^="),
        pytest.param("<<=", "echo $((a <<= b))\n", id="binarit-<<="),
        pytest.param(">>=", "echo $((a >>= b))\n", id="binarit->>="),
        pytest.param("&&=", "echo $((a &&= b))\n", id="binarit-&&="),
        pytest.param("||=", "echo $((a ||= b))\n", id="binarit-||="),
        pytest.param("^^=", "echo $((a ^^= b))\n", id="binarit-^^="),
        pytest.param("**=", "echo $((a **= b))\n", id="binarit-**="),
    ],
)
def test_binary_arith_operator_enum_decodes(run_shfmt, op, expected):
    """All thirty-eight binary arithmetic operator spellings decode."""
    # CATCHES: the binary table includes spellings the bash lexer itself
    # rejects (&&=, ||=, ^^=, **=); the decoder still accepts them and
    # prints them back, unlike a parser round trip.
    proc = _mutate(run_shfmt, "binarit", op)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("op", "expected"),
    [
        pytest.param("-e", "[[ -e f ]]\n", id="untest--e"),
        pytest.param("-f", "[[ -f f ]]\n", id="untest--f"),
        pytest.param("-d", "[[ -d f ]]\n", id="untest--d"),
        pytest.param("-c", "[[ -c f ]]\n", id="untest--c"),
        pytest.param("-b", "[[ -b f ]]\n", id="untest--b"),
        pytest.param("-p", "[[ -p f ]]\n", id="untest--p"),
        pytest.param("-S", "[[ -S f ]]\n", id="untest--S"),
        pytest.param("-L", "[[ -L f ]]\n", id="untest--L"),
        pytest.param("-k", "[[ -k f ]]\n", id="untest--k"),
        pytest.param("-g", "[[ -g f ]]\n", id="untest--g"),
        pytest.param("-u", "[[ -u f ]]\n", id="untest--u"),
        pytest.param("-G", "[[ -G f ]]\n", id="untest--G"),
        pytest.param("-O", "[[ -O f ]]\n", id="untest--O"),
        pytest.param("-N", "[[ -N f ]]\n", id="untest--N"),
        pytest.param("-r", "[[ -r f ]]\n", id="untest--r"),
        pytest.param("-w", "[[ -w f ]]\n", id="untest--w"),
        pytest.param("-x", "[[ -x f ]]\n", id="untest--x"),
        pytest.param("-s", "[[ -s f ]]\n", id="untest--s"),
        pytest.param("-t", "[[ -t f ]]\n", id="untest--t"),
        pytest.param("-z", "[[ -z f ]]\n", id="untest--z"),
        pytest.param("-n", "[[ -n f ]]\n", id="untest--n"),
        pytest.param("-o", "[[ -o f ]]\n", id="untest--o"),
        pytest.param("-v", "[[ -v f ]]\n", id="untest--v"),
        pytest.param("-R", "[[ -R f ]]\n", id="untest--R"),
        pytest.param("!", "[[ ! f ]]\n", id="untest-!"),
        pytest.param("(", "[[ ( f ]]\n", id="untest-("),
    ],
)
def test_unary_test_operator_enum_decodes(run_shfmt, op, expected):
    """All twenty-six unary test operator spellings decode from JSON."""
    # CATCHES: the unary test table includes the '-S' style capitals and
    # even '!' and '(' as spellings; each must print back verbatim.
    proc = _mutate(run_shfmt, "untest", op)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("op", "expected"),
    [
        pytest.param("=~", "[[ a =~ b ]]\n", id="bintest-=~"),
        pytest.param("-nt", "[[ a -nt b ]]\n", id="bintest--nt"),
        pytest.param("-ot", "[[ a -ot b ]]\n", id="bintest--ot"),
        pytest.param("-ef", "[[ a -ef b ]]\n", id="bintest--ef"),
        pytest.param("-eq", "[[ a -eq b ]]\n", id="bintest--eq"),
        pytest.param("-ne", "[[ a -ne b ]]\n", id="bintest--ne"),
        pytest.param("-le", "[[ a -le b ]]\n", id="bintest--le"),
        pytest.param("-ge", "[[ a -ge b ]]\n", id="bintest--ge"),
        pytest.param("-lt", "[[ a -lt b ]]\n", id="bintest--lt"),
        pytest.param("-gt", "[[ a -gt b ]]\n", id="bintest--gt"),
        pytest.param("&&", "[[ a && b ]]\n", id="bintest-&&"),
        pytest.param("||", "[[ a || b ]]\n", id="bintest-||"),
        pytest.param("=", "[[ a = b ]]\n", id="bintest-="),
        pytest.param("==", "[[ a == b ]]\n", id="bintest-=="),
        pytest.param("!=", "[[ a != b ]]\n", id="bintest-!="),
        pytest.param("<", "[[ a < b ]]\n", id="bintest-<"),
        pytest.param(">", "[[ a > b ]]\n", id="bintest->"),
    ],
)
def test_binary_test_operator_enum_decodes(run_shfmt, op, expected):
    """All seventeen binary test operator spellings decode from JSON."""
    # CATCHES: '=' and '==' are distinct enum values and '=~' has its own
    # spelling; a re-implementation that conflates them prints the wrong
    # comparison.
    proc = _mutate(run_shfmt, "bintest", op)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
