"""shfmt's own flag surface and stdin modes beyond dialect selection.

These pin the flag-validation errors that fire before any parsing, the
version output, the -l/-d report modes applied to standard input, the
--filename/apply-ignore interactions, and which EditorConfig language
sections match which dialects.
"""

import pytest

VERSION = "v3.0.0-20261012132700-0e8ea6fccd96\n"


def test_version_flag(run_shfmt):
    """--version prints the module version from the build info."""
    # CATCHES: the version string is baked into the binary from the Go
    # module metadata, not derived from the input or flags.
    proc = run_shfmt(["--version"], input_text="")
    assert proc.returncode == 0
    assert proc.stdout == VERSION
    assert proc.stderr == ""


def test_fn_bl_conflict(run_shfmt):
    """-fn and -bl are mutually exclusive printer options."""
    # CATCHES: the deprecated function-next-line flag conflicts with the
    # block-next-line flag and errors out before reading any input.
    proc = run_shfmt(["-fn", "-bl", "-"], input_text="echo hi\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "-fn and -bl cannot coexist; note that -fn is deprecated\n"
    )


@pytest.mark.parametrize(
    ("flags", "message"),
    [
        (["-l=x", "-"], "only -l and -l=0 allowed\n"),
        (["-f=x", "-"], "only -f and -f=0 allowed\n"),
        (["--detect=bogus", "-"], "--detect only allows default, exec, or all\n"),
    ],
)
def test_optional_value_flag_validation(run_shfmt, flags, message):
    """-l, -f and --detect only accept their fixed value spellings."""
    # CATCHES: these flags take optional values, so anything but the
    # allowed spellings is rejected with a dedicated message, not the
    # generic unknown-flag error.
    proc = run_shfmt(flags, input_text="echo hi\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == message


def test_list_flag_reports_unformatted_stdin(run_shfmt):
    """-l names stdin when its formatting differs and stays quiet otherwise."""
    # CATCHES: -l prints the name (never the formatted bytes) and exits 1
    # only when the input differs from what shfmt would print.
    proc = run_shfmt(["-l", "-"], input_text=" echo hi\n")
    assert proc.returncode == 1
    assert proc.stdout == "<standard input>\n"
    assert proc.stderr == ""

    proc = run_shfmt(["-l", "-"], input_text="echo hi\n")
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""


def test_list_null_separated_stdin(run_shfmt):
    """-l=0 prints the stdin name followed by a NUL byte."""
    # CATCHES: the =0 spelling switches the separator from newline to a
    # raw NUL, with no trailing newline at all.
    proc = run_shfmt(["-l=0", "-"], input_text=" echo hi\n")
    assert proc.returncode == 1
    assert proc.stdout == "<standard input>\x00"
    assert proc.stderr == ""

    proc = run_shfmt(["-l=0", "-"], input_text="echo hi\n")
    assert proc.returncode == 0
    assert proc.stdout == ""


def test_diff_flag_on_stdin(run_shfmt):
    """-d prints a unified diff against the stdin name and exits 1."""
    # CATCHES: the diff labels use the stdin name with a .orig suffix for
    # the left side, and the exit status marks the difference like -l.
    proc = run_shfmt(["-d", "-"], input_text=" echo  hi\n")
    assert proc.returncode == 1
    assert proc.stdout == (
        "diff <standard input>.orig <standard input>\n"
        "--- <standard input>.orig\n"
        "+++ <standard input>\n"
        "@@ -1,1 +1,1 @@\n"
        "- echo  hi\n"
        "+echo hi\n"
    )
    assert proc.stderr == ""

    proc = run_shfmt(["-d", "-"], input_text="echo hi\n")
    assert proc.returncode == 0
    assert proc.stdout == ""


def test_write_flag_rejected_on_stdin(run_shfmt):
    """-w cannot rewrite standard input."""
    # CATCHES: the write-back mode is file-only, so combining it with the
    # stdin argument fails before anything is parsed.
    proc = run_shfmt(["-w", "-"], input_text="echo hi\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "-w cannot be used on standard input\n"


def test_filename_flag_rejected_with_file_args(run_shfmt):
    """--filename only names stdin, never a file argument."""
    # CATCHES: the check fires before the (missing) file is even opened,
    # so the message is about the flag, not about the path.
    proc = run_shfmt(["--filename", "x.sh", "nosuchfile"], input_text="")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "-filename can only be used with stdin\n"


def test_apply_ignore_skips_ignored_stdin(run_shfmt, tmp_path):
    """--apply-ignore honors an ignore=true [*] section for stdin too."""
    # CATCHES: with the flag, an EditorConfig ignore rule makes shfmt
    # exit 0 while printing nothing at all, even for misformatted input.
    (tmp_path / ".editorconfig").write_text("[*]\nignore = true\n")
    proc = run_shfmt(["--apply-ignore", "-"], input_text=" echo hi\n")
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""


def test_ignore_without_apply_ignore_still_formats(run_shfmt, tmp_path):
    """Without --apply-ignore the ignore rule is not consulted on stdin."""
    # CATCHES: ignore is opt-in for explicit paths, so the same
    # .editorconfig leaves normal stdin formatting untouched.
    (tmp_path / ".editorconfig").write_text("[*]\nignore = true\n")
    proc = run_shfmt(["-"], input_text=" echo hi\n")
    assert proc.returncode == 0
    assert proc.stdout == "echo hi\n"
    assert proc.stderr == ""


def test_apply_ignore_needs_a_section(run_shfmt, tmp_path):
    """A header-less ignore property never applies to any file."""
    # CATCHES: EditorConfig properties before the first section header
    # belong to no section, so even --apply-ignore keeps formatting.
    (tmp_path / ".editorconfig").write_text("ignore = true\n")
    proc = run_shfmt(["--apply-ignore", "-"], input_text=" echo hi\n")
    assert proc.returncode == 0
    assert proc.stdout == "echo hi\n"
    assert proc.stderr == ""


def test_apply_ignore_false_formats(run_shfmt, tmp_path):
    """ignore=false is an explicit non-ignore."""
    # CATCHES: only the exact string "true" skips the file; anything else
    # (including "false") formats normally under --apply-ignore.
    (tmp_path / ".editorconfig").write_text("[*]\nignore = false\n")
    proc = run_shfmt(["--apply-ignore", "-"], input_text=" echo  hi\n")
    assert proc.returncode == 0
    assert proc.stdout == "echo hi\n"
    assert proc.stderr == ""


SIMPLIFIABLE = "echo $((a + ((b - c))))\n"
SIMPLIFIED = "echo $((a + (b - c)))\n"


def _with_ec(tmp_path, section):
    """Write an .editorconfig with one section setting simplify."""
    (tmp_path / ".editorconfig").write_text(
        f"[[{section}]]\nsimplify = true\n"
    )


@pytest.mark.parametrize(
    ("section", "filename", "applies"),
    [
        ("zsh", "s.zsh", True),
        ("zsh", "s.bash", False),
        ("bash", "s.bats", True),
        ("bash", "s.zsh", False),
        ("shell", "s.mksh", True),
        ("shell", "s.bash", True),
    ],
)
def test_editorconfig_language_sections(run_shfmt, tmp_path, section,
                                        filename, applies):
    """Language sections only apply to files of that dialect family.

    [[shell]] matches every shell; [[bash]] matches bash and bats;
    [[zsh]] matches only zsh.  simplify=true is the observable effect.
    """
    # CATCHES: the section-to-dialect matching list is fixed, so a bash
    # section must not grab zsh files and a zsh section must not grab
    # bash files, while both honor [[shell]].
    _with_ec(tmp_path, section)
    proc = run_shfmt(["--filename", filename, "-"], input_text=SIMPLIFIABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (SIMPLIFIED if applies else SIMPLIFIABLE)
