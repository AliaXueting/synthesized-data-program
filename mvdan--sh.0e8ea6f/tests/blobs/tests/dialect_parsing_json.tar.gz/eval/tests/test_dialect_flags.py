"""Tests for the -ln/--language-dialect and -p flag surface.

Covers accepted dialect names and their aliases, the exact rejection
message for unknown values, the -p shorthand, flag-value syntax forms
and the conflict rules between -p and -ln.
"""

import pytest

SIMPLE_SCRIPT = "echo hi\n"

# All accepted spellings of the dialect flag value.
VALID_DIALECTS = ["bash", "posix", "mksh", "bats", "zsh", "auto"]
# Aliases that resolve to the POSIX dialect.
POSIX_ALIASES = ["posix", "sh", "dash"]
# Values that must be rejected by the flag parser.
INVALID_DIALECTS = ["bogus", "", "SH", "bash5", "posix "]


@pytest.mark.parametrize("dialect", VALID_DIALECTS)
def test_valid_dialect_names_accepted(run_shfmt, dialect):
    """Every documented dialect name formats simple input successfully."""
    # CATCHES: a re-implementation that rejects or mis-parses any of the
    # six documented -ln values (including "auto") would fail here.
    proc = run_shfmt(["-ln=" + dialect], input_text=SIMPLE_SCRIPT)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == SIMPLE_SCRIPT
    assert proc.stderr == ""


@pytest.mark.parametrize("alias", POSIX_ALIASES)
def test_posix_aliases_reject_arrays(run_shfmt, alias):
    """The "sh" and "dash" spellings behave exactly like -ln=posix."""
    # CATCHES: only "posix" is documented in the usage text, but the
    # flag also accepts "sh" and "dash"; all three must gate arrays.
    proc = run_shfmt(["-ln=" + alias], input_text="a=(1 2)\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        '<standard input>:1:3: arrays are a bash/mksh/zsh feature; '
        'tried parsing as posix\n'
    )


@pytest.mark.parametrize("dialect", INVALID_DIALECTS)
def test_invalid_dialect_value_rejected(run_shfmt, dialect):
    """An unknown dialect value fails with an exact flag-parser error."""
    # CATCHES: the wording "unknown shell language variant" with a Go
    # %q-quoted value and exit code 2 must be reproduced exactly.
    proc = run_shfmt(["-ln=" + dialect], input_text=SIMPLE_SCRIPT)
    assert proc.returncode == 2
    assert proc.stdout == ""
    expected_first = (
        'invalid value "%s" for flag -ln: unknown shell language '
        'variant: "%s"\n' % (dialect, dialect)
    )
    assert proc.stderr.startswith(expected_first)
    # The flag error is followed by the full usage text on stderr.
    assert "usage: shfmt [flags] [path ...]" in proc.stderr
    assert "-ln, --language-dialect str  bash/posix/mksh/bats/zsh" in proc.stderr


def test_invalid_dialect_prints_full_usage(run_shfmt):
    """The usage dump after a bad -ln value is the complete help text."""
    # CATCHES: a re-implementation printing a short hint instead of the
    # full usage block (ending in the project URL) would differ.
    proc = run_shfmt(["-ln=nope"], input_text=SIMPLE_SCRIPT)
    lines = proc.stderr.splitlines()
    assert proc.returncode == 2
    assert lines[0] == 'invalid value "nope" for flag -ln: unknown shell language variant: "nope"'
    assert lines[1] == "usage: shfmt [flags] [path ...]"
    assert lines[-1] == (
        "For more information and to report bugs, see https://github.com/mvdan/sh."
    )
    assert len(lines) > 40  # the whole usage block, not just one line


def test_ln_without_value_is_a_flag_error(run_shfmt):
    """A dangling -ln with no value reports "flag needs an argument"."""
    # CATCHES: the separate-argument form "-ln bash" is valid, but a
    # trailing -ln with no value at all must be a usage error (exit 2).
    proc = run_shfmt(["-ln"], input_text=SIMPLE_SCRIPT)
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr.startswith("flag needs an argument: -ln\n")
    assert "usage: shfmt [flags] [path ...]" in proc.stderr


def test_ln_accepts_space_separated_value(run_shfmt):
    """The Go-flag style "-ln zsh" works like "-ln=zsh"."""
    # CATCHES: a custom flag parser that only accepts the "=" form would
    # reject this spelling, which the reference accepts.
    proc = run_shfmt(["-ln", "zsh"], input_text="echo ${+a}\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo ${+a}\n"


def test_long_language_dialect_flag(run_shfmt):
    """The long --language-dialect spelling parses the same as -ln."""
    # CATCHES: only the long spelling carries the hyphenated name
    # "language-dialect"; it must map to the same dialect resolution.
    proc = run_shfmt(["--language-dialect=zsh"], input_text="echo ${+a}\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo ${+a}\n"


def test_p_shorthand_selects_posix(run_shfmt):
    """-p alone makes the parser reject bash-only array syntax."""
    # CATCHES: -p is documented as shorthand for -ln=posix; it must
    # produce the very same posix rejection message as -ln=posix.
    proc = run_shfmt(["-p"], input_text="a=(1 2)\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        '<standard input>:1:3: arrays are a bash/mksh/zsh feature; '
        'tried parsing as posix\n'
    )


@pytest.mark.parametrize("order", [["-p", "-ln=bash"], ["-ln=bash", "-p"]])
def test_p_and_ln_conflict(run_shfmt, order):
    """Passing both -p and -ln is rejected regardless of their order."""
    # CATCHES: the two flags cannot coexist; the error text and the
    # order-independence of the check are both observable behavior.
    proc = run_shfmt(order, input_text=SIMPLE_SCRIPT)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "-p and -ln=lang cannot coexist\n"


def test_last_ln_value_wins(run_shfmt):
    """When -ln is repeated, the last occurrence decides the dialect."""
    # CATCHES: the flag parser keeps the final value, so the input is
    # parsed as posix and arrays are rejected even though -ln=bash came
    # first.
    proc = run_shfmt(["-ln=bash", "-ln=posix"], input_text="a=(1 2)\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert "tried parsing as posix" in proc.stderr


def test_explicit_ln_auto_still_autodetects(run_shfmt):
    """The literal value "auto" keeps filename-based detection active."""
    # CATCHES: "-ln=auto" must not be treated as an explicit dialect;
    # the .zsh filename below must still select the zsh parser.
    proc = run_shfmt(
        ["-ln=auto", "--filename", "s.zsh"], input_text="echo ${+a}\n"
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo ${+a}\n"


def test_explicit_ln_suppresses_auto_detection_suffix(run_shfmt):
    """With an explicit dialect, LangErrors lose the "(parsed as ...)" suffix."""
    # CATCHES: the suffix "(parsed as bash via -ln=auto)" is only added
    # when the dialect was guessed; an explicit -ln=bash must omit it.
    proc = run_shfmt(["-ln=bash", "--filename", "s.sh"], input_text="echo ${+a}\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "s.sh:1:6: `${+foo}` is a zsh feature; tried parsing as bash\n"
    )


def test_unknown_flag_is_rejected(run_shfmt):
    """An undefined flag produces the Go flag-package error and usage."""
    # CATCHES: the exact "flag provided but not defined" wording and
    # exit code 2 come straight from the Go flag runtime.
    proc = run_shfmt(["--bogus"], input_text=SIMPLE_SCRIPT)
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr.startswith("flag provided but not defined: -bogus\n")
    assert "usage: shfmt [flags] [path ...]" in proc.stderr
