"""Directory and file arguments: which files shfmt picks up, and how.

A directory argument is walked with fileutil.CouldBeScript2, which skips
hidden names, non-regular entries (directories, symlinks) and non-shell
extensions, keeps shell extensions unconditionally, and defers
extensionless names to their shebang.  These tests pin that triage, the
dialect each discovered file is parsed as (visible through dialect-gated
errors and canonicalization), and the -l/-w report modes applied to
walked files.
"""

import pytest

# Content that shfmt would rewrite if it were formatted at all.
SKIPPED_BODY = "echo  skipped\n"
KEPT_BODY = "echo ok\n"


def _make_tree(tmp_path, files, symlinks=None):
    """Create tree/ holding the given relative files and symlinks."""
    for name, text in files.items():
        path = tmp_path / "tree" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    for name, target in (symlinks or {}).items():
        (tmp_path / "tree" / name).symlink_to(target)


def test_directory_walk_formats_shell_files(run_shfmt, tmp_path):
    """A directory argument formats every shell file it discovers."""
    # CATCHES: the walk skips .py files, hidden names, symlinks,
    # extensionless files without a shebang, files too short to hold one
    # and .git directories, while .bash/.zsh/.mksh files and an
    # extensionless file with a bash shebang are formatted in lexical
    # order, each in its own dialect (the mksh case braces canonicalize).
    _make_tree(
        tmp_path,
        {
            "a.bash": "function f { echo; }\n",
            "b.zsh": "echo ${+a}\n",
            "c.py": "print 1\n",
            ".hidden.bash": "function g { echo; }\n",
            "script": "#!/bin/bash\nfunction h { echo; }\n",
            "noshebang": "echo no_shebang\n",
            "tiny": "ab",
            "sub/d.mksh": "case $a { x) echo;; }\n",
            ".git/e.bash": "function i { echo; }\n",
        },
        {"link.bash": "a.bash"},
    )
    proc = run_shfmt(["tree"])
    assert proc.returncode == 0
    assert proc.stdout == (
        "function f { echo; }\n"
        "echo ${+a}\n"
        "#!/bin/bash\n"
        "function h { echo; }\n"
        "case $a in x) echo ;; esac\n"
    )
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("files", "symlinks"),
    [
        pytest.param({".hidden.bash": SKIPPED_BODY}, {}, id="hidden"),
        pytest.param({"x.py": SKIPPED_BODY}, {}, id="extension"),
        pytest.param({}, {"link.bash": "keep.bash"}, id="symlink"),
        pytest.param({"plain": SKIPPED_BODY}, {}, id="no-shebang"),
        pytest.param({"tiny": "ab"}, {}, id="too-short"),
        pytest.param({".git/e.bash": SKIPPED_BODY}, {}, id="vcs-dir"),
    ],
)
def test_walk_skips_non_script_entries(run_shfmt, tmp_path, files, symlinks):
    """Only entries CouldBeScript2 accepts are formatted; the rest vanish.

    Each case puts a misformatted candidate next to a formatted keep.bash:
    if the candidate were picked up, its rewritten bytes would appear in
    stdout alongside the sibling's.
    """
    # CATCHES: the triage arms are checked in order — a leading dot, a
    # non-regular entry, a non-shell extension — and an extensionless
    # name is only read for a shebang, so each of these candidates is
    # silently dropped while keep.bash still prints.
    _make_tree(tmp_path, {"keep.bash": KEPT_BODY, **files}, symlinks)
    proc = run_shfmt(["tree"])
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == KEPT_BODY
    assert proc.stderr == ""


def test_walk_parse_error_names_the_file_and_continues(run_shfmt, tmp_path):
    """A parse error in one walked file is reported and the walk continues."""
    # CATCHES: the error carries the walked path (not <standard input>),
    # the remaining files are still formatted to stdout, and the exit
    # status becomes 1 without stopping the walk.
    _make_tree(
        tmp_path,
        {"arr.bash": "a=(1 2)\n", "after.bash": "echo ok\n"},
    )
    proc = run_shfmt(["-ln=posix", "tree"])
    assert proc.returncode == 1
    assert proc.stdout == "echo ok\n"
    assert proc.stderr == (
        "tree/arr.bash:1:3: arrays are a bash/mksh/zsh feature; "
        "tried parsing as posix\n"
    )


def test_walk_parse_error_carries_the_auto_suffix(run_shfmt, tmp_path):
    """Auto-detected dialects add the -ln=auto suffix to walked errors."""
    # CATCHES: under the default -ln=auto the .bash extension selects
    # bash, so a zsh-only construct fails with the same wording as stdin
    # plus the '(parsed as bash via -ln=auto)' suffix.
    _make_tree(
        tmp_path,
        {"z.bash": "echo ${(e)a}\n", "ok.bash": "echo ok\n"},
    )
    proc = run_shfmt(["tree"])
    assert proc.returncode == 1
    assert proc.stdout == "echo ok\n"
    assert proc.stderr == (
        "tree/z.bash:1:6: parameter expansion flags are a zsh feature; "
        "tried parsing as bash (parsed as bash via -ln=auto)\n"
    )


def test_symlink_argument_dialect_comes_from_the_shebang(run_shfmt, tmp_path):
    """An extensionless symlink arg is parsed per the target's shebang."""
    # CATCHES: the symlink is resolved to a regular file before the
    # triage, but the dialect still comes from the argument's own name
    # (no extension), so the resolved file's .bash extension is ignored
    # and its zsh shebang wins — ${+a} would be a parse error as bash.
    (tmp_path / "real.bash").write_text("#!/bin/zsh\necho ${+a}\n")
    (tmp_path / "linknoext").symlink_to("real.bash")
    proc = run_shfmt(["linknoext"])
    assert proc.returncode == 0
    assert proc.stdout == "#!/bin/zsh\necho ${+a}\n"
    assert proc.stderr == ""


def test_extensionless_file_argument_uses_its_shebang(run_shfmt, tmp_path):
    """An extensionless file argument is parsed per its shebang."""
    # CATCHES: without an extension the dialect is taken from the first
    # line, so the zsh-only ${+a} expansion formats instead of erroring.
    (tmp_path / "plain").write_text("#!/bin/zsh\necho ${+a}\n")
    proc = run_shfmt(["plain"])
    assert proc.returncode == 0
    assert proc.stdout == "#!/bin/zsh\necho ${+a}\n"
    assert proc.stderr == ""


def test_unknown_shebang_file_argument_falls_back_to_bash(run_shfmt, tmp_path):
    """A non-shell shebang on an extensionless file falls back to bash."""
    # CATCHES: the shebang line is kept as a comment and the body is
    # parsed as bash, visible because the trailing ';' is dropped — a
    # skipped file would print nothing at all.
    (tmp_path / "perl").write_text("#!/usr/bin/perl\nprint 1;\n")
    proc = run_shfmt(["perl"])
    assert proc.returncode == 0
    assert proc.stdout == "#!/usr/bin/perl\nprint 1\n"
    assert proc.stderr == ""


def test_missing_path_argument_reports_lstat(run_shfmt):
    """A path argument that does not exist fails with the lstat error."""
    # CATCHES: the walk stats the argument before opening it, so the
    # message names lstat and the raw path, and nothing is printed.
    proc = run_shfmt(["nosuchfile"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "lstat nosuchfile: no such file or directory\n"


def test_list_flag_names_walked_files(run_shfmt, tmp_path):
    """-l and -l=0 print the paths of walked files that differ."""
    # CATCHES: only the misformatted file is named (with a NUL separator
    # for -l=0), the already-formatted sibling stays quiet, and the exit
    # status marks the difference.
    _make_tree(
        tmp_path,
        {"u.bash": " echo hi\n", "f.bash": "echo hi\n"},
    )
    listed = run_shfmt(["-l", "tree"])
    assert listed.returncode == 1
    assert listed.stdout == "tree/u.bash\n"
    assert listed.stderr == ""

    nul = run_shfmt(["-l=0", "tree"])
    assert nul.returncode == 1
    assert nul.stdout == "tree/u.bash\x00"
    assert nul.stderr == ""


def test_write_flag_rewrites_walked_files(run_shfmt, tmp_path):
    """-w rewrites the misformatted walked file in place and stays quiet."""
    # CATCHES: the formatted bytes replace the file contents on disk
    # while stdout stays empty, and the already-formatted sibling is left
    # untouched.
    _make_tree(
        tmp_path,
        {"u.bash": " echo hi\n", "f.bash": "echo hi\n"},
    )
    proc = run_shfmt(["-w", "tree"])
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert (tmp_path / "tree" / "u.bash").read_text() == "echo hi\n"
    assert (tmp_path / "tree" / "f.bash").read_text() == "echo hi\n"


def test_write_flag_refuses_to_replace_a_symlink(run_shfmt, tmp_path):
    """-w refuses to write back through a symlink argument."""
    # CATCHES: the write-back stats the argument itself with lstat, so a
    # symlink (even to a regular file) is rejected with the exact
    # 'refusing to atomically replace' wording instead of writing.
    (tmp_path / "u3.bash").write_text(" echo bad\n")
    (tmp_path / "link3.bash").symlink_to("u3.bash")
    proc = run_shfmt(["-w", "link3.bash"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'refusing to atomically replace "link3.bash" with a regular file '
        "as it is not one already\n"
    )
