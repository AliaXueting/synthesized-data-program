"""Tests for the EditorConfig-driven dialect selection.

When no parser or printer flag is passed, shfmt reads language_dialect
(or its legacy spelling shell_variant) from .editorconfig files.  A
dialect guessed this way is reported with the suffix "(parsed as LANG
via EditorConfig)".
"""

import pytest

ZSH_ONLY = "echo ${+a}\n"


def test_shell_variant_selects_the_dialect(run_shfmt, tmp_path):
    """shell_variant = zsh in .editorconfig parses a .sh file as zsh."""
    # CATCHES: the [[shell]] section applies to any shell file, and the
    # legacy shell_variant spelling must still be honored.
    (tmp_path / ".editorconfig").write_text(
        "[[shell]]\nshell_variant = zsh\n", encoding="utf-8"
    )
    proc = run_shfmt(["--filename", "s.sh"], input_text=ZSH_ONLY)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == ZSH_ONLY


def test_language_dialect_suffix_in_errors(run_shfmt, tmp_path):
    """A dialect set via EditorConfig is named with its own error suffix."""
    # CATCHES: the LangError suffix differs per detection source; here
    # it must say "(parsed as bash via EditorConfig)", not "-ln=auto".
    (tmp_path / ".editorconfig").write_text(
        "[[shell]]\nlanguage_dialect = bash\n", encoding="utf-8"
    )
    proc = run_shfmt(["--filename", "s.sh"], input_text=ZSH_ONLY)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "s.sh:1:6: `${+foo}` is a zsh feature; tried parsing as bash "
        "(parsed as bash via EditorConfig)\n"
    )


def test_editorconfig_beats_the_filename_extension(run_shfmt, tmp_path):
    """language_dialect overrides even an explicit .zsh file name."""
    # CATCHES: the EditorConfig property wins over filename-based
    # detection, so a .zsh name with language_dialect=bash fails.
    (tmp_path / ".editorconfig").write_text(
        "[[shell]]\nlanguage_dialect = bash\n", encoding="utf-8"
    )
    proc = run_shfmt(["--filename", "s.zsh"], input_text=ZSH_ONLY)
    assert proc.returncode == 1
    assert proc.stderr.endswith("(parsed as bash via EditorConfig)\n")


def test_invalid_editorconfig_dialect_ignored(run_shfmt, tmp_path):
    """A bogus shell_variant value falls back to normal auto detection."""
    # CATCHES: an unparseable dialect property is ignored rather than
    # fatal, and the fallback suffix reverts to "-ln=auto".
    (tmp_path / ".editorconfig").write_text(
        "[[shell]]\nshell_variant = bogus\n", encoding="utf-8"
    )
    proc = run_shfmt(["--filename", "s.sh"], input_text=ZSH_ONLY)
    assert proc.returncode == 1
    assert proc.stderr == (
        "s.sh:1:6: `${+foo}` is a zsh feature; tried parsing as bash "
        "(parsed as bash via -ln=auto)\n"
    )


def test_star_section_applies_to_any_file(run_shfmt, tmp_path):
    """A glob [*] section also carries the dialect property."""
    # CATCHES: EditorConfig sections are matched by glob or language
    # name; both routes must reach the same dialect selection.
    (tmp_path / ".editorconfig").write_text(
        "[*]\nshell_variant = zsh\n", encoding="utf-8"
    )
    proc = run_shfmt(["--filename", "s.sh"], input_text=ZSH_ONLY)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == ZSH_ONLY


def test_bash_language_section(run_shfmt, tmp_path):
    """A [[bash]] section matches files detected as bash."""
    # CATCHES: bash files match both [[shell]] and [[bash]] sections;
    # here the bash section forces posix and arrays are rejected.
    (tmp_path / ".editorconfig").write_text(
        "[[bash]]\nshell_variant = posix\n", encoding="utf-8"
    )
    proc = run_shfmt(["--filename", "s.sh"], input_text="a=(1 2)\n")
    assert proc.returncode == 1
    assert proc.stderr == (
        "s.sh:1:3: arrays are a bash/mksh/zsh feature; tried parsing as posix "
        "(parsed as posix via EditorConfig)\n"
    )


def test_posix_flag_disables_editorconfig(run_shfmt, tmp_path):
    """-p counts as a parser flag, so the .editorconfig file is ignored."""
    # CATCHES: like -ln, the -p shorthand turns the EditorConfig lookup
    # off entirely; the zsh property has no effect and no suffix shows.
    (tmp_path / ".editorconfig").write_text(
        "[[shell]]\nshell_variant = zsh\n", encoding="utf-8"
    )
    proc = run_shfmt(["-p"], input_text=ZSH_ONLY)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:6: `${+foo}` is a zsh feature; tried parsing as posix\n"
    )


def test_editorconfig_not_used_without_the_file(run_shfmt, tmp_path):
    """Without an .editorconfig in sight, detection is filename-based only."""
    # CATCHES: the .editorconfig lookup is purely directory-based; an
    # empty working directory must leave the bash fallback in place.
    proc = run_shfmt(["--filename", "s.sh"], input_text=ZSH_ONLY)
    assert proc.returncode == 1
    assert proc.stderr.endswith("(parsed as bash via -ln=auto)\n")
