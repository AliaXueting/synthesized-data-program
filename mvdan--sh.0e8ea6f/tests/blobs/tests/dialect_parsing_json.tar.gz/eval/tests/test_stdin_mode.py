"""The stdin invocation surface: the bare `-` argument.

shfmt reads stdin when given no arguments, and also when its single
positional argument is `-`.  Flags must precede the `-`; anything
after it becomes another file path.  These tests pin that argument
handling plus the extension matching used with explicit file paths.
"""

import json


def test_dash_argument_is_stdin(run_shfmt):
    """A single `-` argument reads and formats standard input."""
    # CATCHES: `-` selects the stdin path, so errors still carry the
    # `<standard input>` prefix and the auto-detection suffix.
    proc = run_shfmt(["-"], input_text="echo ${+a}\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "<standard input>:1:6: `${+foo}` is a zsh feature; tried parsing "
        "as bash (parsed as bash via -ln=auto)\n"
    )


def test_flags_before_dash_argument(run_shfmt):
    """Dialect and printer flags apply when they precede the `-`."""
    # CATCHES: `-ln=posix -` and `-s -` show that flag parsing stops at
    # the `-` but the flags seen before it are honored on stdin.
    posix = run_shfmt(["-ln=posix", "-"], input_text="a=(1 2)\n")
    assert posix.returncode == 1
    assert posix.stdout == ""
    assert posix.stderr == (
        "<standard input>:1:3: arrays are a bash/mksh/zsh feature; "
        "tried parsing as posix\n"
    )
    simplified = run_shfmt(["-s", "-"], input_text="echo $((a + ((b - c))))\n")
    assert simplified.returncode == 0, simplified.stderr
    assert simplified.stdout == "echo $((a + (b - c)))\n"


def test_to_json_with_dash_argument(run_shfmt):
    """`--to-json -` prints the typed tree of the stdin program."""
    # CATCHES: the stdin-only check for --to-json counts `-` as stdin,
    # so the tree is printed instead of a usage error.
    proc = run_shfmt(["--to-json", "-"], input_text="echo hi\n")
    assert proc.returncode == 0, proc.stderr
    tree = json.loads(proc.stdout)
    assert tree["Type"] == "File"
    assert tree["Stmts"][0]["Cmd"]["Type"] == "CallExpr"
    assert tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]["Value"] == "hi"


def test_double_dash_then_dash(run_shfmt):
    """`-- -` terminates flag parsing and still means stdin."""
    # CATCHES: Go's flag package treats everything after `--` as
    # positional, and a single `-` positional is still the stdin path.
    proc = run_shfmt(["--", "-"], input_text="echo hi\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo hi\n"


def test_dash_with_second_argument_is_files(run_shfmt):
    """A `-` followed by anything else makes both arguments file paths."""
    # CATCHES: only a lone `-` means stdin; with two positionals both
    # are walked as paths, and the missing files are reported in order.
    proc = run_shfmt(["-", "-ln=posix"], input_text="echo hi\n")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "lstat -: no such file or directory\n"
        "lstat -ln=posix: no such file or directory\n"
    )


def test_filename_flag_combines_with_dash(run_shfmt):
    """--filename still names the stdin stream next to a `-` argument."""
    # CATCHES: the .zsh extension of --filename selects the zsh dialect
    # for the stdin bytes read through the `-` argument.
    proc = run_shfmt(["--filename", "s.zsh", "-"], input_text="echo ${+a}\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "echo ${+a}\n"


def test_dash_uses_shebang_detection(run_shfmt):
    """Auto-detection reads the stdin shebang in `-` mode too."""
    # CATCHES: the zsh shebang overrides the bash fallback, so the
    # zsh-only ${+a} expansion parses without any -ln flag.
    proc = run_shfmt(["-"], input_text="#!/bin/zsh\necho ${+a}\n")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "#!/bin/zsh\necho ${+a}\n"


def test_extension_matching_is_case_sensitive(run_shfmt, tmp_path):
    """Only lowercase .bash selects bash; .BASH falls back to bash."""
    # CATCHES: the extension table is matched exactly, so an uppercase
    # spelling goes through the fallback and appends the -ln=auto
    # suffix to the error.
    for name in ["a.BASH", "b.Bash"]:
        script = tmp_path / name
        script.write_text("echo ${+a}\n", encoding="utf-8")
        proc = run_shfmt([str(script)])
        assert proc.returncode == 1
        assert proc.stdout == ""
        assert proc.stderr == (
            "%s:1:6: `${+foo}` is a zsh feature; tried parsing as bash "
            "(parsed as bash via -ln=auto)\n" % script
        )
