"""zsh-only parameter expansion tail forms.

${+name} set-ness checks, colon modifiers like ${foo:U:u}, the short ${=}
prefix, an unterminated ${( flag expression, and the error when a nested
parameter expansion is followed by more word characters.
"""


def test_zsh_is_set_operator(run_shfmt):
    """${+var} asks whether the variable is set and round-trips."""
    # CATCHES: the leading + after ${ is zsh's IsSet operator -- the printer
    # keeps it distinct from the ${var+alt} substitution form.
    res = run_shfmt(["-ln=zsh", "-"], "echo ${+x} ${+y}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${+x} ${+y}\n"
    assert res.stderr == ""


def test_zsh_flag_expression_unterminated(run_shfmt):
    """An unterminated ${( flags expression reports the open paren."""
    # CATCHES: the ${( form has its own EOF diagnostic naming `(` and `)`,
    # not the generic brace-matching error for ${.
    res = run_shfmt(["-ln=zsh", "-"], "echo ${(x\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:8: reached EOF without matching `(` with `)`\n"


def test_zsh_colon_modifiers_chain(run_shfmt):
    """${foo:U:u} parses a chain of zsh history modifiers."""
    # CATCHES: each colon-separated modifier is a separate Modifiers entry;
    # the chain reprints with all colons intact rather than collapsing.
    res = run_shfmt(["-ln=zsh", "-"], "echo ${foo:U:u}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${foo:U:u}\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=zsh", "-"], "echo ${foo:U}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${foo:U}\n"


def test_zsh_colon_modifier_unterminated(run_shfmt):
    """An unterminated ${foo:U reports the unopened dollar-brace."""
    # CATCHES: EOF inside a modifier chain points back at the ${ with the
    # "reached EOF without matching" wording at the dollar's column.
    res = run_shfmt(["-ln=zsh", "-"], "echo ${foo:U\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:6: reached EOF without matching `${` with `}`\n"


def test_zsh_empty_short_prefix(run_shfmt):
    """${=} keeps the short Split prefix with an empty parameter."""
    # CATCHES: the doubled/equality prefix scan treats a bare = before } as
    # a prefix on an empty name instead of an operator error.
    res = run_shfmt(["-ln=zsh", "-"], "echo ${=}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${=}\n"
    assert res.stderr == ""


def test_zsh_nested_expansion_cannot_be_followed_by_word(run_shfmt):
    """A word character right after ${${x}} is a dedicated zsh error."""
    # CATCHES: the message names the nested expansion itself, which only
    # zsh parses, and points at the offending trailing character.
    res = run_shfmt(["-ln=zsh", "-"], "echo ${${x}y}\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:12: nested parameter expansion cannot be followed by a word\n"
    )
