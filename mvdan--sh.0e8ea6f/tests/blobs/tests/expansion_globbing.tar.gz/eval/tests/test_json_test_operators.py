"""The [[ ]] unary operator vocabulary through the typed-JSON forms.

Every unary test operator spelling survives a --to-json / --from-json
round-trip unchanged, `!` is one of the spellings, a JSON-only `(` operator
decodes into an unusual but printable tree, and an unknown spelling is
rejected by name.
"""

import json

import pytest

#: Every UnTestOperator spelling the decoder accepts, in enum order.
UNARY_OPERATORS = [
    "-e", "-f", "-d", "-c", "-b", "-p", "-S", "-L", "-k", "-g", "-u",
    "-G", "-O", "-N", "-r", "-w", "-x", "-s", "-t", "-z", "-n", "-o",
    "-v", "-R", "!",
]


def _find_node(obj, type_name):
    """Depth-first search for the first typed-JSON node of a given type."""
    if isinstance(obj, dict):
        if obj.get("Type") == type_name:
            return obj
        for value in obj.values():
            found = _find_node(value, type_name)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = _find_node(value, type_name)
            if found is not None:
                return found
    return None


@pytest.mark.parametrize("op", UNARY_OPERATORS)
def test_unary_test_operator_round_trip(run_shfmt, op):
    """Each unary operator spelling round-trips through typed JSON."""
    # CATCHES: the JSON encoder emits and the decoder accepts the exact
    # spelling, so `[[ -S x ]]` cannot come back as some alias like -h.
    src = f"[[ {op} x ]]\n"
    encoded = run_shfmt(["--to-json", "-"], src.rstrip("\n"))
    assert encoded.returncode == 0, op
    assert encoded.stderr == ""
    unary = _find_node(json.loads(encoded.stdout), "UnaryTest")
    assert unary is not None, op
    assert unary["Op"] == op, op

    decoded = run_shfmt(["--from-json"], encoded.stdout)
    assert decoded.returncode == 0, op
    assert decoded.stdout == src, op
    assert decoded.stderr == "", op


@pytest.mark.parametrize("src,canonical", [("[[ -a x ]]", "-e"), ("[[ -h x ]]", "-L")])
def test_unary_operator_alias_normalised(run_shfmt, src, canonical):
    """The historical -a and -h spellings encode as their modern forms."""
    # CATCHES: the parser maps -a to -e and -h to -L before the tree is
    # serialised, so the JSON never contains the legacy spellings.
    res = run_shfmt(["--to-json", "-"], src)
    assert res.returncode == 0, src
    unary = _find_node(json.loads(res.stdout), "UnaryTest")
    assert unary is not None, src
    assert unary["Op"] == canonical, src


def _with_operator(run_shfmt, src, old, new):
    """Return the reference JSON for 'src' with one UnaryTest Op rewritten."""
    encoded = run_shfmt(["--to-json", "-"], src)
    assert encoded.returncode == 0
    tree = json.loads(encoded.stdout)
    unary = _find_node(tree, "UnaryTest")
    assert unary is not None
    assert unary["Op"] == old
    unary["Op"] = new
    return json.dumps(tree)


def test_lparen_as_unary_operator_decodes(run_shfmt):
    """A JSON-only Op "(" decodes and prints as a lone opening paren."""
    # CATCHES: "(" is a valid UnTestOperator value for the decoder even
    # though the parser can never build one, and it prints back as `[[ ( x`.
    mutated = _with_operator(run_shfmt, "[[ ! x ]]", "!", "(")
    decoded = run_shfmt(["--from-json"], mutated)
    assert decoded.returncode == 0
    assert decoded.stdout == "[[ ( x ]]\n"
    assert decoded.stderr == ""


def test_unknown_unary_operator_rejected(run_shfmt):
    """An operator spelling outside the vocabulary is named in the error."""
    # CATCHES: the decoder reports the invalid value itself with the enum
    # name, on stderr with exit status 1 and no stdout.
    mutated = _with_operator(run_shfmt, "[[ ! x ]]", "!", "-q")
    decoded = run_shfmt(["--from-json"], mutated)
    assert decoded.returncode == 1
    assert decoded.stdout == ""
    assert decoded.stderr == 'invalid UnTestOperator: "-q"\n'
