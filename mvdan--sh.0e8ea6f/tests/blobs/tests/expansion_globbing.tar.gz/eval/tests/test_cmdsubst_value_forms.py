"""Command-substitution shapes beyond the plain $(...) form.

The mksh/bash value-of forms (${ stmts;} and ${|stmts;}), the backquote
special cases (a substitution holding only a comment, or ending in an
unclosed heredoc), and the spacing rules that keep $( (subshell) ) apart
from the arithmetic $((...)).
"""


def test_value_of_forms(run_shfmt):
    """${ stmts;} and ${|stmts;} reformat their inner padding exactly."""
    # CATCHES: the value-of form keeps the space after `${` but drops the
    # space before `}`; the reply-var form drops the space after `${|` too.
    cases = [
        ("echo ${ ls; }\n", "echo ${ ls;}\n"),
        ("echo ${| ls; }\n", "echo ${|ls;}\n"),
        ("echo ${|ls;}\n", "echo ${|ls;}\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-ln=mksh", "-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src

    # bash accepts the same two forms; only posix rejects them.
    res = run_shfmt(["-"], "echo ${ ls; }\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${ ls;}\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=posix", "-"], "echo ${ ls; }\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:6: `${ stmts;}` is a bash/mksh feature; "
        "tried parsing as posix\n"
    )


def test_value_of_requires_leading_space(run_shfmt):
    """${ls;} without a space after ${ is parameter syntax, not value-of."""
    # CATCHES: the value-of form is only entered when the first rune after
    # `${` is a space, tab or newline; otherwise `;` is an invalid parameter
    # expansion operator at its own column.
    res = run_shfmt(["-ln=mksh", "-"], "echo ${ls; }\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:10: not a valid parameter expansion operator: `;`\n"
    )


def test_value_of_multiline_body(run_shfmt):
    """A multi-line ${ ... } body keeps its newlines and needs no `;`."""
    # CATCHES: the closing brace goes on its own line and no semicolon is
    # inserted after the last statement when a newline already separated it.
    res = run_shfmt(["-ln=mksh", "-"], "echo ${\n\tls\n}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${\n\tls\n}\n"
    assert res.stderr == ""


def test_backquote_only_comment(run_shfmt):
    """A backquote containing just a comment prints back as `# text`."""
    # CATCHES: the printer has a special case for a backquote whose only
    # content is a comment; it must not gain $( ) or lose the comment text.
    res = run_shfmt(["-"], "echo `# comment`\n")
    assert res.returncode == 0
    assert res.stdout == "echo `# comment`\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "echo `#`\n")
    assert res.returncode == 0
    assert res.stdout == "echo `#`\n"
    assert res.stderr == ""


def test_cmdsubst_paren_disambiguation(run_shfmt):
    """$( (subshell) ) keeps its spaces; $(((ls))) stays glued."""
    # CATCHES: a command substitution whose first statement starts with `(`
    # must keep a space so it cannot be misread as $(( arithmetic; a real
    # arithmetic expansion containing a parenthesised word stays glued.
    cases = [
        ("echo $( (ls) )\n", "echo $( (ls) )\n"),
        ("echo $( ( (ls) ) )\n", "echo $( ( (ls) ) )\n"),
        ("echo $(( (ls) ))\n", "echo $(((ls)))\n"),
        ("echo $(((ls)))\n", "echo $(((ls)))\n"),
        ("echo $((1+1)) $( (ls) ) $((2+2))\n",
         "echo $((1 + 1)) $( (ls) ) $((2 + 2))\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_backquote_ending_in_heredoc(run_shfmt):
    """A backquote whose last statement has an unclosed heredoc goes multi-line."""
    # CATCHES: the closing backquote arrived right after the heredoc body,
    # so the printer forces a newline after `$(` and reindents the command;
    # the backquote itself is canonicalised into $( ... ).
    res = run_shfmt(["-"], "x=`cat <<EOF\nbody`\n")
    assert res.returncode == 0
    assert res.stdout == "x=$(\n\tcat <<EOF\nbody\nEOF\n)\n"
    assert res.stderr == ""


def test_cmdsubst_statement_layout(run_shfmt):
    """Semicolon-separated statements inside $(...) become newlines."""
    # CATCHES: `a; b` inside a command substitution is printed as two lines
    # while a compound command on one line stays on one line.
    res = run_shfmt(["-"], "echo $(a; b)\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(\n\ta\n\tb\n)\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "echo $(if true; then echo x; fi)\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(if true; then echo x; fi)\n"
    assert res.stderr == ""


def test_keep_padding_in_cmdsubst(run_shfmt):
    """-kp preserves the original padding inside a command substitution."""
    # CATCHES: keep-padding realigns the closing paren with the original
    # column, leaving trailing spaces on the last statement line even though
    # the statements moved onto their own indented lines.
    res = run_shfmt(["-kp", "-"], "echo $(  a   b  )\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(  a   b  )\n"
    assert res.stderr == ""

    res = run_shfmt(["-kp", "-"], "echo $( a; b )\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(\n\ta\n\tb         \n)\n"
    assert res.stderr == ""
