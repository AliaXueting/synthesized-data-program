"""Multi-line word layouts: test clauses, arithmetic and heredoc words.

How continuation lines inside [[ ]] and $(( )) are re-indented, what -bn does
to a test operator, and the odd shapes an escaped newline inside a heredoc
redirect word produces.
"""


def test_multiline_test_expr_indents_continuation(run_shfmt):
    """A test operand on the next line is indented one level."""
    # CATCHES: the second operand of || moves to its own line indented with
    # a tab, instead of staying at column 1 or joining the first line.
    res = run_shfmt(["-ln=bash", "-"], "[[ a ||\nb ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ a ||\n\tb ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=bash", "-"], "[[ (a) ||\n(b) ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ (a) ||\n\t(b) ]]\n"


def test_binary_next_line_moves_test_operator(run_shfmt):
    """-bn moves the test operator to the start of the continuation line."""
    # CATCHES: with -bn the `||` travels to the next line with the indent,
    # instead of staying at the end of the first line as it does by default.
    res = run_shfmt(["-ln=bash", "-bn", "-"], "[[ a ||\nb ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ a\n\t|| b ]]\n"
    assert res.stderr == ""


def test_multiline_test_inside_if(run_shfmt):
    """An if condition's wrapped test expression is indented the same way."""
    # CATCHES: the wrapping inside the if header behaves like a bare [[ ]],
    # and `then` still lands on the same line as the closing brackets.
    res = run_shfmt(["-ln=bash", "-"], "if [[ a ||\nb ]]; then :; fi\n")
    assert res.returncode == 0
    assert res.stdout == "if [[ a ||\n\tb ]]; then :; fi\n"
    assert res.stderr == ""


def test_arith_continuation_gains_backslash(run_shfmt):
    """A newline inside $(( )) is reprinted as a backslash continuation."""
    # CATCHES: arithmetic cannot span lines, so the printer inserts a space,
    # a backslash and the newline before the second operand.
    res = run_shfmt(["-ln=bash", "-"], "echo $((1 +\n2))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((1 + \\\n2))\n"
    assert res.stderr == ""


def test_heredoc_word_with_escaped_newline(run_shfmt):
    """An escaped newline after the heredoc word keeps the body first."""
    # CATCHES: `<<EOF \\` + newline keeps the backslash-newline in the
    # statement, so the printer emits `cat \\`, then the indented body with
    # the redirect trailing it, then the closing word.
    res = run_shfmt(["-ln=bash", "-"], "cat <<EOF \\\nbody\nEOF\n")
    assert res.returncode == 0
    assert res.stdout == "cat \\\n\tbody <<EOF\nEOF\n"
    assert res.stderr == ""


def test_heredoc_body_starting_with_escaped_newline(run_shfmt):
    """A body whose first line is an escaped newline is left untouched."""
    # CATCHES: the escaped newline at the top of the body means that line can
    # never end the heredoc, and the whole construct round-trips verbatim.
    src = "cat <<EOF\n\\\nbody\nEOF\n"
    res = run_shfmt(["-ln=bash", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_case_semicolon_on_own_line(run_shfmt):
    """A ;; on its own line inside a case item is preserved."""
    # CATCHES: when the item body spans lines the terminator may sit alone on
    # its line, and the printer keeps that instead of pulling it up.
    src = "case x in\na)\n\tb\n\t;;\nesac\n"
    res = run_shfmt(["-ln=bash", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""
