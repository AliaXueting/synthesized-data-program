"""Simplification of array subscripts vs other arithmetic positions.

-s removes redundant parentheses and re-spaces indexes, but it must keep
$-prefixed parameters inside a subscript (x[i] and x[$i] differ for
associative arrays) while inlining the very same parameters elsewhere.
"""

import pytest


@pytest.mark.parametrize(
    "src,expected",
    [
        ("x[(i)]=v\n", "x[i]=v\n"),
        ("x[((i+1))]=v\n", "x[i + 1]=v\n"),
        ("x[i+1]=v\n", "x[i + 1]=v\n"),
        ("x[i+1]+=v\n", "x[i + 1]+=v\n"),
        ("echo ${x[i+1]}\n", "echo ${x[i + 1]}\n"),
        ("echo ${x[(i)]}\n", "echo ${x[i]}\n"),
        ("echo $((x[i+1]))\n", "echo $((x[i + 1]))\n"),
        ("echo $((x[(i)]))\n", "echo $((x[i]))\n"),
        ("a=([i+1]=v)\n", "a=([i + 1]=v)\n"),
    ],
)
def test_index_parens_and_spacing_simplified(run_shfmt, src, expected):
    """-s strips subscript parentheses and spaces binary operators there."""
    # CATCHES: the subscript keeps its identity while (i) becomes i and i+1
    # becomes i + 1 -- simplification reaches inside the brackets.
    res = run_shfmt(["-ln=bash", "-s", "-"], src)
    assert res.returncode == 0, src
    assert res.stdout == expected, src
    assert res.stderr == "", src


def test_array_element_parens_are_kept(run_shfmt):
    """A subscript inside an array literal keeps its parentheses."""
    # CATCHES: unlike x[(i)]=v, the element [i]= inside a=(...) is not run
    # through paren removal, so a=([(i)]=v) is reproduced unchanged.
    res = run_shfmt(["-ln=bash", "-s", "-"], "a=([(i)]=v)\n")
    assert res.returncode == 0
    assert res.stdout == "a=([(i)]=v)\n"
    assert res.stderr == ""


@pytest.mark.parametrize(
    "src,expected",
    [
        ("x[$i]=v\n", "x[$i]=v\n"),
        ("x[$i+1]=v\n", "x[$i + 1]=v\n"),
        ("echo ${x[$i+1]}\n", "echo ${x[$i + 1]}\n"),
        ("a=([$i+1]=v)\n", "a=([$i + 1]=v)\n"),
        ("echo $((x[$i]))\n", "echo $((x[$i]))\n"),
        ("echo ${!x[$i]}\n", "echo ${!x[$i]}\n"),
    ],
)
def test_dollar_parameters_kept_in_subscripts(run_shfmt, src, expected):
    """A $ inside a subscript is never inlined, in any word context."""
    # CATCHES: x[i] and x[$i] mean different keys for associative arrays, so
    # simplification records the subscript and leaves every $i alone -- only
    # the spacing around the operator changes.
    res = run_shfmt(["-ln=bash", "-s", "-"], src)
    assert res.returncode == 0, src
    assert res.stdout == expected, src
    assert res.stderr == "", src


def test_nested_arith_subscript_left_alone(run_shfmt):
    """x[$((i+1))] is never a string key, so it only gets re-spaced."""
    # CATCHES: nested arithmetic expansions inside a subscript are always
    # numeric, so the simplifier only normalises the spacing inside them.
    res = run_shfmt(["-ln=bash", "-s", "-"], "x[$((i+1))]=v\n")
    assert res.returncode == 0
    assert res.stdout == "x[$((i + 1))]=v\n"
    assert res.stderr == ""


def test_same_parameter_inlined_outside_subscript(run_shfmt):
    """$i in a subscript survives while $i next to it is inlined."""
    # CATCHES: in $((x[$i] + $i)) the operand position drops the dollar but
    # the subscript position keeps it -- one expression, two treatments.
    res = run_shfmt(["-ln=bash", "-s", "-"], "echo $((x[$i] + $i))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((x[$i] + i))\n"
    assert res.stderr == ""
