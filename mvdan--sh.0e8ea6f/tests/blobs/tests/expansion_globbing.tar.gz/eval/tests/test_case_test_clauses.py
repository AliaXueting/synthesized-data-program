"""Pattern matching inside case clauses and [[ ]] test clauses.

The case statement and the test clause are the two construct families where
glob patterns and regular expressions are parsed as first-class words.  These
tests pin the operators that separate case items, the layout of multi-line
clauses, and the full operator vocabulary of [[ ]] expressions, including the
special lexing rules for unquoted regex operands.
"""


def test_case_item_terminator_operators(run_shfmt):
    """The three case item terminators (;;, ;&, ;;&) survive formatting."""
    # CATCHES: each terminator is a distinct token -- a re-implementation that
    # only knows `;;` would mangle the fall-through spellings ;& and ;;&, and
    # items written on one line must not be exploded into the block layout.
    src = (
        "case $x in\n"
        "a) echo one ;;\n"
        "b) echo two ;&\n"
        "c) echo three ;;&\n"
        "*) echo four ;;\n"
        "esac\n"
    )
    expected = (
        "case $x in\n"
        "a) echo one ;;\n"
        "b) echo two ;&\n"
        "c) echo three ;;&\n"
        "*) echo four ;;\n"
        "esac\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == ""


def test_case_multiline_item_layout_preserved(run_shfmt):
    """Case items whose body is on its own line keep that block layout."""
    # CATCHES: the layout is per item -- a body already on its own line keeps
    # the newline and tab indentation instead of being collapsed.
    src = (
        "case $x in\n"
        "a)\n"
        "\techo A\n"
        "\t;;\n"
        "*)\n"
        "\techo B\n"
        "\t;;\n"
        "esac\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_case_one_line_items_keep_flow(run_shfmt):
    """Single-line case items stay single-line with spaces around ;;."""
    # CATCHES: items written on one line are not exploded into the multi-line
    # layout, and the ;; gains spacing on both sides.
    res = run_shfmt(["-"], "case $x in a) echo x ;;& b) echo y ;; esac\n")
    assert res.returncode == 0
    assert res.stdout == "case $x in a) echo x ;;& b) echo y ;; esac\n"
    assert res.stderr == ""


def test_case_pipe_terminator_is_rejected(run_shfmt):
    """The zsh-only `;|` case terminator is a parse error in the bash dialect."""
    # CATCHES: ;| is not part of the accepted operator set, and the diagnostic
    # blames the `|` character at its exact column.
    res = run_shfmt(["-"], "case $x in a) echo x ;| b) echo y ;; esac\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:23: `|` can only immediately follow a statement\n"


def test_case_comment_attached_to_item(run_shfmt):
    """A trailing comment on the last case item is kept inside the clause."""
    # CATCHES: the comment stays glued to the ;; line rather than being moved
    # after esac or dropped entirely.
    res = run_shfmt(["-"], "case $x in a) echo x ;; # trailing\nesac\n")
    assert res.returncode == 0
    assert res.stdout == "case $x in a) echo x ;; # trailing\nesac\n"
    assert res.stderr == ""


def test_case_extglob_and_default_pattern(run_shfmt):
    """Extglob patterns and the * default pattern mix in one clause."""
    # CATCHES: !(foo|bar) must stay an extended glob word with its pipes
    # spaced, and the bare * default stays a lone star.
    src = "case $x in !(foo|bar)|+(a)) echo three ;; *) echo default ;; esac\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == "case $x in !(foo|bar) | +(a)) echo three ;; *) echo default ;; esac\n"
    assert res.stderr == ""


def test_test_clause_operator_round_trip(run_shfmt):
    """Binary [[ ]] operators keep their spelling and gain spacing."""
    # CATCHES: the operator set spans glob equality, regex match, arithmetic
    # comparison and string ordering -- each must keep its exact letters.
    cases = [
        ("[[ $x == foo* ]]\n", "[[ $x == foo* ]]\n"),
        ("[[ $x != *bar ]]\n", "[[ $x != *bar ]]\n"),
        ("[[ $x =~ ^a[0-9]+b$ ]]\n", "[[ $x =~ ^a[0-9]+b$ ]]\n"),
        ("[[ 1 -lt 2 ]]\n", "[[ 1 -lt 2 ]]\n"),
        ("[[ 3 -ge 4 ]]\n", "[[ 3 -ge 4 ]]\n"),
        ("[[ 5 -eq 6 ]]\n", "[[ 5 -eq 6 ]]\n"),
        ("[[ 7 -ne 8 ]]\n", "[[ 7 -ne 8 ]]\n"),
        ("[[ 9 -gt 10 ]]\n", "[[ 9 -gt 10 ]]\n"),
        ("[[ a < b ]]\n", "[[ a < b ]]\n"),
        ("[[ c > d ]]\n", "[[ c > d ]]\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_test_clause_rejects_chained_comparison(run_shfmt):
    """Two comparison operators in a row are a syntax error, not a chain."""
    # CATCHES: complex expressions must be joined with && or || -- the parser
    # reports the position right after the first complete comparison.
    res = run_shfmt(["-"], "[[ 9 -gt 10 -le 11 ]]\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:13: expected `&&`, `||` or `]]` after complex expr\n"
    )


def test_test_clause_unary_negation_and_groups(run_shfmt):
    """Unary test operators, negation and parenthesised groups are kept."""
    # CATCHES: -z/-n/-f/-v are separate unary tokens, ! keeps its space, and
    # grouping parens hug their contents without inner spaces.
    src = "[[ -z $x || -n $y && -f /tmp/z ]]\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == "[[ -z $x || -n $y && -f /tmp/z ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "[[ ! ( $x == y ) ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ ! ($x == y) ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "[[ $x == y && -v NAME ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ $x == y && -v NAME ]]\n"
    assert res.stderr == ""


def test_test_regex_with_parens_is_one_word(run_shfmt):
    """An unquoted regex with groups stays a single literal word."""
    # CATCHES: the parens in the regex operand belong to the pattern, so they
    # must not be taken as grouping parens or split out of the word.
    res = run_shfmt(["-"], "[[ $x =~ ^(a|b)+c$ ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ $x =~ ^(a|b)+c$ ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "[[ $x =~ a\\(b ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ $x =~ a\\(b ]]\n"
    assert res.stderr == ""


def test_test_regex_mixed_parts_and_command_substitution(run_shfmt):
    """A regex operand may mix quotes and expansions like any other word."""
    # CATCHES: the quoted head and the literal tail form one word, and a
    # backtick substitution inside the operand is normalised to $(...).
    res = run_shfmt(["-"], '[[ $x =~ "start"end ]]\n')
    assert res.returncode == 0
    assert res.stdout == '[[ $x =~ "start"end ]]\n'
    assert res.stderr == ""

    res = run_shfmt(["-"], "[[ $x =~ a`id`b ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ $x =~ a$(id)b ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "[[ $x =~ a$b ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ $x =~ a$b ]]\n"
    assert res.stderr == ""


def test_test_regex_unbalanced_close_paren_error(run_shfmt):
    """A `)` with no opening paren in the regex ends the test expression."""
    # CATCHES: the lexer closes the [[ at that paren, so the error reports the
    # unmatched ]] at the start of the construct, not at the regex.
    res = run_shfmt(["-"], "[[ $x =~ a)b ]]\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:1: reached `)` without matching `[[` with `]]`\n"


def test_legacy_single_bracket_test(run_shfmt):
    """A classic [ ... ] command keeps its brackets and quoted operand."""
    # CATCHES: [ is lexed as a word, not a syntax token, so it must survive
    # byte-for-byte with the spacing rules of a plain command.
    res = run_shfmt(["-"], '[ -n "$x" ]\n')
    assert res.returncode == 0
    assert res.stdout == '[ -n "$x" ]\n'
    assert res.stderr == ""
