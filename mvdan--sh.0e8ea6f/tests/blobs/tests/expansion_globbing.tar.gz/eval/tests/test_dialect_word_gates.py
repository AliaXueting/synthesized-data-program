"""Dialect gates on word-level operator spellings.

Which $-prefixed word forms each dialect lexes at all ($'...', $"...", $[...],
$((#...)), =(...)), the zsh-only arithmetic assignment operators and clobber
redirect aliases, and how the non-supporting dialect reports each one.
"""

import pytest


def test_dollar_quoted_forms_gated_by_dialect(run_shfmt):
    """posix keeps $'...' and $"..." literal; mksh understands both."""
    # CATCHES: outside bash-like dialects the lexer never merges $ with the
    # quote, so the dollar stays a separate literal character in the output.
    cases = [
        ("-ln=posix", "echo $'a'\n", "echo $'a'\n"),
        ("-ln=posix", "echo $\"a\"\n", "echo $\"a\"\n"),
        ("-ln=zsh", "echo $\"a\"\n", "echo $\"a\"\n"),
        ("-ln=mksh", "echo $'a'\n", "echo $'a'\n"),
        ("-ln=mksh", "echo $\"a\"\n", "echo $\"a\"\n"),
        ("-ln=bash", "echo $'a'\n", "echo $'a'\n"),
    ]
    for flags, src, expected in cases:
        res = run_shfmt([flags, "-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_legacy_arith_bracket_only_in_bash(run_shfmt):
    """$[...] is a bash-only spelling; elsewhere it stays literal."""
    # CATCHES: only bash rewrites the legacy $[...] into $((...)); posix and
    # mksh leave the dollar and the bracket as plain literal characters, both
    # unquoted and inside double quotes.
    cases = [
        ("-ln=posix", "echo $[1+2]\n", "echo $[1+2]\n"),
        ("-ln=mksh", "echo $[1+2]\n", "echo $[1+2]\n"),
        ("-ln=zsh", "echo $[1+2]\n", "echo $[1+2]\n"),
        ("-ln=posix", "echo \"$[1+2]\"\n", "echo \"$[1+2]\"\n"),
    ]
    for flags, src, expected in cases:
        res = run_shfmt([flags, "-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_zsh_fd_clobber_aliases_normalise(run_shfmt):
    """zsh >&|, >&!, >>&| and >>&! all print as the &>-family spelling."""
    # CATCHES: the four aliases decode to the same operator values as &>| and
    # &>>|, and the printer always emits the ampersand-first spelling.
    cases = [
        ("echo x >&| f\n", "echo x &>|f\n"),
        ("echo x >&! f\n", "echo x &>|f\n"),
        ("echo x >>&| f\n", "echo x &>>|f\n"),
        ("echo x >>&! f\n", "echo x &>>|f\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-ln=zsh", "-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


@pytest.mark.parametrize(
    "op",
    ["**=", "&&=", "||=", "^^=", "&=", "^=", "+=", "-="],
)
def test_zsh_arith_assignment_operators(run_shfmt, op):
    """The zsh-only compound assignments lex as one operator inside $(( ))."""
    # CATCHES: zsh tokenises **= &&= ||= and ^^= as single assignment
    # operators, so they survive reformatting untouched instead of being
    # re-spaced as two operators.
    src = f"echo $((x {op} 1))\n"
    res = run_shfmt(["-ln=zsh", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_bash_rejects_zsh_arith_assignments(run_shfmt):
    """bash does not know **=, so it reports the bare ** operator error."""
    # CATCHES: bash lexes ** and = separately, so the message blames the
    # power operator rather than mentioning any assignment.
    res = run_shfmt(["-ln=bash", "-"], "echo $((x **= 2))\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:11: `**` must be followed by an expression\n"


def test_unsigned_arith_prefix_is_mksh_only(run_shfmt):
    """$((# ...)) is accepted by mksh and rejected as a bash parse error."""
    # CATCHES: the hash prefix is an mksh unsigned-expression marker, so bash
    # fails with a dialect-gating message that names mksh.
    res = run_shfmt(["-ln=mksh", "-"], "echo $((# 3))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((# 3))\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=bash", "-"], "echo $((# 3))\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:6: unsigned expressions are a mksh feature; "
        "tried parsing as bash\n"
    )


def test_assign_paren_process_substitution_gating(run_shfmt):
    """zsh's =(cmd) form is a process substitution only in zsh."""
    # CATCHES: in bash the =( sequence is reported as a whole operator with
    # the zsh dialect named, not as a stray parenthesis.
    res = run_shfmt(["-ln=zsh", "-"], "echo =(ls)\n")
    assert res.returncode == 0
    assert res.stdout == "echo =(ls)\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=bash", "-"], "echo =(ls)\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:6: `=(` process substitutions are a zsh "
        "feature; tried parsing as bash\n"
    )


@pytest.mark.parametrize(
    "src,line",
    [
        ("case x in a) ;;& b) ;; esac\n", "case patterns must consist of words"),
        ("case x in a) ;& b) ;; esac\n", "`;` can only immediately follow a statement"),
    ],
)
def test_posix_rejects_case_fallthrough_operators(run_shfmt, src, line):
    """The bash ;;& and ;& case terminators do not exist in posix."""
    # CATCHES: without the fallthrough operators the parser reads the marker
    # as plain punctuation, producing two very different diagnostics.
    res = run_shfmt(["-ln=posix", "-"], src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert line in res.stderr
