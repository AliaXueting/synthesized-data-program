"""Malformed expansion constructs and the exact diagnostics they produce.

Each case pins one parser diagnostic for a broken ``${...}`` form: the message
text, the blamed position (line:column) and the exit status.  These are the
errors a user sees when they mistype an expansion operator.
"""

MALFORMED_CASES = [
    # An empty parameter name: the parser runs out of input.
    ("echo ${\n", "<standard input>:1:6: reached EOF without matching `${` with `}`\n"),
    # A newline where an operator was expected.
    ("echo ${var\n", '<standard input>:1:11: not a valid parameter expansion operator: "\\n"\n'),
    # Characters that look like operators but are not.
    ("echo ${var]}\n", "<standard input>:1:11: not a valid parameter expansion operator: `]`\n"),
    ("echo ${var..}\n", "<standard input>:1:11: not a valid parameter expansion operator: `.`\n"),
    ("echo ${x!\n", "<standard input>:1:9: not a valid parameter expansion operator: `!`\n"),
    # Operators that need an operand but found none.
    ("echo ${var[}\n", "<standard input>:1:11: `[` must be followed by an expression\n"),
    ("echo ${var:}\n", "<standard input>:1:11: `:` must be followed by an expression\n"),
    ("echo ${x:/\n", "<standard input>:1:10: `/` must follow an expression\n"),
    ("echo ${x:y:\n", "<standard input>:1:11: `:` must be followed by an expression\n"),
    # Operator combinations that cannot coexist.
    ("echo ${#x\n", "<standard input>:1:10: cannot combine multiple parameter expansion operators\n"),
    # The @-transform operator requires a known letter.
    ("echo ${x@\n", '<standard input>:1:10: invalid @ expansion operator "\\n"\n'),
]


def test_malformed_parameter_expansion_diagnostics(run_shfmt):
    """A broken ${...} yields status 1, empty stdout and one exact message."""
    # CATCHES: the diagnostics differ per mistake -- "must be followed by an
    # expression", "not a valid parameter expansion operator" and "cannot
    # combine multiple parameter expansion operators" are three separate paths.
    for src, message in MALFORMED_CASES:
        res = run_shfmt([], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == message, src


def test_unclosed_brace_reports_the_opening_position(run_shfmt):
    """An EOF after ${ blames the position of the ${ itself."""
    # CATCHES: column 6 is where ${ starts, not where the file ends, so the
    # position points the user at the construct they failed to close.
    res = run_shfmt([], "echo ${x^\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:6: reached EOF without matching `${` with `}`\n"


def test_error_column_tracks_multiline_input(run_shfmt):
    """Positions carry the line number, not just the column offset."""
    # CATCHES: the same construct on line 3 of a script is reported as 3:11,
    # which requires real line tracking rather than a byte offset alone.
    res = run_shfmt([], "a=1\nb=2\necho ${var\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == '<standard input>:3:11: not a valid parameter expansion operator: "\\n"\n'


def test_only_the_first_error_is_reported(run_shfmt):
    """Parsing stops at the first broken expansion in the file."""
    # CATCHES: the diagnostic is emitted exactly once, so a re-implementation
    # must abort at the first error rather than collecting them all.
    res = run_shfmt([], "echo ${var\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr.count("parameter expansion operator") == 1


def test_error_recovery_flag_keeps_going(run_shfmt):
    """--exp.recover still reports the first error but keeps the exit status."""
    # CATCHES: the experimental recovery flag is a plain integer flag whose
    # value 1 changes nothing about this diagnostic's wording or status.
    res = run_shfmt(["--exp.recover=1"], "echo ${var\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == '<standard input>:1:11: not a valid parameter expansion operator: "\\n"\n'


def test_valid_expansion_after_a_comment_is_fine(run_shfmt):
    """A ${...} inside a comment is not an expansion and must not error."""
    # CATCHES: comments are skipped before word parsing, so the malformed
    # text inside them is invisible to the expansion diagnostics.
    res = run_shfmt([], "# echo ${var\n echo ${var}\n")
    assert res.returncode == 0
    assert res.stdout == "# echo ${var\necho ${var}\n"
    assert res.stderr == ""
