"""Command and process substitution forms as seen through the CLI.

``$(...)`` normalisation, legacy backticks, heredocs/herestrings and the
``<(...)`` / ``>(...)`` process substitution forms, plus the exact errors the
parser produces when one of them is left unterminated.
"""


def test_legacy_backticks_become_command_substitution(run_shfmt):
    """Backtick substitution is always re-printed in $( ) form."""
    # CATCHES: `...` and $(...) are interchangeable, and the reference always
    # prints the modern spelling even when the input used backticks.
    res = run_shfmt([], "echo `echo hi`\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(echo hi)\n"
    assert res.stderr == ""


def test_nested_backticks_also_normalised(run_shfmt):
    """A backtick substitution nested inside $( ) is still rewritten."""
    # CATCHES: the rewrite is recursive, so the inner `echo x` becomes
    # $(echo x) while the outer $( ) spelling is preserved.
    res = run_shfmt([], "echo $(echo `echo x`)\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(echo $(echo x))\n"
    assert res.stderr == ""


def test_command_substitution_padding_removed(run_shfmt):
    """Spaces just inside $( ) are dropped, unlike a real subshell."""
    # CATCHES: $( echo hi ) loses the padding because the delimiters are part
    # of the substitution, not a separate subshell command.
    res = run_shfmt([], "echo $( echo hi )\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(echo hi)\n"
    assert res.stderr == ""


def test_multiline_command_substitution_is_indented(run_shfmt):
    """A multi-line substitution body is re-indented with a tab."""
    # CATCHES: the two-space indentation becomes a tab and the closing ) goes
    # on its own line, matching the default indent style.
    res = run_shfmt([], "echo $(\n  echo hi\n)\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(\n\techo hi\n)\n"
    assert res.stderr == ""


def test_quoted_command_substitution_roundtrip(run_shfmt):
    """A substitution inside double quotes keeps its quotes and shape."""
    # CATCHES: "$(echo hi)" must not lose its quotes, and the inner padding
    # rule still applies inside the quoted context.
    res = run_shfmt([], 'echo "$(echo hi)"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "$(echo hi)"\n'
    assert res.stderr == ""


def test_process_substitution_forms(run_shfmt):
    """Both <( ) and >( ) parse in bash and print without extra spaces."""
    # CATCHES: the redirect-looking operators must not be turned into a real
    # redirect; the parenthesised command stays attached to the < or >.
    for src, expected in [
        ("cat <(echo hi)\n", "cat <(echo hi)\n"),
        ("cat >(echo hi)\n", "cat >(echo hi)\n"),
    ]:
        res = run_shfmt([], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_process_substitution_rejected_in_posix(run_shfmt):
    """In POSIX mode <( is not a substitution, so < has no word to take."""
    # CATCHES: posix has no process substitution, so the parser complains
    # about the redirect operator rather than about the parentheses.
    res = run_shfmt(["-ln=posix"], "cat <(echo hi)\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:5: `<` must be followed by a word\n"


def test_unterminated_substitution_errors(run_shfmt):
    """Each unterminated word construct reports its own delimiter."""
    # CATCHES: backticks are reported as an unclosed *quote* while $( is an
    # unmatched *pair*, and both point at column 6 where the word starts.
    cases = [
        ("echo `echo hi\n", '<standard input>:1:6: reached EOF without closing quote "`"\n'),
        ("echo $(echo hi\n", "<standard input>:1:6: reached EOF without matching `$(` with `)`\n"),
        ('echo "unclosed\n', '<standard input>:1:6: reached EOF without closing quote `"`\n'),
        ("echo 'unclosed\n", "<standard input>:1:6: reached EOF without closing quote `'`\n"),
    ]
    for src, message in cases:
        res = run_shfmt([], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == message, src


def test_herestring_loses_padding(run_shfmt):
    """A here-string operator drops the space before its word."""
    # CATCHES: <<< "x:y" becomes <<<"x:y"; the operator is glued to its word
    # exactly like the > and 2> redirect operators are.
    res = run_shfmt([], 'IFS=: read -r a b <<< "x:y"\n')
    assert res.returncode == 0
    assert res.stdout == 'IFS=: read -r a b <<<"x:y"\n'
    assert res.stderr == ""


def test_quoted_herestring_word_roundtrip(run_shfmt):
    """A quoted here-string word keeps its quotes while the space goes."""
    # CATCHES: only the padding is removed; the double quotes around $a must
    # survive because they decide whether the value is re-split.
    res = run_shfmt([], 'x <<<"$a"\n')
    assert res.returncode == 0
    assert res.stdout == 'x <<<"$a"\n'
    assert res.stderr == ""


def test_unquoted_heredoc_body_roundtrip(run_shfmt):
    """An unquoted heredoc body keeps its expansions and its delimiters."""
    # CATCHES: the body of <<EOF is word text where $a will expand, so it must
    # be preserved verbatim including indentation and the delimiter lines.
    src = "x <<EOF\n$a\nEOF\n"
    res = run_shfmt([], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_quoted_heredoc_body_roundtrip(run_shfmt):
    """A quoted delimiter suppresses expansion and must stay quoted."""
    # CATCHES: the quotes around the delimiter change the expansion behaviour
    # of the whole body, so <<'EOF' may never be normalised to <<EOF.
    src = "x <<'EOF'\n$a\nEOF\n"
    res = run_shfmt([], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""
