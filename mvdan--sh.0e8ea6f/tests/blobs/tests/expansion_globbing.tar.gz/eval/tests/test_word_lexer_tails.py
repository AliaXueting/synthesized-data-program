"""Word-lexer tail behaviors reachable only through specific word shapes.

Literals inside parameter-expansion words, $((...)) inside double quotes,
words starting with a multibyte rune, # inside test clauses, comments ended
by escaped newlines, zsh redirect aliases and numeric-range globs read
across the lexer's buffer boundary.
"""


def test_param_word_escapes_and_quotes(run_shfmt):
    """Backslash, quotes and brackets inside ${x-word} stay in the word."""
    # CATCHES: the default-value word keeps its escaped backslash, its
    # inner double quotes and a bare [ -- none of them terminates the
    # parameter expansion or gets requoted by the formatter.
    res = run_shfmt(["-"], "echo ${x-a\\b}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${x-a\\b}\n"

    res = run_shfmt(["-"], 'echo ${x-a"b"}\n')
    assert res.returncode == 0
    assert res.stdout == 'echo ${x-a"b"}\n'

    res = run_shfmt(["-"], "echo ${x-a[b}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${x-a[b}\n"
    assert res.stderr == ""


def test_arithmetic_expansion_inside_double_quotes(run_shfmt):
    """"$((...))" is an arithmetic expansion, and its spacing is normalised."""
    # CATCHES: after a double quote the lexer must still tell $(( apart
    # from $( so the contents go through the arithmetic formatter --
    # 1+2 becomes 1 + 2 while subscripts stay glued.
    res = run_shfmt(["-"], 'echo "$((1+2))"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "$((1 + 2))"\n'
    assert res.stderr == ""

    res = run_shfmt(["-"], 'echo "$((x[i]))" "$(((1+2)))"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "$((x[i]))" "$(((1 + 2)))"\n'


def test_word_starting_with_multibyte_rune(run_shfmt):
    """A word whose first rune is non-ASCII round-trips as one literal."""
    # CATCHES: the literal buffer is seeded with the full multibyte rune,
    # so the é survives as part of the same word as the rest of the name.
    res = run_shfmt(["-"], "écho hi\n")
    assert res.returncode == 0
    assert res.stdout == "écho hi\n"
    assert res.stderr == ""


def test_posix_rejects_process_substitution(run_shfmt):
    """In posix mode >(...) is a redirect whose word may not start with (."""
    # CATCHES: the ( after > is not a process substitution outside the
    # bash-like dialects, so the parser demands a plain word and reports
    # the redirect operator instead.
    res = run_shfmt(["-ln=posix", "-"], "cat >(ls)\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:5: `>` must be followed by a word\n"


def test_hash_is_a_word_character_in_tests(run_shfmt):
    """# inside [[ ]] continues the word instead of starting a comment."""
    # CATCHES: in test expressions a#b stays a single literal word -- the
    # formatter must not split it into a word plus a comment.
    res = run_shfmt(["-"], "[[ a#b == c ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ a#b == c ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "[[ a =~ (x)y ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ a =~ (x)y ]]\n"


def test_comment_ended_by_escaped_newline(run_shfmt):
    """A comment ending in backslash-newline does not swallow the next line."""
    # CATCHES: the escaped newline ends the comment token, so `b` is a
    # command on its own line rather than comment text.
    res = run_shfmt(["-"], "# a \\\nb\n")
    assert res.returncode == 0
    assert res.stdout == "# a \\\nb\n"
    assert res.stderr == ""


def test_quoted_heredoc_body_with_escaped_newline(run_shfmt):
    """A quoted heredoc keeps a backslash-newline pair in the body."""
    # CATCHES: under <<'E' the backslash is literal content, so the body
    # line "a \" and the following line both survive untouched.
    res = run_shfmt(["-"], "cat <<'E'\na \\\nb\nE\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<'E'\na \\\nb\nE\n"
    assert res.stderr == ""


def test_zsh_append_all_redirect_aliases(run_shfmt):
    """zsh's >>& family normalises to the &>> spellings."""
    # CATCHES: >>& is an alias for &>>, and both >>&| and >>&! normalise to
    # the &>>| clobber form -- with the target glued to the operator.
    res = run_shfmt(["-ln=zsh", "-"], "x >>& f\n")
    assert res.returncode == 0
    assert res.stdout == "x &>>f\n"

    res = run_shfmt(["-ln=zsh", "-"], "x >>&| f\n")
    assert res.returncode == 0
    assert res.stdout == "x &>>|f\n"

    res = run_shfmt(["-ln=zsh", "-"], "x >>&! f\n")
    assert res.returncode == 0
    assert res.stdout == "x &>>|f\n"
    assert res.stderr == ""


def test_function_named_at(run_shfmt):
    """The bash function keyword accepts @ as the function name."""
    # CATCHES: `function @()` is not treated as an extended glob -- the
    # name check allows @ so the declaration round-trips intact.
    res = run_shfmt(["-ln=bash", "-"], "function @() { :; }\n")
    assert res.returncode == 0
    assert res.stdout == "function @() { :; }\n"
    assert res.stderr == ""


def test_zsh_numeric_range_across_read_buffer(run_shfmt):
    """A <5-10> glob whose < lands on the last buffered byte still parses."""
    # CATCHES: the numeric-range peek must refill its buffer when the <
    # is the final byte of a 4096-byte read -- the word keeps its glob
    # instead of the < turning into a redirect.
    src = "a" * 4095 + "<5-10>\n"
    res = run_shfmt(["-ln=zsh", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""

    res = run_shfmt(["-ln=zsh", "-"], "echo <5-10>\n")
    assert res.returncode == 0
    assert res.stdout == "echo <5-10>\n"


def test_for_word_list_rejects_parens(run_shfmt):
    """A parenthesis inside a for word list is not a word."""
    # CATCHES: the for list may only contain words, so (b) produces the
    # dedicated "word list can only contain words" error at the paren.
    res = run_shfmt(["-"], "for x in (b)\ndo :; done\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:10: word list can only contain words\n"


def test_bash_for_braces_normalise_to_do_done(run_shfmt):
    """bash's `for x in ...; { ...; }` prints with do/done instead."""
    # CATCHES: the braces form of for is parsed as Braces=true but the
    # canonical printed form is the portable do ... done spelling.
    res = run_shfmt(["-ln=bash", "-"], "for x in a b; { echo $x; }\n")
    assert res.returncode == 0
    assert res.stdout == "for x in a b; do echo $x; done\n"
    assert res.stderr == ""


def test_for_without_in_normalises(run_shfmt):
    """`for x` with a newline or semicolon before do prints as `for x; do`."""
    # CATCHES: whether the loop head ends with a newline or a semicolon,
    # the canonical output inserts the explicit `;` before do.
    res = run_shfmt(["-"], "for x\ndo echo $x; done\n")
    assert res.returncode == 0
    assert res.stdout == "for x; do echo $x; done\n"

    res = run_shfmt(["-"], "for x; do echo $x; done\n")
    assert res.returncode == 0
    assert res.stdout == "for x; do echo $x; done\n"
    assert res.stderr == ""


def test_case_head_requires_word_then_in(run_shfmt):
    """case with a missing word or in gives each its own diagnostic."""
    # CATCHES: `case ;` complains the word is missing while `case in`
    # consumes `in` as the word and then complains the `in` is missing.
    res = run_shfmt(["-"], "case ; a) b;; esac\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:1: `case` must be followed by a word\n"

    res = run_shfmt(["-"], "case in a) b;; esac\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:1: `case x` must be followed by `in`\n"
