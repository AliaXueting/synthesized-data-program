"""Heredoc body treatment: quoting, escapes, tabs and truncation.

How the <<, <<- and quoted-delimiter forms reformat the body: backslash
handling under quoted vs unquoted delimiters, tab stripping and mid-line
tabs with <<-, interaction with -i space indentation, and bodies cut short
at EOF.
"""


def test_quoted_heredoc_backslashes_literal(run_shfmt):
    """A quoted delimiter keeps every backslash in the body verbatim."""
    # CATCHES: with <<\"EOF\" or <<'EOF' backslashes are literal content, so
    # a trailing double backslash must survive instead of being re-escaped.
    res = run_shfmt(["-"], 'cat <<"EOF"\nfoo\\bar\\\\\nEOF\n')
    assert res.returncode == 0
    assert res.stdout == 'cat <<"EOF"\nfoo\\bar\\\\\nEOF\n'
    assert res.stderr == ""

    res = run_shfmt(["-"], "cat <<'EOF'\nfoo\\bar\nEOF\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<'EOF'\nfoo\\bar\nEOF\n"
    assert res.stderr == ""


def test_unquoted_heredoc_escapes_preserved(run_shfmt):
    """An unquoted body keeps $expansions and backslash escapes as written."""
    # CATCHES: $user stays a parameter expansion, \\$ stays an escaped dollar
    # and \\t stays the two literal characters -- none of them is evaluated
    # or dropped while reformatting the body.
    res = run_shfmt(["-"], "cat <<EOF\n$user \\$x \\t\nEOF\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<EOF\n$user \\$x \\t\nEOF\n"
    assert res.stderr == ""


def test_dash_heredoc_strips_one_tab(run_shfmt):
    """<<- strips only the leading tab; mid-line tabs and indent survive."""
    # CATCHES: the closing word loses its leading tab and lands in column 0,
    # a second leading tab stays as content indentation, and a tab in the
    # middle of a line is untouched tabwriter input, not column padding.
    res = run_shfmt(["-"], "cat <<-EOF\n\tline1\n\t\tmid\ttab\n\tnormal\n\tEOF\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<-EOF\n\tline1\n\t\tmid\ttab\n\tnormal\nEOF\n"
    assert res.stderr == ""


def test_dash_heredoc_inside_function(run_shfmt):
    """A <<- heredoc in a function reindents body and closing word."""
    # CATCHES: after stripping one tab the body keeps the extra indent level
    # of the surrounding function and the closing word is re-indented to the
    # function's column.
    res = run_shfmt(["-"], "f() { cat <<-EOF\n\t\tindented\n\t\tEOF\n\t}\n")
    assert res.returncode == 0
    assert res.stdout == "f() {\n\tcat <<-EOF\n\t\tindented\n\tEOF\n}\n"
    assert res.stderr == ""


def test_dash_heredoc_keeps_tabs_with_space_indent(run_shfmt):
    """-i=2 does not convert heredoc-body tabs into spaces."""
    # CATCHES: heredoc bodies are written through a writer that escapes tabs
    # so the tabwidth-based indenter cannot rewrite them, even though the
    # rest of the program now uses two-space indentation; the <<-'s closing
    # word even keeps one literal tab while the body is not re-indented.
    res = run_shfmt(["-i=2", "-"], "cat <<-EOF\n\tline1\n\t\tmid\ttab\n\tEOF\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<-EOF\n\tline1\n\t\tmid\ttab\n\tEOF\n"
    assert res.stderr == ""

    res = run_shfmt(["-i=2", "-"], "cat <<EOF\n\tbody\thas\ttabs\nEOF\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<EOF\n\tbody\thas\ttabs\nEOF\n"
    assert res.stderr == ""


def test_tab_prefixed_word_is_not_the_closing_word(run_shfmt):
    """With << (no dash) a tab-indented EOF is body text, not the delimiter."""
    # CATCHES: only <<- allows the closing word to be preceded by a tab, so
    # the \\tEOF line stays part of the body and the real unindented EOF
    # terminates the heredoc.
    res = run_shfmt(["-"], 'cat <<"EOF"\n\ttabs\there\n\tEOF\nEOF\n')
    assert res.returncode == 0
    assert res.stdout == 'cat <<"EOF"\n\ttabs\there\n\tEOF\nEOF\n'
    assert res.stderr == ""


def test_unterminated_heredoc_completes_at_eof(run_shfmt):
    """A heredoc cut short by EOF gains the closing word and a newline."""
    # CATCHES: the parser ends the body at EOF, and the printer appends the
    # missing final newline plus the delimiter line; with <<- the one-tab
    # strip still applies to the last body line.
    res = run_shfmt(["-"], "cat <<-EOF\n\t\tno closing word\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<-EOF\n\tno closing word\nEOF\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "cat <<EOF\nunterminated")
    assert res.returncode == 0
    assert res.stdout == "cat <<EOF\nunterminated\nEOF\n"
    assert res.stderr == ""
