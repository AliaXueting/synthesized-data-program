"""How the printer lays words out: continuations, indents, padding, minify.

Escaped newlines inside words, the --binary-next-line, --indent, --keep-padding
and --space-redirects printer options, and what --minify does to compound
statements that carry words.
"""


def test_line_continuation_before_word(run_shfmt):
    """An escaped newline before a word is re-emitted after the operator."""
    # CATCHES: the continuation stays after <<< and the following word keeps
    # its tab indent on the next line -- the exact two-line shape is kept.
    res = run_shfmt(["-"], 'cat <<< \\\n\t"bar baz"\n')
    assert res.returncode == 0
    assert res.stdout == 'cat <<< \\\n\t"bar baz"\n'
    assert res.stderr == ""


def test_line_continuation_chain(run_shfmt):
    """A chain of continued words keeps each backslash and indentation."""
    # CATCHES: every escaped newline in the argument list is preserved with a
    # tab indent on the continuation line.
    res = run_shfmt(["-"], "echo one \\\n\ttwo \\\n\tthree\n")
    assert res.returncode == 0
    assert res.stdout == "echo one \\\n\ttwo \\\n\tthree\n"
    assert res.stderr == ""


def test_binary_next_line_moves_operators(run_shfmt):
    """--binary-next-line rewrites && / || chains with continuations."""
    # CATCHES: with -bn the operator moves to the next line and the lines are
    # joined with backslash-newline and a tab, instead of staying split.
    res = run_shfmt(["-bn"], "a &&\nb ||\nc\n")
    assert res.returncode == 0
    assert res.stdout == "a \\\n\t&& b \\\n\t|| c\n"
    assert res.stderr == ""


def test_binary_chain_layout_untouched_by_default(run_shfmt):
    """Without -bn, a split && chain keeps its breaks but gains indents."""
    # CATCHES: the author's line break after && is preserved and each
    # continuation line is re-indented with a tab, rather than joining the
    # chain onto one line.
    res = run_shfmt(["-"], "a &&\nb\n")
    assert res.returncode == 0
    assert res.stdout == "a &&\n\tb\n"
    assert res.stderr == ""


def test_space_indent_flag(run_shfmt):
    """--indent=4 uses four spaces instead of a tab for bodies."""
    # CATCHES: the indentation of the if body is exactly four spaces, not a
    # tab and not two spaces.
    res = run_shfmt(["-i=4"], "if true; then\necho hi\nfi\n")
    assert res.returncode == 0
    assert res.stdout == "if true; then\n    echo hi\nfi\n"
    assert res.stderr == ""


def test_keep_padding_flag(run_shfmt):
    """--keep-padding preserves the original column alignment of words."""
    # CATCHES: the two-space and four-space gaps between the flag words are
    # part of the source's alignment and survive only under -kp.
    src = "echo --flag1  --value2\necho --flag3    --value4\n"
    res = run_shfmt(["-kp"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""

    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == "echo --flag1 --value2\necho --flag3 --value4\n"


def test_space_redirects_flag(run_shfmt):
    """--space-redirects separates every redirect operator from its word."""
    # CATCHES: -sr adds a space after >, >> and even the << of a heredoc,
    # while the fd prefix ({fd}>, 2>>) stays glued to the operator.
    res = run_shfmt(["-sr"], "echo hi >out 2>>err {fd}>f\ncat <<EOF\nbody\nEOF\n")
    assert res.returncode == 0
    assert res.stdout == "echo hi > out 2>> err {fd}> f\ncat << EOF\nbody\nEOF\n"
    assert res.stderr == ""


def test_minify_compound_statements(run_shfmt):
    """--minify strips statement padding and the last case terminator."""
    # CATCHES: minify removes the space after `then` and after case `)`,
    # drops the final `;;` of the last case item, and glues esac to it --
    # while the double space inside the quoted word "a  b" must survive.
    src = (
        "if  true ;  then\n"
        "  echo  \"a  b\"\n"
        "fi\n"
        "case $x in\n"
        "  a ) echo 1 ;;\n"
        "  * ) echo 2 ;;\n"
        "esac\n"
    )
    expected = (
        "if true;then\n"
        "echo \"a  b\"\n"
        "fi\n"
        "case $x in\n"
        "a)echo 1;;\n"
        "*)echo 2\n"
        "esac\n"
    )
    res = run_shfmt(["-mn"], src)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == ""


def test_minify_continuation_drops_indent(run_shfmt):
    """--minify keeps an escaped newline but drops the tab after it."""
    # CATCHES: the backslash-newline itself is required (the word cannot join
    # the line without it), yet the indentation of the continuation is
    # minified away.
    res = run_shfmt(["-mn"], "echo one \\\n\ttwo\n")
    assert res.returncode == 0
    assert res.stdout == "echo one \\\ntwo\n"
    assert res.stderr == ""
