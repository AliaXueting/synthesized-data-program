"""Lexer scan paths: zsh number-range words and the read boundary.

A zsh `<5>` without the dash opens a number range whose closer then
demands a word, and a word whose last rune straddles the lexer's
buffered-read boundary must survive byte for byte.
"""


def test_zsh_number_range_without_dash(run_shfmt):
    """zsh <5> without the opening dash reports the closing bracket word."""
    # CATCHES: the two-character `<5` opens a number range, so the bare
    # `>` at column 8 cannot close it and is rejected with the
    # "must be followed by a word" wording.
    res = run_shfmt(["--ln=zsh", "-"], "echo <5>")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:8: `>` must be followed by a word\n"


def test_multibyte_word_across_read_boundary(run_shfmt):
    """A two-byte rune straddling the 4096-byte read edge survives."""
    # CATCHES: 4095 ASCII bytes put the two-byte é across the lexer's
    # buffered-read boundary, so a rune split between reads must be
    # reassembled and the word round-trips byte for byte.
    src = "a" * 4095 + "é"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src + "\n"
    assert res.stderr == ""
