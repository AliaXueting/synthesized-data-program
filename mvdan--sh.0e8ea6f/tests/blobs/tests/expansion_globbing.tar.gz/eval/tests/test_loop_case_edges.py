"""for-loop word lists and case-clause edges.

The wordIter forms (semicolon without `in`, numeric loop names) and their
diagnostics, plus the mksh `case x {` braces form and the case-clause
structure errors.
"""


def test_for_without_in_list(run_shfmt):
    """`for x; do` iterates the positionals and keeps the semicolon."""
    # CATCHES: a loop name followed directly by `;` is a valid wordIter
    # with no items and must not gain an `in` or lose the semicolon.
    src = "for x; do :; done\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_for_numeric_loop_name(run_shfmt):
    """A numeric loop name like `for 1 in x` is accepted as a literal."""
    # CATCHES: the loop name only has to be a literal word, so `1` is kept
    # instead of being rejected as a non-name.
    src = "for 1 in x; do :; done\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_for_word_list_errors(run_shfmt):
    """Missing names, bad word lists and missing `do` have fixed wording."""
    # CATCHES: each broken shape names the loop prefix it expected, from
    # the bare `for` to the `for foo [in words]` and `for foo` variants.
    cases = [
        ("for; do :; done\n",
         "<standard input>:1:1: `for` must be followed by a literal\n"),
        ("for x in ) do :; done\n",
         "<standard input>:1:1: `for foo [in words]` must be followed by `do`\n"),
        ("for x y do :; done\n",
         "<standard input>:1:1: `for foo` must be followed by `in`, `do`, "
         "`;`, or a newline\n"),
    ]
    for src, err in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == err, src


def test_mksh_case_braces_form_normalises(run_shfmt):
    """mksh's `case x {` braces form reprints with in and esac."""
    # CATCHES: the braces delimiters are a valid parse that the printer
    # canonicalises away, replacing them with the portable in/esac pair.
    res = run_shfmt(["-ln=mksh", "-"], "case $x { a) echo 1 ;; }\n")
    assert res.returncode == 0
    assert res.stdout == "case $x in a) echo 1 ;; esac\n"
    assert res.stderr == ""


def test_case_structure_errors(run_shfmt):
    """A case without a word or without esac reports at column 1."""
    # CATCHES: both structural errors anchor at the `case` keyword itself
    # and spell the expected shape with a placeholder word.
    cases = [
        ("case { a) ;; }\n",
         "<standard input>:1:1: `case x` must be followed by `in`\n"),
        ("case $x in\n",
         "<standard input>:1:1: `case` statement must end with `esac`\n"),
    ]
    for src, err in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == err, src
