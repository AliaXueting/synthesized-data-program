"""Parameter-expansion syntax as seen through the formatter's CLI.

These tests pin how ``${...}`` forms are parsed, re-printed and normalised:
operator spelling, array/length/indirection forms, and the exact byte-level
output the reference produces for each of them.
"""

import json

import pytest

# Recorded reference output for the ${var<op>word} operator families.  The
# braced form is echoed back verbatim, so any re-implementation that re-spells
# an operator (or drops the braces) is caught immediately.
SET_OPERATORS = [":-", ":=", ":+", ":?", "-", "=", "+", "?"]
TRIM_OPERATORS = ["#", "##", "%", "%%"]
CASE_OPERATORS = ["^", "^^", ",", ",,", "^x", "^^y"]


def test_braced_set_operators_roundtrip(run_shfmt):
    """Each ${var<op>word} unset/default operator survives formatting verbatim."""
    # CATCHES: the colon and colon-less :- = + ? families must keep their exact
    # spelling; a printer that normalises ${var-def} to ${var:-def} fails here.
    for op in SET_OPERATORS:
        res = run_shfmt([], "echo ${var%sdef}\n" % op)
        assert res.returncode == 0, op
        assert res.stdout == "echo ${var%sdef}\n" % op, op
        assert res.stderr == "", op


def test_pattern_removal_operators_roundtrip(run_shfmt):
    """The # ## % %% prefix/suffix removal operators are preserved unchanged."""
    # CATCHES: single vs double #/% choose shortest vs longest match; swapping
    # them while printing would silently change the expansion's meaning.
    for op in TRIM_OPERATORS:
        res = run_shfmt([], "echo ${var%spre}\n" % op)
        assert res.returncode == 0, op
        assert res.stdout == "echo ${var%spre}\n" % op, op
        assert res.stderr == "", op


def test_case_conversion_operators_roundtrip(run_shfmt):
    """Bash case-conversion operators ^ ^^ , ,, print back byte-for-byte."""
    # CATCHES: ^ and , are single-char operators that a naive lexer could glue
    # onto the parameter name or onto the following word.
    for op in CASE_OPERATORS:
        res = run_shfmt([], "echo ${var%s}\n" % op)
        assert res.returncode == 0, op
        assert res.stdout == "echo ${var%s}\n" % op, op
        assert res.stderr == "", op


def test_length_and_special_parameter_forms(run_shfmt):
    """Length, indirect, name-expansion and special-parameter forms are kept."""
    # CATCHES: ${#var} ${!var} ${!pre*} ${!pre@} ${#} ${!} ${10} ${@} ${*} ${#@}
    # all look like operator soup; each must survive with its own punctuation.
    snippets = [
        "echo ${#var}",
        "echo ${!var}",
        "echo ${!pre*}",
        "echo ${!pre@}",
        "echo ${#}",
        "echo ${!}",
        "echo ${10}",
        "echo ${@}",
        "echo ${*}",
        "echo ${#@}",
    ]
    for snippet in snippets:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet
        assert res.stderr == "", snippet


def test_naked_dollar_parameters_roundtrip(run_shfmt):
    """Short-form special parameters $@ $* $# $? $$ $! $0 $- $_ stay as typed."""
    # CATCHES: the short special parameters must not be rewritten into braced
    # form, and $- / $_ must not be mistaken for an incomplete expansion.
    line = "echo $1 $2 $@ $* $# $? $$ $! $0 $- $_"
    res = run_shfmt([], line + "\n")
    assert res.returncode == 0
    assert res.stdout == line + "\n"
    assert res.stderr == ""


@pytest.mark.parametrize(
    "snippet,expected",
    [
        ("${var/pat/repl}", "${var/pat/repl}"),
        ("${var//pat/repl}", "${var//pat/repl}"),
        # The replacement slash is re-emitted even when the word is absent.
        ("${var/pat}", "${var/pat/}"),
        ("${var/}", "${var//}"),
        ("${var//}", "${var///}"),
    ],
)
def test_search_and_replace_slashes(run_shfmt, snippet, expected):
    """Search-and-replace gets its separator slashes fully re-materialised."""
    # CATCHES: an omitted pattern or replacement word still prints both slashes
    # (and the leading // for the global form), so ${var/} must become ${var//}.
    res = run_shfmt([], "echo %s\n" % snippet)
    assert res.returncode == 0
    assert res.stdout == "echo %s\n" % expected
    assert res.stderr == ""


def test_array_parameter_forms_roundtrip(run_shfmt):
    """Indexed, @/*, slice, keys and negative-index forms all survive."""
    # CATCHES: ${arr[@]} vs ${arr[*]} and the ${arr[@]:1:2} slice colon syntax
    # must keep their exact characters, including the negative index.
    snippets = [
        "echo ${arr[0]}",
        "echo ${arr[@]}",
        "echo ${arr[*]}",
        "echo ${arr[@]:1:2}",
        "echo ${!arr[@]}",
        "echo ${arr[-1]}",
        "echo ${x@Q}",
    ]
    for snippet in snippets:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet
        assert res.stderr == "", snippet


def test_array_literal_whitespace_collapsed(run_shfmt):
    """Padding inside an array literal is removed but element spacing stays."""
    # CATCHES: a=( [x]=y ) must re-print as a=([x]=y) -- the indexed-element
    # brackets are preserved while the surrounding padding is dropped.
    res = run_shfmt([], "a=( [x]=y )\n")
    assert res.returncode == 0
    assert res.stdout == "a=([x]=y)\n"
    assert res.stderr == ""


def test_indexed_array_literal_roundtrip(run_shfmt):
    """Explicitly indexed and appended array literals keep their shape."""
    # CATCHES: the [0]=a element syntax and the += append operator must both
    # survive formatting without being rewritten to plain word lists.
    for snippet in ["arr=([0]=a [1]=b)", "arr+=(x)", "declare -A x=([a]=1)"]:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet


def test_default_word_keeps_its_own_quoting(run_shfmt):
    """Quoting and nesting inside an expansion's word is left untouched."""
    # CATCHES: the word after :- may itself contain quotes or a nested
    # expansion; the formatter must not flatten or re-quote it.
    for snippet in [
        'echo ${var:-"a b"}',
        "echo ${x:-$y}",
        "echo ${x:-${y}}",
        "echo ${x:=$(y)}",
        "echo ${x:-}",
    ]:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet


def test_adjacent_expansions_not_merged(run_shfmt):
    """Neighbouring expansions and literals stay separate word parts."""
    # CATCHES: ${x}${y} and ${x}--${y} must not be joined into one literal or
    # have their braces removed, even where that would be textual no-op.
    for snippet in ["echo ${x}${y}", "echo ${x}--${y}", "echo ${x}a${y}", "a=${x}b"]:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet


def test_minify_shortens_braced_parameter(run_shfmt):
    """--minify rewrites a plain ${var} into the short $var form."""
    # CATCHES: only the truly plain braced form may be shortened; ${#var},
    # ${arr[@]} and ${var:-x} must keep their braces because $-only cannot
    # express them.
    res = run_shfmt(["-mn"], "echo ${var}\n")
    assert res.returncode == 0
    assert res.stdout == "echo $var\n"
    assert res.stderr == ""


def test_minify_shortens_braced_parameter_inside_quotes(run_shfmt):
    """--minify also shortens "${var}" inside double quotes."""
    # CATCHES: the quoted context is not a reason to keep the braces; the
    # quotes themselves are preserved while ${var} becomes $var.
    res = run_shfmt(["-mn"], 'echo "${var}"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "$var"\n'
    assert res.stderr == ""


def test_minify_keeps_braces_where_required(run_shfmt):
    """--minify leaves operators that need braces completely alone."""
    # CATCHES: shortening ${#var} to $#var would be a semantic change, so the
    # minifier must recognise which forms are expressible without braces.
    for snippet in ["echo ${#var}", "echo ${arr[@]}", "echo ${var:-x}", "echo ${var^}"]:
        res = run_shfmt(["-mn"], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet
        assert res.stderr == "", snippet


def test_tojson_param_exp_operator_and_word(run_shfmt):
    """--to-json exposes the :- operator and its word as structured fields."""
    # CATCHES: the typed tree must report Op ":-", Param "var" and a Lit "def"
    # word, proving the operator was parsed rather than kept as raw text.
    res = run_shfmt(["--to-json"], "echo ${var:-def}\n")
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    exp = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert exp["Type"] == "ParamExp"
    assert exp["Param"]["Value"] == "var"
    assert exp["Exp"]["Op"] == ":-"
    assert exp["Exp"]["Word"]["Parts"][0]["Value"] == "def"


def test_tojson_short_param_flag(run_shfmt):
    """--to-json marks the unbraced $x form with Short: true."""
    # CATCHES: the tree distinguishes $x from ${x} via the Short flag, which is
    # exactly what lets --minify rewrite one but never the other.
    res = run_shfmt(["--to-json"], "echo $x\n")
    assert res.returncode == 0
    tree = json.loads(res.stdout)
    exp = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert exp["Type"] == "ParamExp"
    assert exp["Short"] is True
    assert exp["Param"]["Value"] == "x"
    assert "Rbrace" not in exp


def test_tojson_array_slice_fields(run_shfmt):
    """--to-json records the @ index and the slice offset/length separately."""
    # CATCHES: ${arr[@]:1:2} must decompose into Index "@" plus Slice offsets,
    # not into a single blob, so the two colons keep distinct meanings.
    res = run_shfmt(["--to-json"], "echo ${arr[@]:1:2}\n")
    assert res.returncode == 0
    tree = json.loads(res.stdout)
    exp = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert exp["Type"] == "ParamExp"
    assert exp["Param"]["Value"] == "arr"
    assert exp["Index"]["Parts"][0]["Value"] == "@"
    assert exp["Slice"]["Offset"]["Parts"][0]["Value"] == "1"
    assert exp["Slice"]["Length"]["Parts"][0]["Value"] == "2"
