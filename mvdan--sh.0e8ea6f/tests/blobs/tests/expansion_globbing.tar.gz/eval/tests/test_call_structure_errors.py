"""Statement-structure errors around words, pipes and compound commands.

What the parser says when a parenthesis appears in argument position, when a
bash compound-command word leads a posix statement, when negation or a pipe
is left dangling, and which of those still parse fine.
"""

import pytest


def test_parenthesis_in_argument_position(run_shfmt):
    """A ( or ) token inside a call is reported with the generic wording."""
    # CATCHES: the message names the token itself and the rule "a command can
    # only contain words and redirects", for both an opening and a closing
    # parenthesis.
    res = run_shfmt(["-ln=bash", "-"], "echo )\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:6: a command can only contain words and "
        "redirects; encountered `)`\n"
    )

    res = run_shfmt(["-ln=bash", "-"], "echo { (ls) }\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:8: a command can only contain words and "
        "redirects; encountered `(`\n"
    )


@pytest.mark.parametrize(
    "src,column,builtin",
    [
        ("declare -f (x)\n", 12, "declare"),
        ("local x (y)\n", 9, "local"),
        ("export a (b)\n", 10, "export"),
        ("[[ -n (x)\n", 7, "[["),
        ("let 1 (x)\n", 7, "let"),
        ("nameref x (y)\n", 11, "nameref"),
    ],
)
def test_compound_command_word_in_posix(run_shfmt, src, column, builtin):
    """A bash builtin leading a posix statement gets the dialect message."""
    # CATCHES: when the paren cannot continue the call, the parser blames the
    # first word if it is a bash compound-command name, with the column of the
    # parenthesis and the builtin's own name in the message.
    res = run_shfmt(["-ln=posix", "-"], src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        f"<standard input>:1:{column}: the `{builtin}` builtin is a bash "
        f"feature; tried parsing as posix\n"
    )


def test_negation_edges(run_shfmt):
    """A lone ! and a doubled ! each have their own dedicated message."""
    # CATCHES: the negation operator cannot stand as a whole statement and
    # cannot be repeated; both errors point at the statement start, column 1.
    res = run_shfmt(["-ln=bash", "-"], "!\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:1: `!` cannot form a statement alone\n"

    res = run_shfmt(["-ln=bash", "-"], "! !\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:1: cannot negate a command multiple times\n"


def test_pipe_coprocess_operator_gating(run_shfmt):
    """|& is a bash coprocess pipe; posix sees a dangling | instead."""
    # CATCHES: bash keeps `a |& b` verbatim while posix never merges | with &,
    # so its error blames the bare pipe at column 3.
    res = run_shfmt(["-ln=bash", "-"], "a |& b\n")
    assert res.returncode == 0
    assert res.stdout == "a |& b\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=posix", "-"], "a |& b\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:3: `|` must be followed by a statement\n"


def test_dangling_pipe_operators(run_shfmt):
    """A pipe with nothing after it names the whole operator spelling."""
    # CATCHES: the message says `|&` in bash (the merged operator) rather
    # than the generic `|` wording posix produces for the same trailing text.
    res = run_shfmt(["-ln=bash", "-"], "a |&\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:3: `|&` must be followed by a statement\n"

    res = run_shfmt(["-ln=posix", "-"], "a |&\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:3: `|` must be followed by a statement\n"


def test_pipe_into_redirect_only(run_shfmt):
    """The right side of a pipe may be nothing but a redirect."""
    # CATCHES: `a | >f` is accepted and reprinted with the redirect glued to
    # its target, proving the pipe consumed an empty command word list.
    res = run_shfmt(["-ln=bash", "-"], "a | >f\n")
    assert res.returncode == 0
    assert res.stdout == "a | >f\n"
    assert res.stderr == ""


def test_missing_statement_list_after_keyword(run_shfmt):
    """until with no condition reports the keyword and what it needs."""
    # CATCHES: the diagnostic spells the reserved word `until` with backticks
    # and demands a statement list, at the keyword's own position.
    res = run_shfmt(["-ln=bash", "-"], "until\ndo :; done\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:1: `until` must be followed by a statement list\n"


@pytest.mark.parametrize(
    "src,expected",
    [
        ("((x\n", "<standard input>:1:1: reached EOF without matching `((` with `))`\n"),
        ("echo $[1+2\n", "<standard input>:1:6: reached EOF without matching `$[` with `]`\n"),
        ("echo @(\n", "<standard input>:1:6: reached EOF without matching `@(` with `)`\n"),
        ("echo 'a\\\n", "<standard input>:1:6: reached EOF without closing quote `'`\n"),
        ("echo $((3, ))\n", "<standard input>:1:10: `,` must be followed by an expression\n"),
        ("[[ (a) == b ]]\n", "<standard input>:1:8: expected `&&`, `||` or `]]` after complex expr\n"),
    ],
)
def test_unterminated_word_constructs(run_shfmt, src, expected):
    """Each unterminated word construct has its own matching message."""
    # CATCHES: arithmetic commands, legacy $[, extended globs, single quotes,
    # a dangling comma and a comparison after a parenthesised test operand
    # each produce a distinct diagnostic naming the open construct.
    res = run_shfmt(["-ln=bash", "-"], src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == expected
