"""Raw byte handling in the lexer: NUL, CR, CRLF and invalid UTF-8.

The lexer normalises the byte stream before any word is built: NUL bytes are
dropped like bash does, CRLF pairs collapse to LF, a lone CR acts as a word
separator, and bytes that do not decode as UTF-8 abort the parse with the
position of the offending byte.
"""


def test_null_bytes_are_skipped_like_bash(run_shfmt):
    """A NUL byte inside a word disappears instead of splitting it."""
    # CATCHES: the lexer jumps over \\x00 while advancing a literal, so
    # "a\\0b" is one word "ab"; a NUL alone between spaces stays nothing.
    res = run_shfmt(["-ln=bash", "-"], "echo a\x00b\n")
    assert res.returncode == 0
    assert res.stdout == "echo ab\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=bash", "-"], "echo \x00 hi\n")
    assert res.returncode == 0
    assert res.stdout == "echo hi\n"
    assert res.stderr == ""


def test_crlf_line_endings_normalise_to_lf(run_shfmt):
    """Every CR of a CRLF pair is dropped, so lines end with a bare LF."""
    # CATCHES: the CR is consumed by the lexer and never reaches the printer,
    # so a script saved with Windows endings reformats to Unix endings.
    res = run_shfmt(["-ln=bash", "-"], "echo a\r\ntrue\r\n")
    assert res.returncode == 0
    assert res.stdout == "echo a\ntrue\n"
    assert res.stderr == ""


def test_lone_carriage_return_separates_words(run_shfmt):
    """A CR not followed by LF is not a newline; it breaks the literal."""
    # CATCHES: "a\\rb" is not the single word "a\\rb" nor "ab" -- the CR ends
    # the first literal, so the result is two space-joined words.
    res = run_shfmt(["-ln=bash", "-"], "echo a\rb\n")
    assert res.returncode == 0
    assert res.stdout == "echo a b\n"
    assert res.stderr == ""


def test_escaped_crlf_is_a_line_continuation(run_shfmt):
    """Backslash + CRLF joins the two lines exactly like backslash + LF."""
    # CATCHES: the three-byte continuation \\\\ + CR + LF is collapsed to one
    # escaped newline, so the word survives as "ab" on a single line.
    res = run_shfmt(["-ln=bash", "-"], "echo a\\\r\nb\n")
    assert res.returncode == 0
    assert res.stdout == "echo ab\n"
    assert res.stderr == ""


def test_escaped_newline_before_input_is_dropped(run_shfmt):
    """A continuation at the very start of the file leaves no trace."""
    # CATCHES: the leading backslash-newline is consumed as whitespace before
    # the first statement, so the output starts with "echo" on column 1.
    res = run_shfmt(["-ln=bash", "-"], "\\\necho hi\n")
    assert res.returncode == 0
    assert res.stdout == "echo hi\n"
    assert res.stderr == ""


def test_trailing_backslash_at_eof_is_re_escaped(run_shfmt):
    """A word ending in a lone backslash prints as an escaped backslash."""
    # CATCHES: the input's final backslash has nothing to escape, so the
    # printer re-quotes it as \\\\ to keep the word's meaning unchanged.
    res = run_shfmt(["-ln=bash", "-"], "echo hi\\")
    assert res.returncode == 0
    assert res.stdout == "echo hi\\\\\n"
    assert res.stderr == ""


def test_invalid_utf8_reports_exact_position(run_shfmt):
    """Bytes that are not valid UTF-8 fail with line and column of the byte."""
    # CATCHES: the error names the offset of the very first bad byte -- here
    # column 6 of line 1 and column 3 of line 2 -- not the end of the input.
    res = run_shfmt(["-ln=bash", "-"], b"echo \xff\xfe\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:6: invalid UTF-8 encoding\n"

    res = run_shfmt(["-ln=bash", "-"], b"true\nx=\xff\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:2:3: invalid UTF-8 encoding\n"


def test_valid_multibyte_words_round_trip(run_shfmt):
    """UTF-8 words survive reformatting byte for byte, unlike bad runes."""
    # CATCHES: multi-byte characters are one rune each, so the column count
    # used for alignment advances by one per character, not per byte.
    res = run_shfmt(["-ln=bash", "-"], "echo héllo wörld\n")
    assert res.returncode == 0
    assert res.stdout == "echo héllo wörld\n"
    assert res.stderr == ""
