"""Input/output plumbing for word-heavy scripts: files, stdin, diff, JSON.

How a snippet full of expansions is read (stdin vs a path argument), where the
result goes (stdout, in-place rewrite, diff), what the exit status means, and
how ``--from-json`` round-trips a tree back into formatted source.
"""

import json


def test_stdin_dash_reads_standard_input(run_shfmt):
    """An explicit '-' argument still formats standard input."""
    # CATCHES: '-' is the documented way to force stdin, and the formatted
    # word must land on stdout with a trailing newline and exit status 0.
    res = run_shfmt(["-"], "echo ${var:-def}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${var:-def}\n"
    assert res.stderr == ""


def test_path_argument_formats_file(run_shfmt, write_script):
    """A file argument is read, formatted and printed to stdout untouched."""
    # CATCHES: the file is not rewritten; the formatted bytes go to stdout and
    # an already-canonical script produces byte-identical output.
    path = write_script("script.sh", "echo ${var:-def}\n")
    res = run_shfmt([str(path)])
    assert res.returncode == 0
    assert res.stdout == "echo ${var:-def}\n"
    assert res.stderr == ""
    assert path.read_text() == "echo ${var:-def}\n"


def test_list_flag_reports_file_that_differs(run_shfmt, write_script):
    """-l prints the path of a file whose formatting differs and exits 1."""
    # CATCHES: the path goes to stdout while stderr stays empty, and the exit
    # status is 1 even though nothing failed -- it is a "differs" report.
    path = write_script("script.sh", "echo $((1+2))\n")
    res = run_shfmt(["-l", str(path)])
    assert res.returncode == 1
    assert res.stdout == "%s\n" % path
    assert res.stderr == ""
    assert path.read_text() == "echo $((1+2))\n"


def test_list_flag_silent_when_already_formatted(run_shfmt, write_script):
    """-l stays silent for a canonical file but reports an unspaced one."""
    # CATCHES: the canonical spelling of that arithmetic expression is the
    # spaced one, so only the unspaced variant makes -l print the path.
    differing = write_script("differing.sh", "echo $((1+2))\n")
    canonical = write_script("canonical.sh", "echo $((1 + 2))\n")

    reported = run_shfmt(["-l", str(differing)])
    assert reported.returncode == 1
    assert reported.stdout == "%s\n" % differing
    assert reported.stderr == ""

    silent = run_shfmt(["-l", str(canonical)])
    assert silent.returncode == 0
    assert silent.stdout == ""
    assert silent.stderr == ""


def test_write_flag_rewrites_file_in_place(run_shfmt, write_script):
    """-w rewrites the file with the normalised arithmetic spacing."""
    # CATCHES: the in-place rewrite must apply the same operator spacing rule
    # seen on stdout, and stdout itself stays empty under -w.
    path = write_script("script.sh", "echo $((1+2))\n")
    res = run_shfmt(["-w", str(path)])
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert path.read_text() == "echo $((1 + 2))\n"


def test_diff_flag_prints_unified_diff(run_shfmt, write_script, tmp_path):
    """-d prints a unified diff naming the sides path.orig and path."""
    # CATCHES: the diff header is synthesised from the argument plus ".orig",
    # and only the changed arithmetic line appears with - and + markers.
    path = write_script("script.sh", "echo ${var}\necho $((1+2))\n")
    res = run_shfmt(["-d", "script.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == ""
    assert res.stdout == (
        "diff script.sh.orig script.sh\n"
        "--- script.sh.orig\n"
        "+++ script.sh\n"
        "@@ -1,2 +1,2 @@\n"
        " echo ${var}\n"
        "-echo $((1+2))\n"
        "+echo $((1 + 2))\n"
    )
    assert path.read_text() == "echo ${var}\necho $((1+2))\n"


def test_filename_flag_names_the_error_position(run_shfmt):
    """--filename replaces <standard input> in the error prefix."""
    # CATCHES: the position line is built from the supplied name, so the
    # same broken expansion reports zz.sh instead of the stdin placeholder.
    res = run_shfmt(["--filename=zz.sh"], "echo ${var\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'zz.sh:1:11: not a valid parameter expansion operator: "\\n"\n'


def test_stdin_error_prefix_is_standard_input(run_shfmt):
    """Without --filename the error prefix is the <standard input> marker."""
    # CATCHES: the default name is the literal text <standard input>, which a
    # re-implementation could easily get wrong (e.g. by using "-" or "").
    res = run_shfmt([], "echo ${var\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == '<standard input>:1:11: not a valid parameter expansion operator: "\\n"\n'


def test_from_json_round_trips_a_tree(run_shfmt):
    """--from-json accepts our own --to-json output and formats it."""
    # CATCHES: the ParamExp inside the arithmetic expansion must survive the
    # JSON detour, so the re-printed source still carries the $ before x.
    tree = run_shfmt(["--to-json"], "echo $(($x + 1))\n")
    assert tree.returncode == 0
    node = json.loads(tree.stdout)["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert node["Type"] == "ArithmExp"
    res = run_shfmt(["--from-json"], tree.stdout)
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "echo $(($x + 1))\n"


def test_to_json_is_tab_indented(run_shfmt):
    """--to-json pretty-prints with tab indentation and ends with a newline."""
    # CATCHES: the JSON encoder is configured with a tab indent, so the very
    # first line of the body is a single tab followed by "Type": "File".
    res = run_shfmt(["--to-json"], "echo $x\n")
    assert res.returncode == 0
    assert res.stderr == ""
    lines = res.stdout.split("\n")
    assert lines[0] == "{"
    assert lines[1] == '\t"Type": "File",'
    assert res.stdout.endswith("}\n")


def test_parse_error_goes_to_stderr_only(run_shfmt):
    """A malformed expansion produces no stdout at all and status 1."""
    # CATCHES: nothing is written to stdout when parsing fails, so a caller
    # can rely on "empty stdout" as the parse-error signal.
    res = run_shfmt([], "echo ${\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:6: reached EOF without matching `${` with `}`\n"


def test_multiple_statements_keep_word_order(run_shfmt):
    """Several expansion-heavy lines are emitted in the original order."""
    # CATCHES: the formatter must not reorder or merge statements, and each
    # line keeps its own expansion spelling exactly as it was written.
    src = (
        "a=${x:-1}\n"
        "b=${x#pre}\n"
        "c=$((a + b))\n"
        "d=`echo hi`\n"
        "echo \"$a\" \"$b\" \"$c\" \"$d\"\n"
    )
    expected = (
        "a=${x:-1}\n"
        "b=${x#pre}\n"
        "c=$((a + b))\n"
        "d=$(echo hi)\n"
        "echo \"$a\" \"$b\" \"$c\" \"$d\"\n"
    )
    res = run_shfmt([], src)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == ""
