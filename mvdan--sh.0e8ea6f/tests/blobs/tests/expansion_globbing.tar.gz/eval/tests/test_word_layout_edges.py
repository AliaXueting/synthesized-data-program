"""Word-layout edges: array literals, case patterns and comments.

How multi-line array literals and their comments are re-indented, how
comments attach to case items, and how a comment after a then/keyword
stays on its line.
"""


def test_multiline_array_literal_layout(run_shfmt):
    """Array elements keep their one-per-line layout and indentation."""
    # CATCHES: the opening paren stays on the assignment line, elements are
    # indented one level, and the closing paren lands in column 0.
    res = run_shfmt(["-"], "a=(\n\t1\n\t2\n)\n")
    assert res.returncode == 0
    assert res.stdout == "a=(\n\t1\n\t2\n)\n"
    assert res.stderr == ""


def test_array_literal_inline_comment(run_shfmt):
    """Comments inside an array literal stay on the line they followed."""
    # CATCHES: the comment after `(` and the trailing comment after an
    # element are preserved at their original positions in the new layout.
    res = run_shfmt(["-"], "a=( # c\n\t1\n\t2 # d\n)\n")
    assert res.returncode == 0
    assert res.stdout == "a=( # c\n\t1\n\t2 # d\n)\n"
    assert res.stderr == ""


def test_array_literal_continuation_indent(run_shfmt):
    """A line break inside a one-line array indents the rest of the list."""
    # CATCHES: when the elements already span lines, the element on the new
    # line is indented and the closing paren glues to it without a space.
    res = run_shfmt(["-"], "a=(1 2\n3)\n")
    assert res.returncode == 0
    assert res.stdout == "a=(1 2\n\t3)\n"
    assert res.stderr == ""


def test_case_comment_before_pattern(run_shfmt):
    """A comment before a case pattern moves to column 0, above the pattern."""
    # CATCHES: comments inside a case block are printed at the case's own
    # indentation level, not the pattern's, and the `a | b` pattern keeps
    # its spacing.
    res = run_shfmt(["-"], "case $x in\n\t# comment\n\ta | b)\n\t\techo hi\n\t\t;;\nesac\n")
    assert res.returncode == 0
    assert res.stdout == (
        "case $x in\n# comment\na | b)\n\techo hi\n\t;;\nesac\n"
    )
    assert res.stderr == ""


def test_case_trailing_comment_on_item(run_shfmt):
    """A comment after `;;` stays on the item line."""
    # CATCHES: the comment belongs to the terminated case item and is not
    # moved to the next line or the esac line.
    res = run_shfmt(["-"], "case $x in\n\ta) ;; # trailing\nesac\n")
    assert res.returncode == 0
    assert res.stdout == "case $x in\na) ;; # trailing\nesac\n"
    assert res.stderr == ""


def test_comment_after_then_keyword(run_shfmt):
    """A comment directly after `then` stays at the end of that line."""
    # CATCHES: the keyword line keeps its trailing comment even though the
    # body moves to the next indented line.
    res = run_shfmt(["-"], "if true; then # c\n\t:\nfi\n")
    assert res.returncode == 0
    assert res.stdout == "if true; then # c\n\t:\nfi\n"
    assert res.stderr == ""
