"""End-position computation for rare node forms via --to-json.

Every tree node carries an End position, and the less common node shapes --
coprocess and disown statements, braced for/case clauses, a bare `time`,
parenthesised test and arithmetic operands, naked declare arguments, an
array element with no value, an empty subshell and a zsh `=(...)` -- each
compute that position through their own code path.  The typed JSON tree
exposes the recorded values directly.
"""

import json

import pytest


def pos(offset, line, col):
    """A position object exactly as the typed JSON emits it."""
    return {"Offset": offset, "Line": line, "Col": col}


def _find_node(obj, type_name):
    """Depth-first search for the first typed-JSON node of a given type."""
    if isinstance(obj, dict):
        if obj.get("Type") == type_name:
            return obj
        for value in obj.values():
            found = _find_node(value, type_name)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = _find_node(value, type_name)
            if found is not None:
                return found
    return None


def encoded(run_shfmt, dialect, src):
    """Run --to-json and return the parsed tree."""
    res = run_shfmt([f"--ln={dialect}", "--to-json", "-"], src)
    assert res.returncode == 0, src
    assert res.stderr == "", src
    return json.loads(res.stdout)


def test_coprocess_statement_end(run_shfmt):
    """A mksh `|&` statement ends past the operator, not past the command."""
    # CATCHES: the coprocess statement's End is its two-byte operator
    # position shifted by two (column 7), while its CallExpr stops at
    # column 4 and only the flag `Coprocess` distinguishes the statement.
    tree = encoded(run_shfmt, "mksh", "cat |& cat")
    stmts = tree["Stmts"]
    assert stmts[0]["Coprocess"] is True
    assert stmts[0]["Semicolon"] == pos(4, 1, 5)
    assert stmts[0]["Cmd"]["End"] == pos(3, 1, 4)
    assert stmts[0]["End"] == pos(6, 1, 7)
    assert "Coprocess" not in stmts[1]
    assert stmts[1]["End"] == pos(10, 1, 11)
    assert tree["End"] == pos(10, 1, 11)


@pytest.mark.parametrize("tail", ["&|", "&!"])
def test_disowned_statement_end(run_shfmt, tail):
    """Both zsh disown spellings end the statement past the operator."""
    # CATCHES: `sleep 1 &|` and `sleep 1 &!` keep the command end at column
    # 8 but move the statement end to column 11, with Disown set and the
    # Semicolon position recorded at the operator's ampersand.
    tree = encoded(run_shfmt, "zsh", f"sleep 1 {tail}")
    stmt = tree["Stmts"][0]
    assert stmt["Disown"] is True
    assert stmt["Semicolon"] == pos(8, 1, 9)
    assert stmt["Cmd"]["End"] == pos(7, 1, 8)
    assert stmt["End"] == pos(10, 1, 11)
    assert tree["End"] == pos(10, 1, 11)


def test_braced_c_style_for_end(run_shfmt):
    """A `{ }`-braced C-style for loop records DoPos/DonePos on the braces."""
    # CATCHES: with Braces set, DonePos is the closing brace at column 20
    # and the clause ends one past it; the loop body statement ends at its
    # own semicolon instead.
    tree = encoded(run_shfmt, "bash", "for ((i=0;;)) { :; }")
    for_clause = tree["Stmts"][0]["Cmd"]
    assert for_clause["Type"] == "ForClause"
    assert for_clause["ForPos"] == pos(0, 1, 1)
    assert for_clause["Braces"] is True
    assert for_clause["DoPos"] == pos(14, 1, 15)
    assert for_clause["DonePos"] == pos(19, 1, 20)
    assert for_clause["End"] == pos(20, 1, 21)
    assert for_clause["Do"][0]["End"] == pos(18, 1, 19)


def test_braced_case_clause_end(run_shfmt):
    """A mksh `case x { ... }` clause ends just past the closing brace."""
    # CATCHES: Esac points at the `}` at offset 16 while the clause End is
    # one byte further, and the single item ends at its `;;` terminator
    # with the operator position recorded separately.
    tree = encoded(run_shfmt, "mksh", "case x { a) :;; }")
    case_clause = tree["Stmts"][0]["Cmd"]
    assert case_clause["Type"] == "CaseClause"
    assert case_clause["Case"] == pos(0, 1, 1)
    assert case_clause["In"] == pos(7, 1, 8)
    assert case_clause["Braces"] is True
    assert case_clause["Esac"] == pos(16, 1, 17)
    assert case_clause["End"] == pos(17, 1, 18)
    item = case_clause["Items"][0]
    assert item["Op"] == ";;"
    assert item["OpPos"] == pos(13, 1, 14)
    assert item["End"] == pos(15, 1, 16)
    assert item["Stmts"][0]["End"] == pos(13, 1, 14)


def test_bare_time_clause_end(run_shfmt):
    """`time` with no pipeline still spans the whole keyword."""
    # CATCHES: a TimeClause without X carries no operand field at all, and
    # its End covers the bare keyword through offset 4, matching the file.
    tree = encoded(run_shfmt, "bash", "time")
    clause = tree["Stmts"][0]["Cmd"]
    assert clause["Type"] == "TimeClause"
    assert clause["Time"] == pos(0, 1, 1)
    assert "X" not in clause
    assert clause["End"] == pos(4, 1, 5)
    assert tree["Stmts"][0]["End"] == pos(4, 1, 5)
    assert tree["End"] == pos(4, 1, 5)


def test_paren_test_end(run_shfmt):
    """A parenthesised [[ ]] operand spans from `(` to just past `)`."""
    # CATCHES: ParenTest keeps both paren positions (offsets 3 and 10) and
    # an End one past the closing paren, while the nested UnaryTest ends at
    # its operand word.
    tree = encoded(run_shfmt, "bash", "[[ ( -n x ) ]]")
    paren = _find_node(tree, "ParenTest")
    assert paren is not None
    assert paren["Lparen"] == pos(3, 1, 4)
    assert paren["Rparen"] == pos(10, 1, 11)
    assert paren["End"] == pos(11, 1, 12)
    assert paren["X"]["Type"] == "UnaryTest"
    assert paren["X"]["Op"] == "-n"
    assert paren["X"]["OpPos"] == pos(5, 1, 6)
    assert paren["X"]["End"] == pos(9, 1, 10)


def test_paren_arithm_end(run_shfmt):
    """A parenthesised arithmetic operand records both of its parens."""
    # CATCHES: ParenArithm sits inside the $((...)) expansion with Lparen
    # and Rparen at offsets 9 and 11 and its End one past the closer.
    tree = encoded(run_shfmt, "bash", "echo $(( (x) ))")
    paren = _find_node(tree, "ParenArithm")
    assert paren is not None
    assert paren["Lparen"] == pos(9, 1, 10)
    assert paren["Rparen"] == pos(11, 1, 12)
    assert paren["End"] == pos(12, 1, 13)
    assert paren["X"]["Parts"][0]["Value"] == "x"
    exp = _find_node(tree, "ArithmExp")
    assert exp["End"] == pos(15, 1, 16)


def test_declare_index_without_value_end(run_shfmt):
    """`declare -a a[1]` builds a naked assign with an index and no value."""
    # CATCHES: the name argument serialises Name "a" plus an Index word but
    # no Value at all, and its End matches the whole DeclClause end.
    tree = encoded(run_shfmt, "bash", "declare -a a[1]")
    decl = tree["Stmts"][0]["Cmd"]
    assert decl["Type"] == "DeclClause"
    assert decl["Variant"]["Value"] == "declare"
    flag, name = decl["Args"]
    assert flag["Naked"] is True
    assert flag["Value"]["Parts"][0]["Value"] == "-a"
    assert name["Naked"] is True
    assert "Value" not in name
    assert name["Name"]["Value"] == "a"
    assert name["Index"]["Parts"][0]["Value"] == "1"
    assert name["End"] == pos(15, 1, 16)
    assert decl["End"] == pos(15, 1, 16)


def test_array_element_without_value_end(run_shfmt):
    """`a=([2]=)` keeps an indexed element that has no Value word."""
    # CATCHES: the element ends at its own `=` at offset 7 holding only the
    # Index, the array's Rparen lands on line 2, and both the array and the
    # assignment end just past it.
    tree = encoded(run_shfmt, "bash", "a=([2]=\n)")
    assign = tree["Stmts"][0]["Cmd"]["Assigns"][0]
    assert assign["Name"]["Value"] == "a"
    array = assign["Array"]
    assert array["Lparen"] == pos(2, 1, 3)
    assert array["Rparen"] == pos(8, 2, 1)
    assert array["End"] == pos(9, 2, 2)
    elem = array["Elems"][0]
    assert "Value" not in elem
    assert elem["Index"]["Parts"][0]["Value"] == "2"
    assert elem["End"] == pos(7, 1, 8)
    assert assign["End"] == pos(9, 2, 2)
    assert tree["End"] == pos(9, 2, 2)


def test_negated_statement_end(run_shfmt):
    """`!` belongs to the statement, not to the command it precedes."""
    # CATCHES: the CallExpr starts at offset 2 while the statement starts
    # at 0, so Stmt.End covers the `!` too and Negated is set.
    tree = encoded(run_shfmt, "bash", "! foo")
    stmt = tree["Stmts"][0]
    assert stmt["Negated"] is True
    assert stmt["Position"] == pos(0, 1, 1)
    assert stmt["Cmd"]["Pos"] == pos(2, 1, 3)
    assert stmt["Cmd"]["End"] == pos(5, 1, 6)
    assert stmt["End"] == pos(5, 1, 6)


def test_declare_bare_name_end(run_shfmt):
    """`declare a` produces a naked assign holding only a Name."""
    # CATCHES: the argument has neither Value nor Index, just the Name "a",
    # and still receives a full End position like any other node.
    tree = encoded(run_shfmt, "bash", "declare a")
    decl = tree["Stmts"][0]["Cmd"]
    arg = decl["Args"][0]
    assert arg["Naked"] is True
    assert arg["Name"]["Value"] == "a"
    assert "Value" not in arg
    assert "Index" not in arg
    assert arg["End"] == pos(9, 1, 10)
    assert decl["End"] == pos(9, 1, 10)


def test_empty_subshell_end(run_shfmt):
    """A zsh subshell of only a newline builds a Subshell with no Stmts."""
    # CATCHES: the node keeps both paren positions (line 1 and line 2) and
    # an End on line 2 even though it has no statement list at all.
    tree = encoded(run_shfmt, "zsh", "(\n)")
    sub = tree["Stmts"][0]["Cmd"]
    assert sub["Type"] == "Subshell"
    assert "Stmts" not in sub
    assert sub["Lparen"] == pos(0, 1, 1)
    assert sub["Rparen"] == pos(2, 2, 1)
    assert sub["End"] == pos(3, 2, 2)
    assert tree["End"] == pos(3, 2, 2)


def test_procsubst_temp_end(run_shfmt):
    """A zsh `=(...)` word part carries the `=(` operator and its parens."""
    # CATCHES: ProcSubst records the two-character Op "=(" with OpPos at
    # the `=`, and the inner `ls` statement ends one past the Rparen.
    tree = encoded(run_shfmt, "zsh", "echo =(ls)")
    proc = _find_node(tree, "ProcSubst")
    assert proc is not None
    assert proc["Op"] == "=("
    assert proc["OpPos"] == pos(5, 1, 6)
    assert proc["Rparen"] == pos(9, 1, 10)
    assert proc["End"] == pos(10, 1, 11)
    inner = proc["Stmts"][0]
    assert inner["End"] == pos(9, 1, 10)
    assert inner["Cmd"]["Args"][0]["Parts"][0]["Value"] == "ls"
