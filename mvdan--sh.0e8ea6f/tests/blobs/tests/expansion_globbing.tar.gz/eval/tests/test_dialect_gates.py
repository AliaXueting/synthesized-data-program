"""Dialect gates: which expansion forms each -ln variant accepts.

The language dialect decides whether an expansion family is even parseable.
Every assertion here is an exact stderr line plus exit status 1 recorded from
the reference, including the column the parser blames.
"""


def test_bash_only_families_rejected_in_posix(run_shfmt):
    """Posix rejects case conversion, @-transforms, indirection and arrays."""
    # CATCHES: each family has its own wording ("search and replace",
    # "slicing", "arrays", ...) and its own blame column, so a re-implementation
    # cannot reuse one generic message for all of them.
    cases = [
        ("echo ${var^}\n", "<standard input>:1:11: this expansion operator is a bash feature; tried parsing as posix\n"),
        ("echo ${var,,}\n", "<standard input>:1:11: this expansion operator is a bash feature; tried parsing as posix\n"),
        ("echo ${x@Q}\n", "<standard input>:1:9: this expansion operator is a bash/mksh feature; tried parsing as posix\n"),
        ("echo ${!var}\n", "<standard input>:1:6: `${!foo}` is a bash/mksh feature; tried parsing as posix\n"),
        ("echo ${var/pat/repl}\n", "<standard input>:1:11: search and replace is a bash/mksh/zsh feature; tried parsing as posix\n"),
        ("echo ${var:1:2}\n", "<standard input>:1:11: slicing is a bash/mksh/zsh feature; tried parsing as posix\n"),
        ("echo ${arr[@]}\n", "<standard input>:1:11: arrays are a bash/mksh/zsh feature; tried parsing as posix\n"),
        ("echo ${x[-1]}\n", "<standard input>:1:9: arrays are a bash/mksh/zsh feature; tried parsing as posix\n"),
    ]
    for src, message in cases:
        res = run_shfmt(["-ln=posix"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == message, src


def test_zsh_rejects_bash_and_mksh_operators(run_shfmt):
    """Zsh accepts its own operators but refuses the bash/mksh ones."""
    # CATCHES: the same ${x@Q} is rejected under zsh with "tried parsing as
    # zsh", and the mksh-only ${%x} width operator gets its own message.
    cases = [
        ("echo ${x@Q}\n", "<standard input>:1:9: this expansion operator is a bash/mksh feature; tried parsing as zsh\n"),
        ("echo ${%x}\n", "<standard input>:1:6: `${%foo}` is a mksh feature; tried parsing as zsh\n"),
    ]
    for src, message in cases:
        res = run_shfmt(["-ln=zsh"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == message, src


def test_bash_rejects_mksh_width_operator(run_shfmt):
    """Bash refuses the mksh ${%x} width operator with a fixed message."""
    # CATCHES: the message template mentions the parameter as `${%foo}` even
    # though the input spelled it `${%x}`, i.e. a generic placeholder.
    res = run_shfmt(["-ln=bash"], "echo ${%x}\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:6: `${%foo}` is a mksh feature; tried parsing as bash\n"


def test_operators_accepted_outside_their_home_dialect(run_shfmt):
    """mksh accepts ${%x}; bash, bats and mksh all accept the @-transform."""
    # CATCHES: the accept/reject matrix is per family and per dialect, so a
    # single "is this bash" check is not enough to reproduce it.
    for lang, src in [
        ("-ln=mksh", "echo ${%x}\n"),
        ("-ln=bash", "echo ${x@Q}\n"),
        ("-ln=bats", "echo ${x@Q}\n"),
        ("-ln=mksh", "echo ${x@Q}\n"),
    ]:
        res = run_shfmt([lang], src)
        assert res.returncode == 0, (lang, src)
        assert res.stdout == src, (lang, src)
        assert res.stderr == "", (lang, src)


def test_zsh_only_prefix_operators(run_shfmt):
    """Zsh's = ~ ^ prefixes, nested parameters and :modifiers all parse."""
    # CATCHES: these look like unknown operators to bash, so the zsh dialect
    # must accept them and print them back unchanged.
    for src in ["echo ${=x}\n", "echo ${~x}\n", "echo ${^x}\n", "echo ${${x}}\n", "echo ${x:u}\n"]:
        res = run_shfmt(["-ln=zsh"], src)
        assert res.returncode == 0, src
        assert res.stdout == src, src
        assert res.stderr == "", src


def test_auto_dialect_from_filename_extension(run_shfmt):
    """A .posix filename makes -ln=auto blame posix in its suffix message."""
    # CATCHES: with an explicit -ln the suffix is absent; only the auto path
    # appends "(parsed as posix via -ln=auto)" to the language error.
    res = run_shfmt(["--filename=foo.posix"], "echo ${var^}")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "foo.posix:1:11: this expansion operator is a bash feature; "
        "tried parsing as posix (parsed as posix via -ln=auto)\n"
    )


def test_auto_dialect_acceptance_by_extension(run_shfmt):
    """The filename extension alone selects the dialect under -ln=auto."""
    # CATCHES: .bash/.bats/.sh accept the bash-only operator while .zsh and
    # .mksh reject it, all without any -ln flag on the command line.
    accepted = [
        ("foo.bash", "echo ${var^}\n"),
        ("foo.bats", "echo ${var^}\n"),
        ("foo.sh", "echo ${var^}\n"),
    ]
    for name, src in accepted:
        res = run_shfmt(["--filename=" + name], src)
        assert res.returncode == 0, name
        assert res.stdout == src, name
        assert res.stderr == "", name
    rejected = [
        ("foo.zsh", "foo.zsh:1:11: this expansion operator is a bash feature; tried parsing as zsh (parsed as zsh via -ln=auto)\n"),
        ("foo.mksh", "foo.mksh:1:11: this expansion operator is a bash feature; tried parsing as mksh (parsed as mksh via -ln=auto)\n"),
    ]
    for name, message in rejected:
        res = run_shfmt(["--filename=" + name], "echo ${var^}")
        assert res.returncode == 1, name
        assert res.stdout == "", name
        assert res.stderr == message, name


def test_auto_dialect_from_shebang(run_shfmt):
    """A #!/bin/sh shebang selects posix and reports the auto suffix."""
    # CATCHES: the dialect can come from the file contents rather than the
    # name, and the error still carries the "(parsed as ... via -ln=auto)" tail.
    res = run_shfmt([], "#!/bin/sh\necho ${var^}\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:2:11: this expansion operator is a bash feature; "
        "tried parsing as posix (parsed as posix via -ln=auto)\n"
    )


def test_auto_dialect_shebang_bash_accepted(run_shfmt):
    """A #!/bin/bash shebang makes the bash-only operator legal."""
    # CATCHES: the whole script, shebang included, is echoed back unchanged,
    # proving the shebang was honoured rather than ignored.
    src = "#!/bin/bash\necho ${var^}\n"
    res = run_shfmt([], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_explicit_dialect_has_no_auto_suffix(run_shfmt):
    """An explicit -ln=posix error carries no "(parsed as ...)" tail."""
    # CATCHES: only the auto path appends the provenance suffix, so the two
    # invocation styles are distinguishable from stderr alone.
    res = run_shfmt(["-ln=posix"], "echo ${var^}\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:11: this expansion operator is a bash feature; tried parsing as posix\n"
    )
