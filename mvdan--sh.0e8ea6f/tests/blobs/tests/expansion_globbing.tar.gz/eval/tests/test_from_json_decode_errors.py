"""Typed-JSON decode diagnostics (--from-json) for positions and fields.

--from-json rebuilds a syntax tree from typed JSON.  Malformed input gives
precise per-arm diagnostics: a position field that is not an object, a
position object with the wrong field set, position values out of range, the
Redirect fd literal given as a scalar, unknown fields, a node type decoded
into the wrong slot, operators given as numbers, and non-object top levels.
"""

import json

import pytest


def tree():
    """A minimal File -> Stmt -> CallExpr(echo) with a 2> redirect."""
    return {
        "Type": "File",
        "Stmts": [{
            "Cmd": {
                "Type": "CallExpr",
                "Args": [{
                    "Parts": [{
                        "Type": "Lit",
                        "Pos": {"Offset": 0, "Line": 1, "Col": 1},
                        "ValuePos": {"Offset": 0, "Line": 1, "Col": 1},
                        "Value": "echo",
                    }],
                }],
            },
            "Redirs": [{
                "OpPos": {"Offset": 0, "Line": 1, "Col": 1},
                "Op": ">",
                "N": {
                    "Type": "Lit",
                    "Pos": {"Offset": 0, "Line": 1, "Col": 1},
                    "ValuePos": {"Offset": 0, "Line": 1, "Col": 1},
                    "Value": "2",
                },
                "Word": {"Parts": [{
                    "Type": "Lit",
                    "Pos": {"Offset": 1, "Line": 1, "Col": 2},
                    "ValuePos": {"Offset": 1, "Line": 1, "Col": 2},
                    "Value": "f",
                }]},
            }],
        }],
    }


def run_json(run_shfmt, obj):
    return run_shfmt(["--from-json"], obj if isinstance(obj, str) else json.dumps(obj))


@pytest.mark.parametrize(
    "value, json_type",
    [(3, "number"), (None, "null"), (True, "boolean"), ("x", "string"), ([], "array")],
)
def test_position_field_must_be_object(run_shfmt, value, json_type):
    """A position field holding a JSON scalar names the JSON type."""
    # CATCHES: the diagnostic distinguishes number/null/boolean/string/array
    # instead of a generic type error, e.g. "cannot decode JSON null into a
    # position" for ValuePos: null.
    t = tree()
    t["Stmts"][0]["Cmd"]["Args"][0]["Parts"][0]["ValuePos"] = value
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == f"cannot decode JSON {json_type} into a position\n"


@pytest.mark.parametrize(
    "pos",
    [
        {"Offset": 0, "Line": 1, "Col": 1, "X": 9},
        {"Offset": 0, "Line": 1},
    ],
)
def test_position_needs_exactly_three_fields(run_shfmt, pos):
    """A position object must have exactly Offset, Line and Col."""
    # CATCHES: extra or missing position fields both give the same wording
    # listing the exact allowed field set.
    t = tree()
    t["Stmts"][0]["Cmd"]["Args"][0]["Parts"][0]["ValuePos"] = pos
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stderr == "a position must contain exactly the fields [Offset Line Col]\n"


def test_position_field_value_must_be_number(run_shfmt):
    """A string inside a position names the offending field."""
    # CATCHES: the error mentions both the JSON type and the position field
    # name, so "Line": "1" is distinguishable from a bad Offset.
    t = tree()
    t["Stmts"][0]["Cmd"]["Args"][0]["Parts"][0]["ValuePos"] = {
        "Offset": 0, "Line": "1", "Col": 1,
    }
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stderr == 'cannot decode JSON string into the position field "Line"\n'


@pytest.mark.parametrize(
    "pos, field, rendered",
    [
        ({"Offset": -1, "Line": 1, "Col": 1}, "Offset", "-1"),
        ({"Offset": 0.5, "Line": 1, "Col": 1}, "Offset", "0.5"),
        ({"Offset": 0, "Line": 4294967296, "Col": 1}, "Line", "4.294967296e+09"),
    ],
)
def test_position_values_out_of_range(run_shfmt, pos, field, rendered):
    """Negative, fractional or >uint32 position values are rejected."""
    # CATCHES: out-of-range values echo the offending number, with large
    # values rendered in Go float formatting (4.294967296e+09).
    t = tree()
    t["Stmts"][0]["Cmd"]["Args"][0]["Parts"][0]["ValuePos"] = pos
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stderr == f'the position field "{field}" is out of range: {rendered}\n'


@pytest.mark.parametrize(
    "value, json_type",
    [(3, "number"), (True, "boolean"), ("2", "string"), ([], "array")],
)
def test_redirect_fd_must_be_a_literal_node(run_shfmt, value, json_type):
    """The redirect fd (N) is a Lit node, so scalars name *syntax.Lit."""
    # CATCHES: unlike Pos fields, N decodes as a node pointer, so "N": 3
    # reports *syntax.Lit, not a position or operator type.
    t = tree()
    t["Stmts"][0]["Redirs"][0]["N"] = value
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == f"cannot decode JSON {json_type} into *syntax.Lit\n"


def test_redirect_fd_null_and_roundtrips(run_shfmt):
    """A null fd is allowed and redirects print before the command."""
    # CATCHES: "N": null leaves the fd unset, the > redirect prints as
    # ">f echo" and the >> form as "2>>f echo" with the fd kept.
    t = tree()
    t["Stmts"][0]["Redirs"][0]["N"] = None
    res = run_json(run_shfmt, t)
    assert res.returncode == 0
    assert res.stdout == ">f echo\n"
    assert res.stderr == ""

    res = run_json(run_shfmt, tree())
    assert res.returncode == 0
    assert res.stdout == "2>f echo\n"

    t = tree()
    t["Stmts"][0]["Redirs"][0]["Op"] = ">>"
    res = run_json(run_shfmt, t)
    assert res.returncode == 0
    assert res.stdout == "2>>f echo\n"


def test_unknown_field_names_the_type(run_shfmt):
    """An extra JSON field reports the Go struct it does not belong to."""
    # CATCHES: the message pairs the node type (syntax.File) with the exact
    # unknown field name, so typos in field names are easy to spot.
    t = tree()
    t["Foo"] = 1
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stderr == 'unknown field for syntax.File: "Foo"\n'


def test_node_type_decoded_into_wrong_slot(run_shfmt):
    """A known node type in the wrong list reports both sides."""
    # CATCHES: putting {"Type": "Lit"} where a *syntax.Stmt belongs gives
    # "cannot decode Lit into *syntax.Stmt" rather than a type panic.
    t = tree()
    t["Stmts"][0] = {
        "Type": "Lit",
        "Pos": {"Offset": 0, "Line": 1, "Col": 1},
        "Value": "x",
    }
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stderr == "cannot decode Lit into *syntax.Stmt\n"


def test_command_interface_needs_type(run_shfmt):
    """An empty command object reports the interface it cannot build."""
    # CATCHES: "Cmd": {} has no Type to pick a command node, so the error
    # names the syntax.Command interface and the missing "Type" key.
    t = tree()
    t["Stmts"][0]["Cmd"] = {}
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stderr == 'missing "Type" to decode a JSON object into syntax.Command\n'


def test_operator_must_be_given_as_string(run_shfmt):
    """Operator enums reject JSON numbers and demand their string form."""
    # CATCHES: "Op": 3 names the enum type and explains a string is
    # required -- the wire format only carries operator spellings.
    t = tree()
    t["Stmts"][0]["Redirs"][0]["Op"] = 3
    res = run_json(run_shfmt, t)
    assert res.returncode == 1
    assert res.stderr == (
        "cannot decode JSON number into syntax.RedirOperator; a string is required\n"
    )


@pytest.mark.parametrize(
    "src, message",
    [
        ("[1, 2]", "cannot decode JSON array into syntax.Node"),
        ('"foo"', "cannot decode JSON string into syntax.Node"),
        ("3", "cannot decode JSON number into syntax.Node"),
        ("true", "cannot decode JSON boolean into syntax.Node"),
        ("null", "cannot decode JSON null into a syntax node"),
    ],
)
def test_top_level_json_types(run_shfmt, src, message):
    """Non-object top-level JSON is rejected with its JSON type."""
    # CATCHES: null gets its own "a syntax node" wording while the other
    # scalars name the syntax.Node interface they cannot populate.
    res = run_json(run_shfmt, src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message + "\n"
