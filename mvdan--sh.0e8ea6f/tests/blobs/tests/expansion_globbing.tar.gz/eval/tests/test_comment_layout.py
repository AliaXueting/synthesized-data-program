"""Trailing comments after multi-line statements.

A comment on the closing line of a multi-line statement forces the printer to
compute the statement's end position: consecutive statements align their
trailing comments in one column, and some constructs answer with a
line-continuation backslash instead.
"""

import pytest


def test_trailing_comments_align_in_one_column(run_shfmt):
    """Consecutive statements align their trailing comments to one column."""
    # CATCHES: the four comments line up at the same column even though the
    # statements end at different widths, and the multi-line subshell keeps
    # its comment after the closing parenthesis.
    src = "(a; b) # c\n{ a; } # d\nif a; then b; fi # e\nwhile a; do b; done # f\n"
    res = run_shfmt(["-ln=bash", "-"], src)
    assert res.returncode == 0
    assert res.stdout == (
        "(\n\ta\n\tb\n)                   # c\n"
        "{ a; }              # d\n"
        "if a; then b; fi    # e\n"
        "while a; do b; done # f\n"
    )
    assert res.stderr == ""


def test_comment_after_function_body(run_shfmt):
    """A comment after a function's closing brace stays on that line."""
    # CATCHES: the comment stays glued after `}` rather than moving to its
    # own line, which needs the function's end position.
    res = run_shfmt(["-ln=bash", "-"], "f() {\n\t:\n} # c\n")
    assert res.returncode == 0
    assert res.stdout == "f() {\n\t:\n} # c\n"
    assert res.stderr == ""


def test_comment_after_multiline_arith_command(run_shfmt):
    """A trailing comment after (( ... )) forces the backslash form."""
    # CATCHES: an arithmetic command cannot end with the comment on the same
    # line, so the printer rewrites the opening as `((\\` and pushes the
    # comment to a line of its own.
    res = run_shfmt(["-ln=bash", "-"], "((\nx\n)) # c\n")
    assert res.returncode == 0
    assert res.stdout == "((\\\nx))\n# c\n"
    assert res.stderr == ""


@pytest.mark.parametrize(
    "src,expected",
    [
        ("time {\n\t:\n} # c\n", "time {\n\t:\n} # c\n"),
        ("coproc foo {\n\t:\n} # c\n", "coproc foo {\n\t:\n} # c\n"),
        ("for x in a b; do\n\t:\ndone # c\n", "for x in a b; do\n\t:\ndone # c\n"),
        ("select x in a; do\n\t:\ndone # c\n", "select x in a; do\n\t:\ndone # c\n"),
        ("a=(\n1\n) # c\n", "a=(\n\t1\n) # c\n"),
        ("case x in\na) b;;\nesac # c\n", "case x in\na) b ;;\nesac # c\n"),
    ],
)
def test_comment_after_each_multiline_construct(run_shfmt, src, expected):
    """Every multi-line construct keeps a trailing comment on its last line."""
    # CATCHES: time, coproc, for, select, array literals and case all place
    # the comment after their closing token, and each still reformats its
    # body (the array element gains a tab, `b;;` gains a space).
    res = run_shfmt(["-ln=bash", "-"], src)
    assert res.returncode == 0, src
    assert res.stdout == expected, src
    assert res.stderr == "", src


def test_comment_after_pipe_subshell(run_shfmt):
    """`cmd |(` is spaced to `cmd | (` and keeps its trailing comment."""
    # CATCHES: a subshell directly after a pipe operator gains a space after
    # the pipe, its body is indented, and the comment stays on the paren line.
    res = run_shfmt(["-ln=bash", "-"], "echo a |(\n b\n) # c\n")
    assert res.returncode == 0
    assert res.stdout == "echo a | (\n\tb\n) # c\n"
    assert res.stderr == ""
