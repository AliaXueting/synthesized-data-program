"""coproc clause shapes and function-declaration variants.

Every coproc argument shape (compound command, name+command, bare name),
the bash/zsh split on anonymous and multi-name functions, and the
paren-related diagnostics for function declarations and call arguments.
"""


def test_coproc_compound_command_forms(run_shfmt):
    """coproc directly followed by a compound command needs no name."""
    # CATCHES: while/until, brace groups, subshells and if clauses after
    # coproc are the coprocessed command itself and stay on one line.
    cases = [
        "coproc while :; do sleep 1; done\n",
        "coproc { echo hi; }\n",
        "coproc (echo hi)\n",
        "coproc if true; then echo x; fi\n",
    ]
    for src in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 0, src
        assert res.stdout == src, src
        assert res.stderr == "", src


def test_coproc_name_forms(run_shfmt):
    """coproc NAME cmd and a bare coproc NAME both reprint their word order."""
    # CATCHES: a word after coproc that is not a compound command becomes
    # the process NAME; with a following command the two words stay in
    # order, and with no command the name is the command itself.
    res = run_shfmt(["-"], "coproc NAME echo hi\n")
    assert res.returncode == 0
    assert res.stdout == "coproc NAME echo hi\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "coproc simple\n")
    assert res.returncode == 0
    assert res.stdout == "coproc simple\n"
    assert res.stderr == ""


def test_coproc_requires_command_error(run_shfmt):
    """A bare `coproc` in bash errors; in posix and zsh it is a plain word."""
    # CATCHES: coproc is only a bash compound-command keyword, so the
    # requires-a-command diagnostic fires in bash while other dialects see
    # an ordinary command named coproc and print it unchanged.
    res = run_shfmt(["-"], "coproc\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:1: coproc clause requires a command\n"

    for dialect in ("-ln=posix", "-ln=zsh"):
        res = run_shfmt([dialect, "-"], "coproc\n")
        assert res.returncode == 0, dialect
        assert res.stdout == "coproc\n", dialect
        assert res.stderr == "", dialect


def test_function_multi_name_and_anonymous(run_shfmt):
    """Multi-name and anonymous `function` forms are zsh-only."""
    # CATCHES: bash rejects both with a dialect error naming zsh, while zsh
    # prints the anonymous form with the space before `(` removed.
    res = run_shfmt(["-ln=bash", "-"], "function f g {\n\techo hi\n}\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:1: multi-name functions are a zsh feature; "
        "tried parsing as bash\n"
    )

    res = run_shfmt(["-ln=bash", "-"], "function () {\n\techo hi\n}\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:1: anonymous functions are a zsh feature; "
        "tried parsing as bash\n"
    )

    res = run_shfmt(["-ln=zsh", "-"], "function () {\n\techo hi\n}\n")
    assert res.returncode == 0
    assert res.stdout == "function() {\n\techo hi\n}\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=zsh", "-"], "function {\n\techo hi\n}\n")
    assert res.returncode == 0
    assert res.stdout == "function {\n\techo hi\n}\n"
    assert res.stderr == ""


def test_function_missing_paren_error(run_shfmt):
    """`function f(` without the closing paren names the full prefix."""
    # CATCHES: the diagnostic spells the whole declaration head
    # (`function foo(`), not just the missing token.
    res = run_shfmt(["-"], "function f( {\n\techo hi\n}\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:1: `function foo(` must be followed by `)`\n"
    )


def test_paren_in_call_arguments(run_shfmt):
    """A `(` after a command word is a func-name error in bash, a word in zsh."""
    # CATCHES: `echo (ls)` looks like declaring the function `echo(`, which
    # must be closed -- while zsh keeps the parenthesised word as an
    # argument; `((` in argument position reports the arithmetic-command
    # wording at the paren column.
    res = run_shfmt(["-"], "echo (ls)\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:1: `foo(` must be followed by `)`\n"

    res = run_shfmt(["-ln=zsh", "-"], "echo (ls)\n")
    assert res.returncode == 0
    assert res.stdout == "echo (ls)\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "echo ((1))\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:6: `((` can only be used to open an arithmetic cmd\n"
    )
