"""Parser diagnostics for statement, test and word-level tail cases.

Error tails that no earlier file pinned down: adjacent compound commands,
stray closing tokens, `!` inside a pipeline, redirects before compound
commands, empty test operands, multi-part test operators, declare name
rules, `let` requirements, inline arrays, unusual parameter expansion
operators, the bats `@test` form, expansion-free heredoc words, and zsh's
nested-expansion quoting gate.
"""


def test_adjacent_statements_need_separator(run_shfmt):
    """Two [[ ]] tests on one line must be separated explicitly."""
    # CATCHES: the second `[[` cannot open a new statement on the same
    # line; the error names all three legal separators and points at
    # column 9 where the second test begins.
    res = run_shfmt(["-"], "[[ a ]] [[ b ]]")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:9: statements must be separated by &, ; or a newline\n"
    )


def test_stray_closing_tokens(run_shfmt):
    """) and ]] at the start name the construct they would have closed."""
    # CATCHES: each closer gets its own wording naming the construct
    # (subshell, test) instead of a generic unexpected-token message.
    cases = [
        (") foo", "<standard input>:1:1: `)` can only be used to close a subshell\n"),
        ("]] foo", "<standard input>:1:1: `]]` can only be used to close a test\n"),
    ]
    for src, err in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == err, src


def test_bang_rejected_inside_pipeline(run_shfmt):
    """`!` negates whole statements, not segments of a pipeline."""
    # CATCHES: after `a |` the `!` sits in a pipeline position, so it is
    # rejected at its own column 5 with "can only be used in full
    # statements".
    res = run_shfmt(["-"], "a | ! b")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:5: `!` can only be used in full statements\n"


def test_redirect_before_compound_is_zsh(run_shfmt):
    """A redirect in front of a { } block is reported as a zsh feature."""
    # CATCHES: the gate message names the feature and the dialect it tried,
    # including the auto-detection suffix "(parsed as bash via -ln=auto)".
    res = run_shfmt(["-"], "> out { :; }")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:1: redirects before compound commands are a zsh "
        "feature; tried parsing as bash (parsed as bash via -ln=auto)\n"
    )


def test_test_clause_operand_errors(run_shfmt):
    """An empty [[ ]] and a dangling ! or ( each name their own opener."""
    # CATCHES: every opener word -- [[, ! and ( -- has a separate "must be
    # followed by an expression" wording, each pointing at the opener's
    # own starting column.
    cases = [
        ("[[ ]]", "<standard input>:1:1: `[[` must be followed by an expression\n"),
        ("[[ ! ]]", "<standard input>:1:4: `!` must be followed by an expression\n"),
        ("[[ ( ) ]]", "<standard input>:1:4: `(` must be followed by an expression\n"),
    ]
    for src, err in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == err, src


def test_test_operator_single_literal(run_shfmt):
    """A test operator word must be one literal, not several word parts."""
    # CATCHES: `fo"o"` is a single word built from two parts, rejected at
    # the word's starting column 6 before any operand is considered.
    res = run_shfmt(["-"], '[[ a fo"o" b ]]')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:6: test operator words must consist of a single literal\n"
    )


def test_declare_rejects_invalid_var_name(run_shfmt):
    """declare rejects a name starting with a digit at the word itself."""
    # CATCHES: the diagnostic points at column 9, the `1` of `1x`, with
    # the short "invalid var name" wording and no mention of the value.
    res = run_shfmt(["-"], "declare 1x=2")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:9: invalid var name\n"


def test_let_expression_requirements(run_shfmt):
    """`let` demands an expression and its operators an operand after."""
    # CATCHES: bare `let` fails at 1:1 while `let 1 +` fails at the `+`
    # itself (1:7), reusing the arithmetic "must be followed" wording.
    res = run_shfmt(["-"], "let")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:1: `let` must be followed by an expression\n"

    res = run_shfmt(["-"], "let 1 +")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:7: `+` must be followed by an expression\n"


def test_inline_variable_cannot_be_array(run_shfmt):
    """An array assignment is rejected in command-prefix position."""
    # CATCHES: the error is reported at the assignment start (1:1), since
    # inline variables may only hold scalar values.
    res = run_shfmt(["-"], "a=(1) cmd")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:1: inline variables cannot be arrays\n"


def test_paramexp_operator_gates(run_shfmt):
    """${x*} and ${x@} are rejected with two distinct wordings."""
    # CATCHES: `*` is not an expansion operator at the operator column 9,
    # while the valid-looking `@` needs a literal operand, reported one
    # column further at 10.
    res = run_shfmt(["-"], "echo ${x*}")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:9: not a valid parameter expansion operator: `*`\n"
    )

    res = run_shfmt(["-"], "echo ${x@}")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:10: @ expansion operator requires a literal\n"


def test_mksh_unclosed_heredoc(run_shfmt):
    """An mksh heredoc with no body reports the unclosed delimiter."""
    # CATCHES: the message quotes the delimiter word `EOF` and is reported
    # at the operator column 5, before any heredoc body could be read.
    res = run_shfmt(["--ln=mksh", "-"], "cat <<EOF")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:5: unclosed here-document `EOF`\n"


def test_zsh_subscript_flags_unclosed(run_shfmt):
    """A zsh subscript flag paren is tracked all the way to EOF."""
    # CATCHES: the `(r` inside ${x[(r} opens a subscript-flag paren that
    # never closes, so the error is the reached-EOF wording at column 10.
    res = run_shfmt(["--ln=zsh", "-"], "echo ${x[(r}")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:10: reached EOF without matching `(` with `)`\n"
    )


def test_empty_then_body_dialect_split(run_shfmt):
    """`if ...; then; fi` with no body is bash-only syntax to reject."""
    # CATCHES: bash demands a statement list after `then` (error at the
    # keyword, column 10), while zsh and mksh accept and reprint it.
    res = run_shfmt(["--ln=bash", "-"], "if true; then; fi")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:10: `then` must be followed by a statement list\n"
    )

    for dialect in ("zsh", "mksh"):
        res = run_shfmt([f"--ln={dialect}", "-"], "if true; then; fi")
        assert res.returncode == 0, dialect
        assert res.stdout == "if true; then; fi\n", dialect
        assert res.stderr == "", dialect


def test_bats_test_needs_description_and_body(run_shfmt):
    """@test requires a description word and then a body statement."""
    # CATCHES: the missing-description error quotes only `@test`, while
    # the missing-body error echoes the whole `@test "desc"` prefix with
    # the description word included.
    res = run_shfmt(["--ln=bats", "-"], "@test")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:1: `@test` must be followed by a description word\n"
    )

    res = run_shfmt(["--ln=bats", "-"], '@test "desc"')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        '<standard input>:1:1: `@test "desc"` must be followed by a statement\n'
    )


def test_heredoc_word_expansion_gate(run_shfmt):
    """Backquotes are banned in heredoc words unless the word is quoted."""
    # CATCHES: a bare and a double-quoted delimiter containing a backquote
    # are both rejected at the word's own column (8, then 9), while single
    # quotes make the delimiter fully literal and the body round-trips.
    res = run_shfmt(["-"], "cat <<E`O\nbody\nE`O")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:8: expansions not allowed in heredoc words\n"
    )

    res = run_shfmt(["-"], 'cat <<"E`O"\nbody\nE`O')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:9: expansions not allowed in heredoc words\n"
    )

    res = run_shfmt(["-"], "cat <<'E`O'\nbody\nE`O")
    assert res.returncode == 0
    assert res.stdout == "cat <<'E`O'\nbody\nE`O\n"
    assert res.stderr == ""


def test_zsh_nested_parameter_word_gate(run_shfmt):
    """A nested ${(f)"..."} only accepts a substitution inside the quotes."""
    # CATCHES: a plain quoted word is rejected as "invalid nested parameter
    # expansion" at the expansion start (column 6), while "$(foo)" inside
    # the quotes and the ${#"$(foo)"} length form round-trip byte for byte.
    res = run_shfmt(["--ln=zsh", "-"], 'echo ${(f)"x"}')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:6: invalid nested parameter expansion\n"
    )

    res = run_shfmt(["--ln=zsh", "-"], 'echo ${(f)"$(foo)"}')
    assert res.returncode == 0
    assert res.stdout == 'echo ${(f)"$(foo)"}\n'
    assert res.stderr == ""

    res = run_shfmt(["--ln=zsh", "-"], 'echo ${#"$(foo)"}')
    assert res.returncode == 0
    assert res.stdout == 'echo ${#"$(foo)"}\n'
    assert res.stderr == ""
