"""Arithmetic-expression parse tails inside $((...)) and ((...)).

The remaining diagnostic and normalisation paths: a ternary `?` with no
left operand, the elvis `?:` with an empty word, `++` applied to anything
but a name, `++` with no literal after it, a bare `!`, a leading `**`, a
word that is no operator at all, and the mksh unsigned `#` attribute in
both the command and the expansion form.
"""

import pytest


@pytest.mark.parametrize(
    "src, err",
    [
        ("echo $((? 1 : 2))",
         "<standard input>:1:9: `?` must follow an expression\n"),
        ("echo $((a ?: 2))",
         "<standard input>:1:11: `?` must be followed by an expression\n"),
    ],
)
def test_ternary_question_edges(run_shfmt, src, err):
    """A ternary `?` needs an expression on both of its sides."""
    # CATCHES: a leading `?` is rejected before any operand is read, and
    # the zsh-style elvis `?:` is rejected at the `?` because its middle
    # word is empty.
    res = run_shfmt(["-"], src)
    assert res.returncode == 1, src
    assert res.stdout == "", src
    assert res.stderr == err, src


@pytest.mark.parametrize(
    "src, col",
    [
        ("echo $((1++))", 10),
        ("echo $(((x)++))", 12),
        ("echo $(($x++))", 11),
    ],
)
def test_increment_requires_name(run_shfmt, src, col):
    """`++` may only follow a bare name, not a value or an expression."""
    # CATCHES: a literal, a parenthesised expression and a parameter are
    # all rejected as increment targets, and each error column points at
    # the `++` itself rather than the offending operand.
    res = run_shfmt(["-"], src)
    assert res.returncode == 1, src
    assert res.stdout == "", src
    assert res.stderr == f"<standard input>:1:{col}: `++` must follow a name\n", src


def test_increment_requires_literal(run_shfmt):
    """`++` with nothing after it demands a literal, not just any word."""
    # CATCHES: the empty `$((++))` reports at the operator column 9 with
    # "must be followed by a literal", a different wording than the
    # expression-tail errors.
    res = run_shfmt(["-"], "echo $((++))")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:9: `++` must be followed by a literal\n"


def test_logical_not_requires_expression(run_shfmt):
    """A `!` inside arithmetic needs an operand after it."""
    # CATCHES: `$((!))` is rejected at the `!` at column 9 with the same
    # "must be followed by an expression" wording as outside arithmetic.
    res = run_shfmt(["-"], "echo $((!))")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:9: `!` must be followed by an expression\n"


def test_power_requires_left_operand(run_shfmt):
    """A leading `**` has no left operand to exponentiate."""
    # CATCHES: the power operator is rejected at column 9 with its own
    # "must follow an expression" message, distinct from `*`.
    res = run_shfmt(["-"], "echo $((**2))")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:9: `**` must follow an expression\n"


def test_word_that_is_no_operator(run_shfmt):
    """A `;` between operands is named as an invalid operator."""
    # CATCHES: the semicolon is lexed as an arithmetic word of its own and
    # rejected with the operator wording at its own column 11, keeping the
    # backquoted token in the message.
    res = run_shfmt(["-"], "echo $((1 ; 2))")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:11: not a valid arithmetic operator: `;`\n"
    )


def test_mksh_unsigned_arithm_roundtrip(run_shfmt):
    """The mksh `#` attribute makes an arithmetic expression unsigned."""
    # CATCHES: the command form `((# 5))` round-trips unchanged while the
    # expansion form `$((#5))` gains a space after the `#` on the way out.
    res = run_shfmt(["--ln=mksh", "-"], "((# 5))")
    assert res.returncode == 0
    assert res.stdout == "((# 5))\n"
    assert res.stderr == ""

    res = run_shfmt(["--ln=mksh", "-"], "echo $((#5))")
    assert res.returncode == 0
    assert res.stdout == "echo $((# 5))\n"
    assert res.stderr == ""
