"""Heredoc edge shapes: backquotes, truncation, tab-form closing words.

What happens when a heredoc is left open at a closing backquote, when the
body is empty or missing entirely, and how <<- treats the tabs in front of a
quoted closing word.
"""


def test_unclosed_heredoc_completes_at_backquote(run_shfmt):
    """A heredoc still open when a backquote closes gets a delimiter."""
    # CATCHES: the heredoc is ended at the closing backquote and gains an
    # `EOF` line, and the whole command substitution is reprinted as $( )
    # with the heredoc indented inside it.
    res = run_shfmt(["-ln=bash", "-"], "echo `cat <<EOF\nx\n`\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(\n\tcat <<EOF\nx\nEOF\n)\n"
    assert res.stderr == ""


def test_closed_heredoc_inside_backquote(run_shfmt):
    """A heredoc fully closed inside a backquote keeps its shape."""
    # CATCHES: the backquote becomes $( ) but the heredoc stays inline
    # because nothing had to be recovered at the closing backquote.
    res = run_shfmt(["-ln=bash", "-"], "echo `cat <<EOF\nx\nEOF`\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(cat <<EOF\nx\nEOF\n)\n"
    assert res.stderr == ""


def test_empty_unclosed_heredoc_gains_closing_word(run_shfmt):
    """A heredoc with no body at all is completed with its delimiter."""
    # CATCHES: EOF right after the operator yields an empty body, and the
    # printer still emits the closing delimiter on the next line.
    res = run_shfmt(["-ln=bash", "-"], "cat <<EOF\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<EOF\nEOF\n"
    assert res.stderr == ""


def test_quoted_unclosed_heredoc_gains_closing_word(run_shfmt):
    """A quoted heredoc truncated at EOF is completed the same way."""
    # CATCHES: the body survives verbatim and a closing word line appears,
    # keeping the quoted delimiter spelling in the operator.
    res = run_shfmt(["-ln=bash", "-"], "cat <<'EOF'\nbody\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<'EOF'\nbody\nEOF\n"
    assert res.stderr == ""


def test_dash_heredoc_tabbed_closing_word(run_shfmt):
    """<<- accepts any number of tabs before the closing word."""
    # CATCHES: the closing word matches after stripping all leading tabs and
    # is reprinted at column 0, while the body keeps its own single tab.
    res = run_shfmt(["-ln=bash", "-"], "cat <<-'EOF'\n\tbody\n\t\tEOF\n")
    assert res.returncode == 0
    assert res.stdout == "cat <<-'EOF'\n\tbody\nEOF\n"
    assert res.stderr == ""


def test_quotes_with_escaped_newline_round_trip(run_shfmt):
    """An escaped newline inside single or double quotes stays literal."""
    # CATCHES: inside quotes the backslash-newline pair is content, so it is
    # printed back exactly rather than joining the two halves of the word.
    res = run_shfmt(["-ln=bash", "-"], "echo 'a\\\nb'\n")
    assert res.returncode == 0
    assert res.stdout == "echo 'a\\\nb'\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=bash", "-"], 'echo "a\\\nb"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "a\\\nb"\n'
    assert res.stderr == ""


def test_backquote_escapes_in_double_quotes(run_shfmt):
    """Backslashes before quotes inside a backquote are dropped in $()."""
    # CATCHES: converting `` `echo \"hi\"` `` to $( ) removes the backslashes
    # that only the backquote form needed, keeping the inner double quotes.
    res = run_shfmt(["-ln=bash", "-"], 'echo "`echo \\"hi\\"`"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "$(echo "hi")"\n'
    assert res.stderr == ""
