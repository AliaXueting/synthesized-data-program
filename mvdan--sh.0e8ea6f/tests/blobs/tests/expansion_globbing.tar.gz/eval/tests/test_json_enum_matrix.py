"""The operator enum matrix through the typed JSON tree.

Every operator spelling that was not yet carried by a --to-json/--from-json
round trip: pipes and case terminators, extglobs, redirect operators, the
no-colon parameter expansion operators, the arithmetic operator zoo, the
[[ ]] operator vocabulary, and the compound assigns that only exist as JSON
values.  Plus the type-mismatch diagnostics of the JSON decoder.
"""

import pytest


def roundtrip(run_shfmt, dialect, src):
    """Format src, serialise it, decode it again and return both outputs."""
    fmt = run_shfmt([dialect, "-"], src)
    assert fmt.returncode == 0, src
    tree = run_shfmt([dialect, "--to-json"], src)
    assert tree.returncode == 0, src
    back = run_shfmt(["--from-json"], tree.stdout)
    assert back.returncode == 0, src
    return fmt, back


def test_pipe_and_case_enums_roundtrip(run_shfmt):
    """&&, ||, |, |&, ;& and ;| survive a JSON decode in their dialects."""
    # CATCHES: binary command operators and case-item terminators are enum
    # values in the tree; a wrong text mapping would print a different
    # operator or fail to decode.
    fmt, back = roundtrip(run_shfmt, "-ln=bash", "a && b || c | d |& e\n")
    assert back.stdout == "a && b || c | d |& e\n"
    assert back.stderr == ""
    assert fmt.stdout == back.stdout

    fmt, back = roundtrip(
        run_shfmt, "-ln=bash",
        "case $x in a) echo 1 ;;& esac\ncase $y in b) echo 2 ;& c) echo 3 ;; esac\n")
    assert back.stdout == fmt.stdout
    assert fmt.stdout == (
        "case $x in a) echo 1 ;;& esac\n"
        "case $y in b) echo 2 ;& c) echo 3 ;; esac\n"
    )

    fmt, back = roundtrip(run_shfmt, "-ln=mksh", "case $x in a) echo 1 ;| esac\n")
    assert back.stdout == "case $x in a) echo 1 ;| esac\n"


def test_extglob_enums_roundtrip(run_shfmt):
    """All five extended glob operators ?( *( +( @( !( decode from JSON."""
    # CATCHES: each extglob spelling is its own GlobOperator enum value and
    # must reprint exactly, including the parenthesised pattern.
    src = "echo ?(a) *(b) +(c) @(d) !(e)\n"
    fmt, back = roundtrip(run_shfmt, "-ln=bash", src)
    assert back.stdout == src
    assert fmt.stdout == src


def test_redirect_enums_roundtrip(run_shfmt):
    """Every redirect spelling round-trips through the JSON tree."""
    # CATCHES: <, >&, <<<, &>, &>> (bash) and >|, >>|, &>|, &>>| (zsh) are
    # distinct RedirOperator values; the zsh clobbers must come back as the
    # | spelling, matching the plain formatter.
    fmt, back = roundtrip(
        run_shfmt, "-ln=bash",
        "cmd <in >&2 4>&3\nx=1 cat <<< hi\n")
    assert back.stdout == fmt.stdout
    assert fmt.stdout == "cmd <in >&2 4>&3\nx=1 cat <<<hi\n"

    fmt, back = roundtrip(
        run_shfmt, "-ln=bash", "cmd &>all\nb &>>append\n")
    assert back.stdout == "cmd &>all\nb &>>append\n"

    fmt, back = roundtrip(
        run_shfmt, "-ln=zsh", "cmd >|force >>|app &>|all &>>|app2\n")
    assert back.stdout == fmt.stdout
    assert fmt.stdout == "cmd >|force >>|app &>|all &>>|app2\n"


def test_paramexp_unset_operators_roundtrip(run_shfmt):
    """The no-colon -, +, ? and = operators decode as their own enum values."""
    # CATCHES: ${x-y} (unset only) must not be confused with ${x:-y} (unset
    # or null) -- both directions of the mapping are exercised.
    src = "a=${x-y} ${x+y} ${x?y} ${x=y}\n"
    fmt, back = roundtrip(run_shfmt, "-ln=bash", src)
    assert back.stdout == src
    assert fmt.stdout == src


def test_zsh_array_operator_enums_roundtrip(run_shfmt):
    """zsh's :#, :| and :* parameter operators round-trip through JSON."""
    # CATCHES: these zsh-only operators reuse the colon prefix but are
    # separate enum values from the :- family and from each other.
    src = "echo ${a:#pat} ${a:|b} ${a:*b}\n"
    fmt, back = roundtrip(run_shfmt, "-ln=zsh", src)
    assert back.stdout == src
    assert fmt.stdout == src


def test_array_literal_assign_enum_roundtrip(run_shfmt):
    """The `=(` assign operator carries an array literal through JSON."""
    # CATCHES: an array value uses a different AssignOperator than plain =,
    # and the element words come back with their original spacing.
    src = "a=(1 2 3)\n"
    fmt, back = roundtrip(run_shfmt, "-ln=bash", src)
    assert back.stdout == src
    assert fmt.stdout == src


def test_arith_binary_operator_zoo_roundtrip(run_shfmt):
    """Every remaining binary arithmetic operator decodes and reprints."""
    # CATCHES: % == != < > <= >= << >> & | ^ && || ^^ and the compound
    # assigns -= *= /= %= &= |= ^= <<= >>= are each one enum value, so a
    # single wrong mapping in either direction shows up as a diff.
    srcs = [
        "r=$((a % b == c != d < e > f <= g >= h))\n",
        "r=$((a << b >> c & d | e ^ f && g || h ^^ i))\n",
        "r=$((a += b -= c *= d /= e %= f))\n",
        "r=$((a &= b |= c ^= d <<= e >>= f))\n",
    ]
    for src in srcs:
        fmt, back = roundtrip(run_shfmt, "-ln=bash", src)
        assert back.stdout == src, src
        assert fmt.stdout == src, src


@pytest.mark.parametrize("op", ["**=", "&&=", "||=", "^^="])
def test_json_only_compound_assign_ops(run_shfmt, op):
    """**=, &&=, ||= and ^^= decode from JSON though the lexer rejects them."""
    # CATCHES: these four compound assigns exist only as enum values in the
    # JSON wire format; decoding must accept the spelling and print it.
    tree = run_shfmt(["--to-json"], "r=$((a += b))\n")
    assert tree.returncode == 0
    patched = tree.stdout.replace('"Op": "+="', '"Op": "%s"' % op)
    res = run_shfmt(["--from-json"], patched)
    assert res.returncode == 0, op
    assert res.stdout == "r=$((a %s b))\n" % op
    assert res.stderr == ""


def test_test_operator_zoo_roundtrip(run_shfmt):
    """The [[ ]] unary and binary vocabularies round-trip through JSON."""
    # CATCHES: every UnTestOperator and BinTestOperator spelling (including
    # -nt/-ot/-ef and bare =) must map to its enum and back to the same
    # text; a missing entry would decode to the zero operator.
    srcs = [
        "[[ -e a || -d b ]]\n",
        "[[ a -nt b || c -ot d || e -ef f ]]\n",
        "[[ a = b || c != d || e < f || g > h ]]\n",
        "[[ a -eq b || c -ne d || e -le f || g -ge h || i -lt j || k -gt l ]]\n",
    ]
    for src in srcs:
        fmt, back = roundtrip(run_shfmt, "-ln=bash", src)
        assert back.stdout == src, src
        assert fmt.stdout == src, src


def test_decode_type_mismatch_errors(run_shfmt):
    """Wrong JSON value kinds report the JSON type and the Go field type."""
    # CATCHES: the decoder names the JSON kind (boolean/number/array) and
    # the destination Go type, and an object without "Type" names the
    # interface it could not construct.
    cases = [
        ('{"Type":"File","Stmts":[{"Cmd":{"Type":"CallExpr","Args":true}}]}',
         "cannot decode JSON boolean into []*syntax.Word\n"),
        ('{"Type":"File","Stmts":[{"Cmd":{"Type":"CallExpr","Args":[{"Parts":true}]}}]}',
         "cannot decode JSON boolean into []syntax.WordPart\n"),
        ('{"Type":"File","Stmts":[{"Cmd":{"Type":"CallExpr","Args":'
         '[{"Parts":[{"Type":"Lit","Value":1}]}]}}]}',
         "cannot decode JSON number into string\n"),
        ('{"Type":"File","Stmts":[{"Cmd":{"Type":"CallExpr","Args":'
         '[{"Parts":[{"Type":"Lit","Value":[]}]}]}}]}',
         "cannot decode JSON array into string\n"),
        ('{"Type":"File","Stmts":[{"Cmd":{"Type":"CallExpr","Args":'
         '[{"Parts":[{}]}]}}]}',
         'missing "Type" to decode a JSON object into syntax.WordPart\n'),
        ('{"Type":"File","Stmts":true}',
         "cannot decode JSON boolean into []*syntax.Stmt\n"),
        ('{"Type":"File","Stmts":[true]}',
         "cannot decode JSON boolean into *syntax.Stmt\n"),
        ('{"Type":"File","Stmts":[{"Cmd":{"Type":"CallExpr","Args":'
         '[{"Parts":[{"Type":"Lit","Value":{}}]}]}}]}',
         "cannot decode JSON object into string\n"),
        ('{"Type":"File","Stmts":{}}',
         "cannot decode JSON object into []*syntax.Stmt\n"),
    ]
    for payload, err in cases:
        res = run_shfmt(["--from-json"], payload)
        assert res.returncode == 1, payload
        assert res.stdout == "", payload
        assert res.stderr == err, payload


def test_null_literal_decodes_to_empty_word(run_shfmt):
    """A JSON null for a string field is accepted and yields an empty literal."""
    # CATCHES: null leaves the destination at its zero value instead of
    # erroring, so the word prints as an empty string and the program is
    # still formatted successfully.
    payload = ('{"Type":"File","Stmts":[{"Cmd":{"Type":"CallExpr","Args":'
               '[{"Parts":[{"Type":"Lit","Value":null}]}]}}]}')
    res = run_shfmt(["--from-json"], payload)
    assert res.returncode == 0
    assert res.stdout == "\n"
    assert res.stderr == ""
