"""Simplification (-s) tails for subshells, tests and quoting.

The remaining -s rewrites: inlining a subshell inside a command
substitution (plain and negated forms inline, decorated ones keep their
parens), unquoting a parameter only on the correct side of a comparison,
flipping a negated comparison's operator while dropping the `!`,
unwrapping a parenthesised unary test, and the quoting rewrites for an
escaped dollar against an escaped newline.
"""


def test_inline_subshell_in_command_substitution(run_shfmt):
    """$( (cmd) ) loses its inner parens unless the subshell is decorated."""
    # CATCHES: a plain and a negated subshell inside $( ) are inlined,
    # while a subshell carrying a redirect or a trailing `&` keeps its
    # parentheses because the decoration cannot live on the bare command.
    res = run_shfmt(["-s", "-"], "x=$( (cat < f) )")
    assert res.returncode == 0
    assert res.stdout == "x=$(cat <f)\n"
    assert res.stderr == ""

    res = run_shfmt(["-s", "-"], "x=$( (a) & )")
    assert res.returncode == 0
    assert res.stdout == "x=$( (a) &)\n"
    assert res.stderr == ""

    res = run_shfmt(["-s", "-"], "x=$( (! a) )")
    assert res.returncode == 0
    assert res.stdout == "x=$(! a)\n"
    assert res.stderr == ""


def test_unquote_params_respects_position(run_shfmt):
    """-s unquotes a parameter only when it starts the comparison."""
    # CATCHES: "$b" is unquoted when it stands first, but in the mirrored
    # comparison the literal side "a" is never touched, so the whole
    # comparison is left as written.
    res = run_shfmt(["-s", "-"], '[[ "$b" == a ]]')
    assert res.returncode == 0
    assert res.stdout == "[[ $b == a ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-s", "-"], '[[ "a" == "$b" ]]')
    assert res.returncode == 0
    assert res.stdout == '[[ "a" == "$b" ]]\n'
    assert res.stderr == ""


def test_negated_test_flips_operator(run_shfmt):
    """-s drops the `!` from a test and flips its comparison operator."""
    # CATCHES: `! a != b` becomes `a == b` and `! a == b` becomes
    # `a != b`, so the negation never survives as a word of its own.
    res = run_shfmt(["-s", "-"], "[[ ! a != b ]]")
    assert res.returncode == 0
    assert res.stdout == "[[ a == b ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-s", "-"], "[[ ! a == b ]]")
    assert res.returncode == 0
    assert res.stdout == "[[ a != b ]]\n"
    assert res.stderr == ""


def test_parenthesised_unary_test_unwrapped(run_shfmt):
    """-s removes the redundant parens around a single unary test."""
    # CATCHES: `( -n x )` is one test in parentheses, so both the parens
    # and their padding spaces disappear together.
    res = run_shfmt(["-s", "-"], "[[ ( -n x ) ]]")
    assert res.returncode == 0
    assert res.stdout == "[[ -n x ]]\n"
    assert res.stderr == ""


def test_unary_minus_index_kept(run_shfmt):
    """An array index holding a unary minus is left alone by -s."""
    # CATCHES: `x[-i]` inside the index keeps the unary spelling and the
    # assign round-trips byte for byte, since index simplification only
    # touches plain additions.
    res = run_shfmt(["-s", "-"], "a[x[-i]]=v")
    assert res.returncode == 0
    assert res.stdout == "a[x[-i]]=v\n"
    assert res.stderr == ""


def test_escaped_newline_literal_kept(run_shfmt):
    """A backslash-n pair inside double quotes is not re-quoted."""
    # CATCHES: `"a\nb"` holds the two characters backslash and n, not a
    # real newline, so -s cannot fold it into single quotes and the word
    # is printed exactly as it was read.
    res = run_shfmt(["-s", "-"], 'echo "a\\nb"')
    assert res.returncode == 0
    assert res.stdout == 'echo "a\\nb"\n'
    assert res.stderr == ""


def test_escaped_dollar_requoted(run_shfmt):
    """An escaped dollar inside double quotes moves to single quotes."""
    # CATCHES: "\$foo" needs no backslash once single-quoted, so -s
    # rewrites the whole quoting style to '$foo'.
    res = run_shfmt(["-s", "-"], 'echo "\\$foo"')
    assert res.returncode == 0
    assert res.stdout == "echo '$foo'\n"
    assert res.stderr == ""
