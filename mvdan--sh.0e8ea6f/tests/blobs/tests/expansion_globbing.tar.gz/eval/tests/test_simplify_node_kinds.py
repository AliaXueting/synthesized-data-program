"""Simplify (-s) across statement kinds the suite never simplified before.

The simplifier walks the whole syntax tree, so every statement and word kind
has a -s path: pipelines, subshells, loops, declare/let/time/coproc clauses,
extglob and process substitution, ${var/pat/repl} words and comments attached
to statements, case items and array elements.  These tests pin how each of
those survives -- or is rewritten by -- simplification.
"""


def test_simplify_pipeline_and_subshell(run_shfmt):
    """Pipelines and subshells round-trip unchanged through -s."""
    # CATCHES: -s walks BinaryCmd and Subshell nodes without altering them;
    # a simplifier that rewrote or dropped the pipeline nesting would show.
    res = run_shfmt(["-s"], "a | b\n")
    assert res.returncode == 0
    assert res.stdout == "a | b\n"
    assert res.stderr == ""

    res = run_shfmt(["-s"], "(a | b)\n")
    assert res.returncode == 0
    assert res.stdout == "(a | b)\n"


def test_simplify_loop_forms(run_shfmt):
    """while, word-list for and C-style for loops pass -s untouched."""
    # CATCHES: WhileClause, ForClause/WordIter and CStyleLoop are walked but
    # not rewritten; the C-style header keeps its operator spacing as parsed.
    res = run_shfmt(["-s"], "while a; do b; done\n")
    assert res.returncode == 0
    assert res.stdout == "while a; do b; done\n"

    res = run_shfmt(["-s"], "for x in a b; do b; done\n")
    assert res.returncode == 0
    assert res.stdout == "for x in a b; do b; done\n"

    res = run_shfmt(["-s"], "for ((i = 0; i < 3; i++)); do b; done\n")
    assert res.returncode == 0
    assert res.stdout == "for ((i = 0; i < 3; i++)); do b; done\n"


def test_simplify_declare_let_time_coproc(run_shfmt):
    """declare, let, time and coproc clauses survive -s verbatim."""
    # CATCHES: DeclClause, LetClause, TimeClause and CoprocClause are walked
    # for simplification opportunities but printed back identically here.
    for src in ("declare x=1\n", "let x=1\n", "time (ls)\n",
                "coproc foo { echo; }\n"):
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0
        assert res.stdout == src
        assert res.stderr == ""


def test_simplify_extglob_and_procsubst(run_shfmt):
    """Extended globs and process substitutions stay intact under -s."""
    # CATCHES: -s descends into ExtGlob patterns and ProcSubst statements;
    # neither the @(...) pattern word nor the <(ls) substitution may change.
    res = run_shfmt(["-s", "-ln=bash", "-"], "echo @(a)\n")
    assert res.returncode == 0
    assert res.stdout == "echo @(a)\n"
    assert res.stderr == ""

    res = run_shfmt(["-s", "-ln=bash", "-"], "cat <(ls)\n")
    assert res.returncode == 0
    assert res.stdout == "cat <(ls)\n"


def test_simplify_replacement_and_unary_minus(run_shfmt):
    """${var/pat/repl} is kept and unary minus loses its padding under -s."""
    # CATCHES: the replacement word of ${x/a/b} is walked but preserved,
    # while the unary minus in $(( -x )) is re-spaced to $((-x)) -- the
    # simplifier only rewrites arithmetic padding, not parameter operators.
    res = run_shfmt(["-s"], "echo ${x/a/b} ${y%pat}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${x/a/b} ${y%pat}\n"
    assert res.stderr == ""

    res = run_shfmt(["-s"], "echo $(( -x ))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((-x))\n"


def test_simplify_statement_comments(run_shfmt):
    """Comments trailing or leading a statement survive -s in place."""
    # CATCHES: -s walks each statement's comment list; the trailing comment
    # stays on the echo line and the leading comment stays above it.
    res = run_shfmt(["-s"], "a # c\nb\n")
    assert res.returncode == 0
    assert res.stdout == "a # c\nb\n"
    assert res.stderr == ""

    res = run_shfmt(["-s"], "# c\na\n")
    assert res.returncode == 0
    assert res.stdout == "# c\na\n"


def test_simplify_comments_in_case_and_array(run_shfmt):
    """Comments inside case items and array elements keep their layout."""
    # CATCHES: a comment before a case-item body forces the item terminator
    # onto its own indented line, and an array element keeps its trailing
    # comment -- both survive the simplify walk byte for byte.
    res = run_shfmt(["-s"], "case $x in\na) # c\n  b;;\nesac\n")
    assert res.returncode == 0
    assert res.stdout == "case $x in\na) # c\n\tb\n\t;;\nesac\n"
    assert res.stderr == ""

    res = run_shfmt(["-s"], "a=(\n\t[1]=x # c\n)\n")
    assert res.returncode == 0
    assert res.stdout == "a=(\n\t[1]=x # c\n)\n"


def test_simplify_trailing_comment_after_block(run_shfmt):
    """A done-level trailing comment keeps the loop body indented."""
    # CATCHES: the comment after `done` belongs to the WhileClause's last
    # statements; -s keeps it on the done line rather than moving it inside.
    res = run_shfmt(["-s"], "while a; do b\ndone # c\n")
    assert res.returncode == 0
    assert res.stdout == "while a; do\n\tb\ndone # c\n"
    assert res.stderr == ""


def test_simplify_mixed_script(run_shfmt):
    """A script mixing the new kinds simplifies without any change."""
    # CATCHES: walking declare, let, time, process substitution, pipes and
    # extglob in one file must not trigger any spurious simplification.
    src = "declare -a x=(1 2)\nlet y=1\ntime (ls)\ncat <(ls) | grep x @(a)\n"
    res = run_shfmt(["-s"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""
