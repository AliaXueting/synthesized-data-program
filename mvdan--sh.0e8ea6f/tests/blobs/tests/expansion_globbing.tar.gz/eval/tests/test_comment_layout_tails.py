"""Comment placement in bodies that hold nothing else.

Comment-only case bodies and array literals, comments before the first
statement of a block, blank lines kept before comments, keepPadding of
padded comments, minify keeping only the shebang, and a semicolon kept on
its own line after a line continuation.
"""


def test_comment_only_case_body(run_shfmt):
    """A case with no items keeps a comment between case and esac."""
    # CATCHES: the comment is legal content of the empty item list and
    # prints at column zero, not indented as if inside an item.
    res = run_shfmt(["-"], "case $x in\n# c\nesac\n")
    assert res.returncode == 0
    assert res.stdout == "case $x in\n# c\nesac\n"
    assert res.stderr == ""


def test_comment_before_first_case_item(run_shfmt):
    """A comment before the first pattern moves above it, unindented."""
    # CATCHES: the comment originally inside the first item is re-attached
    # before the `foo)` pattern at column zero, and the item's body keeps
    # the ` ;;` spacing.
    res = run_shfmt(["-"], "case $x in\n\t# c\n\tfoo) bar;;\nesac\n")
    assert res.returncode == 0
    assert res.stdout == "case $x in\n# c\nfoo) bar ;;\nesac\n"
    assert res.stderr == ""


def test_comment_only_array_body(run_shfmt):
    """An array literal may hold only a comment."""
    # CATCHES: a=(\n# c\n) is a valid empty array with a trailing comment;
    # the comment is indented one level inside the parentheses.
    res = run_shfmt(["-"], "a=(\n# c\n)\n")
    assert res.returncode == 0
    assert res.stdout == "a=(\n\t# c\n)\n"
    assert res.stderr == ""


def test_blank_line_before_comment(run_shfmt):
    """A blank line separating a statement from a comment is preserved."""
    # CATCHES: the printer emits two newlines when the comment's line is
    # more than one past the previous statement's line.
    res = run_shfmt(["-"], "a\n\n# c\nb\n")
    assert res.returncode == 0
    assert res.stdout == "a\n\n# c\nb\n"
    assert res.stderr == ""


def test_keep_padding_before_comment(run_shfmt):
    """-kp preserves original column padding before a trailing comment."""
    # CATCHES: the four spaces between the word and the comment survive
    # because keepPadding aligns to the comment's source column.
    res = run_shfmt(["-kp"], "a    # long padding comment\n")
    assert res.returncode == 0
    assert res.stdout == "a    # long padding comment\n"
    assert res.stderr == ""


def test_minify_keeps_only_shebang_comments(run_shfmt):
    """-mn drops trailing comments but keeps the shebang line intact."""
    # CATCHES: minify deletes ordinary comments yet writes the shebang
    # comment verbatim (with its own newline) before the minimised body.
    res = run_shfmt(["-mn", "-ln=bash", "-"], "#!/bin/bash\necho hi # c\n")
    assert res.returncode == 0
    assert res.stdout == "#!/bin/bash\necho hi\n"
    assert res.stderr == ""


def test_semicolon_after_continuation_keeps_line(run_shfmt):
    """A semicolon reached via backslash-newline prints indented alone."""
    # CATCHES: the statement's semicolon sits on a later source line than
    # the command, so the printer writes it after a continuation backslash
    # on its own indented line rather than appending it to `a`.
    res = run_shfmt(["-"], "a \\\n; b\n")
    assert res.returncode == 0
    assert res.stdout == "a \\\n\t;\nb\n"
    assert res.stderr == ""


def test_comment_before_first_block_statement(run_shfmt):
    """A comment leading a then-block indents with the statement."""
    # CATCHES: the comment belongs to the block's statement list, so it is
    # printed inside the block at the body's indentation level.
    res = run_shfmt(["-"], "if a; then\n# c\nb\nfi\n")
    assert res.returncode == 0
    assert res.stdout == "if a; then\n\t# c\n\tb\nfi\n"
    assert res.stderr == ""


def test_then_requires_statement_list(run_shfmt):
    """A then-block holding only a comment is not a statement list."""
    # CATCHES: comments do not count as statements, so `if a; then` followed
    # by just a comment errors at the then position with its own wording.
    res = run_shfmt(["-"], "if a; then\n# c\nfi\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:7: `then` must be followed by a statement list\n"
    )
