"""The full [[ ]] test-operator vocabulary.

Unary operators (-e through -R) and the binary operators the earlier files
did not pin (=, -le, -nt, -ot, -ef), including the two alias spellings that
normalise, plus the exact diagnostics for words that are not operators.
"""


def test_unary_operator_vocabulary(run_shfmt):
    """Every unary [[ ]] operator round-trips with its exact spelling."""
    # CATCHES: each operator string is a separate lexer token; a missing or
    # misspelled entry would leave the word as a plain literal or error out.
    keep = [
        "!", "-e", "-f", "-d", "-c", "-b", "-p", "-S", "-L", "-k", "-g",
        "-u", "-G", "-O", "-N", "-r", "-w", "-x", "-s", "-t", "-z", "-n",
        "-o", "-v", "-R",
    ]
    for op in keep:
        src = "[[ %s arg ]]\n" % op
        res = run_shfmt(["-"], src)
        assert res.returncode == 0, op
        assert res.stdout == src, op
        assert res.stderr == "", op


def test_unary_operator_aliases_normalise(run_shfmt):
    """-a prints back as -e and -h prints back as -L."""
    # CATCHES: -a and -e (also -h and -L) share one operator enum value, so
    # the printer always emits the canonical first spelling of the pair.
    res = run_shfmt(["-"], "[[ -a arg ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ -e arg ]]\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "[[ -h arg ]]\n")
    assert res.returncode == 0
    assert res.stdout == "[[ -L arg ]]\n"
    assert res.stderr == ""


def test_binary_operator_vocabulary_additions(run_shfmt):
    """The =, -le, -nt, -ot and -ef binary operators keep their spelling."""
    # CATCHES: bare `=` is the short glob-equality operator (not an assign),
    # and -le must not be confused with -lt or -ge when reprinted.
    cases = [
        ("[[ a = b ]]\n", "[[ a = b ]]\n"),
        ("[[ a -le b ]]\n", "[[ a -le b ]]\n"),
        ("[[ a -nt b ]]\n", "[[ a -nt b ]]\n"),
        ("[[ a -ot b ]]\n", "[[ a -ot b ]]\n"),
        ("[[ a -ef b ]]\n", "[[ a -ef b ]]\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_invalid_test_operator_errors(run_shfmt):
    """Non-operator words report their position and spelling verbatim."""
    # CATCHES: the error names the offending word in backquotes; in the unary
    # slot the message points at the operand that followed the bad word, and
    # in the binary slot it points at the bad operator itself.
    cases = [
        ("[[ -q foo ]]\n",
         "<standard input>:1:7: not a valid test operator: `foo`\n"),
        ("[[ foo -q bar ]]\n",
         "<standard input>:1:8: not a valid test operator: `-q`\n"),
        ("[[ = foo ]]\n",
         "<standard input>:1:6: not a valid test operator: `foo`\n"),
        ("[[ -eq foo ]]\n",
         "<standard input>:1:8: not a valid test operator: `foo`\n"),
    ]
    for src, err in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == err, src
