"""Typed-JSON operator spellings that only the decoder exercises.

--from-json accepts operator values that the source parser never produces:
the zsh procsubst `=(`, the unary arithmetic `+` and `-`, and it rejects
unknown spellings by naming the enum type.  A position object with the
right field count but a wrong field name is reported per-field.
"""

import json

import pytest


def _find_node(obj, type_name):
    """Depth-first search for the first typed-JSON node of a given type."""
    if isinstance(obj, dict):
        if obj.get("Type") == type_name:
            return obj
        for value in obj.values():
            found = _find_node(value, type_name)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = _find_node(value, type_name)
            if found is not None:
                return found
    return None


def _encoded(run_shfmt, args, src):
    """Return the parsed --to-json tree of src."""
    res = run_shfmt(args + ["--to-json", "-"], src)
    assert res.returncode == 0, src
    assert res.stderr == "", src
    return json.loads(res.stdout)


def test_procsubst_temp_decodes(run_shfmt):
    """The zsh `=(` procsubst spelling decodes and prints back."""
    # CATCHES: "=(" is a procsubst operator value of its own, so decoding
    # the tree must reprint `echo =(ls)` and not the bash `<(` spelling.
    tree = _encoded(run_shfmt, ["--ln=zsh"], "echo =(ls)")
    proc = _find_node(tree, "ProcSubst")
    assert proc is not None
    assert proc["Op"] == "=("
    res = run_shfmt(["--from-json"], json.dumps(tree))
    assert res.returncode == 0
    assert res.stdout == "echo =(ls)\n"
    assert res.stderr == ""


@pytest.mark.parametrize("op", ["+", "-"])
def test_unary_arithm_decode_only_ops(run_shfmt, op):
    """UnaryArithm accepts the + and - spellings that parsing never makes."""
    # CATCHES: $((+x)) and $((-x)) with no space cannot come from the
    # source parser, but the decoder accepts them and prints them glued.
    tree = _encoded(run_shfmt, [], "echo $((! x))")
    unary = _find_node(tree, "UnaryArithm")
    assert unary is not None
    assert unary["Op"] == "!"
    unary["Op"] = op
    res = run_shfmt(["--from-json"], json.dumps(tree))
    assert res.returncode == 0, op
    assert res.stdout == f"echo $(({op}x))\n", op
    assert res.stderr == "", op


def test_unknown_binary_test_operator(run_shfmt):
    """A BinaryTest Op outside the vocabulary is rejected by name."""
    # CATCHES: the decoder reports the enum type and the offending
    # spelling in Go's %q quoting, before any printing is attempted.
    tree = _encoded(run_shfmt, [], "[[ a == b ]]")
    binary = _find_node(tree, "BinaryTest")
    assert binary is not None
    assert binary["Op"] == "=="
    binary["Op"] = "zz"
    res = run_shfmt(["--from-json"], json.dumps(tree))
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid BinTestOperator: "zz"\n'


def test_unknown_paramexp_operator(run_shfmt):
    """A ParamExp Exp op outside the vocabulary is rejected by name."""
    # CATCHES: the Exp object of a parameter expansion carries its own
    # operator enum, and an unknown spelling names ParExpOperator in the
    # error while nothing is printed to stdout.
    tree = _encoded(run_shfmt, [], "echo ${x^}")
    param = _find_node(tree, "ParamExp")
    assert param is not None
    assert param["Exp"]["Op"] == "^"
    param["Exp"]["Op"] = "@@"
    res = run_shfmt(["--from-json"], json.dumps(tree))
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid ParExpOperator: "@@"\n'


def test_position_missing_field_named(run_shfmt):
    """A three-field position with a wrong name reports the missing field."""
    # CATCHES: the field count passes the length check, so the decoder
    # names the exact missing field "Col" instead of listing the whole
    # allowed field set.
    tree = _encoded(run_shfmt, [], "echo hi")
    lit = _find_node(tree, "Lit")
    assert lit is not None
    assert lit["Value"] == "echo"
    lit["ValuePos"] = {"Offset": 0, "Line": 1, "Foo": 2}
    res = run_shfmt(["--from-json"], json.dumps(tree))
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'a position must contain the field "Col"\n'
