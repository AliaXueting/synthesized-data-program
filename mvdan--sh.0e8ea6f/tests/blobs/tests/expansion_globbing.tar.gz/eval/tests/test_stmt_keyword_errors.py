"""Statement-start keyword handling and exotic statement forms.

Keywords that may only close a construct produce a dedicated diagnostic when
they start a statement; backquote statements normalise to $(...); zsh treats
() as an anonymous function declaration; and mksh's |& coprocess pipe prints
on a line of its own.
"""

import pytest


@pytest.mark.parametrize(
    "src, column, message",
    [
        ("then echo\n", 1, "`then` can only be used in an `if`"),
        ("fi\n", 1, "`fi` can only be used to end an `if`"),
        ("do echo\n", 1, "`do` can only be used in a loop"),
        ("done\n", 1, "`done` can only be used to end a loop"),
        ("esac\n", 1, "`esac` can only be used to end a `case`"),
    ],
)
def test_reserved_words_cannot_start_statements(run_shfmt, src, column, message):
    """Closing keywords at statement start each give their own error."""
    # CATCHES: each closing keyword has a distinct diagnostic naming both the
    # keyword and the construct it terminates, reported at the keyword.
    res = run_shfmt(["-"], src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        f"<standard input>:1:{column}: {message}\n"
    )


def test_closing_brace_after_statement(run_shfmt):
    """A lone } after a statement is reported as an unclosed block."""
    # CATCHES: the column points at the brace and the wording names the
    # block, not a generic "unexpected token" error.
    res = run_shfmt(["-"], "echo hi; }\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:10: `}` can only be used to close a block\n"


def test_double_negation_rejected(run_shfmt):
    """Two consecutive ! words cannot both negate a statement."""
    # CATCHES: the second ! is an error, not a double negation or a literal.
    res = run_shfmt(["-"], "! ! true\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:1: cannot negate a command multiple times\n"


def test_backquote_statement_normalises(run_shfmt):
    """A statement that IS a backquote command substitution prints as $(...)."""
    # CATCHES: the command name may be a legacy backquote substitution; the
    # printer rewrites it to the modern $(...) spelling as the whole command.
    res = run_shfmt(["-"], "`echo hi`\n")
    assert res.returncode == 0
    assert res.stdout == "$(echo hi)\n"
    assert res.stderr == ""


def test_zsh_anonymous_function_and_empty_parens(run_shfmt):
    """zsh () introduces an anonymous function; a bare () needs a body."""
    # CATCHES: () { echo } is formatted as a one-line function whose name is
    # the empty parens, while () alone demands a statement like foo() does.
    res = run_shfmt(["-ln=zsh", "-"], "() { echo }\n")
    assert res.returncode == 0
    assert res.stdout == "() { echo; }\n"
    assert res.stderr == ""

    res = run_shfmt(["-ln=zsh", "-"], "()\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:1: `foo()` must be followed by a statement\n"


def test_paren_after_substituted_word_is_not_a_func(run_shfmt):
    """A function name containing $() is rejected at the word's position."""
    # CATCHES: foo$(echo x)() looks like a function declaration but the name
    # holds a substitution, so the parser reports "invalid func name" at 1:1.
    res = run_shfmt(["-"], "foo$(echo x)()\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:1: invalid func name\n"


def test_mksh_coprocess_pipe_layout(run_shfmt):
    """mksh's |& coprocess keeps the operator then breaks the line."""
    # CATCHES: |& is a statement coprocess operator in mksh (not bash's
    # stderr pipe), so the printer writes it right after the left command
    # and starts the right command on the next line at column zero.
    res = run_shfmt(["-ln=mksh", "-"], "ls |& tr a b\n")
    assert res.returncode == 0
    assert res.stdout == "ls |&\ntr a b\n"
    assert res.stderr == ""


def test_multiline_subshell_keeps_paren_gap(run_shfmt):
    """A subshell whose ( is on an earlier line than its body stays split."""
    # CATCHES: to avoid ambiguity with ((, the printer keeps a space after
    # the opening paren when the first inner statement starts on another
    # line -- here the inner (ls) is printed on its own indented line.
    res = run_shfmt(["-"], "(\n(ls)\n)\n")
    assert res.returncode == 0
    assert res.stdout == "(\n\t(ls)\n)\n"
    assert res.stderr == ""
