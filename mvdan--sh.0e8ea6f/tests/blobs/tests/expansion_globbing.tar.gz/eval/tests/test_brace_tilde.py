"""Brace expansion and tilde expansion as seen through the formatter.

Braces and tildes are expanded at run time, never at parse time, so the
formatter must pass them through untouched.  These tests pin that pass-through
behaviour (and the fact that both are plain literals in the syntax tree).
"""

import json

BRACE_SNIPPETS = [
    "{a,b}",
    "a{b,c}d",
    "{1..5}",
    "{a..z}",
    "{z..a}",
    "{5..1}",
    "{01..03}",
    "{001..003}",
    "{-1..1}",
    "{1..5..2}",
    "{a..z..2}",
    "{a,b{c,d}}",
    "{a}",
    "{,}",
    "{ }",
    "$x{a,b}",
    "{a,b}$x",
]

TILDE_SNIPPETS = ["~", "~/bin", "~user", "~root/src", "~+", "~-", "~1"]


def test_brace_forms_pass_through_untouched(run_shfmt):
    """Alternations, sequences and nested braces are never expanded."""
    # CATCHES: brace expansion is a run-time step; a re-implementation that
    # expands {a,b} or {1..5} while formatting would produce different bytes.
    for snippet in BRACE_SNIPPETS:
        res = run_shfmt([], "echo %s\n" % snippet)
        assert res.returncode == 0, snippet
        assert res.stdout == "echo %s\n" % snippet, snippet
        assert res.stderr == "", snippet


def test_braces_inside_quotes_stay_literal(run_shfmt):
    """Quoted braces are already literal and are printed with their quotes."""
    # CATCHES: the double quotes around {a,b} must survive, since removing
    # them would turn a literal brace word into an expandable one.
    res = run_shfmt([], 'echo "{a,b}"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "{a,b}"\n'
    assert res.stderr == ""


def test_brace_is_a_plain_literal_in_the_tree(run_shfmt):
    """--to-json shows {a,b} as one Lit, with no brace node at all."""
    # CATCHES: the syntax tree has no brace-expansion node type, so {a,b} must
    # arrive at the printer as a single literal token of value "{a,b}".
    res = run_shfmt(["--to-json"], "echo {a,b}\n")
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    parts = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"]
    assert len(parts) == 1
    assert parts[0]["Type"] == "Lit"
    assert parts[0]["Value"] == "{a,b}"


def test_tilde_forms_pass_through_untouched(run_shfmt):
    """Bare, user, PWD and DIRSTACK tildes are printed exactly as typed."""
    # CATCHES: tilde expansion needs a password database at run time; the
    # formatter must not resolve ~user, drop it, or rewrite it to $HOME.
    for snippet in TILDE_SNIPPETS:
        res = run_shfmt([], "echo %s\n" % snippet)
        assert res.returncode == 0, snippet
        assert res.stdout == "echo %s\n" % snippet, snippet
        assert res.stderr == "", snippet


def test_tilde_is_literal_when_quoted_or_midword(run_shfmt):
    """A tilde that cannot start an expansion is left completely alone."""
    # CATCHES: quoting suppresses tilde expansion and a~b never starts one, so
    # both must round-trip byte-for-byte including the quote characters.
    for snippet in ['echo "~"', 'echo "~/"', "echo a~b", 'echo "a"~"b"']:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet
        assert res.stderr == "", snippet


def test_tilde_is_a_plain_literal_in_the_tree(run_shfmt):
    """--to-json shows a leading ~ as one Lit, with no tilde node."""
    # CATCHES: like braces, tildes have no AST node of their own, so the tree
    # for `echo ~` contains exactly one literal part whose value is "~".
    res = run_shfmt(["--to-json"], "echo ~\n")
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    parts = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"]
    assert len(parts) == 1
    assert parts[0]["Type"] == "Lit"
    assert parts[0]["Value"] == "~"


def test_tilde_after_expansion_word(run_shfmt):
    """A tilde inside a parameter-expansion word is not an expansion start."""
    # CATCHES: the ~ in ${x:-~} is part of the expansion's word and must be
    # kept there rather than hoisted out into a tilde-prefix.
    res = run_shfmt([], "echo ${x:-~}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${x:-~}\n"
    assert res.stderr == ""


def test_braces_and_tilde_survive_minify(run_shfmt):
    """--minify leaves brace and tilde text intact even while shortening."""
    # CATCHES: minify shortens ${var} but must not touch the brace sequence or
    # the tilde, since neither is a parameter expansion.
    res = run_shfmt(["-mn"], "echo ${var} {1..5} ~/bin\n")
    assert res.returncode == 0
    assert res.stdout == "echo $var {1..5} ~/bin\n"
    assert res.stderr == ""
