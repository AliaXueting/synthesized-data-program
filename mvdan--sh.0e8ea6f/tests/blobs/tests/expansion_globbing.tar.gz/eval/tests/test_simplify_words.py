"""--simplify rewrites of words: quoting, tests, subshells and indices.

``-s`` is where the formatter applies shell *semantics* to words: it removes
quotes that cannot change the outcome, inlines parameters inside arithmetic,
and preserves the ones that would (associative-array keys, glob patterns).
"""


def test_simplify_prefers_single_quotes_for_escapes(run_shfmt):
    """--simplify rewrites "…\\$x…" literals to the shorter single-quoted form."""
    # CATCHES: the escape \\$ inside double quotes is equivalent to a literal
    # in single quotes, but only when the literal contains no apostrophe.
    cases = [
        # Escaping a $ inside double quotes is pointless: single quotes are shorter.
        ('echo "\\$foo"\n', "echo '$foo'\n"),
        ('echo "a\\$b"\n', "echo 'a$b'\n"),
        # An apostrophe inside the literal blocks the swap to single quotes.
        ('echo "a\'b"\n', 'echo "a\'b"\n'),
    ]
    for src, expected in cases:
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_simplify_unquotes_lhs_of_tests(run_shfmt):
    """Double quotes around a lone parameter in [[ ]] are dropped."""
    # CATCHES: unquoting $var inside [[ ]] is safe because no word splitting
    # happens there, but the right-hand operand keeps its quotes.
    cases = [
        ('[[ "$var" == str ]]\n', "[[ $var == str ]]\n"),
        ('[[ -n "$var" ]]\n', "[[ -n $var ]]\n"),
        ('[[ -z "$var" ]]\n', "[[ -z $var ]]\n"),
        ('[[ -f "$var" ]]\n', "[[ -f $var ]]\n"),
        ('[[ ! "$var" ]]\n', "[[ ! $var ]]\n"),
        ('[[ "$var" == "$other" ]]\n', '[[ $var == "$other" ]]\n'),
    ]
    for src, expected in cases:
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_simplify_keeps_quotes_on_pattern_side(run_shfmt):
    """Quoting the RHS of == is preserved because it disables globbing."""
    # CATCHES: unquoting enables globbing, so "a*" must stay quoted even
    # though the same construct on the left-hand side is unquoted.
    res = run_shfmt(["-s"], '[[ "$var" == "a*" ]]\n')
    assert res.returncode == 0
    assert res.stdout == "[[ $var == \"a*\" ]]\n"
    assert res.stderr == ""


def test_simplify_unquotes_both_sides_of_numeric_test(run_shfmt):
    """For -eq the RHS is unquoted too, since it cannot glob."""
    # CATCHES: only the string match operators keep the right-hand quotes;
    # the numeric comparison unquotes both operands.
    res = run_shfmt(["-s"], '[[ "$var" -eq "$x" ]]\n')
    assert res.returncode == 0
    assert res.stdout == "[[ $var -eq $x ]]\n"
    assert res.stderr == ""


def test_simplify_merges_negation_with_operators(run_shfmt):
    """! -n becomes -z, ! ! collapses, and ! == flips to !=."""
    # CATCHES: the negation is folded into the operator itself rather than
    # kept as a leading !, which changes the printed but not the real meaning.
    cases = [
        ("[[ ! -n $var ]]\n", "[[ -z $var ]]\n"),
        ("[[ ! -z $var ]]\n", "[[ -n $var ]]\n"),
        ("[[ ! ! $var ]]\n", "[[ $var ]]\n"),
        ('[[ ! "$var" == str ]]\n', "[[ $var != str ]]\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_simplify_removes_parentheses_in_tests(run_shfmt):
    """Redundant parentheses around test operands disappear entirely."""
    # CATCHES: the parens AND the spaces around them go away, producing
    # `[[ ($var == a) || ($var == b) ]]` rather than `( $var == a )`.
    res = run_shfmt(["-s"], '[[ ( "$var" == a ) || ( "$var" == b ) ]]\n')
    assert res.returncode == 0
    assert res.stdout == "[[ ($var == a) || ($var == b) ]]\n"
    assert res.stderr == ""


def test_simplify_expands_short_match_operator(run_shfmt):
    """The legacy single = match operator is rewritten to ==."""
    # CATCHES: = and == mean the same thing in [[ ]], and the canonical
    # spelling is the double one, so the short form is upgraded.
    cases = [
        ("[[ a = b ]]\n", "[[ a == b ]]\n"),
        ('[[ "$a" = "$b" ]]\n', '[[ $a == "$b" ]]\n'),
    ]
    for src, expected in cases:
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_simplify_unquotes_regex_operand_is_kept(run_shfmt):
    """The =~ right-hand side keeps its quotes: unquoting makes a regex."""
    # CATCHES: unquoting the pattern would turn it into a regular expression,
    # so the reference deliberately leaves that operand alone.
    res = run_shfmt(["-s"], '[[ "$var" =~ "re" ]]\n')
    assert res.returncode == 0
    assert res.stdout == '[[ $var =~ "re" ]]\n'
    assert res.stderr == ""


def test_simplify_inlines_redundant_subshell(run_shfmt):
    """A command substitution wrapping only a subshell loses the inner layer."""
    # CATCHES: $( (stmts) ) is equivalent to $(stmts), so the redundant
    # subshell is inlined even when the whole substitution is quoted.
    cases = [
        ("echo $( (echo hi) )\n", "echo $(echo hi)\n"),
        ('echo "$( (echo hi) )"\n', 'echo "$(echo hi)"\n'),
    ]
    for src, expected in cases:
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_simplify_keeps_dollar_in_array_assignment_index(run_shfmt):
    """x[$i]=1 keeps its $ because i may be an associative-array key."""
    # CATCHES: x[$i] and x[i] differ for associative arrays, so the dollar in
    # an assignment index is never inlined even though -s inlines elsewhere.
    res = run_shfmt(["-s"], "x[$i]=1\n")
    assert res.returncode == 0
    assert res.stdout == "x[$i]=1\n"
    assert res.stderr == ""


def test_simplify_keeps_dollar_in_indexed_param_index(run_shfmt):
    """${x[0]} and ${x[*]} keep their form; only ( ) around an index goes."""
    # CATCHES: a parenthesised index is pure arithmetic so the parens vanish,
    # but the ${...} spelling and the $ inside it are preserved.
    res = run_shfmt(["-s"], "a[(x)]=1\n")
    assert res.returncode == 0
    assert res.stdout == "a[x]=1\n"
    assert res.stderr == ""


def test_simplify_inlines_slice_offset_parameter(run_shfmt):
    """A $name slice offset becomes a bare name, unlike an array index."""
    # CATCHES: slice offsets are always arithmetic, so $i may be inlined
    # there even though the same $i must be kept in an index position.
    res = run_shfmt(["-s"], "echo ${arr[@]:$i:2}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${arr[@]:i:2}\n"
    assert res.stderr == ""


def test_simplify_keeps_positional_in_slice(run_shfmt):
    """Positional parameters in arithmetic positions are never inlined."""
    # CATCHES: $1 has no brace-free spelling in arithmetic, so it survives
    # --simplify where a plain name like $i would have been inlined.
    res = run_shfmt(["-s"], "echo ${arr[@]:$1:2}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${arr[@]:$1:2}\n"
    assert res.stderr == ""


def test_minify_shortens_function_body_braces(run_shfmt):
    """--minify also squeezes the spaces around { } in a function body."""
    # CATCHES: -mn implies -s and additionally removes the padding around
    # block braces, so `f() { echo $1; }` becomes `f(){ echo $1;}`.
    res = run_shfmt(["-mn"], "f() { echo $1; }\n")
    assert res.returncode == 0
    assert res.stdout == "f(){ echo $1;}\n"
    assert res.stderr == ""
