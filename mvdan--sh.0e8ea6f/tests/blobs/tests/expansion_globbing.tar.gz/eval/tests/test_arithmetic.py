"""Arithmetic expansion ``$((...))`` and ``((...))`` as seen via the CLI.

The formatter never evaluates arithmetic, but it does re-print it, so the
spacing of every operator, the treatment of parentheses, numeric bases and the
``--simplify`` / ``--minify`` rewrites are all directly observable.
"""

import json

# Every binary operator is printed with one space on each side, except the
# comma operator which only takes a space after itself.  Recorded from the
# reference: ``$((a+b))`` comes back as ``$((a + b))``.
BINARY_OPERATORS = [
    ("+", "a + b"),
    ("-", "a - b"),
    ("*", "a * b"),
    ("/", "a / b"),
    ("%", "a % b"),
    ("**", "a ** b"),
    ("<<", "a << b"),
    (">>", "a >> b"),
    ("&", "a & b"),
    ("|", "a | b"),
    ("^", "a ^ b"),
    ("&&", "a && b"),
    ("||", "a || b"),
    ("<", "a < b"),
    ("<=", "a <= b"),
    (">", "a > b"),
    (">=", "a >= b"),
    ("==", "a == b"),
    ("!=", "a != b"),
    ("=", "a = b"),
    ("+=", "a += b"),
    ("-=", "a -= b"),
    ("*=", "a *= b"),
    ("/=", "a /= b"),
    ("%=", "a %= b"),
    ("<<=", "a <<= b"),
    (">>=", "a >>= b"),
    ("&=", "a &= b"),
    ("|=", "a |= b"),
    ("^=", "a ^= b"),
    (",", "a, b"),
]

UNARY_OPERATORS = [("-", "-a"), ("+", "+a"), ("~", "~a"), ("!", "! a")]


def test_binary_operator_spacing(run_shfmt):
    """Every binary arithmetic operator is re-printed with its own spacing."""
    # CATCHES: the printer inserts exactly one space around all 30 binary
    # operators, but the comma operator gets a space after itself only.
    for op, printed in BINARY_OPERATORS:
        res = run_shfmt([], "echo $((a%sb))\n" % op)
        assert res.returncode == 0, op
        assert res.stdout == "echo $((%s))\n" % printed, op
        assert res.stderr == "", op


def test_unary_operator_spacing(run_shfmt):
    """Unary - + ~ hug their operand, but logical not gains a space."""
    # CATCHES: only the boolean negation operator is printed as `! a`; a
    # uniform rule for all unary operators would produce the wrong bytes.
    for op, printed in UNARY_OPERATORS:
        res = run_shfmt([], "echo $((%sa))\n" % op)
        assert res.returncode == 0, op
        assert res.stdout == "echo $((%s))\n" % printed, op
        assert res.stderr == "", op


def test_increment_decrement_no_padding(run_shfmt):
    """Pre/post increment and decrement are printed without extra spaces."""
    # CATCHES: ++ and -- must not be mistaken for two unary + or - operators,
    # which would insert a space and change the meaning of the expression.
    for expr in ["a++", "a--", "++a", "--a"]:
        res = run_shfmt([], "echo $((%s))\n" % expr)
        assert res.returncode == 0, expr
        assert res.stdout == "echo $((%s))\n" % expr, expr
        assert res.stderr == "", expr


def test_numeric_bases_preserved(run_shfmt):
    """Hex, octal-like and explicit base literals survive untouched."""
    # CATCHES: 0x10, a leading-zero 010 and the 16#ff / 64#@ base prefixes are
    # lexed as single numeric tokens and must not be reformatted or split.
    for literal in ["0x10", "010", "16#ff", "64#@", "1", "0"]:
        res = run_shfmt([], "echo $((%s))\n" % literal)
        assert res.returncode == 0, literal
        assert res.stdout == "echo $((%s))\n" % literal, literal
        assert res.stderr == "", literal


def test_ternary_and_comma_spacing(run_shfmt):
    """The ternary operator gets spaces around ? and : like a binary op."""
    # CATCHES: `$((a?b:c))` must print as `$((a ? b : c))`; a parser that
    # treats `:` as the slice operator would emit something quite different.
    res = run_shfmt([], "echo $((a?b:c))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((a ? b : c))\n"
    assert res.stderr == ""


def test_parenthesised_grouping_preserved(run_shfmt):
    """Meaningful parentheses are kept while inner spacing is normalised."""
    # CATCHES: $(((1+2)*3)) keeps its grouping parens but still gets the `*`
    # spacing right, so the printer must track paren depth, not just tokens.
    res = run_shfmt([], "echo $(((1+2)*3))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(((1 + 2) * 3))\n"
    assert res.stderr == ""


def test_precedence_untouched(run_shfmt):
    """An already-spaced mixed expression is stable and idempotent."""
    # CATCHES: `1 + 2 * 3` must not gain parentheses and must not be reordered;
    # the printer emits the tree exactly as it was parsed.
    res = run_shfmt([], "echo $((1 + 2 * 3))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((1 + 2 * 3))\n"
    assert res.stderr == ""


def test_assignment_word_arithmetic_spacing(run_shfmt):
    """Arithmetic on the right of an assignment still gets operator spacing."""
    # CATCHES: x=$((1+2)) is an assignment word, not a command argument, yet
    # the arithmetic printer still applies the same spacing rule.
    res = run_shfmt([], "x=$((1+2))\n")
    assert res.returncode == 0
    assert res.stdout == "x=$((1 + 2))\n"
    assert res.stderr == ""


def test_array_subscripts_in_arithmetic(run_shfmt):
    """Array subscripts inside arithmetic keep brackets and get spacing."""
    # CATCHES: a nested subscript like x[a[0]] must keep both bracket pairs,
    # while arr[i+1] still gets the binary spacing applied to its index.
    for expr, expected in [("arr[0]", "arr[0]"), ("arr[i+1]", "arr[i + 1]"), ("x[a[0]]", "x[a[0]]")]:
        res = run_shfmt([], "echo $((%s))\n" % expr)
        assert res.returncode == 0, expr
        assert res.stdout == "echo $((%s))\n" % expected, expr
        assert res.stderr == "", expr


def test_dollar_index_in_arithmetic_is_an_error(run_shfmt):
    """$x[0] inside arithmetic is rejected with a dedicated message."""
    # CATCHES: arithmetic allows bare names as array subscripts, so $x[0] is a
    # specific error and must not silently parse as an indexed parameter.
    res = run_shfmt([], "echo $(($x[0] + 1))\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:11: `[` must follow a name like a[i]\n"


def test_simplify_inlines_simple_parameters(run_shfmt):
    """--simplify drops the $ from plain name parameters inside arithmetic."""
    # CATCHES: arithmetic treats $x and x identically, so the dollar is noise;
    # both the short and braced spellings collapse to the bare name.
    cases = [
        ("echo $(($var + 1))\n", "echo $((var + 1))\n"),
        ("echo $((${var} + 1))\n", "echo $((var + 1))\n"),
        ("echo $(($x + $y))\n", "echo $((x + y))\n"),
        ("echo $(($x))\n", "echo $((x))\n"),
        ("(($var))\n", "((var))\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_simplify_keeps_non_name_parameters(run_shfmt):
    """--simplify never strips the $ from positional/special/indexed params."""
    # CATCHES: $1, $#, $@ and ${x[*]} are not valid bare names in arithmetic,
    # so removing the dollar there would be a semantic change.
    for src in [
        "echo $(($1 + 1))\n",
        "echo $(($# + 1))\n",
        "echo $(($@ + 1))\n",
        "echo $((${x[0]} + 1))\n",
        "echo $((${x[*]} + 1))\n",
    ]:
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0, src
        assert res.stdout == src, src
        assert res.stderr == "", src


def test_simplify_removes_redundant_parentheses(run_shfmt):
    """--simplify strips parentheses that wrap a whole operand."""
    # CATCHES: only parens that wrap the entire sub-expression disappear; the
    # inner (1) and (2) of `$(( (1) + (2) ))` must survive as grouping.
    cases = [
        ("echo $(( ( $x ) ))\n", "echo $((x))\n"),
        ("echo $(( (($x)) ))\n", "echo $((x))\n"),
        ("echo $(( (1 + 2) ))\n", "echo $((1 + 2))\n"),
        ("echo $(( (1) + (2) ))\n", "echo $(((1) + (2)))\n"),
        ("echo $(( $x + ( $y ) ))\n", "echo $((x + (y)))\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-s"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_minify_removes_arithmetic_spacing(run_shfmt):
    """--minify puts the spaces back in: it strips them from arithmetic."""
    # CATCHES: -mn is the inverse of the default printer for arithmetic, so
    # `$((1 + 2))` collapses to `$((1+2))` with no spaces at all.
    res = run_shfmt(["-mn"], "echo $((1 + 2))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((1+2))\n"
    assert res.stderr == ""


def test_tojson_arithmetic_operator_field(run_shfmt):
    """--to-json reports the operator and both operands as separate nodes."""
    # CATCHES: $((a+b)) must parse into a BinaryArithm with Op "+", proving
    # the operator table is shared with the printer's spacing rules.
    res = run_shfmt(["--to-json"], "echo $((a+b))\n")
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    exp = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert exp["Type"] == "ArithmExp"
    assert exp["X"]["Type"] == "BinaryArithm"
    assert exp["X"]["Op"] == "+"
    assert exp["X"]["X"]["Parts"][0]["Value"] == "a"
    assert exp["X"]["Y"]["Parts"][0]["Value"] == "b"


def test_tojson_reflects_simplify(run_shfmt):
    """--to-json runs after --simplify, so the tree shows the inlined name."""
    # CATCHES: the JSON is produced from the simplified node, i.e. the Word
    # 'x' rather than a ParamExp -- the two flags compose in a fixed order.
    res = run_shfmt(["--to-json", "-s"], "echo $(($x + 1))\n")
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    exp = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert exp["Type"] == "ArithmExp"
    assert exp["X"]["X"]["Type"] == "Word"
    assert exp["X"]["X"]["Parts"][0]["Value"] == "x"


def test_unterminated_arithmetic_errors(run_shfmt):
    """Unterminated or operand-less arithmetic fails with exact messages."""
    # CATCHES: an EOF inside $(( and a stray ) produce two distinct wordings,
    # and the reported column points at the opening $(, not at the EOF.
    cases = [
        ("echo $((1\n", "<standard input>:1:6: reached EOF without matching `$((` with `))`\n"),
        ("echo $((1+2)\n", "<standard input>:1:6: reached `)` without matching `$((` with `))`\n"),
        ("echo $((1+\n", "<standard input>:1:10: `+` must be followed by an expression\n"),
        ("echo $((x\n", "<standard input>:1:6: reached EOF without matching `$((` with `))`\n"),
    ]
    for src, message in cases:
        res = run_shfmt([], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == message, src
