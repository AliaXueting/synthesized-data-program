"""Nested parameter expansions and the special-name error paths.

zsh's ${#${x}}, ${#$(cmd)} and ${${x}} nestings versus the bash dialect
error, and the "cannot combine multiple parameter expansion operators"
diagnostic.
"""


def test_zsh_nested_length_forms(run_shfmt):
    """${#$(cmd)} and ${#${x}} round-trip under -ln=zsh."""
    # CATCHES: the length operator applies to a whole nested expansion, so
    # the inner $() or ${} must stay glued directly after the `#`.
    src = "echo ${#${x}} ${#$(ls)}\n"
    res = run_shfmt(["-ln=zsh", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_nested_expansion_is_zsh_only(run_shfmt):
    """bash rejects ${#${x}} and ${#$(ls)} with a dialect error at the ${`."""
    # CATCHES: the error position is the opening `${` of the nesting and the
    # message names zsh as the home dialect of nested expansions.
    for src in ("echo ${#${x}}\n", "echo ${#$(ls)}\n"):
        res = run_shfmt(["-ln=bash", "-"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == (
            "<standard input>:1:9: nested parameter expansions are a zsh "
            "feature; tried parsing as bash\n"
        ), src


def test_zsh_nested_parameter_value(run_shfmt):
    """${${x}} keeps the inner braces as one word in zsh."""
    # CATCHES: the inner expansion is a full word part of the outer one and
    # must not gain quoting or spacing when reprinted.
    src = "echo ${${x}}\n"
    res = run_shfmt(["-ln=zsh", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_cannot_combine_operators_error(run_shfmt):
    """${#$x} reports `cannot combine multiple parameter expansion operators`."""
    # CATCHES: combining the length prefix with another parameter form is
    # rejected at the second `$`, with the full multi-word message.
    res = run_shfmt(["-"], "echo ${#$x}\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:10: cannot combine multiple parameter expansion "
        "operators\n"
    )
