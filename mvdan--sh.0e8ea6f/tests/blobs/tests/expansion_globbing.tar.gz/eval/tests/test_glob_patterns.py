"""Pathname-expansion patterns: globs, classes and extended globs.

Glob characters are ordinary word text to the formatter, but the extended glob
forms @(x) *(x) ?(x) +(x) !(x) are real syntax nodes, and the shell dialect
decides whether they are accepted at all.
"""

import json

GLOB_SNIPPETS = ["*", "?", "???", "a*b", "**", "**/*.txt", "[a-z]", "[^a-z]", "[!a-z]", "[a-]"]

EXTGLOB_SNIPPETS = ["@(a|b)", "*(a)", "?(a)", "+(a)", "!(a|b)", "a@(b)c"]


def test_glob_metacharacters_pass_through(run_shfmt):
    """Unquoted glob metacharacters are printed unchanged and unquoted."""
    # CATCHES: adding quotes around a pattern would stop it globbing at run
    # time, and an unclosed class like [a- is legal text and must not error.
    for snippet in GLOB_SNIPPETS:
        res = run_shfmt([], "echo %s\n" % snippet)
        assert res.returncode == 0, snippet
        assert res.stdout == "echo %s\n" % snippet, snippet
        assert res.stderr == "", snippet


def test_quoted_or_escaped_glob_stays_literal(run_shfmt):
    """Quoting and backslash escapes around globs are preserved exactly."""
    # CATCHES: the reference keeps the exact quoting style used, so "*" stays
    # double-quoted, '*' stays single-quoted and \* keeps its backslash.
    for snippet in ['echo "*"', "echo '*'", "echo \\*", "echo a\\*b"]:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet
        assert res.stderr == "", snippet


def test_extended_glob_forms_in_bash(run_shfmt):
    """All five extended glob forms parse in the default bash dialect."""
    # CATCHES: @(x) *(x) ?(x) +(x) !(x) are distinct operators that must be
    # kept intact, including the | alternation inside the parentheses.
    for snippet in EXTGLOB_SNIPPETS:
        res = run_shfmt([], "echo %s\n" % snippet)
        assert res.returncode == 0, snippet
        assert res.stdout == "echo %s\n" % snippet, snippet
        assert res.stderr == "", snippet


def test_extended_glob_is_its_own_node(run_shfmt):
    """--to-json exposes an ExtGlob node with the operator and pattern."""
    # CATCHES: @(a|b) must become an ExtGlob whose Op is "@(" and whose
    # Pattern literal is the raw "a|b" text, not a parsed alternation.
    res = run_shfmt(["--to-json"], "echo @(a|b)\n")
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    parts = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"]
    assert len(parts) == 1
    assert parts[0]["Type"] == "ExtGlob"
    assert parts[0]["Op"] == "@("
    assert parts[0]["Pattern"]["Value"] == "a|b"


def test_extended_globs_rejected_in_posix(run_shfmt):
    """-ln=posix rejects extended globs with a fixed message and column 6."""
    # CATCHES: the error points at the start of the pattern (column 6, right
    # after `echo `) and names both shells that do support the feature.
    message = "<standard input>:1:6: extended globs are a bash/mksh feature; tried parsing as posix\n"
    for snippet in ["echo @(foo)\n", "echo *(foo)\n", "echo !(foo)\n"]:
        res = run_shfmt(["-ln=posix"], snippet)
        assert res.returncode == 1, snippet
        assert res.stdout == "", snippet
        assert res.stderr == message, snippet


def test_extended_glob_in_case_pattern_rejected_in_posix(run_shfmt):
    """An extended glob used as a case pattern is also a posix error."""
    # CATCHES: the position moves to the pattern itself (line 2, column 3),
    # showing the parser reports it where the pattern list starts.
    res = run_shfmt(["-ln=posix"], "case $x in\n  @(a|b)) echo y;;\nesac\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:2:3: extended globs are a bash/mksh feature; tried parsing as posix\n"


def test_unterminated_extended_glob_error(run_shfmt):
    """An unclosed @( is reported as an unmatched pair, not a bad word."""
    # CATCHES: the message names both the opening @( and the expected ),
    # which distinguishes it from the generic "must be followed by a word".
    res = run_shfmt([], "echo @(a\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:6: reached EOF without matching `@(` with `)`\n"


def test_case_pattern_alternation_gets_spacing(run_shfmt):
    """Pipes between case patterns are spaced like binary operators."""
    # CATCHES: `a|b|c)` must re-print as `a | b | c)` -- the alternation is
    # three separate patterns, not one literal containing pipes.
    res = run_shfmt([], "case $x in a|b|c) echo y;; esac\n")
    assert res.returncode == 0
    assert res.stdout == "case $x in a | b | c) echo y ;; esac\n"
    assert res.stderr == ""


def test_case_pattern_quoting_preserved(run_shfmt):
    """Quoted case patterns keep their quotes and gain ;; spacing."""
    # CATCHES: the empty pattern "" and the spaced pattern 'a b' must keep
    # their quotes, while `echo y;;` gains a space before the ;;.
    for src, expected in [
        ('case $x in "") echo y;; esac\n', 'case $x in "") echo y ;; esac\n'),
        ("case $x in 'a b') echo y;; esac\n", "case $x in 'a b') echo y ;; esac\n"),
    ]:
        res = run_shfmt([], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_case_pattern_with_glob_and_extglob(run_shfmt):
    """Glob and extended-glob patterns in a case clause are kept intact."""
    # CATCHES: a* and @(a|b) as case patterns must not be quoted or unwrapped,
    # and the trailing ;; still gets its separating space.
    for src in ["case $x in a*) echo y;; esac\n", "case $x in @(a|b)) echo y;; esac\n"]:
        expected = src.replace(" echo y;;", " echo y ;;")
        res = run_shfmt([], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_globbing_shell_options_are_plain_commands(run_shfmt):
    """shopt -s extglob/globstar/nullglob are just calls, unchanged."""
    # CATCHES: the formatter does not track shell options, so enabling
    # globstar or nullglob must not change how any pattern is printed.
    src = "shopt -s extglob\nshopt -s globstar\nshopt -s nullglob\nshopt -u nocaseglob\necho **\n"
    res = run_shfmt([], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_field_splitting_ifs_assignment_roundtrip(run_shfmt):
    """A custom IFS assignment is a normal word and is left alone."""
    # CATCHES: IFS=: is an assignment word whose value contains a metachar;
    # the formatter must not quote it, split it, or add spaces around =.
    res = run_shfmt([], 'IFS=: read -r a b <<< "x:y"\n')
    assert res.returncode == 0
    assert res.stdout == 'IFS=: read -r a b <<<"x:y"\n'
    assert res.stderr == ""
