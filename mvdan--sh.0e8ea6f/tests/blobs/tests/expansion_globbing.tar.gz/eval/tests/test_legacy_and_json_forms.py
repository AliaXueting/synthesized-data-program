"""Legacy spellings, arithmetic vocabulary and the typed JSON word tree.

Backtick command substitution (including escapes inside nested backticks),
the legacy $[...] arithmetic form, the @ transform operator alphabet, the full
arithmetic operator zoo, name expansion -- plus the --to-json/--from-json
serialisation of all of those, and the diagnostics for bad enum values in a
hand-written JSON tree.
"""

import json

import pytest

#: A script whose tree contains at least one of every operator enum: case
#: item terminators, [[ ]] test operators, extended globs, process
#: substitution, redirect operators and the full arithmetic operator set.
RICH_SRC = (
    "case $x in a|b) echo one ;;& *) echo d ;; esac\n"
    "[[ $x == foo* && $y =~ ^z || ! -f q ]]\n"
    "let \"a=1\" b++\n"
    "for ((i = 0; i < 3; i++)); do echo $((2 ** 3 + ~x)); done\n"
    "cat <<EOF\n"
    "line $x\n"
    "EOF\n"
    "echo {myfd}>out 2>>err 3<&0 4<>rw 5>|c 6<<-E\n"
    "\ttab\n"
    "E\n"
    "foo <(make) > >(consume) 2> >(err)\n"
    "r=$((x = 1, y += 2 ? a : b, --i, j++, k <<= 3 & 4 | 5 ^ 6, m %= 7 / 8 * 9 - 10 + 11))\n"
)

RICH_FORMATTED = (
    "case $x in a | b) echo one ;;& *) echo d ;; esac\n"
    "[[ $x == foo* && $y =~ ^z || ! -f q ]]\n"
    "let \"a=1\" b++\n"
    "for ((i = 0; i < 3; i++)); do echo $((2 ** 3 + ~x)); done\n"
    "cat <<EOF\n"
    "line $x\n"
    "EOF\n"
    "echo {myfd}>out 2>>err 3<&0 4<>rw 5>|c 6<<-E\n"
    "\ttab\n"
    "E\n"
    "foo <(make) > >(consume) 2> >(err)\n"
    "r=$((x = 1, y += 2 ? a : b, --i, j++, k <<= 3 & 4 | 5 ^ 6, m %= 7 / 8 * 9 - 10 + 11))\n"
)


def test_nested_backquote_escapes_normalised(run_shfmt):
    """An escaped backtick inside a backquote becomes nested $(...)."""
    # CATCHES: `\\`` inside a backquote is a nested command substitution, so
    # the whole word is rebuilt with dollar-parens at both nesting levels.
    res = run_shfmt(["-"], "echo `echo \\`whoami\\``\n")
    assert res.returncode == 0
    assert res.stdout == "echo $(echo $(whoami))\n"
    assert res.stderr == ""


def test_backtick_inside_double_quotes(run_shfmt):
    """A backquote substitution inside double quotes is normalised too."""
    # CATCHES: backquote handling does not stop at the double quote, and the
    # surrounding quoted literals keep their exact spacing.
    res = run_shfmt(["-"], 'echo "pre `echo hi` post"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "pre $(echo hi) post"\n'
    assert res.stderr == ""


def test_legacy_bracket_arith_normalised(run_shfmt):
    """The legacy $[...] arithmetic form is printed as $((...))."""
    # CATCHES: the square-bracket form is accepted on input but never emitted,
    # and the conversion also happens inside double-quoted words.
    res = run_shfmt(["-"], "echo $[1 + 2]\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((1 + 2))\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], 'echo "pre $[1+2] post"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "pre $((1 + 2)) post"\n'
    assert res.stderr == ""


def test_at_transform_operator_alphabet(run_shfmt):
    """Every documented ${x@X} transform letter round-trips."""
    # CATCHES: the accepted alphabet is Q E P A K a k U L; each letter is a
    # distinct operator token, so none may be dropped or lower/upper-cased.
    src = "echo ${x@Q} ${x@E} ${x@P} ${x@A} ${x@K} ${x@a} ${x@k} ${x@U} ${x@L}\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_at_transform_unknown_letter_error(run_shfmt):
    """An unknown ${x@Z} transform letter is a parse error."""
    # CATCHES: the diagnostic quotes the letter with backticks (printable
    # characters use `%#q` backtick quoting) and points at the letter itself.
    res = run_shfmt(["-"], "echo ${x@Z}\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:10: invalid @ expansion operator `Z`\n"


def test_arithmetic_operator_zoo(run_shfmt):
    """Every arithmetic operator keeps its spelling with canonical spacing."""
    # CATCHES: the operator table spans power, shifts, bitwise, comparison,
    # logical, ternary, comma and every compound assignment; spacing is added
    # around binary operators and after unary ! but not after unary ~ - +.
    cases = [
        ("r=$((1 + 2 - 3 * 4 / 5 % 6 ** 2))\n", "r=$((1 + 2 - 3 * 4 / 5 % 6 ** 2))\n"),
        ("r=$((a << 2 >> 1 & 3 | 4 ^ 5))\n", "r=$((a << 2 >> 1 & 3 | 4 ^ 5))\n"),
        ("r=$((1 < 2 && 3 > 4 || 5 <= 6 >= 7))\n", "r=$((1 < 2 && 3 > 4 || 5 <= 6 >= 7))\n"),
        ("r=$((1 == 2 != 3))\n", "r=$((1 == 2 != 3))\n"),
        ("r=$((x = 1, y += 2, z -= 3, w *= 4, v /= 5, u %= 6))\n", "r=$((x = 1, y += 2, z -= 3, w *= 4, v /= 5, u %= 6))\n"),
        ("r=$((a <<= 1, b >>= 2, c &= 3, d |= 4, e ^= 5))\n", "r=$((a <<= 1, b >>= 2, c &= 3, d |= 4, e ^= 5))\n"),
        ("r=$((++i + i++ - --j + j--))\n", "r=$((++i + i++ - --j + j--))\n"),
        ("r=$((!0x10 + ~07 + -1 + +2))\n", "r=$((! 0x10 + ~07 + -1 + +2))\n"),
        ("r=$((x > 1 ? y : z))\n", "r=$((x > 1 ? y : z))\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_arithmetic_base_prefixes(run_shfmt):
    """Hex, octal and base#number literals pass through as words."""
    # CATCHES: 0x, leading zero and N# prefixes are part of the number token,
    # not operators, so they must not be spaced or rewritten.
    src = "r=$((16#ff + 2#1011 + 0x10 + 07 + 99#1))\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_arithmetic_empty_expression_error(run_shfmt):
    """An empty $(( )) reports the position of the opening $(($."""
    # CATCHES: the error blames column 6 where $(( starts, with the token
    # spelled with its backticks in the message.
    res = run_shfmt(["-"], "echo $(())\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:6: `$((` must be followed by an expression\n"


def test_arithmetic_unbalanced_paren_error(run_shfmt):
    """A missing closing paren reports the $( ( position and the )) spelling."""
    # CATCHES: the wording matches `))` as the expected closer and the column
    # points at the $(( that was never closed.
    res = run_shfmt(["-"], "echo $((1 + (2 - 3))\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:6: reached `)` without matching `$((` with `))`\n"


def test_name_expansion_forms_and_json_field(run_shfmt):
    """${!prefix*} and ${!prefix@} differ in the JSON Names field."""
    # CATCHES: the two name-expansion forms share their syntax but serialise
    # the separator as "*" or "@" -- and both survive the JSON round trip.
    for form, names in (("*", "*"), ("@", "@")):
        src = "echo ${!BASH%s}\n" % form
        tree = run_shfmt(["--to-json"], src)
        assert tree.returncode == 0
        node = json.loads(tree.stdout)["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
        assert node["Type"] == "ParamExp"
        assert node["Names"] == names

        res = run_shfmt(["--from-json"], tree.stdout)
        assert res.returncode == 0
        assert res.stdout == src
        assert res.stderr == ""


def test_from_json_round_trips_every_operator_kind(run_shfmt):
    """A tree holding every operator enum survives the JSON detour."""
    # CATCHES: each operator enum (case, test, glob, process substitution,
    # redirect and arithmetic operators) must unmarshal from its textual form
    # and print back to the canonical formatting of the original script.
    tree = run_shfmt(["--to-json"], RICH_SRC)
    assert tree.returncode == 0

    res = run_shfmt(["--from-json"], tree.stdout)
    assert res.returncode == 0
    assert res.stdout == RICH_FORMATTED
    assert res.stderr == ""


def test_from_json_round_trips_param_exp_operators(run_shfmt):
    """Every ${x<op>...} operator unmarshals and reprints identically."""
    # CATCHES: the parameter expansion operators (- := + ? # ## % %% / // ^
    # ^^ , ,, @) are their own enum in the JSON tree; a wrong textual mapping
    # for any one of them would change the printed form.
    src = (
        "a=${x:-d}\nb=${x:=d}\nc=${x:+p}\nd=${x:?m}\n"
        "e=${x#p}\nf=${x##p}\ng=${x%p}\nh=${x%%p}\n"
        "i=${x/a/b}\nj=${x//a/b}\n"
        "k=${x^}\nl=${x^^}\nm=${x,}\nn=${x,,}\no=${x@Q}\n"
    )
    tree = run_shfmt(["--to-json"], src)
    assert tree.returncode == 0

    res = run_shfmt(["--from-json"], tree.stdout)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_bats_test_declaration(run_shfmt):
    """The bats @test form parses with its quoted name word and body."""
    # CATCHES: @test is only valid in the bats dialect; the name stays a
    # single-quoted word and the body keeps the brace layout.
    src = "@test 'name here' {\n\ttrue\n}\n"
    res = run_shfmt(["-ln=bats", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_from_json_empty_file_prints_blank_line(run_shfmt):
    """A File tree with no statements formats to a single newline."""
    # CATCHES: the empty tree is valid JSON input, producing exit 0 and one
    # newline of output rather than an error or empty stdout.
    res = run_shfmt(["--from-json"], '{"Type": "File"}')
    assert res.returncode == 0
    assert res.stdout == "\n"
    assert res.stderr == ""


def mutate_op(run_shfmt, src, path, value):
    """Return the from-json run with one operator field replaced."""
    tree = run_shfmt(["--to-json"], src)
    assert tree.returncode == 0
    root = json.loads(tree.stdout)
    node = root
    for key in path:
        node = node[key]
    node["Op"] = value
    return run_shfmt(["--from-json"], json.dumps(root))


@pytest.mark.parametrize(
    "src,path,value,message",
    [
        # (source, JSON path to the node, bad Op, expected stderr)
        ("a && b\n", ["Stmts", 0, "Cmd"], "&&&", 'invalid BinCmdOperator: "&&&"\n'),
        ("echo @(a)\n", ["Stmts", 0, "Cmd", "Args", 1, "Parts", 0], "%()", 'invalid GlobOperator: "%()"\n'),
        ("cat <(make)\n", ["Stmts", 0, "Cmd", "Args", 1, "Parts", 0], "!!", 'invalid ProcOperator: "!!"\n'),
        ("case $x in a) echo 1 ;; esac\n", ["Stmts", 0, "Cmd", "Items", 0], ";;;", 'invalid CaseOperator: ";;;"\n'),
        ("[[ -z $x ]]\n", ["Stmts", 0, "Cmd", "X"], "-zz", 'invalid UnTestOperator: "-zz"\n'),
        ("echo $((++i))\n", ["Stmts", 0, "Cmd", "Args", 1, "Parts", 0, "X"], "+++", 'invalid UnAritOperator: "+++"\n'),
        ("echo $((1 + 2))\n", ["Stmts", 0, "Cmd", "Args", 1, "Parts", 0, "X"], "***", 'invalid BinAritOperator: "***"\n'),
    ],
)
def test_from_json_invalid_operator_names_the_type(run_shfmt, src, path, value, message):
    """A bogus operator string in the JSON tree names the enum type."""
    # CATCHES: each enum type validates its own values, so the error text
    # carries the Go type name (BinAritOperator, CaseOperator, ...) -- a
    # single generic message for all enums would not match.
    res = mutate_op(run_shfmt, src, path, value)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message


def test_from_json_invalid_redir_operator(run_shfmt):
    """An unknown redirect operator string is rejected before formatting."""
    # CATCHES: the RedirOperator validation happens on decode, so nothing is
    # printed and the message follows the shared `invalid <Type>: "value"` shape.
    res = mutate_op(run_shfmt, "echo hi >f\n", ["Stmts", 0, "Redirs", 0], ">>>")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid RedirOperator: ">>>"\n'


def test_from_json_invalid_names_separator(run_shfmt):
    """A bad ${!prefix...} separator value is a ParNamesOperator error."""
    # CATCHES: the Names field accepts only * and @; anything else is a typed
    # decode error naming ParNamesOperator.
    tree = run_shfmt(["--to-json"], "echo ${!BASH*}\n")
    node = json.loads(tree.stdout)
    node["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]["Names"] = "!"
    res = run_shfmt(["--from-json"], json.dumps(node))
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid ParNamesOperator: "!"\n'


def test_from_json_unknown_type_error(run_shfmt):
    """A tree with an unrecognised node type is rejected."""
    # CATCHES: the decoder is closed over the node vocabulary -- an invented
    # type name fails with the type echoed back, not a generic JSON error.
    res = run_shfmt(["--from-json"], '{"Type": "Bogus"}')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'unknown type: "Bogus"\n'


def test_from_json_malformed_json_error(run_shfmt):
    """Input that is not JSON at all surfaces the raw decoder error."""
    # CATCHES: the message comes from the JSON decoder itself -- `nonsense`
    # looks like the start of the literal null, hence this exact wording.
    res = run_shfmt(["--from-json"], "nonsense")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "invalid character 'o' in literal null (expecting 'u')\n"
