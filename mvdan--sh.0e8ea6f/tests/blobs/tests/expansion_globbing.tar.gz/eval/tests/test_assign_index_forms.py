"""Indexed-array assignment forms and their diagnostics.

a[i]=v and a[i]+=v, naked indices in declare contexts, the bash/zsh split
on a[i]=(...) array values, and the exact follow-`=` errors for broken
index assignments.
"""


def test_indexed_assignment_roundtrip(run_shfmt):
    """a[1]=x, a[1]+=x, a[$i]=x and odd index literals all survive."""
    # CATCHES: the += append form and a non-numeric index like 1x stay one
    # assignment word; the index keeps its own quoting and dollar forms.
    src = "a[1]=x\na[1]+=y\na[$i]=z\na[1x]=2\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_naked_index_in_declare_builtins(run_shfmt):
    """declare and export accept a bare a[1] without a value."""
    # CATCHES: inside a declare-like builtin the index assignment may end
    # without `=`, and the naked form is reprinted with the same shape.
    src = "export a[1]\ndeclare -a a[1]\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_indexed_array_value_dialect_split(run_shfmt):
    """a[1]=(1 2) errors in bash but is a zsh array-element assignment."""
    # CATCHES: bash rejects an array literal as an indexed element's value
    # while zsh assigns the list to that single index; the zsh form then
    # round-trips unchanged.
    res = run_shfmt(["-"], "a[1]=(1 2)\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:5: arrays cannot be nested\n"

    res = run_shfmt(["-ln=zsh", "-"], "a[1]=(1 2)\n")
    assert res.returncode == 0
    assert res.stdout == "a[1]=(1 2)\n"
    assert res.stderr == ""


def test_broken_index_assignment_errors(run_shfmt):
    """Missing `=` after a[b] (or a[b]+) and an empty index both error."""
    # CATCHES: the diagnostic names the offending prefix (`a[b]` or `a[b]+`)
    # at the assignment's own column, while an empty bracket reports at the
    # `[` itself.
    cases = [
        ("a[b]\n", "<standard input>:1:1: `a[b]` must be followed by `=`\n"),
        ("a[b]+\n", "<standard input>:1:1: `a[b]+` must be followed by `=`\n"),
        ("a[]=1\n", "<standard input>:1:2: `[` must be followed by an expression\n"),
    ]
    for src, err in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == err, src


def test_length_operator_special_params(run_shfmt):
    """${#?} ${#-} ${##} ${#x} and the ${#-fallback} ambiguity all pass through."""
    # CATCHES: ${#-fallback} is re-parsed as parameter `#` with a default
    # word (not the length of `$-`), and every special-parameter length
    # form keeps its exact spelling.
    src = "echo ${#?} ${#-} ${##} ${#x} ${#-fallback}\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_multi_digit_positional_parameters(run_shfmt):
    """${10} and ${23} keep their braces -- they are not $1 followed by 0."""
    # CATCHES: the braced multi-digit positional must not be split into a
    # short expansion plus literal digits when the tree is printed.
    src = "echo ${10} ${23}\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""
