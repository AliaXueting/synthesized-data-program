"""Shared harness for the expansion_globbing black-box test module.

The reference program is a shell-script formatter driven through its CLI.
Word-level behaviour -- the syntax of parameter, tilde, brace and arithmetic
expansion, quoting, field/word structure and glob patterns -- is observed by
feeding a snippet on standard input and comparing stdout, stderr and the exit
status byte-for-byte with the recorded reference behaviour.
"""

from __future__ import annotations

import functools
import os
import subprocess
import tempfile
from pathlib import Path

import pytest

#: Minimal, pinned child environment.  Nothing that could perturb the output
#: (FORCE_COLOR, an interactive TERM, EDITOR config discovery) is inherited.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "NO_COLOR": "1",
    "TERM": "dumb",
}

#: Variables that must reach the child even though the environment is pinned,
#: so that the pipeline's coverage instrumentation can still observe runs.
PASSTHROUGH_ENV = ("GOCOVERDIR",)


def build_child_env(extra_env=None):
    """Return the pinned child environment, plus instrumentation passthrough."""
    env = dict(CHILD_ENV)
    for key in PASSTHROUGH_ENV:
        value = os.environ.get(key)
        if value:
            env[key] = value
    if extra_env:
        env.update(extra_env)
    return env


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--version' once against a throwaway GOCOVERDIR, so the
    check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="shfmt-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def shfmt_executable():
    """Return the binary under test, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError("PROGRAMGYM_EXECUTABLE is not set")
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but the
    # pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to the
    # module's uninstrumented copy before pytest starts, so the counters would
    # never be written and this module's coverage report would stay empty.
    # During a coverage run (GOCOVERDIR present), when the assigned binary is
    # not itself instrumented, fall back to the instrumented build the driver
    # stages next to the module workspaces.  The staged file only exists in
    # that layout, so ordinary validation and release runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(str(staged)):
            return str(staged)
    return path


@pytest.fixture(scope="session")
def shfmt_exe():
    """Resolve the candidate binary from PROGRAMGYM_EXECUTABLE."""
    return shfmt_executable()


@pytest.fixture
def run_shfmt(shfmt_exe, tmp_path):
    """Return a helper that runs the candidate once and captures everything."""

    def _run(args, src="", cwd=None, extra_env=None):
        env = build_child_env(extra_env)
        # 'src' is normally text; bytes are accepted so tests can feed the
        # reference input that is not valid UTF-8 (NUL bytes, invalid runes).
        data = src if isinstance(src, bytes) else src.encode()
        proc = subprocess.run(
            [shfmt_exe] + list(args),
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(cwd or tmp_path),
            env=env,
            timeout=60,
        )
        return subprocess.CompletedProcess(
            proc.args,
            proc.returncode,
            proc.stdout.decode("utf-8", "replace"),
            proc.stderr.decode("utf-8", "replace"),
        )

    return _run


@pytest.fixture
def write_script(tmp_path):
    """Return a helper that drops a shell snippet into a real file."""

    def _write(name, text):
        path = tmp_path / name
        path.write_text(text)
        return path

    return _write
