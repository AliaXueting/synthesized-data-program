"""Printer layout decisions for the remaining formatting paths.

Flag-driven indentation (-ci, -fn, -bn, -sr, -kp, -mn), statement and
assignment layout, line continuations for operators, assignments, double
quotes and redirects, comment placement around headers and heredocs,
blank-line collapsing, the zsh doubled parameter flags, zsh `function`
with several names, `<<-` heredoc re-indentation and the mksh typeset
attribute flag.
"""


def test_switch_case_indent(run_shfmt):
    """-ci indents case patterns by one tab."""
    # CATCHES: `a) b;;` becomes a tab-indented `a) b ;;` with a space
    # before the terminator -- a spacing change only -ci performs.
    res = run_shfmt(["-ci", "-"], "case $x in\na) b;;\nesac")
    assert res.returncode == 0
    assert res.stdout == "case $x in\n\ta) b ;;\nesac\n"
    assert res.stderr == ""


def test_function_starting_brace_own_line(run_shfmt):
    """-fn puts a function's opening brace on its own line."""
    # CATCHES: the one-line `foo() { :; }` is split so that `{` starts a
    # new line and the body indents a tab under it.
    res = run_shfmt(["-fn", "-"], "foo() { :; }")
    assert res.returncode == 0
    assert res.stdout == "foo()\n{\n\t:\n}\n"
    assert res.stderr == ""


def test_c_style_for_without_init(run_shfmt):
    """A C-style for loop with no init keeps a space after the first paren."""
    # CATCHES: `for ((; i<3; i++))` prints as `(( ; i < 3; i++))` -- the
    # space sits after the opening paren only, and `i<3` widens to
    # `i < 3` while `i++` stays glued.
    res = run_shfmt(["-"], "for ((; i<3; i++)); do :; done")
    assert res.returncode == 0
    assert res.stdout == "for (( ; i < 3; i++)); do :; done\n"
    assert res.stderr == ""


def test_case_pattern_spelled_esac(run_shfmt):
    """A case pattern may literally be the word `esac`."""
    # CATCHES: the parenthesised pattern `(esac)` keeps its parens and the
    # item's `;;` gains the usual leading space, so the pattern is not
    # confused with the terminating keyword.
    res = run_shfmt(["-"], "case $x in (esac) :;; esac")
    assert res.returncode == 0
    assert res.stdout == "case $x in (esac) : ;; esac\n"
    assert res.stderr == ""


def test_binary_arithm_chain_split(run_shfmt):
    """-bn splits a && chain inside ((...)) with a backslash."""
    # CATCHES: the continuation backslash goes after `a`, the `&&` moves
    # to the next line indented one tab, and the arithmetic parens stay
    # balanced across the split.
    res = run_shfmt(["-bn", "-"], "((a &&\nb))")
    assert res.returncode == 0
    assert res.stdout == "((a \\\n\t&& b))\n"
    assert res.stderr == ""


def test_binary_chain_comment_indent(run_shfmt):
    """A comment inside a -bn split chain indents with the operator."""
    # CATCHES: the `# c` line keeps its own line but gains a tab, matching
    # the tabbed `&&` line above and the operand `b` below it.
    res = run_shfmt(["-bn", "-"], "a &&\n# c\nb")
    assert res.returncode == 0
    assert res.stdout == "a \\\n\t&&\n\t# c\n\tb\n"
    assert res.stderr == ""


def test_assign_prefix_semicolon_split(run_shfmt):
    """`arg=$1; shift` stays whole but `arg=$1; echo hi` splits at the `;`."""
    # CATCHES: the printer keeps `shift` on the assignment's line (the
    # same-statement exception) while a real command after the semicolon
    # always moves to its own line.
    res = run_shfmt(["-"], "arg=$1; shift")
    assert res.returncode == 0
    assert res.stdout == "arg=$1; shift\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "arg=$1; echo hi")
    assert res.returncode == 0
    assert res.stdout == "arg=$1\necho hi\n"
    assert res.stderr == ""


def test_assign_prefix_continuation(run_shfmt):
    """The second assignment of a continued command prefix indents a tab."""
    # CATCHES: the line-continuation backslash keeps the first assignment
    # at column 0 while every following prefix word indents one tab.
    res = run_shfmt(["-"], "a=1 \\\nb=2 cmd")
    assert res.returncode == 0
    assert res.stdout == "a=1 \\\n\tb=2 cmd\n"
    assert res.stderr == ""


def test_dquoted_line_continuation_kept(run_shfmt):
    """A backslash-newline inside double quotes is preserved as written."""
    # CATCHES: the escaped newline is part of the quoted literal, so the
    # printer emits the backslash, the newline and the closing quote
    # exactly where they were.
    res = run_shfmt(["-"], 'echo "a\\\n"')
    assert res.returncode == 0
    assert res.stdout == 'echo "a\\\n"\n'
    assert res.stderr == ""


def test_heredoc_trailing_comment(run_shfmt):
    """A comment after the heredoc operator stays on the operator's line."""
    # CATCHES: `# c` follows `<<EOF` on the same line and the body below
    # is untouched, so the comment does not migrate into the heredoc.
    res = run_shfmt(["-"], "cat <<EOF # c\nbody\nEOF")
    assert res.returncode == 0
    assert res.stdout == "cat <<EOF # c\nbody\nEOF\n"
    assert res.stderr == ""


def test_redirect_spaces_runs_mid_word(run_shfmt):
    """-sr spaces `>f` after a word but keeps the fd-dup `>&2` glued."""
    # CATCHES: the spacing rule applies to the file-target forms only, so
    # `echo >f hi` gains spaces while `echo >&2 hi` is left alone.
    res = run_shfmt(["-sr", "-"], "echo >f hi")
    assert res.returncode == 0
    assert res.stdout == "echo > f hi\n"
    assert res.stderr == ""

    res = run_shfmt(["-sr", "-"], "echo >&2 hi")
    assert res.returncode == 0
    assert res.stdout == "echo >&2 hi\n"
    assert res.stderr == ""


def test_redirect_line_continuation(run_shfmt):
    """A trailing redirect on a continued line indents like the chain."""
    # CATCHES: the redirect target joins the backslash-continued line and
    # the whole `>f` operator-word indents one tab on the new line.
    res = run_shfmt(["-"], "echo hi \\\n> f")
    assert res.returncode == 0
    assert res.stdout == "echo hi \\\n\t>f\n"
    assert res.stderr == ""


def test_keep_pipes_subshell_comment(run_shfmt):
    """-kp preserves a leading comment indented inside a subshell."""
    # CATCHES: the `# c` line keeps its tab inside the parens and the body
    # statements keep their own indentation, byte for byte.
    res = run_shfmt(["-kp", "-"], "(\n\t# c\n\tfoo\n)")
    assert res.returncode == 0
    assert res.stdout == "(\n\t# c\n\tfoo\n)\n"
    assert res.stderr == ""


def test_minify_nested_subshell(run_shfmt):
    """-mn collapses a nested subshell onto as few lines as possible."""
    # CATCHES: the outer parens keep their newlines but the inner `(echo)`
    # fits on one line and the trailing `x` joins the last line before the
    # closing paren.
    res = run_shfmt(["-mn", "-"], "( (echo); x )")
    assert res.returncode == 0
    assert res.stdout == "(\n(echo)\nx)\n"
    assert res.stderr == ""


def test_if_header_newline_kept(run_shfmt):
    """A newline after && in an if header is kept, with the operand tabbed."""
    # CATCHES: the operand `b` indents one tab as a continuation while
    # `then` returns to column 0 on its own line and the body indents.
    res = run_shfmt(["-"], "if a &&\nb\nthen\n:\nfi")
    assert res.returncode == 0
    assert res.stdout == "if a &&\n\tb\nthen\n\t:\nfi\n"
    assert res.stderr == ""


def test_until_header_newline_kept(run_shfmt):
    """An until header keeps its newline after && exactly like if."""
    # CATCHES: the same continuation rule applies to `until` headers: the
    # operand indents, the `do` keyword returns to column 0.
    res = run_shfmt(["-"], "until a &&\nb\ndo\n:\ndone")
    assert res.returncode == 0
    assert res.stdout == "until a &&\n\tb\ndo\n\t:\ndone\n"
    assert res.stderr == ""


def test_comment_before_else_kept(run_shfmt):
    """A comment between the then-body and else stays at column zero."""
    # CATCHES: the `# pre-else` line is not indented into the then-body;
    # it sits directly above the `else` keyword, which itself forces the
    # body statements onto their own indented lines.
    res = run_shfmt(["-"], "if a; then b\n# pre-else\nelse c\nfi")
    assert res.returncode == 0
    assert res.stdout == "if a; then\n\tb\n# pre-else\nelse\n\tc\nfi\n"
    assert res.stderr == ""


def test_for_comment_moves_to_do(run_shfmt):
    """A comment trailing the for header lands after the inserted `do`."""
    # CATCHES: the printer rewrites `for i in a b # stmt` into
    # `for i in a b; do # stmt`, keeping the comment at the end of the
    # header line but after the newly placed `do`.
    res = run_shfmt(["-"], "for i in a b # stmt\ndo foo; done")
    assert res.returncode == 0
    assert res.stdout == "for i in a b; do # stmt\n\tfoo\ndone\n"
    assert res.stderr == ""


def test_blank_lines_collapse_to_one(run_shfmt):
    """Two or more blank lines between statements become a single one."""
    # CATCHES: runs of blank lines are collapsed to exactly one, while a
    # single blank line between statements is of course kept.
    res = run_shfmt(["-"], "a\n\n\nb")
    assert res.returncode == 0
    assert res.stdout == "a\n\nb\n"
    assert res.stderr == ""


def test_zsh_double_parameter_flags_roundtrip(run_shfmt):
    """The doubled zsh parameter flags keep their exact spelling."""
    # CATCHES: ${~~x}, ${^^x} and ${==x} round-trip unchanged in one word
    # list, so neither flag is collapsed to its single-character form.
    res = run_shfmt(["--ln=zsh", "-"], "echo ${~~x} ${^^x} ${==x}")
    assert res.returncode == 0
    assert res.stdout == "echo ${~~x} ${^^x} ${==x}\n"
    assert res.stderr == ""


def test_zsh_function_extra_names_roundtrip(run_shfmt):
    """zsh accepts `function` with more than one name word."""
    # CATCHES: both names stay on the function line and the braces stay
    # inline with the body, unchanged from the input spelling.
    res = run_shfmt(["--ln=zsh", "-"], "function a b { :; }")
    assert res.returncode == 0
    assert res.stdout == "function a b { :; }\n"
    assert res.stderr == ""


def test_heredoc_dash_blank_line(run_shfmt):
    """A blank line inside a <<- heredoc body keeps its own empty line."""
    # CATCHES: the blank line between `x` and `y` is preserved as a truly
    # empty line while both body words gain the tab, and the terminator
    # loses its tab entirely.
    res = run_shfmt(["-"], "cat <<-EOF\nx\n\ny\n\tEOF")
    assert res.returncode == 0
    assert res.stdout == "cat <<-EOF\n\tx\n\n\ty\nEOF\n"
    assert res.stderr == ""


def test_heredoc_dash_underindented_line(run_shfmt):
    """A <<- body line with no leading tab gains one anyway."""
    # CATCHES: `flat` had no indentation in the input but is printed with
    # a tab, since only the terminator's indentation is measured and
    # stripped, not the body's.
    res = run_shfmt(["-"], "cat <<-EOF\n\tdeep\nflat\n\tEOF")
    assert res.returncode == 0
    assert res.stdout == "cat <<-EOF\n\tdeep\n\tflat\nEOF\n"
    assert res.stderr == ""


def test_mksh_typeset_unsigned_flag_roundtrip(run_shfmt):
    """The mksh typeset attribute `#7` stays glued to its option word."""
    # CATCHES: `-U#7` is a single option word carrying the unsigned
    # attribute and its width, so it is not split or re-spaced.
    res = run_shfmt(["--ln=mksh", "-"], "typeset -U#7 x")
    assert res.returncode == 0
    assert res.stdout == "typeset -U#7 x\n"
    assert res.stderr == ""
