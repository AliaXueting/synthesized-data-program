"""Zsh-only word and glob forms and their bash-dialect contrast.

Numeric range globs, subscript flags and parameter flags only parse under
``-ln=zsh``; the same characters mean something else (or stay plain literals)
in the bash dialect.  These tests pin both sides of that dialect boundary.
"""


def test_zsh_numeric_range_globs(run_shfmt):
    """Zsh numeric range glob patterns <m-n> stay inside the word."""
    # CATCHES: <1-10>, <->, <-5> and <5-> are glob syntax in zsh, so they
    # must remain one word instead of turning into redirects.
    src = "echo <1-10>.txt <-> <-5> <5->\n"
    res = run_shfmt(["-ln=zsh", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_numeric_range_is_redirects_in_bash(run_shfmt):
    """The same <1-10>.txt parses as two redirects in the bash dialect."""
    # CATCHES: without zsh, < opens an input redirect from the file `1-10`
    # and > opens an output redirect to `.txt`, with a space added before >.
    res = run_shfmt(["-"], "echo <1-10>.txt\n")
    assert res.returncode == 0
    assert res.stdout == "echo <1-10 >.txt\n"
    assert res.stderr == ""


def test_zsh_extended_glob_is_a_literal(run_shfmt):
    """@(x) and *(x) parse as literals in zsh, not as ExtGlob nodes."""
    # CATCHES: zsh glob qualifiers conflict with bash extglobs, so the zsh
    # dialect keeps the parens in the literal text while bash would split
    # them into extended glob words.
    res = run_shfmt(["-ln=zsh", "-"], "echo @(a|b) *(c)\n")
    assert res.returncode == 0
    assert res.stdout == "echo @(a|b) *(c)\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "echo @(a|b)\n")
    assert res.returncode == 0
    assert res.stdout == "echo @(a|b)\n"
    assert res.stderr == ""


def test_zsh_subscript_flags(run_shfmt):
    """Zsh subscript flags ${arr[(f)pat]} stay attached to the index."""
    # CATCHES: the (i) or (r) flags plus their pattern are part of the
    # subscript, including the comma-separated two-argument (r)pat,other form.
    src = "echo ${arr[(i)pattern]}\necho ${arr[(r)pat,other]}\n"
    res = run_shfmt(["-ln=zsh", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_zsh_parameter_flags(run_shfmt):
    """Zsh ${(j:,:)array} flag syntax round-trips untouched."""
    # CATCHES: the flag list inside the parens, including its own quoting,
    # is preserved as part of the parameter expansion word.
    res = run_shfmt(["-ln=zsh", "-"], "echo ${(j:,:)array}\n")
    assert res.returncode == 0
    assert res.stdout == "echo ${(j:,:)array}\n"
    assert res.stderr == ""
