"""Parameter-expansion edge gates: special names, bad operators, zsh flags.

Indexing $@/$*/$#, the wording for characters that cannot start an operator,
the zsh =/~/^ prefix flags (and their doubled off-forms), zsh short-form
subscripts, and associative-array keys containing a hash.
"""

import json

import pytest


def _find_node(obj, type_name):
    """Depth-first search for the first typed-JSON node of a given type."""
    if isinstance(obj, dict):
        if obj.get("Type") == type_name:
            return obj
        for value in obj.values():
            found = _find_node(value, type_name)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = _find_node(value, type_name)
            if found is not None:
                return found
    return None


def _lit_values(obj):
    """Return every literal string in the tree, in source order."""
    values = []
    if isinstance(obj, dict):
        if obj.get("Type") == "Lit":
            values.append(obj["Value"])
        for value in obj.values():
            values.extend(_lit_values(value))
    elif isinstance(obj, list):
        for value in obj:
            values.extend(_lit_values(value))
    return values


@pytest.mark.parametrize("src", ["echo ${@[1]}\n", "echo ${*[1]}\n", "echo ${#[1]}\n"])
def test_special_parameters_cannot_be_indexed(run_shfmt, src):
    """$@, $* and $# reject a subscript with the same message."""
    # CATCHES: only real names (or array elements) may take a [idx] suffix;
    # the special parameters report "cannot index a special parameter name"
    # at the bracket, not at the parameter.
    res = run_shfmt(["-ln=bash", "-"], src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:9: cannot index a special parameter name\n"


@pytest.mark.parametrize(
    "src,expected",
    [
        ("echo ${a b}\n", "<standard input>:1:9: not a valid parameter expansion operator: ` `\n"),
        ("echo ${x{y}}\n", "<standard input>:1:9: not a valid parameter expansion operator: `{`\n"),
        ("x=${y`z`}\n", '<standard input>:1:6: not a valid parameter expansion operator: "`"\n'),
    ],
)
def test_bad_operator_characters_are_named(run_shfmt, src, expected):
    """A character that cannot continue ${...} is reported verbatim."""
    # CATCHES: the diagnostic quotes the offending rune itself, including a
    # plain space, an opening brace and a backquote, at its exact column.
    res = run_shfmt(["-ln=bash", "-"], src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == expected


def test_zsh_prefix_flags_rejected_in_bash(run_shfmt):
    """bash has no ${=x} or ${~x}, so the flag rune is a bad parameter name."""
    # CATCHES: bash reports "invalid parameter name" pointing at the flag
    # character, because = and ~ are not name runes there.
    for src in ("echo ${=x}\n", "echo ${~x}\n"):
        res = run_shfmt(["-ln=bash", "-"], src)
        assert res.returncode == 1, src
        assert res.stderr == "<standard input>:1:8: invalid parameter name\n", src


@pytest.mark.parametrize(
    "src,field,value",
    [
        ("echo ${=x}\n", "Split", 1),
        ("echo ${==x}\n", "Split", 2),
        ("echo ${~x}\n", "GlobSubst", 1),
        ("echo ${~~x}\n", "GlobSubst", 2),
        ("echo ${^x}\n", "RcExpand", 1),
        ("echo ${^^x}\n", "RcExpand", 2),
    ],
)
def test_zsh_prefix_flag_json_values(run_shfmt, src, field, value):
    """Each single zsh prefix sets its flag to 1; the doubled form sets 2."""
    # CATCHES: the doubled spelling means "force the option off" and is
    # encoded as the distinct value 2, not as the same 1 as the single form.
    res = run_shfmt(["-ln=zsh", "--to-json", "-"], src)
    assert res.returncode == 0
    assert res.stderr == ""
    param = _find_node(json.loads(res.stdout), "ParamExp")
    assert param is not None
    assert param[field] == value


@pytest.mark.parametrize(
    "src,fields",
    [
        ("echo ${=^x}\n", {"Split": 1, "RcExpand": 1}),
        ("echo ${~~^x}\n", {"GlobSubst": 2, "RcExpand": 1}),
        ("echo ${=~x}\n", {"Split": 1, "GlobSubst": 1}),
    ],
)
def test_zsh_prefix_flags_combine(run_shfmt, src, fields):
    """Combined prefixes each keep their own on/off value in the tree."""
    # CATCHES: the prefixes may combine in any order, and the tree records
    # every one of them, so ${~~^x} is GlobSubst=2 next to RcExpand=1.
    res = run_shfmt(["-ln=zsh", "--to-json", "-"], src)
    assert res.returncode == 0
    assert res.stderr == ""
    param = _find_node(json.loads(res.stdout), "ParamExp")
    assert param is not None
    for field, value in fields.items():
        assert param[field] == value, field


def test_zsh_short_param_subscript(run_shfmt):
    """zsh $foo[1] carries an Index; $1[x] keeps the bracket literal."""
    # CATCHES: the short form only subscriptes real names, so the positional
    # $1 keeps [x] as a separate literal word part with no Index field.
    res = run_shfmt(["-ln=zsh", "--to-json", "-"], "echo $foo[1]\n")
    assert res.returncode == 0
    param = _find_node(json.loads(res.stdout), "ParamExp")
    assert param is not None
    assert [part["Value"] for part in param["Index"]["Parts"]] == ["1"]
    assert res.stdout.count('"Index"') == 1

    res = run_shfmt(["-ln=zsh", "-"], "echo $foo[1]\n")
    assert res.stdout == "echo $foo[1]\n"

    res = run_shfmt(["-ln=zsh", "--to-json", "-"], "echo $1[x]\n")
    assert res.returncode == 0
    tree = json.loads(res.stdout)
    param = _find_node(tree, "ParamExp")
    assert param is not None
    assert param["Param"]["Value"] == "1"
    assert "Index" not in param
    # The bracket text survives as a literal part right after the parameter.
    assert _lit_values(tree) == ["echo", "[x]"]


@pytest.mark.parametrize("src", ["echo ${args[cmd,#]}\n", "echo ${args[#,cmd]}\n"])
def test_hash_inside_assoc_array_key(run_shfmt, src):
    """A # inside a subscript stays literal key text in every position."""
    # CATCHES: inside ${name[...]} the hash does not start a comment and is
    # not an mksh unsigned marker, so the whole bracket is one literal key.
    res = run_shfmt(["-ln=bash", "-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_mksh_stmt_forms_need_terminator_in_bash(run_shfmt):
    """bash reads ${ y} as a parameter expansion, so it hits EOF unmatched."""
    # CATCHES: the mksh command-substitution spellings ${ stmts;} and
    # ${|stmts;} never finish in bash -- the diagnostic is the generic
    # unmatched-brace message at the opening ${.
    for src in ("x=${ y}\n", "x=${|y}\n"):
        res = run_shfmt(["-ln=bash", "-"], src)
        assert res.returncode == 1, src
        assert res.stderr == (
            "<standard input>:1:3: reached EOF without matching `${` with `}`\n"
        ), src


def test_param_exp_indirection_gated_in_posix(run_shfmt):
    """${!x} is bash/mksh only, and the message names the fixed form."""
    # CATCHES: the gating diagnostic always says `${!foo}` no matter which
    # name was actually written in the script.
    res = run_shfmt(["-ln=posix", "-"], "echo ${!x}\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:6: `${!foo}` is a bash/mksh feature; "
        "tried parsing as posix\n"
    )
