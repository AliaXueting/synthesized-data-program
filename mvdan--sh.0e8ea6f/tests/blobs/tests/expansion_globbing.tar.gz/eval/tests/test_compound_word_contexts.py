"""Words inside compound statements, heredocs and redirect targets.

Every construct that carries words beyond a simple command: if/elif/else and
loop bodies, for-loop word lists and C-style headers, function declarations,
let words and declare arrays, heredoc bodies with expansions, and the many
redirect spellings that decide where a word ends and a redirect begins.
"""


def test_if_elif_else_layout(run_shfmt):
    """A full if/elif/else chain keeps its reserved-word layout."""
    # CATCHES: the `; then` spelling and the tab-indented bodies are part of
    # the canonical layout; elif bodies are indented one level like then.
    src = (
        "if [ -f x ]; then\n\techo a\nelif [ -f y ]; then\n\techo b\n"
        "else\n\techo c\nfi\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_while_and_until_one_liners(run_shfmt):
    """while/until keep `; do` on the same line, one-liners stay one line."""
    # CATCHES: a while with its body on one line must not gain a newline
    # before do, while the multi-line until keeps its block layout.
    src = (
        "while read -r line; do\n\techo \"$line\"\ndone\n"
        "until [ $x -gt 3 ]; do echo; done\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_for_word_list_keeps_word_kinds(run_shfmt):
    """The for-loop word list keeps globs, quotes and expansions as written."""
    # CATCHES: *.txt, "a b" and $list are three different word kinds that
    # must each survive in the list without being merged or re-quoted.
    src = "for f in *.txt \"a b\" $list; do\n\techo \"$f\"\ndone\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_for_c_style_header_spacing(run_shfmt):
    """A C-style for header gets canonical spacing inside the ((...))."""
    # CATCHES: the arithmetic inside the for header follows the same spacing
    # rules as $((...)) -- spaces around binary operators, none after `(`.
    src = "for (( i = 0; i < 10; i++ )); do\n\techo $i\ndone\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == "for ((i = 0; i < 10; i++)); do\n\techo $i\ndone\n"
    assert res.stderr == ""


def test_select_menu(run_shfmt):
    """A select loop parses and prints with the same shape as for."""
    # CATCHES: select is a distinct reserved word that shares the loop layout;
    # its word list keeps the plain spelling.
    src = "select opt in a b; do\n\techo $opt\ndone\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_function_declaration_forms(run_shfmt):
    """Both bash `function foo` and posix `foo()` forms are preserved."""
    # CATCHES: the two declaration forms must each keep their own spelling --
    # neither gains nor loses the function keyword or the parentheses.
    src = "function foo {\n\techo bar\n}\nbar() {\n\techo baz\n}\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_coproc_time_and_let_words(run_shfmt):
    """coproc, time -p and let words keep their argument shapes."""
    # CATCHES: coproc takes a name plus a brace group on one line, time keeps
    # its -p flag glued, and let words keep their inner quoting untouched.
    src = (
        "coproc mycop { echo hi; }\n"
        "time ls -l\n"
        "time -p sleep 1\n"
        "let \"a = 1 + 2\" b=3*4\n"
        "let a++\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_declare_array_assignment_forms(run_shfmt):
    """declare/local/export keep array literals and default expansions."""
    # CATCHES: indexed and associative array literals, the -A/-r flags and the
    # ${y:-z} default word inside an assignment all survive byte-for-byte.
    src = (
        "declare -a arr=(1 2 3)\n"
        "declare -A assoc=([k]=v [j]=w)\n"
        "local -r x=${y:-z}\n"
        "export PATH=\"$PATH:/opt\"\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_heredoc_body_expansions_normalised(run_shfmt):
    """An unquoted heredoc body keeps expansions and normalises backticks."""
    # CATCHES: $x and $(echo hi) stay live in the body, the backtick command
    # substitution becomes $(...), and \$escaped keeps its backslash.
    src = (
        "cat <<EOF\n"
        "value: $x\n"
        "cmd: $(echo hi)\n"
        "tick: `echo tick`\n"
        "esc: \\$escaped\n"
        "EOF\n"
    )
    expected = (
        "cat <<EOF\n"
        "value: $x\n"
        "cmd: $(echo hi)\n"
        "tick: $(echo tick)\n"
        "esc: \\$escaped\n"
        "EOF\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == ""


def test_heredoc_dash_form_strips_tabs(run_shfmt):
    """<<- keeps leading tabs in the body but drops them on the delimiter."""
    # CATCHES: only the delimiter line loses its tab; the body indentation is
    # preserved exactly, because <<- strips tabs at run time too.
    src = "cat <<-EOF\n\tindented $v\n\tEOF\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == "cat <<-EOF\n\tindented $v\nEOF\n"
    assert res.stderr == ""


def test_heredoc_unclosed_at_eof_is_completed(run_shfmt):
    """A heredoc left unclosed at EOF still formats, with the delimiter added."""
    # CATCHES: unlike a missing quote, an unterminated heredoc is recovered:
    # exit status stays 0 and the closing delimiter line is emitted.
    src = "cat <<EOF\nline $x\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == "cat <<EOF\nline $x\nEOF\n"
    assert res.stderr == ""


def test_heredoc_quoted_delimiter_keeps_body_literal(run_shfmt):
    """A quoted delimiter disables expansion inside the body."""
    # CATCHES: with <<'EOF' the body's $ and $( stay literal characters of
    # the text, so they must be reproduced without any normalisation.
    src = "cat <<'EOF'\n$literal $(cmd)\nEOF\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_redirect_fd_word_forms(run_shfmt):
    """FD-attached redirects keep their glued spelling and target words."""
    # CATCHES: {myfd}>out is a brace-named fd redirect, 2>>err a numbered
    # append and 4<>rw a read-write open -- each operator and its target word
    # must stay attached exactly as written.
    src = "echo {myfd}>out 2>>err 3<&0 4<>rw 5>|c\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_redirect_glued_word_gets_spaced(run_shfmt):
    """A plain word glued before > is split off with a space."""
    # CATCHES: foo>out is not an fd redirect, so the formatter separates the
    # word from the redirect operator, unlike {myfd}>out which stays glued.
    res = run_shfmt(["-"], "echo foo>out\n")
    assert res.returncode == 0
    assert res.stdout == "echo foo >out\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "echo {myfd}>out\n")
    assert res.returncode == 0
    assert res.stdout == "echo {myfd}>out\n"
    assert res.stderr == ""


def test_redirect_array_element_fd(run_shfmt):
    """A bash {name[idx]}> redirect is accepted as an array-element fd."""
    # CATCHES: the brace-word lexer accepts an array subscript inside the fd
    # braces, a form only valid in bash-like dialects.
    res = run_shfmt(["-"], "echo {arr[i]}>out\n")
    assert res.returncode == 0
    assert res.stdout == "echo {arr[i]}>out\n"
    assert res.stderr == ""


def test_word_glued_process_substitution(run_shfmt):
    """A word immediately followed by >(cmd) keeps them glued."""
    # CATCHES: >(consumer) after x without a space is still one redirect with
    # a process substitution target, not a separate > argument.
    res = run_shfmt(["-"], "echo x>(consumer)\n")
    assert res.returncode == 0
    assert res.stdout == "echo x>(consumer)\n"
    assert res.stderr == ""


def test_statement_operators_with_words(run_shfmt):
    """Negation, chains, background and pipe-and operators are preserved."""
    # CATCHES: |& and &> and &>> are three distinct operator spellings, and
    # both redirect forms drop the space before their target word.
    src = (
        "! true && false || true\n"
        "sleep 1 &\n"
        "cmd |& tee log\n"
        "cmd &> /dev/null\n"
        "cmd &>> log\n"
    )
    expected = (
        "! true && false || true\n"
        "sleep 1 &\n"
        "cmd |& tee log\n"
        "cmd &>/dev/null\n"
        "cmd &>>log\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == ""


def test_comment_after_assignment_and_redirect(run_shfmt):
    """Trailing comments align to one column across adjacent statements."""
    # CATCHES: each comment is padded so the # marks line up under the longest
    # statement of the group (here `echo hi >f`), regardless of whether the
    # statement ends with an assignment, a redirect or a plain word.
    src = (
        "x=1 # trailing assign comment\n"
        "echo hi >f # trailing redirect comment\n"
        "foo bar # cmd comment\n"
    )
    expected = (
        "x=1        # trailing assign comment\n"
        "echo hi >f # trailing redirect comment\n"
        "foo bar    # cmd comment\n"
    )
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == ""
