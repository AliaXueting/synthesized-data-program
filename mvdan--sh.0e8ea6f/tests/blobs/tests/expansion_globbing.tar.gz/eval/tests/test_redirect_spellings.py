"""Redirect operator spellings across dialects.

The full &> family, the zsh clobber spellings and their normalisation
(&>! becomes &>|), the zsh &|/&! pipeline operators, and the posix
rejection of &> redirects.
"""


def test_bash_redirect_operator_family(run_shfmt):
    """<&,>&,<>,2>,<<<,&> and &>> all lose the space before their target."""
    # CATCHES: every redirect operator glues to the following word, and the
    # here-string <<< is one operator token, not << plus a literal <.
    cases = [
        ("cmd <in\n", "cmd <in\n"),
        ("cmd >&2\n", "cmd >&2\n"),
        ("cmd <&3\n", "cmd <&3\n"),
        ("cmd <>file\n", "cmd <>file\n"),
        ("cmd 2>out\n", "cmd 2>out\n"),
        ("cat <<< hi\n", "cat <<<hi\n"),
        ("cmd &>all\n", "cmd &>all\n"),
        ("cmd &>>append\n", "cmd &>>append\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_zsh_clobber_spellings_normalise(run_shfmt):
    """zsh's >!, >>!, &>! and &>>! all reprint with the | spelling."""
    # CATCHES: `!` and `|` select the same clobber operator enum value, so
    # the printer always emits the vertical-bar spelling.
    cases = [
        ("cmd >|force\n", "cmd >|force\n"),
        ("cmd >!force\n", "cmd >|force\n"),
        ("cmd >>|app\n", "cmd >>|app\n"),
        ("cmd >>!app\n", "cmd >>|app\n"),
        ("cmd &>|all\n", "cmd &>|all\n"),
        ("cmd &>!all\n", "cmd &>|all\n"),
        ("cmd &>>|app2\n", "cmd &>>|app2\n"),
        ("cmd &>>!app2\n", "cmd &>>|app2\n"),
    ]
    for src, expected in cases:
        res = run_shfmt(["-ln=zsh", "-"], src)
        assert res.returncode == 0, src
        assert res.stdout == expected, src
        assert res.stderr == "", src


def test_zsh_amp_pipe_operators(run_shfmt):
    """zsh &| and &! both background the pipeline and print as `&|`."""
    # CATCHES: the two spellings map to one operator that terminates the
    # statement, so the next command moves to its own line and the printed
    # form is always `&|`.
    for src in ("cmd &| cmd2\n", "cmd &! cmd2\n"):
        res = run_shfmt(["-ln=zsh", "-"], src)
        assert res.returncode == 0, src
        assert res.stdout == "cmd &|\ncmd2\n", src
        assert res.stderr == "", src


def test_posix_rejects_amp_redirect(run_shfmt):
    """posix rejects &> with the dialect-gating message at the operator."""
    # CATCHES: the message names the operator text `&>` and lists the three
    # dialects that allow it, positioned at the `&`.
    res = run_shfmt(["-ln=posix", "-"], "cmd &> out\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:5: `&>` redirects are a bash/mksh/zsh feature; "
        "tried parsing as posix\n"
    )
