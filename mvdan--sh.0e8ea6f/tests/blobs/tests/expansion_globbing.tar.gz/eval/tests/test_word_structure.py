"""Word and quoting structure: how the formatter treats quoted segments.

Quoting decides where field splitting and globbing happen, so the reference
preserves the exact quoting style the author chose.  These tests pin that
behaviour for every quote form and for words built from several parts.
"""

import json

QUOTE_SNIPPETS = [
    'echo ""',
    "echo ''",
    'echo "abc"',
    "echo 'abc'",
    'echo "a\'b"',
    'echo \'a"b\'',
    'echo $\'a\'',
    'echo $"a"',
    'echo "a"b"c"',
    'echo a"b"c',
    'echo \\$x',
    'echo \\"',
    'echo "a\\"b"',
]


def test_quote_forms_roundtrip(run_shfmt):
    """Every quoting style is echoed back with the same characters."""
    # CATCHES: single and double quotes, $'...' and $"..." and backslash
    # escapes all have distinct expansion semantics and must not be swapped.
    for snippet in QUOTE_SNIPPETS:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet
        assert res.stderr == "", snippet


def test_adjacent_quoted_parts_are_not_merged(run_shfmt):
    """"a"b"c" stays three parts; the middle b is an unquoted literal."""
    # CATCHES: merging them would change where field splitting can occur, so
    # the three segments must remain distinguishable in the output.
    res = run_shfmt([], 'echo "a"b"c"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "a"b"c"\n'
    assert res.stderr == ""


def test_tojson_splits_word_into_parts(run_shfmt):
    """--to-json shows a mixed word as separate Lit and quoted parts."""
    # CATCHES: the tree for a"$b" must be [Lit, DblQuoted[ParamExp]] and not
    # one merged literal, proving the formatter models quoting boundaries.
    res = run_shfmt(["--to-json"], 'echo a"$b"\n')
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    parts = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"]
    assert [p["Type"] for p in parts] == ["Lit", "DblQuoted"]
    assert parts[0]["Value"] == "a"
    assert parts[1]["Parts"][0]["Type"] == "ParamExp"


def test_tojson_single_quoted_part(run_shfmt):
    """A single-quoted literal becomes one SglQuoted part."""
    # CATCHES: the node type records which quote was used, which is what lets
    # the printer reproduce the author's choice exactly.
    res = run_shfmt(["--to-json"], "echo 'a b'\n")
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    parts = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"]
    assert len(parts) == 1
    assert parts[0]["Type"] == "SglQuoted"
    assert parts[0]["Value"] == "a b"
    assert "Dollar" not in parts[0]


def test_tojson_dollar_quoted_is_flagged(run_shfmt):
    """$'...' is a different node state from plain '...'."""
    # CATCHES: the Dollar flag is what separates the ANSI-C quoting style
    # from an ordinary single-quoted literal in the typed tree.
    res = run_shfmt(["--to-json"], "echo $'a'\n")
    assert res.returncode == 0
    assert res.stderr == ""
    tree = json.loads(res.stdout)
    parts = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"]
    assert parts[0]["Type"] == "SglQuoted"
    assert parts[0]["Dollar"] is True


def test_escaped_glob_characters_roundtrip(run_shfmt):
    """A backslash before a metacharacter is kept as written."""
    # CATCHES: a\\*b means the star is literal, so removing the backslash
    # would silently turn a literal word into a glob pattern.
    res = run_shfmt([], "echo a\\*b\n")
    assert res.returncode == 0
    assert res.stdout == "echo a\\*b\n"
    assert res.stderr == ""


def test_assignment_words_keep_their_quoting(run_shfmt):
    """Quoting inside an assignment value is preserved, not normalised."""
    # CATCHES: a="$x" and a=$x differ in word splitting for the result, so
    # the reference never rewrites one into the other.
    for snippet in ["a=$x", 'a="$x"', "a=${x}", "a=${x}b"]:
        res = run_shfmt([], snippet + "\n")
        assert res.returncode == 0, snippet
        assert res.stdout == snippet + "\n", snippet


def test_redirection_target_word_roundtrip(run_shfmt):
    """A redirection target is a word: its quoting and spacing are kept."""
    # CATCHES: the space between > and its target disappears, but the target
    # itself ($f, still quoted) is preserved verbatim.
    res = run_shfmt([], 'echo hi >"$f"\n')
    assert res.returncode == 0
    assert res.stdout == 'echo hi >"$f"\n'
    assert res.stderr == ""


def test_leading_redirect_word_order(run_shfmt):
    """A redirect placed before the command keeps its position."""
    # CATCHES: `> $f echo hi` must not be reordered into `echo hi >$f`; only
    # the padding between the operator and the word is removed.
    res = run_shfmt([], "> $f echo hi\n")
    assert res.returncode == 0
    assert res.stdout == ">$f echo hi\n"
    assert res.stderr == ""


def test_fd_redirect_word_roundtrip(run_shfmt):
    """A numbered redirect keeps its fd prefix and loses the padding."""
    # CATCHES: 2> /dev/null becomes 2>/dev/null -- the fd digit stays glued
    # to the operator while the space before the target disappears.
    res = run_shfmt([], "echo hi 2> /dev/null\n")
    assert res.returncode == 0
    assert res.stdout == "echo hi 2>/dev/null\n"
    assert res.stderr == ""


def test_dollar_quoted_string_roundtrip(run_shfmt):
    """$'...' escapes are passed through without interpretation."""
    # CATCHES: \\n inside $'...' is a run-time escape, so the formatter must
    # not expand it, re-spell it or convert the quoting style.
    res = run_shfmt([], "echo $'\\n\\t'\n")
    assert res.returncode == 0
    assert res.stdout == "echo $'\\n\\t'\n"
    assert res.stderr == ""


def test_space_separated_arguments_unchanged(run_shfmt):
    """Word boundaries between arguments are kept exactly as typed."""
    # CATCHES: multiple spaces between words collapse to one, but the words
    # themselves -- here three differently quoted ones -- are untouched.
    res = run_shfmt([], 'echo  "$a"   \'b\'   c\n')
    assert res.returncode == 0
    assert res.stdout == 'echo "$a" \'b\' c\n'
    assert res.stderr == ""
