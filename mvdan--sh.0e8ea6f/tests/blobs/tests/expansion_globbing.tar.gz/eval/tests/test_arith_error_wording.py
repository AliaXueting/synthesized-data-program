"""Arithmetic-expression diagnostics and assignability rules.

The exact wording for invalid operators, broken ternaries, bracket and
comma misuse, which left-hand sides may be assigned to (names and a[i],
but not $x), and the zsh-only floating point syntax.
"""


def test_invalid_operator_wording(run_shfmt):
    """A non-operator word inside $((...)) is named in backquotes."""
    # CATCHES: the lexer reports the literal word, quoted with backticks,
    # at the column where the operator was expected.
    res = run_shfmt(["-"], "echo $((1 foo 2))\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:11: not a valid arithmetic operator: `foo`\n"
    )


def test_ternary_operator_errors(run_shfmt):
    """A ternary missing either side names the missing punctuation."""
    # CATCHES: `:` without `?` and `?` without `:` are separate messages
    # that both point at the operator token that revealed the problem.
    res = run_shfmt(["-"], "echo $((1 : 2))\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:11: ternary operator missing `?` before `:`\n"
    )

    res = run_shfmt(["-"], "echo $((1 ? 2))\n")
    assert res.returncode == 1
    assert res.stderr == (
        "<standard input>:1:11: ternary operator missing `:` after `?`\n"
    )


def test_bracket_and_comma_errors(run_shfmt):
    """Brackets must hold an expression; commas must sit between expressions."""
    # CATCHES: an unclosed `[` in arithmetic and a dangling `,` each have
    # their own wording, including the reached-`)`-without-`]` variant.
    cases = [
        ("echo $((a[))\n",
         "<standard input>:1:10: `[` must be followed by an expression\n"),
        ("echo $((x[1))\n",
         "<standard input>:1:10: reached `)` without matching `[` with `]`\n"),
        ("echo $((1,))\n",
         "<standard input>:1:10: `,` must be followed by an expression\n"),
        ("echo $((,1))\n",
         "<standard input>:1:9: `,` must follow an expression\n"),
    ]
    for src, err in cases:
        res = run_shfmt(["-"], src)
        assert res.returncode == 1, src
        assert res.stdout == "", src
        assert res.stderr == err, src


def test_assignment_target_rules(run_shfmt):
    """Arithmetic assignment needs a bare name or a[i] index on the left."""
    # CATCHES: x = 1 and a[0] = 1 are assignments but $x = 1 and 1 = 2 are
    # rejected with `=` must follow a name`, all reprinted with spacing.
    res = run_shfmt(["-"], "echo $((x = 1, y = 2))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((x = 1, y = 2))\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "echo $((a[0] = 1))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((a[0] = 1))\n"
    assert res.stderr == ""

    res = run_shfmt(["-"], "echo $((1 = 2))\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:11: `=` must follow a name\n"

    res = run_shfmt(["-"], "echo $(($x = 1))\n")
    assert res.returncode == 1
    assert res.stderr == "<standard input>:1:12: `=` must follow a name\n"


def test_floating_point_is_zsh_only(run_shfmt):
    """A decimal point in arithmetic is a zsh feature; bash rejects it."""
    # CATCHES: the period is lexed as a token of its own in bash and gets
    # the dialect-gating message, while zsh keeps 1.5 as one literal word.
    res = run_shfmt(["-ln=bash", "-"], "echo $((1.5))\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "<standard input>:1:10: floating point arithmetic is a zsh feature; "
        "tried parsing as bash\n"
    )

    res = run_shfmt(["-ln=zsh", "-"], "echo $((1.5))\n")
    assert res.returncode == 0
    assert res.stdout == "echo $((1.5))\n"
    assert res.stderr == ""


def test_unary_operator_spelling(run_shfmt):
    """Unary !, + and - gain a space; ++ and -- stay glued to their name."""
    # CATCHES: the printer separates single-char unary operators from their
    # operand but keeps the increment/decrement spellings attached.
    res = run_shfmt(["-"], "r=$((!a + -b - +c - ~d - ++e - --f))\n")
    assert res.returncode == 0
    assert res.stdout == "r=$((! a + -b - +c - ~d - ++e - --f))\n"
    assert res.stderr == ""
