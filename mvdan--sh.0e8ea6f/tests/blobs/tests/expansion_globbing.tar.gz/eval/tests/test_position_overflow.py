"""Position rendering when line or column numbers overflow their bits.

Positions store the column in 14 bits and the line in 18 bits; beyond those
limits the numbers are replaced by a question mark in diagnostics.  The
thresholds are observable through the column of an error inside an
over-long line and the line of an error in a very tall file.
"""


def test_column_overflow_renders_question_mark(run_shfmt):
    """An error past column 16383 prints ? as the column."""
    # CATCHES: positions clamp overflowing columns to zero, which renders as
    # "?" -- the diagnostic reads 1:? instead of the true column 16402.
    src = "x" * 16400 + " '\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:1:?: reached EOF without closing quote `'`\n"


def test_column_overflow_line_still_formats(run_shfmt):
    """An over-long but valid word round-trips unchanged."""
    # CATCHES: clamping only affects position reporting; the 16400-byte
    # literal itself is preserved byte for byte by the formatter.
    src = "x" * 16400 + "\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == ""


def test_line_overflow_renders_question_mark(run_shfmt):
    """An error on a line past 262143 prints ? as the line number."""
    # CATCHES: lines beyond the 18-bit maximum clamp to zero and render as
    # "?", while the column (6) is still reported -- the diagnostic reads
    # ?:6 for the unterminated quote on line 262152.
    src = "\n" * 262150 + "echo '\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<standard input>:?:6: reached EOF without closing quote `'`\n"


def test_line_overflow_file_still_formats(run_shfmt):
    """A quarter-million blank lines do not disturb formatting."""
    # CATCHES: the tall file parses and formats normally; only error
    # positions are affected by the line clamp, never the output.
    src = "\n" * 262150 + "echo hi\n"
    res = run_shfmt(["-"], src)
    assert res.returncode == 0
    assert res.stdout == "echo hi\n"
    assert res.stderr == ""
