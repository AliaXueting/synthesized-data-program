"""The hand-written flag validations in main(): exact messages and exit 1."""

import pytest
from conftest import USAGE, run_shfmt, write_script

POSIX_LANG_ERROR = b"-p and -ln=lang cannot coexist\n"
FN_BL_ERROR = b"-fn and -bl cannot coexist; note that -fn is deprecated\n"
LIST_ERROR = b"only -l and -l=0 allowed\n"
FIND_ERROR = b"only -f and -f=0 allowed\n"
DETECT_ERROR = b"--detect only allows default, exec, or all\n"


@pytest.mark.parametrize(
    "args",
    [
        ["-p", "-ln=posix"],
        ["-p", "-ln=bash"],
        ["-ln=posix", "-p"],
        ["--posix", "-ln=posix"],
        ["-p", "--language-dialect=bash"],
        ["--language-dialect=mksh", "--posix"],
    ],
)
def test_posix_and_language_dialect_cannot_coexist(args):
    """-p together with any -ln value fails with a fixed message."""
    # CATCHES: the message names both flags regardless of which spelling or
    # order was used, and no language value (not even posix) is exempt.
    res = run_shfmt(args, stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == POSIX_LANG_ERROR


@pytest.mark.parametrize(
    "args",
    [
        ["-fn", "-bl"],
        ["-bl", "-fn"],
        ["--func-next-line", "-bl"],
        ["-fn", "--block-next-line"],
        ["--func-next-line", "--block-next-line"],
    ],
)
def test_func_next_line_and_block_next_line_cannot_coexist(args):
    """-fn together with -bl fails, mentioning that -fn is deprecated."""
    # CATCHES: the exact wording including the deprecation note, and the fact
    # that the check is order-independent.
    res = run_shfmt(args, stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == FN_BL_ERROR


@pytest.mark.parametrize(
    "flag", ["-l=1", "-l=2", "-l=true ", "--list=1", "--list=yes", "-l=TRUE", "-l=0\n", "-l=00"]
)
def test_list_flag_only_allows_bare_or_zero(flag):
    """-l only accepts the bare flag, -l=0 and the internal true/false."""
    # CATCHES: values like '1', 'yes', 'TRUE' or '00' are rejected with a
    # message naming only the -l and -l=0 forms.
    res = run_shfmt([flag], stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == LIST_ERROR


@pytest.mark.parametrize("flag", ["-f=1", "-f=2", "--find=x", "--find=yes", "-f=TRUE"])
def test_find_flag_only_allows_bare_or_zero(flag):
    """-f only accepts the bare flag, -f=0 and the internal true/false."""
    # CATCHES: -f shares the boolString flag type with -l but has its own
    # error message naming -f and -f=0.
    res = run_shfmt([flag], stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == FIND_ERROR


@pytest.mark.parametrize(
    "args",
    [
        ["--detect=bogus"],
        ["--detect="],
        ["--detect=DEFAULT"],
        ["--detect", "nope"],
        ["--detect=Exec"],
        ["--detect=all-files"],
    ],
)
def test_detect_only_allows_three_documented_values(args):
    """--detect rejects anything but default, exec and all, case-sensitively."""
    # CATCHES: the comparison is exact, so 'DEFAULT' and 'Exec' are rejected
    # just like arbitrary strings.
    res = run_shfmt(args, stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == DETECT_ERROR


@pytest.mark.parametrize("value", ["default", "exec", "all"])
def test_detect_accepts_its_documented_values(value):
    """The three documented --detect values run normally."""
    # CATCHES: an over-strict validator would reject a legal value and turn a
    # successful formatting run into an error.
    res = run_shfmt(["--detect=" + value], stdin=b"echo   hi\n")
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "flag,stdout,returncode",
    [
        ("-l=true", b"messy.sh\n", 1),
        ("-l=false", b"echo hi\n", 0),
        ("-l=0", b"messy.sh\x00", 1),
    ],
)
def test_list_flag_explicit_values_are_honoured(tmp_path, flag, stdout, returncode):
    """-l=true, -l=false and -l=0 select list, no-list and NUL-separated."""
    # CATCHES: the boolString flag keeps its string value, so 'false' really
    # disables listing (formatting is printed, exit 0) rather than erroring.
    write_script(tmp_path, "messy.sh", b"echo   hi\n")
    res = run_shfmt([flag, "messy.sh"], cwd=tmp_path)
    assert res.returncode == returncode
    assert res.stdout == stdout
    assert res.stderr == b""


def test_find_flag_explicit_values_are_honoured(tmp_path):
    """--find=true and -f=0 both list files, with their own separators."""
    # CATCHES: like -l, the -f flag accepts 'true' and '0' values; 'true'
    # separates paths with newlines and '0' with NUL bytes.
    write_script(tmp_path, "one.sh", b"echo hi\n")
    res = run_shfmt(["--find=true", "one.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"one.sh\n"
    assert res.stderr == b""
    res = run_shfmt(["-f=0", "one.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"one.sh\x00"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "args,expected",
    [
        (["-p", "-ln=posix", "-fn", "-bl", "-l=1", "-f=1", "--detect=x"], POSIX_LANG_ERROR),
        (["-fn", "-bl", "-l=1", "-f=1", "--detect=x"], FN_BL_ERROR),
        (["-l=1", "-f=1", "--detect=x"], LIST_ERROR),
        (["-f=1", "--detect=x"], FIND_ERROR),
        (["--detect=x"], DETECT_ERROR),
    ],
)
def test_validations_report_the_first_failing_check(args, expected):
    """The validations run in a fixed order and stop at the first failure."""
    # CATCHES: the order is -p/-ln, then -fn/-bl, then -l, then -f, then
    # --detect; a different order reports a different message.
    res = run_shfmt(args, stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == expected


def test_validation_errors_do_not_print_the_usage_text(tmp_path):
    """Hand-written validation failures print one line, unlike flag errors."""
    # CATCHES: flag parsing problems exit 2 with the usage text appended,
    # while these validations exit 1 with a single bare line on stderr.
    write_script(tmp_path, "f.sh", b"echo   hi\n")
    res = run_shfmt(["-l=1", "f.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == LIST_ERROR
    assert res.stderr != LIST_ERROR + USAGE


def test_validation_happens_before_any_input_is_processed(tmp_path):
    """A validation failure leaves files untouched and prints nothing else."""
    # CATCHES: the checks run before the walk, so no formatting output and no
    # 'lstat' error for the second, non-existent path may appear.
    write_script(tmp_path, "f.sh", b"echo   hi\n")
    res = run_shfmt(["-p", "-ln=posix", "f.sh", "missing.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == POSIX_LANG_ERROR
    assert (tmp_path / "f.sh").read_bytes() == b"echo   hi\n"
