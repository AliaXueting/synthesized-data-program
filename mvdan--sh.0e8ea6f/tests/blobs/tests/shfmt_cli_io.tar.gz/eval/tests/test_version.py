"""Behavior of the --version / -version flag."""

import pytest
from conftest import VERSION, run_shfmt


def test_version_long_flag_prints_build_version():
    """--version prints the build version on stdout and exits 0."""
    # CATCHES: a re-implementation that prints the version to stderr, exits
    # non-zero, or prints a differently formatted version line breaks here.
    res = run_shfmt(["--version"])
    assert res.returncode == 0
    assert res.stdout == VERSION
    assert res.stderr == b""


def test_version_short_flag_matches_long_flag():
    """-version is an accepted spelling and prints the very same line."""
    # CATCHES: only one of the two spellings being registered as a flag.
    res = run_shfmt(["-version"])
    assert res.returncode == 0
    assert res.stdout == VERSION
    assert res.stderr == b""


@pytest.mark.parametrize("flag", ["--version=1", "--version=true", "--version=t"])
def test_version_accepts_explicit_true_value(flag):
    """--version is a boolean flag, so '=true'-style spellings also work."""
    # CATCHES: implementing --version as a string flag would reject
    # '--version=1' with a flag parsing error instead of printing the version.
    res = run_shfmt([flag])
    assert res.returncode == 0
    assert res.stdout == VERSION
    assert res.stderr == b""


@pytest.mark.parametrize("flag", ["--version=false", "--version=0"])
def test_version_false_value_falls_through_to_formatting(flag):
    """An explicit false value leaves the tool in normal formatting mode."""
    # CATCHES: a re-implementation that prints the version whenever the flag
    # merely appears (instead of honouring its value) would print the version
    # here rather than formatting standard input.
    res = run_shfmt([flag], stdin=b"echo   hi\n")
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "args",
    [
        ["--version", "-p", "-ln=posix"],
        ["--version", "-fn", "-bl"],
        ["--version", "-l=1"],
        ["--version", "--detect=unknown"],
        ["-p", "-ln=posix", "--version"],
        ["-l=1", "--version"],
    ],
)
def test_version_wins_over_validation_errors(args):
    """--version short-circuits every hand-written validation in main()."""
    # CATCHES: the version check runs before the -p/-ln, -fn/-bl, -l and
    # --detect validation, so those flags must not produce an error here.
    res = run_shfmt(args)
    assert res.returncode == 0
    assert res.stdout == VERSION
    assert res.stderr == b""


def test_version_wins_over_path_arguments():
    """--version ignores path arguments instead of walking them."""
    # CATCHES: a version check placed after input routing would report the
    # missing path 'does-not-exist.sh' instead of printing the version.
    res = run_shfmt(["--version", "does-not-exist.sh", "-w"])
    assert res.returncode == 0
    assert res.stdout == VERSION
    assert res.stderr == b""


def test_version_does_not_read_standard_input():
    """--version never consumes stdin, so an empty pipe is fine."""
    # CATCHES: a re-implementation that reads stdin before checking --version
    # would hang or produce formatting output alongside the version.
    res = run_shfmt(["--version"], stdin=b"echo   badly   spaced\n")
    assert res.returncode == 0
    assert res.stdout == VERSION
    assert res.stderr == b""
