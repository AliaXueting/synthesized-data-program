"""Shared black-box helpers for the shfmt_cli_io test module.

Every expectation embedded below was recorded by running the reference
`shfmt` binary through its command line interface only.  Tests never call
into the binary's internals and never hardcode a path to it: the executable
location always comes from PROGRAMGYM_EXECUTABLE.
"""

import functools
import os
import pty
import select
import subprocess
import tempfile
import termios
import threading
import time
from pathlib import Path

# Exact bytes that 'shfmt -h', 'shfmt --help' and every flag parsing error
# print on standard error (44 lines, no trailing blank line).
USAGE = b"""usage: shfmt [flags] [path ...]

shfmt formats shell programs. If the only argument is a dash ('-') or no
arguments are given, standard input will be used, unless it is a terminal.
If a given path is a directory, all shell scripts found under that directory
will be used.

  --version  show version and exit

  -l[=0], --list[=0]  error with a list of files whose formatting differs from shfmt;
                      paths are separated by a newline or a null character if -l=0
  -w,     --write     write result to file instead of stdout
  -d,     --diff      error with a diff when the formatting differs
  --apply-ignore      always apply EditorConfig ignore rules
  --detect str        how to detect shell files when walking: default, exec, or all
  --filename str      provide a name for the standard input file

Parser options:

  -ln, --language-dialect str  bash/posix/mksh/bats/zsh, default "auto"
  -p,  --posix                 shorthand for -ln=posix
  -s,  --simplify              simplify the code

Printer options:

  -i,  --indent uint       0 for tabs (default), >0 for number of spaces
  -bn, --binary-next-line  binary ops like && and | may start a line
  -ci, --case-indent       switch cases will be indented
  -sr, --space-redirects   redirect operators will be followed by a space
  -kp, --keep-padding      keep column alignment paddings
  -fn, --func-next-line    function opening braces are placed on a separate line (deprecated; use -bl)
  -bl, --block-next-line   multi-line block opening tokens like '{', 'then', and 'do' are placed on a separate line
  -mn, --minify             minify the code to reduce its size (implies -s)

Utilities:

  -f[=0], --find[=0]  recursively find all shell files and print the paths;
                      paths are separated by a newline or a null character if -f=0
  --to-json           print syntax tree to stdout as a typed JSON
  --from-json         read syntax tree from stdin as a typed JSON

Formatting options can also be read from EditorConfig files; see 'man shfmt'
for a detailed description of the tool's behavior.
For more information and to report bugs, see https://github.com/mvdan/sh.
"""

# Exact bytes printed by 'shfmt --version' (the version baked into the build).
VERSION = b"v3.0.0-20261012132700-0e8ea6fccd96\n"

# The name shfmt uses for the standard input stream in messages.
STDIN_NAME = b"<standard input>"


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--version' once against a throwaway GOCOVERDIR, so the
    check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="shfmt-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def shfmt_executable():
    """Return the binary under test, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the shfmt binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but the
    # pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to the
    # module's uninstrumented copy before pytest starts, so the counters would
    # never be written and this module's coverage report would stay empty.
    # During a coverage run (GOCOVERDIR present), when the assigned binary is
    # not itself instrumented, fall back to the instrumented build the driver
    # stages next to the module workspaces.  The staged file only exists in
    # that layout, so ordinary validation and release runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(str(staged)):
            return str(staged)
    return path


def _pinned_env(cwd=None, env=None):
    """Build the child environment from scratch: no TTY, no color, no noise.

    TERM, NO_COLOR and FORCE_COLOR are deliberately absent unless a test asks
    for them, so diff coloring and terminal detection are fully controlled.
    """
    child = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
    }
    # Forwarded only so a coverage-instrumented binary can write its counters;
    # the shfmt behavior under test never reads these.
    for passthrough in ("GOCOVERDIR",):
        if os.environ.get(passthrough):
            child[passthrough] = os.environ[passthrough]
    if cwd is not None:
        # Point HOME at the sandbox directory so no user-level EditorConfig
        # file can leak into the run.
        child["HOME"] = str(cwd)
    if env:
        child.update(env)
    return child


def run_shfmt(args, stdin=b"", cwd=None, env=None, timeout=30):
    """Run the binary with 'args' and return the CompletedProcess result.

    stdin is always a pipe and stdout/stderr are always captured, so the
    program never sees a terminal unless run_shfmt_pty is used.
    """
    return subprocess.run(
        [shfmt_executable()] + list(args),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=_pinned_env(cwd, env),
        timeout=timeout,
    )


def run_shfmt_pty(
    args,
    stdin_data=b"",
    tty_stdin=False,
    tty_stdout=False,
    env=None,
    cwd=None,
    timeout=15.0,
):
    """Run the binary with a local pseudo-terminal attached to stdin/stdout.

    Returns a CompletedProcess whose returncode/stdout/stderr describe the
    run.  The pty is created by the test itself with OPOST and ECHO cleared,
    so the bytes the program writes are read back verbatim and nothing is
    echoed into them.  The process is killed if it does not exit within
    'timeout' seconds.
    """
    master, slave = pty.openpty()
    attrs = termios.tcgetattr(slave)
    attrs[1] &= ~termios.OPOST  # keep "\n" from turning into "\r\n"
    attrs[3] &= ~termios.ECHO  # keep our own input out of the output
    termios.tcsetattr(slave, termios.TCSANOW, attrs)

    proc = subprocess.Popen(
        [shfmt_executable()] + list(args),
        stdin=slave if tty_stdin else subprocess.PIPE,
        stdout=slave if tty_stdout else subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=_pinned_env(cwd, env),
    )
    os.close(slave)

    stderr_chunks = []

    def drain_stderr():
        stderr_chunks.append(proc.stderr.read())

    stderr_thread = threading.Thread(target=drain_stderr)
    stderr_thread.start()

    watchdog = threading.Timer(timeout, proc.kill)
    watchdog.start()
    try:
        if tty_stdin:
            # Give the child a moment to (not) consume the terminal, then
            # hand it the script followed by Ctrl-D, the terminal EOF.
            time.sleep(0.05)
            for chunk in (stdin_data, b"\x04"):
                try:
                    os.write(master, chunk)
                except OSError:
                    pass  # the child may already be gone
                time.sleep(0.05)
        else:
            if stdin_data:
                try:
                    proc.stdin.write(stdin_data)
                except (BrokenPipeError, OSError):
                    pass
            try:
                proc.stdin.close()
            except (BrokenPipeError, OSError):
                pass

        if tty_stdout:
            out = b""
            deadline = time.time() + timeout
            while time.time() < deadline:
                ready, _, _ = select.select([master], [], [], 0.1)
                if ready:
                    try:
                        chunk = os.read(master, 65536)
                    except OSError:
                        break  # the child closed the terminal
                    if not chunk:
                        break
                    out += chunk
                elif proc.poll() is not None:
                    break
        else:
            out = proc.stdout.read()

        returncode = proc.wait(timeout=timeout)
    finally:
        watchdog.cancel()
        if proc.poll() is None:
            proc.kill()
            proc.wait()
        stderr_thread.join(timeout)
        for stream in (proc.stdin, proc.stdout, proc.stderr):
            try:
                stream.close()
            except Exception:
                pass
        try:
            os.close(master)
        except OSError:
            pass

    stderr = b"".join(stderr_chunks)
    return subprocess.CompletedProcess(args, returncode, stdout=out, stderr=stderr)


def write_script(directory, name, content, mode=None):
    """Write 'content' into directory/name and return the path object."""
    path = directory / name
    path.write_bytes(content)
    if mode is not None:
        path.chmod(mode)
    return path
