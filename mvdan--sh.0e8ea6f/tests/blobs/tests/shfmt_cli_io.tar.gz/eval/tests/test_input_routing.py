"""Where input comes from: standard input versus path arguments."""

import pytest
from conftest import run_shfmt, write_script

UNTERMINATED = b'echo "unterminated\n'
UNTERMINATED_ERROR = (
    b'<standard input>:1:6: reached EOF without closing quote `"`\n'
)


def test_no_arguments_reads_standard_input():
    """With no path arguments the whole of standard input is formatted."""
    # CATCHES: a re-implementation that requires an explicit '-' (or that
    # shows usage when stdin is a pipe) would fail here.
    res = run_shfmt([], stdin=b"echo   hi\n")
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


def test_single_dash_reads_standard_input():
    """A single '-' argument is the explicit way to ask for standard input."""
    # CATCHES: treating '-' as a file name would produce an 'lstat -' error.
    res = run_shfmt(["-"], stdin=b"echo   hi\n")
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


def test_dash_after_flag_terminator_reads_standard_input():
    """'-- -' still names standard input because it is the only argument."""
    # CATCHES: after '--' a '-' must keep its special meaning as stdin rather
    # than becoming a literal path.
    res = run_shfmt(["--", "-"], stdin=b"echo   hi\n")
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


def test_parse_error_names_the_standard_input():
    """Parse errors on stdin are prefixed with '<standard input>'."""
    # CATCHES: the synthetic name used in 'name:line:col:' messages.
    res = run_shfmt([], stdin=UNTERMINATED)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == UNTERMINATED_ERROR


def test_filename_flag_renames_standard_input():
    """--filename replaces '<standard input>' in every message."""
    # CATCHES: the name is used verbatim, including any directory part.
    res = run_shfmt(["--filename=dir/myscript.sh"], stdin=UNTERMINATED)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'dir/myscript.sh:1:6: reached EOF without closing quote `"`\n'


def test_empty_filename_value_keeps_the_default_name():
    """--filename= (empty) is treated exactly like not passing the flag."""
    # CATCHES: the emptiness check is on the value, so '= ' does not count as
    # providing a name.
    res = run_shfmt(["--filename="], stdin=UNTERMINATED)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == UNTERMINATED_ERROR


def test_filename_still_reads_standard_input_with_dash():
    """--filename and '-' together keep reading standard input."""
    # CATCHES: --filename must not switch the tool into file mode.
    res = run_shfmt(["--filename=myscript.sh", "-"], stdin=b"echo   hi\n")
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "args,expected",
    [
        (["--filename=x.sh", "f.sh"], b"-filename can only be used with stdin\n"),
        (["--filename=x.sh", "-", "f.sh"], b"-filename can only be used with stdin\n"),
    ],
)
def test_filename_with_path_arguments_is_rejected(tmp_path, args, expected):
    """--filename may only be combined with standard input."""
    # CATCHES: any argument other than a lone '-' turns it into an error; the
    # message names the short spelling '-filename' whatever was typed.
    write_script(tmp_path, "f.sh", b"echo hi\n")
    res = run_shfmt(args, stdin=b"echo hi\n", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == expected


def test_to_json_with_path_arguments_is_rejected(tmp_path):
    """--to-json may only be used when reading standard input."""
    # CATCHES: the message names '--to-json' even when the deprecated
    # '--tojson' spelling was used.
    write_script(tmp_path, "f.sh", b"echo hi\n")
    for flag in ("--to-json", "--tojson"):
        res = run_shfmt([flag, "f.sh"], stdin=b"echo hi\n", cwd=tmp_path)
        assert res.returncode == 1
        assert res.stdout == b""
        assert res.stderr == b"--to-json can only be used with stdin\n"


def test_from_json_with_path_arguments_is_rejected(tmp_path):
    """--from-json may only be used when reading standard input."""
    # CATCHES: the third stdin-only flag has its own message.
    write_script(tmp_path, "f.sh", b"echo hi\n")
    res = run_shfmt(["--from-json", "f.sh"], stdin=b"{}", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"--from-json can only be used with stdin\n"


@pytest.mark.parametrize(
    "args,expected",
    [
        (["--to-json", "--from-json", "f.sh"], b"--to-json can only be used with stdin\n"),
        (["--from-json", "--to-json", "f.sh"], b"--to-json can only be used with stdin\n"),
        (["--filename=a", "--to-json", "f.sh"], b"-filename can only be used with stdin\n"),
        (["--filename=a", "--from-json", "f.sh"], b"-filename can only be used with stdin\n"),
    ],
)
def test_stdin_only_flags_are_checked_in_a_fixed_order(tmp_path, args, expected):
    """--filename is reported first, then --to-json, then --from-json."""
    # CATCHES: the checks run in that order, so mixing the flags reports a
    # predictable one of the three messages.
    write_script(tmp_path, "f.sh", b"echo hi\n")
    res = run_shfmt(args, stdin=b"{}", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == expected


@pytest.mark.parametrize("flag", ["-w", "--write", "--write=true", "-w=1"])
def test_write_cannot_be_used_on_standard_input(flag):
    """-w on standard input fails before anything is read."""
    # CATCHES: the exact message and the fact it is checked before parsing,
    # so even invalid shell input never produces a parse error here.
    res = run_shfmt([flag], stdin=UNTERMINATED)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"-w cannot be used on standard input\n"


def test_two_dashes_are_two_path_arguments():
    """'-' loses its meaning once another argument is present."""
    # CATCHES: each '-' is walked as a path and produces its own lstat error.
    res = run_shfmt(["-", "-"], stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == 2 * b"lstat -: no such file or directory\n"


def test_dash_plus_path_switches_to_file_mode(tmp_path):
    """A '-' next to a real path is walked like any other path argument."""
    # CATCHES: the real file is still formatted while '-' produces an error.
    write_script(tmp_path, "f.sh", b"echo   hi\n")
    res = run_shfmt(["-", "f.sh"], stdin=b"echo hi\n", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b"lstat -: no such file or directory\n"


def test_to_json_prints_a_tree_to_stdout():
    """--to-json on stdin writes the typed JSON tree to stdout, exit 0."""
    # CATCHES: the JSON goes to stdout with tab indentation and the run
    # succeeds even though the input was unformatted.
    res = run_shfmt(["--to-json"], stdin=b"echo   hi\n")
    assert res.returncode == 0
    assert res.stdout.startswith(b'{\n\t"Type": "File",\n')
    assert res.stdout.endswith(b"}\n")
    assert res.stderr == b""


def test_from_json_round_trips_through_the_formatter():
    """--from-json parses a tree from stdin and prints the formatted code."""
    # CATCHES: the two JSON flags must accept each other's output.
    encoded = run_shfmt(["--to-json"], stdin=b"echo   hi\n").stdout
    res = run_shfmt(["--from-json"], stdin=encoded)
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


def test_from_json_reports_invalid_input():
    """--from-json with non-JSON input fails with a decoder error."""
    # CATCHES: the JSON decoder error is printed bare (no name:line:col
    # prefix) and the exit code is 1.
    res = run_shfmt(["--from-json"], stdin=b"not json")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"invalid character 'o' in literal null (expecting 'u')\n"


def test_from_json_with_list_reports_the_stdin_name():
    """-l --from-json compares against the JSON bytes and lists stdin."""
    # CATCHES: the difference is measured between the raw JSON input and the
    # formatted code, so the stdin name is listed and the run exits 1.
    encoded = run_shfmt(["--to-json"], stdin=b"echo   hi\n").stdout
    res = run_shfmt(["-l", "--from-json"], stdin=encoded)
    assert res.returncode == 1
    assert res.stdout == b"<standard input>\n"
    assert res.stderr == b""


def test_to_json_parse_error_has_an_empty_name():
    """Parse errors under --to-json are reported without any name prefix."""
    # CATCHES: --to-json replaces the '<standard input>' name with an empty
    # string, so the message starts at the line:column part.
    res = run_shfmt(["--to-json"], stdin=UNTERMINATED)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'1:6: reached EOF without closing quote `"`\n'


def test_to_json_with_filename_reports_that_name_in_errors():
    """--filename restores a real name for --to-json parse errors."""
    # CATCHES: an explicit --filename overrides the empty name that --to-json
    # would otherwise use, so the message is prefixed normally.
    res = run_shfmt(["--to-json", "--filename=x.sh"], stdin=UNTERMINATED)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'x.sh:1:6: reached EOF without closing quote `"`\n'


def test_to_json_and_from_json_round_trip_identically():
    """--to-json --from-json re-encodes a tree to the very same bytes."""
    # CATCHES: decoding and re-encoding are inverses, so combining the flags
    # must reproduce the recorded tree byte for byte, not an empty stream.
    encoded = run_shfmt(["--to-json"], stdin=b"\n").stdout
    assert encoded == b'{\n\t"Type": "File"\n}\n'
    res = run_shfmt(["--to-json", "--from-json"], stdin=encoded)
    assert res.returncode == 0
    assert res.stdout == encoded
    assert res.stderr == b""


def test_tojson_deprecated_alias_prints_the_same_tree():
    """The deprecated --tojson spelling is still accepted and encodes alike."""
    # CATCHES: only --to-json is documented now, but the older --tojson alias
    # must keep printing the exact same tab-indented JSON tree on stdout.
    res = run_shfmt(["--tojson"], stdin=b"\n")
    assert res.returncode == 0
    assert res.stdout == b'{\n\t"Type": "File"\n}\n'
    assert res.stderr == b""


def test_filename_bashrc_selects_bash_over_the_shebang():
    """--filename=.bashrc forces the bash dialect, shebang notwithstanding."""
    # CATCHES: shell config names like .bashrc pick the dialect from the name
    # itself, so a '#!/bin/sh' shebang no longer forces POSIX parsing and the
    # bash-only '&>' redirect parses without any error.
    res = run_shfmt(
        ["--filename=.bashrc"], stdin=b"#!/bin/sh\necho hi &> /dev/null\n"
    )
    assert res.returncode == 0
    assert res.stdout == b"#!/bin/sh\necho hi &>/dev/null\n"
    assert res.stderr == b""


def test_filename_zprofile_selects_zsh():
    """--filename=.zprofile picks the zsh dialect for the standard input."""
    # CATCHES: zsh config names select zsh, which accepts parameter expansion
    # flags ('${(j: :)x}') that would be a parse error under the bash default.
    res = run_shfmt(["--filename=.zprofile"], stdin=b"echo ${(j: :)x}\n")
    assert res.returncode == 0
    assert res.stdout == b"echo ${(j: :)x}\n"
    assert res.stderr == b""
