"""Flag syntax: how the Go flag package accepts and rejects arguments."""

import pytest
from conftest import USAGE, run_shfmt, write_script


@pytest.mark.parametrize(
    "flag,reported",
    [
        ("-x", b"flag provided but not defined: -x\n"),
        ("--bogus", b"flag provided but not defined: -bogus\n"),
        ("--bogus=1", b"flag provided but not defined: -bogus\n"),
        ("-lw", b"flag provided but not defined: -lw\n"),
        ("-i2", b"flag provided but not defined: -i2\n"),
        ("-lnposix", b"flag provided but not defined: -lnposix\n"),
        ("--to", b"flag provided but not defined: -to\n"),
    ],
)
def test_unknown_flag_reports_name_and_usage(flag, reported):
    """Unknown flags print 'flag provided but not defined' plus the usage."""
    # CATCHES: the long '--bogus' form is reported with a single dash, and
    # combined short flags such as '-lw' are not supported at all.
    res = run_shfmt([flag], stdin=b"echo hi\n")
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == reported + USAGE


@pytest.mark.parametrize(
    "flag,reported",
    [
        ("-ln", b"flag needs an argument: -ln\n"),
        ("--language-dialect", b"flag needs an argument: -language-dialect\n"),
        ("-i", b"flag needs an argument: -i\n"),
        ("--indent", b"flag needs an argument: -indent\n"),
        ("--filename", b"flag needs an argument: -filename\n"),
        ("--detect", b"flag needs an argument: -detect\n"),
        ("--exp.recover", b"flag needs an argument: -exp.recover\n"),
    ],
)
def test_missing_flag_value_reports_flag_and_usage(flag, reported):
    """Value-taking flags report 'flag needs an argument' with exit code 2."""
    # CATCHES: the long spelling is reported without its leading dashes and
    # the undocumented --exp.recover flag is registered like any other.
    res = run_shfmt([flag])
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == reported + USAGE


@pytest.mark.parametrize(
    "args,reported",
    [
        (["-i", "abc"], b'invalid value "abc" for flag -i: parse error\n'),
        (["-i=abc"], b'invalid value "abc" for flag -i: parse error\n'),
        (["-i=-1"], b'invalid value "-1" for flag -i: parse error\n'),
        (
            ["-i=99999999999999999999"],
            b'invalid value "99999999999999999999" for flag -i: value out of range\n',
        ),
        (
            ["-ln=foobar"],
            b'invalid value "foobar" for flag -ln: unknown shell language variant: "foobar"\n',
        ),
        (
            ["-ln="],
            b'invalid value "" for flag -ln: unknown shell language variant: ""\n',
        ),
        (["-s=maybe"], b'invalid boolean value "maybe" for -s: parse error\n'),
        (
            ["--apply-ignore=notabool"],
            b'invalid boolean value "notabool" for -apply-ignore: parse error\n',
        ),
        (
            ["--exp.recover=x"],
            b'invalid value "x" for flag -exp.recover: parse error\n',
        ),
    ],
)
def test_invalid_flag_value_reports_the_offending_value(args, reported):
    """Bad values print 'invalid value'/'invalid boolean value' plus usage."""
    # CATCHES: boolean flags use a different error wording than valued flags
    # ('invalid boolean value "x" for -s' has no 'flag' word), and the
    # rejected value is always quoted verbatim.
    res = run_shfmt(args)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == reported + USAGE


def test_double_dash_stops_flag_parsing():
    """After '--' every argument is a path, even ones that look like flags."""
    # CATCHES: a re-implementation that keeps parsing flags after '--' would
    # treat '-l' as the list flag instead of a (missing) path.
    res = run_shfmt(["--", "-l"], stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"lstat -l: no such file or directory\n"


def test_double_dash_alone_still_reads_standard_input():
    """A lone '--' leaves no path arguments, so standard input is used."""
    # CATCHES: treating '--' itself as a path argument would produce an
    # 'lstat --' error instead of formatting the piped script.
    res = run_shfmt(["--"], stdin=b"echo   hi\n")
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


def test_flags_after_a_path_are_not_parsed(tmp_path):
    """Flag parsing stops at the first path argument (Go flag semantics)."""
    # CATCHES: a GNU-style parser that permutes arguments would apply -l to
    # the file instead of trying to lstat the literal path '-l'.
    write_script(tmp_path, "f.sh", b"echo   hi\n")
    res = run_shfmt(["f.sh", "-l"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b"lstat -l: no such file or directory\n"


@pytest.mark.parametrize(
    "args", [["-i=2"], ["-i", "2"], ["--indent=2"], ["--indent", "2"]]
)
def test_indent_flag_accepts_equals_and_space_forms(args):
    """All four spellings of the indent flag set the very same value."""
    # CATCHES: '-i=2' must behave exactly like '-i 2'; supporting only one
    # form would break scripts that use the '=' spelling.
    res = run_shfmt(args, stdin=b"if true; then\nfoo\nfi\n")
    assert res.returncode == 0
    assert res.stdout == b"if true; then\n  foo\nfi\n"
    assert res.stderr == b""


@pytest.mark.parametrize("value", ["0", "4"])
def test_indent_flag_value_selects_tabs_or_spaces(value):
    """-i=0 keeps tab indentation while -i=4 indents with four spaces."""
    # CATCHES: the indent value must actually reach the printer, not merely
    # be accepted by the flag parser.
    res = run_shfmt(["-i=" + value], stdin=b"if true; then\nfoo\nfi\n")
    assert res.returncode == 0
    if value == "0":
        assert res.stdout == b"if true; then\n\tfoo\nfi\n"
    else:
        assert res.stdout == b"if true; then\n    foo\nfi\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "args",
    [
        ["-ln=posix"],
        ["-ln", "posix"],
        ["--language-dialect=posix"],
        ["--language-dialect", "posix"],
        ["-p"],
        ["--posix"],
    ],
)
def test_posix_dialect_flag_spellings_are_equivalent(args):
    """Every spelling of the posix dialect sets the same parser variant."""
    # CATCHES: '-p' is documented as shorthand for '-ln=posix', so all six
    # spellings must reject a bash-only array with the same message.
    res = run_shfmt(args, stdin=b"foo=(1 2)\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert (
        res.stderr
        == b"<standard input>:1:5: arrays are a bash/mksh/zsh feature; tried parsing as posix\n"
    )


@pytest.mark.parametrize("lang", ["bash", "mksh", "bats", "zsh", "auto"])
def test_documented_language_dialects_are_accepted(lang):
    """All five documented dialect names are valid -ln values."""
    # CATCHES: rejecting one of the documented dialects (or accepting an
    # undocumented one) changes which inputs parse successfully.
    res = run_shfmt(["-ln=" + lang], stdin=b"foo=(1 2)\n")
    assert res.returncode == 0
    assert res.stdout == b"foo=(1 2)\n"
    assert res.stderr == b""
