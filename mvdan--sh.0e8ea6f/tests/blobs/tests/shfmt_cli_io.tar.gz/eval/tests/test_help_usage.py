"""The usage text: how it is printed and what it contains."""

import pytest
from conftest import USAGE, run_shfmt


@pytest.mark.parametrize("flag", ["-h", "--help", "-help", "--help=x", "-h=1"])
def test_help_flags_print_usage_on_stderr_and_exit_zero(flag):
    """Every accepted help spelling prints the usage to stderr and exits 0."""
    # CATCHES: printing usage on stdout, exiting non-zero, or only supporting
    # one of the -h/--help/-help spellings (Go's flag package accepts them
    # all, including '--help=x', without parsing the value).
    res = run_shfmt([flag])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == USAGE


def test_help_beats_hand_written_validation():
    """-h is handled during flag parsing, before main() validates flags."""
    # CATCHES: a re-implementation that validates -p/-ln before handling help
    # would exit 1 with '-p and -ln=lang cannot coexist' instead of usage.
    res = run_shfmt(["-h", "-p", "-ln=posix", "-l=1"])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == USAGE


def test_help_wins_when_it_follows_a_bad_flag():
    """A help flag seen first still wins over a later unknown flag."""
    # CATCHES: flag parsing stops at the first error, so the order of the
    # arguments decides whether usage (exit 0) or an error (exit 2) is shown.
    res = run_shfmt(["-h", "--totally-unknown"])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == USAGE


def test_help_loses_when_a_bad_flag_comes_first():
    """An unknown flag seen before -h makes flag parsing fail with exit 2."""
    # CATCHES: mirrors the ordering rule above; '-x -h' must be an error.
    res = run_shfmt(["--totally-unknown", "-h"])
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(b"flag provided but not defined: -totally-unknown\n")
    assert res.stderr.endswith(USAGE)


@pytest.mark.parametrize(
    "section",
    [
        b"Parser options:",
        b"Printer options:",
        b"Utilities:",
    ],
)
def test_usage_groups_flags_into_documented_sections(section):
    """The usage text groups flags into the documented sections, in order."""
    # CATCHES: the sections must appear in this order with these exact
    # headings; a re-implementation that invents its own layout fails.
    res = run_shfmt(["-h"])
    assert res.stderr == USAGE
    assert res.stderr.index(b"Parser options:") < res.stderr.index(b"Printer options:")
    assert res.stderr.index(b"Printer options:") < res.stderr.index(b"Utilities:")
    assert section in res.stderr


@pytest.mark.parametrize(
    "line",
    [
        b"  -l[=0], --list[=0]  error with a list of files whose formatting differs from shfmt;",
        b"  -f[=0], --find[=0]  recursively find all shell files and print the paths;",
        b"  --to-json           print syntax tree to stdout as a typed JSON",
        b"  --from-json         read syntax tree from stdin as a typed JSON",
        b"  -ln, --language-dialect str  bash/posix/mksh/bats/zsh, default \"auto\"",
        b"  -fn, --func-next-line    function opening braces are placed on a separate line (deprecated; use -bl)",
        b"For more information and to report bugs, see https://github.com/mvdan/sh.",
    ],
)
def test_usage_documents_every_flag_family(line):
    """Each documented flag line appears verbatim in the usage text."""
    # CATCHES: a re-implementation that drops, renames or rewraps one of the
    # documented flag lines (or gets the deprecated -fn note wrong).
    res = run_shfmt(["-h"])
    assert res.stderr == USAGE
    assert line in res.stderr


def test_usage_starts_with_synopsis_line():
    """The usage text opens with the one-line synopsis, not a blank line."""
    # CATCHES: leading or trailing whitespace changes, or a missing trailing
    # newline, would change the recorded 2163-byte usage blob.
    res = run_shfmt(["-h"])
    assert res.stderr == USAGE
    assert res.stderr.splitlines()[0] == b"usage: shfmt [flags] [path ...]"
    assert res.stderr.endswith(b"https://github.com/mvdan/sh.\n")
    assert USAGE.count(b"\n") == 44
