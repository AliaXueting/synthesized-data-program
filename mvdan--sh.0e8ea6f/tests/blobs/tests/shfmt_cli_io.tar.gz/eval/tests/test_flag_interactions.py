"""How the output modes interact when several of them are selected."""

import pytest
from conftest import run_shfmt, write_script

UNFORMATTED = b"echo   hi\n"
BROKEN = b'echo "unterminated\n'
BROKEN_ERROR = b'broken.sh:1:6: reached EOF without closing quote `"`\n'


@pytest.mark.parametrize(
    "flags,expected",
    [
        (["-l", "-f"], b"f.sh\n"),
        (["-f", "-l"], b"f.sh\n"),
        (["-l", "-f=0"], b"f.sh\x00"),
        (["--list", "--find"], b"f.sh\n"),
    ],
)
def test_find_takes_precedence_over_list(tmp_path, flags, expected):
    """-f wins over -l: paths are printed as found, never as differing."""
    # CATCHES: the find branch returns before the formatting comparison, so
    # the exit code is 0 and the separator follows the -f spelling.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(flags + ["f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


@pytest.mark.parametrize("flags", [["-f", "-w"], ["-f", "-d"], ["-f", "-w", "-d"]])
def test_find_takes_precedence_over_write_and_diff(tmp_path, flags):
    """-f wins over -w and -d: nothing is written and no diff is printed."""
    # CATCHES: a re-implementation that keeps formatting after finding would
    # rewrite the file or exit 1 with a diff.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(flags + ["f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"f.sh\n"
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == UNFORMATTED


@pytest.mark.parametrize("flags", [["--to-json", "-l"], ["--to-json", "-d"], ["--to-json", "-l", "-d"]])
def test_to_json_takes_precedence_over_list_and_diff(flags):
    """--to-json short-circuits before the -l/-d/-w bookkeeping."""
    # CATCHES: the tree is printed and the run exits 0 even though the input
    # is unformatted, which would otherwise make -l/-d exit 1.
    res = run_shfmt(flags, stdin=UNFORMATTED)
    assert res.returncode == 0
    assert res.stdout.startswith(b'{\n\t"Type": "File",\n')
    assert res.stdout.endswith(b"}\n")
    assert res.stderr == b""


@pytest.mark.parametrize("flags", [[], ["-l"], ["-d"], ["-w"], ["-l", "-w"]])
def test_parse_error_is_reported_under_every_output_mode(tmp_path, flags):
    """A parse error always goes to stderr and never produces output."""
    # CATCHES: the error aborts the file before any listing, diffing or
    # writing happens, so stdout stays empty and the exit code is 1.
    write_script(tmp_path, "broken.sh", BROKEN)
    res = run_shfmt(flags + ["broken.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == BROKEN_ERROR
    assert (tmp_path / "broken.sh").read_bytes() == BROKEN


RECOVERED = b'echo ok\necho "unterminated\n"\n'


def test_exp_recover_recovers_parse_errors_on_standard_input():
    """--exp.recover=1 turns a parse error into successful formatting."""
    # CATCHES: the undocumented recovery flag makes the parser return a
    # partial tree, so nothing goes to stderr and the exit code is 0.
    res = run_shfmt(["--exp.recover=1"], stdin=b'echo ok\necho "unterminated\n')
    assert res.returncode == 0
    assert res.stdout == RECOVERED
    assert res.stderr == b""


def test_exp_recover_zero_keeps_the_error():
    """--exp.recover=0 behaves exactly like not passing the flag."""
    # CATCHES: only a non-zero recovery level enables recovery; zero keeps
    # the normal parse error with the '<standard input>' name prefix.
    res = run_shfmt(["--exp.recover=0"], stdin=BROKEN)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'<standard input>:1:6: reached EOF without closing quote `"`\n'


@pytest.mark.parametrize(
    "flags,returncode,stdout,rewritten",
    [
        ([], 0, b'echo "unterminated\n"\n', False),
        (["-l"], 1, b"broken.sh\n", False),
        (["-w"], 0, b"", True),
    ],
)
def test_exp_recover_works_under_every_output_mode(
    tmp_path, flags, returncode, stdout, rewritten
):
    """A recovered file is processed like any other differing file."""
    # CATCHES: recovery produces output that differs from the input, so -l
    # lists the path and exits 1 while -w rewrites it and exits 0.
    write_script(tmp_path, "broken.sh", BROKEN)
    res = run_shfmt(["--exp.recover=1"] + flags + ["broken.sh"], cwd=tmp_path)
    assert res.returncode == returncode
    assert res.stdout == stdout
    assert res.stderr == b""
    if rewritten:
        assert (tmp_path / "broken.sh").read_bytes() == b'echo "unterminated\n"\n'
    else:
        assert (tmp_path / "broken.sh").read_bytes() == BROKEN


def test_write_false_keeps_standard_input_working():
    """--write=false is an explicit no, so standard input is still allowed."""
    # CATCHES: the '-w cannot be used on standard input' check looks at the
    # flag's value, not at its mere presence on the command line.
    res = run_shfmt(["--write=false"], stdin=UNFORMATTED)
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""
