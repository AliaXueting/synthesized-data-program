"""Behaviors that only appear when a stream really is a terminal.

The tests in this module allocate their own pseudo-terminal with pty.openpty()
so they stay hermetic: nothing depends on the environment the suite itself was
started in, and the terminal exists only for the duration of one test.
"""

from conftest import USAGE, run_shfmt_pty, write_script

UNFORMATTED = b"echo   hi\n"

CONTEXT_SCRIPT = (
    b"echo one\n"
    b"echo   two\n"
    b"echo three\n"
    b"echo   six\n"
)

COLORED_DIFF = (
    b"\x1b[1m"
    b"diff ctx.sh.orig ctx.sh\n"
    b"--- ctx.sh.orig\n"
    b"+++ ctx.sh\n"
    b"\x1b[36m@@ -1,4 +1,4 @@\n"
    b"\x1b[0m echo one\n"
    b"\x1b[31m-echo   two\n"
    b"\x1b[32m+echo two\n"
    b"\x1b[0m echo three\n"
    b"\x1b[31m-echo   six\n"
    b"\x1b[32m+echo six\n"
    b"\x1b[0m"
)

PLAIN_DIFF = (
    b"diff ctx.sh.orig ctx.sh\n"
    b"--- ctx.sh.orig\n"
    b"+++ ctx.sh\n"
    b"@@ -1,4 +1,4 @@\n"
    b" echo one\n"
    b"-echo   two\n"
    b"+echo two\n"
    b" echo three\n"
    b"-echo   six\n"
    b"+echo six\n"
)


def test_no_arguments_on_a_terminal_prints_usage_and_exits_2():
    """With no arguments and a terminal on stdin, usage is shown like jq."""
    # CATCHES: new users would otherwise see the tool hang; the usage text
    # goes to stderr and the exit code is 2, not 0 or 1.
    res = run_shfmt_pty([], stdin_data=b"echo   hi\n", tty_stdin=True)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == USAGE


def test_explicit_dash_still_reads_a_terminal_stdin():
    """An explicit '-' reads the terminal even though stdin is a TTY."""
    # CATCHES: the jq-like shortcut only applies when no arguments at all are
    # given; a dash must keep reading standard input.
    res = run_shfmt_pty(["-"], stdin_data=b"echo   hi\n", tty_stdin=True)
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


def test_diff_is_colored_when_stdout_is_a_terminal(tmp_path):
    """A terminal stdout turns the diff colors on without any environment."""
    # CATCHES: color selection falls back to terminal detection of stdout,
    # which only matters when stdout really is a TTY; the trailing reset is
    # written after the last newline with no newline of its own.
    write_script(tmp_path, "ctx.sh", CONTEXT_SCRIPT)
    res = run_shfmt_pty(["-d", "ctx.sh"], tty_stdout=True, cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == COLORED_DIFF
    assert res.stderr == b""


def test_no_color_disables_terminal_coloring(tmp_path):
    """A non-empty NO_COLOR wins over terminal detection."""
    # CATCHES: the override order is FORCE_COLOR, then NO_COLOR/TERM=dumb,
    # then terminal detection.
    write_script(tmp_path, "ctx.sh", CONTEXT_SCRIPT)
    res = run_shfmt_pty(
        ["-d", "ctx.sh"], tty_stdout=True, env={"NO_COLOR": "1"}, cwd=tmp_path
    )
    assert res.returncode == 1
    assert res.stdout == PLAIN_DIFF
    assert res.stderr == b""


def test_dumb_terminal_disables_terminal_coloring(tmp_path):
    """TERM=dumb wins over terminal detection as well."""
    # CATCHES: only TERM=dumb disables it, not any other TERM value.
    write_script(tmp_path, "ctx.sh", CONTEXT_SCRIPT)
    res = run_shfmt_pty(
        ["-d", "ctx.sh"], tty_stdout=True, env={"TERM": "dumb"}, cwd=tmp_path
    )
    assert res.returncode == 1
    assert res.stdout == PLAIN_DIFF
    assert res.stderr == b""


def test_a_terminal_stdout_does_not_change_plain_output(tmp_path):
    """Formatting output is byte-identical on a terminal and on a pipe."""
    # CATCHES: only the diff is colorized, so a plain run must not gain
    # escape sequences just because stdout is a TTY.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt_pty(["f.sh"], tty_stdout=True, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


def test_a_terminal_stdin_does_not_change_file_arguments(tmp_path):
    """Path arguments are processed normally when stdin is a terminal."""
    # CATCHES: the jq-like shortcut only triggers with zero arguments.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt_pty(
        ["-l", "f.sh"], stdin_data=b"", tty_stdin=True, cwd=tmp_path
    )
    assert res.returncode == 1
    assert res.stdout == b"f.sh\n"
    assert res.stderr == b""
