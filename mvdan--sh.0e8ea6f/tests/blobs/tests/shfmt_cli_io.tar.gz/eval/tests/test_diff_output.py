"""The -d diff output: format, header names, and coloring."""

import pytest
from conftest import run_shfmt, write_script

UNFORMATTED = b"echo   hi\n"

CONTEXT_SCRIPT = (
    b"echo one\n"
    b"echo   two\n"
    b"echo three\n"
    b"echo four\n"
    b"echo five\n"
    b"echo   six\n"
    b"echo seven\n"
)

CONTEXT_PLAIN_DIFF = (
    b"diff ctx.sh.orig ctx.sh\n"
    b"--- ctx.sh.orig\n"
    b"+++ ctx.sh\n"
    b"@@ -1,7 +1,7 @@\n"
    b" echo one\n"
    b"-echo   two\n"
    b"+echo two\n"
    b" echo three\n"
    b" echo four\n"
    b" echo five\n"
    b"-echo   six\n"
    b"+echo six\n"
    b" echo seven\n"
)

CONTEXT_COLOR_DIFF = (
    b"\x1b[1m"
    b"diff ctx.sh.orig ctx.sh\n"
    b"--- ctx.sh.orig\n"
    b"+++ ctx.sh\n"
    b"\x1b[36m@@ -1,7 +1,7 @@\n"
    b"\x1b[0m echo one\n"
    b"\x1b[31m-echo   two\n"
    b"\x1b[32m+echo two\n"
    b"\x1b[0m echo three\n"
    b" echo four\n"
    b" echo five\n"
    b"\x1b[31m-echo   six\n"
    b"\x1b[32m+echo six\n"
    b"\x1b[0m echo seven\n"
)


def test_diff_uses_orig_and_plain_header_names(tmp_path):
    """-d prints a unified diff whose header names are 'path.orig' and 'path'."""
    # CATCHES: the three header lines are 'diff p.orig p', '--- p.orig' and
    # '+++ p', and a difference makes the run exit 1.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-d", "f.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == (
        b"diff f.sh.orig f.sh\n"
        b"--- f.sh.orig\n"
        b"+++ f.sh\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-echo   hi\n"
        b"+echo hi\n"
    )
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == UNFORMATTED


def test_diff_is_empty_when_the_file_is_formatted(tmp_path):
    """-d on an already-formatted file prints nothing and exits 0."""
    # CATCHES: the diff (and the non-zero exit) only appear when the output
    # differs from the input; the plain run proves the file was processed.
    write_script(tmp_path, "f.sh", b"echo hi\n")
    plain = run_shfmt(["f.sh"], cwd=tmp_path)
    assert plain.returncode == 0
    assert plain.stdout == b"echo hi\n"
    res = run_shfmt(["-d", "f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_diff_keeps_context_lines_and_groups_two_hunks(tmp_path):
    """Context lines are kept and several changes share one hunk."""
    # CATCHES: the hunk header counts all seven lines and unchanged lines
    # keep a leading space.
    write_script(tmp_path, "ctx.sh", CONTEXT_SCRIPT)
    res = run_shfmt(["-d", "ctx.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == CONTEXT_PLAIN_DIFF
    assert res.stderr == b""


def test_diff_prints_one_diff_per_file_in_order(tmp_path):
    """Several differing files produce concatenated diffs on stdout."""
    # CATCHES: each file gets its own header block, in argument order.
    write_script(tmp_path, "one.sh", UNFORMATTED)
    write_script(tmp_path, "two.sh", b"echo   there\n")
    res = run_shfmt(["-d", "one.sh", "two.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == (
        b"diff one.sh.orig one.sh\n"
        b"--- one.sh.orig\n"
        b"+++ one.sh\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-echo   hi\n"
        b"+echo hi\n"
        b"diff two.sh.orig two.sh\n"
        b"--- two.sh.orig\n"
        b"+++ two.sh\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-echo   there\n"
        b"+echo there\n"
    )
    assert res.stderr == b""


def test_diff_on_standard_input_names_the_stdin():
    """Diffing stdin uses '<standard input>' in both header names."""
    # CATCHES: the synthetic stdin name gains the '.orig' suffix like any
    # other path.
    res = run_shfmt(["-d"], stdin=UNFORMATTED)
    assert res.returncode == 1
    assert res.stdout == (
        b"diff <standard input>.orig <standard input>\n"
        b"--- <standard input>.orig\n"
        b"+++ <standard input>\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-echo   hi\n"
        b"+echo hi\n"
    )
    assert res.stderr == b""


def test_diff_with_filename_flag_uses_that_name(tmp_path):
    """--filename renames the stdin diff headers as well."""
    # CATCHES: the diff header is built from the same name used elsewhere.
    res = run_shfmt(["-d", "--filename=x.sh"], stdin=UNFORMATTED, cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout.startswith(b"diff x.sh.orig x.sh\n--- x.sh.orig\n+++ x.sh\n")
    assert res.stderr == b""


def test_diff_of_an_empty_file_adds_a_newline(tmp_path):
    """An empty file diffs against a single added empty line."""
    # CATCHES: the hunk header for an empty original is '@@ -0,0 +1,1 @@'.
    write_script(tmp_path, "empty.sh", b"")
    res = run_shfmt(["-d", "empty.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == (
        b"diff empty.sh.orig empty.sh\n"
        b"--- empty.sh.orig\n"
        b"+++ empty.sh\n"
        b"@@ -0,0 +1,1 @@\n"
        b"+\n"
    )
    assert res.stderr == b""


def test_list_and_diff_print_both_outputs(tmp_path):
    """-l -d prints the path first and then the diff for the same file."""
    # CATCHES: the path is printed by the -l branch before the diff, and the
    # exit code is 1 because the diff reported a difference.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-l", "-d", "f.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == (
        b"f.sh\n"
        b"diff f.sh.orig f.sh\n"
        b"--- f.sh.orig\n"
        b"+++ f.sh\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-echo   hi\n"
        b"+echo hi\n"
    )
    assert res.stderr == b""


def test_diff_is_colored_when_force_color_is_set(tmp_path):
    """FORCE_COLOR colors the diff even though stdout is a pipe."""
    # CATCHES: the header is bold, '@@' cyan, '-' red and '+' green, and no
    # escape is emitted when the color does not change.
    write_script(tmp_path, "ctx.sh", CONTEXT_SCRIPT)
    res = run_shfmt(["-d", "ctx.sh"], cwd=tmp_path, env={"FORCE_COLOR": "1"})
    assert res.returncode == 1
    assert res.stdout == CONTEXT_COLOR_DIFF
    assert res.stderr == b""


@pytest.mark.parametrize(
    "env",
    [
        {"NO_COLOR": "1", "FORCE_COLOR": "1"},
        {"TERM": "dumb", "FORCE_COLOR": "1"},
        {"FORCE_COLOR": "yes"},
    ],
)
def test_force_color_wins_over_the_other_color_variables(tmp_path, env):
    """A non-empty FORCE_COLOR forces color regardless of NO_COLOR/TERM."""
    # CATCHES: FORCE_COLOR is checked first, so it overrides the two
    # color-disabling variables.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-d", "f.sh"], cwd=tmp_path, env=env)
    assert res.returncode == 1
    assert res.stdout.startswith(b"\x1b[1mdiff f.sh.orig f.sh\n")
    assert res.stdout.count(b"\x1b[31m") == 1  # one removed line
    assert res.stdout.count(b"\x1b[32m") == 1  # one added line
    assert res.stderr == b""


@pytest.mark.parametrize("env", [{"NO_COLOR": "1"}, {"NO_COLOR": ""}, {"TERM": "dumb"}])
def test_diff_stays_plain_without_force_color(tmp_path, env):
    """Without FORCE_COLOR a piped stdout never gets escape sequences."""
    # CATCHES: no color may leak into piped output when only the disabling
    # variables are set.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-d", "f.sh"], cwd=tmp_path, env=env)
    assert res.returncode == 1
    assert res.stdout == (
        b"diff f.sh.orig f.sh\n"
        b"--- f.sh.orig\n"
        b"+++ f.sh\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-echo   hi\n"
        b"+echo hi\n"
    )
    assert b"\x1b" not in res.stdout
    assert res.stderr == b""
