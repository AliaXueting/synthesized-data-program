"""Output disposition: what is printed or written, and the exit codes."""

import os
import time

import pytest
from conftest import run_shfmt, write_script

UNFORMATTED = b"echo   hi\n"
FORMATTED = b"echo hi\n"


def stat_mode(path):
    """Return the permission bits of a path."""
    return os.stat(path).st_mode & 0o7777


def test_default_mode_prints_formatted_code_to_stdout(tmp_path):
    """Without -l/-w/-d the formatted result goes to stdout and rc is 0."""
    # CATCHES: writing to stdout only (never the file) and succeeding even
    # though the input differed from the output.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == UNFORMATTED


def test_already_formatted_input_is_printed_unchanged(tmp_path):
    """A formatted file round-trips through the tool byte for byte."""
    # CATCHES: a re-implementation that reformats already-clean input (or
    # drops the trailing newline) breaks the round-trip.
    write_script(tmp_path, "f.sh", b"echo hi\nfoo() { bar; }\n")
    res = run_shfmt(["f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"echo hi\nfoo() { bar; }\n"
    assert res.stderr == b""


def test_empty_input_formats_to_a_single_newline(tmp_path):
    """An empty script formats to exactly one newline character."""
    # CATCHES: shfmt always terminates the printed program with a newline,
    # so an empty file yields '\n' rather than an empty output.
    write_script(tmp_path, "empty.sh", b"")
    res = run_shfmt(["empty.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"\n"
    assert res.stderr == b""


def test_missing_final_newline_is_added(tmp_path):
    """A file without a trailing newline gets one in the output."""
    # CATCHES: the printer always terminates the last line.
    write_script(tmp_path, "f.sh", b"echo hi")
    res = run_shfmt(["f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""


def test_list_prints_differing_paths_in_argument_order(tmp_path):
    """-l prints one path per differing file, in the order given."""
    # CATCHES: only differing files are listed, formatted ones are skipped,
    # and the exit code is 1 because at least one differed.
    write_script(tmp_path, "one.sh", UNFORMATTED)
    write_script(tmp_path, "two.sh", FORMATTED)
    write_script(tmp_path, "three.sh", b"echo   there\n")
    res = run_shfmt(["-l", "one.sh", "two.sh", "three.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b"one.sh\nthree.sh\n"
    assert res.stderr == b""


def test_list_is_silent_and_successful_when_nothing_differs(tmp_path):
    """-l on an already-formatted file prints nothing and exits 0."""
    # CATCHES: the exit code tracks whether any file differed, while the
    # default mode on the same file proves it was really read and printed.
    write_script(tmp_path, "f.sh", FORMATTED)
    plain = run_shfmt(["f.sh"], cwd=tmp_path)
    assert plain.returncode == 0
    assert plain.stdout == FORMATTED
    res = run_shfmt(["-l", "f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_list_zero_separator_uses_null_bytes(tmp_path):
    """-l=0 separates the listed paths with NUL instead of a newline."""
    # CATCHES: the machine-readable variant ends with a trailing NUL and no
    # newline at all.
    write_script(tmp_path, "one.sh", UNFORMATTED)
    write_script(tmp_path, "two.sh", b"echo   there\n")
    res = run_shfmt(["-l=0", "one.sh", "two.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b"one.sh\x00two.sh\x00"
    assert res.stderr == b""


def test_list_on_standard_input_prints_the_stdin_name():
    """-l reading standard input lists the synthetic '<standard input>'."""
    # CATCHES: the same name used for parse errors is what -l prints.
    res = run_shfmt(["-l"], stdin=UNFORMATTED)
    assert res.returncode == 1
    assert res.stdout == b"<standard input>\n"
    assert res.stderr == b""


def test_list_zero_separator_on_standard_input():
    """-l=0 reading standard input prints the name followed by a NUL."""
    # CATCHES: the NUL variant applies to stdin as well.
    res = run_shfmt(["-l=0"], stdin=UNFORMATTED)
    assert res.returncode == 1
    assert res.stdout == b"<standard input>\x00"
    assert res.stderr == b""


def test_write_rewrites_the_file_and_prints_nothing(tmp_path):
    """-w writes the formatted bytes back and stays silent on stdout."""
    # CATCHES: with -w nothing is printed to stdout and the exit code is 0
    # even though the file's contents changed.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-w", "f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == FORMATTED


@pytest.mark.parametrize("mode", [0o644, 0o755, 0o600, 0o640])
def test_write_preserves_the_permission_bits(tmp_path, mode):
    """-w rewrites the file without changing its permission bits."""
    # CATCHES: the atomic replacement must copy the original mode, so a
    # 0755 script does not silently become 0644.
    write_script(tmp_path, "f.sh", UNFORMATTED, mode=mode)
    res = run_shfmt(["-w", "f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == FORMATTED
    assert stat_mode(tmp_path / "f.sh") == mode


def test_write_leaves_no_temporary_files_behind(tmp_path):
    """The atomic write cleans up, leaving only the original file."""
    # CATCHES: a re-implementation using naive temp files would leave one in
    # the same directory.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-w", "f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == FORMATTED
    assert sorted(os.listdir(tmp_path)) == ["f.sh"]


def test_write_skips_files_that_need_no_changes(tmp_path):
    """-w rewrites the file that differs but not the one that matches."""
    # CATCHES: shfmt compares before writing, so an already-formatted file
    # keeps its modification time while a sibling really is rewritten.
    clean = write_script(tmp_path, "clean.sh", FORMATTED)
    messy = write_script(tmp_path, "messy.sh", UNFORMATTED)
    before = os.stat(clean).st_mtime_ns
    time.sleep(0.05)
    res = run_shfmt(["-w", "clean.sh", "messy.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert messy.read_bytes() == FORMATTED
    assert os.stat(clean).st_mtime_ns == before


def test_write_refuses_to_replace_a_symlink(tmp_path):
    """-w refuses to atomically replace a non-regular file."""
    # CATCHES: the exact 'refusing to atomically replace' wording, the %q
    # quoting of the path, and the fact that the target is left untouched.
    target = write_script(tmp_path, "real.sh", UNFORMATTED)
    (tmp_path / "link.sh").symlink_to(target)
    res = run_shfmt(["-w", "link.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'refusing to atomically replace "link.sh" with a regular file'
        b" as it is not one already\n"
    )
    assert (tmp_path / "real.sh").read_bytes() == UNFORMATTED
    assert (tmp_path / "link.sh").is_symlink()


def test_list_with_write_still_exits_zero(tmp_path):
    """-l -w lists the file it rewrote but reports success."""
    # CATCHES: with -w set a differing file is not an error, so the exit
    # code is 0 even though -l printed a path.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-l", "-w", "f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"f.sh\n"
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == FORMATTED


def test_diff_with_write_writes_and_reports_the_difference(tmp_path):
    """-d -w writes the file and still exits 1 with the diff on stdout."""
    # CATCHES: unlike -l -w, the -d path returns a 'formatting differs'
    # error after writing, so the exit code is 1.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-d", "-w", "f.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == (
        b"diff f.sh.orig f.sh\n"
        b"--- f.sh.orig\n"
        b"+++ f.sh\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-echo   hi\n"
        b"+echo hi\n"
    )
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == FORMATTED


def test_find_prints_paths_newline_separated(tmp_path):
    """-f prints the paths it walks, one per line, and exits 0."""
    # CATCHES: -f is a listing mode: no formatting is printed at all.
    write_script(tmp_path, "one.sh", UNFORMATTED)
    (tmp_path / "sub").mkdir()
    write_script(tmp_path / "sub", "two.sh", FORMATTED)
    res = run_shfmt(["-f", "one.sh", "sub/two.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"one.sh\nsub/two.sh\n"
    assert res.stderr == b""


def test_find_zero_separator_uses_null_bytes(tmp_path):
    """-f=0 prints the same paths NUL-separated."""
    # CATCHES: the -f flag mirrors -l's '=0' machine-readable variant.
    write_script(tmp_path, "one.sh", FORMATTED)
    res = run_shfmt(["-f=0", "one.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"one.sh\x00"
    assert res.stderr == b""


def test_parse_error_in_file_mode_uses_the_path_as_name(tmp_path):
    """Parse errors print 'path:line:col: message' on stderr, exit 1."""
    # CATCHES: the file's own path is used as the name, and nothing goes to
    # stdout.
    write_script(tmp_path, "broken.sh", b'echo "unterminated\n')
    res = run_shfmt(["broken.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'broken.sh:1:6: reached EOF without closing quote `"`\n'


def test_missing_path_reports_a_lstat_error(tmp_path):
    """A path that does not exist is reported as an lstat error, exit 1."""
    # CATCHES: the error text comes from walking the path, so it is
    # 'lstat <path>: no such file or directory' rather than an open error.
    res = run_shfmt(["missing.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"lstat missing.sh: no such file or directory\n"


def test_errors_do_not_stop_processing_later_arguments(tmp_path):
    """Every path argument is processed even after earlier ones failed."""
    # CATCHES: the walk continues after a parse error and after a missing
    # path, and all errors are printed in order.
    write_script(tmp_path, "broken.sh", b'echo "unterminated\n')
    write_script(tmp_path, "ok.sh", UNFORMATTED)
    res = run_shfmt(["broken.sh", "missing.sh", "ok.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b"echo hi\n"
    assert res.stderr == (
        b'broken.sh:1:6: reached EOF without closing quote `"`\n'
        b"lstat missing.sh: no such file or directory\n"
    )


def test_stdout_and_stderr_carry_different_streams(tmp_path):
    """Formatted output goes to stdout while errors go to stderr."""
    # CATCHES: interleaving the two streams (or printing errors to stdout)
    # would break callers that parse stdout.
    write_script(tmp_path, "ok.sh", UNFORMATTED)
    res = run_shfmt(["ok.sh", "missing.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b"lstat missing.sh: no such file or directory\n"


def test_invalid_utf8_input_is_an_error():
    """Input that is not valid UTF-8 fails with a positioned message."""
    # CATCHES: the parser requires valid UTF-8 and reports it at 1:1.
    res = run_shfmt([], stdin=b"\xff\xfe\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: invalid UTF-8 encoding\n"


def test_apply_ignore_suppresses_output_for_ignored_stdin(tmp_path):
    """--apply-ignore with an ignored filename prints nothing at all."""
    # CATCHES: the EditorConfig ignore rule is only applied to stdin when the
    # flag is given; a filename the rule does not match is still formatted,
    # which proves the tool really ran on the ignored input too.
    (tmp_path / ".editorconfig").write_bytes(b"[*.sh]\nignore = true\n")
    kept = run_shfmt(
        ["--apply-ignore", "--filename=kept.txt"], stdin=UNFORMATTED, cwd=tmp_path
    )
    assert kept.returncode == 0
    assert kept.stdout == FORMATTED
    assert kept.stderr == b""
    res = run_shfmt(
        ["--apply-ignore", "--filename=skipped.sh"], stdin=UNFORMATTED, cwd=tmp_path
    )
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_stdin_without_apply_ignore_still_formats_ignored_files(tmp_path):
    """Without --apply-ignore the same input is formatted normally."""
    # CATCHES: the ignore rule must not leak into the default stdin path.
    (tmp_path / ".editorconfig").write_bytes(b"[*.sh]\nignore = true\n")
    res = run_shfmt(["--filename=skipped.sh"], stdin=UNFORMATTED, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b""


def test_ignored_files_are_skipped_while_walking_directories(tmp_path):
    """Files matched by an ignore rule are skipped when a directory is walked."""
    # CATCHES: walked (non-explicit) paths always apply the ignore rule, so -l
    # lists only the kept shebang file, never the ignored '*.sh' sibling, and
    # still exits 1 because the kept file's formatting differs.
    (tmp_path / ".editorconfig").write_bytes(b"[*.sh]\nignore = true\n")
    (tmp_path / "sub").mkdir()
    write_script(tmp_path / "sub", "ignored.sh", UNFORMATTED)
    write_script(tmp_path / "sub", "kept", b"#!/bin/sh\necho   there\n")
    res = run_shfmt(["-l", "sub"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b"sub/kept\n"
    assert res.stderr == b""


def test_explicit_paths_bypass_ignore_rules_unless_apply_ignore(tmp_path):
    """Naming a file directly skips the ignore rule unless --apply-ignore."""
    # CATCHES: the ignore rule only applies to explicit paths when the flag
    # is given, so the same command prints the formatted file or nothing.
    (tmp_path / ".editorconfig").write_bytes(b"[*.sh]\nignore = true\n")
    (tmp_path / "sub").mkdir()
    write_script(tmp_path / "sub", "ignored.sh", UNFORMATTED)
    formatted = run_shfmt(["sub/ignored.sh"], cwd=tmp_path)
    assert formatted.returncode == 0
    assert formatted.stdout == FORMATTED
    assert formatted.stderr == b""
    ignored = run_shfmt(["--apply-ignore", "sub/ignored.sh"], cwd=tmp_path)
    assert ignored.returncode == 0
    assert ignored.stdout == b""
    assert ignored.stderr == b""
    listed = run_shfmt(["--apply-ignore", "-l", "sub/ignored.sh"], cwd=tmp_path)
    assert listed.returncode == 0
    assert listed.stdout == b""
    assert listed.stderr == b""


def test_apply_ignore_resolves_the_filename_through_its_directory(tmp_path):
    """--filename with a directory part finds the matching .editorconfig."""
    # CATCHES: the EditorConfig lookup happens on the whole --filename value,
    # so 'sub/ignored.sh' matches '[*.sh]' the same way a real path would.
    (tmp_path / ".editorconfig").write_bytes(b"[*.sh]\nignore = true\n")
    (tmp_path / "sub").mkdir()
    write_script(tmp_path / "sub", "ignored.sh", UNFORMATTED)
    ignored = run_shfmt(
        ["--apply-ignore", "--filename=sub/ignored.sh"], stdin=UNFORMATTED, cwd=tmp_path
    )
    assert ignored.returncode == 0
    assert ignored.stdout == b""
    assert ignored.stderr == b""
    kept = run_shfmt(
        ["--apply-ignore", "--filename=sub/kept.txt"], stdin=UNFORMATTED, cwd=tmp_path
    )
    assert kept.returncode == 0
    assert kept.stdout == FORMATTED
    assert kept.stderr == b""


def test_write_is_skipped_for_an_explicitly_ignored_path(tmp_path):
    """--apply-ignore -w leaves an ignored path untouched but writes siblings."""
    # CATCHES: the ignore check runs before any formatting, so the ignored
    # '*.sh' path is neither rewritten nor reported, while the non-matching
    # sibling named in the same run is still written in place.
    (tmp_path / ".editorconfig").write_bytes(b"[*.sh]\nignore = true\n")
    (tmp_path / "sub").mkdir()
    write_script(tmp_path / "sub", "ignored.sh", UNFORMATTED)
    write_script(tmp_path / "sub", "plain.txt", UNFORMATTED)
    res = run_shfmt(
        ["--apply-ignore", "-w", "sub/ignored.sh", "sub/plain.txt"], cwd=tmp_path
    )
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "sub" / "ignored.sh").read_bytes() == UNFORMATTED
    assert (tmp_path / "sub" / "plain.txt").read_bytes() == FORMATTED


@pytest.mark.parametrize("flag", ["-f", "-f=0", "--find=true"])
def test_find_is_ignored_when_reading_standard_input(flag):
    """-f has no effect on standard input: the input is still formatted."""
    # CATCHES: --find only lists paths while walking; on stdin the flag is
    # silently dropped, so the formatted code (not a path) is printed.
    res = run_shfmt([flag], stdin=UNFORMATTED)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b""


def test_empty_standard_input_formats_to_a_single_newline():
    """Empty standard input formats to exactly one newline, like a file."""
    # CATCHES: the stdin path shares the file behaviour of always terminating
    # the printed program with a newline.
    res = run_shfmt([], stdin=b"")
    assert res.returncode == 0
    assert res.stdout == b"\n"
    assert res.stderr == b""


def test_list_write_and_diff_together_print_path_and_diff(tmp_path):
    """-l -w -d prints the path and the diff, writes, and exits 1."""
    # CATCHES: the -l branch prints first, the file is rewritten, and the diff
    # still reports 'formatting differs' even though -w succeeded.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-l", "-w", "-d", "f.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == (
        b"f.sh\n"
        b"diff f.sh.orig f.sh\n"
        b"--- f.sh.orig\n"
        b"+++ f.sh\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-echo   hi\n"
        b"+echo hi\n"
    )
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == FORMATTED


def test_list_zero_separator_with_write(tmp_path):
    """-l=0 -w rewrites the file and prints its path followed by a NUL."""
    # CATCHES: with -w the run succeeds despite the difference, while the
    # machine-readable path list keeps its trailing NUL and no newline.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["-l=0", "-w", "f.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"f.sh\x00"
    assert res.stderr == b""
    assert (tmp_path / "f.sh").read_bytes() == FORMATTED


def test_explicit_symlink_is_formatted_under_its_own_name(tmp_path):
    """An explicit symlink argument is resolved and keeps the symlink name."""
    # CATCHES: explicit symlink arguments are resolved to their target before
    # formatting, so the target's bytes are printed under the link's path.
    (tmp_path / "sub").mkdir()
    target = write_script(tmp_path / "sub", "real.sh", UNFORMATTED)
    (tmp_path / "link.sh").symlink_to(target)
    res = run_shfmt(["link.sh"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b""
    listed = run_shfmt(["-l", "link.sh"], cwd=tmp_path)
    assert listed.returncode == 1
    assert listed.stdout == b"link.sh\n"
    assert listed.stderr == b""


def test_repeated_path_arguments_are_processed_again(tmp_path):
    """The same path given twice is formatted and listed twice."""
    # CATCHES: every path argument is walked independently, so the output
    # simply repeats instead of being de-duplicated.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    plain = run_shfmt(["f.sh", "f.sh"], cwd=tmp_path)
    assert plain.returncode == 0
    assert plain.stdout == 2 * FORMATTED
    assert plain.stderr == b""
    listed = run_shfmt(["-l", "f.sh", "f.sh"], cwd=tmp_path)
    assert listed.returncode == 1
    assert listed.stdout == b"f.sh\nf.sh\n"
    assert listed.stderr == b""


def test_empty_path_argument_reports_lstat_error():
    """An empty string path argument is walked like any other path."""
    # CATCHES: the empty argument is not silently skipped or treated as stdin;
    # it produces an lstat error with an empty path in the message.
    res = run_shfmt([""], stdin=b"echo hi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"lstat : no such file or directory\n"


def test_trailing_slash_on_a_file_reports_not_a_directory(tmp_path):
    """A trailing slash turns a file path into a 'not a directory' error."""
    # CATCHES: the walk lstats the path verbatim, so 'f.sh/' fails with
    # ENOTDIR rather than being normalized to 'f.sh'.
    write_script(tmp_path, "f.sh", UNFORMATTED)
    res = run_shfmt(["f.sh/"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"lstat f.sh/: not a directory\n"


@pytest.mark.parametrize(
    "args,expected",
    [
        (["-l", "--filename=custom.sh"], b"custom.sh\n"),
        (["-l", "--filename", "custom.sh"], b"custom.sh\n"),
        (["-l=0", "--filename=custom.sh"], b"custom.sh\x00"),
    ],
)
def test_list_with_filename_prints_that_name(args, expected):
    """-l on standard input prints the --filename value, not the stdin name."""
    # CATCHES: the name given via --filename replaces '<standard input>' in
    # the -l output, in both separator modes and both flag spellings.
    res = run_shfmt(args, stdin=UNFORMATTED)
    assert res.returncode == 1
    assert res.stdout == expected
    assert res.stderr == b""


def test_dangling_symlink_argument_reports_a_stat_error(tmp_path):
    """An explicit symlink to a missing target fails with a 'stat' error."""
    # CATCHES: explicit symlink arguments are resolved with stat (not lstat)
    # before formatting, so a broken link reports 'stat' in the message.
    (tmp_path / "dangle.sh").symlink_to(tmp_path / "missing.sh")
    res = run_shfmt(["dangle.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"stat dangle.sh: no such file or directory\n"


def test_write_error_beats_the_ignore_rules_on_standard_input(tmp_path):
    """-w on standard input is rejected before any ignore rule is consulted."""
    # CATCHES: the -w check runs first in the stdin path, so even a filename
    # matching an ignore rule cannot silence the write-on-stdin error.
    (tmp_path / ".editorconfig").write_bytes(b"[*.sh]\nignore = true\n")
    res = run_shfmt(
        ["-w", "--apply-ignore", "--filename=ignored.sh"],
        stdin=UNFORMATTED,
        cwd=tmp_path,
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"-w cannot be used on standard input\n"


def test_parse_error_names_the_dialect_it_tried_on_standard_input():
    """With -ln=auto a dialect-specific parse error is annotated."""
    # CATCHES: when the dialect came from the shebang rather than a flag, the
    # error is suffixed with '(parsed as posix via -ln=auto)' naming it.
    res = run_shfmt([], stdin=b"#!/bin/sh\necho hi &> /dev/null\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:2:9: `&>` redirects are a bash/mksh/zsh feature; "
        b"tried parsing as posix (parsed as posix via -ln=auto)\n"
    )


def test_parse_error_names_the_dialect_from_editorconfig(tmp_path):
    """A dialect set by EditorConfig gets its own annotation wording."""
    # CATCHES: when language_dialect comes from .editorconfig the parenthesised
    # suffix says 'via EditorConfig' rather than 'via -ln=auto'.
    (tmp_path / ".editorconfig").write_bytes(b"[*.sh]\nlanguage_dialect = posix\n")
    write_script(tmp_path, "m.sh", b"echo hi &> /dev/null\n")
    res = run_shfmt(["m.sh"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"m.sh:1:9: `&>` redirects are a bash/mksh/zsh feature; "
        b"tried parsing as posix (parsed as posix via EditorConfig)\n"
    )


def test_explicit_symlink_to_a_directory_prints_nothing(tmp_path):
    """A symlink to a directory is resolved and then skipped, unlike the dir."""
    # CATCHES: the explicit symlink is resolved to a directory entry, which is
    # then discarded as a non-script, while naming the directory itself walks
    # it and prints the formatted script inside.
    (tmp_path / "realdir").mkdir()
    write_script(tmp_path / "realdir", "inner.sh", UNFORMATTED)
    (tmp_path / "dirlink").symlink_to(tmp_path / "realdir")
    direct = run_shfmt(["realdir"], cwd=tmp_path)
    assert direct.returncode == 0
    assert direct.stdout == FORMATTED
    assert direct.stderr == b""
    linked = run_shfmt(["dirlink"], cwd=tmp_path)
    assert linked.returncode == 0
    assert linked.stdout == b""
    assert linked.stderr == b""
