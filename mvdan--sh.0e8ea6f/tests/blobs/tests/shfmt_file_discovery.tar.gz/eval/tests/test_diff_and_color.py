"""Diff output for the files that discovery feeds to the formatter.

``-d`` prints a unified diff on stdout and exits 1 whenever a discovered
file's formatting differs.  The bytes are pinned here in both the plain
form and the FORCE_COLOR-colored form, including the precedence that
FORCE_COLOR outranks NO_COLOR and a dumb TERM.
"""

# Exact stdout of 'shfmt -d messy.sh' for the content b"echo   hi\\n".
DIFF_PLAIN = (
    b"diff messy.sh.orig messy.sh\n"
    b"--- messy.sh.orig\n"
    b"+++ messy.sh\n"
    b"@@ -1,1 +1,1 @@\n"
    b"-echo   hi\n"
    b"+echo hi\n"
)

# The same diff with FORCE_COLOR=1: the three header lines are bold, the
# hunk header cyan, the removed line red, the added line green, then reset.
DIFF_COLORED = (
    b"\x1b[1m"
    b"diff messy.sh.orig messy.sh\n"
    b"--- messy.sh.orig\n"
    b"+++ messy.sh\n"
    b"\x1b[36m@@ -1,1 +1,1 @@\n"
    b"\x1b[31m-echo   hi\n"
    b"\x1b[32m+echo hi\n"
    b"\x1b[0m"
)


def test_diff_prints_unified_diff_and_errors(run_shfmt, make_tree):
    """-d prints the exact unified diff for a differing discovered file."""
    # CATCHES: diff headers use path.orig/path and a difference exits 1
    make_tree({"messy.sh": b"echo   hi\n", "clean.sh": b"echo hi\n"})
    messy = run_shfmt("-d", "messy.sh")
    assert messy.returncode == 1
    assert messy.stdout == DIFF_PLAIN
    assert messy.stderr == b""
    clean = run_shfmt("-d", "clean.sh")
    assert clean.returncode == 0
    assert clean.stdout == b""
    assert clean.stderr == b""


def test_diff_colored_when_force_color_set(run_shfmt, make_tree):
    """FORCE_COLOR=1 colors the diff even with TERM=dumb and NO_COLOR set."""
    # CATCHES: FORCE_COLOR outranks both NO_COLOR and a dumb TERM
    make_tree({"messy.sh": b"echo   hi\n"})
    colored = run_shfmt("-d", "messy.sh", env={"FORCE_COLOR": "1"})
    assert colored.returncode == 1
    assert colored.stdout == DIFF_COLORED
    assert colored.stderr == b""
    # NO_COLOR cannot cancel FORCE_COLOR; the color decision checks the
    # latter first, so the colored bytes come out identically.
    both = run_shfmt("-d", "messy.sh", env={"FORCE_COLOR": "1", "NO_COLOR": "1"})
    assert both.returncode == 1
    assert both.stdout == DIFF_COLORED
    assert both.stderr == b""
