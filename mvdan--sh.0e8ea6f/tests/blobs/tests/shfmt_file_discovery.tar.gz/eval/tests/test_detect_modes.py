"""The --detect flag: how hard to look for shebangs in non-shell-extension files.

``default`` only inspects extensionless files, ``exec`` additionally inspects
executable files with a non-shell extension, and ``all`` inspects every regular
non-hidden file.  Hidden files are never rescued by any mode.
"""

import os

import pytest


def test_detect_default_skips_non_shell_extension(run_shfmt, make_tree):
    """By default a file with a non-shell extension is skipped despite a shebang."""
    # CATCHES: the default mode does not read shebangs of *.other files
    make_tree({"a.other": b"#!/bin/sh\ntrue\n", "keep.sh": b"true\n"})
    res = run_shfmt("-f", "--detect=default", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"keep.sh\n"


def test_detect_all_reads_shebang_of_any_extension(run_shfmt, make_tree):
    """--detect=all reads the shebang of every regular file whatever its name."""
    # CATCHES: 'all' upgrades non-shell-extension files to shebang candidates
    make_tree(
        {
            "a.other": b"#!/bin/sh\ntrue\n",
            "b.other": b"true\n",
            "keep.sh": b"true\n",
        }
    )
    res = run_shfmt("-f", "--detect=all", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"a.other\nkeep.sh\n"


def test_detect_exec_requires_executable_bit(run_shfmt, make_tree, tmp_path):
    """--detect=exec only reads the shebang when the executable bit is set."""
    # CATCHES: 'exec' gates the extra shebang read on the 0o111 mode bits
    make_tree({"a.other": b"#!/bin/sh\ntrue\n", "keep.sh": b"true\n"})
    plain = run_shfmt("-f", "--detect=exec", ".")
    assert plain.returncode == 0, plain.stderr
    assert plain.stdout == b"keep.sh\n"
    os.chmod(str(tmp_path / "a.other"), 0o755)
    executable = run_shfmt("-f", "--detect=exec", ".")
    assert executable.returncode == 0, executable.stderr
    assert executable.stdout == b"a.other\nkeep.sh\n"


def test_detect_exec_still_requires_a_shebang(run_shfmt, make_tree, tmp_path):
    """An executable file without a shell shebang stays undiscovered."""
    # CATCHES: the exec bit alone never makes a file a shell script
    make_tree({"b.other": b"true\n", "keep.sh": b"true\n"})
    os.chmod(str(tmp_path / "b.other"), 0o755)
    res = run_shfmt("-f", "--detect=exec", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"keep.sh\n"


def test_detect_never_rescues_hidden_files(run_shfmt, make_tree):
    """--detect=all does not apply to files whose name starts with a dot."""
    # CATCHES: the hidden-file rejection happens before the detect upgrade
    make_tree({".hidden.other": b"#!/bin/sh\ntrue\n", "keep.sh": b"true\n"})
    res = run_shfmt("-f", "--detect=all", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"keep.sh\n"


def test_detect_applies_to_explicit_arguments(run_shfmt, make_tree):
    """--find on an explicit file argument applies the detect mode too."""
    # CATCHES: explicit arguments are re-classified when --find is active
    make_tree({"a.other": b"#!/bin/sh\ntrue\n"})
    all_mode = run_shfmt("-f", "--detect=all", "a.other")
    assert all_mode.returncode == 0, all_mode.stderr
    assert all_mode.stdout == b"a.other\n"
    default_mode = run_shfmt("-f", "--detect=default", "a.other")
    assert default_mode.returncode == 0, default_mode.stderr
    assert default_mode.stdout == b""


def test_detect_applies_when_formatting_a_directory(run_shfmt, make_tree):
    """--detect changes which files a plain directory walk formats."""
    # CATCHES: detection is not limited to --find, it also gates formatting
    make_tree(
        {
            "a.other": b"#!/bin/sh\necho   one\n",
            "b.other": b"echo   two\n",
            "d.sh": b"echo   four\n",
        }
    )
    res = run_shfmt("--detect=all", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"#!/bin/sh\necho one\necho four\n"


def test_detect_exec_accepts_any_executable_bit(run_shfmt, make_tree, tmp_path):
    """Any of the three execute bits is enough for --detect=exec."""
    # CATCHES: the check is mode&0o111, so owner, group and other all count
    make_tree(
        {
            "owner.txt": b"#!/bin/sh\ntrue\n",
            "group.txt": b"#!/bin/sh\ntrue\n",
            "other.txt": b"#!/bin/sh\ntrue\n",
            "keep.sh": b"true\n",
        }
    )
    os.chmod(str(tmp_path / "owner.txt"), 0o100)
    os.chmod(str(tmp_path / "group.txt"), 0o010)
    os.chmod(str(tmp_path / "other.txt"), 0o001)
    res = run_shfmt("-f", "--detect=exec", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        b"group.txt\nkeep.sh\nother.txt\nowner.txt\n"
    )


def test_detect_all_rescues_name_with_inner_shell_extension(run_shfmt, make_tree):
    """A name like run.sh.txt has a non-shell extension until --detect=all."""
    # CATCHES: the shell-extension regexp is anchored at the end of the name
    make_tree({"run.sh.txt": b"#!/bin/sh\ntrue\n", "keep.sh": b"true\n"})
    default = run_shfmt("-f", "--detect=default", ".")
    assert default.returncode == 0, default.stderr
    assert default.stdout == b"keep.sh\n"
    all_mode = run_shfmt("-f", "--detect=all", ".")
    assert all_mode.returncode == 0, all_mode.stderr
    assert all_mode.stdout == b"keep.sh\nrun.sh.txt\n"


@pytest.mark.parametrize(
    "mode",
    [
        pytest.param("default", id="default"),
        pytest.param("exec", id="exec"),
        pytest.param("all", id="all"),
    ],
)
def test_shell_extension_independent_of_detect_mode(run_shfmt, make_tree, mode):
    """A .sh file is always a script, and a shebang-less .other file never is."""
    # CATCHES: no detect mode can demote a shell extension or promote a plain file
    make_tree({"plain.sh": b"true\n", "noshebang.other": b"true\n"})
    res = run_shfmt("-f", "--detect=%s" % mode, ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"plain.sh\n"


@pytest.mark.parametrize(
    "value",
    [
        pytest.param("bad", id="bad"),
        pytest.param("DEFAULT", id="uppercase"),
        pytest.param("", id="empty"),
    ],
)
def test_detect_invalid_value_rejected(run_shfmt, make_tree, value):
    """An unknown --detect value is rejected before any file is touched."""
    # CATCHES: only the exact strings default, exec and all are accepted
    make_tree({"keep.sh": b"true\n"})
    res = run_shfmt("--detect=%s" % value, ".")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"--detect only allows default, exec, or all\n"
