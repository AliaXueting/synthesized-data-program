"""Recursive walking of path arguments (filepath.WalkDir in cmd/shfmt/main.go).

Path arguments are walked depth-first in sorted order, VCS directories are
pruned, symlinks are only resolved when they are the argument itself, and the
path strings printed by ``--find`` echo the argument for the root entry but a
cleaned join for everything below it.
"""

import os

VCS_DIRS = [".git", ".svn", ".hg"]
LOOKALIKE_DIRS = [".bzr", ".github", ".git2", "git", ".GIT", "node_modules"]


def test_recursive_walk_in_sorted_order(run_shfmt, make_tree):
    """Entries are visited in byte order, descending into directories as met."""
    # CATCHES: the walk is sorted, not in raw readdir order
    make_tree(
        {
            "zz.sh": b"true\n",
            "aa.sh": b"true\n",
            "Mm.sh": b"true\n",
            "0.sh": b"true\n",
            "_u.sh": b"true\n",
            "b.sh": b"true\n",
            "Zdir/z.sh": b"true\n",
            "Adir/a.sh": b"true\n",
            "sub/deep/c.sh": b"true\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        b"0.sh\n"
        b"Adir/a.sh\n"
        b"Mm.sh\n"
        b"Zdir/z.sh\n"
        b"_u.sh\n"
        b"aa.sh\n"
        b"b.sh\n"
        b"sub/deep/c.sh\n"
        b"zz.sh\n"
    )


def test_vcs_directories_pruned(run_shfmt, make_tree):
    """A .git/.svn/.hg directory is skipped entirely during a walk."""
    # CATCHES: only those three exact VCS directory names are pruned
    make_tree(
        dict(
            [("%s/x.sh" % vcs, b"true\n") for vcs in VCS_DIRS] + [("keep.sh", b"true\n")]
        )
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"keep.sh\n"


def test_lookalike_directories_not_pruned(run_shfmt, make_tree):
    """Directories that merely resemble a VCS dir are still walked."""
    # CATCHES: the pruning regexp is anchored and case sensitive
    make_tree(
        dict(
            [("%s/x.sh" % name, b"true\n") for name in LOOKALIKE_DIRS]
            + [("keep.sh", b"true\n")]
        )
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        b".GIT/x.sh\n"
        b".bzr/x.sh\n"
        b".git2/x.sh\n"
        b".github/x.sh\n"
        b"git/x.sh\n"
        b"keep.sh\n"
        b"node_modules/x.sh\n"
    )


def test_vcs_directory_pruned_as_explicit_argument(run_shfmt, make_tree):
    """Naming a VCS directory directly still prunes it, unlike hidden files."""
    # CATCHES: the vcsDir check runs before the explicit-argument special cases
    make_tree({".git/x.sh": b"true\n", "keep.sh": b"true\n"})
    res = run_shfmt("-f", ".git")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b""
    control = run_shfmt("-f", "keep.sh")
    assert control.stdout == b"keep.sh\n"
    inside = run_shfmt("-f", ".git/x.sh")
    assert inside.returncode == 0, inside.stderr
    assert inside.stdout == b".git/x.sh\n"


def test_vcs_directories_pruned_at_any_depth(run_shfmt, make_tree):
    """A VCS directory nested deep in the tree is pruned just like a top one."""
    # CATCHES: the prune checks every directory entry, not only the walk root
    make_tree(
        {
            "deep/.git/x.sh": b"true\n",
            "deep/keep.sh": b"true\n",
            "nested/inner/.svn/y.sh": b"true\n",
            "nested/inner/keep2.sh": b"true\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"deep/keep.sh\nnested/inner/keep2.sh\n"
    direct = run_shfmt("-f", "deep/.git")
    assert direct.returncode == 0, direct.stderr
    assert direct.stdout == b""


def test_symlinks_skipped_when_found_by_walk(run_shfmt, make_tree, tmp_path):
    """Symlinks met while walking are never followed or reported."""
    # CATCHES: a symlink is a non-regular entry even when it points at a script
    make_tree(
        {
            "real.sh": b"true\n",
            "realdir/inner.sh": b"true\n",
            "noext": b"#!/bin/sh\ntrue\n",
        }
    )
    os.symlink("real.sh", str(tmp_path / "link.sh"))
    os.symlink("noext", str(tmp_path / "link-noext"))
    os.symlink("realdir", str(tmp_path / "linkdir"))
    os.symlink("nowhere", str(tmp_path / "broken.sh"))
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"noext\nreal.sh\nrealdir/inner.sh\n"


def test_explicit_symlink_argument_is_resolved(run_shfmt, make_tree, tmp_path):
    """A symlink given as an argument is stat'ed and its target processed."""
    # CATCHES: explicit symlink arguments must be resolved, unlike walked ones
    make_tree({"target.sh": b"echo   hi\n", "noext": b"#!/bin/sh\ntrue\n"})
    os.symlink("target.sh", str(tmp_path / "link.sh"))
    os.symlink("noext", str(tmp_path / "link-noext"))
    res = run_shfmt("-f", "link.sh", "link-noext")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"link.sh\nlink-noext\n"
    formatted = run_shfmt("link.sh")
    assert formatted.returncode == 0, formatted.stderr
    assert formatted.stdout == b"echo hi\n"


def test_explicit_broken_symlink_errors(run_shfmt, make_tree, tmp_path):
    """A dangling symlink argument fails with a stat error and exit code 1."""
    # CATCHES: resolving an explicit symlink must surface stat's error message
    make_tree({"keep.sh": b"true\n"})
    os.symlink("nowhere.sh", str(tmp_path / "broken.sh"))
    res = run_shfmt("-f", "broken.sh")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"stat broken.sh: no such file or directory\n"
    walked = run_shfmt("-f", ".")
    assert walked.returncode == 0, walked.stderr
    assert walked.stderr == b""
    assert walked.stdout == b"keep.sh\n"


def test_symlink_to_directory_argument(run_shfmt, make_tree, tmp_path):
    """A symlink argument pointing at a directory resolves to a directory."""
    # CATCHES: after resolving, a directory argument is still not a script
    make_tree({"realdir/inner.sh": b"true\n", "keep.sh": b"true\n"})
    os.symlink("realdir", str(tmp_path / "linkdir"))
    res = run_shfmt("-f", "linkdir")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b""
    control = run_shfmt("-f", "realdir")
    assert control.stdout == b"realdir/inner.sh\n"


def test_root_argument_echoed_verbatim(run_shfmt, make_tree):
    """The argument itself is printed as given; children are path-joined."""
    # CATCHES: only entries below the root get filepath.Join's cleaning
    make_tree({"a.sh": b"true\n", "sub/b.sh": b"true\n"})
    for arg, expected in [
        ("./a.sh", b"./a.sh\n"),
        ("././a.sh", b"././a.sh\n"),
        ("sub/../a.sh", b"sub/../a.sh\n"),
        ("./sub", b"sub/b.sh\n"),
        ("./", b"a.sh\nsub/b.sh\n"),
    ]:
        res = run_shfmt("-f", arg)
        assert res.returncode == 0, res.stderr
        assert res.stdout == expected


def test_multiple_arguments_processed_in_order(run_shfmt, make_tree):
    """Each argument is walked in turn, in the order given on the command line."""
    # CATCHES: arguments are not merged, sorted or de-duplicated against each other
    make_tree({"a.sh": b"true\n", "b.sh": b"true\n", "sub/c.sh": b"true\n"})
    res = run_shfmt("-f", "b.sh", "sub", "a.sh")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"b.sh\nsub/c.sh\na.sh\n"
    again = run_shfmt("-f", "a.sh", "a.sh")
    assert again.returncode == 0, again.stderr
    assert again.stdout == b"a.sh\na.sh\n"


def test_directory_argument_formats_every_discovered_file(run_shfmt, make_tree):
    """Without -f, a directory argument prints each discovered file in order."""
    # CATCHES: discovery decides which files reach the formatter when walking
    make_tree(
        {
            "a.sh": b"echo   one\n",
            "b.txt": b"echo   two\n",
            "c": b"#!/bin/sh\necho   three\n",
            "sub/d.sh": b"echo   four\n",
        }
    )
    res = run_shfmt(".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"echo one\n#!/bin/sh\necho three\necho four\n"


def test_absolute_path_argument(run_shfmt, make_tree, tmp_path):
    """An absolute argument makes --find print absolute paths."""
    # CATCHES: the printed paths always start with the argument as given
    make_tree({"sub/b.sh": b"true\n"})
    res = run_shfmt("-f", str(tmp_path / "sub"))
    assert res.returncode == 0, res.stderr
    assert res.stdout.decode().splitlines() == [
        str(tmp_path / "sub" / "b.sh"),
    ]


def test_write_refuses_explicit_symlink(run_shfmt, make_tree, tmp_path):
    """-w refuses to replace an explicit symlink that needs reformatting."""
    # CATCHES: -w lstats the link itself and refuses non-regular targets
    make_tree({"target.sh": b"echo   hi\n"})
    os.symlink("target.sh", str(tmp_path / "L.sh"))
    res = run_shfmt("-w", "L.sh")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'refusing to atomically replace "L.sh" with a regular file '
        b"as it is not one already\n"
    )
    # Neither the link nor its target was modified.
    assert (tmp_path / "target.sh").read_bytes() == b"echo   hi\n"
    assert os.path.islink(str(tmp_path / "L.sh"))
