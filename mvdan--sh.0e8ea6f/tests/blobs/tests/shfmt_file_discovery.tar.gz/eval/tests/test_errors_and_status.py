"""Error paths and exit statuses triggered while discovering and walking files.

Missing paths, paths that traverse a file, and unparseable scripts each produce
a specific message on stderr and a non-zero exit status, while the remaining
path arguments are still processed.  Standard input, used when no path argument
is given at all, has an error path of its own.
"""

import pytest


def test_no_arguments_reads_standard_input(run_shfmt, make_tree):
    """With no path arguments the input is formatted and written to stdout."""
    # CATCHES: an empty argument list means stdin, not an error or the usage
    make_tree({"a.sh": b"true\n"})
    res = run_shfmt(stdin=b"echo   hi\n")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"echo hi\n"
    assert res.stderr == b""
    dash = run_shfmt("-", stdin=b"echo   hi\n")
    assert dash.returncode == 0, dash.stderr
    assert dash.stdout == b"echo hi\n"


def test_write_flag_refused_on_standard_input(run_shfmt, make_tree):
    """-w is rejected for standard input with a message and exit code 1."""
    # CATCHES: stdin has no file to write back to, so -w is refused early
    make_tree({"a.sh": b"true\n"})
    for args in (("-w",), ("-w", "-")):
        res = run_shfmt(*args, stdin=b"echo   hi\n")
        assert res.returncode == 1, (args, res.stderr)
        assert res.stdout == b""
        assert res.stderr == b"-w cannot be used on standard input\n"


def test_nonexistent_path_argument(run_shfmt, make_tree):
    """A missing path argument reports an lstat error and exits with 1."""
    # CATCHES: the message names the argument verbatim and uses lstat, not stat
    make_tree({"keep.sh": b"true\n"})
    res = run_shfmt("-f", "nosuch.sh")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"lstat nosuch.sh: no such file or directory\n"


def test_nonexistent_path_keeps_trailing_slash(run_shfmt, make_tree):
    """The error message echoes the argument including a trailing slash."""
    # CATCHES: the root path is not cleaned before being reported
    make_tree({"keep.sh": b"true\n"})
    res = run_shfmt("-f", "nosuchdir/")
    assert res.returncode == 1
    assert res.stderr == b"lstat nosuchdir/: no such file or directory\n"


def test_every_missing_argument_is_reported(run_shfmt, make_tree):
    """Each missing argument gets its own error line, in argument order."""
    # CATCHES: a failing argument does not abort the loop over the arguments
    make_tree({"keep.sh": b"true\n"})
    res = run_shfmt("-f", "m1", "m2", "m3")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"lstat m1: no such file or directory\n"
        b"lstat m2: no such file or directory\n"
        b"lstat m3: no such file or directory\n"
    )


def test_remaining_arguments_processed_after_error(run_shfmt, make_tree):
    """A missing argument does not stop later arguments from being walked."""
    # CATCHES: the per-argument loop keeps going and the exit status stays 1
    make_tree({"ok.sh": b"true\n"})
    after = run_shfmt("-f", "ok.sh", "m2")
    assert after.returncode == 1
    assert after.stdout == b"ok.sh\n"
    assert after.stderr == b"lstat m2: no such file or directory\n"
    before = run_shfmt("-f", "m2", "ok.sh")
    assert before.returncode == 1
    assert before.stdout == b"ok.sh\n"
    assert before.stderr == b"lstat m2: no such file or directory\n"


def test_path_through_a_file_is_not_a_directory(run_shfmt, make_tree):
    """Treating a file as a directory fails with ENOTDIR."""
    # CATCHES: the lstat error for a bad path component is surfaced as-is
    make_tree({"a.sh": b"true\n"})
    res = run_shfmt("-f", "a.sh/b.sh")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"lstat a.sh/b.sh: not a directory\n"


def test_empty_path_argument(run_shfmt, make_tree):
    """An empty argument is passed to lstat verbatim rather than dropped."""
    # CATCHES: empty arguments are not filtered out before the walk starts
    make_tree({"ok.sh": b"true\n"})
    res = run_shfmt("-f", "ok.sh", "")
    assert res.returncode == 1
    assert res.stdout == b"ok.sh\n"
    assert res.stderr == b"lstat : no such file or directory\n"


def test_trailing_slash_on_a_file_argument(run_shfmt, make_tree):
    """Slashes after a file name make the path a directory that cannot exist."""
    # CATCHES: the path is handed to lstat uncleaned, yielding ENOTDIR
    make_tree({"a.sh": b"true\n"})
    res = run_shfmt("-f", "a.sh/")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"lstat a.sh/: not a directory\n"


def test_parse_error_in_walk_still_formats_others(run_shfmt, make_tree):
    """A broken script in a walk is reported while other files get formatted."""
    # CATCHES: one bad file sets the exit status but does not stop the walk
    make_tree({"a.sh": b"echo   one\n", "bad.sh": b"foo(\n"})
    res = run_shfmt(".")
    assert res.returncode == 1
    assert res.stdout == b"echo one\n"
    assert res.stderr == b"bad.sh:1:1: `foo(` must be followed by `)`\n"
    explicit = run_shfmt("bad.sh")
    assert explicit.returncode == 1
    assert explicit.stdout == b""
    assert explicit.stderr == b"bad.sh:1:1: `foo(` must be followed by `)`\n"


def test_too_short_files_are_silently_skipped(run_shfmt, make_tree):
    """Files shorter than nine bytes cannot hold a shebang and are skipped."""
    # CATCHES: a short read is not an error, the file is simply not a script
    make_tree(
        {
            "control.sh": b"true\n",
            "empty": b"",
            "one": b"x",
            "eight": b"#!/bin/s",
            "nine": b"#!/bin/sh",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == b"control.sh\nnine\n"


def test_list_exit_status_reflects_differences(run_shfmt, make_tree):
    """-l lists differing files with status 1 and prints nothing for clean ones."""
    # CATCHES: discovery feeds -l, and the status depends on whether it differs
    make_tree({"messy.sh": b"echo   hi\n", "clean.sh": b"echo hi\n"})
    messy = run_shfmt("-l", "messy.sh")
    assert messy.returncode == 1
    assert messy.stdout == b"messy.sh\n"
    clean = run_shfmt("-l", "clean.sh")
    assert clean.returncode == 0
    assert clean.stdout == b""


def test_directory_without_shell_files_is_silent(run_shfmt, make_tree, tmp_path):
    """Walking a directory with no shell scripts produces no output and status 0."""
    # CATCHES: an empty discovery result is a success, not an error
    make_tree({"data.txt": b"nothing here\n", "sub/note.md": b"nothing\n"})
    empty = tmp_path / "emptydir"
    empty.mkdir()
    for arg in (".", "emptydir"):
        res = run_shfmt("-f", arg)
        assert res.returncode == 0, res.stderr
        assert res.stdout == b""
    assert (tmp_path / "data.txt").read_bytes() == b"nothing here\n"
    control = run_shfmt("-f", "sub/note.md")
    assert control.returncode == 0, control.stderr
    assert control.stdout == b""
    positive = run_shfmt("-f", "data.txt", "nosuch.sh")
    assert positive.returncode == 1
    assert positive.stderr == b"lstat nosuch.sh: no such file or directory\n"


def test_list_zero_separates_with_nul(run_shfmt, make_tree):
    """-l=0 lists differing files separated by NUL instead of a newline."""
    # CATCHES: the =0 spelling switches the list separator to a zero byte
    make_tree({"a.sh": b"echo   hi\n", "b.sh": b"echo   hi\n", "clean.sh": b"echo hi\n"})
    single = run_shfmt("-l=0", "a.sh")
    assert single.returncode == 1
    assert single.stdout == b"a.sh\x00"
    assert single.stderr == b""
    walked = run_shfmt("--list=0", ".")
    assert walked.returncode == 1
    assert walked.stdout == b"a.sh\x00b.sh\x00"
    assert walked.stderr == b""


@pytest.mark.parametrize("value", ["1", "yes"])
def test_list_invalid_value_rejected(run_shfmt, make_tree, value):
    """List flag values other than the implicit true and 0 are refused."""
    # CATCHES: only -l and -l=0 parse; any other =value aborts before walking
    make_tree({"a.sh": b"echo   hi\n"})
    res = run_shfmt("-l=%s" % value, "a.sh")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"only -l and -l=0 allowed\n"


@pytest.mark.parametrize(
    "flag,message",
    [
        ("--to-json", "--to-json can only be used with stdin"),
        ("--from-json", "--from-json can only be used with stdin"),
    ],
)
def test_stdin_only_flags_rejected_with_paths(run_shfmt, make_tree, flag, message):
    """--to-json and --from-json refuse to run when path arguments are given."""
    # CATCHES: these flags read only stdin; a path argument aborts the run
    make_tree({"a.sh": b"echo   hi\n"})
    res = run_shfmt(flag, "a.sh")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == message.encode() + b"\n"
