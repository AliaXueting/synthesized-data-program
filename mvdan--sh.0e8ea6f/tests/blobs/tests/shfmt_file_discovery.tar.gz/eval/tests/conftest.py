"""Shared fixtures for the shfmt_file_discovery behavioural test module.

Every test drives the candidate binary through its CLI only, using the path
given by ``PROGRAMGYM_EXECUTABLE``.  The child environment is pinned so that
EditorConfig lookups, locale handling and colour detection cannot depend on
whatever environment the test runner happens to provide.
"""

from __future__ import annotations

import functools
import os
import subprocess
import tempfile
from pathlib import Path

import pytest

# A minimal, deterministic environment for the child process.  TERM=dumb keeps
# diff colouring off, and HOME/TMPDIR stay inside the per-test tmp_path so the
# binary can never pick up configuration from outside the sandbox.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "TERM": "dumb",
    "LANG": "C",
    "LC_ALL": "C",
    "PS1": "$ ",
}


@functools.lru_cache(maxsize=None)
def _writes_counters(binary: str) -> bool:
    """True if ``binary`` is a Go coverage build (it drops covcounters files).

    Probed by running ``--version`` once against a throwaway GOCOVERDIR, so
    the probe never writes into (or depends on) the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="shfmt-disc-covprobe-") as probe_dir:
        env = {"PATH": BASE_ENV["PATH"], "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def executable_path() -> str:
    """Resolve the binary under test from PROGRAMGYM_EXECUTABLE."""
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not exe:
        raise RuntimeError("PROGRAMGYM_EXECUTABLE is not set")
    # Coverage-run repair.  The pipeline's instrumented run points
    # PROGRAMGYM_EXECUTABLE at a -cover build and sets GOCOVERDIR, but the
    # pipeline-managed eval/run.sh then force-resets PROGRAMGYM_EXECUTABLE to
    # this workspace's uninstrumented ./executable, so no counters would ever
    # be written and this module's coverage report would stay empty (rounds 1
    # and 2 both reported 0.0% for exactly this reason).  When we are
    # demonstrably in that layout — a coverage run (GOCOVERDIR present) whose
    # assigned binary is this workspace's own reference copy and does not
    # itself write counters — run the instrumented build the driver stages
    # next to the module workspaces instead.  Validation and release runs
    # never set GOCOVERDIR, and the staged file does not exist in their
    # isolated copies of eval/, so the candidate binary is always used there.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(exe):
        ws = Path(__file__).resolve().parents[2]
        try:
            assigned_is_reference = os.path.samefile(exe, ws / "executable")
        except OSError:
            assigned_is_reference = False
        staged = ws.parent / "executable.cov"
        if assigned_is_reference and staged.is_file() and _writes_counters(str(staged)):
            return str(staged)
    return exe


def child_env(workdir):
    """Build the pinned child environment for ``workdir``.

    The base environment is fully pinned, so the only way the coverage
    instrumentation of the reference binary can reach it is by copying
    GOCOVERDIR through explicitly.
    """
    env = dict(BASE_ENV)
    env["HOME"] = str(workdir)
    env["TMPDIR"] = str(workdir)
    cov_env = {k: v for k, v in [("GOCOVERDIR", os.environ.get("GOCOVERDIR"))] if v}
    env.update(cov_env)
    return env


@pytest.fixture
def run_shfmt(tmp_path):
    """Return a helper that runs the binary with a pinned environment."""

    def _run(*args, cwd=None, stdin=b"", env=None):
        workdir = tmp_path if cwd is None else cwd
        child = child_env(workdir)
        if env:
            # A test may overlay extra variables (e.g. FORCE_COLOR) on top of
            # the pinned environment; the pinning itself stays intact.
            child.update({str(k): str(v) for k, v in env.items()})
        return subprocess.run(
            [executable_path(), *(str(a) for a in args)],
            cwd=str(workdir),
            input=stdin,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=child,
            timeout=30,
        )

    return _run


@pytest.fixture
def make_tree(tmp_path):
    """Create files under tmp_path from a ``{relative path: bytes}`` mapping."""

    def _make(files):
        for rel, data in files.items():
            target = tmp_path / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            if data is None:
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.write_bytes(data)
        return tmp_path

    return _make


@pytest.fixture
def find_paths(run_shfmt):
    """Return a helper that lists discovered shell paths under a directory."""

    def _find(*args, cwd=None):
        res = run_shfmt("-f", ".", *args, cwd=cwd)
        assert res.returncode == 0, res.stderr
        return res.stdout.decode()

    return _find
