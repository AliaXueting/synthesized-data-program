"""The -f/--find utility flag: listing discovered shell paths without formatting.

``-f`` and ``--find`` print one path per line, ``-f=0`` separates them with NUL
bytes, only the values true/false/0 are accepted, and find mode short-circuits
before any formatting, listing or writing happens.
"""

import pytest


def test_find_short_and_long_flags(run_shfmt, make_tree):
    """-f and --find list the same paths on stdout with nothing on stderr."""
    # CATCHES: both spellings of the flag must behave identically
    make_tree({"a.sh": b"true\n", "sub/b.sh": b"true\n", "c.txt": b"true\n"})
    short = run_shfmt("-f", ".")
    long = run_shfmt("--find", ".")
    for res in (short, long):
        assert res.returncode == 0, res.stderr
        assert res.stderr == b""
        assert res.stdout == b"a.sh\nsub/b.sh\n"


def test_find_zero_separates_with_nul(run_shfmt, make_tree):
    """-f=0 and --find=0 print paths terminated by NUL instead of a newline."""
    # CATCHES: the NUL form emits a trailing NUL and no newline at all
    make_tree({"a.sh": b"true\n", "b.sh": b"true\n"})
    for flag in ("-f=0", "--find=0"):
        res = run_shfmt(flag, ".")
        assert res.returncode == 0, res.stderr
        assert res.stdout == b"a.sh\0b.sh\0"


@pytest.mark.parametrize(
    "value",
    [
        pytest.param("1", id="one"),
        pytest.param("yes", id="yes"),
        pytest.param("TRUE", id="uppercase-true"),
    ],
)
def test_find_invalid_value_rejected(run_shfmt, make_tree, value):
    """Only true, false and 0 are accepted as -f/--find values."""
    # CATCHES: the flag is a tri-state bool-string, not a plain boolean
    make_tree({"a.sh": b"true\n"})
    res = run_shfmt("--find=%s" % value, ".")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"only -f and -f=0 allowed\n"


def test_find_false_disables_find(run_shfmt, make_tree):
    """--find=false turns the flag off again and formats instead."""
    # CATCHES: 'false' is an accepted value that restores normal behaviour
    make_tree({"a.sh": b"echo   hi\n"})
    res = run_shfmt("--find=false", "a.sh")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"echo hi\n"


def test_find_repeated_flag_last_wins(run_shfmt, make_tree):
    """Repeating the flag with a different value keeps the last one."""
    # CATCHES: the bool-string flag is overwritten rather than OR-ed together
    make_tree({"a.sh": b"true\n"})
    nul_last = run_shfmt("-f", "-f=0", ".")
    assert nul_last.stdout == b"a.sh\0"
    line_last = run_shfmt("-f=0", "-f", ".")
    assert line_last.stdout == b"a.sh\n"


def test_find_does_not_write_files(run_shfmt, make_tree, tmp_path):
    """-f wins over -w: files are listed and left untouched on disk."""
    # CATCHES: find mode returns before the write branch is ever reached
    make_tree({"a.sh": b"echo   hi\n"})
    res = run_shfmt("-f", "-w", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"a.sh\n"
    assert (tmp_path / "a.sh").read_bytes() == b"echo   hi\n"


def test_find_overrides_list(run_shfmt, make_tree):
    """With -f active, -l never reports formatting differences."""
    # CATCHES: find mode returns before the list/diff logic runs, so exit is 0
    make_tree({"a.sh": b"echo   hi\n"})
    res = run_shfmt("-l", "-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"a.sh\n"


def test_find_reads_standard_input_for_dash(run_shfmt, make_tree):
    """A lone '-' argument reads stdin and formats it even with -f active."""
    # CATCHES: --find has no effect on the standard-input code path
    make_tree({"a.sh": b"true\n"})
    res = run_shfmt("-f", "-", stdin=b"echo   hi\n")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"echo hi\n"


def test_find_does_not_parse_file_contents(run_shfmt, make_tree):
    """A file with a syntax error is still listed by -f with a zero status."""
    # CATCHES: find mode returns after reading the shebang, before parsing
    make_tree({"bad.sh": b"foo(\n", "good.sh": b"echo   hi\n"})
    res = run_shfmt("-f", "bad.sh", "good.sh")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"bad.sh\ngood.sh\n"
    assert res.stderr == b""
    listed = run_shfmt("-l", "-f", ".")
    assert listed.returncode == 0, listed.stderr
    assert listed.stdout == b"bad.sh\ngood.sh\n"


def test_find_with_no_stdin_filename_arg(run_shfmt, make_tree):
    """--filename is refused when a path argument is present."""
    # CATCHES: --filename is only meaningful for standard input
    make_tree({"a.sh": b"true\n"})
    res = run_shfmt("--filename=x.sh", "a.sh")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"-filename can only be used with stdin\n"
