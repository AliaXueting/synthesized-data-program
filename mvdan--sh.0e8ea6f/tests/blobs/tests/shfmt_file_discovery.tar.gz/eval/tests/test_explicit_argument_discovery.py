"""How explicit path arguments are classified as shell scripts.

Naming a path on the command line does *not* guarantee it is treated as a
script: the walk callback keeps the "explicit" mark only for the root entry of
each ``filepath.WalkDir`` call, and as soon as ``--find`` is active (or the
entry is not a regular file) even that root is re-classified through
``fileutil.CouldBeScript2``.  These tests pin the resulting matrix, including
the fact that an explicit symlink is stat'ed for its type and mode while the
name used for classification stays the argument's own basename.
"""

import os


def test_find_skips_explicit_hidden_file(run_shfmt, make_tree):
    """--find refuses a hidden file even though formatting it works."""
    # CATCHES: find mode re-classifies explicit args, so dot-files vanish
    make_tree({".hidden.sh": b"echo   hi\n"})
    plain = run_shfmt("-f", ".hidden.sh")
    assert plain.returncode == 0, plain.stderr
    assert plain.stdout == b""
    assert plain.stderr == b""
    all_mode = run_shfmt("-f", "--detect=all", ".hidden.sh")
    assert all_mode.returncode == 0, all_mode.stderr
    assert all_mode.stdout == b""
    formatted = run_shfmt(".hidden.sh")
    assert formatted.returncode == 0, formatted.stderr
    assert formatted.stdout == b"echo hi\n"


def test_find_skips_explicit_non_shell_extension(run_shfmt, make_tree):
    """--find ignores an explicit *.txt argument even with a shell shebang."""
    # CATCHES: the non-shell extension wins over the shebang for explicit args
    make_tree({"a.txt": b"#!/bin/sh\ntrue\n"})
    plain = run_shfmt("-f", "a.txt")
    assert plain.returncode == 0, plain.stderr
    assert plain.stdout == b""
    assert plain.stderr == b""
    rescued = run_shfmt("-f", "--detect=all", "a.txt")
    assert rescued.returncode == 0, rescued.stderr
    assert rescued.stdout == b"a.txt\n"


def test_find_requires_a_shebang_for_explicit_extensionless(run_shfmt, make_tree):
    """An extensionless explicit argument is only found when it has a shebang."""
    # CATCHES: explicit extensionless args fall back to ConfIfShebang under -f
    make_tree({"noext": b"#!/bin/sh\ntrue\n", "plain": b"true\n"})
    with_shebang = run_shfmt("-f", "noext")
    assert with_shebang.returncode == 0, with_shebang.stderr
    assert with_shebang.stdout == b"noext\n"
    without = run_shfmt("-f", "plain")
    assert without.returncode == 0, without.stderr
    assert without.stdout == b""
    assert without.stderr == b""
    formatted = run_shfmt("plain")
    assert formatted.returncode == 0, formatted.stderr
    assert formatted.stdout == b"true\n"


def test_find_classifies_explicit_symlink_by_link_name(run_shfmt, make_tree, tmp_path):
    """A symlink argument is classified by its own basename, not its target's."""
    # CATCHES: os.Stat only lends its type and mode, Name() stays the argument
    make_tree(
        {
            "target_noext": b"#!/bin/sh\ntrue\n",
            "target_plain": b"plain text no shebang\n",
        }
    )
    os.symlink("target_noext", str(tmp_path / "L1.txt"))
    os.symlink("target_plain", str(tmp_path / "L2.sh"))
    by_name = run_shfmt("-f", "L1.txt")
    assert by_name.returncode == 0, by_name.stderr
    assert by_name.stdout == b""
    assert by_name.stderr == b""
    shell_name = run_shfmt("-f", "L2.sh")
    assert shell_name.returncode == 0, shell_name.stderr
    assert shell_name.stdout == b"L2.sh\n"
    # In format mode both are processed, reading through the link.
    formatted = run_shfmt("L1.txt", "L2.sh")
    assert formatted.returncode == 0, formatted.stderr
    assert formatted.stdout == b"#!/bin/sh\ntrue\nplain text no shebang\n"


def test_explicit_symlink_detect_exec_uses_target_mode(run_shfmt, make_tree, tmp_path):
    """--detect=exec looks at the stat'ed mode of a symlink's target."""
    # CATCHES: resolving an explicit symlink must keep the target's mode bits
    make_tree(
        {
            "exec_target.txt": b"#!/bin/sh\ntrue\n",
            "plain_target.txt": b"#!/bin/sh\ntrue\n",
        }
    )
    os.chmod(str(tmp_path / "exec_target.txt"), 0o755)
    os.symlink("exec_target.txt", str(tmp_path / "Lexec.txt"))
    os.symlink("plain_target.txt", str(tmp_path / "Lplain.txt"))
    exec_mode = run_shfmt("-f", "--detect=exec", "Lexec.txt")
    assert exec_mode.returncode == 0, exec_mode.stderr
    assert exec_mode.stdout == b"Lexec.txt\n"
    no_bit = run_shfmt("-f", "--detect=exec", "Lplain.txt")
    assert no_bit.returncode == 0, no_bit.stderr
    assert no_bit.stdout == b""
    all_mode = run_shfmt("-f", "--detect=all", "Lplain.txt")
    assert all_mode.returncode == 0, all_mode.stderr
    assert all_mode.stdout == b"Lplain.txt\n"


def test_explicit_fifo_is_not_opened(run_shfmt, make_tree, tmp_path):
    """A FIFO argument is skipped, never opened, while sibling args format."""
    # CATCHES: non-regular explicit args must never reach os.Open on a FIFO
    make_tree({"real.sh": b"echo   hi\n", "other.sh": b"echo   x\n"})
    os.mkfifo(str(tmp_path / "pipe.sh"))
    # Format mode: the fifo is skipped silently, the .sh argument still
    # formats (a candidate that opens the fifo blocks and times out instead).
    fmt = run_shfmt("pipe.sh", "real.sh")
    assert fmt.returncode == 0, fmt.stderr
    assert fmt.stdout == b"echo hi\n"
    assert fmt.stderr == b""
    # Find mode lists the regular scripts, never the fifo — its .sh name
    # cannot rescue it because non-regular entries are always discarded.
    found = run_shfmt("-f", ".")
    assert found.returncode == 0, found.stderr
    assert found.stdout == b"other.sh\nreal.sh\n"
    assert found.stderr == b""
    # -w rewrites the regular file in place without ever touching the fifo.
    wrote = run_shfmt("-w", "pipe.sh", "other.sh")
    assert wrote.returncode == 0, wrote.stderr
    assert wrote.stdout == b""
    assert wrote.stderr == b""
    assert (tmp_path / "other.sh").read_bytes() == b"echo x\n"


def test_explicit_non_shell_file_formatted_whatever_detect(run_shfmt, make_tree):
    """A named *.txt file is formatted regardless of the --detect mode."""
    # CATCHES: detect only matters for walked entries, never for explicit ones
    make_tree({"a.txt": b"#!/bin/sh\ntrue\n", "b.txt": b"echo   hi\n"})
    for mode in ("default", "exec", "all"):
        res = run_shfmt("--detect=%s" % mode, "a.txt", "b.txt")
        assert res.returncode == 0, (mode, res.stderr)
        assert res.stdout == b"#!/bin/sh\ntrue\necho hi\n", mode
        assert res.stderr == b"", mode


def test_file_named_like_vcs_dir_is_formatted_when_explicit(run_shfmt, make_tree):
    """A regular file called .git is not pruned and is formatted when named."""
    # CATCHES: the vcsDir prune requires entry.IsDir(), a file is never pruned
    make_tree({"fdir/.git": b"echo   hi\n", "fdir/keep.sh": b"true\n"})
    explicit = run_shfmt("fdir/.git")
    assert explicit.returncode == 0, explicit.stderr
    assert explicit.stdout == b"echo hi\n"
    walked = run_shfmt("-f", "fdir")
    assert walked.returncode == 0, walked.stderr
    assert walked.stdout == b"fdir/keep.sh\n"


def test_apply_ignore_prunes_explicit_directory_argument(run_shfmt, make_tree):
    """--apply-ignore on an ignored directory argument skips the whole walk."""
    # CATCHES: SkipDir returned for the walk root ends the walk without error
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[sub]\nignore = true\n",
            "sub/x.sh": b"echo   x\n",
            "top.sh": b"echo   x\n",
        }
    )
    without_flag = run_shfmt("-f", "sub")
    assert without_flag.returncode == 0, without_flag.stderr
    assert without_flag.stdout == b"sub/x.sh\n"
    for args in (
        ("--apply-ignore", "-f", "sub"),
        ("--apply-ignore", "sub"),
        ("--apply-ignore", "-l", "sub"),
    ):
        res = run_shfmt(*args)
        assert res.returncode == 0, (args, res.stderr)
        assert res.stdout == b""
        assert res.stderr == b""
    # The rule matches the directory entry, not the files below it.
    walk = run_shfmt("--apply-ignore", "-f", ".")
    assert walk.returncode == 0, walk.stderr
    assert walk.stdout == b"top.sh\n"


def test_apply_ignore_matches_hidden_explicit_file(run_shfmt, make_tree):
    """--apply-ignore drops an explicit hidden file when a rule names it."""
    # CATCHES: EditorConfig globs match dot-file names for explicit arguments
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[.hidden.sh]\nignore = true\n",
            ".hidden.sh": b"echo   x\n",
        }
    )
    ignored = run_shfmt("--apply-ignore", ".hidden.sh")
    assert ignored.returncode == 0, ignored.stderr
    assert ignored.stdout == b""
    assert ignored.stderr == b""
    plain = run_shfmt(".hidden.sh")
    assert plain.returncode == 0, plain.stderr
    assert plain.stdout == b"echo x\n"
