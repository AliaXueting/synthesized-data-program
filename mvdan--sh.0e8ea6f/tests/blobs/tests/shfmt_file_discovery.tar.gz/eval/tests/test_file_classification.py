"""Classifying directory entries as shell scripts (fileutil.CouldBeScript2).

A walked entry is only considered a shell script when its name does not start
with a dot, it is a regular file, and either it carries a shell extension or it
has no extension at all (in which case the shebang decides).  These tests pin
the name-based half of that decision.
"""

import os

SHELL_EXTS = ["sh", "bash", "mksh", "bats", "zsh"]
NON_SHELL_EXTS = ["txt", "py", "go", "md", "ssh", "SH"]


def test_shell_extension_discovered(run_shfmt, make_tree):
    """A regular file named *.<shell ext> is a script with no shebang at all."""
    # CATCHES: all five shell extensions are accepted, not just .sh
    make_tree({"script.%s" % ext: b"true\n" for ext in SHELL_EXTS})
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        b"script.bash\nscript.bats\nscript.mksh\nscript.sh\nscript.zsh\n"
    )


def test_non_shell_extension_skipped(run_shfmt, make_tree):
    """A file with a non-shell extension is skipped even with a shell shebang."""
    # CATCHES: the extension check wins over the shebang for named extensions
    make_tree(
        dict(
            [("control.sh", b"true\n")]
            + [("script.%s" % ext, b"#!/bin/sh\ntrue\n") for ext in NON_SHELL_EXTS]
        )
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\n"


def test_dotted_names_without_shell_extension(run_shfmt, make_tree):
    """Names whose only dot is not a shell extension are never scripts."""
    # CATCHES: 'a.' and 'a.sh.' still count as having a non-shell extension
    make_tree(
        {
            "control.sh": b"true\n",
            "a.": b"#!/bin/sh\ntrue\n",
            "a.sh.": b"#!/bin/sh\ntrue\n",
            "a.sh.txt": b"#!/bin/sh\ntrue\n",
            "a.bash.txt": b"#!/bin/sh\ntrue\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\n"


def test_hidden_files_skipped_while_walking(run_shfmt, make_tree):
    """Dot-files are never discovered, whatever their extension or shebang."""
    # CATCHES: the leading '.' check happens before the extension check
    make_tree(
        {
            ".hidden.sh": b"true\n",
            ".hidden": b"#!/bin/sh\ntrue\n",
            "..hidden": b"#!/bin/bash\ntrue\n",
            ".profile": b"#!/bin/sh\ntrue\n",
            "visible.sh": b"true\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"visible.sh\n"


def test_hidden_file_processed_when_explicit(run_shfmt, make_tree):
    """A hidden file named as an explicit argument is still formatted."""
    # CATCHES: discovery only filters walked entries, not explicit arguments
    make_tree(
        {
            ".hidden.sh": b"echo   hi\n",
            ".noext": b"#!/bin/sh\ntrue\n",
        }
    )
    res = run_shfmt(".hidden.sh")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"echo hi\n"
    res2 = run_shfmt(".noext")
    assert res2.returncode == 0, res2.stderr
    assert res2.stdout == b"#!/bin/sh\ntrue\n"


def test_hidden_directories_are_walked(run_shfmt, make_tree):
    """Hidden directories are descended into; only their entries are filtered."""
    # CATCHES: a leading dot prunes a *file*, not the directory that holds it
    make_tree(
        {
            ".config/b.sh": b"true\n",
            ".local/a.sh": b"true\n",
            "top.sh": b"true\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b".config/b.sh\n.local/a.sh\ntop.sh\n"


def test_named_pipe_is_skipped(run_shfmt, make_tree, tmp_path):
    """A FIFO is not a regular file and is skipped both when walked and explicit."""
    # CATCHES: non-regular files must never be opened, which would block on a FIFO
    make_tree({"real.sh": b"true\n"})
    os.mkfifo(str(tmp_path / "pipe.sh"))
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"real.sh\n"
    explicit = run_shfmt("-f", "pipe.sh")
    assert explicit.returncode == 0, explicit.stderr
    assert explicit.stdout == b""


def test_extensionless_file_depends_on_shebang(run_shfmt, make_tree):
    """Among extensionless files only the ones with a shell shebang are found."""
    # CATCHES: extensionless entries fall through to the shebang check
    make_tree(
        {
            "control.sh": b"true\n",
            "with_shebang": b"#!/bin/sh\ntrue\n",
            "without_shebang": b"true\n",
            "plain_text": b"just some words\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\nwith_shebang\n"


def test_extensionless_shebang_file_is_formatted(run_shfmt, make_tree):
    """A shebang-only extensionless file found in a walk gets formatted to stdout."""
    # CATCHES: discovery feeds the formatter, and the shebang line is preserved
    make_tree({"script": b"#!/bin/sh\necho   hi\n"})
    res = run_shfmt(".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"#!/bin/sh\necho hi\n"


def test_explicit_extensionless_file_formatted_without_shebang(run_shfmt, make_tree):
    """An explicit extensionless file is formatted whatever its first line is."""
    # CATCHES: explicit arguments are assumed to be scripts without any check
    make_tree({"script": b"#!/usr/bin/perl\ntrue\n"})
    res = run_shfmt("script")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"#!/usr/bin/perl\ntrue\n"
