"""Dialect resolution for shell config file names (bashrc, zshrc, ...).

``langFromFilename`` maps a handful of dot-file basenames to a fixed
dialect: the bash family (``bashrc``, ``bash_profile``, ``bash_logout``)
always parses as bash and the zsh family (``zshenv``, ``zprofile``,
``zshrc``, ``zlogin``, ``zlogout``) as zsh — with or without the leading
dot, and regardless of any shebang inside the file.  Generic extensionless
names instead fall back to the shebang, or to bash when there is none.
These names are only special as explicit arguments: a walk never
discovers them, because they carry no shell extension and typically no
shebang.
"""

import pytest

# Parameter expansion valid only in zsh; bash rejects it as a LangError.
ZSH_ONLY = b"x=${+foo}\n"
# Parameter expansion valid only in bash-like shells; zsh rejects it.
BASH_ONLY = b"y=${x^}\n"


@pytest.mark.parametrize("name", ["zshrc", ".zshrc", "zshenv", "zprofile", "zlogin", "zlogout"])
def test_zsh_config_names_parse_as_zsh(run_shfmt, make_tree, name):
    """Every zsh config name accepts zsh-only syntax, dot or no dot."""
    # CATCHES: the whole zsh family maps to the zsh dialect by name alone
    make_tree({name: ZSH_ONLY})
    res = run_shfmt(name)
    assert res.returncode == 0, (name, res.stderr)
    assert res.stdout == ZSH_ONLY
    assert res.stderr == b""


@pytest.mark.parametrize(
    "name", ["bashrc", ".bashrc", "bash_profile", ".bash_profile", "bash_logout"]
)
def test_bash_config_names_parse_as_bash(run_shfmt, make_tree, name):
    """Every bash config name accepts bash-only syntax, dot or no dot."""
    # CATCHES: the whole bash family maps to the bash dialect by name alone
    make_tree({name: BASH_ONLY})
    res = run_shfmt(name)
    assert res.returncode == 0, (name, res.stderr)
    assert res.stdout == BASH_ONLY
    assert res.stderr == b""


def test_generic_extensionless_name_falls_back_to_bash(run_shfmt, make_tree):
    """A generic extensionless name parses as bash when no shebang exists."""
    # CATCHES: without a config name or shebang the dialect falls back to bash
    make_tree({"plainname": ZSH_ONLY})
    res = run_shfmt("plainname")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"plainname:1:3: `${+foo}` is a zsh feature; tried parsing as bash "
        b"(parsed as bash via -ln=auto)\n"
    )


def test_zsh_config_name_rejects_bash_only_syntax(run_shfmt, make_tree):
    """Bash-only syntax in a zsh config name errors naming the zsh dialect."""
    # CATCHES: the parse error text proves the file was parsed as zsh
    make_tree({"zshrc": BASH_ONLY})
    res = run_shfmt("zshrc")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"zshrc:1:6: this expansion operator is a bash feature; "
        b"tried parsing as zsh (parsed as zsh via -ln=auto)\n"
    )


def test_config_name_beats_shebang(run_shfmt, make_tree):
    """The config-name dialect wins over a contradicting shebang inside."""
    # CATCHES: for config names the shebang is never read; the name decides
    make_tree(
        {
            "bashrc": b"#!/bin/zsh\n" + BASH_ONLY,
            "zshrc": b"#!/bin/bash\n" + ZSH_ONLY,
            "plainname": b"#!/bin/zsh\n" + BASH_ONLY,
        }
    )
    bash_named = run_shfmt("bashrc")
    assert bash_named.returncode == 0, bash_named.stderr
    assert bash_named.stdout == b"#!/bin/zsh\n" + BASH_ONLY
    zsh_named = run_shfmt("zshrc")
    assert zsh_named.returncode == 0, zsh_named.stderr
    assert zsh_named.stdout == b"#!/bin/bash\n" + ZSH_ONLY
    # Without a config name the shebang decides, so the same content that
    # was fine as "bashrc" is a bash-ism under a zsh shebang here.
    shebang_decides = run_shfmt("plainname")
    assert shebang_decides.returncode == 1
    assert shebang_decides.stdout == b""
    assert shebang_decides.stderr == (
        b"plainname:2:6: this expansion operator is a bash feature; "
        b"tried parsing as zsh (parsed as zsh via -ln=auto)\n"
    )


def test_config_names_are_not_discovered_by_walks(run_shfmt, make_tree):
    """A walk never lists config-named files even though they format fine."""
    # CATCHES: no extension and no shebang means walks skip bashrc/zshrc
    make_tree(
        {
            "bashrc": BASH_ONLY,
            "zshrc": ZSH_ONLY,
            "keep.sh": b"echo   hi\n",
        }
    )
    found = run_shfmt("-f", ".")
    assert found.returncode == 0, found.stderr
    assert found.stdout == b"keep.sh\n"
    assert found.stderr == b""
    formatted = run_shfmt("bashrc", "zshrc")
    assert formatted.returncode == 0, formatted.stderr
    assert formatted.stdout == BASH_ONLY + ZSH_ONLY
