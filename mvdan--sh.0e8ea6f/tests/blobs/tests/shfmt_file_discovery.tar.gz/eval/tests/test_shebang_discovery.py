"""Shebang-driven discovery of extensionless shell scripts.

`shfmt --find` only reports an extensionless regular file when the first bytes
of the file hold a shell shebang that `fileutil.Shebang` accepts.  These tests
pin down exactly which interpreter spellings count, how much whitespace is
tolerated, and the fact that only the first 32 bytes of the file are inspected.
"""

SHELLS = ["sh", "dash", "bash", "mksh", "bats", "zsh"]
CONTROL = {"control.sh": b"true\n"}


def tree_with(make_tree, first_lines):
    """Build a tree with one extensionless file per shebang line, plus a control."""
    files = dict(CONTROL)
    for name, first in first_lines.items():
        files[name] = first + b"true\n"
    return make_tree(files)


def test_bin_shebang_per_shell(run_shfmt, make_tree):
    """An extensionless file with '#!/bin/<shell>' is discovered by --find."""
    # CATCHES: every supported shell name must be accepted after /bin/
    tree_with(
        make_tree,
        {name: b"#!/bin/%s\n" % name.encode() for name in SHELLS},
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == b"bash\nbats\ncontrol.sh\ndash\nmksh\nsh\nzsh\n"


def test_usr_bin_and_env_shebang_forms(run_shfmt, make_tree):
    """'/usr/bin/x', '/usr/bin/env x' and '/bin/env x' shebangs are all accepted."""
    # CATCHES: the shebang regex must accept the optional 'usr/' and 'env ' parts
    tree_with(
        make_tree,
        {
            "usr_sh": b"#!/usr/bin/sh\n",
            "usr_bash": b"#!/usr/bin/bash\n",
            "usr_env_sh": b"#!/usr/bin/env sh\n",
            "usr_env_bash": b"#!/usr/bin/env bash\n",
            "usr_env_zsh": b"#!/usr/bin/env zsh\n",
            "bin_env_sh": b"#!/bin/env sh\n",
        },
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        b"bin_env_sh\n"
        b"control.sh\n"
        b"usr_bash\n"
        b"usr_env_bash\n"
        b"usr_env_sh\n"
        b"usr_env_zsh\n"
        b"usr_sh\n"
    )


def test_whitespace_after_hashbang(run_shfmt, make_tree):
    """Whitespace between '#!' and the interpreter path is tolerated."""
    # CATCHES: the shebang regex allows a run of spaces/tabs right after '#!'
    tree_with(
        make_tree,
        {
            "sp1": b"#! /bin/sh\n",
            "sp2": b"#!  /bin/sh\n",
            "tab": b"#!\t/bin/sh\n",
            "mix": b"#! \t /bin/sh\n",
        },
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\nmix\nsp1\nsp2\ntab\n"


def test_whitespace_between_env_and_shell(run_shfmt, make_tree):
    """Multiple spaces or a tab between 'env' and the shell name still match."""
    # CATCHES: 'env' is followed by a '[ \t]+' run, not exactly one space
    tree_with(
        make_tree,
        {
            "script": b"#!/usr/bin/env   bash\n",
            "tabbed": b"#!/usr/bin/env\tzsh\n",
        },
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\nscript\ntabbed\n"


def test_shebang_trailing_arguments_and_crlf(run_shfmt, make_tree):
    """A shebang may carry interpreter arguments and a CR before the newline."""
    # CATCHES: the shebang match ends at whitespace or end of input, not at EOL
    tree_with(
        make_tree,
        {
            "args": b"#!/bin/bash -e -x\n",
            "words": b"#!/bin/sh extra words here\n",
            "crlf": b"#!/bin/sh\r\n",
        },
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"args\ncontrol.sh\ncrlf\nwords\n"


def test_shebang_exact_nine_bytes(run_shfmt, make_tree):
    """A file holding only '#!/bin/sh' with no newline is still a shell script."""
    # CATCHES: the minimum shebang length of 9 bytes must be readable, not skipped
    make_tree({"control.sh": b"true\n", "nine": b"#!/bin/sh"})
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\nnine\n"


def test_rejected_prefix_forms(run_shfmt, make_tree):
    """Shebangs without a '/bin' path component are not shell scripts."""
    # CATCHES: '#!bin/sh', '#/bin/sh' and '#!//bin/sh' must all be rejected
    tree_with(
        make_tree,
        {
            "noslash": b"#!bin/sh\n",
            "onlyhash": b"#/bin/sh\n",
            "nointerp": b"#!foo bar\n",
            "dblslash": b"#!//bin/sh\n",
            "doubleusr": b"#!/usr/usr/bin/sh\n",
            "leading_nl": b"\n#!/bin/sh\n",
            "leading_sp": b" #!/bin/sh\n",
        },
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\n"


def test_rejected_non_shell_interpreters(run_shfmt, make_tree):
    """Shebangs pointing at non-shell interpreters never make a file a script."""
    # CATCHES: only sh/dash/bash/mksh/bats/zsh are accepted, not perl/python/etc.
    tree_with(
        make_tree,
        {
            "perl": b"#!/usr/bin/perl\n",
            "python": b"#!/usr/bin/python\n",
            "python3": b"#!/usr/bin/env python3\n",
            "ruby": b"#!/bin/ruby\n",
            "node": b"#!/usr/bin/node\n",
            "awk": b"#!/usr/bin/awk\n",
        },
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\n"


def test_rejected_word_boundary_and_case(run_shfmt, make_tree):
    """The shell name must end at a word boundary and match lower-case exactly."""
    # CATCHES: '#!/bin/shfoo', '#!/bin/SH' and '#!\f/bin/sh' are not shell files
    tree_with(
        make_tree,
        {
            "shfoo": b"#!/bin/shfoo\n",
            "sh2": b"#!/bin/sh2\n",
            "semi": b"#!/bin/sh;\n",
            "upper": b"#!/bin/SH\n",
            "capital": b"#!/bin/Sh\n",
            "formfeed": b"#!\f/bin/sh\n",
        },
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\n"


def test_shebang_read_window_is_32_bytes(run_shfmt, make_tree):
    """Only the first 32 bytes of a file are inspected when reading a shebang."""
    # CATCHES: a shebang starting past byte 32 of the file is never discovered
    make_tree(
        {
            "control.sh": b"true\n",
            "inside": b"#!" + b" " * 23 + b"/bin/sh\n# padding line\n",
            "outside": b"#!" + b" " * 24 + b"/bin/sh\n# padding line\n",
            "envinside": b"#!/usr/bin/env" + b" " * 14 + b"bash\n# padding\n",
            "envoutside": b"#!/usr/bin/env" + b" " * 15 + b"bash\n# padding\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"control.sh\nenvinside\ninside\n"
