"""EditorConfig ``ignore=true`` rules applied while discovering files.

Ignore rules always apply to entries found while walking, prune whole
directories, and are extended to explicit path arguments and to standard input
only when ``--apply-ignore`` is given.  Formatting properties themselves are a
different module's concern; only the ignore decisions are pinned here.
"""


def test_ignore_glob_skips_walked_files(run_shfmt, make_tree):
    """A file matching an ignore=true section is skipped during a walk."""
    # CATCHES: ignore rules apply to walked files even without --apply-ignore
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[*.md]\nignore = true\n",
            "keep.sh": b"echo   x\n",
            "note.md": b"echo   x\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"keep.sh\n"
    listed = run_shfmt("-l", ".")
    assert listed.returncode == 1
    assert listed.stdout == b"keep.sh\n"


def test_ignore_section_prunes_whole_directory(run_shfmt, make_tree):
    """A section naming a directory prunes the entire subtree while walking."""
    # CATCHES: a directory match returns filepath.SkipDir, not just a skip
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[sub]\nignore = true\n",
            "sub/x.sh": b"echo   x\n",
            "sub/deep/e.sh": b"echo   x\n",
            "top.sh": b"echo   x\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"top.sh\n"


def test_directory_section_does_not_match_its_files(run_shfmt, make_tree):
    """'[sub]' matches the directory entry only, not the files inside it."""
    # CATCHES: naming a directory as an explicit argument still formats its files
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[sub]\nignore = true\n",
            "sub/x.sh": b"echo   x\n",
            "top.sh": b"echo   x\n",
        }
    )
    res = run_shfmt("-l", "sub")
    assert res.returncode == 1, res.stderr
    assert res.stdout == b"sub/x.sh\n"
    ignored = run_shfmt("--apply-ignore", "-l", "sub/x.sh")
    assert ignored.returncode == 1
    assert ignored.stdout == b"sub/x.sh\n"


def test_recursive_glob_covers_explicit_directory_children(run_shfmt, make_tree):
    """A '**' section ignores the children of an explicitly given directory."""
    # CATCHES: children of an explicit argument are walked, so ignore applies
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[third_party/**]\nignore = true\n",
            "third_party/a.sh": b"echo   x\n",
            "keep.sh": b"echo   x\n",
        }
    )
    res = run_shfmt("-f", "third_party")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b""
    control = run_shfmt("-f", "keep.sh")
    assert control.stdout == b"keep.sh\n"


def test_explicit_file_ignores_rules_by_default(run_shfmt, make_tree):
    """A file named on the command line is formatted despite ignore=true."""
    # CATCHES: explicit arguments skip the EditorConfig ignore lookup by default
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[*.sh]\nignore = true\n",
            "a.sh": b"echo   x\n",
        }
    )
    res = run_shfmt("a.sh")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"echo x\n"


def test_apply_ignore_covers_explicit_file(run_shfmt, make_tree):
    """--apply-ignore extends ignore rules to explicit path arguments."""
    # CATCHES: with the flag an ignored explicit file produces no output at all
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[*.sh]\nignore = true\n",
            "a.sh": b"echo   x\n",
            "b.zsh": b"echo   x\n",
        }
    )
    res = run_shfmt("--apply-ignore", "a.sh")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b""
    kept = run_shfmt("--apply-ignore", "b.zsh")
    assert kept.returncode == 0, kept.stderr
    assert kept.stdout == b"echo x\n"


def test_apply_ignore_covers_stdin_filename(run_shfmt, make_tree):
    """--apply-ignore ignores stdin input whose --filename matches a rule."""
    # CATCHES: stdin has no path of its own, so --filename drives the lookup
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[skip.sh]\nignore = true\n",
            "keep.sh": b"true\n",
        }
    )
    res = run_shfmt("--apply-ignore", "--filename=skip.sh", stdin=b"echo   x\n")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b""
    kept = run_shfmt("--apply-ignore", "--filename=keep.sh", stdin=b"echo   x\n")
    assert kept.returncode == 0, kept.stderr
    assert kept.stdout == b"echo x\n"


def test_stdin_filename_not_ignored_without_flag(run_shfmt, make_tree):
    """Without --apply-ignore, stdin is formatted whatever --filename says."""
    # CATCHES: the ignore lookup for stdin only happens under --apply-ignore
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[skip.sh]\nignore = true\n",
        }
    )
    res = run_shfmt("--filename=skip.sh", stdin=b"echo   x\n")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"echo x\n"
    kept = run_shfmt("--apply-ignore", "--filename=other.sh", stdin=b"echo   x\n")
    assert kept.returncode == 0, kept.stderr
    assert kept.stdout == b"echo x\n"


def test_ignore_survives_formatting_flags(run_shfmt, make_tree):
    """Ignore rules still apply when a printer flag disables other EditorConfig use."""
    # CATCHES: ignore is evaluated during the walk, before useEditorConfig matters
    make_tree(
        {
            ".editorconfig": b"root = true\n\n[*.md]\nignore = true\n",
            "keep.sh": b"echo   x\n",
            "note.md": b"echo   x\n",
        }
    )
    res = run_shfmt("-i=0", "-l", ".")
    assert res.returncode == 1, res.stderr
    assert res.stdout == b"keep.sh\n"
    explicit = run_shfmt("-i=0", "--apply-ignore", "note.md")
    assert explicit.returncode == 0, explicit.stderr
    assert explicit.stdout == b""


def test_nested_editorconfig_applies_to_subtree(run_shfmt, make_tree):
    """An .editorconfig inside a subdirectory ignores files under it."""
    # CATCHES: the lookup walks up from each file, not from the argument root
    make_tree(
        {
            "sub/.editorconfig": b"[a.sh]\nignore = true\n",
            "sub/a.sh": b"echo   x\n",
            "top.sh": b"echo   x\n",
        }
    )
    res = run_shfmt("-f", ".")
    assert res.returncode == 0, res.stderr
    assert res.stdout == b"top.sh\n"


def test_ignore_value_must_be_lowercase_true(run_shfmt, make_tree):
    """Only the exact lower-case string 'true' triggers ignoring."""
    # CATCHES: 'True', '1' and 'yes' are compared as raw strings and never match
    make_tree({"a.sh": b"echo   x\n"})
    for value in (b"True", b"TRUE", b"1", b"yes"):
        make_tree({".editorconfig": b"root = true\n\n[a.sh]\nignore = %s\n" % value})
        res = run_shfmt("-f", ".")
        assert res.returncode == 0, (value, res.stderr)
        assert res.stdout == b"a.sh\n", value
    make_tree({".editorconfig": b"root = true\n\n[a.sh]\nignore = true\n"})
    ignored = run_shfmt("-f", ".")
    assert ignored.returncode == 0, ignored.stderr
    assert ignored.stdout == b""
