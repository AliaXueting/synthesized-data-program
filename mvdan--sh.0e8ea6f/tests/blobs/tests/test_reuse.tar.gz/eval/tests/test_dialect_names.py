"""Dialect selection by filename and by shebang spelling.

Ported from the langFromFilename half of cmd/shfmt/main.go (also exercised
by the flags.txtar cases for /etc/zprofile and .zshrc) and from the
TestShebang table in fileutil/file_test.go. Both sides were recorded by
running the reference binary; the discriminating content is zsh-only
syntax (``${+foo}``), which fails to parse under any other dialect.
"""

import pytest

ZSH_ONLY = "${+foo}\n"

# Shell startup filenames are recognised like an extension, and they win
# over the shebang line inside the file.
BASH_RCFILES = [
    pytest.param("bashrc", id="bashrc"),
    pytest.param(".bashrc", id="dot-bashrc"),
    pytest.param("bash_profile", id="bash-profile"),
    pytest.param("bash_logout", id="bash-logout"),
]

ZSH_RCFILES = [
    pytest.param("zshrc", id="zshrc"),
    pytest.param("zshenv", id="zshenv"),
    pytest.param("zlogin", id="zlogin"),
    pytest.param("zlogout", id="zlogout"),
]

BASH_RCFILE_ERR = (
    "bashrc:2:1: `${+foo}` is a zsh feature; tried parsing as bash"
    " (parsed as bash via -ln=auto)\n"
)


@pytest.mark.parametrize("name", BASH_RCFILES)
def test_bash_startup_filenames_force_the_bash_dialect(run, name):
    """bashrc-style names parse as bash even with a zsh shebang inside."""
    result = run(["--filename=" + name], stdin="#!/bin/zsh\n" + ZSH_ONLY)
    # CATCHES: the filename is consulted before the shebang, so the zsh
    # shebang is ignored and the zsh-only expansion is a parse error whose
    # message names both the file and the dialect that was tried.
    assert (result.returncode, result.out, result.err) == (
        1, "",
        "%s:2:1: `${+foo}` is a zsh feature; tried parsing as bash"
        " (parsed as bash via -ln=auto)\n" % name)


@pytest.mark.parametrize("name", ZSH_RCFILES)
def test_zsh_startup_filenames_force_the_zsh_dialect(run, name):
    """zshrc-style names parse as zsh even with a bash shebang inside."""
    result = run(["--filename=" + name], stdin="#!/bin/bash\n" + ZSH_ONLY)
    # CATCHES: the recognised filename overrides the shebang, so the zsh
    # expansion parses and the program is printed back unchanged.
    assert (result.returncode, result.out, result.err) == (
        0, "#!/bin/bash\n" + ZSH_ONLY, "")


def test_an_unrecognised_name_falls_back_to_the_shebang(run):
    """A filename that is not a shell startup file defers to the shebang."""
    result = run(["--filename=notarc"], stdin="#!/bin/bash\n" + ZSH_ONLY)
    # CATCHES: only the known startup names are treated like extensions;
    # anything else keeps the normal shebang-based detection, which picks
    # bash here and rejects the zsh expansion.
    assert result.returncode == 1
    assert result.err == (
        "notarc:2:1: `${+foo}` is a zsh feature; tried parsing as bash"
        " (parsed as bash via -ln=auto)\n")


def test_startup_filenames_apply_to_walked_files(run, write):
    """Walked startup files use their name's dialect, not their shebang."""
    write("bashrc", "#!/bin/zsh\n" + ZSH_ONLY)
    write("zshenv", "#!/bin/bash\n" + ZSH_ONLY)
    listed = run(["-f", "."])
    # CATCHES: both files are detected as scripts through their shebangs,
    # so -f lists them both...
    assert (listed.returncode, listed.out, listed.err) == (
        0, "bashrc\nzshenv\n", "")
    formatted = run(["."])
    # CATCHES: ...but formatting then parses each with the dialect its
    # filename implies, so zshenv round-trips and bashrc fails.
    assert formatted.returncode == 1
    assert formatted.out == "#!/bin/bash\n" + ZSH_ONLY
    assert formatted.err == BASH_RCFILE_ERR


def test_a_bashrc_file_argument_keeps_its_own_dialect(run, write):
    """Naming a bashrc file directly also parses it as bash."""
    write("bashrc", "#!/bin/zsh\n" + ZSH_ONLY)
    result = run(["bashrc"])
    # CATCHES: the explicit-argument path uses the same filename rules as
    # stdin's --filename, so the error is labelled with the given path.
    assert (result.returncode, result.out, result.err) == (1, "", BASH_RCFILE_ERR)


# --- shebang spellings, from fileutil's TestShebang table ---------------

# Each entry is (content, parses-as-zsh). A shebang the reference does not
# recognise falls back to bash, which rejects the zsh-only expansion.
SHEBANG_CASES = [
    pytest.param("#!/usr/bin/env zsh\n", True, id="env-zsh"),
    pytest.param("#!  /bin/zsh\n", True, id="two-spaces"),
    pytest.param("#! /bin/zsh true\n", True, id="space-then-arguments"),
    pytest.param("#!\t/bin/env\tzsh\n", True, id="tabs-around-env"),
    pytest.param("#!\f/bin/zsh\n", False, id="form-feed-is-not-a-space"),
    pytest.param("#!/bin/bash4\n", False, id="version-suffix"),
    pytest.param("#!/bin/envsh\n", False, id="env-without-a-space"),
    pytest.param("#!/bin/sh5\n", False, id="sh-with-a-version-suffix"),
]


@pytest.mark.parametrize("shebang,recognised", SHEBANG_CASES)
def test_shebang_spellings_select_the_dialect(run, shebang, recognised):
    """Only the shebang spellings the regex allows pick their dialect."""
    result = run([], stdin=shebang + ZSH_ONLY)
    if recognised:
        # CATCHES: the shebang names zsh, so the expansion parses and the
        # whole program (shebang included) is echoed back unchanged.
        assert (result.returncode, result.out, result.err) == (
            0, shebang + ZSH_ONLY, "")
    else:
        # CATCHES: an unrecognised shebang falls back to bash, which
        # rejects the zsh expansion while still reporting the fallback.
        assert result.returncode == 1
        assert result.out == ""
        assert result.err == (
            "<standard input>:2:1: `${+foo}` is a zsh feature;"
            " tried parsing as bash (parsed as bash via -ln=auto)\n")


def test_env_dash_maps_onto_the_posix_dialect(run):
    """A '#!/usr/bin/env dash' shebang parses the file as POSIX shell."""
    result = run([], stdin="#!/usr/bin/env dash\nfoo=(bar)\n")
    # CATCHES: 'dash' is accepted by the shebang regex but is not a
    # dialect of its own — it maps onto POSIX, which rejects arrays.
    assert (result.returncode, result.out, result.err) == (
        1, "",
        "<standard input>:2:5: arrays are a bash/mksh/zsh feature;"
        " tried parsing as posix (parsed as posix via -ln=auto)\n")
