"""Simplification behaviour, ported from the native syntax/simplify_test.go
table. Cases whose native expectation equals the input ('noSimple') pin that
-s leaves the program untouched."""

import pytest

SIMPLIFY_CASES = [
    pytest.param('$((a + ((b - c))))', '$((a + (b - c)))', id='double-parens'),
    pytest.param('${foo[(1)]}', '${foo[1]}', id='array-index-parens'),
    pytest.param('${foo:(1):(2)}', '${foo:1:2}', id='slice-parens'),
    pytest.param('$(($a + ${b}))', '$((a + b))', id='dollar-names-dropped'),
    pytest.param('$((${!a} + ${#b}))', '$((${!a} + ${#b}))', id='special-names-kept'),
    pytest.param('[[ "$foo" == "bar" ]]', '[[ $foo == "bar" ]]', id='quoted-left-word'),
    pytest.param('[[ ! -n $foo ]]', '[[ -z $foo ]]', id='negated-test-flipped'),
    pytest.param('[[ (! a == b) || (! c != d) ]]', '[[ (a != b) || (c == d) ]]',
                 id='inner-negations-folded'),
    pytest.param('[[ foo = bar ]]', '[[ foo == bar ]]', id='single-equals-doubled'),
    pytest.param('$( (sts))', '$(sts)', id='cmdsubst-space-dropped'),
    pytest.param('"foo$bar"', '"foo$bar"', id='expansion-quotes-kept'),
    pytest.param('"fo\\$o"', "'fo$o'", id='escapable-dquote-becomes-squote'),
]


@pytest.mark.parametrize("source,want", SIMPLIFY_CASES)
def test_simplify_flag_matches_native_expectations(run, source, want):
    """-s rewrites each program exactly as the native table records."""
    result = run(["-s"], stdin=source)
    # CATCHES: simplification covers arithmetic paren removal, ${..}
    # folding, test expression rewriting and quote switching, each
    # producing the exact native golden string.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")


@pytest.mark.parametrize("source,want", SIMPLIFY_CASES)
def test_simplify_output_parses_again(run, source, want):
    """The simplified output is itself valid, canonical shell."""
    result = run([], stdin=want)
    # CATCHES: simplification must never produce a program that the
    # parser rejects or that prints differently on a second pass.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")
