"""Node-shape round trips beyond the ported native tables, recorded from
the reference binary.

The shapes here pin how rarely-used productions print back: declare with
no or odd arguments, every coproc spelling, time with assignments, the
zsh-only function/brace/index forms, for loops with no `in` clause or a
`!` word, mksh's `case {` header (rewritten to `in`/`esac`), assignments
prefixing negated and compound commands, and empty assignment values.
"""

import pytest

ROUND_TRIPS = [
    pytest.param("declare", [], "declare", id="declare-alone"),
    pytest.param("declare [[", [], "declare [[", id="declare-double-brackets"),
    pytest.param("coproc (echo hi)", ["-ln=bash"], "coproc (echo hi)",
                 id="coproc-subshell"),
    pytest.param("coproc ((x))", ["-ln=bash"], "coproc ((x))",
                 id="coproc-arithmetic"),
    pytest.param("coproc foo", ["-ln=bash"], "coproc foo",
                 id="coproc-name"),
    pytest.param("coproc foo bar", ["-ln=bash"], "coproc foo bar",
                 id="coproc-name-and-args"),
    pytest.param("coproc while true; do sleep 1; done", ["-ln=bash"],
                 "coproc while true; do sleep 1; done", id="coproc-compound"),
    pytest.param("time", ["-ln=bash"], "time", id="time-alone"),
    pytest.param("time -p ls", ["-ln=bash"], "time -p ls", id="time-p-flag"),
    pytest.param("time a=b cmd", ["-ln=bash"], "time a=b cmd",
                 id="time-with-assignment"),
    pytest.param("function", ["-ln=posix"], "function",
                 id="function-is-a-plain-word-in-posix"),
    pytest.param("function { :; }", ["-ln=zsh"], "function { :; }",
                 id="anonymous-function-in-zsh"),
    pytest.param("echo a\"b\"", ["-ln=zsh"], "echo a\"b\"",
                 id="adjacent-double-quotes-in-zsh"),
    pytest.param("for x; do :; done", ["-ln=bash"], "for x; do :; done",
                 id="for-without-in"),
    pytest.param("for x in !; do :; done", ["-ln=bash"],
                 "for x in !; do :; done", id="for-over-bang-word"),
    pytest.param("! a=b cmd", ["-ln=bash"], "! a=b cmd",
                 id="assignment-after-negation"),
    pytest.param("if a=b cmd; then :; fi", ["-ln=bash"],
                 "if a=b cmd; then :; fi", id="assignment-in-if-head"),
    pytest.param("while a=b cmd; do :; done", ["-ln=bash"],
                 "while a=b cmd; do :; done", id="assignment-in-while-head"),
    pytest.param("a[i]=", ["-ln=zsh"], "a[i]=", id="zsh-indexed-assignment"),
    pytest.param("a=([i]=)", ["-ln=bash"], "a=([i]=)",
                 id="array-element-empty-value"),
    pytest.param("a= cmd", ["-ln=bash"], "a= cmd", id="empty-assignment-value"),
]


@pytest.mark.parametrize("source,flags,want", ROUND_TRIPS)
def test_node_shape_roundtrip(run, source, flags, want):
    """Each shape prints back byte-identically (or as recorded)."""
    result = run(flags, stdin=source)
    # CATCHES: bare declare/time/function keywords survive alone, `[[`
    # after declare is just a word, all five coproc spellings and
    # assignment-prefixed negations/compounds round-trip, and zsh-only
    # forms are gated to their dialect.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, (want + "\n").encode(), b"")


def test_mksh_case_brace_header_is_rewritten(run):
    """mksh's `case x {` header is printed back in the portable spelling."""
    result = run(["-ln=mksh"], stdin="case x { a) b ;; }\n")
    # CATCHES: the brace form parses only in mksh, and the printer
    # normalises it to `in` ... `esac` rather than echoing the braces.
    assert (result.returncode, result.out, result.err) == (
        0, "case x in a) b ;; esac\n", "")


def test_zsh_unclosed_brace_gains_semicolon(run):
    """zsh allows a block without a final `;` before `}`; bash does not."""
    result = run(["-ln=zsh"], stdin="{ echo hi }\n")
    # CATCHES: under zsh the missing separator is legal and the printer
    # completes it to `echo hi; }`, while the same input is an unclosed
    # block error under bash — the dialect choice changes both the parse
    # and the printed separator.
    assert (result.returncode, result.out, result.err) == (
        0, "{ echo hi; }\n", "")
    rejected = run(["-ln=bash"], stdin="{ echo hi }\n")
    # CATCHES: in bash the `}` never binds to the `{`, so the error is
    # the generic unmatched-brace one, not a missing-semicolon one.
    assert (rejected.returncode, rejected.stdout,
            rejected.stderr) == (
        1, b"", b"<standard input>:1:1: reached EOF without matching `{` "
                b"with `}`\n")


@pytest.mark.parametrize(
    "source",
    [
        pytest.param("case x in (esac) b ;; esac", id="parenthesised-esac"),
        pytest.param("case x in 'esac') b ;; esac", id="quoted-esac"),
    ])
def test_esac_pattern_needs_disambiguation(run, source):
    """A pattern spelled `esac` is kept parenthesised or quoted."""
    result = run(["-ln=bash"], stdin=source + "\n")
    # CATCHES: a bare `esac` pattern would end the case statement, so
    # the printer re-emits the disambiguating paren or quotes it had;
    # dropping them would make the output unparseable.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, (source + "\n").encode(), b"")


def test_comment_after_else_separates_clauses(run):
    """A trailing comment ends the else-clause line; the next statement
    moves to its own line, indented with a real tab."""
    result = run(["-s", "-ln=bash"], stdin="if a; then b; else # c\nd; fi\n")
    # CATCHES: the comment cannot share its line with the following
    # statement, so `d` is pushed onto a new line indented by a literal
    # tab — the bytes between `# c` and `d` are exactly `\n\t`.
    assert (result.returncode, result.out, result.err) == (
        0, "if a; then b; else # c\n\td\nfi\n", "")


def test_line_number_overflow_renders_question_mark(run, write):
    """A position past line 262143 prints `?` instead of a line number."""
    write("many.sh", ":\n" * 262144 + ")\n")
    result = run(["many.sh"])
    # CATCHES: line numbers are packed into 18 bits, so line 262145
    # overflows and the position renders `many.sh:?:1:` rather than
    # a wrong wrapped number — the error message itself is intact.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", b"many.sh:?:1: `)` can only be used to close a subshell\n")


def test_column_overflow_renders_question_mark(run, write):
    """A position past column 16383 prints `?` instead of a column."""
    write("long.sh", "a" * 16400 + " )\n")
    result = run(["long.sh"])
    # CATCHES: columns are packed into 14 bits, so column 16403
    # overflows and renders `long.sh:1:?:` — the `?` replaces only the
    # column while the file path and message stay exact.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", b"long.sh:1:?: a command can only contain words and "
                b"redirects; encountered `)`\n")
