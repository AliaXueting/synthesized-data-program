"""Printer behaviour, ported from the native syntax/printer_test.go table.

Each case records (input, canonical output). The reference test suite also
re-runs every input wrapped in blank lines and re-formats the golden output;
those two variants are asserted here as well.
"""

import pytest

PRINT_CASES = [
    pytest.param('fo○ b\\år', 'fo○ b\\år', id='unicode-literal'),
    pytest.param('foo; bar', 'foo\nbar', id='semicolon-split'),
    pytest.param('main "$@"; exit $?', 'main "$@"; exit $?', id='exit-guard-stays'),
    pytest.param('a=$1; shift', 'a=$1; shift', id='shift-guard-stays'),
    pytest.param('cat <<DOC; exit 1\nbody\nDOC', 'cat <<DOC; exit 1\nbody\nDOC',
                 id='heredoc-exit-guard'),
    pytest.param('foo; exit 1; bar', 'foo; exit 1\nbar', id='exit-splits-list'),
    pytest.param('case $1 in\n-v) x=1; break ;;\nesac',
                 'case $1 in\n-v)\n\tx=1; break\n\t;;\nesac', id='case-item-newlines'),
    pytest.param('foo\n\n\nbar', 'foo\n\nbar', id='blank-lines-collapse'),
    pytest.param('foo\n\n', 'foo', id='trailing-blank-lines-dropped'),
    pytest.param('\n\nfoo', 'foo', id='leading-blank-lines-dropped'),
    pytest.param('# foo \n # bar\t', '# foo\n# bar', id='comment-padding-trimmed'),
    pytest.param('if a\nthen\n\tb\nfi', 'if a; then\n\tb\nfi', id='then-joined'),
    pytest.param('foo >&2>/dev/null', 'foo >&2 >/dev/null', id='redirects-split'),
    pytest.param('exec {foo[1]}>&-', 'exec {foo[1]}>&-', id='fd-closing-kept'),
    pytest.param('foo <<EOF bar\nl1\nEOF', 'foo bar <<EOF\nl1\nEOF', id='heredoc-moved-last'),
    pytest.param('{ foo; bar; }', '{\n\tfoo\n\tbar\n}', id='block-expanded'),
    pytest.param('a=\\\nfoo\nb=\\\n"bar"\nc=\\\n\'baz\'',
                 'a=foo\nb="bar"\nc=\'baz\'', id='assignment-continuations'),
    pytest.param('(foo; bar)', '(\n\tfoo\n\tbar\n)', id='subshell-expanded'),
    pytest.param('a bb\\\ncc d', 'a bbcc d', id='word-continuation-joined'),
    pytest.param('case $1 in\na) foo;;&\nb) bar;&\nc) baz;;\nesac',
                 'case $1 in\na) foo ;;&\nb) bar ;&\nc) baz ;;\nesac',
                 id='case-fallthrough'),
    pytest.param('cat <<-EOF\n\t\thello\n\t\t\tworld\n\tEOF',
                 'cat <<-EOF\n\thello\n\t\tworld\nEOF', id='heredoc-dash-dedent'),
    pytest.param('cat <<-EOF\n\tA\nB\n\tEOF',
                 'cat <<-EOF\n\tA\n\tB\nEOF', id='heredoc-dash-clamp'),
    pytest.param('cat <<-EOF\n  hello\n\tEOF',
                 'cat <<-EOF\n\t  hello\nEOF', id='heredoc-dash-spaces'),
    pytest.param("echo $'a\\tb'", "echo $'a\\tb'", id='ansi-c-escape-kept'),
    pytest.param("echo $'a\tb'", "echo $'a\tb'", id='ansi-c-raw-tab-kept'),
    pytest.param('diff <(ls) >(sort)', 'diff <(ls) >(sort)',
                 id='process-substitution'),
    pytest.param('echo `ls`', 'echo $(ls)', id='backticks-converted'),
    pytest.param('echo $[1+2]', 'echo $((1 + 2))', id='legacy-arithmetic'),
    pytest.param('﻿foo', '﻿foo', id='bom-preserved'),
    pytest.param('echo "foo"\necho \'foo\'\necho a"b"c\necho "a\'b"\necho \'a"b\'',
                 'echo "foo"\necho \'foo\'\necho a"b"c\necho "a\'b"\necho \'a"b\'',
                 id='quoting-preserved'),
]

CANONICAL_SCRIPT = """#!/bin/bash

# separate comment

! foo bar >a &

foo() { bar; }

{
\tvar1="some long value" # var1 comment
\tvar2=short             # var2 comment
}

if foo; then bar; fi

for foo in a b c; do
\tbar
done

case $foo in
a) A ;;
b)
\tB
\t;;
esac

foo | bar
foo &&
\t$(bar) &&
\t(more)
"""


@pytest.mark.parametrize("source,want", PRINT_CASES)
def test_print_canonical_form(run, source, want):
    """The printer renders each input into its recorded canonical form."""
    result = run([], stdin=source)
    # CATCHES: byte-exact canonical output including tab indentation, the
    # trailing newline, and no diagnostics on stderr.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")


@pytest.mark.parametrize("source,want", PRINT_CASES)
def test_print_ignores_surrounding_blank_lines(run, source, want):
    """Blank lines around the program do not change the output."""
    result = run([], stdin="\n" + source + "\n")
    # CATCHES: leading and trailing newlines are consumed by the parser,
    # so the canonical output is identical to the bare input's.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")


@pytest.mark.parametrize("source,want", PRINT_CASES)
def test_print_is_idempotent(run, source, want):
    """Re-printing an already formatted program is a fixed point."""
    result = run([], stdin=want)
    # CATCHES: the canonical form is stable — feeding the golden output
    # back in produces the very same bytes.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")


def test_canonical_reference_script_round_trips(run):
    """The repository's canonical.sh is already in canonical form."""
    result = run([], stdin=CANONICAL_SCRIPT)
    # CATCHES: a script covering functions, comments, if/for/case and
    # binary pipelines prints back byte-identically (idempotency over a
    # realistic program, not just table snippets).
    assert (result.returncode, result.out, result.err) == (0, CANONICAL_SCRIPT, "")
