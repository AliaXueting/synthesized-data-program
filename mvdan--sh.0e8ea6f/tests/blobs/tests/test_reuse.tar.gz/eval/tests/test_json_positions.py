"""Position decoding in the typed-JSON input format.

Positions round-trip as objects holding exactly Offset, Line and Col,
and the decoder validates that shape field by field. Each test replaces
one position inside real --to-json output with a malformed value and
records the decoder's refusal. All expectations were recorded from the
reference binary.
"""

import json

import pytest

# Values swapped in for the literal `out`'s ValuePos position.
BAD_POSITIONS = [
    pytest.param("x", "cannot decode JSON string into a position\n", id="string"),
    pytest.param(5, "cannot decode JSON number into a position\n", id="number"),
    pytest.param(None, "cannot decode JSON null into a position\n", id="null"),
    pytest.param(True, "cannot decode JSON boolean into a position\n",
                 id="boolean"),
    pytest.param([], "cannot decode JSON array into a position\n", id="array"),
    pytest.param({"Offset": 0, "Line": 1},
                 "a position must contain exactly the fields [Offset Line Col]\n",
                 id="missing-col"),
    pytest.param({"Offset": 0, "Line": 1, "Col": 1, "Foo": 2},
                 "a position must contain exactly the fields [Offset Line Col]\n",
                 id="extra-field"),
    pytest.param({"Offset": 0, "Line": 1, "Foo": 2},
                 'a position must contain the field "Col"\n', id="renamed-col"),
    pytest.param({"Offset": "0", "Line": 1, "Col": 1},
                 'cannot decode JSON string into the position field "Offset"\n',
                 id="offset-string"),
    pytest.param({"Offset": None, "Line": 1, "Col": 1},
                 'cannot decode JSON null into the position field "Offset"\n',
                 id="offset-null"),
    pytest.param({"Offset": True, "Line": 1, "Col": 1},
                 'cannot decode JSON boolean into the position field "Offset"\n',
                 id="offset-boolean"),
    pytest.param({"Offset": -1, "Line": 1, "Col": 1},
                 'the position field "Offset" is out of range: -1\n',
                 id="negative"),
    pytest.param({"Offset": 1.5, "Line": 1, "Col": 1},
                 'the position field "Offset" is out of range: 1.5\n',
                 id="fractional"),
    pytest.param({"Offset": 4294967296, "Line": 1, "Col": 1},
                 'the position field "Offset" is out of range: 4.294967296e+09\n',
                 id="above-uint32"),
]


def _mutated_position(run, value):
    """Encode `cmd >out`, replace the literal's ValuePos with value."""
    encoded = run(["-ln=bash", "--to-json"], stdin="cmd >out\n")
    assert (encoded.returncode, encoded.err) == (0, "")
    tree = json.loads(encoded.stdout)
    tree["Stmts"][0]["Redirs"][0]["Word"]["Parts"][0]["ValuePos"] = value
    return run(["--from-json"], stdin=json.dumps(tree))


@pytest.mark.parametrize("value,err", BAD_POSITIONS)
def test_malformed_positions_are_refused(run, value, err):
    """A position that is not three uint32 numbers fails to decode."""
    result = _mutated_position(run, value)
    # CATCHES: every wrong JSON shape gets its own message naming the
    # JSON type, the missing/extra field, or the out-of-range number.
    assert (result.returncode, result.out, result.err) == (1, "", err)


def test_position_at_uint32_max_is_accepted(run):
    """2**32-1 is the largest offset a position may hold."""
    result = _mutated_position(
        run, {"Offset": 4294967295, "Line": 1, "Col": 1})
    # CATCHES: the bound is inclusive, so the largest uint32 decodes and
    # the program still prints normally afterwards.
    assert (result.returncode, result.out, result.err) == (0, "cmd >out\n", "")
