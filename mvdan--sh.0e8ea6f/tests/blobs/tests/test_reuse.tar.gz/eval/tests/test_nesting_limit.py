"""The parser's maximum nesting depth, ported from TestParseNestingLimit.

The native suite asserts that 1000 levels parse and that maxNesting+1 fails
with "nesting is deeper than 10000 levels"; here every shape is driven
through stdin and the exact position prefix of the diagnostic is recorded,
including the cases where the column is reported as a literal '?'.
"""

import pytest

MAX_NESTING = 10000

# (builder, expected stderr) recorded from the reference binary at
# maxNesting+1 levels. The position part of the message differs per shape.
DEEP_SHAPES = [
    pytest.param(
        lambda n: "(\n" * n + ":" + ")\n" * n,
        "<standard input>:10001:1: nesting is deeper than 10000 levels\n",
        id="subshell"),
    pytest.param(
        lambda n: "$(" * n + ":" + ")" * n,
        "<standard input>:1:10001: nesting is deeper than 10000 levels\n",
        id="command-substitution"),
    pytest.param(
        lambda n: "${a:-" * n + "x" + "}" * n,
        "<standard input>:1:?: nesting is deeper than 10000 levels\n",
        id="parameter-expansion"),
    pytest.param(
        lambda n: ":&&\n" * n + ":",
        "<standard input>:10000:1: nesting is deeper than 10000 levels\n",
        id="and-chain"),
    pytest.param(
        lambda n: ":|\n" * n + ":",
        "<standard input>:10000:2: nesting is deeper than 10000 levels\n",
        id="pipeline"),
    pytest.param(
        lambda n: "f() " * n + "{ :; }",
        "<standard input>:1:?: nesting is deeper than 10000 levels\n",
        id="function-body"),
    pytest.param(
        lambda n: "if :; then :\nel" * n + "if :; then :\n" + "fi",
        "<standard input>:10000:6: nesting is deeper than 10000 levels\n",
        id="elif-chain"),
    pytest.param(
        lambda n: "((" + "(" * n + "1" + ")" * n + "))",
        "<standard input>:1:10002: nesting is deeper than 10000 levels\n",
        id="arithmetic-parens"),
    pytest.param(
        lambda n: "[[ " + "! " * n + "x" + " ]]",
        "<standard input>:1:?: nesting is deeper than 10000 levels\n",
        id="test-negation"),
]


@pytest.mark.parametrize("build,expected_err", DEEP_SHAPES)
def test_one_level_past_the_limit_fails(run, build, expected_err):
    """Nesting one level past the limit is rejected with a position."""
    result = run([], stdin=build(MAX_NESTING + 1))
    # CATCHES: the depth limit is exactly 10000 and the diagnostic names
    # the offending line and column, which for some shapes is a literal
    # '?' rather than a number.
    assert (result.returncode, result.out, result.err) == (1, "", expected_err)


@pytest.mark.parametrize("build,want_out", [
    pytest.param(lambda n: "$(" * n + ":" + ")" * n,
                 "$(" * 1000 + ":" + ")" * 1000 + "\n", id="command-substitution"),
    pytest.param(lambda n: "${a:-" * n + "x" + "}" * n,
                 "${a:-" * 1000 + "x" + "}" * 1000 + "\n", id="parameter-expansion"),
])
def test_deep_but_legal_nesting_round_trips(run, build, want_out):
    """A thousand levels of nesting print back byte-identically."""
    result = run([], stdin=build(1000))
    # CATCHES: the limit only rejects the very deep programs; 1000 nested
    # command substitutions or parameter expansions still round-trip with
    # status 0 and no reformatting at all.
    assert (result.returncode, result.out, result.err) == (0, want_out, "")


def test_deep_subshells_reformat_with_a_tab_per_level(run):
    """A thousand nested subshells are re-indented, growing the program."""
    result = run([], stdin="(\n" * 1000 + ":" + ")\n" * 1000)
    # CATCHES: the printer puts every nested subshell on its own line with
    # one tab of indentation per level, so the 2002-byte input grows to
    # exactly 1004002 bytes made of 2001 lines.
    assert (result.returncode, result.err) == (0, "")
    assert len(result.stdout) == 1004002
    assert result.stdout.count(b"\n") == 2001
    assert result.stdout.count(b"(") == 1000
    assert result.stdout.count(b")") == 1000


def test_the_boundary_itself_is_reported_for_a_file(run, write):
    """Exactly 10000 open subshells already fail, using the file's path."""
    write("deeper.sh", "(\n" * 10000 + ":" + ")\n" * 10000)
    result = run(["-l", "deeper.sh"])
    # CATCHES: the boundary sits at 10000 open constructs (not 10001) for
    # the statement inside them, and a file argument labels the diagnostic
    # with its path instead of '<standard input>'.
    assert (result.returncode, result.out, result.err) == (
        1, "", "deeper.sh:10001:1: nesting is deeper than 10000 levels\n")


def test_one_below_the_boundary_is_accepted(run, write):
    """9999 open subshells are formatted and only reported as differing."""
    write("deep.sh", "(\n" * 9999 + ":" + ")\n" * 9999)
    result = run(["-l", "deep.sh"], timeout=30)
    # CATCHES: one level below the boundary the program still formats, so
    # -l only reports the (huge) reformatting difference and exits 1 with
    # no parse diagnostic at all.
    assert (result.returncode, result.out, result.err) == (1, "deep.sh\n", "")
    # CATCHES: the indented reprint keeps every level, so it is far larger
    # than the flat input rather than merely echoing it back.
    formatted = run([], stdin="(\n" * 9999 + ":" + ")\n" * 9999, timeout=30)
    assert (formatted.returncode, formatted.err) == (0, "")
    assert len(formatted.stdout) == 100019999


def test_to_json_reports_the_limit_without_a_path(run):
    """--to-json of an over-deep program labels the error with no name."""
    result = run(["--to-json"], stdin="(\n" * 10000 + ":" + ")\n" * 10000)
    # CATCHES: in --to-json mode the parse error carries no '<standard
    # input>' label, matching the empty name used for stdin there.
    assert (result.returncode, result.out, result.err) == (
        1, "", "10001:1: nesting is deeper than 10000 levels\n")
