"""Shell dialect selection and automatic detection behaviour.

Ported from the dialect-related cases of the native flags.txtar and
walk.txtar CLI test scripts plus the fileutil shebang-detection unit
tests; all outputs were recorded from the reference binary.
"""

import pytest

LET = "let a+"
COPROCESS = "coprocess |&\n"


def test_let_clause_is_posix_only(run):
    """'let' parses under posix dialects but not under bash or mksh."""
    outcomes = {
        (): (1, "<standard input>:1:6: `+` must be followed by an expression\n"),
        ("-ln=posix",): (0, "let a+\n"),
        ("-p",): (0, "let a+\n"),
        ("-ln=mksh",): (1, "<standard input>:1:6: `+` must be followed by an expression\n"),
        ("-ln=bash",): (1, "<standard input>:1:6: `+` must be followed by an expression\n"),
    }
    for flags, (rc, want) in outcomes.items():
        result = run(list(flags), stdin=LET)
        # CATCHES: the default stdin dialect is bash, so 'let' errors,
        # while -ln=posix and its -p shorthand accept it verbatim.
        expected_out = want if rc == 0 else ""
        expected_err = "" if rc == 0 else want
        assert (result.returncode, result.out, result.err) == (
            rc, expected_out, expected_err)


def test_coprocess_requires_mksh(run):
    """The mksh coprocess operator only parses under -ln=mksh."""
    bad = run([], stdin=COPROCESS)
    # CATCHES: under the default bash dialect '|&' is a parse error naming
    # the operator, while -ln=mksh formats the line unchanged.
    assert (bad.returncode, bad.out) == (1, "")
    assert bad.err == "<standard input>:1:11: `|&` must be followed by a statement\n"
    good = run(["-ln=mksh"], stdin=COPROCESS)
    assert (good.returncode, good.out, good.err) == (0, COPROCESS, "")


def test_auto_dialect_uses_the_stdin_filename(run):
    """-ln=auto picks the dialect from the -filename extension."""
    for flags in (["-filename=input.mksh"], ["-ln=auto", "-filename=input.mksh"]):
        result = run(flags, stdin=COPROCESS)
        # CATCHES: the .mksh extension of the synthetic filename selects
        # the mksh dialect, and an explicit -ln=auto keeps that behaviour.
        assert (result.returncode, result.out, result.err) == (0, COPROCESS, "")


def test_auto_dialect_uses_the_stdin_shebang(run):
    """A shebang on stdin selects the dialect even without -filename."""
    result = run([], stdin="#!/bin/mksh\ncoprocess |&\n")
    # CATCHES: detection reads the first line of stdin, so the mksh
    # shebang enables '|&' and the shebang line is kept in the output.
    assert (result.returncode, result.out, result.err) == (
        0, "#!/bin/mksh\ncoprocess |&\n", "")


def test_shebang_wins_over_the_sh_extension(run):
    """A shebang overrides the .sh extension during auto detection."""
    result = run(["-filename=input.sh"], stdin="#!/bin/mksh\ncoprocess |&\n")
    # CATCHES: when both cues exist the shebang takes precedence, so the
    # program is parsed as mksh rather than posix/bash.
    assert (result.returncode, result.out, result.err) == (
        0, "#!/bin/mksh\ncoprocess |&\n", "")


def test_explicit_file_needs_no_extension_or_shebang(run, write):
    """An explicit path is formatted even without extension or shebang."""
    write("input-tiny", "foo")
    result = run(["input-tiny"])
    # CATCHES: extension/shebang detection is skipped for explicit files,
    # and the missing trailing newline is added by the printer.
    assert (result.returncode, result.out, result.err) == (0, "foo\n", "")


@pytest.mark.parametrize("name", ["zprofile", ".zshrc"])
def test_known_shell_filenames_select_zsh(run, name):
    """Certain well-known filenames are treated like a zsh extension."""
    result = run(["-filename=" + name], stdin="${} =(bar)\n")
    # CATCHES: names such as zprofile or .zshrc are recognised by more
    # than their extension, enabling zsh-only syntax like '=(bar)'.
    assert (result.returncode, result.out, result.err) == (0, "${} =(bar)\n", "")


def test_auto_failure_names_the_dialect_it_tried(run):
    """A bash feature rejected via -ln=auto reports how it was parsed."""
    result = run(["-filename=input.sh"], stdin="#!/bin/sh\nfoo=(bar)\n")
    # CATCHES: the error names the file, position, the feature, the
    # dialect actually used and the reason ('parsed as posix via -ln=auto').
    assert (result.returncode, result.out, result.err) == (
        1,
        "",
        "input.sh:2:5: arrays are a bash/mksh/zsh feature; "
        "tried parsing as posix (parsed as posix via -ln=auto)\n",
    )


def test_auto_failure_covers_extended_globs(run):
    """Extended globs under a posix shebang produce the auto-dialect error."""
    result = run(["-filename=input.sh"], stdin="#!/bin/sh\necho !(a)\n")
    # CATCHES: like arrays, extglobs name the feature and the auto fallback
    # in one diagnostic line.
    assert (result.returncode, result.out, result.err) == (
        1,
        "",
        "input.sh:2:6: extended globs are a bash/mksh feature; "
        "tried parsing as posix (parsed as posix via -ln=auto)\n",
    )


@pytest.mark.parametrize("content,shebang", [
    (" foo\n", "#!/bin/sh\n"),
    (" foo=(bar)\n", "#!/bin/bash\n"),
    (" foo=(bar)\n", "#!/usr/bin/env bash\n"),
    (" foo\n", "#!/bin/dash\n"),
    (" foo\n", "#!/usr/bin/sh\n"),
    (" foo\n", "#!/bin/env sh\n"),
    (" foo |&\n", "#!/bin/mksh\n"),
    (" ${+foo}\n", "#!/bin/zsh\n"),
    (' @test "foo" { bar; }\n', "#!/usr/bin/env bats\n"),
    (" foo\n", "#! /bin/sh\n"),
    (" foo\n", "#!\t/bin/env\tsh\n"),
    (" foo\n", "#!/bin/bash -e -x\n"),
])
def test_shebang_lines_select_the_dialect(run, write, content, shebang):
    """A variety of shebang spellings map onto the right dialect."""
    write("script.sh", shebang + content)
    result = run(["script.sh"])
    # CATCHES: spaces, tabs, /usr/bin and /usr/bin/env prefixes, extra
    # interpreter arguments and less common shells all still detect.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == shebang + content.lstrip(" ")


def test_language_flag_beats_extension_and_shebang(run, write):
    """An explicit -ln overrides both the extension and the shebang."""
    write("ext.mksh", "coprocess |&\n")
    by_ext = run(["-ln=bash", "ext.mksh"])
    # CATCHES: the explicit dialect wins over the .mksh extension, so the
    # coprocess operator is rejected with the position of the operator.
    assert (by_ext.returncode, by_ext.out) == (1, "")
    assert by_ext.err == "ext.mksh:1:11: `|&` must be followed by a statement\n"
    write("shebang.sh", "#!/bin/mksh\ncoprocess |&\n")
    by_shebang = run(["-ln=bash", "shebang.sh"])
    assert (by_shebang.returncode, by_shebang.out) == (1, "")
    assert by_shebang.err == "shebang.sh:2:11: `|&` must be followed by a statement\n"


def test_stdin_errors_are_labelled_standard_input(run):
    """Parse errors on stdin use the '<standard input>' label."""
    result = run([], stdin="foo(\n")
    # CATCHES: unlike file arguments, stdin diagnostics are prefixed with
    # the placeholder name so the message shape matches file errors.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:1: `foo(` must be followed by `)`\n")
