"""Flag handling, usage/version output and argument validation errors.

Ported from the native flags.txtar CLI test script of the reference
repository; every message below was recorded from the reference binary.
"""

import textwrap

import pytest

USAGE = textwrap.dedent("""\
    usage: shfmt [flags] [path ...]

    shfmt formats shell programs. If the only argument is a dash ('-') or no
    arguments are given, standard input will be used, unless it is a terminal.
    If a given path is a directory, all shell scripts found under that directory
    will be used.

      --version  show version and exit

      -l[=0], --list[=0]  error with a list of files whose formatting differs from shfmt;
                          paths are separated by a newline or a null character if -l=0
      -w,     --write     write result to file instead of stdout
      -d,     --diff      error with a diff when the formatting differs
      --apply-ignore      always apply EditorConfig ignore rules
      --detect str        how to detect shell files when walking: default, exec, or all
      --filename str      provide a name for the standard input file

    Parser options:

      -ln, --language-dialect str  bash/posix/mksh/bats/zsh, default "auto"
      -p,  --posix                 shorthand for -ln=posix
      -s,  --simplify              simplify the code

    Printer options:

      -i,  --indent uint       0 for tabs (default), >0 for number of spaces
      -bn, --binary-next-line  binary ops like && and | may start a line
      -ci, --case-indent       switch cases will be indented
      -sr, --space-redirects   redirect operators will be followed by a space
      -kp, --keep-padding      keep column alignment paddings
      -fn, --func-next-line    function opening braces are placed on a separate line (deprecated; use -bl)
      -bl, --block-next-line   multi-line block opening tokens like '{', 'then', and 'do' are placed on a separate line
      -mn, --minify             minify the code to reduce its size (implies -s)

    Utilities:

      -f[=0], --find[=0]  recursively find all shell files and print the paths;
                          paths are separated by a newline or a null character if -f=0
      --to-json           print syntax tree to stdout as a typed JSON
      --from-json         read syntax tree from stdin as a typed JSON

    Formatting options can also be read from EditorConfig files; see 'man shfmt'
    for a detailed description of the tool's behavior.
    For more information and to report bugs, see https://github.com/mvdan/sh.
    """)


def test_short_help_flag_writes_usage_to_stderr(run):
    """-h prints the full usage text on stderr and exits successfully."""
    result = run(["-h"])
    # CATCHES: help output goes to stderr (stdout stays empty) and the
    # exit status is 0, not the usual error status.
    assert (result.returncode, result.stdout, result.stderr) == (0, b"", USAGE.encode())


@pytest.mark.parametrize("flag", ["-h", "--help"])
def test_help_flags_share_one_usage_text(run, flag):
    """The short and long help flags print byte-identical usage output."""
    result = run([flag])
    # CATCHES: both spellings render the exact same usage, including the
    # flag summary tables and the trailing bug-report lines.
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == USAGE.encode()


def test_version_flags_print_recorded_version(run):
    """-version and --version print the same version string on stdout."""
    recorded = b"v3.0.0-20261012132700-0e8ea6fccd96\n"
    for flag in ["-version", "--version"]:
        result = run([flag])
        # CATCHES: version information belongs on stdout with a newline,
        # exits 0, and never duplicates anything onto stderr.
        assert (result.returncode, result.stdout, result.stderr) == (0, recorded, b"")


def test_posix_flag_cannot_coexist_with_language(run):
    """-p and -ln=lang are mutually exclusive."""
    for args in (["-ln=bash", "-p"], ["--language-dialect=bash", "--posix"],
                 ["-ln=posix", "-p"]):
        result = run(args)
        # CATCHES: the coexistence check runs before any parsing and fails
        # with status 1 and this exact one-line diagnostic.
        assert (result.returncode, result.out, result.err) == (
            1, "", "-p and -ln=lang cannot coexist\n")


def test_func_next_line_cannot_coexist_with_block_next_line(run):
    """-fn and -bl are mutually exclusive."""
    for args in (["-fn", "-bl"], ["--func-next-line", "--block-next-line"]):
        result = run(args)
        # CATCHES: the deprecated -fn flag conflicts with -bl and the
        # error mentions its deprecation explicitly.
        assert (result.returncode, result.out, result.err) == (
            1, "", "-fn and -bl cannot coexist; note that -fn is deprecated\n")


def test_unknown_dialect_is_rejected_with_usage(run):
    """An invalid -ln value fails with status 2 plus the usage text."""
    result = run(["-ln=bad"])
    # CATCHES: flag parsing failures exit with status 2 (unlike runtime
    # errors which use 1) and repeat the full usage on stderr.
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err.startswith(
        'invalid value "bad" for flag -ln: unknown shell language variant: "bad"\n')
    assert result.err.endswith(USAGE)


def test_unknown_flag_is_rejected_with_usage(run):
    """An undefined flag fails with status 2 and the flag error line."""
    result = run(["-zzz"])
    # CATCHES: the Go flag package diagnostic names the bad flag and the
    # usage text follows it on stderr.
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err.startswith("flag provided but not defined: -zzz\n")
    assert result.err.endswith(USAGE)


def test_non_numeric_indent_is_rejected(run):
    """-i requires a number; anything else is a flag parse error."""
    result = run(["-i", "abc"])
    # CATCHES: the uint flag rejects text values with a "parse error"
    # suffix and exit status 2 before any formatting happens.
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err.startswith('invalid value "abc" for flag -i: parse error\n')
    assert result.err.endswith(USAGE)


def test_to_json_rejects_file_arguments(run, write):
    """--to-json may only be used when reading from stdin."""
    write("file.sh", "foo\n")
    result = run(["--to-json", "file.sh"])
    # CATCHES: the JSON printer is stdin-only, so passing a path is a
    # hard error with status 1 rather than silently ignoring the flag.
    assert (result.returncode, result.out, result.err) == (
        1, "", "--to-json can only be used with stdin\n")


def test_from_json_rejects_path_arguments(run):
    """--from-json may only be used when reading from stdin."""
    result = run(["--from-json", "."])
    # CATCHES: even a directory argument is refused before any walking
    # happens, because JSON decoding needs the whole of stdin.
    assert (result.returncode, result.out, result.err) == (
        1, "", "--from-json can only be used with stdin\n")


def test_filename_rejects_file_arguments(run, write):
    """-filename only labels stdin and cannot accompany real paths."""
    write("file.sh", "foo\n")
    result = run(["-filename=foo", "file.sh"])
    # CATCHES: -filename is meaningless alongside real path arguments and
    # is rejected with status 1 up front.
    assert (result.returncode, result.out, result.err) == (
        1, "", "-filename can only be used with stdin\n")


def test_detect_rejects_unknown_modes(run):
    """--detect only accepts default, exec and all."""
    result = run(["--detect=bad"])
    # CATCHES: the mode name is validated before any directory walking,
    # producing this exact message and exit status 1.
    assert (result.returncode, result.out, result.err) == (
        1, "", "--detect only allows default, exec, or all\n")


def test_version_wins_over_write_and_paths(run, write, tmp_path):
    """--version is handled first, ignoring -w and path arguments."""
    write("input.sh", " foo\n")
    result = run(["--version", "-w", "input.sh"])
    # CATCHES: the version branch returns before any argument processing,
    # so the version string is printed, the status is 0, and -w never
    # touches the file, whose bytes stay exactly as written.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"v3.0.0-20261012132700-0e8ea6fccd96\n", b"")
    assert (tmp_path / "input.sh").read_text() == " foo\n"


# --- the -l and -f value grammar (boolStringValue) ----------------------

@pytest.mark.parametrize("flag", ["-l", "-f"])
def test_list_and_find_only_allow_empty_zero_and_true(run, flag):
    """-l and -f reject any value other than nothing, 0 and true."""
    for value in ("1", "true2", "", "yes", "false=1"):
        result = run(["%s=%s" % (flag, value)])
        # CATCHES: only the three spellings '-l', '-l=0' and '-l=true'
        # are legal, and the diagnostic names the flag and its allowed
        # forms rather than printing the usage text.
        assert (result.returncode, result.out, result.err) == (
            1, "", "only %s and %s=0 allowed\n" % (flag, flag))


@pytest.mark.parametrize("spelling", [["-l=true"], ["--list=true"]])
def test_list_true_behaves_like_the_bare_flag(run, write, spelling):
    """-l=true is the explicit spelling of plain -l."""
    write("input.sh", " foo\n")
    result = run([*spelling, "input.sh"])
    # CATCHES: the differing file is listed on stdout and the status is 1,
    # exactly like the bare -l flag.
    assert (result.returncode, result.out, result.err) == (1, "input.sh\n", "")


@pytest.mark.parametrize("spelling", [["-l=false"], ["--list=false"]])
def test_list_false_behaves_like_no_flag_at_all(run, write, spelling):
    """-l=false turns listing off again."""
    write("input.sh", " foo\n")
    result = run([*spelling, "input.sh"])
    # CATCHES: with listing disabled the formatted program itself is
    # printed and the run succeeds, like running with no flags.
    assert (result.returncode, result.out, result.err) == (0, "foo\n", "")


def test_find_true_and_false_toggle_the_finder(run, write):
    """-f=true finds files while -f=false formats them instead."""
    write("sub/input.sh", " foo\n")
    found = run(["-f=true", "sub"])
    # CATCHES: -f=true lists the shell file found under the directory...
    assert (found.returncode, found.out, found.err) == (
        0, "sub/input.sh\n", "")
    formatted = run(["-f=false", "sub"])
    # CATCHES: ...while -f=false formats it, proving both spellings of
    # the value really switch the mode on and off.
    assert (formatted.returncode, formatted.out, formatted.err) == (
        0, "foo\n", "")


def test_long_list_and_find_accept_the_zero_separator(run, write):
    """--list=0 and --find=0 match the short -l=0 and -f=0 spellings."""
    write("input.sh", " foo\n")
    listed = run(["--list=0", "input.sh"])
    # CATCHES: the long spelling of the null-separated listing prints the
    # differing path followed by a NUL byte and exits 1.
    assert (listed.returncode, listed.stdout, listed.err) == (
        1, b"input.sh\x00", "")
    found = run(["--find=0", "input.sh"])
    assert (found.returncode, found.stdout, found.err) == (
        0, b"input.sh\x00", "")
