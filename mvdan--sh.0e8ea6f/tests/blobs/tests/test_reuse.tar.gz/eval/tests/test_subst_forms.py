"""Command-substitution spelling and spacing, recorded from the reference.

Backquotes round-trip in simple cases but are promoted to $( ) whenever
they contain another backquote — including inside double quotes and inside
a `let` assignment. Without -s the space in `$( (ls) )` is preserved, while
the zsh/bash brace forms drop only the space before the semicolon.
"""

import pytest

SUBST_FORMS = [
    pytest.param("echo `# hi`", "echo `# hi`",
                 id="backquote-comment-kept"),
    pytest.param("echo $( (ls) )", "echo $( (ls) )",
                 id="space-inside-parens-kept"),
    pytest.param("echo `x \\`y\\` z`", "echo $(x $(y) z)",
                 id="nested-backquotes-promoted"),
    pytest.param("echo `x \"\\`y\\`\"`", "echo $(x \"$(y)\")",
                 id="backquote-in-quotes-promoted"),
    pytest.param("let x=`echo 1`", "let x=$(echo 1)",
                 id="backquote-in-let-promoted"),
]


@pytest.mark.parametrize("source,want", SUBST_FORMS)
def test_substitution_form(run, source, want):
    """Each substitution spelling prints exactly as recorded, un-simplified."""
    result = run(["-ln=bash"], stdin=source)
    # CATCHES: nested backquotes are rewritten to $( ) everywhere — even
    # inside double quotes and let assignments — while a lone backquote
    # containing only a comment is preserved, and without -s the space
    # in `$( (ls) )` is not collapsed.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, (want + "\n").encode(), b"")


@pytest.mark.parametrize(
    "source,want",
    [
        pytest.param("echo ${| a; }", "echo ${|a;}", id="replyvar-space-dropped"),
        pytest.param("echo ${ a; }", "echo ${ a;}", id="brace-keeps-inner-space"),
    ])
def test_brace_command_semicolon_spacing(run, source, want):
    """-s tightens only the space before `;` in ${|..;} and ${ ..;}."""
    result = run(["-s", "-ln=bash"], stdin=source)
    # CATCHES: the space after `${` survives while the one before `;`
    # disappears, and the replyvar form loses the space after the bar
    # too — two different tightening rules, both pinned.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, (want + "\n").encode(), b"")
