"""zsh-only constructs and their dialect gates.

Each construct is printed in zsh (its canonical form) and refused in
bash where the parser emits a gate error. All expectations were
recorded by running the reference binary.
"""

import pytest

ZSH_FLAGS = [
    pytest.param("echo ${(j.:.)a}\n", "echo ${(j.:.)a}\n", id="join-sep"),
    pytest.param("echo ${(q)a}\n", "echo ${(q)a}\n", id="quote-flag"),
    pytest.param("echo ${(ps.-.)a}\n", "echo ${(ps.-.)a}\n", id="split-sep"),
    pytest.param("echo ${(U)a}\n", "echo ${(U)a}\n", id="upper"),
    pytest.param("echo ${(j.:.)a:mod}\n", "echo ${(j.:.)a:mod}\n", id="flags-then-word"),
    pytest.param("echo ${(q)a:u}\n", "echo ${(q)a:u}\n", id="flag-then-colon-word"),
]


@pytest.mark.parametrize("source,want", ZSH_FLAGS)
def test_zsh_expansion_flags(run, source, want):
    """zsh `${(flags)param}` forms print unchanged."""
    result = run(["-ln=zsh", "-"], stdin=source)
    # CATCHES: the flag literal between `(` and `)` is kept verbatim,
    # including separators like `j.:.` and any trailing `:word`.
    assert (result.returncode, result.out, result.err) == (0, want, "")


def test_zsh_expansion_flags_are_gated_in_bash(run):
    """bash rejects `${(flags)...}` with a dedicated gate."""
    for source in ("echo ${(q)a}\n", "echo ${(j.:.)a}\n", "echo ${(ps.-.)a}\n"):
        result = run(["-ln=bash", "-"], stdin=source)
        # CATCHES: the gate names `parameter expansion flags` (not a
        # generic expansion error) and points at the `(`.
        assert (result.returncode, result.out, result.err) == (
            1, "",
            "<standard input>:1:6: parameter expansion flags are a zsh "
            "feature; tried parsing as bash\n")


ZSH_PREFIXES = [
    pytest.param("${=a}", id="split"),
    pytest.param("${~a}", id="glob"),
    pytest.param("${^a}", id="rc"),
    pytest.param("${==a}", id="split-off"),
    pytest.param("${~~a}", id="glob-off"),
    pytest.param("${^^a}", id="rc-off"),
    pytest.param("${=^a}", id="split-rc"),
    pytest.param("${=a:-b}", id="split-with-default"),
]


@pytest.mark.parametrize("form", ZSH_PREFIXES)
def test_zsh_parameter_prefixes(run, form):
    """zsh's `=`, `~`, `^` prefixes (single or doubled) print verbatim."""
    result = run(["-ln=zsh", "-"], stdin="echo %s\n" % form)
    # CATCHES: doubling a prefix forces the option off but prints the
    # same doubled spelling; combinations keep their order.
    assert (result.returncode, result.out, result.err) == (
        0, "echo %s\n" % form, "")


@pytest.mark.parametrize("form", ZSH_PREFIXES)
def test_zsh_parameter_prefixes_fail_in_bash(run, form):
    """bash sees the prefixes as part of an invalid parameter name."""
    result = run(["-ln=bash", "-"], stdin="echo %s\n" % form)
    # CATCHES: bash does not gate these as a zsh feature; it reports an
    # invalid parameter name at the closing brace.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:8: invalid parameter name\n")


@pytest.mark.parametrize("dialect,want,err", [
    pytest.param("zsh", "() { echo hi; }\n", None, id="zsh-anon"),
    pytest.param("bash", None,
                 "anonymous functions are a zsh feature; tried parsing as bash\n",
                 id="bash-gate"),
])
def test_anonymous_functions(run, dialect, want, err):
    """`() { ...; }` declares an anonymous function only in zsh."""
    result = run(["-ln=%s" % dialect, "-"], stdin="() { echo hi; }\n")
    # CATCHES: zsh prints the bare-parens form verbatim while bash
    # refuses it with a gate naming the construct.
    if err is None:
        assert (result.returncode, result.out, result.err) == (0, want, "")
    else:
        assert (result.returncode, result.out, result.err) == (1, "", "<standard input>:1:1: " + err)


@pytest.mark.parametrize("dialect,want,err", [
    pytest.param("zsh", "function f g { echo; }\n", None, id="zsh-multi"),
    pytest.param("bash", None,
                 "multi-name functions are a zsh feature; tried parsing as bash\n",
                 id="bash-gate"),
])
def test_multi_name_functions(run, dialect, want, err):
    """`function f g {...}` declares two functions at once in zsh."""
    result = run(["-ln=%s" % dialect, "-"], stdin="function f g { echo; }\n")
    # CATCHES: both names stay on the single function declaration line;
    # bash has its own gate message for the multi-name form.
    if err is None:
        assert (result.returncode, result.out, result.err) == (0, want, "")
    else:
        assert (result.returncode, result.out, result.err) == (1, "", "<standard input>:1:1: " + err)


def test_coproc_with_a_name_diverges_between_dialects(run):
    """`coproc name { ...; }` is fine in bash but breaks zsh's coproc."""
    bash = run(["-ln=bash", "-"], stdin="coproc name { echo; }\n")
    assert (bash.returncode, bash.out, bash.err) == (
        0, "coproc name { echo; }\n", "")
    zsh = run(["-ln=zsh", "-"], stdin="coproc name { echo; }\n")
    # CATCHES: zsh takes `name` as the coproc's command word, so the
    # block's closing brace becomes the error position.
    assert (zsh.returncode, zsh.out, zsh.err) == (
        1, "", "<standard input>:1:21: `}` can only be used to close a block\n")


def test_let_clause_prints_expressions_verbatim(run):
    """let keeps quoting and separates multiple expressions by spaces."""
    for dialect in ("bash", "zsh"):
        result = run(["-ln=%s" % dialect, "-"], stdin='let "a = 1 + 2" b\n')
        # CATCHES: let's arguments are words like any other, so the
        # quoted arithmetic keeps its quotes through the round trip.
        assert (result.returncode, result.out, result.err) == (
            0, 'let "a = 1 + 2" b\n', "")


def test_time_and_select_round_trip_in_both_dialects(run):
    """time and select are shared constructs that print unchanged."""
    for dialect in ("bash", "zsh"):
        time = run(["-ln=%s" % dialect, "-"], stdin="time echo hi\n")
        assert (time.returncode, time.out, time.err) == (0, "time echo hi\n", "")
        select = run(["-ln=%s" % dialect, "-"],
                     stdin="select x in a b; do echo $x; done\n")
        # CATCHES: select's `; do` keeps its semicolon even though a
        # newline would also separate the parts.
        assert (select.returncode, select.out, select.err) == (
            0, "select x in a b; do echo $x; done\n", "")
