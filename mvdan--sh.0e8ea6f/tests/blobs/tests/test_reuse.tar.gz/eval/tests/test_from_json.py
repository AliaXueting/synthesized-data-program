"""--from-json behaviour: decode errors, non-File roots and round trips.

Ported from the typedjson package's own tests (TestRoundtripAnyNode and
TestRoundtripZsh) plus probes of the CLI's error paths, which the native
suite only reaches through the Go API. Every message and byte below was
recorded from the reference binary.
"""

import textwrap

import pytest

# --- decode errors ------------------------------------------------------

DECODE_ERRORS = [
    pytest.param("not json",
                 "invalid character 'o' in literal null (expecting 'u')\n",
                 id="not-json"),
    pytest.param('{"Type":"NoSuchThing"}', 'unknown type: "NoSuchThing"\n',
                 id="unknown-type"),
    pytest.param('{}',
                 'missing "Type" to decode a JSON object into syntax.Node\n',
                 id="missing-type"),
    pytest.param("[]", "cannot decode JSON array into syntax.Node\n",
                 id="array"),
    pytest.param("null", "cannot decode JSON null into a syntax node\n",
                 id="null"),
    pytest.param("123", "cannot decode JSON number into syntax.Node\n",
                 id="number"),
    pytest.param('{"Type":"File","Stmts":"nope"}',
                 "cannot decode JSON string into []*syntax.Stmt\n",
                 id="wrong-field-type"),
]


@pytest.mark.parametrize("payload,expected_err", DECODE_ERRORS)
def test_from_json_rejects_broken_payloads(run, payload, expected_err):
    """Malformed or mistyped trees are rejected with the decoder's message."""
    result = run(["--from-json"], stdin=payload)
    # CATCHES: each class of broken input has its own diagnostic, all with
    # status 1 and nothing on stdout.
    assert (result.returncode, result.out, result.err) == (1, "", expected_err)


def test_from_json_ignores_bytes_after_the_tree(run):
    """Trailing garbage after the JSON value is not an error."""
    result = run(["--from-json"], stdin='{"Type":"File"} extra')
    # CATCHES: the decoder stops after one JSON value, so the leftover
    # text is ignored and the empty File prints as a single newline.
    assert (result.returncode, result.out, result.err) == (0, "\n", "")


def test_from_json_of_an_empty_file_prints_a_newline(run):
    """A File node with no statements prints as one empty line."""
    result = run(["--from-json"], stdin='{"Type":"File"}')
    # CATCHES: even an empty program is terminated by a newline, matching
    # what formatting an empty input produces.
    assert (result.returncode, result.out, result.err) == (0, "\n", "")


def test_from_json_accepts_a_non_file_root(run):
    """Any node type may be the root, not only File."""
    lit = ('{"Type":"Lit","ValuePos":{"Offset":0,"Line":1,"Col":1},'
           '"Value":"foo"}')
    valued = run(["--from-json"], stdin=lit)
    # CATCHES: a lone Lit prints its value with no trailing newline,
    # unlike a File which always ends in one.
    assert (valued.returncode, valued.stdout, valued.err) == (0, b"foo", "")
    valueless = run(["--from-json"], stdin='{"Type":"Lit"}')
    # CATCHES: absent fields decode to their zero values rather than
    # failing, so the same node without a Value prints nothing at all —
    # still without the newline a File root would produce.
    assert (valueless.returncode, valueless.err) == (0, "")
    assert valueless.stdout == b""


# --- round trips --------------------------------------------------------

ALL_NODES = textwrap.dedent("""\
    foo=bar qux >redir <<EOF
    hdoc
    EOF
    baz=(one [two]=three)
    ! foo | bar || baz & 'sgl' "dbl" ${foo:-x} $(cmd) $((1 + -2)) $(( ($x) )) @(glob) <(proc) {a,b}
    if foo; then bar; else baz; fi
    for i in x; do foo; done
    for ((i = 0; i < 3; i++)); do foo; done
    while foo; do bar; done
    case i in foo) bar ;; esac
    { foo; }
    (foo)
    foo() { bar; }
    declare -A foo
    let x=1
    time foo
    coproc foo
    ((2))
    [[ ! (foo && -n bar) ]]
    # comment
    """)

ALL_NODES_CANONICAL = textwrap.dedent("""\
    foo=bar qux >redir <<EOF
    hdoc
    EOF
    baz=(one [two]=three)
    ! foo | bar || baz &
    'sgl' "dbl" ${foo:-x} $(cmd) $((1 + -2)) $((($x))) @(glob) <(proc) {a,b}
    if foo; then bar; else baz; fi
    for i in x; do foo; done
    for ((i = 0; i < 3; i++)); do foo; done
    while foo; do bar; done
    case i in foo) bar ;; esac
    { foo; }
    (foo)
    foo() { bar; }
    declare -A foo
    let x=1
    time foo
    coproc foo
    ((2))
    [[ ! (foo && -n bar) ]]
    # comment
    """)


def test_every_node_type_survives_a_json_round_trip(run):
    """A program using every node type round-trips through typed JSON."""
    encoded = run(["--to-json"], stdin=ALL_NODES)
    assert (encoded.returncode, encoded.err) == (0, "")
    # CATCHES: the 19-statement program serialises to exactly 71306 bytes
    # of JSON holding 120 typed nodes, so a node type that failed to
    # encode would change both numbers.
    assert len(encoded.stdout) == 71306
    assert encoded.stdout.count(b'"Type":') == 120
    decoded = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: encoding and then decoding must lose no information, so
    # the printed program is the canonical form of the original (note the
    # `$(( ($x) ))` inner parentheses collapsing to `$((($x)))`).
    assert (decoded.returncode, decoded.out, decoded.err) == (
        0, ALL_NODES_CANONICAL, "")


def test_zsh_flags_arithm_round_trips_through_json(run):
    """The zsh-only FlagsArithm node survives the JSON round trip."""
    encoded = run(["-ln=zsh", "--to-json"], stdin="echo ${a[(r)foo]}\n")
    assert (encoded.returncode, encoded.err) == (0, "")
    decoded = run(["-ln=zsh", "--from-json"], stdin=encoded.stdout)
    # CATCHES: `${a[(r)foo]}` only parses as zsh, and its typed JSON must
    # decode back into a tree that prints the very same expansion.
    assert (decoded.returncode, decoded.out, decoded.err) == (
        0, "echo ${a[(r)foo]}\n", "")


def test_bats_testdecl_round_trips_through_json(run):
    """The bats-only TestDecl node survives the JSON round trip."""
    encoded = run(["-ln=bats", "--to-json"], stdin='@test "name" {\n\tfoo\n}\n')
    assert (encoded.returncode, encoded.err) == (0, "")
    decoded = run(["-ln=bats", "--from-json"], stdin=encoded.stdout)
    # CATCHES: the @test declaration is a node type of its own, and the
    # round trip keeps both its quoting and the tab-indented body.
    assert (decoded.returncode, decoded.out, decoded.err) == (
        0, '@test "name" {\n\tfoo\n}\n', "")


def test_from_json_re_encodes_byte_identically(run):
    """Decoding and re-encoding a tree gives the very same JSON."""
    encoded = run(["-ln=bats", "--to-json"], stdin='@test "name" {\n\tfoo\n}\n')
    again = run(["--from-json", "--to-json"], stdin=encoded.stdout)
    # CATCHES: the typed encoding is stable — no fields are added, lost
    # or reordered by a decode/encode cycle, so the bytes match exactly.
    assert (again.returncode, again.err) == (0, "")
    assert again.stdout == encoded.stdout
    assert len(again.stdout) == 3684
