"""Lexer edge cases: buffer chunk boundaries and sentinel control runes.

Ported from the printTests table in syntax/printer_test.go (the bufSize
entries) and from TestParseHighControlRunes in syntax/parser_test.go. The
lexer reads input in 1 KiB chunks and uses U+0080/U+0081 as rune sentinels,
so bytes landing exactly on a chunk boundary are a behaviour worth pinning.
"""

import pytest

BUF_SIZE = 1 << 10  # syntax/parser.go: const bufSize = 1 << 10

# Every case below records the exact bytes the reference binary printed.
CHUNK_CASES = [
    pytest.param(" " * (BUF_SIZE - 3) + "○", "○",
                 id="rune-ends-a-chunk"),
    pytest.param(" " * (BUF_SIZE - 0) + "○", "○",
                 id="rune-starts-a-chunk"),
    pytest.param(" " * (BUF_SIZE - 2) + "○", "○",
                 id="rune-split-after-first-byte"),
    pytest.param(" " * (BUF_SIZE - 1) + "○", "○",
                 id="rune-split-after-second-byte"),
    pytest.param(" " * (BUF_SIZE - 2) + ">(a)", ">(a)",
                 id="peek-across-the-chunk-edge"),
    pytest.param("a" + " " * (BUF_SIZE - 2) + "\\\nb", "a \\\n\tb",
                 id="escaped-newline-at-a-chunk-edge"),
    pytest.param(" " * (BUF_SIZE - 10) + "${a/b//○}", "${a/b//○}",
                 id="utf8-max-padding-inside-an-expansion"),
]


@pytest.mark.parametrize("source,want", CHUNK_CASES)
def test_chunk_boundary_runes_round_trip(run, source, want):
    """Programs whose runes straddle the 1 KiB buffer boundary re-print."""
    result = run([], stdin=source)
    # CATCHES: the lexer must not lose or split a multi-byte rune that
    # lands on a 1024-byte chunk boundary, and the leading padding spaces
    # are still dropped by the printer.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")


# U+0080 and U+0081 double as the lexer's EOF and escaped-newline
# sentinels; the native suite checks they parse as ordinary characters.
CONTROL_RUNES = ["\u0080", "\u0081"]


@pytest.mark.parametrize("quote", ["", "'", '"'])
@pytest.mark.parametrize("rune", CONTROL_RUNES)
def test_control_runes_parse_as_characters(run, quote, rune):
    """U+0080 and U+0081 are literal characters, not lexer sentinels."""
    word = "a%sb" % rune
    source = "echo %s%s%s" % (quote, word, quote)
    result = run([], stdin=source)
    # CATCHES: the two runes the lexer internally uses as sentinels must
    # survive a round trip inside a word, single quotes or double quotes.
    assert (result.returncode, result.out, result.err) == (0, source + "\n", "")


UNICODE_LITERALS = [
    pytest.param('fo○ b\\u00e5r', id="bare-word"),
    pytest.param('"fo○ b\\u00e5r"', id="double-quoted"),
    pytest.param("'fo○ b\\u00e5r'", id="single-quoted"),
    pytest.param('${a#fo○ b\\u00e5r}', id="parameter-expansion"),
    pytest.param('#fo○ b\\u00e5r', id="comment"),
    pytest.param("<<EOF\nfo○ b\\u00e5r\nEOF", id="heredoc"),
    pytest.param("$'fo○ b\\u00e5r'", id="ansi-c-quoted"),
    pytest.param('${a/b//○}', id="expansion-replacement"),
]


@pytest.mark.parametrize("source", UNICODE_LITERALS)
def test_non_ascii_round_trips(run, source):
    """Multi-byte runes are printed back verbatim wherever they appear."""
    result = run([], stdin=source)
    # CATCHES: the printer must not re-escape or mangle non-ASCII runes in
    # words, quotes, comments, heredocs or parameter expansions.
    assert (result.returncode, result.out, result.err) == (0, source + "\n", "")
