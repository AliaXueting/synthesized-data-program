"""Parser and lexer paths reached only by rare constructs.

Numeric range globs, zsh redirect aliases, regex tests, nested
parameter expansions, brace-form loops and the reserved-word error
messages. All expectations were recorded from the reference binary.
"""

import pytest

ZSH_RANGES = [
    pytest.param("<->", id="open"),
    pytest.param("<5->", id="lower"),
    pytest.param("<-10>", id="upper"),
    pytest.param("<5-10>", id="both"),
]


@pytest.mark.parametrize("form", ZSH_RANGES)
def test_zsh_numeric_range_globs(run, form):
    """zsh numeric range globs like `<->` and `<5-10>` print verbatim."""
    result = run(["-ln=zsh", "-"], stdin="echo %s\n" % form)
    # CATCHES: the whole range including both angle brackets is a single
    # literal word, so it must not be read as a redirect.
    assert (result.returncode, result.out, result.err) == (0, "echo %s\n" % form, "")


def test_numeric_range_is_not_a_redirect_in_zsh(run):
    """Several ranges sit in one command without redirect ambiguity."""
    result = run(["-ln=zsh", "-"], stdin="echo <-> <5-> <-10> <5-10>\n")
    # CATCHES: each `<...>` form lexes as a word; a naive lexer would
    # stop at the first `<` and complain about a missing word.
    assert (result.returncode, result.out, result.err) == (
        0, "echo <-> <5-> <-10> <5-10>\n", "")


def test_numeric_range_fails_as_redirect_in_bash(run):
    """bash has no range globs, so `<->` is a redirect error."""
    result = run(["-ln=bash", "-"], stdin="echo <->\n")
    # CATCHES: bash lexes `<` as a redirect and then chokes on `->`.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:8: `>` must be followed by a word\n")


ZSH_APPEND_ALL = [
    pytest.param(">>&", "cmd &>>f\n", id="alias-becomes-append-all"),
    pytest.param(">>&|", "cmd &>>|f\n", id="alias-clobber"),
    pytest.param(">>&!", "cmd &>>|f\n", id="alias-bang-normalised"),
]


@pytest.mark.parametrize("source,want", ZSH_APPEND_ALL)
def test_zsh_append_all_aliases(run, source, want):
    """zsh's `>>&` family of aliases prints as the `&>>` spellings."""
    result = run(["-ln=zsh", "-"], stdin="cmd %s f\n" % source)
    # CATCHES: `>>&` is an alias for `&>>` and `>>&|`/`>>&!` for
    # `&>>|`, and the printer always emits the canonical spelling.
    assert (result.returncode, result.out, result.err) == (0, want, "")


def test_regex_test_with_parens_round_trips(run):
    """A parenthesised regex after =~ is kept as one word."""
    result = run(["-ln=bash", "-"], stdin="[[ a =~ (b|c) ]]\n")
    # CATCHES: the regex side keeps its parens and pipe verbatim rather
    # than being split into words or a subshell.
    assert (result.returncode, result.out, result.err) == (0, "[[ a =~ (b|c) ]]\n", "")


@pytest.mark.parametrize("dialect,want,err", [
    pytest.param("bash", "[[ a =~ b ]]\n", None, id="bash-keeps"),
    pytest.param("posix", "[[ a =~ b ]]\n", None, id="posix-keeps"),
    pytest.param("mksh", None,
                 "regex tests are a bash/zsh feature; tried parsing as mksh\n",
                 id="mksh-gates"),
])
def test_regex_test_dialects(run, dialect, want, err):
    """`=~` is kept by bash and even posix, but mksh gates it."""
    result = run(["-ln=%s" % dialect, "-"], stdin="[[ a =~ b ]]\n")
    # CATCHES: mksh is the odd one out refusing regex tests, while
    # posix (despite lacking [[ ]] extensions elsewhere) keeps it.
    if err is None:
        assert (result.returncode, result.out, result.err) == (0, want, "")
    else:
        assert (result.returncode, result.out, result.err) == (
            1, "", "<standard input>:1:6: " + err)


def test_regex_after_a_complex_expression(run):
    """`=~` may not follow a parenthesised expression."""
    result = run(["-ln=bash", "-"], stdin="[[ (a) =~ b ]]\n")
    # CATCHES: the parser only allows words on the left of =~, and the
    # error lists the three tokens that may follow instead.
    assert (result.returncode, result.out, result.err) == (
        1, "",
        "<standard input>:1:8: expected `&&`, `||` or `]]` after complex expr\n")


@pytest.mark.parametrize("source", [
    pytest.param("cmd <<'EOF'\nbody\nEOF\n", id="single-quoted"),
    pytest.param('cmd <<"EOF"\nbody\nEOF\n', id="double-quoted"),
])
def test_quoted_heredoc_delimiters(run, source):
    """Quoted heredoc delimiters keep their quotes when reprinted."""
    result = run(["-ln=bash", "-"], stdin=source)
    # CATCHES: the quoting of the delimiter changes the body's meaning
    # (no expansions), so it must survive the round trip exactly.
    assert (result.returncode, result.out, result.err) == (0, source, "")


ZSH_NESTED = [
    pytest.param("echo ${#${a}}\n", "echo ${#${a}}\n", id="length-of-param"),
    pytest.param("echo ${#$(a)}\n", "echo ${#$(a)}\n", id="length-of-cmdsubst"),
    pytest.param("echo \"${#${a}}\"\n", "echo \"${#${a}}\"\n",
                 id="length-inside-quotes"),
    pytest.param("echo ${x-${y}}\n", "echo ${x-${y}}\n", id="nested-default"),
]


@pytest.mark.parametrize("source,want", ZSH_NESTED)
def test_nested_parameter_expansions_zsh(run, source, want):
    """zsh nests expansions inside `${#...}` and defaults."""
    result = run(["-ln=zsh", "-"], stdin=source)
    # CATCHES: the inner expansion keeps its own braces/parens and the
    # outer `${#` prefix, with no extra spacing introduced.
    assert (result.returncode, result.out, result.err) == (0, want, "")


def test_nested_parameter_expansions_are_gated_in_bash(run):
    """bash refuses nested parameter expansions inside `${#...}`."""
    for source in ("echo ${#${a}}\n", "echo ${#$(a)}\n", "echo ${#${a\n"):
        result = run(["-ln=bash", "-"], stdin=source)
        # CATCHES: the gate fires at the inner `${` even when the
        # expansion is never closed.
        assert (result.returncode, result.out, result.err) == (
            1, "",
            "<standard input>:1:9: nested parameter expansions are a zsh "
            "feature; tried parsing as bash\n")


def test_nested_default_inside_double_quotes(run):
    """A nested default expansion is fine in bash when double-quoted."""
    result = run(["-ln=bash", "-"], stdin='echo "${a-${b}}"\n')
    # CATCHES: nesting inside `"..."` is accepted even though the bare
    # `${#${a}}` form is zsh-only.
    assert (result.returncode, result.out, result.err) == (
        0, 'echo "${a-${b}}"\n', "")


LONE_KEYWORDS = [
    pytest.param("}", "`}` can only be used to close a block\n", id="right-brace"),
    pytest.param("then", "`then` can only be used in an `if`\n", id="then"),
    pytest.param("fi", "`fi` can only be used to end an `if`\n", id="fi"),
    pytest.param("do", "`do` can only be used in a loop\n", id="do"),
    pytest.param("done", "`done` can only be used to end a loop\n", id="done"),
    pytest.param("esac", "`esac` can only be used to end a `case`\n", id="esac"),
]


@pytest.mark.parametrize("keyword,err", LONE_KEYWORDS)
def test_lone_keywords_have_specific_errors(run, keyword, err):
    """Each reserved word alone on a line gets its own error message."""
    result = run(["-ln=bash", "-"], stdin=keyword + "\n")
    # CATCHES: the messages say where each keyword belongs (`if`, a
    # loop, a `case`, a block) rather than a generic syntax error.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:1: " + err)


@pytest.mark.parametrize("dialect,want,err", [
    pytest.param("bash", "for i in a b; do echo; done\n", None, id="bash-expands"),
    pytest.param("mksh", "for i in a b; do echo; done\n", None, id="mksh-expands"),
    pytest.param("posix", None,
                 "for loops with braces are a bash/mksh feature; tried parsing as posix\n",
                 id="posix-gates"),
    pytest.param("zsh", None,
                 "for loops with braces are a bash/mksh feature; tried parsing as zsh\n",
                 id="zsh-gates"),
])
def test_for_loops_with_braces(run, dialect, want, err):
    """`for ...; { ...; }` normalises to do/done where it parses."""
    result = run(["-ln=%s" % dialect, "-"], stdin="for i in a b; { echo; }\n")
    # CATCHES: the brace form is accepted by bash and mksh and printed
    # as the equivalent do/done form, while posix AND zsh gate it.
    if err is None:
        assert (result.returncode, result.out, result.err) == (0, want, "")
    else:
        assert (result.returncode, result.out, result.err) == (
            1, "", "<standard input>:1:15: " + err)


def test_cstyle_for_with_braces_also_expands(run):
    """The brace form of `for ((...))` also prints as do/done."""
    result = run(["-ln=bash", "-"], stdin="for ((i = 0; i < 3; i++)); { echo; }\n")
    # CATCHES: the brace-to-do rewrite applies to c-style loops too,
    # with the arithmetic header re-spaced.
    assert (result.returncode, result.out, result.err) == (
        0, "for ((i = 0; i < 3; i++)); do echo; done\n", "")


def test_let_without_expressions(run):
    """A bare `let` is an error asking for an expression."""
    result = run(["-ln=bash", "-"], stdin="let\n")
    # CATCHES: the parser demands at least one arithmetic expression
    # after the let keyword.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:1: `let` must be followed by an expression\n")


def test_let_is_accepted_by_every_dialect(run):
    """`let a=1` parses even in posix, where let is not standard."""
    for dialect in ("bash", "mksh", "posix"):
        result = run(["-ln=%s" % dialect, "-"], stdin="let a=1\n")
        # CATCHES: the let clause is not dialect-gated at all, printing
        # the tight arithmetic form everywhere.
        assert (result.returncode, result.out, result.err) == (0, "let a=1\n", "")


@pytest.mark.parametrize("source,want", [
    pytest.param("function f { echo; }\n", "function f { echo; }\n",
                 id="keyword-form"),
    pytest.param("function f() { echo; }\n", "function f() { echo; }\n",
                 id="parens-form"),
    pytest.param("f() { echo; }\n", "f() { echo; }\n", id="plain-form"),
])
def test_function_keyword_forms(run, source, want):
    """All three function declaration spellings print canonically."""
    result = run(["-ln=bash", "-"], stdin=source)
    # CATCHES: the parens in `function f()` are kept (unlike the plain
    # `f()` form, which also keeps them), and a one-line body stays on
    # one line in every spelling.
    assert (result.returncode, result.out, result.err) == (0, want, "")


def test_function_keyword_is_gated_in_posix(run):
    """posix refuses the `function` builtin with its own message."""
    result = run(["-ln=posix", "-"], stdin="function f { echo; }\n")
    # CATCHES: the gate fires at the function NAME position (1:12),
    # after `function ` has been consumed, and mentions the builtin.
    assert (result.returncode, result.out, result.err) == (
        1, "",
        '<standard input>:1:12: the "function" builtin is a bash feature; '
        "tried parsing as posix\n")


# --- more zsh redirect and background aliases -------------------------------

ZSH_RDR_ALL = [
    pytest.param(">&|", "cmd &>|f\n", id="alias-clobber"),
    pytest.param(">&!", "cmd &>|f\n", id="alias-bang-normalised"),
]


@pytest.mark.parametrize("source,want", ZSH_RDR_ALL)
def test_zsh_rdr_all_aliases(run, source, want):
    """zsh's `>&|` and `>&!` aliases print as the `&>|` spelling."""
    result = run(["-ln=zsh", "-"], stdin="cmd %s f\n" % source)
    # CATCHES: both clobber-all aliases collapse to one canonical form,
    # and the target word stays attached to the operator.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("source,want", [
    pytest.param("a &! b\n", "a &|\nb\n", id="starts-next-stmt"),
    pytest.param("cmd >f &!\n", "cmd >f &|\n", id="trailing"),
])
def test_zsh_andbang_normalises_to_andpipe(run, source, want):
    """zsh's `&!` background-and-clobber alias prints as `&|`."""
    result = run(["-ln=zsh", "-"], stdin=source)
    # CATCHES: the bang form is an alias for `&|`; after it the command
    # ends, so a following word starts a new statement line.
    assert (result.returncode, result.out, result.err) == (0, want, "")


# --- arithmetic operator errors ----------------------------------------------

ARITHM_ERRORS = [
    pytest.param("echo $((1 = 2))\n", 11, "`=` must follow a name\n",
                 id="assign-to-number"),
    pytest.param('echo $(("a" = b))\n', 13, "`=` must follow a name\n",
                 id="assign-to-string"),
    pytest.param("echo $((? a : b))\n", 9, "`?` must follow an expression\n",
                 id="quest-first"),
    pytest.param("echo $((a ? : c))\n", 11,
                 "`?` must be followed by an expression\n", id="colon-after-quest"),
    pytest.param("echo $((a : b))\n", 11,
                 "ternary operator missing `?` before `:`\n", id="colon-alone"),
    pytest.param("echo $((a[))\n", 10, "`[` must be followed by an expression\n",
                 id="lone-bracket"),
    pytest.param("echo $((1++))\n", 10, "`++` must follow a name\n",
                 id="post-inc-number"),
]


@pytest.mark.parametrize("source,col,err", ARITHM_ERRORS)
def test_arithmetic_operator_errors(run, source, col, err):
    """Misplaced arithmetic operators each get their own message."""
    result = run(["-ln=bash", "-"], stdin=source)
    # CATCHES: assignment, ternary, subscript and increment operators
    # all name the offending token and what it must follow.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:%d: %s" % (col, err))


@pytest.mark.parametrize("source", [
    pytest.param("echo $((a[i] + 1))\n", id="indexed-name"),
    pytest.param("echo $((a++))\n", id="post-increment"),
])
def test_arithmetic_name_forms_are_accepted(run, source):
    """Indexing and post-increment are fine when applied to names."""
    result = run(["-ln=bash", "-"], stdin=source)
    # CATCHES: `a[i]` is a valid operand and `a++` a valid postfix on a
    # name, where `1++` was rejected — the parser only allows names.
    assert (result.returncode, result.out, result.err) == (0, source, "")


def test_subscript_flags_are_gated_in_bash(run):
    """`${a[(r)x]}` subscript flags are a zsh-only feature."""
    result = run(["-ln=bash", "-"], stdin="echo ${a[(r)x]}\n")
    # CATCHES: the gate fires at the `(` of the subscript flags with the
    # usual "tried parsing as bash" suffix.
    assert (result.returncode, result.out, result.err) == (
        1, "",
        "<standard input>:1:10: subscript flags are a zsh feature; "
        "tried parsing as bash\n")


# --- regex word edges ---------------------------------------------------------

def test_regex_with_two_words_is_not_a_test_operator(run):
    """Only one word may follow `=~`; a second is not an operator."""
    result = run(["-ln=bash", "-"], stdin="[[ a =~ b c ]]\n")
    # CATCHES: the regex word swallows `b`, so `c` lands in operator
    # position and is reported as an invalid test operator.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:11: not a valid test operator: `c`\n")


def test_regex_with_nested_parens_survives(run):
    """Nested parentheses in a regex stay inside the one regex word."""
    result = run(["-ln=bash", "-"], stdin="[[ a =~ ((b)) ]]\n")
    # CATCHES: the lexer counts opening parens in the regex so nesting
    # does not end the word early or open a subshell.
    assert (result.returncode, result.out, result.err) == (
        0, "[[ a =~ ((b)) ]]\n", "")
