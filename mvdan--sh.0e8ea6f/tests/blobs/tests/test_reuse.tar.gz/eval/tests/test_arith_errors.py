"""Arithmetic-expression and `let` parsing errors, recorded from the
reference binary.

Each malformed expression fails with status 1, empty stdout and the exact
diagnostic below; stdin runs are labelled '<standard input>'. The positions
pin where the arithmetic parser gave up, which is not always the offending
token — e.g. `+=` is blamed even when it follows a perfectly good
parenthesised expression, because only a plain name may be assigned to.
"""

import pytest

ARITH_ERRORS = [
    pytest.param("echo $((: ))", "1:9: ternary operator missing `?` before `:`",
                 id="colon-without-question"),
    pytest.param("echo $(([1]))", "1:9: `[` must follow a name like a[i]",
                 id="bracket-after-literal"),
    pytest.param("echo $((1 + ))", "1:11: `+` must be followed by an expression",
                 id="dangling-plus"),
    pytest.param("echo $((! ))", "1:9: `!` must be followed by an expression",
                 id="dangling-bang"),
    pytest.param("echo $((++$a))", "1:9: `++` must be followed by a literal",
                 id="increment-of-parameter"),
    pytest.param("echo $(((a) += 1))", "1:13: `+=` must follow a name",
                 id="plusequals-after-parens"),
    pytest.param("echo $(($a += 1))", "1:12: `+=` must follow a name",
                 id="plusequals-after-parameter"),
    pytest.param("echo $((a[))", "1:10: `[` must be followed by an expression",
                 id="empty-subscript"),
    pytest.param("echo $((a \"b\"))", "1:11: not a valid arithmetic operator: `\"`",
                 id="string-literal-as-operator"),
    pytest.param("echo $((a", "1:6: reached EOF without matching `$((` with `))`",
                 id="unterminated-arith"),
    pytest.param("echo $((**2))", "1:9: `**` must follow an expression",
                 id="leading-power"),
    pytest.param("echo $((*2))", "1:9: `*` must follow an expression",
                 id="leading-multiply"),
    pytest.param("echo $((a+(b[))", "1:13: `[` must be followed by an expression",
                 id="nested-empty-subscript"),
    pytest.param("let a += b", "1:7: statements must be separated by &, ; or a newline",
                 id="let-arguments-are-statements"),
    pytest.param("let )", "1:1: `let` must be followed by an expression",
                 id="let-with-closing-paren"),
]


@pytest.mark.parametrize("source,message", ARITH_ERRORS)
def test_arithmetic_error(run, source, message):
    """Malformed arithmetic fails with the recorded position and message."""
    result = run(["-ln=bash"], stdin=source)
    # CATCHES: the arithmetic parser has a distinct diagnostic per broken
    # shape — operator with no right operand, assignment target checks,
    # subscript rules, EOF inside $(( — each with its own column.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", ("<standard input>:" + message + "\n").encode())
