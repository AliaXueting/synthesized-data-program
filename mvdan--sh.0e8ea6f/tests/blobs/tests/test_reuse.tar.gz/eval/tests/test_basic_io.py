"""Basic stdin/file/stdout interactions, ported from the native basic.txtar
and atomic.txtar CLI test scripts of the reference repository."""

import subprocess

import pytest

from conftest import program_path, pinned_env

GOLDEN = "foo\n"


def test_stdin_is_formatted_by_default(run):
    """With no arguments the program reads stdin and prints the result."""
    result = run([], stdin=" foo\n")
    # CATCHES: leading whitespace is stripped and a newline-terminated
    # canonical form is written to stdout with no diagnostics at all.
    assert (result.returncode, result.out, result.err) == (0, GOLDEN, "")


def test_single_dash_reads_stdin(run):
    """A lone '-' argument still means 'read standard input'."""
    result = run(["-"], stdin=" foo\n")
    # CATCHES: '-' is only a stdin marker in this position; it must not be
    # lstat'ed as a path, and the output must equal the no-argument form.
    assert (result.returncode, result.out, result.err) == (0, GOLDEN, "")


def test_dash_beside_a_path_is_treated_as_a_path(run, write):
    """'-' combined with other arguments is looked up as a literal path."""
    write("g.sh", " foo\n")
    result = run(["-", "g.sh"])
    # CATCHES: stdin mode is only chosen when '-' is the only argument;
    # here it fails with a lstat error yet still formats the other file.
    assert result.returncode == 1
    assert result.out == GOLDEN
    assert result.err == "lstat -: no such file or directory\n"


def test_file_argument_prints_without_rewriting(run, write, tmp_path):
    """A file argument is formatted to stdout; the file itself is untouched."""
    write("input.sh", " foo\n")
    result = run(["input.sh"])
    # CATCHES: plain formatting must never modify the input file on disk,
    # unlike -w; the original bytes stay intact.
    assert (result.returncode, result.out, result.err) == (0, GOLDEN, "")
    assert (tmp_path / "input.sh").read_text() == " foo\n"


def test_list_reports_differing_file_on_stdout(run, write):
    """-l prints differing paths to stdout and exits non-zero."""
    write("input.sh", " foo\n")
    result = run(["-l", "input.sh"])
    # CATCHES: the file name goes to stdout (not stderr) and the exit
    # status is 1 because at least one file differed.
    assert (result.returncode, result.out, result.err) == (1, "input.sh\n", "")


def test_list_repeats_a_repeated_path(run, write):
    """Passing the same path twice lists it once per occurrence."""
    write("input.sh", " foo\n")
    result = run(["-l", "input.sh", "input.sh"])
    # CATCHES: each explicit argument is processed independently, so the
    # differing path is reported twice on stdout.
    assert result.returncode == 1
    assert result.out == "input.sh\ninput.sh\n"
    assert result.err == ""


def test_list_write_reformats_in_place(run, write, tmp_path):
    """-l -w rewrites differing files and still lists them on stdout."""
    write("input.sh", " foo\n")
    result = run(["-l", "-w", "input.sh"])
    # CATCHES: -w writes the canonical bytes into the file, the path is
    # listed once, and the run exits 0 because nothing was left unwritten.
    assert (result.returncode, result.out, result.err) == (0, "input.sh\n", "")
    assert (tmp_path / "input.sh").read_text() == GOLDEN


def test_long_list_write_flags(run, write, tmp_path):
    """--list --write behaves exactly like the short flag pair."""
    write("input.sh", " foo\n")
    result = run(["--list", "--write", "input.sh"])
    # CATCHES: the long spellings of the flags share one code path with
    # -l -w, including the in-place rewrite and the stdout listing.
    assert (result.returncode, result.out, result.err) == (0, "input.sh\n", "")
    assert (tmp_path / "input.sh").read_text() == GOLDEN


def test_list_null_separator(run, write):
    """-l=0 separates the listed paths with NUL instead of a newline."""
    write("a.sh", " foo\n")
    write("b.sh", "bar\n")
    result = run(["-l=0", "a.sh", "b.sh"])
    # CATCHES: the differing path is terminated by a zero byte rather than
    # a newline, which keeps the listing safe for paths with spaces.
    assert (result.returncode, result.err) == (1, "")
    assert result.stdout == b"a.sh\x00"
    spelled = run(["--list=0", "a.sh", "b.sh"])
    # CATCHES: the long spelling of the flag produces the same bytes, and a
    # file that does not differ contributes nothing at all.
    assert (spelled.returncode, spelled.stdout) == (1, b"a.sh\x00")


def test_already_formatted_file_is_silent(run, write):
    """-l on an already canonical file prints nothing and exits 0."""
    write("ok.sh", "foo\n")
    write("messy.sh", " foo\n")
    result = run(["-l", "ok.sh"])
    # CATCHES: exit status 0 with empty stdout is the "nothing differs"
    # signal, distinguishing -l from a formatting failure.
    assert (result.returncode, result.out, result.err) == (0, "", "")
    # Positive control: a differing sibling listed in the same run must be
    # reported on stdout, so the empty result above cannot come from a
    # program that simply never lists anything.
    both = run(["-l", "ok.sh", "messy.sh"])
    assert (both.returncode, both.out, both.err) == (1, "messy.sh\n", "")


def test_empty_stdin_prints_a_single_newline(run):
    """Formatting an empty program still emits one newline."""
    result = run([], stdin=b"")
    # CATCHES: even the empty program produces a trailing newline on
    # stdout rather than zero bytes.
    assert (result.returncode, result.out, result.err) == (0, "\n", "")


def test_missing_path_is_a_lstat_error(run):
    """A nonexistent path is reported once per argument on stderr."""
    result = run(["nonexistent-1", "nonexistent-2"])
    # CATCHES: every bad path gets its own lstat diagnostic on stderr and
    # the overall exit status is 1, with nothing on stdout.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "lstat nonexistent-1: no such file or directory\n"
        "lstat nonexistent-2: no such file or directory\n"
    )


def test_write_refuses_standard_input(run):
    """-w cannot be combined with reading from stdin."""
    result = run(["-w"], stdin=" foo\n")
    # CATCHES: writing back to stdin is impossible, so the program refuses
    # with a dedicated message instead of silently dropping the output.
    assert (result.returncode, result.out, result.err) == (
        1, "", "-w cannot be used on standard input\n")


def test_nul_bytes_in_input_are_dropped(run):
    """NUL bytes embedded in a program are removed from the output."""
    result = run([], stdin=b"if\x00 a; th\x00en b; \x00fi")
    # CATCHES: the parser tolerates NUL bytes and the printer omits them,
    # producing the same output as the equivalent NUL-free program.
    assert (result.returncode, result.out, result.err) == (0, "if a; then b; fi\n", "")


def test_atomic_rewrite_while_script_runs(run, write, tmp_path):
    """-w replaces the file atomically while it is being executed."""
    script = "echo foo\n  %s -l -w input.sh\necho bar\n" % program_path()
    write("input.sh", script)
    # CATCHES: the rewrite is atomic, so the shell that is still reading
    # the script sees the rest of it and finishes with 'echo bar'.
    proc = subprocess.run(
        ["sh", "input.sh"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(tmp_path),
        env=pinned_env(tmp_path),
        timeout=20,
    )
    assert (proc.returncode, proc.stderr) == (0, b"")
    assert proc.stdout.decode() == "foo\ninput.sh\nbar\n"
    assert (tmp_path / "input.sh").read_text() == (
        "echo foo\n%s -l -w input.sh\necho bar\n" % program_path())


def test_write_preserves_the_file_mode(run, write, tmp_path):
    """-w rewrites the file but keeps its original permission bits."""
    import os
    write("input.sh", " foo\n")
    os.chmod(str(tmp_path / "input.sh"), 0o741)
    result = run(["-w", "input.sh"])
    # CATCHES: the atomic replacement copies the mode of the replaced file,
    # so the unusual 741 bits survive the rewrite while the content is
    # canonicalised — a naive temp-file write would reset them to 0644.
    assert (result.returncode, result.out, result.err) == (0, "", "")
    assert (tmp_path / "input.sh").read_text() == GOLDEN
    assert (os.stat(str(tmp_path / "input.sh")).st_mode & 0o777) == 0o741


def test_list_null_separator_with_write_stays_quiet(run, write, tmp_path):
    """-l=0 -w reports the rewritten path with a NUL and exits 0."""
    write("input.sh", " foo\n")
    result = run(["-l=0", "-w", "input.sh"])
    # CATCHES: the NUL-separated listing still names the file, but because
    # -w also rewrites it the run exits 0 instead of the dry-run status 1.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"input.sh\x00"
    assert (tmp_path / "input.sh").read_text() == GOLDEN
