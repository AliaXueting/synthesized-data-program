"""Directory walking, file discovery and the --find utility.

Ported from the native walk.txtar and detect.txtar CLI test scripts: the
found-file list, the walked-format output and the per-file diagnostics
were all recorded from the reference binary running over these trees.
"""

import os
import textwrap

import pytest

FIND_GOLDEN = textwrap.dedent("""\
    error/parse-error.sh
    modify/dir/ext.sh
    modify/ext-shebang.sh
    modify/ext.bash
    modify/ext.bats
    modify/ext.mksh
    modify/ext.sh
    modify/ext.zsh
    modify/shebang-args
    modify/shebang-bash
    modify/shebang-bash.sh
    modify/shebang-dash
    modify/shebang-env-bash
    modify/shebang-env-bats
    modify/shebang-env-sh
    modify/shebang-mksh
    modify/shebang-sh
    modify/shebang-space
    modify/shebang-tabs
    modify/shebang-usr-sh
    modify/shebang-zsh
    nonl/shebang
    """)

LIST_GOLDEN = textwrap.dedent("""\
    modify/ext-shebang.sh
    modify/ext.bash
    modify/ext.bats
    modify/ext.mksh
    modify/ext.sh
    modify/ext.zsh
    modify/shebang-args
    modify/shebang-bash
    modify/shebang-bash.sh
    modify/shebang-dash
    modify/shebang-env-bash
    modify/shebang-env-bats
    modify/shebang-env-sh
    modify/shebang-mksh
    modify/shebang-sh
    modify/shebang-space
    modify/shebang-tabs
    modify/shebang-usr-sh
    modify/shebang-zsh
    nonl/shebang
    """)

PARSE_ERR = "error/parse-error.sh:1:1: `foo(` must be followed by `)`\n"


@pytest.fixture
def tree(write):
    """Rebuild the directory tree used by the native walk.txtar script."""
    files = {
        "modify/shebang-sh": "#!/bin/sh\n foo\n",
        "modify/shebang-bash": "#!/bin/bash\n foo=(bar)\n",
        "modify/shebang-bash.sh": "#!/bin/bash\n foo=(bar)\n",
        "modify/shebang-dash": "#!/bin/dash\n foo\n",
        "modify/shebang-usr-sh": "#!/usr/bin/sh\n foo\n",
        "modify/shebang-env-bash": "#!/usr/bin/env bash\n foo=(bar)\n",
        "modify/shebang-env-sh": "#!/bin/env sh\n foo\n",
        "modify/shebang-mksh": "#!/bin/mksh\n foo |&\n",
        "modify/shebang-zsh": "#!/bin/zsh\n ${+foo}\n",
        "modify/shebang-env-bats": '#!/usr/bin/env bats\n @test "foo" { bar; }\n',
        "modify/shebang-space": "#! /bin/sh\n foo\n",
        "modify/shebang-tabs": "#!\t/bin/env\tsh\n foo\n",
        "modify/shebang-args": "#!/bin/bash -e -x\n foo\n",
        "modify/ext.sh": " foo\n",
        "modify/ext.bash": " foo=(bar)\n",
        "modify/ext.mksh": " foo |&\n",
        "modify/ext.zsh": " ${+foo}\n",
        "modify/ext.bats": ' @test "foo" { bar; }\n',
        "modify/ext-shebang.sh": "#!/bin/sh\n foo\n",
        "modify/dir/ext.sh": "foo\n",
        "none/.hidden": "foo long enough\n",
        "none/.hidden-shebang": "#!/bin/sh\n foo\n",
        "none/..hidden-shebang": "#!/bin/sh\n foo\n",
        "none/noext-empty": "foo\n",
        "none/noext-noshebang": "foo long enough\n",
        "none/shebang-nonewline": "#!/bin/shfoo\n",
        "none/ext.other": "foo\n",
        "none/empty": "",
        "none/ext-shebang.other": "#!/bin/sh\n foo\n",
        "none/shebang-nospace": "#!/bin/envsh\n foo\n",
        "error/parse-error.sh": "foo(\n",
        "skip/.git/ext.sh": "foo\n",
        "skip/.svn/ext.sh": "foo\n",
        "skip/.hg/ext.sh": "foo\n",
        # a shebang with no trailing newline: nine bytes, still a script
        "nonl/shebang": b"#!/bin/sh",
    }
    for rel, content in files.items():
        write(rel, content)
    return files


def test_find_lists_shell_files_recursively(run, tree):
    """-f walks the tree and prints every shell file it detects."""
    result = run(["-f", "."])
    # CATCHES: detection uses shell extensions and shebangs, skips hidden
    # files, non-shell extensions, empty extensionless files and VCS
    # directories, and prints paths in walk order.
    assert (result.returncode, result.out, result.err) == (0, FIND_GOLDEN, "")


@pytest.mark.parametrize("flags", [["--find", "."], ["-f", "."]])
def test_find_long_flag_matches_short(run, tree, flags):
    """--find and -f produce the same listing."""
    result = run(flags)
    # CATCHES: both spellings of the find flag share one implementation,
    # including the ordering of discovered paths.
    assert (result.returncode, result.out, result.err) == (0, FIND_GOLDEN, "")


def test_find_null_separator(run, tree):
    """-f=0 separates the printed paths with NUL bytes."""
    result = run(["-f=0", "modify/ext.sh", "modify/shebang-sh",
                  "none/ext-shebang.other", "none/noext-noshebang"])
    # CATCHES: explicit file arguments are still filtered by extension and
    # shebang, and the separator becomes a zero byte instead of a newline.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"modify/ext.sh\x00modify/shebang-sh\x00"


def test_find_explicit_files_check_extension_and_shebang(run, tree):
    """-f on explicit paths applies the same detection as walking."""
    result = run(["-f", "modify/ext.sh", "modify/shebang-sh",
                  "none/ext-shebang.other", "none/noext-noshebang"])
    # CATCHES: the .other file with a shebang and the extensionless file
    # without one are both skipped even though they were named directly.
    assert (result.returncode, result.out, result.err) == (
        0, "modify/ext.sh\nmodify/shebang-sh\n", "")


def test_format_directory_prints_every_file(run, tree):
    """Formatting a directory concatenates every file's output on stdout."""
    result = run(["."])
    # CATCHES: each discovered file is printed in walk order separated by
    # nothing but the files' own newlines, and the single unparseable file
    # only produces a stderr line without aborting the walk.
    assert result.returncode == 1
    assert result.err == PARSE_ERR
    assert result.out == textwrap.dedent("""\
        foo
        #!/bin/sh
        foo
        foo=(bar)
        @test "foo" { bar; }
        foo |&
        foo
        ${+foo}
        #!/bin/bash -e -x
        foo
        #!/bin/bash
        foo=(bar)
        #!/bin/bash
        foo=(bar)
        #!/bin/dash
        foo
        #!/usr/bin/env bash
        foo=(bar)
        #!/usr/bin/env bats
        @test "foo" { bar; }
        #!/bin/env sh
        foo
        #!/bin/mksh
        foo |&
        #!/bin/sh
        foo
        #! /bin/sh
        foo
        #!\t/bin/env\tsh
        foo
        #!/usr/bin/sh
        foo
        #!/bin/zsh
        ${+foo}
        #!/bin/sh
        """)


def test_list_directory_lists_differing_files(run, tree):
    """-l on a directory lists every file whose formatting differs."""
    result = run(["-l", "."])
    # CATCHES: the differing files are listed without the parse error file
    # (which only gets a stderr diagnostic), and the status stays 1.
    assert result.returncode == 1
    assert result.err == PARSE_ERR
    assert result.out == LIST_GOLDEN


def test_list_write_directory_rewrites_files(run, tree, tmp_path):
    """-l -w on a directory rewrites all differing files in place."""
    result = run(["-l", "-w", "."])
    # CATCHES: the listing is identical to the dry -l run, the files on
    # disk are canonicalised, and the parse error still fails the run.
    assert result.returncode == 1
    assert result.err == PARSE_ERR
    assert result.out == LIST_GOLDEN
    assert (tmp_path / "modify/ext.sh").read_text() == "foo\n"
    assert (tmp_path / "modify/shebang-mksh").read_text() == "#!/bin/mksh\nfoo |&\n"


def test_lone_parse_error_file(run, tree):
    """Formatting the broken file alone reports only its own error."""
    result = run(["error/parse-error.sh"])
    # CATCHES: the diagnostic is prefixed with the path as given and no
    # other output is produced.
    assert (result.returncode, result.out, result.err) == (1, "", PARSE_ERR)


def test_explicitly_named_files_ignore_detection(run, tree):
    """Files named directly are formatted even if a walk would skip them."""
    with_shebang = run(["none/ext-shebang.other"])
    # CATCHES: the .other extension and the missing extension are ignored
    # for explicit arguments, so both files format normally.
    assert (with_shebang.returncode, with_shebang.out, with_shebang.err) == (
        0, "#!/bin/sh\nfoo\n", "")
    without = run(["none/noext-noshebang"])
    assert (without.returncode, without.out, without.err) == (
        0, "foo long enough\n", "")


def test_shebang_only_file_without_final_newline(run, tree):
    """A nine-byte shebang-only file counts as a script and gains a newline."""
    listed = run(["-f", "nonl"])
    # CATCHES: detection reads the shebang even without a trailing newline
    # and the printer then appends the missing final newline.
    assert (listed.returncode, listed.out, listed.err) == (0, "nonl/shebang\n", "")
    formatted = run(["nonl/shebang"])
    assert (formatted.returncode, formatted.out, formatted.err) == (0, "#!/bin/sh\n", "")


def test_writing_a_symlink_is_refused(run, tree, tmp_path):
    """-w refuses to replace a symlink with a regular file."""
    (tmp_path / "link.bash").symlink_to(tmp_path / "modify/ext.bash")
    listed = run(["-l", "link.bash"])
    # CATCHES: reading through the symlink works for -l, but -w detects
    # the non-regular file and refuses the atomic replacement.
    assert (listed.returncode, listed.out, listed.err) == (1, "link.bash\n", "")
    written = run(["-w", "link.bash"])
    assert written.returncode == 1
    assert written.out == ""
    assert written.err == (
        'refusing to atomically replace "link.bash" with a regular file '
        'as it is not one already\n')
    assert (tmp_path / "modify/ext.bash").read_text() == " foo=(bar)\n"


def test_formatting_a_symlinked_script_follows_it(run, tree, tmp_path):
    """An explicit symlink argument is resolved to its target."""
    (tmp_path / "link.sh").symlink_to(tmp_path / "modify/ext-shebang.sh")
    result = run(["link.sh"])
    # CATCHES: the symlink is followed for explicit arguments so the
    # target's content is formatted rather than refused.
    assert (result.returncode, result.out, result.err) == (0, "#!/bin/sh\nfoo\n", "")


# The tree used by the native detect.txtar script: shell extensions,
# extension-less shebang scripts and shebangs behind foreign extensions.
DETECT_FILES = {
    "ext.sh": " foo\n",
    "noext-shebang": "#!/bin/sh\n foo\n",
    "plain.other": "#!/bin/sh\n foo\n",
    "exec.other": "#!/bin/sh\n foo\n",
    "execnoshebang.other": "foo long enough\n",
    "noshebang.other": "foo long enough\n",
    ".hidden.other": "#!/bin/sh\n foo\n",
}

DETECT_DEFAULT = "ext.sh\nnoext-shebang\n"
DETECT_ALL = "exec.other\next.sh\nnoext-shebang\nplain.other\n"


@pytest.fixture
def detect_tree(write, tmp_path):
    """Rebuild the detect.txtar tree, marking two files executable."""
    for rel, content in DETECT_FILES.items():
        write(rel, content)
    for rel in ("exec.other", "execnoshebang.other"):
        os.chmod(str(tmp_path / rel), 0o755)


def test_detect_default_is_the_default_mode(run, detect_tree):
    """--detect=default finds exactly what no flag at all finds."""
    plain = run(["-f", "."])
    explicit = run(["-f", "--detect=default", "."])
    # CATCHES: the default mode only uses shell extensions and extension-less
    # shebangs, and naming it explicitly changes nothing about the listing.
    assert (plain.returncode, plain.out, plain.err) == (0, DETECT_DEFAULT, "")
    assert (explicit.returncode, explicit.out, explicit.err) == (
        0, DETECT_DEFAULT, "")


def test_detect_all_reads_shebangs_behind_any_extension(run, detect_tree):
    """--detect=all considers foreign extensions with a shebang inside."""
    result = run(["-f", "--detect=all", "."])
    # CATCHES: plain.other and exec.other are only found because their
    # contents start with a shebang, while the shebang-less and hidden
    # files with the same extension stay invisible.
    assert (result.returncode, result.out, result.err) == (0, DETECT_ALL, "")


def test_detect_exec_requires_the_executable_bit(run, detect_tree):
    """--detect=exec only adds foreign files that are executable."""
    result = run(["-f", "--detect=exec", "."])
    # CATCHES: exec.other is executable and carries a shebang so it is
    # found, but the equally executable execnoshebang.other is not,
    # because its contents do not look like a script.
    assert (result.returncode, result.out, result.err) == (
        0, "exec.other\next.sh\nnoext-shebang\n", "")


def test_detect_all_applies_to_explicit_arguments(run, detect_tree):
    """-f --detect=all filters named paths by the same detection."""
    result = run(["-f", "--detect=all", "plain.other", "noshebang.other"])
    # CATCHES: the shebang decides for the named foreign-extension file,
    # while the shebang-less one is dropped even though it was named.
    assert (result.returncode, result.out, result.err) == (
        0, "plain.other\n", "")


def test_detect_all_governs_formatting_a_directory(run, detect_tree, tmp_path):
    """Formatting a walk with --detect=all reaches the extra files."""
    listed = run(["-l", "--detect=all", "."])
    # CATCHES: every file the all mode discovers is listed as differing
    # because each of them starts with a stray space.
    assert (listed.returncode, listed.out, listed.err) == (1, DETECT_ALL, "")
    written = run(["-l", "-w", "--detect=all", "."])
    assert (written.returncode, written.out, written.err) == (0, DETECT_ALL, "")
    # CATCHES: the plain.other file, invisible to the default mode, has
    # really been rewritten in place by the walk.
    assert (tmp_path / "plain.other").read_text() == "#!/bin/sh\nfoo\n"
    assert (tmp_path / "noshebang.other").read_text() == "foo long enough\n"


def test_a_named_pipe_is_skipped_without_blocking(run, write, tmp_path):
    """A FIFO in the tree is ignored rather than read for a shebang."""
    write("ext.sh", " foo\n")
    write("sub/inner.sh", " bar\n")
    os.mkfifo(str(tmp_path / "named-pipe"))
    result = run(["-f", "."], timeout=10)
    # CATCHES: probing a non-regular file for a shebang would block forever
    # on an open FIFO, so only the two regular scripts are listed.
    assert (result.returncode, result.out, result.err) == (
        0, "ext.sh\nsub/inner.sh\n", "")
    formatted = run(["."], timeout=10)
    # CATCHES: formatting the tree also leaves the pipe alone and still
    # exits 0 rather than reporting an error for it.
    assert (formatted.returncode, formatted.out, formatted.err) == (
        0, "foo\nbar\n", "")


def test_a_symlinked_directory_is_not_followed(run, write, tmp_path):
    """A symlink to a directory names no files, unlike one to a script."""
    write("ext.sh", " foo\n")
    write("sub/inner.sh", " bar\n")
    (tmp_path / "link-dir").symlink_to(tmp_path / "sub")
    (tmp_path / "link.sh").symlink_to(tmp_path / "ext.sh")
    walked = run(["-f", "link-dir"])
    # CATCHES: the walk treats the directory symlink as a single non-regular
    # entry and never descends into it, so nothing is printed at all.
    assert (walked.returncode, walked.out, walked.err) == (0, "", "")
    formatted = run(["link-dir"])
    assert (formatted.returncode, formatted.out, formatted.err) == (0, "", "")
    linked = run(["-f", "link.sh"])
    # CATCHES: a symlink to a regular script is still reported by name,
    # showing that the skip above is about directories, not symlinks.
    assert (linked.returncode, linked.out, linked.err) == (0, "link.sh\n", "")


def test_a_broken_symlink_argument_reports_the_stat_error(run, write, tmp_path):
    """An explicit dangling symlink fails to be resolved for formatting."""
    (tmp_path / "broken.sh").symlink_to(tmp_path / "does-not-exist")
    result = run(["broken.sh"])
    # CATCHES: an explicit symlink argument is resolved with stat, which
    # fails for a dangling link, and the raw stat error is printed with
    # status 1 rather than being silently skipped.
    assert (result.returncode, result.out, result.err) == (
        1, "", "stat broken.sh: no such file or directory\n")


def test_a_broken_symlink_is_refused_by_find_too(run, tmp_path):
    """-f on a dangling symlink reports the same stat error."""
    (tmp_path / "broken.sh").symlink_to(tmp_path / "does-not-exist")
    result = run(["-f", "broken.sh"])
    # CATCHES: the symlink is resolved before the find branch runs, so
    # even the listing mode fails on a dangling link instead of printing
    # its path.
    assert (result.returncode, result.out, result.err) == (
        1, "", "stat broken.sh: no such file or directory\n")


def test_a_broken_symlink_in_a_walk_is_skipped(run, write, tmp_path):
    """A dangling symlink met during a walk names no error at all."""
    write("real.sh", " foo\n")
    (tmp_path / "broken.sh").symlink_to(tmp_path / "does-not-exist")
    found = run(["-f", "."])
    # CATCHES: walked symlinks are not resolved, so the dangling link is
    # discarded as a non-regular entry and only the real script is listed.
    assert (found.returncode, found.out, found.err) == (0, "real.sh\n", "")
    formatted = run(["."])
    # CATCHES: formatting the tree is equally unaffected by the broken
    # link, which never produces a diagnostic.
    assert (formatted.returncode, formatted.out, formatted.err) == (
        0, "foo\n", "")
