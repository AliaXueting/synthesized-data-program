"""Simplifier edge cases beyond the ported native table.

Every rewrite below was recorded from the reference binary running -s:
subscript operators are re-spaced like ordinary arithmetic, parentheses
around subscripts behave differently in array literals than in parameter
expansions, negated test expressions fold their operator when an opposite
exists, and several quoting styles must survive -s untouched.
"""

import pytest

SIMPLIFY_EDGES = [
    pytest.param("a[i+1]=v", "a[i + 1]=v", id="index-operator-respaced"),
    pytest.param("a=( [(i)]=v )", "a=([(i)]=v)", id="array-literal-parens-kept"),
    pytest.param("a[-i]=v", "a[-i]=v", id="negative-index-untouched"),
    pytest.param("[[ ((a)) ]]", "[[ a ]]", id="test-parens-dropped"),
    pytest.param("[[ ! -z a ]]", "[[ -n a ]]", id="negation-flips-z"),
    pytest.param("[[ ! ! -z a ]]", "[[ -z a ]]", id="double-negation-cancels"),
    pytest.param("[[ ! -e a ]]", "[[ ! -e a ]]", id="unflippable-operator-kept"),
    pytest.param('echo "$a"', 'echo "$a"', id="quoted-parameter-kept"),
    pytest.param('echo "\'"', 'echo "\'"', id="embedded-single-quote-kept"),
    pytest.param('echo "\\n"', 'echo "\\n"', id="backslash-escape-kept"),
    pytest.param('[[ "a" == b ]]', '[[ "a" == b ]]', id="right-operand-stays-bare"),
]


@pytest.mark.parametrize("source,want", SIMPLIFY_EDGES)
def test_simplify_edge_rewrites(run, source, want):
    """-s rewrites or preserves each edge shape exactly as recorded."""
    result = run(["-s", "-ln=bash"], stdin=source)
    # CATCHES: subscript re-spacing, the array-literal/parameter-expansion
    # paren asymmetry, negation folding (single and double, plus the case
    # with no opposite operator) and quote preservation are all pinned
    # byte for byte.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, (want + "\n").encode(), b"")


@pytest.mark.parametrize("source,want", SIMPLIFY_EDGES)
def test_simplify_edge_output_is_stable(run, source, want):
    """A second formatting pass over the simplified text changes nothing."""
    again = run(["-s", "-ln=bash"], stdin=want)
    # CATCHES: none of these rewrites may oscillate — re-running -s over
    # its own output yields the identical program, so a wrong rewrite
    # that is not a fixpoint would be exposed here.
    assert (again.returncode, again.stdout, again.stderr) == (
        0, (want + "\n").encode(), b"")
