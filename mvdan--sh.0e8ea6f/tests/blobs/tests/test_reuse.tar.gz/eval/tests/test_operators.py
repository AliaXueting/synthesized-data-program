"""Operator tables across the shell dialects.

Every expectation here was recorded by running the reference binary. The
tables pin three different behaviours for each operator family: the
canonical print in the dialects that accept it, the exact gate error in
the dialects that reject it, and the typed-JSON round trip through
--to-json/--from-json (which exercises the operator decoders).
"""

import json

import pytest

# --- redirect operators ----------------------------------------------------

# (spelling, full input, expected print) in bash.
REDIR_BASH = [
    pytest.param("cmd >out", "cmd >out\n", id="out"),
    pytest.param("cmd >>out", "cmd >>out\n", id="append"),
    pytest.param("cmd <in", "cmd <in\n", id="in"),
    pytest.param("cmd <>io", "cmd <>io\n", id="in-out"),
    pytest.param("cmd <&3", "cmd <&3\n", id="dup-in"),
    pytest.param("cmd >&2", "cmd >&2\n", id="dup-out"),
    pytest.param("cmd >|out", "cmd >|out\n", id="clobber"),
    pytest.param("cmd <<EOF\nbody\nEOF\n", "cmd <<EOF\nbody\nEOF\n", id="heredoc"),
    pytest.param("cmd <<-EOF\nbody\nEOF\n", "cmd <<-EOF\n\tbody\nEOF\n",
                 id="dash-heredoc"),
    pytest.param("cmd <<<str", "cmd <<<str\n", id="word-heredoc"),
    pytest.param("cmd &>all", "cmd &>all\n", id="all-out"),
    pytest.param("cmd &>>all", "cmd &>>all\n", id="all-append"),
    pytest.param("cmd &>!all", "cmd &>!all\n", id="bang-stays-in-word"),
    pytest.param("cmd &>>!all", "cmd &>>!all\n", id="bang-stays-in-append"),
]

# zsh-only spellings; in bash the `!` is part of the redirected word.
REDIR_ZSH_ONLY = [
    pytest.param("cmd >>|out", "cmd >>|out\n", id="append-clobber"),
    pytest.param("cmd &>|all", "cmd &>|all\n", id="all-clobber"),
    pytest.param("cmd &>>|all", "cmd &>>|all\n", id="all-append-clobber"),
    pytest.param("cmd &>!all", "cmd &>|all\n", id="bang-normalised"),
    pytest.param("cmd &>>!all", "cmd &>>|all\n", id="append-bang-normalised"),
]

REDIR_BASH_GATE = [
    pytest.param("cmd >>|out\n", "`>>|` redirects are a zsh feature; tried parsing as bash\n"),
    pytest.param("cmd &>|all\n", "`&>|` redirects are a zsh feature; tried parsing as bash\n"),
    pytest.param("cmd &>>|all\n", "`&>>|` redirects are a zsh feature; tried parsing as bash\n"),
]


@pytest.mark.parametrize("source,want", REDIR_BASH)
def test_redirect_operator_table_bash(run, source, want):
    """Every bash redirect operator reprints in its canonical spelling."""
    result = run(["-ln=bash", "-"], stdin=source)
    # CATCHES: each operator must survive a parse/print round trip with
    # its exact spelling, including the <<- heredoc's re-indented body.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("source,want", REDIR_ZSH_ONLY)
def test_redirect_operator_table_zsh(run, source, want):
    """zsh redirect spellings print canonically; `!` forms normalise to `|`."""
    result = run(["-ln=zsh", "-"], stdin=source)
    # CATCHES: zsh maps the `&>!`/`&>>!` spellings onto the same operator
    # as `&>|`/`&>>|` and prints the `|` spelling, while bash would keep
    # the `!` inside the word.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("source,err", REDIR_BASH_GATE, ids=["append-clob", "all-clob", "all-append-clob"])
def test_zsh_redirects_are_gated_in_bash(run, source, err):
    """bash rejects the zsh-only redirect operators with a dialect gate."""
    result = run(["-ln=bash", "-"], stdin=source)
    # CATCHES: the lexer must refuse `>>|` and friends in bash, naming
    # the operator, the feature and the dialect tried.
    assert (result.returncode, result.out, result.err) == (1, "", "<standard input>:1:5: " + err)


# --- parameter expansion operators -----------------------------------------

PARAM_BASH = [
    pytest.param("+", "echo ${a+b}\n"),
    pytest.param(":+", "echo ${a:+b}\n"),
    pytest.param("-", "echo ${a-b}\n"),
    pytest.param(":-", "echo ${a:-b}\n"),
    pytest.param("?", "echo ${a?b}\n"),
    pytest.param(":?", "echo ${a:?b}\n"),
    pytest.param("=", "echo ${a=b}\n"),
    pytest.param(":=", "echo ${a:=b}\n"),
    pytest.param("%", "echo ${a%b}\n"),
    pytest.param("%%", "echo ${a%%b}\n"),
    pytest.param("#", "echo ${a#b}\n"),
    pytest.param("##", "echo ${a##b}\n"),
    pytest.param("^", "echo ${a^b}\n"),
    pytest.param("^^", "echo ${a^^b}\n"),
    pytest.param(",", "echo ${a,b}\n"),
    pytest.param(",,", "echo ${a,,b}\n"),
]

PARAM_ZSH_ONLY = [
    pytest.param(":#", "echo ${a:#b}\n", id="col-hash"),
    pytest.param(":|", "echo ${a:|b}\n", id="col-pipe"),
    pytest.param(":*", "echo ${a:*b}\n", id="col-star"),
]


@pytest.mark.parametrize("op,want", PARAM_BASH)
def test_paramexp_operator_table_bash(run, op, want):
    """Every bash ${...} operator reprints unchanged."""
    result = run(["-ln=bash", "-"], stdin="echo ${a%sb}\n" % op)
    # CATCHES: all sixteen bash expansion operators must round trip with
    # their exact one- or two-character spelling.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("op,want", PARAM_ZSH_ONLY)
def test_paramexp_zsh_operators(run, op, want):
    """zsh's `:#`, `:|` and `:*` expansion operators are accepted there."""
    result = run(["-ln=zsh", "-"], stdin="echo ${a%sb}\n" % op)
    # CATCHES: these three operators are zsh-only; bash and posix must
    # reject them while zsh prints them verbatim.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("op", [":#", ":|", ":*"])
def test_paramexp_zsh_operators_are_gated(run, op):
    """`:#`, `:|` and `:*` are refused outside zsh."""
    for dialect in ("bash", "posix"):
        result = run(["-ln=%s" % dialect, "-"], stdin="echo ${a%sb}\n" % op)
        # CATCHES: the gate error names the construct with the argument
        # placeholder form `${name:#arg}` and the dialect tried.
        assert (result.returncode, result.out, result.err) == (
            1, "",
            "<standard input>:1:9: ${name%sarg} is a zsh feature; "
            "tried parsing as %s\n" % (op, dialect))


@pytest.mark.parametrize("op", ["^", "^^", ",", ",,"], ids=["caret", "dbl-caret", "comma", "dbl-comma"])
def test_paramexp_case_operators_are_bash_only(run, op):
    """The case-modifier operators are refused in zsh and posix."""
    for dialect in ("zsh", "posix"):
        result = run(["-ln=%s" % dialect, "-"], stdin="echo ${a%sb}\n" % op)
        # CATCHES: zsh and posix reject the bash case operators with the
        # generic "this expansion operator" wording at the operator.
        assert (result.returncode, result.out, result.err) == (
            1, "",
            "<standard input>:1:9: this expansion operator is a bash "
            "feature; tried parsing as %s\n" % dialect)


@pytest.mark.parametrize("letter", list("QEPAaKk"))
def test_paramexp_at_operator_letters(run, letter):
    """`${a@X}` accepts the seven bash operator letters and mksh's `Q`."""
    bash = run(["-ln=bash", "-"], stdin="echo ${a@%s}\n" % letter)
    # CATCHES: every letter must round trip in bash, and mksh must accept
    # only `Q` while rejecting the other six with the gate error.
    assert (bash.returncode, bash.out, bash.err) == (
        0, "echo ${a@%s}\n" % letter, "")
    mksh = run(["-ln=mksh", "-"], stdin="echo ${a@%s}\n" % letter)
    if letter == "Q":
        assert (mksh.returncode, mksh.out, mksh.err) == (0, "echo ${a@Q}\n", "")
    else:
        assert (mksh.returncode, mksh.out, mksh.err) == (
            1, "",
            "<standard input>:1:10: this expansion operator is a bash "
            "feature; tried parsing as mksh\n")


def test_paramexp_at_operator_rejects_unknown_letters(run):
    """`${a@b}` with an unknown letter is a hard error, not a gate."""
    result = run(["-ln=bash", "-"], stdin="echo ${a@b}\n")
    # CATCHES: an invalid @ operator letter is reported as an invalid
    # operator naming the letter, unlike the dialect gates.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:10: invalid @ expansion operator `b`\n")


def test_parnames_is_bash_only(run):
    """`${!a*}` and `${!a@}` decode in bash and are gated elsewhere."""
    for op in ("*", "@"):
        bash = run(["-ln=bash", "-"], stdin="echo ${!a%s}\n" % op)
        assert (bash.returncode, bash.out, bash.err) == (0, "echo ${!a%s}\n" % op, "")
        zsh = run(["-ln=zsh", "-"], stdin="echo ${!a%s}\n" % op)
        assert (zsh.returncode, zsh.out, zsh.err) == (
            1, "", "<standard input>:1:6: `${!foo}` is a bash/mksh feature; "
            "tried parsing as zsh\n")
        posix = run(["-ln=posix", "-"], stdin="echo ${!a%s}\n" % op)
        assert (posix.returncode, posix.out, posix.err) == (
            1, "", "<standard input>:1:6: `${!foo}` is a bash/mksh feature; "
            "tried parsing as posix\n")
        # CATCHES: mksh's message is the odd one out: it names the full
        # `${!foo*}` form even though it shares the bash/mksh prefix.
        mksh = run(["-ln=mksh", "-"], stdin="echo ${!a%s}\n" % op)
        assert (mksh.returncode, mksh.out, mksh.err) == (
            1, "", "<standard input>:1:6: `${!foo%s}` is a bash feature; "
            "tried parsing as mksh\n" % op)


# --- arithmetic operators ---------------------------------------------------

ARITH_BIN_BASH = [
    pytest.param("+", "echo $((a + b))\n"),
    pytest.param("-", "echo $((a - b))\n"),
    pytest.param("*", "echo $((a * b))\n"),
    pytest.param("/", "echo $((a / b))\n"),
    pytest.param("%", "echo $((a % b))\n"),
    pytest.param("**", "echo $((a ** b))\n"),
    pytest.param("==", "echo $((a == b))\n"),
    pytest.param(">", "echo $((a > b))\n"),
    pytest.param("<", "echo $((a < b))\n"),
    pytest.param("!=", "echo $((a != b))\n"),
    pytest.param("<=", "echo $((a <= b))\n"),
    pytest.param(">=", "echo $((a >= b))\n"),
    pytest.param("&", "echo $((a & b))\n"),
    pytest.param("|", "echo $((a | b))\n"),
    pytest.param("^", "echo $((a ^ b))\n"),
    pytest.param(">>", "echo $((a >> b))\n"),
    pytest.param("<<", "echo $((a << b))\n"),
    pytest.param("&&", "echo $((a && b))\n"),
    pytest.param("||", "echo $((a || b))\n"),
    pytest.param(",", "echo $((a, b))\n"),
    pytest.param("=", "echo $((a = b))\n"),
    pytest.param("+=", "echo $((a += b))\n"),
    pytest.param("-=", "echo $((a -= b))\n"),
    pytest.param("*=", "echo $((a *= b))\n"),
    pytest.param("/=", "echo $((a /= b))\n"),
    pytest.param("%=", "echo $((a %= b))\n"),
    pytest.param("&=", "echo $((a &= b))\n"),
    pytest.param("|=", "echo $((a |= b))\n"),
    pytest.param("^=", "echo $((a ^= b))\n"),
    pytest.param("<<=", "echo $((a <<= b))\n"),
    pytest.param(">>=", "echo $((a >>= b))\n"),
    pytest.param("^^", "echo $((a ^^ b))\n"),
]

ARITH_BIN_ZSH_ONLY = [
    pytest.param("&&=", "echo $((a &&= b))\n", id="logical-and-assign"),
    pytest.param("||=", "echo $((a ||= b))\n", id="logical-or-assign"),
    pytest.param("**=", "echo $((a **= b))\n", id="power-assign"),
    pytest.param("^^=", "echo $((a ^^= b))\n", id="xor-assign"),
]


@pytest.mark.parametrize("op,want", ARITH_BIN_BASH)
def test_arith_binary_operator_table(run, op, want):
    """bash arithmetic binary operators print with their spacing rules."""
    result = run(["-ln=bash", "-"], stdin="echo $((a %s b))\n" % op)
    # CATCHES: every binary operator must re-print with single spaces,
    # including the comma which prints as `a, b`.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("op,want", ARITH_BIN_ZSH_ONLY)
def test_arith_assignment_operators_zsh(run, op, want):
    """zsh accepts the four extra assignment operators."""
    result = run(["-ln=zsh", "-"], stdin="echo $((a %s b))\n" % op)
    # CATCHES: `&&=`, `||=`, `**=` and `^^=` only lex in zsh, where they
    # print like any other assignment operator.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("op", ["&&=", "||=", "**=", "^^="],
                         ids=["and", "or", "pow", "xor"])
def test_arith_assignment_operators_gated_in_bash(run, op):
    """bash rejects the zsh assignment operators after the first half."""
    result = run(["-ln=bash", "-"], stdin="echo $((a %s b))\n" % op)
    # CATCHES: bash lexes e.g. `&&=` as `&&` followed by `=`, so the
    # error names the two-character operator, not the three-character one.
    head = op[:2]
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:11: `%s` must be followed by an "
        "expression\n" % head)


ARITH_UNARY = [
    pytest.param("!a", "echo $((! a))\n", id="not"),
    pytest.param("~a", "echo $((~a))\n", id="bnot"),
    pytest.param("+a", "echo $((+a))\n", id="plus"),
    pytest.param("-a", "echo $((-a))\n", id="minus"),
    pytest.param("++a", "echo $((++a))\n", id="pre-inc"),
    pytest.param("--a", "echo $((--a))\n", id="pre-dec"),
    pytest.param("a++", "echo $((a++))\n", id="post-inc"),
    pytest.param("a--", "echo $((a--))\n", id="post-dec"),
]


@pytest.mark.parametrize("expr,want", ARITH_UNARY)
def test_arith_unary_operator_table(run, expr, want):
    """Unary arithmetic operators print tight, except `!` which spaces."""
    result = run(["-ln=bash", "-"], stdin="echo $((%s))\n" % expr)
    # CATCHES: logical not prints as `! a` with a space while every other
    # unary operator (and both fixings of ++/--) prints without one.
    assert (result.returncode, result.out, result.err) == (0, want, "")


def test_arith_ternary_and_comma_chains(run):
    """Ternaries and comma chains keep their spacing in full form."""
    ternary = run(["-ln=bash", "-"], stdin="echo $((a ? b : c))\n")
    # CATCHES: the ternary keeps `?`/`:` spacing and a comma chain joins
    # with `, ` separators, unlike the minified forms.
    assert (ternary.returncode, ternary.out, ternary.err) == (
        0, "echo $((a ? b : c))\n", "")
    comma = run(["-ln=bash", "-"], stdin="echo $((a, b, c))\n")
    assert (comma.returncode, comma.out, comma.err) == (
        0, "echo $((a, b, c))\n", "")


def test_arith_ternary_without_colon(run):
    """A `?` without its `:` is an error naming both characters."""
    result = run(["-ln=bash", "-"], stdin="echo $((a ? b))\n")
    # CATCHES: the parser reports the missing colon of the ternary, a
    # distinct message from a missing operand.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:11: ternary operator missing `:` after `?`\n")


# --- test expression operators ----------------------------------------------

TEST_UNARY = [
    "-e", "-f", "-d", "-c", "-b", "-p", "-S", "-L", "-k", "-g", "-u",
    "-G", "-O", "-N", "-r", "-w", "-x", "-s", "-t", "-z", "-n", "-o",
    "-v", "-R",
]

TEST_UNARY_NORMALISED = [
    pytest.param("-a", "-e", id="a-becomes-e"),
    pytest.param("-h", "-L", id="h-becomes-capital-L"),
]

TEST_BINARY = [
    "=~", "-nt", "-ot", "-ef", "-eq", "-ne", "-le", "-ge", "-lt", "-gt",
    "&&", "||", "=", "==", "!=", "<", ">",
]


@pytest.mark.parametrize("op", TEST_UNARY)
def test_unary_test_operator_table(run, op):
    """Every unary [[ ]] test operator survives the round trip."""
    result = run(["-ln=bash", "-"], stdin="[[ %s f ]]\n" % op)
    # CATCHES: all 24 unary spellings, including the mixed-case -S, -G,
    # -O, -N, -L and -R, must re-print verbatim.
    assert (result.returncode, result.out, result.err) == (0, "[[ %s f ]]\n" % op, "")


@pytest.mark.parametrize("op,want", TEST_UNARY_NORMALISED)
def test_unary_test_operator_aliases_normalise(run, op, want):
    """`-a` and `-h` are aliases that print as `-e` and `-L`."""
    result = run(["-ln=bash", "-"], stdin="[[ %s f ]]\n" % op)
    # CATCHES: the parser folds the historical alias spellings onto the
    # canonical operator before printing.
    assert (result.returncode, result.out, result.err) == (0, "[[ %s f ]]\n" % want, "")


@pytest.mark.parametrize("op", TEST_BINARY)
def test_binary_test_operator_table(run, op):
    """Every binary [[ ]] test operator survives the round trip."""
    result = run(["-ln=bash", "-"], stdin="[[ a %s b ]]\n" % op)
    # CATCHES: all 17 binary operators, from `=~` to `>`, print verbatim
    # with single spaces around them.
    assert (result.returncode, result.out, result.err) == (0, "[[ a %s b ]]\n" % op, "")


@pytest.mark.parametrize("op", ["-N", "-R"], ids=["modified", "ref-var"])
def test_unary_test_operators_zsh_rejects(run, op):
    """zsh refuses bash's -N and -R but keeps -S, -G, -O, -o and -v."""
    for other in ("-S", "-G", "-O", "-o", "-v"):
        ok = run(["-ln=zsh", "-"], stdin="[[ %s f ]]\n" % other)
        assert (ok.returncode, ok.out, ok.err) == (0, "[[ %s f ]]\n" % other, "")
    result = run(["-ln=zsh", "-"], stdin="[[ %s f ]]\n" % op)
    # CATCHES: zsh lexes -N/-R as words, so the error blames the operand
    # `f` as an invalid test operator rather than the flag itself.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:7: not a valid test operator: `f`\n")


# --- case, process substitution and extglob operators -----------------------

CASE_TABLE = [
    pytest.param("bash", ";;", "case x in\na) A ;;\nb) B ;;\nesac\n", None),
    pytest.param("bash", ";&", "case x in\na) A ;&\nb) B ;;\nesac\n", None),
    pytest.param("bash", ";;&", "case x in\na) A ;;&\nb) B ;;\nesac\n", None),
    pytest.param("bash", ";|", None, "`|` can only immediately follow a statement\n"),
    pytest.param("zsh", ";;", "case x in\na) A ;;\nb) B ;;\nesac\n", None),
    pytest.param("zsh", ";&", "case x in\na) A ;&\nb) B ;;\nesac\n", None),
    pytest.param("zsh", ";|", "case x in\na) A ;|\nb) B ;;\nesac\n", None),
    pytest.param("mksh", ";|", "case x in\na) A ;|\nb) B ;;\nesac\n", None),
]

CASE_ZSH_GATE = [
    ("zsh", ";;&", "case patterns must consist of words\n"),
    ("mksh", ";;&", "case patterns must consist of words\n"),
]


@pytest.mark.parametrize("dialect,op,want,err", CASE_TABLE)
def test_case_operator_table(run, dialect, op, want, err):
    """Case terminators `;;`, `;&`, `;;&` and `;|` per dialect."""
    source = "case x in\na) A %s\nb) B ;;\nesac\n" % op
    result = run(["-ln=%s" % dialect, "-"], stdin=source)
    # CATCHES: `;|` is zsh/mksh-only (bash blames `|`), while `;;&` is
    # bash-only (zsh and mksh blame the pattern).
    if err is None:
        assert (result.returncode, result.out, result.err) == (0, want, "")
    else:
        assert (result.returncode, result.out, result.err) == (1, "", "<standard input>:2:7: " + err)


@pytest.mark.parametrize("dialect,op,err", CASE_ZSH_GATE,
                         ids=["zsh-dbl-semi-pipe", "mksh-dbl-semi-pipe"])
def test_case_dbl_semi_pipe_is_bash_only(run, dialect, op, err):
    """`;;&` is refused by zsh and mksh."""
    source = "case x in\na) A %s\nb) B ;;\nesac\n" % op
    result = run(["-ln=%s" % dialect, "-"], stdin=source)
    # CATCHES: the rejection message comes from the pattern parser, so
    # the column points past the terminator.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:2:8: " + err)


PROCSUBST_TABLE = [
    pytest.param("bash", "<(", "cmd <(a)\n", None),
    pytest.param("bash", ">(", "cmd >(a)\n", None),
    pytest.param("bash", "=(", None, "`=(` process substitutions are a zsh feature; tried parsing as bash\n"),
    pytest.param("zsh", "=(", "cmd =(a)\n", None),
    pytest.param("mksh", "<(", None, "`<` must be followed by a word\n"),
    pytest.param("mksh", ">(", None, "`>` must be followed by a word\n"),
    pytest.param("posix", "<(", None, "`<` must be followed by a word\n"),
    pytest.param("posix", "=(", None, "`=(` process substitutions are a zsh feature; tried parsing as posix\n"),
]


@pytest.mark.parametrize("dialect,op,want,err", PROCSUBST_TABLE)
def test_procsubst_table(run, dialect, op, want, err):
    """Process substitution acceptance and gate errors per dialect."""
    result = run(["-ln=%s" % dialect, "-"], stdin="cmd %sa)\n" % op)
    # CATCHES: `=(` is zsh-only with its own message, while mksh/posix
    # report `<(`/`>(` as a redirect missing its word.
    if err is None:
        assert (result.returncode, result.out, result.err) == (0, want, "")
    else:
        assert (result.returncode, result.out, result.err) == (
            1, "", "<standard input>:1:5: " + err)


EXTGLOB_TABLE = [
    "?(", "*(", "+(", "@(", "!(",
]


@pytest.mark.parametrize("op", EXTGLOB_TABLE, ids=["quest", "star", "plus", "at", "excl"])
def test_extglob_operator_table(run, op):
    """The five extglob operators parse in bash and zsh, not posix."""
    bash = run(["-ln=bash", "-"], stdin="ls %sa)\n" % op)
    assert (bash.returncode, bash.out, bash.err) == (0, "ls %sa)\n" % op, "")
    zsh = run(["-ln=zsh", "-"], stdin="ls %sa)\n" % op)
    assert (zsh.returncode, zsh.out, zsh.err) == (0, "ls %sa)\n" % op, "")
    posix = run(["-ln=posix", "-"], stdin="ls %sa)\n" % op)
    # CATCHES: posix refuses every extended glob with one shared gate
    # message that names both bash and mksh.
    assert (posix.returncode, posix.out, posix.err) == (
        1, "", "<standard input>:1:4: extended globs are a bash/mksh "
        "feature; tried parsing as posix\n")


@pytest.mark.parametrize("op", TEST_UNARY)
def test_unary_test_operators_decode_from_json(run, op):
    """Each unary test operator survives a typed-JSON round trip."""
    encoded = run(["-ln=bash", "--to-json"], stdin="[[ %s f ]]\n" % op)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the UnTestOperator decoder must accept every spelling the
    # parser can produce, from `-e` to `-R`.
    assert (result.returncode, result.out, result.err) == (0, "[[ %s f ]]\n" % op, "")


@pytest.mark.parametrize("op", TEST_BINARY)
def test_binary_test_operators_decode_from_json(run, op):
    """Each binary test operator survives a typed-JSON round trip."""
    encoded = run(["-ln=bash", "--to-json"], stdin="[[ a %s b ]]\n" % op)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the BinTestOperator decoder must accept all seventeen
    # spellings, including `=~` and the file-age comparisons.
    assert (result.returncode, result.out, result.err) == (0, "[[ a %s b ]]\n" % op, "")


@pytest.mark.parametrize("op,want", PARAM_BASH)
def test_paramexp_operators_decode_from_json(run, op, want):
    """Each bash expansion operator survives a typed-JSON round trip."""
    encoded = run(["-ln=bash", "--to-json"], stdin="echo ${a%sb}\n" % op)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the ParExpOperator decoder covers all sixteen bash
    # spellings including the bare `+`/`-`/`=`/`?` forms.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("source,want", REDIR_BASH)
def test_redirect_operators_decode_from_json(run, source, want):
    """Each bash redirect operator survives a typed-JSON round trip."""
    encoded = run(["-ln=bash", "--to-json"], stdin=source)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the RedirOperator decoder must accept all fourteen bash
    # spellings, keeping heredoc bodies intact through the cycle.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("source,want", REDIR_ZSH_ONLY)
def test_zsh_redirect_operators_decode_from_json(run, source, want):
    """The zsh-only redirect spellings decode back to their print form."""
    encoded = run(["-ln=zsh", "--to-json"], stdin=source)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: `&>!` encodes as the same RdrAllClob operator as `&>|`,
    # so the JSON round trip prints the normalised `|` spelling too.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("op,want", ARITH_BIN_BASH)
def test_arith_binary_operators_decode_from_json(run, op, want):
    """Each bash arithmetic operator survives a typed-JSON round trip."""
    encoded = run(["-ln=bash", "--to-json"], stdin="echo $((a %s b))\n" % op)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the BinAritOperator decoder must accept all thirty-one
    # bash spellings, from `+` to `>>=`.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("expr,want", ARITH_UNARY)
def test_arith_unary_operators_decode_from_json(run, expr, want):
    """Each unary arithmetic operator survives a typed-JSON round trip."""
    encoded = run(["-ln=bash", "--to-json"], stdin="echo $((%s))\n" % expr)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the UnAritOperator decoder must distinguish pre/post
    # increment (`++a` vs `a++`) through the Op string alone.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("op", EXTGLOB_TABLE, ids=["quest", "star", "plus", "at", "excl"])
def test_extglob_operators_decode_from_json(run, op):
    """Each extglob operator survives a typed-JSON round trip."""
    encoded = run(["-ln=bash", "--to-json"], stdin="ls %sa)\n" % op)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the GlobOperator decoder must accept all five spellings,
    # each of which changes the pattern's meaning.
    assert (result.returncode, result.out, result.err) == (0, "ls %sa)\n" % op, "")


@pytest.mark.parametrize("dialect,op", [("bash", ";;"), ("bash", ";&"), ("bash", ";;&"),
                                        ("zsh", ";|"), ("mksh", ";|")])
def test_case_operators_decode_from_json(run, dialect, op):
    """Each accepted case terminator survives a typed-JSON round trip."""
    source = "case x in\na) A %s\nb) B ;;\nesac\n" % op
    encoded = run(["-ln=%s" % dialect, "--to-json"], stdin=source)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the CaseOperator decoder must keep the terminator
    # semantics distinct; `;|` only appears in zsh/mksh trees.
    assert (result.returncode, result.out, result.err) == (0, source, "")


# --- operator round trips through the typed JSON -----------------------------

ROUND_TRIPS = [
    pytest.param("bash", "cmd >out 2>&1 >>log <<EOF\nbody\nEOF\n",
                 "cmd >out 2>&1 >>log <<EOF\nbody\nEOF\n", id="redirects"),
    pytest.param("bash", "a && b | c || d\n", "a && b | c || d\n",
                 id="pipeline-operators"),
    pytest.param("bash", "echo $((a + b * c - d))\n", "echo $((a + b * c - d))\n",
                 id="arith-chain"),
    pytest.param("bash", "echo ${a:-b} ${c##d} ${e%%f} ${g//h/i}\n",
                 "echo ${a:-b} ${c##d} ${e%%f} ${g//h/i}\n", id="paramexp-operators"),
    pytest.param("bash", "[[ -e f && a == b || ! -z c ]]\n",
                 "[[ -e f && a == b || ! -z c ]]\n", id="test-operators"),
    pytest.param("bash", "case $a in\nx|y) A ;;&\n*) B ;;\nesac\n",
                 "case $a in\nx | y) A ;;&\n*) B ;;\nesac\n", id="case-operators"),
    pytest.param("bash", "ls ?(a|b)*(.txt)+(c)@(d)!(e)\n",
                 "ls ?(a|b)*(.txt)+(c)@(d)!(e)\n", id="extglob-operators"),
    pytest.param("bash", "diff <(a) >(b)\n", "diff <(a) >(b)\n", id="procsubst"),
    pytest.param("zsh", "cmd >>|a &>|b &>>|c\n", "cmd >>|a &>|b &>>|c\n",
                 id="zsh-redirects"),
    pytest.param("zsh", "echo ${(j.:.)a} ${a:#b} ${a:|b} ${a:*b}\n",
                 "echo ${(j.:.)a} ${a:#b} ${a:|b} ${a:*b}\n", id="zsh-expansions"),
    pytest.param("zsh", "echo $((a **= b))\necho $((a ^^ b))\necho $((a ^^= b))\n"
                 "echo $((a ||= b))\necho $((a &&= b))\n",
                 "echo $((a **= b))\necho $((a ^^ b))\necho $((a ^^= b))\n"
                 "echo $((a ||= b))\necho $((a &&= b))\n", id="zsh-arith"),
    pytest.param("mksh", "case x in\na) A ;|\nb) B ;;\nesac\n",
                 "case x in\na) A ;|\nb) B ;;\nesac\n", id="mksh-case-pipe"),
    pytest.param("zsh", "cmd =(a)\n", "cmd =(a)\n", id="zsh-temp-procsubst"),
    pytest.param("zsh", "a |& b\n", "a |& b\n", id="zsh-pipe-both"),
    pytest.param("bash", "echo ${!a*} ${!a@}\n", "echo ${!a*} ${!a@}\n",
                 id="parnames-both"),
    pytest.param("bash", "echo ${a@Q} ${a@E} ${a@P} ${a@A} ${a@a} ${a@K} ${a@k}\n",
                 "echo ${a@Q} ${a@E} ${a@P} ${a@A} ${a@a} ${a@K} ${a@k}\n",
                 id="at-operators"),
    pytest.param("bash", "echo $((a ? b : c)) $((x, y))\n",
                 "echo $((a ? b : c)) $((x, y))\n", id="ternary-and-comma"),
    pytest.param("bash", "[[ ! f ]]\n[[ ! -z f ]]\n[[ (a == b) ]]\n[[ (! a) ]]\n",
                 "[[ ! f ]]\n[[ ! -z f ]]\n[[ (a == b) ]]\n[[ (! a) ]]\n",
                 id="not-and-paren-tests"),
]


@pytest.mark.parametrize("dialect,source,want", ROUND_TRIPS)
def test_operator_families_round_trip_through_json(run, dialect, source, want):
    """to-json followed by from-json reproduces the canonical print."""
    encoded = run(["-ln=%s" % dialect, "--to-json"], stdin=source)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: every operator spelling must survive an encode/decode
    # cycle through the typed JSON tree, so the decoder's operator
    # tables have to agree with the parser's.
    assert (result.returncode, result.out, result.err) == (0, want, "")


# --- invalid operators in --from-json input ----------------------------------

INVALID_OPS = [
    pytest.param("cmd >out\n", lambda t: t["Stmts"][0]["Redirs"][0].__setitem__("Op", ">!"),
                 'invalid RedirOperator: ">!"\n', id="redirect"),
    pytest.param("a && b\n", lambda t: t["Stmts"][0]["Cmd"].__setitem__("Op", "bogus"),
                 'invalid BinCmdOperator: "bogus"\n', id="bincmd"),
    pytest.param("echo ${a:-b}\n", lambda t: t["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]["Exp"].__setitem__("Op", ":~"),
                 'invalid ParExpOperator: ":~"\n', id="parexp"),
    pytest.param("echo ${!a*}\n", lambda t: t["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0].__setitem__("Names", "bogus"),
                 'invalid ParNamesOperator: "bogus"\n', id="parnames"),
    pytest.param("echo $((a + b))\n", lambda t: t["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]["X"].__setitem__("Op", "++="),
                 'invalid BinAritOperator: "++="\n', id="binarith"),
    pytest.param("echo $((!a))\n", lambda t: t["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]["X"].__setitem__("Op", "!!"),
                 'invalid UnAritOperator: "!!"\n', id="unarith"),
    pytest.param("[[ -e f ]]\n", lambda t: t["Stmts"][0]["Cmd"]["X"].__setitem__("Op", "-ee"),
                 'invalid UnTestOperator: "-ee"\n', id="unarytest"),
    pytest.param("[[ a == b ]]\n", lambda t: t["Stmts"][0]["Cmd"]["X"].__setitem__("Op", "==="),
                 'invalid BinTestOperator: "==="\n', id="binarytest"),
    pytest.param("cmd <(a)\n", lambda t: [p.__setitem__("Op", "<((") for w in t["Stmts"][0]["Cmd"]["Args"] for p in w["Parts"] if p.get("Type") == "ProcSubst"],
                 'invalid ProcOperator: "<(("\n', id="procsubst"),
    pytest.param("case x in\na) A ;;\nesac\n", lambda t: t["Stmts"][0]["Cmd"]["Items"][0].__setitem__("Op", ";;;"),
                 'invalid CaseOperator: ";;;"\n', id="caseitem"),
]


@pytest.mark.parametrize("source,mutate,want", INVALID_OPS)
def test_invalid_operator_decodes_are_rejected(run, source, mutate, want):
    """--from-json rejects an unknown operator string in any family."""
    encoded = run(["-ln=bash", "--to-json"], stdin=source)
    assert encoded.returncode == 0
    tree = json.loads(encoded.out)
    mutate(tree)
    result = run(["--from-json"], stdin=json.dumps(tree))
    # CATCHES: each operator family decoder validates its strings, so a
    # corrupted tree fails with `invalid <Family>: "..."` and exit 1.
    assert (result.returncode, result.out, result.err) == (1, "", want)


def test_invalid_glob_operator_decode(run):
    """--from-json also rejects an unknown extglob operator."""
    encoded = run(["-ln=bash", "--to-json"], stdin="ls ?(a)\n")
    assert encoded.returncode == 0
    tree = json.loads(encoded.out)
    extglob = tree["Stmts"][0]["Cmd"]["Args"][1]["Parts"][0]
    assert extglob["Type"] == "ExtGlob"
    extglob["Op"] = "?(("
    result = run(["--from-json"], stdin=json.dumps(tree))
    # CATCHES: the extglob decoder sits on the word-part path, so the
    # reject happens while decoding the argument's second part.
    assert (result.returncode, result.out, result.err) == (
        1, "", 'invalid GlobOperator: "?(("\n')


def test_unknown_json_field_is_rejected(run):
    """--from-json rejects fields the target node does not have."""
    encoded = run(["-ln=bash", "--to-json"], stdin="ls ?(a)\n")
    assert encoded.returncode == 0
    tree = json.loads(encoded.out)
    # Add an Op field to the plain Lit `ls` word part.
    tree["Stmts"][0]["Cmd"]["Args"][0]["Parts"][0]["Op"] = ">"
    result = run(["--from-json"], stdin=json.dumps(tree))
    # CATCHES: the decoder is strict about unknown fields, naming both
    # the node type and the offending field.
    assert (result.returncode, result.out, result.err) == (
        1, "", 'unknown field for syntax.Lit: "Op"\n')


def test_redirect_without_a_word_crashes(run):
    """A Redirect with no Word makes the reference crash, not error."""
    encoded = run(["-ln=bash", "--to-json"], stdin="cmd >out\n")
    assert encoded.returncode == 0
    tree = json.loads(encoded.out)
    tree["Stmts"][0]["Redirs"][0]["Word"] = None
    result = run(["--from-json"], stdin=json.dumps(tree))
    # CATCHES: the reference dereferences the missing word while
    # printing, exiting 2 with a Go nil-pointer panic on stderr.
    assert result.returncode == 2
    assert result.err.startswith(
        "panic: runtime error: invalid memory address or nil pointer "
        "dereference\n")
