"""Printer option tables, ported from the native syntax/printer_test.go.

Round 1 only exercised one hand-written program per printer flag; these
tables port the full native per-flag tables (TestPrintBinaryNextLine,
TestPrintSwitchCaseIndent, TestPrintFunctionNextLine, TestPrintBlockNextLine,
TestPrintSpaceRedirects, TestPrintKeepPadding, TestPrintKeepPaddingSpaces,
TestPrintMinify and TestPrintSpaces). Every expected string below was
recorded by feeding the input to the reference binary through stdin.
"""

import pytest

# --- TestPrintBinaryNextLine: -bn ---------------------------------------

BINARY_NEXT_LINE = [
    pytest.param("foo <<EOF &&\nl1\nEOF\nbar", "foo <<EOF && bar\nl1\nEOF",
                 id="heredoc-joined-before-operator"),
    pytest.param("a \\\n\t&& b", "a \\\n\t&& b", id="already-continued"),
    pytest.param("a \\\n\t&& b\nc", "a \\\n\t&& b\nc", id="two-statements"),
    pytest.param("{\n(a \\\n&& b)\nc\n}", "{\n\t(a \\\n\t\t&& b)\n\tc\n}",
                 id="nested-subshell-indented"),
    pytest.param("a && b \\\n&& c", "a && b \\\n\t&& c", id="second-operator-moved"),
    pytest.param("a \\\n&& $(b) && c \\\n&& d",
                 "a \\\n\t&& $(b) && c \\\n\t&& d", id="mixed-operators"),
    pytest.param("a \\\n&& b\nc \\\n&& d", "a \\\n\t&& b\nc \\\n\t&& d",
                 id="two-chains"),
    pytest.param("a | {\nb \\\n| c\n}", "a | {\n\tb \\\n\t\t| c\n}",
                 id="inside-block"),
    pytest.param("a \\\n\t&& if foo; then\nbar\nfi",
                 "a \\\n\t&& if foo; then\n\t\tbar\n\tfi", id="if-body-indented"),
    pytest.param("if foo \\\n&& bar\nthen\nbar\nfi",
                 "if foo \\\n\t&& bar\nthen\n\tbar\nfi", id="condition-continued"),
    pytest.param("a |\nb |\nc", "a \\\n\t| b \\\n\t| c", id="pipeline-stacked"),
    pytest.param("foo |\n# misplaced\nbar", "foo \\\n\t|\n\t# misplaced\n\tbar",
                 id="misplaced-comment-indented"),
    pytest.param("{\n\tfoo\n\t#a\n\tbar\n} | etc", "{\n\tfoo\n\t#a\n\tbar\n} | etc",
                 id="comment-before-block-pipe"),
    pytest.param("foo &&\n#a1\n#a2\n$(bar)", "foo \\\n\t&&\n\t#a1\n\t#a2\n\t$(bar)",
                 id="comments-after-operator"),
    pytest.param("{\n\tfoo\n\t#a\n} |\n# misplaced\nbar",
                 "{\n\tfoo\n\t#a\n} \\\n\t|\n\t# misplaced\n\tbar",
                 id="block-then-comment"),
    pytest.param("foo | bar\n#after", "foo | bar\n#after", id="trailing-comment"),
    pytest.param("a |\nb | #c2\nc", "a \\\n\t| b \\\n\t|\n\t#c2\n\tc",
                 id="comment-between-operators"),
    pytest.param("a \\\n\t&", "a \\\n\t&", id="background-kept"),
    pytest.param("[[ a\n\t|| b ]]", "[[ a\n\t|| b ]]", id="test-already-split"),
    pytest.param("[[ a &&\nb ]]", "[[ a\n\t&& b ]]", id="test-operator-moved"),
    pytest.param("[[ a ||\nb ||\nc ]]", "[[ a\n\t|| b\n\t|| c ]]",
                 id="test-two-operators"),
    pytest.param("if [[ a ||\nb ]]; then\nc\nfi",
                 "if [[ a\n\t|| b ]]; then\n\tc\nfi", id="test-inside-if"),
    pytest.param("((a \\\n\t|| b))", "((a \\\n\t|| b))", id="arith-already-split"),
    pytest.param("((a &&\nb))", "((a \\\n\t&& b))", id="arith-operator-moved"),
    pytest.param("((a ||\nb ||\nc))", "((a \\\n\t|| b \\\n\t|| c))",
                 id="arith-two-operators"),
    pytest.param("if ((a ||\nb)); then\nc\nfi",
                 "if ((a \\\n\t|| b)); then\n\tc\nfi", id="arith-inside-if"),
    pytest.param("echo $((a +\nb))", "echo $((a \\\n\t+ b))",
                 id="expansion-operator-moved"),
    pytest.param("a \\\n\tb \\\n\tc \\\n\t# EOC", "a \\\n\tb \\\n\tc\n# EOC",
                 id="word-comment-dedented"),
    pytest.param("a \\\n\t| b \\\n\t| c \\\n\t# EOC", "a \\\n\t| b \\\n\t| c\n# EOC",
                 id="pipeline-comment-dedented"),
]


# --- TestPrintSwitchCaseIndent: -ci -------------------------------------

CASE_INDENT = [
    pytest.param("case $i in\n1)\nfoo\n;;\nesac",
                 "case $i in\n\t1)\n\t\tfoo\n\t\t;;\nesac", id="single-item"),
    pytest.param("case $i in\n1)\na\n;;\n2)\nb\n;;\nesac",
                 "case $i in\n\t1)\n\t\ta\n\t\t;;\n\t2)\n\t\tb\n\t\t;;\nesac",
                 id="two-items"),
    pytest.param("case $i in\n\t#foo\nesac", "case $i in\n\t#foo\nesac",
                 id="lone-comment"),
]


# --- TestPrintFunctionNextLine: -fn -------------------------------------

FUNC_NEXT_LINE = [
    pytest.param("foo() { bar; }", "foo()\n{\n\tbar\n}", id="one-liner"),
    pytest.param("foo()\n{ bar; }", "foo()\n{\n\tbar\n}", id="brace-already-down"),
    pytest.param("foo()\n\n{\n\n\tbar\n}", "foo()\n{\n\n\tbar\n}",
                 id="blank-lines-collapse"),
    pytest.param("function foo {\n\tbar\n}", "function foo\n{\n\tbar\n}",
                 id="function-keyword"),
    pytest.param("function foo() {\n\tbar\n}", "function foo()\n{\n\tbar\n}",
                 id="function-keyword-parens"),
    pytest.param("{ foo() { bar; }; }", "{\n\tfoo()\n\t{\n\t\tbar\n\t}\n}",
                 id="nested-in-block"),
]


# --- TestPrintBlockNextLine: -bl ----------------------------------------

BLOCK_NEXT_LINE = [
    pytest.param("foo() { bar; }", "foo() { bar; }", id="short-func-kept"),
    pytest.param("if a; then b; fi", "if a; then b; fi", id="short-if-kept"),
    pytest.param("if a; then b; else c; fi", "if a; then b; else c; fi",
                 id="short-if-else-kept"),
    pytest.param("while a; do b; done", "while a; do b; done",
                 id="short-while-kept"),
    pytest.param("for i in 1 2; do b; done", "for i in 1 2; do b; done",
                 id="short-for-kept"),
    pytest.param("foo() { bar; baz; }", "foo()\n{\n\tbar\n\tbaz\n}",
                 id="two-statement-func-split"),
    pytest.param("foo() {\n\tbar\n}", "foo()\n{\n\tbar\n}",
                 id="multi-line-func-split"),
    pytest.param("foo()\n{ bar; }", "foo()\n{\n\tbar\n}", id="brace-moved-down"),
    pytest.param("function foo {\n\tbar\n}", "function foo\n{\n\tbar\n}",
                 id="function-keyword-split"),
    pytest.param("{ foo() { bar; baz; }; }", "{ foo()\n\t{\n\t\tbar\n\t\tbaz\n\t}; }",
                 id="inner-func-split-in-one-line-block"),
    pytest.param("{\n\tfoo() { bar; baz; }\n}",
                 "{\n\tfoo()\n\t{\n\t\tbar\n\t\tbaz\n\t}\n}",
                 id="inner-func-split-in-block"),
    pytest.param("if a; then\n\tb\nfi", "if a\nthen\n\tb\nfi", id="if-then-split"),
    pytest.param("if a; then b; c; fi", "if a\nthen\n\tb\n\tc\nfi",
                 id="short-if-body-split"),
    pytest.param("if a; then\n\tb\nelif c; then\n\td\nelse\n\te\nfi",
                 "if a\nthen\n\tb\nelif c\nthen\n\td\nelse\n\te\nfi",
                 id="elif-else-split"),
    pytest.param("while a; do\n\tb\ndone", "while a\ndo\n\tb\ndone",
                 id="while-do-split"),
    pytest.param("until a; do\n\tb\ndone", "until a\ndo\n\tb\ndone",
                 id="until-do-split"),
    pytest.param("for i in 1 2; do\n\tb\ndone", "for i in 1 2\ndo\n\tb\ndone",
                 id="for-do-split"),
    pytest.param("select i in 1 2; do\n\tb\ndone", "select i in 1 2\ndo\n\tb\ndone",
                 id="select-do-split"),
    pytest.param("for i in 1 2 3; do if a; then b; c; fi; d; done",
                 "for i in 1 2 3\ndo\n\tif a\n\tthen\n\t\tb\n\t\tc\n\tfi\n\td\ndone",
                 id="nested-if-in-for"),
    pytest.param("coproc foo {\n\tbar\n\tbaz\n}", "coproc foo {\n\tbar\n\tbaz\n}",
                 id="coproc-brace-kept"),
    pytest.param("foo() (\n\tbar\n\tbaz\n)", "foo() (\n\tbar\n\tbaz\n)",
                 id="subshell-body-kept"),
    pytest.param("foo() if a; then\n\tb\n\tc\nfi", "foo() if a\nthen\n\tb\n\tc\nfi",
                 id="func-if-body-split"),
]


# --- TestPrintSpaceRedirects: -sr ---------------------------------------

SPACE_REDIRECTS = [
    pytest.param("echo foo bar > f", "echo foo bar > f", id="already-spaced"),
    pytest.param("echo > f foo bar", "echo > f foo bar", id="leading-redirect"),
    pytest.param("echo >(cmd)", "echo >(cmd)", id="proc-subst-not-a-redirect"),
    pytest.param("echo > >(cmd)", "echo > >(cmd)", id="redirect-to-proc-subst"),
    pytest.param("<< EOF\nfoo\nEOF", "<< EOF\nfoo\nEOF", id="heredoc-spaced"),
    pytest.param("<<- EOF\n\t$(< foo)\nEOF", "<<- EOF\n\t$(< foo)\nEOF",
                 id="dedented-heredoc"),
    pytest.param("echo 2> f", "echo 2> f", id="fd-redirect"),
    pytest.param("echo foo bar >&1", "echo foo bar >&1", id="dup-redirect"),
    pytest.param("echo 2<&1 foo bar", "echo 2<&1 foo bar", id="input-dup"),
]


# --- TestPrintKeepPadding: -kp ------------------------------------------

KEEP_PADDING = [
    pytest.param("echo foo bar", "echo foo bar", id="single-spaces"),
    pytest.param("echo  foo   bar", "echo  foo   bar", id="word-padding"),
    pytest.param("a=b  c=d   bar", "a=b  c=d   bar", id="assignment-padding"),
    pytest.param("echo foo    >bar", "echo foo    >bar", id="redirect-padding"),
    pytest.param("echo foo    2>bar", "echo foo    2>bar", id="fd-redirect-padding"),
    pytest.param("{ foo;  }", "{ foo;  }", id="brace-padding"),
    pytest.param("a()   { foo; }", "a()   { foo; }", id="func-brace-padding"),
    pytest.param("a   && b", "a   && b", id="and-padding"),
    pytest.param("a   | b", "a   | b", id="pipe-padding"),
    pytest.param("a |  b", "a |  b", id="pipe-padding-after"),
    pytest.param("{  a b c; }", "{  a b c; }", id="block-inner-padding"),
    pytest.param("foo    # x\nbaaar  # y", "foo    # x\nbaaar  # y",
                 id="comment-alignment"),
    pytest.param("{ { a; }; }", "{ { a; }; }", id="nested-blocks"),
    pytest.param("{  a;  }", "{  a;  }", id="block-both-padding"),
    pytest.param("(  a   )", "(  a   )", id="subshell-padding"),
    pytest.param("'foo\nbar'   # x", "'foo\nbar'   # x",
                 id="padding-after-quoted-newline"),
    pytest.param("\tfoo", "foo", id="leading-tab-stripped"),
    pytest.param("  if foo; then bar; fi", "if   foo; then bar; fi",
                 id="keyword-padding-kept"),
    pytest.param("1234 || { x; y; }", "1234 || {\n\tx\n\ty\n}",
                 id="multi-line-block-expanded"),
    pytest.param("array=('one'\n\t\t# 'two'\n\t\t'three')",
                 "array=('one'\n\t# 'two'\n\t'three')", id="array-comment-reindented"),
]


# --- TestPrintKeepPaddingSpaces: -kp -i=2 -------------------------------

KEEP_PADDING_SPACES = [
    pytest.param("array=('one'\n        # 'two'\n        'three')",
                 "array=('one'\n        # 'two'\n        'three')",
                 id="array-comment-alignment"),
    pytest.param("    abc=123", "    abc=123", id="leading-spaces-kept"),
    pytest.param("foo \\\n  bar \\\n    baz", "foo \\\n  bar \\\n    baz",
                 id="continuation-padding"),
    pytest.param("{\n  foo\n    bar\n}", "{\n  foo\n    bar\n}",
                 id="block-inner-padding"),
    pytest.param("# foo\n  # bar", "# foo\n  # bar", id="comment-padding"),
]


# --- TestPrintMinify: -mn ----------------------------------------------

MINIFY = [
    pytest.param("echo foo bar $a $(b)", "echo foo bar $a $(b)", id="already-tight"),
    pytest.param("#comment", "", id="lone-comment-dropped"),
    pytest.param("foo #comment", "foo", id="inline-comment-dropped"),
    pytest.param("foo\n\nbar", "foo\nbar", id="blank-line-dropped"),
    pytest.param("foo &", "foo&", id="background-attached"),
    pytest.param("foo >bar 2>baz <etc", "foo >bar 2>baz <etc", id="redirects-kept"),
    pytest.param("{\n\tfoo\n}", "{\nfoo\n}", id="block-unindented"),
    pytest.param("(\n\ta\n)\n(\n\tb\n\tc\n)", "(a)\n(b\nc)", id="subshells-collapsed"),
    pytest.param("$(\n\ta\n)\n$(\n\tb\n\tc\n)", "$(a)\n$(b\nc)",
                 id="cmdsubsts-collapsed"),
    pytest.param("f() { x; }", "f(){ x;}", id="func-brace-attached"),
    pytest.param("((1 + 2))", "((1+2))", id="arith-spaces-dropped"),
    pytest.param("((\nfoo\n))", "((\\\nfoo))", id="arith-newline-kept"),
    pytest.param("((\na > 0\n&&\na < 10\n))", "((\\\na>0&& \\\na<10))",
                 id="arith-chain-split"),
    pytest.param("((a > 0 &&\na < 10))", "((a>0&& \\\na<10))",
                 id="arith-chain-split-2"),
    pytest.param("echo $a ${b} ${c}-d ${e}f ${g}_h",
                 "echo $a $b $c-d ${e}f ${g}_h", id="braces-dropped-when-safe"),
    pytest.param("echo ${0} ${3} ${10} ${22}", "echo $0 $3 ${10} ${22}",
                 id="multi-digit-params-kept"),
    pytest.param("case $a in\nx) c ;;\ny | z)\n\td\n\t;;\nesac",
                 "case $a in\nx)c;;\ny|z)d\nesac", id="case-collapsed"),
    pytest.param("a && b | c", "a&&b|c", id="operators-attached"),
    pytest.param("a &&\n\tb |\n\tc", "a&&b|c", id="operators-joined"),
    pytest.param("${0/${a}\\\n}", "${0/$a/}", id="expansion-continuation-joined"),
    pytest.param("#!/bin/sh\necho 1\n#!/bin/sh\necho 2",
                 "#!/bin/sh\necho 1\necho 2", id="inner-shebang-comment-dropped"),
    pytest.param("a=$(\n\tcat <<'EOF'\n  hello\nEOF\n)",
                 "a=$(cat <<'EOF'\n  hello\nEOF\n)", id="quoted-heredoc-collapsed"),
    pytest.param("(\n\tcat <<EOF\n hello\nEOF\n)",
                 "(cat <<EOF\n hello\nEOF\n)", id="heredoc-collapsed"),
    pytest.param("diff -y <(cat <<EOF\n1\n2\n3\nEOF\n) <(cat <<EOF\n1\n4\n3\nEOF\n)",
                 "diff -y <(cat <<EOF\n1\n2\n3\nEOF\n) <(cat <<EOF\n1\n4\n3\nEOF\n)",
                 id="proc-subst-heredocs-kept"),
]


# --- TestPrintSpaces: -i N ---------------------------------------------

INDENT_SPACES = [
    pytest.param(["-i=0"], "{\nfoo \\\nbar\n}", "{\n\tfoo \\\n\t\tbar\n}",
                 id="zero-is-tabs"),
    pytest.param(["-i=2"], "{\nfoo \\\nbar\n}", "{\n  foo \\\n    bar\n}",
                 id="two-spaces"),
    pytest.param(["-i=4"], "{\nfoo \\\nbar\n}", "{\n    foo \\\n        bar\n}",
                 id="four-spaces"),
    pytest.param(["-i=2"], "if foo; then # inline1\nbar # inline2\n# withfi\nfi",
                 "if foo; then # inline1\n  bar        # inline2\n# withfi\nfi",
                 id="comment-alignment"),
    pytest.param(["-i=2"], "array=('one'\n    # 'two'\n    'three')",
                 "array=('one'\n  # 'two'\n  'three')", id="array-comment-indent"),
]


FLAG_TABLES = [
    ("binary-next-line", ["-bn"], BINARY_NEXT_LINE),
    ("case-indent", ["-ci"], CASE_INDENT),
    ("func-next-line", ["-fn"], FUNC_NEXT_LINE),
    ("block-next-line", ["-bl"], BLOCK_NEXT_LINE),
    ("space-redirects", ["-sr"], SPACE_REDIRECTS),
    ("keep-padding", ["-kp"], KEEP_PADDING),
    ("keep-padding-spaces", ["-kp", "-i=2"], KEEP_PADDING_SPACES),
    ("minify", ["-mn"], MINIFY),
]


@pytest.mark.parametrize(
    "flags,source,want",
    [pytest.param(flags, case.values[0], case.values[1],
                  id="%s-%s" % (name, case.id))
     for name, flags, cases in FLAG_TABLES for case in cases],
)
def test_printer_flag_table(run, flags, source, want):
    """Each native printer-table case renders to its recorded golden."""
    result = run(flags, stdin=source)
    # CATCHES: byte-exact printer output for this flag, including line
    # continuation backslashes, comment alignment and heredoc bodies.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")


@pytest.mark.parametrize(
    "flags,source,want",
    [pytest.param(p.values[0], p.values[1], p.values[2], id=p.id)
     for p in INDENT_SPACES],
)
def test_indent_spaces_table(run, flags, source, want):
    """Indent widths and the tab default render continuations and comments."""
    result = run(flags, stdin=source)
    # CATCHES: the indent width changes both the block indentation and the
    # doubled indentation of continuation lines, and comments align to the
    # statement's column rather than the raw input padding.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")
