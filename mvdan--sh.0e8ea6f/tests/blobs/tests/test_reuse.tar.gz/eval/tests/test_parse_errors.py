"""Parse error reporting, ported from the native errorCases table in
syntax/parser_test.go and the langErr2 entries of syntax/filetests_test.go.

Every (input, dialect, message) triple below was verified against the
reference binary: exit status 1, empty stdout, and the exact stderr line.
"""

import pytest

ERROR_CASES = [
    pytest.param(b'echo \x80', [], '1:6: invalid UTF-8 encoding', id='invalid-utf8'),
    pytest.param(b'\necho \x80', [], '2:6: invalid UTF-8 encoding', id='utf8-line-two'),
    pytest.param(b'${ ', ['-ln=mksh'],
                 '1:1: reached EOF without matching `${` with `}`', id='mksh-unmatched-brace'),
    pytest.param(b'${ { foo; }bar; }', ['-ln=mksh'],
                 '1:12: statements must be separated by &, ; or a newline',
                 id='statements-unseparated'),
    pytest.param(b'! !', [], '1:1: cannot negate a command multiple times',
                 id='double-negation'),
    pytest.param(b'}', ['-ln=posix'], '1:1: `}` can only be used to close a block',
                 id='lone-closing-brace'),
    pytest.param(b'{ ; }', [], '1:1: `{` must be followed by a statement list',
                 id='empty-block'),
    pytest.param(b';;', ['-ln=posix'], '1:1: `;;` can only be used in a case clause',
                 id='lone-case-terminator'),
    pytest.param(b'<<EOF', ['-ln=mksh'], '1:1: unclosed here-document `EOF`',
                 id='unclosed-heredoc'),
    pytest.param(b'echo $((a b"', [], '1:11: not a valid arithmetic operator: `b`',
                 id='bad-arith-operator'),
    pytest.param(b'echo !(a)', ['-ln=posix'],
                 '1:6: extended globs are a bash/mksh feature; tried parsing as posix',
                 id='extglob-in-posix'),
    pytest.param(b'foo=(1 2)', ['-ln=posix'],
                 '1:5: arrays are a bash/mksh/zsh feature; tried parsing as posix',
                 id='arrays-in-posix'),
    pytest.param(b'((1.2 > 0.3))', ['-ln=bash'],
                 '1:4: floating point arithmetic is a zsh feature; tried parsing as bash',
                 id='float-in-bash'),
    pytest.param(b'$((# 1 + 2))', ['-ln=bash'],
                 '1:1: unsigned expressions are a mksh feature; tried parsing as bash',
                 id='unsigned-in-bash'),
    pytest.param(b'if foo; then; fi', [],
                 '1:9: `then` must be followed by a statement list', id='empty-then-body'),
    pytest.param(b'foo(', ['-ln=zsh'],
                 '1:4: reached EOF without matching `(` with `)`', id='unclosed-subshell'),
]


@pytest.mark.parametrize("source,flags,message", ERROR_CASES)
def test_parse_error_message_and_status(run, source, flags, message):
    """A malformed program fails with the recorded diagnostic and status 1."""
    result = run(flags, stdin=source)
    # CATCHES: the position prefix, the wording of each parser message and
    # the exit status are all pinned; stdout stays empty.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", ("<standard input>:" + message + "\n").encode())


def test_parse_error_for_a_file_argument_uses_its_path(run, write):
    """The same parse error names the file when given as a path argument."""
    write("bad.sh", "foo(\n")
    result = run(["bad.sh"])
    # CATCHES: for real files the '<standard input>' label is replaced by
    # the path exactly as it was given on the command line.
    assert (result.returncode, result.out, result.err) == (
        1, "", "bad.sh:1:1: `foo(` must be followed by `)`\n")


def test_parse_error_in_to_json_mode_has_no_label(run):
    """--to-json reports parse errors without the stdin label."""
    result = run(["--to-json"], stdin="foo(\n")
    # CATCHES: the JSON code path prints the bare parser message, unlike
    # plain formatting which prefixes '<standard input>:'.
    assert (result.returncode, result.out, result.err) == (
        1, "", "1:1: `foo(` must be followed by `)`\n")
