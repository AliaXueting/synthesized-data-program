"""The --exp.recover parser flag, ported from the native
syntax/parser_test.go TestParseRecoverErrors table.

Every recovered output, budget-exhaustion diagnostic and exit status below
was recorded by running the reference binary. The flag lets the parser skip
up to N missing mandatory tokens (quotes, braces, keywords) on a best-effort
basis and print the reconstructed program instead of failing.
"""

import textwrap

import pytest

USAGE = textwrap.dedent("""\
    usage: shfmt [flags] [path ...]

    shfmt formats shell programs. If the only argument is a dash ('-') or no
    arguments are given, standard input will be used, unless it is a terminal.
    If a given path is a directory, all shell scripts found under that directory
    will be used.

      --version  show version and exit

      -l[=0], --list[=0]  error with a list of files whose formatting differs from shfmt;
                          paths are separated by a newline or a null character if -l=0
      -w,     --write     write result to file instead of stdout
      -d,     --diff      error with a diff when the formatting differs
      --apply-ignore      always apply EditorConfig ignore rules
      --detect str        how to detect shell files when walking: default, exec, or all
      --filename str      provide a name for the standard input file

    Parser options:

      -ln, --language-dialect str  bash/posix/mksh/bats/zsh, default "auto"
      -p,  --posix                 shorthand for -ln=posix
      -s,  --simplify              simplify the code

    Printer options:

      -i,  --indent uint       0 for tabs (default), >0 for number of spaces
      -bn, --binary-next-line  binary ops like && and | may start a line
      -ci, --case-indent       switch cases will be indented
      -sr, --space-redirects   redirect operators will be followed by a space
      -kp, --keep-padding      keep column alignment paddings
      -fn, --func-next-line    function opening braces are placed on a separate line (deprecated; use -bl)
      -bl, --block-next-line   multi-line block opening tokens like '{', 'then', and 'do' are placed on a separate line
      -mn, --minify             minify the code to reduce its size (implies -s)

    Utilities:

      -f[=0], --find[=0]  recursively find all shell files and print the paths;
                          paths are separated by a newline or a null character if -f=0
      --to-json           print syntax tree to stdout as a typed JSON
      --from-json         read syntax tree from stdin as a typed JSON

    Formatting options can also be read from EditorConfig files; see 'man shfmt'
    for a detailed description of the tool's behavior.
    For more information and to report bugs, see https://github.com/mvdan/sh.
    """)

# Inputs needing one or more recovered tokens, with the reconstructed
# program the reference prints for --exp.recover=3. All inputs lack a final
# newline; the printer supplies one.
RECOVER_CASES = [
    pytest.param("foo;", "foo", id="complete-with-semicolon"),
    pytest.param("foo", "foo", id="complete-without-semicolon"),
    pytest.param("'incomp", "''", id="unclosed-single-quote"),
    pytest.param("foo; 'incomp", "foo\n''", id="second-statement-quote"),
    pytest.param("{ incomp", "{ incomp; }", id="unclosed-block"),
    pytest.param("(incomp", "(incomp)", id="unclosed-subshell"),
    pytest.param("(incomp; foo", "(\n\tincomp\n\tfoo\n)", id="unclosed-two-stmt-subshell"),
    pytest.param("$(incomp", "$(incomp)", id="unclosed-cmdsubst"),
    pytest.param("((incomp", "((incomp))", id="unclosed-arithmetic"),
    pytest.param("$((incomp", "$((incomp))", id="unclosed-arithmetic-dollar"),
    pytest.param("$[incomp", "$((incomp))", id="legacy-arithmetic-converted"),
    pytest.param("if foo", "if foo; then; fi", id="if-without-then-fi"),
    pytest.param("if foo; then bar", "if foo; then bar; fi", id="if-without-fi"),
    pytest.param("for i in 1 2 3; echo $i; done",
                 "for i in 1 2 3; do echo $i; done", id="for-without-do"),
    pytest.param('" incomp', '" incomp"', id="unclosed-double-quote"),
    pytest.param("`incomp", "$(incomp)", id="unclosed-backquote"),
    pytest.param("incomp >", "incomp >", id="redirect-without-word"),
    pytest.param("${incomp", "${incomp}", id="unclosed-parameter"),
    pytest.param("incomp | ", "incomp |", id="pipe-without-statement"),
    pytest.param("incomp || ", "incomp ||", id="or-without-statement"),
    pytest.param("incomp && ", "incomp &&", id="and-without-statement"),
    pytest.param("(one | { two >", "(one | { two >; })", id="three-missing-tokens"),
    pytest.param("(one > ; two | ); { three",
                 "(\n\tone >\n\ttwo |\n)\n{ three; }", id="mixed-missing-tokens"),
]


@pytest.mark.parametrize("source,want", RECOVER_CASES)
def test_incomplete_programs_are_recovered_and_printed(run, source, want):
    """--exp.recover=3 prints a reconstructed program instead of an error."""
    result = run(["--exp.recover=3"], stdin=source)
    # CATCHES: every missing mandatory token is synthesised (closing the
    # quote/brace/keyword, inserting 'then'/'do', turning `$[...]` and
    # backquotes into `$(...)`), all with status 0 and empty stderr.
    assert (result.returncode, result.out, result.err) == (0, want + "\n", "")


@pytest.mark.parametrize("budget,diagnostic", [
    pytest.param(1, "<standard input>:1:8: reached EOF without matching `{` with `}`\n",
                 id="budget-one-inner-block"),
    pytest.param(2, "<standard input>:1:1: reached EOF without matching `(` with `)`\n",
                 id="budget-two-outer-subshell"),
])
def test_recovery_budget_exhaustion_reports_a_normal_error(run, budget,
                                                           diagnostic):
    """Too small a budget leaves the outermost unrecovered error."""
    result = run(["--exp.recover=%d" % budget], stdin="(one | { two >")
    # CATCHES: '(one | { two >' needs three recovered tokens; with one or
    # two the parse still fails, reporting the innermost block first and
    # then the subshell, exactly like the unrecovered parse would.
    assert (result.returncode, result.out, result.err) == (1, "", diagnostic)


@pytest.mark.parametrize("budget", ["0", "-1"])
def test_zero_and_negative_budgets_behave_like_no_recovery(run, budget):
    """--exp.recover=0 or a negative value disable recovery entirely."""
    result = run(["--exp.recover=" + budget], stdin="'incomp")
    # CATCHES: only a positive budget enables recovery, so these spellings
    # produce the plain unclosed-quote diagnostic with status 1.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:1: reached EOF without closing quote `'`\n")


def test_recover_rejects_non_numeric_values(run):
    """--exp.recover requires an integer; text fails with status 2."""
    result = run(["--exp.recover=abc"], stdin="foo\n")
    # CATCHES: the Go flag package rejects the value before any parsing
    # happens, printing the flag error line followed by the full usage.
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err.startswith(
        'invalid value "abc" for flag -exp.recover: parse error\n')
    assert result.err.endswith(USAGE)


def test_recovery_formats_file_arguments_and_writes_in_place(run, write,
                                                             tmp_path):
    """--exp.recover also governs file arguments, including with -w."""
    write("rec.sh", "if foo")
    result = run(["--exp.recover=3", "-w", "rec.sh"])
    # CATCHES: the recovered program is not just printed — with -w it
    # replaces the incomplete file on disk, and the run exits 0 because
    # nothing failed to parse.
    assert (result.returncode, result.out, result.err) == (0, "", "")
    assert (tmp_path / "rec.sh").read_text() == "if foo; then; fi\n"


def test_recovered_diff_keeps_the_missing_newline_marker(run):
    """-d on a recovered program marks the lacking final newline."""
    result = run(["--exp.recover=3", "-d"], stdin="if foo")
    # CATCHES: the diff's minus side is the original input without a final
    # newline (so it carries the '\ No newline at end of file' marker) while
    # the plus side is the recovered program, and the status is 1.
    assert result.returncode == 1
    assert result.err == ""
    assert result.out == (
        "diff <standard input>.orig <standard input>\n"
        "--- <standard input>.orig\n"
        "+++ <standard input>\n"
        "@@ -1,1 +1,1 @@\n"
        "-if foo\n"
        "\\ No newline at end of file\n"
        "+if foo; then; fi\n"
    )


def test_recovery_does_not_disable_editorconfig(run, write):
    """--exp.recover is not a formatting flag, so EditorConfig still applies."""
    write(".editorconfig",
          "root = true\n\n[*]\nindent_style = space\nindent_size = 2\n")
    result = run(["--exp.recover=3", "--filename=probe.sh"],
                 stdin="if foo; then\nbar")
    # CATCHES: the missing 'fi' is recovered AND the two-space indent from
    # the config is applied to the result, proving the experimental parser
    # flag does not turn EditorConfig lookups off the way -i or -s would.
    assert (result.returncode, result.out, result.err) == (
        0, "if foo; then\n  bar\nfi\n", "")
    unrecovered = run(["--filename=probe.sh"], stdin="if foo; then\nbar")
    # CATCHES: without the flag the same input fails with the unterminated
    # 'if' diagnostic, so the recovered output above is not what a plain
    # parse produces.
    assert (unrecovered.returncode, unrecovered.out, unrecovered.err) == (
        1, "", "probe.sh:1:1: `if` statement must end with `fi`\n")


def test_unrecoverable_syntax_still_fails(run):
    """A stray ')' is not a missing token, so recovery cannot help it."""
    recovered = run(["--exp.recover=3"], stdin="badsyntax)")
    plain = run([], stdin="badsyntax)")
    # CATCHES: only mandatory tokens that are absent can be recovered; an
    # unexpected extra token fails identically with and without the flag.
    assert (recovered.returncode, recovered.out, recovered.err) == (
        1, "",
        "<standard input>:1:10: a command can only contain words and "
        "redirects; encountered `)`\n")
    assert (plain.returncode, plain.out, plain.err) == (
        recovered.returncode, recovered.out, recovered.err)


RECOVERED_JSON = """\
{
	"Type": "File",
	"Pos": {
		"Offset": 0,
		"Line": 1,
		"Col": 1
	},
	"Stmts": [
		{
			"Pos": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			},
			"Cmd": {
				"Type": "CallExpr",
				"Pos": {
					"Offset": 0,
					"Line": 1,
					"Col": 1
				},
				"Args": [
					{
						"Pos": {
							"Offset": 0,
							"Line": 1,
							"Col": 1
						},
						"Parts": [
							{
								"Type": "SglQuoted",
								"Pos": {
									"Offset": 0,
									"Line": 1,
									"Col": 1
								},
								"Left": {
									"Offset": 0,
									"Line": 1,
									"Col": 1
								}
							}
						]
					}
				]
			},
			"Position": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			}
		}
	]
}
"""


def test_recovered_trees_can_be_dumped_as_json(run):
    """--to-json dumps the recovered tree, including its bare nodes."""
    result = run(["--exp.recover=3", "--to-json"], stdin="'i")
    # CATCHES: the recovered single-quoted word prints as '' but its JSON
    # node is a SglQuoted with only a Left position — no End and no Value —
    # which is how a wrong reconstruction (e.g. inventing an End) shows up.
    assert result.returncode == 0
    assert result.err == ""
    assert result.stdout == RECOVERED_JSON.encode()
