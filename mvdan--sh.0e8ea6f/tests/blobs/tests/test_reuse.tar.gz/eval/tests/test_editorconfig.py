"""EditorConfig-driven formatting, ported from the native editorconfig.txtar
CLI test script of the reference repository.

Every tree, .editorconfig content and expected byte string below was recorded
by running the reference binary. The general rules pinned here: options are
read from the nearest .editorconfig files (merged, nearest wins), any parser
or printer flag on the command line disables the lookups entirely, and
"ignore = true" sections skip files found while walking directories.
"""

import textwrap

import pytest

# The root config used by most tests: three-space indentation for everything.
ROOT_CONFIG = textwrap.dedent("""\
    root = true

    [*]
    indent_style = space
    indent_size = 3
    """)

# A root config that also pins a dialect for one filename pattern.
DIALECT_CONFIG = textwrap.dedent("""\
    root = true

    [*]
    indent_style = space
    indent_size = 3

    [*_posix.sh]
    language_dialect = posix
    """)

# ignore rules, as used by the native walk section of editorconfig.txtar.
IGNORE_CONFIG = textwrap.dedent("""\
    root = true

    [third_party/**]
    ignore = true

    [1_lone_ignored.sh]
    ignore = true

    [2_dir_ignored]
    ignore = true
    """)

# One printer knob per test: the property text, an input written in the
# opposite style, and the output the reference binary produced for it.
PRINTER_KNOBS = [
    pytest.param("binary_next_line = true", "foo |\n\tbar\n",
                 "foo \\\n\t| bar\n", id="binary-next-line"),
    pytest.param("case_indent = true", 'case "$1" in\nA) echo foo ;;\nesac\n',
                 'case "$1" in\n\tA) echo foo ;;\nesac\n', id="case-indent"),
    pytest.param("switch_case_indent = true", 'case "$1" in\nA) echo foo ;;\nesac\n',
                 'case "$1" in\n\tA) echo foo ;;\nesac\n', id="switch-case-indent"),
    pytest.param("switch_case_indent = true\ncase_indent = false",
                 'case "$1" in\nA) echo foo ;;\nesac\n',
                 'case "$1" in\nA) echo foo ;;\nesac\n', id="case-indent-false-wins"),
    pytest.param("space_redirects = true", "echo foo >bar\n",
                 "echo foo > bar\n", id="space-redirects"),
    pytest.param("keep_padding = true", "echo  foo    bar\n",
                 "echo  foo    bar\n", id="keep-padding"),
    pytest.param("function_next_line = true", "foo() {\n\techo foo\n}\n",
                 "foo()\n{\n\techo foo\n}\n", id="function-next-line"),
    pytest.param("block_next_line = true",
                 "foo() {\n\tbar\n\tbaz\n}\n\nif cond; then\n\tfoo\nfi\n\n"
                 "for i in a b; do\n\tfoo\ndone\n",
                 "foo()\n{\n\tbar\n\tbaz\n}\n\nif cond\nthen\n\tfoo\nfi\n\n"
                 "for i in a b\ndo\n\tfoo\ndone\n", id="block-next-line"),
    pytest.param("minify = true", "foo() {\n\techo foo\n}\n",
                 "foo(){\necho foo\n}\n", id="minify"),
]

# Dialect knobs: the property text, a program only valid in that dialect
# (written slightly off canonical form) and the canonical output.
DIALECT_KNOBS = [
    pytest.param("language_dialect = bash", "#!/bin/sh\narray=( elem )\n",
                 "#!/bin/sh\narray=(elem)\n", id="language-dialect-bash"),
    pytest.param("language_dialect = mksh", "#!/bin/sh\ncoprocess  |&\n",
                 "#!/bin/sh\ncoprocess |&\n", id="language-dialect-mksh"),
    pytest.param("shell_variant = mksh", "#!/bin/sh\ncoprocess  |&\n",
                 "#!/bin/sh\ncoprocess |&\n", id="shell_variant-mksh"),
    pytest.param("shell_variant = posix\nlanguage_dialect = mksh",
                 "#!/bin/sh\ncoprocess  |&\n",
                 "#!/bin/sh\ncoprocess |&\n",
                 id="language-dialect-beats-shell_variant"),
]


def test_stdin_uses_editorconfig_indent(run, write):
    """Standard input is formatted with the nearest config's options."""
    write(".editorconfig", ROOT_CONFIG)
    result = run([], stdin="{\n\tindented\n}\n")
    # CATCHES: stdin is looked up as a file in the working directory, so the
    # three-space indent reaches a program that was never given a path.
    assert (result.returncode, result.out, result.err) == (
        0, "{\n   indented\n}\n", "")


def test_file_argument_uses_editorconfig_indent(run, write):
    """A file argument picks up the same options as standard input."""
    write(".editorconfig", ROOT_CONFIG)
    write("input.sh", "{\n\tindented\n}\n")
    result = run(["input.sh"])
    # CATCHES: the lookup follows the file's own directory, so an explicit
    # path is formatted with the same three spaces as the stdin form.
    assert (result.returncode, result.out, result.err) == (
        0, "{\n   indented\n}\n", "")


def test_list_under_editorconfig_reports_the_differing_file(run, write):
    """-l compares against the EditorConfig form, not the default one."""
    write(".editorconfig", ROOT_CONFIG)
    write("input.sh", "{\n\tindented\n}\n")
    result = run(["-l", "input.sh"])
    # CATCHES: the file only differs once the three-space indent is applied,
    # so a program ignoring EditorConfig would exit 0 and print nothing.
    assert (result.returncode, result.out, result.err) == (1, "input.sh\n", "")


def test_an_equivalent_indent_flag_matches_the_config(run, write):
    """-i=3 reproduces the config's output byte for byte."""
    write(".editorconfig", ROOT_CONFIG)
    write("input.sh", "{\n\tindented\n}\n")
    via_config = run(["input.sh"])
    via_flag = run(["-i=3", "input.sh"])
    # CATCHES: the config's indent_size=3 is the same knob as -i=3, so the
    # two invocations agree; this anchors the three-space expectation.
    assert via_config.returncode == via_flag.returncode == 0
    assert via_config.stdout == via_flag.stdout == b"{\n   indented\n}\n"


@pytest.mark.parametrize("flags", [
    ["-p"], ["-sr"], ["-i=0"], ["-bn"], ["-ci"], ["-kp"], ["-fn"], ["-bl"],
    ["-s"], ["-ln=bash"], ["-ln=posix"], ["--posix"], ["--indent=0"],
    ["--simplify"], ["--keep-padding"], ["--space-redirects"],
    ["--binary-next-line"], ["--case-indent"], ["--func-next-line"],
    ["--block-next-line"], ["--language-dialect=bash"],
])
def test_any_formatting_flag_disables_editorconfig(run, write, flags):
    """Using any parser or printer flag skips the EditorConfig lookups."""
    write(".editorconfig", ROOT_CONFIG)
    write("input.sh", "{\n\tindented\n}\n")
    result = run([*flags, "input.sh"])
    # CATCHES: every option flag, in either spelling, turns the whole
    # feature off, so the output falls back to the default tab indent.
    assert (result.returncode, result.out, result.err) == (
        0, "{\n\tindented\n}\n", "")


def test_nested_config_overrides_and_merges(run, write):
    """A nearer config wins per-property while keeping the parent's others."""
    write(".editorconfig", ROOT_CONFIG)
    write("morespaces/.editorconfig", "[*.sh]\nindent_size = 6\n")
    write("morespaces/input.sh", "{\n\tindented\n}\n")
    result = run(["morespaces/input.sh"])
    # CATCHES: the nearer file overrides indent_size only; indent_style
    # still comes from the parent, so the result is six spaces, not tabs.
    assert (result.returncode, result.out, result.err) == (
        0, "{\n      indented\n}\n", "")


def test_indent_style_alone_defaults_to_eight_spaces(run, write):
    """indent_style = space without a size falls back to eight columns."""
    write(".editorconfig", "root = true\n\n[a.sh]\nindent_style = space\n")
    write("a.sh", "{\nindented\n}\n")
    result = run(["a.sh"])
    # CATCHES: the size default is eight, matching a hardware tab stop,
    # rather than the CLI default of an actual tab character.
    assert (result.returncode, result.out, result.err) == (
        0, "{\n        indented\n}\n", "")


def test_indent_size_alone_keeps_tabs(run, write):
    """indent_size on its own does not switch the indentation to spaces."""
    write(".editorconfig", "root = true\n\n[a.sh]\nindent_size = 5\n")
    write("a.sh", "{\nindented\n}\n")
    result = run(["a.sh"])
    # CATCHES: only indent_style selects the unit, so a lone indent_size is
    # ignored and the default tab indent is kept.
    assert (result.returncode, result.out, result.err) == (
        0, "{\n\tindented\n}\n", "")


@pytest.mark.parametrize("property_text,source,want", DIALECT_KNOBS)
def test_dialect_knobs_override_the_shebang(run, write, property_text,
                                            source, want):
    """A dialect property replaces the language the shebang announced."""
    write(".editorconfig", "root = true\n\n[d.sh]\n%s\n" % property_text)
    write("d.sh", source)
    result = run(["d.sh"])
    # CATCHES: the #!/bin/sh shebang would parse the file as POSIX shell
    # where '|&' and arrays are invalid, so the property must win for this
    # to succeed and print the canonical dialect-specific form.
    assert (result.returncode, result.out, result.err) == (0, want, "")


def test_without_a_dialect_property_the_shebang_wins(run, write):
    """An empty section leaves the shebang-detected POSIX dialect in place."""
    write(".editorconfig", "root = true\n\n[d.sh]\n")
    write("d.sh", "#!/bin/sh\ncoprocess |&\n")
    result = run(["d.sh"])
    # CATCHES: a section that sets nothing changes nothing, so the mksh-only
    # coprocess operator fails to parse and is reported on stderr.
    assert (result.returncode, result.out, result.err) == (
        1, "", "d.sh:2:11: `|` must be followed by a statement\n")


def test_bash_arrays_fail_without_the_bash_dialect(run, write):
    """The same control with bash syntax names the fallback dialect."""
    write(".editorconfig", "root = true\n\n[d.sh]\n")
    write("d.sh", "#!/bin/sh\narray=(elem)\n")
    result = run(["d.sh"])
    # CATCHES: the diagnostic says which dialect was used and that it came
    # from the auto-detection, not from an EditorConfig property.
    assert (result.returncode, result.out, result.err) == (
        1, "", "d.sh:2:7: arrays are a bash/mksh/zsh feature; "
               "tried parsing as posix (parsed as posix via -ln=auto)\n")


def test_filename_patterns_apply_to_stdin_names(run, write):
    """-filename lets the config's filename patterns match standard input."""
    write(".editorconfig", DIALECT_CONFIG)
    arrays = "array=(\n\telement\n)\n"
    named = run(["-filename=foo_posix.sh"], stdin=arrays)
    # CATCHES: the [*_posix.sh] rule matches the given name, so the arrays
    # are parsed as POSIX shell and the error credits EditorConfig.
    assert (named.returncode, named.out, named.err) == (
        1, "", "foo_posix.sh:1:7: arrays are a bash/mksh/zsh feature; "
               "tried parsing as posix (parsed as posix via EditorConfig)\n")
    unnamed = run([], stdin=arrays)
    # CATCHES: without a name the pattern cannot match, the bash fallback
    # parses the arrays and the root config's three spaces are used.
    assert (unnamed.returncode, unnamed.out, unnamed.err) == (
        0, "array=(\n   element\n)\n", "")


@pytest.mark.parametrize("property_text,source,want", PRINTER_KNOBS)
def test_printer_knobs_rewrite_the_program(run, write, property_text, source,
                                           want):
    """Each printer property reforms the program in its own way."""
    write(".editorconfig", "root = true\n\n[f.sh]\n%s\n" % property_text)
    write("f.sh", source)
    result = run(["f.sh"])
    # CATCHES: the property is applied exactly like its command line flag,
    # turning the opposite-style input into the knob's canonical form.
    assert (result.returncode, result.out, result.err) == (0, want, "")


def test_simplify_property_simplifies(run, write):
    """simplify = true is the EditorConfig spelling of -s."""
    write(".editorconfig", "root = true\n\n[f.sh]\nsimplify = true\n")
    write("f.sh", "$((a + ((b - c))))\n")
    result = run(["f.sh"])
    # CATCHES: the redundant arithmetic parentheses are dropped without any
    # command line flag being given.
    assert (result.returncode, result.out, result.err) == (
        0, "$((a + (b - c)))\n", "")


def test_minify_property_implies_simplify(run, write):
    """minify = true turns on minification and simplification together."""
    write(".editorconfig", "root = true\n\n[f.sh]\nminify = true\n")
    write("f.sh", "$((a + ((b - c))))\n")
    result = run(["f.sh"])
    # CATCHES: minify implies simplify even from a config file, so the
    # spaces go first and the redundant parentheses are dropped as well.
    assert (result.returncode, result.out, result.err) == (
        0, "$((a+(b - c)))\n", "")


@pytest.fixture
def ignored_tree(write):
    """The ignore-rule tree used by the native walk section."""
    write(".editorconfig", ROOT_CONFIG)
    write("ignored/.editorconfig", IGNORE_CONFIG)
    write("ignored/third_party/bad_syntax_ignored.sh", "bad (syntax\n")
    write("ignored/1_lone_ignored.sh", "echo   foo\n")
    write("ignored/2_dir_ignored/ignored.sh", "echo   foo\n")
    write("ignored/3_regular/regular.sh", "echo   foo\n")


def test_walking_skips_files_matching_ignore_rules(run, ignored_tree):
    """Files and directories with ignore = true are skipped while walking."""
    result = run(["-l", "ignored"])
    # CATCHES: only the file with no matching rule is listed; the ignored
    # directory, the ignored file and the broken file under third_party/**
    # are all left alone, including its parse error.
    assert (result.returncode, result.out, result.err) == (
        1, "ignored/3_regular/regular.sh\n", "")


def test_ignore_rules_survive_formatting_flags(run, ignored_tree):
    """A formatting flag skips the options but not the ignore rules."""
    result = run(["-l", "-i=0", "ignored"])
    # CATCHES: -i=0 disables every EditorConfig option, yet the ignore
    # rules still hide the same two files from the walk.
    assert (result.returncode, result.out, result.err) == (
        1, "ignored/3_regular/regular.sh\n", "")


def test_explicit_arguments_ignore_the_ignore_rules(run, ignored_tree):
    """Naming a file directly formats it even if a rule would skip it."""
    result = run(["-l", "ignored/1_lone_ignored.sh",
                  "ignored/3_regular/regular.sh",
                  "ignored/third_party/bad_syntax_ignored.sh"])
    # CATCHES: explicit paths are exempt from ignore rules, so all three are
    # processed in argument order; the broken one reports the parser's
    # generic "foo(" wording even though its own word is "bad (syntax".
    assert result.returncode == 1
    assert result.out == ("ignored/1_lone_ignored.sh\n"
                          "ignored/3_regular/regular.sh\n")
    assert result.err == (
        "ignored/third_party/bad_syntax_ignored.sh:1:1: "
        "`foo(` must be followed by `)`\n")


def test_apply_ignore_extends_the_rules_to_explicit_arguments(run,
                                                              ignored_tree):
    """--apply-ignore makes explicit arguments obey ignore = true too."""
    result = run(["--apply-ignore", "-l", "ignored/1_lone_ignored.sh",
                  "ignored/3_regular/regular.sh",
                  "ignored/third_party/bad_syntax_ignored.sh"])
    # CATCHES: the flag restores the walk-time behaviour for named paths,
    # so only the regular file is listed and no parse error is reported.
    assert (result.returncode, result.out, result.err) == (
        1, "ignored/3_regular/regular.sh\n", "")


def test_apply_ignore_hides_ignored_files_from_the_output(run, ignored_tree):
    """--apply-ignore also drops ignored files from plain formatting."""
    result = run(["--apply-ignore", "ignored/1_lone_ignored.sh",
                  "ignored/3_regular/regular.sh"])
    # CATCHES: without the flag both files are printed, so a single
    # "echo foo" line can only mean the ignored file was dropped.
    assert (result.returncode, result.out, result.err) == (
        0, "echo foo\n", "")


@pytest.mark.parametrize("name,dialect,indented", [
    ("binsh", "sh", "  indented"),
    ("binbash", "bash", "    indented"),
    ("binzsh", "zsh", "     indented"),
])
def test_language_sections_match_the_shebang_dialect(run, write, name,
                                                     dialect, indented):
    """[[shell]], [[bash]] and [[zsh]] sections follow the detected dialect."""
    write(".editorconfig", textwrap.dedent("""\
        root = true

        [*]
        indent_style = space
        indent_size = 1

        [[shell]]
        indent_size = 2

        [[bash]]
        indent_size = 4

        [[zsh]]
        indent_size = 5
        """))
    write("shebang/" + name, "#!/bin/%s\n\n{\n indented\n}\n" % dialect)
    result = run(["shebang/" + name])
    # CATCHES: the extension-less scripts are matched by their shebang's
    # dialect section, each with its own indent size rather than the
    # one-space default of the plain [*] section.
    assert (result.returncode, result.out, result.err) == (
        0, "#!/bin/%s\n\n{\n%s\n}\n" % (dialect, indented), "")


def test_sibling_configs_do_not_leak_into_each_other(run, write):
    """Two configs in sibling directories only apply to their own files."""
    write(".editorconfig", ROOT_CONFIG)
    write("mc/sr/.editorconfig", "[*]\nspace_redirects = true\n")
    write("mc/sr/f.sh", "foo >bar\n")
    write("mc/bn/.editorconfig", "[*]\nbinary_next_line = true\n")
    write("mc/bn/f.sh", "foo &&\n   bar\n")
    result = run(["mc"])
    # CATCHES: each directory's knob is applied to its own file only, so
    # both are reformatted in place and the concatenated output shows one
    # change per file rather than both knobs in either file.
    assert result.returncode == 0
    assert result.out == "foo \\\n   && bar\nfoo > bar\n"
    assert result.err == ""


def test_sibling_configs_are_not_confused_by_a_shared_walk(run, write):
    """A -d walk diffs each file against its own directory's config."""
    write(".editorconfig", ROOT_CONFIG)
    write("mc/sr/.editorconfig", "[*]\nspace_redirects = true\n")
    write("mc/sr/f.sh", "foo >bar\n")
    write("mc/bn/.editorconfig", "[*]\nbinary_next_line = true\n")
    write("mc/bn/f.sh", "foo &&\n   bar\n")
    result = run(["-d", "mc"])
    # CATCHES: each file is diffed against its own directory's knob, so BOTH
    # report a diff; a walk reusing one config for both files (or a silent
    # no-op binary) prints nothing and exits 0 instead of these two hunks.
    assert result.returncode == 1
    assert result.err == ""
    assert result.out == (
        "diff mc/bn/f.sh.orig mc/bn/f.sh\n"
        "--- mc/bn/f.sh.orig\n"
        "+++ mc/bn/f.sh\n"
        "@@ -1,2 +1,2 @@\n"
        "-foo &&\n"
        "-   bar\n"
        "+foo \\\n"
        "+   && bar\n"
        "diff mc/sr/f.sh.orig mc/sr/f.sh\n"
        "--- mc/sr/f.sh.orig\n"
        "+++ mc/sr/f.sh\n"
        "@@ -1,1 +1,1 @@\n"
        "-foo >bar\n"
        "+foo > bar\n"
    )


def test_bats_files_match_bash_and_shell_sections_only(run, write):
    """A [[bats]] section never matches; bats files use [[bash]] instead."""
    write(".editorconfig", textwrap.dedent("""\
        root = true

        [[bats]]
        indent_style = space
        indent_size = 5

        [[bash]]
        indent_style = space
        indent_size = 2
        """))
    write("t.bats", '#!/usr/bin/env bats\n@test "foo" {\n bar\n}\n')
    result = run(["t.bats"])
    # CATCHES: bats scripts resolve to the [[bash]] and [[shell]] language
    # sections, so the body is indented two spaces and the five-space
    # [[bats]] section is ignored entirely.
    assert (result.returncode, result.out, result.err) == (
        0, '#!/usr/bin/env bats\n@test "foo" {\n  bar\n}\n', "")


def test_mksh_files_match_the_shell_section_only(run, write):
    """A [[mksh]] section never matches; mksh files only use [[shell]]."""
    write(".editorconfig", textwrap.dedent("""\
        root = true

        [[mksh]]
        indent_style = space
        indent_size = 5

        [[shell]]
        indent_style = space
        indent_size = 2
        """))
    write("t.mksh", "if true; then\ncop |&\nfi\n")
    result = run(["t.mksh"])
    # CATCHES: the .mksh extension selects the mksh dialect (so '|&' parses)
    # but only the [[shell]] section applies to it, giving two spaces rather
    # than the five spaces a naive [[mksh]] lookup would produce.
    assert (result.returncode, result.out, result.err) == (
        0, "if true; then\n  cop |&\nfi\n", "")


def test_an_invalid_language_dialect_is_ignored(run, write):
    """An unknown language_dialect value falls back to the detected dialect."""
    write(".editorconfig", textwrap.dedent("""\
        root = true

        [*]
        language_dialect = python
        """))
    write("t.sh", "let a+\n")
    result = run(["t.sh"])
    # CATCHES: the bogus dialect is dropped silently rather than failing the
    # run, so the file still parses as the auto-detected bash and produces
    # bash's plain 'let' diagnostic without any "(parsed as ...)" suffix.
    assert (result.returncode, result.out, result.err) == (
        1, "", "t.sh:1:6: `+` must be followed by an expression\n")
    write("t2.sh", "foo=(bar)\n")
    arrays = run(["t2.sh"])
    # CATCHES: the fallback really is bash — a bash-only array parses fine,
    # which a posix fallback would have rejected.
    assert (arrays.returncode, arrays.out, arrays.err) == (0, "foo=(bar)\n", "")


@pytest.mark.parametrize("size", ["0", "tab"])
def test_indent_size_zero_or_tab_falls_back_to_eight_spaces(run, write,
                                                            size):
    """indent_size values that are not positive numbers keep the 8-space default."""
    write(".editorconfig",
          "root = true\n\n[*]\nindent_style = space\nindent_size = %s\n" % size)
    write("t.sh", "if true; then\nfoo\nfi\n")
    result = run(["t.sh"])
    # CATCHES: indent_style = space alone means eight spaces, and neither
    # indent_size = 0 nor the spec's indent_size = tab spelling counts as a
    # positive size, so neither narrows the indent.
    assert (result.returncode, result.out, result.err) == (
        0, "if true; then\n        foo\nfi\n", "")


def test_apply_ignore_also_covers_standard_input(run, write):
    """--apply-ignore drops stdin whose -filename matches an ignore rule."""
    write(".editorconfig", "root = true\n\n[*.ignored.sh]\nignore = true\n")
    ignored = run(["--apply-ignore", "--filename=x.ignored.sh"], stdin=" foo\n")
    # CATCHES: the ignore rules are consulted for standard input too, so a
    # matching synthetic filename formats to nothing at all with status 0.
    assert (ignored.returncode, ignored.out, ignored.err) == (0, "", "")
    regular = run(["--apply-ignore", "--filename=x.sh"], stdin=" foo\n")
    # CATCHES: a non-matching name is still formatted, proving the empty
    # result above comes from the ignore rule and not from a broken flag.
    assert (regular.returncode, regular.out, regular.err) == (0, "foo\n", "")
    without_flag = run(["--filename=x.ignored.sh"], stdin=" foo\n")
    # CATCHES: without --apply-ignore the matching name formats normally,
    # pinning that stdin is exempt from the ignore rules by default.
    assert (without_flag.returncode, without_flag.out, without_flag.err) == (
        0, "foo\n", "")
