"""Here-document printing edges, recorded from the reference binary.

These shapes pin the printer's heredoc bookkeeping: completing a document
whose input was truncated without a trailing newline, stacking two
documents on one command, reproducing the exact delimiter spelling
(backslashed, or continued over a line escape), and re-indenting <<-bodies
line by line inside an indented block.
"""

import pytest

HEREDOC_EDGES = [
    # The terminator line is printed even though the input never contained
    # one, and the output always ends with a newline.
    pytest.param("cat <<EOF\nbody", "cat <<EOF\nbody\nEOF\n",
                 id="truncated-input-completed"),
    # Two documents on one command keep their order; both terminators are
    # reprinted in sequence.
    pytest.param("cat <<A <<B\n1\nA\n2\nB\n", "cat <<A <<B\n1\nA\n2\nB\n",
                 id="two-stacked-documents"),
    # A backslash-quoted delimiter round-trips with its backslash.
    pytest.param("cat <<\\EOF\nhi\nEOF\n", "cat <<\\EOF\nhi\nEOF\n",
                 id="quoted-delimiter-spelling-kept"),
    # A backslash-newline inside the delimiter word continues it, so the
    # real delimiter is EOFx; the literal EOF line is just body text.
    pytest.param("cat <<EOF\\\nx\nEOF\nEOFx\n", "cat <<EOFx\nEOF\nEOFx\n",
                 id="delimiter-line-continuation"),
]


@pytest.mark.parametrize("source,want", HEREDOC_EDGES)
def test_heredoc_edge_roundtrip(run, source, want):
    """Heredoc headers and bodies print exactly as recorded."""
    result = run(["-ln=bash"], stdin=source)
    # CATCHES: the terminator is synthesised for truncated input, stacked
    # documents stay ordered, the \\-quoted delimiter keeps its backslash
    # and a line-escaped delimiter word is joined onto one line.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, want.encode(), b"")


@pytest.mark.parametrize(
    "source,want",
    [
        # An empty body line is left completely empty — no tabs are added
        # to it — while the surrounding body lines gain one indent level.
        pytest.param("f() {\n\tcat <<-EOF\n\ta\n\n\tb\n\tEOF\n}\n",
                     "f() {\n\tcat <<-EOF\n\t\ta\n\n\t\tb\n\tEOF\n}\n",
                     id="empty-line-not-indented"),
        # A body line already carrying an extra tab keeps it: the printer
        # re-indents relative to the heredoc's nesting level.
        pytest.param("f() {\n\tcat <<-EOF\n\t\tx\n\tEOF\n}\n",
                     "f() {\n\tcat <<-EOF\n\t\tx\n\tEOF\n}\n",
                     id="extra-tab-preserved"),
    ])
def test_heredoc_dash_body_indent(run, source, want):
    """<<- bodies inside a function are re-indented line by line."""
    result = run(["-ln=bash"], stdin=source)
    # CATCHES: re-indentation is per body line — empty lines stay byte
    # empty and lines already deeper keep their depth — while the
    # terminator line itself is not re-indented with the body.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, want.encode(), b"")
