"""Source-level equivalences, ported from the multi-input entries of the
native syntax/filetests_test.go table.

The native suite asserts that many differently written sources parse to the
same syntax tree; through the CLI that shows up as identical printed output
whenever the printer does not preserve the original line breaks, and as
recorded line-preserving output when it does. Every expectation below was
recorded from the reference binary.
"""

import pytest

EQUIV_CASES = [
    # whitespace-only programs all print a single newline
    pytest.param('', '\n', id='empty'),
    pytest.param(' ', '\n', id='spaces-only'),
    pytest.param('\t', '\n', id='tab-only'),
    pytest.param('\n \n', '\n', id='blank-lines-only'),
    pytest.param('\r \r\n', '\n', id='carriage-returns-only'),
    # padding around words disappears
    pytest.param('foo', 'foo\n', id='plain-word'),
    pytest.param('foo ', 'foo\n', id='trailing-space'),
    pytest.param(' foo', 'foo\n', id='leading-space'),
    pytest.param('foo \\\n', 'foo\n', id='dangling-continuation'),
    # separators between statements are normalised to newlines
    pytest.param('foo\nbar', 'foo\nbar\n', id='newline-separated'),
    pytest.param('foo; bar;', 'foo\nbar\n', id='semicolon-separated'),
    pytest.param('foo;bar;', 'foo\nbar\n', id='tight-semicolons'),
    pytest.param('\nfoo\nbar\n', 'foo\nbar\n', id='padded-with-blank-lines'),
    pytest.param('foo\r\nbar\r\n', 'foo\nbar\n', id='crlf-newlines'),
    # escaped newlines inside a word are joined
    pytest.param('foobar', 'foobar\n', id='joined-word'),
    pytest.param('foo\\\nbar', 'foobar\n', id='word-split-by-continuation'),
    pytest.param('foo\\\nba\\\nr', 'foobar\n', id='word-split-twice'),
    # a trailing backslash is escaped when printed
    pytest.param('foo\\', 'foo\\\\\n', id='trailing-backslash-escaped'),
    pytest.param('f\\\noo\\', 'foo\\\\\n', id='split-trailing-backslash'),
    # subshells stay on one line only if the source did
    pytest.param('(foo)', '(foo)\n', id='subshell-one-line'),
    pytest.param('(foo;)', '(foo)\n', id='subshell-semicolon'),
    pytest.param('(\nfoo\n)', '(\n\tfoo\n)\n', id='subshell-multi-line'),
    # if clauses: the printer remembers where the source broke the line
    pytest.param('if a; then b; fi', 'if a; then b; fi\n', id='if-one-line'),
    pytest.param('if a\nthen\nb\nfi', 'if a; then\n\tb\nfi\n', id='if-multi-line'),
    pytest.param('if a \nthen\nb\nfi', 'if a; then\n\tb\nfi\n', id='if-space-before-then'),
    pytest.param('if\x00 a; th\x00en b; \x00fi', 'if a; then b; fi\n', id='if-with-nul-bytes'),
    # keywords may be split by escaped newlines in the source
    pytest.param('while a; do b; done', 'while a; do b; done\n', id='while-one-line'),
    pytest.param('wh\\\nile a; do b; done', 'while\n\ta\ndo b; done\n',
                 id='while-keyword-split'),
    pytest.param('while a\ndo\nb\ndone', 'while a; do\n\tb\ndone\n', id='while-multi-line'),
    # blocks
    pytest.param('{ foo; }', '{ foo; }\n', id='block-one-line'),
    pytest.param('{\nfoo\n}', '{\n\tfoo\n}\n', id='block-multi-line'),
    # word padding and continuations
    pytest.param('foo a b', 'foo a b\n', id='words-spaced'),
    pytest.param(' foo  a  b ', 'foo a b\n', id='words-extra-spaces'),
    pytest.param('foo \\\n a b', 'foo \\\n\ta b\n', id='word-continuation-kept'),
    pytest.param('foo \\\r\n a b', 'foo \\\n\ta b\n', id='word-crlf-continuation'),
]


@pytest.mark.parametrize("source,want", EQUIV_CASES)
def test_sources_print_to_recorded_form(run, source, want):
    """Each recorded source variant prints to its recorded canonical form."""
    result = run([], stdin=source)
    # CATCHES: the printer collapses separator/padding differences but
    # deliberately preserves the author's line breaks inside blocks,
    # subshells and compound words — both sides of that rule are pinned.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("source,want", EQUIV_CASES)
def test_sources_round_trip_stably(run, source, want):
    """Printing the output again yields the very same bytes."""
    result = run([], stdin=want)
    # CATCHES: canonical output is a fixed point even for the line-
    # preserving cases such as '(\nfoo\n)'.
    assert (result.returncode, result.out, result.err) == (0, want, "")
