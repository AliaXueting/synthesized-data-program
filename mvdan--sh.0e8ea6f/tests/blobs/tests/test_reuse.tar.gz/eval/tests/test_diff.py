"""The -d/--diff flag, ported from the native diff.txtar CLI test script.

Every diff body, header spelling and exit status below was recorded by
running the reference binary.
"""

import pytest

STDIN_DIFF = (
    "diff <standard input>.orig <standard input>\n"
    "--- <standard input>.orig\n"
    "+++ <standard input>\n"
    "@@ -1,3 +1,3 @@\n"
    "- foo\n"
    "+foo\n"
    " \n"
    " bar\n"
)

FILE_DIFF = (
    "diff input.sh.orig input.sh\n"
    "--- input.sh.orig\n"
    "+++ input.sh\n"
    "@@ -1,3 +1,3 @@\n"
    "- foo\n"
    "+foo\n"
    " \n"
    " bar\n"
)

COLORED_STDIN_DIFF = (
    "\x1b[1mdiff <standard input>.orig <standard input>\n"
    "--- <standard input>.orig\n"
    "+++ <standard input>\n"
    "\x1b[36m@@ -1,3 +1,3 @@\n"
    "\x1b[31m- foo\n"
    "\x1b[32m+foo\n"
    "\x1b[0m \n"
    " bar\n"
)

EXPANSION_DIFF = (
    "diff two.sh.orig two.sh\n"
    "--- two.sh.orig\n"
    "+++ two.sh\n"
    "@@ -1,1 +1,2 @@\n"
    "-foo; bar\n"
    "+foo\n"
    "+bar\n"
)


@pytest.mark.parametrize("flag", ["-d", "--diff"])
def test_diff_of_stdin_labels_the_standard_input(run, flag):
    """-d on stdin renders a unified diff against '<standard input>'."""
    result = run([flag], stdin=" foo\n\nbar\n")
    # CATCHES: the diff header names the synthetic '.orig' side for stdin
    # and the whole diff goes to stdout with an empty stderr and status 1.
    assert (result.returncode, result.out, result.err) == (1, STDIN_DIFF, "")


def test_diff_of_a_file_argument_labels_the_path(run, write):
    """-d on a file names both diff sides after that path."""
    write("input.sh", " foo\n\nbar\n")
    result = run(["-d", "input.sh"])
    # CATCHES: the file's own path (as given) is used for both sides of
    # the header, suffixed with '.orig' on the minus side only.
    assert (result.returncode, result.out, result.err) == (1, FILE_DIFF, "")


def test_diff_repeats_for_a_repeated_path(run, write):
    """Naming the same file twice prints its diff twice."""
    write("input.sh", " foo\n\nbar\n")
    result = run(["-d", "input.sh", "input.sh"])
    # CATCHES: every explicit argument is diffed independently, so the
    # identical hunk block appears back to back on stdout.
    assert (result.returncode, result.out, result.err) == (1, FILE_DIFF * 2, "")


def test_diff_of_a_directory_only_reports_differing_files(run, write):
    """-d over a directory diffs the messy file and stays silent on the rest."""
    write("messy.sh", " foo\n\nbar\n")
    write("clean.sh", "foo\n")
    result = run(["-d", "."])
    # CATCHES: the already canonical sibling produces no diff at all while
    # the messy one is diffed under its walked path, proving -d on a
    # directory is selective rather than a blanket failure.
    assert result.returncode == 1
    assert result.err == ""
    assert result.out == (
        "diff messy.sh.orig messy.sh\n"
        "--- messy.sh.orig\n"
        "+++ messy.sh\n"
        "@@ -1,3 +1,3 @@\n"
        "- foo\n"
        "+foo\n"
        " \n"
        " bar\n"
    )


def test_diff_hunks_grow_when_the_program_expands(run, write):
    """A one-line program that splits into two lines gets a growing hunk."""
    write("two.sh", "foo; bar\n")
    result = run(["-d", "two.sh"])
    # CATCHES: the hunk header counts -1,1 +1,2 and the single removed
    # line is replaced by two added lines, not one edited line.
    assert (result.returncode, result.out, result.err) == (1, EXPANSION_DIFF, "")


def test_diff_is_colored_when_force_color_is_set(run):
    """FORCE_COLOR=true wraps the diff in ANSI color escapes."""
    result = run(["-d"], stdin=" foo\n\nbar\n",
                 extra_env={"FORCE_COLOR": "true"})
    # CATCHES: only the header, hunk marker and changed lines are colored
    # (bold, cyan, red, green) and a single reset ends the colored run,
    # leaving the unchanged context lines plain.
    assert result.returncode == 1
    assert result.err == ""
    assert result.stdout == COLORED_STDIN_DIFF.encode()


def test_diff_stays_plain_when_force_color_is_empty(run, write):
    """An empty FORCE_COLOR keeps the diff free of escape sequences."""
    write("input.sh", " foo\n\nbar\n")
    result = run(["-d", "input.sh"])
    # CATCHES: color must stay off by default, so no ESC byte appears
    # anywhere in the diff even though the content differs.
    assert b"\x1b" not in result.stdout
    assert (result.returncode, result.out, result.err) == (1, FILE_DIFF, "")


def test_diff_of_a_parse_error_reports_only_the_error(run, write):
    """A file that does not parse yields its diagnostic and no diff."""
    write("bad.sh", "foo(\n")
    result = run(["-d", "bad.sh"])
    # CATCHES: the parse failure aborts that file's diff entirely, the
    # diagnostic goes to stderr and the status is 1.
    assert (result.returncode, result.out, result.err) == (
        1, "", "bad.sh:1:1: `foo(` must be followed by `)`\n")


def test_list_flag_prints_the_path_before_its_diff(run, write):
    """-l -d lists the differing path and then prints its diff."""
    write("input.sh", " foo\n\nbar\n")
    result = run(["-l", "-d", "input.sh"])
    # CATCHES: both reports are produced in one run, the listing line
    # coming first on stdout, and the status stays 1.
    assert result.returncode == 1
    assert result.err == ""
    assert result.out == "input.sh\n" + FILE_DIFF


def test_write_and_diff_report_and_rewrite_together(run, write, tmp_path):
    """-w -d rewrites the file and still prints the diff with status 1."""
    write("input.sh", " foo\n\nbar\n")
    result = run(["-w", "-d", "input.sh"])
    # CATCHES: both actions happen in one run — the unified diff goes to
    # stdout, the file is replaced by the canonical bytes on disk, and the
    # exit status is 1 because -d always reports a difference.
    assert result.returncode == 1
    assert result.err == ""
    assert result.out == FILE_DIFF
    assert (tmp_path / "input.sh").read_text() == "foo\n\nbar\n"


def test_filename_names_the_sides_of_a_stdin_diff(run):
    """--filename relabels both sides of a stdin diff."""
    result = run(["-d", "--filename=x.sh"], stdin=" foo\n\nbar\n")
    # CATCHES: the synthetic filename replaces '<standard input>' in the
    # diff header, so both the '.orig' and plain sides are named after it.
    assert result.returncode == 1
    assert result.err == ""
    assert result.out == STDIN_DIFF.replace("<standard input>", "x.sh")


def test_no_color_beats_the_terminal_check(run):
    """NO_COLOR keeps the diff plain even in a colour-capable environment."""
    result = run(["-d"], stdin=" foo\n\nbar\n", extra_env={"NO_COLOR": "1"})
    # CATCHES: NO_COLOR disables the colours that FORCE_COLOR would
    # otherwise enable, so the diff is byte-identical to the plain one.
    assert result.returncode == 1
    assert result.err == ""
    assert result.stdout == STDIN_DIFF.encode()


def test_a_dumb_terminal_stays_plain(run):
    """TERM=dumb also keeps the diff free of escape sequences."""
    result = run(["-d"], stdin=" foo\n\nbar\n", extra_env={"TERM": "dumb"})
    # CATCHES: TERM=dumb is one of the recognised "never colour" signals,
    # so the output matches the plain diff exactly.
    assert (result.returncode, result.stdout, result.err) == (
        1, STDIN_DIFF.encode(), "")


def test_an_unusual_term_alone_does_not_enable_colour(run):
    """A colour-capable TERM value alone cannot turn colours on."""
    result = run(["-d"], stdin=" foo\n\nbar\n", extra_env={"TERM": "xterm-256color"})
    # CATCHES: only a real terminal check (or FORCE_COLOR) enables colour,
    # so a TERM name by itself leaves the diff plain.
    assert (result.returncode, result.stdout, result.err) == (
        1, STDIN_DIFF.encode(), "")


@pytest.mark.parametrize("extra", [
    {"FORCE_COLOR": "1", "NO_COLOR": "1"},
    {"FORCE_COLOR": "1", "TERM": "dumb"},
])
def test_force_color_wins_over_the_other_variables(run, extra):
    """FORCE_COLOR takes precedence over NO_COLOR and TERM=dumb."""
    result = run(["-d"], stdin=" foo\n\nbar\n", extra_env=extra)
    # CATCHES: FORCE_COLOR is checked first, so even with NO_COLOR set or
    # TERM=dumb the full coloured diff (bold header, cyan hunk marker,
    # red removal, green addition, final reset) is produced.
    assert (result.returncode, result.err) == (1, "")
    assert result.stdout == COLORED_STDIN_DIFF.encode()


def test_an_empty_no_color_is_not_a_disabler(run):
    """NO_COLOR must be non-empty to disable colours."""
    result = run(["-d"], stdin=" foo\n\nbar\n", extra_env={"NO_COLOR": ""})
    # CATCHES: an empty NO_COLOR is ignored (as with FORCE_COLOR), so the
    # plain diff is produced for the same reason as with no variable at
    # all — not because colours were disabled.
    assert (result.returncode, result.stdout, result.err) == (
        1, STDIN_DIFF.encode(), "")


def test_null_separated_listing_precedes_the_diff(run, write):
    """-l=0 -d prints the path with a NUL separator and then the diff."""
    write("input.sh", " foo\n\nbar\n")
    result = run(["-l=0", "-d", "input.sh"])
    # CATCHES: both reports share one run — the NUL-terminated path comes
    # first, the unified diff follows, and the status is 1.
    assert result.returncode == 1
    assert result.err == ""
    assert result.stdout == b"input.sh\x00" + FILE_DIFF.encode()
