"""The --to-json and --from-json utilities, ported from the native
tojson.txtar CLI test script of the reference repository.

The JSON dumps are byte-for-byte recordings of the reference binary's
output; note that it indents nested objects and arrays with tabs.
"""

EMPTY_JSON = '{\n\t"Type": "File"\n}\n'

SIMPLE_JSON = """\
{
	"Type": "File",
	"Pos": {
		"Offset": 0,
		"Line": 1,
		"Col": 1
	},
	"End": {
		"Offset": 3,
		"Line": 1,
		"Col": 4
	},
	"Stmts": [
		{
			"Pos": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			},
			"End": {
				"Offset": 3,
				"Line": 1,
				"Col": 4
			},
			"Cmd": {
				"Type": "CallExpr",
				"Pos": {
					"Offset": 0,
					"Line": 1,
					"Col": 1
				},
				"End": {
					"Offset": 3,
					"Line": 1,
					"Col": 4
				},
				"Args": [
					{
						"Pos": {
							"Offset": 0,
							"Line": 1,
							"Col": 1
						},
						"End": {
							"Offset": 3,
							"Line": 1,
							"Col": 4
						},
						"Parts": [
							{
								"Type": "Lit",
								"Pos": {
									"Offset": 0,
									"Line": 1,
									"Col": 1
								},
								"End": {
									"Offset": 3,
									"Line": 1,
									"Col": 4
								},
								"ValuePos": {
									"Offset": 0,
									"Line": 1,
									"Col": 1
								},
								"ValueEnd": {
									"Offset": 3,
									"Line": 1,
									"Col": 4
								},
								"Value": "foo"
							}
						]
					}
				]
			},
			"Position": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			}
		}
	]
}
"""

COMMENT_JSON = """\
{
	"Type": "File",
	"Pos": {
		"Offset": 0,
		"Line": 1,
		"Col": 1
	},
	"End": {
		"Offset": 1,
		"Line": 1,
		"Col": 2
	},
	"Last": [
		{
			"Pos": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			},
			"End": {
				"Offset": 1,
				"Line": 1,
				"Col": 2
			},
			"Hash": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			}
		}
	]
}
"""


def test_to_json_of_the_empty_program(run):
    """An empty stdin dumps the minimal File node."""
    result = run(["--to-json"], stdin=b"")
    # CATCHES: the empty program has no Pos/End/Stmts fields at all, so
    # the dump is exactly three lines and exits 0.
    assert (result.returncode, result.out, result.err) == (0, EMPTY_JSON, "")


def test_to_json_of_a_single_call(run):
    """One call statement dumps its positions, args and literal parts."""
    result = run(["--to-json"], stdin="foo\n")
    # CATCHES: every node carries Pos/End and the literal word also has
    # ValuePos/ValueEnd plus the quoted value, all tab-indented.
    assert result.returncode == 0
    assert result.err == ""
    assert result.stdout == SIMPLE_JSON.encode()


def test_to_json_of_a_lone_comment(run):
    """A comment-only program only fills the Last (comments) field."""
    result = run(["--to-json"], stdin="#\n")
    # CATCHES: comments live in a trailing "Last" array with a lone "Hash"
    # position, and no Stmts array is emitted.
    assert result.returncode == 0
    assert result.err == ""
    assert result.stdout == COMMENT_JSON.encode()


def test_old_tojson_flag_name_matches_the_new_one(run):
    """-tojson is the old spelling of --to-json."""
    old = run(["-tojson"], stdin="foo\n")
    new = run(["--to-json"], stdin="foo\n")
    # CATCHES: both spellings produce byte-identical dumps and neither
    # writes anything to stderr.
    assert old.returncode == new.returncode == 0
    assert old.stderr == new.stderr == b""
    assert old.stdout == new.stdout == SIMPLE_JSON.encode()


def test_to_json_ignores_printer_flags(run):
    """-i does not change the JSON dump, which is tab-indented regardless."""
    plain = run(["--to-json"], stdin="{\nfoo\n}\n")
    indented = run(["--to-json", "-i=4"], stdin="{\nfoo\n}\n")
    # CATCHES: the tree dump is never reformatted by printer options, so
    # a four-space indent request leaves the tab-indented JSON untouched.
    assert plain.returncode == indented.returncode == 0
    assert plain.stdout == indented.stdout
    assert b"\t" in plain.stdout


def test_from_json_round_trips_to_the_canonical_form(run):
    """--to-json output fed back into --from-json prints the program."""
    tree = run(["--to-json"], stdin=" foo;  bar\n")
    result = run(["--from-json"], stdin=tree.stdout)
    # CATCHES: the decoded tree prints in canonical form, splitting the
    # semicolon list into two lines even though the JSON preserved the
    # original one-line source positions.
    assert (result.returncode, result.out, result.err) == (0, "foo\nbar\n", "")


def test_from_json_honours_printer_flags(run):
    """Printer options still apply when printing a decoded tree."""
    tree = run(["--to-json"], stdin="{\nfoo\n}\n")
    spaces = run(["--from-json", "-i=4"], stdin=tree.stdout)
    minified = run(["--from-json", "-mn"], stdin=tree.stdout)
    # CATCHES: -i=4 turns the tab indent into four spaces and -mn strips
    # the newlines inside the block, so JSON is only a transport format.
    assert (spaces.returncode, spaces.out, spaces.err) == (
        0, "{\n    foo\n}\n", "")
    assert (minified.returncode, minified.out, minified.err) == (
        0, "{\nfoo\n}\n", "")


def test_from_json_accepts_a_lone_dash_argument(run):
    """'-' is accepted alongside --from-json and still reads stdin."""
    tree = run(["--to-json"], stdin=" foo;  bar\n")
    result = run(["--from-json", "-"], stdin=tree.stdout)
    # CATCHES: the dash does not disable stdin mode for --from-json the
    # way a real path argument would.
    assert (result.returncode, result.out, result.err) == (0, "foo\nbar\n", "")


def test_from_json_rejects_non_json_input(run):
    """Feeding a shell program to --from-json fails with the JSON decoder."""
    result = run(["--from-json"], stdin="foo\n")
    # CATCHES: the raw Go encoding/json diagnostic is surfaced unchanged
    # on stderr with status 1 and nothing on stdout.
    assert (result.returncode, result.out, result.err) == (
        1, "", "invalid character 'o' in literal false (expecting 'a')\n")


def test_to_json_reports_parse_errors_without_a_path_label(run):
    """A parse error in --to-json mode is not prefixed by a file name."""
    result = run(["--to-json"], stdin="foo(\n")
    # CATCHES: the tree dump fails at parse time and the diagnostic is
    # printed bare (no '<standard input>:' prefix) with status 1.
    assert (result.returncode, result.out, result.err) == (
        1, "", "1:1: `foo(` must be followed by `)`\n")


SIMPLIFIED_JSON = """\
{
	"Type": "File",
	"Pos": {
		"Offset": 0,
		"Line": 1,
		"Col": 1
	},
	"End": {
		"Offset": 8,
		"Line": 1,
		"Col": 9
	},
	"Stmts": [
		{
			"Pos": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			},
			"End": {
				"Offset": 8,
				"Line": 1,
				"Col": 9
			},
			"Cmd": {
				"Type": "CallExpr",
				"Pos": {
					"Offset": 0,
					"Line": 1,
					"Col": 1
				},
				"End": {
					"Offset": 8,
					"Line": 1,
					"Col": 9
				},
				"Args": [
					{
						"Pos": {
							"Offset": 0,
							"Line": 1,
							"Col": 1
						},
						"End": {
							"Offset": 8,
							"Line": 1,
							"Col": 9
						},
						"Parts": [
							{
								"Type": "SglQuoted",
								"Pos": {
									"Offset": 0,
									"Line": 1,
									"Col": 1
								},
								"End": {
									"Offset": 8,
									"Line": 1,
									"Col": 9
								},
								"Left": {
									"Offset": 0,
									"Line": 1,
									"Col": 1
								},
								"Right": {
									"Offset": 7,
									"Line": 1,
									"Col": 8
								},
								"Value": "fo$o"
							}
						]
					}
				]
			},
			"Position": {
				"Offset": 0,
				"Line": 1,
				"Col": 1
			}
		}
	]
}
"""


def test_to_json_simplifies_the_tree_before_dumping(run):
    """-s simplifies the parsed tree, and the dump reflects the change."""
    result = run(["--to-json", "-s"], stdin='"fo\\$o"\n')
    # CATCHES: the double-quoted word is rewritten into a SglQuoted node
    # before encoding, yet keeps the ORIGINAL source offsets (End 8, Right
    # 7 of the seven-byte input) rather than those of the shorter 'fo$o'.
    assert result.returncode == 0
    assert result.err == ""
    assert result.stdout == SIMPLIFIED_JSON.encode()
    plain = run(["--to-json"], stdin='"fo\\$o"\n')
    # CATCHES: without -s the dump keeps the DblQuoted node with its Lit
    # part, so the simplification above is visible in the JSON itself.
    assert b'"Type": "DblQuoted"' in plain.stdout
    assert b'"Type": "DblQuoted"' not in result.stdout


def test_filename_labels_parse_errors_in_to_json_mode(run):
    """--to-json errors carry the -filename label when one is given."""
    result = run(["--to-json", "--filename=x.sh"], stdin="foo(\n")
    # CATCHES: the JSON mode's default empty label is replaced by the given
    # synthetic filename, so the diagnostic is prefixed with 'x.sh:'.
    assert (result.returncode, result.out, result.err) == (
        1, "", "x.sh:1:1: `foo(` must be followed by `)`\n")


def test_from_json_and_to_json_chain_in_one_run(run):
    """--from-json --to-json re-encodes the decoded tree unchanged."""
    tree = run(["--to-json"], stdin="foo\n")
    result = run(["--from-json", "--to-json"], stdin=tree.stdout)
    # CATCHES: decoding and re-encoding in a single run is an identity for
    # the typed JSON form, byte-identical to the original dump.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == SIMPLE_JSON.encode()
