"""Node-type coverage under -s and parser gates for rare constructs.

Running -s walks the whole tree before printing, so feeding it one
program per node type exercises every branch of the tree walker. The
remaining cases pin parser gates for constructs only some dialects
accept. All expectations were recorded from the reference binary.
"""

import pytest

# One program per walked node type; -s must print the canonical form.
SIMPLIFY_WALK = [
    pytest.param("bash", "if true; then echo a; elif false; then echo b; else echo c; fi\n",
                 "if true; then echo a; elif false; then echo b; else echo c; fi\n",
                 id="if-elif-else"),
    pytest.param("bash", "while true; do echo a; done\n",
                 "while true; do echo a; done\n", id="while"),
    pytest.param("bash", "until false; do echo a; done\n",
                 "until false; do echo a; done\n", id="until"),
    pytest.param("bash", "for x in a b c; do echo $x; done\n",
                 "for x in a b c; do echo $x; done\n", id="for-worditer"),
    pytest.param("bash", "for ((i = 0; i < 10; i++)); do echo $i; done\n",
                 "for ((i = 0; i < 10; i++)); do echo $i; done\n", id="for-cstyle"),
    pytest.param("bash", "case $a in\nx) echo 1 ;;\ny|z) echo 2 ;;\nesac\n",
                 "case $a in\nx) echo 1 ;;\ny | z) echo 2 ;;\nesac\n", id="case"),
    pytest.param("bash", "select x in a b; do echo $x; done\n",
                 "select x in a b; do echo $x; done\n", id="select"),
    pytest.param("bash", "function f {\n\techo\n}\n",
                 "function f {\n\techo\n}\n", id="funcdecl"),
    pytest.param("bash", "(echo a; echo b)\n", "(\n\techo a\n\techo b\n)\n",
                 id="subshell"),
    pytest.param("bash", "{ echo a; echo b; }\n", "{\n\techo a\n\techo b\n}\n",
                 id="block"),
    pytest.param("bash", "((i++))\n", "((i++))\n", id="arithmcmd"),
    pytest.param("bash", "echo $((a + b))\n", "echo $((a + b))\n", id="arithmexp"),
    pytest.param("bash", "[[ -e f && a == b ]]\n", "[[ -e f && a == b ]]\n",
                 id="testclause"),
    pytest.param("bash", "declare -a x=(1 2)\n", "declare -a x=(1 2)\n", id="decl"),
    pytest.param("bash", "local x=1 y=2\n", "local x=1 y=2\n", id="local"),
    pytest.param("bash", "a=(1 2 [3]=4)\n", "a=(1 2 [3]=4)\n", id="array"),
    pytest.param("bash", "ls ?(a|b)*(.txt)\n", "ls ?(a|b)*(.txt)\n", id="extglob"),
    pytest.param("bash", "diff <(a) >(b)\n", "diff <(a) >(b)\n", id="procsubst"),
    pytest.param("bash", "time echo hi\n", "time echo hi\n", id="time"),
    pytest.param("bash", "coproc name { echo; }\n", "coproc name { echo; }\n",
                 id="coproc"),
    pytest.param("bash", "let \"a = 1\" b=2\n", "let \"a = 1\" b=2\n", id="let"),
    pytest.param("bats", "@test \"name\" {\n\techo hi\n}\n",
                 "@test \"name\" {\n\techo hi\n}\n", id="bats-testdecl"),
    pytest.param("bash", "cmd >out 2>>log <<EOF\nbody\nEOF\n",
                 "cmd >out 2>>log <<EOF\nbody\nEOF\n", id="redirects"),
    pytest.param("bash", "# c1\ncmd # c2\n", "# c1\ncmd # c2\n", id="comments"),
    pytest.param("bash", "echo ${a:-b}\n", "echo ${a:-b}\n", id="paramexp-word"),
    pytest.param("zsh", "echo ${a[(r)foo]}\n", "echo ${a[(r)foo]}\n",
                 id="flagsarithm"),
    pytest.param("bash", "a=(\n\t# comment\n\t1\n\t2\n)\n",
                 "a=(\n\t# comment\n\t1\n\t2\n)\n", id="array-comments"),
    pytest.param("bash", "case x in\n# c\na) A ;;\nesac\n",
                 "case x in\n# c\na) A ;;\nesac\n", id="case-comments"),
]


@pytest.mark.parametrize("dialect,source,want", SIMPLIFY_WALK)
def test_simplify_walks_every_node_type(run, dialect, source, want):
    """-s accepts and canonically reprints each node type."""
    result = run(["-ln=%s" % dialect, "-s"], stdin=source)
    # CATCHES: simplification visits every node kind (if/case/select/
    # arrays/extglob/coproc/let/@test...) and none of them may crash it
    # or alter the canonical print.
    assert (result.returncode, result.out, result.err) == (0, want, "")


@pytest.mark.parametrize("dialect,source,want", SIMPLIFY_WALK)
def test_every_node_type_round_trips_through_json(run, dialect, source, want):
    """Each node type also survives the typed-JSON round trip."""
    encoded = run(["-ln=%s" % dialect, "--to-json"], stdin=source)
    assert (encoded.returncode, encoded.err) == (0, "")
    result = run(["--from-json"], stdin=encoded.stdout)
    # CATCHES: the encoder/decoder pair must handle every node kind the
    # parser can produce, not just plain statements.
    assert (result.returncode, result.out, result.err) == (0, want, "")


def test_recovered_backquote_heredoc_prints_dollar_form(run):
    """Recovery prints a backquoted heredoc command as $( ) with a
    reconstructed heredoc."""
    result = run(["-ln=bash", "--exp.recover=1"],
                 stdin="echo `cat << EOF\nbody\n")
    # CATCHES: an unclosed heredoc inside an unclosed backquote is
    # rebuilt as $( ... <<EOF ... EOF ), dropping the backquotes and
    # removing the space in `<< EOF`.
    assert (result.returncode, result.out, result.err) == (
        0, "echo $(\n\tcat <<EOF\nbody\nEOF\n)\n", "")


def test_recovered_closed_backquote_heredoc_matches(run):
    """Closing the backquote afterwards does not change the recovery."""
    result = run(["-ln=bash", "--exp.recover=1"],
                 stdin="echo `cat << EOF\nbody\n`\n")
    # CATCHES: the heredoc still counts as unclosed (EOF never appeared
    # on its own line), so the print matches the open-backquote case.
    assert (result.returncode, result.out, result.err) == (
        0, "echo $(\n\tcat <<EOF\nbody\nEOF\n)\n", "")


def test_unclosed_backquote_without_recovery(run):
    """Without --exp.recover an unclosed backquote is a quoted EOF error."""
    result = run(["-ln=bash", "-"], stdin="echo `cat << EOF\nbody\n")
    # CATCHES: the plain parser reports the unterminated backquote with
    # the `reached EOF without closing quote` wording, not a heredoc
    # error.
    assert (result.returncode, result.out, result.err) == (
        1, "", '<standard input>:1:6: reached EOF without closing quote "`"\n')


# --- parser gates for rare assignment and command forms ----------------------

def test_inline_variables_cannot_be_arrays(run):
    """An array assignment before a command is rejected outright."""
    for source in ("a=(1) cmd\n", "a[0]=1 cmd\n"):
        result = run(["-ln=bash", "-"], stdin=source)
        # CATCHES: only scalar assignments may prefix a command; an array
        # (or indexed) assignment there is an error naming the rule.
        assert (result.returncode, result.out, result.err) == (
            1, "", "<standard input>:1:1: inline variables cannot be arrays\n")


def test_bare_array_assignments_are_fine(run):
    """Array assignments as the whole statement are not inline variables."""
    result = run(["-ln=bash", "-"], stdin="a=(1) b=(2)\n")
    # CATCHES: the inline-variable rule only applies when a command
    # follows; a list of array assignments prints unchanged.
    assert (result.returncode, result.out, result.err) == (0, "a=(1) b=(2)\n", "")


@pytest.mark.parametrize("dialect,want,err", [
    pytest.param("bash", None, "arrays cannot be nested\n", id="bash-rejects"),
    pytest.param("zsh", "a[i]=(1 2)\n", None, id="zsh-accepts"),
])
def test_indexed_array_assignment(run, dialect, want, err):
    """`a[i]=(...)` nests arrays, but only in zsh."""
    result = run(["-ln=%s" % dialect, "-"], stdin="a[i]=(1 2)\n")
    # CATCHES: bash reports `arrays cannot be nested` at the bracket,
    # while zsh keeps the indexed array assignment verbatim.
    if err is None:
        assert (result.returncode, result.out, result.err) == (0, want, "")
    else:
        assert (result.returncode, result.out, result.err) == (
            1, "", "<standard input>:1:5: " + err)


@pytest.mark.parametrize("source,err", [
    pytest.param("a[b] c\n", "`a[b]` must be followed by `=`\n", id="naked-index"),
    pytest.param("a[b]\n", "`a[b]` must be followed by `=`\n", id="lone-index"),
    pytest.param("a[b]+\n", "`a[b]+` must be followed by `=`\n", id="append-no-eq"),
])
def test_indexed_assignment_requires_equals(run, source, err):
    """An indexed name without `=` is reported with its full form."""
    result = run(["-ln=bash", "-"], stdin=source)
    # CATCHES: the message echoes the indexed form, including the `+`
    # when an append assignment was started.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<standard input>:1:1: " + err)


def test_double_paren_in_call_position(run):
    """`((` after a command word is rejected with its own message."""
    result = run(["-ln=bash", "-"], stdin="echo ((1))\n")
    # CATCHES: `((` is reserved for arithmetic commands; in argument
    # position the parser names that rule instead of a generic error.
    assert (result.returncode, result.out, result.err) == (
        1, "",
        "<standard input>:1:6: `((` can only be used to open an "
        "arithmetic cmd\n")


@pytest.mark.parametrize("dialect,want,err", [
    pytest.param("bash", None,
                 "redirects before compound commands are a zsh feature; "
                 "tried parsing as bash\n", id="bash-gate"),
    pytest.param("zsh", "if true; then echo; fi >out\n", None, id="zsh-moves-it"),
])
def test_redirect_before_compound_command(run, dialect, want, err):
    """zsh accepts a leading redirect and reprints it at the end."""
    result = run(["-ln=%s" % dialect, "-"],
                 stdin=">out if true; then echo; fi\n")
    # CATCHES: zsh moves the redirect after the compound command when
    # printing, while bash refuses the form with a dialect gate.
    if err is None:
        assert (result.returncode, result.out, result.err) == (0, want, "")
    else:
        assert (result.returncode, result.out, result.err) == (1, "", "<standard input>:1:1: " + err)
