"""Keyword-parsing errors beyond the ported native tables, recorded from
the reference binary.

These diagnostics fire on the declare/function/@test/for family and on
words that only look like command starts: `[[` with a broken expression,
`((` after a word, a function-call-shaped `foo(...)` that is not zsh
syntax, and a quoted reserved word followed by a stray `)`. Note the
generic placeholder in two messages: the parser blames `foo(` and
`for foo` regardless of the actual word used.
"""

import pytest

KEYWORD_ERRORS = [
    pytest.param("declare 1a=2", [],
                 "1:9: invalid var name", id="declare-bad-name"),
    pytest.param("declare (", [],
                 "1:9: `declare` must be followed by names or assignments",
                 id="declare-paren"),
    pytest.param("function", ["-ln=bash"],
                 "1:1: `function` must be followed by a name",
                 id="function-missing-name"),
    pytest.param("function () { :; }", ["-ln=bash"],
                 "1:1: anonymous functions are a zsh feature; tried parsing as bash",
                 id="anonymous-function-in-bash"),
    pytest.param("function { :; }", ["-ln=posix"],
                 '1:10: the "function" builtin is a bash feature; tried parsing as posix',
                 id="function-builtin-in-posix"),
    pytest.param("@test", ["-ln=bats"],
                 "1:1: `@test` must be followed by a description word",
                 id="bats-test-missing-description"),
    pytest.param("@test \"d\"", ["-ln=bats"],
                 '1:1: `@test "desc"` must be followed by a statement',
                 id="bats-test-missing-body"),
    pytest.param("echo =(a)", ["-ln=bats"],
                 "1:6: `=(` process substitutions are a zsh feature; tried parsing as bats",
                 id="procsub-in-bats"),
    pytest.param("x ((1))", [],
                 "1:3: `((` can only be used to open an arithmetic cmd",
                 id="double-paren-after-word"),
    pytest.param("x (y)", [],
                 "1:1: `foo(` must be followed by `)`",
                 id="call-shaped-word"),
    pytest.param("for x while :; do :; done", [],
                 "1:1: `for foo` must be followed by `in`, `do`, `;`, or a newline",
                 id="for-followed-by-while"),
    pytest.param("for x { b; }", ["-ln=mksh"],
                 "1:1: `for foo` must be followed by `in`, `do`, `;`, or a newline",
                 id="mksh-for-brace-rejected"),
    pytest.param("[[ ( ]]", ["-ln=bash"],
                 "1:4: `(` must be followed by an expression",
                 id="test-paren-then-close"),
    pytest.param("[[ a =b\"b\" ]]", ["-ln=bash"],
                 "1:6: test operator words must consist of a single literal",
                 id="test-operator-two-parts"),
    pytest.param("echo \"if\" )", [],
                 "1:11: a command can only contain words and redirects; encountered `)`",
                 id="quoted-reserved-word-is-a-word"),
]


@pytest.mark.parametrize("source,flags,message", KEYWORD_ERRORS)
def test_keyword_error(run, source, flags, message):
    """Each keyword misfire fails with the recorded diagnostic and status 1."""
    result = run(flags, stdin=source)
    # CATCHES: one distinct message per keyword family, including the
    # placeholder wording (`foo(`, `for foo`) that does not echo the
    # real input, and dialect-gated messages naming both dialects.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", ("<standard input>:" + message + "\n").encode())
