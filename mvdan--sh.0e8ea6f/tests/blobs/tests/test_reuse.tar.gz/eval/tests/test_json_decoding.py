"""Typed-JSON field decoding, recorded from the reference binary.

Each test dumps a real program with --to-json, mutates one field, and
feeds the tree back through --from-json. The mutations pin the decoder's
per-kind type errors (a Go string field refuses booleans, objects and
arrays; the RedirOperator enum refuses numbers; a statement list refuses
an object and a SglQuoted element) and the contrasting cases that are
accepted: a JSON null decodes as an empty string, positions beyond the
bit-packed line/column bounds still print, and a Naked assignment drops
its `=` sign when printed.
"""

import copy
import json

import pytest

# The program dumped and mutated below.
SOURCE = "cat a >b\n"


def _tree(run, source, lang):
    """The --to-json dump of source, decoded to a Python tree."""
    dumped = run(["-ln=" + lang, "--to-json"], stdin=source)
    assert (dumped.returncode, dumped.err) == (0, "")
    return json.loads(dumped.stdout)


def _refeed(run, tree, lang="bash"):
    return run(["--from-json", "-ln=" + lang], stdin=json.dumps(tree))


def _first_literal(tree):
    return tree["Stmts"][0]["Cmd"]["Args"][0]["Parts"][0]


@pytest.mark.parametrize(
    "bad_value,message",
    [
        pytest.param(True, "cannot decode JSON boolean into string\n",
                     id="boolean"),
        pytest.param({}, "cannot decode JSON object into string\n",
                     id="object"),
        pytest.param([], "cannot decode JSON array into string\n",
                     id="array"),
    ])
def test_string_field_rejects_non_strings(run, bad_value, message):
    """A Go string field refuses every non-string JSON kind."""
    tree = _tree(run, SOURCE, "bash")
    _first_literal(tree)["Value"] = bad_value
    result = _refeed(run, tree)
    # CATCHES: the decoder names the JSON kind it found, one message per
    # kind, while the same field accepts strings and nulls — so only the
    # non-string, non-null kinds fail with status 1.
    assert (result.returncode, result.out, result.err) == (1, "", message)


def test_operator_field_rejects_numbers(run):
    """RedirOperator wants its string spelling, not a number."""
    tree = _tree(run, SOURCE, "bash")
    tree["Stmts"][0]["Redirs"][0]["Op"] = 5
    result = _refeed(run, tree)
    # CATCHES: enum fields are typed, so a JSON number is rejected with
    # a message naming both the Go type and that a string is required.
    assert (result.returncode, result.out, result.err) == (
        1, "", "cannot decode JSON number into syntax.RedirOperator; "
               "a string is required\n")


def test_statement_list_rejects_an_object(run):
    """Stmts is a slice, so a JSON object cannot decode into it."""
    tree = _tree(run, SOURCE, "bash")
    tree["Stmts"] = {}
    result = _refeed(run, tree)
    # CATCHES: the slice type is spelled out in the message, which
    # differs from the string-field errors above.
    assert (result.returncode, result.out, result.err) == (
        1, "", "cannot decode JSON object into []*syntax.Stmt\n")


def test_statement_list_rejects_a_word_element(run):
    """An element of Stmts must itself be a statement node."""
    tree = _tree(run, SOURCE, "bash")
    tree["Stmts"].append({"Type": "SglQuoted", "Value": "x"})
    result = _refeed(run, tree)
    # CATCHES: the appended element is decoded as a node first and only
    # then type-asserted, so the error names both node kinds.
    assert (result.returncode, result.out, result.err) == (
        1, "", "cannot decode SglQuoted into *syntax.Stmt\n")


def test_null_value_decodes_as_empty_string(run):
    """Unlike booleans, a JSON null in a string field decodes — to ""."""
    tree = _tree(run, SOURCE, "bash")
    _first_literal(tree)["Value"] = None
    result = _refeed(run, tree)
    # CATCHES: the first word prints as empty but is still there, so the
    # command keeps its leading separator space and prints ` a >b`.
    assert (result.returncode, result.out, result.err) == (0, " a >b\n", "")


@pytest.mark.parametrize("field,value", [
    pytest.param("Line", 300000, id="line-past-bit-width"),
    pytest.param("Col", 16384, id="col-past-bit-width"),
])
def test_positions_beyond_bit_width_still_decode(run, field, value):
    """Lines past 262143 and columns past 16383 decode and print fine."""
    tree = _tree(run, SOURCE, "bash")
    tree["Stmts"][0]["Cmd"]["Pos"][field] = value
    result = _refeed(run, tree)
    # CATCHES: the bit-packed bounds are a printing concern, not a
    # decoding one — only the uint32 range is enforced at decode time,
    # so the program still prints exactly as it parsed.
    assert (result.returncode, result.out, result.err) == (
        0, "cat a >b\n", "")


def test_naked_assignment_prints_without_equals(run):
    """Setting Naked on an assignment drops the `=` when printing."""
    tree = _tree(run, "a[i]=\n", "zsh")
    tree["Stmts"][0]["Cmd"]["Assigns"][0]["Naked"] = True
    result = _refeed(run, tree, "zsh")
    # CATCHES: the JSON flag switches the printed form from `a[i]=` to
    # `a[i]` — the printer consults the node field, not the source text,
    # because the source no longer exists in --from-json mode.
    assert (result.returncode, result.out, result.err) == (0, "a[i]\n", "")


def test_unmutated_tree_round_trips(run):
    """Feeding the untouched dump back prints the original program."""
    tree = _tree(run, SOURCE, "bash")
    # copy just to prove the helper's tree is not mutated by refeeding
    result = _refeed(run, copy.deepcopy(tree))
    # CATCHES: the decode/print cycle is lossless for a plain redirect
    # command — every position and word survives the JSON round trip.
    assert (result.returncode, result.out, result.err) == (
        0, "cat a >b\n", "")
