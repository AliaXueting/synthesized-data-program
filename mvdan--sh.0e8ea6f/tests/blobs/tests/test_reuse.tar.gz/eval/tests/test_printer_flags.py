"""Printer option flags and the simplify/minify modes.

Ported from the printer-flag section of the native flags.txtar CLI test
script and the simplify.txtar script; the goldens below were recorded
from the reference binary.
"""

import textwrap

import pytest

FLAGS_INPUT = textwrap.dedent("""\
    foo() {
    \tbar &&
    \t\tbaz

    \tcase $i in
    \tj)
    \t\tz
    \t\t;;
    \tesac

    \tspace >redirs

    \tkeep    padding
    }
    """)

GOLDEN_INDENT = textwrap.dedent("""\
    foo() {
      bar &&
        baz

      case $i in
      j)
        z
        ;;
      esac

      space >redirs

      keep padding
    }
    """)

GOLDEN_BINARY_NEXT_LINE = textwrap.dedent("""\
    foo() {
    \tbar \\
    \t\t&& baz

    \tcase $i in
    \tj)
    \t\tz
    \t\t;;
    \tesac

    \tspace >redirs

    \tkeep padding
    }
    """)

GOLDEN_CASE_INDENT = textwrap.dedent("""\
    foo() {
    \tbar &&
    \t\tbaz

    \tcase $i in
    \t\tj)
    \t\t\tz
    \t\t\t;;
    \tesac

    \tspace >redirs

    \tkeep padding
    }
    """)

GOLDEN_SPACE_REDIRECTS = textwrap.dedent("""\
    foo() {
    \tbar &&
    \t\tbaz

    \tcase $i in
    \tj)
    \t\tz
    \t\t;;
    \tesac

    \tspace > redirs

    \tkeep padding
    }
    """)

GOLDEN_KEEP_PADDING = textwrap.dedent("""\
    foo() {
    \tbar &&
    \t\tbaz

    \tcase $i in
    \tj)
    \t\tz
    \t\t;;
    \tesac

    \tspace >redirs

    \tkeep  padding
    }
    """)

GOLDEN_FUNC_NEXT_LINE = textwrap.dedent("""\
    foo()
    {
    \tbar &&
    \t\tbaz

    \tcase $i in
    \tj)
    \t\tz
    \t\t;;
    \tesac

    \tspace >redirs

    \tkeep padding
    }
    """)

BLOCKS_INPUT = textwrap.dedent("""\
    foo() {
    \tbar
    \tbaz
    }

    f() { short; }

    if cond; then
    \tfoo
    fi

    for i in a b; do
    \tfoo
    done
    """)

GOLDEN_BLOCK_NEXT_LINE = textwrap.dedent("""\
    foo()
    {
    \tbar
    \tbaz
    }

    f() { short; }

    if cond
    then
    \tfoo
    fi

    for i in a b
    do
    \tfoo
    done
    """)


@pytest.mark.parametrize("spelling", [["-i", "2"], ["--indent", "2"]])
def test_indent_flag_uses_spaces(run, spelling):
    """-i N reformats using N spaces instead of a tab."""
    result = run(spelling, stdin=FLAGS_INPUT)
    # CATCHES: every nesting level becomes exactly N spaces, including
    # inside case clauses, and the short and long spellings agree.
    assert (result.returncode, result.out, result.err) == (0, GOLDEN_INDENT, "")


@pytest.mark.parametrize("spelling", [["-bn"], ["--binary-next-line"]])
def test_binary_next_line_keeps_operators_on_their_own_line(run, spelling):
    """-bn breaks lines before binary operators instead of after them."""
    result = run(spelling, stdin=FLAGS_INPUT)
    # CATCHES: 'bar &&' becomes 'bar \\\n\t\t&& baz' with a line-continuation
    # backslash, while everything else keeps the default layout.
    assert (result.returncode, result.out, result.err) == (
        0, GOLDEN_BINARY_NEXT_LINE, "")


@pytest.mark.parametrize("spelling", [["-ci"], ["--case-indent"]])
def test_case_indent_indents_case_branches(run, spelling):
    """-ci indents the case patterns and their bodies."""
    result = run(spelling, stdin=FLAGS_INPUT)
    # CATCHES: case items move one level right but the closing 'esac'
    # stays at the outer indentation level.
    assert (result.returncode, result.out, result.err) == (0, GOLDEN_CASE_INDENT, "")


@pytest.mark.parametrize("spelling", [["-sr"], ["--space-redirects"]])
def test_space_redirects_adds_a_space_after_operators(run, spelling):
    """-sr prints '> redirs' instead of '>redirs'."""
    result = run(spelling, stdin=FLAGS_INPUT)
    # CATCHES: only the redirect operator spacing changes; the padding of
    # the unrelated 'keep    padding' line is still collapsed.
    assert (result.returncode, result.out, result.err) == (
        0, GOLDEN_SPACE_REDIRECTS, "")


@pytest.mark.parametrize("spelling", [["-kp"], ["--keep-padding"]])
def test_keep_padding_preserves_alignment_spaces(run, spelling):
    """-kp keeps the original column alignment padding."""
    result = run(spelling, stdin=FLAGS_INPUT)
    # CATCHES: 'keep    padding' keeps its run of spaces while every other
    # construct is formatted exactly as without the flag.
    assert (result.returncode, result.out, result.err) == (0, GOLDEN_KEEP_PADDING, "")


@pytest.mark.parametrize("spelling", [["-fn"], ["--func-next-line"]])
def test_func_next_line_moves_the_brace_down(run, spelling):
    """-fn puts the function body brace on its own line."""
    result = run(spelling, stdin=FLAGS_INPUT)
    # CATCHES: only the 'foo() {' header is split into two lines; the
    # remainder of the body layout is untouched.
    assert (result.returncode, result.out, result.err) == (0, GOLDEN_FUNC_NEXT_LINE, "")


@pytest.mark.parametrize("spelling", [["-bl"], ["--block-next-line"]])
def test_block_next_line_splits_every_block_header(run, spelling):
    """-bl puts '{', 'then' and 'do' on their own lines."""
    result = run(spelling, stdin=BLOCKS_INPUT)
    # CATCHES: all multi-line block openers are split, while the single
    # short function 'f() { short; }' is left on one line.
    assert (result.returncode, result.out, result.err) == (0, GOLDEN_BLOCK_NEXT_LINE, "")


SIMPLIFY_INPUT = "foo() {\n\t(( $bar ))\n}\n"
SIMPLIFY_GOLDEN = "foo() {\n\t((bar))\n}\n"
MINIFY_GOLDEN = "foo(){\n((bar))\n}\n"


@pytest.mark.parametrize("spelling", [["-s"], ["--simplify"]])
def test_simplify_flag_removes_redundant_syntax(run, spelling):
    """-s drops the redundant spaces and dollar sign inside (( }))."""
    result = run(spelling, stdin=SIMPLIFY_INPUT)
    # CATCHES: '(( $bar ))' simplifies to '((bar))' — spaces stripped and
    # the parameter expansion replaced by the bare name.
    assert (result.returncode, result.out, result.err) == (0, SIMPLIFY_GOLDEN, "")


@pytest.mark.parametrize("spelling", [["-mn"], ["--minify"]])
def test_minify_flag_collapses_the_program(run, spelling):
    """-mn minifies whitespace and implies -s."""
    result = run(spelling, stdin=SIMPLIFY_INPUT)
    # CATCHES: minify removes all non-essential whitespace including the
    # space in 'foo(){' and still performs the -s simplification.
    assert (result.returncode, result.out, result.err) == (0, MINIFY_GOLDEN, "")


def test_indent_zero_means_tabs(run):
    """-i=0 is the explicit spelling of the default tab indentation."""
    result = run(["-i=0"], stdin=FLAGS_INPUT)
    # CATCHES: zero is a valid value selecting tabs, matching the output
    # produced without any -i flag at all.
    plain = run([], stdin=FLAGS_INPUT)
    assert (result.returncode, result.out) == (0, plain.out)
    assert result.out.startswith("foo() {\n\tbar &&\n")
