"""Dialect-specific shapes: zsh indexes/flags and mksh's statement |&."""

from conftest import guard, run_shfmt


def test_zsh_bare_array_index(tmp_path):
    """zsh's $name[i] form keeps its unbraced shape."""
    # CATCHES: zsh allows an index directly on a parameter without braces;
    # printing it as ${arr[i]} would change the word's dialect meaning.
    res = run_shfmt(["-ln=zsh"], input="echo $arr[i]\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo $arr[i]\n"


def test_zsh_doubled_pre_operators(tmp_path):
    """zsh's explicitly-disabled pre-operators print doubled characters."""
    # CATCHES: the off-state of the ~ and = pre-operators is spelled by
    # doubling the character; collapsing to one would flip the flag on.
    res = run_shfmt(["-ln=zsh"], input="echo ${~~x} ${==x}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${~~x} ${==x}\n"


def test_zsh_subscript_flags(tmp_path):
    """zsh subscript flags like (r) and (I) round-trip everywhere."""
    # CATCHES: the flag parens are kept verbatim in word position, in a
    # braced expansion, and inside arithmetic alike.
    res = run_shfmt(
        ["-ln=zsh"],
        input="echo $foo[(r)x] ${foo[(I)bar]} $((foo[(I)bar]))\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "echo $foo[(r)x] ${foo[(I)bar]} $((foo[(I)bar]))\n"


def test_mksh_pipe_amp_ends_the_statement(tmp_path):
    """mksh parses '|&' as a statement suffix, unlike bash's binary form."""
    # CATCHES: the same bytes mean a coprocess suffix in mksh (next
    # statement on a new line) but a pipe-both operator in bash (single
    # line) — the printer must follow the dialect.
    res = run_shfmt(["-ln=mksh"], input="foo |& bar\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo |&\nbar\n"
    res = run_shfmt([], input="foo |& bar\n", cwd=guard(tmp_path))
    assert res.stdout == "foo |& bar\n"


def test_mksh_pipe_amp_minified(tmp_path):
    """-mn glues mksh's '|&' suffix to its statement."""
    # CATCHES: minify removes the space before the suffix but the following
    # statement still begins on a fresh line.
    res = run_shfmt(["-ln=mksh", "-mn"], input="foo |& bar\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo|&\nbar\n"
