"""Shared helpers for driving the shfmt reference binary as a black box.

Every test in this module formats shell code and compares the exact bytes the
program writes to stdout (or stderr/exit status for argument errors).  The
binary is always resolved through ``PROGRAMGYM_EXECUTABLE`` so that the suite
can be pointed at a re-implementation.
"""

from __future__ import annotations

import functools
import os
import subprocess
import tempfile
from pathlib import Path

# A pinned, minimal environment for every child process: no locale surprises,
# no color codes in diffs, and no variables that could influence formatting.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "TERM": "dumb",
    "NO_COLOR": "1",
}

# Written into the top directory of every test tree so that EditorConfig
# discovery stops there: the tests then never depend on whatever
# .editorconfig files may exist above the temporary directory.
ROOT_GUARD = "root = true\n"


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if ``binary`` is a Go coverage build (it drops covcounters files).

    Probed by running ``--version`` once against a throwaway GOCOVERDIR, so
    the check itself never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="shfmt-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [str(binary), "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def shfmt_path() -> Path:
    """Return the absolute path of the program under test."""
    path = Path(os.environ["PROGRAMGYM_EXECUTABLE"]).resolve()
    # The pipeline's coverage pass sets GOCOVERDIR and points
    # PROGRAMGYM_EXECUTABLE at a cover-instrumented build of the reference,
    # but the pipeline-managed eval/run.sh resets PROGRAMGYM_EXECUTABLE to
    # this module's uninstrumented ./executable before pytest starts, which
    # would silently drop every counter and leave the module's coverage
    # report empty.  During a coverage run, when the assigned binary is not
    # itself instrumented, fall back to the instrumented build staged next
    # to the module workspaces.  Ordinary validation and release runs never
    # set GOCOVERDIR and always run the assigned binary unchanged.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(staged):
            return staged
    return path


def run_shfmt(args, input="", cwd=None, env=None):
    """Run the program under test and return the completed process.

    ``args`` is the argument list (without the program name), ``input`` is fed
    to standard input, and ``cwd`` is the working directory of the child.  A
    fixed environment is used unless ``env`` extends it.
    """
    child_env = dict(CHILD_ENV)
    if env:
        child_env.update(env)
    # Coverage instrumentation hook: the pipeline builds the reference binary
    # with -cover, so GOCOVERDIR must survive the pinned environment for the
    # module's source coverage to be measured.  The value is made absolute
    # because children run inside per-test temporary directories; a relative
    # GOCOVERDIR would be resolved against those directories instead of the
    # pipeline's counter directory, and the cover runtime would then fail to
    # write its counters.
    cov_env = {
        "GOCOVERDIR": os.path.abspath(v)
        for v in [os.environ.get("GOCOVERDIR")]
        if v
    }
    child_env.update(cov_env)
    return subprocess.run(
        [str(shfmt_path()), *[str(a) for a in args]],
        input=input,
        capture_output=True,
        text=True,
        encoding="utf-8",
        cwd=None if cwd is None else str(cwd),
        env=child_env,
        timeout=30,
    )


def lines(*ls):
    """Join lines into the exact text the printer emits, with the final EOL."""
    return "\n".join(ls) + "\n"


def guard(tmp_path, text=ROOT_GUARD):
    """Isolate ``tmp_path`` from ancestor .editorconfig files.

    Writes an .editorconfig with ``root = true`` (and optionally the given
    extra text) at the top of the test tree so that property discovery never
    escapes the temporary directory.
    """
    (tmp_path / ".editorconfig").write_text(text, encoding="utf-8")
    return tmp_path
