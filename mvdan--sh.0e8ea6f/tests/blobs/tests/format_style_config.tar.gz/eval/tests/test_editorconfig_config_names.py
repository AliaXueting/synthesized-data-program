"""Well-known shell config file names select their dialect's language section.

langFromFilename maps names like 'bashrc' or 'zshrc' to a shell dialect
without reading a shebang, so such a file matches the [[bash]] or [[zsh]]
EditorConfig sections (and [[shell]]) — and never the other language's
section.  Every expectation below was recorded from the reference binary.
"""

import pytest

from conftest import guard, run_shfmt

# One nesting level so the winning indent style/size is unambiguous.
NESTED = "if a; then\nb\nfi\n"

# Both language sections style the same body differently: bash uses two
# spaces, zsh uses four.
BOTH_SECTIONS = (
    "root = true\n"
    "[[bash]]\n"
    "indent_style = space\n"
    "indent_size = 2\n"
    "[[zsh]]\n"
    "indent_style = space\n"
    "indent_size = 4\n"
)


def stdin_with_name(tmp_path, name, ec_text=BOTH_SECTIONS, src=NESTED):
    return run_shfmt(["--filename", name], input=src, cwd=guard(tmp_path, ec_text))


@pytest.mark.parametrize("name", ["bashrc", "bash_profile", "bash_logout"])
def test_bash_config_names_select_bash_section(tmp_path, name):
    """Bash's config file names match [[bash]], not [[zsh]]."""
    # CATCHES: the name alone (no extension, no shebang) picks the bash
    # dialect, so its 2-space indent wins over [[zsh]]'s four spaces.
    res = stdin_with_name(tmp_path, name)
    assert res.returncode == 0
    assert res.stdout == "if a; then\n  b\nfi\n"


@pytest.mark.parametrize(
    "name", ["zshenv", "zprofile", "zshrc", "zlogin", "zlogout"]
)
def test_zsh_config_names_select_zsh_section(tmp_path, name):
    """Zsh's five config file names all match the [[zsh]] section."""
    # CATCHES: each of zsh's startup-file spellings maps to the zsh dialect
    # and must pick up [[zsh]]'s 4-space indent, never [[bash]]'s two.
    res = stdin_with_name(tmp_path, name)
    assert res.returncode == 0
    assert res.stdout == "if a; then\n    b\nfi\n"


def test_dot_prefixed_config_name_loses_its_dot(tmp_path):
    """A leading dot is stripped, so '.zshrc' still selects zsh."""
    # CATCHES: the dotfile spelling '.zshrc' is the same config name as
    # 'zshrc' and must match [[zsh]] rather than fall back to bash tabs.
    res = stdin_with_name(tmp_path, ".zshrc")
    assert res.returncode == 0
    assert res.stdout == "if a; then\n    b\nfi\n"


def test_bash_config_name_ignores_zsh_only_section(tmp_path):
    """A bashrc does not pick up properties from a [[zsh]]-only file."""
    # CATCHES: with only a [[zsh]] section present, the bash-dialect
    # 'bashrc' must keep the tab default instead of borrowing zsh's style.
    res = stdin_with_name(
        tmp_path,
        "bashrc",
        ec_text=(
            "root = true\n"
            "[[zsh]]\n"
            "indent_style = space\n"
            "indent_size = 4\n"
        ),
    )
    assert res.returncode == 0
    assert res.stdout == "if a; then\n\tb\nfi\n"


def test_zsh_config_name_ignores_bash_only_section(tmp_path):
    """A zshrc does not pick up properties from a [[bash]]-only file."""
    # CATCHES: with only a [[bash]] section present, the zsh-dialect
    # 'zshrc' must keep the tab default instead of borrowing bash's style.
    res = stdin_with_name(
        tmp_path,
        "zshrc",
        ec_text=(
            "root = true\n"
            "[[bash]]\n"
            "indent_style = space\n"
            "indent_size = 2\n"
        ),
    )
    assert res.returncode == 0
    assert res.stdout == "if a; then\n\tb\nfi\n"


def test_config_name_as_explicit_file_argument(tmp_path):
    """A config-named file on disk is formatted with its dialect's section."""
    # CATCHES: the dialect mapping also drives formatting of real file
    # arguments, not only '--filename' on standard input.
    root = guard(tmp_path, BOTH_SECTIONS)
    (root / "bashrc").write_text(NESTED, encoding="utf-8")
    (root / "zshrc").write_text(NESTED, encoding="utf-8")
    res_bash = run_shfmt(["bashrc"], cwd=root)
    assert res_bash.returncode == 0
    assert res_bash.stdout == "if a; then\n  b\nfi\n"
    res_zsh = run_shfmt(["zshrc"], cwd=root)
    assert res_zsh.returncode == 0
    assert res_zsh.stdout == "if a; then\n    b\nfi\n"
