"""Tests for the -bn/--binary-next-line printer flag."""

from conftest import guard, lines, run_shfmt

CHAIN = "foo &&\n\t$(bar) &&\n\t(more)\n"

PIPE_CHAIN = "foo |\n\tbar |\n\tbaz\n"

SHORT_CHAIN = "true && false || echo hi\n"


def test_binary_next_line_moves_and_operators(tmp_path):
    """-bn starts continuation lines with && and escapes the newline."""
    # CATCHES: the operator moves down and a backslash continues the line
    res = run_shfmt(["-bn"], input=CHAIN, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo \\",
        "\t&& $(bar) \\",
        "\t&& (more)",
    )


def test_binary_next_line_moves_pipe_operators(tmp_path):
    """-bn also applies to pipelines spanning multiple lines."""
    # CATCHES: pipes are binary operators and need the same backslash
    res = run_shfmt(["-bn"], input=PIPE_CHAIN, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo \\",
        "\t| bar \\",
        "\t| baz",
    )


def test_default_keeps_binary_operators_at_line_end(tmp_path):
    """Without -bn the operators stay at the end of the previous line."""
    # CATCHES: the default style must not leak the -bn placement
    res = run_shfmt([], input=CHAIN + PIPE_CHAIN, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo &&",
        "\t$(bar) &&",
        "\t(more)",
        "foo |",
        "\tbar |",
        "\tbaz",
    )


def test_short_binary_chain_stays_on_one_line(tmp_path):
    """-bn never breaks a chain that already fits on a single line."""
    # CATCHES: -bn only reacts to input that already spans multiple lines
    res = run_shfmt(["-bn"], input=SHORT_CHAIN, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == SHORT_CHAIN


def test_binary_next_line_in_test_expression(tmp_path):
    """-bn splits binary operators inside [[ ]] without a backslash."""
    # CATCHES: inside double brackets no backslash escape is needed
    src = '[[ -n $a ||\n\t-z $b ]] && echo hi\n'
    res = run_shfmt(["-bn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "[[ -n $a",
        "\t|| -z $b ]] && echo hi",
    )


def test_binary_next_line_in_arithmetic_command(tmp_path):
    """-bn splits operators inside (( )) and keeps the backslash."""
    # CATCHES: arithmetic commands print without a space after the parens
    src = "if (( x > 1 &&\n\ty < 2 )); then\n\tbar\nfi\n"
    res = run_shfmt(["-bn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "if ((x > 1 \\",
        "\t&& y < 2)); then",
        "\tbar",
        "fi",
    )


def test_binary_next_line_long_form(tmp_path):
    """--binary-next-line is the same option as -bn."""
    # CATCHES: the long spelling must be wired to the same printer knob
    res = run_shfmt(["--binary-next-line"], input=PIPE_CHAIN, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo \\",
        "\t| bar \\",
        "\t| baz",
    )


def test_binary_next_line_with_pipeline_redirect(tmp_path):
    """A redirect on the last pipeline element keeps its place with -bn."""
    # CATCHES: redirects bind to the command, not to the moved operator
    src = "foo 2>&1 |\n\tbar\n"
    res = run_shfmt(["-bn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo 2>&1 \\",
        "\t| bar",
    )
