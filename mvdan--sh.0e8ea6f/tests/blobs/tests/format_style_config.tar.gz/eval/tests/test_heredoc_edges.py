"""Heredoc edge cases: re-indentation, unclosed bodies, delimiters."""

from conftest import guard, lines, run_shfmt


def test_dash_heredoc_body_is_reindented(tmp_path):
    """A <<- body inside a block gains the block's indentation."""
    # CATCHES: <<- strips one tab from the body and then re-indents it one
    # level deeper than the 'cat' line, so the body follows the block.
    res = run_shfmt(
        [],
        input="if true; then\n\tcat <<-EOF\n\tbody\n\tEOF\nfi\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == lines(
        "if true; then",
        "\tcat <<-EOF",
        "\t\tbody",
        "\tEOF",
        "fi",
    )


def test_dash_heredoc_keeps_embedded_tabs(tmp_path):
    """Tabs inside a <<- body line survive as literal content."""
    # CATCHES: only the leading tabs of a body line are re-indentation; the
    # tab between 'body' and 'more' is content and must not be expanded.
    res = run_shfmt(
        [],
        input="if true; then\n\tcat <<-EOF\n\tbody\tmore\n\tEOF\nfi\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == lines(
        "if true; then",
        "\tcat <<-EOF",
        "\t\tbody\tmore",
        "\tEOF",
        "fi",
    )


def test_dash_heredoc_body_with_expansion(tmp_path):
    """A <<- body containing expansions is still re-indented."""
    # CATCHES: the re-indenter sits between the printer and the writer even
    # when the body prints word parts like $x rather than a plain literal.
    res = run_shfmt(
        [],
        input="if true; then\n\tcat <<-EOF\n\t$x y\n\tEOF\nfi\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == lines(
        "if true; then",
        "\tcat <<-EOF",
        "\t\t$x y",
        "\tEOF",
        "fi",
    )


def test_dash_heredoc_blank_line_gets_no_tabs(tmp_path):
    """Blank lines inside a <<- body stay completely empty."""
    # CATCHES: an empty body line must not gain indentation tabs, which
    # would change the heredoc's content bytes.
    res = run_shfmt(
        [],
        input="if true; then\n\tcat <<-EOF\n\ta\n\n\tb\n\tEOF\nfi\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == lines(
        "if true; then",
        "\tcat <<-EOF",
        "\t\ta",
        "",
        "\t\tb",
        "\tEOF",
        "fi",
    )


def test_dash_heredoc_with_space_indent_keeps_body_tabs(tmp_path):
    """With -i spaces a <<- body keeps its original literal tabs."""
    # CATCHES: the tab-stripping re-indenter only runs when indenting with
    # tabs; with spaces the body is copied through verbatim, tabs included.
    res = run_shfmt(
        ["-i=2"],
        input="if true; then\n\tcat <<-EOF\n\tbody\n\tEOF\nfi\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == lines(
        "if true; then",
        "  cat <<-EOF",
        "\tbody",
        "\tEOF",
        "fi",
    )


def test_quoted_delimiter_keeps_trailing_backslash(tmp_path):
    """A quoted delimiter's body is copied without backslash escaping."""
    # CATCHES: the body of a quoted heredoc is printed as a raw literal, so
    # its trailing backslash is not doubled like it would be elsewhere.
    res = run_shfmt(
        [],
        input="cat <<'EOF'\nfoo\\\nEOF\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "cat <<'EOF'\nfoo\\\nEOF\n"


def test_unclosed_heredoc_is_completed(tmp_path):
    """A heredoc cut short by EOF is closed with its delimiter."""
    # CATCHES: the printer appends the missing final newline and prints the
    # delimiter so the output is a complete, re-parseable heredoc.
    res = run_shfmt([], input="cat <<EOF\nfoo", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "cat <<EOF\nfoo\nEOF\n"


def test_escaped_delimiter_closes_unquoted(tmp_path):
    """A backslash-escaped delimiter word closes as its unquoted spelling."""
    # CATCHES: the opening delimiter keeps its backslash, the terminator is
    # the unquoted spelling, and the unterminated body is closed with it.
    res = run_shfmt(
        [],
        input="cat <<E\\OF\nbody\nE\\OF\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "cat <<E\\OF\nbody\nE\\OF\nEOF\n"


def test_heredoc_with_inline_comment(tmp_path):
    """A comment on the heredoc's start line is flushed before the body."""
    # CATCHES: the pending comment must be printed on the heredoc's opening
    # line and never sink into the heredoc body below it.
    res = run_shfmt(
        [],
        input="cat <<EOF # c\nbody\nEOF\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "cat <<EOF # c\nbody\nEOF\n"


def test_nested_heredoc_inside_dash_body(tmp_path):
    """A heredoc inside $() inside a <<- body bypasses the indenter."""
    # CATCHES: the inner heredoc's body and delimiter are written straight
    # to the real writer while the surrounding $( ) is re-indented.
    res = run_shfmt(
        [],
        input=(
            "if true; then\n"
            "\tcat <<-EOF\n"
            "\t$(cat <<INNER\n"
            "hi\n"
            "INNER\n"
            ")\n"
            "\tEOF\n"
            "fi\n"
        ),
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == lines(
        "if true; then",
        "\tcat <<-EOF",
        "\t\t$(",
        "\t\t\tcat <<INNER",
        "hi",
        "INNER",
        "\t\t)",
        "\tEOF",
        "fi",
    )


def test_double_quoted_delimiter_keeps_quotes(tmp_path):
    """A double-quoted delimiter prints with its quotes, unlike 'EOF'."""
    # CATCHES: the terminator line is always the bare word, but the opening
    # delimiter must echo the exact quoting that disabled expansion.
    res = run_shfmt(
        [],
        input='cat <<"EOF"\nfoo\nEOF\n',
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == 'cat <<"EOF"\nfoo\nEOF\n'


def test_backquote_heredoc_becomes_command_substitution(tmp_path):
    """A heredoc terminated by a backquote is reprinted inside $( )."""
    # CATCHES: the closing backquote is converted to a '$(' command
    # substitution, with the heredoc's delimiter printed before the ')'.
    res = run_shfmt(
        [],
        input="x=`cat <<EOF\nfoo\n`\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "x=$(\n\tcat <<EOF\nfoo\nEOF\n)\n"


def test_nested_dash_heredocs_indent_selectively(tmp_path):
    """Heredocs nested inside two '<<-' bodies indent at their own levels."""
    # CATCHES: the innermost plain heredoc's body and delimiter bypass the
    # indenters and land at column zero, while each '<<-' delimiter is
    # re-indented to its own nesting level.
    src = (
        "if true; then\n"
        "\tcat <<-OUTER\n"
        "\t$(\n"
        "\t\tcat <<-INNER\n"
        "\t\t$(cat <<PLAIN\n"
        "hi\n"
        "PLAIN\n"
        ")\n"
        "\t\tINNER\n"
        "\t)\n"
        "\tOUTER\n"
        "fi\n"
    )
    res = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "if true; then",
        "\tcat <<-OUTER",
        "\t\t$(",
        "\t\t\tcat <<-INNER",
        "\t\t\t\t$(",
        "\t\t\t\t\tcat <<PLAIN",
        "hi",
        "PLAIN",
        "\t\t\t\t)",
        "\t\t\tINNER",
        "\t\t)",
        "\tOUTER",
        "fi",
    )
