"""Tests for combinations of several printer flags at once."""

from conftest import guard, lines, run_shfmt


def test_google_style_flags(tmp_path):
    """The documented '-i 2 -ci -bn' Google style combination."""
    # CATCHES: case indent, spaces and binary-next-line must all stack
    src = "case $x in\na)\n\tfoo &&\n\t\tbar\n\t;;\nesac\n"
    res = run_shfmt(["-i=2", "-ci", "-bn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $x in",
        "  a)",
        "    foo \\",
        "      && bar",
        "    ;;",
        "esac",
    )


def test_all_boolean_printer_flags_together(tmp_path):
    """-i, -bn, -ci, -sr, -kp and -bl can all be combined."""
    # CATCHES: keep-padding shifts the moved '{' by the indent size
    src = (
        "foo() {\n"
        "\tif a; then\n"
        "\t\tb\n"
        "\tfi\n"
        "}\n"
        "case $x in\n"
        "a)\n"
        "\tfoo >out\n"
        "\t;;\n"
        "esac\n"
        "foo &&\n"
        "\tbar\n"
    )
    res = run_shfmt(["-i=3", "-bn", "-ci", "-sr", "-kp", "-bl"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo()",
        "      {",
        "   if a",
        "   then",
        "      b",
        "   fi",
        "}",
        "case $x in",
        "   a)",
        "      foo > out",
        "      ;;",
        "esac",
        "foo \\",
        "    && bar",
    )


def test_block_next_line_with_binary_next_line(tmp_path):
    """-bl and -bn together: the operator moves down before 'then'."""
    # CATCHES: the multi-line condition keeps 'then' on its own line
    src = "if foo &&\n\tbar; then\n\tbaz\nfi\n"
    res = run_shfmt(["-bl", "-bn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "if foo \\",
        "\t&& bar",
        "then",
        "\tbaz",
        "fi",
    )


def test_minify_overrides_binary_next_line(tmp_path):
    """-mn wins over -bn: everything is joined onto one line."""
    # CATCHES: minify ignores the binary operator placement entirely
    src = "if foo &&\n\tbar; then\n\tbaz\nfi\n"
    res = run_shfmt(["-mn", "-bn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "if foo&&bar;then",
        "baz",
        "fi",
    )


def test_case_indent_with_block_next_line(tmp_path):
    """-ci and -bl stack inside a case branch."""
    # CATCHES: the inner 'then' moves to its own line at the case level
    src = "case $x in\na)\n\tif b; then\n\t\tc\n\tfi\n\t;;\nesac\n"
    res = run_shfmt(["-ci", "-bl"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $x in",
        "\ta)",
        "\t\tif b",
        "\t\tthen",
        "\t\t\tc",
        "\t\tfi",
        "\t\t;;",
        "esac",
    )


def test_flags_apply_when_formatting_a_file(tmp_path):
    """Printer flags also apply when the input is a file argument."""
    # CATCHES: the file path is not echoed, only the formatted bytes
    root = guard(tmp_path)
    (root / "a.sh").write_text("if foo; then\nbar\nfi\n", encoding="utf-8")
    res = run_shfmt(["-i=4", "a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == lines(
        "if foo; then",
        "    bar",
        "fi",
    )


def test_diff_output_reflects_printer_flags(tmp_path):
    """-d prints a diff that shows the flag's effect and exits 1."""
    # CATCHES: the diff body carries the four-space indentation
    root = guard(tmp_path)
    (root / "a.sh").write_text("if foo; then\nbar\nfi\n", encoding="utf-8")
    res = run_shfmt(["-i=4", "-d", "a.sh"], cwd=root)
    assert res.returncode == 1
    assert res.stderr == ""
    assert res.stdout == lines(
        "diff a.sh.orig a.sh",
        "--- a.sh.orig",
        "+++ a.sh",
        "@@ -1,3 +1,3 @@",
        " if foo; then",
        "-bar",
        "+    bar",
        " fi",
    )


def test_write_flag_applies_printer_flags_in_place(tmp_path):
    """-w rewrites the file on disk using the requested indentation."""
    # CATCHES: stdout stays empty and the file holds the formatted text
    root = guard(tmp_path)
    script = root / "a.sh"
    script.write_text("if foo; then\nbar\nfi\n", encoding="utf-8")
    res = run_shfmt(["-i=4", "-w", "a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert script.read_text(encoding="utf-8") == lines(
        "if foo; then",
        "    bar",
        "fi",
    )


def test_boolean_flags_accept_one_and_zero_spellings(tmp_path):
    """Bool printer flags accept the shell-style 1/0 spellings."""
    # CATCHES: '-ci=1' enables and '-ci=0' disables, like =true/=false
    case_src = "case $x in\na)\n\tA\n\t;;\nesac\n"
    on = run_shfmt(["-ci=1"], input=case_src, cwd=guard(tmp_path))
    assert on.returncode == 0
    assert on.stdout == lines(
        "case $x in",
        "\ta)",
        "\t\tA",
        "\t\t;;",
        "esac",
    )
    off = run_shfmt(["-ci=0"], input=case_src, cwd=guard(tmp_path))
    assert off.returncode == 0
    assert off.stdout == lines(
        "case $x in",
        "a)",
        "\tA",
        "\t;;",
        "esac",
    )
    mini = run_shfmt(["-mn=1"], input="if foo; then\n\tbar\nfi\n", cwd=guard(tmp_path))
    assert mini.returncode == 0
    assert mini.stdout == lines("if foo;then", "bar", "fi")


def test_invalid_boolean_value_is_rejected(tmp_path):
    """A printer bool flag with a bad value is a flag error with usage."""
    # CATCHES: '-bn=maybe' exits 2 with a parse error before reading input
    res = run_shfmt(["-bn=maybe"], input="foo\n", cwd=guard(tmp_path))
    assert res.returncode == 2
    assert res.stdout == ""
    assert 'invalid boolean value "maybe" for -bn: parse error' in res.stderr
    assert "usage: shfmt [flags] [path ...]" in res.stderr


def test_force_color_diff_beats_no_color(tmp_path):
    """FORCE_COLOR wins over NO_COLOR and TERM=dumb in -d output."""
    # CATCHES: the diff is colorized with bold, cyan, red and green codes
    root = guard(tmp_path)
    (root / "a.sh").write_text("if foo; then\nbar\nfi\n", encoding="utf-8")
    res = run_shfmt(["-d", "a.sh"], cwd=root, env={"FORCE_COLOR": "1"})
    assert res.returncode == 1
    assert res.stderr == ""
    assert res.stdout == (
        "\x1b[1mdiff a.sh.orig a.sh\n"
        "--- a.sh.orig\n"
        "+++ a.sh\n"
        "\x1b[36m@@ -1,3 +1,3 @@\n"
        "\x1b[0m if foo; then\n"
        "\x1b[31m-bar\n"
        "\x1b[32m+\tbar\n"
        "\x1b[0m fi\n"
    )
