"""Tests for the -bl/--block-next-line and -fn/--func-next-line flags."""

from conftest import guard, lines, run_shfmt

FUNC = "function foo() {\n\tbar\n}\nbaz() {\n\tqux\n}\n"

LOOPS = "if foo; then\n\tbar\nfi\nfor x in a b; do\n\tbar\ndone\nwhile foo; do\n\tbar\ndone\n"


def test_block_next_line_moves_all_opening_tokens(tmp_path):
    """-bl puts {, then and do on a line of their own."""
    # CATCHES: all three opening tokens move down, not just the brace
    res = run_shfmt(["-bl"], input=FUNC + LOOPS, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "function foo()",
        "{",
        "\tbar",
        "}",
        "baz()",
        "{",
        "\tqux",
        "}",
        "if foo",
        "then",
        "\tbar",
        "fi",
        "for x in a b",
        "do",
        "\tbar",
        "done",
        "while foo",
        "do",
        "\tbar",
        "done",
    )


def test_block_next_line_elif_else(tmp_path):
    """-bl also breaks the line before elif/else branches."""
    # CATCHES: elif gets its own 'then' too while else has no keyword pair
    src = "if a; then\n\tb\nelif c; then\n\td\nelse\n\te\nfi\n"
    res = run_shfmt(["-bl"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "if a",
        "then",
        "\tb",
        "elif c",
        "then",
        "\td",
        "else",
        "\te",
        "fi",
    )


def test_block_next_line_leaves_single_line_blocks_alone(tmp_path):
    """-bl never splits a block that fits on one line."""
    # CATCHES: 'foo() { bar; }' and 'if foo; then bar; fi' stay on one line
    src = "foo() { bar; }\nif foo; then bar; fi\n"
    res = run_shfmt(["-bl"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src


def test_block_next_line_does_not_move_subshell_bodies(tmp_path):
    """A subshell body opens with '(', which -bl leaves where it is."""
    # CATCHES: only '{', 'then' and 'do' are affected, not '('
    src = "foo() (\n\tbar\n)\n"
    res = run_shfmt(["-bl"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src


def test_block_next_line_leaves_case_and_brace_blocks(tmp_path):
    """Bare brace blocks and case statements keep their opening line."""
    # CATCHES: '{' opening a plain block and 'case ... in' are not moved
    src = "{\n\tfoo\n}\ncase $x in\na) A ;;\nesac\n"
    res = run_shfmt(["-bl"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src


def test_func_next_line_moves_only_braces(tmp_path):
    """-fn moves a function's opening brace but not then/do."""
    # CATCHES: the deprecated flag is narrower than -bl
    res = run_shfmt(["-fn"], input=FUNC + LOOPS, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "function foo()",
        "{",
        "\tbar",
        "}",
        "baz()",
        "{",
        "\tqux",
        "}",
        "if foo; then",
        "\tbar",
        "fi",
        "for x in a b; do",
        "\tbar",
        "done",
        "while foo; do",
        "\tbar",
        "done",
    )


def test_func_next_line_splits_single_line_function(tmp_path):
    """-fn even splits a function whose body fits on one line."""
    # CATCHES: unlike -bl, -fn does not leave 'foo() { bar; }' untouched
    src = "foo() { bar; }\n"
    res = run_shfmt(["-fn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo()",
        "{",
        "\tbar",
        "}",
    )


def test_func_next_line_moves_subshell_paren(tmp_path):
    """-fn also breaks the line before a subshell function body."""
    # CATCHES: 'foo() (' is treated like a brace body by -fn
    src = "foo() (\n\tbar\n)\n"
    res = run_shfmt(["-fn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo()",
        "(",
        "\tbar",
        ")",
    )


def test_func_and_block_next_line_conflict(tmp_path):
    """-fn and -bl cannot be combined and the tool errors out."""
    # CATCHES: the conflict is detected before any input is read
    res = run_shfmt(["-fn", "-bl"], input="foo\n", cwd=guard(tmp_path))
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "-fn and -bl cannot coexist; note that -fn is deprecated\n"
    long_forms = run_shfmt(
        ["--func-next-line", "--block-next-line"], input="foo\n", cwd=guard(tmp_path)
    )
    assert long_forms.returncode == 1
    assert long_forms.stderr == res.stderr


def test_multiline_condition_keeps_then_on_its_own_line(tmp_path):
    """A 'then' after a multi-line condition stays put even without -bl."""
    # CATCHES: the newline is kept because the condition spans lines
    src = "if foo &&\n\tbar; then\n\tbaz\nfi\n"
    res = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "if foo &&",
        "\tbar; then",
        "\tbaz",
        "fi",
    )
