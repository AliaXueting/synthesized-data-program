"""Tests for the -sr/--space-redirects printer flag."""

from conftest import guard, lines, run_shfmt

SIMPLE = "foo >a\nbar >>b\nbaz <c\nr 2>err\ns 2>>out\n"

EXCEPTIONS = "qux 2>&1\nn >&2\nm <&0\np >(foo)\nq <(bar)\n"


def test_space_redirects_adds_space_after_operators(tmp_path):
    """-sr separates the word from >, >>, < and numbered redirects."""
    # CATCHES: every plain redirect operator gains one space before the word
    res = run_shfmt(["-sr"], input=SIMPLE, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo > a",
        "bar >> b",
        "baz < c",
        "r 2> err",
        "s 2>> out",
    )


def test_default_has_no_space_after_redirects(tmp_path):
    """Without -sr the redirect operator sticks to the following word."""
    # CATCHES: the default output must remain compact, not -sr styled
    res = run_shfmt([], input=SIMPLE, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == SIMPLE


def test_space_redirects_exceptions(tmp_path):
    """>&, <&, >( and <( never gain a space, even with -sr."""
    # CATCHES: fd duplication and process substitution are the documented
    # exceptions to the space-redirects rule
    res = run_shfmt(["-sr"], input=EXCEPTIONS, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == EXCEPTIONS


def test_space_redirects_other_operators(tmp_path):
    """-sr also spaces >|, <>, &>, &>>, <<< and here-doc operators."""
    # CATCHES: the rarely used operators follow the same spacing rule
    src = "foo >|out\nfoo <>out\nfoo &>out\nfoo &>>out\nfoo <<<bar\n"
    res = run_shfmt(["-sr"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo >| out",
        "foo <> out",
        "foo &> out",
        "foo &>> out",
        "foo <<< bar",
    )


def test_space_redirects_heredoc_operator(tmp_path):
    """The here-doc operator itself is spaced by -sr, the body is not."""
    # CATCHES: '<<EOF' becomes '<< EOF' while the body keeps its tabs
    src = "foo >out <<EOF\n\tbody\nEOF\n"
    res = run_shfmt(["-sr"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo > out << EOF",
        "\tbody",
        "EOF",
    )


def test_space_redirects_default_keeps_operators_tight(tmp_path):
    """Without -sr the extra operators keep touching their word."""
    # CATCHES: >|, <>, &>, &>> and <<< are tight in the default style
    src = "foo >|out\nfoo <>out\nfoo &>out\nfoo &>>out\nfoo <<<bar\n"
    res = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src


def test_space_redirects_long_form(tmp_path):
    """--space-redirects is the long spelling of -sr."""
    # CATCHES: the long option must reach the same printer option
    res = run_shfmt(["--space-redirects"], input=SIMPLE, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo > a",
        "bar >> b",
        "baz < c",
        "r 2> err",
        "s 2>> out",
    )


def test_space_redirects_on_inline_redirects(tmp_path):
    """-sr also spaces redirects sitting between a command's words."""
    # CATCHES: position-ordered redirects like 'echo >out hi' get the same
    # space after the operator as trailing ones, fd-prefixed or not.
    res = run_shfmt(
        ["-sr"],
        input="echo >out hi\necho 2>out hi\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "echo > out hi\necho 2> out hi\n"
