"""Word part edges: quoting forms, substitutions, globs and continuations."""

from conftest import guard, lines, run_shfmt


def test_herestring_keeps_leading_continuation(tmp_path):
    """An escaped newline right after <<< is preserved with indentation."""
    # CATCHES: a leading escaped newline between word parts is kept, unlike
    # escaped newlines elsewhere which are stripped for indentation.
    res = run_shfmt(
        [],
        input='cat <<< \\\n\t"bar baz"\n',
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == 'cat <<< \\\n\t"bar baz"\n'


def test_escaped_newline_inside_double_quotes(tmp_path):
    """A backslash-newline inside double quotes survives verbatim."""
    # CATCHES: escaped newlines inside quotes are part of the string and
    # must not be dropped or re-indented by the printer.
    res = run_shfmt([], input='echo "a\\\nb"\n', cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == 'echo "a\\\nb"\n'


def test_dollar_quote_forms(tmp_path):
    """$'...' and $"..." keep their dollar prefixes."""
    # CATCHES: both dollar-quoting prefixes are dialect syntax, not $ plus a
    # quoted word, and must be re-emitted as single tokens.
    res = run_shfmt(
        [],
        input='echo $\'hi\\n\' $\"hi\"\n',
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "echo $'hi\\n' $\"hi\"\n"


def test_extglob_operators_round_trip(tmp_path):
    """Extglob patterns keep their @(...) ?(...) +(...) !(...) shapes."""
    # CATCHES: extglob prefixes and their inner alternation are word parts
    # glued together; inserting spaces would break the pattern.
    res = run_shfmt([], input="echo +(a|b) @(a)?(b) !(c)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo +(a|b) @(a)?(b) !(c)\n"


def test_process_substitutions_get_spaces(tmp_path):
    """>(...) and <(...) are separated from neighbouring words."""
    # CATCHES: process substitution operators need a preceding space so
    # they cannot fuse with << or other redirect operators.
    res = run_shfmt([], input="diff <(ls) >(ls)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "diff <(ls) >(ls)\n"


def test_lone_backslash_at_eof_is_escaped(tmp_path):
    """A trailing backslash with no newline is doubled in the output."""
    # CATCHES: an odd number of trailing backslashes would escape the
    # newline shfmt appends, so the last one is doubled to stay literal.
    res = run_shfmt([], input="echo hi \\", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo hi \\\\\n"


def test_command_substitution_starting_with_paren(tmp_path):
    """$( (cmd) ) keeps the space between the two opening parens."""
    # CATCHES: '$( (' must not collapse into '$((' which starts an
    # arithmetic expression instead of a nested subshell.
    res = run_shfmt([], input="echo $( (echo hi) )\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo $( (echo hi) )\n"


def test_nested_subshell_parens_keep_spaces(tmp_path):
    """( (cmd) ) keeps its inner space even on a single line."""
    # CATCHES: the printer inserts a space between stacked opening parens
    # to keep '( (' distinct from the arithmetic-command token '(('.
    res = run_shfmt([], input="( (echo hi) )\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "( (echo hi) )\n"
    res = run_shfmt([], input="(\n\t(echo hi)\n)\n", cwd=guard(tmp_path))
    assert res.stdout == "(\n\t(echo hi)\n)\n"


def test_minify_collapses_nested_subshell(tmp_path):
    """-mn drops the inner subshell's parens to '(echo hi)'."""
    # CATCHES: under minify the nested subshell is squeezed onto the outer
    # parens because no newline separates them.
    res = run_shfmt(["-mn"], input="( (echo hi) )\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "(echo hi)\n"


def test_backquote_comment_substitution(tmp_path):
    """A backquote substitution holding only a comment is kept inline."""
    # CATCHES: the empty backquote command with a comment keeps its exact
    # backquote spelling instead of becoming an empty $( ).
    res = run_shfmt([], input="echo `# c`\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo `# c`\n"


def test_replyvar_substitution(tmp_path):
    """Bash's ${|stmts;} form is reprinted with tight braces."""
    # CATCHES: the ${| ...; } command substitution form loses its inner
    # spaces and the ';' is glued to the closing brace.
    res = run_shfmt([], input="echo ${| reply=1; }\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${|reply=1;}\n"


def test_tempfile_substitution(tmp_path):
    """Bash's ${ stmts; } form keeps its leading space only."""
    # CATCHES: the space after '${' is required to tell the tempfile form
    # apart from a parameter expansion, but the ';}' is squeezed.
    res = run_shfmt([], input="echo ${ echo hi; }\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${ echo hi;}\n"


def test_zsh_empty_subshell_keeps_space(tmp_path):
    """A zsh empty subshell prints as '(' plus a space before the newline."""
    # CATCHES: zsh allows an empty subshell, and the printer adds a space
    # after the paren so it cannot read as the '() {' function prefix.
    res = run_shfmt(["-ln=zsh"], input="(\n)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "( \n)\n"


def test_double_quotes_with_multiple_escaped_newlines(tmp_path):
    """Every backslash-newline inside one double-quoted word survives."""
    # CATCHES: several escaped newlines within the same literal are each
    # preserved, not just the first; none may gain the block's indentation.
    res = run_shfmt([], input='echo "a\\\nb\\\nc"\n', cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == 'echo "a\\\nb\\\nc"\n'


def test_minify_collapses_multiline_nested_subshell(tmp_path):
    """-mn squeezes a multi-line nested subshell onto a single line."""
    # CATCHES: the source line breaks are dropped when they cost width, so
    # both paren layers end up on one line with no space between them.
    res = run_shfmt(["-mn"], input="(\n\t(echo hi)\n)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "(echo hi)\n"


def test_trailing_escaped_newline_in_double_quotes(tmp_path):
    """An escaped newline after the last part of a double-quoted word stays."""
    # CATCHES: the backslash-newline trailing the literal is re-emitted on
    # its own line before the closing quote instead of being dropped.
    res = run_shfmt([], input='echo "abc\\\n"\n', cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == 'echo "abc\\\n"\n'


def test_arithm_command_after_opening_subshell_paren(tmp_path):
    """A '((x))' right after '(' keeps the separating space on both ends."""
    # CATCHES: '( ((x)) )' would misparse as arithmetic if either space
    # were dropped, so both parens keep their guard spaces.
    res = run_shfmt([], input="( ((x)) )\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "( ((x)) )\n"


def test_chain_ending_in_arithm_command(tmp_path):
    """A ')' after an arithmetic command keeps its space, after a word not."""
    # CATCHES: '(x && ((y)) )' needs the space before the final ')' but the
    # opening one glues to 'x' — the two ends follow different rules.
    res = run_shfmt([], input="( x && ((y)) )\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "(x && ((y)) )\n"
