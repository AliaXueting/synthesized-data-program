"""Parameter expansion forms and how the printer spaces them.

Every expectation was recorded by feeding the reference binary the quoted
script on standard input and capturing its exact output.
"""

from conftest import guard, lines, run_shfmt


def test_default_and_error_modifiers(tmp_path):
    """The :-, :=, :? and :+ modifier families round-trip unchanged."""
    # CATCHES: a printer that drops or respaces the ':' modifier operators
    # would corrupt these four expansion families.
    src = "echo ${x:-y} ${x:=z} ${x:?err} ${x:+alt}\n"
    res = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src


def test_pattern_stripping_operators(tmp_path):
    """The #, ##, % and %% strip operators keep their doubled spellings."""
    # CATCHES: collapsing '# #' into '#' or '%' into '%%' changes shell
    # semantics; the printer must preserve the operator arity exactly.
    src = "echo ${x#p} ${x##p} ${x%p} ${x%%p}\n"
    res = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src


def test_slice_negative_offset_keeps_guard_space(tmp_path):
    """A negative slice offset is printed with a space after the colon."""
    # CATCHES: without the forced space ${x: -1} would be re-emitted as the
    # entirely different default-value expansion ${x:-1}.
    res = run_shfmt([], input="echo ${x: -1} ${x: -3:2}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${x: -1} ${x: -3:2}\n"
    res = run_shfmt([], input="echo ${x:-1}\n", cwd=guard(tmp_path))
    assert res.stdout == "echo ${x:-1}\n"


def test_replacement_slashes_normalize(tmp_path):
    """Empty replacement operands get their trailing slash restored."""
    # CATCHES: the printer rewrites a bare trailing slash to a leading one
    # (${x/} becomes ${x//}); losing that normalization is a visible diff.
    res = run_shfmt([], input="echo ${x/} ${x//a}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${x//} ${x//a/}\n"


def test_string_operator_expansions(tmp_path):
    """The @ operator spellings and name/length expansions round-trip."""
    # CATCHES: the @-operators, ${!name@}/${!prefix*} name lists and the
    # length operator must all keep their exact spelling and order.
    src = "echo ${x@Q} ${x@U} ${x@E} ${!x@} ${!pre*} ${#x} ${#x[@]}\n"
    res = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src


def test_array_index_gets_spaces(tmp_path):
    """An arithmetic array index is re-spaced like other arithmetic."""
    # CATCHES: binary index operators gain spaces (i+1 becomes i + 1) while
    # bare names stay tight; the index is formatted as arithmetic.
    res = run_shfmt([], input="echo ${arr[i]} ${arr[i+1]} ${arr[$i]}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${arr[i]} ${arr[i + 1]} ${arr[$i]}\n"


def test_positional_parameters_stay_braced(tmp_path):
    """Multi-digit positional parameters keep their braces."""
    # CATCHES: ${10} must never be shortened to $10, which shell would read
    # as $1 followed by a literal 0.
    res = run_shfmt([], input="echo ${10} ${11}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${10} ${11}\n"


def test_minify_shortens_safe_braces_only(tmp_path):
    """-mn drops the braces around a simple name but not ${10}."""
    # CATCHES: minify only unbraces when the following literal cannot join
    # the name; ${10} and ${foo}x-style continuations must stay braced.
    res = run_shfmt(["-mn"], input="echo ${foo} bar ${10}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo $foo bar ${10}\n"


def test_zsh_expansion_flags_and_operators(tmp_path):
    """zsh flag, isset, glob, split and rc-expand prefixes round-trip."""
    # CATCHES: the (flags) form, ${+x}, ${~x}, ${=x}, ${^x} and the nested
    # ${${x}} are zsh-specific shapes the printer must reproduce verbatim.
    src = "echo ${(q)x} ${(t)x} ${+x} ${~x} ${=x} ${^x} ${${x}}\n"
    res = run_shfmt(["-ln=zsh"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src


def test_minify_keeps_braces_when_word_continues(tmp_path):
    """-mn leaves ${foo}bar braced because $foobar reads differently."""
    # CATCHES: unbracing here would fuse the name with the following text,
    # so minify's brace removal is suppressed by the trailing literal.
    res = run_shfmt(["-mn"], input="echo ${foo}bar\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${foo}bar\n"


def test_zsh_comma_slice_index_stays_compact(tmp_path):
    """A zsh comma slice index keeps its operands squeezed together."""
    # CATCHES: unlike ${arr[i + 1]}, the zsh slice comma must not gain
    # spaces or the word stops being a slice assignment.
    res = run_shfmt(["-ln=zsh"], input="echo $foo[1,3]\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo $foo[1,3]\n"


def test_zsh_history_modifiers(tmp_path):
    """zsh's ':h'-style modifiers round-trip verbatim, singly and chained."""
    # CATCHES: ${x:h2} and ${x:r:t} are zsh modifier lists printed as
    # colon-separated lits; respacing or merging them changes the expansion.
    res = run_shfmt(["-ln=zsh"], input="echo ${x:h2}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${x:h2}\n"
    res = run_shfmt(["-ln=zsh"], input="echo ${x:r:t}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${x:r:t}\n"


def test_replacement_with_replacement_word(tmp_path):
    """${x/a/b} keeps its replacement operand after the second slash."""
    # CATCHES: the With word must follow the '/' — dropping it would turn
    # the substitution into the deletion form ${x/a/}.
    res = run_shfmt([], input="echo ${x/a/b}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${x/a/b}\n"
