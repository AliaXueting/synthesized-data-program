"""Tests pinning the default (canonical) style and rarely-used constructs.

syntax/canonical.sh in the source tree documents the reference style; the
first test feeds a script written in exactly that style and requires the
output to be identical.  The remaining tests pin constructs that no other
test file exercises: negation, background, the time prefix, arithmetic
expansions, '<<-' here-documents and select/until loops.
"""

from conftest import guard, lines, run_shfmt

# The reference style, one construct per few lines: comments, negation with a
# redirect and background, one-line functions, brace blocks with aligned
# comments, if/for/case, pipelines, fd duplication, '<<-' here-documents and
# arithmetic expansions.
CANONICAL = "\n".join([
    "#!/bin/bash",
    "",
    "# separate comment",
    "",
    "! foo bar >a &",
    "",
    "foo() { bar; }",
    "",
    "{",
    '\tvar1="some long value" # var1 comment',
    "\tvar2=short             # var2 comment",
    "}",
    "",
    "if foo; then bar; fi",
    "",
    "for foo in a b c; do",
    "\tbar",
    "done",
    "",
    "case $foo in",
    "a) A ;;",
    "b)",
    "\tB",
    "\t;;",
    "esac",
    "",
    "foo | bar",
    "foo &&",
    "\t$(bar) &&",
    "\t(more)",
    "",
    "foo 2>&1",
    "foo <<-EOF",
    "\tbar",
    "EOF",
    "",
    "$((3 + 4))",
]) + "\n"


def test_canonical_style_round_trips(tmp_path):
    """A script already in the canonical style is printed unchanged."""
    # CATCHES: the whole default style at once: every construct keeps its
    # exact bytes when the input is already canonical
    res = run_shfmt([], input=CANONICAL, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == CANONICAL


def test_negation_time_and_background_round_trip(tmp_path):
    """'! cmd >file &' and 'time' commands keep their one-line shape."""
    # CATCHES: negation, redirects, '&' and time prefixes are not re-ordered
    src = "! foo bar >a &\ntime foo\ntime { foo; }\n"
    res = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == src


def test_arithmetic_expansion_spacing(tmp_path):
    """Arithmetic expansions gain spaces around binary operators."""
    # CATCHES: '$((3+4))' is normalized to '$((3 + 4))' by the default style
    src = "echo $((3+4))\na=$((1+2))\n"
    res = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines("echo $((3 + 4))", "a=$((1 + 2))")


def test_space_redirects_dash_heredoc_operator(tmp_path):
    """-sr also spaces the '<<-' operator, keeping the body verbatim."""
    # CATCHES: '<<-EOF' becomes '<<- EOF' while the body keeps its tab
    src = "foo <<-EOF\n\tbar\nEOF\n"
    res = run_shfmt(["-sr"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines("foo <<- EOF", "\tbar", "EOF")


def test_block_next_line_moves_select_and_until_do(tmp_path):
    """-bl moves the 'do' of select and until loops like other blocks."""
    # CATCHES: select and until opening tokens move just like for/while
    src = "select x in a b; do\n\techo $x\ndone\nuntil foo; do\n\tbar\ndone\n"
    res = run_shfmt(["-bl"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "select x in a b",
        "do",
        "\techo $x",
        "done",
        "until foo",
        "do",
        "\tbar",
        "done",
    )


def test_minify_joins_select_and_until(tmp_path):
    """-mn replaces the newline before 'do' with ';do' in select/until."""
    # CATCHES: 'select x in a b;do' and 'until foo;do' collapse to one line
    src = "select x in a b; do\n\techo $x\ndone\nuntil foo; do\n\tbar\ndone\n"
    res = run_shfmt(["-mn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "select x in a b;do",
        "echo $x",
        "done",
        "until foo;do",
        "bar",
        "done",
    )


def test_binary_next_line_after_time_prefix(tmp_path):
    """-bn moves a pipe down even when the pipeline starts with 'time'."""
    # CATCHES: a 'time' prefix does not stop the operator from moving down
    src = "time foo |\n\tbar\n"
    res = run_shfmt(["-bn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines("time foo \\", "\t| bar")
