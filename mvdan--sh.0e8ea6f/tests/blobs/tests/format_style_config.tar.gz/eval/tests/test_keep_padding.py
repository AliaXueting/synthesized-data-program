"""Tests for the -kp/--keep-padding printer flag."""

from conftest import guard, lines, run_shfmt

BLOCK = (
    "{\n"
    '\tvar1="some long value" # var1 comment\n'
    "\tvar2=short             # var2 comment\n"
    "}\n"
    "foo        bar\n"
    "a=1      b=2\n"
)

WORDS = "foo        bar\na=1      b=2\nls   -l  /tmp\n"


def test_keep_padding_preserves_word_columns(tmp_path):
    """-kp keeps the input spacing between words of a command."""
    # CATCHES: padding between arguments survives instead of collapsing
    res = run_shfmt(["-kp"], input=WORDS, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == WORDS


def test_default_collapses_padding_between_words(tmp_path):
    """Without -kp runs of spaces between words become a single space."""
    # CATCHES: the default style must squash the column padding
    res = run_shfmt([], input=WORDS, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo bar\na=1 b=2\nls -l /tmp\n"


def test_keep_padding_keeps_assignment_padding(tmp_path):
    """-kp keeps the spacing of word assignments inside a command."""
    # CATCHES: 'a=1    b=2' arguments keep their padding with -kp
    src = "foo a=1    b=2   c=3\n"
    res = run_shfmt(["-kp"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src
    plain = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert plain.stdout == "foo a=1 b=2 c=3\n"


def test_keep_padding_shifts_block_comments(tmp_path):
    """-kp keeps column padding but drops the default comment alignment."""
    # CATCHES: with -kp the second comment is no longer aligned with the
    # first one, unlike the tab-aligned default output
    res = run_shfmt(["-kp"], input=BLOCK, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "{",
        '\tvar1="some long value" # var1 comment',
        "\tvar2=short           # var2 comment",
        "}",
        "foo        bar",
        "a=1      b=2",
    )


def test_default_aligns_block_comments(tmp_path):
    """The default style aligns trailing comments inside a block."""
    # CATCHES: without -kp comments are aligned into the same column
    res = run_shfmt([], input=BLOCK, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "{",
        '\tvar1="some long value" # var1 comment',
        "\tvar2=short             # var2 comment",
        "}",
        "foo bar",
        "a=1 b=2",
    )


def test_keep_padding_with_space_indent(tmp_path):
    """-kp plus -i keeps padding when indenting with spaces."""
    # CATCHES: padding is measured in columns, so space indent changes it
    src = "foo() {\n\tif a; then\n\t\tb=1    c=2\n\tfi\n}\n"
    res = run_shfmt(["-kp", "-i=4"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo() {",
        "    if a; then",
        "        b=1 c=2",
        "    fi",
        "}",
    )
    tabs = run_shfmt(["-kp"], input=src, cwd=guard(tmp_path))
    assert tabs.stdout == lines(
        "foo() {",
        "\tif a; then",
        "\t\tb=1  c=2",
        "\tfi",
        "}",
    )


def test_keep_padding_long_form(tmp_path):
    """--keep-padding is the long spelling of -kp."""
    # CATCHES: the long option must be wired to the same printer option
    src = "foo() {\n\tif a; then\n\t\tb=1    c=2\n\tfi\n}\n"
    res = run_shfmt(["--keep-padding"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo() {",
        "\tif a; then",
        "\t\tb=1  c=2",
        "\tfi",
        "}",
    )


def test_keep_padding_case_pattern_padding(tmp_path):
    """-kp keeps the padding inside a single-line case branch."""
    # CATCHES: 'a)  A  ;;' keeps its inner spaces under -kp only
    src = "case $x in\na)  A  ;;\nesac\n"
    res = run_shfmt(["-kp"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == src
    plain = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert plain.stdout == "case $x in\na) A ;;\nesac\n"
