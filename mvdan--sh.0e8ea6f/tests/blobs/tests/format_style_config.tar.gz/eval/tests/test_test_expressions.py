"""[[ ]] test expressions: operators, parens and multi-line forms."""

from conftest import guard, run_shfmt


def test_binary_and_unary_operators(tmp_path):
    """Binary test operators keep single spaces around them."""
    # CATCHES: every binary test operator is re-spaced with exactly one
    # space on each side, and the unary '! -z' pair keeps its inner space.
    res = run_shfmt(
        [],
        input="[[ a -eq b && ! -z c ]]\n[[ a =~ ^b ]]\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "[[ a -eq b && ! -z c ]]\n[[ a =~ ^b ]]\n"


def test_parenthesized_test_operands(tmp_path):
    """Parenthesized operands inside [[ ]] keep their tight parens."""
    # CATCHES: the opening paren is glued to the following word and the
    # closing paren to the preceding one, unlike subshell parens.
    res = run_shfmt([], input="[[ (a) || (b) ]]\n[[ (a == b) && c ]]\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "[[ (a) || (b) ]]\n[[ (a == b) && c ]]\n"


def test_multiline_test_expression_keeps_break(tmp_path):
    """A test operand on a later source line stays on its own line."""
    # CATCHES: the second operand is printed behind a real newline plus one
    # indent level, not joined with spaces onto the operator line.
    res = run_shfmt(
        [],
        input="[[ a == b ||\n\tc == d ]]\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "[[ a == b ||\n\tc == d ]]\n"


def test_binary_next_line_moves_test_operator(tmp_path):
    """-bn moves && inside [[ ]] onto the next line."""
    # CATCHES: with -bn the test operator starts the continuation line,
    # glued to its right operand but separated from the left one.
    res = run_shfmt(["-bn"], input="[[ a &&\nb ]]\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "[[ a\n\t&& b ]]\n"
