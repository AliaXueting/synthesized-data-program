"""Tests for the [[shell]], [[bash]] and [[zsh]] EditorConfig sections."""

import pytest

from conftest import guard, lines, run_shfmt

SRC = "if foo; then\nbar\nfi\n"

# One section per language; later sections win, so a bash script sees 6 spaces,
# a zsh script 7 and every other dialect only the [[shell]] 2.
LANG_SECTIONS = (
    "root = true\n"
    "\n[[shell]]\n"
    "indent_style = space\n"
    "indent_size = 2\n"
    "\n[[bash]]\n"
    "indent_style = space\n"
    "indent_size = 6\n"
    "\n[[zsh]]\n"
    "indent_style = space\n"
    "indent_size = 7\n"
)

REVERSED_SECTIONS = (
    "root = true\n"
    "\n[[bash]]\n"
    "indent_style = space\n"
    "indent_size = 6\n"
    "\n[[shell]]\n"
    "indent_style = space\n"
    "indent_size = 2\n"
)


def indented(n):
    return lines("if foo; then", " " * n + "bar", "fi")


@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("a.sh", 6),
        ("a.bash", 6),
        ("a.bats", 6),
        ("a.zsh", 7),
        ("a.mksh", 2),
        ("noext", 6),
    ],
)
def test_language_sections_by_extension(tmp_path, name, expected):
    """[[bash]] matches bash and bats, [[zsh]] only zsh, [[shell]] all."""
    # CATCHES: extensionless files fall back to bash and pick [[bash]]
    root = guard(tmp_path, LANG_SECTIONS)
    (root / name).write_text(SRC, encoding="utf-8")
    res = run_shfmt([name], cwd=root)
    assert res.returncode == 0
    assert res.stdout == indented(expected)


@pytest.mark.parametrize(
    ("name", "shebang", "expected"),
    [
        ("noext", "#!/bin/zsh\n", 7),
        ("noext", "#!/bin/bash\n", 6),
        ("noext", "#!/bin/sh\n", 2),
    ],
)
def test_language_sections_by_shebang(tmp_path, name, shebang, expected):
    """A shebang decides which language sections match an extensionless file."""
    # CATCHES: #!/bin/sh is posix so only [[shell]] applies to it
    root = guard(tmp_path, LANG_SECTIONS)
    (root / name).write_text(shebang + SRC, encoding="utf-8")
    res = run_shfmt([name], cwd=root)
    assert res.returncode == 0
    assert res.stdout == shebang + indented(expected)


def test_later_language_section_wins(tmp_path):
    """When several language sections match, the last one in the file wins."""
    # CATCHES: [[shell]] placed after [[bash]] overrides it for bash files
    root = guard(tmp_path, REVERSED_SECTIONS)
    (root / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt(["a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == indented(2)


def test_language_sections_apply_to_stdin_filenames(tmp_path):
    """--filename is enough for language sections to match stdin input."""
    # CATCHES: stdin with a .zsh filename picks up the [[zsh]] properties
    root = guard(tmp_path, LANG_SECTIONS)
    res = run_shfmt(["--filename=a.zsh"], input=SRC, cwd=root)
    assert res.returncode == 0
    assert res.stdout == indented(7)
    mksh = run_shfmt(["--filename=a.mksh"], input=SRC, cwd=root)
    assert mksh.stdout == indented(2)


def test_bash_section_does_not_match_zsh(tmp_path):
    """A zsh script ignores [[bash]] properties entirely."""
    # CATCHES: only the generic [[shell]] properties reach a zsh script
    root = guard(
        tmp_path,
        "root = true\n\n[[shell]]\nindent_style = space\nindent_size = 2\n"
        "\n[[bash]]\nspace_redirects = true\n",
    )
    src = "foo >out\n"
    (root / "a.zsh").write_text(src, encoding="utf-8")
    (root / "a.bash").write_text(src, encoding="utf-8")
    zsh = run_shfmt(["a.zsh"], cwd=root)
    assert zsh.returncode == 0
    assert zsh.stdout == "foo >out\n"
    bash = run_shfmt(["a.bash"], cwd=root)
    assert bash.stdout == "foo > out\n"


def test_shell_section_matches_every_dialect(tmp_path):
    """[[shell]] applies to bash, zsh, mksh and posix alike."""
    # CATCHES: every dialect name resolves to the common [[shell]] section
    root = guard(
        tmp_path,
        "root = true\n\n[[shell]]\nindent_style = space\nindent_size = 3\n",
    )
    for name in ("a.bash", "a.zsh", "a.mksh", "a.bats"):
        (root / name).write_text(SRC, encoding="utf-8")
        res = run_shfmt([name], cwd=root)
        assert res.returncode == 0, name
        assert res.stdout == indented(3), name
