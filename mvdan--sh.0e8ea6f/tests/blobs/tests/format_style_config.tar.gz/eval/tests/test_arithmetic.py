"""Arithmetic formatting: commands, expansions, C-style loops and minify."""

from conftest import guard, lines, run_shfmt


def test_cstyle_loop_spacing(tmp_path):
    """A C-style for loop squeezes the opening double paren."""
    # CATCHES: the canonical style prints 'for ((i = 0; ...' without the
    # space after '((' that the input had, while 'i = 0' keeps its spaces.
    res = run_shfmt(
        [],
        input="for (( i = 0; i < 10; i++ )); do echo; done\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "for ((i = 0; i < 10; i++)); do echo; done\n"


def test_cstyle_loop_empty_parts_keep_spaces(tmp_path):
    """Missing loop clauses are printed as explicit empty slots."""
    # CATCHES: a nil clause renders as ' ; ' between the semicolons — the
    # printer re-inserts the space before the semicolon that the input
    # omitted, and an empty loop keeps both slots.
    res = run_shfmt(
        [],
        input="for ((; i < 10; )); do :; done\nfor ((;;)); do :; done\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == lines(
        "for (( ; i < 10; )); do :; done",
        "for (( ; ; )); do :; done",
    )


def test_incdec_operators_stay_tight(tmp_path):
    """Pre/post increment and decrement never gain inner spaces."""
    # CATCHES: unary ++/-- must stay glued to their operand even though
    # binary arithmetic operators are always re-spaced.
    res = run_shfmt(
        [],
        input="echo $((i++)) $((i--)) $((++i)) $((--i))\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "echo $((i++)) $((i--)) $((++i)) $((--i))\n"


def test_not_operator_forces_a_space(tmp_path):
    """'!' in arithmetic is printed with a space before its operand."""
    # CATCHES: history expansion makes '!x' unsafe in interactive shells,
    # so the printer normalizes both spellings to '! x'.
    res = run_shfmt([], input="echo $((! x)) $((!x))\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo $((! x)) $((! x))\n"


def test_nested_parens_collapse_into_command_parens(tmp_path):
    """A parenthesized sum inside $(( )) loses the separating space."""
    # CATCHES: '(( (' would be ambiguous with the arithmetic-command token,
    # so the inner paren is glued to the outer '((('.
    res = run_shfmt([], input="echo $(( (1+2)*3 ))\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo $(((1 + 2) * 3))\n"


def test_comma_operator_keeps_spaces(tmp_path):
    """The comma operator is spaced like a binary operator."""
    # CATCHES: the comma is a binary operator with spaces, unlike its tight
    # form inside a zsh slice index.
    res = run_shfmt([], input="echo $((1, 2))\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo $((1, 2))\n"


def test_binary_next_line_escapes_arithmetic_newlines(tmp_path):
    """-bn keeps source line breaks inside $(( )) as escaped newlines."""
    # CATCHES: with -bn the operator moves to the next line behind an
    # escaped newline, and the whole expression must stay on one logical
    # line inside the expansion.
    res = run_shfmt(
        ["-bn"],
        input="echo $((\n\t1 +\n\t2\n))\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "echo $((\\\n1 \\\n\t+ 2))\n"


def test_minify_squeezes_cstyle_loop_arithmetic(tmp_path):
    """-mn compacts all arithmetic spacing, including the loop clauses."""
    # CATCHES: minify drops the spaces around every arithmetic operator and
    # after the ';' separating the loop clauses and the 'do'.
    res = run_shfmt(
        ["-mn"],
        input="for (( i = 0; i < 10; i++ )); do echo; done\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "for ((i=0; i<10; i++));do echo;done\n"


def test_mksh_unsigned_arithmetic(tmp_path):
    """mksh's unsigned '#' arithmetic keeps its space in both forms."""
    # CATCHES: the '# ' marker of unsigned expressions is dialect-gated and
    # must survive with its space in expansions and commands alike.
    res = run_shfmt(
        ["-ln=mksh"],
        input="echo $((# 2#101))\n((# 2#101))\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "echo $((# 2#101))\n((# 2#101))\n"


def test_mksh_width_operator(tmp_path):
    """mksh's ${%var} width expansion round-trips."""
    # CATCHES: '%' as a prefix operator is a distinct token from the '%'
    # pattern-strip suffix; mixing them up would change the expansion.
    res = run_shfmt(["-ln=mksh"], input="echo ${%x}\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo ${%x}\n"
