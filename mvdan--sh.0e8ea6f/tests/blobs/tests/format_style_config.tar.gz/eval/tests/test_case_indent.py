"""Tests for the -ci/--case-indent printer flag."""

from conftest import guard, lines, run_shfmt

CASE = "case $foo in\na) A ;;\nb)\n\tB\n\t;;\nesac\n"


def test_case_indent_indents_branches(tmp_path):
    """-ci puts patterns one level in and their bodies one level further."""
    # CATCHES: both the pattern line and the body/terminator move right
    res = run_shfmt(["-ci"], input=CASE, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $foo in",
        "\ta) A ;;",
        "\tb)",
        "\t\tB",
        "\t\t;;",
        "esac",
    )


def test_default_does_not_indent_case_branches(tmp_path):
    """Without -ci the case patterns stay flush with the case keyword."""
    # CATCHES: the default style must not indent patterns like -ci does
    res = run_shfmt([], input=CASE, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $foo in",
        "a) A ;;",
        "b)",
        "\tB",
        "\t;;",
        "esac",
    )


def test_case_indent_keeps_fallthrough_operators(tmp_path):
    """The ;;& and ;& terminators are printed next to their branch."""
    # CATCHES: fallthrough terminators must not be turned into plain ;;
    src = "case $foo in\na) A ;;&\nb) B ;&\nc) C ;;\nesac\n"
    res = run_shfmt(["-ci"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $foo in",
        "\ta) A ;;&",
        "\tb) B ;&",
        "\tc) C ;;",
        "esac",
    )


def test_case_indent_with_multiple_patterns(tmp_path):
    """Multi-pattern branches get their patterns spaced with a pipe."""
    # CATCHES: 'a|b)' is reprinted as 'a | b' while indenting the branch
    src = "case $foo in\na|b)\nA\n;;\n*)\nB\n;;\nesac\n"
    res = run_shfmt(["-ci"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $foo in",
        "\ta | b)",
        "\t\tA",
        "\t\t;;",
        "\t*)",
        "\t\tB",
        "\t\t;;",
        "esac",
    )


def test_case_indent_inside_function_with_spaces(tmp_path):
    """-ci and -i combine: the case adds one level inside the function body."""
    # CATCHES: case levels stack on top of the enclosing function level
    src = "f() {\ncase $x in\na)\nA\n;;\nesac\n}\n"
    res = run_shfmt(["-ci", "-i=2"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "f() {",
        "  case $x in",
        "    a)",
        "      A",
        "      ;;",
        "  esac",
        "}",
    )


def test_case_indent_splits_several_commands(tmp_path):
    """A branch holding several commands is printed one per line."""
    # CATCHES: 'a) foo; bar ;;' must expand to two indented statements
    src = "case $x in\na) foo; bar ;;\nesac\n"
    res = run_shfmt(["-ci"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $x in",
        "\ta)",
        "\t\tfoo",
        "\t\tbar",
        "\t\t;;",
        "esac",
    )
