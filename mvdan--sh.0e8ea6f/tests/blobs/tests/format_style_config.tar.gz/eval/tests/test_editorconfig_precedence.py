"""Tests for the precedence between CLI flags and .editorconfig properties."""

import pytest

from conftest import guard, lines, run_shfmt

SRC = "if foo; then\nbar\nfi\n"

SPACED = "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 4\n"

TABS = lines("if foo; then", "\tbar", "fi")

SPACES = lines("if foo; then", "    bar", "fi")


@pytest.mark.parametrize(
    "args",
    [
        ["-i=0"],
        ["-i=2"],
        ["--indent=3"],
        ["-ln=bash"],
        ["-ln=posix"],
        ["-p"],
        ["--posix"],
        ["-s"],
        ["--simplify"],
        ["-bn"],
        ["-ci"],
        ["-sr"],
        ["-kp"],
        ["-fn"],
        ["-bl"],
        ["-mn"],
        ["-bn=false"],
    ],
)
def test_any_parser_or_printer_flag_disables_editorconfig(tmp_path, args):
    """Any parser or printer flag turns off all EditorConfig properties."""
    # CATCHES: even a flag set to its default value (-i=0, -bn=false) wins
    root = guard(tmp_path, SPACED)
    (root / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt([*args, "a.sh"], cwd=root)
    assert res.returncode == 0, args
    if args in (["-i=2"], ["--indent=3"]):
        # the flag value wins over the config's indent_size = 4, so the
        # body is indented by the flag's size, not by four spaces
        n = int(args[0].split("=")[1])
        assert res.stdout == lines("if foo; then", " " * n + "bar", "fi"), args
    elif args == ["-bl"]:
        assert res.stdout == lines("if foo", "then", "\tbar", "fi"), args
    elif args == ["-mn"]:
        assert res.stdout == lines("if foo;then", "bar", "fi"), args
    else:
        assert res.stdout == TABS, args


def test_generic_flags_keep_editorconfig(tmp_path):
    """-l and -d are not parser/printer flags, so EditorConfig still applies."""
    # CATCHES: the listed diff body shows the four-space EditorConfig indent
    root = guard(tmp_path, SPACED)
    (root / "a.sh").write_text(SRC, encoding="utf-8")
    listed = run_shfmt(["-l", "a.sh"], cwd=root)
    assert listed.returncode == 1
    assert listed.stdout == "a.sh\n"
    diffed = run_shfmt(["-d", "a.sh"], cwd=root)
    assert diffed.returncode == 1
    assert diffed.stdout == lines(
        "diff a.sh.orig a.sh",
        "--- a.sh.orig",
        "+++ a.sh",
        "@@ -1,3 +1,3 @@",
        " if foo; then",
        "-bar",
        "+    bar",
        " fi",
    )


def test_flag_wins_over_every_editorconfig_property(tmp_path):
    """One flag disables all properties, not just the related one."""
    # CATCHES: -i=0 must reset case_indent, space_redirects and the rest too
    props = (
        "root = true\n"
        "\n[*.sh]\n"
        "indent_style = space\n"
        "indent_size = 4\n"
        "case_indent = true\n"
        "space_redirects = true\n"
        "binary_next_line = true\n"
    )
    root = guard(tmp_path, props)
    src = "case $x in\na) foo >out\n;;\nesac\nfoo &&\n\tbar\n"
    with_ec = run_shfmt(["--filename=a.sh"], input=src, cwd=root)
    assert with_ec.returncode == 0
    assert with_ec.stdout == lines(
        "case $x in",
        "    a)",
        "        foo > out",
        "        ;;",
        "esac",
        "foo \\",
        "    && bar",
    )
    with_flag = run_shfmt(["-i=0", "--filename=a.sh"], input=src, cwd=root)
    assert with_flag.returncode == 0
    assert with_flag.stdout == lines(
        "case $x in",
        "a)",
        "\tfoo >out",
        "\t;;",
        "esac",
        "foo &&",
        "\tbar",
    )


def test_editorconfig_beats_defaults(tmp_path):
    """With no flag given the .editorconfig value replaces the default."""
    # CATCHES: the default tab indentation must yield to the config file
    root = guard(tmp_path, SPACED)
    (root / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt(["a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == SPACES
