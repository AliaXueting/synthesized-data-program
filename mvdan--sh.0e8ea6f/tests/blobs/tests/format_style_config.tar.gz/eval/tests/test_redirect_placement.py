"""Redirect placement and the -l=0 listing output."""

from conftest import guard, lines, run_shfmt


def test_redirect_before_first_argument(tmp_path):
    """A leading redirect keeps its place before the command words."""
    # CATCHES: redirects that precede all arguments are re-printed before
    # the command name, not re-ordered to the end of the statement.
    res = run_shfmt([], input=">out echo hi\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == ">out echo hi\n"


def test_redirect_between_arguments(tmp_path):
    """A redirect sitting between arguments stays exactly there."""
    # CATCHES: the printer splits the word list at the redirect's source
    # position so '>out' remains between 'echo' and 'hi'.
    res = run_shfmt([], input="echo >out hi\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo >out hi\n"


def test_fd_numbered_redirects(tmp_path):
    """Numbered and duplication redirects keep their tight operators."""
    # CATCHES: the fd number stays glued to '>' and the '>&' duplication
    # operator is never given a space by the default style.
    res = run_shfmt([], input="echo hi 2>err 2>&1\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo hi 2>err 2>&1\n"


def test_redirect_after_escaped_newline(tmp_path):
    """A redirect on a continuation line keeps the backslash-newline."""
    # CATCHES: the redirect's source line break is preserved behind an
    # escaped newline instead of being pulled up to the command line.
    res = run_shfmt([], input="echo hi \\\n\t>out\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo hi \\\n\t>out\n"


def test_list_zero_prints_null_separated_paths(tmp_path):
    """-l=0 lists differing files separated by NUL bytes with rc 1."""
    # CATCHES: only files whose formatting differs are listed, the NUL
    # byte separates them, and the exit status is 1 like plain -l.
    root = guard(tmp_path)
    (root / "a.sh").write_text("if true; then\nfoo\nfi\n")
    (root / "b.sh").write_text("if true\nthen\n\tfoo\nfi\n")
    (root / "c.sh").write_text("if true; then\n\tfoo\nfi\n")
    res = run_shfmt(["-l=0", "a.sh", "b.sh", "c.sh"], cwd=root)
    assert res.returncode == 1
    assert res.stdout == "a.sh\x00b.sh\x00"


def test_numbered_redirect_between_arguments(tmp_path):
    """A fd-prefixed redirect between words stays between them."""
    # CATCHES: the '2>' word splits the argument list like a bare '>'
    # would, so the redirect is not shuffled to the statement's end.
    res = run_shfmt([], input="echo 2>out hi\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "echo 2>out hi\n"


def test_numbered_redirect_before_first_argument(tmp_path):
    """A leading fd-prefixed redirect stays ahead of the command word."""
    # CATCHES: '2>out' before the command name is kept in front, matching
    # the bare-redirect placement rather than moving behind 'echo'.
    res = run_shfmt([], input="2>out echo hi\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "2>out echo hi\n"


def test_redirect_then_process_substitution(tmp_path):
    """A process substitution following a redirect keeps its space."""
    # CATCHES: the '>(tee log)' word is spaced apart from '2>' so the two
    # operators cannot merge into a different redirect shape.
    res = run_shfmt([], input="exec 2> >(tee log)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "exec 2> >(tee log)\n"


def test_list_zero_exits_zero_when_clean(tmp_path):
    """-l=0 prints nothing and exits 0 when every file matches."""
    # CATCHES: an already-formatted file produces no NUL bytes at all and
    # the run must look successful on every channel.
    root = guard(tmp_path)
    (root / "c.sh").write_text("if true; then\n\tfoo\nfi\n")
    res = run_shfmt(["-l=0", "c.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
