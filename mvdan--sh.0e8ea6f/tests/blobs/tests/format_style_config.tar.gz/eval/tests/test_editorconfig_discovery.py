"""Tests for how .editorconfig files are discovered and applied."""

from conftest import guard, lines, run_shfmt

SRC = "if foo; then\nbar\nfi\n"


def test_editorconfig_in_same_directory(tmp_path):
    """A .editorconfig next to the script sets the indentation."""
    # CATCHES: indent_style/indent_size replace the tab default
    root = guard(tmp_path, "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 4\n")
    (root / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt(["a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "    bar", "fi")


def test_editorconfig_found_in_parent_directory(tmp_path):
    """Formatting a file in a subdirectory uses the parent's .editorconfig."""
    # CATCHES: discovery walks up the directory tree, not just the file's dir
    root = guard(tmp_path, "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 2\n")
    sub = root / "sub"
    sub.mkdir()
    (sub / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt(["sub/a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "  bar", "fi")
    from_sub = run_shfmt(["a.sh"], cwd=sub)
    assert from_sub.stdout == res.stdout


def test_stdin_without_filename_ignores_glob_sections(tmp_path):
    """Stdin is named '<standard input>', which matches no *.sh pattern."""
    # CATCHES: a [*.sh] section must not leak into nameless stdin input
    root = guard(tmp_path, "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 2\n")
    res = run_shfmt([], input=SRC, cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "\tbar", "fi")


def test_stdin_without_filename_still_matches_language_sections(tmp_path):
    """A [[shell]] section applies even to nameless stdin input."""
    # CATCHES: language sections match by dialect, not by file name
    root = guard(tmp_path, "root = true\n\n[[shell]]\nindent_style = space\nindent_size = 2\n")
    res = run_shfmt([], input=SRC, cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "  bar", "fi")


def test_stdin_with_filename_uses_editorconfig(tmp_path):
    """--filename makes EditorConfig work for standard input."""
    # CATCHES: the relative filename is resolved against the work directory
    root = guard(tmp_path, "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 3\n")
    res = run_shfmt(["--filename=a.sh"], input=SRC, cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "   bar", "fi")


def test_closer_editorconfig_wins(tmp_path):
    """The nearest .editorconfig overrides properties of a parent one."""
    # CATCHES: properties merge with the closest file taking precedence
    root = guard(tmp_path, "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 9\n")
    sub = root / "sub"
    sub.mkdir()
    (sub / ".editorconfig").write_text(
        "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 3\n", encoding="utf-8"
    )
    (sub / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt(["sub/a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "   bar", "fi")


def test_root_true_stops_the_search(tmp_path):
    """root = true in a parent .editorconfig hides any config above it."""
    # CATCHES: a child config still wins, but the walk stops at root=true
    root = guard(tmp_path, "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 9\n")
    outer = root / "outer"
    outer.mkdir()
    (outer / ".editorconfig").write_text(
        "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 4\n", encoding="utf-8"
    )
    deep = outer / "deep"
    deep.mkdir()
    (deep / ".editorconfig").write_text(
        "root = true\n\n[*.sh]\nindent_style = space\nindent_size = 2\n", encoding="utf-8"
    )
    (deep / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt(["outer/deep/a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "  bar", "fi")


def test_editorconfig_with_no_matching_section(tmp_path):
    """A .editorconfig whose sections do not match leaves the defaults."""
    # CATCHES: an unrelated pattern must not change the tab default
    root = guard(tmp_path, "root = true\n\n[*.bash]\nindent_style = space\nindent_size = 4\n")
    (root / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt(["a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "\tbar", "fi")


def test_empty_editorconfig_keeps_defaults(tmp_path):
    """An .editorconfig without sections behaves like no config at all."""
    # CATCHES: the file's mere presence must not alter the default style
    root = guard(tmp_path, "root = true\n")
    (root / "a.sh").write_text(SRC, encoding="utf-8")
    res = run_shfmt(["a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "\tbar", "fi")
    stdin = run_shfmt([], input=SRC, cwd=root)
    assert stdin.stdout == res.stdout
