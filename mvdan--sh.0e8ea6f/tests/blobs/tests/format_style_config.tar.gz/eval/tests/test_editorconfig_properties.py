"""Tests for the individual EditorConfig formatting properties.

Round 1 covered discovery, section matching, flag precedence and the
indent/case-indent/space-redirects/binary-next-line properties.  These tests
pin the remaining properties of the EditorConfig integration: simplify,
minify, keep_padding, function_next_line, block_next_line, the indent_size
fallback rules, the legacy spellings and language_dialect.
"""

import pytest

from conftest import guard, lines, run_shfmt


def with_props(tmp_path, props, src, args=(), name="a.sh"):
    """Format ``src`` as a file under an .editorconfig carrying ``props``."""
    root = guard(tmp_path, "root = true\n\n[*.sh]\n" + props)
    (root / name).write_text(src, encoding="utf-8")
    return run_shfmt([*args, name], cwd=root)


def test_simplify_property(tmp_path):
    """simplify = true strips quotes like the -s flag, keeping the layout."""
    # CATCHES: the property must reach the same simplifier as --simplify
    src = 'foo() {\n\t[[ -n "${foo}" ]]\n}\n'
    res = with_props(tmp_path, "simplify = true\n", src)
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == lines(
        "foo() {",
        "\t[[ -n ${foo} ]]",
        "}",
    )


def test_minify_property(tmp_path):
    """minify = true minifies the code and implies simplify."""
    # CATCHES: the property implies simplify exactly like the -mn flag
    src = 'foo() {\n\t[[ -n "${foo}" ]]\n\tbar\n}\n'
    res = with_props(tmp_path, "minify = true\n", src)
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo(){",
        "[[ -n $foo ]]",
        "bar",
        "}",
    )


def test_minify_property_ignores_indent_style(tmp_path):
    """minify = true wins over indent_style = space: nothing is indented."""
    # CATCHES: minification has priority over the indentation property
    src = "if foo; then\n\tbar\nfi\n"
    res = with_props(tmp_path, "minify = true\nindent_style = space\nindent_size = 4\n", src)
    assert res.returncode == 0
    assert res.stdout == lines("if foo;then", "bar", "fi")


def test_keep_padding_property(tmp_path):
    """keep_padding = true preserves the input's column padding."""
    # CATCHES: the property must reach the same printer knob as -kp
    src = "foo        bar\na=1      b=2\n"
    res = with_props(tmp_path, "keep_padding = true\n", src)
    assert res.returncode == 0
    assert res.stdout == src


def test_function_next_line_property(tmp_path):
    """function_next_line = true moves only the function's opening brace."""
    # CATCHES: the deprecated knob is narrower than block_next_line
    src = "foo() { bar; }\nif foo; then\n\tbar\nfi\n"
    res = with_props(tmp_path, "function_next_line = true\n", src)
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo()",
        "{",
        "\tbar",
        "}",
        "if foo; then",
        "\tbar",
        "fi",
    )


def test_block_next_line_property(tmp_path):
    """block_next_line = true moves then/do but leaves short functions."""
    # CATCHES: a single-line function stays put while 'then' moves down
    src = "foo() { bar; }\nif foo; then\n\tbar\nfi\n"
    res = with_props(tmp_path, "block_next_line = true\n", src)
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo() { bar; }",
        "if foo",
        "then",
        "\tbar",
        "fi",
    )


def test_both_next_line_properties_produce_no_output(tmp_path):
    """function_next_line plus block_next_line yields empty output."""
    # CATCHES: only the CLI flags conflict-check; via EditorConfig the
    # printer refuses the combination and the empty result is printed
    src = "foo() {\n\tbar\n}\n"
    root = guard(
        tmp_path,
        "root = true\n\n[*.sh]\nfunction_next_line = true\nblock_next_line = true\n",
    )
    (root / "a.sh").write_text(src, encoding="utf-8")
    res = run_shfmt(["a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    listed = run_shfmt(["-l", "a.sh"], cwd=root)
    assert listed.returncode == 1
    assert listed.stdout == "a.sh\n"


def test_space_indent_without_size_defaults_to_eight(tmp_path):
    """indent_style = space with no indent_size means eight spaces."""
    # CATCHES: the documented fallback is 8 spaces, not the tab default
    src = "if foo; then\n\tbar\nfi\n"
    res = with_props(tmp_path, "indent_style = space\n", src)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", " " * 8 + "bar", "fi")


def test_indent_size_without_space_style_is_ignored(tmp_path):
    """indent_size alone does nothing: only indent_style = space enables it."""
    # CATCHES: indent_size = 4 must not turn on space indentation by itself
    src = "if foo; then\n\tbar\nfi\n"
    res = with_props(tmp_path, "indent_size = 4\n", src)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "\tbar", "fi")


def test_tab_indent_style_with_size_keeps_tabs(tmp_path):
    """indent_style = tab ignores indent_size entirely."""
    # CATCHES: anything but indent_style = space keeps the tab default
    src = "if foo; then\n\tbar\nfi\n"
    res = with_props(tmp_path, "indent_style = tab\nindent_size = 4\n", src)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", "\tbar", "fi")


@pytest.mark.parametrize("size", ["0", "tab"])
def test_unusable_indent_size_falls_back_to_eight(tmp_path, size):
    """indent_size values that are not positive integers fall back to 8."""
    # CATCHES: '0' and 'tab' never yield a usable size, so 8 spaces are used
    src = "if foo; then\n\tbar\nfi\n"
    res = with_props(tmp_path, "indent_style = space\nindent_size = %s\n" % size, src)
    assert res.returncode == 0
    assert res.stdout == lines("if foo; then", " " * 8 + "bar", "fi")


def test_legacy_switch_case_indent_spelling(tmp_path):
    """switch_case_indent is the accepted legacy spelling of case_indent."""
    # CATCHES: the old property name must still reach the printer knob
    src = "case $x in\na)\n\tA\n\t;;\nesac\n"
    res = with_props(tmp_path, "switch_case_indent = true\n", src)
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $x in",
        "\ta)",
        "\t\tA",
        "\t\t;;",
        "esac",
    )


def test_case_indent_beats_legacy_spelling(tmp_path):
    """case_indent wins when both spellings are present in a section."""
    # CATCHES: case_indent = false must override switch_case_indent = true
    src = "case $x in\na)\n\tA\n\t;;\nesac\n"
    res = with_props(tmp_path, "case_indent = false\nswitch_case_indent = true\n", src)
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $x in",
        "a)",
        "\tA",
        "\t;;",
        "esac",
    )


ARRAYS = "foo=(1 2)\n"

DIALECT_ERR = (
    "a.sh:1:5: arrays are a bash/mksh/zsh feature; "
    "tried parsing as posix (parsed as posix via EditorConfig)\n"
)


def test_language_dialect_posix_changes_parsing(tmp_path):
    """language_dialect = posix turns bash-only syntax into a parse error."""
    # CATCHES: the error message names EditorConfig as the dialect's source
    res = with_props(tmp_path, "language_dialect = posix\n", ARRAYS)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == DIALECT_ERR


def test_legacy_shell_variant_spelling(tmp_path):
    """shell_variant is the accepted legacy spelling of language_dialect."""
    # CATCHES: the old property name reaches the same dialect switch
    res = with_props(tmp_path, "shell_variant = posix\n", ARRAYS)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == DIALECT_ERR


def test_language_dialect_beats_shell_variant(tmp_path):
    """language_dialect wins when both spellings are present."""
    # CATCHES: language_dialect = bash overrides shell_variant = posix
    res = with_props(tmp_path, "language_dialect = bash\nshell_variant = posix\n", ARRAYS)
    assert res.returncode == 0
    assert res.stdout == ARRAYS


def test_invalid_language_dialect_is_ignored(tmp_path):
    """An unknown language_dialect value leaves the detected dialect."""
    # CATCHES: a bad value neither fails nor changes the bash fallback
    res = with_props(tmp_path, "language_dialect = nonsense\n", ARRAYS)
    assert res.returncode == 0
    assert res.stdout == ARRAYS


def test_language_dialect_in_shell_section_on_stdin(tmp_path):
    """A [[shell]] language_dialect also applies to stdin with a filename."""
    # CATCHES: dialect properties work without a real file on disk
    root = guard(tmp_path, "root = true\n\n[[shell]]\nlanguage_dialect = posix\n")
    res = run_shfmt(["--filename=a.sh"], input=ARRAYS, cwd=root)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == DIALECT_ERR


@pytest.mark.parametrize("value", ["TRUE", "1", "yes"])
def test_printer_properties_only_accept_lowercase_true(tmp_path, value):
    """Property values are compared to the exact string 'true'."""
    # CATCHES: TRUE/1/yes must leave the binary operator at line end
    src = "foo &&\n\tbar\n"
    res = with_props(tmp_path, "binary_next_line = %s\n" % value, src)
    assert res.returncode == 0
    assert res.stdout == src


def test_malformed_editorconfig_is_tolerated(tmp_path):
    """A malformed section header leaves the defaults instead of failing."""
    # CATCHES: an unclosed '[' neither applies the properties nor errors out
    src = "if foo; then\n\tbar\nfi\n"
    root = guard(tmp_path, "root = true\n\n[*.sh\nindent_style = space\nindent_size = 4\n")
    (root / "a.sh").write_text(src, encoding="utf-8")
    res = run_shfmt(["a.sh"], cwd=root)
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == lines("if foo; then", "\tbar", "fi")


def test_all_printer_properties_together(tmp_path):
    """Every printer property can be combined in a single section."""
    # CATCHES: all knobs stack: spaces, -bn, -ci, -sr, -kp, -bl and simplify
    props = (
        "indent_style = space\n"
        "indent_size = 3\n"
        "binary_next_line = true\n"
        "case_indent = true\n"
        "space_redirects = true\n"
        "keep_padding = true\n"
        "block_next_line = true\n"
        "simplify = true\n"
    )
    src = (
        "foo        bar\n"
        "foo() {\n"
        "\tif foo &&\n"
        "\t\tbar; then\n"
        '\t\t[[ -n "${x}" ]]\n'
        "\tfi\n"
        "\tcase $x in\n"
        "\ta)\n"
        "\t\techo one   >out\n"
        "\t\t;;\n"
        "\tesac\n"
        "}\n"
    )
    res = with_props(tmp_path, props, src)
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == lines(
        "foo        bar",
        "foo()",
        "      {",
        "   if foo \\",
        "        && bar",
        "   then",
        "      [[ -n ${x} ]]",
        "   fi",
        "   case $x in",
        "      a)",
        "         echo one > out",
        "         ;;",
        "   esac",
        "}",
    )


def test_keep_padding_toggles_per_file(tmp_path):
    """keep_padding is re-applied per file, including turning it back off."""
    # CATCHES: printer options come from EditorConfig for every file, so
    # one invocation can enable keep_padding, disable it for b.sh and
    # enable it again for c.sh (walked in lexical order).
    root = guard(
        tmp_path,
        "root = true\n[*]\nkeep_padding = true\n[b.sh]\nkeep_padding = false\n",
    )
    for name in ("a.sh", "b.sh", "c.sh"):
        (root / name).write_text("echo a    b\n", encoding="utf-8")
    res = run_shfmt(["."], cwd=root)
    assert res.returncode == 0
    assert res.stdout == "echo a    b\necho a b\necho a    b\n"
