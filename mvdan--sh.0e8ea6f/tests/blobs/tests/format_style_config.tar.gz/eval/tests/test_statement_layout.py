"""Statement layout: separators, control keywords, comments and cases."""

from conftest import guard, lines, run_shfmt


def test_control_keywords_stay_on_the_same_line(tmp_path):
    """exit/return/shift/break/continue keep sharing the previous line."""
    # CATCHES: only these five guard keywords may share a line with the
    # preceding statement; any other command gets its own line.
    res = run_shfmt(
        [],
        input="foo; exit $?\narg=$1; shift\nfor x in a; do foo; break; done\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo; exit $?",
        "arg=$1; shift",
        "for x in a; do",
        "\tfoo; break",
        "done",
    )


def test_return_keeps_line_inside_function(tmp_path):
    """A trailing 'return 1' stays on the body's last statement line."""
    # CATCHES: the block spans lines, but 'return' still glues to 'foo'
    # while the function braces are split onto their own lines.
    res = run_shfmt(
        [],
        input="f() { foo; return 1; }\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "f() {\n\tfoo; return 1\n}\n"


def test_semicolon_after_continuation_stays_on_its_own_line(tmp_path):
    """A ';' that began its own source line keeps that line."""
    # CATCHES: the separator is written behind a fresh escaped newline with
    # indentation, instead of being pulled up after 'foo'.
    res = run_shfmt([], input="foo \\\n; bar\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo \\\n\t;\nbar\n"


def test_coprocess_operator(tmp_path):
    """The '|&' coprocess pipe operator is preserved."""
    # CATCHES: '|&' is a single operator token, not '|' followed by '&' —
    # splitting it would change a coprocess into a background pipeline.
    res = run_shfmt([], input="foo |& bar\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo |& bar\n"


def test_zsh_disown_operator_normalizes_bang(tmp_path):
    """zsh's '&|' and '&!' both print as '&|' on their own line."""
    # CATCHES: the two disown spellings normalize to '&|', and the operator
    # ends its statement line like '&' does.
    res = run_shfmt(["-ln=zsh"], input="foo &| bar\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo &|\nbar\n"
    res = run_shfmt(["-ln=zsh"], input="foo &! bar\n", cwd=guard(tmp_path))
    assert res.stdout == "foo &|\nbar\n"


def test_zsh_disown_minified(tmp_path):
    """-mn glues the disown operator to its command."""
    # CATCHES: minify removes the space before '&|' but the newline before
    # the next statement survives because '&' forces a line break.
    res = run_shfmt(["-ln=zsh", "-mn"], input="foo &| bar\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo&|\nbar\n"


def test_comment_after_opening_paren(tmp_path):
    """A comment right after '(' is flushed before the first statement."""
    # CATCHES: the comment stays glued to the opening paren while the body
    # statement is indented onto the following line.
    res = run_shfmt([], input="( # c\nfoo)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "( # c\n\tfoo\n)\n"


def test_empty_case_stays_two_lines(tmp_path):
    """'case x in esac' is split over two lines, even with -mn."""
    # CATCHES: an empty case list forces a newline after 'in' because
    # 'case x in; esac' is invalid shell; minify cannot join it either.
    res = run_shfmt([], input="case $x in esac\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "case $x in\nesac\n"
    res = run_shfmt(["-mn"], input="case $x in esac\n", cwd=guard(tmp_path))
    assert res.stdout == "case $x in\nesac\n"


def test_case_item_comment_stays_above_pattern(tmp_path):
    """A comment before a case item remains before its pattern."""
    # CATCHES: the pending comment is printed before the item's pattern and
    # is not swallowed into the previous item's statement list.
    res = run_shfmt(
        [],
        input="case $x in\n# c\na) : ;;\nesac\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "case $x in\n# c\na) : ;;\nesac\n"


def test_esac_pattern_needs_parens(tmp_path):
    """A pattern spelled 'esac' keeps its disambiguating parens."""
    # CATCHES: '(esac)' keeps its opening paren because a bare 'esac)'
    # would terminate the case statement; any other pattern loses it.
    res = run_shfmt(
        [],
        input="case $x in (esac) : ;; esac\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "case $x in (esac) : ;; esac\n"


def test_leading_pattern_parens_are_dropped(tmp_path):
    """Parens around an ordinary pattern are removed."""
    # CATCHES: the canonical style has no paren before patterns except when
    # the pattern itself is the word 'esac'.
    res = run_shfmt([], input="case $x in (a) : ;; esac\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "case $x in a) : ;; esac\n"


def test_comment_after_double_semicolon(tmp_path):
    """A trailing comment after ';;' stays on the item's last line."""
    # CATCHES: the comment is attached after the ';;' separator, and the
    # whole item is re-indented to the case level at the same time.
    res = run_shfmt(
        [],
        input="case $x in\n\ta) : ;; # c\nesac\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "case $x in\na) : ;; # c\nesac\n"


def test_multiline_case_pattern_keeps_continuation(tmp_path):
    """A pattern split with an escaped newline keeps the backslash."""
    # CATCHES: the '|' keeps a space before the escaped newline and the
    # second pattern line is indented one level deeper.
    res = run_shfmt(
        [],
        input="case $x in\n\ta |\\\n\tb) : ;;\nesac\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "case $x in\na | \\\n\tb) : ;;\nesac\n"


def test_comment_between_header_and_do_moves_after_do(tmp_path):
    """A comment on the for/while header line is re-attached after 'do'."""
    # CATCHES: the comment cannot stay in the header, so it follows the
    # 'do' keyword on the same line while the body is still split.
    res = run_shfmt(
        [],
        input="for i in a b # c\ndo foo; done\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "for i in a b; do # c\n\tfoo\ndone\n"
    res = run_shfmt(
        [],
        input="while : # c\ndo foo; done\n",
        cwd=guard(tmp_path),
    )
    assert res.stdout == "while :; do # c\n\tfoo\ndone\n"


def test_binary_next_line_with_comment_on_right_operand(tmp_path):
    """-bn places the operator, then the comment, then the operand."""
    # CATCHES: the pending comment is flushed between the operator line and
    # the right operand, each on its own indented line.
    res = run_shfmt(["-bn"], input="foo && # c\nbar\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo \\\n\t&&\n\t# c\n\tbar\n"


def test_block_next_line_with_comment_after_then(tmp_path):
    """-bl moves 'then' to its own line and keeps its trailing comment."""
    # CATCHES: 'then' is placed on a new line but its inline comment stays
    # attached to it rather than moving into the body.
    res = run_shfmt(["-bl"], input="if true; then # c\n\tfoo\nfi\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "if true\nthen # c\n\tfoo\nfi\n"


def test_comment_before_else_stays_on_its_own_line(tmp_path):
    """A comment line between the body and 'else' keeps its position."""
    # CATCHES: the pending comment is flushed at column zero right before
    # 'else' instead of being pulled up behind 'b' or dropped.
    res = run_shfmt(
        [],
        input="if a; then\n\tb\n# c\nelse\n\td\nfi\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "if a; then\n\tb\n# c\nelse\n\td\nfi\n"


def test_subshell_binary_operand_closing_paren(tmp_path):
    """The ')' after a binary chain glues unless the right end is a subshell."""
    # CATCHES: when the chain's last operand is itself a subshell the outer
    # ')' needs a separating space, but after a plain word it is glued on.
    res = run_shfmt([], input="( (x) && (y) )\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "( (x) && (y) )\n"
    res = run_shfmt([], input="( (x) && y )\n", cwd=guard(tmp_path))
    assert res.stdout == "( (x) && y)\n"


def test_comment_attached_to_else_keyword(tmp_path):
    """A comment after 'else' stays attached to the else line."""
    # CATCHES: the trailing '# c' belongs to the else clause itself and is
    # printed on its line, not flushed into the body or before 'else'.
    res = run_shfmt([], input="if a; then b; else # c\n\td\nfi\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "if a; then b; else # c\n\td\nfi\n"


def test_only_guard_keywords_stay_after_semicolon(tmp_path):
    """Non-simple second statements never share the previous line."""
    # CATCHES: '$bar' (non-literal word), 'a\"b\"' (multi-part word) and
    # '((x))' (not a call) all refuse the same-line treatment that only
    # exit/return/shift/break/continue get.
    res = run_shfmt(
        [],
        input='foo; $bar\nfoo; a"b"\nfoo; ((x))\n',
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == 'foo\n$bar\nfoo\na"b"\nfoo\n((x))\n'
