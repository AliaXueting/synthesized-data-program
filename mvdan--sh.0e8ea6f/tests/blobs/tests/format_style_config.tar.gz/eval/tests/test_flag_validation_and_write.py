"""Flag-validation errors and the '-w' write-back edge of the style flags.

These pin the argument checks that guard the parser/printer style flags
(their exact stderr line and exit status) plus the one failure mode of
'-w' in-place rewriting: refusing to replace a non-regular file.
"""

import pytest

from conftest import guard, run_shfmt

CONFLICT = "-p and -ln=lang cannot coexist\n"


@pytest.mark.parametrize(
    "args",
    [
        ["-p", "-ln=bash"],
        ["--posix", "--language-dialect", "bash"],
        ["-ln=mksh", "-p"],
    ],
)
def test_posix_conflicts_with_explicit_dialect(tmp_path, args):
    """-p cannot be combined with an explicit -ln dialect."""
    # CATCHES: -p is only a shorthand for -ln=posix, so any explicit
    # dialect is rejected with this exact message and exit status 1.
    res = run_shfmt(args, input=":\n", cwd=guard(tmp_path))
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == CONFLICT


def test_filename_flag_requires_stdin(tmp_path):
    """--filename is rejected when a path argument is also given."""
    # CATCHES: --filename only names the standard-input stream; combined
    # with a path argument it fails with this exact line before any walk.
    root = guard(tmp_path)
    (root / "x.sh").write_text(":\n", encoding="utf-8")
    res = run_shfmt(["--filename", "x.sh", "."], cwd=root)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "-filename can only be used with stdin\n"


def test_write_refuses_to_replace_symlink(tmp_path):
    """-w refuses to atomically replace a symlink with a regular file."""
    # CATCHES: in-place rewriting lstats the path and bails out with this
    # refusal line, leaving the symlink's target bytes completely untouched.
    root = guard(tmp_path)
    original = "if a; then\nb\nfi\n"
    (root / "target.sh").write_text(original, encoding="utf-8")
    (root / "link.sh").symlink_to(root / "target.sh")
    res = run_shfmt(["-w", "-i=2", "link.sh"], cwd=root)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        'refusing to atomically replace "link.sh" with a regular file '
        "as it is not one already\n"
    )
    assert (root / "target.sh").read_text(encoding="utf-8") == original


def test_malformed_section_glob_panics(tmp_path):
    """An .editorconfig section header with an unclosed '[' panics."""
    # CATCHES: a glob like '[[a(b]' reaches the editorconfig glob
    # compiler unvalidated and crashes the process with exit status 2.
    root = guard(tmp_path, "root = true\n[[a(b]\nindent_size = 2\n")
    (root / "a.sh").write_text("if a; then\nb\nfi\n", encoding="utf-8")
    res = run_shfmt(["a.sh"], cwd=root)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr.startswith("panic: [ was not matched with a closing ]")
