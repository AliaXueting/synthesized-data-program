"""Declaration commands, functions, and rarer command forms."""

from conftest import guard, lines, run_shfmt


def test_declare_with_bare_and_assigned_names(tmp_path):
    """declare/export/local keep mixed bare and assigned arguments."""
    # CATCHES: declaration arguments are assignments without '=' spacing —
    # 'x=1' stays tight and bare names keep their word separation.
    res = run_shfmt(
        [],
        input="declare x=1 y\ndeclare -a x=(1 2)\nexport x=1\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "declare x=1 y\ndeclare -a x=(1 2)\nexport x=1\n"


def test_local_bare_names(tmp_path):
    """local with bare names keeps a single-statement body on one line."""
    # CATCHES: 'local' keeps its arguments as bare words, and a body with a
    # single statement stays on the brace line while a second statement
    # forces the canonical multi-line split.
    res = run_shfmt([], input="f() { local a b; }\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "f() { local a b; }\n"
    res = run_shfmt([], input="f() { local a b; foo; }\n", cwd=guard(tmp_path))
    assert res.stdout == "f() {\n\tlocal a b\n\tfoo\n}\n"


def test_mksh_typeset_nameref(tmp_path):
    """mksh 'typeset -n' arguments survive untouched."""
    # CATCHES: typeset is a declaration variant whose flag words and tight
    # name=value arguments must both be preserved.
    res = run_shfmt(["-ln=mksh"], input="typeset -n x=y\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "typeset -n x=y\n"


def test_standalone_indexed_assignment(tmp_path):
    """An array-element assignment outside a command keeps its index."""
    # CATCHES: 'arr[2]=x' is an assignment word, not a call — the index
    # brackets stay glued to the name and get no arithmetic re-spacing.
    res = run_shfmt([], input="arr[2]=x\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "arr[2]=x\n"


def test_append_assignment(tmp_path):
    """The '+=' append operator is preserved on arrays and words."""
    # CATCHES: '+=' is a distinct operator token from '='; printing it as
    # '=+' would change the assignment into arithmetic.
    res = run_shfmt([], input="a+=(4 5)\nb+=x\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "a+=(4 5)\nb+=x\n"


def test_assignments_with_escaped_newline(tmp_path):
    """Inline assignments keep their backslash-newline separation."""
    # CATCHES: the escaped newline between two inline assignments survives
    # with its indentation instead of collapsing both onto one line.
    res = run_shfmt([], input="x=1 \\\n\ty=2 cmd\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "x=1 \\\n\ty=2 cmd\n"


def test_multiline_array_literal(tmp_path):
    """A multi-line array keeps one element per line."""
    # CATCHES: elements move to the indent level and the closing paren goes
    # back to column zero; nothing is joined onto the '(' line.
    res = run_shfmt([], input="a=(\n\t1\n\t2\n)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "a=(\n\t1\n\t2\n)\n"


def test_indexed_array_elements(tmp_path):
    """[i]=v style elements keep their tight index-equals-value shape."""
    # CATCHES: the index, '=' and value form one element token and must not
    # be re-spaced like a standalone assignment or arithmetic.
    res = run_shfmt([], input="a=([i]=v [j]=w)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "a=([i]=v [j]=w)\n"


def test_array_with_leading_comment(tmp_path):
    """A comment after '(' stays on the opening line of the array."""
    # CATCHES: the comment is flushed right after the opening paren, before
    # the first element line, and is not dropped or moved to the end.
    res = run_shfmt([], input="a=( # c\n\t1\n)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "a=( # c\n\t1\n)\n"


def test_minify_keeps_array_newlines_but_drops_comment(tmp_path):
    """-mn drops the array comment yet cannot join the elements."""
    # CATCHES: the newlines inside the array are structural and survive
    # minify, but the comment vanishes and indentation is stripped.
    res = run_shfmt(["-mn"], input="a=( # c\n\t1\n\t2\n)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "a=(\n1\n2)\n"


def test_function_keyword_forms(tmp_path):
    """'function name' and 'function name()' both keep their spelling."""
    # CATCHES: the 'function' keyword makes the '()' optional, and the
    # printer must echo exactly the spelling the input used.
    res = run_shfmt(
        [],
        input="function foo { :; }\nfunction foo() { :; }\n",
        cwd=guard(tmp_path),
    )
    assert res.returncode == 0
    assert res.stdout == "function foo { :; }\nfunction foo() { :; }\n"


def test_function_next_line_with_keyword(tmp_path):
    """-fn moves the brace down even for the 'function' spelling."""
    # CATCHES: the deprecated -fn option applies to keyword functions too,
    # putting the brace on its own line while 'function foo' stays intact.
    res = run_shfmt(["-fn"], input="function foo { :; }\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "function foo\n{\n\t:\n}\n"


def test_minify_function_squeezes_brace(tmp_path):
    """-mn keeps the space after the name but glues the body."""
    # CATCHES: minify removes the space before '}' but keeps the one after
    # the function name — an asymmetric spacing rule easy to get wrong.
    res = run_shfmt(["-mn"], input="function foo { :; }\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "function foo { :;}\n"


def test_zsh_function_with_two_names(tmp_path):
    """zsh's multi-name function declaration round-trips."""
    # CATCHES: multiple function names before the brace are a zsh form and
    # must not be collapsed into a single name or joined differently.
    res = run_shfmt(["-ln=zsh"], input="function f g { :; }\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "function f g { :; }\n"


def test_let_with_multiple_expressions(tmp_path):
    """let keeps its argument quoting and spacing."""
    # CATCHES: let arguments are arithmetic words printed with their quotes
    # intact and space-separated, not evaluated or re-spaced.
    res = run_shfmt([], input='let "a=b+1" c=2\n', cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == 'let "a=b+1" c=2\n'


def test_time_posix_format(tmp_path):
    """time -p keeps its -p flag and its operand."""
    # CATCHES: '-p' belongs to the time clause itself and must stay between
    # 'time' and its command even though it looks like a command flag.
    res = run_shfmt([], input="time -p ls\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "time -p ls\n"


def test_coproc_forms(tmp_path):
    """coproc with a name and block, or a plain command, round-trip."""
    # CATCHES: 'coproc name { ... }' keeps the name and the one-line block,
    # while 'coproc cmd args' keeps the command as a plain statement.
    res = run_shfmt([], input="coproc foo { echo; }\ncoproc echo hi\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "coproc foo { echo; }\ncoproc echo hi\n"


def test_array_comment_after_element_stays_inline(tmp_path):
    """A trailing comment on an array element keeps its line."""
    # CATCHES: the comment rides along after the first element rather than
    # sinking to the closing paren or vanishing.
    res = run_shfmt([], input="a=(1 # c\n\t2\n)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "a=(1 # c\n\t2\n)\n"


def test_array_comment_after_last_element(tmp_path):
    """A comment after the final element keeps the block multi-line."""
    # CATCHES: the trailing comment blocks the one-line squeeze and is
    # printed indented on its own line before the closing paren.
    res = run_shfmt([], input="a=(1\n\t# c\n)\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "a=(1\n\t# c\n)\n"


def test_bats_test_declaration(tmp_path):
    """BATS '@test' declarations round-trip with their description."""
    # CATCHES: '@test' is a bats-only declaration whose quoted description
    # and single-line body must be echoed exactly.
    res = run_shfmt(["-ln=bats"], input='@test "name" { :; }\n', cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == '@test "name" { :; }\n'
