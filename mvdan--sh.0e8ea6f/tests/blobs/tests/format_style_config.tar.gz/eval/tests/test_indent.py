"""Tests for the -i/--indent printer flag and the default indentation."""

from conftest import guard, lines, run_shfmt

NESTED = "if foo; then\nbar\nfor x in a b; do\nbaz\ndone\nfi\n"

NESTED_TABS = lines(
    "if foo; then",
    "\tbar",
    "\tfor x in a b; do",
    "\t\tbaz",
    "\tdone",
    "fi",
)


def test_default_indentation_is_one_tab(tmp_path):
    """Without any flag the printer indents each level with a single tab."""
    # CATCHES: a re-implementation defaulting to spaces or to tab_width>1
    res = run_shfmt([], input=NESTED, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == NESTED_TABS
    assert res.stderr == ""


def test_indent_zero_and_long_form_still_mean_tabs(tmp_path):
    """-i=0, '-i 0' and --indent=0 all select tabs, like the default."""
    # CATCHES: the documented '-i=0 disables EditorConfig' idiom must be tabs
    for args in (["-i=0"], ["-i", "0"], ["--indent=0"], ["--indent", "0"]):
        res = run_shfmt(args, input=NESTED, cwd=guard(tmp_path))
        assert res.returncode == 0, args
        assert res.stdout == NESTED_TABS, args


def test_indent_n_spaces(tmp_path):
    """A positive -i/--indent value means exactly that many spaces per level."""
    # CATCHES: level two must get twice the spaces, not the same amount
    for args, unit in (
        (["-i=1"], " "),
        (["-i=2"], "  "),
        (["-i=3"], "   "),
        (["-i=4"], "    "),
        (["-i=8"], "        "),
        (["--indent=4"], "    "),
        (["--indent", "4"], "    "),
    ):
        expected = lines(
            "if foo; then",
            unit + "bar",
            unit + "for x in a b; do",
            unit * 2 + "baz",
            unit + "done",
            "fi",
        )
        res = run_shfmt(args, input=NESTED, cwd=guard(tmp_path))
        assert res.returncode == 0, args
        assert res.stdout == expected, args


def test_indent_does_not_touch_heredoc_bodies(tmp_path):
    """Heredoc bodies keep their original tabs even with space indentation."""
    # CATCHES: heredoc content is verbatim, never re-indented by -i
    src = "foo() {\n\tcat <<EOF\n\t\tsome text\nEOF\n\tbar\n}\n"
    res = run_shfmt(["-i=4"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo() {",
        "    cat <<EOF",
        "\t\tsome text",
        "EOF",
        "    bar",
        "}",
    )


def test_indent_invalid_uint_is_rejected(tmp_path):
    """-i only accepts unsigned integers; anything else is a flag error."""
    # CATCHES: the uint type check with its exact message and exit status 2
    for bad in ("abc", "-1", "1.5", "4 ", ""):
        res = run_shfmt(["-i=" + bad], input="foo\n", cwd=guard(tmp_path))
        assert res.returncode == 2, bad
        assert res.stdout == "", bad
        assert 'invalid value "%s" for flag -i: parse error' % bad in res.stderr, (
            bad,
            res.stderr,
        )


def test_indent_without_argument_is_rejected(tmp_path):
    """A trailing -i with no value is an argument error, not zero."""
    # CATCHES: '-i' must not silently fall back to the default indent
    res = run_shfmt(["-i"], input="foo\n", cwd=guard(tmp_path))
    assert res.returncode == 2
    assert res.stdout == ""
    assert "flag needs an argument: -i" in res.stderr
    assert "usage: shfmt [flags] [path ...]" in res.stderr


def test_indent_attached_short_value_is_not_go_style(tmp_path):
    """'-i2' is not a valid spelling: the whole word is one unknown flag."""
    # CATCHES: only '-i 2' and '-i=2' work, so -i2 must fail loudly
    res = run_shfmt(["-i2"], input="foo\n", cwd=guard(tmp_path))
    assert res.returncode == 2
    assert res.stdout == ""
    assert "flag provided but not defined: -i2" in res.stderr


def test_repeated_indent_flag_last_wins(tmp_path):
    """Giving -i twice keeps only the last value."""
    # CATCHES: flags must be applied in order instead of first-wins
    src = "if foo; then\nbar\nfi\n"
    first = run_shfmt(["-i=4", "-i=2"], input=src, cwd=guard(tmp_path))
    second = run_shfmt(["-i=2", "-i=4"], input=src, cwd=guard(tmp_path))
    assert first.returncode == 0
    assert second.returncode == 0
    assert first.stdout == lines("if foo; then", "  bar", "fi")
    assert second.stdout == lines("if foo; then", "    bar", "fi")


def test_indent_with_case_indent_levels(tmp_path):
    """-ci adds a level for case branches on top of the chosen indent."""
    # CATCHES: case patterns and their bodies sit at different levels
    src = "case $foo in\na)\nA\n;;\nesac\n"
    res = run_shfmt(["-ci", "-i=2"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $foo in",
        "  a)",
        "    A",
        "    ;;",
        "esac",
    )
