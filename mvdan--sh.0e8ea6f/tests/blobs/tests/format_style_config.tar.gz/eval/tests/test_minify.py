"""Tests for the -mn/--minify printer flag and its link to --simplify."""

from conftest import guard, lines, run_shfmt

KITCHEN = (
    "#!/bin/bash\n"
    "# a comment\n"
    "foo() {\n"
    "\tbar   $@\n"
    '\tbaz "${var}"   # trailing comment\n'
    "}\n"
    "if foo; then\n"
    "\tbar\n"
    "fi\n"
    "for x in a b c; do\n"
    "\techo ${x}\n"
    "done\n"
    "case $y in\n"
    "a) echo one ;;\n"
    "b)\n"
    "\techo two\n"
    "\t;;\n"
    "esac\n"
    "foo \\\n"
    "\tbar\n"
    'echo "a very long string"\n'
    "a=$(( 1 + 2 ))\n"
)

MINIFIED = lines(
    "#!/bin/bash",
    "foo(){",
    "bar $@",
    'baz "$var"',
    "}",
    "if foo;then",
    "bar",
    "fi",
    "for x in a b c;do",
    "echo $x",
    "done",
    "case $y in",
    "a)echo one;;",
    "b)echo two",
    "esac",
    "foo \\",
    "bar",
    'echo "a very long string"',
    "a=$((1+2))",
)


def test_minify_strips_comments_and_indentation(tmp_path):
    """-mn drops comments, indentation and padding to shrink the output."""
    # CATCHES: comments vanish entirely and no indentation is emitted
    res = run_shfmt(["-mn"], input=KITCHEN, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == MINIFIED


def test_minify_drops_spaces_after_keywords_and_semicolons(tmp_path):
    """-mn removes the space after 'then'/'do' and around pipes and &&."""
    # CATCHES: 'if a; then b; fi | c && d' collapses to 'a;then b;fi|c&&d'
    src = "if a; then b; fi | c && d\nx=$(foo   bar)\n"
    res = run_shfmt(["-mn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "if a;then b;fi|c&&d\nx=$(foo bar)\n"


def test_minify_drops_closing_double_semicolon(tmp_path):
    """The final ';;' before esac is dropped when minifying."""
    # CATCHES: only the last terminator disappears, earlier ones stay
    src = "case $y in\na) echo one ;;\nb)\n\techo two\n\t;;\nesac\n"
    res = run_shfmt(["-mn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "case $y in",
        "a)echo one;;",
        "b)echo two",
        "esac",
    )


def test_minify_keeps_heredoc_bodies_and_delimiters(tmp_path):
    """Here-documents keep their newlines and body text when minifying."""
    # CATCHES: the heredoc body and delimiter are never joined onto one line
    src = "foo() {\n\tcat <<EOF\n\t\tsome text\nEOF\n\tbar\n}\n"
    res = run_shfmt(["-mn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo(){",
        "cat <<EOF",
        "\t\tsome text",
        "EOF",
        "bar",
        "}",
    )


def test_minify_implies_simplify(tmp_path):
    """-mn also simplifies: quotes and braces are removed."""
    # CATCHES: minification implies --simplify without the flag being given
    src = '[[ -n "${foo}" ]]\necho ${x}\n'
    res = run_shfmt(["-mn"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "[[ -n $foo ]]\necho $x\n"
    plain = run_shfmt([], input=src, cwd=guard(tmp_path))
    assert plain.stdout == src


def test_simplify_flag_alone_keeps_formatting(tmp_path):
    """--simplify rewrites the code but keeps the normal layout."""
    # CATCHES: -s removes quotes inside [[ ]] yet keeps indentation
    src = 'foo() {\n\t[[ -n "${foo}" ]]\n}\n'
    res = run_shfmt(["-s"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == lines(
        "foo() {",
        "\t[[ -n ${foo} ]]",
        "}",
    )


def test_minify_ignores_indent_flag(tmp_path):
    """-mn ignores -i: nothing is indented even with -i=4."""
    # CATCHES: minify has priority over the indentation setting
    src = "foo() {\n\tbar\n}\n"
    res = run_shfmt(["-mn", "-i=4"], input=src, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "foo(){\nbar\n}\n"


def test_minify_long_form(tmp_path):
    """--minify is the long spelling of -mn."""
    # CATCHES: the long option must be wired to the same printer option
    res = run_shfmt(["--minify"], input=KITCHEN, cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == MINIFIED


def test_minify_nested_subshell_forces_newline(tmp_path):
    """-mn breaks the line after '(' when the first stmt is a subshell."""
    # CATCHES: a space after '(' would read as '( (' while joining costs
    # bytes, so minify instead forces a newline right after the paren.
    res = run_shfmt(["-mn"], input="( (echo hi); x )\n", cwd=guard(tmp_path))
    assert res.returncode == 0
    assert res.stdout == "(\n(echo hi)\nx)\n"
