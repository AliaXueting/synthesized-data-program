"""Validation of ``[[ ]]`` conditional and ``(( ))`` arithmetic commands.

The gosh engine parses conditional expressions with test.go's grammar and
arithmetic commands with the same expression parser as ``$(( ))``.  The
shipped reference exposes exactly that validation layer: malformed
conditionals and arithmetic commands are refused at parse time with precise
diagnostics, while the classic ``[ ]`` and bare ``test`` forms go through as
plain words with no validation at all.  A re-implementation that accepted the
same shapes (or rejected the classic ones) would break every expectation here.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

import pytest

from conftest import run_script


def test_complex_expr_needs_operator_after_second_operand():
    """`[[ a = b = c ]]` rejects the third operand position."""
    res = run_script("[[ a = b = c ]]\n")
    # CATCHES: once `a = b` forms a complete binary expression the grammar
    # only allows `&&`, `||` or `]]`; a third operand is a parse error
    # pointing at the stray `=` on column 10, not a runtime test failure.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:10: expected `&&`, `||` or `]]` after complex expr\n"
    )


@pytest.mark.parametrize("source", ["[[ -f ]]\n", "[[ a == ]]\n"])
def test_binary_operator_consumes_the_closing_brackets(source):
    """A trailing binary operator swallows `]]` as its operand and hits EOF."""
    res = run_script(source)
    # CATCHES: `-f` is unary and `==` binary, so the `]]` word is eaten as
    # the missing operand and the diagnostic becomes the generic unclosed
    # `[[` error reported at 1:1 rather than anything about the operator.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: reached EOF without matching `[[` with `]]`\n"


def test_negation_inside_conditional_needs_an_expression():
    """`[[ ! ]]` refuses the negation that has nothing to negate."""
    res = run_script("[[ ! ]]\n")
    # CATCHES: `!` inside a conditional must be followed by an expression;
    # the error is reported at the `!` itself (column 4), and exit is 1.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:4: `!` must be followed by an expression\n"


@pytest.mark.parametrize(
    "source, column, operator",
    [
        ("[[ a -a b ]]\n", 6, "-a"),
        ("[[ a | b ]]\n", 6, "|"),
        ("[[ -n a b ]]\n", 9, "b"),
    ],
)
def test_unusable_word_is_reported_as_an_invalid_operator(source, column, operator):
    """Any word that cannot continue the expression is an invalid operator."""
    res = run_script(source)
    # CATCHES: the conditional grammar has no operand slot after a complete
    # expression, so `-a`, `|` or a plain word there all yield the same
    # `not a valid test operator` wording at the offending column.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:%d: not a valid test operator: `%s`\n" % (column, operator.encode())
    )


def test_unbalanced_paren_inside_conditional_names_litword():
    """An unclosed `(` inside `[[ ]]` fails with the LitWord wording."""
    res = run_script("[[ ( a ]]\n")
    # CATCHES: the conditional's `(` is closed by `)` only, so the `]]` word
    # cannot balance it; the parser reports `reached LitWord` (the internal
    # token name for `]]`) instead of the usual EOF wording.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:4: reached LitWord without matching `(` with `)`\n"


@pytest.mark.parametrize(
    "source, opener", [("[[ ]]\n", "[["), ("(( ))\n", "(("), ("((;))\n", "((")]
)
def test_empty_conditional_and_arithmetic_commands(opener, source):
    """Empty `[[ ]]` and `(( ))` bodies are rejected identically."""
    res = run_script(source)
    # CATCHES: both compound commands demand an expression right after the
    # opener; the shared wording names the opener at 1:1, and even `((;))`
    # is treated as empty rather than as a stray semicolon.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:1: `%s` must be followed by an expression\n" % opener.encode()
    )


@pytest.mark.parametrize(
    "source, operator", [("((1+))\n", "+"), ("((a=))\n", "=")]
)
def test_dangling_arithmetic_operator_in_a_command(source, operator):
    """`((x+))` / `((x=))` reject the trailing operator at column 4."""
    res = run_script(source)
    # CATCHES: an arithmetic command whose expression ends in a binary
    # operator is a parse error naming the operator, not an evaluation
    # error; the position is the operator column (4) inside `((`.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:4: `%s` must be followed by an expression\n" % operator.encode()
    )


def test_leading_comma_in_an_arithmetic_command():
    """`((,))` reports that a comma must follow an expression."""
    res = run_script("((,))\n")
    # CATCHES: the comma operator needs a left operand first; this wording
    # (`must follow`, not `must be followed by`) is unique to the comma.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:3: `,` must follow an expression\n"


def test_empty_arithmetic_expansion_inside_a_word():
    """An empty `$(( ))` expansion in a word is rejected at the `$`."""
    res = run_script("echo $(( ))\n")
    # CATCHES: the arithmetic *expansion* shares the expression grammar but
    # reports the `$((` opener at the `$` column (6), distinct from the
    # `((` command wording at 1:1.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:6: `$((` must be followed by an expression\n"


@pytest.mark.parametrize(
    "source",
    [
        "[[ a =~ b ]]\n",
        "[[ ! -f x ]]\n",
        "[[ a < b && c > d ]]\n",
        "[[ -z $x || -n $y ]]\n",
        "[[ a = b && c = d ]]\n",
    ],
)
def test_valid_conditional_operators_roundtrip_verbatim(source):
    """Regex match, negation, ordering and logical operators all re-print as-is."""
    res = run_script(source)
    # CATCHES: every operator the conditional grammar accepts is preserved
    # byte for byte on one line, including `=~`, `<`/`>` ordering and `!`
    # before a unary operator.
    assert res.returncode == 0
    assert res.stdout == source.encode()
    assert res.stderr == b""


@pytest.mark.parametrize(
    "source",
    [
        "[ a -a b ]\n",
        "[ a = b = c ]\n",
        "[ ! a = b ]\n",
        "[ -f ]\n",
        "test a = b = c\n",
    ],
)
def test_classic_test_forms_are_not_validated(source):
    """`[ ]` and bare `test` accept shapes the `[[ ]]` grammar rejects."""
    res = run_script(source)
    # CATCHES: the classic test command is just a word list at statement
    # level -- `-a`, four operands, a dangling `-f` and even `test` with too
    # many arguments all parse and re-print verbatim, proving the validation
    # lives only in the `[[ ]]`/`(( ))` grammars.
    assert res.returncode == 0
    assert res.stdout == source.encode()
    assert res.stderr == b""


def test_closing_brackets_on_the_next_line_are_rejoined():
    """A `]]` on its own line joins the condition onto one line."""
    res = run_script("[[ a == b\n]]\n")
    # CATCHES: unlike `{`/`}` bodies, the conditional always re-prints on a
    # single line even when the author broke before the closer.
    assert res.returncode == 0
    assert res.stdout == b"[[ a == b ]]\n"
    assert res.stderr == b""


def test_conditional_continuation_line_gains_a_tab():
    """A broken `&&` inside `[[ ]]` indents the continuation with one tab."""
    res = run_script("[[ a == b &&\nc == d ]]\n")
    # CATCHES: the binary operator keeps its trailing position and the
    # continuation operand is indented with a single tab, matching the
    # statement-list continuation style.
    assert res.returncode == 0
    assert res.stdout == b"[[ a == b &&\n\tc == d ]]\n"
    assert res.stderr == b""
