"""Edge-of-the-statement-layer behaviour of the shipped reference binary.

These tests continue pinning the statement layer the gosh engine would drive
(runner.go: empty compound bodies, pipelines of compound statements, negation
and `time` prefixes, function definition quirks) plus the word-level and
comment-level edges that live inside a statement.  The shipped reference
contains no interpreter, so every expectation is a recorded round-trip or a
recorded parse diagnostic: nothing is executed, and a re-implementation that
structured any of these statements differently breaks the expectations.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

import pytest

from conftest import run_script


def test_case_with_no_items_prints_on_two_lines():
    """A case statement with zero clauses keeps `in` and `esac` on own lines."""
    res = run_script("case x in esac\n")
    assert res.returncode == 0
    assert res.stdout == b"case x in\nesac\n"
    # CATCHES: the clause-less case never collapses to the single input line;
    # the same two-line layout is produced whether or not the author already
    # broke the line before `esac`.
    res2 = run_script("case x in\nesac\n")
    assert res2.returncode == 0
    assert res2.stdout == b"case x in\nesac\n"


def test_case_item_body_and_terminator_quirks():
    """An empty clause body is inline; an omitted final `;;` is added back."""
    res = run_script("case x in a) ;; esac\n")
    assert res.returncode == 0
    assert res.stdout == b"case x in a) ;; esac\n"
    # CATCHES: the last clause's `;;` is optional in the grammar but the
    # printer always re-inserts it, detached from the last body word.
    res2 = run_script("case x in a) echo A; esac\n")
    assert res2.returncode == 0
    assert res2.stdout == b"case x in a) echo A ;; esac\n"


def test_case_terminator_on_its_own_line_gains_body_indent():
    """A `;;` at column zero on its own line is indented to the body level."""
    res = run_script("case $x in\na)\n\techo A\n;;\nesac\n")
    # CATCHES: the terminator line is re-indented with one tab like the body
    # statements, instead of staying at the column the author wrote it at.
    assert res.returncode == 0
    assert res.stdout == b"case $x in\na)\n\techo A\n\t;;\nesac\n"


def test_empty_brace_group_is_rejected():
    """`{ }` with no statements is a parse error, also inside a function."""
    res = run_script("{ }\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: `{` must be followed by a statement list\n"
    # CATCHES: the same empty-body diagnostic fires for a function body, with
    # the position moved to the `{` itself (column 5) rather than the `f()`.
    res2 = run_script("f() { }\n")
    assert res2.returncode == 1
    assert res2.stderr == b"<standard input>:1:5: `{` must be followed by a statement list\n"


@pytest.mark.parametrize("source", ["()\n", "f()\n", "function f\n"])
def test_bodyless_function_uses_the_foo_wording(source):
    """`()`, `f()` and `function f` with no body share one `foo()` diagnostic."""
    res = run_script(source)
    # CATCHES: the diagnostic names the placeholder `foo()`, not the actual
    # function name, and is anchored at 1:1 for all three spellings.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: `foo()` must be followed by a statement\n"


def test_function_brace_on_the_next_line_is_rejoined():
    """`f()` and a `{` body on separate lines are printed on one line."""
    res = run_script("f()\n{ :; }\n")
    # CATCHES: like `then` and `do`, the function's opening brace is glued
    # back onto the definition, so the split never survives a round-trip.
    assert res.returncode == 0
    assert res.stdout == b"f() { :; }\n"
    assert res.stderr == b""


def test_space_before_function_parens_is_dropped():
    """`function f ()` loses the space between the name and the parens."""
    res = run_script("function f () { :; }\n")
    # CATCHES: only the `function f()` spelling is canonical; extra spaces
    # before the parens are normalised away while the keyword form survives.
    assert res.returncode == 0
    assert res.stdout == b"function f() { :; }\n"


def test_multiline_subshell_function_body_is_kept():
    """A subshell function body already laid out on lines stays that way."""
    res = run_script("f() (\n\ta\n)\n")
    # CATCHES: the subshell body keeps its multi-line layout with the closing
    # paren on its own line, unlike the inline `f() (echo hi)` form.
    assert res.returncode == 0
    assert res.stdout == b"f() (\n\ta\n)\n"


def test_two_functions_on_one_line_are_split():
    """`;` between two function definitions becomes a line break."""
    res = run_script("f() { a; }; g() { b; }\n")
    # CATCHES: the statement separator splits function definitions onto
    # separate lines exactly like simple statements.
    assert res.returncode == 0
    assert res.stdout == b"f() { a; }\ng() { b; }\n"


def test_pipelines_of_compound_statements_roundtrip():
    """Brace groups, loops and ifs may all be pipeline stages, kept inline."""
    script = "{ a; } | b\nwhile a; do b; done | c\nif a; then b; fi | c\n"
    res = run_script(script)
    # CATCHES: a compound statement is a legal pipeline stage and keeps its
    # single-line layout; the pipe operator does not force a re-layout.
    assert res.returncode == 0
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_multiline_subshell_as_a_pipeline_stage():
    """A multi-statement subshell stage explodes; `| next` follows the `)`."""
    res = run_script("(a; b) | c\n")
    # CATCHES: the subshell body splits onto lines and the pipe operator
    # stays on the closing-paren line rather than the last inner statement.
    assert res.returncode == 0
    assert res.stdout == b"(\n\ta\n\tb\n) | c\n"


def test_background_after_a_pipeline():
    """`&` after the last pipeline stage stays attached to that line."""
    res = run_script("a | b &\n")
    # CATCHES: the background operator binds to the whole pipeline and is
    # printed after its final stage, not after the first.
    assert res.returncode == 0
    assert res.stdout == b"a | b &\n"


def test_continuation_lines_gain_a_tab():
    """A line broken after `&&` or `|` has its continuation indented a tab."""
    res = run_script("a &&\nb\n")
    assert res.returncode == 0
    assert res.stdout == b"a &&\n\tb\n"
    assert run_script("a |\nb\n").stdout == b"a |\n\tb\n"
    # CATCHES: the same one-tab continuation indent applies inside an `if`
    # header, with `; then` still glued onto the last condition line.
    res3 = run_script("if a &&\nb; then c; fi\n")
    assert res3.returncode == 0
    assert res3.stdout == b"if a &&\n\tb; then c; fi\n"


def test_negation_before_compound_statements():
    """`!` prefixes subshells and brace groups; only the subshell explodes."""
    res = run_script("! (a; b)\n")
    assert res.returncode == 0
    assert res.stdout == b"! (\n\ta\n\tb\n)\n"
    # CATCHES: the negation stays before the opening paren of the exploded
    # subshell, and a brace-group or backgrounded statement keeps `! ` inline.
    res2 = run_script("! { a; }\n! a &\n")
    assert res2.returncode == 0
    assert res2.stdout == b"! { a; }\n! a &\n"


def test_time_prefix_takes_pipelines_and_subshells():
    """`time` before a pipeline or subshell round-trips; bare `time` parses."""
    script = "time a | b\ntime (ls)\ntime\n"
    res = run_script(script)
    # CATCHES: the `time` prefix applies to whole pipelines and subshells
    # without any re-layout, and a `time` with no body is still a statement.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_bare_select_loop_roundtrips():
    """`select x; do ...` with no `in` clause parses like the bare `for`."""
    res = run_script("select x; do :; done\n")
    # CATCHES: the wordless select is accepted and gains no `in` clause when
    # re-printed, mirroring the bare `for i; do` form.
    assert res.returncode == 0
    assert res.stdout == b"select x; do :; done\n"


def test_assignment_value_forms_roundtrip():
    """Empty and command-substitution assignment values are kept verbatim."""
    script = "x=\nx=$(cmd) y=2\n"
    res = run_script(script)
    # CATCHES: an assignment with no value is still an assignment statement,
    # and a `$( )` value keeps its glued `name=` shape next to a second one.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_multiline_array_literal_is_preserved():
    """An array literal laid out one element per line keeps that layout."""
    res = run_script("a=(\n\t1\n\t2\n)\n")
    # CATCHES: the printer preserves the author's element-per-line array
    # layout instead of collapsing the literal back onto one line.
    assert res.returncode == 0
    assert res.stdout == b"a=(\n\t1\n\t2\n)\n"


def test_indirection_and_substring_expansions_roundtrip():
    """`${!x}` indirection and `${x:1:2}` substring forms survive verbatim."""
    script = "echo ${!x}\necho ${x:1:2}\n"
    res = run_script(script)
    # CATCHES: the indirection bang and the two-colon substring operator are
    # preserved byte for byte, neither split nor re-spaced.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_backslash_line_continuation_is_preserved():
    """A backslash-newline continuation is kept and the next line indented."""
    res = run_script("echo a \\\nb\n")
    # CATCHES: the continuation is not joined into one word list -- the
    # backslash-newline survives and the continued words gain a tab indent.
    assert res.returncode == 0
    assert res.stdout == b"echo a \\\n\tb\n"


def test_escaped_metacharacters_and_empty_command_word():
    """Escaped operators stay escaped; a lone `\"\"` is a valid command word."""
    script = 'echo a \\&\\& b\n""\n'
    res = run_script(script)
    # CATCHES: `\&\&` is word text, never a list operator, and a quoted-empty
    # command word parses as a statement instead of being dropped.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_legacy_fd_redirect_forms():
    """`>&f` and `<&2` parse as their own redirect operators, verbatim."""
    script = "cmd >&f\ncmd <&2\n"
    res = run_script(script)
    # CATCHES: the legacy `>&file` spelling is not rewritten to `&>file` nor
    # to a duplication form, and stdin may be duplicated from fd 2.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_redirect_order_with_a_here_string():
    """A here-string and a file redirect keep the order they were written in."""
    script = "cmd <<<x >f\ncmd >f <<<x\n"
    res = run_script(script)
    # CATCHES: unlike heredoc operators, a here-string does not migrate to
    # the end of the word list -- source order is preserved exactly.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_fd_duplication_inside_a_pipeline():
    """`2>&1` on a pipeline stage stays on that stage's line."""
    res = run_script("a 2>&1 | b\n")
    # CATCHES: the duplication binds to the first stage, not the pipeline,
    # and is printed between the stage's words and the pipe operator.
    assert res.returncode == 0
    assert res.stdout == b"a 2>&1 | b\n"


def test_persistent_exec_redirections():
    """`exec >f 2>&1` and a named-fd input on `exec` round-trip verbatim."""
    script = "exec >f 2>&1\nexec {fd}<file\n"
    res = run_script(script)
    # CATCHES: persistent redirections on `exec` are ordinary redirect lists;
    # the brace-named fd works for input too and keeps its `{fd}<` spelling.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_empty_quoted_redirect_target_is_allowed():
    """`>\"\"` is a valid (empty) target word, not a parse error."""
    res = run_script('echo >""\n')
    # CATCHES: the target of a redirect is a word, and an explicitly empty
    # quoted word passes the grammar where a missing word would not.
    assert res.returncode == 0
    assert res.stdout == b'echo >""\n'
    assert res.stderr == b""


def test_mixed_heredoc_operators_on_one_command():
    """`<<-A` and `<<B` on one command each keep their own body and rules."""
    res = run_script("cat <<-A <<B\n\tx\n\tA\ny\nB\n")
    # CATCHES: only the `<<-` heredoc strips a tab from its terminator (`A`
    # is de-tabbed while its body line keeps the tab); the plain `<<B`
    # terminator stays at column zero exactly as written.
    assert res.returncode == 0
    assert res.stdout == b"cat <<-A <<B\n\tx\nA\ny\nB\n"


def test_heredoc_on_a_pipeline_stage():
    """A heredoc operator on the first stage stays on that stage's line."""
    res = run_script("cat <<EOF | wc -l\nbody\nEOF\n")
    # CATCHES: the heredoc belongs to the first pipeline stage and its body
    # still follows the whole pipeline line, terminator at column zero.
    assert res.returncode == 0
    assert res.stdout == b"cat <<EOF | wc -l\nbody\nEOF\n"


def test_heredoc_inside_a_subshell():
    """A heredoc inside a subshell forces the multi-line subshell layout."""
    res = run_script("(cat <<EOF\nx\nEOF\n)\n")
    # CATCHES: the heredoc body keeps the subshell's statements multi-line,
    # so the closing paren lands on its own line after the terminator.
    assert res.returncode == 0
    assert res.stdout == b"(\n\tcat <<EOF\nx\nEOF\n)\n"


def test_comment_placement_roundtrip():
    """Comments on their own lines and trailing words are kept verbatim."""
    script = "# lead\necho hi # trailing\necho hi #nospace\n# hello\n"
    res = run_script(script)
    assert res.returncode == 0
    assert res.stdout == script.encode()
    # CATCHES: a comment is never re-spaced (`#nospace` stays glued) and a
    # comment-only program still gains its missing final newline.
    res2 = run_script("# hello")
    assert res2.returncode == 0
    assert res2.stdout == b"# hello\n"


def test_comment_in_an_if_header_migrates_to_the_then():
    """A comment on the if-condition line re-attaches after the joined `then`."""
    res = run_script("if a # c\nthen b; fi\n")
    # CATCHES: when `then` is glued onto the condition, the trailing comment
    # travels with the `then` keyword (`if a; then # c`) instead of staying
    # behind on the condition or being dropped.
    assert res.returncode == 0
    assert res.stdout == b"if a; then # c\n\tb\nfi\n"


def test_comments_are_not_collapsed_like_blank_lines():
    """Comment lines never merge, unlike runs of blank lines."""
    res = run_script("echo a\n# c1\n\n# c2\necho b\n")
    # CATCHES: blank-line collapsing does not touch comments -- both comment
    # lines and the blank line between them survive the round-trip.
    assert res.returncode == 0
    assert res.stdout == b"echo a\n# c1\n\n# c2\necho b\n"


def test_comments_inside_function_and_case_bodies():
    """A comment line inside a function or case body stays in place."""
    script = "f() {\n\t# note\n\ta\n}\ncase $x in\n# note\na) b ;;\nesac\n"
    res = run_script(script)
    # CATCHES: body comments keep their line and indentation inside both a
    # function body and between case patterns, with no re-layout.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_shebang_is_preserved_and_does_not_switch_dialect():
    """A `#!` line on stdin is a preserved comment; the grammar stays bash."""
    script = "#!/bin/sh\n[[ -n $x ]]\necho a[1] b\n"
    res = run_script(script)
    # CATCHES: stdin programs are parsed with the default grammar no matter
    # the shebang text -- the POSIX-incompatible `[[ ]]` still parses, and
    # the shebang line itself is echoed back verbatim.
    assert res.returncode == 0
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_shell_option_and_builtin_flag_words_roundtrip():
    """The full set/shopt option spellings and builtin flags round-trip."""
    script = (
        ":\n"
        "true\n"
        "false\n"
        "exit\n"
        "exit 0\n"
        "return 1\n"
        "break\n"
        "continue 2\n"
        "set -a\n"
        "set -e\n"
        "set -f\n"
        "set -n\n"
        "set -u\n"
        "set -x\n"
        "set -o pipefail\n"
        "set +o xtrace\n"
        "set -o errexit -o nounset\n"
        "set --\n"
        "shopt -s globstar nullglob\n"
        "shopt -u extglob\n"
        "shopt -p\n"
        "command -V ls\n"
        "type -a ls\n"
        "type -t ls\n"
        "hash -r\n"
        "getopts ab: opt\n"
        "read -s -p 'x: ' pass\n"
        "read -a arr\n"
        "read -r a b c\n"
        "IFS= read -r line\n"
        "IFS=: read -ra parts\n"
        "readarray -d : arr\n"
        "mapfile -t lines\n"
        "local x=1\n"
        "local -r y=2\n"
        "export x=1\n"
        "export -n x\n"
        "readonly z=3\n"
        "declare -n ref=x\n"
        "unalias -a\n"
        "pushd -n /tmp\n"
        "popd -n\n"
        "dirs -l\n"
        "cd -P /tmp\n"
        "cd -L .\n"
        "pwd -P\n"
        "wait\n"
        "wait $!\n"
        "eval 'echo \"hi\"'\n"
        "printf -v out '%s\\n' x\n"
        "echo -e 'a\\tb'\n"
        "echo -E 'a\\nb'\n"
        "trap 'cleanup' ERR\n"
        "trap '' INT\n"
        "trap -l\n"
        "x=$(cmd)\n"
        "exec 3>&-\n"
    )
    res = run_script(script)
    # CATCHES: every option spelling from the engine's surface (set -a..-x,
    # set -o long forms, shopt -s/-u/-p, read/getopts/readarray/mapfile flag
    # words, IFS-prefixed reads, cd -L/-P, wait, eval, printf -v) is an
    # ordinary word list to the reference -- none is executed or re-spaced.
    assert res.returncode == 0
    assert res.stdout == script.encode()
    assert res.stderr == b""
