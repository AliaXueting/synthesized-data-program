"""Control-byte handling in words, comments and heredoc bodies.

The gosh engine would pass these bytes through to the running command's
argv; the shipped reference contains no interpreter, but its printer runs
the re-printed program through an aligning writer, so control bytes that
survive inside word literals change the SHAPE of the printed output:

* a form feed (``\\x0c``) inside a word, a quoted string, a comment or a
  heredoc body terminates the printed line and starts a new one;
* a vertical tab (``\\x0b``) acts as an aligned tab stop between the
  surrounding text (usually collapsing to a single space, but padded when
  a neighbouring line has a wider cell);
* a UTF-8 BOM or another raw control byte is just part of the word and
  round-trips byte for byte.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

from conftest import run_script


def test_form_feed_inside_a_word_breaks_the_output_line():
    """A form feed inside a word literal ends the printed line there."""
    res = run_script("x\x0cy\n")
    assert res.returncode == 0
    assert res.stdout == b"x\ny\n"
    # CATCHES: the form feed is kept inside the single parsed word, but the
    # printer emits a line break in its place, splitting the word across
    # two output lines (each further form feed adds another break).
    res2 = run_script("echo a\x0cb\x0cc\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo a\nb\nc\n"


def test_form_feed_leaves_the_following_space_at_line_start():
    """Text after the form feed keeps its leading space on the new line."""
    res = run_script("echo a\x0c b\n")
    assert res.returncode == 0
    assert res.stdout == b"echo a\n b\n"
    # CATCHES: the word-separator space that followed the form feed lands
    # at the start of the continuation line; a real newline after the form
    # feed adds an extra blank line rather than merging with the break.
    res2 = run_script("x\x0c\ny\n")
    assert res2.returncode == 0
    assert res2.stdout == b"x\n\ny\n"


def test_form_feed_at_the_start_prints_a_leading_blank_line():
    """A leading form feed prints an empty line before the first statement."""
    res = run_script("\x0cecho hi\n")
    assert res.returncode == 0
    assert res.stdout == b"\necho hi\n"
    # CATCHES: unlike real blank lines, repeated form feeds are never
    # collapsed — each one prints its own break, so two form feeds produce
    # two blank lines between the statements.
    res2 = run_script("echo a\n\x0c\x0cecho b\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo a\n\n\necho b\n"


def test_form_feed_breaks_lines_inside_quoted_words():
    """The form-feed break happens even inside single or double quotes."""
    res = run_script("echo 'a\x0cb'\n")
    assert res.returncode == 0
    assert res.stdout == b"echo 'a\nb'\n"
    # CATCHES: the quote characters themselves stay on their original
    # lines — only the form feed's position becomes a line break, so the
    # closing quote ends up after the break for both quote styles.
    res2 = run_script('echo "a\x0cb"\n')
    assert res2.returncode == 0
    assert res2.stdout == b'echo "a\nb"\n'


def test_form_feed_in_indented_context_does_not_indent_the_rest():
    """The text after a form feed lands at column 0 even when indented."""
    res = run_script("f() {\n\techo a\x0cb\n}\n")
    assert res.returncode == 0
    assert res.stdout == b"f() {\n\techo a\nb\n}\n"
    # CATCHES: the continuation is NOT re-indented to the function body's
    # tab level, and a `<<-` heredoc body behaves the same — the byte after
    # the break is printed with no leading tab added.
    res2 = run_script("cat <<-EOF\n\ta\x0cb\nEOF\n")
    assert res2.returncode == 0
    assert res2.stdout == b"cat <<-EOF\n\ta\nb\nEOF\n"


def test_form_feed_breaks_heredoc_bodies_and_comments():
    """Form feeds break lines inside plain heredoc bodies and comments."""
    res = run_script("cat <<EOF\na\x0cb\nEOF\n")
    assert res.returncode == 0
    assert res.stdout == b"cat <<EOF\na\nb\nEOF\n"
    # CATCHES: a form feed inside a comment also ends the comment's line,
    # so the comment text after it continues on the next output line.
    res2 = run_script("# comment\x0cnext\n")
    assert res2.returncode == 0
    assert res2.stdout == b"# comment\nnext\n"


def test_vertical_tab_becomes_a_single_space():
    """A vertical tab in a word re-prints as a single space."""
    res = run_script("x\x0by\n")
    assert res.returncode == 0
    assert res.stdout == b"x y\n"
    # CATCHES: consecutive vertical tabs produce one space (the empty cell
    # between them is discarded), a trailing one pads with a single space,
    # and inside quotes the byte becomes a space just the same.  Each case
    # must run in its own program: vtab cells align across ALL output
    # lines, so combining them would widen the padding.
    res2 = run_script("x\x0b\x0by\n")
    assert res2.returncode == 0
    assert res2.stdout == b"x y\n"
    res3 = run_script("x\x0by\x0bz\n")
    assert res3.returncode == 0
    assert res3.stdout == b"x y z\n"
    res4 = run_script("a\x0b\n")
    assert res4.returncode == 0
    assert res4.stdout == b"a \n"
    res5 = run_script('echo "a\x0bb"\n')
    assert res5.returncode == 0
    assert res5.stdout == b'echo "a b"\n'


def test_vertical_tab_is_an_aligned_tab_stop():
    """Vertical tabs align neighbouring lines like tab stops."""
    res = run_script("x\x0by\naaaa\x0by\n")
    assert res.returncode == 0
    assert res.stdout == b"x    y\naaaa y\n"
    # CATCHES: the cell before the vertical tab is padded to the width of
    # the widest same-column cell plus one, so `x` gains four spaces to
    # line up with `aaaa`; word-separator spaces after the tab stack with
    # the padding, giving two spaces between each word.
    res2 = run_script("echo a\x0b b\x0b c\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo a  b  c\n"


def test_bom_and_control_bytes_round_trip_raw():
    """A BOM or other raw control byte inside a word is preserved."""
    res = run_script("﻿echo hi\n")
    assert res.returncode == 0
    assert res.stdout == b"\xef\xbb\xbfecho hi\n"
    # CATCHES: the UTF-8 BOM is not stripped or treated as whitespace — it
    # survives at the start of the program and glued inside a word, and an
    # otherwise unhandled control byte like 0x0f round-trips byte for byte.
    res2 = run_script("echo ﻿x\nx\x0fy\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo \xef\xbb\xbfx\nx\x0fy\n"
