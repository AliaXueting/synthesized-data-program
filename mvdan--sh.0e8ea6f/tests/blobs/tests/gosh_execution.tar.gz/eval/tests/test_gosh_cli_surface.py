"""CLI surface of the gosh driver as shipped in the reference binary.

These tests pin the driver-level contract of ``cmd/gosh`` that the shipped
reference binary actually exhibits.  The reference in this workspace is built
from ``./cmd/shfmt`` of mvdan/sh, so it contains no interpreter: every gosh
driver behaviour listed in the module description is observable only as its
*absence*.  Recording that absence precisely is what these tests do -- a
re-implementation that grew a shell mode, or that executed scripts instead of
parsing them, would break every assertion here.

All expectations below were recorded by running ``./executable``.
"""

from __future__ import annotations

from conftest import run_gosh, run_gosh_argv, write_script

# Exact bytes recorded from the reference for an unrecognised -c flag.
FLAG_ERROR = b"flag provided but not defined: -c\n"
USAGE_HEADER = b"usage: shfmt [flags] [path ...]"


def test_dash_c_is_not_a_defined_flag():
    """`gosh -c 'command'` is rejected: the reference has no -c flag at all."""
    res = run_gosh("echo hello world")
    # CATCHES: gosh's -c command mode is absent; the reference rejects the flag
    # outright with exit 2 and the formatter's usage text on stderr.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(FLAG_ERROR)
    assert USAGE_HEADER in res.stderr


def test_empty_dash_c_is_rejected_like_any_other():
    """An explicitly empty `-c ''` is not the gosh no-op; it is a flag error."""
    res = run_gosh("")
    # CATCHES: gosh detects an explicitly set -c via flag.Visit and runs nothing;
    # the reference instead fails flag parsing before that logic can run.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(FLAG_ERROR)


def test_dash_c_equals_form_is_rejected():
    """`-c=command` (Go flag's '=' form) is rejected identically to `-c cmd`."""
    res = run_gosh_argv(["-c=echo hi"])
    # CATCHES: even the '-c=value' spelling trips the same undefined-flag error,
    # so no argument spelling reaches a command-execution path.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(FLAG_ERROR)


def test_exit_status_is_not_mirrored_from_dash_c():
    """`gosh -c 'exit 3'` does not make the process exit 3."""
    res = run_gosh("exit 3")
    # CATCHES: gosh mirrors the script's exit status through interp.ExitStatus;
    # the reference exits 2 from the flag error instead of 3.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(FLAG_ERROR)


def test_dash_c_wins_over_script_arguments():
    """`-c` plus a script path never opens the path: the flag error comes first."""
    res = run_gosh_argv(["-c", "echo A", "/definitely/not/here.sh"])
    # CATCHES: gosh's commandSet branch runs only the -c string, so a bad script
    # path is never reported; the reference fails earlier, in flag parsing.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(FLAG_ERROR)
    assert b"no such file or directory" not in res.stderr


def test_dash_c_performs_no_redirection(tmp_path):
    """A `-c` command containing a redirection creates no file."""
    target = tmp_path / "should-not-exist.txt"
    res = run_gosh("echo hi > %s" % target)
    # CATCHES: no interpreter runs, so the > redirection never opens the file.
    assert res.returncode == 2
    assert not target.exists()
    assert res.stderr.startswith(FLAG_ERROR)


def test_missing_script_path_error_wording(tmp_path):
    """A missing script argument reports `lstat`, not gosh's `open` error."""
    missing = tmp_path / "absent.sh"
    res = run_gosh_argv([str(missing)])
    # CATCHES: gosh's os.Open path reports `open <path>: no such file or directory`
    # and exits 1; the reference reports `lstat` instead -- same exit code,
    # different wording, which pins which code path ran.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"lstat %s: no such file or directory\n" % str(missing).encode()


def test_script_argument_is_printed_not_executed(tmp_path):
    """A script file argument comes back as formatted source, never as output."""
    script = write_script(tmp_path, "s.sh", "echo   hi\n")
    res = run_gosh_argv([str(script)])
    # CATCHES: gosh runs script arguments in order and prints `hi`; the reference
    # parses and reprints the source with its canonical spacing instead.
    assert res.returncode == 0
    assert res.stdout == b"echo hi\n"


def test_script_exit_status_is_not_mirrored(tmp_path):
    """A script whose only statement is `exit 3` still exits 0."""
    script = write_script(tmp_path, "exit-only.sh", "exit 3\n")
    res = run_gosh_argv([str(script)])
    # CATCHES: gosh mirrors the script's exit status; the reference executes
    # nothing and exits 0 while echoing the `exit 3` statement back.
    assert res.returncode == 0
    assert res.stdout == b"exit 3\n"


def test_multiple_script_arguments_run_in_order(tmp_path):
    """Several script arguments are processed in the order they were given."""
    first = write_script(tmp_path, "a.sh", "echo   one\n")
    second = write_script(tmp_path, "b.sh", "if true;then\n echo two;fi\n")
    res = run_gosh_argv([str(first), str(second)])
    # CATCHES: gosh runs each file in order and would print `one` then `two`;
    # the reference emits both files' formatted source in the same order.
    assert res.returncode == 0
    assert res.stdout == b"echo one\nif true; then\n\techo two\nfi\n"


def test_missing_later_script_does_not_stop_the_run(tmp_path):
    """A missing script argument errors but later files are still processed."""
    good = write_script(tmp_path, "good.sh", "echo   one\n")
    absent = tmp_path / "absent.sh"
    res = run_gosh_argv([str(good), str(absent), str(good)])
    # CATCHES: gosh's runPath loop returns on the first os.Open failure, so a
    # file listed after a missing one never runs; the reference keeps going and
    # emits the good file twice with the lstat error in between.
    assert res.returncode == 1
    assert res.stdout == b"echo one\necho one\n"
    assert res.stderr == b"lstat %s: no such file or directory\n" % str(absent).encode()


def test_stdin_script_is_printed_not_executed():
    """A non-terminal stdin script is echoed back rather than run."""
    res = run_gosh_argv([], stdin="echo one\necho two\nexit 4\n")
    # CATCHES: gosh runs non-terminal stdin as a script and exits 4; the
    # reference prints the source verbatim and exits 0.
    assert res.returncode == 0
    assert res.stdout == b"echo one\necho two\nexit 4\n"


def test_stdin_command_not_found_is_not_an_error():
    """An unknown command on stdin yields status 127 in gosh, 0 here."""
    res = run_gosh_argv([], stdin="nosuchcommand123\n")
    # CATCHES: gosh prints `nosuchcommand123: executable file not found in $PATH`
    # and exits 127; the reference echoes the word and exits 0.
    assert res.returncode == 0
    assert res.stdout == b"nosuchcommand123\n"
    assert res.stderr == b""


def test_stdin_xtrace_produces_no_trace():
    """`set -x` on stdin emits no trace lines because nothing is executed."""
    res = run_gosh_argv([], stdin="set -x\necho hi\n")
    # CATCHES: gosh's trace.go writes `+ echo hi` to stderr under xtrace; the
    # reference produces no stderr at all and prints the two statements.
    assert res.returncode == 0
    assert res.stdout == b"set -x\necho hi\n"
    assert res.stderr == b""


def test_stdin_exit_trap_does_not_fire():
    """A trap on EXIT never runs because no statement is executed."""
    res = run_gosh_argv([], stdin="trap 'echo trapped' EXIT\necho body\n")
    # CATCHES: gosh runs the EXIT trap after the body, printing `trapped`; the
    # reference prints both lines as source with no extra output.
    assert res.returncode == 0
    assert res.stdout == b"trap 'echo trapped' EXIT\necho body\n"
    assert res.stderr == b""


def test_stdin_arithmetic_is_not_evaluated():
    """`$((1+2))` is reprinted with printer spacing, not evaluated to 3."""
    res = run_gosh_argv([], stdin="echo $((1+2))\n")
    # CATCHES: gosh evaluates the arithmetic expansion and prints `3`; the
    # reference normalises it to `$((1 + 2))` inside the echoed source.
    assert res.returncode == 0
    assert res.stdout == b"echo $((1 + 2))\n"


def test_stdin_function_definition_is_just_text():
    """A function definition on stdin is reprinted, and its body never runs."""
    res = run_gosh_argv([], stdin="f() {\n  echo in\n}\nf\n")
    # CATCHES: gosh registers f and prints `in` on the trailing call; the
    # reference re-indents the definition and echoes the call unchanged.
    assert res.returncode == 0
    assert res.stdout == b"f() {\n\techo in\n}\nf\n"


def test_stdin_pipeline_is_not_run():
    """A pipeline on stdin is echoed as source instead of being executed."""
    res = run_gosh_argv([], stdin="echo hi | tr a-z A-Z\n")
    # CATCHES: gosh forks the pipeline and prints `HI`; the reference prints the
    # pipeline text, proving no statement-level execution happened.
    assert res.returncode == 0
    assert res.stdout == b"echo hi | tr a-z A-Z\n"


def test_stdin_heredoc_is_not_fed_to_a_command():
    """A heredoc body stays attached to its command instead of being printed."""
    res = run_gosh_argv([], stdin="cat <<EOF\nhi\nEOF\n")
    # CATCHES: gosh feeds `hi` to cat and prints `hi`; the reference prints the
    # whole construct, heredoc marker and body included.
    assert res.returncode == 0
    assert res.stdout == b"cat <<EOF\nhi\nEOF\n"


def test_stdin_script_has_no_side_effects(tmp_path):
    """A stdin script that creates a file creates nothing."""
    marker = tmp_path / "marker-stdin.txt"
    res = run_gosh_argv([], stdin="touch %s\n" % marker)
    # CATCHES: gosh would run touch and leave the marker behind; the reference
    # leaves the filesystem untouched while echoing the command.
    assert res.returncode == 0
    assert res.stdout == b"touch %s\n" % str(marker).encode()
    assert not marker.exists()


def test_script_argument_has_no_side_effects(tmp_path):
    """A script argument that creates a file creates nothing."""
    marker = tmp_path / "marker-file.txt"
    script = write_script(tmp_path, "side-effect.sh", "touch %s\n" % marker)
    res = run_gosh_argv([str(script)])
    # CATCHES: running the script would leave the marker file behind; the
    # reference only prints the source, so the path must stay absent.
    assert res.returncode == 0
    assert res.stdout == b"touch %s\n" % str(marker).encode()
    assert not marker.exists()
