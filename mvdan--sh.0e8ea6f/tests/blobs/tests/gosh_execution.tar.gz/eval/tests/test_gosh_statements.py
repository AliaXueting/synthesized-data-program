"""Statement and control-flow level behaviour of shell programs.

The gosh engine executes parsed shell programs at the statement level
(runner.go): compound statements, loops, case, functions, pipelines and the
statement operators ``&&``/``||``/``&``/``!``.  The shipped reference binary
contains no interpreter, so the statement layer is observable through what it
does with a program instead: which statement forms parse at all, and how the
statement layer is normalised when the program is re-printed (line joining,
tab indentation, operator and terminator spacing).  A re-implementation that
structured compound statements differently -- or that actually executed the
statements -- breaks every expectation below.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode, the gosh driver's stdin path).
"""

from __future__ import annotations

import pytest

from conftest import run_gosh_argv, run_script, write_script


def test_if_elif_else_single_line_is_preserved():
    """A fully-inline if/elif/else is re-printed unchanged on one line."""
    res = run_script("if a; then b; elif c; then d; else e; fi\n")
    # CATCHES: a complete compound statement that fits on one line must
    # stay on one line; the reference neither splits nor rewraps it.
    assert res.returncode == 0
    assert res.stdout == b"if a; then b; elif c; then d; else e; fi\n"
    assert res.stderr == b""


def test_multiline_if_rejoins_then_to_the_condition():
    """A `then` on its own line is glued back to the condition with `; `."""
    res = run_script("if a\nthen\n  b\nfi\n")
    # CATCHES: the statement layer normalises `if cond\\nthen` to
    # `if cond; then`; only the body keeps its own line, indented by a tab.
    assert res.returncode == 0
    assert res.stdout == b"if a; then\n\tb\nfi\n"
    assert res.stderr == b""


def test_elif_chain_stays_on_one_line():
    """Three elif branches plus else survive a round-trip verbatim."""
    res = run_script("if a; then b; elif c; then d; elif e; then f; else g; fi\n")
    # CATCHES: elif/else keywords keep their position in the chain; the
    # reference does not reorder, merge or split the branches.
    assert res.returncode == 0
    assert res.stdout == b"if a; then b; elif c; then d; elif e; then f; else g; fi\n"


def test_else_if_is_not_collapsed_into_elif():
    """`else if ...; fi; fi` is printed back literally, not rewritten to elif."""
    res = run_script("if a; then b; else if c; then d; fi; fi\n")
    # CATCHES: the reference prints the nested statement it parsed; it
    # never applies the else-if to elif rewrite a smarter printer might.
    assert res.returncode == 0
    assert res.stdout == b"if a; then b; else if c; then d; fi; fi\n"


@pytest.mark.parametrize("keyword", ["while", "until"])
def test_while_and_until_one_liners_are_preserved(keyword):
    """while/until loops written on one line round-trip unchanged."""
    res = run_script("%s a; do b; done\n" % keyword)
    # CATCHES: both loop keywords take the same `cond; do body; done`
    # statement shape and are kept inline, including the `; do` join.
    assert res.returncode == 0
    assert res.stdout == b"%s a; do b; done\n" % keyword.encode()


def test_multiline_while_rejoins_do():
    """A `do` on its own line is glued back to the loop condition."""
    res = run_script("while a\ndo\n\tb\ndone\n")
    # CATCHES: like `then`, the `do` keyword is re-joined onto the
    # condition line and the body is re-indented with a tab.
    assert res.returncode == 0
    assert res.stdout == b"while a; do\n\tb\ndone\n"


def test_for_in_and_bare_for_roundtrip():
    """`for x in words` and the bare `for x` (implicit "$@") both parse."""
    res = run_script("for i in 1 2 3; do echo $i; done\n")
    assert res.returncode == 0
    assert res.stdout == b"for i in 1 2 3; do echo $i; done\n"
    # CATCHES: the wordless `for i; do` form is a distinct statement the
    # parser accepts (it iterates "$@" when executed); it must not be
    # rejected nor gain an `in` clause when re-printed.
    res2 = run_script("for i; do echo $i; done\n")
    assert res2.returncode == 0
    assert res2.stdout == b"for i; do echo $i; done\n"


def test_c_style_for_header_spacing_is_normalized():
    """The `for ((init; cond; post))` header gets arithmetic spacing."""
    res = run_script("for ((i=0;i<10;i+=2)); do :; done\n")
    # CATCHES: the three header clauses are re-printed with arithmetic
    # spacing (`i = 0; i < 10; i += 2`) even though the source had none.
    assert res.returncode == 0
    assert res.stdout == b"for ((i = 0; i < 10; i += 2)); do :; done\n"


def test_c_style_for_empty_parts_spacing():
    """An empty `for ((;;))` header prints as `( ; ; )` with spaces."""
    res = run_script("for((;;)); do :; done\n")
    # CATCHES: empty arithmetic clauses become a spaced `; ;` and the
    # keyword gains a space too -- `for (( ; ; ))` -- a surprising but
    # recorded normalisation of the empty C-style loop.
    assert res.returncode == 0
    assert res.stdout == b"for (( ; ; )); do :; done\n"


def test_select_loop_roundtrip():
    """The bash `select` menu loop parses and round-trips verbatim."""
    res = run_script("select x in a b; do echo $x; done\n")
    # CATCHES: `select` is a first-class loop statement in the engine's
    # grammar; it must keep its `in words` clause and inline body.
    assert res.returncode == 0
    assert res.stdout == b"select x in a b; do echo $x; done\n"


def test_case_terminators_and_patterns_get_spacing():
    """Case item bodies get a space before `;;` and pipes in patterns."""
    res = run_script("case $x in a) echo A;; b|c) echo B;; *) echo C;; esac\n")
    # CATCHES: the case terminator `;;` is printed detached from the last
    # body word (`A ;;`), and `b|c` splits into two patterns `b | c`.
    assert res.returncode == 0
    assert res.stdout == b"case $x in a) echo A ;; b | c) echo B ;; *) echo C ;; esac\n"


def test_case_fallthrough_operators_are_spaced():
    """The `;&` and `;;&` fallthrough terminators print detached from words."""
    res = run_script("case $x in a) echo A;& b) echo B;;& c) echo C;; esac\n")
    # CATCHES: bash's two fallthrough operators are distinct case-item
    # terminators and must survive as ` ;&` and ` ;;&`, not `;;`.
    assert res.returncode == 0
    assert res.stdout == b"case $x in a) echo A ;& b) echo B ;;& c) echo C ;; esac\n"


def test_case_in_keyword_is_rejoined():
    """A newline between `case $x` and `in` is collapsed."""
    res = run_script("case $x\nin\na) b;;\nesac\n")
    # CATCHES: only `in` is glued back onto the case word; the case item
    # itself keeps its line, with its terminator gaining the usual space.
    assert res.returncode == 0
    assert res.stdout == b"case $x in\na) b ;;\nesac\n"


def test_multiline_case_layout_is_preserved():
    """A case item already laid out one-word-per-line is kept that way."""
    res = run_script("case $x in\na)\n\techo A\n\t;;\nesac\n")
    # CATCHES: the statement layer preserves the author's line breaks
    # inside case items; it does not collapse the item back to one line.
    assert res.returncode == 0
    assert res.stdout == b"case $x in\na)\n\techo A\n\t;;\nesac\n"


def test_brace_and_subshell_bodies_split_onto_lines():
    """Multi-statement `{ }` and `( )` bodies are exploded to lines."""
    res = run_script("{ echo a; echo b; }\n")
    assert res.returncode == 0
    assert res.stdout == b"{\n\techo a\n\techo b\n}\n"
    # CATCHES: a brace group or subshell holding several statements is
    # always printed multi-line with tab indent; the semicolons vanish.
    res2 = run_script("(echo a; echo b)\n")
    assert res2.returncode == 0
    assert res2.stdout == b"(\n\techo a\n\techo b\n)\n"


@pytest.mark.parametrize("body", ["{ a; }", "(a)"])
def test_single_statement_bodies_stay_inline(body):
    """A one-statement brace group or subshell stays on a single line."""
    res = run_script(body + "\n")
    # CATCHES: the split from the multi-statement case does not apply to a
    # single-statement body; braces and parens hug their one statement.
    assert res.returncode == 0
    assert res.stdout == body.encode() + b"\n"


def test_function_body_splits_statements():
    """Two statements in a function body are split onto separate lines."""
    res = run_script("f() { local -r x=1; readonly y=2; }\n")
    # CATCHES: the function body statements are re-laid out one per line
    # with tab indentation, exactly like a top-level statement list.
    assert res.returncode == 0
    assert res.stdout == b"f() {\n\tlocal -r x=1\n\treadonly y=2\n}\n"


@pytest.mark.parametrize(
    ("definition", "printed"),
    [
        ("f() { echo hi; }", "f() { echo hi; }"),
        ("function f { echo hi; }", "function f { echo hi; }"),
        ("function f() { echo hi; }", "function f() { echo hi; }"),
        ("f() (echo hi)", "f() (echo hi)"),
    ],
)
def test_function_definition_forms(definition, printed):
    """All four function definition spellings are accepted and re-printed."""
    res = run_script(definition + "\n")
    # CATCHES: the engine's grammar accepts the POSIX form, the `function`
    # keyword form, both combined, and a subshell body -- each kept as-is.
    assert res.returncode == 0
    assert res.stdout == printed.encode() + b"\n"


def test_nested_compound_statements_indent_with_tabs():
    """A loop nested in a function gains one tab of indent per level."""
    res = run_script("f() {\nif a; then\nb\nfi\n}\n")
    # CATCHES: nesting depth is reflected in the reprint: the `if` gets
    # one tab, its body two; the single-statement `if` itself stays inline.
    assert res.returncode == 0
    assert res.stdout == b"f() {\n\tif a; then\n\t\tb\n\tfi\n}\n"


def test_semicolons_split_statements_onto_lines():
    """`;` between simple statements becomes a newline in the output."""
    res = run_script("x=1; export x\n")
    # CATCHES: the statement separator is normalised to a line break --
    # each statement gets its own line, so `x=1; export x` never survives.
    assert res.returncode == 0
    assert res.stdout == b"x=1\nexport x\n"


def test_background_operator_binds_to_the_last_statement():
    """`a; b &` backgrounds only `b`, and the list is split by lines."""
    res = run_script("a; b &\n")
    # CATCHES: the `&` belongs to the second statement only; the reprint
    # splits the list but keeps `&` attached to `b` on the same line.
    assert res.returncode == 0
    assert res.stdout == b"a\nb &\n"


def test_background_after_a_compound_statement():
    """`&` after a multi-statement subshell or brace group stays on the closer."""
    res = run_script("(a; b) &\n")
    assert res.returncode == 0
    assert res.stdout == b"(\n\ta\n\tb\n) &\n"
    # CATCHES: the compound body still explodes to lines, and the `&`
    # follows the closing paren/brace rather than the last inner word.
    res2 = run_script("{ a; b; } &\n")
    assert res2.returncode == 0
    assert res2.stdout == b"{\n\ta\n\tb\n} &\n"


def test_negation_prefix_forms_roundtrip():
    """`!` before a command, a pipeline or an AND-list is kept verbatim."""
    res = run_script("! false\n! a | b\n! a && b\n")
    # CATCHES: the negation operator applies to whole pipelines and lists;
    # the reference keeps the `! ` prefix attached to each statement.
    assert res.returncode == 0
    assert res.stdout == b"! false\n! a | b\n! a && b\n"


def test_stacked_negation_is_a_parse_error():
    """`! ! true` never parses: multiple negation is rejected outright."""
    res = run_script("! ! true\n")
    # CATCHES: unlike bash, the grammar forbids stacking `!`; the program
    # is refused at parse time with exit 1 and this exact diagnostic.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: cannot negate a command multiple times\n"


def test_time_and_coproc_prefixes_roundtrip():
    """`time` and `coproc` statements are re-printed verbatim."""
    res = run_script("time ls\ntime -p ls\ntime { ls; }\n")
    assert res.returncode == 0
    assert res.stdout == b"time ls\ntime -p ls\ntime { ls; }\n"
    # CATCHES: `time` is a statement prefix taking pipelines and brace
    # groups, and coproc accepts a named or unnamed compound/command body.
    res2 = run_script("coproc mycop { echo hi; }\ncoproc echo hi\ncoproc mycop (echo hi)\n")
    assert res2.returncode == 0
    assert res2.stdout == b"coproc mycop { echo hi; }\ncoproc echo hi\ncoproc mycop (echo hi)\n"


def test_stderr_pipeline_operator_roundtrip():
    """The bash `|&` operator (pipe stderr too) parses and prints as-is."""
    res = run_script("a |& b\n")
    # CATCHES: `|&` must be kept distinct from `|` and from `2>&1 |`;
    # the reference treats it as its own pipeline operator.
    assert res.returncode == 0
    assert res.stdout == b"a |& b\n"


def test_conditional_and_arithmetic_commands_roundtrip():
    """`[[ ]]` conditionals and `(( ))` arithmetic commands are statements."""
    res = run_script("if [[ -n $x && $y == z ]]; then :; fi\n((i++))\n((i = i + 1))\n")
    # CATCHES: the double-bracket conditional and the arithmetic command
    # are statement forms of their own; inner spacing is normalised for
    # `(( ))` but `[[ ]]` words are untouched.
    assert res.returncode == 0
    assert res.stdout == b"if [[ -n $x && $y == z ]]; then :; fi\n((i++))\n((i = i + 1))\n"


def test_classic_test_command_forms():
    """`[ ... ]` and `test ...` are plain command words, kept verbatim."""
    res = run_script("if [ -f x ]; then :; fi\nif test -f x; then :; fi\n[ ! -f x ]\n")
    # CATCHES: the classic test command is not a keyword -- the brackets
    # are ordinary words, so no spacing or quoting is normalised there.
    assert res.returncode == 0
    assert res.stdout == b"if [ -f x ]; then :; fi\nif test -f x; then :; fi\n[ ! -f x ]\n"


def test_builtin_call_words_roundtrip():
    """Builtin calls are ordinary command words and round-trip verbatim."""
    script = (
        "echo -n hi\n"
        "printf '%s\\n' \"hi\"\n"
        "read -r x y z\n"
        "readarray -t arr <f\n"
        "alias ll='ls -l'\n"
        "unalias ll\n"
        "trap 'rm -f /tmp/f' EXIT INT TERM\n"
        "trap - EXIT\n"
        "times\n"
        "help cd\n"
        "shopt -s dotglob\n"
        "set -o errexit\n"
        "set +o nounset\n"
        "hash cat\n"
        "type ls\n"
        "command -v cat\n"
        "builtin echo hi\n"
        "dirs\n"
        "pushd /tmp\n"
        "popd\n"
        "set -- a b c\n"
        "shift 2\n"
        "cd /tmp || exit 1\n"
        "pwd\n"
        "exec /bin/sh -c 'echo hi'\n"
        "source /dev/null\n"
        ". ./lib.sh\n"
        "declare -n ref=x\n"
        "declare -a arr=(1 2 3)\n"
        "let \"i = i + 1\"\n"
    )
    res = run_script(script)
    # CATCHES: the whole builtin surface is statement-level command words;
    # the reference executes none of them and prints every line verbatim.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_empty_script_prints_a_single_newline():
    """An empty program on stdin formats to exactly one newline."""
    res = run_script("")
    # CATCHES: even the empty program produces a well-formed empty
    # document (a single `\\n`), not zero bytes nor an error.
    assert res.returncode == 0
    assert res.stdout == b"\n"
    assert res.stderr == b""


def test_script_without_final_newline_gains_one():
    """A program lacking its final newline gets one appended."""
    res = run_script("echo a")
    # CATCHES: the reprint always ends in a newline, so a truncated last
    # line is completed rather than passed through byte-identical.
    assert res.returncode == 0
    assert res.stdout == b"echo a\n"


def test_script_file_argument_compound_formatting(tmp_path):
    """Script file arguments get the same statement normalisation."""
    script = write_script(tmp_path, "func.sh", "f() {\n  echo one\n  echo two\n}\nf\n")
    res = run_gosh_argv([str(script)])
    # CATCHES: the driver's script-file path parses and re-prints the file
    # with tab indentation and the trailing call kept as a statement.
    assert res.returncode == 0
    assert res.stdout == b"f() {\n\techo one\n\techo two\n}\nf\n"
    assert res.stderr == b""

    if_script = write_script(tmp_path, "if.sh", "if a\nthen\n  b\nfi\n")
    res2 = run_gosh_argv([str(if_script)])
    assert res2.returncode == 0
    assert res2.stdout == b"if a; then\n\tb\nfi\n"
