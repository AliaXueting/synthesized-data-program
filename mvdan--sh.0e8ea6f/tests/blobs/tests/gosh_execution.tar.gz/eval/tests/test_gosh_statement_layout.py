"""Statement-form gates and layout normalisations, second surface.

The gosh engine runs these statements; the shipped reference has no
interpreter, so this layer is pinned through which statement forms parse
and how they are normalised when re-printed.  This file covers the forms
left open by the earlier rounds: spaced digits before redirects, the
`(( ))`-vs-`[[ ]]` condition spacing contrast, multi-line C-style `for`
headers rejoined with backslash continuations, word lists that cannot
span newlines, compound statements as pipeline stages, and the remaining
array-literal and process-substitution layouts.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

from conftest import run_script


def test_spaced_digit_before_redirect_is_a_word():
    """`2` separated by a space is a command word, not an fd prefix."""
    res = run_script("cmd 2 >f\n")
    assert res.returncode == 0
    assert res.stdout == b"cmd 2 >f\n"
    # CATCHES: only a digit glued to the redirect operator makes an fd
    # duplication; with a space the digit stays a plain word and the
    # redirect keeps its glued `>f` spelling with collapsed spacing.
    res2 = run_script("cmd 2 >> f\n")
    assert res2.returncode == 0
    assert res2.stdout == b"cmd 2 >>f\n"


def test_arithmetic_condition_hugs_but_conditional_keeps_spaces():
    """A `(( ))` loop condition hugs; a `[[ ]]` condition keeps its spaces."""
    res = run_script("until (( i > 3 )); do :; done\n")
    assert res.returncode == 0
    assert res.stdout == b"until ((i > 3)); do :; done\n"
    # CATCHES: the spaces inside `(( i > 3 ))` are dropped to hug the
    # parens exactly like a standalone arithmetic command, while the
    # `[[ -n $x ]]` conditional in the same position round-trips verbatim
    # with all its inner spaces.
    res2 = run_script("while [[ -n $x ]]; do :; done\n")
    assert res2.returncode == 0
    assert res2.stdout == b"while [[ -n $x ]]; do :; done\n"


def test_multiline_c_style_for_header_is_rejoined_with_backslashes():
    """C-style `for` headers split across lines keep backslash joins."""
    res = run_script("for ((i = 0;\ni < 3;\ni++))\ndo :; done\n")
    assert res.returncode == 0
    assert res.stdout == b"for ((i = 0;  \\\ni < 3;  \\\ni++))\ndo :; done\n"
    # CATCHES: the header is re-joined onto one logical line using escaped
    # newlines, with TWO spaces left before each backslash after the `;` —
    # a spacing quirk unique to this header form.
    assert res.stderr == b""


def test_c_style_for_opening_paren_continuation():
    """A break right after `((` is re-joined with a single backslash."""
    res = run_script("for ((\ni = 0; i < 3; i++\n))\ndo :; done\n")
    assert res.returncode == 0
    assert res.stdout == b"for ((\\\ni = 0; i < 3; i++))\ndo :; done\n"
    # CATCHES: when the whole header expression sits on the next line, the
    # join point is right after `((` and the closing `))` hugs the
    # expression with no trailing continuation.
    assert res.stderr == b""


def test_multiline_elif_bodies_rejoin_their_then():
    """A `then` on its own line is re-joined for `if` and `elif` alike."""
    res = run_script("if a\nthen b\nelif c\nthen d\nelse e\nfi\n")
    assert res.returncode == 0
    # CATCHES: every clause header is normalised to `cond; then` on one
    # line while its body statement moves to an indented line of its own —
    # the elif clauses follow exactly the same rule as the opening if.
    assert res.stdout == b"if a; then\n\tb\nelif c; then\n\td\nelse\n\te\nfi\n"
    assert res.stderr == b""


def test_bare_in_header_normalises_to_a_semicolon():
    """A newline right after `in` or the loop condition becomes `; do`."""
    res = run_script("for i in\ndo :; done\n")
    assert res.returncode == 0
    assert res.stdout == b"for i in; do :; done\n"
    # CATCHES: `in` with an empty word list followed by a newline prints
    # back with a semicolon; the same holds for `select`, and a newline
    # between an `until` condition and its `do` is re-joined too.
    res2 = run_script("select x in\ndo :; done\nuntil x\ndo :; done\n")
    assert res2.returncode == 0
    assert res2.stdout == b"select x in; do :; done\nuntil x; do :; done\n"


def test_word_list_cannot_continue_on_the_next_line():
    """For/select word lists end at the first newline."""
    res = run_script("for i in a\nb\ndo :; done\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:1: `for foo [in words]` must be followed by `do`\n"
    )
    # CATCHES: once `in` has a word, the list cannot span a newline — the
    # second line's `b` is neither a word of the list nor `do`, and select
    # shares the same wording with its own keyword in the message.
    res2 = run_script("select x in\na b\ndo :; done\n")
    assert res2.returncode == 1
    assert res2.stdout == b""
    assert res2.stderr == (
        b"<standard input>:1:1: `select foo [in words]` must be followed by `do`\n"
    )


def test_final_double_semicolon_ampersand_is_kept():
    """A final `;;&` before `esac` is preserved with the body spacing."""
    res = run_script("case $x in a) b;;& esac\n")
    assert res.returncode == 0
    # CATCHES: the optional final terminator is re-printed even in its
    # `;;&` fallthrough spelling, gaining the same ` ;;` spacing the plain
    # `;;` form gets before `esac`.
    assert res.stdout == b"case $x in a) b ;;& esac\n"
    assert res.stderr == b""


def test_extglob_case_patterns_roundtrip():
    """Extended glob patterns in case items round-trip verbatim."""
    script = (
        "case $x in @(a|b)) echo m ;; esac\n"
        "case $x in *(a)b) echo m ;; esac\n"
    )
    res = run_script(script)
    assert res.returncode == 0
    # CATCHES: extglob pattern words are kept exactly as written in the
    # pattern position — the `@(...)`, `*(...)` spellings and their inner
    # pipe are statement-level word forms that survive untouched.
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_compound_statements_as_pipeline_stages():
    """Brace groups, ifs, loops, functions and cases can be piped."""
    script = (
        "{ a; } | c\n"
        "if a; then :; fi | c\n"
        "for i in a; do :; done | cat\n"
        "f() { :; } | cat\n"
        "case $x in a) b;; esac | c\n"
    )
    res = run_script(script)
    assert res.returncode == 0
    assert res.stdout == (
        b"{ a; } | c\n"
        b"if a; then :; fi | c\n"
        b"for i in a; do :; done | cat\n"
        b"f() { :; } | cat\n"
        b"case $x in a) b ;; esac | c\n"
    )
    # CATCHES: every compound statement form may be a pipeline stage and
    # stays inline on one line, with only the case body's `;;` gaining
    # its spacing; the pipe is not moved to a new line.
    assert res.stderr == b""


def test_assignments_in_an_and_or_list():
    """Lone assignments may be the operands of `&&` and `||`."""
    res = run_script("a=1 && b=2\na=1 || b=2\n")
    assert res.returncode == 0
    # CATCHES: an assignment statement is a valid left/right side of an
    # and-or operator and keeps its position; it is not demoted to a plain
    # command word the way some lone words are.
    assert res.stdout == b"a=1 && b=2\na=1 || b=2\n"
    assert res.stderr == b""


def test_coproc_takes_a_full_if_statement():
    """A coproc body may be an entire if/then/fi compound."""
    res = run_script("coproc if :; then :; fi\n")
    assert res.returncode == 0
    # CATCHES: the coproc prefix accepts any compound command, keeping the
    # one-line if layout intact behind it.
    assert res.stdout == b"coproc if :; then :; fi\n"
    assert res.stderr == b""


def test_time_prefixes_can_stack():
    """`time` may repeat and combine with compounds and background."""
    res = run_script("time time ls\ntime { :; } &\n")
    assert res.returncode == 0
    # CATCHES: a second `time` is accepted as a plain word after the
    # first, and the prefix still binds a brace group followed by `&`.
    assert res.stdout == b"time time ls\ntime { :; } &\n"
    assert res.stderr == b""


def test_escaped_newline_before_a_here_string_word():
    """A backslash-newline before a here-string word is kept."""
    res = run_script("cmd <<< \\\nword\n")
    assert res.returncode == 0
    # CATCHES: the leading escaped newline separating the operator from
    # its word is preserved (not stripped) and the word's continuation
    # line gains a tab indent.
    assert res.stdout == b"cmd <<< \\\n\tword\n"
    assert res.stderr == b""


def test_heredoc_inside_command_substitution_goes_multiline():
    """A heredoc inside `$( )` forces the multiline substitution layout."""
    res = run_script("x=$(cat <<EOF\nhi\nEOF\n)\n")
    assert res.returncode == 0
    # CATCHES: the substitution re-prints as `$(\n\t...` with the command
    # indented one tab and the heredoc body and delimiter kept inside it,
    # rather than the single-line `$(cat <<EOF ...)` spelling.
    assert res.stdout == b"x=$(\n\tcat <<EOF\nhi\nEOF\n)\n"
    assert res.stderr == b""


def test_process_substitution_as_fd_redirect_targets():
    """`< <(cmd)`, `2> >(cmd)` and `< <(gen)` redirect forms round-trip."""
    script = (
        "exec 3< <(cmd)\n"
        "cmd 2> >(tr x)\n"
        "while read -r l; do echo $l; done < <(gen)\n"
    )
    res = run_script(script)
    assert res.returncode == 0
    # CATCHES: a process substitution may be the target of an fd-prefixed
    # redirect (both `<` and `>`) and of a `done < <(...)` loop redirect,
    # with the two-word `< <(` spacing preserved exactly.
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_array_literal_spacing_collapses():
    """Inner spaces of an array literal collapse; side-by-side ones stay."""
    res = run_script("a=(  1  2  )\n")
    assert res.returncode == 0
    assert res.stdout == b"a=(1 2)\n"
    # CATCHES: whitespace inside the parens is normalised away just like
    # between command words, while two separate array assignments keep
    # their single-line side-by-side layout.
    res2 = run_script("a=(1) b=(2)\n")
    assert res2.returncode == 0
    assert res2.stdout == b"a=(1) b=(2)\n"


def test_array_literal_continuation_gains_a_tab():
    """A wrapped array literal indents its continuation elements."""
    res = run_script("a=(1 2\n3 4)\n")
    assert res.returncode == 0
    # CATCHES: when an array literal is split across lines, the second
    # line's elements are indented one tab, mirroring statement
    # continuation lines.
    assert res.stdout == b"a=(1 2\n\t3 4)\n"
    assert res.stderr == b""


def test_hyphenated_and_dotted_function_names_roundtrip():
    """Function names containing `-` or `.` are accepted words."""
    res = run_script("foo-bar() { :; }\nfoo.bar() { :; }\n")
    assert res.returncode == 0
    # CATCHES: names beyond the bare identifier charset still define
    # functions and round-trip verbatim; neither the hyphen nor the dot
    # turns the definition into a plain command word.
    assert res.stdout == b"foo-bar() { :; }\nfoo.bar() { :; }\n"
    assert res.stderr == b""


def test_quoted_declare_name_is_allowed():
    """A quoted variable name after `declare` is accepted."""
    res = run_script('declare "x"=1\n')
    assert res.returncode == 0
    # CATCHES: the declaration builtin's name word may be quoted and keeps
    # its quotes on the way out — unlike assignment statements, where the
    # name must be an unquoted literal.
    assert res.stdout == b'declare "x"=1\n'
    assert res.stderr == b""
