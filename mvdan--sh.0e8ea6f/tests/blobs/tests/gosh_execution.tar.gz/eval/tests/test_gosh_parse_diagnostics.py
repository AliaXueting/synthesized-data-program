"""Parse diagnostics as the shipped reference binary reports them.

The gosh driver stops at the first parse error whether input comes from `-c`,
a script file, or the interactive reader; the shipped reference contains no
interpreter, but its parser is the same statement grammar, and the exact
diagnostic wording, source positions, and first-error stopping are all
observable on stderr with exit status 1.  These tests pin those messages for
the statement-level mistakes a re-implementation must reproduce.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

import pytest

from conftest import run_script


@pytest.mark.parametrize(
    ("source", "quote"),
    [
        ("echo 'unclosed\n", "`'`"),
        ('echo "unclosed\n', '`"`'),
        ("echo `unclosed\n", '"`"'),
    ],
)
def test_unclosed_quote_diagnostics(source, quote):
    """An unterminated quote reports the opening position and the quote."""
    res = run_script(source)
    # CATCHES: the position points at where the quote STARTED (column 6),
    # not where input ran out, and the message names the exact quote byte.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:6: reached EOF without closing quote " + quote.encode() + b"\n"
    )


@pytest.mark.parametrize(
    ("source", "message"),
    [
        ("[[ $x == y\n", "reached EOF without matching `[[` with `]]`"),
        ("(( 1 + 2\n", "reached EOF without matching `((` with `))`"),
        ("{ echo a\n", "reached EOF without matching `{` with `}`"),
        ("( echo a\n", "reached EOF without matching `(` with `)`"),
    ],
)
def test_unclosed_compound_forms(source, message):
    """An unclosed compound reports the open/close pair at its start position."""
    res = run_script(source)
    # CATCHES: all four bracketing forms use the same "reached EOF without
    # matching X with Y" wording, anchored at the opening token (1:1).
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: " + message.encode() + b"\n"


def test_unterminated_if_and_case():
    """Compound statements missing their terminator name it explicitly."""
    res = run_script("if true; then echo a\n")
    assert res.returncode == 1
    assert res.stderr == b"<standard input>:1:1: `if` statement must end with `fi`\n"
    # CATCHES: `if` and `case` report "must end with" their closing keyword
    # instead of the bracket-matching wording used by `{`, `(`, `[[`, `((`.
    res2 = run_script("case $x in a) echo A ;;\n")
    assert res2.returncode == 1
    assert res2.stderr == b"<standard input>:1:1: `case` statement must end with `esac`\n"


@pytest.mark.parametrize(
    ("source", "message"),
    [
        ("fi\n", "`fi` can only be used to end an `if`"),
        ("done\n", "`done` can only be used to end a loop"),
        ("esac\n", "`esac` can only be used to end a `case`"),
        ("elif x\n", "`elif` can only be used in an `if`"),
        ("then\n", "`then` can only be used in an `if`"),
        ("do\n", "`do` can only be used in a loop"),
        ("}\n", "`}` can only be used to close a block"),
        (")\n", "`)` can only be used to close a subshell"),
        (";;\n", "`;;` can only be used in a case clause"),
    ],
)
def test_stray_clause_keywords_are_rejected(source, message):
    """Clause keywords with nothing to close get a keyword-specific error."""
    res = run_script(source)
    # CATCHES: each reserved closing word has its own "can only be used"
    # message naming what it belongs to, all anchored at 1:1.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: " + message.encode() + b"\n"


def test_else_and_in_are_plain_words():
    """`else` and `in` outside a clause are accepted as command words."""
    res = run_script("else\n")
    assert res.returncode == 0
    assert res.stdout == b"else\n"
    # CATCHES: unlike fi/done/esac, `else` and `in` are NOT reserved
    # standalone -- the parser treats them as ordinary words and echoes
    # them back instead of erroring.
    res2 = run_script("in\n")
    assert res2.returncode == 0
    assert res2.stdout == b"in\n"


def test_empty_clause_bodies_are_rejected():
    """An empty `then` or `do` body is a parse error naming the keyword."""
    res = run_script("if x; then\nfi\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:7: `then` must be followed by a statement list\n"
    # CATCHES: the position is the clause keyword itself (line 1 col 7 for
    # `then`; line 2 col 1 when `do` starts its own line).
    res2 = run_script("while x\ndo\ndone\n")
    assert res2.returncode == 1
    assert res2.stderr == b"<standard input>:2:1: `do` must be followed by a statement list\n"


@pytest.mark.parametrize(
    ("source", "message"),
    [
        ("if x\n", "`if <cond>` must be followed by `then`"),
        ("while x\n", "`while <cond>` must be followed by `do`"),
        ("case x\n\t(a) echo A ;;\nesac\n", "`case x` must be followed by `in`"),
        ("until\n", "`until` must be followed by a statement list"),
    ],
)
def test_missing_clause_keywords(source, message):
    """Headers missing their required clause keyword say what must follow."""
    res = run_script(source)
    # CATCHES: the message interpolates the header shape (`if <cond>`) or
    # the actual case subject word (`case x`), not a generic error.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: " + message.encode() + b"\n"


@pytest.mark.parametrize(
    "operator",
    ["|", "&&", "||", ";", "&"],
)
def test_leading_operator_is_rejected(operator):
    """An operator with no statement before it is refused at column 1."""
    res = run_script(f"{operator} echo a\n")
    # CATCHES: every list operator errors with the same "can only
    # immediately follow a statement" wording when it starts the input.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:1: `" + operator.encode() + b"` can only immediately follow a statement\n"
    )


@pytest.mark.parametrize(
    ("source", "column"),
    [
        ("echo a |\n", 8),
        ("echo a &&\n", 8),
        ("echo a ||\n", 8),
    ],
)
def test_dangling_operator_is_rejected(source, column):
    """A binary operator at end of input points at the operator itself."""
    res = run_script(source)
    # CATCHES: the position lands on the operator token (column 8 after
    # `echo a `), and the wording is "must be followed by a statement".
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:%d: `" % column
        + source.split()[-1].encode()
        + b"` must be followed by a statement\n"
    )


def test_only_the_first_parse_error_is_reported():
    """Parsing stops at the first error; later ones are never reported."""
    res = run_script("echo ok\n)\necho also\nfi\n")
    # CATCHES: the script contains two broken statements (`)` and a stray
    # `fi`) but exactly one diagnostic line is printed, for the first one
    # (line 2), and the valid statement before it produces no output.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:2:1: `)` can only be used to close a subshell\n"


def test_parse_error_positions_use_line_and_column():
    """The position prefix is `line:column` of the offending token."""
    res = run_script("echo one\necho two\n)\n")
    # CATCHES: the error on the third statement is reported as 3:1, so a
    # re-implementation must track real positions, not just line numbers.
    assert res.returncode == 1
    assert res.stderr == b"<standard input>:3:1: `)` can only be used to close a subshell\n"


def test_unclosed_quote_swallows_the_rest_of_the_script():
    """An unterminated quote consumes later lines; only it is reported."""
    res = run_script("echo 'unclosed\n)\n")
    # CATCHES: the stray `)` on line 2 is inside the quoted word, so the
    # only diagnostic is the unclosed quote at its opening position.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:6: reached EOF without closing quote `'`\n"


@pytest.mark.parametrize(
    ("source", "column", "message"),
    [
        ("echo $(x\n", 6, "reached EOF without matching `$(` with `)`"),
        ("echo ${x\n", 9, 'not a valid parameter expansion operator: "\\n"'),
        ("echo $((1+\n", 10, "`+` must be followed by an expression"),
    ],
)
def test_unclosed_word_expansion_forms(source, column, message):
    """Unclosed `$(`, `${` and `$((` each get their own diagnostic."""
    res = run_script(source)
    # CATCHES: command substitution uses the bracket-matching wording at the
    # `$` (column 6), an unterminated `${` reports the newline byte itself as
    # an invalid operator (column 9, escaped as "\\n"), and an unfinished
    # arithmetic expression blames the dangling operator (column 10).
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:%d: %s\n" % (column, message.encode())


@pytest.mark.parametrize(
    ("source", "message"),
    [
        ("for i in a\n", "`for foo [in words]` must be followed by `do`"),
        ("for i in a; echo\n", "`for foo [in words]` must be followed by `do`"),
        ("select x in a\n", "`select foo [in words]` must be followed by `do`"),
    ],
)
def test_loop_headers_missing_do(source, message):
    """`for`/`select` headers without `do` use the `foo` placeholder wording."""
    res = run_script(source)
    # CATCHES: the message shows the placeholder `foo`, never the real loop
    # variable, and a `;` plus more words after the word list is the same
    # error as running out of input.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: " + message.encode() + b"\n"


@pytest.mark.parametrize(
    ("source", "message"),
    [
        ("while :; do :\n", "`while` statement must end with `done`"),
        ("until :; do :\n", "`until` statement must end with `done`"),
        ("select x in a; do :\n", "`select` statement must end with `done`"),
        ("case $x in\n", "`case` statement must end with `esac`"),
    ],
)
def test_unclosed_loops_and_case_name_their_keyword(source, message):
    """Loops and case missing their closer name the keyword that must end it."""
    res = run_script(source)
    # CATCHES: while/until/select all say "must end with `done`" while a
    # `case` that never saw a single clause still reports `esac` -- the
    # missing items do not change the wording.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: " + message.encode() + b"\n"


def test_case_pattern_without_a_closing_paren():
    """A case clause missing its `)` is reported at the following word."""
    res = run_script("case x in a echo\n")
    # CATCHES: the diagnostic points at column 13 (the word after the
    # pattern) and complains about pattern separation, not a missing paren.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:13: case patterns must be separated with `|`\n"


def test_empty_elif_condition_and_missing_list_separator():
    """An empty `elif` condition and a missing `;` before `fi` both fail."""
    res = run_script("if a; then b; elif; then c; fi\n")
    assert res.returncode == 1
    assert res.stderr == b"<standard input>:1:15: `elif` must be followed by a statement list\n"
    # CATCHES: `else c fi` without a `;` does not error at the `else`; the
    # `fi` is swallowed as an argument word and the failure surfaces as the
    # generic unclosed-`if` wording at 1:1.
    res2 = run_script("if a; then b; else c fi\n")
    assert res2.returncode == 1
    assert res2.stderr == b"<standard input>:1:1: `if` statement must end with `fi`\n"


@pytest.mark.parametrize("source", ["!\n", "! && a\n"])
def test_lone_negation_is_rejected(source):
    """A `!` with no command after it cannot form a statement."""
    res = run_script(source)
    # CATCHES: the negation needs a statement to negate -- even when an
    # operator follows -- and the error is anchored at the `!` itself.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: `!` cannot form a statement alone\n"


def test_lone_coproc_is_rejected():
    """A `coproc` with no command body is refused at parse time."""
    res = run_script("coproc\n")
    # CATCHES: unlike `time`, which may stand alone, `coproc` demands a
    # command and gets its own non-`foo()` wording for the missing one.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: coproc clause requires a command\n"


def test_invalid_utf8_input_is_a_parse_error():
    """A byte that is not valid UTF-8 is rejected at its exact position."""
    res = run_script(b"echo \xff\n")
    # CATCHES: the lexer requires valid UTF-8 and reports the offending byte
    # by position (column 6, right after `echo `) rather than skipping it
    # the way NUL bytes are silently dropped.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:6: invalid UTF-8 encoding\n"
