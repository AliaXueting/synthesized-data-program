"""Statement-form grammar gates and normalisations of the shipped reference.

Round-4 continuation of the statement-layer pinning: which statement forms
the grammar accepts (coproc shapes, redirect-only statements, assignments
with `+=` and array indexes, `function` keyword forms), how they are
normalised when re-printed, and the exact diagnostics for the shapes it
refuses (mid-pipeline `!`, empty clause conditions, clause terminators
outside `case`, array-assignment misuse).  The shipped reference executes
nothing, so every expectation is a recorded round-trip or diagnostic.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

import pytest

from conftest import run_script


def test_case_pattern_paren_is_dropped():
    """The optional `(` before a case pattern never survives re-printing."""
    res = run_script("case x in (a) echo A;; esac\n")
    assert res.returncode == 0
    assert res.stdout == b"case x in a) echo A ;; esac\n"
    # CATCHES: the grammar allows `(a)` but always re-prints the pattern
    # without the opening paren, both inline and in the multi-line layout
    # (where the column-0 `;;` also gains the body's tab indent).
    res2 = run_script("case x in\n(a)\necho A\n;;\nesac\n")
    assert res2.returncode == 0
    assert res2.stdout == b"case x in\na)\n\techo A\n\t;;\nesac\n"


def test_case_pattern_union_gets_pipe_spacing():
    """A `a|b)` pattern union is re-printed with spaced pipes."""
    res = run_script("case x in a|b) echo AB;; esac\n")
    # CATCHES: pattern alternatives are words joined by `|`, and the printer
    # spaces them like every other binary operator: `a | b)`.
    assert res.returncode == 0
    assert res.stdout == b"case x in a | b) echo AB ;; esac\n"


@pytest.mark.parametrize(
    "source",
    [
        "coproc NAME { echo hi; }\n",
        "coproc N cat <f\n",
        "coproc (echo hi)\n",
        "coproc X (echo hi)\n",
        "coproc name cmd &\n",
    ],
)
def test_coproc_statement_forms_roundtrip(source):
    """Named/anonymous coproc bodies, subshell bodies and `&` all survive."""
    res = run_script(source)
    # CATCHES: the coproc statement accepts a NAME + compound body, a NAME +
    # simple command (with redirects), a bare subshell and a backgrounded
    # command, and each form re-prints verbatim on one line.
    assert res.returncode == 0
    assert res.stdout == source.encode()
    assert res.stderr == b""


@pytest.mark.parametrize("source", ["time -p ls\n", "time -p\n", "time -x ls\n"])
def test_time_prefix_takes_any_flag_words(source):
    """`time` swallows flag-looking words without validating them."""
    res = run_script(source)
    # CATCHES: unlike the option-parsing builtins, the `time` prefix takes
    # the following words as its command, so even an unknown `-x` flag is
    # just a word and never a diagnostic.
    assert res.returncode == 0
    assert res.stdout == source.encode()
    assert res.stderr == b""


def test_redirect_only_statement_roundtrips():
    """A statement that is nothing but a redirect is a valid statement."""
    res = run_script(">f\n")
    assert res.returncode == 0
    assert res.stdout == b">f\n"
    # CATCHES: a redirection with no command words parses as a whole
    # statement, keeps its collapsed `>f` spacing, and splits from a
    # following statement onto its own line.
    res2 = run_script("> f; echo\n")
    assert res2.returncode == 0
    assert res2.stdout == b">f\necho\n"


def test_redirect_between_assignments_and_command():
    """`FOO=1 > f cmd` keeps the redirect after the assignments."""
    res = run_script("FOO=1 > f cmd\n")
    # CATCHES: a redirect interleaved between the inline assignments and the
    # command words keeps its written position when re-printed (collapsed to
    # `>f`), rather than migrating to the front or the back.
    assert res.returncode == 0
    assert res.stdout == b"FOO=1 >f cmd\n"


def test_process_substitution_as_a_redirect_target():
    """`> >(cmd)` uses a process substitution as the redirect target."""
    res = run_script("cmd > >(tr a-z A-Z)\n")
    # CATCHES: the target word of a file redirect may itself be a `>( )`
    # process substitution, and it round-trips with the inner command
    # intact.
    assert res.returncode == 0
    assert res.stdout == b"cmd > >(tr a-z A-Z)\n"
    assert res.stderr == b""


def test_background_splits_before_a_following_negation():
    """`a & ! b` becomes two statements: `a &` then `! b`."""
    res = run_script("a & ! b\n")
    # CATCHES: after `&` ends a statement the `!` can only start a new one,
    # so the printer splits the line instead of keeping the author's single
    # line.
    assert res.returncode == 0
    assert res.stdout == b"a &\n! b\n"


def test_negation_with_inline_assignments():
    """`! x=1 cmd` negates a command with assignments; `!` after one is a word."""
    res = run_script("! x=1 cmd\n")
    assert res.returncode == 0
    assert res.stdout == b"! x=1 cmd\n"
    # CATCHES: `!` is only special as the first token of a pipeline -- after
    # an inline assignment it degrades to a plain command word and the
    # statement re-prints as `x=1 ! cmd` with no negation at all.
    res2 = run_script("x=1 ! cmd\n")
    assert res2.returncode == 0
    assert res2.stdout == b"x=1 ! cmd\n"


def test_function_definition_in_an_and_or_list():
    """A function definition may be the left side of `&&`."""
    res = run_script("f() { :; } && g\n")
    # CATCHES: the grammar allows a complete function definition inside an
    # AND-OR list (unlike some shells), and it round-trips on one line.
    assert res.returncode == 0
    assert res.stdout == b"f() { :; } && g\n"


def test_append_assignment_forms_roundtrip():
    """`a+=3` and `a+=1 cmd` keep their `+=` operator verbatim."""
    res = run_script("a+=3\n")
    assert res.returncode == 0
    assert res.stdout == b"a+=3\n"
    # CATCHES: append-assignment works both as a whole statement and as an
    # inline variable prefix before a command word.
    res2 = run_script("a+=1 cmd\n")
    assert res2.returncode == 0
    assert res2.stdout == b"a+=1 cmd\n"


def test_empty_command_substitution_collapses():
    """An empty `$( )` substitution re-prints as `$()` even mid-word."""
    res = run_script("echo $( )\n")
    assert res.returncode == 0
    assert res.stdout == b"echo $()\n"
    # CATCHES: the empty command substitution loses its inner spaces whether
    # it stands alone or sits between literal word parts.
    res2 = run_script("echo a$( )b\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo a$()b\n"


def test_bare_for_with_immediate_do():
    """`for i; do :; done` needs no `in` list when `;` follows the name."""
    res = run_script("for i; do :; done\n")
    # CATCHES: the `in words` part is optional -- the bare for form with an
    # immediate `;` is valid and re-prints on one line.
    assert res.returncode == 0
    assert res.stdout == b"for i; do :; done\n"


def test_array_element_assignments_roundtrip():
    """`a[0]=1` and `a[b]+=1` are statements and split onto lines."""
    res = run_script("a[0]=1; a[b]+=1\n")
    # CATCHES: array-element assignment (including the append `+=` form) is
    # a whole statement; two of them on one input line are split like any
    # other `;`-separated statements.
    assert res.returncode == 0
    assert res.stdout == b"a[0]=1\na[b]+=1\n"


def test_two_ifs_on_one_line_are_split():
    """Two complete `if` statements on one line become two lines."""
    res = run_script("if a; then b; else c; fi; if d; then e; fi\n")
    # CATCHES: the `;` between two compound statements splits the output
    # lines even though each individual `if` stays collapsed inline.
    assert res.returncode == 0
    assert res.stdout == b"if a; then b; else c; fi\nif d; then e; fi\n"


def test_exec_and_let_word_surfaces_roundtrip():
    """`exec -a` and `let` with multiple expressions re-print verbatim."""
    res = run_script("exec -a name cmd arg\n")
    assert res.returncode == 0
    assert res.stdout == b"exec -a name cmd arg\n"
    # CATCHES: `let` keeps every arithmetic expression as a plain word with
    # no added or removed spacing between its assignments.
    res2 = run_script("let a=1 b=2\n")
    assert res2.returncode == 0
    assert res2.stdout == b"let a=1 b=2\n"


def test_directory_stack_builtin_words_roundtrip():
    """`dirs -c`, `pushd sub`, `popd` split onto one line each."""
    res = run_script("dirs -c; pushd sub; popd\n")
    # CATCHES: the directory-stack builtins are ordinary word statements;
    # their flag words survive verbatim and the `;` separators split lines.
    assert res.returncode == 0
    assert res.stdout == b"dirs -c\npushd sub\npopd\n"


@pytest.mark.parametrize(
    "source, column", [("a | ! b\n", 5), ("time ! ls\n", 6)]
)
def test_negation_cannot_appear_mid_pipeline(source, column):
    """`!` after `|` or after the `time` prefix is a parse error."""
    res = run_script(source)
    # CATCHES: negation is only valid at the start of a full statement, so
    # `a | ! b` and `time ! ls` are both refused at the `!` column with the
    # `can only be used in full statements` wording.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:%d: `!` can only be used in full statements\n" % column
    )


@pytest.mark.parametrize(
    "source, keyword",
    [
        ("if; then :; fi\n", "if"),
        ("while; do :; done\n", "while"),
        ("until; do :; done\n", "until"),
    ],
)
def test_empty_clause_conditions_are_rejected(source, keyword):
    """`if;`, `while;`, `until;` with no condition list are parse errors."""
    res = run_script(source)
    # CATCHES: a clause header demands a non-empty condition list; the empty
    # form is refused at 1:1 naming the keyword, before the missing
    # `then`/`do` could even be reported.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:1: `%s` must be followed by a statement list\n" % keyword.encode()
    )


@pytest.mark.parametrize(
    "source, keyword",
    [
        ('for "i" in a; do :; done\n', "for"),
        ("select; do :; done\n", "select"),
    ],
)
def test_for_and_select_need_a_literal_name(source, keyword):
    """A quoted loop name (or none at all) is rejected as non-literal."""
    res = run_script(source)
    # CATCHES: both loop keywords require an unquoted literal name; a quoted
    # `"i"` or a missing name both fail at 1:1 with the `literal` wording.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:1: `%s` must be followed by a literal\n" % keyword.encode()
    )


def test_bare_for_name_needs_in_do_or_separator():
    """`for i a; do` reports the full set of allowed followers."""
    res = run_script("for i a; do :; done\n")
    # CATCHES: after a bare for-name anything but `in`, `do`, `;` or a
    # newline is an error, and the diagnostic uses the `for foo` placeholder
    # wording with all four followers listed.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:1: `for foo` must be followed by "
        b"`in`, `do`, `;`, or a newline\n"
    )


def test_case_needs_its_subject_word():
    """`case;` with no subject word is rejected at the keyword."""
    res = run_script("case; do :; esac\n")
    # CATCHES: unlike the loop keywords, `case` demands a subject word and
    # the error fires at 1:1 before the missing `in` matters.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: `case` must be followed by a word\n"


@pytest.mark.parametrize(
    "source, column, message",
    [
        ("a[b] c=1\n", 1, b"`a[b]` must be followed by `=`"),
        ("a[]=1\n", 2, b"`[` must be followed by an expression"),
    ],
)
def test_array_element_assignment_errors(source, column, message):
    """A subscripted name must be followed by `=` and a valid index."""
    res = run_script(source)
    # CATCHES: `a[b]` alone is not a statement prefix (error at 1:1 naming
    # the `a[b]` form), and an empty `[]` index is an expression error
    # reported at the `[` column instead.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:%d: %s\n" % (column, message)


def test_inline_variables_cannot_be_arrays():
    """`a[0]=1 cmd` refuses an array assignment before a command."""
    res = run_script("a[0]=1 cmd\n")
    # CATCHES: inline variable prefixes may only be plain `name=value`
    # assignments; an array-element assignment prefixing a command is
    # rejected with the `inline variables cannot be arrays` wording.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: inline variables cannot be arrays\n"


def test_function_keyword_requires_a_name():
    """`function 'f'` is rejected; digit-leading and quoted declare names are not."""
    res = run_script("function 'f' { :; }\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: `function` must be followed by a name\n"
    # CATCHES: only the `function` keyword demands a bare name word -- a
    # digit-leading `1f` is accepted, and `declare "x"` keeps its quoted
    # argument as a plain word.
    res2 = run_script("function 1f { :; }\n")
    assert res2.returncode == 0
    assert res2.stdout == b"function 1f { :; }\n"
    res3 = run_script('declare "x"\n')
    assert res3.returncode == 0
    assert res3.stdout == b'declare "x"\n'


def test_let_requires_an_expression():
    """A lone `let` with no expressions is a parse error."""
    res = run_script("let\n")
    # CATCHES: the `let` keyword demands at least one arithmetic expression
    # word; with none it is refused at 1:1 instead of running as a command
    # that evaluates nothing.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: `let` must be followed by an expression\n"


@pytest.mark.parametrize(
    "source, column, terminator",
    [("a;;\n", 2, ";;"), ("a ;;&\n", 3, ";;&"), ("a ;&\n", 3, ";&")],
)
def test_clause_terminators_outside_case(source, column, terminator):
    """`;;`, `;;&` and `;&` after a complete statement are rejected."""
    res = run_script(source)
    # CATCHES: case-clause terminators are refused outside a `case` with the
    # position pointing at the terminator column after the statement, and
    # all three spellings share the wording.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:%d: `%s` can only be used in a case clause\n"
        % (column, terminator.encode())
    )


def test_misplaced_second_ampersand():
    """`a & & b` rejects the `&` that does not immediately follow a statement."""
    res = run_script("a & & b\n")
    # CATCHES: a second `&` separated from the first by a space is not the
    # `&&` operator and not a new background marker; it gets its own
    # `can only immediately follow a statement` wording at column 5.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:5: `&` can only immediately follow a statement\n"


@pytest.mark.parametrize(
    "source, column, operator",
    [("a && | b\n", 3, "&&"), ("a |&\n", 3, "|&")],
)
def test_operators_need_a_following_statement(source, column, operator):
    """`&&` and `|&` demand a statement after them even mid-line."""
    res = run_script(source)
    # CATCHES: when what follows `&&` is another operator (`|`), or when
    # `|&` is the last word, the `must be followed by a statement` wording
    # fires at the operator column -- distinct from the dangling-at-EOF
    # diagnostics already pinned.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:%d: `%s` must be followed by a statement\n"
        % (column, operator.encode())
    )


def test_stray_paren_in_a_case_body():
    """`b)` starting inside a clause body is the words-and-redirects error."""
    res = run_script("case x in a) b) echo B;; esac\n")
    # CATCHES: after `a)` the parser is in a clause *body*, so the next `)`
    # cannot open a pattern there; the diagnostic names what a command may
    # contain and points at the stray `)` (column 15).
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:15: a command can only contain words and "
        b"redirects; encountered `)`\n"
    )


def test_empty_parameter_name_is_invalid():
    """`${}` is rejected at the closing brace with `invalid parameter name`."""
    res = run_script("echo ${}\n")
    # CATCHES: an empty parameter name is not the `not a valid parameter
    # expansion operator` family -- it has its own wording, reported at the
    # `}` column (8) inside the word.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:8: invalid parameter name\n"
