"""Word-level statement forms as the shipped reference binary handles them.

The gosh engine would expand these words while running each statement
(runner.go, vars.go); the shipped reference contains no interpreter, so the
word layer is pinned through the round-trip: which word forms parse, which
spellings the printer rewrites into canonical form (backticks to `$( )`,
`$[ ]` to `$(( ))`, arithmetic operator spacing, inter-word whitespace), and
which forms are preserved byte for byte.  Nothing is ever expanded.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

import pytest

from conftest import run_script


def test_backticks_are_rewritten_to_command_substitution():
    """Backquote command substitutions are re-printed as `$( )`."""
    res = run_script("echo `backtick cmd`\n")
    # CATCHES: the canonical command substitution spelling is `$( )`; the
    # legacy backquote form is parsed and re-printed in the new form.
    assert res.returncode == 0
    assert res.stdout == b"echo $(backtick cmd)\n"
    assert res.stderr == b""


def test_nested_backticks_are_rewritten_to_nested_substitutions():
    """Escaped nested backquotes become nested `$( )` substitutions."""
    res = run_script("echo `nested \\`backtick\\``\n")
    # CATCHES: one level of escaping nests a backquote inside another, and
    # the reprint nests the two substitutions in the same shape.
    assert res.returncode == 0
    assert res.stdout == b"echo $(nested $(backtick))\n"


def test_deprecated_arithmetic_brackets_are_rewritten():
    """`$[ ]` arithmetic is re-printed as the modern `$(( ))` form."""
    res = run_script("echo $[1+2]\n")
    # CATCHES: the deprecated `$[ ]` spelling parses as arithmetic and is
    # canonicalised to `$(( ))` with spaced operators.
    assert res.returncode == 0
    assert res.stdout == b"echo $((1 + 2))\n"


def test_arithmetic_operator_spacing_is_normalised():
    """Binary arithmetic operators gain spaces; parens and operands hug."""
    res = run_script("echo $((x+1))\n")
    assert res.returncode == 0
    assert res.stdout == b"echo $((x + 1))\n"
    # CATCHES: spaces after `((` and before `))` are dropped, inner parens
    # hug their operand, and binary operators are always spaced.
    res2 = run_script("echo $(( (1+2)*3 ))\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo $(((1 + 2) * 3))\n"
    res3 = run_script("echo $(( x + 1 )) $((y))\n")
    assert res3.returncode == 0
    assert res3.stdout == b"echo $((x + 1)) $((y))\n"


def test_assignment_values_get_arithmetic_normalisation():
    """Arithmetic inside an assignment value is spaced like anywhere else."""
    res = run_script("a=$((1+2))\n")
    # CATCHES: the assignment statement keeps its `name=` shape but the
    # value's arithmetic is canonicalised, showing the value is parsed as
    # arithmetic and not kept as opaque literal text.
    assert res.returncode == 0
    assert res.stdout == b"a=$((1 + 2))\n"


def test_interword_whitespace_is_collapsed():
    """Runs of spaces or tabs between words become a single space."""
    res = run_script("echo a    b\n")
    assert res.returncode == 0
    assert res.stdout == b"echo a b\n"
    # CATCHES: tabs between words collapse exactly like spaces, and the
    # leading gap after the command word disappears too.
    res2 = run_script("echo a\t\tb\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo a b\n"
    res3 = run_script("cmd    arg1   arg2\n")
    assert res3.returncode == 0
    assert res3.stdout == b"cmd arg1 arg2\n"


def test_quoting_forms_roundtrip_verbatim():
    """Quote styles and escapes are preserved, never re-quoted or unquoted."""
    script = (
        "echo 'single quoted'\n"
        'echo "double quoted"\n'
        "echo $'ansi c\\nquoted'\n"
        'echo "nested \\"inner\\" quotes"\n'
        "echo 'it'\\''s escaped'\n"
        "echo a\\ b\n"
        "echo \\$HOME\n"
    )
    res = run_script(script)
    # CATCHES: single, double, ANSI-C and escaped quoting all round-trip
    # byte for byte; the printer never normalises a quote style away.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_array_forms_roundtrip():
    """Array assignment and indexing forms parse and round-trip verbatim."""
    script = (
        "a=(1 2 3)\n"
        "a+=(4 5)\n"
        "declare -a arr=(x y)\n"
        "echo ${a[@]}\n"
        "echo ${a[*]}\n"
        "echo ${#a[@]}\n"
        "echo ${a[0]}\n"
    )
    res = run_script(script)
    # CATCHES: array literals, the `+=` append form, length expansion and
    # element indexing are all statement-level word forms the reference
    # accepts without executing anything.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_parameter_expansion_operators_roundtrip():
    """Parameter expansion operators keep their exact spelling."""
    script = (
        "echo ${x:-default}\n"
        "echo ${x%suffix}\n"
        "echo ${x//old/new}\n"
        "echo ${x^^}\n"
    )
    res = run_script(script)
    # CATCHES: default-value, suffix-trim, global-replace and case-modify
    # operators are preserved byte for byte, including `^^`.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_special_parameters_roundtrip():
    """Special parameter words are kept exactly as written."""
    res = run_script("echo $? $! $$ $0 $# $@ $*\n")
    # CATCHES: all seven special parameters survive the round-trip as
    # single dollar-prefixed words; none is split or merged.
    assert res.returncode == 0
    assert res.stdout == b"echo $? $! $$ $0 $# $@ $*\n"


def test_tilde_forms_roundtrip():
    """Tilde prefixes inside words are preserved."""
    script = "echo ~/file\necho ~user/file\necho ~+\n"
    res = run_script(script)
    # CATCHES: the home, named-user and PWD tilde prefixes stay glued to
    # the rest of their words.
    assert res.returncode == 0
    assert res.stdout == script.encode()


def test_conditional_parens_hug_their_operands():
    """Inside `[[ ]]`, grouping parens hug; other operators keep spacing."""
    res = run_script("[[ ( $x || $y ) && $z ]]\n")
    assert res.returncode == 0
    assert res.stdout == b"[[ ($x || $y) && $z ]]\n"
    # CATCHES: the negation and regex-match operators keep their exact
    # spacing, and only the grouping parens are pulled tight.
    res2 = run_script("[[ ! -z $x ]]\n[[ $x =~ ^re.*$ ]]\n")
    assert res2.returncode == 0
    assert res2.stdout == b"[[ ! -z $x ]]\n[[ $x =~ ^re.*$ ]]\n"


def test_arithmetic_command_spacing():
    """`(( ))` commands drop the space after `((`; comma and `=` are spaced."""
    res = run_script("(( i++, j = 5 ))\n")
    # CATCHES: the arithmetic command hugs its opening parens while the
    # comma operator and the assignment keep single spaces, which is a
    # different rule from the word-level `$(( ))` expansion.
    assert res.returncode == 0
    assert res.stdout == b"((i++, j = 5))\n"


def test_spaced_assignment_is_not_an_assignment():
    """`a = 5` is a plain command word list, not an assignment statement."""
    res = run_script("a = 5\n")
    assert res.returncode == 0
    assert res.stdout == b"a = 5\n"
    # CATCHES: only the glued `name=value` form is an assignment; with
    # spaces the `=` is just a word, and glued assignments keep their
    # place in front of a command word.
    res2 = run_script("a=1 b=2 cmd arg\n")
    assert res2.returncode == 0
    assert res2.stdout == b"a=1 b=2 cmd arg\n"
