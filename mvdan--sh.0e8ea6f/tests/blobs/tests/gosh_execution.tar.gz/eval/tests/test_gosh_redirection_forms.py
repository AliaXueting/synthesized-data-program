"""Redirection statements as the shipped reference binary handles them.

The gosh engine applies redirections at the statement level (runner.go): the
file operators `>`/`>>`/`<`/`<>`/`>|`, fd duplication and closing (`2>&1`,
`2>&-`), here-strings, heredocs, and process substitutions.  The shipped
reference binary contains no interpreter, so the redirection layer is pinned
through what it actually does with these statements: every operator parses,
the operator-to-target spacing is normalised, redirects stay attached to the
right statement (simple, compound, or pipeline stage), and malformed
redirections are refused with exact diagnostics.  Nothing is ever opened,
written, or fed to a command.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

import pytest

from conftest import run_script


@pytest.mark.parametrize(
    ("source", "printed"),
    [
        ("echo hi > f", "echo hi >f"),
        ("echo hi >> f", "echo hi >>f"),
        ("cat <> f", "cat <>f"),
        ("echo x >| f", "echo x >|f"),
    ],
)
def test_redirect_operator_spacing_is_collapsed(source, printed):
    """A space between a file operator and its target is always removed."""
    res = run_script(source + "\n")
    # CATCHES: all four file operators (`>`, `>>`, `<>`, `>|`) hug their
    # target word; the reference rewrites `> f` to `>f` for each of them.
    assert res.returncode == 0
    assert res.stdout == printed.encode() + b"\n"
    assert res.stderr == b""


def test_fd_prefixed_operator_spacing_is_collapsed():
    """Digit-prefixed operators lose the space before their target too."""
    res = run_script("cmd 2> f\n")
    assert res.returncode == 0
    assert res.stdout == b"cmd 2>f\n"
    # CATCHES: the digit prefix stays glued to the operator and the target
    # follows immediately, for output and input forms alike.
    res2 = run_script("cmd 3> f\ncmd 4<f\ncmd 2>>f\n")
    assert res2.returncode == 0
    assert res2.stdout == b"cmd 3>f\ncmd 4<f\ncmd 2>>f\n"


def test_fd_duplication_operator_forms():
    """`2>&1`, `>&2`, `3<&0` parse as duplication ops, spacing normalised."""
    res = run_script("cmd 2>& 1\ncmd >& 2\ncmd 3<&0\n")
    # CATCHES: `>& 1` with a space is collapsed to `>&1`, and both the
    # stderr and stdin duplication spellings round-trip verbatim.
    assert res.returncode == 0
    assert res.stdout == b"cmd 2>&1\ncmd >&2\ncmd 3<&0\n"
    assert res.stderr == b""


def test_fd_closing_operators_roundtrip():
    """The `>&-` and `<&-` closing operators are statements of their own kind."""
    res = run_script("cmd 2>&-\ncmd 0<&-\nexec 0<&-\n")
    # CATCHES: closing a descriptor (`2>&-`) is kept distinct from
    # duplicating it, and survives on commands and `exec` alike.
    assert res.returncode == 0
    assert res.stdout == b"cmd 2>&-\ncmd 0<&-\nexec 0<&-\n"
    assert res.stderr == b""


def test_bash_combined_redirect_operators():
    """`&>` and `&>>` (stdout+stderr combined) parse and print verbatim."""
    res = run_script("cmd &>f\ncmd &>>f\n")
    # CATCHES: the two bash-specific combined operators must not be
    # rewritten into `>f 2>&1` pairs nor split into separate redirects.
    assert res.returncode == 0
    assert res.stdout == b"cmd &>f\ncmd &>>f\n"
    assert res.stderr == b""


def test_named_fd_redirect_roundtrip():
    """The bash `{var}>file` form allocates a named fd and prints as-is."""
    res = run_script("exec {logfd}>logfile\n")
    # CATCHES: a brace-named fd is a valid redirect target word; the
    # reference keeps `{logfd}` glued to the operator exactly as written.
    assert res.returncode == 0
    assert res.stdout == b"exec {logfd}>logfile\n"
    assert res.stderr == b""


def test_leading_redirect_on_a_simple_command():
    """A redirect may precede the command words it applies to."""
    res = run_script(">f echo hi\n")
    assert res.returncode == 0
    assert res.stdout == b">f echo hi\n"
    # CATCHES: the prefix redirect also works inside subshells and brace
    # groups and stays attached to the statement, not the enclosing body.
    res2 = run_script("(>f a)\n{ >f a; }\n")
    assert res2.returncode == 0
    assert res2.stdout == b"(>f a)\n{ >f a; }\n"


def test_leading_redirect_before_a_compound_command_is_rejected():
    """`>f if ...; fi` is refused: prefix redirects onto compounds are zsh-only."""
    res = run_script(">f if a; then b; fi\n")
    # CATCHES: the grammar accepts prefix redirects only before simple
    # commands; before a compound it errors out with this zsh-feature
    # diagnostic instead of parsing the statement.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:1: redirects before compound commands are a zsh "
        b"feature; tried parsing as bash (parsed as bash via -ln=auto)\n"
    )


@pytest.mark.parametrize(
    ("source", "message"),
    [
        ("echo >\n", b"<standard input>:1:6: `>` must be followed by a word\n"),
        ("cmd 2>&\n", b"<standard input>:1:6: `>&` must be followed by a word\n"),
    ],
)
def test_redirect_requires_a_target_word(source, message):
    """A redirection operator with no target word is a parse error."""
    res = run_script(source)
    # CATCHES: the diagnostic names the exact operator (`>` vs `>&`) and
    # the column just past it, with exit status 1 and empty stdout.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == message


def test_multiple_redirects_keep_their_written_order():
    """Several redirects on one command print in the order they were given."""
    res = run_script("cmd >f 2>&1\ncmd 2>&1 >f\ncat < f < g\n")
    # CATCHES: `>f 2>&1` and `2>&1 >f` have different run-time meanings;
    # the reference preserves the source order rather than sorting, and a
    # doubled input redirect keeps both occurrences.
    assert res.returncode == 0
    assert res.stdout == b"cmd >f 2>&1\ncmd 2>&1 >f\ncat <f <g\n"
    assert res.stderr == b""


def test_quoted_redirect_target_is_preserved():
    """A quoted target word keeps its quotes through the round-trip."""
    res = run_script('echo hi >"my file"\n')
    # CATCHES: the target is a word, not a path string -- its quoting must
    # survive so a re-implementation cannot drop or add quote marks.
    assert res.returncode == 0
    assert res.stdout == b'echo hi >"my file"\n'
    assert res.stderr == b""


def test_here_string_word_quoting_is_preserved():
    """Here-string targets keep their quoting and spacing is unchanged."""
    res = run_script('cat <<<"hi there"\ntr a-z A-Z <<<"$x"\n')
    # CATCHES: the `<<<` operator hugs its word and the word's own quoting
    # (double quotes and the `$x` inside them) is printed back verbatim.
    assert res.returncode == 0
    assert res.stdout == b'cat <<<"hi there"\ntr a-z A-Z <<<"$x"\n'
    assert res.stderr == b""


def test_redirect_on_each_pipeline_stage():
    """Each stage of a pipeline can carry its own redirect, kept per stage."""
    res = run_script("a >x | b >y\n")
    # CATCHES: the redirect binds to the stage it was written on; it must
    # not migrate to the pipeline as a whole or to the neighbouring stage.
    assert res.returncode == 0
    assert res.stdout == b"a >x | b >y\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    ("source", "printed"),
    [
        ("if a; then b; fi >log", "if a; then b; fi >log"),
        ("case $x in a) echo A;; esac >log", "case $x in a) echo A ;; esac >log"),
        ("{ a; } >f", "{ a; } >f"),
        ("f() { a; } >f", "f() { a; } >f"),
        ("(a) >f", "(a) >f"),
        ("while read l; do echo $l; done <f", "while read l; do echo $l; done <f"),
        ('while read l; do echo "$l"; done >>f', 'while read l; do echo "$l"; done >>f'),
    ],
)
def test_redirects_attached_to_compound_statements(source, printed):
    """Compound statements take trailing redirects without being re-laid-out."""
    res = run_script(source + "\n")
    # CATCHES: a redirect after `fi`, `esac`, `}`, `)`, or `done` stays on
    # the same line as the closer; only the case-item terminator gains its
    # usual ` ;;` spacing.
    assert res.returncode == 0
    assert res.stdout == printed.encode() + b"\n"
    assert res.stderr == b""


def test_two_heredocs_on_one_command():
    """Two heredoc operators on one command each keep their own body."""
    res = run_script("cat <<A <<B\n1\nA\n2\nB\n")
    # CATCHES: both bodies stay attached to their own delimiter in order;
    # the second heredoc's body is not merged into the first one.
    assert res.returncode == 0
    assert res.stdout == b"cat <<A <<B\n1\nA\n2\nB\n"
    assert res.stderr == b""


def test_heredoc_after_a_compound_statement():
    """A heredoc may be attached to `done` and its body follows the line."""
    res = run_script("while :; do :; done <<EOF\nx\nEOF\n")
    # CATCHES: the heredoc belongs to the loop statement, not to the last
    # body command; the body lines are printed between the operator line
    # and its delimiter without re-indentation.
    assert res.returncode == 0
    assert res.stdout == b"while :; do :; done <<EOF\nx\nEOF\n"
    assert res.stderr == b""


def test_process_substitution_words_roundtrip():
    """`<( )` and `>( )` words parse as command arguments, not redirects."""
    res = run_script("diff <(sort a) <(sort b)\ngzip >(nc host port)\n")
    # CATCHES: process substitutions are word-level constructs that ride
    # along as arguments; the reference must not mistake them for input or
    # output redirections on the outer command.
    assert res.returncode == 0
    assert res.stdout == b"diff <(sort a) <(sort b)\ngzip >(nc host port)\n"
    assert res.stderr == b""


def test_exec_fd_redirection_statements():
    """`exec` fd redirections are ordinary statements and get spacing fixes."""
    res = run_script("exec 3< /etc/hosts\nexec 2>&-\n")
    # CATCHES: the persistent `exec 3< file` redirection keeps its fd
    # prefix while the space after the operator is collapsed to `3<file`.
    assert res.returncode == 0
    assert res.stdout == b"exec 3</etc/hosts\nexec 2>&-\n"
    assert res.stderr == b""


def test_redirect_together_with_background_operator():
    """A redirect and the `&` operator coexist on one statement."""
    res = run_script("a >f &\n! a >f\n")
    # CATCHES: the trailing `&` stays after the redirect and a leading `!`
    # stays before the command; neither operator swallows the other.
    assert res.returncode == 0
    assert res.stdout == b"a >f &\n! a >f\n"
    assert res.stderr == b""
