"""Heredoc statements as the shipped reference binary handles them.

The gosh engine feeds heredoc bodies to commands at the statement level
(runner.go); the shipped reference contains no interpreter, so the heredoc
layer is pinned through what the binary actually does: `<<` vs `<<-`
delimiters, quoted delimiters, terminator matching (exact word, column rules,
tab stripping), the printer's heredoc body indentation, the auto-completion of
unterminated heredocs, and where a heredoc operator is re-printed relative to
the command's words.  Nothing is ever fed to a command.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

import pytest

from conftest import run_script


def test_dash_hdoc_strips_one_tab_from_the_terminator():
    """`<<-` removes a leading tab from the terminator, one tab only."""
    res = run_script("cat <<-EOF\n\tline1\n\t\tline2\n\tEOF\n")
    # CATCHES: only the terminator loses exactly one tab; body lines keep
    # their tabs verbatim, including a second tab on deeply indented lines.
    assert res.returncode == 0
    assert res.stdout == b"cat <<-EOF\n\tline1\n\t\tline2\nEOF\n"
    assert res.stderr == b""


def test_dash_hdoc_body_lines_gain_a_leading_tab():
    """`<<-` body lines are printed with at least one leading tab."""
    res = run_script("cat <<-EOF\nplain\n\tEOF\n")
    assert res.returncode == 0
    assert res.stdout == b"cat <<-EOF\n\tplain\nEOF\n"
    # CATCHES: the printer normalises `<<-` bodies to be tab-indented: a
    # body line without a tab gains one, and a terminator at column 0
    # (no tab to strip) still terminates the heredoc.
    res2 = run_script("cat <<-EOF\nplain\nEOF\n")
    assert res2.returncode == 0
    assert res2.stdout == b"cat <<-EOF\n\tplain\nEOF\n"


def test_dash_hdoc_mixed_indent_body_lines():
    """A `<<-` body mixes tabbed and plain lines; each plain line gains a tab."""
    res = run_script("cat <<-EOF\n\ttab\nplain\n\tEOF\n")
    # CATCHES: the tab rule is per line, not per heredoc: `tab` keeps its
    # own tab, `plain` gains one, and the terminator is de-tabbed once.
    assert res.returncode == 0
    assert res.stdout == b"cat <<-EOF\n\ttab\n\tplain\nEOF\n"


def test_dash_hdoc_space_indent_does_not_terminate():
    """`<<-` strips tabs only, so a space-indented terminator never matches."""
    res = run_script("cat <<-EOF\n    spaced indent\n    EOF\n")
    # CATCHES: the space-indented `EOF` is body text (spaces are not
    # stripped), so the heredoc runs to EOF, is auto-closed with a fresh
    # terminator, and every body line still gains its leading tab.
    assert res.returncode == 0
    assert res.stdout == b"cat <<-EOF\n\t    spaced indent\n\t    EOF\nEOF\n"


def test_unterminated_heredoc_gains_its_terminator():
    """A heredoc that never sees its delimiter is auto-closed, not an error."""
    res = run_script("cat <<EOF\nunterminated\n")
    # CATCHES: reaching end of input inside a heredoc body is not a parse
    # error; the printer appends the missing delimiter word `EOF`.
    assert res.returncode == 0
    assert res.stdout == b"cat <<EOF\nunterminated\nEOF\n"
    assert res.stderr == b""


@pytest.mark.parametrize("quote", ["'", '"'])
def test_quoted_heredoc_delimiters_are_preserved(quote):
    """`<<'EOF'` and `<<"EOF"` keep their quoting in the reprint."""
    source = "cat <<{q}EOF{q}\n$not expanded\nEOF\n".format(q=quote)
    res = run_script(source)
    # CATCHES: quoting the delimiter suppresses expansion in gosh; the
    # reference keeps the exact quoted spelling instead of unquoting it.
    assert res.returncode == 0
    assert res.stdout == source.encode()


def test_dash_hdoc_with_quoted_delimiter():
    """`<<-` and a quoted delimiter combine; operator spacing is collapsed."""
    res = run_script("cat <<-'EOF'\n\tx\nEOF\n")
    assert res.returncode == 0
    assert res.stdout == b"cat <<-'EOF'\n\tx\nEOF\n"
    # CATCHES: a space between `<<-` and the quoted delimiter is removed
    # while the quote style itself is preserved verbatim.
    res2 = run_script('cat <<- "EOF"\n\tx\nEOF\n')
    assert res2.returncode == 0
    assert res2.stdout == b'cat <<-"EOF"\n\tx\nEOF\n'


def test_heredoc_operator_space_is_collapsed():
    """A space between `<<` and the delimiter is removed."""
    res = run_script("cat << EOF\nx\nEOF\n")
    # CATCHES: the delimiter must hug the operator, exactly like the file
    # redirect operators collapse `> f` to `>f`.
    assert res.returncode == 0
    assert res.stdout == b"cat <<EOF\nx\nEOF\n"


def test_heredoc_blank_lines_are_preserved():
    """Blank lines inside a heredoc body survive verbatim."""
    res = run_script("cat <<EOF\n\n\nx\n\nEOF\n")
    # CATCHES: between statements the printer collapses runs of blank
    # lines to one, but inside a heredoc body every byte is body text and
    # all blank lines are kept.
    assert res.returncode == 0
    assert res.stdout == b"cat <<EOF\n\n\nx\n\nEOF\n"


def test_indented_dash_hdoc_inside_an_if():
    """An indented `<<-` keeps its body indented one tab deeper than the line."""
    res = run_script("if true; then\n\tcat <<-EOF\n\t\tbody\n\t\tEOF\nfi\n")
    # CATCHES: the body keeps the statement indent plus one tab while the
    # terminator is printed at the statement indent, still de-tabbed once.
    assert res.returncode == 0
    assert res.stdout == b"if true; then\n\tcat <<-EOF\n\t\tbody\n\tEOF\nfi\n"


def test_plain_heredoc_terminator_must_start_at_column_zero():
    """A tab-indented `EOF` only terminates a `<<-` heredoc, never a `<<` one."""
    res = run_script("if true; then\n\tcat <<EOF\n\tbody\n\tEOF\nfi\n")
    # CATCHES: the plain `<<` heredoc swallows the indented `EOF` and the
    # `fi`, runs to end of input, and the failure surfaces as the unclosed
    # `if` diagnostic rather than a heredoc error.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:1: `if` statement must end with `fi`\n"


def test_plain_heredoc_terminator_at_column_zero_inside_a_function():
    """A plain `<<` heredoc inside a function needs its `EOF` at column 0."""
    res = run_script("f() {\n\tcat <<EOF\n\tbody\nEOF\n}\n")
    assert res.returncode == 0
    assert res.stdout == b"f() {\n\tcat <<EOF\n\tbody\nEOF\n}\n"
    # CATCHES: with the terminator back at column 0 the heredoc ends before
    # the closing brace, and the body keeps its function-level indent.
    res2 = run_script("f() {\n\tcat <<EOF\n\tbody\n\tEOF\n}\n")
    assert res2.returncode == 1
    assert res2.stdout == b""
    assert res2.stderr == b"<standard input>:1:5: reached EOF without matching `{` with `}`\n"


def test_heredoc_terminator_must_match_the_delimiter_exactly():
    """A body line equal to the delimiter plus a suffix stays body text."""
    res = run_script("cat <<EOF\nEOFx\nEOF\n")
    # CATCHES: terminator matching is on the whole word, so `EOFx` is not
    # the terminator and the real `EOF` on the next line is.
    assert res.returncode == 0
    assert res.stdout == b"cat <<EOF\nEOFx\nEOF\n"


def test_heredoc_delimiter_is_a_single_word():
    """`<<E O F` takes `E` as the delimiter; `O F` become command words."""
    res = run_script("cat <<E O F\nx\nE O F\n")
    # CATCHES: only the first word after `<<` is the delimiter, so the
    # `E O F` line is body text, the heredoc runs to EOF, and the missing
    # terminator `E` is auto-appended.
    assert res.returncode == 0
    assert res.stdout == b"cat O F <<E\nx\nE O F\nE\n"


def test_heredoc_redirect_is_printed_after_the_command_words():
    """A heredoc operator is deferred to the end of the word list."""
    res = run_script("cat <<EOF extra\nx\nEOF\n")
    assert res.returncode == 0
    assert res.stdout == b"cat extra <<EOF\nx\nEOF\n"
    # CATCHES: file redirects keep their place between the first two words
    # (`echo >f hi` is unchanged) and heredocs always move past the words,
    # while redirects keep their relative order among themselves.
    res2 = run_script("echo >f hi\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo >f hi\n"
    res3 = run_script("echo hi >f there more\n")
    assert res3.returncode == 0
    assert res3.stdout == b"echo hi there more >f\n"
