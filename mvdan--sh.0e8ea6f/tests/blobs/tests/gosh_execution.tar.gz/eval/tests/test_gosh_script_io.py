"""Script-file and stdin handling as the shipped reference binary does it.

The gosh driver runs script file arguments in order, treats non-terminal
stdin as a script, and mirrors the script exit status; the shipped reference
contains no interpreter, so this driver surface is pinned through what the
binary actually does: how a parse error inside one file is named and how the
run continues to later files, that `-` means standard input only when it is
the sole argument, that stdin is ignored once file arguments are given, and
how line endings, stray bytes, and blank lines are normalised on the way in.

All expected bytes were recorded by running ``./executable`` with the exact
argument vectors and stdin payloads shown.
"""

from __future__ import annotations

from conftest import run_gosh_argv, run_script, write_script


def test_script_file_parse_error_names_the_file(tmp_path):
    """A parse error inside a script file is prefixed with the file's path."""
    bad = write_script(tmp_path, "bad.sh", "echo two\n)\n")
    res = run_gosh_argv([str(bad)])
    # CATCHES: stdin errors are prefixed `<standard input>`; file errors
    # carry the full path with the same line:column shape, and a valid
    # statement before the error still produces no output at all.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"%s:2:1: `)` can only be used to close a subshell\n" % str(bad).encode()
    )


def test_parse_error_in_one_file_does_not_stop_later_files(tmp_path):
    """A failing file between two good ones does not abort the run."""
    good = write_script(tmp_path, "good.sh", "echo one\n")
    bad = write_script(tmp_path, "bad.sh", "echo two\n)\n")
    res = run_gosh_argv([str(good), str(bad), str(good)])
    # CATCHES: gosh's driver loop would return on the first failing file;
    # the reference keeps going and prints both good files' output with the
    # single error for the middle file, exiting 1 at the end.
    assert res.returncode == 1
    assert res.stdout == b"echo one\necho one\n"
    assert res.stderr == (
        b"%s:2:1: `)` can only be used to close a subshell\n" % str(bad).encode()
    )


def test_files_after_a_failing_file_still_run(tmp_path):
    """A file listed after a failing one is still processed."""
    good = write_script(tmp_path, "good.sh", "echo one\n")
    bad = write_script(tmp_path, "bad.sh", ")\n")
    res = run_gosh_argv([str(bad), str(good)])
    # CATCHES: the error file comes first, yet the good file's output is
    # still printed, so per-file failures never abort the argument loop.
    assert res.returncode == 1
    assert res.stdout == b"echo one\n"
    assert res.stderr == (
        b"%s:1:1: `)` can only be used to close a subshell\n" % str(bad).encode()
    )


def test_non_shell_extension_file_is_still_parsed(tmp_path):
    """A single explicit file argument is parsed whatever its extension."""
    other = write_script(tmp_path, "err.txt", ")\n")
    res = run_gosh_argv([str(other)])
    # CATCHES: explicit arguments are always read as shell programs -- the
    # extension-based detection only applies when walking directories.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"%s:1:1: `)` can only be used to close a subshell\n" % str(other).encode()
    )


def test_empty_script_file_prints_a_single_newline(tmp_path):
    """An empty script file formats to exactly one newline, exit 0."""
    empty = write_script(tmp_path, "empty.sh", "")
    res = run_gosh_argv([str(empty)])
    # CATCHES: the empty program is not empty output -- a single newline is
    # printed for it, matching the stdin behaviour for empty input.
    assert res.returncode == 0
    assert res.stdout == b"\n"
    assert res.stderr == b""


def test_the_same_script_file_twice_is_processed_twice(tmp_path):
    """A repeated file argument is read and printed once per occurrence."""
    good = write_script(tmp_path, "good.sh", "echo one\n")
    res = run_gosh_argv([str(good), str(good)])
    # CATCHES: argument processing is a plain loop over the argv list; no
    # de-duplication or caching of file arguments happens.
    assert res.returncode == 0
    assert res.stdout == b"echo one\necho one\n"


def test_a_lone_dash_argument_means_standard_input():
    """`-` as the only argument makes the binary read the script from stdin."""
    res = run_gosh_argv(["-"], stdin="echo dash\n")
    # CATCHES: `-` is the documented "read stdin" argument; the stdin
    # program is parsed and re-printed exactly like the no-argument form.
    assert res.returncode == 0
    assert res.stdout == b"echo dash\n"
    assert res.stderr == b""


def test_dash_beside_a_file_argument_is_a_missing_path(tmp_path):
    """`-` next to another argument is treated as a path, not as stdin."""
    good = write_script(tmp_path, "good.sh", "echo one\n")
    res = run_gosh_argv(["-", str(good)], stdin="echo dash\n")
    # CATCHES: the stdin meaning applies only when `-` is the sole
    # argument; here it becomes a path to lstat, fails with the missing
    # file wording, the other file still runs, and stdin is never read
    # (`echo dash` appears nowhere in the output).
    assert res.returncode == 1
    assert res.stdout == b"echo one\n"
    assert res.stderr == b"lstat -: no such file or directory\n"


def test_stdin_is_ignored_when_script_files_are_given(tmp_path):
    """With file arguments present, standard input is never consumed."""
    good = write_script(tmp_path, "good.sh", "echo one\n")
    res = run_gosh_argv([str(good)], stdin="echo stdin\n")
    # CATCHES: only when there are no arguments (or just `-`) does the
    # driver fall back to stdin; here the piped script is left unread and
    # only the file's program is printed.
    assert res.returncode == 0
    assert res.stdout == b"echo one\n"
    assert res.stderr == b""


def test_crlf_line_endings_are_stripped():
    """Carriage returns at line ends are removed from the program."""
    res = run_script("echo a\r\necho b\r\n")
    assert res.returncode == 0
    assert res.stdout == b"echo a\necho b\n"
    # CATCHES: even a lone trailing carriage return with no following
    # newline is dropped, so the printer always ends with a bare newline.
    res2 = run_script("echo a\r")
    assert res2.returncode == 0
    assert res2.stdout == b"echo a\n"


def test_nul_bytes_are_silently_dropped():
    """A NUL byte inside a word disappears without any diagnostic."""
    res = run_script(b"echo a\x00b\n")
    # CATCHES: the lexer skips NUL bytes entirely rather than erroring or
    # ending the word, so `a<NUL>b` reprints as the single word `ab`.
    assert res.returncode == 0
    assert res.stdout == b"echo ab\n"
    assert res.stderr == b""


def test_blank_line_runs_collapse_to_one():
    """Multiple blank lines between statements collapse to a single one."""
    res = run_script("echo a\n\n\n\necho b\n")
    # CATCHES: blank lines are structural, not content: a run of three
    # becomes exactly one separator line.
    assert res.returncode == 0
    assert res.stdout == b"echo a\n\necho b\n"


def test_leading_and_trailing_blank_lines_are_dropped():
    """Blank lines at the very start or end of the program vanish."""
    res = run_script("echo a\n\n")
    assert res.returncode == 0
    assert res.stdout == b"echo a\n"
    # CATCHES: leading blanks vanish too, so the first statement always
    # starts on line 1 of the output; the program still ends with exactly
    # one newline.
    res2 = run_script("\n\necho a\n")
    assert res2.returncode == 0
    assert res2.stdout == b"echo a\n"


def test_whitespace_only_lines_count_as_blank():
    """A line of only spaces separates statements like a blank line."""
    res = run_script("echo a\n   \necho b\n")
    # CATCHES: a space-only line is normalised to an empty separator line
    # rather than being kept or dropped, unlike trailing blank lines.
    assert res.returncode == 0
    assert res.stdout == b"echo a\n\necho b\n"


def test_whitespace_only_program_prints_a_single_newline():
    """A program of only spaces or tabs formats to one newline, exit 0."""
    res = run_script("   \n")
    assert res.returncode == 0
    assert res.stdout == b"\n"
    # CATCHES: tab-only input behaves exactly like space-only and like the
    # empty program -- one newline, never zero bytes of output.
    res2 = run_script("\t\t\n")
    assert res2.returncode == 0
    assert res2.stdout == b"\n"


def test_invalid_utf8_in_a_script_file_names_the_file(tmp_path):
    """A non-UTF-8 byte inside a script file is a file-prefixed parse error."""
    bad = tmp_path / "bad.sh"
    bad.write_bytes(b"echo \xff\n")
    res = run_gosh_argv([str(bad)])
    # CATCHES: the invalid-encoding diagnostic carries the script file's
    # path with the same line:column shape as the stdin variant, and the
    # run stops with exit status 1 and no stdout.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"%s:1:6: invalid UTF-8 encoding\n" % str(bad).encode()
