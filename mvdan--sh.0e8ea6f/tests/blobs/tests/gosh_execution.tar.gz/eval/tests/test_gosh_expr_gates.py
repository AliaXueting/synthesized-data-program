"""Expression-gate diagnostics the shipped reference enforces per statement.

The gosh engine evaluates `(( ))` arithmetic commands, `let` expressions
and `[[ ]]` conditionals while running a statement (test.go, runner.go);
the shipped reference contains no interpreter, but its parser validates
these expression grammars up front and rejects malformed ones with exact
diagnostics.  This file pins the gates not covered by the earlier
conditional-validation round: stray words and `=` in arithmetic, dangling
operators inside `let` and `[[ ]]`, the hash character's two behaviours,
unclosed array literals and subscripts, and the missing heredoc delimiter.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

from conftest import run_script


def test_plain_word_is_not_an_arithmetic_operator():
    """A second bare word inside `(( ))` is not an arithmetic operator."""
    res = run_script("(( a b ))\n")
    assert res.returncode == 1
    assert res.stdout == b""
    # CATCHES: after the first operand only real operators may follow; the
    # plain word `b` is reported as `not a valid arithmetic operator` at
    # its own column, the arithmetic analogue of the test-operator error.
    assert res.stderr == (
        b"<standard input>:1:6: not a valid arithmetic operator: `b`\n"
    )


def test_arithmetic_assignment_target_must_be_a_name():
    """Assigning to a literal inside `(( ))` is rejected."""
    res = run_script("(( 1 = 2 ))\n")
    assert res.returncode == 1
    assert res.stdout == b""
    # CATCHES: the `=` is recognised as an assignment operator but must
    # follow a variable name; a numeric left-hand side is refused with the
    # dedicated `` `=` must follow a name `` wording at the operator.
    assert res.stderr == b"<standard input>:1:6: `=` must follow a name\n"


def test_single_close_paren_in_arithmetic_command():
    """`(( a )` reports the mismatched `)` at the command start."""
    res = run_script("(( a )\n")
    assert res.returncode == 1
    assert res.stdout == b""
    # CATCHES: a single closing paren cannot close the double-paren
    # command; the error points back at column 1 with the `reached `)``
    # wording, unlike the EOF variant which fires only at end of input.
    assert res.stderr == (
        b"<standard input>:1:1: reached `)` without matching `((` with `))`\n"
    )


def test_dangling_operator_inside_let():
    """`let` arguments are validated as arithmetic, not kept as words."""
    res = run_script("let a+\n")
    assert res.returncode == 1
    assert res.stdout == b""
    # CATCHES: the trailing `+` inside a `let` argument surfaces the same
    # `` must be followed by an expression `` error as inside `(( ))`,
    # proving the let body is parsed as an expression, not a plain word.
    assert res.stderr == (
        b"<standard input>:1:6: `+` must be followed by an expression\n"
    )


def test_hash_is_not_a_comment_in_arithmetic():
    """`#` inside arithmetic is an invalid operator, not a comment."""
    res = run_script("(( a # b ))\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:6: not a valid arithmetic operator: `#`\n"
    )
    # CATCHES: the same holds inside a `$(( ))` expansion word, where the
    # error is reported at the hash's own column — nothing is swallowed as
    # a comment even when the `#` is glued to the preceding operand.
    res2 = run_script("echo $((a #b))\n")
    assert res2.returncode == 1
    assert res2.stdout == b""
    assert res2.stderr == (
        b"<standard input>:1:11: not a valid arithmetic operator: `#`\n"
    )


def test_dangling_logic_operator_in_conditional():
    """A trailing `&&`/`||` inside `[[ ]]` needs a following expression."""
    res = run_script("[[ a == b && ]]\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:11: `&&` must be followed by an expression\n"
    )
    # CATCHES: the empty right-hand side of a logic operator is reported at
    # the operator itself (not at the `]]`), and `||` behaves identically
    # with the column pointing at its own position.
    res2 = run_script("[[ -n a || ]]\n")
    assert res2.returncode == 1
    assert res2.stdout == b""
    assert res2.stderr == (
        b"<standard input>:1:9: `||` must be followed by an expression\n"
    )


def test_spaced_hash_starts_a_comment_inside_conditional():
    """A spaced `#` inside `[[ ]]` becomes a comment and eats the `]]`."""
    res = run_script("[[ a #b ]]\n")
    assert res.returncode == 1
    assert res.stdout == b""
    # CATCHES: inside the conditional a hash preceded by a space starts a
    # line comment, so the closing `]]` is swallowed and the diagnostic is
    # the generic unclosed-`[[` EOF error pointing at the command start.
    assert res.stderr == (
        b"<standard input>:1:1: reached EOF without matching `[[` with `]]`\n"
    )


def test_unspaced_hash_is_part_of_the_word():
    """A hash glued to a word inside `[[ ]]` is literal text."""
    res = run_script("[[ a#b ]]\n")
    assert res.returncode == 0
    assert res.stdout == b"[[ a#b ]]\n"
    # CATCHES: only a *spaced* hash opens a comment inside the conditional;
    # glued to the preceding word the `#` is plain word text and the whole
    # conditional round-trips verbatim as a valid operand.
    assert res.stderr == b""


def test_unclosed_array_literal_and_subscript():
    """Unclosed `(` in an array literal and `[` in a subscript are errors."""
    res = run_script("a=(1 2\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:3: reached EOF without matching `(` with `)`\n"
    )
    # CATCHES: the array literal's opening paren is reported at its own
    # column (after the `=`), and an unclosed subscript bracket gets the
    # matching `[`/`]` wording at the bracket's column.
    res2 = run_script("a[b\n")
    assert res2.returncode == 1
    assert res2.stdout == b""
    assert res2.stderr == (
        b"<standard input>:1:2: reached EOF without matching `[` with `]`\n"
    )


def test_heredoc_operator_requires_its_delimiter():
    """`<<` with no delimiter word is a parse error, not an empty heredoc."""
    res = run_script("cat <<\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:1:5: `<<` must be followed by a word\n"
    # CATCHES: the heredoc operator must be followed by a delimiter word;
    # a following `;` or newline is refused with the same wording at the
    # operator's position — no zero-delimiter heredoc is invented.
    res2 = run_script("cat << ;\n")
    assert res2.returncode == 1
    assert res2.stdout == b""
    assert res2.stderr == b"<standard input>:1:5: `<<` must be followed by a word\n"


def test_anonymous_function_is_rejected():
    """`if()` is parsed as a zsh anonymous function, not a bash one."""
    res = run_script("if() { :; }\n")
    assert res.returncode == 1
    assert res.stdout == b""
    # CATCHES: a keyword followed by `()` would be an anonymous function
    # (a zsh feature); under the default bash grammar this is refused with
    # the dedicated wording naming both the feature and the dialect.
    assert res.stderr == (
        b"<standard input>:1:3: anonymous functions are a zsh feature; "
        b"tried parsing as bash (parsed as bash via -ln=auto)\n"
    )


def test_valid_arithmetic_statement_forms_roundtrip():
    """Chained and subscripted arithmetic assignments round-trip."""
    script = "((x = y = 1))\na[i]+=1\necho $((a[0] + 1))\n"
    res = run_script(script)
    assert res.returncode == 0
    assert res.stdout == script.encode()
    # CATCHES: chained assignment inside the arithmetic command, the
    # `+=` form with an array subscript, and a subscript read inside a
    # `$(( ))` expansion are all accepted statement word forms.
    assert res.stderr == b""
