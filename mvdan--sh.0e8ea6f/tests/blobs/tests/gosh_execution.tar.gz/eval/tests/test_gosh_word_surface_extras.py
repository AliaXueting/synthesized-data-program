"""Word and builtin-argument forms the engine parses per statement.

The gosh engine would expand these words and run these builtins while
executing each statement (runner.go, vars.go, builtin.go); the shipped
reference contains no interpreter, so this surface is pinned through the
round-trip: the expansion spellings that parse as single words, the
argument words of the builtins whose flags were not exercised by the
earlier word-surface round, and the arithmetic normalisation applied
inside builtin arguments.

All expected bytes were recorded by feeding the program on stdin to
``./executable`` (non-terminal script mode).
"""

from __future__ import annotations

from conftest import run_script


def test_redirect_only_command_substitution():
    """`$(<file)` parses as a substitution holding just a redirect."""
    res = run_script("echo $(<file)\n")
    assert res.returncode == 0
    # CATCHES: the bash shorthand for reading a file inside a command
    # substitution is a valid word form — the redirect is the command's
    # whole body and the spelling round-trips unchanged.
    assert res.stdout == b"echo $(<file)\n"
    assert res.stderr == b""


def test_bash_expansion_operator_extras_roundtrip():
    """`${x: -1}`, `${!x[@]}`, `${x^}` and `${x,}` round-trip verbatim."""
    script = "echo ${x: -1}\necho ${!x[@]}\necho ${x^}\necho ${x,}\n"
    res = run_script(script)
    assert res.returncode == 0
    # CATCHES: the arithmetic default with a space after the colon, the
    # key-list indirection, and both single-char case-modification
    # operators are preserved byte for byte.
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_flags_parameter_roundtrip():
    """`$-` and its braced form `${-}` round-trip as single words."""
    res = run_script("echo $-\necho ${-}\n")
    assert res.returncode == 0
    # CATCHES: the current-flags special parameter is a distinct word form
    # from the seven already pinned; both the short and braced spellings
    # survive without being split or renamed.
    assert res.stdout == b"echo $-\necho ${-}\n"
    assert res.stderr == b""


def test_localized_string_quoting_roundtrip():
    """`$"..."` locale quoting is preserved, not rewritten to plain quotes."""
    res = run_script('echo $"localized"\n')
    assert res.returncode == 0
    # CATCHES: the dollar-prefixed double-quoted string is its own quoting
    # form; the printer keeps the `$` rather than normalising it away.
    assert res.stdout == b'echo $"localized"\n'
    assert res.stderr == b""


def test_ansi_c_escape_sequences_roundtrip():
    """Escape sequences inside `$'...'` survive untouched."""
    script = "echo $'a\\tb\\n'\necho $'\\x41\\101'\necho $'\\\\'\n"
    res = run_script(script)
    assert res.returncode == 0
    # CATCHES: tab/newline escapes, two-digit hex and octal escapes and an
    # escaped backslash are kept exactly as written — the string is never
    # decoded or re-encoded by the round-trip.
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_trailing_escaped_quote_in_ansi_c_string():
    """A trailing `\\'` escapes the closing quote and never terminates."""
    res = run_script("echo $'\\x41\\101\\'\n")
    assert res.returncode == 1
    assert res.stdout == b""
    # CATCHES: the final backslash escapes the closing quote, so the
    # string runs to EOF and the unclosed-quote error points at the
    # opening `$'` (column 6) with the reached-EOF wording.
    assert res.stderr == (
        b"<standard input>:1:6: reached EOF without closing quote `'`\n"
    )


def test_array_subscript_word_forms_roundtrip():
    """Subscripted assignments, unsets and associative literals round-trip."""
    script = (
        "a[$i]=x\n"
        "unset a[0]\n"
        "declare -A x=([a]=1 [b]=2)\n"
        "local -n ref=x\n"
    )
    res = run_script(script)
    assert res.returncode == 0
    # CATCHES: a subscript with an expansion, an array-element unset
    # argument, an associative-array literal with `[k]=v` elements and the
    # nameref spelling of `local` are all accepted statement words.
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_arithmetic_in_builtin_arguments_is_normalised():
    """`$(( ))` inside builtin arguments gets operator spacing."""
    res = run_script("shift $((n+1))\n")
    assert res.returncode == 0
    assert res.stdout == b"shift $((n + 1))\n"
    # CATCHES: builtin argument words are parsed as real words, so the
    # arithmetic inside them is canonicalised (`+` gains spaces) exactly
    # like anywhere else — also for `exit`.
    res2 = run_script("exit $((1+1))\n")
    assert res2.returncode == 0
    assert res2.stdout == b"exit $((1 + 1))\n"


def test_combined_set_flag_words_roundtrip():
    """Clustered `set` flags, `+x` reset and friends round-trip verbatim."""
    script = "set -euo pipefail\nset -e -u\nset +x\nunalias -a\nhash -r\ncd -\n"
    res = run_script(script)
    assert res.returncode == 0
    # CATCHES: the clustered short-flag spelling `-euo` with a trailing
    # `-o` option, the `+` reset form, `unalias -a`, `hash -r` and the
    # bare `cd -` are all statement words the engine must accept.
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_builtin_flag_word_extras_roundtrip():
    """`export -f`, `wait -n` and a quoted `eval` script round-trip."""
    script = 'export -f f\nwait -n\neval "a=1; b=2"\n'
    res = run_script(script)
    assert res.returncode == 0
    # CATCHES: the function-export and wait-for-any flag words parse, and
    # the eval builtin's quoted argument keeps its inner `;` and spaces —
    # it is one word, not a statement list.
    assert res.stdout == script.encode()
    assert res.stderr == b""


def test_heredoc_fed_read_roundtrip():
    """A `read` statement with its heredoc attached round-trips inline."""
    res = run_script("read -r a b <<EOF\nx y\nEOF\n")
    assert res.returncode == 0
    # CATCHES: the heredoc stays attached to the read statement it feeds,
    # with the body and terminator printed after the command line exactly
    # as written — the redirect is not moved or duplicated.
    assert res.stdout == b"read -r a b <<EOF\nx y\nEOF\n"
    assert res.stderr == b""
