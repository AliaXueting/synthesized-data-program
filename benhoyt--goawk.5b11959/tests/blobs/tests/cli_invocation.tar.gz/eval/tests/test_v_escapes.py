"""-v var=value argument parsing and its backslash-escape processing."""

import pytest

from conftest import run_goawk


@pytest.mark.parametrize("value,expected", [
    (r"a\tb", "a\tb"),
    (r"a\nb", "a\nb"),
    (r"a\rb", "a\rb"),
    ("\\101", "A"),
    ("\\x41", "A"),
    (r"\z", "z"),
    (r"a\\b", "a\\b"),
    ("\\u263a", "☺"),
], ids=["tab", "newline", "carriage-return", "octal", "hex", "unknown-char",
        "escaped-backslash", "unicode-escape"])
def test_v_interprets_backslash_escapes(value, expected):
    """-v values are unescaped like AWK string literals."""
    # CATCHES: assigning the raw bytes (a literal backslash-t) instead of the
    # decoded character for every escape class.
    res = run_goawk(["-v", "x=" + value, 'BEGIN { printf "[%s]", x }'])
    assert res.returncode == 0
    assert res.stdout == "[%s]" % expected
    assert res.stderr == ""


def test_v_bad_hex_escape_falls_back_to_the_raw_value():
    """'\\xZZ' has no hex digits, so the raw text is assigned unchanged."""
    # CATCHES: an unescaping error being fatal (or silently dropped); the
    # documented behaviour is to keep the original value.
    res = run_goawk(["-v", "x=" + r"\xZZ", 'BEGIN { printf "[%s]", x }'])
    assert res.returncode == 0
    assert res.stdout == r"[\xZZ]"
    assert res.stderr == ""


def test_v_bad_unicode_escape_falls_back_to_the_raw_value():
    """'\\uZZ' (no digits) and a surrogate '\\ud800' both keep the raw text."""
    # CATCHES: only the no-digits case being handled; an invalid Unicode code
    # point must also fall back rather than error or emit a replacement char.
    no_digits = run_goawk(["-v", "x=" + r"\uZZ", 'BEGIN { printf "[%s]", x }'])
    assert no_digits.returncode == 0
    assert no_digits.stdout == r"[\uZZ]"
    surrogate = run_goawk(["-v", "x=" + r"\ud800", 'BEGIN { printf "[%s]", x }'])
    assert surrogate.returncode == 0
    assert surrogate.stdout == r"[\ud800]"


def test_v_trailing_backslash_is_kept_literally():
    """A value ending in a single backslash is assigned with that backslash."""
    # CATCHES: the trailing backslash being dropped or flagged as a bad escape;
    # unescaping keeps it as a literal backslash.
    res = run_goawk(["-v", "x=a\\", 'BEGIN { printf "[%s]", x }'])
    assert res.returncode == 0
    assert res.stdout == "[a\\]"
    assert res.stderr == ""


def test_v_value_containing_a_real_newline_is_kept_raw():
    """A literal newline in the value cannot be unescaped, so it stays as-is."""
    # CATCHES: rejecting (or stripping) the newline; the failed unescape falls
    # back to the original value, newline included.
    res = run_goawk(["-v", "x=a\nb", 'BEGIN { printf "[%s]", x }'])
    assert res.returncode == 0
    assert res.stdout == "[a\nb]"
    assert res.stderr == ""


def test_v_value_may_contain_further_equals_signs():
    """Only the first '=' splits the name from the value."""
    # CATCHES: splitting on every '=', which would mangle values like 'a=b'.
    res = run_goawk(["-v", "x=a=b", 'BEGIN { printf "[%s]", x }'])
    assert res.returncode == 0
    assert res.stdout == "[a=b]"
    assert res.stderr == ""


def test_v_empty_value_assigns_the_empty_string():
    """'x=' assigns the empty string, not an error."""
    # CATCHES: rejecting an empty value (or leaving x unset, printing nothing
    # at all between the brackets).
    res = run_goawk(["-v", "x=", 'BEGIN { printf "[%s]", x }'])
    assert res.returncode == 0
    assert res.stdout == "[]"
    assert res.stderr == ""


def test_repeated_v_flags_last_one_wins():
    """Two -v flags for the same variable: the later assignment overwrites."""
    # CATCHES: keeping the first value (or erroring on a duplicate name).
    res = run_goawk(["-v", "x=first", "-v", "x=second", 'BEGIN { print x }'])
    assert res.returncode == 0
    assert res.stdout == "second\n"
    assert res.stderr == ""


def test_v_assigns_builtin_variables(tmp_path):
    """-v can set builtins such as RS before the program runs."""
    # CATCHES: -v assignments only applying to user variables; record
    # splitting must honour the -v RS value.
    res = run_goawk(["-v", "RS=;", "{ print }"], stdin="a b;c\nd;e", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "a b\nc\nd\ne\n"
    assert res.stderr == ""


def test_v_with_invalid_variable_name_is_not_an_error():
    """A -v name that is not a legal AWK variable is accepted on the CLI."""
    # CATCHES: validating -v names eagerly and failing; goawk accepts the
    # argument and simply never uses the bogus variable.
    res = run_goawk(["-v", "1x=2", 'BEGIN { print "ok" }'])
    assert res.returncode == 0
    assert res.stdout == "ok\n"
    assert res.stderr == ""
