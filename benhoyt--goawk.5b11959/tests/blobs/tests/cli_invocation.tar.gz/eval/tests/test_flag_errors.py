"""Argument validation errors: every diagnostic goes to stderr with exit 1."""

import pytest

from conftest import SHORT_USAGE, run_goawk, write_file


def test_no_program_and_no_progfile_prints_usage():
    """With no arguments at all goawk prints just the short usage line."""
    # CATCHES: printing the whole option list (or nothing) instead of the
    # one-line usage, or exiting with a status other than 1.
    res = run_goawk([])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == SHORT_USAGE + "\n"


def test_double_dash_alone_still_lacks_a_program():
    """A lone '--' consumes itself but leaves no program, so usage is printed."""
    # CATCHES: treating '--' itself as the end marker AND a program source, or
    # passing it through as an operand; the usage error must still appear.
    res = run_goawk(["--"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == SHORT_USAGE + "\n"


@pytest.mark.parametrize("flag", ["-z", "--bogus", "-cfoo", "-data"])
def test_unknown_flag_is_rejected_with_its_name(flag):
    """Undefined flags report 'flag provided but not defined' naming the arg."""
    # CATCHES: the exact wording and the echoed argument, plus exit status 1;
    # a generic 'invalid flag' message would not match.
    res = run_goawk([flag, "BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "flag provided but not defined: %s\n" % flag


@pytest.mark.parametrize("flag", [
    "-F", "-f", "-v", "-E", "-i", "-o", "-N",
    "-cpuprofile", "-memprofile", "-covermode", "-coverprofile",
])
def test_value_flag_at_end_of_args_needs_an_argument(flag):
    """Every value-taking flag errors with 'flag needs an argument' at end of args."""
    # CATCHES: a flag that silently swallows the following argument (or the
    # program operand) instead of demanding a value.
    res = run_goawk([flag])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "flag needs an argument: %s\n" % flag


@pytest.mark.parametrize("var_args", [["-v", "foo"], ["-vfoo"]], ids=["separated", "attached"])
def test_v_without_equals_is_rejected(var_args):
    """-v values must contain '=' or the name=value format error is printed."""
    # CATCHES: accepting a bare variable name (assigning empty) rather than
    # rejecting it with the documented message.
    res = run_goawk(var_args + ["BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "-v flag must be in format name=value\n"


@pytest.mark.parametrize("mode_args", [["-covermode", "bogus"], ["-covermode=bogus"]],
                         ids=["separated", "attached"])
def test_invalid_covermode_is_rejected(mode_args):
    """-covermode only accepts set and count."""
    # CATCHES: silently ignoring an unknown coverage mode instead of failing
    # with the 'can only be one of' diagnostic.
    res = run_goawk(mode_args + ["BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "-covermode can only be one of: set, count\n"


@pytest.mark.parametrize("mode_args", [["-N", "bogus"], ["-Nbogus"]], ids=["separated", "attached"])
def test_invalid_newline_mode_is_rejected(mode_args):
    """-N only accepts smart, raw and crlf."""
    # CATCHES: falling back to the default newline mode for an invalid value
    # instead of erroring out.
    res = run_goawk(mode_args + ["BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "-N arg can only be one of: smart, raw, crlf\n"


@pytest.mark.parametrize("mode_args", [["-i", "abc"], ["-iabc"]], ids=["separated", "attached"])
def test_invalid_input_mode_is_rejected(mode_args):
    """-i validates its mode string and reports it in quotes."""
    # CATCHES: mode validation happening (or not) for the glued form too, and
    # the exact quoted-mode wording of the message.
    res = run_goawk(mode_args + ["BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid input mode "abc"\n'


@pytest.mark.parametrize("mode_args", [["-o", "xyz"], ["-oxyz"]], ids=["separated", "attached"])
def test_invalid_output_mode_is_rejected(mode_args):
    """-o validates its mode string and reports it in quotes."""
    # CATCHES: output-mode validation being skipped, which would let the
    # program run instead of exiting 1.
    res = run_goawk(mode_args + ["BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid output mode "xyz"\n'


def test_header_flag_requires_input_mode():
    """-H without -i (or --csv) is rejected."""
    # CATCHES: accepting -H on its own, which would change header handling
    # instead of failing with the documented error.
    res = run_goawk(["-H", "{ print 1 }"], stdin="x\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "-H only allowed together with -i\n"


@pytest.mark.parametrize("prog_args", [
    ["-f", "nope.awk"],
    ["-fnope.awk"],
    ["-E", "nope.awk"],
    ["-Enope.awk"],
], ids=["-f separated", "-f attached", "-E separated", "-E attached"])
def test_missing_progfile_is_reported_with_quoted_name(tmp_path, prog_args):
    """A nonexistent program file is reported as file "name" not found."""
    # CATCHES: the quoted-name wording (not a raw OS error), for both -f and
    # -E and for both glued spellings.
    res = run_goawk(prog_args, cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "nope.awk" not found\n'


def test_directory_as_progfile_reports_read_error(tmp_path):
    """A directory as the -f argument opens but fails to read."""
    # CATCHES: the not-found wording being reused for every failure; a
    # directory yields the 'is a directory' read error instead.
    (tmp_path / "adir").mkdir()
    res = run_goawk(["-f", "adir"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "read adir: is a directory\n"


def test_newline_mode_is_validated_before_the_program_is_read():
    """-N parsing happens during argument scanning, before the program loads."""
    # CATCHES: validation order -- a bad -N must win over a later missing
    # program file or parse error, because args are scanned first.
    res = run_goawk(["-N", "bogus", "-f", "nope.awk", "`"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "-N arg can only be one of: smart, raw, crlf\n"


def test_input_mode_is_validated_after_the_program_parses():
    """A bad -i mode is only reported once the program itself parses cleanly."""
    # CATCHES: validation order in the other direction -- the parse error for
    # the program text must take precedence over the input-mode error.
    res = run_goawk(["-i", "abc", "`"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<cmdline>:1:1: unexpected char\n`\n^\n"


def test_header_without_input_mode_reported_after_parse(tmp_path):
    """-H without -i is checked after parsing, so a broken program wins."""
    # CATCHES: ordering of the -H check relative to the parse step; the parse
    # error must be reported first.
    res = run_goawk(["-H", "`"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<cmdline>:1:1: unexpected char\n`\n^\n"


def test_cpu_profile_in_unwritable_path_reports_create_error(tmp_path):
    """-cpuprofile pointing into a missing directory fails with a create error."""
    # CATCHES: profile creation errors being swallowed; the run must exit 1
    # with the 'could not create CPU profile' diagnostic.
    res = run_goawk(["-cpuprofile=nodir/x", "BEGIN { print 1 }"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "could not create CPU profile: open nodir/x: no such file or directory\n"


def test_cover_profile_in_unwritable_path_reports_write_error(tmp_path):
    """-coverprofile into a missing directory fails when writing the profile."""
    # CATCHES: coverage profile write errors; the program still runs first, so
    # its output is produced before the error and the exit status is 1.
    res = run_goawk(["-coverprofile=nodir/x", "BEGIN { print \"out\" }"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == "out\n"
    assert res.stderr == "unable to write coverage profile: open nodir/x: no such file or directory\n"
