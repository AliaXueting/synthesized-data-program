"""Shared helpers for the cli_invocation test module.

Every test runs the goawk binary as a black box through ``run_goawk``, which
resolves the executable from ``PROGRAMGYM_EXECUTABLE`` and always feeds the
child a closed (EOF-immediate) stdin plus a pinned, hermetic environment.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

# The reference binary's own "-h" banner, recorded from ./executable -h.
VERSION = "v1.32.0"
COPYRIGHT = "GoAWK " + VERSION + " - Copyright (c) 2022 Ben Hoyt"
SHORT_USAGE = "usage: goawk [-F fs] [-v var=value] [-f progfile | 'prog'] [file ...]"


def _executable() -> Path:
    """Absolute path of the binary under test."""
    raw = os.environ.get("PROGRAMGYM_EXECUTABLE") or "executable"
    path = Path(raw)
    if not path.is_absolute():
        # run.sh starts pytest in the module root, so a relative setting
        # resolves against the directory that contains eval/tests/.
        rooted = Path(__file__).resolve().parents[2] / raw
        if rooted.exists():
            return rooted
    return path


def _child_env() -> dict:
    """Pinned child environment, forwarding the coverage hook when set."""
    env = {
        "PATH": "/usr/bin:/bin",
        "LC_ALL": "C.UTF-8",
        "LANG": "C.UTF-8",
    }
    # Coverage instrumentation hook: the pipeline rebuilds the reference with
    # -cover and points GOCOVERDIR at a counter directory; without forwarding
    # it the module's coverage report would come out empty.
    # cov_env = {"GOCOVERDIR": v} for v in [os.environ.get("GOCOVERDIR")] if v
    cov_env = dict([("GOCOVERDIR", v) for v in [os.environ.get("GOCOVERDIR")] if v])
    env.update(cov_env)
    return env


class Result:
    """One goawk invocation: decoded stdout/stderr and the exit status."""

    def __init__(self, proc: subprocess.CompletedProcess) -> None:
        self.returncode = proc.returncode
        self.stdout = proc.stdout.decode("utf-8", errors="replace")
        self.stderr = proc.stderr.decode("utf-8", errors="replace")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return ("Result(returncode=%r, stdout=%r, stderr=%r)"
                % (self.returncode, self.stdout, self.stderr))


def run_goawk(args, stdin: str = "", cwd=None, timeout: float = 10.0) -> Result:
    """Run the binary under test with ``args`` and return its Result.

    ``stdin`` defaults to an empty (immediately-EOF) pipe so a program that
    reads input records never blocks waiting on a terminal.
    """
    return run_goawk_binary(_executable(), args, stdin=stdin, cwd=cwd, timeout=timeout)


def run_goawk_binary(binary, args, stdin: str = "", cwd=None,
                     timeout: float = 10.0) -> Result:
    """Run an explicit binary path (e.g. a renamed copy) exactly like run_goawk."""
    argv = [str(binary)] + [str(a) for a in args]
    proc = subprocess.run(
        argv,
        input=stdin.encode("utf-8"),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=_child_env(),
        timeout=timeout,
    )
    return Result(proc)


def write_file(directory, name: str, text: str) -> Path:
    """Create ``name`` inside ``directory`` (usually tmp_path) and return it."""
    path = Path(directory) / name
    path.write_text(text, encoding="utf-8")
    return path
