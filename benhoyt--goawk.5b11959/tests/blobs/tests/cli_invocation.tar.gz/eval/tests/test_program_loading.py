"""How goawk obtains the AWK program text: -f/-E files, stdin, concatenation
and the per-file names used in parse-error messages (internal/parseutil).
"""

from conftest import _executable, run_goawk, write_file

GOOD = 'BEGIN { print "good" }\n'
# Parse error on line 2 (a tab-indented "x*" with nothing after the '*').
BAD_A = "BEGIN {\n\tx*\n}\n"
# Parse error on line 2 with a different message (a stray ')').
BAD_B = "BEGIN {\n\ty)\n}\n"


def test_progfile_flag_takes_precedence_over_program_operand(tmp_path):
    """With -f given, the first non-flag operand is not the program."""
    # CATCHES: appending the operand program after the -f program, or using it
    # instead of the file; only the file's program may run.
    write_file(tmp_path, "prog.awk", 'BEGIN { print "from file" }\n')
    res = run_goawk(["-f", "prog.awk", 'BEGIN { print "from arg" }'], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "from file\n"
    assert res.stderr == ""


def test_multiple_progfiles_are_concatenated(tmp_path):
    """Two -f files are joined into one program and both run."""
    # CATCHES: only the last (or first) -f file being kept, which would drop
    # one of the two BEGIN blocks.
    write_file(tmp_path, "a.awk", 'BEGIN { print "one" }\n')
    write_file(tmp_path, "b.awk", 'BEGIN { print "two" }\n')
    res = run_goawk(["-f", "a.awk", "-f", "b.awk"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "one\ntwo\n"
    assert res.stderr == ""


def test_progfiles_without_trailing_newline_are_separated(tmp_path):
    """A -f file with no final newline does not fuse with the next file."""
    # CATCHES: naive byte concatenation, which would join '}' and 'BEGIN' on
    # one line and produce a parse error instead of running both blocks.
    write_file(tmp_path, "a.awk", 'BEGIN { print 1 }')
    write_file(tmp_path, "b.awk", 'BEGIN { print 2 }')
    res = run_goawk(["-f", "a.awk", "-f", "b.awk"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "1\n2\n"
    assert res.stderr == ""


def test_empty_progfile_contributes_nothing(tmp_path):
    """An empty -f file is allowed and simply adds no source."""
    # CATCHES: an empty program file being treated as an error or as the whole
    # program; the second file's block must still run.
    write_file(tmp_path, "empty.awk", "")
    write_file(tmp_path, "real.awk", 'BEGIN { print "real" }\n')
    res = run_goawk(["-f", "empty.awk", "-f", "real.awk"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "real\n"
    assert res.stderr == ""


def test_function_defined_in_one_progfile_used_in_next(tmp_path):
    """A function from the first -f file is visible in the second."""
    # CATCHES: parsing each -f file as an independent program instead of one
    # concatenated source.
    write_file(tmp_path, "lib.awk", "function bump(x) { return x + 1 }\n")
    write_file(tmp_path, "main.awk", 'BEGIN { print bump(41) }\n')
    res = run_goawk(["-f", "lib.awk", "-f", "main.awk"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "42\n"
    assert res.stderr == ""


def test_same_progfile_twice_reports_duplicate_function(tmp_path):
    """Loading one -f file twice yields a duplicate function definition error."""
    # CATCHES: de-duplicating repeated -f arguments instead of concatenating
    # them, which must trip the parser's duplicate-function check.
    write_file(tmp_path, "lib.awk", "function bump(x) { return x + 1 }\n")
    res = run_goawk(["-f", "lib.awk", "-f", "lib.awk"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == ('lib.awk:1:10: function "bump" already defined\n'
                          'function bump(x) { return x + 1 }\n'
                          '         ^\n')


def test_progfile_from_stdin_with_dash(tmp_path):
    """'-f -' reads the program source from standard input."""
    # CATCHES: '-' being treated as a literal file name (missing file error)
    # instead of as the stdin program source.
    res = run_goawk(["-f", "-"], stdin='BEGIN { print "stdin prog" }\n', cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "stdin prog\n"
    assert res.stderr == ""


def test_progfile_from_stdin_attached_dash(tmp_path):
    """'-f-' (glued) also reads the program source from standard input."""
    # CATCHES: the glued -f form not special-casing '-' as stdin.
    res = run_goawk(["-f-"], stdin='BEGIN { print "glued stdin" }\n', cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "glued stdin\n"
    assert res.stderr == ""


def test_stdin_progfile_and_file_progfile_concatenate(tmp_path):
    """'-f file -f -' concatenates the file program with stdin's."""
    # CATCHES: stdin not being usable as one of several program sources.
    write_file(tmp_path, "a.awk", 'BEGIN { print "file part" }\n')
    res = run_goawk(["-f", "a.awk", "-f", "-"],
                    stdin='BEGIN { print "stdin part" }\n', cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "file part\nstdin part\n"
    assert res.stderr == ""


def test_stdin_progfile_is_named_stdin_in_errors(tmp_path):
    """Parse errors in a stdin program are reported against '<stdin>'."""
    # CATCHES: using '<cmdline>' (or '-') as the name for stdin programs; the
    # file name in the diagnostic must be <stdin>.
    res = run_goawk(["-f", "-"], stdin="`", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<stdin>:1:1: unexpected char\n`\n^\n"


def test_command_line_program_is_named_cmdline_in_errors(tmp_path):
    """Parse errors in a program operand are reported against '<cmdline>'."""
    # CATCHES: reporting the program text's origin with a different label
    # (for example '-' or the executable name).
    res = run_goawk(["`"], stdin="", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<cmdline>:1:1: unexpected char\n`\n^\n"


def test_parse_error_in_second_progfile_uses_its_own_name_and_line(tmp_path):
    """Errors in the second -f file keep that file's name and local line."""
    # CATCHES: line numbers of the concatenated source being reported as-is;
    # the FileReader must map back to bad.awk line 2, column 4.
    write_file(tmp_path, "good.awk", GOOD)
    write_file(tmp_path, "bad.awk", BAD_A)
    res = run_goawk(["-f", "good.awk", "-f", "bad.awk"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == ("bad.awk:2:4: expected expression instead of <newline>\n"
                          "    x*\n"
                          "      ^\n")


def test_parse_error_line_mapping_is_independent_of_file_order(tmp_path):
    """A broken file reports its own line number wherever it is listed."""
    # CATCHES: the line mapping only working for the last (or first) file;
    # both orders must report bad.awk:2:4.
    write_file(tmp_path, "good.awk", GOOD)
    write_file(tmp_path, "bad.awk", BAD_A)
    first = run_goawk(["-f", "bad.awk", "-f", "good.awk"], cwd=tmp_path)
    second = run_goawk(["-f", "good.awk", "-f", "bad.awk"], cwd=tmp_path)
    assert first.returncode == 1
    assert first.stderr == ("bad.awk:2:4: expected expression instead of <newline>\n"
                            "    x*\n"
                            "      ^\n")
    assert second.stderr == first.stderr


def test_first_broken_progfile_wins(tmp_path):
    """With two broken files, the one whose error comes first is reported."""
    # CATCHES: reporting the second file's error (or a merged diagnostic);
    # parsing stops at the first error in the concatenated source.
    write_file(tmp_path, "badA.awk", BAD_A)
    write_file(tmp_path, "badB.awk", BAD_B)
    res = run_goawk(["-f", "badB.awk", "-f", "badA.awk"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == ("badB.awk:2:3: expected ; or newline between statements\n"
                          "    y)\n"
                          "     ^\n")


def test_error_on_first_line_of_second_progfile(tmp_path):
    """A missing trailing newline does not shift the second file's line 1."""
    # CATCHES: the newline normalization being skipped, which would make the
    # second file's first line land on the previous file's last line.
    write_file(tmp_path, "a.awk", 'BEGIN { print 1 }')
    write_file(tmp_path, "b.awk", "`\n")
    res = run_goawk(["-f", "a.awk", "-f", "b.awk"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "b.awk:1:1: unexpected char\n`\n^\n"


def test_stdin_progfile_between_files_keeps_its_name(tmp_path):
    """With '-f good -f - -f bad', an error in stdin is reported as <stdin>."""
    # CATCHES: the stdin source losing its own name in the line-to-file map
    # when it sits between two regular files.
    write_file(tmp_path, "good.awk", GOOD)
    write_file(tmp_path, "bad.awk", BAD_A)
    res = run_goawk(["-f", "good.awk", "-f", "-", "-f", "bad.awk"],
                    stdin="`", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<stdin>:1:1: unexpected char\n`\n^\n"


def test_empty_stdin_program_is_allowed(tmp_path):
    """'-f -' with an empty stdin yields an empty program that runs cleanly."""
    # CATCHES: an empty stdin program being an error; it must simply run and
    # produce no output, while the trailing -f file still executes.
    write_file(tmp_path, "real.awk", 'BEGIN { print "after empty stdin" }\n')
    res = run_goawk(["-f", "-", "-f", "real.awk"], stdin="", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "after empty stdin\n"
    assert res.stderr == ""


def test_unreadable_stdin_progfile_reports_read_error(tmp_path):
    """'-f -' with an unreadable stdin fails with the read error, not a crash."""
    # CATCHES: a read error while loading the stdin program being ignored (an
    # empty program would run instead) or crashing without a message.
    import os
    import subprocess

    from conftest import _child_env
    directory = tmp_path / "adir"
    directory.mkdir()
    fd = os.open(str(directory), os.O_RDONLY)
    try:
        proc = subprocess.run(
            [str(_executable()), "-f", "-"],
            stdin=fd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env=_child_env(), timeout=10)
    finally:
        os.close(fd)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"read /dev/stdin: is a directory\n"


def test_wildcards_in_progfile_names_are_not_expanded(tmp_path):
    """Program file names are used verbatim; no glob expansion on Linux."""
    # CATCHES: wildcard expansion (a Windows-only feature in goawk) being
    # applied to -f arguments or input operands on POSIX systems.
    write_file(tmp_path, "p1.awk", 'BEGIN { print "one" }\n')
    write_file(tmp_path, "p2.awk", 'BEGIN { print "two" }\n')
    write_file(tmp_path, "in1.txt", "x\n")
    write_file(tmp_path, "in2.txt", "y\n")
    progfile = run_goawk(["-f", "p*.awk"], cwd=tmp_path)
    assert progfile.returncode == 1
    assert progfile.stdout == ""
    assert progfile.stderr == 'file "p*.awk" not found\n'
    operand = run_goawk(["{ print }", "in*.txt"], stdin="", cwd=tmp_path)
    assert operand.returncode == 1
    assert operand.stderr == 'file "in*.txt" not found\n'
