"""-h/--help and -version/--version behaviour of the goawk binary."""

from conftest import COPYRIGHT, SHORT_USAGE, run_goawk

# Exact bytes of `./executable -h` (copyright line, blank line, short usage,
# blank line, then the full option list; the option list itself ends with a
# single trailing newline).
HELP_TEXT = """GoAWK v1.32.0 - Copyright (c) 2022 Ben Hoyt

usage: goawk [-F fs] [-v var=value] [-f progfile | 'prog'] [file ...]

Standard AWK arguments:
  --csv             enable CSV input mode; equivalent to "-i csv"
  -F separator      field separator (default " ")
  -f progfile       load AWK source from progfile (multiple allowed)
  -v var=value      variable assignment (multiple allowed)

Additional GoAWK features:
  -c                use Unicode chars for index, length, match, substr, and %c
  -E progfile       load program, treat as last option, disable var=value args
  -H                parse header row and enable @"field" in CSV input mode
  -h, --help        show this help message
  -i mode           parse input into fields using CSV format (ignore FS and RS)
                    'csv|tsv [separator=<char>] [comment=<char>] [header]'
  -o mode           use CSV output for print with args (ignore OFS and ORS)
                    'csv|tsv [separator=<char>]'
  -N mode           newline output translation: smart (default), raw, crlf
  -version          show GoAWK version and exit

GoAWK debugging arguments:
  -coverappend      append to coverage profile instead of overwriting
  -covermode mode   set coverage mode: set, count (default "set")
  -coverprofile fn  write coverage profile to file
  -cpuprofile fn    write CPU profile to file
  -d                print parsed syntax tree to stdout and exit
  -da               print VM assembly instructions to stdout and exit
  -dt               print variable type information to stdout and exit
  -memprofile fn    write memory profile to file
"""


def test_help_short_flag_prints_banner_usage_and_options():
    """-h prints copyright, short usage and the whole option list to stdout."""
    # CATCHES: a re-implementation that drops or rewords any -h line, sends the
    # usage to stderr, or exits non-zero on -h fails the byte-exact compare.
    res = run_goawk(["-h"])
    assert res.stdout == HELP_TEXT
    assert res.stderr == ""
    assert res.returncode == 0


def test_help_long_flag_matches_short_flag_output():
    """--help produces exactly the same text as -h, on stdout, exiting 0."""
    # CATCHES: only the short -h form being wired up (or --help being rejected
    # as an unknown flag) makes the two outputs differ or the run fail.
    short = run_goawk(["-h"])
    long = run_goawk(["--help"])
    assert long.returncode == 0
    assert long.stderr == ""
    assert long.stdout == short.stdout
    assert long.stdout == HELP_TEXT


def test_version_flags_print_version_and_exit_zero():
    """Both -version and --version print the bare version string on stdout."""
    # CATCHES: version output with extra text (copyright, newline style) or a
    # non-zero exit status; also that --version is accepted like -version.
    for flag in ("-version", "--version"):
        res = run_goawk([flag])
        assert res.stdout == "v1.32.0\n"
        assert res.stderr == ""
        assert res.returncode == 0


def test_help_flag_wins_even_after_other_flags():
    """-h anywhere in the flag section prints help instead of running a program."""
    # CATCHES: flag parsing that stops at -h or that tries to run the trailing
    # program operand would print something other than the help text.
    res = run_goawk(["-F", ",", "-h", "BEGIN { print \"not run\" }"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == HELP_TEXT


def test_help_flag_after_program_operand_is_an_input_file():
    """Once flag parsing ended at the program operand, -h is just a filename."""
    # CATCHES: implementations that keep scanning for -h after the program
    # operand would print help; here it must be treated as an input file name.
    res = run_goawk(["{ print }", "-h"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "-h" not found\n'


def test_single_dash_help_is_not_a_defined_flag():
    """-help (one dash) is not recognised; only -h and --help are."""
    # CATCHES: prefix-based flag matching that would accept -help as help; the
    # manual parser must report it as undefined and exit 1.
    res = run_goawk(["-help"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "flag provided but not defined: -help\n"


def test_version_flag_prefix_is_parsed_as_a_v_assignment():
    """-versionx is not a version flag: the -v prefix swallows it as a var spec."""
    # CATCHES: exact-match handling of -version must lose to the attached -v
    # form for near-misses, yielding the name=value format error.
    res = run_goawk(["-versionx", "BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "-v flag must be in format name=value\n"


def test_help_banner_and_usage_line_are_separate_documents():
    """The help text is built from three blocks separated by blank lines."""
    # CATCHES: subtle spacing drift -- the banner, the one-line usage and the
    # option list must be joined by exactly one blank line each.
    res = run_goawk(["--help"])
    blocks = res.stdout.split("\n\n")
    assert blocks[0] == COPYRIGHT
    assert blocks[1] == SHORT_USAGE
    assert blocks[2].startswith("Standard AWK arguments:")
    assert res.stdout.endswith("  -memprofile fn    write memory profile to file\n")
