"""POSIX-style attached flag arguments versus separated '-F x' arguments.

goawk parses arguments manually, so '-F:' and '-F :' are equivalent for every
flag that takes a value (and the long debug flags use an '=' instead).
"""

import pytest

from conftest import run_goawk, write_file


@pytest.mark.parametrize("flag_args", [["-F", ","], ["-F,"]], ids=["separated", "attached"])
def test_field_separator_attached_and_separated(tmp_path, flag_args):
    """-F: and '-F :' both set the field separator."""
    # CATCHES: a re-implementation using the flag package (or one that only
    # accepts separated arguments) would fail on the glued '-F,' form.
    res = run_goawk(flag_args + ["{ print $1, $3 }"],
                    stdin="1,2,3\n4,5,6\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "1 3\n4 6\n"
    assert res.stderr == ""


@pytest.mark.parametrize("sep", ["::", "\t", "|"])
def test_field_separator_multi_char_and_tab_values(tmp_path, sep):
    """The attached -F value is taken verbatim, including repeats and tabs."""
    # CATCHES: attached-form parsing that stops at the first ':' or that
    # mangles whitespace would split on the wrong separator.
    res = run_goawk(["-F" + sep, "{ print $2 }"],
                    stdin="a" + sep + "b" + sep + "c\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "b\n"


@pytest.mark.parametrize("flag_args", [["-v", "OFS=."], ["-vOFS=."]], ids=["separated", "attached"])
def test_var_assignment_attached_and_separated(flag_args):
    """-vOFS=. and '-v OFS=.' both assign the variable."""
    # CATCHES: the glued -v form must be split after '-v', not parsed as a
    # boolean flag followed by a stray argument.
    res = run_goawk(flag_args + ["{ print $1, $3 }"], stdin="1 2 3\n")
    assert res.returncode == 0
    assert res.stdout == "1.3\n"


@pytest.mark.parametrize("flag_args", [["-f", "prog.awk"], ["-fprog.awk"]], ids=["separated", "attached"])
def test_progfile_attached_and_separated(tmp_path, flag_args):
    """-fprog.awk loads prog.awk just like '-f prog.awk'."""
    # CATCHES: the attached -f form must be recognised as the program-file
    # flag rather than an unknown flag or a program operand.
    write_file(tmp_path, "prog.awk", 'BEGIN { print "from file" }\n')
    res = run_goawk(flag_args, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "from file\n"
    assert res.stderr == ""


@pytest.mark.parametrize("flag_args", [["-i", "csv"], ["-icsv"]], ids=["separated", "attached"])
def test_input_mode_attached_and_separated(flag_args):
    """-icsv and '-i csv' both select CSV input parsing."""
    # CATCHES: input-mode flag whose value is only accepted with a space; the
    # field indexes would then come from the default whitespace splitting.
    res = run_goawk(flag_args + ["{ print $2 }"], stdin="Bob,42\nJane,37\n")
    assert res.returncode == 0
    assert res.stdout == "42\n37\n"


@pytest.mark.parametrize("flag_args", [["--csv"], ["-csv"]], ids=["double-dash", "single-dash"])
def test_csv_input_long_and_short_flags(flag_args):
    """--csv and -csv are both accepted spellings of '-i csv'."""
    # CATCHES: only one of the two documented CSV spellings being implemented,
    # or --csv being rejected as an unknown long flag.
    res = run_goawk(flag_args + ["{ print $2 }"], stdin="Bob,42\nJane,37\n")
    assert res.returncode == 0
    assert res.stdout == "42\n37\n"


@pytest.mark.parametrize("flag_args", [["-o", "csv"], ["-ocsv"]], ids=["separated", "attached"])
def test_output_mode_attached_and_separated(flag_args):
    """-ocsv and '-o csv' both select CSV output for print with arguments."""
    # CATCHES: output-mode flag glued form; the print output would then be
    # space separated instead of CSV quoted where needed.
    res = run_goawk(flag_args + ['BEGIN { print "foo,bar", 3.14, "baz" }'])
    assert res.returncode == 0
    assert res.stdout == '"foo,bar",3.14,baz\n'


def test_newline_mode_raw_and_crlf_differ(tmp_path):
    """-Nraw keeps LF while -Ncrlf rewrites the newlines, in both spellings."""
    # CATCHES: an implementation that ignores -N altogether passes raw but
    # cannot produce the CRLF bytes the crlf spellings must emit.
    raw = run_goawk(["-Nraw", 'BEGIN { printf "a\\nb\\n" }'], cwd=tmp_path)
    raw_attached = run_goawk(["-Nraw", 'BEGIN { printf "a\\nb\\n" }'], cwd=tmp_path)
    crlf = run_goawk(["-Ncrlf", 'BEGIN { printf "a\\nb\\n" }'], cwd=tmp_path)
    assert raw.returncode == 0
    assert raw.stdout == "a\nb\n"
    assert raw_attached.stdout == "a\nb\n"
    assert crlf.stdout == "a\r\nb\r\n"


@pytest.mark.parametrize("flag_args", [["-N", "crlf"], ["-Ncrlf"]], ids=["separated", "attached"])
def test_newline_mode_crlf_attached_and_separated(flag_args):
    """-Ncrlf translates output newlines to CRLF in both spellings."""
    # CATCHES: the attached -Ncrlf form falling through to the unknown-flag
    # error instead of setting the translation mode.
    res = run_goawk(flag_args + ['BEGIN { printf "a\\n" }'])
    assert res.returncode == 0
    assert res.stdout == "a\r\n"


@pytest.mark.parametrize("flag_args", [["-E", "prog.awk"], ["-Eprog.awk"]], ids=["separated", "attached"])
def test_execprog_attached_and_separated(tmp_path, flag_args):
    """-Eprog.awk loads prog.awk exactly like '-E prog.awk'."""
    # CATCHES: the attached -E form must load the program file; anything else
    # (unknown flag, program operand) produces different output or an error.
    write_file(tmp_path, "prog.awk", 'BEGIN { print "E loaded" }\n')
    res = run_goawk(flag_args, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "E loaded\n"
    assert res.stderr == ""


def test_cpuprofile_attached_equals_form_creates_profile(tmp_path):
    """-cpuprofile=fn (with '=') is the attached spelling of the CPU profile flag."""
    # CATCHES: the long debug flags only accept the '=' glued form; a flag
    # package style parser would not create the profile file at all.
    res = run_goawk(["-cpuprofile=cpu.out", 'BEGIN { print "ran" }'], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "ran\n"
    profile = tmp_path / "cpu.out"
    assert profile.is_file()
    assert profile.stat().st_size > 0


def test_memprofile_attached_equals_form_creates_profile(tmp_path):
    """-memprofile=fn (with '=') writes a heap profile while the program runs."""
    # CATCHES: the '=' form of -memprofile being treated as an unknown flag,
    # which would exit 1 instead of writing the profile file.
    res = run_goawk(["-memprofile=mem.out", 'BEGIN { print "ran" }'], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "ran\n"
    profile = tmp_path / "mem.out"
    assert profile.is_file()
    assert profile.stat().st_size > 0


def test_attached_debug_flag_without_equals_is_rejected():
    """-cpuprofilefn (no '=') is not a defined flag, unlike -cpuprofile=fn."""
    # CATCHES: prefix matching that would accept -cpuprofilefn; only the '='
    # glued form exists for the long debug flags.
    res = run_goawk(["-cpuprofilefn", "BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "flag provided but not defined: -cpuprofilefn\n"


def test_covermode_and_coverprofile_attached_equals_forms(tmp_path):
    """-covermode=count and -coverprofile=fn work in the '=' glued spelling."""
    # CATCHES: the coverage debug flags only supporting separated arguments;
    # the profile would then be missing or written with the default mode.
    res = run_goawk(["-covermode=count", "-coverprofile=cov.out", "{ print $1 }"],
                    stdin="x\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "x\n"
    content = (tmp_path / "cov.out").read_text(encoding="utf-8")
    assert content.splitlines()[0] == "mode: count"


@pytest.mark.parametrize("flag", ["-Version", "-VERSION", "-csvx", "-h2"])
def test_flags_are_case_sensitive(flag):
    """Only the documented exact spellings are flags; case variants are errors."""
    # CATCHES: case-insensitive or prefix-relaxed flag matching, which would
    # accept -Version/-csvx/-h2 instead of rejecting them as undefined.
    res = run_goawk([flag, "BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "flag provided but not defined: %s\n" % flag


def test_attached_f_prefix_is_always_a_progfile():
    """-fx=y is a program file named 'x=y', not a variable assignment."""
    # CATCHES: prefix routing that maps the '-f' glued form onto -v style
    # assignment handling; the file name must be taken verbatim.
    res = run_goawk(["-fx=y", "BEGIN { print 1 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "x=y" not found\n'


def test_chars_flag_switches_to_character_semantics():
    """-c makes %c format a Unicode character instead of a single byte."""
    # CATCHES: -c being accepted but ignored (or the other way round); without
    # it the same program must emit the single byte '4'.
    with_chars = run_goawk(["-c", 'BEGIN { printf "%c", 4660 }'])
    without_chars = run_goawk(['BEGIN { printf "%c", 4660 }'])
    assert with_chars.returncode == 0
    assert with_chars.stdout == "ሴ"
    assert without_chars.stdout == "4"


@pytest.mark.parametrize("flag_args", [
    ["-i", "csv", "-H"],
    ["-icsv", "-H"],
    ["-H", "--csv"],
], ids=["-i separated", "-i attached", "with --csv"])
def test_header_flag_with_input_mode_parses_header_row(flag_args):
    """-H together with -i (or --csv) parses the CSV header row."""
    # CATCHES: -H being rejected in every combination, or the header row being
    # treated as a data record; @"age" only resolves with the header parsed.
    res = run_goawk(flag_args + ['{ print @"age" }'], stdin="name,age\nBob,42\n")
    assert res.returncode == 0
    assert res.stdout == "42\n"
    assert res.stderr == ""


@pytest.mark.parametrize("flag_args", [["-N", "smart"], ["-Nsmart"]], ids=["separated", "attached"])
def test_newline_mode_smart_is_the_explicit_default(flag_args):
    """'-N smart' spells out the default mode and keeps LF output."""
    # CATCHES: smart not being an accepted mode name (falling through to the
    # 'can only be one of' error) or changing the output newlines.
    default = run_goawk(['BEGIN { printf "a\\nb\\n" }'])
    explicit = run_goawk(flag_args + ['BEGIN { printf "a\\nb\\n" }'])
    assert explicit.returncode == 0
    assert explicit.stderr == ""
    assert explicit.stdout == default.stdout
    assert explicit.stdout == "a\nb\n"


def test_covermode_set_explicit_and_separated_coverprofile(tmp_path):
    """'-covermode set' and '-coverprofile fn' (both separated) work as written."""
    # CATCHES: only the '=' glued spellings of the coverage flags being wired
    # up, or 'set' not being an accepted mode name.
    res = run_goawk(["-covermode", "set", "-coverprofile", "cov.out", "{ print $1 }"],
                    stdin="x\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "x\n"
    lines = (tmp_path / "cov.out").read_text(encoding="utf-8").splitlines()
    assert lines[0] == "mode: set"
    assert lines[1] == "%s/<cmdline>:1.3,1.12 1 1" % tmp_path

