"""-E progfile semantics: last option, input-file-only tail, no var= operands."""

from conftest import run_goawk, write_file

ARGV_PROG = "BEGIN { for (i = 1; i < ARGC; i++) print i, ARGV[i] }"


def test_E_makes_following_flags_input_files(tmp_path):
    """After -E nothing is a flag any more, not even '-F:'."""
    # CATCHES: continuing flag parsing past -E; '-F:' must be handed to the
    # interpreter as an input file name instead of setting the separator.
    write_file(tmp_path, "prog.awk", "{ print FILENAME }\n")
    res = run_goawk(["-E", "prog.awk", "-F:"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "-F:" not found\n'


def test_E_makes_double_dash_an_input_file(tmp_path):
    """A '--' after -E is just another operand, not an end-of-flags marker."""
    # CATCHES: honouring '--' after -E, which would drop the marker instead of
    # trying to open it as an input file.
    write_file(tmp_path, "prog.awk", "{ print FILENAME }\n")
    write_file(tmp_path, "in.txt", "hello\n")
    res = run_goawk(["-E", "prog.awk", "--", "in.txt"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "--" not found\n'


def test_E_attached_form_also_ends_flag_parsing(tmp_path):
    """'-Eprog.awk' behaves identically: the rest are input files only."""
    # CATCHES: the glued -E form not stopping the argument scan, so '-F:'
    # would be parsed as a separator instead of a file name.
    write_file(tmp_path, "prog.awk", "{ print FILENAME }\n")
    res = run_goawk(["-Eprog.awk", "-F:"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "-F:" not found\n'


def test_E_attached_prefix_takes_everything_as_filename():
    """'-E2' means progfile '2' -- the -E prefix wins over unknown-flag errors."""
    # CATCHES: '-E2' being rejected as an undefined flag; the manual parser
    # routes any '-E...' argument to the progfile list.
    res = run_goawk(["-E2"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "2" not found\n'


def test_E_disables_name_value_operands(tmp_path):
    """With -E, 'x=42' is an input file, not a variable assignment."""
    # CATCHES: still treating 'name=value' operands as assignments after -E;
    # the interpreter must try to open the file instead.
    write_file(tmp_path, "prog.awk", "{ print }\n")
    res = run_goawk(["-E", "prog.awk", "x=42"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "x=42" not found\n'


def test_f_keeps_name_value_operands_as_assignments(tmp_path):
    """Without -E, a 'x=42' operand assigns the variable when it is reached."""
    # CATCHES: dropping operand assignments entirely; the assignment happens
    # as ARGV is processed, so BEGIN sees the old value and END the new one.
    write_file(tmp_path, "prog.awk", 'BEGIN { print "begin:" x } END { print "end:" x }\n')
    res = run_goawk(["-f", "prog.awk", "x=42"], stdin="", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "begin:\nend:42\n"
    assert res.stderr == ""


def test_f_then_E_loads_both_files_and_disables_argvars(tmp_path):
    """-f before -E contributes its file, and -E still disables assignments."""
    # CATCHES: -E discarding previously collected -f programs, or failing to
    # set the no-arg-vars mode when a -f was also given.
    write_file(tmp_path, "end.awk", 'END { print x }\n')
    res = run_goawk(["-f", "end.awk", "-E", "end.awk", "x=42"], stdin="", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "x=42" not found\n'


def test_E_dash_reads_program_from_stdin():
    """'-E -' loads the program from standard input like '-f -'."""
    # CATCHES: '-' after -E being treated as a file name instead of stdin.
    res = run_goawk(["-E", "-"], stdin='BEGIN { print "E stdin" }\n')
    assert res.returncode == 0
    assert res.stdout == "E stdin\n"
    assert res.stderr == ""


def test_E_shows_remaining_args_in_argv(tmp_path):
    """Arguments after -E become ARGV entries for the program to inspect."""
    # CATCHES: dropping or flag-parsing the tail arguments; they must all be
    # visible in ARGV even though they look like flags.
    write_file(tmp_path, "prog.awk", ARGV_PROG + "\n")
    res = run_goawk(["-E", "prog.awk", "-w", "--", "in.txt"], stdin="", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "1 -w\n2 --\n3 in.txt\n"
    assert res.stderr == ""


def test_E_with_input_files_runs_the_main_loop(tmp_path):
    """A normal run: -E program plus real input file operands."""
    # CATCHES: -E swallowing the input files into the program source; the
    # program must process the file operands as input.
    write_file(tmp_path, "prog.awk", "{ print FILENAME \":\" $0 }\n")
    write_file(tmp_path, "in.txt", "hello\n")
    res = run_goawk(["-E", "prog.awk", "in.txt"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "in.txt:hello\n"
    assert res.stderr == ""
