"""Operands after the program: interpreter Args, ARGV/ARGC, input files and
the process exit status.
"""

import os
import shutil

from conftest import run_goawk, run_goawk_binary, write_file


def test_argv0_is_the_invoked_command_basename():
    """ARGV[0] holds the base name of the invoked binary, not its full path."""
    # CATCHES: stuffing the whole argv[0] path (or a hardcoded "goawk") into
    # ARGV[0].
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE") or "executable"
    res = run_goawk(["BEGIN { print ARGV[0] }"])
    assert res.returncode == 0
    assert res.stdout == "%s\n" % os.path.basename(exe)
    assert res.stderr == ""


def test_argv0_follows_a_renamed_binary(tmp_path):
    """Copying the binary under another name changes ARGV[0]."""
    # CATCHES: ARGV[0] being a constant rather than derived from the actual
    # command line used to start the process.
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE") or "executable"
    renamed = tmp_path / "renamed-awk-probe"
    shutil.copy2(exe, renamed)
    res = run_goawk_binary(renamed, ["BEGIN { print ARGV[0] }"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "renamed-awk-probe\n"
    assert res.stderr == ""


def test_remaining_operands_become_argv_entries():
    """Operands after the program are exposed as ARGV[1..] with ARGC counted."""
    # CATCHES: operands being consumed as flags or dropped from ARGV.
    prog = "BEGIN { print ARGC; for (i = 1; i < ARGC; i++) print i, ARGV[i] }"
    res = run_goawk([prog, "a", "b"], stdin="")
    assert res.returncode == 0
    assert res.stdout == "3\n1 a\n2 b\n"
    assert res.stderr == ""


def test_name_value_operand_after_double_dash_still_assigns():
    """'x=42' operands keep their assignment meaning after '--'."""
    # CATCHES: the end-of-flags marker also disabling operand assignments (as
    # -E does); only -E must turn them into file names.
    res = run_goawk(["--", "END { print x }", "x=42"], stdin="")
    assert res.returncode == 0
    assert res.stdout == "42\n"
    assert res.stderr == ""


def test_first_operand_is_program_even_if_it_looks_like_assignment():
    """With no -f, 'x=42' as the first operand is the program text itself."""
    # CATCHES: sniffing the first operand for 'name=value' and treating it as
    # an assignment; only operands AFTER the program are assignments.
    res = run_goawk(["x=42"], stdin="hi\n")
    assert res.returncode == 0
    assert res.stdout == "hi\n"
    assert res.stderr == ""


def test_flag_order_around_progfile_does_not_matter(tmp_path):
    """-v may be given before or after -f; both assign the variable."""
    # CATCHES: only accepting value flags before -f (or after it).
    write_file(tmp_path, "prog.awk", "BEGIN { print x }\n")
    before = run_goawk(["-v", "x=42", "-f", "prog.awk"], cwd=tmp_path)
    after = run_goawk(["-f", "prog.awk", "-v", "x=42"], cwd=tmp_path)
    assert before.returncode == 0
    assert before.stdout == "42\n"
    assert after.returncode == 0
    assert after.stdout == "42\n"


def test_input_file_operands_are_read_in_order(tmp_path):
    """Operands after the program are input files, read in the given order."""
    # CATCHES: operands not reaching the interpreter as input files, or being
    # reordered; FNR/NR show the per-file and global record counters.
    write_file(tmp_path, "in1.txt", "one\ntwo\n")
    write_file(tmp_path, "in2.txt", "uno\n")
    res = run_goawk(["{ print FNR, NR, $0 }", "in1.txt", "in2.txt"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "1 1 one\n2 2 two\n1 3 uno\n"
    assert res.stderr == ""


def test_exit_status_from_exit_statement_is_preserved():
    """'exit 3' in the program makes the process exit with status 3."""
    # CATCHES: normalising every non-zero exit to 1 (or 0).
    res = run_goawk(["BEGIN { print \"before\"; exit 3 }"])
    assert res.returncode == 3
    assert res.stdout == "before\n"
    assert res.stderr == ""


def test_runtime_error_prints_to_stderr_and_exits_one():
    """A runtime failure reports its message on stderr with exit status 1."""
    # CATCHES: runtime errors going to stdout, or the exit status being 0.
    res = run_goawk(["BEGIN { print 1/0 }"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "division by zero\n"


def test_stdout_and_stderr_are_separate_streams(tmp_path):
    """Program output goes to stdout while the diagnostic goes to stderr."""
    # CATCHES: both streams being merged (or the error aborting earlier
    # output), which a re-implementation using a single stream would show.
    write_file(tmp_path, "missing.txt", "not used\n")
    res = run_goawk(["BEGIN { print \"line one\" } { print }", "nosuch.txt"],
                    stdin="", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == "line one\n"
    assert res.stderr == 'file "nosuch.txt" not found\n'
