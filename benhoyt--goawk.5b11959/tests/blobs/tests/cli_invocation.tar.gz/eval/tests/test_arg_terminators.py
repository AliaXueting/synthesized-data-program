"""What ends flag parsing: '--', a lone '-', or any non-'-' argument."""

from conftest import SHORT_USAGE, run_goawk, write_file


def test_double_dash_ends_flag_parsing(tmp_path):
    """Flags before '--' still apply; everything after it is program/operands."""
    # CATCHES: ignoring the flags that precede the marker, or continuing to
    # parse flags after it; -F, must split fields while the program operand is
    # used verbatim.
    res = run_goawk(["-F", ",", "--", "{ print $1 }"],
                    stdin="a,b\nc,d\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "a\nc\n"
    assert res.stderr == ""


def test_double_dash_makes_help_a_program_operand():
    """After '--', '--help' is the program text, not the help flag."""
    # CATCHES: scanning for help flags past the end-of-flags marker. '--help'
    # parses as the AWK pre-decrement expression --help, a true pattern, so the
    # rule's default action prints each input record.
    res = run_goawk(["--", "--help"], stdin="hello\n")
    assert res.returncode == 0
    assert res.stdout == "hello\n"
    assert res.stderr == ""


def test_lone_dash_ends_flag_parsing_and_is_the_program():
    """A single '-' is not a flag: it becomes the program text '-'."""
    # CATCHES: treating '-' as stdin for the program source (that is -f -), or
    # as an unknown flag; here it is the program operand and fails to parse.
    res = run_goawk(["-"], stdin="ignored\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<cmdline>:1:2: expected expression instead of <newline>\n-\n ^\n"


def test_first_nonflag_operand_ends_flag_parsing(tmp_path):
    """Once the program operand is seen, later '-x' args are input files."""
    # CATCHES: a second flag-scanning pass over the operands, which would
    # apply -F: instead of trying to open it as an input file.
    res = run_goawk(["{ print }", "-F:"], stdin="", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "-F:" not found\n'


def test_flags_after_double_dash_are_input_files(tmp_path):
    """A '-h' after '--' is an input file name, not the help flag."""
    # CATCHES: the '--' marker only ending flag parsing once; args after it
    # must reach the interpreter as file operands.
    res = run_goawk(["--", "{ print }", "-h"], stdin="", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "-h" not found\n'


def test_double_dash_is_not_kept_in_argv(tmp_path):
    """The '--' marker itself is consumed and never appears in ARGV."""
    # CATCHES: passing the marker through to the interpreter, which would add
    # an extra ARGV entry (and try to open it as an input file).
    prog = "BEGIN { for (i = 1; i < ARGC; i++) print i, ARGV[i] }"
    res = run_goawk(["--", prog, "a", "b"], stdin="", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "1 a\n2 b\n"
    assert res.stderr == ""


def test_second_double_dash_is_an_operand(tmp_path):
    """Only the first '--' ends flag parsing; a second one is a file name."""
    # CATCHES: repeatedly stripping '--' markers, which would hide the second
    # marker instead of reporting it as a missing input file.
    res = run_goawk(["--", "{ print }", "--"], stdin="", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'file "--" not found\n'


def test_dash_operand_reads_standard_input():
    """A '-' operand after the program means 'read input from stdin'."""
    # CATCHES: '-' operands being dropped or treated as flags; every record
    # (including the empty one) must be read from stdin and printed.
    res = run_goawk(["{ print $0 }", "-"], stdin="one\n\nthree\n")
    assert res.returncode == 0
    assert res.stdout == "one\n\nthree\n"
    assert res.stderr == ""


def test_flag_like_filename_after_progfile_flag(tmp_path):
    """A '-name' argument directly after -f is the progfile, not a flag."""
    # CATCHES: re-scanning the value of -f for flags; it must be used verbatim
    # as the program file name, even though it starts with a dash.
    write_file(tmp_path, "-dash.awk", 'BEGIN { print "dash file" }\n')
    res = run_goawk(["-f", "-dash.awk"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "dash file\n"
    assert res.stderr == ""


def test_flag_looking_operand_after_double_dash_is_the_program():
    """A '-1' operand after '--' is the program text, not a flag."""
    # CATCHES: resuming flag parsing after the marker; '-1' is a truthy AWK
    # pattern, so the default action prints every input record.
    res = run_goawk(["--", "-1"], stdin="x\ny\n")
    assert res.returncode == 0
    assert res.stdout == "x\ny\n"
    assert res.stderr == ""
