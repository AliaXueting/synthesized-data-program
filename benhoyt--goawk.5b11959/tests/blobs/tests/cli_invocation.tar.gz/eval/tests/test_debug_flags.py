"""Debugging arguments: -d/-da/-dt (stdout dumps, no execution) and the
coverage/profiling flags documented in the -h output.
"""

from conftest import run_goawk

PARSE_TREE = """$1 {
    print 1 + 1
}
"""

ASM = """        // pattern
0000    FieldInt 1

        // { body }
0000    Num 1 (0)
0002    Num 1 (0)
0004    Add
0005    Print 1

"""

TYPE_INFO = """globals
  ARGV: array 0
  ENVIRON: array 1
  FIELDS: array 2
  a: array 3
  x: scalar 0
function f(b, y)  # index 0
  b: array 0
  y: scalar 0
"""


def test_debug_flag_prints_parse_tree_without_running():
    """-d dumps the parsed program to stdout and exits 0 without executing."""
    # CATCHES: -d still running the program (printing extra output) or exiting
    # non-zero; the dumped syntax tree must be the only output.
    res = run_goawk(["-d", "$1 { print 1+1 }"], stdin="ignored\n")
    assert res.returncode == 0
    assert res.stdout == PARSE_TREE
    assert res.stderr == ""


def test_debug_flag_dump_beats_begin_block():
    """A BEGIN block is never executed when -d is given."""
    # CATCHES: -d being handled after (or during) execution, which would emit
    # the program's own print output before the dump.
    res = run_goawk(["-d", 'BEGIN { print "never runs" }'])
    assert res.returncode == 0
    assert res.stdout == 'BEGIN {\n    print "never runs"\n}\n'
    assert res.stderr == ""


def test_debug_asm_flag_prints_bytecode():
    """-da prints the VM assembly instructions and exits 0."""
    # CATCHES: -da being treated as '-d' plus a stray 'a' argument, or the
    # instruction dump going to stderr.
    res = run_goawk(["-da", "$1 { print 1+1 }"], stdin="ignored\n")
    assert res.returncode == 0
    assert res.stdout == ASM
    assert res.stderr == ""


def test_debug_types_flag_prints_variable_types():
    """-dt prints resolved variable type information for globals and params."""
    # CATCHES: -dt not resolving parameter types (array vs scalar) or printing
    # to a different stream.
    prog = "BEGIN { x=42; print f(a,1) }\nfunction f(b, y) { return b[y] }\n"
    res = run_goawk(["-dt", prog])
    assert res.returncode == 0
    assert res.stdout == TYPE_INFO
    assert res.stderr == ""


def test_debug_and_asm_flags_combine():
    """-d and -da together print the tree followed by the assembly."""
    # CATCHES: only the last debug flag being honoured; both dumps must appear
    # in a fixed order.
    res = run_goawk(["-d", "-da", "$1 { print 1+1 }"], stdin="ignored\n")
    assert res.returncode == 0
    assert res.stdout == PARSE_TREE + ASM
    assert res.stderr == ""


def test_debug_flag_works_with_progfile(tmp_path):
    """-d also dumps a program loaded with -f (and does not run it)."""
    # CATCHES: -d only being wired up for program operands, which would leave
    # the dump empty or run the file's BEGIN block.
    (tmp_path / "prog.awk").write_text('BEGIN { print "never runs" }\n', encoding="utf-8")
    res = run_goawk(["-f", "prog.awk", "-d"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == 'BEGIN {\n    print "never runs"\n}\n'
    assert res.stderr == ""


def test_coverprofile_default_mode_is_set(tmp_path):
    """-coverprofile alone writes a Go coverage profile with 'mode: set'."""
    # CATCHES: an empty or differently-headed profile file; the first line
    # must be the Go cover header and the block line must name the source and
    # record that the block ran once.
    res = run_goawk(["-coverprofile=cov.out", "{ print $1 }"], stdin="x\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "x\n"
    lines = (tmp_path / "cov.out").read_text(encoding="utf-8").splitlines()
    assert lines[0] == "mode: set"
    assert lines[1] == "%s/<cmdline>:1.3,1.12 1 1" % tmp_path


def test_covermode_count_is_recorded_in_profile(tmp_path):
    """-covermode count makes the profile header say 'mode: count'."""
    # CATCHES: the mode flag being ignored when a profile is requested.
    res = run_goawk(["-covermode", "count", "-coverprofile=cov.out", "{ print $1 }"],
                    stdin="x\n", cwd=tmp_path)
    assert res.stdout == "x\n"
    assert res.returncode == 0
    lines = (tmp_path / "cov.out").read_text(encoding="utf-8").splitlines()
    assert lines[0] == "mode: count"
    assert len(lines) == 2
    assert lines[1] == "%s/<cmdline>:1.3,1.12 1 1" % tmp_path


def test_coverprofile_names_progfile_sources(tmp_path):
    """A program loaded with -f is named with its path in the coverage profile."""
    # CATCHES: cover blocks of -f programs being attributed to '<cmdline>'.
    (tmp_path / "prog.awk").write_text("{ print $1 }\n", encoding="utf-8")
    res = run_goawk(["-coverprofile=cov.out", "-f", "prog.awk"], stdin="x\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "x\n"
    lines = (tmp_path / "cov.out").read_text(encoding="utf-8").splitlines()
    assert lines[1] == "%s/prog.awk:1.3,1.12 1 1" % tmp_path


def test_coverappend_appends_blocks_to_existing_profile(tmp_path):
    """-coverappend adds a second block line instead of truncating the file."""
    # CATCHES: -coverappend being ignored (the file overwritten with one
    # block) or appending a duplicate header.
    args = ["-coverprofile=cov.out", "-coverappend", "{ print $1 }"]
    first = run_goawk(args, stdin="x\n", cwd=tmp_path)
    second = run_goawk(args, stdin="x\n", cwd=tmp_path)
    assert first.stdout == "x\n"
    assert second.stdout == "x\n"
    assert first.returncode == 0
    assert second.returncode == 0
    assert (tmp_path / "cov.out").read_text(encoding="utf-8") == (
        "mode: set\n"
        "%s/<cmdline>:1.3,1.12 1 1\n"
        "%s/<cmdline>:1.3,1.12 1 1\n" % (tmp_path, tmp_path))


def test_coverprofile_not_written_when_parse_fails(tmp_path):
    """A parse error means no coverage profile is produced at all."""
    # CATCHES: writing a (partial) profile before the program was parsed; the
    # diagnostic must be the parse error and the file must stay absent.
    res = run_goawk(["-coverprofile=cov.out", "`"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "<cmdline>:1:1: unexpected char\n`\n^\n"
    assert not (tmp_path / "cov.out").exists()


def test_coverappend_alone_runs_the_program(tmp_path):
    """-coverappend without -coverprofile is accepted and changes nothing."""
    # CATCHES: -coverappend requiring a profile and erroring out.
    res = run_goawk(["-coverappend", 'BEGIN { print "ran" }'], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "ran\n"
    assert res.stderr == ""


def test_cpuprofile_separated_form_creates_profile(tmp_path):
    """'-cpuprofile fn' (separated) writes a non-empty CPU profile."""
    # CATCHES: only the '=' glued spelling being supported for the debug
    # flags.
    res = run_goawk(["-cpuprofile", "cpu.out", 'BEGIN { print "ran" }'], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "ran\n"
    profile = tmp_path / "cpu.out"
    assert profile.is_file()
    assert profile.stat().st_size > 0


def test_memprofile_separated_form_creates_profile(tmp_path):
    """'-memprofile fn' (separated) writes a non-empty heap profile."""
    # CATCHES: the separated form of -memprofile being rejected.
    res = run_goawk(["-memprofile", "mem.out", 'BEGIN { print "ran" }'], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "ran\n"
    profile = tmp_path / "mem.out"
    assert profile.is_file()
    assert profile.stat().st_size > 0
