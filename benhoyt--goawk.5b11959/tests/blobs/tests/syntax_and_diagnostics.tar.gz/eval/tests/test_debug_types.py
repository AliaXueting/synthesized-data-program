"""The -dt flag: variable type information printed to stdout, exit 0.

The dump is produced by internal/resolver/resolve.go printVarTypes: a
'globals' section (always listing ARGV, ENVIRON and FIELDS) followed by one
section per function, names sorted, each variable tagged scalar or array
with its parameter-ordered index. Nothing is executed.
"""


def test_globals_only_program_lists_the_three_builtin_arrays(run):
    """A program with no user variables dumps just the builtin globals."""
    result = run(["-dt", "BEGIN { }"])
    # CATCHES: ARGV, ENVIRON and FIELDS are always present as arrays with
    # indexes 0-2, in that fixed order, even for an empty program.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n")


def test_globals_and_functions_with_scalar_and_array_params(run):
    """Globals and function locals are dumped with their types and indexes."""
    source = "\nBEGIN { x=42; a[1]=x; print f(a, 1) }\n" \
             "function f(b, y, z) { return b[y+z] }\n" \
             "function hi(x) { print \"hi \" x }\n"
    result = run(["-dt", source])
    # CATCHES: scalars and arrays get separate zero-based index sequences
    # (a is array 3 after the three builtins; b is array 0 inside f), and
    # functions are listed with their '# index N' call index.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "  a: array 3\n"
        "  x: scalar 0\n"
        "function f(b, y, z)  # index 0\n"
        "  b: array 0\n"
        "  y: scalar 0\n"
        "  z: scalar 1\n"
        "function hi(x)  # index 1\n"
        "  x: scalar 0\n")


def test_function_with_no_variables_prints_header_only(run):
    """A function with no params or locals still gets a section header."""
    result = run(["-dt", 'function f() { print "hi" } BEGIN { f() }'])
    # CATCHES: the function appears with an empty parameter list and no
    # variable lines under it.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "function f()  # index 0\n")


def test_main_variables_share_one_scalar_index_sequence(run):
    """BEGIN, action and END sections share the globals' scalar indexes."""
    result = run(["-dt", "BEGIN { q = 1 } { r = $1 } END { s = 2 }"])
    # CATCHES: variables from all three sections are globals sorted by
    # name, numbered 0,1,2 in first-use order across the whole program.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "  q: scalar 0\n"
        "  r: scalar 1\n"
        "  s: scalar 2\n")


def test_special_variables_are_not_listed(run):
    """References to NR, NF, FS etc. never appear in the type dump."""
    result = run(["-dt", "{ print NR, NF, FILENAME, SUBSEP, RSTART, RLENGTH, FS }"])
    # CATCHES: special variables live in a separate scope and are absent
    # from the globals section, unlike user variables.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n")


def test_local_parameter_shadows_global_of_same_name(run):
    """A function parameter hides a same-named global in its section."""
    result = run(["-dt", "function f(x) { return x } BEGIN { x = 5; print f(x) }"])
    # CATCHES: the global x and the local x are reported separately, each
    # with its own scope's index numbering.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "  x: scalar 0\n"
        "function f(x)  # index 0\n"
        "  x: scalar 0\n")


def test_dt_exits_zero_without_executing(run):
    """-dt never runs the program, even one that would fail at runtime."""
    result = run(["-dt", "BEGIN { print 1/0 }"])
    # CATCHES: the division by zero is never evaluated because -dt exits
    # right after resolving, so stderr is empty and the status is 0.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n")


def test_dt_with_covermode_dumps_twice(run):
    """Coverage re-resolution makes -dt print the type table twice."""
    result = run(["-dt", "-covermode", "count", "BEGIN {\n  for (i=0; i<7; i++) print i\n}\n"])
    # CATCHES: the program is resolved once, annotated with __COVER, then
    # re-resolved, so the dump appears twice and the second one lists the
    # __COVER array the annotation introduced.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "  i: scalar 0\n"
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "  __COVER: array 3\n"
        "  i: scalar 0\n")


def test_dt_order_is_before_the_ast_dump(run):
    """With -dt and -d together, types print first, then the AST."""
    result = run(["-d", "-dt", "BEGIN { x = 1; print x }"])
    # CATCHES: type info is written during parsing/resolution which happens
    # before the -d dump, so the 'globals' section precedes 'BEGIN {'.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "  x: scalar 0\n"
        "BEGIN {\n"
        "    x = 1\n"
        "    print x\n"
        "}\n")
