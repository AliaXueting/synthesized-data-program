"""The -coverprofile/-covermode/-coverappend flags: Go-cover-format output.

After the program runs normally, GoAWK writes a profile in the Go cover
format: a ``mode: X`` header line followed by one line per tracked block,
``FILE:STARTLINE.STARTCOL,ENDLINE.ENDCOL NUMSTMTS COUNT``. FILE is the
absolute path of the -f file (or ``<cwd>/<cmdline>`` for a command-line
program). Every expectation below was recorded from the reference binary;
``<TMP>`` stands for the test sandbox directory the profile names.
"""

import pytest

# The program from docs/cover.md's example, used for most profile-shape
# tests: one always-run statement, an if with both branches.
DOC_PROG = (
    'BEGIN {\n'
    '    print "will always run"\n'
    '    if ((1 + 1) == 2) {\n'
    '        print "should run"\n'
    '    } else {\n'
    '        print "wont run"\n'
    '    }\n'
    '}\n'
)

# The three blocks of DOC_PROG in the order the profiler tracks them:
# the if body, the else body, then the outer two-statement block.
DOC_PROG_BLOCKS = (
    "<TMP>/prog.awk:4.9,4.27 1 1\n"
    "<TMP>/prog.awk:6.9,6.25 1 0\n"
    "<TMP>/prog.awk:2.5,3.23 2 1\n"
)


def test_coverprofile_runs_program_and_writes_set_profile(
        run, write, tmp_path, normalize_paths):
    """-coverprofile runs the program, then writes a 'mode: set' profile."""
    write("prog.awk", DOC_PROG)
    result = run(["-f", "prog.awk", "-coverprofile", "cover.out"])
    # CATCHES: the program executes normally first (both prints on stdout,
    # exit 0) and the default mode with only -coverprofile is "set"; the
    # never-taken else block is recorded with count 0.
    assert (result.returncode, result.out, result.err) == (
        0, "will always run\nshould run\n", "")
    profile = normalize_paths((tmp_path / "cover.out").read_text())
    assert profile == "mode: set\n" + DOC_PROG_BLOCKS


def test_covermode_set_vs_count(run, write, tmp_path, normalize_paths):
    """'count' records how many times a block ran; 'set' just 0 or 1."""
    write("loop.awk",
          'BEGIN {\n'
          '  for (i = 0; i < 3; i++) {\n'
          '    print "loop"\n'
          '  }\n'
          '}\n')
    result = run(["-f", "loop.awk", "-covermode", "count",
                  "-coverprofile", "count.out"])
    # CATCHES: with -covermode count the loop body that ran three times
    # gets count 3, and the header line says "mode: count".
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "count.out").read_text())
    assert profile == (
        "mode: count\n"
        "<TMP>/loop.awk:3.5,3.17 1 3\n"
        "<TMP>/loop.awk:2.3,2.27 1 1\n")

    result = run(["-f", "loop.awk", "-coverprofile", "set.out"])
    # CATCHES: the identical program under the default set mode caps the
    # thrice-executed block at 1, which is what 'set' semantics mean.
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "set.out").read_text())
    assert profile == (
        "mode: set\n"
        "<TMP>/loop.awk:3.5,3.17 1 1\n"
        "<TMP>/loop.awk:2.3,2.27 1 1\n")


def test_coverappend_accumulates_blocks_across_runs(
        run, write, tmp_path, normalize_paths):
    """-coverappend appends a fresh set of block lines on every run."""
    write("prog.awk", DOC_PROG)
    for _ in range(2):
        result = run(["-f", "prog.awk", "-covermode", "count",
                      "-coverappend", "-coverprofile", "acc.out"])
        assert (result.returncode, result.err) == (0, "")
    # CATCHES: appending does not merge counts: the same three block lines
    # appear twice, once per run, and only one 'mode:' header is written.
    profile = normalize_paths((tmp_path / "acc.out").read_text())
    assert profile == "mode: count\n" + DOC_PROG_BLOCKS + DOC_PROG_BLOCKS


def test_profile_is_truncated_without_coverappend(
        run, write, tmp_path, normalize_paths):
    """Without -coverappend a second run overwrites the earlier profile."""
    write("prog.awk", DOC_PROG)
    for _ in range(2):
        result = run(["-f", "prog.awk", "-coverprofile", "trunc.out"])
        assert (result.returncode, result.err) == (0, "")
    # CATCHES: the second run truncates the file, so only one 'mode:' line
    # and one set of blocks remain even after two runs.
    profile = normalize_paths((tmp_path / "trunc.out").read_text())
    assert profile == "mode: set\n" + DOC_PROG_BLOCKS


def test_coverappend_creates_missing_file_with_mode_line(
        run, write, tmp_path, normalize_paths):
    """-coverappend to a nonexistent path creates it like a fresh profile."""
    write("prog.awk", DOC_PROG)
    result = run(["-f", "prog.awk", "-covermode", "count",
                  "-coverappend", "-coverprofile", "new.out"])
    # CATCHES: appending to a file that does not exist yet still writes the
    # 'mode: count' header, exactly like writing a brand-new profile.
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "new.out").read_text())
    assert profile == "mode: count\n" + DOC_PROG_BLOCKS


def test_coverappend_preserves_existing_content(
        run, write, tmp_path, normalize_paths):
    """-coverappend keeps earlier profile lines and the one mode header."""
    write("prog.awk", DOC_PROG)
    (tmp_path / "pre.out").write_text(
        "mode: set\n/some/old/path.awk:1.1,1.2 1 5\n")
    result = run(["-f", "prog.awk", "-coverprofile", "pre.out",
                  "-coverappend"])
    # CATCHES: the pre-existing block line from another run is kept, the
    # new blocks are appended after it, and no second 'mode:' line is added.
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "pre.out").read_text())
    assert profile == (
        "mode: set\n"
        "/some/old/path.awk:1.1,1.2 1 5\n"
        + DOC_PROG_BLOCKS)


def test_coverappend_to_empty_existing_file_omits_mode_line(
        run, write, tmp_path, normalize_paths):
    """-coverappend to a zero-byte file writes blocks but no mode header."""
    write("prog.awk", DOC_PROG)
    (tmp_path / "empty.out").write_text("")
    result = run(["-f", "prog.awk", "-coverprofile", "empty.out",
                  "-coverappend"])
    # CATCHES: the header is only written for files the profiler created
    # itself, so appending to a pre-existing empty file yields blocks with
    # no 'mode:' line at all.
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "empty.out").read_text())
    assert profile == DOC_PROG_BLOCKS


@pytest.mark.parametrize("mode_arg", ["bogus", "SET", ""])
def test_invalid_covermode_is_rejected(run, mode_arg):
    """A -covermode other than set/count errors before running anything."""
    result = run(["-covermode", mode_arg, "BEGIN { print 1 }"])
    # CATCHES: only exact lowercase 'set' or 'count' are accepted; anything
    # else (unknown word, uppercase, empty) fails with this exact message
    # on stderr and status 1 before the program even runs.
    assert (result.returncode, result.out, result.err) == (
        1, "", "-covermode can only be one of: set, count\n")


@pytest.mark.parametrize("flag", ["-covermode", "-coverprofile"])
def test_coverage_flags_require_an_argument(run, flag):
    """A trailing -covermode/-coverprofile with no value is a usage error."""
    result = run([flag])
    # CATCHES: the flag parser reports the missing argument by flag name and
    # exits 1 without reading a program from anywhere.
    assert (result.returncode, result.out, result.err) == (
        1, "", "flag needs an argument: %s\n" % flag)


@pytest.mark.parametrize("bad_path,expected_stderr", [
    pytest.param("no/such/dir/c.out",
                 "unable to write coverage profile: open no/such/dir/c.out:"
                 " no such file or directory\n",
                 id="missing-dir"),
    pytest.param("adir",
                 "unable to write coverage profile: open adir: is a directory\n",
                 id="is-a-directory"),
])
def test_unwritable_coverprofile_errors_after_running(run, write,
                                                      bad_path, expected_stderr):
    """A profile path that cannot be opened errors after the program ran."""
    write("adir/keep", "")  # make sure the directory exists
    result = run(["-coverprofile", bad_path, 'BEGIN { print "ran" }'])
    # CATCHES: the program's stdout appears first because the profile is
    # only written after execution; then the open failure aborts with
    # status 1 and the 'unable to write coverage profile' message.
    assert (result.returncode, result.out, result.err) == (
        1, "ran\n", expected_stderr)


def test_coverprofile_blocks_are_per_input_file(
        run, write, tmp_path, normalize_paths):
    """Each -f file's blocks carry that file's own path and line numbers."""
    write("f1.awk", 'BEGIN {\n  print "one"\n}\n')
    write("f2.awk", '/x/ { print "two" }\n\nfunction helper() {\n  return 42\n}\n')
    write("f3.awk", 'END {\n  print "end"\n  print helper()\n}\n')
    result = run(["-f", "f1.awk", "-f", "f2.awk", "-f", "f3.awk",
                  "-coverprofile", "multi.out"], stdin="x\n")
    # CATCHES: every block names the absolute path of the -f file it came
    # from with that file's LOCAL line numbers, and blocks are emitted in
    # program order: BEGIN blocks, actions, END blocks, then functions.
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "multi.out").read_text())
    assert profile == (
        "mode: set\n"
        "<TMP>/f1.awk:2.3,2.14 1 1\n"
        "<TMP>/f2.awk:1.7,1.19 1 1\n"
        "<TMP>/f3.awk:2.3,3.17 2 1\n"
        "<TMP>/f2.awk:4.3,4.12 1 1\n")


def test_coverprofile_labels_cmdline_program_with_cwd(
        run, tmp_path, normalize_paths):
    """A command-line program is profiled under <cwd>/<cmdline>."""
    result = run(["-coverprofile", "cmd.out", "BEGIN { print 1 }"])
    # CATCHES: the block path for a command-line program is the literal
    # '<cmdline>' made absolute against the working directory, not the
    # program text or a temp name.
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "cmd.out").read_text())
    assert profile == (
        "mode: set\n"
        "<TMP>/<cmdline>:1.9,1.17 1 1\n")


def test_coverprofile_written_when_program_exits_nonzero(
        run, tmp_path, normalize_paths):
    """An explicit exit status still gets its profile written."""
    result = run(["-coverprofile", "ex.out",
                  'BEGIN { print "before"; exit 3 }'])
    # CATCHES: exit 3 is a normal end of program, not an error: the profile
    # is written (with both statements in one 2-statement block) and the
    # process keeps the program's exit status 3.
    assert (result.returncode, result.out, result.err) == (3, "before\n", "")
    profile = normalize_paths((tmp_path / "ex.out").read_text())
    assert profile == (
        "mode: set\n"
        "<TMP>/<cmdline>:1.9,1.32 2 1\n")


def test_coverprofile_not_written_on_runtime_error(run, tmp_path):
    """A runtime failure skips the profile write entirely."""
    result = run(["-coverprofile", "rt.out", 'BEGIN { print "a"; print 1/0 }'])
    # CATCHES: the interpreter error aborts before the profile is written,
    # so no file appears and the status is 1 with the error on stderr.
    assert (result.returncode, result.out, result.err) == (
        1, "a\n", "division by zero\n")
    assert not (tmp_path / "rt.out").exists()


def test_debug_flag_skips_profile_write(run, tmp_path):
    """-d exits before execution, so -coverprofile never writes a file."""
    result = run(["-d", "-coverprofile", "d.out", "BEGIN { print 1 }"])
    # CATCHES: the AST is still annotated for coverage (the dump shows the
    # injected '__COVER[1] = 1' statement), but -d exits 0 before the
    # program runs, and the profile is only written after execution, so
    # no file is created even though -coverprofile was given.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    __COVER[1] = 1\n    print 1\n}\n"
    assert not (tmp_path / "d.out").exists()


def test_covermode_annotates_ast_dump(run):
    """-covermode rewrites the AST with __COVER counter assignments."""
    result = run(["-covermode", "set", "-d", "-f", "-"],
                 stdin="BEGIN {\n"
                       "    print \"will always run\"\n"
                       "    if ((1 + 1) == 2) {\n"
                       "        print \"should run\"\n"
                       "    } else {\n"
                       "        print \"wont run\"\n"
                       "    }\n"
                       "}\n")
    # CATCHES: the -d dump of the annotated program shows __COVER[N] = 1
    # inserted before the statements of each block, numbered in the order
    # the blocks were tracked (if body 1, else body 2, outer block 3).
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n"
        "    __COVER[3] = 1\n"
        "    print \"will always run\"\n"
        "    if ((1 + 1) == 2) {\n"
        "        __COVER[1] = 1\n"
        "        print \"should run\"\n"
        "    } else {\n"
        "        __COVER[2] = 1\n"
        "        print \"wont run\"\n"
        "    }\n"
        "}\n")


def test_coverprofile_equals_form(run, tmp_path, normalize_paths):
    """-coverprofile=FILE works like the two-argument form."""
    result = run(["-coverprofile=eq.out", "BEGIN { print 1 }"])
    # CATCHES: the =-attached spelling of the flag is accepted and produces
    # exactly the same 'mode: set' profile as the separate-argument form.
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "eq.out").read_text())
    assert profile == (
        "mode: set\n"
        "<TMP>/<cmdline>:1.9,1.17 1 1\n")


def test_empty_coverprofile_value_disables_writing(run, tmp_path):
    """An empty -coverprofile= value runs the program but writes nothing."""
    result = run(["-coverprofile=", 'BEGIN { print "x" }'])
    # CATCHES: an empty path is treated as "no profile", so the program
    # still runs and exits 0 but no file is created and no error is shown.
    assert (result.returncode, result.out, result.err) == (0, "x\n", "")
    assert list(tmp_path.iterdir()) == []


def test_coverage_block_spans_for_while_and_dowhile(
        run, write, tmp_path, normalize_paths):
    """Loop blocks are tracked as body plus the statements before them."""
    write("dw.awk",
          'BEGIN {\n'
          '  i = 0\n'
          '  while (i < 2) {\n'
          '    i++\n'
          '  }\n'
          '  do {\n'
          '    i--\n'
          '  } while (i > 0)\n'
          '}\n')
    result = run(["-f", "dw.awk", "-coverprofile", "dw.out"])
    # CATCHES: a while loop yields a block for its body plus a block for
    # the preceding statements ending at the loop's '{' column, while a
    # do-while spans from 'do' to the end of its trailing condition.
    assert (result.returncode, result.err) == (0, "")
    profile = normalize_paths((tmp_path / "dw.out").read_text())
    assert profile == (
        "mode: set\n"
        "<TMP>/dw.awk:4.5,4.8 1 1\n"
        "<TMP>/dw.awk:2.3,3.17 2 1\n"
        "<TMP>/dw.awk:7.5,7.8 1 1\n"
        "<TMP>/dw.awk:6.3,8.18 1 1\n")


def test_coverprofile_annotates_forin_body(run, write, tmp_path,
                                           normalize_paths):
    """A for-in loop's body is a separate block, 0 when never executed."""
    write("forin.awk",
          'BEGIN {\n'
          '  for (k in a) {\n'
          '    print k\n'
          '  }\n'
          '}\n')
    result = run(["-f", "forin.awk", "-coverprofile", "forin.out"])
    # CATCHES: the loop body (line 3) gets its own block that stays at
    # count 0 because the array is empty, while the for-in statement
    # itself (line 2, ending at the body's opening brace) counts 1; the
    # body block is listed before the loop's own block.
    assert (result.returncode, result.out, result.err) == (0, "", "")
    profile = normalize_paths((tmp_path / "forin.out").read_text())
    assert profile == (
        "mode: set\n"
        "<TMP>/forin.awk:3.5,3.12 1 0\n"
        "<TMP>/forin.awk:2.3,2.16 1 1\n")
