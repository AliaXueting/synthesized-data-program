"""Shared black-box harness for the GoAWK syntax_and_diagnostics suite.

Every test drives the program under test exclusively through its command
line interface, resolving the binary from ``PROGRAMGYM_EXECUTABLE``. All
expectations embedded in the tests were recorded by running the reference
binary.
"""

import os
import subprocess
from pathlib import Path

import pytest


def program_path():
    """Resolve the program under test from $PROGRAMGYM_EXECUTABLE."""
    raw = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not raw:
        pytest.fail("PROGRAMGYM_EXECUTABLE must point at the program under test")
    return str(Path(raw))


class RunResult:
    """Outcome of one black-box invocation of the program."""

    def __init__(self, returncode, stdout, stderr):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

    @property
    def out(self):
        """stdout decoded as text."""
        return self.stdout.decode("utf-8", "surrogateescape")

    @property
    def err(self):
        """stderr decoded as text."""
        return self.stderr.decode("utf-8", "surrogateescape")

    def __repr__(self):
        return "RunResult(rc=%d, stdout=%r, stderr=%r)" % (
            self.returncode, self.stdout, self.stderr)


def pinned_env(home, extra=None):
    """A minimal, deterministic child environment."""
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": str(home),
        "TMPDIR": str(home),
        # Pin the locale so no environment-dependent formatting sneaks in.
        "LC_ALL": "C.UTF-8",
    }
    if extra:
        env.update(extra)
    # Coverage instrumentation hook: let the pipeline's GOCOVERDIR reach the
    # child so source coverage of the reference binary can be measured. The
    # value is made absolute because the child runs with cwd inside tmp_path;
    # a relative GOCOVERDIR would otherwise scatter the coverage files into
    # the throwaway sandbox instead of the pipeline's collection directory.
    cov_env = {"GOCOVERDIR": os.path.abspath(v)
               for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    return env


@pytest.fixture
def run(tmp_path):
    """Run the program under test with cwd pinned inside ``tmp_path``.

    The ``cwd`` argument is always interpreted relative to ``tmp_path`` so
    that no path outside it is ever touched.
    """

    def _run(args=(), stdin=b"", cwd=None, extra_env=None, timeout=20):
        if isinstance(stdin, str):
            stdin = stdin.encode("utf-8")
        workdir = tmp_path if cwd is None else tmp_path / cwd
        proc = subprocess.run(
            [program_path(), *[str(a) for a in args]],
            input=stdin,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(workdir),
            env=pinned_env(tmp_path, extra_env),
            timeout=timeout,
        )
        return RunResult(proc.returncode, proc.stdout, proc.stderr)

    return _run


@pytest.fixture
def write(tmp_path):
    """Create files inside ``tmp_path``; parents are created as needed."""

    def _write(relpath, content):
        path = tmp_path / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, str):
            content = content.encode("utf-8")
        path.write_bytes(content)
        return path

    return _write


@pytest.fixture
def normalize_paths(tmp_path):
    """Replace the sandbox's absolute path prefixes with a placeholder.

    GoAWK's coverage profile stores absolute source paths (see
    internal/cover/cover.go toAbsolutePath), so a recorded expectation can
    only name them via a placeholder.
    """

    def _normalize(text):
        for prefix in {str(tmp_path), str(tmp_path.resolve())}:
            text = text.replace(prefix, "<TMP>")
        return text

    return _normalize
