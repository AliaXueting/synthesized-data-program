"""The -da flag: numbered VM assembly instructions printed to stdout.

The dump comes from internal/compiler/disassembler.go: each section is
introduced by an eight-space '// name' comment and instructions are
'ADDR    Opcode operands' with a four-hex-digit address. -da exits 0
without executing the program.
"""


def test_begin_only_program_disassembly(run):
    """A single BEGIN block disassembles under a '// BEGIN' comment."""
    result = run(["-da", "BEGIN { print 1+1 }"])
    # CATCHES: constants are pooled ('Num 1 (0)' twice reuses index 0),
    # addresses are instruction counts in hex, and a trailing blank line
    # ends the section.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Num 1 (0)\n"
        "0002    Num 1 (0)\n"
        "0004    Add\n"
        "0005    Print 1\n"
        "\n")


def test_pattern_and_body_disassemble_separately(run):
    """A pattern action disassembles as 'pattern' then '{ body }'."""
    result = run(["-da", "$1 { print 1+1 }"])
    # CATCHES: the pattern and the body are separate code blocks that each
    # restart their address numbering at 0000.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // pattern\n"
        "0000    FieldInt 1\n"
        "\n"
        "        // { body }\n"
        "0000    Num 1 (0)\n"
        "0002    Num 1 (0)\n"
        "0004    Add\n"
        "0005    Print 1\n"
        "\n")


def test_range_pattern_disassembles_as_start_and_stop(run):
    """A range pattern gets '// start' and '// stop' blocks."""
    result = run(["-da", "1, 5 { print $1 }"])
    # CATCHES: the two pattern expressions are labelled start and stop and
    # the numeric constants get distinct pool indexes (0) and (1).
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // start\n"
        "0000    Num 1 (0)\n"
        "\n"
        "        // stop\n"
        "0000    Num 5 (1)\n"
        "\n"
        "        // { body }\n"
        "0000    FieldInt 1\n"
        "0002    Print 1\n"
        "\n")


def test_pattern_only_action_has_no_body_block(run):
    """A pattern with no action prints only its pattern block."""
    result = run(["-da", "/foo/"])
    # CATCHES: with no body there is no '// { body }' section, and regex
    # constants are wrapped as \"(?s:...)\" when disassembled.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // pattern\n"
        '0000    Regex "(?s:foo)" (0)\n'
        "\n")


def test_empty_action_compiles_to_nop(run):
    """An action with no statements compiles to a single Nop."""
    result = run(["-da", "{ }"])
    # CATCHES: the empty body still emits a code block containing exactly
    # one Nop instruction at address 0000.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // { body }\n"
        "0000    Nop\n"
        "\n")


def test_globals_and_strings_in_disassembly(run):
    """Assignments and prints show Global/Str opcodes with names."""
    result = run(["-da", 'BEGIN { x = "s"; y = 1.5; print x, y; print x > "f"; if (x) print "t"; else print "f" }'])
    # CATCHES: string constants are %q-quoted with their pool index, float
    # constants print as 1.5, and jump targets are absolute hex addresses
    # (JumpFalse 0x0021 / Jump 0x0026 for the if/else).
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        '0000    Str "s" (0)\n'
        "0002    AssignGlobal x\n"
        "0004    Num 1.5 (0)\n"
        "0006    AssignGlobal y\n"
        "0008    Global x\n"
        "000a    Global y\n"
        "000c    Print 2\n"
        '000f    Str "f" (1)\n'
        "0011    Global x\n"
        "0013    Print 1 >\n"
        "0016    Global x\n"
        "0018    JumpFalse 0x0021\n"
        '001a    Str "t" (2)\n'
        "001c    Print 1\n"
        "001f    Jump 0x0026\n"
        '0021    Str "f" (1)\n'
        "0023    Print 1\n"
        "\n")


def test_arrays_loops_and_delete_in_disassembly(run):
    """Array ops show ForIn/Delete/CallLengthArray with the array name."""
    result = run(["-da", 'BEGIN { a[1] = "x"; for (k in a) print k; delete a[1]; print length(a) }'])
    # CATCHES: array element stores use Str for the index, ForIn names both
    # the loop variable and array with its jump target, and length() of an
    # array compiles to CallLengthArray rather than a generic call.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        '0000    Str "x" (0)\n'
        '0002    Str "1" (1)\n'
        "0004    AssignArrayGlobal a\n"
        "0006    ForIn k a 0x0011\n"
        "000c    Global k\n"
        "000e    Print 1\n"
        '0011    Str "1" (1)\n'
        "0013    Delete a\n"
        "0016    CallLengthArray a\n"
        "0019    Print 1\n"
        "\n")


def test_getline_forms_in_disassembly(run):
    """Pipe and file getlines compile to GetlineGlobal with the redirect."""
    result = run(["-da", 'BEGIN { "cat" | getline line; getline x < "file"; print line }'])
    # CATCHES: the redirect token ('|' or '<') is printed before the
    # target variable name, and each getline result is dropped with Drop.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        '0000    Str "cat" (0)\n'
        "0002    GetlineGlobal | line\n"
        "0005    Drop\n"
        '0006    Str "file" (1)\n'
        "0008    GetlineGlobal < x\n"
        "000b    Drop\n"
        "000c    Global line\n"
        "000e    Print 1\n"
        "\n")


def test_user_function_and_local_variables_in_disassembly(run):
    """Functions get a '// function NAME' block with Local opcodes."""
    result = run(["-da", "function f(x) { return x*2 } END { print f(21) }"])
    # CATCHES: the function block is emitted after END, locals are named
    # from the parameter list, and the call site shows 'CallUser f []'
    # with the (empty) array-argument list.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // END\n"
        "0000    Num 21 (1)\n"
        "0002    CallUser f []\n"
        "0005    Print 1\n"
        "\n"
        "        // function f\n"
        "0000    Local x\n"
        "0002    Num 2 (0)\n"
        "0004    Multiply\n"
        "0005    Return\n"
        "\n")


def test_array_param_passing_in_disassembly(run):
    """Passing a global array to a function lists it in CallUser args."""
    source = "function f(a, b) { a[b] = 1; print b; for (x in a) print x }\n" \
             "BEGIN { c[1]=1; f(c, 2) }"
    result = run(["-da", source])
    # CATCHES: the array argument is shown as '[c]' after the function
    # name, and inside f the parameter is addressed as ArrayLocal a.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Num 1 (0)\n"
        '0002    Str "1" (0)\n'
        "0004    AssignArrayGlobal c\n"
        "0006    Num 2 (1)\n"
        "0008    CallUser f [c]\n"
        "000d    Drop\n"
        "\n"
        "        // function f\n"
        "0000    Num 1 (0)\n"
        "0002    Local b\n"
        "0004    AssignArrayLocal a\n"
        "0006    Local b\n"
        "0008    Print 1\n"
        "000b    ForIn x a 0x0016\n"
        "0011    Global x\n"
        "0013    Print 1\n"
        "\n")


def test_special_variables_in_disassembly(run):
    """Special variables use Special/AssignSpecial/IncrSpecial opcodes."""
    result = run(["-da", 'BEGIN { print NR, NF, FS, SUBSEP, ENVIRON["X"], ARGV[1] }'])
    # CATCHES: special variables are referenced by name not index, and
    # indexing ENVIRON/ARGV uses ArrayGlobal with the array's name.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Special NR\n"
        "0002    Special NF\n"
        "0004    Special FS\n"
        "0006    Special SUBSEP\n"
        '0008    Str "X" (0)\n'
        "000a    ArrayGlobal ENVIRON\n"
        '000c    Str "1" (1)\n'
        "000e    ArrayGlobal ARGV\n"
        "0010    Print 6\n"
        "\n")


def test_assign_and_incr_special_in_disassembly(run):
    """Assigning and incrementing special variables keeps their names."""
    result = run(["-da", 'BEGIN { NR = 1; NF = 2; FS = "x"; ++NR; $3 = 5 }'])
    # CATCHES: ++NR becomes IncrSpecial 1 NR (amount then name) and field
    # assignment compiles to AssignField with no operand.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Num 1 (0)\n"
        "0002    AssignSpecial NR\n"
        "0004    Num 2 (1)\n"
        "0006    AssignSpecial NF\n"
        '0008    Str "x" (0)\n'
        "000a    AssignSpecial FS\n"
        "000c    IncrSpecial 1 NR\n"
        "000f    Num 5 (2)\n"
        "0011    Num 3 (3)\n"
        "0013    AssignField\n"
        "\n")


def test_builtin_calls_in_disassembly(run):
    """Builtin calls disassemble as CallBuiltin with a Builtin* opcode."""
    result = run(["-da", 'BEGIN { print close("f"), fflush(), fflush("f") }'])
    # CATCHES: close and fflush map to BuiltinClose/BuiltinFflushAll/
    # BuiltinFflush, and string args are shared from the constant pool.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        '0000    Str "f" (0)\n'
        "0002    CallBuiltin BuiltinClose\n"
        "0004    CallBuiltin BuiltinFflushAll\n"
        '0006    Str "f" (0)\n'
        "0008    CallBuiltin BuiltinFflush\n"
        "000a    Print 3\n"
        "\n")


def test_printf_redirect_in_disassembly(run):
    """printf with a file redirect shows the redirect token after the count."""
    result = run(["-da", 'BEGIN { printf "%s", "a" > "f"; print | "cat" }'])
    # CATCHES: 'Printf 2 >' encodes the argument count and the redirect
    # token, while a pipe print with no args is 'Print 0 |'.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        '0000    Str "f" (0)\n'
        '0002    Str "%s" (1)\n'
        '0004    Str "a" (2)\n'
        "0006    Printf 2 >\n"
        '0009    Str "cat" (3)\n'
        "000b    Print 0 |\n"
        "\n")


def test_da_with_covermode_shows_cover_counter(run):
    """-covermode annotates the program, visible in the assembly."""
    result = run(["-da", "-covermode", "count", "BEGIN { print 1 }"])
    # CATCHES: coverage instrumentation inserts an IncrArrayGlobal on the
    # __COVER array before the statement, and nothing is executed.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        '0000    Str "1" (0)\n'
        "0002    IncrArrayGlobal 1 __COVER\n"
        "0005    Num 1 (0)\n"
        "0007    Print 1\n"
        "\n")


def test_da_exits_zero_without_executing(run):
    """-da never runs the program, even one that would fail at runtime."""
    result = run(["-da", "BEGIN { print 1/0 }"])
    # CATCHES: the division by zero is never evaluated because -da exits
    # right after disassembling, so stderr is empty and the status is 0.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Num 1 (0)\n"
        "0002    Num 0 (1)\n"
        "0004    Divide\n"
        "0005    Print 1\n"
        "\n")


def test_all_special_variables_in_disassembly(run):
    """Every special variable is referenced in -da by its name."""
    result = run(["-da", "BEGIN { print ARGC, CONVFMT, FILENAME, FNR, "
                 "INPUTMODE, OFMT, OFS, ORS, OUTPUTMODE, RLENGTH, RS, "
                 "RSTART, RT }"])
    # CATCHES: each of the 13 non-builtin-array special variables loads via
    # a Special opcode spelled with the variable's own name, in source
    # order, and the print counts all 13 arguments.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Special ARGC\n"
        "0002    Special CONVFMT\n"
        "0004    Special FILENAME\n"
        "0006    Special FNR\n"
        "0008    Special INPUTMODE\n"
        "000a    Special OFMT\n"
        "000c    Special OFS\n"
        "000e    Special ORS\n"
        "0010    Special OUTPUTMODE\n"
        "0012    Special RLENGTH\n"
        "0014    Special RS\n"
        "0016    Special RSTART\n"
        "0018    Special RT\n"
        "001a    Print 13\n"
        "\n")


def test_assigning_every_special_variable_in_disassembly(run):
    """Assignments to special variables keep their names too."""
    result = run(["-da", 'BEGIN { ARGC = 1; CONVFMT = "x"; FILENAME = "f"; '
                 'FNR = 2; INPUTMODE = "i"; OFMT = "o"; OFS = "s"; '
                 'ORS = "r"; OUTPUTMODE = "m"; RLENGTH = 3; RS = "t"; '
                 'RSTART = 4; RT = "u" }'])
    # CATCHES: AssignSpecial prints the destination's name, and numbers and
    # strings come from separate constant pools (Num and Str share index
    # counters within their own kind, shown in the parenthesised index).
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Num 1 (0)\n"
        "0002    AssignSpecial ARGC\n"
        '0004    Str "x" (0)\n'
        "0006    AssignSpecial CONVFMT\n"
        '0008    Str "f" (1)\n'
        "000a    AssignSpecial FILENAME\n"
        "000c    Num 2 (1)\n"
        "000e    AssignSpecial FNR\n"
        '0010    Str "i" (2)\n'
        "0012    AssignSpecial INPUTMODE\n"
        '0014    Str "o" (3)\n'
        "0016    AssignSpecial OFMT\n"
        '0018    Str "s" (4)\n'
        "001a    AssignSpecial OFS\n"
        '001c    Str "r" (5)\n'
        "001e    AssignSpecial ORS\n"
        '0020    Str "m" (6)\n'
        "0022    AssignSpecial OUTPUTMODE\n"
        "0024    Num 3 (2)\n"
        "0026    AssignSpecial RLENGTH\n"
        '0028    Str "t" (7)\n'
        "002a    AssignSpecial RS\n"
        "002c    Num 4 (3)\n"
        "002e    AssignSpecial RSTART\n"
        '0030    Str "u" (8)\n'
        "0032    AssignSpecial RT\n"
        "\n")


def test_getline_target_variants_in_disassembly(run):
    """getline into nothing, a field, a pipe, a special var and an array."""
    result = run(["-da", 'BEGIN { getline; getline $1; "cat" | getline; '
                 "getline NR; getline arr[2] }"])
    # CATCHES: the redirect token prints as '<illegal>' when there is none,
    # '|' for a pipe, and the target is spelled after it: nothing for a
    # bare getline, then field, special and array forms by name.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Getline <illegal>\n"
        "0002    Drop\n"
        "0003    Num 1 (0)\n"
        "0005    GetlineField <illegal>\n"
        "0007    Drop\n"
        '0008    Str "cat" (0)\n'
        "000a    Getline |\n"
        "000c    Drop\n"
        "000d    GetlineSpecial <illegal> NR\n"
        "0010    Drop\n"
        '0011    Str "2" (1)\n'
        "0013    GetlineArray <illegal> arr\n"
        "0017    Drop\n"
        "\n")


def test_local_variable_and_array_opcodes_in_disassembly(run):
    """Local scalars and array params get their own named opcodes."""
    source = ("function f(x, a) { x = 1; x++; x += 2; a[1] = 2; a[1]++; "
              'a[1] += 3; print x, a[1]; if (2 in a) print "in"; '
              "getline x; return x }\n"
              "BEGIN { g[0] = 9; f(1, g) }")
    result = run(["-da", source])
    # CATCHES: inside the function every operation names the local (x) or
    # the local array (a) directly, e.g. 'InLocal a' for the membership
    # test and 'GetlineLocal <illegal> x' for the getline target.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Num 9 (3)\n"
        '0002    Str "0" (3)\n'
        "0004    AssignArrayGlobal g\n"
        "0006    Num 1 (0)\n"
        "0008    CallUser f [g]\n"
        "000d    Drop\n"
        "\n"
        "        // function f\n"
        "0000    Num 1 (0)\n"
        "0002    AssignLocal x\n"
        "0004    IncrLocal 1 x\n"
        "0007    Num 2 (1)\n"
        "0009    AugAssignLocal AugOpAdd x\n"
        "000c    Num 2 (1)\n"
        '000e    Str "1" (0)\n'
        "0010    AssignArrayLocal a\n"
        '0012    Str "1" (0)\n'
        "0014    IncrArrayLocal 1 a\n"
        "0017    Num 3 (2)\n"
        '0019    Str "1" (0)\n'
        "001b    AugAssignArrayLocal AugOpAdd a\n"
        "001e    Local x\n"
        '0020    Str "1" (0)\n'
        "0022    ArrayLocal a\n"
        "0024    Print 2\n"
        '0027    Str "2" (1)\n'
        "0029    InLocal a\n"
        "002b    JumpFalse 0x0032\n"
        '002d    Str "in" (2)\n'
        "002f    Print 1\n"
        "0032    GetlineLocal <illegal> x\n"
        "0035    Drop\n"
        "0036    Local x\n"
        "0038    Return\n"
        "\n")


def test_comparison_and_logical_jump_opcodes_in_disassembly(run):
    """Each comparison in an if compiles to a specific inverted jump."""
    result = run(["-da", 'BEGIN { if (x == 1) print "a"; if (x != 1) '
                 'print "b"; if (x < 1) print "c"; if (x > 1) print "d"; '
                 'if (x <= 1) print "e"; if (x >= 1) print "f"; '
                 'if (a && b) print "g"; if (a || b) print "h" }'])
    # CATCHES: 'if (x == 1)' branches with JumpNotEquals (the inverted
    # comparison), '<' becomes JumpGreaterOrEqual and so on, while &&
    # uses Dupe/JumpFalse and || uses Dupe/JumpTrue, each closing with a
    # Boolean opcode and absolute hex jump targets.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Global x\n"
        "0002    Num 1 (0)\n"
        "0004    JumpNotEquals 0x000b\n"
        '0006    Str "a" (0)\n'
        "0008    Print 1\n"
        "000b    Global x\n"
        "000d    Num 1 (0)\n"
        "000f    JumpEquals 0x0016\n"
        '0011    Str "b" (1)\n'
        "0013    Print 1\n"
        "0016    Global x\n"
        "0018    Num 1 (0)\n"
        "001a    JumpGreaterOrEqual 0x0021\n"
        '001c    Str "c" (2)\n'
        "001e    Print 1\n"
        "0021    Global x\n"
        "0023    Num 1 (0)\n"
        "0025    JumpLessOrEqual 0x002c\n"
        '0027    Str "d" (3)\n'
        "0029    Print 1\n"
        "002c    Global x\n"
        "002e    Num 1 (0)\n"
        "0030    JumpGreater 0x0037\n"
        '0032    Str "e" (4)\n'
        "0034    Print 1\n"
        "0037    Global x\n"
        "0039    Num 1 (0)\n"
        "003b    JumpLess 0x0042\n"
        '003d    Str "f" (5)\n'
        "003f    Print 1\n"
        "0042    Global a\n"
        "0044    Dupe\n"
        "0045    JumpFalse 0x004a\n"
        "0047    Drop\n"
        "0048    Global b\n"
        "004a    Boolean\n"
        "004b    JumpFalse 0x0052\n"
        '004d    Str "g" (6)\n'
        "004f    Print 1\n"
        "0052    Global a\n"
        "0054    Dupe\n"
        "0055    JumpTrue 0x005a\n"
        "0057    Drop\n"
        "0058    Global b\n"
        "005a    Boolean\n"
        "005b    JumpFalse 0x0062\n"
        '005d    Str "h" (7)\n'
        "005f    Print 1\n"
        "\n")


def test_split_sprintf_nulls_printf_in_disassembly(run):
    """Builtin calls with arrays, missing args and bare printf."""
    source = ('function f3(p, q, r) { } BEGIN { split("a b", s); '
              'n = split("a-b", t, "-"); m = sprintf("%d", 1); f3(1); '
              'printf "x"; x = $"name" }')
    result = run(["-da", source])
    # CATCHES: split names its array, split with a separator prints
    # 'CallSplitSep t 0', sprintf prints its argument count, calling f3
    # with fewer args than params pads with 'Nulls 2', a redirect-less
    # printf prints just the count, and $"name" is a plain Field after a
    # string constant.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        '0000    Str "a b" (0)\n'
        "0002    CallSplit s\n"
        "0005    Drop\n"
        '0006    Str "a-b" (1)\n'
        '0008    Str "-" (2)\n'
        "000a    CallSplitSep t 0\n"
        "000e    AssignGlobal n\n"
        '0010    Str "%d" (3)\n'
        "0012    Num 1 (0)\n"
        "0014    CallSprintf 2\n"
        "0016    AssignGlobal m\n"
        "0018    Num 1 (0)\n"
        "001a    Nulls 2\n"
        "001c    CallUser f3 []\n"
        "001f    Drop\n"
        '0020    Str "x" (4)\n'
        "0022    Printf 1\n"
        '0025    Str "name" (5)\n'
        "0027    Field\n"
        "0028    AssignGlobal x\n"
        "\n"
        "        // function f3\n"
        "\n")


def test_field_incr_and_multi_index_opcodes_in_disassembly(run):
    """Named fields, field increments and multi-index/concat forms."""
    result = run(["-da", 'BEGIN { x = @"name"; $1++; $1 += 2; m[1, 2] = 3; '
                 'print m[1, 2]; print "a" "b" "c" }'])
    # CATCHES: @"name" compiles to FieldByNameStr with the quoted name and
    # pool index, $1++ to IncrField 1 and $1 += 2 to AugAssignField, a
    # two-subscript index uses IndexMulti 2, and three concatenated
    # strings collapse into one ConcatMulti 3.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        '0000    FieldByNameStr "name" (0)\n'
        "0002    AssignGlobal x\n"
        "0004    Num 1 (0)\n"
        "0006    IncrField 1\n"
        "0008    Num 2 (1)\n"
        "000a    Num 1 (0)\n"
        "000c    AugAssignField AugOpAdd\n"
        "000e    Num 3 (2)\n"
        '0010    Str "1" (1)\n'
        '0012    Str "2" (2)\n'
        "0014    IndexMulti 2\n"
        "0016    AssignArrayGlobal m\n"
        '0018    Str "1" (1)\n'
        '001a    Str "2" (2)\n'
        "001c    IndexMulti 2\n"
        "001e    ArrayGlobal m\n"
        "0020    Print 1\n"
        '0023    Str "a" (3)\n'
        '0025    Str "b" (4)\n'
        '0027    Str "c" (5)\n'
        "0029    ConcatMulti 3\n"
        "002b    Print 1\n"
        "\n")


def test_augassign_special_in_disassembly(run):
    """Compound assignment to a special variable uses AugAssignSpecial."""
    result = run(["-da", "BEGIN { NR += 2 }"])
    # CATCHES: NR += 2 compiles to Num then AugAssignSpecial, and the
    # disassembler renders the variable slot with a %d verb, so the
    # literal text '%!d(string=NR)' is printed instead of a clean name.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "        // BEGIN\n"
        "0000    Num 2 (0)\n"
        "0002    AugAssignSpecial AugOpAdd %!d(string=NR)\n"
        "\n")
