"""Parse, lex and name-resolution errors: exact diagnostics on stderr.

Every expectation below was recorded from the reference binary. The error
format is ``FILE:LINE:COL: message`` followed by the offending source line
and a caret line (tabs rendered as 4 spaces), and the process exits 1 with
empty stdout. ``FILE`` is ``<cmdline>`` for a command-line program.
"""

import pytest

# Lexical errors: bad characters, unterminated strings/regexes, bad escapes
# and bad number syntax, all reported by lexer/lexer.go.
LEXICAL_ERRORS = [
    pytest.param('`',
                 '<cmdline>:1:1: unexpected char\n`\n^\n',
                 id='backtick'),
    pytest.param('BEGIN { print 1 & 2 }',
                 "<cmdline>:1:18: unexpected char after '&'\nBEGIN { print 1 & 2 }\n                 ^\n",
                 id='amp-standalone'),
    pytest.param('BEGIN { print "abc }',
                 "<cmdline>:1:21: can't have newline in string\nBEGIN { print \"abc }\n                    ^\n",
                 id='unterminated-string'),
    pytest.param('BEGIN { print "a\nb" }',
                 "<cmdline>:1:17: can't have newline in string\nBEGIN { print \"a\n                ^\n",
                 id='newline-in-string'),
    pytest.param('BEGIN { print "\\x" }',
                 '<cmdline>:1:18: 1 or 2 hex digits expected\nBEGIN { print "\\x" }\n                 ^\n',
                 id='bad-hex-escape'),
    pytest.param('BEGIN { print "\\uZZ" }',
                 '<cmdline>:1:18: 1-8 hex digits expected\nBEGIN { print "\\uZZ" }\n                 ^\n',
                 id='bad-u-escape'),
    pytest.param('BEGIN { print "\\ud800" }',
                 '<cmdline>:1:22: invalid Unicode character\nBEGIN { print "\\ud800" }\n                     ^\n',
                 id='surrogate-escape'),
    pytest.param('BEGIN { /abc }',
                 "<cmdline>:1:15: can't have newline in regex\nBEGIN { /abc }\n              ^\n",
                 id='unterminated-regex'),
    pytest.param('.',
                 '<cmdline>:1:2: expected digits\n.\n ^\n',
                 id='lone-dot'),
    pytest.param('BEGIN { print "abc\\',
                 ":0:1: didn't find end quote in string\n\n^\n",
                 id='backslash-eof'),
    pytest.param('BEGIN { x \\ y }',
                 "<cmdline>:1:12: expected \\n after \\ line continuation\n"
                 "BEGIN { x \\ y }\n"
                 "           ^\n",
                 id='bad-line-continuation'),
    pytest.param('BEGIN { x = /abc\\',
                 ":0:1: didn't find end slash in regex\n\n^\n",
                 id='regex-eof-backslash'),
]


@pytest.mark.parametrize("source,expected_stderr", LEXICAL_ERRORS)
def test_lexical_error_message_and_status(run, source, expected_stderr):
    """A lexically invalid program reports the recorded diagnostic."""
    result = run([source])
    # CATCHES: the exact position prefix, message wording, echoed source
    # line, caret column and exit status 1 are all pinned; stdout is empty.
    assert (result.returncode, result.out, result.err) == (
        1, "", expected_stderr)


# Grammar errors: unbalanced delimiters, lvalue rules, comma rules,
# statement separators and print/printf redirection syntax.
GRAMMAR_ERRORS = [
    pytest.param('BEGIN { print (1 + 2 }',
                 '<cmdline>:1:22: expected ) instead of }\nBEGIN { print (1 + 2 }\n                     ^\n',
                 id='unbalanced-paren'),
    pytest.param('BEGIN { print 1 + 2) }',
                 '<cmdline>:1:20: expected ; or newline between statements\nBEGIN { print 1 + 2) }\n                   ^\n',
                 id='extra-rparen'),
    pytest.param('BEGIN { a[1 }',
                 '<cmdline>:1:13: expected ] instead of }\nBEGIN { a[1 }\n            ^\n',
                 id='unbalanced-bracket'),
    pytest.param('BEGIN { if (x) print 1 else print 2 }',
                 '<cmdline>:1:24: expected , instead of else\nBEGIN { if (x) print 1 else print 2 }\n                       ^\n',
                 id='else-without-semi'),
    pytest.param('BEGIN { 1 = 2 }',
                 '<cmdline>:1:9: expected lvalue before =\nBEGIN { 1 = 2 }\n        ^\n',
                 id='assign-non-lvalue'),
    pytest.param('BEGIN { "str" = 1 }',
                 '<cmdline>:1:9: expected lvalue before =\nBEGIN { "str" = 1 }\n        ^\n',
                 id='assign-string-lvalue'),
    pytest.param('BEGIN { (x) = 1 }',
                 '<cmdline>:1:9: expected lvalue before =\nBEGIN { (x) = 1 }\n        ^\n',
                 id='assign-grouping-lvalue'),
    pytest.param('BEGIN { f() = 1 }',
                 '<cmdline>:1:9: expected lvalue before =\nBEGIN { f() = 1 }\n        ^\n',
                 id='assign-call-lvalue'),
    pytest.param('BEGIN { ++ 1 }',
                 '<cmdline>:1:12: expected lvalue after ++\nBEGIN { ++ 1 }\n           ^\n',
                 id='preincr-non-lvalue'),
    pytest.param('BEGIN { 1 ++ }',
                 '<cmdline>:1:14: expected lvalue after ++\nBEGIN { 1 ++ }\n             ^\n',
                 id='postincr-non-lvalue'),
    pytest.param('BEGIN { x = (1, 2) }',
                 '<cmdline>:1:13: unexpected comma-separated expression\nBEGIN { x = (1, 2) }\n            ^\n',
                 id='comma-expr-assignment'),
    pytest.param('(1, 2) 3',
                 '<cmdline>:1:1: unexpected comma-separated expression\n(1, 2) 3\n^\n',
                 id='comma-expr-pattern'),
    pytest.param('BEGIN { sub(/a/, "b", "c") }',
                 '<cmdline>:1:23: 3rd arg to sub/gsub must be lvalue\nBEGIN { sub(/a/, "b", "c") }\n                      ^\n',
                 id='sub-string-third-arg'),
    pytest.param('BEGIN { gsub(/a/, "b", 3) }',
                 '<cmdline>:1:24: 3rd arg to sub/gsub must be lvalue\nBEGIN { gsub(/a/, "b", 3) }\n                       ^\n',
                 id='gsub-num-third-arg'),
    pytest.param('BEGIN { printf }',
                 '<cmdline>:1:16: expected printf args, got none\nBEGIN { printf }\n               ^\n',
                 id='printf-no-args'),
    pytest.param('BEGIN { print "a" > }',
                 '<cmdline>:1:21: expected expression instead of }\nBEGIN { print "a" > }\n                    ^\n',
                 id='print-no-dest'),
    pytest.param('BEGIN { printf "a" > }',
                 '<cmdline>:1:22: expected expression instead of }\nBEGIN { printf "a" > }\n                     ^\n',
                 id='printf-no-dest'),
    pytest.param('BEGIN { print | }',
                 '<cmdline>:1:17: expected expression instead of }\nBEGIN { print | }\n                ^\n',
                 id='print-pipe-no-dest'),
    pytest.param('BEGIN { print "a" >> }',
                 '<cmdline>:1:22: expected expression instead of }\nBEGIN { print "a" >> }\n                     ^\n',
                 id='print-append-no-dest'),
    pytest.param('{ print $1 > "f", "g" }',
                 '<cmdline>:1:17: expected ; or newline between statements\n{ print $1 > "f", "g" }\n                ^\n',
                 id='redirect-then-comma'),
    pytest.param('BEGIN { print 1 print 2 }',
                 '<cmdline>:1:17: expected , instead of print\nBEGIN { print 1 print 2 }\n                ^\n',
                 id='stmt-without-separator'),
    pytest.param('BEGIN { x = 1, 2 }',
                 '<cmdline>:1:14: expected ; or newline between statements\nBEGIN { x = 1, 2 }\n             ^\n',
                 id='assign-comma'),
    pytest.param('$1 in a 2',
                 '<cmdline>:1:9: expected , instead of number\n$1 in a 2\n        ^\n',
                 id='expected-comma-in-pattern'),
    pytest.param('BEGIN { for if }',
                 '<cmdline>:1:13: expected ( instead of if\nBEGIN { for if }\n            ^\n',
                 id='for-if'),
    pytest.param('BEGIN { while }',
                 '<cmdline>:1:15: expected ( instead of }\nBEGIN { while }\n              ^\n',
                 id='while-no-paren'),
    pytest.param('BEGIN { do } while (x)',
                 '<cmdline>:1:12: expected expression instead of }\nBEGIN { do } while (x)\n           ^\n',
                 id='do-empty'),
    pytest.param('BEGIN { for (x in a) }',
                 '<cmdline>:1:22: expected expression instead of }\nBEGIN { for (x in a) }\n                     ^\n',
                 id='forin-empty'),
    pytest.param('BEGIN { delete }',
                 '<cmdline>:1:16: expected name instead of }\nBEGIN { delete }\n               ^\n',
                 id='delete-no-name'),
    pytest.param('BEGIN { delete a[ }',
                 '<cmdline>:1:19: expected expression instead of ]\nBEGIN { delete a[ }\n                  ^\n',
                 id='delete-empty-index'),
    pytest.param('{ return }',
                 '<cmdline>:1:3: return must be inside a function\n{ return }\n  ^\n',
                 id='return-in-action'),
    pytest.param('BEGIN { break }',
                 '<cmdline>:1:9: break must be inside a loop body\nBEGIN { break }\n        ^\n',
                 id='break-outside-loop'),
    pytest.param('BEGIN { continue }',
                 '<cmdline>:1:9: continue must be inside a loop body\nBEGIN { continue }\n        ^\n',
                 id='continue-outside-loop'),
    pytest.param('BEGIN { next }',
                 "<cmdline>:1:9: next can't be inside BEGIN or END\nBEGIN { next }\n        ^\n",
                 id='next-in-begin'),
    pytest.param('END { nextfile }',
                 "<cmdline>:1:7: nextfile can't be inside BEGIN or END\nEND { nextfile }\n      ^\n",
                 id='nextfile-in-end'),
    pytest.param('print 1 +',
                 '<cmdline>:1:1: expected expression instead of print\nprint 1 +\n^\n',
                 id='print-as-pattern'),
    pytest.param('BEGIN { print "a" # comment }',
                 ':0:1: expected } instead of EOF\n\n^\n',
                 id='expr-instead-of-rbrace'),
    pytest.param('BEGIN { for (if; i < 3; i++) print }',
                 "<cmdline>:1:14: expected print/printf, delete, or expression\n"
                 "BEGIN { for (if; i < 3; i++) print }\n"
                 "             ^\n",
                 id='for-keyword-pre'),
    pytest.param('BEGIN { for (i = 0; i < 3; if) print }',
                 "<cmdline>:1:28: expected print/printf, delete, or expression\n"
                 "BEGIN { for (i = 0; i < 3; if) print }\n"
                 "                           ^\n",
                 id='for-keyword-post'),
    pytest.param('function f(f) { }',
                 "<cmdline>:1:12: can't use function name as parameter name\n"
                 "function f(f) { }\n"
                 "           ^\n",
                 id='func-name-param'),
    pytest.param('function f(a, a) { }',
                 '<cmdline>:1:15: duplicate parameter name "a"\n'
                 "function f(a, a) { }\n"
                 "              ^\n",
                 id='dup-param'),
    pytest.param('BEGIN { @"x" = 1 }',
                 "<cmdline>:1:14: assigning @ expression not supported\n"
                 'BEGIN { @"x" = 1 }\n'
                 "             ^\n",
                 id='assign-named-field'),
    pytest.param('BEGIN { for (1 in a) print }',
                 "<cmdline>:1:22: expected 'for (var in array) ...'\n"
                 "BEGIN { for (1 in a) print }\n"
                 "                     ^\n",
                 id='forin-non-var'),
    pytest.param('BEGIN { for ((1, 2) in a) print }',
                 "<cmdline>:1:27: expected 'for (var in array) ...'\n"
                 "BEGIN { for ((1, 2) in a) print }\n"
                 "                          ^\n",
                 id='forin-multi'),
    pytest.param('BEGIN { for (f() in a) print }',
                 "<cmdline>:1:24: expected 'for (var in array) ...'\n"
                 "BEGIN { for (f() in a) print }\n"
                 "                       ^\n",
                 id='forin-call'),
    pytest.param('BEGIN { print a[] }',
                 "<cmdline>:1:17: expected expression instead of ]\n"
                 "BEGIN { print a[] }\n"
                 "                ^\n",
                 id='empty-index'),
]


@pytest.mark.parametrize("source,expected_stderr", GRAMMAR_ERRORS)
def test_grammar_error_message_and_status(run, source, expected_stderr):
    """A grammatically invalid program reports the recorded diagnostic."""
    result = run([source])
    # CATCHES: the parser's exact message, token names in "expected X
    # instead of Y" wording, caret column and exit status 1 are pinned.
    assert (result.returncode, result.out, result.err) == (
        1, "", expected_stderr)


# Name-resolution errors, reported by internal/resolver/resolve.go in the
# same FILE:LINE:COL format as parse errors.
RESOLVE_ERRORS = [
    pytest.param('BEGIN { f() }',
                 '<cmdline>:1:9: undefined function "f"\nBEGIN { f() }\n        ^\n',
                 id='undefined-function'),
    pytest.param('function f() { g() } BEGIN { f() }',
                 '<cmdline>:1:16: undefined function "g"\nfunction f() { g() } BEGIN { f() }\n               ^\n',
                 id='undefined-function-nested'),
    pytest.param('function f(x) { x() } BEGIN { f(1) }',
                 '<cmdline>:1:17: can\'t call local variable "x" as function\nfunction f(x) { x() } BEGIN { f(1) }\n                ^\n',
                 id='call-local-as-function'),
    pytest.param('function f(a) { } BEGIN { f(1, 2) }',
                 '<cmdline>:1:27: "f" called with more arguments than declared\nfunction f(a) { } BEGIN { f(1, 2) }\n                          ^\n',
                 id='too-many-args'),
    pytest.param('function f() { } function f() { } BEGIN { }',
                 '<cmdline>:1:27: function "f" already defined\nfunction f() { } function f() { } BEGIN { }\n                          ^\n',
                 id='function-redefined'),
    pytest.param('BEGIN { x = 1 } function x() { }',
                 '<cmdline>:1:9: global var "x" can\'t also be a function\nBEGIN { x = 1 } function x() { }\n        ^\n',
                 id='global-var-as-function'),
    pytest.param('BEGIN { x = 1; print x[1] }',
                 '<cmdline>:1:22: can\'t use scalar "x" as array\nBEGIN { x = 1; print x[1] }\n                     ^\n',
                 id='scalar-as-array'),
    pytest.param('BEGIN { a[1] = 2; print a }',
                 '<cmdline>:1:25: can\'t use array "a" as scalar\nBEGIN { a[1] = 2; print a }\n                        ^\n',
                 id='array-as-scalar'),
    pytest.param('BEGIN { x = 1; f(x) } function f(a) { print a[1] }',
                 '<cmdline>:1:18: can\'t pass scalar "x" as array param\nBEGIN { x = 1; f(x) } function f(a) { print a[1] }\n                 ^\n',
                 id='pass-scalar-as-array-param'),
    pytest.param('function f(s) { print s } BEGIN { a[1]=2; f(a) }',
                 '<cmdline>:1:45: can\'t pass array "a" as scalar param\nfunction f(s) { print s } BEGIN { a[1]=2; f(a) }\n                                            ^\n',
                 id='pass-array-as-scalar-param'),
    pytest.param('function f(a) { a[1] = 1 } BEGIN { f(2) }',
                 "<cmdline>:1:36: can't pass scalar 2 as array param\nfunction f(a) { a[1] = 1 } BEGIN { f(2) }\n                                   ^\n",
                 id='pass-literal-as-array-param'),
    pytest.param('function f(a) { a[1] = 1 } BEGIN { f("str") }',
                 '<cmdline>:1:36: can\'t pass scalar "str" as array param\nfunction f(a) { a[1] = 1 } BEGIN { f("str") }\n                                   ^\n',
                 id='pass-string-as-array-param'),
    pytest.param('function f(a) { a[1] = 1 } BEGIN { f(1+2) }',
                 "<cmdline>:1:36: can't pass scalar 1 + 2 as array param\nfunction f(a) { a[1] = 1 } BEGIN { f(1+2) }\n                                   ^\n",
                 id='pass-expr-as-array-param'),
    pytest.param('function f(x) { print x } BEGIN { g[0] = 9; f(g) }',
                 '<cmdline>:1:47: can\'t pass array "g" as scalar param\nfunction f(x) { print x } BEGIN { g[0] = 9; f(g) }\n                                              ^\n',
                 id='pass-array-as-scalar-param-unused-other'),
]


@pytest.mark.parametrize("source,expected_stderr", RESOLVE_ERRORS)
def test_resolve_error_message_and_status(run, source, expected_stderr):
    """A name-resolution failure is reported like a parse error."""
    result = run([source])
    # CATCHES: resolver diagnostics share the FILE:LINE:COL + source line
    # + caret format and exit status 1, with the exact quoted-name wording.
    assert (result.returncode, result.out, result.err) == (
        1, "", expected_stderr)


def test_error_line_renders_tabs_as_four_spaces(run, write):
    """The echoed source line expands tabs to 4 spaces and shifts the caret."""
    write("tab.awk", "BEGIN {\n\tx*;\n}\n")
    result = run(["-f", "tab.awk"])
    # CATCHES: a tab before the error becomes 4 spaces on the echo line and
    # counts as 3 extra caret spaces, so the caret lands under the ';'.
    assert (result.returncode, result.out, result.err) == (
        1,
        "",
        "tab.awk:2:4: expected expression instead of ;\n"
        "    x*;\n"
        "      ^\n")


def test_error_line_renders_crlf_source(run, write):
    """A CR before LF changes the offending token to <newline>."""
    write("crlf.awk", "BEGIN {\n\tx*\r\n}\n")
    result = run(["-f", "crlf.awk"])
    # CATCHES: with \r\n line endings the parser reports <newline> (the CR
    # is skipped by the lexer) while the echoed source line keeps the raw
    # CR byte, and the caret still counts the tab as 4 columns.
    assert (result.returncode, result.out, result.err) == (
        1,
        "",
        "crlf.awk:2:4: expected expression instead of <newline>\n"
        "    x*\r\n"
        "      ^\n")


def test_error_caret_counts_runes_not_bytes(run, write):
    """The caret column counts runes, but positions count bytes."""
    write("uni.awk", 'BEGIN { print "éé" + }\n')
    result = run(["-f", "uni.awk"])
    # CATCHES: the error column is byte-based (24) while the caret is placed
    # by rune count (21 spaces), so multi-byte text shifts the caret left.
    assert (result.returncode, result.out, result.err) == (
        1,
        "",
        "uni.awk:1:24: expected expression instead of }\n"
        'BEGIN { print "éé" + }\n'
        "                     ^\n")


def test_error_in_stdin_program_labels_stdin(run):
    """A program read from stdin with -f - is labelled <stdin>."""
    result = run(["-f", "-"], stdin="\n $\n")
    # CATCHES: the file label is the literal '<stdin>' and the line/column
    # are relative to the stdin source, not the concatenated program.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<stdin>:2:3: expected expression instead of <newline>\n $\n  ^\n")


def test_error_reports_file_and_local_line_for_multiple_f_files(run, write):
    """With several -f files the error names the file and its local line."""
    write("good.awk", 'BEGIN { print "good" }\n')
    write("bad.awk", "x*\n")
    result = run(["-f", "good.awk", "-f", "bad.awk"])
    # CATCHES: the overall line 2 is translated to bad.awk line 1, and the
    # echoed source line comes from the concatenated source.
    assert (result.returncode, result.out, result.err) == (
        1, "", "bad.awk:1:3: expected expression instead of <newline>\nx*\n  ^\n")


def test_error_in_first_f_file_wins_even_if_second_given(run, write):
    """A bad first -f file is reported regardless of later files."""
    write("f1.awk", "print 1 +\n")
    write("f2.awk", "BEGIN {\n  print 1\n}\n")
    result = run(["-f", "f1.awk", "-f", "f2.awk"])
    # CATCHES: parsing stops at the first error; 'print' is not a valid
    # pattern expression so the error is at 1:1 of the first file.
    assert (result.returncode, result.out, result.err) == (
        1, "", "f1.awk:1:1: expected expression instead of print\nprint 1 +\n^\n")


def test_error_in_second_f_file_uses_local_line_number(run, write):
    """An error in a later -f file reports that file's own line count."""
    write("f1.awk", "BEGIN {\n  print 1\n}\n")
    write("f2.awk", "BEGIN {\n  print 1 +\n}\n")
    result = run(["-f", "f1.awk", "-f", "f2.awk"])
    # CATCHES: f1 has 3 lines so overall line 4 maps to f2 line 2, keeping
    # the per-file line numbering in the diagnostic.
    assert (result.returncode, result.out, result.err) == (
        1,
        "",
        "f2.awk:2:12: expected expression instead of <newline>\n"
        "  print 1 +\n"
        "           ^\n")


def test_missing_f_program_file_is_reported(run):
    """A -f file that does not exist errors before any parsing."""
    result = run(["-f", "nosuchprog.awk"])
    # CATCHES: opening the program file happens before parsing, so the
    # message is the file-not-found one, not a parse diagnostic.
    assert (result.returncode, result.out, result.err) == (
        1, "", 'file "nosuchprog.awk" not found\n')


def test_multi_line_cmdline_error_uses_cmdline_label(run):
    """A multi-line command-line program keeps the <cmdline> label."""
    result = run(["BEGIN {\n\tx*;\n}"])
    # CATCHES: the label is '<cmdline>' even for multi-line programs, and
    # line 2 with its tab is echoed with the tab expanded to 4 spaces.
    assert (result.returncode, result.out, result.err) == (
        1,
        "",
        "<cmdline>:2:4: expected expression instead of ;\n"
        "    x*;\n"
        "      ^\n")


def test_eof_error_reports_empty_file_name_and_line_zero(run, write):
    """An error at EOF past the last line prints an empty name and line 0."""
    write("ub.awk", "BEGIN {\n  print 1\n")
    result = run(["-f", "ub.awk"])
    # CATCHES: the EOF position is past the file's line range so FileLine
    # yields ("", 0), giving the odd ':0:1:' prefix and an empty echo line.
    assert (result.returncode, result.out, result.err) == (
        1, "", ":0:1: expected } instead of EOF\n\n^\n")


def test_parse_error_goes_to_stderr_only(run):
    """The diagnostic goes to stderr; stdout stays completely empty."""
    result = run(["BEGIN { print 1 +"])
    # CATCHES: even though -d style output goes to stdout, parse errors are
    # written to stderr only, and nothing is printed on stdout.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", b"<cmdline>:1:18: expected expression instead of <newline>\n"
              b"BEGIN { print 1 +\n"
              b"                 ^\n")


def test_valid_program_next_to_invalid_variable_names(run):
    """Builtins and keywords cannot be redefined as functions or used oddly."""
    result = run(["function print() { }"])
    # CATCHES: keyword 'print' is not a name, so the function parameter
    # list parse fails with the recorded token message.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<cmdline>:1:10: expected name instead of print\nfunction print() { }\n         ^\n")


def test_regex_pattern_with_missing_end_slash_in_action(run):
    """An unterminated regex in an action errors on the newline."""
    result = run(["{ /foo }"])
    # CATCHES: the lexer scans the regex to end of line and reports the
    # newline variant of the regex error at the line end column.
    assert (result.returncode, result.out, result.err) == (
        1, "", "<cmdline>:1:9: can't have newline in regex\n{ /foo }\n        ^\n")
