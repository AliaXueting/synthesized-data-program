"""Every construct of the grammar must parse cleanly, checked via -d.

The -d flag prints the parsed AST to stdout and exits 0 without executing
the program, so it doubles as a "this source is accepted" oracle: a wrong
re-implementation that rejects (or mis-parses) any construct below fails
either on the exit status or on the dumped AST text.
"""

import pytest

# Whole-program layouts: BEGIN, END, patterns, range patterns, functions.
PROGRAM_LAYOUTS = [
    pytest.param(
        "$1 { print 1+1 }",
        "$1 {\n    print 1 + 1\n}\n",
        id="field-pattern-action"),
    pytest.param(
        "BEGIN { x = 1 } END { print x } /re/ { print } $2 > 1 { print } 1, 5 { print }",
        "BEGIN {\n    x = 1\n}\n"
        "\n/re/ {\n    print \n}\n"
        "\n$2 > 1 {\n    print \n}\n"
        "\n1, 5 {\n    print \n}\n"
        "\nEND {\n    print x\n}\n",
        id="all-section-kinds"),
    pytest.param(
        "1 2 3",
        "1 2 3\n",
        id="concat-pattern-only-action"),
    pytest.param(
        "x ? y : z 4",
        "x ? y : z 4\n",
        id="ternary-pattern-only-action"),
    pytest.param(
        "{ }",
        "{\n}\n",
        id="empty-action"),
    pytest.param(
        "function f() { } BEGIN { print }",
        "BEGIN {\n    print \n}\n\nfunction f() {\n}\n",
        id="function-and-begin"),
    pytest.param(
        "function f() { return }  BEGIN { print f() }",
        "BEGIN {\n    print f()\n}\n\nfunction f() {\n    return\n}\n",
        id="function-with-bare-return"),
]


@pytest.mark.parametrize("source,expected_stdout", PROGRAM_LAYOUTS)
def test_program_layout_parses(run, source, expected_stdout):
    """The given program layout parses and dumps the recorded AST."""
    result = run(["-d", source])
    # CATCHES: section ordering (BEGIN, actions, END, functions), the
    # blank line between sections, and the two-space-per-level indentation
    # of the AST dump are all pinned.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == expected_stdout


def test_all_statement_kinds_parse(run):
    """Every statement form parses; -d pretty-prints each one."""
    source = (
        "function add(a, b,   local1, local2) { return a + b }\n"
        "BEGIN {\n"
        "  while (x < 3) x++\n"
        "  do { x-- } while (x > 0)\n"
        "  for (i = 0; i < 3; i++) print i\n"
        "  for (k in arr) delete arr[k]\n"
        "  if (x in arr) print \"yes\"; else print \"no\"\n"
        "  print x ? \"a\" : \"b\"\n"
        "  printf \"%d %s\\n\", 1, \"hi\"\n"
        "  getline line < \"file\"\n"
        "  \"cmd\" | getline\n"
        "  print \"x\" > \"out\"\n"
        "  print \"y\" >> \"out2\"\n"
        "  print \"z\" | \"cat\"\n"
        "  exit 1\n"
        "}\n"
    )
    result = run(["-d", source])
    # CATCHES: loops, for-in, delete, if/else, ternary, printf, all three
    # redirections, all getline forms and exit all parse; the dump spells
    # redirections with no space after the operator (e.g. '>"out"').
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n"
        "    while (x < 3) {\n"
        "        x++\n"
        "    }\n"
        "    do {\n"
        "        x--\n"
        "    } while (x > 0)\n"
        "    for (i = 0; i < 3; i++) {\n"
        "        print i\n"
        "    }\n"
        "    for (k in arr) {\n"
        "        delete arr[k]\n"
        "    }\n"
        "    if (x in arr) {\n"
        "        print \"yes\"\n"
        "    } else {\n"
        "        print \"no\"\n"
        "    }\n"
        "    print x ? \"a\" : \"b\"\n"
        "    printf \"%d %s\\n\", 1, \"hi\"\n"
        "    getline line <\"file\"\n"
        "    \"cmd\" |getline\n"
        "    print \"x\" >\"out\"\n"
        "    print \"y\" >>\"out2\"\n"
        "    print \"z\" |\"cat\"\n"
        "    exit 1\n"
        "}\n"
        "\n"
        "function add(a, b, local1, local2) {\n"
        "    return a + b\n"
        "}\n"
    )


def test_all_expression_kinds_parse(run):
    """Unary, exponent, concat, match and indexing forms all parse."""
    source = (
        "BEGIN {\n"
        "  x = -1; y = !x; z = +x; w = x ^ y ^ 2; v = x ** 2\n"
        "  s = \"a\" \"b\" 1 2\n"
        "  b = x ~ /re/; c = x !~ \"s\"\n"
        "  n = $1; m = $(x+1); k = $NF\n"
        "  x += 1; x -= 1; x *= 1; x /= 1; x %= 1; x ^= 1\n"
        "  y = x++; z = ++x; w = x--; v = --x\n"
        "}\n"
    )
    result = run(["-d", source])
    # CATCHES: '**' is dumped as '^', concatenation as a single space,
    # unary !/+ keep their operator, and assignment/incr forms round-trip.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n"
        "    x = -1\n"
        "    y = !x\n"
        "    z = +x\n"
        "    w = x ^ y ^ 2\n"
        "    v = x ^ 2\n"
        "    s = \"a\" \"b\" 1 2\n"
        "    b = x ~ /re/\n"
        "    c = x !~ \"s\"\n"
        "    n = $1\n"
        "    m = $(x + 1)\n"
        "    k = $NF\n"
        "    x += 1\n"
        "    x -= 1\n"
        "    x *= 1\n"
        "    x /= 1\n"
        "    x %= 1\n"
        "    x ^= 1\n"
        "    y = x++\n"
        "    z = ++x\n"
        "    w = x--\n"
        "    v = --x\n"
        "}\n"
    )


def test_builtin_calls_parse(run):
    """Calls to every builtin function parse and dump their arg lists."""
    source = (
        "BEGIN {\n"
        "  print length(a), split(\"a b\", a), substr(\"abc\", 2)\n"
        "  print sqrt(2), exp(1), log(2), sin(1), cos(1), atan2(1, 2)\n"
        "  print int(1.5), rand(), srand(), srand(1), index(\"ab\", \"a\"), match(\"ab\", /a/)\n"
        "  print sprintf(\"%d\", 1), tolower(\"A\"), toupper(\"a\")\n"
        "}\n"
    )
    result = run(["-d", source])
    # CATCHES: builtins are dumped as ordinary calls with their argument
    # lists, and a regex argument to match() keeps its slash form.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n"
        "    print length(a), split(\"a b\", a), substr(\"abc\", 2)\n"
        "    print sqrt(2), exp(1), log(2), sin(1), cos(1), atan2(1, 2)\n"
        "    print int(1.5), rand(), srand(), srand(1), index(\"ab\", \"a\"), match(\"ab\", /a/)\n"
        "    print sprintf(\"%d\", 1), tolower(\"A\"), toupper(\"a\")\n"
        "}\n"
    )


def test_number_literals_are_normalized_in_dump(run):
    """Number literals dump as integers when integral, else %.6g."""
    source = "BEGIN { print 1.5e3, .5, 1., 1500000, 0.0000015 }"
    result = run(["-d", source])
    # CATCHES: the AST re-prints numeric values rather than echoing source
    # text, so 1.5e3 becomes 1500, .5 becomes 0.5 and 1. becomes 1.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n    print 1500, 0.5, 1, 1500000, 1.5e-06\n}\n")


def test_number_then_name_is_concatenation(run):
    """'1e' and '0x10' lex as a number concatenated with a name."""
    result = run(["-d", "BEGIN { x = 1e; y = 0x10 }"])
    # CATCHES: per awk/gawk behaviour a trailing 'e' is not an exponent, so
    # '1e' is 1 concatenated with e and '0x10' is 0 concatenated with x10.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    x = 1 e\n    y = 0 x10\n}\n"


def test_print_with_parenthesized_args_splices_the_commas(run):
    """print (a, b) prints two args, not one grouped expression."""
    result = run(["-d", "BEGIN { print (1, 2) }"])
    # CATCHES: parens around all print args are unwrapped to a plain
    # argument list, which is why the dump shows no parentheses.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    print 1, 2\n}\n"


def test_print_redirect_destination_spacing_is_odd(run):
    """Redirect operators dump with no space before the destination."""
    result = run(["-d", 'BEGIN { print "a" > "f" > "g"; print | "cat" }'])
    # CATCHES: the AST printer writes '>"f"' with no space but ' > "g"'
    # with spaces for the nested comparison, an exact formatting quirk.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n    print \"a\" >\"f\" > \"g\"\n    print  |\"cat\"\n}\n")


def test_multidimensional_in_expression_parses(run):
    """(i, j) in a is the multi-dimensional membership test."""
    result = run(["-d", "BEGIN { print (1, 2) in a }"])
    # CATCHES: the parenthesised comma list followed by 'in' is an InExpr
    # whose index list is dumped re-parenthesised.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    print (1, 2) in a\n}\n"


def test_getline_target_and_file_forms(run):
    """getline into a variable, a field or an array index all parse."""
    result = run(["-d", "BEGIN { getline; getline x; getline $1; getline a[1] }"])
    # CATCHES: bare getline dumps with no target and the others keep their
    # target expression, one statement each.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n    getline\n    getline x\n    getline $1\n    getline a[1]\n}\n")


def test_single_quoted_string_parses(run):
    """GoAWK accepts single-quoted strings as an extension."""
    result = run(["-d", "BEGIN { print 'single' }"])
    # CATCHES: the single-quoted string is accepted and re-printed with
    # double quotes in the dump.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    print \"single\"\n}\n"


def test_valid_program_runs_and_prints_its_output(run):
    """A valid program executes, writing its output to stdout."""
    result = run(['BEGIN { print "ran"; printf "%d", 42 }'])
    # CATCHES: acceptance is also observable without -d: the program really
    # executes (print and printf both write to stdout) and exits 0, unlike
    # the -d/-da paths or any of the error paths which print nothing.
    assert (result.returncode, result.out, result.err) == (
        0, "ran\n42", "")


def test_comment_only_and_empty_programs_parse(run, write):
    """Empty and comment-only sources are valid programs."""
    write("empty.awk", "")
    empty = run(["-d", "-f", "empty.awk"])
    # CATCHES: an empty program dumps as a single blank line (Program
    # String() is empty but the dump adds one newline).
    assert (empty.returncode, empty.err) == (0, "")
    assert empty.out == "\n"

    write("cmt.awk", "# just a comment\n")
    cmt = run(["-d", "-f", "cmt.awk"])
    # CATCHES: a comment-only program is also empty, dumping one newline.
    assert (cmt.returncode, cmt.err) == (0, "")
    assert cmt.out == "\n"


def test_semicolons_and_newlines_both_separate_items(run):
    """Items can be separated by ';' or newlines, and blocks need none."""
    result = run(["-d", 'BEGIN { print 1 }; BEGIN { print 2 }\n{ print 3 }'])
    # CATCHES: two BEGIN sections both dump, joined by a blank line, and a
    # following action needs no separator after the closing brace.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n    print 1\n}\n\nBEGIN {\n    print 2\n}\n\n{\n    print 3\n}\n")


def test_named_field_expression_parses(run):
    """@expr is GoAWK's named-field syntax and dumps with the @ prefix."""
    result = run(["-d", 'BEGIN { x = @"name"; print @"n" }'])
    # CATCHES: the @ token starts a NamedFieldExpr whose dump keeps the '@'
    # and re-quotes the constant field name with double quotes.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        'BEGIN {\n    x = @"name"\n    print @"n"\n}\n')


def test_control_flow_statements_dump(run):
    """break, continue, exit, next and nextfile all parse and dump."""
    result = run(["-d",
                  "BEGIN { while (1) { break }; for (i = 0; i < 3; i++) "
                  "{ continue }; exit }\n"
                  "{ if ($1) next; nextfile }"])
    # CATCHES: break and continue print as bare keywords inside their loop
    # bodies, a bare exit prints with no status expression, and next and
    # nextfile are allowed in a main action (outside BEGIN/END).
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n"
        "    while (1) {\n"
        "        break\n"
        "    }\n"
        "    for (i = 0; i < 3; i++) {\n"
        "        continue\n"
        "    }\n"
        "    exit\n"
        "}\n"
        "\n"
        "{\n"
        "    if ($1) {\n"
        "        next\n"
        "    }\n"
        "    nextfile\n"
        "}\n")


def test_delete_whole_array_block_stmt_and_chained_assign(run):
    """delete without index, a bare block statement and x = y = 1 parse."""
    result = run(["-d",
                  'BEGIN { delete a; delete b[1]; { print "block" }; '
                  "x = y = 1 }"])
    # CATCHES: 'delete a' (whole array) dumps without brackets, a '{ ... }'
    # block used as a statement keeps its braces indented one level, and
    # chained assignment nests right-associated.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n"
        "    delete a\n"
        "    delete b[1]\n"
        "    {\n"
        '        print "block"\n'
        "    }\n"
        "    x = y = 1\n"
        "}\n")


def test_regex_with_escaped_newline_spans_lines(run, write):
    """A backslash-newline inside a regex lets it continue on the next line."""
    write("mlre.awk", "BEGIN { x = /a\\\nb/ }")
    result = run(["-d", "-f", "mlre.awk"])
    # CATCHES: the escaped newline is consumed by the regex scanner so the
    # regex spans two source lines, and the dump re-indents the embedded
    # newline's continuation line by four spaces.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    x = /a\\\n    b/\n}\n"


def test_string_escapes_are_decoded_in_dump(run):
    """Escape sequences are decoded; the dump re-escapes specials."""
    result = run(["-d", 'BEGIN { print "\\t\\r\\a\\b\\f\\v", "\\x41", '
                 '"\\101", "é", "\\z", "\\x4e9" }'])
    # CATCHES: \\x and octal escapes decode to their byte values (A), an
    # unknown escape like \\z is just the character, \\x stops after two
    # hex digits so "\\x4e9" is N + literal 9, and the dump re-escapes
    # control characters like \\t back to their two-character form.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        'BEGIN {\n'
        '    print "\\t\\r\\a\\b\\f\\v", "A", "A", "é", "z", "N9"\n'
        '}\n')


def test_signed_exponents_normalize_in_dump(run):
    """Numbers with signed exponents and E normalize to plain values."""
    result = run(["-d", "BEGIN { print 1e+2, 1e-2, 1E3 }"])
    # CATCHES: '+'/'-' signs and capital E in exponents are all accepted
    # and the dump prints the computed value (100, 0.01, 1000) rather than
    # the source spelling.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    print 100, 0.01, 1000\n}\n"


def test_trailing_e_with_sign_is_not_exponent(run):
    """'1e + 2' lexes as 1 concatenated with e, plus 2."""
    result = run(["-d", "BEGIN { print 1e + 2 }"])
    # CATCHES: after '1e' the lexer unreads both the 'e' and the '+' when
    # no digit follows, so the expression is (1 e) + 2, dumped exactly so.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    print 1 e + 2\n}\n"


def test_gte_and_not_equals_operators_dump(run):
    """The >= and != operators round-trip through the AST dump."""
    result = run(["-d", "BEGIN { print 1 >= 2, 1 != 2 }"])
    # CATCHES: '>=' prints as '>=' (not '=>' or '≥') and '!=' keeps its
    # bang-equals spelling in the dumped expression.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    print 1 >= 2, 1 != 2\n}\n"


def test_regex_after_div_and_regex_with_escaped_slash(run):
    """/=/ starts a regex even though /= could lex as an assignment."""
    result = run(["-d", 'BEGIN { x = /a\\/b/; print "a" ~ /=/ }'])
    # CATCHES: a regex literal beginning with '=' is reassembled after the
    # lexer's '/=' token, and an escaped slash inside a regex keeps its
    # backslash in the dump.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        'BEGIN {\n    x = /a\\/b/\n    print "a" ~ /=/\n}\n')


def test_for_with_empty_body_and_lone_semicolon(run):
    """A ';' right after a for header is an empty statement, not an error."""
    result = run(["-d", 'BEGIN { for (i = 0; i < 3; i++); print "x" }'])
    # CATCHES: the semicolon after the for header is consumed as a null
    # statement so the for gets an empty block and print follows it.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        'BEGIN {\n    for (i = 0; i < 3; i++) {\n    }\n    print "x"\n}\n')

    result = run(["-d", "BEGIN { ; print 1 }"])
    # CATCHES: a lone semicolon inside a block is skipped entirely, so the
    # dump shows only the print statement.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    print 1\n}\n"


def test_assignment_on_right_of_logical_operator(run):
    """'a && b = 1' parses as a && (b = 1) and dumps the grouping."""
    result = run(["-d", "BEGIN { a && b = 1 }"])
    # CATCHES: the parser folds the assignment into the right operand of
    # && and the dump keeps explicit parentheses around 'b = 1'.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    a && (b = 1)\n}\n"


def test_recursive_and_shared_call_graph_runs(run):
    """Recursion and functions called from several places resolve fine."""
    source = ("function fib(n) { return n < 2 ? n : fib(n-1) + fib(n-2) }\n"
              "function h() { }\n"
              "function u() { h() }\n"
              "function v() { h() }\n"
              "BEGIN { print fib(10); u(); v() }")
    result = run([source])
    # CATCHES: a call graph with recursion (fib) and a shared callee (h
    # called from both u and v) topologically sorts and resolves without
    # any diagnostic, and the program runs to produce fib(10) = 55.
    assert (result.returncode, result.out, result.err) == (0, "55\n", "")


def test_unicode_and_uppercase_hex_escapes_decode(run):
    r"""\\uXXXX escapes decode to UTF-8 runes and \\xAB to a raw byte."""
    result = run(["-d", r'BEGIN { print "\u00e9", "\u00E9", "\xAB" }'])
    # CATCHES: both \u00e9 and \u00E9 (uppercase hex digit) decode to the
    # two-byte é, while \xAB is a non-printable byte that the dumper
    # quotes back as lowercase \xab.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n"
        '    print "é", "é", "\\xab"\n'
        "}\n")


def test_precedence_parens_appear_in_dump(run):
    """Lower-precedence subexpressions get re-parenthesized in the dump."""
    source = ("function f(p, q) { return p }\n"
              "BEGIN {\n"
              "  print !(a && b), !(a || b)\n"
              '  x = /re/ "s"\n'
              '  z = -length("ab")\n'
              "  n = (getline line) + 0\n"
              "  w = -f(1, 2)\n"
              "  print f(1, 2)\n"
              "  y = $(arr[1])\n"
              "}")
    result = run(["-d", source])
    # CATCHES: the printer re-adds parens around && and || under !, around
    # 'getline line' under +, and around arr[1] under $, while the calls
    # in -length("ab") and -f(1, 2) bind tightly enough to stay bare.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "BEGIN {\n"
        "    print !(a && b), !(a || b)\n"
        '    x = /re/ "s"\n'
        '    z = -length("ab")\n'
        "    n = (getline line) + 0\n"
        "    w = -f(1, 2)\n"
        "    print f(1, 2)\n"
        "    y = $(arr[1])\n"
        "}\n"
        "\n"
        "function f(p, q) {\n"
        "    return p\n"
        "}\n")


def test_command_getline_expression_dumps_with_pipe(run):
    """'cmd | getline' used as an expression dumps as 'cmd |getline'."""
    result = run(["-d", 'BEGIN { x = "cat" | getline }'])
    # CATCHES: the AST printer renders a command-piped getline with the
    # pipe glued to the keyword: 'x = "cat" |getline' with no space
    # between the command string and the pipe.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == 'BEGIN {\n    x = "cat" |getline\n}\n'


def test_arguments_may_span_lines_after_comma(run, write):
    """A newline right after a comma is allowed between print arguments."""
    write("args.awk", "BEGIN {\n  print 1,\n      2\n}")
    result = run(["-d", "-f", "args.awk"])
    # CATCHES: the parser skips newlines after the comma separating print
    # arguments (commaNewlines), so the statement continues on the next
    # line and the dump collapses it to a single 'print 1, 2'.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "BEGIN {\n    print 1, 2\n}\n"
