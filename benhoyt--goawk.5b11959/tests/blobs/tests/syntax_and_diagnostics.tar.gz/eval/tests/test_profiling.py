"""The -cpuprofile and -memprofile flags: pprof profile file output.

Both flags run the program normally and write a gzip-compressed pprof
profile (the file starts with the two gzip magic bytes 0x1f 0x8b). The
CPU profile is created before execution starts; the memory profile is
only created after the program has finished. Every expectation below was
recorded from the reference binary.
"""

import pytest

# A program that does a little arithmetic so the profiler has work to do.
WORK_PROG = "BEGIN { s = 0; for (i = 0; i < 1000; i++) s += i; print s }"


def test_cpuprofile_writes_profile_while_program_runs(run, tmp_path):
    """-cpuprofile runs the program normally and writes a pprof file."""
    result = run(["-cpuprofile", "cpu.out", WORK_PROG])
    # CATCHES: profiling does not change the program's own output or exit
    # status, and the profile is a gzip stream (0x1f 0x8b magic) with real
    # content rather than an empty file.
    assert (result.returncode, result.out, result.err) == (0, "499500\n", "")
    profile = (tmp_path / "cpu.out").read_bytes()
    assert profile[:2] == b"\x1f\x8b"
    assert len(profile) > 100


def test_memprofile_writes_profile_after_program_runs(run, tmp_path):
    """-memprofile also leaves a non-empty gzip profile behind."""
    result = run(["-memprofile", "mem.out", WORK_PROG])
    # CATCHES: the heap profile is written after execution but the file is
    # still a valid gzip pprof stream, and the program output is unchanged.
    assert (result.returncode, result.out, result.err) == (0, "499500\n", "")
    profile = (tmp_path / "mem.out").read_bytes()
    assert profile[:2] == b"\x1f\x8b"
    assert len(profile) > 100


def test_cpuprofile_bad_path_errors_before_running(run):
    """A -cpuprofile path that cannot be created aborts before execution."""
    result = run(["-cpuprofile", "no/such/dir/cpu.out",
                  'BEGIN { print "hi" }'])
    # CATCHES: the CPU profile file is created up front, so the program
    # never runs (stdout stays empty) and the failure names the path.
    assert (result.returncode, result.out, result.err) == (
        1, "",
        "could not create CPU profile: open no/such/dir/cpu.out:"
        " no such file or directory\n")


def test_memprofile_bad_path_errors_after_running(run):
    """A -memprofile path that cannot be created aborts after execution."""
    result = run(["-memprofile", "no/such/dir/mem.out",
                  'BEGIN { print "hi" }'])
    # CATCHES: the memory profile is only created once the program has
    # finished, so the program's stdout appears before the error, and the
    # process exits 1 without writing anything else.
    assert (result.returncode, result.out, result.err) == (
        1, "hi\n",
        "could not create memory profile: open no/such/dir/mem.out:"
        " no such file or directory\n")


def test_cpuprofile_and_memprofile_together(run, tmp_path):
    """Both profile flags can be used in the same invocation."""
    result = run(["-cpuprofile", "cpu.out", "-memprofile", "mem.out",
                  'BEGIN { print "both" }'])
    # CATCHES: both files are created for one run: the CPU profile while
    # starting up and the memory profile at shutdown, each a gzip stream.
    assert (result.returncode, result.out, result.err) == (0, "both\n", "")
    for name in ("cpu.out", "mem.out"):
        profile = (tmp_path / name).read_bytes()
        assert profile[:2] == b"\x1f\x8b"
        assert len(profile) > 100


def test_cpuprofile_equals_form(run, tmp_path):
    """-cpuprofile=FILE works like the two-argument form."""
    result = run(["-cpuprofile=cpu.out", 'BEGIN { print "eq" }'])
    # CATCHES: the =-attached spelling is accepted and writes the same
    # kind of gzip profile file as the separate-argument form.
    assert (result.returncode, result.out, result.err) == (0, "eq\n", "")
    profile = (tmp_path / "cpu.out").read_bytes()
    assert profile[:2] == b"\x1f\x8b"
    assert len(profile) > 100


@pytest.mark.parametrize("flag", ["-cpuprofile", "-memprofile"])
def test_profile_flags_require_an_argument(run, flag):
    """A trailing -cpuprofile/-memprofile with no value is a usage error."""
    result = run([flag])
    # CATCHES: the flag parser reports the missing argument by flag name
    # and exits 1 before any program is read or run.
    assert (result.returncode, result.out, result.err) == (
        1, "", "flag needs an argument: %s\n" % flag)
