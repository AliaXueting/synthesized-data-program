"""Name resolution and type inference, observed via -dt and clean runs.

The resolver assigns every variable a scope and a scalar/array type and
propagates types through function call chains until they reach a fixpoint;
``-dt`` prints the result. Functions are indexed in source definition
order even when the call graph is cyclic, and displayed alphabetically.
Every expectation below was recorded from the reference binary.
"""


def test_type_inference_propagates_array_through_call_chain(run):
    """An array passed along a chain of calls types every link as array."""
    result = run(["-dt",
                  "function f(a) { a[1] = 1 } function g(b) { f(b) } "
                  "BEGIN { g(c) }"])
    # CATCHES: the global c and both parameters a and b are all inferred
    # to be arrays even though only f's body uses its parameter as one;
    # the global gets index 3 (after the builtin arrays) while each
    # function's parameters have their own index space starting at 0.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "  c: array 3\n"
        "function f(a)  # index 0\n"
        "  a: array 0\n"
        "function g(b)  # index 1\n"
        "  b: array 0\n")


def test_length_of_variable_records_it_as_scalar(run):
    """length(x) alone leaves x typed as a scalar global."""
    result = run(["-dt", "BEGIN { print length(x) }"])
    # CATCHES: length's argument may be scalar or array, so the resolver
    # defers; with no other use, x ends up a scalar global with index 0.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "  x: scalar 0\n")


def test_length_of_literal_records_no_variable(run):
    """length(\"hello\") registers no variable at all."""
    result = run(["-dt", 'BEGIN { print length("hello") }'])
    # CATCHES: a non-variable argument to length is simply walked as an
    # expression, so the globals list keeps only the three builtin arrays.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n")


def test_function_indexes_follow_source_order(run):
    """Function indexes come from definition order, display is alphabetical."""
    result = run(["-dt",
                  "function fib(n) { return n < 2 ? n : fib(n-1) + fib(n-2) }\n"
                  "function h() { }\n"
                  "function u() { h() }\n"
                  "function v() { h() }\n"
                  "BEGIN { print fib(10); u(); v() }"])
    # CATCHES: -dt lists functions alphabetically but their '# index N'
    # numbers follow source definition order (fib 0, h 1, u 2, v 3),
    # regardless of who calls whom, and each has its own parameter
    # numbering (only fib has the parameter n).
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "function fib(n)  # index 0\n"
        "  n: scalar 0\n"
        "function h()  # index 1\n"
        "function u()  # index 2\n"
        "function v()  # index 3\n")


def test_mutually_recursive_functions_resolve(run):
    """Mutual recursion is resolved and indexes stay in source order."""
    result = run(["-dt",
                  "function isodd(n) { return n == 0 ? 0 : iseven(n-1) }\n"
                  "function iseven(n) { return n == 0 ? 1 : isodd(n-1) }\n"
                  "BEGIN { print iseven(10), isodd(10) }"])
    # CATCHES: the call graph cycle (isodd -> iseven -> isodd) is handled
    # without a diagnostic; isodd keeps index 0 and iseven index 1 from
    # source order even though the display sorts iseven first.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "globals\n"
        "  ARGV: array 0\n"
        "  ENVIRON: array 1\n"
        "  FIELDS: array 2\n"
        "function iseven(n)  # index 1\n"
        "  n: scalar 0\n"
        "function isodd(n)  # index 0\n"
        "  n: scalar 0\n")
