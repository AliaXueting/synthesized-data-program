"""The -v flag's escape interpretation (lexer.Unescape), observed via CLI.

POSIX requires ``-v name=value`` to interpret backslash escapes in value
the same way string literals do. GoAWK applies the string unescaper to
each -v value; when the value is not a valid escaped string the raw value
is kept instead. Every expectation below was recorded from the reference
binary.
"""


def test_v_flag_unescapes_tab(run):
    """-v interprets \\t and friends like a string literal would."""
    result = run(["-v", "t=a\\tb", "BEGIN { print t }"])
    # CATCHES: the -v value goes through the lexer's unescaper, so the
    # program sees a real tab character between the a and the b.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "a\tb\n"


def test_v_flag_keeps_value_on_bad_escape(run):
    """An invalid escape in -v leaves the raw value untouched."""
    result = run(["-v", "x=a\\x", "BEGIN { print x }"])
    # CATCHES: '\\x' with no hex digits fails to unescape, and the failure
    # is silent: the variable just keeps the literal backslash-x text.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "a\\x\n"


def test_v_flag_unknown_escape_is_the_character(run):
    """An unrecognized escape like \\q unescapes to just the character."""
    result = run(["-v", "z=a\\q", "BEGIN { print z }"])
    # CATCHES: per AWK string rules any escaped character that has no
    # special meaning collapses to the character itself, so a\\q yields
    # 'aq' with no backslash.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "aq\n"
