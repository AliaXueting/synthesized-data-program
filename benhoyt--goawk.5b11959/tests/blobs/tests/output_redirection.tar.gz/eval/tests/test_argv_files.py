"""Iteration over input files named on the command line (the ARGV-walking
part of nextLine in io.go): NR/FNR/FILENAME across multiple files, var=value
argument assignments, the special "-" and empty-string arguments, missing
files, and what -E changes about argument handling."""


def test_multiple_files_update_nr_fnr_filename(goawk, tmp_path):
    """Records from file arguments keep NR running and reset FNR/FILENAME."""
    # CATCHES: after f1.txt is exhausted its stream is closed, f2.txt is
    # opened, NR continues at 3 while FNR restarts at 1.
    (tmp_path / "f1.txt").write_bytes(b"one\ntwo\n")
    (tmp_path / "f2.txt").write_bytes(b"three\n")
    result = goawk(['{ print NR ":" FNR ":" FILENAME ":" $0 }', 'f1.txt', 'f2.txt'])
    assert result.returncode == 0
    assert result.stdout == b"1:1:f1.txt:one\n2:2:f1.txt:two\n3:1:f2.txt:three\n"
    assert result.stderr == b""


def test_stdin_is_used_when_a_file_arg_was_given(goawk, tmp_path):
    """After file args are exhausted, stdin is not read."""
    # CATCHES: hadFiles is true once a real file was seen, so the pending
    # stdin data must be ignored rather than read as a fourth record.
    (tmp_path / "f1.txt").write_bytes(b"one\ntwo\n")
    result = goawk(
        ['{ print NR ":" $0 } END { print NR }', 'f1.txt'], stdin=b"stdin-data\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"1:one\n2:two\n2\n"
    assert result.stderr == b""


def test_var_assignment_argument_sets_the_variable(goawk, tmp_path):
    """A name=value argument assigns the variable before records are read."""
    # CATCHES: the assignment is processed while walking ARGV, so it is
    # visible both in the main loop and in END.
    (tmp_path / "d.txt").write_bytes(b"r1\n")
    result = goawk(['{ print $0, y }', 'y=7', 'd.txt'])
    assert result.returncode == 0
    assert result.stdout == b"r1 7\n"
    assert result.stderr == b""


def test_var_assignment_argument_before_stdin(goawk):
    """var=value args are processed even when input then comes from stdin."""
    # CATCHES: ARGV is walked before falling back to stdin, so x is set
    # before the first record is read.
    result = goawk(['{ print NR, x }', 'x=5'], stdin=b"1\n2\n")
    assert result.returncode == 0
    assert result.stdout == b"1 5\n2 5\n"
    assert result.stderr == b""


def test_var_assignment_argument_interprets_escapes(goawk):
    """Escape sequences in var=value arguments are interpreted."""
    # CATCHES: like -v, a literal backslash-t in the argument becomes a
    # real TAB and \101 becomes "A".
    result = goawk(['END { print x }', 'x=a\tb'])
    assert result.returncode == 0
    assert result.stdout == b"a\tb\n"
    assert result.stderr == b""


def test_var_assignment_argument_octal_escape(goawk):
    """Octal escapes in var=value arguments are interpreted too."""
    # CATCHES: \101 must decode to "A", pinning the shared unescape rules.
    result = goawk(['END { print x }', 'x=q\\101r'])
    assert result.returncode == 0
    assert result.stdout == b"qAr\n"
    assert result.stderr == b""


def test_var_assignment_argument_counts_in_argc(goawk):
    """A var=value argument is an ARGV entry and bumps ARGC."""
    # CATCHES: ARGC includes the assignment argument itself.
    result = goawk(['BEGIN { print ARGC }', 'x=42'])
    assert result.returncode == 0
    assert result.stdout == b"2\n"
    assert result.stderr == b""


def test_empty_string_argument_is_skipped(goawk):
    """An empty ARGV argument is skipped and stdin is still used."""
    # CATCHES: "" is not a file, but skipping it does not set hadFiles, so
    # the program falls back to reading stdin ("hi" is still printed).
    result = goawk(['{ print }', ''], stdin=b"hi\n")
    assert result.returncode == 0
    assert result.stdout == b"hi\n"
    assert result.stderr == b""


def test_dash_argument_reads_stdin(goawk):
    """A "-" argument means stdin, with FILENAME "-"."""
    # CATCHES: "-" must be read as stdin (not a file named "-") and FILENAME
    # reports the dash.
    result = goawk(['{ print FILENAME ":" $0 }', '-'], stdin=b"hi\n")
    assert result.returncode == 0
    assert result.stdout == b"-:hi\n"
    assert result.stderr == b""


def test_two_dash_arguments_read_stdin_twice(goawk):
    """Each "-" argument re-reads stdin as a separate input."""
    # CATCHES: both "-" entries open the (same) stdin, reading records "a"
    # and "b" from one stream of input.
    result = goawk(['{ print NR $0 }', '-', '-'], stdin=b"a\nb\n")
    assert result.returncode == 0
    assert result.stdout == b"1a\n2b\n"
    assert result.stderr == b""


def test_file_argument_then_dash_reads_stdin_after_the_file(goawk, tmp_path):
    """A "-" after a real file argument reads stdin as the next input."""
    # CATCHES: NR keeps counting across the switch from file to stdin and
    # FILENAME switches from the file name to "-".
    (tmp_path / "f1.txt").write_bytes(b"one\ntwo\n")
    result = goawk(
        ['{ print NR ":" FILENAME ":" $0 }', 'f1.txt', '-'], stdin=b"stdin-data\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"1:f1.txt:one\n2:f1.txt:two\n3:-:stdin-data\n"
    assert result.stderr == b""


def test_missing_file_argument_is_an_error(goawk):
    """A nonexistent file argument exits 1 with 'file ... not found'."""
    # CATCHES: the open failure is reported with the file-not-found wording
    # and the exit status is 1.
    result = goawk(['{ print }', 'nope.txt'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b'file "nope.txt" not found\n'


def test_dash_e_disables_var_assignment_arguments(goawk, tmp_path):
    """With -E, a name=value argument is treated as a file name."""
    # CATCHES: -E turns off var=value processing, so "x=42" is opened as a
    # file and fails with the not-found error.
    (tmp_path / "p.awk").write_bytes(b'END { print x }')
    result = goawk(['-E', 'p.awk', 'x=42'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b'file "x=42" not found\n'


def test_non_variable_argument_is_a_filename(goawk):
    """An argument without a valid var= form is treated as a file."""
    # CATCHES: "not a var=thing" does not match the var pattern (the name
    # has spaces), so it is opened as a file and reported missing.
    result = goawk(['END { print 1 }', 'not a var=thing'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b'file "not a var=thing" not found\n'
