"""Output ordering and stream synchronisation: stdout buffering, where errors
land, and how program output interleaves with piped command output."""

import os

import pytest


def require_dev_full():
    """Skip tests that need /dev/full when it is not present."""
    if not os.path.exists("/dev/full"):
        pytest.skip("/dev/full is not available in this environment")


def test_output_before_a_runtime_error_is_still_written(goawk):
    """Buffered stdout written before a fatal error is flushed on the way out."""
    # CATCHES: stdout is buffered when it is not a terminal, so the two
    # records must still appear (in order) even though printf then fails.
    result = goawk(['BEGIN { print "line1"; print "line2"; printf "%y", 1 }'])
    assert result.returncode == 1
    assert result.stdout == b"line1\nline2\n"
    assert result.stderr == b"format error: invalid format type 'y'\n"


def test_runtime_errors_go_to_stderr_not_stdout(goawk):
    """A failing print redirection reports on stderr and prints nothing."""
    # CATCHES: the error message must not leak into stdout.
    result = goawk(['BEGIN { print "x" > "/nonexistent-dir-xyz/f.txt" }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b"output redirection error: open /nonexistent-dir-xyz/f.txt:"
        b" no such file or directory\n"
    )


def test_stdout_error_message_is_flushed_after_pending_stdout(goawk):
    """An fflush error is printed after the stdout that precedes it."""
    # CATCHES: error output flushes stdout first, so a merged capture shows
    # "before", then the error, then the fflush return value and "after".
    result = goawk(
        ['BEGIN { print "before"; print "fflush:", fflush("zzz"); print "after" }'],
        merge_stderr=True,
    )
    assert result.returncode == 0
    assert result.stdout == (
        b'before\n'
        b'error flushing "zzz": not an output file or pipe\n'
        b"fflush: -1\n"
        b"after\n"
    )


def test_dev_stderr_writes_interleave_in_program_order(goawk):
    """Each /dev/stderr write flushes stdout first, keeping output ordered."""
    # CATCHES: /dev/stderr is not a registered stream, so every print to it
    # re-syncs stdout; the merged order is out1, err1, out2, err2.
    result = goawk(
        [
            "BEGIN { print \"out1\"; print \"err1\" > \"/dev/stderr\"; "
            "print \"out2\"; print \"err2\" > \"/dev/stderr\" }",
        ],
        merge_stderr=True,
    )
    assert result.returncode == 0
    assert result.stdout == b"out1\nerr1\nout2\nerr2\n"


def test_dev_stdout_writes_stay_in_stdout_order(goawk):
    """Prints to /dev/stdout merge with normal prints in program order."""
    # CATCHES: /dev/stdout writes must not be reordered ahead of buffered
    # stdout content.
    result = goawk(
        ['BEGIN { print "out1"; print "ds1" > "/dev/stdout"; print "out2" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"out1\nds1\nout2\n"
    assert result.stderr == b""


def test_program_stdout_precedes_piped_command_output(goawk):
    """A pipe left open until exit delivers its output after later prints."""
    # CATCHES: the pipe is only flushed at program exit, so the "main" line
    # printed afterwards is written first.
    result = goawk(
        ['BEGIN { print "p1" | "cat"; print "p2" | "cat"; print "main" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"main\np1\np2\n"
    assert result.stderr == b""


def test_closed_pipe_output_precedes_the_close_return_value(goawk):
    """close() waits for the command, so its output is already in place."""
    # CATCHES: the command's output must appear before the value that close()
    # returns, which is printed after close() returns.
    result = goawk(['BEGIN { print "x" | "cat"; print "code:", close("cat") }'])
    assert result.returncode == 0
    assert result.stdout == b"x\ncode: 0\n"
    assert result.stderr == b""


def test_stdout_write_error_at_exit_fails_the_program(goawk):
    """A stdout write error discovered at exit gives status 1 and a message."""
    # CATCHES: the final flush of stdout is checked, so pointing stdout at a
    # full device fails the program instead of exiting silently.
    require_dev_full()
    result = goawk(['BEGIN { print "x" }'], stdout_path="/dev/full")
    assert result.returncode == 1
    assert b"no space left on device" in result.stderr


def test_records_reach_several_files_independently(goawk, tmp_path):
    """Writes to two files interleave without affecting either file's order."""
    # CATCHES: each named stream keeps its own buffer, so alternating writes
    # cannot mix the two files' contents.
    result = goawk(
        [
            'BEGIN { for (i = 1; i <= 5; i++) { '
            'print "left" i > "left.txt"; print "right" i > "right.txt" } }',
        ]
    )
    assert result.returncode == 0
    assert (tmp_path / "left.txt").read_bytes() == (
        b"left1\nleft2\nleft3\nleft4\nleft5\n"
    )
    assert (tmp_path / "right.txt").read_bytes() == (
        b"right1\nright2\nright3\nright4\nright5\n"
    )


def test_exit_status_is_zero_after_a_clean_run_with_redirects(goawk, tmp_path):
    """A program that only writes to files exits 0 with empty stdout."""
    # CATCHES: redirected writes must not be echoed to stdout nor affect the
    # exit status.
    result = goawk(
        ['BEGIN { print "a" > "f.txt"; printf "b\\n" > "f.txt"; print "c" | "cat" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"c\n"
    assert result.stderr == b""
    assert (tmp_path / "f.txt").read_bytes() == b"a\nb\n"
