"""``print`` statement behaviour: separators, record terminator, number
formatting on the way out (OFS/ORS/OFMT/CONVFMT)."""


def test_print_without_arguments_writes_record_and_ors(goawk):
    """Bare ``print`` writes $0 verbatim followed by ORS."""
    # CATCHES: a re-implementation that re-joins fields with OFS instead of
    # emitting the raw record would corrupt records containing separators.
    result = goawk(["{ print }"], stdin=b"a b\nc d\n")
    assert result.returncode == 0
    assert result.stdout == b"a b\nc d\n"
    assert result.stderr == b""


def test_print_without_arguments_in_begin_prints_empty_record(goawk):
    """In BEGIN $0 is the empty string, so bare ``print`` emits only ORS."""
    # CATCHES: printing an empty record must still emit the record separator.
    result = goawk(["BEGIN { print }"])
    assert result.returncode == 0
    assert result.stdout == b"\n"
    assert result.stderr == b""


def test_print_arguments_joined_with_default_ofs(goawk):
    """``print a, b, c`` joins with OFS (space) and ends with ORS."""
    # CATCHES: default OFS is a single space, not a tab or empty string.
    result = goawk(['BEGIN { print "a", "b", "c" }'])
    assert result.returncode == 0
    assert result.stdout == b"a b c\n"
    assert result.stderr == b""


def test_print_single_argument_is_not_ofs_separated(goawk):
    """A single argument is emitted alone; OFS only separates arguments."""
    # CATCHES: an implementation that appends OFS around every argument.
    result = goawk(["BEGIN { OFS = \"::\"; print 1 }"])
    assert result.returncode == 0
    assert result.stdout == b"1\n"
    assert result.stderr == b""


def test_print_prints_dollar0_as_single_field(goawk):
    """``print $0`` is one argument, so changing OFS has no effect on it."""
    # CATCHES: print $0 must not re-join the fields with the current OFS.
    result = goawk(["{ if (NR == 1) OFS = \"+\"; print $0 }"], stdin=b"x\ny\n")
    assert result.returncode == 0
    assert result.stdout == b"x\ny\n"
    assert result.stderr == b""


def test_ofs_and_ors_changes_take_effect_mid_stream(goawk):
    """Assigning OFS/ORS between records affects the very next print."""
    # CATCHES: separators must be re-read per print, not cached at startup.
    result = goawk(
        ['{ if (NR == 2) { OFS = "-"; ORS = "|\\n" } print $1, $2 }'],
        stdin=b"1 2\n3 4\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1 2\n3-4|\n"
    assert result.stderr == b""


def test_ors_change_only_affects_record_terminator(goawk):
    """Changing ORS mid-stream changes only the terminator, not the body."""
    # CATCHES: ORS is appended per record, so a mid-program change applies
    # only to records printed afterwards.
    result = goawk(['{ if (NR == 2) ORS = "!"; print }'], stdin=b"x\ny\n")
    assert result.returncode == 0
    assert result.stdout == b"x\ny!"
    assert result.stderr == b""


def test_empty_ors_concatenates_records(goawk):
    """ORS = "" makes successive records run together with no terminator."""
    # CATCHES: the record separator must be honoured even when empty.
    result = goawk(['BEGIN { ORS = ""; print "a"; print "b" }'])
    assert result.returncode == 0
    assert result.stdout == b"ab"
    assert result.stderr == b""


def test_multicharacter_ofs_and_ors(goawk):
    """OFS and ORS may be arbitrary multi-character strings."""
    # CATCHES: separators longer than one byte must be emitted verbatim.
    result = goawk(['BEGIN { OFS = "::"; ORS = "<->"; print 1, 2, 3 }'])
    assert result.returncode == 0
    assert result.stdout == b"1::2::3<->"
    assert result.stderr == b""


def test_print_empty_string_argument_still_gets_ors(goawk):
    """``print ""`` writes nothing but still terminates the record."""
    # CATCHES: an empty argument is a field, distinct from no arguments.
    result = goawk(['BEGIN { print "" }'])
    assert result.returncode == 0
    assert result.stdout == b"\n"
    assert result.stderr == b""


def test_print_concatenated_arguments_form_one_field(goawk):
    """Adjacent expressions are one argument, so OFS does not separate them."""
    # CATCHES: ``print "a" "b", "c"`` must print "ab-c", not "a-b-c".
    result = goawk(['BEGIN { OFS = "-"; print "a" "b", "c" }'])
    assert result.returncode == 0
    assert result.stdout == b"ab-c\n"
    assert result.stderr == b""


def test_print_numbers_use_default_ofmt(goawk):
    """Non-integer numbers print with OFMT, defaulting to %.6g."""
    # CATCHES: default numeric output format is %.6g and 0.1+0.2 prints as
    # "0.3" (shortest round-trip), not "0.300000".
    result = goawk(
        ["BEGIN { print 1/3; print 0.1 + 0.2; print 1e21; print 123456789012345678 }"]
    )
    assert result.returncode == 0
    assert result.stdout == b"0.333333\n0.3\n1e+21\n123456789012345680\n"
    assert result.stderr == b""


def test_print_ofmt_change_applies_to_non_integers_only(goawk):
    """OFMT affects non-integers; integral values print as integers."""
    # CATCHES: an OFMT of "%.2f" must not turn the integer 2 into "2.00".
    result = goawk(['BEGIN { OFMT = "%.2f"; print 1/3; print 2 }'])
    assert result.returncode == 0
    assert result.stdout == b"0.33\n2\n"
    assert result.stderr == b""


def test_print_ofmt_with_integer_conversion(goawk):
    """An OFMT such as "%d" converts the number through the format engine."""
    # CATCHES: OFMT = "%d" truncates 3.7 to 3 when printing.
    result = goawk(['BEGIN { OFMT = "%d"; print 3.7; print 2 }'])
    assert result.returncode == 0
    assert result.stdout == b"3\n2\n"
    assert result.stderr == b""


def test_print_invalid_ofmt_used_as_literal_string(goawk):
    """An OFMT that cannot be applied falls back to the literal format text."""
    # CATCHES: OFMT = "%d %d" prints the format itself rather than erroring.
    result = goawk(['BEGIN { OFMT = "%d %d"; print 1.5 }'])
    assert result.returncode == 0
    assert result.stdout == b"%d %d\n"
    assert result.stderr == b""


def test_print_strnum_field_keeps_input_string_form(goawk):
    """A numeric input field prints as read until arithmetic is applied."""
    # CATCHES: $1 from input "1.5" prints as "1.5" even after OFMT changes;
    # only $1+0 (a real number) is reformatted by OFMT.
    result = goawk(
        ['{ print $1; OFMT = "%.2f"; print $1 + 0 }'], stdin=b"1.5\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"1.5\n1.50\n"
    assert result.stderr == b""


def test_print_inf_and_nan_bypass_ofmt(goawk):
    """Infinity and NaN are formatted without reference to OFMT."""
    # CATCHES: OFMT = "%.2f" must not produce "inf" as "+inf" or "1.#J".
    result = goawk(
        ["BEGIN { print exp(1000), sqrt(-1); OFMT = \"%.2f\"; print exp(1000), sqrt(-1) }"]
    )
    assert result.returncode == 0
    assert result.stdout == b"inf nan\ninf nan\n"
    assert result.stderr == b""


def test_convfmt_with_integer_conversion(goawk):
    """CONVFMT may be an integer conversion; string coercion uses it."""
    # CATCHES: concatenating a number with "" applies CONVFMT, so
    # CONVFMT = "%d" yields "0" for 1/3.
    result = goawk(['BEGIN { CONVFMT = "%d"; print "" 1/3; x = 1/3; print x "" }'])
    assert result.returncode == 0
    assert result.stdout == b"0\n0\n"
    assert result.stderr == b""


def test_print_and_printf_interleave_in_program_order(goawk):
    """print and printf share the stdout stream and keep write order."""
    # CATCHES: printf output must not be flushed out of order relative to
    # neighbouring print statements.
    result = goawk(['BEGIN { print "a"; printf "b"; print "c" }'])
    assert result.returncode == 0
    assert result.stdout == b"a\nbc\n"
    assert result.stderr == b""
