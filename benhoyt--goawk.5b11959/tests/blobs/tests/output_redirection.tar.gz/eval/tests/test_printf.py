"""``printf``/``sprintf`` behaviour: conversions, flags, width, precision,
dynamic ``*`` arguments, ``%c`` modes, and format errors."""

import pytest


def test_printf_does_not_append_a_record_separator(goawk):
    """printf emits exactly the formatted string, with no ORS appended."""

    # CATCHES: an implementation that reuses the print path would add "\\n".
    result = goawk(['BEGIN { printf "abc" }'])
    assert result.returncode == 0
    assert result.stdout == b"abc"
    assert result.stderr == b""


def test_printf_embedded_newlines_are_written_verbatim(goawk):
    """Literal newlines in the format string are written as-is (LF)."""
    # CATCHES: default -N smart mode must not translate embedded newlines on
    # Linux, unlike -N crlf.
    result = goawk(['BEGIN { printf "a\\nb" }'])
    assert result.returncode == 0
    assert result.stdout == b"a\nb"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "format_string,args_source,expected",
    [
        ("%d", "42", b"42"),
        ("%i", "7", b"7"),
        ("%o", "8", b"10"),
        ("%x", "255", b"ff"),
        ("%X", "255", b"FF"),
        ("%u", "5", b"5"),
        ("%f", "1234.5678", b"1234.567800"),
        ("%e", "1234.5678", b"1.234568e+03"),
        ("%E", "1234.5678", b"1.234568E+03"),
        ("%g", "1234.5678", b"1234.57"),
        ("%G", "1234.5678", b"1234.57"),
        ("%.3f", "3.14159", b"3.142"),
        ("%.2e", "1234.5678", b"1.23e+03"),
        ("%.10g", "1234.5678", b"1234.5678"),
        ("%a", "1.0", b"0x1p+00"),
    ],
)
def test_printf_single_conversion(goawk, format_string, args_source, expected):
    """Each supported conversion produces the exact bytes of the reference."""
    # CATCHES: a single wrong conversion letter (e.g. Go's %g shortest
    # round-trip instead of C's 6 significant digits) changes these bytes.
    result = goawk(['BEGIN { printf "' + format_string + '", ' + args_source + " }"])
    assert result.returncode == 0
    assert result.stdout == expected
    assert result.stderr == b""


@pytest.mark.parametrize(
    "number,expected",
    [
        ("0.00001234", b"1.234e-05"),
        ("123456789", b"1.23457e+08"),
        ("0.5", b"0.5"),
        ("100000", b"100000"),
        ("1234.5678", b"1234.57"),
    ],
)
def test_printf_bare_g_uses_c_default_precision(goawk, number, expected):
    """A bare %g formats with 6 significant digits, like C/POSIX awk."""
    # CATCHES: Go's fmt %g default (shortest round-trip) would print
    # "1.234e-05" only by luck and "123456789" instead of "1.23457e+08".
    result = goawk(["BEGIN { printf \"%g\", " + number + " }"])
    assert result.returncode == 0
    assert result.stdout == expected
    assert result.stderr == b""


def test_printf_flag_characters(goawk):
    """The -, +, space, 0 and # flags combine with width and precision."""
    # CATCHES: each flag must reach the underlying formatter; a missing
    # space-flag would print "42" instead of " 42".
    result = goawk(
        [
            "BEGIN { printf \"[%d][%-5d][%5d][%05d][%+d][% d][%#x][%#o][%.3f][%8.3f]\","
            " 42, 42, 42, 42, 42, 42, 255, 8, 3.14159, 3.14159 }"
        ]
    )
    assert result.returncode == 0
    assert result.stdout == b"[42][42   ][   42][00042][+42][ 42][0xff][010][3.142][   3.142]"
    assert result.stderr == b""


def test_printf_string_width_and_precision(goawk):
    """Width and precision apply to %s, truncating and padding the string."""
    # CATCHES: precision on %s truncates ("abc" not "abcdef") and width pads
    # on the left by default.
    result = goawk(
        ['BEGIN { printf "[%10.3s][%.2s][%s]", "abcdef", "abcdef", "abcdef" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"[       abc][ab][abcdef]"
    assert result.stderr == b""


def test_printf_dynamic_width_and_precision(goawk):
    """``*`` takes width/precision from the argument list."""
    # CATCHES: dynamic width and precision consume extra arguments in order,
    # so %*d with 6, 42 yields "    42" (width 6, value 42).
    result = goawk(['BEGIN { printf "[%*d][%.*f]", 6, 42, 3, 3.14159 }'])
    assert result.returncode == 0
    assert result.stdout == b"[    42][3.142]"
    assert result.stderr == b""


def test_printf_percent_literal(goawk):
    """%% produces a single percent sign and consumes no argument."""
    # CATCHES: "100%%" must print as "100%", not "100%%" or an error.
    result = goawk(['BEGIN { printf "100%%" }'])
    assert result.returncode == 0
    assert result.stdout == b"100%"
    assert result.stderr == b""


def test_printf_c_number_prints_low_byte(goawk):
    """Without -c, %c of a number prints the value truncated to one byte."""
    # CATCHES: 4660 mod 256 is 52 ('4'); an implementation that emits the
    # Unicode code point without -c would print \\u1234 instead.
    result = goawk(['BEGIN { printf "%c", 4660 }'])
    assert result.returncode == 0
    assert result.stdout == b"4"
    assert result.stderr == b""


def test_printf_c_number_prints_code_point_with_chars_flag(goawk):
    """With -c, %c of a number prints the UTF-8 encoding of that code point."""
    # CATCHES: -c must switch %c from byte semantics to Unicode semantics.
    result = goawk(["-c", 'BEGIN { printf "%c", 4660 }'])
    assert result.returncode == 0
    assert result.stdout == b"\xe1\x88\xb4"
    assert result.stderr == b""


def test_printf_c_number_zero_writes_nul_byte(goawk):
    """%c of zero writes a single NUL byte."""
    # CATCHES: a NUL byte must be emitted, not skipped or rendered as "\\0".
    result = goawk(['BEGIN { printf "[%c]", 0 }'])
    assert result.returncode == 0
    assert result.stdout == b"[\x00]"
    assert result.stderr == b""


def test_printf_c_number_wraps_modulo_256(goawk):
    """In byte mode %c of 256 wraps to the NUL byte."""
    # CATCHES: the value is truncated to a byte, so 256 becomes 0.
    result = goawk(['BEGIN { printf "[%c]", 256 }'])
    assert result.returncode == 0
    assert result.stdout == b"[\x00]"
    assert result.stderr == b""


def test_printf_c_string_prints_first_byte(goawk):
    """Without -c, %c of a string prints its first byte only."""
    # CATCHES: for a multi-byte string only the leading byte 0xC3 is printed.
    result = goawk(['BEGIN { printf "%c", "éxyz" }'])
    assert result.returncode == 0
    assert result.stdout == b"\xc3"
    assert result.stderr == b""


def test_printf_c_string_prints_first_rune_with_chars_flag(goawk):
    """With -c, %c of a string prints its first UTF-8 character."""
    # CATCHES: -c makes %c of a string emit the whole first rune (2 bytes).
    result = goawk(["-c", 'BEGIN { printf "%c", "éxyz" }'])
    assert result.returncode == 0
    assert result.stdout == b"\xc3\xa9"
    assert result.stderr == b""


def test_printf_c_empty_string_writes_nul_byte(goawk):
    """%c of the empty string writes a NUL byte, not nothing."""
    # CATCHES: an empty string argument must still produce one output byte.
    result = goawk(['BEGIN { printf "[%c]", "" }'])
    assert result.returncode == 0
    assert result.stdout == b"[\x00]"
    assert result.stderr == b""


def test_printf_c_string_ascii_first_character(goawk):
    """%c of an ASCII string prints its first character."""
    # CATCHES: the whole string must not be emitted, only the first char.
    result = goawk(['BEGIN { printf "%c", "abc" }'])
    assert result.returncode == 0
    assert result.stdout == b"a"
    assert result.stderr == b""


@pytest.mark.parametrize("bad_format", ["%y", "%q", "%z"])
def test_printf_invalid_format_type_is_a_runtime_error(goawk, bad_format):
    """An unknown conversion is a runtime error with an exact message."""
    # CATCHES: the error text is "format error: invalid format type 'y'" and
    # the exit status is 1, with nothing written to stdout.
    result = goawk(['BEGIN { printf "' + bad_format + '", 1 }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        "format error: invalid format type '" + bad_format[1] + "'\n"
    ).encode()


def test_printf_missing_argument_is_a_runtime_error(goawk):
    """Fewer arguments than conversions is a runtime error."""
    # CATCHES: the message reports both counts: "got 1 args, expected 2".
    result = goawk(['BEGIN { printf "%d %d", 1 }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"format error: got 1 args, expected 2\n"


def test_printf_extra_arguments_are_ignored(goawk):
    """More arguments than conversions is not an error; extras are dropped."""
    # CATCHES: only missing arguments are fatal; surplus ones are ignored.
    result = goawk(['BEGIN { printf "%d", 1, 2 }'])
    assert result.returncode == 0
    assert result.stdout == b"1"
    assert result.stderr == b""


def test_printf_trailing_percent_is_a_runtime_error(goawk):
    """A format ending in a bare % errors instead of printing it."""
    # CATCHES: "abc%" must fail with "expected type specifier after %".
    result = goawk(['BEGIN { printf "abc%" }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"format error: expected type specifier after %\n"


def test_sprintf_shares_the_printf_engine(goawk):
    """sprintf() uses the same format engine and reports the same errors."""
    # CATCHES: an invalid conversion in sprintf() aborts the program with the
    # identical message, instead of returning a string.
    result = goawk(['BEGIN { print sprintf("%q", 1) }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"format error: invalid format type 'q'\n"


def test_printf_negative_values_in_unsigned_conversions(goawk):
    """%o/%x/%X treat negative numbers as unsigned 64-bit two's complement."""
    # CATCHES: -8 must print as 1777777777777777777770, not "-10".
    result = goawk(['BEGIN { printf "%o %x %X", -8, -255, -255 }'])
    assert result.returncode == 0
    assert result.stdout == b"1777777777777777777770 ffffffffffffff01 FFFFFFFFFFFFFF01"
    assert result.stderr == b""


def test_printf_s_conversion_of_a_number_uses_convfmt(goawk):
    """%s of a number converts it with CONVFMT, and honours changes to it."""
    # CATCHES: printf "%s", 1/3 gives "0.333333" until CONVFMT is changed to
    # "%.3f", after which it gives "0.333".
    result = goawk(
        ['BEGIN { printf "%s\\n", 1/3; CONVFMT = "%.3f"; printf "%s\\n", 1/3 }']
    )
    assert result.returncode == 0
    assert result.stdout == b"0.333333\n0.333\n"
    assert result.stderr == b""


def test_printf_coerces_string_arguments_to_numbers(goawk):
    """String arguments are converted with a leading-numeric-prefix parse."""
    # CATCHES: "42abc" converts to 42 and "abc" to 0, not an error.
    result = goawk(['BEGIN { printf "[%d][%d][%f]", "42abc", "abc", "3.5xyz" }'])
    assert result.returncode == 0
    assert result.stdout == b"[42][0][3.500000]"
    assert result.stderr == b""


def test_printf_int_conversion_overflow(goawk):
    """Converting a float beyond int64 range yields the int64 minimum."""
    # CATCHES: 1e20 converted with %d produces -9223372036854775808 rather
    # than an error or a clamped positive value.
    result = goawk(['BEGIN { printf "%d", 1e20 }'])
    assert result.returncode == 0
    assert result.stdout == b"-9223372036854775808"
    assert result.stderr == b""
