"""Record separator handling on the input side of io.go: how RS decides
what one "record" is (and therefore what a bare ``print`` emits), the RT
value each splitter leaves behind, and how FS splits a record into fields.
Everything here is observed through what ``print`` writes back out."""

import pytest


def test_rs_empty_groups_blank_line_separated_records(goawk):
    """RS="" splits input into blank-line-separated paragraph records."""
    # CATCHES: with RS="" the record is the whole paragraph "a\\nb", not two
    # separate lines, and "d" after two blank lines is a third record.
    result = goawk(
        ['BEGIN { RS = "" } { print NR ":" $0 }'],
        stdin=b"a\nb\n\nc\n\n\nd\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a\nb\n2:c\n3:d\n"
    assert result.stderr == b""


def test_rs_empty_sets_rt_to_the_blank_region(goawk):
    """RT holds the exact blank region that terminated the record."""
    # CATCHES: RT is not simply RS; for RS="" it is the run of newlines that
    # ended the record (two for one blank line, three for two blank lines,
    # and the final record's own trailing newline).
    result = goawk(
        ['BEGIN { RS = "" } { print NR "[" RT "]" }'],
        stdin=b"a\nb\n\nc\n\n\nd\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1[\n\n]\n2[\n\n\n]\n3[\n]\n"
    assert result.stderr == b""


def test_rs_empty_leading_newlines_are_skipped(goawk):
    """Blank lines before the first record do not produce an empty record."""
    # CATCHES: a wrong splitter would emit an empty leading record for the
    # newlines at the start of the input.
    result = goawk(
        ['BEGIN { RS = "" } { print NR ":" $0 }'],
        stdin=b"\n\n\nhello\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:hello\n"
    assert result.stderr == b""


def test_rs_empty_input_of_only_blank_lines_yields_no_records(goawk):
    """An input made purely of newlines produces zero records."""
    # CATCHES: END must still run (printing 0), proving the record loop body
    # never executed.
    result = goawk(
        ['BEGIN { RS = "" } { n++ } END { print n + 0 }'],
        stdin=b"\n\n\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"0\n"
    assert result.stderr == b""


def test_rs_empty_final_record_without_newline_has_empty_rt(goawk):
    """A final record that is not followed by a blank line has RT=""."""
    # CATCHES: the paragraph "a\\nb" ends at EOF with no terminator, so RT
    # must be empty rather than a newline.
    result = goawk(
        ['BEGIN { RS = "" } { print NR ":" $0 ":RT[" RT "]" }'],
        stdin=b"a\nb",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a\nb:RT[]\n"
    assert result.stderr == b""


def test_rs_empty_final_record_with_newline_keeps_rt_newline(goawk):
    """A single trailing newline is itself the terminator at EOF."""
    # CATCHES: the final record "a\\nb" plus its own "\\n" is one record with
    # RT="\\n" (the trailing newline is stripped from $0 by the EOF path).
    result = goawk(
        ['BEGIN { RS = "" } { print NR ":" $0 ":RT[" RT "]" }'],
        stdin=b"a\nb\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a\nb:RT[\n]\n"
    assert result.stderr == b""


def test_rs_empty_treats_windows_blank_line_as_terminator(goawk):
    r"""RS="" recognises \n\r\n (CRLF blank line) as a record terminator."""
    # CATCHES: the Windows-style blank line "\r\n\r\n" is skipped like a
    # blank region; record 1's RT is "\n\r\n" and record 2 ("b", at EOF)
    # keeps RT "\r\n" with the trailing bytes stripped from $0.
    result = goawk(
        ['BEGIN { RS = "" } { print NR ":" $0 ":RT[" RT "]" }'],
        stdin=b"a\r\n\r\nb\r\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a:RT[\n\r\n]\n2:b:RT[\r\n]\n"
    assert result.stderr == b""


def test_rs_empty_with_single_char_fs_also_splits_on_newlines(goawk):
    """RS="" plus a one-character FS splits fields on newlines as well."""
    # CATCHES: POSIX multi-line behaviour: the paragraph "a,b\\nc,d" with
    # FS="," yields four fields, while the second paragraph yields two.
    result = goawk(
        ['BEGIN { RS = ""; FS = "," } { print NR ":" $1 "|" $2 "|" $3 "|" NF }'],
        stdin=b"a,b\nc,d\n\ne,f\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a|b|c|4\n2:e|f||2\n"
    assert result.stderr == b""


def test_rs_empty_trims_carriage_returns_from_fields(goawk):
    r"""RS="" with single-char FS strips "\r" from end of split lines."""
    # CATCHES: the CR before the embedded newline is trimmed from the field,
    # so $1 of record 1 is exactly "x".
    result = goawk(
        ['BEGIN { RS = ""; FS = "," } { print NR ":" $1 }'],
        stdin=b"x\r\ny\n\nz\r\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:x\n2:z\n"
    assert result.stderr == b""


def test_single_character_rs_splits_on_that_byte(goawk):
    """A one-character RS splits records on every occurrence of that byte."""
    # CATCHES: the final record "c" has no separator after it but is still
    # returned, and RT for every record (including the last) is ";" itself.
    result = goawk(
        ['BEGIN { RS = ";" } { print NR ":" $0 ":" RT }'],
        stdin=b"a;b;c",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a:;\n2:b:;\n3:c:;\n"
    assert result.stderr == b""


def test_multicharacter_rs_is_a_regex(goawk):
    """A multi-character RS is treated as a regular expression."""
    # CATCHES: RS="--" matches the literal two dashes, and the final record
    # has RT="" because the regex splitter clears RT at EOF.
    result = goawk(
        ['BEGIN { RS = "--" } { print NR ":" $0 ":RT[" RT "]" }'],
        stdin=b"a--b--c",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a:RT[--]\n2:b:RT[--]\n3:c:RT[]\n"
    assert result.stderr == b""


def test_regex_rs_matches_runs_via_the_regex_splitter(goawk):
    r"""A regex RS like "X+" consumes the whole matched run as terminator."""
    # CATCHES: "X+" must match both Xs at once, so RT is "XX" and there are
    # exactly two records.
    result = goawk(
        ['BEGIN { RS = "X+" } { print NR ":" $0 ":RT[" RT "]" }'],
        stdin=b"aXXb",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a:RT[XX]\n2:b:RT[]\n"
    assert result.stderr == b""


def test_multibyte_single_rune_rs_uses_the_regex_splitter(goawk):
    "A single multi-byte character RS is handled by the regex path."
    # CATCHES: "é" is one rune but two bytes, so it must not go through the
    # byte splitter; the split still happens on each occurrence.
    result = goawk(
        ['BEGIN { RS = "é" } { print NR ":" $0 }'],
        stdin="aéb".encode("utf-8"),
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a\n2:b\n"
    assert result.stderr == b""


def test_regex_rs_that_matches_empty_returns_whole_input(goawk):
    r"""An RS regex matching the empty string yields one big record."""
    # CATCHES: gawk compatibility: RS="()" matches empty, the match is
    # ignored, and the entire input (including its trailing newline) becomes
    # a single record.
    result = goawk(
        ['BEGIN { RS = "()" } { print NR ":" $0 }'],
        stdin=b"a\nb\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a\nb\n\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "fs,expected",
    [
        (",", b"1:a|b|c\n"),
        (", +", b"1:a|b,c|\n"),
        ("--", b"1:a|b|c\n"),
        ("()", b"1:a,b,c||\n"),
    ],
)
def test_fs_splitting_modes(goawk, fs, expected):
    """FS as plain char, regex, and empty-match regex all split differently."""
    # CATCHES: FS=", +" only matches a comma followed by spaces (so the bare
    # "," before "c" does not split), and FS="()" skips empty matches so the
    # whole line is one field.
    stdin = b"a,  b,c\n" if fs == ", +" else b"a--b--c\n" if fs == "--" else b"a,b,c\n"
    result = goawk(['BEGIN { FS = "%s" } { print NR ":" $1 "|" $2 "|" $3 }' % fs], stdin=stdin)
    assert result.returncode == 0
    assert result.stdout == expected
    assert result.stderr == b""


def test_single_char_fs_empty_line_has_no_fields(goawk):
    """An empty input line yields NF=0 with a one-character FS."""
    # CATCHES: the empty middle record must produce NF 0 and an empty $0,
    # not a single empty field.
    result = goawk(
        ['BEGIN { FS = "," } { print NR ":" NF ":" $0 }'],
        stdin=b"a\n\nb\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:1:a\n2:0:\n3:1:b\n"
    assert result.stderr == b""


def test_default_rs_strips_carriage_return_from_records(goawk):
    r"""With the default RS, a trailing "\r" is dropped from $0."""
    # CATCHES: input "a\r\n" must print as "a\n" — the CR is removed by the
    # record reader, not passed through to output.
    result = goawk(["{ print $0 }"], stdin=b"a\r\nb\r\n")
    assert result.returncode == 0
    assert result.stdout == b"a\nb\n"
    assert result.stderr == b""


def test_final_record_without_trailing_newline_is_still_returned(goawk):
    """Input whose last record has no newline still yields that record."""
    # CATCHES: the reader must not drop the unterminated final record "ab".
    result = goawk(["{ print NR \":\" $0 }"], stdin=b"ab")
    assert result.returncode == 0
    assert result.stdout == b"1:ab\n"
    assert result.stderr == b""

