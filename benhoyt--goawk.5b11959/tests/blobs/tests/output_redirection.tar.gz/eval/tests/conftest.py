"""Harness for black-box tests of GoAWK's output-side behaviour.

The binary under test is only ever exercised through its command line
interface; every expected byte string in the test modules below was recorded
by actually running the reference ``./executable``.
"""

import os
import select
import subprocess
import time

import pytest

# Fully pinned, minimal environment for child processes.  GoAWK runs
# ``print ... | "cmd"`` pipes through "/bin/sh -c", so PATH has to resolve the
# standard coreutils.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "LC_ALL": "C",
}

# Generous per-invocation cap; every test in this module finishes in well
# under a second, this only guards against a hung child.
DEFAULT_TIMEOUT = 30


class RunResult(object):
    """Recorded outcome of a single goawk invocation."""

    def __init__(self, args, returncode, stdout, stderr):
        self.args = list(args)
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

    def __repr__(self):
        return "RunResult(args=%r, returncode=%d, stdout=%r, stderr=%r)" % (
            self.args,
            self.returncode,
            self.stdout,
            self.stderr,
        )


def child_env(overrides=None):
    """Build the pinned child environment, forwarding coverage dirs."""
    env = dict(CHILD_ENV)
    if overrides:
        env.update(overrides)
    # Coverage instrumentation hook: the pipeline builds the reference binary
    # with -cover, so GOCOVERDIR must reach the child for the coverage
    # counters to be written.
    cov = os.environ.get("GOCOVERDIR")
    if cov:
        env["GOCOVERDIR"] = cov
    return env


def run_goawk(
    args,
    stdin=b"",
    cwd=None,
    env=None,
    timeout=DEFAULT_TIMEOUT,
    stdout_path=None,
    merge_stderr=False,
):
    """Run the goawk binary under test and capture its exact output bytes.

    ``stdout_path`` redirects the child's stdout to a file (used to point it
    at devices such as /dev/full), and ``merge_stderr`` duplicates the child's
    stderr onto its stdout so write ordering across the two can be checked.
    """
    executable = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not executable:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; cannot run the binary under test"
        )
    argv = [executable] + [os.fsdecode(a) for a in args]
    stderr_arg = subprocess.STDOUT if merge_stderr else subprocess.PIPE
    if stdout_path is None:
        proc = subprocess.run(
            argv,
            input=stdin,
            stdout=subprocess.PIPE,
            stderr=stderr_arg,
            cwd=cwd,
            env=child_env(env),
            timeout=timeout,
        )
        return RunResult(argv[1:], proc.returncode, proc.stdout, proc.stderr)
    with open(stdout_path, "wb") as stdout_file:
        proc = subprocess.run(
            argv,
            input=stdin,
            stdout=stdout_file,
            stderr=stderr_arg,
            cwd=cwd,
            env=child_env(env),
            timeout=timeout,
        )
        stderr = proc.stderr if stderr_arg == subprocess.PIPE else b""
    return RunResult(argv[1:], proc.returncode, b"", stderr)


@pytest.fixture
def goawk(tmp_path):
    """Run goawk with its working directory pinned to a fresh temp dir."""

    def run(args, stdin=b"", env=None, timeout=DEFAULT_TIMEOUT, cwd=None, **kwargs):
        return run_goawk(
            args, stdin=stdin, cwd=cwd if cwd is not None else tmp_path,
            env=env, timeout=timeout, **kwargs,
        )

    return run


def interact_goawk(args, feed, cwd=None, first_read_timeout=5.0, total_timeout=20.0):
    """Run goawk interactively and report what it printed before blocking.

    The child's stdin is held open until after ``first_read_timeout`` has
    elapsed, so a program that blocks on ``getline`` only finishes once
    ``feed`` is written.  The returned ``early`` bytes are therefore exactly
    what the child flushed to stdout *before* it blocked.
    """
    executable = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not executable:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; cannot run the binary under test"
        )
    argv = [executable] + [os.fsdecode(a) for a in args]
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env=child_env(),
    )
    stdout_fd = proc.stdout.fileno()
    ready, _, _ = select.select([stdout_fd], [], [], first_read_timeout)
    early = os.read(stdout_fd, 4096) if ready else b""

    proc.stdin.write(feed)
    proc.stdin.flush()
    proc.stdin.close()

    chunks = []
    deadline = time.time() + total_timeout
    while True:
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        ready, _, _ = select.select([stdout_fd], [], [], remaining)
        if not ready:
            break
        data = os.read(stdout_fd, 4096)
        if not data:
            break
        chunks.append(data)
    proc.wait(timeout=total_timeout)
    stderr = proc.stderr.read()
    proc.stdout.close()
    proc.stderr.close()
    return {
        "early": early,
        "stdout": early + b"".join(chunks),
        "stderr": stderr,
        "returncode": proc.returncode,
    }


@pytest.fixture
def interact(tmp_path):
    """Run goawk interactively, pinned to a fresh temp working directory."""

    def run(args, feed, **kwargs):
        kwargs.setdefault("cwd", tmp_path)
        return interact_goawk(args, feed, **kwargs)

    return run
