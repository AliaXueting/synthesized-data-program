"""Newline output translation (-N smart|raw|crlf) for every kind of output:
stdout, redirected files, /dev/stderr, pipes and CSV records."""

import pytest


def read_file(path):
    with open(path, "rb") as handle:
        return handle.read()


@pytest.mark.parametrize(
    "mode_args",
    [[], ["-N", "smart"], ["-Nsmart"], ["-N", "raw"], ["-Nraw"]],
)
def test_smart_and_raw_leave_lf_untouched(goawk, mode_args):
    """smart (the default) and raw write LF as LF on Linux."""

    # CATCHES: a re-implementation that translated newlines by default (or
    # treated smart as CRLF) would emit \r\n here.
    result = goawk(mode_args + ['BEGIN { printf "foo\\nbar\\n" }'])
    assert result.returncode == 0
    assert result.stdout == b"foo\nbar\n"
    assert result.stderr == b""


@pytest.mark.parametrize("mode_args", [[], ["-N", "smart"], ["-N", "raw"]])
def test_embedded_crlf_is_not_rewritten_in_smart_and_raw(goawk, mode_args):
    """A CR already present in the data is passed through unchanged."""
    # CATCHES: smart mode must not strip or double an existing \r.
    result = goawk(mode_args + ['BEGIN { printf "foo\\r\\nbar\\n" }'])
    assert result.returncode == 0
    assert result.stdout == b"foo\r\nbar\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "mode_args", [["-N", "crlf"], ["-Ncrlf"]]
)
def test_crlf_mode_translates_printf_output(goawk, mode_args):
    """-N crlf turns every LF written by printf into CR LF."""
    # CATCHES: both spellings of the flag must produce \r\n line endings.
    result = goawk(mode_args + ['BEGIN { printf "foo\\nbar\\n" }'])
    assert result.returncode == 0
    assert result.stdout == b"foo\r\nbar\r\n"
    assert result.stderr == b""


def test_crlf_mode_translates_print_output(goawk):
    """The ORS written by print is translated to CR LF too."""
    # CATCHES: print's record separator must go through the same translation
    # as printf's literal newlines.
    result = goawk(["-N", "crlf", 'BEGIN { print "foo" }'])
    assert result.returncode == 0
    assert result.stdout == b"foo\r\n"
    assert result.stderr == b""


def test_crlf_mode_translates_redirected_file_writes(goawk, tmp_path):
    """Records written to a redirected file also get CR LF endings."""
    # CATCHES: translation is not limited to stdout; the file must contain
    # \r\n for both the print and the printf writes.
    result = goawk(
        [
            "-N",
            "crlf",
            'BEGIN { print "foo" > "nl.txt"; printf "bar\\n" > "nl.txt" }',
        ]
    )
    assert result.returncode == 0
    assert read_file(tmp_path / "nl.txt") == b"foo\r\nbar\r\n"


def test_crlf_mode_translates_dev_stderr_writes(goawk):
    """Writes to /dev/stderr are translated to CR LF as well."""
    # CATCHES: the special stderr stream must share the newline translation.
    result = goawk(["-N", "crlf", 'BEGIN { print "err" > "/dev/stderr" }'])
    assert result.returncode == 0
    assert result.stderr == b"err\r\n"
    assert result.stdout == b""


def test_crlf_mode_translates_dash_writes(goawk):
    """Writes to the special name "-" are translated to CR LF."""
    # CATCHES: the stdout alias must be translated like stdout itself.
    result = goawk(["-N", "crlf", 'BEGIN { print "a" > "/dev/stdout"; print "b" > "-" }'])
    assert result.returncode == 0
    assert result.stdout == b"a\r\nb\r\n"
    assert result.stderr == b""


def test_crlf_mode_translates_pipe_writes(goawk):
    """Records piped into a command are translated to CR LF."""
    # CATCHES: the pipe stream must apply the same newline translation before
    # the data reaches the child command.
    result = goawk(["-N", "crlf", 'BEGIN { print "line" | "cat" }'])
    assert result.returncode == 0
    assert result.stdout == b"line\r\n"
    assert result.stderr == b""


def test_crlf_mode_translates_ofs_newlines(goawk):
    """A newline inside OFS is translated along with ORS."""
    # CATCHES: every piece of a print (OFS included) passes through the
    # translation, giving a\r\nb\r\n rather than a\nb\r\n.
    result = goawk(["-N", "crlf", 'BEGIN { OFS = "\\n"; print "a", "b" }'])
    assert result.returncode == 0
    assert result.stdout == b"a\r\nb\r\n"
    assert result.stderr == b""


def test_crlf_mode_with_custom_ors_without_newline(goawk):
    """An ORS that contains no LF is emitted unchanged."""
    # CATCHES: translation only rewrites newlines; "XY" must stay "XY".
    result = goawk(["-N", "crlf", 'BEGIN { ORS = "XY"; print "foo" }'])
    assert result.returncode == 0
    assert result.stdout == b"fooXY"
    assert result.stderr == b""


def test_crlf_mode_with_empty_ors(goawk):
    """With ORS = "" the record body is written with no added bytes."""
    # CATCHES: an empty terminator must not gain a \r\n.
    result = goawk(["-N", "crlf", 'BEGIN { ORS = ""; print "foo" }'])
    assert result.returncode == 0
    assert result.stdout == b"foo"
    assert result.stderr == b""


def test_crlf_mode_does_not_double_an_existing_crlf(goawk):
    """An existing \r\n in the data is normalised, not turned into \r\r\n."""
    # CATCHES: translation first folds \r\n to \n and then expands it again,
    # so no extra \r may appear.
    result = goawk(["-N", "crlf", 'BEGIN { printf "foo\\r\\nbar\\n" }'])
    assert result.returncode == 0
    assert result.stdout == b"foo\r\nbar\r\n"
    assert result.stderr == b""


def test_crlf_mode_translates_csv_output_records(goawk):
    """CSV output mode honours -N crlf for its record terminator."""
    # CATCHES: the CSV writer must use CR LF line endings under -N crlf.
    result = goawk(["-o", "csv", "-N", "crlf", 'BEGIN { print 1, " 2 " }'])
    assert result.returncode == 0
    assert result.stdout == b'1," 2 "\r\n'
    assert result.stderr == b""


def test_crlf_mode_translates_newline_inside_quoted_csv_field(goawk):
    """A newline inside a quoted CSV field is also written as CR LF."""
    # CATCHES: the embedded newline is part of the field data and must be
    # translated too, giving "a\r\nb",c\r\n.
    result = goawk(["-o", "csv", "-N", "crlf", 'BEGIN { print "a\\nb", "c" }'])
    assert result.returncode == 0
    assert result.stdout == b'"a\r\nb",c\r\n'
    assert result.stderr == b""


def test_raw_mode_keeps_csv_output_lf(goawk):
    """-N raw forces LF endings even for CSV output."""
    # CATCHES: raw must override any smart/CRLF default for the CSV writer.
    result = goawk(["-o", "csv", "-N", "raw", 'BEGIN { print 1, " 2 " }'])
    assert result.returncode == 0
    assert result.stdout == b'1," 2 "\n'
    assert result.stderr == b""


@pytest.mark.parametrize("bad_args", [["-N", "INVALID"], ["-NINVALID"], ["-N", "crlfx"]])
def test_invalid_newline_mode_is_rejected(goawk, bad_args):
    """An unknown -N value aborts before the program runs."""
    # CATCHES: the exact message is "-N arg can only be one of: smart, raw,
    # crlf" and the exit status is 1.
    result = goawk(bad_args + ['BEGIN { print "x" }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"-N arg can only be one of: smart, raw, crlf\n"
