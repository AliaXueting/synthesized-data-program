"""CSV input mode (``-i csv`` / ``-i tsv`` / ``--csv``): how the CSV record
splitter parses fields, quotes, comments, headers and byte-order marks, and
what those records then look like when printed back out."""

import os
import subprocess
import time

import pytest


def feed_in_two_chunks(args, first, second, cwd, delay=0.3):
    """Run goawk feeding its stdin in two writes separated by a delay.

    The gap forces the record reader to see a partial, non-EOF chunk first,
    exercising the code paths that wait for the rest of a CSV record.  The
    child's environment is pinned exactly like every other test.
    """
    executable = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not executable:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; cannot run the binary under test"
        )
    env = {
        "PATH": "/usr/bin:/bin",
        "LC_ALL": "C",
    }
    # Coverage instrumentation hook: forward GOCOVERDIR to the child.
    cov = os.environ.get("GOCOVERDIR")
    if cov:
        env["GOCOVERDIR"] = cov
    argv = [executable] + [os.fsdecode(a) for a in args]
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env=env,
    )
    proc.stdin.write(first)
    proc.stdin.flush()
    time.sleep(delay)
    proc.stdin.write(second)
    proc.stdin.flush()
    proc.stdin.close()
    stdout = proc.stdout.read()
    stderr = proc.stderr.read()
    proc.wait(timeout=30)
    proc.stdout.close()
    proc.stderr.close()
    return proc.returncode, stdout, stderr


def test_csv_input_basic_field_splitting(goawk):
    """-i csv splits records on commas and sets NF."""
    # CATCHES: $1/$2/$3 must be the unquoted field values and NF counts 3.
    result = goawk(['-i', 'csv', '{ print $1 "|" $2 "|" $3 "|" NF }'], stdin=b"a,b,c\n")
    assert result.returncode == 0
    assert result.stdout == b"a|b|c|3\n"
    assert result.stderr == b""


def test_csv_input_dollar0_is_the_raw_record(goawk):
    """$0 keeps the raw CSV text of the record."""
    # CATCHES: $0 is not the joined fields but the original record bytes.
    result = goawk(['-i', 'csv', '{ print $0 }'], stdin=b"a,b,c\n")
    assert result.returncode == 0
    assert result.stdout == b"a,b,c\n"
    assert result.stderr == b""


def test_csv_input_quoted_field_hiding_separator(goawk):
    """A quoted field may contain the separator."""
    # CATCHES: "a,x" is a single field despite the comma inside the quotes.
    result = goawk(['-i', 'csv', '{ print $1 "|" $2 "|" NF }'], stdin=b'"a,x",b\n')
    assert result.returncode == 0
    assert result.stdout == b"a,x|b|2\n"
    assert result.stderr == b""


def test_csv_input_doubled_quotes_inside_quoted_field(goawk):
    """A doubled double-quote is an escaped literal quote."""
    # CATCHES: "say ""hi""" decodes to the five characters say "hi".
    result = goawk(['-i', 'csv', '{ print $1 "|" $2 }'], stdin=b'"say ""hi""",b\n')
    assert result.returncode == 0
    assert result.stdout == b'say "hi"|b\n'
    assert result.stderr == b""


def test_csv_input_newline_inside_quoted_field(goawk):
    """A quoted field may span a newline and the record is still one record."""
    # CATCHES: the newline inside quotes must not terminate the record, so
    # $1 contains both lines and $2 is still "b".
    result = goawk(['-i', 'csv', '{ print $1 "|" $2 }'], stdin=b'"l1\nl2",b\n')
    assert result.returncode == 0
    assert result.stdout == b"l1\nl2|b\n"
    assert result.stderr == b""


def test_csv_input_crlf_inside_quoted_field_becomes_lf(goawk):
    r"""A "\r\n" inside a quoted field is normalised to "\n"."""
    # CATCHES: the embedded CRLF becomes a bare LF in the field value, and
    # the CR is removed from $0 as well.
    result = goawk(['-i', 'csv', '{ print $1; print $0 }'], stdin=b'"l1\r\nl2",b\n')
    assert result.returncode == 0
    assert result.stdout == b'l1\nl2\n"l1\nl2",b\n'
    assert result.stderr == b""


def test_csv_input_bare_quote_after_closing_quote(goawk):
    r"""A quote followed by other text is a literal quote (lazy quotes)."""
    # CATCHES: in `"b"c` the quote after b does not close the field cleanly;
    # GoAWK appends it literally and keeps scanning to the line end, so the
    # field value is `b"c` including the trailing newline.
    result = goawk(['-i', 'csv', '{ print $1 "|" $2 }'], stdin=b'a,"b"c\n')
    assert result.returncode == 0
    assert result.stdout == b'a|b"c\n\n'
    assert result.stderr == b""


def test_csv_input_bare_quote_in_unquoted_field(goawk):
    """A quote in the middle of an unquoted field is plain data."""
    # CATCHES: a"b stays a"b — quotes only start a quoted field at the very
    # beginning of the field.
    result = goawk(['-i', 'csv', '{ print $1 "|" $2 }'], stdin=b'a"b,c\n')
    assert result.returncode == 0
    assert result.stdout == b'a"b|c\n'
    assert result.stderr == b""


def test_csv_input_empty_fields_are_preserved(goawk):
    """Empty unquoted and quoted fields both produce empty strings."""
    # CATCHES: the leading empty field must not be dropped; NF is 2 and $0
    # echoes the original quoting.
    result = goawk(['-i', 'csv', '{ print NF ":" $1 "|" $2 ":" $0 }'], stdin=b',"b"\n')
    assert result.returncode == 0
    assert result.stdout == b'2:|b:,"b"\n'
    assert result.stderr == b""


def test_csv_input_abrupt_eof_inside_quoted_field(goawk):
    """A quoted field cut off by EOF is returned without the quote."""
    # CATCHES: the unterminated field "abc still yields the record with
    # field value abc rather than an error or a dropped record.
    result = goawk(['-i', 'csv', '{ print NF ":" $1 }'], stdin=b'"abc')
    assert result.returncode == 0
    assert result.stdout == b"1:abc\n"
    assert result.stderr == b""


def test_csv_input_record_without_trailing_newline(goawk):
    """A final CSV record without a newline is still parsed."""
    # CATCHES: the missing terminator must not lose the last record.
    result = goawk(['-i', 'csv', '{ print NR ":" $1 "|" $2 }'], stdin=b"a,b")
    assert result.returncode == 0
    assert result.stdout == b"1:a|b\n"
    assert result.stderr == b""


def test_csv_input_trailing_carriage_return_at_eof_is_dropped(goawk):
    r"""A final record ending "\r" (no newline) loses the "\r"."""
    # CATCHES: at EOF a lone trailing CR is not part of the field value.
    result = goawk(['-i', 'csv', '{ print $1 "|" $2 }'], stdin=b"a,b\r")
    assert result.returncode == 0
    assert result.stdout == b"a|b\n"
    assert result.stderr == b""


def test_csv_input_blank_lines_are_skipped(goawk):
    """Blank lines between CSV records produce no records."""
    # CATCHES: NR goes 1,2 for the two data rows; the blank lines (including
    # trailing ones) are skipped entirely.
    result = goawk(
        ['-i', 'csv', '{ print NR ":" $1 "|" $2 }'], stdin=b"a,b\n\nc,d\n\n\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a|b\n2:c|d\n"
    assert result.stderr == b""


def test_csv_input_comment_lines_are_skipped(goawk):
    """comment=<char> skips lines starting with that character."""
    # CATCHES: both the leading "# hdr" and the middle "# mid" vanish; only
    # the two data rows are numbered.
    result = goawk(
        ['-i', 'csv comment=#', '{ print NR ":" $1 "|" $2 }'],
        stdin=b"# hdr\na,b\n# mid\nc,d\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:a|b\n2:c|d\n"
    assert result.stderr == b""


def test_csv_input_comment_at_eof_without_newline(goawk):
    """A comment line at EOF without a newline is skipped cleanly."""
    # CATCHES: the reader must not hang or emit an empty record when the
    # input ends inside the skip loop.
    result = goawk(['-i', 'csv comment=#', '{ print NR ":" $1 }'], stdin=b"a,b\n#trail")
    assert result.returncode == 0
    assert result.stdout == b"1:a\n"
    assert result.stderr == b""


def test_csv_input_utf8_bom_is_skipped(goawk):
    """A UTF-8 byte-order mark at the start of the input is skipped."""
    # CATCHES: the BOM must not end up in $1 or $0; the record reads as if
    # the input began with "a".
    result = goawk(['-i', 'csv', '{ print $1 "|" $2; print $0 }'], stdin=b"\xef\xbb\xbfa,b\n")
    assert result.returncode == 0
    assert result.stdout == b"a|b\na,b\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "first,second",
    [
        (b"\xef", b"\xbb\xbfa,b\n"),
        (b"\xef\xbb", b"\xbfa,b\n"),
    ],
)
def test_csv_input_bom_split_across_reads(goawk, tmp_path, first, second):
    """A BOM delivered in two chunks is still recognised and skipped."""
    # CATCHES: when the first read returns only one or two bytes of the BOM
    # the reader must wait for more data instead of treating those bytes as
    # record content.
    returncode, stdout, stderr = feed_in_two_chunks(
        ['-i', 'csv', '{ print $1 "|" $2 }'], first, second, cwd=tmp_path
    )
    assert returncode == 0
    assert stdout == b"a|b\n"
    assert stderr == b""


def test_csv_input_partial_line_across_reads(goawk, tmp_path):
    """A record whose first field arrives in two writes is parsed whole."""
    # CATCHES: after reading "a," with no newline and no EOF the reader must
    # request more data, not emit a record with a truncated field.
    returncode, stdout, stderr = feed_in_two_chunks(
        ['-i', 'csv', '{ print $1 "|" $2 }'], b"a,", b"b\n", cwd=tmp_path
    )
    assert returncode == 0
    assert stdout == b"a|b\n"
    assert stderr == b""


def test_csv_input_quoted_field_spanning_reads(goawk, tmp_path):
    """A quoted field split across two writes is reassembled."""
    # CATCHES: the open quote at the end of the first chunk must make the
    # reader pull the continuation line before parsing the record.
    returncode, stdout, stderr = feed_in_two_chunks(
        ['-i', 'csv', '{ print $1 "|" $2 }'], b'"a\n', b'b",c\n', cwd=tmp_path
    )
    assert returncode == 0
    assert stdout == b"a\nb|c\n"
    assert stderr == b""


def test_csv_input_separator_override(goawk):
    """separator=<char> changes the field separator character."""
    # CATCHES: with separator=; the semicolon splits fields and a comma is
    # ordinary data.
    result = goawk(
        ['-i', 'csv separator=;', '{ print $1 "|" $2 }'], stdin=b"a;x,y\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"a|x,y\n"
    assert result.stderr == b""


def test_csv_input_multibyte_separator_override(goawk):
    """A multi-byte separator character is accepted."""
    # CATCHES: separator=é splits on the two-byte UTF-8 rune.
    result = goawk(
        ['-i', 'csv separator=é', '{ print $1 "|" $2 }'],
        stdin="aéb\n".encode("utf-8"),
    )
    assert result.returncode == 0
    assert result.stdout == b"a|b\n"
    assert result.stderr == b""


def test_tsv_input_mode(goawk):
    """-i tsv splits fields on tabs."""
    # CATCHES: commas are data in tsv mode; the tab splits $1 and $2.
    result = goawk(['-i', 'tsv', '{ print $1 "|" $2 }'], stdin=b"a,x\tb\n")
    assert result.returncode == 0
    assert result.stdout == b"a,x|b\n"
    assert result.stderr == b""


def test_tsv_input_separator_override(goawk):
    """The tsv mode's separator can be overridden back to comma."""
    # CATCHES: "tsv separator=," must override the default tab.
    result = goawk(
        ['-i', 'tsv separator=,', '{ print $1 "|" $2 }'], stdin=b"a,b\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"a|b\n"
    assert result.stderr == b""


def test_dash_dash_csv_alias(goawk):
    """--csv is equivalent to -i csv."""
    # CATCHES: the POSIX-style --csv flag must parse input as CSV too.
    result = goawk(['--csv', '{ print $2 $1 }'], stdin=b"a,b\n")
    assert result.returncode == 0
    assert result.stdout == b"ba\n"
    assert result.stderr == b""


def test_csv_input_from_a_file_argument(goawk, tmp_path):
    """CSV mode applies when records come from a file argument, not stdin."""
    # CATCHES: the CSV splitter is installed for file-driven input as well.
    (tmp_path / "data.csv").write_bytes(b"p,q\nr,s\n")
    result = goawk(['-i', 'csv', '{ print $1 $2 }', 'data.csv'])
    assert result.returncode == 0
    assert result.stdout == b"pq\nrs\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "mode,message",
    [
        ("csv separator=ab", b'invalid CSV/TSV separator "ab"\n'),
        ("csv comment=ab", b'invalid CSV/TSV comment character "ab"\n'),
        ("xyz", b'invalid input mode "xyz"\n'),
    ],
)
def test_csv_input_mode_option_errors(goawk, mode, message):
    """Invalid -i modes and options are rejected with an exact message."""
    # CATCHES: a two-character separator or comment is invalid, and an
    # unknown mode name is reported as such, all with exit status 1.
    result = goawk(['-i', mode, '{ print }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == message


def test_csv_input_header_named_fields(goawk):
    """-H parses a header row and enables @"name" field access."""
    # CATCHES: the header row itself is consumed (NR starts at the first
    # data row) and @"name"/@"age" read the right columns.
    result = goawk(
        ['-H', '-i', 'csv', '{ print NR ":" @"name" "|" @"age" }'],
        stdin=b"name,age\nbob,3\ncat,9\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"1:bob|3\n2:cat|9\n"
    assert result.stderr == b""


def test_csv_input_header_mode_in_mode_string(goawk):
    """'header' inside the -i mode string matches -H."""
    # CATCHES: -i 'csv header' is documented as equivalent to -i csv -H.
    result = goawk(
        ['-i', 'csv header', '{ print @"name" }'], stdin=b"name,age\nbob,3\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"bob\n"
    assert result.stderr == b""


def test_csv_input_header_populates_fields_array(goawk):
    """The FIELDS array maps field numbers to the header names."""
    # CATCHES: FIELDS[1] is "id" etc. on the header row; note FIELDS is
    # keyed by number, so FIELDS["email"] is empty.
    result = goawk(
        ['-H', '-i', 'csv', 'NR==1 { print FIELDS[1], FIELDS[2], FIELDS[3]; print "[" FIELDS["email"] "]" }'],
        stdin=b"id,name,email\n1,bob,b@x\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"id name email\n[]\n"
    assert result.stderr == b""


def test_csv_input_header_is_per_file(goawk, tmp_path):
    """Each input file gets its own header row parsed."""
    # CATCHES: setFieldNames runs for h2.csv too, so @nick works there even
    # though h1.csv's header called the column @name.
    (tmp_path / "h1.csv").write_bytes(b"name,age\nbob,3\n")
    (tmp_path / "h2.csv").write_bytes(b"nick,yrs\ncat,9\n")
    result = goawk(
        ['-H', '-i', 'csv', '{ print FILENAME ":" @"name" @"nick" }', 'h1.csv', 'h2.csv']
    )
    assert result.returncode == 0
    assert result.stdout == b"h1.csv:bob\nh2.csv:cat\n"
    assert result.stderr == b""


def test_csv_input_header_only_file_yields_no_records(goawk):
    """A file with only a header row produces no records."""
    # CATCHES: the header row is consumed by the parser, so NR stays 0 in
    # END even though one line of input was present.
    result = goawk(
        ['-H', '-i', 'csv', 'BEGIN { print "b" } END { print NR }'],
        stdin=b"name,age\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"b\n0\n"
    assert result.stderr == b""


def test_csv_input_dollar0_assignment_is_reparsed_as_csv(goawk):
    """Assigning $0 re-parses it with the CSV rules."""
    # CATCHES: $0="a,b" must become two CSV fields, not one FS-split field.
    result = goawk(
        ['-i', 'csv', 'BEGIN { $0 = "a,b"; print NF ":" $1 "|" $2 }'], stdin=b"z\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"2:a|b\n"
    assert result.stderr == b""


def test_csv_input_dollar0_assignment_to_empty(goawk):
    """Assigning an empty $0 leaves zero fields."""
    # CATCHES: the CSV re-parse of "" yields no fields, so NF is 0.
    result = goawk(['-i', 'csv', 'BEGIN { $0 = ""; print NF }'], stdin=b"z\n")
    assert result.returncode == 0
    assert result.stdout == b"0\n"
    assert result.stderr == b""


def test_csv_input_field_rebuild_uses_ofs_not_the_separator(goawk):
    """Record rebuild after $1= uses OFS even in CSV input mode."""
    # CATCHES: input mode does not make OFS the CSV separator; $1="x y"
    # rebuilds $0 with the default OFS space: "x y b".
    result = goawk(
        ['-i', 'csv', '{ $1 = "x y"; print $0 }'], stdin=b"a,b\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"x y b\n"
    assert result.stderr == b""


def test_csv_input_nf_shrink_rebuilds_with_ofs(goawk):
    """Lowering NF rebuilds $0 from the kept fields joined with OFS."""
    # CATCHES: NF=2 drops the third field and the rebuild joins with OFS
    # (space), not the input comma.
    result = goawk(
        ['-i', 'csv', '{ NF = 2; print $0 "~" NF }'], stdin=b"a,b,c\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"a b~2\n"
    assert result.stderr == b""


def test_csv_input_getline_reads_whole_csv_records(goawk):
    """getline consumes the next CSV record, not the next line."""
    # CATCHES: v becomes the whole record "c,d" (comma included) because
    # getline uses the same CSV splitter as the main loop.
    result = goawk(
        ['-i', 'csv', '{ getline v; print $0 "~" v }'], stdin=b"a,b\nc,d\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"a,b~c,d\n"
    assert result.stderr == b""


def test_csv_input_getline_var_leaves_stale_fields(goawk):
    """After getline v in CSV mode, $1 already reflects the new record."""
    # CATCHES: GoAWK quirk: $0 still shows the old record "a,b" while the
    # field values were updated to the newly-read record ($1 is "c").
    result = goawk(
        ['-i', 'csv', '{ getline v; print "v=" v; print "$0=" $0; print "$1=" $1 }'],
        stdin=b"a,b\nc,d\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"v=c,d\n$0=a,b\n$1=c\n"
    assert result.stderr == b""


def test_csv_input_record_count_in_end(goawk):
    """END sees the CSV record count."""
    # CATCHES: NR counts parsed records, so two CSV rows give NR 2.
    result = goawk(['-i', 'csv', 'END { print NR }'], stdin=b"a,b\nc,d\n")
    assert result.returncode == 0
    assert result.stdout == b"2\n"
    assert result.stderr == b""
