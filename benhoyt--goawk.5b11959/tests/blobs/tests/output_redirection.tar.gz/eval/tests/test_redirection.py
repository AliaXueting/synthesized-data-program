"""Output redirection: ``> "file"``, ``>> "file"``, ``| "cmd"``, the special
names /dev/stdout, /dev/stderr and "-", and the errors those can raise."""

import pytest


def read_file(path):
    with open(path, "rb") as handle:
        return handle.read()


def test_greater_truncates_only_on_first_use(goawk, tmp_path):
    """A second print to an open stream continues; >> appends to it too."""

    # CATCHES: the file is truncated once when the stream is opened, so a
    # second ">" must not wipe the first line.
    result = goawk(
        ['BEGIN { print "one" > "f.txt"; print "two" > "f.txt";'
         ' print "three" >> "f.txt" }']
    )
    assert result.returncode == 0
    assert result.stdout == b""
    assert read_file(tmp_path / "f.txt") == b"one\ntwo\nthree\n"


def test_greater_truncates_a_preexisting_file(goawk, tmp_path):
    """> truncates a file left over from a previous run."""
    # CATCHES: an implementation that always appends would leave old content.
    (tmp_path / "f.txt").write_bytes(b"old content that must disappear\n")
    result = goawk(['BEGIN { print "new" > "f.txt" }'])
    assert result.returncode == 0
    assert read_file(tmp_path / "f.txt") == b"new\n"


def test_append_creates_missing_file(goawk, tmp_path):
    """>> creates the file when it does not exist."""
    # CATCHES: >> on a missing file must create it, not error.
    result = goawk(['BEGIN { print "app" >> "g.txt" }'])
    assert result.returncode == 0
    assert read_file(tmp_path / "g.txt") == b"app\n"


def test_append_after_close_continues(goawk, tmp_path):
    """After close(), >> opens the file again and appends."""
    # CATCHES: close() forgets the stream, so the next >> really appends.
    result = goawk(
        ['BEGIN { print "aaaa" > "f.txt"; close("f.txt"); print "b" >> "f.txt" }']
    )
    assert result.returncode == 0
    assert read_file(tmp_path / "f.txt") == b"aaaa\nb\n"


def test_greater_after_close_truncates(goawk, tmp_path):
    """After close(), > reopens and truncates the file."""
    # CATCHES: a cached stream would append instead of truncating.
    result = goawk(
        ['BEGIN { print "aaaa" > "f.txt"; close("f.txt"); print "b" > "f.txt" }']
    )
    assert result.returncode == 0
    assert read_file(tmp_path / "f.txt") == b"b\n"


def test_greater_after_append_reuses_open_stream(goawk, tmp_path):
    """While a stream is open, the > vs >> operator is ignored."""
    # CATCHES: once "f.txt" is open via >>, a later > must not truncate it.
    result = goawk(['BEGIN { print "a" >> "f.txt"; print "b" > "f.txt" }'])
    assert result.returncode == 0
    assert read_file(tmp_path / "f.txt") == b"a\nb\n"


def test_printf_redirect_writes_the_same_stream(goawk, tmp_path):
    """printf honours redirection exactly like print."""
    # CATCHES: printf must write through the same stream machinery, so the
    # file ends up with exactly the formatted bytes.
    result = goawk(['BEGIN { printf "%s=%d\\n", "x", 5 > "h.txt" }'])
    assert result.returncode == 0
    assert read_file(tmp_path / "h.txt") == b"x=5\n"


def test_redirect_destination_may_be_any_expression(goawk, tmp_path):
    """The destination is evaluated; each distinct name gets its own file."""
    # CATCHES: streams are keyed by the evaluated name string, so changing a
    # variable redirects to a different file.
    result = goawk(
        ['BEGIN { f = "e1.txt"; print "to-e1" > f; f = "e2.txt"; print "to-e2" > f }']
    )
    assert result.returncode == 0
    assert read_file(tmp_path / "e1.txt") == b"to-e1\n"
    assert read_file(tmp_path / "e2.txt") == b"to-e2\n"


def test_redirect_destination_from_parenthesised_expression(goawk, tmp_path):
    """A parenthesised concatenation is a valid destination expression."""
    # CATCHES: "print > ("a" "b")" must concatenate before opening the file.
    result = goawk(['BEGIN { print "x" > ("c" "c" ".txt") }'])
    assert result.returncode == 0
    assert read_file(tmp_path / "cc.txt") == b"x\n"


def test_record_separator_applies_to_redirected_writes(goawk, tmp_path):
    """Redirected prints still end with ORS and join with OFS."""
    # CATCHES: redirection must not fall back to a hard-coded "\\n".
    result = goawk(
        ['BEGIN { OFS = "|"; ORS = ";\\n"; print "a", "b" > "f.txt" }']
    )
    assert result.returncode == 0
    assert read_file(tmp_path / "f.txt") == b"a|b;\n"


def test_pipe_sends_print_output_to_a_shell_command(goawk):
    """``print | "cmd"`` pipes into /bin/sh -c and its output reaches stdout."""
    # CATCHES: the pipe target runs via the shell, so shell syntax works and
    # the child's stdout is forwarded to the program's stdout.
    result = goawk(['BEGIN { print "hello" | "tr a-z A-Z" }'])
    assert result.returncode == 0
    assert result.stdout == b"HELLO\n"
    assert result.stderr == b""


def test_pipe_reuses_the_stream_for_the_same_command(goawk):
    """Two prints to the same command string share one pipe and one process."""
    # CATCHES: a new process per print would uppercase only via one tr and
    # could reorder; both lines must flow through the same tr invocation.
    result = goawk(
        ['BEGIN { print "hello" | "tr a-z A-Z"; print "world" | "tr a-z A-Z" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"HELLO\nWORLD\n"
    assert result.stderr == b""


def test_greater_after_pipe_reuses_the_pipe_stream(goawk):
    """A name already open as a pipe is reused even for the > operator."""
    # CATCHES: "print > cmd" after "print | cmd" must not create a file named
    # after the command; the second line goes through the same pipe (and is
    # therefore uppercased too).
    result = goawk(
        ['BEGIN { print "a" | "tr a-z A-Z"; print "b" > "tr a-z A-Z" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"A\nB\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "command,expected_stdout,expected_stderr",
    [
        ("cat", b"x\ncode: 0\n", b""),
        ("false", b"code: 1\n", b""),
        ('sh -c \\"exit 3\\"', b"code: 3\n", b""),
        (
            "nonexistent-command-xyz",
            b"code: 127\n",
            b"/bin/sh: 1: nonexistent-command-xyz: not found\n",
        ),
        ("read l; kill -TERM $$", b"code: 271\n", b""),
    ],
)
def test_close_of_a_pipe_returns_the_command_exit_status(
    goawk, command, expected_stdout, expected_stderr
):
    """close("cmd") waits for the command and returns its exit status."""
    # CATCHES: exit status mapping is 0/1/3 for normal exits, 127 for a
    # command the shell cannot find, and 256+15 for death by SIGTERM; only
    # "cat" echoes the piped line back.  The TERM command reads the piped
    # line before killing itself so the flush at close() never races an
    # already-dead reader (which would add a spurious broken-pipe error).
    program = 'BEGIN { print "x" | "%s"; print "code:", close("%s") }' % (
        command,
        command,
    )
    result = goawk([program])
    assert result.returncode == 0
    assert result.stdout == expected_stdout
    assert result.stderr == expected_stderr


def test_close_of_an_output_file_returns_zero(goawk):
    """close() of an output file returns 0 and a second close returns -1."""
    # CATCHES: after close() the name is unregistered, so closing again
    # reports -1 like any unopened name.
    result = goawk(
        ['BEGIN { print "x" > "c.txt"; print "close:", close("c.txt"), close("c.txt") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"close: 0 -1\n"
    assert result.stderr == b""


def test_close_of_an_unopened_name_returns_minus_one(goawk):
    """close() of a name that was never opened returns -1 without an error."""
    # CATCHES: an unopened name is not an error message, just a -1 result.
    result = goawk(['BEGIN { print "close:", close("never-opened-file") }'])
    assert result.returncode == 0
    assert result.stdout == b"close: -1\n"
    assert result.stderr == b""


def test_dev_stdout_redirect_writes_to_standard_output(goawk):
    """``> "/dev/stdout"`` writes to the program's stdout, not a file."""
    # CATCHES: /dev/stdout must be special-cased rather than opened as a file,
    # and the output must appear in stdout order.
    result = goawk(['BEGIN { print "normal"; print "dev" > "/dev/stdout" }'])
    assert result.returncode == 0
    assert result.stdout == b"normal\ndev\n"
    assert result.stderr == b""


def test_dev_stderr_redirect_writes_to_standard_error(goawk):
    """``> "/dev/stderr"`` writes to the program's stderr."""
    # CATCHES: the message must land on stderr while stdout stays empty.
    result = goawk(['BEGIN { print "dev2" > "/dev/stderr" }'])
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b"dev2\n"


def test_dash_redirect_writes_to_standard_output(goawk):
    """The filename "-" means stdout for both > and >>."""
    # CATCHES: "-" is a special name; no file named "-" may be created and
    # the append operator must behave identically.
    result = goawk(['BEGIN { print "out"; print "dash" > "-" }'])
    assert result.returncode == 0
    assert result.stdout == b"out\ndash\n"
    assert result.stderr == b""


def test_special_stream_names_are_not_registered_streams(goawk):
    """close() and fflush() do not know /dev/stdout, /dev/stderr or "-"."""
    # CATCHES: these names are never entered in the stream table, so
    # close("/dev/stderr") returns -1 and fflush("/dev/stdout") errors.
    result = goawk(
        ['BEGIN { print "x" > "/dev/stderr"; print "close:", close("/dev/stderr") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"close: -1\n"
    assert result.stderr == b"x\n"
    result = goawk(
        ['BEGIN { print "x" > "/dev/stdout"; print "fflush:", fflush("/dev/stdout") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"x\nfflush: -1\n"
    assert result.stderr == b'error flushing "/dev/stdout": not an output file or pipe\n'


def test_dev_null_is_a_real_output_file(goawk):
    """Unlike /dev/stdout, /dev/null is opened as an ordinary file stream."""
    # CATCHES: close("/dev/null") returns 0 because it is a registered file
    # stream rather than a special name.
    result = goawk(
        ['BEGIN { print "x" > "/dev/null"; print "close:", close("/dev/null") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"close: 0\n"
    assert result.stderr == b""


def test_unopenable_destination_is_a_runtime_error(goawk):
    """A destination that cannot be created aborts with a precise message."""
    # CATCHES: the error text names the failing path operation and the exit
    # status is 1.
    result = goawk(['BEGIN { print "x" > "/nonexistent-dir-xyz/f.txt" }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b"output redirection error: open /nonexistent-dir-xyz/f.txt:"
        b" no such file or directory\n"
    )


def test_cannot_write_to_a_reader_stream(goawk):
    """A name opened for reading cannot then be used as a print target."""
    # CATCHES: the same name in the input-stream table must be rejected with
    # "can't write to reader stream" and exit status 1.
    result = goawk(['BEGIN { "cat" | getline x; print "y" > "cat" }'])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"can't write to reader stream\n"


def test_cannot_read_from_a_writer_stream(goawk, tmp_path):
    """A name opened for writing cannot then be used as a getline source."""
    # CATCHES: getline on a writer's name fails with "can't read from writer
    # stream" rather than reading back the buffered data.
    result = goawk(
        ['BEGIN { print "y" > "f.txt"; getline line < "f.txt"; print line }']
    )
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"can't read from writer stream\n"


def test_write_to_a_pipe_closed_by_the_reader_fails(goawk):
    """Writing to a pipe whose reader exited early is a fatal write error."""
    # CATCHES: the EPIPE surfaces as "write |1: broken pipe" with exit
    # status 1 once the 64KB stream buffer overflows.
    result = goawk(
        [
            'BEGIN { s = "xxxxxxxxxxxxxxxx"; '
            'for (i = 0; i < 10000; i++) print s | "head -1" }'
        ]
    )
    assert result.returncode == 1
    assert result.stdout == b"xxxxxxxxxxxxxxxx\n"
    assert result.stderr == b"write |1: broken pipe\n"


def test_closed_file_can_be_reopened_for_reading(goawk, tmp_path):
    """After close() a file can be read back through getline."""
    # CATCHES: close() must flush and close the file so the data written is
    # immediately readable by the same program.
    result = goawk(
        ['BEGIN { print "a" > "f.txt"; close("f.txt");'
         ' getline line < "f.txt"; print "read:", line }']
    )
    assert result.returncode == 0
    assert result.stdout == b"read: a\n"
    assert result.stderr == b""
