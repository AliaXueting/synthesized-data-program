"""Output write-error paths in io.go: print/printf failing mid-program
against a full device, fflush("") reporting a failing stream, fflush with an
unbuffered stdout, and CSV output to the unbuffered stderr stream."""

import os

import pytest


def require_dev_full():
    """Skip tests that need /dev/full when it is not present."""
    if not os.path.exists("/dev/full"):
        pytest.skip("/dev/full is not available in this environment")


def test_bare_print_write_error_on_stdout_aborts(goawk):
    """A bare print that cannot write stdout fails the program."""
    # CATCHES: with stdout pointing at the full device (a character device,
    # so output is unbuffered) the very first print fails with the exact
    # "write /dev/stdout: no space left on device" error and status 1.
    require_dev_full()
    result = goawk(['BEGIN { print }'], stdout_path="/dev/full")
    assert result.returncode == 1
    assert result.stderr == b"write /dev/stdout: no space left on device\n"


def test_multivalue_print_write_error_on_stdout_aborts(goawk):
    """A print with several arguments hits the same write error."""
    # CATCHES: the OFS/ORS writes around the arguments are checked too, not
    # just the argument text itself.
    require_dev_full()
    result = goawk(['BEGIN { print "a", "b" }'], stdout_path="/dev/full")
    assert result.returncode == 1
    assert result.stderr == b"write /dev/stdout: no space left on device\n"


def test_printf_write_error_on_stdout_aborts(goawk):
    """A printf that cannot write stdout fails the program the same way."""
    # CATCHES: printf shares the output writer, so its write error is the
    # identical message and status 1.
    require_dev_full()
    result = goawk(['BEGIN { printf "%s %s\\n", "a", "b" }'], stdout_path="/dev/full")
    assert result.returncode == 1
    assert result.stderr == b"write /dev/stdout: no space left on device\n"


def test_print_arguments_write_error_surfaces_from_print(goawk):
    """Buffer overflow on a redirected full device fails at the print."""
    # CATCHES: more than the 64KB stream buffer of "a <i> c" records forces
    # the flush error out of print itself (not only at close), with status 1.
    require_dev_full()
    result = goawk(
        [
            'BEGIN { for (i = 0; i < 20000; i++) print "a", i, "c" > "/dev/full" }',
        ]
    )
    assert result.returncode == 1
    assert result.stderr == b"write /dev/full: no space left on device\n"


def test_fflush_all_reports_the_failing_stream(goawk):
    """fflush("") returns -1 and logs the failing stream by name."""
    # CATCHES: flushing every stream must report the full device with the
    # 'error flushing "/dev/full"' wording while the program still exits 0.
    require_dev_full()
    result = goawk(
        ['BEGIN { print "x" > "/dev/full"; print "rc:", fflush("") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"rc: -1\n"
    assert result.stderr == (
        b'error flushing "/dev/full": write /dev/full: no space left on device\n'
    )


def test_fflush_all_succeeds_with_unbuffered_stdout(goawk, tmp_path):
    """fflush("") returns 0 when stdout is a character device."""
    # CATCHES: with stdout on /dev/null goawk uses raw (unbuffered) stdout,
    # which is not a flusher; fflush("") must still succeed and report 0
    # through a /dev/stderr write rather than erroring.
    result = goawk(
        [
            'BEGIN { print "a" > "ff.txt"; printf "rc %d\\n", fflush("") > "/dev/stderr" }',
        ],
        stdout_path="/dev/null",
    )
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b"rc 0\n"
    assert (tmp_path / "ff.txt").read_bytes() == b"a\n"


def test_csv_output_to_dev_stderr_reuses_the_buffer(goawk):
    """Two CSV prints to /dev/stderr both come out fully formatted."""
    # CATCHES: /dev/stderr is not a buffered writer, so CSV output builds a
    # private buffer around it; the second print must reset and reuse that
    # buffer, producing a second properly quoted record.
    result = goawk(
        [
            '-o', 'csv',
            'BEGIN { print "a,x" > "/dev/stderr"; print "b" > "/dev/stderr" }',
        ]
    )
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b'"a,x"\nb\n'
