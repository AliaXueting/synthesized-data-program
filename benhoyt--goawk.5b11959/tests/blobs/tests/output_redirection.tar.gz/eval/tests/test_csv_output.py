"""CSV output mode (-o csv / -o tsv / OUTPUTMODE): which print statements are
CSV-formatted, RFC 4180 quoting rules, and mode parsing errors."""

import pytest


def read_file(path):
    with open(path, "rb") as handle:
        return handle.read()


def awk_string(text):
    """Escape text for use inside an AWK double-quoted string literal."""
    return (
        text.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
    )


def test_csv_output_quotes_fields_that_need_it(goawk):
    """Only fields containing special characters get wrapped in quotes."""
    # CATCHES: the plain field and the tab field stay unquoted while the
    # comma, quote and newline fields are quoted with doubled inner quotes.
    result = goawk(
        [
            "-o",
            "csv",
            'BEGIN { print "plain", "with,comma", "with\\"quote",'
            ' "with\\nnewline", "with\\ttab" }',
        ]
    )
    assert result.returncode == 0
    assert result.stdout == (
        b'plain,"with,comma","with""quote","with\nnewline",with\ttab\n'
    )
    assert result.stderr == b""


@pytest.mark.parametrize(
    "field,expected",
    [
        ("plain", b"plain,c\n"),
        ("with,comma", b'"with,comma",c\n'),
        ('say "hi"', b'"say ""hi""",c\n'),
        ("two\nlines", b'"two\nlines",c\n'),
        ("carriage\rreturn", b'"carriage\rreturn",c\n'),
        (" leading", b'" leading",c\n'),
        ("trailing ", b"trailing ,c\n"),
        ("tab\tinside", b"tab\tinside,c\n"),
    ],
)
def test_csv_output_field_quoting_rules(goawk, field, expected):
    """Each field value is quoted exactly when RFC 4180 (plus the reference's
    extra rules for CR and leading whitespace) requires it."""
    # CATCHES: the reference also quotes fields that start with whitespace or
    # contain a carriage return, which a naive RFC 4180 writer misses.
    result = goawk(["-o", "csv", 'BEGIN { print "%s", "c" }' % awk_string(field)])
    assert result.returncode == 0
    assert result.stdout == expected
    assert result.stderr == b""


def test_csv_output_field_equal_to_separator_is_quoted(goawk):
    """A field consisting of just the separator is quoted."""
    # CATCHES: the single comma field must be emitted as "," and not as an
    # empty pair of fields.
    result = goawk(["-o", "csv", 'BEGIN { print ",", "c" }'])
    assert result.returncode == 0
    assert result.stdout == b'",",c\n'
    assert result.stderr == b""


def test_csv_output_quotes_field_starting_with_unicode_space(goawk):
    """A leading non-breaking space also triggers quoting."""
    # CATCHES: the quoting rule is "first rune is whitespace", which includes
    # U+00A0, not just ASCII space and tab.
    result = goawk(["-o", "csv", 'BEGIN { print " x", "y" }'])
    assert result.returncode == 0
    assert result.stdout == b'"\xc2\xa0x",y\n'
    assert result.stderr == b""


def test_csv_output_quotes_backslash_dot_field(goawk):
    """The field "\\." is quoted (matches the Go encoding/csv writer)."""
    # CATCHES: the reference inherits encoding/csv's special case for the
    # literal two-character field backslash-dot.
    result = goawk(["-o", "csv", 'BEGIN { print "\\\\.", "y" }'])
    assert result.returncode == 0
    assert result.stdout == b'"\\.",y\n'
    assert result.stderr == b""


def test_csv_output_empty_fields(goawk):
    """Empty fields produce empty (unquoted) columns."""
    # CATCHES: an empty field must not be quoted as "".
    result = goawk(["-o", "csv", 'BEGIN { print "", "", "c" }'])
    assert result.returncode == 0
    assert result.stdout == b",,c\n"
    assert result.stderr == b""


def test_csv_output_print_without_arguments_is_raw(goawk):
    """A bare print writes $0 unquoted even in CSV output mode."""
    # CATCHES: the record is written raw, so embedded separators and quotes
    # are NOT escaped for a bare print.
    result = goawk(["-o", "csv", "{ print }"], stdin=b'a,b\n"c,d",e\n')
    assert result.returncode == 0
    assert result.stdout == b'a,b\n"c,d",e\n'
    assert result.stderr == b""


def test_csv_output_print_dollar0_is_one_quoted_field(goawk):
    """print $0 in CSV mode is a one-field record and therefore quoted."""
    # CATCHES: unlike a bare print, print $0 goes through the CSV writer.
    result = goawk(["-o", "csv", "{ print $0 }"], stdin=b'a,b\n"c,d",e\n')
    assert result.returncode == 0
    assert result.stdout == b'"a,b"\n"""c,d"",e"\n'
    assert result.stderr == b""


def test_printf_is_not_csv_formatted(goawk):
    """printf output is untouched by CSV output mode."""
    # CATCHES: printf must not quote its result even when a field would need
    # quoting under the CSV rules.
    result = goawk(
        ["-o", "csv", 'BEGIN { printf "%s,%s\\n", "a,b", "c" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"a,b,c\n"
    assert result.stderr == b""


def test_csv_output_ignores_ofs_and_ors(goawk):
    """OFS and ORS have no effect on a CSV print with arguments."""
    # CATCHES: setting OFS="|" and ORS=";\\n" must not change the CSV record.
    result = goawk(
        ["-o", "csv", 'BEGIN { OFS = "|"; ORS = ";\\n"; print "a", "b" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"a,b\n"
    assert result.stderr == b""


def test_csv_output_single_argument(goawk):
    """A single-argument print in CSV mode writes one field plus newline."""
    # CATCHES: the record is still terminated by a newline, not ORS.
    result = goawk(["-o", "csv", 'BEGIN { print "a" }'])
    assert result.returncode == 0
    assert result.stdout == b"a\n"
    assert result.stderr == b""


def test_csv_output_numbers_use_ofmt(goawk):
    """Numeric arguments are formatted with OFMT before CSV quoting."""
    # CATCHES: OFMT changes are honoured per field ("0.33" after "%.2f").
    result = goawk(
        ["-o", "csv", 'BEGIN { print 1/3; OFMT = "%.2f"; print 1/3; print 2 }']
    )
    assert result.returncode == 0
    assert result.stdout == b"0.333333\n0.33\n2\n"
    assert result.stderr == b""


def test_tsv_output_uses_tab_separator(goawk):
    """-o tsv separates fields with a tab and quotes tab-containing fields."""
    # CATCHES: with a tab separator a comma field is NOT quoted while a field
    # containing a tab IS.
    result = goawk(["-o", "tsv", 'BEGIN { print "a,b", "a\\tb", "c" }'])
    assert result.returncode == 0
    assert result.stdout == b'a,b\t"a\tb"\tc\n'
    assert result.stderr == b""


@pytest.mark.parametrize(
    "mode,field,expected",
    [
        ("csv separator=|", "a|b", b'"a|b"|c\n'),
        ("csv separator=,", "a,b", b'"a,b",c\n'),
        ("csv separator=|", "a,b", b"a,b|c\n"),
        ("csv separator=é", "aéb", b'"a\xc3\xa9b"\xc3\xa9c\n'),
    ],
)
def test_csv_output_separator_override(goawk, mode, field, expected):
    """separator=<char> changes both the separator and the quoting trigger."""
    # CATCHES: quoting follows the configured separator, so with "|" a comma
    # is an ordinary character and a pipe is quoted.
    result = goawk(["-o", mode, 'BEGIN { print "%s", "c" }' % field])
    assert result.returncode == 0
    assert result.stdout == expected
    assert result.stderr == b""


def test_outputmode_variable_enables_csv_output(goawk):
    """Setting OUTPUTMODE in BEGIN is equivalent to -o csv."""
    # CATCHES: the special variable must be honoured at run time.
    result = goawk(['BEGIN { OUTPUTMODE = "csv"; print "a,b", "c" }'])
    assert result.returncode == 0
    assert result.stdout == b'"a,b",c\n'
    assert result.stderr == b""


def test_outputmode_variable_reports_its_value(goawk):
    """Reading OUTPUTMODE back returns the parsed mode string."""
    # CATCHES: OUTPUTMODE round-trips as the canonical "csv" string.
    result = goawk(['BEGIN { OUTPUTMODE = "csv"; print OUTPUTMODE }'])
    assert result.returncode == 0
    assert result.stdout == b"csv\n"
    assert result.stderr == b""


def test_outputmode_variable_with_separator(goawk):
    """OUTPUTMODE accepts the same "csv separator=X" syntax as -o."""
    # CATCHES: the variable form supports the full option syntax.
    result = goawk(
        ['BEGIN { OUTPUTMODE = "csv separator=|"; print "a|b", "c" }']
    )
    assert result.returncode == 0
    assert result.stdout == b'"a|b"|c\n'
    assert result.stderr == b""


def test_outputmode_empty_string_restores_default_mode(goawk):
    """Assigning "" to OUTPUTMODE returns to OFS/ORS-based output."""
    # CATCHES: an empty mode string is valid and disables CSV output.
    result = goawk(
        ['BEGIN { OUTPUTMODE = ""; print "a,b", "c" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"a,b c\n"
    assert result.stderr == b""


def test_outputmode_invalid_value_is_a_runtime_error(goawk):
    """An invalid OUTPUTMODE aborts after earlier output has been printed."""
    # CATCHES: the error message is 'invalid output mode "bogus"', stdout
    # keeps what was printed before, and the exit status is 1.
    result = goawk(['BEGIN { print "x"; OUTPUTMODE = "bogus" }'])
    assert result.returncode == 1
    assert result.stdout == b"x\n"
    assert result.stderr == b'invalid output mode "bogus"\n'


@pytest.mark.parametrize(
    "mode,message",
    [
        ("csv separator=ab", b'invalid CSV/TSV separator "ab"\n'),
        ("csv foo=1", b'invalid output mode key "foo"\n'),
        ('csv separator="', b"invalid CSV field separator or comment delimiter\n"),
    ],
)
def test_outputmode_option_errors(goawk, mode, message):
    """Bad OUTPUTMODE values fail with these exact messages."""
    # CATCHES: each malformed mode has its own message, including the
    # multi-character separator and the disallowed quote separator.
    result = goawk(['BEGIN { OUTPUTMODE = "%s" }' % awk_string(mode)])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == message


def test_o_flag_with_invalid_mode(goawk):
    """-o with an unknown mode fails before running the program."""
    # CATCHES: the CLI flag reports 'invalid output mode "xyz"' and exits 1.
    result = goawk(["-oxyz", "BEGIN { }"])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b'invalid output mode "xyz"\n'


def test_o_flag_requires_an_argument(goawk):
    """-o with no argument is a usage error."""
    # CATCHES: the missing argument message is 'flag needs an argument: -o'.
    result = goawk(["-o"])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"flag needs an argument: -o\n"


@pytest.mark.parametrize("args", [[ "-ocsv" ], [ "-o", "csv" ]])
def test_o_flag_attached_and_separate_forms(goawk, args):
    """-ocsv and "-o csv" behave identically."""
    # CATCHES: both spellings of the option must enable CSV output.
    result = goawk(args + ['BEGIN { print "a,b", "c" }'])
    assert result.returncode == 0
    assert result.stdout == b'"a,b",c\n'
    assert result.stderr == b""


def test_outputmode_from_v_flag(goawk):
    """-v OUTPUTMODE=... also enables CSV output mode."""
    # CATCHES: the -v variable assignment path must configure output mode.
    result = goawk(
        ["-v", "OUTPUTMODE=csv separator=|", 'BEGIN { print "a|b", "c" }']
    )
    assert result.returncode == 0
    assert result.stdout == b'"a|b"|c\n'
    assert result.stderr == b""


def test_field_assignment_rebuilds_record_with_csv_rules(goawk):
    """$1=$1 re-joins the fields using CSV output formatting."""
    # CATCHES: the rebuilt $0 quotes the field that contains a separator, so
    # a later bare print writes the CSV-encoded record.
    result = goawk(
        ["-i", "csv", "-o", "csv", '{ $1 = $1; print }'],
        stdin=b'a,"b,c"\n',
    )
    assert result.returncode == 0
    assert result.stdout == b'a,"b,c"\n'
    assert result.stderr == b""


def test_field_assignment_rebuilds_record_for_tsv(goawk):
    """$1=$1 in TSV output mode re-joins with tabs and quotes as needed."""
    # CATCHES: converting CSV to TSV quotes a field only if it contains a
    # tab, so "b,c" stays bare while a tab-containing field gets quoted.
    result = goawk(
        ["-i", "csv", "-o", "tsv", '{ $1 = $1; print }'],
        stdin=b'a,"b,c"\n',
    )
    assert result.returncode == 0
    assert result.stdout == b"a\tb,c\n"
    assert result.stderr == b""


def test_field_assignment_rebuild_quotes_tab_field_for_tsv(goawk):
    """A field containing a tab is quoted when rebuilding a TSV record."""
    # CATCHES: the CSV joiner must consider the target separator, not a
    # hard-coded comma.
    result = goawk(
        ["-i", "csv", "-o", "tsv", '{ $1 = $1; print }'],
        stdin=b'a,"b\tc"\n',
    )
    assert result.returncode == 0
    assert result.stdout == b'a\t"b\tc"\n'
    assert result.stderr == b""


def test_csv_output_to_a_redirected_file(goawk, tmp_path):
    """CSV formatting applies to prints redirected into a file."""
    # CATCHES: redirection must not bypass the CSV writer.
    result = goawk(["-o", "csv", 'BEGIN { print "a,b", "c" > "cf.txt" }'])
    assert result.returncode == 0
    assert read_file(tmp_path / "cf.txt") == b'"a,b",c\n'


def test_csv_output_to_a_pipe(goawk):
    """CSV formatting applies to prints piped into a command."""
    # CATCHES: a piped print also goes through the CSV writer.
    result = goawk(["-o", "csv", 'BEGIN { print "a,b", "c" | "cat" }'])
    assert result.returncode == 0
    assert result.stdout == b'"a,b",c\n'
    assert result.stderr == b""


def test_csv_output_to_dev_stderr(goawk):
    """CSV formatting applies when writing to /dev/stderr."""
    # CATCHES: the /dev/stderr special name keeps CSV formatting.
    result = goawk(["-o", "csv", 'BEGIN { print "a,b", "c" > "/dev/stderr" }'])
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b'"a,b",c\n'
