"""Output stream lifecycle: fflush(), close(), buffering of redirected
writes, and the guaranteed flush/close of every stream at program exit."""

import os

import pytest


def read_file(path):
    with open(path, "rb") as handle:
        return handle.read()


def require_dev_full():
    """Skip tests that need /dev/full when it is not present."""
    if not os.path.exists("/dev/full"):
        pytest.skip("/dev/full is not available in this environment")


def test_fflush_of_a_named_stream_returns_zero(goawk, tmp_path):
    """fflush("name") flushes one open stream and returns 0."""
    # CATCHES: the return value of a successful flush is the number 0, which
    # print must render as "0" rather than "" or "true".
    result = goawk(
        ['BEGIN { print "x" > "ff.txt"; print "fflush:", fflush("ff.txt") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"fflush: 0\n"
    assert result.stderr == b""
    assert read_file(tmp_path / "ff.txt") == b"x\n"


def test_fflush_with_no_arguments_returns_zero(goawk, tmp_path):
    """fflush() with no arguments flushes every open stream."""
    # CATCHES: the no-argument form is valid and returns 0 on success.
    result = goawk(
        ['BEGIN { print "x" > "ff.txt"; print "fflush:", fflush() }']
    )
    assert result.returncode == 0
    assert result.stdout == b"fflush: 0\n"
    assert result.stderr == b""


def test_fflush_with_empty_string_returns_zero(goawk, tmp_path):
    """fflush("") is equivalent to fflush() and flushes all streams."""
    # CATCHES: only a non-empty name selects a single stream; the empty
    # string must mean "all streams".
    result = goawk(
        ['BEGIN { print "x" > "ff.txt"; print "fflush:", fflush("") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"fflush: 0\n"
    assert result.stderr == b""


def test_fflush_of_an_unopened_name_errors(goawk):
    """fflush of a name that is not an open stream returns -1 and logs why."""
    # CATCHES: the exact stderr text is
    # 'error flushing "nope.txt": not an output file or pipe'.
    result = goawk(['BEGIN { print "fflush:", fflush("nope.txt") }'])
    assert result.returncode == 0
    assert result.stdout == b"fflush: -1\n"
    assert result.stderr == b'error flushing "nope.txt": not an output file or pipe\n'


def test_fflush_of_a_closed_stream_errors(goawk, tmp_path):
    """After close() the name is unknown to fflush() again."""
    # CATCHES: close() unregisters the stream, so a later fflush reports
    # "not an output file or pipe" rather than succeeding.
    result = goawk(
        ['BEGIN { print "a" > "z.txt"; close("z.txt"); print fflush("z.txt") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"-1\n"
    assert result.stderr == b'error flushing "z.txt": not an output file or pipe\n'


def test_fflush_then_more_writes_continue_the_file(goawk, tmp_path):
    """Writes after fflush() continue at the same position in the file."""
    # CATCHES: flushing must not close or reopen the stream, so the second
    # line lands after the first instead of overwriting it.
    result = goawk(
        ['BEGIN { print "a" > "ff2.txt"; fflush("ff2.txt"); print "b" > "ff2.txt" }']
    )
    assert result.returncode == 0
    assert read_file(tmp_path / "ff2.txt") == b"a\nb\n"


def test_fflush_flushes_stdout_before_a_blocking_read(interact):
    """fflush() pushes pending stdout out before the program blocks."""
    # CATCHES: stdout is buffered when it is not a terminal, so without
    # fflush() the "first" line would still be in the buffer while the
    # program waits on getline.
    outcome = interact(
        ['BEGIN { print "first"; fflush(); getline line < "-"; print "second: " line }'],
        b"hi\n",
    )
    assert outcome["returncode"] == 0
    assert outcome["early"] == b"first\n"
    assert outcome["stdout"] == b"first\nsecond: hi\n"
    assert outcome["stderr"] == b""


def test_bare_getline_flushes_pending_stdout(interact):
    """An unredirected getline flushes stdout first (prompt support)."""
    # CATCHES: GoAWK flushes buffered stdout before reading a record, so a
    # prompt written with printf appears before the program blocks.
    outcome = interact(
        ['BEGIN { printf "prompt: "; getline line; print "got " line }'],
        b"hi\n",
    )
    assert outcome["returncode"] == 0
    assert outcome["early"] == b"prompt: "
    assert outcome["stdout"] == b"prompt: got hi\n"
    assert outcome["stderr"] == b""


def test_redirected_file_is_complete_at_program_exit(goawk, tmp_path):
    """An output file is flushed and closed at exit without an explicit close."""
    # CATCHES: 10000 records exceed the stream buffer, so the file is only
    # complete if every open stream is flushed before the process exits.
    result = goawk(
        ['BEGIN { for (i = 0; i < 10000; i++) print "x" i > "big.txt" }']
    )
    assert result.returncode == 0
    assert result.stdout == b""
    content = read_file(tmp_path / "big.txt")
    assert len(content.splitlines()) == 10000
    assert content.endswith(b"x9998\nx9999\n")


def test_open_pipe_is_flushed_and_closed_at_program_exit(goawk):
    """A pipe left open at exit is flushed, so the command output appears."""
    # CATCHES: without the exit-time flush/close the "row" lines would be
    # lost when the process exits.
    result = goawk(
        ['BEGIN { for (i = 0; i < 3; i++) print "row" i | "cat"; print "done" }']
    )
    assert result.returncode == 0
    assert result.stdout == b"done\nrow0\nrow1\nrow2\n"
    assert result.stderr == b""


def test_multiple_output_files_are_each_complete(goawk, tmp_path):
    """Interleaved writes to several files keep per-file order and finish."""
    # CATCHES: every open file must be flushed at exit and each file must
    # contain its own records in order.
    result = goawk(
        [
            'BEGIN { for (i = 1; i <= 3; i++) { '
            'print "a" i > "i1.txt"; print "b" i > "i2.txt" } }',
        ]
    )
    assert result.returncode == 0
    assert read_file(tmp_path / "i1.txt") == b"a1\na2\na3\n"
    assert read_file(tmp_path / "i2.txt") == b"b1\nb2\nb3\n"


def test_close_reports_write_failures_on_stderr(goawk):
    """close() returns -1 and logs 'error closing' when flushing fails."""
    # CATCHES: on a full device the buffered data cannot be flushed, so
    # close() returns -1 and writes 'error closing "/dev/full": ...' to
    # stderr while the exit status stays 0.
    require_dev_full()
    result = goawk(['BEGIN { print "x" > "/dev/full"; print "close:", close("/dev/full") }'])
    assert result.returncode == 0
    assert result.stdout == b"close: -1\n"
    assert result.stderr == (
        b'error closing "/dev/full": write /dev/full: no space left on device\n'
    )


def test_fflush_reports_write_failures_on_stderr(goawk):
    """fflush() returns -1 and logs 'error flushing' when the write fails."""
    # CATCHES: a failed flush is reported per stream name with the underlying
    # error, and the return value is -1.
    require_dev_full()
    result = goawk(['BEGIN { print "x" > "/dev/full"; print "fflush:", fflush("/dev/full") }'])
    assert result.returncode == 0
    assert result.stdout == b"fflush: -1\n"
    assert result.stderr == (
        b'error flushing "/dev/full": write /dev/full: no space left on device\n'
    )


def test_buffer_overflow_write_error_aborts_the_program(goawk):
    """A write error surfacing during print aborts the program with status 1."""
    # CATCHES: once more than one buffer of data is written to /dev/full the
    # error surfaces from print itself, not just at flush time.
    require_dev_full()
    result = goawk(
        [
            'BEGIN { s = "xxxxxxxxxxxxxxxx"; '
            'for (i = 0; i < 80000; i++) print s > "/dev/full" }',
        ]
    )
    assert result.returncode == 1
    assert result.stderr == b"write /dev/full: no space left on device\n"
