"""Input-side streams in io.go/iostream.go reached from AWK: getline from
files, pipes and stdin, the close() results for input streams (including
the raw wait statuses of piped commands), and the errors those raise."""

import pytest


def read_file(path):
    with open(path, "rb") as handle:
        return handle.read()


def test_getline_from_a_file_reads_consecutive_lines(goawk, tmp_path):
    """Two getlines on the same filename reuse the one open stream."""
    # CATCHES: the second getline must continue at the second line, not
    # reopen the file and return the first line again.
    (tmp_path / "g.txt").write_bytes(b"l1\nl2\n")
    result = goawk(
        ['BEGIN { getline a < "g.txt"; getline b < "g.txt"; print a "|" b }']
    )
    assert result.returncode == 0
    assert result.stdout == b"l1|l2\n"
    assert result.stderr == b""


def test_getline_from_missing_file_returns_minus_one(goawk):
    """getline on an unopenable file returns -1 without failing the program."""
    # CATCHES: the failed open is reported through getline's return value
    # only: the variable is untouched (empty), ERRNO stays empty, and the
    # program keeps running and exits 0.
    result = goawk(
        ['BEGIN { n = (getline l < "nope.txt"); print n, l, ERRNO }']
    )
    assert result.returncode == 0
    assert result.stdout == b"-1  \n"
    assert result.stderr == b""


def test_getline_from_stdin_dash_reads_lines(goawk):
    """getline < "-" reads from stdin, and a second call continues it."""
    # CATCHES: "-" is a special name meaning stdin; both lines come from
    # the same stdin scanner.
    result = goawk(
        ['BEGIN { getline x < "-"; getline y < "-"; print x "|" y }'],
        stdin=b"a\nb\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"a|b\n"
    assert result.stderr == b""


def test_close_of_stdin_dash_is_not_a_stream(goawk):
    """close("-") returns -1 because the stdin name is never registered."""
    # CATCHES: getline < "-" caches a scanner but no input stream, so
    # close("-") reports "not open" like any other unknown name.
    result = goawk(
        ['BEGIN { getline x < "-"; print x, close("-") }'], stdin=b"a\n"
    )
    assert result.returncode == 0
    assert result.stdout == b"a -1\n"
    assert result.stderr == b""


def test_command_getline_reads_command_output(goawk):
    """"cmd" | getline reads the command's stdout via /bin/sh -c."""
    # CATCHES: the pipe input path runs through the shell, so the line read
    # is the command's output.
    result = goawk(['BEGIN { "echo hi" | getline v; print v }'])
    assert result.returncode == 0
    assert result.stdout == b"hi\n"
    assert result.stderr == b""


def test_command_getline_reuses_the_stream(goawk, tmp_path):
    """A second getline on the same command string continues the same pipe."""
    # CATCHES: both lines are consumed from one stream, so the second
    # getline returns the second line and status 1.
    (tmp_path / "two.txt").write_bytes(b"a\nb\n")
    result = goawk(
        [
            'BEGIN { "cat two.txt" | getline x; '
            'r = ("cat two.txt" | getline y); print x "|" y "|" r }'
        ]
    )
    assert result.returncode == 0
    assert result.stdout == b"a|b|1\n"
    assert result.stderr == b""


def test_command_getline_on_a_writer_stream_name_errors(goawk):
    """A name already open as an output pipe cannot be read with | getline."""
    # CATCHES: getInputScannerPipe rejects the name with "can't read from
    # writer stream"; the buffered pipe output is still flushed to stdout
    # on the way out and the exit status is 1.
    result = goawk(['BEGIN { print "x" | "cat"; "cat" | getline v }'])
    assert result.returncode == 1
    assert result.stdout == b"x\n"
    assert result.stderr == b"can't read from writer stream\n"


def test_close_of_an_input_file_returns_zero(goawk, tmp_path):
    """close() of a file opened by getline returns 0."""
    # CATCHES: input streams are closable too; the first close returns 0
    # and a second close returns -1 (the name was unregistered).
    (tmp_path / "g.txt").write_bytes(b"l1\n")
    result = goawk(
        ['BEGIN { getline a < "g.txt"; print close("g.txt"), close("g.txt") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"0 -1\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "command,expected_close",
    [
        ("echo hi", b"read: hi\nclose: 0\n"),
        ("false", b"close: 1\n"),
        ("exit 3", b"close: 3\n"),
    ],
)
def test_close_of_an_input_pipe_returns_exit_status(goawk, command, expected_close):
    """close() of a command pipe waits and reports the command's status."""
    # CATCHES: close("cmd") returns the child's exit code (0, 1 or 3) just
    # like closing an output pipe does.
    if command == "echo hi":
        program = 'BEGIN { "echo hi" | getline v; print "read: " v; print "close:", close("echo hi") }'
    else:
        program = 'BEGIN { "%s" | getline v; print "close:", close("%s") }' % (
            command,
            command,
        )
    result = goawk([program])
    assert result.returncode == 0
    assert result.stdout == expected_close
    assert result.stderr == b""


def test_close_of_an_input_pipe_twice(goawk):
    """Closing a command pipe twice returns -1 the second time."""
    # CATCHES: the first close unregisters the stream, so the second close
    # is an ordinary "not open" -1 with no error message.
    result = goawk(
        ['BEGIN { "echo hi" | getline v; print close("echo hi"), close("echo hi") }']
    )
    assert result.returncode == 0
    assert result.stdout == b"0 -1\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "label,command,expected_code",
    [
        ("k", "read l; kill -KILL $$", b"k: 265\n"),
        ("s", "sh -c \"read l; ulimit -c unlimited; kill -SEGV $$\"", b"s: 523\n"),
        ("a", "sh -c \"read l; ulimit -c unlimited; kill -ABRT $$\"", b"a: 518\n"),
    ],
)
def test_close_maps_signal_deaths_of_piped_commands(goawk, label, command, expected_code):
    """close() maps signals: 256+signal, or 512+signal when core dumped."""
    # CATCHES: SIGKILL maps to 265 (256+9); with core dumps enabled SIGSEGV
    # maps to 523 (512+11) and SIGABRT to 518 (512+6).  The signal commands
    # read the piped line before killing themselves, so close()'s flush
    # never sees a dead reader (which would add a spurious broken-pipe
    # error on stderr).
    quoted = command.replace('"', '\\"')
    program = 'BEGIN { print "x" | "%s"; print "%s:", close("%s") }' % (
        quoted,
        label,
        quoted,
    )
    result = goawk([program])
    assert result.returncode == 0
    assert result.stdout == expected_code
    assert result.stderr == b""
