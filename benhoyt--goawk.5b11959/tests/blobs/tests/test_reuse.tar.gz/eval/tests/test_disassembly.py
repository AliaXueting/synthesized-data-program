"""VM disassembly dumps behind the -da flag: opcode names, operand formatting,
and section structure, recorded byte-exact from the reference binary. The -da
flag dumps the compiled program to stdout and exits 0 without executing it
(no input files are read, no redirected files are created, no pipes run).
"""

import pytest


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'BEGIN { print ARGC, CONVFMT, FILENAME, FNR, FS, INPUTMODE, NF, NR, OFMT, OFS, ORS, OUTPUTMODE, RLENGTH, RS, RSTART, RT, SUBSEP }', 0, b'        // BEGIN\n0000    Special ARGC\n0002    Special CONVFMT\n0004    Special FILENAME\n0006    Special FNR\n0008    Special FS\n000a    Special INPUTMODE\n000c    Special NF\n000e    Special NR\n0010    Special OFMT\n0012    Special OFS\n0014    Special ORS\n0016    Special OUTPUTMODE\n0018    Special RLENGTH\n001a    Special RS\n001c    Special RSTART\n001e    Special RT\n0020    Special SUBSEP\n0022    Print 17\n\n', b''),
    ],
    ids=['specials-all'],
)
def test_special_var_reads(run, tmp_path, prog, rc, out, err):
    """Reading each of the 17 special variables compiles to a Special opcode that disassembles to the variable's exact name (ARGC..SUBSEP), and a 17-operand print shows the arg count."""
    # CATCHES: exact spelling of every special-variable opcode name
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'BEGIN { FS=","; NR=1; NF=2; SUBSEP="|"; NR++; NR--; getline NR }', 0, b'        // BEGIN\n0000    Str "," (0)\n0002    AssignSpecial FS\n0004    Num 1 (0)\n0006    AssignSpecial NR\n0008    Num 2 (1)\n000a    AssignSpecial NF\n000c    Str "|" (1)\n000e    AssignSpecial SUBSEP\n0010    IncrSpecial 1 NR\n0013    IncrSpecial -1 NR\n0016    GetlineSpecial <illegal> NR\n0019    Drop\n\n', b''),
        (b'BEGIN { NR += 2; NR -= 3; NR *= 2; NR /= 2; NR ^= 2; NR %= 5; OFS = OFS "x" }', 0, b'        // BEGIN\n0000    Num 2 (0)\n0002    AugAssignSpecial AugOpAdd %!d(string=NR)\n0005    Num 3 (1)\n0007    AugAssignSpecial AugOpSub %!d(string=NR)\n000a    Num 2 (0)\n000c    AugAssignSpecial AugOpMul %!d(string=NR)\n000f    Num 2 (0)\n0011    AugAssignSpecial AugOpDiv %!d(string=NR)\n0014    Num 2 (0)\n0016    AugAssignSpecial AugOpPow %!d(string=NR)\n0019    Num 5 (2)\n001b    AugAssignSpecial AugOpMod %!d(string=NR)\n001e    Special OFS\n0020    Str "x" (0)\n0022    Concat\n0023    AssignSpecial OFS\n\n', b''),
        (b'BEGIN { for (NR in a) print }', 0, b'        // BEGIN\n0000    ForIn NR a 0x0009\n0006    Print 0\n\n', b''),
    ],
    ids=['assign-incr', 'augassign', 'forin-special-var'],
)
def test_special_var_writes(run, tmp_path, prog, rc, out, err):
    """Assignments, pre/post increments, augmented assignments, and getline targets on special variables each get their own disassembly form; AugAssignSpecial mis-formats the name as %!d(string=NAME), a reference quirk reproduced verbatim."""
    # CATCHES: AssignSpecial/IncrSpecial/GetlineSpecial operand forms incl. the %!d(string=NR) quirk
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'function f(a, x) { x = 3; a[x] = 4; a[x] += 1; x++; if (x in a) return (x in a); for (k in a) print k; delete a[x]; return x }\nBEGIN { print f(h, g) }', 0, b'        // BEGIN\n0000    Global g\n0002    CallUser f [h]\n0007    Print 1\n\n        // function f\n0000    Num 3 (0)\n0002    AssignLocal x\n0004    Num 4 (1)\n0006    Local x\n0008    AssignArrayLocal a\n000a    Num 1 (2)\n000c    Local x\n000e    AugAssignArrayLocal AugOpAdd a\n0011    IncrLocal 1 x\n0014    Local x\n0016    InLocal a\n0018    JumpFalse 0x001f\n001a    Local x\n001c    InLocal a\n001e    Return\n001f    ForIn k a 0x002a\n0025    Global k\n0027    Print 1\n002a    Local x\n002c    Delete a\n002f    Local x\n0031    Return\n\n', b''),
        (b'BEGIN { g = 1; h[g] = 2; h["k"] += 3; g++; if (g in h) print "in"; delete h[1]; delete h }', 0, b'        // BEGIN\n0000    Num 1 (0)\n0002    AssignGlobal g\n0004    Num 2 (1)\n0006    Global g\n0008    AssignArrayGlobal h\n000a    Num 3 (2)\n000c    Str "k" (0)\n000e    AugAssignArrayGlobal AugOpAdd h\n0011    IncrGlobal 1 g\n0014    Global g\n0016    InGlobal h\n0018    JumpFalse 0x001f\n001a    Str "in" (1)\n001c    Print 1\n001f    Str "1" (2)\n0021    Delete h\n0024    DeleteAll h\n\n', b''),
        (b'function f(a, x) { print a[x]; x *= 2; return x }\nBEGIN { g += 1 }', 0, b'        // BEGIN\n0000    Num 1 (1)\n0002    AugAssignGlobal AugOpAdd g\n\n        // function f\n0000    Local x\n0002    ArrayLocal a\n0004    Print 1\n0007    Num 2 (0)\n0009    AugAssignLocal AugOpMul x\n000c    Local x\n000e    Return\n\n', b''),
    ],
    ids=['locals-arrays', 'globals-arrays', 'local-read-augassign'],
)
def test_scope_opcodes(run, tmp_path, prog, rc, out, err):
    """Scalar and array references distinguish Local vs Global (and ArrayLocal vs ArrayGlobal) with the variable's source name as operand; augmented assignments carry the aug-op before the variable name, and delete of one element is Delete while delete of a whole array is DeleteAll."""
    # CATCHES: local/global scope distinction and array element vs whole-array delete
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'BEGIN { if (x == 1) print "a"; else print "b"; while (0) print "c"; for (i=0; i<3; i++) print i; print (x ? 2 : 3) }', 0, b'        // BEGIN\n0000    Global x\n0002    Num 1 (0)\n0004    JumpNotEquals 0x000d\n0006    Str "a" (0)\n0008    Print 1\n000b    Jump 0x0012\n000d    Str "b" (1)\n000f    Print 1\n0012    Num 0 (1)\n0014    JumpFalse 0x001f\n0016    Str "c" (2)\n0018    Print 1\n001b    Num 0 (1)\n001d    JumpTrue 0x0016\n001f    Num 0 (1)\n0021    AssignGlobal i\n0023    Global i\n0025    Num 3 (2)\n0027    JumpGreaterOrEqual 0x0037\n0029    Global i\n002b    Print 1\n002e    IncrGlobal 1 i\n0031    Global i\n0033    Num 3 (2)\n0035    JumpLess 0x0029\n0037    Global x\n0039    JumpFalse 0x003f\n003b    Num 2 (3)\n003d    Jump 0x0041\n003f    Num 3 (2)\n0041    Print 1\n\n', b''),
        (b'BEGIN { if (x != 1) print 1; if (x > 1) print 2; if (x <= 1) print 3; do { print 4 } while (x >= 1); print (x==1 && y==2); print (x<1 || y>2); print (x<=1); print (x>=1); print (x!=1) }', 0, b'        // BEGIN\n0000    Global x\n0002    Num 1 (0)\n0004    JumpEquals 0x000b\n0006    Num 1 (0)\n0008    Print 1\n000b    Global x\n000d    Num 1 (0)\n000f    JumpLessOrEqual 0x0016\n0011    Num 2 (1)\n0013    Print 1\n0016    Global x\n0018    Num 1 (0)\n001a    JumpGreater 0x0021\n001c    Num 3 (2)\n001e    Print 1\n0021    Num 4 (3)\n0023    Print 1\n0026    Global x\n0028    Num 1 (0)\n002a    JumpGreaterOrEqual 0x0021\n002c    Global x\n002e    Num 1 (0)\n0030    Equals\n0031    Dupe\n0032    JumpFalse 0x003a\n0034    Drop\n0035    Global y\n0037    Num 2 (1)\n0039    Equals\n003a    Boolean\n003b    Print 1\n003e    Global x\n0040    Num 1 (0)\n0042    Less\n0043    Dupe\n0044    JumpTrue 0x004c\n0046    Drop\n0047    Global y\n0049    Num 2 (1)\n004b    Greater\n004c    Boolean\n004d    Print 1\n0050    Global x\n0052    Num 1 (0)\n0054    LessOrEqual\n0055    Print 1\n0058    Global x\n005a    Num 1 (0)\n005c    GreaterOrEqual\n005d    Print 1\n0060    Global x\n0062    Num 1 (0)\n0064    NotEquals\n0065    Print 1\n\n', b''),
    ],
    ids=['if-while-for', 'compare-jumps'],
)
def test_jump_opcodes(run, tmp_path, prog, rc, out, err):
    """if/while/for/do-while/ternary compile to fused compare-and-branch opcodes (the if condition's comparison is inverted: `==` becomes JumpNotEquals), while && and || use Dupe/Drop/JumpFalse/JumpTrue with a Boolean opcode."""
    # CATCHES: inverted compare-and-jump fusion for all six comparison operators
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'BEGIN { print "x" > "f.txt"; print "y" >> "f.txt"; print "z" | "cat"; printf "%d\\n", 1 > "g.txt"; printf "%d\\n", 2 | "cat"; print | "cat" }', 0, b'        // BEGIN\n0000    Str "f.txt" (0)\n0002    Str "x" (1)\n0004    Print 1 >\n0007    Str "f.txt" (0)\n0009    Str "y" (2)\n000b    Print 1 >>\n000e    Str "cat" (3)\n0010    Str "z" (4)\n0012    Print 1 |\n0015    Str "g.txt" (5)\n0017    Str "%d\\n" (6)\n0019    Num 1 (0)\n001b    Printf 2 >\n001e    Str "cat" (3)\n0020    Str "%d\\n" (6)\n0022    Num 2 (1)\n0024    Printf 2 |\n0027    Str "cat" (3)\n0029    Print 0 |\n\n', b''),
        (b'BEGIN { printf "%d", 1 }', 0, b'        // BEGIN\n0000    Str "%d" (0)\n0002    Num 1 (0)\n0004    Printf 2\n\n', b''),
    ],
    ids=['redirects', 'printf-plain'],
)
def test_print_redirect_opcodes(run, tmp_path, prog, rc, out, err):
    """Print/Printf carry their redirect token as a trailing operand (>, >>, |); a printf without redirect shows only its argument count, and a bare piped print shows count 0 (Print 0 |)."""
    # CATCHES: redirect token printed after the argument count for print and printf
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'BEGIN { getline; getline g; getline $1; getline a[1]; getline g < "in.txt"; "cat" | getline; "cat" | getline $2; "cat" | getline g }', 0, b'        // BEGIN\n0000    Getline <illegal>\n0002    Drop\n0003    GetlineGlobal <illegal> g\n0006    Drop\n0007    Num 1 (0)\n0009    GetlineField <illegal>\n000b    Drop\n000c    Str "1" (0)\n000e    GetlineArray <illegal> a\n0012    Drop\n0013    Str "in.txt" (1)\n0015    GetlineGlobal < g\n0018    Drop\n0019    Str "cat" (2)\n001b    Getline |\n001d    Drop\n001e    Num 2 (1)\n0020    Str "cat" (2)\n0022    GetlineField |\n0024    Drop\n0025    Str "cat" (2)\n0027    GetlineGlobal | g\n002a    Drop\n\n', b''),
        (b'function f(x, y) { getline y; getline a[1]; return y }\nBEGIN { print f(1) }', 0, b'        // BEGIN\n0000    Num 1 (0)\n0002    Nulls 1\n0004    CallUser f []\n0007    Print 1\n\n        // function f\n0000    GetlineLocal <illegal> y\n0003    Drop\n0004    Str "1" (0)\n0006    GetlineArray <illegal> a\n000a    Drop\n000b    Local y\n000d    Return\n\n', b''),
    ],
    ids=['getline-global', 'getline-local'],
)
def test_getline_opcodes(run, tmp_path, prog, rc, out, err):
    """Each getline target kind gets its own opcode (Getline, GetlineGlobal, GetlineField, GetlineArray, GetlineLocal for function parameters); a getline with no redirect prints <illegal> as the redirect token."""
    # CATCHES: distinct Getline* opcode per target kind and the <illegal> no-redirect token
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'BEGIN { print atan2(1,2); print cos(0); print exp(1); print int(1.5); print log(2); print sin(1); print sqrt(4); print index("abc","b"); print substr("abc",2,1); print substr("abc",2); print match("abc",/b/); print tolower("A"); print toupper("a"); print system("true"); print rand(); print srand(7); print srand(); print close("x"); print fflush("x"); print fflush() }', 0, b'        // BEGIN\n0000    Num 1 (0)\n0002    Num 2 (1)\n0004    CallBuiltin BuiltinAtan2\n0006    Print 1\n0009    Num 0 (2)\n000b    CallBuiltin BuiltinCos\n000d    Print 1\n0010    Num 1 (0)\n0012    CallBuiltin BuiltinExp\n0014    Print 1\n0017    Num 1.5 (3)\n0019    CallBuiltin BuiltinInt\n001b    Print 1\n001e    Num 2 (1)\n0020    CallBuiltin BuiltinLog\n0022    Print 1\n0025    Num 1 (0)\n0027    CallBuiltin BuiltinSin\n0029    Print 1\n002c    Num 4 (4)\n002e    CallBuiltin BuiltinSqrt\n0030    Print 1\n0033    Str "abc" (0)\n0035    Str "b" (1)\n0037    CallBuiltin BuiltinIndex\n0039    Print 1\n003c    Str "abc" (0)\n003e    Num 2 (1)\n0040    Num 1 (0)\n0042    CallBuiltin BuiltinSubstrLength\n0044    Print 1\n0047    Str "abc" (0)\n0049    Num 2 (1)\n004b    CallBuiltin BuiltinSubstr\n004d    Print 1\n0050    Str "abc" (0)\n0052    Str "b" (1)\n0054    CallBuiltin BuiltinMatch\n0056    Print 1\n0059    Str "A" (2)\n005b    CallBuiltin BuiltinTolower\n005d    Print 1\n0060    Str "a" (3)\n0062    CallBuiltin BuiltinToupper\n0064    Print 1\n0067    Str "true" (4)\n0069    CallBuiltin BuiltinSystem\n006b    Print 1\n006e    CallBuiltin BuiltinRand\n0070    Print 1\n0073    Num 7 (5)\n0075    CallBuiltin BuiltinSrandSeed\n0077    Print 1\n007a    CallBuiltin BuiltinSrand\n007c    Print 1\n007f    Str "x" (5)\n0081    CallBuiltin BuiltinClose\n0083    Print 1\n0086    Str "x" (5)\n0088    CallBuiltin BuiltinFflush\n008a    Print 1\n008d    CallBuiltin BuiltinFflushAll\n008f    Print 1\n\n', b''),
        (b'function f(arr) { return length(arr) }\nBEGIN { a[1]=1; print length(a), f(a); print length("abcd"); print length; split("a b", s); split("a,b", t, ","); split("a1b", u, /1/); print sprintf("%d-%s", 1, "x") }', 0, b'        // BEGIN\n0000    Num 1 (0)\n0002    Str "1" (0)\n0004    AssignArrayGlobal a\n0006    CallLengthArray a\n0009    CallUser f [a]\n000e    Print 2\n0011    Str "abcd" (1)\n0013    CallBuiltin BuiltinLengthArg\n0015    Print 1\n0018    CallBuiltin BuiltinLength\n001a    Print 1\n001d    Str "a b" (2)\n001f    CallSplit s\n0022    Drop\n0023    Str "a,b" (3)\n0025    Str "," (4)\n0027    CallSplitSep t 0\n002b    Drop\n002c    Str "a1b" (5)\n002e    Str "1" (0)\n0030    CallSplitSep u 1\n0034    Drop\n0035    Str "%d-%s" (6)\n0037    Num 1 (0)\n0039    Str "x" (7)\n003b    CallSprintf 3\n003d    Print 1\n\n        // function f\n0000    CallLengthArray arr\n0003    Return\n\n', b''),
        (b'BEGIN { s = "aa"; print sub("a","X",s); print gsub("a","X",s); print sub("a","X",$1); print gsub("a","X",$2) }', 0, b'        // BEGIN\n0000    Str "aa" (0)\n0002    AssignGlobal s\n0004    Str "a" (1)\n0006    Str "X" (2)\n0008    Global s\n000a    CallBuiltin BuiltinSub\n000c    AssignGlobal s\n000e    Print 1\n0011    Str "a" (1)\n0013    Str "X" (2)\n0015    Global s\n0017    CallBuiltin BuiltinGsub\n0019    AssignGlobal s\n001b    Print 1\n001e    Num 1 (0)\n0020    Dupe\n0021    Field\n0022    Str "a" (1)\n0024    Str "X" (2)\n0026    Rote\n0027    CallBuiltin BuiltinSub\n0029    Rote\n002a    AssignFieldSub\n002b    Print 1\n002e    Num 2 (1)\n0030    Dupe\n0031    Field\n0032    Str "a" (1)\n0034    Str "X" (2)\n0036    Rote\n0037    CallBuiltin BuiltinGsub\n0039    Rote\n003a    AssignFieldSub\n003b    Print 1\n\n', b''),
    ],
    ids=['math-string', 'length-split', 'sub-gsub'],
)
def test_builtin_call_opcodes(run, tmp_path, prog, rc, out, err):
    """Each builtin call disassembles with its arity-specific opcode (BuiltinSubstr vs BuiltinSubstrLength, BuiltinSrand vs BuiltinSrandSeed, BuiltinLength vs BuiltinLengthArg, bare fflush() vs fflush(arg)); split with a separator shows CallSplitSep plus a 0/1 regex flag, and length(array) becomes CallLengthArray naming the array."""
    # CATCHES: arity-dependent builtin opcode names and split's regex-separator flag
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'function f(a, b) { a[1]++; b[2]--; return length(a) }\nfunction h() { return 1 }\nBEGIN { x[1]=1; y[1]=2; x[1]++; x[1]--; print f(x, y); print h() }', 0, b'        // BEGIN\n0000    Num 1 (0)\n0002    Str "1" (0)\n0004    AssignArrayGlobal x\n0006    Num 2 (1)\n0008    Str "1" (0)\n000a    AssignArrayGlobal y\n000c    Str "1" (0)\n000e    IncrArrayGlobal 1 x\n0011    Str "1" (0)\n0013    IncrArrayGlobal -1 x\n0016    CallUser f [x, y]\n001d    Print 1\n0020    CallUser h []\n0023    Print 1\n\n        // function f\n0000    Str "1" (0)\n0002    IncrArrayLocal 1 a\n0005    Str "2" (1)\n0007    IncrArrayLocal -1 b\n000a    CallLengthArray a\n000d    Return\n\n        // function h\n0000    Num 1 (0)\n0002    Return\n\n', b''),
        (b'function f(arr, x) { for (x in arr) print x; return 1 }\nBEGIN { print f(h) }', 0, b'        // BEGIN\n0000    Nulls 1\n0002    CallUser f [h]\n0007    Print 1\n\n        // function f\n0000    ForIn x arr 0x000b\n0006    Local x\n0008    Print 1\n000b    Num 1 (0)\n000d    Return\n\n', b''),
    ],
    ids=['calluser', 'forin-local-var'],
)
def test_user_call_opcodes(run, tmp_path, prog, rc, out, err):
    """User function calls list their array parameters in brackets after the function name (CallUser f [x, y], or [] with none), and calling with fewer arguments than parameters pads with a Nulls opcode; a for-in loop whose variable is a function parameter loads it with Local rather than Global."""
    # CATCHES: array-argument list in CallUser and Nulls padding for missing args
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'BEGIN { $1++; $1--; $2 += 5; $2 %= 3; $2 ^= 2; print $4; print $x; print @x }', 0, b'        // BEGIN\n0000    Num 1 (0)\n0002    IncrField 1\n0004    Num 1 (0)\n0006    IncrField -1\n0008    Num 5 (1)\n000a    Num 2 (2)\n000c    AugAssignField AugOpAdd\n000e    Num 3 (3)\n0010    Num 2 (2)\n0012    AugAssignField AugOpMod\n0014    Num 2 (2)\n0016    Num 2 (2)\n0018    AugAssignField AugOpPow\n001a    FieldInt 4\n001c    Print 1\n001f    Global x\n0021    Field\n0022    Print 1\n0025    Global x\n0027    FieldByName\n0028    Print 1\n\n', b''),
        (b'BEGIN { print @"name"; print @/x/ }', 0, b'        // BEGIN\n0000    FieldByNameStr "name" (0)\n0002    Print 1\n0005    Regex "(?s:x)" (0)\n0007    FieldByName\n0008    Print 1\n\n', b''),
    ],
    ids=['field-ops', 'named-fields'],
)
def test_field_opcodes(run, tmp_path, prog, rc, out, err):
    """Numeric field access with a constant compiles to FieldInt, variable index to Field, @name to FieldByNameStr, and @regex to Regex+FieldByName; ++/-- on fields use IncrField with a signed amount and += %= ^= use AugAssignField with the aug-op name."""
    # CATCHES: FieldInt vs Field vs FieldByName/FieldByNameStr distinction for @ syntax
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'/a/\n/b/, /c/ { print }\n$1 > 2 { print }\n{ }\nEND { print }', 0, b'        // pattern\n0000    Regex "(?s:a)" (0)\n\n        // start\n0000    Regex "(?s:b)" (1)\n\n        // stop\n0000    Regex "(?s:c)" (2)\n\n        // { body }\n0000    Print 0\n\n        // pattern\n0000    FieldInt 1\n0002    Num 2 (0)\n0004    Greater\n\n        // { body }\n0000    Print 0\n\n        // { body }\n0000    Nop\n\n        // END\n0000    Print 0\n\n', b''),
    ],
    ids=['actions'],
)
def test_action_structure(run, tmp_path, prog, rc, out, err):
    """The dump labels sections: a pattern-only action prints // pattern with no body, a range pattern gets // start and // stop sections, an empty action body compiles to a single Nop, and sections are separated by blank lines in source order."""
    # CATCHES: section comments and ordering for pattern-only, range, empty-body, and END actions
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'prog,rc,out,err',
    [
        (b'BEGIN { print "a\\nb"; print "tab\\tand\\"quote" }', 0, b'        // BEGIN\n0000    Str "a\\nb" (0)\n0002    Print 1\n0005    Str "tab\\tand\\"quote" (1)\n0007    Print 1\n\n', b''),
        (b'1.5e10 { print } BEGIN { print -1; print 0.125; print 123456789 }', 0, b'        // BEGIN\n0000    Num 1 (0)\n0002    UnaryMinus\n0003    Print 1\n0006    Num 0.125 (1)\n0008    Print 1\n000b    Num 123456789 (2)\n000d    Print 1\n\n        // pattern\n0000    Num 15000000000 (3)\n\n        // { body }\n0000    Print 0\n\n', b''),
        (b'BEGIN { print "a" "b" "c" "d"; v[1, 2] = 9; print v[1, 2] }', 0, b'        // BEGIN\n0000    Str "a" (0)\n0002    Str "b" (1)\n0004    Str "c" (2)\n0006    Str "d" (3)\n0008    ConcatMulti 4\n000a    Print 1\n000d    Num 9 (0)\n000f    Str "1" (4)\n0011    Str "2" (5)\n0013    IndexMulti 2\n0015    AssignArrayGlobal v\n0017    Str "1" (4)\n0019    Str "2" (5)\n001b    IndexMulti 2\n001d    ArrayGlobal v\n001f    Print 1\n\n', b''),
        (b'/a.*b/ { print } BEGIN { if (/x/) print "re" }', 0, b'        // BEGIN\n0000    Regex "(?s:x)" (0)\n0002    JumpFalse 0x0009\n0004    Str "re" (0)\n0006    Print 1\n\n        // pattern\n0000    Regex "(?s:a.*b)" (1)\n\n        // { body }\n0000    Print 0\n\n', b''),
    ],
    ids=['str-escape', 'num-formats', 'concat-index', 'regex-literal'],
)
def test_literal_formatting(run, tmp_path, prog, rc, out, err):
    """Constants are formatted Go-style in the dump: strings use %q escaping (\\n, \\t, \\"), whole numbers print as integers (including 15000000000 from 1.5e10) while 0.125 keeps decimals, negative literals are not folded (Num 1 + UnaryMinus), multi-subscripts use IndexMulti with a count, 4-way concat uses ConcatMulti 4, and regex literals are wrapped as "(?s:...)". """
    # CATCHES: Go %q string escaping and integer vs float constant formatting
    res = run(['-da', prog], cwd=tmp_path)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err
