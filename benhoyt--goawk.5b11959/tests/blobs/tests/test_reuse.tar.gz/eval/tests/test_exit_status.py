"""Exit status semantics: exit N from BEGIN/main/END, which block runs after exit, and how later exits override earlier ones."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print "x"; exit; print "y" }  { print "a" }  END { print "z" }'], b'line', {}, [], {}, 0, b'x\nz\n', b''),
        (['BEGIN { print "x"; exit 1+2; print "y" }  { print "a" }  END { print "z" }'], b'line', {}, [], {}, 3, b'x\nz\n', b''),
        (['{ print "x"; exit; print "y" }  END { print "z" }'], b'line', {}, [], {}, 0, b'x\nz\n', b''),
        (['END { print "x"; exit; print "y" }'], b'line', {}, [], {}, 0, b'x\n', b''),
        (['BEGIN { print "x"; exit 42 }  END { print "z"; exit }'], b'line', {}, [], {}, 42, b'x\nz\n', b''),
        (['BEGIN { print "x"; exit }  END { print "z"; exit 43 }'], b'line', {}, [], {}, 43, b'x\nz\n', b''),
        (['BEGIN { print "x"; exit 44 }  { print "a"; exit }'], b'line', {}, [], {}, 44, b'x\n', b''),
    ],
    ids=['begin-exit', 'begin-exit-expr', 'main-exit', 'end-exit', 'end-override', 'end-override-expr', 'main-override'],
)
def test_exit_status_propagation(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """exit stops the current block; END still runs; the last executed exit status (expression-valued) becomes the process exit code; plain exit means 0."""
    # CATCHES: END runs after exit but its own exit can override status
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

