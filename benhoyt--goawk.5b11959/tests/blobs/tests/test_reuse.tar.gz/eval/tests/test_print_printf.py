"""print and printf behavior: separators, conversion specifiers, and numeric output formatting via OFMT/CONVFMT."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print "x", "y" }'], b'', {}, [], {}, 0, b'x y\n', b''),
        (['BEGIN { print OFS; OFS = ","; print "x", "y" }'], b'', {}, [], {}, 0, b' \nx,y\n', b''),
        (['BEGIN { print ORS; ORS = "."; print "x", "y" }'], b'', {}, [], {}, 0, b'\n\nx y.', b''),
        (['BEGIN { print; print }'], b'', {}, [], {}, 0, b'\n\n', b''),
    ],
    ids=['default', 'ofs', 'ors', 'empty-print'],
)
def test_print_separators(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """print joins arguments with OFS (default space) and terminates with ORS (default newline); both variables are assignable."""
    # CATCHES: default OFS is space, ORS is newline, both assignable
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { printf "%% %d %x %c %f %s", 42, 42, 42, 42, 42 }'], b'', {}, [], {}, 0, b'% 42 2a * 42.000000 42', b''),
        (['BEGIN { printf "%d %i %o %u %x %X", 42, 42, 42, 42, 42, 42 }'], b'', {}, [], {}, 0, b'42 42 52 42 2a 2A', b''),
        (['BEGIN { printf "%3d", 42 }'], b'', {}, [], {}, 0, b' 42', b''),
        (['BEGIN { printf "%3s", "x" }'], b'', {}, [], {}, 0, b'  x', b''),
        (['BEGIN { printf "%.1g", 42 }'], b'', {}, [], {}, 0, b'4e+01', b''),
        (['BEGIN { printf "%g", 12345.678 }'], b'', {}, [], {}, 0, b'12345.7', b''),
        (['BEGIN { printf "%G", 12345.678 }'], b'', {}, [], {}, 0, b'12345.7', b''),
        (['BEGIN { printf "%g %g", 3.14159265358979, 100000 }'], b'', {}, [], {}, 0, b'3.14159 100000', b''),
        (['BEGIN { print sprintf("% 5d", 42) }'], b'', {}, [], {}, 0, b'   42\n', b''),
        (['BEGIN { print sprintf("%*s %.*s", 5, "abc", 5, "abcdefghi") }'], b'', {}, [], {}, 0, b'  abc abcde\n', b''),
    ],
    ids=['mixed', 'int-family', 'width-int', 'width-str', 'prec-g', 'g', 'G', 'g-two', 'space-flag', 'star'],
)
def test_printf_conversions(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """printf supports the awk conversion characters with C-style formatting: integers, octal/hex, floats, strings with width, precision, and flags, plus literal %%."""
    # CATCHES: exact spacing/rounding of each printf conversion
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { printf "%c", 0 }'], b'', {}, [], {}, 0, b'\x00', b''),
        (['BEGIN { printf "%c", 127 }'], b'', {}, [], {}, 0, b'\x7f', b''),
        (['BEGIN { printf "%c", 128 }'], b'', {}, [], {}, 0, b'\x80', b''),
        (['BEGIN { printf "%c", 255 }'], b'', {}, [], {}, 0, b'\xff', b''),
        (['BEGIN { printf "%c", 256 }'], b'', {}, [], {}, 0, b'\x00', b''),
        (['BEGIN { printf "%c", "xyz" }'], b'', {}, [], {}, 0, b'x', b''),
        (['BEGIN { printf "%c", "" }'], b'', {}, [], {}, 0, b'\x00', b''),
    ],
    ids=['zero', 'del', 'high', 'ff', 'wrap', 'string', 'empty'],
)
def test_printf_c_byte_semantics(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """%c converts numbers to single bytes (mod 256) and strings to their first byte (empty string becomes a NUL byte)."""
    # CATCHES: %c emits raw bytes 0x00-0xff, not multi-byte characters
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_printf_ignores_extra_args(run, tmp_path):
    """Extra arguments beyond the format's conversions are ignored without error."""
    # CATCHES: surplus printf args silently dropped, no error
    args = ['BEGIN { printf "%d", 12, 34 }']
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'12'
    assert res.stderr == b''


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print OFMT, 1.2345678; OFMT = "%.3g"; print OFMT, 1.234567 }'], b'', {}, [], {}, 0, b'%.6g 1.23457\n%.3g 1.23\n', b''),
        (['BEGIN { OFMT = "%s"; print 1234.5678 }'], b'', {}, [], {}, 0, b'1234.57\n', b''),
        (['BEGIN { OFMT = "%s"; CONVFMT = "%d"; print 1234.5678 }'], b'', {}, [], {}, 0, b'1234\n', b''),
        (['BEGIN { print CONVFMT, 1.2345678 ""; CONVFMT = "%.3g"; print CONVFMT, 1.234567 "" }'], b'', {}, [], {}, 0, b'%.6g 1.23457\n%.3g 1.23\n', b''),
        (['BEGIN { CONVFMT = "%d"; print 1234.5678 "" }'], b'', {}, [], {}, 0, b'1234\n', b''),
        (['BEGIN { CONVFMT = "abc"; print 1234.5678 "" }'], b'', {}, [], {}, 0, b'abc\n', b''),
        (['BEGIN { CONVFMT = "%s"; print "[" 1234.5678 "" "]" }'], b'', {}, [], {}, 0, b'[]\n', b''),
    ],
    ids=['defaults', 'ofmt-s', 'ofmt-convfmt', 'convfmt', 'convfmt-d', 'convfmt-abc', 'convfmt-s'],
)
def test_ofmt_and_convfmt(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Numeric print uses OFMT (%.6g default); a non-numeric OFMT falls back to CONVFMT, and CONVFMT governs number-to-string conversion."""
    # CATCHES: OFMT drives print of non-integers; bad OFMT uses CONVFMT
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

