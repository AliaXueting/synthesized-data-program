"""Command-line option handling: usage and version output, flag parsing, option errors, and variable-assignment arguments."""

import pytest


def test_no_arguments_prints_usage(run, tmp_path):
    """Running the binary with no arguments prints the one-line usage on stderr and exits 1, with nothing on stdout."""
    # CATCHES: usage text goes to stderr (not stdout) with exit status 1
    args = []
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 1
    assert res.stdout == b''
    assert res.stderr == b"usage: goawk [-F fs] [-v var=value] [-f progfile | 'prog'] [file ...]\n"


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-h'], b'', {}, [], {}, 0, b'GoAWK v1.32.0 - Copyright (c) 2022 Ben Hoyt\n\nusage: goawk [-F fs] [-v var=value] [-f progfile | \'prog\'] [file ...]\n\nStandard AWK arguments:\n  --csv             enable CSV input mode; equivalent to "-i csv"\n  -F separator      field separator (default " ")\n  -f progfile       load AWK source from progfile (multiple allowed)\n  -v var=value      variable assignment (multiple allowed)\n\nAdditional GoAWK features:\n  -c                use Unicode chars for index, length, match, substr, and %c\n  -E progfile       load program, treat as last option, disable var=value args\n  -H                parse header row and enable @"field" in CSV input mode\n  -h, --help        show this help message\n  -i mode           parse input into fields using CSV format (ignore FS and RS)\n                    \'csv|tsv [separator=<char>] [comment=<char>] [header]\'\n  -o mode           use CSV output for print with args (ignore OFS and ORS)\n                    \'csv|tsv [separator=<char>]\'\n  -N mode           newline output translation: smart (default), raw, crlf\n  -version          show GoAWK version and exit\n\nGoAWK debugging arguments:\n  -coverappend      append to coverage profile instead of overwriting\n  -covermode mode   set coverage mode: set, count (default "set")\n  -coverprofile fn  write coverage profile to file\n  -cpuprofile fn    write CPU profile to file\n  -d                print parsed syntax tree to stdout and exit\n  -da               print VM assembly instructions to stdout and exit\n  -dt               print variable type information to stdout and exit\n  -memprofile fn    write memory profile to file\n', b''),
        (['--help'], b'', {}, [], {}, 0, b'GoAWK v1.32.0 - Copyright (c) 2022 Ben Hoyt\n\nusage: goawk [-F fs] [-v var=value] [-f progfile | \'prog\'] [file ...]\n\nStandard AWK arguments:\n  --csv             enable CSV input mode; equivalent to "-i csv"\n  -F separator      field separator (default " ")\n  -f progfile       load AWK source from progfile (multiple allowed)\n  -v var=value      variable assignment (multiple allowed)\n\nAdditional GoAWK features:\n  -c                use Unicode chars for index, length, match, substr, and %c\n  -E progfile       load program, treat as last option, disable var=value args\n  -H                parse header row and enable @"field" in CSV input mode\n  -h, --help        show this help message\n  -i mode           parse input into fields using CSV format (ignore FS and RS)\n                    \'csv|tsv [separator=<char>] [comment=<char>] [header]\'\n  -o mode           use CSV output for print with args (ignore OFS and ORS)\n                    \'csv|tsv [separator=<char>]\'\n  -N mode           newline output translation: smart (default), raw, crlf\n  -version          show GoAWK version and exit\n\nGoAWK debugging arguments:\n  -coverappend      append to coverage profile instead of overwriting\n  -covermode mode   set coverage mode: set, count (default "set")\n  -coverprofile fn  write coverage profile to file\n  -cpuprofile fn    write CPU profile to file\n  -d                print parsed syntax tree to stdout and exit\n  -da               print VM assembly instructions to stdout and exit\n  -dt               print variable type information to stdout and exit\n  -memprofile fn    write memory profile to file\n', b''),
        (['-h', 'BEGIN { print 1 }'], b'', {}, [], {}, 0, b'GoAWK v1.32.0 - Copyright (c) 2022 Ben Hoyt\n\nusage: goawk [-F fs] [-v var=value] [-f progfile | \'prog\'] [file ...]\n\nStandard AWK arguments:\n  --csv             enable CSV input mode; equivalent to "-i csv"\n  -F separator      field separator (default " ")\n  -f progfile       load AWK source from progfile (multiple allowed)\n  -v var=value      variable assignment (multiple allowed)\n\nAdditional GoAWK features:\n  -c                use Unicode chars for index, length, match, substr, and %c\n  -E progfile       load program, treat as last option, disable var=value args\n  -H                parse header row and enable @"field" in CSV input mode\n  -h, --help        show this help message\n  -i mode           parse input into fields using CSV format (ignore FS and RS)\n                    \'csv|tsv [separator=<char>] [comment=<char>] [header]\'\n  -o mode           use CSV output for print with args (ignore OFS and ORS)\n                    \'csv|tsv [separator=<char>]\'\n  -N mode           newline output translation: smart (default), raw, crlf\n  -version          show GoAWK version and exit\n\nGoAWK debugging arguments:\n  -coverappend      append to coverage profile instead of overwriting\n  -covermode mode   set coverage mode: set, count (default "set")\n  -coverprofile fn  write coverage profile to file\n  -cpuprofile fn    write CPU profile to file\n  -d                print parsed syntax tree to stdout and exit\n  -da               print VM assembly instructions to stdout and exit\n  -dt               print variable type information to stdout and exit\n  -memprofile fn    write memory profile to file\n', b''),
    ],
    ids=['h', 'help-long', 'h-ignores-rest'],
)
def test_help_flag_prints_full_usage(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-h and --help print the full multi-section usage message to stdout and exit 0 without running any program."""
    # CATCHES: help goes to stdout with exit 0, not stderr and exit 1
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-version'], b'', {}, [], {}, 0, b'v1.32.0\n', b''),
        (['--version'], b'', {}, [], {}, 0, b'v1.32.0\n', b''),
        (['-version', 'BEGIN { print 1 }'], b'', {}, [], {}, 0, b'v1.32.0\n', b''),
    ],
    ids=['version', 'version-long', 'version-ignores-rest'],
)
def test_version_flag(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-version and --version print the version line to stdout and exit 0."""
    # CATCHES: version string is exactly 'v1.32.0' with newline, exit 0
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-F'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -F\n'),
        (['-f'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -f\n'),
        (['-v'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -v\n'),
        (['-i'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -i\n'),
        (['-o'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -o\n'),
        (['-N'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -N\n'),
        (['-E'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -E\n'),
        (['-covermode'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -covermode\n'),
        (['-coverprofile'], b'', {}, [], {}, 1, b'', b'flag needs an argument: -coverprofile\n'),
    ],
    ids=['-F', '-f', '-v', '-i', '-o', '-N', '-E', '-covermode', '-coverprofile'],
)
def test_flag_needs_argument(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Every value-taking flag errors with 'flag needs an argument' on stderr and exit 1 when its value is missing."""
    # CATCHES: each flag name appears in its own missing-argument message
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_undefined_flag_rejected(run, tmp_path):
    """An unknown flag is rejected with 'flag provided but not defined' and exit 1."""
    # CATCHES: unknown flag error names the flag and exits 1
    args = ['-z']
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 1
    assert res.stdout == b''
    assert res.stderr == b'flag provided but not defined: -z\n'


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-iabc', '{}'], b'', {}, [], {}, 1, b'', b'invalid input mode "abc"\n'),
        (['-oxyz', '{}'], b'', {}, [], {}, 1, b'', b'invalid output mode "xyz"\n'),
        (['-covermode', 'wrong', '{}'], b'', {}, [], {}, 1, b'', b'-covermode can only be one of: set, count\n'),
        (['-covermode=wrong', '{}'], b'', {}, [], {}, 1, b'', b'-covermode can only be one of: set, count\n'),
        (['-NINVALID', 'BEGIN{}'], b'', {}, [], {}, 1, b'', b'-N arg can only be one of: smart, raw, crlf\n'),
        (['-v', 'foo', 'BEGIN {}'], b'', {}, [], {}, 1, b'', b'-v flag must be in format name=value\n'),
        (['-H', '{}'], b'', {}, [], {}, 1, b'', b'-H only allowed together with -i\n'),
    ],
    ids=['input-mode', 'output-mode', 'covermode-sep', 'covermode-eq', 'newline-mode', 'v-format', 'H-without-i'],
)
def test_invalid_option_values(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Flag values are validated: bad input/output modes, coverage modes, -N modes, -v format, and -H without -i each produce their exact error message and exit 1."""
    # CATCHES: exact per-option validation error messages with exit 1
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ print }', 'notexist'], b'', {}, [], {}, 1, b'', b'file "notexist" not found\n'),
        (['{ print $1 }', '-file'], b'', {}, [], {}, 1, b'', b'file "-file" not found\n'),
        (['--', '{ print $1 }', '-file'], b'', {}, [], {}, 1, b'', b'file "-file" not found\n'),
        (['{ print }', 'sub/one.txt'], b'', {}, [], {}, 1, b'', b'file "sub/one.txt" not found\n'),
        (['FNR==1 { print FILENAME }', '*.txt'], b'', {}, [], {}, 1, b'', b'file "*.txt" not found\n'),
        (['-f', '*.awk'], b'', {}, [], {}, 1, b'', b'file "*.awk" not found\n'),
    ],
    ids=['plain', 'dash-file', 'after-ddash', 'subdir', 'wildcard', 'wildcard-progfile'],
)
def test_missing_input_file(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Nonexistent input files produce a 'file ... not found' error on stderr with exit 1; the path is quoted exactly as given, including dashes, wildcards, and subdirectories."""
    # CATCHES: quoted filename in error, wildcard chars not expanded on Linux
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_wildcards_not_expanded(run, tmp_path):
    """Shell-style wildcards are not expanded when matching files exist in the current directory: '*.txt' still fails with not found."""
    # CATCHES: glob args stay literal even when matches exist on disk
    args = ['FNR==1 { print FILENAME }', '*.txt']
    stdin = b''
    files = {'a.txt': b'A\n', 'b.txt': b'B\n', 'c.awk': b'{}\n'}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 1
    assert res.stdout == b''
    assert res.stderr == b'file "*.txt" not found\n'


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-v', 'x=42', '-v', 'y=foo', 'BEGIN { print x, y }'], b'', {}, [], {}, 0, b'42 foo\n', b''),
        (['-v', 'X=x\\ty', 'BEGIN { printf X }'], b'', {}, [], {}, 0, b'x\ty', b''),
        (['-v', 'x=42.0', 'BEGIN { print (x==42) }'], b'', {}, [], {}, 0, b'1\n', b''),
        (['END { printf X }', 'X=a\\tb'], b'', {}, [], {}, 0, b'a\tb', b''),
    ],
    ids=['two-vars', 'unescape', 'numeric', 'operand-assign'],
)
def test_v_flag_assignment(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-v assigns variables before the program runs; values are unescaped (backslash-t becomes a tab) and numeric strings compare numerically. A name=value operand after the program assigns at that point instead."""
    # CATCHES: -v unescapes escape sequences and strnum assignment semantics
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-E', 'f.txt', '-w'], b'', {'f.txt': b'BEGIN { print "E-arg" }\n'}, [], {}, 0, b'E-arg\n', b''),
        (['-E', 'f.txt', '--', '-l'], b'', {'f.txt': b'BEGIN { print "E-arg" }\n'}, [], {}, 0, b'E-arg\n', b''),
        (['-E', 'f.txt', 'foo=bar'], b'', {'f.txt': b'BEGIN { print "E-arg" }\n'}, [], {}, 0, b'E-arg\n', b''),
        (['-Ef.txt', '-w'], b'', {'f.txt': b'BEGIN { print "E-arg" }\n'}, [], {}, 0, b'E-arg\n', b''),
    ],
    ids=['w', 'ddash-dash-l', 'foo-eq-bar', 'attached'],
)
def test_E_flag_disables_varargs(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-E loads the program file, is treated as the last option, and disables name=value operand assignment: later operands become input files, and a BEGIN-only program never opens them."""
    # CATCHES: args after -E are files not assignments; lazy file open
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-F,', '{ print $1, $3 }'], b'1,2,3\n4,5,6', {}, [], {}, 0, b'1 3\n4 6\n', b''),
        (['-vRS=;', '$0'], b'a b;c\nd;e', {}, [], {}, 0, b'a b\nc\nd\ne\n', b''),
        (['-f-', '-f', '-'], b'BEGIN { print "b" }', {}, [], {}, 0, b'b\n', b''),
        (['-icsv', '{ print $2, $1 }'], b'Bob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['-csv', '{ print $2, $1 }'], b'Bob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['--csv', '{ print $2, $1 }'], b'Bob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['-Nraw', "BEGIN { printf 'foo\\nbar\\n' }"], b'', {}, [], {}, 0, b'foo\nbar\n', b''),
        (['-Ncrlf', "BEGIN { printf 'foo\\nbar\\n' }"], b'', {}, [], {}, 0, b'foo\r\nbar\r\n', b''),
    ],
    ids=['F-attached', 'v-attached', 'f-attached', 'i-attached', 'csv-short', 'csv-long', 'N-attached-raw', 'N-attached-crlf'],
)
def test_combined_flag_forms(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Attached short forms work identically to separated forms: -F:, -vRS=;, -f-, -icsv, -csv, --csv, -Nraw, -Ncrlf."""
    # CATCHES: attached flag+value parsing matches separated two-arg form
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_coverprofile_writes_file(run, tmp_path):
    """-coverprofile runs the program normally (stdout and exit 0) and additionally writes a coverage profile file next to the output."""
    # CATCHES: coverage flag still runs the program and creates the file
    args = ['-coverprofile', 'cover.out', 'BEGIN { print 1 }']
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'1\n'
    assert res.stderr == b''
    assert (tmp_path / "cover.out").exists()


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print ENVIRON["MYVAR"] }'], b'', {}, [], {'MYVAR': 'hello'}, 0, b'hello\n', b''),
        (['BEGIN { n=0; for (k in ENVIRON) n++; print n, ENVIRON["MYVAR"] }'], b'', {}, [], {'MYVAR': 'hello'}, 0, b'4 hello\n', b''),
    ],
    ids=['read', 'count'],
)
def test_environ_variable_access(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """ENVIRON exposes the child process environment: a variable passed through the pinned child env is readable, and iterating ENVIRON counts exactly the pinned variables plus the extra one."""
    # CATCHES: child env is the pinned set plus any test-provided extras
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

