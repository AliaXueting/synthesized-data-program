"""Built-in function behavior recorded from the reference: math, string functions, coercion, and escape sequences."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print sin(0), sin(0.5), sin(1), sin(-1) }'], b'', {}, [], {}, 0, b'0 0.479426 0.841471 -0.841471\n', b''),
        (['BEGIN { print cos(0), cos(0.5), cos(1), cos(-1) }'], b'', {}, [], {}, 0, b'1 0.877583 0.540302 0.540302\n', b''),
        (['BEGIN { print exp(0), exp(0.5), exp(1), exp(-1) }'], b'', {}, [], {}, 0, b'1 1.64872 2.71828 0.367879\n', b''),
        (['BEGIN { print log(0), log(0.5), log(1) }'], b'', {}, [], {}, 0, b'-inf -0.693147 0\n', b''),
        (['BEGIN { print log(-1) }'], b'', {}, [], {}, 0, b'nan\n', b''),
        (['BEGIN { print sqrt(0), sqrt(2), sqrt(4) }'], b'', {}, [], {}, 0, b'0 1.41421 2\n', b''),
        (['BEGIN { print atan2(1, 0.5), atan2(-1, 0) }'], b'', {}, [], {}, 0, b'1.10715 -1.5708\n', b''),
        (['BEGIN { print int(3.5), int("1.9"), int(4), int(-3.6), int("x"), int("") }'], b'', {}, [], {}, 0, b'3 1 4 -3 0 0\n', b''),
    ],
    ids=['sin', 'cos', 'exp', 'log', 'log-neg', 'sqrt', 'atan2', 'int'],
)
def test_math_functions(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """sin, cos, exp, log, sqrt, atan2, and int follow Go's float64 math, printed with the default %.6g number formatting."""
    # CATCHES: exact float formatting of math builtins incl. inf/nan
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print match("food", "foo"), RSTART, RLENGTH }'], b'', {}, [], {}, 0, b'1 1 3\n', b''),
        (['BEGIN { print match("x food y", "fo"), RSTART, RLENGTH }'], b'', {}, [], {}, 0, b'3 3 2\n', b''),
        (['BEGIN { print match("x food y", "fox"), RSTART, RLENGTH }'], b'', {}, [], {}, 0, b'0 0 -1\n', b''),
        (['BEGIN { print match("x food y", /[fod]+/), RSTART, RLENGTH }'], b'', {}, [], {}, 0, b'3 3 4\n', b''),
        (['BEGIN { print match("a\\nb\\nc", /^a.*c$/), RSTART, RLENGTH }'], b'', {}, [], {}, 0, b'1 1 5\n', b''),
        (['BEGIN { print RSTART, RLENGTH; RSTART=5; RLENGTH=42; print RSTART, RLENGTH; }'], b'', {}, [], {}, 0, b'0 0\n5 42\n', b''),
    ],
    ids=['plain', 'middle', 'no-match', 'regex', 'anchored', 'rstart-settable'],
)
def test_match_sets_rstart_rlength(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """match() returns the 1-based start of the match and sets RSTART and RLENGTH; both variables are readable and assignable."""
    # CATCHES: match() side effects on RSTART/RLENGTH after each call
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ print length, length(), length("buzz"), length("") }'], b'foo bar', {}, [], {}, 0, b'7 7 4 0\n', b''),
        (['BEGIN { print index("foo", "f"), index("foo0", 0), index("foo", "o"), index("foo", "x") }'], b'', {}, [], {}, 0, b'1 4 2 0\n', b''),
        (['BEGIN { print index("föö", "f"), index("föö0", 0), index("föö", "ö"), index("föö", "x") }'], b'', {}, [], {}, 0, b'1 6 2 0\n', b''),
        (['BEGIN { print length("a"), length("絵") }'], b'', {}, [], {}, 0, b'1 3\n', b''),
        (['BEGIN { print substr("food", 1) }'], b'', {}, [], {}, 0, b'food\n', b''),
        (['BEGIN { print substr("food", 1, 2) }'], b'', {}, [], {}, 0, b'fo\n', b''),
        (['BEGIN { print substr("food", 5) }'], b'', {}, [], {}, 0, b'\n', b''),
        (['BEGIN { print substr("food", 2, -3), substr("fööd", 2, -3) }'], b'', {}, [], {}, 0, b' \n', b''),
        (['BEGIN { print substr("fööd", 1, 2) }'], b'', {}, [], {}, 0, b'f\xc3\n', b''),
        (['BEGIN { print substr("food", -1, 8), substr("fööd", -1, 8) }'], b'', {}, [], {}, 0, b'food f\xc3\xb6\xc3\xb6d\n', b''),
        (['BEGIN { print tolower("Foo BaR") }'], b'', {}, [], {}, 0, b'foo bar\n', b''),
        (['BEGIN { print toupper("Foo BaR") }'], b'', {}, [], {}, 0, b'FOO BAR\n', b''),
    ],
    ids=['length-field', 'index', 'index-unicode', 'length-unicode', 'substr-rest', 'substr-len', 'substr-past-end', 'substr-neg-len', 'substr-unicode', 'substr-neg-start', 'tolower', 'toupper'],
)
def test_length_index_substr(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """length/index/substr operate on bytes by default: multi-byte characters count as their UTF-8 bytes, and substr clamps out-of-range positions."""
    # CATCHES: byte-oriented indexing and substr clamping of bad ranges
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print "-12"+0, "+12"+0, " \\t\\r\\n7foo"+0, ".5"+0, "5."+0, "."+0 }'], b'', {}, [], {}, 0, b'-12 12 7 0.5 5 0\n', b''),
        (['BEGIN { print "1e3"+0, "1.2e-1"+0, "1e+1"+0, "1e"+0, "1e+"+0 }'], b'', {}, [], {}, 0, b'1000 0.12 10 1 1\n', b''),
    ],
    ids=['decimal', 'exponent'],
)
def test_number_string_coercion(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """String-to-number coercion accepts leading whitespace, signs, decimals, and exponents, stopping at the first invalid character (value 0 if none)."""
    # CATCHES: leading-numeric prefix parsing incl. whitespace and signs
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ print $1+0 }'], b'0x0\n0X10\n0x1234567890\n-0xa\n0xf.f\n0xf.fp10\n0x.\n0xf.\n', {}, [], {}, 0, b'0\n16\n78187493520\n-10\n15.9375\n16320\n0\n15\n', b''),
        (['BEGIN { print int("0x22"), int("-0xa"), int("0xffz"), int("022"), int("-022") }'], b'', {}, [], {}, 0, b'34 -10 255 22 -22\n', b''),
    ],
    ids=['hex-lines', 'hex-int'],
)
def test_hex_float_parsing(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Hexadecimal float literals (0x...) parse as numbers, including hex fractions and binary exponents; int() also accepts hex strings."""
    # CATCHES: 0x hex floats with p-exponents coerce numerically
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_nan_inf_string_parsing(run, tmp_path):
    """The strings 'nan' and 'inf'/'-inf' (case-sensitive per POSIX strtod) coerce to those float values; prefixes like 'na' or 'in' coerce to 0."""
    # CATCHES: full-word nan/inf parse as floats, prefixes do not
    args = ['{ print $1, $2+0 }']
    stdin = b'1 nan\n2 NAN\n6 na\n8 inf\n13 -inf\n14 in\n'
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'1 nan\n2 nan\n6 0\n8 inf\n13 -inf\n14 0\n'
    assert res.stderr == b''


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print "0\\n1\\t2\\r3\\a4\\b5\\f6\\v7\\x408\\xf" }'], b'', {}, [], {}, 0, b'0\n1\t2\r3\x074\x085\x0c6\x0b7@8\x0f\n', b''),
        (['BEGIN { print "The \\u201cQUICK\\u201d brown fox \\u1F602" }'], b'', {}, [], {}, 0, b'The \xe2\x80\x9cQUICK\xe2\x80\x9d brown fox \xf0\x9f\x98\x82\n', b''),
        (['BEGIN { print \'"\' "\'" "xy" "z" }'], b'', {}, [], {}, 0, b'"\'xyz\n', b''),
    ],
    ids=['control', 'unicode', 'quote-concat'],
)
def test_string_escapes(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """String literals interpret C-style escapes including \\t, \\r, bell/backspace/formfeed/vtab, \\xNN hex, and \\uXXXX Unicode code points."""
    # CATCHES: escape decoding in double-quoted strings incl \x and \u
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { e="x"; E="X"; print 1e, 1E }'], b'', {}, [], {}, 0, b'1x 1X\n', b''),
        (['BEGIN { a=2; print 1e+a, 1E+a, 1e+1, 1E+1 }'], b'', {}, [], {}, 0, b'12 12 10 10\n', b''),
        (['BEGIN { print 1e1000, -1e1000 }'], b'', {}, [], {}, 0, b'inf -inf\n', b''),
        (['BEGIN { print 2^3, 2^3^3, 2^-3, -2^3, "2"^"3", 3^.14 }'], b'', {}, [], {}, 0, b'8 134217728 0.125 -8 8 1.16626\n', b''),
        (['BEGIN { print 1+2*3/4^5%6 7, (1+2)*3/4^5%6 "7" }'], b'', {}, [], {}, 0, b'1.005867 0.008789067\n', b''),
    ],
    ids=['e-var', 'e-var-plus', 'overflow', 'pow', 'precedence'],
)
def test_exponent_and_precedence(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Number tokenization and operator precedence: '1e' is 1 followed by variable e, ^ is right-associative and binds tighter than unary minus, and implicit concatenation has the lowest precedence."""
    # CATCHES: 1e+a tokenizes as concat; -2^3 is -(2^3); ^ right-assoc
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

