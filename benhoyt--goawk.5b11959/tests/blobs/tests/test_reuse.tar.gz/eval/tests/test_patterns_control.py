"""Patterns and control flow: range patterns, next, ternary associativity, increment/decrement, in/delete, and functions."""

import pytest


def test_range_pattern(run, tmp_path):
    """A comma-separated range pattern turns on at the left pattern and off at the right, inclusive of both records."""
    # CATCHES: range start/end records are both included in the action
    args = ['NR==2, NR==4 { print $0 }']
    stdin = b'1\n2\n3\n4\n5\n6\n'
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'2\n3\n4\n'
    assert res.stderr == b''


def test_next_statement(run, tmp_path):
    """next skips the rest of the rules for the current record."""
    # CATCHES: next skips only remaining rules, not the whole program
    args = ['{ if (NR==2) next; print }']
    stdin = b'a\nb\nc'
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'a\nc\n'
    assert res.stderr == b''


def test_ternary_associativity(run, tmp_path):
    """The ternary operator is right-associative, so nested un-parenthesized ternaries bind as a?b:(c?d:e)."""
    # CATCHES: right-associativity of ?: without explicit parentheses
    args = ['BEGIN { print 1?2?3:4:5, 1?0?3:4:5, 0?2?3:4:5 }']
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'3 4 5\n'
    assert res.stderr == b''


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print x++; print x }'], b'', {}, [], {}, 0, b'0\n1\n', b''),
        (['BEGIN { print x; print x--; print --x; print x }'], b'', {}, [], {}, 0, b'\n0\n-2\n-2\n', b''),
        (['{ print $++n; print $--n }'], b'x y', {}, [], {}, 0, b'x\nx y\n', b''),
        (['BEGIN{ a = 3; b = 7; c = (a)++b; print a, b, c }'], b'', {}, [], {}, 0, b'3 8 38\n', b''),
        (['BEGIN { x=1; x += x+=3; print x }'], b'', {}, [], {}, 0, b'8\n', b''),
    ],
    ids=['post', 'pre-post', 'field-index', 'paren-inc', 'compound'],
)
def test_increment_decrement(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Post-increment yields the old value then increments; pre-decrement decrements first; these compose with field indices and compound assignment (which is right-associative in GoAWK)."""
    # CATCHES: post vs pre increment order and $++n index evaluation
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { a["x"] = 3; print "x" in a, "y" in a }'], b'', {}, [], {}, 0, b'1 0\n', b''),
        (['BEGIN { a["x"] = 3; a["y"] = 4; delete a["x"]; for (k in a) print k, a[k] }'], b'', {}, [], {}, 0, b'y 4\n', b''),
    ],
    ids=['in', 'delete'],
)
def test_in_operator_and_delete(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """'key in array' tests membership without creating the element; delete removes an element."""
    # CATCHES: 'in' does not create the key; delete removes exactly one
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_regex_ternary_matching(run, tmp_path):
    """A bare /regex/ in an expression matches against $0."""
    # CATCHES: unanchored regex match against current record in expr context
    args = ['{ print /x/?"t":"f" }']
    stdin = b'x\ny\nxx\nz\n'
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b't\nf\nt\nf\n'
    assert res.stderr == b''


def test_seen_array_dedup(run, tmp_path):
    """The !seen[$0]++ idiom prints each distinct record once (creates the key as a side effect but only on first sight)."""
    # CATCHES: ++ on array element yields old uninitialized value 0
    args = ['!seen[$0]++']
    stdin = b'1\n2\n3\n2\n3\n3\n'
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'1\n2\n3\n'
    assert res.stderr == b''


def test_function_recursion(run, tmp_path):
    """User functions recurse; a recursive fib computes correctly."""
    # CATCHES: recursion and user function calls work from BEGIN
    args = ['function fib(n) { return n < 3 ? 1 : fib(n-2) + fib(n-1) } BEGIN { for (i = 1; i <= 7; i++) printf "%d ", fib(i) }']
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'1 1 2 3 5 8 13 '
    assert res.stderr == b''

