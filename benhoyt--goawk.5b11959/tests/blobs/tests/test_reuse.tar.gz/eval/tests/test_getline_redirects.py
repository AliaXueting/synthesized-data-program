"""getline, output redirection, pipes, close/fflush, /dev/stdout and /dev/stderr, and the system() built-in."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { getline x; print x }'], b'foo', {}, [], {}, 0, b'foo\n', b''),
        (['BEGIN { getline a[1]; print a[1] }'], b'foo', {}, [], {}, 0, b'foo\n', b''),
        (['BEGIN { getline $1; print $1 }'], b'foo', {}, [], {}, 0, b'foo\n', b''),
    ],
    ids=['var', 'array', 'field'],
)
def test_getline_from_stdin(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """getline (with a variable, array element, or field target) reads the next line from stdin."""
    # CATCHES: getline targets can be var, array elem, or field
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print getline x < "/no/such/file" }'], b'', {}, [], {}, 0, b'-1\n', b''),
        (['BEGIN { print getline x <"missing.txt"; print x }'], b'', {'keep.txt': b'x'}, [], {}, 0, b'-1\n\n', b''),
        (['BEGIN { print getline x < "-"; print x }'], b'a\nb\n', {}, [], {}, 0, b'1\na\n', b''),
        (['{ print $0; print getline x <"-"; print x }'], b'one\ntwo\n', {}, [], {}, 0, b'one\n0\n\ntwo\n0\n\n', b''),
    ],
    ids=['missing', 'missing-relative', 'dash-in-begin', 'dash-in-main'],
)
def test_getline_from_file(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """'getline x < file' reads a file (returns -1 if missing); the special filename '-' means stdin, and inside the main loop stdin has already been consumed."""
    # CATCHES: getline returns -1 for missing file; '-' maps to stdin
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN {\n\tprint "foo" >"out"\n\tprint close("out")\n\tprint "bar" >"out"\n\tprint close("out")\n\tgetline <"out"\n\tprint $0\n\tprint close("out")\n\tprint close("out")\n}'], b'', {}, [], {}, 0, b'0\n0\nbar\n0\n-1\n', b''),
        (['BEGIN {\n\tprint "foo" >"out"\n\tprint "bar" >"out"\n\tprint close("out")\n\tgetline <"out"\n\tprint $0\n\tprint close("out")\n\tgetline <"out"\n\tprint $0\n\tprint close("out")\n\tprint close("out")\n}'], b'', {}, [], {}, 0, b'0\nfoo\n0\nfoo\n0\n-1\n', b''),
        (['BEGIN { print close("nothing") }'], b'', {}, [], {}, 0, b'-1\n', b''),
        (['BEGIN {\n\tprint "foo">"out"\n\tclose("out")\n\tprint "bar">>"out"\n\tclose("out")\n\tgetline <"out"\n\tprint $0\n\tgetline <"out"\n\tprint $0\n}'], b'', {}, [], {}, 0, b'foo\nbar\n', b''),
    ],
    ids=['close-then-read', 'write-two-read', 'close-unopened', 'append'],
)
def test_redirection_to_files(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """'print > file' truncates on first write and appends while open; close() flushes and returns 0, -1 once already closed; '>>' appends across opens; a written file can be read back with getline after close."""
    # CATCHES: > truncates only on open, close returns 0 then -1, >> appends
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print 1 >"/dev/stderr"; print 2 }'], b'', {}, [], {}, 0, b'2\n', b'1\n'),
        (['BEGIN { print "x"; print "y">"/dev/stdout" }'], b'', {}, [], {}, 0, b'x\ny\n', b''),
    ],
    ids=['stderr', 'stdout'],
)
def test_dev_stdout_and_stderr(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Redirecting to /dev/stdout and /dev/stderr writes to the real process streams, separating them from normal print output."""
    # CATCHES: /dev/stderr redirect lands on stderr, /dev/stdout on stdout
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print "x" | "cat"; close("cat"); print "y" }'], b'', {}, [], {}, 0, b'x\ny\n', b''),
        (['BEGIN { print "1"; "echo 2" | getline x; print x }'], b'', {}, [], {}, 0, b'1\n2\n', b''),
        (['BEGIN { "echo foo" | getline a[1]; print a[1] }'], b'', {}, [], {}, 0, b'foo\n', b''),
    ],
    ids=['pipe-write-close', 'pipe-read', 'pipe-read-array'],
)
def test_pipes(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """'print | command' pipes to a shell command; closing the pipe waits for it; a command on the left of '| getline' pipes its output into the program."""
    # CATCHES: pipe write then close ordering; reading from command pipe
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print system("echo foo"); print system("echo bar") }'], b'', {}, [], {}, 0, b'foo\n0\nbar\n0\n', b''),
        (['BEGIN { print system("exit 42") }'], b'', {}, [], {}, 0, b'42\n', b''),
        (['BEGIN { system("cat") }'], b'foo\nbar', {}, [], {}, 0, b'foo\nbar', b''),
        (['BEGIN { print system(">&2 echo error") }'], b'', {}, [], {}, 0, b'0\n', b'error\n'),
    ],
    ids=['echo', 'exit-status', 'stdin-passthrough', 'stderr'],
)
def test_system_function(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """system() runs a shell command, passes stdin through, and returns the command's exit status; the command's stdout/stderr go to the process streams."""
    # CATCHES: system() returns child exit status and passes streams through
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print fflush(); print fflush("") }'], b'', {}, [], {}, 0, b'0\n0\n', b''),
        (['BEGIN { print "x"; print fflush(); print "y"; print fflush("") }'], b'', {}, [], {}, 0, b'x\n0\ny\n0\n', b''),
        (['BEGIN { print "x" >"out"; print fflush("out"); print "y"; print fflush("") }'], b'', {}, [], {}, 0, b'0\ny\n0\n', b''),
        (['BEGIN { print fflush("x") }'], b'', {}, [], {}, 0, b'-1\n', b'error flushing "x": not an output file or pipe\n'),
        (['BEGIN { "cat" | getline; print fflush("cat") }'], b'', {}, [], {}, 0, b'-1\n', b'error flushing "cat": not an output file or pipe\n'),
    ],
    ids=['bare', 'with-output', 'file', 'unknown', 'input-stream'],
)
def test_fflush(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """fflush() and fflush("") flush all output returning 0; fflush(file) flushes an open stream; an unknown name returns -1 with an error message on stderr (exit stays 0)."""
    # CATCHES: fflush error path returns -1 but keeps exit status 0
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_cannot_read_from_writer_stream(run, tmp_path):
    """Reading (getline) from a stream opened for writing fails with "can't read from writer stream" and exit 1."""
    # CATCHES: stream direction is enforced: writer streams reject getline
    args = ['BEGIN { print "foo" >"out"; getline <"out" }']
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 1
    assert res.stdout == b''
    assert res.stderr == b"can't read from writer stream\n"

