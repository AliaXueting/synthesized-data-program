"""CSV/TSV input and output modes: -i/-o/--csv flags, header rows with @"field" and FIELDS, separator/comment options, and the INPUTMODE/OUTPUTMODE variables."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-icsv', '{ print $2, $1 }'], b'Bob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['-i', 'csv', '{ print $2, $1 }'], b'Bob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['-csv', '{ print $2, $1 }'], b'Bob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['--csv', '{ print $2, $1 }'], b'Bob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
    ],
    ids=['i-attached', 'i-separated', 'csv-short', 'csv-long'],
)
def test_csv_flag_aliases(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-icsv, '-i csv', -csv, and --csv all enable CSV input parsing (quotes honored); -H may come before or after -i."""
    # CATCHES: all CSV flag spellings parse quoted fields identically
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-icsv', '-H', '{ print @"age", @"name" }'], b'name,age\nBob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['-H', '-i', 'csv', '{ print @"age", @"name" }'], b'name,age\nBob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['-icsv', '-H', '{ print $2, $1 }'], b'name,age\nBob,42\nJane,37', {}, [], {}, 0, b'42 Bob\n37 Jane\n', b''),
        (['BEGIN { INPUTMODE="csv header" } NR==1 { for (i=1; i in FIELDS; i++) print i, FIELDS[i] }'], b'name,email,age\na,b,c', {}, [], {}, 0, b'1 name\n2 email\n3 age\n', b''),
        (['BEGIN { INPUTMODE="csv" } { print @"age" }'], b'name,age\nBob,42', {}, [], {}, 1, b'', b'no field names for @; use -H or add "header" to INPUTMODE, and use "getline" first if in BEGIN\n'),
    ],
    ids=['named', 'i-then-H', 'positional-with-header', 'fields-array', 'no-header-error'],
)
def test_csv_header_named_fields(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """With -H the first row is a header: @"name" accesses fields by name, positional $N skips the header, and FIELDS holds the header names; without a header @ errors."""
    # CATCHES: -H consumes header row and enables @-access plus FIELDS
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-o', 'csv', 'BEGIN { print "foo,bar", 3.14, "baz" }'], b'', {}, [], {}, 0, b'"foo,bar",3.14,baz\n', b''),
        (['-o', 'tsv', 'BEGIN { print "a b", 1 }'], b'', {}, [], {}, 0, b'a b\t1\n', b''),
        (['BEGIN { OUTPUTMODE="csv" } { print $2, $1 }'], b'a"b c\nd e', {}, [], {}, 0, b'c,"a""b"\ne,d\n', b''),
        (['BEGIN { OUTPUTMODE="tsv" } { print $2, $1 }'], b'a"b c\nd e', {}, [], {}, 0, b'c\t"a""b"\ne\td\n', b''),
        (['-icsv', '-H', '-ocsv', '{ print @"age", @"name" }'], b'name,age\n"Bo,ba",42\nJane,37', {}, [], {}, 0, b'42,"Bo,ba"\n37,Jane\n', b''),
    ],
    ids=['o-csv', 'o-tsv', 'outputmode-csv', 'outputmode-tsv', 'in-and-out'],
)
def test_csv_output_quoting(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-o csv quotes fields containing the separator, quotes, or newlines (doubling embedded quotes); -o tsv uses tabs; the quoting applies to print with commas."""
    # CATCHES: output quoting doubles embedded quotes, keeps others bare
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-i', 'csv separator=|', '{ print $1, $3 }'], b'Bob,Smith|bob@smith.com|42\nJane|jane@brown.com|37', {}, [], {}, 0, b'Bob,Smith 42\nJane 37\n', b''),
        (['-i', 'csv comment=#', '{ print $1, $3 }'], b'# this is a comment\nBob,Smith,bob@smith.com,42\nJane,jane@brown.com,37', {}, [], {}, 0, b'Bob bob@smith.com\nJane 37\n', b''),
        (['-o', 'csv separator=|', '{ print $2, $1 }'], b'a"b c\nd e', {}, [], {}, 0, b'c|"a""b"\ne|d\n', b''),
        (['-i', 'csv separator=foo', '{}'], b'', {}, [], {}, 1, b'', b'invalid CSV/TSV separator "foo"\n'),
        (['-o', 'csv separator=foo', '{}'], b'', {}, [], {}, 1, b'', b'invalid CSV/TSV separator "foo"\n'),
    ],
    ids=['i-separator', 'i-comment', 'o-separator', 'bad-separator', 'bad-output-separator'],
)
def test_csv_mode_options(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """The -i/-o mode string accepts separator and comment options in one argument; invalid separators error exactly."""
    # CATCHES: 'csv separator=X' splits on X; comment=X skips # lines
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { INPUTMODE="csv separator=,"; print INPUTMODE }'], b'', {}, [], {}, 0, b'csv\n', b''),
        (['BEGIN { INPUTMODE="csv header=true comment=# separator=|"; print INPUTMODE }'], b'', {}, [], {}, 0, b'csv separator=| comment=# header\n', b''),
        (['BEGIN { OUTPUTMODE="csv separator=|"; printf "%s", OUTPUTMODE }'], b'', {}, [], {}, 0, b'csv separator=|', b''),
    ],
    ids=['default-comma', 'normalized', 'outputmode'],
)
def test_inputmode_normalization(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Assigning INPUTMODE normalizes the mode string when read back ('csv header=true ...' becomes 'csv separator=| comment=# header'); an explicit separator=, collapses to the default."""
    # CATCHES: INPUTMODE echoes back normalized, not as written
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { INPUTMODE="csv header" } { print }'], b'name,age\nBob,42\nJane,37', {}, [], {}, 0, b'Bob,42\nJane,37\n', b''),
        (['BEGIN { INPUTMODE="csv" } { print $1, $3 }'], b'name,email,age\nBob,bob@smith.com,42\nJane,jane@brown.com,37', {}, [], {}, 0, b'name age\nBob 42\nJane 37\n', b''),
        (['BEGIN { INPUTMODE="csv header" } { print $1, $3 }'], b'name,email,age\nBob\tSmith,bob@smith.com,42\n\nJane,jane@brown.com,37\n# not a comment', {}, [], {}, 0, b'Bob\tSmith 42\nJane 37\n# not a comment \n', b''),
        (['BEGIN { INPUTMODE="csv header" } { print $0; $0=NR; print $0 }'], b'name,age\nBob,42\nJane,37', {}, [], {}, 0, b'Bob,42\n1\nJane,37\n2\n', b''),
        (['BEGIN { INPUTMODE="csv header"; OUTPUTMODE="csv"; print "age", "name" } { print $2, $1 }'], b'name,age\nBob,42\n"J B",37\n"A""B",7', {}, [], {}, 0, b'age,name\n42,Bob\n37,J B\n7,"A""B"\n', b''),
        (['BEGIN { INPUTMODE="csv" } { s += $-1 } END { print s }'], b'a,1\nb,2\nc,3\n', {}, [], {}, 0, b'6\n', b''),
        (['BEGIN { INPUTMODE="csv" } { $1 = $1 $1; print $1, $2 }'], b'a,1\nb,2', {}, [], {}, 0, b'aa 1\nbb 2\n', b''),
        (['BEGIN { INPUTMODE=OUTPUTMODE="csv" } { $0 = "X,3"; print $1, $2; print }'], b'a,1\nb,2', {}, [], {}, 0, b'X,3\nX,3\nX,3\nX,3\n', b''),
    ],
    ids=['header-skips-first', 'no-header', 'header-fields', 'header-record-assign', 'header-write-csv', 'negative-field', 'concat-field', 'record-resplit'],
)
def test_inputmode_via_variable(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """INPUTMODE/OUTPUTMODE can be set from the program (or -v) instead of flags and take effect from the next record on."""
    # CATCHES: in-program INPUTMODE switch affects records after BEGIN
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_csv_bom_ignored(run, tmp_path):
    """A UTF-8 byte-order mark at the very start of the first line is ignored; a BOM on a later line is kept as data."""
    # CATCHES: BOM stripped from first field of first record only
    args = ['BEGIN { INPUTMODE="csv" } { print $1=="foo" }']
    stdin = b'\xef\xbb\xbffoo,bar\n\xef\xbb\xbffoo,bar'
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'1\n0\n'
    assert res.stderr == b''


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { INPUTMODE = "csv"; split("foo,\\"bar baz\\",,x", a); for (i=1; i in a; i++) print i ": " a[i] }'], b'', {}, [], {}, 0, b'1: foo\n2: bar baz\n3: \n4: x\n', b''),
        (['BEGIN { INPUTMODE = "csv"; split("foo,\\"bar baz\\",,x", a, " "); for (i=1; i in a; i++) print i ": " a[i] }'], b'', {}, [], {}, 0, b'1: foo,"bar\n2: baz",,x\n', b''),
    ],
    ids=['split-csv', 'split-explicit'],
)
def test_split_honors_inputmode(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """split() without a separator argument uses the CSV parser when INPUTMODE is csv (quotes group fields); an explicit separator argument overrides it."""
    # CATCHES: split() defaults to CSV parsing under INPUTMODE=csv
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

