"""Runtime error reporting: plain messages on stderr with exit 1, and how a runtime error aborts the run (END blocks are skipped)."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print 1/0 }'], b'', {}, [], {}, 1, b'', b'division by zero\n'),
        (['BEGIN { print 1%0 }'], b'', {}, [], {}, 1, b'', b'division by zero in mod\n'),
        (['BEGIN { x /= 0 }'], b'', {}, [], {}, 1, b'', b'division by zero\n'),
        (['BEGIN { print sprintf("%d") }'], b'', {}, [], {}, 1, b'', b'format error: got 0 args, expected 1\n'),
        (['BEGIN { printf "%d" }'], b'', {}, [], {}, 1, b'', b'format error: got 0 args, expected 1\n'),
        (['{ NF=-1; }'], b'x', {}, [], {}, 1, b'', b'NF set to negative value: -1\n'),
        (['{ NF=1234567; }'], b'x', {}, [], {}, 1, b'', b'NF set too large: 1234567\n'),
        (['BEGIN { $1234567=1 }'], b'', {}, [], {}, 1, b'', b'field index too large: 1234567\n'),
        (['BEGIN { ARGC=1234567 }'], b'', {}, [], {}, 1, b'', b'ARGC set too large: 1234567\n'),
        (['function f(x) { 0 in _; f(_) }  BEGIN { f() }'], b'', {}, [], {}, 1, b'', b'calling "f" exceeded maximum call depth of 1000\n'),
        (['BEGIN { a[x]; a=42 }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:15: can\'t use array "a" as scalar\nBEGIN { a[x]; a=42 }\n              ^\n'),
        (['BEGIN { s=42; s[x] }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:15: can\'t use scalar "s" as array\nBEGIN { s=42; s[x] }\n              ^\n'),
        (['function f(x) { print x } BEGIN { print f(1, 2) }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:41: "f" called with more arguments than declared\nfunction f(x) { print x } BEGIN { print f(1, 2) }\n                                        ^\n'),
        (['BEGIN { INPUTMODE="xyz" }'], b'', {}, [], {}, 1, b'', b'invalid input mode "xyz"\n'),
        (['BEGIN { INPUTMODE="csv separator=foo" }'], b'', {}, [], {}, 1, b'', b'invalid CSV/TSV separator "foo"\n'),
        (['BEGIN { OUTPUTMODE="csv foo=bar" }'], b'', {}, [], {}, 1, b'', b'invalid output mode key "foo"\n'),
        (['{ sub(/x/, "y", 42) }'], b'x', {}, [], {}, 1, b'', b'<cmdline>:1:17: 3rd arg to sub/gsub must be lvalue\n{ sub(/x/, "y", 42) }\n                ^\n'),
    ],
    ids=['div-zero', 'mod-zero', 'div-assign-zero', 'sprintf-missing-arg', 'printf-missing-arg', 'nf-negative', 'nf-too-large', 'field-too-large', 'argc-too-large', 'call-depth', 'scalar-as-array', 'array-as-scalar', 'too-many-args', 'inputmode-invalid', 'inputmode-separator', 'outputmode-key', 'sub-third-arg'],
)
def test_runtime_error_messages(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Execution errors exit 1 with their exact message on stderr: runtime errors are plain text (division, format mismatches, invalid field counts, call depth, mode validation), while type confusion (scalar/array, wrong arity, sub lvalue) is caught at parse time with position and caret."""
    # CATCHES: exact runtime error text and exit 1 with no stdout prefix
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print 1; print 2/0; print 3 } END { print "end" }'], b'', {}, [], {}, 1, b'1\n', b'division by zero\n'),
        (['{ print NR; if (NR==1) print 1/0 } END { print "end" }'], b'a\nb', {}, [], {}, 1, b'1\n', b'division by zero\n'),
    ],
    ids=['in-begin', 'in-main'],
)
def test_runtime_error_aborts_program_and_skips_end(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """A runtime error stops execution immediately: already-printed output remains on stdout, the error goes to stderr with exit 1, and END blocks do not run."""
    # CATCHES: partial stdout kept, END skipped, exit 1 on runtime error
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_directory_input_file(run, tmp_path):
    """An input operand that names a directory fails at read time with 'error reading from input: read ...: is a directory' and exit 1."""
    # CATCHES: directory operands produce read-error not not-found error
    args = ['{ print }', 'sub']
    stdin = b''
    files = {}
    dirs = ['sub']
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 1
    assert res.stdout == b''
    assert res.stderr == b'error reading from input: read sub: is a directory\n'


def test_input_files_opened_lazily(run, tmp_path):
    """Input files are opened only when the main loop first needs a record: a BEGIN-only program succeeds (exit 0, prints its output) even when its file operand does not exist."""
    # CATCHES: missing file ignored by BEGIN-only program, exit 0
    args = ['BEGIN { print "x" }', 'missing.txt']
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'x\n'
    assert res.stderr == b''

