"""-d AST dump deep-dive: the pretty-printer for every statement and expression form (internal/ast/ast.go String methods), recorded verbatim from the reference."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', 'BEGIN { x = 1 } { print x } END { print "bye" } function double(n) { return n * 2 }'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    x = 1\n}\n\n{\n    print x\n}\n\nEND {\n    print "bye"\n}\n\nfunction double(n) {\n    return n * 2\n}\n', b''),
        (['-d', 'function f() { }'], b'', {}, [], {}, 0, b'function f() {\n}\n', b''),
        (['-d', ''], b'', {}, [], {}, 0, b'\n', b''),
    ],
    ids=['begin-action-end-function', 'function-only', 'empty-program'],
)
def test_program_section_layout(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """The dump prints all BEGIN blocks, then actions in source order, then all END blocks, then functions, joined by blank lines; an empty program dumps a single newline."""
    # CATCHES: section reordering (BEGIN/END/functions collected out of source order) and blank-line separation between sections
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', 'BEGIN {\n  if (x) { print "a" } else { print "b" }\n  for (i = 0; i < 3; i++) print i\n  for (k in arr) print k, arr[k]\n  for (;;) { break }\n  while (0) continue\n  do { x++ } while (x < 2)\n  { print "block" }\n}\n{ next }\n{ nextfile }\nEND { exit 42 }\nfunction f(a) { delete a[1]; delete a; return }'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    if (x) {\n        print "a"\n    } else {\n        print "b"\n    }\n    for (i = 0; i < 3; i++) {\n        print i\n    }\n    for (k in arr) {\n        print k, arr[k]\n    }\n    for (;;) {\n        break\n    }\n    while (0) {\n        continue\n    }\n    do {\n        x++\n    } while (x < 2)\n    {\n        print "block"\n    }\n}\n\n{\n    next\n}\n\n{\n    nextfile\n}\n\nEND {\n    exit 42\n}\n\nfunction f(a) {\n    delete a[1]\n    delete a\n    return\n}\n', b''),
        (['-d', 'BEGIN { exit } END { exit 1 + 1 }\nfunction g() { return }\nfunction h() { return 1 + 2 }\nfunction i2(a) { delete a[1, 2] }\nfunction j(b) { if (b) print 1; else print 2 }'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    exit\n}\n\nEND {\n    exit 1 + 1\n}\n\nfunction g() {\n    return\n}\n\nfunction h() {\n    return 1 + 2\n}\n\nfunction i2(a) {\n    delete a[1, 2]\n}\n\nfunction j(b) {\n    if (b) {\n        print 1\n    } else {\n        print 2\n    }\n}\n', b''),
        (['-d', 'BEGIN { if ((n = 1)) print n; while ((m = getline) > 0) print m }'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    if ((n = 1)) {\n        print n\n    }\n    while ((m = getline) > 0) {\n        print m\n    }\n}\n', b''),
    ],
    ids=['every-statement', 'exit-return-delete', 'assign-in-cond'],
)
def test_statement_prettyprinting(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Every statement kind prints as a fully braced, four-space indented block: if/else, for (with any of init/cond/post omitted), for-in, while, do-while, break, continue, next, nextfile, exit (with and without status), delete (with index, multi-index, and whole array), return (with and without value), and nested stand-alone blocks."""
    # CATCHES: brace-normalization (braces added around single statements) and exit/return/delete argument formatting
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', 'BEGIN {\n  print 1 + 2, 3 * 4, 5 / 2, 5 % 2, 2 - 1, 2 ^ 3 ^ 2\n  print (x == y), (x != y), (x < y), (x <= y), (x > y), (x >= y)\n  print x ~ /foo/, x !~ "bar"\n  print p && q, p || q\n  print "a" "b" "c"\n}'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print 1 + 2, 3 * 4, 5 / 2, 5 % 2, 2 - 1, 2 ^ 3 ^ 2\n    print (x == y), (x != y), (x < y), (x <= y), (x > y), (x >= y)\n    print x ~ /foo/, x !~ "bar"\n    print p && q, p || q\n    print "a" "b" "c"\n}\n', b''),
        (['-d', 'BEGIN {\n  print -x, !x, +x\n  print x++, ++x, x--, --x\n  print $1, $NF, $(NF - 1), $$1\n  print $-1, $"a", $x y, (x), ((x))\n}'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print -x, !x, +x\n    print x++, ++x, x--, --x\n    print $1, $NF, $(NF - 1), $$1\n    print $(-1), $"a", $x y, (x), ((x))\n}\n', b''),
        (['-d', 'BEGIN {\n  print @"name", @x, @("a" "b")\n  print (i, j) in arr, i in arr\n  print i + 1 in arr\n  print !x in arr\n}'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print @"name", @x, @("a" "b")\n    print (i, j) in arr, i in arr\n    print i + 1 in arr\n    print !x in arr\n}\n', b''),
        (['-d', 'BEGIN {\n  print c ? x : y, c ? x : d ? y : z\n  print (c ? x : y) + 1\n  print x = 1, x = y = 1, (x = 1) + 2\n  print x += 1, x -= 1, x *= 1, x /= 1, x %= 1, x ^= 1\n  print $2 += 3, arr[k] ^= v\n}'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print c ? x : y, c ? x : d ? y : z\n    print (c ? x : y) + 1\n    print x = 1, x = y = 1, (x = 1) + 2\n    print x += 1, x -= 1, x *= 1, x /= 1, x %= 1, x ^= 1\n    print $2 += 3, arr[k] ^= v\n}\n', b''),
        (['-d', 'BEGIN {\n  print length($0), split(s, b, ","), sub(/x/, "y", s), sprintf("%d", 1), cos(0), rand()\n  print length(x) + 1, -f(), g() * 2, f(1), f(1, 2)\n  print /re/ + 1\n}\nfunction f(a, b) { }\nfunction g(a) { }'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print length($0), split(s, b, ","), sub(/x/, "y", s), sprintf("%d", 1), cos(0), rand()\n    print length(x) + 1, -f(), g() * 2, f(1), f(1, 2)\n    print /re/ + 1\n}\n\nfunction f(a, b) {\n}\n\nfunction g(a) {\n}\n', b''),
    ],
    ids=['binary-operators', 'unary-field-grouping', 'named-field-in', 'ternary-assign', 'builtin-and-user-calls'],
)
def test_expression_prettyprinting(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Binary operators print with spaces (concatenation as a bare space), unary/incr/field expressions keep only precedence-required parens ($(-1) but $NF), in-expressions keep multi-index parens, and assignment/ternary chains reproduce right-associativity with parens only where precedence demands."""
    # CATCHES: precedence-driven parenthesization, e.g. (c ? x : y) + 1 keeps parens while c ? x : d ? y : z does not, and !x in arr stays unparenthesized
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', 'BEGIN { print 1.5, 0.000001, 1e10, 123456789, 1e100, .5, 100000000000000000000, 9223372036854775807, 1e21, 123.456789, 1e-5, 123456.7 }'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print 1.5, 1e-06, 10000000000, 123456789, 1e+100, 0.5, 1e+20, 9.22337e+18, 1e+21, 123.457, 1e-05, 123457\n}\n', b''),
        (['-d', 'BEGIN { print "a\\tb", "a\\"b", "\\303\\251", "\\x01", x ~ /a\\/b/, y ~ /\\\\/, z ~ /a\\tb/ }'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print "a\\tb", "a\\"b", "\xc3\xa9", "\\x01", x ~ /a\\/b/, y ~ /\\\\/, z ~ /a\\tb/\n}\n', b''),
    ],
    ids=['number-literals', 'string-and-regex-literals'],
)
def test_literal_formatting(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Integer-valued number literals print in full integer form (1e10 becomes 10000000000) while non-integers use %.6g (123456.7 becomes 123457, int64-overflowing 9223372036854775807 becomes 9.22337e+18); string literals are Go-quoted with escapes re-emitted and octal escapes decoded to UTF-8, and regex literals keep their source text with / escaped as \\/."""
    # CATCHES: the int64 vs %.6g split in number formatting and strconv.Quote-style re-escaping of string/regex literals
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', 'BEGIN {\n  print\n  print (1, 2)\n  printf "%d", 1\n  print > "f"\n  print >> g\n  print | "cmd"\n  printf "%s", s >> "g"\n  print $0 > f\n  print $1 > ("f" ".txt")\n  printf "x" | "cmd"\n}'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print \n    print 1, 2\n    printf "%d", 1\n    print  >"f"\n    print  >>g\n    print  |"cmd"\n    printf "%s", s >>"g"\n    print $0 >f\n    print $1 >("f" ".txt")\n    printf "x" |"cmd"\n}\n', b''),
        (['-d', 'BEGIN { print getline, getline v, getline < "f", ("cmd" | getline), ("cmd" | getline x) }\n{ "cmd" | getline x < "f" }'],
         b'', {}, [], {}, 0,
         b'BEGIN {\n    print getline, getline v, getline <"f", ("cmd" |getline), ("cmd" |getline x)\n}\n\n{\n    "cmd" |getline x < "f"\n}\n', b''),
    ],
    ids=['print-printf-redirects', 'getline-forms'],
)
def test_io_expression_prettyprinting(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """print with no args dumps with a trailing space and redirects attach with no space after the operator (print  >"f"); parenthesized print args (1, 2) split into comma-separated args; getline dumps its command (cmd |getline), target, and <file parts in that order with no space after | or <."""
    # CATCHES: redirect spacing quirks (two spaces before > after empty print args, none after) and getline part ordering
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', '/re/\n/start/, /stop/ { }\nNR > 1, NR < 5\n$1 && $2 { print }\n{ }\n$0 { print }\nx ? y : z { print }'],
         b'', {}, [], {}, 0,
         b'/re/\n\n/start/, /stop/ {\n}\n\nNR > 1, NR < 5\n\n$1 && $2 {\n    print \n}\n\n{\n}\n\n$0 {\n    print \n}\n\nx ? y : z {\n    print \n}\n', b''),
    ],
    ids=['pattern-forms'],
)
def test_pattern_sections(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """A pattern-only section prints just the pattern (regex literal, expression, range pair joined with ', '), any expression including ternaries and $0 can be a pattern, and a section with an empty body prints a bare braced block."""
    # CATCHES: range patterns print as two comma-separated patterns and body-less patterns print without braces
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', '-v', 'z=9', '{ print NR }', '-'], b'a\nb\n', {}, [], {}, 0,
         b'{\n    print NR\n}\n', b''),
        (['-d', '-f', 'prog.awk'], b'', {'prog.awk': b'BEGIN { print "fromfile" }\n'}, [], {}, 0,
         b'BEGIN {\n    print "fromfile"\n}\n', b''),
    ],
    ids=['ignores-stdin-and-vars', 'from-f-file'],
)
def test_dump_does_not_execute(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-d exits 0 after printing the dump without running the program: stdin data, -v assignments, and input file arguments are never processed."""
    # CATCHES: -d must not consume input or execute actions (no NR lines printed despite stdin and '-' file arg)
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', 'function f( { }'], b'', {}, [], {}, 1, b'',
         b'<cmdline>:1:13: expected name instead of {\nfunction f( { }\n            ^\n'),
    ],
    ids=['parse-error-wins'],
)
def test_parse_error_precedes_dump(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """A program that fails to parse produces the standard caret-format parse error on stderr with exit 1 and no AST dump on stdout, even under -d."""
    # CATCHES: -d does not suppress or alter parse error reporting (message, source line, caret, exit code)
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err
