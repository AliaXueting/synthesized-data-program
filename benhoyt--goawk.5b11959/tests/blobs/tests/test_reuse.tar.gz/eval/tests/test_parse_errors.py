"""Parse (syntax) error reporting: position-qualified messages with the offending source line and caret, named by program origin (command line, stdin, or -f file)."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['`'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:1: unexpected char\n`\n^\n'),
        (['BEGIN {\n\tx*;\n}'], b'', {}, [], {}, 1, b'', b'<cmdline>:2:4: expected expression instead of ;\n    x*;\n      ^\n'),
        (['BEGIN {\n\tx*\r\n}'], b'', {}, [], {}, 1, b'', b'<cmdline>:2:4: expected expression instead of <newline>\n    x*\r\n      ^\n'),
        (['BEGIN { print "a" } &'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:22: unexpected char after \'&\'\nBEGIN { print "a" } &\n                     ^\n'),
    ],
    ids=['backtick', 'newline-in-expr', 'crlf-source', 'ampersand'],
)
def test_parse_error_format_with_caret(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """A parse error prints 'name:line:col: message', the source line with tabs expanded to 4 spaces, and a caret under the offending column."""
    # CATCHES: tab-expanded source line plus caret column in error output
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-f', '-'], b'\n $', {}, [], {}, 1, b'', b'<stdin>:2:3: expected expression instead of <newline>\n $\n  ^\n'),
        (['-f', 'good.awk', '-f', 'bad.awk'], b'', {'bad.awk': b'x*\n', 'good.awk': b'BEGIN { print 1 }\n'}, [], {}, 1, b'', b'bad.awk:1:3: expected expression instead of <newline>\nx*\n  ^\n'),
        (['-f', 'bad.awk', '-f', 'good.awk'], b'', {'bad.awk': b'x*\n', 'good.awk': b'BEGIN { print 1 }\n'}, [], {}, 1, b'', b'bad.awk:1:3: expected expression instead of <newline>\nx*\n  ^\n'),
        (['-f', 'good.awk', '-f', '-', '-f', 'bad.awk'], b'`', {'bad.awk': b'x*\n', 'good.awk': b'BEGIN { print 1 }\n'}, [], {}, 1, b'', b'<stdin>:1:1: unexpected char\n`\n^\n'),
    ],
    ids=['stdin-prog', 'file-then-bad', 'bad-then-file', 'mix-stdin-first'],
)
def test_parse_error_names_the_program_source(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """The name in a parse error is '<cmdline>' for command-line programs, '<stdin>' for -f -, and the -f file path otherwise; the first offending source reports first."""
    # CATCHES: error prefix identifies whether prog came from CLI/stdin/file
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { printf }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:16: expected printf args, got none\nBEGIN { printf }\n               ^\n'),
        (['BEGIN { next }'], b'', {}, [], {}, 1, b'', b"<cmdline>:1:9: next can't be inside BEGIN or END\nBEGIN { next }\n        ^\n"),
        (['BEGIN { nextfile }'], b'', {}, [], {}, 1, b'', b"<cmdline>:1:9: nextfile can't be inside BEGIN or END\nBEGIN { nextfile }\n        ^\n"),
        (['0 in FS'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:6: can\'t use scalar "FS" as array\n0 in FS\n     ^\n'),
        (['function f() {} function f() {} BEGIN { }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:26: function "f" already defined\nfunction f() {} function f() {} BEGIN { }\n                         ^\n'),
        (['BEGIN { print . }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:16: expected digits\nBEGIN { print . }\n               ^\n'),
        (['BEGIN { print "foo }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:21: can\'t have newline in string\nBEGIN { print "foo }\n                    ^\n'),
        (['/foo'], b'', {}, [], {}, 1, b'', b"<cmdline>:1:5: can't have newline in regex\n/foo\n    ^\n"),
        (['BEGIN { print 1&*2 }'], b'', {}, [], {}, 1, b'', b"<cmdline>:1:17: unexpected char after '&'\nBEGIN { print 1&*2 }\n                ^\n"),
        (['BEGIN { ++3 }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:11: expected lvalue after ++\nBEGIN { ++3 }\n          ^\n'),
        (['{ break }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:3: break must be inside a loop body\n{ break }\n  ^\n'),
        (['BEGIN { return }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:9: return must be inside a function\nBEGIN { return }\n        ^\n'),
        (['BEGIN { print 1e+ }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:19: expected expression instead of }\nBEGIN { print 1e+ }\n                  ^\n'),
        (['function foo(foo) { print "foo", foo } BEGIN { foo(5) }'], b'', {}, [], {}, 1, b'', b'<cmdline>:1:14: can\'t use function name as parameter name\nfunction foo(foo) { print "foo", foo } BEGIN { foo(5) }\n             ^\n'),
    ],
    ids=['printf-no-args', 'next-in-begin', 'nextfile-in-begin', 'in-non-array', 'dup-func', 'dot', 'unterminated-string', 'unterminated-regex', 'bad-unary', 'inc-literal', 'break-outside', 'return-outside', 'exp-eof', 'dup-param'],
)
def test_parse_error_cases(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """A selection of syntax errors from the native test suite: each produces its exact message and exit 1 before any output."""
    # CATCHES: distinct messages for invalid syntax positions and tokens
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

