"""Shared black-box test helpers for the goawk executable.

Every test drives the binary purely through its command line (arguments,
stdin, files inside ``tmp_path``) and compares raw stdout/stderr bytes and
exit status against values recorded from the reference implementation.
"""

import os
import subprocess

import pytest

# Resolved through PROGRAMGYM_EXECUTABLE (set by eval/run.sh) so the same
# tests run unchanged against the reference binary and any candidate build.
GOAWK = os.environ.get("PROGRAMGYM_EXECUTABLE", "executable")

# Pinned, hermetic child environment: fixed PATH and locale, no user state.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "LC_ALL": "C.UTF-8",
    "HOME": "/nonexistent-home",
}


class RunResult:
    """Outcome of one goawk invocation: exit status plus raw output bytes."""

    def __init__(self, returncode, stdout, stderr):
        self.returncode = returncode
        self.stdout = stdout  # raw bytes, so \\x80 and \\r\\n stay exact
        self.stderr = stderr

    @property
    def rc(self):
        return self.returncode

    def __repr__(self):
        return "RunResult(rc=%d, stdout=%r, stderr=%r)" % (
            self.returncode, self.stdout, self.stderr)


def child_env(extra=None):
    """Build the pinned child environment, propagating GOCOVERDIR if set."""
    env = dict(BASE_ENV)
    # Coverage instrumentation hook: the pipeline measures source coverage of
    # the reference binary through GOCOVERDIR, so it must reach the child.
    gocoverdir = os.environ.get("GOCOVERDIR")
    if gocoverdir:
        env["GOCOVERDIR"] = gocoverdir
    if extra:
        env.update(extra)
    return env


def run_goawk(args, stdin=b"", cwd=None, env=None, timeout=10):
    """Run the goawk binary once and return a RunResult with exact bytes."""
    if isinstance(stdin, str):
        stdin = stdin.encode("utf-8")
    try:
        proc = subprocess.run(
            [GOAWK] + list(args),
            input=stdin,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd,
            env=child_env(env),
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        pytest.fail("goawk timed out after %ss: %r" % (timeout, list(args)))
    return RunResult(proc.returncode, proc.stdout, proc.stderr)


@pytest.fixture
def run():
    """Fixture giving access to run_goawk for tests that prefer it."""
    return run_goawk


@pytest.fixture
def workdir(tmp_path):
    """Empty directory the test may chdir into (via cwd=) and fill with files."""
    return tmp_path
