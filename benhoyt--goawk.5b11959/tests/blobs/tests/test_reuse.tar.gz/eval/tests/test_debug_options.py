"""Debug dump options: -d (parsed AST), -da (VM assembly), -dt (variable types); they print to stdout, exit 0, and do not run the program."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-d', '$1 { print 1+1 }'], b'', {}, [], {}, 0, b'$1 {\n    print 1 + 1\n}\n', b''),
        (['-da', '$1 { print 1+1 }'], b'', {}, [], {}, 0, b'        // pattern\n0000    FieldInt 1\n\n        // { body }\n0000    Num 1 (0)\n0002    Num 1 (0)\n0004    Add\n0005    Print 1\n\n', b''),
        (['-d', '-da', '$1 { print 1+1 }'], b'', {}, [], {}, 0, b'$1 {\n    print 1 + 1\n}\n        // pattern\n0000    FieldInt 1\n\n        // { body }\n0000    Num 1 (0)\n0002    Num 1 (0)\n0004    Add\n0005    Print 1\n\n', b''),
        (['-dt', '\nBEGIN { x=42; a[1]=x; print f(a, 1) }\nfunction f(b, y, z) { return b[y+z] }\nfunction hi(x) { print "hi " x }\n'], b'', {}, [], {}, 0, b'globals\n  ARGV: array 0\n  ENVIRON: array 1\n  FIELDS: array 2\n  a: array 3\n  x: scalar 0\nfunction f(b, y, z)  # index 0\n  b: array 0\n  y: scalar 0\n  z: scalar 1\nfunction hi(x)  # index 1\n  x: scalar 0\n', b''),
    ],
    ids=['d', 'da', 'd-da', 'dt'],
)
def test_debug_dumps(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-d pretty-prints the parsed program, -da dumps annotated VM bytecode, -dt prints variable type information, and -d -da concatenates both dumps; none execute the program."""
    # CATCHES: debug flags dump to stdout and exit without running
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

