"""Unicode chars mode (-c) versus default byte mode, and newline output translation modes (-N smart/raw/crlf)."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-c', '{ print length }'], b'\xe7\xb5\xb5\n', {}, [], {}, 0, b'1\n', b''),
        (['-c', 'BEGIN { print length("a"), length("絵") }'], b'', {}, [], {}, 0, b'1 1\n', b''),
        (['-c', 'BEGIN { print index("föö", "f"), index("föö0", 0), index("föö", "ö"), index("föö", "x") }'], b'', {}, [], {}, 0, b'1 4 2 0\n', b''),
        (['-c', 'BEGIN { print substr("food", 1, 2), substr("fööd", 1, 2) }'], b'', {}, [], {}, 0, b'fo f\xc3\xb6\n', b''),
        (['-c', 'BEGIN { print substr("food", 2, 3), substr("fööd", 2, 3) }'], b'', {}, [], {}, 0, b'ood \xc3\xb6\xc3\xb6d\n', b''),
        (['-c', 'BEGIN { print match("絵 fööd y", /[föd]+/), RSTART, RLENGTH }'], b'', {}, [], {}, 0, b'3 3 4\n', b''),
        (['-c', 'BEGIN { printf "%c", 4660 }'], b'', {}, [], {}, 0, b'\xe1\x88\xb4', b''),
    ],
    ids=['length', 'length-str', 'index', 'substr-start', 'substr-mid', 'match', 'printf-c'],
)
def test_chars_mode_functions(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-c makes index, length, match, substr, and %c operate on Unicode characters instead of bytes."""
    # CATCHES: -c counts code points not UTF-8 bytes in string functions
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ print length }'], b'\xe7\xb5\xb5\n', {}, [], {}, 0, b'3\n', b''),
        (['BEGIN { print length("a"), length("絵"), index("föö", "ö") }'], b'', {}, [], {}, 0, b'1 3 2\n', b''),
        (['BEGIN { printf "%c", 4660 }'], b'', {}, [], {}, 0, b'4', b''),
    ],
    ids=['length', 'length-index', 'printf-c'],
)
def test_default_byte_mode(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Without -c, string functions are byte-oriented and %c with a large number emits the low byte as a digit character."""
    # CATCHES: default mode is bytes: length 3 for one CJK char, %c digits
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-N', 'smart', "BEGIN { printf 'foo\\nbar\\n' }"], b'', {}, [], {}, 0, b'foo\nbar\n', b''),
        (['-Nsmart', "BEGIN { printf 'foo\\nbar\\n' }"], b'', {}, [], {}, 0, b'foo\nbar\n', b''),
        (['-N', 'raw', "BEGIN { printf 'foo\\nbar\\n' }"], b'', {}, [], {}, 0, b'foo\nbar\n', b''),
        (['-Nraw', "BEGIN { printf 'foo\\nbar\\n' }"], b'', {}, [], {}, 0, b'foo\nbar\n', b''),
        (['-N', 'crlf', "BEGIN { printf 'foo\\nbar\\n' }"], b'', {}, [], {}, 0, b'foo\r\nbar\r\n', b''),
        (['-Ncrlf', "BEGIN { printf 'foo\\nbar\\n' }"], b'', {}, [], {}, 0, b'foo\r\nbar\r\n', b''),
        (['-o', 'csv', '-Nraw', 'BEGIN { print 1, " 2 " }'], b'', {}, [], {}, 0, b'1," 2 "\n', b''),
        (['-o', 'csv', '-Ncrlf', 'BEGIN { print 1, " 2 " }'], b'', {}, [], {}, 0, b'1," 2 "\r\n', b''),
    ],
    ids=['smart', 'smart-attached', 'raw', 'raw-attached', 'crlf', 'crlf-attached', 'csv-raw', 'csv-crlf'],
)
def test_newline_output_modes(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-N controls newline translation of print/printf output: smart (default) emits \\n, raw emits \\n verbatim, crlf emits \\r\\n; the mode composes with -o csv."""
    # CATCHES: crlf mode writes literal \r\n; raw leaves output untouched
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

