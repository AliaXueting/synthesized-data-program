"""-coverprofile behavior: profile file contents (set/count modes, append), block coordinates with absolute source paths, and the error paths when the __COVER array holds non-numeric data."""

import pytest


def _read(tmp_path, name):
    """Read a file written by the child under tmp_path as raw bytes."""
    return (tmp_path / name).read_bytes()


def _cwd_prefix(tmp_path):
    """Absolute cwd as the child process resolves it (Go makes block paths absolute via os.Getwd, which resolves symlinks)."""
    return str(tmp_path.resolve()).encode()


def test_coverprofile_set_mode_blocks(run, tmp_path):
    """-coverprofile runs the program normally and writes a 'mode: set' profile whose block lines give absolute source path, start.end positions, statement count, and hit flag (1)."""
    # CATCHES: profile records the program's absolute path (<cmdline> under the cwd) with exact block coordinates and hit counts
    (tmp_path / "in.txt").write_bytes(b"a\nb\nc\n")
    res = run(["-coverprofile", "cov.out", 'BEGIN { print "hello" } { print NR }', "in.txt"],
              stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0
    assert res.stdout == b"hello\n1\n2\n3\n"
    assert res.stderr == b""
    prefix = _cwd_prefix(tmp_path)
    assert _read(tmp_path, "cov.out") == (
        b"mode: set\n"
        + prefix + b"/<cmdline>:1.9,1.23 1 1\n"
        + prefix + b"/<cmdline>:1.27,1.36 1 1\n"
    )


def test_coverprofile_count_mode_counts(run, tmp_path):
    """-covermode count writes 'mode: count' and per-block execution counts: the per-record block ran twice while the if-body taken only for the matching record ran once."""
    # CATCHES: count mode accumulates execution counts per block instead of a set/unset flag
    (tmp_path / "in.txt").write_bytes(b"a\nb\n")
    res = run(["-covermode", "count", "-coverprofile", "cov.out",
               '{ if ($1 == "a") print "A" }', "in.txt"],
              stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0
    assert res.stdout == b"A\n"
    assert res.stderr == b""
    prefix = _cwd_prefix(tmp_path)
    assert _read(tmp_path, "cov.out") == (
        b"mode: count\n"
        + prefix + b"/<cmdline>:1.18,1.28 1 1\n"
        + prefix + b"/<cmdline>:1.3,1.18 1 2\n"
    )


def test_coverprofile_empty_program_writes_mode_line_only(run, tmp_path):
    """A program with no coverage-tracked blocks (empty BEGIN body) still creates the profile file, containing only the 'mode: set' header line."""
    # CATCHES: the profile file is created even when no blocks were tracked, with just the mode header
    res = run(["-coverprofile", "cov.out", "BEGIN { }"], stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "cov.out").exists()
    assert _read(tmp_path, "cov.out") == b"mode: set\n"


def test_coverprofile_append_vs_truncate(run, tmp_path):
    """-coverappend appends another block line per run without repeating the mode header, while a second plain -coverprofile run truncates the file back to one header plus one line."""
    # CATCHES: append mode keeps earlier runs' lines and skips the mode line; without it the file is truncated and rewritten
    (tmp_path / "in.txt").write_bytes(b"a\nb\n")
    line = _cwd_prefix(tmp_path) + b"/<cmdline>:1.3,1.9 1 1\n"
    res = run(["-coverprofile", "cov.out", "{ print }", "in.txt"], stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0 and res.stdout == b"a\nb\n"
    res = run(["-coverappend", "-coverprofile", "cov.out", "{ print }", "in.txt"],
              stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0 and res.stdout == b"a\nb\n"
    assert _read(tmp_path, "cov.out") == b"mode: set\n" + line + line
    res = run(["-coverprofile", "cov.out", "{ print }", "in.txt"], stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0
    assert _read(tmp_path, "cov.out") == b"mode: set\n" + line


def test_coverprofile_append_creates_new_file(run, tmp_path):
    """-coverappend on a not-yet-existing profile path behaves like a fresh write: mode header followed by the block lines."""
    # CATCHES: append to a new file still emits the mode header line
    res = run(["-coverappend", "-coverprofile", "cov.out", 'BEGIN { print 1 }'],
              stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0
    assert res.stdout == b"1\n"
    assert _read(tmp_path, "cov.out") == (
        b"mode: set\n" + _cwd_prefix(tmp_path) + b"/<cmdline>:1.9,1.17 1 1\n"
    )


def test_coverprofile_statement_kinds_blocks(run, tmp_path):
    """A program using every statement kind tracks a block per basic block, recording its statement count (e.g. '2' for the printf plus nested-block group) and 0 for blocks that never ran (the { next } action skipped by nextfile, the uncalled function body)."""
    # CATCHES: per-block statement counts and zero counts for unexecuted blocks (nextfile-skipped action and uncalled function)
    (tmp_path / "r.txt").write_bytes(b"a\n")
    prog = ('function cleanup(a) { delete a; return 1 }\n'
            'BEGIN {\n'
            '  for (i = 0; i < 2; i++) { if (i) break; else continue }\n'
            '  while (0) { }\n'
            '  do { x++ } while (x < 1)\n'
            '  for (k in arr) { }\n'
            '  printf "%d", 1\n'
            '  { print "block" }\n'
            '}\n'
            '{ nextfile }\n'
            '{ next }\n'
            'END { exit 0 }')
    res = run(["-coverprofile", "cov.out", prog, "r.txt"], stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0
    assert res.stdout == b"1block\n"
    assert res.stderr == b""
    prefix = _cwd_prefix(tmp_path) + b"/<cmdline>:"
    assert _read(tmp_path, "cov.out") == b"mode: set\n" + b"".join(
        prefix + line for line in [
            b"3.36,3.41 1 1\n",
            b"3.48,3.57 1 1\n",
            b"3.29,3.36 1 1\n",
            b"3.3,3.27 1 1\n",
            b"4.3,4.13 1 1\n",
            b"5.8,5.12 1 1\n",
            b"5.3,5.27 1 1\n",
            b"6.3,6.18 1 1\n",
            b"8.5,8.19 1 1\n",
            b"7.3,8.20 2 1\n",
            b"10.3,10.12 1 1\n",
            b"11.3,11.8 1 0\n",
            b"12.7,12.14 1 1\n",
            b"1.23,1.42 2 0\n",
        ]
    )


def test_coverprofile_group_positions(run, tmp_path):
    """Block coordinates come from the first statement's start to the last statement's end, so a leading stand-alone block gets its own entry and a trailing printf terminates its group; never-called functions report their multi-statement group with count 0."""
    # CATCHES: groups span consecutive simple statements (numStmts 2-3) and record 0 hits when the function is never called
    prog = ('function f(a) { return 1; x = 2 }\n'
            'function g(b) { y = 1; delete b }\n'
            'BEGIN { { print "b1" } print "b2"; z = 1; printf "%d", 9 }')
    res = run(["-coverprofile", "cov.out", prog], stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 0
    assert res.stdout == b"b1\nb2\n9"
    assert res.stderr == b""
    prefix = _cwd_prefix(tmp_path) + b"/<cmdline>:"
    assert _read(tmp_path, "cov.out") == b"mode: set\n" + b"".join(
        prefix + line for line in [
            b"3.11,3.22 1 1\n",
            b"3.9,3.24 1 1\n",
            b"3.24,3.58 3 1\n",
            b"1.17,1.33 2 0\n",
            b"2.17,2.33 2 0\n",
        ]
    )


@pytest.mark.parametrize(
    'args, stdin, files, expected_line',
    [
        (["-coverprofile", "cov.out", "-f", "-"], b'BEGIN { print "x" }\n', {},
         b"<stdin>:1.9,1.19 1 1\n"),
        (["-coverprofile", "cov.out", "-f", "prog.awk"], b"", {"prog.awk": b'BEGIN { print "p" }\n'},
         b"prog.awk:1.9,1.19 1 1\n"),
    ],
    ids=["stdin-program", "f-file-program"],
)
def test_coverprofile_names_program_source(run, tmp_path, args, stdin, files, expected_line):
    """The profile's source path is the resolved cwd plus '<stdin>' for a -f - program and the -f file's path for a file program."""
    # CATCHES: profile block paths distinguish stdin vs file program sources and are made absolute against the cwd
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    res = run(args, stdin=stdin, cwd=tmp_path, env={})
    assert res.rc == 0
    assert res.stderr == b""
    assert _read(tmp_path, "cov.out") == b"mode: set\n" + _cwd_prefix(tmp_path) + b"/" + expected_line


@pytest.mark.parametrize(
    'prog, stdin, err',
    [
        ('BEGIN { __COVER[1] = "strval" }', b"",
         b"unable to write coverage profile: non-float64 value in data: strval\n"),
        ('BEGIN { if (__COVER[9]) print }', b"",
         b"unable to write coverage profile: non-float64 value in data: \n"),
        ('{ __COVER[7] = $1 }', b"5\n",
         b"unable to write coverage profile: non-float64 value in data: 5\n"),
        ('BEGIN { __COVER["x"] = 1 }', b"",
         b"unable to write coverage profile: non-int index in data: x\n"),
    ],
    ids=["string-value", "null-value", "strnum-field-value", "non-int-index"],
)
def test_coverprofile_bad_cover_data_errors(run, tmp_path, prog, stdin, err):
    """Writing non-numeric values into the internal __COVER array makes profile writing fail after the program ran: exit 1, the exact 'unable to write coverage profile: ...' message on stderr, and no profile file created (string, null, and numeric-string input field values, plus non-integer indices, are all rejected)."""
    # CATCHES: coverage data conversion rejects string/null/strnum values and non-int keys with distinct messages, before the profile file is created
    res = run(["-coverprofile", "cov.out", prog], stdin=stdin, cwd=tmp_path, env={})
    assert res.rc == 1
    assert res.stdout == b""
    assert res.stderr == err
    assert not (tmp_path / "cov.out").exists()


def test_coverprofile_unwritable_path(run, tmp_path):
    """When the profile path names a directory, the program's normal output is still produced, then the run fails with 'unable to write coverage profile: open ...: is a directory' on stderr and exit 1."""
    # CATCHES: profile open failure surfaces after execution (stdout preserved) as a stderr message with exit 1
    (tmp_path / "adir").mkdir()
    res = run(["-coverprofile", "adir", 'BEGIN { print 1 }'], stdin=b"", cwd=tmp_path, env={})
    assert res.rc == 1
    assert res.stdout == b"1\n"
    assert res.stderr == b"unable to write coverage profile: open adir: is a directory\n"
