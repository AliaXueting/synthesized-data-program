"""Field and record splitting: FS/OFS/ORS interaction, field assignment rebuilding $0, NF manipulation, negative indices, RS (including regex and paragraph mode) and RT."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-F', ',', '{ print $1, $3 }'], b'1 2 3\n4 5 6', {}, [], {}, 0, b'1 2 3 \n4 5 6 \n', b''),
        (['-F,', '{ print $1, $3 }'], b'1,2,3\n4,5,6', {}, [], {}, 0, b'1 3\n4 6\n', b''),
        (['-v', 'OFS=.', '{ print $1, $3 }'], b'1 2 3\n4 5 6', {}, [], {}, 0, b'1.3\n4.6\n', b''),
        (['-v', 'OFS=.', '-v', 'ORS=', '{ print $1, $3 }'], b'1 2 3\n4 5 6', {}, [], {}, 0, b'1.34.6', b''),
    ],
    ids=['F-comma-space', 'F-comma', 'ofs-dot', 'ofs-ors'],
)
def test_fs_field_splitting(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """-F sets FS; a single-space FS splits on runs of whitespace, other separators split literally; print re-joins fields with OFS and terminates with ORS."""
    # CATCHES: FS=',' literal vs default whitespace splitting; OFS/ORS on print
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ print NF }'], b'\na\nc d\ne f g', {}, [], {}, 0, b'0\n1\n2\n3\n', b''),
        (['{ print; print $1, $3, $NF }'], b'a b c d e', {}, [], {}, 0, b'a b c d e\na c e\n', b''),
    ],
    ids=['nf', 'fields'],
)
def test_nf_and_field_references(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """NF counts fields per record (0 for a blank record) and $NF references the last field."""
    # CATCHES: NF is 0 on empty line but record still prints as blank
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ print $1,$3; $2="x"; print; print $2 }'], b'a b c', {}, [], {}, 0, b'a c\na x c\nx\n', b''),
        (['{ print; $0="x y z"; print; print $1, $3 }'], b'a b c', {}, [], {}, 0, b'a b c\nx y z\nx z\n', b''),
        (['{ print NF; NF=1; $2="two"; print $0, NF }'], b'\n', {}, [], {}, 0, b'0\n two 2\n', b''),
        (['{ NF=1; $3="x"; print $0; print NF }'], b'a b', {}, [], {}, 0, b'a  x\n3\n', b''),
        (['{ NF=3; $1="x"; print $0; print NF }'], b'a', {}, [], {}, 0, b'x  \n3\n', b''),
    ],
    ids=['assign-mid', 'assign-zero', 'nf-then-assign', 'nf-trunc-extend', 'nf-extend'],
)
def test_field_assignment_rebuilds_record(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Assigning a field rebuilds $0 by joining fields with OFS; assigning $0 re-splits fields; setting NF truncates or pads the record with empty fields."""
    # CATCHES: $-rebuild joins with OFS; NF= extends record with blanks
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ print $-1 }'], b'a\nb c\nd e f\n', {}, [], {}, 0, b'a\nc\nf\n', b''),
        (['{ $-1="x"; print }'], b'a\nb c\nd e f\n', {}, [], {}, 0, b'x\nb x\nd e x\n', b''),
    ],
    ids=['read', 'write'],
)
def test_negative_field_indices(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Negative field indices count from the end; assigning a negative index extends the record."""
    # CATCHES: $-1 is last field; assignment to $-1 appends
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ $$0++; print $0 }'], b'2 3 4', {}, [], {}, 0, b'3\n', b''),
        (['BEGIN { $0="3 4 5 6 7 8 9"; a=3; print $$a++++; print }'], b'', {}, [], {}, 0, b'7\n3 4 6 6 8 8 9\n', b''),
    ],
    ids=['dollar-dollar', 'dollar-inc'],
)
def test_field_index_expressions(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Field indices are full expressions: $$0 uses $0's value as an index (a non-numeric whole-record string indexes field 0), and $$a++++ pairs post-increments left-to-right."""
    # CATCHES: $$0++ increments the record itself via index 0 semantics
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { RS="ö" }  { print }'], b'1\xc3\xb6two\xc3\xb6three', {}, [], {}, 0, b'1\ntwo\nthree\n', b''),
        (['BEGIN { RS="\\\\.+" }  { print }'], b'1.two..three...4.', {}, [], {}, 0, b'1\ntwo\nthree\n4\n', b''),
        (['BEGIN { RS=".." } { print $0 RT }'], b'foo bar bazz', {}, [], {}, 0, b'fo\no \nba\nr \nba\nzz\n', b''),
        (['BEGIN { FS="x"; RS=",.*," } { print }'], b'one,\n,two', {}, [], {}, 0, b'one\ntwo\n', b''),
        (['BEGIN { print RS; RS="|"; print RS }  { print }'], b'a b|c d|', {}, [], {}, 0, b'\n\n|\na b\nc d\n', b''),
    ],
    ids=['rs-literal-unicode', 'rs-regex', 'rt', 'rs-regex-fs', 'rs-change'],
)
def test_rs_multichar_and_rt(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """A multi-character RS is treated as a regex; a single-character RS matches literally; RT holds the actual record terminator matched."""
    # CATCHES: regex RS vs literal single-char RS; RT is the matched text
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { RS=""; FS="\\n" }  { printf "%d (%d):\\n", NR, NF; for (i=1; i<=NF; i++) print $i }'], b'a\n\nb\nc', {}, [], {}, 0, b'1 (1):\na\n2 (2):\nb\nc\n', b''),
        (['BEGIN { RS=""; FS="\\n" }  { printf "%d (%d):\\n", NR, NF; for (i=1; i<=NF; i++) print $i }'], b'a b\nc d\n\ne f\n\n\n  \n\n\ng h\n\n\n', {}, [], {}, 0, b'1 (2):\na b\nc d\n2 (1):\ne f\n3 (1):\n  \n4 (1):\ng h\n', b''),
        (['BEGIN { RS="" }  { print "got", $0 } END { print "records:", NR }'], b'\n\n\n\n', {}, [], {}, 0, b'records: 0\n', b''),
    ],
    ids=['para-no-trailing', 'para-multi', 'para-blank-input'],
)
def test_rs_paragraph_mode(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """RS="" splits input into paragraphs (blank-line separated), stripping leading/trailing newlines; multiple blank lines count once, and an all-blank input yields no records (END still runs and sees NR=0)."""
    # CATCHES: paragraph mode strips blank lines and collapses separators
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_subsep(run, tmp_path):
    """Multi-dimensional array subscripts join with SUBSEP (default 0x1c); SUBSEP is assignable and affects new subscripts."""
    # CATCHES: default SUBSEP byte 0x1c; reassignment changes joins
    args = ['BEGIN { print SUBSEP; a[1, 2] = "onetwo"; print a[1, 2]; SUBSEP = "|"; print SUBSEP; a[1, 2] = "onetwo"; print a[1, 2] }']
    stdin = b''
    files = {}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'\x1c\nonetwo\n|\nonetwo\n'
    assert res.stderr == b''

