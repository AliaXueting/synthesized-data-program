"""Program source loading and input file handling: -f files, stdin via '-', ARGV/ARGC manipulation, FNR/NR/FILENAME bookkeeping."""

import pytest


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['-f', '-'], b'BEGIN { print "b" }', {}, [], {}, 0, b'b\n', b''),
        (['-f', '-', '-f', '-'], b'BEGIN { print "b" }', {}, [], {}, 0, b'b\n', b''),
    ],
    ids=['f-dash', 'f-dash-twice'],
)
def test_program_from_stdin_dash(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """'-f -' reads the program from stdin; a second '-f -' re-reads (now empty) stdin and concatenates nothing."""
    # CATCHES: stdin consumed once as program source, second read is empty
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_multiple_program_files(run, tmp_path):
    """Multiple -f files concatenate into one program and both run in source order."""
    # CATCHES: concatenated program order: BEGIN runs, then main rules
    args = ['-f', 'good.awk', '-f', 'good2.awk']
    stdin = b'hi\n'
    files = {'good.awk': b'BEGIN { print 1 }\n', 'good2.awk': b'{ print "two", $0 }\n'}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'1\ntwo hi\n'
    assert res.stderr == b''


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['{ print FILENAME ":" FNR "/" NR ": " $0 }', 'g1.txt', 'g4.txt'], b'', {'g1.txt': b'ONE\n', 'g4.txt': b'FOUR a\nFOUR b\n'}, [], {}, 0, b'g1.txt:1/1: ONE\ng4.txt:1/2: FOUR a\ng4.txt:2/3: FOUR b\n', b''),
        (['$0', 'g1.txt', '-', 'g1.txt'], b'STDIN', {'g1.txt': b'ONE\n'}, [], {}, 0, b'ONE\nSTDIN\nONE\n', b''),
        (['$0', 'g1.txt', '-', 'g1.txt', '-'], b'STDIN', {'g1.txt': b'ONE\n'}, [], {}, 0, b'ONE\nSTDIN\nONE\n', b''),
        (['{ print NR, FNR } END { print NR, FNR }', '-'], b'a\nb\nc\n', {}, [], {}, 0, b'1 1\n2 2\n3 3\n3 3\n', b''),
    ],
    ids=['two-files', 'stdin-between', 'stdin-twice', 'nr-fnr-end'],
)
def test_filename_fnr_nr_across_input_files(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """Reading multiple file operands resets FNR per file while NR keeps counting; FILENAME reflects the current operand ('-' for stdin)."""
    # CATCHES: FNR resets per file, NR global, stdin operand named '-'
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_nextfile_skips_current_file(run, tmp_path):
    """nextfile stops processing the current file and moves to the next input operand immediately."""
    # CATCHES: nextfile jumps to next operand, not just next record
    args = ['{ print FILENAME ":" FNR "/" NR ": " $0 }  FNR==2 { nextfile }', 'g5.txt', '-', 'g6.txt']
    stdin = b'a\nb\nc\n'
    files = {'g5.txt': b'one\ntwo 2\n', 'g6.txt': b'Uno\nDuo\n'}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'g5.txt:1/1: one\ng5.txt:2/2: two 2\n-:1/3: a\n-:2/4: b\ng6.txt:1/5: Uno\ng6.txt:2/6: Duo\n'
    assert res.stderr == b''


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN {\n\tfor (i=1; i<ARGC; i++) {\n\t\tprint i, ARGV[i]\n\t}\n}', 'a', 'b'], b'', {}, [], {}, 0, b'1 a\n2 b\n', b''),
        (['BEGIN {\n\tfor (i=1; i<ARGC; i++) {\n\t\tprint i, ARGV[i]\n\t\tdelete ARGV[i]\n\t}\n}\n$0', 'a', 'b'], b'c\nd', {}, [], {}, 0, b'1 a\n2 b\nc\nd\n', b''),
        (['BEGIN {\n\tARGV[1] = ""\n}\n$0', 'g1.txt', '-', 'g1.txt'], b'c\nd', {'g1.txt': b'ONE\n'}, [], {}, 0, b'c\nd\nONE\n', b''),
        (['BEGIN {\n\tARGC = 3\n}\n$0', 'g1.txt', '-', 'g1.txt'], b'c\nd', {'g1.txt': b'ONE\n'}, [], {}, 0, b'ONE\nc\nd\n', b''),
    ],
    ids=['list', 'delete', 'empty', 'argc'],
)
def test_argv_and_argc_manipulation(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """ARGV and ARGC are live: deleting an ARGV entry skips that input, an empty ARGV entry also skips it, and shrinking ARGC truncates the operand list."""
    # CATCHES: ARGV/ARGC edits control which operands are read as input
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err


def test_var_assignment_operands(run, tmp_path):
    """A name=value operand assigns the variable when reached during input processing, so assignments interleaved with files take effect between files."""
    # CATCHES: assignment operands apply in position, not up front
    args = ['-v', 'A=1', '-f', 'g3.awk', 'B=2', 'countries.txt']
    stdin = b''
    files = {'countries.txt': b'Russia\t8650\t262\tAsia\nCanada\t3852\t24\tNorth America\n', 'g3.awk': b'BEGIN {\n\tprint "A=" A ", B=" B+0\n\tprint "\\tARGV[1] = " ARGV[1]\n\tprint "\\tARGV[2] = " ARGV[2]\n}\n$2 > 100 { print "A=" A ", B=" B+0 }'}
    dirs = []
    env = {}
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == 0
    assert res.stdout == b'A=1, B=0\n\tARGV[1] = B=2\n\tARGV[2] = countries.txt\nA=1, B=2\nA=1, B=2\n'
    assert res.stderr == b''


@pytest.mark.parametrize(
    'args, stdin, files, dirs, env, rc, out, err',
    [
        (['BEGIN { print FILENAME }'], b'', {}, [], {}, 0, b'\n', b''),
        (['{ print FILENAME }'], b'a', {}, [], {}, 0, b'-\n', b''),
        (['BEGIN { FILENAME = "10"; print(FILENAME, FILENAME<2) }\nBEGIN { FILENAME = 10; print(FILENAME, FILENAME<2) }\n{ print(FILENAME, FILENAME<2) }', '10', '10x'], b'', {'10': b'one\n', '10x': b'two\n'}, [], {}, 0, b'10 1\n10 0\n10 0\n10x 1\n', b''),
        (['BEGIN { print(ARGV[1]<2, ARGV[2]<2); ARGV[1]="10"; ARGV[2]="10x"; print(ARGV[1]<2, ARGV[2]<2) }', '10', '10x'], b'', {}, [], {}, 0, b'0 1\n1 1\n', b''),
    ],
    ids=['begin-empty', 'stdin-dash', 'filename-set', 'argv-strnum'],
)
def test_filename_type_semantics(run, tmp_path, args, stdin, files, dirs, env, rc, out, err):
    """FILENAME starts empty, becomes '-' for stdin, and setting FILENAME in BEGIN gives it string type; comparing it with a number follows strnum comparison rules per operand."""
    # CATCHES: FILENAME is strnum-typed: '10'<2 is true but 10<2 is not
    for name, data in files.items():
        (tmp_path / name).write_bytes(data)
    for name in dirs:
        (tmp_path / name).mkdir()
    res = run(args, stdin=stdin, cwd=tmp_path, env=env)
    assert res.rc == rc
    assert res.stdout == out
    assert res.stderr == err

