"""Values and coercion: null, str, num and numStr types.

An uninitialized variable reads as both "" and 0; string-to-number parses the
leading numeric prefix (including hex and inf/nan forms); comparison is
numeric only when both sides are numbers or numeric strings; number-to-string
conversion uses CONVFMT or OFMT.
"""

import pytest


def test_uninitialized_variable_is_empty_and_zero(run_goawk):
    """An uninitialized variable reads as "" in string context and 0 in numeric."""
    # CATCHES: an implementation whose null value prints as "0" or fails to
    # concatenate as the empty string would differ on all three lines.
    res = run_goawk(
        'BEGIN { print uninit; print uninit + 5; print uninit "x"; print uninit * 3 }'
    )
    assert res.returncode == 0
    assert res.stdout == "\n5\nx\n0\n"


def test_uninitialized_comparison_takes_other_side_type(run_goawk):
    """A null value compares numerically with numbers, as a string with strings."""
    # CATCHES: the null value is neither str nor num, so it adopts the other
    # operand's comparison type instead of always comparing one way.
    res = run_goawk(
        'BEGIN { print (uninit == 0), (uninit == ""), (uninit == "0"), (uninit == "e") }'
    )
    assert res.returncode == 0
    assert res.stdout == "1 1 0 0\n"


def test_zero_number_vs_empty_string_not_equal(run_goawk):
    """The number 0 and the string "" are not equal: comparison is by string."""
    # CATCHES: a str-vs-num comparison converts the number with CONVFMT ("0")
    # and compares strings, so 0 and "" differ unlike the null value case.
    res = run_goawk('BEGIN { n = 0; s = ""; print (n == s), (n == ""), (s == 0) }')
    assert res.returncode == 0
    assert res.stdout == "0 0 0\n"


@pytest.mark.parametrize(
    "text, expected",
    [
        ("3x", "3"),
        ("", "0"),
        ("  42abc", "42"),
        ("1e3", "1000"),
        (".5xyz", "0.5"),
        ("-7.25rest", "-7.25"),
        ("1_000", "1"),  # underscore digit separators are not AWK numbers
        ("1e", "1"),  # dangling exponent is ignored
        ("1e+", "1"),
        (".", "0"),
        ("e5", "0"),
        ("+", "0"),
        ("-", "0"),
        ("+-1", "0"),
    ],
)
def test_string_to_number_prefix_parsing(run_goawk, text, expected):
    """String-to-number conversion parses the leading numeric prefix."""
    # CATCHES: a full-string ParseFloat would reject "3x" and "1e"; the
    # reference parses the valid prefix and silently drops the rest.
    res = run_goawk('BEGIN { print "%s" + 0 }' % text)
    assert res.returncode == 0
    assert res.stdout == expected + "\n"


@pytest.mark.parametrize(
    "text, expected",
    [
        ("0x1f", "31"),  # hex integer form
        ("0x10", "16"),
        ("-0x10", "-16"),
        ("0x1p3", "8"),  # hex float with binary exponent
        ("0x.8p1", "1"),
        ("0x", "0"),  # bare 0x is not a hex number
        ("0xg", "0"),
        ("inf", "inf"),
        ("-inf", "-inf"),
        ("Inf", "inf"),  # case-insensitive special values
        ("NAN", "nan"),
        ("infinityx", "inf"),  # special prefix wins even with trailing junk
        ("1e1000", "inf"),  # overflow saturates
        ("-1e1000", "-inf"),
    ],
)
def test_string_to_number_hex_and_specials(run_goawk, text, expected):
    """Hex integers and inf/nan forms are recognized when converting."""
    # CATCHES: hex without a 'p' exponent and signed 'nan' need special
    # handling that a plain Go/strconv ParseFloat does not provide.
    res = run_goawk('BEGIN { print "%s" + 0 }' % text)
    assert res.returncode == 0
    assert res.stdout == expected + "\n"


def test_number_to_string_default_format(run_goawk):
    """Non-integral numbers convert to strings with "%.6g" by default."""
    # CATCHES: 1/3 must print as 0.333333 (six significant digits), not the
    # full float64 expansion, and identical for both CONVFMT and print.
    res = run_goawk('BEGIN { print 1/3; print 1/3 ""; print 2.5; print 1/3 == 0.333333 }')
    assert res.returncode == 0
    assert res.stdout == "0.333333\n0.333333\n2.5\n0\n"


def test_large_integers_print_exactly(run_goawk):
    """Integral float64 values convert to strings as exact integers."""
    # CATCHES: values beyond 2^53 round in float64 and must print as the
    # rounded integer, and 1e15/1e16 must not switch to exponent notation.
    res = run_goawk(
        "BEGIN { print 1e15; print 1e16; print 9007199254740993; print 123456789012345678 }"
    )
    assert res.returncode == 0
    assert res.stdout == (
        "1000000000000000\n"
        "10000000000000000\n"
        "9007199254740992\n"
        "123456789012345680\n"
    )


def test_huge_number_converts_to_scientific_notation(run_goawk):
    """1e100 converts to a string using %.6g, giving "1e+100"."""
    # CATCHES: %.6g formatting switches to exponential form for large
    # exponents and Go's FormatFloat spells it "1e+100", not "1E+100".
    res = run_goawk('BEGIN { x = 1e100; print x ""; print (x "" == "1e+100") }')
    assert res.returncode == 0
    assert res.stdout == "1e+100\n1\n"


def test_nan_inf_string_forms(run_goawk):
    """nan and +/-inf convert to the strings "nan", "inf" and "-inf"."""
    # CATCHES: these bypass CONVFMT/OFMT entirely and use fixed spellings
    # (Go prints "inf", not "infinity", and NaN is always unsigned).
    res = run_goawk('BEGIN { print 2^1024; print -2^1024; print "nan"+0; print +"inf" }')
    assert res.returncode == 0
    assert res.stdout == "inf\n-inf\nnan\ninf\n"


def test_nan_comparison_semantics(run_goawk):
    """NaN follows IEEE semantics: unequal and unordered in comparisons."""
    # CATCHES: an implementation that compares NaN as a plain float64 gets
    # all six comparisons right, but string/number coercion must not kick in.
    res = run_goawk(
        'BEGIN { n = "nan"+0; print (n == n), (n != n), (n < 1), (n > 1), (n <= n), (n >= n) }'
    )
    assert res.returncode == 0
    assert res.stdout == "0 1 0 0 0 0\n"


def test_nan_string_comparison(run_goawk):
    """A nan number compared against the string "nan" compares as strings."""
    # CATCHES: toString(nan) is "nan", so the mixed comparison is the string
    # comparison "nan" == "nan" which is true.
    res = run_goawk('BEGIN { print ("nan" == "nan"), ("nan"+0 == "nan") }')
    assert res.returncode == 0
    assert res.stdout == "1 1\n"


def test_comparison_numeric_when_both_sides_numbers(run_goawk):
    """"9" < "10" is false as strings but true when compared numerically."""
    # CATCHES: the string literals compare lexically ("9" > "10"), while the
    # same values coming from fields are numeric strings and compare 9 < 10.
    res = run_goawk('BEGIN { print ("9" < "10") }')
    assert res.returncode == 0
    assert res.stdout == "0\n"

    res = run_goawk('{ print ($1 < $2) }', stdin="9 10\n")
    assert res.returncode == 0
    assert res.stdout == "1\n"


def test_numstr_field_comparison_rules(run_goawk):
    """Field values compare numerically when they parse as numbers."""
    # CATCHES: input fields are numeric strings: "9" vs 9 is numeric, but a
    # field like "3.0abc" that does not fully parse compares as a string.
    res = run_goawk('{ print ($1 == 9); print ($1 == "3.0abc"); print ($1 == 3) }',
                    stdin="3.0abc\n")
    assert res.returncode == 0
    assert res.stdout == "0\n1\n0\n"

    res = run_goawk('{ print ($1 == 3) }', stdin="9\n")
    assert res.returncode == 0
    assert res.stdout == "0\n"


def test_field_text_is_preserved_verbatim(run_goawk):
    """A numeric string keeps its original text: "007" stays "007"."""
    # CATCHES: reformatting a field through its numeric value would turn
    # "007" into "7" and " 9" into "9" when concatenated or printed.
    res = run_goawk('{ print $1; print $1+1; print $1 ""; s = $1; print s, s == 7 }',
                    stdin="007\n")
    assert res.returncode == 0
    assert res.stdout == "007\n8\n007\n007 1\n"


def test_numstr_strict_parsing_for_comparison(run_goawk):
    """Field comparison uses full-string float parsing, not prefix parsing."""
    # CATCHES: $1+0 uses prefix parsing ("1e" gives 1) but deciding whether
    # $1 is numeric uses strict parsing, so "1e" compares as a string and
    # "1e" == 1 is false.
    res = run_goawk('{ printf "%s|eq=%d|plus=%d\\n", $1, ($1 == ($1+0)), $1+0 }',
                    stdin="1e\n1_0\n+n\n")
    assert res.returncode == 0
    assert res.stdout == "1e|eq=0|plus=1\n1_0|eq=0|plus=1\n+n|eq=0|plus=0\n"


def test_numstr_hex_field_compares_numerically(run_goawk):
    """A hex field value is a numeric string and compares numerically."""
    # CATCHES: strict parsing accepts "0x10" (with an implicit p0 exponent),
    # so the field equals the number 16 rather than the string "16".
    res = run_goawk('{ print ($1 == 16), ($1 == "0x10"), ($1+0) }', stdin="0x10\n")
    assert res.returncode == 0
    assert res.stdout == "1 1 16\n"


@pytest.mark.parametrize(
    "expr, expected",
    [
        ('"1e1" == 10', "0"),  # string "1e1" vs "10" compares as text
        ('"10" == 1e1', "1"),  # number 10 converts to "10" first
        ('" 1" == 1', "0"),  # leading space makes it a different string
        ('"0x10" == 16', "0"),
        ('" 5 " == 5', "0"),  # string with padding vs number
        ("0.1+0.2 == 0.3", "0"),  # float64 addition is not exact
        ("1 == 1.0", "1"),
        ("1e100 == 1e100", "1"),
    ],
)
def test_mixed_type_comparison_selection(run_goawk, expr, expected):
    """A comparison is a string comparison if either side is a true string."""
    # CATCHES: if one side is a pure string the other side's number is run
    # through CONVFMT and compared as text, which flips several results.
    res = run_goawk("BEGIN { print (%s) }" % expr)
    assert res.returncode == 0
    assert res.stdout == expected + "\n"


def test_string_number_arithmetic_coercion(run_goawk):
    """Arithmetic always coerces both operands through prefix parsing."""
    # CATCHES: "9" + "1" is 10 (not "91") and "0x10" * 2 is 32, unlike the
    # comparison operators which would use string semantics here.
    res = run_goawk('BEGIN { print "9" + "1"; print "0x10" * 2; print "a" + "b"; print "3" * "4" }')
    assert res.returncode == 0
    assert res.stdout == "10\n32\n0\n12\n"


def test_concat_conversion_uses_convfmt(run_goawk):
    """Concatenating a number uses CONVFMT, while print uses OFMT."""
    # CATCHES: the same value can render differently in the two contexts;
    # with the defaults they agree, but the paths are independent.
    res = run_goawk('BEGIN { x = 0.5; print x "x"; print x }')
    assert res.returncode == 0
    assert res.stdout == "0.5x\n0.5\n"


def test_boolean_truth_of_values(run_goawk):
    """"0" is true (non-empty string), 0.0 and "" are false."""
    # CATCHES: truthiness of a string is only about being non-empty; only
    # numeric values and parseable numeric strings use the != 0 rule.
    res = run_goawk(
        'BEGIN { print ("0" ? 1 : 0), ("" ? 1 : 0), (0.0 ? 1 : 0), ("x" ? 1 : 0), (0 ? 1 : 0) }'
    )
    assert res.returncode == 0
    assert res.stdout == "1 0 0 1 0\n"


def test_numstr_field_truth(run_goawk):
    """A field whose text is "0" is false; one with text "0x" is true."""
    # CATCHES: field "0" parses strictly to 0 and is false, but "0x" fails
    # strict parsing and falls back to the non-empty-string rule.
    res = run_goawk('{ print ($1 ? "T" : "F") }', stdin="0\n0x\n00\n")
    assert res.returncode == 0
    assert res.stdout == "F\nT\nF\n"
