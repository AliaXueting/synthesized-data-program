"""User-defined functions: parameters as locals, recursion, call limits.

Function semantics of the core language: parameters double as local
variables, calling with fewer arguments than declared is allowed (the
missing ones read as ""/0), more arguments is a parse error, recursion works
up to the 1000-frame limit, and `return` without a value yields a null value.
"""

import pytest


def test_function_returns_value(run_goawk):
    """A function computes and returns a value from its parameters."""
    # CATCHES: argument evaluation and the return expression are ordinary
    # expressions; add(2, 3) must yield exactly 5.
    res = run_goawk("function add(a, b) { return a + b } BEGIN { print add(2, 3) }")
    assert res.returncode == 0
    assert res.stdout == "5\n"


def test_function_calls_compose_as_expressions(run_goawk):
    """Function calls are expressions and compose with operator precedence."""
    # CATCHES: g() + g() * 2 must honor * over + (1 + 2 = 3), evaluating
    # g() twice rather than caching a result.
    res = run_goawk("function g() { return 1 } BEGIN { print g() + g() * 2 }")
    assert res.returncode == 0
    assert res.stdout == "3\n"


def test_function_defined_after_use(run_goawk):
    """Functions may be called before their definition appears in the file."""
    # CATCHES: the resolver collects all functions first, so forward use is
    # legal, unlike statement-level forward references to variables.
    res = run_goawk("BEGIN { x = h(2); print x } function h(n) { return n * 10 }")
    assert res.returncode == 0
    assert res.stdout == "20\n"


def test_bare_return_yields_null_value(run_goawk):
    """return with no value yields a value that is "" and 0."""
    # CATCHES: the returned null prints as an empty field, concatenates as
    # "" and adds as 0 -- all three coercions of one null value.
    res = run_goawk(
        'function f(x) { return } BEGIN { r = f(1); print r, r "", r + 0 }'
    )
    assert res.returncode == 0
    assert res.stdout == "  0\n"


def test_calling_with_fewer_arguments(run_goawk):
    """Missing trailing arguments are supplied as null ("")."""
    # CATCHES: only "x" arrives; b and c read as empty strings, so the
    # concatenation is exactly "x" rather than an error.
    res = run_goawk('function f(a, b, c) { return a b c } BEGIN { print f("x") }')
    assert res.returncode == 0
    assert res.stdout == "x\n"


def test_calling_with_more_arguments_is_parse_error(run_goawk):
    """Calling with more arguments than declared never starts running."""
    # CATCHES: the arity check happens at compile time with a source position
    # pointing at the call site and the function name in the message.
    res = run_goawk("function f(x) { return x } BEGIN { print f(1, 2) }")
    assert res.returncode == 1
    assert res.stdout == ""
    lines = res.stderr.splitlines()
    assert lines[0].startswith("<cmdline>:1:42:")
    assert '"f" called with more arguments than declared' in lines[0]


def test_recursion_computes_nested_calls(run_goawk):
    """Recursive calls nest correctly, each with its own frame."""
    # CATCHES: fact(10) needs 10 live frames at once with independent n
    # values; a shared-frame implementation returns a wrong product.
    res = run_goawk(
        "function fact(n) { return n <= 1 ? 1 : n * fact(n-1) } BEGIN { print fact(10) }"
    )
    assert res.returncode == 0
    assert res.stdout == "3628800\n"


def test_recursion_exceeds_call_depth_limit(run_goawk):
    """Unbounded recursion stops at the 1000-frame limit with an error."""
    # CATCHES: the runtime error message has no source position (unlike parse
    # errors), names the function, states the limit, and exits 1.
    res = run_goawk("function r(n) { return r(n+1) } BEGIN { print r(0) }")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'calling "r" exceeded maximum call depth of 1000\n'


def test_parameters_are_local_copies(run_goawk):
    """Assigning to a parameter does not modify the caller's variable."""
    # CATCHES: parameters are by-value for scalars: f() sets its local x to
    # 99 while the caller's v keeps 5.
    res = run_goawk("function f(x) { x = 99; return x } BEGIN { v = 5; print f(v), v }")
    assert res.returncode == 0
    assert res.stdout == "99 5\n"


def test_unqualified_assignment_inside_function_hits_global(run_goawk):
    """A name that is not a parameter resolves to the global variable."""
    # CATCHES: y is not declared as a parameter, so f() writes the global y,
    # changing what BEGIN sees afterwards.
    res = run_goawk("function f() { y = 7 } BEGIN { y = 1; f(); print y }")
    assert res.returncode == 0
    assert res.stdout == "7\n"


def test_extra_parameters_serve_as_local_variables(run_goawk):
    """By convention extra parameters act as function-local variables."""
    # CATCHES: i and s are locals (separated from real args by spaces), so
    # the loop and accumulator leave no trace on any global.
    res = run_goawk(
        "function f(n, i, s) { s = 0; for (i = 0; i < n; i++) s += i; return s }"
        "BEGIN { print f(5) }"
    )
    assert res.returncode == 0
    assert res.stdout == "10\n"


def test_scalar_argument_passed_to_array_param_is_parse_error(run_goawk):
    """Passing a non-array where an array parameter is expected is rejected."""
    # CATCHES: the check is static: the string literal is not an array, and
    # the error names it in the message with a position on the call.
    res = run_goawk('function f(s) { s[1] = 1 } BEGIN { f("scalar") }')
    assert res.returncode == 1
    assert res.stdout == ""
    lines = res.stderr.splitlines()
    assert lines[0].startswith("<cmdline>:1:36:")
    assert 'can\'t pass scalar "scalar" as array param' in lines[0]


def test_function_call_inside_pattern_and_action(run_goawk):
    """User functions can be called from patterns as well as actions."""
    # CATCHES: the pattern regex test and the action's function call both
    # evaluate per record; substr here just proves argument passing works.
    res = run_goawk(
        "function firstchar(s) { return substr(s, 1, 1) }"
        '$1 ~ /r/ { print firstchar($1) }',
        stdin="r1\nr2\n",
    )
    assert res.returncode == 0
    assert res.stdout == "r\nr\n"


def test_passing_global_array_creates_it(run_goawk):
    """An undeclared global passed as an array param becomes an array."""
    # CATCHES: f(x) with x never used before must bind x as an array, so the
    # assignment inside the function is visible in the caller afterwards.
    res = run_goawk(
        'function f(a) { a[1] = "set" } BEGIN { f(x); print x[1] }'
    )
    assert res.returncode == 0
    assert res.stdout == "set\n"
