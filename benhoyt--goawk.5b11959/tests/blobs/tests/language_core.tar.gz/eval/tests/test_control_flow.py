"""Control flow: if/else, loops, break/continue, next, nextfile, exit.

All structured-control constructs of the core language: if/else binding,
while, do-while and for(;;) loops (each comparison operator drives a
different loop-condition opcode), break/continue semantics per loop kind,
``next`` and ``nextfile`` record/file skipping, and exit out of loops.
"""

import pytest


def test_if_else_and_dangling_else(run_goawk):
    """An else binds to the nearest if, not the outer one."""
    # CATCHES: grouping the else with the outer if would print "c" instead of
    # "b"; the nested-if form pins AWK's dangling-else resolution.
    res = run_goawk(
        'BEGIN { x = 1; if (x == 1) if (x == 2) print "a"; else print "b"; else print "c" }'
    )
    assert res.returncode == 0
    assert res.stdout == "b\n"


def test_while_loop_and_false_condition(run_goawk):
    """while runs zero times when the condition starts false."""
    # CATCHES: a while whose body never prints must not fall back to running
    # once (that would be do-while behaviour); only "once" appears.
    res = run_goawk(
        'BEGIN { i = 0; while (i < 3) { print i; i++ }; while (0) print "never"; print "done" }'
    )
    assert res.returncode == 0
    assert res.stdout == "0\n1\n2\ndone\n"


def test_do_while_runs_body_once_when_false(run_goawk):
    """do-while evaluates the condition only after the first body run."""
    # CATCHES: checking the condition before the body would print nothing for
    # i=5; the reference runs the body once and leaves i incremented.
    res = run_goawk(
        'BEGIN { i = 5; do { print "body", i; i++ } while (i < 3); print "i", i }'
    )
    assert res.returncode == 0
    assert res.stdout == "body 5\ni 6\n"


@pytest.mark.parametrize(
    "op, expected_body_count",
    [
        ("<", 3),
        ("<=", 4),
        ("!=", 3),
        (">", 0),
        (">=", 0),
        ("==", 0),
    ],
)
def test_for_loop_condition_operators(run_goawk, op, expected_body_count):
    """for (;;) uses the six comparison operators with i starting at 0."""
    # CATCHES: each operator drives a distinct loop-condition path; a wrong
    # strict/non-strict choice changes the body count between 3 and 4, and
    # the "after" line proves control reaches past the loop in every case.
    res = run_goawk(
        'BEGIN { for (i = 0; i %s 3; i++) print "body"; print "after" }' % op
    )
    assert res.returncode == 0
    assert res.stdout == "body\n" * expected_body_count + "after\n"


def test_break_and_continue_in_for_loop(run_goawk):
    """continue skips the rest of the body; break leaves the loop."""
    # CATCHES: the for-increment still runs after continue (i reaches 4), and
    # break stops before the i==4 iteration prints.
    res = run_goawk(
        'BEGIN { for (i = 0; i < 5; i++) { if (i == 2) continue; if (i == 4) break; print i } }'
    )
    assert res.returncode == 0
    assert res.stdout == "0\n1\n3\n"


def test_break_exits_only_innermost_loop(run_goawk):
    """break inside a nested loop only terminates the inner one."""
    # CATCHES: a break that unwound both loops would print one line total;
    # the reference restarts the inner loop for the second outer iteration.
    res = run_goawk(
        'BEGIN { for (i = 0; i < 2; i++) { for (j = 0; j < 5; j++) { if (j == 1) break; print i, j } } }'
    )
    assert res.returncode == 0
    assert res.stdout == "0 0\n1 0\n"


def test_continue_in_while_skips_rest_of_body(run_goawk):
    """In a while loop, continue jumps back to the condition immediately."""
    # CATCHES: unlike a for loop, the increment lives in the body, so moving
    # it after the continue would loop forever; the reference prints 1 3 5.
    res = run_goawk(
        "BEGIN { i = 0; while (i < 5) { i++; if (i % 2 == 0) continue; print i } }"
    )
    assert res.returncode == 0
    assert res.stdout == "1\n3\n5\n"


def test_exit_stops_loop_and_runs_end_block(run_goawk):
    """exit from inside a loop aborts the loop but still runs END."""
    # CATCHES: treating exit like break would print "3" as well, and skipping
    # END would lose the "end" line; the status comes from the exit operand.
    res = run_goawk(
        'BEGIN { for (i = 0; i < 10; i++) { if (i == 3) exit 2; print i } } END { print "end" }'
    )
    assert res.returncode == 2
    assert res.stdout == "0\n1\n2\nend\n"
    assert res.stderr == ""


def test_next_skips_remaining_rules_for_record(run_goawk):
    """next abandons the current record, skipping all later rules."""
    # CATCHES: if next only ended the current rule's action, "r2 a" would be
    # printed for the first record and "r1end" for every record.
    res = run_goawk(
        '{ print "r1", $0; if ($1 == "a") next; print "r1end" } { print "r2", $0 }',
        stdin="a\nb\n",
    )
    assert res.returncode == 0
    assert res.stdout == "r1 a\nr1 b\nr1end\nr2 b\n"


def test_next_skips_rest_of_current_rule_only(run_goawk):
    """next skips to the next record from a mid-rule position."""
    # CATCHES: statements after next in the same action must not run, so
    # "got a" never appears even though the earlier print does.
    res = run_goawk('{ if ($1 == "a") next; print "got", $1 }', stdin="a\nb\n")
    assert res.returncode == 0
    assert res.stdout == "got b\n"


@pytest.mark.parametrize(
    "prog, message_line",
    [
        ("BEGIN { next }", "next can't be inside BEGIN or END"),
        ("END { next }", "next can't be inside BEGIN or END"),
        ("BEGIN { nextfile }", "nextfile can't be inside BEGIN or END"),
        ("END { nextfile }", "nextfile can't be inside BEGIN or END"),
    ],
)
def test_next_nextfile_in_begin_end_are_parse_errors(run_goawk, prog, message_line):
    """next/nextfile inside BEGIN or END are rejected at parse time."""
    # CATCHES: these are compile-time rejections, not runtime errors: the
    # message carries a source position and the program never starts.
    res = run_goawk(prog, stdin="x\n")
    assert res.returncode == 1
    assert res.stdout == ""
    lines = res.stderr.splitlines()
    assert lines[0].startswith("<cmdline>:1:")
    assert message_line in lines[0]


def test_nextfile_moves_to_next_input_file(run_goawk, write_input):
    """nextfile abandons the current file and continues with the next one."""
    # CATCHES: FNR must reset to 1 per file while NR keeps counting across
    # files, and only the first record of each file is processed.
    write_input("f1.txt", "f1a\nf1b\n")
    write_input("f2.txt", "f2a\nf2b\n")
    res = run_goawk(
        '{ print FILENAME, FNR, NR, $0; nextfile } END { print "end", NR }',
        args=["f1.txt", "f2.txt"],
    )
    assert res.returncode == 0
    assert res.stdout == "f1.txt 1 1 f1a\nf2.txt 1 2 f2a\nend 2\n"


def test_boolean_patterns_with_and_or(run_goawk):
    """Patterns combine with && and ||, both evaluated per record."""
    # CATCHES: a rule with /a/ && /b/ must not fire on records with only one
    # of the regexes, while /a/ || /c/ fires on either.
    res = run_goawk(
        '/a/ && /b/ { print "both", $0 }\n/a/ || /c/ { print "either", $0 }',
        stdin="ab\naxb\ncd\n",
    )
    assert res.returncode == 0
    assert res.stdout == "both ab\neither ab\nboth axb\neither axb\neither cd\n"


def test_runtime_error_inside_pattern_evaluation(run_goawk):
    """A runtime error while evaluating a pattern stops the program."""
    # CATCHES: the pattern 1/$1 divides by zero on the second record; the
    # first record must have completed processing before the error.
    res = run_goawk('NR>1 && 1/$1 { print "pat", $0 } END { print "end" }',
                    stdin="3\n0\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "division by zero\n"


def test_string_comparisons_in_condition_position(run_goawk):
    """Comparisons used as if/while conditions compare as strings lexically."""
    # CATCHES: in condition position the compiler fuses each comparison into
    # a single conditional-jump opcode, and that opcode must keep the same
    # string-vs-number rule as the standalone operators -- with a string on
    # the left every test below compares lexically ("b" < "c" true, "9" <
    # "10" false so the while body never runs), and every false branch (taken
    # or skipped jump) prints nothing at all.
    res = run_goawk(
        'BEGIN { s = "b";'
        ' if (s == "b") print "eq"; if (s != "c") print "ne";'
        ' if (s < "c") print "lt"; if (s > "a") print "gt";'
        ' if (s <= "b") print "le"; if (s >= "b") print "ge";'
        ' n = 0; while ("9" < "10") n++; print "while", n;'
        ' if (s == "a") print "no"; if (s < "a") print "no";'
        ' if (s > "b") print "no"; if (s != "b") print "no";'
        ' print "none" }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "eq\nne\nlt\ngt\nle\nge\nwhile 0\nnone\n"
