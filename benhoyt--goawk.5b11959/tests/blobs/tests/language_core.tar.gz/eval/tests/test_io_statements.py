"""getline variants and print/printf redirection (vm.go I/O opcodes).

``getline`` reads a record ahead of the main loop into a variable, a field,
a special variable or an array element -- optionally from a redirected file
or command -- and returns 1 on success, 0 at end of input and -1 on error.
``print``/``printf`` can redirect to a file (truncated on the first open of
the run, appended to afterwards) or pipe to a command.
"""

import pytest


def test_getline_into_global_variable_reads_ahead(run_goawk):
    """getline x pulls the next record into x and returns 1, or 0 at EOF."""
    # CATCHES: each getline consumes one more record from the main input and
    # yields 1, while at end of input it yields 0 and leaves the target
    # variable as the empty string.
    res = run_goawk(
        'BEGIN { getline x; print "got:" x; getline y; print "got:" y;'
        ' print (getline z), "[" z "]" }',
        stdin="hello\nworld\n",
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "got:hello\ngot:world\n0 []\n"


def test_getline_bare_in_action_replaces_record(run_goawk):
    """A bare getline inside an action loads the next record into $0."""
    # CATCHES: the record read by getline replaces $0 (and the main loop then
    # continues from the record AFTER it), so the second "rec:" line shows
    # the third input line, not the second one again.
    res = run_goawk('{ print "rec:" $0; getline; print "line:" $0 }',
                    stdin="a\nb\nc\n")
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "rec:a\nline:b\nrec:c\nline:c\n"


def test_getline_into_field_replaces_whole_record(run_goawk):
    """getline $N loads the line into $0, ignoring the field index."""
    # CATCHES: the reference's GetlineField opcode assigns field 0 whatever
    # index the program wrote, so "getline $2" replaces the entire record
    # (NF drops to the field count of the line read) rather than setting $2;
    # at EOF it returns 0 and leaves the current record untouched.
    res = run_goawk('{ print "rec:" $0; getline $2; print "after:" $0, NF }',
                    stdin="one two\nthree four\nfive six\n")
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == ("rec:one two\nafter:three four 2\n"
                          "rec:five six\nafter:five six 2\n")


def test_getline_into_special_variable_sets_it(run_goawk):
    """getline NR stores the line's numeric value and still counts records."""
    # CATCHES: getline from the main input sets the named special variable to
    # the line read (numStr "7" reads back as 7) while ALSO advancing the
    # record counters, so FNR shows 1 and END sees NR advanced past the
    # record the main loop then consumed.
    res = run_goawk("BEGIN { getline NR; print NR, FNR } END { print NR }",
                    stdin="7\n8\n")
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "7 1\n8\n"


def test_getline_into_array_element_uses_preead_index(run_goawk):
    """The subscript of getline a[i] is evaluated before the record is read."""
    # CATCHES: NR is read for the subscript first (storing under key "1"),
    # then getline consumes "q" and bumps NR to 2 -- so a[NR] afterwards is
    # empty while a[1] holds the line, and only key "1" exists in END.
    res = run_goawk(
        '{ getline a[NR]; print "NR=" NR, "a1=" a[1] }'
        ' END { for (k in a) print "key:" k }',
        stdin="p\nq\n",
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "NR=2 a1=q\nkey:1\n"


def test_getline_from_file_keeps_one_position_per_name(run_goawk, write_input):
    """getline x < "file" reads successive lines of that file."""
    # CATCHES: all getline statements naming the same file share one read
    # position (the second getline continues at line 2, the while loop then
    # picks up at line 3), and the loop stops with 0 at end of file.
    write_input("in2.txt", "r1\nr2\nr3\n")
    res = run_goawk(
        'BEGIN { getline a < "in2.txt"; getline b < "in2.txt"; print a "/" b;'
        ' while ((getline l < "in2.txt") > 0) last = l; print "last:" last }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "r1/r2\nlast:r3\n"


def test_getline_from_missing_file_returns_minus_one(run_goawk):
    """getline from a file that cannot be opened yields -1 and carries on."""
    # CATCHES: a failed file redirection is not a fatal error -- getline
    # returns -1, the target variable stays empty, NR is untouched (file
    # redirections never advance the record counters), and the program keeps
    # running with exit status 0 and nothing on stderr.
    res = run_goawk(
        'BEGIN { n = (getline x < "nope.txt"); print n, "[" x "]", NR }',
        stdin="",
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "-1 [] 0\n"


def test_getline_into_function_local_variable(run_goawk):
    """Inside a function, getline writes into the local parameter."""
    # CATCHES: the local parameter is a distinct slot from any global, so
    # getline loc reads the line into the frame and the bare getline used as
    # a return value still yields 1 per record consumed.
    res = run_goawk(
        "function f(loc) { getline loc; return loc }"
        " function g(loc) { return getline loc }"
        ' BEGIN { print "<" f(0) ">", g(0), g(0) }',
        stdin="deep\nz\nmore\n",
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "<deep> 1 1\n"


def test_print_redirect_truncates_once_then_appends(run_goawk, tmp_path):
    """Repeated ">" redirects to one name share a single truncated stream."""
    # CATCHES: the file is opened (and truncated) only on the FIRST redirect
    # to that name in the run -- later "print > name" calls append to the
    # same open stream, so all three lines land in the file in order, and
    # nothing leaks to stdout.
    res = run_goawk(
        'BEGIN { print "a" > "out.txt"; print "b" > "out.txt" }'
        ' END { print "z" > "out.txt" }'
    )
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert (tmp_path / "out.txt").read_bytes() == b"a\nb\nz\n"


def test_print_append_redirect_extends_file(run_goawk, tmp_path):
    """>> appends to the stream opened by an earlier > in the same run."""
    # CATCHES: within one run ">>" to a name already opened by ">" writes to
    # that same open stream (no second open, no repositioning), so the three
    # statements produce a, b, c in order.
    res = run_goawk(
        'BEGIN { print "a" > "f.txt"; print "b" >> "f.txt"; print "c" > "f.txt" }'
    )
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert (tmp_path / "f.txt").read_bytes() == b"a\nb\nc\n"


def test_printf_redirect_writes_formatted_output(run_goawk, tmp_path):
    """printf with a file redirect formats then writes to that file."""
    # CATCHES: printf's format string is processed exactly as on stdout (the
    # \n escape and the %d/%s conversions) and the result goes to the file,
    # with successive redirects appending like print does.
    res = run_goawk(
        'BEGIN { printf "%d=%s\\n", 1, "x" > "p.txt";'
        ' printf "%s\\n", "second" > "p.txt" }'
    )
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert (tmp_path / "p.txt").read_bytes() == b"1=x\nsecond\n"


def test_print_redirect_into_missing_directory_is_error(run_goawk):
    """Redirecting into a path whose directory is missing is a fatal error."""
    # CATCHES: opening sub/out.txt fails because sub/ does not exist; the
    # error goes to stderr only (stdout stays empty) prefixed with
    # "output redirection error: " and the process exits with status 1
    # without creating anything.
    res = run_goawk('BEGIN { print "x" > "sub/out.txt" }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "output redirection error: open sub/out.txt: no such file or directory\n"
    )


def test_print_pipe_streams_all_writes_to_one_command(run_goawk):
    """print | "cmd" sends every write for that command to one process."""
    # CATCHES: the three statements share a single "sort" process (opened
    # once per command string), so sort sees all three lines on its stdin and
    # the output arrives sorted -- not three separate commands.
    res = run_goawk('BEGIN { print "1" | "sort"; print "3" | "sort"; print "2" | "sort" }')
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "1\n2\n3\n"


def test_print_with_no_arguments_redirects_record(run_goawk, tmp_path):
    """A bare "print > file" writes the current record, not a blank line."""
    # CATCHES: print with zero arguments writes $0 verbatim (unformatted,
    # regardless of the surrounding fields) once per record to the file.
    res = run_goawk('{ print > "noargs.txt" }', stdin="a b\nc d\n")
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert (tmp_path / "noargs.txt").read_bytes() == b"a b\nc d\n"


def test_printf_redirect_into_missing_directory_is_error(run_goawk):
    """printf's file redirect reports the same open failure as print."""
    # CATCHES: printf evaluates and formats its arguments, but the failure
    # happens when the destination is opened, so nothing is written, the
    # "output redirection error: " message goes to stderr alone and the
    # process exits 1.
    res = run_goawk('BEGIN { printf "%d", 5 > "sub2/out.txt" }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "output redirection error: open sub2/out.txt: no such file or directory\n"
    )


def test_directory_as_input_file_is_read_error(run_goawk, write_input, tmp_path):
    """A directory named as an input file fails when the record is read."""
    # CATCHES: opening succeeds, so the failure only surfaces when the first
    # record is read: the earlier file's records are still printed, the
    # message "error reading from input: read <name>: is a directory" goes
    # to stderr alone and the exit status is 1.
    write_input("good.txt", "one\ntwo\n")
    (tmp_path / "adir").mkdir()
    res = run_goawk('{ print $0 }', args=["good.txt", "adir"])
    assert res.returncode == 1
    assert res.stdout == "one\ntwo\n"
    assert res.stderr == "error reading from input: read adir: is a directory\n"


def test_newline_output_modes(run_cli):
    """-N translates every output newline: smart/raw stay LF, crlf adds CR."""
    # CATCHES: crlf mode rewrites each "\\n" written by print AND printf (and
    # by redirected files) into "\\r\\n" while leaving output with no
    # trailing newline untouched; smart and raw both leave plain LF on Linux,
    # and any other -N value is rejected before the program runs.
    crlf = run_cli(["-N", "crlf", 'BEGIN { print "a"; printf "x\\ny\\n" }'])
    assert crlf.returncode == 0
    assert crlf.stderr == ""
    assert crlf.stdout == "a\r\nx\r\ny\r\n"
    none = run_cli(["-N", "crlf", 'BEGIN { printf "no-newline" }'])
    assert none.returncode == 0
    assert none.stdout == "no-newline"
    for mode in ("smart", "raw"):
        keep = run_cli(["-N", mode, 'BEGIN { print "a" }'])
        assert keep.returncode == 0
        assert keep.stdout == "a\n"
    bad = run_cli(["-N", "bogus", 'BEGIN { print "a" }'])
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == "-N arg can only be one of: smart, raw, crlf\n"


def test_newline_crlf_applies_to_redirected_files(run_cli, tmp_path):
    """-N crlf also translates newlines written into redirected files."""
    # CATCHES: the translation happens in the output writer, so a file
    # opened by "print > name" receives the same CRLF line endings as
    # stdout, not the raw LF the program produced.
    res = run_cli(["-N", "crlf", 'BEGIN { print "a" > "crlf.txt" }'])
    assert res.returncode == 0
    assert res.stdout == ""
    assert (tmp_path / "crlf.txt").read_bytes() == b"a\r\n"


@pytest.mark.parametrize(
    "target",
    [
        "y",          # global variable
        "$1",         # field
        "a[1]",       # array element
        "NR",         # special variable
        "",           # bare getline (record itself)
        "loc",        # function-local variable (via call below)
    ],
)
def test_getline_from_writer_stream_is_error(run_goawk, target):
    """getline cannot read a name already opened for writing."""
    # CATCHES: after "print > name" the name is registered as an output
    # stream, so a later "getline < name" is rejected for every target form
    # -- variable, field, array element, special variable or the bare
    # record -- with the bare message on stderr and exit status 1.
    if target == "loc":
        prog = ('function f(loc) { getline loc < "w.txt" }'
                ' BEGIN { print "x" > "w.txt"; f(1) }')
    elif target == "":
        prog = 'BEGIN { print "x" > "w.txt"; getline < "w.txt" }'
    else:
        prog = 'BEGIN { print "x" > "w.txt"; getline %s < "w.txt" }' % target
    res = run_goawk(prog)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "can't read from writer stream\n"
