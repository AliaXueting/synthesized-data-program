"""The -da debug dump (internal/compiler/disassembler.go).

-da prints a human-readable disassembly of the compiled program -- the
opcode names come from opcode_string.go, the operand rendering and section
headers from disassembler.go -- and then exits WITHOUT running the program.
The dump is fully deterministic: 4-hex-digit addresses, one section per
BEGIN/main/action/END/function region, each followed by a blank line.
"""

RICH_PROGRAM = """\
function total(arr,   t, k) { for (k in arr) t += arr[k]; return t }
BEGIN {
  x = 1; y = 2
  x += 3; y ^= 2
  a[1] = "one"; b[1, 2] = x
  if (1 in a && !(x > y)) print "yes"; else print "no"
  while (x < 10) x++
  for (i = 0; i < 3; i++) { if (i == 1) continue; break }
  delete a[1]; delete b
  print x, y, $1, $NF, total(a), x ~ /z/ ? "m" : "n", x !~ "q"
  printf "%d\\n", x > "out.txt"
  getline line < "in.txt"
  print | "sort"
  exit 0
}
"""

MORE_PROGRAM = """\
function ops(arr,   loc) {
  loc = 1
  loc++
  arr[2]++
  arr[3] *= 2
  getline loc
  return 2 in arr
}
BEGIN {
  x = 1.5
  NR += 2
  NF++
  $1 += 2
  a[1] += 4
  a[1]++
  print length(a), length("abc"), @"name"
  split("a b", s)
  split("a,b", t, ",")
  u = sprintf("%d", 7)
  v = "a" "b" "c" "d"
  if (x > 1 || x <= 2) print v
  while (x != 9) break
  getline
  getline $3
  getline NR
  getline a[5]
  print ops(a)
}
"""

THIRD_PROGRAM = """\
function two(arr1, arr2) { return (1 in arr1) || (2 in arr2) }
function mixed(scal, arr3) { arr3[1] = "x"; return scal }
BEGIN {
  FS = ":"
  $2++
  printf "%d", 5
  x = a[7]
  print two(c, d), mixed(9, e)
  for (g in a) print g
  while (x > 1) break
  for (i = 0; i <= 2; i++) print i
}
"""

THIRD_EXPECTED = """\
        // BEGIN
0000    Str ":" (3)
0002    AssignSpecial FS
0004    Num 2 (0)
0006    IncrField 1
0008    Str "%d" (4)
000a    Num 5 (1)
000c    Printf 2
000f    Str "7" (5)
0011    ArrayGlobal a
0013    AssignGlobal x
0015    CallUser two [c, d]
001c    Num 9 (2)
001e    CallUser mixed [e]
0023    Print 2
0026    ForIn g a 0x0031
002c    Global g
002e    Print 1
0031    Global x
0033    Num 1 (3)
0035    JumpLessOrEqual 0x003f
0037    Jump 0x003f
0039    Global x
003b    Num 1 (3)
003d    JumpGreater 0x0037
003f    Num 0 (4)
0041    AssignGlobal i
0043    Global i
0045    Num 2 (0)
0047    JumpGreater 0x0057
0049    Global i
004b    Print 1
004e    IncrGlobal 1 i
0051    Global i
0053    Num 2 (0)
0055    JumpLessOrEqual 0x0049

        // function two
0000    Str "1" (0)
0002    InLocal arr1
0004    Dupe
0005    JumpTrue 0x000c
0007    Drop
0008    Str "2" (1)
000a    InLocal arr2
000c    Boolean
000d    Return

        // function mixed
0000    Str "x" (2)
0002    Str "1" (0)
0004    AssignArrayLocal arr3
0006    Local scal
0008    Return

"""

MORE_EXPECTED = """\
        // BEGIN
0000    Num 1.5 (2)
0002    AssignGlobal x
0004    Num 2 (1)
0006    AugAssignSpecial AugOpAdd %!d(string=NR)
0009    IncrSpecial 1 NF
000c    Num 2 (1)
000e    Num 1 (0)
0010    AugAssignField AugOpAdd
0012    Num 4 (3)
0014    Str "1" (2)
0016    AugAssignArrayGlobal AugOpAdd a
0019    Str "1" (2)
001b    IncrArrayGlobal 1 a
001e    CallLengthArray a
0021    Str "abc" (3)
0023    CallBuiltin BuiltinLengthArg
0025    FieldByNameStr "name" (4)
0027    Print 3
002a    Str "a b" (5)
002c    CallSplit s
002f    Drop
0030    Str "a,b" (6)
0032    Str "," (7)
0034    CallSplitSep t 0
0038    Drop
0039    Str "%d" (8)
003b    Num 7 (4)
003d    CallSprintf 2
003f    AssignGlobal u
0041    Str "a" (9)
0043    Str "b" (10)
0045    Str "c" (11)
0047    Str "d" (12)
0049    ConcatMulti 4
004b    AssignGlobal v
004d    Global x
004f    Num 1 (0)
0051    Greater
0052    Dupe
0053    JumpTrue 0x005b
0055    Drop
0056    Global x
0058    Num 2 (1)
005a    LessOrEqual
005b    Boolean
005c    JumpFalse 0x0063
005e    Global v
0060    Print 1
0063    Global x
0065    Num 9 (5)
0067    JumpEquals 0x0071
0069    Jump 0x0071
006b    Global x
006d    Num 9 (5)
006f    JumpNotEquals 0x0069
0071    Getline <illegal>
0073    Drop
0074    Num 3 (6)
0076    GetlineField <illegal>
0078    Drop
0079    GetlineSpecial <illegal> NR
007c    Drop
007d    Str "5" (13)
007f    GetlineArray <illegal> a
0083    Drop
0084    Nulls 1
0086    CallUser ops [a]
008b    Print 1

        // function ops
0000    Num 1 (0)
0002    AssignLocal loc
0004    IncrLocal 1 loc
0007    Str "2" (0)
0009    IncrArrayLocal 1 arr
000c    Num 2 (1)
000e    Str "3" (1)
0010    AugAssignArrayLocal AugOpMul arr
0013    GetlineLocal <illegal> loc
0016    Drop
0017    Str "2" (0)
0019    InLocal arr
001b    Return

"""

RICH_EXPECTED = """\
        // BEGIN
0000    Num 1 (0)
0002    AssignGlobal x
0004    Num 2 (1)
0006    AssignGlobal y
0008    Num 3 (2)
000a    AugAssignGlobal AugOpAdd x
000d    Num 2 (1)
000f    AugAssignGlobal AugOpPow y
0012    Str "one" (0)
0014    Str "1" (1)
0016    AssignArrayGlobal a
0018    Global x
001a    Str "1" (1)
001c    Str "2" (2)
001e    IndexMulti 2
0020    AssignArrayGlobal b
0022    Str "1" (1)
0024    InGlobal a
0026    Dupe
0027    JumpFalse 0x0030
0029    Drop
002a    Global x
002c    Global y
002e    Greater
002f    Not
0030    Boolean
0031    JumpFalse 0x003a
0033    Str "yes" (3)
0035    Print 1
0038    Jump 0x003f
003a    Str "no" (4)
003c    Print 1
003f    Global x
0041    Num 10 (3)
0043    JumpGreaterOrEqual 0x004e
0045    IncrGlobal 1 x
0048    Global x
004a    Num 10 (3)
004c    JumpLess 0x0045
004e    Num 0 (4)
0050    AssignGlobal i
0052    Global i
0054    Num 3 (2)
0056    JumpGreaterOrEqual 0x006b
0058    Global i
005a    Num 1 (0)
005c    JumpNotEquals 0x0060
005e    Jump 0x0062
0060    Jump 0x006b
0062    IncrGlobal 1 i
0065    Global i
0067    Num 3 (2)
0069    JumpLess 0x0058
006b    Str "1" (1)
006d    Delete a
0070    DeleteAll b
0073    Global x
0075    Global y
0077    FieldInt 1
0079    Special NF
007b    Field
007c    Nulls 2
007e    CallUser total [a]
0083    Global x
0085    Str "z" (5)
0087    Match
0088    JumpFalse 0x008e
008a    Str "m" (6)
008c    Jump 0x0090
008e    Str "n" (7)
0090    Global x
0092    Str "q" (8)
0094    NotMatch
0095    Print 7
0098    Str "out.txt" (9)
009a    Str "%d\\n" (10)
009c    Global x
009e    Printf 2 >
00a1    Str "in.txt" (11)
00a3    GetlineGlobal < line
00a6    Drop
00a7    Str "sort" (12)
00a9    Print 0 |
00ac    Num 0 (4)
00ae    ExitStatus

        // function total
0000    ForIn k arr 0x000d
0006    Local k
0008    ArrayLocal arr
000a    AugAssignLocal AugOpAdd t
000d    Local t
000f    Return

"""


def test_debug_asm_disassembles_begin_without_running(run_cli):
    """-da dumps the compiled BEGIN block and never executes it."""
    # CATCHES: the dump replaces the run entirely -- "3s" (what the print
    # would emit) never appears -- and shows the opcode stream with 4-hex
    # addresses, constant-pool indices in parentheses, and a trailing blank
    # line after the section.
    res = run_cli(["-da", 'BEGIN { x = 1 + 2; print x "s" }'])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == (
        "        // BEGIN\n"
        "0000    Num 1 (0)\n"
        "0002    Num 2 (1)\n"
        "0004    Add\n"
        "0005    AssignGlobal x\n"
        "0007    Global x\n"
        "0009    Str \"s\" (0)\n"
        "000b    Concat\n"
        "000c    Print 1\n"
        "\n"
    )


def test_debug_asm_program_without_sections_outputs_nothing(run_cli):
    """Programs the compiler emits no code for dump nothing under -da."""
    # CATCHES: Disassemble only writes a section when the compiler emitted
    # code for it -- an empty program, a comment-only program and even an
    # empty BEGIN block all dump nothing (exit status still 0) -- while an
    # empty action or END block DOES get a section holding a single Nop, so
    # the silence above is "no sections", not a CLI that never prints.
    for prog in ["", "   # just a comment\n", "BEGIN { }", "BEGIN { ; }"]:
        res = run_cli(["-da", prog])
        assert res.returncode == 0
        assert res.stderr == ""
        assert res.stdout == ""
    empty_action = run_cli(["-da", "{ }"])
    assert empty_action.returncode == 0
    assert empty_action.stdout == "        // { body }\n0000    Nop\n\n"
    empty_end = run_cli(["-da", "END { }"])
    assert empty_end.returncode == 0
    assert empty_end.stdout == "        // END\n0000    Nop\n\n"
    # An empty BEGIN block is dropped entirely, but its action survives.
    dropped = run_cli(["-da", "BEGIN { } { print }"])
    assert dropped.returncode == 0
    assert dropped.stdout == "        // { body }\n0000    Print 0\n\n"
    # An uncalled function still gets a (header-only) section.
    func = run_cli(["-da", "function f() { }"])
    assert func.returncode == 0
    assert func.stdout == "        // function f\n\n"


def test_debug_asm_sections_for_range_pattern_and_end(run_cli):
    """Range patterns and END each get their own disassembly section."""
    # CATCHES: the two halves of a range pattern disassemble as separate
    # "// start" and "// stop" sections, the action body as "// { body }",
    # and regex constants print with the (?s:...) wrapper GoAWK compiles in.
    res = run_cli(["-da", "/foo/, /bar/ { print $1 } END { print NR }"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == (
        "        // start\n"
        "0000    Regex \"(?s:foo)\" (0)\n"
        "\n"
        "        // stop\n"
        "0000    Regex \"(?s:bar)\" (1)\n"
        "\n"
        "        // { body }\n"
        "0000    FieldInt 1\n"
        "0002    Print 1\n"
        "\n"
        "        // END\n"
        "0000    Special NR\n"
        "0002    Print 1\n"
        "\n"
    )


def test_debug_asm_rich_constructs(run_cli, tmp_path):
    """A construct-heavy program dumps every major opcode kind exactly."""
    # CATCHES: augmented assignment names its operator (AugOpAdd/AugOpPow),
    # multi-subscript stores use IndexMulti, membership tests use InGlobal,
    # for-in shows its jump target, printf/print render their redirection
    # (">", "|"), getline names its target variable, and a user call with an
    # array parameter is annotated "[a]" -- plus a separate function section.
    (tmp_path / "rich.awk").write_text(RICH_PROGRAM)
    res = run_cli(["-da", "-f", "rich.awk"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == RICH_EXPECTED


def test_debug_asm_single_pattern_section(run_cli):
    """A single (non-range) pattern disassembles under a "// pattern" header."""
    # CATCHES: unlike a range pattern (which gets "// start" and "// stop"),
    # one pattern gets one "// pattern" section before the "// { body }"
    # section, and the bare next statement is the operand-less Next opcode.
    res = run_cli(["-da", "$1 > 0 { print $2; next }"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == (
        "        // pattern\n"
        "0000    FieldInt 1\n"
        "0002    Num 0 (0)\n"
        "0004    Greater\n"
        "\n"
        "        // { body }\n"
        "0000    FieldInt 2\n"
        "0002    Print 1\n"
        "0005    Next\n"
        "\n"
    )


def test_debug_asm_special_augmented_and_getline_forms(run_cli, tmp_path):
    """Augmented ops on specials/fields/arrays and every getline variant."""
    # CATCHES: the AugAssignSpecial operand renders with Go's %!d(string=NR)
    # formatting artifact (the reference passes a string to a %d verb), bare
    # getline variants print "<illegal>" for the absent redirection token,
    # float constants show as Num 1.5, @"name" is FieldByNameStr, and the
    # builtins length/split/sprintf disassemble to their dedicated opcodes.
    (tmp_path / "more.awk").write_text(MORE_PROGRAM)
    res = run_cli(["-da", "-f", "more.awk"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == MORE_EXPECTED


def test_debug_asm_special_field_and_redirectless_opcodes(run_cli, tmp_path):
    """Plain special/field writes, redirectless printf, plain array reads."""
    # CATCHES: FS=":" is AssignSpecial (contrast AugAssignSpecial), $2++ is
    # IncrField, printf without redirection shows no token after the count,
    # reading a global array element is ArrayGlobal, for-in over a global
    # names it in the ForIn line, and while/for with > and <= conditions
    # produce JumpLessOrEqual and JumpGreater exits.
    (tmp_path / "third.awk").write_text(THIRD_PROGRAM)
    res = run_cli(["-da", "-f", "third.awk"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == THIRD_EXPECTED
