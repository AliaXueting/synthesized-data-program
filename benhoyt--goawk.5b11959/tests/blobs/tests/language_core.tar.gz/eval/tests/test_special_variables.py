"""Special variable assignment semantics (setSpecial in interp.go).

Assigning FS/RS with an invalid multi-character regex errors; a single
character is a literal separator; NF truncates or extends fields and rebuilds
$0 with OFS; CONVFMT/OFMT/OFS/ORS/SUBSEP assignments take effect; ARGC
changes later input processing; NR/FNR/RSTART/RLENGTH/RT/FILENAME are
read-write; and negative field indices count from the last field.
"""

import pytest


@pytest.mark.parametrize(
    "fs, stdin, expected",
    [
        # single character is a literal separator, even a regex metachar
        ("|", "a:b|c", "a:b c  2\n"),
        ("[", "a:b|c", "a:b|c   1\n"),
        ("a", "1a", "1   2\n"),
        # multi-character value is used as a regex
        ("X+", "aXXbXc", "a b c 3\n"),
        (", *", "a, b,c", "a b c 3\n"),
    ],
)
def test_fs_assignment_separator_kinds(run_goawk, fs, stdin, expected):
    """FS single chars split literally; multi-char values split as regexes."""
    # CATCHES: a one-character FS is never compiled as a regex ("|" splits on
    # the literal bar, "[" does not error), while two+ characters are.
    res = run_goawk('BEGIN { FS = "%s" } { print $1, $2, $3, NF }' % fs,
                    stdin=stdin + "\n")
    assert res.returncode == 0
    assert res.stdout == expected


def test_fs_single_char_regex_metachar_is_literal(run_goawk):
    """FS="|" splits on the literal bar, not the regex alternation."""
    # CATCHES: compiling a single-char FS as a regex would split "a:b|c" on
    # an empty-string match into many fields instead of two.
    res = run_goawk('BEGIN { FS = "|" } { print NF, "[" $1 "]", "[" $2 "]" }',
                    stdin="a:b|c\n")
    assert res.returncode == 0
    assert res.stdout == "2 [a:b] [c]\n"


def test_special_variable_defaults_are_readable(run_goawk):
    """Every special variable reads back its documented default value."""
    # CATCHES: ARGC is 1 for a bare program (no file arguments), FS/OFS are a
    # single space, CONVFMT/OFMT are "%.6g", ORS/RS are newlines, SUBSEP is
    # the 0x1c separator byte, and INPUTMODE/OUTPUTMODE read as empty.  Note
    # "print ORS" and "print RS" each emit TWO newlines (value plus the ORS
    # terminator), so four separate between OFS's line and SUBSEP's \x1c.
    res = run_goawk(
        "BEGIN { print ARGC; print CONVFMT; print FS; print OFMT; print OFS;"
        " print ORS; print RS; print SUBSEP; print INPUTMODE; print OUTPUTMODE }"
    )
    assert res.returncode == 0
    assert res.stdout == "1\n%.6g\n \n%.6g\n \n\n\n\n\n\x1c\n\n\n"


def test_special_variables_read_back_after_assignment(run_goawk):
    """Assignments to the string-valued specials read back verbatim."""
    # CATCHES: CONVFMT/OFMT/OFS/RS/SUBSEP store the assigned string exactly
    # (no validation or normalization on the read-back path).
    res = run_goawk(
        'BEGIN { CONVFMT = "%.2f"; print CONVFMT; OFMT = "%.1f"; print OFMT;'
        ' OFS = ","; print OFS; RS = "x"; print RS; SUBSEP = ":"; print SUBSEP }'
    )
    assert res.returncode == 0
    assert res.stdout == "%.2f\n%.1f\n,\nx\n:\n"


@pytest.mark.parametrize(
    "fs, message",
    [
        ("x(", 'invalid regex "x(": error parsing regexp: missing closing ): `(?s:x()`'),
        ("[a-", 'invalid regex "[a-": error parsing regexp: invalid character class range: `a-)`'),
    ],
)
def test_fs_invalid_regex_is_runtime_error(run_goawk, fs, message):
    """Assigning a multi-character invalid regex to FS errors immediately."""
    # CATCHES: the message embeds the Go regexp error and the (?s:) wrapper
    # that GoAWK adds, and the error surfaces before any input is read.
    res = run_goawk('BEGIN { FS = "%s" }' % fs, stdin="x\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message + "\n"


def test_fs_change_takes_effect_from_next_record(run_goawk):
    """Assigning FS mid-record does not re-split the current record."""
    # CATCHES: the current record keeps its already-computed fields (so $2 is
    # empty under the default FS), but the next record splits with the new
    # FS, giving "e|f" for $2.
    res = run_goawk('FNR == 1 { FS = ":" } FNR == 2 { print $2 }',
                    stdin="a:b|c\nd:e|f\n")
    assert res.returncode == 0
    assert res.stdout == "e|f\n"

    res = run_goawk('{ FS = ":"; print $2 }', stdin="a:b|c\n")
    assert res.returncode == 0
    assert res.stdout == "\n"


def test_rs_assignment_splits_records(run_goawk):
    """Assigning RS re-separates records on the literal character."""
    # CATCHES: with RS="2" the input "1\\n2\\n3" yields two records ("1\\n"
    # and "\\n3") -- the separator itself is consumed.
    res = run_goawk('BEGIN { RS = "2" } { print NR, "[" $0 "]" }', stdin="1\n2\n3")
    assert res.returncode == 0
    assert res.stdout == "1 [1\n]\n2 [\n3]\n"


def test_rs_multibyte_character(run_goawk):
    """A multi-byte single-character RS splits on that character."""
    # CATCHES: multi-byte separators go through the regex path but must still
    # match the whole character, not a byte-level or empty split.
    res = run_goawk('BEGIN { RS = "§" } { print NR, $0 }',
                    stdin="a§b§c")
    assert res.returncode == 0
    assert res.stdout == "1 a\n2 b\n3 c\n"


def test_rs_empty_is_paragraph_mode(run_goawk):
    """RS="" separates records on blank lines, stripping padding."""
    # CATCHES: paragraph mode joins the "para one" and "line2" lines into a
    # single record and drops the blank separators entirely.
    res = run_goawk('BEGIN { RS = "" } { print NR, "[" $0 "]" }',
                    stdin="para one\nline2\n\npara two\n\n\npara three\n")
    assert res.returncode == 0
    assert res.stdout == "1 [para one\nline2]\n2 [para two]\n3 [para three]\n"


def test_rs_invalid_regex_is_runtime_error(run_goawk):
    """Assigning an invalid multi-character regex to RS errors immediately."""
    # CATCHES: the same invalid-regex error format as FS, raised by the
    # assignment itself before any record is read.
    res = run_goawk('BEGIN { RS = "x(" }', stdin="x\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid regex "x(": error parsing regexp: missing closing ): `(?s:x()`\n'


def test_rs_multichar_regex_separates_records(run_goawk):
    """A valid multi-character RS is compiled as a regex separator."""
    # CATCHES: RS="x+" splits "axxbxc" on runs of x (the whole match is
    # consumed), unlike the single-character path which matches one char.
    res = run_goawk('BEGIN { RS = "x+" } { print NR, "[" $0 "]" }', stdin="axxbxc")
    assert res.returncode == 0
    assert res.stdout == "1 [a]\n2 [b]\n3 [c]\n"


def test_rs_change_applies_from_next_file(run_goawk):
    """Changing RS mid-file does not re-separate the current input file."""
    # CATCHES: the scanner for the current input was already built with the
    # old RS, so record 2 is still newline-separated ("cXd").
    res = run_goawk('NR == 1 { RS = "X" } { print NR, "[" $0 "]" }',
                    stdin="aXb\ncXd\n")
    assert res.returncode == 0
    assert res.stdout == "1 [aXb]\n2 [cXd]\n"


def test_nf_assignment_truncates_extends_and_rebuilds(run_goawk):
    """NF = n drops or adds fields and rebuilds $0 joined with OFS."""
    # CATCHES: extending pads with empty fields ("a b c  "), truncating then
    # setting OFS only affects the next rebuild, and NF=2 rebuilds as "a-b".
    res = run_goawk(
        '{ NF = 3; print $0; NF = 5; print "[" $0 "]"; OFS = "-"; NF = 2; print $0 }',
        stdin="a b c d e\n",
    )
    assert res.returncode == 0
    assert res.stdout == "a b c\n[a b c  ]\na-b\n"


def test_nf_assignment_keeps_fractional_value(run_goawk):
    """NF = 1.9 keeps the fractional value but truncates the field count."""
    # CATCHES: the stored NF is the assigned value itself (prints as 1.9);
    # in BEGIN the field list is empty, so the rebuilt $0 stays "".
    res = run_goawk('BEGIN { NF = 1.9; print NF, "[" $0 "]" }', stdin="a b c\n")
    assert res.returncode == 0
    assert res.stdout == "1.9 []\n"


def test_nf_increment_and_augmented_assignment(run_goawk):
    """NF-- and NF += n work like ordinary augmented assignments."""
    # CATCHES: NF-- must rebuild $0 after dropping the last field (NF=2,
    # "a b"), and NF += 2 extends to 4 fields, re-padding with empties.
    res = run_goawk(
        '{ NF--; print NF, $0; NF += 2; print NF, "[" $0 "]" }',
        stdin="a b c\n",
    )
    assert res.returncode == 0
    assert res.stdout == "2 a b\n4 [a b  ]\n"


@pytest.mark.parametrize(
    "prog, expected",
    [
        ('BEGIN { OFS = "|"; print 1, 2, 3 }', "1|2|3\n"),
        ('BEGIN { ORS = ";"; print 1; print 2 }', "1;2;"),
    ],
)
def test_ofs_and_ors_assignments(run_goawk, prog, expected):
    """OFS separates print arguments; ORS terminates printed records."""
    # CATCHES: both take effect for every print after the assignment, and
    # ORS fully replaces the newline -- the output ends with ";" and no
    # trailing newline is appended at exit.
    res = run_goawk(prog)
    assert res.returncode == 0
    assert res.stdout == expected


def test_convfmt_applies_to_concat_ofmt_to_print(run_goawk):
    """CONVFMT governs string conversion; OFMT governs print of numbers."""
    # CATCHES: with CONVFMT="%.3f" the concatenation 1.5 "" is "1.500" while
    # print 1.5 still uses the default OFMT ("1.5"); integers (1) bypass
    # both formats and print exactly.
    res = run_goawk(
        'BEGIN { CONVFMT = "%.3f"; print 1.5 ""; print 1 ""; print 1.5 }'
    )
    assert res.returncode == 0
    assert res.stdout == "1.500\n1\n1.5\n"


def test_ofmt_assignment_formats_printed_numbers(run_goawk):
    """OFMT reformats non-integer numbers printed by print."""
    # CATCHES: 1/3 becomes "0.333" under OFMT="%.3f" while the integer 1
    # still prints exactly as "1" (integers never use OFMT).
    res = run_goawk('BEGIN { OFMT = "%.3f"; print 1.5; print 1/3; print 1 }')
    assert res.returncode == 0
    assert res.stdout == "1.500\n0.333\n1\n"


def test_convfmt_integer_conversions_use_sprintf(run_goawk):
    """A non-float CONVFMT like "%d" converts the number via sprintf."""
    # CATCHES: 3.7 truncates to "3" and 3000000000.5 to "3000000000" -- the
    # conversion is handed to sprintf, not to float formatting.
    res = run_goawk(
        'BEGIN { CONVFMT = "%d"; print 3.7 ""; print 3000000000.5 "" }'
    )
    assert res.returncode == 0
    assert res.stdout == "3\n3000000000\n"


def test_convfmt_percent_s_yields_empty_string(run_goawk):
    """A CONVFMT of "%s" converts numbers to the empty string."""
    # CATCHES: %s would recurse through CONVFMT, so (like gawk and mawk) the
    # reference produces "" instead of the number's text.
    res = run_goawk(
        'BEGIN { CONVFMT = "%s"; x = 3.7 ""; print "[" x "]" }'
    )
    assert res.returncode == 0
    assert res.stdout == "[]\n"


def test_ofmt_percent_s_falls_back_to_convfmt(run_goawk):
    """Unlike CONVFMT, an OFMT of "%s" converts using CONVFMT."""
    # CATCHES: print 3.7 under OFMT="%s" and CONVFMT="%.2f" gives "3.70" --
    # the %s guard only applies to CONVFMT itself.
    res = run_goawk('BEGIN { OFMT = "%s"; CONVFMT = "%.2f"; print 3.7, 3.7 "" }')
    assert res.returncode == 0
    assert res.stdout == "3.70 3.70\n"


@pytest.mark.parametrize(
    "fmt, value, expected",
    [
        ('%5.1f|', "2.25", "  2.2|"),  # width, one decimal, trailing text
        ("%.3f%%", "3.5", "3.500%"),  # literal %% survives the format
        ("%08.3f", "3.5", "0003.500"),  # zero padding to width 8
        ("%.0f", "2.5", "2"),  # Go rounds half to even
        ("%.0f", "3.5", "4"),
    ],
)
def test_number_format_conversions(run_goawk, fmt, value, expected):
    """CONVFMT/OFMT support full printf-style float specifications."""
    # CATCHES: the format string is handed to sprintf verbatim, including
    # width, zero padding and literal "%%", and %.0f rounds half to even.
    res = run_goawk(
        'BEGIN { CONVFMT = "%s"; print %s "" }' % (fmt, value)
    )
    assert res.returncode == 0
    assert res.stdout == expected + "\n"


def test_nr_assignment_persists_and_counts_on(run_goawk):
    """Assigning NR mid-stream changes the numbering from then on."""
    # CATCHES: after NR = 10 on record 2, the next record is 11 while FNR
    # keeps its own per-file count (3), showing NR and FNR are independent.
    res = run_goawk('NR == 2 { NR = 10 } { print NR, FNR }', stdin="a\nb\nc\n")
    assert res.returncode == 0
    assert res.stdout == "1 1\n10 2\n11 3\n"


def test_fnr_assignment_reset_by_next_record(run_goawk):
    """An FNR assigned in BEGIN is reset when the first record is read."""
    # CATCHES: reading the first record recomputes FNR from the file start
    # (1, 2, ...), discarding the value 5 set in BEGIN.
    res = run_goawk('BEGIN { FNR = 5 } { print FNR, NR }', stdin="x\ny\n")
    assert res.returncode == 0
    assert res.stdout == "1 1\n2 2\n"


def test_fnr_resets_per_file_nr_continues(run_goawk, write_input):
    """FNR counts within each file; NR counts across all files."""
    # CATCHES: for the second file FNR restarts at 1 while NR keeps going
    # (3, 4) -- the two counters must not be conflated.
    write_input("f1.txt", "l1\nl2\n")
    write_input("f2.txt", "l3\nl4\n")
    res = run_goawk('{ print NR, FNR, FILENAME }', args=["f1.txt", "f2.txt"])
    assert res.returncode == 0
    assert res.stdout == "1 1 f1.txt\n2 2 f1.txt\n3 1 f2.txt\n4 2 f2.txt\n"


def test_argc_assignment_limits_and_extends_file_list(run_goawk, write_input):
    """ARGC controls how many ARGV entries are processed as input files."""
    # CATCHES: ARGC=2 stops after the first file; growing ARGC to 4 makes the
    # interpreter pick up a file assigned to ARGV[3] inside BEGIN.
    write_input("fa.txt", "l1\nl2\n")
    write_input("fb.txt", "l3\n")

    res = run_goawk('BEGIN { ARGC = 2 } { print FILENAME, FNR, NR, $0 }',
                    args=["fa.txt", "fb.txt"])
    assert res.returncode == 0
    assert res.stdout == "fa.txt 1 1 l1\nfa.txt 2 2 l2\n"

    res = run_goawk(
        'BEGIN { ARGV[3] = "fb.txt"; ARGC = 4 } { print FILENAME, FNR, NR, $0 }',
        args=["fa.txt"],
    )
    assert res.returncode == 0
    assert res.stdout == "fa.txt 1 1 l1\nfa.txt 2 2 l2\nfb.txt 1 3 l3\n"


def test_rstart_rlength_are_read_write(run_goawk):
    """RSTART and RLENGTH default to 0 and can be assigned."""
    # CATCHES: before any match() call both read 0, and plain assignments
    # store arbitrary numbers that read back unchanged.
    res = run_goawk(
        "BEGIN { print RSTART, RLENGTH; RSTART = 5; RLENGTH = 7; print RSTART, RLENGTH }"
    )
    assert res.returncode == 0
    assert res.stdout == "0 0\n5 7\n"


def test_filename_is_empty_in_begin_and_dash_for_stdin(run_goawk):
    """FILENAME is "" before any file and "-" when reading standard input."""
    # CATCHES: a re-implementation that pre-sets FILENAME to the program name
    # or to "" while reading stdin would differ on one of the two lines.
    res = run_goawk('BEGIN { print "[" FILENAME "]" } { print FILENAME }', stdin="x\n")
    assert res.returncode == 0
    assert res.stdout == "[]\n-\n"


def test_rt_assignment_reads_back(run_goawk):
    """RT is assignable and reads back until the next record replaces it."""
    # CATCHES: assigning RT="zz" in BEGIN stores the value; per record RT
    # holds the actual record terminator, here the newline.
    res = run_goawk(
        'BEGIN { RT = "zz"; print "[" RT "]" }',
        stdin="x\n",
    )
    assert res.returncode == 0
    assert res.stdout == "[zz]\n"

    res = run_goawk('{ print "[" RT "]" }', stdin="a\nb\n")
    assert res.returncode == 0
    assert res.stdout == "[\n]\n[\n]\n"


def test_negative_field_indices_count_from_last(run_goawk):
    """$-n reads the n-th field from the end; past-the-start reads ""."""
    # CATCHES: $-1 is the last field ("c"), $-3 the first ("a"), $-5 one
    # before the start is "", and far-out $-100 is "" as well.
    res = run_goawk(
        '{ print $-1, $-3, $-5, "[" $-100 "]" }', stdin="a b c\n"
    )
    assert res.returncode == 0
    assert res.stdout == "c a  []\n"


def test_negative_field_index_assignment(run_goawk):
    """$-1 = v writes the last field; an out-of-range write is a no-op."""
    # CATCHES: $-1 = "Z" rewrites field 3 (rebuilding $0), while $-99 = "Q"
    # resolves before the first field and silently does nothing.
    res = run_goawk('{ $-1 = "Z"; print; $-99 = "Q"; print }', stdin="a b c\n")
    assert res.returncode == 0
    assert res.stdout == "a b Z\na b Z\n"


def test_field_zero_assignment_resplits_fields(run_goawk):
    """Assigning $0 re-splits the record into fresh fields."""
    # CATCHES: after $0 = "z y" the fields come from the new text (NF=2,
    # $1="z"), not from the original record's fields.
    res = run_goawk('{ $0 = "z y"; print $1, $2, NF }', stdin="a b c\n")
    assert res.returncode == 0
    assert res.stdout == "z y 2\n"


def test_field_index_too_large_via_augmented_assignment(run_goawk):
    """$1000001 += 1 reports the same field-index error as assignment."""
    # CATCHES: the augmented-assignment path on a field validates the index
    # too, failing with the exact "field index too large" message.
    res = run_goawk('BEGIN { $1000001 += 1 }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "field index too large: 1000001\n"


def test_nf_divide_by_zero_via_augmented_assignment(run_goawk):
    """NF /= 0 raises the plain division-by-zero runtime error."""
    # CATCHES: augmented assignment on a special variable goes through the
    # normal arithmetic error path with no position prefix.
    res = run_goawk('BEGIN { NF /= 0 }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "division by zero\n"


def test_inputmode_assignment_in_begin_changes_field_splitting(run_goawk):
    """INPUTMODE set in BEGIN retypes the main input before it is read."""
    # CATCHES: the CSV input mode (with its separator=... option) is a
    # writable special variable like FS, and setting it in BEGIN takes effect
    # for every record the main loop reads afterwards.
    res = run_goawk('BEGIN { INPUTMODE = "csv separator=;" } { print $1, $2 }',
                    stdin="a;b\nc;d\n")
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "a b\nc d\n"


def test_inputmode_and_outputmode_read_back_after_assignment(run_goawk):
    """INPUTMODE/OUTPUTMODE read back the canonical spelling of their mode."""
    # CATCHES: assigning "csv", "tsv" or "csv header" and reading the
    # variable back returns that same canonical text (an empty assignment
    # clears it to the default mode, which prints as the empty string), and
    # once OUTPUTMODE is itself CSV the value containing the separator is
    # printed CSV-quoted: "csv separator=|".
    res = run_goawk(
        'BEGIN { INPUTMODE = "csv"; print INPUTMODE; INPUTMODE = "tsv";'
        ' print INPUTMODE; INPUTMODE = "csv header"; print INPUTMODE;'
        ' INPUTMODE = ""; print "[" INPUTMODE "]";'
        ' OUTPUTMODE = "csv"; print OUTPUTMODE;'
        ' OUTPUTMODE = "csv separator=|"; print OUTPUTMODE }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == (
        "csv\ntsv\ncsv header\n[]\ncsv\n\"csv separator=|\"\n"
    )


@pytest.mark.parametrize(
    "prog, message",
    [
        ('BEGIN { INPUTMODE = "bogus"; print 1 }',
         'invalid input mode "bogus"'),
        ('BEGIN { INPUTMODE = "csv bogus"; print 1 }',
         'invalid input mode key "bogus"'),
        ('BEGIN { INPUTMODE = "csv separator=\\""; print 1 }',
         "invalid CSV field separator or comment delimiter"),
        ('BEGIN { INPUTMODE = "csv separator=xx"; print 1 }',
         'invalid CSV/TSV separator "xx"'),
        ('BEGIN { INPUTMODE = "tsv separator="; print 1 }',
         'invalid CSV/TSV separator ""'),
        ('BEGIN { INPUTMODE = "csv comment=##"; print 1 }',
         'invalid CSV/TSV comment character "##"'),
        ('BEGIN { INPUTMODE = "csv header=bogus"; print 1 }',
         'invalid header value "bogus"'),
        ('BEGIN { INPUTMODE = "tsv bogus=1"; print 1 }',
         'invalid input mode key "bogus"'),
        ('BEGIN { OUTPUTMODE = "bogus"; print 1 }',
         'invalid output mode "bogus"'),
        ('BEGIN { OUTPUTMODE = "csv separator=\\""; print 1 }',
         "invalid CSV field separator or comment delimiter"),
        ('BEGIN { OUTPUTMODE = "csv separator=xx"; print 1 }',
         'invalid CSV/TSV separator "xx"'),
        ('BEGIN { OUTPUTMODE = "csv bogus=1"; print 1 }',
         'invalid output mode key "bogus"'),
    ],
)
def test_inputmode_outputmode_invalid_values_are_runtime_errors(
        run_goawk, prog, message):
    """Bad INPUTMODE/OUTPUTMODE assignments abort with a bare message."""
    # CATCHES: these special variables validate on assignment (a bad mode
    # name, an unknown mode key or an unusable separator), the message goes
    # to stderr alone with exit status 1, and the rest of the program never
    # runs (no "1" is printed).
    res = run_goawk(prog)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message + "\n"


def test_outputmode_assignment_changes_print_formatting(run_goawk):
    """OUTPUTMODE = "csv ..." switches print to CSV field joining."""
    # CATCHES: with a custom CSV separator, print joins arguments with that
    # separator and only quotes a field when it needs it (one containing the
    # separator, or one containing a quote character, which is doubled).
    res = run_goawk(
        'BEGIN { OUTPUTMODE = "csv separator=|";'
        ' print 1, "a,b"; print "x\\"y"; print "plain" }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == '1|a,b\n"x""y"\nplain\n'


def test_outputmode_csv_record_rebuild(run_goawk):
    """In CSV output mode, $0 is rebuilt with CSV joining and quoting."""
    # CATCHES: assigning fields rebuilds $0 through the CSV writer, so the
    # two-field record x,y is stored (and printed) as the quoted string
    # "x,y", while the individual fields still print unquoted; truncating
    # with NF = 1 leaves a single field that needs no quoting.
    res = run_goawk(
        'BEGIN { OUTPUTMODE = "csv"; $1 = "x"; $2 = "y"; print $0;'
        ' print $1, $2; NF = 1; print $0 }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == '"x,y"\nx,y\nx\n'


def test_named_field_access_requires_header_mode(run_goawk):
    """@"name" without a header row is a fatal runtime error."""
    # CATCHES: the field-by-name lookup needs column names, which only exist
    # after a header row was read (via -H/-i ... header or INPUTMODE with
    # "header"); using it before that prints the exact guidance message to
    # stderr and exits 1.
    res = run_goawk('BEGIN { print @"x" }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        'no field names for @; use -H or add "header" to INPUTMODE,'
        ' and use "getline" first if in BEGIN\n'
    )
    # The dynamic @"name" form (computed field name) fails the same way.
    dynamic = run_goawk('BEGIN { n = "x"; print @n }')
    assert dynamic.returncode == 1
    assert dynamic.stdout == ""
    assert dynamic.stderr == res.stderr


def test_named_field_access_with_header_mode(run_goawk):
    """@"name" resolves columns by the header row, dynamically or literally."""
    # CATCHES: after INPUTMODE = "csv header" a getline in BEGIN consumes the
    # header row itself, literal @"name" and dynamic @n both resolve to that
    # column's value, and an unknown column name yields the empty string.
    res = run_goawk(
        'BEGIN { INPUTMODE = "csv header"; getline;'
        ' print @"name", @"age"; n = "age"; print @n;'
        ' print @"missing" "]" }',
        stdin="name,age\nbob,7\n",
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "bob 7\n7\n]\n"


def test_cli_mode_flags_are_visible_in_inputmode_outputmode(run_cli):
    """-i/-H/-o are just assignments to the INPUTMODE/OUTPUTMODE variables."""
    # CATCHES: the CLI flags and the variables share one code path, so
    # INPUTMODE reads back exactly "csv", "csv header" (with -H) or "tsv",
    # and because -o made output CSV the OUTPUTMODE value containing the "|"
    # separator is itself printed CSV-quoted.
    csv = run_cli(["-i", "csv", "BEGIN { print INPUTMODE }"])
    assert csv.returncode == 0
    assert csv.stdout == "csv\n"
    header = run_cli(["-H", "-i", "csv", "BEGIN { print INPUTMODE }"])
    assert header.returncode == 0
    assert header.stdout == "csv header\n"
    both = run_cli(["-i", "tsv", "-o", "csv",
                    "BEGIN { print INPUTMODE, OUTPUTMODE }"])
    assert both.returncode == 0
    assert both.stdout == "tsv,csv\n"
    quoted = run_cli(["-o", "csv separator=|", "BEGIN { print OUTPUTMODE }"])
    assert quoted.returncode == 0
    assert quoted.stdout == '"csv separator=|"\n'


def test_inputmode_outputmode_read_back_canonical_options(run_goawk):
    """Mode variables read back every option in canonical spelling."""
    # CATCHES: reading INPUTMODE regenerates the text from the parsed
    # configuration -- separator= and comment= appear only when they differ
    # from the mode's default ("," for csv, tab for tsv), "header" only when
    # the header flag is on ("header=false" reads back as plain "csv"), and
    # a tsv OUTPUTMODE with a non-default separator prints CSV-quoted
    # because it contains the output separator "|".
    res = run_goawk(
        'BEGIN { INPUTMODE = "csv separator=;"; print INPUTMODE;'
        ' INPUTMODE = "csv comment=#"; print INPUTMODE;'
        ' INPUTMODE = "csv separator=; comment=# header"; print INPUTMODE;'
        ' INPUTMODE = "csv header=false"; print INPUTMODE;'
        ' OUTPUTMODE = "tsv"; print OUTPUTMODE;'
        ' OUTPUTMODE = "tsv separator=|"; print OUTPUTMODE }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == (
        "csv separator=;\ncsv comment=#\n"
        "csv separator=; comment=# header\ncsv\ntsv\n\"tsv separator=|\"\n"
    )


def test_filename_assignment_reads_back(run_goawk):
    """FILENAME is writable in BEGIN but the input setup overwrites it."""
    # CATCHES: assigning FILENAME stores the given string (nothing is
    # opened) and it reads back inside BEGIN, but as soon as the main loop
    # starts reading a record the input setup resets FILENAME to the real
    # input name, "-" for standard input.
    res = run_goawk(
        'BEGIN { FILENAME = "chosen"; print FILENAME } { print FILENAME }',
        stdin="x\n",
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "chosen\n-\n"
