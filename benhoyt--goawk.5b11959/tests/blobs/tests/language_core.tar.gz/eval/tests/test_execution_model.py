"""Execution model: BEGIN/main/END ordering, pattern-action rules, exit status.

The interpreter runs BEGIN blocks once, then tests each input record against
the pattern-action rules in order, then runs END blocks.  Range patterns keep
per-rule state, ``exit`` interacts with END blocks in specific ways, and
runtime errors print only their message on stderr with exit status 1.
"""

import pytest


def test_begin_rules_end_order(run_goawk):
    """BEGIN runs once, every rule runs per record, END runs once at the end."""
    # CATCHES: a re-implementation that interleaves END before the last
    # record or runs BEGIN per record would produce a different line order.
    res = run_goawk('BEGIN { print "begin" } { print "rule" } END { print "end" }',
                    stdin="r1\nr2\n")
    assert res.returncode == 0
    assert res.stdout == "begin\nrule\nrule\nend\n"
    assert res.stderr == ""


def test_begin_only_program_never_reads_input(run_goawk):
    """A program with only a BEGIN block never processes any input records."""
    # CATCHES: reading input when no main rules exist would block on stdin or
    # print records; the reference stops right after BEGIN.
    res = run_goawk('BEGIN { print "B" }', stdin="1\n2\n3\n")
    assert res.returncode == 0
    assert res.stdout == "B\n"
    assert res.stderr == ""


def test_begin_only_with_explicit_getline_reads(run_goawk):
    """BEGIN can still pull input explicitly with getline when it wants to."""
    # CATCHES: getline inside BEGIN must read from the real input stream,
    # giving the first record, and the unread remainder is discarded.
    res = run_goawk('BEGIN { getline; print }', stdin="1\n2\n")
    assert res.returncode == 0
    assert res.stdout == "1\n"


def test_pattern_without_action_prints_record(run_goawk):
    """A rule with a pattern but no action is equivalent to { print $0 }."""
    # CATCHES: a re-implementation that treats a bare pattern as a no-op or
    # that prints the empty string would differ here.
    res = run_goawk("/a/", stdin="a\nb\na\n")
    assert res.returncode == 0
    assert res.stdout == "a\na\n"


def test_pattern_without_action_prints_rebuilt_record(run_goawk):
    """A later pattern-only rule prints $0 as rebuilt by an earlier rule."""
    # CATCHES: pattern-only rules print the current $0 buffer, so a field
    # assignment in an earlier rule for the same record must be visible.
    res = run_goawk('{ $1 = "X" } /X/', stdin="a b\n")
    assert res.returncode == 0
    assert res.stdout == "X b\n"


def test_empty_action_block_prints_nothing(run_goawk):
    """An explicitly empty action block { } is NOT the same as no action."""
    # CATCHES: GoAWK compiles a bare pattern to "print $0" but an explicit
    # empty block to a no-op, so mixing the two up prints the record; the
    # BEGIN marker proves the program itself ran and printed nothing else.
    res = run_goawk('BEGIN { print "begin" } { $1 = "X" } /X/ { }', stdin="a b\n")
    assert res.returncode == 0
    assert res.stdout == "begin\n"
    assert res.stderr == ""


def test_no_pattern_matches_every_record(run_goawk):
    """A rule with no pattern matches every record, including empty lines."""
    # CATCHES: an empty record must still match; only a false pattern value
    # skips the action.
    res = run_goawk("{ print NR }", stdin="a\n\nb\n")
    assert res.returncode == 0
    assert res.stdout == "1\n2\n3\n"


@pytest.mark.parametrize(
    "prog, expected",
    [
        # any non-empty string constant is true for every record
        ('"foo"', "foo\nbar\n1\n0\n"),
        ("1", "foo\nbar\n1\n0\n"),  # numeric 1 is true
        ('"0"', "foo\nbar\n1\n0\n"),  # the string "0" is non-empty, hence true
        ("$1", "foo\nbar\n1\n"),  # field value: $1=="0" is numerically false
    ],
)
def test_constant_and_expression_patterns(run_goawk, prog, expected):
    """Constant string/number patterns are truthiness tests, not matches."""
    # CATCHES: treating a bare string pattern as a regex match against $0, or
    # the string "0" as false, would change which records are printed.
    res = run_goawk(prog, stdin="foo\nbar\n1\n0\n")
    assert res.returncode == 0
    assert res.stdout == expected


def test_false_constant_pattern_skips_action_but_runs_begin_end(run_goawk):
    """A constant pattern of 0 never fires, yet BEGIN/END blocks still run."""
    # CATCHES: the records must still be read (END proves it) while the rule
    # body never executes; treating 0 as a match or skipping END breaks this.
    res = run_goawk('BEGIN { print "begin" } 0 { print "never" } END { print "end", NR }',
                    stdin="foo\nbar\n")
    assert res.returncode == 0
    assert res.stdout == "begin\nend 2\n"
    assert res.stderr == ""


def test_range_pattern_inclusive_endpoints(run_goawk):
    """A range pattern (p1,p2) matches the start record through the stop one."""
    # CATCHES: both endpoints must be included and the state must end after
    # the stop record; off-by-one on either endpoint changes the output.
    res = run_goawk("/b/,/c/", stdin="a\nb\nc\nd\n")
    assert res.returncode == 0
    assert res.stdout == "b\nc\n"


def test_range_pattern_restarts_after_end(run_goawk):
    """After a range ends, a record matching the start pattern restarts it."""
    # CATCHES: the range state must reset once the stop pattern matches, so a
    # later start record opens a new range (here never closed again).
    res = run_goawk("/x/,/y/", stdin="x\ny\nx\nz\nx\n")
    assert res.returncode == 0
    assert res.stdout == "x\ny\nx\nz\nx\n"


def test_range_pattern_same_record_endpoints(run_goawk):
    """A record matching both range endpoints is printed once, range closes."""
    # CATCHES: matching the stop pattern on the very record that opened the
    # range must not swallow that record nor keep the range open.
    res = run_goawk("/a/,/a/ { print NR }", stdin="a\nb\n")
    assert res.returncode == 0
    assert res.stdout == "1\n"


def test_range_pattern_state_is_per_rule(run_goawk):
    """Two range rules each keep their own independent range state."""
    # CATCHES: sharing one "in range" flag between rules would start rule B
    # when rule A starts instead of at its own start record.
    res = run_goawk('NR==2, NR==4 { print "A" NR } NR==3, NR==5 { print "B" NR }',
                    stdin="1\n2\n3\n4\n5\n6\n")
    assert res.returncode == 0
    assert res.stdout == "A2\nA3\nB3\nA4\nB4\nB5\n"


def test_multiple_rules_run_in_order_per_record(run_goawk):
    """Every matching rule runs for a record, in program order."""
    # CATCHES: stopping after the first matching rule (like switch/case)
    # would only print the first line of the expected output.
    res = run_goawk('{ print "first " NR } NR <= 2 { print "second " NR }',
                    stdin="a\nb\nc\n")
    assert res.returncode == 0
    assert res.stdout == "first 1\nsecond 1\nfirst 2\nsecond 2\nfirst 3\n"


def test_end_sees_final_nr_without_running_actions(run_goawk):
    """END blocks run after input is exhausted; NR keeps its final value."""
    # CATCHES: NR must be available in END with the count of records read,
    # and an END-only program still reads the input first.
    res = run_goawk("END { print NR }", stdin="a\nb\n")
    assert res.returncode == 0
    assert res.stdout == "2\n"


def test_end_runs_with_zero_records(run_goawk):
    """END runs even when there were no input records at all."""
    # CATCHES: treating an empty input as "skip END" would print nothing
    # instead of the recorded line with NR==0.
    res = run_goawk('{ print "no" } END { print "end", NR }', stdin="")
    assert res.returncode == 0
    assert res.stdout == "end 0\n"


@pytest.mark.parametrize(
    "prog, stdin, expected_status, expected_stdout",
    [
        ('{ print "m"; exit 7 }', "a\n", 7, "m\n"),  # exit in a main rule
        ('{ print "m"; exit }', "a\n", 0, "m\n"),  # bare exit defaults to 0
        # exit in BEGIN skips main, runs END
        ('BEGIN { print "b"; exit 3 } { print "m" } END { print "e" }', "a\nb\n", 3, "b\ne\n"),
        ('END { print "e"; exit 5 }', "a\n", 5, "e\n"),  # exit in END
        # END exit overrides earlier status
        ('{ print "m"; exit 1 } END { print "e"; exit 2 }', "a\n", 2, "m\ne\n"),
        # bare exit in END keeps prior status
        ('{ print "m"; exit 5 } END { print "e"; exit }', "a\n", 5, "m\ne\n"),
        # explicit exit 0 in END resets the status
        ('{ print "m"; exit 5 } END { print "e"; exit 0 }', "a\n", 0, "m\ne\n"),
    ],
)
def test_exit_status_handling(run_goawk, prog, stdin, expected_status, expected_stdout):
    """exit N sets the process status, END still runs, END exit wins."""
    # CATCHES: a bare `exit` inside END must keep the earlier status instead
    # of resetting it to 0, and exiting in BEGIN must still run END blocks
    # while skipping every main rule.
    res = run_goawk(prog, stdin=stdin)
    assert res.returncode == expected_status
    assert res.stdout == expected_stdout
    assert res.stderr == ""


def test_exit_in_begin_runs_end_but_not_main(run_goawk):
    """exit in BEGIN stops main rules from running but END still executes."""
    # CATCHES: a re-implementation that aborts the whole program on exit
    # would skip the END block entirely.
    res = run_goawk('BEGIN { exit 3 } { print "main" } END { print "end" }',
                    stdin="a\nb\n")
    assert res.returncode == 3
    assert res.stdout == "end\n"
    assert res.stderr == ""


def test_exit_in_end_stops_immediately(run_goawk):
    """exit inside an END block stops execution of the rest of that block."""
    # CATCHES: statements after `exit` inside END must not run, and the
    # status is the one given to that exit.
    res = run_goawk('END { exit 9; print "unreachable" }', stdin="a\n")
    assert res.returncode == 9
    assert res.stdout == ""


@pytest.mark.parametrize(
    "status_expr, expected",
    [
        ('"7"', 7),  # numeric string prefix is parsed
        ("2.9", 2),  # fractional status truncates toward zero
        ("300", 44),  # only the low 8 bits reach the OS
        ("-1", 255),  # negative wraps as unsigned byte
        ('"abc"', 0),  # non-numeric string coerces to 0
    ],
)
def test_exit_status_value_coercion(run_goawk, status_expr, expected):
    """The exit status expression is coerced like any other number."""
    # CATCHES: exit must run its argument through the normal string-to-number
    # coercion and then truncate to the OS status byte range; the END block's
    # output proves the program really ran when the status coerces to 0.
    res = run_goawk('END { print "e"; exit %s }' % status_expr, stdin="a\n")
    assert res.returncode == expected
    assert res.stdout == "e\n"
    assert res.stderr == ""


def test_runtime_error_message_and_status(run_goawk):
    """A runtime error prints just its message to stderr and exits 1."""
    # CATCHES: the message has no position prefix or "error:" decoration,
    # stdout produced before the error is still flushed, and the status is 1.
    res = run_goawk('BEGIN { print "hello"; print 1/0 }')
    assert res.returncode == 1
    assert res.stdout == "hello\n"
    assert res.stderr == "division by zero\n"


def test_output_before_runtime_error_is_flushed(run_goawk):
    """Printed output that precedes a runtime error still reaches stdout."""
    # CATCHES: the error path must flush buffered stdout, otherwise the
    # earlier print output is lost when the process exits with status 1.
    res = run_goawk('BEGIN { print "first"; x = 1%0 }')
    assert res.returncode == 1
    assert res.stdout == "first\n"
    assert res.stderr == "division by zero in mod\n"


@pytest.mark.parametrize(
    "prog, message",
    [
        ("BEGIN { print 1/0 }", "division by zero"),
        ("BEGIN { print 1%0 }", "division by zero in mod"),
        ("BEGIN { x = 5; x /= 0 }", "division by zero"),
        ("BEGIN { x = 5; x %= 0 }", "division by zero in mod"),
        ("BEGIN { $1 = 1; $1 /= 0 }", "division by zero"),
        ("BEGIN { NF = -1 }", "NF set to negative value: -1"),
        ("BEGIN { NF = 1000001 }", "NF set too large: 1000001"),
        ("BEGIN { $1000001 = \"x\" }", "field index too large: 1000001"),
        ("BEGIN { ARGC = 2000000 }", "ARGC set too large: 2000000"),
        ("BEGIN { NF = 1e20 }", "NF set to negative value: -9223372036854775808"),
    ],
)
def test_runtime_error_messages(run_goawk, prog, message):
    """Exact runtime error message text for arithmetic and special vars."""
    # CATCHES: each message must match byte-for-byte, including the huge
    # int64-overflow value produced by NF = 1e20.
    res = run_goawk(prog, stdin="a b\n")
    assert res.returncode == 1
    assert res.stderr == message + "\n"
    assert res.stdout == ""


@pytest.mark.parametrize(
    "prog, message",
    [
        ("(1/0), /b/ { print }", "division by zero"),
        ("/a/, (2%0) { print }", "division by zero in mod"),
        ("NR>0, (1/0) { print }", "division by zero"),
    ],
)
def test_runtime_error_in_range_pattern_halts(run_goawk, prog, message):
    """A runtime error in either half of a range pattern stops the program."""
    # CATCHES: both the start and the stop expression of a range pattern are
    # evaluated as patterns, so a failing one aborts with its bare message on
    # stderr and exit status 1 before any record's action can print.
    res = run_goawk(prog, stdin="a\nb\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message + "\n"
