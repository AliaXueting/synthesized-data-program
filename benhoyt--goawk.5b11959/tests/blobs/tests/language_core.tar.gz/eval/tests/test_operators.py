"""Operators: arithmetic, comparison, boolean, ternary, regex, in, incr/decr.

All AWK operators as the VM evaluates them: precedence and associativity,
short-circuit evaluation of && and ||, regex matching with ~ and !~ (with
dynamic regexes and leftmost-longest semantics), the `in` operator, pre/post
increment/decrement on every lvalue kind, and augmented assignments.
"""

import pytest


def test_arithmetic_operators(run_goawk):
    """The six arithmetic operators on integers and floats."""
    # CATCHES: division and subtraction results are float64 and print via
    # %.6g, so e.g. 7/2 prints "3.5" while 2*3 prints "6".
    res = run_goawk("BEGIN { print 1 + 2, 5 - 8, 2 * 3, 7 / 2, -7 / 2, 2 ^ 10 }")
    assert res.returncode == 0
    assert res.stdout == "3 -3 6 3.5 -3.5 1024\n"


def test_left_associative_subtraction(run_goawk):
    """Binary - and / associate left, so 10-3-2 is (10-3)-2."""
    # CATCHES: right-associative evaluation would give 10-(3-2)=9 instead
    # of the recorded 5.
    res = run_goawk("BEGIN { print 10 - 3 - 2; print 100 / 5 / 2 }")
    assert res.returncode == 0
    assert res.stdout == "5\n10\n"


def test_modulo_sign_follows_dividend(run_goawk):
    """% uses Go's math.Mod, so the result takes the sign of the dividend."""
    # CATCHES: a C-style truncated division would give -7%3 == -1 here too,
    # but 7%-3 would be -1 instead of the recorded +1.
    res = run_goawk("BEGIN { print 7 % 3, -7 % 3, 7 % -3, -7 % -3 }")
    assert res.returncode == 0
    assert res.stdout == "1 -1 1 -1\n"


def test_power_is_right_associative(run_goawk):
    """^ associates right, so 2^3^2 is 2^(3^2) = 512."""
    # CATCHES: left-associative evaluation would compute (2^3)^2 = 64 and
    # (2^2)^3 = 64 instead of the recorded 512 and 256.
    res = run_goawk("BEGIN { print 2 ^ 3 ^ 2; print 2 ^ 2 ^ 3 }")
    assert res.returncode == 0
    assert res.stdout == "512\n256\n"


def test_unary_minus_binds_looser_than_power(run_goawk):
    """-2^2 is -(2^2); unary minus does not bind tighter than ^."""
    # CATCHES: evaluating (-2)^2 gives 4; the reference prints -4 because ^
    # has higher precedence than the unary minus.
    res = run_goawk("BEGIN { print -2 ^ 2; print (-2) ^ 2 }")
    assert res.returncode == 0
    assert res.stdout == "-4\n4\n"


def test_unary_operators_coerce_to_number(run_goawk):
    """Unary + and - coerce strings through prefix parsing; ! yields 0 or 1."""
    # CATCHES: unary plus is a real operator that converts "3x" to 3, not a
    # no-op, and ! uses string truthiness so !"x" is 0 but !"" is 1.
    res = run_goawk(
        'BEGIN { x = "3x"; print +x, -x; print +"abc", -"abc", +""; print !0, !5, !"x", !"" }'
    )
    assert res.returncode == 0
    assert res.stdout == "3 -3\n0 0 0\n1 0 0 1\n"


def test_concat_binds_looser_than_arithmetic(run_goawk):
    """Concatenation has lower precedence than arithmetic operators."""
    # CATCHES: 2 "3" * 2 is "2" concatenated with 6 ("26"), not "23"*2=46;
    # 1+2 "a" concatenates after adding.
    res = run_goawk('BEGIN { print 2 "3" * 2; print 1 + 2 "a"; print "a" 1 + 2 }')
    assert res.returncode == 0
    assert res.stdout == "26\n3a\na3\n"


def test_concat_flattens_multiple_terms(run_goawk):
    """A run of concatenations joins all operands left to right."""
    # CATCHES: 1+2 "a" 3 4 builds "3a34"; an implementation that only
    # concatenates pairwise after arithmetic could order it differently.
    res = run_goawk('BEGIN { print 1 + 2 "a" 3 4 }')
    assert res.returncode == 0
    assert res.stdout == "3a34\n"


@pytest.mark.parametrize(
    "expr, expected",
    [
        ('"a" < "b"', "1"),
        ('"b" > "a"', "1"),
        ('"a" <= "a"', "1"),
        ('"b" >= "b"', "1"),
        ('"a" == "a"', "1"),
        ('"a" != "a"', "0"),
        ("2 < 3", "1"),
        ("3 <= 3", "1"),
        ("5 > 4", "1"),
        ("4 >= 5", "0"),
        ("2 == 3", "0"),
        ("2 != 3", "1"),
    ],
)
def test_comparison_operators(run_goawk, expr, expected):
    """All six comparison operators over strings and numbers."""
    # CATCHES: both operands here are pure strings or pure numbers, so the
    # comparison type is unambiguous and each operator's result is pinned.
    res = run_goawk("BEGIN { print (%s) }" % expr)
    assert res.returncode == 0
    assert res.stdout == expected + "\n"


def test_boolean_operators_return_zero_or_one(run_goawk):
    """&& and || produce the numbers 1 or 0, never an operand value."""
    # CATCHES: some languages return the deciding operand (5 && 3 -> 3); AWK
    # semantics here yield a normalized boolean.
    res = run_goawk('BEGIN { print 5 && 3; print 5 || 7; print "a" && "b"; print "" || 0 }')
    assert res.returncode == 0
    assert res.stdout == "1\n1\n1\n0\n"


def test_short_circuit_skips_right_operand(run_goawk):
    """&& and || do not evaluate the right operand when unnecessary."""
    # CATCHES: the function must not be called when the left operand already
    # decides the result, including the 1/0 in an unselected ternary branch.
    res = run_goawk(
        "function f(x) { print \"f called \" x; return x }\n"
        "BEGIN { print (0 && f(1)); print (1 || f(2)); print (f(0) && f(3));"
        " print (f(1) || f(4)); print (1 ? 10 : 1/0); print (0 ? 1/0 : 20) }"
    )
    assert res.returncode == 0
    assert res.stdout == "0\n1\nf called 0\n0\nf called 1\n1\n10\n20\n"


def test_ternary_is_right_associative(run_goawk):
    """Nested conditionals group right: 1?2:3?4:5 is 1?2:(3?4:5)."""
    # CATCHES: left-associative grouping (1?2:3)?4:5 would also give 4-like
    # results in some cases; the nested middle-conditional case pins it.
    res = run_goawk('BEGIN { print 1 ? 2 : 3 ? 4 : 5; print 1 ? 0 ? "a" : "b" : "c"; print 0 ? "x" : 0 ? "y" : "z" }')
    assert res.returncode == 0
    assert res.stdout == "2\nb\nz\n"


def test_regex_match_operators(run_goawk):
    """~ and !~ test regex matching; matching is case-sensitive."""
    # CATCHES: the regex is compiled with Go semantics but no case folding,
    # so "ABC" ~ "abc" is 0 and !~ is its exact negation.
    res = run_goawk('BEGIN { print ("abc" ~ "b"), ("abc" !~ "b"), ("ABC" ~ "abc"), ("abc" ~ "B") }')
    assert res.returncode == 0
    assert res.stdout == "1 0 0 0\n"


def test_regex_match_dynamic_regex(run_goawk):
    """The right side of ~ can be any string expression, compiled at runtime."""
    # CATCHES: a dynamic regex is compiled on the fly and cached by text, so
    # a variable holding "b+" behaves exactly like the literal /b+/.
    res = run_goawk('BEGIN { r = "b+"; print ("abbb" ~ r), ("abbb" !~ r) }')
    assert res.returncode == 0
    assert res.stdout == "1 0\n"


def test_regex_match_invalid_regex_error(run_goawk):
    """An invalid dynamic regex is a runtime error with a wrapped message."""
    # CATCHES: the Go error mentions the "(?s:" wrapper, so the recorded
    # message ends with `[)` rather than `[` -- a faithful re-implementation
    # detail of how GoAWK reports the underlying regexp failure.
    res = run_goawk('BEGIN { print ("abc" ~ "[") }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid regex "[": error parsing regexp: missing closing ]: `[)`\n'


def test_standalone_regex_matches_record(run_goawk):
    """A bare /regex/ expression is equivalent to $0 ~ /regex/."""
    # CATCHES: in BEGIN the record is the empty string so the match fails;
    # per record it tests the current $0.
    res = run_goawk("BEGIN { if (/x/) print \"y\"; else print \"n\" }", stdin="x\n")
    assert res.returncode == 0
    assert res.stdout == "n\n"

    res = run_goawk("{ print /ell/ }", stdin="hello\nworld\n")
    assert res.returncode == 0
    assert res.stdout == "1\n0\n"


def test_in_operator_scalar_subscript(run_goawk):
    """(i in a) tests element existence; subscripts are strings."""
    # CATCHES: the number 1 and the string "1" are the same subscript, and
    # `in` must not create the element it tests.
    res = run_goawk('BEGIN { a[1] = "x"; a["k"] = "y"; print (1 in a), ("1" in a), ("k" in a), (2 in a); print length(a) }')
    assert res.returncode == 0
    assert res.stdout == "1 1 1 0\n2\n"


def test_in_operator_multi_subscript(run_goawk):
    """((i,j) in a) joins subscripts with SUBSEP before the lookup."""
    # CATCHES: the multi-dim key is "1\x1c2"; a plain "1" lookup must fail,
    # while an explicit SUBSEP join of the same parts must succeed.
    res = run_goawk(
        'BEGIN { b[1,2] = "m"; print ((1,2) in b), ("1" in b),'
        ' (("1" SUBSEP "2") in b) }'
    )
    assert res.returncode == 0
    assert res.stdout == "1 0 1\n"


def test_increment_decrement_on_scalar(run_goawk):
    """Pre/post ++ and -- on a scalar, with the value visible between ops."""
    # CATCHES: post-increment yields the old value and pre yields the new
    # one, and the operations sequence 5,6,7,7,5 pins the evaluation order
    # of a comma-separated print list.
    res = run_goawk("BEGIN { x = 5; print x++, x, ++x, x--, --x }")
    assert res.returncode == 0
    assert res.stdout == "5 6 7 7 5\n"


def test_increment_coerces_string_to_number(run_goawk):
    """++ on a string value parses its numeric prefix first."""
    # CATCHES: "9"++ becomes 10 (not the string "91"), "abc"++ becomes 1
    # after coercing to 0, and "3.5"++ becomes 4.5.
    res = run_goawk('BEGIN { y = "9"; print y++; z = "abc"; print z++, z; s = "3.5"; s++; print s }')
    assert res.returncode == 0
    assert res.stdout == "9\n0 1\n4.5\n"


def test_postincrement_field_yields_number(run_goawk):
    """The value of $n++ is the numeric coercion of the old field text."""
    # CATCHES: $1++ pushes UnaryPlus(old $1) so "7x" yields 7, and the
    # assignment rebuilds $0 with the new numeric field ("8 2.5").
    res = run_goawk('{ print $1++; print $0; print $2--; print $0 }',
                    stdin="7x 2.5\n")
    assert res.returncode == 0
    assert res.stdout == "7\n8 2.5\n2.5\n8 1.5\n"


def test_field_increment_as_statement(run_goawk):
    """$n++ / $n-- as standalone statements mutate the field in place."""
    # CATCHES: the statement form has no expression value -- it goes straight
    # through the field-increment path -- and a non-numeric field coerces
    # through 0 ("abc" becomes 1, "def" becomes 1), rebuilding $0 each time.
    res = run_goawk('{ $1++; print; $1--; print }', stdin="5 7\n")
    assert res.returncode == 0
    assert res.stdout == "6 7\n5 7\n"

    res = run_goawk('{ $1++; print; $2++; print }', stdin="abc def\n")
    assert res.returncode == 0
    assert res.stdout == "1 def\n1 1\n"


def test_field_increment_index_too_large(run_goawk):
    """$n++ validates the field index before touching the record."""
    # CATCHES: the statement-form increment reports the same "field index
    # too large" error as plain assignment, with no source position.
    res = run_goawk('BEGIN { $1000001++ }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "field index too large: 1000001\n"


def test_not_match_invalid_regex_error(run_goawk):
    """An invalid dynamic regex on the right of !~ is a runtime error."""
    # CATCHES: !~ compiles its right operand just like ~, so "(" fails with
    # the same wrapped Go regexp message instead of being treated as a
    # literal string comparison.
    res = run_goawk('BEGIN { print ("abc" !~ "(") }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'invalid regex "(": error parsing regexp: missing closing ): `(?s:()`\n'


def test_increment_on_array_element(run_goawk):
    """++/-- work on array elements and keep the element's numeric state."""
    # CATCHES: a[1]++ yields the old value then stores the new one, and the
    # subscript is evaluated exactly once.
    res = run_goawk("BEGIN { a[1] = 10; print a[1]++, a[1], ++a[1] }")
    assert res.returncode == 0
    assert res.stdout == "10 11 12\n"


def test_dollar_postincrement_parses_as_field_of_index(run_goawk):
    """$n++ means $(n++) -- incrementing the index, not the field."""
    # CATCHES: with n unset, $(n++) reads $0 and the whole postfix
    # expression's value is the numeric coercion of $0 (0 for text), while
    # ($n)++ is rejected as a non-lvalue.
    res = run_goawk("{ print $n++ }", stdin="a b c\n")
    assert res.returncode == 0
    assert res.stdout == "0\n"

    res = run_goawk("{ print ($n)++ }", stdin="a b c\n")
    assert res.returncode == 1
    assert "expected lvalue after ++" in res.stderr


@pytest.mark.parametrize(
    "op, expected",
    [
        ("+=", "15"),
        ("-=", "5"),
        ("*=", "50"),
        ("/=", "2"),
        ("%=", "0"),
        ("^=", "100000"),
    ],
)
def test_augmented_assignment_operators(run_goawk, op, expected):
    """Every augmented assignment operator on a scalar, from x=10 and rhs=5."""
    # CATCHES: /= and %= must produce the same float formatting as the plain
    # operators (10/5 prints "2"), and %= on 10%5 is exactly 0.
    res = run_goawk("BEGIN { x = 10; x %s 5; print x }" % op)
    assert res.returncode == 0
    assert res.stdout == expected + "\n"


def test_augmented_assignment_on_string_value(run_goawk):
    """Augmented assignment coerces a string variable through its prefix."""
    # CATCHES: x = "10" then x += 5 gives the number 15, exactly like the
    # ++ operator's coercion rules.
    res = run_goawk('BEGIN { x = "10"; x += 5; print x }')
    assert res.returncode == 0
    assert res.stdout == "15\n"


def test_augmented_assignment_on_field_and_array(run_goawk):
    """Augmented assignment works on fields and array elements alike."""
    # CATCHES: assigning $1 += 2 must rebuild $0 from the fields, and the
    # array element update must reuse the subscript evaluated once.
    res = run_goawk('{ $1 += 2; print $0; a[1] = 4; a[1] *= 3; print a[1] }',
                    stdin="5 6\n")
    assert res.returncode == 0
    assert res.stdout == "7 6\n12\n"


def test_augmented_assignment_subscript_evaluated_once(run_goawk):
    """The array subscript of a[n++] += 10 is evaluated exactly once."""
    # CATCHES: evaluating the subscript twice would advance n to 3 and leave
    # a[1] untouched; the reference increments n once and updates a[1].
    res = run_goawk("BEGIN { n = 1; a[1] = 5; a[n++] += 10; print n, a[1] }")
    assert res.returncode == 0
    assert res.stdout == "2 15\n"


def test_assignment_expression_yields_value(run_goawk):
    """An assignment is an expression whose value is the assigned value."""
    # CATCHES: (x = 5) + 1 is 6 and x ends up 5; chained a=b=c assigns
    # right to left.
    res = run_goawk("BEGIN { print (x = 5) + 1, x; a = b = c = 7; print a, b, c }")
    assert res.returncode == 0
    assert res.stdout == "6 5\n7 7 7\n"


def test_assignment_to_field_expression(run_goawk):
    """$(x = 2) = "set" assigns through a computed field index."""
    # CATCHES: the index expression's side effect (x=2) must happen and the
    # field write must rebuild $0 with OFS, here leaving field 1 empty.
    res = run_goawk('BEGIN { $(x = 2) = "set"; print x, $2, "[" $0 "]" }')
    assert res.returncode == 0
    assert res.stdout == "2 set [ set]\n"


def test_augmented_assignment_used_as_expression_value(run_goawk):
    """(x += 5) evaluates to the new value, evaluated left to right."""
    # CATCHES: an augmented assignment in expression position yields the
    # updated value (the reference compiles this through its Swap opcode),
    # the string "a" coerces to 0 before adding, and several of them in one
    # print list apply in sequence (15%3=0, 0^3=0, 0-100=-100).
    res = run_goawk(
        'BEGIN { x = 10; y = (x += 5); print x, y;'
        ' s = "a"; t = (s += 1); print s, t;'
        ' print (x %= 3), (x ^= 3), (x -= 100) }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "15 15\n1 1\n0 0 -100\n"


@pytest.mark.parametrize(
    "prog, message",
    [
        ("function f(x) { print \"before\"; x /= 0; print \"after\" }"
         " BEGIN { f(3) }", "division by zero"),
        ("function f(x) { x %= 0 } BEGIN { f(3) }",
         "division by zero in mod"),
        ('BEGIN { a[1] = 5; a[1] /= 0 }', "division by zero"),
        ("function f(a) { a[1] = 5; a[1] %= 0 } BEGIN { f(b) }",
         "division by zero in mod"),
    ],
)
def test_augmented_assignment_errors_on_locals_and_arrays(
        run_goawk, prog, message):
    """Augmented assignment errors on locals and array elements alike."""
    # CATCHES: the /= and %= checks run for every assignment target kind --
    # function locals, global array elements and array parameters -- not just
    # plain globals, each aborting with the bare message on stderr, and the
    # statements after the failing one never execute.
    res = run_goawk(prog)
    assert res.returncode == 1
    assert res.stderr == message + "\n"
    if "before" in prog:
        assert res.stdout == "before\n"
    else:
        assert res.stdout == ""


@pytest.mark.parametrize(
    "prog, message",
    [
        ("BEGIN { NF = 2; NF -= 5 }", "NF set to negative value: -3"),
        ("BEGIN { NF-- }", "NF set to negative value: -1"),
        ("BEGIN { ARGC += 2000000 }", "ARGC set too large: 2000001"),
    ],
)
def test_increment_and_augassign_on_specials_can_error(
        run_goawk, prog, message):
    """NF--/NF -= 5/ARGC += ... validate through setSpecial and fail."""
    # CATCHES: the increment and augmented-assignment opcodes on special
    # variables store through setSpecial, so they hit the same validation as
    # plain assignment (negative or too-large NF, too-large ARGC) and abort
    # with the identical message; the successful NF++/NF += 2 form works.
    res = run_goawk(prog)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message + "\n"
    ok = run_goawk('BEGIN { NF = 1; NF++; print NF; NF += 2; print NF }')
    assert ok.returncode == 0
    assert ok.stdout == "2\n4\n"
