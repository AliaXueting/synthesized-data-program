"""Arrays: string subscripts, delete, for-in, SUBSEP, pass-by-reference.

Array semantics of the core language: subscripts are always stringified,
``delete`` removes single elements or the whole array, reading an element
springs it into existence while ``in`` does not, multi-dimensional keys are
joined with SUBSEP, and arrays are passed by reference into functions.
"""

import pytest


def test_for_in_visits_every_key_exactly_once(run_goawk):
    """for (k in a) iterates all keys, each exactly once."""
    # CATCHES: skipping or repeating a key changes the count; iteration order
    # is unspecified, so the test counts visits rather than ordering them.
    res = run_goawk(
        'BEGIN { a[1] = "x"; a[2] = "y"; a[3] = "z"; n = 0;'
        ' for (k in a) n++; print n }'
    )
    assert res.returncode == 0
    assert res.stdout == "3\n"


def test_for_in_yields_the_key_strings(run_goawk):
    """The loop variable receives the key string of each element."""
    # CATCHES: keys are strings ("k1"/"k2"), not indices or values; the
    # collected lines are sorted before comparing because for-in order is
    # map order and must not be relied on.
    res = run_goawk(
        'BEGIN { a["k1"] = 1; a["k2"] = 2; for (k in a) print k }'
    )
    assert res.returncode == 0
    assert sorted(res.stdout.splitlines()) == ["k1", "k2"]


def test_for_in_over_empty_or_undeclared_array(run_goawk):
    """for-in over an empty or never-declared array runs zero iterations."""
    # CATCHES: iterating an undeclared array must be a silent no-op, not an
    # error, and must not create the array.
    res = run_goawk(
        'BEGIN { for (i in b) print "never"; print "done", length(b) }'
    )
    assert res.returncode == 0
    assert res.stdout == "done 0\n"


def test_delete_single_element(run_goawk):
    """delete a[i] removes exactly that element."""
    # CATCHES: after deleting one key, `in` reports it gone while the other
    # element survives and the array length drops to one.
    res = run_goawk(
        'BEGIN { a[1] = "x"; a[2] = "y"; delete a[1];'
        ' print (1 in a), (2 in a), length(a) }'
    )
    assert res.returncode == 0
    assert res.stdout == "0 1 1\n"


def test_delete_whole_array(run_goawk):
    """delete a (no subscript) clears every element of the array."""
    # CATCHES: only the contents are cleared; the array itself remains usable
    # and every `in` test now fails.
    res = run_goawk(
        'BEGIN { a[1] = "x"; a[2] = "y"; a[3] = "z"; delete a;'
        ' print length(a), (1 in a) }'
    )
    assert res.returncode == 0
    assert res.stdout == "0 0\n"


def test_delete_missing_element_is_noop(run_goawk):
    """Deleting a key that does not exist leaves the array unchanged."""
    # CATCHES: delete of a missing key must not error and must not create the
    # key either.
    res = run_goawk(
        'BEGIN { a[1] = "x"; delete a[99]; print length(a), (99 in a) }'
    )
    assert res.returncode == 0
    assert res.stdout == "1 0\n"


def test_delete_multi_dimensional_element(run_goawk):
    """delete a[i,j] removes the SUBSEP-joined key."""
    # CATCHES: the multi-dim subscript must be rebuilt the same way for the
    # delete and the later `in` test, so the element disappears cleanly.
    res = run_goawk(
        'BEGIN { m[1,2] = "x"; delete m[1,2]; print ((1,2) in m), length(m) }'
    )
    assert res.returncode == 0
    assert res.stdout == "0 0\n"


def test_reading_element_creates_it_but_in_does_not(run_goawk):
    """A plain read of a[i] springs the element into existence; `in` doesn't."""
    # CATCHES: after `x = a[1]` the array has grown to length 1 even though
    # nothing was assigned, while the earlier `in` test left it empty.
    res = run_goawk(
        'BEGIN { print (1 in a), length(a); x = a[1];'
        ' print (1 in a), length(a), "[" x "]" }'
    )
    assert res.returncode == 0
    assert res.stdout == "0 0\n1 1 []\n"


def test_subscripts_are_stringified(run_goawk):
    """Subscripts convert to strings: 1.0 -> "1", 1.5 -> "1.5", -0 -> "0"."""
    # CATCHES: using the number itself as the key text ("1.0") or keeping a
    # signed zero ("-0") would make the later string lookups fail.
    res = run_goawk(
        'BEGIN { a[1.0] = "one"; print ("1" in a);'
        ' a[1.5] = "f"; print (1.5 in a), ("1.5" in a);'
        ' b[-0] = 1; print ("0" in b), ("-0" in b) }'
    )
    assert res.returncode == 0
    assert res.stdout == "1\n1 1\n1 0\n"


def test_subsep_change_affects_new_keys_only(run_goawk):
    """Changing SUBSEP only affects keys created afterwards."""
    # CATCHES: the existing key was built with the default SUBSEP (\\x1c), so
    # after SUBSEP="," the (1,2) lookup misses while a fresh (3,4) key hits.
    res = run_goawk(
        'BEGIN { m[1,2] = "x"; SUBSEP = ","; print ((1,2) in m);'
        ' m[3,4] = "y"; print ((3,4) in m), (("3,4") in m) }'
    )
    assert res.returncode == 0
    assert res.stdout == "0\n1 1\n"


def test_array_scalar_name_collision_is_parse_error(run_goawk):
    """A name cannot be used as both a scalar and an array."""
    # CATCHES: the resolver rejects the second, conflicting use at parse time
    # with a source position, naming the variable in the message.
    res = run_goawk('BEGIN { x = 1; x[1] = 2 }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert 'can\'t use scalar "x" as array' in res.stderr

    res = run_goawk('BEGIN { a[1] = 1; a = 2 }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert 'can\'t use array "a" as scalar' in res.stderr


def test_arrays_pass_by_reference_into_functions(run_goawk):
    """Array parameters alias the caller's array, not a copy."""
    # CATCHES: if arrays were copied on call, the "new" key would not appear
    # in the caller's array b and its length would stay 1.
    res = run_goawk(
        'function f(a) { a["new"] = 5 }'
        'BEGIN { b["old"] = 1; f(b); print ("new" in b), b["new"], length(b) }'
    )
    assert res.returncode == 0
    assert res.stdout == "1 5 2\n"


def test_delete_inside_function_affects_caller_array(run_goawk):
    """delete through an array parameter removes the caller's element."""
    # CATCHES: the function deletes b's "k" element via the parameter alias,
    # leaving exactly the "j" element, which for-in then reports.
    res = run_goawk(
        'function f(a) { delete a["k"]; for (k in a) print "f", k }'
        'BEGIN { b["k"] = 1; b["j"] = 2; f(b); print length(b) }'
    )
    assert res.returncode == 0
    assert res.stdout == "f j\n1\n"


def test_local_array_in_function(run_goawk):
    """Extra parameters give functions local arrays, isolated from globals."""
    # CATCHES: the local array `a` (declared as an extra parameter) starts
    # empty, supports ++ and +=, and vanishes after return; the global g is
    # untouched.
    res = run_goawk(
        "function f(x,   a) { a[1] = \"loc\"; a[2] = 4; a[2]++; a[1] += 10;"
        ' return a[1] a[2] }\n'
        'BEGIN { print f(0); print ("1" in g), length(g) }'
    )
    assert res.returncode == 0
    assert res.stdout == "105\n0 0\n"


def test_break_and_continue_inside_for_in(run_goawk):
    """break and continue work inside a for-in loop."""
    # CATCHES: break must leave just the for-in (not the program), and
    # continue must skip to the next key without recounting the current one.
    res = run_goawk(
        'BEGIN { a["x"] = 1; for (k in a) { print "first", k; break };'
        ' print "after" }'
    )
    assert res.returncode == 0
    assert res.stdout == "first x\nafter\n"

    res = run_goawk(
        'BEGIN { a[1] = 1; a[2] = 2; a[3] = 3; n = 0;'
        ' for (k in a) { if (k == "2") continue; n++ }; print n }'
    )
    assert res.returncode == 0
    assert res.stdout == "2\n"


def test_for_in_with_special_variable_as_loop_variable(run_goawk):
    """for (NR in a) assigns each key to the special variable itself."""
    # CATCHES: a special variable is a legal for-in loop variable -- the key
    # string is stored through setSpecial, so NR reads back 10 (and 11 after
    # +1), SUBSEP becomes "s", and NF = 5 even rebuilds $0 as five empty
    # fields joined by OFS; RSTART works the same way.
    res = run_goawk(
        'BEGIN { a["10"] = 1; for (NR in a) print NR; print NR + 1;'
        ' b["s"] = 1; for (SUBSEP in b) print "[" SUBSEP "]";'
        ' c["5"] = 1; for (NF in c) print NF, "[" $0 "]";'
        ' d["3"] = 1; for (RSTART in d) print RSTART }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "10\n11\n[s]\n5 [    ]\n3\n"


def test_for_in_special_variable_assignment_error(run_goawk):
    """A key that cannot be stored into the special variable is an error."""
    # CATCHES: the loop assigns every key through setSpecial, so a key of
    # 1000001 makes the NF assignment fail mid-loop with the usual "NF set
    # too large" message and exit status 1 (the body never runs).
    res = run_goawk('BEGIN { a["1000001"] = 1; for (NF in a) print "never" }')
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "NF set too large: 1000001\n"


def test_in_and_for_in_on_local_arrays(run_goawk):
    """"in" and for-in work on array parameters and extra-param locals."""
    # CATCHES: array parameters and the extra "local" parameters (declared
    # after the spaces in the parameter list) are real arrays, so "k in arr"
    # tests them, for-in iterates them, and a local array is distinct from
    # any global of the same name.
    res = run_goawk(
        "function has(arr, k) { return k in arr }"
        " function count(arr, k) { for (k in arr) n++; return n }"
        ' function locals(x,   loc) { loc["z"] = 5;'
        ' return ("z" in loc) + 10 * length(loc) }'
        ' BEGIN { a[1] = "x"; a[2] = "y";'
        ' print has(a, "1"), has(a, "9"), count(a), locals(1) }'
    )
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == "1 0 2 11\n"


def test_runtime_error_inside_for_in_body_stops_iteration(run_goawk):
    """An error raised in a for-in body aborts the loop and the program."""
    # CATCHES: the error propagates out of the for-in (remaining keys are
    # never visited) and out of the program -- the line already printed is
    # flushed to stdout, the bare message goes to stderr alone, and the exit
    # status is 1.
    res = run_goawk(
        'BEGIN { a["only"] = 1; for (k in a) { print "key:" k; x = 1 / 0 } }'
    )
    assert res.returncode == 1
    assert res.stdout == "key:only\n"
    assert res.stderr == "division by zero\n"
