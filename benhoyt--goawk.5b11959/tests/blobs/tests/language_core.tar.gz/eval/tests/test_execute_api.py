"""Interpreter entry points reachable from the CLI (newexecute.go).

The CLI builds a Config (from -v flags) and calls Interpreter.Execute; a
config error such as an invalid -v NF value is reported before the program
starts.  The -coverprofile flag drives Interpreter.Array, which extracts the
hidden __COVER array so the coverage profile can be written: blocks report
hit counts per mode, append vs overwrite, and 0 for never-executed blocks.
The __COVER array is an ordinary AWK array, so programs can also inspect or
sabotage it: non-integer keys and non-numeric values make the profile write
fail after the program already ran, in-program assignments override block
counts, and a program with no blocks at all leaves Array nothing to find.
"""

import pytest

PROG = 'BEGIN { x = 1 }\n{ if ($1 > 1) print "big" }\nEND { print NR }\n'


def read_profile(tmp_path, name):
    """Return (mode line, sorted data lines) of a coverage profile file.

    Block lines are stripped of the leading working directory (the -f file is
    recorded by its absolute path) and sorted, because the interpreter
    emits them in Go map-iteration order.
    """
    lines = (tmp_path / name).read_text().splitlines()
    prefix = str(tmp_path) + "/"
    return lines[0], sorted(line.replace(prefix, "") for line in lines[1:])


@pytest.mark.parametrize(
    "assignment, message",
    [
        ("NF=-1", "NF set to negative value: -1"),
        ("NF=1000001", "NF set too large: 1000001"),
        ("ARGC=2000000", "ARGC set too large: 2000000"),
        (
            "RS=x(",
            'invalid regex "x(": error parsing regexp: missing closing ): `(?s:x()`',
        ),
    ],
)
def test_v_special_variable_errors_stop_execution(run_cli, assignment, message):
    """An invalid -v special-variable value fails before the program runs."""
    # CATCHES: -v values go through the same setSpecial validation as runtime
    # assignment, the error has no source position, and the program body
    # never executes (stdout stays empty).
    res = run_cli(["-v", assignment, 'BEGIN { print "ran" }'])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message + "\n"


def test_v_single_char_fs_value_is_literal(run_cli):
    """A one-character -v FS= is a literal separator, never a regex error."""
    # CATCHES: only multi-character separators are compiled as regexes, so
    # -v 'FS=(' runs fine and the program output still appears.
    res = run_cli(["-v", "FS=(", 'BEGIN { print "ran" }'])
    assert res.returncode == 0
    assert res.stdout == "ran\n"
    assert res.stderr == ""


def test_v_undefined_variable_is_ignored(run_cli):
    """-v for a name the program never declares is silently ignored."""
    # CATCHES: setVarByName skips unknown names instead of erroring, so the
    # program still runs and prints its marker line.
    res = run_cli(["-v", "nosuchvar=5", 'BEGIN { print "ok" }'])
    assert res.returncode == 0
    assert res.stdout == "ok\n"


def test_coverprofile_set_mode(run_cli, tmp_path):
    """-coverprofile writes a 'mode: set' profile with one line per block."""
    # CATCHES: every executed block records hit 1 (set semantics), the file
    # names are the resolved -f program path, and block order follows map
    # iteration so the lines are sorted before comparing.
    (tmp_path / "prog.awk").write_text(PROG)
    res = run_cli(["-f", "prog.awk", "-coverprofile=cov.prof"], stdin="1\n2\n3\n")
    assert res.returncode == 0
    assert res.stdout == "big\nbig\n3\n"
    mode, blocks = read_profile(tmp_path, "cov.prof")
    assert mode == "mode: set"
    assert blocks == [
        "prog.awk:1.9,1.15 1 1",
        "prog.awk:2.15,2.27 1 1",
        "prog.awk:2.3,2.15 1 1",
        "prog.awk:3.7,3.16 1 1",
    ]


def test_coverprofile_count_mode_counts_hits(run_cli, tmp_path):
    """-covermode=count records how often each block ran."""
    # CATCHES: the if-body runs twice (records 2 and 3), the condition three
    # times, and BEGIN/END once each -- counts, not just 0/1 flags.
    (tmp_path / "prog.awk").write_text(PROG)
    res = run_cli(
        ["-f", "prog.awk", "-covermode=count", "-coverprofile=cov.prof"],
        stdin="1\n2\n3\n",
    )
    assert res.returncode == 0
    assert res.stdout == "big\nbig\n3\n"
    mode, blocks = read_profile(tmp_path, "cov.prof")
    assert mode == "mode: count"
    assert blocks == [
        "prog.awk:1.9,1.15 1 1",
        "prog.awk:2.15,2.27 1 2",
        "prog.awk:2.3,2.15 1 3",
        "prog.awk:3.7,3.16 1 1",
    ]


def test_coverprofile_zero_for_unexecuted_block(run_cli, tmp_path):
    """A block that never ran is still listed, with hit count 0."""
    # CATCHES: the dead if-body must appear in the profile with 0 rather than
    # being omitted, so consumers can tell "not run" from "not instrumented".
    (tmp_path / "prog.awk").write_text(PROG)
    res = run_cli(["-f", "prog.awk", "-coverprofile=cov.prof"], stdin="1\n")
    assert res.returncode == 0
    assert res.stdout == "1\n"
    mode, blocks = read_profile(tmp_path, "cov.prof")
    assert mode == "mode: set"
    assert blocks == [
        "prog.awk:1.9,1.15 1 1",
        "prog.awk:2.15,2.27 1 0",
        "prog.awk:2.3,2.15 1 1",
        "prog.awk:3.7,3.16 1 1",
    ]


def test_coverprofile_append_extends_existing_file(run_cli, tmp_path):
    """-coverappend appends a new run's blocks to an existing profile."""
    # CATCHES: the second run's records are appended (not merged), and the
    # mode header written by the first run is left untouched.
    (tmp_path / "prog.awk").write_text(PROG)
    res = run_cli(["-f", "prog.awk", "-coverprofile=cov.prof"], stdin="1\n2\n3\n")
    assert res.returncode == 0
    res = run_cli(
        ["-f", "prog.awk", "-covermode=count", "-coverappend", "-coverprofile=cov.prof"],
        stdin="1\n",
    )
    assert res.returncode == 0
    text = (tmp_path / "cov.prof").read_text()
    lines = text.splitlines()
    assert lines[0] == "mode: set"  # header from the first run is kept
    assert len(lines) == 1 + 8  # two runs of four blocks each
    prefix = str(tmp_path) + "/"
    assert sorted(line.replace(prefix, "") for line in lines[1:]) == sorted(
        [
            "prog.awk:1.9,1.15 1 1",
            "prog.awk:2.15,2.27 1 1",
            "prog.awk:2.3,2.15 1 1",
            "prog.awk:3.7,3.16 1 1",
            "prog.awk:1.9,1.15 1 1",
            "prog.awk:2.15,2.27 1 0",
            "prog.awk:2.3,2.15 1 1",
            "prog.awk:3.7,3.16 1 1",
        ]
    )


def test_coverprofile_without_append_overwrites(run_cli, tmp_path):
    """Without -coverappend a second run truncates the profile."""
    # CATCHES: the file is rewritten from scratch (single header, four
    # blocks) instead of accumulating lines from the first run.
    (tmp_path / "prog.awk").write_text(PROG)
    res = run_cli(["-f", "prog.awk", "-coverprofile=cov.prof"], stdin="1\n2\n3\n")
    assert res.returncode == 0
    res = run_cli(["-f", "prog.awk", "-coverprofile=cov.prof"], stdin="1\n")
    assert res.returncode == 0
    mode, blocks = read_profile(tmp_path, "cov.prof")
    assert mode == "mode: set"
    assert blocks == [
        "prog.awk:1.9,1.15 1 1",
        "prog.awk:2.15,2.27 1 0",
        "prog.awk:2.3,2.15 1 1",
        "prog.awk:3.7,3.16 1 1",
    ]


def test_coverprofile_program_from_command_line(run_cli, tmp_path):
    """A command-line program is reported under the <cmdline> file name."""
    # CATCHES: programs passed as an argument are attributed to the special
    # file name "<cmdline>" (resolved under the working directory) with
    # positions counted from the start of the program text.
    res = run_cli(
        ["-coverprofile=cov.prof", 'BEGIN { if (0) { print "never" }; print "always" }'],
    )
    assert res.returncode == 0
    assert res.stdout == "always\n"
    lines = (tmp_path / "cov.prof").read_text().splitlines()
    # Strip the leading working directory so the expectation is tmp_path-free
    # while everything after it stays byte-exact.
    prefix = str(tmp_path) + "/"
    assert lines[0] == "mode: set"
    assert sorted(line.replace(prefix, "") for line in lines[1:]) == [
        "<cmdline>:1.18,1.32 1 0",
        "<cmdline>:1.35,1.50 1 1",
        "<cmdline>:1.9,1.16 1 1",
    ]


@pytest.mark.parametrize(
    "kind, mode_flag, mode_line",
    [
        ("empty-file", [], "mode: set"),
        ("comment-file", [], "mode: set"),
        ("cmdline", [], "mode: set"),
        ("comment-file", ["-covermode=count"], "mode: count"),
    ],
)
def test_coverprofile_program_without_blocks_writes_header_only(
    run_cli, tmp_path, kind, mode_flag, mode_line
):
    """A program with no coverable blocks yields a header-only profile."""
    # CATCHES: with zero statements the __COVER array is never created, so
    # Interpreter.Array finds no such array and the profile contains only the
    # mode line -- no error, no block lines, exit status 0.
    if kind == "cmdline":
        argv = mode_flag + ["-coverprofile=cov.prof", ""]
    else:
        name = "empty.awk" if kind == "empty-file" else "comment.awk"
        text = "" if kind == "empty-file" else "# only a comment\n"
        (tmp_path / name).write_text(text)
        argv = ["-f", name] + mode_flag + ["-coverprofile=cov.prof"]
    res = run_cli(argv)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert (tmp_path / "cov.prof").read_text() == mode_line + "\n"


def test_coverprofile_non_int_index_in_cover_array(run_cli, tmp_path):
    """A non-integer __COVER key aborts profile writing after the run."""
    # CATCHES: the program's own output is already on stdout when the profile
    # write fails, the message embeds the offending key, and no profile file
    # is created at all (data validation happens before the file is opened).
    res = run_cli(
        ["-coverprofile=cov.prof", 'BEGIN { __COVER["x"] = 1; print "done" }']
    )
    assert res.returncode == 1
    assert res.stdout == "done\n"
    assert res.stderr == "unable to write coverage profile: non-int index in data: x\n"
    assert not (tmp_path / "cov.prof").exists()


def test_coverprofile_string_value_in_cover_array(run_cli, tmp_path):
    """A string __COVER value fails conversion with the value in the message."""
    # CATCHES: Interpreter.Array maps string array elements to Go strings, and
    # the profile writer only accepts numbers, so the assigned text "s" is
    # reported verbatim inside "non-float64 value in data".
    res = run_cli(
        ["-coverprofile=cov.prof", 'BEGIN { __COVER["9"] = "s"; print "done" }']
    )
    assert res.returncode == 1
    assert res.stdout == "done\n"
    assert res.stderr == "unable to write coverage profile: non-float64 value in data: s\n"
    assert not (tmp_path / "cov.prof").exists()


def test_coverprofile_null_value_in_cover_array(run_cli, tmp_path):
    """An uninitialized __COVER value reads as empty in the error message."""
    # CATCHES: assigning a never-set variable stores a null value, which
    # Interpreter.Array converts to the empty string -- the message ends with
    # "data: " and nothing after it, unlike the string case.
    res = run_cli(
        ["-coverprofile=cov.prof", 'BEGIN { __COVER["9"] = z; print "done" }']
    )
    assert res.returncode == 1
    assert res.stdout == "done\n"
    assert res.stderr == "unable to write coverage profile: non-float64 value in data: \n"
    assert not (tmp_path / "cov.prof").exists()


def test_coverprofile_numstr_value_in_cover_array(run_cli, tmp_path, write_input):
    """A numeric-string __COVER value (an ARGV element) fails like a string."""
    # CATCHES: ARGV elements are numeric strings; their text ("in.txt") is
    # what Interpreter.Array extracts and what lands in the error message,
    # even though the value originated from the argument list.
    write_input("prog.awk", 'BEGIN { __COVER["5"] = ARGV[1]; print "done" }\n')
    write_input("in.txt", "l1\n")
    res = run_cli(["-f", "prog.awk", "-coverprofile=cov.prof", "in.txt"])
    assert res.returncode == 1
    assert res.stdout == "done\n"
    assert res.stderr == "unable to write coverage profile: non-float64 value in data: in.txt\n"
    assert not (tmp_path / "cov.prof").exists()


def test_coverprofile_delete_cover_array_resets_counts(run_cli, tmp_path):
    """Deleting __COVER inside a block erases that block's own counter."""
    # CATCHES: the counter statement runs at block entry, then the user's
    # delete wipes the whole array, so the one executed block is reported
    # with count 0 even though it clearly ran (stdout "x" was printed).
    (tmp_path / "prog.awk").write_text('BEGIN { delete __COVER; print "x" }\n')
    res = run_cli(["-f", "prog.awk", "-coverprofile=cov.prof"])
    assert res.returncode == 0
    assert res.stdout == "x\n"
    mode, blocks = read_profile(tmp_path, "cov.prof")
    assert mode == "mode: set"
    assert blocks == ["prog.awk:1.9,1.35 2 0"]


@pytest.mark.parametrize(
    "mode_flag, mode_line, prog, expected",
    [
        (
            [],
            "mode: set",
            'BEGIN { __COVER[1] = 42; print "b" }\n',
            ["prog.awk:1.9,1.36 2 42"],
        ),
        (
            ["-covermode=count"],
            "mode: count",
            'BEGIN { __COVER[2] = 7; if (1) { print "a" }; print "b" }\n',
            ["prog.awk:1.34,1.44 1 1", "prog.awk:1.47,1.57 1 1", "prog.awk:1.9,1.32 2 7"],
        ),
    ],
)
def test_coverprofile_user_value_overrides_block_count(
    run_cli, tmp_path, mode_flag, mode_line, prog, expected
):
    """An in-program __COVER assignment overwrites the block's own counter."""
    # CATCHES: counters are statements at block entry, so a later user
    # assignment to the same index wins -- the profile reports 42 (set mode)
    # or 7 (count mode) instead of the real execution count of 1.
    (tmp_path / "prog.awk").write_text(prog)
    res = run_cli(["-f", "prog.awk"] + mode_flag + ["-coverprofile=cov.prof"])
    assert res.returncode == 0
    mode, blocks = read_profile(tmp_path, "cov.prof")
    assert mode == mode_line
    assert blocks == expected


def test_coverprofile_extra_int_keys_beyond_blocks_ignored(run_cli, tmp_path):
    """Integer __COVER keys past the last block are dropped silently."""
    # CATCHES: only tracked block indices are written; an extra entry with a
    # valid integer key and numeric value neither errors nor shows up in the
    # profile, and the real block still reports its true count of 1.
    (tmp_path / "prog.awk").write_text('BEGIN { __COVER[99] = 5; print "b" }\n')
    res = run_cli(["-f", "prog.awk", "-coverprofile=cov.prof"])
    assert res.returncode == 0
    assert res.stdout == "b\n"
    mode, blocks = read_profile(tmp_path, "cov.prof")
    assert mode == "mode: set"
    assert blocks == ["prog.awk:1.9,1.36 2 1"]


def test_coverprofile_missing_directory_errors(run_cli, tmp_path):
    """A profile path inside a missing directory errors after the program ran."""
    # CATCHES: the failed open is reported with the Go "open ...: no such
    # file or directory" error verbatim after the program's stdout has been
    # produced, and the exit status is 1.
    res = run_cli(["-coverprofile=nodir/cov.prof", 'BEGIN { print "b" }'])
    assert res.returncode == 1
    assert res.stdout == "b\n"
    assert res.stderr == (
        "unable to write coverage profile: open nodir/cov.prof: "
        "no such file or directory\n"
    )


def test_coverprofile_scalar_cover_name_crashes(run_cli, tmp_path):
    """Using __COVER as a scalar under -coverprofile crashes the process."""
    # CATCHES: the coverage annotation makes __COVER an array, so the user's
    # scalar assignment fails re-resolution so hard the process dies with a
    # Go panic: exit status 2, "panic:" line naming the position, no output,
    # and no profile file -- instead of a clean parse error (which is what
    # the same conflict yields without -coverprofile).
    res = run_cli(["-coverprofile=cov.prof", "BEGIN { __COVER = 5 }"])
    assert res.returncode == 2
    assert res.stdout == ""
    assert (
        res.stderr.splitlines()[0]
        == 'panic: parse error at 1:9: can\'t use array "__COVER" as scalar'
    )
    assert not (tmp_path / "cov.prof").exists()


def test_v_assigns_program_global_scalar(run_cli):
    """-v name=value pre-assigns a scalar the program declares."""
    # CATCHES: the value becomes the global's initial value (a numeric
    # string that prints back as its text), while -v also interprets escape
    # sequences in the value, so "a\tb" contains a real tab.
    res = run_cli(["-v", "greeting=hello",
                   'BEGIN { print greeting; print ++count }'])
    assert res.returncode == 0
    assert res.stdout == "hello\n1\n"
    escaped = run_cli(["-v", "t=a\\tb", 'BEGIN { print "[" t "]" }'])
    assert escaped.returncode == 0
    assert escaped.stdout == "[a\tb]\n"
