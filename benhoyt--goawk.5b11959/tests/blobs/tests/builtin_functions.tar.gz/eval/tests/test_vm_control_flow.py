"""Tests for VM control flow: next, nextfile, exit, for-in and calls.

These pin the remaining control-flow opcodes of interp/vm.go: next /
nextfile record skipping, exit statuses (including the END block running
after exit), for-in loops over special and local variables, function
return values, the recursion limit and deep expression stacks.
"""

import pytest

from conftest import run_goawk, text


@pytest.fixture
def two_files(tmp_path):
    """Create f1.txt (two lines) and f2.txt (one line) in tmp_path."""
    (tmp_path / "f1.txt").write_text("one\ntwo\n")
    (tmp_path / "f2.txt").write_text("THREE\n")
    return tmp_path


def test_next_skips_rest_of_rules():
    """'next' abandons the current record, skipping later statements."""
    # CATCHES: the 'skip' record produces no output at all (the print after
    # the next never runs) while the following record is processed.
    result = run_goawk(
        '{ if ($1 == "skip") next; print $0 }',
        stdin="skip\nkeep\n",
    )
    assert result.returncode == 0
    assert text(result) == "keep\n"


def test_nextfile_moves_to_the_next_operand(two_files):
    """'nextfile' stops reading the current file and starts the next one."""
    # CATCHES: nextfile skips the REST of f1.txt (only 'one' prints) and
    # processing continues with f2.txt rather than ending the program.
    result = run_goawk(
        '{ if (FNR == 2) nextfile; print FILENAME, $0 }',
        args=["f1.txt", "f2.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "f1.txt one\nf2.txt THREE\n"


@pytest.mark.parametrize(
    "prog,status,expected",
    [
        ('{ print "rec", NR; if (NR == 1) exit 3 }', 3, "rec 1\n"),
        ('{ print "rec", NR; if (NR == 1) exit }', 0, "rec 1\n"),
        ('{ print "rec", NR; exit NR * 2 }', 2, "rec 1\n"),
    ],
    ids=["with-status", "bare-exit", "computed-status"],
)
def test_exit_sets_process_status(prog, status, expected):
    """exit N terminates the main loop and sets the process exit status."""
    # CATCHES: the numeric argument of exit becomes the interpreter's exit
    # code (2 for NR*2 on the first record) and a bare 'exit' means 0,
    # while output already printed is kept and the 2nd record is never read.
    result = run_goawk(prog, stdin="a\nb\n")
    assert result.returncode == status
    assert text(result) == expected
    assert result.stderr == b""


def test_end_block_runs_after_exit():
    """The END block still executes after exit, with NR at its old value."""
    # CATCHES: 'exit 7' from BEGIN does not skip END, and NR is still 0
    # because no record was ever read; the exit status survives the END
    # block.
    result = run_goawk('BEGIN { exit 7 } END { print "end", NR }')
    assert result.returncode == 7
    assert text(result) == "end 0\n"


@pytest.mark.parametrize(
    "prog,expected_lines",
    [
        ('BEGIN { a["x"] = 1; a["y"] = 2;'
         ' for (NR in a) print NR, a[NR] }', ["x 1", "y 2"]),
        ('function f(a) { for (k in a) print k, a[k] }'
         ' BEGIN { b["p"] = 1; b["q"] = 2; f(b) }', ["p 1", "q 2"]),
    ],
    ids=["special-var", "local-var"],
)
def test_for_in_loop_variable_kinds(prog, expected_lines):
    """for-in can iterate into a special variable or a function local."""
    # CATCHES: using NR as the loop variable assigns each INDEX to NR, and
    # a local loop variable works the same; the VISIT ORDER is unspecified
    # (raw map order), so every index must appear exactly once.
    result = run_goawk(prog)
    assert result.returncode == 0
    assert sorted(text(result).splitlines()) == expected_lines


def test_for_in_break_stops_the_loop():
    """'break' inside for-in stops iterating over the array."""
    # CATCHES: break leaves the for-in loop right after the first index,
    # so exactly ONE key prints even though the array holds three.
    result = run_goawk(
        'BEGIN { a["x"] = 1; a["y"] = 2; a["z"] = 3;'
        ' for (k in a) { print k; break } }'
    )
    lines = text(result).splitlines()
    assert len(lines) == 1
    assert lines[0] in ("x", "y", "z")


def test_return_inside_for_in():
    """'return' from inside a for-in loop exits the function immediately."""
    # CATCHES: the return value produced inside the loop body becomes the
    # function's value and the loop does not continue after it.
    result = run_goawk(
        'function f(a) { for (k in a) { print "visit", k; return k } }'
        ' BEGIN { b["only"] = 1; print "got", f(b) }'
    )
    assert result.returncode == 0
    assert text(result) == "visit only\ngot only\n"


def test_function_without_return_yields_empty_string():
    """Calling a function whose body falls through yields an empty value."""
    # CATCHES: the implicit return value prints as nothing at all (an
    # empty field between the two spaces), not 0 and not 'null'.
    result = run_goawk('function f() { } BEGIN { print f(), "[" f() "]" }')
    assert text(result) == " []\n"


def test_function_missing_arguments_are_null():
    """Arguments beyond those passed default to an empty (zero) value."""
    # CATCHES: f(3, 1) with 110 parameters makes p109 an empty value that
    # acts as 0 in arithmetic, so the sum is 3 -- and long parameter lists
    # (over the initial 100-slot value stack) are handled.
    params = ",".join("p%d" % i for i in range(110))
    result = run_goawk(
        'function f(%s) { return p0 + p109 } BEGIN { print f(3, 1) }'
        % params
    )
    assert text(result) == "3\n"


def test_runaway_recursion_is_a_runtime_error():
    """Infinite recursion stops at the call depth limit with a clear error."""
    # CATCHES: the interpreter aborts with 'calling "f" exceeded maximum
    # call depth of 1000' (status 1) instead of crashing the process.
    result = run_goawk('function f() { return f() } BEGIN { print f() }')
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'calling "f" exceeded maximum call depth of 1000\n'
    )


def test_long_concatenation_chain():
    """A single print with 120 concatenated operands evaluates fully."""
    # CATCHES: more than 100 operands in one concatenation (past the
    # interpreter's initial value-stack size) still produce the exact
    # joined string, with every number rendered in its integer form.
    operands = " ".join(str(i) for i in range(1, 121))
    expected = "".join(str(i) for i in range(1, 121))
    result = run_goawk('BEGIN { print %s }' % operands)
    assert text(result) == expected + "\n"
