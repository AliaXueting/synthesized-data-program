"""Tests for the close() and fflush() builtins (stream status returns)."""

import pytest

from conftest import run_goawk, text


def test_close_of_never_opened_stream_returns_minus_one():
    """close() of a name that was never opened returns -1."""
    # CATCHES: closing an unknown stream name must yield -1 (not 0 and
    # not an error), leaving stderr empty.
    result = run_goawk('BEGIN { print close("nosuchfile") }')
    assert result.returncode == 0
    assert text(result) == "-1\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "expr",
    ["fflush()", 'fflush("")'],
    ids=["no-arg", "empty-string"],
)
def test_fflush_all_returns_zero(expr):
    """fflush() and fflush(\"\") flush all output streams and return 0."""
    # CATCHES: the no-argument and empty-string forms both mean 'flush
    # everything' and report success as 0.
    result = run_goawk('BEGIN { print %s }' % expr)
    assert result.returncode == 0
    assert text(result) == "0\n"
    assert result.stderr == b""


def test_fflush_unknown_stream_returns_minus_one():
    """fflush(name) of a non-stream prints an error and returns -1."""
    # CATCHES: flushing a name that is not an output file or pipe emits
    # 'error flushing ...: not an output file or pipe' on stderr and the
    # function value is -1.
    result = run_goawk('BEGIN { print fflush("nosuchstream") }')
    assert result.returncode == 0
    assert text(result) == "-1\n"
    assert result.stderr.decode() == (
        'error flushing "nosuchstream": not an output file or pipe\n'
    )


@pytest.fixture
def data_file(tmp_path):
    """Create f1.txt (two lines) in tmp_path."""
    (tmp_path / "f1.txt").write_text("one\ntwo\n")
    return tmp_path


def test_close_output_file_returns_zero(tmp_path):
    """close() of a file opened with '>' returns 0 and flushes the file."""
    # CATCHES: the redirected print must actually be written to the file
    # (close flushes it) and close() then reports success as 0.
    result = run_goawk(
        'BEGIN { print "hello" > "out.txt"; print close("out.txt") }',
        cwd=tmp_path,
    )
    assert result.returncode == 0
    assert text(result) == "0\n"
    assert (tmp_path / "out.txt").read_text() == "hello\n"


def test_close_output_pipe_returns_command_status():
    """close() of an output pipe returns the command's exit status."""
    # CATCHES: closing a '| command' stream yields the command's exit code
    # (1 for 'false') without printing anything to stderr, even though the
    # command failed.
    result = run_goawk(
        'BEGIN { print "x" | "false"; print close("false") }'
    )
    assert result.returncode == 0
    assert text(result) == "1\n"
    assert result.stderr == b""


def test_close_input_pipe_returns_command_status():
    """close() of a '| getline' pipe returns the command's exit status."""
    # CATCHES: after reading from a command, close() reports the command's
    # own exit code (4 for 'exit 4') rather than 0.
    result = run_goawk(
        'BEGIN { "exit 4" | getline line; print close("exit 4") }'
    )
    assert result.returncode == 0
    assert text(result) == "4\n"


def test_close_input_file_returns_zero(data_file):
    """close() of a '< file' input stream returns 0."""
    # CATCHES: an input FILE stream closes successfully with 0, unlike a
    # pipe (whose status is the command's exit code).
    result = run_goawk(
        'BEGIN { getline line < "f1.txt"; print close("f1.txt") }',
        cwd=data_file,
    )
    assert result.returncode == 0
    assert text(result) == "0\n"


def test_close_is_idempotent_after_first_close(tmp_path):
    """Closing the same stream a second time returns -1."""
    # CATCHES: the first close() removes the stream from the stream table,
    # so the second close() finds nothing and returns -1 (not 0, not an
    # error), with no stderr output.
    result = run_goawk(
        'BEGIN { print "x" > "o2.txt"; print close("o2.txt");'
        ' print close("o2.txt") }',
        cwd=tmp_path,
    )
    assert result.returncode == 0
    assert text(result) == "0\n-1\n"
    assert result.stderr == b""


def test_append_redirect_appends_to_existing_file(tmp_path):
    """'>>' appends after '>' instead of truncating the file."""
    # CATCHES: the first '>' creates the file, the '>>' must append to it
    # (not overwrite), and reading the file back through getline shows
    # both lines in order.
    result = run_goawk(
        'BEGIN { print "a" > "o.txt"; print "b" >> "o.txt";'
        ' close("o.txt"); while ((getline line < "o.txt") > 0) print line }',
        cwd=tmp_path,
    )
    assert result.returncode == 0
    assert text(result) == "a\nb\n"


def test_printf_redirect_writes_to_file(tmp_path):
    """printf with '> file' writes formatted output to that file."""
    # CATCHES: printf's redirection takes the same file streams as print,
    # so the formatted 'x=5' line lands in the file verbatim.
    result = run_goawk(
        'BEGIN { printf "%s=%d\\n", "x", 5 > "p.txt"; close("p.txt");'
        ' getline l < "p.txt"; print l }',
        cwd=tmp_path,
    )
    assert result.returncode == 0
    assert text(result) == "x=5\n"


def test_printf_pipe_output_and_close():
    """printf with '| command' writes through the pipe and closes cleanly."""
    # CATCHES: the piped printf output reaches the command's stdout before
    # the status is printed, and close() of the pipe reports 0.
    result = run_goawk(
        'BEGIN { printf "%d\\n", 42 | "cat"; print close("cat") }'
    )
    assert result.returncode == 0
    assert text(result) == "42\n0\n"
