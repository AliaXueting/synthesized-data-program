"""Tests for the system() builtin: shell execution and exit status.

All commands are /bin/sh builtins (echo/printf/exit/true/false), so no
external files or network access are involved.
"""

import pytest

from conftest import run_goawk, text


@pytest.mark.parametrize(
    "command,expected_status",
    [
        ("exit 3", "3"),
        ("exit 2", "2"),
        ("false", "1"),
        ("true", "0"),
        ("", "0"),
    ],
    ids=["exit-3", "exit-2", "false", "true", "empty"],
)
def test_system_returns_exit_status(command, expected_status):
    """system(cmd) returns the command's exit status as a number."""
    # CATCHES: the return value is the wait status of /bin/sh -c (so
    # 'exit 3' gives 3), an empty command succeeds with 0, and 'false'
    # maps to 1.
    result = run_goawk(
        'BEGIN { print system("%s") }' % command
    )
    assert result.returncode == 0
    assert text(result) == expected_status + "\n"


def test_system_passes_command_stdout_through():
    """The command's stdout is passed through to the interpreter's stdout."""
    # CATCHES: system() must wire the child's stdout to the same stream
    # as print, so 'echo during' appears before the returned status 0.
    result = run_goawk('BEGIN { print system("echo during") }')
    assert result.returncode == 0
    assert text(result) == "during\n0\n"


def test_system_passes_command_stderr_through():
    """The command's stderr goes to the interpreter's stderr, not stdout."""
    # CATCHES: stderr redirection of the child must reach the goawk
    # process's stderr while stdout only carries the printed status.
    result = run_goawk('BEGIN { print system("echo oops 1>&2") }')
    assert result.returncode == 0
    assert text(result) == "0\n"
    assert result.stderr.decode() == "oops\n"


def test_system_output_interleaves_in_order():
    """Output printed before system() precedes the child's output."""
    # CATCHES: goawk flushes its buffered stdout before starting the
    # child, so 'before' is emitted before the child's 'during' and the
    # status print comes last.
    result = run_goawk(
        'BEGIN { print "before"; print system("echo during"); print "after" }'
    )
    assert result.returncode == 0
    assert text(result) == "before\nduring\n0\nafter\n"


def test_system_stdout_without_newline_concatenates():
    """A command's trailing-byte-free stdout is not padded."""
    # CATCHES: 'printf out' writes no newline, so the following print of
    # the status lands directly after it on the same line.
    result = run_goawk('BEGIN { s = system("printf out"); print s }')
    assert result.returncode == 0
    assert text(result) == "out0\n"


def test_system_command_killed_by_signal():
    """A command that dies from a signal reports 256 + signal number."""
    # CATCHES: 'kill -9 $$' makes the shell itself die of SIGKILL, and
    # system() must surface that as 256+9 = 265 (GoAWK's encoding of a
    # signalled child), not as the shell's own exit status or -1.
    result = run_goawk('BEGIN { print system("kill -9 $$") }')
    assert result.returncode == 0
    assert text(result) == "265\n"
    assert result.stderr == b""
