"""Tests for the FIELDS array and @-field access in CSV header mode."""

import pytest

from conftest import run_goawk, text


CSV_INPUT = "name,email,age\nalice,a@x,30\nbob,b@y,9\n"


def test_fields_maps_index_to_column_name():
    """FIELDS[i] holds the i-th header column NAME (not the reverse)."""
    # CATCHES: in CSV header mode FIELDS is keyed by column index and
    # yields the header text: 1 name, 2 email, 3 age.
    result = run_goawk(
        'NR==1 { for (i = 1; i in FIELDS; i++) print i, FIELDS[i] }',
        flags=["-i", "csv", "-H"],
        stdin=CSV_INPUT,
    )
    assert result.returncode == 0
    assert text(result) == "1 name\n2 email\n3 age\n"


def test_fields_length_and_membership():
    """FIELDS has one element per header column, keyed 1..N."""
    # CATCHES: length(FIELDS) is the column count and 'in' is true for
    # indexes 1..3 but false for 4 and for the name string 'name' (the
    # array is index->name, not name->index).
    result = run_goawk(
        'NR==1 { print length(FIELDS);'
        ' print (1 in FIELDS), (4 in FIELDS), ("name" in FIELDS) }',
        flags=["-i", "csv", "-H"],
        stdin=CSV_INPUT,
    )
    assert result.returncode == 0
    assert text(result) == "3\n1 0 0\n"


def test_fields_missing_key_is_empty():
    """FIELDS[\"name\"] does not exist and reads as the empty string."""
    # CATCHES: looking FIELDS up by column NAME yields "" (a null entry),
    # confirming the key direction is index-to-name only.
    result = run_goawk(
        'NR==1 { print FIELDS["name"] == "" }',
        flags=["-i", "csv", "-H"],
        stdin=CSV_INPUT,
    )
    assert result.returncode == 0
    assert text(result) == "1\n"


def test_fields_preserves_quoted_header_names():
    """A quoted CSV header field keeps its embedded comma in FIELDS."""
    # CATCHES: for header 'a,"b,c"' the second column name is the single
    # string 'b,c' -- quoting is honored when building FIELDS.
    result = run_goawk(
        'NR==1 { for (i = 1; i in FIELDS; i++) print i, FIELDS[i] }',
        flags=["-i", "csv", "-H"],
        stdin='a,"b,c"\n1,2\n',
    )
    assert result.returncode == 0
    assert text(result) == "1 a\n2 b,c\n"


def test_at_literal_reads_named_field():
    """@\"name\" evaluates to the data field under that header column."""
    # CATCHES: @ takes a string literal (or expression) naming a column
    # and yields the field value: @name/@age on row 2 give 'bob' and '9'.
    result = run_goawk(
        'NR==2 { print @"name", @"age" }',
        flags=["-i", "csv", "-H"],
        stdin=CSV_INPUT,
    )
    assert result.returncode == 0
    assert text(result) == "bob 9\n"


def test_at_expression_uses_variable_value():
    """@var uses the variable's VALUE as the column name."""
    # CATCHES: @n with n holding 'y' reads column y (value 2), so @ is
    # an expression form, not a bare identifier lookup.
    result = run_goawk(
        'NR==1 { n = "age"; print @n }',
        flags=["-i", "csv", "-H"],
        stdin=CSV_INPUT,
    )
    assert result.returncode == 0
    assert text(result) == "30\n"


def test_at_unknown_column_is_empty():
    """@\"nonexistent\" yields the empty string, not an error."""
    # CATCHES: an unknown column name returns "" quietly rather than
    # aborting or returning the whole record.
    result = run_goawk(
        'NR==1 { print @"zzz" == "" }',
        flags=["-i", "csv", "-H"],
        stdin=CSV_INPUT,
    )
    assert result.returncode == 0
    assert text(result) == "1\n"


def test_at_without_header_is_error():
    """@field with no CSV header aborts with the exact guidance message."""
    # CATCHES: using @ when no header was configured is a runtime error
    # (status 1) with the message pointing at -H / INPUTMODE 'header'.
    result = run_goawk(
        '{ print @x }',
        flags=["-i", "csv"],
        stdin="x\n",
    )
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'no field names for @; use -H or add "header" to INPUTMODE, '
        'and use "getline" first if in BEGIN\n'
    )


def test_at_literal_without_header_is_error():
    """A literal @"name" with no header aborts like the variable form."""
    # CATCHES: the string-literal form of @ is validated at runtime just
    # like @variable -- the same guidance message and exit status 1 come
    # from the literal-name lookup path, not only the dynamic one.
    result = run_goawk(
        'BEGIN { print @"foo" }',
        flags=["-i", "csv"],
        stdin="a,b\n",
    )
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'no field names for @; use -H or add "header" to INPUTMODE, '
        'and use "getline" first if in BEGIN\n'
    )


def test_at_assignment_is_parse_error():
    """Assigning through an @ expression is rejected at parse time."""
    # CATCHES: '@name = value' is not supported: the parser errors with
    # 'assigning @ expression not supported' and exits 1 before running.
    result = run_goawk(
        'NR==1 { @name = "carol"; print $1 }',
        flags=["-i", "csv", "-H"],
        stdin=CSV_INPUT,
    )
    assert result.returncode == 1
    assert result.stdout == b""
    assert "assigning @ expression not supported" in result.stderr.decode()


def test_inputmode_header_string_enables_fields_from_begin():
    """INPUTMODE='csv header' set in BEGIN activates FIELDS and @."""
    # CATCHES: the header mode can be configured by assigning the special
    # variable INPUTMODE (equivalent to -i csv -H), after which FIELDS
    # and @name work in the main loop.
    result = run_goawk(
        'BEGIN { INPUTMODE = "csv header" }'
        ' NR==1 { for (i = 1; i in FIELDS; i++) print i, FIELDS[i];'
        ' print @"name" }',
        stdin=CSV_INPUT,
    )
    assert result.returncode == 0
    assert text(result) == "1 name\n2 email\n3 age\nalice\n"


def test_tsv_header_fields():
    """-i tsv -H builds FIELDS from tab-separated headers too."""
    # CATCHES: the FIELDS surface works for TSV input mode with the same
    # index-to-name mapping.
    result = run_goawk(
        'NR==1 { print FIELDS[1], FIELDS[2] }',
        flags=["-i", "tsv", "-H"],
        stdin="x\ty\n1\t2\n",
    )
    assert result.returncode == 0
    assert text(result) == "x y\n"
