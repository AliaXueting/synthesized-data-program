"""Tests for the rand() and srand() random-number builtins."""

from conftest import run_goawk, text


def rand_sequence(prog, runs=2):
    """Run prog `runs` times; return the list of stdout texts."""
    return [text(run_goawk(prog)) for _ in range(runs)]


def test_rand_without_srand_is_deterministic():
    """rand() with no srand() yields the same fixed sequence every run."""
    # CATCHES: the unseeded generator must be deterministic (initial seed
    # 1): the first three values are exactly 0.606997, 0.317963, 0.872292
    # in every invocation.
    outputs = rand_sequence('BEGIN { for (i = 0; i < 3; i++) print rand() }')
    assert outputs[0] == "0.606997\n0.317963\n0.872292\n"
    assert outputs[1] == outputs[0]


def test_rand_values_are_in_half_open_unit_interval():
    """Every rand() value lies in [0, 1) -- never 1.0 or negative."""
    # CATCHES: the generator must never return 1.0 or a negative value
    # across a thousand draws, matching the half-open [0,1) contract.
    result = run_goawk(
        'BEGIN { bad = 0; for (i = 0; i < 1000; i++) {'
        ' r = rand(); if (r < 0 || r >= 1) bad++ } print bad }'
    )
    assert text(result) == "0\n"


def test_srand_returns_the_previous_seed():
    """srand(x) reseeds and returns the seed value that was in effect."""
    # CATCHES: the initial seed is 1, so the first srand(42) returns 1;
    # each later srand returns the previous seed (42, then 7) and the
    # no-argument srand() does the same.
    result = run_goawk(
        'BEGIN { print srand(42); print srand(7); print srand() }'
    )
    assert text(result) == "1\n42\n7\n"


def test_srand_seed_makes_sequence_reproducible():
    """srand(n) with a fixed n reproduces the exact same sequence."""
    # CATCHES: after srand(99) the values must be exactly 0.559714,
    # 0.61605 and 0.733242 on every run -- a wrong seeding formula (or
    # clock-based seeding when an argument is given) breaks this.
    outputs = rand_sequence(
        'BEGIN { srand(99); for (i = 0; i < 3; i++) print rand() }'
    )
    assert outputs[0] == "0.559714\n0.61605\n0.733242\n"
    assert outputs[1] == outputs[0]


def test_srand_with_one_matches_unseeded_generator():
    """The default seed is 1: srand(1) reproduces the unseeded sequence."""
    # CATCHES: rand() before any srand() must equal rand() after srand(1),
    # proving the initial state is seed 1 rather than 0 or a random value.
    result = run_goawk('BEGIN { print rand(); srand(1); print rand() }')
    assert text(result) == "0.606997\n0.606997\n"


def test_srand_different_seeds_give_different_values():
    """Distinct seeds produce a different first rand() value."""
    # CATCHES: reseeding with 2 after 1 must actually change the next
    # value, so srand cannot be a no-op.
    result = run_goawk(
        'BEGIN { srand(1); a = rand(); srand(2); b = rand(); print a != b }'
    )
    assert text(result) == "1\n"


def test_srand_negative_seed_round_trips():
    """srand() accepts negative seeds and reports them back verbatim."""
    # CATCHES: srand(-3) stores -3 (no clamping to zero), so the following
    # srand(0) returns -3.
    result = run_goawk('BEGIN { srand(-3); print srand(0) }')
    assert text(result) == "-3\n"


def test_srand_string_seed_coerces_to_number():
    """A string seed argument is coerced numerically, like srand(5)."""
    # CATCHES: srand("5") must seed identically to srand(5), so the same
    # first rand() value comes out afterwards.
    result = run_goawk(
        'BEGIN { srand("5"); a = rand(); srand(5); b = rand();'
        ' print a == b }'
    )
    assert text(result) == "1\n"
