"""Shared helpers for the builtin_functions black-box tests.

Every test invokes the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hardcoded path).  Child processes run with a pinned, hermetic environment: no
network, no TTY, a fixed PATH, and data files only under ``tmp_path``.
``GOCOVERDIR`` is copied from the test process environment into the child env
when present so the pipeline can measure source coverage of the binary.
"""

import os
import subprocess
from pathlib import Path

# The runner (eval/run.sh) always exports PROGRAMGYM_EXECUTABLE.  The relative
# fallback only exists so the suite can be launched by hand from the branch
# root without it; tests themselves never hardcode a path.
_ENV_VAR = "PROGRAMGYM_EXECUTABLE"


def _executable_path() -> str:
    path = os.environ.get(_ENV_VAR)
    if path:
        return path
    fallback = Path(__file__).resolve().parents[2] / "executable"
    if fallback.is_file():
        return str(fallback)
    raise RuntimeError(
        f"{_ENV_VAR} is not set and no executable was found at {fallback}"
    )


# The pinned base environment for every child process.  Tests may add to it
# (``env=``) or replace it entirely (``replace_env=True``) when they need
# exact control over what ENVIRON contains.
BASE_ENV = {
    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
    "HOME": "/tmp",
    "TMPDIR": "/tmp",
    "LC_ALL": "C.UTF-8",
    "LANG": "C.UTF-8",
}


def child_env(extra=None, replace=False):
    """Build the child environment: pinned base, test overrides, GOCOVERDIR.

    Returns the exact dict the child process will see, so tests can predict
    what ``ENVIRON`` must contain (e.g. ``len(child_env(...))``).
    """
    env = {} if replace else dict(BASE_ENV)
    if extra:
        env.update(extra)
    # Coverage instrumentation hook: pass GOCOVERDIR through when the harness
    # set it, so the pipeline can collect coverage of the reference binary.
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env["GOCOVERDIR"] = value
    return env


def run_goawk(prog=None, flags=(), args=(), stdin="", env=None,
              replace_env=False, cwd=None, progfile=None, timeout=30):
    """Run the AWK executable and return the completed subprocess result.

    Args:
        prog: AWK program passed as a single command-line argument.
        progfile: path to a program file; used as ``-f progfile`` instead of
            ``prog`` (needed when the program contains quotes that would be
            mangled by shell-free argument passing is not an issue, but kept
            for readability of quoting-heavy programs).
        flags: extra CLI flags placed before the program (e.g. ``["-c"]``).
        args: operands placed after the program (filenames, ``var=value``).
        stdin: input bytes (or str) fed to the program's stdin.
        env: extra environment variables layered over the pinned base env.
        replace_env: build the child env from ``env`` alone (no base vars).
        cwd: working directory for the child (use ``tmp_path`` for file tests).
        timeout: subprocess timeout in seconds.

    Returns ``subprocess.CompletedProcess`` with raw ``stdout``/``stderr``
    bytes and ``returncode``.
    """
    if (prog is None) == (progfile is None):
        raise ValueError("exactly one of prog / progfile is required")
    cmd = [_executable_path()]
    cmd.extend(str(f) for f in flags)
    if progfile is not None:
        cmd.extend(["-f", str(progfile)])
    else:
        cmd.append(prog)
    cmd.extend(str(a) for a in args)
    data = stdin.encode() if isinstance(stdin, str) else stdin
    return subprocess.run(
        cmd,
        input=data,
        capture_output=True,
        env=child_env(env, replace=replace_env),
        cwd=str(cwd) if cwd is not None else None,
        timeout=timeout,
    )


def text(result) -> str:
    """Decode a CompletedProcess stdout as text (asserts are done on this)."""
    return result.stdout.decode("utf-8", errors="surrogateescape")
