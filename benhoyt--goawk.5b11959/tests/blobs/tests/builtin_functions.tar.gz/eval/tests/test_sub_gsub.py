"""Tests for sub() and gsub(): replacement, write-through, and & handling."""

import pytest

from conftest import run_goawk, text


def test_sub_replaces_first_match_only():
    """sub() replaces only the first match and returns 1."""
    # CATCHES: sub() must stop after the first replacement ("X bar foo"),
    # while returning the count of replacements performed.
    result = run_goawk(
        'BEGIN { s = "foo bar foo"; n = sub(/foo/, "X", s); print n, s }'
    )
    assert result.returncode == 0
    assert text(result) == "1 X bar foo\n"


def test_gsub_replaces_all_matches():
    """gsub() replaces every non-overlapping match and returns the count."""
    # CATCHES: gsub() must continue after a replacement (unlike sub) and
    # return the total number of replacements, not just 1.
    result = run_goawk(
        'BEGIN { s = "foo bar foo"; n = gsub(/foo/, "X", s); print n, s }'
    )
    assert result.returncode == 0
    assert text(result) == "2 X bar X\n"


def test_sub_default_target_is_dollar0_and_rebuilds_fields():
    """sub(re, repl) with no target uses $0 and re-splits the fields."""
    # CATCHES: after sub() on $0 the record is re-parsed so NF and $2 see the
    # new value, and the return value is still the replacement count.
    result = run_goawk(
        '{ n = sub(/hello/, "HI"); print n, $0, NF, $2 }',
        stdin="hello world hello\n",
    )
    assert result.returncode == 0
    assert text(result) == "1 HI world hello 3 world\n"


def test_gsub_on_field_rebuilds_record():
    """gsub(re, repl, $1) writes through to the field and rebuilds $0."""
    # CATCHES: replacing in $1 must update $0 to "XXX bbb" (fields rejoined
    # with OFS), proving field targets are real lvalues.
    result = run_goawk(
        '{ n = gsub(/a/, "X", $1); print n, $1, $0 }',
        stdin="aaa bbb\n",
    )
    assert result.returncode == 0
    assert text(result) == "3 XXX XXX bbb\n"


def test_sub_to_array_element_writes_through():
    """sub(re, repl, a[i]) updates exactly that array element."""
    # CATCHES: array-element targets must be written through, including when
    # the array is passed to a user function as a parameter.
    result = run_goawk(
        'function fix(a) { sub(/o/, "0", a[1]) }'
        'BEGIN { arr[1] = "foo"; arr[2] = "world"; fix(arr);'
        ' print arr[1], arr[2] }'
    )
    assert result.returncode == 0
    assert text(result) == "f0o world\n"


def test_sub_on_scalar_function_param_is_local():
    """sub() on a by-value scalar parameter does not write to the caller."""
    # CATCHES: scalars are passed by value, so sub(/o/,...) inside f() must
    # leave the caller's x unchanged even though sub writes its target.
    result = run_goawk(
        'function f(t) { sub(/o/, "0", t) } BEGIN { x = "foo"; f(x); print x }'
    )
    assert result.returncode == 0
    assert text(result) == "foo\n"


@pytest.mark.parametrize(
    "repl,expected",
    [
        (r"[&]", r"he[ll]o"),
        (r"a\\&b", r"hea&bo"),
        (r"a\\\\b", r"hea\bo"),
        (r"a\\nb", r"hea\nbo"),
        ("", "heo"),
        (r"x\\", r"hex\o"),
    ],
    ids=["amp", "escaped-amp", "escaped-backslash", "backslash-other",
         "empty", "trailing-backslash"],
)
def test_sub_replacement_escapes(repl, expected):
    """& is the matched text; \\& is a literal &; other escapes pass through."""
    # CATCHES: "&" must expand to the matched substring, "\&" must become a
    # literal ampersand, "\\" a single backslash, while "\n" must stay the
    # two characters backslash-n (not a newline).
    prog = 'BEGIN { s = "hello"; sub(/l+/, "%s", s); print s }' % repl
    result = run_goawk(prog)
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_sub_no_match_returns_zero():
    """sub() returns 0 and leaves the target unchanged when nothing matches."""
    # CATCHES: the count must be 0 (not an error) and the string must be
    # untouched when the regex does not match at all.
    result = run_goawk(
        'BEGIN { s = "abc"; n = sub(/x/, "y", s); print n, s }'
    )
    assert result.returncode == 0
    assert text(result) == "0 abc\n"


def test_gsub_empty_regex_inserts_between_chars():
    """gsub(//, repl) inserts the replacement at every character boundary."""
    # CATCHES: an empty regex matches at every position (including start and
    # end), so "ab" becomes "-a-b-" with count 3, and "&" expands to "".
    result = run_goawk(
        'BEGIN { s = "ab"; n = gsub(//, "-", s); print n, s;'
        ' s2 = "ab"; m = gsub(//, "[&]", s2); print m, s2 }'
    )
    assert result.returncode == 0
    assert text(result) == "3 -a-b-\n3 []a[]b[]\n"


def test_gsub_overlap_skips_consumed_text():
    """gsub() resumes after the replaced text, not inside it."""
    # CATCHES: after replacing "aa" in "aaa" with "X", scanning continues
    # after the replacement, so the leftover "a" stays: 1 replacement, "Xa".
    result = run_goawk(
        'BEGIN { s = "aaa"; n = gsub(/aa/, "X", s); print n, s }'
    )
    assert result.returncode == 0
    assert text(result) == "1 Xa\n"


def test_gsub_ampersand_uses_each_match():
    """In gsub() every replacement's & refers to its own matched text."""
    # CATCHES: "&" must expand per-match ("12" then nothing), producing
    # "ab<12>12>cd", not a single global expansion.
    result = run_goawk(
        'BEGIN { s = "ab12cd"; n = gsub(/[0-9]+/, "<&>&>", s); print n, s }'
    )
    assert result.returncode == 0
    assert text(result) == "1 ab<12>12>cd\n"


@pytest.mark.parametrize(
    "bad_target",
    [
        '"literal"',
        "1+2",
        "length(s)",
    ],
    ids=["string-literal", "arithmetic", "function-call"],
)
def test_sub_target_must_be_lvalue(bad_target):
    """A non-lvalue third argument to sub/gsub is a parse-time error."""
    # CATCHES: the parser must reject constant or expression targets with
    # "3rd arg to sub/gsub must be lvalue", exiting 1 before running anything.
    prog = "BEGIN { x = sub(/a/, \"b\", %s) }" % bad_target
    result = run_goawk(prog)
    assert result.returncode == 1
    assert text(result) == ""
    assert "3rd arg to sub/gsub must be lvalue" in result.stderr.decode()


def test_sub_target_lvalue_error_message_format():
    """The lvalue parse error carries position, source line, and caret."""
    # CATCHES: the error must be reported at the exact column of the bad
    # argument with the offending line echoed underneath.
    result = run_goawk('BEGIN { sub(/a/, "b", "literal") }')
    assert result.returncode == 1
    assert result.stderr.decode() == (
        "<cmdline>:1:23: 3rd arg to sub/gsub must be lvalue\n"
        'BEGIN { sub(/a/, "b", "literal") }\n'
        "                      ^\n"
    )


def test_sub_regex_from_string_variable():
    """sub() accepts the regex as a dynamic string; & still expands."""
    # CATCHES: the first argument need not be a /re/ literal, and the
    # matched-text expansion must work identically for dynamic regexes.
    result = run_goawk(
        'BEGIN { re = "l+"; s = "hello"; n = sub(re, "<&>", s); print n, s }'
    )
    assert result.returncode == 0
    assert text(result) == "1 he<ll>o\n"


def test_sub_invalid_dynamic_regex_is_runtime_error():
    """An invalid regex string aborts sub() at runtime with exit status 1."""
    # CATCHES: dynamic regexes are compiled when sub runs; the error names the
    # regex and nothing further executes (exit 1, stderr, stdout flushed).
    result = run_goawk(
        'BEGIN { re = "[a"; s = "x"; print "pre"; print sub(re, "y", s) }'
    )
    assert result.returncode == 1
    assert text(result) == "pre\n"
    assert result.stderr.decode() == (
        'invalid regex "[a": error parsing regexp: missing closing ]: `[a)`\n'
    )


def test_gsub_invalid_dynamic_regex_is_runtime_error():
    """An invalid regex string aborts gsub() the same way sub() does."""
    # CATCHES: gsub() compiles its dynamic regex at call time too, so the
    # same 'invalid regex ...' message and exit status 1 apply -- and this
    # holds for the implicit-$0 form as well as an explicit target.
    result = run_goawk(
        'BEGIN { re = "["; s = "abc"; print "pre"; print gsub(re, "x", s) }'
    )
    assert result.returncode == 1
    assert text(result) == "pre\n"
    assert result.stderr.decode() == (
        'invalid regex "[": error parsing regexp: missing closing ]: `[)`\n'
    )


def test_gsub_invalid_regex_on_default_target_is_runtime_error():
    """gsub(re, repl) with a bad regex and the default $0 target errors."""
    # CATCHES: the 2-argument gsub form (target defaults to $0) also
    # validates the regex, with Go's (?s:...) wrapper shown in the error.
    result = run_goawk(
        'BEGIN { re = "("; $0 = "abc"; print gsub(re, "x") }'
    )
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'invalid regex "(": error parsing regexp: missing closing ): `(?s:()`\n'
    )
