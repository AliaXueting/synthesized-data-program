"""Tests for the CONVFMT and OFMT special variables.

CONVFMT governs number-to-string conversion in string context (such as
concatenation); OFMT governs how print formats numeric values.  Both
default to '%.6g', only apply to non-integer numbers, and are parsed
through the same machinery as sprintf formats.
"""

import pytest

from conftest import run_goawk, text


def test_default_formats_are_six_digit_g():
    """CONVFMT and OFMT both read back as '%.6g' by default."""
    # CATCHES: the default value of both special variables is exactly
    # '%.6g', and 1.23456789 renders as 1.23457 in both contexts.
    result = run_goawk('BEGIN { print CONVFMT, OFMT; print 1.23456789 "" }')
    assert result.returncode == 0
    assert text(result) == "%.6g %.6g\n1.23457\n"


@pytest.mark.parametrize(
    "convfmt,value,expected",
    [
        ('"%.3f"', "1.5", "1.500"),
        ('"%.2e"', "1234.5", "1.23e+03"),
        ('"%d"', "3.7", "3"),
        ('"%d"', "-3.7", "-3"),
        ('"%c"', "65.5", "A"),
        ('"%s"', "1.5", ""),
        ('"%.6q"', "1.5", "%.6q"),
        ('"abc"', "1.5", "abc"),
    ],
    ids=["fixed", "exponent", "int-conversion", "int-truncates",
         "char-conversion", "percent-s-empty", "invalid-literal",
         "no-conversion-literal"],
)
def test_convfmt_applies_to_string_conversion(convfmt, value, expected):
    """CONVFMT controls how a non-integer becomes a string via concat."""
    # CATCHES: '%d' truncates via sprintf (3.7 -> 3), '%c' encodes the
    # code point (65.5 -> A), '%s' yields the EMPTY string (gawk/mawk
    # recursion guard), and invalid/no-conversion formats are used as
    # literal text verbatim.
    result = run_goawk(
        'BEGIN { CONVFMT = %s; x = %s ""; print x }' % (convfmt, value)
    )
    assert result.returncode == 0
    assert text(result) == expected + "\n"


@pytest.mark.parametrize(
    "convfmt,value,expected",
    [
        ('"%.3f"', "2", "2"),
        ('"%.3f"', "4", "4"),
        ('"%d"', "7", "7"),
    ],
    ids=["integer-float-fmt", "integer-concat", "integer-int-fmt"],
)
def test_convfmt_ignores_integers(convfmt, value, expected):
    """Integer values convert to strings without applying CONVFMT."""
    # CATCHES: even with CONVFMT='%.3f' or '%d' the integer 2 stays '2'
    # and is never rendered as '2.000' or truncated.
    result = run_goawk(
        'BEGIN { CONVFMT = %s; x = %s ""; print x }' % (convfmt, value)
    )
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_convfmt_and_ofmt_are_independent():
    """CONVFMT affects concatenation while print still uses OFMT."""
    # CATCHES: setting CONVFMT='%.1f' changes 2.25 in a concat to 2.2 but
    # print of the same literal still uses OFMT ('%.6g' -> 2.25).
    result = run_goawk(
        'BEGIN { CONVFMT = "%.1f"; print 2.25 "", 2.25 }'
    )
    assert result.returncode == 0
    assert text(result) == "2.2 2.25\n"


@pytest.mark.parametrize(
    "ofmt,value,expected",
    [
        ('"%.2f"', "1.23456789", "1.23"),
        ('"%.2f"', "2", "2"),
        ('"%d"', "3.7", "3"),
        ('"%c"', "65.5", "A"),
    ],
    ids=["fixed", "integer-plain", "int-conversion", "char-conversion"],
)
def test_ofmt_applies_to_print(ofmt, value, expected):
    """OFMT controls how print renders non-integer numbers."""
    # CATCHES: print applies OFMT ('%.2f' -> 1.23, '%d' -> 3, '%c' -> A
    # for 65.5) while integers are printed plainly.
    result = run_goawk('BEGIN { OFMT = %s; print %s }' % (ofmt, value))
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_ofmt_percent_s_falls_back_to_convfmt():
    """An %s in OFMT converts the number using CONVFMT, not OFMT."""
    # CATCHES: with OFMT='%s' and CONVFMT='%.2f', print 1.5 gives 1.50 --
    # the %s recursion guard applies to CONVFMT only, so OFMT's %s defers
    # to the CONVFMT conversion.
    result = run_goawk(
        'BEGIN { OFMT = "%s"; CONVFMT = "%.2f"; print 1.5 }'
    )
    assert result.returncode == 0
    assert text(result) == "1.50\n"


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('sqrt(-1) ""', "nan"),
        ('exp(1000) ""', "inf"),
    ],
    ids=["nan", "inf"],
)
def test_nan_inf_bypass_convfmt(expr, expected):
    """NaN and infinity stringify without consulting CONVFMT."""
    # CATCHES: even with CONVFMT='%.3f' the special values print as the
    # literal 'nan' and 'inf' rather than being formatted.
    result = run_goawk(
        'BEGIN { CONVFMT = "%%.3f"; x = %s; print x }' % expr
    )
    assert result.returncode == 0
    assert text(result) == expected + "\n"
