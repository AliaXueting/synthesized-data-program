"""Tests for the split() builtin: separator semantics and array handling."""

import pytest

from conftest import run_goawk, text


@pytest.mark.parametrize(
    "s,expected",
    [
        ("a b  c", "3|a|b|c"),
        ("  a   b  ", "2|a|b"),
        ("a\tb c", "3|a|b|c"),
        ("", "0"),
        ("   ", "0"),
        ("one", "1|one"),
    ],
    ids=["runs", "stripped", "tabs-spaces", "empty", "blank", "single"],
)
def test_split_default_whitespace(s, expected):
    """split(s, a) with default FS splits on whitespace runs, stripping ends."""
    # CATCHES: leading/trailing whitespace must be stripped and runs of
    # whitespace must collapse to one separator, unlike a literal " " split.
    parts = expected.split("|")
    prog = 'BEGIN { n = split(@S@, a); printf "%d", n'
    for i in range(1, len(parts)):
        prog += '; printf "|%s", a[%d]' % ("%s", i)
    prog += '; print "" }'
    prog = prog.replace("@S@", '"%s"' % s)
    result = run_goawk(prog)
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_split_removes_existing_elements():
    """split() clears the target array before filling it, even sparse keys."""
    # CATCHES: a pre-existing a[5] must disappear after split(), so length(a)
    # is the new element count, not the union of old and new.
    result = run_goawk(
        'BEGIN { a[1]="old"; a[2]="old"; a[5]="old"; n = split("x y", a);'
        ' print n, length(a); for (i=1; i<=n; i++) printf "%s,", a[i]; print "" }'
    )
    assert result.returncode == 0
    assert text(result) == "2 2\nx,y,\n"


@pytest.mark.parametrize(
    "s,sep,expected",
    [
        ("a,b,,c", ",", "4|a|b||c"),
        ("axb", ".", "1|axb"),
        ("axxyc", "x+", "2|a|yc"),
        ("axyc", "xy", "2|a|c"),
        ("a.b.c", "[.]", "3|a|b|c"),
    ],
    ids=["literal-comma", "dot-is-literal", "multichar-is-regex",
         "literal-pair", "bracket-regex"],
)
def test_split_string_separator(s, sep, expected):
    """A 1-char string separator is literal; 2+ chars are used as a regex."""
    # CATCHES: split("axb", a, ".") must NOT split (single char = literal),
    # while "x+" and "[.]" must be treated as regular expressions.
    parts = expected.split("|")
    prog = 'BEGIN { n = split(@S@, a, @F@); printf "%d", n'
    for i in range(1, len(parts)):
        prog += '; printf "|%s", a[%d]' % ("%s", i)
    prog += '; print "" }'
    prog = prog.replace("@S@", '"%s"' % s).replace("@F@", '"%s"' % sep)
    result = run_goawk(prog)
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_split_regex_literal_separator():
    """A /re/ regex literal separator splits on the regex, not literally."""
    # CATCHES: split("axb", a, /./) splits on every character giving 4 empty
    # parts, proving the regex form differs from the "." string form.
    result = run_goawk(
        'BEGIN { n = split("axb", a, /./); printf "%d", n;'
        ' for (i=1; i<=n; i++) printf "[%s]", a[i]; print "" }'
    )
    assert result.returncode == 0
    assert text(result) == "4[][][][]\n"


def test_split_empty_separator_gives_characters():
    """split(s, a, "") splits the string into individual characters."""
    # CATCHES: an empty separator must yield one element per character (2 for
    # "éà", which is 4 bytes), and split("", a, "") yields zero elements.
    result = run_goawk(
        'BEGIN { n = split("éà", a, ""); print n, a[1], a[2];'
        ' m = split("", b, ""); print m, length(b) }'
    )
    assert result.returncode == 0
    assert text(result) == "2 é à\n0 0\n"


def test_split_explicit_space_separator():
    """split(s, a, " ") uses whitespace-run semantics like the default FS."""
    # CATCHES: an explicit " " separator must behave like default FS (strip
    # and collapse runs), NOT like a literal single space.
    result = run_goawk(
        'BEGIN { n = split("  a   b  ", a, " "); print n, a[1], a[2] }'
    )
    assert result.returncode == 0
    assert text(result) == "2 a b\n"


def test_split_uses_current_fs_value():
    """split(s, a) with no separator uses the live FS variable."""
    # CATCHES: changing FS between calls must change what split(s, a) splits
    # on: with FS=":" it splits on colon, then with FS="," it does not.
    result = run_goawk(
        'BEGIN { FS=":"; n = split("a:b:c", a); print n, a[2];'
        ' FS=","; m = split("a:b:c", b); print m, b[1] }'
    )
    assert result.returncode == 0
    assert text(result) == "3 b\n1 a:b:c\n"


def test_split_empty_string_returns_zero():
    """split("", a) returns 0 and leaves the array empty."""
    # CATCHES: an empty input string must give count 0 and an array with no
    # elements, regardless of the separator.
    result = run_goawk(
        'BEGIN { print split("", a), length(a), split("", b, ","), length(b) }'
    )
    assert result.returncode == 0
    assert text(result) == "0 0 0 0\n"


def test_split_array_usable_afterwards():
    """The array filled by split() supports in, indexing, and length()."""
    # CATCHES: elements must be stored with 1-based numeric string keys so
    # both (1 in arr) and ("1" in arr) are true after splitting.
    result = run_goawk(
        'BEGIN { n = split("a b c", arr); print n, length(arr),'
        ' (1 in arr), (4 in arr), ("1" in arr), arr[3] }'
    )
    assert result.returncode == 0
    assert text(result) == "3 3 1 0 1 c\n"


def test_split_into_local_array_in_function():
    """split() can target a local array parameter inside a user function."""
    # CATCHES: the array argument must resolve through the local frame so the
    # split fills the callee's array without touching the caller's globals.
    result = run_goawk(
        'function f(s,   a, n) { n = split(s, a, ","); return n " " a[2] }'
        'BEGIN { print f("a,b"), f("a,b,c") }'
    )
    assert result.returncode == 0
    assert text(result) == "2 b 3 b\n"


def test_split_honors_csv_input_mode_for_two_arg_form(tmp_path):
    """In CSV input mode, split(s, a) parses CSV; split(s, a, sep) does not."""
    # CATCHES: the 2-arg form must use the CSV parser (quoted field "y,z"
    # stays one element) while the 3-arg form ignores the input mode.
    progfile = tmp_path / "csvsplit.awk"
    progfile.write_text(
        'BEGIN {\n'
        '  n = split("x,\\"y,z\\"", a); print n, a[1], a[2]\n'
        '  m = split("x,y,z", b, ","); print m, b[1], b[2]\n'
        '}\n'
    )
    result = run_goawk(progfile=progfile, flags=["-i", "csv"], cwd=tmp_path)
    assert result.returncode == 0
    assert text(result) == "2 x y,z\n3 x y\n"


def test_split_invalid_multichar_regex_separator_is_error():
    """A multi-char string separator that is an invalid regex is an error."""
    # CATCHES: separators longer than one character are compiled as regexes
    # at runtime, so split(s, a, "x(") fails with 'invalid regex "x(": ...'
    # and exit status 1 before any output.
    result = run_goawk('BEGIN { n = split("abc", a, "x("); print n }')
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'invalid regex "x(": error parsing regexp: missing closing ): '
        '`(?s:x()`\n'
    )


def test_split_two_arg_uses_dashF_flag_separator():
    """The -F flag configures the FS used by the 2-argument split()."""
    # CATCHES: with -F ',' both the automatic field splitting and the
    # 2-arg split() see the same separator, so "a,b" yields two fields and
    # split() returns 2 -- the flag must feed the same FS the builtin reads.
    result = run_goawk(
        '{ print NF, $1, $2; print split($0, a) }',
        flags=["-F", ","],
        stdin="a,b\n",
    )
    assert result.returncode == 0
    assert text(result) == "2 a b\n2\n"


def test_begin_fs_assignment_overrides_dashF_for_split():
    """Assigning FS in BEGIN takes precedence over the -F flag."""
    # CATCHES: the program's own FS = ";" wins over the command-line -F ','
    # for the 2-arg split(), so "a,b" no longer splits and the count is 1
    # (the whole line as a single element).
    result = run_goawk(
        'BEGIN { FS = ";" } { n = split($0, a); print n, a[1], a[2] }',
        flags=["-F", ","],
        stdin="a,b\n",
    )
    assert result.returncode == 0
    assert text(result) == "1 a,b \n"
