"""Tests for the sprintf() builtin: return value, conversions, and errors."""

import pytest

from conftest import run_goawk, text


@pytest.mark.parametrize(
    "fmt,args,expected",
    [
        ("%d-%s", '42, "hi"', "42-hi"),
        ("%s=%d;%.2f", '"a", 1, 2.345', "a=1;2.35"),
        ("%i %u %o %x %X", "42, 42, 42, 255, 255", "42 42 52 ff FF"),
        ("%e %f", "1234.5, 2/3", "1.234500e+03 0.666667"),
        ("100%%", None, "100%"),
        ("just text", None, "just text"),
        ("[%-5d] [%05.1f]", "42, 3.14", "[42   ] [003.1]"),
        ("[%*d]", "5, 42", "[   42]"),
        ("[%d] [%d]", '"42abc", "abc"', "[42] [0]"),
        ("[%s] [%s]", "1.5, 1e20", "[1.5] [1e+20]"),
    ],
    ids=["basic", "multi", "int-bases", "exp-fixed", "percent",
         "no-conv", "width-flags", "star-width", "string-num", "num-string"],
)
def test_sprintf_return_value(fmt, args, expected):
    """sprintf() returns the fully formatted string (all conversion types)."""
    # CATCHES: the return value must be a plain formatted string: string args
    # to %d coerce numerically ("42abc"->42, "abc"->0) and numbers to %s use
    # the %.6g-style conversion (1e20 -> "1e+20"), and a format with no
    # conversions may be called with zero arguments.
    call = 'sprintf("%s")' % fmt if args is None else 'sprintf("%s", %s)' % (fmt, args)
    result = run_goawk('BEGIN { print %s }' % call)
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_sprintf_too_few_args_is_error():
    """More conversions than arguments is a runtime error (exit status 1)."""
    # CATCHES: the arg-count check must fire with the exact message including
    # both counts, after flushing already-printed output.
    result = run_goawk('BEGIN { print "first"; print sprintf("%d %d", 42) }')
    assert result.returncode == 1
    assert text(result) == "first\n"
    assert result.stderr.decode() == "format error: got 1 args, expected 2\n"


def test_sprintf_extra_args_ignored():
    """Fewer conversions than arguments is fine; extras are ignored."""
    # CATCHES: only a shortfall is an error; surplus arguments must not be
    # appended or rejected.
    result = run_goawk('BEGIN { print sprintf("%d", 42, 43, 44) }')
    assert result.returncode == 0
    assert text(result) == "42\n"


@pytest.mark.parametrize(
    "fmt,message",
    [
        ("abc%", "format error: expected type specifier after %\n"),
        ("%-5", "format error: expected type specifier after %\n"),
        ("%y 1", "format error: invalid format type 'y'\n"),
    ],
    ids=["trailing-percent", "flags-then-eof", "bad-type"],
)
def test_sprintf_bad_format_is_error(fmt, message):
    """A malformed format string aborts with a format error on stderr."""
    # CATCHES: a bare trailing % and a flag run that runs into end-of-string
    # both yield 'expected type specifier after %', and an unknown conversion
    # letter names it -- all with exit status 1 and empty stdout.
    prog = "BEGIN { print sprintf(\"%s\") }" % fmt
    result = run_goawk(prog)
    assert result.returncode == 1
    assert text(result) == ""
    assert result.stderr.decode() == message


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], b"\xbb\n"),
        (["-c"], "λ\n".encode("utf-8")),
    ],
    ids=["bytes", "chars"],
)
def test_sprintf_percent_c_chars_mode(flags, expected):
    """%c of a code point over 255: raw low byte, or UTF-8 under -c."""
    # CATCHES: sprintf("%c", 955) in byte mode emits the single raw byte
    # 0xBB (955 truncated to a byte), while -c UTF-8-encodes the whole code
    # point as the two-byte "λ".
    result = run_goawk('BEGIN { print sprintf("%c", 955) }', flags=flags)
    assert result.returncode == 0
    assert result.stdout == expected


@pytest.mark.parametrize(
    "flags",
    [[], ["-c"]],
    ids=["bytes", "chars"],
)
def test_sprintf_percent_c_string_and_ascii_agree_across_modes(flags):
    """%c of a string takes its first char; ASCII code points match both modes."""
    # CATCHES: string arguments yield their first character ("h" from
    # "héllo") and code point 65 yields "A" identically in byte and chars
    # mode -- only non-ASCII code points differ between the modes.
    result = run_goawk(
        'BEGIN { print sprintf("[%c] [%c]", "héllo", 65) }',
        flags=flags,
    )
    assert result.returncode == 0
    assert text(result) == "[h] [A]\n"


def test_sprintf_percent_c_number_codes_mode():
    """Under -c, %c of a number encodes the Unicode code point."""
    # CATCHES: byte mode would emit byte(955); chars mode must UTF-8 encode
    # code point 955 as the two-byte λ sequence.
    result = run_goawk(
        'BEGIN { s = sprintf("%c", 955); print s, length(s) }',
        flags=["-c"],
    )
    assert result.returncode == 0
    assert text(result) == "λ 1\n"


def test_sprintf_percent_c_empty_string_is_nul():
    """%c of an empty string yields a single NUL byte."""
    # CATCHES: GoAWK maps the empty string to a 0 byte rather than erroring,
    # so the result has length 1.
    result = run_goawk('BEGIN { s = sprintf("%c", ""); print length(s) }')
    assert result.returncode == 0
    assert text(result) == "1\n"


def test_sprintf_bare_percent_g_matches_posix():
    """A bare %g uses C's 6 significant digits, not Go's shortest form."""
    # CATCHES: Go's fmt %g would print 1e+10 for 10000000000, but GoAWK
    # injects ".6" so %g matches POSIX awk's six significant digits.
    result = run_goawk('BEGIN { print sprintf("%g|%g|%g", 1e10, 0.5, 2) }')
    assert result.returncode == 0
    assert text(result) == "1e+10|0.5|2\n"


@pytest.mark.parametrize(
    "fmt,arg,expected",
    [
        ("%a", "1.0", "0x1p+00"),
        ("%A", "255.0", "0X1.FEP+07"),
        ("%12a", "1.0", "     0x1p+00"),
    ],
    ids=["lowercase", "uppercase", "padded"],
)
def test_sprintf_hex_float_conversions(fmt, arg, expected):
    """%a and %A format arguments as hexadecimal floating point."""
    # CATCHES: GoAWK maps %a/%A onto Go's %x/%X float verbs, giving
    # lower-case '0x1p+00' for %a and upper-case '0X1.FEP+07' for %A, and
    # field widths still pad the converted value.
    result = run_goawk('BEGIN { print sprintf("%s", %s) }' % (fmt, arg))
    assert result.returncode == 0
    assert text(result) == expected + "\n"


@pytest.mark.parametrize(
    "fmt,args,message",
    [
        ("%y", "1", "format error: invalid format type 'y'\n"),
        ("%d %d", "1", "format error: got 1 args, expected 2\n"),
    ],
    ids=["bad-type", "too-few-args"],
)
def test_printf_statement_format_errors(fmt, args, message):
    """The printf STATEMENT aborts on the same format errors as sprintf()."""
    # CATCHES: printf formats at output time, so a bad conversion letter or
    # a missing argument is a fatal runtime error carrying the identical
    # message sprintf() would produce, after flushing earlier output.
    result = run_goawk(
        'BEGIN { print "pre"; printf "%s", %s }' % (fmt, args)
    )
    assert result.returncode == 1
    assert text(result) == "pre\n"
    assert result.stderr.decode() == message
