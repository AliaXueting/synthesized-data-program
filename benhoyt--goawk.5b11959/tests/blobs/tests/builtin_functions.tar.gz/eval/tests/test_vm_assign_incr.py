"""Tests for ++/-- and the augmented assignment operators.

These pin the Incr* and AugAssign* opcode families of interp/vm.go across
every lvalue kind: fields, global/local scalars, global/local array
elements and special variables -- including their error paths and the
value-producing (expression context) forms.
"""

import pytest

from conftest import run_goawk, text


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('BEGIN { $0 = "5 7"; $1++; $2--; print $0, $1, $2 }', "6 6 6 6"),
        ('BEGIN { $0 = "a b"; $3++; print $0, NF, $3 }', "a b 1 3 1"),
        ('BEGIN { $0 = "a b"; $0++; print $0 }', "1"),
    ],
    ids=["existing-fields", "creates-field", "field-zero"],
)
def test_increment_fields(prog, expected):
    """++/-- on a field rewrites the field and rebuilds $0."""
    # CATCHES: incrementing a missing field creates it (value 1, NF rises),
    # incrementing $0 replaces the whole record, and every change is
    # reflected in the rebuilt $0.
    assert text(run_goawk(prog)) == expected + "\n"


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('function f() { n = 5; n++; m = 5; m--; print n, m }'
         ' BEGIN { f() }', "6 4"),
        ('BEGIN { a["k"] = 5; a["k"]++; print a["k"] }', "6"),
        ('function f(a) { a["k"] = 5; a["k"]++; print a["k"] }'
         ' BEGIN { f(b); print b["k"] }', "6\n6"),
    ],
    ids=["local-scalar", "global-array", "local-array"],
)
def test_increment_scalars_and_arrays(prog, expected):
    """++ works on local scalars and on global and local array elements."""
    # CATCHES: a local array element increments the CALLER's array through
    # the array reference, so the new value is visible after the call.
    assert text(run_goawk(prog)) == expected + "\n"


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('BEGIN { RSTART = 5; RSTART++; RLENGTH = 3; RLENGTH--;'
         ' print RSTART, RLENGTH }', "6 2"),
        ('{ NR++; print NR, FNR }', "2 1\n4 2"),
        ('{ FNR += 10; print FNR }', "11\n22"),
        ('BEGIN { RSTART = 3; RSTART ^= 2; print RSTART }', "9"),
        ('BEGIN { RSTART = 3; RSTART += 4; print RSTART;'
         ' RLENGTH = 10; RLENGTH /= 4; print RLENGTH }', "7\n2.5"),
    ],
    ids=["rstart-rlength", "nr-in-rule", "fnr-augassign", "power",
         "add-then-div"],
)
def test_increment_and_augassign_special_vars(prog, expected):
    """++/-- and op= assign through to special variables like normal ones."""
    # CATCHES: special variables are real lvalues: RSTART++ writes back 6,
    # NR++ inside a rule doubles every record number, and RLENGTH /= 4
    # yields 2.5 -- a VM that treats specials as read-only would break.
    result = run_goawk(prog, stdin="a\nb\n")
    assert text(result) == expected + "\n"


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('BEGIN { x = 10; x += 5; x -= 3; x *= 2; x /= 4; x ^= 2;'
         ' x %= 4; print x }', "0"),
        ('function f() { x = 10; x += 5; x -= 3; x *= 2; x /= 4;'
         ' print x } BEGIN { f() }', "6"),
        ('function f() { x = 7; x %= 4; print x } BEGIN { f() }', "3"),
    ],
    ids=["all-ops-global", "all-ops-local", "mod-local"],
)
def test_augassign_scalars(prog, expected):
    """All six op= operators work on globals and on function locals."""
    # CATCHES: the ops apply right-to-left onto the variable in sequence
    # (10+5-3*2/4^2%4 == 0) and locals are independent of same-named
    # globals.
    assert text(run_goawk(prog)) == expected + "\n"


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('BEGIN { $0 = "10 6"; $1 += 5; $2 *= 3; print $0 }', "15 18"),
        ('BEGIN { $0 = "10"; $1 /= 4; print $0 }', "2.5"),
    ],
    ids=["add-mul", "divide"],
)
def test_augassign_fields(prog, expected):
    """op= on a field converts, applies the operator and rebuilds $0."""
    # CATCHES: $1 /= 4 turns "10" into the string "2.5" in the rebuilt
    # record, not the integer 2.
    assert text(run_goawk(prog)) == expected + "\n"


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('BEGIN { a["k"] = 10; a["k"] += 5; a["k"] *= 2; a["k"] ^= 2;'
         ' print a["k"] }', "900"),
        ('function f(a) { a["k"] = 7; a["k"] -= 2; a["k"] *= 3;'
         ' print a["k"] } BEGIN { f(b); print b["k"] }', "15\n15"),
    ],
    ids=["global-array", "local-array"],
)
def test_augassign_array_elements(prog, expected):
    """op= on array elements works for global and local (parameter) arrays."""
    # CATCHES: a local array parameter writes through to the caller's
    # array, so both prints show 15.
    assert text(run_goawk(prog)) == expected + "\n"


@pytest.mark.parametrize(
    "prog,message",
    [
        ('BEGIN { x = 1; x /= 0 }', "division by zero"),
        ('BEGIN { x = 1; x %= 0 }', "division by zero in mod"),
        ('function f() { x = 1; x /= 0 } BEGIN { f() }',
         "division by zero"),
        ('function f(a) { a["k"] = 1; a["k"] %= 0 } BEGIN { f(b) }',
         "division by zero in mod"),
        ('BEGIN { print 1 / 0 }', "division by zero"),
        ('BEGIN { print 7 % 0 }', "division by zero in mod"),
    ],
    ids=["global-div", "global-mod", "local-div", "local-array-mod",
         "expr-div", "expr-mod"],
)
def test_zero_division_errors(prog, message):
    """Dividing or taking modulo by zero is fatal, from any lvalue kind."""
    # CATCHES: the aug-assign forms (/= and %=) raise the very same error
    # messages as the binary operators, for globals, locals and array
    # elements alike, always with exit status 1.
    result = run_goawk(prog)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == message + "\n"


@pytest.mark.parametrize(
    "prog",
    [
        'BEGIN { $1000001 = "x" }',
        'BEGIN { $1000001++ }',
        'BEGIN { $1000001 += 1 }',
        'BEGIN { sub(/^/, "y", $1000001) }',
    ],
    ids=["assign", "increment", "augassign", "sub-target"],
)
def test_field_index_too_large_is_error(prog):
    """Field indices above the limit are rejected for every write form."""
    # CATCHES: 1000001 exceeds the maximum field index (1000000), and the
    # guard fires for plain assignment, ++, += and even a sub() target
    # whose regex matched the empty string.
    result = run_goawk(prog)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == "field index too large: 1000001\n"


def test_negative_field_index_counts_from_end():
    """Assigning $-1 addresses the last field of the record."""
    # CATCHES: negative field indices are translated relative to NF, so
    # $-1 = "Z" replaces the third field of "a b c".
    result = run_goawk('BEGIN { $0 = "a b c"; $-1 = "Z"; print $0 }')
    assert text(result) == "a b Z\n"


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('BEGIN { b["x"] = 1; print ("x" in b), ("y" in b) }', "1 0"),
        ('function f(a, k) { return (k in a) }'
         ' BEGIN { b["x"] = 1; print f(b, "x"), f(b, "y") }', "1 0"),
    ],
    ids=["global", "local-parameter"],
)
def test_in_expression_does_not_create_elements(prog, expected):
    """'k in a' tests membership without creating the element."""
    # CATCHES: 'in' against a local array parameter works like a global,
    # and a missing key yields 0 without inserting it into the array.
    assert text(run_goawk(prog)) == expected + "\n"


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("(x += 5)", "15\n15\n"),
        ("(x *= 3)", "30\n30\n"),
        ("(x -= 2)", "8\n8\n"),
    ],
    ids=["add", "multiply", "subtract"],
)
def test_augassign_yields_the_new_value(expr, expected):
    """An op= used as an expression evaluates to the updated variable."""
    # CATCHES: print (x += 5) prints 15 (the assigned value) AND the
    # variable afterwards holds 15 -- the expression form must both
    # assign and produce the result.
    result = run_goawk('BEGIN { x = 10; print %s; print x }' % expr)
    assert text(result) == expected


def test_augassign_in_condition():
    """An op= inside an if() condition is evaluated before the test."""
    # CATCHES: the assignment happens first (x becomes 3) and THEN the
    # comparison uses that new value, so 'big' and x==3 both print.
    result = run_goawk(
        'BEGIN { x = 1; if ((x *= 3) > 2) print "big", x }'
    )
    assert text(result) == "big 3\n"


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('($1 = "hello")', "hello"),
        ('(a[1] = "hi")', "hi"),
    ],
    ids=["field", "array-element"],
)
def test_assignment_expression_yields_assigned_value(expr, expected):
    """An assignment used as an expression produces the assigned value."""
    # CATCHES: print ($1 = "hello") both assigns $1 and prints "hello";
    # for arrays the element is stored and readable afterwards.
    result = run_goawk('BEGIN { print %s }' % expr)
    assert text(result) == expected + "\n"


def test_array_assignment_expression_is_stored():
    """The value produced by an array assignment expression is stored."""
    # CATCHES: (a[1] = "hi") must really write a[1], not just yield the
    # value on the stack.
    result = run_goawk('BEGIN { print (a[1] = "hi"); print a[1] }')
    assert text(result) == "hi\nhi\n"


def test_post_and_pre_increment_values():
    """i++ yields the old value, ++i the new one, and both store."""
    # CATCHES: post-increment returns 5 while incrementing to 6, and
    # pre-increment returns 7 after incrementing 6 to 7.
    result = run_goawk(
        'BEGIN { i = 5; print i++, i; print ++i, i }'
    )
    assert text(result) == "5 6\n7 7\n"
