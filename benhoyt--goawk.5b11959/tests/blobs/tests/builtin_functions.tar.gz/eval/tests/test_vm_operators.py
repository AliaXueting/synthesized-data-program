"""Tests for the VM's arithmetic, comparison and matching operators.

These pin the binary/unary operator opcodes of interp/vm.go: subtraction,
division, modulo, power, unary plus, logical not, the string-vs-number
comparison rules, the ~ and !~ matching operators and a stand-alone
/regex/ used as an expression.
"""

import pytest

from conftest import run_goawk, text


def run_one(expr):
    """Evaluate a single expression in BEGIN and return its printed text."""
    return text(run_goawk('BEGIN { print %s }' % expr)).rstrip("\n")


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("7 - 2", "5"),
        ("7 - 2.5", "4.5"),
        ('"7" - 2', "5"),
        ("2.5 - 7", "-4.5"),
        ('"" - 1', "-1"),
        ('"abc" - 1', "-1"),
    ],
    ids=["ints", "fraction", "string-coerce", "negative", "empty-string",
         "garbage-string"],
)
def test_subtraction_operator(expr, expected):
    """The binary '-' operator coerces strings to numbers before subtracting."""
    # CATCHES: subtraction coerces non-numeric strings ("" and "abc") to 0
    # rather than erroring or string-concatenating.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("7 / 2", "3.5"),
        ("1 / 3", "0.333333"),
        ("-7 / 2", "-3.5"),
        ('"9" / 3', "3"),
        ('"10" / 4', "2.5"),
    ],
    ids=["exact", "repeating", "negative", "string-num", "string-frac"],
)
def test_division_operator(expr, expected):
    """The '/' operator does true floating-point division with coercion."""
    # CATCHES: division is not integer division (7/2 is 3.5) and repeating
    # results print through the %.6g default number format (1/3 -> 0.333333).
    assert run_one(expr) == expected


def test_division_by_zero_is_runtime_error():
    """x / 0 aborts the program with 'division by zero' and exit status 1."""
    # CATCHES: division by zero is a hard runtime error (not inf/nan), the
    # message is exactly 'division by zero', and output printed before the
    # error is still flushed to stdout.
    result = run_goawk('BEGIN { print "before"; print 1 / 0 }')
    assert result.returncode == 1
    assert text(result) == "before\n"
    assert result.stderr.decode() == "division by zero\n"


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("7 % 3", "1"),
        ("-7 % 3", "-1"),
        ("7 % -3", "1"),
        ("-7 % -3", "-1"),
        ("7.5 % 2", "1.5"),
        ("0 % 5", "0"),
        ("5 % 5", "0"),
        ('"7" % 3', "1"),
    ],
    ids=["positive", "neg-left", "neg-right", "both-neg", "fractional",
         "zero-left", "exact", "string-coerce"],
)
def test_modulo_operator(expr, expected):
    """'%' follows Go's math.Mod: the result takes the LEFT operand's sign."""
    # CATCHES: -7 % 3 is -1 (sign of the dividend, like C's fmod and GoAWK,
    # not Python's floor-mod which would give 2).
    assert run_one(expr) == expected


def test_modulo_by_zero_is_runtime_error():
    """x % 0 aborts with 'division by zero in mod' and exit status 1."""
    # CATCHES: modulo by zero has its own error text, distinct from the
    # division-by-zero message, and is a fatal error at status 1.
    result = run_goawk('BEGIN { print "before"; print 7 % 0 }')
    assert result.returncode == 1
    assert text(result) == "before\n"
    assert result.stderr.decode() == "division by zero in mod\n"


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("2 ^ 10", "1024"),
        ("2 ** 10", "1024"),
        ("9 ^ 0.5", "3"),
        ("2 ^ -2", "0.25"),
        ("(-2) ^ 2", "4"),
        ("0 ^ 0", "1"),
    ],
    ids=["caret", "double-star", "square-root", "negative-exponent",
         "negative-base", "zero-zero"],
)
def test_power_operator(expr, expected):
    """Both '^' and '**' exponentiate, including fractional exponents."""
    # CATCHES: ** is accepted as an alias of ^, 9^0.5 is exactly 3, and
    # 0^0 evaluates to 1 (math.Pow semantics) rather than an error.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('+"3.5" + 1', "4.5"),
        ('+"12abc"', "12"),
        ('+""', "0"),
        ('+"abc"', "0"),
        ("+7", "7"),
    ],
    ids=["coerce-add", "numeric-prefix", "empty", "garbage", "number"],
)
def test_unary_plus_coerces_to_number(expr, expected):
    """Unary '+' forces its operand to its numeric value."""
    # CATCHES: unary plus is a real coercion ("12abc" -> 12), not a no-op,
    # and non-numeric strings coerce to 0 instead of staying strings.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("!0", "1"),
        ("!1", "0"),
        ('!""', "1"),
        ('!"abc"', "0"),
        ("!(2 > 3)", "1"),
        ("!0.5", "0"),
    ],
    ids=["zero", "one", "empty-string", "nonempty-string", "expression",
         "fraction"],
)
def test_logical_not_operator(expr, expected):
    """'!' maps truthiness (nonzero number or nonempty string) to 0/1."""
    # CATCHES: the empty string is falsy and any nonempty string is truthy
    # for '!', and the result is always exactly 0 or 1.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('("a" != "b")', "1"),
        ('("a" != "a")', "0"),
        ('("10" != "9")', "1"),
        ('("a" != "a ")', "1"),
    ],
    ids=["different", "identical", "numeric-strings", "trailing-space"],
)
def test_string_inequality(expr, expected):
    """!= between string operands compares them as strings."""
    # CATCHES: string comparison is exact and byte-wise, so "10" != "9" is
    # true even though 10 != 9 numerically, and trailing blanks matter.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('("10" < "9")', "1"),
        ('("a" < "b")', "1"),
        ('("abc" < "abd")', "1"),
        ('("b" <= "a")', "0"),
        ('("a" <= "a")', "1"),
        ('("b" > "a")', "1"),
        ('("9" > "10")', "1"),
        ('("Z" > "a")', "0"),
        ('("a" >= "b")', "0"),
        ('("a" >= "a")', "1"),
        ('("9" >= "10")', "1"),
    ],
    ids=["numeric-strings-lt", "alpha-lt", "prefix-lt", "alpha-le-false",
         "alpha-le-equal", "alpha-gt", "numeric-strings-gt", "case-order",
         "alpha-ge-false", "alpha-ge-equal", "numeric-strings-ge"],
)
def test_string_ordering_comparisons(expr, expected):
    """Relational operators on two strings use byte-wise string order."""
    # CATCHES: "10" < "9" is TRUE because both operands are strings ("1"
    # sorts before "9") while 10 < 9 is false numerically -- the string
    # branch of every relational operator is what gets pinned here.
    assert run_one(expr) == expected


def test_numeric_ordering_comparisons():
    """Relational operators on two numbers compare numerically."""
    # CATCHES: with numeric (not string) operands the same operators use
    # arithmetic order, the mirror image of the string-mode results.
    assert run_one("(10 < 9), (9 < 10), (2 <= 2), (3 >= 4), (5 > 4)") == (
        "0 1 1 0 1"
    )


def test_comparison_mode_depends_on_string_value():
    """A string-typed operand forces string comparison of the whole expr."""
    # CATCHES: when one side holds the string "10" and the other the number
    # 9, comparison is string-wise ("10" < "9" -> true), so the decision of
    # string-vs-number mode is per-operation, not per-program.
    result = run_goawk('BEGIN { a = "10"; b = 9; print (a < b), (a > b) }')
    assert text(result) == "1 0\n"


def test_string_number_equality_is_string_comparison():
    """A string from a variable never equals a numerically-equal number."""
    # CATCHES: a "strnum"-style variable holding "1.0" does NOT compare
    # equal to the number 1 (unlike gawk's strnum rules) -- comparisons
    # involving a string value are always lexical.
    result = run_goawk('BEGIN { a = "1.0"; print (a == 1), ("1.0" == 1) }')
    assert text(result) == "0 0\n"


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('("abc" ~ /b/)', "1"),
        ('("abc" ~ /x/)', "0"),
        ('("abc" ~ "")', "1"),
        ('("abbbc" ~ r)', "1"),
        ('("abc" !~ /b/)', "0"),
        ('("abc" !~ /x/)', "1"),
        ('("abc" !~ "")', "0"),
    ],
    ids=["match", "no-match", "empty-regex-match", "dynamic-regex",
         "not-match-hit", "not-match-miss", "not-match-empty"],
)
def test_match_and_not_match_operators(expr, expected):
    """~ and !~ test regex membership and return exactly 0 or 1."""
    # CATCHES: the empty regex matches every string (including via !~,
    # where it yields 0), and a regex held in a variable works the same as
    # a literal one.
    result = run_goawk('BEGIN { r = "b+"; print %s }' % expr)
    assert text(result) == expected + "\n"


@pytest.mark.parametrize(
    "regex,op",
    [("[", "~"), ("(", "!~")],
    ids=["match", "not-match"],
)
def test_match_with_invalid_dynamic_regex_is_error(regex, op):
    """An invalid regex string in a ~ / !~ operand is a fatal runtime error."""
    # CATCHES: the regex is compiled at evaluation time, so a malformed
    # pattern aborts with exit status 1 carrying Go's regexp error text,
    # including the (?s:...) wrapper GoAWK adds to dynamic regexes.
    result = run_goawk(
        'BEGIN { print "before"; r = "%s"; print "x" %s r }' % (regex, op)
    )
    assert result.returncode == 1
    assert text(result) == "before\n"
    if op == "~":
        assert result.stderr.decode() == (
            'invalid regex "[": error parsing regexp: missing closing ]: `[)`\n'
        )
    else:
        assert result.stderr.decode() == (
            'invalid regex "(": error parsing regexp: '
            'missing closing ): `(?s:()`\n'
        )


def test_match_operator_against_record_and_fields():
    """~ applies to $0 and $1 with the usual field splitting."""
    # CATCHES: matching against a field uses only that field's text, while
    # matching $0 uses the full record with its separators.
    result = run_goawk(
        '{ print ($0 ~ /o/), ($1 ~ /^[0-9]+$/) }',
        stdin="one 2\n",
    )
    assert text(result) == "1 0\n"


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('{ if (/wor/) print "has-wor" }', "has-wor\n"),
        ('{ n = /o/; print n }', "1\n1\n"),
        ('{ if (!/zzz/) print "no-zzz" }', "no-zzz\nno-zzz\n"),
    ],
    ids=["in-if", "as-value", "negated"],
)
def test_standalone_regex_tests_record(prog, expected):
    """A bare /regex/ expression means '$0 ~ /regex/'."""
    # CATCHES: a stand-alone regex literal matches against the current
    # record (not $1), evaluates to 1/0, and can be negated with '!'.
    result = run_goawk(prog, stdin="world\nhello\n")
    assert text(result) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('"a" "b" "c" "d" 1 2 3', "abcd123"),
        ('"x" sprintf("<%s>", "y") "z"', "x<y>z"),
    ],
    ids=["literal-chain", "with-call"],
)
def test_concatenation_chain(expr, expected):
    """A chain of 3+ concatenation operands joins left to right."""
    # CATCHES: long concat chains are flattened into one operation and
    # numbers concatenate using their string form (1 2 3 -> "123").
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "cond,expected",
    [
        ('"a" < "b"', "lt-yes"),
        ('"10" == "10"', "eq-yes"),
        ('"x" != "y"', "ne-yes"),
        ('"b" > "a"', "gt-yes"),
        ('"a" <= "a"', "le-yes"),
        ('"b" >= "a"', "ge-yes"),
        ('3 < 5', "lt-yes"),
        ('3 == 3', "eq-yes"),
        ('3 != 4', "ne-yes"),
        ('3 > 2', "gt-yes"),
        ('3 <= 3', "le-yes"),
        ('3 >= 3', "ge-yes"),
    ],
    ids=["lt-str", "eq-str", "ne-str", "gt-str", "le-str", "ge-str",
         "lt-num", "eq-num", "ne-num", "gt-num", "le-num", "ge-num"],
)
def test_if_condition_comparisons(cond, expected):
    """Every comparison operator works directly as an if() condition."""
    # CATCHES: conditions support all six comparison operators for both
    # string and numeric operands; a wrong fused-comparison implementation
    # would flip one of these branches.
    result = run_goawk(
        'BEGIN { if (%s) print "%s"; else print "no" }' % (cond, expected)
    )
    assert text(result) == expected + "\n"


def test_if_else_false_branches():
    """Failing conditions fall through to the else branch."""
    # CATCHES: the jump targets must be right for both the taken and the
    # not-taken path of ==, != and <.
    result = run_goawk(
        'BEGIN { i = 9;'
        ' if (i < 5) print "lt"; else print "no-lt";'
        ' if (i == 3) print "eq"; else print "no-eq";'
        ' if (i != 4) print "ne"; else print "no-ne" }'
    )
    assert text(result) == "no-lt\nno-eq\nne\n"


@pytest.mark.parametrize(
    "loop,expected",
    [
        ('i = 0; while (i < 3) { print "i", i; i++ }',
         "i 0\ni 1\ni 2\n"),
        ('for (i = 0; i <= 2; i++) print "f", i', "f 0\nf 1\nf 2\n"),
    ],
    ids=["while", "for"],
)
def test_loops_with_fused_conditions(loop, expected):
    """while and for conditions use the comparison operators directly."""
    # CATCHES: loop conditions with < and <= terminate at exactly the right
    # iteration -- off-by-one bound handling would change the line count.
    result = run_goawk('BEGIN { %s }' % loop)
    assert text(result) == expected


def test_ternary_condition_comparison():
    """A comparison used as a ternary condition picks the right arm."""
    # CATCHES: the >= fused comparison drives the ternary branch, yielding
    # 'ge' rather than 'lt' for i == 1.
    result = run_goawk('BEGIN { i = 1; print (i >= 1) ? "ge" : "lt" }')
    assert text(result) == "ge\n"
