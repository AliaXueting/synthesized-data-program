"""Tests for the tolower() and toupper() builtins."""

import pytest

from conftest import run_goawk, text


@pytest.mark.parametrize(
    "func,argument,expected",
    [
        ("tolower", '"AbC-D1_ x"', "abc-d1_ x"),
        ("tolower", '"already lower"', "already lower"),
        ("tolower", '"ÉÀÜ"', "éàü"),
        ("tolower", '"ΛΩΩκ"', "λωωκ"),
        ("tolower", '"Z9Y_!~"', "z9y_!~"),
        ("toupper", '"AbC-D1_ x"', "ABC-D1_ X"),
        ("toupper", '"ALREADY"', "ALREADY"),
        ("toupper", '"éàü"', "ÉÀÜ"),
        ("toupper", '"αβγδ"', "ΑΒΓΔ"),
        ("toupper", '"a1b_!~"', "A1B_!~"),
    ],
    ids=["lower-mixed", "lower-identity", "lower-latin-accents",
         "lower-greek", "lower-non-letters", "upper-mixed", "upper-identity",
         "upper-latin-accents", "upper-greek", "upper-non-letters"],
)
def test_case_conversion(func, argument, expected):
    """tolower/toupper convert case and leave non-letters alone."""
    # CATCHES: conversion is full Unicode (É -> é, α -> Α), not ASCII-only,
    # and digits/punctuation pass through unchanged.
    result = run_goawk('BEGIN { print %s(%s) }' % (func, argument))
    assert result.returncode == 0
    assert text(result) == expected + "\n"


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('tolower(42)', "42"),
        ('toupper(3.5)', "3.5"),
        ('tolower("")', ""),
        ('toupper("")', ""),
    ],
    ids=["number", "float", "empty-lower", "empty-upper"],
)
def test_case_conversion_coerces_arguments(expr, expected):
    """Numbers convert to their string form; empty strings stay empty."""
    # CATCHES: tolower(42) is the string "42" (number-to-string coercion
    # happens before casing) and the empty string is returned as-is.
    result = run_goawk('BEGIN { x = %s; print "[" x "]" }' % expr)
    assert result.returncode == 0
    assert text(result) == "[%s]\n" % expected


def test_case_functions_usable_inside_expressions():
    """tolower() results compose with other builtins like index()."""
    # CATCHES: the return value is a real string value usable inline:
    # index(tolower("A-B"), "a") is 1, proving eager conversion.
    result = run_goawk('BEGIN { s = "A-B"; print index(tolower(s), "a") }')
    assert result.returncode == 0
    assert text(result) == "1\n"
