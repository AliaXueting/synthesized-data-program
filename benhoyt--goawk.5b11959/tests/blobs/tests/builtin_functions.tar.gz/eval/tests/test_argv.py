"""Tests for the ARGV array and ARGC special variable.

File-based tests create their data files inside tmp_path and run the
interpreter with cwd=tmp_path so only relative names are used.
"""

import os

import pytest

from conftest import run_goawk, text


@pytest.fixture
def two_files(tmp_path):
    """Create f1.txt (two lines) and f2.txt (one line) in tmp_path."""
    (tmp_path / "f1.txt").write_text("one\ntwo\n")
    (tmp_path / "f2.txt").write_text("THREE\n")
    return tmp_path


def test_argv0_is_basename_of_executable():
    """ARGV[0] is the basename of the invoked executable path."""
    # CATCHES: ARGV[0] is not a fixed string like 'goawk'; it mirrors the
    # basename of however the binary was invoked by the test harness.
    result = run_goawk('BEGIN { print ARGV[0] }')
    assert result.returncode == 0
    assert text(result) == os.path.basename(os.environ.get(
        "PROGRAMGYM_EXECUTABLE", os.path.abspath("executable"))) + "\n"


def test_argc_counts_arguments_plus_one():
    """ARGC is the number of operands plus one (for ARGV[0])."""
    # CATCHES: with operands 'a' and 'b', ARGC is 3 and ARGV[1]/ARGV[2]
    # hold the operands while ARGV[3] is absent (empty string).
    result = run_goawk(
        'BEGIN { print ARGC; print ARGV[1], ARGV[2], ARGV[3] }',
        args=["a", "b"],
    )
    assert result.returncode == 0
    assert text(result) == "3\na b \n"


def test_argv_iteration_over_all_indexes():
    """ARGV[0..ARGC-1] iterates the program name then the operands."""
    # CATCHES: the ARGV array indexes line up with ARGC, so a 0-based
    # loop yields the executable basename followed by each operand.
    result = run_goawk(
        'BEGIN { for (i = 0; i < ARGC; i++) print i, ARGV[i] }',
        args=["p", "q"],
    )
    assert result.returncode == 0
    exe = os.path.basename(os.environ.get(
        "PROGRAMGYM_EXECUTABLE", os.path.abspath("executable")))
    assert text(result) == "0 %s\n1 p\n2 q\n" % exe


def test_argv_length_equals_argc_minus_one():
    """length(ARGV) counts the elements, including ARGV[0]."""
    # CATCHES: with no operands length(ARGV) is 1 (just ARGV[0]); with
    # two operands it is 3.
    no_args = run_goawk('BEGIN { print length(ARGV) }')
    with_args = run_goawk('BEGIN { print length(ARGV) }', args=["a", "b"])
    assert text(no_args) == "1\n"
    assert text(with_args) == "3\n"


def test_argv_assignment_ignored_while_argc_is_one(two_files):
    """ARGV[1]=\"file\" alone is inert while ARGC is still 1: stdin is read."""
    # CATCHES: merely assigning ARGV[1] does not make the interpreter read
    # that file -- with ARGC still 1 the operand is skipped and records come
    # from stdin instead, so f1.txt's lines never appear in the output.
    result = run_goawk(
        'BEGIN { ARGV[1] = "f1.txt"; print "begin" } { print "rec:" $0 }',
        stdin="STDIN\n",
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "begin\nrec:STDIN\n"


def test_argv_assignment_with_argc_reads_file(two_files):
    """ARGV[1]=\"file\" with ARGC=2 reads the file from BEGIN."""
    # CATCHES: raising ARGC to 2 activates the assigned ARGV[1] operand,
    # so the records of f1.txt are processed.
    result = run_goawk(
        'BEGIN { ARGV[1] = "f1.txt"; ARGC = 2 } { print }',
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "one\ntwo\n"


def test_argv_assignment_appends_after_existing_files(two_files):
    """ARGV[2]=\"f2.txt\" with ARGC=3 appends a file after the operands."""
    # CATCHES: an assigned high-index ARGV slot is processed in position
    # order after the command-line operand f1.txt.
    result = run_goawk(
        'BEGIN { ARGV[2] = "f2.txt"; ARGC = 3 } { print }',
        args=["f1.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "one\ntwo\nTHREE\n"


def test_argv_overwrite_replaces_operand(two_files):
    """Assigning ARGV[1] replaces the operand that was there."""
    # CATCHES: the main loop reads the CURRENT value of each ARGV slot,
    # so replacing slot 1 with f2.txt skips f1.txt entirely.
    result = run_goawk(
        'BEGIN { ARGV[1] = "f2.txt" } { print }',
        args=["f1.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "THREE\n"


def test_delete_argv_element_skips_that_file(two_files):
    """delete ARGV[1] removes the operand from the processing loop."""
    # CATCHES: deleting an ARGV element makes the loop skip that position
    # (f1.txt) and continue with the next (f2.txt).
    result = run_goawk(
        'BEGIN { delete ARGV[1] } { print }',
        args=["f1.txt", "f2.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "THREE\n"


def test_argc_truncation_stops_after_nth_file(two_files):
    """ARGC=2 limits processing to ARGV[1] only."""
    # CATCHES: lowering ARGC in BEGIN truncates the operand list, so
    # f2.txt is never opened.
    result = run_goawk(
        'BEGIN { ARGC = 2 } { print }',
        args=["f1.txt", "f2.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "one\ntwo\n"


def test_argc_one_falls_back_to_stdin(two_files):
    """ARGC=1 removes all operands, so records come from stdin."""
    # CATCHES: with ARGC forced to 1 no file operand is processed and the
    # interpreter reads stdin instead, even though f1.txt was passed.
    result = run_goawk(
        'BEGIN { ARGC = 1 } { print }',
        args=["f1.txt"],
        stdin="STDIN\n",
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "STDIN\n"


def test_argc_assignment_mid_loop_takes_effect(two_files):
    """Lowering ARGC from a rule stops later operands from being read."""
    # CATCHES: after the first record is processed, ARGC=2 means the loop
    # stops before f2.txt even though it was originally an operand.
    result = run_goawk(
        'NR==1 { ARGC = 2 } { print }',
        args=["f1.txt", "f2.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "one\ntwo\n"


def test_argv_assignment_mid_loop_takes_effect_at_position(two_files):
    """Assigning ARGV[2] while processing ARGV[1] adds the next file."""
    # CATCHES: when record 1 is read, ARGV[2] is assigned f2.txt and
    # ARGC raised, so after f1.txt finishes the loop reads f2.txt.
    result = run_goawk(
        'NR==1 { ARGV[2] = "f2.txt"; ARGC = 3 } { print }',
        args=["f1.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "one\ntwo\nTHREE\n"


def test_argv_assignment_to_slot_zero_is_not_read(two_files):
    """ARGV[0] can be assigned but is never treated as a filename."""
    # CATCHES: the operand loop starts at index 1, so overwriting ARGV[0]
    # with a filename neither reads that file nor breaks anything: the
    # assignment is visible when reading ARGV[0] back, and records still
    # come from stdin.
    result = run_goawk(
        'BEGIN { ARGV[0] = "f1.txt"; print "argv0:" ARGV[0] }'
        ' { print "rec:" $0 }',
        stdin="STDIN\n",
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "argv0:f1.txt\nrec:STDIN\n"


def test_var_assignment_operand_sets_variable(two_files):
    """An operand of the form name=value assigns the variable."""
    # CATCHES: the operand 'x=5' is treated as an assignment (visible in
    # END after operand processing) rather than as a filename.
    result = run_goawk('END { print x }', args=["x=5"], cwd=two_files)
    assert result.returncode == 0
    assert text(result) == "5\n"


def test_var_assignment_then_file_operands(two_files):
    """A name=value operand assigns before later file operands are read."""
    # CATCHES: processing order is left to right: x=5 takes effect, then
    # f1.txt is read with x already set for every record.
    result = run_goawk(
        '{ print x, $0 }',
        args=["x=5", "f1.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "5 one\n5 two\n"


def test_filename_and_fnr_track_current_file(two_files):
    """FILENAME follows the operand being read and FNR resets per file."""
    # CATCHES: FILENAME echoes the operand string (relative name as
    # passed), NR counts across files while FNR restarts at each file.
    result = run_goawk(
        '{ print FILENAME, NR, FNR }',
        args=["f1.txt", "f2.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == (
        "f1.txt 1 1\nf1.txt 2 2\nf2.txt 3 1\n"
    )


def test_argc_assignment_coerces_string_to_number(two_files):
    """ARGC = \"2\" stores the numeric 2 (truncating the file list)."""
    # CATCHES: special variables hold numbers, so a string assignment is
    # coerced and the truncated operand list still reads f1.txt only.
    result = run_goawk(
        'BEGIN { ARGC = "2" } { print }',
        args=["f1.txt", "f2.txt"],
        cwd=two_files,
    )
    assert result.returncode == 0
    assert text(result) == "one\ntwo\n"
