"""Disassembly (-da flag) of programs that use the special variables.

The internal special-variable table (internal/ast/specialvars.go) is only
observable through the ``-da`` flag, which prints the compiled program's
disassembly and exits without running it.  Every opcode that touches a
special variable prints the variable's canonical name, so these tests pin
the exact name spellings and opcode formats for all 17 special variables.
"""

import pytest

from conftest import run_goawk, text


SPECIAL_VARS = [
    "ARGC", "CONVFMT", "FILENAME", "FNR", "FS", "INPUTMODE", "NF", "NR",
    "OFMT", "OFS", "ORS", "OUTPUTMODE", "RLENGTH", "RS", "RSTART", "RT",
    "SUBSEP",
]


def disasm(prog):
    """Run the -da disassembler and return its stdout text."""
    return text(run_goawk(prog, flags=["-da"]))


@pytest.mark.parametrize("name", SPECIAL_VARS)
def test_da_reading_special_var_emits_special_opcode(name):
    """Reading a special variable compiles to a 'Special <NAME>' opcode."""
    # CATCHES: each of the 17 special variables must be recognised by name
    # and compile to the 'Special' opcode naming it; a re-implementation
    # with a different name table (or a plain global) would disassemble
    # differently.
    assert disasm('BEGIN { print %s }' % name) == (
        "        // BEGIN\n"
        "0000    Special %s\n"
        "0002    Print 1\n"
        "\n" % name
    )


@pytest.mark.parametrize("name", SPECIAL_VARS)
def test_da_assigning_special_var_emits_assignspecial_opcode(name):
    """Assigning a special variable compiles to 'AssignSpecial <NAME>'."""
    # CATCHES: assignment to each special variable must compile to the
    # AssignSpecial opcode with the canonical name, proving the whole
    # special-variable name table round-trips through the compiler.
    assert disasm('BEGIN { %s = 1 }' % name) == (
        "        // BEGIN\n"
        "0000    Num 1 (0)\n"
        "0002    AssignSpecial %s\n"
        "\n" % name
    )


def test_da_read_all_special_vars_in_one_program():
    """All 17 special variables read in one program disassemble in order."""
    # CATCHES: the opcode stream must load each special variable in
    # left-to-right source order and the final Print must report the
    # argument count (17), pinning the stack layout of a 17-value print.
    prog = "BEGIN { print %s }" % ", ".join(SPECIAL_VARS)
    lines = ["        // BEGIN"]
    addr = 0
    for name in SPECIAL_VARS:
        lines.append("%04x    Special %s" % (addr, name))
        addr += 2
    lines.append("%04x    Print 17" % addr)
    assert disasm(prog) == "\n".join(lines) + "\n\n"


def test_da_incr_special_pre_and_post():
    """++ and -- on special variables compile to IncrSpecial with amount."""
    # CATCHES: both NR++ (post) and ++FNR (pre) compile to the same
    # IncrSpecial opcode with amount 1 when the value is unused, and
    # decrements carry amount -1 -- the disassembler prints the amount
    # before the variable name.
    assert disasm("BEGIN { NR++; ++FNR; NR--; --NF }") == (
        "        // BEGIN\n"
        "0000    IncrSpecial 1 NR\n"
        "0003    IncrSpecial 1 FNR\n"
        "0006    IncrSpecial -1 NR\n"
        "0009    IncrSpecial -1 NF\n"
        "\n"
    )


def test_da_augassign_special_format_string_quirk():
    """AugAssignSpecial disassembly prints the name via a %d verb (Go quirk)."""
    # CATCHES: the reference disassembler formats AugAssignSpecial with a
    # %d verb for the variable NAME, so Go renders it as
    # '%!d(string=NR)'; the operation name (AugOpAdd/AugOpMul/AugOpMod)
    # precedes it.  This exact garbled output is observable CLI behavior.
    assert disasm("BEGIN { NR += 2; FS *= 3; SUBSEP %= 2 }") == (
        "        // BEGIN\n"
        "0000    Num 2 (0)\n"
        "0002    AugAssignSpecial AugOpAdd %!d(string=NR)\n"
        "0005    Num 3 (1)\n"
        "0007    AugAssignSpecial AugOpMul %!d(string=FS)\n"
        "000a    Num 2 (0)\n"
        "000c    AugAssignSpecial AugOpMod %!d(string=SUBSEP)\n"
        "\n"
    )


def test_da_getline_into_special_var():
    """'getline VAR' compiles to GetlineSpecial with the redirect token."""
    # CATCHES: reading a line into a special variable uses the
    # GetlineSpecial opcode; with no redirection the redirect operand
    # prints as '<illegal>' (the zero Token), and with '< \"file\"' it
    # prints the '<' token followed by the variable name.
    assert disasm('BEGIN { getline RS }') == (
        "        // BEGIN\n"
        "0000    GetlineSpecial <illegal> RS\n"
        "0003    Drop\n"
        "\n"
    )
    assert disasm('BEGIN { getline NR < "f.txt" }') == (
        "        // BEGIN\n"
        "0000    Str \"f.txt\" (0)\n"
        "0002    GetlineSpecial < NR\n"
        "0005    Drop\n"
        "\n"
    )


def test_da_does_not_execute_the_program():
    """-da prints the disassembly to stdout and exits 0 without running."""
    # CATCHES: the program body must NOT be executed under -da -- no
    # 'EXECUTED' output appears, only the compiled Str/Print opcodes.
    result = run_goawk('BEGIN { print "EXECUTED" }', flags=["-da"])
    assert result.returncode == 0
    assert result.stderr == b""
    assert text(result) == (
        '        // BEGIN\n'
        '0000    Str "EXECUTED" (0)\n'
        '0002    Print 1\n'
        '\n'
    )


def test_da_sections_in_source_order():
    """Main and END sections are labelled and disassembled in order."""
    # CATCHES: the disassembly lists the main section as '// { body }' and
    # the END section as '// END' (a BEGIN-less program), each followed by
    # a blank separator line.
    assert disasm('END { print NR }  { print FNR }') == (
        "        // { body }\n"
        "0000    Special FNR\n"
        "0002    Print 1\n"
        "\n"
        "        // END\n"
        "0000    Special NR\n"
        "0002    Print 1\n"
        "\n"
    )


def test_da_parse_error_goes_to_stderr_with_caret():
    """A program that fails to parse errors out instead of disassembling."""
    # CATCHES: -da with a broken program reports the parse error on stderr
    # with '<line>:<col>: message', a blank line, and a caret line, and
    # exits with status 1.
    result = run_goawk("BEGIN {", flags=["-da"])
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == ":0:1: expected } instead of EOF\n\n^\n"
