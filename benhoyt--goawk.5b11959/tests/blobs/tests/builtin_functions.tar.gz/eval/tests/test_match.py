"""Tests for the match() builtin and the RSTART/RLENGTH special variables."""

import pytest

from conftest import run_goawk, text


@pytest.mark.parametrize(
    "s,regex,expected",
    [
        ("banana", "/an/", "2 2 2"),
        ("hello", "/xyz/", "0 0 -1"),
        ("abc", "//", "1 1 0"),
        ("hello world", "/o/", "5 5 1"),
        ("aXbXc", "/X[^X]*/", "2 2 2"),
    ],
    ids=["first-match", "no-match", "empty-regex", "late-match", "longest"],
)
def test_match_sets_and_returns_rstart(s, regex, expected):
    """match(s, re) returns RSTART and sets RSTART (1-based) and RLENGTH."""
    # CATCHES: RSTART must be 1-based with RLENGTH the match length, and a
    # failed match must leave RSTART=0 / RLENGTH=-1 (not 0/0).
    prog = 'BEGIN { m = match("%s", %s); print m, RSTART, RLENGTH }' % (s, regex)
    result = run_goawk(prog)
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_match_rlength_is_longest_match():
    """RLENGTH covers the full (leftmost-longest) match, not one character."""
    # CATCHES: GoAWK uses leftmost-longest matching, so match("aaa", /a*/)
    # must give RLENGTH 3, not the 1 that a leftmost-shortest engine would.
    result = run_goawk('BEGIN { match("aaa", /a*/); print RSTART, RLENGTH }')
    assert result.returncode == 0
    assert text(result) == "1 3\n"


def test_match_no_match_resets_previous_values():
    """A failed match overwrites previously successful RSTART/RLENGTH values."""
    # CATCHES: match() must reset RSTART to 0 and RLENGTH to -1 even if an
    # earlier successful match had left other values there.
    result = run_goawk(
        'BEGIN { match("abc", /b/); print RSTART, RLENGTH;'
        ' match("abc", /z/); print RSTART, RLENGTH }'
    )
    assert result.returncode == 0
    assert text(result) == "2 1\n0 -1\n"


def test_rstart_rlength_are_ordinary_variables():
    """RSTART and RLENGTH are readable, writable, and re-set by match()."""
    # CATCHES: they must behave like normal variables when assigned, and
    # match() must overwrite the assigned values.
    result = run_goawk(
        'BEGIN { RSTART = 99; RLENGTH = 42; print RSTART, RLENGTH;'
        ' m = match("hello", /l/); print m, RSTART, RLENGTH }'
    )
    assert result.returncode == 0
    assert text(result) == "99 42\n3 3 1\n"


def test_match_defaults_before_any_match():
    """Before any match() call, RSTART is 0 and RLENGTH is 0."""
    # CATCHES: the initial RLENGTH is 0, not -1; only a failed match() sets -1.
    result = run_goawk("BEGIN { print RSTART, RLENGTH }")
    assert result.returncode == 0
    assert text(result) == "0 0\n"


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], "7 7 3\n"),
        (["-c"], "4 4 1\n"),
    ],
    ids=["bytes", "chars"],
)
def test_match_chars_mode(flags, expected):
    """-c makes match/RSTART/RLENGTH count characters, not bytes."""
    # CATCHES: for "aé日本b" the 本 match starts at byte 7 but character 4,
    # and RLENGTH is 3 bytes vs 1 character.
    result = run_goawk(
        'BEGIN { s = "aé日本b"; print match(s, /本/), RSTART, RLENGTH }',
        flags=flags,
    )
    assert result.returncode == 0
    assert text(result) == expected


def test_match_regex_from_string_variable():
    """match() accepts a regex held in a string variable, not just /re/."""
    # CATCHES: the first argument handling must compile a dynamic regex
    # string and still set RSTART/RLENGTH.
    result = run_goawk(
        'BEGIN { re = "l+"; print match("hello", re), RSTART, RLENGTH }'
    )
    assert result.returncode == 0
    assert text(result) == "3 3 2\n"


def test_match_invalid_regex_literal_is_parse_error():
    """An invalid /re/ literal fails at parse time with position and caret."""
    # CATCHES: regex literals are validated before execution, so nothing runs
    # (stdout stays empty) and the error names the position of the regex.
    result = run_goawk(
        'BEGIN { print "before"; print match("abc", /[a/) }'
    )
    assert result.returncode == 1
    assert text(result) == ""
    assert result.stderr.decode() == (
        "<cmdline>:1:44: error parsing regexp: missing closing ]: `[a)`\n"
        'BEGIN { print "before"; print match("abc", /[a/) }\n'
        "                                           ^\n"
    )


def test_match_invalid_regex_string_is_runtime_error():
    """An invalid regex held in a string fails at runtime, flushing stdout."""
    # CATCHES: dynamic regexes are compiled when match() runs, so output
    # produced before the failing call is flushed, then the process exits 1.
    result = run_goawk(
        'BEGIN { re = "[a"; print "before"; print match("abc", re) }'
    )
    assert result.returncode == 1
    assert text(result) == "before\n"
    assert result.stderr.decode() == (
        'invalid regex "[a": error parsing regexp: missing closing ]: `[a)`\n'
    )
