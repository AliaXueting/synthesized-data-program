"""Tests for the ENVIRON array (a copy of the process environment).

Tests pin the child environment exactly (or replace it wholesale) so the
observed ENVIRON contents are deterministic even though the test harness
may add variables such as GOCOVERDIR.
"""

import pytest

from conftest import run_goawk, text


def test_environ_maps_real_environment_variable():
    """ENVIRON[\"FOO\"] reads the value of the FOO environment variable."""
    # CATCHES: environment variables present in the child process appear
    # in ENVIRON with their exact value.
    result = run_goawk('BEGIN { print ENVIRON["FOO"] }', env={"FOO": "bar"})
    assert result.returncode == 0
    assert text(result) == "bar\n"


def test_environ_missing_key_is_empty_string():
    """A variable that is not set yields the empty string, not an error."""
    # CATCHES: referencing an absent ENVIRON key returns "" (the null
    # value), so comparing it to the empty string is true.
    result = run_goawk(
        'BEGIN { print ENVIRON["PGSYNTH_UNSET"] == "" }',
        replace_env=True,
    )
    assert result.returncode == 0
    assert text(result) == "1\n"


def test_environ_membership_with_pinned_env():
    """'in' reports exactly which keys exist in ENVIRON."""
    # CATCHES: ENVIRON is a real array supporting 'in'; with a fully
    # replaced environment only FOO and BAZ are present, PGSYNTH_NOPE is
    # not.
    result = run_goawk(
        'BEGIN { print ("FOO" in ENVIRON), ("BAZ" in ENVIRON),'
        ' ("PGSYNTH_NOPE" in ENVIRON) }',
        env={"FOO": "bar", "BAZ": "qux"},
        replace_env=True,
    )
    assert result.returncode == 0
    assert text(result) == "1 1 0\n"


def test_environ_value_may_contain_equals():
    """Only the first '=' separates key from value in an env var."""
    # CATCHES: for FOO=a=b the whole 'a=b' is the value; the remainder is
    # not dropped or re-split.
    result = run_goawk(
        'BEGIN { print ENVIRON["FOO"] }',
        env={"FOO": "a=b"},
        replace_env=True,
    )
    assert result.returncode == 0
    assert text(result) == "a=b\n"


def test_environ_iteration_yields_keys():
    """Iterating ENVIRON visits every key of the pinned environment."""
    # CATCHES: 'for (k in ENVIRON)' walks the real array contents, seeing
    # both A and B exactly once (other harness variables are filtered
    # out, keeping the count deterministic).
    result = run_goawk(
        'BEGIN { n = 0; for (k in ENVIRON) { if (k == "A" || k == "B") n++ }'
        ' print n }',
        env={"A": "1", "B": "2"},
        replace_env=True,
    )
    assert result.returncode == 0
    assert text(result) == "2\n"


def test_environ_assignment_visible_only_inside():
    """Assigning ENVIRON[k] updates the array but not the real environment."""
    # CATCHES: after ENVIRON["NEW"] = "xyz" the key exists inside awk,
    # but a system() child still sees the variable as unset, proving
    # ENVIRON is a snapshot copy rather than a live view.
    result = run_goawk(
        'BEGIN { ENVIRON["NEW"] = "xyz";'
        ' print ("NEW" in ENVIRON), ENVIRON["NEW"];'
        ' print system("printf %s ${NEW-unset}") }',
        env={"FOO": "bar"},
        replace_env=True,
    )
    assert result.returncode == 0
    assert text(result) == "1 xyz\nunset0\n"
