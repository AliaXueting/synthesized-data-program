"""Tests for the index() builtin: 1-based positions and -c character mode."""

import pytest

from conftest import run_goawk, text


@pytest.mark.parametrize(
    "s,t,expected",
    [
        ("hello", "l", 3),
        ("hello", "ll", 3),
        ("hello", "z", 0),
        ("abc", "", 1),
        ("abc", "abc", 1),
        ("abc", "abcd", 0),
        ("", "a", 0),
        ("", "", 1),
        ("banana", "na", 3),
    ],
    ids=["first-l", "double-l", "absent", "empty-needle", "whole",
         "needle-longer", "empty-hay", "both-empty", "inside"],
)
def test_index_positions(s, t, expected):
    """index(s, t) is 1-based and returns 0 when t does not occur in s."""
    # CATCHES: an off-by-one (0-based) implementation or a -1 "not found"
    # sentinel would break these exact positions.
    prog = 'BEGIN { print index("%s", "%s") }' % (s, t)
    result = run_goawk(prog)
    assert result.returncode == 0
    assert text(result) == "%d\n" % expected


def test_index_first_occurrence_only():
    """index finds the FIRST occurrence, not the last or a later one."""
    # CATCHES: using a last-index-of search would report 4 instead of 2 for
    # the "X" separators in "aXbXc".
    result = run_goawk('BEGIN { print index("aXbXc", "X") }')
    assert result.returncode == 0
    assert text(result) == "2\n"


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], "4 2\n"),
        (["-c"], "3 2\n"),
    ],
    ids=["bytes", "chars"],
)
def test_index_chars_mode(flags, expected):
    """-c makes index report character positions for multibyte strings."""
    # CATCHES: with "aébc" the byte offset of "b" is 4 but the character
    # offset is 3; without -c the é counts as 2 bytes.
    result = run_goawk(
        'BEGIN { s = "aébc"; print index(s, "b"), index(s, "é") }',
        flags=flags,
    )
    assert result.returncode == 0
    assert text(result) == expected


def test_index_result_is_usable_in_expressions():
    """index() returns a number usable in arithmetic and comparisons."""
    # CATCHES: the return value must be a real numeric value, not a string
    # that only prints correctly.
    result = run_goawk(
        'BEGIN { i = index("hello", "l"); print i + 10, (i > 2), (i == 3), i * 2 }'
    )
    assert result.returncode == 0
    assert text(result) == "13 1 1 6\n"
