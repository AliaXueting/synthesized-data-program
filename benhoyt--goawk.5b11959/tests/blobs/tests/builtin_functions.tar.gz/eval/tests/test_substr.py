"""Tests for the substr() builtin: clamping rules and -c character mode."""

import pytest

from conftest import run_goawk, text


@pytest.mark.parametrize(
    "s,pos,expected",
    [
        ("hello world", 7, "world"),
        ("hello", 3, "llo"),
        ("hello", 0, "hello"),
        ("hello", -2, "hello"),
        ("hello", 5, "o"),
        ("hello", 6, ""),
        ("hello", 10, ""),
    ],
    ids=["mid", "tail", "zero", "negative", "last-char", "at-end-plus1", "far-out"],
)
def test_substr_two_arg_clamping(s, pos, expected):
    """substr(s, m) clamps m<=0 to 1 and returns "" when m exceeds len(s)."""
    # CATCHES: substr("hello", 0) must yield the whole string (not "" or "o"),
    # and any start past the end must yield the empty string.
    prog = 'BEGIN { print "[" substr("%s", %d) "]" }' % (s, pos)
    result = run_goawk(prog)
    assert result.returncode == 0
    assert text(result) == "[%s]\n" % expected


@pytest.mark.parametrize(
    "pos,length,expected",
    [
        (2, 3, "ell"),
        (2, 99, "ello"),
        (2, 0, ""),
        (2, -1, ""),
        (1, 5, "hello"),
        (4, 3, "lo"),
        (10, 3, ""),
        (1, 0, ""),
    ],
    ids=["mid", "length-clamped", "zero-length", "negative-length",
         "exact", "short-tail", "pos-past-end", "zero-from-start"],
)
def test_substr_three_arg_clamping(pos, length, expected):
    """substr(s, m, n) clamps n<0 to 0 and n past the end to the remainder."""
    # CATCHES: negative length must give "" (not the whole tail), and a start
    # beyond the string end gives "" even with a large length.
    prog = 'BEGIN { print "[" substr("hello", %d, %d) "]" }' % (pos, length)
    result = run_goawk(prog)
    assert result.returncode == 0
    assert text(result) == "[%s]\n" % expected


def test_substr_position_and_length_coerce_from_strings():
    """substr() converts non-integer position/length arguments numerically."""
    # CATCHES: string arguments like "2" must coerce to numbers; "abc" coerce
    # to 0 which clamps to start 1.
    result = run_goawk(
        'BEGIN { print "[" substr("hello", "2", "2") "]",'
        ' "[" substr("hello", "abc", 2) "]" }'
    )
    assert result.returncode == 0
    assert text(result) == "[el] [he]\n"


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], "éllo\n"),
        (["-c"], "éllo\n"),
    ],
    ids=["bytes", "chars"],
)
def test_substr_multibyte_two_arg(flags, expected):
    """substr(s, 2) on "héllo": byte 2 happens to be the start of é."""
    # CATCHES: é starts at byte 2, so byte mode (skip 1 byte) and char mode
    # (skip the "h") both return "éllo" -- but for different reasons; the
    # byte variant must slice raw bytes, not decode runes.
    result = run_goawk('BEGIN { print substr("héllo", 2) }', flags=flags)
    assert result.returncode == 0
    assert text(result) == expected


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], "é"),
        (["-c"], "él"),
    ],
    ids=["bytes", "chars"],
)
def test_substr_multibyte_length_unit(flags, expected):
    """substr(s, 2, 2) counts bytes by default and characters under -c."""
    # CATCHES: the length unit must switch with -c: bytes gives just "é"
    # (its two bytes) while chars gives "él" (two whole characters).
    result = run_goawk('BEGIN { s = "héllo"; print substr(s, 2, 2) }', flags=flags)
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_substr_chars_mode_clamping():
    """-c mode substr clamps out-of-range start/length like byte mode does."""
    # CATCHES: in chars mode pos<=0 clamps to 1, pos past end gives "", and
    # negative length gives "" -- all measured in characters.
    result = run_goawk(
        'BEGIN { s = "héllo"; print "[" substr(s, 0) "]" ;'
        ' print "[" substr(s, -3) "]"; print "[" substr(s, 99) "]";'
        ' print "[" substr(s, 2, -1) "]"; print "[" substr(s, 2, 99) "]";'
        ' print "[" substr(s, 3, 2) "]" }',
        flags=["-c"],
    )
    assert result.returncode == 0
    assert text(result) == (
        "[héllo]\n"
        "[héllo]\n"
        "[]\n"
        "[]\n"
        "[éllo]\n"
        "[ll]\n"
    )


def test_substr_bytes_mode_slices_raw_bytes():
    """Byte mode substr can split multibyte characters, yielding invalid UTF-8."""
    # CATCHES: substr must slice raw bytes without validating UTF-8, so
    # substr("日本語", 2) starts mid-character; a rune-aware implementation
    # would return "本語" instead of the invalid 4-byte prefix.
    s = "日本語".encode("utf-8")
    result = run_goawk(
        'BEGIN { s = "日本語"; printf "%s|%s|%s\\n", substr(s, 2),'
        ' substr(s, 1, 3), substr(s, 4) }'
    )
    assert result.returncode == 0
    assert result.stdout == s[1:] + b"|" + s[0:3] + b"|" + s[3:] + b"\n"


def test_substr_chars_mode_cjk():
    """-c mode substr works on CJK characters: 1 char == 1 unit."""
    # CATCHES: each of 日/本/語 is 3 bytes; only -c mode can extract "本語"
    # with substr(s, 2) and "本" with substr(s, 2, 1).
    result = run_goawk(
        'BEGIN { s = "日本語"; print substr(s, 2), "|", substr(s, 1, 1),'
        ' "|", substr(s, 2, 1), "|", substr(s, 4), "|", substr(s, 3, 5) }',
        flags=["-c"],
    )
    assert result.returncode == 0
    assert text(result) == "本語 | 日 | 本 |  | 語\n"


def test_substr_with_rstart_rlength_idiom():
    """The classic match()+substr(RSTART, RLENGTH) idiom extracts the match."""
    # CATCHES: RSTART/RLENGTH must be set by match() and be directly usable
    # as substr() arguments (1-based start, match length).
    result = run_goawk(
        'BEGIN { s = "aXbXc"; if (match(s, /X[^X]*/)) print substr(s, RSTART, RLENGTH) }'
    )
    assert result.returncode == 0
    assert text(result) == "Xb\n"


@pytest.mark.parametrize(
    "pos,length,expected",
    [
        (2, 100, "éllo"),
        (-3, 100, "héllo"),
    ],
    ids=["long-length-clamps", "negative-position-clamps"],
)
def test_substr_chars_mode_clamps_to_string_bounds(pos, length, expected):
    """Under -c, over-long lengths and negative positions clamp to bounds."""
    # CATCHES: in characters mode substr("héllo", 2, 100) returns the whole
    # 4-character tail and a negative start clamps to 1 giving all five
    # characters, mirroring the byte-mode clamping rules.
    result = run_goawk(
        'BEGIN { print "[" substr("héllo", %d, %d) "]" }' % (pos, length),
        flags=["-c"],
    )
    assert result.returncode == 0
    assert text(result) == "[%s]\n" % expected


@pytest.mark.parametrize(
    "pos,length",
    [
        (10, 2),
        (6, 3),
    ],
    ids=["far-past-end", "one-past-end"],
)
def test_substr_chars_mode_position_past_end_with_length(pos, length):
    """Under -c, a start beyond the string end gives "" even with a length."""
    # CATCHES: the three-argument form must treat a character position past
    # the end as empty (the start clamps to the very end of the string),
    # matching the two-argument behaviour instead of wrapping around or
    # returning the last character.
    result = run_goawk(
        'BEGIN { print "[" substr("héllo", %d, %d) "]" }' % (pos, length),
        flags=["-c"],
    )
    assert result.returncode == 0
    assert text(result) == "[]\n"
