"""Tests for special-variable behavior: SUBSEP, NF, FS, INPUTMODE/OUTPUTMODE."""

import pytest

from conftest import run_goawk, text


def test_subsep_default_is_single_unit_separator():
    """SUBSEP defaults to the single byte 0x1c (unit separator)."""
    # CATCHES: the default SUBSEP is one byte long and joins subscripts
    # at position 2 of '1<SUBSEP>2' (a 3-byte key), pinning the exact
    # default value \\x1c.
    result = run_goawk(
        'BEGIN { s = 1 SUBSEP 2; print length(s);'
        ' print index(s, "\\x1c") }'
    )
    assert result.returncode == 0
    assert text(result) == "3\n2\n"


def test_subsep_joins_multi_dimensional_subscripts():
    """a[1,2] is keyed by '1\\x1c2', so 'in' sees the joined key."""
    # CATCHES: multi-dim subscripts concatenate with SUBSEP between them,
    # so ("1" SUBSEP "2") in a is true while the plain "12" key is not.
    result = run_goawk(
        'BEGIN { a[1, 2] = 9;'
        ' print ("1" SUBSEP "2") in a, ("12") in a }'
    )
    assert result.returncode == 0
    assert text(result) == "1 0\n"


def test_subsep_joins_three_subscripts():
    """Three subscripts join with two SUBSEP separators."""
    # CATCHES: a[x,y,z] builds 'x<SUBSEP>y<SUBSEP>z', verified with an
    # explicit 'in' lookup of the hand-built key.
    result = run_goawk(
        'BEGIN { a["x", "y", "z"] = 1;'
        ' print (("x" SUBSEP "y" SUBSEP "z") in a) }'
    )
    assert result.returncode == 0
    assert text(result) == "1\n"


def test_subsep_assignment_changes_the_join():
    """Assigning SUBSEP='-' re-keys subsequent multi-dim subscripts."""
    # CATCHES: after SUBSEP='-' the element a[\"x\",\"y\"] lives under the
    # key 'x-y' and the old \\x1c-joined key no longer exists.
    result = run_goawk(
        'BEGIN { SUBSEP = "-"; a["x", "y"] = 1;'
        ' print ("x-y" in a), (("x" "\\x1c" "y") in a) }'
    )
    assert result.returncode == 0
    assert text(result) == "1 0\n"


def test_subsep_value_readable_after_assignment():
    """SUBSEP reads back as an ordinary string variable."""
    # CATCHES: SUBSEP is assignable and readable like any variable; a
    # two-character value has length 2.
    result = run_goawk('BEGIN { SUBSEP = "!!"; print length(SUBSEP) }')
    assert result.returncode == 0
    assert text(result) == "2\n"


def test_subsep_joins_non_integer_subscript_as_number_string():
    """A numeric subscript like 1.5 joins via its %.6g string form."""
    # CATCHES: non-integer subscript keys convert through the usual
    # number-to-string rules, so a[1.5, 2] is keyed '1.5\\x1c2'.
    result = run_goawk(
        'BEGIN { a[1.5, 2] = 1; k = ""; for (key in a) k = key;'
        ' print k == "1.5" SUBSEP "2" }'
    )
    assert result.returncode == 0
    assert text(result) == "1\n"


@pytest.mark.parametrize(
    "prog,expected",
    [
        ('BEGIN { $0 = "a b"; NF = 3; print NF; print "[" $3 "]"; print $0 }',
         "3\n[]\na b \n"),
        ('BEGIN { $0 = "a b c"; NF = 1; print NF, $0 }', "1 a\n"),
        ('BEGIN { $0 = "a b"; NF = 0; print NF, "[" $0 "]" }', "0 []\n"),
    ],
    ids=["pad", "shrink", "zero"],
)
def test_nf_assignment_rebuilds_record(prog, expected):
    """Assigning NF pads with empty fields or drops trailing fields."""
    # CATCHES: NF=3 on 'a b' appends an empty third field and rebuilds
    # $0 as 'a b ' (trailing OFS), NF=1 keeps only 'a', and NF=0 empties
    # the record entirely.
    result = run_goawk(prog)
    assert result.returncode == 0
    assert text(result) == expected


def test_nf_assignment_pads_with_ofs():
    """Field padding joins with the current OFS, not a space."""
    # CATCHES: with OFS='-' the rebuilt record after NF=4 is 'a-b--',
    # proving joinFields honors the OFS special variable.
    result = run_goawk(
        'BEGIN { OFS = "-"; $0 = "a b"; NF = 4; print $0 }'
    )
    assert result.returncode == 0
    assert text(result) == "a-b--\n"


def test_nf_negative_assignment_is_error():
    """NF = -1 aborts with the exact 'NF set to negative value' message."""
    # CATCHES: negative NF is rejected at runtime with status 1 and the
    # message 'NF set to negative value: -1'.
    result = run_goawk('BEGIN { NF = -1 }')
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == "NF set to negative value: -1\n"


def test_argc_too_large_is_error():
    """ARGC = 2000000000 aborts with 'ARGC set too large'."""
    # CATCHES: there is an upper bound on ARGC; exceeding it is a runtime
    # error with the offending value echoed in the message.
    result = run_goawk('BEGIN { ARGC = 2000000000 }')
    assert result.returncode == 1
    assert result.stderr.decode() == "ARGC set too large: 2000000000\n"


@pytest.mark.parametrize(
    "fs,line,expected",
    [
        ("(", "a(b", "2 a b"),
        ("z", "azb", "2 a b"),
        ("[0-9]", "a1b", "2 a b"),
    ],
    ids=["regex-metachar-literal", "plain-literal", "bracket-regex"],
)
def test_fs_single_char_literal_multichar_regex(fs, line, expected):
    """A 1-char FS splits literally (even '(' ); longer FS is a regex."""
    # CATCHES: FS='(' does NOT error or act as a regex -- single
    # character separators are literal -- while '[0-9]' (2+ chars) is
    # compiled as a regular expression.
    result = run_goawk(
        'BEGIN { FS = "%s" } { print NF, $1, $2 }' % fs,
        stdin=line + "\n",
    )
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_fs_invalid_multichar_regex_is_error():
    """A multi-character FS that is an invalid regex errors at assignment."""
    # CATCHES: FS='x(' fails eagerly when the assignment executes (not
    # when a record is read), with the regex error wrapped as
    # 'invalid regex "x(": ...' and exit status 1.
    result = run_goawk('BEGIN { FS = "x(" }; { print }', stdin="a\n")
    assert result.returncode == 1
    assert result.stderr.decode() == (
        'invalid regex "x(": error parsing regexp: missing closing ): '
        '`(?s:x()`\n'
    )


def test_rs_assignment_splits_records_on_separator():
    """RS=',' splits input into records at each comma (newline kept)."""
    # CATCHES: record 1 of 'a b\\n1,2\\n' with RS=',' is 'a b\\n1' -- the
    # record itself contains the newline -- and NR still counts records.
    result = run_goawk(
        'BEGIN { RS = "," } { print NR, $0 }',
        stdin="a b\n1,2\n",
    )
    assert result.returncode == 0
    assert text(result) == "1 a b\n1\n2 2\n\n"


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], "[]"),
        (["-i", "csv", "-H"], "[csv header]"),
    ],
    ids=["default-empty", "csv-header-flags"],
)
def test_inputmode_readback(flags, expected):
    """INPUTMODE reads back as '' by default or the configured mode."""
    # CATCHES: -i csv -H surfaces as the INPUTMODE string 'csv header'
    # and the default is the empty string.
    result = run_goawk('BEGIN { print "[" INPUTMODE "]" }', flags=flags)
    assert result.returncode == 0
    assert text(result) == expected + "\n"


def test_inputmode_assignment_in_begin_enables_csv():
    """INPUTMODE='csv' assigned in BEGIN switches field parsing."""
    # CATCHES: setting the special variable INPUTMODE in BEGIN has the
    # same effect as the -i flag: 'a b' becomes a single CSV field (NF 1)
    # and '1,2' splits into two fields.
    result = run_goawk(
        'BEGIN { INPUTMODE = "csv" } { print NR, NF, $1 }',
        stdin="a b\n1,2\n",
    )
    assert result.returncode == 0
    assert text(result) == "1 1 a b\n2 2 1\n"


def test_inputmode_assignment_midstream_does_not_resplit():
    """INPUTMODE set after reading started leaves NF at 0 (no re-parse)."""
    # CATCHES: assigning INPUTMODE from a main-loop rule does not
    # retroactively re-split the already-read record nor re-parse later
    # ones: $0 stays intact but NF reads 0 and $1 is empty.
    result = run_goawk(
        'NR==1 { INPUTMODE = "csv" } { print NR, NF, "[" $0 "]" }'
        ' END { print "total", NR }',
        stdin="a b\n1,2\n",
    )
    assert result.returncode == 0
    assert text(result) == "1 0 [a b]\n2 0 [1,2]\ntotal 2\n"


def test_outputmode_readback_and_default():
    """OUTPUTMODE reads back empty by default and echoes assignments."""
    # CATCHES: OUTPUTMODE is an ordinary readable special variable: ''
    # by default, and an assigned value reads back verbatim.
    result = run_goawk(
        'BEGIN { print "[" OUTPUTMODE "]"; OUTPUTMODE = "csv";'
        ' print OUTPUTMODE }'
    )
    assert result.returncode == 0
    assert text(result) == "[]\ncsv\n"
