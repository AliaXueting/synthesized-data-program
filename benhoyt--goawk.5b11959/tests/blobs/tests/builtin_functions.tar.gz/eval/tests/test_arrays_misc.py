"""POSIX array-element auto-creation semantics (vm.go arrayGet)."""

from conftest import run_goawk, text


def test_referencing_element_creates_it():
    """Reading a[k] creates a null entry, so 'k in a' becomes true."""
    # CATCHES: any reference to a nonexistent element (outside 'in')
    # auto-creates it: before the reference 'k in a' is false, after
    # reading a["k"] it is true.
    result = run_goawk(
        'BEGIN { if ("k" in a) print "yes"; else print "no";'
        ' x = a["k"]; if ("k" in a) print "yes2" }'
    )
    assert result.returncode == 0
    assert text(result) == "no\nyes2\n"


def test_created_element_counts_in_length():
    """The auto-created null element is visible to length()."""
    # CATCHES: after x = a["k"] the array length is 1 even though nothing
    # was stored, matching POSIX element-creation semantics.
    result = run_goawk('BEGIN { x = a["k"]; print length(a) }')
    assert result.returncode == 0
    assert text(result) == "1\n"


def test_in_expression_does_not_create():
    """('k' in a) alone does not create the element."""
    # CATCHES: only non-'in' references create elements; a pure 'in' test
    # leaves the array empty (length 0).
    result = run_goawk('BEGIN { b = ("k" in a); print length(a) }')
    assert result.returncode == 0
    assert text(result) == "0\n"
