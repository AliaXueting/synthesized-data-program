"""Tests for the length() builtin: strings, $0, numbers, arrays, and -c mode."""

import pytest

from conftest import run_goawk, text


def test_length_string_literals():
    """length() counts BYTES of a string literal (multibyte chars count >1)."""
    # CATCHES: a re-implementation that counts Unicode chars by default (as
    # gawk --characters-as-bytes does) would report 5 for "héllo" instead of 6.
    result = run_goawk('BEGIN { print length("hello"), length(""), length("héllo") }')
    assert result.returncode == 0
    assert text(result) == "5 0 6\n"


def test_length_bare_and_dollar0_over_records():
    """Bare length, length() and length($0) are identical and track $0 per record."""
    # CATCHES: bare `length` must read the current record, not a stale or
    # global value; each input line must give its own length.
    result = run_goawk(
        "{ print length, length(), length($0) }",
        stdin="hello\nhi there\nab\n",
    )
    assert result.returncode == 0
    assert text(result) == "5 5 5\n8 8 8\n2 2 2\n"


def test_length_in_begin_and_after_field0_assign():
    """length is 0 in BEGIN (no record yet) and follows $0 assignments."""
    # CATCHES: BuiltinLength reads the live record buffer, so assigning $0
    # must change bare length even though no input was read.
    result = run_goawk(
        'BEGIN { print length } { $0 = "modified!!"; print length; exit }',
        stdin="x\n",
    )
    assert result.returncode == 0
    assert text(result) == "0\n10\n"


def test_length_of_numbers():
    """length() of a number converts it to a string first (%.6g-ish form)."""
    # CATCHES: numbers must be stringified with the default number->string
    # conversion before measuring; -1e100 becomes "-1e+100" (7 chars).
    result = run_goawk("BEGIN { print length(12345), length(3.5), length(-1e100) }")
    assert result.returncode == 0
    assert text(result) == "5 3 7\n"


def test_length_of_array():
    """length(array) returns the number of elements, shrinking on delete."""
    # CATCHES: length() must dispatch on array-ness of the argument; deleting
    # one element of three must report 2, and `delete a` must report 0.
    result = run_goawk(
        "BEGIN { a[1]=1; a[2]=2; a[5]=5; print length(a);"
        " delete a[1]; print length(a); delete a; print length(a) }"
    )
    assert result.returncode == 0
    assert text(result) == "3\n2\n0\n"


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], "6\n2\n"),
        (["-c"], "5\n1\n"),
    ],
    ids=["bytes", "chars"],
)
def test_length_chars_mode(flags, expected):
    """-c makes length count Unicode characters instead of bytes."""
    # CATCHES: the -c flag must switch length from byte counting to rune
    # counting; "héllo" is 6 bytes but 5 characters, and a lone "é" counts
    # as 2 bytes or 1 character depending on the mode.
    result = run_goawk(
        'BEGIN { s = "héllo"; print length(s); t = "é"; print length(t) }',
        flags=flags,
    )
    assert result.returncode == 0
    assert text(result) == expected


def test_length_chars_mode_bare_over_input():
    """-c also changes bare length (length of $0) to character counting."""
    # CATCHES: BuiltinLength (no-arg form) must honor the chars flag too,
    # otherwise per-record lengths of multibyte input stay byte-based.
    result = run_goawk(
        "{ print length }",
        flags=["-c"],
        stdin="hé\nü\n",
    )
    assert result.returncode == 0
    assert text(result) == "2\n1\n"
