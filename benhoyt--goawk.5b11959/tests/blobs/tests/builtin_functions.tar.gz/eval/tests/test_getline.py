"""Tests for getline in all its forms and its return codes.

These pin the six Getline* opcode handlers of interp/vm.go: bare getline,
getline into a variable / field / array element / special variable, and
the '< file' and '| command' redirections, including EOF (0), a missing
file (-1) and errors raised while storing into a special variable.
"""

import pytest

from conftest import run_goawk, text


@pytest.fixture
def input_file(tmp_path):
    """Create f1.txt (two lines) in tmp_path."""
    (tmp_path / "f1.txt").write_text("one\ntwo\n")
    return tmp_path


def test_bare_getline_reads_into_record():
    """Bare getline replaces $0 and returns 1 per line, 0 at EOF."""
    # CATCHES: getline splits the read line into fields ($0 and NF update),
    # and the while form stops exactly when getline returns 0 at EOF.
    result = run_goawk(
        'BEGIN { while (getline > 0) print "got:", $0, NF; print "end" }',
        stdin="a b\nc\n",
    )
    assert result.returncode == 0
    assert text(result) == "got: a b 2\ngot: c 1\nend\n"


def test_bare_getline_at_eof_returns_zero():
    """getline with empty input returns 0 immediately."""
    # CATCHES: the EOF result is the number 0 (not -1 and not an error),
    # so a bare getline on already-exhausted stdin yields 0.
    result = run_goawk('BEGIN { n = getline; print n }', stdin="")
    assert result.returncode == 0
    assert text(result) == "0\n"


@pytest.mark.parametrize(
    "target,print_expr,stdin,expected",
    [
        ("line", "line", "hello world\n", "1 hello world\n"),
        ("$1", "$0, NF", "hello world\n", "1 hello world 2\n"),
        ("a[1]", "a[1]", "val\n", "1 val\n"),
        ("RS", "RS", "recsep\n", "1 recsep\n"),
        ("RSTART", "RSTART", "one\n", "1 one\n"),
    ],
    ids=["global", "field", "array-element", "special-rs", "special-rstart"],
)
def test_getline_targets(target, print_expr, stdin, expected):
    """getline stores the line into the chosen target and returns 1."""
    # CATCHES: getline $1 rebuilds the whole record from the read line
    # (NF becomes 2), array elements and special variables receive the
    # raw line, and the function value is the success code 1.
    result = run_goawk('BEGIN { n = getline %s; print n, %s }'
                       % (target, print_expr), stdin=stdin)
    assert result.returncode == 0
    assert text(result) == expected


def test_getline_into_local_variable():
    """getline inside a function stores into the function's local."""
    # CATCHES: the local 'line' is a distinct slot from any global, so the
    # read line lands in the local and is printed from inside the call.
    result = run_goawk(
        'function f() { n = getline line; print n, line } BEGIN { f() }',
        stdin="loc\n",
    )
    assert result.returncode == 0
    assert text(result) == "1 loc\n"


def test_getline_from_file(input_file):
    """getline < file reads the first line of that file."""
    # CATCHES: the '< name' redirection reads from the named file rather
    # than stdin, and repeated reads walk down the file.
    result = run_goawk(
        'BEGIN { while ((getline line < "f1.txt") > 0) print "line:", line;'
        ' print "done" }',
        cwd=input_file,
    )
    assert result.returncode == 0
    assert text(result) == "line: one\nline: two\ndone\n"


def test_getline_from_missing_file_returns_minus_one():
    """getline < missing-file returns -1 without aborting."""
    # CATCHES: an unopenable file is NOT a fatal error -- getline yields -1
    # (and close() of the same name also reports -1) while the program
    # keeps running.
    result = run_goawk(
        'BEGIN { n = getline line < "nosuch.txt"; print n;'
        ' print close("nosuch.txt") }'
    )
    assert result.returncode == 0
    assert text(result) == "-1\n-1\n"


def test_getline_from_pipe():
    """'cmd' | getline reads the command's stdout."""
    # CATCHES: the pipe form runs the command through the shell and reads
    # its output; a second read of the same command yields 0 once its
    # output is exhausted.
    result = run_goawk(
        'BEGIN { "echo a" | getline x; print x; n = "echo a" | getline y;'
        ' print n }'
    )
    assert result.returncode == 0
    assert text(result) == "a\n0\n"


def test_getline_from_pipe_exhausts_to_zero():
    """Looping over 'cmd' | getline ends with the 0 return code."""
    # CATCHES: after the single output line is consumed the next getline
    # on the same stream returns 0, so the loop body runs exactly once.
    result = run_goawk(
        'BEGIN { while (("echo a" | getline x) > 0) print "line:", x;'
        ' print "done" }'
    )
    assert result.returncode == 0
    assert text(result) == "line: a\ndone\n"


@pytest.mark.parametrize(
    "var,line,message",
    [
        ("NF", "-5", "NF set to negative value: -5"),
        ("ARGC", "9999999", "ARGC set too large: 9999999"),
    ],
    ids=["nf-negative", "argc-too-large"],
)
def test_getline_into_special_var_can_error(var, line, message):
    """getline into NF/ARGC applies the special variable's validation."""
    # CATCHES: storing a read line into NF or ARGC runs the same checks as
    # assignment -- a negative NF or oversized ARGC aborts with the exact
    # 'set to ...' message at status 1.
    result = run_goawk('BEGIN { n = getline %s; print n }' % var,
                       stdin=line + "\n")
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == message + "\n"


def test_getline_into_fs_keeps_value():
    """getline into FS stores the line as the new field separator."""
    # CATCHES: FS is a plain special variable here -- the read line ','
    # becomes FS and is readable back, with no validation error for a
    # single-character separator.
    result = run_goawk('BEGIN { n = getline FS; print n, FS }', stdin=",\n")
    assert result.returncode == 0
    assert text(result) == "1 ,\n"
