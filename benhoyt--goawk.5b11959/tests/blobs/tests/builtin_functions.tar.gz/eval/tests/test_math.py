"""Tests for the math builtins: atan2, cos, sin, exp, log, sqrt, int."""

import pytest

from conftest import run_goawk, text


def run_one(expr):
    """Evaluate a single expression in BEGIN and return its printed text."""
    return text(run_goawk('BEGIN { print %s }' % expr)).rstrip("\n")


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("atan2(1, 1)", "0.785398"),
        ("atan2(-1, 1)", "-0.785398"),
        ("atan2(0, -1)", "3.14159"),
        ("atan2(1, 2)", "0.463648"),
        ("atan2(-1, -1)", "-2.35619"),
        ("atan2(1, -1)", "2.35619"),
        ("atan2(\"1\", \"2\")", "0.463648"),
    ],
    ids=["ne", "se", "west", "wide", "sw", "nw", "string-args"],
)
def test_atan2(expr, expected):
    """atan2(y, x) computes the four-quadrant arctangent of y/x."""
    # CATCHES: the argument order is (y, x) with the correct quadrant
    # signs, and string arguments are coerced to numbers first.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("cos(0)", "1"),
        ("cos(1)", "0.540302"),
        ("cos(-1)", "0.540302"),
        ("cos(\"0\")", "1"),
        ("sin(0)", "0"),
        ("sin(0.5)", "0.479426"),
        ("sin(-0.5)", "-0.479426"),
    ],
    ids=["cos-zero", "cos-one", "cos-even", "cos-string", "sin-zero",
         "sin-half", "sin-negative"],
)
def test_trig_functions(expr, expected):
    """cos() and sin() take radians; cos is even and sin is odd."""
    # CATCHES: arguments are interpreted as radians (not degrees) and
    # cos(-x) must equal cos(x) while sin(-x) negates sin(x).
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("exp(0)", "1"),
        ("exp(1)", "2.71828"),
        ("exp(-1)", "0.367879"),
        ("exp(\"1\")", "2.71828"),
        ("log(1)", "0"),
        ("log(2.718281828459045)", "1"),
        ("log(0.5)", "-0.693147"),
        ("log(exp(1))", "1"),
        ("exp(log(2))", "2"),
    ],
    ids=["exp-zero", "exp-one", "exp-neg", "exp-string", "log-one",
         "log-e", "log-half", "roundtrip-log", "roundtrip-exp"],
)
def test_exp_and_log(expr, expected):
    """exp() and log() are natural (base-e) exponential and logarithm."""
    # CATCHES: log is the NATURAL log (log(e)==1) and exp/log are mutual
    # inverses; printed values use the %.6g number format.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("sqrt(0)", "0"),
        ("sqrt(2)", "1.41421"),
        ("sqrt(16)", "4"),
        ("sqrt(1e10)", "100000"),
        ("sqrt(\"4\")", "2"),
    ],
    ids=["zero", "irrational", "perfect", "large", "string-arg"],
)
def test_sqrt(expr, expected):
    """sqrt() returns the square root of its numeric argument."""
    # CATCHES: sqrt accepts large values and string coercion ("4" -> 4)
    # and prints via %.6g, so sqrt(2) shows six significant digits.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("int(3.7)", "3"),
        ("int(-3.7)", "-3"),
        ("int(0)", "0"),
        ("int(-0.5)", "0"),
        ("int(42)", "42"),
        ("int(7/2)", "3"),
        ("int(-7/2)", "-3"),
        ("int(1e15)", "1000000000000000"),
        ("int(1e18)", "1000000000000000000"),
    ],
    ids=["positive", "negative", "zero", "tiny-negative", "integer",
         "expr", "expr-negative", "e15", "e18"],
)
def test_int_truncates_toward_zero(expr, expected):
    """int() truncates toward zero, never rounding away from it."""
    # CATCHES: int(-3.7) must be -3 (truncation toward zero, not floor),
    # and large in-range values like 1e18 convert exactly.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('int("3.9")', "3"),
        ('int("-3.9")', "-3"),
        ('int("42abc")', "42"),
        ('int("abc")', "0"),
    ],
    ids=["string-fraction", "string-negative", "string-prefix", "string-garbage"],
)
def test_int_coerces_strings_first(expr, expected):
    """int() converts string arguments to numbers before truncating."""
    # CATCHES: a numeric-prefix string is parsed with atof semantics
    # ("42abc" -> 42) and a non-numeric string becomes 0, THEN truncation
    # applies -- int("-3.9") is -3, not a string.
    assert run_one(expr) == expected


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("sqrt(-1)", "nan"),
        ("log(0)", "-inf"),
        ("log(-1)", "nan"),
        ("exp(1000)", "inf"),
    ],
    ids=["sqrt-negative", "log-zero", "log-negative", "exp-overflow"],
)
def test_math_special_values(expr, expected):
    """Out-of-domain math yields Go-style nan/inf, not errors."""
    # CATCHES: sqrt(-1) and log(-1) print as 'nan', log(0) as '-inf' and
    # exp overflow as 'inf' -- lowercase Go spellings, and the interpreter
    # does not abort with a runtime error.
    assert run_one(expr) == expected
