"""CSV/TSV input mode (docs/csv.md): the -i/--csv flags, INPUTMODE parsing
and errors, RFC 4180 quoting, separator/comment overrides, and the fact
that FS/RS are ignored."""

import pytest


@pytest.mark.parametrize("args", [
    ['--csv', '{ print NF, $1, $2 }'],
    ['-i', 'csv', '{ print NF, $1, $2 }'],
    ['-icsv', '{ print NF, $1, $2 }'],
    ['-v', 'INPUTMODE=csv', '{ print NF, $1, $2 }'],
    ['BEGIN { INPUTMODE="csv" } { print NF, $1, $2 }'],
])
def test_ways_to_enable_csv_input(run, args):
    """CSV input mode can be enabled by flag, -v or BEGIN assignment."""
    result = run(args, stdin=b"a,b\n")
    # CATCHES: every enabled form splits the comma line into two fields,
    # proving the mode is active regardless of how it was requested.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b\n', b'')


def test_tsv_input_mode(run):
    """-i tsv splits on tab characters by default."""
    result = run(['-i', 'tsv', '{ print NF, $1, $2 }'], stdin=b"a\tb\nc\td\n")
    # CATCHES: TSV mode's default separator is the tab, so both records
    # split into two fields.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b\n2 c d\n', b'')


def test_csv_and_tsv_flags_last_one_wins(run):
    """--csv and -i tsv together: the -i form takes precedence."""
    result = run(['--csv', '-i', 'tsv', '{ print NF, $1, $2 }'], stdin=b"a\tb\n")
    # CATCHES: with both flags given, -i tsv wins and the tab-separated
    # line parses into two fields.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b\n', b'')


@pytest.mark.parametrize("args,expected", [
    (['-i', 'csv separator=| comment=# header', 'BEGIN { print "[" INPUTMODE "]" }'],
     b'[csv separator=| comment=# header]\n'),
    (['-i', 'tsv separator=;', 'BEGIN { print "[" INPUTMODE "]" }'],
     b'[tsv separator=;]\n'),
    (['BEGIN { print "[" INPUTMODE "]" }'], b'[]\n'),
])
def test_inputmode_reads_back_normalized(run, args, expected):
    """Reading INPUTMODE returns the normalized mode string."""
    result = run(args, stdin=b"a\n")
    # CATCHES: INPUTMODE round-trips as a canonical 'csv|tsv [options]'
    # string and is empty in the default mode.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_quoted_field_contains_separator(run):
    """RFC 4180: a quoted field may contain the separator."""
    result = run(['--csv', '{ print NF, "[" $1 "]", "[" $2 "]" }'],
                 stdin=b'"a,b",c\n')
    # CATCHES: the quoted 'a,b' is a single field, so NF is 2.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 [a,b] [c]\n', b'')


def test_escaped_quotes_in_quoted_field(run):
    """RFC 4180: '""' inside a quoted field is a literal quote."""
    result = run(['--csv', '{ print NF, "[" $1 "]", "[" $2 "]" }'],
                 stdin=b'"a""b",c\n')
    # CATCHES: the doubled quote unescapes to one quote character, 'a"b'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 [a"b] [c]\n', b'')


def test_quoted_field_spans_lines(run):
    """RFC 4180: quoted fields may contain newlines."""
    result = run(['--csv', '{ print NR, NF, "[" $1 "]", "[" $2 "]" }'],
                 stdin=b'"line1\nline2",c\n')
    # CATCHES: the whole quoted field including its embedded newline is one
    # record (NR stays 1) and one field.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 2 [line1\nline2] [c]\n', b'')


def test_lazy_quotes_are_tolerated(run):
    """Bare quotes in unquoted fields are kept literally."""
    result = run(['--csv', '{ print NF, "[" $1 "]", "[" $2 "]", "[" $3 "]" }'],
                 stdin=b'a "word","1"2",a"\n')
    # CATCHES: unlike strict RFC 4180, lazy quotes don't error; the fields
    # keep their stray quote characters.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 [a "word"] [1"2] [a"]\n', b'')


def test_empty_lines_are_skipped(run):
    """Blank lines produce no records and don't count in NR."""
    result = run(['--csv', '{ print NR, $0 }'], stdin=b"a,b\n\nc,d\n\n")
    # CATCHES: NR is renumbered across the skipped blank lines, so 'c,d'
    # prints as record 2.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 a,b\n2 c,d\n', b'')


def test_crlf_line_endings_stripped(run):
    """CRLF record terminators don't leave a CR in the last field."""
    result = run(['--csv', '{ print NR, "[" $1 "]", "[" $2 "]" }'],
                 stdin=b"a,b\r\nc,d\r\n")
    # CATCHES: the CR of a CRLF terminator is dropped from field values.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [a] [b]\n2 [c] [d]\n', b'')


def test_bare_cr_inside_line_is_data(run):
    """A bare CR within a record is kept in the field."""
    result = run(['--csv', '{ print NF, "[" $1 "]", "[" $2 "]", "[" $3 "]" }'],
                 stdin=b"a,b\rc,d\r\n")
    # CATCHES: only \r\n (or a trailing \r at EOF) is a terminator; a bare
    # CR stays inside the field value 'b\rc'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 [a] [b\rc] [d]\n', b'')


def test_trailing_cr_at_eof_dropped(run):
    """A record ending with CR but no LF still loses the CR."""
    result = run(['--csv', '{ print NF, "[" $1 "]", "[" $2 "]" }'],
                 stdin=b"field1,field2\r")
    # CATCHES: the final unterminated record is trimmed of its trailing CR
    # before EOF.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 [field1] [field2]\n', b'')


def test_crlf_inside_quoted_field_normalized(run):
    """CRLF inside a quoted field becomes a lone LF."""
    result = run(['--csv', '{ print NF, "[" $1 "]", "[" $2 "]", "[" $3 "]" }'],
                 stdin=b'A,"Hello\r\nHi",B\r\n')
    # CATCHES: the CR is removed inside multi-line quoted fields, leaving
    # 'Hello\nHi'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 [A] [Hello\nHi] [B]\n', b'')


def test_utf8_bom_skipped(run):
    """A UTF-8 BOM at the start of input is ignored."""
    result = run(['--csv', '{ print "[" $1 "]" }'], stdin=b"\xef\xbb\xbfa,b\n")
    # CATCHES: the three BOM bytes are skipped rather than becoming part of
    # the first field.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[a]\n', b'')


def test_leading_trailing_whitespace_kept(run):
    """CSV mode does not strip surrounding whitespace from fields."""
    result = run(['--csv', '{ print NF, "[" $1 "]", "[" $2 "]" }'],
                 stdin=b"  a  ,  b  \n")
    # CATCHES: unlike the default FS=' ' splitting, '  a  ' keeps its
    # spaces verbatim.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 [  a  ] [  b  ]\n', b'')


def test_record_without_final_newline(run):
    """A final record without a trailing newline is still parsed."""
    result = run(['--csv', '{ print NF, $1, $2, $3 }'], stdin=b"a,b,c")
    # CATCHES: EOF acts as an implicit record terminator.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 a b c\n', b'')


@pytest.mark.parametrize("line,expected", [
    (b"a,b,c,\n", b'4 [a][b][c][]\n'),    # trailing separator: empty 4th field
    (b"a,b,c, \n", b'4 [a][b][c][ ]\n'),  # trailing space is data, not a trim
])
def test_trailing_separator_makes_empty_field(run, line, expected):
    """A trailing separator yields a final empty (or space) field."""
    result = run(['--csv', '{ print NF, "[" $1 "][" $2 "][" $3 "][" $4 "]" }'],
                 stdin=line)
    # CATCHES: the field after the last separator exists and is empty; a
    # space there is preserved as data.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_even_number_of_quotes(run):
    """Six quotes in a quoted field unescape to three quotes."""
    result = run(['--csv', '{ print NF, "[" $1 "]" }'], stdin=b'""""""""\n')
    # CATCHES: the whole input is one quoted field whose three doubled
    # quote pairs collapse to '"""'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 ["""]\n', b'')


def test_unterminated_quote_keeps_newline(run):
    """An unterminated quoted field at EOF keeps its trailing newline."""
    result = run(['--csv', '{ print NF, "[" $1 "]" }'], stdin=b'"b\n')
    # CATCHES: a lazy-quote record that ends after a newline retains the
    # newline inside the field value.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [b\n]\n', b'')


@pytest.mark.parametrize("mode,line,expected", [
    ('csv separator=|', b"a|b\nc|d\n", b'2 [a] [b]\n2 [c] [d]\n'),
    ('csv separator=;', b'a;b\n"x;y";z\n', b'2 [a] [b]\n2 [x;y] [z]\n'),
])
def test_separator_override(run, mode, line, expected):
    """separator=<char> replaces the field delimiter."""
    result = run(['-i', mode, '{ print NF, "[" $1 "]", "[" $2 "]" }'],
                 stdin=line)
    # CATCHES: the overridden separator splits fields (and is still
    # quotable, as the 'x;y' field shows).
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_separator_override_non_ascii(run):
    """Non-ASCII separator characters work, including inside data."""
    result = run(['-i', 'csv separator=£', '{ print NF, "[" $1 "]", "[" $2 "]", "[" $3 "]" }'],
                 stdin="a£b,c£ \td,e\n".encode())
    # CATCHES: the multi-byte separator is matched as a single rune, so
    # 'b,c' stays together as the second field.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, '3 [a] [b,c] [ \td,e]\n'.encode(), b'')


def test_comment_lines_skipped(run):
    """comment=<char> skips lines starting with that character."""
    result = run(['-i', 'csv comment=#', '{ print NR, "[" $1 "]" }'],
                 stdin=b"# c1\na,b\n# c2\nc,d\n")
    # CATCHES: comment lines produce no records and NR counts only data
    # rows.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [a]\n2 [c]\n', b'')


def test_comment_char_must_be_first_character(run):
    """A comment char preceded by whitespace is data, not a comment."""
    result = run(['-i', 'csv comment=#', '{ print "[" $1 "]" }'],
                 stdin=b"  #x\na,b\n")
    # CATCHES: comment detection only triggers at the very start of the
    # line, so the indented '#x' row is kept as a record.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[  #x]\n[a]\n', b'')


def test_comment_char_ignored_inside_quoted_field(run):
    """A comment char inside a quoted field is data."""
    result = run(['-i', 'csv comment=#', '{ print "[" $2 "]" }'],
                 stdin=b'a,"#not comment"\n')
    # CATCHES: comment skipping happens per physical line before quoting is
    # considered, but this line starts with 'a', so the quoted '#...' is
    # preserved as field data.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[#not comment]\n', b'')


def test_comment_char_non_ascii(run):
    """Non-ASCII comment characters work."""
    result = run(['-i', 'csv comment=€', '{ print "[" $1 "]" }'],
                 stdin="€ comment\na,b\n".encode())
    # CATCHES: the multi-byte comment rune is decoded properly, so the
    # '€ comment' line is skipped.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[a]\n', b'')


def test_fs_and_rs_ignored_in_csv_mode(run):
    """FS and RS settings have no effect in CSV input mode."""
    result = run(['--csv', '-F', ',', '-v', 'RS=,', '{ print NR, NF, "[" $1 "]" }'],
                 stdin=b"a,b\nc,d\n")
    # CATCHES: even with FS and RS set to the comma, records are split by
    # newlines and fields by the CSV parser.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 2 [a]\n2 2 [c]\n', b'')


def test_dollar0_is_raw_record_and_rebuild(run):
    """$0 keeps the raw CSV text; a field assignment rebuilds it."""
    result = run(['--csv', '{ print "[" $0 "]" }'], stdin=b'"a,b",c\n')
    # CATCHES: $0 is the unmodified input record (quotes intact).
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'["a,b",c]\n', b'')
    rebuilt = run(['--csv', '{ $1=$1; print "[" $0 "]" }'], stdin=b'"a,b",c\n')
    # CATCHES: after $1=$1 the record is rebuilt from the parsed fields
    # joined by OFS (a space), losing the quotes.
    assert (rebuilt.returncode, rebuilt.stdout, rebuilt.stderr) == (
        0, b'[a,b c]\n', b'')


def test_nr_fnr_filename_in_csv_mode(run):
    """NR/FNR/FILENAME behave normally in CSV mode on stdin."""
    result = run(['-i', 'csv comment=#', '{ print NR, FNR, FILENAME, $1 }'],
                 stdin=b"# c\n\na,b\n\n# d\ne,f\n")
    # CATCHES: comments and blank lines leave no gap in NR/FNR numbering
    # and FILENAME is '-' for stdin.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 - a\n2 2 - e\n', b'')


def test_getline_reparses_csv_in_begin(run):
    """getline in BEGIN parses the record with CSV rules."""
    result = run(['-i', 'csv', 'BEGIN { getline; print NF, "[" $1 "]", "[" $2 "]" }'],
                 stdin=b'a,"b,c"\n')
    # CATCHES: a record read by getline in BEGIN is re-split with the CSV
    # parser, keeping 'b,c' as one field.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 [a] [b,c]\n', b'')


def test_inputmode_assigned_midprogram(run):
    """INPUTMODE assigned outside BEGIN disables field parsing."""
    result = run(['{ INPUTMODE = "csv"; print NF, $1, $2 }'], stdin=b"a,b\n")
    # CATCHES: the scanner was already created, so the mode switch leaves
    # the record unparsed: NF is 0 and both fields print empty.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'0  \n', b'')


def test_csv_files_without_header_mode(run, write):
    """Multiple CSV files without -H: every row is a data row."""
    write("a.csv", b"h1,h2\n1,2\n")
    write("b.csv", b"g1,g2\n3,4\n")
    result = run(['-i', 'csv', '{ print FILENAME, NR, FNR, $1 }',
                  'a.csv', 'b.csv'])
    # CATCHES: FNR resets per file while NR keeps counting, and the header
    # rows are processed as ordinary records.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'a.csv 1 1 h1\na.csv 2 2 1\nb.csv 3 1 g1\nb.csv 4 2 3\n', b'')


def test_many_comment_lines_and_long_fields(run, write):
    """Comment skipping and long fields survive large inputs."""
    write("big.csv", b"#ignore\n" * 2000 + b"@" * 300 + b"," + b"*" * 300 + b"\n")
    result = run(['-i', 'csv comment=#', '{ print NF, length($1), length($2) }',
                  'big.csv'])
    # CATCHES: 2000 comment lines are skipped and the two 300-byte fields
    # parse correctly, exercising buffered reading.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 300 300\n', b'')


@pytest.mark.parametrize("args,expected_err", [
    (['-i', 'abc', '{ print }'],
     b'invalid input mode "abc"\n'),
    (['BEGIN { INPUTMODE="abc" } { print }'],
     b'invalid input mode "abc"\n'),
    (['-i', 'csv foo=bar', '{ print }'],
     b'invalid input mode key "foo"\n'),
    (['-i', 'csv separator=xy', '{ print }'],
     b'invalid CSV/TSV separator "xy"\n'),
    (['-i', 'csv comment=xy', '{ print }'],
     b'invalid CSV/TSV comment character "xy"\n'),
    (['-i', 'csv separator="', '{ print }'],
     b'invalid CSV field separator or comment delimiter\n'),
    (['-i', 'csv separator=x comment=x', '{ print }'],
     b'invalid CSV field separator or comment delimiter\n'),
    (['-i', 'csv header=x', '{ print }'],
     b'invalid header value "x"\n'),
    (['-i'], b'flag needs an argument: -i\n'),
    (['-i', 'header', '{ print }'],
     b'invalid input mode "header"\n'),
])
def test_input_mode_errors(run, args, expected_err):
    """Malformed input modes fail with precise messages and exit 1."""
    result = run(args, stdin=b"a\n")
    # CATCHES: each bad mode reports its own exact diagnostic on stderr
    # with exit status 1 and no stdout output.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', expected_err)


DUMP = ('--csv',
        '{ printf "%d:", NR; for (i=1;i<=NF;i++) printf " [%s]", $i; print "" }')


def test_comma_field_grid(run):
    """Every combination of trailing separators yields the empty fields."""
    result = run(DUMP, stdin=b"x,y,z,w\nx,y,z,\nx,y,,\nx,,,\n,,,\n")
    # CATCHES: missing values become empty fields so all rows keep four
    # fields, including the all-empty row.
    assert (result.returncode, result.stdout, result.stderr) == (
        0,
        b'1: [x] [y] [z] [w]\n2: [x] [y] [z] []\n3: [x] [y] [] []\n'
        b'4: [x] [] [] []\n5: [] [] [] []\n', b'')


def test_quoted_comma_grid(run):
    """Explicitly quoted empty fields parse the same as bare ones."""
    result = run(DUMP, stdin=b'"x","y","z","w"\n"x","y","",""\n"","","",""\n')
    # CATCHES: quoted empty strings are real fields, keeping the row width
    # at four.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1: [x] [y] [z] [w]\n2: [x] [y] [] []\n3: [] [] [] []\n', b'')


def test_short_row_keeps_its_own_width(run):
    """Rows may have differing field counts."""
    result = run(DUMP, stdin=b"a,b,\nc,d,e\n")
    # CATCHES: there is no fixed field count; the first row has three
    # fields (last one empty) and the second has three non-empty ones.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1: [a] [b] []\n2: [c] [d] [e]\n', b'')


@pytest.mark.parametrize("input_bytes,expected", [
    # CRCRLF terminators keep a bare CR in the field.
    (b"field\r\r\nfield\r\r\n", b'1: [field\r]\n2: [field\r]\n'),
    # A CR-only line inside the record joins into the field.
    (b"field\r\r\n\rfield\r\r\n\r", b'1: [field\r]\n2: [\rfield\r]\n'),
    # A record of only newlines inside quotes.
    (b'"\n\n\n\n"', b'1: [\n\n\n\n]\n'),
])
def test_cr_edge_cases(run, input_bytes, expected):
    """Carriage-return corner cases from the CSV reader test data."""
    result = run(DUMP, stdin=input_bytes)
    # CATCHES: only CRLF is a terminator; lone CRs survive inside fields
    # and are never treated as record separators on their own.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_crlf_only_input_yields_no_records(run):
    """Input consisting solely of CRLF line endings yields no records."""
    result = run(['--csv',
                  '{ printf "%d:", NR; for (i=1;i<=NF;i++) printf " [%s]", $i; print "" }'
                  ' END { print "END", NR }'],
                 stdin=b"\r\n\r\n\r\n\r\n")
    # CATCHES: pure line-ending input is fully skipped without a final
    # empty record, so NR stays 0 and only the END marker prints (a
    # reader that emitted a trailing empty record would print "END 1").
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'END 0\n', b'')


@pytest.mark.parametrize("input_bytes,expected", [
    (b'"foo"bar"\r\n', b'1: [foo"bar]\n'),  # lazy quote before CRLF
    (b'"foo""bar"\r\n', b'1: [foo"bar]\n'),  # escaped quote before CRLF
])
def test_lazy_and_escaped_quote_with_crlf(run, input_bytes, expected):
    """Lazy quotes and escaped quotes both yield the same field with CRLF."""
    result = run(DUMP, stdin=input_bytes)
    # CATCHES: whether the inner quote is lazy or doubled, the field is
    # 'foo"bar' and the CRLF terminator is stripped.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_nonascii_separator_rune_decoding(run):
    """Separator runes sharing a UTF-8 prefix with data decode correctly."""
    result = run(['-i', 'csv separator=λ comment=€', DUMP[1]],
                 stdin='"abθcd"λefθgh'.encode())
    # CATCHES: λ and θ share their first byte, but the parser decodes full
    # runes so only λ splits fields and θ stays in the data.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, '1: [abθcd] [efθgh]\n'.encode(), b'')


def test_nonascii_comment_rune_decoding(run):
    """Comment detection decodes full runes, not bytes."""
    result = run(['-i', 'csv comment=θ', DUMP[1]], stdin="λ\nλ\nθ\nλ\n".encode())
    # CATCHES: only the line starting with the exact θ rune is skipped;
    # the λ lines (sharing a UTF-8 prefix byte) are kept as records.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, '1: [λ]\n2: [λ]\n3: [λ]\n'.encode(), b'')
