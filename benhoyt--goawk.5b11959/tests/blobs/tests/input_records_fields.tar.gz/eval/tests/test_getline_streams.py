"""getline in all its forms, close() of input streams, and nextfile."""

import pytest


def test_getline_into_dollar0_sets_nf_nr_fnr(run):
    """Bare getline reads into $0 and bumps NR/FNR/NF."""
    result = run(['BEGIN { while ((getline) > 0) print NR, FNR, NF, "[" $0 "]" }'],
                 stdin=b"l1\nl2\n")
    # CATCHES: plain getline replaces the record and increments NR and FNR
    # just like the main input loop, and fields are re-split.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 1 [l1]\n2 2 1 [l2]\n', b'')


def test_getline_into_variable(run):
    """'getline var' reads into the variable without touching $0."""
    result = run(['BEGIN { while ((getline v) > 0) print "[" v "]" }'],
                 stdin=b"l1\nl2\n")
    # CATCHES: the variable form leaves the record untouched while still
    # consuming input.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[l1]\n[l2]\n', b'')


def test_getline_from_file_reads_whole_file(run, write):
    """'getline <"file"' iterates over every record of the file."""
    write("f1.txt", b"x\ny\n")
    result = run(['BEGIN { while ((getline line < "f1.txt") > 0) print "[" line "]" }'])
    # CATCHES: repeated getline calls on the same name continue the same
    # stream rather than reopening it.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[x]\n[y]\n', b'')


def test_getline_from_file_keeps_filename_and_nr(run, write):
    """getline from a file does not change FILENAME, NR or FNR."""
    write("f1.txt", b"x\ny\n")
    result = run(['BEGIN { n=(getline < "f1.txt"); '
                  'print n, "[" FILENAME "]", NR, FNR, "[" $0 "]" }'])
    # CATCHES: the read succeeds (n=1) and loads $0, but FILENAME stays
    # empty in BEGIN and both counters stay 0.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [] 0 0 [x]\n', b'')


def test_getline_variable_from_file(run, write):
    """'getline var <"file"' reads a record into the variable."""
    write("f1.txt", b"x\ny\n")
    result = run(['BEGIN { while ((getline v < "f1.txt") > 0) print "[" v "]" }'])
    # CATCHES: the variable-plus-redirect form shares the same per-name
    # stream as the $0 form.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[x]\n[y]\n', b'')


def test_getline_missing_file_returns_minus_one(run):
    """getline from a nonexistent file returns -1 without dying."""
    result = run(['BEGIN { n = (getline < "nope.txt"); print "n=" n }'])
    # CATCHES: the open failure is reported through the return value -1
    # only; nothing goes to stderr and the exit status stays 0.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'n=-1\n', b'')


def test_getline_directory_returns_minus_one(run, write):
    """getline from a directory opens but fails reading, giving -1."""
    write("adir/keep", b"")
    result = run(['BEGIN { n = (getline < "adir"); print "n=" n }'])
    # CATCHES: the read error (EISDIR) is converted to -1 for getline
    # instead of aborting like it would in the main input loop.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'n=-1\n', b'')


def test_getline_empty_filename_returns_minus_one(run):
    """getline from an empty filename fails with -1."""
    result = run(['BEGIN { n = (getline < ""); print "n=" n }'])
    # CATCHES: the empty name is not treated as stdin; it fails to open and
    # returns -1.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'n=-1\n', b'')


def test_command_pipe_getline(run):
    """'"cmd" | getline' runs the command via /bin/sh -c."""
    result = run(['BEGIN { "echo hi" | getline v; print "[" v "]" }'])
    # CATCHES: the command's first output line becomes the variable value
    # with the trailing newline stripped.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[hi]\n', b'')


def test_command_pipe_getline_return_values(run):
    """Pipe getline returns 1 on success and 0 at EOF of the command."""
    result = run(['BEGIN { r = ("printf abc" | getline a); '
                  'print "r=" r, "a=[" a "]" }'])
    # CATCHES: a record without a trailing newline is still returned, and
    # the return value is 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'r=1 a=[abc]\n', b'')


def test_command_pipe_getline_eof_zero(run):
    """A command with no output gives getline 0."""
    result = run(['BEGIN { r = ("exit 3" | getline x); '
                  'print "r=" r, "x=[" x "]" }'])
    # CATCHES: an empty-output command ends the stream, so getline returns
    # 0 (not -1) and the variable keeps its old value.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'r=0 x=[]\n', b'')


def test_command_pipe_getline_missing_command(run):
    """A command that doesn't exist yields 0 and a shell error."""
    result = run(['BEGIN { n = ("no_such_command_xyz" | getline v); '
                  'print "n=" n, "v=[" v "]" }'])
    # CATCHES: the shell's 'not found' diagnostic goes to stderr while
    # getline itself just sees EOF (n=0) and stays non-fatal.
    assert (result.returncode, result.stdout) == (0, b'n=0 v=[]\n')
    assert b"no_such_command_xyz: not found" in result.stderr


def test_getline_from_dash_reads_stdin(run):
    """getline <"-" reads from standard input."""
    result = run(['BEGIN { while ((getline l < "-") > 0) print "[" l "]" }'],
                 stdin=b"s1\ns2\n")
    # CATCHES: the name '-' is special-cased to stdin for getline, and the
    # stream is separate from the main input.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[s1]\n[s2]\n', b'')


def test_getline_variable_from_dash(run):
    """'getline var <"-"' reads stdin into the variable."""
    result = run(['BEGIN { n = (getline v < "-"); print n, "[" v "]" }'],
                 stdin=b"dd\n")
    # CATCHES: the redirect form with a variable also understands '-'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [dd]\n', b'')


def test_close_reopens_file_from_start(run, write):
    """close() forgets the stream so the next getline re-reads the file."""
    write("f1.txt", b"x\ny\n")
    result = run(['BEGIN { getline a < "f1.txt"; close("f1.txt"); '
                  'getline b < "f1.txt"; print a, b }'])
    # CATCHES: after close the file is reopened from the beginning, so both
    # reads return the first record.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'x x\n', b'')


def test_unclosed_stream_keeps_position(run, write):
    """Without close(), successive getlines advance through the file."""
    write("f1.txt", b"x\ny\n")
    result = run(['BEGIN { getline a < "f1.txt"; getline b < "f1.txt"; print a, b }'])
    # CATCHES: the stream named "f1.txt" retains its position between
    # getline calls.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'x y\n', b'')


def test_getline_respects_rs(run, write):
    """getline from a file uses the current RS for records."""
    write("rs1.txt", b"aXb\ncXd\n")
    result = run(['-v', 'RS=X', 'BEGIN { getline l < "rs1.txt"; print "[" l "]" }'])
    # CATCHES: the custom record separator applies to getline streams too,
    # so the record stops at the first X.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[a]\n', b'')


def test_getline_in_main_loop_consumes_next_record(run):
    """A getline inside the main loop eats the following record."""
    result = run(['{ print "rec=" $0; if (FNR==1) { getline extra; print "extra=" extra } }'],
                 stdin=b"r1\nr2\nr3\n")
    # CATCHES: the record consumed by getline is not revisited by the main
    # loop, so r2 only appears via 'extra'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'rec=r1\nextra=r2\nrec=r3\n', b'')


def test_getline_increments_nr_and_fnr(run):
    """Bare getline in the main loop advances NR/FNR past the record."""
    result = run(['{ getline; print NR, FNR, $0 }'], stdin=b"r1\nr2\nr3\n")
    # CATCHES: getline reads r2 while the main loop is on r1, so the
    # printed NR/FNR are 2, and the final failed getline leaves $0 alone.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 2 r2\n3 3 r3\n', b'')


def test_getline_from_writer_stream_is_an_error(run, write):
    """Reading from a name currently open for writing fails."""
    write("out1.txt", b"")
    result = run(['BEGIN { print "x" > "out1.txt"; '
                  'n = (getline < "out1.txt"); print "n=" n }'])
    # CATCHES: an output stream and input stream cannot share a name; the
    # exact 'can't read from writer stream' error aborts with status 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b"can't read from writer stream\n")


def test_getline_stream_is_separate_from_argv_input(run, write):
    """getline <"file" opens its own stream even if file is an operand."""
    write("f1.txt", b"x\ny\n")
    result = run(['{ getline < "f1.txt"; print FILENAME, FNR, "[" $0 "]" }',
                  'f1.txt'])
    # CATCHES: both the main loop and the getline redirect read the file
    # from the start independently.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'f1.txt 1 [x]\nf1.txt 2 [y]\n', b'')


def test_close_file_returns_zero_then_minus_one(run, write):
    """close() on an input file returns 0, and -1 once already closed."""
    write("f1.txt", b"x\ny\n")
    result = run(['BEGIN { getline < "f1.txt"; print close("f1.txt"); '
                  'print close("f1.txt") }'])
    # CATCHES: the first close of an open file stream reports 0 and removes
    # it, so a second close reports -1.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'0\n-1\n', b'')


@pytest.mark.parametrize("name", ["never", ""])
def test_close_of_never_opened_stream(run, name):
    """close() of a name that was never open returns -1."""
    result = run(['BEGIN { print close("%s") }' % name])
    # CATCHES: closing an unknown (or empty) stream name is not an error;
    # it just yields -1.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'-1\n', b'')


def test_close_returns_command_exit_status(run):
    """close() on a command pipe returns the command's exit status."""
    result = run(['BEGIN { "exit 5" | getline x; print close("exit 5") }'])
    # CATCHES: the pipe's close waits for the child and reports its status
    # as a number.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'5\n', b'')


def test_close_of_successful_command_returns_zero(run):
    """close() of a successful command pipe returns 0."""
    result = run(['BEGIN { "echo one" | getline a; print close("echo one") }'])
    # CATCHES: a zero-exit command gives close() 0, matching the file
    # stream behaviour.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'0\n', b'')


@pytest.mark.parametrize("cmd,expected", [
    ('kill -9 $$', b'265\n'),      # 256 + SIGKILL(9)
    ('kill -TERM $$', b'271\n'),   # 256 + SIGTERM(15)
])
def test_close_of_signal_killed_command(run, cmd, expected):
    """close() encodes a signal death as 256 plus the signal number."""
    result = run(['BEGIN { "%s" | getline x; print close("%s") }' % (cmd, cmd)])
    # CATCHES: an unhandled-signal exit is not an error; the status is the
    # gawk-style 256+signal encoding, distinguishing it from exit codes.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_fflush_of_input_stream_errors(run, write):
    """fflush() cannot flush a stream opened for input."""
    write("f1.txt", b"x\ny\n")
    result = run(['BEGIN { getline < "f1.txt"; print fflush("f1.txt") }'])
    # CATCHES: an input-only stream is rejected by fflush with the 'not an
    # output file or pipe' diagnostic on stderr and a -1 return value.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'-1\n', b'error flushing "f1.txt": not an output file or pipe\n')


def test_pipe_reruns_command_after_close(run):
    """After close(), using the same command re-runs it."""
    result = run(['BEGIN { "echo one" | getline a; print close("echo one"); '
                  'r=("echo one" | getline b); print "r=" r, "b=[" b "]" }'])
    # CATCHES: the second use of the same command string starts a fresh
    # child process, so it returns a new record.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'0\nr=1 b=[one]\n', b'')


def test_nextfile_skips_to_next_file(run, write):
    """nextfile stops processing the current file immediately."""
    write("nn1.txt", b"a1\na2\n")
    write("nn2.txt", b"b1\nb2\n")
    result = run(['{ print FILENAME, FNR, $0; nextfile }', 'nn1.txt', 'nn2.txt'])
    # CATCHES: only the first record of each file is seen, and FNR restarts
    # at 1 for the second file.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'nn1.txt 1 a1\nnn2.txt 1 b1\n', b'')


def test_nextfile_keeps_nr_and_resets_fnr(run, write):
    """nextfile: NR continues across files while FNR resets."""
    write("nn1.txt", b"a1\na2\na3\n")
    write("nn2.txt", b"b1\nb2\n")
    result = run(['FNR==2 { nextfile } { print FILENAME, NR, FNR, $0 }',
                  'nn1.txt', 'nn2.txt'])
    # CATCHES: after skipping the rest of nn1.txt, the first record of
    # nn2.txt has NR=3 (continuing) but FNR=1 (reset).
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'nn1.txt 1 1 a1\nnn2.txt 3 1 b1\n', b'')


def test_nextfile_on_every_file_still_runs_end(run, write):
    """Skipping every file still allows END to run."""
    write("nn1.txt", b"a1\n")
    write("nn2.txt", b"b1\n")
    result = run(['FNR==1 { nextfile } { print $0 } END { print "END" }',
                  'nn1.txt', 'nn2.txt'])
    # CATCHES: nextfile only skips input; the END block still executes and
    # the exit status stays 0.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'END\n', b'')


@pytest.mark.parametrize("prog,expected_err", [
    ('BEGIN { nextfile }',
     b"<cmdline>:1:9: nextfile can't be inside BEGIN or END\n"
     b'BEGIN { nextfile }\n        ^\n'),
    ('END { nextfile }',
     b"<cmdline>:1:7: nextfile can't be inside BEGIN or END\n"
     b'END { nextfile }\n      ^\n'),
])
def test_nextfile_in_begin_or_end_is_a_parse_error(run, prog, expected_err):
    """nextfile is rejected inside BEGIN or END at parse time."""
    result = run([prog])
    # CATCHES: the error is reported with a caret pointing at the offending
    # 'nextfile' and includes the source line, exiting 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', expected_err)
