"""Where records come from: stdin, file operands, '-' and var=value ARGV
handling, NR/FNR/FILENAME bookkeeping, and input file open/read errors."""

import pytest


def test_stdin_used_when_no_file_operands(run):
    """With no operands the program reads stdin and FILENAME is '-'."""
    result = run(['{ print NR, FNR, FILENAME, $0 }'], stdin=b"a\nb\n")
    # CATCHES: stdin input sets FILENAME to '-' while NR and FNR both count
    # every record (no per-file reset because there is only one "file").
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 - a\n2 2 - b\n', b'')


def test_file_operand_reads_file_in_order(run, write):
    """A file operand is read and sets FILENAME to the operand text."""
    write("f1.txt", b"x\ny\n")
    result = run(['{ print NR, FNR, FILENAME, $0 }', 'f1.txt'])
    # CATCHES: the operand string itself becomes FILENAME and both NR and
    # FNR increase per record of that single file.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 f1.txt x\n2 2 f1.txt y\n', b'')


def test_multiple_files_update_nr_and_fnr(run, write):
    """File operands are processed in order; NR is global, FNR per file."""
    write("f2.txt", b"p\n")
    write("f3.txt", b"q\nr\n")
    result = run(['{ print NR, FNR, FILENAME }', 'f2.txt', 'f3.txt'])
    # CATCHES: FNR restarts at 1 for each file while NR keeps counting
    # across files, and FILENAME switches per file.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 f2.txt\n2 1 f3.txt\n3 2 f3.txt\n', b'')


def test_same_file_twice_is_read_twice(run, write):
    """Repeating an operand re-reads the file from the start."""
    write("f1.txt", b"x\ny\n")
    result = run(['{ print NR, FNR, FILENAME }', 'f1.txt', 'f1.txt'])
    # CATCHES: the second occurrence reopens the file so FNR resets even
    # though FILENAME is unchanged, while NR runs 1..4.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 f1.txt\n2 2 f1.txt\n3 1 f1.txt\n4 2 f1.txt\n', b'')


def test_dash_operand_means_stdin(run):
    """A '-' operand reads standard input and FILENAME prints '-'."""
    result = run(['{ print FILENAME }', '-'], stdin=b"m\n")
    # CATCHES: '-' is a stdin marker, not a path, so FILENAME is '-' and no
    # 'not found' error occurs.
    assert (result.returncode, result.stdout, result.stderr) == (0, b'-\n', b'')


def test_dash_twice_reads_stdin_only_once(run):
    """Two '-' operands: the second finds stdin already at EOF."""
    result = run(['{ print NR, FILENAME }', '-', '-'], stdin=b"only\n")
    # CATCHES: stdin is not rewindable, so the second '-' yields no records;
    # only one record is processed in total.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 -\n', b'')


def test_stdin_and_file_mix(run, write):
    """'-' before a file: stdin first, then the file, FNR resets."""
    write("f1.txt", b"x\ny\n")
    result = run(['{ print NR, FNR, FILENAME }', '-', 'f1.txt'], stdin=b"s1\ns2\n")
    # CATCHES: records from stdin and from the file interleave in operand
    # order with FNR resetting at each boundary.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 -\n2 2 -\n3 1 f1.txt\n4 2 f1.txt\n', b'')


def test_missing_file_errors_and_exits_1(run):
    """A missing input file reports to stderr and exits 1."""
    result = run(['{ print }', 'missing.txt'])
    # CATCHES: the exact error text quotes the operand and goes to stderr
    # with a newline, stdout stays empty, and the exit status is 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'file "missing.txt" not found\n')


def test_missing_file_after_valid_file(run, write):
    """Earlier files are fully processed before the missing file errors."""
    write("f1.txt", b"x\ny\n")
    result = run(['{ print }', 'f1.txt', 'missing.txt'])
    # CATCHES: records of the good file are printed first, then processing
    # aborts with the not-found error and exit status 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'x\ny\n', b'file "missing.txt" not found\n')


def test_missing_file_skips_end_block(run, write):
    """An input error aborts the run without running END."""
    write("f1.txt", b"x\n")
    result = run(['{ print } END { print "END" }', 'f1.txt', 'missing.txt'])
    # CATCHES: END does not run when an input file fails to open; only the
    # earlier records reach stdout before exit status 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'x\n', b'file "missing.txt" not found\n')


def test_directory_operand_read_error(run, write):
    """A directory operand opens but fails when read."""
    write("adir/keep", b"")
    result = run(['{ print }', 'adir'])
    # CATCHES: opening a directory succeeds so the failure surfaces as a
    # read error wrapped in 'error reading from input:' and exit status 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'error reading from input: read adir: is a directory\n')


def test_unreadable_file_open_error(run, write):
    """An open error other than 'not found' is reported differently."""
    loop = write("loop", b"")
    loop.unlink()
    loop.symlink_to("loop")  # self-referencing symlink: open fails with ELOOP
    result = run(['{ print }', 'loop'])
    # CATCHES: open failures that are not ENOENT print the raw OS error in
    # 'open <name>: <reason>' form (no 'not found' quoting) and exit 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'open loop: too many levels of symbolic links\n')


def test_dangling_symlink_is_not_found(run, write):
    """A symlink pointing at a missing target is a 'not found' case."""
    dangling = write("dangling", b"")
    dangling.unlink()
    dangling.symlink_to("/nonexistent/target")
    result = run(['{ print }', 'dangling'])
    # CATCHES: ENOENT from a dangling symlink is reported with the quoted
    # 'not found' message, same as a plain missing name.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'file "dangling" not found\n')


def test_var_assignment_applies_when_position_reached(run, write):
    """A 'name=value' operand assigns when that ARGV position is reached."""
    write("f1.txt", b"x\ny\n")
    write("f3.txt", b"z\n")
    result = run(['{ print NR, v }', 'f1.txt', 'v=9', 'f3.txt'])
    # CATCHES: the assignment takes effect between files: records of the
    # first file see an empty v, later records see 9.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 \n2 \n3 9\n', b'')


def test_assignment_between_files_keeps_nr(run, write):
    """var=value operands do not reset NR or FNR bookkeeping."""
    write("f1.txt", b"x\ny\n")
    write("nn1.txt", b"a1\na2\na3\n")
    result = run(
        ['{ print NR, FNR, FILENAME, v }', 'f1.txt', 'v=mid', 'nn1.txt'])
    # CATCHES: an assignment operand is skipped without touching NR/FNR
    # (NR continues 3,4,5) and the variable stays set for later files.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 f1.txt \n2 2 f1.txt \n3 1 nn1.txt mid\n4 2 nn1.txt mid\n'
           b'5 3 nn1.txt mid\n', b'')


def test_assignment_only_argv_still_reads_stdin(run):
    """Assignments don't count as files: stdin is used afterwards."""
    result = run(['{ print v, $0 }', 'v=5'], stdin=b"hi\n")
    # CATCHES: after consuming the assignment operand no file was seen, so
    # the program falls back to stdin even though ARGV had an operand.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'5 hi\n', b'')


def test_begin_can_rewrite_argv_and_argc(run, write):
    """BEGIN may replace the file list via ARGV/ARGC."""
    write("f1.txt", b"x\ny\n")
    write("f3.txt", b"z\n")
    result = run(
        ['BEGIN { ARGV[1]="f1.txt"; ARGV[2]="f3.txt"; ARGC=3 }'
         ' { print FILENAME, $0 }'])
    # CATCHES: file operands come from ARGV[1..ARGC-1] evaluated after
    # BEGIN, so the rewritten list is used verbatim.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'f1.txt x\nf1.txt y\nf3.txt z\n', b'')


def test_argv_empty_string_is_skipped(run, write):
    """An empty ARGV entry is skipped, not treated as a file."""
    write("f3.txt", b"z\n")
    result = run(
        ['BEGIN { ARGV[1]=""; ARGV[2]="f3.txt"; ARGC=3 } { print NR, FILENAME }'])
    # CATCHES: the empty entry produces no records and no error; the next
    # entry is read normally.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 f3.txt\n', b'')


def test_argc_zero_reads_stdin(run):
    """Setting ARGC=0 in BEGIN makes the program read stdin."""
    result = run(['BEGIN { ARGC=0 } { print FILENAME }'], stdin=b"a\n")
    # CATCHES: with no ARGV entries left and no files seen, stdin is used
    # and FILENAME becomes '-'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'-\n', b'')


def test_E_disables_var_assignment_operands(run, write):
    """After -E, 'name=value' operands are treated as file names."""
    write("prog.awk", b'{ print v, FILENAME }')
    write("f1.txt", b"x\ny\n")
    result = run(['-E', 'prog.awk', 'v=hello', 'f1.txt'])
    # CATCHES: -E turns off var=value processing, so 'v=hello' is opened as
    # a file, which fails with the not-found error and exit status 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'file "v=hello" not found\n')


def test_empty_file_produces_no_records(run, write):
    """An empty input file yields no records and no error."""
    write("empty.txt", b"")
    result = run(['{ print "row" } END { print "END", NR }', 'empty.txt'])
    # CATCHES: an empty file is not an error; the action simply never runs,
    # NR stays 0, and only the END marker prints (treating an empty file as
    # one empty record would produce "row" and "END 1").
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'END 0\n', b'')


def test_operand_with_equals_is_an_assignment(run, write):
    """An operand matching name=value is an assignment even if a file with
    that exact name exists."""
    write("we=ird.txt", b"z\n")
    result = run(['END { print NR, we }', 'we=ird.txt'])
    # CATCHES: the name=value pattern wins over file lookup, so the operand
    # assigns variable 'we' (making it printable) and no records are read;
    # reading the like-named file instead would give "1 " plus an empty
    # variable value.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'0 ird.txt\n', b'')


def test_var_assignment_operands_unescape_values(run, write):
    """Escape sequences in var=value operands are interpreted."""
    write("f1.txt", b"x\n")
    result = run(['{ print "[" v "]"; exit }', 'v=a\\tb', 'f1.txt'])
    # CATCHES: the value 'a\tb' becomes a real tab in the variable, matching
    # the -v escape handling.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[a\tb]\n', b'')


def test_begin_only_program_does_not_read_input(run):
    """A BEGIN-only program never opens the input files."""
    result = run(['BEGIN { print "b" }', 'missing.txt'])
    # CATCHES: without a main loop no input is read at all, so even a
    # missing file operand produces no error.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'b\n', b'')


def test_end_only_program_still_reads_input(run):
    """An END-only program still iterates over the input files."""
    result = run(['END { print "END" }', 'missing.txt'])
    # CATCHES: unlike BEGIN-only, an END block still triggers the input
    # loop, so the missing file is reported and END never runs.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'file "missing.txt" not found\n')


def test_absolute_path_operand_kept_in_filename(run, write, tmp_path):
    """An absolute path operand appears verbatim in FILENAME."""
    path = write("f1.txt", b"x\n")
    result = run(['{ print FILENAME }', str(path)])
    # CATCHES: the operand is not normalized or made relative; FILENAME is
    # exactly the path string given on the command line.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, str(path).encode() + b"\n", b'')


@pytest.mark.parametrize("prog,stdin,expected_out", [
    # BEGIN-only: input never touched.
    ('BEGIN { print "b" }', b"", b"b\n"),
    # END-only: input is still consumed (here: stdin, empty).
    ('END { print "E" }', b"", b"E\n"),
])
def test_begin_vs_end_input_iteration(run, prog, stdin, expected_out):
    """Only END blocks (not BEGIN-only programs) iterate the input."""
    result = run([prog], stdin=stdin)
    # CATCHES: a BEGIN-only program skips the record loop entirely while an
    # END-only program drains stdin first, then runs END.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected_out, b'')
