"""Stream lifecycle tests: close()/fflush() on file and command streams.

These target the stream objects in interp/iostream.go (outFileStream,
outCmdStream, inFileStream, inCmdStream, waitExitCode): how streams are
buffered, what close() returns for each stream kind (0 for files, the
command's exit status for pipes, 256/512+signal encodings), which errors
are reported on stderr versus returned from close(), and when an
unclosed stream is flushed at program exit. All expectations were
recorded by running the reference binary.
"""

import pytest


# ---------------------------------------------------------------------------
# close() on output file streams (outFileStream)
# ---------------------------------------------------------------------------

def test_print_to_file_then_close_returns_zero(run, write, tmp_path):
    """Closing an output file stream returns 0 and flushes the data."""
    result = run(['BEGIN { print "x" > "o.txt"; print "c=" close("o.txt") }'])
    # CATCHES: close() of a file stream flushes the buffered line to disk
    # and returns 0, and the file really contains the written bytes.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=0\n', b'')
    assert (tmp_path / "o.txt").read_bytes() == b"x\n"


def test_second_close_of_output_file_returns_minus_one(run):
    """Closing an already-closed output file stream returns -1."""
    result = run(['BEGIN { print "x" > "o.txt"; print "c1=" close("o.txt");'
                  ' print "c2=" close("o.txt") }'])
    # CATCHES: after close() the stream is unregistered, so a second close
    # of the same name returns -1 instead of erroring or returning 0 again.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c1=0\nc2=-1\n', b'')


def test_two_prints_to_one_file_stream_do_not_truncate(run, tmp_path):
    """A second print to an already-open file stream appends in memory."""
    result = run(['BEGIN { print "x" > "o.txt"; print "y" > "o.txt" }'])
    # CATCHES: the second '>' reuses the open stream instead of reopening
    # (which would truncate), so both lines land in the file.
    assert (result.returncode, result.stdout, result.stderr) == (0, b'', b'')
    assert (tmp_path / "o.txt").read_bytes() == b"x\ny\n"


def test_greater_truncates_existing_file(run, write, tmp_path):
    """A '>' redirect to a new stream truncates an existing file."""
    write("o.txt", b"OLDCONTENT\n")
    result = run(['BEGIN { print "new" > "o.txt" }'])
    # CATCHES: opening a '>' stream is a create/truncate, so the previous
    # content is gone and only the new line remains.
    assert (result.returncode, result.stdout, result.stderr) == (0, b'', b'')
    assert (tmp_path / "o.txt").read_bytes() == b"new\n"


def test_close_then_reopen_truncates(run, write, tmp_path):
    """After close(), a new '>' stream truncates and starts fresh."""
    write("o.txt", b"aaa\nbbb\n")
    result = run(['BEGIN { print "a" > "o.txt"; print "c=" close("o.txt");'
                  ' print "b" > "o.txt" }'])
    # CATCHES: close() ends the stream, so the next '>' reopens with
    # truncation; only "b" survives, not the pre-existing or first writes.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=0\n', b'')
    assert (tmp_path / "o.txt").read_bytes() == b"b\n"


def test_append_redirect_appends(run, write, tmp_path):
    """A '>>' redirect appends to existing file content."""
    write("o.txt", b"old\n")
    result = run(['BEGIN { print "a" >> "o.txt"; print "b" >> "o.txt" }'])
    # CATCHES: '>>' opens in append mode (no truncation) and reuses the
    # stream for the second print, keeping the original content first.
    assert (result.returncode, result.stdout, result.stderr) == (0, b'', b'')
    assert (tmp_path / "o.txt").read_bytes() == b"old\na\nb\n"


def test_greater_to_open_append_stream_appends(run, tmp_path):
    """'>' to a name already opened via '>>' reuses the append stream."""
    result = run(['BEGIN { print "a" >> "o.txt"; print "b" > "o.txt" }'])
    # CATCHES: stream lookup is by name only, so '>' finds the existing
    # append-mode stream and writes instead of truncating the file.
    assert (result.returncode, result.stdout, result.stderr) == (0, b'', b'')
    assert (tmp_path / "o.txt").read_bytes() == b"a\nb\n"


# ---------------------------------------------------------------------------
# close() exit statuses on command pipes (outCmdStream / waitExitCode)
# ---------------------------------------------------------------------------

def test_close_output_pipe_returns_zero(run):
    """Closing a pipe whose command exited 0 returns 0 after flushing."""
    result = run(['BEGIN { print "x" | "cat"; print "c=" close("cat") }'])
    # CATCHES: close() flushes the buffered line to the command, waits for
    # it, and returns its exit status; the command's output appears on
    # goawk's stdout before the close status is printed.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'x\nc=0\n', b'')


def test_close_output_pipe_returns_command_exit_status(run):
    """Closing a pipe returns the command's nonzero exit status."""
    result = run(['BEGIN { print "x" | "read line; exit 3";'
                  ' print "c=" close("read line; exit 3") }'])
    # CATCHES: waitExitCode maps a normal exit to the raw status, so an
    # 'exit 3' command makes close() return 3 (not 0 or 256-based). The
    # command reads its input first so the flush never races its death.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=3\n', b'')


def test_close_output_pipe_signal_death(run):
    """A command killed by a signal closes with status 256+signal."""
    result = run(['BEGIN { print "x" | "read line; kill -9 $$";'
                  ' print "c=" close("read line; kill -9 $$") }'])
    # CATCHES: unhandled-signal death is encoded as 256+signal, so SIGKILL
    # (9) yields 265, matching gawk's close() convention. The command
    # consumes its input before dying so the write always completes.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=265\n', b'')


def test_close_output_pipe_core_dump(run):
    """A command that dies with a core dump closes with status 512+signal."""
    result = run(['BEGIN { print "x" |'
                  ' "read line; ulimit -c unlimited; kill -ILL $$";'
                  ' print "c=" close('
                  '"read line; ulimit -c unlimited; kill -ILL $$") }'])
    # CATCHES: core-dump signal death uses the 512+signal encoding, so
    # SIGILL (4) yields 516, distinct from the plain 256+signal case.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=516\n', b'')


def test_close_input_pipe_core_dump(run):
    """An input pipe command killed with a core dump also closes 512+signal."""
    result = run(['BEGIN { "ulimit -c unlimited; kill -ILL $$" | getline;'
                  ' print "c=" close("ulimit -c unlimited; kill -ILL $$") }'])
    # CATCHES: the same waitExitCode encoding applies to input pipes
    # ("cmd" | getline), not just output pipes.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=516\n', b'')


def test_pipe_command_stderr_passes_through(run):
    """A piped command's stderr is routed to goawk's own stderr."""
    result = run(['BEGIN { print "x" | "read line; echo err 1>&2";'
                  ' print "c=" close("read line; echo err 1>&2") }'])
    # CATCHES: the child's stderr is wired to the interpreter's stderr
    # stream, so "err" lands on stderr while close() still returns 0.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=0\n', b'err\n')


def test_closed_output_pipe_reuse_reruns_command(run):
    """Writing to a pipe name again after close() starts a new command."""
    result = run(['BEGIN { print "1" | "cat"; print "c=" close("cat");'
                  ' print "2" | "cat"; print "c=" close("cat") }'])
    # CATCHES: close() unregisters the stream, so the next print to the
    # same name spawns a fresh command; each cat outputs its own line.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1\nc=0\n2\nc=0\n', b'')


def test_fflush_output_pipe_returns_zero(run):
    """fflush() on an output pipe flushes it and returns 0."""
    result = run(['BEGIN { print "x" | "cat"; f = fflush("cat");'
                  ' c = close("cat"); print "f=" f " c=" c }'])
    # CATCHES: fflush works on command streams too (returns 0), the flushed
    # data still reaches the command, and the later close() re-syncs before
    # the summary line is printed.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'x\nf=0 c=0\n', b'')


# ---------------------------------------------------------------------------
# Write-error paths on output streams
# ---------------------------------------------------------------------------

DEVFULL_ERR = b'write /dev/full: no space left on device\n'


def test_close_write_error_on_devfull(run):
    """close() returns -1 and logs when flushing to /dev/full fails."""
    result = run(['BEGIN { print "hello" > "/dev/full";'
                  ' print "c=" close("/dev/full") }'])
    # CATCHES: a flush error at close time is reported on stderr with the
    # quoted stream name and the OS error, and close() returns -1 while
    # the program continues (exit status stays 0).
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=-1\n',
        b'error closing "/dev/full": ' + DEVFULL_ERR)


def test_fflush_write_error_on_devfull(run):
    """fflush() on a failing output file returns -1 and logs the error."""
    result = run(['BEGIN { print "hello" > "/dev/full";'
                  ' print "f=" fflush("/dev/full") }'])
    # CATCHES: fflush surfaces the underlying write error on stderr with
    # the stream name quoted, and returns -1 instead of 0.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'f=-1\n',
        b'error flushing "/dev/full": ' + DEVFULL_ERR)


def test_fflush_all_reports_failing_stream(run):
    """fflush("") returns -1 if any open stream fails to flush."""
    result = run(['BEGIN { print "a" > "q.txt"; print "b" > "/dev/full";'
                  ' print "r=" fflush("") }'])
    # CATCHES: the flush-everything form reports each failing stream (here
    # /dev/full) and returns -1 because not all streams could be flushed.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'r=-1\n',
        b'error flushing "/dev/full": ' + DEVFULL_ERR)


def test_unclosed_failing_stream_ignored_at_exit(run):
    """A write error on a stream never closed is silently ignored at exit."""
    result = run(['BEGIN { print "hello" > "/dev/full"; print "done" }'])
    # CATCHES: the interpreter's exit-time close of remaining streams
    # ignores errors, so nothing is printed to stderr and the exit status
    # stays 0 even though the flush to /dev/full failed.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'done\n', b'')


def test_broken_pipe_at_close_reports_error(run):
    """A buffered write to a dead reader at close() logs but returns status.

    system() flushes the pipe once, so the reader (sleep) sees its input
    and exits; the lines printed afterwards stay in the 64 KiB stream
    buffer and only hit the broken pipe when close() flushes them.
    """
    result = run(['BEGIN { print "x" | "sleep 0.1"; system("sleep 0.5");'
                  ' for (i=0;i<500;i++) print "0123456789" | "sleep 0.1";'
                  ' print "c=" close("sleep 0.1") }'])
    # CATCHES: close() on an output pipe reports the broken-pipe write
    # error on stderr but still returns the command's exit status (0 for
    # sleep), and the program is not aborted.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=0\n',
        b'error closing "sleep 0.1": write |1: broken pipe\n')


def test_broken_pipe_during_print_is_fatal(run):
    """A write error while auto-flushing a pipe aborts the program."""
    result = run(['BEGIN { for (i=0;i<50000;i++)'
                  ' print "0123456789" | "head -1"; print "after" }'])
    # CATCHES: once the 64 KiB buffer fills, print itself gets the EPIPE
    # error, which is fatal: stderr carries only the raw error message,
    # the exit status is 1, and "after" is never printed.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'0123456789\n', b'write |1: broken pipe\n')


def test_write_error_during_print_is_fatal(run):
    """An ENOSPC write error mid-print on a file stream is fatal too."""
    result = run(['BEGIN { for (i=0;i<20000;i++)'
                  ' print "xxxx" > "/dev/full"; print "after" }'])
    # CATCHES: the same fatal propagation applies to file streams: the raw
    # write error goes to stderr, exit status is 1, and execution stops.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', DEVFULL_ERR)


# ---------------------------------------------------------------------------
# fflush() making buffered data visible
# ---------------------------------------------------------------------------

def test_fflush_output_file_makes_data_visible(run):
    """fflush() on a named file pushes buffered data to disk immediately."""
    result = run(['BEGIN { print "one" > "f.txt"; print "r=" fflush("f.txt");'
                  ' while (("cat f.txt" | getline) > 0) print "got:", $0;'
                  ' close("cat f.txt") }'])
    # CATCHES: without fflush the line would still be sitting in the
    # stream buffer and cat would see an empty file; with it, cat reads
    # "one" back before the program ends.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'r=0\ngot: one\n', b'')


def test_fflush_empty_flushes_all_streams(run):
    """fflush("") flushes every open output stream, not just one."""
    result = run(['BEGIN { print "one" > "f1.txt"; print "two" > "f2.txt";'
                  ' fflush("");'
                  ' while (("cat f1.txt f2.txt" | getline) > 0)'
                  ' print "got:", $0; close("cat f1.txt f2.txt") }'])
    # CATCHES: both buffered streams are pushed to disk by the single
    # fflush(""), so the subsequent cat of both files returns both lines.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'got: one\ngot: two\n', b'')


def test_fflush_without_args_flushes_all(run):
    """fflush() with no arguments behaves like fflush("")."""
    result = run(['BEGIN { print "x" > "g.txt"; r = fflush();'
                  ' while (("cat g.txt" | getline) > 0) print "got:", $0;'
                  ' print "r=" r }'])
    # CATCHES: the zero-argument form also flushes all output streams and
    # returns 0, making the buffered line visible to the reading command.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'got: x\nr=0\n', b'')


def test_fflush_unknown_stream_name(run):
    """fflush() of a name that is not an output stream returns -1."""
    result = run(['BEGIN { print fflush("nope.txt") }'])
    # CATCHES: an unknown stream name is rejected with a stderr message
    # quoting the name and explaining it is not an output file or pipe.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'-1\n',
        b'error flushing "nope.txt": not an output file or pipe\n')


# ---------------------------------------------------------------------------
# Special stream names
# ---------------------------------------------------------------------------

def test_print_to_dash_writes_stdout_close_minus_one(run):
    """print > "-" writes to stdout; the name is not a closeable stream."""
    result = run(['BEGIN { print "x" > "-"; print "c1=" close("-") }'])
    # CATCHES: "-" is an alias for stdout, not a registered stream, so the
    # data goes to stdout but close("-") finds nothing and returns -1.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'x\nc1=-1\n', b'')


def test_print_to_dev_stdout_and_stderr(run):
    """/dev/stdout and /dev/stderr route to the interpreter's own streams."""
    result = run(['BEGIN { print "e" > "/dev/stderr"; print "s" > "/dev/stdout";'
                  ' print "c1=" close("/dev/stdout");'
                  ' print "c2=" close("/dev/stderr") }'])
    # CATCHES: these device names are intercepted rather than opened as
    # files, so output is rerouted to the real stdout/stderr and closing
    # the names returns -1 because no stream was registered.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b's\nc1=-1\nc2=-1\n', b'e\n')


# ---------------------------------------------------------------------------
# Stream-name conflicts between input and output
# ---------------------------------------------------------------------------

def test_print_to_reader_stream_is_an_error(run):
    """Writing to a name currently open as a reading stream is an error."""
    result = run(['BEGIN { "echo hi" | getline; print "x" > "echo hi" }'])
    # CATCHES: a name may not be both a reader and a writer; the print
    # redirect aborts the program with status 1 before any output.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b"can't write to reader stream\n")


def test_write_then_read_back_same_name(run):
    """After closing an output file, the same name can be read back."""
    result = run(['BEGIN { print "written" > "h.txt";'
                  ' print "c=" close("h.txt");'
                  ' while ((getline line < "h.txt") > 0) print "read:", line;'
                  ' close("h.txt") }'])
    # CATCHES: the close flushes and unregisters the writer, so a getline
    # on the same name opens a fresh reader stream and returns the bytes
    # that were just written.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c=0\nread: written\n', b'')


# ---------------------------------------------------------------------------
# Parametrized close() status matrix
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("cmd,expected_status", [
    ("read line; true", b"c=0\n"),
    ("read line; exit 3", b"c=3\n"),
    ("read line; kill -9 $$", b"c=265\n"),
    ("read line; kill -TERM $$", b"c=271\n"),
])
def test_close_output_pipe_status_matrix(run, cmd, expected_status):
    """close() on output pipes maps command deaths to status codes."""
    result = run(['BEGIN { print "x" | "%s"; print "c=" close("%s") }'
                  % (cmd, cmd)])
    # CATCHES: the exit-status encoding (raw status, 256+SIGKILL,
    # 256+SIGTERM) is identical to the input-pipe close() convention;
    # each command reads its input first so no write/death race exists.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected_status, b'')
