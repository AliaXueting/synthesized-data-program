"""CSV header mode: -H / the 'header' INPUTMODE option, named field access
with @"...", and the FIELDS array."""

import pytest


def test_header_enables_named_field_access(run):
    """-H parses a header row and enables @"name" access."""
    result = run(['-i', 'csv', '-H', '{ print @"name" }'],
                 stdin=b"name,age\nBob,7\nJane,9\n")
    # CATCHES: the header row itself produces no record; each data row is
    # accessed by column name.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'Bob\nJane\n', b'')


def test_header_mode_word_equivalent_to_h(run):
    """'header' in the INPUTMODE string is equivalent to -H."""
    result = run(['-i', 'csv header', '{ print @"name"; exit }'],
                 stdin=b"name,age\nBob,7\n")
    # CATCHES: the 'header' configuration word enables named access without
    # the -H flag.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'Bob\n', b'')


@pytest.mark.parametrize("mode,expected", [
    ('csv header=true', b'7\n'),
    ('csv header', b'7\n'),
])
def test_header_true_value(run, mode, expected):
    """header=true explicitly enables the header row."""
    result = run(['-i', mode, '{ print @"age" }'], stdin=b"name,age\nBob,7\n")
    # CATCHES: the explicit 'true' value (or empty value) turns header mode
    # on just like the bare word.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_header_false_value_disables(run):
    """header=false keeps the first row as data."""
    result = run(['-i', 'csv header=false', '{ print $1 }'],
                 stdin=b"name,age\nBob,7\n")
    # CATCHES: 'false' disables header parsing, so the header line prints
    # as an ordinary record.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'name\nBob\n', b'')


def test_fields_array_maps_index_to_name(run):
    """FIELDS maps field numbers to the header names."""
    result = run(['-i', 'csv', '-H',
                  '{ for (i=1; i in FIELDS; i++) print i, FIELDS[i]; exit }'],
                 stdin=b"id,name,email\n1,Bob,b@bob.com\n")
    # CATCHES: FIELDS is populated from the header row in order, starting
    # at index 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 id\n2 name\n3 email\n', b'')


def test_fields_updated_per_input_file(run, write):
    """Each input file gets its own header row and FIELDS contents."""
    write("m1.csv", b"h1,h2\n1,2\n")
    write("m2.csv", b"g1,g2\n3,4\n")
    result = run(['-i', 'csv', '-H', '{ print FILENAME, FIELDS[1], FIELDS[2] }',
                  'm1.csv', 'm2.csv'])
    # CATCHES: FIELDS is rewritten when each new file's header is read, and
    # stale names from the previous file are cleared.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'm1.csv h1 h2\nm2.csv g1 g2\n', b'')


def test_named_access_scoped_to_current_file(run, write):
    """@"name" only resolves names from the current file's header."""
    write("m1.csv", b"h1,h2\n1,2\n")
    write("m2.csv", b"g1,g2\n3,4\n")
    result = run(['-i', 'csv', '-H', '{ print FILENAME, @"h1", @"g1" }',
                  'm1.csv', 'm2.csv'])
    # CATCHES: a name absent from the current header yields the empty
    # string rather than an error or the old file's value.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'm1.csv 1 \nm2.csv  3\n', b'')


def test_unknown_field_name_is_empty(run):
    """An unknown column name gives "" instead of an error."""
    result = run(['-i', 'csv', '-H', '{ print "[" @"nope" "]" }'],
                 stdin=b"id,name\n1,Bob\n")
    # CATCHES: out-of-range names silently return empty, keeping the exit
    # status 0.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[]\n', b'')


def test_quoted_header_names(run):
    """Header names may be quoted CSV fields."""
    result = run(['-i', 'csv', '-H', '{ print @"age" }'],
                 stdin=b'"name","age"\nBob,7\n')
    # CATCHES: quoting in the header row is unescaped before the names are
    # registered.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'7\n', b'')


def test_duplicate_header_names_last_wins(run):
    """Duplicate column names: the last occurrence is used."""
    result = run(['-i', 'csv', '-H', '{ print @"a" }'], stdin=b"a,a\n1,2\n")
    # CATCHES: the name-to-index map keeps the rightmost column with that
    # name, so '2' prints.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2\n', b'')


def test_dynamic_named_field_access(run):
    """@ accepts a variable or expression as the field name."""
    result = run(['-i', 'csv', '-H',
                  '{ n="name"; print @n; print @("na" "me") }'],
                 stdin=b"name,age\nBob,7\n")
    # CATCHES: named access works with computed names just like the $
    # operator, printing the value twice.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'Bob\nBob\n', b'')


def test_named_fields_in_a_loop(run):
    """Dynamic names allow looping over numbered columns."""
    result = run(['-i', 'csv', '-H',
                  '{ for (i=1; i<=5; i++) print @("address_" i) }'],
                 stdin=(b"name,address_1,address_2,address_3,address_4,address_5\n"
                        b"Bob Smith,123 Way St,Apt 2B,Township,Cityville,United Plates\n"))
    # CATCHES: concatenating the column prefix with the loop counter
    # resolves each address field in order.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'123 Way St\nApt 2B\nTownship\nCityville\nUnited Plates\n', b'')


@pytest.mark.parametrize("args,stdin,expected", [
    (['-i', 'tsv', '-H', '{ print @"h2" }'], b"h1\th2\n1\t2\n", b'2\n'),
    (['--csv', '-H', '{ print @"h2" }'], b"h1,h2\n1,2\n", b'2\n'),
])
def test_header_with_other_input_flags(run, args, stdin, expected):
    """-H works with -i tsv and with --csv."""
    result = run(args, stdin=stdin)
    # CATCHES: header parsing is not tied to the csv mode flag; TSV input
    # and the --csv shortcut both support it.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_header_only_file_gives_no_records(run, write):
    """A file containing only a header row produces no records."""
    write("m3.csv", b"h1,h2\n")
    result = run(['-i', 'csv', '-H',
                  '{ print "row" } END { print "END", NR }', 'm3.csv'])
    # CATCHES: the header row is consumed without yielding a data record,
    # so the action never runs, NR stays 0, and only the END marker is
    # printed (an implementation emitting the header as a record would
    # print "row" and "END 1" instead).
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'END 0\n', b'')


def test_fields_array_empty_without_header(run):
    """Without header mode FIELDS exists but stays empty."""
    result = run(['-i', 'csv', '{ for (i in FIELDS) print i, FIELDS[i]; print "done" }'],
                 stdin=b"a,b\n")
    # CATCHES: FIELDS is a valid array in any mode but only header mode
    # fills it; iterating it prints nothing.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'done\n', b'')


@pytest.mark.parametrize("args,stdin", [
    # No CSV mode at all.
    (['{ print @"a" }'], b"a,b\n"),
    # CSV mode but no -H/header option.
    (['-i', 'csv', '{ print @"a" }'], b"a,b\n"),
    # -H given but used in BEGIN before any header was read.
    (['-i', 'csv', '-H', 'BEGIN { print @"name" }'], b"name,age\nBob,7\n"),
])
def test_at_outside_header_mode_errors(run, args, stdin):
    """@"..." without a parsed header row is a fatal error."""
    result = run(args, stdin=stdin)
    # CATCHES: the exact diagnostic names both remedies (-H / 'header' in
    # INPUTMODE / getline in BEGIN) and the run exits 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'',
        b'no field names for @; use -H or add "header" to INPUTMODE,'
        b' and use "getline" first if in BEGIN\n')


def test_getline_in_begin_enables_named_access(run):
    """getline in BEGIN reads the header so @"..." works there."""
    result = run(['-i', 'csv', '-H', 'BEGIN { getline; print @"name" }'],
                 stdin=b"name,age\nBob,7\n")
    # CATCHES: reading the header via getline inside BEGIN registers the
    # field names before the main loop starts.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'Bob\n', b'')


@pytest.mark.parametrize("args", [
    ['-H', '{ print }'],
    ['-H', '-o', 'csv', '{ print }'],
])
def test_h_requires_i(run, args):
    """-H without -i is rejected."""
    result = run(args, stdin=b"a\n")
    # CATCHES: -H is only valid together with -i, even when an output mode
    # was configured; the exact message and exit status 1 result.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'-H only allowed together with -i\n')


def test_fields_is_an_array_at_parse_time(run):
    """FIELDS cannot be used as a scalar."""
    result = run(['-i', 'csv', '-H', 'BEGIN { FIELDS = 3 }'], stdin=b"a\n")
    # CATCHES: FIELDS is reserved as an array, so assigning a scalar is a
    # compile-time error pointing at the offending source line.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'',
        b'<cmdline>:1:9: can\'t use array "FIELDS" as scalar\n'
        b'BEGIN { FIELDS = 3 }\n        ^\n')


def test_doc_example_print_abbreviation(run, write):
    """Doc example: print a column by name from a quoted CSV file."""
    write("states.csv",
          b'"State","Abbreviation"\n"Alabama","AL"\n"Alaska","AK"\n"Arizona","AZ"\n')
    result = run(['-i', 'csv', '-H', '{ print @"Abbreviation" }', 'states.csv'])
    # CATCHES: quoted header names and quoted data both parse, selecting
    # the second column for every row.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'AL\nAK\nAZ\n', b'')


def test_doc_example_match_and_count(run, write):
    """Doc example: match a named field against a regex and count."""
    write("states.csv",
          b'"State","Abbreviation"\n"New Hampshire","NH"\n"New Jersey","NJ"\n'
          b'"New Mexico","NM"\n"New York","NY"\n"Ohio","OH"\n')
    result = run(['-i', 'csv', '-H',
                  '@"State" ~ /New/ { n++ } END { print n }', 'states.csv'])
    # CATCHES: named fields work in patterns too, not just actions.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'4\n', b'')


def test_doc_example_csv_to_tsv_conversion(run, write):
    """Doc example: reformat a CSV file to TSV with $1=$1."""
    write("states.csv", b'"State","Abbreviation"\n"Alabama","AL"\n')
    result = run(['-i', 'csv', '-o', 'tsv', '{ $1=$1; print }', 'states.csv'])
    # CATCHES: without -H the header row is data; assigning $1 re-joins the
    # parsed fields with the output separator (tab) and bare print emits
    # the rebuilt $0.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'State\tAbbreviation\nAlabama\tAL\n', b'')
