"""Field splitting via FS: default whitespace, single characters, regexes,
field/NF assignment semantics, and the field index limits."""

import pytest


def test_default_fs_splits_whitespace_runs(run):
    """Default FS collapses runs of spaces/tabs and strips the ends."""
    result = run(['{ print NF, "[" $1 "][" $2 "][" $3 "]" }'],
                 stdin=b"  a  b\t c \n")
    # CATCHES: leading and trailing whitespace is dropped and interior runs
    # of mixed spaces/tabs count as one separator.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 [a][b][c]\n', b'')


def test_blank_line_gives_nf_zero(run):
    """A blank line yields NF==0 and an empty $0."""
    result = run(['{ print NR, NF, "[" $0 "]" }'], stdin=b"x\n\ny\n")
    # CATCHES: the blank line is a record (NR counts it) but has zero
    # fields and $0 is empty, unlike a line of spaces which would also be
    # trimmed to zero fields.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 1 [x]\n2 0 []\n3 1 [y]\n', b'')


def test_single_char_fs_keeps_empty_fields(run):
    """A single-character FS splits on every occurrence, keeping empties."""
    result = run(['-F', ',', '{ print NF, $1, $2, $3, $4 }'], stdin=b"a,b,,c\n")
    # CATCHES: the empty field between the two commas is preserved, giving
    # four fields with $3 empty.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'4 a b  c\n', b'')


@pytest.mark.parametrize("fs,input_line", [
    (".", b"a.b\n"),   # regex metacharacter used literally
    ("[", b"a[b\n"),   # an invalid regex is still fine as a literal char
])
def test_single_char_fs_is_literal(run, fs, input_line):
    """A one-character FS is literal, never compiled as a regex."""
    result = run(['-F', fs, '{ print NF, $1, $2 }'], stdin=input_line)
    # CATCHES: '.' and '[' split literally instead of acting as regex
    # metacharacters, so both lines produce two fields.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b\n', b'')


def test_explicit_space_fs_behaves_like_default(run):
    """FS of a single space means the default whitespace splitting."""
    result = run(['-F', ' ', '{ print NF, $1, $2, $3 }'], stdin=b"a  b\n")
    # CATCHES: a single space FS is special-cased to whitespace-run
    # splitting, so 'a  b' is two fields, not three.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b \n', b'')


def test_multichar_fs_is_regex(run):
    """A multi-character FS is used as a regex."""
    result = run(['-F', 'X+', '{ print NF, $1, $2, $3 }'], stdin=b"aXXbXc\n")
    # CATCHES: 'X+' consumes whole runs of X, producing three fields.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 a b c\n', b'')


def test_fs_regex_leftmost_longest(run):
    """FS regex matching is leftmost-longest."""
    result = run(['-F', ',+', '{ print NF, $1, $2 }'], stdin=b"a,,b\n")
    # CATCHES: the run of commas is one separator, so NF is 2 and no empty
    # middle field appears.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b\n', b'')


def test_fs_regex_alternation(run):
    """FS alternation splits on any alternative."""
    result = run(['-F', 'X|Y', '{ print NF, $1, $2, $3 }'], stdin=b"aXbYc\n")
    # CATCHES: both alternatives separate fields, giving three fields.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 a b c\n', b'')


def test_empty_fs_splits_every_character(run):
    """FS='' splits the record into single characters."""
    result = run(['-F', '', '{ print NF, $1, $2, $3 }'], stdin=b"abc\n")
    # CATCHES: the empty FS is not an error: each character becomes a
    # field.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 a b c\n', b'')


def test_multibyte_single_char_fs(run):
    """A single multi-byte character FS splits on that character."""
    result = run(['-F', 'é', '{ print NF, $1, $2 }'], stdin="aéb\n".encode())
    # CATCHES: the two-byte separator splits the record into two fields
    # without breaking the UTF-8 encoding.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b\n', b'')


def test_fs_escape_in_v_assignment(run):
    """-v FS='\t' interprets the escape into a real tab."""
    result = run(['-v', 'FS=\\t', '{ print NF, $1, $2 }'], stdin=b"a\tb\n")
    # CATCHES: the -v value is unescaped, so FS is a real tab character and
    # splits the tab-separated line into two fields.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b\n', b'')


def test_fs_assignment_affects_only_later_records(run):
    """Assigning FS re-splits the next record, not the current one."""
    result = run(['-F', ',', '{ FS=":"; print NR, NF, $1, $2 }'],
                 stdin=b"a,b\nc:d\n")
    # CATCHES: record 1 keeps the FS it was read with (2 fields 'a','b')
    # while record 2 is already split on the new ':' FS.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 2 a b\n2 2 c d\n', b'')


def test_fs_assignment_does_not_resplit_current_record(run):
    """A field reference after FS assignment keeps the old split."""
    result = run(['-F', ',', '{ FS=":"; print NF; $1=$1; print NF, $2 }'],
                 stdin=b"a,b,c\n")
    # CATCHES: NF stays 3 and $2 stays 'b' even after $1=$1 forces a
    # field operation; the record is never re-split with the new FS.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3\n3 b\n', b'')


def test_invalid_regex_fs_errors(run):
    """A multi-character FS that is an invalid regex is a fatal error."""
    result = run(['{ FS="[a"; print NF }'], stdin=b"ab\n")
    # CATCHES: the regex is compiled when FS is assigned, so a bad pattern
    # aborts with the invalid-regex error and exit status 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'invalid regex "[a": error parsing regexp: missing closing ]: `[a)`\n')


def test_field_assignment_beyond_nf_extends_record(run):
    """Assigning $n for n>NF pads with empty fields joined by OFS."""
    result = run(['{ $5 = "z"; print NF; print "[" $0 "]" }'], stdin=b"a b\n")
    # CATCHES: $2..$4 become empty strings and $0 is rebuilt with the
    # default OFS (single space), giving 'a b   z'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'5\n[a b   z]\n', b'')


@pytest.mark.parametrize("nf,expected", [
    (2, b'2\n[a b]\n'),      # truncate
    (5, b'5\n[a b c  ]\n'),  # pad with empty fields
    (0, b'0\n[]\n'),         # clear all fields
])
def test_nf_assignment(run, nf, expected):
    """Assigning NF truncates, pads, or clears the current record."""
    result = run(['{ NF = %d; print NF; print "[" $0 "]" }' % nf],
                 stdin=b"a b c\n")
    # CATCHES: NF=2 drops the third field from $0, NF=5 appends empties,
    # and NF=0 empties $0 entirely.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, expected, b'')


def test_nf_negative_is_an_error(run):
    """NF may not be set to a negative number."""
    result = run(['{ NF = -1 }'], stdin=b"a\n")
    # CATCHES: the assignment aborts the program with the exact negative
    # value message and exit status 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'NF set to negative value: -1\n')


def test_nf_too_large_is_an_error(run):
    """NF above 1,000,000 is rejected."""
    result = run(['{ NF = 1000001 }'], stdin=b"a\n")
    # CATCHES: the 1,000,000 field limit applies to NF assignment too, with
    # its own message.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'NF set too large: 1000001\n')


def test_field_index_too_large_on_assignment(run):
    """Assigning $1000001 errors; reading it is just empty."""
    result = run(['{ $1000001 = "x" }'], stdin=b"a\n")
    # CATCHES: assignment to an out-of-range field index is fatal with the
    # exact message, while reading the same index yields "".
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'field index too large: 1000001\n')
    read = run(['{ print "[" $1000001 "]" }'], stdin=b"a\n")
    assert (read.returncode, read.stdout, read.stderr) == (0, b'[]\n', b'')


def test_field_index_limit_is_inclusive(run):
    """$1000000 is the largest assignable field index."""
    result = run(['{ $1000000 = "x"; print NF }'], stdin=b"a\n")
    # CATCHES: the maximum field index is exactly 1,000,000; the assignment
    # succeeds and NF reports the new size.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1000000\n', b'')


def test_dollar0_assignment_resplits(run):
    """Assigning $0 re-splits it into fields using FS."""
    result = run(['-F', ',', '{ $0 = "a,b"; print NF, $1, $2 }'], stdin=b"x\n")
    # CATCHES: after $0 is replaced the fields come from the new text split
    # by the current FS, not from the original record.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 a b\n', b'')


def test_field_assignment_with_regex_fs_rejoins_with_ofs(run):
    """After a field assignment $0 is rebuilt with OFS, not FS."""
    result = run(['-F', 'X+', '{ $1 = "Y"; print "[" $0 "]" }'], stdin=b"aXbXc\n")
    # CATCHES: $0 becomes 'Y b c' (space-joined) even though the fields were
    # split by the X+ regex.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'[Y b c]\n', b'')


def test_assign_field_after_nf_truncate(run):
    """Assigning a field after truncation re-extends the record."""
    result = run(['-F', ',', '{ NF=2; $3="z"; print NF, "[" $0 "]" }'],
                 stdin=b"a,b,c\n")
    # CATCHES: after NF=2 the third field was dropped; assigning $3 again
    # brings the record back to three fields, joined by OFS.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 [a b z]\n', b'')


def test_negative_field_index_counts_from_right(run):
    """$-1 refers to the last field."""
    result = run(['{ print $-1 }'], stdin=b"a b c\n")
    # CATCHES: negative indexes count from the right, so $-1 prints 'c'
    # without error.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'c\n', b'')


def test_assign_beyond_nf_via_expression(run):
    """$(NF+1) appends a field."""
    result = run(['{ $(NF+1) = "c"; print NF, "[" $0 "]" }'], stdin=b"a b\n")
    # CATCHES: a computed index works like a literal one, appending the
    # new field to the record.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'3 [a b c]\n', b'')


def test_split_two_args_uses_csv_in_csv_mode(run):
    """In CSV mode the two-argument split() splits CSV, ignoring FS."""
    result = run(['-i', 'csv',
                  'BEGIN { n = split("x,\\"y,z\\"", a); print n, a[1], a[2] }'],
                 stdin=b"x\n")
    # CATCHES: the quoted field 'y,z' stays one element, showing CSV
    # parsing is used for split() in CSV input mode.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'2 x y,z\n', b'')
