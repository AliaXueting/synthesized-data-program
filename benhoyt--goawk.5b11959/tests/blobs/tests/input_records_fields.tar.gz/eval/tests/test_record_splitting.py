"""Record splitting via RS: default newline, single-character separators,
multi-character regexes, paragraph mode, RT, CRLF handling and the record
length limit."""

import pytest

# 10 MiB is the maximum record length the reference supports.
LIMIT = 10485760


def test_default_rs_processes_trailing_record(run):
    """A final record without its separator is still processed."""
    result = run(['{ print NR, "[" $0 "]", "RT=[" RT "]" }'], stdin=b"a\nb")
    # CATCHES: the unterminated last record is returned as a record, and for
    # the default single-char RS, RT always reports RS itself even though
    # the last record had no terminator.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [a] RT=[\n]\n2 [b] RT=[\n]\n', b'')


@pytest.mark.parametrize("rs", [b"X", b"*"])
def test_single_char_rs_splits_literal(run, rs):
    """A one-character RS splits on that literal byte, regex or not."""
    result = run(['-v', 'RS=' + rs.decode(), '{ print NR, "[" $0 "]" }'],
                 stdin=rs.join([b"a", b"b", b"c"]))
    # CATCHES: a single-char RS is literal, so even regex metacharacters
    # like '*' separate records instead of matching empty.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [a]\n2 [b]\n3 [c]\n', b'')


def test_single_char_rs_with_trailing_separator(run):
    """A trailing RS produces no extra empty record."""
    result = run(['-v', 'RS=X', '{ print NR, "[" $0 "]" }'], stdin=b"aXbX")
    # CATCHES: input ending in the separator yields exactly two records;
    # no empty third record is emitted.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [a]\n2 [b]\n', b'')


def test_multichar_rs_is_regex_with_rt(run):
    """A multi-character RS is a regex; RT is the matched text."""
    result = run(['-v', 'RS=XY', '{ print NR, "[" $0 "]", "RT=[" RT "]" }'],
                 stdin=b"aXYbXYc")
    # CATCHES: RT holds the actual terminator text for each record and
    # becomes the empty string for a final unterminated record.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [a] RT=[XY]\n2 [b] RT=[XY]\n3 [c] RT=[]\n', b'')


def test_regex_rs_leftmost_longest(run):
    """Regex RS uses leftmost-longest matching."""
    result = run(['-v', 'RS=a|ab', '{ print NR, "[" $0 "]", "RT=[" RT "]" }'],
                 stdin=b"zabz")
    # CATCHES: at the same start position the longer alternative 'ab' wins
    # for both the split and RT.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [z] RT=[ab]\n2 [z] RT=[]\n', b'')


def test_regex_rs_with_quantifier(run):
    """RS regexes may match runs of varying length."""
    result = run(['-v', 'RS=ab+', '{ print NR, "[" $0 "]", "RT=[" RT "]" }'],
                 stdin=b"abba abb ab")
    # CATCHES: each terminator match consumes the whole 'ab+' run, so the
    # record count and RT lengths reflect greedy matching.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [] RT=[abb]\n2 [a ] RT=[abb]\n3 [ ] RT=[ab]\n', b'')


def test_multibyte_single_char_rs(run):
    """A single multi-byte character RS goes through the regex path."""
    result = run(['-v', 'RS=é', '{ print NR, "[" $0 "]", "RT=[" RT "]" }'],
                 stdin="aéb".encode())
    # CATCHES: a two-byte RS still splits on the whole character and RT is
    # the UTF-8 bytes of it (empty for the unterminated last record).
    assert (result.returncode, result.stdout, result.stderr) == (
        0, '1 [a] RT=[é]\n2 [b] RT=[]\n'.encode(), b'')


def test_paragraph_mode_splits_and_resplits_fields(run):
    """RS='' is paragraph mode; fields are re-split on whitespace."""
    result = run(['-v', 'RS=', '{ print NR, "[" $0 "]", "NF=" NF, "RT=[" RT "]" }'],
                 stdin=b"para1 l1\npara1 l2\n\n\npara2 l1\n\npara3\n\n")
    # CATCHES: paragraphs are separated by runs of blank lines, embedded
    # newlines stay inside $0, NF counts whitespace-separated fields across
    # lines, and RT is the full blank-line run that ended the paragraph.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [para1 l1\npara1 l2] NF=4 RT=[\n\n\n]\n'
           b'2 [para2 l1] NF=2 RT=[\n\n]\n'
           b'3 [para3] NF=1 RT=[\n\n]\n', b'')


def test_paragraph_mode_strips_leading_trailing_blanks(run):
    """Leading and trailing blank lines are dropped in paragraph mode."""
    result = run(['-v', 'RS=', '{ print NR, "[" $0 "]" }'],
                 stdin=b"\n\nfirst\n\n\nlast\n\n\n")
    # CATCHES: blank runs at the very start and end of input do not produce
    # empty records; only two paragraphs are seen.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [first]\n2 [last]\n', b'')


def test_paragraph_mode_only_blank_lines(run):
    """Input of only blank lines produces no records at all."""
    result = run(['-v', 'RS=', '{ print NR, "[" $0 "]" } END { print "END", NR }'],
                 stdin=b"\n\n\n")
    # CATCHES: all-blank input is fully skipped without a final empty
    # record, so NR stays 0 and only the END marker prints (emitting a
    # trailing empty paragraph would give "1 []" and "END 1").
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'END 0\n', b'')


def test_paragraph_mode_unterminated_record(run):
    """A paragraph without a trailing blank run is still processed."""
    result = run(['-v', 'RS=', '{ print NR, "[" $0 "]", "RT=[" RT "]" }'],
                 stdin=b"last")
    # CATCHES: at EOF the final paragraph is returned with RT set to the
    # empty string because no terminator was consumed.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [last] RT=[]\n', b'')


def test_paragraph_mode_crlf_terminators(run):
    """CRLF blank runs work as paragraph separators and set RT."""
    result = run(['-v', 'RS=', '{ print NR, "[" $0 "]", "RT=[" RT "]" }'],
                 stdin=b"a\r\n\r\n\r\nb\r\n")
    # CATCHES: the CR is stripped from the record text but RT contains the
    # whole raw blank run including the CR bytes.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [a] RT=[\n\r\n\r\n]\n2 [b] RT=[\r\n]\n', b'')


def test_paragraph_mode_single_char_fs_splits_newlines(run):
    """RS='' with a single-char FS also splits fields on newlines."""
    result = run(['-v', 'RS=', '-F', ',', '{ print NR, NF, $1, $2, $3 }'],
                 stdin=b"a,b\nc:d\n\nx,y\n")
    # CATCHES: the POSIX multiple-line rule makes a one-character FS split
    # on embedded newlines too, so 'b\nc:d' becomes two fields.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 3 a b c:d\n2 2 x y \n', b'')


def test_crlf_input_drops_cr_with_default_rs(run):
    """CRLF line endings are stripped of the CR by the default RS."""
    result = run(['{ print NR, "[" $0 "]" }'], stdin=b"one\r\ntwo\r\n")
    # CATCHES: $0 contains no carriage return when RS is the default
    # newline splitter.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [one]\n2 [two]\n', b'')


def test_crlf_kept_with_single_char_rs(run):
    """With a non-newline single-char RS the CR stays in the record."""
    result = run(['-v', 'RS=X', '{ print NR, "[" $0 "]" }'],
                 stdin=b"one\r\nXtwo\r\n")
    # CATCHES: CR stripping only happens for the default newline splitter,
    # so records keep their '\r\n' bytes verbatim.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [one\r\n]\n2 [two\r\n]\n', b'')


def test_rs_change_in_begin(run):
    """Assigning RS in BEGIN configures the record scanner."""
    result = run(['BEGIN { RS="a" } { print NR, "[" $0 "]" }'], stdin=b"1a2b3")
    # CATCHES: an RS set before any input is read takes effect for all
    # records.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [1]\n2 [2b3]\n', b'')


def test_rs_change_midstream_is_ignored(run):
    """Changing RS while a file is being scanned has no effect."""
    result = run(['{ if (NR==1) RS="ZW"; print NR, "[" $0 "]", "RT=[" RT "]" }'],
                 stdin=b"1XY2ZW3")
    # CATCHES: the scanner for the current input was already built, so the
    # whole input stays one record and RT reflects the RS in force when the
    # record was read ('\n').
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [1XY2ZW3] RT=[\n]\n', b'')


def test_empty_match_regex_rs(run):
    """An RS regex that matches empty returns the whole input once."""
    result = run(['-v', 'RS=()', '{ print NR, "[" $0 "]", "RT=[" RT "]" }'],
                 stdin=b"abc")
    # CATCHES: a zero-width match never splits the record; the entire input
    # is one record with RT empty.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'1 [abc] RT=[]\n', b'')


def test_record_over_limit_errors(run, write):
    """A record longer than 10 MiB is a fatal read error."""
    write("big.txt", b"x" * (LIMIT + 524288) + b"\n")
    result = run(['{ print length($0) }', 'big.txt'])
    # CATCHES: the over-long record aborts with the exact token-too-long
    # message on stderr and exit status 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'error reading from input: bufio.Scanner: token too long\n')


@pytest.mark.parametrize("size,expected", [
    (LIMIT - 1, b'10485759\n'),   # just under the limit: fine
    (LIMIT, b''),                 # exactly at the limit: too long
])
def test_record_length_boundary(run, write, size, expected):
    """The record length limit is exactly 10 MiB."""
    write("big.txt", b"x" * size + b"\n")
    result = run(['{ print length($0) }', 'big.txt'])
    # CATCHES: a record of 10485759 bytes plus newline parses, while
    # 10485760 bytes already trips the scanner limit (rc=1).
    if expected:
        assert (result.returncode, result.stdout, result.stderr) == (
            0, expected, b'')
    else:
        assert (result.returncode, result.stdout, result.stderr) == (
            1, b'', b'error reading from input: bufio.Scanner: token too long\n')


def test_record_over_limit_from_stdin(run):
    """The record limit applies to stdin input as well."""
    result = run(['{ print }'], stdin=b"y" * (LIMIT + 1) + b"\n")
    # CATCHES: stdin uses the same scanner limit, so the same error text
    # and exit status 1 result.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b'', b'error reading from input: bufio.Scanner: token too long\n')
