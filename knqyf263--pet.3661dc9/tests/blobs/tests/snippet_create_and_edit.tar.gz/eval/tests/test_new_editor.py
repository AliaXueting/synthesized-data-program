"""The ``-e/--editor`` path of ``pet new`` (createAndEditSnippet/countSnippetLines).

`pet new -e` skips every prompt, saves an empty snippet, and then opens the
configured editor at a line computed from the previous file length.
Expectations recorded from ``./executable``.
"""

from __future__ import annotations

from conftest import make_recorder, make_script, run_pet, write_config, write_file

EMPTY_SNIPPET = (
    '\n[[Snippets]]\n  Description = ""\n  Output = ""\n  Tag = []\n  command = ""\n'
)


def _setup(tmp_path, content=""):
    snippet = write_file(tmp_path / "snippets.toml", content)
    return snippet


def test_editor_starts_at_line_three_for_an_empty_file(tmp_path):
    """An empty snippet file yields the `+3` start line."""
    snippet = _setup(tmp_path)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: the start line is CountLines(file)+3, so an empty file (0 lines)
    # positions the editor on line 3, right where the new snippet was appended.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert args.read_text() == "argc=2\narg=+3\narg=%s\n" % snippet
    assert snippet.read_text() == EMPTY_SNIPPET


def test_editor_start_line_is_newline_count_plus_three(tmp_path):
    """A populated file positions the editor three lines past its line count."""
    base = (
        '\n[[Snippets]]\n  Description = "a"\n  Output = ""\n  Tag = []\n'
        '  command = "aa"\n\n[[Snippets]]\n  Description = "b"\n  Output = ""\n'
        '  Tag = []\n  command = "bb"\n'
    )
    snippet = _setup(tmp_path, base)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: base holds 12 '\n' bytes, so the editor is asked for +15 -- the
    # appended empty snippet sits exactly there after the rewrite.
    assert res.returncode == 0
    assert args.read_text() == "argc=2\narg=+15\narg=%s\n" % snippet
    assert snippet.read_text() == base + EMPTY_SNIPPET


def test_editor_start_line_counts_bytes_not_displayed_lines(tmp_path):
    """A file without a trailing newline counts its 2 '\n' bytes as 2 lines."""
    snippet = _setup(tmp_path, '[[Snippets]]\n  Description = "x"\n  command = "y"')
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: CountLines() only counts '\n' bytes, so the final unterminated
    # line is invisible and the start line is 2+3 rather than 3+3.
    assert res.returncode == 0
    assert args.read_text() == "argc=2\narg=+5\narg=%s\n" % snippet


def test_editor_start_line_ignores_carriage_returns(tmp_path):
    """CRLF blank lines count once each: 3 '\\n' bytes give +6."""
    snippet = _setup(tmp_path, "\r\n\r\n\r\n")
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: the line separator used by CountLines() is exactly {'\n'}, so the
    # '\r' halves of the CRLF pairs do not add to the count.
    assert res.returncode == 0
    assert args.read_text() == "argc=2\narg=+6\narg=%s\n" % snippet


def test_editor_nonzero_exit_is_reported_after_the_save(tmp_path):
    """An editor that fails still leaves the saved empty snippet behind."""
    snippet = _setup(tmp_path)
    editor = make_script(tmp_path, "exit 3", name="fail.sh")
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: createAndEditSnippet saves first, so the editor's `exit status 3`
    # is returned as a cobra error on stdout with exit 255 while the file keeps
    # the appended empty snippet.
    assert res.returncode == 255
    assert res.stdout == b"exit status 3\n"
    assert res.stderr == b""
    assert snippet.read_text() == EMPTY_SNIPPET


def test_editor_command_not_found_yields_127(tmp_path):
    """A missing editor binary surfaces sh's 127 plus its stderr."""
    snippet = _setup(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet),
                          editor="/nonexistent/editor-xyz")
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: run() executes the editor through `sh -c`, so a missing binary is
    # reported by the shell on stderr and the exit status is the shell's 127.
    assert res.returncode == 255
    assert res.stdout == b"exit status 127\n"
    assert res.stderr == b"sh: 1: /nonexistent/editor-xyz: not found\n"
    assert snippet.read_text() == EMPTY_SNIPPET


def test_editor_inherits_stdout_stderr_and_stdin(tmp_path):
    """The editor runs with pet's own stdin/stdout/stderr wired through."""
    snippet = _setup(tmp_path)
    editor = make_script(
        tmp_path, 'echo EDITOR-STDOUT; echo EDITOR-STDERR >&2; cat > "%s"'
        % (tmp_path / "editor-stdin.txt"),
        name="io.sh",
    )
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "new", "-e"],
                  stdin=b"STDIN-DATA\n", home=tmp_path)
    # CATCHES: editFile() calls run(command, os.Stdin, os.Stdout), so everything
    # the editor writes and reads goes to pet's own streams.
    assert res.returncode == 0
    assert res.stdout == b"EDITOR-STDOUT\n"
    assert res.stderr == b"EDITOR-STDERR\n"
    assert (tmp_path / "editor-stdin.txt").read_text() == "STDIN-DATA\n"


def test_editor_flag_is_ignored_when_arguments_are_given(tmp_path):
    """`pet new -e echo hi` prompts for the description instead of editing."""
    snippet = _setup(tmp_path)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "new", "-e", "echo", "hi"],
                  stdin=b"the desc\n", home=tmp_path)
    # CATCHES: the UseEditor branch only runs when no positional args exist, so
    # the editor is never launched and the snippet is created from the prompts.
    assert res.returncode == 0
    assert res.stdout == b"Command> echo hi\n"
    assert not args.exists()
    assert snippet.read_text() == (
        '\n[[Snippets]]\n  Description = "the desc"\n'
        '  Output = ""\n  Tag = []\n  command = "echo hi"\n'
    )


def test_editor_runs_after_the_snippet_was_saved(tmp_path):
    """The empty snippet is already on disk when the editor starts."""
    snippet = _setup(tmp_path, '\n[[Snippets]]\n  Description = "a"\n  command = "aa"\n')
    editor = make_script(
        tmp_path, 'printf "tail\\n" >> "%s"' % snippet, name="append.sh"
    )
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: Save() runs before editFile(), so whatever the editor appends
    # lands after the canonical block of the freshly appended empty snippet
    # (and the pre-existing snippet is normalised on the same rewrite).
    assert res.returncode == 0
    assert snippet.read_text() == (
        '\n[[Snippets]]\n  Description = "a"\n  Output = ""\n  Tag = []\n'
        '  command = "aa"\n' + EMPTY_SNIPPET + "tail\n"
    )


def test_editor_invocation_is_shell_word_split(tmp_path):
    """The editor string plus `+N` and the path are joined and parsed by sh."""
    snippet = _setup(tmp_path)
    target = tmp_path / "sh-args.txt"
    editor = make_script(
        tmp_path,
        'printf \'%s\\n\' "$0" >> "' + str(target) + '"; '
        'for a in "$@"; do printf \'%s\\n\' "$a" >> "' + str(target) + '"; done',
        name="argv.sh",
    )
    config = write_config(tmp_path, snippetfile=str(snippet),
                          editor=str(editor) + "   extra")
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: editFile() builds one command string ("editor extra +3 path") and
    # hands it to `sh -c`, which splits it into four separate argv words.
    assert res.returncode == 0
    assert target.read_text() == "%s\nextra\n+3\n%s\n" % (editor, snippet)
