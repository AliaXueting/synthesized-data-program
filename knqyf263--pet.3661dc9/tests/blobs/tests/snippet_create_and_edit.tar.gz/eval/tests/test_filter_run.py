"""Resolving the selector's output in filter() (cmd/util.go).

The line(s) printed by ``General.selectcmd`` are mapped back to snippet
commands: one selection may open the parameter dialog, several are joined,
and a selector failure is swallowed.  Expectations recorded from
``./executable``.
"""

from __future__ import annotations

import pytest

from conftest import (
    make_script,
    make_selector,
    run_pet,
    run_pet_interactive,
    write_config,
    write_file,
)

GREET_AND_BYE = (
    '[[Snippets]]\n  Description = "greet"\n  command = "echo hello"\n\n'
    '[[Snippets]]\n  Description = "bye"\n  command = "echo bye"\n'
)


def _setup(tmp_path, main=GREET_AND_BYE, selection="", **kw):
    """Snippet file + selector stand-in + config; returns (main, record, out, config)."""
    main_path = write_file(tmp_path / "snippets.toml", main)
    selector, record, out = make_selector(tmp_path)
    out.write_text(selection)
    config = write_config(tmp_path, snippetfile=str(main_path),
                          selectcmd=str(selector), **kw)
    return main_path, record, out, config


def test_selected_command_is_echoed_and_run(tmp_path):
    """`pet exec` prints `> command` and then runs it through the shell."""
    _, _, _, config = _setup(tmp_path, selection="[greet]: echo hello \n")
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: the selected line is mapped back to the snippet's command,
    # echoed with a "> " prefix on stdout and executed via `sh -c`.
    assert res.returncode == 0
    assert res.stdout == b"> echo hello\nhello\n"
    assert res.stderr == b""


def test_two_selected_lines_are_joined_with_semicolon_space(tmp_path):
    """A multi-line selector output becomes one shell command joined by `; `."""
    _, _, _, config = _setup(
        tmp_path, selection="[greet]: echo hello \n[bye]: echo bye \n")
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: all selected lines are collected and joined into a single
    # `sh -c` invocation with "; " separators, so both commands run in one
    # shell and their outputs interleave in order.
    assert res.returncode == 0
    assert res.stdout == b"> echo hello; echo bye\nhello\nbye\n"


def test_multiline_command_is_run_with_real_newlines(tmp_path):
    """The executed command keeps the real newlines shown as `\\n` to the selector."""
    main = ('[[Snippets]]\n  Description = "multi"\n'
            '  command = "echo one\\necho two"\n')
    _, _, _, config = _setup(tmp_path, main=main,
                             selection="[multi]: echo one\\necho two \n")
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: the `\n` escaping lives only in the line fed to the selector;
    # the `> ` echo and the executed command both contain real newlines.
    assert res.returncode == 0
    assert res.stdout == b"> echo one\necho two\none\ntwo\n"


@pytest.mark.parametrize("selection", [
    (""),
    ("[totally unknown line]: does not exist\n"),
], ids=["empty-output", "unknown-line"])
def test_unresolvable_selection_runs_an_empty_command(tmp_path, selection):
    """An empty or unknown selection maps to the empty command, not an error."""
    _, _, _, config = _setup(tmp_path, selection=selection)
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: a missing map key resolves to a zero-value snippet whose
    # command is "", so exec still prints its "> " line, runs `sh -c ""`
    # and exits 0.
    assert res.returncode == 0
    assert res.stdout == b"> \n"
    assert res.stderr == b""


def test_selector_nonzero_exit_is_swallowed_by_exec(tmp_path):
    """A selector exiting 42 is not an error for `pet exec`."""
    main = write_file(tmp_path / "snippets.toml", GREET_AND_BYE)
    failing = make_script(tmp_path, "exit 42", name="fail.sh")
    config = write_config(tmp_path, snippetfile=str(main), selectcmd=str(failing))
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: filter() discards the selector's error (returns nil, nil), so
    # unlike `pet edit` the exec path carries on with an empty command list
    # and exits 0.
    assert res.returncode == 0
    assert res.stdout == b"> \n"
    assert res.stderr == b""


@pytest.mark.parametrize("command,expected_stdout", [
    (["exec"], b"> \n"),
    (["search"], b""),
], ids=["exec", "search"])
def test_missing_selector_binary_is_swallowed(tmp_path, command, expected_stdout):
    """A missing selectcmd binary costs the shell's 127 but not a pet error."""
    main = write_file(tmp_path / "snippets.toml", GREET_AND_BYE)
    config = write_config(tmp_path, snippetfile=str(main),
                          selectcmd="/nonexistent/sel-xyz")
    res = run_pet(["--config", str(config)] + command, home=tmp_path)
    # CATCHES: the selector runs under `sh -c` with pet's stderr wired
    # through, so dash's `not found` line reaches stderr while the command
    # itself still succeeds with rc 0.
    assert res.returncode == 0
    assert res.stdout == expected_stdout
    assert res.stderr == b"sh: 1: /nonexistent/sel-xyz: not found\n"


def test_query_flag_is_passed_to_the_selector(tmp_path):
    """`-q` appends a shell-quoted `--query <value>` to the select command."""
    _, record, _, config = _setup(tmp_path, selection="[greet]: echo hello \n")
    res = run_pet(["--config", str(config), "exec", "-q", "echo one"],
                  home=tmp_path)
    # CATCHES: the query is appended to the selectcmd string as
    # `--query <shellescape.Quote(value)>` and word-split by the shell into
    # two selector arguments.
    assert res.returncode == 0
    assert record.read_text().startswith("argc=2\narg=--query\narg=echo one\n")
    assert res.stdout == b"> echo hello\nhello\n"


def test_param_command_without_a_tty_panics(tmp_path):
    """Selecting a `<param>` command without a terminal crashes the dialog."""
    main = ('[[Snippets]]\n  Description = "param"\n  command = "echo <name>"\n')
    _, _, _, config = _setup(tmp_path, main=main,
                             selection="[param]: echo <name> \n")
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: a single selected line containing a <param> opens the gocui
    # parameter dialog, which cannot start without /dev/tty and panics
    # (exit code 2) instead of running the command.
    assert res.returncode == 2
    assert res.stdout == b""
    assert b"panic: failed to initialize tcell screen: open /dev/tty" in res.stderr


def _dialog_workspace(tmp_path, command):
    """Snippet with a param'd COMMAND + selector returning its line."""
    main = write_file(tmp_path / "snippets.toml",
                      '[[Snippets]]\n  Description = "param"\n  command = "%s"\n'
                      % command)
    selector, _, out = make_selector(tmp_path)
    out.write_text("[param]: %s \n" % command)
    config = write_config(tmp_path, snippetfile=str(main), selectcmd=str(selector))
    return config


def test_param_dialog_fills_the_placeholder_on_a_tty(tmp_path):
    """On a tty the param dialog substitutes the typed value and runs the result."""
    config = _dialog_workspace(tmp_path, "echo hello <name>")
    rc, tty = run_pet_interactive(["--config", str(config), "exec"],
                                  ["myvalue\r"], home=tmp_path,
                                  line_delay=0.6, initial_delay=0.6)
    # CATCHES: a single param'd selection opens the gocui dialog; the typed
    # text replaces the <name> placeholder and filter() returns exactly that
    # one filled-in command, which exec echoes with "> " and executes.
    assert rc == 0
    assert tty.endswith(b"> echo hello myvalue\r\nhello myvalue\r\n")


def test_param_dialog_uses_the_default_value_on_enter(tmp_path):
    """`<name=bob>` pre-fills the dialog, so a bare ENTER runs the default."""
    config = _dialog_workspace(tmp_path, "echo hello <name=bob>")
    rc, tty = run_pet_interactive(["--config", str(config), "exec"], ["\r"],
                                  home=tmp_path,
                                  line_delay=0.6, initial_delay=0.6)
    # CATCHES: the text after `=` inside the placeholder becomes the view's
    # initial content, so pressing ENTER without typing substitutes `bob`.
    assert rc == 0
    assert tty.endswith(b"> echo hello bob\r\nhello bob\r\n")


def test_multiple_selection_skips_the_param_dialog(tmp_path):
    """With two lines selected the `<param>` command runs literally."""
    main = (
        '[[Snippets]]\n  Description = "quoted param"\n'
        '  command = "echo \\"value=<arg>\\""\n\n'
        '[[Snippets]]\n  Description = "plain"\n  command = "echo plain-text"\n'
    )
    _, _, _, config = _setup(
        tmp_path, main=main,
        selection='[quoted param]: echo "value=<arg>" \n[plain]: echo plain-text \n')
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: the parameter dialog only opens for a single selected line;
    # with several lines the params search is skipped entirely and the raw
    # commands (angle brackets included) are joined and executed.
    assert res.returncode == 0
    assert res.stdout == b'> echo "value=<arg>"; echo plain-text\nvalue=<arg>\nplain-text\n'


def test_search_prints_the_command_without_a_trailing_newline(tmp_path):
    """`pet search` writes the command with no newline while stdout is a pipe."""
    main = ('[[Snippets]]\n  Description = "solo"\n'
            '  command = "echo hello-search"\n')
    _, _, _, config = _setup(tmp_path, main=main,
                             selection="[solo]: echo hello-search \n")
    res = run_pet(["--config", str(config), "search"], home=tmp_path)
    # CATCHES: the newline after the command is only printed when stdout is
    # a terminal, so a piped `pet search` emits exactly the command bytes.
    assert res.returncode == 0
    assert res.stdout == b"echo hello-search"
    assert res.stderr == b""


def test_search_appends_a_newline_on_a_tty(tmp_path):
    """On a terminal `pet search` terminates the command with a newline."""
    main = ('[[Snippets]]\n  Description = "solo"\n'
            '  command = "echo hello-pty"\n')
    main_path = write_file(tmp_path / "snippets.toml", main)
    selector, _, out = make_selector(tmp_path)
    out.write_text("[solo]: echo hello-pty \n")
    config = write_config(tmp_path, snippetfile=str(main_path), selectcmd=str(selector))
    rc, tty = run_pet_interactive(["--config", str(config), "search"], [],
                                  home=tmp_path)
    # CATCHES: term.IsTerminal(1) gates the trailing newline, so on a pty the
    # command line is terminated (the pty itself turns \n into \r\n).
    assert rc == 0
    assert tty == b"echo hello-pty\r\n"


@pytest.mark.parametrize("delimiter_args,expected", [
    ([], b"echo hello; echo bye"),
    (["-d", " && "], b"echo hello && echo bye"),
], ids=["default-semicolon", "custom-delimiter"])
def test_search_joins_multiple_selections_with_the_delimiter(
        tmp_path, delimiter_args, expected):
    """Several selected commands are joined by `; ` or the -d delimiter."""
    _, _, _, config = _setup(
        tmp_path, selection="[greet]: echo hello \n[bye]: echo bye \n")
    res = run_pet(["--config", str(config), "search"] + delimiter_args,
                  home=tmp_path)
    # CATCHES: search joins the resolved commands with the configured
    # delimiter ("; " by default, overridable with -d) and still adds no
    # trailing newline off-tty.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_search_raw_prints_a_param_command_verbatim(tmp_path):
    """`--raw` skips the parameter dialog and prints the command untouched."""
    main = ('[[Snippets]]\n  Description = "param"\n'
            '  command = "echo <greeting-word>"\n')
    _, _, _, config = _setup(tmp_path, main=main,
                             selection="[param]: echo <greeting-word> \n")
    res = run_pet(["--config", str(config), "search", "--raw"], home=tmp_path)
    # CATCHES: with --raw the params search is bypassed even for a single
    # selected line, so the <placeholder> reaches stdout verbatim and the
    # exit status stays 0.
    assert res.returncode == 0
    assert res.stdout == b"echo <greeting-word>"
    assert res.stderr == b""
