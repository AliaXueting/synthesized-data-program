"""Multi-line command entry of ``pet new -m`` (cmd/new.go scanMultiLine()).

The state machine ignores leading empty lines, ends on two consecutive empty
lines and joins everything else with newlines.  Expectations recorded from
``./executable``.
"""

from __future__ import annotations

from conftest import run_pet, run_pet_interactive, run_pet_pty, write_config, write_file


def _setup(tmp_path, content="", **kw):
    snippet = write_file(tmp_path / "snippets.toml", content)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true", **kw)
    return snippet, config


def _saved(command_body, description="the desc"):
    """The canonical TOML block for a command whose file body is COMMAND_BODY.

    COMMAND_BODY is the literal text that sits between the quotes of the
    ``command =`` value, i.e. newlines are already spelled ``\\n``.
    """
    return (
        '\n[[Snippets]]\n  Description = "%s"\n'
        '  Output = ""\n  Tag = []\n  command = "%s"\n' % (description, command_body)
    )


def test_multiline_joins_lines_and_terminates_on_two_blanks(tmp_path):
    """Two consecutive blank lines end entry; inner newlines are kept."""
    snippet, config = _setup(tmp_path)
    rc, stdout, stderr = run_pet_pty(
        ["--config", str(config), "new", "-m"],
        ["line1\n", "line2\n", "\n", "\n", "the desc\n"],
        home=tmp_path,
    )
    # CATCHES: the saved command stores a real embedded newline, which the TOML
    # encoder writes back as a two-character \n escape.
    assert rc == 0
    assert stdout == b""
    assert stderr == b""
    assert snippet.read_text() == _saved("line1\\nline2")


def test_multiline_leading_blank_lines_are_ignored(tmp_path):
    """Empty lines typed before any content are skipped, not stored."""
    snippet, config = _setup(tmp_path)
    rc, stdout, _ = run_pet_pty(
        ["--config", str(config), "new", "-m"],
        ["\n", "\n", "first\n", "second\n", "\n", "\n", "the desc\n"],
        home=tmp_path,
    )
    # CATCHES: in the `start` state only a completely empty line continues the
    # loop, so the command starts at "first" with no leading newlines.
    assert rc == 0
    assert snippet.read_text() == _saved("first\\nsecond")


def test_multiline_single_blank_does_not_terminate(tmp_path):
    """One blank line followed by content continues the same command."""
    snippet, config = _setup(tmp_path)
    rc, stdout, _ = run_pet_pty(
        ["--config", str(config), "new", "-m"],
        ["one\n", "\n", "two\n", "\n", "\n", "the desc\n"],
        home=tmp_path,
    )
    # CATCHES: after a single blank line the machine is in lastLineEmpty and any
    # further content is appended, so only a *second* blank ends the input.
    assert rc == 0
    assert snippet.read_text() == _saved("one\\ntwo")


def test_multiline_whitespace_only_line_is_content(tmp_path):
    """A line of spaces is not blank for the state machine."""
    snippet, config = _setup(tmp_path)
    rc, stdout, _ = run_pet_pty(
        ["--config", str(config), "new", "-m"],
        ["one\n", "   \n", "two\n", "\n", "\n", "the desc\n"],
        home=tmp_path,
    )
    # CATCHES: scanMultiLine compares `line == ""` without TrimSpace, so a
    # whitespace line is preserved verbatim inside the command.
    assert rc == 0
    assert snippet.read_text() == _saved("one\\n   \\ntwo")


def test_multiline_leading_whitespace_line_is_content(tmp_path):
    """A leading line of spaces becomes the first command line."""
    snippet, config = _setup(tmp_path)
    rc, stdout, _ = run_pet_pty(
        ["--config", str(config), "new", "-m"],
        ["  \n", "one\n", "\n", "\n", "the desc\n"],
        home=tmp_path,
    )
    # CATCHES: only truly empty leading lines are ignored; "  " is stored as the
    # first line, unlike the single-line scan() which trims.
    assert rc == 0
    assert snippet.read_text() == _saved("  \\none")


def test_multiline_single_line_then_two_blanks(tmp_path):
    """A one-line command still needs the two blank lines to finish."""
    snippet, config = _setup(tmp_path)
    rc, stdout, _ = run_pet_pty(
        ["--config", str(config), "new", "-m"],
        ["only\n", "\n", "\n", "the desc\n"],
        home=tmp_path,
    )
    # CATCHES: even a single-line command is stored unchanged (no trimming, no
    # trailing newline) once the double blank arrives.
    assert rc == 0
    assert snippet.read_text() == _saved("only")


def test_multiline_eof_without_terminator_cancels(tmp_path):
    """EOF before the double blank line reports `canceled` and saves nothing."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "-m"],
                  stdin=b"one\ntwo\n", home=tmp_path)
    # CATCHES: leaving the multi-line state machine via EOF returns a fresh
    # `canceled` error, so no snippet is written.
    assert res.returncode == 255
    assert res.stdout == b"canceled\n"
    assert res.stderr == b""
    assert snippet.read_text() == ""


def test_multiline_ctrl_c_on_empty_line_cancels(tmp_path):
    """^C on an empty multi-line line aborts entry."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "-m"],
                  stdin=b"one\n\x03", home=tmp_path)
    # CATCHES: ErrInterrupt with an empty line breaks out of the loop and the
    # collected text is discarded.
    assert res.returncode == 255
    assert res.stdout == b"canceled\n"
    assert snippet.read_text() == ""


def test_multiline_uses_the_dots_continuation_prompt(tmp_path):
    """After the first line the prompt switches to the `.......> ` form."""
    snippet, config = _setup(tmp_path)
    rc, stdout = run_pet_interactive(
        ["--config", str(config), "new", "-m"],
        ["line1\n", "line2\n", "\n", "\n", "the desc\n"],
        home=tmp_path,
    )
    # CATCHES: scanMultiLine calls SetPrompt with color.YellowString(".......> ")
    # (plain yellow, not HiYellow) once the first line has been accepted.
    assert rc == 0
    assert b"\x1b[33mCommand> \x1b[0m" in stdout
    assert b"\x1b[33m.......> \x1b[0m" in stdout
    assert stdout.count(b"\x1b[33m.......> \x1b[0m") >= 2
    assert snippet.read_text() == _saved("line1\\nline2")


def test_multiline_flag_is_ignored_when_args_are_given(tmp_path):
    """`pet new -m echo hi` behaves like the plain positional form."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "-m", "echo", "hi"],
                  stdin=b"the desc\n", home=tmp_path)
    # CATCHES: the `len(args) > 0` branch is taken before the multiline flag is
    # consulted, so no multi-line prompt ever appears.
    assert res.returncode == 0
    assert res.stdout == b"Command> echo hi\n"
    assert snippet.read_text() == _saved("echo hi", "the desc")
