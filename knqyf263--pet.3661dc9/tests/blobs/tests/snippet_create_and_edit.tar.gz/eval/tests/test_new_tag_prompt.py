"""The ``-t/--tag`` prompt of ``pet new`` (cmd/new.go).

The tag prompt is asked after the description, is allowed to be empty, and its
answer is split on whitespace.  Expectations recorded from ``./executable``.
"""

from __future__ import annotations

from conftest import run_pet, run_pet_interactive, run_pet_pty, write_config, write_file


def _setup(tmp_path, content=""):
    snippet = write_file(tmp_path / "snippets.toml", content)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true")
    return snippet, config


def _saved(tag_body, description="the desc", command="echo hi"):
    """Canonical TOML for one snippet whose Tag list body is TAG_BODY."""
    return (
        '\n[[Snippets]]\n  Description = "%s"\n'
        '  Output = ""\n  Tag = %s\n  command = "%s"\n'
        % (description, tag_body, command)
    )


def test_tag_prompt_splits_the_answer_on_spaces(tmp_path):
    """`-t` asks a third question whose words become the tag list."""
    snippet, config = _setup(tmp_path)
    rc, stdout, stderr = run_pet_pty(
        ["--config", str(config), "new", "-t"],
        ["echo hi\n", "the desc\n", "tagA tagB\n"],
        home=tmp_path,
    )
    # CATCHES: strings.Fields() splits on any whitespace run, so the two words
    # become a two-element Tag array in the saved TOML.
    assert rc == 0
    assert stdout == b""
    assert stderr == b""
    assert snippet.read_text() == _saved('["tagA", "tagB"]')


def test_tag_prompt_collapses_repeated_whitespace(tmp_path):
    """Runs of spaces around and between tags produce a clean list."""
    snippet, config = _setup(tmp_path)
    rc, stdout, _ = run_pet_pty(
        ["--config", str(config), "new", "-t"],
        ["echo hi\n", "the desc\n", "  a   b  \n"],
        home=tmp_path,
    )
    # CATCHES: the answer is not trimmed by scan() but Fields() ignores the
    # leading/trailing/duplicated spaces when building the list.
    assert rc == 0
    assert snippet.read_text() == _saved('["a", "b"]')


def test_tag_prompt_empty_answer_means_no_tags(tmp_path):
    """An empty tag answer stores an empty Tag list."""
    snippet, config = _setup(tmp_path)
    rc, stdout, _ = run_pet_pty(
        ["--config", str(config), "new", "-t"],
        ["echo hi\n", "the desc\n", "\n"],
        home=tmp_path,
    )
    # CATCHES: the tag prompt is the only one created with allowEmpty=true, so
    # an empty line returns immediately instead of re-prompting.
    assert rc == 0
    assert snippet.read_text() == _saved("[]")


def test_tag_prompt_whitespace_answer_means_no_tags(tmp_path):
    """A whitespace-only tag answer also stores no tags."""
    snippet, config = _setup(tmp_path)
    rc, stdout, _ = run_pet_pty(
        ["--config", str(config), "new", "-t"],
        ["echo hi\n", "the desc\n", "   \n"],
        home=tmp_path,
    )
    # CATCHES: scan() trims the line to "" which, with allowEmpty=true, is
    # returned as an empty tag string and then skipped by the `if t != ""`.
    assert rc == 0
    assert snippet.read_text() == _saved("[]")


def test_tag_prompt_is_asked_after_the_description(tmp_path):
    """Without -t no tag prompt exists and the snippet has no Tag."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "echo", "hi"],
                  stdin=b"the desc\n", home=tmp_path)
    # CATCHES: the Tag prompt only exists behind the flag, so a plain run stores
    # an empty list rather than reading a third line.
    assert res.returncode == 0
    assert snippet.read_text() == _saved("[]")


def test_tag_prompt_eof_cancels_the_whole_snippet(tmp_path):
    """EOF at the tag prompt discards the already-collected fields."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "-t", "echo", "hi"],
                  stdin=b"the desc\n", home=tmp_path)
    # CATCHES: the tag prompt is a separate readline instance, so EOF there
    # yields `canceled` and nothing is written even though the command and the
    # description were already answered.
    assert res.returncode == 255
    assert res.stdout == b"Command> echo hi\ncanceled\n"
    assert snippet.read_text() == ""


def test_tag_prompt_is_ansi_hi_cyan(tmp_path):
    """On a tty the tag prompt uses the HiCyan escape."""
    snippet, config = _setup(tmp_path)
    rc, stdout = run_pet_interactive(
        ["--config", str(config), "new", "-t", "echo", "hi"],
        ["the desc\n", "x y\n"],
        home=tmp_path,
    )
    # CATCHES: the prompt string is color.HiCyanString("Tag> "), which is a
    # different colour code from the command/description prompts.
    assert rc == 0
    assert b"\x1b[96mTag> \x1b[0m" in stdout
    assert snippet.read_text() == _saved('["x", "y"]')


def test_tag_long_flag_and_false_spelling(tmp_path):
    """`--tag=false` and the default both skip the prompt."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "--tag=false", "echo", "hi"],
                  stdin=b"the desc\n", home=tmp_path)
    # CATCHES: only a truthy --tag enables the extra prompt; the explicit false
    # spelling behaves exactly like omitting the flag.
    assert res.returncode == 0
    assert res.stdout == b"Command> echo hi\n"
    assert snippet.read_text() == _saved("[]")
