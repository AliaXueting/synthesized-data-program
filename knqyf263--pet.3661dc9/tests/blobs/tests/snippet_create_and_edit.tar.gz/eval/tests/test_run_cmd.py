"""run()'s General.cmd branch (cmd/util_unix.go).

When ``General.cmd`` is configured, run() stops using ``sh -c`` entirely: the
command string is appended to the configured argv and executed as one single
argument.  Expectations recorded from ``./executable``.
"""

from __future__ import annotations

from conftest import make_script, make_selector, run_pet, write_config, write_file

A_SNIPPET = '[[Snippets]]\n  Description = "a"\n  command = "aa"\n'


def _recorder(tmp_path, log_name="args.txt", append=False):
    """A General.cmd stand-in recording its argv into LOG_NAME."""
    log = tmp_path / log_name
    body = (
        '{\n  echo "argc=$#"\n'
        '  for a in "$@"; do\n    echo "arg=$a"\n  done\n'
        '} %s "%s"\n' % (">>" if append else ">", log)
    )
    return make_script(tmp_path, body), log


def test_cmd_receives_the_whole_editor_invocation_as_one_argument(tmp_path):
    """With General.cmd set the `editor +0 path` string is one single argv."""
    snippet = write_file(tmp_path / "snippets.toml", A_SNIPPET)
    log = tmp_path / "args.txt"
    wrapper = make_script(
        tmp_path,
        '{\n  echo "argc=$#"\n'
        '  for a in "$@"; do\n    echo "arg=$a"\n  done\n'
        '} > "%s"\necho wrapper-ran\n' % log)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true",
                          cmd=[str(wrapper)])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: run() execs cmd[0] directly (no `sh -c`), so the whole
    # `true +0 <path>` invocation arrives as ONE argument and the wrapper's
    # stdout is wired straight to pet's own stdout.
    assert res.returncode == 0
    assert res.stdout == b"wrapper-ran\n"
    assert res.stderr == b""
    assert log.read_text() == "argc=1\narg=true +0 %s\n" % snippet


def test_cmd_leading_arguments_precede_the_command_string(tmp_path):
    """Extra General.cmd entries are prepended before the command string."""
    snippet = write_file(tmp_path / "snippets.toml", A_SNIPPET)
    wrapper, log = _recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true",
                          cmd=[str(wrapper), "pre1", "pre2"])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: cmd behaves like sudo/env wrappers -- every configured element
    # becomes its own argv word and the command string is only the last one.
    assert res.returncode == 0
    assert log.read_text() == "argc=3\narg=pre1\narg=pre2\narg=true +0 %s\n" % snippet


def test_editor_string_is_not_word_split_under_cmd(tmp_path):
    """An editor value containing spaces stays one unsplit argument."""
    snippet = write_file(tmp_path / "snippets.toml", A_SNIPPET)
    wrapper, log = _recorder(tmp_path)
    editor = str(wrapper) + "   extra"
    config = write_config(tmp_path, snippetfile=str(snippet), editor=editor,
                          cmd=[str(wrapper)])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: without `sh -c` nobody word-splits the editor string, so
    # `<wrapper>   extra +0 <path>` is handed over verbatim, spaces included.
    assert res.returncode == 0
    assert log.read_text() == "argc=1\narg=%s   extra +0 %s\n" % (wrapper, snippet)


def test_missing_cmd_binary_is_a_fork_exec_error(tmp_path):
    """A General.cmd[0] that does not exist is a fork/exec failure, not 127."""
    snippet = write_file(tmp_path / "snippets.toml", A_SNIPPET)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true",
                          cmd=["/nonexistent/wrap-xyz"])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: exec.Command reports the missing binary as a `fork/exec` error
    # on stdout with exit 255 -- unlike the sh -c path, which surfaces the
    # shell's own `not found` diagnostic and status 127 on stderr.
    assert res.returncode == 255
    assert res.stdout == b"fork/exec /nonexistent/wrap-xyz: no such file or directory\n"
    assert res.stderr == b""


def test_new_e_start_line_flows_through_cmd(tmp_path):
    """`pet new -e` computes its `+N` line before the cmd wrapper runs."""
    snippet = write_file(tmp_path / "snippets.toml", A_SNIPPET)
    wrapper, log = _recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true",
                          cmd=[str(wrapper)])
    res = run_pet(["--config", str(config), "new", "-e"], home=tmp_path)
    # CATCHES: the snippet file holds 3 '\n' bytes, so the empty snippet is
    # appended after a rewrite and the wrapper is asked for `true +6 <path>`
    # -- same start-line rule as the sh -c path, just a different runner.
    assert res.returncode == 0
    assert log.read_text() == "argc=1\narg=true +6 %s\n" % snippet


def test_cmd_wraps_the_selector_and_the_editor(tmp_path):
    """With snippetdirs, General.cmd wraps the selector run AND the editor."""
    main = write_file(tmp_path / "main.toml",
                      '[[Snippets]]\n  Description = "main one"\n'
                      '  command = "mc"\n')
    write_file(tmp_path / "dirA" / "a.toml",
               '[[Snippets]]\n  Description = "dir one"\n'
               '  command = "dc"\n')
    selector, record, out = make_selector(tmp_path)
    out.write_text("[dir one]: dc\n")
    log = tmp_path / "wraplog.txt"
    wrapper = make_script(
        tmp_path,
        '{\n  echo "argc=$#"\n'
        '  for a in "$@"; do\n    echo "arg=$a"\n  done\n'
        '} >> "%s"\nsh -c "$1"\n' % log)
    config = write_config(tmp_path, snippetfile=str(main), editor="true",
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")],
                          cmd=[str(wrapper)])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: both child invocations of the edit flow go through cmd[0]:
    # first `selectcmd ` (note the trailing space from the empty options
    # join), then `editor +0 <selected file>` once a snippet was chosen.
    assert res.returncode == 0
    assert log.read_text() == (
        "argc=1\narg=%s \nargc=1\narg=true +0 %s\n"
        % (selector, tmp_path / "dirA" / "a.toml")
    )
    assert record.read_text() == (
        "argc=0\nstdin:\n[main one]: mc\n[dir one]: dc\n"
    )
