"""``pet edit`` with snippetdirs: choosing the file via selectFile().

When General.snippetdirs is set, `pet edit` first builds one line per snippet,
feeds them to the configured ``selectcmd`` and opens whichever file the selected
line belongs to.  Expectations recorded from ``./executable``.
"""

from __future__ import annotations

from conftest import make_recorder, make_selector, run_pet, write_config, write_file

MAIN_FILE = (
    '\n[[Snippets]]\n  Description = "main one"\n  Output = ""\n  Tag = ["main"]\n'
    '  command = "main-cmd"\n'
)
MULTILINE_SNIPPET = (
    '\n[[Snippets]]\n  Description = "multi"\n  Output = ""\n  Tag = ["x", "y"]\n'
    '  command = "line1\\nline2"\n'
)


def _workspace(tmp_path, main=MAIN_FILE, dirs=("dirA",), dir_files=None):
    """Create main snippet file + snippetdirs; return (main, config builders)."""
    main_path = write_file(tmp_path / "snippets.toml", main)
    for name, content in (dir_files or {}).items():
        write_file(tmp_path / name, content)
    return main_path


def test_selector_receives_one_line_per_snippet(tmp_path):
    """The selector's stdin lists `[desc]: command #tag` per snippet."""
    main = _workspace(
        tmp_path,
        main=MAIN_FILE + MULTILINE_SNIPPET,
        dir_files={
            "dirA/a.toml": '\n[[Snippets]]\n  Description = "nested"\n'
                           '  command = "nc"\n',
            "dirA/sub/b.toml": '\n[[Snippets]]\n  Description = "deep"\n'
                               '  command = "dc"\n',
            "dirA/ignored.txt": "junk",
            "dirA/notes.yaml": "junk",
        },
    )
    selector, record, out = make_selector(tmp_path)
    config = write_config(tmp_path, snippetfile=str(main), editor="true",
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: the built text escapes embedded newlines as \n, appends one
    # " #tag" per tag, walks snippetdirs recursively and skips non-.toml files.
    assert res.returncode == 255  # empty selection, see below
    assert record.read_text() == (
        "argc=0\n"
        "stdin:\n"
        "[main one]: main-cmd #main\n"
        "[multi]: line1\\nline2 #x #y\n"
        "[nested]: nc\n"
        "[deep]: dc\n"
    )


def test_first_selected_line_names_the_main_snippet_file(tmp_path):
    """`selectcmd` printing every line makes the first (main) snippet win."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  command = "cmd-a"\n',
    })
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(main), editor=str(editor),
                          selectcmd="cat", snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: only the first output line is mapped back, and the main file's
    # snippets come first because the main file is loaded before the dirs.
    assert res.returncode == 0
    assert res.stdout == b""
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % main


def test_selecting_a_directory_snippet_opens_that_file(tmp_path):
    """Choosing a snippet from a snippetdir opens that snippet's own file."""
    dir_file = tmp_path / "dirA" / "a.toml"
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  Output = ""\n  Tag = ["a"]\n  command = "cmd-a"\n',
    })
    selector, record, out = make_selector(tmp_path)
    editor, args = make_recorder(tmp_path)
    out.write_text("[dirA one]: cmd-a #a\n", encoding="utf-8")
    config = write_config(tmp_path, snippetfile=str(main), editor=str(editor),
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: the selected line is looked up in a map of text->SnippetInfo and
    # the snippet's own file (not the main file) is handed to the editor.
    assert res.returncode == 0
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % dir_file
    assert record.read_text().startswith("argc=0\nstdin:\n")


def test_selecting_a_nested_snippet_opens_the_nested_file(tmp_path):
    """Snippets found in a subdirectory of a snippetdir open that file."""
    nested = tmp_path / "dirA" / "sub" / "b.toml"
    main = _workspace(tmp_path, dir_files={
        "dirA/sub/b.toml": '\n[[Snippets]]\n  Description = "nested"\n'
                           '  command = "nc"\n',
    })
    selector, record, out = make_selector(tmp_path)
    editor, args = make_recorder(tmp_path)
    out.write_text("[nested]: nc\n", encoding="utf-8")
    config = write_config(tmp_path, snippetfile=str(main), editor=str(editor),
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: getFiles() walks the directory tree, so a snippet two levels deep
    # still carries its own absolute path.
    assert res.returncode == 0
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % nested


def test_query_flag_is_shell_quoted_into_two_arguments(tmp_path):
    """-q becomes `--query 'value'` inside the sh -c command line."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  command = "cmd-a"\n',
    })
    selector, record, out = make_selector(tmp_path)
    out.write_text("[main one]: main-cmd #main\n", encoding="utf-8")
    config = write_config(tmp_path, snippetfile=str(main), editor="true",
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit", "-q", "find me"],
                  home=tmp_path)
    # CATCHES: pet builds the literal string `--query 'find me'` and lets the
    # shell split it, so the selector sees two separate arguments.
    assert res.returncode == 0
    assert record.read_text().startswith("argc=2\narg=--query\narg=find me\nstdin:\n")


def test_query_with_metacharacters_survives_the_shell_roundtrip(tmp_path):
    """A query containing quotes and $ keeps its exact bytes."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  command = "cmd-a"\n',
    })
    selector, record, out = make_selector(tmp_path)
    out.write_text("[main one]: main-cmd #main\n", encoding="utf-8")
    config = write_config(tmp_path, snippetfile=str(main), editor="true",
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit", "-q", "a'b\"c $x"],
                  home=tmp_path)
    # CATCHES: shellescape.Quote() wraps the value so `sh -c` hands the selector
    # the very same bytes, with no expansion of $x.
    assert res.returncode == 0
    assert record.read_text().startswith("argc=2\narg=--query\narg=a'b\"c $x\nstdin:\n")


def test_tag_flag_filters_the_selector_input(tmp_path):
    """-t keeps only snippets carrying that tag and is not passed to selectcmd."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  Output = ""\n  Tag = ["a"]\n  command = "cmd-a"\n',
    })
    selector, record, out = make_selector(tmp_path)
    editor, args = make_recorder(tmp_path)
    out.write_text("[dirA one]: cmd-a #a\n", encoding="utf-8")
    config = write_config(tmp_path, snippetfile=str(main), editor=str(editor),
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit", "-t", "a"], home=tmp_path)
    # CATCHES: the tag filters the list before the text is built, so the untagged
    # main snippet disappears and the selector gets no extra argument for it.
    assert res.returncode == 0
    assert record.read_text() == "argc=0\nstdin:\n[dirA one]: cmd-a #a\n"
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % (
        tmp_path / "dirA" / "a.toml"
    )


def test_tag_flag_with_no_match_selects_nothing(tmp_path):
    """A tag nobody has leaves the selector with empty input and no file."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  command = "cmd-a"\n',
    })
    selector, record, out = make_selector(tmp_path)
    config = write_config(tmp_path, snippetfile=str(main), editor="true",
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit", "-t", "zzz"], home=tmp_path)
    # CATCHES: with nothing selected the parsed line is empty, so the snippet
    # lookup yields a zero SnippetInfo and the empty path fails to resolve.
    assert res.returncode == 255
    assert res.stdout == b"error resolving relative path - unknown path: \n"
    assert record.read_text() == "argc=0\nstdin:\n"


def test_empty_selector_output_selects_no_file(tmp_path):
    """A selector that prints nothing also ends in the path error."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  command = "cmd-a"\n',
    })
    selector, record, out = make_selector(tmp_path)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(main), editor=str(editor),
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: the "no snippet file selected" guard is unreachable here -- the
    # split of an empty buffer yields one empty line whose snippet has no file,
    # so the empty-path error is what the user actually sees.
    assert res.returncode == 255
    assert res.stdout == b"error resolving relative path - unknown path: \n"
    assert not args.exists()


def test_unknown_selected_line_selects_no_file(tmp_path):
    """A selector answer that matches no snippet also resolves to no file."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  command = "cmd-a"\n',
    })
    selector, record, out = make_selector(tmp_path)
    out.write_text("[no such snippet]: at all\n", encoding="utf-8")
    config = write_config(tmp_path, snippetfile=str(main), editor="true",
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: the missing map key returns the zero value instead of an error,
    # so the failure surfaces as the empty-path message rather than a lookup
    # error.
    assert res.returncode == 255
    assert res.stdout == b"error resolving relative path - unknown path: \n"


def test_selector_nonzero_exit_stops_the_edit(tmp_path):
    """A selector exiting non-zero aborts before the editor is launched."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  command = "cmd-a"\n',
    })
    selector, _, _ = make_selector(tmp_path)
    selector.write_text(
        "#!/bin/sh\ncat > /dev/null\necho \"[dirA one]: cmd-a\"\nexit 4\n",
        encoding="utf-8",
    )
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(main), editor=str(editor),
                          selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: run()'s error is returned even though the selector had printed a
    # perfectly good line, so the editor never runs.
    assert res.returncode == 255
    assert res.stdout == b"exit status 4\n"
    assert res.stderr == b""
    assert not args.exists()


def test_selector_command_not_found_reports_127(tmp_path):
    """A missing selectcmd is reported by sh on stderr."""
    main = _workspace(tmp_path, dir_files={
        "dirA/a.toml": '\n[[Snippets]]\n  Description = "dirA one"\n'
                       '  command = "cmd-a"\n',
    })
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(main), editor=str(editor),
                          selectcmd="/nonexistent/selector",
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: the select command runs through `sh -c`, whose 127 exit status
    # and `not found` message are propagated to pet's own streams.
    assert res.returncode == 255
    assert res.stdout == b"exit status 127\n"
    assert res.stderr == b"sh: 1: /nonexistent/selector: not found\n"


def test_missing_snippetdir_is_a_load_error(tmp_path):
    """A configured snippetdir that does not exist aborts the edit."""
    main = _workspace(tmp_path)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(main), editor=str(editor),
                          selectcmd="true", snippetdirs=["/nonexistent/dir"])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: selectFile() wraps the load failure with the `load snippet
    # failed:` prefix before anything else happens.
    assert res.returncode == 255
    assert res.stdout == b"load snippet failed: snippet directory not found. /nonexistent/dir\n"
    assert not args.exists()


def test_missing_main_file_with_snippetdirs_is_a_load_error(tmp_path):
    """With snippetdirs the main file must exist, unlike the plain edit path."""
    missing = tmp_path / "missing.toml"
    write_file(tmp_path / "dirA" / "a.toml",
               '\n[[Snippets]]\n  Description = "dirA one"\n  command = "cmd-a"\n')
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(missing), editor=str(editor),
                          selectcmd="true",
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: once snippetdirs is configured the snippets really are loaded, so
    # the same missing file that the plain path ignores is now fatal.
    assert res.returncode == 255
    assert res.stdout == (
        b"load snippet failed: snippet file not found. %s\n"
        b"Please run 'pet configure' and provide a correct file path, or remove this\n"
        b"if you only want to provide snippetdirs instead\n" % str(missing).encode()
    )
    assert not args.exists()
