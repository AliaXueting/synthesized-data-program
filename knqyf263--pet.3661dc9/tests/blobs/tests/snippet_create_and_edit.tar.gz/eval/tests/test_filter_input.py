"""The selector input built by filter() (cmd/util.go) for exec/search.

``pet exec``/``pet search`` load every snippet, render one line per snippet
with the configured ``format`` and feed those lines to ``General.selectcmd``
on its stdin.  Every expectation here was recorded by running ``./executable``.
"""

from __future__ import annotations

import pytest

from conftest import make_selector, run_pet, run_pet_interactive, write_config, write_file

# Two plain snippets: one untagged, one tagged.
GREET_AND_BYE = (
    '[[Snippets]]\n  Description = "greet"\n  command = "echo hello"\n\n'
    '[[Snippets]]\n  Description = "bye"\n  command = "echo bye"\n'
    '  Tag = ["farewell"]\n'
)


def _setup(tmp_path, main=GREET_AND_BYE, selection="", **kw):
    """Snippet file + selector stand-in + config; returns (main, record, out, config)."""
    main_path = write_file(tmp_path / "snippets.toml", main)
    selector, record, out = make_selector(tmp_path)
    out.write_text(selection)
    config = write_config(tmp_path, snippetfile=str(main_path),
                          selectcmd=str(selector), **kw)
    return main_path, record, out, config


def test_missing_snippet_file_is_a_load_error(tmp_path):
    """`pet exec` fails before running the selector when the file is missing."""
    selector, record, _ = make_selector(tmp_path)
    absent = tmp_path / "absent.toml"
    config = write_config(tmp_path, snippetfile=str(absent), selectcmd=str(selector))
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: filter() wraps the load failure as `load snippet failed: ...`
    # (printed on stdout by the root command) and exits 255 without ever
    # starting the selector.
    assert res.returncode == 255
    assert res.stdout == (
        "load snippet failed: snippet file not found. %s\n"
        "Please run 'pet configure' and provide a correct file path, or remove this\n"
        "if you only want to provide snippetdirs instead\n" % (tmp_path / "absent.toml")
    ).encode()
    assert res.stderr == b""
    assert not record.exists()


def test_bad_toml_snippet_file_is_a_load_error(tmp_path):
    """Unparseable TOML is reported through filter()'s load-error wrapper."""
    bad = write_file(tmp_path / "bad.toml", "garbage [[[\n")
    selector, _, _ = make_selector(tmp_path)
    config = write_config(tmp_path, snippetfile=str(bad), selectcmd=str(selector))
    res = run_pet(["--config", str(config), "search"], home=tmp_path)
    # CATCHES: a snippet file that fails to parse aborts `pet search` with the
    # `load snippet failed: failed to parse snippet file.` wrapper (exit 255)
    # before any selector is started.
    assert res.returncode == 255
    assert res.stdout.startswith(b"load snippet failed: failed to parse snippet file.")
    assert res.stderr == b""


def test_selector_receives_the_default_format_lines(tmp_path):
    """Default lines are `[desc]: command #tag ` with a trailing space."""
    _, record, out, config = _setup(tmp_path)
    out.write_text("[greet]: echo hello \n")
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: the built-in format is "[$description]: $command $tags" where
    # each tag contributes "#tag " -- so an untagged snippet keeps the space
    # before the empty $tags and a tagged line ends with a trailing space.
    assert res.returncode == 0
    assert record.read_text() == (
        "argc=0\n"
        "stdin:\n"
        "[greet]: echo hello \n"
        "[bye]: echo bye #farewell \n"
    )


def test_multiline_commands_appear_with_literal_backslash_n(tmp_path):
    """Embedded newlines are shown to the selector as literal `\\n`."""
    main = ('[[Snippets]]\n  Description = "multi"\n'
            '  command = "echo one\\necho two"\n')
    _, record, out, config = _setup(tmp_path, main=main)
    out.write_text("[multi]: echo one\\necho two \n")
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: only the line fed to the selector escapes newlines as the two
    # characters `\n`; the command actually executed keeps real newlines.
    assert res.returncode == 0
    assert record.read_text() == (
        "argc=0\nstdin:\n[multi]: echo one\\necho two \n"
    )


def test_tag_flag_limits_the_selector_input(tmp_path):
    """`-t` keeps only the snippets carrying that exact tag."""
    _, record, out, config = _setup(tmp_path)
    out.write_text("[bye]: echo bye #farewell \n")
    res = run_pet(["--config", str(config), "exec", "-t", "farewell"], home=tmp_path)
    # CATCHES: the tag filter compares the whole tag string, so only the
    # matching snippet reaches the selector and the rest are dropped silently.
    assert res.returncode == 0
    assert record.read_text() == "argc=0\nstdin:\n[bye]: echo bye #farewell \n"
    assert res.stdout == b"> echo bye\nbye\n"


def test_snippet_with_a_repeated_tag_is_listed_twice(tmp_path):
    """A snippet whose Tag list repeats the filter tag is emitted per match."""
    main = ('[[Snippets]]\n  Description = "dupe"\n  command = "echo dup"\n'
            '  Tag = ["same", "same"]\n')
    _, record, _, config = _setup(tmp_path, main=main)
    res = run_pet(["--config", str(config), "exec", "-t", "same"],
                  home=tmp_path)
    # CATCHES: the filter loop appends the snippet once per matching tag
    # entry, so a duplicated tag makes the same line appear twice.
    assert res.returncode == 0
    assert record.read_text() == (
        "argc=0\nstdin:\n[dupe]: echo dup #same #same \n[dupe]: echo dup #same #same \n"
    )


def test_tag_flag_without_matches_feeds_the_selector_an_empty_list(tmp_path):
    """A tag matching nothing leaves the selector's stdin empty."""
    _, record, out, config = _setup(tmp_path)
    out.write_text("[greet]: echo hello \n")
    res = run_pet(["--config", str(config), "exec", "-t", "no-such-tag"],
                  home=tmp_path)
    # CATCHES: with no matching snippets the selector receives zero lines but
    # is still started, and its (now unknown) output maps to an empty command.
    assert res.returncode == 0
    assert record.read_text() == "argc=0\nstdin:\n"
    assert res.stdout == b"> \n"


def test_snippetdirs_snippets_join_the_selector_input(tmp_path):
    """filter() loads snippetdirs too, after the main file's snippets."""
    main = write_file(tmp_path / "snippets.toml",
                      '[[Snippets]]\n  Description = "main file"\n'
                      '  command = "echo main"\n')
    write_file(tmp_path / "dirA" / "one.toml",
               '[[Snippets]]\n  Description = "from dir one"\n'
               '  command = "echo d1"\n')
    write_file(tmp_path / "dirB" / "nested" / "two.toml",
               '[[Snippets]]\n  Description = "from dir two"\n'
               '  command = "echo d2"\n')
    selector, record, _ = make_selector(tmp_path)
    config = write_config(tmp_path, snippetfile=str(main), selectcmd=str(selector),
                          snippetdirs=[str(tmp_path / "dirA"), str(tmp_path / "dirB")])
    res = run_pet(["--config", str(config), "search"], home=tmp_path)
    # CATCHES: unlike `pet new`, the exec/search pipeline loads snippetdirs
    # recursively, main file first then each directory in config order.
    assert res.returncode == 0
    assert record.read_text() == (
        "argc=0\n"
        "stdin:\n"
        "[main file]: echo main \n"
        "[from dir one]: echo d1 \n"
        "[from dir two]: echo d2 \n"
    )


def test_custom_format_is_used_for_the_selector_input(tmp_path):
    """General.format replaces the built-in line layout."""
    main = ('[[Snippets]]\n  Description = "greet"\n  command = "echo hello"\n\n'
            '[[Snippets]]\n  Description = "tagged"\n  command = "echo tag"\n'
            '  Tag = ["a", "b"]\n')
    _, record, _, config = _setup(
        tmp_path, main=main, format="run $description with $command [$tags]")
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: $description/$command/$tags are plain textual placeholders in
    # the configured format; empty tags render as `[]` and each tag keeps its
    # trailing space inside the brackets.
    assert res.returncode == 0
    assert record.read_text() == (
        "argc=0\n"
        "stdin:\n"
        "run greet with echo hello []\n"
        "run tagged with echo tag [#a #b ]\n"
    )


def test_only_the_first_command_placeholder_is_replaced(tmp_path):
    """A format repeating $command leaves the second occurrence literal."""
    main = '[[Snippets]]\n  Description = "greet"\n  command = "echo hello"\n'
    _, record, _, config = _setup(
        tmp_path, main=main, format="X $command Y $command Z")
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: each placeholder is substituted with strings.Replace(..., 1),
    # so only the first $command in the format is expanded.
    assert res.returncode == 0
    assert record.read_text() == "argc=0\nstdin:\nX echo hello Y $command Z\n"


def test_tags_placeholder_inside_a_description_is_expanded(tmp_path):
    """A literal $tags inside the description swallows the tag expansion."""
    main = ('[[Snippets]]\n  Description = "about $tags here"\n'
            '  command = "echo hi"\n  Tag = ["t1"]\n')
    _, record, _, config = _setup(tmp_path, main=main)
    res = run_pet(["--config", str(config), "exec"], home=tmp_path)
    # CATCHES: $tags is replaced only once and $description is expanded
    # first, so a $tags typed inside a description gets the tags while the
    # format's own trailing $tags stays literal (no trailing space either).
    assert res.returncode == 0
    assert record.read_text() == "argc=0\nstdin:\n[about #t1  here]: echo hi $tags\n"


def test_color_flag_does_not_colour_piped_selector_input(tmp_path):
    """--color is inert while stdout is a pipe (the colour library detects it)."""
    main = ('[[Snippets]]\n  Description = "greet"\n  command = "echo hello"\n'
            '  Tag = ["hi", "warm"]\n')
    _, record, _, config = _setup(tmp_path, main=main)
    res = run_pet(["--config", str(config), "exec", "--color"], home=tmp_path)
    # CATCHES: the colored line is only built when the flag/config asks for
    # it, but the ANSI escapes are suppressed off-tty, so the selector input
    # is byte-identical to the uncolored one.
    assert res.returncode == 0
    text = record.read_text()
    assert text == "argc=0\nstdin:\n[greet]: echo hello #hi #warm \n"
    assert "\x1b" not in text


@pytest.mark.parametrize("argv_extra", [
    (["--color"]),
    ([]),
])
def test_colourised_selector_input_on_a_tty(tmp_path, argv_extra):
    """On a tty, --color (or General.color) paints description/tags for the selector."""
    main = ('[[Snippets]]\n  Description = "greet"\n  command = "echo hello"\n'
            '  Tag = ["hi", "warm"]\n')
    main_path = write_file(tmp_path / "snippets.toml", main)
    selector, record, out = make_selector(tmp_path)
    out.write_text("[greet]: echo hello #hi #warm \n")
    config = write_config(tmp_path, snippetfile=str(main_path),
                          selectcmd=str(selector), color=(argv_extra == []))
    rc, tty = run_pet_interactive(["--config", str(config), "exec"] + argv_extra,
                                  [], home=tmp_path)
    # CATCHES: with a tty on stdout the description is wrapped in \x1b[91m
    # (HiRed) and the whole "#hi #warm " tag run in \x1b[96m (HiCyan) while
    # the brackets and the command stay uncoloured -- and the *map key* used
    # to resolve the selection stays the plain line.
    assert rc == 0
    assert record.read_text() == (
        "argc=0\nstdin:\n[\x1b[91mgreet\x1b[0m]: echo hello \x1b[96m#hi #warm \x1b[0m\n"
    )
    assert tty == b"> echo hello\r\nhello\r\n"
