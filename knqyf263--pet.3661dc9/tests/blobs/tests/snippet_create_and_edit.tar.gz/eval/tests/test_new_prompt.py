"""Prompt behaviour of ``pet new`` (cmd/new.go scan()).

``pet new`` collects the command and the description with chzyer/readline.
Every expectation here was recorded by running ``./executable``.
"""

from __future__ import annotations

from conftest import (
    canonical_snippets,
    run_pet,
    run_pet_interactive,
    run_pet_pty,
    write_config,
    write_file,
)

# The exact canonical TOML block the reference writes for one plain snippet.
ONE_SNIPPET = (
    '\n[[Snippets]]\n  Description = "the description"\n'
    '  Output = ""\n  Tag = []\n  command = "echo hi"\n'
)


def _setup(tmp_path, content="", **kw):
    snippet = write_file(tmp_path / "snippets.toml", content)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true", **kw)
    return snippet, config


def test_positional_args_skip_the_command_prompt(tmp_path):
    """`pet new echo hello world` echoes the command and only asks Description."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "echo", "hello", "world"],
                  stdin=b"my description\n", home=tmp_path)
    # CATCHES: positional args are joined with spaces, printed as
    # `Command> <joined>` (no ANSI codes off-tty) and never re-prompted.
    assert res.returncode == 0
    assert res.stdout == b"Command> echo hello world\n"
    assert res.stderr == b""
    assert snippet.read_text() == (
        '\n[[Snippets]]\n  Description = "my description"\n'
        '  Output = ""\n  Tag = []\n  command = "echo hello world"\n'
    )


def test_stdout_is_empty_while_reading_prompts_off_tty(tmp_path):
    """Off-tty the readline prompts are not written to stdout at all."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "echo", "hi"],
                  stdin=b"the description\n", home=tmp_path)
    # CATCHES: readline only prints its prompt when stdout is a terminal, so a
    # piped run emits nothing but the positional-args echo line.
    assert res.returncode == 0
    assert res.stdout == b"Command> echo hi\n"
    assert b"Description>" not in res.stdout
    assert snippet.read_text() == ONE_SNIPPET


def test_eof_on_the_command_prompt_reports_canceled(tmp_path):
    """EOF on an empty Command line aborts with the `canceled` error."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new"], stdin=b"", home=tmp_path)
    # CATCHES: io.EOF on an empty line leaves scan() with CanceledError(), which
    # cobra prints on stdout with exit status 255 (os.Exit(-1)).
    assert res.returncode == 255
    assert res.stdout == b"canceled\n"
    assert res.stderr == b""
    assert snippet.read_text() == ""


def test_ctrl_c_on_an_empty_command_line_reports_canceled(tmp_path):
    """A literal ^C byte on an empty Command line also cancels."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new"], stdin=b"\x03", home=tmp_path)
    # CATCHES: readline maps byte 0x03 to ErrInterrupt; an empty line breaks the
    # scan loop and produces the same `canceled` error as EOF.
    assert res.returncode == 255
    assert res.stdout == b"canceled\n"
    assert snippet.read_text() == ""


def test_ctrl_c_on_a_nonempty_command_line_reprompts(tmp_path):
    """^C with text on the line discards the line and asks again."""
    snippet, config = _setup(tmp_path)
    rc, stdout, stderr = run_pet_pty(
        ["--config", str(config), "new"],
        ["echo\x03", "real command\n", "the description\n"],
        home=tmp_path,
    )
    # CATCHES: scan() only cancels when the interrupted line is empty; here the
    # second attempt is kept and saved as the command.
    assert rc == 0
    assert stdout == b""
    assert stderr == b""
    assert snippet.read_text() == (
        '\n[[Snippets]]\n  Description = "the description"\n'
        '  Output = ""\n  Tag = []\n  command = "real command"\n'
    )


def test_whitespace_only_command_lines_are_reprompted(tmp_path):
    """Blank/whitespace Command lines are skipped, and the value is trimmed."""
    snippet, config = _setup(tmp_path)
    rc, stdout, stderr = run_pet_pty(
        ["--config", str(config), "new"],
        ["   \n", "\t\n", "  echo hi  \n", "the description\n"],
        home=tmp_path,
    )
    # CATCHES: scan() loops on TrimSpace(line)=="" and stores TrimSpace(line),
    # so surrounding blanks never reach the saved command.
    assert rc == 0
    assert snippet.read_text() == ONE_SNIPPET


def test_blank_command_line_does_not_cancel(tmp_path):
    """A blank first Command line is consumed, then EOF on Description cancels."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new"],
                  stdin=b"   \necho hi\n", home=tmp_path)
    # CATCHES: whitespace input re-prompts inside one readline instance (the
    # second line is read from the same buffer), so nothing is saved.
    assert res.returncode == 255
    assert res.stdout == b"canceled\n"
    assert snippet.read_text() == ""


def test_whitespace_only_description_is_reprompted(tmp_path):
    """Blank Description answers are skipped until a non-empty one arrives."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "echo", "hi"],
                  stdin=b"  \n\nreal desc\n", home=tmp_path)
    # CATCHES: the Description prompt uses allowEmpty=false, so blank lines are
    # re-prompted rather than stored as an empty description.
    assert res.returncode == 0
    assert res.stdout == b"Command> echo hi\n"
    assert snippet.read_text() == (
        '\n[[Snippets]]\n  Description = "real desc"\n'
        '  Output = ""\n  Tag = []\n  command = "echo hi"\n'
    )


def test_two_prompts_supplied_at_once_cannot_both_be_read(tmp_path):
    """Piping command and description in one write ends in `canceled`."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new"],
                  stdin=b"echo hi\nthe description\n", home=tmp_path)
    # CATCHES: every scan() builds a new readline instance whose bufio swallows
    # the whole pipe, so the Description prompt sees EOF and cancels; the file
    # is left untouched.
    assert res.returncode == 255
    assert res.stdout == b"canceled\n"
    assert snippet.read_text() == ""


def test_command_read_from_the_tty_is_saved(tmp_path):
    """A plain two-prompt run over a pty saves both fields."""
    snippet, config = _setup(tmp_path)
    rc, stdout, stderr = run_pet_pty(
        ["--config", str(config), "new"],
        ["echo hi\n", "the description\n"],
        home=tmp_path,
    )
    # CATCHES: both prompts are answered from stdin when the lines arrive
    # separately, and the snippet lands in the configured snippet file.
    assert rc == 0
    assert stdout == b""
    assert stderr == b""
    assert snippet.read_text() == ONE_SNIPPET


def test_interactive_prompts_are_ansi_coloured(tmp_path):
    """On a real tty the prompts carry their HiYellow/HiGreen escapes."""
    snippet, config = _setup(tmp_path)
    rc, stdout = run_pet_interactive(
        ["--config", str(config), "new"],
        ["echo hi\n", "the description\n"],
        home=tmp_path,
    )
    # CATCHES: the prompts are built with color.HiYellowString/HiGreenString,
    # which only emit escapes when stdout is a terminal.
    assert rc == 0
    assert b"\x1b[93mCommand> \x1b[0m" in stdout
    assert b"\x1b[92mDescription> \x1b[0m" in stdout
    assert snippet.read_text() == ONE_SNIPPET


def test_empty_positional_command_is_saved_verbatim(tmp_path):
    """`pet new ""` stores an empty command without re-prompting."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", ""],
                  stdin=b"desc\n", home=tmp_path)
    # CATCHES: with args present the command branch is skipped entirely, so even
    # an empty argument becomes the command (`Command> ` with nothing after it).
    assert res.returncode == 0
    assert res.stdout == b"Command> \n"
    assert snippet.read_text() == (
        '\n[[Snippets]]\n  Description = "desc"\n'
        '  Output = ""\n  Tag = []\n  command = ""\n'
    )


def test_multiple_empty_positional_args_join_to_one_space(tmp_path):
    """`pet new "" ""` joins the two empty args into a single space."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "", ""],
                  stdin=b"desc\n", home=tmp_path)
    # CATCHES: strings.Join(args, " ") is used verbatim, so two empty arguments
    # produce a one-space command.
    assert res.returncode == 0
    assert res.stdout == b"Command>  \n"
    assert snippet.read_text() == (
        '\n[[Snippets]]\n  Description = "desc"\n'
        '  Output = ""\n  Tag = []\n  command = " "\n'
    )
