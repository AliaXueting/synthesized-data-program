"""Shared harness for the ``snippet_create_and_edit`` module tests.

Every test drives the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hard-coded path).  The helpers exposed here are:

``run_pet``              run the candidate with a raw argument vector, feeding
                        ``stdin`` bytes through a pipe, and return the
                        completed process (stdout/stderr are bytes)
``run_pet_pty``          run it with stdin on a pty but stdout/stderr on pipes,
                        feeding the given lines one at a time (readline only
                        keeps its buffer inside one prompt, so a two-prompt
                        flow needs the lines to arrive separately)
``run_pet_interactive``  run it with stdin/stdout/stderr all on a pty so the
                        readline prompts (and their ANSI colours) are emitted

The configuration helpers build the ``config.toml`` / ``snippet.toml`` fixtures
and the little shell scripts used as ``editor`` / ``selectcmd`` stand-ins; they
all live inside ``tmp_path`` so the suite stays hermetic.
"""

from __future__ import annotations

import functools
import os
import pty
import select
import subprocess
import tempfile
import time
from pathlib import Path

# A fixed, pinned child environment: no dependence on the ambient environment,
# no network, and a PATH that only reaches a few external programs.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent-pet-home",
    "TMPDIR": "/tmp",
    "LANG": "C",
    "TERM": "xterm",
}


@functools.lru_cache(maxsize=None)
def _writes_counters(binary: str) -> bool:
    """True if BINARY is a Go coverage build (it drops covcounters files).

    Probed by running 'version' once against a throwaway GOCOVERDIR, so the
    check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="pet-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def executable_path() -> str:
    """Return the candidate path from PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE", "")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; the suite cannot drive the candidate"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but the
    # pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to this
    # module's uninstrumented copy before pytest starts, so no counters would
    # ever be written and this module's coverage report would stay empty.
    # During a coverage run (GOCOVERDIR present), when the assigned binary is
    # not itself instrumented, fall back to the instrumented build the driver
    # stages next to the module workspaces.  That file only exists in the
    # pipeline layout, so ordinary validation and release runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[3] / "executable.cov"
        if staged.exists() and _writes_counters(str(staged)):
            return str(staged)
    return path


def merge_env(env=None, extra=None, home=None):
    """BASE_ENV, replaced by env when given, then patched by extra/home."""
    if env is None:
        merged = dict(BASE_ENV)
    else:
        merged = dict(env)
        merged.setdefault("PATH", BASE_ENV["PATH"])
    if home is not None:
        merged["HOME"] = str(home)
    if extra:
        merged.update(extra)
    # Coverage instrumentation hook (REQUIRED): copy GOCOVERDIR from the
    # test process environment into the child env when present, so the
    # pipeline can measure source coverage of the reference binary.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    merged.update(cov_env)
    return merged


def run_pet(argv, *, stdin=b"", env=None, extra=None, cwd=None, home=None, timeout=30):
    """Run the candidate with ARGV and piped stdin; return the process result.

    stdin may be str or bytes; stdout/stderr are always bytes so that exact
    recorded byte expectations can be asserted.
    """
    data = stdin if isinstance(stdin, bytes) else stdin.encode()
    return subprocess.run(
        [executable_path()] + list(argv),
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env=merge_env(env, extra, home),
        timeout=timeout,
    )


def run_pet_pty(argv, lines, *, env=None, extra=None, cwd=None, home=None,
                timeout=30, line_delay=0.4, initial_delay=0.35):
    """Run the candidate with stdin on a pty and stdout/stderr on pipes.

    Because stdout is not a terminal the readline layer runs non-interactive
    (no prompt bytes are emitted), but stdin still behaves like a terminal, so
    the lines of LINES can be delivered one prompt at a time.  Returns
    ``(returncode, stdout, stderr)``.
    """
    master, slave = pty.openpty()
    proc = subprocess.Popen(
        [executable_path()] + list(argv),
        stdin=slave,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env=merge_env(env, extra, home),
        close_fds=True,
    )
    os.close(slave)
    time.sleep(initial_delay)
    for line in lines:
        if isinstance(line, str):
            line = line.encode()
        os.write(master, line)
        time.sleep(line_delay)
    os.close(master)  # deliver EOF
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        stdout, stderr = proc.communicate()
    return proc.returncode, stdout, stderr


def _drain(fd, sink):
    """Move whatever is readable on FD into SINK; return True if anything was."""
    got = False
    while True:
        ready, _, _ = select.select([fd], [], [], 0)
        if not ready:
            return got
        try:
            data = os.read(fd, 65536)
        except OSError:
            return got
        if not data:
            return got
        sink.extend(data)
        got = True


def run_pet_interactive(argv, lines, *, env=None, extra=None, cwd=None, home=None,
                        timeout=30, line_delay=0.4, initial_delay=0.35, cols=80):
    """Run the candidate with stdin/stdout/stderr all on a pty.

    Here the readline layer is interactive, so the prompts (with their ANSI
    colour escapes) are written to the terminal.  Returns ``(returncode,
    terminal_output_bytes)``.
    """
    pid, fd = pty.fork()
    if pid == 0:  # child
        try:
            import fcntl
            import struct
            import termios

            fcntl.ioctl(0, termios.TIOCSWINSZ, struct.pack("HHHH", 24, cols, 0, 0))
        except Exception:
            pass
        child_env = merge_env(env, extra, home)
        try:
            os.execve(executable_path(), [executable_path()] + list(argv), child_env)
        except Exception:
            os._exit(127)
    out = bytearray()
    time.sleep(initial_delay)
    _drain(fd, out)
    for line in lines:
        if isinstance(line, str):
            line = line.encode()
        os.write(fd, line)
        time.sleep(line_delay)
        _drain(fd, out)
    deadline = time.time() + 1.2
    while time.time() < deadline:
        if not _drain(fd, out):
            time.sleep(0.1)
        else:
            deadline = time.time() + 0.5
    try:
        os.close(fd)
    except OSError:
        pass
    try:
        _, status = os.waitpid(pid, 0)
        rc = os.waitstatus_to_exitcode(status)
    except Exception:
        rc = None
    return rc, bytes(out)


# ---------------------------------------------------------------------------
# fixture builders
# ---------------------------------------------------------------------------

def write_file(path, text):
    """Write TEXT to PATH (creating parent dirs) and return the path."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(text, bytes):
        path.write_bytes(text)
    else:
        path.write_text(text, encoding="utf-8")
    return path


def make_script(directory, body, name="tool.sh"):
    """Write an executable ``#!/bin/sh`` script running BODY into DIRECTORY."""
    path = Path(directory) / name
    path.write_text("#!/bin/sh\n" + body + "\n", encoding="utf-8")
    path.chmod(0o755)
    return path


def make_recorder(directory, name="rec.sh"):
    """Create an editor stand-in that records its argv into ``args.txt``.

    Returns ``(script_path, args_path)``.  The recorded file has one
    ``argc=<n>`` line followed by one ``arg=<value>`` line per argument.
    """
    directory = Path(directory)
    args_path = directory / "args.txt"
    body = (
        '{\n  echo "argc=$#"\n'
        '  for a in "$@"; do\n    echo "arg=$a"\n  done\n'
        '} > "%s"\n' % args_path
    )
    return make_script(directory, body, name), args_path


def make_selector(directory, name="sel.sh"):
    """Create a ``selectcmd`` stand-in.

    It records its argv and its stdin into ``sel.txt`` and then prints the
    contents of ``sel-out.txt`` (which the test writes to choose the "selected"
    snippet line).  Returns ``(script_path, record_path, out_path)``.
    """
    directory = Path(directory)
    record_path = directory / "sel.txt"
    out_path = directory / "sel-out.txt"
    body = (
        '{\n  echo "argc=$#"\n'
        '  for a in "$@"; do\n    echo "arg=$a"\n  done\n'
        '  echo "stdin:"\n  cat\n'
        '} > "%s"\ncat "%s"\n' % (record_path, out_path)
    )
    out_path.write_text("", encoding="utf-8")
    return make_script(directory, body, name), record_path, out_path


def _toml_str(value):
    return '"%s"' % str(value).replace("\\", "\\\\").replace('"', '\\"')


def write_config(directory, *, snippetfile=None, editor=None, selectcmd=None,
                 snippetdirs=None, cmd=None, backend=None, sortby=None,
                 format=None, color=None, gist=None, gitlab=None, ghe=None,
                 name="config.toml"):
    """Write a pet ``config.toml`` into DIRECTORY and return its path.

    ``gist``/``gitlab``/``ghe`` are dicts of raw ``[Section]`` keys, e.g.
    ``{"auto_sync": True, "access_token": "x"}``.
    """
    lines = ["[General]"]
    if snippetfile is not None:
        lines.append("snippetfile = %s" % _toml_str(snippetfile))
    if editor is not None:
        lines.append("editor = %s" % _toml_str(editor))
    if selectcmd is not None:
        lines.append("selectcmd = %s" % _toml_str(selectcmd))
    if snippetdirs:
        lines.append(
            "snippetdirs = [%s]" % ", ".join(_toml_str(d) for d in snippetdirs)
        )
    if cmd:
        lines.append("cmd = [%s]" % ", ".join(_toml_str(c) for c in cmd))
    if backend is not None:
        lines.append("backend = %s" % _toml_str(backend))
    if sortby is not None:
        lines.append("sortby = %s" % _toml_str(sortby))
    if format is not None:
        lines.append("format = %s" % _toml_str(format))
    if color is not None:
        lines.append("color = %s" % ("true" if color else "false"))
    lines.append("")
    for section, values in (("Gist", gist), ("GitLab", gitlab), ("GHEGist", ghe)):
        if not values:
            continue
        lines.append("[%s]" % section)
        for key, value in values.items():
            if value is True:
                lines.append("%s = true" % key)
            elif value is False:
                lines.append("%s = false" % key)
            else:
                lines.append("%s = %s" % (key, _toml_str(value)))
        lines.append("")
    return write_file(Path(directory) / name, "\n".join(lines) + "\n")


def canonical_snippets(*entries):
    """Build the canonical TOML the reference writes for the given snippets.

    Each entry is a dict with ``Description``/``command``/``Tag``/``Output``
    keys (missing ones default to the empty value the encoder always emits).
    """
    parts = []
    for entry in entries:
        tag = entry.get("Tag") or []
        tag_text = "[%s]" % ", ".join(_toml_str(t) for t in tag) if tag else "[]"
        parts.append(
            "[[Snippets]]\n"
            "  Description = %s\n"
            "  Output = %s\n"
            "  Tag = %s\n"
            "  command = %s\n"
            % (
                _toml_str(entry.get("Description", "")),
                _toml_str(entry.get("Output", "")),
                tag_text,
                _toml_str(entry.get("command", "")),
            )
        )
    return "\n" + "\n".join(parts)
