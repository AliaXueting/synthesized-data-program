"""``pet edit`` opening the configured editor (cmd/edit.go + cmd/util_unix.go).

Without snippetdirs the command never loads the snippet list: it just runs
``<editor> +0 <snippetfile>`` through ``sh -c``.  Expectations recorded from
``./executable``.
"""

from __future__ import annotations

from conftest import make_recorder, make_script, run_pet, write_config, write_file

ONE_SNIPPET = (
    '\n[[Snippets]]\n  Description = "a"\n  Output = ""\n  Tag = []\n'
    '  command = "aa"\n'
)


def _setup(tmp_path, content=ONE_SNIPPET, **kw):
    snippet = write_file(tmp_path / "snippets.toml", content)
    return snippet


def test_edit_opens_the_snippetfile_at_line_zero(tmp_path):
    """`pet edit` runs the editor with the `+0` line argument."""
    snippet = _setup(tmp_path)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: the unix editFile() appends " +0 <path>" (line-number syntax)
    # rather than passing the bare path the windows variant uses.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % snippet


def test_edit_does_not_load_the_snippet_file(tmp_path):
    """A missing snippet file is not an error: the editor is still launched."""
    missing = tmp_path / "missing.toml"
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(missing), editor=str(editor))
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: without snippetdirs edit() never calls snippets.Load(), so a
    # nonexistent snippet file is handed straight to the editor.
    assert res.returncode == 0
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % missing


def test_edit_bad_toml_is_not_validated(tmp_path):
    """Even an unparseable snippet file is opened without complaint."""
    snippet = _setup(tmp_path, content="this is not toml {{{\n")
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: no parsing happens on this path, unlike `pet new` which refuses to
    # run on the same file.
    assert res.returncode == 0
    assert res.stdout == b""
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % snippet


def test_edit_query_flag_is_ignored_without_snippetdirs(tmp_path):
    """-q never reaches a selector because no selector is run."""
    snippet = _setup(tmp_path)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor),
                          selectcmd="echo should-not-run")
    res = run_pet(["--config", str(config), "edit", "-q", "hello"],
                  home=tmp_path)
    # CATCHES: options are only consumed by selectFile(), which is skipped when
    # snippetdirs is empty, so the editor sees exactly two arguments.
    assert res.returncode == 0
    assert res.stdout == b""
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % snippet


def test_edit_editor_failure_is_reported_verbatim(tmp_path):
    """A failing editor exits pet with the `exit status N` error."""
    snippet = _setup(tmp_path)
    editor = make_script(tmp_path, "exit 7", name="fail.sh")
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: run() returns the exec error and cobra prints it on stdout with
    # exit status 255.
    assert res.returncode == 255
    assert res.stdout == b"exit status 7\n"
    assert res.stderr == b""


def test_edit_editor_changes_are_kept(tmp_path):
    """Whatever the editor writes to the snippet file stays there."""
    snippet = _setup(tmp_path)
    editor = make_script(
        tmp_path,
        'printf "\\n[[Snippets]]\\n  Description = \\"added\\"\\n  command = \\"zz\\"\\n" '
        '>> "%s"' % snippet,
        name="append.sh",
    )
    config = write_config(tmp_path, snippetfile=str(snippet), editor=str(editor))
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: pet never rewrites the file after the editor, so the appended
    # hand-written (non-canonical) block is preserved byte for byte.
    assert res.returncode == 0
    assert res.stdout == b""
    assert snippet.read_text() == (
        ONE_SNIPPET + '\n[[Snippets]]\n  Description = "added"\n  command = "zz"\n'
    )


def test_edit_empty_snippetfile_is_a_path_error(tmp_path):
    """An empty snippetfile fails before anything else, even with snippetdirs."""
    write_file(tmp_path / "dirA" / "a.toml",
               '\n[[Snippets]]\n  Description = "d"\n  command = "c"\n')
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile="", editor=str(editor),
                          snippetdirs=[str(tmp_path / "dirA")], selectcmd="true")
    res = run_pet(["--config", str(config), "edit"], home=tmp_path)
    # CATCHES: the snippet file path is resolved before the snippetdirs branch,
    # so the empty value aborts with the path error and no editor runs.
    assert res.returncode == 255
    assert res.stdout == b"error resolving relative path - unknown path: \n"
    assert not args.exists()


def test_edit_relative_snippetfile_drops_two_characters(tmp_path):
    """A relative snippetfile is expanded by chopping its first two bytes."""
    home = tmp_path / "home"
    write_file(home / "l.toml", ONE_SNIPPET)
    write_file(home / "rel.toml", ONE_SNIPPET)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile="rel.toml", editor=str(editor))
    res = run_pet(["--config", str(config), "edit"], home=home)
    # CATCHES: expandPath() takes path[2:] for any relative value, so "rel.toml"
    # names $HOME/l.toml and rel.toml itself is never touched.
    assert res.returncode == 0
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % (home / "l.toml")


def test_edit_tilde_snippetfile_expands_to_home(tmp_path):
    """A `~/...` snippetfile is resolved against $HOME."""
    home = tmp_path / "home"
    write_file(home / "tilde.toml", ONE_SNIPPET)
    editor, args = make_recorder(tmp_path)
    config = write_config(tmp_path, snippetfile="~/tilde.toml",
                          editor=str(editor))
    res = run_pet(["--config", str(config), "edit"], home=home)
    # CATCHES: the `~` prefix is the one relative form that expands to the home
    # directory rather than losing its first two characters.
    assert res.returncode == 0
    assert args.read_text() == "argc=2\narg=+0\narg=%s\n" % (home / "tilde.toml")
