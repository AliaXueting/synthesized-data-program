"""What ``pet new`` writes to disk (cmd/new.go + snippet.Save()).

After any successful save the whole snippet file is rewritten in the canonical
TOML form of the encoder.  Expectations recorded from ``./executable``.
"""

from __future__ import annotations

from conftest import canonical_snippets, run_pet, write_config, write_file

HAND_WRITTEN = (
    "# hand written comment\n"
    "\n[[Snippets]]\n"
    '  command = "zzz last"\n'
    '  Description = "Zeta snippet"\n'
    '  Tag = [ "b", "a" ]\n'
    '  Output = "out z"\n'
    "\n[[Snippets]]\n"
    'Description = "alpha snippet"\n'
    'command = "aaa first"\n'
)


def _setup(tmp_path, content="", **kw):
    snippet = write_file(tmp_path / "snippets.toml", content)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true", **kw)
    return snippet, config


def test_hand_written_formatting_is_normalised(tmp_path):
    """Comments, field order and missing fields are rewritten canonically."""
    snippet, config = _setup(tmp_path, HAND_WRITTEN)
    res = run_pet(["--config", str(config), "new", "echo", "new"],
                  stdin=b"brand new desc\n", home=tmp_path)
    # CATCHES: the file is re-encoded from the parsed structs, so the comment
    # disappears, the fields come out in encoder order with Output/Tag always
    # present, and Tag loses the inner spacing it was written with.
    assert res.returncode == 0
    assert res.stdout == b"Command> echo new\n"
    assert snippet.read_text() == canonical_snippets(
        {"Description": "Zeta snippet", "Output": "out z", "Tag": ["b", "a"],
         "command": "zzz last"},
        {"Description": "alpha snippet", "command": "aaa first"},
        {"Description": "brand new desc", "command": "echo new"},
    )


def test_unknown_toml_fields_are_dropped_on_rewrite(tmp_path):
    """A field the struct does not know is silently removed."""
    snippet, config = _setup(
        tmp_path,
        '\n[[Snippets]]\n  Description = "x"\n  command = "y"\n'
        '  UnknownField = "zzz"\n',
    )
    res = run_pet(["--config", str(config), "new", "echo", "n"],
                  stdin=b"newdesc\n", home=tmp_path)
    # CATCHES: go-toml unmarshals only the known keys and Save() re-encodes the
    # structs, so UnknownField does not survive the round trip.
    assert res.returncode == 0
    assert snippet.read_text() == canonical_snippets(
        {"Description": "x", "command": "y"},
        {"Description": "newdesc", "command": "echo n"},
    )


def test_snippetdirs_files_are_left_untouched(tmp_path):
    """`pet new` rewrites only the main file, never the snippetdirs files."""
    snippet, config = _setup(
        tmp_path, '\n[[Snippets]]\n  Description = "main"\n  command = "mc"\n'
    )
    dir_file = write_file(tmp_path / "dirA" / "a.toml",
                          '# dir comment\n[[Snippets]]\n  Description = "dir one"\n'
                          '  command = "dc"\n')
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true",
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "new", "echo", "x"],
                  stdin=b"new desc\n", home=tmp_path)
    # CATCHES: snippets.Load(false) only reads the main file, so the directory
    # snippet is not even loaded and its hand-written comment survives verbatim.
    assert res.returncode == 0
    assert snippet.read_text() == canonical_snippets(
        {"Description": "main", "command": "mc"},
        {"Description": "new desc", "command": "echo x"},
    )
    assert dir_file.read_text() == (
        '# dir comment\n[[Snippets]]\n  Description = "dir one"\n  command = "dc"\n'
    )


def test_duplicate_description_is_rejected(tmp_path):
    """A description that already exists aborts the save."""
    snippet, config = _setup(tmp_path)
    run_pet(["--config", str(config), "new", "echo", "one"],
            stdin=b"dup desc\n", home=tmp_path)
    res = run_pet(["--config", str(config), "new", "echo", "two"],
                  stdin=b"dup desc\n", home=tmp_path)
    # CATCHES: the uniqueness check runs before Save(), so the second snippet is
    # not appended and the error text names the offending description.
    assert res.returncode == 255
    assert res.stdout == b"Command> echo two\nsnippet [dup desc] already exists\n"
    assert snippet.read_text() == canonical_snippets(
        {"Description": "dup desc", "command": "echo one"}
    )


def test_duplicate_check_is_case_sensitive(tmp_path):
    """Descriptions differing only in case are both accepted."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "echo", "n"],
                  stdin=b"DUP DESC\n", home=tmp_path)
    # CATCHES: the comparison is a plain Go string equality, never folded.
    assert res.returncode == 0
    assert res.stdout == b"Command> echo n\n"
    assert snippet.read_text() == canonical_snippets(
        {"Description": "DUP DESC", "command": "echo n"}
    )


def test_duplicate_check_uses_the_trimmed_answer(tmp_path):
    """Surrounding whitespace on the answer still collides."""
    snippet, config = _setup(tmp_path)
    run_pet(["--config", str(config), "new", "echo", "one"],
            stdin=b"dup desc\n", home=tmp_path)
    res = run_pet(["--config", str(config), "new", "echo", "n"],
                  stdin=b"  dup desc  \n", home=tmp_path)
    # CATCHES: scan() returns the trimmed line, so the duplicate comparison sees
    # the same string as the stored description.
    assert res.returncode == 255
    assert res.stdout == b"Command> echo n\nsnippet [dup desc] already exists\n"


def test_duplicate_in_a_snippetdir_is_not_checked(tmp_path):
    """Only the main file is searched for duplicate descriptions."""
    snippet = write_file(tmp_path / "snippets.toml", "")
    write_file(tmp_path / "dirA" / "a.toml",
               '\n[[Snippets]]\n  Description = "same desc"\n  command = "dc"\n')
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true",
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "new", "echo", "x"],
                  stdin=b"same desc\n", home=tmp_path)
    # CATCHES: the duplicate loop walks snippets loaded with includeDirs=false,
    # so a same-named snippet living in a snippetdir does not block the save.
    assert res.returncode == 0
    assert snippet.read_text() == canonical_snippets(
        {"Description": "same desc", "command": "echo x"}
    )


def test_sortby_reorders_the_rewritten_file(tmp_path):
    """SortBy=description re-orders the pre-existing snippets on save."""
    base = canonical_snippets(
        {"Description": "mid desc", "command": "bbb"},
        {"Description": "aaa desc", "command": "ccc"},
        {"Description": "zzz desc", "command": "aaa"},
    )
    snippet = write_file(tmp_path / "snippets.toml", base)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true",
                          sortby="description")
    res = run_pet(["--config", str(config), "new", "echo", "x"],
                  stdin=b"new desc\n", home=tmp_path)
    # CATCHES: Order() runs during Load(), so the rewrite sorts the old entries
    # (descending description) while the new snippet is appended afterwards.
    assert res.returncode == 0
    assert snippet.read_text() == canonical_snippets(
        {"Description": "zzz desc", "command": "aaa"},
        {"Description": "mid desc", "command": "bbb"},
        {"Description": "aaa desc", "command": "ccc"},
        {"Description": "new desc", "command": "echo x"},
    )


def test_sortby_minus_recency_reverses_the_file(tmp_path):
    """SortBy=-recency reverses the stored order before appending."""
    base = canonical_snippets(
        {"Description": "first", "command": "f"},
        {"Description": "second", "command": "s"},
        {"Description": "third", "command": "t"},
    )
    snippet = write_file(tmp_path / "snippets.toml", base)
    config = write_config(tmp_path, snippetfile=str(snippet), editor="true",
                          sortby="-recency")
    res = run_pet(["--config", str(config), "new", "echo", "x"],
                  stdin=b"new desc\n", home=tmp_path)
    # CATCHES: the "-recency" branch calls reverse() on the loaded slice, which
    # is what the encoder then writes out.
    assert res.returncode == 0
    assert snippet.read_text() == canonical_snippets(
        {"Description": "third", "command": "t"},
        {"Description": "second", "command": "s"},
        {"Description": "first", "command": "f"},
        {"Description": "new desc", "command": "echo x"},
    )


def test_special_characters_are_toml_escaped(tmp_path):
    """Quotes, backslashes and tabs in the answers are escaped in the file."""
    snippet, config = _setup(tmp_path)
    res = run_pet(
        ["--config", str(config), "new", 'echo "a\\b"', "tab\there"],
        stdin=b'desc with "quotes" and \\ back\n',
        home=tmp_path,
    )
    # CATCHES: the encoder escapes `"` and `\` and spells a TAB as the two
    # characters \t, while the echoed Command> line keeps the raw bytes.
    assert res.returncode == 0
    assert res.stdout == b'Command> echo "a\\b" tab\there\n'
    assert snippet.read_text() == (
        '\n[[Snippets]]\n'
        '  Description = "desc with \\"quotes\\" and \\\\ back"\n'
        '  Output = ""\n'
        '  Tag = []\n'
        '  command = "echo \\"a\\\\b\\" tab\\there"\n'
    )


def test_unicode_round_trips_untouched(tmp_path):
    """Non-ASCII command and description bytes are stored verbatim."""
    snippet, config = _setup(tmp_path)
    res = run_pet(["--config", str(config), "new", "echo", "日本語"],
                  stdin="ünïcödé desc\n".encode(), home=tmp_path)
    # CATCHES: the encoder writes UTF-8 without escaping, so both fields come
    # back byte for byte.
    assert res.returncode == 0
    assert res.stdout == "Command> echo 日本語\n".encode()
    assert snippet.read_text(encoding="utf-8") == canonical_snippets(
        {"Description": "ünïcödé desc", "command": "echo 日本語"}
    )


def test_empty_snippetfile_with_snippetdirs_is_an_error(tmp_path):
    """An empty snippetfile does not fall back to the first snippetdir."""
    write_file(tmp_path / "dirA" / "a.toml",
               '\n[[Snippets]]\n  Description = "d"\n  command = "c"\n')
    config = write_config(tmp_path, snippetfile="", editor="true",
                          snippetdirs=[str(tmp_path / "dirA")])
    res = run_pet(["--config", str(config), "new", "echo", "x"],
                  stdin=b"desc\n", home=tmp_path)
    # CATCHES: the README claims new snippets go to the first directory, but the
    # reference resolves the empty path first and fails with this exact error
    # before any prompt is shown.
    assert res.returncode == 255
    assert res.stdout == b"error resolving relative path - unknown path: \n"
    assert res.stderr == b""
    assert (tmp_path / "dirA" / "a.toml").read_text() == (
        '\n[[Snippets]]\n  Description = "d"\n  command = "c"\n'
    )
