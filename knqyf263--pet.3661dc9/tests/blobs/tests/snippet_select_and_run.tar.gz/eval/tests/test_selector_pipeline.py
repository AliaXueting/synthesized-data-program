"""The selector subprocess contract: stdin in, chosen lines back out.

The configured General.SelectCmd is executed through ``sh -c`` with the
rendered snippet lines on stdin and its stdout is parsed back into commands.
These tests pin how the parsed lines map back to snippets and what happens
when the selector misbehaves.
"""


def _store(pet):
    pet.write_snippets(
        pet.snippet("list files", "ls -la", ["fs", "common"]),
        pet.snippet("show date", "date", ["time"]),
        pet.snippet("greet", "echo hello"),
    )


def test_first_selected_line_resolves_to_its_command(pet):
    """A selector emitting one line picks exactly that snippet's command."""
    pet.write_config(selectcmd="head -n1")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the selected line must map back through the rendered-line map;
    # printing the whole store or the first snippet regardless of the choice
    # would betray a broken line-to-snippet resolution.
    assert result.stdout == b"ls -la"


def test_join_order_follows_selector_output_order(pet):
    """Multiple selected lines are joined in the order the selector printed."""
    pet.write_config(selectcmd="tac")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: pet does not re-sort the selector's output, so a selector that
    # reverses the lines yields the commands in reversed order.
    assert result.stdout == b"echo hello; date; ls -la"


def test_grep_selector_returns_only_matching_commands(pet):
    """An arbitrary filtering selector (grep) works without any TTY."""
    pet.write_config(selectcmd="grep date")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: any non-interactive selector works because the lines arrive on
    # stdin; a re-implementation requiring an fzf/peco style protocol fails.
    assert result.stdout == b"date"


def test_unknown_line_resolves_to_empty_command(pet):
    """A selected line that is not a rendered snippet maps to no command."""
    pet.write_config(selectcmd="echo NOT-A-SNIPPET-LINE")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: an unknown line yields an empty string command rather than an
    # error, so search prints nothing and still exits successfully.
    assert result.stdout == b""


def test_slightly_altered_line_no_longer_resolves(pet):
    """Line matching is exact: changing one character breaks the lookup."""
    pet.write_config(selectcmd="sed -e s/fs/XX/")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the map lookup is a byte-exact string compare, so the mutated
    # first line resolves to an empty command while the untouched lines still
    # resolve, leaving an empty slot at the front of the joined output.
    assert result.stdout == b"; date; echo hello"


def test_mixed_known_and_unknown_lines_keep_empty_slots(pet):
    """Unknown lines between known ones stay as empty join slots."""
    pet.write_config(
        selectcmd=(
            "printf '%s\\n' '[list files]: ls -la #fs #common ' 'BOGUS' "
            "'[greet]: echo hello '"
        )
    )
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: every selector output line becomes one joined command, unknown
    # ones included, so the middle slot is empty rather than dropped.
    assert result.stdout == b"ls -la; ; echo hello"


def test_selector_nonzero_exit_is_swallowed(pet):
    """A selector that fails outright still yields success and empty output."""
    pet.write_config(selectcmd="false")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: filter() discards the selector error (returns no commands), so
    # pet search exits 0 with empty stdout instead of propagating the error.
    assert result.stdout == b""
    assert result.stderr == b""


def test_selector_output_before_failure_is_discarded(pet):
    """A selector that prints a line and then exits non-zero is treated as failure."""
    pet.write_config(selectcmd="head -n1; exit 5")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: pet does not parse the selector's stdout when the process
    # failed, so even a fully valid printed line is thrown away.
    assert result.stdout == b""


def test_selector_stderr_is_passed_through(pet):
    """The selector's stderr is inherited, not captured or swallowed."""
    pet.write_config(selectcmd="echo SELECTOR-ERR >&2; head -n1")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the selector's stderr is wired to pet's own stderr while its
    # stdout stays captured, so the user still sees the selector complaining.
    assert result.stderr == b"SELECTOR-ERR\n"
    assert result.stdout == b"ls -la"


def test_selector_with_no_output_returns_empty(pet):
    """A selector that simply exits with no output selects nothing."""
    pet.write_config(selectcmd="true")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: an empty selector buffer still produces one empty line, which
    # resolves to an empty command, so search succeeds printing nothing.
    assert result.stdout == b""
    assert result.stderr == b""


def test_empty_snippet_store_searches_to_nothing(pet):
    """An existing but empty snippet store is not an error."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets()
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: with zero snippets the selector receives an empty stdin, its
    # empty output resolves to an empty command and pet still exits 0.
    assert result.stdout == b""
    assert result.stderr == b""


def test_selector_trailing_blank_line_becomes_empty_command(pet):
    """A trailing empty line from the selector is one more empty selection."""
    pet.write_config(selectcmd="head -n1; echo")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: only one trailing newline is trimmed from the buffer, so a
    # selector emitting an extra blank line adds an empty joined slot.
    assert result.stdout == b"ls -la; "
