"""selectFile() (reached through ``pet edit``) plus the shared runner plumbing.

``pet edit`` only calls selectFile() when General.SnippetDirs is configured,
so every test here configures a snippetdir; the editor is a harmless ``echo``
so the chosen snippet file path is what pet prints.
"""

import pytest


def _project(pet, selectcmd="selrec", snippetdirs=()):
    pet.write_config(
        selectcmd=selectcmd,
        editor="echo",
        snippetdirs=list(snippetdirs) or [pet.root / "d1"],
        fmt="FMT-SHOULD-BE-IGNORED",
    )
    directory = pet.root / "d1"
    directory.mkdir(exist_ok=True)
    (directory / "a.toml").write_text(pet.snippet("from dir A", "echo A", ["dir"]))
    (directory / "b.toml").write_text(pet.snippet("from dir B", "echo B", ["dir"]))
    pet.write_snippets(
        pet.snippet("list files", "ls -la", ["fs", "common"]),
        pet.snippet("show date", "date", ["time"]),
    )
    return directory


def test_selectfile_renders_its_own_line_layout(pet):
    """selectFile ignores General.Format and appends tags without a space."""
    _project(pet)
    result = pet.run("edit", stdin=b"", extra_env=pet.env_with_selector_head())
    assert result.returncode == 0
    # CATCHES: selectFile hardcodes "[%s]: %s" plus " #tag" per tag (no
    # trailing space) and never consults General.Format, unlike filter().
    assert pet.selector_stdin_log.read_bytes() == (
        b"[list files]: ls -la #fs #common\n"
        b"[show date]: date #time\n"
        b"[from dir A]: echo A #dir\n"
        b"[from dir B]: echo B #dir\n"
    )
    assert result.stdout == b"+0 " + str(pet.snippet_path).encode() + b"\n"


def test_selectfile_only_honours_the_first_selected_line(pet):
    """A selector returning every line still yields just one snippet file."""
    _project(pet, selectcmd="cat")
    result = pet.run("edit", stdin=b"")
    assert result.returncode == 0
    # CATCHES: only lines[0] is looked up, so a select-all does not try to
    # edit several files and the main store's file is the one edited.
    assert result.stdout == b"+0 " + str(pet.snippet_path).encode() + b"\n"


def test_selectfile_resolves_the_line_to_its_owning_file(pet):
    """Picking a directory snippet edits that snippet's own file."""
    directory = _project(pet, selectcmd="grep 'from dir B'")
    result = pet.run("edit", stdin=b"")
    assert result.returncode == 0
    # CATCHES: the chosen line maps back to the SnippetInfo carrying the
    # source filename, so the editor is pointed at b.toml, not the main file.
    assert result.stdout == b"+0 " + str(directory / "b.toml").encode() + b"\n"


def test_selectfile_honours_the_tag_filter(pet):
    """``-t`` filters the store before selectFile renders its lines."""
    _project(pet, selectcmd="selrec")
    result = pet.run("edit", "-t", "dir", stdin=b"",
                     extra_env=pet.env_with_selector_head())
    assert result.returncode == 0
    # CATCHES: the tag pre-filter runs in selectFile too, so only directory
    # snippets reach the selector and the main store stays invisible to it.
    assert pet.selector_stdin_log.read_bytes() == (
        b"[from dir A]: echo A #dir\n"
        b"[from dir B]: echo B #dir\n"
    )
    assert result.stdout == b"+0 " + str(pet.root / "d1" / "a.toml").encode() + b"\n"


def test_selectfile_with_an_unresolvable_line_reports_a_path_error(pet):
    """A selected line that maps to no snippet fails while resolving its path."""
    _project(pet, selectcmd="echo NOT-A-SNIPPET-LINE")
    result = pet.run("edit", stdin=b"")
    assert result.returncode == 255
    # CATCHES: an unknown line has an empty filename, and path resolution of
    # the empty string errors out with the "unknown path" message on stdout.
    assert result.stdout == b"error resolving relative path - unknown path: \n"
    assert result.stderr == b""


def test_selectfile_does_not_swallow_selector_failures(pet):
    """Unlike filter(), selectFile propagates a failing selector as an error."""
    _project(pet, selectcmd="grep nothing-matches")
    result = pet.run("edit", stdin=b"")
    assert result.returncode == 255
    # CATCHES: filter() discards selector errors while selectFile returns
    # them, so a selector exiting non-zero makes pet edit fail loudly.
    assert result.stdout == b"exit status 1\n"
    assert result.stderr == b""


def test_general_cmd_replaces_the_shell_runner_everywhere(pet):
    """General.Cmd is used for the selector and for the executed command."""
    pet.write_config(selectcmd="head -n1", cmd=("echo", "WRAPPED"))
    pet.write_snippets(pet.snippet("greet", "echo hi there"))
    search = pet.run("search")
    assert search.returncode == 0
    # CATCHES: with General.Cmd set, pet execs [echo WRAPPED <command>]
    # instead of `sh -c <command>`; the selector therefore never sees stdin
    # and search resolves nothing, while exec prints the wrapper's output.
    assert search.stdout == b""
    executed = pet.run("exec")
    assert executed.returncode == 0
    assert executed.stdout == b"> \nWRAPPED \n"


def test_general_cmd_receives_the_whole_command_as_one_argument(pet):
    """The command string is a single argv element for the Cmd wrapper."""
    pet.write_config(selectcmd="grep greet", cmd=("printf", "P<%s>"))
    pet.write_snippets(pet.snippet("greet", "echo hi there"))
    result = pet.run("exec")
    assert result.returncode == 0
    # CATCHES: the selector line "grep greet" is passed as one argument, so
    # printf's single %s consumes it whole; shell-style resplitting would
    # print one P<...> group per word instead.
    assert result.stdout == b"> \nP<>"


def test_unwritable_config_path_is_reported_on_stderr(pet):
    """A --config path that cannot be created aborts with status 1."""
    missing = pet.root / "no-such-dir" / "config.toml"
    result = pet.run("search", "--config", str(missing), use_config=False)
    assert result.returncode == 1
    # CATCHES: config creation failures go to STDERR with exit status 1,
    # unlike command errors which pet prints on stdout with status 255.
    assert result.stderr == (
        b"open " + str(missing).encode() + b": no such file or directory"
    )
    assert result.stdout == b""


def test_search_help_documents_the_selection_flags(pet):
    """``pet search --help`` lists the flags the selection pipeline owns."""
    result = pet.run("search", "--help")
    assert result.returncode == 0
    # CATCHES: the help text names --color/-d/--query/--raw/-t for search;
    # a re-implementation missing one of them (or adding exec's --silent)
    # produces a different flag block.
    assert result.stdout == (
        b"Search snippets interactively (default filtering tool: peco)\n"
        b"\n"
        b"Usage:\n"
        b"  pet search [flags]\n"
        b"\n"
        b"Flags:\n"
        b"      --color              Enable colorized output (only fzf)\n"
        b"  -d, --delimiter string   Use delim as the command delimiter character (default \"; \")\n"
        b"  -h, --help               help for search\n"
        b"  -q, --query string       Initial value for query\n"
        b"      --raw                Output raw command without entering parameter dialog\n"
        b"  -t, --tag string         Filter tag\n"
        b"\n"
        b"Global Flags:\n"
        b"      --config string   config file (default is $HOME/.config/pet/config.toml)\n"
        b"      --debug           debug mode\n"
    )
