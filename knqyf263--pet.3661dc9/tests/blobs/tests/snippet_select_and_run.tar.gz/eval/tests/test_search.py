"""``pet search``: output formatting, --query/--color/--raw/--delimiter flags."""

import pytest

SNIPPETS = (
    ("list files", "ls -la", ["fs"]),
    ("show date", "date", ["time"]),
    ("greet", "echo hello", None),
)


def _store(pet, snippets=SNIPPETS):
    pet.write_snippets(*(pet.snippet(*entry) for entry in snippets))


def test_search_prints_joined_commands_without_trailing_newline(pet):
    """stdout gets no newline after the joined commands when it is a pipe."""
    pet.write_config(selectcmd="cat")
    _store(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the trailing newline is only printed for terminals, so a piped
    # stdout ends immediately after the last command with no "\n" byte.
    assert result.stdout == b"ls -la; date; echo hello"


@pytest.mark.parametrize(
    ("delimiter", "expected"),
    [
        ("; ", b"ls -la; date; echo hello"),  # default
        (" || ", b"ls -la || date || echo hello"),
        ("@@@", b"ls -la@@@date@@@echo hello"),
        ("", b"ls -ladateecho hello"),
        (" # ", b"ls -la # date # echo hello"),
    ],
)
def test_search_delimiter_flag_joins_selections(pet, delimiter, expected):
    """``-d/--delimiter`` replaces the "; " join separator."""
    pet.write_config(selectcmd="cat")
    _store(pet)
    result = pet.run("search", "--delimiter", delimiter)
    assert result.returncode == 0
    # CATCHES: the delimiter is inserted verbatim between every selected
    # command (including an empty one) and is not quoted or trimmed.
    assert result.stdout == expected


def test_search_long_delimiter_flag_matches_short(pet):
    """``--delimiter`` and ``-d`` are the same flag."""
    pet.write_config(selectcmd="cat")
    _store(pet)
    short = pet.run("search", "-d", "<>")
    long = pet.run("search", "--delimiter", "<>")
    assert short.returncode == 0
    assert long.returncode == 0
    # CATCHES: both spellings bind the same string variable; a re-implementation
    # that only registers one of them fails with an unknown-flag error.
    assert short.stdout == long.stdout == b"ls -la<>date<>echo hello"


@pytest.mark.parametrize(
    "query",
    ["foo", "a b", "a; echo INJECTED", "it's", 'say "hi"', "$HOME", "a|b&c"],
)
def test_search_query_is_shell_escaped_into_one_argument(pet, query):
    """``-q`` appends ``--query <value>`` with the value shell-quoted."""
    pet.write_config(selectcmd="selrec")
    _store(pet)
    result = pet.run("search", "-q", query, extra_env=pet.env_with_selector_head())
    assert result.returncode == 0
    # CATCHES: search shell-escapes the query, so spaces, semicolons, quotes,
    # dollar signs and pipes all stay inside a single selector argument and
    # cannot split or inject into the selector command line.
    assert pet.selector_argv_log.read_text().splitlines() == [
        "ARG1:[--query]",
        f"ARG2:[{query}]",
    ]
    assert result.stdout == b"ls -la"


def test_search_empty_query_passes_no_selector_options(pet):
    """An empty ``-q`` value adds no ``--query`` argument at all."""
    pet.write_config(selectcmd="selrec")
    _store(pet)
    result = pet.run("search", "-q", "", extra_env=pet.env_with_selector_head())
    assert result.returncode == 0
    # CATCHES: the option is only appended when the query is non-empty, so an
    # empty -q leaves the selector argument list completely untouched.
    assert pet.selector_argv_log.read_text() == ""
    assert result.stdout == b"ls -la"


def test_search_color_flag_leaves_selector_input_plain(pet):
    """``--color`` still resolves the selection when color cannot be emitted."""
    pet.write_config(selectcmd="selrec")
    _store(pet)
    result = pet.run("search", "--color", extra_env=pet.env_with_selector_head())
    assert result.returncode == 0
    # CATCHES: with a non-terminal stdout (and TERM=dumb) the "colorized" line
    # is byte-identical to the plain one, so the choice still maps back to the
    # command instead of resolving to nothing.
    assert pet.selector_stdin_log.read_bytes() == (
        b"[list files]: ls -la #fs \n"
        b"[show date]: date #time \n"
        b"[greet]: echo hello \n"
    )
    assert result.stdout == b"ls -la"


def test_general_color_true_behaves_like_the_color_flag(pet):
    """General.Color = true in the config has the same effect as ``--color``."""
    pet.write_config(selectcmd="selrec", color=True)
    _store(pet)
    result = pet.run("search", extra_env=pet.env_with_selector_head())
    assert result.returncode == 0
    # CATCHES: the config switch and the flag share one code path, so a store
    # rendered with General.Color still resolves back to real commands.
    assert result.stdout == b"ls -la"
    assert pet.selector_stdin_log.read_bytes() == (
        b"[list files]: ls -la #fs \n"
        b"[show date]: date #time \n"
        b"[greet]: echo hello \n"
    )


def test_search_raw_emits_param_command_verbatim(pet):
    """``--raw`` skips the parameter dialog and prints the placeholders."""
    pet.write_config(selectcmd="grep param")
    pet.write_snippets(pet.snippet("param snippet", "echo VAL=<val=7>"))
    result = pet.run("search", "--raw")
    assert result.returncode == 0
    # CATCHES: with --raw the command text is emitted untouched, angle
    # brackets included, instead of being opened in the parameter dialog.
    assert result.stdout == b"echo VAL=<val=7>"


def test_search_param_snippet_without_raw_attempts_the_dialog(pet):
    """A single param selection without ``--raw`` starts the TUI dialog."""
    pet.write_config(selectcmd="grep param")
    pet.write_snippets(pet.snippet("param snippet", "echo VAL=<val=7>"))
    result = pet.run("search", timeout=20)
    assert result.returncode == 2
    # CATCHES: the parameter dialog is attempted (and dies without a usable
    # terminal) rather than printing the raw command; pet aborts with Go's
    # panic exit status 2 and nothing on stdout.
    assert result.stdout == b""
    assert b"panic: failed to initialize tcell screen" in result.stderr


def test_search_multi_line_selection_skips_the_param_dialog(pet):
    """Two selected lines bypass the parameter dialog entirely."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets(
        pet.snippet("plain", "echo PLAIN"),
        pet.snippet("param snippet", "echo VAL=<val=7>"),
    )
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the dialog only opens for exactly one selected line, so a
    # multi-selection returns every command verbatim, placeholders included.
    assert result.stdout == b"echo PLAIN; echo VAL=<val=7>"


def test_first_run_creates_default_config_with_fzf_selector(pet):
    """With no config file pet writes the default one and runs its fzf selector."""
    config_dir = pet.root / "petcfg"
    config_dir.mkdir()
    result = pet.run("search", use_config=False, extra_env={"PET_CONFIG_DIR": str(config_dir)})
    assert result.returncode == 0
    # CATCHES: the freshly generated default config uses an fzf selector; with
    # fzf absent the selector failure is swallowed, so search prints nothing
    # and still exits 0 while the shell reports the missing binary on stderr.
    assert result.stdout == b""
    assert result.stderr != b""
    generated = (config_dir / "config.toml").read_text()
    assert "fzf --ansi --layout=reverse" in generated
    assert (config_dir / "snippet.toml").exists()
