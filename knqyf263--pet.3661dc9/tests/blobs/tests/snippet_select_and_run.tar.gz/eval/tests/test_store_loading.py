"""Loading the snippet store for the selection pipeline.

search/exec/clip always load the main snippet file plus every ``*.toml``
under the configured snippetdirs before anything is rendered, so store-level
errors and ordering are observable through the selection commands.
"""

import pytest


def test_snippetdirs_are_loaded_after_the_main_file(pet):
    """Main store first, then each snippetdir's files, in walk order."""
    pet.write_config(
        selectcmd="cat",
        snippetdirs=[pet.make_snippetdir(
            "d1",
            {
                "a.toml": pet.snippet("dir A", "echo A", ["dir"]),
                "b.toml": pet.snippet("dir B", "echo B", ["dir"]),
            },
        )],
    )
    pet.write_snippets(pet.snippet("main one", "echo MAIN", ["main"]))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: directory snippets are appended after the main file's snippets,
    # not merged or sorted, so a select-all joins MAIN first then A then B.
    assert result.stdout == b"echo MAIN; echo A; echo B"


def test_overlapping_snippetdirs_load_the_same_file_twice(pet):
    """Directory walking is recursive and overlapping dirs duplicate snippets."""
    directory = pet.root / "d1"
    (directory / "sub").mkdir(parents=True)
    (directory / "a.toml").write_text(pet.snippet("dir A", "echo A"))
    (directory / "sub" / "c.toml").write_text(pet.snippet("dir C", "echo C"))
    pet.write_config(selectcmd="cat", snippetdirs=[directory, directory / "sub"])
    pet.write_snippets(pet.snippet("main one", "echo MAIN"))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the parent dir already walks its subdirectory, so listing both
    # loads c.toml twice and its command is selected (and joined) twice.
    assert result.stdout == b"echo MAIN; echo A; echo C; echo C"


def test_snippetdirs_ignore_files_without_toml_extension(pet):
    """Only ``*.toml`` files inside a snippetdir are loaded."""
    directory = pet.make_snippetdir(
        "d1",
        {
            "a.toml": pet.snippet("dir A", "echo A"),
            "notes.txt": pet.snippet("txt file", "echo TXT"),
            "README": pet.snippet("no ext", "echo README"),
        },
    )
    pet.write_config(selectcmd="cat", snippetdirs=[directory])
    pet.write_snippets()
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the file filter is a regexp on the *.toml suffix, so the .txt
    # and extension-less stores never contribute a selectable line.
    assert result.stdout == b"echo A"


def test_missing_snippetdir_is_an_error(pet):
    """A configured snippetdir that does not exist aborts the command."""
    pet.write_config(selectcmd="cat", snippetdirs=[pet.root / "no-such-dir"])
    pet.write_snippets(pet.snippet("main one", "echo MAIN"))
    result = pet.run("search")
    assert result.returncode == 255
    # CATCHES: snippetdirs are stat'ed before use and the failure surfaces as
    # a load error on stdout with exit status 255, not as an empty selection.
    assert result.stdout == (
        b"load snippet failed: snippet directory not found. "
        + str(pet.root / "no-such-dir").encode()
        + b"\n"
    )
    assert result.stderr == b""


def test_missing_snippet_file_is_an_error(pet):
    """A missing main snippet file aborts with the configure hint."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets()
    pet.snippet_path.unlink()
    result = pet.run("search")
    assert result.returncode == 255
    # CATCHES: the multi-line "snippet file not found" hint (including the
    # 'pet configure' advice) is printed on stdout, even for exec and clip.
    assert result.stdout == (
        b"load snippet failed: snippet file not found. "
        + str(pet.snippet_path).encode()
        + b"\nPlease run 'pet configure' and provide a correct file path, "
        b"or remove this\nif you only want to provide snippetdirs instead\n"
    )
    assert result.stderr == b""


def test_unparsable_snippet_file_is_an_error(pet):
    """A broken TOML store aborts with the parser position in the message."""
    pet.write_config(selectcmd="cat")
    pet.write_raw_snippets(
        '[[Snippets]]\n  Description = "bad"\n  command = "echo oops\n"\n'
    )
    result = pet.run("search")
    assert result.returncode == 255
    # CATCHES: a raw newline inside a basic TOML string makes go-toml fail and
    # pet prefixes the parser error with "failed to parse snippet file.".
    assert result.stdout.startswith(
        b"load snippet failed: failed to parse snippet file."
    )
    assert b"unescaped control character U+000A" in result.stdout


def test_relative_snippetfile_drops_its_first_two_characters(pet):
    """A relative SnippetFile is joined onto $HOME after chopping two chars."""
    (pet.home_dir / ".toml").write_text(pet.snippet("quirk", "echo STRIPPED"))
    pet.write_config(selectcmd="head -n1", snippetfile="xx.toml")
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: path expansion assumes a "~/..." prefix, so "xx.toml" resolves
    # to $HOME/.toml (first two characters dropped), not $HOME/xx.toml and
    # not a cwd-relative path.
    assert result.stdout == b"echo STRIPPED"


def test_relative_snippetfile_without_home_is_an_error(pet):
    """With $HOME unset a relative store path fails before any selection."""
    pet.write_config(selectcmd="head -n1", snippetfile="xx.toml")
    pet.write_snippets()
    result = pet.run("search", extra_env={"HOME": None})
    assert result.returncode == 255
    # CATCHES: the home directory is resolved lazily through $HOME; without it
    # pet reports the "unknown home dir" wrapping error and exits 255.
    assert result.stdout == (
        b"load snippet failed: error resolving relative path - "
        b"unknown home dir:\n$HOME is not defined\n"
    )


@pytest.mark.parametrize(
    ("sortby", "expected"),
    [
        ("", b"echo ZEBRA; echo MID; echo ALPHA"),  # file order (recency default)
        ("recency", b"echo ZEBRA; echo MID; echo ALPHA"),
        ("-recency", b"echo ALPHA; echo MID; echo ZEBRA"),
        ("command", b"echo ZEBRA; echo MID; echo ALPHA"),  # descending
        ("+command", b"echo ZEBRA; echo MID; echo ALPHA"),
        ("-command", b"echo ALPHA; echo MID; echo ZEBRA"),
        ("description", b"echo MID; echo ZEBRA; echo ALPHA"),  # descending
        ("+description", b"echo MID; echo ZEBRA; echo ALPHA"),
        ("-description", b"echo ALPHA; echo ZEBRA; echo MID"),
    ],
)
def test_sortby_reorders_the_lines_offered_to_the_selector(pet, sortby, expected):
    """General.SortBy reorders the store before the lines are rendered."""
    pet.write_config(selectcmd="cat", sortby=sortby)
    pet.write_snippets(
        pet.snippet("bbb", "echo ZEBRA"),
        pet.snippet("ccc", "echo MID"),
        pet.snippet("aaa", "echo ALPHA"),
    )
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the store order handed to the selector depends on the sort mode
    # ("command"/"description" sort descending, a "-" prefix reverses and
    # "recency" keeps file order), so a wrong order joins different commands.
    assert result.stdout == expected
