"""``pet clip``: joining the selection and handing it to the clipboard.

The clipboard itself is provided by a fake ``xclip`` on the private PATH
(atotto/clipboard runs ``xclip -in -selection clipboard`` and writes the
payload on its stdin), which makes both the success and the failure paths
observable without a display server.
"""

import pytest

SNIPPETS = (
    ("list files", "ls -la", ["fs"]),
    ("show date", "date", ["time"]),
    ("greet", "echo hello", None),
)


def _store(pet):
    pet.write_snippets(*(pet.snippet(*entry) for entry in SNIPPETS))


def test_clip_copies_the_selected_command_to_the_clipboard(pet):
    """A single selection is copied verbatim, without a trailing newline."""
    pet.write_config(selectcmd="grep greet")
    _store(pet)
    result = pet.run("clip", use_xclip=True)
    assert result.returncode == 0
    # CATCHES: the clipboard receives exactly the resolved command bytes; an
    # implementation that copies the rendered line or appends a newline fails.
    assert pet.clipboard_log.read_bytes() == b"echo hello"
    assert pet.clipboard_argv_log.read_text() == "-in -selection clipboard\n"
    assert result.stdout == b""


def test_clip_joins_selections_with_the_delimiter_flag(pet):
    """Multiple selections are joined with ``-d`` before copying."""
    pet.write_config(selectcmd="cat")
    _store(pet)
    result = pet.run("clip", "-d", "@@@", use_xclip=True)
    assert result.returncode == 0
    # CATCHES: clip honours --delimiter just like search, so the copied text
    # is the joined commands rather than a newline separated list.
    assert pet.clipboard_log.read_bytes() == b"ls -la@@@date@@@echo hello"


def test_clip_command_flag_prints_the_command_line(pet):
    """``--command`` echoes ``Command: <command>`` before copying."""
    pet.write_config(selectcmd="grep greet")
    _store(pet)
    result = pet.run("clip", "--command", use_xclip=True)
    assert result.returncode == 0
    # CATCHES: the label is printed as "Command: " followed by the joined
    # command and a newline, on stdout, even though the copy itself is silent.
    assert result.stdout == b"Command: echo hello\n"
    assert pet.clipboard_log.read_bytes() == b"echo hello"


def test_clip_command_flag_prints_nothing_for_an_empty_selection(pet):
    """``--command`` stays quiet when the joined command is empty."""
    pet.write_config(selectcmd="true")
    _store(pet)
    result = pet.run("clip", "--command", use_xclip=True)
    assert result.returncode == 0
    # CATCHES: the echo is guarded by a non-empty command check, so a selector
    # that selects nothing copies an empty clipboard without printing.
    assert result.stdout == b""
    assert pet.clipboard_log.read_bytes() == b""


def test_clip_without_any_clipboard_utility_fails(pet):
    """With no xclip/xsel available pet reports the missing utility."""
    pet.write_config(selectcmd="grep greet")
    _store(pet)
    result = pet.run("clip")
    assert result.returncode == 255
    # CATCHES: the atotto/clipboard "No clipboard utilities available" error
    # is printed on stdout and pet exits 255 instead of succeeding silently.
    assert result.stdout == (
        b"No clipboard utilities available. Please install xsel, xclip, "
        b"wl-clipboard or Termux:API add-on for termux-clipboard-get/set.\n"
    )
    assert result.stderr == b""


def test_clip_command_flag_prints_before_the_clipboard_error(pet):
    """``--command`` output comes first, then the clipboard failure."""
    pet.write_config(selectcmd="grep greet")
    _store(pet)
    result = pet.run("clip", "--command")
    assert result.returncode == 255
    # CATCHES: the Command line is printed before the clipboard write is
    # attempted, so both lines end up on stdout in that order.
    assert result.stdout == (
        b"Command: echo hello\n"
        b"No clipboard utilities available. Please install xsel, xclip, "
        b"wl-clipboard or Termux:API add-on for termux-clipboard-get/set.\n"
    )


def test_clip_clipboard_helper_failure_reports_exit_status(pet):
    """A clipboard helper exiting non-zero surfaces as "exit status N"."""
    pet.write_config(selectcmd="grep greet")
    _store(pet)
    result = pet.run("clip", use_xclip=True, extra_env={"XCLIP_EXIT": "7"})
    assert result.returncode == 255
    # CATCHES: the helper still receives the payload first, then its exit
    # status is wrapped into the error pet prints on stdout.
    assert pet.clipboard_log.read_bytes() == b"echo hello"
    assert result.stdout == b"exit status 7\n"


def test_clip_raw_copies_param_command_verbatim(pet):
    """``--raw`` copies the command with its ``<param>`` placeholders."""
    pet.write_config(selectcmd="grep param")
    pet.write_snippets(pet.snippet("param snippet", "echo VAL=<val=7>"))
    result = pet.run("clip", "--raw", use_xclip=True)
    assert result.returncode == 0
    # CATCHES: --raw skips the parameter dialog, so the clipboard holds the
    # literal placeholder text rather than an expanded command.
    assert pet.clipboard_log.read_bytes() == b"echo VAL=<val=7>"


def test_clip_param_snippet_without_raw_attempts_the_dialog(pet):
    """A single param selection without ``--raw`` opens the dialog instead."""
    pet.write_config(selectcmd="grep param")
    pet.write_snippets(pet.snippet("param snippet", "echo VAL=<val=7>"))
    result = pet.run("clip", timeout=20)
    assert result.returncode == 2
    # CATCHES: clip tries to expand parameters like search does, so the
    # clipboard is never written and pet dies in the dialog with status 2.
    assert result.stdout == b""
    assert b"panic: failed to initialize tcell screen" in result.stderr


def test_clip_query_is_not_shell_escaped(pet):
    """clip appends the raw query, so a spaced query splits into arguments."""
    pet.write_config(selectcmd="selrec")
    _store(pet)
    result = pet.run("clip", "-q", "a b", use_xclip=True,
                     extra_env=pet.env_with_selector_head())
    assert result.returncode == 0
    # CATCHES: unlike search/exec, clip does not shell-escape the query, so
    # "a b" arrives at the selector as two separate arguments.
    assert pet.selector_argv_log.read_text().splitlines() == [
        "ARG1:[--query]",
        "ARG2:[a]",
        "ARG3:[b]",
    ]
    assert pet.clipboard_log.read_bytes() == b"ls -la"


def test_clip_query_semicolon_injects_into_the_selector_command(pet):
    """An unescaped ``;`` in the query breaks out of the selector invocation."""
    pet.write_config(selectcmd="selrec")
    _store(pet)
    result = pet.run("clip", "-q", "a; echo INJECTED", use_xclip=True)
    assert result.returncode == 0
    # CATCHES: the query text is concatenated raw, so the semicolon ends the
    # selector command and "echo INJECTED" runs as a second shell command
    # whose output pet treats as an extra (unresolvable) selected line.
    assert pet.selector_argv_log.read_text().splitlines() == [
        "ARG1:[--query]",
        "ARG2:[a]",
    ]
    assert pet.clipboard_log.read_bytes() == b"ls -la; date; echo hello; "


@pytest.mark.parametrize(
    ("args", "message"),
    [
        (("--color",), b"unknown flag: --color\n"),
        (("-s",), b"unknown shorthand flag: 's' in -s\n"),
    ],
)
def test_clip_rejects_flags_it_does_not_own(pet, args, message):
    """Flags belonging to search/exec are rejected by clip."""
    pet.write_config(selectcmd="grep greet")
    _store(pet)
    result = pet.run("clip", *args)
    assert result.returncode == 255
    # CATCHES: clip owns --command/-d/-q/--raw/-t only; the usage error goes
    # to stdout with exit status 255 because errors are silenced on stderr.
    assert result.stdout == message
