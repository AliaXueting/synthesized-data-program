"""How filter() renders snippet lines and how ``-t/--tag`` pre-filters them.

These tests pin the exact bytes pet pipes into the selector (captured with a
recording selector helper) and the commands the selection resolves back to.
"""

SELECTOR_ALL = "selrec"  # records stdin/argv, echoes every line back


def _three_snippets(pet):
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_snippets(
        pet.snippet("list files", "ls -la", ["fs", "common"]),
        pet.snippet("show date", "date", ["time"]),
        pet.snippet("greet", "echo hello"),
    )


def test_default_format_renders_description_command_tags(pet):
    """Default layout is ``[$description]: $command $tags`` per snippet."""
    _three_snippets(pet)
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: a re-implementation that swaps the slots, drops the brackets or
    # forgets the space between $command and $tags feeds the selector
    # differently and the selection no longer maps back to a command.
    assert pet.selector_stdin_log.read_bytes() == (
        b"[list files]: ls -la #fs #common \n"
        b"[show date]: date #time \n"
        b"[greet]: echo hello \n"
    )
    assert result.stdout == b"ls -la; date; echo hello"


def test_every_tag_renders_as_hash_prefix_with_trailing_space(pet):
    """Each tag becomes ``#<tag> `` so three tags span ``#a #b #c ``."""
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_snippets(pet.snippet("t", "cmd", ["a", "b", "c"]))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the tag block keeps one trailing space (it is "#%s " per tag),
    # not a separator-joined list, and the line still resolves to the command.
    assert pet.selector_stdin_log.read_bytes() == b"[t]: cmd #a #b #c \n"
    assert result.stdout == b"cmd"


def test_untagged_snippet_leaves_empty_tags_slot(pet):
    """A snippet without tags keeps the format's space, i.e. a trailing blank."""
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_snippets(pet.snippet("solo", "echo plain"))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the literal "[$description]: $command $tags" leaves a trailing
    # space when $tags is empty; trimming it would break the lookup key.
    assert pet.selector_stdin_log.read_bytes() == b"[solo]: echo plain \n"
    assert result.stdout == b"echo plain"


def test_multiline_command_is_rendered_with_literal_backslash_n(pet):
    """Real newlines in a command become the two characters ``\\n`` on the line."""
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_snippets(pet.snippet("multi", "echo one\necho two", ["a"]))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the selector must stay a single line, yet the resolved command
    # keeps its real newlines when pet prints it back out.
    assert pet.selector_stdin_log.read_bytes() == b"[multi]: echo one\\necho two #a \n"
    assert result.stdout == b"echo one\necho two"


def test_literal_backslash_n_inside_command_is_kept_verbatim(pet):
    """A command that already contains ``\\n`` as text is not double-escaped."""
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_raw_snippets(
        "[[Snippets]]\n"
        "  Description = 'bs'\n"
        "  Output = ''\n"
        "  command = 'echo a\\nb'\n"
    )
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: only actual newline bytes are rewritten; a backslash-n already
    # present in the stored command must survive untouched.
    assert pet.selector_stdin_log.read_bytes() == b"[bs]: echo a\\nb \n"
    assert result.stdout == b"echo a\\nb"


def test_custom_format_from_config_is_used(pet):
    """General.Format replaces the default layout entirely."""
    pet.write_config(selectcmd=SELECTOR_ALL, fmt="$command ### $description")
    pet.write_snippets(
        pet.snippet("first", "cmd-one"),
        pet.snippet("second", "cmd-two"),
    )
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the config format drives the line layout; an implementation
    # ignoring General.Format would emit the default "[...]: ..." layout.
    assert pet.selector_stdin_log.read_bytes() == (
        b"cmd-one ### first\ncmd-two ### second\n"
    )
    assert result.stdout == b"cmd-one; cmd-two"


def test_only_first_placeholder_occurrence_is_substituted(pet):
    """Each $placeholder is replaced exactly once (strings.Replace n=1)."""
    pet.write_config(selectcmd=SELECTOR_ALL, fmt="$description-$description")
    pet.write_snippets(pet.snippet("alpha", "cmd"))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: pet substitutes only the first occurrence, so the second
    # $description stays literal in the selector line.
    assert pet.selector_stdin_log.read_bytes() == b"alpha-$description\n"
    assert result.stdout == b"cmd"


def test_default_format_leaves_dollar_description_in_command_alone(pet):
    """With the default layout the format's own $description absorbs the swap."""
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_snippets(pet.snippet("has dollar", "echo $description"))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: $command is expanded first, then the FIRST $description is
    # replaced; in the default layout that first occurrence is the format's
    # own placeholder, so the copy inside the command text stays literal.
    assert pet.selector_stdin_log.read_bytes() == (
        b"[has dollar]: echo $description \n"
    )
    assert result.stdout == b"echo $description"


def test_command_text_is_substituted_into_later_placeholders(pet):
    """$command is expanded first, so its text is rescanned for $description."""
    pet.write_config(selectcmd=SELECTOR_ALL, fmt="$command ### $description")
    pet.write_snippets(pet.snippet("has dollar", "echo $description"))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: placeholders are expanded in order command -> description ->
    # tags, so when the command itself injects a $description token and no
    # earlier occurrence exists, that token gets replaced by the description.
    assert pet.selector_stdin_log.read_bytes() == (
        b"echo has dollar ### $description\n"
    )
    assert result.stdout == b"echo $description"


def test_description_text_is_substituted_into_tags_placeholder(pet):
    """A $tags token inside a description swallows the single $tags expansion."""
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_raw_snippets(
        "[[Snippets]]\n"
        "  Description = 'say $tags now'\n"
        "  Output = ''\n"
        "  Tag = ['t1']\n"
        "  command = 'x1'\n"
    )
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: only one $tags replacement happens and it lands on the earliest
    # occurrence, which here sits inside the description text.
    assert pet.selector_stdin_log.read_bytes() == b"[say #t1  now]: x1 $tags\n"
    assert result.stdout == b"x1"


def test_placeholder_free_format_collapses_every_snippet(pet):
    """A format without placeholders makes all lines identical; last store wins."""
    pet.write_config(selectcmd=SELECTOR_ALL, fmt="CONST")
    pet.write_snippets(
        pet.snippet("alpha", "cmd-alpha"),
        pet.snippet("beta", "cmd-beta"),
    )
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the rendered lines are map keys, so identical lines collapse
    # onto the last snippet loaded and every selection returns cmd-beta.
    assert pet.selector_stdin_log.read_bytes() == b"CONST\nCONST\n"
    assert result.stdout == b"cmd-beta; cmd-beta"


def test_tags_only_format_prefixes_hash_block(pet):
    """A format of just ``$tags`` shows the trailing space per tag."""
    pet.write_config(selectcmd=SELECTOR_ALL, fmt="$tags|$command")
    pet.write_snippets(
        pet.snippet("one", "x1", ["t1"]),
        pet.snippet("none", "x2"),
    )
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: untagged snippets render an empty tags field, keeping the "|"
    # glued to the front of the line, and both selections still resolve.
    assert pet.selector_stdin_log.read_bytes() == b"#t1 |x1\n|x2\n"
    assert result.stdout == b"x1; x2"


def test_empty_command_snippet_renders_double_space(pet):
    """An empty command leaves the ``$command $tags`` gap as two spaces."""
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_snippets(pet.snippet("empty", "", ["e"]))
    result = pet.run("search")
    assert result.returncode == 0
    # CATCHES: the empty command resolves to an empty output string rather
    # than being skipped, so search prints nothing but still exits 0.
    assert pet.selector_stdin_log.read_bytes() == b"[empty]:  #e \n"
    assert result.stdout == b""


# ---------------------------------------------------------------------------
# tag pre-filtering
# ---------------------------------------------------------------------------


def test_tag_filter_selects_only_exact_tag_matches(pet):
    """``-t`` keeps snippets whose tag list contains the exact string."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets(
        pet.snippet("list files", "ls -la", ["fs", "common"]),
        pet.snippet("show date", "date", ["time"]),
    )
    result = pet.run("search", "-t", "fs")
    assert result.returncode == 0
    # CATCHES: unlike `pet list`, the tag filter here is a single exact match,
    # not a comma split, and the filtered snippet is the only line offered.
    assert result.stdout == b"ls -la"


def test_tag_filter_restricts_what_the_selector_receives(pet):
    """Pre-filtering happens before the selector, not after it."""
    pet.write_config(selectcmd=SELECTOR_ALL)
    pet.write_snippets(
        pet.snippet("list files", "ls -la", ["fs", "common"]),
        pet.snippet("show date", "date", ["time"]),
    )
    result = pet.run("search", "-t", "time")
    assert result.returncode == 0
    # CATCHES: only the matching snippet's line is piped to the selector, so a
    # selector echoing everything back cannot return the other commands.
    assert pet.selector_stdin_log.read_bytes() == b"[show date]: date #time \n"
    assert result.stdout == b"date"


def test_tag_filter_does_not_split_commas(pet):
    """``-t a,b`` matches nothing: no comma splitting in search/exec/clip."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets(
        pet.snippet("list files", "ls -la", ["fs", "common"]),
        pet.snippet("show date", "date", ["time"]),
    )
    result = pet.run("search", "-t", "fs,common")
    assert result.returncode == 0
    # CATCHES: `pet list -t` splits on commas but the selection pipeline does
    # a whole-string tag comparison, so the comma list selects nothing.
    assert result.stdout == b""


def test_tag_filter_is_case_sensitive(pet):
    """Tag matching compares exact strings, so ``FS`` never matches ``fs``."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets(pet.snippet("list files", "ls -la", ["fs"]))
    result = pet.run("search", "-t", "FS")
    assert result.returncode == 0
    # CATCHES: the filter is a plain == on the tag string; a case-insensitive
    # re-implementation would find the snippet and print its command.
    assert result.stdout == b""


def test_tag_filter_repeats_snippet_once_per_matching_tag(pet):
    """A snippet listing the same tag twice appears twice after filtering."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets(
        pet.snippet("dup tags", "echo dup", ["x", "x"]),
        pet.snippet("other", "echo other", ["y"]),
    )
    result = pet.run("search", "-t", "x")
    assert result.returncode == 0
    # CATCHES: the filter appends the snippet inside the per-tag loop, so a
    # duplicated tag duplicates the line and the command is selected twice.
    assert result.stdout == b"echo dup; echo dup"


def test_tag_containing_a_space_matches_exactly(pet):
    """Tags are compared as whole strings, spaces included."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets(
        pet.snippet("spaced", "echo spaced", ["my tag"]),
        pet.snippet("plain", "echo plain", ["my"]),
    )
    result = pet.run("search", "-t", "my tag")
    assert result.returncode == 0
    # CATCHES: the tag value is not tokenised on whitespace, so only the
    # snippet carrying the literal tag "my tag" survives the filter.
    assert result.stdout == b"echo spaced"


def test_repeated_tag_flag_last_one_wins(pet):
    """Passing ``-t`` twice keeps only the final value, like any string flag."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets(
        pet.snippet("a", "echo a", ["ta"]),
        pet.snippet("b", "echo b", ["tb"]),
    )
    result = pet.run("search", "-t", "ta", "-t", "tb")
    assert result.returncode == 0
    # CATCHES: cobra string flags are overwritten, not accumulated, so the
    # second -t replaces the first and only "echo b" is selectable.
    assert result.stdout == b"echo b"
