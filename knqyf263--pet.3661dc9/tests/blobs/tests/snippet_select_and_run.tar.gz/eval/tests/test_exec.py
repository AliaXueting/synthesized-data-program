"""``pet exec``: printing, running and reporting the selected command."""

import pytest


def test_exec_prints_prefix_then_the_command_output(pet):
    """``> <command>`` is printed first, then the child's stdout follows."""
    pet.write_config(selectcmd="grep greet")
    pet.write_snippets(pet.snippet("greet", "echo hi there"))
    result = pet.run("exec")
    assert result.returncode == 0
    # CATCHES: the echoed prefix line and the child's output share pet's
    # stdout in that order; losing the prefix or reordering them is visible.
    assert result.stdout == b"> echo hi there\nhi there\n"
    assert result.stderr == b""


@pytest.mark.parametrize("flag", ["-s", "--silent"])
def test_exec_silent_flag_suppresses_the_prefix(pet, flag):
    """``-s/--silent`` drops only the ``>`` prefix line, not the output."""
    pet.write_config(selectcmd="grep greet")
    pet.write_snippets(pet.snippet("greet", "echo hi there"))
    result = pet.run("exec", flag)
    assert result.returncode == 0
    # CATCHES: silent hides the echoed command but the executed command still
    # writes to pet's stdout and the exit status stays successful.
    assert result.stdout == b"hi there\n"


def test_exec_failing_command_reports_exit_status(pet):
    """A failing child surfaces as an error printed on stdout with status 255."""
    pet.write_config(selectcmd="grep fail")
    pet.write_snippets(pet.snippet("fail", "echo to-stderr >&2; exit 3"))
    result = pet.run("exec")
    assert result.returncode == 255
    # CATCHES: pet wraps the child's exit status as "exit status N", prints it
    # on STDOUT (not stderr) and exits with 255 (os.Exit(-1)).
    assert result.stdout == b"> echo to-stderr >&2; exit 3\nexit status 3\n"
    assert result.stderr == b"to-stderr\n"


def test_exec_child_stderr_is_inherited(pet):
    """The executed command's stderr lands on pet's stderr unchanged."""
    pet.write_config(selectcmd="grep warn")
    pet.write_snippets(pet.snippet("warn", "echo CHILD-STDERR >&2"))
    result = pet.run("exec")
    assert result.returncode == 0
    # CATCHES: stdout and stderr of the child are wired to the corresponding
    # pet streams separately, so interleaving or redirecting them is a bug.
    assert result.stdout == b"> echo CHILD-STDERR >&2\n"
    assert result.stderr == b"CHILD-STDERR\n"


def test_exec_passes_its_own_stdin_to_the_command(pet):
    """pet's stdin is handed to the executed command."""
    pet.write_config(selectcmd="grep 'read stdin'")
    pet.write_snippets(pet.snippet("read stdin", "cat"))
    result = pet.run("exec", stdin=b"PIPED-STDIN-DATA\n")
    assert result.returncode == 0
    # CATCHES: the selector consumes the rendered lines, not pet's stdin, so
    # the remaining input is still readable by the executed command.
    assert result.stdout == b"> cat\nPIPED-STDIN-DATA\n"


def test_exec_joins_selections_with_a_hardcoded_separator(pet):
    """exec always joins with "; " and offers no --delimiter flag."""
    pet.write_config(selectcmd="cat")
    pet.write_snippets(
        pet.snippet("one", "echo ONE"),
        pet.snippet("two", "echo TWO"),
    )
    result = pet.run("exec")
    assert result.returncode == 0
    # CATCHES: unlike search/clip, exec ignores any delimiter idea and joins
    # the selected commands with "; " before printing and running them as one
    # shell script.
    assert result.stdout == b"> echo ONE; echo TWO\nONE\nTWO\n"


def test_exec_runs_multiline_command_as_a_shell_script(pet):
    """A multi-line command keeps its newlines when executed."""
    pet.write_config(selectcmd="grep multi")
    pet.write_snippets(pet.snippet("multi", "echo line1\necho line2"))
    result = pet.run("exec")
    assert result.returncode == 0
    # CATCHES: the stored newlines are only escaped for the selector line;
    # the executed command keeps them, so both lines run and print.
    assert result.stdout == b"> echo line1\necho line2\nline1\nline2\n"


def test_exec_selector_failure_still_prints_an_empty_prefix(pet):
    """A failing selector yields an empty command that is still "run"."""
    pet.write_config(selectcmd="false")
    pet.write_snippets(pet.snippet("greet", "echo hi there"))
    result = pet.run("exec")
    assert result.returncode == 0
    # CATCHES: the swallowed selector error leaves one empty command, so exec
    # prints "> " (with the trailing space) and successfully runs an empty
    # shell command.
    assert result.stdout == b"> \n"
    assert result.stderr == b""


def test_exec_accepts_extra_positional_arguments(pet):
    """exec ignores positional arguments instead of rejecting them."""
    pet.write_config(selectcmd="grep greet")
    pet.write_snippets(pet.snippet("greet", "echo hi there"))
    result = pet.run("exec", "some", "leftover", "args")
    assert result.returncode == 0
    # CATCHES: the command takes no positional arguments but does not error
    # on them either; a re-implementation with a strict arg validator fails.
    assert result.stdout == b"> echo hi there\nhi there\n"


def test_exec_query_is_shell_escaped_like_search(pet):
    """exec shares search's shell-escaped ``--query`` handling."""
    pet.write_config(selectcmd="selrec")
    pet.write_snippets(pet.snippet("greet", "echo hi there"))
    result = pet.run("exec", "-q", "a; rm -rf /", extra_env=pet.env_with_selector_head())
    assert result.returncode == 0
    # CATCHES: exec shell-escapes the query exactly like search, so the
    # semicolon payload stays one selector argument and cannot inject.
    assert pet.selector_argv_log.read_text().splitlines() == [
        "ARG1:[--query]",
        "ARG2:[a; rm -rf /]",
    ]
    assert result.stdout == b"> echo hi there\nhi there\n"


def test_exec_param_snippet_attempts_the_dialog(pet):
    """exec has no --raw flag, so a single param selection always opens the dialog."""
    pet.write_config(selectcmd="grep param")
    pet.write_snippets(pet.snippet("param snippet", "echo VAL=<val=7>"))
    result = pet.run("exec", timeout=20)
    assert result.returncode == 2
    # CATCHES: exec always asks filter() to expand parameters, so selecting a
    # <param> command aborts into the dialog instead of running the command.
    assert result.stdout == b""
    assert b"panic: failed to initialize tcell screen" in result.stderr


@pytest.mark.parametrize(
    ("args", "message"),
    [
        (("-d", "X"), b"unknown shorthand flag: 'd' in -d\n"),
        (("--delimiter", "X"), b"unknown flag: --delimiter\n"),
        (("--raw",), b"unknown flag: --raw\n"),
        (("--color=maybe",), b"invalid argument \"maybe\" for \"--color\" flag: strconv.ParseBool: parsing \"maybe\": invalid syntax\n"),
    ],
)
def test_exec_rejects_flags_it_does_not_own(pet, args, message):
    """Flags belonging to search/clip are rejected by exec."""
    pet.write_config(selectcmd="grep greet")
    pet.write_snippets(pet.snippet("greet", "echo hi there"))
    result = pet.run("exec", *args)
    assert result.returncode == 255
    # CATCHES: exec only owns --color/-q/-t/-s; anything else is a usage error
    # printed on stdout (SilenceErrors) with exit status 255.
    assert result.stdout == message
    assert result.stderr == b""
