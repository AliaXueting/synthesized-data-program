"""Shared harness for the ``snippet_select_and_run`` module tests.

Every test drives the reference binary through its CLI only.  The binary is
resolved from ``PROGRAMGYM_EXECUTABLE``; each test gets a throwaway project
directory holding a config file, a snippet store, a private ``PATH`` and a
pinned child environment, so nothing depends on the machine running the suite.
"""

import os
import shutil
import subprocess
from pathlib import Path

import pytest

PROGRAMGYM_ENV_VAR = "PROGRAMGYM_EXECUTABLE"

#: default selector used by the fixtures (deterministic, non-interactive)
DEFAULT_SELECTCMD = "head -n1"

#: binaries the ``sh -c`` runner and the selector helpers rely on.  They are
#: symlinked into the private PATH so the child never sees the host $PATH.
PATH_TOOLS = (
    "sh",
    "cat",
    "echo",
    "grep",
    "head",
    "printf",
    "sed",
    "tac",
    "tail",
    "tee",
)

#: selector helper: records the argv pet handed it, tees the snippet lines pet
#: piped into it, and echoes either every line or only the first one back.
SELECTOR_HELPER = """\
#!/bin/sh
n=0
for a in "$@"; do
  n=$((n + 1))
  printf 'ARG%d:[%s]\\n' "$n" "$a"
done > "${SEL_ARGV_OUT:-/dev/null}"
if [ "${SEL_HEAD:-0}" = "1" ]; then
  tee "${SEL_STDIN_OUT:-/dev/null}" | head -n1
else
  tee "${SEL_STDIN_OUT:-/dev/null}"
fi
"""

#: fake clipboard helper standing in for xclip (atotto/clipboard runs
#: ``xclip -in -selection clipboard`` and writes the payload on its stdin).
XCLIP_HELPER = """\
#!/bin/sh
printf '%s\\n' "$*" > "${XCLIP_ARGV_OUT:?}"
cat > "${XCLIP_STDIN_OUT:?}"
if [ -n "${XCLIP_EXIT:-}" ]; then
  exit "$XCLIP_EXIT"
fi
"""

CONFIG_TEMPLATE = """\
[Gist]
  file_name = "pet-snippet.toml"

[General]
  Backend = "gist"
  Cmd = [{cmd}]
  Color = {color}
  Column = 40
  Editor = "{editor}"
  Format = "{fmt}"
  SelectCmd = "{selectcmd}"
  SnippetDirs = [{snippetdirs}]
  SnippetFile = "{snippetfile}"
  SortBy = "{sortby}"

[GitLab]
  Visibility = "private"
  file_name = "pet-snippet.toml"
"""


def _program_path():
    """Resolve the reference binary from PROGRAMGYM_EXECUTABLE."""
    value = os.environ.get(PROGRAMGYM_ENV_VAR)
    if not value:
        raise RuntimeError(
            f"{PROGRAMGYM_ENV_VAR} must point at the reference executable"
        )
    path = Path(value)
    if not path.is_file():
        raise RuntimeError(f"{PROGRAMGYM_ENV_VAR} does not name a file: {value}")
    return str(path)


def run_pet(args, *, cwd=None, env=None, stdin=None, timeout=30):
    """Run the reference binary once and return the completed process.

    ``args`` is the argv after the program name.  ``env`` is used verbatim when
    given; otherwise a minimal pinned environment (host PATH, TERM=dumb plus
    the GOCOVERDIR passthrough) is built.  All module tests go through this
    helper, indirectly via :class:`PetProject`.
    """
    if env is None:
        env = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "HOME": os.environ.get("HOME", "/nonexistent"),
            "TERM": "dumb",
        }
        cover_dir = os.environ.get("GOCOVERDIR")
        if cover_dir:
            env["GOCOVERDIR"] = cover_dir
    return subprocess.run(
        [_program_path(), *args],
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        cwd=str(cwd) if cwd else None,
        timeout=timeout,
    )


def toml_basic(value):
    """Quote ``value`` as a TOML basic string."""
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return '"' + escaped + '"'


def toml_literal(value):
    """Quote ``value`` as a TOML literal string (no escape processing)."""
    if "'" in value:
        raise ValueError("TOML literal strings cannot contain apostrophes")
    if "\n" in value:
        return "'''" + value + "'''"
    return "'" + value + "'"


def snippet_block(description, command, tags=None):
    """Render one ``[[Snippets]]`` table the way pet itself stores snippets."""
    lines = [
        "[[Snippets]]",
        f"  Description = {toml_literal(description)}",
        "  Output = ''",
    ]
    if tags is not None:
        lines.append("  Tag = [" + ", ".join(toml_literal(t) for t in tags) + "]")
    lines.append(f"  command = {toml_literal(command)}")
    return "\n".join(lines) + "\n"


class PetProject:
    """A disposable pet project (config + snippet store + private PATH)."""

    def __init__(self, root):
        self.root = Path(root)
        self.exe = _program_path()
        self.config_path = self.root / "config.toml"
        self.snippet_path = self.root / "snippet.toml"
        self.bin_dir = self.root / "bin"
        self.tools_dir = self.root / "tools"
        self.home_dir = self.root / "home"
        for directory in (self.bin_dir, self.tools_dir, self.home_dir):
            directory.mkdir()
        self._link_path_tools()
        self._write_helper("selrec", SELECTOR_HELPER)
        self._write_helper("xclip", XCLIP_HELPER)
        (self.bin_dir / "selrec").symlink_to(self.tools_dir / "selrec")
        self.selector_argv_log = self.root / "selector-argv.txt"
        self.selector_stdin_log = self.root / "selector-stdin.txt"
        self.clipboard_log = self.root / "clipboard.txt"
        self.clipboard_argv_log = self.root / "clipboard-argv.txt"

    # -- snippet rendering ------------------------------------------------
    snippet = staticmethod(snippet_block)

    # -- setup helpers ----------------------------------------------------
    def _link_path_tools(self):
        for tool in PATH_TOOLS:
            source = shutil.which(tool)
            if source is None:
                raise RuntimeError(f"required tool not found on PATH: {tool}")
            (self.bin_dir / tool).symlink_to(source)

    def _write_helper(self, name, body):
        target = self.tools_dir / name
        target.write_text(body)
        target.chmod(0o755)

    # -- project content --------------------------------------------------
    def write_config(
        self,
        *,
        selectcmd=DEFAULT_SELECTCMD,
        fmt="",
        color=False,
        cmd=(),
        snippetdirs=(),
        snippetfile=None,
        sortby="",
        editor="true",
    ):
        """Write config.toml; ``snippetfile`` defaults to the main store."""
        self.config_path.write_text(
            CONFIG_TEMPLATE.format(
                cmd=", ".join(toml_basic(part) for part in cmd),
                color="true" if color else "false",
                editor=editor,
                fmt=fmt.replace("\\", "\\\\").replace('"', '\\"'),
                selectcmd=selectcmd.replace("\\", "\\\\").replace('"', '\\"'),
                snippetdirs=", ".join(toml_basic(str(d)) for d in snippetdirs),
                snippetfile=snippetfile or str(self.snippet_path),
                sortby=sortby.replace("\\", "\\\\").replace('"', '\\"'),
            )
        )
        return self.config_path

    def write_snippets(self, *blocks):
        """Write the main snippet store from ``snippet_block`` pieces."""
        self.snippet_path.write_text("\n".join(blocks) + "\n" if blocks else "")
        return self.snippet_path

    def write_raw_snippets(self, text):
        """Write the main snippet store from raw TOML text."""
        self.snippet_path.write_text(text)
        return self.snippet_path

    def make_snippetdir(self, name, files):
        """Create a snippet directory with ``{filename: toml_text}`` files."""
        directory = self.root / name
        directory.mkdir()
        for filename, text in files.items():
            (directory / filename).write_text(text)
        return directory

    # -- execution --------------------------------------------------------
    def base_env(self):
        env = {
            "PATH": str(self.bin_dir),
            "HOME": str(self.home_dir),
            "TERM": "dumb",
            # selector helper knobs (harmless when the helper is not used)
            "SEL_ARGV_OUT": str(self.selector_argv_log),
            "SEL_STDIN_OUT": str(self.selector_stdin_log),
            "SEL_HEAD": "0",
        }
        cover_dir = os.environ.get("GOCOVERDIR")
        if cover_dir:
            env["GOCOVERDIR"] = cover_dir
        return env

    def env_with_selector_head(self, head=True):
        """Child env variant asking the selector helper to keep line 1 only."""
        env = self.base_env()
        env["SEL_HEAD"] = "1" if head else "0"
        return env

    def run(
        self,
        *args,
        stdin=None,
        use_xclip=False,
        extra_env=None,
        use_config=True,
        timeout=30,
        cwd=None,
    ):
        """Run pet with the pinned environment and return the result."""
        env = self.base_env()
        xclip_link = self.bin_dir / "xclip"
        if use_xclip:
            if not xclip_link.is_symlink():
                xclip_link.symlink_to(self.tools_dir / "xclip")
            env["XCLIP_ARGV_OUT"] = str(self.clipboard_argv_log)
            env["XCLIP_STDIN_OUT"] = str(self.clipboard_log)
        elif xclip_link.is_symlink() or xclip_link.exists():
            xclip_link.unlink()
        if extra_env:
            for key, value in extra_env.items():
                if value is None:
                    env.pop(key, None)
                else:
                    env[key] = value
        argv = [self.exe]
        if use_config:
            argv += ["--config", str(self.config_path)]
        argv += list(args)
        return subprocess.run(
            argv,
            input=stdin,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            cwd=str(cwd or self.root),
            timeout=timeout,
        )


@pytest.fixture()
def pet(tmp_path):
    """Fresh pet project: config, snippet store, private PATH, pinned env."""
    return PetProject(tmp_path)
