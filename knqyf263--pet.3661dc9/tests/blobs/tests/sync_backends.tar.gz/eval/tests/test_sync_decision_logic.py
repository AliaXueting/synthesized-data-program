"""The AutoSync decision matrix in sync/sync.go, driven through `pet sync`."""

import json

import pytest

from conftest import (
    LOCAL_SNIPPET,
    OLD_EPOCH,
    REMOTE_EPOCH,
    UPLOADED_SNIPPET,
    gitlab_routes,
)


@pytest.fixture
def gitlab(pet, make_backend):
    """A pet project pointed at a GitLab stub holding one remote snippet."""
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.backend = backend
    return pet


def test_missing_local_file_attempts_a_download(gitlab):
    """A missing main snippet file is treated as 'download' and then fails.

    CATCHES: pet chooses the download branch for a missing file, so it fails
    loading the local snippets and prints the multi-line 'snippet file not
    found' message with the raw configured path.
    """
    res = gitlab.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nsnippet file not found. %s\n"
        "Please run 'pet configure' and provide a correct file path, or remove "
        "this\nif you only want to provide snippetdirs instead\n"
        % (gitlab.backend.url, gitlab.snippet_file)
    )
    assert not gitlab.snippet_file.exists()


def test_zero_length_local_file_is_downloaded(gitlab):
    """A zero-length local file is always downloaded, whatever its mtime.

    CATCHES: the size check runs before the timestamp comparison, so even a
    brand-new empty file is overwritten by the remote content.
    """
    gitlab.write_snippets("", mtime=OLD_EPOCH)
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nDownload success\n" % gitlab.backend.url
    assert gitlab.snippet_text() == UPLOADED_SNIPPET


def test_local_newer_than_remote_uploads(gitlab):
    """A local mtime strictly newer than the remote updated_at uploads.

    CATCHES: pet PUTs the re-encoded local snippets and prints
    'Upload success' while leaving the local file untouched.
    """
    gitlab.write_snippets(LOCAL_SNIPPET)
    before = gitlab.snippet_mtime()
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % gitlab.backend.url
    assert gitlab.snippet_mtime() == before
    assert gitlab.snippet_text() == LOCAL_SNIPPET
    assert gitlab.backend.request("PUT", "/api/v4/snippets/7") is not None


def test_remote_newer_than_local_downloads(gitlab):
    """A remote updated_at strictly newer than the local mtime downloads.

    CATCHES: the local file is replaced by the raw remote bytes and
    'Download success' is printed; no upload request is made.
    """
    gitlab.write_snippets(LOCAL_SNIPPET, mtime=OLD_EPOCH)
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nDownload success\n" % gitlab.backend.url
    assert gitlab.snippet_text() == UPLOADED_SNIPPET
    assert [p for p in gitlab.backend.paths() if p[0] == "PUT"] == []


def test_equal_timestamps_are_silent(gitlab):
    """Identical local mtime and remote updated_at do nothing at all.

    CATCHES: neither upload nor download happens; only the echoed url line is
    printed and the process exits 0 without any HTTP write request.
    """
    gitlab.write_snippets(LOCAL_SNIPPET, mtime=REMOTE_EPOCH)
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\n" % gitlab.backend.url
    assert gitlab.snippet_text() == LOCAL_SNIPPET
    assert [p for p in gitlab.backend.paths() if p[0] in ("PUT", "POST")] == []


def test_equal_timestamps_but_different_content_stays_silent(gitlab):
    """Equal timestamps suppress the sync even when the contents differ.

    CATCHES: the decision only compares timestamps, so a diverging local file
    is not uploaded when its mtime equals the remote updated_at.
    """
    gitlab.write_snippets('[[snippets]]\n  command = "other"\n'
                          '  description = "other"\n', mtime=REMOTE_EPOCH)
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\n" % gitlab.backend.url
    assert "other" in gitlab.snippet_text()
    assert [p for p in gitlab.backend.paths() if p[0] in ("PUT", "POST")] == []


def test_identical_content_reports_already_up_to_date(gitlab):
    """A download whose content matches the local file prints up-to-date.

    CATCHES: pet compares the remote content with the re-encoded local body,
    so matching content prints 'Already up-to-date' and never rewrites the
    file (mtime and mode stay exactly as they were).
    """
    gitlab.write_snippets(LOCAL_SNIPPET, mtime=OLD_EPOCH, mode=0o600)
    before = (gitlab.snippet_mtime(), gitlab.snippet_mode())
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nAlready up-to-date\n" % gitlab.backend.url
    assert (gitlab.snippet_mtime(), gitlab.snippet_mode()) == before
    assert gitlab.snippet_text() == LOCAL_SNIPPET


def test_download_keeps_the_existing_file_mode(gitlab):
    """A download truncates the existing file instead of recreating it.

    CATCHES: the local file keeps its 0600 mode after being overwritten, which
    distinguishes truncate-and-write from remove-and-recreate.
    """
    gitlab.write_snippets(LOCAL_SNIPPET, mtime=OLD_EPOCH, mode=0o600)
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode().endswith("Download success\n")
    assert gitlab.snippet_mode() == 0o600
    assert gitlab.snippet_text() == UPLOADED_SNIPPET


def test_download_writes_the_raw_remote_bytes(gitlab, make_backend):
    """The downloaded file holds the remote bytes verbatim.

    CATCHES: pet writes the snippet content exactly as served (leading blank
    line included) rather than re-encoding it through the TOML encoder.
    """
    raw = '\n[[Snippets]]\n  Description = "from remote"\n  Output = ""\n' \
          '  Tag = []\n  command = "remote cmd"\n'
    backend = make_backend(gitlab_routes(content=raw))
    pet = gitlab
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET, mtime=OLD_EPOCH)
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert pet.snippet_text() == raw


def test_upload_body_is_the_reencoded_snippet_toml(gitlab):
    """The uploaded body is the canonical TOML re-encoding of the snippets.

    CATCHES: the local snippet file is parsed and re-encoded (field order and
    quoting normalised) before it is sent to the backend.
    """
    gitlab.write_snippets(LOCAL_SNIPPET)
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    body = json.loads(gitlab.backend.request("PUT", "/api/v4/snippets/7").body)
    assert body["content"] == UPLOADED_SNIPPET
    assert body["file_name"] == "pet-snippet.toml"
    assert body["title"] == "pet-snippet"
    assert body["description"] == "Snippet file generated by pet"


def test_upload_ignores_snippetdirs(gitlab):
    """Only the main snippet file is uploaded, snippetdirs are skipped.

    CATCHES: a snippet living in a configured snippetdir must not reach the
    backend even though the directory is listed in [General].
    """
    extra = gitlab.root / "extra" / "other.toml"
    extra.parent.mkdir(parents=True)
    extra.write_text('[[snippets]]\n  command = "extra cmd"\n'
                     '  description = "extra desc"\n')
    gitlab.write_config(general={"backend": "gitlab",
                                 "snippetdirs": [str(gitlab.root / "extra")]},
                        gitlab={"access_token": "tok",
                                "url": gitlab.backend.url, "id": "7",
                                "file_name": "pet-snippet.toml"})
    gitlab.write_snippets(LOCAL_SNIPPET)
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    body = json.loads(gitlab.backend.request("PUT", "/api/v4/snippets/7").body)
    assert body["content"] == UPLOADED_SNIPPET
    assert "extra" not in body["content"]


def test_download_ignores_snippetdirs(gitlab):
    """A download rewrites only the main snippet file.

    CATCHES: files inside a configured snippetdir are left byte-identical when
    the main file is replaced by the remote content.
    """
    extra = gitlab.root / "extra" / "other.toml"
    extra.parent.mkdir(parents=True)
    extra.write_text('[[snippets]]\n  command = "extra cmd"\n'
                     '  description = "extra desc"\n')
    gitlab.write_config(general={"backend": "gitlab",
                                 "snippetdirs": [str(gitlab.root / "extra")]},
                        gitlab={"access_token": "tok",
                                "url": gitlab.backend.url, "id": "7",
                                "file_name": "pet-snippet.toml"})
    gitlab.write_snippets(LOCAL_SNIPPET, mtime=OLD_EPOCH)
    res = gitlab.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode().endswith("Download success\n")
    assert gitlab.snippet_text() == UPLOADED_SNIPPET
    assert extra.read_text() == '[[snippets]]\n  command = "extra cmd"\n' \
                                '  description = "extra desc"\n'


def test_no_remote_id_makes_no_http_request(pet, make_backend):
    """Without a remote id the client returns an empty snippet immediately.

    CATCHES: an empty remote snippet plus an empty local file ends in
    'Already up-to-date' without a single request to the backend.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "file_name": "pet-snippet.toml"})
    pet.write_snippets("")
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "Already up-to-date\n"
    assert backend.requests == []


def test_no_remote_id_and_empty_local_file_is_already_up_to_date(pet):
    """The gist client with no gist_id also reports up-to-date offline.

    CATCHES: the default gist backend with a token but no gist_id never talks
    to the network, so an empty local file prints 'Already up-to-date'.
    """
    pet.write_config(gist={"access_token": "tok"})
    pet.write_snippets("")
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "Already up-to-date\n"
