"""Shared fixtures and helpers for the pet sync module tests (sync/*, cmd/sync.go)."""

import base64
import json
import os
import re
import socket
import ssl
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

# Sentinel used to request deletion of a variable from the child environment.
DELETE = object()

# ---------------------------------------------------------------------------
# Recorded reference behaviour
# ---------------------------------------------------------------------------

# A minimal main snippet file and the exact body `pet sync` uploads for it
# (the snippets are re-encoded through the TOML encoder before uploading).
LOCAL_SNIPPET = '[[snippets]]\n  command = "echo hello"\n  description = "say hello"\n'
UPLOADED_SNIPPET = (
    '\n[[Snippets]]\n  Description = "say hello"\n  Output = ""\n'
    '  Tag = []\n  command = "echo hello"\n'
)

# A second local snippet used to prove the file is rewritten by the editor path.
EDITED_SNIPPET = '[[snippets]]\n  command = "edited"\n  description = "edited"\n'
EDITED_UPLOADED = (
    '\n[[Snippets]]\n  Description = "edited"\n  Output = ""\n'
    '  Tag = []\n  command = "edited"\n'
)

# Remote snippet "updated_at" instant used to decide upload vs. download.
REMOTE_UPDATED_AT = "2020-06-15T12:00:00Z"
REMOTE_EPOCH = 1592222400  # 2020-06-15T12:00:00Z == REMOTE_UPDATED_AT
OLD_EPOCH = 946684800      # 2000-01-01, strictly older than the remote snippet

# Exact multi-line stdout of a failing access-token lookup, per backend.
EMPTY_TOKEN_MESSAGES = {
    "gist": (
        "Failed to initialize API client: Failed to initialize Gist client: "
        "access_token is empty.\n"
        "Go https://github.com/settings/tokens/new and create access_token "
        '(only need "gist" scope).\n'
        "Write access_token in config file (pet configure) or export "
        "$PET_GITHUB_ACCESS_TOKEN.\n\t\t\n"
    ),
    "ghe": (
        "Failed to initialize API client: Failed to initialize GHE client: "
        "access_token is empty.\n"
        "Go https://github.com/settings/tokens/new and create access_token "
        '(only need "gist" scope).\n'
        "Write access_token in config file (pet configure) or export "
        "$PET_GHE_ACCESS_TOKEN.\n\t\t\n"
    ),
    "gitlab": (
        "Failed to initialize API client: Failed to initialize GitLab client: "
        "access_token is empty.\n"
        "Go https://gitlab.com/profile/personal_access_tokens and create "
        "access_token.\n"
        "Write access_token in config file (pet configure) or export "
        "$PET_GITLAB_ACCESS_TOKEN.\n\t\t\n"
    ),
}

# A throwaway self-signed certificate for "localhost" (valid until 2046)
# used to tell the [GitLab] skip_ssl option apart from a verifying TLS
# client.  The certificate and its private-key PEMs are base64-encoded
# here so the exact bytes survive being embedded in this source file.
TLS_PEM_B64 = (
    "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURKVENDQWcyZ0F3SUJBZ0lVRzNNRG"
    "IyY05XM0NWanFpYW0zRU5NRXI4YkFvd0RRWUpLb1pJaHZjTkFRRUwKQlFBd0ZERVNNQkFH"
    "QTFVRUF3d0piRzlqWVd4b2IzTjBNQjRYRFRJMk1UQXhOakF3TXpReU1Gb1hEVFEyTVRBeA"
    "pNVEF3TXpReU1Gb3dGREVTTUJBR0ExVUVBd3dKYkc5allXeG9iM04wTUlJQklqQU5CZ2tx"
    "aGtpRzl3MEJBUUVGCkFBT0NBUThBTUlJQkNnS0NBUUVBbVVlTlk5dUI4bUxhZEI2Q1pMZH"
    "Z4TFNGaU1LZkdhRlV5MTJCbk5XUWVSQm4Kc1pwYkcxU2wvV2pHM1MrQnltRmVDaTF1N3No"
    "djhaQllGbHhNa1lLNnZxckl1Smthcnd6VkZqTU8yaGZROFVoOQpTaGdTNEkyb1pnZUJHUU"
    "RkRnM3Q0p1MzZpLzE5dWlIOCtQK215dkR2OGpCM2phc0FHc01qTHV6bEJNSzNoeGN2CllH"
    "VFB1NytIcENqTHFVL2Q5TTZQcGIvL2pkNSs0ZVJYZmxNS3RWaEt0ZS9vcnJPbTZpS0lJSW"
    "oxYzBEdkRaSW4KN2JNQzF0Yy9ib1hBbVpLRkQ5Z2p3YUZFSU85cHNMb3NGeVpjTGlXa0t5"
    "empNNHBpWVZ3RWNyZ1RlRzd6YWo2ZApPcVpZWUpxSmduRFl3SFVPYm9jRW9LYUlLZ1hsL2"
    "p4UUgrZmJPdEVLSHdJREFRQUJvMjh3YlRBZEJnTlZIUTRFCkZnUVVHbS9mcHpydzZpU2w3"
    "UGo2Z2J6RWFoalM0WGd3SHdZRFZSMGpCQmd3Rm9BVUdtL2ZwenJ3NmlTbDdQajYKZ2J6RW"
    "FoalM0WGd3RHdZRFZSMFRBUUgvQkFVd0F3RUIvekFhQmdOVkhSRUVFekFSaHdSL0FBQUJn"
    "Z2xzYjJOaApiR2h2YzNRd0RRWUpLb1pJaHZjTkFRRUxCUUFEZ2dFQkFGSGdRVGxXRlRnOX"
    "cwV0pTY25xSG05NS8rMDFSUTdUCndta0tXeitGN3U1Rm55ZVRtTkNUcDE4ejNzYlNyaVlo"
    "bHJuT2ttWFgxSmRQdGQrWDFINzhVa3hZTzQ4TjcxZFUKLzVmS25DNmpmUm9zLytkQzRVVD"
    "daUWpiT3lWTVZneXRRQlhJbDBNZWkzSnYzOXlRTFhMNVVMdlJvZk91SGJEOQp2bVo4Z2I5"
    "N2NQenJqUzJPUWI0aFNBc3FteXptcGF0bXdGSmJneUtaeTZySS9JRFYxUkY4YkhxOWFKYW"
    "Y2MmgzCnV4T09Hd1JuM29pQzdrUUhRM3hzSzRNemt4NGhJZjZ5S3d3YzZRVjEwbHZ6TEZr"
    "Z1hwenZtSGlpL1ZBbGxOVG8KQTB5ank0a1RPRE16T0FNRjBtUTdRUkpJV25CMDJseHhRd0"
    "MwQzJ5NnhxbTlqL3JYWlZtV2g1Zz0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQotLS0t"
    "LUJFR0lOIFBSSVZBVEUgS0VZLS0tLS0KTUlJRXZnSUJBREFOQmdrcWhraUc5dzBCQVFFRk"
    "FBU0NCS2d3Z2dTa0FnRUFBb0lCQVFDWlI0MWoyNEh5WXRwMApIb0prdDIvRXRJV0l3cDha"
    "b1ZUTFhZR2MxWkI1RUdleG1sc2JWS1g5YU1iZEw0SEtZVjRLTFc3dXlHL3hrRmdXClhFeV"
    "JncnErcXNpNG1ScXZETlVXTXc3YUY5RHhTSDFLR0JMZ2phaG1CNEVaQU4wV3pzSW03ZnFM"
    "L1gyNklmejQKLzZiSzhPL3lNSGVOcXdBYXd5TXU3T1VFd3JlSEZ5OWdaTSs3djRla0tNdX"
    "BUOTMwem8rbHYvK04zbjdoNUZkKwpVd3ExV0VxMTcraXVzNmJxSW9nZ2lQVnpRTzhOa2lm"
    "dHN3TFcxejl1aGNDWmtvVVAyQ1BCb1VRZzcybXd1aXdYCkpsd3VKYVFyTE9NemltSmhYQV"
    "J5dUJONGJ2TnFQcDA2cGxoZ21vbUNjTmpBZFE1dWh3U2dwb2dxQmVYK1BGQWYKNTlzNjBR"
    "b2ZBZ01CQUFFQ2dnRUFBc1FieW1yYy9zd2NqUms2ZzlRYm5EMGdabkM4cTVzUnRmOGdwbE"
    "tPOTRyOQpsQTJUdEthT2FFaEtibXRtWXQ4OFJ6Vm9CR25HNWd1K0lJa3NpSTVjdUZ3ZlN5"
    "cllKRzNpMm9lMEE1T0h5R2c2CmVwVW5UTGpCdFRXbGRXeTM1Z0FpZzNsVlJYbDBSTFpLK1"
    "E0RUFJZzE0WittU0ttR3FFcFAzdVRxTFJwN3lBcnkKa2JtRlU5NUtmOWdZNitjNVNLZ2ZH"
    "bzFJcW54SWpqU1l5TWtIcGlnd3p1SlZsRHhXYUd5Ykk0RmpoZmVaa2dMcwpZdjR0TWowal"
    "BrNGFTNnkxQ1g3ckYyV25RTktuVmxaaHp2NU9FNFdLZFlOa0NIeDczMDNoWlVLeFJNSkVL"
    "ejZhCkF0c2NrQ01pZmlNQlFmbGZkMjVjSE0zZnN2VUZrdCtPdjNJUXRJU2RRUUtCZ1FEVG"
    "dTZGZTTTNyQWwzUi9GUkYKY2JUNUdCREpld1ByTDJXQ2xiL1BQSjNnVDJZQzlGTWNQbGR1"
    "WXQ2MnFkU2NNb0tPYXFlbEZ1Vkp5MGNubG1SVgpBZC9zMGpsN3JaNWV4Ynp4S0NETFY1a3"
    "FkMU5pbXEwN0hMZHNqWmFZMS9nVUI2SnQxdWpNTkQ0OXVBVW5mREl5ClNBRTRzbTdyTTk3"
    "ZHVqWjJQMnQ5bmp3bTJRS0JnUUM1aHAzQXErSVhhRis3Nlk5bHZmWWorUGIwNVovb1RLZD"
    "AKeWlxcENEUWxWV2hSWnRkMGtsSDZRZ1k4Q2tNbTdTTCtzR0VMSGRFR2YzUW1WanB4cTQv"
    "bDZTN3VBdXYrU3dPTQpVRUtGTDlBb3pwUXdZNldwZW9YWlRyNkRzVTM2TUJTTnZVR1IwYz"
    "BtM0pGWDM0cjlkS0ZRUytBTjZ3ZDFZbDc0ClphWXVsZkpOdHdLQmdRRERIM3JnUi8xWTJ5"
    "VU03WG9kV3VwM2g0RXRMNlVNMnZ3T1BmTG4wR2RpSWozZGFlUW0Kd1VqTjJMN1l5OU1PaX"
    "ZheFJxb0UveHRuT2ZjYUNYL2tnTWRCNXl3SzhzQ1JkR0Y4SmVZalVseEd0akVpWGNxRgpK"
    "MWY4K0o2L3dUYm4yNmM1S0RRNjk5T1lBdVlXYUZpeTFJVHo5b0duMFlIQkV1TGRzbUtMVU"
    "dqeitRS0JnUUNVCkRRd1l0RkhSa2paTGsrQWVOaENWdGxrRko3V0xRSmlsaDZ1eGhsMXVx"
    "WkI4M1UvMHM4dDlwWENxT3hwSmx4WEYKSDJYaDVDSnBTQTZkaFZSUVg3T09xcDRMekFNZH"
    "hDa0pzUWJVbUVwS05raGxzUytEWnNZbm0wSkhmNWVWbndiWAo4WDdBNmljSDZ4NkZmRnZE"
    "Vlc1aDBKcjFJR2lzVVJzdXFKZU1ONWJNVXdLQmdIZGFoZTBLUkxZUXhyRXkreWdXCnJ2dH"
    "FoY3hpN3M0NUJXekZGYm50cXZZZS9wUGxIMDhGanh5QnRzWHI2N2tzMWJwT1dETVVNaHdv"
    "QWFWZGNhWDcKZUhRYXN1VzlNWHFIWHJJem1tZlNieFlDYlgreGthanNsVHNUTkNQV2VOOH"
    "FTR0dKNDBNRnNJOFhZV1Nha2VmOAo5TzVGaXZUV1plSWNPS1hYa1hVY1ZHWGwKLS0tLS1F"
    "TkQgUFJJVkFURSBLRVktLS0tLQo="
)


# ---------------------------------------------------------------------------
# Executable resolution and process running
# ---------------------------------------------------------------------------


def _resolve_executable():
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if exe and os.path.exists(exe):
        return exe
    raise RuntimeError(
        "PROGRAMGYM_EXECUTABLE is not set or does not exist; "
        "the ProgramGym runner must export it."
    )


@pytest.fixture(scope="session")
def pet_exe():
    """Return the absolute path of the pet binary under test."""
    return _resolve_executable()


def coverage_env():
    """Pass the Go coverage output directory through to the child process."""
    cov_env = {key: value
               for key, value in [("GOCOVERDIR", os.environ.get("GOCOVERDIR"))]
               if value}
    return cov_env


def child_env(home, env=None):
    """Build a fully pinned environment for the pet child process."""
    base = {
        "HOME": str(home),
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C",
        "LC_ALL": "C",
        "TERM": "dumb",
        "TZ": "UTC",
    }
    for key, value in (env or {}).items():
        if value is DELETE:
            base.pop(key, None)
        else:
            base[key] = value
    base.update(coverage_env())
    return base


def run_pet(exe, args=(), home=None, env=None, stdin=b"", cwd=None, timeout=30):
    """Invoke the pet binary and return the completed subprocess."""
    if isinstance(stdin, str):
        stdin = stdin.encode("utf-8")
    return subprocess.run(
        [exe, *args],
        input=stdin,
        env=child_env(home, env),
        cwd=str(cwd) if cwd is not None else (str(home) if home else None),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )


# ---------------------------------------------------------------------------
# Config / snippet file scaffolding
# ---------------------------------------------------------------------------


def toml_value(value):
    """Render a Python value as a TOML right-hand side."""
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return '"%s"' % value.replace("\\", "\\\\").replace('"', '\\"')
    if isinstance(value, (list, tuple)):
        return "[%s]" % ", ".join(toml_value(item) for item in value)
    raise TypeError("unsupported TOML value: %r" % (value,))


class PetProject(object):
    """A disposable pet home directory, config file and main snippet file."""

    def __init__(self, exe, root):
        self.exe = exe
        self.root = Path(root)
        self.home = self.root / "home"
        self.home.mkdir(parents=True, exist_ok=True)
        self.snippet_file = self.root / "snippet.toml"
        self.config_file = self.root / "config.toml"

    def write_snippets(self, content, mtime=None, mode=None):
        """Create the main snippet file, optionally pinning mtime and mode."""
        self.snippet_file.write_text(content)
        if mode is not None:
            os.chmod(self.snippet_file, mode)
        if mtime is not None:
            os.utime(self.snippet_file, (mtime, mtime))
        return self.snippet_file

    def write_config(self, general=None, gist=None, gitlab=None, ghe=None,
                     with_snippetfile=True):
        """Write config.toml from per-section dictionaries."""
        head = dict(general or {})
        if with_snippetfile:
            head.setdefault("snippetfile", str(self.snippet_file))
        blocks = [("General", head)]
        for name, body in (("Gist", gist), ("GitLab", gitlab), ("GHEGist", ghe)):
            if body is not None:
                blocks.append((name, body))
        lines = []
        for name, body in blocks:
            lines.append("[%s]" % name)
            for key, value in body.items():
                lines.append("  %s = %s" % (key, toml_value(value)))
            lines.append("")
        self.config_file.write_text("\n".join(lines) + "\n")
        return self.config_file

    def run(self, args=(), env=None, stdin=b"", timeout=30, with_config=True):
        """Run pet with this project's config, home and working directory."""
        argv = []
        if with_config:
            argv += ["--config", str(self.config_file)]
        argv += list(args)
        return run_pet(self.exe, argv, home=self.home, env=env, stdin=stdin,
                       cwd=self.root, timeout=timeout)

    def snippet_text(self):
        return self.snippet_file.read_text()

    def snippet_mode(self):
        return os.stat(self.snippet_file).st_mode & 0o777

    def snippet_mtime(self):
        return os.stat(self.snippet_file).st_mtime_ns

    def write_editor(self, content):
        """Install an "editor" that overwrites the main snippet file.

        pet runs ``<editor> +<line> <file>`` through ``sh -c``, so the file
        path arrives as ``$2``.
        """
        if "'" in content:
            raise ValueError("editor helper cannot quote %r" % content)
        script = self.root / "editor.sh"
        script.write_text("#!/bin/sh\nprintf '%%s' '%s' > \"$2\"\n" % content)
        os.chmod(str(script), 0o755)
        return str(script)


@pytest.fixture
def pet(tmp_path, pet_exe):
    """A fresh pet project rooted in the test's tmp_path."""
    return PetProject(pet_exe, tmp_path)


# ---------------------------------------------------------------------------
# Local stub backend
# ---------------------------------------------------------------------------


class Request(object):
    """One recorded HTTP request made by the pet binary."""

    __slots__ = ("method", "path", "headers", "body")

    def __init__(self, method, path, headers, body):
        self.method = method
        self.path = path
        self.headers = headers
        self.body = body

    def header(self, name):
        for key, value in self.headers.items():
            if key.lower() == name.lower():
                return value
        return None

    def json(self):
        return json.loads(self.body.decode("utf-8"))

    def __repr__(self):
        return "Request(%s %s, body=%r)" % (self.method, self.path, self.body)


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def _dispatch(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""
        backend = self.server.backend
        backend.requests.append(
            Request(self.command, self.path, dict(self.headers), body))
        rule = backend.match(self.command, self.path)
        if rule is None:
            status, ctype, payload = 404, "text/plain", "unmatched stub route"
        else:
            status, ctype, payload = rule
        if isinstance(payload, str):
            payload = payload.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = do_HEAD = _dispatch


class StubBackend(object):
    """A rule-driven HTTP server impersonating a gist / GitLab backend."""

    def __init__(self, rules, tls=False, cert_dir=None):
        self.rules = rules
        self.requests = []
        self._httpd = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self._httpd.backend = self
        if tls:
            pem = Path(cert_dir) / "stub.pem"
            pem.write_bytes(base64.b64decode(TLS_PEM_B64))
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.load_cert_chain(str(pem))
            self._httpd.socket = context.wrap_socket(self._httpd.socket,
                                                     server_side=True)
        self._thread = threading.Thread(target=self._httpd.serve_forever,
                                        daemon=True)
        self._thread.start()

    @property
    def port(self):
        return self._httpd.server_address[1]

    @property
    def url(self):
        return "http://127.0.0.1:%d" % self.port

    @property
    def tls_url(self):
        return "https://127.0.0.1:%d" % self.port

    def match(self, method, path):
        for rule_method, pattern, status, ctype, payload in self.rules:
            if rule_method != method and rule_method != "*":
                continue
            if pattern is None or re.fullmatch(pattern, path):
                return (status, ctype, payload)
        return None

    def paths(self):
        return [(request.method, request.path) for request in self.requests]

    def request(self, method, path):
        for request in self.requests:
            if request.method == method and request.path == path:
                return request
        return None

    def close(self):
        self._httpd.shutdown()
        self._httpd.server_close()


def route(method, path, status=200, json_body=None, text=None,
          content_type=None):
    """Build one stub rule: (method, path-regex, status, type, payload)."""
    if json_body is not None:
        payload = json.dumps(json_body)
        ctype = content_type or "application/json"
    else:
        payload = text if text is not None else ""
        ctype = content_type or "text/plain"
    return (method, path, status, ctype, payload)


def gist_routes(gist_id="abc123", content=UPLOADED_SNIPPET,
                updated=REMOTE_UPDATED_AT, file_name="pet-snippet.toml"):
    """Route table for a GitHub(ghe) gist backend holding one snippet file."""
    body = {
        "id": gist_id,
        "updated_at": updated,
        "files": {file_name: {"filename": file_name, "content": content}},
    }
    return [
        route("GET", "/gists/%s" % gist_id, json_body=body),
        route("PATCH", "/gists/%s" % gist_id, json_body={}),
        route("POST", "/gists", status=201,
              json_body={"id": "brandnewid", "updated_at": updated}),
    ]


def gitlab_routes(snippet_id=7, content=UPLOADED_SNIPPET,
                  updated=REMOTE_UPDATED_AT, file_name="pet-snippet.toml"):
    """Route table for a GitLab backend holding one snippet."""
    body = {
        "id": snippet_id,
        "file_name": file_name,
        "updated_at": updated,
        "title": "pet-snippet",
    }
    return [
        route("GET", "/api/v4/snippets/%d" % snippet_id, json_body=body),
        route("GET", "/api/v4/snippets/%d/raw" % snippet_id, text=content),
        route("PUT", "/api/v4/snippets/%d" % snippet_id, json_body={}),
        route("POST", "/api/v4/snippets", status=201,
              json_body={"id": 99, "file_name": file_name}),
    ]


@pytest.fixture
def make_backend(tmp_path):
    """Start rule-driven stub backends; every server is closed on teardown."""
    started = []

    def factory(rules, tls=False):
        server = StubBackend(rules, tls=tls, cert_dir=tmp_path)
        started.append(server)
        return server

    yield factory
    for server in started:
        server.close()


def dead_port():
    """Reserve and release a localhost TCP port so connects are refused."""
    for _ in range(20):
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()
        probe = socket.socket()
        try:
            probe.connect(("127.0.0.1", port))
        except OSError:
            probe.close()
            return port
        probe.close()
    raise RuntimeError("could not reserve a closed localhost port")
