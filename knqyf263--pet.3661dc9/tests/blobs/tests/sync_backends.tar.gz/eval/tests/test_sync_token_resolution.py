"""Access-token resolution for pet sync: config value, env var, or nothing."""

import json

import pytest

from conftest import (
    EMPTY_TOKEN_MESSAGES,
    LOCAL_SNIPPET,
    UPLOADED_SNIPPET,
    dead_port,
    gist_routes,
    gitlab_routes,
)

GIST_ENV = "PET_GITHUB_ACCESS_TOKEN"
GHE_ENV = "PET_GHE_ACCESS_TOKEN"
GITLAB_ENV = "PET_GITLAB_ACCESS_TOKEN"


def test_no_token_at_all_prints_gist_help_text(pet):
    """pet sync with neither config token nor env var fails on stdout.

    CATCHES: the whole three-line access_token help text (token URL, env var
    name and a trailing tab-tab line) is printed on stdout, not stderr.
    """
    pet.write_config(gist={"file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES["gist"]
    assert res.stderr == b""


def test_ghe_backend_without_token_prints_ghe_help_text(pet):
    """The ghe backend names $PET_GHE_ACCESS_TOKEN in its empty-token message.

    CATCHES: each backend has its own env-var name in the help text, so a
    re-implementation must print $PET_GHE_ACCESS_TOKEN for backend=ghe.
    """
    pet.write_config(general={"backend": "ghe"},
                     ghe={"file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES["ghe"]


def test_gitlab_backend_without_token_prints_gitlab_help_text(pet):
    """The gitlab backend points at the GitLab token URL and env var.

    CATCHES: the GitLab message differs from the gist one in both the URL
    (gitlab.com/profile/personal_access_tokens) and the env-var name.
    """
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES["gitlab"]


def test_empty_string_config_token_still_counts_as_empty(pet):
    """An explicitly empty access_token in the config is treated as unset.

    CATCHES: `access_token = ""` must not satisfy the token lookup, so the
    command still fails with the multi-line help text and exit code 255.
    """
    pet.write_config(gist={"access_token": "", "gist_id": "abc123"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES["gist"]


def test_gist_env_var_initializes_the_client(pet):
    """$PET_GITHUB_ACCESS_TOKEN alone is enough to build the gist client.

    CATCHES: with the env var set the client is created and pet talks to
    https://api.github.com/gists/<id>; the run fails on the (dead) proxy
    instead of on the empty-token message.
    """
    pet.write_config(gist={"gist_id": "zzz"})
    pet.write_snippets(LOCAL_SNIPPET)
    port = dead_port()
    res = pet.run(["sync"], env={GIST_ENV: "envtoken",
                                 "HTTPS_PROXY": "http://127.0.0.1:%d" % port})
    assert res.returncode == 255
    assert res.stdout.decode() == (
        'Failed to get gist: Get "https://api.github.com/gists/zzz": '
        "proxyconnect tcp: dial tcp 127.0.0.1:%d: connect: connection "
        "refused\n" % port
    )


def test_whitespace_token_is_not_empty(pet):
    """A whitespace-only access_token still counts as configured.

    CATCHES: the empty-token check is an exact string comparison, so a single
    space is accepted and the run proceeds to the network call.
    """
    pet.write_config(gist={"access_token": " ", "gist_id": "zzz"})
    pet.write_snippets(LOCAL_SNIPPET)
    port = dead_port()
    res = pet.run(["sync"], env={"HTTPS_PROXY": "http://127.0.0.1:%d" % port})
    assert res.returncode == 255
    assert "access_token is empty" not in res.stdout.decode()
    assert res.stdout.decode().startswith('Failed to get gist: Get ')


def test_ghe_config_token_wins_over_env_var(pet, make_backend):
    """A config access_token is preferred over the GHE env variable.

    CATCHES: the Authorization header actually sent carries the config value,
    so config beats $PET_GHE_ACCESS_TOKEN in the resolution order.
    """
    backend = make_backend(gist_routes())
    pet.write_config(general={"backend": "ghe"},
                     ghe={"access_token": "cfgtoken",
                          "base_url": backend.url,
                          "gist_id": "abc123",
                          "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"], env={GHE_ENV: "envtoken"})
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url
    assert backend.request("GET", "/gists/abc123").header("Authorization") == \
        "Bearer cfgtoken"


def test_ghe_env_token_used_when_config_is_empty(pet, make_backend):
    """$PET_GHE_ACCESS_TOKEN is used when the config token is unset.

    CATCHES: the fallback to the environment variable must produce a Bearer
    header with the env value for the ghe backend.
    """
    backend = make_backend(gist_routes())
    pet.write_config(general={"backend": "ghe"},
                     ghe={"base_url": backend.url, "gist_id": "abc123",
                          "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"], env={GHE_ENV: "envtoken"})
    assert res.returncode == 0
    assert backend.request("PATCH", "/gists/abc123").header("Authorization") \
        == "Bearer envtoken"


def test_gitlab_config_token_wins_over_env_var(pet, make_backend):
    """The config access_token is preferred over $PET_GITLAB_ACCESS_TOKEN.

    CATCHES: GitLab auth travels in a PRIVATE-TOKEN header; it must carry the
    config value when both sources are populated.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "cfgtoken", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"], env={GITLAB_ENV: "envtoken"})
    assert res.returncode == 0
    assert backend.request("GET", "/api/v4/snippets/7").header("Private-Token") \
        == "cfgtoken"


def test_gitlab_env_token_used_when_config_is_empty(pet, make_backend):
    """$PET_GITLAB_ACCESS_TOKEN is sent as the PRIVATE-TOKEN header value.

    CATCHES: the env-var fallback for the gitlab backend is observable in the
    header pet sends to the GitLab API.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"url": backend.url, "id": "7",
                             "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"], env={GITLAB_ENV: "envtoken"})
    assert res.returncode == 0
    assert backend.request("GET", "/api/v4/snippets/7").header("Private-Token") \
        == "envtoken"


@pytest.mark.parametrize("backend,env_name", [
    ("gitlab", GIST_ENV),
    ("gitlab", GHE_ENV),
    ("ghe", GITLAB_ENV),
    ("ghe", GIST_ENV),
])
def test_foreign_env_var_does_not_unlock_the_client(pet, backend, env_name):
    """Only the env var matching the selected backend is honoured.

    CATCHES: exporting $PET_GITHUB_ACCESS_TOKEN must not satisfy the gitlab or
    ghe client, which still fails with its own empty-token message.
    """
    pet.write_config(general={"backend": backend})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"], env={env_name: "some-token"})
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES[backend]


def test_ghe_ignores_gitlab_section_token(pet):
    """A [GitLab] token does not satisfy the ghe client.

    CATCHES: token sections are per backend, so configuring only
    [GitLab].access_token with backend=ghe still fails with the GHE message.
    """
    pet.write_config(general={"backend": "ghe"},
                     gitlab={"access_token": "gitlab-token"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES["ghe"]


def test_gitlab_ignores_gist_section_token(pet):
    """A [Gist] token does not satisfy the gitlab client.

    CATCHES: the gitlab client only reads [GitLab].access_token and
    $PET_GITLAB_ACCESS_TOKEN, never the gist settings.
    """
    pet.write_config(general={"backend": "gitlab"},
                     gist={"access_token": "gist-token"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES["gitlab"]


def test_ghe_upload_body_carries_the_snippet_file(pet, make_backend):
    """The ghe upload posts the re-encoded snippet TOML as the file content.

    CATCHES: the gist file map is keyed by [GHEGist].file_name and its content
    is the canonical TOML re-encoding of the local snippet file.
    """
    backend = make_backend(gist_routes())
    pet.write_config(general={"backend": "ghe"},
                     ghe={"access_token": "tok", "base_url": backend.url,
                          "gist_id": "abc123", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 0
    request = backend.request("PATCH", "/gists/abc123")
    assert json.loads(request.body) == {
        "description": "description",
        "public": False,
        "files": {"pet-snippet.toml": {"content": UPLOADED_SNIPPET}},
    }
