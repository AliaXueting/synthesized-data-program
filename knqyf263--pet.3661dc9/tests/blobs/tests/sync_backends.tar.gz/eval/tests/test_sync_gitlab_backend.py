"""GitLab Snippets backend specifics (sync/gitlab.go)."""

import json

import pytest

from conftest import (
    LOCAL_SNIPPET,
    OLD_EPOCH,
    UPLOADED_SNIPPET,
    dead_port,
    gitlab_routes,
)

PANIC_FIRST_LINE = (
    "panic: runtime error: invalid memory address or nil pointer dereference"
)


def gitlab_project(pet, backend, **gitlab_cfg):
    """Write a gitlab config pointing at the given stub backend."""
    body = {"access_token": "tok", "url": backend.url,
            "file_name": "pet-snippet.toml"}
    body.update(gitlab_cfg)
    pet.write_config(general={"backend": "gitlab"}, gitlab=body)
    pet.write_snippets(LOCAL_SNIPPET)
    return pet


@pytest.mark.parametrize("bad_id", ["abc", "7.5", " 7", "1e3", "7x", "0x7"])
def test_non_numeric_id_is_rejected_at_client_init(pet, make_backend, bad_id):
    """A non-numeric [GitLab].id fails before any request is made.

    CATCHES: the id is parsed with strconv.Atoi and the error is wrapped as
    'Invalid GitLab Snippet ID: 0' plus the raw strconv message.
    """
    backend = make_backend(gitlab_routes())
    gitlab_project(pet, backend, id=bad_id)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nFailed to initialize API client: Failed to initialize GitLab "
        'client: Invalid GitLab Snippet ID: 0: strconv.Atoi: parsing "%s": '
        "invalid syntax\n" % (backend.url, bad_id)
    )
    assert backend.requests == []


def test_id_zero_behaves_like_no_id(pet, make_backend):
    """[GitLab].id = "0" is indistinguishable from an unset id.

    CATCHES: a zero id makes the client skip the lookup entirely and create a
    new remote snippet, printing 'GitLab Snippet ID: <id>'.
    """
    backend = make_backend(gitlab_routes())
    gitlab_project(pet, backend, id="0")
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "%s\nGitLab Snippet ID: 99\nUpload success\n" % backend.url
    )
    assert [p for p in backend.paths() if p[0] == "GET"] == []


def test_negative_id_is_requestable(pet, make_backend):
    """A negative numeric id is accepted and used verbatim in the path.

    CATCHES: only the numeric parse matters, so /api/v4/snippets/-5 is
    requested and the file_name check then applies to the answer.
    """
    backend = make_backend([
        ("GET", "/api/v4/snippets/-5", 200, "application/json",
         json.dumps({"id": -5, "file_name": "pet-snippet.toml",
                     "updated_at": "2020-06-15T12:00:00Z"})),
        ("GET", "/api/v4/snippets/-5/raw", 200, "text/plain",
         UPLOADED_SNIPPET),
        ("PUT", "/api/v4/snippets/-5", 200, "application/json", "{}"),
    ])
    gitlab_project(pet, backend, id="-5")
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url
    assert ("GET", "/api/v4/snippets/-5") in backend.paths()


def test_404_reports_no_gitlab_snippet_id(pet, make_backend):
    """A 404 from GitLab is reported with the constant '404 Not Found' text.

    CATCHES: pet wraps a 404 as 'No GitLab Snippet ID (<id>)' followed by the
    client's fixed not-found error, ignoring the response body.
    """
    backend = make_backend([("GET", "/api/v4/snippets/9", 404,
                             "application/json",
                             json.dumps({"message": "no such snippet"}))])
    gitlab_project(pet, backend, id="9")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nNo GitLab Snippet ID (9): 404 Not Found\n" % backend.url
    )


def test_other_http_error_reports_failed_to_get_gitlab_snippet(pet,
                                                               make_backend):
    """A non-404 HTTP error keeps the request details in the message.

    CATCHES: the message contains the method, the full url, the status code
    and the parsed response body of the failing request.
    """
    backend = make_backend([("GET", "/api/v4/snippets/10", 403,
                             "application/json",
                             json.dumps({"message": "403 Forbidden"}))])
    gitlab_project(pet, backend, id="10")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nFailed to get GitLab Snippet (ID: 10): GET "
        "%s/api/v4/snippets/10: 403 {message: 403 Forbidden}\n"
        % (backend.url, backend.url)
    )


def test_remote_file_name_mismatch_is_reported(pet, make_backend):
    """A snippet whose file_name differs from the config is rejected.

    CATCHES: the file name comparison happens before the content fetch, so the
    message is 'No snippet file in GitLab Snippet (ID: <id>)'.
    """
    backend = make_backend(gitlab_routes(file_name="something-else.toml"))
    gitlab_project(pet, backend, id="7")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nNo snippet file in GitLab Snippet (ID: 7)\n" % backend.url
    )
    assert [p for p in backend.paths() if p[1].endswith("/raw")] == []


def test_empty_raw_content_is_reported_as_empty(pet, make_backend):
    """An empty raw snippet body fails with '<file_name> is empty'.

    CATCHES: the content is fetched and then checked, so an empty body is an
    error rather than an empty download.
    """
    backend = make_backend(gitlab_routes(content=""))
    gitlab_project(pet, backend, id="7")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == "%s\npet-snippet.toml is empty\n" % backend.url


def test_visibility_is_sent_in_the_upload_body(pet, make_backend):
    """[GitLab].visibility is forwarded on create and update.

    CATCHES: the visibility value travels in the JSON body of the snippet
    request; an unset value is sent as an empty string.
    """
    backend = make_backend(gitlab_routes())
    gitlab_project(pet, backend, id="7", visibility="private")
    res = pet.run(["sync"])
    assert res.returncode == 0
    body = json.loads(backend.request("PUT", "/api/v4/snippets/7").body)
    assert body["visibility"] == "private"
    assert body["content"] == UPLOADED_SNIPPET


def test_unset_visibility_is_sent_as_an_empty_string(pet, make_backend):
    """With no visibility configured the body carries an empty string.

    CATCHES: pet does not default visibility, it just forwards whatever the
    config holds (here: nothing).
    """
    backend = make_backend(gitlab_routes())
    gitlab_project(pet, backend, id="7")
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert json.loads(
        backend.request("PUT", "/api/v4/snippets/7").body)["visibility"] == ""


def test_failed_update_is_wrapped_twice(pet, make_backend):
    """A failing snippet update reports both wrapper messages.

    CATCHES: the client and AutoSync both wrap the error, so the text repeats
    'Failed to update GitLab Snippet' before the request details.
    """
    backend = make_backend([
        ("GET", "/api/v4/snippets/7", 200, "application/json",
         json.dumps({"id": 7, "file_name": "pet-snippet.toml",
                     "updated_at": "2020-06-15T12:00:00Z"})),
        ("GET", "/api/v4/snippets/7/raw", 200, "text/plain", UPLOADED_SNIPPET),
        ("PUT", "/api/v4/snippets/7", 400, "application/json",
         json.dumps({"message": "update rejected"})),
    ])
    gitlab_project(pet, backend, id="7")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nFailed to upload snippet: Failed to update GitLab Snippet: "
        "Failed to update GitLab Snippet: PUT %s/api/v4/snippets/7: 400 "
        "{message: update rejected}\n" % (backend.url, backend.url)
    )


def test_connection_failure_crashes_the_process(pet):
    """A refused connection to the GitLab url makes pet crash, not error.

    CATCHES: the GitLab client dereferences the nil response, so a transport
    failure ends in a Go panic (exit code 2) with the url still echoed.
    """
    port = dead_port()
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok",
                             "url": "http://127.0.0.1:%d" % port, "id": "7",
                             "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 2
    assert res.stdout.decode() == "http://127.0.0.1:%d\n" % port
    assert res.stderr.decode().startswith(PANIC_FIRST_LINE)
    assert pet.snippet_text() == LOCAL_SNIPPET


def test_skip_ssl_true_accepts_a_self_signed_certificate(pet, make_backend):
    """skip_ssl = true builds a client that does not verify the certificate.

    CATCHES: with skip_ssl the TLS handshake against a self-signed local
    certificate succeeds and the sync completes normally.
    """
    backend = make_backend(gitlab_routes(), tls=True)
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.tls_url,
                             "id": "7", "file_name": "pet-snippet.toml",
                             "skip_ssl": True})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.tls_url


def test_skip_ssl_false_rejects_a_self_signed_certificate(pet, make_backend):
    """Without skip_ssl the same self-signed certificate is rejected.

    CATCHES: the verification failure is a transport error for the GitLab
    client, so the command crashes with a nil-pointer panic and exit code 2.
    """
    backend = make_backend(gitlab_routes(), tls=True)
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.tls_url,
                             "id": "7", "file_name": "pet-snippet.toml",
                             "skip_ssl": False})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 2
    assert res.stdout.decode() == "%s\n" % backend.tls_url
    assert res.stderr.decode().startswith(PANIC_FIRST_LINE)
