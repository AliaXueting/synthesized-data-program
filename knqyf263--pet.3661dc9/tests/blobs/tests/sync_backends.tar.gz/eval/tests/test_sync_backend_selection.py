"""Backend selection for pet sync driven by the [General] backend value."""

import pytest

from conftest import (
    EMPTY_TOKEN_MESSAGES,
    LOCAL_SNIPPET,
    gist_routes,
    gitlab_routes,
)


@pytest.mark.parametrize("backend,client", [
    ("", "gist"),
    ("gist", "gist"),
    ("ghe", "ghe"),
    ("gitlab", "gitlab"),
    ("bogus", "gist"),
    ("Gist", "gist"),
    ("GITLAB", "gist"),
    ("GHE", "gist"),
    ("github", "gist"),
])
def test_backend_value_selects_the_client(pet, backend, client):
    """General.backend picks the client; anything unexpected falls back to gist.

    CATCHES: only the exact lowercase strings ghe/gitlab select those backends;
    an unset value, a typo or different casing silently uses GitHub gist.
    """
    pet.write_config(general={"backend": backend} if backend else None)
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES[client]


def test_unset_backend_defaults_to_gist(pet):
    """Omitting [General].backend entirely uses the GitHub gist client.

    CATCHES: a config without a backend key must behave exactly like
    backend="gist" and never error out about the missing key.
    """
    pet.write_config(gist={"file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES["gist"]


def test_gitlab_backend_hits_gitlab_api_paths(pet, make_backend):
    """backend=gitlab talks to /api/v4/snippets/<id> and its raw endpoint.

    CATCHES: the GitLab client must fetch the snippet metadata, then the raw
    content, in that order, before deciding to upload or download.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url
    assert backend.paths() == [
        ("GET", "/api/v4/snippets/7"),
        ("GET", "/api/v4/snippets/7/raw"),
        ("PUT", "/api/v4/snippets/7"),
    ]


def test_ghe_backend_hits_gist_api_paths(pet, make_backend):
    """backend=ghe talks to /gists/<id> and edits it with PATCH.

    CATCHES: the ghe client is a plain gist client pointed at base_url, so an
    upload is a PATCH to /gists/<gist_id>, not a GitLab API call.
    """
    backend = make_backend(gist_routes())
    pet.write_config(general={"backend": "ghe"},
                     ghe={"access_token": "tok", "base_url": backend.url,
                          "gist_id": "abc123", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url
    assert backend.paths() == [
        ("GET", "/gists/abc123"),
        ("PATCH", "/gists/abc123"),
    ]


def test_gitlab_url_without_scheme_suffix_is_not_duplicated(pet, make_backend):
    """A [GitLab].url already ending in /api/v4 is not doubled up.

    CATCHES: the client appends api/v4 only when missing, so the request path
    stays /api/v4/snippets/7 while the url is echoed verbatim.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok",
                             "url": backend.url + "/api/v4",
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s/api/v4\nUpload success\n" % backend.url
    assert ("GET", "/api/v4/snippets/7") in backend.paths()
