"""GitHub gist and GitHub-Enterprise gist backends (sync/gist.go, sync/ghe.go)."""

import json

import pytest

from conftest import (
    LOCAL_SNIPPET,
    OLD_EPOCH,
    UPLOADED_SNIPPET,
    dead_port,
    gist_routes,
)


def ghe_project(pet, backend, **ghe_cfg):
    """Write a ghe config pointing at the given stub backend."""
    body = {"access_token": "tok", "base_url": backend.url,
            "file_name": "pet-snippet.toml"}
    body.update(ghe_cfg)
    pet.write_config(general={"backend": "ghe"}, ghe=body)
    pet.write_snippets(LOCAL_SNIPPET)
    return pet


def test_base_url_is_echoed_to_stdout(pet, make_backend):
    """[GHEGist].base_url is printed before any sync work happens.

    CATCHES: the url line is echoed verbatim (no trailing slash added) and is
    the first output of the command.
    """
    backend = make_backend(gist_routes())
    ghe_project(pet, backend, gist_id="abc123")
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url


def test_upload_url_is_echoed_after_base_url(pet, make_backend):
    """base_url and upload_url are both echoed, base_url first.

    CATCHES: the two url lines are printed in a fixed order before the sync
    decision, regardless of which one the client actually uses.
    """
    backend = make_backend(gist_routes())
    ghe_project(pet, backend, gist_id="abc123",
                upload_url=backend.url + "/uploads")
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "%s\n%s/uploads\nUpload success\n" % (backend.url, backend.url)
    )


def test_upload_url_alone_is_echoed(pet, make_backend):
    """Only upload_url configured: it is echoed, base_url is not.

    CATCHES: each url key is echoed independently, and an empty base_url makes
    the gist request fail with an unsupported-protocol-scheme error.
    """
    backend = make_backend(gist_routes())
    body = {"access_token": "tok", "base_url": "",
            "upload_url": backend.url + "/uploads",
            "file_name": "pet-snippet.toml", "gist_id": "abc123"}
    pet.write_config(general={"backend": "ghe"}, ghe=body)
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s/uploads\nFailed to get gist: Get \"/gists/abc123\": "
        'unsupported protocol scheme ""\n' % backend.url
    )


def test_first_upload_creates_the_gist_and_prints_its_id(pet, make_backend):
    """Without a gist_id the first upload creates a gist and prints its id.

    CATCHES: pet POSTs to /gists and prints 'Gist ID: <id>' before
    'Upload success'.
    """
    backend = make_backend(gist_routes())
    ghe_project(pet, backend)
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "%s\nGist ID: brandnewid\nUpload success\n" % backend.url
    )
    request = backend.request("POST", "/gists")
    assert json.loads(request.body)["files"]["pet-snippet.toml"]["content"] \
        == UPLOADED_SNIPPET


def test_existing_gist_id_is_edited_with_patch(pet, make_backend):
    """With a gist_id configured the upload edits the existing gist.

    CATCHES: the upload becomes a PATCH to /gists/<gist_id> and no new id is
    printed.
    """
    backend = make_backend(gist_routes())
    ghe_project(pet, backend, gist_id="abc123")
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url
    assert [p for p in backend.paths() if p[0] == "PATCH"] == \
        [("PATCH", "/gists/abc123")]
    assert [p for p in backend.paths() if p[0] == "POST"] == []


def test_public_flag_is_sent_in_the_upload_body(pet, make_backend):
    """[GHEGist].public is forwarded as the gist visibility flag.

    CATCHES: public=true must appear in the JSON body of the gist edit.
    """
    backend = make_backend(gist_routes())
    ghe_project(pet, backend, gist_id="abc123", public=True)
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert json.loads(backend.request("PATCH", "/gists/abc123").body)["public"] \
        is True


def test_404_reports_no_gist_id(pet, make_backend):
    """A 404 from the gist endpoint is reported as a missing gist id.

    CATCHES: pet wraps a 404 as 'No gist ID (<id>)' with the GitHub error
    string (method, url, status and message) appended.
    """
    backend = make_backend([("GET", "/gists/gone", 404,
                             "application/json",
                             json.dumps({"message": "Not Found"}))])
    ghe_project(pet, backend, gist_id="gone")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nNo gist ID (gone): GET %s/gists/gone: 404 Not Found []\n"
        % (backend.url, backend.url)
    )


@pytest.mark.parametrize("status,message", [
    (500, "Internal Server Error"),
    (401, "Bad credentials"),
    (403, "Forbidden"),
])
def test_other_http_errors_report_failed_to_get_gist(pet, make_backend,
                                                     status, message):
    """Any non-404 HTTP error is wrapped as 'Failed to get gist'.

    CATCHES: only 404 gets the 'No gist ID' treatment; every other status is
    reported through the generic wrapper with method, url and body message.
    """
    backend = make_backend([("GET", "/gists/oops", status, "application/json",
                             json.dumps({"message": message}))])
    ghe_project(pet, backend, gist_id="oops")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nFailed to get gist: GET %s/gists/oops: %d %s []\n"
        % (backend.url, backend.url, status, message)
    )


def test_remote_file_with_wrong_name_reports_is_empty(pet, make_backend):
    """A gist whose only file has another name fails the file_name lookup.

    CATCHES: pet looks for the [GHEGist].file_name entry inside the gist, and
    the mismatch is reported as '<file_name> is empty'.
    """
    backend = make_backend(gist_routes(file_name="other-name.toml"))
    ghe_project(pet, backend, gist_id="abc123")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == "%s\npet-snippet.toml is empty\n" % backend.url


def test_remote_file_with_empty_content_reports_is_empty(pet, make_backend):
    """A gist file with empty content is rejected with '<file_name> is empty'.

    CATCHES: even a matching file name is not enough; empty content is an
    error rather than an empty download.
    """
    backend = make_backend(gist_routes(content=""))
    ghe_project(pet, backend, gist_id="abc123")
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == "%s\npet-snippet.toml is empty\n" % backend.url


def test_unreachable_host_reports_failed_to_get_gist(pet):
    """A connection refused to base_url surfaces as 'Failed to get gist'.

    CATCHES: the transport error is wrapped with the full Go url.Error text
    and the process exits 255 instead of crashing.
    """
    port = dead_port()
    pet.write_config(general={"backend": "ghe"},
                     ghe={"access_token": "tok",
                          "base_url": "http://127.0.0.1:%d" % port,
                          "gist_id": "abc123",
                          "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "http://127.0.0.1:%d\nFailed to get gist: Get "
        "\"http://127.0.0.1:%d/gists/abc123\": dial tcp 127.0.0.1:%d: "
        "connect: connection refused\n" % (port, port, port)
    )
    assert pet.snippet_text() == LOCAL_SNIPPET


def test_failed_download_leaves_the_snippet_file_intact(pet, make_backend):
    """A failing remote lookup never rewrites the local snippet file.

    CATCHES: when GetSnippet fails the command exits non-zero and the local
    file still holds its original bytes.
    """
    backend = make_backend(gist_routes(content=""))
    ghe_project(pet, backend, gist_id="abc123", public=False)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert pet.snippet_text() == LOCAL_SNIPPET
    assert pet.snippet_mode() == 0o644


def test_remote_newer_downloads_the_gist_file(pet, make_backend):
    """A remote gist newer than the local file is downloaded verbatim.

    CATCHES: the content of the gist file named by file_name is written into
    the main snippet file.
    """
    backend = make_backend(gist_routes())
    pet.write_config(general={"backend": "ghe"},
                     ghe={"access_token": "tok", "base_url": backend.url,
                          "gist_id": "abc123", "file_name": "pet-snippet.toml"})
    pet.write_snippets('[[snippets]]\n  command = "stale"\n'
                       '  description = "stale"\n', mtime=OLD_EPOCH)
    res = pet.run(["sync"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nDownload success\n" % backend.url
    assert pet.snippet_text() == UPLOADED_SNIPPET


def test_gist_backend_targets_api_github_com(pet):
    """The plain gist backend always talks to https://api.github.com.

    CATCHES: with a gist_id configured the GitHub gist client requests
    /gists/<id> on api.github.com (observed through a dead proxy).
    """
    pet.write_config(gist={"access_token": "tok", "gist_id": "zzz"})
    pet.write_snippets(LOCAL_SNIPPET)
    port = dead_port()
    res = pet.run(["sync"], env={"HTTPS_PROXY": "http://127.0.0.1:%d" % port})
    assert res.returncode == 255
    assert res.stdout.decode() == (
        'Failed to get gist: Get "https://api.github.com/gists/zzz": '
        "proxyconnect tcp: dial tcp 127.0.0.1:%d: connect: connection "
        "refused\n" % port
    )


def test_create_gist_failure_is_wrapped_twice(pet, make_backend):
    """A failing gist creation is reported by both the client and AutoSync.

    CATCHES: the message carries 'Failed to upload snippet' and the inner
    'Failed to create gist' wrapper around the GitHub error string.
    """
    backend = make_backend([("POST", "/gists", 404, "application/json",
                             json.dumps({"message": "create nope"}))])
    ghe_project(pet, backend)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "%s\nFailed to upload snippet: Failed to create gist: POST %s/gists: "
        "404 create nope []\n" % (backend.url, backend.url)
    )
