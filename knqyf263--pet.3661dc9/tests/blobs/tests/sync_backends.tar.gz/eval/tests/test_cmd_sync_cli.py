"""The `pet sync` subcommand: help, flags, exit codes and auto-sync triggers."""

import json

from conftest import (
    EDITED_SNIPPET,
    EDITED_UPLOADED,
    EMPTY_TOKEN_MESSAGES,
    LOCAL_SNIPPET,
    OLD_EPOCH,
    UPLOADED_SNIPPET,
    dead_port,
    gist_routes,
    gitlab_routes,
)

SYNC_HELP = """Sync snippets with gist/gitlab

Usage:
  pet sync [flags]

Flags:
  -h, --help   help for sync

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
"""

PANIC_FIRST_LINE = (
    "panic: runtime error: invalid memory address or nil pointer dereference"
)


def test_sync_help_prints_the_subcommand_help(pet):
    """`pet sync --help` prints the sync help text and nothing else.

    CATCHES: the help lists the inherited --config/--debug global flags, so a
    re-implementation must register them as persistent flags on the root.
    """
    res = pet.run(["sync", "--help"])
    assert res.returncode == 0
    assert res.stdout.decode() == SYNC_HELP
    assert res.stderr == b""


def test_sync_help_short_flag_matches(pet):
    """`pet sync -h` behaves exactly like `--help`.

    CATCHES: only the short help flag is accepted for the subcommand and it
    produces the very same bytes as --help.
    """
    res = pet.run(["sync", "-h"])
    assert res.returncode == 0
    assert res.stdout.decode() == SYNC_HELP


def test_sync_ignores_positional_arguments(pet):
    """Extra positional arguments do not stop `pet sync` from running.

    CATCHES: sync takes no arguments but does not reject them either; the run
    proceeds straight to the (failing) token lookup.
    """
    pet.write_config()
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync", "foo", "bar"])
    assert res.returncode == 255
    assert res.stdout.decode() == EMPTY_TOKEN_MESSAGES["gist"]


def test_unknown_flag_is_reported_on_stdout(pet):
    """An unknown flag is a plain error message on stdout with exit 255.

    CATCHES: pet silences cobra's usage output, so the only output is the
    'unknown flag' line itself.
    """
    res = pet.run(["sync", "--bogus"])
    assert res.returncode == 255
    assert res.stdout.decode() == "unknown flag: --bogus\n"
    assert res.stderr == b""


def test_unknown_command_suggests_sync(pet):
    """A misspelled command produces cobra's suggestion on stdout.

    CATCHES: 'syncc' is close enough to 'sync' for the did-you-mean hint,
    which only works if the subcommand is registered under that name.
    """
    res = pet.run(["syncc"])
    assert res.returncode == 255
    assert res.stdout.decode() == (
        'unknown command "syncc" for "pet"\n\nDid you mean this?\n\tsync\n\n'
    )


def test_broken_config_is_reported_on_stderr_with_exit_1(pet):
    """A syntactically invalid config file aborts before syncing.

    CATCHES: config load failures go to stderr (no trailing newline) with exit
    code 1, unlike sync failures which go to stdout with 255.
    """
    pet.config_file.write_text("this is [ not toml\n")
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.decode() == (
        '(1, 6): was expecting token =, but got "is" instead'
    )


def test_debug_flag_is_accepted_and_changes_nothing(pet, make_backend):
    """--debug is inherited from the root command and is a no-op for sync.

    CATCHES: the global flag must be accepted after the subcommand and must
    not alter the sync output.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync", "--debug"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url


def test_config_flag_works_after_the_subcommand(pet, make_backend):
    """--config is a persistent flag accepted both before and after `sync`.

    CATCHES: `pet sync --config <file>` must read the same file as
    `pet --config <file> sync`, so both runs produce identical output.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    before = pet.run(["--config", str(pet.config_file), "sync"],
                     with_config=False)
    after = pet.run(["sync", "--config", str(pet.config_file)],
                    with_config=False)
    assert before.returncode == after.returncode == 0
    assert after.stdout == before.stdout
    assert before.stdout.decode().endswith("Upload success\n")


def test_missing_snippetfile_key_crashes(pet, make_backend):
    """A config without snippetfile leaves pet with an unusable path.

    CATCHES: cmd/sync.go ignores the path resolution error, so AutoSync
    dereferences a nil path and the process dies with exit code 2.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"}, with_snippetfile=False,
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["sync"])
    assert res.returncode == 2
    assert res.stdout.decode() == "%s\n" % backend.url
    assert res.stderr.decode().startswith(PANIC_FIRST_LINE)


def test_new_triggers_autosync_for_the_configured_backend(pet, make_backend):
    """`pet new` honours [Gist].auto_sync and syncs via General.backend.

    CATCHES: the auto-sync switch lives in the [Gist] section even when the
    backend is gitlab, so the GitLab client is used for the upload.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gist={"auto_sync": True},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["new", "echo hi"], stdin="my description\n")
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "Command> echo hi\n%s\nUpload success\n" % backend.url
    )
    body = json.loads(backend.request("PUT", "/api/v4/snippets/7").body)
    assert body["content"] == (
        UPLOADED_SNIPPET +
        '\n[[Snippets]]\n  Description = "my description"\n  Output = ""\n'
        '  Tag = []\n  command = "echo hi"\n'
    )


def test_new_ignores_the_gitlab_auto_sync_flag(pet, make_backend):
    """[GitLab].auto_sync does not trigger the automatic sync.

    CATCHES: only [Gist].auto_sync is consulted, so a gitlab-only auto_sync
    setting leaves `pet new` without any sync output.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab"},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml",
                             "auto_sync": True})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["new", "echo hi"], stdin="my description\n")
    assert res.returncode == 0
    assert res.stdout.decode() == "Command> echo hi\n"
    assert backend.requests == []


def test_new_without_token_keeps_the_saved_snippet(pet):
    """A missing token fails the auto-sync but keeps the new snippet.

    CATCHES: the snippet is written to the main file before the sync runs, so
    the file keeps the new entry even though the command exits 255.
    """
    pet.write_config(gist={"auto_sync": True})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["new", "echo hi"], stdin="my description\n")
    assert res.returncode == 255
    assert res.stdout.decode() == (
        "Command> echo hi\n" + EMPTY_TOKEN_MESSAGES["gist"]
    )
    assert "my description" in pet.snippet_text()
    assert "echo hi" in pet.snippet_text()


def test_edit_triggers_autosync_when_content_changes(pet, make_backend):
    """`pet edit` syncs after the editor changed the snippet file.

    CATCHES: pet compares the file before and after running the editor and
    uploads the new content when they differ.
    """
    backend = make_backend(gitlab_routes())
    editor = pet.write_editor(EDITED_SNIPPET)
    pet.write_config(general={"backend": "gitlab", "editor": editor},
                     gist={"auto_sync": True},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["edit"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url
    assert pet.snippet_text() == EDITED_SNIPPET
    assert json.loads(
        backend.request("PUT", "/api/v4/snippets/7").body)["content"] == \
        EDITED_UPLOADED


def test_edit_without_a_change_skips_the_sync(pet, make_backend):
    """An editor that leaves the file untouched triggers no sync.

    CATCHES: pet skips AutoSync when the content is unchanged, so no request
    reaches the backend at all.
    """
    backend = make_backend(gitlab_routes())
    pet.write_config(general={"backend": "gitlab", "editor": "true",
                              "snippetfile": str(pet.snippet_file)},
                     gist={"auto_sync": True},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["edit"])
    assert res.returncode == 0
    assert res.stdout.decode() == ""
    assert backend.requests == []


def test_new_with_editor_flag_triggers_autosync(pet, make_backend):
    """`pet new -e` runs the editor and then syncs the result.

    CATCHES: the editor path of `pet new` also honours [Gist].auto_sync and
    uploads whatever the editor left in the file.
    """
    backend = make_backend(gitlab_routes())
    editor = pet.write_editor(EDITED_SNIPPET)
    pet.write_config(general={"backend": "gitlab", "editor": editor},
                     gist={"auto_sync": True},
                     gitlab={"access_token": "tok", "url": backend.url,
                             "id": "7", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET)
    res = pet.run(["new", "-e"])
    assert res.returncode == 0
    assert res.stdout.decode() == "%s\nUpload success\n" % backend.url
    assert json.loads(
        backend.request("PUT", "/api/v4/snippets/7").body)["content"] == \
        EDITED_UPLOADED


def test_unreachable_backend_does_not_corrupt_the_snippet_file(pet):
    """A failing backend never destroys the local snippet file.

    CATCHES: after an unreachable ghe backend the file still holds the exact
    original bytes and mode.
    """
    port = dead_port()
    pet.write_config(general={"backend": "ghe"},
                     ghe={"access_token": "tok",
                          "base_url": "http://127.0.0.1:%d" % port,
                          "gist_id": "abc123",
                          "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET, mtime=OLD_EPOCH, mode=0o600)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert pet.snippet_text() == LOCAL_SNIPPET
    assert pet.snippet_mode() == 0o600


def test_ghe_error_leaves_the_file_alone(pet, make_backend):
    """A remote error on download keeps the stale local file.

    CATCHES: when the gist lookup fails the local file is not replaced, even
    though pet had already decided to download because the remote was newer.
    """
    backend = make_backend([("GET", "/gists/abc123", 500, "application/json",
                             json.dumps({"message": "boom"}))])
    pet.write_config(general={"backend": "ghe"},
                     ghe={"access_token": "tok", "base_url": backend.url,
                          "gist_id": "abc123", "file_name": "pet-snippet.toml"})
    pet.write_snippets(LOCAL_SNIPPET, mtime=OLD_EPOCH)
    res = pet.run(["sync"])
    assert res.returncode == 255
    assert pet.snippet_text() == LOCAL_SNIPPET
