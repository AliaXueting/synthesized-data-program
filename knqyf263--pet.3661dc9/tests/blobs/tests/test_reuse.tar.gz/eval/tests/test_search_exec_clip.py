"""``pet search`` / ``pet exec`` / ``pet clip`` selection pipelines.

Rewritten from ``cmd/exec_test.go`` (TestExecute_EmptyString,
TestExecute_SilentFlag) plus the selector plumbing in cmd/util.go filter().
Deterministic selections come from a configured ``SelectCmd`` (``cat``,
``head -n 1``, capture scripts) instead of an interactive fzf.
"""

import pytest

from conftest import (run_pet, snippet_block, make_script,
                      SELECTOR_SCRIPT, TEE_SELECTOR_SCRIPT)

TWO_SNIPPETS = (
    snippet_block("first snippet", "echo one", tag=["alpha"])
    + snippet_block("second snippet", "echo two", tag=["beta"])
)

CAT_CONFIG = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "cat"\n')

HEAD_CONFIG = ('[General]\n'
               '  SnippetFile = "{home}/snippets.toml"\n'
               '  SelectCmd = "head -n 1"\n')


def test_search_joins_all_selected_without_trailing_newline(tmp_path):
    """``SelectCmd = cat`` selects every line; search prints the commands
    joined with the default "; " delimiter and NO trailing newline (the
    newline is only added when stdout is a terminal)."""
    # CATCHES: search checks term.IsTerminal(1) before the final newline -
    # piped output must end right after the last command byte.
    res = run_pet(["search"], tmp_path=tmp_path, config=CAT_CONFIG,
                  snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == "echo one; echo two"
    assert res.err == ""


def test_search_custom_delimiter(tmp_path):
    """``-d`` replaces the join delimiter between selected commands."""
    # CATCHES: the delimiter is inserted verbatim (default "; "), including
    # multi-character values.
    res = run_pet(["search", "-d", " && "], tmp_path=tmp_path,
                  config=CAT_CONFIG, snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == "echo one && echo two"


def test_search_single_selection_returns_one_command(tmp_path):
    """``SelectCmd = head -n 1`` selects only the first formatted line, so
    search prints exactly that snippet's command."""
    # CATCHES: the selection maps back through the formatted-text map to the
    # snippet's real command, not the displayed line.
    res = run_pet(["search"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == "echo one"


def test_search_with_unset_selectcmd_is_silently_empty(tmp_path):
    """A config that omits SelectCmd yields an empty selector command; the
    empty selection maps to an empty command and search prints nothing with
    exit 0 - while the same snippets behind ``SelectCmd = cat`` print both
    commands."""
    # CATCHES: the fzf default only applies to freshly generated configs; a
    # hand-written config without SelectCmd runs "sh -c ' '" and swallows
    # the error (filter returns nil, nil), so no failure surfaces.
    config = '[General]\n  SnippetFile = "{home}/snippets.toml"\n'
    res = run_pet(["search"], tmp_path=tmp_path, config=config,
                  snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""

    res = run_pet(["search"], tmp_path=tmp_path, config=CAT_CONFIG,
                  snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == "echo one; echo two"


def test_search_default_selectcmd_uses_fzf(tmp_path):
    """The generated default config pipes through fzf; with no fzf on PATH
    the selector fails, filter swallows the error and search succeeds with
    empty output while sh reports the missing command on stderr."""
    # CATCHES: filter() discards the selector's error (returns nil, nil) but
    # the child's stderr still leaks through to pet's stderr.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "fzf --ansi"\n')
    res = run_pet(["search"], tmp_path=tmp_path, config=config,
                  snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == "sh: 1: fzf: not found\n"


def test_selector_receives_formatted_snippet_lines(tmp_path):
    """The selector's stdin carries one formatted line per snippet using the
    default format "[$description]: $command $tags", with tags rendered as
    "#tag " each and newlines in commands escaped to literal backslash-n."""
    # CATCHES: pins the exact text pet feeds to the select command - the
    # trailing space after the tag list and the literal "\\n" escaping.
    make_script(tmp_path, "sel.sh", TEE_SELECTOR_SCRIPT.format(
        log=str(tmp_path / "args.log"),
        stdinlog=str(tmp_path / "stdin.log"),
        selection=str(tmp_path / "selection.txt")))
    (tmp_path / "selection.txt").write_text("")
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "{home}/sel.sh"\n')
    snippets = (
        snippet_block("first snippet", "echo one", tag=["alpha", "x y"])
        + snippet_block("second", "echo two\\necho three")
    )
    res = run_pet(["search"], tmp_path=tmp_path, config=config, snippets=snippets)
    assert res.rc == 0
    assert (tmp_path / "stdin.log").read_text() == (
        "[first snippet]: echo one #alpha #x y \n"
        "[second]: echo two\\necho three \n"
    )


def test_selector_custom_format_replaces_first_occurrence_only(tmp_path):
    """A configured ``Format`` replaces each placeholder's FIRST occurrence
    only; a second "$command" stays literal."""
    # CATCHES: strings.Replace is called with count=1 per placeholder, so
    # "[$description] $command || $command" keeps the second "$command".
    make_script(tmp_path, "sel.sh", TEE_SELECTOR_SCRIPT.format(
        log=str(tmp_path / "args.log"),
        stdinlog=str(tmp_path / "stdin.log"),
        selection=str(tmp_path / "selection.txt")))
    (tmp_path / "selection.txt").write_text("")
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  Format = "CMD=$command DESC=$description TAGS=$tags END"\n'
              '  SelectCmd = "{home}/sel.sh"\n')
    res = run_pet(["search"], tmp_path=tmp_path, config=config,
                  snippets=snippet_block("first snippet", "echo one",
                                         tag=["alpha"]))
    assert res.rc == 0
    assert (tmp_path / "stdin.log").read_text() == (
        "CMD=echo one DESC=first snippet TAGS=#alpha  END\n")

    config2 = config.replace(
        'Format = "CMD=$command DESC=$description TAGS=$tags END"',
        'Format = "[$description] $command || $command <> $tags"')
    res = run_pet(["search"], tmp_path=tmp_path, config=config2,
                  snippets=snippet_block("first snippet", "echo one",
                                         tag=["alpha"]))
    assert res.rc == 0
    assert (tmp_path / "stdin.log").read_text() == (
        "[first snippet] echo one || $command <> #alpha \n")


def test_exec_runs_selected_command_with_prefix_line(tmp_path):
    """``pet exec`` prints "> <command>" then executes it through "sh -c"
    with stdout inherited."""
    # CATCHES: cmd/exec_test.go - the "> " prefix line precedes execution
    # and the command output follows on the same stream.
    res = run_pet(["exec"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == "> echo one\none\n"
    assert res.err == ""


def test_exec_silent_suppresses_only_prefix_line(tmp_path):
    """``--silent`` suppresses the "> <command>" echo but still runs the
    command and shows its output."""
    # CATCHES: cmd/exec_test.go TestExecute_SilentFlag - silent mutes the
    # prefix, not the executed command's own output.
    res = run_pet(["exec", "-s"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == "one\n"


def test_exec_joins_multiple_selections_with_semicolon(tmp_path):
    """Multiple selected lines are joined with "; " into one shell command,
    so both echo commands run in sequence."""
    # CATCHES: multi-selection concatenates COMMANDS (not lines) through
    # strings.Join(commands, "; ") before sh -c runs them.
    res = run_pet(["exec"], tmp_path=tmp_path, config=CAT_CONFIG,
                  snippets=TWO_SNIPPETS)
    assert res.rc == 0
    assert res.out == "> echo one; echo two\none\ntwo\n"


def test_exec_propagates_nonzero_exit_status(tmp_path):
    """A selected command exiting 3 makes pet report "exit status 3" on
    stdout and exit 255 itself."""
    # CATCHES: the exec.Cmd error from run() propagates through RunE to the
    # root Execute() which prints it and exits -1 (255).
    res = run_pet(["exec"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippet_block("failer", "exit 3"))
    assert res.rc == 255
    assert res.out == "> exit 3\nexit status 3\n"


def test_exec_passes_command_stderr_through(tmp_path):
    """The executed command's stderr is wired to pet's stderr while exit
    status stays 0."""
    # CATCHES: run() sets cmd.Stderr = os.Stderr - stderr is not merged
    # into stdout.
    res = run_pet(["exec"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippet_block("stderrer", "echo to-err >&2"))
    assert res.rc == 0
    assert res.out == "> echo to-err >&2\n"
    assert res.err == "to-err\n"


def test_clip_without_clipboard_reports_missing_utilities(tmp_path):
    """``pet clip`` with no clipboard helper on PATH fails with the
    "No clipboard utilities available." message on stdout and exit 255."""
    # CATCHES: atotto/clipboard's error surfaces through RunE (printed to
    # stdout with rc 255), not as a Go panic.
    res = run_pet(["clip", "--raw"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippet_block("s", "echo hi"))
    assert res.rc == 255
    assert res.out == (
        "No clipboard utilities available. Please install xsel, xclip, "
        "wl-clipboard or Termux:API add-on for termux-clipboard-get/set.\n"
    )


def test_clip_command_flag_prints_selected_command(tmp_path):
    """``--command`` prints "Command: <selected command>" before the
    clipboard write is attempted."""
    # CATCHES: the flag only prints when the joined command is non-empty;
    # the label has no color codes when stdout is piped.
    res = run_pet(["clip", "--raw", "--command"], tmp_path=tmp_path,
                  config=HEAD_CONFIG, snippets=snippet_block("s", "echo hi"))
    assert res.rc == 255
    assert res.out == (
        "Command: echo hi\n"
        "No clipboard utilities available. Please install xsel, xclip, "
        "wl-clipboard or Termux:API add-on for termux-clipboard-get/set.\n"
    )


@pytest.mark.parametrize("cmd, expected_args", [
    (["search", "-q", "foo bar"], "SEL: [--query] [foo bar]"),
    (["exec", "-q", "foo; rm x"], "SEL: [--query] [foo; rm x]"),
    # clip.go is the one caller that forgets shellescape.Quote
    (["clip", "-q", "foo bar"], "SEL: [--query] [foo] [bar]"),
])
def test_query_flag_quoting_per_command(tmp_path, cmd, expected_args):
    """search/exec shell-quote the --query value into one selector
    argument; clip passes it through unquoted so it word-splits."""
    # CATCHES: clip.go builds "--query %s" without shellescape.Quote - the
    # selector receives three arguments instead of two.
    make_script(tmp_path, "sel.sh", SELECTOR_SCRIPT.format(
        log=str(tmp_path / "args.log"), selection=str(tmp_path / "sel.txt")))
    (tmp_path / "sel.txt").write_text("[s]: echo sel\n")
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "{home}/sel.sh"\n')
    run_pet(cmd, tmp_path=tmp_path, config=config,
            snippets=snippet_block("s", "echo sel"))
    assert (tmp_path / "args.log").read_text() == expected_args + "\n"


def test_config_cmd_prefix_replaces_shell_execution(tmp_path):
    """With ``Cmd`` configured, run() execs Cmd's argv with the command
    appended as the last argument instead of "sh -c"."""
    # CATCHES: the same Cmd prefix applies to the executed snippet command -
    # "/bin/echo WRAPPED: <cmd>" prints the command rather than running it.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "head -n 1"\n'
              '  Cmd = ["/bin/echo", "WRAPPED:"]\n')
    res = run_pet(["exec"], tmp_path=tmp_path, config=config,
                  snippets=snippet_block("one", "echo uno"))
    assert res.rc == 0
    assert res.out == "> \nWRAPPED: \n"
