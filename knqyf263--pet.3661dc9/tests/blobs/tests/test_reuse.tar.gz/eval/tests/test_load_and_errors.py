"""Snippet-file loading, snippet-directory discovery and error paths.

Rewritten from the native suite's ``snippet/snippet_test.go`` (TestLoad,
TestLoadWithIncludeDirectories), ``snippet/util_test.go`` (TestTomlRegEx,
TestGetFiles) and ``path/path_test.go`` (expandPath cases), all driven through
the CLI.  RunError messages below were recorded from the reference binary.
"""

import pytest

from conftest import run_pet, snippet_block

MAIN_SNIPPETS = snippet_block("main snippet", "echo main")


def test_missing_snippet_file_error(tmp_path):
    """A missing main snippet file aborts with the three-line guidance
    message on stdout and exit status 255 (os.Exit(-1))."""
    # CATCHES: the error names the configured path verbatim and wraps at the
    # exact hardcoded line breaks; errors go to stdout, not stderr.
    config = '[General]\n  SnippetFile = "{home}/gone.toml"\n'
    res = run_pet(["list"], tmp_path=tmp_path, config=config, snippets=None)
    assert res.rc == 255
    assert res.out == (
        "snippet file not found. %s/gone.toml\n"
        "Please run 'pet configure' and provide a correct file path, or remove this\n"
        "if you only want to provide snippetdirs instead\n" % tmp_path
    )
    assert res.err == ""


def test_missing_snippet_dir_error(tmp_path):
    """A configured snippet directory that does not exist aborts with
    "snippet directory not found." once the main file itself exists."""
    # CATCHES: the directory check only runs after the main snippet file
    # check passes - a missing main file wins over a missing directory.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SnippetDirs = ["{home}/no-such-dir"]\n')
    res = run_pet(["list"], tmp_path=tmp_path, config=config)
    assert res.rc == 255
    assert res.out == "snippet directory not found. %s/no-such-dir\n" % tmp_path


def test_invalid_toml_snippet_file_error(tmp_path):
    """An unparsable snippet file reports "failed to parse snippet file."
    with go-toml's position-annotated message."""
    # CATCHES: the parser error is prefixed by pet's own wrapper text and
    # includes the (line, column) position of the offending token.
    res = run_pet(["list"], tmp_path=tmp_path, snippets="this is not toml {{{")
    assert res.rc == 255
    assert res.out == (
        'failed to parse snippet file. (1, 6): was expecting token =, '
        'but got "is" instead\n'
    )


def test_unescaped_newline_in_command_is_parse_error(tmp_path):
    """A raw newline inside a TOML basic string (the command value) is
    rejected as an unescaped control character."""
    # CATCHES: multiline commands must be written with \\n escapes; a
    # re-implementation accepting raw newlines would silently load instead.
    res = run_pet(["list"], tmp_path=tmp_path, snippets=(
        '\n[[Snippets]]\n'
        '  Description = "d"\n'
        '  Output = ""\n'
        '  Tag = []\n'
        '  command = "echo two\necho three"\n'))
    assert res.rc == 255
    assert res.out == (
        "failed to parse snippet file. (6, 14): "
        "unescaped control character U+000A\n"
    )


def test_snippet_file_pointing_at_directory(tmp_path):
    """A SnippetFile that exists but is a directory fails at read time with
    "failed to load snippet file." carrying Go's is-a-directory error."""
    # CATCHES: os.Stat succeeds for directories so the not-found branch is
    # skipped; the failure surfaces later while reading the file.
    (tmp_path / "asdir").mkdir()
    config = '[General]\n  SnippetFile = "{home}/asdir"\n'
    res = run_pet(["list"], tmp_path=tmp_path, config=config, snippets=None)
    assert res.rc == 255
    assert res.out == (
        "failed to load snippet file. read %s/asdir: is a directory\n" % tmp_path
    )


def test_snippet_dirs_load_only_toml_files_recursively(tmp_path):
    """Snippet directories are walked recursively and only files whose name
    ends in ".toml" are loaded (".json", ".yaml", ".tomlx" are ignored)."""
    # CATCHES: mirrors snippet/util_test.go TestTomlRegEx - the extension
    # match is anchored so "e.tomlx" must NOT be treated as a snippet file.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SnippetDirs = ["{home}/inc"]\n')
    files = {
        "inc/a.toml": snippet_block("inc a", "echo a"),
        "inc/b.json": snippet_block("json skipped", "echo skipped"),
        "inc/sub/c.toml": snippet_block("inc sub c", "echo c"),
        "inc/e.tomlx": snippet_block("bad ext", "echo badext"),
        "inc/d.yaml": snippet_block("yaml skipped", "echo yskip"),
    }
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path, config=config,
                  snippets=MAIN_SNIPPETS, files=files)
    assert res.rc == 0
    lines = res.out.splitlines()
    assert [l.split(" : ")[0].rstrip() for l in lines] == [
        "main snippet", "inc a", "inc sub c"]


def test_snippet_dirs_walk_in_lexical_order_main_file_first(tmp_path):
    """The main file's snippets always come first, then directory files in
    filepath.Walk (lexical) order."""
    # CATCHES: mirrors snippet_test.go TestLoadWithIncludeDirectories - the
    # load order is main file, then each dir walked lexically (a before z,
    # subdirectories inline).
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SnippetDirs = ["{home}/inc1", "{home}/inc2"]\n')
    files = {
        "inc1/z.toml": snippet_block("inc1 z", "echo z"),
        "inc1/a.toml": snippet_block("inc1 a", "echo a"),
        "inc2/m.toml": snippet_block("inc2 m", "echo m"),
    }
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path, config=config,
                  snippets=MAIN_SNIPPETS, files=files)
    assert res.rc == 0
    names = [l.split(" : ")[0].rstrip() for l in res.out.splitlines()]
    assert names == ["main snippet", "inc1 a", "inc1 z", "inc2 m"]


def test_snippet_dir_entry_may_be_a_toml_file(tmp_path):
    """A SnippetDirs entry pointing directly at a "*.toml" file is loaded:
    filepath.Walk visits the root path itself."""
    # CATCHES: no directory check rejects a plain file entry - the walk
    # callback matches the file's own name against the .toml regex.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SnippetDirs = ["{home}/only.toml"]\n')
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path, config=config,
                  snippets=MAIN_SNIPPETS,
                  files={"only.toml": snippet_block("file as dir", "echo fad")})
    assert res.rc == 0
    names = [l.split(" : ")[0].rstrip() for l in res.out.splitlines()]
    assert names == ["main snippet", "file as dir"]


def test_snippetfile_tilde_is_expanded_to_home(tmp_path):
    """A "~/"-prefixed SnippetFile resolves against $HOME (path.expandPath),
    not against the current working directory."""
    # CATCHES: mirrors path_unix_test.go TestExpandPathWithTilde - the tilde
    # is expanded before the file is opened, so the snippet loads from
    # <tmp>/.config/pet/snippet.toml while pet runs with cwd=<tmp>.
    config = ('[General]\n'
              '  SnippetFile = "~/.config/pet/snippet.toml"\n')
    files = {".config/pet/snippet.toml": snippet_block("tilde snip", "echo tilde")}
    res = run_pet(["list"], tmp_path=tmp_path, config=config, snippets=None,
                  files=files)
    assert res.rc == 0
    assert res.out == (
        "Description: tilde snip\n"
        "    Command: echo tilde\n"
        "        Tag: \n"
        "------------------------------\n"
    )


def test_snippetfile_relative_path_strips_two_characters(tmp_path):
    """A relative SnippetFile is mangled: expandPath joins $HOME with
    path[2:], so "snips.toml" resolves to "<home>/ips.toml"."""
    # CATCHES: upstream quirk kept from path.go - the first two characters
    # of ANY relative path are dropped before joining with the home dir.
    config = '[General]\n  SnippetFile = "snips.toml"\n'
    files = {"ips.toml": snippet_block("stripped path quirk", "echo quirk")}
    res = run_pet(["list"], tmp_path=tmp_path, config=config, snippets=None,
                  files=files)
    assert res.rc == 0
    assert res.out == (
        "Description: stripped path quirk\n"
        "    Command: echo quirk\n"
        "        Tag: \n"
        "------------------------------\n"
    )


def test_snippetfile_relative_missing_reports_original_name(tmp_path):
    """When the mangled relative path does not exist, the error message
    reports the original configured string, not the expanded one."""
    # CATCHES: Load() formats the error with the raw config value while the
    # stat used the expanded path - both halves must stay decoupled.
    config = '[General]\n  SnippetFile = "snips.toml"\n'
    res = run_pet(["list"], tmp_path=tmp_path, config=config, snippets=None)
    assert res.rc == 255
    assert res.out == (
        "snippet file not found. snips.toml\n"
        "Please run 'pet configure' and provide a correct file path, or remove this\n"
        "if you only want to provide snippetdirs instead\n"
    )


def test_snippetfile_empty_string_is_resolving_error(tmp_path):
    """An empty SnippetFile fails path resolution with the "unknown path"
    message (path_test.go TestExpandPathWithEmptyInputErrors)."""
    # CATCHES: expandPath distinguishes "" (error), "~" (home) and longer
    # relatives (quirky strip) - the empty case must error, not fall back.
    config = '[General]\n  SnippetFile = ""\n'
    res = run_pet(["list"], tmp_path=tmp_path, config=config, snippets=None)
    assert res.rc == 255
    assert res.out == "error resolving relative path - unknown path: \n"
