"""Path resolution (path/path.go expandPath / NewAbsolutePath) observed
through every CLI entry point that funnels a configured path through it:
``--config``, ``SnippetFile``, ``SnippetDirs`` and ``PET_CONFIG_DIR``.

The native suite (``path_test.go`` / ``path_unix_test.go``) only exercises
four inputs: ``""`` (error), ``~/.config/pet`` and ``~/relative/path``
(tilde-prefix join) and ``/var/tmp`` (absolute passthrough).  The branches
left unpinned are exactly the ones these tests record against the reference:

* a path that is *exactly* ``~`` expands to the whole home directory, and
* a relative path with no usable ``$HOME`` fails with the "unknown home
  dir" error (the home lookup happens *before* the ``~`` comparison).
"""

import re

import pytest

from conftest import run_pet

#: Version output shape: an ldflags-injected revision hash (the reference
#: prints "pet version 3661dc9cb080bf48343e2d7f56a75abd3864c1d6").
VERSION_RE = re.compile(r"^pet version [0-9a-f]{40}\n$")

#: First bytes of the recorded root.go panic: initConfig calls plain
#: ``panic(err)`` when the --config path cannot be made absolute, so Go's
#: runtime prints the multi-line error with every continuation line
#: tab-indented, then the goroutine dump.
NO_HOME_PANIC_PREFIX = (
    "panic: error resolving relative path - unknown home dir:\n"
    "\t$HOME is not defined\n"
    "\n"
    "goroutine 1 [running]:\n"
)

#: The "unknown home dir" error text once it reaches a command's RunE
#: (printed by fmt.Println, hence a trailing newline).
NO_HOME_RUNE_ERROR = (
    "error resolving relative path - unknown home dir:\n$HOME is not defined\n"
)


@pytest.mark.parametrize("tilde", [
    pytest.param("~", id="bare tilde"),
    pytest.param("~/", id="tilde slash"),
])
def test_config_flag_tilde_variants_read_home_directory(tmp_path, tilde):
    """``--config ~`` (and ``~/``) resolve to the home DIRECTORY itself, so
    loading the config fails with Go's "is a directory" read error on stderr
    and exit 1."""
    # CATCHES: expandPath special-cases a path that is exactly "~" to the
    # whole home dir, and "~/" collapses onto it via the strip-two rule -
    # neither ever looks at the cwd, and neither is treated as a file name.
    res = run_pet(["--config", tilde, "version"], tmp_path=tmp_path,
                  config=None, snippets=None)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == "read %s: is a directory" % tmp_path


@pytest.mark.parametrize("config_path", [
    pytest.param("./rel.toml", id="relative"),
    pytest.param("~", id="bare tilde"),
])
def test_config_flag_path_without_home_panics(tmp_path, config_path):
    """With an empty ``$HOME`` the --config path cannot be made absolute and
    initConfig dies via ``panic(err)``: exit 2, empty stdout, the tab-indented
    "unknown home dir" panic value and the initConfig frame on the stack."""
    # CATCHES: expandPath consults os.UserHomeDir() BEFORE comparing the path
    # to "~", so even the bare tilde reports the missing home dir rather than
    # expanding - and initConfig panics (rc 2) instead of printing the error.
    res = run_pet(["--config", config_path, "version"], tmp_path=tmp_path,
                  config=None, snippets=None, env={"HOME": ""})
    assert res.rc == 2
    assert res.out == ""
    assert res.err.startswith(NO_HOME_PANIC_PREFIX)
    assert "github.com/knqyf263/pet/cmd.initConfig()" in res.err


def test_snippetfile_bare_tilde_fails_reading_home_as_file(tmp_path):
    """``SnippetFile = "~"`` expands the snippet file to the home directory:
    os.Stat succeeds (it exists), so the failure only surfaces at read time
    as "failed to load snippet file." on stdout with exit 255."""
    # CATCHES: unlike "~/"-prefixed values which resolve to a file *inside*
    # home, the bare tilde names the directory itself - the stat-based
    # not-found branch is skipped and the ReadFile error is what escapes.
    res = run_pet(["list"], tmp_path=tmp_path,
                  config='[General]\n  SnippetFile = "~"\n', snippets=None)
    assert res.rc == 255
    assert res.out == "failed to load snippet file. read %s: is a directory\n" \
        % tmp_path
    assert res.err == ""


def test_snippetfile_relative_without_home_reports_unknown_home_dir(tmp_path):
    """A relative SnippetFile with an empty ``$HOME`` fails inside
    snippet.Load - after the config itself loaded fine - so the error takes
    the RunE path: stdout, exit 255, no panic."""
    # CATCHES: the same expandPath failure surfaces differently per entry
    # point - via --config it panics in initConfig (rc 2, stderr), via
    # SnippetFile it is a plain RunE error printed to stdout with rc 255.
    config = '[General]\n  SnippetFile = "./rel.toml"\n'
    res = run_pet(["--config", str(tmp_path / "cfg.toml"), "list"],
                  tmp_path=tmp_path, config=None, snippets=None,
                  files={"cfg.toml": config}, env={"HOME": ""})
    assert res.rc == 255
    assert res.out == NO_HOME_RUNE_ERROR
    assert res.err == ""


def test_snippetdirs_relative_without_home_reports_unknown_home_dir(tmp_path):
    """A relative ``SnippetDirs`` entry with an empty ``$HOME`` fails even
    though the main snippet file resolved fine: each directory entry is made
    absolute before it is ever stat'ed."""
    # CATCHES: the dirs loop resolves the configured string BEFORE os.Stat,
    # so the ./mydirs entry errors on path expansion alone - the directory
    # does not need to exist for (and is never touched by) this failure.
    config = ('[General]\n'
              '  SnippetFile = "%s/snippets.toml"\n'
              '  SnippetDirs = ["./mydirs"]\n' % tmp_path)
    res = run_pet(["--config", str(tmp_path / "cfg.toml"), "list"],
                  tmp_path=tmp_path, config=None, snippets=None,
                  files={"cfg.toml": config, "snippets.toml": ""},
                  env={"HOME": ""})
    assert res.rc == 255
    assert res.out == NO_HOME_RUNE_ERROR
    assert res.err == ""


def test_snippetfile_single_dot_is_unknown_path_error(tmp_path):
    """``SnippetFile = "."`` is rejected by path expansion itself: any
    relative path shorter than two characters is an "unknown path" error and
    never reaches the strip-two home join."""
    # CATCHES: expandPath only joins home for relative paths LONGER than one
    # character, so "." errors out exactly like the empty string - a
    # re-implementation that cwd-joins "." would list snippets instead.
    res = run_pet(["list"], tmp_path=tmp_path,
                  config='[General]\n  SnippetFile = "."\n', snippets=None)
    assert res.rc == 255
    assert res.out == "error resolving relative path - unknown path: .\n"
    assert res.err == ""


def test_pet_config_dir_relative_without_home_errors(tmp_path):
    """A relative ``PET_CONFIG_DIR`` with an empty ``$HOME`` is mkdir'ed
    verbatim (relcfg/ appears in the cwd) and only then fails to become
    absolute: initConfig prints the error to stderr, exit 1, no newline."""
    # CATCHES: GetDefaultConfigDir runs MkdirAll on the RAW env value before
    # NewAbsolutePath, so the directory skeleton exists even though the
    # resolution then fails - and the error goes through the stderr/exit-1
    # path, not the panic initConfig uses for --config.
    res = run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
                  pet_config_dir=False,
                  env={"HOME": "", "PET_CONFIG_DIR": "relcfg"})
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ("error resolving relative path - unknown home dir:\n"
                       "$HOME is not defined")
    assert (tmp_path / "relcfg").is_dir()


def test_homeless_default_config_dir_creates_relative_skeleton_then_errors(
        tmp_path):
    """With neither ``$HOME`` nor ``PET_CONFIG_DIR`` the default config dir
    ``filepath.Join("", ".config", "pet")`` stays RELATIVE: pet creates
    ``.config/pet`` under the cwd and then fails to make it absolute."""
    # CATCHES: the default-dir join uses the empty $HOME verbatim instead of
    # erroring early, so the skeleton directory is observable in the cwd
    # before the same "unknown home dir" error kills the run.
    res = run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
                  pet_config_dir=False, env={"HOME": ""})
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ("error resolving relative path - unknown home dir:\n"
                       "$HOME is not defined")
    assert (tmp_path / ".config" / "pet").is_dir()
    assert not (tmp_path / ".config" / "pet" / "config.toml").exists()


def test_snippetfile_under_regular_file_is_stat_error(tmp_path):
    """A SnippetFile whose parent is a regular file fails os.Stat with ENOTDIR
    - which is not "not exist" - so snippet.Load reports the raw stat error
    on stdout with exit 255, unlike the not-found message."""
    # CATCHES: the same ENOTDIR situation that --config reports on stderr
    # with rc 1 takes the SnippetFile route to stdout with rc 255 - and the
    # message is the "failed to load snippet file." wrapper, not the
    # "snippet file not found." one reserved for IsNotExist.
    res = run_pet(["list"], tmp_path=tmp_path,
                  config='[General]\n  SnippetFile = "%s/regfile/snips.toml"\n'
                         % tmp_path,
                  snippets=None, files={"regfile": "x"})
    assert res.rc == 255
    assert res.out == ("failed to load snippet file. stat %s/regfile/"
                       "snips.toml: not a directory\n" % tmp_path)
    assert res.err == ""


def test_config_under_regular_file_is_stat_error(tmp_path):
    """A ``--config`` path whose parent is a regular file fails os.Stat with
    ENOTDIR - which is NOT "not exist" - so pet reports the raw stat error
    on stderr with exit 1 instead of creating the file."""
    # CATCHES: config.Load distinguishes stat failures: only IsNotExist
    # triggers default-config creation, so ENOTDIR must surface as the bare
    # "stat ...: not a directory" error rather than an open/create error.
    res = run_pet(["--config", str(tmp_path / "regfile" / "x.toml"),
                   "version"],
                  tmp_path=tmp_path, config=None, snippets=None,
                  files={"regfile": "x"})
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ("stat %s/regfile/x.toml: not a directory" % tmp_path)


def test_config_in_missing_parent_directory_fails_creation(tmp_path):
    """A ``--config`` path in a directory that does not exist takes the
    create-default branch (stat says ENOENT) and then os.Create fails,
    because pet never mkdirs the parent."""
    # CATCHES: the default-config branch only creates the FILE - the missing
    # parent directory is not created first, so the recorded failure is the
    # open(2) error, not a successful default config.
    res = run_pet(["--config", str(tmp_path / "missingdir" / "config.toml"),
                   "version"],
                  tmp_path=tmp_path, config=None, snippets=None)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ("open %s/missingdir/config.toml: no such file or "
                       "directory" % tmp_path)
    assert not (tmp_path / "missingdir").exists()


def test_config_creation_reports_default_config_dir_failure(tmp_path):
    """When ``--config`` names a creatable new file but ``PET_CONFIG_DIR`` is
    blocked by a regular file, the empty config file is created FIRST and the
    default-config-dir failure is reported afterwards."""
    # CATCHES: config.Load creates the config file before resolving the
    # default config dir, so new.toml exists but stays EMPTY when
    # GetDefaultConfigDir fails - the error is the wrapped mkdir failure.
    res = run_pet(["--config", str(tmp_path / "new.toml"), "version"],
                  tmp_path=tmp_path, config=None, snippets=None,
                  files={"blocker": "x"},
                  env={"PET_CONFIG_DIR": str(tmp_path / "blocker")})
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ("Failed to get the default config directory: "
                       "cannot create directory: mkdir %s/blocker: "
                       "not a directory" % tmp_path)
    assert (tmp_path / "new.toml").read_bytes() == b""


def test_relative_pet_config_dir_is_stripped_before_use(tmp_path):
    """A relative ``PET_CONFIG_DIR`` is mkdir'ed verbatim in the cwd but then
    run through expandPath, whose strip-two rule maps ``petdir`` to
    ``<home>/tdir`` - where no directory was ever created."""
    # CATCHES: the same two-character-strip quirk known from SnippetFile
    # applies to PET_CONFIG_DIR: petdir/ is created in the cwd while the
    # config is expected at $HOME/tdir/config.toml and fails to open there.
    res = run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
                  pet_config_dir=False, env={"PET_CONFIG_DIR": "petdir"})
    assert res.rc == 1
    assert res.out == ""
    assert res.err == ("open %s/tdir/config.toml: no such file or directory"
                       % tmp_path)
    assert (tmp_path / "petdir").is_dir()
    assert not (tmp_path / "tdir").exists()


def test_config_flag_relative_path_strips_two_chars(tmp_path):
    """A relative ``--config`` value loses its first two characters before
    being joined with ``$HOME``: ``XXcfg.toml`` never appears on disk and the
    default config is written to ``<home>/cfg.toml`` while the command still
    succeeds."""
    # CATCHES: expandPath's path[2:] quirk is entry-point independent - the
    # --config flag gets the same mangling as SnippetFile, so the created
    # file's name is "cfg.toml", not "XXcfg.toml".
    res = run_pet(["--config", "XXcfg.toml", "version"], tmp_path=tmp_path,
                  config=None, snippets=None)
    assert res.rc == 0
    assert VERSION_RE.match(res.out)
    assert res.err == ""
    created = tmp_path / "cfg.toml"
    assert created.is_file()
    assert not (tmp_path / "XXcfg.toml").exists()
    content = created.read_text()
    assert '  Backend = "gist"\n' in content
    assert '  SnippetFile = "%s/petcfg/snippet.toml"\n' % tmp_path in content


def test_config_flag_tilde_path_creates_config_under_home(tmp_path):
    """``--config ~/new.toml`` resolves against ``$HOME``: the default config
    is created at ``<home>/new.toml`` (never in a literal ``~`` directory)
    and the command itself succeeds."""
    # CATCHES: the tilde-prefix join takes path[2:] ("new.toml") under $HOME
    # - no directory named "~" is ever created in the cwd and the written
    # default config points its SnippetFile at the PET_CONFIG_DIR.
    res = run_pet(["--config", "~/new.toml", "version"], tmp_path=tmp_path,
                  config=None, snippets=None)
    assert res.rc == 0
    assert VERSION_RE.match(res.out)
    assert res.err == ""
    created = tmp_path / "new.toml"
    assert created.is_file()
    assert not (tmp_path / "~").exists()
    content = created.read_text()
    assert '  Backend = "gist"\n' in content
    assert '  SnippetFile = "%s/petcfg/snippet.toml"\n' % tmp_path in content
