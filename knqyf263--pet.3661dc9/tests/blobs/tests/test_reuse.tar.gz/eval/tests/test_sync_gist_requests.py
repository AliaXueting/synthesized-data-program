"""``pet sync`` gist request paths (sync/gist.go GetSnippet /
UploadSnippet / createGist), observed through the CLI.

The offline paths (token validation, the empty-gist-ID short circuit) are
covered by ``test_sync_backends.py``.  The request paths are reached here by
pointing the Go HTTP stack's proxy support at a closed loopback port: the
gist client dials ``https://api.github.com`` through ``$HTTPS_PROXY``, the
local connection is refused, and the wrapped error surfaces on stdout with
exit status 255.  No traffic ever leaves the machine, the port is never
bound, and the recorded messages are byte-stable.
"""

from conftest import run_pet, snippet_block

#: A loopback proxy address with nothing listening behind it: every request
#: pet makes fails immediately with "connection refused".
CLOSED_PROXY = "http://127.0.0.1:1"

PROXY_ENV = {"HTTPS_PROXY": CLOSED_PROXY}

#: The transport-level failure Go reports for the closed proxy.
REFUSED = "proxyconnect tcp: dial tcp 127.0.0.1:1: connect: connection refused"


def gist_config(extra=""):
    """A gist-backend config pointing at ``<tmp>/snippets.toml``."""
    return ('[General]\n'
            '  SnippetFile = "{home}/snippets.toml"\n'
            '  Backend = "gist"\n' + extra)


def test_sync_gist_get_request_error_with_gist_id(tmp_path):
    """A configured gist_id makes GetSnippet issue a real GET
    https://api.github.com/gists/<id> request; through the closed proxy the
    request fails and AutoSync's error is printed on stdout with rc 255."""
    # CATCHES: GetSnippet only short-circuits on an EMPTY gist ID - any
    # configured ID goes through the go-github client, and the error is
    # wrapped as "Failed to get gist" with the full Go http error verb,
    # URL and proxy dial failure quoted verbatim.
    config = gist_config('\n[Gist]\n'
                         '  access_token = "dummy"\n'
                         '  gist_id = "gid42"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="",
                  env=PROXY_ENV)
    assert res.rc == 255
    assert res.out == (
        'Failed to get gist: Get "https://api.github.com/gists/gid42": '
        + REFUSED + "\n")
    assert res.err == ""


def test_sync_gist_env_token_reaches_get_request(tmp_path):
    """$PET_GITHUB_ACCESS_TOKEN alone initializes the gist client far
    enough to issue the GET request for a configured gist_id - the same
    request failure as with a config token."""
    # CATCHES: getGithubAccessToken falls back to the env variable when the
    # config token is empty, and the resulting client still performs the
    # remote lookup instead of the empty-snippet shortcut.
    config = gist_config('\n[Gist]\n  gist_id = "gid42"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="",
                  env=dict(PROXY_ENV, PET_GITHUB_ACCESS_TOKEN="dummy"))
    assert res.rc == 255
    assert res.out == (
        'Failed to get gist: Get "https://api.github.com/gists/gid42": '
        + REFUSED + "\n")
    assert res.err == ""


def test_sync_gist_upload_creates_gist_request_error(tmp_path):
    """A non-empty local snippet file is newer than the zero remote
    timestamp, so AutoSync uploads: with no gist_id set UploadSnippet
    CREATEs a gist, and the POST request through the closed proxy fails
    with the double-wrapped error message."""
    # CATCHES: the upload branch is chosen purely by mtime comparison
    # (local file vs the zero UpdatedAt of the empty-ID snippet), and an
    # empty gist_id means "create" (POST /gists) - "Failed to upload
    # snippet" wrapping "Failed to create gist" wrapping the dial error.
    config = gist_config('\n[Gist]\n  access_token = "dummy"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config,
                  snippets=snippet_block("s", "echo hi"), env=PROXY_ENV)
    assert res.rc == 255
    assert res.out == (
        'Failed to upload snippet: Failed to create gist: '
        'Post "https://api.github.com/gists": ' + REFUSED + "\n")
    assert res.err == ""


def test_sync_unknown_backend_falls_back_to_gist_client(tmp_path):
    """A Backend value other than gitlab/ghe is not rejected: NewSyncClient
    falls through to the gist client, which accepts the env token and
    completes the offline empty-ID sync with "Already up-to-date"."""
    # CATCHES: only the exact strings "gitlab" and "ghe" select the other
    # backends - any typo (here "bitbucket") silently means gist.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  Backend = "bitbucket"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="",
                  env={"PET_GITHUB_ACCESS_TOKEN": "dummy"})
    assert res.rc == 0
    assert res.out == "Already up-to-date\n"
    assert res.err == ""


def test_sync_upload_reports_local_parse_error(tmp_path):
    """Before uploading, upload() reloads the local snippet file: a
    non-empty file with invalid TOML aborts with "Failed to load the local
    snippets" wrapping go-toml's parser error, without any network access."""
    # CATCHES: AutoSync picks the upload branch by file size/mtime alone;
    # the content is only validated inside upload()'s Load(false), so the
    # parse error (not a request error) is what surfaces.
    config = gist_config('\n[Gist]\n  access_token = "dummy"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config,
                  snippets="this is not toml {{{")
    assert res.rc == 255
    assert res.out == (
        "Failed to load the local snippets: failed to parse snippet file. "
        '(1, 6): was expecting token =, but got "is" instead\n')
    assert res.err == ""
