"""``pet new`` snippet creation, rewritten from the native suite's
``cmd/new_test.go`` (TestScan family, TestNew_SnippetCreationWithSnippetDirectory)
and ``snippet/snippet_test.go`` TestSave (exact saved TOML bytes).

All prompt interactions run over a pipe, which is how the reference binary
behaves when stdin is not a terminal: the readline-backed prompt emits no
prompt text, and a second prompt started after the first one consumed the
pipe sees EOF (the first readline instance buffers ahead and its buffer is
discarded on close).
"""

import pytest

from conftest import run_pet, snippet_block, make_script, EDITOR_SCRIPT

EDITOR_CONFIG = ('[General]\n'
                 '  SnippetFile = "{home}/snippets.toml"\n'
                 '  Editor = "{home}/editor.sh"\n')


def test_new_with_args_saves_exact_toml_bytes(tmp_path):
    """``pet new "cmd"`` + a description line appends a block with the exact
    encoder layout: leading blank line, Description/Output/Tag/command keys
    indented by two spaces, lowercase multiline "command" key."""
    # CATCHES: mirrors snippet_test.go TestSave byte-for-byte, including the
    # leading "\n" before [[Snippets]] and the field order.
    res = run_pet(["new", "echo 'Hello, World!'"], stdin="Test snippet\n",
                  tmp_path=tmp_path,
                  snippets=snippet_block("existing", "echo old"))
    assert res.rc == 0
    assert res.out == "Command> echo 'Hello, World!'\n"
    assert (tmp_path / "snippets.toml").read_text() == (
        snippet_block("existing", "echo old")
        + '\n[[Snippets]]\n'
        '  Description = "Test snippet"\n'
        '  Output = ""\n'
        '  Tag = []\n'
        '  command = "echo \'Hello, World!\'"\n'
    )


def test_new_echoes_command_and_quotes_toml_values(tmp_path):
    """Double quotes and backslashes in the command are escaped when the
    snippet is encoded to TOML."""
    # CATCHES: go-toml escapes '"' and '\\' in basic strings; a re-impl
    # writing raw values would corrupt the saved file.
    command = 'echo "it\'s" a \\test\\'
    res = run_pet(["new", command], stdin="quote desc\n", tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out == "Command> %s\n" % command
    assert (tmp_path / "snippets.toml").read_text() == (
        '\n[[Snippets]]\n'
        '  Description = "quote desc"\n'
        '  Output = ""\n'
        '  Tag = []\n'
        '  command = "echo \\"it\'s\\" a \\\\test\\\\"\n'
    )


def test_new_joins_multiple_arguments_with_spaces(tmp_path):
    """Positional arguments are joined with single spaces to form the
    command, so ``pet new echo hello world`` stores "echo hello world"."""
    # CATCHES: cmd/new_test.go uses strings.Join(args, " "); argument
    # boundaries other than spaces (e.g. tabs) would be lost.
    res = run_pet(["new", "echo", "hello", "world"], stdin="multi arg\n",
                  tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out == "Command> echo hello world\n"
    assert 'command = "echo hello world"' in (tmp_path / "snippets.toml").read_text()


def test_new_empty_command_argument_is_allowed(tmp_path):
    """A single empty argument still counts as "arguments given": the
    command line is echoed with a trailing space and an empty command is
    saved."""
    # CATCHES: len(args) > 0 decides whether the Command> prompt is skipped,
    # so one empty string argument bypasses the prompt without cancelling.
    res = run_pet(["new", ""], stdin="empty cmd desc\n", tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out == "Command> \n"
    assert (tmp_path / "snippets.toml").read_text() == (
        '\n[[Snippets]]\n'
        '  Description = "empty cmd desc"\n'
        '  Output = ""\n'
        '  Tag = []\n'
        '  command = ""\n'
    )


def test_new_duplicate_description_is_rejected(tmp_path):
    """A description that already exists in the main snippet file aborts
    with "snippet [...] already exists" and saves nothing."""
    # CATCHES: the duplicate check compares against snippets loaded from the
    # main file only, before the new block is appended.
    res = run_pet(["new", "echo dup"], stdin="existing\n", tmp_path=tmp_path,
                  snippets=snippet_block("existing", "echo old"))
    assert res.rc == 255
    assert res.out == "Command> echo dup\nsnippet [existing] already exists\n"
    assert (tmp_path / "snippets.toml").read_text() == snippet_block(
        "existing", "echo old")


def test_new_duplicate_check_ignores_snippet_dirs(tmp_path):
    """The duplicate check loads the main file only, so a description that
    exists solely in a snippet-directory file is accepted."""
    # CATCHES: _new calls snippets.Load(false) - directory snippets must not
    # block creation even though list would show them.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SnippetDirs = ["{home}/inc"]\n')
    files = {"inc/a.toml": snippet_block("dir only", "echo dir")}
    res = run_pet(["new", "echo fine"], stdin="dir only\n", tmp_path=tmp_path,
                  config=config, snippets=snippet_block("main", "echo m"),
                  files=files)
    assert res.rc == 0
    saved = (tmp_path / "snippets.toml").read_text()
    assert 'Description = "dir only"\n  Output = ""\n  Tag = []\n  command = "echo fine"' in saved


def test_new_skips_blank_description_lines_and_trims_spaces(tmp_path):
    """Blank lines at the description prompt are ignored (the prompt loops)
    and surrounding whitespace is trimmed from the accepted answer."""
    # CATCHES: cmd/new_test.go TestScan_EmptyStringWithoutAllowEmpty - empty
    # input re-prompts instead of cancelling; only EOF cancels.
    res = run_pet(["new", "echo t"], stdin="\n\n   padded desc   \n",
                  tmp_path=tmp_path)
    assert res.rc == 0
    assert 'Description = "padded desc"' in (tmp_path / "snippets.toml").read_text()


def test_new_eof_at_description_prompt_cancels(tmp_path):
    """EOF at the description prompt cancels: "canceled" is printed to
    stdout and the process exits 255, leaving the snippet file untouched."""
    # CATCHES: the CanceledError from scan() propagates through cobra's
    # RunE to fmt.Println(err) in Execute() - stdout, not stderr.
    res = run_pet(["new", "echo hi"], stdin="\n", tmp_path=tmp_path)
    assert res.rc == 255
    assert res.out == "Command> echo hi\ncanceled\n"
    assert (tmp_path / "snippets.toml").read_text() == ""


def test_new_tag_prompt_sees_eof_after_description(tmp_path):
    """With ``--tag`` and both lines piped at once, the tag prompt still
    gets EOF: the first readline instance buffered the whole pipe and its
    buffer is discarded when it closes, so the run cancels."""
    # CATCHES: pins the readline buffering behavior of the reference binary:
    # sequential prompts cannot both be fed from one piped stdin write.
    res = run_pet(["new", "-t", "echo x"], stdin="mydesc\nmytag\n",
                  tmp_path=tmp_path)
    assert res.rc == 255
    assert res.out == "Command> echo x\ncanceled\n"
    assert (tmp_path / "snippets.toml").read_text() == ""


def test_new_multiline_mode_cancels_at_description(tmp_path):
    """``-m`` reads the command until a double blank line, then asks for
    the description - which sees EOF from the same pipe, so the run cancels
    and nothing is saved."""
    # CATCHES: the multiline state machine consumes the whole pipe; the
    # follow-up description prompt then cancels with rc 255.
    res = run_pet(["new", "-m"], stdin="line one\nline two\n\n\n",
                  tmp_path=tmp_path)
    assert res.rc == 255
    assert res.out == "canceled\n"
    assert (tmp_path / "snippets.toml").read_text() == ""


def test_new_missing_snippet_file_errors_before_prompting(tmp_path):
    """When the configured snippet file does not exist, ``pet new`` fails
    with the snippet-file-not-found error before printing the Command> line."""
    # CATCHES: Load(false) runs before any prompt, so a missing file wins
    # over the interactive flow.
    config = '[General]\n  SnippetFile = "{home}/gone.toml"\n'
    res = run_pet(["new", "echo x"], stdin="d\n", tmp_path=tmp_path,
                  config=config, snippets=None)
    assert res.rc == 255
    assert res.out == (
        "snippet file not found. %s/gone.toml\n"
        "Please run 'pet configure' and provide a correct file path, or remove this\n"
        "if you only want to provide snippetdirs instead\n" % tmp_path
    )


def test_new_with_dirs_writes_main_file_only(tmp_path):
    """A new snippet is appended to the main snippet file even when snippet
    directories are configured; the directory files stay untouched."""
    # CATCHES: cmd/new_test.go TestNew_SnippetCreationWithSnippetDirectory -
    # the save must not spread or overwrite directory snippets.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SnippetDirs = ["{home}/inc1", "{home}/inc2"]\n')
    dir_a = snippet_block("dir1 snippet 1", "echo dir1-1")
    dir_b = snippet_block("dir2 snippet 1", "echo dir2-1")
    files = {"inc1/s.toml": dir_a, "inc2/s.toml": dir_b}
    main = snippet_block("main snippet 1", "echo main1")
    res = run_pet(["new", "echo new command"], stdin="brand new\n",
                  tmp_path=tmp_path, config=config, snippets=main, files=files)
    assert res.rc == 0
    saved = (tmp_path / "snippets.toml").read_text()
    assert saved.count("[[Snippets]]") == 2
    assert 'command = "echo new command"' in saved
    assert (tmp_path / "inc1" / "s.toml").read_text() == dir_a
    assert (tmp_path / "inc2" / "s.toml").read_text() == dir_b


def test_new_editor_flag_appends_empty_snippet_and_opens_editor(tmp_path):
    """``pet new -e`` appends an empty snippet block, then opens the
    configured editor at line (existing line count + 3)."""
    # CATCHES: the start line is computed from the pre-append line count, so
    # a 12-line file opens at +15, and the appended block has empty strings.
    make_script(tmp_path, "editor.sh",
                EDITOR_SCRIPT.format(log=str(tmp_path / "editor.log")))
    main = (
        snippet_block("one", "echo 1")
        + snippet_block("two", "echo 2")
    )
    assert main.count("\n") == 12
    res = run_pet(["new", "-e"], tmp_path=tmp_path,
                  config=EDITOR_CONFIG.format(home=tmp_path), snippets=main)
    assert res.rc == 0
    assert res.out == ""
    assert (tmp_path / "editor.log").read_text() == (
        "EDITOR: [+15] [%s/snippets.toml]\n" % tmp_path)
    assert (tmp_path / "snippets.toml").read_text() == main + (
        '\n[[Snippets]]\n'
        '  Description = ""\n'
        '  Output = ""\n'
        '  Tag = []\n'
        '  command = ""\n'
    )


def test_new_editor_flag_ignored_when_command_given(tmp_path):
    """With a positional command, ``-e`` never triggers the editor: the
    normal description prompt runs and the snippet is saved directly."""
    # CATCHES: the editor branch lives in the "no arguments" arm of _new, so
    # "pet new -e cmd" must behave exactly like "pet new cmd".
    make_script(tmp_path, "editor.sh",
                EDITOR_SCRIPT.format(log=str(tmp_path / "editor.log")))
    res = run_pet(["new", "-e", "echo x"], stdin="d\n", tmp_path=tmp_path,
                  config=EDITOR_CONFIG.format(home=tmp_path))
    assert res.rc == 0
    assert not (tmp_path / "editor.log").exists()
    assert 'command = "echo x"' in (tmp_path / "snippets.toml").read_text()


def test_new_autosync_failure_still_saves_snippet(tmp_path):
    """With Gist auto_sync enabled and no access token, the snippet is
    saved first and then the sync failure surfaces with exit 255."""
    # CATCHES: Save() runs before AutoSync(), so the file must contain the
    # new snippet even though the command reports the sync error.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '\n[Gist]\n'
              '  auto_sync = true\n')
    res = run_pet(["new", "echo auto"], stdin="autosync desc\n",
                  tmp_path=tmp_path, config=config)
    assert res.rc == 255
    assert res.out == (
        "Command> echo auto\n"
        "Failed to initialize API client: Failed to initialize Gist client: "
        "access_token is empty.\n"
        "Go https://github.com/settings/tokens/new and create access_token "
        "(only need \"gist\" scope).\n"
        "Write access_token in config file (pet configure) or export "
        "$PET_GITHUB_ACCESS_TOKEN.\n"
        "\t\t\n"
    )
    saved = (tmp_path / "snippets.toml").read_text()
    assert 'Description = "autosync desc"' in saved
