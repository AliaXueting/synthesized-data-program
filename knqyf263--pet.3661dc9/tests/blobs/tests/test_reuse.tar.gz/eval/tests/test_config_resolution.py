"""Config resolution and default-config generation (config/config.go,
cmd/root.go initConfig), rewritten from the native suite's config-loading
behavior plus path_test.go expansion cases.

Recorded facts: an unreadable config aborts with the raw error on STDERR and
exit 1 (initConfig), while runtime command errors print to stdout with exit
255 (RootCmd.Execute).  The default config template embeds the default
snippet path ``<config dir>/snippet.toml`` and an editor chosen as
$EDITOR > sensible-editor (if on PATH) > vim.
"""

import pytest

from conftest import run_pet

#: Full default config recorded from the reference binary with EDITOR unset
#: and a PATH containing no sensible-editor (falls back to vim).  The only
#: variable part is the snippet file path inside the config directory.
DEFAULT_CONFIG_TEMPLATE = '''\
[GHEGist]
  Public = false
  access_token = ""
  auto_sync = false
  base_url = ""
  file_name = ""
  gist_id = ""
  upload_url = ""

[General]
  Backend = "gist"
  Cmd = []
  Color = false
  Column = 40
  Editor = "vim"
  Format = "[$description]: $command $tags"
  SelectCmd = "fzf --ansi --layout=reverse --border --height=90% --pointer=* --cycle --prompt=Snippets:"
  SnippetDirs = []
  SnippetFile = "{cfgdir}/snippet.toml"
  SortBy = ""

[Gist]
  Public = false
  access_token = ""
  auto_sync = false
  file_name = "pet-snippet.toml"
  gist_id = ""

[GitLab]
  ID = ""
  Url = ""
  Visibility = "private"
  access_token = ""
  auto_sync = false
  file_name = "pet-snippet.toml"
  skip_ssl = false
'''


def narrow_path(tmp_path):
    """A PATH containing only an ``sh`` symlink: no sensible-editor, so the
    default config's editor detection falls back to vim."""
    bindir = tmp_path / "bin"
    bindir.mkdir(exist_ok=True)
    sh = bindir / "sh"
    if not sh.exists():
        sh.symlink_to("/bin/sh")
    return {"PATH": str(bindir)}


def test_default_config_is_created_with_full_template(tmp_path):
    """A missing config file is created with the complete default template,
    together with an empty snippet file next to it."""
    # CATCHES: the generated config lists every key (including the fzf
    # SelectCmd default and Gist file_name "pet-snippet.toml") and starts
    # with a blank line before [GHEGist].
    res = run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
                  env=narrow_path(tmp_path))
    assert res.rc == 0
    cfgdir = tmp_path / "petcfg"
    expected = DEFAULT_CONFIG_TEMPLATE.replace("{cfgdir}", str(cfgdir))
    assert (cfgdir / "config.toml").read_text() == "\n" + expected
    assert (cfgdir / "snippet.toml").read_text() == ""


def test_default_config_respects_editor_env(tmp_path):
    """$EDITOR wins over the sensible-editor/vim detection when the default
    config is generated."""
    # CATCHES: config.Load reads EDITOR from the environment before probing
    # for sensible-editor on PATH.
    env = narrow_path(tmp_path)
    env["EDITOR"] = "nano"
    run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
            env=env)
    content = (tmp_path / "petcfg" / "config.toml").read_text()
    assert '  Editor = "nano"\n' in content


def test_default_config_falls_back_to_vim_without_sensible_editor(tmp_path):
    """With EDITOR unset and no sensible-editor reachable through PATH, the
    generated config uses vim."""
    # CATCHES: the fallback probes "command -v sensible-editor" through the
    # child's PATH - a re-implementation hardcoding sensible-editor (the
    # value on this host's default PATH) breaks here.
    run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
            env=narrow_path(tmp_path))
    content = (tmp_path / "petcfg" / "config.toml").read_text()
    assert '  Editor = "vim"\n' in content


def test_default_config_uses_sensible_editor_when_on_path(tmp_path):
    """With the normal system PATH (which provides sensible-editor but no
    EDITOR), the generated config picks sensible-editor."""
    # CATCHES: detection order is $EDITOR > sensible-editor > vim.
    run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None)
    content = (tmp_path / "petcfg" / "config.toml").read_text()
    assert '  Editor = "sensible-editor"\n' in content


def test_default_config_dir_created_recursively(tmp_path):
    """A PET_CONFIG_DIR with missing parents is created recursively
    (MkdirAll) before the config is written."""
    # CATCHES: GetDefaultConfigDir creates the whole directory chain, so a
    # nested PET_CONFIG_DIR works on first run.
    nested = tmp_path / "a" / "b" / "c"
    res = run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
                  env={"PET_CONFIG_DIR": str(nested)})
    assert res.rc == 0
    assert res.out.startswith("pet version ")
    assert (nested / "config.toml").exists()
    assert (nested / "snippet.toml").exists()


def test_default_config_without_pet_config_dir_uses_home(tmp_path):
    """Without PET_CONFIG_DIR the default config lands in
    $HOME/.config/pet/ (created with mode 0700 dirs)."""
    # CATCHES: the XDG-style default path is $HOME-based on unix; PET_CONFIG_DIR
    # is only consulted when actually set.
    res = run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
                  pet_config_dir=False)
    assert res.rc == 0
    cfg = tmp_path / ".config" / "pet" / "config.toml"
    assert cfg.exists()
    assert (tmp_path / ".config" / "pet" / "snippet.toml").exists()
    content = cfg.read_text()
    assert ('SnippetFile = "%s"\n'
            % (tmp_path / ".config" / "pet" / "snippet.toml")) in content


def test_config_flag_reads_custom_path(tmp_path):
    """``--config`` points at an arbitrary TOML file; the snippet file it
    references is used for the run."""
    # CATCHES: --config replaces both the PET_CONFIG_DIR and the $HOME
    # default resolution.
    custom = tmp_path / "myconf.toml"
    custom.write_text('[General]\n  SnippetFile = "{home}/snippets.toml"\n'
                      .replace("{home}", str(tmp_path)))
    (tmp_path / "snippets.toml").write_text(
        '\n[[Snippets]]\n'
        '  Description = "from custom config"\n'
        '  Output = ""\n'
        '  Tag = []\n'
        '  command = "echo custom"\n')
    res = run_pet(["--config", str(custom), "list"], tmp_path=tmp_path,
                  config=None, snippets=None)
    assert res.rc == 0
    assert res.out == (
        "Description: from custom config\n"
        "    Command: echo custom\n"
        "        Tag: \n"
        "------------------------------\n"
    )


def test_config_flag_missing_file_is_created(tmp_path):
    """``--config newfile.toml`` creates the default config at that path
    (but the default snippet file still goes to the default config dir)."""
    # CATCHES: the created config's SnippetFile is always
    # GetDefaultConfigDir()/snippet.toml regardless of where the config
    # itself was created.
    target = tmp_path / "created.toml"
    res = run_pet(["--config", str(target), "version"], tmp_path=tmp_path,
                  config=None, snippets=None, pet_config_dir=False)
    assert res.rc == 0
    assert target.exists()
    content = target.read_text()
    assert ('SnippetFile = "%s"\n'
            % (tmp_path / ".config" / "pet" / "snippet.toml")) in content


def test_invalid_config_toml_prints_parser_error_to_stderr(tmp_path):
    """An unparsable config aborts during initialization: the go-toml error
    goes to STDERR without a trailing newline and the process exits 1."""
    # CATCHES: config load errors use a different channel (stderr) and exit
    # code (1) than command errors (stdout, 255).
    res = run_pet(["list"], tmp_path=tmp_path, config="not valid toml [[",
                  snippets=None)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == '(1, 5): was expecting token =, but got "valid" instead'


def test_config_path_is_directory_error(tmp_path):
    """``--config`` pointing at a directory fails with Go's
    "is a directory" read error on stderr and exit 1."""
    # CATCHES: os.Stat succeeds for a directory so creation is skipped and
    # the subsequent ReadFile fails.
    res = run_pet(["--config", str(tmp_path), "list"], tmp_path=tmp_path,
                  config=None, snippets=None)
    assert res.rc == 1
    assert res.err == "read %s: is a directory" % tmp_path


def test_pet_config_dir_blocked_by_file_error(tmp_path):
    """A PET_CONFIG_DIR whose parent is a regular file cannot be created;
    the mkdir error is reported on stderr with exit 1."""
    # CATCHES: GetDefaultConfigDir wraps the MkdirAll failure as
    # "cannot create directory: <mkdir error>".
    blocker = tmp_path / "blocker"
    blocker.write_text("")
    res = run_pet(["version"], tmp_path=tmp_path, config=None, snippets=None,
                  env={"PET_CONFIG_DIR": str(blocker / "sub")})
    assert res.rc == 1
    assert res.err == ("cannot create directory: mkdir %s: not a directory"
                       % blocker)


def test_version_reports_config_error_first(tmp_path):
    """cobra's OnInitialize runs the config load before the command body:
    ``pet version`` with a broken config never prints the version."""
    # CATCHES: initialization order - even commands that never touch
    # snippets fail on a broken config.
    res = run_pet(["version"], tmp_path=tmp_path, config="broken [ [[",
                  snippets=None)
    assert res.rc == 1
    assert res.out == ""
    assert res.err == '(1, 8): was expecting token =, but got "[" instead'


def test_unknown_command_bypasses_config_error(tmp_path):
    """An unknown subcommand is rejected by cobra before initConfig runs,
    so the config error never appears."""
    # CATCHES: argument validation precedes initialization - the unknown
    # command message wins over the broken config.
    res = run_pet(["frobnicate"], tmp_path=tmp_path, config="broken [ [[",
                  snippets=None)
    assert res.rc == 255
    assert res.out == 'unknown command "frobnicate" for "pet"\n'
    assert res.err == ""
