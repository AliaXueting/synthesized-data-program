"""Black-box CLI test helpers for the pet reference binary (test_reuse module).

Every test in this suite drives the reference implementation exclusively
through its command line interface, mirroring behaviors mined from the
repository's native Go test suite (``snippet/snippet_test.go``,
``snippet/util_test.go``, ``cmd/new_test.go``, ``cmd/exec_test.go``,
``dialog/params_test.go``, ``path/path_test.go`` and friends).

The child process environment is fully pinned so host settings (``TERM``,
``NO_COLOR``, ``EDITOR``, leftover ``PET_*_ACCESS_TOKEN`` variables) cannot
change the recorded behavior, and every run happens inside the test's
``tmp_path``.
"""

import os
import socket
import ssl
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

#: Per-run timeout: the whole suite must stay well under the harness budget.
TIMEOUT_SECONDS = 10

#: Minimal, deterministic environment for the child process.  ``HOME`` and
#: ``PET_CONFIG_DIR`` are filled in per run with the test's ``tmp_path`` so
#: that neither the default ``$HOME/.config/pet`` config nor any host token
#: can leak into a run.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "TZ": "UTC",
    "NO_COLOR": "1",
    "TERM": "dumb",
}

#: Standard config written to ``<tmp>/petcfg/config.toml`` unless a test
#: overrides it.  ``{home}`` is replaced with the test's ``tmp_path``.
DEFAULT_CONFIG = """\
[General]
  SnippetFile = "{home}/snippets.toml"
  SelectCmd = "cat"
"""


class RunResult:
    """Decoded stdout/stderr/exit-code triple of one reference binary run."""

    __slots__ = ("rc", "out", "err")

    def __init__(self, proc):
        self.rc = proc.returncode
        self.out = proc.stdout.decode("utf-8", errors="surrogateescape")
        self.err = proc.stderr.decode("utf-8", errors="surrogateescape")


def _write_files(tmp_path, files):
    """Write ``files`` (relative path -> text/bytes) underneath ``tmp_path``."""
    for rel, content in (files or {}).items():
        target = tmp_path / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(
            content.encode("utf-8") if isinstance(content, str) else content)


def _child_env(tmp_path, extra, pet_config_dir):
    """Build the pinned child environment, merging case-specific overrides."""
    env = dict(BASE_ENV)
    if tmp_path is not None:
        env["HOME"] = str(tmp_path)
        if pet_config_dir:
            env["PET_CONFIG_DIR"] = str(tmp_path / "petcfg")
    env.update(extra or {})
    # Coverage instrumentation hook: the pipeline rebuilds the reference with
    # ``go build -cover`` and points ``GOCOVERDIR`` at a counter directory.
    # Pass the variable through so reference-source coverage is measured.
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env.update({"GOCOVERDIR": value})
    return env


def run_pet(args, stdin="", tmp_path=None, config=DEFAULT_CONFIG,
            snippets="", files=None, env=None, timeout=TIMEOUT_SECONDS,
            pet_config_dir=True, cwd=None):
    """Run the reference pet binary as a black box and decode its output.

    :param args:            CLI arguments; numbers are converted with ``str()``.
    :param stdin:           text (or bytes) fed to the child's standard input.
    :param tmp_path:        working directory and ``HOME`` for the child.
    :param config:          TOML text written to ``<tmp>/petcfg/config.toml``
                            (``{home}`` is replaced with ``tmp_path``);
                            ``None`` leaves the config directory absent so the
                            binary creates its default config.
    :param snippets:        content of ``<tmp>/snippets.toml``; ``None``
                            skips creating the file entirely.
    :param files:           mapping of relative path -> text/bytes written
                            under ``tmp_path`` before the child starts.
    :param env:             extra environment variables overriding the base.
    :param pet_config_dir:  whether to point ``PET_CONFIG_DIR`` at
                            ``<tmp>/petcfg`` (False exercises the default
                            ``$HOME/.config/pet`` resolution).
    :returns:               :class:`RunResult` with ``rc``, ``out`` and ``err``.
    """
    if tmp_path is not None:
        _write_files(tmp_path, files)
        if config is not None:
            cfg = tmp_path / "petcfg" / "config.toml"
            cfg.parent.mkdir(parents=True, exist_ok=True)
            cfg.write_text(config.replace("{home}", str(tmp_path)))
        if snippets is not None:
            (tmp_path / "snippets.toml").write_text(snippets)
    argv = [os.environ["PROGRAMGYM_EXECUTABLE"]] + [str(a) for a in args]
    proc = subprocess.run(
        argv,
        input=stdin.encode("utf-8") if isinstance(stdin, str) else stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd if cwd is not None else tmp_path) if tmp_path is not None else None,
        env=_child_env(tmp_path, env, pet_config_dir),
        timeout=timeout,
    )
    return RunResult(proc)


def make_script(tmp_path, name, body):
    """Write an executable helper script under ``tmp_path`` and return its path.

    Used for deterministic ``SelectCmd``/``Editor`` substitutes: the recorded
    scripts log the arguments pet hands them and emit a fixed selection.
    """
    script = tmp_path / name
    script.write_text(body)
    script.chmod(0o755)
    return script


#: Selector script: records its argv to ``args.log`` (one ``[arg]`` per
#: argument) and prints a single fixed selection line on stdout.
SELECTOR_SCRIPT = """\
#!/bin/sh
printf 'SEL:' >> "{log}"
for a in "$@"; do printf ' [%s]' "$a" >> "{log}"; done
printf '\\n' >> "{log}"
cat "{selection}"
"""

#: Selector script that additionally tees the formatted snippet text pet pipes
#: into it to ``stdin.log`` before echoing the fixed selection.
TEE_SELECTOR_SCRIPT = """\
#!/bin/sh
printf 'SEL:' >> "{log}"
for a in "$@"; do printf ' [%s]' "$a" >> "{log}"; done
printf '\\n' >> "{log}"
tee "{stdinlog}" > "{selection}"
"""

#: Editor script: records ``EDITOR:<arg> <arg>...`` lines to ``editor.log``.
EDITOR_SCRIPT = """\
#!/bin/sh
printf 'EDITOR:' >> "{log}"
for a in "$@"; do printf ' [%s]' "$a" >> "{log}"; done
printf '\\n' >> "{log}"
"""


def snippet_block(description, command, tag=None, output=""):
    """Render one ``[[Snippets]]`` block the way pet itself saves them.

    Mirrors the exact encoder output of ``snippet.Save`` (field order,
    two-space indentation, ``command`` lowercase key) so snippet fixtures stay
    byte-identical to files the reference binary writes.
    """
    if tag is None:
        tag_text = "[]"
    else:
        tag_text = "[" + ", ".join('"%s"' % t for t in tag) + "]"
    return (
        "\n[[Snippets]]\n"
        '  Description = "%s"\n'
        '  Output = "%s"\n'
        "  Tag = %s\n"
        '  command = "%s"\n'
        % (description, output, tag_text, command)
    )


class _StubHandler(BaseHTTPRequestHandler):
    """HTTP handler answering from a fixed routing table, recording requests.

    Used as the base class of the per-test handler created by
    :class:`LoopbackStub`; ``routes``, ``requests``, ``header`` and ``label``
    are installed on that subclass, never on this class.
    """

    protocol_version = "HTTP/1.1"

    def _respond(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length).decode() if length else ""
        self.requests.append("%s %s %s=%s body=%s" % (
            self.command, self.path, self.label,
            self.headers.get(self.header), body))
        status, payload = self.routes.get(
            "%s %s" % (self.command, self.path),
            (404, '{"message": "no route"}'))
        payload = payload.encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    do_GET = do_POST = do_PUT = do_PATCH = _respond

    def log_message(self, *args):
        pass


class LoopbackStub:
    """Loopback HTTP API stub bound to an OS-assigned port.

    The sync backends take their API base URL from the pet config, so a stub
    on 127.0.0.1 drives their request paths hermetically: no DNS lookup, no
    external host, nothing shared between tests.  ``routes`` maps
    ``"METHOD /path"`` to a ``(status, body)`` pair (any unrouted path answers
    404); every request the binary sends is appended to :attr:`requests` as
    ``"METHOD /path <label>=<header value> body=<request body>"`` with
    ``header``/``label`` picking the credential header to record.
    """

    def __init__(self, routes, header, label):
        handler = type("Handler", (_StubHandler,),
                       {"routes": routes, "requests": [], "header": header,
                        "label": label})
        self.requests = handler.requests
        self._handler = handler
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.base_url = "http://127.0.0.1:%d" % self._server.server_address[1]
        threading.Thread(target=self._server.serve_forever, daemon=True).start()

    def close(self):
        self._server.shutdown()
        self._server.server_close()


def _api_github_tls_context(tmp_path):
    """Throwaway CA plus a server certificate for ``api.github.com``.

    Returns ``(ca_path, ssl_context)``.  The Go runtime builds its root pool
    from ``$SSL_CERT_FILE``, so a child pointed at the CA file verifies a
    certificate issued under ``tmp_path`` for a host it would otherwise only
    trust through the public GitHub infrastructure.
    """
    import datetime

    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    now = datetime.datetime.now(datetime.UTC)
    ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, u"pet-mitm-ca")])
    ca_cert = (x509.CertificateBuilder()
               .subject_name(ca_name).issuer_name(ca_name)
               .public_key(ca_key.public_key())
               .serial_number(x509.random_serial_number())
               .not_valid_before(now - datetime.timedelta(days=1))
               .not_valid_after(now + datetime.timedelta(days=1))
               .add_extension(x509.BasicConstraints(ca=True, path_length=None),
                              critical=True)
               .sign(ca_key, hashes.SHA256()))
    leaf_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    leaf_cert = (x509.CertificateBuilder()
                 .subject_name(x509.Name([x509.NameAttribute(
                     NameOID.COMMON_NAME, u"api.github.com")]))
                 .issuer_name(ca_name)
                 .public_key(leaf_key.public_key())
                 .serial_number(x509.random_serial_number())
                 .not_valid_before(now - datetime.timedelta(days=1))
                 .not_valid_after(now + datetime.timedelta(days=1))
                 .add_extension(x509.SubjectAlternativeName(
                     [x509.DNSName(u"api.github.com")]), critical=False)
                 .sign(ca_key, hashes.SHA256()))
    ca_path = tmp_path / "mitm-ca.pem"
    cert_path = tmp_path / "mitm-cert.pem"
    key_path = tmp_path / "mitm-key.pem"
    ca_path.write_bytes(ca_cert.public_bytes(serialization.Encoding.PEM))
    cert_path.write_bytes(leaf_cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(leaf_key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption()))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(str(cert_path), str(key_path))
    return str(ca_path), context


class GithubProxyStub:
    """Loopback CONNECT proxy answering as ``https://api.github.com``.

    The gist backend's API URL is hard-coded, so - unlike the GitLab and GHE
    backends - it cannot be pointed at a plain loopback server through the
    config.  The stub instead interposes on the transport: the Go HTTP stack
    honors ``$HTTPS_PROXY`` for https URLs by sending a CONNECT request, and
    honors ``$SSL_CERT_FILE`` for the root pool verifying the tunnel's
    certificate.  Each connection's CONNECT is answered with 200, upgraded to
    TLS with a certificate for api.github.com issued by a throwaway CA (all
    key material written under ``tmp_path``), and then served with the same
    routing table/recording scheme as :class:`LoopbackStub`: ``routes`` maps
    ``"METHOD /path"`` to ``(status, body)`` and requests land in
    :attr:`requests` as ``"METHOD /path auth=<Authorization header>"``.

    Nothing leaves 127.0.0.1 (no DNS, no external host) and the CA is never
    reused across tests.  Merge :attr:`env` into :func:`run_pet`'s ``env``
    argument to route a child process through the proxy.
    """

    def __init__(self, tmp_path, routes):
        ca_path, tls_context = _api_github_tls_context(tmp_path)
        handler = type("Handler", (_StubHandler,),
                       {"routes": routes, "requests": [], "header": "Authorization",
                        "label": "auth"})
        self.requests = handler.requests
        self._handler = handler
        self._tls_context = tls_context
        self._closed = False
        self._listener = socket.socket()
        self._listener.bind(("127.0.0.1", 0))
        self._listener.listen(8)
        self.env = {
            "HTTPS_PROXY": "http://127.0.0.1:%d"
                           % self._listener.getsockname()[1],
            "SSL_CERT_FILE": ca_path,
        }
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        self._listener.settimeout(0.2)
        while not self._closed:
            try:
                conn, _ = self._listener.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            threading.Thread(target=self._tunnel, args=(conn,),
                             daemon=True).start()

    def _tunnel(self, conn):
        """Answer one CONNECT request, then serve HTTP over the TLS tunnel."""
        try:
            head = b""
            while b"\r\n\r\n" not in head:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                head += chunk
            conn.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")
            tls = self._tls_context.wrap_socket(conn, server_side=True)
        except OSError:
            try:
                conn.close()
            except OSError:
                pass
            return
        try:
            self._handler(tls, ("127.0.0.1", 0), None)
        except Exception:
            pass
        finally:
            try:
                tls.close()
            except OSError:
                pass

    def close(self):
        self._closed = True
        try:
            self._listener.close()
        except OSError:
            pass
