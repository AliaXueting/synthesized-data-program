"""``pet edit`` / ``pet configure`` editor launching (cmd/edit.go,
cmd/configure.go, cmd/util_unix.go editFile).

The configured Editor is invoked through ``sh -c "<editor> +<line> <path>"``
- recorded here with a capture script that logs its exact argv.
"""

from conftest import run_pet, snippet_block, make_script, EDITOR_SCRIPT


def editor_config(editor="{home}/editor.sh", extra=""):
    return ('[General]\n'
            '  SnippetFile = "{home}/snippets.toml"\n'
            '  Editor = "%s"\n%s' % (editor, extra))


def write_editor(tmp_path):
    make_script(tmp_path, "editor.sh",
                EDITOR_SCRIPT.format(log=str(tmp_path / "editor.log")))


def test_edit_opens_main_snippet_file_at_line_zero(tmp_path):
    """Without snippet dirs, edit opens the main snippet file directly with
    the " +0" start line appended to the editor command."""
    # CATCHES: editFile builds "<editor> +<line> <path>" as one shell
    # command; the line argument is "+0" (not "0" or "+1").
    write_editor(tmp_path)
    res = run_pet(["edit"], tmp_path=tmp_path,
                  config=editor_config().format(home=tmp_path),
                  snippets=snippet_block("s", "echo 1"))
    assert res.rc == 0
    assert res.out == ""
    assert (tmp_path / "editor.log").read_text() == (
        "EDITOR: [+0] [%s/snippets.toml]\n" % tmp_path)


def test_edit_with_dirs_selects_file_via_selector(tmp_path):
    """With snippet dirs configured, edit first pipes the snippet list
    through SelectCmd and opens the file the selected snippet came from."""
    # CATCHES: the selected formatted line maps back to the snippet's
    # Filename, so the editor receives the directory file, not the main one.
    write_editor(tmp_path)
    (tmp_path / "inc").mkdir()
    (tmp_path / "inc" / "other.toml").write_text(
        snippet_block("from dir", "echo dir"))
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  Editor = "{home}/editor.sh"\n'
              '  SnippetDirs = ["{home}/inc"]\n'
              '  SelectCmd = "grep from"\n')
    res = run_pet(["edit"], tmp_path=tmp_path, config=config,
                  snippets=snippet_block("main", "echo main"))
    assert res.rc == 0
    assert (tmp_path / "editor.log").read_text() == (
        "EDITOR: [+0] [%s/inc/other.toml]\n" % tmp_path)


def test_edit_with_empty_editor_runs_plus_zero_as_command(tmp_path):
    """An empty Editor still builds " +0 <path>", which sh fails to execute;
    the exec error "exit status 127" surfaces on stdout with rc 255."""
    # CATCHES: editFile does not validate the editor; the shell error and
    # Go's exit status string both leak through.
    res = run_pet(["edit"], tmp_path=tmp_path,
                  config=editor_config(editor="").format(home=tmp_path),
                  snippets=snippet_block("s", "echo 1"))
    assert res.rc == 255
    assert res.out == "exit status 127\n"
    assert res.err == "sh: 1: +0: not found\n"


def test_edit_with_missing_editor_binary(tmp_path):
    """An Editor naming a nonexistent binary yields the same exit-status
    error, with sh naming the missing command on stderr."""
    # CATCHES: the child's stderr passes through pet's stderr unchanged.
    res = run_pet(["edit"], tmp_path=tmp_path,
                  config=editor_config(editor="no-such-editor").format(
                      home=tmp_path),
                  snippets=snippet_block("s", "echo 1"))
    assert res.rc == 255
    assert res.out == "exit status 127\n"
    assert res.err == "sh: 1: no-such-editor: not found\n"


def test_configure_opens_config_file(tmp_path):
    """``pet configure`` opens the resolved config file path (PET_CONFIG_DIR
    or --config), not the snippet file."""
    # CATCHES: configure uses the `configFile` variable resolved in
    # initConfig, so with PET_CONFIG_DIR set it edits that directory's
    # config.toml.
    write_editor(tmp_path)
    res = run_pet(["configure"], tmp_path=tmp_path,
                  config=editor_config().format(home=tmp_path))
    assert res.rc == 0
    assert (tmp_path / "editor.log").read_text() == (
        "EDITOR: [+0] [%s/petcfg/config.toml]\n" % tmp_path)


def test_edit_unchanged_content_skips_autosync(tmp_path):
    """With auto_sync enabled, an editor that leaves the snippet file
    untouched makes edit return cleanly (the sync is skipped)."""
    # CATCHES: edit compares contentBefore/contentAfter; equal content
    # short-circuits before AutoSync even though auto_sync is true.
    config = editor_config(extra='\n[Gist]\n  auto_sync = true\n'
                     ).format(home=tmp_path)
    write_editor(tmp_path)
    res = run_pet(["edit"], tmp_path=tmp_path, config=config,
                  snippets=snippet_block("s", "echo 1"))
    assert res.rc == 0
    assert res.out == ""
    assert (tmp_path / "editor.log").read_text() == (
        "EDITOR: [+0] [%s/snippets.toml]\n" % tmp_path)


def test_edit_changed_content_triggers_autosync_error(tmp_path):
    """An editor that modifies the snippet file lets edit proceed to
    AutoSync, which fails without a token after the file was changed."""
    # CATCHES: only a content CHANGE reaches the sync call - the error
    # proves the before/after comparison ran and the sync branch fired.
    body = EDITOR_SCRIPT.format(log=str(tmp_path / "editor.log")) + (
        'echo "# touched" >> "$2"\n')
    make_script(tmp_path, "editor.sh", body)
    config = editor_config(extra='\n[Gist]\n  auto_sync = true\n'
                     ).format(home=tmp_path)
    res = run_pet(["edit"], tmp_path=tmp_path, config=config,
                  snippets=snippet_block("s", "echo 1"))
    assert res.rc == 255
    assert res.out == (
        "Failed to initialize API client: Failed to initialize Gist client: "
        "access_token is empty.\n"
        "Go https://github.com/settings/tokens/new and create access_token "
        '(only need "gist" scope).\n'
        "Write access_token in config file (pet configure) or export "
        "$PET_GITHUB_ACCESS_TOKEN.\n"
        "\t\t\n"
    )
    assert "# touched" in (tmp_path / "snippets.toml").read_text()
