"""Snippet ordering (snippet.Order) and tag filtering (FilterByTags vs the
cmd/util.go tag filter), rewritten from snippet_test.go TestFilterByTags and
the Order() switch in snippet/snippet.go.

Sort semantics recorded from the reference binary:
``command``/``+command`` sort DESCENDING (the Less functions use ">"),
the ``-`` prefix reverses to ascending, ``-recency`` reverses file order and
any unrecognized value keeps file (recency) order.
"""

import pytest

from conftest import run_pet, snippet_block

#: Three snippets whose command/description/output all sort differently, so
#: every SortBy mode produces a distinguishable order.
SORT_SNIPPETS = (
    snippet_block("zebra", "echo z", output="out-z")
    + snippet_block("apple", "echo a", output="out-a")
    + snippet_block("mango", "echo m", output="out-m")
)


def sorted_config(sort_by):
    return ('[General]\n'
            '  SnippetFile = "{home}/snippets.toml"\n'
            '  SortBy = "%s"\n' % sort_by)


def list_names(tmp_path, sort_by, snippets=SORT_SNIPPETS):
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path,
                  config=sorted_config(sort_by), snippets=snippets)
    assert res.rc == 0
    return [l.split(" : ")[0].rstrip() for l in res.out.splitlines()]


@pytest.mark.parametrize("sort_by, expected", [
    # default / unrecognized values keep file (recency) order
    ("", ["zebra", "apple", "mango"]),
    ("recency", ["zebra", "apple", "mango"]),
    ("bogus", ["zebra", "apple", "mango"]),
    # "command" and "+command" sort descending (Less uses ">")
    ("command", ["zebra", "mango", "apple"]),
    ("+command", ["zebra", "mango", "apple"]),
    ("-command", ["apple", "mango", "zebra"]),
    ("description", ["zebra", "mango", "apple"]),
    ("+description", ["zebra", "mango", "apple"]),
    ("-description", ["apple", "mango", "zebra"]),
    ("output", ["zebra", "mango", "apple"]),
    ("+output", ["zebra", "mango", "apple"]),
    ("-output", ["apple", "mango", "zebra"]),
    # "-recency" reverses the load order
    ("-recency", ["mango", "apple", "zebra"]),
])
def test_sort_by_modes(tmp_path, sort_by, expected):
    """Every documented SortBy value orders the snippet list as recorded;
    the bare forms sort descending because Less() compares with ">"."""
    # CATCHES: "command"/"description"/"output" sort DESCENDING - a
    # re-implementation using natural ascending order fails these cases.
    assert list_names(tmp_path, sort_by) == expected


TAG_SNIPPETS = (
    snippet_block("one", "echo one", tag=["alpha"])
    + snippet_block("two", "echo two", tag=["beta", "gamma"])
    + "\n[[Snippets]]\n"
      '  Description = "three"\n'
      '  Output = ""\n'
      '  command = "echo three"\n'
)


def test_list_tags_flag_matches_any_of_comma_list(tmp_path):
    """``pet list -t a,b`` splits on commas and keeps snippets tagged with
    ANY of the values (snippet.FilterByTags)."""
    # CATCHES: list's -t is comma-separated with OR semantics - unlike
    # search/exec/clip whose -t matches one exact tag string.
    res = run_pet(["list", "-t", "alpha,beta", "--oneline"], tmp_path=tmp_path,
                  snippets=TAG_SNIPPETS)
    assert res.rc == 0
    names = [l.split(" : ")[0].rstrip() for l in res.out.splitlines()]
    assert names == ["one", "two"]


def test_list_tags_flag_skips_untagged_snippets(tmp_path):
    """Untagged snippets never match a tag filter (FilterByTags skips
    snippets whose Tag slice is empty): only the tagged "one" and "two"
    rows are printed, in load order."""
    # CATCHES: the "three" snippet has no Tag key at all, so even a filter
    # listing every used tag must not include it - the exact two-line
    # oneline rendering is pinned here.
    res = run_pet(["list", "-t", "alpha,gamma", "--oneline"], tmp_path=tmp_path,
                  snippets=TAG_SNIPPETS)
    assert res.rc == 0
    assert res.out == (
        "one" + " " * 37 + " : echo one\n"
        "two" + " " * 37 + " : echo two\n"
    )
    assert res.err == ""


def test_list_tags_no_match_outputs_nothing(tmp_path):
    """A tag filter matching no snippet yields empty output and exit 0,
    while a filter matching one tag on the same file still renders that
    snippet."""
    # CATCHES: filtering to zero snippets is not an error - the command
    # still succeeds silently instead of failing or printing a placeholder.
    res = run_pet(["list", "-t", "zzz"], tmp_path=tmp_path,
                  snippets=TAG_SNIPPETS)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""

    res = run_pet(["list", "-t", "beta", "--oneline"], tmp_path=tmp_path,
                  snippets=TAG_SNIPPETS)
    assert res.rc == 0
    assert res.out == "two" + " " * 37 + " : echo two\n"


def test_search_tag_matches_single_exact_tag(tmp_path):
    """``pet search -t`` matches the flag value against one whole tag
    (cmd/util.go filter), so a comma list matches nothing."""
    # CATCHES: search/exec/clip do NOT split the tag on commas - "-t
    # red,blue" matches no snippet while list would match both.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "cat"\n')
    res = run_pet(["search", "-t", "alpha,beta"], tmp_path=tmp_path,
                  config=config, snippets=TAG_SNIPPETS)
    assert res.rc == 0
    assert res.out == ""

    res = run_pet(["search", "-t", "alpha"], tmp_path=tmp_path,
                  config=config, snippets=TAG_SNIPPETS)
    assert res.rc == 0
    assert res.out == "echo one"


def test_list_unsorted_keeps_load_order(tmp_path):
    """With no SortBy configured the snippets appear in file order across
    main and directory files (recency = load order)."""
    # CATCHES: recency is implemented as load order, not mtime - directory
    # snippets follow the main file's in the order walked.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SnippetDirs = ["{home}/inc"]\n')
    files = {"inc/extra.toml": snippet_block("from dir", "echo dir")}
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path, config=config,
                  snippets=snippet_block("first", "echo 1"), files=files)
    assert res.rc == 0
    names = [l.split(" : ")[0].rstrip() for l in res.out.splitlines()]
    assert names == ["first", "from dir"]
