"""``pet sync`` GitHub Enterprise gist request paths (sync/ghe.go) through the CLI.

Like the GitLab client, the GHE gist client takes its base URL from the pet
config (``[GHEGist] base_url``), so a stub HTTP server bound to an
OS-assigned loopback port drives its whole request surface hermetically.  The
two backends differ in instructive ways that these tests pin:

* the GHE client authenticates with an OAuth2 ``Authorization: Bearer`` header
  (the GitLab client uses ``PRIVATE-TOKEN``),
* ``GetSnippet`` guards its 404 check with ``res != nil``, so a transport
  failure is a clean wrapped error - unlike the GitLab client, which
  segfaults on the nil response,
* the upload body is a github.Gist: description "description", the configured
  ``public`` flag and a files map keyed by the configured file name,
* update uses PATCH on the gist id (wrapped twice on failure) while create
  POSTs to the collection and prints the returned gist id.
"""

import json

from conftest import LoopbackStub, run_pet, snippet_block

#: Token written into the config file; recorded as "Bearer <token>".
TOKEN = "ghp-test"

#: A well-formed local snippet file (byte-identical to pet's own encoder).
LOCAL_SNIPPETS = snippet_block("s", "echo hi")

#: Raw content served inside the remote gist's files map.
REMOTE_SNIPPETS = snippet_block("remote", "echo remote")


def gist_json(content, updated_at="2020-01-02T03:04:05Z", gist_id="gid42",
              file_name="snippets.toml"):
    """A gist metadata response whose files map holds one named file."""
    return json.dumps({
        "id": gist_id, "updated_at": updated_at,
        "files": {file_name: {"filename": file_name, "content": content}},
    })


#: Standard [GHEGist] section: token, matching file name, gist id.
WITH_ID = ('  access_token = "%s"\n'
           '  file_name = "snippets.toml"\n'
           '  gist_id = "gid42"\n' % TOKEN)

#: [GHEGist] section without a gist id: GetSnippet short-circuits, so an
#: existing local file is uploaded as a NEW gist.
NO_ID = ('  access_token = "%s"\n'
         '  file_name = "snippets.toml"\n' % TOKEN)


class GHEStub(LoopbackStub):
    """Loopback GHE gist API recording the Authorization header."""

    def __init__(self, routes):
        super().__init__(routes, header="Authorization", label="auth")

    def config(self, ghe):
        """Config text pointing the sync client at this stub."""
        return ('[General]\n'
                '  SnippetFile = "{home}/snippets.toml"\n'
                '  Backend = "ghe"\n'
                '\n[GHEGist]\n'
                '  base_url = "%s"\n%s' % (self.base_url, ghe))


def run_sync(stub, tmp_path, ghe, snippets="", env=None):
    """Run ``pet sync`` against ``stub``; returns (result, request lines)."""
    try:
        res = run_pet(["sync"], tmp_path=tmp_path, config=stub.config(ghe),
                      snippets=snippets, env=env)
        return res, list(stub.requests)
    finally:
        stub.close()


def gist_body(content, public="false"):
    """The exact JSON body pet sends when uploading a gist.

    Key order and escaping match Go's encoding of the github.Gist struct as
    recorded from the reference binary, including the trailing newline that
    go-github's json.Encoder appends to every request body (the GitLab client
    marshals without one).
    """
    body = {"description": "description", "public": json.loads(public),
            "files": {"snippets.toml": {"content": content}}}
    return json.dumps(body, separators=(",", ":")) + "\n"


def test_sync_ghe_downloads_newer_remote_gist(tmp_path):
    """An empty local file forces the download branch: one GET of the gist
    prints "Download success" and stores the content of the gist file whose
    name matches the configured file_name."""
    # CATCHES: the gist content comes from the files map entry named by the
    # config's file_name (not from a second request), authenticated with an
    # OAuth2 Bearer token.
    stub = GHEStub({"GET /gists/gid42": [200, gist_json(REMOTE_SNIPPETS)]})
    res, requests = run_sync(stub, tmp_path, WITH_ID, snippets="")
    assert res.rc == 0
    assert res.out == stub.base_url + "\nDownload success\n"
    assert res.err == ""
    assert requests == ["GET /gists/gid42 auth=Bearer %s body=" % TOKEN]
    assert (tmp_path / "snippets.toml").read_text() == REMOTE_SNIPPETS


def test_sync_ghe_missing_remote_file_is_empty_error(tmp_path):
    """A gist whose files map has no entry named like the configured
    file_name yields "<file_name> is empty" with exit status 255."""
    # CATCHES: the file lookup walks gist.Files comparing the FILE's name
    # with the config value, so a gist holding other.toml is treated as
    # empty rather than downloaded.
    other = gist_json("x", file_name="other.toml")
    stub = GHEStub({"GET /gists/gid42": [200, other]})
    res, requests = run_sync(stub, tmp_path, WITH_ID, snippets="")
    assert res.rc == 255
    assert res.out == stub.base_url + "\nsnippets.toml is empty\n"
    assert res.err == ""
    assert requests == ["GET /gists/gid42 auth=Bearer %s body=" % TOKEN]


def test_sync_ghe_not_found_is_wrapped_as_missing_gist(tmp_path):
    """A 404 for the gist GET is wrapped as "No gist ID (<id>)" with the
    go-github error text, which ends with an empty errors slice "[]". """
    # CATCHES: GetSnippet special-cases status 404 (guarded by a nil check on
    # the response) and interpolates the configured gist id, not a number.
    stub = GHEStub({"GET /gists/gid42": [404, '{"message": "Not Found"}']})
    res, _ = run_sync(stub, tmp_path, WITH_ID, snippets="")
    assert res.rc == 255
    assert res.out == (
        stub.base_url + "\nNo gist ID (gid42): GET %s/gists/gid42: "
        "404 Not Found []\n" % stub.base_url)
    assert res.err == ""


def test_sync_ghe_other_errors_report_request_details(tmp_path):
    """Any non-404 failure of the gist GET keeps the generic "Failed to get
    gist" wrap, quoting method, URL, status and the API's message."""
    # CATCHES: only 404 takes the missing-gist branch; 401 keeps the request
    # details and the trailing empty "[]" of go-github's error formatting.
    stub = GHEStub({"GET /gists/gid42": [401, '{"message": "Bad credentials"}']})
    res, _ = run_sync(stub, tmp_path, WITH_ID, snippets="")
    assert res.rc == 255
    assert res.out == (
        stub.base_url + "\nFailed to get gist: GET %s/gists/gid42: "
        "401 Bad credentials []\n" % stub.base_url)
    assert res.err == ""


def test_sync_ghe_transport_failure_is_a_clean_error(tmp_path):
    """A connection refused to a never-bound loopback port is a wrapped error
    with exit status 255 - the GHE client nil-checks the response, so unlike
    the GitLab backend it does NOT crash on a transport failure."""
    # CATCHES: ghe.go guards the 404 check with "res != nil", so a dial
    # failure surfaces as "Failed to get gist: Get ...: dial tcp ...:
    # connection refused" on stdout instead of a SIGSEGV panic.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  Backend = "ghe"\n'
              '\n[GHEGist]\n'
              '  access_token = "tok"\n'
              '  base_url = "http://127.0.0.1:1"\n'
              '  file_name = "snippets.toml"\n'
              '  gist_id = "gid42"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="")
    assert res.rc == 255
    assert res.out == (
        "http://127.0.0.1:1\n"
        'Failed to get gist: Get "http://127.0.0.1:1/gists/gid42": '
        "dial tcp 127.0.0.1:1: connect: connection refused\n")
    assert res.err == ""


def test_sync_ghe_upload_edits_existing_gist(tmp_path):
    """A local file newer than the remote gist is uploaded with PATCH to
    gists/<id>, carrying the re-encoded local TOML under the configured file
    name and public=false."""
    # CATCHES: the update branch PATCHes the gist id (it does not POST a new
    # gist), and the body's files key comes from the config's file_name.
    stub = GHEStub({"GET /gists/gid42": [200, gist_json(REMOTE_SNIPPETS)],
                    "PATCH /gists/gid42": [200, gist_json(REMOTE_SNIPPETS)]})
    res, requests = run_sync(stub, tmp_path, WITH_ID, snippets=LOCAL_SNIPPETS)
    assert res.rc == 0
    assert res.out == stub.base_url + "\nUpload success\n"
    assert res.err == ""
    assert requests == [
        "GET /gists/gid42 auth=Bearer %s body=" % TOKEN,
        "PATCH /gists/gid42 auth=Bearer %s body=%s"
        % (TOKEN, gist_body(LOCAL_SNIPPETS)),
    ]


def test_sync_ghe_update_failure_is_triple_wrapped(tmp_path):
    """A failing PATCH surfaces three prefixes deep: "Failed to upload
    snippet" wrapping "Failed to update gist" wrapping "Failed to edit gist"
    before the go-github request error."""
    # CATCHES: updateGist and UploadSnippet both wrap, so the message nests
    # twice - one level deeper than the create failure - and names PATCH.
    stub = GHEStub({"GET /gists/gid42": [200, gist_json(REMOTE_SNIPPETS)],
                    "PATCH /gists/gid42": [401, '{"message": "Bad credentials"}']})
    res, _ = run_sync(stub, tmp_path, WITH_ID, snippets=LOCAL_SNIPPETS)
    assert res.rc == 255
    assert res.out == (
        stub.base_url + "\nFailed to upload snippet: Failed to update gist: "
        "Failed to edit gist: PATCH %s/gists/gid42: 401 Bad credentials []\n"
        % stub.base_url)
    assert res.err == ""


def test_sync_ghe_create_prints_new_gist_id(tmp_path):
    """Without a gist id the upload branch creates a new gist with POST
    gists/ (no GET at all) and prints the returned id before the success
    message."""
    # CATCHES: the empty gist id short-circuits GetSnippet, the local file's
    # mtime beats the zero remote timestamp, and the id from the response is
    # echoed as "Gist ID: <string id>".
    stub = GHEStub({"POST /gists": [200, gist_json("x", gist_id="newgid")]})
    res, requests = run_sync(stub, tmp_path, NO_ID, snippets=LOCAL_SNIPPETS)
    assert res.rc == 0
    assert res.out == stub.base_url + "\nGist ID: newgid\nUpload success\n"
    assert res.err == ""
    assert requests == [
        "POST /gists auth=Bearer %s body=%s" % (TOKEN, gist_body(LOCAL_SNIPPETS)),
    ]


def test_sync_ghe_create_failure_is_wrapped(tmp_path):
    """A failing create POST is wrapped by createGist and upload only (two
    levels, not three) and names POST and the gists collection URL."""
    # CATCHES: createGist returns its error unwrapped by UploadSnippet's
    # create branch, so the message has one prefix fewer than the update
    # failure and no gist id appears in the URL.
    stub = GHEStub({"POST /gists": [401, '{"message": "Bad credentials"}']})
    res, _ = run_sync(stub, tmp_path, NO_ID, snippets=LOCAL_SNIPPETS)
    assert res.rc == 255
    assert res.out == (
        stub.base_url + "\nFailed to upload snippet: Failed to create gist: "
        "POST %s/gists: 401 Bad credentials []\n" % stub.base_url)
    assert res.err == ""


def test_sync_ghe_public_flag_reaches_request_body(tmp_path):
    """The configured public flag is forwarded as the JSON boolean in the
    create request body; the default is false."""
    # CATCHES: Public comes straight from config.Conf.GHEGist.Public with no
    # defaulting to true, and Go emits a real JSON boolean, not a string.
    stub = GHEStub({"POST /gists": [200, gist_json("x", gist_id="newgid")]})
    res, requests = run_sync(stub, tmp_path, NO_ID + '  public = true\n',
                             snippets=LOCAL_SNIPPETS)
    assert res.rc == 0
    assert res.out == stub.base_url + "\nGist ID: newgid\nUpload success\n"
    assert requests[0] == ("POST /gists auth=Bearer %s body=%s"
                           % (TOKEN, gist_body(LOCAL_SNIPPETS, public="true")))


def test_sync_ghe_token_from_environment_reaches_header(tmp_path):
    """With no access_token in the config, $PET_GHE_ACCESS_TOKEN alone
    initializes the client and is sent as the Bearer token."""
    # CATCHES: getGHEAccessToken falls back to the environment variable, and
    # the token travels as "Authorization: Bearer <token>".
    stub = GHEStub({"POST /gists": [200, gist_json("x", gist_id="newgid")]})
    res, requests = run_sync(stub, tmp_path, '  file_name = "snippets.toml"\n',
                             snippets=LOCAL_SNIPPETS,
                             env={"PET_GHE_ACCESS_TOKEN": "envtok"})
    assert res.rc == 0
    assert res.out == stub.base_url + "\nGist ID: newgid\nUpload success\n"
    assert requests == [
        "POST /gists auth=Bearer envtok body=%s" % gist_body(LOCAL_SNIPPETS),
    ]


def test_sync_ghe_missing_base_url_cannot_post(tmp_path):
    """Without a base_url the enterprise client keeps an empty base URL, so
    the create POST fails locally with Go's "unsupported protocol scheme"
    error before any connection is attempted."""
    # CATCHES: NewGHEGistClient only overrides the base URL when the config
    # value is non-empty, and the client construction error is ignored - the
    # failure only appears once a request is actually made.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  Backend = "ghe"\n'
              '\n[GHEGist]\n'
              '  access_token = "tok"\n'
              '  file_name = "snippets.toml"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config,
                  snippets=LOCAL_SNIPPETS)
    assert res.rc == 255
    assert res.out == (
        'Failed to upload snippet: Failed to create gist: Post "/gists": '
        'unsupported protocol scheme ""\n')
    assert res.err == ""
