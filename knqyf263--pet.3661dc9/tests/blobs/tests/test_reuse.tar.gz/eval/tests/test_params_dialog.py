"""Parameter placeholders (dialog/params.go SearchForParams regex) observed
through the CLI.

Rewritten from the native suite's ``dialog/params_test.go``
(TestSearchForParams fixtures).  The parsed keys/values are only consumed by
the gocui TUI, which cannot start without a terminal - so the black-box
oracle is whether ``pet search`` (without ``--raw``) detects ANY parameter in
the selected command:

* params found  -> GenerateParamsLayout -> gocui/tcell fails -> Go panic,
  rc 2, stderr starting with "failed to initialize tcell screen: terminal
  not cursor addressable" (recorded with the pinned TERM=dumb; tcell reports
  the dumb terminfo as not cursor addressable)
* params absent -> the raw command is printed, rc 0
"""

import re

import pytest

from conftest import run_pet, snippet_block

HEAD_CONFIG = ('[General]\n'
               '  SnippetFile = "{home}/snippets.toml"\n'
               '  SelectCmd = "head -n 1"\n')

#: First bytes of every recorded param-dialog panic: a log line and a panic
#: line carrying the same tcell screen error, then the bare tab line Go's
#: panic printer emits before the goroutine dump.  Only the timestamp varies.
PANIC_PREFIX = re.compile(
    r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} "
    r"failed to initialize tcell screen: terminal not cursor addressable\n"
    r"panic: failed to initialize tcell screen: terminal not cursor addressable\n"
    r"\t\n"
    r"\n"
    r"goroutine 1 \[running\]:\n")


def run_search(tmp_path, toml_command):
    """Run ``pet search`` over one snippet whose ``command`` value is the
    given (already TOML-escaped) text."""
    return run_pet(["search"], tmp_path=tmp_path, config=HEAD_CONFIG,
                   snippets=snippet_block("p", toml_command))


#: Commands (as they appear between the quotes of the TOML ``command`` value)
#: that SearchForParams must classify as parameterized.  Mirrors every
#: TestSearchForParams case yielding at least one parameter; ``\\n`` is a TOML
#: escape so the loaded command contains a real newline, and ``\\"`` embeds a
#: literal double quote.
PARAMETERIZED_COMMANDS = [
    "echo <a=1> <b> hello",
    "<a=1> <b> <c=3>",
    # three distinct params spread over a newline (TestSearchForParams_WithNewline)
    "<a=1> <b> hello\\n<c=3>",
    "example_function --flag=<param=Lots of Bananas>",
    "<a=1 <b> hello",
    "<a=1<b>hello",
    "cat <<EOF > <file=path/to/file>\\nEOF",
    "<a=1> <a=2> <a=3>",
    'echo \\"<param=Hello == World!===>\\"',
    'echo \\"<param=|_Hello_||_Hello world_||_How are you?_|> <second=Hello>, <third>\\"',
    "plain < param> leading space",
    "cmd <a=1><b=2>",
    "cmd <a=1> <a=2 <a=3>",
    "<file=~/.bashrc>",
    "a <x\\nb> c",
    "<a=>",
    # same key repeated across lines plus a new key
    "<a=1> <a=2> <a=3>\\n<b=4>",
    # broken bracket group on the second line still leaves <b=4> matchable
    "<a=1> <a=2> <a=3 \\n<b=4>",
    # unclosed trailing group does not invalidate earlier matches
    "<a=1> <a=2> <a=3>\\n<b=4",
    # two distinct params inside quoted arguments
    'curl -X POST \\"<host=http://localhost:9200>/<index>\\" -H \'Content-Type: application/json\'',
]


@pytest.mark.parametrize("toml_command", PARAMETERIZED_COMMANDS)
def test_search_panics_into_param_dialog_for_parameterized_commands(
        tmp_path, toml_command):
    """A selected command containing parameter placeholders opens the param
    dialog; without a terminal gocui fails and the process panics with
    exit status 2 and empty stdout."""
    # CATCHES: SearchForParams' regex `<([^<>]*[^\\s])>` accepts spaces and
    # newlines inside the brackets as long as the last char is not
    # whitespace - all these recorded commands must reach the dialog.
    res = run_search(tmp_path, toml_command)
    assert res.rc == 2
    assert res.out == ""
    assert PANIC_PREFIX.match(res.err)
    assert "github.com/knqyf263/pet/dialog.GenerateParamsLayout" in res.err


#: Commands whose bracket groups fail the parameter regex: printed verbatim.
PLAIN_COMMANDS = [
    "no params here",
    "plain <param > trailing space",
    "plain <>",
    "plain <param unclosed",
    "angle 1 < 2 and 3 > 4",
    # whitespace right before ">" disqualifies a group even with a default
    "plain <param=with trailing space >",
    # a ">" without any "<" is never a group
    "100% > done",
    "just > angle",
]


@pytest.mark.parametrize("command", PLAIN_COMMANDS)
def test_search_skips_dialog_when_no_parameter_matches(tmp_path, command):
    """Commands whose bracket groups fail the parameter regex (trailing
    whitespace before ">", empty group, unclosed bracket, plain math
    comparison, a bare ">") print the command verbatim with exit 0."""
    # CATCHES: the regex demands a non-space character right before ">",
    # so "<param >" and "< 2 and 3 >" are NOT parameters and must not
    # open the dialog.
    res = run_search(tmp_path, command)
    assert res.rc == 0
    assert res.out == command
    assert res.err == ""


def test_search_raw_outputs_parameterized_command_verbatim(tmp_path):
    """``--raw`` bypasses the parameter dialog: the selected command is
    printed with its placeholders untouched and no trailing newline."""
    # CATCHES: raw mode skips SearchForParams entirely, so even a command
    # full of <param=...> tokens never opens the TUI.
    res = run_pet(["search", "--raw"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippet_block("p", "echo <greeting=hello> <name>"))
    assert res.rc == 0
    assert res.out == "echo <greeting=hello> <name>"
    assert res.err == ""


def test_clip_raw_skips_param_dialog(tmp_path):
    """``pet clip --raw`` also bypasses the dialog and fails afterwards on
    the missing clipboard utility, not on the TUI."""
    # CATCHES: clip shares filter()'s raw flag; without it the same snippet
    # would panic with rc 2 before ever reaching the clipboard call.
    res = run_pet(["clip", "--raw"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippet_block("p", "echo <greeting=hello>"))
    assert res.rc == 255
    assert res.out.startswith("No clipboard utilities available.")


def test_exec_has_no_raw_flag(tmp_path):
    """``pet exec`` does not offer --raw: an unknown flag is rejected with
    exit 255 before anything runs."""
    # CATCHES: only search and clip register --raw; exec always parses
    # parameters for a single selection (and would panic on a TTY-less
    # param dialog).
    res = run_pet(["exec", "--raw"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippet_block("p", "echo x"))
    assert res.rc == 255
    assert res.out == "unknown flag: --raw\n"


def test_multiple_selections_skip_param_dialog(tmp_path):
    """Parameters are only searched when exactly one line is selected; with
    ``SelectCmd = cat`` selecting all lines the joined commands are printed
    even if they contain placeholders."""
    # CATCHES: filter() only calls SearchForParams when len(lines) == 1, so
    # a multi-line selection sidesteps the dialog entirely.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "cat"\n')
    snippets = (
        snippet_block("p1", "echo <a=1> first")
        + snippet_block("p2", "echo <b=2> second")
    )
    res = run_pet(["search"], tmp_path=tmp_path, config=config,
                  snippets=snippets)
    assert res.rc == 0
    assert res.out == "echo <a=1> first; echo <b=2> second"
    assert res.err == ""


def test_unmatched_selection_line_yields_empty_command(tmp_path):
    """A selector line that matches no formatted snippet maps to the zero
    SnippetInfo, so search prints the empty command (exit 0) - while the
    real formatted line for the same snippet still selects its command."""
    # CATCHES: the formatted-text map lookup returns a zero value instead of
    # erroring, so a bogus selection silently selects nothing.
    snippets = snippet_block("p", "echo x")
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "head -n 1"\n')
    res = run_pet(["search"], tmp_path=tmp_path, config=config,
                  snippets=snippets)
    assert res.rc == 0
    assert res.out == "echo x"

    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  SelectCmd = "echo bogus-selection-line"\n')
    res = run_pet(["search"], tmp_path=tmp_path, config=config,
                  snippets=snippets)
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""


def test_param_detection_ignores_placeholders_in_description(tmp_path):
    """SearchForParams inspects the selected snippet's COMMAND, not the
    formatted line - a description full of placeholders never opens the
    dialog while a plain command is echoed back."""
    # CATCHES: filter() looks up snippetTexts[line].Command before calling
    # SearchForParams; matching against the displayed text (which contains
    # the description) would wrongly open the dialog here.
    snippets = snippet_block("run <a=1> now", "echo hi")
    res = run_pet(["search"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippets)
    assert res.rc == 0
    assert res.out == "echo hi"
    assert res.err == ""


def test_search_tag_filter_can_select_parameterized_command(tmp_path):
    """``-t`` narrows the snippet list before the selector runs, so tagging
    makes the parameterized snippet the only (single) selection and the
    dialog opens - while the other tag still selects the plain command."""
    # CATCHES: the tag filter runs before SearchForParams, and the selected
    # line count is computed after filtering - one remaining snippet with
    # params still panics into the dialog.
    snippets = (
        snippet_block("plain", "echo plain", tag=["alpha"])
        + snippet_block("paramed", "echo <x=1>", tag=["beta"])
    )
    res = run_pet(["search", "-t", "beta"], tmp_path=tmp_path,
                  config=HEAD_CONFIG, snippets=snippets)
    assert res.rc == 2
    assert res.out == ""
    assert PANIC_PREFIX.match(res.err)

    res = run_pet(["search", "-t", "alpha"], tmp_path=tmp_path,
                  config=HEAD_CONFIG, snippets=snippets)
    assert res.rc == 0
    assert res.out == "echo plain"
    assert res.err == ""


def test_exec_panics_into_param_dialog(tmp_path):
    """``pet exec`` has no --raw escape: a single selected parameterized
    command opens the dialog and panics on the TTY-less screen with the
    exec frames on the goroutine stack."""
    # CATCHES: exec always calls filter(..., raw=false), so parameterized
    # snippets break exec the same way as search - the recorded stack shows
    # cmd._execute -> cmd.filter -> dialog.GenerateParamsLayout.
    res = run_pet(["exec"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippet_block("p", "echo <a=1>"))
    assert res.rc == 2
    assert res.out == ""
    assert PANIC_PREFIX.match(res.err)
    assert "github.com/knqyf263/pet/dialog.GenerateParamsLayout" in res.err
    assert "github.com/knqyf263/pet/cmd.filter" in res.err
    assert "github.com/knqyf263/pet/cmd._execute" in res.err


def test_clip_panics_into_param_dialog_without_raw(tmp_path):
    """``pet clip`` without --raw also parses parameters: the dialog opens
    before any clipboard access and panics with the clip frame on the
    stack."""
    # CATCHES: clip's RunE reaches filter(..., flag.Raw) with raw=false by
    # default, so the TUI failure precedes the "No clipboard utilities"
    # error that --raw would produce.
    res = run_pet(["clip"], tmp_path=tmp_path, config=HEAD_CONFIG,
                  snippets=snippet_block("p", "echo <a=1>"))
    assert res.rc == 2
    assert res.out == ""
    assert PANIC_PREFIX.match(res.err)
    assert "github.com/knqyf263/pet/dialog.GenerateParamsLayout" in res.err
    assert "github.com/knqyf263/pet/cmd.clip" in res.err
