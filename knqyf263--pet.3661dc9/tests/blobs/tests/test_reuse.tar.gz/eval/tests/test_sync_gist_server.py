"""``pet sync`` gist request paths (sync/gist.go), observed through the CLI.

The gist backend is the only one whose API URL cannot be configured - it is
hard-coded to ``https://api.github.com``.  These tests nevertheless drive its
whole request surface hermetically by interposing on the transport instead of
the URL: a loopback proxy (:class:`GithubProxyStub` in conftest.py) accepts
the Go HTTP stack's CONNECT request for ``api.github.com:443`` (pet honors
``$HTTPS_PROXY``), answers with a certificate for that host issued by a
throwaway CA under ``tmp_path`` (pet honors ``$SSL_CERT_FILE``), and serves
the routed responses over the tunnel.  Nothing leaves 127.0.0.1, no DNS is
touched, and no key material is shared between tests.

Behaviors pinned here, all recorded from the reference binary:

* authentication is OAuth2 ``Authorization: Bearer <token>`` (the config
  token wins over ``$PET_GITHUB_ACCESS_TOKEN``), and unlike the GitLab and
  GHE clients the gist client echoes nothing to stdout while initializing,
* ``GetSnippet`` reads the snippet content from the gist's ``files`` map
  entry named by the configured ``file_name`` - one GET, no raw request,
* a 404 answer is wrapped as ``No gist ID (<id>)`` while any other failure
  keeps the generic ``Failed to get gist`` wrap quoting go-github's request
  error (method, URL, status, message and the trailing empty errors slice),
* upload PATCHes ``gists/<id>`` to update (triple-wrapped failures) and
  POSTs ``gists`` to create (double-wrapped failures, new id echoed),
* a config that omits ``file_name`` leaves the value EMPTY - the
  ``pet-snippet.toml`` default is only written into auto-created configs.
"""

import calendar
import json
import os

from conftest import GithubProxyStub, run_pet, snippet_block

#: Token written into the config file; recorded as "Bearer <token>".
TOKEN = "ghp-test"

#: A well-formed local snippet file (byte-identical to pet's own encoder).
LOCAL_SNIPPETS = snippet_block("s", "echo hi")

#: Content served inside the remote gist's files map.
REMOTE_SNIPPETS = snippet_block("remote", "echo remote")

#: The hard-coded gist API base URL the reference binary always dials.
API = "https://api.github.com"

#: 2020-01-02T03:04:05Z as an epoch second, for pinning a file's mtime.
PAST_EPOCH = calendar.timegm((2020, 1, 2, 3, 4, 5))

#: Same gist metadata with a far-future timestamp, making the remote strictly
#: newer than any local file written during the test.
FUTURE = "2999-01-01T00:00:00Z"


def gist_json(content, updated_at="2020-01-02T03:04:05Z", gist_id="gid42",
              file_name="snippets.toml"):
    """A gist metadata response whose files map holds one named file."""
    return json.dumps({
        "id": gist_id, "updated_at": updated_at,
        "files": {file_name: {"filename": file_name, "content": content}},
    })


#: Standard [Gist] section: token, matching file name, gist id.
WITH_ID = ('  access_token = "%s"\n'
           '  file_name = "snippets.toml"\n'
           '  gist_id = "gid42"\n' % TOKEN)

#: [Gist] section without a gist id: GetSnippet short-circuits, so a
#: non-empty local file is uploaded as a NEW gist.
NO_ID = ('  access_token = "%s"\n'
         '  file_name = "snippets.toml"\n' % TOKEN)


class GistProxyStub(GithubProxyStub):
    """CONNECT proxy for api.github.com recording the Authorization header."""

    def config(self, gist):
        """Config text selecting the gist backend with this [Gist] section."""
        return ('[General]\n'
                '  SnippetFile = "{home}/snippets.toml"\n'
                '  Backend = "gist"\n'
                '\n[Gist]\n' + gist)


def run_sync(stub, tmp_path, gist, snippets="", env=None):
    """Run ``pet sync`` through ``stub``; returns (result, request lines)."""
    try:
        res = run_pet(["sync"], tmp_path=tmp_path, config=stub.config(gist),
                      snippets=snippets, env=dict(stub.env, **(env or {})))
        return res, list(stub.requests)
    finally:
        stub.close()


def gist_body(content, public="false", file_name="snippets.toml"):
    """The exact JSON body pet sends when uploading a gist.

    Key order and escaping match Go's encoding of the github.Gist struct as
    recorded from the reference binary, including the trailing newline that
    go-github's json.Encoder appends to every request body.
    """
    body = {"description": "description", "public": json.loads(public),
            "files": {file_name: {"content": content}}}
    return json.dumps(body, separators=(",", ":")) + "\n"


def test_sync_gist_downloads_newer_remote(tmp_path):
    """An empty local file forces the download branch: one GET of the gist
    prints "Download success" and stores the content of the gist file whose
    name matches the configured file_name - with no URL echo first."""
    # CATCHES: the gist content comes from the files map entry of the single
    # GET response (no separate raw request), authenticated with an OAuth2
    # Bearer token, and unlike the gitlab/ghe backends nothing is printed
    # during client construction.
    stub = GistProxyStub(tmp_path, {"GET /gists/gid42":
                                    [200, gist_json(REMOTE_SNIPPETS)]})
    res, requests = run_sync(stub, tmp_path, WITH_ID, snippets="")
    assert res.rc == 0
    assert res.out == "Download success\n"
    assert res.err == ""
    assert requests == ["GET /gists/gid42 auth=Bearer %s body=" % TOKEN]
    assert (tmp_path / "snippets.toml").read_text() == REMOTE_SNIPPETS


def test_sync_gist_missing_remote_file_is_empty_error(tmp_path):
    """A gist whose files map has no entry named like the configured
    file_name yields "<file_name> is empty" with exit status 255."""
    # CATCHES: the file lookup walks gist.Files comparing each FILE's name
    # with the config value, so a gist holding other.toml is treated as
    # empty rather than downloaded.
    other = gist_json("x", file_name="other.toml")
    stub = GistProxyStub(tmp_path, {"GET /gists/gid42": [200, other]})
    res, requests = run_sync(stub, tmp_path, WITH_ID, snippets="")
    assert res.rc == 255
    assert res.out == "snippets.toml is empty\n"
    assert res.err == ""
    assert requests == ["GET /gists/gid42 auth=Bearer %s body=" % TOKEN]


def test_sync_gist_not_found_is_wrapped_as_missing_gist(tmp_path):
    """A 404 for the gist GET is wrapped as "No gist ID (<id>)" with the
    go-github error text, which ends with an empty errors slice "[]"."""
    # CATCHES: GetSnippet special-cases status 404 (guarded by a nil check on
    # the response) and interpolates the configured gist id, not a number.
    stub = GistProxyStub(tmp_path, {"GET /gists/gid42":
                                    [404, '{"message": "Not Found"}']})
    res, _ = run_sync(stub, tmp_path, WITH_ID, snippets="")
    assert res.rc == 255
    assert res.out == (
        "No gist ID (gid42): GET %s/gists/gid42: 404 Not Found []\n" % API)
    assert res.err == ""


def test_sync_gist_other_error_reports_request_details(tmp_path):
    """Any non-404 failure of the gist GET keeps the generic "Failed to get
    gist" wrap, quoting method, URL, status and the API's message."""
    # CATCHES: only 404 takes the missing-gist branch; 401 keeps the request
    # details and the trailing empty "[]" of go-github's error formatting.
    stub = GistProxyStub(tmp_path, {"GET /gists/gid42":
                                    [401, '{"message": "Bad credentials"}']})
    res, _ = run_sync(stub, tmp_path, WITH_ID, snippets="")
    assert res.rc == 255
    assert res.out == (
        "Failed to get gist: GET %s/gists/gid42: 401 Bad credentials []\n"
        % API)
    assert res.err == ""


def test_sync_gist_upload_edits_existing_gist(tmp_path):
    """A local file newer than the remote gist is uploaded with PATCH to
    gists/<id>, carrying the re-encoded local TOML under the configured file
    name and public=false."""
    # CATCHES: the update branch PATCHes the gist id (it does not POST a new
    # gist), re-uses the same tunnel for both requests, and the body's files
    # key comes from the config's file_name.
    stub = GistProxyStub(tmp_path, {
        "GET /gists/gid42": [200, gist_json(REMOTE_SNIPPETS)],
        "PATCH /gists/gid42": [200, gist_json(REMOTE_SNIPPETS)],
    })
    res, requests = run_sync(stub, tmp_path, WITH_ID, snippets=LOCAL_SNIPPETS)
    assert res.rc == 0
    assert res.out == "Upload success\n"
    assert res.err == ""
    assert requests == [
        "GET /gists/gid42 auth=Bearer %s body=" % TOKEN,
        "PATCH /gists/gid42 auth=Bearer %s body=%s"
        % (TOKEN, gist_body(LOCAL_SNIPPETS)),
    ]


def test_sync_gist_update_failure_is_triple_wrapped(tmp_path):
    """A failing PATCH surfaces three prefixes deep: "Failed to upload
    snippet" wrapping "Failed to update gist" wrapping "Failed to edit gist"
    before the go-github request error."""
    # CATCHES: updateGist and UploadSnippet both wrap, so the message nests
    # twice - one level deeper than the create failure - and names PATCH.
    stub = GistProxyStub(tmp_path, {
        "GET /gists/gid42": [200, gist_json(REMOTE_SNIPPETS)],
        "PATCH /gists/gid42": [401, '{"message": "Bad credentials"}'],
    })
    res, _ = run_sync(stub, tmp_path, WITH_ID, snippets=LOCAL_SNIPPETS)
    assert res.rc == 255
    assert res.out == (
        "Failed to upload snippet: Failed to update gist: "
        "Failed to edit gist: PATCH %s/gists/gid42: 401 Bad credentials []\n"
        % API)
    assert res.err == ""


def test_sync_gist_create_prints_new_gist_id(tmp_path):
    """Without a gist id the upload branch creates a new gist with POST
    gists/ (no GET at all) and prints the returned id before the success
    message."""
    # CATCHES: the empty gist id short-circuits GetSnippet, the local file's
    # mtime beats the zero remote timestamp, and the id from the response is
    # echoed as "Gist ID: <string id>".
    stub = GistProxyStub(tmp_path, {"POST /gists":
                                    [200, gist_json("x", gist_id="newgid")]})
    res, requests = run_sync(stub, tmp_path, NO_ID, snippets=LOCAL_SNIPPETS)
    assert res.rc == 0
    assert res.out == "Gist ID: newgid\nUpload success\n"
    assert res.err == ""
    assert requests == [
        "POST /gists auth=Bearer %s body=%s"
        % (TOKEN, gist_body(LOCAL_SNIPPETS)),
    ]


def test_sync_gist_create_failure_is_wrapped(tmp_path):
    """A failing create POST is wrapped by createGist and upload only (two
    levels, not three) and names POST and the gists collection URL."""
    # CATCHES: createGist's error is returned unwrapped by UploadSnippet's
    # create branch, so the message has one prefix fewer than the update
    # failure and no gist id appears in the URL.
    stub = GistProxyStub(tmp_path, {"POST /gists":
                                    [401, '{"message": "Bad credentials"}']})
    res, requests = run_sync(stub, tmp_path, NO_ID, snippets=LOCAL_SNIPPETS)
    assert res.rc == 255
    assert res.out == (
        "Failed to upload snippet: Failed to create gist: "
        "POST %s/gists: 401 Bad credentials []\n" % API)
    assert res.err == ""
    assert len(requests) == 1


def test_sync_gist_public_flag_reaches_request_body(tmp_path):
    """The configured public flag is forwarded as the JSON boolean in the
    create request body; the default is false."""
    # CATCHES: Public comes straight from config.Conf.Gist.Public with no
    # defaulting to true, and Go emits a real JSON boolean, not a string.
    stub = GistProxyStub(tmp_path, {"POST /gists":
                                    [200, gist_json("x", gist_id="newgid")]})
    res, requests = run_sync(stub, tmp_path, NO_ID + '  public = true\n',
                             snippets=LOCAL_SNIPPETS)
    assert res.rc == 0
    assert res.out == "Gist ID: newgid\nUpload success\n"
    assert requests[0] == ("POST /gists auth=Bearer %s body=%s"
                           % (TOKEN, gist_body(LOCAL_SNIPPETS, public="true")))


def test_sync_gist_token_from_environment_reaches_header(tmp_path):
    """With no access_token in the config, $PET_GITHUB_ACCESS_TOKEN alone
    initializes the client and is sent as the Bearer token."""
    # CATCHES: getGithubAccessToken falls back to the environment variable,
    # and the token travels as "Authorization: Bearer <token>".
    stub = GistProxyStub(tmp_path, {"POST /gists":
                                    [200, gist_json("x", gist_id="newgid")]})
    res, requests = run_sync(
        stub, tmp_path, '  file_name = "snippets.toml"\n',
        snippets=LOCAL_SNIPPETS, env={"PET_GITHUB_ACCESS_TOKEN": "envtok"})
    assert res.rc == 0
    assert res.out == "Gist ID: newgid\nUpload success\n"
    assert requests == [
        "POST /gists auth=Bearer envtok body=%s" % gist_body(LOCAL_SNIPPETS),
    ]


def test_sync_gist_config_token_wins_over_environment(tmp_path):
    """When both the config file and $PET_GITHUB_ACCESS_TOKEN provide a
    token, the config value is the one that reaches the request header."""
    # CATCHES: getGithubAccessToken checks config.Conf.Gist.AccessToken first
    # and only consults the env variable when it is empty.
    stub = GistProxyStub(tmp_path, {"POST /gists":
                                    [200, gist_json("x", gist_id="newgid")]})
    res, requests = run_sync(stub, tmp_path, NO_ID, snippets=LOCAL_SNIPPETS,
                             env={"PET_GITHUB_ACCESS_TOKEN": "envtok"})
    assert res.rc == 0
    assert res.out == "Gist ID: newgid\nUpload success\n"
    assert requests == [
        "POST /gists auth=Bearer %s body=%s"
        % (TOKEN, gist_body(LOCAL_SNIPPETS)),
    ]


def test_sync_gist_missing_file_name_matches_no_remote_file(tmp_path):
    """A config that omits file_name leaves Gist.FileName empty (the
    pet-snippet.toml default is only written into auto-created configs), so
    no gist file matches and the error interpolates the empty name."""
    # CATCHES: Load() unmarshals into the zero-value struct without applying
    # createDefaultConfig's defaults, making the message " is empty" with a
    # leading space from the empty %s.
    stub = GistProxyStub(tmp_path, {"GET /gists/gid42":
                                    [200, gist_json(REMOTE_SNIPPETS)]})
    res, requests = run_sync(
        stub, tmp_path, '  access_token = "%s"\n  gist_id = "gid42"\n' % TOKEN,
        snippets="")
    assert res.rc == 255
    assert res.out == " is empty\n"
    assert res.err == ""
    assert requests == ["GET /gists/gid42 auth=Bearer %s body=" % TOKEN]


def test_sync_gist_missing_file_name_keys_upload_body_with_empty_string(
        tmp_path):
    """The same empty file_name becomes the files map key of the create
    request body: an empty-string key, not pet-snippet.toml."""
    # CATCHES: UploadSnippet builds its files map from config.Conf.Gist.
    # FileName verbatim, so the JSON body carries "files":{"":{...}}.
    stub = GistProxyStub(tmp_path, {"POST /gists":
                                    [200, gist_json("x", gist_id="newgid")]})
    res, requests = run_sync(stub, tmp_path, '  access_token = "%s"\n' % TOKEN,
                             snippets=LOCAL_SNIPPETS)
    assert res.rc == 0
    assert res.out == "Gist ID: newgid\nUpload success\n"
    assert requests == [
        "POST /gists auth=Bearer %s body=%s"
        % (TOKEN, gist_body(LOCAL_SNIPPETS, file_name="")),
    ]


def test_sync_gist_identical_remote_content_reports_up_to_date(tmp_path):
    """A remote gist that is newer but whose content re-encodes to the local
    TOML prints "Already up-to-date" and leaves the file untouched."""
    # CATCHES: the remote.After(local) branch still compares the CONTENT
    # before writing - equal content means no download and no rewrite, so
    # the pinned mtime survives the run.
    stub = GistProxyStub(tmp_path, {"GET /gists/gid42":
                                    [200, gist_json(LOCAL_SNIPPETS,
                                                    updated_at=FUTURE)]})
    local = tmp_path / "snippets.toml"
    try:
        local.write_text(LOCAL_SNIPPETS)
        os.utime(local, (PAST_EPOCH, PAST_EPOCH))
        res = run_pet(["sync"], tmp_path=tmp_path,
                      config=stub.config(WITH_ID), snippets=None,
                      env=dict(stub.env))
    finally:
        stub.close()
    assert res.rc == 0
    assert res.out == "Already up-to-date\n"
    assert res.err == ""
    assert int(os.stat(local).st_mtime) == PAST_EPOCH


def test_sync_gist_equal_timestamps_sync_silently(tmp_path):
    """A local mtime exactly equal to the remote updated_at picks the default
    branch of the sync switch: no upload, no download, no message at all -
    the gist client prints nothing, so stdout stays completely empty."""
    # CATCHES: the mtime comparison is a strict After() on both sides, so
    # equal timestamps must not trigger "Already up-to-date" or an upload;
    # the process exits 0 after exactly one GET without writing the file.
    stub = GistProxyStub(tmp_path, {"GET /gists/gid42":
                                    [200, gist_json(REMOTE_SNIPPETS)]})
    local = tmp_path / "snippets.toml"
    try:
        local.write_text(LOCAL_SNIPPETS)
        os.utime(local, (PAST_EPOCH, PAST_EPOCH))
        res = run_pet(["sync"], tmp_path=tmp_path,
                      config=stub.config(WITH_ID), snippets=None,
                      env=dict(stub.env))
    finally:
        stub.close()
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""
    assert stub.requests == ["GET /gists/gid42 auth=Bearer %s body=" % TOKEN]
    assert local.read_text() == LOCAL_SNIPPETS


def test_sync_gist_remote_newer_downloads_new_content(tmp_path):
    """A remote gist strictly newer than the local file whose content
    differs overwrites the local file with the gist content."""
    # CATCHES: the remote.After(local) branch with DIFFERENT content takes
    # the download path, replacing the whole file byte-for-byte with the
    # remote body rather than merging.
    stub = GistProxyStub(tmp_path, {"GET /gists/gid42":
                                    [200, gist_json(REMOTE_SNIPPETS,
                                                    updated_at=FUTURE)]})
    local = tmp_path / "snippets.toml"
    try:
        local.write_text(LOCAL_SNIPPETS)
        os.utime(local, (PAST_EPOCH, PAST_EPOCH))
        res = run_pet(["sync"], tmp_path=tmp_path,
                      config=stub.config(WITH_ID), snippets=None,
                      env=dict(stub.env))
    finally:
        stub.close()
    assert res.rc == 0
    assert res.out == "Download success\n"
    assert res.err == ""
    assert local.read_text() == REMOTE_SNIPPETS
