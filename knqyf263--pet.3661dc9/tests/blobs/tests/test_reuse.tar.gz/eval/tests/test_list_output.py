"""``pet list`` rendering (cmd/list.go), rewritten from the load/render paths
exercised by the native suite (``snippet/snippet_test.go`` TestLoad fixtures).

Every expected byte below was recorded by running the reference binary.
"""

import pytest

from conftest import run_pet, snippet_block

SNIPPETS = (
    snippet_block("greet user", "echo hello", tag=["greet"])
    + snippet_block("run pets", "echo pet", tag=["pet", "animal"])
)


def test_list_renders_description_command_tag_and_rule(tmp_path):
    """Each snippet prints label lines indented to 12 columns plus a 30-dash rule.

    The label column layout ("Description:", "    Command:", "        Tag:")
    and the trailing 30-dash separator come from the fixed format strings in
    cmd/list.go.
    """
    # CATCHES: a re-implementation that changes label padding or the dash
    # count breaks the exact per-snippet block rendering.
    res = run_pet(["list"], tmp_path=tmp_path, snippets=SNIPPETS)
    assert res.rc == 0
    assert res.out == (
        "Description: greet user\n"
        "    Command: echo hello\n"
        "        Tag: greet\n"
        "------------------------------\n"
        "Description: run pets\n"
        "    Command: echo pet\n"
        "        Tag: pet animal\n"
        "------------------------------\n"
    )
    assert res.err == ""


def test_list_empty_tag_array_prints_empty_tag_line(tmp_path):
    """``Tag = []`` (non-nil empty slice) still prints a Tag line, a missing
    Tag key prints none at all.

    The Go code checks ``snippet.Tag != nil``; go-toml decodes an empty TOML
    array as a non-nil empty slice.
    """
    # CATCHES: treating an empty tag array like an absent tag field would
    # drop (or add) the "        Tag: " line for one of the two snippets.
    snippets = (
        snippet_block("no tags here", "echo none", tag=[])
        + "\n[[Snippets]]\n"
        '  Description = "untagged"\n'
        '  Output = ""\n'
        '  command = "echo bare"\n'
    )
    res = run_pet(["list"], tmp_path=tmp_path, snippets=snippets)
    assert res.rc == 0
    assert res.out == (
        "Description: no tags here\n"
        "    Command: echo none\n"
        "        Tag: \n"
        "------------------------------\n"
        "Description: untagged\n"
        "    Command: echo bare\n"
        "------------------------------\n"
    )


def test_list_output_field_indents_continuation_lines(tmp_path):
    """A multi-line Output value re-indents every line after the first to 13
    columns (12 + space)."""
    # CATCHES: the "\n" -> "\n<13 spaces>" replacement is list.go specific;
    # a plain newline join would lose the deep indentation of line 2.
    snippets = snippet_block("multi out", "echo x", output="line1\\nline2")
    res = run_pet(["list"], tmp_path=tmp_path, snippets=snippets)
    assert res.rc == 0
    assert res.out == (
        "Description: multi out\n"
        "    Command: echo x\n"
        "        Tag: \n"
        "     Output: line1\n"
        "             line2\n"
        "------------------------------\n"
    )


def test_list_multiline_command_continuation_lines(tmp_path):
    """A command containing newlines prints its first line on the Command:
    row and every further line right-stripped onto a bare 12-space row."""
    # CATCHES: only the first command line carries the "    Command:" label;
    # continuation lines use a literal 12-space prefix with no label.
    snippets = snippet_block("multi cmd", "echo one\\necho two")
    res = run_pet(["list"], tmp_path=tmp_path, snippets=snippets)
    assert res.rc == 0
    assert res.out == (
        "Description: multi cmd\n"
        "    Command: echo one\n"
        "             echo two\n"
        "        Tag: \n"
        "------------------------------\n"
    )


def test_list_debug_shows_filename_row(tmp_path):
    """``--debug`` prefixes each block with a right-aligned "   Filename:"
    row naming the file the snippet was loaded from."""
    # CATCHES: the Filename is loaded on the fly (never stored in TOML), so
    # this pins that list reports the originating snippet file per snippet.
    snippets = snippet_block("s one", "echo 1")
    res = run_pet(["list", "--debug"], tmp_path=tmp_path, snippets=snippets)
    assert res.rc == 0
    assert res.out == (
        "   Filename: %s/snippets.toml\n"
        "Description: s one\n"
        "    Command: echo 1\n"
        "        Tag: \n"
        "------------------------------\n" % tmp_path
    )


def test_list_empty_snippet_file_outputs_nothing(tmp_path):
    """An existing but empty snippet file lists nothing and exits 0, while
    the same command with one snippet renders its block."""
    # CATCHES: an empty TOML file is a valid load (zero snippets) - it must
    # not be confused with a missing file, which errors with rc 255.
    res = run_pet(["list"], tmp_path=tmp_path,
                  snippets=snippet_block("s one", "echo 1"))
    assert res.rc == 0
    assert res.out == (
        "Description: s one\n"
        "    Command: echo 1\n"
        "        Tag: \n"
        "------------------------------\n"
    )

    res = run_pet(["list"], tmp_path=tmp_path, snippets="")
    assert res.rc == 0
    assert res.out == ""
    assert res.err == ""


def test_list_ignores_positional_arguments(tmp_path):
    """Extra positional arguments are accepted and ignored by ``pet list``."""
    # CATCHES: list registers no Args validator, so "pet list junk" still
    # renders snippets instead of rejecting the unknown argument.
    res = run_pet(["list", "junk", "args"], tmp_path=tmp_path,
                  snippets=snippet_block("s", "echo 1"))
    assert res.rc == 0
    assert res.out.startswith("Description: s\n")


@pytest.mark.parametrize("description, line", [
    # Recorded lines: the description is padded to 40 *display* columns
    # (runewidth), then followed by " : echo a".
    ("ascii desc", "ascii desc                               : echo a"),
    ("unicode ✓✓✓ desc",
     "unicode ✓✓✓ desc                         : echo a"),
    # 10 CJK runes occupy 20 cells, so only 20 padding spaces follow.
    ("日本語の説明テキスト",
     "日本語の説明テキスト                     : echo a"),
    ("exact-forty-chars-desc-xxxxxxxxxxxxxxxxx",
     "exact-forty-chars-desc-xxxxxxxxxxxxxxxxx : echo a"),
])
def test_list_oneline_pads_description_to_column(tmp_path, description, line):
    """``--oneline`` pads the description to 40 display columns using east-
    asian width (CJK runes count double, check marks single)."""
    # CATCHES: the padding uses runewidth, not rune count - a naive
    # ljust(40) over-pads CJK and breaks the recorded column alignment.
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path,
                  snippets=snippet_block(description, "echo a"))
    assert res.rc == 0
    assert res.out == line + "\n"


def test_list_oneline_truncates_long_description(tmp_path):
    """Descriptions wider than the column are truncated to 37 chars plus
    "..." and then padded back to the full 40 columns."""
    # CATCHES: truncation appends "..." inside the 40-cell budget (37+3),
    # and the truncated text is still right-padded with a single space.
    long_desc = "wide desc aaaaaaaa bbbbbbbb cccccccc dddddddd eeeeeeee"
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path,
                  snippets=snippet_block(long_desc, "echo wide"))
    assert res.rc == 0
    assert res.out == (
        "wide desc aaaaaaaa bbbbbbbb cccccccc ... : echo wide\n"
    )


def test_list_oneline_escapes_newlines_in_command(tmp_path):
    """``--oneline`` renders a multi-line command with literal backslash-n
    so it stays on one row."""
    # CATCHES: only the oneline mode escapes newlines; the same command in
    # plain mode spans continuation rows (covered above).
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path,
                  snippets=snippet_block("m", "echo one\\necho two"))
    assert res.rc == 0
    assert res.out == ("m" + " " * 39 + " : echo one\\necho two\n")


def test_list_oneline_honors_configured_column(tmp_path):
    """A ``Column`` value in the config overrides the default 40-column
    width for oneline truncation/padding."""
    # CATCHES: col==0 falls back to 40, but any other configured number is
    # used verbatim - here 10 columns.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml"\n'
              '  Column = 10\n')
    snippets = (
        snippet_block("multi cmd", "echo one\\necho two")
        + snippet_block("wide desc aaaaaaaa bbbbbbbb cccccccc dddddddd", "echo w")
    )
    res = run_pet(["list", "--oneline"], tmp_path=tmp_path, config=config,
                  snippets=snippets)
    assert res.rc == 0
    assert res.out == (
        "multi cmd  : echo one\\necho two\n"
        "wide de... : echo w\n"
    )
