"""``pet sync`` and the sync client initialization (sync/*.go).

Every case below is offline: the three backends validate the access token
before any network call, an empty gist/snippet ID makes GetSnippet return
an empty snippet without a request, and a non-numeric GitLab ID fails at
strconv.Atoi.  No test sets a gist/snippet ID together with a token, which
would be the only path that touches the network.
"""

import pytest

from conftest import run_pet


def sync_config(backend, extra=""):
    return ('[General]\n'
            '  SnippetFile = "{home}/snippets.toml"\n'
            '  Backend = "%s"\n%s' % (backend, extra))


#: Full recorded no-token failure output per backend (prefix + 3 message
#: lines + the trailing tab-tab line from the Go raw string).
NO_TOKEN_OUTPUT = {
    "gist": (
        "Failed to initialize API client: Failed to initialize Gist client: "
        "access_token is empty.\n"
        "Go https://github.com/settings/tokens/new and create access_token "
        '(only need "gist" scope).\n'
        "Write access_token in config file (pet configure) or export "
        "$PET_GITHUB_ACCESS_TOKEN.\n"
        "\t\t\n"
    ),
    "gitlab": (
        "Failed to initialize API client: Failed to initialize GitLab "
        "client: access_token is empty.\n"
        "Go https://gitlab.com/profile/personal_access_tokens and create "
        "access_token.\n"
        "Write access_token in config file (pet configure) or export "
        "$PET_GITLAB_ACCESS_TOKEN.\n"
        "\t\t\n"
    ),
    "ghe": (
        "Failed to initialize API client: Failed to initialize GHE client: "
        "access_token is empty.\n"
        "Go https://github.com/settings/tokens/new and create access_token "
        '(only need "gist" scope).\n'
        "Write access_token in config file (pet configure) or export "
        "$PET_GHE_ACCESS_TOKEN.\n"
        "\t\t\n"
    ),
}


@pytest.mark.parametrize("backend", ["gist", "gitlab", "ghe"])
def test_sync_without_token_fails_per_backend(tmp_path, backend):
    """Each backend reports its own "access_token is empty." block naming
    its env variable, wrapped by the AutoSync "Failed to initialize API
    client" prefix; exit status is 255."""
    # CATCHES: the three multiline messages differ in URL and variable name
    # and end with a bare tab-tab line from the raw Go string.
    res = run_pet(["sync"], tmp_path=tmp_path,
                  config=sync_config(backend), snippets="")
    assert res.rc == 255
    assert res.out == NO_TOKEN_OUTPUT[backend]
    assert res.err == ""


def test_sync_gist_offline_already_up_to_date(tmp_path):
    """With a token but no gist_id the client returns an empty remote
    snippet; an empty local file then compares equal and sync prints
    "Already up-to-date" with exit 0 - no network involved."""
    # CATCHES: GetSnippet short-circuits on an empty gist ID before any
    # HTTP call, and download() prints "Already up-to-date" when the remote
    # content equals the local TOML encoding.
    config = sync_config("gist", '\n[Gist]\n  access_token = "dummy"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="")
    assert res.rc == 0
    assert res.out == "Already up-to-date\n"
    assert res.err == ""


def test_sync_gist_token_from_environment(tmp_path):
    """The gist token is also accepted from $PET_GITHUB_ACCESS_TOKEN."""
    # CATCHES: getGithubAccessToken checks the config first, then the env
    # variable - the env fallback alone must initialize the client.
    res = run_pet(["sync"], tmp_path=tmp_path, config=sync_config("gist"),
                  snippets="", env={"PET_GITHUB_ACCESS_TOKEN": "dummy"})
    assert res.rc == 0
    assert res.out == "Already up-to-date\n"


def test_sync_ghe_prints_base_and_upload_urls(tmp_path):
    """The GHE client echoes the configured base_url and upload_url to
    stdout while initializing, before reporting the sync result."""
    # CATCHES: NewGHEGistClient fmt.Println's both URLs - observable output
    # even though nothing else happens for an empty gist ID.
    config = sync_config(
        "ghe",
        '\n[GHEGist]\n'
        '  access_token = "dummy"\n'
        '  base_url = "https://ghe.example.com/api/v3"\n'
        '  upload_url = "https://upload.example.com"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="")
    assert res.rc == 0
    assert res.out == (
        "https://ghe.example.com/api/v3\n"
        "https://upload.example.com\n"
        "Already up-to-date\n"
    )


def test_sync_gitlab_prints_url_and_accepts_empty_id(tmp_path):
    """The GitLab client echoes the configured Url and, with no ID set,
    completes offline with "Already up-to-date"."""
    # CATCHES: the URL echo happens during client construction; an empty ID
    # yields the zero-value snippet without a request.
    config = sync_config(
        "gitlab",
        '\n[GitLab]\n'
        '  access_token = "dummy"\n'
        '  Url = "https://gitlab.example.com/api/v4"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="")
    assert res.rc == 0
    assert res.out == (
        "https://gitlab.example.com/api/v4\n"
        "Already up-to-date\n"
    )


def test_sync_gitlab_non_numeric_id_is_client_error(tmp_path):
    """A GitLab ID that is not a number fails in the client constructor
    with the strconv error wrapped in pet's messages."""
    # CATCHES: strconv.Atoi runs during NewGitLabClient, so the failure is
    # prefixed by "Failed to initialize API client" rather than a request
    # error.
    config = sync_config(
        "gitlab",
        '\n[GitLab]\n'
        '  access_token = "dummy"\n'
        '  ID = "not-a-number"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="")
    assert res.rc == 255
    assert res.out == (
        "Failed to initialize API client: Failed to initialize GitLab "
        "client: Invalid GitLab Snippet ID: 0: strconv.Atoi: parsing "
        '"not-a-number": invalid syntax\n'
    )


def test_sync_missing_snippet_file_with_token(tmp_path):
    """With a valid-looking token and no gist ID, a missing local snippet
    file surfaces the snippet-file-not-found error from download()'s
    Load(false)."""
    # CATCHES: AutoSync stats the local file only after GetSnippet; the
    # IsNotExist branch calls download() whose Load fails with the standard
    # guidance message.
    config = ('[General]\n'
              '  SnippetFile = "{home}/gone.toml"\n'
              '  Backend = "gist"\n'
              '\n[Gist]\n'
              '  access_token = "dummy"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets=None)
    assert res.rc == 255
    assert res.out == (
        "snippet file not found. %s/gone.toml\n"
        "Please run 'pet configure' and provide a correct file path, or remove this\n"
        "if you only want to provide snippetdirs instead\n" % tmp_path
    )


def test_sync_snippet_path_under_regular_file_crashes(tmp_path):
    """A SnippetFile whose parent component is a regular file makes os.Stat
    fail with ENOTDIR - which is NOT IsNotExist - and pet crashes: AutoSync
    evaluates fi.Size() on the nil FileInfo before the error branch, so the
    process dies with SIGSEGV (rc 2) and empty stdout."""
    # CATCHES: the "os.IsNotExist(err) || fi.Size() == 0" condition
    # dereferences the nil FileInfo for any non-NotExist stat error, making
    # the "Failed to get a FileInfo" branch unreachable; a re-implementation
    # that checks the error first and prints a message would NOT crash.
    config = ('[General]\n'
              '  SnippetFile = "{home}/snippets.toml/nope"\n'
              '  Backend = "gist"\n'
              '\n[Gist]\n'
              '  access_token = "dummy"\n')
    res = run_pet(["sync"], tmp_path=tmp_path, config=config, snippets="x")
    assert res.rc == 2
    assert res.out == ""
    lines = res.err.splitlines()
    assert lines[0] == (
        "panic: runtime error: invalid memory address or nil pointer "
        "dereference")
    assert lines[1].startswith("[signal SIGSEGV: segmentation violation code=0x1")
    assert "github.com/knqyf263/pet/sync.AutoSync" in res.err
