"""CLI surface: version, help texts, unknown commands and flag errors
(cobra behavior of cmd/root.go and the per-command init() registrations).

All texts below were recorded from the reference binary.
"""

import pytest

from conftest import run_pet

ROOT_HELP = """\
pet - Simple command-line snippet manager.

Usage:
  pet [command]

Available Commands:
  clip        Copy the selected commands
  completion  Generate the autocompletion script for the specified shell
  configure   Edit config file
  edit        Edit snippet file
  exec        Run the selected commands
  help        Help about any command
  list        Show all snippets
  new         Create a new snippet
  search      Search snippets
  sync        Sync snippets
  version     Print the version number

Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
  -h, --help            help for pet

Use "pet [command] --help" for more information about a command.
"""


def test_version_prints_revision_hash(tmp_path):
    """``pet version`` prints "pet version <git-revision>"."""
    # CATCHES: the version string is the bare revision hash prefixed by
    # "pet version ", not a semver.
    res = run_pet(["version"], tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out.startswith("pet version ")
    assert len(res.out.strip().split()[-1]) == 40
    assert res.out.endswith("\n")


@pytest.mark.parametrize("args", [[], ["--help"], ["-h"], ["help"]])
def test_root_help_variants(tmp_path, args):
    """Bare ``pet``, ``--help``, ``-h`` and ``pet help`` all print the same
    root help listing every subcommand in alphabetical order."""
    # CATCHES: the root command has no Run function, so even argumentless
    # invocation just prints help with exit 0.
    res = run_pet(args, tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out == ROOT_HELP
    assert res.err == ""


def test_help_for_subcommand_list(tmp_path):
    """``pet help list`` prints list's own help: long description, usage
    line and the oneline/tags flags plus global flags."""
    # CATCHES: per-command help shows only that command's flags under
    # "Flags:" and the persistent ones under "Global Flags:".
    res = run_pet(["help", "list"], tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out == """\
Show all snippets

Usage:
  pet list [flags]

Flags:
  -h, --help          help for list
      --oneline       Display snippets in one line
  -t, --tags string   list by specified tags as comma separated values

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
"""


def test_help_for_subcommand_new(tmp_path):
    """``pet new -h`` shows the COMMAND usage arg and the editor/multiline/
    tag flags with their one-line descriptions."""
    # CATCHES: the usage line is "pet new COMMAND [flags]" and the multiline
    # flag description contains a literal backslash-n ("Double \\n to quit").
    res = run_pet(["new", "-h"], tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out == """\
Create a new snippet (default: $HOME/.config/pet/snippet.toml)

Usage:
  pet new COMMAND [flags]

Flags:
  -e, --editor      Use editor to create snippet
  -h, --help        help for new
  -m, --multiline   Can enter multiline snippet (Double \\n to quit)
  -t, --tag         Display tag prompt (delimiter: space)

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
"""


def test_help_for_subcommand_search(tmp_path):
    """``pet search --help`` lists the raw/color/query/tag/delimiter flags
    with the recorded default delimiter "; "."""
    # CATCHES: the delimiter flag's help line embeds the default value
    # '(default "; ")' which cobra renders for non-empty defaults.
    res = run_pet(["search", "--help"], tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out == """\
Search snippets interactively (default filtering tool: peco)

Usage:
  pet search [flags]

Flags:
      --color              Enable colorized output (only fzf)
  -d, --delimiter string   Use delim as the command delimiter character (default "; ")
  -h, --help               help for search
  -q, --query string       Initial value for query
      --raw                Output raw command without entering parameter dialog
  -t, --tag string         Filter tag

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
"""


def test_help_unknown_topic_goes_to_stderr(tmp_path):
    """``pet help unknown`` prints "Unknown help topic" with the usage block
    on STDERR and still exits 0."""
    # CATCHES: the help command routes bad topics to stderr (unlike command
    # errors, which go to stdout) and does not fail the run.
    res = run_pet(["help", "unknown-topic"], tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out == ""
    assert res.err.startswith("Unknown help topic [`unknown-topic`]\n")
    assert "Available Commands:" in res.err


def test_unknown_command_error_with_suggestions(tmp_path):
    """An unknown command that looks like a typo lists suggestions after
    the error line (cobra's Levenshtein suggestions)."""
    # CATCHES: suggestions are tab-indented under "Did you mean this?" and
    # the whole message goes to stdout with exit 255.
    res = run_pet(["lis"], tmp_path=tmp_path)
    assert res.rc == 255
    assert res.out == (
        'unknown command "lis" for "pet"\n'
        "\n"
        "Did you mean this?\n"
        "\tclip\n"
        "\tlist\n"
        "\n"
    )
    assert res.err == ""


def test_unknown_command_without_suggestions(tmp_path):
    """An unknown command sharing no prefix with any subcommand reports
    only the one-line error."""
    # CATCHES: suggestion generation is distance-based; unrelated names get
    # no "Did you mean this?" block.
    res = run_pet(["frobnicate"], tmp_path=tmp_path)
    assert res.rc == 255
    assert res.out == 'unknown command "frobnicate" for "pet"\n'


def test_flag_needs_argument_error(tmp_path):
    """A flag requiring a value at the end of the argv fails with cobra's
    "flag needs an argument" message on stdout and exit 255."""
    # CATCHES: flag-parse errors are returned from Execute (SilenceErrors)
    # and printed by main's fmt.Println, not by cobra's default handler.
    res = run_pet(["list", "--tags"], tmp_path=tmp_path)
    assert res.rc == 255
    assert res.out == "flag needs an argument: --tags\n"
    assert res.err == ""


def test_unknown_flag_error(tmp_path):
    """An unrecognized flag is rejected before the command runs."""
    # CATCHES: unknown flags abort even for commands that accept positional
    # arguments, and the message names the exact flag.
    res = run_pet(["list", "--bogus"], tmp_path=tmp_path)
    assert res.rc == 255
    assert res.out == "unknown flag: --bogus\n"


def test_version_ignores_extra_arguments(tmp_path):
    """``pet version extra`` ignores the positional argument and prints the
    version normally."""
    # CATCHES: no subcommand registers an Args validator, so positional
    # junk is silently accepted everywhere.
    res = run_pet(["version", "extra-arg"], tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out.startswith("pet version ")


def test_completion_command_help(tmp_path):
    """The cobra-generated ``completion`` command advertises the shell
    subcommands (bash/zsh/fish/powershell)."""
    # CATCHES: completion is a built-in cobra command appearing in the root
    # help; its own help lists the supported shells.
    res = run_pet(["completion"], tmp_path=tmp_path)
    assert res.rc == 0
    assert res.out.startswith(
        "Generate the autocompletion script for pet for the specified shell.")
    for shell in ("bash", "zsh", "fish", "powershell"):
        assert shell in res.out
