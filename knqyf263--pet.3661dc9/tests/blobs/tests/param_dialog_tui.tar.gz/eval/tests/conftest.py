"""Shared black-box harness for the pet parameter-dialog behavioural tests.

Every test drives the program under test exclusively through its command
line interface, resolving the binary from ``PROGRAMGYM_EXECUTABLE``.

The dialog under test is a full-screen gocui TUI, so the harness runs the
program on a private pseudo-terminal: the dialog is drawn on the pty (tcell
opens ``/dev/tty``, which is the pty), keystrokes are written to the pty
master and the program's own stdout/stderr are redirected to files inside
``tmp_path`` so they can be compared byte for byte without any terminal
noise mixed in.

All expectations embedded in the tests were recorded by running the
reference binary.
"""

import fcntl
import json
import os
import pty
import re
import select
import signal
import struct
import subprocess
import termios
import time
from pathlib import Path

import pytest

#: Title of the read-only view that always shows the raw command.
DIALOG_TITLE = "Command(TAB => Select next, ENTER => Execute command):"

#: Rows/columns of the private pty used by every dialog test.
ROWS, COLS = 40, 120

CONFIG_TMPL = """[General]
  snippetfile = "%(snippet)s"
  editor = "vi"
  column = 40
  selectcmd = "%(select)s"
  backend = "gist"
  sortby = ""

[Gist]
  file_name = "pet-snippet.toml"
"""


def program_path():
    """Resolve the program under test from $PROGRAMGYM_EXECUTABLE."""
    raw = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not raw:
        pytest.fail("PROGRAMGYM_EXECUTABLE must point at the program under test")
    return str(Path(raw))


def pinned_env(home, extra=None):
    """A minimal, deterministic child environment."""
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": str(home),
        "TMPDIR": str(home),
        "TERM": "xterm",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
    }
    if extra:
        env.update(extra)
    # Coverage instrumentation hook: let the pipeline's GOCOVERDIR reach the
    # child so source coverage of the reference binary can be measured. The
    # value is made absolute because the child runs with cwd inside tmp_path;
    # a relative GOCOVERDIR would otherwise scatter the coverage files into
    # the throwaway sandbox instead of the pipeline's collection directory.
    cov_env = {"GOCOVERDIR": os.path.abspath(v)
               for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    return env


class PtyChild:
    """The program under test on a fresh pty, stdout/stderr in files."""

    def __init__(self, argv, env, cwd, out_path, err_path, rows, cols,
                 tty_stdout=False):
        self.status = None
        self.buf = b""
        self.pid, self.master = pty.fork()
        if self.pid == 0:  # child: pty becomes the controlling terminal
            try:
                os.chdir(cwd)
                if not tty_stdout:
                    fd = os.open(out_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                                 0o644)
                    os.dup2(fd, 1)
                fd = os.open(err_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                             0o644)
                os.dup2(fd, 2)
                os.execve(argv[0], argv, env)
            except Exception:
                os._exit(127)
        self.set_size(rows, cols)

    # -- plumbing ------------------------------------------------------
    def set_size(self, rows, cols):
        fcntl.ioctl(self.master, termios.TIOCSWINSZ,
                    struct.pack("HHHH", rows, cols, 0, 0))

    def _read(self, timeout=0.05):
        """Read once; byte count (0 if nothing), None on EOF/error."""
        r, _, _ = select.select([self.master], [], [], timeout)
        if not r:
            return 0
        try:
            data = os.read(self.master, 65536)
        except OSError:
            return None
        if not data:
            return None
        self.buf += data
        return len(data)

    def wait_for(self, needle, timeout=10.0):
        """Read until the literal ``needle`` shows up on the pty stream."""
        if isinstance(needle, str):
            needle = needle.encode()
        deadline = time.time() + timeout
        while time.time() < deadline:
            if needle in self.buf:
                return True
            if self._read(0.05) is None:
                return needle in self.buf
        return needle in self.buf

    def drain(self, quiet=0.35, timeout=15.0):
        """Read until nothing new arrived for ``quiet`` seconds."""
        last = time.time()
        deadline = time.time() + timeout
        while time.time() < deadline:
            self.reap()
            if self.status is not None:
                if not self._read(0.05):
                    break
                last = time.time()
                continue
            n = self._read(0.05)
            if n:
                last = time.time()
            elif time.time() - last >= quiet:
                break
        return self.buf

    def reap(self):
        if self.status is not None:
            return self.status
        try:
            pid, st = os.waitpid(self.pid, os.WNOHANG)
            if pid == self.pid:
                self.status = st
        except ChildProcessError:
            self.status = -1
        return self.status

    def wait(self, timeout=10.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            self.reap()
            if self.status is not None:
                return self.status
            self._read(0.05)
        return self.status

    def exit_code(self):
        if self.status is None:
            return None
        return (os.WEXITSTATUS(self.status) if os.WIFEXITED(self.status)
                else -os.WTERMSIG(self.status))

    def send(self, data):
        if isinstance(data, str):
            data = data.encode()
        while data:
            n = os.write(self.master, data)
            data = data[n:]

    def kill(self):
        try:
            os.kill(self.pid, signal.SIGKILL)
        except OSError:
            pass
        try:
            os.waitpid(self.pid, os.WNOHANG)
        except OSError:
            pass


# ------------------------------------------------------------------ vt100 --
CSI = re.compile(r"\x1b\[([0-9;?<>=]*)([ -/]*)([@-~])")
OSC = re.compile(r"\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")
PLAIN = re.compile(
    r"\x1b(\[[0-9;?<>=]*[ -/]*[@-~]|\][^\x07\x1b]*(?:\x07|\x1b\\)|"
    r"[()][0-9A-Za-z]|[=><]|\x1b)")


class Screen:
    """A tiny vt100 renderer: pty bytes in, a character grid out."""

    def __init__(self, rows, cols):
        self.rows, self.cols = rows, cols
        self.grid = [[" "] * cols for _ in range(rows)]
        self.fg = [[None] * cols for _ in range(rows)]
        self.x = self.y = 0
        self.fgcur = None
        self.reported_cursor = (0, 0)

    def feed(self, data):
        if isinstance(data, bytes):
            data = data.decode("utf-8", "replace")
        i, n = 0, len(data)
        while i < n:
            ch = data[i]
            if ch == "\x1b":
                m = CSI.match(data, i)
                if m:
                    self._csi(m.group(1), m.group(3))
                    i = m.end()
                    continue
                m = OSC.match(data, i)
                if m:
                    i = m.end()
                    continue
                if i + 1 < n and data[i + 1] in "()":
                    i += 3
                elif i + 1 < n and data[i + 1] in "=>":
                    i += 2
                elif i + 1 < n and data[i + 1] == "]":
                    j = data.find("\x1b\\", i)
                    i = n if j < 0 else j + 2
                else:
                    i += 1
                continue
            if ch == "\r":
                self.x = 0
            elif ch == "\n":
                self.y = min(self.rows - 1, self.y + 1)
            elif ch == "\b":
                self.x = max(0, self.x - 1)
            elif ch == "\t":
                self.x = min(self.cols - 1, (self.x // 8 + 1) * 8)
            elif ord(ch) >= 32 and ord(ch) != 127:
                if 0 <= self.y < self.rows and 0 <= self.x < self.cols:
                    self.grid[self.y][self.x] = ch
                    self.fg[self.y][self.x] = self.fgcur
                self.x += 1
            i += 1

    def _csi(self, params, final):
        nums = [int(p) for p in params.lstrip("?").split(";") if p != ""]

        def g(i, d=1):
            return nums[i] if i < len(nums) else d

        if params.startswith("?"):
            return
        if final in "Hf":
            self.y, self.x = max(0, g(0, 1) - 1), max(0, g(1, 1) - 1)
            self.reported_cursor = (self.y, self.x)
        elif final == "A":
            self.y = max(0, self.y - g(0, 1))
        elif final == "B":
            self.y = min(self.rows - 1, self.y + g(0, 1))
        elif final == "C":
            self.x = min(self.cols - 1, self.x + g(0, 1))
        elif final == "D":
            self.x = max(0, self.x - g(0, 1))
        elif final == "G":
            self.x = max(0, g(0, 1) - 1)
        elif final == "d":
            self.y = max(0, g(0, 1) - 1)
        elif final == "J":
            if g(0, 0) in (2, 3):
                self.grid = [[" "] * self.cols for _ in range(self.rows)]
                self.fg = [[None] * self.cols for _ in range(self.rows)]
        elif final == "K":
            mode = g(0, 0)
            rng = (range(self.x, self.cols) if mode == 0 else
                   range(0, self.x + 1) if mode == 1 else range(self.cols))
            for xx in rng:
                self.grid[self.y][xx] = " "
                self.fg[self.y][xx] = None
        elif final == "m":
            if not nums:
                nums = [0]
            for v in nums:
                if v == 0 or v == 39:
                    self.fgcur = None
                elif 30 <= v <= 37:
                    self.fgcur = v - 30
                elif 90 <= v <= 97:
                    self.fgcur = v - 90 + 8

    # -- accessors -----------------------------------------------------
    def row(self, y):
        """Row ``y`` right-stripped of padding blanks."""
        return "".join(self.grid[y]).rstrip()

    def find(self, needle):
        """(y, x) of the first occurrence of ``needle``, else None."""
        for y in range(self.rows):
            x = "".join(self.grid[y]).find(needle)
            if x >= 0:
                return (y, x)
        return None

    def fg_at(self, y, x):
        return self.fg[y][x]

    def boxes(self):
        """Every drawn box frame as (y, x0, title, title_fg, content_row).

        gocui frames a view with ``┌─Title───┐``; the title text and its
        colours are extracted from that top border row, the content is the
        row below it.
        """
        out = []
        for y in range(self.rows - 1):
            row = "".join(self.grid[y])
            x0 = row.find("┌")
            x1 = row.find("┐", x0 + 1) if x0 >= 0 else -1
            if x0 < 0 or x1 < 0:
                continue
            raw = row[x0 + 1:x1]
            title = raw.strip("─")
            t0 = x0 + 1 + (len(raw) - len(raw.lstrip("─")))
            fg = [self.fg[y][x] for x in range(t0, t0 + len(title))]
            content = "".join(self.grid[y + 1]).rstrip()
            out.append((y, x0, title, fg, content))
        return out

    def view(self, title):
        """The box whose title is exactly ``title``, else None."""
        for box in self.boxes():
            if box[2] == title:
                return box
        return None

    def focused_title(self):
        """Title of the highlighted (green fg) view, else None.

        GenerateParamsLayout sets ``SelFgColor`` to green, so exactly the
        focused view's title is drawn in colour.
        """
        for y, x0, title, fg, _ in self.boxes():
            if any(c == 2 for c in fg):
                return title
        return None


def box_text(box):
    """The text shown inside a box frame, frame borders removed."""
    _, x0, _, _, content = box
    inner = content[x0 + 1:]
    if inner.endswith("│"):
        inner = inner[:-1]
    return inner.rstrip()


def strip_escapes(buf):
    """Remove every escape sequence from a pty byte stream."""
    return PLAIN.sub("", buf.decode("utf-8", "surrogateescape"))


class RunResult:
    """Outcome of one black-box invocation of the program."""

    def __init__(self, returncode, stdout, stderr, tty, dialog, screen):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
        self.tty = tty
        self.dialog = dialog
        self.screen = screen

    @property
    def out(self):
        """stdout decoded as text."""
        return self.stdout.decode("utf-8", "surrogateescape")

    @property
    def err(self):
        """stderr decoded as text."""
        return self.stderr.decode("utf-8", "surrogateescape")

    def __repr__(self):
        return "RunResult(rc=%d, stdout=%r, stderr=%r, dialog=%r)" % (
            self.returncode, self.stdout, self.stderr, self.dialog)


def write_snippet_env(tmp_path, commands, select):
    """Create the config dir + snippet file; returns the config directory."""
    tmp = Path(tmp_path)
    cfg = tmp / "cfg"
    snips = tmp / "snips"
    cfg.mkdir(parents=True, exist_ok=True)
    snips.mkdir(parents=True, exist_ok=True)
    snippet_file = snips / "snippet.toml"
    parts = []
    for i, cmd in enumerate(commands):
        parts.append('[[snippets]]\n  description = "s%d"\n  command = %s\n'
                     '  tag = []\n  output = ""\n' % (i, json.dumps(cmd)))
    snippet_file.write_text("".join(parts))
    (cfg / "config.toml").write_text(
        CONFIG_TMPL % {"snippet": snippet_file, "select": select})
    return cfg


def run_pet(tmp_path, commands, args, keys=(), select="head -n 1",
            rows=ROWS, cols=COLS, env_extra=None, wait_dialog=True,
            quiet=0.35, key_quiet=0.3, tty_stdout=False):
    """Run pet on a private pty and drive its parameter dialog.

    ``commands``  snippet command strings, first one is selected by default.
    ``select``    the deterministic selector (selectcmd) to configure.
    ``keys``      bytes written to the pty once the dialog has drawn.
    ``tty_stdout`` keep stdout on the pty instead of a file (to exercise
                   behaviour that depends on stdout being a terminal).

    Keys are only sent after the dialog's title has actually been drawn, so
    they can never be swallowed by the still-canonical tty line discipline.
    """
    tmp = Path(tmp_path)
    cfg = write_snippet_env(tmp, commands, select)
    out_path = tmp / "stdout.txt"
    err_path = tmp / "stderr.txt"
    env = pinned_env(tmp, env_extra)
    env["PET_CONFIG_DIR"] = str(cfg)
    child = PtyChild([program_path()] + [str(a) for a in args], env, str(tmp),
                     str(out_path), str(err_path), rows, cols, tty_stdout)
    try:
        dialog = child.wait_for(DIALOG_TITLE, timeout=10.0)
        if dialog:
            child.drain(quiet=quiet, timeout=6.0)
        if wait_dialog:
            for k in keys:
                child.send(k)
                child.drain(quiet=key_quiet, timeout=6.0)
            child.wait(timeout=10.0)
        else:
            child.wait(timeout=10.0)
        child.drain(quiet=0.2, timeout=3.0)
        rc = child.exit_code()
        tty = child.buf
    finally:
        child.kill()
    screen = Screen(rows, cols)
    screen.feed(tty)
    if tty_stdout:
        marker = b"\x1b[?1049l"
        pos = tty.rfind(marker)
        tail = tty[pos + len(marker):] if pos >= 0 else tty
        stdout = strip_escapes(tail).encode("utf-8", "surrogateescape")
    else:
        stdout = out_path.read_bytes() if out_path.exists() else b""
    return RunResult(rc, stdout,
                     err_path.read_bytes() if err_path.exists() else b"",
                     tty, dialog, screen)


def run_pet_plain(tmp_path, commands, args, select="head -n 1", stdin=b""):
    """Run pet as a plain child process without any terminal attached."""
    tmp = Path(tmp_path)
    cfg = write_snippet_env(tmp, commands, select)
    env = pinned_env(tmp, {"PET_CONFIG_DIR": str(cfg)})
    proc = subprocess.run([program_path()] + [str(a) for a in args],
                          input=stdin, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, cwd=str(tmp), env=env,
                          timeout=30)
    return RunResult(proc.returncode, proc.stdout, proc.stderr, b"",
                     False, Screen(ROWS, COLS))


@pytest.fixture
def pet(tmp_path):
    """``run_pet`` bound to this test's tmp_path."""
    return lambda *a, **kw: run_pet(tmp_path, *a, **kw)


@pytest.fixture
def pet_plain(tmp_path):
    """``run_pet_plain`` bound to this test's tmp_path."""
    return lambda *a, **kw: run_pet_plain(tmp_path, *a, **kw)
