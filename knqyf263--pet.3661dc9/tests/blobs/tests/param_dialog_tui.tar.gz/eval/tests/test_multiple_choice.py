"""Multiple-choice defaults: ``<p=|_a_||_b_||_c_|>`` and their cycling keys.

``generateMultipleParameterView`` splits a default that contains ``|_..._|``
groups into a list of choices, titles the view with an UP/DOWN hint when
there is more than one choice, and binds UP/DOWN to cycle through them
(wrapping around at both ends).
"""

from conftest import box_text

ENTER = b"\r"
TAB = b"\t"
DOWN = b"\x1b[B"
UP = b"\x1b[A"
MC = 'echo "<p=|_aa_||_bb_||_cc_|>"'


def param_boxes(res):
    """The dialog's boxes minus the read-only command view."""
    return [b for b in res.screen.boxes() if not b[2].startswith("Command(")]


def test_three_choices_get_updown_hint_title(pet):
    """A view with several choices is titled with the UP/DOWN hint."""
    res = pet([MC], ["search"])
    boxes = param_boxes(res)
    # CATCHES: the view title is '<name> (UP/DOWN => Select default value)'
    # exactly when the default holds more than one choice.
    assert [b[2] for b in boxes] == ["p (UP/DOWN => Select default value)"]


def test_single_choice_has_plain_title(pet):
    """``|_only_|`` is one choice, so no UP/DOWN hint is added."""
    res = pet(['echo "<p=|_only_|>"'], ["search"])
    boxes = param_boxes(res)
    # CATCHES: the hint is only appended when maxOpt > 1; a single-choice
    # default gets a plain view titled with the parameter name.
    assert [b[2] for b in boxes] == ["p"]
    assert box_text(boxes[0]) == "only"


def test_first_choice_is_pre_selected(pet):
    """The first choice fills the field before any key is pressed."""
    res = pet([MC], ["search"])
    # CATCHES: the initial value shown is defaultParams[0], the first choice
    # in the order the choices appear in the default.
    assert box_text(param_boxes(res)[0]) == "aa"


def test_enter_substitutes_the_displayed_choice(pet):
    """ENTER substitutes whatever choice is currently displayed."""
    res = pet([MC], ["search"], [ENTER])
    # CATCHES: the choice shown in the field is what insertParams receives,
    # so an untouched multiple-choice field substitutes its first choice.
    assert (res.returncode, res.stdout) == (0, b'echo "aa"')


def test_down_moves_to_the_second_choice(pet):
    """DOWN selects the next choice."""
    res = pet([MC], ["search"], [DOWN])
    # CATCHES: ArrowDown is bound on the multiple-choice view and replaces
    # the field content with the next choice.
    assert box_text(param_boxes(res)[0]) == "bb"


def test_down_twice_reaches_the_last_choice(pet):
    """DOWN twice reaches the third choice."""
    res = pet([MC], ["search"], [DOWN, DOWN])
    # CATCHES: every DOWN press advances one choice, and the field is
    # cleared and refilled rather than appended to.
    assert box_text(param_boxes(res)[0]) == "cc"


def test_down_wraps_around_to_the_first_choice(pet):
    """DOWN past the last choice wraps back to the first."""
    res = pet([MC], ["search"], [DOWN, DOWN, DOWN])
    # CATCHES: the index wraps modulo the number of choices, so a third DOWN
    # on three choices lands back on the first one.
    assert box_text(param_boxes(res)[0]) == "aa"


def test_up_from_the_first_choice_wraps_to_the_last(pet):
    """UP from the first choice wraps around to the last."""
    res = pet([MC], ["search"], [UP])
    # CATCHES: ArrowUp wraps backwards, so the first choice is preceded by
    # the last one.
    assert box_text(param_boxes(res)[0]) == "cc"


def test_up_then_down_returns_to_the_first_choice(pet):
    """UP (wrap to last) then DOWN (wrap to first) restores choice one."""
    res = pet([MC], ["search"], [UP, DOWN])
    # CATCHES: the cycling index is stateful across key presses, so the
    # wrap from UP is remembered by the following DOWN.
    assert box_text(param_boxes(res)[0]) == "aa"


def test_down_then_enter_substitutes_that_choice(pet):
    """The cycled-to choice is the one substituted by ENTER."""
    res = pet([MC], ["search"], [DOWN, ENTER])
    # CATCHES: the final command uses the value visible in the field at the
    # moment ENTER is pressed.
    assert res.stdout == b'echo "bb"'


def test_updown_choices_may_contain_spaces_and_specials(pet):
    """Choice text may hold spaces, '=' and '#' characters."""
    cmd = 'echo "<p=|_Jane Doe = special #chars_||_Sam_|>"'
    res = pet([cmd], ["search"], [DOWN, ENTER])
    # CATCHES: choices are delimited by the |_..._| markers only, so the
    # spaces and specials inside a choice are preserved verbatim.
    assert res.stdout == b'echo "Sam"'
    res2 = pet([cmd], ["search"], [ENTER])
    assert res2.stdout == b'echo "Jane Doe = special #chars"'


def test_duplicated_choices_are_kept_as_separate_options(pet):
    """``|_a_||_a_||_b_|`` still cycles through three options."""
    cmd = 'echo "<p=|_a_||_a_||_b_|>"'
    res = pet([cmd], ["search"], [DOWN, DOWN, ENTER])
    # CATCHES: the choices are not de-duplicated, so the second DOWN lands
    # on the repeated 'a' and only the third reaches 'b'.
    assert res.stdout == b'echo "b"'


def test_text_outside_choice_markers_is_dropped(pet):
    """A default of ``pre|_a_|post`` only offers the marked choices."""
    res = pet(["echo <p=pre|_a_|post>"], ["search"])
    boxes = param_boxes(res)
    # CATCHES: everything outside the |_..._| groups (the 'pre'/'post'
    # text) is discarded: only 'a' remains, both on screen and in the
    # substituted command.
    assert box_text(boxes[0]) == "a"
    assert pet(["echo <p=pre|_a_|post>"], ["search"], [ENTER]).stdout == b"echo a"


def test_unmatched_pipe_marker_is_an_ordinary_default(pet):
    """``|_a`` without a closing ``_|`` is a plain default."""
    res = pet(["echo <p=|_a>"], ["search"])
    boxes = param_boxes(res)
    # CATCHES: the multiple-value regex needs a full |_..._| pair, so an
    # unterminated marker stays literal text in a normal single view.
    assert [b[2] for b in boxes] == ["p"]
    assert box_text(boxes[0]) == "|_a"


def test_trailing_marker_without_opener_is_ordinary(pet):
    """``a_|`` without a leading ``|_`` is a plain default too."""
    res = pet(["echo <p=a_|>"], ["search"])
    boxes = param_boxes(res)
    # CATCHES: only complete |_..._| pairs are split into choices, so 'a_|'
    # is pre-filled as-is and substituted unchanged.
    assert box_text(boxes[0]) == "a_|"
    assert pet(["echo <p=a_|>"], ["search"], [ENTER]).stdout == b"echo a_|"


def test_pipe_without_markers_is_an_ordinary_default(pet):
    """A plain '|' in a default is not a choice separator."""
    res = pet(["echo <p=a|b>"], ["search"])
    boxes = param_boxes(res)
    # CATCHES: 'a|b' contains no |_..._| group, so it is one ordinary
    # default and the pipe survives the substitution.
    assert [b[2] for b in boxes] == ["p"]
    assert pet(["echo <p=a|b>"], ["search"], [ENTER]).stdout == b"echo a|b"


def test_updown_on_a_plain_field_keeps_the_default(pet):
    """UP/DOWN on a single-value field neither clears nor changes it."""
    res = pet(["echo <a=one>"], ["search"], [UP, DOWN, ENTER])
    # CATCHES: only multiple-choice views bind the arrow keys, so on a plain
    # field they must not disturb the pre-filled default.
    assert res.stdout == b"echo one"


def test_multiple_choice_next_to_plain_params(pet):
    """A command can mix multiple-choice and plain parameters."""
    cmd = 'echo "<mc=|_x_||_y_|>" <plain=zz>'
    res = pet([cmd], ["search"])
    boxes = param_boxes(res)
    # CATCHES: each parameter is rendered by its own rule, so the first view
    # gets the UP/DOWN hint while the second is a plain pre-filled field.
    assert [b[2] for b in boxes] == ["mc (UP/DOWN => Select default value)",
                                     "plain"]
    assert [box_text(b) for b in boxes] == ["x", "zz"]
