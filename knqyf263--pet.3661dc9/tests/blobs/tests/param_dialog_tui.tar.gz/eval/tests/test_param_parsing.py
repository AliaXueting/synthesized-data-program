"""Placeholder syntax: which ``<...>`` forms are parameters, and their defaults.

Every test selects one snippet with a deterministic selector (``head -n 1``)
so the dialog opens on exactly one command.  The observable consequences of
``SearchForParams`` are the dialog's per-parameter views (one view per key,
titled with the key, pre-filled with the default) and, after ENTER, the
command string that ``insertParams`` hands back to the subcommand.
"""

from conftest import box_text

# Keys sent to the pty.
ENTER = b"\r"
TAB = b"\t"
CTRL_K = b"\x0b"
CTRL_C = b"\x03"
DOWN = b"\x1b[B"
UP = b"\x1b[A"
RIGHT = b"\x1b[C"
LEFT = b"\x1b[D"
BACKSPACE = b"\x7f"


def final(pet, command, keys=(ENTER,)):
    """Run `pet search` on one snippet and return its stdout."""
    res = pet([command], ["search"], list(keys))
    assert res.dialog, "expected the parameter dialog to open"
    return res


def test_plain_command_opens_no_dialog(pet):
    """A command without any placeholder never opens the parameter dialog."""
    res = pet(["echo plain"], ["search"])
    # CATCHES: GenerateParamsLayout is only entered when a placeholder was
    # found; with none the raw command is printed with no alt-screen UI.
    assert res.dialog is False
    assert b"\x1b[?1049h" not in res.tty
    assert (res.returncode, res.stdout, res.stderr) == (0, b"echo plain", b"")


def test_bare_placeholder_substitutes_empty(pet):
    """``<param>`` without '=' yields one empty field."""
    res = final(pet, "echo <a>")
    # CATCHES: a parameter without a default is pre-filled with the empty
    # string, so ENTER substitutes nothing and the two spaces collapse.
    assert (res.returncode, res.stdout, res.stderr) == (0, b"echo ", b"")


def test_placeholder_with_default_substitutes_default(pet):
    """``<param=default>`` pre-fills the field with the default value."""
    res = final(pet, "echo <a=one>")
    # CATCHES: the text after the first '=' is kept verbatim as the default
    # and is substituted unchanged when the field is left alone.
    assert (res.returncode, res.stdout) == (0, b"echo one")


def test_three_params_kept_in_first_seen_order(pet):
    """Each key gets its own field, in the order the keys first appear."""
    res = pet(["echo <a=1> <b> <c=3>"], ["search"])
    boxes = [b for b in res.screen.boxes() if not b[2].startswith("Command(")]
    # CATCHES: SearchForParams keeps first-seen order with one view per key,
    # and the bare key in the middle stays empty while both defaults are used.
    assert [b[2] for b in boxes] == ["a", "b", "c"]
    assert [box_text(b) for b in boxes] == ["1", "", "3"]
    assert final(pet, "echo <a=1> <b> <c=3>").stdout == b"echo 1  3"


def test_default_may_contain_spaces(pet):
    """A default may span spaces; only a trailing space makes it invalid."""
    res = final(pet, "echo '<p=Lots of Bananas>'")
    # CATCHES: everything up to the closing '>' is the default, spaces
    # included, as long as the last character is not whitespace.
    assert res.stdout == b"echo 'Lots of Bananas'"


def test_default_may_contain_equals_signs(pet):
    """Only the first '=' separates key from default."""
    res = final(pet, 'echo "<p=Hello == World!===>"')
    # CATCHES: strings.Cut splits at the first '=', so every later '=' is
    # part of the default value and survives the substitution.
    assert res.stdout == b'echo "Hello == World!==="'


def test_empty_angle_brackets_is_not_a_param(pet):
    """``<>`` is left alone and no dialog is shown."""
    res = pet(["echo <>"], ["search"])
    # CATCHES: the placeholder regex needs at least one non-space character
    # inside the brackets, so <> never becomes an editable field.
    assert res.dialog is False
    assert (res.returncode, res.stdout) == (0, b"echo <>")


def test_space_only_angle_brackets_is_not_a_param(pet):
    """``< >`` is not a parameter."""
    res = pet(["echo < >"], ["search"])
    # CATCHES: a bracket content that is only whitespace can never satisfy
    # the "must not end with whitespace" rule, so no dialog opens.
    assert res.dialog is False
    assert res.stdout == b"echo < >"


def test_default_of_only_space_is_not_a_param(pet):
    """``<a= >`` is left untouched."""
    res = pet(["echo <a= >"], ["search"])
    # CATCHES: a default consisting of a single space still ends in
    # whitespace, which the placeholder regex rejects.
    assert res.dialog is False
    assert res.stdout == b"echo <a= >"


def test_default_ending_with_space_is_not_a_param(pet):
    """``<a=abc >`` keeps its literal text."""
    res = pet(["echo <a=abc >"], ["search"])
    # CATCHES: only defaults that end with a non-space character are
    # placeholders; a trailing space makes the whole form literal text.
    assert res.dialog is False
    assert res.stdout == b"echo <a=abc >"


def test_param_name_may_contain_spaces(pet):
    """``<a b>`` *is* a parameter: inner spaces are allowed."""
    res = final(pet, "echo <a b>")
    # CATCHES: only the character before '>' must be non-space, so a key may
    # contain spaces; the whole key is then replaced by the field value.
    assert res.stdout == b"echo "


def test_param_name_with_spaces_and_default(pet):
    """``<a b=x y>`` splits the key at the first '=' only."""
    res = final(pet, "echo <a b=x y>")
    # CATCHES: the key is 'a b' and the default is 'x y'; the space inside
    # the key does not stop the placeholder from being recognised.
    assert res.stdout == b"echo x y"


def test_repeated_key_shows_one_field_last_default_wins(pet):
    """``<a=1> <a=2> <a=3>`` produces a single field pre-filled with 3."""
    res = pet(["echo <a=1> <a=2> <a=3>"], ["search"])
    boxes = [b for b in res.screen.boxes() if not b[2].startswith("Command(")]
    # CATCHES: repeated keys collapse into one view (first-seen order) while
    # the default of the last occurrence overwrites the earlier ones.
    assert [b[2] for b in boxes] == ["a"]
    assert box_text(boxes[0]) == "3"
    assert final(pet, "echo <a=1> <a=2> <a=3>").stdout == b"echo 3 3 3"


def test_repeated_key_bare_first_then_default(pet):
    """``<a> <a=2>``: the later default fills the single field."""
    res = final(pet, "echo <a> <a=2>")
    # CATCHES: a bare occurrence first and a defaulted one later still yield
    # one field, and the default is the one that is pre-filled.
    assert res.stdout == b"echo 2 2"


def test_repeated_key_default_first_then_bare(pet):
    """``<a=2> <a>``: the bare occurrence does not clear the default."""
    res = final(pet, "echo <a=2> <a>")
    # CATCHES: an existing key is never reset by a later bare placeholder,
    # so the default '2' is used for every occurrence.
    assert res.stdout == b"echo 2 2"


def test_every_occurrence_of_a_key_is_replaced(pet):
    """All three occurrences of ``<a>`` receive the typed value."""
    res = final(pet, "echo <a> x <a> y <a>", keys=("Q", ENTER))
    # CATCHES: insertParams replaces every whole-match occurrence of the
    # placeholder, not just the first one.
    assert res.stdout == b"echo Q x Q y Q"


def test_typed_value_replaces_default_prefix(pet):
    """Typing inserts at the cursor, which sits before the default text."""
    res = final(pet, "echo <a=one>", keys=("Z", ENTER))
    # CATCHES: the field cursor starts at column 0, so typed text is
    # prepended to the pre-filled default instead of appended.
    assert res.stdout == b"echo Zone"


def test_field_value_is_trimmed(pet):
    """Leading/trailing spaces typed into a field are dropped."""
    res = final(pet, "echo <p>", keys=("  spaced  ", ENTER))
    # CATCHES: evaluateParams TrimSpaces each view buffer, so outer blanks
    # typed by the user never reach the final command.
    assert res.stdout == b"echo spaced"


def test_field_value_keeps_inner_spaces(pet):
    """Spaces in the middle of a typed value are preserved."""
    res = final(pet, "echo <p>", keys=("a b c", ENTER))
    # CATCHES: only the outer whitespace is trimmed; inner spaces are kept
    # verbatim by the dialog's buffer handling.
    assert res.stdout == b"echo a b c"


def test_placeholder_key_with_slashes_and_dots(pet):
    """Keys are not restricted to identifiers."""
    res = final(pet, "echo <a.b/c>", keys=("v", ENTER))
    # CATCHES: any non-space, non-bracket characters may form a key, and the
    # view title plus substitution both use that exact key.
    assert res.stdout == b"echo v"


def test_empty_default_substitutes_empty(pet):
    """``<p=>`` is a valid parameter with an empty default."""
    res = final(pet, "echo <p=>")
    # CATCHES: an '=' directly before '>' still splits key from default, so
    # the field exists but is pre-filled with nothing.
    assert res.stdout == b"echo "


def test_default_starting_with_equals(pet):
    """``<p==x>`` keeps the second '=' as part of the default."""
    res = final(pet, "echo <p==x>")
    # CATCHES: strings.Cut only consumes the first '=', so '=x' is the
    # default and it is substituted unchanged.
    assert res.stdout == b"echo =x"


def test_unicode_default_is_preserved(pet):
    """Non-ASCII defaults survive the round trip."""
    res = final(pet, "echo <p=héllo wörld>")
    # CATCHES: the placeholder regex is byte/rune agnostic, so a UTF-8
    # default is pre-filled and substituted exactly as written.
    assert res.stdout == "echo héllo wörld".encode("utf-8")


def test_tab_in_default_becomes_four_spaces(pet):
    """A tab inside a default is widened to four spaces by the view."""
    res = final(pet, "echo <p=a\tb>")
    # CATCHES: only whitespace at the very end disqualifies a default, and a
    # tab in the middle is expanded to four spaces by the view buffer, which
    # is what ends up in the final command.
    assert res.stdout == b"echo a    b"


def test_param_across_newline_in_multiline_command(pet):
    """Placeholders on separate lines of a command are all filled."""
    res = final(pet, "echo one\necho <a=two>")
    # CATCHES: SearchForParams scans the whole multi-line command, and the
    # newlines of the command survive into the final command string.
    assert res.stdout == b"echo one\necho two"


def test_heredoc_with_angle_brackets(pet):
    """A command full of '<' and '>' still finds the real placeholder."""
    res = final(pet, "cat <<EOF > <file=path/to/file>\nEOF")
    # CATCHES: the '<' and '>' of the heredoc redirection do not confuse the
    # placeholder scan; only <file=...> is treated as a parameter.
    assert res.stdout == b"cat <<EOF > path/to/file\nEOF"


def test_nested_brackets_make_the_gt_part_of_the_key(pet):
    """``<a=<b>>`` is parsed as one parameter named ``b>``."""
    res = pet(["echo <a=<b>>"], ["search"])
    boxes = [b for b in res.screen.boxes() if not b[2].startswith("Command(")]
    # CATCHES: the regex cannot nest, so it matches '<b>' and greedily takes
    # the following '>' as the final character of the key.
    assert [b[2] for b in boxes] == ["b>"]
    # CATCHES: the whole match '<b>>' is replaced by the field value, which
    # leaves the outer '<a=' dangling in the final command.
    assert final(pet, "echo <a=<b>>").stdout == b"echo <a="


def test_nested_brackets_typed_value(pet):
    """Typing into the ``b>`` field of ``<a=<b>>`` replaces ``<b>>``."""
    res = final(pet, "echo <a=<b>>", keys=("hello", ENTER))
    # CATCHES: the substituted text lands where the whole match was, so the
    # result is '<a=hello' with the trailing '>' consumed as part of the key.
    assert res.stdout == b"echo <a=hello"


def test_default_starting_with_gt(pet):
    """``<a=>b>`` parses as key 'a' with the match ending at the first '>'."""
    res = final(pet, "echo <a=>b>")
    # CATCHES: the leftmost-shortest bracket content wins, so the match is
    # '<a=>' and the remaining 'b>' is plain command text.
    assert res.stdout == b"echo b>"


def test_value_containing_another_placeholder_cascades(pet):
    """A typed '<b>' is itself replaced by b's value."""
    res = final(pet, "<a> <b>", keys=("<b>", TAB, "X", ENTER))
    # CATCHES: insertParams replaces the placeholders one after another on
    # the evolving string, so text inserted for <a> is re-scanned for <b>.
    assert res.stdout == b"X X"


def test_cannot_type_a_literal_tab_into_a_field(pet):
    """TAB moves the focus instead of inserting a tab character."""
    res = final(pet, "echo <a> <b>", keys=("x", TAB, "y", ENTER))
    # CATCHES: TAB is bound to nextView for the whole gui, so it never
    # reaches the field editor and 'x' and 'y' land in different fields.
    assert res.stdout == b"echo x y"
