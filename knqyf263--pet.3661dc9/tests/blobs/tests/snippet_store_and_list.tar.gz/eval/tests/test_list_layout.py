"""Default (non-oneline) layout of `pet list`.

The default view prints, per snippet, 12-column right-aligned labels
``Description:``, ``Command:``, ``Tag:`` and ``Output:`` followed by a
30-dash separator; multiline commands and outputs are re-indented under the
first line.
"""

from conftest import SEPARATOR, run_pet, write_config, write_snippets


def _setup(tmp_path, body, **config):
    """Write one snippet file + config, return (cwd, config path)."""
    snippets = write_snippets(tmp_path, "snippet.toml", body)
    cfg = write_config(tmp_path, snippetfile=str(snippets), **config)
    return tmp_path, cfg


def test_full_snippet_prints_all_labels_and_separator(tmp_path):
    """A snippet with every field prints four labelled lines + separator."""
    # CATCHES: wrong label padding (the labels are right-aligned in 12
    # columns) or a wrong separator length would break the exact output.
    body = (
        '[[snippets]]\n'
        'description = "greeting"\n'
        'command = "echo hello"\n'
        'tag = ["demo"]\n'
        'output = "hello"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: greeting\n"
        "    Command: echo hello\n"
        "        Tag: demo\n"
        "     Output: hello\n"
        + SEPARATOR + "\n"
    ).encode()
    assert res.stderr == b""


def test_snippet_without_tags_omits_the_tag_line(tmp_path):
    """A snippet whose table has no tag key prints no Tag line at all."""
    # CATCHES: printing an empty "Tag:" line for untagged snippets (or
    # treating a missing key as an empty list) would add a bogus line.
    body = (
        '[[snippets]]\n'
        'description = "untagged"\n'
        'command = "true"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: untagged\n"
        "    Command: true\n"
        + SEPARATOR + "\n"
    ).encode()


def test_empty_tag_array_still_prints_an_empty_tag_line(tmp_path):
    """`tag = []` decodes to a non-nil empty slice, so a bare label prints."""
    # CATCHES: distinguishing `tag = []` from a missing tag key -- the empty
    # array still produces "Tag: " with a trailing space, unlike no key.
    body = (
        '[[snippets]]\n'
        'description = "empty tag array"\n'
        'command = "false"\n'
        'tag = []\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: empty tag array\n"
        "    Command: false\n"
        "        Tag: \n"
        + SEPARATOR + "\n"
    ).encode()


def test_missing_and_empty_output_both_omit_the_output_line(tmp_path):
    """`output = ""` and no output key both print no Output line."""
    # CATCHES: an implementation printing an empty "Output:" label for an
    # explicitly empty output string (rather than only for non-empty ones).
    body = (
        '[[snippets]]\n'
        'description = "no output key"\n'
        'command = "a"\n'
        '\n'
        '[[snippets]]\n'
        'description = "empty output string"\n'
        'command = "b"\n'
        'output = ""\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: no output key\n"
        "    Command: a\n"
        + SEPARATOR + "\n"
        "Description: empty output string\n"
        "    Command: b\n"
        + SEPARATOR + "\n"
    ).encode()


def test_multiline_command_prints_first_line_then_indented_rest(tmp_path):
    """A command containing newlines prints line 1 after the label and the
    remaining lines indented by 13 spaces to align under it."""
    # CATCHES: the continuation indent is 13 columns (a 12-wide right-aligned
    # blank plus the label separator space), not 12 or a tab.
    body = (
        '[[snippets]]\n'
        'description = "multiline command"\n'
        'command = "echo line1\\necho line2\\necho line3"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: multiline command\n"
        "    Command: echo line1\n"
        "             echo line2\n"
        "             echo line3\n"
        + SEPARATOR + "\n"
    ).encode()


def test_command_with_trailing_newline_prints_a_blank_continuation_line(tmp_path):
    """A command ending in a newline yields a final 13-space blank line."""
    # CATCHES: rstripping the command (or splitting differently) would drop
    # the trailing all-blank continuation line "             ".
    body = (
        '[[snippets]]\n'
        'description = "trailing newline"\n'
        'command = "echo a\\necho b\\n"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: trailing newline\n"
        "    Command: echo a\n"
        "             echo b\n"
        "             \n"
        + SEPARATOR + "\n"
    ).encode()


def test_multiline_output_is_reindented_like_the_command(tmp_path):
    """Every newline in the output is followed by 13 spaces of indent."""
    # CATCHES: output continuation lines must line up under the first output
    # line exactly like multiline command continuations do.
    body = (
        '[[snippets]]\n'
        'description = "multiline output"\n'
        'command = "x"\n'
        'output = "out1\\nout2\\nout3"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: multiline output\n"
        "    Command: x\n"
        "     Output: out1\n"
        "             out2\n"
        "             out3\n"
        + SEPARATOR + "\n"
    ).encode()


def test_output_with_embedded_blank_line_keeps_the_indent(tmp_path):
    """A blank line inside the output becomes a 13-space line, not empty."""
    # CATCHES: a plain newline replacement (no indent filler) would emit a
    # completely empty line instead of the 13-space one.
    body = (
        '[[snippets]]\n'
        'description = "blank line in output"\n'
        'command = "x"\n'
        'output = "line1\\n\\nline3"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: blank line in output\n"
        "    Command: x\n"
        "     Output: line1\n"
        "             \n"
        "             line3\n"
        + SEPARATOR + "\n"
    ).encode()


def test_empty_command_prints_an_empty_command_line(tmp_path):
    """`command = ""` prints "    Command: " including the trailing space."""
    # CATCHES: an implementation that strips trailing whitespace per line
    # would lose the space after the colon of the Command label.
    body = (
        '[[snippets]]\n'
        'description = "empty command"\n'
        'command = ""\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: empty command\n"
        "    Command: \n"
        + SEPARATOR + "\n"
    ).encode()


def test_missing_description_key_prints_an_empty_description(tmp_path):
    """A snippet table without a description key still lists, blank label."""
    # CATCHES: treating a missing description as a parse error or skipping
    # the snippet entirely instead of printing "Description: ".
    body = (
        '[[snippets]]\n'
        'command = "no description key"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: \n"
        "    Command: no description key\n"
        + SEPARATOR + "\n"
    ).encode()


def test_empty_snippets_table_prints_all_blank_fields(tmp_path):
    """A bare `[[snippets]]` header with no keys yields an empty snippet."""
    # CATCHES: skipping a keyless snippet table instead of listing it with
    # empty description and command labels.
    body = "[[snippets]]\n"
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: \n"
        "    Command: \n"
        + SEPARATOR + "\n"
    ).encode()


def test_multiline_description_is_printed_verbatim(tmp_path):
    """A description containing a newline is printed raw, breaking the
    single-line layout (no re-indentation is applied to it)."""
    # CATCHES: only command and output are re-indented; descriptions pass
    # through untouched, so the second line starts at column 0.
    body = (
        '[[snippets]]\n'
        'description = "multi\\nline desc"\n'
        'command = "z"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: multi\n"
        "line desc\n"
        "    Command: z\n"
        + SEPARATOR + "\n"
    ).encode()


def test_very_long_description_is_not_truncated_in_default_layout(tmp_path):
    """The default layout never truncates; only --oneline applies a column."""
    # CATCHES: applying the 40-column truncation outside --oneline mode.
    long_description = "L" * 200
    body = (
        '[[snippets]]\n'
        'description = "%s"\n'
        'command = "echo long"\n' % long_description
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: " + long_description + "\n"
        "    Command: echo long\n"
        + SEPARATOR + "\n"
    ).encode()


def test_multiple_tags_are_joined_with_single_spaces(tmp_path):
    """The tag array is rendered space separated on one Tag line."""
    # CATCHES: comma-separating tags or printing one Tag line per tag.
    body = (
        '[[snippets]]\n'
        'description = "many tags"\n'
        'command = "x"\n'
        'tag = ["one", "two", "three"]\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: many tags\n"
        "    Command: x\n"
        "        Tag: one two three\n"
        + SEPARATOR + "\n"
    ).encode()


def test_repeated_tag_value_is_printed_twice(tmp_path):
    """A tag array holding the same value twice prints it twice (no
    de-duplication happens on display)."""
    # CATCHES: de-duplicating tags before joining them.
    body = (
        '[[snippets]]\n'
        'description = "duptag"\n'
        'command = "x"\n'
        'tag = ["a", "a"]\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: duptag\n"
        "    Command: x\n"
        "        Tag: a a\n"
        + SEPARATOR + "\n"
    ).encode()


def test_tag_containing_a_space_is_printed_verbatim(tmp_path):
    """Tags are not split on whitespace: "foo bar" stays a single tag."""
    # CATCHES: splitting tag values on spaces when printing or filtering.
    body = (
        '[[snippets]]\n'
        'description = "tag with space"\n'
        'command = "echo sp"\n'
        'tag = ["foo bar"]\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: tag with space\n"
        "    Command: echo sp\n"
        "        Tag: foo bar\n"
        + SEPARATOR + "\n"
    ).encode()


def test_snippets_are_listed_in_file_order(tmp_path):
    """With no sortby configured the snippets appear exactly in file order."""
    # CATCHES: reordering snippets by description (or anything else) when
    # General.sortby is unset.
    body = (
        '[[snippets]]\n'
        'description = "beta"\n'
        'command = "echo b"\n'
        '\n'
        '[[snippets]]\n'
        'description = "alpha"\n'
        'command = "echo a"\n'
        '\n'
        '[[snippets]]\n'
        'description = "gamma"\n'
        'command = "echo g"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: beta\n"
        "    Command: echo b\n"
        + SEPARATOR + "\n"
        "Description: alpha\n"
        "    Command: echo a\n"
        + SEPARATOR + "\n"
        "Description: gamma\n"
        "    Command: echo g\n"
        + SEPARATOR + "\n"
    ).encode()


def test_empty_snippet_store_prints_nothing_and_exits_zero(tmp_path):
    """An existing but empty snippet file yields empty stdout, exit code 0."""
    # CATCHES: erroring out on (or printing something for) an empty store.
    cwd, cfg = _setup(tmp_path, "")
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_comment_only_snippet_file_is_an_empty_store(tmp_path):
    """A snippet file containing only TOML comments lists nothing, exit 0."""
    # CATCHES: rejecting a comment-only file as malformed TOML.
    cwd, cfg = _setup(tmp_path, "# just a comment\n\n")
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_unknown_keys_in_a_snippet_table_are_ignored(tmp_path):
    """Extra keys inside a [[snippets]] table do not error and are not
    printed."""
    # CATCHES: strict decoding that rejects unknown snippet-table keys with
    # "failed to parse snippet file."
    body = (
        '[[snippets]]\n'
        'description = "extra keys"\n'
        'command = "echo extra"\n'
        'tag = ["t"]\n'
        'unknown_key = "whatever"\n'
        'another = 42\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: extra keys\n"
        "    Command: echo extra\n"
        "        Tag: t\n"
        + SEPARATOR + "\n"
    ).encode()


def test_snippet_table_keys_are_matched_case_insensitively(tmp_path):
    """Upper-case DESCRIPTION/COMMAND/TAG/OUTPUT keys still populate the
    fields (go-toml matches struct field names case-insensitively)."""
    # CATCHES: a decoder that only accepts the lower-case key spellings
    # would list the snippet with every field empty instead.
    body = (
        '[[snippets]]\n'
        'DESCRIPTION = "upper"\n'
        'COMMAND = "echo up"\n'
        'TAG = ["T"]\n'
        'OUTPUT = "out"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: upper\n"
        "    Command: echo up\n"
        "        Tag: T\n"
        "     Output: out\n"
        + SEPARATOR + "\n"
    ).encode()


def test_toml_multiline_literal_command_is_supported(tmp_path):
    """A TOML multi-line basic string (\"\"\"...\"\"\") is decoded with its
    newlines intact; the newline right after the opening delimiter is
    trimmed per the TOML spec."""
    # CATCHES: not trimming the first newline of a \"\"\" string (which
    # would produce a leading blank continuation line) or refusing
    # multi-line strings in the command field entirely.
    body = (
        '[[snippets]]\n'
        'description = "literal multiline"\n'
        'command = """echo one\n'
        'echo two"""\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: literal multiline\n"
        "    Command: echo one\n"
        "             echo two\n"
        + SEPARATOR + "\n"
    ).encode()
