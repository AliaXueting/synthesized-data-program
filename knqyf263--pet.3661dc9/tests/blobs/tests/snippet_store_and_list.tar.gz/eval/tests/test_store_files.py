"""The multi-file snippet store: General.snippetfile plus General.snippetdirs.

Every ``*.toml`` file below each snippetdirs entry is collected recursively
(only the file *name* has to match ``*.toml``) and merged after the main
snippet file; ``--debug`` attributes each snippet to the file it came from.
"""

import pytest

from conftest import SEPARATOR, run_pet, write_config, write_snippets


def _store(tmp_path, extra_dirs=()):
    """Build a store: main.toml plus two nested snippet directories.

    Layout:
      main.toml            -> "from main"
      d/one.toml           -> "from one", "second in one"
      d/other/four.toml    -> "from four"
      d/sub/deep/three.toml-> "from three (deep)"
      d/sub/two.toml       -> "from two (nested)"
      d/notes.txt, d/other/readme.md -> not snippets
    """
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\ntag = ["m"]\n',
    )
    write_snippets(
        tmp_path,
        "d/one.toml",
        '[[snippets]]\ndescription = "from one"\ncommand = "echo one"\ntag = ["d"]\n'
        '\n'
        '[[snippets]]\ndescription = "second in one"\ncommand = "echo one2"\ntag = ["d", "x"]\n',
    )
    write_snippets(
        tmp_path,
        "d/sub/two.toml",
        '[[snippets]]\ndescription = "from two (nested)"\ncommand = "echo two"\n',
    )
    write_snippets(
        tmp_path,
        "d/sub/deep/three.toml",
        '[[snippets]]\ndescription = "from three (deep)"\ncommand = "echo three"\n',
    )
    write_snippets(
        tmp_path,
        "d/other/four.toml",
        '[[snippets]]\ndescription = "from four"\ncommand = "echo four"\n',
    )
    write_snippets(tmp_path, "d/notes.txt", "not a snippet file\n")
    write_snippets(tmp_path, "d/other/readme.md", "not a snippet file\n")
    dirs = [str(tmp_path / d) for d in extra_dirs] if extra_dirs else [str(tmp_path / "d")]
    cfg = write_config(
        tmp_path, snippetfile=str(tmp_path / "main.toml"), snippetdirs=dirs
    )
    return tmp_path, cfg


def test_main_file_comes_first_then_directory_snippets(tmp_path):
    """The main snippet file is always listed before any snippetdirs
    content, and --debug shows which file each snippet was loaded from."""
    # CATCHES: merging the directories before the main file, or losing the
    # per-file attribution of the merged snippets.
    cwd, cfg = _store(tmp_path)
    res = run_pet(["list", "--debug", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout.decode().splitlines() == [
        "   Filename: %s" % (tmp_path / "main.toml"),
        "Description: from main",
        "    Command: echo main",
        "        Tag: m",
        SEPARATOR,
        "   Filename: %s" % (tmp_path / "d" / "one.toml"),
        "Description: from one",
        "    Command: echo one",
        "        Tag: d",
        SEPARATOR,
        "   Filename: %s" % (tmp_path / "d" / "one.toml"),
        "Description: second in one",
        "    Command: echo one2",
        "        Tag: d x",
        SEPARATOR,
        "   Filename: %s" % (tmp_path / "d" / "other" / "four.toml"),
        "Description: from four",
        "    Command: echo four",
        SEPARATOR,
        "   Filename: %s" % (tmp_path / "d" / "sub" / "deep" / "three.toml"),
        "Description: from three (deep)",
        "    Command: echo three",
        SEPARATOR,
        "   Filename: %s" % (tmp_path / "d" / "sub" / "two.toml"),
        "Description: from two (nested)",
        "    Command: echo two",
        SEPARATOR,
    ]


def test_nested_subdirectories_are_walked_recursively(tmp_path):
    """Snippet files two levels below a snippetdirs entry are collected."""
    # CATCHES: only scanning the top level of each snippetdirs entry.
    cwd, cfg = _store(tmp_path)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert b"from three (deep)" in res.stdout
    assert b"from two (nested)" in res.stdout


def test_walk_order_is_lexicographic_per_directory(tmp_path):
    """Within one directory tree the files are visited in lexical order, so
    d/other/four.toml comes before d/sub/... and sub/deep before sub/two."""
    # CATCHES: walking directories in readdir (non-sorted) order instead of
    # the deterministic lexical order.
    cwd, cfg = _store(tmp_path)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    descriptions = [
        line.split(": ", 1)[1]
        for line in res.stdout.decode().splitlines()
        if line.startswith("Description:")
    ]
    assert descriptions == [
        "from main",
        "from one",
        "second in one",
        "from four",
        "from three (deep)",
        "from two (nested)",
    ]


def test_non_toml_files_are_ignored(tmp_path):
    """Only file names matching *.toml are collected; .txt and .md files in
    the same tree contribute nothing (and do not error)."""
    # CATCHES: trying to parse every regular file under snippetdirs (which
    # would fail on the plain-text files, or list six snippets plus more).
    cwd, cfg = _store(tmp_path)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    descriptions = [
        line.split(": ", 1)[1]
        for line in res.stdout.decode().splitlines()
        if line.startswith("Description:")
    ]
    assert descriptions == [
        "from main",
        "from one",
        "second in one",
        "from four",
        "from three (deep)",
        "from two (nested)",
    ]


@pytest.mark.parametrize(
    "name",
    [".toml", "up.TOML", "b.toml.bak", "xx.tomltoml", "no_ext"],
)
def test_only_plain_dot_toml_names_are_collected(tmp_path, name):
    """A file is collected only when its name matches *.toml exactly: no
    stem (.toml), upper-case extension, trailing suffix or no extension."""
    # CATCHES: case-insensitive or unanchored extension matching, which
    # would load the extra file and list its snippet too.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    write_snippets(
        tmp_path,
        "d/%s" % name,
        '[[snippets]]\ndescription = "IGNORED"\ncommand = "x"\n',
    )
    cfg = write_config(
        tmp_path, snippetfile=str(tmp_path / "main.toml"), snippetdirs=[str(tmp_path / "d")]
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: from main\n"
        "    Command: echo main\n"
        + SEPARATOR + "\n"
    ).encode()


def test_multiple_directories_are_merged_in_config_order(tmp_path):
    """snippetdirs entries are processed in the order they are listed, not
    alphabetically."""
    # CATCHES: sorting the snippetdirs entries before walking them.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    write_snippets(
        tmp_path,
        "zzz/late.toml",
        '[[snippets]]\ndescription = "late dir"\ncommand = "echo late"\n',
    )
    write_snippets(
        tmp_path,
        "aaa/early.toml",
        '[[snippets]]\ndescription = "early dir"\ncommand = "echo early"\n',
    )
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(tmp_path / "zzz"), str(tmp_path / "aaa")],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    descriptions = [
        line.split(": ", 1)[1]
        for line in res.stdout.decode().splitlines()
        if line.startswith("Description:")
    ]
    assert descriptions == ["from main", "late dir", "early dir"]


def test_empty_directory_contributes_nothing(tmp_path):
    """An existing but empty snippetdirs entry is fine and adds no
    snippets."""
    # CATCHES: erroring on an empty directory (e.g. by confusing it with a
    # missing one).
    (tmp_path / "emptydir").mkdir()
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "only main"\ncommand = "echo main"\n',
    )
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(tmp_path / "emptydir")],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: only main\n"
        "    Command: echo main\n"
        + SEPARATOR + "\n"
    ).encode()


def test_duplicate_directory_entries_duplicate_snippets(tmp_path):
    """Listing the same directory twice loads (and lists) its snippets
    twice; nothing de-duplicates them."""
    # CATCHES: de-duplicating collected snippet files across snippetdirs
    # entries.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    write_snippets(
        tmp_path,
        "d/f.toml",
        '[[snippets]]\ndescription = "from f"\ncommand = "echo f"\n',
    )
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(tmp_path / "d"), str(tmp_path / "d")],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    descriptions = [
        line.split(": ", 1)[1]
        for line in res.stdout.decode().splitlines()
        if line.startswith("Description:")
    ]
    assert descriptions == ["from main", "from f", "from f"]


def test_directory_entry_may_point_at_a_toml_file(tmp_path):
    """A snippetdirs entry that is itself a *.toml file is walked like a
    one-file directory and its snippets are merged (attributed to the
    absolute path of that file)."""
    # CATCHES: rejecting a file (rather than a directory) as a snippetdirs
    # entry, or skipping the walk root itself.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    write_snippets(
        tmp_path,
        "solo.toml",
        '[[snippets]]\ndescription = "solo file entry"\ncommand = "echo solo"\n',
    )
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(tmp_path / "solo.toml")],
    )
    res = run_pet(["list", "--debug", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout.decode().splitlines() == [
        "   Filename: %s" % (tmp_path / "main.toml"),
        "Description: from main",
        "    Command: echo main",
        SEPARATOR,
        "   Filename: %s" % (tmp_path / "solo.toml"),
        "Description: solo file entry",
        "    Command: echo solo",
        SEPARATOR,
    ]


def test_directory_entry_pointing_at_a_non_toml_file_is_ignored(tmp_path):
    """A snippetdirs entry that is a regular non-.toml file contributes
    nothing (the walk only matches *.toml names)."""
    # CATCHES: erroring because the entry is a file, or loading it anyway.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    write_snippets(tmp_path, "plain.txt", "plain text file\n")
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(tmp_path / "plain.txt")],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout.count(b"Description:") == 1


def test_directory_entry_below_a_non_directory_is_silently_skipped(tmp_path):
    """A snippetdirs entry whose parent is a regular file fails the stat
    with a non-'not exist' error, which is *ignored*: the walk then finds
    nothing and the listing still succeeds."""
    # CATCHES: treating any stat error on a snippetdirs entry as fatal
    # (only a plain 'not exist' produces the 'snippet directory not
    # found.' error).
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "only main"\ncommand = "echo main"\n',
    )
    plain = tmp_path / "plain.txt"
    plain.write_text("just a file\n", encoding="utf-8")
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(plain / "nodir")],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: only main\n"
        "    Command: echo main\n"
        + SEPARATOR + "\n"
    ).encode()


def test_debug_filename_for_main_file_is_the_config_value(tmp_path):
    """--debug reports the main file under the exact string from the
    config (here a relative value), while directory files are reported
    with their absolute walked path."""
    # CATCHES: normalizing the main snippet file to an absolute path in
    # the Filename line (the config string is echoed verbatim).
    write_snippets(
        tmp_path,
        "ippet.toml",
        '[[snippets]]\ndescription = "relative main"\ncommand = "echo rel"\n',
    )
    write_snippets(
        tmp_path,
        "d/f.toml",
        '[[snippets]]\ndescription = "dir snippet"\ncommand = "echo dir"\n',
    )
    # A relative snippetfile value has its first two characters dropped
    # when expanded against $HOME (see test_config_paths.py), so
    # "snippet.toml" resolves to <HOME>/ippet.toml.
    cfg = write_config(
        tmp_path,
        snippetfile="snippet.toml",
        snippetdirs=[str(tmp_path / "d")],
    )
    res = run_pet(["list", "--debug", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout.decode().splitlines() == [
        "   Filename: snippet.toml",
        "Description: relative main",
        "    Command: echo rel",
        SEPARATOR,
        "   Filename: %s" % (tmp_path / "d" / "f.toml"),
        "Description: dir snippet",
        "    Command: echo dir",
        SEPARATOR,
    ]


def test_oneline_mode_does_not_print_the_debug_filename(tmp_path):
    """--debug only adds Filename lines in the default layout; combined
    with --oneline nothing extra is printed."""
    # CATCHES: emitting the Filename line in oneline mode too.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "only"\ncommand = "echo only"\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "main.toml"))
    res = run_pet(
        ["list", "--oneline", "--debug", "--config", str(cfg)], tmp_path
    )
    assert res.returncode == 0
    assert res.stdout == ("only" + " " * 36 + " : echo only\n").encode()


def test_duplicate_descriptions_across_files_are_both_listed(tmp_path):
    """Two files holding snippets with the same description both list
    theirs (nothing keys snippets by description)."""
    # CATCHES: de-duplicating merged snippets by description.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "same text"\ncommand = "echo main"\n',
    )
    write_snippets(
        tmp_path,
        "d/f.toml",
        '[[snippets]]\ndescription = "same text"\ncommand = "echo dir"\n',
    )
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(tmp_path / "d")],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: same text\n"
        "    Command: echo main\n"
        + SEPARATOR + "\n"
        "Description: same text\n"
        "    Command: echo dir\n"
        + SEPARATOR + "\n"
    ).encode()
