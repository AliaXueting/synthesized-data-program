"""The `-t/--tags` filter of `pet list`.

`--tags a,b` keeps the snippets carrying ANY of the comma separated tags.
Snippets with no tags are always excluded from a filtered listing, tags are
matched exactly (case sensitive, no trimming) and an unknown tag produces
empty output with exit code 0.
"""

import pytest

from conftest import SEPARATOR, run_pet, write_config, write_snippets

# A small store covering the interesting tag shapes: a multi-tag snippet,
# an untagged one, an empty-array one and a tag containing a space.
STORE = (
    '[[snippets]]\n'
    'description = "multiline command"\n'
    'command = "echo one"\n'
    'tag = ["alpha", "beta"]\n'
    '\n'
    '[[snippets]]\n'
    'description = "no tags here"\n'
    'command = "true"\n'
    '\n'
    '[[snippets]]\n'
    'description = "empty tags array"\n'
    'command = "false"\n'
    'tag = []\n'
    '\n'
    '[[snippets]]\n'
    'description = "tag with space"\n'
    'command = "echo sp"\n'
    'tag = ["foo bar"]\n'
)


@pytest.fixture()
def store(tmp_path):
    """A configured four-snippet store; returns (cwd, config path)."""
    snippets = write_snippets(tmp_path, "snippet.toml", STORE)
    cfg = write_config(tmp_path, snippetfile=str(snippets))
    return tmp_path, cfg


def test_single_tag_keeps_only_matching_snippets(store):
    """-t with one tag keeps just the snippets carrying that exact tag."""
    # CATCHES: matching on substring (which would also keep "alphabet" for
    # the tag "alpha") or ignoring the flag entirely.
    cwd, cfg = store
    res = run_pet(["list", "-t", "alpha", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: multiline command\n"
        "    Command: echo one\n"
        "        Tag: alpha beta\n"
        + SEPARATOR + "\n"
    ).encode()


def test_comma_separated_tags_use_any_semantics(store):
    """-t beta,alpha keeps a snippet carrying either tag (no snippet is
    duplicated even when it matches several listed tags)."""
    # CATCHES: AND semantics over the listed tags, or emitting a snippet
    # once per matching tag.
    cwd, cfg = store
    res = run_pet(["list", "-t", "beta,alpha", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout.count(b"Description:") == 1
    assert b"multiline command" in res.stdout


def test_unknown_tag_prints_nothing_and_exits_zero(store):
    """A tag no snippet carries yields empty stdout and exit code 0."""
    # CATCHES: erroring out (or printing all snippets) for an unknown tag.
    cwd, cfg = store
    res = run_pet(["list", "-t", "nope", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_untagged_snippets_are_excluded_from_filtered_listings(store):
    """A snippet with no tag key never matches, even when other snippets
    do."""
    # CATCHES: letting untagged snippets pass through an active tag filter
    # (the listing would grow beyond the single matching snippet).
    cwd, cfg = store
    res = run_pet(["list", "-t", "beta", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: multiline command\n"
        "    Command: echo one\n"
        "        Tag: alpha beta\n"
        + SEPARATOR + "\n"
    ).encode()


def test_empty_tag_array_snippets_are_excluded_from_filtered_listings(store):
    """`tag = []` counts as having no tags for the filter."""
    # CATCHES: treating an empty tag array as "matches anything", which
    # would add the "empty tags array" snippet to the listing.
    cwd, cfg = store
    res = run_pet(["list", "-t", "beta", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout.decode().count("Description:") == 1
    assert "empty tags array" not in res.stdout.decode()


def test_tag_containing_a_space_matches_only_verbatim(store):
    """The tag "foo bar" is matched as one tag, spaces included."""
    # CATCHES: splitting the filter value on whitespace as well as commas.
    cwd, cfg = store
    res = run_pet(["list", "-t", "foo bar", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: tag with space\n"
        "    Command: echo sp\n"
        "        Tag: foo bar\n"
        + SEPARATOR + "\n"
    ).encode()


def test_partial_tag_words_do_not_match(store):
    """"foo" does not match the tag "foo bar" -- matching is exact."""
    # CATCHES: substring or word-prefix matching of tag values.
    cwd, cfg = store
    res = run_pet(["list", "-t", "foo", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == b""


def test_space_after_comma_is_part_of_the_tag(store):
    """No trimming happens: "-t alpha, beta" looks for the tag " beta"."""
    # CATCHES: trimming whitespace around each comma separated tag (which
    # would additionally match the snippet tagged "beta").
    cwd, cfg = store
    res = run_pet(["list", "-t", "alpha, beta", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: multiline command\n"
        "    Command: echo one\n"
        "        Tag: alpha beta\n"
        + SEPARATOR + "\n"
    ).encode()


def test_tag_matching_is_case_sensitive(tmp_path):
    """The tag "Foo" is not matched by the filter value "foo"."""
    # CATCHES: case folding tag values before comparing them.
    snippets = write_snippets(
        tmp_path,
        "snippet.toml",
        '[[snippets]]\ndescription = "cased"\ncommand = "x"\ntag = ["Foo"]\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(snippets))
    res = run_pet(["list", "-t", "foo", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    res = run_pet(["list", "-t", "Foo", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: cased\n"
        "    Command: x\n"
        "        Tag: Foo\n"
        + SEPARATOR + "\n"
    ).encode()


def test_empty_tag_flag_disables_filtering(store):
    """`-t ""` leaves the store unfiltered (the flag value is checked for
    emptiness, not just presence)."""
    # CATCHES: filtering by a single empty tag when the value is empty,
    # which would hide every snippet instead of none.
    cwd, cfg = store
    res = run_pet(["list", "-t", "", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: multiline command\n"
        "    Command: echo one\n"
        "        Tag: alpha beta\n"
        + SEPARATOR + "\n"
        "Description: no tags here\n"
        "    Command: true\n"
        + SEPARATOR + "\n"
        "Description: empty tags array\n"
        "    Command: false\n"
        "        Tag: \n"
        + SEPARATOR + "\n"
        "Description: tag with space\n"
        "    Command: echo sp\n"
        "        Tag: foo bar\n"
        + SEPARATOR + "\n"
    ).encode()


def test_empty_elements_in_tag_list_are_not_matches(store):
    """`-t alpha,,beta` behaves like `alpha,beta`: the empty element
    matches nothing (and empty-tag snippets stay hidden)."""
    # CATCHES: an empty filter element acting as a wildcard.
    cwd, cfg = store
    res = run_pet(["list", "-t", "alpha,,beta", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout.count(b"Description:") == 1
    assert b"multiline command" in res.stdout


def test_long_form_and_equals_syntax_of_the_tags_flag(store):
    """--tags and --tags=VALUE are accepted spellings of -t VALUE."""
    # CATCHES: registering only the short -t spelling of the flag.
    cwd, cfg = store
    for args in (["--tags", "alpha"], ["--tags=alpha"]):
        res = run_pet(["list"] + args + ["--config", str(cfg)], cwd)
        assert res.returncode == 0
        assert res.stdout.count(b"Description:") == 1
        assert b"multiline command" in res.stdout


def test_filtered_listing_keeps_the_configured_order(tmp_path):
    """The filter is applied after loading, so the surviving snippets keep
    their store order (here: file order)."""
    # CATCHES: re-sorting the filtered result (e.g. by description).
    body = (
        '[[snippets]]\n'
        'description = "zulu"\n'
        'command = "z"\n'
        'tag = ["t"]\n'
        '\n'
        '[[snippets]]\n'
        'description = "alpha"\n'
        'command = "a"\n'
        'tag = ["t"]\n'
    )
    snippets = write_snippets(tmp_path, "snippet.toml", body)
    cfg = write_config(tmp_path, snippetfile=str(snippets))
    res = run_pet(["list", "-t", "t", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    listed = [
        line
        for line in res.stdout.decode().splitlines()
        if line.startswith("Description:")
    ]
    assert listed == ["Description: zulu", "Description: alpha"]


def test_filter_applies_after_sorting(tmp_path):
    """Sorting happens at load time, so a filtered listing is still in the
    configured sort order (here: description-sorted, i.e. descending)."""
    # CATCHES: re-sorting the filtered survivors, or getting the sort
    # direction wrong (description sort is descending, so "two" is first).
    body = (
        '[[snippets]]\n'
        'description = "one"\n'
        'command = "echo 1"\n'
        'tag = ["t"]\n'
        '\n'
        '[[snippets]]\n'
        'description = "two"\n'
        'command = "echo 2"\n'
        'tag = ["t"]\n'
        '\n'
        '[[snippets]]\n'
        'description = "unfiltered"\n'
        'command = "echo 3"\n'
        'tag = ["other"]\n'
    )
    snippets = write_snippets(tmp_path, "snippet.toml", body)
    cfg = write_config(tmp_path, snippetfile=str(snippets), sortby="description")
    res = run_pet(["list", "-t", "t", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: two\n"
        "    Command: echo 2\n"
        "        Tag: t\n"
        + SEPARATOR + "\n"
        "Description: one\n"
        "    Command: echo 1\n"
        "        Tag: t\n"
        + SEPARATOR + "\n"
    ).encode()


def test_oneline_respects_the_tag_filter(store):
    """--oneline composes with -t and keeps the padded description column."""
    # CATCHES: the tag filter being ignored in oneline mode.
    cwd, cfg = store
    res = run_pet(
        ["list", "--oneline", "-t", "beta", "--config", str(cfg)], cwd
    )
    assert res.returncode == 0
    assert res.stdout == (
        "multiline command" + " " * 23 + " : echo one\n"
    ).encode()
