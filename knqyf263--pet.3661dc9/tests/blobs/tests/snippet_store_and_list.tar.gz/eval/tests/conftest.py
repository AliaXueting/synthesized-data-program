"""Shared black-box helpers for the snippet_store_and_list test module.

Every expectation embedded in this module's tests was recorded by running the
reference `pet` binary through its command line interface only.  Tests never
call into the binary's internals and never hardcode a path to it: the
executable location always comes from PROGRAMGYM_EXECUTABLE.

The module under test owns the TOML snippet store (``[[snippets]]`` tables
read from ``General.snippetfile`` plus every ``*.toml`` below the
``General.snippetdirs`` directories) and the non-interactive ``pet list``
view of it.
"""

import functools
import os
import pty
import select
import subprocess
import tempfile
import termios
import threading
import time
from pathlib import Path


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running 'list --help' once against a throwaway GOCOVERDIR, so
    the check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="pet-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "list", "--help"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def pet_executable():
    """Return the binary under test, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the pet binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but
    # the pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to
    # the module's uninstrumented copy before pytest starts, so the counters
    # would never be written and this module's coverage report would stay
    # empty.  During a coverage run (GOCOVERDIR present), when the assigned
    # binary is not itself instrumented, fall back to the instrumented build
    # the driver stages next to the module workspaces.  The staged file only
    # exists in that layout, so ordinary validation and release runs are
    # unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if staged.is_file() and _writes_counters(str(staged)):
            return str(staged)
    return path


def _pinned_env(cwd, env=None, home=None):
    """Build the child environment from scratch: no TTY, no color, no noise.

    HOME always points at the per-test sandbox directory (or the explicit
    'home' argument) so that ``~`` expansion and the default
    ``$HOME/.config/pet/config.toml`` lookup can never leak outside the
    test.  TERM / NO_COLOR are deliberately absent so color handling is
    fully controlled by the individual tests.
    """
    child = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
        "HOME": str(home if home is not None else cwd),
    }
    # Forwarded only so a coverage-instrumented binary can write its counters;
    # the pet behavior under test never reads these.
    for passthrough in ("GOCOVERDIR",):
        if os.environ.get(passthrough):
            child[passthrough] = os.environ[passthrough]
    if env:
        for key, value in env.items():
            if value is None:
                child.pop(key, None)
            else:
                child[key] = value
    return child


def run_pet(args, cwd, env=None, timeout=30, home=None):
    """Run the binary with 'args' and return the CompletedProcess result.

    stdin is always a pipe, stdout/stderr are always captured, so the program
    never sees a terminal (use run_pet_pty for the TTY cases).  'home'
    overrides the HOME the child sees (it defaults to the cwd).
    """
    return subprocess.run(
        [pet_executable()] + list(args),
        input=b"",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd),
        env=_pinned_env(cwd, env, home),
        timeout=timeout,
    )


def run_pet_pty(args, cwd, env=None, timeout=15.0, home=None):
    """Run the binary with stdout attached to a pseudo-terminal.

    Returns a CompletedProcess whose returncode/stdout/stderr describe the
    run.  The pty is created by the test itself with OPOST cleared, so the
    bytes the program writes are read back verbatim (plain "\\n", no "\\r\\n")
    and nothing is echoed into them.  fatih/color only emits ANSI sequences
    when stdout is a terminal, so this is how the colored layout is probed.
    """
    master, slave = pty.openpty()
    attrs = termios.tcgetattr(slave)
    attrs[1] &= ~termios.OPOST  # keep "\n" from turning into "\r\n"
    attrs[3] &= ~termios.ECHO  # keep our own input out of the output
    termios.tcsetattr(slave, termios.TCSANOW, attrs)

    proc = subprocess.Popen(
        [pet_executable()] + list(args),
        stdin=subprocess.DEVNULL,
        stdout=slave,
        stderr=subprocess.PIPE,
        cwd=str(cwd),
        env=_pinned_env(cwd, env, home),
    )
    os.close(slave)

    stderr_chunks = []

    def drain_stderr():
        stderr_chunks.append(proc.stderr.read())

    stderr_thread = threading.Thread(target=drain_stderr)
    stderr_thread.start()

    out = b""
    deadline = time.time() + timeout
    while time.time() < deadline:
        ready, _, _ = select.select([master], [], [], 0.1)
        if ready:
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break  # the child closed the terminal
            if not chunk:
                break
            out += chunk
        elif proc.poll() is not None:
            # No data and the child is gone: nothing more can arrive.
            break

    try:
        returncode = proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        returncode = proc.wait()

    stderr_thread.join(timeout)
    for stream in (proc.stdout, proc.stderr):
        try:
            stream.close()
        except Exception:
            pass
    try:
        os.close(master)
    except OSError:
        pass

    return subprocess.CompletedProcess(
        args, returncode, stdout=out, stderr=b"".join(stderr_chunks)
    )


def _toml_str(value):
    """Quote a python string as a TOML basic string."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def write_config(
    directory,
    snippetfile=None,
    snippetdirs=None,
    column=None,
    sortby=None,
    extra="",
):
    """Write a config.toml into 'directory' and return its path.

    Only the [General] keys this module cares about are emitted; unset
    arguments are omitted from the file entirely (which is itself a behavior
    under test, e.g. a missing snippetfile key).
    """
    lines = ["[General]"]
    if snippetfile is not None:
        lines.append("snippetfile = %s" % _toml_str(str(snippetfile)))
    if snippetdirs is not None:
        lines.append(
            "snippetdirs = [%s]"
            % ", ".join(_toml_str(str(d)) for d in snippetdirs)
        )
    if column is not None:
        lines.append("column = %d" % column)
    if sortby is not None:
        lines.append("sortby = %s" % _toml_str(str(sortby)))
    body = "\n".join(lines) + "\n"
    if extra:
        body += extra
    path = Path(directory) / "config.toml"
    path.write_text(body, encoding="utf-8")
    return path


def write_snippets(directory, name, body):
    """Write a snippet TOML 'body' into directory/name; return its path."""
    path = Path(directory) / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8")
    return path


# The 30-dash separator printed after every snippet in the default layout.
SEPARATOR = "-" * 30
