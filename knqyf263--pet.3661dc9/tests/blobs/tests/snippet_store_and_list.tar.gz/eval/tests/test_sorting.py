"""General.sortby ordering of the snippet store.

Unset (or "recency") keeps the file order; "-recency" reverses it; the
field sorts "command"/"description"/"output" are *descending* (an artifact
of the comparison being written with '>') and their "-"-prefixed spellings
are ascending.  A "+" prefix is the same as no prefix.
"""

import pytest

from conftest import run_pet, write_config, write_snippets

# Three snippets whose description, command and output all sort in a
# different relative order, so each sortby spelling is distinguishable.
# File order:      beta(zzz/o3), alpha(mmm/o1), gamma(aaa/o2)
BODY = (
    '[[snippets]]\n'
    'description = "beta"\n'
    'command = "zzz"\n'
    'output = "o3"\n'
    '\n'
    '[[snippets]]\n'
    'description = "alpha"\n'
    'command = "mmm"\n'
    'output = "o1"\n'
    '\n'
    '[[snippets]]\n'
    'description = "gamma"\n'
    'command = "aaa"\n'
    'output = "o2"\n'
)


@pytest.fixture()
def sorted_store(tmp_path):
    """A configured three-snippet store; returns (cwd, config path)."""
    snippets = write_snippets(tmp_path, "snippet.toml", BODY)
    cfg = write_config(tmp_path, snippetfile=str(snippets))
    return tmp_path, cfg


def _descriptions(res):
    """The ordered list of descriptions printed by a listing."""
    return [
        line.split(": ", 1)[1]
        for line in res.stdout.decode().splitlines()
        if line.startswith("Description:")
    ]


def _with_sortby(tmp_path, sortby):
    snippets = write_snippets(tmp_path, "snippet.toml", BODY)
    cfg = write_config(tmp_path, snippetfile=str(snippets), sortby=sortby)
    return tmp_path, cfg


def test_unset_sortby_keeps_file_order(sorted_store):
    """With no General.sortby the snippets appear in file order."""
    # CATCHES: imposing a default alphabetical order when sortby is unset.
    cwd, cfg = sorted_store
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["beta", "alpha", "gamma"]


@pytest.mark.parametrize("sortby", ["recency", "+recency", "bogus", "Recency"])
def test_recency_and_unknown_values_keep_file_order(tmp_path, sortby):
    """'recency', '+recency' and any unrecognized value are all no-ops."""
    # CATCHES: erroring on (or reversing for) an unknown sortby value.
    cwd, cfg = _with_sortby(tmp_path, sortby)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["beta", "alpha", "gamma"]


def test_minus_recency_reverses_file_order(tmp_path):
    """sortby = '-recency' lists the snippets back to front."""
    # CATCHES: reversing only per file instead of across the whole merged
    # store (checked again across files further below).
    cwd, cfg = _with_sortby(tmp_path, "-recency")
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["gamma", "alpha", "beta"]


@pytest.mark.parametrize("sortby", ["command", "+command"])
def test_command_sort_is_descending(tmp_path, sortby):
    """sortby = 'command' (and '+command') lists zzz before aaa."""
    # CATCHES: the counter-intuitive descending direction of the field
    # sorts, and the '+' prefix meaning 'same as no prefix'.
    cwd, cfg = _with_sortby(tmp_path, sortby)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["beta", "alpha", "gamma"]


def test_minus_command_sort_is_ascending(tmp_path):
    """sortby = '-command' lists aaa before zzz."""
    # CATCHES: '-' not actually flipping the direction of the command sort.
    cwd, cfg = _with_sortby(tmp_path, "-command")
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["gamma", "alpha", "beta"]


@pytest.mark.parametrize("sortby", ["description", "+description"])
def test_description_sort_is_descending(tmp_path, sortby):
    """sortby = 'description' (and '+description') lists gamma, beta,
    alpha."""
    # CATCHES: assuming the description sort is A-to-Z.
    cwd, cfg = _with_sortby(tmp_path, sortby)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["gamma", "beta", "alpha"]


def test_minus_description_sort_is_ascending(tmp_path):
    """sortby = '-description' lists alpha, beta, gamma."""
    # CATCHES: '-' not flipping the direction of the description sort.
    cwd, cfg = _with_sortby(tmp_path, "-description")
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["alpha", "beta", "gamma"]


@pytest.mark.parametrize("sortby", ["output", "+output"])
def test_output_sort_is_descending(tmp_path, sortby):
    """sortby = 'output' (and '+output') sorts by the output text, o3
    before o1."""
    # CATCHES: ignoring the output field or sorting it ascending.
    cwd, cfg = _with_sortby(tmp_path, sortby)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["beta", "gamma", "alpha"]


def test_minus_output_sort_is_ascending(tmp_path):
    """sortby = '-output' lists o1 before o3."""
    # CATCHES: '-' not flipping the direction of the output sort.
    cwd, cfg = _with_sortby(tmp_path, "-output")
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert _descriptions(res) == ["alpha", "gamma", "beta"]


def test_output_sort_puts_snippets_without_output_last(tmp_path):
    """A snippet with no output decodes to the empty string, which sorts
    after every non-empty output in the (descending) output sort."""
    # CATCHES: skipping or special-casing snippets that lack the sorted
    # field instead of sorting them by their empty value.
    body = (
        '[[snippets]]\n'
        'description = "has-out-b"\n'
        'command = "c1"\n'
        'output = "bbb"\n'
        '\n'
        '[[snippets]]\n'
        'description = "no-out"\n'
        'command = "c2"\n'
        '\n'
        '[[snippets]]\n'
        'description = "has-out-a"\n'
        'command = "c3"\n'
        'output = "aaa"\n'
    )
    snippets = write_snippets(tmp_path, "snippet.toml", body)
    cfg = write_config(tmp_path, snippetfile=str(snippets), sortby="output")
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert _descriptions(res) == ["has-out-b", "has-out-a", "no-out"]


def test_sorting_spans_the_whole_merged_store(tmp_path):
    """Sorting is applied to the merged main-file + directories result,
    not per file."""
    # CATCHES: sorting each snippet file separately and then concatenating
    # the blocks.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "m-middle"\ncommand = "b"\n',
    )
    write_snippets(
        tmp_path,
        "d/f.toml",
        '[[snippets]]\ndescription = "d-first"\ncommand = "c"\n',
    )
    write_snippets(
        tmp_path,
        "d/g.toml",
        '[[snippets]]\ndescription = "g-last"\ncommand = "a"\n',
    )
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(tmp_path / "d")],
        sortby="-command",
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert _descriptions(res) == ["g-last", "m-middle", "d-first"]


def test_sorting_applies_to_the_oneline_view(tmp_path):
    """--oneline shows the same sorted order as the default layout."""
    # CATCHES: sorting only the default (labelled) rendering.
    cwd, cfg = _with_sortby(tmp_path, "-description")
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout.decode().splitlines() == [
        "alpha" + " " * 35 + " : mmm",
        "beta" + " " * 36 + " : zzz",
        "gamma" + " " * 35 + " : aaa",
    ]
