"""The `--oneline` view of `pet list`.

Every snippet prints as `description : command` on a single line: the
description is truncated (with `...`) and space-padded to the configured
column width (General.column, default 40, measured in terminal display
width) and newlines inside the command are rendered as a literal `\\n`.
"""

import pytest

from conftest import run_pet, write_config, write_snippets


def _setup(tmp_path, body, **config):
    """Write one snippet file + config, return (cwd, config path)."""
    snippets = write_snippets(tmp_path, "snippet.toml", body)
    cfg = write_config(tmp_path, snippetfile=str(snippets), **config)
    return tmp_path, cfg


def test_oneline_pads_description_to_the_default_40_columns(tmp_path):
    """With no General.column the description column is 40 wide."""
    # CATCHES: a different default column width or forgetting the space
    # padding before the " : " separator.
    body = (
        '[[snippets]]\n'
        'description = "short"\n'
        'command = "echo hi"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == b"short" + b" " * 35 + b" : echo hi\n"
    assert res.stderr == b""


def test_oneline_description_of_exactly_40_columns_is_untouched(tmp_path):
    """A description whose display width equals the column is neither
    truncated nor padded."""
    # CATCHES: an off-by-one that truncates at exactly the column width.
    desc = "0123456789012345678901234567890123456789"  # 40 chars
    body = (
        '[[snippets]]\n'
        'description = "%s"\n'
        'command = "exactly40"\n' % desc
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (desc + " : exactly40\n").encode()


def test_oneline_truncates_descriptions_past_40_columns(tmp_path):
    """A 41-column description is cut to 37 characters plus '...'."""
    # CATCHES: the ellipsis is part of the budget, so 37 chars + "..." (40
    # total), not 40 chars + "...".
    desc = "01234567890123456789012345678901234567890"  # 41 chars
    body = (
        '[[snippets]]\n'
        'description = "%s"\n'
        'command = "exactly41"\n' % desc
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "0123456789012345678901234567890123456" + "..." + " : exactly41\n"
    ).encode()


def test_oneline_empty_description_is_padded_to_40_spaces(tmp_path):
    """An empty description becomes 40 spaces, so the line starts with the
    padding and still contains the ' : ' separator."""
    # CATCHES: collapsing the empty description to nothing (and thus
    # shifting the command to the left edge of the line).
    body = (
        '[[snippets]]\n'
        'description = ""\n'
        'command = "empty-desc"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == b" " * 40 + b" : empty-desc\n"


@pytest.mark.parametrize(
    "column,expected",
    [
        # a 30-char description truncated to 9 chars + "...", a 5-char one
        # padded out to the full 12-column width.
        (12, "a very lo... : cmd\nshort        : cmd\n"),
        # at 25 columns the long description keeps 22 chars + "...".
        (25, "a very long descriptio... : cmd\nshort                     : cmd\n"),
    ],
)
def test_oneline_uses_the_configured_column(tmp_path, column, expected):
    """General.column overrides the 40-column default for truncation and
    padding alike."""
    # CATCHES: honoring the config column for padding but not truncation
    # (or vice versa), or ignoring the key entirely.
    body = (
        '[[snippets]]\n'
        'description = "a very long description indeed"\n'
        'command = "cmd"\n'
        '\n'
        '[[snippets]]\n'
        'description = "short"\n'
        'command = "cmd"\n'
    )
    cwd, cfg = _setup(tmp_path, body, column=column)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == expected.encode()


def test_oneline_column_zero_falls_back_to_the_default_40(tmp_path):
    """General.column = 0 is treated as 'unset' and uses 40 columns."""
    # CATCHES: honoring a literal zero column (which would truncate every
    # description to bare "...").
    body = (
        '[[snippets]]\n'
        'description = "zero column config"\n'
        'command = "z"\n'
    )
    cwd, cfg = _setup(tmp_path, body, column=0)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "zero column config" + " " * 22 + " : z\n"
    ).encode()


@pytest.mark.parametrize("column", [3, 1, -5])
def test_oneline_tiny_columns_shrink_to_a_bare_ellipsis(tmp_path, column):
    """A column too small to hold the 3-dot tail yields just '...' with no
    padding."""
    # CATCHES: crashing, printing the untruncated description, or padding
    # past the column when the column is smaller than the ellipsis.
    body = (
        '[[snippets]]\n'
        'description = "truncated away"\n'
        'command = "x"\n'
    )
    cwd, cfg = _setup(tmp_path, body, column=column)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == b"... : x\n"


def test_oneline_truncates_wide_characters_by_display_width(tmp_path):
    """CJK characters count as two columns, so truncation and padding use
    display width, not the rune or byte count."""
    # CATCHES: measuring the description in characters or bytes instead of
    # terminal cells (which would keep 20 CJK runes = 40 cells and then pad
    # by 20 more spaces).
    body = (
        '[[snippets]]\n'
        'description = "日本語のスニペットです、これはとても長い説明文です"\n'
        'command = "echo cjk"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    # 18 CJK runes (36 cells) + "..." = 39 cells, padded by one space to 40.
    expected = "日本語のスニペットです、これはとても" + "..." + " "
    assert res.stdout == (expected + " : echo cjk\n").encode()


def test_oneline_counts_accented_letters_as_single_columns(tmp_path):
    """Precomposed accented letters and emoji count with their display
    width (1 for é, 2 for the coffee mug) when padding."""
    # CATCHES: padding by byte count (é is 2 bytes in UTF-8), which would
    # misalign the separator column.
    body = (
        '[[snippets]]\n'
        'description = "café ☕ unicode"\n'
        'command = "echo uni"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    # "café ☕ unicode" is 15 cells wide -> 25 padding spaces.
    assert res.stdout == ("café ☕ unicode" + " " * 25 + " : echo uni\n").encode()


def test_oneline_renders_command_newlines_as_literal_backslash_n(tmp_path):
    """A multiline command prints on one line with \\n in place of each
    newline."""
    # CATCHES: printing the raw newlines (which would break the one-line
    # invariant) or dropping the later lines entirely.
    body = (
        '[[snippets]]\n'
        'description = "multiline command"\n'
        'command = "echo line1\\necho line2\\necho line3"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "multiline command" + " " * 23 + " : echo line1\\necho line2\\necho line3\n"
    ).encode()


def test_oneline_with_empty_command_keeps_the_trailing_separator(tmp_path):
    """An empty command leaves a trailing space after the colon."""
    # CATCHES: stripping the trailing whitespace of the oneline line.
    body = (
        '[[snippets]]\n'
        'description = "has empty cmd"\n'
        'command = ""\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == ("has empty cmd" + " " * 27 + " : \n").encode()


def test_oneline_ignores_the_tag_and_output_fields(tmp_path):
    """Neither tags nor output appear in the oneline rendering."""
    # CATCHES: appending tags or output text to the oneline line.
    body = (
        '[[snippets]]\n'
        'description = "fields ignored"\n'
        'command = "c"\n'
        'tag = ["t1", "t2"]\n'
        'output = "some output"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == ("fields ignored" + " " * 26 + " : c\n").encode()


def test_oneline_does_not_truncate_the_command(tmp_path):
    """Only the description column is width limited; a long command prints
    in full."""
    # CATCHES: applying the same truncation to the command half of the line.
    long_command = "echo " + "k" * 90
    body = (
        '[[snippets]]\n'
        'description = "long cmd"\n'
        'command = "%s"\n' % long_command
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == ("long cmd" + " " * 32 + " : " + long_command + "\n").encode()


def test_oneline_prints_one_line_per_snippet_in_file_order(tmp_path):
    """Every snippet produces exactly one line and no separators."""
    # CATCHES: keeping the 30-dash separator between oneline entries.
    body = (
        '[[snippets]]\n'
        'description = "first"\n'
        'command = "echo 1"\n'
        '\n'
        '[[snippets]]\n'
        'description = "second"\n'
        'command = "echo 2"\n'
    )
    cwd, cfg = _setup(tmp_path, body)
    res = run_pet(["list", "--oneline", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "first" + " " * 35 + " : echo 1\n"
        "second" + " " * 34 + " : echo 2\n"
    ).encode()
