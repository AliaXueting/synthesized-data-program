"""Color handling of `pet list`.

The labels are printed through fatih/color helpers, which emit ANSI
sequences only when stdout is a terminal (and TERM is not "dumb" and
NO_COLOR is unset).  Piped runs -- like every other test in this module --
must contain no escape sequences at all.
"""

from conftest import run_pet, run_pet_pty, write_config, write_snippets

STORE = (
    '[[snippets]]\n'
    'description = "colored"\n'
    'command = "echo one"\n'
    'tag = ["t1"]\n'
    'output = "out"\n'
    '\n'
    '[[snippets]]\n'
    'description = "second"\n'
    'command = "echo two"\n'
)


def _store(tmp_path):
    snippets = write_snippets(tmp_path, "snippet.toml", STORE)
    cfg = write_config(tmp_path, snippetfile=str(snippets))
    return tmp_path, cfg


def test_piped_stdout_has_no_escape_sequences(tmp_path):
    """With stdout piped (not a TTY) the layout is plain text: no ANSI
    color codes anywhere."""
    # CATCHES: emitting the colored variant regardless of isatty, which
    # would embed \\x1b[9Xm sequences in every piped listing.
    cwd, cfg = _store(tmp_path)
    res = run_pet(["list", "--config", str(cfg)], cwd)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: colored\n"
        "    Command: echo one\n"
        "        Tag: t1\n"
        "     Output: out\n"
        "------------------------------\n"
        "Description: second\n"
        "    Command: echo two\n"
        "------------------------------\n"
    ).encode()


def test_tty_stdout_colors_each_label(tmp_path):
    """On a terminal each label is wrapped in its own ANSI color:
    description hi-green (92), command hi-yellow (93), tag hi-cyan (96),
    output hi-red (91)."""
    # CATCHES: wrong color codes per label, coloring the values instead of
    # the labels, or forgetting the reset sequence after each label.
    cwd, cfg = _store(tmp_path)
    res = run_pet_pty(
        ["list", "--config", str(cfg)], cwd, env={"TERM": "xterm"}
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "\x1b[92mDescription:\x1b[0m colored\n"
        "\x1b[93m    Command:\x1b[0m echo one\n"
        "\x1b[96m        Tag:\x1b[0m t1\n"
        "\x1b[91m     Output:\x1b[0m out\n"
        "------------------------------\n"
        "\x1b[92mDescription:\x1b[0m second\n"
        "\x1b[93m    Command:\x1b[0m echo two\n"
        "------------------------------\n"
    ).encode()


def test_tty_stdout_colors_the_oneline_halves(tmp_path):
    """In oneline mode the padded description is hi-green and the command
    hi-yellow; the ' : ' separator itself stays uncolored."""
    # CATCHES: coloring the whole line as one span (which would wrap the
    # separator too) or padding outside the color span.
    cwd, cfg = _store(tmp_path)
    res = run_pet_pty(
        ["list", "--oneline", "--config", str(cfg)], cwd, env={"TERM": "xterm"}
    )
    assert res.returncode == 0
    assert res.stdout == (
        "\x1b[92mcolored" + " " * 33 + "\x1b[0m : \x1b[93mecho one\x1b[0m\n"
        "\x1b[92msecond" + " " * 34 + "\x1b[0m : \x1b[93mecho two\x1b[0m\n"
    ).encode()


def test_tty_stdout_colors_the_debug_filename_red(tmp_path):
    """The --debug Filename line uses plain red (31), not a hi-intensity
    color."""
    # CATCHES: picking a different SGR code for the Filename label than
    # for the other labels.
    cwd, cfg = _store(tmp_path)
    res = run_pet_pty(
        ["list", "--debug", "--config", str(cfg)], cwd, env={"TERM": "xterm"}
    )
    assert res.returncode == 0
    expected_first_line = (
        "\x1b[31m   Filename:\x1b[0m %s\n" % (tmp_path / "snippet.toml")
    )
    assert res.stdout.startswith(expected_first_line.encode())


def test_no_color_env_disables_colors_on_a_tty(tmp_path):
    """A set NO_COLOR variable wins over the terminal detection."""
    # CATCHES: only checking isatty and ignoring the NO_COLOR convention.
    cwd, cfg = _store(tmp_path)
    res = run_pet_pty(
        ["list", "--config", str(cfg)],
        cwd,
        env={"TERM": "xterm", "NO_COLOR": "1"},
    )
    assert res.returncode == 0
    assert res.stdout == (
        "Description: colored\n"
        "    Command: echo one\n"
        "        Tag: t1\n"
        "     Output: out\n"
        "------------------------------\n"
        "Description: second\n"
        "    Command: echo two\n"
        "------------------------------\n"
    ).encode()


def test_term_dumb_disables_colors_on_a_tty(tmp_path):
    """TERM=dumb also forces the uncolored layout on a terminal."""
    # CATCHES: ignoring the TERM value when deciding whether to colorize.
    cwd, cfg = _store(tmp_path)
    res = run_pet_pty(
        ["list", "--config", str(cfg)], cwd, env={"TERM": "dumb"}
    )
    assert res.returncode == 0
    assert res.stdout == (
        "Description: colored\n"
        "    Command: echo one\n"
        "        Tag: t1\n"
        "     Output: out\n"
        "------------------------------\n"
        "Description: second\n"
        "    Command: echo two\n"
        "------------------------------\n"
    ).encode()


def test_multiline_command_continuations_are_not_colored(tmp_path):
    """On a TTY only the 'Command:' label is colored; the indented
    continuation lines of a multiline command are plain."""
    # CATCHES: colorizing each continuation line (or the indent) of a
    # multiline command instead of only the label line.
    body = (
        '[[snippets]]\n'
        'description = "ml"\n'
        'command = "echo one\\necho two"\n'
    )
    snippets = write_snippets(tmp_path, "snippet.toml", body)
    cfg = write_config(tmp_path, snippetfile=str(snippets))
    res = run_pet_pty(
        ["list", "--config", str(cfg)], tmp_path, env={"TERM": "xterm"}
    )
    assert res.returncode == 0
    assert res.stdout == (
        "\x1b[92mDescription:\x1b[0m ml\n"
        "\x1b[93m    Command:\x1b[0m echo one\n"
        "             echo two\n"
        "------------------------------\n"
    ).encode()
