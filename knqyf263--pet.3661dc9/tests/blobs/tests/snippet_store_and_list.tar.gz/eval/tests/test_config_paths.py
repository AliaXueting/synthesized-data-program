"""Config plumbing and path resolution of the snippet store.

The store is driven entirely by the config file: General.snippetfile names
the main file and General.snippetdirs the merged directories.  Relative
paths are expanded against $HOME by a routine that (faithfully to the
reference) drops the first two characters of any non-'~' relative value,
and the config file itself is found via --config, $PET_CONFIG_DIR or
$HOME/.config/pet/config.toml in that order.
"""

from conftest import SEPARATOR, run_pet, write_config, write_snippets


def test_relative_snippetfile_drops_its_first_two_characters(tmp_path):
    """A relative snippetfile value has its first two characters removed
    before being joined onto $HOME: "snippet.toml" reads <HOME>/ippet.toml."""
    # CATCHES: the sane implementation (join $HOME with the whole relative
    # path) -- the reference resolves to ippet.toml and finds nothing at
    # <HOME>/snippet.toml.
    # HOME is tmp_path while the process runs in tmp_path/work, so this
    # also pins that the expansion uses $HOME, not the working directory.
    work = tmp_path / "work"
    work.mkdir()
    write_snippets(
        tmp_path,
        "ippet.toml",
        '[[snippets]]\ndescription = "two chars dropped"\ncommand = "echo two"\n',
    )
    # A decoy at the path a correct implementation would use.
    write_snippets(
        tmp_path,
        "snippet.toml",
        '[[snippets]]\ndescription = "wrong file"\ncommand = "echo wrong"\n',
    )
    cfg = write_config(tmp_path, snippetfile="snippet.toml")
    res = run_pet(["list", "--config", str(cfg)], work, home=tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: two chars dropped\n"
        "    Command: echo two\n"
        + SEPARATOR + "\n"
    ).encode()


def test_relative_snippetfile_not_found_reports_the_configured_value(tmp_path):
    """When a relative snippetfile cannot be resolved the error names the
    original config string, not the mangled expansion."""
    # CATCHES: echoing the expanded path (with its first two characters
    # gone) in the 'snippet file not found.' message.
    cfg = write_config(tmp_path, snippetfile="relcheck/snippet.toml")
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "snippet file not found. relcheck/snippet.toml\n"
        "Please run 'pet configure' and provide a correct file path, or remove this\n"
        "if you only want to provide snippetdirs instead\n"
    ).encode()


def test_tilde_snippetfile_resolves_to_the_home_directory(tmp_path):
    """snippetfile = "~" resolves to $HOME itself, which exists but is a
    directory, so the load fails with the directory read error."""
    # CATCHES: rejecting "~" outright instead of expanding it to the home
    # directory (and then failing to read it as a file).
    cfg = write_config(tmp_path, snippetfile="~")
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "failed to load snippet file. read %s: is a directory\n" % tmp_path
    ).encode()


def test_tilde_slash_path_is_joined_onto_home(tmp_path):
    """snippetfile = "~/main.toml" reads <HOME>/main.toml."""
    # CATCHES: leaving the "~/" prefix in the path (the file would not be
    # found) or mangling "~/..." like other relative values.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "tilde resolved"\ncommand = "echo tilde"\n',
    )
    cfg = write_config(tmp_path, snippetfile="~/main.toml")
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: tilde resolved\n"
        "    Command: echo tilde\n"
        + SEPARATOR + "\n"
    ).encode()


def test_two_character_tilde_value_collapses_to_home(tmp_path):
    """snippetfile = "~x" is not "~" but is longer than one character, so
    everything after the second character is dropped and $HOME is used."""
    # CATCHES: rejecting "~x" as malformed instead of resolving it to
    # $HOME (the same directory read error follows).
    cfg = write_config(tmp_path, snippetfile="~x")
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "failed to load snippet file. read %s: is a directory\n" % tmp_path
    ).encode()


def test_single_character_relative_snippetfile_cannot_be_expanded(tmp_path):
    """A one-character relative value (other than "~") is rejected by the
    path resolver with the 'unknown path' message."""
    # CATCHES: joining any non-empty relative path onto $HOME -- only
    # values longer than one character take that route.
    cfg = write_config(tmp_path, snippetfile="x")
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == b"error resolving relative path - unknown path: x\n"


def test_relative_config_flag_value_is_mangled_the_same_way(tmp_path):
    """--config accepts a relative path, which is expanded against $HOME
    with the same two-character drop: "pet-cfg.toml" reads
    <HOME>/t-cfg.toml, not ./pet-cfg.toml."""
    # CATCHES: resolving the --config flag against the process working
    # directory instead of $HOME with the mangled expansion.
    work = tmp_path / "work"
    work.mkdir()
    write_snippets(
        tmp_path,
        "t-cfg.toml",
        '[General]\nsnippetfile = "%s"\n' % (tmp_path / "main.toml"),
    )
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "via mangled config"\ncommand = "echo cfg"\n',
    )
    # A decoy at the path a cwd-relative resolution would use.
    write_snippets(
        work,
        "pet-cfg.toml",
        '[General]\nsnippetfile = "%s"\n' % (tmp_path / "nope.toml"),
    )
    res = run_pet(["list", "--config", "pet-cfg.toml"], work, home=tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: via mangled config\n"
        "    Command: echo cfg\n"
        + SEPARATOR + "\n"
    ).encode()


def test_pet_config_dir_supplies_the_default_config(tmp_path):
    """Without --config the config is read from
    $PET_CONFIG_DIR/config.toml."""
    # CATCHES: only ever looking under $HOME/.config/pet.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "pet config dir"\ncommand = "echo pcd"\n',
    )
    conf_dir = tmp_path / "petconf"
    conf_dir.mkdir()
    write_config(conf_dir, snippetfile=str(tmp_path / "main.toml"))
    res = run_pet(["list"], tmp_path, env={"PET_CONFIG_DIR": str(conf_dir)})
    assert res.returncode == 0
    assert res.stdout == (
        "Description: pet config dir\n"
        "    Command: echo pcd\n"
        + SEPARATOR + "\n"
    ).encode()


def test_pet_config_dir_default_is_auto_created(tmp_path):
    """A fresh $PET_CONFIG_DIR makes pet write a default config.toml and an
    empty snippet file there, and the listing is empty with exit 0."""
    # CATCHES: failing to create (or to tolerate) the default configuration
    # when none exists yet.
    conf_dir = tmp_path / "fresh"
    res = run_pet(["list"], tmp_path, env={"PET_CONFIG_DIR": str(conf_dir)})
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (conf_dir / "config.toml").is_file()
    assert (conf_dir / "snippet.toml").is_file()
    # The generated config points the store at the created snippet file.
    generated = (conf_dir / "config.toml").read_text(encoding="utf-8")
    assert 'SnippetFile = "%s"' % (conf_dir / "snippet.toml") in generated


def test_config_flag_overrides_pet_config_dir(tmp_path):
    """An explicit --config wins over $PET_CONFIG_DIR."""
    # CATCHES: letting the environment variable take precedence over the
    # command line flag.
    write_snippets(
        tmp_path,
        "a.toml",
        '[[snippets]]\ndescription = "from flag config"\ncommand = "echo a"\n',
    )
    write_snippets(
        tmp_path,
        "b.toml",
        '[[snippets]]\ndescription = "from env config"\ncommand = "echo b"\n',
    )
    conf_dir = tmp_path / "petconf"
    conf_dir.mkdir()
    write_config(conf_dir, snippetfile=str(tmp_path / "b.toml"))
    flag_cfg = write_config(tmp_path, snippetfile=str(tmp_path / "a.toml"))
    res = run_pet(
        ["list", "--config", str(flag_cfg)],
        tmp_path,
        env={"PET_CONFIG_DIR": str(conf_dir)},
    )
    assert res.returncode == 0
    assert b"from flag config" in res.stdout
    assert b"from env config" not in res.stdout


def test_pet_config_dir_overrides_the_home_default(tmp_path):
    """When both are available, $PET_CONFIG_DIR wins over
    $HOME/.config/pet/config.toml."""
    # CATCHES: preferring the HOME location over the dedicated environment
    # variable.
    write_snippets(
        tmp_path,
        "a.toml",
        '[[snippets]]\ndescription = "from home config"\ncommand = "echo home"\n',
    )
    write_snippets(
        tmp_path,
        "b.toml",
        '[[snippets]]\ndescription = "from pet config dir"\ncommand = "echo pcd"\n',
    )
    home_conf = tmp_path / ".config" / "pet"
    home_conf.mkdir(parents=True)
    write_config(home_conf, snippetfile=str(tmp_path / "a.toml"))
    conf_dir = tmp_path / "petconf"
    conf_dir.mkdir()
    write_config(conf_dir, snippetfile=str(tmp_path / "b.toml"))
    res = run_pet(["list"], tmp_path, env={"PET_CONFIG_DIR": str(conf_dir)})
    assert res.returncode == 0
    assert res.stdout == (
        "Description: from pet config dir\n"
        "    Command: echo pcd\n"
        + SEPARATOR + "\n"
    ).encode()


def test_home_default_config_location_is_used(tmp_path):
    """Without --config or PET_CONFIG_DIR the config comes from
    $HOME/.config/pet/config.toml."""
    # CATCHES: looking somewhere other than $HOME/.config/pet.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "home config"\ncommand = "echo home"\n',
    )
    conf_dir = tmp_path / ".config" / "pet"
    conf_dir.mkdir(parents=True)
    write_config(conf_dir, snippetfile=str(tmp_path / "main.toml"))
    res = run_pet(["list"], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: home config\n"
        "    Command: echo home\n"
        + SEPARATOR + "\n"
    ).encode()


def test_home_default_config_is_created_when_missing(tmp_path):
    """With nothing configured at all, pet creates the default config and
    snippet file under $HOME/.config/pet and lists nothing."""
    # CATCHES: requiring a pre-existing configuration instead of
    # bootstrapping one.
    res = run_pet(["list"], tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / ".config" / "pet" / "config.toml").is_file()
    assert (tmp_path / ".config" / "pet" / "snippet.toml").is_file()


def test_config_keys_are_matched_case_insensitively(tmp_path):
    """SNIPPETFILE (upper case) populates the same config field as
    snippetfile."""
    # CATCHES: a config decoder that only accepts the lower-case key
    # spelling would end up with an empty snippetfile.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "upper config key"\ncommand = "echo up"\n',
    )
    cfg_path = tmp_path / "upper-config.toml"
    cfg_path.write_text(
        '[General]\nSNIPPETFILE = "%s"\n' % (tmp_path / "main.toml"),
        encoding="utf-8",
    )
    res = run_pet(["list", "--config", str(cfg_path)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: upper config key\n"
        "    Command: echo up\n"
        + SEPARATOR + "\n"
    ).encode()


def test_absolute_paths_work_with_home_unset(tmp_path):
    """The home directory is only consulted for relative values: with HOME
    unset and every path absolute, the listing still works."""
    # CATCHES: eagerly resolving $HOME (which would fail when it is not
    # set) even though no relative path needs it.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "no home needed"\ncommand = "echo nh"\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "main.toml"))
    res = run_pet(
        ["list", "--config", str(cfg)], tmp_path, env={"HOME": None}
    )
    assert res.returncode == 0
    assert res.stdout == (
        "Description: no home needed\n"
        "    Command: echo nh\n"
        + SEPARATOR + "\n"
    ).encode()


def test_home_unset_with_relative_snippetfile_is_fatal(tmp_path):
    """A relative snippetfile cannot be expanded when $HOME is unset; the
    resolver's two-line error goes to stdout with status 255."""
    # CATCHES: a different error message (or channel) when the home
    # directory is unavailable.
    cfg = write_config(tmp_path, snippetfile="snippet.toml")
    res = run_pet(
        ["list", "--config", str(cfg)], tmp_path, env={"HOME": None}
    )
    assert res.returncode == 255
    assert res.stdout == (
        "error resolving relative path - unknown home dir:\n"
        "$HOME is not defined\n"
    ).encode()
    assert res.stderr == b""


def test_home_unset_with_no_config_is_a_config_error(tmp_path):
    """With HOME unset and no --config/PET_CONFIG_DIR the default config
    directory cannot be built: stderr, exit 1, no trailing newline."""
    # CATCHES: the config bootstrap errors use the stderr/exit-1 channel,
    # unlike the store errors on stdout/255.
    res = run_pet(["list"], tmp_path, env={"HOME": None})
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        "error resolving relative path - unknown home dir:\n"
        "$HOME is not defined"
    ).encode()


def test_config_flag_is_accepted_before_the_subcommand(tmp_path):
    """--config is a persistent root flag, so it also works in front of
    the subcommand."""
    # CATCHES: registering --config only on the list command, which would
    # reject `pet --config X list` with an unknown-flag error.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "flagorder"\ncommand = "echo fo"\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "main.toml"))
    res = run_pet(["--config", str(cfg), "list", "--oneline"], tmp_path)
    assert res.returncode == 0
    assert res.stdout == ("flagorder" + " " * 31 + " : echo fo\n").encode()


def test_tags_flag_value_may_swallow_the_next_flag_token(tmp_path):
    """-t takes the next token as its value even when that token is the
    --config flag itself, so the config falls back to the default lookup."""
    # CATCHES: a flag parser that refuses a value starting with '--' for
    # -t (the reference consumes it, and the default config bootstrap then
    # kicks in under $HOME/.config/pet).
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "flagorder"\ncommand = "echo fo"\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "main.toml"))
    res = run_pet(["list", "-t", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    # The explicit config was never read; the default one was created.
    assert (tmp_path / ".config" / "pet" / "config.toml").is_file()
    assert (tmp_path / ".config" / "pet" / "snippet.toml").is_file()
