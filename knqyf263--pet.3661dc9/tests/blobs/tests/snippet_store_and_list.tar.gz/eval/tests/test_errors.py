"""Fatal error paths of the snippet store and how they are reported.

Every command that loads snippets dies when the main snippet file is
missing.  Those errors are printed by the cobra root command on *stdout*
with exit status 255, while a broken *config* file is reported on stderr
with exit status 1 -- two clearly different channels.
"""

import pytest

from conftest import run_pet, write_config, write_snippets


def test_missing_snippet_file_is_fatal_with_multiline_error(tmp_path):
    """A snippetfile that does not exist aborts with the three-line
    'snippet file not found.' message on stdout and exit status 255."""
    # CATCHES: printing the message on stderr, using exit code 1, or
    # rewrapping the three fixed lines differently.
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "nope.toml"))
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "snippet file not found. %s\n"
        "Please run 'pet configure' and provide a correct file path, or remove this\n"
        "if you only want to provide snippetdirs instead\n" % (tmp_path / "nope.toml")
    ).encode()
    assert res.stderr == b""


@pytest.mark.parametrize(
    "extra_args",
    [
        ["--oneline"],
        ["-t", "some-tag"],
        ["--debug"],
        ["--oneline", "-t", "x", "--debug"],
    ],
)
def test_missing_snippet_file_is_fatal_for_every_list_variant(
    tmp_path, extra_args
):
    """No flag combination recovers from a missing snippet file: the error
    precedes any rendering."""
    # CATCHES: a code path that renders an empty listing instead of
    # failing the load first.
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "nope.toml"))
    res = run_pet(["list"] + extra_args + ["--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert b"snippet file not found." in res.stdout
    assert res.stdout.count(b"\n") == 3


def test_empty_snippetfile_value_is_a_path_resolution_error(tmp_path):
    """`snippetfile = ""` cannot be expanded to an absolute path and fails
    with the path resolver's message."""
    # CATCHES: treating an empty snippetfile as "file missing" (wrong
    # message) or as an empty store (no error at all).
    cfg = write_config(tmp_path, snippetfile="")
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "error resolving relative path - unknown path: \n"
    ).encode()
    assert res.stderr == b""


def test_config_without_a_snippetfile_key_fails_the_same_way(tmp_path):
    """A config that never mentions snippetfile behaves like an empty
    value: the store cannot resolve a path."""
    # CATCHES: defaulting the missing key to $HOME/.config/pet/snippet.toml
    # (only the auto-created default config does that).
    cfg = write_config(tmp_path)
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "error resolving relative path - unknown path: \n"
    ).encode()


def test_snippet_file_that_is_a_directory_fails_to_load(tmp_path):
    """A snippetfile naming an existing directory passes the existence
    check but fails when read."""
    # CATCHES: stat-only existence checking without handling the
    # read-a-directory error path.
    (tmp_path / "adir").mkdir()
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "adir"))
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "failed to load snippet file. read %s: is a directory\n" % (tmp_path / "adir")
    ).encode()


def test_snippet_file_below_a_non_directory_fails_at_stat(tmp_path):
    """A snippetfile path whose parent is a regular file fails the initial
    stat with 'not a directory' -- a different error than a missing file."""
    # CATCHES: folding every stat failure into the 'snippet file not
    # found.' message instead of distinguishing non-NotExist errors.
    plain = tmp_path / "plain.txt"
    plain.write_text("just a file\n", encoding="utf-8")
    missing = tmp_path / "plain.txt" / "x.toml"
    cfg = write_config(tmp_path, snippetfile=str(missing))
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "failed to load snippet file. stat %s: not a directory\n" % missing
    ).encode()
    assert res.stderr == b""


def test_missing_snippet_directory_is_fatal(tmp_path):
    """A snippetdirs entry that does not exist aborts with 'snippet
    directory not found.' naming the configured value."""
    # CATCHES: skipping missing directories silently (which would list the
    # main file's snippets instead of failing).
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(tmp_path / "nodir")],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "snippet directory not found. %s\n" % (tmp_path / "nodir")
    ).encode()
    assert res.stderr == b""


def test_relative_snippet_directory_reports_the_configured_value(tmp_path):
    """A relative snippetdirs value cannot be resolved (and the error shows
    the original string, not the mangled expansion)."""
    # CATCHES: echoing the expanded (first-two-characters-dropped) path in
    # the error message instead of the configured one.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    cfg = write_config(
        tmp_path, snippetfile=str(tmp_path / "main.toml"), snippetdirs=["dirs"]
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == b"snippet directory not found. dirs\n"


def test_malformed_snippet_toml_is_a_parse_error(tmp_path):
    """An unterminated TOML string surfaces as 'failed to parse snippet
    file.' including go-toml's position information."""
    # CATCHES: a different (or missing) parse error message, or the wrong
    # stream/exit status for malformed snippet data.
    write_snippets(
        tmp_path,
        "bad.toml",
        '[[snippets]]\ndescription = "broken\ncommand = "unclosed\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "bad.toml"))
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "failed to parse snippet file. (2, 16): unescaped control character U+000A\n"
    ).encode()
    assert res.stderr == b""


def test_wrongly_typed_tag_is_a_parse_error(tmp_path):
    """A tag array holding integers fails to decode into []string."""
    # CATCHES: coercing non-string tag values (e.g. via fmt.Sprint) instead
    # of failing the decode.
    write_snippets(
        tmp_path,
        "numtag.toml",
        '[[snippets]]\ndescription = "numtags"\ncommand = "x"\ntag = [1, 2]\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "numtag.toml"))
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "failed to parse snippet file. (4, 1): Can't convert 1(int64) to string\n"
    ).encode()


def test_snippets_table_without_double_brackets_is_a_parse_error(tmp_path):
    """`[snippets]` (a plain table, not an array of tables) cannot be
    decoded into the snippet list and fails with a multi-line message."""
    # CATCHES: silently ignoring a non-array snippets table instead of
    # surfacing the decode error.
    write_snippets(
        tmp_path,
        "single.toml",
        '[snippets]\ndescription = "single"\ncommand = "echo single"\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "single.toml"))
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        'failed to parse snippet file. (1, 1): Can\'t convert command = "echo single"\n'
        'description = "single"\n'
        "(*toml.Tree) to a tree\n"
    ).encode()


def test_broken_symlink_in_snippet_dir_fails_to_load(tmp_path):
    """A dangling *.toml symlink inside a snippetdirs entry is collected
    (its name matches) and then fails to read."""
    # CATCHES: skipping unreadable files during the walk instead of
    # failing the load.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    d = tmp_path / "d"
    d.mkdir()
    (d / "gone.toml").symlink_to(tmp_path / "target-that-does-not-exist.toml")
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(d)],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "failed to load snippet file. open %s: no such file or directory\n"
        % (d / "gone.toml")
    ).encode()


def test_directory_named_toml_inside_snippet_dir_fails_to_load(tmp_path):
    """A directory whose *name* matches *.toml is collected by the walker
    and then fails to be read as a file."""
    # CATCHES: matching only regular files (f.Mode().IsRegular()) during
    # the walk -- the reference matches any directory entry name.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "from main"\ncommand = "echo main"\n',
    )
    d = tmp_path / "d"
    (d / "level1.toml").mkdir(parents=True)
    write_snippets(
        tmp_path,
        "d/zz.toml",
        '[[snippets]]\ndescription = "real file"\ncommand = "echo real"\n',
    )
    cfg = write_config(
        tmp_path,
        snippetfile=str(tmp_path / "main.toml"),
        snippetdirs=[str(d)],
    )
    res = run_pet(["list", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == (
        "failed to load snippet file. read %s: is a directory\n"
        % (d / "level1.toml")
    ).encode()


def test_malformed_config_is_reported_on_stderr_with_exit_one(tmp_path):
    """A config value of the wrong type is a *config* error: stderr, exit
    status 1, no trailing newline -- unlike the store errors."""
    # CATCHES: reporting config decode failures through the same
    # stdout/255 channel as the snippet store errors.
    cfg_path = tmp_path / "bad-config.toml"
    cfg_path.write_text(
        '[General]\nsnippetfile = "%s"\ncolumn = "wide"\n' % (tmp_path / "s.toml"),
        encoding="utf-8",
    )
    res = run_pet(["list", "--config", str(cfg_path)], tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"(3, 1): Can't convert wide(string) to int"


def test_config_flag_pointing_at_a_directory_fails_on_stderr(tmp_path):
    """--config naming a directory is a config-load error (stderr, exit
    1)."""
    # CATCHES: crashing or exiting with a different status when the config
    # path is a directory.
    d = tmp_path / "cfgdir"
    d.mkdir()
    res = run_pet(["list", "--config", str(d)], tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"read %s: is a directory" % d


def test_empty_config_file_behaves_like_no_snippetfile(tmp_path):
    """A zero-byte config file parses (to nothing) and then fails on the
    empty snippetfile, on stdout with status 255."""
    # CATCHES: rejecting an empty config file as a config parse error.
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text("", encoding="utf-8")
    res = run_pet(["list", "--config", str(cfg_path)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == b"error resolving relative path - unknown path: \n"
    assert res.stderr == b""


def test_unknown_flag_is_reported_on_stdout_with_status_255(tmp_path):
    """An unrecognized flag is a cobra error: 'unknown flag: ...' on
    stdout, exit status 255, and no usage dump."""
    # CATCHES: cobra's usual 'Error: ... + usage' output on stderr with
    # exit 2 (the root command silences both and prints the bare error).
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "x"\ncommand = "y"\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "main.toml"))
    res = run_pet(["list", "--bogus", "--config", str(cfg)], tmp_path)
    assert res.returncode == 255
    assert res.stdout == b"unknown flag: --bogus\n"
    assert res.stderr == b""


def test_positional_arguments_are_accepted_and_ignored(tmp_path):
    """`pet list` takes no positional arguments but tolerates any."""
    # CATCHES: rejecting extra arguments with a usage error.
    write_snippets(
        tmp_path,
        "main.toml",
        '[[snippets]]\ndescription = "x"\ncommand = "y"\n',
    )
    cfg = write_config(tmp_path, snippetfile=str(tmp_path / "main.toml"))
    res = run_pet(["list", "stray-arg", "--config", str(cfg)], tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "Description: x\n"
        "    Command: y\n"
        "------------------------------\n"
    ).encode()
