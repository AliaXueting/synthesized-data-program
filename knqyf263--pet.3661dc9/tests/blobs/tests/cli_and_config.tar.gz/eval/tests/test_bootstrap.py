"""First-run bootstrap: the default config.toml and snippet.toml.

When the resolved config file does not exist, pet creates the config
directory, writes a fully populated config.toml and creates an empty
snippet.toml in the *default* config dir.  The exact bytes written, the
directory mode, the editor defaulting chain and the "don't overwrite an
existing config" rule are all pinned here.
"""

import pytest
from conftest import (
    default_config_path,
    default_snippet_path,
    expected_default_config,
    make_empty_path,
    make_path_with_stub,
    run_pet,
)
from recorded import VERSION_LINE


def test_first_run_writes_the_complete_default_config(home, work):
    """A missing config.toml is created with every documented default."""
    # CATCHES: byte-for-byte the written file — leading blank line, the four
    # sections in alphabetical order, Column = 40, the long fzf SelectCmd,
    # backend/format/gist/gitlab defaults and the empty list values.
    res = run_pet(["version"], home, cwd=work, env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    cfg = default_config_path(home)
    assert cfg.exists()
    assert cfg.read_bytes() == expected_default_config(default_snippet_path(home))


def test_first_run_creates_an_empty_snippet_file(home, work):
    """The bootstrap also creates an empty snippet.toml next to the config."""
    # CATCHES: snippet.toml is created empty via os.Create, so an existing
    # file would be truncated — and a fresh one is zero bytes long.
    res = run_pet(["version"], home, cwd=work, env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    snip = default_snippet_path(home)
    assert snip.exists()
    assert snip.read_bytes() == b""
    assert snip.stat().st_size == 0


def test_snippet_file_goes_to_the_default_dir_not_to_config_flag(home, work):
    """With --config elsewhere, snippet.toml still lands in the default dir."""
    # CATCHES: the bootstrap hardcodes the default config dir for the snippet
    # file, so --config only moves config.toml; the SnippetFile line inside
    # the written config points at the default dir too.
    cfg = work / "mine.toml"
    res = run_pet(["--config", str(cfg), "version"], home, cwd=work,
                  env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert cfg.read_bytes() == expected_default_config(default_snippet_path(home))
    assert default_snippet_path(home).exists()
    assert not default_config_path(home).exists()
    assert list(work.iterdir()) == [cfg]


def test_second_run_does_not_rewrite_the_config(home, work):
    """An existing config is never overwritten, whatever the environment."""
    # CATCHES: the whole bootstrap block is skipped once config.toml exists, so
    # a hand-edited file survives a second run byte for byte.
    run_pet(["version"], home, cwd=work, env={"EDITOR": "first-editor"})
    cfg = default_config_path(home)
    assert cfg.exists()
    cfg.write_text("[General]\n  Column = 22\n")
    res = run_pet(["version"], home, cwd=work, env={"EDITOR": "second-editor"})
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert cfg.read_text() == "[General]\n  Column = 22\n"


def test_bootstrap_truncates_an_existing_snippet_file(home, work):
    """Missing config.toml but present snippet.toml: the latter is emptied."""
    # CATCHES: the snippet file is created with os.Create, which truncates, so
    # losing config.toml silently wipes existing snippets.
    snip = default_snippet_path(home)
    snip.parent.mkdir(parents=True)
    snip.write_text('[[snippets]]\n  description = "precious"\n')
    res = run_pet(["version"], home, cwd=work, env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert snip.read_bytes() == b""
    assert default_config_path(home).exists()


@pytest.mark.parametrize("editor", ["myeditor", "vi"])
def test_editor_default_comes_from_the_environment(home, work, editor):
    """$EDITOR is copied verbatim into the written config."""
    # CATCHES: only the environment is consulted — there is no fallback while
    # $EDITOR is non-empty, and the value is not validated in any way.
    res = run_pet(["version"], home, cwd=work, env={"EDITOR": editor})
    assert res.returncode == 0
    assert default_config_path(home).read_bytes() == expected_default_config(
        default_snippet_path(home), editor
    )


def test_editor_defaults_to_sensible_editor_when_it_is_on_path(
        tmp_path, home, work):
    """No $EDITOR: 'sensible-editor' is chosen when it is on PATH."""
    # CATCHES: the check is `sh -c 'command -v sensible-editor'` against the
    # child PATH, which the test pins to a directory holding only a stub.
    stub_path = make_path_with_stub(tmp_path / "stubs")
    res = run_pet(["version"], home, cwd=work, path=str(stub_path))
    assert res.returncode == 0
    assert b'  Editor = "sensible-editor"\n' in default_config_path(home).read_bytes()


def test_editor_defaults_to_vim_without_sensible_editor(tmp_path, home, work):
    """No $EDITOR and no sensible-editor on PATH: the default is 'vim'."""
    # CATCHES: the fallback chain ends at vim, so a PATH without the Debian
    # helper yields Editor = "vim" in the generated config.
    empty_path = make_empty_path(tmp_path / "empty")
    res = run_pet(["version"], home, cwd=work, path=str(empty_path))
    assert res.returncode == 0
    assert b'  Editor = "vim"\n' in default_config_path(home).read_bytes()


def test_pet_config_dir_config_points_its_snippetfile_there(home, work):
    """With $PET_CONFIG_DIR the SnippetFile default moves with it."""
    # CATCHES: the written SnippetFile is joined onto the default config dir,
    # so it follows $PET_CONFIG_DIR instead of staying under $HOME.
    pcd = home / "pcd"
    res = run_pet(["version"], home, cwd=work,
                  env={"PET_CONFIG_DIR": str(pcd), "EDITOR": "myeditor"})
    assert res.returncode == 0
    assert (pcd / "config.toml").read_bytes() == expected_default_config(
        pcd / "snippet.toml"
    )
