"""Path expansion (path/path.go) as it is observable through the CLI.

Every path pet consumes — the --config value, snippetfile, snippetdirs and the
sync targets — goes through NewAbsolutePath, whose relative branch is odd:
absolute paths pass through unchanged, '~' means the home dir, '~/x' means
$HOME/x, and *any other* relative path is joined to the home dir after its
first two characters are dropped.  These tests pin which file pet actually
touches for each spelling.
"""

from conftest import (
    default_snippet_path,
    expected_default_config,
    run_pet,
    write_config,
)
from recorded import LIST_DEBUG_TEMPLATE, VERSION_LINE

SNIPPET_TOML = (
    '[[snippets]]\n'
    '  description = "desc one"\n'
    '  command = "echo one"\n'
    '  tag = ["t1"]\n'
)


def test_bare_relative_config_path_drops_two_characters(home, work):
    """--config my.toml is created as $HOME/.toml, not ./my.toml."""
    # CATCHES: the relative branch joins home with value[2:], so 'my.toml'
    # loses its 'my' prefix; nothing is ever written to the working directory.
    res = run_pet(["--config", "my.toml", "version"], home, cwd=work,
                  env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert (home / ".toml").read_bytes() == expected_default_config(
        default_snippet_path(home)
    )
    assert not (work / "my.toml").exists()
    assert list(work.iterdir()) == []


def test_tilde_config_path_lands_in_home(home, work):
    """--config ~/chosen.toml is created as $HOME/chosen.toml."""
    # CATCHES: '~/x' is the supported relative spelling and produces the same
    # bootstrap output as an absolute path inside HOME.
    res = run_pet(["--config", "~/chosen.toml", "version"], home, cwd=work,
                  env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert (home / "chosen.toml").read_bytes() == expected_default_config(
        default_snippet_path(home)
    )


def test_absolute_config_path_passes_through_unchanged(home, work):
    """An absolute --config is used as-is, with no re-anchoring."""
    # CATCHES: absolute paths skip expansion entirely, so a file outside HOME
    # is used directly while nothing appears under HOME except the snippet
    # file the bootstrap always creates in the default dir.
    cfg = work / "abs.toml"
    res = run_pet(["--config", str(cfg), "version"], home, cwd=work,
                  env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert cfg.read_bytes() == expected_default_config(default_snippet_path(home))
    assert not (home / "abs.toml").exists()


def test_tilde_snippetfile_is_expanded_for_reading(home, work):
    """snippetfile = '~/s.toml' reads $HOME/s.toml."""
    # CATCHES: the expansion applies to config-supplied paths too, and the
    # Filename line printed under --debug still shows the raw '~/s.toml'.
    (home / "s.toml").write_text(SNIPPET_TOML)
    write_config(home, '[General]\n  snippetfile = "~/s.toml"\n')
    res = run_pet(["list", "--debug"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == LIST_DEBUG_TEMPLATE.replace(b"@SNIPPETFILE@", b"~/s.toml")


def test_bare_relative_snippetfile_drops_two_characters(home, work):
    """snippetfile = 'snips.toml' is read from $HOME/ips.toml."""
    # CATCHES: 'snips.toml' loses 'sn' and becomes $HOME/ips.toml — the file
    # actually named snips.toml right there is never read.
    (home / "ips.toml").write_text(SNIPPET_TOML)
    (home / "snips.toml").write_text(
        '[[snippets]]\n  description = "wrong file"\n  command = "echo wrong"\n'
    )
    write_config(home, '[General]\n  snippetfile = "snips.toml"\n')
    res = run_pet(["list"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == (
        b"Description: desc one\n"
        b"    Command: echo one\n"
        b"        Tag: t1\n"
        + b"-" * 30 + b"\n"
    )


def test_absolute_snippetfile_is_used_verbatim(home, work):
    """An absolute snippetfile outside HOME is read as written."""
    # CATCHES: no expansion happens for absolute paths, so a snippet file in
    # the working directory is picked up exactly as spelled.
    snip = work / "snips.toml"
    snip.write_text(SNIPPET_TOML)
    write_config(home, '[General]\n  snippetfile = "%s"\n' % snip)
    res = run_pet(["list", "--debug"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == LIST_DEBUG_TEMPLATE.replace(
        b"@SNIPPETFILE@", str(snip).encode()
    )
