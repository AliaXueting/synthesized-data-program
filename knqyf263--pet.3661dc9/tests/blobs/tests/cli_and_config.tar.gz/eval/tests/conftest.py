"""Shared black-box helpers for the pet `cli_and_config` test module.

The binary under test is only ever exercised through its command line: the
helpers here never import anything from it and never hardcode its location,
the path always comes from PROGRAMGYM_EXECUTABLE.  Every expected byte the
tests compare against lives in recorded.py and was captured by actually
running the reference binary.
"""

import functools
import os
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

# Make the sibling recorded.py module importable no matter how pytest was
# started (it holds every byte-exact expectation captured from the reference).
sys.path.insert(0, str(Path(__file__).resolve().parent))

# Environment variable pet reads for the snippet editor; tests set it
# explicitly whenever the recorded expectation depends on it.
EDITOR_ENV = "EDITOR"

# Environment variable that replaces $HOME/.config/pet wholesale.
PET_CONFIG_DIR_ENV = "PET_CONFIG_DIR"


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--help' once against a throwaway GOCOVERDIR and a
    throwaway HOME, so the check never touches the real counter directory
    and never leaves a config file behind.
    """
    with tempfile.TemporaryDirectory(prefix="pet-covprobe-") as probe:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"),
               "HOME": probe, "GOCOVERDIR": probe}
        try:
            subprocess.run([binary, "--help"], env=env,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=30)
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe).glob("covcounters.*"))


def pet_executable():
    """Return the pet binary under test, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the pet binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but the
    # pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to the
    # module's uninstrumented copy before pytest starts, so the counters would
    # never be written and this module's coverage report would stay empty.
    # During a coverage run (GOCOVERDIR present), when the assigned binary is
    # not itself instrumented, fall back to the instrumented build the driver
    # stages next to the module workspaces.  Ordinary validation runs have no
    # GOCOVERDIR and always test the binary they were given.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if staged.exists() and _writes_counters(str(staged)):
            return str(staged)
    return path


def base_env(home, extra=None, path=None):
    """Build the child environment from scratch: no TTY, no leakage.

    Only PATH/LANG/HOME are set plus whatever a test explicitly asks for, so
    EDITOR, PET_CONFIG_DIR, TERM and friends cannot leak in from the test
    process.  GOCOVERDIR is forwarded only so a coverage-instrumented binary
    can write its counters; pet's own behavior never reads it.
    """
    child = {
        "PATH": path if path is not None else os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
        "HOME": str(home),
    }
    # Coverage hook: forward GOCOVERDIR so an instrumented reference build can
    # drop its counter files (see INSTRUCTION.md).
    gocoverdir = os.environ.get("GOCOVERDIR")
    if gocoverdir:
        child["GOCOVERDIR"] = gocoverdir
    if extra:
        child.update(extra)
    return child


def run_pet(args, home, env=None, cwd=None, stdin=b"", path=None, timeout=30):
    """Run the binary with 'args' and return the CompletedProcess result.

    stdin is always a pipe and stdout/stderr are always captured, so the
    program never sees a terminal, and the working directory defaults to the
    test's scratch directory rather than the pytest invocation directory.
    """
    return subprocess.run(
        [pet_executable()] + [str(a) for a in args],
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=base_env(home, env, path),
        timeout=timeout,
    )


@pytest.fixture
def home(tmp_path):
    """A fresh, empty HOME directory for one test."""
    d = tmp_path / "home"
    d.mkdir()
    return d


@pytest.fixture
def work(tmp_path):
    """A fresh, empty working directory (pet's cwd) for one test."""
    d = tmp_path / "work"
    d.mkdir()
    return d


def default_config_dir(home):
    """The config directory pet uses without --config / PET_CONFIG_DIR."""
    return Path(home) / ".config" / "pet"


def default_config_path(home):
    return default_config_dir(home) / "config.toml"


def default_snippet_path(home):
    return default_config_dir(home) / "snippet.toml"


def write_config(home, text):
    """Write 'text' as $HOME/.config/pet/config.toml and return its path."""
    path = default_config_path(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path


def expected_default_config(snippetfile, editor="myeditor"):
    """The recorded first-run config.toml with the variable lines filled in."""
    from recorded import DEFAULT_CONFIG_TEMPLATE
    return (DEFAULT_CONFIG_TEMPLATE
            .replace(b"@SNIPPETFILE@", str(snippetfile).encode())
            .replace(b"@EDITOR@", str(editor).encode()))


def make_editor_recorder(directory, capture_name="editor-capture.txt"):
    """Create an editor script that records its argv and stdin to a file.

    Returns (script_path, capture_path).  The script always exits 0, so a run
    through it proves pet both built the command line and wired the streams.
    """
    directory = Path(directory)
    capture = directory / capture_name
    script = directory / "editor.sh"
    script.write_text(
        "#!/bin/sh\n"
        "{\n"
        '  printf "argc=%s\\n" "$#"\n'
        "  i=1\n"
        '  for a in "$@"; do printf "arg%d=%s\\n" "$i" "$a"; i=$((i+1)); done\n'
        '  printf "stdin=%s" "$(cat)"\n'
        "} > " + shlex.quote(str(capture)) + "\n"
    )
    script.chmod(0o755)
    return script, capture


def make_path_with_stub(directory, name="sensible-editor"):
    """Return a directory whose PATH contains only an executable 'name' stub."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    stub = directory / name
    stub.write_text("#!/bin/sh\nexit 0\n")
    stub.chmod(0o755)
    return directory


def make_empty_path(directory):
    """Return an empty directory usable as a PATH with no commands at all."""
    d = Path(directory) / "nothing-here"
    d.mkdir(parents=True)
    return d
