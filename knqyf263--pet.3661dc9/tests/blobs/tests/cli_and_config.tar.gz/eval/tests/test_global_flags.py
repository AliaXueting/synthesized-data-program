"""The two persistent flags: --config and --debug, in every spelling.

Both are registered on RootCmd as persistent flags, so they must be accepted
before the subcommand, after it, and in both '--flag value' and '--flag=value'
form.  --debug is observable through `pet list`, which prints an extra
Filename line for every snippet when it is on.
"""

import pytest
from conftest import (
    default_snippet_path,
    expected_default_config,
    run_pet,
    write_config,
)
from recorded import LIST_DEBUG_TEMPLATE, LIST_PLAIN_TEMPLATE, VERSION_LINE

# One snippet with a tag, so both the description and the Tag line render.
SNIPPET_TOML = (
    '[[snippets]]\n'
    '  description = "desc one"\n'
    '  command = "echo one"\n'
    '  tag = ["t1"]\n'
)


@pytest.fixture
def configured(home):
    """A config whose snippetfile is a one-snippet file inside HOME."""
    snips = home / "snips.toml"
    snips.write_text(SNIPPET_TOML)
    write_config(home, '[General]\n  snippetfile = "%s"\n' % snips)
    return snips


@pytest.mark.parametrize(
    "args",
    [
        pytest.param(["--debug", "list"], id="before-subcommand"),
        pytest.param(["list", "--debug"], id="after-subcommand"),
        pytest.param(["list", "--debug=true"], id="equals-form"),
    ],
)
def test_debug_flag_adds_the_filename_line(home, work, configured, args):
    """--debug in any position makes `pet list` print the Filename line."""
    # CATCHES: --debug is inherited by every subcommand, and the Filename line
    # shows the raw snippetfile value exactly as written in the config.
    res = run_pet(args, home, cwd=work)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == LIST_DEBUG_TEMPLATE.replace(
        b"@SNIPPETFILE@", str(configured).encode()
    )


def test_without_debug_there_is_no_filename_line(home, work, configured):
    """`pet list` without --debug prints no Filename line at all."""
    # CATCHES: the extra line is gated on the flag, not on the config, and the
    # rest of the rendering (label column, 30 dashes) stays identical.
    res = run_pet(["list"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == LIST_PLAIN_TEMPLATE.replace(
        b"@SNIPPETFILE@", str(configured).encode()
    )


def test_debug_false_keeps_the_list_output_plain(home, work, configured):
    """--debug=false parses and leaves `pet list` without the Filename line."""
    # CATCHES: the flag is a bool, so the '=value' spelling must be accepted
    # and an explicit false must behave exactly like leaving it out.
    res = run_pet(["--debug=false", "list"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == LIST_PLAIN_TEMPLATE.replace(
        b"@SNIPPETFILE@", str(configured).encode()
    )


def test_debug_true_still_runs_the_subcommand(home, work):
    """--debug=true parses and does not disturb the version output."""
    # CATCHES: '=true' is a valid bool spelling; the subcommand still runs and
    # the bootstrap still writes the default config.
    res = run_pet(["--debug=true", "version"], home, cwd=work,
                  env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert res.stderr == b""


@pytest.mark.parametrize(
    "args",
    [
        pytest.param(["--config", "{cfg}", "version"], id="space-form"),
        pytest.param(["--config={cfg}", "version"], id="equals-form"),
    ],
)
def test_config_flag_spellings(home, work, args):
    """--config <path> and --config=<path> both select the config file."""
    # CATCHES: both spellings bootstrap the same file, and its SnippetFile
    # still points at the default config dir rather than next to --config.
    cfg = work / "chosen.toml"
    res = run_pet(
        [a.replace("{cfg}", str(cfg)) for a in args], home, cwd=work,
        env={"EDITOR": "myeditor"},
    )
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert cfg.read_bytes() == expected_default_config(default_snippet_path(home))


def test_config_flag_accepted_after_the_subcommand(home, work):
    """`pet version --config <path>` is just as valid as the reverse order."""
    # CATCHES: persistent flags are merged into every subcommand's flag set,
    # so the order of flag and subcommand does not matter.
    cfg = work / "after.toml"
    res = run_pet(["version", "--config", str(cfg)], home, cwd=work,
                  env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert cfg.read_bytes() == expected_default_config(default_snippet_path(home))


def test_config_and_debug_combined(home, work):
    """--config and --debug can be combined in one command line."""
    # CATCHES: both persistent flags parse together, and the config written at
    # the --config location still carries every default value.
    cfg = work / "both.toml"
    res = run_pet(["--config", str(cfg), "--debug", "version"], home, cwd=work,
                  env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert res.stderr == b""
    assert cfg.read_bytes() == expected_default_config(default_snippet_path(home))
    assert default_snippet_path(home).exists()
