"""The completion surface: cobra's hidden __complete protocol and scripts.

misc/completions/zsh/_pet is a hand-maintained script that must enumerate the
same subcommands, flags and flag help strings as the real command surface (it
currently lacks `clip`).  The machine-readable mirror of that surface is the
hidden `__complete` command, so these tests pin its exact output for every
subcommand and flag, plus the four generated completion scripts.
"""

import pytest
from conftest import run_pet
from recorded import (
    COMPLETE_FLAGS,
    COMPLETE_PREFIX_MATCH,
    COMPLETE_ROOT_FLAGS,
    COMPLETE_SUBCOMMANDS,
    COMPLETE_SUBCOMMANDS_NO_DESC,
    COMPLETION_DIRECTIVE_STDERR,
    COMPLETION_SCRIPT_HEAD,
    COMPLETION_SCRIPT_TAIL,
)


def test_complete_lists_every_subcommand_with_its_description(home, work):
    """`pet __complete ''` enumerates all subcommands with their Short text."""
    # CATCHES: the hidden protocol is what the shipped zsh script drives; the
    # list must contain clip and completion too, in cobra's sorted order, and
    # ends with the ':4' directive on stdout plus a note on stderr.
    res = run_pet(["__complete", ""], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == COMPLETE_SUBCOMMANDS
    assert res.stderr == COMPLETION_DIRECTIVE_STDERR


def test_complete_without_descriptions(home, work):
    """`pet __completeNoDesc ''` prints the same names without the tab+text."""
    # CATCHES: the NoDesc variant strips only the description column; the
    # names, their order and the trailing directive stay identical.
    res = run_pet(["__completeNoDesc", ""], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == COMPLETE_SUBCOMMANDS_NO_DESC
    assert res.stderr == COMPLETION_DIRECTIVE_STDERR


def test_complete_filters_by_prefix(home, work):
    """`pet __complete con` narrows the list to the matching subcommands."""
    # CATCHES: prefix matching is done by the program itself, so 'con' yields
    # configure (and only configure) with its description attached.
    res = run_pet(["__complete", "con"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == COMPLETE_PREFIX_MATCH
    assert res.stderr == COMPLETION_DIRECTIVE_STDERR


def test_complete_lists_the_root_flags(home, work):
    """`pet __complete -` lists the persistent flags plus -h."""
    # CATCHES: the root offers exactly --config, --debug and --help/-h with
    # the same help strings the root help screen prints.
    res = run_pet(["__complete", "-"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == COMPLETE_ROOT_FLAGS
    assert res.stderr == COMPLETION_DIRECTIVE_STDERR


@pytest.mark.parametrize("sub", list(COMPLETE_FLAGS))
def test_complete_lists_the_flags_of_every_subcommand(home, work, sub):
    """`pet __complete <sub> -` lists inherited and local flags with help."""
    # CATCHES: this is the machine-readable mirror of the static zsh script in
    # misc/completions/zsh/_pet (which is missing clip): every flag name, its
    # shorthand and its help string must match the real command surface.
    res = run_pet(["__complete", sub, "-"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == COMPLETE_FLAGS[sub]
    assert res.stderr == COMPLETION_DIRECTIVE_STDERR


@pytest.mark.parametrize("shell", ["bash", "zsh", "fish", "powershell"])
def test_completion_script_generation(home, work, shell):
    """`pet completion <shell>` emits the cobra script for that shell."""
    # CATCHES: each script starts with its shell's distinctive header (the zsh
    # one with '#compdef pet') and ends with the registered completer.
    res = run_pet(["completion", shell], home, cwd=work)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout.startswith(COMPLETION_SCRIPT_HEAD[shell])
    assert res.stdout.endswith(COMPLETION_SCRIPT_TAIL[shell])
    assert len(res.stdout) > 1000
