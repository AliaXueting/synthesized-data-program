"""`pet configure`: re-opening the resolved config file in General.editor.

On unix the editor is invoked as `<editor> +0 <absolute config path>` through
`sh -c`, with stdin/stdout/stderr inherited.  When General.Cmd is set it
replaces the `sh -c` wrapper entirely.  A failing editor turns into a RunE
error: the exit status line is printed on stdout and the process exits 255.
"""

from conftest import (
    default_config_path,
    default_snippet_path,
    expected_default_config,
    make_editor_recorder,
    run_pet,
    write_config,
)
from recorded import (
    CONFIGURE_CAT_EDITOR_STDERR,
    CONFIGURE_CAT_EDITOR_STDOUT_TEMPLATE,
    CONFIGURE_EMPTY_EDITOR_STDERR,
    CONFIGURE_EMPTY_EDITOR_STDOUT,
)


def _editor_config(home, editor):
    return write_config(home, '[General]\n  editor = "%s"\n' % editor)


def test_configure_invokes_the_editor_with_line_zero_and_the_path(
        tmp_path, home, work):
    """The editor receives exactly two arguments: '+0' and the config path."""
    # CATCHES: the command line is built as '<editor> +0 <path>' and the path
    # is the *absolute* config file pet resolved, not the argv spelling.
    script, capture = make_editor_recorder(tmp_path)
    cfg = _editor_config(home, script)
    res = run_pet(["configure"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert capture.read_text() == "argc=2\narg1=+0\narg2=%s\nstdin=" % cfg


def test_configure_passes_its_stdin_to_the_editor(tmp_path, home, work):
    """pet's own stdin is wired straight through to the editor process."""
    # CATCHES: editFile hands os.Stdin to the child, so an interactive editor
    # would see the user's terminal input on the other end of the pipe.
    script, capture = make_editor_recorder(tmp_path)
    _editor_config(home, script)
    res = run_pet(["configure"], home, cwd=work, stdin=b"EDITOR-STDIN")
    assert res.returncode == 0
    assert capture.read_text().endswith("stdin=EDITOR-STDIN")


def test_configure_with_config_flag_opens_that_file(tmp_path, home, work):
    """--config decides which file the editor is pointed at."""
    # CATCHES: configure re-resolves the raw --config value, so the editor is
    # handed the same file pet loaded (and none other is touched).
    script, capture = make_editor_recorder(tmp_path)
    cfg = work / "chosen.toml"
    cfg.write_text('[General]\n  editor = "%s"\n' % script)
    res = run_pet(["--config", str(cfg), "configure"], home, cwd=work)
    assert res.returncode == 0
    assert capture.read_text() == "argc=2\narg1=+0\narg2=%s\nstdin=" % cfg
    assert not default_config_path(home).exists()


def test_configure_expands_a_bare_relative_config_path(tmp_path, home, work):
    """--config my.toml really opens $HOME/.toml (first two chars dropped)."""
    # CATCHES: every --config value goes through NewAbsolutePath, whose
    # relative branch joins home + value[2:], so 'my.toml' becomes '.toml'.
    script, capture = make_editor_recorder(tmp_path)
    (home / ".toml").write_text('[General]\n  editor = "%s"\n' % script)
    res = run_pet(["--config", "my.toml", "configure"], home, cwd=work)
    assert res.returncode == 0
    assert capture.read_text() == "argc=2\narg1=+0\narg2=%s/.toml\nstdin=" % home
    assert not (work / "my.toml").exists()


def test_configure_expands_a_tilde_config_path(tmp_path, home, work):
    """--config ~/x.toml opens $HOME/x.toml."""
    # CATCHES: '~/x' is the one relative form that is really supported; the
    # editor sees the expanded absolute path with no '~' left in it.
    script, capture = make_editor_recorder(tmp_path)
    (home / "tilde.toml").write_text('[General]\n  editor = "%s"\n' % script)
    res = run_pet(["--config", "~/tilde.toml", "configure"], home, cwd=work)
    assert res.returncode == 0
    assert capture.read_text() == "argc=2\narg1=+0\narg2=%s/tilde.toml\nstdin=" % home


def test_configure_with_an_empty_editor_fails(tmp_path, home, work):
    """An empty editor makes sh try to run '+0', which does not exist."""
    # CATCHES: the command line degenerates to ' +0 <path>'; dash reports
    # 'sh: 1: +0: not found' on stderr while pet's own error line
    # 'exit status 127' lands on stdout and the status becomes 255.
    _editor_config(home, "")
    res = run_pet(["configure"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == CONFIGURE_EMPTY_EDITOR_STDOUT
    assert res.stderr == CONFIGURE_EMPTY_EDITOR_STDERR


def test_configure_without_an_editor_key_fails_the_same_way(home, work):
    """A config that omits the editor key behaves like an empty string."""
    # CATCHES: an existing config file is never re-defaulted, so the editor
    # stays empty exactly as if it had been set to "".
    write_config(home, "[General]\n")
    res = run_pet(["configure"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == CONFIGURE_EMPTY_EDITOR_STDOUT
    assert res.stderr == CONFIGURE_EMPTY_EDITOR_STDERR


def test_configure_with_cat_dumps_the_config_and_fails(home, work):
    """editor=cat runs 'cat +0 <path>': it prints the file, then errors."""
    # CATCHES: '+0' is passed to the editor as a real argument, so cat treats
    # it as a missing file, prints the config to stdout and exits 1, which pet
    # relays as 'exit status 1' on stdout with status 255.
    cfg = _editor_config(home, "cat")
    res = run_pet(["configure"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == CONFIGURE_CAT_EDITOR_STDOUT_TEMPLATE.replace(
        b"@CONFIG@", cfg.read_bytes()
    )
    assert res.stderr == CONFIGURE_CAT_EDITOR_STDERR


def test_configure_runs_the_command_through_general_cmd(home, work):
    """General.cmd replaces the 'sh -c' wrapper with a fixed argv prefix."""
    # CATCHES: when cmd is set the whole '<editor> +0 <path>' string becomes a
    # single argument appended to cmd, so 'echo' just prints it.
    cfg = write_config(home, '[General]\n  editor = "myed"\n  cmd = ["echo"]\n')
    res = run_pet(["configure"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == ("myed +0 %s\n" % cfg).encode()
    assert res.stderr == b""


def test_configure_after_bootstrap_edits_the_new_file(tmp_path, home, work):
    """A fresh HOME: bootstrap writes the config, then configure opens it."""
    # CATCHES: the editor comes from $EDITOR via the bootstrap defaults, and
    # the file handed to it is the freshly written default config.
    script, _capture = make_editor_recorder(tmp_path)
    res = run_pet(["configure"], home, cwd=work, env={"EDITOR": str(script)})
    assert res.returncode == 0
    assert default_config_path(home).read_bytes() == expected_default_config(
        default_snippet_path(home), str(script)
    )
    assert default_snippet_path(home).exists()
