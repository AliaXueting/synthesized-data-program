"""Root command surface: bare invocation, help flags, per-command help text.

`pet` is a plain cobra application whose root command has no Run function, so
a bare invocation prints the usage listing; every subcommand (including the
cobra-built `help`, `completion` and the hidden `__complete` family) is
reachable from that listing.  These tests pin the exact bytes of each help
screen and which of those screens actually trigger the config bootstrap.
"""

import pytest
from conftest import default_config_path, run_pet
from recorded import (
    ROOT_HELP,
    SUBCOMMAND_HELP,
    UNKNOWN_HELP_TOPIC_STDERR,
    VERSION_LINE,
)

# Every argv spelling that prints the root usage on stdout with status 0.
ROOT_HELP_FORMS = [
    pytest.param([], id="bare"),
    pytest.param(["-h"], id="short-help"),
    pytest.param(["--help"], id="long-help"),
    pytest.param(["help"], id="help-subcommand"),
]


@pytest.mark.parametrize("args", ROOT_HELP_FORMS)
def test_root_help_is_identical_for_every_form(home, work, args):
    """`pet`, `pet -h`, `pet --help` and `pet help` print the same bytes."""
    # CATCHES: the usage block, the alphabetical command table (clip and the
    # cobra completion command included) and the trailing hint line must all
    # match exactly; any of them drifting shows up as a byte difference.
    res = run_pet(args, home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == ROOT_HELP
    assert res.stderr == b""


def test_bare_invocation_never_touches_the_filesystem(home, work):
    """A bare `pet` prints help without running the config bootstrap."""
    # CATCHES: cobra only runs the initializers for a runnable command and the
    # root command has none, so $HOME/.config must not be created at all.
    res = run_pet([], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == ROOT_HELP
    assert not (home / ".config").exists()
    assert list(work.iterdir()) == []


def test_help_subcommand_triggers_the_config_bootstrap(home, work):
    """`pet help` IS runnable, so it creates the default config first."""
    # CATCHES: unlike `pet --help`, `pet help` executes a command and therefore
    # runs initConfig, which writes $HOME/.config/pet/config.toml.
    res = run_pet(["help"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == ROOT_HELP
    assert default_config_path(home).exists()


@pytest.mark.parametrize("sub", list(SUBCOMMAND_HELP))
def test_subcommand_help_via_flag_and_via_help(home, work, sub):
    """`<sub> --help` and `pet help <sub>` print identical per-command help."""
    # CATCHES: each screen carries that command's Short/Long text, its Usage
    # line, its own flags, and the inherited --config/--debug global block.
    via_flag = run_pet([sub, "--help"], home, cwd=work)
    via_help = run_pet(["help", sub], home, cwd=work)
    assert via_flag.returncode == 0
    assert via_help.returncode == 0
    assert via_flag.stdout == SUBCOMMAND_HELP[sub]
    assert via_help.stdout == SUBCOMMAND_HELP[sub]
    assert via_flag.stderr == b""
    assert via_help.stderr == b""


def test_subcommand_short_help_matches_long_help(home, work):
    """`pet configure -h` and `pet configure --help` are byte-identical."""
    # CATCHES: -h and --help share one flag, so the two screens cannot drift
    # apart the way a hand-rolled help printer would let them.
    short = run_pet(["configure", "-h"], home, cwd=work)
    long = run_pet(["configure", "--help"], home, cwd=work)
    assert short.returncode == 0
    assert long.returncode == 0
    assert short.stdout == long.stdout == SUBCOMMAND_HELP["configure"]


def test_unknown_help_topic_is_reported_on_stderr(home, work):
    """`pet help bogus` prints an unknown-topic report on stderr, exit 0."""
    # CATCHES: the topic is rendered with Go's %#q back quoting as [`bogus`],
    # goes to stderr (not stdout) and still exits 0.
    res = run_pet(["help", "bogus"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == UNKNOWN_HELP_TOPIC_STDERR


def test_unknown_help_topic_usage_omits_the_help_flag(home, work):
    """The usage block after an unknown help topic has no -h/--help entry."""
    # CATCHES: root's help flag is registered lazily, so this usage block is
    # missing the 'help for pet' line that `pet --help` itself shows.
    res = run_pet(["help", "bogus"], home, cwd=work)
    assert res.returncode == 0
    assert res.stderr == UNKNOWN_HELP_TOPIC_STDERR
    assert b"-h, --help            help for pet" not in res.stderr
    assert b"-h, --help            help for pet" in ROOT_HELP


def test_version_prints_the_build_string(home, work):
    """`pet version` prints exactly one line: 'pet version <build>'."""
    # CATCHES: the build identifier is baked into the binary at compile time;
    # a re-implementation that ships 'dev' or a different hash fails here.
    res = run_pet(["version"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert res.stderr == b""


def test_version_ignores_extra_arguments(home, work):
    """`pet version not-a-flag` still prints the version and exits 0."""
    # CATCHES: the version command does not validate its arguments, but the
    # config bootstrap still ran (config.toml exists afterwards).
    res = run_pet(["version", "not-a-flag"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert default_config_path(home).exists()


def test_completion_parent_help(home, work):
    """`pet completion --help` documents the four shell subcommands."""
    # CATCHES: the completion command is provided by cobra itself; its help
    # must list bash/fish/powershell/zsh plus the global flags.
    res = run_pet(["completion", "--help"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == SUBCOMMAND_HELP["completion"]
    assert res.stderr == b""


def test_completion_with_unknown_shell_shows_parent_help(home, work):
    """`pet completion bogus` is not an error: it prints the parent help."""
    # CATCHES: the completion command has no Run of its own, so an unknown
    # shell falls through to the help screen with status 0 and, because no
    # command ran, without creating a config file.
    res = run_pet(["completion", "bogus"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == SUBCOMMAND_HELP["completion"]
    assert res.stderr == b""
    assert not (home / ".config").exists()
