"""Byte-exact expectations recorded from the reference `pet` binary.

Every constant below was captured by running the reference binary through its
command line only (fresh temporary HOME, pinned environment) and dumping the
raw stdout/stderr bytes.  Constants whose name ends in _TEMPLATE contain an
@...@ placeholder where the recording contained a path that changes per run;
tests substitute the path of the file they created.
"""
# Exact stdout of `pet version` (the build hash baked into the binary).
VERSION_LINE = b"""pet version 3661dc9cb080bf48343e2d7f56a75abd3864c1d6
"""

# Exact stdout printed by `pet`, `pet -h`, `pet --help` and `pet help`.
# (identical bytes for all four; stderr stays empty, exit status 0)
ROOT_HELP = b"""pet - Simple command-line snippet manager.

Usage:
  pet [command]

Available Commands:
  clip        Copy the selected commands
  completion  Generate the autocompletion script for the specified shell
  configure   Edit config file
  edit        Edit snippet file
  exec        Run the selected commands
  help        Help about any command
  list        Show all snippets
  new         Create a new snippet
  search      Search snippets
  sync        Sync snippets
  version     Print the version number

Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
  -h, --help            help for pet

Use "pet [command] --help" for more information about a command.
"""

# Exact stdout of `<subcommand> --help` (and of `pet help <subcommand>`).
SUBCOMMAND_HELP = {
    "clip": b"""Copy the selected commands to clipboard

Usage:
  pet clip [flags]

Flags:
      --command            Display snippets in one line
  -d, --delimiter string   Use delim as the command delimiter character (default "; ")
  -h, --help               help for clip
  -q, --query string       Initial value for query
      --raw                Output raw command without entering parameter dialog
  -t, --tag string         Filter tag

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "completion": b"""Generate the autocompletion script for pet for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  pet completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode

Use "pet completion [command] --help" for more information about a command.
""",
    "configure": b"""Edit config file (default: opened by vim)

Usage:
  pet configure [flags]

Flags:
  -h, --help   help for configure

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "edit": b"""Edit snippet file (default: opened by vim)

Usage:
  pet edit [flags]

Flags:
  -h, --help           help for edit
  -q, --query string   Initial value for query
  -t, --tag string     Filter tag

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "exec": b"""Run the selected commands directly

Usage:
  pet exec [flags]

Flags:
      --color          Enable colorized output (only fzf)
  -h, --help           help for exec
  -q, --query string   Initial value for query
  -s, --silent         Suppress the command output
  -t, --tag string     Filter tag

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "help": b"""Help provides help for any command in the application.
Simply type pet help [path to command] for full details.

Usage:
  pet help [command] [flags]

Flags:
  -h, --help   help for help

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "list": b"""Show all snippets

Usage:
  pet list [flags]

Flags:
  -h, --help          help for list
      --oneline       Display snippets in one line
  -t, --tags string   list by specified tags as comma separated values

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "new": b"""Create a new snippet (default: $HOME/.config/pet/snippet.toml)

Usage:
  pet new COMMAND [flags]

Flags:
  -e, --editor      Use editor to create snippet
  -h, --help        help for new
  -m, --multiline   Can enter multiline snippet (Double \\n to quit)
  -t, --tag         Display tag prompt (delimiter: space)

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "search": b"""Search snippets interactively (default filtering tool: peco)

Usage:
  pet search [flags]

Flags:
      --color              Enable colorized output (only fzf)
  -d, --delimiter string   Use delim as the command delimiter character (default "; ")
  -h, --help               help for search
  -q, --query string       Initial value for query
      --raw                Output raw command without entering parameter dialog
  -t, --tag string         Filter tag

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "sync": b"""Sync snippets with gist/gitlab

Usage:
  pet sync [flags]

Flags:
  -h, --help   help for sync

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
    "version": b"""Print the version number

Usage:
  pet version [flags]

Flags:
  -h, --help   help for version

Global Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode
""",
}
# Exact stderr of `pet help bogus` (stdout empty, exit status 0).  Note the
# usage block lacks the '-h, --help' line the root help itself carries.
UNKNOWN_HELP_TOPIC_STDERR = b"""Unknown help topic [`bogus`]
Usage:
  pet [command]

Available Commands:
  clip        Copy the selected commands
  completion  Generate the autocompletion script for the specified shell
  configure   Edit config file
  edit        Edit snippet file
  exec        Run the selected commands
  help        Help about any command
  list        Show all snippets
  new         Create a new snippet
  search      Search snippets
  sync        Sync snippets
  version     Print the version number

Flags:
      --config string   config file (default is $HOME/.config/pet/config.toml)
      --debug           debug mode

Use "pet [command] --help" for more information about a command.
"""

# Exact stdout of the command-line parse failures.  All of them exit with
# status 255 (os.Exit(-1)) and write nothing to stderr.
UNKNOWN_COMMAND_STDOUT = b"""unknown command "bogus" for "pet"
"""
UNKNOWN_FLAG_STDOUT = b"""unknown flag: --bogus
"""
UNKNOWN_SHORT_FLAG_STDOUT = b"""unknown shorthand flag: 'x' in -x
"""
FLAG_NEEDS_ARGUMENT_STDOUT = b"""flag needs an argument: --config
"""
INVALID_BOOL_STDOUT = b"""invalid argument "bogus" for "--debug" flag: strconv.ParseBool: parsing "bogus": invalid syntax
"""

# Exact bytes of the config.toml written on first run (recorded with
# EDITOR=myeditor).  @SNIPPETFILE@ marks the SnippetFile line, which always
# points at the *default* config dir, never at a --config override.
DEFAULT_CONFIG_TEMPLATE = b"""
[GHEGist]
  Public = false
  access_token = ""
  auto_sync = false
  base_url = ""
  file_name = ""
  gist_id = ""
  upload_url = ""

[General]
  Backend = "gist"
  Cmd = []
  Color = false
  Column = 40
  Editor = "@EDITOR@"
  Format = "[$description]: $command $tags"
  SelectCmd = "fzf --ansi --layout=reverse --border --height=90% --pointer=* --cycle --prompt=Snippets:"
  SnippetDirs = []
  SnippetFile = "@SNIPPETFILE@"
  SortBy = ""

[Gist]
  Public = false
  access_token = ""
  auto_sync = false
  file_name = "pet-snippet.toml"
  gist_id = ""

[GitLab]
  ID = ""
  Url = ""
  Visibility = "private"
  access_token = ""
  auto_sync = false
  file_name = "pet-snippet.toml"
  skip_ssl = false
"""

# Hidden cobra completion commands.  __complete enumerates subcommands /
# flags together with their help strings; the directive line goes to stderr.
COMPLETE_SUBCOMMANDS = b"""clip	Copy the selected commands
completion	Generate the autocompletion script for the specified shell
configure	Edit config file
edit	Edit snippet file
exec	Run the selected commands
help	Help about any command
list	Show all snippets
new	Create a new snippet
search	Search snippets
sync	Sync snippets
version	Print the version number
:4
"""
COMPLETE_SUBCOMMANDS_NO_DESC = b"""clip
completion
configure
edit
exec
help
list
new
search
sync
version
:4
"""
COMPLETE_PREFIX_MATCH = b"""configure	Edit config file
:4
"""
COMPLETE_ROOT_FLAGS = b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--help	help for pet
-h	help for pet
:4
"""
COMPLETE_FLAGS = {
    "clip": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--command	Display snippets in one line
--delimiter	Use delim as the command delimiter character
-d	Use delim as the command delimiter character
--help	help for clip
-h	help for clip
--query	Initial value for query
-q	Initial value for query
--raw	Output raw command without entering parameter dialog
--tag	Filter tag
-t	Filter tag
:4
""",
    "completion": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--help	help for completion
-h	help for completion
:4
""",
    "configure": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--help	help for configure
-h	help for configure
:4
""",
    "edit": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--help	help for edit
-h	help for edit
--query	Initial value for query
-q	Initial value for query
--tag	Filter tag
-t	Filter tag
:4
""",
    "exec": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--color	Enable colorized output (only fzf)
--help	help for exec
-h	help for exec
--query	Initial value for query
-q	Initial value for query
--silent	Suppress the command output
-s	Suppress the command output
--tag	Filter tag
-t	Filter tag
:4
""",
    "help": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--help	help for help
-h	help for help
:4
""",
    "list": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--help	help for list
-h	help for list
--oneline	Display snippets in one line
--tags	list by specified tags as comma separated values
-t	list by specified tags as comma separated values
:4
""",
    "new": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--editor	Use editor to create snippet
-e	Use editor to create snippet
--help	help for new
-h	help for new
--multiline	Can enter multiline snippet (Double \\n to quit)
-m	Can enter multiline snippet (Double \\n to quit)
--tag	Display tag prompt (delimiter: space)
-t	Display tag prompt (delimiter: space)
:4
""",
    "search": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--color	Enable colorized output (only fzf)
--delimiter	Use delim as the command delimiter character
-d	Use delim as the command delimiter character
--help	help for search
-h	help for search
--query	Initial value for query
-q	Initial value for query
--raw	Output raw command without entering parameter dialog
--tag	Filter tag
-t	Filter tag
:4
""",
    "sync": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--help	help for sync
-h	help for sync
:4
""",
    "version": b"""--config	config file (default is $HOME/.config/pet/config.toml)
--debug	debug mode
--help	help for version
-h	help for version
:4
""",
}
COMPLETION_DIRECTIVE_STDERR = b"""Completion ended with directive: ShellCompDirectiveNoFileComp
"""

# First five / last lines of the generated `pet completion <shell>` scripts.
# They are pure cobra boilerplate but pin the program name wiring.
COMPLETION_SCRIPT_HEAD = {
    "bash": b"""# bash completion V2 for pet                                  -*- shell-script -*-

__pet_debug()
{
    if [[ -n ${BASH_COMP_DEBUG_FILE-} ]]; then
""",
    "zsh": b"""#compdef pet
compdef _pet pet

# zsh completion for pet                                  -*- shell-script -*-

""",
    "fish": b"""# fish completion for pet                                  -*- shell-script -*-

function __pet_debug
    set -l file "$BASH_COMP_DEBUG_FILE"
    if test -n "$file"
""",
    "powershell": b"""# powershell completion for pet                                  -*- shell-script -*-

function __pet_debug {
    if ($env:BASH_COMP_DEBUG_FILE) {
        "$args" | Out-File -Append -FilePath "$env:BASH_COMP_DEBUG_FILE"
""",
}
COMPLETION_SCRIPT_TAIL = {
    "bash": b"""fi

# ex: ts=4 sw=4 et filetype=sh
""",
    "zsh": b"""if [ "$funcstack[1]" = "_pet" ]; then
    _pet
fi
""",
    "fish": b"""complete -c pet -n 'not __pet_requires_order_preservation && __pet_prepare_completions' -f -a '$__pet_comp_results'
# otherwise we use the -k flag
complete -k -c pet -n '__pet_requires_order_preservation && __pet_prepare_completions' -f -a '$__pet_comp_results'
""",
    "powershell": b"""}

Register-ArgumentCompleter -CommandName 'pet' -ScriptBlock ${__petCompleterBlock}
""",
}

# `pet list` output for a one-snippet file, with and without --debug.
# @SNIPPETFILE@ is the raw snippetfile value from the config.
LIST_PLAIN_TEMPLATE = b"""Description: desc one
    Command: echo one
        Tag: t1
------------------------------
"""
LIST_DEBUG_TEMPLATE = b"""   Filename: @SNIPPETFILE@
Description: desc one
    Command: echo one
        Tag: t1
------------------------------
"""

# Config bootstrap failures: printed to stderr WITHOUT a trailing newline,
# exit status 1 (the initConfig path, unlike the 255 RunE path).
BAD_TOML_1_STDERR = b"""(1, 5): was expecting token =, but got "toml" instead"""
BAD_TOML_2_STDERR = b"""(1, 2): unexpected token unclosed table key, was expecting a table key"""
# RunE failures instead: printed to STDOUT with a newline, exit status 255.
SNIPPET_NOT_FOUND_TEMPLATE = b"""snippet file not found. @SNIPPETFILE@
Please run 'pet configure' and provide a correct file path, or remove this
if you only want to provide snippetdirs instead
"""
SNIPPETDIR_NOT_FOUND_TEMPLATE = b"""snippet directory not found. @DIR@
"""
EMPTY_SNIPPETFILE_STDOUT = b"""error resolving relative path - unknown path: 
"""

# `pet configure` when the configured editor is empty or is `cat`.
CONFIGURE_EMPTY_EDITOR_STDOUT = b"""exit status 127
"""
CONFIGURE_EMPTY_EDITOR_STDERR = b"""sh: 1: +0: not found
"""
CONFIGURE_CAT_EDITOR_STDERR = b"""cat: +0: No such file or directory
"""
# @CONFIG@ stands for the whole config file content; pet appends the
# editor's own 'exit status 1' error line to the same stream.
CONFIGURE_CAT_EDITOR_STDOUT_TEMPLATE = b"""@CONFIG@exit status 1
"""
