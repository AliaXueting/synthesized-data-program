"""Command-line parse failures and the exit-status / stream contract.

RootCmd sets SilenceErrors and SilenceUsage, so cmd.Execute() prints whatever
error it got itself (with fmt.Println, i.e. on *stdout*) and then calls
os.Exit(-1), which the shell reports as status 255.  These tests pin the exact
message text, the stream it lands on, and that status.
"""

import pytest
from conftest import run_pet
from recorded import (
    FLAG_NEEDS_ARGUMENT_STDOUT,
    INVALID_BOOL_STDOUT,
    ROOT_HELP,
    UNKNOWN_COMMAND_STDOUT,
    UNKNOWN_FLAG_STDOUT,
    UNKNOWN_SHORT_FLAG_STDOUT,
)


@pytest.mark.parametrize("name", ["bogus", "definitely-not-a-command"])
def test_unknown_command_fails_on_stdout(home, work, name):
    """An unknown subcommand is reported on stdout and exits 255."""
    # CATCHES: cobra's own error printer is silenced, so the message comes from
    # cmd.Execute() itself — stdout, not stderr — with the command name quoted
    # and the process exiting 255 (os.Exit(-1)).
    res = run_pet([name], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == b'unknown command "' + name.encode() + b'" for "pet"\n'
    assert res.stderr == b""


def test_unknown_command_never_creates_a_config(home, work):
    """The unknown-command error happens before any config bootstrap."""
    # CATCHES: command resolution precedes the initializers, so no directory
    # is created even though the run failed.
    res = run_pet(["bogus"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == UNKNOWN_COMMAND_STDOUT
    assert not (home / ".config").exists()


def test_unknown_flag_on_root(home, work):
    """An unrecognised long flag on the root command exits 255."""
    # CATCHES: 'unknown flag: --bogus' goes to stdout with status 255, and the
    # usage text stays suppressed (SilenceUsage is set on RootCmd).
    res = run_pet(["--bogus"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == UNKNOWN_FLAG_STDOUT
    assert res.stderr == b""


def test_unknown_flag_after_subcommand(home, work):
    """A typo'd persistent flag is rejected after the subcommand too."""
    # CATCHES: --config/--debug are persistent flags, so the same parse error
    # path runs whether the flag is given before or after 'version'.
    res = run_pet(["version", "--bogus"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == UNKNOWN_FLAG_STDOUT
    assert res.stderr == b""


def test_flag_owned_by_a_sibling_subcommand_is_rejected(home, work):
    """--oneline belongs to `list`, so `pet version --oneline` fails."""
    # CATCHES: local flags are not global; the error names the flag itself.
    res = run_pet(["version", "--oneline"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == b"unknown flag: --oneline\n"
    assert res.stderr == b""


def test_unknown_shorthand_flag(home, work):
    """An unrecognised shorthand is reported with the character and argv."""
    # CATCHES: pflag's message embeds both the shorthand letter and the whole
    # '-x' token it appeared in.
    res = run_pet(["-x"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == UNKNOWN_SHORT_FLAG_STDOUT
    assert res.stderr == b""


def test_config_flag_requires_a_value(home, work):
    """`pet version --config` with no value is a parse error, exit 255."""
    # CATCHES: the persistent --config flag takes a string argument; the
    # message names the flag and the status is 255, not 1.
    res = run_pet(["version", "--config"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == FLAG_NEEDS_ARGUMENT_STDOUT
    assert res.stderr == b""


def test_subcommand_flag_requires_a_value(home, work):
    """`pet list --tags` without a value reports that flag by name."""
    # CATCHES: the same 'flag needs an argument' wording is used for local
    # flags, proving one shared parser handles root and subcommand flags.
    res = run_pet(["list", "--tags"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == b"flag needs an argument: --tags\n"
    assert res.stderr == b""


def test_debug_flag_rejects_a_non_boolean_value(home, work):
    """--debug=bogus surfaces strconv's ParseBool error, exit 255."""
    # CATCHES: the bool flag's parse failure is wrapped by pflag as
    # 'invalid argument "bogus" for "--debug" flag: strconv.ParseBool: ...'.
    res = run_pet(["--debug=bogus", "version"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == INVALID_BOOL_STDOUT
    assert res.stderr == b""


def test_config_flag_swallows_the_subcommand_name(home, work):
    """`pet --config version` eats 'version' as the flag's value."""
    # CATCHES: with the subcommand consumed as the --config value no runnable
    # command is left, so the root help prints with status 0 and no config
    # file is created anywhere.
    res = run_pet(["--config", "version"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == ROOT_HELP
    assert res.stderr == b""
    assert not (home / ".config").exists()
    assert list(work.iterdir()) == []


def test_parse_error_beats_a_earlier_help_flag(home, work):
    """`pet -h -x` still fails: the whole argv is parsed before help."""
    # CATCHES: a help flag earlier on the command line does not short-circuit
    # parsing; the later unknown shorthand still aborts with status 255.
    res = run_pet(["-h", "-x"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == UNKNOWN_SHORT_FLAG_STDOUT
    assert res.stderr == b""
