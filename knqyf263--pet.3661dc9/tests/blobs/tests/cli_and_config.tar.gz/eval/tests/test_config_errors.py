"""Config load failures and configs that are missing keys.

Two different failure channels exist and they must not be confused:
  * initConfig failures (unparseable TOML, unopenable path) print to STDERR
    with exit status 1 and no trailing newline;
  * command failures returned through RunE (e.g. a bad snippetfile) are
    printed by cmd.Execute() to STDOUT with a newline and exit status 255.
"""

import pytest
from conftest import default_config_path, run_pet, write_config
from recorded import (
    BAD_TOML_1_STDERR,
    BAD_TOML_2_STDERR,
    EMPTY_SNIPPETFILE_STDOUT,
    LIST_PLAIN_TEMPLATE,
    ROOT_HELP,
    SNIPPET_NOT_FOUND_TEMPLATE,
    SNIPPETDIR_NOT_FOUND_TEMPLATE,
)

# (id, file body, exact stderr) for config.toml files go-toml rejects.
BAD_TOML_FILES = [
    pytest.param("not toml at all ===\n", BAD_TOML_1_STDERR, id="not-toml"),
    pytest.param("[General\nbad = \n", BAD_TOML_2_STDERR, id="unclosed-table"),
]


@pytest.mark.parametrize("body,expected", BAD_TOML_FILES)
def test_unparseable_toml_is_reported_on_stderr(home, work, body, expected):
    """A config.toml go-toml cannot parse aborts with status 1 on stderr."""
    # CATCHES: the parser message (line, column and token text) is printed by
    # initConfig with Fprintf — no trailing newline, stderr not stdout — and
    # the process exits 1 rather than 255.
    write_config(home, body)
    res = run_pet(["version"], home, cwd=work)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == expected
    # the broken file itself must be left untouched
    assert default_config_path(home).read_text() == body


def test_broken_config_breaks_help_but_not_dash_help(home, work):
    """`pet help` runs the initializers and fails; `pet --help` does not."""
    # CATCHES: the help *subcommand* is runnable so it loads the config first
    # and dies with status 1, while the --help flag short-circuits before any
    # initializer and still prints the full root help with status 0.
    write_config(home, "not toml at all ===\n")
    via_help = run_pet(["help"], home, cwd=work)
    via_flag = run_pet(["--help"], home, cwd=work)
    assert via_help.returncode == 1
    assert via_help.stdout == b""
    assert via_help.stderr == BAD_TOML_1_STDERR
    assert via_flag.returncode == 0
    assert via_flag.stdout == ROOT_HELP


def test_config_path_in_a_missing_directory(home, work):
    """--config into a directory that does not exist fails with status 1."""
    # CATCHES: no parent directory is created for --config (unlike the default
    # config dir), so os.Create fails and the raw Go error is printed.
    cfg = work / "no-such-dir" / "config.toml"
    res = run_pet(["--config", str(cfg), "version"], home, cwd=work)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == ("open %s: no such file or directory" % cfg).encode()
    assert not (work / "no-such-dir").exists()


def test_config_path_pointing_at_a_directory(home, work):
    """--config <directory> is stat-able but cannot be read as a file."""
    # CATCHES: the load path stats first (so the file "exists"), then ReadFile
    # fails with 'read ...: is a directory' on stderr with status 1.
    d = work / "adir"
    d.mkdir()
    res = run_pet(["--config", str(d), "version"], home, cwd=work)
    assert res.returncode == 1
    assert res.stderr == ("read %s: is a directory" % d).encode()
    assert res.stdout == b""


def test_config_tilde_only_resolves_to_home(home, work):
    """--config '~' expands to $HOME itself, which is a directory."""
    # CATCHES: NewAbsolutePath maps a bare '~' to the home dir, so the config
    # "file" is $HOME and the run dies reading it.
    res = run_pet(["--config", "~", "version"], home, cwd=work)
    assert res.returncode == 1
    assert res.stderr == ("read %s: is a directory" % home).encode()
    assert res.stdout == b""


def test_config_without_snippetfile_key_leaves_it_empty(home, work):
    """A config that omits snippetfile makes `pet list` fail on ''."""
    # CATCHES: missing keys stay zero-valued (there is no defaulting when the
    # file exists), and the empty path is rejected by the path expander with
    # 'error resolving relative path - unknown path:' on stdout, status 255.
    write_config(home, "[General]\n")
    res = run_pet(["list"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == EMPTY_SNIPPETFILE_STDOUT
    assert res.stderr == b""


def test_missing_snippet_file_error_message(home, work):
    """A snippetfile that does not exist produces the long guidance message."""
    # CATCHES: the three-line message names the raw path from the config and
    # tells the user to run 'pet configure'; it goes to stdout with 255.
    snip = home / "nope.toml"
    write_config(home, '[General]\n  snippetfile = "%s"\n' % snip)
    res = run_pet(["list"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == SNIPPET_NOT_FOUND_TEMPLATE.replace(
        b"@SNIPPETFILE@", str(snip).encode()
    )
    assert res.stderr == b""


def test_missing_snippetdirs_entry_error_message(home, work):
    """A snippetdirs entry that does not exist fails with its own message."""
    # CATCHES: directories are checked after the main snippet file loads, and
    # the message is the single-line 'snippet directory not found. <dir>'.
    snip = home / "ok.toml"
    snip.write_text("")
    missing_dir = home / "nodir"
    write_config(
        home,
        '[General]\n  snippetfile = "%s"\n  snippetdirs = ["%s"]\n' % (snip, missing_dir),
    )
    res = run_pet(["list"], home, cwd=work)
    assert res.returncode == 255
    assert res.stdout == SNIPPETDIR_NOT_FOUND_TEMPLATE.replace(
        b"@DIR@", str(missing_dir).encode()
    )
    assert res.stderr == b""


def test_minimal_config_with_only_snippetfile_is_enough(home, work):
    """A one-key config works: nothing is defaulted, but list succeeds."""
    # CATCHES: with the file present no defaults are injected at all — list
    # falls back to its own column constant — yet the snippets render.
    snip = home / "s.toml"
    snip.write_text(
        '[[snippets]]\n'
        '  description = "desc one"\n'
        '  command = "echo one"\n'
        '  tag = ["t1"]\n'
    )
    write_config(home, '[General]\n  snippetfile = "%s"\n' % snip)
    res = run_pet(["list"], home, cwd=work)
    assert res.returncode == 0
    assert res.stdout == LIST_PLAIN_TEMPLATE.replace(
        b"@SNIPPETFILE@", str(snip).encode()
    )
    assert res.stderr == b""
