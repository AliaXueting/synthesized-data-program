"""Config file discovery: $HOME/.config/pet, $PET_CONFIG_DIR and --config.

initConfig resolves the config path in three steps: --config wins outright,
otherwise $PET_CONFIG_DIR replaces the whole ".config/pet" tail (any value,
even an empty one, counts as "set"), and the fallback is
$HOME/.config/pet/config.toml.  The directory itself is created with mode
0700 before anything is written into it.
"""

from conftest import (
    default_config_dir,
    default_config_path,
    default_snippet_path,
    expected_default_config,
    run_pet,
)
from recorded import VERSION_LINE


def test_default_config_lives_under_home(home, work):
    """With no env and no flag the config is $HOME/.config/pet/config.toml."""
    # CATCHES: the full default file is written there — and nowhere near the
    # working directory — with every default value recorded below.
    res = run_pet(["version"], home, cwd=work, env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert res.stdout == VERSION_LINE
    assert default_config_path(home).read_bytes() == expected_default_config(
        default_snippet_path(home)
    )
    assert list(work.iterdir()) == []


def test_pet_config_dir_replaces_the_default_directory(home, work):
    """$PET_CONFIG_DIR wholesale replaces $HOME/.config/pet."""
    # CATCHES: nothing at all is created under $HOME/.config when the variable
    # is set; both config.toml and snippet.toml move to the new directory.
    pcd = home / "elsewhere"
    res = run_pet(["version"], home, cwd=work,
                  env={"PET_CONFIG_DIR": str(pcd), "EDITOR": "myeditor"})
    assert res.returncode == 0
    assert (pcd / "config.toml").read_bytes() == expected_default_config(
        pcd / "snippet.toml"
    )
    assert (pcd / "snippet.toml").exists()
    assert not (home / ".config").exists()


def test_pet_config_dir_set_but_empty_fails(home, work):
    """An empty PET_CONFIG_DIR still counts as set, and mkdir '' fails."""
    # CATCHES: the variable is read with LookupEnv, so '' wins over $HOME and
    # MkdirAll('') fails; the message lands on stderr with status 1 and no
    # trailing newline.
    res = run_pet(["version"], home, cwd=work, env={"PET_CONFIG_DIR": ""})
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"cannot create directory: mkdir : no such file or directory"
    assert not (home / ".config").exists()


def test_pet_config_dir_tilde_expands_to_home(home, work):
    """PET_CONFIG_DIR='~' is expanded to $HOME after the mkdir."""
    # CATCHES: the directory is created from the raw value first (a literal
    # '~' directory appears in the cwd) and only then expanded, so the config
    # and snippet files land directly in $HOME.
    res = run_pet(["version"], home, cwd=work, env={"PET_CONFIG_DIR": "~"})
    assert res.returncode == 0
    assert (home / "config.toml").exists()
    assert (home / "snippet.toml").exists()
    assert (work / "~").is_dir()
    assert not (home / ".config").exists()


def test_pet_config_dir_relative_name_loses_two_characters(home, work):
    """A bare relative PET_CONFIG_DIR is expanded by dropping two characters."""
    # CATCHES: GetDefaultConfigDir mkdirs the raw name in the cwd, then hands
    # it to the path expander, which drops the first two characters — so
    # 'reldir' is looked up as $HOME/ldir and the bootstrap fails.
    res = run_pet(["version"], home, cwd=work, env={"PET_CONFIG_DIR": "reldir"})
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        "open %s/ldir/config.toml: no such file or directory" % home
    ).encode()
    assert (work / "reldir").is_dir()
    assert not (home / "ldir").exists()


def test_pet_config_dir_pointing_at_a_file_cannot_be_created(home, work):
    """A PET_CONFIG_DIR that names an existing file fails with 'not a dir'."""
    # CATCHES: the mkdir error is wrapped as 'cannot create directory: ...'
    # and printed to stderr with status 1 before anything else happens.
    blocker = home / "blocker"
    blocker.write_text("not a directory\n")
    res = run_pet(["version"], home, cwd=work, env={"PET_CONFIG_DIR": str(blocker)})
    assert res.returncode == 1
    assert res.stderr == (
        "cannot create directory: mkdir %s: not a directory" % blocker
    ).encode()
    assert res.stdout == b""


def test_config_flag_beats_pet_config_dir_for_the_config_file(home, work):
    """--config wins for config.toml, but snippet.toml still uses the default."""
    # CATCHES: the bootstrap only ever creates snippet.toml inside the default
    # config dir (here $PET_CONFIG_DIR), never next to the --config file.
    pcd = home / "pcd"
    cfg = work / "chosen.toml"
    res = run_pet(["--config", str(cfg), "version"], home, cwd=work,
                  env={"PET_CONFIG_DIR": str(pcd), "EDITOR": "myeditor"})
    assert res.returncode == 0
    assert cfg.read_bytes() == expected_default_config(pcd / "snippet.toml")
    assert (pcd / "snippet.toml").exists()
    assert not (pcd / "config.toml").exists()
    assert not (home / ".config").exists()


def test_the_config_directory_is_created_with_mode_0700(home, work):
    """$HOME/.config/pet is created with mode 0700 (not 0755)."""
    # CATCHES: GetDefaultConfigDir passes 0700 to MkdirAll for the config dir
    # and every parent it has to create.
    res = run_pet(["version"], home, cwd=work, env={"EDITOR": "myeditor"})
    assert res.returncode == 0
    assert (default_config_dir(home).stat().st_mode & 0o777) == 0o700
    assert ((home / ".config").stat().st_mode & 0o777) == 0o700
