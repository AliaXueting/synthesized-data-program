"""The input-consuming builtins: input, inputs, and input_filename."""

import pytest
from conftest import run_gojq, write_file


@pytest.fixture()
def files(tmp_path):
    """Create the small file corpus used by the builtin tests."""
    write_file(tmp_path, "a.json", b"1\n")
    write_file(tmp_path, "b.json", b"2\n3\n")
    write_file(tmp_path, "lines.txt", b"x\ny\n")
    return tmp_path


def test_input_returns_the_next_value():
    """`input` yields the input value after the current one."""
    # CATCHES: the main loop's value and `input` share one iterator, so the
    # successor consumed by `input` is never revisited by the main loop: the
    # pairs are (1,2) and (3,4), not (1,2) and (2,3).
    res = run_gojq(["-c", "[., input]"], b"1 2 3 4")
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n[3,4]\n"
    assert res.stderr == b""


def test_input_exhaustion_reports_break():
    """Running out of inputs raises the bare error `gojq: break`."""
    # CATCHES: unlike jq's "No more inputs", gojq surfaces the internal
    # break sentinel as the message `break`, on stderr, with exit code 5.
    res = run_gojq(["-n", "input"], b"")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: break\n"


def test_input_exhaustion_mid_stream_stops_remaining_values():
    """A late `input` failure still prints the outputs already produced."""
    # CATCHES: the query runs per main-loop value, so earlier outputs stand
    # and only the iteration whose `input` failed prints the error.
    res = run_gojq(["-c", "input, ."], b"1 2 3")
    assert res.returncode == 5
    assert res.stdout == b"2\n1\n"
    assert res.stderr == b"gojq: break\n"


def test_try_input_catches_the_break_string():
    """`try input catch .` exposes the exhaustion error as the string "break"."""
    # CATCHES: the catch binding receives the plain string "break", so the
    # exit code is 0 and the error is catchable like any query error.
    res = run_gojq(['-n', 'try input catch "caught: \\(.)"'], b"")
    assert res.returncode == 0
    assert res.stdout == b'"caught: break"\n'
    assert res.stderr == b""


def test_inputs_collects_all_remaining_values():
    """`inputs` drains every value after the current one."""
    # CATCHES: with one main value 1, `inputs` yields 2 and 3; with no
    # remaining values it yields an empty stream, not an error.
    res = run_gojq(["-c", "[inputs]"], b"1 2 3")
    assert res.returncode == 0
    assert res.stdout == b"[2,3]\n"
    single = run_gojq(["-c", "[inputs]"], b"1")
    assert single.returncode == 0
    assert single.stdout == b"[]\n"
    assert single.stderr == b""


def test_inputs_empty_input_is_an_empty_array():
    """Under -n with nothing to read, `[inputs]` is just `[]`."""
    # CATCHES: `inputs` swallows the break sentinel at end of stream, so an
    # empty input source is not an error.
    res = run_gojq(["-nc", "[inputs]"], b"")
    assert res.returncode == 0
    assert res.stdout == b"[]\n"
    assert res.stderr == b""


def test_inputs_spans_file_boundaries(files):
    """`inputs` keeps draining across every file argument."""
    # CATCHES: the builtin sees the whole multi-file iterator, not just the
    # current file, so a.json and b.json values join one array.
    res = run_gojq(["-nc", "[inputs]", "a.json", "b.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b"[1,2,3]\n"
    assert res.stderr == b""


def test_input_reads_from_later_files(files):
    """A failing `input` at one file's end continues into the next file."""
    # CATCHES: without -n the main loop also consumes values, so after a.json
    # is drained by `.` and `input`, the next `input` reaches into b.json.
    res = run_gojq(["-c", "input", "a.json", "b.json"], cwd=files)
    assert res.returncode == 5
    assert res.stdout == b"2\n"
    assert res.stderr == b"gojq: break\n"


def test_input_filename_is_stdin_for_piped_input():
    """With no file arguments, input_filename is the literal `<stdin>`."""
    # CATCHES: the stdin source is named `<stdin>` (not null as in jq), and
    # the same name is used in raw and stream input modes.
    res = run_gojq(["-c", "input_filename"], b"1")
    assert res.returncode == 0
    assert res.stdout == b'"<stdin>"\n'
    raw = run_gojq(["-Rc", "input_filename"], b"x\n")
    assert raw.returncode == 0
    assert raw.stdout == b'"<stdin>"\n'
    streamed = run_gojq(["--stream", "-c", "input_filename"], b"1")
    assert streamed.returncode == 0
    assert streamed.stdout == b'"<stdin>"\n'
    assert streamed.stderr == b""


def test_input_filename_is_null_with_null_input(files):
    """Under -n with no `input` call, input_filename is null."""
    # CATCHES: the file iterator is advanced lazily, so before anything is
    # read there is no current file and the builtin returns null.
    res = run_gojq(["-nc", "input_filename", "a.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b"null\n"
    assert res.stderr == b""


def test_input_filename_reports_named_files_per_value(files):
    """With file arguments, input_filename follows the file being read."""
    # CATCHES: every value carries the name of the file it came from, so the
    # two a.json values print `a.json` and the b.json value prints `b.json`.
    write_file(files, "two.json", b"1 2\n")
    write_file(files, "three.json", b"3\n")
    res = run_gojq(["-c", "input_filename", "two.json", "three.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b'"two.json"\n"two.json"\n"three.json"\n'
    assert res.stderr == b""


def test_input_filename_tracks_the_file_of_the_last_input(files):
    """After `input` crosses into the next file, the name follows it."""
    # CATCHES: the name is the source of the most recently read value, so
    # after draining a.json the second `input` reports b.json.
    res = run_gojq(
        ["-nc", "[input, input] | input_filename", "a.json", "b.json"], cwd=files
    )
    assert res.returncode == 0
    assert res.stdout == b'"b.json"\n'
    assert res.stderr == b""


def test_input_filename_null_once_inputs_are_exhausted(files):
    """After `inputs` drains everything there is no current file, so null."""
    # CATCHES: exhausting the iterator releases the last file, and the
    # builtin then returns null instead of the previous file name.
    res = run_gojq(["-nc", "[inputs] | input_filename", "a.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b"null\n"
    without_n = run_gojq(["-c", "[inputs] | input_filename", "a.json"], cwd=files)
    assert without_n.returncode == 0
    assert without_n.stdout == b"null\n"
    assert without_n.stderr == b""


def test_input_filename_for_dash_is_stdin():
    """Reading via `-` names the source `<stdin>`, not the dash."""
    # CATCHES: the `-` argument is renamed to `<stdin>` inside the iterator,
    # so input_filename never leaks a literal `-`.
    res = run_gojq(["-c", "input_filename", "-"], b"1")
    assert res.returncode == 0
    assert res.stdout == b'"<stdin>"\n'
    assert res.stderr == b""


def test_input_parse_error_inside_inputs_is_a_query_error(files):
    """A parse error surfaced through `inputs` gains the `error:` prefix."""
    # CATCHES: the error value raised by the builtin is re-raised by the
    # query, printing `gojq: error: invalid json: ...` and producing no
    # output at all.
    write_file(files, "bad.json", b"1 {")
    res = run_gojq(["-nc", "[inputs]", "bad.json"], cwd=files)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: error: invalid json: bad.json\n"
        b"    1 {\n"
        b"       ^  unexpected EOF\n"
    )


def test_input_stops_before_the_error_when_not_needed(files):
    """`input` that stops at the last good value never sees the parse error."""
    # CATCHES: parsing is lazy per value, so reading only the first value of
    # a file whose second value is broken exits 0.
    write_file(files, "bad.json", b"1 {")
    res = run_gojq(["-nc", "input", "bad.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_inputs_in_raw_mode_are_lines(files):
    """Under -R the `inputs` builtin collects the remaining lines."""
    # CATCHES: the raw line iterator backs the builtin too, so `inputs`
    # yields the not-yet-read lines as strings.
    res = run_gojq(["-nRc", "[inputs]"], b"a\nb\n")
    assert res.returncode == 0
    assert res.stdout == b'["a","b"]\n'
    from_files = run_gojq(["-nRc", "[inputs]", "lines.txt"], cwd=files)
    assert from_files.returncode == 0
    assert from_files.stdout == b'["x","y"]\n'
    assert from_files.stderr == b""


def test_inputs_in_stream_mode_are_events():
    """Under --stream the `inputs` builtin yields the parse events."""
    # CATCHES: the streaming iterator is shared with the builtin, so `[inputs]`
    # under -n collects the [path, value] pairs like --stream would print.
    res = run_gojq(["-nc", "[inputs]", "--stream"], b"[1]")
    assert res.returncode == 0
    assert res.stdout == b"[[[0],1],[[0]]]\n"
    assert res.stderr == b""
