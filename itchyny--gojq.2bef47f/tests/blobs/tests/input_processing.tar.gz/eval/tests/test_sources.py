"""Where query input comes from: stdin by default, named files, and `-`."""

import pytest
from conftest import run_gojq, write_file


@pytest.fixture()
def files(tmp_path):
    """Create the small standard corpus of input files used by this module."""
    write_file(tmp_path, "a.json", b"1 2\n")
    write_file(tmp_path, "b.json", b'{"x": 3}')
    write_file(tmp_path, "noeol.json", b"7")
    write_file(tmp_path, "empty.json", b"")
    return tmp_path


def test_stdin_is_the_default_source():
    """Without file arguments every whitespace-separated stdin value is used."""
    # CATCHES: the default source is the whole stdin stream, split on
    # whitespace, and each value is fed to the query independently.
    res = run_gojq(["-c", "."], b'1 {"a":2} [3]')
    assert res.returncode == 0
    assert res.stdout == b'1\n{"a":2}\n[3]\n'
    assert res.stderr == b""


def test_stdin_values_split_across_lines(tmp_path):
    """Values may span lines and be separated by any JSON whitespace."""
    # CATCHES: newline separation and blank lines between values behave the
    # same as single-space separation; blank lines produce no empty inputs.
    res = run_gojq(["-c", "."], b'1\n\n[2]\n\t3\n')
    assert res.returncode == 0
    assert res.stdout == b"1\n[2]\n3\n"
    assert res.stderr == b""


def test_empty_stdin_runs_query_zero_times():
    """An empty stdin stream feeds the query no input values at all."""
    # CATCHES: empty input is not an error and not a single null; the query
    # simply never runs, so nothing reaches stdout and the exit code is 0.
    res = run_gojq(["-c", "."], b"")
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_single_file_parsed_as_one_stream(files):
    """A file argument is parsed as a whole stream of concatenated values."""
    # CATCHES: each file is one JSON stream, not one line-delimited value, so
    # several top-level values inside one file each reach the query.
    res = run_gojq(["-c", ".", "a.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b"1\n2\n"
    assert res.stderr == b""


def test_multiple_files_processed_in_argument_order(files):
    """File arguments are consumed in the order given on the command line."""
    # CATCHES: inputs from all files flow through one iterator in argument
    # order, with no separator or reordering between them.
    res = run_gojq(["-c", ".", "b.json", "a.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b'{"x":3}\n1\n2\n'
    assert res.stderr == b""


def test_dash_alone_reads_stdin():
    """A lone `-` file argument means standard input."""
    # CATCHES: `-` is the conventional stdin marker, so the values come from
    # the pipe instead of a file named `-`.
    res = run_gojq(["-c", ".", "-"], b"5 6")
    assert res.returncode == 0
    assert res.stdout == b"5\n6\n"
    assert res.stderr == b""


def test_dash_between_files_reads_stdin_there(files):
    """`-` inserts the stdin values at that position among the files."""
    # CATCHES: stdin is just one more source in the file list, so its values
    # appear between the surrounding files' values.
    res = run_gojq(["-c", ".", "a.json", "-", "b.json"], b"8", cwd=files)
    assert res.returncode == 0
    assert res.stdout == b"1\n2\n8\n{\"x\":3}\n"
    assert res.stderr == b""


def test_dash_after_dashdash_still_means_stdin():
    """`--` ends option parsing but a following `-` still selects stdin."""
    # CATCHES: the `--` separator stops flag parsing yet does not turn `-`
    # into a literal file name; it keeps its stdin meaning.
    res = run_gojq(["-c", ".", "--", "-"], b"1")
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_missing_file_error_then_next_file_still_processed(files):
    """An unreadable file reports an open error and processing continues."""
    # CATCHES: the exact message is `gojq: open missing.json: no such file or
    # directory`, it goes to stderr, later files are still read, and the exit
    # code is 5.
    res = run_gojq(["-c", ".", "missing.json", "a.json"], cwd=files)
    assert res.returncode == 5
    assert res.stdout == b"1\n2\n"
    assert res.stderr == b"gojq: open missing.json: no such file or directory\n"


def test_every_missing_file_is_reported(files):
    """Each missing file in the list produces its own error line."""
    # CATCHES: the iterator does not stop at the first unreadable file; both
    # open failures are printed, one per line, and the exit code stays 5.
    res = run_gojq(["-c", ".", "m1.json", "m2.json"], cwd=files)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: open m1.json: no such file or directory\n"
        b"gojq: open m2.json: no such file or directory\n"
    )


def test_empty_filename_argument_is_an_open_error(files):
    """An empty-string file argument fails to open like any other name."""
    # CATCHES: the empty argument is passed to open verbatim, giving the
    # message `gojq: open : no such file or directory`.
    res = run_gojq(["-c", ".", ""], cwd=files)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: open : no such file or directory\n"


def test_directory_argument_is_a_read_error(tmp_path):
    """Opening a directory succeeds but reading it fails with EISDIR."""
    # CATCHES: the read error surfaces wrapped as an `invalid json:` error
    # whose echoed line is empty, followed by a caret line.
    (tmp_path / "sub").mkdir()
    res = run_gojq(["-c", ".", "sub"], cwd=tmp_path)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: invalid json: sub\n    \n    ^  read sub: is a directory\n"


def test_directory_in_raw_mode_reports_a_bare_read_error(tmp_path):
    """In -R mode a directory argument fails with a plain read error."""
    # CATCHES: the raw line iterator does not wrap failures in the
    # `invalid json:` block format; it prints `gojq: read sub: is a directory`
    # on one line, unlike the JSON mode's caret rendering.
    (tmp_path / "sub").mkdir()
    res = run_gojq(["-Rc", ".", "sub"], cwd=tmp_path)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: read sub: is a directory\n"


@pytest.mark.parametrize(
    "args,expected_err",
    [
        (["-Rsc", ".", "sub"], b"gojq: read sub: is a directory\n"),
        (["-Rsc", ".", "nope.txt"], b"gojq: open nope.txt: no such file or directory\n"),
    ],
)
def test_raw_slurp_source_errors_are_bare_too(args, expected_err, tmp_path):
    """-Rs reports read and open errors as one-line messages, exit 5."""
    # CATCHES: the whole-input readers share the raw iterators' plain error
    # style: no echoed line, no caret, whether the open or the read fails.
    (tmp_path / "sub").mkdir()
    res = run_gojq(args, cwd=tmp_path)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == expected_err


def test_repeated_dash_reads_stdin_only_once():
    """Two `-` arguments share one stdin stream, so values are not repeated."""
    # CATCHES: stdin is never rewound or closed between sources; once the
    # pipe is exhausted the second `-` contributes no further values.
    res = run_gojq(["-c", ".", "-", "-"], b"5")
    assert res.returncode == 0
    assert res.stdout == b"5\n"
    assert res.stderr == b""


def test_file_without_trailing_newline(files):
    """A file whose last value has no trailing newline is still complete."""
    # CATCHES: the JSON decoder is stream-based, so a missing final newline
    # neither drops the last value nor adds an error.
    res = run_gojq(["-c", ".", "noeol.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b"7\n"
    assert res.stderr == b""


def test_empty_file_yields_no_values(files):
    """An empty file contributes no input values and is not an error."""
    # CATCHES: an empty file behaves exactly like an empty stdin stream: zero
    # inputs, empty output, exit code 0.
    res = run_gojq(["-c", ".", "empty.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_same_file_listed_twice_is_read_twice(files):
    """Repeating a file name reads its values again the second time."""
    # CATCHES: file sources are opened per occurrence, not deduplicated.
    res = run_gojq(["-c", ".", "a.json", "a.json"], cwd=files)
    assert res.returncode == 0
    assert res.stdout == b"1\n2\n1\n2\n"
    assert res.stderr == b""


def test_null_input_does_not_open_file_arguments(tmp_path):
    """With -n and no `input` calls, file arguments are never even opened."""
    # CATCHES: the file iterator is created lazily, so a missing or malformed
    # file goes completely unnoticed under -n and the exit code stays 0.
    res = run_gojq(["-nc", ".", "missing.json"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"null\n"
    assert res.stderr == b""


def test_null_input_reports_file_error_only_when_read(tmp_path):
    """Under -n the missing file is only reported once `input` touches it."""
    # CATCHES: the same lazy iterator backs the `input` builtin, so the open
    # error appears exactly when the query asks for the next value.
    res = run_gojq(["-nc", "input", "missing.json"], cwd=tmp_path)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: open missing.json: no such file or directory\n"


def test_args_flag_consumes_remaining_arguments_as_positional(tmp_path):
    """`--args` turns the remaining arguments into $ARGS, not input files."""
    # CATCHES: after `--args` no argument is treated as a file name, so stdin
    # remains the input source and `$ARGS.positional` holds the strings.
    write_file(tmp_path, "a.json", b"1 2\n")
    res = run_gojq(["-c", "$ARGS", "--args", "a.json"], b"9", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b'{"named":{},"positional":["a.json"]}\n'
    plain = run_gojq(["-c", ".", "--args", "a.json"], b"9", cwd=tmp_path)
    assert plain.returncode == 0
    assert plain.stdout == b"9\n"


def test_first_positional_argument_is_the_query(tmp_path):
    """A file name given before the flags becomes the query, not a source."""
    # CATCHES: the first remaining argument is always the query, so `a.json`
    # is compiled and fails with exit code 3, not read as input.
    write_file(tmp_path, "a.json", b"1 2\n")
    res = run_gojq(["a.json", "-c", "."], cwd=tmp_path)
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"gojq: compile error: function not defined: a/0\n"


def test_from_file_query_leaves_files_as_input_sources(tmp_path):
    """-f takes the query from a file; the remaining arguments are inputs."""
    # CATCHES: with -f the first remaining argument is an input file, and
    # several files still concatenate through the shared iterator.
    write_file(tmp_path, "q.jq", b". + 10\n")
    write_file(tmp_path, "a.json", b"1 2\n")
    res = run_gojq(["-f", "q.jq", "-c", "a.json", "a.json"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"11\n12\n11\n12\n"
    assert res.stderr == b""
