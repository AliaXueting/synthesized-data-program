"""--yaml-input: documents, multi-document streams, and their parse errors."""

import pytest
from conftest import run_gojq, write_file


def yaml_input(stdin, extra=()):
    """Run gojq in YAML input mode and return the CompletedProcess."""
    return run_gojq(["--yaml-input", "-c"] + list(extra) + ["."], stdin)


def test_yaml_mapping_and_nested_structures():
    """A YAML mapping becomes a JSON object with nested values."""
    # CATCHES: nested mappings and inline flow sequences are converted, with
    # unquoted scalars becoming strings or numbers by YAML rules.
    res = yaml_input(b"a:\n  b: 1\n  c: [1, 2]\n")
    assert res.returncode == 0
    assert res.stdout == b'{"a":{"b":1,"c":[1,2]}}\n'
    assert res.stderr == b""


def test_yaml_block_sequences():
    """Block sequences become arrays, nesting included."""
    # CATCHES: `- ` list items are collected into an array and a nested dash
    # list becomes a nested array.
    res = yaml_input(b"- 1\n- 2\n")
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n"
    nested = yaml_input(b"- 1.2\n- 3\n- - 4\n")
    assert nested.returncode == 0
    assert nested.stdout == b"[1.2,3,[4]]\n"
    assert nested.stderr == b""


def test_yaml_multi_document_stream():
    """`---` separators split the stream into separate input values."""
    # CATCHES: each document is an independent input, so the query runs once
    # per document in order.
    res = yaml_input(b"--- 1\n--- 2\n--- 3\n")
    assert res.returncode == 0
    assert res.stdout == b"1\n2\n3\n"
    assert res.stderr == b""


def test_yaml_documents_without_marker_are_one_scalar():
    """Bare lines without `---` form ONE multi-line plain scalar."""
    # CATCHES: `1\\ntrue\\nnull\\nhello` is a single document (the string
    # "1 true null hello"), not four values; only `---` separates documents.
    res = yaml_input(b"1\ntrue\nnull\nhello\n")
    assert res.returncode == 0
    assert res.stdout == b'"1 true null hello"\n'
    assert res.stderr == b""


def test_yaml_empty_document_markers_yield_nulls():
    """Consecutive `---` markers produce explicit null documents."""
    # CATCHES: an empty document between markers is the null value, so two
    # markers give two nulls, not zero values.
    res = yaml_input(b"---\n---\n")
    assert res.returncode == 0
    assert res.stdout == b"null\nnull\n"
    assert res.stderr == b""


def test_yaml_empty_and_comment_only_input():
    """Empty input or comments alone produce no documents at all."""
    # CATCHES: a comments-only stream yields zero inputs, exactly like an
    # empty stream, without an error.
    res = yaml_input(b"")
    assert res.returncode == 0
    assert res.stdout == b""
    comments = yaml_input(b"# hi\n")
    assert comments.returncode == 0
    assert comments.stdout == b""
    assert comments.stderr == b""


def test_yaml_anchors_and_aliases_resolve():
    """Anchored values are shared, and aliases dereference to the same value."""
    # CATCHES: `&x 1` and `*x` both resolve to 1 in the output object.
    res = yaml_input(b"a: &x 1\nb: *x\n")
    assert res.returncode == 0
    assert res.stdout == b'{"a":1,"b":1}\n'
    assert res.stderr == b""


def test_yaml_block_scalar_keeps_newlines():
    """A `|` block scalar preserves the inner line breaks and final newline."""
    # CATCHES: the literal block scalar keeps its trailing newline, giving
    # the string "x\\ny\\n".
    res = yaml_input(b"a: |\n  x\n  y\n")
    assert res.returncode == 0
    assert res.stdout == b'{"a":"x\\ny\\n"}\n'
    assert res.stderr == b""


def test_yaml_quotes_distinguish_strings_from_numbers():
    """Quoted scalars stay strings while bare scalars become numbers."""
    # CATCHES: YAML quoting is semantic, so "1" is the string "1" while 1 is
    # the number 1.
    res = yaml_input(b'- "1"\n- 1\n')
    assert res.returncode == 0
    assert res.stdout == b'["1",1]\n'
    assert res.stderr == b""


def test_yaml_number_and_special_scalar_forms():
    """YAML special numbers and hex integers follow go-yaml's conversions."""
    # CATCHES: .inf becomes the max float, .nan becomes null, and 0x10 is
    # parsed as the integer 16.
    res = yaml_input(b"- 1\n- 1.5\n- .inf\n- .nan\n- 0x10\n")
    assert res.returncode == 0
    assert res.stdout == b"[1,1.5,1.7976931348623157e+308,null,16]\n"
    assert res.stderr == b""


def test_yaml_is_a_superset_of_json_flow_syntax():
    """JSON is valid YAML, so JSON files parse in YAML input mode."""
    # CATCHES: --yaml-input accepts regular JSON documents unchanged.
    res = yaml_input(b'{"a": 1}\n')
    assert res.returncode == 0
    assert res.stdout == b'{"a":1}\n'
    flow = yaml_input(b"[1, 2, {a: b}]\n")
    assert flow.returncode == 0
    assert flow.stdout == b'[1,2,{"a":"b"}]\n'
    assert flow.stderr == b""


def test_yaml_slurp_collects_documents(tmp_path):
    """-s collects every YAML document into one array."""
    # CATCHES: slurp sits above the YAML decoder, so documents join the same
    # array in order.
    res = run_gojq(["--yaml-input", "-sc", "."], b"--- 1\n--- 2\n")
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n"
    assert res.stderr == b""


def test_yaml_named_files(tmp_path):
    """File arguments are read as YAML documents, one file at a time."""
    # CATCHES: each file is a separate YAML stream whose documents flow into
    # the shared iterator in argument order.
    write_file(tmp_path, "a.yaml", b"a: 1\nb: two\n")
    write_file(tmp_path, "b.yaml", b"--- 1\n--- 2\n")
    write_file(tmp_path, "empty.yaml", b"")
    res = run_gojq(
        ["--yaml-input", "-c", ".", "a.yaml", "b.yaml", "empty.yaml"], cwd=tmp_path
    )
    assert res.returncode == 0
    assert res.stdout == b'{"a":1,"b":"two"}\n1\n2\n'
    assert res.stderr == b""


def test_yaml_null_input_reads_documents_via_inputs():
    """-n --yaml-input leaves the documents readable through `inputs`."""
    # CATCHES: the YAML iterator feeds the `inputs` builtin under -n, with
    # each document becoming one array element.
    res = run_gojq(["--yaml-input", "-nc", "[inputs]"], b"1\n--- 2\n")
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "stdin,expected_out,expected_err",
    [
        (
            b"a: 1\n b: 2\n",
            b"",
            b"gojq: invalid yaml: <stdin>:2\n"
            b"    2 |  b: 2\n"
            b"          ^  mapping values are not allowed in this context\n",
        ),
        (
            b"a:\n\t- 1\n",
            b"",
            b"gojq: invalid yaml: <stdin>:2\n"
            b"    2 | \t- 1\n"
            b"        ^  found character that cannot start any token\n",
        ),
        (
            b"a: *undefined\n",
            b"",
            b"gojq: invalid yaml: <stdin>:1\n"
            b"    1 | a: *undefined\n"
            b"           ^  unknown anchor 'undefined' referenced\n",
        ),
        (
            b"a: 1\na: 2\n",
            b"",
            b"gojq: invalid yaml: <stdin>:2\n"
            b'    2 | a: 2\n'
            b'        ^  mapping key "a" already defined at line 1\n',
        ),
        (
            b"1\n...\n2\n",
            b"1\n",
            b"gojq: invalid yaml: <stdin>:3\n"
            b"    3 | 2\n"
            b"        ^  did not find expected <document start>\n",
        ),
    ],
)
def test_yaml_parse_errors(stdin, expected_out, expected_err):
    """YAML errors render as `invalid yaml: NAME:LINE` with the same gutter."""
    # CATCHES: YAML failures always use the NAME:LINE form (even on line 1),
    # quote the go-yaml message, exit 5, and keep documents decoded before
    # the failure on stdout.
    res = yaml_input(stdin)
    assert res.returncode == 5
    assert res.stdout == expected_out
    assert res.stderr == expected_err


def test_yaml_unterminated_flow_error():
    """An unterminated flow collection reports missing node content."""
    # CATCHES: the error points at the line of the unterminated `[` with the
    # go-yaml message `did not find expected node content`.
    res = yaml_input(b"a: [\n")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid yaml: <stdin>:1\n"
        b"    1 | a: [\n"
        b"            ^  did not find expected node content\n"
    )


def test_yaml_error_in_named_file_and_with_slurp(tmp_path):
    """YAML errors name the file, and -s still suppresses all output."""
    # CATCHES: the file name replaces `<stdin>` in the header, and slurping
    # means the earlier document `1` never reaches stdout.
    write_file(tmp_path, "bad.yaml", b"a: [\n")
    res = run_gojq(["--yaml-input", "-c", ".", "bad.yaml"], cwd=tmp_path)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid yaml: bad.yaml:1\n"
        b"    1 | a: [\n"
        b"            ^  did not find expected node content\n"
    )
    slurped = run_gojq(["--yaml-input", "-sc", "."], b"1\n---\n{\n")
    assert slurped.returncode == 5
    assert slurped.stdout == b""
    assert slurped.stderr == (
        b"gojq: invalid yaml: <stdin>:3\n"
        b"    3 | {\n"
        b"         ^  did not find expected node content\n"
    )
