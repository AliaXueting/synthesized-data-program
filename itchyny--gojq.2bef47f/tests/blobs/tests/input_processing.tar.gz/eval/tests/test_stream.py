"""The --stream streaming parser: [path, value] and [path] events."""

import pytest
from conftest import run_gojq, write_file


def stream(stdin, extra=()):
    """Run `--stream -c .` and return the CompletedProcess."""
    return run_gojq(["--stream", "-c", "."] + list(extra), stdin)


@pytest.mark.parametrize(
    "stdin,expected",
    [
        (b"1", b"[[],1]\n"),
        (b"null", b"[[],null]\n"),
        (b"true", b"[[],true]\n"),
        (b'"x"', b'[[],"x"]\n'),
        (b"1.0", b"[[],1.0]\n"),
    ],
)
def test_stream_top_level_scalars(stdin, expected):
    """A top-level scalar emits one [path, value] event with an empty path."""
    # CATCHES: the event path for a top-level value is the empty array, and
    # number text like `1.0` is preserved verbatim rather than normalized.
    res = stream(stdin)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_stream_array_leaf_and_end_events():
    """Array elements emit [index, value] then a final [last-index] event."""
    # CATCHES: the END event of a container carries the path of its LAST
    # element, not the container's own path or an empty path.
    res = stream(b'[1,[2,3],{"a":1}]')
    assert res.returncode == 0
    assert res.stdout == (
        b"[[0],1]\n"
        b"[[1,0],2]\n"
        b"[[1,1],3]\n"
        b"[[1,1]]\n"
        b'[[2,"a"],1]\n'
        b'[[2,"a"]]\n'
        b"[[2]]\n"
    )
    assert res.stderr == b""


def test_stream_deeply_nested_array_paths():
    """Nesting builds the full numeric path, unwound one END at a time."""
    # CATCHES: each closing bracket emits its own END event with the deepest
    # surviving path, so [[1]] produces three trailing [path] events.
    res = stream(b"[[[1]]]")
    assert res.returncode == 0
    assert res.stdout == (
        b"[[0,0,0],1]\n"
        b"[[0,0,0]]\n"
        b"[[0,0]]\n"
        b"[[0]]\n"
    )
    assert res.stderr == b""


def test_stream_object_key_value_events():
    """Object entries emit [key, value] events ending with the last key."""
    # CATCHES: keys appear in the path as strings in document order, and the
    # object's END event repeats the final key's path.
    res = stream(b'{"a":{"b":1},"c":2}')
    assert res.returncode == 0
    assert res.stdout == (
        b'[["a","b"],1]\n'
        b'[["a","b"]]\n'
        b'[["c"],2]\n'
        b'[["c"]]\n'
    )
    assert res.stderr == b""


def test_stream_object_key_order_is_document_order():
    """Object keys are streamed in their written order, not sorted."""
    # CATCHES: the path uses the keys exactly as they appear in the document,
    # so `b` precedes `a` when written that way.
    res = stream(b'{"b":1,"a":2}')
    assert res.returncode == 0
    assert res.stdout == b'[["b"],1]\n[["a"],2]\n[["a"]]\n'
    assert res.stderr == b""


def test_stream_object_whose_last_value_is_an_array():
    """An object ending in a container emits both nested and key END events."""
    # CATCHES: the inner array's END uses its own last index path, then the
    # object's END uses the key path.
    res = stream(b'{"a":[1]}')
    assert res.returncode == 0
    assert res.stdout == b'[["a",0],1]\n[["a",0]]\n[["a"]]\n'
    assert res.stderr == b""


@pytest.mark.parametrize(
    "stdin,expected",
    [
        (b"[]", b"[[],[]]\n"),
        (b"{}", b"[[],{}]\n"),
        (b"[[ ],{ },{\"a\":{}}]", b"[[0],[]]\n[[1],{}]\n[[2,\"a\"],{}]\n[[2,\"a\"]]\n[[2]]\n"),
    ],
)
def test_stream_empty_containers(stdin, expected):
    """Empty containers emit [path, container] instead of a [path] END."""
    # CATCHES: an empty array reports `[]` and an empty object `{}` as the
    # event value, and the outer array still gets its own END afterwards.
    res = stream(stdin)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_stream_multiple_top_level_values():
    """Each top-level value restarts the path from empty."""
    # CATCHES: the state machine resets between top-level values, so the
    # second value's events have empty paths again.
    res = stream(b'1 2 "x"')
    assert res.returncode == 0
    assert res.stdout == b'[[],1]\n[[],2]\n[[],"x"]\n'
    assert res.stderr == b""


def test_stream_unicode_keys_are_decoded():
    """\\uXXXX escapes in keys are decoded into real characters in the path."""
    # CATCHES: the path carries the decoded key, so `\\u00e9` becomes the
    # two UTF-8 bytes of é in the compact output.
    res = stream(b'{"\\u00e9":1}')
    assert res.returncode == 0
    assert res.stdout == '[["é"],1]\n[["é"]]\n'.encode()
    assert res.stderr == b""


def test_stream_empty_input_emits_no_events():
    """An empty stream produces no events and exits 0."""
    # CATCHES: --stream with no input is not an error and emits nothing.
    res = stream(b"")
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_stream_with_null_input_runs_once_on_null():
    """--stream -n still feeds null to the query, ignoring the stream."""
    # CATCHES: -n replaces the main loop iterator, so the stream parser only
    # runs when the query asks for input.
    res = run_gojq(["--stream", "-nc", "."], b"1")
    assert res.returncode == 0
    assert res.stdout == b"null\n"
    assert res.stderr == b""


def test_stream_inputs_builtin_yields_events():
    """Under -n the `inputs` builtin streams the parse events as values."""
    # CATCHES: `inputs` iterates the same stream parser, collecting every
    # [path, value] and [path] event into the array.
    res = run_gojq(["-nc", "[inputs]", "--stream"], b"[1]")
    assert res.returncode == 0
    assert res.stdout == b"[[[0],1],[[0]]]\n"
    assert res.stderr == b""


def test_stream_reads_named_file(tmp_path):
    """--stream works per file argument and resets state between files."""
    # CATCHES: each file gets a fresh stream state machine, so events from
    # the second file start from an empty path again.
    write_file(tmp_path, "one.json", b"[1]")
    write_file(tmp_path, "two.json", b"2")
    res = run_gojq(["--stream", "-c", ".", "one.json", "two.json"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"[[0],1]\n[[0]]\n[[],2]\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "stdin,partial,expected_err",
    [
        (
            b"[1",
            b"[[0],1]\n",
            b"gojq: invalid json: <stdin>\n    [1\n      ^  unexpected EOF\n",
        ),
        (
            b"[1,]",
            b"[[0],1]\n",
            b"gojq: invalid json: <stdin>\n    [1,]\n      ^  invalid character ']' looking for beginning of value\n",
        ),
        (
            b"[1] [2 x",
            b"[[0],1]\n[[0]]\n[[0],2]\n",
            b"gojq: invalid json: <stdin>\n    [1] [2 x\n          ^  invalid character 'x' after array element\n",
        ),
    ],
)
def test_stream_parse_errors_emit_partial_events(stdin, partial, expected_err):
    """Stream parse errors keep the events already emitted, then exit 5."""
    # CATCHES: events decoded before the failure are printed to stdout, the
    # Go json message is quoted verbatim, and the exit code is 5.
    res = stream(stdin)
    assert res.returncode == 5
    assert res.stdout == partial
    assert res.stderr == expected_err


def test_stream_with_slurp_parse_error_prints_nothing():
    """--stream -s fails before emitting because slurp buffers everything."""
    # CATCHES: the slurp wrapper drains the whole stream first, so a parse
    # error means no array is ever produced on stdout.
    res = run_gojq(["--stream", "-sc", "."], b"[1 x")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    [1 x\n"
        b"      ^  invalid character 'x' after array element\n"
    )
