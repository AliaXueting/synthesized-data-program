"""Input-iterator wiring in cli.go: value flags, per-mode names, and error types.

Covers the paths in cli/cli.go that build input values outside the main input
stream (--argjson, --jsonargs, --slurpfile, --rawfile), the input_filename
name each input mode reports, and the error renderings defined in cli/error.go
for flag and query parse failures.
"""

import pytest
from conftest import run_gojq, write_file


@pytest.fixture()
def corpus(tmp_path):
    """Create the files shared by the wiring tests."""
    write_file(tmp_path, "vals.json", b"1 2 3")
    write_file(tmp_path, "empty.json", b"")
    write_file(tmp_path, "bad.json", b"1 {")
    write_file(tmp_path, "raw.txt", b"x\ny\n")
    return tmp_path


@pytest.mark.parametrize(
    "args,stdin,expected",
    [
        (["-sc", "input_filename"], b"1 2", b'"<stdin>"\n'),
        (["-Rsc", "input_filename"], b"x\n", b'"<stdin>"\n'),
        (["--stream", "-sc", "input_filename"], b"1", b'"<stdin>"\n'),
        (["--yaml-input", "-c", "input_filename"], b"a: 1\n", b'"<stdin>"\n'),
        (["--yaml-input", "-c", "input_filename", "raw.txt"], b"", b'"raw.txt"\n'),
        (["-nRc", "input | input_filename", "raw.txt"], b"", b'"raw.txt"\n'),
    ],
)
def test_input_filename_in_every_input_mode(args, stdin, expected, corpus):
    """Every input mode names stdin `<stdin>` and files by their file name."""
    # CATCHES: the slurp, raw, raw-slurp, stream and YAML iterators all
    # forward their source name, so input_filename is mode-independent.
    res = run_gojq(args, stdin, cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_input_filename_null_after_slurping_a_file(corpus):
    """After -s drains a file there is no current file, so null."""
    # CATCHES: the slurped file iterator releases its inner iterator once
    # exhausted, so the name query falls back to null even though a file was
    # read, while the stdin case keeps reporting `<stdin>`.
    res = run_gojq(["-sc", "input_filename", "vals.json"], cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == b"null\n"
    stdin_case = run_gojq(["-sc", "input_filename"], b"1 2")
    assert stdin_case.returncode == 0
    assert stdin_case.stdout == b'"<stdin>"\n'
    assert stdin_case.stderr == b""


def test_slurpfile_reads_whole_file_as_array(corpus):
    """--slurpfile binds the file's values as one array variable."""
    # CATCHES: the whole file is slurped with the same iterator stack as -s,
    # so `1 2 3` becomes [1,2,3] and an empty file becomes [].
    res = run_gojq(["-c", "$x", "--slurpfile", "x", "vals.json"], b"null", cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == b"[1,2,3]\n"
    empty = run_gojq(["-c", "$x", "--slurpfile", "x", "empty.json"], b"null", cwd=corpus)
    assert empty.returncode == 0
    assert empty.stdout == b"[]\n"
    assert empty.stderr == b""


@pytest.mark.parametrize(
    "fname,expected_err",
    [
        (
            "nope.json",
            b"gojq: open nope.json: no such file or directory\n",
        ),
        (
            "bad.json",
            b"gojq: invalid json: bad.json\n"
            b"    1 {\n"
            b"       ^  unexpected EOF\n",
        ),
        (
            "raw.txt",
            b"gojq: invalid json: raw.txt\n"
            b"    x\n"
            b"    ^  invalid character 'x' looking for beginning of value\n",
        ),
    ],
)
def test_slurpfile_errors_are_reported_before_the_query_runs(fname, expected_err, corpus):
    """--slurpfile failures abort immediately with the file's error."""
    # CATCHES: the variable is loaded before compiling/running, so a missing
    # or malformed file stops everything with exit code 5 and no stdout.
    res = run_gojq(["-c", "$x", "--slurpfile", "x", fname], b"null", cwd=corpus)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == expected_err


def test_argjson_parses_exactly_one_value(corpus):
    """--argjson uses the first value and ignores any trailing text."""
    # CATCHES: only one Next() is taken from the argument's JSON iterator, so
    # `1 2` binds 1 without complaining about the leftover `2`.
    res = run_gojq(["-c", "$x", "--argjson", "x", "1 2"], b"null", cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    null = run_gojq(["-c", "$x", "--argjson", "x", "null"], b"null", cwd=corpus)
    assert null.returncode == 0
    assert null.stdout == b"null\n"
    assert null.stderr == b""


def test_argjson_invalid_value_names_the_variable(corpus):
    """A broken --argjson reports `invalid json: $name` with the value echo."""
    # CATCHES: the parse error's "file name" is the `$name` variable itself,
    # and the run aborts with exit 5 before the query is compiled.
    res = run_gojq(["-c", ".", "--argjson", "x", "{"], b"null", cwd=corpus)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: $x\n"
        b"    {\n"
        b"     ^  unexpected EOF\n"
    )


def test_jsonargs_parse_each_argument_as_one_value(corpus):
    """--jsonargs converts each following argument to a JSON value."""
    # CATCHES: each argument keeps only its first JSON value, and a broken
    # argument aborts with the name `--jsonargs` in the error header.
    res = run_gojq(
        ["-c", "$ARGS.positional", "--jsonargs", "1 {", "2"], b"null", cwd=corpus
    )
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n"
    bad = run_gojq(["-c", ".", "--jsonargs", "1", "{"], b"null", cwd=corpus)
    assert bad.returncode == 5
    assert bad.stdout == b""
    assert bad.stderr == (
        b"gojq: invalid json: --jsonargs\n"
        b"    {\n"
        b"     ^  unexpected EOF\n"
    )


def test_rawfile_binds_file_contents_as_a_string(corpus):
    """--rawfile binds the file bytes as one string, newline included."""
    # CATCHES: no JSON parsing happens, the contents are used verbatim, and a
    # missing file aborts with the plain open error.
    res = run_gojq(["-c", "$x", "--rawfile", "x", "raw.txt"], b"null", cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == b'"x\\ny\\n"\n'
    missing = run_gojq(["-c", ".", "--rawfile", "x", "nope.txt"], b"null", cwd=corpus)
    assert missing.returncode == 5
    assert missing.stdout == b""
    assert missing.stderr == b"gojq: open nope.txt: no such file or directory\n"


@pytest.mark.parametrize(
    "args,expected_err",
    [
        (["--nope"], b"gojq: unknown flag `--nope'\n"),
        (["--stream=1", "."], b"gojq: boolean flag `--stream' cannot have an argument\n"),
        (["--indent"], b"gojq: expected argument for flag `--indent'\n"),
        (
            ["--indent", "x", "."],
            b'gojq: invalid argument for flag `--indent\': strconv.Atoi: parsing "x": invalid syntax\n',
        ),
    ],
)
def test_flag_parse_errors_exit_two(args, expected_err):
    """Flag failures print the bare flag error and exit 2."""
    # CATCHES: flag errors are prefixed only with `gojq: ` (no category) and
    # use exit code 2, unlike input errors' 5 and compile errors' 3.
    res = run_gojq(args, b"1")
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == expected_err


def test_query_parse_error_single_line_form():
    """A one-line query error echoes the query with a caret under it."""
    # CATCHES: the query text replaces the file name, the echo is indented by
    # four spaces, and the exit code is 3.
    res = run_gojq([".["], b"1")
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid query: .[\n"
        b"    .[\n"
        b"      ^  unexpected EOF\n"
    )


def test_query_parse_error_multiline_uses_arg_and_line():
    """A query containing a newline uses the `<arg>:LINE` form."""
    # CATCHES: once the query text has a newline the header becomes
    # `invalid query: <arg>:2` with the line-numbered gutter.
    res = run_gojq([". |\n.["], b"1")
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid query: <arg>:2\n"
        b"    2 | .[\n"
        b"          ^  unexpected EOF\n"
    )


def test_query_parse_error_from_file_names_the_file(tmp_path):
    """-f query errors report the query file name and its line."""
    # CATCHES: with -f the error header carries the query file's name, and
    # the gutter shows the line inside that file.
    write_file(tmp_path, "qbad.jq", b". | .[")
    write_file(tmp_path, "qnl.jq", b". |\n.[1")
    res = run_gojq(["-f", "qbad.jq"], b"1", cwd=tmp_path)
    assert res.returncode == 3
    assert res.stderr == (
        b"gojq: invalid query: qbad.jq:1\n"
        b"    1 | . | .[\n"
        b"              ^  unexpected EOF\n"
    )
    res2 = run_gojq(["-f", "qnl.jq"], b"1", cwd=tmp_path)
    assert res2.returncode == 3
    assert res2.stderr == (
        b"gojq: invalid query: qnl.jq:2\n"
        b"    2 | .[1\n"
        b"           ^  unexpected EOF\n"
    )


def test_invalid_utf8_in_a_string_value_survives_as_replacement():
    """Invalid UTF-8 inside a JSON string becomes U+FFFD, not an error."""
    # CATCHES: the decoder replaces the bad byte with the replacement
    # character, so the value round-trips to stdout instead of failing.
    res = run_gojq(["-c", "."], b'0 "a\xffb" @')
    assert res.returncode == 5
    assert res.stdout == b'0\n"a\xef\xbf\xbdb"\n'
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b'    0 "a\xffb" @\n'
        b"            ^  invalid character '@' looking for beginning of value\n"
    )


def test_invalid_utf8_at_error_offset_is_trimmed_from_the_echo():
    """A trailing invalid byte is dropped from the echoed error line."""
    # CATCHES: the echoed line keeps the valid `1 ` prefix but the bad byte is
    # trimmed from the end, and the message names the byte as the rune ÿ.
    res = run_gojq(["-c", "."], b"1 \xff")
    assert res.returncode == 5
    assert res.stdout == b"1\n"
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    1 \n"
        b"      ^  invalid character '\xc3\xbf' looking for beginning of value\n"
    )


def test_debug_and_stderr_builtins_write_to_stderr():
    """`debug` logs a JSON pair and `stderr` writes the raw value, on stderr."""
    # CATCHES: both builtins write to standard error while the value still
    # flows to stdout; `stderr` adds no trailing newline but `debug` does.
    res = run_gojq(["-nc", "1 | debug | stderr"])
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b'["DEBUG:",1]\n1'


@pytest.mark.parametrize(
    "query,expected_err",
    [
        (["error(\"boom\")"], b"gojq: error: boom\n"),
        (["error(null)"], b"gojq: error: null\n"),
        (["error(3)"], b"gojq: error: 3\n"),
        (["error({\"a\":1})"], b"gojq: error: {\"a\":1}\n"),
    ],
)
def test_error_builtin_renders_the_value_after_the_prefix(query, expected_err):
    """The `error` builtin prints `gojq: error: <json>` and exits 5."""
    # CATCHES: the raised value is marshaled compactly between the `gojq:
    # error: ` prefix and the newline, whether it is a string, null, a
    # number, or an object.
    res = run_gojq(["-nc"] + query)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == expected_err


def test_query_error_is_reported_per_input_and_processing_continues():
    """A raised error is printed for each input; the run keeps going."""
    # CATCHES: a query error on one input does not stop input iteration, so
    # two stdin values produce two identical error lines and exit 5, while a
    # `try` that catches the error keeps the exit code 0.
    res = run_gojq(["-c", "error(1)"], b"0 0")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: error: 1\ngojq: error: 1\n"
    caught = run_gojq(["-c", "try error(1) catch ."], b"0 0")
    assert caught.returncode == 0
    assert caught.stdout == b"1\n1\n"
    assert caught.stderr == b""


def test_halt_stops_processing_and_output():
    """`halt` ends the run quietly, keeping values already printed."""
    # CATCHES: `halt` stops the whole run with exit code 0, so the value
    # after it in the generator never reaches stdout and nothing is logged.
    res = run_gojq(["-nc", "1, halt, 2"])
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "query,expected_err,expected_code",
    [
        (["\"msg\" | halt_error"], b"msg", 5),
        (["{\"a\":1} | halt_error"], b'{"a":1}\n', 5),
        (["3 | halt_error(1)"], b"3\n", 1),
        (["halt_error"], b"", 5),
    ],
)
def test_halt_error_writes_the_value_to_stderr(query, expected_err, expected_code):
    """`halt_error` writes its value to stderr and exits with its code."""
    # CATCHES: a string value is written raw with NO trailing newline, while
    # other values are JSON-marshaled with one; the exit code is the given
    # code or the default 5 for a missing argument (a bare null value).
    res = run_gojq(["-nc"] + query)
    assert res.returncode == expected_code
    assert res.stdout == b""
    assert res.stderr == expected_err
