"""Shared black-box helpers for the input_processing test module.

Every expectation embedded in this module's tests was recorded by running the
reference ``gojq`` binary through its command line interface only.  Tests never
call into the binary's internals and never hardcode a path to it: the
executable location always comes from ``PROGRAMGYM_EXECUTABLE``.
"""

import functools
import os
import subprocess
import tempfile
from pathlib import Path


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--version' once against a throwaway GOCOVERDIR, so the
    check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="gojq-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def gojq_executable():
    """Return the binary under test, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the gojq binary under test"
        )
    # The pipeline's coverage driver sets GOCOVERDIR, but the module's own
    # `executable` is an uninstrumented build that ignores it, so counters
    # would never be written and this module's coverage report would stay
    # empty.  When a coverage run is in progress and the assigned binary is
    # not instrumented, fall back to the instrumented build staged one level
    # above the module workspaces.  It only exists in that layout, so plain
    # validation and release runs keep using the assigned binary.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(str(staged)):
            return str(staged)
    return path


def _pinned_env(cwd=None, env=None):
    """Build the child environment from scratch: no TTY, no color, no noise.

    TERM, NO_COLOR and FORCE_COLOR are deliberately absent, and the locale is
    pinned, so error rendering never depends on the ambient environment.
    """
    child = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
    }
    # Forwarded only so a coverage-instrumented binary can write its counters;
    # the gojq behavior under test never reads these.
    for passthrough in ("GOCOVERDIR",):
        if os.environ.get(passthrough):
            child[passthrough] = os.environ[passthrough]
    if cwd is not None:
        child["HOME"] = str(cwd)
    if env:
        child.update(env)
    return child


def run_gojq(args, stdin=b"", cwd=None, env=None, timeout=30):
    """Run gojq with 'args' and return the CompletedProcess result.

    stdin is always a pipe and stdout/stderr are always captured, so the
    program never sees a terminal and the bytes it writes are exact.
    """
    return subprocess.run(
        [gojq_executable()] + list(args),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=_pinned_env(cwd, env),
        timeout=timeout,
    )


def write_file(directory, name, content):
    """Write 'content' into directory/name and return the path object."""
    path = Path(directory) / name
    if isinstance(content, str):
        content = content.encode()
    path.write_bytes(content)
    return path
