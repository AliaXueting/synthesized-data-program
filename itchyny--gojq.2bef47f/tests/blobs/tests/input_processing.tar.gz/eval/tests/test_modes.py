"""Input mode flags: -n, -R, -s, --stream, --yaml-input and their precedence."""

import pytest
from conftest import run_gojq, write_file


@pytest.fixture()
def corpus(tmp_path):
    """Create the files shared by the mode tests."""
    write_file(tmp_path, "a.json", b"1 2\n")
    write_file(tmp_path, "b.json", b"3")
    write_file(tmp_path, "lines.txt", b"foo\nbar\nbaz\n")
    return tmp_path


def test_null_input_runs_the_query_once_on_null():
    """-n feeds a single null regardless of the (ignored) stdin contents."""
    # CATCHES: under -n the main loop never reads the input stream, so stdin
    # is left untouched for `input`/`inputs` and exactly one null is produced.
    res = run_gojq(["-nc", "[.]"], b"1 2 3")
    assert res.returncode == 0
    assert res.stdout == b"[null]\n"
    assert res.stderr == b""


def test_null_input_files_still_readable_by_inputs(corpus):
    """With -n, file arguments are still consumed by the `inputs` builtin."""
    # CATCHES: -n swaps only the main-loop iterator; the compiled query keeps
    # the real file iterator, so `inputs` drains every file's values.
    res = run_gojq(["-nc", "[inputs]", "a.json", "b.json"], cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == b"[1,2,3]\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "stdin,expected",
    [
        (b"foo\nbar\nbaz\n", b'"foo"\n"bar"\n"baz"\n'),
        (b"last", b'"last"\n'),
        (b"\n\n\n", b'""\n""\n""\n'),
        (b"a\r\nb\r\n", b'"a\\r"\n"b\\r"\n'),
        (b"a\rb", b'"a\\rb"\n'),
        (b"a\n\nb", b'"a"\n""\n"b"\n'),
        (b"", b""),
        (b'{"a": 1}\n[1,2]', b'"{\\"a\\": 1}"\n"[1,2]"\n'),
    ],
)
def test_raw_input_splits_on_newlines(stdin, expected):
    """-R reads one string per line, trimming exactly one trailing newline."""
    # CATCHES: only the final `\n` is stripped (a CR before it survives),
    # a last line without newline is still emitted, empty lines become empty
    # strings, and empty input yields no strings at all.
    res = run_gojq(["-Rc", "."], stdin)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_raw_input_reads_each_file_line_by_line(corpus):
    """-R applies per line to each file argument independently."""
    # CATCHES: every file is split on its own newlines; files without a
    # trailing newline still produce their last line.
    write_file(corpus, "noeol.txt", b"last")
    write_file(corpus, "empty.txt", b"")
    res = run_gojq(["-Rc", ".", "lines.txt", "noeol.txt", "empty.txt"], cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == b'"foo"\n"bar"\n"baz"\n"last"\n'
    assert res.stderr == b""


@pytest.mark.parametrize(
    "stdin,expected",
    [
        (b"1 2 3", b"[1,2,3]\n"),
        (b"", b"[]\n"),
        (b"  \n\n  ", b"[]\n"),
        (b'{"a":1} [2,3] 4', b'[{"a":1},[2,3],4]\n'),
    ],
)
def test_slurp_collects_values_into_one_array(stdin, expected):
    """-s gathers every input value into a single array."""
    # CATCHES: empty or whitespace-only input gives an empty array, not null
    # or an error, and all values keep their order and types.
    res = run_gojq(["-sc", "."], stdin)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_slurp_spans_all_file_arguments(corpus):
    """-s collects the values of every file into the one array."""
    # CATCHES: the slurp wrapper sits above the file iterator, so values from
    # later files join the same array.
    res = run_gojq(["-sc", ".", "a.json", "b.json"], cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == b"[1,2,3]\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "stdin,expected",
    [
        (b"foo\nbar\nbaz\n", b'"foo\\nbar\\nbaz\\n"\n'),
        (b"last", b'"last"\n'),
        (b"", b'""\n'),
        (b"a\x00b\n", b'"a\\u0000b\\n"\n'),
    ],
)
def test_slurp_raw_reads_entire_input_as_one_string(stdin, expected):
    """-R with -s returns the whole input as a single string, untrimmed."""
    # CATCHES: no newline trimming happens at all in this mode, the empty
    # input is the empty string, and NUL bytes survive as \\u0000 escapes.
    res = run_gojq(["-Rsc", "."], stdin)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_slurp_raw_joins_all_files_into_one_string(corpus):
    """-R -s concatenates the full contents of every file argument."""
    # CATCHES: each file is read to its end and the strings are joined with
    # nothing in between, so newlines between files are preserved verbatim.
    res = run_gojq(["-Rsc", ".", "lines.txt", "lines.txt"], cwd=corpus)
    assert res.returncode == 0
    assert res.stdout == b'"foo\\nbar\\nbaz\\nfoo\\nbar\\nbaz\\n"\n'
    assert res.stderr == b""


def test_raw_input_takes_precedence_over_stream():
    """-R wins over --stream: input is treated as raw lines, not events."""
    # CATCHES: the mode switch checks -R first, so `--stream -R` never parses
    # JSON and emits one string per line.
    res = run_gojq(["--stream", "-R", "-c", "."], b"1\n2\n")
    assert res.returncode == 0
    assert res.stdout == b'"1"\n"2"\n'
    assert res.stderr == b""


def test_raw_input_takes_precedence_over_yaml_input():
    """-R wins over --yaml-input too: lines are raw strings, not documents."""
    # CATCHES: YAML parsing never happens when -R is given, so even YAML
    # mappings come through as plain lines.
    res = run_gojq(["--yaml-input", "-Rc", "."], b"a: 1\n")
    assert res.returncode == 0
    assert res.stdout == b'"a: 1"\n'
    assert res.stderr == b""


def test_stream_takes_precedence_over_yaml_input():
    """--stream parses as JSON even together with --yaml-input."""
    # CATCHES: the stream mode is chosen before the YAML mode, so YAML text
    # fails JSON parsing and reports `invalid json`, not `invalid yaml`.
    res = run_gojq(["--yaml-input", "--stream", "-c", "."], b"a: 1\n")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    a: 1\n"
        b"    ^  invalid character 'a' looking for beginning of value\n"
    )


def test_raw_slurp_ignores_stream_flag():
    """-R -s --stream reads the whole input, ignoring the stream parser."""
    # CATCHES: -R is checked first and -s turns it into a read-all, so the
    # --stream flag contributes nothing.
    res = run_gojq(["-R", "-s", "--stream", "-c", "."], b"1\n2\n")
    assert res.returncode == 0
    assert res.stdout == b'"1\\n2\\n"\n'
    assert res.stderr == b""


def test_stream_with_slurp_collects_events_into_array():
    """--stream -s puts every streaming event into one array."""
    # CATCHES: the slurp wrapper collects the event pairs, so the output is a
    # single array of [path, value] and [path] entries.
    res = run_gojq(["--stream", "-sc", "."], b"[1,2]")
    assert res.returncode == 0
    assert res.stdout == b"[[[0],1],[[1],2],[[1]]]\n"
    assert res.stderr == b""


def test_null_input_with_slurp_input_builtin_yields_the_array():
    """Under -n -s the `input` builtin returns the one slurped array."""
    # CATCHES: `input` and the main loop share the same slurped iterator, so
    # one call yields the whole array and a second would be exhausted.
    res = run_gojq(["-nsc", "input"], b"1 2")
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n"
    assert res.stderr == b""


def test_null_input_with_slurp_inputs_yields_nested_array():
    """Under -n -s the `inputs` builtin produces one element: the array."""
    # CATCHES: the slurped iterator emits exactly one value, so `[inputs]`
    # wraps that single array in another array.
    res = run_gojq(["-nsc", "[inputs]"], b"1 2")
    assert res.returncode == 0
    assert res.stdout == b"[[1,2]]\n"
    assert res.stderr == b""


def test_slurp_with_input_builtin_is_exhausted_after_main_value():
    """Without -n, -s consumes the array for `.` so `input` is exhausted."""
    # CATCHES: the main loop takes the single slurped value before the query
    # runs, leaving nothing for `input`, which reports `gojq: break`.
    res = run_gojq(["-sc", "input"], b"1 2")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: break\n"


def test_clustered_and_long_flag_forms_are_equivalent():
    """-nRsc clustering and the long flag names select the same modes."""
    # CATCHES: short flags cluster in any grouping and the long names
    # --null-input/--raw-input/--slurp/--compact-output map to the same mode.
    res = run_gojq(["-nRc", "."], b"x\n")
    assert res.returncode == 0
    assert res.stdout == b"null\n"
    long = run_gojq(["--null-input", "--raw-input", "--compact-output", "."], b"x\n")
    assert long.returncode == 0
    assert long.stdout == b"null\n"
    assert long.stderr == b""
