"""Exact rendering of malformed-JSON errors by cli/error.go.

The single-line form is::

    gojq: invalid json: <stdin>
        <line>
        ^  <go json message>

and the multi-line form is::

    gojq: invalid json: <stdin>:LINE
        LINE | <line>
              ^  <go json message>
"""

import pytest
from conftest import run_gojq, write_file

VALUE = b'{"a": 1}'


def test_invalid_object_key_single_line_form():
    """A bad object key on line 1 gets the caret under the offending byte."""
    # CATCHES: the message quotes the Go json decoder text verbatim
    # (`invalid character 'b' looking for beginning of object key string`)
    # and the caret sits one byte into the echoed line.
    res = run_gojq(["-c", "."], b"{bad: 1}")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    {bad: 1}\n"
        b"     ^  invalid character 'b' looking for beginning of object key string\n"
    )


def test_invalid_value_single_line_form():
    """A bad value start echoes the line with the caret under the character."""
    # CATCHES: the caret column tracks the exact byte offset of the failure,
    # here under the `x` following two valid values.
    res = run_gojq(["-c", "."], b"1 2 x")
    assert res.returncode == 5
    assert res.stdout == b"1\n2\n"
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    1 2 x\n"
        b"        ^  invalid character 'x' looking for beginning of value\n"
    )


def test_unterminated_string_reports_unexpected_eof():
    """An unterminated string reports `unexpected EOF` past the line end."""
    # CATCHES: for unexpected EOF the caret is placed one column past the end
    # of the echoed line, not under a real character.
    res = run_gojq(["-c", "."], b'"abc')
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b'    "abc\n'
        b"        ^  unexpected EOF\n"
    )


def test_invalid_array_element_error():
    """A trailing comma inside an array points at the closing bracket."""
    # CATCHES: after the first value is emitted, the `]` is rejected with the
    # Go message `invalid character ']' looking for beginning of value`.
    res = run_gojq(["-c", "."], b'0["a",]')
    assert res.returncode == 5
    assert res.stdout == b"0\n"
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b'    0["a",]\n'
        b"          ^  invalid character ']' looking for beginning of value\n"
    )


def test_unexpected_eof_inside_array():
    """A truncated array reports unexpected EOF with the partial value kept."""
    # CATCHES: the value decoded before the truncation (`0`) still reaches
    # stdout before the error stops the run with exit code 5.
    res = run_gojq(["-c", "."], b"0[1")
    assert res.returncode == 5
    assert res.stdout == b"0\n"
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    0[1\n"
        b"       ^  unexpected EOF\n"
    )


def test_values_before_the_error_are_printed():
    """Every value decoded before the syntax error is still output."""
    # CATCHES: the decoder streams values out one by one, so all of
    # 1, 2, 3 are printed before the error on line 4 aborts processing.
    res = run_gojq(["-c", "."], b"1\n2\n3\n@\n")
    assert res.returncode == 5
    assert res.stdout == b"1\n2\n3\n"
    assert res.stderr == (
        b"gojq: invalid json: <stdin>:4\n"
        b"    4 | @\n"
        b"        ^  invalid character '@' looking for beginning of value\n"
    )


@pytest.mark.parametrize(
    "stdin,expected_err",
    [
        (
            b"0\n{\n  0",
            b"gojq: invalid json: <stdin>:3\n"
            b"    3 |   0\n"
            b"          ^  invalid character '0' looking for beginning of object key string\n",
        ),
        (
            b'0\n{\n  "a":\n}',
            b"gojq: invalid json: <stdin>:4\n"
            b"    4 | }\n"
            b"        ^  invalid character '}' looking for beginning of value\n",
        ),
        (
            b'{\n  "a": 1,\n  "b": @\n}',
            b"gojq: invalid json: <stdin>:3\n"
            b'    3 |   "b": @\n'
            b"               ^  invalid character '@' looking for beginning of value\n",
        ),
        (
            b"\n\n@",
            b"gojq: invalid json: <stdin>:3\n"
            b"    3 | @\n"
            b"        ^  invalid character '@' looking for beginning of value\n",
        ),
    ],
)
def test_multiline_errors_use_file_colon_line_form(stdin, expected_err):
    """Errors past line 1 switch to the `NAME:LINE` form with a line gutter."""
    # CATCHES: once the computed line is greater than 1 the format changes to
    # `<stdin>:LINE` plus a `LINE | ` prefix on the echoed line, and the caret
    # accounts for the gutter width.
    res = run_gojq(["-c", "."], stdin)
    assert res.returncode == 5
    assert res.stderr == expected_err


def test_crlf_counts_as_one_line_separator():
    """A \\r\\n pair ends one line; the \\r is not echoed on the next line."""
    # CATCHES: line counting treats CRLF as a single separator, so the bad `0`
    # is line 3 and the echoed line contains no stray carriage return.
    res = run_gojq(["-c", "."], b"1\r\n{\r\n0")
    assert res.returncode == 5
    assert res.stdout == b"1\n"
    assert res.stderr == (
        b"gojq: invalid json: <stdin>:3\n"
        b"    3 | 0\n"
        b"        ^  invalid character '0' looking for beginning of object key string\n"
    )


def test_lone_cr_also_ends_a_line():
    """A bare \\r is a line separator for error reporting."""
    # CATCHES: even though JSON only needs \\n, the error context splitter
    # breaks on a lone \\r too, giving the same line 3 report.
    res = run_gojq(["-c", "."], b"1\r{\r0")
    assert res.returncode == 5
    assert res.stdout == b"1\n"
    assert res.stderr == (
        b"gojq: invalid json: <stdin>:3\n"
        b"    3 | 0\n"
        b"        ^  invalid character '0' looking for beginning of object key string\n"
    )


def test_caret_column_uses_display_width():
    """The caret column counts double-width characters as two columns."""
    # CATCHES: alignment uses terminal cell width, so the two CJK characters
    # shift the caret four columns, not two.
    res = run_gojq(["-c", "."], '{\n  "日本": @\n}'.encode())
    assert res.returncode == 5
    assert res.stderr == (
        "gojq: invalid json: <stdin>:2\n"
        '    2 |   "日本": @\n'
        "                  ^  invalid character '@' looking for beginning of value\n"
    ).encode()
    assert res.stdout == b""


def test_long_line_is_truncated_to_64_chars():
    """The echoed line is clipped to 64 characters, caret kept in range."""
    # CATCHES: a 102-character line is echoed only up to 64 characters, while
    # the caret still points at the offending `x` near the start.
    res = run_gojq(["-c", "."], b"0 " + b"x" * 100 + b"\n")
    assert res.returncode == 5
    assert res.stdout == b"0\n"
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    0 " + b"x" * 62 + b"\n"
        b"      ^  invalid character 'x' looking for beginning of value\n"
    )


def test_far_offset_slides_a_48_char_window():
    """When the error is far into a line, the echo starts 48 columns earlier."""
    # CATCHES: for offsets past 48 the echoed window starts at offset-48, so
    # only the tail of the line is shown with the caret still under the `@`.
    res = run_gojq(["-c", "."], b"[" + b"0," * 40 + b"@]")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,@]\n"
        b"                                                    ^  invalid character '@' looking for beginning of value\n"
    )


def test_utf8_bom_is_rejected():
    """A byte-order mark is not JSON whitespace; the error quotes byte 0xEF."""
    # CATCHES: the message shows the BOM's first byte as the Latin-1 rune
    # `ï` (UTF-8 encoded) while the echoed line contains the raw BOM bytes.
    res = run_gojq(["-c", "."], b"\xef\xbb\xbf1")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    \xef\xbb\xbf1\n"
        b"    ^  invalid character '\xc3\xaf' looking for beginning of value\n"
    )


def test_exceeded_max_depth_error():
    """Nesting beyond Go's decoder limit reports `exceeded max depth`."""
    # CATCHES: at 10001 levels the decoder gives up, the 64-char window ends
    # in closing brackets, and the message differs from a syntax error.
    res = run_gojq(["-c", "empty"], b"[" * 10001 + b"]" * 10001)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    " + (b"[" * 49) + (b"]" * 15) + b"\n"
        + (b" " * 52) + b"^  invalid character '[' exceeded max depth\n"
    )
    ok = run_gojq(["-c", "empty"], b"[" * 9999 + b"]" * 9999)
    assert ok.returncode == 0
    assert ok.stdout == b""
    assert ok.stderr == b""


def test_duplicate_object_keys_are_not_an_error():
    """Duplicate keys in a JSON object silently keep the last value."""
    # CATCHES: unlike YAML mode, JSON input accepts repeated keys, and the
    # later value overwrites the earlier one.
    res = run_gojq(["-c", "."], b'{"a":1,"a":2}')
    assert res.returncode == 0
    assert res.stdout == b'{"a":2}\n'
    assert res.stderr == b""


@pytest.mark.parametrize(
    "bad_tail",
    [b'\n"\\q"\n', b"\n[1"],
)
def test_error_context_survives_the_16k_buffer_boundary(bad_tail):
    """A 20 KiB value before the error still yields the right line and text."""
    # CATCHES: the decoder buffers 16 KiB at a time; the error context still
    # points at line 2 and echoes the short offending line, not the big value.
    stdin = b'"' + b"a" * 20480 + b'"' + bad_tail
    res = run_gojq(["-c", "."], stdin)
    assert res.returncode == 5
    expected = {
        b'\n"\\q"\n': (
            b'    2 | "\\q"\n'
            b"          ^  invalid character 'q' in string escape code\n"
        ),
        b"\n[1": b"    2 | [1\n          ^  unexpected EOF\n",
    }[bad_tail]
    assert res.stderr == b"gojq: invalid json: <stdin>:2\n" + expected


def test_line_tracking_across_many_buffer_resets():
    """10000 lines of input keep the error line number exact."""
    # CATCHES: each 16 KiB buffer reset advances the tracked line count, so
    # the error after 10001 lines is reported on line 10002.
    stdin = b"0\n" * 10000 + b'"' + b"a" * 20480 + b'"\n[1'
    res = run_gojq(["-c", "."], stdin)
    assert res.returncode == 5
    assert res.stderr == (
        b"gojq: invalid json: <stdin>:10002\n"
        b"    10002 | [1\n"
        b"              ^  unexpected EOF\n"
    )


def test_line_counting_for_many_single_values():
    """A run of single values keeps its own line count for the error line."""
    # CATCHES: 40000 newline-separated values are all emitted, and the bad
    # token after them is reported on line 40001.
    res = run_gojq(["-c", "."], b"0\n" * 40000 + b":\n")
    assert res.returncode == 5
    assert res.stdout.count(b"0\n") == 40000
    assert res.stderr == (
        b"gojq: invalid json: <stdin>:40001\n"
        b"    40001 | :\n"
        b"            ^  invalid character ':' looking for beginning of value\n"
    )


def test_file_errors_echo_the_file_name_and_line(tmp_path):
    """A malformed file reports `invalid json: NAME:LINE` with its own name."""
    # CATCHES: the file argument's name replaces `<stdin>` in the header while
    # the rest of the rendering is byte-identical to the stdin case.
    write_file(tmp_path, "m1.json", b'{\n  "a": 1,\n  0\n}')
    write_file(tmp_path, "m2.json", b'0\n{\n  "a":\n}')
    res = run_gojq(["-c", ".", "m1.json"], cwd=tmp_path)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: m1.json:3\n"
        b"    3 |   0\n"
        b"          ^  invalid character '0' looking for beginning of object key string\n"
    )
    res2 = run_gojq(["-c", ".", "m2.json"], cwd=tmp_path)
    assert res2.returncode == 5
    assert res2.stdout == b"0\n"
    assert res2.stderr == (
        b"gojq: invalid json: m2.json:4\n"
        b"    4 | }\n"
        b"        ^  invalid character '}' looking for beginning of value\n"
    )


def test_pipe_and_seekable_file_report_identical_context(tmp_path):
    """A piped stdin and a seekable file give the same error line for >16 KiB."""
    # CATCHES: the reader re-seeks files but tees pipes into a buffer; both
    # paths must agree, here on line 40001 of a 40 KiB input.
    data = b"0[0," + b"\n" * 40000 + b"1\n"
    piped = run_gojq(["-c", "."], data)
    write_file(tmp_path, "large.json", data)
    filed = run_gojq(["-c", ".", "large.json"], cwd=tmp_path)
    assert piped.returncode == filed.returncode == 5
    assert piped.stdout == filed.stdout == b"0\n"
    assert piped.stderr == (
        b"gojq: invalid json: <stdin>:40001\n"
        b"    40001 | 1\n"
        b"             ^  unexpected EOF\n"
    )
    assert filed.stderr == piped.stderr.replace(b"<stdin>", b"large.json")


def test_parse_error_in_one_file_continues_with_the_next(tmp_path):
    """A bad file abandons only that file; later files are still processed."""
    # CATCHES: the file iterator moves on after the inner parser errors, so
    # good.json's `2` is still printed after the error for bad.json.
    write_file(tmp_path, "bad.json", b"1 {")
    write_file(tmp_path, "good.json", b"2")
    res = run_gojq(["-c", ".", "bad.json", "good.json"], cwd=tmp_path)
    assert res.returncode == 5
    assert res.stdout == b"1\n2\n"
    assert res.stderr == (
        b"gojq: invalid json: bad.json\n"
        b"    1 {\n"
        b"       ^  unexpected EOF\n"
    )


def test_every_bad_file_reports_its_own_error(tmp_path):
    """Two malformed files each produce their own error block, in order."""
    # CATCHES: processing does not stop at the first parse error, and each
    # error is prefixed by its own file name.
    write_file(tmp_path, "bad.json", b"1 {")
    write_file(tmp_path, "bad2.json", b"} }")
    res = run_gojq(["-c", ".", "bad.json", "bad2.json"], cwd=tmp_path)
    assert res.returncode == 5
    assert res.stdout == b"1\n"
    assert res.stderr == (
        b"gojq: invalid json: bad.json\n"
        b"    1 {\n"
        b"       ^  unexpected EOF\n"
        b"gojq: invalid json: bad2.json\n"
        b"    } }\n"
        b"    ^  invalid character '}' looking for beginning of value\n"
    )


def test_slurp_with_parse_error_outputs_nothing():
    """With -s a parse error suppresses the whole array output."""
    # CATCHES: slurp buffers all values before emitting, so the error means
    # stdout stays empty even though a valid value came first.
    res = run_gojq(["-sc", "."], b"1 {")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: <stdin>\n"
        b"    1 {\n"
        b"       ^  unexpected EOF\n"
    )


@pytest.mark.parametrize("extra_flags", [[], ["-e"], ["-r"], ["--tab"]])
def test_input_error_exit_code_is_five_regardless_of_output_flags(extra_flags):
    """Input parse errors always exit 5, unchanged by output flags and -e."""
    # CATCHES: the exit code for input errors is the default error code 5 and
    # is not overridden by -e's falsy/no-value codes.
    res = run_gojq(extra_flags + ["."], b"1 {")
    assert res.returncode == 5
    assert res.stdout == b"1\n"
    assert res.stderr.endswith(b"unexpected EOF\n")
