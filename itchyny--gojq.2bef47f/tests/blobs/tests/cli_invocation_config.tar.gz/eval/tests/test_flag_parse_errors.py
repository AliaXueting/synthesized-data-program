"""Flag-parsing diagnostics of the reflection-based parser in ``cli/flags.go``.

Every malformed invocation is rejected before any query is compiled or any
input is read, and the diagnostic is printed as ``gojq: <message>`` on stderr
with exit code 2.  These tests pin the exact message wording (including the
backquote-quoting of flag names), the stream, and the exit code.
"""

from __future__ import annotations

import pytest

from conftest import run_gojq

# All expectations below were recorded by running ./executable.

# Long flags that jq has but gojq does not define.
UNKNOWN_LONG_FLAGS = [
    "--sort-keys",
    "--unbuffered",
    "--ascii-output",
    "--seq",
    "--exit-status-extra",
    "--raw-output00",
]

# Short letters that are not bound to any flag (gojq defines r j c C M n R s f L e v h).
UNKNOWN_SHORT_FLAGS = ["-a", "-S", "-A", "-l", "-m", "-z", "-i", "-o"]

# Every boolean long flag: giving one an `=value` is rejected at parse time.
BOOLEAN_LONG_FLAGS = [
    "--raw-output",
    "--raw-output0",
    "--join-output",
    "--compact-output",
    "--tab",
    "--yaml-output",
    "--color-output",
    "--monochrome-output",
    "--null-input",
    "--raw-input",
    "--stream",
    "--yaml-input",
    "--slurp",
    "--from-file",
    "--exit-status",
    "--version",
    "--help",
]

# Map-valued flags that consume exactly two arguments.
TWO_ARGUMENT_FLAGS = ["--arg", "--argjson", "--slurpfile", "--rawfile"]


def test_unknown_long_flag_message_and_exit_code():
    """An unrecognised long flag is quoted with backquotes and exits 2."""
    res = run_gojq(["--definitely-not-a-flag"])
    # CATCHES: the parser reports the whole argument, backquote-quoted, as
    # `unknown flag `--definitely-not-a-flag'' on stderr with exit code 2.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `--definitely-not-a-flag'\n"


def test_unknown_short_flag_message_and_exit_code():
    """An unrecognised single-letter short flag names only the letter."""
    res = run_gojq(["-x"])
    # CATCHES: for short flags the diagnostic carries just the letter, not the
    # whole argument (`unknown flag `x''), unlike long flags.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `x'\n"


@pytest.mark.parametrize("flag", UNKNOWN_LONG_FLAGS)
def test_jq_style_flags_are_unknown(flag):
    """Flags known from jq but absent from gojq are rejected as unknown."""
    res = run_gojq([flag])
    # CATCHES: gojq defines no --sort-keys/--unbuffered/--ascii-output/--seq
    # flags; a re-implementation that borrows jq's flag set would accept them.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `%s'\n" % flag.encode()


@pytest.mark.parametrize("flag", UNKNOWN_SHORT_FLAGS)
def test_undefined_short_letters_are_unknown(flag):
    """Short letters without a bound flag are rejected naming the letter."""
    res = run_gojq([flag])
    # CATCHES: only r j c C M n R s f L e v h are bound; every other letter
    # (including jq's -S and -a) yields `unknown flag `<letter>''.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `%s'\n" % flag[1:].encode()


@pytest.mark.parametrize("flag", BOOLEAN_LONG_FLAGS)
def test_boolean_flag_cannot_have_an_argument(flag):
    """``--bool=value`` is rejected for every boolean long flag."""
    res = run_gojq([flag + "=yes"])
    # CATCHES: boolean flags reject attached values with `boolean flag `X'
    # cannot have an argument'; the message names the flag without `=yes'.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: boolean flag `%s' cannot have an argument\n" % flag.encode()


def test_boolean_message_names_flag_without_the_value():
    """The `=value` part is stripped from the flag name in the message."""
    res = run_gojq(["--tab=some-long-value"])
    # CATCHES: the diagnostic quotes `--tab' only, not `--tab=some-long-value',
    # so the parser splits on `=' before reporting.
    assert res.returncode == 2
    assert res.stderr == b"gojq: boolean flag `--tab' cannot have an argument\n"


@pytest.mark.parametrize("flag", ["--indent", "-L", "--library-path"])
def test_missing_argument_for_single_argument_flag(flag):
    """Value-taking flags at the end of argv report `expected argument'."""
    res = run_gojq([flag])
    # CATCHES: --indent and -L/--library-path need one argument; running out
    # of arguments yields `expected argument for flag `X'' with exit code 2.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: expected argument for flag `%s'\n" % flag.encode()


@pytest.mark.parametrize("flag", TWO_ARGUMENT_FLAGS)
@pytest.mark.parametrize("tail", [[], ["only-one"]], ids=["zero", "one"])
def test_map_flags_require_two_arguments(flag, tail):
    """The four name/value map flags demand exactly two arguments."""
    res = run_gojq([flag] + tail)
    # CATCHES: --arg/--argjson/--slurpfile/--rawfile consume two arguments;
    # with fewer the parser says `expected 2 arguments' (not `expected
    # argument') and exits 2.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: expected 2 arguments for flag `%s'\n" % flag.encode()


@pytest.mark.parametrize("value", ["x", "abc", "1.5", "", "0x2", "1_0"])
def test_non_integer_indent_is_a_flag_error(value):
    """``--indent`` values that Atoi rejects produce a strconv-wrapped error."""
    res = run_gojq(["--indent", value, "."])
    # CATCHES: the integer conversion failure surfaces verbatim as
    # `invalid argument for flag `--indent': strconv.Atoi: parsing ...'.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid argument for flag `--indent': "
        b'strconv.Atoi: parsing "%s": invalid syntax\n' % value.encode()
    )


@pytest.mark.parametrize("cluster", ["-cx", "-nx", "-rx", "-cnx", "-ex"])
def test_unknown_letter_inside_a_cluster(cluster):
    """An unknown letter anywhere in a short cluster aborts parsing."""
    res = run_gojq([cluster, "."])
    # CATCHES: clustered shorts are expanded letter by letter, so the bad
    # letter is reported on its own (`unknown flag `x'') even mid-cluster.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `x'\n"


@pytest.mark.parametrize("order", [["--badflag", "--help"], ["--help", "--badflag"]])
def test_flag_error_beats_help_in_any_order(order):
    """A parse error wins over --help regardless of argument order."""
    res = run_gojq(order)
    # CATCHES: parseFlags scans every argument before help is honored, so an
    # unknown flag is fatal (exit 2) even when --help was already seen.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `--badflag'\n"


def test_unknown_flag_after_the_query_is_still_fatal():
    """Option scanning does not stop at the first positional argument."""
    res = run_gojq([".", "-x"])
    # CATCHES: flags may appear after the query; an unknown one still aborts
    # with exit 2 instead of being treated as an input filename.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `x'\n"


def test_unknown_flag_beats_predefined_variable_setup():
    """A later unknown flag wins over earlier valid --arg definitions."""
    res = run_gojq(["--arg", "k", "v", "--no-such-flag"])
    # CATCHES: the whole argument vector is parsed before variables are set
    # up, so the flag error is reported instead of running the query.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `--no-such-flag'\n"


def test_flag_errors_go_to_stderr_not_stdout():
    """Nothing is written to stdout when flag parsing fails."""
    res = run_gojq(["--argjson", "k", "1", "--bogus"])
    # CATCHES: the error path writes only to stderr; stdout stays closed for
    # business (empty) even though earlier flags parsed fine.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"gojq: unknown flag `--bogus'\n"
