"""The jq module system: ``-L`` search paths, import/include, data modules.

``cli/cli.go`` passes the ``-L`` paths (or the defaults ``~/.jq``,
``$ORIGIN/../lib/gojq`` and ``$ORIGIN/../lib``) to ``gojq.NewModuleLoader``
from ``module_loader.go``.  These tests pin module lookup (flat and
``name/name.jq`` layouts), the ``search:`` metadata override, JSON data
modules, the ``~/.jq`` initialisation module, and the error messages for
missing or broken modules.
"""

from __future__ import annotations

import pytest

from conftest import run_gojq, write_file

# All expectations below were recorded by running ./executable.


@pytest.fixture
def libs(tmp_path):
    """A library directory with one module defining `twice`."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "math.jq", "def twice: . * 2;\n")
    return "libs"


def test_import_as_binds_namespaced_functions(tmp_path, libs):
    """``import "m" as x`` exposes its defs as ``x::name``."""
    res = run_gojq(["-n", "-L", libs, 'import "math" as m; 21 | m::twice'], cwd=tmp_path)
    # CATCHES: the module's functions are reachable only through the alias
    # namespace `m::`, and the import must come from -L, not the defaults.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


def test_include_binds_functions_unnamespaced(tmp_path, libs):
    """``include "m"`` brings its defs into the current scope directly."""
    res = run_gojq(["-n", "-L", libs, 'include "math"; 21 | twice'], cwd=tmp_path)
    # CATCHES: include has no alias, so `twice` resolves without a namespace.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


def test_unnamespaced_access_after_import_is_not_defined(tmp_path, libs):
    """After ``import ... as m`` the bare name is still unknown."""
    res = run_gojq(["-n", "-L", libs, 'import "math" as m; 21 | twice'], cwd=tmp_path)
    # CATCHES: `import` does not leak the module's names into scope; only
    # `include` does — the compile error names the missing function.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"gojq: compile error: function not defined: twice/0\n"


def test_repeated_library_paths_are_all_searched(tmp_path, libs):
    """``-L a -L b`` searches both directories, in order."""
    empty = tmp_path / "empty"
    empty.mkdir()
    res = run_gojq(
        ["-n", "-L", "empty", "-L", libs, 'import "math" as m; 5 | m::twice'],
        cwd=tmp_path,
    )
    # CATCHES: the -L flag is repeatable and every path contributes to the
    # search list.
    assert res.returncode == 0
    assert res.stdout == b"10\n"


def test_explicit_library_path_replaces_the_defaults(tmp_path):
    """With any ``-L`` given, ``~/.jq`` is no longer searched."""
    home = tmp_path / "home"
    (home / ".jq").mkdir(parents=True)
    write_file(home / ".jq", "math.jq", "def twice: . * 2;\n")
    missing = tmp_path / "no-such-dir"
    res = run_gojq(
        ["-n", "-L", str(missing), 'import "math" as m; 1'],
        env={"HOME": str(home)},
    )
    # CATCHES: the default paths are used only when -L is absent entirely, so
    # a (nonexistent) -L directory shadows ~/.jq and the module is not found.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b'gojq: compile error: module not found: "math"\n'


def test_home_jq_directory_is_a_default_search_path(tmp_path):
    """Without ``-L``, modules resolve from the ``~/.jq`` directory."""
    home = tmp_path / "home"
    (home / ".jq").mkdir(parents=True)
    write_file(home / ".jq", "math.jq", "def twice: . * 2;\n")
    res = run_gojq(
        ["-n", 'import "math" as m; 21 | m::twice'], env={"HOME": str(home)}
    )
    # CATCHES: ~/.jq is one of the three default search paths, so a module
    # there is found with no -L at all.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


def test_home_jq_file_is_loaded_as_initialization_module(tmp_path):
    """A ``~/.jq`` *file* is parsed and its defs become globally available."""
    home = tmp_path / "home"
    home.mkdir()
    write_file(home, ".jq", 'def greeting: "hello from init";\n')
    res = run_gojq(["-n", "greeting"], env={"HOME": str(home)})
    # CATCHES: the loader loads ~/.jq as an init module whose definitions are
    # in scope for the main query without any import.
    assert res.returncode == 0
    assert res.stdout == b'"hello from init"\n'


def test_home_jq_init_module_parse_error(tmp_path):
    """A broken ``~/.jq`` is reported with its path and line."""
    home = tmp_path / "home"
    home.mkdir()
    write_file(home, ".jq", "def (: bad\n")
    res = run_gojq(["-n", "1"], env={"HOME": str(home)})
    # CATCHES: the init module is parsed at compile time; its parse error
    # carries the full ~/.jq path (exit 3), not a generic message.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == (
        "gojq: invalid query: %s/.jq:1\n    1 | def (: bad\n            ^  unexpected token \"(\"\n"
        % home
    ).encode()


def test_home_jq_init_module_cannot_import_from_itself(tmp_path):
    """An import inside ``~/.jq`` still looks in ~/.jq — which is a file."""
    home = tmp_path / "home"
    home.mkdir()
    write_file(home, ".jq", 'include "math";\n')
    res = run_gojq(["-n", "1"], env={"HOME": str(home)})
    # CATCHES: ~/.jq is opened as a file, so ~/.jq/math.jq cannot exist and
    # the include fails with module not found (search paths still apply).
    assert res.returncode == 3
    assert res.stderr == b'gojq: compile error: module not found: "math"\n'


def test_library_path_tilde_form(tmp_path):
    """``-L '~/dir'`` expands ``~`` against $HOME."""
    home = tmp_path / "home"
    (home / "mylibs").mkdir(parents=True)
    write_file(home / "mylibs", "math.jq", "def thrice: . * 3;\n")
    res = run_gojq(
        ["-n", "-L", "~/mylibs", 'import "math" as m; 14 | m::thrice'],
        env={"HOME": str(home)},
    )
    # CATCHES: a leading `~/` in a library path is expanded to the home
    # directory, not treated as a literal directory name.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


def test_library_path_relative_to_cwd(tmp_path, libs):
    """A relative ``-L`` path resolves against the current directory."""
    res = run_gojq(["-n", "-L", ".", 'import "libs/math" as m; 5 | m::twice'],
                   cwd=tmp_path)
    # CATCHES: relative library paths (including `.`) are joined onto the
    # working directory, and nested relative module names work.
    assert res.returncode == 0
    assert res.stdout == b"10\n"


def test_nested_module_directory_layout(tmp_path):
    """A module may live at ``<path>/<name>/<name>.jq``."""
    d = tmp_path / "libs"
    (d / "mymod").mkdir(parents=True)
    write_file(d / "mymod", "mymod.jq", "def inc: . + 1;\n")
    res = run_gojq(["-n", "-L", "libs", 'import "mymod" as m; 41 | m::inc'],
                   cwd=tmp_path)
    # CATCHES: lookupModule tries both `name.jq` and `name/name.jq` in each
    # search directory.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


def test_module_not_found_message(tmp_path):
    """A missing module is a compile error with a quoted module name."""
    res = run_gojq(["-n", "-L", ".", 'import "absent" as m; 1'], cwd=tmp_path)
    # CATCHES: the message quotes the module name (`module not found:
    # "absent"`) and is a compile error, exit 3.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b'gojq: compile error: module not found: "absent"\n'


def test_broken_module_reports_the_module_file(tmp_path):
    """A module that fails to parse is reported with its own file name."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "broken.jq", "def (\n")
    res = run_gojq(["-n", "-L", "libs", 'import "broken" as m; 1'], cwd=tmp_path)
    # CATCHES: the parse error names the *module file* (libs/broken.jq:1) and
    # shows the module's own source line, not the importing query.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid query: libs/broken.jq:1\n"
        b"    1 | def (\n"
        b'            ^  unexpected token "("\n'
    )


def test_search_metadata_overrides_the_search_path(tmp_path, libs):
    """``import "m" as x {search: "dir"}`` looks in dir first."""
    other = tmp_path / "other"
    other.mkdir()
    write_file(other, "math.jq", "def twice: . * 100;\n")
    res = run_gojq(
        ["-n", '-L', libs, 'import "math" as m {search: "other"}; 1 | m::twice'],
        cwd=tmp_path,
    )
    # CATCHES: the metadata `search` directory takes precedence over the -L
    # paths, so the `other` copy of the module wins.
    assert res.returncode == 0
    assert res.stdout == b"100\n"


def test_search_metadata_works_with_include(tmp_path, libs):
    """``include "m" {search: "dir"}`` behaves the same as import."""
    other = tmp_path / "other"
    other.mkdir()
    write_file(other, "math.jq", "def twice: . * 5;\n")
    res = run_gojq(
        ["-n", "-L", libs, 'include "math" {search: "other"}; 8 | twice'],
        cwd=tmp_path,
    )
    # CATCHES: the search override applies to include directives too.
    assert res.returncode == 0
    assert res.stdout == b"40\n"


def test_search_metadata_without_a_match_falls_back_to_dash_l(tmp_path, libs):
    """The metadata directory is searched *first*, then the -L paths."""
    other = tmp_path / "other"
    other.mkdir()
    write_file(libs and tmp_path / libs, "only.jq", "def one: 1;\n")
    res = run_gojq(
        ["-n", "-L", libs, 'import "only" as m {search: "other"}; m::one'],
        cwd=tmp_path,
    )
    # CATCHES: `only` exists only under -L, so after the search dir misses,
    # the regular library path is still consulted.
    assert res.returncode == 0
    assert res.stdout == b"1\n"


def test_module_relative_search_path(tmp_path):
    """A module's own ``{search: "."}`` resolves against the module's dir."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "inner.jq", "def plus2: . + 2;\n")
    write_file(d, "outer.jq", 'import "inner" as i {search: "."};\ndef both: i::plus2 | i::plus2;\n')
    res = run_gojq(
        ["-n", "-L", "libs", 'import "outer" as o; 5 | o::both'], cwd=tmp_path
    )
    # CATCHES: parseModule rewrites a relative search path to the directory of
    # the module file that declared it, so outer.jq finds inner.jq next to it.
    assert res.returncode == 0
    assert res.stdout == b"9\n"


def test_json_data_module_is_an_array_of_values(tmp_path):
    """``import "d" as $d`` binds the file's JSON values as one array."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "data.json", '{"answer": 42}')
    res = run_gojq(["-nc", "-L", "libs", 'import "data" as $d; $d'], cwd=tmp_path)
    # CATCHES: JSON data modules need the `$` alias and bind an *array* of the
    # file's values (here a single object).
    assert res.returncode == 0
    assert res.stdout == b'[{"answer":42}]\n'


def test_json_data_module_multiple_values(tmp_path):
    """A data module with several top-level values keeps them in order."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "multi.json", "1 2 3")
    res = run_gojq(["-nc", "-L", "libs", 'import "multi" as $d; $d'], cwd=tmp_path)
    # CATCHES: every JSON value in the file becomes one array element.
    assert res.returncode == 0
    assert res.stdout == b"[1,2,3]\n"


def test_json_data_module_dollar_dollar_alias(tmp_path):
    """``$d::d`` is bound to the same array as ``$d``."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "data.json", "7")
    res = run_gojq(
        ["-nc", "-L", "libs", 'import "data" as $d; $d::d'], cwd=tmp_path
    )
    # CATCHES: the loader also defines the `name::name` alias for data
    # modules, mirroring jq's behaviour.
    assert res.returncode == 0
    assert res.stdout == b"[7]\n"


def test_json_data_module_invalid_json(tmp_path):
    """Unparsable JSON data module content is a compile error naming it."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "bad.json", "nope")
    res = run_gojq(["-n", "-L", "libs", 'import "bad" as $d; 1'], cwd=tmp_path)
    # CATCHES: the JSON parse failure carries the data file's path and
    # contents, exit 3 (compile error), not 5.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: compile error: invalid json: libs/bad.json\n"
        b"    nope\n"
        b"     ^  invalid character 'o' in literal null (expecting 'u')\n"
    )


def test_json_module_without_dollar_alias_is_not_found(tmp_path):
    """``import "d" as d`` (no ``$``) looks for a .jq module only."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "data.json", "1")
    res = run_gojq(["-n", "-L", "libs", 'import "data" as d; 1'], cwd=tmp_path)
    # CATCHES: the alias spelling decides the extension searched: without `$`
    # only data.jq is looked for, so the .json file is not found.
    assert res.returncode == 3
    assert res.stderr == b'gojq: compile error: module not found: "data"\n'


def test_jq_module_with_dollar_alias_is_not_found(tmp_path):
    """``import "m" as $m`` (with ``$``) looks for a .json module only."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "m.jq", "def f: 1;\n")
    res = run_gojq(["-n", "-L", "libs", 'import "m" as $m; 1'], cwd=tmp_path)
    # CATCHES: the `$` alias searches .json files, so the .jq module is not
    # found even though it exists.
    assert res.returncode == 3
    assert res.stderr == b'gojq: compile error: module not found: "m"\n'


def test_modulemeta_lists_definitions(tmp_path):
    """``modulemeta`` reports a module's defs and deps."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "meta.jq", "def answer: 42;\ndef double(x): x * 2;\n")
    res = run_gojq(["-nc", "-L", "libs", '"meta" | modulemeta'], cwd=tmp_path)
    # CATCHES: modulemeta lists function/arity defs and no deps, in this
    # exact JSON shape.
    assert res.returncode == 0
    assert res.stdout == b'{"defs":["answer/0","double/1"],"deps":[]}\n'


def test_modulemeta_reports_module_directive_metadata(tmp_path):
    """A ``module {...}`` directive's keys appear in modulemeta output."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "hm.jq", 'module {home: "https://example.com"};\ndef hi: 1;\n')
    res = run_gojq(["-nc", "-L", "libs", '"hm" | modulemeta'], cwd=tmp_path)
    # CATCHES: the directive's metadata object is merged into modulemeta's
    # output alongside defs and deps.
    assert res.returncode == 0
    assert res.stdout == b'{"defs":["hi/0"],"deps":[],"home":"https://example.com"}\n'


def test_modulemeta_resolves_dep_search_paths(tmp_path):
    """A module's imports are listed with their resolved search directory."""
    d = tmp_path / "libs"
    d.mkdir()
    write_file(d, "inner.jq", "def plus2: . + 2;\n")
    write_file(d, "outer.jq", 'import "inner" as i {search: "."};\ndef wrap: 1;\n')
    res = run_gojq(["-nc", "-L", "libs", '"outer" | modulemeta'], cwd=tmp_path)
    # CATCHES: modulemeta rewrites the dep's `search` to the resolved
    # directory of the module that imports it (here "libs").
    assert res.returncode == 0
    assert res.stdout == (
        b'{"defs":["wrap/0"],"deps":[{"as":"i","is_data":false,'
        b'"relpath":"inner","search":"libs"}]}\n'
    )


def test_modulemeta_missing_module_is_a_runtime_error(tmp_path):
    """``modulemeta`` of an unknown module fails with exit 5, not 3."""
    res = run_gojq(["-nc", "-L", ".", '"absent" | modulemeta'], cwd=tmp_path)
    # CATCHES: modulemeta loads the module at *runtime*, so the not-found
    # error is a plain error (exit 5) rather than a compile error (exit 3).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b'gojq: module not found: "absent"\n'


def test_data_module_not_found_message_mentions_name(tmp_path):
    """A missing data module reports the module name like a .jq module."""
    res = run_gojq(["-n", "-L", ".", 'import "absent" as $d; 1'], cwd=tmp_path)
    # CATCHES: the same `module not found: "absent"` message covers data
    # modules, still a compile error.
    assert res.returncode == 3
    assert res.stderr == b'gojq: compile error: module not found: "absent"\n'
