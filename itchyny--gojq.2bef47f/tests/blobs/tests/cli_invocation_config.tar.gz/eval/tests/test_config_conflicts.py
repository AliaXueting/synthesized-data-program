"""Flag conflicts and environment-variable configuration read in ``cli/cli.go``.

Before any input is read, ``runInternal`` validates combinations of output
flags (``--tab`` with ``--yaml-output``, the ``--indent`` range) and decides
colouring from ``-C``/``-M`` and the ``NO_COLOR``/``TERM``/``GOJQ_COLORS``
environment variables.  These tests pin those precedence rules.
"""

from __future__ import annotations

import pytest

from conftest import run_gojq

# All expectations below were recorded by running ./executable.

# The coloured form of {"a":1} with the default palette.
COLORED = b'{\033[34;1m"a"\033[0m: \033[36m1\033[0m}\n'


@pytest.mark.parametrize("order", [["--yaml-output", "--tab"], ["--tab", "--yaml-output"]])
def test_tab_conflicts_with_yaml_output(order):
    """``--tab`` and ``--yaml-output`` together are rejected before running."""
    res = run_gojq(order + ["."], stdin='{"a":1}')
    # CATCHES: the conflict is detected in argument order independence with
    # the exact message and exit code 5 (a usage error, not a parse error).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: cannot use tabs for YAML output\n"


@pytest.mark.parametrize("count", [10, 11, 100])
def test_indent_above_nine_is_rejected(count):
    """``--indent`` values over 9 fail the range check with exit 5."""
    res = run_gojq(["--indent", str(count), "."], stdin='{"a":1}')
    # CATCHES: the upper bound is 9; the message echoes the given count.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: too many indentation count: %d\n" % count


def test_indent_nine_is_accepted():
    """``--indent 9`` is the largest accepted value."""
    res = run_gojq(["--indent", "9", "."], stdin='{"a":[1]}')
    # CATCHES: the boundary value 9 is legal and produces 9-space indents.
    assert res.returncode == 0
    assert res.stdout == (
        b'{\n         "a": [\n                  1\n         ]\n}\n'
    )


def test_indent_zero_is_accepted():
    """``--indent 0`` disables indentation rather than erroring."""
    res = run_gojq(["--indent", "0", "."], stdin='{"a":1}')
    # CATCHES: zero is in range and prints each key on its own unindented line.
    assert res.returncode == 0
    assert res.stdout == b'{\n"a": 1\n}\n'


def test_color_flag_forces_color_when_piped():
    """``-C`` colourises even though stdout is a pipe."""
    res = run_gojq(["-C", "."], stdin='{"a":1}')
    # CATCHES: without -C a piped stdout is monochrome; -C forces the ANSI
    # palette (recorded bytes, including the object-key colour 34;1).
    assert res.returncode == 0
    assert res.stdout == COLORED


def test_no_color_env_loses_to_color_flag():
    """``NO_COLOR`` is ignored when ``-C`` is given."""
    res = run_gojq(["-C", "."], stdin='{"a":1}', extra={"NO_COLOR": "1"})
    # CATCHES: the explicit -C flag takes precedence over the NO_COLOR
    # environment variable.
    assert res.returncode == 0
    assert res.stdout == COLORED


def test_term_dumb_env_loses_to_color_flag():
    """``TERM=dumb`` is likewise ignored when ``-C`` is given."""
    res = run_gojq(["-C", "."], stdin='{"a":1}', extra={"TERM": "dumb"})
    # CATCHES: the TERM=dumb monochrome rule is only a fallback, not an
    # override of -C.
    assert res.returncode == 0
    assert res.stdout == COLORED


def test_empty_no_color_is_not_set():
    """``NO_COLOR=`` (empty string) does not count as set."""
    res = run_gojq(["-C", "."], stdin='{"a":1}', extra={"NO_COLOR": ""})
    # CATCHES: only a non-empty NO_COLOR disables colour; the empty value is
    # treated as absent.
    assert res.returncode == 0
    assert res.stdout == COLORED


@pytest.mark.parametrize("cluster", ["-CM", "-MC", "-cCM", "-cMC"])
def test_monochrome_flag_beats_color_flag(cluster):
    """``-M`` wins over ``-C`` in any order or cluster."""
    res = run_gojq([cluster, "."], stdin='{"a":1}')
    # CATCHES: when both are given, monochrome wins regardless of order; the
    # output has no escape sequences.
    assert res.returncode == 0
    assert res.stdout == b'{"a":1}\n'


def test_piped_output_is_monochrome_by_default():
    """Without ``-C`` a piped stdout never gets colour codes."""
    res = run_gojq(["."], stdin='{"a":1}')
    # CATCHES: the isatty check makes piped output monochrome by default.
    assert res.returncode == 0
    assert res.stdout == b'{\n  "a": 1\n}\n'


def test_invalid_gojq_colors_with_color_flag():
    """An unparsable ``GOJQ_COLORS`` is an error only when colour is on."""
    res = run_gojq(["-C", "."], stdin='{"a":1}', extra={"GOJQ_COLORS": "zz"})
    # CATCHES: with -C the palette string is validated and `zz` is rejected
    # with exit 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b'gojq: invalid color: "zz"\n'


def test_invalid_gojq_colors_ignored_without_color():
    """The same bad ``GOJQ_COLORS`` is harmless without ``-C``."""
    res = run_gojq(["-c", "."], stdin='{"a":1}', extra={"GOJQ_COLORS": "zz"})
    # CATCHES: the palette is only parsed when colour output is enabled, so a
    # piped run ignores the variable entirely.
    assert res.returncode == 0
    assert res.stdout == b'{"a":1}\n'
