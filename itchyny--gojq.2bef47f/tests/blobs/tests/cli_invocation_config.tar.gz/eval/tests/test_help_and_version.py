"""The ``-h``/``--help`` and ``-v``/``--version`` outputs.

The help text is generated reflectively from the ``flagopts`` struct in
``cli/cli.go`` by ``formatFlags`` in ``cli/flags.go``: a header block, then a
``Command Options:`` table whose columns are padded to a fixed width, and a
trailing ``Help Option:`` section.  Both help and version go to stdout with
exit code 0, and help takes precedence over version.
"""

from __future__ import annotations

import pytest

from conftest import run_gojq

# Exact bytes recorded from the reference for `--help`.
HELP_TEXT = (
    "gojq - Go implementation of jq\n"
    "\n"
    "Version: 0.12.19 (rev: 2bef47f/go1.25.13)\n"
    "\n"
    "Synopsis:\n"
    "  % echo '{\"foo\": 128}' | gojq '.foo'\n"
    "\n"
    "Usage:\n"
    "  gojq [OPTIONS]\n"
    "\n"
    "Command Options:\n"
    "  -r, --raw-output          output raw strings\n"
    "      --raw-output0         implies -r with NUL character delimiter\n"
    "  -j, --join-output         implies -r with no newline delimiter\n"
    "  -c, --compact-output      output without pretty-printing\n"
    "      --indent number       number of spaces for indentation\n"
    "      --tab                 use tabs for indentation\n"
    "      --yaml-output         output in YAML format\n"
    "  -C, --color-output        output with colors even if piped\n"
    "  -M, --monochrome-output   output without colors\n"
    "  -n, --null-input          use null as input value\n"
    "  -R, --raw-input           read input as raw strings\n"
    "      --stream              parse input in stream fashion\n"
    "      --yaml-input          read input as YAML format\n"
    "  -s, --slurp               read all inputs into an array\n"
    "  -f, --from-file           load query from file\n"
    "  -L, --library-path dir    directory to search modules from\n"
    "      --arg name value      set a string value to a variable\n"
    "      --argjson name value  set a JSON value to a variable\n"
    "      --slurpfile name file set the JSON contents of a file to a variable\n"
    "      --rawfile name file   set the contents of a file to a variable\n"
    "      --args                consume remaining arguments as positional string values\n"
    "      --jsonargs            consume remaining arguments as positional JSON values\n"
    "  -e, --exit-status         exit 1 when the last value is false or null\n"
    "  -v, --version             display version information\n"
    "\n"
    "Help Option:\n"
    "  -h, --help                display this help information\n"
    "\n"
)

# Exact bytes recorded from the reference for `--version`.
VERSION_TEXT = b"gojq 0.12.19 (rev: 2bef47f/go1.25.13)\n"

# One recorded line per flag row, pinned individually so a single misplaced
# column or description is caught precisely.
FLAG_TABLE_LINES = [
    "  -r, --raw-output          output raw strings",
    "      --raw-output0         implies -r with NUL character delimiter",
    "  -j, --join-output         implies -r with no newline delimiter",
    "  -c, --compact-output      output without pretty-printing",
    "      --indent number       number of spaces for indentation",
    "      --tab                 use tabs for indentation",
    "      --yaml-output         output in YAML format",
    "  -C, --color-output        output with colors even if piped",
    "  -M, --monochrome-output   output without colors",
    "  -n, --null-input          use null as input value",
    "  -R, --raw-input           read input as raw strings",
    "      --stream              parse input in stream fashion",
    "      --yaml-input          read input as YAML format",
    "  -s, --slurp               read all inputs into an array",
    "  -f, --from-file           load query from file",
    "  -L, --library-path dir    directory to search modules from",
    "      --arg name value      set a string value to a variable",
    "      --argjson name value  set a JSON value to a variable",
    "      --slurpfile name file set the JSON contents of a file to a variable",
    "      --rawfile name file   set the contents of a file to a variable",
    "      --args                consume remaining arguments as positional string values",
    "      --jsonargs            consume remaining arguments as positional JSON values",
    "  -e, --exit-status         exit 1 when the last value is false or null",
    "  -v, --version             display version information",
    "  -h, --help                display this help information",
]


def test_help_exact_bytes():
    """``--help`` prints the exact 1696-byte help text and exits 0."""
    res = run_gojq(["--help"])
    # CATCHES: the whole help page (header, synopsis, reflect-generated flag
    # table, help-option section and blank line) byte for byte.
    assert res.returncode == 0
    assert res.stdout == HELP_TEXT.encode()
    assert res.stderr == b""


def test_short_help_matches_long_help():
    """``-h`` is an alias for ``--help`` with identical output."""
    res = run_gojq(["-h"])
    # CATCHES: both spellings produce the same text; a parser that treats -h
    # differently (or omits the alias) breaks this.
    assert res.returncode == 0
    assert res.stdout == HELP_TEXT.encode()
    assert res.stderr == b""


@pytest.mark.parametrize("line", FLAG_TABLE_LINES)
def test_help_flag_table_row(line):
    """Each flag row of the help table matches the recorded line exactly."""
    res = run_gojq(["--help"])
    # CATCHES: the reflect-generated table aligns descriptions at a fixed
    # column and lists every flag in declaration order; one wrong row (a
    # missing flag, a wrong arg hint, off-by-one padding) fails here.
    assert res.returncode == 0
    assert (line + "\n").encode() in res.stdout


def test_version_exact_bytes():
    """``--version`` prints one exact line and exits 0."""
    res = run_gojq(["--version"])
    # CATCHES: the version banner `gojq 0.12.19 (rev: ...)' including the
    # revision and Go runtime version, with exit status 0.
    assert res.returncode == 0
    assert res.stdout == VERSION_TEXT
    assert res.stderr == b""


def test_short_version_matches_long_version():
    """``-v`` is an alias for ``--version``."""
    res = run_gojq(["-v"])
    # CATCHES: -v prints the same single line as --version.
    assert res.returncode == 0
    assert res.stdout == VERSION_TEXT
    assert res.stderr == b""


@pytest.mark.parametrize("order", [["--help", "--version"], ["--version", "--help"]])
def test_help_wins_over_version_in_any_order(order):
    """When both are given, help output is printed whatever the order."""
    res = run_gojq(order)
    # CATCHES: the help check runs before the version check, so the full help
    # page wins regardless of argument order (and version is never printed).
    assert res.returncode == 0
    assert res.stdout == HELP_TEXT.encode()
    assert res.stderr == b""


def test_help_wins_over_version_in_one_cluster():
    """``-hv`` in one cluster still shows help, not the version."""
    res = run_gojq(["-hv"])
    # CATCHES: both clustered shorts are set, but the help branch is checked
    # first, so the version flag is ignored.
    assert res.returncode == 0
    assert res.stdout == HELP_TEXT.encode()


def test_help_is_printed_even_for_an_invalid_query():
    """Help short-circuits before the query is parsed."""
    res = run_gojq(["--help", "(("])
    # CATCHES: an unparsable query argument does not prevent the help output
    # or turn the exit status nonzero.
    assert res.returncode == 0
    assert res.stdout == HELP_TEXT.encode()
    assert res.stderr == b""


def test_help_wins_over_missing_query_file():
    """Help beats a later ``-f`` with no file argument."""
    res = run_gojq(["--help", "-f"])
    # CATCHES: `expected a query file' would be an error without --help; the
    # help branch returns before the query source is even examined.
    assert res.returncode == 0
    assert res.stdout == HELP_TEXT.encode()
    assert res.stderr == b""


def test_invalid_indent_value_beats_help():
    """A non-integer ``--indent`` is a parse error and so beats ``--help``."""
    res = run_gojq(["--help", "--indent", "abc"])
    # CATCHES: the Atoi failure happens while parsing the argument vector,
    # before the help branch runs, so help is not printed (exit 2).
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid argument for flag `--indent': "
        b'strconv.Atoi: parsing "abc": invalid syntax\n'
    )


def test_help_with_unrelated_flags_and_arguments():
    """Other flags and a query argument do not change the help output."""
    res = run_gojq(["-nc", "--arg", "k", "v", "--help", ".a"])
    # CATCHES: help is emitted verbatim even when input/output flags and a
    # predefined variable are also present.
    assert res.returncode == 0
    assert res.stdout == HELP_TEXT.encode()
    assert res.stderr == b""


def test_help_and_version_go_to_stdout():
    """Neither help nor version writes anything to stderr."""
    help_res = run_gojq(["--help"])
    version_res = run_gojq(["--version"])
    # CATCHES: both banners are stdout-only; a re-implementation printing the
    # usage text to stderr (like Go's flag package) fails here.
    assert help_res.stderr == b""
    assert version_res.stderr == b""
    assert help_res.returncode == 0
    assert version_res.returncode == 0
    assert version_res.stdout == VERSION_TEXT
