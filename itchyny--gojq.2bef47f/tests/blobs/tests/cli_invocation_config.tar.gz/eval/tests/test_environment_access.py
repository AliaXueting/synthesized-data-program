"""Environment access through the ``env`` builtin and the ``$ENV`` variable.

``cli/cli.go`` wires ``gojq.WithEnvironLoader(os.Environ)`` into the compiler,
which is what makes both the ``env`` builtin and the predefined ``$ENV``
object reflect the process environment.  These tests pin that wiring with a
pinned child environment: values, key sets, nested lookup and the empty case.
"""

from __future__ import annotations

import pytest

from conftest import run_gojq

# All expectations below were recorded by running ./executable.

# A minimal, fully pinned environment used by most tests below.
PINNED = {"HOME": "/home/gojq-tester", "GOJQ_TEST_VAR": "a value"}


def test_env_builtin_exposes_process_environment():
    """``env.NAME`` returns the child process's environment value."""
    res = run_gojq(["-nc", "env.GOJQ_TEST_VAR"], env=PINNED)
    # CATCHES: the environ loader is wired in cli.go; without it `env` would
    # be an error or an empty object instead of the string "a value".
    assert res.returncode == 0
    assert res.stdout == b'"a value"\n'


def test_dollar_env_exposes_process_environment():
    """``$ENV.NAME`` returns the same environment value."""
    res = run_gojq(["-nc", "$ENV.GOJQ_TEST_VAR"], env=PINNED)
    # CATCHES: $ENV is bound separately from the env builtin but from the same
    # loader, so both must carry the value.
    assert res.returncode == 0
    assert res.stdout == b'"a value"\n'


def test_dollar_env_supports_nested_lookup():
    """``$ENV.HOME`` reads through the object with dotted access."""
    res = run_gojq(["-nc", "$ENV.HOME"], env=PINNED)
    # CATCHES: $ENV is a real object value, so nested field access works and
    # yields the pinned HOME.
    assert res.returncode == 0
    assert res.stdout == b'"/home/gojq-tester"\n'


def test_env_builtin_is_an_object_of_every_variable():
    """``env`` holds every exported variable, keys sorted on output."""
    res = run_gojq(["-nc", "env | keys"], env={"AAA": "1", "ZZZ": "2", "MMM": "3"})
    # CATCHES: the object contains all three variables (and only those, since
    # the child env is pinned), with object keys sorted in the output.
    assert res.returncode == 0
    assert res.stdout == b'["AAA","MMM","ZZZ"]\n'


def test_env_and_dollar_env_are_equal():
    """The builtin and the variable expose the same mapping."""
    res = run_gojq(["-nc", "env == $ENV"], env=PINNED)
    # CATCHES: both are built from the same environ snapshot, so they compare
    # equal — a re-implementation wiring only one of them breaks this.
    assert res.returncode == 0
    assert res.stdout == b"true\n"


def test_empty_environment_gives_empty_objects():
    """With no environment variables at all, ``env`` and ``$ENV`` are {}."""
    res = run_gojq(["-nc", "[env, $ENV]"], env={})
    # CATCHES: the environ loader is the only source — a truly empty (pinned)
    # environment yields two empty objects, not an error.
    assert res.returncode == 0
    assert res.stdout == b"[{},{}]\n"


def test_missing_variable_is_null():
    """Looking up an undefined name gives null, not an error."""
    res = run_gojq(["-nc", "env.NO_SUCH_VAR_GOJQ"], env=PINNED)
    # CATCHES: environment lookup misses return null like any object field.
    assert res.returncode == 0
    assert res.stdout == b"null\n"


def test_environment_with_empty_value_is_present():
    """A variable set to the empty string is present with value ""."""
    res = run_gojq(["-nc", '[env.GOJQ_TEST_VAR, (env | has("GOJQ_TEST_VAR"))]'],
                   env={"GOJQ_TEST_VAR": ""})
    # CATCHES: os.Environ carries empty-valued variables, so the key exists
    # and its value is "" rather than the key being dropped or null.
    assert res.returncode == 0
    assert res.stdout == b'["",true]\n'


def test_environment_values_are_verbatim_strings():
    """Values containing spaces, `=` and semicolons survive intact."""
    res = run_gojq(["-nc", "env.X"], env={"X": "a b=c;d"})
    # CATCHES: the value is split only on the first `=` (by the environ
    # loader), so later `=` and other punctuation stay in the value.
    assert res.returncode == 0
    assert res.stdout == b'"a b=c;d"\n'


def test_env_object_type_and_lookup():
    """``$ENV`` is an object; missing keys yield null via .[...] too."""
    res = run_gojq(["-nc", "[$ENV | type, .[\"NOPE\"]]", ], env=PINNED)
    # CATCHES: $ENV behaves as a plain object for type checks and bracket
    # access (null on miss).
    assert res.returncode == 0
    assert res.stdout == b'["object",null]\n'
