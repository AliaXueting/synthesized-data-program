"""Predefined variables: ``--arg``, ``--argjson``, ``--slurpfile``,
``--rawfile``, ``--args``, ``--jsonargs`` and the ``$ARGS`` object.

The four map-valued flags feed ``$name`` variables (and ``$ARGS.named``);
``--args``/``--jsonargs`` switch the remaining positionals into
``$ARGS.positional`` as strings or parsed JSON.  The map parser remembers
every name it has bound, so the *first* flag to define a name wins even
across different flags.
"""

from __future__ import annotations

import pytest

from conftest import run_gojq, write_file

# All expectations below were recorded by running ./executable.


def test_arg_defines_a_string_variable():
    """``--arg name value`` binds a JSON string."""
    res = run_gojq(["-nc", "--arg", "foo", "bar", "$foo"])
    # CATCHES: the value is a string, so it is echoed with quotes.
    assert res.returncode == 0
    assert res.stdout == b'"bar"\n'


def test_argjson_defines_a_parsed_json_variable():
    """``--argjson name value`` parses the value as JSON."""
    res = run_gojq(["-nc", "--argjson", "foo", '{"a": 1}', "$foo"])
    # CATCHES: unlike --arg the value is compiled as JSON, so the object
    # structure survives.
    assert res.returncode == 0
    assert res.stdout == b'{"a":1}\n'


@pytest.mark.parametrize(
    "value,expected",
    [
        ("-7", b"-7"),
        ("true", b"true"),
        ("null", b"null"),
        ("[1, 2]", b"[1,2]"),
        ('"text"', b'"text"'),
    ],
)
def test_argjson_scalar_and_composite_values(value, expected):
    """``--argjson`` accepts every JSON type for the value."""
    res = run_gojq(["-nc", "--argjson", "k", value, "$k"])
    # CATCHES: numbers, booleans, null, arrays and strings are all parsed by
    # the JSON input iterator, not treated as text.
    assert res.returncode == 0
    assert res.stdout == expected + b"\n"


def test_argjson_takes_only_the_first_value():
    """``--argjson k '1 2'`` binds 1 and drops the rest."""
    res = run_gojq(["-nc", "--argjson", "k", "1 2", "$k"])
    # CATCHES: only the first JSON value in the argument is consumed.
    assert res.returncode == 0
    assert res.stdout == b"1\n"


def test_argjson_ignores_trailing_garbage():
    """``--argjson k '1 x'`` still binds 1 without complaint."""
    res = run_gojq(["-nc", "--argjson", "k", "1 x", "$k"])
    # CATCHES: the trailing `x` is never read, so no invalid-json error is
    # reported for it.
    assert res.returncode == 0
    assert res.stdout == b"1\n"


def test_argjson_empty_value_is_null():
    """``--argjson k ''`` binds null rather than failing."""
    res = run_gojq(["-nc", "--argjson", "k", "", "$k"])
    # CATCHES: an empty string reaches EOF before any value, which the input
    # iterator reports as null (not as an error).
    assert res.returncode == 0
    assert res.stdout == b"null\n"


def test_argjson_invalid_json_error():
    """Invalid JSON in ``--argjson`` is reported naming the variable."""
    res = run_gojq(["-nc", "--argjson", "foo", "{bad", "$foo"])
    # CATCHES: the error is `invalid json: $foo` (the variable name, not the
    # flag name), shows the offending text with a caret, and exits 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: $foo\n"
        b"    {bad\n"
        b"     ^  invalid character 'b' looking for beginning of object key string\n"
    )


@pytest.mark.parametrize("value", ["nope", "[1,", "{'a':1}"])
def test_argjson_invalid_json_values(value):
    """Other invalid JSON values fail with the same shape and exit 5."""
    res = run_gojq(["-nc", "--argjson", "k", value, "$k"])
    # CATCHES: every unparsable --argjson value is a runtime error (exit 5,
    # `invalid json: $k`), never a flag-parse or compile error.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.startswith(b"gojq: invalid json: $k\n    ")
    assert res.stderr.endswith(b"\n")


def test_slurpfile_binds_an_array_of_file_values(tmp_path):
    """``--slurpfile name file`` is an array of every JSON value in the file."""
    write_file(tmp_path, "vals.json", '{"a": 1}\n2\n')
    res = run_gojq(["-nc", "--slurpfile", "k", "vals.json", "$k"], cwd=tmp_path)
    # CATCHES: $k is the *array* of the file's values, not the values
    # themselves and not a single merged object.
    assert res.returncode == 0
    assert res.stdout == b'[{"a":1},2]\n'


def test_slurpfile_single_value_is_still_an_array(tmp_path):
    """Even one JSON value in the file yields a one-element array."""
    write_file(tmp_path, "one.json", "[1, 2]")
    res = run_gojq(["-nc", "--slurpfile", "k", "one.json", "$k"], cwd=tmp_path)
    # CATCHES: the array-of-values wrapper is applied regardless of how many
    # values (or what type) the file holds.
    assert res.returncode == 0
    assert res.stdout == b"[[1,2]]\n"


def test_slurpfile_empty_file_is_empty_array(tmp_path):
    """An empty file gives the empty array, not null."""
    write_file(tmp_path, "empty.json", "")
    res = run_gojq(["-nc", "--slurpfile", "k", "empty.json", "$k"], cwd=tmp_path)
    # CATCHES: zero values in the file produce [] rather than null.
    assert res.returncode == 0
    assert res.stdout == b"[]\n"


def test_slurpfile_missing_file(tmp_path):
    """``--slurpfile`` with a missing file reports the open error."""
    res = run_gojq(["-nc", "--slurpfile", "k", "absent.json", "$k"], cwd=tmp_path)
    # CATCHES: the raw `open <file>: no such file or directory` error is
    # printed (exit 5) before the query runs.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: open absent.json: no such file or directory\n"


def test_slurpfile_invalid_json_names_the_file(tmp_path):
    """Unparsable file content is reported against the file path."""
    write_file(tmp_path, "bad.json", "oops")
    res = run_gojq(["-nc", "--slurpfile", "k", "bad.json", "$k"], cwd=tmp_path)
    # CATCHES: the `invalid json:` header names the *file* (bad.json), unlike
    # --argjson which names the variable.
    assert res.returncode == 5
    assert res.stderr == (
        b"gojq: invalid json: bad.json\n"
        b"    oops\n"
        b"    ^  invalid character 'o' looking for beginning of value\n"
    )


def test_rawfile_binds_the_file_contents(tmp_path):
    """``--rawfile name file`` is the raw text, uninterpreted."""
    write_file(tmp_path, "note.txt", "line1\n")
    res = run_gojq(["-nc", "--rawfile", "k", "note.txt", "$k"], cwd=tmp_path)
    # CATCHES: the file is read verbatim (newlines included) into a string,
    # not parsed as JSON.
    assert res.returncode == 0
    assert res.stdout == b'"line1\\n"\n'


def test_rawfile_missing_file(tmp_path):
    """``--rawfile`` with a missing file reports the open error."""
    res = run_gojq(["-nc", "--rawfile", "k", "absent.txt", "$k"], cwd=tmp_path)
    # CATCHES: same os.ReadFile failure path as --slurpfile, exit 5.
    assert res.returncode == 5
    assert res.stderr == b"gojq: open absent.txt: no such file or directory\n"


def test_repeated_arg_first_occurrence_wins():
    """Defining the same name twice with ``--arg`` keeps the first value."""
    res = run_gojq(["-nc", "--arg", "k", "first", "--arg", "k", "second", "$k"])
    # CATCHES: the second definition of a name is silently ignored, so $k is
    # "first" (not an error and not "second").
    assert res.returncode == 0
    assert res.stdout == b'"first"\n'


def test_repeated_slurpfile_first_occurrence_wins(tmp_path):
    """The same first-wins rule applies within ``--slurpfile``."""
    write_file(tmp_path, "one.json", "1")
    write_file(tmp_path, "two.json", "2")
    res = run_gojq(
        ["-nc", "--slurpfile", "k", "one.json", "--slurpfile", "k", "two.json", "$k"],
        cwd=tmp_path,
    )
    # CATCHES: only the first file is read for a repeated name.
    assert res.returncode == 0
    assert res.stdout == b"[1]\n"


@pytest.mark.parametrize(
    "first,second,expected",
    [
        (["--arg", "k", "A"], ["--argjson", "k", "1"], b'"A"'),
        (["--argjson", "k", "1"], ["--arg", "k", "A"], b"1"),
        (["--arg", "k", "A"], ["--rawfile", "k", "f.txt"], b'"A"'),
        (["--rawfile", "k", "f.txt"], ["--argjson", "k", "1"], b'"f\\n"'),
    ],
)
def test_first_flag_to_define_a_name_wins_across_flags(tmp_path, first, second, expected):
    """A name claimed by one map flag is ignored by a later, different one."""
    write_file(tmp_path, "f.txt", "f\n")
    write_file(tmp_path, "f.json", "0")
    argv = ["-nc"] + first + second + ["$k"]
    res = run_gojq(argv, cwd=tmp_path)
    # CATCHES: the dedup of predefined names is global across --arg,
    # --argjson, --rawfile and --slurpfile, in command-line order — a second
    # flag defining the same name contributes nothing.
    assert res.returncode == 0
    assert res.stdout == expected + b"\n"


def test_slurpfile_and_rawfile_also_dedupe(tmp_path):
    """``--slurpfile`` then ``--rawfile`` with one name keeps the slurped array."""
    write_file(tmp_path, "f.json", "1")
    write_file(tmp_path, "f.txt", "f\n")
    res = run_gojq(
        ["-nc", "--slurpfile", "k", "f.json", "--rawfile", "k", "f.txt", "$k"],
        cwd=tmp_path,
    )
    # CATCHES: the cross-flag rule covers the two file-reading flags as well;
    # the array from --slurpfile survives.
    assert res.returncode == 0
    assert res.stdout == b"[1]\n"


def test_args_object_default_shape():
    """``$ARGS`` exists even with no variable flags at all."""
    res = run_gojq(["-nc", "$ARGS"])
    # CATCHES: $ARGS is always bound, with empty named/positional parts.
    assert res.returncode == 0
    assert res.stdout == b'{"named":{},"positional":[]}\n'


def test_args_object_named_part():
    """``$ARGS.named`` holds the string and JSON variables together."""
    res = run_gojq(
        ["-nc", "--arg", "s", "v", "--argjson", "n", "5", "$ARGS.named"]
    )
    # CATCHES: both --arg and --argjson land in the same named object.
    assert res.returncode == 0
    assert res.stdout == b'{"n":5,"s":"v"}\n'


def test_args_flag_makes_positionals_strings():
    """``--args`` turns the arguments after the query into strings."""
    res = run_gojq(["-nc", "--args", "$ARGS.positional", "a", "1", "[2]"])
    # CATCHES: after --args every remaining positional (including JSON-looking
    # ones) is a plain string, and the query is still the first positional.
    assert res.returncode == 0
    assert res.stdout == b'["a","1","[2]"]\n'


def test_args_flag_with_no_positionals():
    """``--args`` with nothing following yields an empty positional list."""
    res = run_gojq(["-nc", "--args", "$ARGS.positional"])
    # CATCHES: --args alone does not error; positional stays [].
    assert res.returncode == 0
    assert res.stdout == b"[]\n"


def test_jsonargs_parses_each_positional():
    """``--jsonargs`` parses every remaining positional as JSON."""
    res = run_gojq(
        ["-nc", "--jsonargs", "$ARGS.positional", "1", '"x"', "[2,{\"k\":null}]"]
    )
    # CATCHES: each argument is individually JSON-parsed (not one document),
    # preserving types across the list.
    assert res.returncode == 0
    assert res.stdout == b'[1,"x",[2,{"k":null}]]\n'


def test_jsonargs_invalid_value_error():
    """A non-JSON positional under ``--jsonargs`` fails naming the flag."""
    res = run_gojq(["-nc", "--jsonargs", "$ARGS.positional", "1", "oops"])
    # CATCHES: the error header names `--jsonargs` (the flag, in contrast to
    # --argjson naming the variable), exit 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid json: --jsonargs\n"
        b"    oops\n"
        b"    ^  invalid character 'o' looking for beginning of value\n"
    )


def test_args_then_jsonargs_overwrites_in_place():
    """``--args a --jsonargs 1`` merges into one positional list."""
    res = run_gojq(["-nc", "--args", "$ARGS.positional", "a", "--jsonargs", "1"])
    # CATCHES: --jsonargs copies the earlier --args list and replaces the
    # entries it parses, so the result mixes both: ["a",1].
    assert res.returncode == 0
    assert res.stdout == b'["a",1]\n'


def test_jsonargs_then_args_appends_strings():
    """``--jsonargs 1 2 --args x y`` keeps the parsed values first."""
    res = run_gojq(
        ["-nc", "--jsonargs", "$ARGS.positional", "1", "2", "--args", "x", "y"]
    )
    # CATCHES: the later --args pads the JSON list with its own strings,
    # yielding [1,2,"x","y"] — order preserved from the flags.
    assert res.returncode == 0
    assert res.stdout == b'[1,2,"x","y"]\n'


def test_named_and_positional_coexist():
    """Named variables and --args positionals appear together in $ARGS."""
    res = run_gojq(["-nc", "--arg", "a", "1", "--args", "$ARGS", "p"])
    # CATCHES: $ARGS has both parts at once, positional holding "p".
    assert res.returncode == 0
    assert res.stdout == b'{"named":{"a":"1"},"positional":["p"]}\n'


@pytest.mark.parametrize(
    "name",
    ["1abc", "a-b", "", "a.b", "ünï"],
)
def test_invalid_variable_names_are_compile_errors(name):
    """Names that are not valid jq identifiers fail at compile time."""
    res = run_gojq(["-nc", "--arg", name, "v", "$ARGS"])
    # CATCHES: the name is validated (as `$name`) during compilation, giving
    # `compile error: invalid variable name: $<name>` with exit 3.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: compile error: invalid variable name: $%s\n" % name.encode()
    )


def test_arg_value_that_looks_like_a_flag():
    """A value starting with ``-`` is taken verbatim by ``--arg``."""
    res = run_gojq(["-nc", "--arg", "k", "-x", "$k"])
    # CATCHES: the second argument of --arg is consumed as a value even though
    # it looks like a short flag.
    assert res.returncode == 0
    assert res.stdout == b'"-x"\n'
