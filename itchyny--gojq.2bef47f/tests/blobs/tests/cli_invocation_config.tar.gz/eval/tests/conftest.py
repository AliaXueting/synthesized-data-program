"""Shared harness for the ``cli_invocation_config`` module tests.

Every test drives the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hard-coded path).  The main helper is ``run_gojq``, which takes a raw argument
vector and returns the completed process with byte-exact stdout/stderr so the
recorded expectations can be asserted verbatim.

The child environment is fully pinned (an empty temporary HOME, fixed PATH,
LANG and TMPDIR) so the default module search paths (``~/.jq`` et al.) never
pick up files from the ambient machine.  Tests that exercise the ``~`` search
path pass their own ``HOME`` through ``env=``.
"""

from __future__ import annotations

import os
import pathlib
import subprocess
import tempfile

# The pinned child environment is built per call; HOME points at an empty
# throwaway directory created on first use so ``~/.jq`` does not exist.
_BASE_HOME: list[str] = []


def executable_path() -> str:
    """Return the candidate path from PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE", "")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; the suite cannot drive the candidate"
        )
    return path


def default_home() -> str:
    """Return a stable empty HOME directory (created on first call)."""
    if not _BASE_HOME:
        _BASE_HOME.append(tempfile.mkdtemp(prefix="gojq-cli-home-"))
    return _BASE_HOME[0]


def _merge_env(env, extra):
    """Build the child environment: pinned base, overridden by env/extra."""
    if env is None:
        merged = {
            "PATH": "/usr/bin:/bin",
            "HOME": default_home(),
            "TMPDIR": "/tmp",
            "LANG": "C",
        }
    else:
        # An explicit env is used verbatim so tests can pin exactly which
        # variables the child sees (the binary spawns no other processes).
        merged = dict(env)
    if extra:
        merged.update(extra)
    # Coverage instrumentation hook (REQUIRED): copy GOCOVERDIR from the
    # test process environment into the child env when present, so the
    # pipeline can measure source coverage of the reference binary.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    merged.update(cov_env)
    return merged


def run_gojq(argv, *, stdin="", cwd=None, env=None, extra=None, timeout=30):
    """Run the candidate with a raw argument vector, return the process.

    stdin may be str or bytes; stdout/stderr are always bytes so that exact
    recorded byte expectations can be asserted.
    """
    data = stdin if isinstance(stdin, bytes) else stdin.encode()
    return subprocess.run(
        [executable_path()] + list(argv),
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env=_merge_env(env, extra),
        timeout=timeout,
    )


def write_file(directory, name, text):
    """Write TEXT to DIRECTORY/NAME and return the path as a str."""
    path = pathlib.Path(directory) / name
    path.write_text(text, encoding="utf-8")
    return str(path)
