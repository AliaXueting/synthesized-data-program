"""Accepted spellings of gojq's flags (clusters, ``=``, ``--``).

The reflection-based parser in ``cli/flags.go`` accepts several argument
grammars: long and short flags, clustered shorts, ``--flag=value``,
``-L=value``, ``-Lvalue`` and space-separated values, plus ``--`` to stop
option parsing.  These tests record which spellings the reference accepts and
which silently degrade into positional arguments.
"""

from __future__ import annotations

import pytest

from conftest import run_gojq, write_file

# All expectations below were recorded by running ./executable.


def test_long_and_short_flag_are_equivalent(tmp_path):
    """``-c`` and ``--compact-output`` produce identical compacted output."""
    long_res = run_gojq(["--compact-output", "."], stdin='{"a": [1, 2]}')
    short_res = run_gojq(["-c", "."], stdin='{"a": [1, 2]}')
    # CATCHES: both spellings set the same option; a parser that only binds
    # one of them would differ on the other invocation.
    assert long_res.returncode == 0
    assert long_res.stdout == b'{"a":[1,2]}\n'
    assert long_res.stdout == short_res.stdout
    assert short_res.returncode == 0


def test_clustered_short_flags_apply_together():
    """``-cn`` clusters two boolean shorts into one argument."""
    res = run_gojq(["-cn", "1, 2"])
    # CATCHES: every letter of a cluster is expanded (null-input + compact),
    # so `-cn` behaves exactly like `-c -n`.
    assert res.returncode == 0
    assert res.stdout == b"1\n2\n"


def test_cluster_of_three_flags():
    """``-nrj`` applies raw, null-input and join-output at once."""
    res = run_gojq(["-nrj", '"a", "b"'])
    # CATCHES: three clustered shorts all take effect; output is joined
    # without any delimiter between the two raw strings.
    assert res.returncode == 0
    assert res.stdout == b"ab"


def test_value_taking_short_flag_terminates_a_cluster(tmp_path):
    """A cluster ending in ``-L`` takes its value from the next argument."""
    libs = tmp_path / "libs"
    libs.mkdir()
    write_file(libs, "m.jq", "def twice: . * 2;\n")
    res = run_gojq(["-nL", "libs", 'import "m" as m; 21 | m::twice'], cwd=tmp_path)
    # CATCHES: `-nL libs` must set null-input AND bind the library path from
    # the following argument; splitting wrongly reports an unknown flag.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


@pytest.mark.parametrize("spelling", ["-L=libs", "-Llibs", "-L libs"])
def test_short_library_path_spellings(tmp_path, spelling):
    """``-L=dir``, ``-Ldir`` and ``-L dir`` all set the library path."""
    libs = tmp_path / "libs"
    libs.mkdir()
    write_file(libs, "m.jq", "def twice: . * 2;\n")
    argv = list(spelling.split(" ")) if " " in spelling else [spelling]
    res = run_gojq(["-n"] + argv + ['import "m" as m; 21 | m::twice'], cwd=tmp_path)
    # CATCHES: the `=` form, the attached form and the separate form are all
    # accepted for the value-taking short flag -L.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


@pytest.mark.parametrize("spelling", ["--library-path=libs", "--library-path libs"])
def test_long_library_path_spellings(tmp_path, spelling):
    """``--library-path=dir`` and ``--library-path dir`` both work."""
    libs = tmp_path / "libs"
    libs.mkdir()
    write_file(libs, "m.jq", "def thrice: . * 3;\n")
    argv = list(spelling.split(" ")) if " " in spelling else [spelling]
    res = run_gojq(["-n"] + argv + ['import "m" as m; 14 | m::thrice'], cwd=tmp_path)
    # CATCHES: the long flag accepts an attached `=value` as well as a
    # separate argument.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


def test_long_equals_form_for_indent():
    """``--indent=3`` passes the value through the ``=`` syntax."""
    res = run_gojq(["--indent=3", "."], stdin='{"a": [1]}')
    # CATCHES: the attached value is parsed as an integer indent of three
    # spaces per level (reference output below recorded verbatim).
    assert res.returncode == 0
    assert res.stdout == b'{\n   "a": [\n      1\n   ]\n}\n'


def test_equals_form_of_map_flag_binds_next_argument():
    """``--arg=name value`` makes *name* the variable and *value* its value."""
    res = run_gojq(["-nc", "--arg=foo", "bar", "$foo"])
    # CATCHES: for two-argument flags the `=value` part becomes the FIRST
    # (name) argument and the following argv entry the second (value) —
    # not `--arg` with value `=foo`.
    assert res.returncode == 0
    assert res.stdout == b'"bar"\n'


def test_equals_form_of_map_flag_still_needs_two_arguments():
    """``--arg=name`` alone still reports the two-argument requirement."""
    res = run_gojq(["-nc", "--arg=foo"])
    # CATCHES: the rewritten form consumes the next argv entry as the value,
    # so a missing one yields `expected 2 arguments', not success.
    assert res.returncode == 2
    assert res.stderr == b"gojq: expected 2 arguments for flag `--arg'\n"


def test_equals_form_of_argjson():
    """``--argjson=name value`` parses the following argument as JSON."""
    res = run_gojq(["-nc", "--argjson=x", "[1, 2]", "$x"])
    # CATCHES: the `=` spelling works for --argjson too; the JSON value comes
    # from the argument after the flag.
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n"


def test_double_dash_stops_option_parsing():
    """After ``--`` every argument is positional, even flag-looking ones."""
    res = run_gojq(["--", "-c", ".a"])
    # CATCHES: `-c` after `--` is not an option; it becomes the query and the
    # following argument an input file, so compilation fails on `-c`.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"gojq: compile error: function not defined: c/0\n"


def test_double_dash_then_ordinary_query():
    """A query after ``--`` is used as the query, not as a flag."""
    res = run_gojq(["--", ".a"], stdin='{"a": 7}')
    # CATCHES: the first positional after `--` is the query itself.
    assert res.returncode == 0
    assert res.stdout == b"7\n"


def test_double_dash_terminator_is_not_kept_as_query():
    """A lone ``--`` followed by a query does not eat the query as a flag."""
    res = run_gojq(["--", "--"], stdin="null")
    # CATCHES: the first `--` ends options, so the second `--` becomes the
    # query text and fails to parse.
    assert res.returncode == 3
    assert res.stderr == (
        b"gojq: invalid query: --\n    --\n      ^  unexpected EOF\n"
    )


def test_bare_dash_is_a_positional_query():
    """A single ``-`` is not an option; it is the query text."""
    res = run_gojq(["-"])
    # CATCHES: only arguments longer than one character starting with `-` are
    # options, so `-` is the query and fails to parse.
    assert res.returncode == 3
    assert res.stderr == b"gojq: invalid query: -\n    -\n     ^  unexpected EOF\n"


def test_dash_with_digits_is_a_positional_query():
    """``-1`` is the negation query, not an option (digits stop clustering)."""
    res = run_gojq(["-1"], stdin="1")
    # CATCHES: a non-letter in what looks like a short cluster makes the whole
    # argument positional; `-1` negates the input.
    assert res.returncode == 0
    assert res.stdout == b"-1\n"


def test_cluster_with_digit_degrades_to_positional():
    """``-n1`` is not an error: the cluster becomes the query ``-n1``."""
    res = run_gojq(["-n1", "1"])
    # CATCHES: hitting a non-letter inside a cluster silently treats the whole
    # argument as a positional, which then fails to compile as a query.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"gojq: compile error: function not defined: n1/0\n"


@pytest.mark.parametrize(
    "arg,func",
    [("-h=x", "x"), ("-r=1", "r"), ("-n=1", "n"), ("-c=2", "c")],
)
def test_short_boolean_with_equals_is_positional(arg, func):
    """``-h=x`` is not a boolean-with-argument error but the query text."""
    res = run_gojq([arg])
    # CATCHES: the `=` rejection only applies to long flags; for a short bool
    # the whole argument degrades to a positional query `-(h=x)` that then
    # fails to compile.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"gojq: compile error: function not defined: %s/0\n" % func.encode()


def test_args_equals_degrades_to_positional():
    """``--args=x`` is not rejected: ``x`` becomes the query."""
    res = run_gojq(["--args=x", "1"])
    # CATCHES: --args is a positional slice flag, not a boolean, so the
    # `=value` check does not fire; the value is re-scanned as a positional.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"gojq: compile error: function not defined: x/0\n"


def test_value_taking_flag_consumes_dash_prefixed_value():
    """``--arg k -x`` stores ``-x`` instead of parsing it as a flag."""
    res = run_gojq(["-nc", "--arg", "k", "-x", "$k"])
    # CATCHES: a flag's argument is taken verbatim even when it starts with a
    # dash, so it never reaches option parsing.
    assert res.returncode == 0
    assert res.stdout == b'"-x"\n'


def test_indent_accepts_negative_value_as_argument():
    """``--indent -3`` consumes ``-3`` and then rejects the range."""
    res = run_gojq(["--indent", "-3", "."], stdin="null")
    # CATCHES: the negative number is consumed as the flag argument (Atoi
    # accepts it) and only the later range check rejects it with exit 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: negative indentation count: -3\n"


def test_flags_may_follow_the_positional_query():
    """Options are scanned after the query argument too."""
    res = run_gojq([".a", "-c"], stdin='{"a": [1]}')
    # CATCHES: parseFlags never stops at the first positional, so a flag
    # placed after the query still applies.
    assert res.returncode == 0
    assert res.stdout == b"[1]\n"


def test_cluster_argument_flag_swallows_following_letter():
    """``-Ln`` uses ``n`` as the library path, not as ``--null-input``."""
    res = run_gojq(["-Ln", "."], stdin="5")
    # CATCHES: when a value-taking short flag is followed by more letters in
    # the same argument, the rest of the cluster becomes its value; `-Ln`
    # therefore does NOT enable null-input (the input value 5 survives).
    assert res.returncode == 0
    assert res.stdout == b"5\n"
