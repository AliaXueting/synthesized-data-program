"""How the query text and the input files are selected from the arguments.

The first non-flag argument is the query (whitespace-trimmed, defaulting to
``.``), the remaining arguments become input files, and ``-f``/``--from-file``
switches the query source to a file.  This file pins that selection logic and
its error paths (missing query file, unreadable file, empty query).
"""

from __future__ import annotations

import pytest

from conftest import run_gojq, write_file

# All expectations below were recorded by running ./executable.


def test_absent_query_defaults_to_identity():
    """With no positional argument at all the query is ``.``."""
    res = run_gojq([], stdin="5")
    # CATCHES: the query defaults to `.` rather than being an error, so the
    # input value is echoed back unchanged.
    assert res.returncode == 0
    assert res.stdout == b"5\n"
    assert res.stderr == b""


def test_first_positional_is_the_query():
    """The first non-flag argument is the query, not a file."""
    res = run_gojq([".a"], stdin='{"a": 42}')
    # CATCHES: argument zero becomes the query text and stdin is still the
    # input source.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


def test_query_argument_is_whitespace_trimmed():
    """Surrounding spaces and newlines are stripped from the query."""
    res = run_gojq(["  .a  "], stdin='{"a": 1}')
    # CATCHES: leading/trailing whitespace is removed before parsing, so a
    # padded query still compiles.
    assert res.returncode == 0
    assert res.stdout == b"1\n"


def test_trimmed_query_shows_in_parse_error():
    """The diagnostic shows the trimmed query text, not the raw argument."""
    res = run_gojq(["  ((  "])
    # CATCHES: the error report displays the trimmed contents `((` (both in
    # the header line and the echoed line), proving TrimSpace ran first.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"gojq: invalid query: ((\n    ((\n      ^  unexpected EOF\n"


def test_leading_newline_is_trimmed_from_query():
    """A leading newline is trimmed, keeping the single-line error format."""
    res = run_gojq(["\n1 +"])
    # CATCHES: after trimming the query contains no newline, so the error uses
    # the plain `invalid query: 1 +' format instead of `invalid query: <arg>:1'.
    assert res.returncode == 3
    assert res.stderr == b"gojq: invalid query: 1 +\n    1 +\n       ^  unexpected EOF\n"


def test_internal_newline_uses_line_numbered_format():
    """A newline *inside* the query switches the error to `<arg>:<line>`."""
    res = run_gojq(["1 +\n +"])
    # CATCHES: only untrimmed newlines inside the query trigger the
    # `invalid query: <arg>:2` multi-line report with a line-number gutter.
    assert res.returncode == 3
    assert res.stderr == b"gojq: invalid query: <arg>:2\n    2 |  +\n          ^  unexpected EOF\n"


def test_remaining_positionals_are_input_files(tmp_path):
    """Arguments after the query are input files, processed in order."""
    write_file(tmp_path, "one.json", '{"a": 1}')
    write_file(tmp_path, "two.json", '{"a": 2}')
    res = run_gojq([".a", "one.json", "two.json"], cwd=tmp_path)
    # CATCHES: every remaining positional is opened as an input file and the
    # query runs once per file, in argv order.
    assert res.returncode == 0
    assert res.stdout == b"1\n2\n"
    assert res.stderr == b""


def test_missing_input_file_is_an_error(tmp_path):
    """A nonexistent input file fails with exit 5 naming the file."""
    missing = tmp_path / "absent.json"
    res = run_gojq([".", str(missing)])
    # CATCHES: input files are opened before evaluation; the Go-style `open
    # <path>: no such file or directory` error is printed with exit code 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: open %s: no such file or directory\n" % str(missing).encode()


def test_from_file_loads_the_query(tmp_path):
    """``-f FILE`` reads the query text from the file."""
    write_file(tmp_path, "query.jq", "def forty_two: 42; forty_two")
    res = run_gojq(["-n", "-f", "query.jq"], cwd=tmp_path)
    # CATCHES: the file content (spaces, definitions and all) becomes the
    # query, evaluated with null input.
    assert res.returncode == 0
    assert res.stdout == b"42\n"


def test_from_file_long_flag(tmp_path):
    """``--from-file`` is the long spelling of ``-f``."""
    write_file(tmp_path, "query.jq", ".a")
    res = run_gojq(["--from-file", "query.jq"], stdin='{"a": 9}', cwd=tmp_path)
    # CATCHES: the long spelling works identically and stdin is still read
    # when no input files follow.
    assert res.returncode == 0
    assert res.stdout == b"9\n"


def test_from_file_consumes_only_first_argument(tmp_path):
    """``-f`` takes the first remaining argument; the rest are input files."""
    write_file(tmp_path, "query.jq", ".a")
    write_file(tmp_path, "data.json", '{"a": 3}')
    res = run_gojq(["-f", "query.jq", "data.json"], cwd=tmp_path)
    # CATCHES: with -f the positional roles shift by one — the first is the
    # query file and the following ones are input files.
    assert res.returncode == 0
    assert res.stdout == b"3\n"


def test_from_file_missing_argument():
    """``-f`` with no argument left reports the dedicated message."""
    res = run_gojq(["-f"])
    # CATCHES: the message `expected a query file for flag `-f'` is a *usage*
    # error (exit 5), not a flag-parse error (exit 2).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: expected a query file for flag `-f'\n"


def test_from_file_unreadable_file(tmp_path):
    """``-f`` on a missing file reports the open error with exit 5."""
    missing = tmp_path / "gone.jq"
    res = run_gojq(["-f", str(missing)])
    # CATCHES: the raw os.ReadFile error is printed (`open ...`) and the exit
    # code is the default error code 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"gojq: open %s: no such file or directory\n" % str(missing).encode()


def test_from_file_directory(tmp_path):
    """``-f`` on a directory reports a read error, still exit 5."""
    res = run_gojq(["-f", str(tmp_path)])
    # CATCHES: opening a directory yields `read <dir>: is a directory`
    # (read, not open), exit 5.
    assert res.returncode == 5
    assert res.stderr == b"gojq: read %s: is a directory\n" % str(tmp_path).encode()


def test_from_file_after_double_dash(tmp_path):
    """``-f -- FILE`` still reads FILE thanks to the terminator."""
    write_file(tmp_path, "query.jq", "1 + 1")
    res = run_gojq(["-f", "--", "query.jq"], stdin="null", cwd=tmp_path)
    # CATCHES: `--` is consumed as the end-of-options marker, not as the
    # query file name, so the following argument is used.
    assert res.returncode == 0
    assert res.stdout == b"2\n"


def test_from_file_with_double_dash_only():
    """``-f --`` has no query file left and reports the usage error."""
    res = run_gojq(["-f", "--"])
    # CATCHES: the terminator leaves zero positional arguments, so the
    # `expected a query file' message fires.
    assert res.returncode == 5
    assert res.stderr == b"gojq: expected a query file for flag `-f'\n"


def test_whitespace_only_query_file_is_missing_query(tmp_path):
    """A query file of only whitespace is a compile error, not ``.``."""
    write_file(tmp_path, "blank.jq", "   \n  ")
    res = run_gojq(["-f", "blank.jq"], stdin="null", cwd=tmp_path)
    # CATCHES: file contents are NOT trimmed like the command-line query, so a
    # blank file is `missing query (try ".")` with exit 3 rather than `.`.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b'gojq: compile error: missing query (try ".")\n'


def test_empty_query_argument_is_missing_query():
    """An explicitly empty query argument is not the default query."""
    res = run_gojq([""], stdin="null")
    # CATCHES: the empty string is a *provided* query and fails to compile
    # with `missing query (try ".")` instead of falling back to `.`.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b'gojq: compile error: missing query (try ".")\n'


def test_query_file_parse_error_names_the_file(tmp_path):
    """A parse error in the query file reports the file path and line."""
    write_file(tmp_path, "broken.jq", "1 +\n")
    res = run_gojq(["-f", "broken.jq"], cwd=tmp_path)
    # CATCHES: with -f the diagnostic header carries the file name and line
    # (`invalid query: broken.jq:1`) with the line-number gutter format.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == (
        b"gojq: invalid query: broken.jq:1\n    1 | 1 +\n           ^  unexpected EOF\n"
    )


def test_query_file_may_contain_newlines(tmp_path):
    """A multi-line query file is fine as long as it parses."""
    write_file(tmp_path, "multiline.jq", "\n\n  .a \n")
    res = run_gojq(["-f", "multiline.jq"], stdin='{"a": 6}', cwd=tmp_path)
    # CATCHES: newlines and surrounding whitespace inside a query file are
    # legal query syntax; only an empty file is an error.
    assert res.returncode == 0
    assert res.stdout == b"6\n"
