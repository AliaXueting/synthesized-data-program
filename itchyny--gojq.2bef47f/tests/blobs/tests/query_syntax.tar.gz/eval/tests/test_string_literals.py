"""Tests for string literals: escapes, unicode, and interpolation.

These pin the exact set of accepted escape sequences, the decoding of
\\uXXXX escapes (including surrogate pairs and lone surrogates), the
string-interpolation grammar, and the "invalid escape sequence" and
"unterminated string literal" parse errors.
"""

import subprocess

import pytest

from conftest import _child_env, _gojq_bin


def test_escape_sequences(run_gojq):
    """All JSON escapes are accepted; '\\/' decodes to a plain slash."""
    # CATCHES: the full escape set \n \t \r \b \f \/ \" \\ round-trips
    # through the string literal, so an implementation missing \b or \f
    # would report an invalid escape instead.
    proc = run_gojq(['" \\n\\t\\r\\b\\f\\/\\\"\\\\ "'])
    assert proc.returncode == 0
    assert proc.stdout == '" \\n\\t\\r\\b\\f/\\"\\\\ "\n'
    assert proc.stderr == ""

    proc = run_gojq(['"a\\/b"'])
    assert proc.returncode == 0
    assert proc.stdout == '"a/b"\n'

    proc = run_gojq(['"a#b"'])
    assert proc.returncode == 0
    assert proc.stdout == '"a#b"\n'


def test_unicode_escapes(run_gojq):
    """\\uXXXX escapes decode; surrogate pairs combine into one rune."""
    # CATCHES: a surrogate pair becomes a single 4-byte UTF-8 character
    # (length 1, 4 bytes) while a lone surrogate degrades to U+FFFD.
    proc = run_gojq(['"\\u0041\\u00e9"'])
    assert proc.returncode == 0
    assert proc.stdout == '"Aé"\n'

    proc = run_gojq(['"\\u0041\\u00e9\\uff10"'])
    assert proc.returncode == 0
    assert proc.stdout == '"Aé０"\n'

    proc = run_gojq(['"\\ud83d\\ude04" | length, utf8bytelength'])
    assert proc.returncode == 0
    assert proc.stdout == "1\n4\n"

    proc = run_gojq(['"\\ud83d"'])
    assert proc.returncode == 0
    assert proc.stdout == '"\ufffd"\n'

    proc = run_gojq(['"\\ude04"'])
    assert proc.returncode == 0
    assert proc.stdout == '"\ufffd"\n'

    proc = run_gojq(['"\\u0001\\u007f"'])
    assert proc.returncode == 0
    assert proc.stdout == '"\\u0001\\u007f"\n'


def test_raw_characters_in_string(run_gojq):
    """Raw newlines and multibyte characters may appear inside literals."""
    # CATCHES: a literal newline inside the string is kept (echoed as \n)
    # and a non-ASCII character passes through without escaping.
    proc = run_gojq(['"a\nb"'])
    assert proc.returncode == 0
    assert proc.stdout == '"a\\nb"\n'

    proc = run_gojq(['"☆"'])
    assert proc.returncode == 0
    assert proc.stdout == '"☆"\n'


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        (
            '"foo\\,bar"',
            'gojq: invalid query: "foo\\,bar"\n'
            '    "foo\\,bar"\n'
            '        ^  invalid escape sequence "\\," in string literal\n',
        ),
        (
            '"\\u"',
            'gojq: invalid query: "\\u"\n'
            '    "\\u"\n'
            '     ^  invalid escape sequence "\\u" in string literal\n',
        ),
        (
            '"\\u````"',
            'gojq: invalid query: "\\u````"\n'
            '    "\\u````"\n'
            '     ^  invalid escape sequence "\\u" in string literal\n',
        ),
        (
            '"\\uAA\\uAA"',
            'gojq: invalid query: "\\uAA\\uAA"\n'
            '    "\\uAA\\uAA"\n'
            '     ^  invalid escape sequence "\\uAA" in string literal\n',
        ),
        (
            '"\\uAA@AA"',
            'gojq: invalid query: "\\uAA@AA"\n'
            '    "\\uAA@AA"\n'
            '     ^  invalid escape sequence "\\uAA" in string literal\n',
        ),
        (
            '"\\uAAGA"',
            'gojq: invalid query: "\\uAAGA"\n'
            '    "\\uAAGA"\n'
            '     ^  invalid escape sequence "\\uAA" in string literal\n',
        ),
        (
            '"\\ufffg"',
            'gojq: invalid query: "\\ufffg"\n'
            '    "\\ufffg"\n'
            '     ^  invalid escape sequence "\\ufff" in string literal\n',
        ),
        (
            '"0\\u00:00"',
            'gojq: invalid query: "0\\u00:00"\n'
            '    "0\\u00:00"\n'
            '      ^  invalid escape sequence "\\u00" in string literal\n',
        ),
        (
            '"0\\u0000\\u000/0"',
            'gojq: invalid query: "0\\u0000\\u000/0"\n'
            '    "0\\u0000\\u000/0"\n'
            '            ^  invalid escape sequence "\\u000" in string literal\n',
        ),
        (
            '"\\(1) \\x "',
            'gojq: invalid query: "\\(1) \\x "\n'
            '    "\\(1) \\x "\n'
            '          ^  invalid escape sequence "\\x" in string literal\n',
        ),
        (
            '"\\a"',
            'gojq: invalid query: "\\a"\n'
            '    "\\a"\n'
            '     ^  invalid escape sequence "\\a" in string literal\n',
        ),
        (
            '"\\U0041"',
            'gojq: invalid query: "\\U0041"\n'
            '    "\\U0041"\n'
            '     ^  invalid escape sequence "\\U" in string literal\n',
        ),
        (
            '"\\x7f"',
            'gojq: invalid query: "\\x7f"\n'
            '    "\\x7f"\n'
            '     ^  invalid escape sequence "\\x" in string literal\n',
        ),
        (
            '"\\u\\(',
            'gojq: invalid query: "\\u\\(\n'
            '    "\\u\\(\n'
            '     ^  invalid escape sequence "\\u" in string literal\n',
        ),
    ],
)
def test_invalid_escape_sequences(run_gojq, query, expected_stderr):
    """Bad escapes report the exact escape text and caret column."""
    # CATCHES: the message quotes only the invalid escape (e.g. "\\uAA" out
    # of "\\uAAGA") and the caret points at the backslash, not the character
    # after it.
    proc = run_gojq([query])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == expected_stderr


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        (
            '. + "foo',
            'gojq: invalid query: . + "foo\n'
            "    . + \"foo\n"
            "            ^  unterminated string literal\n",
        ),
        (
            '"\\',
            'gojq: invalid query: "\\\n    "\\\n      ^  unterminated string literal\n',
        ),
        # The trailing newline of a command-line query is trimmed away before
        # parsing, so the message echoes the query without it and the escaped
        # quote at the end still leaves the literal unterminated.
        (
            '"\\"\n',
            'gojq: invalid query: "\\"\n    "\\"\n       ^  unterminated string literal\n',
        ),
        (
            '"a',
            'gojq: invalid query: "a\n    "a\n      ^  unterminated string literal\n',
        ),
    ],
)
def test_unterminated_string_literals(run_gojq, query, expected_stderr):
    """An unclosed quote reports 'unterminated string literal' at the end."""
    # CATCHES: the caret sits one past the last byte, and an escaped quote
    # at end-of-input still counts as unterminated.
    proc = run_gojq([query])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == expected_stderr


def test_string_interpolation(run_gojq):
    """'\\(query)' splices query results into the string."""
    # CATCHES: interpolations are full queries (object construction, slices,
    # nested interpolations) and may be chained or sit at either end.
    cases = [
        (['"a\\(1+2)b"'], "null\n", '"a3b"\n'),
        (['"\\(1)\\(2)"'], "null\n", '"12"\n'),
        (['"\\(1)a"'], "null\n", '"1a"\n'),
        (['"\\()a"'], "null\n", None),
        (['"a\\("b\\("c\\("d")")")"'], "null\n", '"abcd"\n'),
        (['"x\\("y\\("z")w")e"'], "null\n", '"xyzwe"\n'),
        (['"\\({a:1}.a)"'], "null\n", '"1"\n'),
        (['"\\({a:1})"'], "null\n", '"{\\"a\\":1}"\n'),
        (['"\\(.[1:2])"'], "[1,2,3]\n", '"[2]"\n'),
        (['"{a:1} | "\\(.)""'], None, None),
    ]
    for args, stdin, expected in cases:
        proc = run_gojq(args, input_text=stdin or "null\n")
        if expected is None:
            assert proc.returncode == 3, args
            assert proc.stdout == "", args
        else:
            assert proc.returncode == 0, args
            assert proc.stdout == expected, args

    proc = run_gojq(["--arg", "x", "V", '"\\($x)"'])
    assert proc.returncode == 0
    assert proc.stdout == '"V"\n'


def test_interpolation_syntax_errors(run_gojq):
    """Empty interpolations and unbalanced parens are parse errors."""
    # CATCHES: '"\\()"' rejects an empty interpolation body while '"\\(1 +)'
    # blames the ')' token, and an interpolation left open reports EOF.
    cases = [
        (
            '"\\()"',
            'gojq: invalid query: "\\()"\n    "\\()"\n       ^  unexpected token ")"\n',
        ),
        (
            '"\\(1 +)',
            'gojq: invalid query: "\\(1 +)\n    "\\(1 +)\n          ^  unexpected token ")"\n',
        ),
        (
            '"\\(',
            'gojq: invalid query: "\\(\n    "\\(\n       ^  unexpected EOF\n',
        ),
        (
            '"\\(1) \\x "',
            'gojq: invalid query: "\\(1) \\x "\n'
            '    "\\(1) \\x "\n'
            '          ^  invalid escape sequence "\\x" in string literal\n',
        ),
        (
            '"x\\("y\\("z")"w"',
            'gojq: invalid query: "x\\("y\\("z")"w"\n'
            '    "x\\("y\\("z")"w"\n'
            '                 ^  unexpected token "w"\n',
        ),
    ]
    for query, expected in cases:
        proc = run_gojq([query])
        assert proc.returncode == 3, query
        assert proc.stdout == "", query
        assert proc.stderr == expected, query


def test_escape_of_multibyte_character_is_invalid_utf8(run_gojq):
    """A backslash before a multibyte char yields raw invalid UTF-8 bytes."""
    # CATCHES: the invalid-escape token is the backslash plus only the
    # FIRST byte of the character, so stderr contains a lone 0xC3 byte that
    # is not valid UTF-8; the echo line still shows the full character.
    proc = subprocess.run(
        [_gojq_bin(), '"\\é"'],
        input=b"null\n",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=_child_env(),
        timeout=10,
    )
    assert proc.returncode == 3
    assert proc.stdout == b""
    assert proc.stderr == (
        b'gojq: invalid query: "\\\xc3\xa9"\n'
        b'    "\\\xc3\xa9"\n'
        b'     ^  invalid escape sequence "\\\xc3" in string literal\n'
    )


def test_comment_inside_interpolation(run_gojq):
    """Comments may appear inside an interpolation's query."""
    # CATCHES: the '# c' runs to the newline inside "\\(...)", so the
    # interpolation still evaluates 1 + 2.
    proc = run_gojq(['"\\(1 # c\n+ 2)"'])
    assert proc.returncode == 0
    assert proc.stdout == '"3"\n'
    assert proc.stderr == ""
