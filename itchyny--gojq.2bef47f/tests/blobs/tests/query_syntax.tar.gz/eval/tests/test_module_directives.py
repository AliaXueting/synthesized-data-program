"""Tests for module directives: import, include and the module header.

These pin the directive grammar (where the ';' and 'as' alias are required,
that metadata objects may only contain constant terms) and, through an
explicit '-L' search directory, how a module's own imports use 'search'
metadata and how JSON modules bind '$data' variables.  The metadata
constants are compiled by the ConstTerm/ConstObject helpers in query.go.
"""

import pytest

DIRECTIVE_ERROR_CASES = [
    ("import;", 'gojq: invalid query: import;\n    import;\n          ^  unexpected token ";"\n'),
    ('import "m";', 'gojq: invalid query: import "m";\n    import "m";\n              ^  unexpected token ";"\n'),
    ('import "m" as;', 'gojq: invalid query: import "m" as;\n    import "m" as;\n                 ^  unexpected token ";"\n'),
    (
        'import "m" as x, y;',
        'gojq: invalid query: import "m" as x, y;\n    import "m" as x, y;\n                   ^  unexpected token ","\n',
    ),
    ("include;", 'gojq: invalid query: include;\n    include;\n           ^  unexpected token ";"\n'),
    ('include "m" as x;', 'gojq: invalid query: include "m" as x;\n    include "m" as x;\n                ^  unexpected token "as"\n'),
    ("module;", 'gojq: invalid query: module;\n    module;\n          ^  unexpected token ";"\n'),
    ("module 1;", 'gojq: invalid query: module 1;\n    module 1;\n           ^  unexpected token "1"\n'),
    ("module {a: .foo};", 'gojq: invalid query: module {a: .foo};\n    module {a: .foo};\n               ^  unexpected token ".foo"\n'),
    (
        'import "m" as x {a: .foo};',
        'gojq: invalid query: import "m" as x {a: .foo};\n'
        '    import "m" as x {a: .foo};\n'
        '                        ^  unexpected token ".foo"\n',
    ),
    (
        ". as $x | module {a:1}; .",
        "gojq: invalid query: . as $x | module {a:1}; .\n"
        "    . as $x | module {a:1}; .\n"
        '              ^  unexpected token "module"\n',
    ),
]


@pytest.mark.parametrize(("query", "expected_stderr"), DIRECTIVE_ERROR_CASES)
def test_module_directive_syntax_errors(run_gojq, query, expected_stderr):
    """Malformed import/include/module directives report the bad token."""
    # CATCHES: 'import' requires a path AND 'as' alias, 'include' forbids
    # the alias, metadata values must be constant terms ('.foo' is
    # rejected), and 'module' is only legal at the start of a query.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        ('import "m" as x;', 'gojq: compile error: module not found: "m"\n'),
        ('include "m";', 'gojq: compile error: module not found: "m"\n'),
        ('import "m" as $x;', 'gojq: compile error: module not found: "m"\n'),
        ("module {a: 1}; import \"m\" as x;", 'gojq: compile error: module not found: "m"\n'),
    ],
)
def test_module_not_found(run_gojq, query, expected_stderr):
    """A well-formed directive for a missing module is a compile error."""
    # CATCHES: the directive parses fine and fails at compile time with
    # 'module not found' naming the quoted path, exit code 3.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


def test_module_header_forms(run_gojq):
    """A 'module {...};' header prefixes the query; alone it is empty."""
    # CATCHES: 'module {a: 1}; .' parses and runs, but a file with only a
    # module header reports 'missing query' because there is no body.
    proc = run_gojq(["module {a: 1}; ."])
    assert proc.returncode == 0
    assert proc.stdout == "null\n"
    assert proc.stderr == ""

    for header in ["module {};", 'module {"a": 1};']:
        proc = run_gojq([header])
        assert proc.returncode == 3, header
        assert proc.stdout == "", header
        assert proc.stderr == 'gojq: compile error: missing query (try ".")\n', header


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        # every constant term kind is accepted as metadata
        (
            'import "m" as x {a: 1, "b": "s", c: null, d: true, e: false,'
            ' f: [1, "x"], g: {h: 2}};',
            'gojq: compile error: module not found: "m"\n',
        ),
        ('import "m" as x {};', 'gojq: compile error: module not found: "m"\n'),
    ],
)
def test_import_metadata_constant_terms(run_gojq, query, expected_stderr):
    """Metadata objects accept numbers, strings, null, bools, arrays, objs."""
    # CATCHES: metadata values are restricted to constant terms -- numbers,
    # strings, null, true, false and nested constant arrays/objects all
    # parse, while any query term is rejected in the syntax-error test.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


def _write(tmp_path, name, contents):
    path = tmp_path / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(contents, encoding="utf-8", newline="")
    return path


def test_module_loading_with_search_metadata(run_gojq, tmp_path):
    """A module's own import may redirect lookup via '{search: "dir"}'."""
    # CATCHES: the 'search' metadata of an import inside a *loaded module*
    # resolves relative to that module's directory, so 'n' is found under
    # 'sub/' even though the outer '-L' directory does not contain it.
    _write(tmp_path, "q.jq", 'include "m2";\nh\n')
    _write(tmp_path, "m2.jq", 'import "n" as y {search: "sub"};\ndef h: y::g;\n')
    _write(tmp_path, "sub/n.jq", "def g: 7;\n")
    proc = run_gojq(["-L", ".", "-f", "q.jq"], input_text="0")
    assert proc.returncode == 0
    assert proc.stdout == "7\n"
    assert proc.stderr == ""


def test_module_search_metadata_non_string_ignored(run_gojq, tmp_path):
    """A non-string 'search' metadata value is ignored, not an error."""
    # CATCHES: '{search: 1}' parses but does not redirect the lookup, so
    # the import fails with 'module not found' rather than a type error.
    _write(tmp_path, "q.jq", 'include "m3";\nh\n')
    _write(tmp_path, "m3.jq", 'import "n" as y {search: 1, other: [1]};\ndef h: y::g;\n')
    _write(tmp_path, "sub/n.jq", "def g: 7;\n")
    proc = run_gojq(["-L", ".", "-f", "q.jq"], input_text="0")
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: compile error: module not found: "n"\n'


def test_module_parse_error_uses_file_form(run_gojq, tmp_path):
    """A syntax error inside a loaded module reports that module's file."""
    # CATCHES: the error names the module file ('bad.jq:2') with the
    # line-number gutter, not the -f query file or '<arg>'.
    _write(tmp_path, "q.jq", 'include "bad";\n.\n')
    _write(tmp_path, "bad.jq", "def f: 1\n%{\n")
    proc = run_gojq(["-L", ".", "-f", "q.jq"])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: invalid query: bad.jq:2\n    2 | %{\n          ^  unexpected EOF\n'


def test_json_module_import(run_gojq, tmp_path):
    """'import "d" as $data' slurps a .json file into a $variable."""
    # CATCHES: the JSON file's values are collected into an array (so the
    # binding is $data[0].k even for a single object), and multiple JSON
    # values in one file become successive elements of that array.
    _write(tmp_path, "q.jq", 'import "d" as $data;\n$data[0].k\n')
    _write(tmp_path, "d.json", '{"k": [1, 2]}')
    proc = run_gojq(["-L", ".", "-f", "q.jq"])
    assert proc.returncode == 0
    assert proc.stdout == "[\n  1,\n  2\n]\n"
    assert proc.stderr == ""

    _write(tmp_path, "q.jq", 'import "two" as $t;\n[$t[0].a, $t[1].b]\n')
    _write(tmp_path, "two.json", '{"a":1} {"b":2}')
    proc = run_gojq(["-L", ".", "-f", "q.jq"])
    assert proc.returncode == 0
    assert proc.stdout == "[\n  1,\n  2\n]\n"
    assert proc.stderr == ""


def test_json_module_invalid_json(run_gojq, tmp_path):
    """A malformed .json module fails compilation with a json error."""
    # CATCHES: the compile error wraps the JSON parse error and echoes the
    # offending file contents with a caret, exit code 3.
    _write(tmp_path, "q.jq", 'import "bad" as $b;\n1\n')
    _write(tmp_path, "bad.json", "oops")
    proc = run_gojq(["-L", ".", "-f", "q.jq"])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == (
        "gojq: compile error: invalid json: bad.json\n"
        "    oops\n"
        "    ^  invalid character 'o' looking for beginning of value\n"
    )


def test_import_binds_module_functions(run_gojq, tmp_path):
    """'import ... as x' binds functions under 'x::', include does not."""
    # CATCHES: an imported module's functions are reachable through the
    # 'x::name' namespace while 'include' puts them in the plain scope.
    _write(tmp_path, "q.jq", 'import "m" as x;\nx::f\n')
    _write(tmp_path, "m.jq", "def f: 42;\n")
    proc = run_gojq(["-L", ".", "-f", "q.jq"])
    assert proc.returncode == 0
    assert proc.stdout == "42\n"
    assert proc.stderr == ""

    _write(tmp_path, "q.jq", 'include "m";\nf\n')
    proc = run_gojq(["-L", ".", "-f", "q.jq"])
    assert proc.returncode == 0
    assert proc.stdout == "42\n"
    assert proc.stderr == ""


def test_import_metadata_compiles_with_module(run_gojq, tmp_path):
    """A full constant metadata object loads alongside the module."""
    # CATCHES: metadata containing every constant term kind (numbers,
    # strings, null, true/false, arrays and nested objects) compiles with
    # the import and does not disturb the module's functions.
    _write(
        tmp_path,
        "q.jq",
        'import "m" as x {a: 1, "b": "s", c: null, d: true, e: false,'
        ' f: [1, "x"], g: {h: 2}};\nx::f\n',
    )
    _write(tmp_path, "m.jq", "def f: 42;\n")
    proc = run_gojq(["-L", ".", "-f", "q.jq"], input_text="0")
    assert proc.returncode == 0
    assert proc.stdout == "42\n"
    assert proc.stderr == ""


CONST_METADATA_ERROR_CASES = [
    # an interpolated string is not a constant term; the parser blames the
    # key token 'search' for the failure, with the caret inside that key
    (
        'import "m" as x {search: "\\(1)"};',
        'gojq: invalid query: import "m" as x {search: "\\(1)"};\n'
        '    import "m" as x {search: "\\(1)"};\n'
        '                        ^  unexpected token "search"\n',
    ),
    # unary minus is not part of the constant-term grammar
    (
        'import "m" as x {a: -1};',
        'gojq: invalid query: import "m" as x {a: -1};\n'
        '    import "m" as x {a: -1};\n'
        '                        ^  unexpected token "-"\n',
    ),
    ("module {a: -1}; .", 'gojq: invalid query: module {a: -1}; .\n    module {a: -1}; .\n               ^  unexpected token "-"\n'),
]


@pytest.mark.parametrize(("query", "expected_stderr"), CONST_METADATA_ERROR_CASES)
def test_const_metadata_value_restrictions(run_gojq, query, expected_stderr):
    """Metadata values must be plain constant terms, not expressions."""
    # CATCHES: interpolated strings and unary minus are rejected inside
    # import/module metadata even though plain '-1' is a number literal
    # elsewhere; the interpolated-string case blames the key token.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


def test_quoted_search_metadata_key(run_gojq, tmp_path):
    """A quoted '"search"' metadata key redirects module lookup."""
    # CATCHES: the metadata object's ToValue folds both identifier keys and
    # quoted string keys to the same name, so '{"search": "d"}' resolves
    # the module from directory d exactly like '{search: "d"}' would.
    _write(tmp_path, "q.jq", 'import "m" as x {"search": "d"};\nx::f\n')
    _write(tmp_path, "d/m.jq", "def f: 42;\n")
    proc = run_gojq(["-L", ".", "-f", "q.jq"], input_text="0")
    assert proc.returncode == 0
    assert proc.stdout == "42\n"
    assert proc.stderr == ""


def test_include_with_search_metadata(run_gojq, tmp_path):
    """'include' also accepts a metadata object with a search path."""
    # CATCHES: the include production takes the same optional metadata as
    # import (but no 'as' alias), and its quoted 'search' key redirects
    # the lookup of the included module itself.
    _write(tmp_path, "q.jq", 'include "m" {"search": "d"};\nf\n')
    _write(tmp_path, "d/m.jq", "def f: 42;\n")
    proc = run_gojq(["-L", ".", "-f", "q.jq"], input_text="0")
    assert proc.returncode == 0
    assert proc.stdout == "42\n"
    assert proc.stderr == ""


def test_quoted_search_inside_loaded_module(run_gojq, tmp_path):
    """A loaded module's own import may use a quoted 'search' key."""
    # CATCHES: the quoted KeyString form of 'search' metadata also
    # redirects the lookup of a module's own imports, resolved relative
    # to that module's directory, exactly like the identifier-key form.
    _write(tmp_path, "q.jq", 'include "m2";\nh\n')
    _write(tmp_path, "m2.jq", 'import "n" as y {"search": "e"};\ndef h: y::g;\n')
    _write(tmp_path, "e/n.jq", "def g: 7;\n")
    proc = run_gojq(["-L", ".", "-f", "q.jq"], input_text="0")
    assert proc.returncode == 0
    assert proc.stdout == "7\n"
    assert proc.stderr == ""


def test_duplicate_search_metadata_last_wins(run_gojq, tmp_path):
    """Duplicate 'search' keys: the later metadata entry wins."""
    # CATCHES: ToValue builds a map, so in '{search: "a", "search": "b"}'
    # the quoted entry overwrites the identifier one -- the module is
    # found in b (222), never in a (111).
    _write(tmp_path, "a/m.jq", "def f: 111;\n")
    _write(tmp_path, "b/m.jq", "def f: 222;\n")
    _write(tmp_path, "q.jq", 'import "m" as x {search: "a", "search": "b"};\nx::f\n')
    proc = run_gojq(["-L", ".", "-f", "q.jq"], input_text="0")
    assert proc.returncode == 0
    assert proc.stdout == "222\n"
    assert proc.stderr == ""
