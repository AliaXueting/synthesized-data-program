"""Tests for individual grammar productions of the goyacc parser.

Each group drives a distinct reduce action in the generated parser: the '/'
and '%' operators, the empty object '{}', unary '+', the 'term '.' suffix'
and 'term '.' string' productions, bare-string object keys, pipe
expressions inside object values, string and computed keys in destructuring
patterns, the const-object/const-array forms allowed in module metadata,
and deeply nested queries that force the parser stack to grow.
"""

import pytest

DIV_MOD_CASES = [
    ("6 / 2", 0, "3\n", ""),
    ('"a,b" / ","', 0, '[\n  "a",\n  "b"\n]\n', ""),
    ("1 / 0", 5, "", "gojq: cannot divide number (1) by: number (0)\n"),
    ("5 % 2", 0, "1\n", ""),
    ("5.5 % 2", 0, "1\n", ""),
    ("1 % 0", 5, "", "gojq: cannot modulo number (1) by: number (0)\n"),
]


@pytest.mark.parametrize(("query", "expected_rc", "expected_stdout", "expected_stderr"), DIV_MOD_CASES)
def test_division_and_modulo(run_gojq, query, expected_rc, expected_stdout, expected_stderr):
    """'/' divides or splits strings; '%' truncates toward zero."""
    # CATCHES: '/' is polymorphic (numbers divide, strings split on the
    # separator) and errors on a zero divisor, while '%' truncates its
    # operands before taking the remainder (5.5 % 2 is 1) and errors on a
    # zero divisor with its own 'cannot modulo' wording.
    proc = run_gojq([query])
    assert proc.returncode == expected_rc, query
    assert proc.stdout == expected_stdout, query
    assert proc.stderr == expected_stderr, query


EMPTY_OBJECT_UNARY_CASES = [
    ("{}", 0, "{}\n", ""),
    ("+1", 0, "1\n", ""),
    ('+"a"', 5, "", 'gojq: cannot plus: string ("a")\n'),
    ("+null", 5, "", "gojq: cannot plus: null\n"),
]


@pytest.mark.parametrize(("query", "expected_rc", "expected_stdout", "expected_stderr"), EMPTY_OBJECT_UNARY_CASES)
def test_empty_object_and_unary_plus(run_gojq, query, expected_rc, expected_stdout, expected_stderr):
    """'{}' is an object construction and '+' is a unary operator."""
    # CATCHES: a bare '{}' reduces to an empty object construction (it is
    # not a block or a parse error), and unary '+' accepts only numbers —
    # applying it to a string or to null is a run-time 'cannot plus' error
    # rather than a syntax error.
    proc = run_gojq([query])
    assert proc.returncode == expected_rc, query
    assert proc.stdout == expected_stdout, query
    assert proc.stderr == expected_stderr, query


TERM_SUFFIX_CASES = [
    (".a.[1]", '{"a":[5,6]}\n', "6\n"),
    ("[5,6] as $x | $x.[1]", "null\n", "6\n"),
    ('.a."b"', '{"a":{"b":7}}\n', "7\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), TERM_SUFFIX_CASES)
def test_term_dot_suffix_and_string(run_gojq, query, stdin, expected):
    """A term may be followed by '.' then a suffix or a string."""
    # CATCHES: 'term '.' suffix' and 'term '.' string' are separate
    # productions from the plain '.a[1]' / '.a.b' forms, so '.a.[1]',
    # '$x.[1]' and '.a."b"' all parse and index exactly like their dotted
    # equivalents.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


STRING_KEY_CASES = [
    ('{"foo"}', '{"foo":9}\n', '{\n  "foo": 9\n}\n'),
    ('{"a b"}', '{"a b":1}\n', '{\n  "a b": 1\n}\n'),
    ("{a: 1 | . + 1}", "null\n", '{\n  "a": 2\n}\n'),
    ("{a: 1 | . + 1, b: 2}", "null\n", '{\n  "a": 2,\n  "b": 2\n}\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), STRING_KEY_CASES)
def test_string_object_keys_and_pipe_values(run_gojq, query, stdin, expected):
    """A bare string is an object shorthand; values may be pipe expressions."""
    # CATCHES: '{"foo"}' reduces as a string objectkeyval and looks that
    # field up in the input (spaces in the key included), and an object
    # value is a full pipe expression — '{a: 1 | . + 1}' maps the pipe over
    # '.' being the object under construction, and a following ', b: 2'
    # then continues the object.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


PATTERN_KEY_CASES = [
    ('{"a":1,"b":2} as {a: $x, b: $y} | [$x, $y]', "null\n", "[\n  1,\n  2\n]\n"),
    ('{"a":1,"b":2} as {a: $x, ("b"): $y} | [$x, $y]', "null\n", "[\n  1,\n  2\n]\n"),
    ('{"a b":1} as {"a b": $x} | $x', "null\n", "1\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), PATTERN_KEY_CASES)
def test_object_pattern_keys(run_gojq, query, stdin, expected):
    """Object patterns accept several entries, computed and quoted keys."""
    # CATCHES: an objectpattern reduces from multiple 'patternkey: $var'
    # entries, and the key may be a computed parenthesized expression
    # ('("b")') or a quoted string whose text contains spaces, unlike the
    # '{a: $x}' identifier-only shorthand.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


METADATA_CASES = [
    ("module {a: 1,}; .", 0, "null\n", ""),
    ("module {if: 1}; .", 0, "null\n", ""),
    ('import "m" as x {a: []}; .', 3, "", 'gojq: compile error: module not found: "m"\n'),
    ('import "m" as x {if: 1}; .', 3, "", 'gojq: compile error: module not found: "m"\n'),
]


@pytest.mark.parametrize(("query", "expected_rc", "expected_stdout", "expected_stderr"), METADATA_CASES)
def test_module_metadata_const_forms(run_gojq, query, expected_rc, expected_stdout, expected_stderr):
    """Const-object metadata allows trailing commas, keywords, empty arrays."""
    # CATCHES: the const-object in a module or import header may end with a
    # trailing comma and may use a keyword like 'if' as a key, and a
    # const-array in that position may be empty — all of these parse, and
    # the imports only fail later at module resolution ('module not found'),
    # proving the grammar accepted the metadata form itself.
    proc = run_gojq([query])
    assert proc.returncode == expected_rc, query
    assert proc.stdout == expected_stdout, query
    assert proc.stderr == expected_stderr, query


DEEP_CASES = [
    ("(" * 400 + "1+2" + ")" * 400, "3\n"),
    ("1 | " + " | ".join(["."] * 400), "1\n"),
]


@pytest.mark.parametrize(("query", "expected"), DEEP_CASES)
def test_deeply_nested_queries(run_gojq, query, expected):
    """Hundreds of nesting levels still parse and evaluate."""
    # CATCHES: 400 levels of parentheses (or 400 chained pipes) parse
    # without a depth limit or stack complaint — the generated parser grows
    # its state stack on demand — and the nesting leaves the result alone.
    proc = run_gojq([query])
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == ""
