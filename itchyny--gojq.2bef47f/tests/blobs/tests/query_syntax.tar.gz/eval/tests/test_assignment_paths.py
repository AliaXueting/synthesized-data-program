"""Tests for assignment and update paths.

These pin the grammar of '=' / '|=' update expressions and the compile-time
rewrite of constant left-hand paths into 'setpath', which lives in the
toIndexKey/toIndices helpers of query.go: a constant '.a[0] = f' becomes
setpath(["a", 0]; f) and a slice '.[1:2] = f' becomes
setpath([{"start": 1, "end": 2}]; f), visible verbatim in runtime errors.
"""

import pytest

ASSIGN_CASES = [
    (".a[0] = 9", '{"a":[1,2]}', '{\n  "a": [\n    9,\n    2\n  ]\n}\n'),
    ('.["k"] = 9', "{}", '{\n  "k": 9\n}\n'),
    (".[1:2] = [9]", "[1,2,3]", "[\n  1,\n  9,\n  3\n]\n"),
    (".[:2] = [9]", "[1,2,3]", "[\n  9,\n  3\n]\n"),
    (".[1:] = [9]", "[1,2,3]", "[\n  1,\n  9\n]\n"),
    ("(.a).b = 9", '{"a":{"b":1}}', '{\n  "a": {\n    "b": 9\n  }\n}\n'),
    (
        ".a.b[0][1:] = [9]",
        '{"a":{"b":[[1,2]]}}',
        '{\n  "a": {\n    "b": [\n      [\n        1,\n        9\n      ]\n    ]\n  }\n}\n',
    ),
    ('."a b" = 1', "null", '{\n  "a b": 1\n}\n'),
    (".a? = 1", "null", '{\n  "a": 1\n}\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), ASSIGN_CASES)
def test_constant_path_assignment(run_gojq, query, stdin, expected):
    """'=' accepts field, bracket, slice and parenthesized constant paths."""
    # CATCHES: the '=' operator parses suffix chains (slices with one or
    # both bounds omitted, quoted keys, an optional '?' and a parenthesized
    # term) on the left side, and each rewrite updates exactly that path.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "stdin", "expected_stderr"),
    [
        (
            ".[0] = 1",
            "5",
            "gojq: setpath([0]; 1) cannot be applied to 5:"
            " expected an array but got: number (5)\n",
        ),
        (
            ".[1:2] = 9",
            "[1,2,3]",
            'gojq: setpath([{"end":2,"start":1}]; 9) cannot be applied'
            " to [1,2,3]: expected an array but got: number (9)\n",
        ),
        (
            '.["k"] = 1',
            "5",
            'gojq: setpath(["k"]; 1) cannot be applied to 5:'
            " expected an object but got: number (5)\n",
        ),
    ],
)
def test_assignment_rewrite_visible_in_errors(run_gojq, query, stdin, expected_stderr):
    """Runtime failures of constant '=' show the rewritten setpath call."""
    # CATCHES: the error text names setpath with the folded path array —
    # '[0]' for an index and '{"end":2,"start":1}' for a slice — proving
    # the compile-time constant-path rewrite of the '=' grammar.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 5, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


def test_nonconstant_path_assignment(run_gojq):
    """Non-constant paths fall back to path-based update semantics."""
    # CATCHES: '.a[.b] = 1' computes the index from the input and '.a[] = 1'
    # updates every element, while '|=' runs a filter through each path —
    # none of these may be folded into a constant setpath.
    cases = [
        ('.a[.b] = 1', '{"a":[9,9],"b":1}', '{\n  "a": [\n    9,\n    1\n  ],\n  "b": 1\n}\n'),
        ('.a[] = 1', '{"a":[9,9]}', '{\n  "a": [\n    1,\n    1\n  ]\n}\n'),
        ('.a |= 1', '{"a":5}', '{\n  "a": 1\n}\n'),
    ]
    for query, stdin, expected in cases:
        proc = run_gojq([query], input_text=stdin)
        assert proc.returncode == 0, query
        assert proc.stdout == expected, query
        assert proc.stderr == "", query


UPDATE_OP_CASES = [
    ('.a += 5', '{"a":1}', '{\n  "a": 6\n}\n'),
    ('.a -= 5', '{"a":10}', '{\n  "a": 5\n}\n'),
    ('.a *= 5', '{"a":2}', '{\n  "a": 10\n}\n'),
    ('.a /= 5', '{"a":10}', '{\n  "a": 2\n}\n'),
    ('.a %= 5', '{"a":12}', '{\n  "a": 2\n}\n'),
    # //= only replaces falsy values, like //
    ('.a //= 5', '{"a":false}', '{\n  "a": 5\n}\n'),
    ('.a[1] += 1', '{"a":[1,2]}', '{\n  "a": [\n    1,\n    3\n  ]\n}\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), UPDATE_OP_CASES)
def test_update_operators(run_gojq, query, stdin, expected):
    """The arithmetic update operators '+=' to '//=' parse and apply."""
    # CATCHES: each two-character update operator is one token ('+=' is not
    # '+' then '='), and '//=' keeps a truthy left side instead of
    # overwriting it.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


def test_alternative_operator(run_gojq):
    """'//' yields the right side only when the left is null/false/empty."""
    # CATCHES: '//' binds an alternative expression per output (empty left
    # falls through, null and false are falsy), and a parenthesized path
    # list on the left of '|=' updates every path.
    cases = [
        ('.a // 5', '{"a":false}', "5\n"),
        ('[.a // 5, .b // 6]', '{"a":null}', "[\n  5,\n  6\n]\n"),
        ("[1,2] | .[0] // 3", "[null, 2]", "1\n"),
        ('"a" // "b"', "null", '"a"\n'),
        ("empty // 2", "null", "2\n"),
        ("(.a,.b) |= . + 1", '{"a":1,"b":2}', '{\n  "a": 2,\n  "b": 3\n}\n'),
    ]
    for query, stdin, expected in cases:
        proc = run_gojq([query], input_text=stdin)
        assert proc.returncode == 0, query
        assert proc.stdout == expected, query
        assert proc.stderr == "", query
