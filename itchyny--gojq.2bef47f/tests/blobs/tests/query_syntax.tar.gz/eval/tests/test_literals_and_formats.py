"""Tests for number literals, operators, format strings and constructors.

These pin how the lexer accepts numbers (decimals, exponents, the unary
minus vs subtraction ambiguity), the @format tokens alone and applied to
interpolated strings, and object/array construction syntax including which
keys are accepted and where trailing commas are legal.
"""

import pytest

NUMBER_CASES = [
    (
        "[1, 1.0, 1e2, 1E+2, 1e-2, -0, 0.5, 100.001, 1.5e300]",
        "null",
        "[\n  1,\n  1,\n  100,\n  100,\n  0.01,\n  0,\n  0.5,\n  100.001,\n  1.5e+300\n]\n",
    ),
    # overflow clamps to the maximum float64 instead of erroring
    ("1e1000", "null", "1.7976931348623157e+308\n"),
    ("0.1+0.2", "null", "0.30000000000000004\n"),
    ("3.14 | tostring", "null", '"3.14"\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), NUMBER_CASES)
def test_number_literals(run_gojq, query, stdin, expected):
    """Integers, decimals and exponents all parse; 1.0 prints as 1."""
    # CATCHES: '1.0' normalizes to 1, exponents decode ('1e-2' to 0.01) and
    # print back in Go's shortest form ('1.5e+300'), and overflow clamps to
    # the float64 maximum rather than being a syntax error.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        ("1e+", 'gojq: invalid query: 1e+\n    1e+\n    ^  invalid token "1e+"\n'),
        ("1e", 'gojq: invalid query: 1e\n    1e\n    ^  invalid token "1e"\n'),
    ],
)
def test_number_edge_forms(run_gojq, query, expected_stderr):
    """'.' may lead or trail a number; an exponent needs digits."""
    # CATCHES: '.5', '1.' and '1.e5' all parse as numbers (leading zeros
    # are fine too) while a bare exponent sign or missing digits lex to an
    # 'invalid token' report rather than an unexpected token.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query

    for query, expected in [
        (".5", "0.5\n"),
        ("1.", "1\n"),
        ("1.e5", "100000\n"),
        ("00.5", "0.5\n"),
    ]:
        proc = run_gojq([query])
        assert proc.returncode == 0, query
        assert proc.stdout == expected, query
        assert proc.stderr == "", query


def test_unary_minus_vs_subtraction(run_gojq):
    """Unary minus and subtraction disambiguate by context."""
    # CATCHES: '.a -1' and '.x-1' are subtractions (a path glued to '-1'),
    # '- -1' applies unary minus twice, and '-"x"' fails at runtime not at
    # parse time because negation is checked when the query runs.
    cases = [
        (".a -1", '{"a":1}', "0\n"),
        (".x-1", '{"x":10}', "9\n"),
        ("[1,2] | .[0] - .[1]", "null", "-1\n"),
        ("- -1", "null", "1\n"),
        ("[-1, - 1, -1 + 2, 1 - -1]", "null", "[\n  -1,\n  -1,\n  1,\n  2\n]\n"),
    ]
    for query, stdin, expected in cases:
        proc = run_gojq([query], input_text=stdin)
        assert proc.returncode == 0, query
        assert proc.stdout == expected, query

    proc = run_gojq(['-"x"'])
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: cannot negate: string ("x")\n'


FORMAT_CASES = [
    ('@html', '"<b>&"', '"&lt;b&gt;&amp;"\n'),
    ('@uri', '"a b/c?d=e"', '"a%20b%2Fc%3Fd%3De"\n'),
    ("@sh", '"it\'s"', "\"'it'\\\\''s'\"\n"),
    ('@base64', '"abc"', '"YWJj"\n'),
    ('@base64d', '"YWJj"', '"abc"\n'),
    # a format applied to an interpolated string formats each part
    ('@base64 "\\(.)"', '"ab"', '"YWI="\n'),
    # a literal '@json' inside the string body is not a format application
    ('@text "\\(1) @json"', "null", '"1 @json"\n'),
    # '?' suffixes a format term just like any other term
    ("@base64?", "null", '"bnVsbA=="\n'),
    # '@text' passes the string through; printing re-escapes the newline
    ('@text', '"a\\nb"', '"a\\nb"\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), FORMAT_CASES)
def test_format_strings(run_gojq, query, stdin, expected):
    """@format tokens alone and applied to interpolated strings parse."""
    # CATCHES: '@base64 "\\(.)"' applies the format to the interpolated
    # value, while a bare '@json' inside the literal text stays text, and
    # '@base64?' shows '?' may suffix a format term.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        ("@", 'gojq: invalid query: @\n    @\n    ^  unexpected token "@"\n'),
        (
            "@base64 @base64",
            'gojq: invalid query: @base64 @base64\n    @base64 @base64\n            ^  unexpected token "@base64"\n',
        ),
        (
            '[1] | @text?"x"',
            'gojq: invalid query: [1] | @text?"x"\n    [1] | @text?"x"\n                ^  unexpected token "\\"x\\""\n',
        ),
        ("@text 1", 'gojq: invalid query: @text 1\n    @text 1\n          ^  unexpected token "1"\n'),
        (
            '@base64 "\\("',
            'gojq: invalid query: @base64 "\\("\n    @base64 "\\("\n                ^  unterminated string literal\n',
        ),
    ],
)
def test_format_syntax_errors(run_gojq, query, expected_stderr):
    """A format must be followed by a string literal, not a bare term."""
    # CATCHES: '@text 1' rejects a number after the format, '@' alone is an
    # unexpected token, and two formats in a row blame the second one.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


def test_unknown_format_is_runtime_error(run_gojq):
    """An undefined @format name parses; the failure happens at runtime."""
    # CATCHES: the lexer accepts any '@word', so '@foo' is not a syntax
    # error — it exits 5 with 'format not defined' only when evaluated.
    proc = run_gojq(["@foo"])
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: format not defined: @foo\n"


OBJECT_CASES = [
    ('{a: 1, "b": 2, c: {d: 4}}', "null", '{\n  "a": 1,\n  "b": 2,\n  "c": {\n    "d": 4\n  }\n}\n'),
    # {foo} copies the .foo field; {a} likewise
    ("{foo}", '{"foo":9}', '{\n  "foo": 9\n}\n'),
    ("{a}", '{"a":1,"b":2}', '{\n  "a": 1\n}\n'),
    # interpolated string keys are allowed
    ('{"\\(1)": 2}', "null", '{\n  "1": 2\n}\n'),
    # a trailing comma is legal inside objects
    ("{a: 1,}", "null", '{\n  "a": 1\n}\n'),
    # every reserved word is accepted as a key
    (
        "{if: 1, then: 2, else: 3, end: 4}",
        "null",
        '{\n  "else": 3,\n  "end": 4,\n  "if": 1,\n  "then": 2\n}\n',
    ),
    (
        "{and: 1, as: 2, def: 3, reduce: 4, foreach: 5, try: 6, catch: 7,"
        " label: 8, import: 9, include: 10}",
        "null",
        '{\n  "and": 1,\n  "as": 2,\n  "catch": 7,\n  "def": 3,\n  "foreach": 5,\n'
        '  "import": 9,\n  "include": 10,\n  "label": 8,\n  "reduce": 4,\n  "try": 6\n}\n',
    ),
    ("{null: 1, true: 2, false: 3}", "null", '{\n  "false": 3,\n  "null": 1,\n  "true": 2\n}\n'),
    ('[.[] | {(.k): .v}]', '[{"k":"a","v":1}]', '[\n  {\n    "a": 1\n  }\n]\n'),
    ("{'a': 1}", "null", None),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), OBJECT_CASES)
def test_object_construction_forms(run_gojq, query, stdin, expected):
    """Object keys: idents, keywords, strings, interpolations, queries."""
    # CATCHES: keywords and null/true/false are plain keys, '{foo}' is
    # shorthand, a trailing comma is allowed, but single quotes are not
    # string delimiters ('{\'a\': 1}' is a parse error).
    proc = run_gojq([query], input_text=stdin)
    if expected is None:
        assert proc.returncode == 3, query
        assert proc.stdout == "", query
        assert proc.stderr == (
            "gojq: invalid query: {'a': 1}\n    {'a': 1}\n     ^  unexpected token \"'\"\n"
        ), query
    else:
        assert proc.returncode == 0, query
        assert proc.stdout == expected, query
        assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        ("{a: }", 'gojq: invalid query: {a: }\n    {a: }\n        ^  unexpected token "}"\n'),
        ("{,}", 'gojq: invalid query: {,}\n    {,}\n     ^  unexpected token ","\n'),
        ("{a: 1 b: 2}", 'gojq: invalid query: {a: 1 b: 2}\n    {a: 1 b: 2}\n          ^  unexpected token "b"\n'),
        ("{@base64: 1}", 'gojq: invalid query: {@base64: 1}\n    {@base64: 1}\n     ^  unexpected token "@base64"\n'),
        ("{1: 2}", 'gojq: invalid query: {1: 2}\n    {1: 2}\n     ^  unexpected token "1"\n'),
        ("{a 1}", 'gojq: invalid query: {a 1}\n    {a 1}\n       ^  unexpected token "1"\n'),
    ],
)
def test_object_construction_errors(run_gojq, query, expected_stderr):
    """Bad object entries report the offending token."""
    # CATCHES: formats and bare numbers cannot be keys, a value cannot be
    # omitted before '}', and a missing comma blames the next key.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


ARRAY_CASES = [
    ("[[1], [2]]", "null", "[\n  [\n    1\n  ],\n  [\n    2\n  ]\n]\n"),
    ("[1 | 2, 3]", "null", "[\n  2,\n  3\n]\n"),
    ("[]", "null", "[]\n"),
    ('["ab"[0], .[1]]', "[5,6]", '[\n  "a",\n  6\n]\n'),
    ("[.[] | select(. > 1)]", "[1,2,3]", "[\n  2,\n  3\n]\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), ARRAY_CASES)
def test_array_construction(run_gojq, query, stdin, expected):
    """Arrays collect a whole query; terms may carry suffixes inside."""
    # CATCHES: '[1 | 2, 3]' collects the piped comma expression, and
    # '"ab"[0]' indexes a string literal inside an array.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        ("[1, 2,]", 'gojq: invalid query: [1, 2,]\n    [1, 2,]\n          ^  unexpected token "]"\n'),
        ("[,1]", 'gojq: invalid query: [,1]\n    [,1]\n     ^  unexpected token ","\n'),
        ("[1; 2]", 'gojq: invalid query: [1; 2]\n    [1; 2]\n      ^  unexpected token ";"\n'),
    ],
)
def test_array_construction_errors(run_gojq, query, expected_stderr):
    """Arrays reject trailing commas, leading commas and semicolons."""
    # CATCHES: unlike objects, a trailing comma before ']' is a parse error
    # in arrays, and ';' is not a separator.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


def test_boolean_and_comparison_operators(run_gojq):
    """and/or/not and the comparison operators parse at their precedence."""
    # CATCHES: '1 and 2' truthiness uses the values themselves, 'not' is
    # a zero-arity function invoked through a pipe, and the six comparison
    # operators parse between arbitrary terms.
    proc = run_gojq(["true and false, true or false, (true | not)"])
    assert proc.returncode == 0
    assert proc.stdout == "false\ntrue\nfalse\n"

    proc = run_gojq(["1 and 2"])
    assert proc.returncode == 0
    assert proc.stdout == "true\n"

    proc = run_gojq(['"a" == "a", 1 != 2, 1 < 2, 2 <= 2, 3 > 4, 4 >= 4'])
    assert proc.returncode == 0
    assert proc.stdout == "true\ntrue\ntrue\ntrue\nfalse\ntrue\n"
