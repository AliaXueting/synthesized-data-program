"""Tests for control-flow syntax: if/elif/else, try/catch, reduce, foreach.

These pin the grammar of the block constructs and the exact 'unexpected
token' / 'unexpected EOF' reports for malformed variants, including which
token is blamed when a clause separator is wrong.
"""

import pytest

IF_CASES = [
    ("if . then 1 else 2 end", "true", "1\n"),
    ("if . then 1 elif false then 2 elif true then 3 else 4 end", "false", "3\n"),
    # 'else' is optional: a false condition returns the input unchanged
    ("if . then 1 end", "false", "false\n"),
    ("if .a then 1 else 2 end", "null", "2\n"),
    ("if 1 then 2 else 3 end", "null", "2\n"),
    (
        '[.[] | if . > 1 then "big" else "small" end]',
        "[0,1,2]",
        '[\n  "small",\n  "small",\n  "big"\n]\n',
    ),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), IF_CASES)
def test_if_forms(run_gojq, query, stdin, expected):
    """if/then/elif/else/end parses with optional else and any cond type."""
    # CATCHES: else is optional (a false condition yields the input), elif
    # chains repeat, and the condition may be any term, not just a path.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        ("if", 'gojq: invalid query: if\n    if\n      ^  unexpected EOF\n'),
        (
            "if . then 1",
            'gojq: invalid query: if . then 1\n    if . then 1\n               ^  unexpected EOF\n',
        ),
        (
            "if . then end",
            'gojq: invalid query: if . then end\n    if . then end\n              ^  unexpected token "end"\n',
        ),
        (
            "if . then 1 else 2 elif 3 then 4 end",
            "gojq: invalid query: if . then 1 else 2 elif 3 then 4 end\n"
            "    if . then 1 else 2 elif 3 then 4 end\n"
            '                       ^  unexpected token "elif"\n',
        ),
    ],
)
def test_if_syntax_errors(run_gojq, query, expected_stderr):
    """Malformed if chains report EOF or the offending keyword token."""
    # CATCHES: 'elif' after 'else' is rejected (it blames the 'elif' token,
    # not 'end'), and 'if . then end' blames 'end' for the missing body.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


TRY_CASES = [
    ('try error("x") catch .', "null", '"x"\n'),
    # 'catch' is optional: the error is swallowed and the try yields nothing
    ('[try error("x")]', "null", "[]\n"),
    ("[.[] | try error(.) catch .]", "[1,2]", "[\n  1,\n  2\n]\n"),
    # try applies to a full query producing multiple outputs
    ("try (1,2) catch .", "null", "1\n2\n"),
    # the catch body is a full query and 'error' is a plain term here
    ("try error catch . + 1", "null", "1\n"),
    ('[.[] | .a?]', '[1,{"a":3}]', "[\n  3\n]\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), TRY_CASES)
def test_try_catch_forms(run_gojq, query, stdin, expected):
    """try/catch with optional catch and postfix '?' suppress errors."""
    # CATCHES: 'try error catch . + 1' parses 'error' as the try body (a
    # zero-arity call), so the catch adds 1 to the caught value.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        (
            '[try error("a") catch .?"x"]',
            'gojq: invalid query: [try error("a") catch .?"x"]\n'
            '    [try error("a") catch .?"x"]\n'
            '                            ^  unexpected token "\\"x\\""\n',
        ),
        ("try 1 +", 'gojq: invalid query: try 1 +\n    try 1 +\n           ^  unexpected EOF\n'),
    ],
)
def test_try_syntax_errors(run_gojq, query, expected_stderr):
    """The postfix '?' binds tighter than a following string token."""
    # CATCHES: in '.?"x"' the '?' suffix attaches to '.' so the string
    # literal becomes an unexpected token; 'try' still swallows a whole
    # pipe expression so 'try 1 +' runs to EOF.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


REDUCE_CASES = [
    ("reduce .[] as $x (0; . + $x)", "[1,2,3]", "6\n"),
    # an empty source leaves the initial value untouched
    ("reduce empty as $x (0; .)", "null", "0\n"),
    # destructuring patterns bind inside reduce
    ("reduce .[] as [$a, $b] ([]; . + [$a + $b])", "[[1,2],[3,4]]", "[\n  3,\n  7\n]\n"),
    ("reduce .[] as $x (100; . - $x)", "[1,2,3]", "94\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), REDUCE_CASES)
def test_reduce_forms(run_gojq, query, stdin, expected):
    """reduce TERM as PATTERN (init; update) parses patterns and terms."""
    # CATCHES: the reduce source may be any term ('empty' keeps the init)
    # and the pattern may destructure arrays before the '(' init/update ')'.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        (
            "reduce .[] as [$a, $b] ({u:0;}); .",
            "gojq: invalid query: reduce .[] as [$a, $b] ({u:0;}); .\n"
            "    reduce .[] as [$a, $b] ({u:0;}); .\n"
            '                                ^  unexpected token ";"\n',
        ),
        (
            "reduce .[] as $x (0; . + $x; . * 2)",
            "gojq: invalid query: reduce .[] as $x (0; . + $x; . * 2)\n"
            "    reduce .[] as $x (0; . + $x; . * 2)\n"
            '                               ^  unexpected token ";"\n',
        ),
        (
            "reduce .[] as $x (0;)",
            "gojq: invalid query: reduce .[] as $x (0;)\n"
            "    reduce .[] as $x (0;)\n"
            '                        ^  unexpected token ")"\n',
        ),
        (
            "foreach .[] as $x (0)",
            "gojq: invalid query: foreach .[] as $x (0)\n"
            "    foreach .[] as $x (0)\n"
            '                        ^  unexpected token ")"\n',
        ),
    ],
)
def test_reduce_foreach_arity_errors(run_gojq, query, expected_stderr):
    """reduce takes exactly two parenthesized parts; foreach two or three."""
    # CATCHES: a third ';'-separated part is rejected for reduce but is
    # exactly what foreach's extract clause is, and a missing update after
    # ';' blames the closing paren.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


FOREACH_CASES = [
    ("foreach .[] as $x (0; . + $x)", "[1,2,3]", "1\n3\n6\n"),
    (
        "foreach .[] as $x (0; . + $x; [$x, .])",
        "[1,2]",
        "[\n  1,\n  1\n]\n[\n  2,\n  3\n]\n",
    ),
    (
        "foreach .[] as $x (null; .x = $x)",
        "[1,2]",
        '{\n  "x": 1\n}\n{\n  "x": 2\n}\n',
    ),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), FOREACH_CASES)
def test_foreach_forms(run_gojq, query, stdin, expected):
    """foreach emits every state, with an optional extract expression."""
    # CATCHES: without an extract clause foreach outputs each intermediate
    # state; with one, it outputs the extract applied to each state.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


LABEL_CASES = [
    ("label $out | 1, break $out, 2", "null", "1\n"),
    ("[label $out | .[] | if . > 1 then break $out else . end]", "[1,2,3]", "[\n  1\n]\n"),
    # breaking the outer label from inside an inner one discards the rest of
    # both label bodies, while breaking the inner label resumes the outer one
    ("[label $a | (label $b | 1, break $a, 2), 3]", "null", "[\n  1\n]\n"),
    ("[label $a | (label $b | 1, break $b, 2), 3]", "null", "[\n  1,\n  3\n]\n"),
    ("first( label $o | .[] | if .==2 then break $o else . end )", "[1,2,3]", "1\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), LABEL_CASES)
def test_label_and_break(run_gojq, query, stdin, expected):
    """label $name binds a target that break $name unwinds to."""
    # CATCHES: 'break $a' inside a nested 'label $b' unwinds the outer
    # label, and everything after 'break' in the label body is skipped.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


def test_label_break_undefined(run_gojq):
    """break without a matching label is a compile error, not a parse one."""
    # CATCHES: 'label $out' without a pipe reports EOF at the parse level,
    # while a syntactically fine 'break $x' with no label in scope fails
    # compilation with 'label not defined'.
    proc = run_gojq(["label $out"])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: invalid query: label $out\n    label $out\n              ^  unexpected EOF\n'

    proc = run_gojq(["break $out"])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == "gojq: compile error: label not defined: $out\n"

    proc = run_gojq(["label $out | break $x"])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == "gojq: compile error: label not defined: $x\n"
