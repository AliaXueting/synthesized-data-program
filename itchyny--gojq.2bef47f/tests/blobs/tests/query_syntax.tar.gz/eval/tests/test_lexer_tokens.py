"""Tests for lexer tokenization corners reachable from the CLI.

These pin the hand-written lexer's number scanning (bad tokens reported as
one span), multibyte identifier tokens, the '::' module-qualified name scan,
the number grammar reused by tonumber, the variable-name check behind
--arg, raw control characters inside string literals, and the backslash
line-continuation of comments across CRLF line endings.
"""

import pytest

INVALID_NUMBER_CASES = [
    (
        ".1.",
        'gojq: invalid query: .1.\n    .1.\n    ^  invalid token ".1."\n',
    ),
    (
        "1.2.3",
        'gojq: invalid query: 1.2.3\n    1.2.3\n    ^  invalid token "1.2."\n',
    ),
    (
        "1ex",
        'gojq: invalid query: 1ex\n    1ex\n    ^  invalid token "1ex"\n',
    ),
    (
        "1e2x",
        'gojq: invalid query: 1e2x\n    1e2x\n    ^  invalid token "1e2x"\n',
    ),
    (
        ".1e",
        'gojq: invalid query: .1e\n    .1e\n    ^  invalid token ".1e"\n',
    ),
]


@pytest.mark.parametrize(("query", "expected_stderr"), INVALID_NUMBER_CASES)
def test_invalid_number_tokens(run_gojq, query, expected_stderr):
    """Malformed numbers are reported as one 'invalid token' span."""
    # CATCHES: a number that starts with '.' or keeps scanning past a bad
    # exponent is reported as a single 'invalid token' covering the whole
    # scanned span ("1.2.", "1e2x") with the caret at the token start, not
    # split into a valid prefix plus a separate unexpected token.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


MULTIBYTE_CASES = [
    (
        "あ",
        'gojq: invalid query: あ\n    あ\n    ^  unexpected token "あ"\n',
    ),
    (
        ". あ",
        'gojq: invalid query: . あ\n    . あ\n      ^  unexpected token "あ"\n',
    ),
    (
        '"あ',
        'gojq: invalid query: "あ\n    "あ\n       ^  unterminated string literal\n',
    ),
]


@pytest.mark.parametrize(("query", "expected_stderr"), MULTIBYTE_CASES)
def test_multibyte_token_errors(run_gojq, query, expected_stderr):
    """Multibyte input forms whole tokens and carets follow display columns."""
    # CATCHES: a multibyte rune lexes as an identifier token the parser
    # then rejects as 'unexpected token "あ"' with the caret placed under
    # the rune (column 3 of '. あ', not byte 3), and an unterminated string
    # ending in a valid multibyte rune keeps that rune in the echoed line
    # with the caret one display column past it.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


DOUBLE_COLON_CASES = [
    (
        "foo::1",
        'gojq: invalid query: foo::1\n    foo::1\n       ^  unexpected token ":"\n',
    ),
    (
        "$x::1",
        'gojq: invalid query: $x::1\n    $x::1\n      ^  unexpected token ":"\n',
    ),
    # with a full identifier after '::' the whole thing is one token, which
    # then fails to resolve as a variable at compile time
    ("$a::b", "gojq: compile error: variable not defined: $a::b\n"),
    ("1 as $x | $x::y", "gojq: compile error: variable not defined: $x::y\n"),
]


@pytest.mark.parametrize(("query", "expected_stderr"), DOUBLE_COLON_CASES)
def test_module_ident_double_colon(run_gojq, query, expected_stderr):
    """'::' only lexes as a module qualifier when an identifier follows."""
    # CATCHES: the lexer scans 'foo::bar' as one module-qualified name only
    # when a full identifier follows '::'; after 'foo::1' it backs the scan
    # out and the first ':' becomes the unexpected token, while '$a::b'
    # does lex as a single variable name that then fails compilation with
    # 'variable not defined: $a::b' (not a parse error).
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


TONUMBER_OK_CASES = [
    ('".5" | tonumber', "0.5\n"),
    ('"1." | tonumber', "1\n"),
    ('"+2" | tonumber', "2\n"),
    ('"-1.5e3" | tonumber', "-1500\n"),
]


@pytest.mark.parametrize(("query", "expected"), TONUMBER_OK_CASES)
def test_tonumber_accepts_lexer_number_forms(run_gojq, query, expected):
    """tonumber accepts the lexer's number grammar, not just JSON's."""
    # CATCHES: tonumber validates through the lexer's number scanner, so
    # forms a strict JSON parser would reject — a leading '.', a trailing
    # '.', a leading '+' — all convert, and exponents apply.
    proc = run_gojq([query])
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


TONUMBER_BAD_CASES = [
    ('"x" | tonumber', 'gojq: tonumber cannot be applied to "x": invalid number\n'),
    ('"1.2.3" | tonumber', 'gojq: tonumber cannot be applied to "1.2.3": invalid number\n'),
    ('"1e" | tonumber', 'gojq: tonumber cannot be applied to "1e": invalid number\n'),
    ('"" | tonumber', 'gojq: tonumber cannot be applied to "": invalid number\n'),
    ('" 1" | tonumber', 'gojq: tonumber cannot be applied to " 1": invalid number\n'),
]


@pytest.mark.parametrize(("query", "expected_stderr"), TONUMBER_BAD_CASES)
def test_tonumber_rejects_non_numbers(run_gojq, query, expected_stderr):
    """Strings that are not a single lexer number fail tonumber at run time."""
    # CATCHES: letters, doubled dots, a bare exponent, an empty string and
    # surrounding whitespace all report 'invalid number' with the input
    # string JSON-quoted in the message, at exit 5.
    proc = run_gojq([query])
    assert proc.returncode == 5, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


ARG_NAME_CASES = [
    (["--arg", "foo", "1", "$foo"], 0, '"1"\n', ""),
    (["--arg", "1x", "v", "."], 3, "", "gojq: compile error: invalid variable name: $1x\n"),
    (["--arg", "a-b", "v", "$a-b"], 3, "", "gojq: compile error: invalid variable name: $a-b\n"),
]


@pytest.mark.parametrize(("args", "expected_rc", "expected_stdout", "expected_stderr"), ARG_NAME_CASES)
def test_arg_variable_names(run_gojq, args, expected_rc, expected_stdout, expected_stderr):
    """--arg names go through the lexer's variable-name validation."""
    # CATCHES: a valid --arg name binds $foo as a string even in a query
    # that only mentions it, while names that are not identifiers ('1x',
    # 'a-b') fail compilation with 'invalid variable name: $1x' before the
    # query body is analyzed.
    proc = run_gojq(args)
    assert proc.returncode == expected_rc, args
    assert proc.stdout == expected_stdout, args
    assert proc.stderr == expected_stderr, args


RAW_TAB_CASES = [
    ('"☆\tb"', '"☆\\tb"\n'),
    ('"☆\t\\(1)"', '"☆\\t1"\n'),
]


@pytest.mark.parametrize(("query", "expected"), RAW_TAB_CASES)
def test_raw_tab_in_string_literals(run_gojq, query, expected):
    """A raw TAB byte inside a string literal is kept and re-escaped."""
    # CATCHES: the string scanner accepts a literal control character (and
    # a multibyte rune) inside a quoted literal, and the JSON encoder
    # re-escapes the tab as '\t' on output — also inside an interpolation.
    proc = run_gojq([query])
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


COMMENT_CRLF_CASES = [
    # the backslash continues the comment across the CRLF, so '+ 99' is
    # swallowed and the query is just '1'
    (b"1 # c\\\r\n+ 99\n", "1\n"),
    # without the backslash the CR ends the comment and '+ 99' runs as code
    (b"1 # c\r\n+ 99\n", "100\n"),
]


@pytest.mark.parametrize(("contents", "expected"), COMMENT_CRLF_CASES)
def test_comment_backslash_crlf_continuation(query_file, contents, expected):
    """A trailing backslash continues a comment line across CRLF."""
    # CATCHES: inside a comment a backslash before the line ending makes
    # the comment continue on the next line even when the ending is the
    # two-byte CRLF pair ('+ 99' disappears from the query); without the
    # backslash the CR terminates the comment and the next line is code.
    proc = query_file(contents, binary=True)
    assert proc.returncode == 0, contents
    assert proc.stdout == expected, contents
    assert proc.stderr == "", contents
