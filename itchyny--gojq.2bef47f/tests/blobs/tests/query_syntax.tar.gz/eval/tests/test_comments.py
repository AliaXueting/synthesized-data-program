"""Tests for '#' comments inside queries.

These pin that a comment runs from '#' to the end of the line (or the end
of the query when there is no newline), may contain any characters
including quotes and braces, and may appear between any two tokens --
inside objects, arrays, parens, def bodies and reduce clauses.
"""

import pytest

COMMENT_CASES = [
    (". # trailing comment", "null", "null\n"),
    # quotes and braces inside a comment are not tokenized
    ('. # comment with "quote and {brace', "null", "null\n"),
    # a comment ends at the newline; the query continues on the next line
    (".a # c\n.b", '{"a":{"b":1}}', "1\n"),
    # a '#' at the very end of the query with no trailing newline is fine
    (". #", "null", "null\n"),
    # a whole line may be a comment
    ("1 # one\n# two\n+ 2", "null", "3\n"),
    ('{"a": 1 # c\n}', "null", '{\n  "a": 1\n}\n'),
    ("(1 # c\n)", "null", "1\n"),
    ("[1 # c\n, 2]", "null", "[\n  1,\n  2\n]\n"),
    ("def f: 1; # c\nf", "null", "1\n"),
    ("reduce .[] as $x (0 # c\n; . + $x)", "[1,2]", "3\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), COMMENT_CASES)
def test_comments_between_tokens(run_gojq, query, stdin, expected):
    """Comments run to end-of-line and may sit between any two tokens."""
    # CATCHES: the comment text may contain '"' and '{' without ending the
    # comment, an unterminated comment at end of input is accepted, and
    # comments are legal inside object/array/def/reduce constructions.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


def test_comment_only_query_is_missing_query(run_gojq):
    """A query consisting solely of a comment has no term to parse."""
    # CATCHES: the lexer produces zero tokens so the parser is never
    # invoked; the failure is the 'missing query' compile error.
    proc = run_gojq(["# only comment"])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: compile error: missing query (try ".")\n'


def test_comment_backslash_continuation(run_gojq):
    """A comment ending in one backslash swallows the next line."""
    # CATCHES: '# ...\' continues the comment across the newline so the
    # following '+ 2' is comment text, while '\\\\\n' is an escaped
    # backslash that does NOT continue, leaving '+ 2' as query text.
    proc = run_gojq(["1 # c\\\n+ 2"])
    assert proc.returncode == 0
    assert proc.stdout == "1\n"
    assert proc.stderr == ""

    proc = run_gojq(["1 # c\\\\\n+ 2"])
    assert proc.returncode == 0
    assert proc.stdout == "3\n"
    assert proc.stderr == ""
