"""Tests for how index and slice expressions become update paths.

These pin the grammar's '.[e]' / '.[s:e]' index expressions when they are used
as paths: negative and unary indices ('.[-1]', '.[+1]', '.[- -1]'), fractional
and out-of-range number keys, empty-string keys ('.[""]', '.""'), and the
path arrays the 'path' builtin reports for them ('[{"end":2,"start":1}]' for
a slice).  They also pin the update semantics those paths produce through
'=', '|=' and 'del' (negative slices, inverted and empty slices inserting,
fractional bounds flooring) and the exact 'setpath([...]; v)' runtime error
text for the failing variants.
"""

import pytest

NEG_UNARY_INDEX_CASES = [
    # a negative constant index addresses the last element
    ("[1,2,3] | .[-1] = 9", "null", "[\n  1,\n  2,\n  9\n]\n"),
    # negating zero normalizes to index 0, not -0
    ("[1,2] | .[-0] = 9", "null", "[\n  9,\n  2\n]\n"),
    # unary plus is accepted inside an index and leaves the number alone
    ("[1,2,3] | .[+1] = 9", "null", "[\n  1,\n  9,\n  3\n]\n"),
    ("[1,2,3] | .[-2]", "null", "2\n"),
    ("null | .[0] = 9", "null", "[\n  9\n]\n"),
    # '.[+1]' on null pads one null before the value, like '.[1]'
    ("null | .[+1] = 9", "null", "[\n  null,\n  9\n]\n"),
    # negative indices work nested at any depth of a constant path
    ('{"a":[1,2,3]} | .a[-1] = 9', "null", '{\n  "a": [\n    1,\n    2,\n    9\n  ]\n}\n'),
    (
        '{"a":{"b":[1,2]}} | .a.b[-1] = 9',
        "null",
        '{\n  "a": {\n    "b": [\n      1,\n      9\n    ]\n  }\n}\n',
    ),
    # double unary is one index expression: -(-1) is 1
    ("[1,2,3] | .[- -1]", "null", "2\n"),
    ("[1,2,3] | .[- -1] = 9", "null", "[\n  1,\n  9,\n  3\n]\n"),
    ("null | .[- -1] = 9", "null", "[\n  null,\n  9\n]\n"),
    # a parenthesized unary is still a single index expression: -(1) is -1
    ("[1,2,3] | .[-(1)] = 9", "null", "[\n  1,\n  2,\n  9\n]\n"),
    # the index may be computed from the input itself
    ("[1,2,3] | .[-.[1]]", "null", "2\n"),
    # a variable index keeps the update path-based
    ("1 as $x | [10,20,30] | .[$x] = 9", "null", "[\n  10,\n  9,\n  30\n]\n"),
    # two assignments separated by a comma each update the original input
    ("[1,2,3] | .[-1] = 9, .[0] = 8", "null", "[\n  1,\n  2,\n  9\n]\n[\n  8,\n  2,\n  3\n]\n"),
    # a fractional index floors towards zero on read
    ("[1,2,3] | .[0.5]", "null", "1\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), NEG_UNARY_INDEX_CASES)
def test_negative_and_unary_index_paths(run_gojq, query, stdin, expected):
    """Unary '+'/'-' and negative numbers are valid index expressions."""
    # CATCHES: the index grammar accepts unary minus and plus ('.[-1]',
    # '.[+1]', '.[- -1]', '.[-(1)]', '.[-.[1]]'), negated zero normalizes to
    # index 0, and negative indices address from the end on every update.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


HUGE_INDEX_ERROR_CASES = [
    (
        "null | .[-1] = 9",
        "gojq: setpath([-1]; 9) cannot be applied to null:"
        " array index should not be negative: -1\n",
    ),
    (
        "null | .[1e100] = 1",
        "gojq: setpath([1e+100]; 1) cannot be applied to null:"
        " array index too large: 9223372036854775807\n",
    ),
    (
        "null | .[-1e100] = 1",
        "gojq: setpath([-1e+100]; 1) cannot be applied to null:"
        " array index should not be negative: -9223372036854775808\n",
    ),
    (
        "null | .[+1e100] = 9",
        "gojq: setpath([1e+100]; 9) cannot be applied to null:"
        " array index too large: 9223372036854775807\n",
    ),
]


@pytest.mark.parametrize(("query", "expected_stderr"), HUGE_INDEX_ERROR_CASES)
def test_index_path_errors_on_null(run_gojq, query, expected_stderr):
    """Updating null through a bad numeric index fails with setpath text."""
    # CATCHES: a negative index against null is rejected (unlike against an
    # array), and huge float indices clamp to the int64 extremes inside the
    # setpath error: MaxInt64 for 'too large', MinInt64 for 'negative'.
    proc = run_gojq([query], input_text="null")
    assert proc.returncode == 5, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


def test_index_expression_type_errors(run_gojq):
    """Ill-typed index expressions fail at their own operation first."""
    # CATCHES: '.[-"a"]' negates the string before indexing, a fractional
    # index on an object is an array-style index, and null/boolean keys in an
    # assignment against null still demand a string object key.
    cases = [
        ("[1,2,3] | .[-\"a\"]", 'gojq: cannot negate: string ("a")\n'),
        ('{"a":1} | .[0.5]', 'gojq: expected an array but got: object ({"a":1})\n'),
        ("null | .[null] = 1", "gojq: expected a string for object key but got: null\n"),
        (
            "null | .[true] = 1",
            "gojq: expected a string for object key but got: boolean (true)\n",
        ),
    ]
    for query, expected_stderr in cases:
        proc = run_gojq([query], input_text="null")
        assert proc.returncode == 5, query
        assert proc.stdout == "", query
        assert proc.stderr == expected_stderr, query


EMPTY_KEY_CASES = [
    ('.[""] = 1', "null", '{\n  "": 1\n}\n'),
    ('."" = 1', "null", '{\n  "": 1\n}\n'),
    # a space between '.' and the quoted key still parses as one suffix
    ('. "" = 1', "null", '{\n  "": 1\n}\n'),
    ('{"": {"": 2}} | ."".""', "null", "2\n"),
    ('{"a":{}} | .a[""] = 1', "null", '{\n  "a": {\n    "": 1\n  }\n}\n'),
    ('path(.[""])', "null", '[\n  ""\n]\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), EMPTY_KEY_CASES)
def test_empty_string_keys(run_gojq, query, stdin, expected):
    """The empty string is a legal field key in every access form."""
    # CATCHES: '.[""]', '.""' and '. ""' all build the constant key "" (not a
    # missing-name default), so updates create an "" entry and chained empty
    # keys keep walking; 'path' echoes the empty-string key verbatim.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


PATH_BUILTIN_CASES = [
    ('{"a":[1]} | path(.a[0])', '[\n  "a",\n  0\n]\n'),
    # a slice path is the {"start":..,"end":..} object, keys sorted on output
    ('path(.[1:2])', '[\n  {\n    "end": 2,\n    "start": 1\n  }\n]\n'),
    ("path(.[-1])", "[\n  -1\n]\n"),
    ("path(.[-0])", "[\n  0\n]\n"),
    # a float index survives into the path array without flooring
    ("path(.[1e100])", "[\n  1e+100\n]\n"),
    # '?' inside a path expression does not interrupt path enumeration
    ("path(.a?.b)", '[\n  "a",\n  "b"\n]\n'),
    ('{"a":[1,2]} | path(.a[-1])', '[\n  "a",\n  -1\n]\n'),
    # computed keys enumerate their runtime value as a path
    ('{"ab":1} | path(.["a"+"b"])', '[\n  "ab"\n]\n'),
]


@pytest.mark.parametrize(("query", "expected"), PATH_BUILTIN_CASES)
def test_path_builtin_reports_index_paths(run_gojq, query, expected):
    """'path' prints the exact key array an index expression denotes."""
    # CATCHES: field, numeric (negative, negated-zero, huge float) and slice
    # indexes each produce their literal path element — a slice becomes the
    # {"end":..,"start":..} object — so the reimplementation must fold
    # indexes into the same path arrays, not merely evaluate them.
    proc = run_gojq([query], input_text="null")
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


def test_path_of_iteration_errors(run_gojq):
    """'.[]' inside path() still has to iterate the input."""
    # CATCHES: path() evaluates its argument, so '.[]' against null fails
    # with the iteration error instead of producing a path value.
    proc = run_gojq(["path(.[])"], input_text="null")
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: cannot iterate over: null\n"


SLICE_UPDATE_CASES = [
    # negative bounds count from the end
    ("[1,2,3,4] | .[-2:] = [9]", "null", "[\n  1,\n  2,\n  9\n]\n"),
    ("[1,2,3,4] | .[:-2] = [9]", "null", "[\n  9,\n  3,\n  4\n]\n"),
    ("[1,2,3,4] | .[1:-1] = [9]", "null", "[\n  1,\n  9,\n  4\n]\n"),
    ("[1,2,3] | .[-1:] = [9]", "null", "[\n  1,\n  2,\n  9\n]\n"),
    # an empty replacement deletes the addressed range
    ("[1,2,3] | .[1:-1] = []", "null", "[\n  1,\n  3\n]\n"),
    # inverted and empty ranges insert at the start position
    ("[1,2,3] | .[2:1] = [9]", "null", "[\n  1,\n  2,\n  9,\n  3\n]\n"),
    ("[1,2,3] | .[1:1] = [9]", "null", "[\n  1,\n  9,\n  2,\n  3\n]\n"),
    # fractional bounds floor the start and ceil the end
    ("[1,2,3] | .[1.5:2.5] = [9]", "null", "[\n  1,\n  9\n]\n"),
    ("[1,2,3] | .[1.5:2.5]", "null", "[\n  2,\n  3\n]\n"),
    # strings slice with negative bounds on read
    ('"abcd" | .[-2:]', "null", '"cd"\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), SLICE_UPDATE_CASES)
def test_slice_assignment_semantics(run_gojq, query, stdin, expected):
    """Slice paths update, delete or insert according to their bounds."""
    # CATCHES: negative slice bounds address from the end, an empty
    # replacement array deletes the range, inverted ('.[2:1]') and empty
    # ('.[1:1]') ranges insert at the start bound, and fractional bounds
    # floor the start while ceiling the end ('.[1.5:2.5]' is '[1:3]').
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


SLICE_ERROR_CASES = [
    (
        '"abcd" | .[1:2] = "x"',
        'gojq: setpath([{"end":2,"start":1}]; "x") cannot be applied'
        ' to "abcd": expected an array but got: string ("abcd")\n',
    ),
    (
        '[1,2,3] | .["a":"b"]',
        'gojq: expected a number for indexing an array but got: string ("a")\n',
    ),
    (
        '[1,2,3] | .["a":"b"] = [9]',
        'gojq: setpath([{"end":"b","start":"a"}]; [9]) cannot be applied'
        " to [1,2,3]: expected a number for indexing an array but got:"
        ' string ("a")\n',
    ),
    (
        "null | .[false:false] = 1",
        "gojq: setpath([{\"end\":false,\"start\":false}]; 1) cannot be applied"
        " to null: expected a number for indexing an array but got:"
        " boolean (false)\n",
    ),
]


@pytest.mark.parametrize(("query", "expected_stderr"), SLICE_ERROR_CASES)
def test_slice_path_type_errors(run_gojq, query, expected_stderr):
    """Ill-typed slice operands fail with the slice bounds in the path."""
    # CATCHES: slice paths keep whatever the bounds evaluate to — strings and
    # booleans appear verbatim inside the '{"start":..,"end":..}' path object
    # of the setpath error, and a string input is not an array for updates.
    proc = run_gojq([query], input_text="null")
    assert proc.returncode == 5, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


DEL_UPDATE_CASES = [
    ("[1,2,3,4] | del(.[1:3])", "null", "[\n  1,\n  4\n]\n"),
    ("[1,2,3,4] | del(.[-1])", "null", "[\n  1,\n  2,\n  3\n]\n"),
    ("[1,2,3] | .[-1] |= 9", "null", "[\n  1,\n  2,\n  9\n]\n"),
    ("[1,2,3] | .[1:2] |= [9]", "null", "[\n  1,\n  9,\n  3\n]\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), DEL_UPDATE_CASES)
def test_del_and_update_through_index_paths(run_gojq, query, stdin, expected):
    """'del' and '|=' accept negative indices and slice paths."""
    # CATCHES: 'del(.[1:3])' removes a slice range and 'del(.[-1])' the last
    # element, while '|=' routes the same negative/slice paths through the
    # update — none of these may reject negative or sliced path elements.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


def test_del_with_string_key_on_array_errors(run_gojq):
    """'del' with a string key demands an object, like the read would."""
    # CATCHES: deleting '.["a"]' from an array fails with the object-index
    # error before any deletion happens, exit code 5 with empty stdout.
    proc = run_gojq(['[1,2,3] | del(.["a"])'], input_text="null")
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: expected an object but got: array ([1,2,3])\n"


OPTIONAL_UPDATE_CASES = [
    # '.[]?' updates every element like '.[]'
    ("[1,2] | .[]? = 9", "null", "[\n  9,\n  9\n]\n"),
    # '?' swallows the type error of '.a["b"]' against a number: no update
    ('{"a":1} | .a["b"]? = 9', "null", '{\n  "a": 1\n}\n'),
    # a '?' in the middle of a path does not stop the update
    ('{"a":{"b":1}} | .a?.b = 9', "null", '{\n  "a": {\n    "b": 9\n  }\n}\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), OPTIONAL_UPDATE_CASES)
def test_optional_suffixes_in_update_paths(run_gojq, query, stdin, expected):
    """'?' suffixes are legal inside the left side of an assignment."""
    # CATCHES: '.[]? = 9' still updates every element, a failing optional
    # index ('.a["b"]?' against a number) silently skips the update instead
    # of erroring, and '.a?.b = 9' updates through the optional link.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


def test_format_term_as_index(run_gojq):
    """A '@format' term is a valid index expression, evaluated on the input."""
    # CATCHES: '.[@text]' parses and applies @text to the whole input, so the
    # key looked up is the JSON text of the input itself ('{"null":5}'), not
    # the string "null" — the result is a missing key, i.e. null.
    proc = run_gojq(['{"null":5} | .[@text]'], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "null\n"
    assert proc.stderr == ""
