"""Tests for the parse-error display formats.

These pin the two error layouts: the single-line form for command-line
queries without newlines, and the '<file>:<line>' form with a line-number
gutter for -f files or any query containing a newline (LF or CR), plus the
long-line windowing that keeps the caret within 48 columns of the echo,
and the display and exit code of an uncaught run-time 'error'.
"""

import pytest

FILE_ERROR_CASES = [
    # error on line 2 of a multi-line file
    ("-f", "q.jq", "1 +\n2 +\n", 'gojq: invalid query: q.jq:2\n    2 | 2 +\n           ^  unexpected EOF\n'),
    ("-f", "q.jq", ".a\n.b )\n.c", 'gojq: invalid query: q.jq:2\n    2 | .b )\n           ^  unexpected token ")"\n'),
    # blank lines count: the error is on physical line 4
    ("-f", "q.jq", "\n\n\n.b ~", 'gojq: invalid query: q.jq:4\n    4 | .b ~\n           ^  unexpected token "~"\n'),
    # a single-line file still uses the gutter form because it came from -f
    ("-f", "q.jq", "1 +", 'gojq: invalid query: q.jq:1\n    1 | 1 +\n           ^  unexpected EOF\n'),
    # CRLF line endings: the CR is stripped from the echoed line
    ("-f", "q.jq", "1 +\r\n2 +\r\n", 'gojq: invalid query: q.jq:2\n    2 | 2 +\n           ^  unexpected EOF\n'),
    # bare CR also ends a line
    ("-f", "q.jq", "1 +\r2 +", 'gojq: invalid query: q.jq:2\n    2 | 2 +\n           ^  unexpected EOF\n'),
]


@pytest.mark.parametrize(("flag", "name", "contents", "expected_stderr"), FILE_ERROR_CASES)
def test_multiline_file_error_gutter(run_gojq, tmp_path, flag, name, contents, expected_stderr):
    """-f file errors print 'file:line', the numbered line and a caret."""
    # CATCHES: the gutter is '    2 | <line>' with the caret re-indented
    # under the exact column, blank lines shift the reported line number,
    # and even a single-line -f file uses this form instead of the plain
    # echo.
    (tmp_path / name).write_text(contents, encoding="utf-8", newline="")
    proc = run_gojq([flag, name])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == expected_stderr


ARG_ERROR_CASES = [
    ("1 +\n  * 2", 'gojq: invalid query: <arg>:2\n    2 |   * 2\n          ^  unexpected token "*"\n'),
    ("1 +\r2 +", 'gojq: invalid query: <arg>:2\n    2 | 2 +\n           ^  unexpected EOF\n'),
]


@pytest.mark.parametrize(("query", "expected_stderr"), ARG_ERROR_CASES)
def test_multiline_arg_error(run_gojq, query, expected_stderr):
    """A command-line query containing a newline uses the '<arg>:line' form."""
    # CATCHES: the file slot prints '<arg>' for command-line queries, and
    # both LF and CR inside the query switch to the line-number form.
    proc = run_gojq([query])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == expected_stderr


TRUNCATION_CASES = [
    # 64-char query: the echo drops the front so the caret fits
    (
        ".a" + ".b" * 30 + " ~",
        "gojq: invalid query: .a.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b ~\n"
        "    b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b ~\n"
        '                                                    ^  unexpected token "~"\n',
    ),
    # 80-char query: same 48-column window before the caret
    (
        ".b" * 40 + " ~",
        "gojq: invalid query: " + ".b" * 40 + " ~\n"
        "    b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b.b ~\n"
        '                                                    ^  unexpected token "~"\n',
    ),
    # 100 chars: the window keeps 47 characters before the caret here
    (
        "a" * 100 + " 1",
        "gojq: invalid query: " + "a" * 100 + " 1\n"
        "    " + "a" * 47 + " 1\n"
        '                                                    ^  unexpected token "1"\n',
    ),
]


@pytest.mark.parametrize(("query", "expected_stderr"), TRUNCATION_CASES)
def test_long_line_truncation(run_gojq, query, expected_stderr):
    """The echo of a long line is windowed around the error offset."""
    # CATCHES: the full query still appears in the header, but the echoed
    # line is cut so the caret stays within 48 columns of its start; the
    # caret column itself is unchanged from the untruncated layout.
    proc = run_gojq([query])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == expected_stderr


def test_caret_alignment_with_wide_characters(run_gojq):
    """The caret counts display width, not bytes or runes."""
    # CATCHES: for a query of double-width CJK characters the caret is
    # placed by terminal column width after the truncated window, and the
    # window boundary does not split a multibyte character in half.
    proc = run_gojq(['"日本語日本語日本語日本語日本語日本語日本語日本語日本語日本語日本語" ~'])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == (
        'gojq: invalid query: "日本語日本語日本語日本語日本語日本語日本語日本語日本語日本語日本語" ~\n'
        "    語日本語日本語日本語日本語日本語\" ~\n"
        '                                      ^  unexpected token "~"\n'
    )


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        ("", "gojq: compile error: missing query (try \".\")\n"),
        ("   ", "gojq: compile error: missing query (try \".\")\n"),
        ("#", "gojq: compile error: missing query (try \".\")\n"),
        ("# only comment", "gojq: compile error: missing query (try \".\")\n"),
        ("\t\n ", "gojq: compile error: missing query (try \".\")\n"),
    ],
)
def test_missing_query_errors(run_gojq, query, expected_stderr):
    """An empty, whitespace-only or comment-only query is a compile error."""
    # CATCHES: a query that lexes to zero tokens reports the 'missing
    # query' compile error with the '(try \".\")' hint rather than a parse
    # error, and the command-line query is whitespace-trimmed first.
    proc = run_gojq([query])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == expected_stderr


@pytest.mark.parametrize(
    ("contents", "expected_stderr"),
    [
        ("", "gojq: compile error: missing query (try \".\")\n"),
        (" \n\t ", "gojq: compile error: missing query (try \".\")\n"),
        ("# c", "gojq: compile error: missing query (try \".\")\n"),
        ("module {};", "gojq: compile error: missing query (try \".\")\n"),
        ('module {"a": 1};', "gojq: compile error: missing query (try \".\")\n"),
    ],
)
def test_missing_query_from_file(run_gojq, tmp_path, contents, expected_stderr):
    """-f files with no query body report 'missing query' too."""
    # CATCHES: an empty or comment-only file and a file holding only a
    # 'module' header all produce the missing-query compile error, exit 3.
    (tmp_path / "q.jq").write_text(contents, encoding="utf-8", newline="")
    proc = run_gojq(["-f", "q.jq"])
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == expected_stderr


UNCAUGHT_ERROR_CASES = [
    ("error", "gojq: error: null\n"),
    ("null | error", "gojq: error: null\n"),
    ("error(null)", "gojq: error: null\n"),
    ('error("x")', "gojq: error: x\n"),
]


@pytest.mark.parametrize(("query", "expected_stderr"), UNCAUGHT_ERROR_CASES)
def test_uncaught_error_exit_code(run_gojq, query, expected_stderr):
    """An uncaught run-time error prints 'gojq: error: <value>' and exits 5."""
    # CATCHES: unlike parse and compile failures (exit 3), an error raised
    # at run time and never caught exits 5 with the 'gojq: error:' prefix
    # and no stdout; a string error value prints bare (error("x") shows x,
    # not a JSON-quoted "x") while other values print as themselves.
    proc = run_gojq([query])
    assert proc.returncode == 5, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query
