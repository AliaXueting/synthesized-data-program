"""Tests for computed paths: indexing and slicing by run-time expressions.

A constant path like '.a[0]' is folded by the compiler into a setpath call,
but as soon as a key comes from an expression ('.["a"+"b"]', '.[$i]',
'.[$s:$e]') the path is no longer constant: reads compile to the _index and
_slice builtins and '=' compiles to a path-aware assignment.  These pin the
values those forms produce, the container type errors they raise, and the
'invalid path against' error for '=' whose left side is not a path at all.
"""

import pytest

READ_CASES = [
    # the key is computed from any expression: concatenation, a nested path,
    # a string interpolation
    ('{"a":0,"ab":1} | .["a"+"b"]', "1\n"),
    ('{"k":["z"],"z":7} | .[.k[0]]', "7\n"),
    ('{"1":9} | .["\\(1)"]', "9\n"),
    # $variable indices, including a negative one counting from the end
    ("1 as $i | [10,20,30] | .[$i]", "20\n"),
    ("-1 as $i | [1,2,3] | .[$i]", "3\n"),
    # variable slice bounds over an array and over a string
    ("1 as $s | 3 as $e | [1,2,3,4] | .[$s:$e]", "[\n  2,\n  3\n]\n"),
    ('1 as $s | 2 as $e | "abcd" | .[$s:$e]', '"b"\n'),
    # constant index and slice on a string value
    ('"abc" | .[0]', '"a"\n'),
    ('"abc" | .[1:2]', '"b"\n'),
]


@pytest.mark.parametrize(("query", "expected"), READ_CASES)
def test_computed_index_reads(run_gojq, query, expected):
    """Index and slice suffixes whose keys are expressions read at run time."""
    # CATCHES: the key or slice bound may be any expression (string
    # concatenation, interpolation, a nested path, a $variable) and a
    # negative variable index resolves from the end exactly like a constant
    # one; slicing works on strings as well as arrays.
    proc = run_gojq([query])
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


TYPE_ERROR_CASES = [
    # an integer index against an object (literal and computed)
    ('{"a":1} | .[0]', 'gojq: expected an array but got: object ({"a":1})\n'),
    ('{"k":0,"a":1} | .[.k]', 'gojq: expected an array but got: object ({"a":1,"k":0})\n'),
    # a string key against an array (the inner .k fails first in the second)
    ('[1,2] | .["a"]', "gojq: expected an object but got: array ([1,2])\n"),
    ("[1,2] | .[.k]", "gojq: expected an object but got: array ([1,2])\n"),
    # object keys that are not strings
    ('{"k":null} | .[.k]', "gojq: expected a string for object key but got: null\n"),
    ('{"a":1} | .[null]', "gojq: expected a string for object key but got: null\n"),
    ('{"a":1} | .[true]', "gojq: expected a string for object key but got: boolean (true)\n"),
    # an array key takes the array branch of the container first
    ('{"a":1} | .[[1]]', 'gojq: expected an array but got: object ({"a":1})\n'),
    # a slice against a number (literal and variable bounds)
    ("5 | .[1:2]", "gojq: expected an array but got: number (5)\n"),
    ("1 as $s | 2 as $e | 5 | .[$s:$e]", "gojq: expected an array but got: number (5)\n"),
]


@pytest.mark.parametrize(("query", "expected_stderr"), TYPE_ERROR_CASES)
def test_computed_index_type_errors(run_gojq, query, expected_stderr):
    """The _index/_slice builtins check container and key types at run time."""
    # CATCHES: an integer index on an object, a string key on an array, a
    # null/boolean/array key, or a slice on a number each reports the
    # offending container or key with its value; a computed '.[.k]' on an
    # array fails inside '.k' before the outer index is even applied.
    proc = run_gojq([query])
    assert proc.returncode == 5, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


ASSIGN_CASES = [
    # writing through a computed key: concatenation and interpolation
    ('.["a"+"b"] = 1', "null\n", '{\n  "ab": 1\n}\n'),
    ('.["\\(1)"] = 5', "null\n", '{\n  "1": 5\n}\n'),
    # writing through a key read from the input itself
    (".[.k] = 9", '{"k":"z"}\n', '{\n  "k": "z",\n  "z": 9\n}\n'),
    (".[.k[0]] = 9", '{"k":["z"]}\n', '{\n  "k": [\n    "z"\n  ],\n  "z": 9\n}\n'),
    # slice assignment with variable bounds, and one-sided slices
    ("1 as $s | 3 as $e | [1,2,3,4] | .[$s:$e] = [9]", "null\n", "[\n  1,\n  9,\n  4\n]\n"),
    ("3 as $e | [1,2,3,4] | .[:$e] = [9]", "null\n", "[\n  9,\n  4\n]\n"),
    ("1 as $s | [1,2,3,4] | .[$s:] = [9]", "null\n", "[\n  1,\n  9\n]\n"),
    # a fractional index floors to 0; 1e1 = 10 pads ten nulls before the 9
    ("null | .[0.5] = 1", "null\n", "[\n  1\n]\n"),
    ("null | .[1e1] = 9", "null\n", "[\n" + "  null,\n" * 10 + "  9\n]\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), ASSIGN_CASES)
def test_computed_key_assignment(run_gojq, query, stdin, expected):
    """'=' through a computed key or slice writes the path at run time."""
    # CATCHES: assignment evaluates the key expression against the input,
    # so '.[.k] = 9' can read 'z' out of the object it is extending; slice
    # bounds may be variables or omitted, and numeric indices normalize
    # (0.5 floors to 0, 1e1 pads the array with nulls up to index 10).
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


def test_computed_key_assignment_type_error(run_gojq):
    """A computed object key that is not a string fails at assignment time."""
    # CATCHES: the key type is only checked when the assignment runs, so
    # '.[.k] = 9' with .k == true parses and compiles fine and then reports
    # the same 'expected a string for object key' error as the read form.
    proc = run_gojq(['{"k":true} | .[.k] = 9'], input_text='{"k":true}\n')
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: expected a string for object key but got: boolean (true)\n"


NON_PATH_CASES = [
    # every literal and computed value on the left of '=' fails the same way
    ("1 = 2", "gojq: invalid path against: number (1)\n"),
    ("true = true", "gojq: invalid path against: boolean (true)\n"),
    ('"s" = 1', 'gojq: invalid path against: string ("s")\n'),
    ("-1 = 2", "gojq: invalid path against: number (-1)\n"),
    ("[] = 1", "gojq: invalid path against: array ([])\n"),
    ("{a:1} = 2", 'gojq: invalid path against: object ({"a":1})\n'),
    # parentheses do not turn a value into a path
    ("(1) = 2", "gojq: invalid path against: number (1)\n"),
    ('("a"+"b") = 1', 'gojq: invalid path against: string ("ab")\n'),
    # '=' binds looser than '+', so this is ("a"+"b") = 1 as well
    ('"a"+"b" = 1', 'gojq: invalid path against: string ("ab")\n'),
    # $variables, formats and if/else results are values, not paths
    ("1 as $x | $x = 2", "gojq: invalid path against: number (1)\n"),
    ("@text = 1", 'gojq: invalid path against: string ("null")\n'),
    ("if . then 1 else 2 end = 3", "gojq: invalid path against: number (2)\n"),
    # a comma expression reports its first output and aborts
    ("(1,2) = 3", "gojq: invalid path against: number (1)\n"),
    # 'error' raises before any path check happens
    ("error = 1", "gojq: error: null\n"),
]


@pytest.mark.parametrize(("query", "expected_stderr"), NON_PATH_CASES)
def test_assignment_to_non_paths(run_gojq, query, expected_stderr):
    """'=' requires a path on its left; anything else is a run-time error."""
    # CATCHES: literals, variables, @format results, if/else values and
    # parenthesized expressions all fail with 'invalid path against:
    # <type> (<value>)' at exit 5; '+' binds tighter than '=' so "a"+"b" = 1
    # blames the concatenated "ab", and 'error' on the left raises first.
    proc = run_gojq([query])
    assert proc.returncode == 5, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


NULL_PATH_CASES = [
    # the path of null against null input is empty, so the whole document
    # is replaced; the same is true of '..' against null
    ("null = 1", "null\n", 0, "1\n", ""),
    (".. = 1", "null\n", 0, "1\n", ""),
    # against a real input those same queries are errors instead
    ('{"a":5} | null = 1', '{"a":5}\n', 5, "", "gojq: invalid path against: null\n"),
    (
        '{"a":5} | .. = 1',
        '{"a":5}\n',
        5,
        "",
        'gojq: setpath(["a"]; 1) cannot be applied to 1: expected an object but got: number (1)\n',
    ),
    (
        "[1,2] | .. = 1",
        "[1,2]\n",
        5,
        "",
        "gojq: setpath([0]; 1) cannot be applied to 1: expected an array but got: number (1)\n",
    ),
]


@pytest.mark.parametrize(("query", "stdin", "expected_rc", "expected_stdout", "expected_stderr"), NULL_PATH_CASES)
def test_null_and_recurse_paths(run_gojq, query, stdin, expected_rc, expected_stdout, expected_stderr):
    """null and '..' behave as paths only against null input."""
    # CATCHES: on null input both 'null = 1' and '.. = 1' have the empty
    # path and replace the whole document, but against an object 'null = 1'
    # is 'invalid path against: null' and '.. = 1' fails setpath on the
    # first leaf, naming the exact path ('["a"]' / '[0]') it tried to write.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == expected_rc, query
    assert proc.stdout == expected_stdout, query
    assert proc.stderr == expected_stderr, query
