"""Tests for 'def' definitions, variable references and destructuring.

These pin the def grammar (argument lists separated by ';', '$' parameter
bindings, recursive and nested definitions, the rejection of reserved
words as function names), the 'as' pattern grammar with '?//' alternatives,
and the compile errors for undefined variables and labels.
"""

import pytest

DEF_CASES = [
    ("def f: 1; f", "null", "1\n"),
    ("def f(x): x + x; f(3)", "null", "6\n"),
    ("def f(a; b): a + b; f(1; 2)", "null", "3\n"),
    # a function may call itself
    ("def fact: if . <= 1 then 1 else . * (.-1 | fact) end; 5 | fact", "null", "120\n"),
    # definitions nest and the inner one is only visible in the outer body
    ("def f: def g: 3; g * 2; f", "null", "6\n"),
    # '$x' binds the argument value while 'x' would re-evaluate the filter
    ("def f($x): $x; f(5)", "null", "5\n"),
    # a def may appear after a pipe, scoped to the rest of the query
    ("[1] | def f: .[0]; f", "null", "1\n"),
    ("def f: .a; {a: 7} | f", "null", "7\n"),
    ("def f(x): def g(y): x + y; g(x); f(4)", "null", "8\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), DEF_CASES)
def test_def_forms(run_gojq, query, stdin, expected):
    """def supports ';'-separated args, $params, recursion and nesting."""
    # CATCHES: arguments are separated by ';' not ',', '$x' parameters bind
    # values, and a nested def's scope ends with its enclosing body.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


@pytest.mark.parametrize(
    ("query", "expected_stderr"),
    [
        ('def if: 1; .', 'gojq: invalid query: def if: 1; .\n    def if: 1; .\n        ^  unexpected token "if"\n'),
        ("def f: 1", 'gojq: invalid query: def f: 1\n    def f: 1\n            ^  unexpected EOF\n'),
        ("def f(: 1; .", 'gojq: invalid query: def f(: 1; .\n    def f(: 1; .\n          ^  unexpected token ":"\n'),
        ('def f(x;): 1; .', 'gojq: invalid query: def f(x;): 1; .\n    def f(x;): 1; .\n            ^  unexpected token ")"\n'),
        ('def 1f: 2; .', 'gojq: invalid query: def 1f: 2; .\n    def 1f: 2; .\n        ^  invalid token "1f"\n'),
    ],
)
def test_def_syntax_errors(run_gojq, query, expected_stderr):
    """Reserved words and bad identifiers cannot name a function."""
    # CATCHES: 'def if:' blames the keyword token, 'def 1f:' is an invalid
    # token (not an unexpected one), and a missing ';' reports EOF one past
    # the body.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


PATTERN_CASES = [
    ("[1,2] as [$a, $b] | $a + $b", "null", "3\n"),
    ('{"a":1} as {a: $x} | $x', "null", "1\n"),
    # an arbitrary query in parens as the object pattern key
    ('{"a":1} as {("a"): $x} | $x', "null", "1\n"),
    # a short array binds missing positions to null
    ("[1] as [$a, $b] | [$a, $b]", "null", "[\n  1,\n  null\n]\n"),
    ('{"a":{"b":2}} as {a: {b: $x}} | $x', "null", "2\n"),
    # {$a} is shorthand for {a: $a}
    ('{"a":1} as {$a} | $a', "null", "1\n"),
    ("[[1,2]] as [[$a, $b]] | $a", "null", "1\n"),
    # destructuring null succeeds with null bindings
    ("null as {$x} | 1", "null", "1\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), PATTERN_CASES)
def test_destructuring_patterns(run_gojq, query, stdin, expected):
    """'as' accepts array, object, nested and shorthand patterns."""
    # CATCHES: '{$a}' is shorthand for '{a: $a}', '("a")' is a computed
    # pattern key, a short array binds nulls, and patterns nest.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


ALTERNATIVE_CASES = [
    # the array pattern alternative matches arrays
    (". as [$a] ?// {$a} | $a", "[5]", "5\n"),
    # ... and the object alternative matches objects with that key
    (". as [$a] ?// {$a} | $a", '{"a":5}', "5\n"),
    # more than two alternatives separated by ?//
    (". as [$a] ?// [$a, $b] | $a", "[5]", "5\n"),
    # a bare variable is a valid single-alternative pattern
    ("1 as $x ?// $y | $x", "null", "1\n"),
    # alternatives are tried per input value
    ('.[] as [$a] ?// {$a} | $a', '[[1],{"a":2}]', "1\n2\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), ALTERNATIVE_CASES)
def test_pattern_alternatives(run_gojq, query, stdin, expected):
    """'?//' separates alternative destructuring patterns."""
    # CATCHES: each '?//' alternative is tried in order per input, so the
    # same query destructures both arrays and objects, and '.a ?// .b'
    # outside a pattern parses as '.a? // .b' instead.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query

    proc = run_gojq([".a ?// .b"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "null\n"
    assert proc.stderr == ""


def test_undefined_variable_and_loc(run_gojq):
    """Undefined $variables and $__loc__ are compile errors with exit 3."""
    # CATCHES: '$__loc__' is not a predefined variable in gojq, so it
    # reports 'variable not defined: $__loc__' like any other unbound name.
    cases = [
        ("$x", "gojq: compile error: variable not defined: $x\n"),
        ("$__loc__", "gojq: compile error: variable not defined: $__loc__\n"),
        (". as $x | $y", "gojq: compile error: variable not defined: $y\n"),
    ]
    for query, expected in cases:
        proc = run_gojq([query])
        assert proc.returncode == 3, query
        assert proc.stdout == "", query
        assert proc.stderr == expected, query

    # a bound variable works and round-trips its value
    proc = run_gojq(["1 as $x | $x"])
    assert proc.returncode == 0
    assert proc.stdout == "1\n"
