"""Tests for path expressions: identity, recurse, fields, indexes, slices.

These pin which suffix forms the grammar accepts after '.' and after a
term, and how the lexer splits '.' + ident / '.' + number from '..' and
'.' alone.
"""

import pytest


def test_identity_and_recurse(run_gojq):
    """Identity '.' and recurse '..' are distinct terms."""
    # CATCHES: '.' returns the input untouched while '..' yields the input
    # and every descendant, so a grammar that folded recurse into identity
    # would emit the extra values here.
    proc = run_gojq(["."], input_text='{"a":1}\n')
    assert proc.returncode == 0
    assert proc.stdout == '{\n  "a": 1\n}\n'
    assert proc.stderr == ""

    proc = run_gojq(["[.]"], input_text="3\n")
    assert proc.returncode == 0
    assert proc.stdout == "[\n  3\n]\n"

    proc = run_gojq(["[..] | length"], input_text="3\n")
    assert proc.returncode == 0
    assert proc.stdout == "1\n"


def test_field_access_forms(run_gojq):
    """Plain, chained, quoted and keyword-named fields all parse."""
    # CATCHES: keywords such as 'if' lex as a field name after '.', and a
    # quoted string is accepted after '.', which plain-ident lexers miss.
    cases = [
        ([".foo"], '{"foo":42}\n', "42\n"),
        ([".foo.bar"], '{"foo":{"bar":"x"}}\n', '"x"\n'),
        (['."foo bar"'], '{"foo bar":7}\n', "7\n"),
        (['."é"'], '{"é":1}\n', "1\n"),
        ([".if"], '{"if":3}\n', "3\n"),
        ([".and"], '{"and":4}\n', "4\n"),
        ([".null"], '{"null":5}\n', "5\n"),
        ([".def"], '{"def":5}\n', "5\n"),
        ([".if.then"], '{"if":{"then":6}}\n', "6\n"),
        ([".a .b"], "null\n", "null\n"),
        (['. "a"'], '{"a":6}\n', "6\n"),
    ]
    for args, stdin, expected in cases:
        proc = run_gojq(args, input_text=stdin)
        assert proc.returncode == 0, args
        assert proc.stdout == expected, args
        assert proc.stderr == "", args


def test_index_and_slice_forms(run_gojq):
    """Bracket indexes, slices and omitted slice bounds parse."""
    # CATCHES: slices accept start-only, end-only and expression bounds,
    # and .["a":] is accepted with a string as the slice start.
    cases = [
        ([".[0]"], "[5,6]\n", "5\n"),
        ([".[-1]"], "[1,2,3]\n", "3\n"),
        ([".[1:3]"], "[1,2,3,4]\n", "[\n  2,\n  3\n]\n"),
        ([".[:2]"], "[1,2,3,4]\n", "[\n  1,\n  2\n]\n"),
        ([".[2:]"], "[1,2,3,4]\n", "[\n  3,\n  4\n]\n"),
        ([".[1 + 1 : 3]"], "[1,2,3,4]\n", "[\n  3\n]\n"),
        ([".[:-1]"], "[1,2,3]\n", "[\n  1,\n  2\n]\n"),
        (['.["a"]'], '{"a":5}\n', "5\n"),
        (['.a["b"]'], '{"a":{"b":6}}\n', "6\n"),
        ([".[1 + 1]"], "[1,2,3]\n", "3\n"),
        (['.["a":]'], "null\n", "null\n"),
        (['. [1]'], "[9]\n", "null\n"),
        (['{"a":1} | . ["a"]'], "null\n", "1\n"),
    ]
    for args, stdin, expected in cases:
        proc = run_gojq(args, input_text=stdin)
        assert proc.returncode == 0, args
        assert proc.stdout == expected, args


def test_iteration_and_optional(run_gojq):
    """Iteration and the optional '?' suffix, alone and chained."""
    # CATCHES: '?' suppresses the iteration/index error, so '.foo?' on a
    # number produces no output at all instead of a runtime error.
    cases = [
        ([".[]"], "[1,2]\n", "1\n2\n"),
        ([".[]"], '{"a":1,"b":2}\n', "1\n2\n"),
        ([".[][]"], "[[1],[2]]\n", "1\n2\n"),
        ([".foo?"], "3\n", ""),
        ([".[]?"], "3\n", ""),
        ([".foo?.bar?"], '"s"\n', ""),
        (["[.[]?[]?]"], "[[1],2]\n", "[\n  1\n]\n"),
        ([".a?.b"], '{"a":{"b":1}}\n', "1\n"),
        (["[.[0]?]"], "5\n", "[]\n"),
        (["[.[1:2]?]"], "null\n", "[\n  null\n]\n"),
        (["[.[]?.a?]"], '[{"a":1},2]\n', "[\n  1\n]\n"),
        ([".a??"], "null\n", "null\n"),
        ([".?"], "null\n", "null\n"),
        (["..?"], "null\n", "null\n"),
        (['["ab"?]'], "null\n", '[\n  "ab"\n]\n'),
    ]
    for args, stdin, expected in cases:
        proc = run_gojq(args, input_text=stdin)
        assert proc.returncode == 0, args
        assert proc.stdout == expected, args


def test_suffixes_on_terms(run_gojq):
    """Suffixes may follow parenthesized terms, strings and numbers."""
    # CATCHES: '"ab"[0]' indexes a string literal and '(.a | .b).c' chains
    # a suffix onto a parenthesized query, both non-obvious grammar spots.
    cases = [
        (['"ab"[0]'], "null\n", '"a"\n'),
        (["(.a).b"], '{"a":{"b":7}}\n', "7\n"),
        (["(.a | .b).c"], '{"a":{"b":{"c":8}}}\n', "8\n"),
        (["(.a)?"], "3\n", ""),
        (["(1)"], "null\n", "1\n"),
        (["((1))"], "null\n", "1\n"),
        (["1 | . + 1 | . + 1"], "null\n", "3\n"),
    ]
    for args, stdin, expected in cases:
        proc = run_gojq(args, input_text=stdin)
        assert proc.returncode == 0, args
        assert proc.stdout == expected, args

    # '1[0]' parses as the number 1 indexed by 0; it fails at runtime, not
    # at parse time, proving the suffix attached to the number term.
    proc = run_gojq(["[1[0]]"])
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: expected an array but got: number (1)\n"


def test_whitespace_rules(run_gojq):
    """Whitespace changes tokenization: '. .x' vs '..x' and '0 .x' vs '0.x'."""
    # CATCHES: '..x' lexes as recurse followed by ident 'x' (parse error),
    # while '. .x' is identity with a field suffix; likewise '0.x' is an
    # invalid number token but '0 .x' is the number 0 indexed by "x".
    proc = run_gojq([". .x"], input_text='{"x":9}\n')
    assert proc.returncode == 0
    assert proc.stdout == "9\n"

    proc = run_gojq(["..x"], input_text='{"x":1}\n')
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: invalid query: ..x\n    ..x\n      ^  unexpected token "x"\n'

    proc = run_gojq(["0 .x"], input_text="{}\n")
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: expected an object but got: number (0)\n"

    proc = run_gojq(["0.x"], input_text="{}\n")
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: invalid query: 0.x\n    0.x\n    ^  invalid token "0.x"\n'

    proc = run_gojq([". ."], input_text="7\n")
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: invalid query: . .\n    . .\n       ^  unexpected EOF\n'

    proc = run_gojq([".a. b"], input_text="null\n")
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: invalid query: .a. b\n    .a. b\n        ^  unexpected token "b"\n'


def test_invalid_suffix_errors(run_gojq):
    """Malformed suffix chains report 'unexpected EOF' or the bad token."""
    # CATCHES: '.foo.' and '.abc[' report EOF at one column past the last
    # character, while '{ .id }' reports the '.id' token itself.
    cases = [
        (".foo.", 'gojq: invalid query: .foo.\n    .foo.\n         ^  unexpected EOF\n'),
        (".abc[", 'gojq: invalid query: .abc[\n    .abc[\n         ^  unexpected EOF\n'),
        ("[1, 2", 'gojq: invalid query: [1, 2\n    [1, 2\n         ^  unexpected EOF\n'),
        ("...", 'gojq: invalid query: ...\n    ...\n       ^  unexpected EOF\n'),
        (".?/", 'gojq: invalid query: .?/\n    .?/\n       ^  unexpected EOF\n'),
        (
            ".[1:2:3]",
            'gojq: invalid query: .[1:2:3]\n    .[1:2:3]\n         ^  unexpected token ":"\n',
        ),
        (".x.5", 'gojq: invalid query: .x.5\n    .x.5\n      ^  unexpected token ".5"\n'),
        (".?a", 'gojq: invalid query: .?a\n    .?a\n      ^  unexpected token "a"\n'),
        (
            "[ .[] | { .id } ]",
            'gojq: invalid query: [ .[] | { .id } ]\n    [ .[] | { .id } ]\n              ^  unexpected token ".id"\n',
        ),
    ]
    for query, expected in cases:
        proc = run_gojq([query], input_text="{}\n")
        assert proc.returncode == 3, query
        assert proc.stdout == "", query
        assert proc.stderr == expected, query


def test_keyword_and_operator_tokens_rejected_as_terms(run_gojq):
    """Bare operator and punctuation tokens fail as leading terms."""
    # CATCHES: '>', '&', '\\', '$', ')', '=', '!' and '?' each produce the
    # single-character "unexpected token" wording with the caret at column 0.
    cases = [
        (">abc", 'unexpected token ">"'),
        (".foo & .bar", 'unexpected token "&"'),
        ("\\\\/", 'unexpected token "\\\\"'),
        ("$", 'unexpected token "$"'),
        (")", 'unexpected token ")"'),
        ("=", 'unexpected token "="'),
        ("!", 'unexpected token "!"'),
        ("??", 'unexpected token "?"'),
        ("| .", 'unexpected token "|"'),
        ("then . end", 'unexpected token "then"'),
    ]
    for query, fragment in cases:
        proc = run_gojq([query], input_text="{}\n")
        assert proc.returncode == 3, query
        assert proc.stdout == "", query
        assert proc.stderr.startswith("gojq: invalid query: %s\n" % query), query
        assert fragment in proc.stderr, query
        assert proc.stderr.count("\n") == 3, query


def test_pipe_and_comma_precedence(run_gojq):
    """Pipes bind looser than commas: '. | ., . | .' fans out per branch."""
    # CATCHES: the recorded output is two '1's, not one, pinning that the
    # comma inside the pipe right-hand side splits before the second pipe.
    proc = run_gojq([". | ., . | ."], input_text="1\n")
    assert proc.returncode == 0
    assert proc.stdout == "1\n1\n"

    proc = run_gojq(["[1, (2, 3)]"])
    assert proc.returncode == 0
    assert proc.stdout == "[\n  1,\n  2,\n  3\n]\n"

    for query, expected in [
        (". |", 'gojq: invalid query: . |\n    . |\n       ^  unexpected EOF\n'),
        ("1,", 'gojq: invalid query: 1,\n    1,\n      ^  unexpected EOF\n'),
        (". -", 'gojq: invalid query: . -\n    . -\n       ^  unexpected EOF\n'),
        ("(1", 'gojq: invalid query: (1\n    (1\n      ^  unexpected EOF\n'),
        ("()", 'gojq: invalid query: ()\n    ()\n     ^  unexpected token ")"\n'),
    ]:
        proc = run_gojq([query])
        assert proc.returncode == 3, query
        assert proc.stdout == "", query
        assert proc.stderr == expected, query
