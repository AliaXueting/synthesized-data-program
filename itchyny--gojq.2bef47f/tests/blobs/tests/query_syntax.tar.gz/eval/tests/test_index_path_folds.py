"""Tests for how index and slice expressions fold into update paths.

These pin the constant-path folding implemented by query.go's
Index.toIndexKey / toIndices family and its Term/Suffix/Query callers,
observed through 'path(...)' and through '=' / '|=' / 'del': a slice key
always carries both 'start' and 'end' (an omitted bound becomes an explicit
null), fractional and negative-zero indices keep their float shape inside
path(...) while assignments truncate them toward zero, computed bounds
('1+2', '"\\(1)"', '$x') fall back to runtime paths that record the same
slice key, a comma inside brackets is a stream of indices, and 'path(..)' /
'path(.a[])' enumerate every path a query visits.
"""

import pytest

SLICE_OMITTED_BOUND_CASES = [
    # an omitted end bound is recorded as an explicit null, not dropped
    ("path(.[1:])", "[1,2,3]\n", '[\n  {\n    "end": null,\n    "start": 1\n  }\n]\n'),
    # an omitted start bound is the explicit null on the other side
    ("path(.[:2])", "[1,2,3]\n", '[\n  {\n    "end": 2,\n    "start": null\n  }\n]\n'),
    # negative bounds count from the end even with the other side omitted
    ("path(.[-1:])", "[1,2,3]\n", '[\n  {\n    "end": null,\n    "start": -1\n  }\n]\n'),
    ("path(.[:-1])", "[1,2,3]\n", '[\n  {\n    "end": -1,\n    "start": null\n  }\n]\n'),
    # a named field folds in front of the slice key
    ('path(.a[1:])', '{"a":[1,2]}\n', '[\n  "a",\n  {\n    "end": null,\n    "start": 1\n  }\n]\n'),
    # a string bound is kept verbatim in the key (null input is never sliced)
    ('path(.["a":2])', "null\n", '[\n  {\n    "end": 2,\n    "start": "a"\n  }\n]\n'),
    # a @format term is a legal slice start; @text of null is the string "null"
    ("path(.[@text:2])", "null\n", '[\n  {\n    "end": 2,\n    "start": "null"\n  }\n]\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), SLICE_OMITTED_BOUND_CASES)
def test_path_of_slices_with_omitted_bounds(run_gojq, query, stdin, expected):
    """path() of a slice reports both bounds, null for the omitted one."""
    # CATCHES: the folded slice key is always {"start":..,"end":..} with an
    # explicit JSON null for an omitted bound, negative bounds included.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


SLICE_GRAMMAR_ERROR_CASES = [
    # at least one bound is required before the ':'
    (
        "path(.[:])",
        'gojq: invalid query: path(.[:])\n    path(.[:])\n            ^  unexpected token "]"\n',
    ),
    # the start position cannot be empty before a ';' either
    (
        ".[;2]",
        'gojq: invalid query: .[;2]\n    .[;2]\n      ^  unexpected token ";"\n',
    ),
    # only one ':' separates the bounds
    (
        ".[1:2:3]",
        'gojq: invalid query: .[1:2:3]\n    .[1:2:3]\n         ^  unexpected token ":"\n',
    ),
]


@pytest.mark.parametrize(("query", "expected_stderr"), SLICE_GRAMMAR_ERROR_CASES)
def test_slice_grammar_requires_bounds(run_gojq, query, expected_stderr):
    """'.[ : ]' needs a bound on at least one side of the colon."""
    # CATCHES: '.[:]', '.[;2]' and '.[1:2:3]' are rejected at parse time
    # with the caret on the offending ':' / ';' / ']' token.
    proc = run_gojq([query])
    assert proc.returncode == 3, query
    assert proc.stdout == "", query
    assert proc.stderr == expected_stderr, query


SLICE_NULL_ASSIGNMENT_CASES = [
    ("null | .[1:2] = [9]", "[\n  9\n]\n"),
    ("null | .[:2] = [9]", "[\n  9\n]\n"),
    ("null | .[1:] = [9]", "[\n  9\n]\n"),
]


@pytest.mark.parametrize(("query", "expected"), SLICE_NULL_ASSIGNMENT_CASES)
def test_slice_assignment_against_null(run_gojq, query, expected):
    """Assigning a slice of null replaces the null with the value."""
    # CATCHES: slice assignment against null builds '[9]' whatever the
    # bounds are -- unlike '.[1] = 9', which pads a leading null.
    proc = run_gojq([query])
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


SLICE_UPDATE_CASES = [
    # deleting an open-ended range keeps only the head
    ("[1,2,3,4] | del(.[1:])", "[\n  1\n]\n"),
    # updating an open-ended range replaces the tail
    ("[1,2,3] | .[1:] |= [9]", "[\n  1,\n  9\n]\n"),
]


@pytest.mark.parametrize(("query", "expected"), SLICE_UPDATE_CASES)
def test_slice_del_and_update_with_omitted_bounds(run_gojq, query, expected):
    """del() and |= accept slices with an omitted bound."""
    # CATCHES: 'del(.[1:])' truncates the array after index 0 and
    # '.[1:] |= [9]' rewrites the tail, both exit 0.
    proc = run_gojq([query])
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


def test_string_slice_bounds(run_gojq):
    """String slice bounds parse; they only fail against real containers."""
    # CATCHES: '.[: "a"]' against null is fine (null slices to null) while
    # the same string bound against an array is the runtime error
    # 'expected a number for indexing an array but got: string ("a")'.
    proc = run_gojq(['.[: "a"]'], input_text="null\n")
    assert proc.returncode == 0
    assert proc.stdout == "null\n"
    assert proc.stderr == ""

    proc = run_gojq(['[1,2,3] | .["a":2]'])
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: expected a number for indexing an array but got: string ("a")\n'


CHAINED_SLICE_CASES = [
    # a slice key may be followed by more suffixes inside one path
    (
        'path(.a[1:2][0])',
        '{"a":[[1,2],[3,4]]}\n',
        '[\n  "a",\n  {\n    "end": 2,\n    "start": 1\n  },\n  0\n]\n',
    ),
    # assignment folds through the slice then the integer index
    ("null | .a[1:2][0] = 9", "null\n", '{\n  "a": [\n    9\n  ]\n}\n'),
    # reading chains the same way: element 0 of the slice [1:2]
    ("[[1,2],[3,4]] | .[1:2][0]", "null\n", '[\n  3,\n  4\n]\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), CHAINED_SLICE_CASES)
def test_chained_slice_then_index_paths(run_gojq, query, stdin, expected):
    """A slice suffix can be chained with further index suffixes."""
    # CATCHES: '.a[1:2][0]' is one path ["a",{"start":1,"end":2},0], and
    # assigning through it builds the nested array in one step.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


FRACTIONAL_INDEX_CASES = [
    # the fractional float survives into the path array unfloored
    ("path(.[0.5])", "null\n", '[\n  0.5\n]\n'),
    ("path(.[-0.5])", "null\n", '[\n  -0.5\n]\n'),
    # '.5' after '.[', the lexer scans it as the number 0.5
    ("path(.[.5])", "null\n", '[\n  0.5\n]\n'),
    # reading truncates toward zero, so -0.5 is index 0 (the first element)
    ("[1,2,3] | .[-0.5]", "null\n", "1\n"),
    ("[1,2,3] | .[-0.5] = 9", "null\n", "[\n  9,\n  2,\n  3\n]\n"),
    # against null the truncated index 0 creates the first element
    ("null | .[-0.5] = 1", "null\n", "[\n  1\n]\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), FRACTIONAL_INDEX_CASES)
def test_fractional_index_folds(run_gojq, query, stdin, expected):
    """Fractional indices keep their float shape in paths, truncate in use."""
    # CATCHES: path(.[0.5]) reports the raw 0.5 while reads and writes
    # truncate toward zero -- '-0.5' is index 0, not an error like '-1'.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


SIGNED_ZERO_EXPONENT_CASES = [
    # unary minus on 0.0 folds to negative zero, printed as -0 by the encoder
    ("path(.[-0.0])", "null\n", '[\n  -0\n]\n'),
    # but -0.0 truncates back to plain index 0 when used as a path
    ("null | .[-0.0] = 9", "null\n", '[\n  9\n]\n'),
    # 1e1 folds to the float 10.0, encoded as 10
    ("path(.[1e1])", "null\n", '[\n  10\n]\n'),
    # 1e1000 clamps to the float64 maximum inside the path
    ("path(.[1e1000])", "null\n", '[\n  1.7976931348623157e+308\n]\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), SIGNED_ZERO_EXPONENT_CASES)
def test_signed_zero_and_exponent_index_folds(run_gojq, query, stdin, expected):
    """'-0.0' and exponent literals fold into paths as raw floats."""
    # CATCHES: negated zero keeps its sign inside path(...) ('-0') but is
    # index 0 on assignment, and 1e1000 clamps to the float64 maximum.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


COMPUTED_BOUND_CASES = [
    # arithmetic in the brackets evaluates inside path()
    ("path(.[1+2])", "null\n", '[\n  3\n]\n'),
    # assignment through it pads like the plain '.[3] = 9' would
    ("null | .[1+2] = 9", "null\n", '[\n  null,\n  null,\n  null,\n  9\n]\n'),
    # an interpolated string key is computed, then recorded as "1"
    ('path(.["\\(1)"])', "null\n", '[\n  "1"\n]\n'),
    # an interpolated slice bound parses; slicing null gives null
    ('.["\\(1)":2]', "null\n", "null\n"),
    # a variable slice start still records the end:null key at runtime
    (
        "1 as $s | [1,2,3,4] | path(.[$s:])",
        "null\n",
        '[\n  {\n    "end": null,\n    "start": 1\n  }\n]\n',
    ),
    # both bounds computed from variables, slicing a string
    (
        '1 as $s | 3 as $e | "abcde" | path(.[$s:$e])',
        "null\n",
        '[\n  {\n    "end": 3,\n    "start": 1\n  }\n]\n',
    ),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), COMPUTED_BOUND_CASES)
def test_computed_index_expressions_in_paths(run_gojq, query, stdin, expected):
    """Non-constant bounds fall back to runtime paths with the same keys."""
    # CATCHES: '1+2', '"\\(1)"' and '$x' are not constant-folded but still
    # evaluate inside path(), producing the same slice/index keys.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


MULTI_INDEX_CASES = [
    # a comma inside the brackets indexes by each value in turn
    ("[10,20,30] | .[1,2]", "null\n", "20\n30\n"),
    ('.["a","b"]', '{"a":1,"b":2}\n', "1\n2\n"),
    # assignment applies to every index of the stream
    ("[10,20,30] | .[1,2] = 9", "null\n", "[\n  10,\n  9,\n  9\n]\n"),
    ('null | .["a","b"] = 1', "null\n", '{\n  "a": 1,\n  "b": 1\n}\n'),
    # path() itself becomes a stream: one path array per index
    ("path(.[1,2])", "null\n", "[\n  1\n]\n[\n  2\n]\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), MULTI_INDEX_CASES)
def test_multi_index_brackets(run_gojq, query, stdin, expected):
    """A comma inside '.[...]' is a stream of indices."""
    # CATCHES: '.[1,2]' yields both elements (not an array of them), the
    # assignment form updates both positions, and path(.[1,2]) emits two
    # separate path arrays.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query


PATH_ENUMERATION_CASES = [
    # recurse visits the root, then every descendant path
    (
        "[path(..)]",
        '{"a":{"b":1}}\n',
        '[\n  [],\n  [\n    "a"\n  ],\n  [\n    "a",\n    "b"\n  ]\n]\n',
    ),
    (
        "[path(..)]",
        "[[1]]\n",
        '[\n  [],\n  [\n    0\n  ],\n  [\n    0,\n    0\n  ]\n]\n',
    ),
    # iteration enumerates one path per element
    (
        "[path(.a[])]",
        '{"a":[1,2]}\n',
        '[\n  [\n    "a",\n    0\n  ],\n  [\n    "a",\n    1\n  ]\n]\n',
    ),
    ("[path(.[])]", '{"a":1}\n', '[\n  [\n    "a"\n  ]\n]\n'),
    # '..' accepts an '[]' suffix; an empty container iterates to nothing
    ("[] | [..[]]", "null\n", "[]\n"),
    ('{"a":{}} | [..[]]', "null\n", '[\n  {}\n]\n'),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), PATH_ENUMERATION_CASES)
def test_path_enumeration_of_recurse_and_iteration(run_gojq, query, stdin, expected):
    """path() enumerates the paths that '..' and '.[]' visit."""
    # CATCHES: '[path(..)]' lists [], ["a"], ["a","b"] in document order,
    # and '..[]' (recurse with an iteration suffix) yields each container.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query

    # '..[]' over a structure that reaches a number prints the values it
    # managed to produce before the iteration of the number fails
    proc = run_gojq(["[1] | ..[]"])
    assert proc.returncode == 5
    assert proc.stdout == "1\n"
    assert proc.stderr == "gojq: cannot iterate over: number (1)\n"


STRING_KEY_FOLD_CASES = [
    # escape sequences are decoded before folding, and re-encoded on output
    ('path(.["a\\tb"])', "null\n", '[\n  "a\\tb"\n]\n'),
    # bracket-string suffixes chain into one constant path
    ('path(.["a"]["b"])', "null\n", '[\n  "a",\n  "b"\n]\n'),
    ('null | .["a"]["b"] = 1', "null\n", '{\n  "a": {\n    "b": 1\n  }\n}\n'),
    ('null | .a["b"]["c"] = 1', "null\n", '{\n  "a": {\n    "b": {\n      "c": 1\n    }\n  }\n}\n'),
    # a parenthesized term keeps the chain foldable
    ('(.a)["b"] = 1', "null\n", '{\n  "a": {\n    "b": 1\n  }\n}\n'),
    # interpolated string keys also work in destructuring object patterns
    ('{"1":5} as {"\\(1)": $x} | $x', "null\n", "5\n"),
]


@pytest.mark.parametrize(("query", "stdin", "expected"), STRING_KEY_FOLD_CASES)
def test_string_key_folds(run_gojq, query, stdin, expected):
    """String keys fold through brackets, chains and patterns."""
    # CATCHES: '.["a\\tb"]' decodes the escape before folding (path echoes
    # it re-escaped), and '.["a"]["b"] = 1' builds nested objects through
    # the chained bracket suffixes.
    proc = run_gojq([query], input_text=stdin)
    assert proc.returncode == 0, query
    assert proc.stdout == expected, query
    assert proc.stderr == "", query
