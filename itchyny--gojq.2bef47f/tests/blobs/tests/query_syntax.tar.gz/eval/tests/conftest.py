"""Shared helpers for the query_syntax test module.

The program under test is gojq.  These tests pin the query-language grammar:
which query texts parse, and the exact bytes of the syntax-error reports
("gojq: invalid query: ..." with the indented echo line, caret line and
"unexpected token" wording, exit code 3, empty stdout) plus the "missing
query" compile error for empty queries.
"""

import functools
import os
import subprocess
import tempfile
from pathlib import Path

import pytest


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--version' once against a throwaway GOCOVERDIR, so
    the check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="gojq-covprobe-") as probe_dir:
        env = {"PATH": "/usr/bin:/bin", "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def _gojq_bin():
    """Resolve the reference binary through PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the gojq binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but
    # the pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to
    # this module's uninstrumented copy before pytest starts, so the counters
    # would never be written and this module's coverage report would stay
    # empty.  During a coverage run (GOCOVERDIR present), when the assigned
    # binary is not itself instrumented, fall back to the instrumented build
    # the driver stages next to the module workspaces.  That file only exists
    # in the pipeline layout, so ordinary validation runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(str(staged)):
            return str(staged)
    return path


# Pinned child environment: no network, no locale or color surprises.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "dumb",
}


def _child_env():
    """The pinned child environment plus the coverage forwarding vars."""
    env = dict(CHILD_ENV)
    # The pipeline measures source coverage of the reference binary through
    # GOCOVERDIR; forward it when the test process itself was started with
    # it so an instrumented binary can write its covermeta files.  Read at
    # call time so a per-test override is honored too.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    return env


def _invoke(args, input_text, cwd, timeout, env=None):
    """Spawn gojq with the given argv and capture both output streams."""
    child_env = _child_env()
    if env:
        # A per-test override layers on top of the pinned environment;
        # everything not named stays pinned.
        child_env.update(env)
    return subprocess.run(
        [_gojq_bin(), *args],
        input=input_text,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=cwd,
        env=child_env,
        timeout=timeout,
    )


def run_gojq(args, input_text="null\n", cwd=None, timeout=10, env=None):
    """Run gojq with the given argv and return the completed process.

    ``args`` is the full argument vector after the binary name, so tests
    control whether the query comes from the command line, from ``-f`` or
    with flags such as ``--arg`` or ``-n``.
    """
    return _invoke(args, input_text, cwd, timeout, env)


@pytest.fixture(name="run_gojq")
def run_gojq_fixture(tmp_path):
    """The run_gojq helper, defaulting to an isolated empty cwd."""

    def _run(args, input_text="null\n", cwd=None, timeout=10, env=None):
        return _invoke(args, input_text, cwd or str(tmp_path), timeout, env)

    return _run


@pytest.fixture(name="query_file")
def query_file_fixture(tmp_path):
    """Write a query (or module) file and return a runner bound to it.

    The first argument is the file contents; the rest are extra gojq
    arguments.  The returned callable runs ``gojq -f <file> ...`` from
    inside the per-test directory and returns the completed process, with
    ``proc.file`` carrying the file path for building expected messages.
    """

    def _make(contents, name="q.jq", args=(), input_text="null\n", binary=False):
        path = tmp_path / name
        if binary:
            path.write_bytes(contents)
        else:
            path.write_text(contents, encoding="utf-8", newline="")
        proc = _invoke(
            ["-f", str(path), *args], input_text, str(tmp_path), 10, None
        )
        proc.file = str(path)
        return proc

    return _make
