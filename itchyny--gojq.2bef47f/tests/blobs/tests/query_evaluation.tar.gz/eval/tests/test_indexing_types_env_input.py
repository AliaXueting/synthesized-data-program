"""String indexing, type names, $ENV/env access, and input/inputs."""


def test_string_indexing(q):
    # CATCHES: indexing a string literal is a gojq extension — positive
    # indices pick characters, NEGATIVE indices count from the end, an
    # out-of-range index gives null, but a string key still demands an
    # object (type error wording names the actual type).
    r = q('"abcde"[2]')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"c"\n', "")
    r = q('"abcde"[-1]')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"e"\n', "")
    r = q('"abcde"[10]')
    assert (r.returncode, r.stdout, r.stderr) == (0, "null\n", "")
    r = q('"abcde"["a"]')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: expected an object but got: string ("abcde")\n')


def test_type_of_every_value(q):
    # CATCHES: the jq type ladder names null as "null" (not "Null" or a
    # panic) and reports arbitrary-precision integers as plain "number".
    r = q('[null,true,false,1,1.5,1' + '0' * 33 + ',"s",[],{}] | map(type)')
    assert (r.returncode, r.stdout, r.stderr) == (
        0,
        '["null","boolean","boolean","number","number","number",'
        '"string","array","object"]\n',
        "")


def test_dollar_env_reads_pinned_environment(q):
    # CATCHES: $ENV and env snapshot the child process environment at
    # query start (HOME is the pinned /nonexistent), and $ENV is an object
    # even when wrapped in an array.
    r = q("$ENV.HOME")
    assert (r.returncode, r.stdout, r.stderr) == (0, '"/nonexistent"\n', "")
    r = q("env.HOME")
    assert (r.returncode, r.stdout, r.stderr) == (0, '"/nonexistent"\n', "")
    r = q("[$ENV] | keys")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[0]\n", "")


def test_inputs_slurps_and_input_exhaustion_errors(run_gojq):
    # CATCHES: inputs consumes every remaining input value, but input past
    # the end is a hard error `gojq: break` with exit 5 (not empty), while
    # -n defers the first input so `input` reads the first stdin value.
    r = run_gojq(["-c", "-n", "[inputs]"], stdin="1 2 3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2,3]\n", "")
    r = run_gojq(["-c", "[input, input, input]"], stdin="1 2")
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: break\n")
    r = run_gojq(["-c", "-n", "[input]"], stdin="")
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: break\n")
    r = run_gojq(["-c", "-n", "input"], stdin="1 2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")


def test_first_and_last_generators(run_gojq):
    # CATCHES: first(f) yields only the initial output while last(f) keeps
    # the final one without buffering the stream.
    r = run_gojq(["-c", "first(1,2), last(1,2,3)"], stdin="null")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n3\n", "")
