"""Arithmetic and data operators under jq type rules, incl. big integers."""


def test_number_addition_and_float_precision(q):
    # CATCHES: int+int stays an exact int, mixing int/float promotes to
    # float, and float results are printed with Go's shortest round-trip
    # formatting (0.1+0.2 is NOT 0.3).
    r = q("1+2, 1+2.5, 1.5+2.5")
    assert (r.returncode, r.stdout, r.stderr) == (0, "3\n3.5\n4\n", "")
    r = q("0.1 + 0.2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "0.30000000000000004\n", "")
    r = q("1 / 3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "0.3333333333333333\n", "")


def test_big_integer_literals_preserved(q):
    # CATCHES: integers beyond int64 are kept in arbitrary precision instead
    # of being coerced to a float64 and losing their trailing digits.
    r = q("4722366482869645213696")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "4722366482869645213696\n", "")
    r = q("4722366482869645213696 + 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "4722366482869645213697\n", "")
    r = q("9007199254740993 + 0")
    assert (r.returncode, r.stdout, r.stderr) == (0, "9007199254740993\n", "")


def test_integer_overflow_promotes_to_bigint(q):
    # CATCHES: int operations that would wrap around are promoted to
    # arbitrary-precision integers instead of overflowing silently.
    r = q("9223372036854775807 + 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "9223372036854775808\n", "")
    r = q("-9223372036854775807 - 2")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "-9223372036854775809\n", "")
    r = q("4611686018427387904 * 2")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "9223372036854775808\n", "")
    r = q("9223372036854775807 * 9223372036854775807")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "85070591730234615847396907784232501249\n", "")
    r = q("1000000000000000000000000000000000 + 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1000000000000000000000000000000001\n", "")


def test_negate_and_minint_edges(q):
    # CATCHES: -1 * minint must produce the positive big integer
    # 9223372036854775808 rather than overflowing back to minint, and both
    # division and modulo by -1 handle minint without wrapping.
    r = q("-1 * (-9223372036854775807 - 1)")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "9223372036854775808\n", "")
    r = q("(-9223372036854775807 - 1) / -1")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "9223372036854775808\n", "")
    r = q("(-9223372036854775807 - 1) % -1")
    assert (r.returncode, r.stdout, r.stderr) == (0, "0\n", "")
    r = q("5 / -1, 5 % -1")
    assert (r.returncode, r.stdout, r.stderr) == (0, "-5\n0\n", "")


def test_division_exactness_rules(q):
    # CATCHES: exact integer division stays an integer (10/2 is 5, not 5.0),
    # inexact division becomes a float, and big-int division stays exact big
    # when it divides evenly and floats only when it does not.
    r = q("10 / 2, 10 / 4, 10 / 4.0, 10.0 / 4, 8 / 2, -8 / 2, 0.5 / 0.5")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "5\n2.5\n2.5\n2.5\n4\n-4\n1\n", "")
    r = q("100000000000000000000 / 2")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "50000000000000000000\n", "")
    r = q("100000000000000000000 / 3")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "33333333333333330000\n", "")
    r = q("10000000000000000000000000000000 / 2")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "5000000000000000000000000000000\n", "")
    # uneven big division degrades to float64 precision
    r = q("10000000000000000000000000000001 / 2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "5e+30\n", "")


def test_division_by_zero(q):
    # CATCHES: division by zero is a runtime error phrased "cannot divide X
    # by: Y" with the operands previewed, on stderr with exit code 5.
    for query, message in [
        ("1 / 0", "gojq: cannot divide number (1) by: number (0)\n"),
        ("1.0 / 0", "gojq: cannot divide number (1) by: number (0)\n"),
        ("0 / 0", "gojq: cannot divide number (0) by: number (0)\n"),
        ("1.5 / 0", "gojq: cannot divide number (1.5) by: number (0)\n"),
        (
            "100000000000000000000 / 0",
            "gojq: cannot divide number (100000000000000000000)"
            " by: number (0)\n",
        ),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (5, "", message), query


def test_modulo_semantics(q):
    # CATCHES: % truncates float operands toward zero before taking the
    # remainder, keeps Go's truncated (sign-of-dividend) remainder for
    # negatives, and works on big integers exactly.
    r = q("10 % 3, -10 % 3, 10 % -3, 7 % -2, 0 % 5")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1\n-1\n1\n1\n0\n", "")
    r = q("10.5 % 3, -10.5 % 3, 10 % 3.5")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n-1\n1\n", "")
    r = q("100000000000000000000 % 7")
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n", "")
    r = q("1e19 % 3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    # modulo by zero is an error, not a value
    r = q("1 % 0")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot modulo number (1) by: number (0)\n")
    r = q("0 % 0")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot modulo number (0) by: number (0)\n")


def test_string_repetition(q):
    # CATCHES: string * number repeats the string with the count truncated
    # toward zero, negative counts yield null, and results past 2^31-1 bytes
    # raise a "repeat string result too large" error instead of allocating.
    r = q('"abc" * 3, "abc" * 0, "abc" * 2.9, "ab" * 2.5')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '"abcabcabc"\n""\n"abcabc"\n"abab"\n', "")
    # the repetition works with the operands in either order
    r = q('3 * "ab", 2 * "a"')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"ababab"\n"aa"\n', "")
    r = q('"abc" * -1')
    assert (r.returncode, r.stdout, r.stderr) == (0, "null\n", "")
    # an empty string never overflows, even at the clamp boundary
    r = q('"" * 2147483647')
    assert (r.returncode, r.stdout, r.stderr) == (0, '""\n', "")
    r = q('"a" * 2147483647')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: repeat string result too large: "a" * 2147483647\n')
    r = q('"ab" * 2000000000')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: repeat string result too large: "ab" * 2000000000\n')
    r = q("1.5 * 2, 3 * 1.5")
    assert (r.returncode, r.stdout, r.stderr) == (0, "3\n4.5\n", "")


def test_string_array_object_operators(q):
    # CATCHES: + concatenates strings/arrays and shallow-merges objects
    # (right wins); / splits a string by its right operand.
    r = q('"abc" + "def"')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"abcdef"\n', "")
    r = q('"a,b,c" / ",", "abc" / ""')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '["a","b","c"]\n["a","b","c"]\n', "")
    r = q("[1,2] + [3], [] + [1]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2,3]\n[1]\n", "")
    r = q('{"a":1} + {"b":2}, {"a":1} + {"a":2}')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":1,"b":2}\n{"a":2}\n', "")


def test_object_deep_merge_and_array_subtraction(q):
    # CATCHES: object * recursively merges nested objects (right side wins on
    # leaves), while array - removes every element equal to some right-side
    # element (all duplicates, compared with the jq total order).
    r = q('{"a":1,"b":{"x":1}} * {"b":{"y":2}}')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":1,"b":{"x":1,"y":2}}\n', "")
    r = q("[1,2,3] - [2], [1,2,3,2] - [2], [1,2,3] - []")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[1,3]\n[1,3]\n[1,2,3]\n", "")
    r = q("[1,[2],{\"a\":3}] - [[2],[3]]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[1,{"a":3}]\n', "")


def test_null_and_boolean_operand_rules(q):
    # CATCHES: null acts as the identity for + on either side, but is a type
    # error for -, /, %; booleans error in every arithmetic operator.
    r = q("null + 1, 1 + null, null + null")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n1\nnull\n", "")
    r = q("null - 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot subtract: null and number (1)\n")
    r = q("null / 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot divide: null and number (1)\n")
    r = q("true + true")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot add: boolean (true) and boolean (true)\n")
    r = q('{"a":1} - {"a":1}')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: cannot subtract: object ({"a":1})'
              ' and object ({"a":1})\n')


def test_unary_minus_and_plus(q):
    # CATCHES: unary - applies to every output of its operand generator and
    # errors with "cannot negate"/"cannot plus" on non-number types.
    r = q("-(1,2)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "-1\n-2\n", "")
    r = q("- 1 - 2, -1 + 2, 2 - -1, 1 - - - 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "-3\n1\n3\n0\n", "")
    r = q('-"a"')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: cannot negate: string ("a")\n')
    r = q('+"a"')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: cannot plus: string ("a")\n')
    r = q("null | -.")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot negate: null\n")
    r = q("true | -.")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot negate: boolean (true)\n")
    r = q("false | +.")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot plus: boolean (false)\n")


def test_float_overflow_clamps(q):
    # CATCHES: float arithmetic that overflows the float64 range is printed
    # clamped to max float64 (1.7976931348623157e+308) rather than as
    # Infinity or an error.
    r = q("1e308 * 10, 1e308 / 1e-308, 1e1000, 1.5e300 * 1.5e300")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1.7976931348623157e+308\n" * 4, "")
