"""Path tracking: slice and getpath path components, broken-path errors."""


def test_path_of_slice_expressions(q):
    # CATCHES: a slice inside path() becomes ONE path component — an object
    # {"start":..,"end":..} with null for the omitted side, never two
    # separate indices.
    r = q("null | path(.[1:2])")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[{"end":2,"start":1}]\n', "")
    r = q("[1,2,3] | path(.[1:])")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[{"end":null,"start":1}]\n', "")
    r = q("[1,2,3] | path(.[:2])")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[{"end":2,"start":null}]\n', "")


def test_path_through_getpath_and_chained_indices(q):
    # CATCHES: getpath contributes each element as its own path component,
    # and chained index/suffix access builds the flat path in order.
    r = q('{"a":{"b":1}} | path(getpath(["a","b"]))')
    assert (r.returncode, r.stdout, r.stderr) == (0, '["a","b"]\n', "")
    r = q("path(.a[0].b)")
    assert (r.returncode, r.stdout, r.stderr) == (0, '["a",0,"b"]\n', "")


def test_iterating_a_slice_keeps_slice_in_path(q):
    # CATCHES: iterating `.a | .[0:2] | .[]` inside path() emits one path
    # per element with the slice itself kept as the middle component.
    r = q('{"a":[1,2]} | path(.a | .[0:2] | .[])')
    assert (r.returncode, r.stdout, r.stderr) == (
        0,
        '["a",{"end":2,"start":0},0]\n["a",{"end":2,"start":0},1]\n',
        "")


def test_invalid_path_when_stream_leaves_the_path(q):
    # CATCHES: a path expression that filters through a non-path function
    # fails with two distinct wordings — `invalid path on iterating
    # against:` when the NEXT op iterates the foreign value, and
    # `invalid path against:` when the foreign value is the final result
    # or is indexed/sliced directly.
    r = q('{"a":[1,2]} | path(.a | to_entries | .[])')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: invalid path on iterating against: array'
        ' ([{"key":0,"value":1},{"ke ...])\n')
    r = q('{"a":[1,2]} | path(.a | length)')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: invalid path against: number (2)\n")
    r = q('{"a":[1,2]} | path(.a | keys)')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: invalid path against: array ([0,1])\n")
    r = q('{"a":1} | path(.a | tostring | .[0])')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: invalid path against: string ("1")\n')
    r = q('{"a":[1,2]} | path(.a | tostring | .[0:1])')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: invalid path against: string ("[1,2]")\n')


def test_paths_of_nested_input(q):
    # CATCHES: paths lists every path to every value (containers included)
    # in document order — the object key first, then each array element.
    r = q('{"a":[1,2]} | [paths]')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[["a"],["a",0],["a",1]]\n', "")
