"""Comparison operators under the jq total order, and/or/not, and //."""


def test_total_order_type_ranking(q):
    # CATCHES: the jq total order ranks null < false < true < numbers <
    # strings < arrays < objects; every cross-type comparison follows it.
    r = q(
        "[null < false, false < true, true < 0, 0 < \"a\","
        " \"a\" < [1], [1] < {}, null < {}]"
    )
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[true,true,true,true,true,true,true]\n", "")
    r = q("null == null, null == false, 1 == \"1\", [] == [], {} == {}")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\nfalse\nfalse\ntrue\ntrue\n", "")
    r = q("1 <= 1, 1 >= 1, 1 != 1, 1 != 2")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\ntrue\nfalse\ntrue\n", "")


def test_string_comparison_is_byte_order(q):
    # CATCHES: strings compare bytewise (so uppercase sorts before lowercase
    # and multi-byte UTF-8 sorts after all ASCII), not by locale or codepoint.
    r = q('"a" < "b", "A" < "a", "abc" < "abd", "abc" < "ab", "" < "a"')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\ntrue\ntrue\nfalse\ntrue\n", "")
    # 0xC3 (é) is greater than 'z' (0x7A), and 0xC3BF (ÿ) is less than 0xC480 (Ā)
    r = q('"é" < "z", "ÿ" < "Ā"')
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\ntrue\n", "")


def test_array_comparison_is_structural(q):
    # CATCHES: arrays compare element-wise left to right, and a shorter
    # prefix sorts before a longer one regardless of the extra elements.
    r = q("[[1],[2]] < [[1],[3]], [1,2] < [1,2,0], [1,2] < [1,3]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\ntrue\ntrue\n", "")
    r = q("[1,2] == [1,2], [1,2] == [1,2,3], [1,[2]] == [1,[2]]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\nfalse\ntrue\n", "")
    # element comparison is by the total order, so [null] sorts before [false]
    r = q("[null] < [false], [[0]] < [[\"a\"]]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\ntrue\n", "")


def test_object_comparison(q):
    # CATCHES: objects compare by their sorted key arrays first, then by the
    # values for each shared key in sorted-key order.
    r = q('{} < {"a":1}, {"a":1} < {"a":1,"b":0}, {"a":1} < {"a":2}')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\ntrue\ntrue\n", "")
    # {"b":..} has a bigger key array than {"a":..}, so it sorts after
    r = q('{"b":1} < {"a":2}')
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\n", "")
    # key order in the literal does not matter for equality
    r = q('{"a":1,"b":2} == {"b":2,"a":1}, {"a":1,"b":2} == {"a":1}')
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\nfalse\n", "")


def test_number_equality_across_representations(q):
    # CATCHES: int, float and big-int representations of the same value
    # compare equal, but the comparison of a big int against a float goes
    # through float64, so 9007199254740993 equals its rounded float literal.
    r = q("1 == 1.0, 10000000000000000000 == 10000000000000000000.0")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\ntrue\n", "")
    r = q("9007199254740993 == 9007199254740993.0")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\n", "")
    r = q("10000000000000000000 < 10000000000000000001, 1 < 1.5, 1.5 < 2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\ntrue\ntrue\n", "")
    # float arithmetic noise still breaks equality
    r = q("0.1 + 0.2 == 0.3, 1 == 1.00000000000000001")
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\ntrue\n", "")


def test_nan_comparisons(q):
    # CATCHES: NaN sorts before every other number (so nan < nan is true)
    # while NaN == NaN is false, and NaN is printed as null.
    r = q("nan == nan, nan < nan, nan < 1, 1 < nan, nan == 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "false\ntrue\ntrue\nfalse\nfalse\n", "")
    r = q("nan < infinite, -infinite < nan")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\nfalse\n", "")
    r = q("[nan] == [nan]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\n", "")
    r = q("nan, [nan, infinite]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "null\n[null,1.7976931348623157e+308]\n", "")


def test_infinity_comparisons(q):
    # CATCHES: infinite compares larger than any big integer, -infinite
    # smaller, and infinite == infinite holds.
    r = q("infinite > 10000000000000000000, infinite == infinite")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\ntrue\n", "")
    r = q("-infinite < -10000000000000000000, [infinite] > [1e308]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\ntrue\n", "")


def test_and_or_truthiness_and_short_circuit(q):
    # CATCHES: only null and false are falsy (0, "", [], {} are truthy), and
    # and/or short-circuit so the right operand is never evaluated when the
    # left already decides the result.
    r = q("1 and 2, null and 1, false and 1, 1 and null, null and null")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\nfalse\nfalse\nfalse\nfalse\n", "")
    r = q("1 or 2, null or 2, false or false, null or null")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\ntrue\nfalse\nfalse\n", "")
    r = q('0 and 1, "" and 1, [] and 1, {} and 1')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "true\ntrue\ntrue\ntrue\n", "")
    r = q('false and error("x")')
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\n", "")
    r = q('true or error("x")')
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\n", "")
    # a generator left operand runs per value; its error still surfaces
    r = q('(1,error("x")) and true')
    assert (r.returncode, r.stdout, r.stderr) == (5, "true\n", "gojq: error: x\n")
    r = q('(error("x"),1) and true')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: error: x\n")


def test_not_function(q):
    # CATCHES: `not` negates jq truthiness (only null/false are falsy).
    r = q("1|not")
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\n", "")
    r = q("null|not")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\n", "")
    r = q("false|not")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\n", "")
    r = q('"x"|not')
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\n", "")
    r = q("[]|not")
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\n", "")
    r = q("{}|not")
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\n", "")


def test_alternative_operator(q):
    # CATCHES: // yields the left values that are neither null nor false and
    # only falls back to the right side when the left stream produced none,
    # but errors on the left still propagate (they are not swallowed).
    r = q('null // 1, false // 1, true // 1, 0 // 1, "" // 1, [] // 1')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1\n1\ntrue\n0\n\"\"\n[]\n", "")
    r = q("(null,false,empty,1) // 2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    r = q("(1,null) // 2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    r = q('(1, null, false) // (10, 20)')
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    # error() values are not treated as falsy by //
    r = q('error("x") // 42')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: error: x\n")
    r = q('(1,error("x")) // 42')
    assert (r.returncode, r.stdout, r.stderr) == (5, "1\n", "gojq: error: x\n")
