"""Module loading: include/import via -L, data modules, and modulemeta."""

MOD = "def double: . * 2;\ndef triple: . * 3;\n"


def _write(tmp_path, name, content):
    path = tmp_path / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return path


def test_include_and_import_with_alias(run_gojq, tmp_path):
    # CATCHES: include pulls definitions into the current scope while
    # `import ... as m` namespaces them as m::name, and a missing module
    # is a compile error (exit 3) naming the quoted module path.
    _write(tmp_path, "lib/mymod.jq", MOD)
    r = run_gojq(["-c", "-n", "-L", "lib", 'include "mymod"; 5 | double'])
    assert (r.returncode, r.stdout, r.stderr) == (0, "10\n", "")
    r = run_gojq(["-c", "-n", "-L", "lib",
                  'import "mymod" as m; 5 | m::triple, m::double'])
    assert (r.returncode, r.stdout, r.stderr) == (0, "15\n10\n", "")
    r = run_gojq(["-c", "-n", 'include "pgsynth_missing_module_xyz"; 1'])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "",
        'gojq: compile error: module not found: "pgsynth_missing_module_xyz"\n')


def test_module_parse_error_is_invalid_query(run_gojq, tmp_path):
    # CATCHES: a syntax error inside a loaded module is reported as
    # `gojq: invalid query: <module-file>:<line>` with the same caret
    # formatting as a bad main query, and still exits 3.
    _write(tmp_path, "lib/bad.jq", "def broken(: 1;\n")
    r = run_gojq(["-c", "-n", "-L", "lib", 'include "bad"; 1'])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "",
        "gojq: invalid query: lib/bad.jq:1\n"
        "    1 | def broken(: 1;\n"
        '                   ^  unexpected token ":"\n')


def test_data_module_import_always_wraps_in_array(run_gojq, tmp_path):
    # CATCHES: `import "x" as $d` binds $d to an ARRAY of every JSON value
    # in the file — a single value is wrapped, several values accumulate,
    # an empty file gives [], and a missing data module is a compile error.
    _write(tmp_path, "lib/data.json", '{"x": 42}\n')
    r = run_gojq(["-c", "-n", "-L", "lib", 'import "data" as $d; $d'])
    assert (r.returncode, r.stdout, r.stderr) == (0, '[{"x":42}]\n', "")
    _write(tmp_path, "lib/multi.json", '{"x":42}\n{"y":1}\n')
    r = run_gojq(["-c", "-n", "-L", "lib", 'import "multi" as $d; $d'])
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[{"x":42},{"y":1}]\n', "")
    _write(tmp_path, "lib/empty.json", "")
    r = run_gojq(["-c", "-n", "-L", "lib", 'import "empty" as $d; $d'])
    assert (r.returncode, r.stdout, r.stderr) == (0, "[]\n", "")
    r = run_gojq(["-c", "-n", "-L", "lib",
                  'import "nonexistent_data" as $d; $d'])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "", 'gojq: compile error: module not found: "nonexistent_data"\n')


def test_module_alias_visibility(run_gojq, tmp_path):
    # CATCHES: a module's own imports stay private — its `m::f` names are
    # not re-exported through the importing alias (u::f is undefined even
    # though uses.jq imports meta), while its own definitions are.
    _write(tmp_path, "lib/meta.jq", "def f: 1;\n")
    _write(tmp_path, "lib/uses.jq",
           'module {a: 1};\nimport "meta" as m;\ndef h: 3;\n')
    r = run_gojq(["-c", "-n", "-L", "lib", 'import "uses" as u; u::h'])
    assert (r.returncode, r.stdout, r.stderr) == (0, "3\n", "")
    r = run_gojq(["-c", "-n", "-L", "lib", 'import "uses" as u; u::f'])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "", "gojq: compile error: function not defined: u::f/0\n")


def test_modulemeta_reports_defs_and_deps(run_gojq, tmp_path):
    # CATCHES: modulemeta returns the module's metadata object plus a
    # sorted `defs` list and a `deps` entry per import with relpath, alias
    # (`as` without the $), and is_data false for function imports.
    _write(tmp_path, "lib/meta.jq", "def f: 1;\n")
    _write(tmp_path, "lib/uses.jq",
           'module {a: 1};\nimport "meta" as m;\ndef h: 3;\n')
    r = run_gojq(["-c", "-n", "-L", "lib", '"uses" | modulemeta'])
    assert (r.returncode, r.stdout, r.stderr) == (
        0,
        '{"a":1,"defs":["h/0"],'
        '"deps":[{"as":"m","is_data":false,"relpath":"meta"}]}\n',
        "")


def test_transitive_include(run_gojq, tmp_path):
    # CATCHES: a module may itself include another module; its definitions
    # become visible both through the alias and via a direct include.
    _write(tmp_path, "lib/mymod2.jq", "def q: 99;\n")
    _write(tmp_path, "lib/inc.jq", 'include "mymod2";\n')
    r = run_gojq(["-c", "-n", "-L", "lib", 'import "inc" as i; i::q'])
    assert (r.returncode, r.stdout, r.stderr) == (0, "99\n", "")
    r = run_gojq(["-c", "-n", "-L", "lib", 'include "inc"; q'])
    assert (r.returncode, r.stdout, r.stderr) == (0, "99\n", "")
