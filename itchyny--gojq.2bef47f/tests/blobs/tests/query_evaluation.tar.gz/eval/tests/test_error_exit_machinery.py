"""Error values, halt, and the compile-error/exit-code machinery."""


def test_error_values_propagate_to_top_level(q):
    # CATCHES: an uncaught error() terminates the whole run with exit 5 and
    # `gojq: error: <v>` on stderr for every value shape — strings verbatim,
    # non-strings via compact JSON, and null stays `error: null`.
    for query, message in [
        ('error("x")', "gojq: error: x\n"),
        ("error({a:1})", 'gojq: error: {"a":1}\n'),
        ("error(null)", "gojq: error: null\n"),
        ("error", "gojq: error: null\n"),
        ("error(5)", "gojq: error: 5\n"),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (5, "", message), query


def test_halt_and_halt_error(q):
    # CATCHES: halt stops evaluation silently with exit 0; halt_error exits
    # 5 by default, writes a STRING value to stderr without a trailing
    # newline, JSON-encodes non-strings with a newline, honors a custom
    # exit code, and is not catchable by try/catch.
    r = q("1, halt, 2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    r = q("halt_error")
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "")
    r = q('"boom" | halt_error')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "boom")
    r = q("{a:1} | halt_error")
    assert (r.returncode, r.stdout, r.stderr) == (5, "", '{"a":1}\n')
    r = q('"code" | halt_error(3)')
    assert (r.returncode, r.stdout, r.stderr) == (3, "", "code")
    r = q("1, halt_error, 2")
    assert (r.returncode, r.stdout, r.stderr) == (5, "1\n", "")
    r = q('try halt_error catch "caught"')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "")


def test_compile_error_variables_labels_and_names(q):
    # CATCHES: post-parse compile problems all print
    # `gojq: compile error: <msg>` with exit 3 — undefined variables
    # (including the unsupported $__loc__), break of an undefined label,
    # errors nested arbitrarily deep, and invalid --arg variable names.
    for query, message in [
        ("$x", "gojq: compile error: variable not defined: $x\n"),
        ("$__loc__", "gojq: compile error: variable not defined: $__loc__\n"),
        ("label $a | break $b", "gojq: compile error: label not defined: $b\n"),
        ("1 + $x", "gojq: compile error: variable not defined: $x\n"),
        ("def f($a): $a + $b; f(1)",
         "gojq: compile error: variable not defined: $b\n"),
        ("try $x catch .", "gojq: compile error: variable not defined: $x\n"),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (3, "", message), query


def test_arg_variable_name_validated_at_compile(run_gojq):
    # CATCHES: --arg names that are not valid jq identifiers are rejected
    # as `compile error: invalid variable name: $<name>` with exit 3.
    r = run_gojq(["-c", "-n", "--arg", "1abc", "v", "$ARGS"])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "", "gojq: compile error: invalid variable name: $1abc\n")
    r = run_gojq(["-c", "-n", "--arg", "a-b", "v", "$a_b"])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "", "gojq: compile error: invalid variable name: $a-b\n")


def test_format_not_defined_and_interpolation(q):
    # CATCHES: an unknown @format is a RUNTIME error (`gojq: format not
    # defined: @foo`, exit 5) raised only when the format is actually
    # applied — a plain string literal after it passes through untouched.
    r = q("@foo")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: format not defined: @foo\n")
    r = q('@foo "x"')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"x"\n', "")
    r = q('@foo "a\\(1)"')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: format not defined: @foo\n")
    r = q('@base64 "a\\(1)"')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"aMQ=="\n', "")
    r = q('@json "x\\(1)"')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"x1"\n', "")


def test_alternative_operator_does_not_catch_errors(q):
    # CATCHES: `//` falls through only on false/null outputs — an error on
    # the left side (even after some values were produced) aborts the whole
    # expression with exit 5 instead of evaluating the alternative, and an
    # erroring right side propagates too.
    r = q('error("x") // 42')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: error: x\n")
    r = q('(1, error("x")) // 42')
    assert (r.returncode, r.stdout, r.stderr) == (5, "1\n", "gojq: error: x\n")
    r = q('null // error("y")')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: error: y\n")
