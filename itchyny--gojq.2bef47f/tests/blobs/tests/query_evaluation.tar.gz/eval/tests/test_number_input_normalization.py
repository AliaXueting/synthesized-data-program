"""Input numbers (json.Number) and big-int/float normalization paths."""


def test_input_numbers_printed_verbatim(run_gojq):
    # CATCHES: numbers read from input are echoed byte-for-byte without
    # normalization — `1e400` keeps its literal shape even though it
    # overflows float64, and huge integer literals keep every digit.
    r = run_gojq(["-c", "."], stdin="1e400")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1e400\n", "")
    r = run_gojq(["-c", "."], stdin="4722366482869645213696")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "4722366482869645213696\n", "")
    r = run_gojq(["-c", "."], stdin="1" + "0" * 400)
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1" + "0" * 400 + "\n", "")


def test_input_numbers_normalized_by_operators(run_gojq):
    # CATCHES: the first arithmetic operation normalizes an input number:
    # out-of-range exponents clamp to ±1.7976931348623157e+308, integer
    # literals beyond int64 stay exact big ints, mixing a float loses
    # precision, and 1e19 (past int64) prints with all its zeros.
    r = run_gojq(["-c", ". + 0"], stdin="1e400")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1.7976931348623157e+308\n", "")
    r = run_gojq(["-c", ". + 0"], stdin="-1e400")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "-1.7976931348623157e+308\n", "")
    r = run_gojq(["-c", ". + 0"], stdin="4722366482869645213696")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "4722366482869645213696\n", "")
    r = run_gojq(["-c", ". + 0.0"], stdin="4722366482869645213696")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "4.722366482869645e+21\n", "")
    r = run_gojq(["-c", ". + 0"], stdin="1" + "0" * 400)
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1" + "0" * 400 + "\n", "")
    r = run_gojq(["-c", ". + 0.5"], stdin="1" + "0" * 400)
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1.7976931348623157e+308\n", "")
    r = run_gojq(["-c", ". + 0"], stdin="1e19")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "10000000000000000000\n", "")
    r = run_gojq(["-c", ".a + 0"], stdin='{"a": 1e400}')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1.7976931348623157e+308\n", "")
    r = run_gojq(["-c", ". == 1"], stdin="1.0")
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\n", "")


def test_negate_and_plus_on_input_numbers(run_gojq):
    # CATCHES: negating an input number is textual for the json.Number
    # representation: `0` becomes `-0` and `-0` becomes `0`, floats and
    # huge literals flip sign, and unary `+` returns the value unchanged.
    for stdin, out in [
        ("0", "-0\n"),
        ("-0", "0\n"),
        ("1.5", "-1.5\n"),
        ("1e400", "-1e400\n"),
        ("1" + "0" * 33, "-" + "1" + "0" * 33 + "\n"),
    ]:
        r = run_gojq(["-c", "-."], stdin=stdin)
        assert (r.returncode, r.stdout, r.stderr) == (0, out, ""), stdin
    r = run_gojq(["-c", "+."], stdin="3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "3\n", "")


def test_bigint_float_interplay_and_indexing(q):
    # CATCHES: big ints convert to float64 for mixed comparisons/arithmetic
    # (10^33 > 1e30, and 10^400 overflows to +MaxFloat64), a big-int index
    # clamps instead of erroring (null / empty slice / unbounded limit),
    # and big-int * -1 uses the exact negate path.
    r = q("(1" + "0" * 33 + ", 1) | . < 1e30")
    assert (r.returncode, r.stdout, r.stderr) == (0, "false\ntrue\n", "")
    r = q("1e30 < 1" + "0" * 33)
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\n", "")
    r = q("1" + "0" * 33 + " == 1" + "0" * 33)
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\n", "")
    r = q("1" + "0" * 33 + " - 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "9" * 33 + "\n", "")
    r = q("1" + "0" * 33 + " * -1")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "-" + "1" + "0" * 33 + "\n", "")
    r = q("[1,2] | .[10000000000000000000]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "null\n", "")
    r = q("[1,2] | .[10000000000000000000:]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[]\n", "")
    r = q('"abcdef" | .[10000000000000000000:]')
    assert (r.returncode, r.stdout, r.stderr) == (0, '""\n', "")
    r = q("limit(10000000000000000000; 1,2)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n2\n", "")


def test_modulo_and_type_error_operand_pairs(q):
    # CATCHES: float modulo truncates the divisor toward zero first, so
    # `1.5 % 0.5` is a divide-by-zero-style error with the
    # `cannot modulo <l> by: <r>` wording; NaN modulo yields NaN (printed
    # as null); non-number pairs of the same type error with both operands
    # previewed; and big ints preview truncated with a bare ` ...`.
    for query, code, out, err in [
        ("1.5 % 0.5", 5, "",
         "gojq: cannot modulo number (1.5) by: number (0.5)\n"),
        ("1.5 % 0", 5, "",
         "gojq: cannot modulo number (1.5) by: number (0)\n"),
        ("nan % 1, -nan % 1", 0, "null\nnull\n", ""),
        ("1" + "0" * 33 + " % 0", 5, "",
         "gojq: cannot modulo number (10000000000000000000000000 ...) by: number (0)\n"),
        ("1" + "0" * 33 + " % 7", 0, "6\n", ""),
        ('"a" * "b"', 5, "",
         'gojq: cannot multiply: string ("a") and string ("b")\n'),
        ("[1] / [1]", 5, "",
         "gojq: cannot divide: array ([1]) and array ([1])\n"),
        ("{} % {}", 5, "",
         "gojq: cannot modulo: object ({}) and object ({})\n"),
        ('"" + "x", "x" + ""', 0, '"x"\n"x"\n', ""),
        ("[] + [1], [1] + []", 0, "[1]\n[1]\n", ""),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (code, out, err), query
