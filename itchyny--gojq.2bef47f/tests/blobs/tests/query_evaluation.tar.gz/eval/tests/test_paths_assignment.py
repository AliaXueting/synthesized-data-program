"""Path expressions, getpath/setpath/delpaths, and assignment operators."""


def test_path_expression_basics(q):
    # CATCHES: path() reports the concrete paths its filter visits, including
    # array indices, and a comma of paths yields each path separately.
    r = q('{"a":{"b":1}} | path(.a.b)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '["a","b"]\n', "")
    r = q('{"a":[1,2]} | [path(.a[0]), path(.a[1])]')
    assert (r.returncode, r.stdout, r.stderr) == (0, '[["a",0],["a",1]]\n', "")
    r = q('path(.a[0].b)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '["a",0,"b"]\n', "")
    r = q('{"a":1} | path(.a, .a)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '["a"]\n["a"]\n', "")
    r = q('{"a":1} | path(.[])')
    assert (r.returncode, r.stdout, r.stderr) == (0, '["a"]\n', "")
    r = q("[1] | path(.[])")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[0]\n", "")
    # indexing past missing keys still reports the would-be path
    r = q('{"a":1} | path(.b.c)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '["b","c"]\n', "")


def test_path_expression_control_forms(q):
    # CATCHES: path() tracks through if-branches, //, first(), getpath, `as`
    # bindings and reduce; select() contributes the empty path and empty
    # contributes no path at all.
    for query, expected in [
        ('{"a":1} | path(if true then .a else .b end)', '["a"]\n'),
        ('{"a":1} | path(.a // .b)', '["a"]\n'),
        ('{"a":1} | path(first(.a))', '["a"]\n'),
        ('{"a":1} | path(getpath(["a"]))', '["a"]\n'),
        ('{"a":1} | path(.a | .)', '["a"]\n'),
        ('{"a":1} | path(.a | length)', '["a"]\n'),
        ('{"a":1} | path(.a as $x | .b)', '["b"]\n'),
        ('{"a":1} | path(select(true))', "[]\n"),
        ('{"a":1} | path(reduce .[] as $x (.; .))', "[]\n"),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (0, expected, ""), query
    r = q('{"a":1} | path(empty)')
    assert (r.returncode, r.stdout, r.stderr) == (0, "", "")


def test_invalid_path_errors(q):
    # CATCHES: a filter that produces a value instead of a path fails with
    # "invalid path against: <value>"; gojq has no leaf_paths builtin.
    r = q('{"a":1} | path(1)')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: invalid path against: number (1)\n")
    # `path(.a) = 5` uses the array as the path target, which is not a path
    r = q('{"a":1} | path(.a) = 5')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: invalid path against: array (["a"])\n')
    r = q("leaf_paths")
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "", "gojq: compile error: function not defined: leaf_paths/0\n")


def test_paths_builtin(q):
    # CATCHES: paths lists every strict subpath (never the root `[]`)
    # depth-first in document order, and scalars have no paths at all.
    r = q('{"a":{"b":1}} | [paths]')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[["a"],["a","b"]]\n', "")
    r = q('{"a":[1,"x",2]} | [paths]')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[["a"],["a",0],["a",1],["a",2]]\n', "")
    r = q("[[1,2],[3]] | [paths]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[[0],[0,0],[0,1],[1],[1,0]]\n", "")
    for query in ["1 | [paths]", '"a" | [paths]', "[] | [paths]",
                  "{} | [paths]"]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (0, "[]\n", ""), query


def test_getpath_semantics(q):
    # CATCHES: getpath walks missing keys through null instead of erroring,
    # and an empty path returns the input unchanged.
    r = q('{"a":{"b":2}} | getpath(["a","b"])')
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n", "")
    r = q("null | getpath([\"a\",\"b\"])")
    assert (r.returncode, r.stdout, r.stderr) == (0, "null\n", "")
    r = q('{"a":1} | getpath([])')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1}\n', "")
    r = q('{"a":1} | getpath(["a"])')
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")


def test_getpath_type_errors(q):
    # CATCHES: getpath wraps inner type errors with the path echoed and uses
    # two different wordings: "cannot be applied to <input>: <reason>" for a
    # bad path argument and "cannot be applied to: <input>" for a bad input.
    for query, message in [
        ('{"a":1} | getpath(["a","b"])',
         'gojq: getpath(["a","b"]) cannot be applied to {"a":1}:'
         " expected an object but got: number (1)\n"),
        ('{"a":1} | getpath(["a",0])',
         'gojq: getpath(["a",0]) cannot be applied to {"a":1}:'
         " expected an array but got: number (1)\n"),
        ('{"a":1} | getpath("a")',
         'gojq: getpath("a") cannot be applied to: object ({"a":1})\n'),
        ('{"a":1} | getpath([null])',
         'gojq: getpath([null]) cannot be applied to {"a":1}:'
         " expected a string for object key but got: null\n"),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (5, "", message), query


def test_setpath_semantics(q):
    # CATCHES: setpath creates missing object keys, pads arrays with nulls up
    # to a positive index, and treats a -1 index as the last element.
    r = q('{"a":{"b":1}} | setpath(["a","b"]; 5)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":{"b":5}}\n', "")
    r = q('{"a":1} | setpath(["b"]; 5)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1,"b":5}\n', "")
    r = q('{"a":[1,2]} | setpath(["a",5]; 5)')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":[1,2,null,null,null,5]}\n', "")
    r = q('{"a":[1,2]} | setpath(["a",-1]; 5)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":[1,5]}\n', "")
    r = q('[1,2,3] | setpath([{"start":1,"end":2}]; [9])')
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,9,3]\n", "")
    # wrong key type for the container is an error naming the path
    r = q('{"a":1} | setpath(["a","b"]; 5)')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: setpath(["a","b"]; 5) cannot be applied to {"a":1}:'
        " expected an object but got: number (1)\n",)


def test_plain_assignment(q):
    # CATCHES: `=` replaces each matched path with the right side evaluated
    # once per RHS output against the ORIGINAL input, creating structure as
    # needed.
    r = q('{"a":[1,2,3]} | .a[1] = 9')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":[1,9,3]}\n', "")
    r = q(".a.b.c = 1")
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":{"b":{"c":1}}}\n', "")
    r = q('[1,2,3] | .[1] = 9 | .[0] = 8')
    assert (r.returncode, r.stdout, r.stderr) == (0, "[8,9,3]\n", "")
    # a generator RHS produces one output per value
    r = q('{"a":1} | .a = (1,2)')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":1}\n{"a":2}\n', "")
    r = q('{"a":1} | (1,2) as $x | .a = $x')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":1}\n{"a":2}\n', "")
    # a path generator on the left assigns to every path it visits
    r = q('{"a":1} | .[("a","b")] = 5')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":5,"b":5}\n', "")
    r = q('[1,2] | (.[0], .[1]) = 9')
    assert (r.returncode, r.stdout, r.stderr) == (0, "[9,9]\n", "")
    # RHS reads the ORIGINAL input, not a partially assigned one
    r = q('{"a":1,"b":2} | .a = .b')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":2,"b":2}\n', "")
    r = q('[1,2] | .[0] = .[1]')
    assert (r.returncode, r.stdout, r.stderr) == (0, "[2,2]\n", "")


def test_assignment_index_and_type_errors(q):
    # CATCHES: out-of-range and fractional indices extend arrays, while a
    # string key on an array (or any key on a scalar) is a setpath error.
    r = q("[1] | .[3] = 7")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,null,null,7]\n", "")
    r = q("[1] | .[-1] = 7")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[7]\n", "")
    r = q("[1] | .[1.5] = 7")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,7]\n", "")
    r = q('[1] | .["a"] = 7')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: setpath(["a"]; 7) cannot be applied to [1]:'
        " expected an object but got: array ([1])\n")
    r = q("1 | .a = 5")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: setpath(["a"]; 5) cannot be applied to 1:'
        " expected an object but got: number (1)\n")
    r = q('"a" | .a = 5')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: setpath(["a"]; 5) cannot be applied to "a":'
        ' expected an object but got: string ("a")\n')
    # an error mid-RHS keeps the outputs already produced
    r = q('{"a":1} | .a = (1,error("x"))')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, '{"a":1}\n', "gojq: error: x\n")
    r = q('{"a":1} | .a = (error("x"))')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: error: x\n")


def test_modify_update_assignment(q):
    # CATCHES: `|=` applies the update to the current value at each path,
    # keeps only the FIRST output of a multi-output update, deletes the key
    # when the update yields empty, and binds tighter than the comma.
    r = q('{"a":1} | .a |= . + 1')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":2}\n', "")
    r = q('{"a":{"b":1}} | .a.b |= . + 1')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":{"b":2}}\n', "")
    r = q('{"a":1} | .a |= (1,2)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1}\n', "")
    r = q("[1,2] | .[0] |= (1,2)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2]\n", "")
    r = q('{"a":1} | .a |= empty')
    assert (r.returncode, r.stdout, r.stderr) == (0, "{}\n", "")
    # an erroring update after a good output keeps the first output
    r = q('{"a":1} | .a |= (1,error("e"))')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1}\n', "")
    # `|=` binds tighter than `,`: this is `.a, (.b |= .+1)`
    r = q('{"a":1} | .a, .b |= .+1')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '1\n{"a":1,"b":1}\n', "")
    r = q('[[1,2],[3,4]] | (.[0], .[1]) |= . + [9]')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[[1,2,9],[3,4,9]]\n", "")
    # update over every element and over every recursive path
    r = q("[1,2] | .[] |= . + 1")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[2,3]\n", "")
    r = q('{"a":1,"b":[2]} | (.. |= (if type == "number" then . + 1 else . end))')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":2,"b":[3]}\n', "")
    # an erroring update body surfaces the error value
    r = q('{"a":1} | .a |= error')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: error: 1\n")


def test_arithmetic_update_assignments(q):
    # CATCHES: += -= *= /= %= //= update in place using the matching operator
    # (string repeat, array concat, string split all included) and //= only
    # fires when the current value is null or false.
    r = q('{"a":1} | .a += 1, (.a -= 1)')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":2}\n{"a":0}\n', "")
    r = q('{"a":2} | .a *= 3, (.a /= 2), (.a %= 2)')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":6}\n{"a":1}\n{"a":0}\n', "")
    r = q('{"a":null} | .a //= 5')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":5}\n', "")
    r = q('{"a":1} | .a //= 5')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1}\n', "")
    r = q('{"a":1} | .b //= 5')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1,"b":5}\n', "")
    r = q('{"a":1,"b":2} | .a += .b')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":3,"b":2}\n', "")
    r = q("[1,2] | .[] += 10")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[11,12]\n", "")
    r = q('{"a":[1,2]} | .a += [3]')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":[1,2,3]}\n', "")
    r = q('{"a":"x"} | .a *= 3')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":"xxx"}\n', "")
    r = q('{"a":"abc"} | .a /= ""')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":["a","b","c"]}\n', "")
    # //= with a generator RHS emits one output per alternative value
    r = q('{"a":null} | .a //= (5,6)')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":5}\n{"a":6}\n', "")
    r = q('{"a":1} | .a //= (5,6)')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":1}\n{"a":1}\n', "")


def test_del_and_delpaths(q):
    # CATCHES: del removes every path its filter visits (deduplicated from
    # the left, so deleting .[0] twice removes two elements), slices can be
    # deleted too, and deleting a missing key is a no-op.
    r = q("[1,2,3] | del(.[1])")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,3]\n", "")
    r = q("[1,2,3] | del(.[1],.[2])")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1]\n", "")
    r = q("[1,2,3] | del(.[0], .[0])")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[2,3]\n", "")
    r = q('{"a":1,"b":2} | del(.a), del(.a,.b)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"b":2}\n{}\n', "")
    r = q("[[1,2],[3,4]] | del(.[0][1])")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[[1],[3,4]]\n", "")
    r = q("[1,2,3] | del(.[1:3]), del(.[0:2])")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1]\n[3]\n", "")
    r = q('{"a":1} | del(.b)')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1}\n', "")
    r = q('[1,2,3] | del(.[] | select(. == 2))')
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,3]\n", "")
    r = q('{"a":1,"b":2} | delpaths([["a"],["b"]])')
    assert (r.returncode, r.stdout, r.stderr) == (0, "{}\n", "")
    r = q("1 | del(.a)")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: expected an object but got: number (1)\n")


def test_slice_assignment(q):
    # CATCHES: slice assignment replaces the slice with the RHS array
    # (growing or shrinking the array), inserts at a zero-width or reversed
    # range, and clamps negative bounds from the end.
    r = q("[1,2,3] | .[1:2] = [9], (.[0:0] = [9])")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[1,9,3]\n[9,1,2,3]\n", "")
    r = q("[1,2,3] | .[2:1] = [9]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2,9,3]\n", "")
    r = q("[1,2,3] | .[-2:] = [9], (.[:-2] = [9])")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[1,9]\n[9,2,3]\n", "")
    r = q("[1,2,3] | .[1:] = [9,9,9]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,9,9,9]\n", "")
    r = q('{"a":[1,2,3]} | .a[1:] = []')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":[1]}\n', "")
    r = q("[1,2,3] | .[1:2] = [9] | .[2:3] = [8]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,9,8]\n", "")
    # the RHS of a slice assignment must be an array
    r = q('{"a":[1,2,3]} | .a[1:2] = 9')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: setpath(["a",{"end":2,"start":1}]; 9) cannot be applied'
        ' to {"a":[1,2,3]}: expected an array but got: number (9)\n')
    r = q('{"a":[1,2,3]} | .a[1:] = null')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: setpath(["a",{"end":null,"start":1}]; null) cannot be'
        ' applied to {"a":[1,2,3]}: expected an array but got: null\n')
    # strings cannot be slice-assigned; the error echoes the sorted-key path
    r = q('"abcdef" | .[1:3] = "XY"')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: setpath([{"end":3,"start":1}]; "XY") cannot be applied'
        ' to "abcdef": expected an array but got: string ("abcdef")\n')
    # a slice update applies a filter to the slice as an array
    r = q("[1,2,3] | .[1:3] |= map(.*10)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,20,30]\n", "")
    r = q('{"a":[1,2,3]} | .a[1:2] |= [.[0]+5]')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":[1,7,3]}\n', "")
    r = q('"abcdef" | .[1:3] |= ascii_upcase')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: setpath([{"end":3,"start":1}]; "BC") cannot be applied'
        ' to "abcdef": expected an array but got: string ("abcdef")\n')
