"""Runtime type error wording: operator names, types, and value previews."""


def test_binop_type_error_wording(q):
    # CATCHES: every arithmetic operator has its own verb in the error
    # ("cannot add", "cannot subtract", ...) with both operands shown as
    # `type (preview)`, on stderr with exit code 5.
    for query, message in [
        ('1 + "a"', 'gojq: cannot add: number (1) and string ("a")\n'),
        ('1 - "a"', 'gojq: cannot subtract: number (1) and string ("a")\n'),
        ('2 * ["a"]', 'gojq: cannot multiply: number (2) and array (["a"])\n'),
        ('1 * {}', 'gojq: cannot multiply: number (1) and object ({})\n'),
        ('1 / "x"', 'gojq: cannot divide: number (1) and string ("x")\n'),
        ('"x" / 1', 'gojq: cannot divide: string ("x") and number (1)\n'),
        ('[1] % 2', 'gojq: cannot modulo: array ([1]) and number (2)\n'),
        ('{} * 1', 'gojq: cannot multiply: object ({}) and number (1)\n'),
        ('"abc" - 1', 'gojq: cannot subtract: string ("abc") and number (1)\n'),
        ('"abc" - "b"', 'gojq: cannot subtract: string ("abc")'
                        ' and string ("b")\n'),
        ('true + true', 'gojq: cannot add: boolean (true)'
                        ' and boolean (true)\n'),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (5, "", message), query


def test_long_string_preview_truncated(q):
    # CATCHES: error previews truncate string operands at 30 bytes and mark
    # the cut with ` ..."` (quote, space, three dots, closing quote).
    r = q('1 + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: cannot add: number (1)'
        ' and string ("aaaaaaaaaaaaaaaaaaaaaaaa ...")\n')
    r = q('"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + 1')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: cannot add: string ("aaaaaaaaaaaaaaaaaaaaaaaa ...")'
        ' and number (1)\n')


def test_array_preview_truncated(q):
    # CATCHES: array previews truncate to 30 bytes ending in ` ...]`, cutting
    # mid-element (here inside the number 10) without adding a trailing comma.
    r = q("[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20] + 1")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: cannot add: array ([0,1,2,3,4,5,6,7,8,9,10,1 ...])"
        " and number (1)\n")
    r = q("1 + [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: cannot add: number (1)"
        " and array ([0,1,2,3,4,5,6,7,8,9,10,1 ...])\n")


def test_object_preview_truncated(q):
    # CATCHES: object previews truncate to 30 bytes ending in ` ...}` and the
    # keys inside are sorted, so the cut happens after the long "aaa..." key.
    r = q('{"aaaaaaaaaaaaaaaaaaaaaaaaaaaaa":1,"bbbb":2} + 1')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: cannot add: object ({"aaaaaaaaaaaaaaaaaaaaaaa ...})'
        ' and number (1)\n')
    r = q('1 + {"aaaaaaaaaaaaaaaaaaaaaaaaaaaaa":1,"bbbb":2}')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: cannot add: number (1)'
        ' and object ({"aaaaaaaaaaaaaaaaaaaaaaa ...})\n')


def test_multibyte_preview_truncates_on_rune_boundary(q):
    # CATCHES: preview truncation is byte-limited but never splits a UTF-8
    # sequence, so multi-byte operands keep well-formed text before ` ..."`.
    r = q('"ééééééééééééééééééééééééééé" + 1')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: cannot add: string ("éééééééééééé ...") and number (1)\n')
    r = q('"日本語テキストはここにとても長いです" + 1')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: cannot add: string ("日本語テキストは ...") and number (1)\n')


def test_iteration_and_index_type_errors(q):
    # CATCHES: iterating a non-iterable says "cannot iterate over:", indexing
    # with the wrong key type names the expected type, and a non-string object
    # key is rejected at construction time.
    for query, message in [
        ("null | .[]", "gojq: cannot iterate over: null\n"),
        ("1 | .[]", "gojq: cannot iterate over: number (1)\n"),
        ('"abc" | .[]', 'gojq: cannot iterate over: string ("abc")\n'),
        ("1 | .a", "gojq: expected an object but got: number (1)\n"),
        ("1 | .[0]", "gojq: expected an array but got: number (1)\n"),
        ('{"a":1} | .[0]',
         'gojq: expected an array but got: object ({"a":1})\n'),
        ('"abc" | .["a"]', 'gojq: expected an object but got: string ("abc")\n'),
        ("[1,2,3] | .[true]",
         "gojq: expected a number for indexing an array but got:"
         " boolean (true)\n"),
        ("[1,2,3] | .[null]",
         "gojq: expected a number for indexing an array but got: null\n"),
        ("[1,2,3] | .[\"a\":]",
         'gojq: expected a number for indexing an array but got:'
         ' string ("a")\n'),
        ("{(1): 2}",
         "gojq: expected a string for object key but got: number (1)\n"),
        ('{"a":1} | .a.b', "gojq: expected an object but got: number (1)\n"),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (5, "", message), query
