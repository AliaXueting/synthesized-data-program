"""Shared helpers for the query_evaluation test module.

The program under test is gojq.  These tests pin the semantics of *evaluating*
a well-formed query: the evaluation model (pipes, commas, generators,
backtracking), the operators with jq type rules and arbitrary-precision
integers, comparisons under the jq total order, control flow (if/try/reduce/
foreach/label), paths and assignment, destructuring patterns, string
interpolation, compile-time errors, and the error/exit machinery.
"""

import os
import subprocess
from pathlib import Path

import pytest

# Pinned child environment: no network, no locale or color surprises, and a
# deterministic ``$ENV`` for the queries that read it.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "dumb",
}


def _gojq_bin():
    """Resolve the reference binary through PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the gojq binary under test"
        )
    return path


def _child_env(env=None):
    """The pinned child environment plus coverage forwarding vars."""
    child = dict(CHILD_ENV)
    # The pipeline measures source coverage of the reference binary through
    # GOCOVERDIR; forward it when the test process itself was started with it
    # so an instrumented binary can write its covermeta files.  Read at call
    # time so a per-test override is honored too.
    for key in ("GOCOVERDIR",):
        value = os.environ.get(key)
        if value:
            child[key] = value
    if env:
        # A per-test override (e.g. a variable a query reads through $ENV)
        # layers on top of the pinned environment; everything not named stays
        # pinned.
        child.update(env)
    return child


def _invoke(args, stdin, cwd, timeout, env=None):
    """Spawn gojq with the given argv and capture both output streams."""
    return subprocess.run(
        [_gojq_bin(), *args],
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=cwd,
        env=_child_env(env),
        timeout=timeout,
    )


def run_gojq(args, stdin="", cwd=None, timeout=10, env=None):
    """Run gojq with the given argv list and return the completed process.

    ``args`` is the full argument list after the binary (queries included).
    Most call sites pass ``["-n", "-c", QUERY]`` so the query runs against a
    null input and assertions compare exact compact output.
    """
    return _invoke(args, stdin, cwd, timeout, env)


@pytest.fixture(name="run_gojq")
def run_gojq_fixture(tmp_path):
    """The run_gojq helper, defaulting to an isolated empty cwd."""

    def _run(args, stdin="", cwd=None, timeout=10, env=None):
        return _invoke(args, stdin, cwd or str(tmp_path), timeout, env)

    return _run


@pytest.fixture(name="q")
def q_fixture(run_gojq):
    """Run a null-input compact query and return the completed process."""

    def _run(query, stdin="", env=None):
        return run_gojq(["-n", "-c", query], stdin=stdin, env=env)

    return _run
