"""Evaluation model: streams, pipes, generators, scopes, recursion, labels."""


def test_comma_produces_outputs_in_order(q):
    # CATCHES: comma must emit each branch's outputs left to right, one
    # compact JSON value per line, before the next branch starts.
    r = q("1,2,3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n2\n3\n", "")
    r = q("(1,2), (3,4), 5")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n2\n3\n4\n5\n", "")


def test_pipe_and_comma_precedence(q):
    # CATCHES: `|` binds looser than `,` so `1,2 | . + 1` feeds the whole
    # comma stream through the pipe, not just its right operand.
    r = q("1,2 | . + 1")
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n3\n", "")
    r = q("(1,2 | . + 1), 3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n3\n3\n", "")
    # `//` binds tighter than `,`: the alternative result comes first.
    r = q("1 // 2, 3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n3\n", "")


def test_generator_cartesian_product(q):
    # CATCHES: binary operators evaluate their operands as generators; the
    # left operand drives the outer loop, giving 11,12,21,22 (not 11,21,12,22).
    r = q("(1,2) + (10,20)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "11\n12\n21\n22\n", "")
    r = q("1 + (2,3) + (10,20)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "13\n14\n23\n24\n", "")
    r = q("(1,2) | (., .)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n1\n2\n2\n", "")


def test_duplicate_identity_generator_operand_order(q):
    # CATCHES: when a generator of identity terms `(., .)` feeds the left side
    # of an operator, gojq walks the right operand in the outer loop, so the
    # products group per right value (15,15,25,25) instead of 15,25,15,25.
    r = q("5 | [(. , .) + (10,20)]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[15,15,25,25]\n", "")
    r = q("5 | [(. , .) * (10,20)]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[50,50,100,100]\n", "")
    # A literal duplicate pair keeps the ordinary left-outer order.
    r = q("[(1,1) + (10,20)]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[11,11,21,21]\n", "")


def test_empty_and_partial_streams(q):
    # CATCHES: `empty` produces no output at all (exit 0, empty stdout) and
    # vanishes inside larger streams instead of emitting null.
    r = q("empty")
    assert (r.returncode, r.stdout, r.stderr) == (0, "", "")
    r = q("1, empty, 2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n2\n", "")
    r = q("[empty, 1]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1]\n", "")
    r = q("(empty, 1) + (empty, 10)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "11\n", "")


def test_backtracking_over_iteration(q):
    # CATCHES: `.[] as $x | body` re-runs the body for each element, and a
    # destructuring pattern inside `as` binds per iteration.
    r = q("[[1,2],[3]] | .[] as [$a] | $a")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n3\n", "")
    r = q("[1,2,3] | .[] as $x | $x + 1")
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n3\n4\n", "")
    r = q("[1,2,3] | .[0,1] as $x | $x")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n2\n", "")
    r = q('{"a":1,"b":2} | to_entries[] as {key:$k, value:$v} | [$k,$v]')
    assert (r.returncode, r.stdout, r.stderr) == (0, '["a",1]\n["b",2]\n', "")


def test_definitions_nesting_and_shadowing(q):
    # CATCHES: inner defs are visible only inside their def; a later `def f`
    # shadows an earlier one; `$x` bindings are lexically scoped.
    r = q("def f: def g: 5; g; f")
    assert (r.returncode, r.stdout, r.stderr) == (0, "5\n", "")
    r = q("def f: 1; def f: 2; f")
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n", "")
    # the function body sees the $x binding from its definition site
    r = q("1 as $x | def f: $x; 2 as $x | f")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    r = q("1 as $x | 2 as $x | $x")
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n", "")
    # duplicate parameter names: the last binding wins
    r = q("def f($a; $a): $a; f(1;2)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n", "")


def test_closures_and_deferred_arguments(q):
    # CATCHES: a non-`$` function argument is a closure re-evaluated at every
    # use, while a `$name` argument is bound once per call output.
    r = q("def f(x): x + x; f(1,2)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "2\n3\n3\n4\n", "")
    r = q("def f(g): [g, g]; f(1,2)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2,1,2]\n", "")
    # array construction collects ALL outputs of the closure into one array
    r = q("def f(x): [x]; f(1,2)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2]\n", "")
    r = q("def f($x): [$x]; f(1,2)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1]\n[2]\n", "")
    r = q("def f(x): def g: x; g; f(1)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    r = q("def f(g): g; . as $x | f($x + 1)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")


def test_recursion_and_tail_calls(q):
    # CATCHES: recursion keeps exact big-integer arithmetic, deep non-tail
    # recursion (1000 frames) works, and tail calls do not exhaust the stack
    # even after 100000 iterations.
    r = q(
        "def fact($n): if $n < 2 then 1 else $n * fact($n - 1) end; fact(50)"
    )
    assert (r.returncode, r.stdout, r.stderr) == (
        0,
        "30414093201713378043612608166064768844377641568960512000000000000\n",
        "",
    )
    r = q("def f($n): if $n == 0 then 0 else 1 + f($n - 1) end; f(1000)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1000\n", "")
    r = q("def f($n): if $n == 0 then 0 else f($n - 1) end; f(100000)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "0\n", "")
    r = q("def f: 1, f; [limit(5; f)]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,1,1,1,1]\n", "")
    r = q(
        "def f($n): if $n <= 0 then empty else $n, f($n - 1) end; [f(3)]"
    )
    assert (r.returncode, r.stdout, r.stderr) == (0, "[3,2,1]\n", "")


def test_label_and_break(q):
    # CATCHES: `break $out` stops the labeled body, discarding everything
    # after the break in that stream, and labels nest innermost-first.
    r = q("label $out | 1, break $out, 2")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    r = q("label $out | (1,2) | if . == 2 then break $out else . end")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    r = q("label $a | label $b | 1, break $b, 2, break $a, 3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")
    # a label inside a function def breaks only that function's body
    r = q("def f: label $out | 1, break $out, 2; f, 3")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n3\n", "")
    r = q("[label $out | range(10) | if . > 3 then break $out else . end]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[0,1,2,3]\n", "")
    # breaking out of a reduce discards the accumulated state entirely
    r = q(
        "label $out | reduce (1,2,3) as $x "
        "(0; if . > 2 then break $out else . + $x end)"
    )
    assert (r.returncode, r.stdout, r.stderr) == (0, "", "")
