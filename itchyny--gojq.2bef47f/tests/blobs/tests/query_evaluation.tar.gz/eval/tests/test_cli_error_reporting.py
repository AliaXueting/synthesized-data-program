"""CLI error reporting: parse-error formatting, carets, exit codes.

These pin how the gojq CLI renders errors on stderr (the ``gojq: `` prefix,
the echoed source line, the ``^`` caret line, and the trailing error text)
for invalid queries, invalid JSON/YAML input, flag problems, and the
``--exit-status`` exit-code machinery.
"""


def test_invalid_query_short_form_with_caret(q):
    # CATCHES: a bad single-line query arg is reported as
    # `gojq: invalid query: <query>` followed by the echoed line, a caret
    # under the offending token (column 1-based, one past an EOF position),
    # and the parser message, with exit code 3.
    for query, caret in [
        ("(", "     ^  unexpected EOF\n"),
        ("foo bar", "        ^  unexpected token \"bar\"\n"),
        ("1 +", "       ^  unexpected EOF\n"),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (
            3, "", f"gojq: invalid query: {query}\n    {query}\n{caret}"), query


def test_invalid_query_caret_counts_terminal_cells(q):
    # CATCHES: the caret column is computed in terminal cells (runewidth),
    # not bytes or runes: three 3-byte-wide Japanese chars shift the caret
    # by 6 columns, and a bad leading identifier token points at column 0.
    r = q('.["あいう"] +')
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "",
        'gojq: invalid query: .["あいう"] +\n'
        '    .["あいう"] +\n'
        '                 ^  unexpected EOF\n')
    r = q("あああああ +")
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "",
        'gojq: invalid query: あああああ +\n'
        '    あああああ +\n'
        '    ^  unexpected token "あ"\n')


def test_invalid_query_long_line_window(q):
    # CATCHES: for an error past column 48 the echoed query line is trimmed
    # to a ~64-char window ending near the caret (leading characters are
    # dropped, not the tail), and the caret keeps pointing at the token.
    query = "a" * 50 + " bbb"
    r = q(query)
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "",
        f"gojq: invalid query: {query}\n"
        "    " + "a" * 47 + " bbb\n"
        '                                                    ^  unexpected token "bbb"\n')
    query = "a" * 75 + " bbb ccc"
    r = q(query)
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "",
        f"gojq: invalid query: {query}\n"
        "    " + "a" * 47 + " bbb ccc\n"
        '                                                    ^  unexpected token "bbb"\n')


def test_invalid_query_multiline_and_from_file(run_gojq, tmp_path):
    # CATCHES: once the query spans lines (arg with newline, -f file, or
    # CRLF file), the report switches to `invalid query: <fname>:<line>`
    # with a `<line> | <text>` gutter, and the filename is the -f argument.
    expected = "    2 | 2 +\n           ^  unexpected EOF\n"
    r = run_gojq(["-c", "-n", "1,\n2 +"])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "", "gojq: invalid query: <arg>:2\n" + expected)
    (tmp_path / "q.jq").write_text("1,\n2 +\n")
    r = run_gojq(["-c", "-n", "-f", "q.jq"])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "", "gojq: invalid query: q.jq:2\n" + expected)
    (tmp_path / "crlf.jq").write_bytes(b"1,\r\n2 +\r\n")
    r = run_gojq(["-c", "-n", "-f", "crlf.jq"])
    assert (r.returncode, r.stdout, r.stderr) == (
        3, "", "gojq: invalid query: crlf.jq:2\n" + expected)


def test_invalid_json_stdin_and_files(run_gojq, tmp_path):
    # CATCHES: invalid JSON input exits 5 with `gojq: invalid json: <fname>`;
    # errors on the first line use the short caret form, later lines switch
    # to `<fname>:<line>` with a gutter, earlier values are still printed,
    # and file arguments use the file's name.
    for stdin, out, err in [
        ("{", "", "gojq: invalid json: <stdin>\n    {\n     ^  unexpected EOF\n"),
        ("[1,", "", "gojq: invalid json: <stdin>\n    [1,\n       ^  unexpected EOF\n"),
        ("nul", "", "gojq: invalid json: <stdin>\n    nul\n       ^  unexpected EOF\n"),
        ("1 2\n{", "1\n2\n",
         "gojq: invalid json: <stdin>:2\n    2 | {\n         ^  unexpected EOF\n"),
        ('{"a":1}\n{"b":2}\nxx', '{"a":1}\n{"b":2}\n',
         "gojq: invalid json: <stdin>:3\n    3 | xx\n"
         "        ^  invalid character 'x' looking for beginning of value\n"),
        ("{\n  a: 1", "",
         "gojq: invalid json: <stdin>:2\n    2 |   a: 1\n"
         "          ^  invalid character 'a' looking for beginning of object key string\n"),
    ]:
        r = run_gojq(["-c", "."], stdin=stdin)
        assert (r.returncode, r.stdout, r.stderr) == (5, out, err), stdin
    (tmp_path / "bad.json").write_text("zzz")
    r = run_gojq(["-c", ".", "bad.json"])
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: invalid json: bad.json\n    zzz\n"
        "    ^  invalid character 'z' looking for beginning of value\n")
    (tmp_path / "bad2.json").write_text('{"a":1}\nzzz')
    r = run_gojq(["-c", ".", "bad2.json"])
    assert (r.returncode, r.stdout, r.stderr) == (
        5, '{"a":1}\n',
        "gojq: invalid json: bad2.json:2\n    2 | zzz\n"
        "        ^  invalid character 'z' looking for beginning of value\n")


def test_invalid_json_line_window_truncation(run_gojq):
    # CATCHES: a syntax error far into a long input line still shows only a
    # ~48-char window before the caret (leading text dropped), while a
    # nearby error echoes the whole short line.
    stdin = '{"a": "' + "x" * 80 + '", bbb}'
    r = run_gojq(["-c", "."], stdin=stdin)
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: invalid json: <stdin>\n"
        "    " + "x" * 45 + '", bbb}\n'
        "                                                    ^  invalid character 'b'"
        " looking for beginning of object key string\n")
    r = run_gojq(["-c", "."], stdin='{"a": 1, "b": 2, c: 3}')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        'gojq: invalid json: <stdin>\n'
        '    {"a": 1, "b": 2, c: 3}\n'
        "                     ^  invalid character 'c'"
        " looking for beginning of object key string\n")


def test_invalid_json_from_argjson_jsonargs_slurpfile(run_gojq, tmp_path):
    # CATCHES: JSON values from --argjson/--jsonargs/--slurpfile report as
    # `invalid json` with the variable (`$x`), the literal `--jsonargs`, or
    # the file name in the header, and a multi-line value counts lines.
    r = run_gojq(["-c", "-n", "--argjson", "x", "{", "."])
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: invalid json: $x\n    {\n     ^  unexpected EOF\n")
    r = run_gojq(["-c", "-n", "--argjson", "x", "zz", "."])
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: invalid json: $x\n    zz\n"
        "    ^  invalid character 'z' looking for beginning of value\n")
    r = run_gojq(["-c", "-n", "--argjson", "x", "{\n  a: 1", "$x"])
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: invalid json: $x:2\n    2 |   a: 1\n"
        "          ^  invalid character 'a' looking for beginning of object key string\n")
    r = run_gojq(["-c", "-n", "--jsonargs", "$ARGS", "{"])
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: invalid json: --jsonargs\n    {\n     ^  unexpected EOF\n")
    (tmp_path / "bad.json").write_text("zzz")
    r = run_gojq(["-c", "-n", "--slurpfile", "f", "bad.json", "."])
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: invalid json: bad.json\n    zzz\n"
        "    ^  invalid character 'z' looking for beginning of value\n")


def test_invalid_yaml_input(run_gojq, tmp_path):
    # CATCHES: with --yaml-input, broken YAML reports as
    # `gojq: invalid yaml: <fname>:<line>` with a gutter and caret, using
    # the underlying parser's wording, and file args show the file name.
    for stdin, err in [
        ("a: 1\n b: [2",
         "gojq: invalid yaml: <stdin>:2\n    2 |  b: [2\n"
         "          ^  mapping values are not allowed in this context\n"),
        ("- a\n- b\nx",
         "gojq: invalid yaml: <stdin>:3\n    3 | x\n"
         "        ^  could not find expected ':'\n"),
        ("foo: bar: baz",
         "gojq: invalid yaml: <stdin>:1\n    1 | foo: bar: baz\n"
         "                ^  mapping values are not allowed in this context\n"),
    ]:
        r = run_gojq(["-c", "--yaml-input", "."], stdin=stdin)
        assert (r.returncode, r.stdout, r.stderr) == (5, "", err), stdin
    (tmp_path / "y.yaml").write_text("a: 1\nx: [2\n")
    r = run_gojq(["-c", "--yaml-input", ".", "y.yaml"])
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "",
        "gojq: invalid yaml: y.yaml:2\n    2 | x: [2\n"
        "           ^  did not find expected ',' or ']'\n")


def test_flag_parse_and_indent_errors(run_gojq):
    # CATCHES: unknown flags and missing flag arguments exit 2 with the
    # flag quoted in backticks (short flags lose the dash), while other
    # usage problems like a missing -f file or a bad --indent exit 5.
    for args, code, err in [
        (["--bogus", "."], 2, "gojq: unknown flag `--bogus'\n"),
        (["-Z", "."], 2, "gojq: unknown flag `Z'\n"),
        (["--arg", "."], 2, "gojq: expected 2 arguments for flag `--arg'\n"),
        (["-f"], 5, "gojq: expected a query file for flag `-f'\n"),
        (["--indent", "10", "-n", "1"], 5, "gojq: too many indentation count: 10\n"),
        (["--indent", "-1", "-n", "1"], 5, "gojq: negative indentation count: -1\n"),
    ]:
        r = run_gojq(args)
        assert (r.returncode, r.stdout, r.stderr) == (code, "", err), args


def test_exit_status_exit_codes(run_gojq):
    # CATCHES: -e exits 1 when the LAST output value is false/null, 4 when
    # there is no output at all, 0 for a truthy last value, and an error
    # keeps its own exit code 5 (a halt_error code also wins over -e).
    for args, stdin, code, out, err in [
        (["-c", "-n", "-e", "null"], "", 1, "null\n", ""),
        (["-c", "-n", "-e", "false"], "", 1, "false\n", ""),
        (["-c", "-n", "-e", "empty"], "", 4, "", ""),
        (["-c", "-n", "-e", "1, null"], "", 1, "1\nnull\n", ""),
        (["-c", "-n", "-e", "null, 1"], "", 0, "null\n1\n", ""),
        (["-c", "-n", "-e", 'error("x")'], "", 5, "", "gojq: error: x\n"),
        (["-c", "-e", "."], "", 4, "", ""),
        (["-c", "-e", ".b"], '{"a":1}', 1, "null\n", ""),
        (["-c", "-n", "-e", "halt_error(2)"], "", 2, "", ""),
    ]:
        r = run_gojq(args, stdin=stdin)
        assert (r.returncode, r.stdout, r.stderr) == (code, out, err), args
