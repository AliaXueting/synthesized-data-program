"""Control flow: if/elif, try/catch, `?`, reduce/foreach, recursive descent."""


def test_if_truthiness(q):
    # CATCHES: only null and false are falsy in a condition; 0, "" and every
    # other value take the then branch.
    for query, expected in [
        ("if true then 1 else 2 end", "1\n"),
        ("if false then 1 else 2 end", "2\n"),
        ("if null then 1 else 2 end", "2\n"),
        ("if 0 then 1 else 2 end", "1\n"),
        ('if "" then 1 else 2 end', "1\n"),
        ("if [] then 1 else 2 end", "1\n"),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (0, expected, ""), query
    # a generator condition forks the if per condition value, in order
    r = q('if (false,null,0,"x") then "t" else "f" end')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '"f"\n"f"\n"t"\n"t"\n', "")


def test_if_elif_else_and_missing_else(q):
    # CATCHES: elif chains pick the first true branch and a missing else
    # branch yields the input unchanged (null here), not an error.
    r = q('if 1 > 2 then "a" elif 2 > 1 then "b" else "c" end')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"b"\n', "")
    r = q('if 1 > 2 then "a" elif 2 > 3 then "b" else "c" end')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"c"\n', "")
    r = q("if false then 1 end")
    assert (r.returncode, r.stdout, r.stderr) == (0, "null\n", "")
    # an empty condition stream means the if produces nothing at all
    r = q("[if empty then 1 else 2 end]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[]\n", "")
    r = q("[if (true,false) then 1 else 2 end]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2]\n", "")


def test_try_catch_error_values(q):
    # CATCHES: catch sees the error *value* (not its string form): strings
    # stay strings, numbers and objects pass through unchanged, and
    # error(null) yields null rather than being treated as "no error".
    for query, expected in [
        ('try error("boom") catch .', '"boom"\n'),
        ("try error(42) catch .", "42\n"),
        ('try error({a:1}) catch .', '{"a":1}\n'),
        ("try error(null) catch .", "null\n"),
        ("try error catch .", "null\n"),
        ('try error(error("x")) catch .', '"x"\n'),
        ("try error([1,\"x\"]) catch .", "[1,\"x\"]\n"),
    ]:
        r = q(query)
        assert (r.returncode, r.stdout, r.stderr) == (0, expected, ""), query
    # operator errors are caught as their message string
    r = q("try (1/0) catch .")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '"cannot divide number (1) by: number (0)"\n', "")
    r = q('try (1/0) catch . == "cannot divide number (1) by: number (0)"')
    assert (r.returncode, r.stdout, r.stderr) == (0, "true\n", "")


def test_try_catch_binds_looser_than_operators(q):
    # CATCHES: `try A catch B + C` parses as `(try A catch B) + C`, so the
    # catch result feeds the addition and fails on the first caught value.
    r = q('try (1,error("x"),2) catch . + "!"')
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", 'gojq: cannot add: number (1) and string ("!")\n')
    # ...while an explicitly parenthesized catch body succeeds
    r = q('try (1,error("x"),2) catch (. + "!")')
    assert (r.returncode, r.stdout, r.stderr) == (0, '1\n"x!"\n', "")


def test_try_with_generators_and_nested_catch(q):
    # CATCHES: try keeps the outputs the body produced *before* the error,
    # then continues with the catch result in place of the failed output.
    r = q('try (1,error("x"),2) catch .')
    assert (r.returncode, r.stdout, r.stderr) == (0, '1\n"x"\n', "")
    r = q('[try (1,error("e"),3) catch "caught"]')
    assert (r.returncode, r.stdout, r.stderr) == (0, '[1,"caught"]\n', "")
    # an erroring catch body propagates outward
    r = q('try error("a") catch error("b")')
    assert (r.returncode, r.stdout, r.stderr) == (5, "", "gojq: error: b\n")
    # ...and an outer try catches it again
    r = q('try (try error("a") catch error("b")) catch "c"')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"c"\n', "")
    r = q('try error("a") catch try error("b") catch .')
    assert (r.returncode, r.stdout, r.stderr) == (0, '"b"\n', "")


def test_optional_operator_sugar(q):
    # CATCHES: `?` swallows errors from its operand entirely (no output, exit
    # 0), including error() values and indexing/iterating type errors.
    r = q("(1/0)?")
    assert (r.returncode, r.stdout, r.stderr) == (0, "", "")
    r = q("1 | .a?")
    assert (r.returncode, r.stdout, r.stderr) == (0, "", "")
    r = q("1 | .[]?")
    assert (r.returncode, r.stdout, r.stderr) == (0, "", "")
    r = q('error("x")?')
    assert (r.returncode, r.stdout, r.stderr) == (0, "", "")
    r = q("[(1,2,error(\"e\"),3)?]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2]\n", "")
    r = q("[(1/0)?, (1%0)?]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[]\n", "")
    # an inner `?` already swallowed the error, so the outer catch sees none
    r = q('try (error("x")?) catch "c"')
    assert (r.returncode, r.stdout, r.stderr) == (0, "", "")
    # ? after a term works on iteration and on chains
    r = q("[.[]?]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[]\n", "")
    r = q(".a?.b?")
    assert (r.returncode, r.stdout, r.stderr) == (0, "null\n", "")


def test_reduce_basics(q):
    # CATCHES: reduce folds the state through every source value, an empty
    # source keeps the init, and a generator init forks the whole reduction.
    r = q("reduce (1,2,3) as $x (0; . + $x)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "6\n", "")
    r = q("reduce empty as $x (0; . + $x)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "0\n", "")
    r = q("reduce (1,2) as $x ((10,20); . + $x)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "13\n23\n", "")
    # an update producing several values keeps only the LAST one per step
    r = q("reduce (1,2) as $x (0; . + $x, . - $x)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "-3\n", "")
    r = q("[reduce (1,2) as $x (0; . + $x, . - $x)]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[-3]\n", "")


def test_foreach_states_and_extract(q):
    # CATCHES: foreach emits every intermediate state (unlike reduce), the
    # extract clause maps each state, and multiple init states run the whole
    # body once per state in order.
    r = q("foreach (1,2,3) as $x (0; . + $x)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n3\n6\n", "")
    r = q("foreach (1,2,3) as $x (0; .+$x; .*10)")
    assert (r.returncode, r.stdout, r.stderr) == (0, "10\n30\n60\n", "")
    r = q("[foreach (1,2,3) as $x (0; .+$x; [$x,.])]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[[1,1],[2,3],[3,6]]\n", "")
    # an extract that itself outputs several values emits them all
    r = q("[foreach (1,2) as $x (0; .+$x; ., .*10)]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,10,3,30]\n", "")
    r = q("foreach (1,2,3) as $x (0,10; .+$x)")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "1\n3\n6\n11\n13\n16\n", "")
    r = q("[foreach (1,2,3) as $x ((0,100); .+$x)]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[1,3,6,101,103,106]\n", "")


def test_recursive_descent(q):
    # CATCHES: `..` visits the root first then every descendant depth-first,
    # and `[path(..)]` yields the root path `[]` followed by each subpath.
    r = q("[..]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[null]\n", "")
    r = q("[[1,[2]],3] | [..]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[[[1,[2]],3],[1,[2]],1,[2],2,3]\n", "")
    r = q('{"a":{"b":1}} | [..]')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[{"a":{"b":1}},{"b":1},1]\n', "")
    r = q('{"a":[1]} | [path(..)]')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[[],["a"],["a",0]]\n', "")
    r = q("[1,[2]] | [.. | select(type == \"number\")]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2]\n", "")


def test_recursive_descent_optional(q):
    # CATCHES: `..?` is recursive descent with errors suppressed per node, so
    # scalars and erroring nodes are simply skipped instead of aborting.
    r = q("[1,null,\"a\"] | [..?]")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, "[[1,null,\"a\"],1,null,\"a\"]\n", "")
    r = q("1 | [..?]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1]\n", "")
    r = q(".. | try error(\"d\") catch \"c\"")
    assert (r.returncode, r.stdout, r.stderr) == (0, '"c"\n', "")


def test_errors_inside_generators(q):
    # CATCHES: an error in the middle of a generator stream aborts the rest
    # of that stream, while values already produced are still printed.
    r = q('1,error("x"),2')
    assert (r.returncode, r.stdout, r.stderr) == (5, "1\n", "gojq: error: x\n")
    r = q("[.[] | try error catch \"e\"]")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: cannot iterate over: null\n")
