"""Destructuring `as` patterns (?// alternatives) and object construction."""


def test_alternative_patterns_fall_through(q):
    # CATCHES: with `?//` a failing pattern degrades to the next one and
    # unbound variables from the failed pattern come out as null; the last
    # pattern's failure is a real error (catchable by try/catch).
    r = q("[[1,2]] | .[] as [$a, $b] ?// $c | [$a, $b, $c]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2,null]\n", "")
    r = q("1 | . as [$a] ?// $b | [$a, $b]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[null,1]\n", "")
    r = q("1 | . as {$a} ?// $b | [$a, $b]")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[null,1]\n", "")
    r = q('{"a":1} | . as {a: $x} ?// [$y] | [$x, $y]')
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,null]\n", "")
    r = q("[1,2] as [$a, $b] ?// $c | [$a, $b, $c] | .")
    assert (r.returncode, r.stdout, r.stderr) == (0, "[1,2,null]\n", "")
    r = q("5 | . as [$a, $b] ?// {$c} | [$a, $b, $c]")
    assert (r.returncode, r.stdout, r.stderr) == (
        5, "", "gojq: expected an object but got: number (5)\n")
    r = q("try (5 | . as [$a] ?// {$b} | 1) catch .")
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '"expected an object but got: number (5)"\n', "")


def test_object_pattern_bindings(q):
    # CATCHES: object patterns bind the named key ({$a} is {a:$a}), a
    # computed key expression works as the lookup key, and null input
    # simply leaves every variable null rather than erroring.
    r = q(". as {$a} | $a")
    assert (r.returncode, r.stdout, r.stderr) == (0, "null\n", "")
    r = q('{"k":1} | . as {("k"): $v} | $v')
    assert (r.returncode, r.stdout, r.stderr) == (0, "1\n", "")


def test_object_construction_shorthands(q):
    # CATCHES: {$o} uses the variable's NAME as the key, {a} and {"a"}
    # read .a / .["a"] from the input, and object construction is a
    # cartesian product in key-major order when both sides generate.
    r = q('{"a":1} as $o | {$o}')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"o":{"a":1}}\n', "")
    r = q('{"a":1} | {a}')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1}\n', "")
    r = q('{"a":1} | {"a"}')
    assert (r.returncode, r.stdout, r.stderr) == (0, '{"a":1}\n', "")
    r = q('[(1,2) | {("k"+(.|tostring)): .}]')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '[{"k1":1},{"k2":2}]\n', "")
    r = q('{("a","b"): (1,2)}')
    assert (r.returncode, r.stdout, r.stderr) == (
        0, '{"a":1}\n{"a":2}\n{"b":1}\n{"b":2}\n', "")
