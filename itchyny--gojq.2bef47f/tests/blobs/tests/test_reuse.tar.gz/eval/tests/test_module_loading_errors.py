"""Module loading, search metadata and module parse errors.

The module machinery is where the reference binary decides how an import's
``{"search": ...}`` metadata is interpreted (only a plain string redirects
the lookup, and ``~`` is expanded against ``HOME``), and where parse
failures of loaded files surface.  Those failures look different depending
on who reports them: ``modulemeta`` prints the bare one-line form while the
compile path reformats the module's source with a caret and a line number,
and an unparsable ``.json`` data module is reported as invalid JSON.

Every expected value below was recorded by running the reference binary.
"""

import pytest

from conftest import run_gojq

#: Fixture tree.  ``dep.jq`` exists three times with different bodies so
#: that a redirecting search value is observable in the result, and the
#: broken files exercise the error paths of module loading.
MODULE_FILES = {
    # reachable only through the HOME directory
    "dep.jq": "def g: 3;\n",
    # the default -L search directory
    "search/dep.jq": "def g: 1;\n",
    # reachable only when a search value points here
    "search/sub/dep.jq": "def g: 2;\n",
    "search/m_str.jq": ('import "dep" as o {"search": "./sub"};\n'
                        "def h: o::g;\n"),
    "search/m_num.jq": 'import "dep" as o {"search": 1};\ndef h: o::g;\n',
    "search/m_null.jq": 'import "dep" as o {"search": null};\ndef h: o::g;\n',
    "search/m_obj.jq": ('import "dep" as o {"search": {"a":1}};\n'
                        "def h: o::g;\n"),
    "search/m_bool.jq": ('import "dep" as o {"search": true};\n'
                         "def h: o::g;\n"),
    "search/m_home.jq": 'import "dep" as o {"search": "~/"};\ndef h: o::g;\n',
    # a module that does not parse
    "search/bad.jq": "def x(: 1;\n",
    # a data module whose JSON is invalid
    "search/baddata.json": "not json {{{\n",
    "search/usesdata.jq": 'import "baddata" as $d;\ndef k: $d;\n',
    "search/usesbad.jq": 'import "bad" as b;\ndef m: b::x;\n',
}


def run_module(args, tmp_path, stdin="null"):
    """Run the reference binary with the module fixture tree in place."""
    return run_gojq(args, stdin=stdin, tmp_path=tmp_path,
                    files=MODULE_FILES)


def test_search_metadata_string_redirects_module_lookup(tmp_path):
    """a string search value is resolved relative to the module's directory.

    ``{"search": "./sub"}`` in ``search/m_str.jq`` makes ``dep`` resolve to
    ``search/sub/dep.jq``, which is *not* on the ``-L search`` path's
    default resolution order — otherwise ``dep`` would be ``search/dep.jq``.
    """
    # CATCHES: the import picks the dep.jq from the redirected directory
    # (result 2) instead of the one in the -L directory (result 1)
    res = run_module(["-c", "-L", "search", 'include "m_str"; h'], tmp_path)
    assert res.out == "2\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("module", ["m_num", "m_null", "m_obj", "m_bool"])
def test_non_string_search_metadata_is_ignored(tmp_path, module):
    """only a string search value redirects; other constants are ignored.

    A number, null, object or boolean in the ``search`` slot silently falls
    back to the default search paths instead of erroring about the
    metadata itself.
    """
    # CATCHES: {"search": 1} does not complain about the metadata — the
    # import still resolves dep from the -L directory (result 1)
    res = run_module(["-c", "-L", "search", 'include "%s"; h' % module],
                     tmp_path)
    assert res.out == "1\n"
    assert res.err == ""
    assert res.rc == 0


def test_search_metadata_expands_home(tmp_path):
    """a search value starting with "~/" is expanded against HOME.

    ``{"search": "~/"}`` resolves to the HOME directory (which the test
    harness pins to ``tmp_path``), where a third ``dep.jq`` lives.
    """
    # CATCHES: the tilde form reaches tmp_path/dep.jq (result 3) rather
    # than a literal "./~" directory or the -L directory (result 1)
    res = run_module(["-c", "-L", "search", 'include "m_home"; h'], tmp_path)
    assert res.out == "3\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("module,expected_search", [
    ("m_str", '"search":"search/sub"'),
    ("m_num", '"search":1'),
    ("m_null", '"search":null'),
    ("m_bool", '"search":true'),
])
def test_modulemeta_reflects_search_metadata_verbatim(tmp_path, module,
                                                      expected_search):
    """modulemeta echoes the metadata value and the resolved directory.

    A string search value is reported as the directory it resolved to
    (relative to the working directory), while non-string values are
    reflected unchanged.
    """
    # CATCHES: m_str reports the resolved "search/sub" directory but m_num
    # reports the raw number 1, so the resolution only happens for strings
    res = run_module(["-nc", "-L", "search", '"%s" | modulemeta' % module],
                     tmp_path)
    assert res.out == ('{"defs":["h/0"],"deps":[{"as":"o","is_data":false,'
                       '"relpath":"dep",%s}]}\n' % expected_search)
    assert res.err == ""
    assert res.rc == 0


def test_modulemeta_on_unparsable_module(tmp_path):
    """modulemeta reports a module parse error as a runtime error.

    The message is the bare one-line form ``invalid query: <path>: <err>``
    with exit code 5, because the module is loaded by the ``modulemeta``
    call at run time rather than during compilation.
    """
    # CATCHES: modulemeta prints "invalid query: search/bad.jq:" on one
    # line with exit 5, unlike the compile-time form which adds a caret
    res = run_module(["-nc", "-L", "search", '"bad" | modulemeta'],
                     tmp_path)
    assert res.out == ""
    assert res.err == 'gojq: invalid query: search/bad.jq: unexpected token ":"\n'
    assert res.rc == 5


def test_importing_unparsable_module(tmp_path):
    """a broken imported module is a compile error with source context.

    Because the failing query is a file and not the command line argument,
    the message carries the file name and line number plus a caret under
    the offending token, and the exit code is 3.
    """
    # CATCHES: the message quotes "search/bad.jq:1" and repeats the module
    # source line with the caret under the ":" of "def x(:"
    res = run_module(["-c", "-L", "search", 'include "usesbad"; m'],
                     tmp_path)
    assert res.out == ""
    assert res.err == ('gojq: invalid query: search/bad.jq:1\n'
                       "    1 | def x(: 1;\n"
                       '              ^  unexpected token ":"\n')
    assert res.rc == 3


def test_importing_invalid_json_data_module(tmp_path):
    """a data module with broken JSON is a compile-time JSON parse error.

    The import of a ``.json`` file is reported with the "invalid json"
    prefix, the file name, and the offending source line with a caret, and
    the whole thing is wrapped as a compile error (exit code 3).
    """
    # CATCHES: the message says "invalid json: search/baddata.json" and
    # quotes the file contents "not json {{{" with the caret on column 1
    res = run_module(["-c", "-L", "search", 'include "usesdata"; k'],
                     tmp_path)
    assert res.out == ""
    assert res.err == ('gojq: compile error: invalid json:'
                       " search/baddata.json\n"
                       "    not json {{{\n"
                       "     ^  invalid character 'o' in literal null"
                       " (expecting 'u')\n")
    assert res.rc == 3


def test_modulemeta_of_data_import_does_not_read_the_json(tmp_path):
    """modulemeta lists a data dependency without loading its contents.

    ``usesdata`` imports ``baddata`` as a value, yet modulemeta succeeds
    and reports the dependency with ``is_data`` set, because only the
    module metadata is inspected, never the data file.
    """
    # CATCHES: modulemeta returns a result (exit 0) even though importing
    # the same data module at compile time fails on the broken JSON
    res = run_module(["-nc", "-L", "search", '"usesdata" | modulemeta'],
                     tmp_path)
    assert res.out == ('{"defs":["k/0"],"deps":[{"as":"d","is_data":true,'
                       '"relpath":"baddata"}]}\n')
    assert res.err == ""
    assert res.rc == 0
