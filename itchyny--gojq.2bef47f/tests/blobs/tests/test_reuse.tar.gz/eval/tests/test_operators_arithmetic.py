"""Arithmetic, comparison and boolean operators (operator.go).

Rewritten from the operator coverage of the native suite: the arithmetic
cases of ``cli/test.yaml`` (add/subtract/multiply/divide/modulo with their
type errors and big-integer semantics) and the truthiness/comparison
behaviors of the library tests.  Every expected value below was recorded
by running the reference binary.
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("query,expected_out", [
    ("null + 1", "1\n"),
    ("1 + null", "1\n"),
    ("1 + 2", "3\n"),
    ("0.1 + 0.2", "0.30000000000000004\n"),
    # big integers are added exactly, not through float64
    ("10000000000000000000 + 1", "10000000000000000001\n"),
    ('"a" + "b"', '"ab"\n'),
    ("[1] + [2, 3]", "[1,2,3]\n"),
    # object merge: right side wins on conflicting keys
    ('{"a":1,"b":2} + {"b":3,"c":4}', '{"a":1,"b":3,"c":4}\n'),
    ('null + {"a":1}', '{"a":1}\n'),
    ("true + null", "true\n"),
    ('{"a":1} + null', '{"a":1}\n'),
])
def test_add_operator(tmp_path, query, expected_out):
    """add joins every pair of like types and treats null as identity."""
    # CATCHES: big ints stay exact; object + object merges, not replaces
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ('1 + "a"', 'gojq: cannot add: number (1) and string ("a")\n'),
    ("{} + []", 'gojq: cannot add: object ({}) and array ([])\n'),
    ('"a" + 1', 'gojq: cannot add: string ("a") and number (1)\n'),
])
def test_add_operator_type_errors(tmp_path, query, expected_err):
    """adding unlike types fails with a preview of both operands."""
    # CATCHES: error names both operands' types and values in order
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    ("5 - 3", "2\n"),
    ("5.5 - 0.5", "5\n"),
    ("-5 - -3", "-2\n"),
    # array subtraction removes every listed element
    ("[1,2,3,2,1] - [2]", "[1,3,1]\n"),
    ('[{"a":1},{"b":2}] - [{"a":1}]', '[{"b":2}]\n'),
    # nan members are matched by identity, so they get removed like jq does
    ("[nan,{x:nan}] - [nan,{x:nan}]", '[null,{"x":null}]\n'),
])
def test_subtract_operator(tmp_path, query, expected_out):
    """subtract works on numbers and as multiset difference on arrays."""
    # CATCHES: array difference removes duplicates too; nan cancels to null
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("null - 1", "gojq: cannot subtract: null and number (1)\n"),
    ('"a" - 1', 'gojq: cannot subtract: string ("a") and number (1)\n'),
])
def test_subtract_operator_type_errors(tmp_path, query, expected_err):
    """subtracting from non-numbers fails naming both operand previews."""
    # CATCHES: null is not an identity for subtraction (unlike addition)
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    ("3 * 4", "12\n"),
    ("2.5 * 4", "10\n"),
    ('3 * "ab"', '"ababab"\n'),
    # object * object is a recursive merge, arrays replace wholesale
    ('{"a":{"b":1,"c":2}} * {"a":{"b":3}}', '{"a":{"b":3,"c":2}}\n'),
    ('{"a":[1,2]} * {"a":[3]}', '{"a":[3]}\n'),
])
def test_multiply_operator(tmp_path, query, expected_out):
    """multiply scales numbers, repeats strings and deep-merges objects."""
    # CATCHES: nested object merge keeps sibling keys, arrays do not merge
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_multiply_string_by_fractional_count(tmp_path):
    """string repetition truncates the count and yields null below zero.

    Recorded from the reference binary for the multiplier sweep
    ``(-1.0, -0.5, 0.0, 0.5, 1.0, 1.5, 3.7, 10, nan) * "abc"``: a count
    of 0 or 0.5 produces "", 1.5 produces one copy, 3.7 three copies,
    while negative and nan counts produce null.
    """
    # CATCHES: counts truncate toward zero; negative and nan give null
    res = run_gojq(
        ["-c", '(-1.0, -0.5, 0.0, 0.5, 1.0, 1.5, 3.7, 10, nan) * "abc"'],
        stdin="null", tmp_path=tmp_path)
    assert res.out == ('null\nnull\n""\n""\n"abc"\n"abc"\n"abcabcabc"\n'
                       '"abcabcabcabcabcabcabcabcabcabc"\nnull\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ('{"a":1} * null',
     'gojq: cannot multiply: object ({"a":1}) and null\n'),
    ('"a" * "b"',
     'gojq: cannot multiply: string ("a") and string ("b")\n'),
])
def test_multiply_operator_type_errors(tmp_path, query, expected_err):
    """multiplying non-number/non-string mixes aborts with rc 5."""
    # CATCHES: object * null is an error, not an identity operation
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


def test_multiply_oversize_string_repeat_error(tmp_path):
    """repeating a string past the size limit raises a catchable error."""
    # CATCHES: oversize repeat reports the operand and multiplier verbatim
    res = run_gojq(["-c", 'try (720000000 * "abc") catch .'],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == \
        '"repeat string result too large: \\"abc\\" * 720000000"\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ("10 / 4", "2.5\n"),
    ("1 / 3", "0.3333333333333333\n"),
    ('"a,b,c" / ","', '["a","b","c"]\n'),
    ('"abc" / ""', '["a","b","c"]\n'),
    ("infinite / infinite", "null\n"),
])
def test_divide_operator(tmp_path, query, expected_out):
    """divide turns into float division and string splitting on strings."""
    # CATCHES: integer inputs become floats; empty separator explodes chars
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("5 / 0", "gojq: cannot divide number (5) by: number (0)\n"),
    ("0 / 0", "gojq: cannot divide number (0) by: number (0)\n"),
    ('"abc" / 1', 'gojq: cannot divide: string ("abc") and number (1)\n'),
])
def test_divide_operator_type_errors(tmp_path, query, expected_err):
    """division by zero is a fatal error, unlike IEEE infinity rules."""
    # CATCHES: gojq refuses x/0 instead of producing infinite
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    ("5 % 3", "2\n"),
    ("5.5 % 3", "2\n"),
    ("-5 % 3", "-2\n"),
    ("5 % -3", "2\n"),
    # big integers take the remainder exactly
    ("1000000000000000000001 % 7", "0\n"),
    ("nan % 1", "null\n"),
])
def test_modulo_operator(tmp_path, query, expected_out):
    """modulo keeps the sign of the dividend and works on big integers."""
    # CATCHES: -5 % 3 is -2 (not 1); nan propagates to null
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("5 % 0", "gojq: cannot modulo number (5) by: number (0)\n"),
    ('"a" % 1', 'gojq: cannot modulo: string ("a") and number (1)\n'),
])
def test_modulo_operator_type_errors(tmp_path, query, expected_err):
    """modulo by zero and non-number operands are fatal errors."""
    # CATCHES: modulo-by-zero message wording differs from division's
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("-(3)", "null", "-3\n"),
    ("-(3.5)", "null", "-3.5\n"),
    ("-(-2)", "null", "2\n"),
    ("+1", "null", "1\n"),
    ("[1, -2, 3.5] | map(-.)", "null", "[-1,2,-3.5]\n"),
    ("{x: -.}, {x: -. | abs}", "1", '{"x":-1}\n{"x":1}\n'),
])
def test_unary_operators(tmp_path, query, stdin, expected_out):
    """unary minus and plus only coerce numbers, identity otherwise."""
    # CATCHES: unary minus works elementwise via map; +1 echoes 1
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ('-"a"', 'gojq: cannot negate: string ("a")\n'),
    ("(-null)", 'gojq: cannot negate: null\n'),
    ('+"a"', 'gojq: cannot plus: string ("a")\n'),
    ("+{}", 'gojq: cannot plus: object ({})\n'),
])
def test_unary_operator_type_errors(tmp_path, query, expected_err):
    """unary minus/plus reject every non-number with distinct wording."""
    # CATCHES: negate and plus have separate error verbs in messages
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    ('[1 < 2, 2 <= 2, 3 > 2, 3 >= 4, "a" < "b", null < false, '
     'false < true, true < 0, 0 < "", [] < {}, [1] < [2], {"a":1} < {"b":0}]',
     "[true,true,true,false,true,true,true,true,true,true,true,true]\n"),
    ('[1 == 1.0, [1,2] == [1,2], {"a":1} == {"a":1}, "1" != 1, nan == nan, '
     "nan < nan, infinite == infinite, [nan] == [nan], "
     "10000000000000000000000000000000000000000 > 1]",
     "[true,true,true,true,false,true,true,false,true]\n"),
])
def test_comparison_operators(tmp_path, query, expected_out):
    """comparisons follow the total order across all JSON types."""
    # CATCHES: null < false < true < numbers < strings < arrays < objects
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_nan_comparison_and_sorting(tmp_path):
    """nan equals nothing (even itself) yet sorts before every number.

    Recorded from the reference binary: ``nan == nan`` is false while
    ``nan < nan`` is true, so sorting a nan-polluted array collects the
    nans (rendered as null) in front and min picks one of them.
    """
    # CATCHES: nan==nan false but nan<nan true; min drops nan to null
    res = run_gojq(["-c", "[nan, 1, nan, 2, nan] | [min, max, sort]"],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == "[null,2,[null,null,null,1,2]]\n"
    assert res.err == ""
    assert res.rc == 0


def test_sort_orders_strings_by_code_points(tmp_path):
    """strings sort lexicographically, not numerically."""
    # CATCHES: "10" sorts before "2" because it is code point order
    res = run_gojq(["-c", '["10", "9", "2", "10"] | sort'],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == '["10","10","2","9"]\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    # only false and null are falsy; and/or short-circuit around errors
    ('[null and true, false and error("x"), 1 and 2, 0 and 1, "" and 1, '
     '[] and 1, {} and 1, true or error("x"), null or false, null or 0, '
     "false or null]",
     "[false,false,true,true,true,true,true,true,false,true,false]\n"),
    ("[1, null, \"\", 0, false, [], {}] | map(not)",
     "[false,true,false,false,true,false,false]\n"),
])
def test_boolean_and_or_not(tmp_path, query, expected_out):
    """and/or use jq truthiness (only false/null falsy) and short-circuit."""
    # CATCHES: 0, "", [] and {} are all truthy; errors never evaluate
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("1 and error", "gojq: error: null\n"),
    ("false or error", "gojq: error: null\n"),
])
def test_boolean_operator_error_propagation(tmp_path, query, expected_err):
    """and/or propagate errors from the side they actually evaluate."""
    # CATCHES: no short-circuit rescue when the error side must run
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    ('[null // 1, false // 1, 0 // 1, "" // "d", empty // 1, '
     "(1, null, false) // 2, (null, false, 2) // 3, (null, false) // 3]",
     '[1,1,0,"",1,1,2,3]\n'),
    ('(null, 1, false, 2) // 99', "1\n2\n"),
    ('(empty, null, false) // "x"', '"x"\n'),
    ('{"a":1} | [.a // "d", .b // "d"]', '[1,"d"]\n'),
])
def test_alternative_operator(tmp_path, query, expected_out):
    """// falls back on falsy or empty left sides, keeps truthy outputs."""
    # CATCHES: truthy left outputs pass through; empty counts as falsy
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_alternative_operator_error_propagation(tmp_path):
    """// does not swallow errors from the left-hand side."""
    # CATCHES: error("x") // 3 aborts instead of yielding the default
    res = run_gojq(["-c", 'error("x") // 3'], stdin="null",
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: error: x\n"
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('.a //= "d", .b //= "d"', '{"a":1}', '{"a":1}\n{"a":1,"b":"d"}\n'),
    ('map_values(tonumber? // .)', '{"x": "1", "y": "1.5", "z": "z"}',
     '{"x":1,"y":1.5,"z":"z"}\n'),
])
def test_alternative_assignment(tmp_path, query, stdin, expected_out):
    """//= only assigns when the current value is null or false."""
    # CATCHES: existing falsy-but-truthy values like 0 would be kept
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0
