"""@format strings (@text, @json, @html, @uri, @urid, @csv, @tsv, @sh,
@base64, @base64d) with and without interpolation.

Rewritten from the native ``cli/test.yaml`` cases 'format strings @text'
through 'format strings @base64d'.  Expected values recorded from the
reference binary.
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("@text, @json", "null\n", '"null"\n"null"\n'),
    ("@text, @json", "{}\n", '"{}"\n"{}"\n'),
])
def test_format_text_and_json(tmp_path, query, stdin, expected_out):
    """@text and @json both render the value as its JSON text.

    From ``cli/test.yaml``: 'format strings @text' and 'format strings
    @json'.
    """
    # CATCHES: both formats produce identical strings for scalars
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_format_json_interpolation(tmp_path):
    """interpolated values inside @json strings are JSON-encoded."""
    # CATCHES: each \\(...) splices the compact JSON of its expression
    res = run_gojq(['-c', '@json "0\\(.)1\\(. + .)2\\([2])3"'],
                   stdin="[1]", tmp_path=tmp_path)
    assert res.out == '"0[1]1[1,1]2[2]3"\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    # bare @html escapes the encoding of the whole input
    ("@html", '{"foo": "<div>&\'\\"</div>"}\n',
     '"{&quot;foo&quot;:&quot;&lt;div&gt;&amp;&apos;\\\\&quot;'
     '&lt;/div&gt;&quot;}"\n'),
    # literal parts of an @html string stay unescaped
    ('@html "x\\(.)x\\(.+.)x\\("<>")x"', '["<>"]',
     '"x[&quot;&lt;&gt;&quot;]x[&quot;&lt;&gt;&quot;,&quot;&lt;&gt;&quot;]'
     'x&lt;&gt;x"\n'),
])
def test_format_html(tmp_path, query, stdin, expected_out):
    """@html escapes &, <, >, ' and " in interpolated values only.

    From ``cli/test.yaml``: 'format strings @html' and '... with string
    interpolation'.
    """
    # CATCHES: literal segments of the format string are never escaped
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("@uri", '[1, {"foo": "<div>&\'\\"()+</div>"}]',
     '"%5B1%2C%7B%22foo%22%3A%22%3Cdiv%3E%26%27%5C%22%28%29%2B%3C%2Fdiv'
     '%3E%22%7D%5D"\n'),
    ('@uri "q=\\(.)&q=\\(. + .)"', '["<>", "{&}"]',
     '"q=%5B%22%3C%3E%22%2C%22%7B%26%7D%22%5D&q=%5B%22%3C%3E%22%2C%22%7B'
     '%26%7D%22%2C%22%3C%3E%22%2C%22%7B%26%7D%22%5D"\n'),
])
def test_format_uri(tmp_path, query, stdin, expected_out):
    """@uri percent-encodes every non-unreserved byte of the value.

    From ``cli/test.yaml``: 'format strings @uri' and '... with string
    interpolation'.
    """
    # CATCHES: JSON punctuation like []{}":& encodes byte by byte
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_format_urid(tmp_path):
    """@urid decodes percent escapes back into the original text."""
    # CATCHES: decoding is exact, including the backslash-quote pair
    res = run_gojq(
        ["-c", "@urid"],
        stdin='"%5B1%2C%7B%22foo%22%3A%22%3Cdiv%3E%26%27%5C%22%28%29%2B'
              '%3C%2Fdiv%3E%22%7D%5D"',
        tmp_path=tmp_path)
    assert res.out == '"[1,{\\"foo\\":\\"<div>&\'\\\\\\"()+</div>\\"}]"\n'
    assert res.err == ""
    assert res.rc == 0


def test_format_urid_error(tmp_path):
    """@urid rejects malformed escapes with the offending text."""
    # CATCHES: the bad escape itself is quoted inside the message
    res = run_gojq(["-c", "@urid"], stdin='"%5B1%2C%"', tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == \
        'gojq: @urid cannot be applied to "%5B1%2C%": invalid URL escape "%"\n'
    assert res.rc == 5


CSV_TSV_STDIN = '[1, "foo", null, "foo,\\n\\"bar\\"\\tbaz\\u0000\\\\0"]'


def test_format_csv(tmp_path):
    """@csv renders array elements as a CSV row, quoting as needed.

    From ``cli/test.yaml``: 'format strings @csv' — control characters
    become literal \\n/\\t/\\0 escapes inside the quoted field.
    """
    # CATCHES: null yields an empty field; quotes are doubled
    res = run_gojq(["-c", "@csv"], stdin=CSV_TSV_STDIN + "\n",
                   tmp_path=tmp_path)
    assert res.out == \
        '"1,\\"foo\\",,\\"foo,\\n\\"\\"bar\\"\\"\\tbaz\\\\0\\\\0\\""\n'
    assert res.err == ""
    assert res.rc == 0


def test_format_csv_interpolation(tmp_path):
    """interpolated arrays are CSV-formatted element by element."""
    # CATCHES: each \\(...) contributes one comma-joined row fragment
    res = run_gojq(['-c', '@csv "\\(.),\\(. + .),\\([nan])"'],
                   stdin='[1, "foo", null, 2]', tmp_path=tmp_path)
    assert res.out == '"1,\\"foo\\",,2,1,\\"foo\\",,2,1,\\"foo\\",,2,"\n'
    assert res.err == ""
    assert res.rc == 0


def test_format_csv_errors(tmp_path):
    """@csv needs an array of scalars; other shapes abort the run."""
    # CATCHES: both the input type and element types get messages
    res = run_gojq(["-c", "@csv"], stdin="null\n[1, {\"foo\":1}]\n",
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == ('gojq: @csv cannot be applied to: null\n'
                       'gojq: @csv cannot format an array including: '
                       'object ({"foo":1})\n')
    assert res.rc == 5


def test_format_tsv(tmp_path):
    """@tsv renders array elements as a tab-separated row.

    From ``cli/test.yaml``: 'format strings @tsv'.
    """
    # CATCHES: tabs/newlines/NULs become literal escape sequences
    res = run_gojq(["-c", "@tsv"], stdin=CSV_TSV_STDIN + "\n",
                   tmp_path=tmp_path)
    assert res.out == \
        '"1\\tfoo\\t\\tfoo,\\\\n\\"bar\\"\\\\tbaz\\\\0\\\\\\\\0"\n'
    assert res.err == ""
    assert res.rc == 0


def test_format_tsv_errors(tmp_path):
    """@tsv needs an array of scalars; other shapes abort the run."""
    # CATCHES: nested arrays are rejected as elements too
    res = run_gojq(["-c", "@tsv"], stdin='0\n[1, ["foo"]]\n',
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == ('gojq: @tsv cannot be applied to: number (0)\n'
                       'gojq: @tsv cannot format an array including: '
                       'array (["foo"])\n')
    assert res.rc == 5


def test_format_sh(tmp_path):
    """@sh shell-quotes strings and leaves null/true/false bare.

    From ``cli/test.yaml``: 'format strings @sh'.
    """
    # CATCHES: embedded quotes escape as '\'' and NUL as literal \0
    res = run_gojq(
        ["-c", "@sh"],
        stdin='null\ntrue\n[1, "f\'o\'o\\u0000\\\\0", null, false]\n',
        tmp_path=tmp_path)
    assert res.out == ('"null"\n"true"\n'
                       '"1 \'f\'\\\\\'\'o\'\\\\\'\'o\\\\0\\\\0\' '
                       'null false"\n')
    assert res.err == ""
    assert res.rc == 0


def test_format_sh_error(tmp_path):
    """@sh refuses arrays containing objects."""
    # CATCHES: object elements name the format and the offender
    res = run_gojq(["-c", "@sh"], stdin='[{"foo": "<>"}]', tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == \
        'gojq: @sh cannot format an array including: object ({"foo":"<>"})\n'
    assert res.rc == 5


def test_format_base64(tmp_path):
    """@base64 encodes the value; interpolation encodes each value."""
    # CATCHES: interp repeats the base64 for each expression output
    res = run_gojq(['-c', '@base64, @base64 "\\(.),\\(. + .),\\(. + . + .)"'],
                   stdin="[1,2]", tmp_path=tmp_path)
    assert res.out == \
        '"WzEsMl0="\n"WzEsMl0=,WzEsMiwxLDJd,WzEsMiwxLDIsMSwyXQ=="\n'
    assert res.err == ""
    assert res.rc == 0


def test_format_base64d(tmp_path):
    """@base64d decodes, tolerating missing padding and junk tails."""
    # CATCHES: unpadded and trailing-garbage input still decode fully
    res = run_gojq(
        ["-c", "@base64d"],
        stdin='"eyJmb28iOiJiYXIifQ=="\n"eyJmb28iOiJiYXIifQ"\n'
              '"eyJmb28iOiJiYXIifQ=x=y"\n',
        tmp_path=tmp_path)
    assert res.out == '"{\\"foo\\":\\"bar\\"}"\n' * 3
    assert res.err == ""
    assert res.rc == 0


def test_format_base64d_error(tmp_path):
    """@base64d aborts on non-alphabet input."""
    # CATCHES: reports the byte offset of the illegal character
    res = run_gojq(["-c", "@base64d"], stdin='":"', tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == \
        'gojq: @base64d cannot be applied to ":": illegal base64 data at input byte 0\n'
    assert res.rc == 5
