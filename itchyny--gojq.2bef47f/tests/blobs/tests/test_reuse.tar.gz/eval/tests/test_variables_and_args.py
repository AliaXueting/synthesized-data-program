"""Variable binding options: --arg/--argjson/--slurpfile/--rawfile/--args.

Rewritten from the native suite ``cli/test.yaml`` cases "arg option",
"argjson option", "slurpfile option", "rawfile option", "$ARGS variable
with args option", "$ARGS variable with jsonargs option", "double dash" and
the flag error cases.
"""

import pytest

from conftest import run_gojq

TESTDATA = {"testdata/7.json": '1\n2\n{ "foo": 42 }\n'}


def test_arg_and_argjson_options(tmp_path):
    """--arg binds strings, --argjson binds parsed JSON values.

    Native cases "arg option" and "argjson option": ``--arg bar 42`` keeps
    ``42`` a string while ``--argjson bar 10`` binds the number 10.
    """
    # CATCHES: --arg always binds a string even when it looks numeric
    res = run_gojq(["--arg", "foo", "value 1", "--arg", "bar", "42",
                    "{ $foo, $bar }"], stdin="123", tmp_path=tmp_path)
    assert res.out == '{\n  "bar": "42",\n  "foo": "value 1"\n}\n'
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["--argjson", "foo", "{ \"foo\": 42 }", "--argjson", "bar",
                    "10", "{ $foo, $bar }"], stdin="123", tmp_path=tmp_path)
    assert res.out == '{\n  "bar": 10,\n  "foo": {\n    "foo": 42\n  }\n}\n'
    assert res.rc == 0


def test_argjson_big_integer(tmp_path):
    """--argjson keeps big integers exact (no float64 rounding).

    Native case "argjson option with big integer": 10^31 doubled prints all
    32 digits.
    """
    # CATCHES: big integer variables stay arbitrary precision through arithmetic
    res = run_gojq(["--argjson", "foo", "10000000000000000000000000000000",
                    "$foo * 2"], stdin="0", tmp_path=tmp_path)
    assert res.out == "20000000000000000000000000000000\n"
    assert res.err == ""
    assert res.rc == 0


def test_slurpfile_and_rawfile(tmp_path):
    """--slurpfile binds an array of a file's values; --rawfile its text.

    Native cases "slurpfile option" and "rawfile option" against the same
    three-value JSON file.
    """
    # CATCHES: slurpfile wraps values in an array; rawfile binds raw text
    res = run_gojq(["--slurpfile", "foo", "testdata/7.json", "{ $foo }"],
                   stdin="null", tmp_path=tmp_path, files=TESTDATA)
    assert res.out == '{\n  "foo": [\n    1,\n    2,\n    {\n      "foo": 42\n    }\n  ]\n}\n'
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["--rawfile", "foo", "testdata/7.json", "{ $foo }"],
                   stdin="null", tmp_path=tmp_path, files=TESTDATA)
    assert res.out == '{\n  "foo": "1\\n2\\n{ \\"foo\\": 42 }\\n"\n}\n'
    assert res.rc == 0


@pytest.mark.parametrize("mode,expected_out", [
    ("--args", '{\n  "named": {\n    "foo": "value"\n  },\n  "positional": [\n'
               '    "1",\n    "\\"bar\\"",\n    "{\\"x\\":1}"\n  ]\n}\n'
               '"1"\n"\\"bar\\""\n"{\\"x\\":1}"\n'),
    ("--jsonargs", '{\n  "named": {\n    "foo": "value"\n  },\n'
                   '  "positional": [\n    1,\n    "bar",\n    {\n      "x": 1\n    }\n  ]\n}\n'
                   '1\n"bar"\n{\n  "x": 1\n}\n'),
])
def test_positional_args(tmp_path, mode, expected_out):
    """--args keeps remaining arguments as strings; --jsonargs parses them.

    Native cases "$ARGS variable with args option" and "$ARGS variable with
    jsonargs option": the query can appear before the positional values, and
    ``$ARGS`` exposes both named and positional arguments.
    """
    # CATCHES: --jsonargs parses values as JSON while --args keeps them raw strings
    res = run_gojq(["--arg", "foo", "value", "$ARGS | ., .positional[]",
                    mode, "1", '"bar"', '{"x":1}'],
                   stdin="0", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args,expected_out,expected_err,rc", [
    (["--", "."], "1\n", "", 0),
    (["--", "--", "."], "", "gojq: invalid query: --\n    --\n"
     "      ^  unexpected EOF\n", 3),
])
def test_double_dash(tmp_path, args, expected_out, expected_err, rc):
    """The first ``--`` ends flags; anything after is a query or file.

    Native cases "double dash" and "double double dash": a second ``--``
    is taken as the query itself and fails to parse.
    """
    # CATCHES: only the first "--" is a separator; the second becomes the query
    res = run_gojq(args, stdin="1", tmp_path=tmp_path)
    assert res.rc == rc
    assert res.out == expected_out
    assert res.err == expected_err


@pytest.mark.parametrize("args,expected_err,rc", [
    (["--argjson", "0x", "0", "."],
     "gojq: compile error: invalid variable name: $0x\n", 3),
    (["-q", "."], "gojq: unknown flag `q'\n", 2),
])
def test_invalid_option_errors(tmp_path, args, expected_err, rc):
    """Bad variable names and unknown flags fail with distinct exit codes.

    Native cases "argjson option error" (compile error, exit 3) and
    "invalid short option error" (flag parse error, exit 2).
    """
    # CATCHES: compile error exits 3 while unknown flag exits 2
    res = run_gojq(args, tmp_path=tmp_path)
    assert res.rc == rc
    assert res.out == ""
    assert res.err == expected_err
