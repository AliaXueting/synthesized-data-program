"""Basic stdin -> stdout JSON round-trip behavior of the gojq CLI.

Rewritten from the native suite ``cli/test.yaml`` cases "empty args",
"query with comment", "number input/query", "string input/query" and the
library ``encoder_test.go`` number formatting cases.
"""

import pytest

from conftest import run_gojq


def test_default_query_is_identity(tmp_path):
    """Omitting the query argument applies the identity filter to each input.

    Native case "empty args": no positional arguments, stdin ``null``.
    """
    # CATCHES: absent query argument defaults to "." instead of erroring
    res = run_gojq([], stdin="null", tmp_path=tmp_path)
    assert res.out == "null\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected", [
    (". # comment", "null\n"),
    ("# comment\n1,\n# comment \\\n  comment \\ 0 \\\n  comment\n2,\n"
     "# comment \\\n  comment \\\\\n3, #      \\\n  comment \\\\\\\n"
     "  comment \\\\\n4 #\n", "1\n2\n3\n4\n"),
    ("1, # \r\n2, # \\\r\ncomment\\\\\r\n3", "1\n2\n3\n"),
])
def test_query_comments_are_stripped(tmp_path, query, expected):
    """Hash comments (incl. backslash line continuations) vanish from queries.

    Native cases "query with comment", "query with comment with newline" and
    the DOS (CRLF) variant: a trailing backslash inside a comment continues
    the comment onto the next line.
    """
    # CATCHES: "\\" at end of a comment line continues the comment; CRLF also ends a comment
    res = run_gojq([query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected
    assert res.err == ""
    assert res.rc == 0


def test_number_input_roundtrip(tmp_path):
    """Numbers read from stdin are echoed with their literal spelling intact.

    Native case "number input": 10.0 keeps its trailing zero and 5e1000 stays
    an exponent literal instead of overflowing to a float.
    """
    # CATCHES: number literals keep original spelling (10.0, 5e1000) on echo
    res = run_gojq(["."], stdin="128 3.14 10.0 6.02e23 5e1000", tmp_path=tmp_path)
    assert res.out == "128\n3.14\n10.0\n6.02e23\n5e1000\n"
    assert res.err == ""
    assert res.rc == 0


def test_number_literal_normalization(tmp_path):
    """Query number literals are normalized when printed.

    Native case "number query": 01000 prints as 1000, 1.2e3 as 1200, 1E+3 as
    1000 and 1E-9 as 1e-9.
    """
    # CATCHES: leading zeros and exponent spellings normalize on output
    res = run_gojq(["0, 128, 01000, 3.14, 1.2e3, 1E+3, 1E-9"], stdin="0",
                   tmp_path=tmp_path)
    assert res.out == "0\n128\n1000\n3.14\n1200\n1000\n1e-9\n"
    assert res.err == ""
    assert res.rc == 0


def test_string_escapes_and_surrogates(tmp_path):
    r"""String escapes round-trip; surrogate pairs decode to one code point.

    Native cases "string query", "string query including control characters"
    and "string query including surrogate pairs": \r \n \t \f \b \" \\ \/ stay
    escaped, ０ decodes to a full-width digit, literal control bytes
    re-encode as \u0001-style escapes, and 😄 is one rune of length
    1 / 4 bytes / code point 128516.
    """
    # CATCHES: raw control bytes in queries re-emit as \u escapes; surrogate pairs merge
    res = run_gojq([r'" Hello, world! \r\n\t\f\b\"\\\/０ "'], stdin="null",
                   tmp_path=tmp_path)
    assert res.out == '" Hello, world! \\r\\n\\t\\f\\b\\"\\\\/０ "\n'
    assert res.rc == 0

    res = run_gojq(["\"\x01\x07\x0f\\n\", \"\x7f\\n\""], stdin="null",
                   tmp_path=tmp_path)
    assert res.out == '"\\u0001\\u0007\\u000f\\n"\n"\\u007f\\n"\n'
    assert res.rc == 0

    res = run_gojq(['"\\ud83d\\ude04" | length, utf8bytelength, explode[]'],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == "1\n4\n128516\n"
    assert res.rc == 0
    assert res.err == ""


def test_string_interpolation_preserves_newlines(tmp_path):
    """Literal newlines inside string queries are encoded as \\n on output.

    Native case "string query including newlines": a string literal spanning
    several physical lines, containing an interpolation with embedded
    newlines, prints as one JSON string with \\n escapes.
    """
    # CATCHES: raw newlines inside string literals must not leak into output
    res = run_gojq(["\"a\n\\(\"\nb\nc\n\")\nd\n\""], stdin="null", tmp_path=tmp_path)
    assert res.out == '"a\\n\\nb\\nc\\n\\nd\\n"\n'
    assert res.err == ""
    assert res.rc == 0


def test_object_keys_keep_escape_sequences(tmp_path):
    """Object keys with JSON escapes are stored and re-encoded verbatim.

    Native case "object input and string escape": keys containing \\u0000,
    \\t, \\r, \\u001f, quotes and DEL keep their escaped spelling both as
    object keys and as values.
    """
    # CATCHES: escapes in object keys survive a round trip unchanged
    res = run_gojq(
        [], stdin='{"foo\\u0000\\t\\n\\r\\u001f !\\"#$/09:;<>?@AZ[\\\\]^_`az{|}~\\u007f": "<\\t\\n\\r>"}',
        tmp_path=tmp_path)
    assert res.out == ('{\n  "foo\\u0000\\t\\n\\r\\u001f !\\"#$/09:;<>?@AZ['
                       '\\\\]^_`az{|}~\\u007f": "<\\t\\n\\r>"\n}\n')
    assert res.err == ""
    assert res.rc == 0


def test_special_value_encoding(tmp_path):
    """Special float and big-integer values use jq's canonical JSON encoding.

    From library ``encoder_test.go``: 1e-6 prints as 0.000001 but 1e-7 keeps
    exponent form, NaN prints as null, infinities print as
    1.7976931348623157e+308, and a 39-digit integer survives a round trip
    without losing precision.
    """
    # CATCHES: nan->null, infinities->max-double literal, big ints never go through float64
    res = run_gojq(
        ["-cn", "[42, 3.14, 1e-6, 1e-7, -1e-9, 1e-10, nan, infinite, -infinite]"],
        stdin="null", tmp_path=tmp_path)
    assert res.out == ("[42,3.14,0.000001,1e-7,-1e-9,1e-10,null,"
                       "1.7976931348623157e+308,-1.7976931348623157e+308]\n")
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["-c", "."], stdin="340282366920938463463374607431768211455",
                   tmp_path=tmp_path)
    assert res.out == "340282366920938463463374607431768211455\n"
    assert res.rc == 0

    res = run_gojq(["-c", "."], stdin="[1e1000, -1e1000, 5e-324]",
                   tmp_path=tmp_path)
    assert res.out == "[1e1000,-1e1000,5e-324]\n"
    assert res.rc == 0
    assert res.err == ""
