"""CLI flag parsing, usage text and positional argument handling (cli/flags.go).

Rewritten from the flag machinery exercised by the native suite
(``cli/test.yaml`` cases "module directory option without argument", the
"--args option"/"--jsonargs option" family and "double dash") plus the
usage text produced by ``formatFlags``.  Every expected byte below was
recorded by running the reference binary.
"""

import re

import pytest

from conftest import run_gojq

#: ``--help`` header before the version line (which embeds build metadata).
HELP_HEADER = "gojq - Go implementation of jq\n\n"

#: ``--help`` output after the version line: the synopsis, usage and the
#: full option list emitted by ``formatFlags``.
HELP_TAIL = """
Synopsis:
  % echo '{"foo": 128}' | gojq '.foo'

Usage:
  gojq [OPTIONS]

Command Options:
  -r, --raw-output          output raw strings
      --raw-output0         implies -r with NUL character delimiter
  -j, --join-output         implies -r with no newline delimiter
  -c, --compact-output      output without pretty-printing
      --indent number       number of spaces for indentation
      --tab                 use tabs for indentation
      --yaml-output         output in YAML format
  -C, --color-output        output with colors even if piped
  -M, --monochrome-output   output without colors
  -n, --null-input          use null as input value
  -R, --raw-input           read input as raw strings
      --stream              parse input in stream fashion
      --yaml-input          read input as YAML format
  -s, --slurp               read all inputs into an array
  -f, --from-file           load query from file
  -L, --library-path dir    directory to search modules from
      --arg name value      set a string value to a variable
      --argjson name value  set a JSON value to a variable
      --slurpfile name file set the JSON contents of a file to a variable
      --rawfile name file   set the contents of a file to a variable
      --args                consume remaining arguments as positional string values
      --jsonargs            consume remaining arguments as positional JSON values
  -e, --exit-status         exit 1 when the last value is false or null
  -v, --version             display version information

Help Option:
  -h, --help                display this help information

"""

#: Module used by the short-option tests: ``-L``-attached directory names.
MODULE_FILES = {"lib/m.jq": "def f: 42;\n"}


@pytest.mark.parametrize("args", [
    ["--help"],
    ["-h"],
    ["--tab", "--help"],
    ["-c", "-h"],
])
def test_help_usage_text(tmp_path, args):
    """--help (or -h) prints the usage text to stdout and exits 0.

    The version line embeds the revision hash and Go version the binary was
    built with, so only its shape and the ``0.12.19`` version are pinned;
    every other byte of the output is compared exactly.
    """
    # CATCHES: help wins over other flags and lists every option with the
    # exact column alignment produced by the usage formatter
    res = run_gojq(args, tmp_path=tmp_path)
    assert res.out.startswith(HELP_HEADER)
    rest = res.out[len(HELP_HEADER):]
    m = re.match(r"Version: 0\.12\.19 \(rev: [^/]+/[^)]+\)\n", rest)
    assert m, rest
    assert rest[m.end():] == HELP_TAIL
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args", [["--version"], ["-v"], ["-c", "--version"]])
def test_version_output(tmp_path, args):
    """--version prints one line with the version and exits 0."""
    # CATCHES: version flag short-circuits before any query parsing
    res = run_gojq(args, tmp_path=tmp_path)
    assert re.fullmatch(r"gojq 0\.12\.19 \(rev: [^/]+/[^)]+\)\n", res.out)
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args,expected_err", [
    (["--unknown-flag"], "gojq: unknown flag `--unknown-flag'\n"),
    (["--unknown-flag=5"], "gojq: unknown flag `--unknown-flag=5'\n"),
    (["--unknown-flag=5", "."], "gojq: unknown flag `--unknown-flag=5'\n"),
    (["-cZ", "."], "gojq: unknown flag `Z'\n"),
    (["--tab=x"], "gojq: boolean flag `--tab' cannot have an argument\n"),
    (["--compact-output=yes"], "gojq: boolean flag `--compact-output' cannot have an argument\n"),
])
def test_unknown_and_misused_flags(tmp_path, args, expected_err):
    """unknown flags and boolean flags given arguments exit 2.

    Native case "module directory option without argument" shows the
    flag-parse exit code is 2 (not the query-error codes 3 or 5).
    """
    # CATCHES: the offending flag name is quoted and unknown long flags with
    # "=" keep the whole argument in the message
    res = run_gojq(args, stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 2


@pytest.mark.parametrize("args,expected_err", [
    (["--indent"], "gojq: expected argument for flag `--indent'\n"),
    (["--indent", "x", "."],
     'gojq: invalid argument for flag `--indent\': strconv.Atoi: parsing "x": invalid syntax\n'),
    (["--indent=", "."],
     'gojq: invalid argument for flag `--indent\': strconv.Atoi: parsing "": invalid syntax\n'),
    (["-L"], "gojq: expected argument for flag `-L'\n"),
    (["-nc", "-L"], "gojq: expected argument for flag `-L'\n"),
    (["-ncL"], "gojq: expected argument for flag `-L'\n"),
])
def test_flag_argument_errors(tmp_path, args, expected_err):
    """--indent/-L complain when their value is missing or not a number.

    Native case "module directory option without argument": ``-L`` without a
    directory is a flag-parse error with exit code 2.
    """
    # CATCHES: --indent reports the strconv failure verbatim, including the
    # empty string when the flag was written as "--indent="
    res = run_gojq(args, stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 2


@pytest.mark.parametrize("flag", ["arg", "argjson", "slurpfile", "rawfile"])
def test_two_argument_flags_require_both_values(tmp_path, flag):
    """--arg/--argjson/--slurpfile/--rawfile need name and value.

    A single trailing word is not enough: the parser consumes two arguments
    after the flag, so one missing value is a flag-parse error.
    """
    # CATCHES: the error names the flag and demands two arguments, not one
    res = run_gojq(["--" + flag, "foo"], tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: expected 2 arguments for flag `--%s'\n" % flag
    assert res.rc == 2


@pytest.mark.parametrize("library_args", [
    ["-L", "lib"],
    ["-Llib"],
    ["-L=lib"],
    ["-ncLlib"],
    ["-nc", "-L=lib"],
])
def test_library_path_attached_value(tmp_path, library_args):
    """-L accepts separate, attached and "="-separated directory values.

    Native cases "source query from file short option in clumped options"
    (short flags may be clumped) and the module directory option cases.
    """
    # CATCHES: "-Llib" and "-L=lib" both pass "lib" (not "=lib") as the path
    res = run_gojq(library_args + ['import "m" as m; m::f'],
                   stdin="null", tmp_path=tmp_path, files=MODULE_FILES)
    assert res.out == "42\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args,expected_out", [
    (["-n", "-1"], "-1\n"),
    (["-n", "-.5"], "-0.5\n"),
    (["-c", "-1"], "-1\n"),
    (["-n", "--", "-1"], "-1\n"),
    (["--", ".a"], "null\n"),
])
def test_dash_prefixed_queries(tmp_path, args, expected_out):
    """arguments starting with "-" that are not flags become the query.

    Native case "double dash": after ``--`` everything is positional, and a
    leading "-1"/"-.5" is only a flag if the character after "-" is a
    known short option letter.
    """
    # CATCHES: "-1" is a negative-number query, not an unknown flag error
    res = run_gojq(args, stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_double_dash_stops_option_parsing(tmp_path):
    """after "--" even "--help" is treated as the query text.

    The query ``--help`` parses as the (undefined) function ``help``, so the
    run fails at compile time instead of printing the usage.
    """
    # CATCHES: "--" disables flag parsing; "--help" then reaches the compiler
    res = run_gojq(["--", "--help"], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: compile error: function not defined: help/0\n"
    assert res.rc == 3


def test_first_positional_after_args_is_the_query(tmp_path):
    """the first bare word after --args becomes the query.

    ``--args`` only starts consuming positional values once the query is
    already in place, so ``--args a b '$ARGS'`` runs the query ``a`` and
    keeps ``b`` and ``$ARGS`` as positional string arguments.
    """
    # CATCHES: the first word after --args is taken as the query, so this
    # fails on the undefined function a/0 instead of echoing $ARGS
    res = run_gojq(["-n", "--args", "a", "b", "$ARGS"], tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: compile error: function not defined: a/0\n"
    assert res.rc == 3


def test_jsonargs_consumes_late_positional_as_json(tmp_path):
    """words after --jsonargs are parsed as JSON even when that fails.

    With the query already chosen, ``--args a --jsonargs 1`` leaves ``$ARGS``
    as a --jsonargs value; the invalid JSON text is reported against the
    flag name with the offending line and caret.
    """
    # CATCHES: the JSON error names "--jsonargs" and points at the "$" of
    # the unparsable positional value
    res = run_gojq(["-n", "--args", "a", "--jsonargs", "1", "$ARGS"],
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == ("gojq: invalid json: --jsonargs\n"
                       "    $ARGS\n"
                       "    ^  invalid character '$' looking for beginning of value\n")
    assert res.rc == 5


@pytest.mark.parametrize("args,expected_out", [
    (["-nc", "$ARGS", "--jsonargs", "1", "2", "--args", "a"],
     '{"named":{},"positional":[1,2,"a"]}\n'),
    (["-nc", "$ARGS", "--args", "a", "--jsonargs", "1", "2"],
     '{"named":{},"positional":["a",1,2]}\n'),
    (["-nc", "$ARGS", "--args", "x", "--args", "y", "z"],
     '{"named":{},"positional":["x","y","z"]}\n'),
    (["-nc", "$ARGS", "--args"],
     '{"named":{},"positional":[]}\n'),
    (["-n", "$ARGS", "--args", "null", "--jsonargs"],
     '{\n  "named": {},\n  "positional": [\n    "null"\n  ]\n}\n'),
])
def test_args_jsonargs_interleaving(tmp_path, args, expected_out):
    """--args and --jsonargs can be interleaved; index slots are shared.

    Native cases "args option with jsonargs option" and "$ARGS variable with
    jsonargs option": switching flags keeps one positional list, with
    --jsonargs values parsed as JSON and written into their slots.
    """
    # CATCHES: switching --jsonargs -> --args pads the string list so JSON
    # values land in the slots they were given ("[1,2,\"a\"] keeps 1 and 2)
    res = run_gojq(args, stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_repeated_arg_flag_keeps_first_value(tmp_path):
    """repeating --arg with the same name keeps the first binding."""
    # CATCHES: the second --arg x 2 is dropped, $x stays the string "1"
    res = run_gojq(["-n", "--arg", "x", "1", "--arg", "x", "2", "$x"],
                   tmp_path=tmp_path)
    assert res.out == '"1"\n'
    assert res.err == ""
    assert res.rc == 0


def test_home_dot_jq_default_module_path(tmp_path):
    """modules are searched in ~/.jq even without -L.

    The default library path is ``~/.jq`` plus the binary's own lib
    directories, so a module dropped into ``$HOME/.jq`` resolves with no
    flags at all.
    """
    # CATCHES: HOME is the module search root, so .jq/h.jq is found by name
    res = run_gojq(["-nc", 'include "h"; h'], stdin="0", tmp_path=tmp_path,
                   files={".jq/h.jq": "def h: 99;\n"})
    assert res.out == "99\n"
    assert res.err == ""
    assert res.rc == 0
