"""Query parse and compile error output (exit code 3, "gojq: " prefix).

Rewritten from the native suite ``cli/test.yaml`` error cases and the
line/column computation table in ``cli/error_test.go`` (which pins the
caret placement, line truncation and 48-column skip rule).
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("query", ["", "# comment"])
def test_missing_query(tmp_path, query):
    """An empty or comment-only query is a compile error with exit code 3.

    Native cases "missing query" and "missing query with comment": the error
    suggests the query ``"."``.
    """
    # CATCHES: empty/comment-only queries are compile errors suggesting (try ".")
    res = run_gojq([query], stdin="null", tmp_path=tmp_path)
    assert res.rc == 3
    assert res.out == ""
    assert res.err == 'gojq: compile error: missing query (try ".")\n'


def test_invalid_token_caret_position(tmp_path):
    """Invalid tokens echo the query with a caret under the token.

    Native case "number literal error" (``0..[empty]``): stderr repeats the
    offending query on its own line and points the caret at the ``0..``
    token, prefixed by the ``gojq: `` program name.
    """
    # CATCHES: caret column points at the invalid token "0.." start
    res = run_gojq(["0..[empty]"], stdin="0", tmp_path=tmp_path)
    assert res.rc == 3
    assert res.out == ""
    assert res.err == ('gojq: invalid query: 0..[empty]\n'
                       '    0..[empty]\n'
                       '    ^  invalid token "0.."\n')


@pytest.mark.parametrize("query,expected_err", [
    ('. + "foo',
     'gojq: invalid query: . + "foo\n    . + "foo\n'
     '            ^  unterminated string literal\n'),
    ('"foo\\,bar"',
     'gojq: invalid query: "foo\\,bar"\n    "foo\\,bar"\n'
     '        ^  invalid escape sequence "\\," in string literal\n'),
    ('"\n\\u\n"',
     'gojq: invalid query: <arg>:2\n    2 | \\u\n'
     '        ^  invalid escape sequence "\\u" in string literal\n'),
])
def test_string_literal_parse_errors(tmp_path, query, expected_err):
    """String literal errors show caret context and switch to line format.

    Native "string query error" cases: an unterminated literal keeps the
    one-line format, an invalid escape repeats the string, and a query
    containing a newline switches to the ``<arg>:<line>`` format with a
    ``<line> | `` context prefix.
    """
    # CATCHES: newline in query switches error format to "<arg>:<line>" style
    res = run_gojq([query], stdin="null", tmp_path=tmp_path)
    assert res.rc == 3
    assert res.out == ""
    assert res.err == expected_err


@pytest.mark.parametrize("query,expected_err", [
    ("abc", "gojq: compile error: function not defined: abc/0\n"),
    ("$abc", "gojq: compile error: variable not defined: $abc\n"),
])
def test_undefined_function_and_variable(tmp_path, query, expected_err):
    """Undefined names fail at compile time, not per input value.

    Native cases "function not defined" and "variable not defined": no input
    is even read; the process exits 3 with a ``compile error:`` message.
    """
    # CATCHES: undefined names are compile errors (exit 3) before any input is read
    res = run_gojq([query], stdin="{}", tmp_path=tmp_path)
    assert res.rc == 3
    assert res.out == ""
    assert res.err == expected_err


def test_multiline_query_error_line_number(tmp_path):
    """Multi-line invalid queries report the exact line and column.

    Native case "invalid multiple line query": the caret sits under the
    ``}`` token on line 3, indented to line up under the quoted line text.
    """
    # CATCHES: line number 3 reported and caret indented under "}" token
    res = run_gojq(["[\n  .[]\n  | { id } }\n]\n"], stdin="{}", tmp_path=tmp_path)
    assert res.rc == 3
    assert res.out == ""
    assert res.err == ('gojq: invalid query: <arg>:3\n'
                       '    3 |   | { id } }\n'
                       '                   ^  unexpected token "}"\n')


@pytest.mark.parametrize("query,expected_err", [
    ("." + "0" * 100 + "!",
     'gojq: invalid query: .' + "0" * 100 + "!\n" +
     '    ' + "0" * 48 + "!\n" +
     ' ' * 52 + '^  unexpected token "!"\n'),
    ("." + "0" * 80 + "!" + "0" * 80,
     'gojq: invalid query: .' + "0" * 80 + "!" + "0" * 80 + "\n" +
     '    ' + "0" * 48 + "!" + "0" * 15 + "\n" +
     ' ' * 52 + '^  unexpected token "!"\n'),
])
def test_long_invalid_line_truncation(tmp_path, query, expected_err):
    """Long error lines are truncated around the 48-column caret window.

    From ``cli/error_test.go`` (getLineByOffset): when the error offset is
    more than 48 characters into the line, the echoed line skips forward so
    the caret lands at column 48, and the echoed line is capped at 64
    characters.
    """
    # CATCHES: echoed line truncated to 64 chars with caret recentered at col 48
    res = run_gojq([query], stdin="null", tmp_path=tmp_path)
    assert res.rc == 3
    assert res.out == ""
    assert res.err == expected_err
