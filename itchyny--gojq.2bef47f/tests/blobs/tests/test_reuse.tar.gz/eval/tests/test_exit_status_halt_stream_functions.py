"""Exit status, halt, debug/stderr and input-stream functions.

Rewritten from the native suite ``cli/test.yaml`` cases "exit status option"
and its variants, "halt function", "halt_error functions", "debug/0
function", "stderr function", "input function" (+ "with files", "error"),
"inputs function" and "input_filename function".
"""

import pytest

from conftest import run_gojq

TESTDATA = {
    "testdata/1.json": '{"foo":10}\n',
    "testdata/2.json": '[{\n"bar"\n:\n[]\n}]\n',
    "testdata/7.json": '1\n2\n{ "foo": 42 }\n',
}


@pytest.mark.parametrize("args,stdin,expected_out,rc", [
    (["-e", "."], "null", "null\n", 1),
    (["--exit-status", "."], "false", "false\n", 1),
    (["--exit-status", "not"], "false", "true\n", 0),
    (["-e", "empty"], "null", "", 4),
    (["--exit-status", "1,not,2"], "false", "1\ntrue\n2\n", 0),
])
def test_exit_status_option(tmp_path, args, stdin, expected_out, rc):
    """-e maps the last output value to 0 (truthy) or 1 (falsy/null).

    Native cases "exit status option" and its long-option variants: ``null``
    and ``false`` results exit 1, ``true`` exits 0, and with several results
    only the last one counts (``2`` in ``1,not,2``).
    """
    # CATCHES: last result decides the code; empty output is a distinct code 4
    res = run_gojq(args, stdin=stdin, tmp_path=tmp_path)
    assert res.rc == rc
    assert res.out == expected_out
    assert res.err == ""


def test_exit_status_with_error(tmp_path):
    """A query error overrides -e and exits with the default error code.

    Native case "exit status long option with error function": ``error`` on
    ``false`` prints ``gojq: error: false`` and exits 5 even with
    ``--exit-status``.
    """
    # CATCHES: query errors still exit 5 even when --exit-status is given
    res = run_gojq(["--exit-status", "error"], stdin="false", tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == "gojq: error: false\n"


def test_halt_stops_processing(tmp_path):
    """halt ends the whole process immediately with exit code 0.

    Native case "halt function": a recursive countdown halts before the
    trailing ``., .`` of the query can produce anything.
    """
    # CATCHES: statements after halt never emit output and the code stays 0
    res = run_gojq(["def f($n): if $n > 0 then $n, f($n - 1) else halt end; "
                    "f(.), ."], stdin="3", tmp_path=tmp_path)
    assert res.out == "3\n2\n1\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("stdin,expected_err,rc", [
    ("1", "1\n", 5),
    ('"foo\\nbar\\nbaz\\n"', "foo\nbar\nbaz\n", 5),
])
def test_halt_error_default_code(tmp_path, stdin, expected_err, rc):
    """halt_error/0 writes the value to stderr and exits 5.

    Native cases "halt_error/0 function" and "...on string": numbers are
    printed as JSON while strings are written raw (embedded newlines kept).
    """
    # CATCHES: halt_error strings go to stderr raw, not JSON-encoded
    res = run_gojq(["halt_error"], stdin=stdin, tmp_path=tmp_path)
    assert res.rc == rc
    assert res.out == ""
    assert res.err == expected_err


@pytest.mark.parametrize("stdin,expected_err,rc", [
    ("null", "", 42),
    ('"foo\\nbar\\nbaz\\n"', "foo\nbar\nbaz\n", 42),
])
def test_halt_error_custom_code(tmp_path, stdin, expected_err, rc):
    """halt_error(N) exits with N; strings are still written raw to stderr.

    Native cases "halt_error/1 function" and "...on string": the custom exit
    code is used verbatim (42) and a null value writes nothing at all.
    """
    # CATCHES: exit code 42 propagates from halt_error's argument
    res = run_gojq(["halt_error(42)"], stdin=stdin, tmp_path=tmp_path)
    assert res.rc == rc
    assert res.out == ""
    assert res.err == expected_err


def test_debug_writes_to_stderr(tmp_path):
    """debug emits ["DEBUG:", <value>] lines on stderr while results flow.

    Native case "debug/0 function": every value passed through ``debug`` is
    compact-JSON-dumped to stderr as a two-element array prefixed by
    ``"DEBUG:"``, without disturbing the stdout stream.
    """
    # CATCHES: debug output goes to stderr as ["DEBUG:",v] per value, rc 0
    res = run_gojq(["-c", "recurse(debug|.[]?)"],
                   stdin='[{}]\n[1,{"a":[2,"b"]}]\n', tmp_path=tmp_path)
    assert res.out == ('[{}]\n{}\n[1,{"a":[2,"b"]}]\n1\n{"a":[2,"b"]}\n'
                       '[2,"b"]\n2\n"b"\n')
    assert res.err == ('["DEBUG:",[{}]]\n["DEBUG:",{}]\n'
                       '["DEBUG:",[1,{"a":[2,"b"]}]]\n["DEBUG:",1]\n'
                       '["DEBUG:",{"a":[2,"b"]}]\n["DEBUG:",[2,"b"]]\n'
                       '["DEBUG:",2]\n["DEBUG:","b"]\n')
    assert res.rc == 0


def test_stderr_function_writes_without_newline(tmp_path):
    """stderr writes the value's compact JSON with no added separator.

    Native case "stderr function": unlike ``debug``, the value is written
    verbatim (compact, no ``["DEBUG:",...]`` wrapper, no newline), so the
    stderr bytes concatenate directly.
    """
    # CATCHES: stderr fn adds no newline and no DEBUG wrapper, rc stays 0
    res = run_gojq(["-c", "recurse(stderr|.[]?)"],
                   stdin='[{}]\n[1,{"a":[2,"b"]}]\n"DEBUG:"\n', tmp_path=tmp_path)
    assert res.out == ('[{}]\n{}\n[1,{"a":[2,"b"]}]\n1\n{"a":[2,"b"]}\n'
                       '[2,"b"]\n2\n"b"\n"DEBUG:"\n')
    assert res.err == '[{}]{}[1,{"a":[2,"b"]}]1{"a":[2,"b"]}[2,"b"]2bDEBUG:'
    assert res.rc == 0


def test_input_function_exhaustion(tmp_path):
    """Reading past the last input with input/0 is a fatal error.

    Native case "input function error": the first ``input`` consumes the only
    value; the second fails with ``gojq: break`` and exit code 5.
    """
    # CATCHES: input/0 past end of stream errors "gojq: break" with rc 5
    res = run_gojq(["-n", "input, input"], stdin="1", tmp_path=tmp_path)
    assert res.out == "1\n"
    assert res.err == "gojq: break\n"
    assert res.rc == 5


def test_input_function_with_files(tmp_path):
    """input/0 pulls the next value across all file arguments in order.

    Native case "input function with files": ``range(5) | input`` reads five
    values from 1.json then 7.json then 1.json again, wrapping around the
    argument list before failing on exhaustion.
    """
    # CATCHES: input reads across file boundaries incl. a repeated file
    res = run_gojq(["-n", "-c", "range(5) | input", "testdata/1.json",
                    "testdata/7.json", "testdata/1.json"],
                   stdin="", tmp_path=tmp_path, files=TESTDATA)
    assert res.out == '{"foo":10}\n1\n2\n{"foo":42}\n{"foo":10}\n'
    assert res.err == ""
    assert res.rc == 0


def test_inputs_function(tmp_path):
    """inputs streams every remaining input value as a generator.

    Native case "inputs function": ``reduce inputs as $x (0; . + $x)`` sums
    the whitespace-separated values of the input stream under -n.
    """
    # CATCHES: inputs yields all values one by one for reduce to fold
    res = run_gojq(["-n", "reduce inputs as $x (0; . + $x)"],
                   stdin="1 2 3 4 5", tmp_path=tmp_path)
    assert res.out == "15\n"
    assert res.err == ""
    assert res.rc == 0


def test_input_filename(tmp_path):
    """input_filename reports the current file, or <stdin> for stdin.

    Native cases "input_filename function with json file arguments" and
    "...with hyphen for stdin": repeated ``-`` arguments re-open stdin but
    only yield values the first time (subsequent reads hit EOF).
    """
    # CATCHES: stdin is reported as "<stdin>" and cannot be rewound
    res = run_gojq(["input_filename", "testdata/1.json", "testdata/2.json"],
                   stdin="0", tmp_path=tmp_path, files=TESTDATA)
    assert res.out == '"testdata/1.json"\n"testdata/2.json"\n'
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["input_filename", "-", "testdata/1.json", "-",
                    "testdata/2.json", "-"],
                   stdin="0", tmp_path=tmp_path, files=TESTDATA)
    assert res.out == '"<stdin>"\n"testdata/1.json"\n"testdata/2.json"\n'
    assert res.err == ""
    assert res.rc == 0
