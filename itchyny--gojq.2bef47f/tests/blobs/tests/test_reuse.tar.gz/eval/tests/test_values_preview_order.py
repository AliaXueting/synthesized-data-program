"""Value types, total sort order and error-message value previews.

Rewritten from the library tests ``cli/../type_test.go`` (``type`` of every
JSON value), ``compare_test.go`` (the total order used by ``sort``) and
``preview_test.go`` (how offending values are rendered in error messages),
plus the per-value error handling of the CLI process loop.
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("stdin,expected_out", [
    ("null", '"null"\n'),
    ("false", '"boolean"\n'),
    ("0", '"number"\n'),
    ('""', '"string"\n'),
    ("[]", '"array"\n'),
    ("{}", '"object"\n'),
])
def test_type_of_each_json_value(tmp_path, stdin, expected_out):
    """type returns the lowercase name of each JSON value's class.

    From ``type_test.go``: null, boolean, number, string, array and object
    each map to their own type string.
    """
    # CATCHES: all six type names distinct; booleans are not "bool"
    res = run_gojq(["-c", "type"], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_sort_total_order_across_types(tmp_path):
    """sort orders null < false < true < numbers < strings < arrays < objects.

    From ``compare_test.go``: a mixed array of every type sorts with null
    first, booleans by truth value, then numbers, strings, arrays (by
    contents) and objects last.
    """
    # CATCHES: cross-type total order puts objects after arrays after strings
    res = run_gojq(["-c", "sort"],
                   stdin='[{}, [], "a", 1, true, false, null, [1], "b", 2]',
                   tmp_path=tmp_path)
    assert res.out == '[null,false,true,1,2,"a","b",[],[1],{}]\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("stdin,expected_out", [
    # strings sort by code points: "" < "A" < "B" < "a" < "ab" < "abc"
    ('["a", "A", "abc", "ab", "B", ""]', '["","A","B","a","ab","abc"]\n'),
    # numbers sort numerically before any string, each group its own way
    ('["10", 9, 2, "2", 1]', '[1,2,9,"10","2"]\n'),
    # big integers compare exactly, not as float64
    ('[10000000000000000000000000000000000000000, 1, -1]',
     '[-1,1,10000000000000000000000000000000000000000]\n'),
    # objects compare keys first: {"a":..} < {"a":..,"b":..} < {"b":..}
    ('[{"b":0}, {"a":2}, {}, {"a":1,"b":0}, {"a":1}]',
     '[{},{"a":1},{"a":2},{"a":1,"b":0},{"b":0}]\n'),
])
def test_sort_within_each_type(tmp_path, stdin, expected_out):
    """Within one type, sort uses the type's natural order.

    From ``compare_test.go``: strings by code points, numbers numerically
    (big integers exactly), and objects by key array first, then values.
    """
    # CATCHES: object order is keys-first, so {"a":2} precedes {"a":1,"b":0}
    res = run_gojq(["-c", "sort"], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_err", [
    (".[]", '"0 1 2 3 4 5 6 7 8 9 10 11 12 13"',
     'gojq: cannot iterate over: string '
     '("0 1 2 3 4 5 6 7 8 9 10 1 ...")\n'),
    (".foo", "10000000000000000000000000000000000000000",
     "gojq: expected an object but got: "
     "number (10000000000000000000000000 ...)\n"),
    (".[]", '"str"', 'gojq: cannot iterate over: string ("str")\n'),
    (".foo", "[1,2]", "gojq: expected an object but got: array ([1,2])\n"),
])
def test_error_value_preview_truncation(tmp_path, query, stdin, expected_err):
    """Long values in error messages are preview-truncated with `` ...``.

    From ``preview_test.go``: long strings and big numbers are cut to a
    fixed prefix followed by ``...``, while short values appear verbatim and
    arrays compactly.
    """
    # CATCHES: long string/number previews truncated to prefix + " ..."
    res = run_gojq([query], stdin=stdin, tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == expected_err


def test_per_value_errors_with_mixed_results(tmp_path):
    """Failing input values only cost their own stderr line; the rest print.

    From the CLI process loop (see ``cli.go``): each input value runs the
    query independently, so an error on one value neither stops processing
    nor suppresses the successful results on stdout.
    """
    # CATCHES: successful values still print between per-value error lines
    res = run_gojq(["-c", ".foo"], stdin='[1]\n{"foo":42}\n"str"\n{"foo":0}\n',
                   tmp_path=tmp_path)
    assert res.out == "42\n0\n"
    assert res.err == ('gojq: expected an object but got: array ([1])\n'
                       'gojq: expected an object but got: string ("str")\n')
    assert res.rc == 5

    res = run_gojq(["-c", ".[] | .foo"],
                   stdin='null\n"string"\n42\n["foo"]\n{"foo":42}\n',
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == ('gojq: cannot iterate over: null\n'
                       'gojq: cannot iterate over: string ("string")\n'
                       'gojq: cannot iterate over: number (42)\n'
                       'gojq: expected an object but got: string ("foo")\n'
                       'gojq: expected an object but got: number (42)\n')
    assert res.rc == 5
