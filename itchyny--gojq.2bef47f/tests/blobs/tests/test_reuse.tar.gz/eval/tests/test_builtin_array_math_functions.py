"""Array, value and math builtins of func.go: add, flatten, the sort
family, has/contains/inside, indices/index/rindex, bsearch, transpose,
reverse, length/keys, clamped indexing and slicing, values/abs/toboolean,
the exp/log/trig/gamma/Bessel function tables and number classification.

Rewritten from the corresponding native ``cli/test.yaml`` cases
('add/0 function', 'flatten/0 function', 'flatten/1 function', 'min,
min_by, max, max_by functions', 'sort, sort_by, group_by functions',
'unique, unique_by functions', 'has function ...', 'contains function',
'inside function', 'indices, index, rindex functions ...',
'transpose function', 'reverse function', 'abs function', 'tonumber
function', 'tostring function' and the math function
cases).  Expected values recorded from the reference binary.
"""

import pytest

from conftest import run_gojq


def test_add_builtin(tmp_path):
    """add folds the + operator over arrays and object values."""
    # CATCHES: empty input gives null; objects merge by key
    res = run_gojq(["-c", "add"],
                   stdin='[]\n[1,2,3]\n["a","b","c"]\n[[3],[4,5],[6]]\n'
                         '[{"a":1}, {"b":2}, {"a":3}]\n{}\n{"a":1,"b":9}\n'
                         '{"a":"a","b":"b","c":"c"}\n'
                         '{"a":[1],"b":[2],"c":[3],"d":[4]}\n',
                   tmp_path=tmp_path)
    assert res.out == ('null\n6\n"abc"\n[3,4,5,6]\n{"a":3,"b":2}\nnull\n'
                       '10\n"abc"\n[1,2,3,4]\n')
    assert res.err == ""
    assert res.rc == 0


def test_add_builtin_errors(tmp_path):
    """add surfaces the + operator errors for mismatched elements."""
    # CATCHES: the message names both offending element previews
    res = run_gojq(["-c", "try add catch ."],
                   stdin='[{}, [], {}]\n["x", null, "y", {}, "z"]\n',
                   tmp_path=tmp_path)
    assert res.out == ('"cannot add: object ({}) and array ([])"\n'
                       '"cannot add: string (\\"xy\\") and object ({})"\n')
    assert res.err == ""
    assert res.rc == 0


def test_flatten(tmp_path):
    """flatten/0 collapses nested arrays completely, one level for objects."""
    # CATCHES: object values are flattened one level, keys dropped
    res = run_gojq(["-c", "flatten"],
                   stdin='[]\n[0, [[[[[1]]]]]]\n[0, [1, [2]], [1, [[3], 2]]]\n'
                         '{"x": [1], "y": [[2]], "z": [[[3]]]}\n',
                   tmp_path=tmp_path)
    assert res.out == '[]\n[0,1]\n[0,1,2,1,3,2]\n[1,2,3]\n'
    assert res.err == ""
    assert res.rc == 0


def test_flatten_depths(tmp_path):
    """flatten/1 flattens exactly depth levels; fractional depths floor."""
    # CATCHES: flatten(1.5) behaves like flatten(1), not an error
    res = run_gojq(["-c", "flatten(0, 1.5, 2)"],
                   stdin='[]\n[0, [[[[[1]]]]]]\n'
                         '[0, [1, [2]], [1, [[3], 2]]]\n',
                   tmp_path=tmp_path)
    assert res.out == ('[]\n[]\n[]\n'
                       '[0,[[[[[1]]]]]]\n[0,1]\n[0,[[[1]]]]\n'
                       '[0,[1,[2]],[1,[[3],2]]]\n[0,1,2,1,3,2]\n'
                       '[0,1,2,1,[3],2]\n')
    assert res.err == ""
    assert res.rc == 0


def test_flatten_errors(tmp_path):
    """flatten rejects non-arrays and negative or nan depths."""
    # CATCHES: nan depth reads as "should not be negative: null"
    res = run_gojq(
        ["-c", 'try flatten catch ., try flatten("") catch ., '
               'try flatten(-1) catch ., try flatten(nan) catch .'],
        stdin="0 [[]]\n[]\n", tmp_path=tmp_path)
    assert res.out == ('"flatten cannot be applied to: number (0)"\n'
                       '"flatten cannot be applied to: number (0)"\n'
                       '"flatten cannot be applied to: number (0)"\n'
                       '"flatten cannot be applied to: number (0)"\n'
                       '[]\n'
                       '"flatten cannot be applied to: string (\\"\\")"\n'
                       '"flatten depth should not be negative: -1"\n'
                       '"flatten depth should not be negative: null"\n'
                       '[]\n'
                       '"flatten cannot be applied to: string (\\"\\")"\n'
                       '"flatten depth should not be negative: -1"\n'
                       '"flatten depth should not be negative: null"\n')
    assert res.err == ""
    assert res.rc == 0


def test_min_max_by_families(tmp_path):
    """min/max/min_by/max_by pick extremes; empty arrays give null."""
    # CATCHES: min_by/max_by on empty stays null, no error
    res = run_gojq(
        ["-c", '[min, min_by(.[1]), min_by(.[2]), '
               'max, max_by(.[1]), max_by(.[2])]'],
        stdin='[]\n[[4,2,"a"],[3,1,"a"],[2,4,"a"],[1,3,"a"]]\n',
        tmp_path=tmp_path)
    assert res.out == ('[null,null,null,null,null,null]\n'
                       '[[1,3,"a"],[3,1,"a"],[4,2,"a"],[4,2,"a"],'
                       '[2,4,"a"],[1,3,"a"]]\n')
    assert res.err == ""
    assert res.rc == 0


def test_sort_group_unique_families(tmp_path):
    """sort_by accepts several keys; group_by groups; unique keeps order."""
    # CATCHES: group_by(.a+.b-.c==2) groups by boolean expression result
    res = run_gojq(
        ["-c", 'sort, sort_by(.a), sort_by(.b, .c), group_by(.b), '
               'group_by(.c, .a), group_by(.a + .b - .c == 2)'],
        stdin='[{"a": 1, "b": 4, "c": 5}, {"a": 4, "b": 1, "c": 2}, '
              '{"a": 1, "b": 4, "c": 3}, {"a": 3, "b": 2, "c": 1}]',
        tmp_path=tmp_path)
    assert res.out == (
        '[{"a":1,"b":4,"c":3},{"a":1,"b":4,"c":5},{"a":3,"b":2,"c":1},'
        '{"a":4,"b":1,"c":2}]\n'
        '[{"a":1,"b":4,"c":5},{"a":1,"b":4,"c":3},{"a":3,"b":2,"c":1},'
        '{"a":4,"b":1,"c":2}]\n'
        '[{"a":4,"b":1,"c":2},{"a":3,"b":2,"c":1},{"a":1,"b":4,"c":3},'
        '{"a":1,"b":4,"c":5}]\n'
        '[[{"a":4,"b":1,"c":2}],[{"a":3,"b":2,"c":1}],'
        '[{"a":1,"b":4,"c":5},{"a":1,"b":4,"c":3}]]\n'
        '[[{"a":3,"b":2,"c":1}],[{"a":4,"b":1,"c":2}],'
        '[{"a":1,"b":4,"c":3}],[{"a":1,"b":4,"c":5}]]\n'
        '[[{"a":1,"b":4,"c":5},{"a":4,"b":1,"c":2},{"a":3,"b":2,"c":1}],'
        '[{"a":1,"b":4,"c":3}]]\n')
    assert res.err == ""
    assert res.rc == 0


def test_unique_and_unique_by(tmp_path):
    """unique sorts then deduplicates; unique_by keys on the expression."""
    # CATCHES: unique_by(length) keeps first of each length, sorted
    res = run_gojq(["-c", "unique, unique_by(length)"],
                   stdin='[7,3,5,1,4,2,5,3,6,1,7,4,3]\n'
                         '["cat", "dog", "hello", "world", "banana", '
                         '"apple"]\n',
                   tmp_path=tmp_path)
    assert res.out == ('[1,2,3,4,5,6,7]\n[1,2,3,4,5,6,7]\n'
                       '["apple","banana","cat","dog","hello","world"]\n'
                       '["cat","hello","banana"]\n')
    assert res.err == ""
    assert res.rc == 0


def test_sort_family_type_errors(tmp_path):
    """the sort family reports its own name for non-array inputs."""
    # CATCHES: min/max/sort/unique have per-function error messages
    res = run_gojq(
        ["-c", 'try min catch ., try max catch ., try sort catch ., '
               'try unique catch ., try group_by(.) catch ., '
               'try min_by(.) catch ., try unique_by(.) catch .'],
        stdin="0", tmp_path=tmp_path)
    assert res.out == ('"min cannot be applied to: number (0)"\n'
                       '"max cannot be applied to: number (0)"\n'
                       '"sort cannot be applied to: number (0)"\n'
                       '"unique cannot be applied to: number (0)"\n'
                       '"cannot iterate over: number (0)"\n'
                       '"cannot iterate over: number (0)"\n'
                       '"cannot iterate over: number (0)"\n')
    assert res.err == ""
    assert res.rc == 0


def test_has_on_objects(tmp_path):
    """has on objects answers per key, driven by a stream of keys."""
    # CATCHES: missing keys answer false without error
    res = run_gojq(["-c", "has(.c[])"],
                   stdin='{"a":{"b":1},"c":["a","b"]}\n{"c":["b","c"]}\n',
                   tmp_path=tmp_path)
    assert res.out == "true\nfalse\nfalse\ntrue\n"
    assert res.err == ""
    assert res.rc == 0


def test_has_on_arrays_and_null(tmp_path):
    """has on arrays does numeric membership; nan is never present."""
    # CATCHES: has(infinite) is false even on long arrays; null has nothing
    res = run_gojq(["-c", "has(2, nan, infinite, -infinite)"],
                   stdin="[1, 2, 3]\n[1, 3]\nnull\n", tmp_path=tmp_path)
    assert res.out == "true\n" + "false\n" * 11
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_err,expected_rc", [
    ("has(0)", "{}", "gojq: has(0) cannot be applied to: object ({})\n", 5),
    ("has(1; 2)", "[0]",
     "gojq: compile error: function not defined: has/2\n", 3),
])
def test_has_errors(tmp_path, query, stdin, expected_err, expected_rc):
    """has type errors at runtime and arity errors at compile time."""
    # CATCHES: has/2 is rejected before any input is read
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == expected_rc


def test_contains_matrix(tmp_path):
    """contains checks deep containment: substrings, subsequences, subsets."""
    # CATCHES: [1,2,3] contains [3,1] as a multiset, not a subsequence
    res = run_gojq(
        ["-c", '.[] as $x | (null,false,true,[],[3,4],[3,1],"foo","ll",'
               '{},{"a":1},{"a":""},{"b":[5]},{"a":3,"b":[5]}) as $y | '
               '$x | [$x,$y,contains($y)]?'],
        stdin='[null,false,true,[],[1,2,3],"","hello",{"a":3,"b":[4,5,6]}]',
        tmp_path=tmp_path)
    assert res.out == (
        '[null,null,true]\n[false,false,true]\n[true,true,true]\n'
        '[[],[],true]\n[[],[3,4],false]\n[[],[3,1],false]\n'
        '[[1,2,3],[],true]\n[[1,2,3],[3,4],false]\n[[1,2,3],[3,1],true]\n'
        '["","foo",false]\n["","ll",false]\n["hello","foo",false]\n'
        '["hello","ll",true]\n'
        '[{"a":3,"b":[4,5,6]},{},true]\n[{"a":3,"b":[4,5,6]},{"a":1},'
        'false]\n[{"a":3,"b":[4,5,6]},{"a":""},false]\n'
        '[{"a":3,"b":[4,5,6]},{"b":[5]},true]\n'
        '[{"a":3,"b":[4,5,6]},{"a":3,"b":[5]},true]\n')
    assert res.err == ""
    assert res.rc == 0


def test_contains_error(tmp_path):
    """contains against a nan input previews nan as null in the message."""
    # CATCHES: the error echoes the argument array with null for nan
    res = run_gojq(["-c", 'try (nan | contains([nan])) catch .'],
                   stdin="0", tmp_path=tmp_path)
    assert res.out == \
        '"contains([null]) cannot be applied to: number (null)"\n'
    assert res.err == ""
    assert res.rc == 0


def test_inside_matrix(tmp_path):
    """inside(x) is containment with the roles swapped."""
    # CATCHES: ["bar","baz"] inside ["foobaz","foobar"] via substrings
    res = run_gojq(
        ["-c", '.[] as $x | (false,"abc",[],["foobaz","foobar"],'
               '{},{"a":10,"b":20,"c":30}) as $y | $x | '
               '[$x,$y,inside($y)]?'],
        stdin='["a",["bar","baz"],{"a":10,"b":20}]', tmp_path=tmp_path)
    assert res.out == ('["a","abc",true]\n[["bar","baz"],[],false]\n'
                       '[["bar","baz"],["foobaz","foobar"],true]\n'
                       '[{"a":10,"b":20},{},false]\n'
                       '[{"a":10,"b":20},{"a":10,"b":20,"c":30},true]\n')
    assert res.err == ""
    assert res.rc == 0


def test_indices_family_on_null(tmp_path):
    """indices/index/rindex on null all give null."""
    # CATCHES: no error for null input, plain null output
    res = run_gojq(["-c", "[indices(0), index(0), rindex(0)]"],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == "[null,null,null]\n"
    assert res.err == ""
    assert res.rc == 0


def test_indices_family_on_arrays(tmp_path):
    """indices reports all match positions; index/rindex first and last."""
    # CATCHES: subarray [1,2,1] matches at overlapping-safe positions only
    res = run_gojq(
        ["-c", '[indices(0, 1, [1, 2, 1])], [index(0, 1, [1, 2])], '
               '[rindex(0, 1, [1, 2])]'],
        stdin="[]\n[0]\n[0, 1, 2, 1, 2, 1, 0, 1, 0]\n", tmp_path=tmp_path)
    assert res.out == ('[[],[],[]]\n[null,null,null]\n[null,null,null]\n'
                       '[[0],[],[]]\n[0,null,null]\n[0,null,null]\n'
                       '[[0,6,8],[1,3,5,7],[1,3]]\n[0,1,1]\n[8,7,3]\n')
    assert res.err == ""
    assert res.rc == 0


def test_indices_family_on_strings(tmp_path):
    """indices on strings finds substring offsets in code points."""
    # CATCHES: the empty string matches nowhere (unlike regex splits)
    res = run_gojq(
        ["-c", '[indices("", ",", "x")], [index("", ",", "x")], '
               '[rindex("", ",", "x")]'],
        stdin='"a,bc,def,ghij,klmno"', tmp_path=tmp_path)
    assert res.out == ('[[],[1,4,8,13],[]]\n[null,1,null]\n'
                       '[null,13,null]\n')
    assert res.err == ""
    assert res.rc == 0


def test_indices_family_multibyte(tmp_path):
    """indices offsets count code points even for multibyte text."""
    # CATCHES: "３４" found at 3, not at a byte offset like 6
    res = run_gojq(
        ["-c", '[indices("０", "１", "３４")], [index("０", "１", "３４")], '
               '[rindex("０", "１", "３４")]'],
        stdin='"０１２３４０"', tmp_path=tmp_path)
    assert res.out == "[[0,5],[1],[3]]\n[0,1,3]\n[5,1,3]\n"
    assert res.err == ""
    assert res.rc == 0


def test_indices_family_type_errors(tmp_path):
    """indices/index/rindex share one error wording per function."""
    # CATCHES: each function name appears in its own error message
    res = run_gojq(
        ["-c", '(try indices([]) catch .), (try index([]) catch .), '
               "(try rindex([]) catch .)"],
        stdin="{}", tmp_path=tmp_path)
    assert res.out == ('"indices([]) cannot be applied to: object ({})"\n'
                       '"index([]) cannot be applied to: object ({})"\n'
                       '"rindex([]) cannot be applied to: object ({})"\n')
    assert res.err == ""
    assert res.rc == 0


def test_bsearch(tmp_path):
    """bsearch returns the index or -(insertion point)-1 when absent."""
    # CATCHES: absent values return negative encoded positions
    res = run_gojq(["-c", "bsearch(0,1,2,3,4,5,6)"],
                   stdin="[1,3,5]", tmp_path=tmp_path)
    assert res.out == "-1\n0\n-2\n1\n-3\n2\n-4\n"
    assert res.err == ""
    assert res.rc == 0


def test_bsearch_objects(tmp_path):
    """bsearch compares with the total order, objects included."""
    # CATCHES: {x:1,y:1} sits at index 4 of the keyed cross product
    res = run_gojq(["-c", '[{x:range(.),y:range(.)}] | bsearch({x:1,y:1})'],
                   stdin="3", tmp_path=tmp_path)
    assert res.out == "4\n"
    assert res.err == ""
    assert res.rc == 0


def test_transpose(tmp_path):
    """transpose pads ragged arrays with nulls."""
    # CATCHES: shorter columns gain trailing nulls, not truncation
    res = run_gojq(["-c", "transpose"],
                   stdin='[]\n[[1,2,3,[]],[4,"foo",{}],[5,6]]\n',
                   tmp_path=tmp_path)
    assert res.out == \
        '[]\n[[1,4,5],[2,"foo",6],[3,{},null],[[],null,null]]\n'
    assert res.err == ""
    assert res.rc == 0


def test_reverse(tmp_path):
    """reverse flips arrays; strings are rejected with rc 5."""
    # CATCHES: reverse on a string errors instead of reversing chars
    res = run_gojq(["-c", "reverse"],
                   stdin='[0, 1, 2, 3, 4]\n"abcde"\n[]\n', tmp_path=tmp_path)
    assert res.out == "[4,3,2,1,0]\n[]\n"
    assert res.err == 'gojq: reverse cannot be applied to: string ("abcde")\n'
    assert res.rc == 5


def test_length_matrix(tmp_path):
    """length: null 0, numbers absolute, strings runes, containers sizes."""
    # CATCHES: -2 has length 2; big ints keep exact magnitude
    res = run_gojq(["-c", "length"],
                   stdin='null\n0\n1.5\n-2\n1000000000000000000000\n'
                         '"foobar"\n"日本語"\n[]\n[1,2,3]\n{}\n'
                         '{"a":1,"b":2}\n',
                   tmp_path=tmp_path)
    assert res.out == ('0\n0\n1.5\n2\n1000000000000000000000\n6\n3\n0\n'
                       '3\n0\n2\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("stdin,expected_err", [
    ("true\n", "gojq: length cannot be applied to: boolean (true)\n"),
    ("false\n", "gojq: length cannot be applied to: boolean (false)\n"),
])
def test_length_type_errors(tmp_path, stdin, expected_err):
    """length refuses booleans with the value echoed."""
    # CATCHES: true and false are named individually, not as "boolean"
    res = run_gojq(["-c", "length"], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


def test_utf8bytelength(tmp_path):
    """utf8bytelength counts bytes, unlike length's code points."""
    # CATCHES: "日本語" is 3 runes but 9 bytes
    res = run_gojq(["-c", "utf8bytelength"],
                   stdin='"foobar"\n"ä"\n"日本語"\n""\n', tmp_path=tmp_path)
    assert res.out == "6\n2\n9\n0\n"
    assert res.err == ""
    assert res.rc == 0


def test_utf8bytelength_type_error(tmp_path):
    """utf8bytelength only accepts strings."""
    # CATCHES: numbers are rejected even though length accepts them
    res = run_gojq(["-c", "utf8bytelength"], stdin="1\n", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: utf8bytelength cannot be applied to: number (1)\n"
    assert res.rc == 5


def test_keys(tmp_path):
    """keys sorts object keys and returns indices for arrays."""
    # CATCHES: object keys come out sorted, array keys as 0..n-1
    res = run_gojq(["-c", "keys"],
                   stdin='{"foo": 1, "bar": 2, "baz": 3}\n[10, 1, 100]\n',
                   tmp_path=tmp_path)
    assert res.out == '["bar","baz","foo"]\n[0,1,2]\n'
    assert res.err == ""
    assert res.rc == 0


def test_keys_type_error(tmp_path):
    """keys rejects scalars."""
    # CATCHES: scalar input produces the func0TypeError form
    res = run_gojq(["-c", "keys"], stdin="1\n", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: keys cannot be applied to: number (1)\n"
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('.[0], .[1], .[5], .[-1], .[-5]', "[1, 2]\n",
     "1\n2\nnull\n2\nnull\n"),
    ('.[1], .[-1], .[9]', '"ab"\n', '"b"\n"b"\nnull\n'),
    ('.[9], .[-9]', '"abc"\n', "null\nnull\n"),
])
def test_clamped_indexing(tmp_path, query, stdin, expected_out):
    """out-of-range indices give null; negatives count from the end."""
    # CATCHES: single-char strings index like one-element arrays
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_clamped_string_index_on_array_error(tmp_path):
    """string keys on arrays are type errors, not null."""
    # CATCHES: .["x"] against [1,2] fails unlike .["x"] against objects
    res = run_gojq(["-c", '.["x"]'], stdin="[1, 2]\n", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: expected an object but got: array ([1,2])\n"
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('.[2:5], .[-5:-1], .[1:0], .[-2:], .[:2]', "[1, 2, 3]\n",
     "[3]\n[1,2]\n[]\n[2,3]\n[1,2]\n"),
    ('.[1:100], .[-100:1], .[2:], .[:0]', '"abcde"\n',
     '"bcde"\n"a"\n"cde"\n""\n'),
])
def test_clamped_slicing(tmp_path, query, stdin, expected_out):
    """slice bounds clamp to the container; start>end gives empty."""
    # CATCHES: .[1:0] is [] rather than reversed
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_values_filter(tmp_path):
    """values filters out only null, keeping false and empty containers."""
    # CATCHES: false survives values, unlike truthiness filters
    res = run_gojq(["-c", "map(values)"],
                   stdin='[null, false, 0, "", [], {}, "x"]\n',
                   tmp_path=tmp_path)
    assert res.out == '[false,0,"",[],{},"x"]\n'
    assert res.err == ""
    assert res.rc == 0


def test_abs(tmp_path):
    """abs negates negatives exactly, big integers included."""
    # CATCHES: 4722366482869645213696 (2**72) survives as an exact int
    res = run_gojq(
        ["-c", "map(abs), (.[] | abs)"],
        stdin='[-1, 1, -1.5, 1.5, -10000000000000000000000000000000000000000, '
              "-4722366482869645213696]\n",
        tmp_path=tmp_path)
    assert res.out == ('[1,1,1.5,1.5,10000000000000000000000000000000000000000,'
                       '4722366482869645213696]\n'
                       '1\n1\n1.5\n1.5\n'
                       '10000000000000000000000000000000000000000\n'
                       "4722366482869645213696\n")
    assert res.err == ""
    assert res.rc == 0


def test_toboolean(tmp_path):
    """toboolean accepts the strings "true"/"false" and booleans."""
    # CATCHES: "TRUE" is rejected; case matters
    res = run_gojq(["-c", "toboolean"],
                   stdin='"true"\n"false"\ntrue\nfalse\n', tmp_path=tmp_path)
    assert res.out == "true\nfalse\ntrue\nfalse\n"
    assert res.err == ""
    assert res.rc == 0


def test_toboolean_errors(tmp_path):
    """toboolean errors distinguish type failures from bad literals."""
    # CATCHES: wrong-case strings get their own "invalid boolean" message
    res = run_gojq(["-c", "try toboolean catch ."],
                   stdin='1\n"TRUE"\nnull\n', tmp_path=tmp_path)
    assert res.out == ('"toboolean cannot be applied to: number (1)"\n'
                       '"toboolean cannot be applied to \\"TRUE\\": '
                       'invalid boolean"\n'
                       '"toboolean cannot be applied to: null"\n')
    assert res.err == ""
    assert res.rc == 0


def test_number_classification(tmp_path):
    """isfinite/isinfinite/isnan/isnormal classify IEEE values."""
    # CATCHES: nan is not normal and -0 prints as plain 0
    res = run_gojq(
        ["-c", '(nan, infinite, -infinite, 0, -0, 1, '
               '1.7976931348623157e+308) | '
               "[., isfinite, isinfinite, isnan, isnormal]"],
        stdin="null", tmp_path=tmp_path)
    assert res.out == (
        "[null,true,false,true,false]\n"
        "[1.7976931348623157e+308,false,true,false,false]\n"
        "[-1.7976931348623157e+308,false,true,false,false]\n"
        "[0,true,false,false,false]\n"
        "[0,true,false,false,false]\n"
        "[1,true,false,false,true]\n"
        "[1.7976931348623157e+308,true,false,false,true]\n")
    assert res.err == ""
    assert res.rc == 0


def test_isnan_type_errors(tmp_path):
    """isnan rejects non-numbers with per-type messages."""
    # CATCHES: each container type gets its own preview in the message
    res = run_gojq(['-c', '"", [], {} | try isnan catch .'],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == ('"isnan cannot be applied to: string (\\"\\")"\n'
                       '"isnan cannot be applied to: array ([])"\n'
                       '"isnan cannot be applied to: object ({})"\n')
    assert res.err == ""
    assert res.rc == 0


def test_finites_and_normals_streams(tmp_path):
    """finites/normals filter streams of numbers by IEEE class."""
    # CATCHES: negatives pass finites; subnormals fail normals
    res = run_gojq(
        ["-c", '[nan, infinite, -infinite, 0, 1, '
               '2.2250738585072014e-308 | ., -. | finites], '
               "[0, 2.2250738585072014e-308, 1, nan, infinite | normals], "
               "[0, 2.2250738585072011e-308, 2.2250738585072014e-308, 1, "
               '1.7976931348623157e+308, nan, infinite, "", [], {} '
               "| [., isnormal]]"],
        stdin="null", tmp_path=tmp_path)
    assert res.out == (
        "[null,null,0,0,1,-1,2.2250738585072014e-308,"
        "-2.2250738585072014e-308]\n"
        "[2.2250738585072014e-308,1]\n"
        "[[0,false],[2.225073858507201e-308,false],"
        "[2.2250738585072014e-308,true],[1,true],"
        "[1.7976931348623157e+308,true],[null,false],"
        "[1.7976931348623157e+308,false],"
        '["",false],[[],false],[{},false]]\n')
    assert res.err == ""
    assert res.rc == 0


def test_rounding_functions(tmp_path):
    """floor/ceil/trunc/fabs/round/nearbyint differ on halves and signs."""
    # CATCHES: -2.5 floors to -3 but rounds to -2; nearbyint rounds to even
    res = run_gojq(
        ["-c", "map(floor), map(ceil), map(trunc), map(fabs), "
               "map(round), map(nearbyint)"],
        stdin="[-3.7, -3.3, -2.5, -1.7, -1.0, -0.7, -0.3, 0.0, 0.3, "
              "0.5, 0.7, 1.0, 1.7, 2.5, 3.3, 3.7]",
        tmp_path=tmp_path)
    assert res.out == (
        "[-4,-4,-3,-2,-1,-1,-1,0,0,0,0,1,1,2,3,3]\n"
        "[-3,-3,-2,-1,-1,-0,-0,0,1,1,1,1,2,3,4,4]\n"
        "[-3,-3,-2,-1,-1,-0,-0,0,0,0,0,1,1,2,3,3]\n"
        "[3.7,3.3,2.5,1.7,1,0.7,0.3,0,0.3,0.5,0.7,1,1.7,2.5,3.3,3.7]\n"
        "[-4,-3,-3,-2,-1,-1,-0,0,0,1,1,1,2,3,3,4]\n"
        "[-4,-3,-2,-2,-1,-1,-0,0,0,0,1,1,2,2,3,4]\n")
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("map(sqrt), map(cbrt) | map(. * 1000000000 | floor / 1000000000)",
     "[-8, -3.375, 0, 0.125, 1, 4, 8, 9, 16.777216]",
     "[null,null,0,0.35355339,1,2,2.828427124,3,4.096]\n"
     "[-2,-1.5,0,0.5,1,1.587401051,2,2.080083823,2.56]\n"),
    ("[floor, ceil, sqrt, exp10]",
     "1e1000\n-1e1000\n",
     "[1.7976931348623157e+308,1.7976931348623157e+308,"
     "1.7976931348623157e+308,1.7976931348623157e+308]\n"
     "[-1.7976931348623157e+308,-1.7976931348623157e+308,null,0]\n"),
])
def test_sqrt_cbrt_and_big_values(tmp_path, query, stdin, expected_out):
    """sqrt/cbrt on negatives give null; huge literals clamp to ±Inf.

    From ``cli/test.yaml`` math cases: sqrt of a negative is null, and
    1e1000 parses to the IEEE maximum, so floor/ceil/sqrt saturate.
    """
    # CATCHES: exp10 of -1e1000 underflows to 0, sqrt(-inf) to null
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("map(exp), map(exp2), map(exp10), map(expm1)", "[0, 1, 2]",
     "[1,2.718281828459045,7.38905609893065]\n[1,2,4]\n[1,10,100]\n"
     "[0,1.718281828459045,6.38905609893065]\n"),
    ("map(log), map(log2), map(log10), map(log1p), map(logb)",
     "[1, 2, 10, 1024, 0.5]",
     "[0,0.6931471805599453,2.302585092994046,6.931471805599453,"
     "-0.6931471805599453]\n"
     "[0,1,3.321928094887362,10,-1]\n"
     "[0,0.3010299956639812,1,3.010299956639812,-0.3010299956639812]\n"
     "[0.6931471805599453,1.0986122886681096,2.3978952727983707,"
     "6.932447891572509,0.4054651081081644]\n"
     "[0,1,3,10,-1]\n"),
    # log(0) family saturates at -Inf, rendered as the float maximum
    ("map(log), map(log2), map(log10)", "[0]",
     "[-1.7976931348623157e+308]\n[-1.7976931348623157e+308]\n"
     "[-1.7976931348623157e+308]\n"),
])
def test_exp_log_families(tmp_path, query, stdin, expected_out):
    """exp/exp2/exp10/expm1 and log/log2/log10/log1p/logb as /0 builtins.

    The math functions apply to the input value, so they are invoked
    without arguments (exp/1 does not exist in this build).
    """
    # CATCHES: log(0) prints as -1.7976931348623157e+308, not "-inf"
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("map(significand)",
     "[0, -0.5, 1, -1.5, 2, 10, 64, 100, 5e-324, -5e-324]",
     "[0,-1,1,-1.5,1,1.25,1,1.5625,1,-1]\n"),
    ("map(frexp), map(modf)", "[0, 0.25, -0.5, 1, -1.5, 2, 3.125]",
     "[[0,0],[0.5,-1],[-0.5,0],[0.5,1],[-0.75,1],[0.5,2],[0.78125,2]]\n"
     "[[0,0],[0.25,0],[-0.5,-0],[0,1],[-0.5,-1],[0,2],[0.125,3]]\n"),
    ("infinite, -infinite | modf", "null",
     "[0,1.7976931348623157e+308]\n[-0,-1.7976931348623157e+308]\n"),
    ("[pow(0,0.5,2; 0,0.5,-2,3,10)]", "null",
     "[1,1,1,0,0.7071067811865476,1.4142135623730951,"
     "1.7976931348623157e+308,4,0.25,0,0.125,8,0,0.0009765625,1024]\n"),
    ("[ldexp(0,0.5,2; 0,0.5,-2,3,10)]", "null",
     "[0,0.5,2,0,0.5,2,0,0.125,0.5,0,4,16,0,512,2048]\n"),
])
def test_significand_frexp_modf_pow_ldexp(tmp_path, query, stdin,
                                          expected_out):
    """significand/frexp/modf expose float internals; pow/ldexp scale.

    From ``cli/test.yaml`` math cases: frexp returns [fraction, exp2],
    modf returns [fraction, integer], pow/ldexp take cartesian products
    of their two argument streams.
    """
    # CATCHES: modf(-infinite) keeps a -0 fraction and -inf integer
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ("[fdim(0.25,0.625; 0.125,0.375)]", "[0.125,0.5,0,0.25]\n"),
    ("[fmax(0.1,0.3; 0.2,0.4)]", "[0.2,0.3,0.4,0.4]\n"),
    ("[fmin(0.1,0.3; 0.2,0.4)]", "[0.1,0.2,0.1,0.3]\n"),
    # nan loses against a number for fdim/fmax/fmin, but nan-nan is nan
    ("[fdim(1,nan; 1,nan)]", "[0,null,null,null]\n"),
    ("[fmax(1,nan; 1,nan)]", "[1,1,1,null]\n"),
    ("[fmin(1,nan; 1,nan)]", "[1,1,1,null]\n"),
    ("[copysign(0,0.5,-1.5; 0,1,-3.5)]",
     "[0,0.5,1.5,0,0.5,1.5,-0,-0.5,-1.5]\n"),
    ("[drem(0.5,-0.75,1.125; 0.5,-0.25)], "
     "[fmod(0.5,-0.75,1.125; 0.5,-0.25)], "
     "[remainder(0.5,-0.75,1.125; 0.5,-0.25)]",
     "[0,0.25,0.125,0,-0,0.125]\n[0,-0.25,0.125,0,-0,0.125]\n"
     "[0,0.25,0.125,0,-0,0.125]\n"),
    ("[nextafter(0, 1; 2)], [scalb(0.5, 1; 0, 1)]",
     "[5e-324,1.0000000000000002]\n[0.5,1,1,2]\n"),
    ("[nextafter(1; 2), nextafter(2; 1), scalb(0.5; 3), scalb(1; -2)]",
     "[1.0000000000000002,1.9999999999999998,4,0.25]\n"),
    ("[atan2(0,1; 0,1,-3)], [hypot(0,-3.75,12; 0,5,-16)] | "
     "map(. * 1000000000 | floor / 1000000000)",
     "[0,1.570796326,0,0.785398163,3.141592653,2.819842099]\n"
     "[0,3.75,12,5,6.25,13,16,16.433578429,20]\n"),
])
def test_two_argument_math(tmp_path, query, expected_out):
    """two-argument math builtins take cartesian products of streams.

    From ``cli/test.yaml`` math cases for fdim/fmax/fmin/copysign/
    drem/fmod/remainder/nextafter/scalb/atan2/hypot.
    """
    # CATCHES: fmax/fmin prefer the number over nan; copysign keeps -0
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("map(sin), map(cos), map(tan) | map(. * 1000000000 | floor / 1000000000)",
     "[0, 1, 2]",
     "[0,0.841470984,0.909297426]\n[1,0.540302305,-0.416146837]\n"
     "[0,1.557407724,-2.185039864]\n"),
    ("map(asin), map(acos), map(atan), map(asinh), map(acosh), map(atanh) | "
     "map(. * 1000000000 | floor / 1000000000)", "[0, 1, 2]",
     "[0,1.570796326,null]\n[1.570796326,0,null]\n"
     "[0,0.785398163,1.107148717]\n[0,0.881373587,1.443635475]\n"
     "[null,0,1.316957896]\n[0,1.7976931348623157e+308,null]\n"),
    ("map(gamma), map(lgamma), map(tgamma) | "
     "map(. * 1000000000 | floor / 1000000000)", "[1, 2, 5, 0.5, 1.5, -0.5]",
     "[1,1,24,1.77245385,0.886226925,-3.544907702]\n"
     "[0,0,3.17805383,0.572364942,-0.120782238,1.265512123]\n"
     "[1,1,24,1.77245385,0.886226925,-3.544907702]\n"),
    ("map(erf), map(erfc) | map(. * 1000000000 | floor / 1000000000)",
     "[0, 0.5, 1, 2]",
     "[0,0.520499877,0.842700792,0.995322265]\n"
     "[1,0.479500122,0.157299207,0.004677734]\n"),
    ("map(j0), map(j1), map(y0), map(y1) | "
     "map(. * 1000000000 | floor / 1000000000)", "[1, 2]",
     "[0.765197686,0.223890779]\n[0.440050585,0.576724807]\n"
     "[0.088256964,0.510375672]\n[-0.781212822,-0.107032432]\n"),
    ("[jn(0, 1, 2; 1, 2), yn(0, 1, 2; 1, 2)] | "
     "map(. * 1000000000 | floor / 1000000000)", "null",
     "[0.765197686,0.440050585,0.114903484,0.223890779,0.576724807,"
     "0.352834028,0.088256964,-0.781212822,-1.650682607,0.510375672,"
     "-0.107032432,-0.617408105]\n"),
])
def test_trig_gamma_and_bessel(tmp_path, query, stdin, expected_out):
    """trig, inverse trig, gamma, error-function and Bessel builtins."""
    # CATCHES: domain errors (asin(2)) become null, not errors
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ("nan, infinite, -infinite | [., tostring, tojson]",
     '[null,"null","null"]\n'
     '[1.7976931348623157e+308,"1.7976931348623157e+308",'
     '"1.7976931348623157e+308"]\n'
     '[-1.7976931348623157e+308,"-1.7976931348623157e+308",'
     '"-1.7976931348623157e+308"]\n'),
    # nan comparisons are inconsistent on purpose: == false but < true
    ("nan | [.<., .>., .<0, .>0, .==., .!=.]",
     "[true,false,true,false,false,true]\n"),
])
def test_nan_infinite_encoding_and_comparison(tmp_path, query, expected_out):
    """nan prints as null and infinite as the float maximum."""
    # CATCHES: nan < nan is true even though nan == nan is false
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_infinite_arithmetic_matrix(tmp_path):
    """infinite propagates through arithmetic and cancels to nan."""
    # CATCHES: inf-inf and inf/inf give null (nan rendered as null)
    res = run_gojq(
        ["-c", "[infinite, -infinite] | (.[], .[]+.[], .[]-.[], .[]*.[], "
               ".[]/.[], 1/.[], -1/.[], .[]-1e300, .[]+1e300) | "
               "[., . == infinite, . == -infinite]"],
        stdin="null", tmp_path=tmp_path)
    assert res.out == (
        "[1.7976931348623157e+308,true,false]\n"
        "[-1.7976931348623157e+308,false,true]\n"
        "[1.7976931348623157e+308,true,false]\n"
        "[null,false,false]\n[null,false,false]\n"
        "[-1.7976931348623157e+308,false,true]\n"
        "[null,false,false]\n"
        "[-1.7976931348623157e+308,false,true]\n"
        "[1.7976931348623157e+308,true,false]\n"
        "[null,false,false]\n"
        "[1.7976931348623157e+308,true,false]\n"
        "[-1.7976931348623157e+308,false,true]\n"
        "[-1.7976931348623157e+308,false,true]\n"
        "[1.7976931348623157e+308,true,false]\n"
        "[null,false,false]\n[null,false,false]\n[null,false,false]\n"
        "[null,false,false]\n[0,false,false]\n[-0,false,false]\n"
        "[-0,false,false]\n[0,false,false]\n"
        "[1.7976931348623157e+308,true,false]\n"
        "[-1.7976931348623157e+308,false,true]\n"
        "[1.7976931348623157e+308,true,false]\n"
        "[-1.7976931348623157e+308,false,true]\n")
    assert res.err == ""
    assert res.rc == 0


def test_tonumber(tmp_path):
    """tonumber parses JSON number text exactly, big ints included."""
    # CATCHES: "9." and "+.123" parse; "05" keeps no octal meaning
    res = run_gojq(["-c", "tonumber"],
                   stdin='"0"\n"12345"\n"-43210"\n'
                         '"10000000000000000000"\n"+4.2"\n"05"\n"9."\n'
                         '"+.123"\n"-.1"\n"1e-2"\n"2.e-2"\n"1e300"\n'
                         '"1e1000"\n3.14\n',
                   tmp_path=tmp_path)
    assert res.out == ("0\n12345\n-43210\n10000000000000000000\n4.2\n5\n"
                       "9\n0.123\n-0.1\n0.01\n0.02\n1e+300\n"
                       "1.7976931348623157e+308\n3.14\n")
    assert res.err == ""
    assert res.rc == 0


def test_tonumber_errors(tmp_path):
    """tonumber reports the literal it could not parse."""
    # CATCHES: each rejected literal appears verbatim in its message
    res = run_gojq(["-c", "try tonumber catch ."],
                   stdin='""\n"."\n" "\n"1a"\n".e1"\n"-.e"\n',
                   tmp_path=tmp_path)
    assert res.out == ('"tonumber cannot be applied to \\"\\": '
                       'invalid number"\n'
                       '"tonumber cannot be applied to \\".\\": '
                       'invalid number"\n'
                       '"tonumber cannot be applied to \\" \\": '
                       'invalid number"\n'
                       '"tonumber cannot be applied to \\"1a\\": '
                       'invalid number"\n'
                       '"tonumber cannot be applied to \\".e1\\": '
                       'invalid number"\n'
                       '"tonumber cannot be applied to \\"-.e\\": '
                       'invalid number"\n')
    assert res.err == ""
    assert res.rc == 0


def test_tostring(tmp_path):
    """tostring keeps strings bare and JSON-encodes everything else."""
    # CATCHES: string input is returned unchanged, not requoted
    res = run_gojq(["-c", "tostring"],
                   stdin='null\nfalse\ntrue\n3.14\n"foo bar"\n'
                         '{"foo": "-43210"}\n[1,2,3]\n["<&><>"]\n',
                   tmp_path=tmp_path)
    assert res.out == ('"null"\n"false"\n"true"\n"3.14"\n"foo bar"\n'
                       '"{\\"foo\\":\\"-43210\\"}"\n"[1,2,3]"\n'
                       '"[\\"<&><>\\"]"\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ('try ("" | floor) catch .',
     '"floor cannot be applied to: string (\\"\\")"\n'),
    ('try (pow(1; "")) catch .',
     '"pow cannot be applied to: string (\\"\\")"\n'),
    ('try ({} | sqrt) catch .',
     '"sqrt cannot be applied to: object ({})"\n'),
])
def test_math_function_type_errors(tmp_path, query, expected_out):
    """math builtins reject non-number inputs, one- and two-arg alike."""
    # CATCHES: pow's second argument type is checked too
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0
