"""Input reading options: -R/-n/-s/--stream/--yaml-input and combinations.

Rewritten from the native suite ``cli/test.yaml`` cases "raw string input
option", "null input value option", "slurp option", "stream option" and the
``--yaml-input`` cases (also mirroring ``cli/inputs_test.go``
``TestYAMLInputIter``).
"""

import pytest

from conftest import run_gojq


def test_raw_input_lines(tmp_path):
    r"""-R reads each input line as a raw string, stripping the terminator.

    Native case "raw string input option": a lone CR inside a line is kept
    (and re-escaped on output) while the trailing line terminator is
    stripped; a missing final newline does not drop the last line.
    """
    # CATCHES: embedded \r kept verbatim, final unterminated line still read
    res = run_gojq(["-R", "."], stdin="null\nfalse\r\nfoo\nbar", tmp_path=tmp_path)
    assert res.out == '"null"\n"false\\r"\n"foo"\n"bar"\n'
    assert res.err == ""
    assert res.rc == 0


def test_raw_input_errors_accumulate(tmp_path):
    """Every raw line is processed; each failure adds one stderr line.

    Native case "raw string input option error": dividing three raw lines
    by 2 produces three separate ``cannot divide`` errors (each prefixed by
    ``gojq: ``) and exit code 5.
    """
    # CATCHES: per-line errors accumulate instead of stopping at the first
    res = run_gojq(["-R", ". / 2"], stdin='{\n  "foo": "bar"\n}\n',
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == ('gojq: cannot divide: string ("{") and number (2)\n'
                       'gojq: cannot divide: string ("  \\"foo\\": \\"bar\\"") '
                       'and number (2)\n'
                       'gojq: cannot divide: string ("}") and number (2)\n')
    assert res.rc == 5


def test_null_input_ignores_stdin(tmp_path):
    """-n runs the query once with null, ignoring piped input.

    Native cases "null input value option" and "null input value option with
    raw string input option": even combined with -R the input stream is not
    consumed.
    """
    # CATCHES: -n with -R still yields null, stdin is never read
    res = run_gojq(["-n", "[.]"], stdin="", tmp_path=tmp_path)
    assert res.out == "[\n  null\n]\n"
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["-n", "-R", "."], stdin="foo", tmp_path=tmp_path)
    assert res.out == "null\n"
    assert res.rc == 0


def test_slurp_collects_values(tmp_path):
    """-s wraps all inputs into one array; with -R the whole text is one string.

    Native cases "slurp option" and "slurp option with raw string input
    option".
    """
    # CATCHES: -s with -R keeps the raw text (incl. \r) as a single string
    res = run_gojq(["-s", "."],
                   stdin='null\nfalse\n[]\n{ "foo": "bar" }\n', tmp_path=tmp_path)
    assert res.out == '[\n  null,\n  false,\n  [],\n  {\n    "foo": "bar"\n  }\n]\n'
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["-s", "-R", "."], stdin="null\nfalse\r\nfoo\nbar",
                   tmp_path=tmp_path)
    assert res.out == '"null\\nfalse\\r\\nfoo\\nbar"\n'
    assert res.rc == 0


def test_slurp_multiple_files(tmp_path):
    """-s merges the contents of every file argument into one array.

    Native cases "slurp option with multiple json files" and "slurp and raw
    input option with multiple json files".
    """
    # CATCHES: values from several files concatenate in argument order
    files = {"testdata/1.json": '{"foo":10}\n',
             "testdata/2.json": '[{\n"bar"\n:\n[]\n}]\n'}
    res = run_gojq(["-s", ".", "testdata/1.json", "testdata/2.json"],
                   tmp_path=tmp_path, files=files)
    assert res.out == '[\n  {\n    "foo": 10\n  },\n  [\n    {\n      "bar": []\n    }\n  ]\n]\n'
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["-R", "-s", ".", "testdata/1.json", "testdata/2.json"],
                   tmp_path=tmp_path, files=files)
    assert res.out == '"{\\"foo\\":10}\\n[{\\n\\"bar\\"\\n:\\n[]\\n}]\\n"\n'
    assert res.rc == 0


def test_stream_option(tmp_path):
    """--stream emits [path, leaf] events including path-only close events.

    Native case "stream option": scalars produce ``[[],value]``, array and
    object containers additionally emit a ``[path]`` event after their
    leaves.
    """
    # CATCHES: containers emit a path-only closing event after their leaves
    res = run_gojq(["-c", "--stream", "."],
                   stdin='1\n2\n[]\n{}\n[3]\n{"x":1,"y":2}\n', tmp_path=tmp_path)
    assert res.out == ('[[],1]\n[[],2]\n[[],[]]\n[[],{}]\n[[0],3]\n[[0]]\n'
                       '[["x"],1]\n[["y"],2]\n[["y"]]\n')
    assert res.err == ""
    assert res.rc == 0


def test_stream_option_unterminated_input(tmp_path):
    """--stream flushes events parsed so far, then reports the syntax error.

    Native case "stream option with unterminated input after a comma": the
    events before the EOF are on stdout while the error goes to stderr and
    the exit code is 5.
    """
    # CATCHES: partial stream events are flushed to stdout before the error
    res = run_gojq(["-c", "--stream", "."], stdin='{"a":1,', tmp_path=tmp_path)
    assert res.out == '[["a"],1]\n'
    assert res.err == 'gojq: invalid json: <stdin>\n    {"a":1,\n           ^  unexpected EOF\n'
    assert res.rc == 5


def test_yaml_input_documents(tmp_path):
    """--yaml-input splits on ``---`` and converts scalars/keys to JSON.

    Native cases "yaml input option" and "yaml input option with non-string
    keys": block scalars keep their trailing newline, non-string keys become
    string keys verbatim, and each document is processed separately.
    """
    # CATCHES: YAML block scalar keeps trailing newline; keys stringified verbatim
    res = run_gojq(["--yaml-input", "."],
                   stdin="foo:\n  bar: 42\n  baz: |\n    a\n    b\nqux: 100\n---\nfoo: 1\n---\nbar\n",
                   tmp_path=tmp_path)
    assert res.out == ('{\n  "foo": {\n    "bar": 42,\n    "baz": "a\\nb\\n"\n  },\n'
                       '  "qux": 100\n}\n{\n  "foo": 1\n}\n"bar"\n')
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["--yaml-input", "."], stdin="foo:\n  - 42.10: bar\n",
                   tmp_path=tmp_path)
    assert res.out == '{\n  "foo": [\n    {\n      "42.10": "bar"\n    }\n  ]\n}\n'
    assert res.rc == 0


def test_yaml_input_error(tmp_path):
    """YAML parse errors use the same caret format as JSON errors.

    Native cases "yaml input option error" and "yaml input option error with
    multibyte characters": the message is ``invalid yaml: <stdin>:<line>``
    and the caret column counts display width.
    """
    # CATCHES: duplicate YAML key error quotes the key and reports line 1
    res = run_gojq(["--yaml-input", "."], stdin="foo: 10\n10\nbar:\n",
                   tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == ("gojq: invalid yaml: <stdin>:2\n"
                       "    2 | 10\n"
                       "        ^  could not find expected ':'\n")

    res = run_gojq(["--yaml-input", "."], stdin="{１２３: 4, １２３: 5}\n",
                   tmp_path=tmp_path)
    assert res.rc == 5
    assert res.err == ('gojq: invalid yaml: <stdin>:1\n'
                       '    1 | {１２３: 4, １２３: 5}\n'
                       '                    ^  mapping key "１２３" already '
                       'defined at line 1\n')
