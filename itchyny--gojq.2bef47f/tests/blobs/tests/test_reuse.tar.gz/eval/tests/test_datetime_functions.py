"""Time functions of func.go: gmtime, localtime, mktime, strftime,
strflocaltime, todate, fromdate, strptime and date.

Rewritten from the native ``cli/test.yaml`` time-function cases
('gmtime function', 'localtime function', 'mktime function', 'strftime
function', 'strflocaltime function', 'todate function', 'fromdate
function', 'strptime function').  The pinned environment sets TZ=UTC, so
localtime agrees with gmtime and %z renders as +0000.  Expected values
recorded from the reference binary.
"""

import pytest

from conftest import run_gojq


def test_gmtime(tmp_path):
    """gmtime breaks epoch seconds into [Y,m,d,H,M,S.f,wday,yday]."""
    # CATCHES: month/day are zero-based; negative seconds go to 1969
    res = run_gojq(["-c", "gmtime | map(. * 1000000 | floor / 1000000)"],
                   stdin="1500000000 1567890123.456 1600000000.111 "
                         "-1 -0.5 0.5",
                   tmp_path=tmp_path)
    assert res.out == ("[2017,6,14,2,40,0,5,194]\n"
                       "[2019,8,7,21,2,3.456,6,249]\n"
                       "[2020,8,13,12,26,40.111,0,256]\n"
                       "[1969,11,31,23,59,59,3,364]\n"
                       "[1969,11,31,23,59,59.5,3,364]\n"
                       "[1970,0,1,0,0,0.5,4,0]\n")
    assert res.err == ""
    assert res.rc == 0


def test_localtime_matches_gmtime_under_utc(tmp_path):
    """with TZ=UTC pinned, localtime is identical to gmtime."""
    # CATCHES: fractional seconds survive the local-time breakdown
    res = run_gojq(["-c", "localtime | map(. * 1000000 | floor / 1000000)"],
                   stdin="1500000000 1567890123.456 -1 -0.5 0.5",
                   tmp_path=tmp_path)
    assert res.out == ("[2017,6,14,2,40,0,5,194]\n"
                       "[2019,8,7,21,2,3.456,6,249]\n"
                       "[1969,11,31,23,59,59,3,364]\n"
                       "[1969,11,31,23,59,59.5,3,364]\n"
                       "[1970,0,1,0,0,0.5,4,0]\n")
    assert res.err == ""
    assert res.rc == 0


def test_mktime_strftime_roundtrip(tmp_path):
    """mktime normalizes broken-down times; strftime formats both forms.

    From ``cli/test.yaml``: 'mktime function' and 'strftime function' —
    strftime accepts a broken-down array or epoch seconds; mktime folds
    out-of-range fields (a 59.5 second field becomes -0.5 seconds).
    """
    # CATCHES: [2025] fills missing fields from December, not January
    res = run_gojq(
        ["-cr", '(.,mktime | .,strftime("%Y-%m-%dT%H:%M:%SZ"),'
                'strflocaltime("%Y-%m-%dT%H:%M:%S%z")), todate'],
        stdin='[2017,6,14,2,40,0,5,194]\n[2019,8,7,21,2,3.456,6,249]\n'
              '[2024,7,20]\n[2025]\n'
              '[1969,11,31,23,59,59.5,3,364]\n',
        tmp_path=tmp_path)
    assert res.out == (
        "[2017,6,14,2,40,0,5,194]\n2017-07-14T02:40:00Z\n"
        "2017-07-14T02:40:00+0000\n1500000000\n2017-07-14T02:40:00Z\n"
        "2017-07-14T02:40:00+0000\n2017-07-14T02:40:00Z\n"
        "[2019,8,7,21,2,3.456,6,249]\n2019-09-07T21:02:03Z\n"
        "2019-09-07T21:02:03+0000\n1567890123.456\n2019-09-07T21:02:03Z\n"
        "2019-09-07T21:02:03+0000\n2019-09-07T21:02:03Z\n"
        "[2024,7,20]\n2024-08-20T00:00:00Z\n2024-08-20T00:00:00+0000\n"
        "1724112000\n2024-08-20T00:00:00Z\n2024-08-20T00:00:00+0000\n"
        "2024-08-20T00:00:00Z\n"
        "[2025]\n2024-12-31T00:00:00Z\n2024-12-31T00:00:00+0000\n"
        "1735603200\n2024-12-31T00:00:00Z\n2024-12-31T00:00:00+0000\n"
        "2024-12-31T00:00:00Z\n"
        "[1969,11,31,23,59,59.5,3,364]\n1969-12-31T23:59:59Z\n"
        "1969-12-31T23:59:59+0000\n-0.5\n1969-12-31T23:59:59Z\n"
        "1969-12-31T23:59:59+0000\n1969-12-31T23:59:59Z\n")
    assert res.err == ""
    assert res.rc == 0


def test_mktime_fractional_seconds(tmp_path):
    """mktime keeps fractional seconds; %f formats six digits.

    From ``cli/test.yaml``: 'mktime function fractional part' and
    'strftime function %f'.
    """
    # CATCHES: -0.5 seconds normalizes back into 1969 with .500000
    res = run_gojq(
        ["-r", 'mktime, strftime("%Y-%m-%dT%H:%M:%S.%fZ"), '
               'strflocaltime("%Y-%m-%dT%H:%M:%S.%f%z")'],
        stdin='[1970,0,1,0,0,-0.5]\n[1970,0,1,0,0,-1.25]\n'
              '[1970,0,1,0,0,60.25]\n[1970,0,1,0,0,0.5]\n',
        tmp_path=tmp_path)
    assert res.out == (
        "-0.5\n1969-12-31T23:59:59.500000Z\n"
        "1969-12-31T23:59:59.500000+0000\n"
        "-1.25\n1969-12-31T23:59:58.750000Z\n"
        "1969-12-31T23:59:58.750000+0000\n"
        "60.25\n1970-01-01T00:01:00.250000Z\n"
        "1970-01-01T00:01:00.250000+0000\n"
        "0.5\n1970-01-01T00:00:00.500000Z\n"
        "1970-01-01T00:00:00.500000+0000\n")
    assert res.err == ""
    assert res.rc == 0


def test_mktime_normalization_via_update(tmp_path):
    """updating a field then mktime folds the change back to seconds."""
    # CATCHES: subtracting 0.5s shifts every timestamp by exactly -0.5
    res = run_gojq(["-c", "gmtime | .[5] -= 0.5 | mktime"],
                   stdin="0 60 86400 -60", tmp_path=tmp_path)
    assert res.out == "-0.5\n59.5\n86399.5\n-60.5\n"
    assert res.err == ""
    assert res.rc == 0


def test_gmtime_range_errors(tmp_path):
    """gmtime rejects seconds outside the representable range."""
    # CATCHES: nan previews as null in the "out of range" message
    res = run_gojq(
        ["-c", '[infinite, -infinite, nan, 1e19, 9223372036854775807] '
               "| .[] | try gmtime catch ."],
        stdin="null", tmp_path=tmp_path)
    assert res.out == (
        '"gmtime cannot be applied to 1.7976931348623157e+308: '
        'number of seconds is out of range"\n'
        '"gmtime cannot be applied to -1.7976931348623157e+308: '
        'number of seconds is out of range"\n'
        '"gmtime cannot be applied to null: number of seconds is '
        'out of range"\n'
        '"gmtime cannot be applied to 10000000000000000000: '
        'number of seconds is out of range"\n'
        '"gmtime cannot be applied to 9223372036854775807: '
        'number of seconds is out of range"\n')
    assert res.err == ""
    assert res.rc == 0


def test_mktime_range_errors(tmp_path):
    """mktime rejects out-of-range fields and non-numeric members."""
    # CATCHES: long arrays are previewed with " ..." in the message
    res = run_gojq(
        ["-c", '[[infinite,0,1], [nan,0,1], [1e19,0,1], [0,1e19,1], '
               "[2001,0,1,0,0,infinite], [9223372036854775807,0,1], "
               '["x",0,1]] | .[] | try mktime catch .'],
        stdin="null", tmp_path=tmp_path)
    assert res.out == (
        '"mktime cannot be applied to [1.7976931348623157e+308,0,1]: '
        'number is out of range"\n'
        '"mktime cannot be applied to [null,0,1]: number is out of '
        'range"\n'
        '"mktime cannot be applied to [10000000000000000000,0,1]: '
        'number is out of range"\n'
        '"mktime cannot be applied to [0,10000000000000000000,1]: '
        'number is out of range"\n'
        '"mktime cannot be applied to [2001,0,1,0,0,1.797693134 ...]: '
        'number is out of range"\n'
        '"mktime cannot be applied to [9223372036854775807,0,1]: '
        'number is out of range"\n'
        '"mktime cannot be applied to [\\"x\\",0,1]: '
        'expected an array of 8 numbers"\n')
    assert res.err == ""
    assert res.rc == 0


def test_strftime_range_errors(tmp_path):
    """strftime/todate share the seconds range check with gmtime."""
    # CATCHES: todate's error names its own format string
    res = run_gojq(
        ["-c", 'try (infinite | todate) catch ., '
               'try ([1e19,0,1] | strftime("%Y")) catch .'],
        stdin="null", tmp_path=tmp_path)
    assert res.out == (
        '"strftime(\\"%Y-%m-%dT%H:%M:%SZ\\") cannot be applied to '
        '1.7976931348623157e+308: number of seconds is out of range"\n'
        '"strftime(\\"%Y\\") cannot be applied to '
        '[10000000000000000000,0,1]: number is out of range"\n')
    assert res.err == ""
    assert res.rc == 0


def test_strptime_and_fromdate(tmp_path):
    """strptime parses ISO-ish stamps; fromdate gives epoch seconds.

    From ``cli/test.yaml``: 'strptime function' and 'fromdate function'
    — %f captures fractional seconds, %z accepts +0000 and +0900.
    """
    # CATCHES: timezone offsets are folded into the epoch result
    res = run_gojq(
        ["-c", 'strptime("%Y-%m-%dT%H:%M:%S%z")? // '
               'strptime("%Y-%m-%dT%H:%M:%S.%f%z"), fromdate?'],
        stdin='"2017-07-14T02:40:00Z"\n"2019-09-08T06:02:03+0900"\n'
              '"1969-12-31T23:59:59.5+0000"\n'
              '"2345-01-02T03:04:05.678901+0000"\n',
        tmp_path=tmp_path)
    assert res.out == (
        "[2017,6,14,2,40,0,5,194]\n1500000000\n"
        "[2019,8,7,21,2,3,6,249]\n1567890123\n"
        "[1969,11,31,23,59,59.5,3,364]\n"
        "[2345,0,2,3,4,5.678901,2,1]\n")
    assert res.err == ""
    assert res.rc == 0


def test_strptime_strftime_c_roundtrip(tmp_path):
    """%c parses and reformats a whole locale-style timestamp."""
    # CATCHES: %c roundtrips day names and month names exactly
    res = run_gojq(["-c", 'strptime("%c") | strftime("%c")'],
                   stdin='"Thu Jul 23 20:41:06 2020"', tmp_path=tmp_path)
    assert res.out == '"Thu Jul 23 20:41:06 2020"\n'
    assert res.err == ""
    assert res.rc == 0


def test_dateadd_absent_from_this_build(tmp_path):
    """dateadd/datesub are not compiled into this gojq build.

    The reference binary rejects dateadd/2 with a compile error, so the
    newer source tree's date arithmetic cannot be exercised here; this
    test pins the actual binary behavior instead.
    """
    # CATCHES: rc 3 with "function not defined", before reading input
    res = run_gojq(
        ["-c", '[dateadd("year"; 1), datesub("year"; 1), '
               'dateadd("seconds"; 90), datesub("milliseconds"; 500)]'],
        stdin="1704067200", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: compile error: function not defined: dateadd/2\n"
    assert res.rc == 3
