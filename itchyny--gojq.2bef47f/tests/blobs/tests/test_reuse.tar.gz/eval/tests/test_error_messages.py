"""Runtime and compile error message shapes (error.go).

Every error value the reference binary can raise has its own message
template.  This file pins the families the rest of the suite had not yet
reached: oversized array indices, non-string object keys, non-number string
indices, the ``*_by`` length mismatch, unknown ``@format`` names, ``break``
without a label, invalid paths built by iterating, the try-end wrapping that
keeps a finished ``try`` from catching later errors, and the parse errors
surfaced while loading a module.

All expected strings below were recorded by running the reference binary.
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("query,stdin,expected_err", [
    # 0x20000000 is the index threshold; the message names the raw index
    (".[536870912] = 1", "[1]",
     'gojq: setpath([536870912]; 1) cannot be applied to [1]:'
     " array index too large: 536870912\n"),
    ("setpath([536870912]; 1)", "[]",
     'gojq: setpath([536870912]; 1) cannot be applied to []:'
     " array index too large: 536870912\n"),
    # a float index is truncated to an integer and reported the same way
    (".a[1e10] = 1", "null",
     'gojq: setpath(["a",10000000000]; 1) cannot be applied to null:'
     " array index too large: 10000000000\n"),
])
def test_array_index_too_large(tmp_path, query, stdin, expected_err):
    """assigning past 0x20000000 reports "array index too large".

    The setpath wrapper carries the whole path and the new value, and the
    inner reason names the offending index verbatim, whether it was written
    as an integer literal or produced by a float.
    """
    # CATCHES: the threshold is 536870912 and the index is echoed back
    # unrounded, so 1e10 reports 10000000000 rather than 1e+10
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_err", [
    ("{(1): 2}", "null",
     "gojq: expected a string for object key but got: number (1)\n"),
    ("{(.): 2}", "null",
     "gojq: expected a string for object key but got: null\n"),
    ("{([1]): 2}", "null",
     "gojq: expected a string for object key but got: array ([1])\n"),
    # setpath walks into a null input and needs a string key there too
    ("setpath([[1]]; 2)", "null",
     "gojq: setpath([[1]]; 2) cannot be applied to null:"
     " expected a string for object key but got: array ([1])\n"),
    ("setpath([true]; 2)", "null",
     "gojq: setpath([true]; 2) cannot be applied to null:"
     " expected a string for object key but got: boolean (true)\n"),
])
def test_object_key_must_be_string(tmp_path, query, stdin, expected_err):
    """object construction and setpath reject non-string keys.

    Object construction previews the offending key value, and setpath
    wraps the same message with the path and value it was given.
    """
    # CATCHES: the message is "expected a string for object key but got",
    # distinct from the "expected an object" family, and previews the value
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


def test_computed_object_keys_still_work(tmp_path):
    """keys computed at run time are accepted when they become strings.

    ``{(.[] | tostring): 2}`` builds an object from array elements, so the
    type check happens per produced key rather than at compile time.
    """
    # CATCHES: a filter producing strings is a legal key expression even
    # though the same filter shape errors when it yields a number
    res = run_gojq(["-c", "[1] | {(.[] | tostring): 2}"], stdin="null",
                   tmp_path=tmp_path)
    assert res.out == '{"1":2}\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,bound", [
    ('"abc" | .["a":]', '"a"'),
    ('"abc" | .[:"x"]', '"x"'),
    ('"abc" | .["x":"y"]', '"x"'),
])
def test_string_slice_bound_must_be_number(tmp_path, query, bound):
    """slicing a string reports the first non-number bound.

    The error names the bound that failed ("expected a number for indexing
    a string"), which is the start bound when both are invalid.
    """
    # CATCHES: string slicing validates each bound separately and blames the
    # start bound first, rather than reporting a generic type error
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == ("gojq: expected a number for indexing a string"
                       " but got: string (%s)\n" % bound)
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_name", [
    ("[1,2,3] | _min_by([1])", "min_by"),
    ("[1,2,3] | _max_by([1])", "max_by"),
    ("[1,2,3] | _sort_by([1])", "sort_by"),
    ("[1,2,3] | _group_by([1])", "group_by"),
    ("[1,2,3] | _unique_by([1])", "unique_by"),
])
def test_by_functions_length_mismatch(tmp_path, query, expected_name):
    """the internal ``_*_by`` builtins report "length mismatch".

    The public wrappers always pair each element with its key, so the
    mismatch is only visible when calling the internal function directly
    with a shorter or longer key array; the message keeps the public name.
    """
    # CATCHES: _sort_by([1]) says "sort_by([1]) cannot be applied to
    # [1,2,3]: length mismatch" — the public name with the argument preview
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == ('gojq: %s([1]) cannot be applied to [1,2,3]:'
                       " length mismatch\n" % expected_name)
    assert res.rc == 5


def test_by_functions_accept_matching_lengths(tmp_path):
    """the internal ``_*_by`` functions work when lengths agree.

    Passing a key array of the same length as the input bypasses the
    public ``map([f])`` wrapper and still sorts and groups correctly.
    """
    # CATCHES: _sort_by([3,1,2]) reorders to [2,3,1] and _unique_by
    # deduplicates by [1,1,2] to [1,3], proving the keys are honoured
    res = run_gojq(["-c", '[_sort_by([3,1,2]), _unique_by([1,1,2]),'
                          ' _group_by([1,1,2]), _min_by([3,1,2])]'],
                   stdin='[1,2,3]', tmp_path=tmp_path)
    assert res.out == "[[2,3,1],[1,3],[[1,2],[3]],2]\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("format(\"foo\")", "gojq: format not defined: @foo\n"),
    ("format(\"@csv\")", "gojq: format not defined: @@csv\n"),
])
def test_format_not_defined(tmp_path, query, expected_err):
    """format() rejects names that are not registered @formats.

    The name is looked up after prefixing "@", so an argument that already
    carries the sigil produces a doubled name in the message.
    """
    # CATCHES: format("@csv") reports "@@csv", showing the "@" is always
    # prepended instead of being detected on the argument
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("format(\"text\")", "null", '"null"\n'),
    ("format(\"uri\")", '"x"', '"x"\n'),
])
def test_format_by_name_matches_the_at_syntax(tmp_path, query, stdin,
                                               expected_out):
    """format() resolves to the same function as the @syntax literal.

    ``format("text")`` and ``format("uri")`` behave exactly like ``@text``
    and ``@uri`` when applied to the same input.
    """
    # CATCHES: the dynamic lookup returns the identical format function,
    # so "x" is quoted by @text and left bare by @uri
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("break $out", "gojq: compile error: label not defined: $out\n"),
    ("def f: break $l; f", "gojq: compile error: label not defined: $l\n"),
    ("try (break $out) catch .",
     "gojq: compile error: label not defined: $out\n"),
])
def test_break_outside_a_label_is_a_compile_error(tmp_path, query,
                                                  expected_err):
    """``break $label`` needs an enclosing label at compile time.

    The label must be visible lexically, so a function body cannot break a
    caller's label, and ``try`` cannot guard the missing-label error.
    """
    # CATCHES: the missing label is reported as a compile error (exit 3)
    # naming "$out", not as a runtime error, and try cannot suppress it
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 3


@pytest.mark.parametrize("query,expected_out", [
    # a direct break ends the label body, so the trailing 2 never runs
    ("label $l | 1, break $l, 2", "1\n"),
    # the same break reached through a function defined inside the label
    ("label $l | (1, (def f: break $l; f), 2)", "1\n"),
])
def test_break_inside_a_label_silently_exits(tmp_path, query, expected_out):
    """``break`` inside its label ends the label body without output.

    Values produced before the break are kept, everything after it in the
    label body is skipped, and the query still exits 0 — whether the break
    is written directly or called through a function defined inside the
    label's scope.
    """
    # CATCHES: only "1" is printed; the "2" after the break is dropped and
    # no "label not defined" error appears for the in-scope function call
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("path([1,2] | .[])",
     "gojq: invalid path on iterating against: array ([1,2])\n"),
    ("path({\"a\":1} | .[])",
     'gojq: invalid path on iterating against: object ({"a":1})\n'),
])
def test_invalid_path_on_iterating(tmp_path, query, expected_err):
    """``path`` over a freshly built container reports the iterating form.

    Iterating a value that is not the path's own input is a distinct error
    from the plain "invalid path against" produced by indexing one.
    """
    # CATCHES: .[] inside path() against a constructed array says
    # "invalid path on iterating against", not "invalid path against"
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


def test_invalid_path_against_when_indexing(tmp_path):
    """indexing a constructed container inside path uses the other message.

    ``path([1,2] | .[0])`` fails the path check without iterating, so the
    plain "invalid path against" wording is used.
    """
    # CATCHES: indexing and iterating the same container produce the two
    # different invalid-path wordings
    res = run_gojq(["-c", "path([1,2] | .[0])"], stdin="null",
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: invalid path against: array ([1,2])\n"
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    # the inner catch does not see the error raised after its try finished
    ('try (try (1) catch "a" | error("z")) catch .', '"z"\n'),
    # an error raised inside a catch handler is visible to an outer catch
    ('try (try error("x") catch error("y")) catch .', '"y"\n'),
])
def test_finished_try_does_not_catch_later_errors(tmp_path, query,
                                                  expected_out):
    """a catch handler only guards its own try body.

    Once the inner ``try`` has completed, an error raised afterwards in the
    same expression is not offered to that inner handler, while an error
    raised by a handler itself is offered to the enclosing one.
    """
    # CATCHES: try (try (1) catch "a" | error("z")) catch . prints "z"
    # rather than "a", so the inner handler is skipped once its body ended
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_error_after_try_still_exits_five(tmp_path):
    """an uncaught error after a successful try keeps exit code 5.

    ``try (1) catch "a" | error("z")`` prints the plain "error: z" form and
    exits 5, showing the try added no protection past its body.
    """
    # CATCHES: the message is "gojq: error: z" with exit 5 — the earlier
    # try neither catches the error nor changes the exit code
    res = run_gojq(["-c", 'try (1) catch "a" | error("z")'], stdin="null",
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: error: z\n"
    assert res.rc == 5
