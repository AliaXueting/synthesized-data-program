"""Path builtins, assignment/update operators and stream generators.

Covers the path machinery of func.go and the constant-path assignment of
query.go: getpath/setpath/delpaths, the path/paths functions, tostream/
fromstream/truncate_stream, the =/|=/+=/del family, and the stream
builtins range/limit/skip/first/last/nth/while/until/repeat/combinations/
walk/INDEX/JOIN/IN/any/all/isempty/error/env/now/reduce/foreach.

Rewritten from the corresponding native ``cli/test.yaml`` cases
('getpath function ...', 'setpath function ...', 'delpaths function
...', 'del function ...', 'assignment operator with fork',
'update-assignment operator ...', 'path function ...', 'paths/0
function', 'paths/1 function', 'tostream function', 'fromstream
function', 'truncate_stream function', 'while function', 'until
function', 'repeat function', 'range function', 'limit/2 function',
'skip/2 function', 'first/0, last/0, nth/1 functions', 'combinations/0
function', 'walk function', 'INDEX function', 'JOIN function', 'IN
function', 'isempty function', 'env function', '$ENV variable', 'now
function', 'reduce iterator', 'foreach iterator').  Expected values
recorded from the reference binary.
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('getpath(["a",1,"b",2]), getpath([])', '{"a":[{},{"b":[1,2,3]}]}',
     '3\n{"a":[{},{"b":[1,2,3]}]}\n'),
    # slice paths and negative open-ended slices work on strings
    ('[getpath([{"start":1,"end":3}]), getpath([{"start":-2,"end":null}]), '
     'getpath([1]), getpath([])]', '"abcde"', '["bc","de","b","abcde"]\n'),
    ('getpath(["a",{"start":0,"end":2}]), getpath(["a",1])', '{"a":"abc"}',
     '"ab"\n"b"\n'),
])
def test_getpath(tmp_path, query, stdin, expected_out):
    """getpath walks a path of keys, indices and slices, null on miss."""
    # CATCHES: slices inside paths; empty path returns the whole value
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_err", [
    ('getpath(["a",1,"b","c"])', '{"a":[{},{"b":[1,2,3,4,5,6,7]}]}',
     'gojq: getpath(["a",1,"b","c"]) cannot be applied to '
     '{"a":[{},{"b":[1,2,3,4,5, ...}: expected an object but got: '
     'array ([1,2,3,4,5,6,7])\n'),
    ('getpath(["k"])', '"abc"',
     'gojq: getpath(["k"]) cannot be applied to "abc": '
     'expected an object but got: string ("abc")\n'),
])
def test_getpath_errors(tmp_path, query, stdin, expected_err):
    """getpath errors echo the path and the offending container."""
    # CATCHES: long values are truncated with " ..." in the preview
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('[getpath(path(.[1:3])), getpath(path(.[1]))]', '"abcde"',
     '["bc","b"]\n'),
    ('. as $d | [path(.a[0:2]), path(.b[1])] | '
     'map(. as $p | $d | getpath($p))', '{"a":"abc","b":"xyz"}',
     '["ab","y"]\n'),
])
def test_getpath_path_roundtrip(tmp_path, query, stdin, expected_out):
    """paths produced by path() feed back into getpath unchanged."""
    # CATCHES: slice paths survive the path->getpath round trip
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    # two paths x two values fan out; missing containers are built
    ('setpath([["a","b",0,1,2],[1,2,"a","b"]][]; 1,2)', "null",
     '{"a":{"b":[[null,[null,null,1]]]}}\n'
     '[null,[null,null,{"a":{"b":1}}]]\n'
     '{"a":{"b":[[null,[null,null,2]]]}}\n'
     '[null,[null,null,{"a":{"b":2}}]]\n'),
    # negative indices replace relative to the end
    ('setpath(-2,0,2 | [.]; 4,5)', "[1,2,3]",
     "[1,4,3]\n[4,2,3]\n[1,2,4]\n[1,5,3]\n[5,2,3]\n[1,2,5]\n"),
    ('setpath([]; 10)', "null", "10\n"),
])
def test_setpath(tmp_path, query, stdin, expected_out):
    """setpath builds missing containers and accepts negative indices."""
    # CATCHES: empty path replaces the whole input with the value
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_err", [
    ("setpath([-1]; 10)", "[]",
     "gojq: setpath([-1]; 10) cannot be applied to []: "
     "array index should not be negative: -1\n"),
    ('setpath(["a","b","c"]; 10)', '{"a":{"b":[]}}',
     'gojq: setpath(["a","b","c"]; 10) cannot be applied to '
     '{"a":{"b":[]}}: expected an object but got: array ([])\n'),
    ('setpath(["a",1]; 10)', '{"a":{"b":[]}}',
     'gojq: setpath(["a",1]; 10) cannot be applied to '
     '{"a":{"b":[]}}: expected an array but got: object ({"b":[]})\n'),
    ("setpath([{}]; 10)", "null",
     'gojq: setpath([{}]; 10) cannot be applied to null: '
     'expected "start" and "end" for slicing but got: object ({})\n'),
    ("setpath([{start:0}]; 10)", "null",
     'gojq: setpath([{"start":0}]; 10) cannot be applied to null: '
     'expected "start" and "end" for slicing but got: '
     'object ({"start":0})\n'),
    ("setpath([[]]; 10)", "[]",
     "gojq: setpath([[]]; 10) cannot be applied to []: "
     "expected a number for indexing an array but got: array ([])\n"),
    ("setpath([{start:0,end:1}]; 10)", "[]",
     'gojq: setpath([{"end":1,"start":0}]; 10) cannot be applied to []: '
     "expected an array but got: number (10)\n"),
])
def test_setpath_errors(tmp_path, query, stdin, expected_err):
    """setpath rejects wrong-typed path members, in path order.

    From ``cli/test.yaml``: the eight 'setpath function error' cases.
    """
    # CATCHES: each bad path member type has its own message wording
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


def test_setpath_catchable_errors(tmp_path):
    """setpath errors are catchable values, so try/catch resumes."""
    # CATCHES: the failing path is echoed inside the caught message
    res = run_gojq(
        ["-c", '.[] as $q | try (setpath($q; 10)) catch .'],
        stdin='[[-1],["a","b","c"],["a",1],[{}],[{"start":0}],[[]],'
              '[{"start":0,"end":1}]]',
        tmp_path=tmp_path)
    assert res.out == (
        '[[-1],["a","b","c"],["a",1],[{}],[{"start":0}],[[]],10]\n'
        '"setpath([\\"a\\",\\"b\\",\\"c\\"]; 10) cannot be applied to '
        '[[-1],[\\"a\\",\\"b\\",\\"c\\"],[\\"a\\", ...]: '
        'expected an object but got: array ([[-1],[\\"a\\",\\"b\\",\\"c\\"],'
        '[\\"a\\", ...])"\n'
        '"setpath([\\"a\\",1]; 10) cannot be applied to '
        '[[-1],[\\"a\\",\\"b\\",\\"c\\"],[\\"a\\", ...]: '
        'expected an object but got: array ([[-1],[\\"a\\",\\"b\\",\\"c\\"],'
        '[\\"a\\", ...])"\n'
        '"setpath([{}]; 10) cannot be applied to '
        '[[-1],[\\"a\\",\\"b\\",\\"c\\"],[\\"a\\", ...]: '
        'expected \\"start\\" and \\"end\\" for slicing but got: '
        'object ({})"\n'
        '"setpath([{\\"start\\":0}]; 10) cannot be applied to '
        '[[-1],[\\"a\\",\\"b\\",\\"c\\"],[\\"a\\", ...]: '
        'expected \\"start\\" and \\"end\\" for slicing but got: '
        'object ({\\"start\\":0})"\n'
        '"setpath([[]]; 10) cannot be applied to '
        '[[-1],[\\"a\\",\\"b\\",\\"c\\"],[\\"a\\", ...]: '
        'expected a number for indexing an array but got: array ([])"\n'
        '"setpath([{\\"end\\":1,\\"start\\":0}]; 10) cannot be applied to '
        '[[-1],[\\"a\\",\\"b\\",\\"c\\"],[\\"a\\", ...]: '
        'expected an array but got: number (10)"\n')
    assert res.err == ""
    assert res.rc == 0


def test_setpath_slice_with_non_number(tmp_path):
    """slice paths with non-number members fail inside setpath."""
    # CATCHES: {"start":"x"} reports the string where a number belongs
    res = run_gojq(["-c", 'try (setpath([{start:"x",end:2}]; [9])) catch .'],
                   stdin="[1,2,3]", tmp_path=tmp_path)
    assert res.out == ('"setpath([{\\"end\\":2,\\"start\\":\\"x\\"}]; [9]) '
                       'cannot be applied to [1,2,3]: expected a number for '
                       'indexing an array but got: string (\\"x\\")"\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('delpaths([["a",1,"b",1]])', '{"a":[{},{"b":[1,2,3]}]}',
     '{"a":[{},{"b":[1,3]}]}\n'),
    # deletions apply from the highest index down
    ("delpaths([[2],[6],[4]])", "[1,2,3,4,5]", "[1,2,4]\n"),
    ('delpaths([["a","b","c"]])', "{}", "{}\n"),
    ("delpaths([[2],[-10],[10],[-3]])", "[1,2,3,4,5]", "[1,2,4,5]\n"),
    ('delpaths([["x"],["x",0,"y"]], [["x",0],["x",0,"y"]], '
     '[["x"],["x",{"start":0}]])', '{"x":[{"y":0}]}',
     '{}\n{"x":[]}\n{}\n'),
    ('delpaths([["a"]]), delpaths([["a","b"]]), delpaths([[0]]), '
     "delpaths([[-1]]), delpaths([[{start:1,end:2}]])", "null",
     "null\nnull\nnull\nnull\nnull\n"),
])
def test_delpaths(tmp_path, query, stdin, expected_out):
    """delpaths removes several paths at once, ignoring misses.

    From ``cli/test.yaml``: 'delpaths function', '... against array',
    '... not found key', '... out of index', '... with overlapping
    paths', '... against null'.
    """
    # CATCHES: overlapping paths each apply; deleting on null stays null
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_delpaths_catchable_errors(tmp_path):
    """delpaths errors are catchable and preview the whole input."""
    # CATCHES: three distinct failure modes in one caught stream
    res = run_gojq(["-c", '.[] as $q | try (delpaths([$q])) catch .'],
                   stdin='[[{}],["x"],[{"start":1,"end":{}}]]',
                   tmp_path=tmp_path)
    assert res.out == (
        '"delpaths([[{}]]) cannot be applied to '
        '[[{}],[\\"x\\"],[{\\"end\\":{},\\"s ...]: '
        'expected \\"start\\" and \\"end\\" for slicing but got: '
        'object ({})"\n'
        '"delpaths([[\\"x\\"]]) cannot be applied to '
        '[[{}],[\\"x\\"],[{\\"end\\":{},\\"s ...]: '
        'expected an object but got: array ([[{}],[\\"x\\"],'
        '[{\\"end\\":{},\\"s ...])"\n'
        '"delpaths([[{\\"end\\":{},\\"start\\":1}]]) cannot be applied to '
        '[[{}],[\\"x\\"],[{\\"end\\":{},\\"s ...]: '
        'expected a number for indexing an array but got: '
        'object ({})"\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("paths", '[1,[[1,{"a":2},3],{"a":[2]}]]',
     "[0]\n[1]\n[1,0]\n[1,0,0]\n[1,0,1]\n[1,0,1,\"a\"]\n[1,0,2]\n[1,1]\n"
     "[1,1,\"a\"]\n[1,1,\"a\",0]\n"),
    ("paths(. > 2)", '[1,[[1,{"a":2},3],{"a":[2]}]]',
     "[1]\n[1,0]\n[1,0,1]\n[1,0,2]\n[1,1]\n[1,1,\"a\"]\n"),
    # scalars have no paths at all
    ("[paths], [paths(numbers)]", "1", "[]\n[]\n"),
    ("[paths]", '"a"', "[]\n"),
])
def test_paths_functions(tmp_path, query, stdin, expected_out):
    """paths enumerates every subpath, optionally filtered by a query.

    From ``cli/test.yaml``: 'paths/0 function' and 'paths/1 function'.
    """
    # CATCHES: paths(f) keeps paths whose VALUE satisfies f, incl. objects
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("[path(..)]", '{"a": 1}', '[[],["a"]]\n'),
    ('[path(.a[0].b), path(.[1:2]), path(.["k"])]', "null",
     '[["a",0,"b"],[{"end":2,"start":1}],["k"]]\n'),
    ('[path(getpath(["a", 0]))]', "null", '[["a",0]]\n'),
    # if/then/else on identity is a valid path expression
    ("path(if true then . else . end)", "null", "[]\n"),
])
def test_path_function(tmp_path, query, stdin, expected_out):
    """path() materializes the path a filter navigates."""
    # CATCHES: slices serialize as {"start":..,"end":..} objects
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out,expected_err,expected_rc", [
    # select inside path keeps only matching branches
    ('path(.[] | select(.id | startswith("x")) | .id)',
     '[{"id": "xy"}, {"id": "yx"}]', '[0,"id"]\n', "", 0),
    # getpath of the input itself is not a path expression
    ("path({} | getpath([]))", "{}", "",
     "gojq: invalid path against: object ({})\n", 5),
    # slices keyed on the wrong container type abort the whole run
    ('[path(.[1:3]), path(.a[0:2]), path(.b[1])]', '"abcde"\n{"a":"abc","b":"xyz"}',
     "",
     'gojq: expected an object but got: string ("abcde")\n'
     'gojq: expected an array but got: object ({"a":"abc","b":"xyz"})\n', 5),
])
def test_path_select_and_errors(tmp_path, query, stdin, expected_out,
                                expected_err, expected_rc):
    """path() supports select; errors when the filter is not a path.

    From ``cli/test.yaml``: 'path function with select' and 'path
    function error with getpath function'.
    """
    # CATCHES: each bad input produces its own error line before exit
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == expected_err
    assert res.rc == expected_rc


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("tostream", '[0,[1,{"a":1},{"b":2}]]',
     "[[0],0]\n[[1,0],1]\n[[1,1,\"a\"],1]\n[[1,1,\"a\"]]\n"
     "[[1,2,\"b\"],2]\n[[1,2,\"b\"]]\n[[1,2]]\n[[1]]\n"),
    ("fromstream(range(5) | "
     "truncate_stream({x:[1,{y:[2]},3],z:[4]} | tostream))", "null",
     '{"x":[1,{"y":[2]},3],"z":[4]}\n[1,{"y":[2]},3]\n[4]\n{"y":[2]}\n'
     "[2]\n"),
    ("[truncate_stream([[0],1],[[1,0],2],[[1,0]],[[1]])]", "0 1 2",
     "[[[0],1],[[1,0],2],[[1,0]],[[1]]]\n[[[0],2],[[0]]]\n[]\n"),
])
def test_tostream_fromstream_truncate(tmp_path, query, stdin, expected_out):
    """tostream flattens to [path, leaf] events; fromstream rebuilds.

    From ``cli/test.yaml``: 'tostream function', 'fromstream function'
    and 'truncate_stream function'.
    """
    # CATCHES: closing events carry only the path; truncation drops depth
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    (".a = 1", "{}", '{"a":1}\n'),
    ('."key" = "v", .["k2"] = 2', "{}", '{"key":"v"}\n{"k2":2}\n'),
    (".a[0] = 9", '{"a":[1,2]}', '{"a":[9,2]}\n'),
    (".[-1] = 9", "[1,2]", "[1,9]\n"),
    (".[1:3] = [8,9]", "[1,2,3,4,5]", "[1,8,9,4,5]\n"),
    (".[:2] = [0]", "[1,2,3]", "[0,3]\n"),
    (".[2:] = [0]", "[1,2,3]", "[1,2,0]\n"),
    ('.a.b[0]."c"[1:] = [7]', "null", '{"a":{"b":[{"c":[7]}]}}\n'),
    (".a.[0] = 7, .x[1].y = 8", "null",
     '{"a":[7]}\n{"x":[null,{"y":8}]}\n'),
    ('.foo = 1, .foo[0] = 2, .foo["a"] = 3', "null",
     '{"foo":1}\n{"foo":[2]}\n{"foo":{"a":3}}\n'),
    # right-hand streams fan out; multi-path left sides assign everywhere
    ('.a = (1,2), (.b, .c) = 9', "{}",
     '{"a":1}\n{"a":2}\n{"b":9,"c":9}\n'),
    ("[range(3)] | .[] = 0 | [.[] = 1, .[] = 2]", "null",
     "[[1,1,1],[2,2,2]]\n"),
    (".x = 1 | .y = (.x + 1)", "null", '{"x":1,"y":2}\n'),
])
def test_constant_path_assignment(tmp_path, query, stdin, expected_out):
    """= writes through constant paths, building containers as needed.

    From ``cli/test.yaml``: 'assignment operator with fork' and the
    'assignment operator ...' family (keys, indices, slices, chains).
    """
    # CATCHES: .a.[0] dot-suffix form and open-ended slices both assign
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out,expected_err,expected_rc", [
    # float indices truncate toward zero before the write
    (".a[1.5] = 2", '{"a":[1,9]}', '{"a":[1,2]}\n', "", 0),
    (".a[-1.5] = 7", '{"a":[1,9,3]}', '{"a":[1,9,7]}\n', "", 0),
    # nan truncates to the minimum int64 and is rejected by setpath
    (".[nan] = 8", "[1,9,3]", "",
     "gojq: setpath([null]; 8) cannot be applied to [1,9,3]: "
     "array index should not be negative: -9223372036854775808\n", 5),
])
def test_float_index_assignment(tmp_path, query, stdin, expected_out,
                                expected_err, expected_rc):
    """non-integer indices truncate; nan becomes an int64 overflow."""
    # CATCHES: -1.5 truncates toward zero to -1, not to -2
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == expected_err
    assert res.rc == expected_rc


@pytest.mark.parametrize("query,stdin,expected_out", [
    # |= keeps only the first update output
    ('.a |= . + 1, .b |= (., . * 2)', '{"a":1,"b":5}',
     '{"a":2,"b":5}\n{"a":1,"b":5}\n'),
    ('.a += 1, .b -= 1, .c *= 3, .d /= 2, .e %= 3',
     '{"a":1,"b":5,"c":4,"d":7,"e":8}',
     '{"a":2,"b":5,"c":4,"d":7,"e":8}\n'
     '{"a":1,"b":4,"c":4,"d":7,"e":8}\n'
     '{"a":1,"b":5,"c":12,"d":7,"e":8}\n'
     '{"a":1,"b":5,"c":4,"d":3.5,"e":8}\n'
     '{"a":1,"b":5,"c":4,"d":7,"e":2}\n'),
    ('.a += "x", .b += [1]', '{"a":"s","b":[0]}',
     '{"a":"sx","b":[0]}\n{"a":"s","b":[0,1]}\n'),
    # //= only replaces null/false, unlike the // operator's truthiness
    ('.a //= "d", .b //= "d"', '{"a":false,"b":1}',
     '{"a":"d","b":1}\n{"a":false,"b":1}\n'),
])
def test_update_assignment_operators(tmp_path, query, stdin, expected_out):
    """update assignments modify in place through the same paths.

    From ``cli/test.yaml``: 'update-assignment operator with fork',
    '... with alternative operator' and the arithmetic variants.
    """
    # CATCHES: += on strings appends; |= takes the first output only
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("[range(.)] | .[] |= . * 2", "5", "[0,2,4,6,8]\n"),
    # empty update output deletes the element
    ("[range(.)] | .[] |= if . % 2 == 0 then empty else [., -.] end", "10",
     "[[1,-1],[3,-3],[5,-5],[7,-7],[9,-9]]\n"),
    ('try (.foo |= (. + "x")) catch .', '"abc"',
     '"expected an object but got: string (\\"abc\\")"\n'),
])
def test_update_on_elements_and_strings(tmp_path, query, stdin, expected_out):
    """|= over .[] maps elements; empty deletes; strings cannot update."""
    # CATCHES: empty update output removes the path instead of erroring
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('del(.foo[0], .bar[0], .foo, .baz.bar[0].x)',
     '{"foo": [0,1,2,3,4], "bar": [0,1], "baz": {"bar": [{"x": 1}]}}',
     '{"bar":[1],"baz":{"bar":[{}]}}\n'),
    ("del(.[1], .[-6], .[2], .[-3:9])", "[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]",
     "[0,3,5,6,9]\n"),
    ("del(.a), del(.a.b), del(.[0]), del(.[-1]), del(.[1:2])", "null",
     "null\nnull\nnull\nnull\nnull\n"),
    ('del(.foo[1:][:3][1:], .bar[:2][1:])',
     '{"foo": [0,1,2,3,4], "bar": [0,1]}', '{"bar":[0],"foo":[0,1,4]}\n'),
    ("del(.), del(empty), del((.foo,.bar,.baz) | .[2,3,0])",
     '{"foo": [0,1,2,3,4], "bar": [0,1]}',
     'null\n{"bar":[0,1],"foo":[0,1,2,3,4]}\n{"bar":[1],"foo":[1,4]}\n'),
])
def test_del_operator(tmp_path, query, stdin, expected_out):
    """del removes several paths at once through path expressions.

    From ``cli/test.yaml``: 'del function', 'del function with array
    slicing', 'del function against null'.
    """
    # CATCHES: del(.) nulls the input; del(empty) changes nothing
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("[range(5)], [range(2; 5)], [range(0; 10; 3)], [range(0; 10; -1)], "
     "[range(5; 0; -2)], [range(0.5; 4; 1.5)], [range(3; 0)]", "null",
     "[0,1,2,3,4]\n[2,3,4]\n[0,3,6,9]\n[]\n[5,3,1]\n[0.5,2,3.5]\n[]\n"),
    ("[range(0)], [range(-1)], [range(1; 1)], [range(1; 0)]", "null",
     "[]\n[]\n[]\n[]\n"),
    ('try (range(1; 2; null)) catch .', "null",
     '"range cannot be applied to: null"\n'),
])
def test_range_function(tmp_path, query, stdin, expected_out):
    """range steps from up to (exclusive) by, with float support."""
    # CATCHES: zero or negative spans produce no outputs at all
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out,expected_err,expected_rc", [
    ("[limit(3; .[])], [limit(0; .[])], [limit(5; .[])]", "[1, 2, 3]\n",
     "[1,2,3]\n[]\n[1,2,3]\n", "", 0),
    # limit stops an infinite generator early
    ("[limit(3; repeat(1))]", "null", "[1,1,1]\n", "", 0),
    ('[limit(-1; .[])]', "[1, 2, 3]\n", "",
     "gojq: error: limit doesn't support negative count\n", 5),
    ('try (limit("x"; .[])) catch .', "[1]\n",
     '"cannot subtract: string (\\"x\\") and number (1)"\n', "", 0),
])
def test_limit_function(tmp_path, query, stdin, expected_out, expected_err,
                        expected_rc):
    """limit caps an iterator; negative counts are fatal errors.

    From ``cli/test.yaml``: 'limit/2 function' and 'limit/2 function
    with negative count'.
    """
    # CATCHES: the negative-count check happens before any iteration
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == expected_err
    assert res.rc == expected_rc


def test_skip_function(tmp_path):
    """skip drops the first n outputs; negative counts abort the run."""
    # CATCHES: skipping past the end yields [] before the error path
    res = run_gojq(
        ["-c", "[skip(2; .[])], [skip(0; .[])], [skip(9; .[])], "
               "[skip(-1; .[])]"],
        stdin="[1, 2, 3]\n", tmp_path=tmp_path)
    assert res.out == "[3]\n[1,2,3]\n[]\n"
    assert res.err == "gojq: error: skip doesn't support negative count\n"
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("[first, last]", "[1, 2, 3]\n", "[1,3]\n"),
    ("first(.[]), last(.[])", "[1, 2, 3]\n", "1\n3\n"),
    ("[first(empty)], [last(empty)]", "null", "[]\n[]\n"),
    # first/last on an empty array give null, not errors
    ("first, last", "[]\n", "null\nnull\n"),
    # nth/1 is index-based; negative indices clamp from the end
    ("nth(2), nth(-1), nth(9)", "[1, 2, 3]\n", "3\n3\nnull\n"),
    ("nth(2; .[]), nth(9; .[])", "[1, 2, 3]\n", "3\n"),
    ("try first catch .", "null", "null\n"),
])
def test_first_last_nth(tmp_path, query, stdin, expected_out):
    """first/last/nth pick positions from arrays or sub-iterators.

    From ``cli/test.yaml``: 'first/0, last/0, nth/1 functions',
    'first/1, last/1, nth/2 functions', '... on empty'.
    """
    # CATCHES: nth/2 out of range produces nothing (no null)
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_first_arity_error(tmp_path):
    """first/2 is not defined; only first/0 and first/1 exist."""
    # CATCHES: compile error rc 3 names the missing arity exactly
    res = run_gojq(["-c", "try (. | first(1; 2)) catch ."],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: compile error: function not defined: first/2\n"
    assert res.rc == 3


@pytest.mark.parametrize("query,stdin,expected_out", [
    # while emits each state before the update, until only the last
    ("[., 1] | [while(.[0] < 100; [.[0] + .[1], .[0]])]", "1",
     "[[1,1],[2,1],[3,2],[5,3],[8,5],[13,8],[21,13],[34,21],[55,34],"
     "[89,55]]\n"),
    ("[., 1] | [until(.[0] > 100; [.[0] + .[1], .[0]])]", "1",
     "[[144,89]]\n"),
    # repeat applies f to the unchanged input every iteration
    ("[limit(4; repeat(. * 2))]", "1", "[2,2,2,2]\n"),
    ("[limit(4; repeat(.*.))]", "2", "[4,4,4,4]\n"),
])
def test_while_until_repeat(tmp_path, query, stdin, expected_out):
    """while/until/repeat generate streams of states.

    From ``cli/test.yaml``: 'while function', 'until function' and
    'repeat function'.
    """
    # CATCHES: repeat never emits the initial value, only f outputs
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("[combinations]", "[[1, 2], [3, 4]]",
     "[[1,3],[1,4],[2,3],[2,4]]\n"),
    ("[combinations(2)]", "[1, 2]", "[[1,1],[1,2],[2,1],[2,2]]\n"),
    ("[combinations(3)]", "[0, 1]",
     "[[0,0,0],[0,0,1],[0,1,0],[0,1,1],[1,0,0],[1,0,1],[1,1,0],[1,1,1]]\n"),
])
def test_combinations(tmp_path, query, stdin, expected_out):
    """combinations enumerates the cartesian product of the input arrays.

    From ``cli/test.yaml``: 'combinations/0 function' and
    'combinations/1 function'.
    """
    # CATCHES: combinations(n) reuses the same array n times
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('walk(if type == "number" then . + 1 else . end)',
     '{"a": [1, 2], "b": {"c": 3}}', '{"a":[2,3],"b":{"c":4}}\n'),
    ('walk(if type == "array" then sort else . end)', "[[3, 1], [2]]",
     "[[1,3],[2]]\n"),
])
def test_walk(tmp_path, query, stdin, expected_out):
    """walk applies a filter bottom-up over the whole tree.

    From ``cli/test.yaml``: 'walk function' and 'walk function with
    multiple values'.
    """
    # CATCHES: children are walked before the filter sees the parent
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("INDEX(range(5); .*2)", "null", '{"0":0,"2":1,"4":2,"6":3,"8":4}\n'),
    ("INDEX(.[]; .a)", '[{"a": 1}, {"a": 2}]',
     '{"1":{"a":1},"2":{"a":2}}\n'),
    # JOIN pairs by key; missing keys join with null
    ("[range(5)] | JOIN(map(.*3); .*2)", "null",
     "[[0,0],[1,6],[2,12],[3,null],[4,null]]\n"),
    ("[range(5; 13)|IN(range(0; 10; 3))]", "null",
     "[false,true,false,false,true,false,false,false]\n"),
])
def test_index_join_in(tmp_path, query, stdin, expected_out):
    """INDEX/JOIN/IN build and probe key-based lookups.

    From ``cli/test.yaml``: 'INDEX function', 'JOIN function' and 'IN
    function'.
    """
    # CATCHES: IN answers per element against a stream of candidates
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("[any, all, any(.[]; .), all(.[]; .), any(.[]; . > 1), "
     "all(.[]; . > 1)]", "[]", "[false,true,false,true,false,true]\n"),
    ("[any, all, any(.[]; . > 1), all(.[]; . > 1)]", "[true, false]",
     "[true,false,false,false]\n"),
    ("[any, all, any(.[]; . > 1), all(.[]; . > 1)]", "[1, 2]",
     "[true,true,true,false]\n"),
    ("[isempty(empty), isempty(1), isempty(1, 2)]", "null",
     "[true,false,false]\n"),
])
def test_any_all_isempty(tmp_path, query, stdin, expected_out):
    """any/all fold truthiness over arrays; isempty peeks one output.

    From ``cli/test.yaml``: 'all/0, any/0 functions', 'all/1, any/1
    functions', 'all/2, any/2 functions' and 'isempty function'.
    """
    # CATCHES: all of [] is true while any of [] is false
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out,expected_err,expected_rc", [
    # error(null) previews as null in the fatal message
    ("try error(null) catch ., (error(null) | .)", "null\n",
     "gojq: error: null\n", 5),
    ("error(\"msg\")", "", "gojq: error: msg\n", 5),
    # non-string error values pass through catch unchanged
    ("try (error({a: 1})) catch .", '{"a":1}\n', "", 0),
    ("try (error(null)) catch ., try (error([1])) catch .", "null\n[1]\n",
     "", 0),
])
def test_error_function_forms(tmp_path, query, expected_out, expected_err,
                              expected_rc):
    """error raises with the given value; catch receives it verbatim."""
    # CATCHES: uncaught error(null) still prints "gojq: error: null"
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == expected_err
    assert res.rc == expected_rc


def test_env_and_dollar_env(tmp_path):
    """env and $ENV expose the pinned child environment identically."""
    # CATCHES: $ENV and env are separate objects with equal contents
    res = run_gojq(
        ["-c", "[env.TZ, env.PATH, $ENV.TZ, $ENV.PATH, ($ENV | type), "
               "(env | type), ($ENV == env)]"],
        stdin="null", tmp_path=tmp_path)
    assert res.out == ('["UTC","/usr/bin:/bin","UTC","/usr/bin:/bin",'
                       '"object","object",true]\n')
    assert res.err == ""
    assert res.rc == 0


def test_now_bounds(tmp_path):
    """now returns a plausible epoch-seconds number."""
    # CATCHES: bounded between 2001 and 2100, so the test never flakes
    res = run_gojq(["-c", "[now | type, now > 1000000000, "
                          "now < 4102444800]"],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == '["number",true,true]\n'
    assert res.err == ""
    assert res.rc == 0


def test_reduce_and_foreach(tmp_path):
    """reduce folds; foreach emits each intermediate state."""
    # CATCHES: foreach's output uses the update value, not the state
    res = run_gojq(
        ["-c", "[range(.)] | reduce .[] as $i (0; . + $i), "
               "[foreach range(5) as $item (0; $item)]"],
        stdin="10", tmp_path=tmp_path)
    assert res.out == "45\n[0,1,2,3,4]\n"
    assert res.err == ""
    assert res.rc == 0


def test_builtins_surface(tmp_path):
    """builtins lists path functions with their arities."""
    # CATCHES: exact sorted list of the path-related builtin names
    res = run_gojq(
        ["-c", 'builtins | length > 100, '
               '(map(select(test("^(getpath|setpath|delpaths|paths)/"))) '
               "| sort)"],
        stdin="null", tmp_path=tmp_path)
    assert res.out == ('true\n["delpaths/1","getpath/1","paths/0","paths/1",'
                       '"setpath/2"]\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_err", [
    ("[leaf_paths]", '{"a":[1,{"b":2}]}',
     "gojq: compile error: function not defined: leaf_paths/0\n"),
    ("keys_unsorted", '{"a":1}',
     "gojq: compile error: function not defined: keys_unsorted/0\n"),
    ("toarray", "[1]",
     "gojq: compile error: function not defined: toarray/0\n"),
])
def test_skew_functions_absent_from_build(tmp_path, query, stdin,
                                          expected_err):
    """functions in the newer source tree that the binary lacks.

    leaf_paths, keys_unsorted and toarray exist in the source under
    test but are not compiled into this gojq 0.12.19 binary; the tests
    pin the binary's actual compile-error behavior.
    """
    # CATCHES: rc 3 compile error before any stdin value is read
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 3
