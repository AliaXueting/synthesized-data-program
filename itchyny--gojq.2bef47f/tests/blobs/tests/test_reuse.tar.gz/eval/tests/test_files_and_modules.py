"""File arguments, query files and module loading through the CLI.

Rewritten from the native suite ``cli/test.yaml`` cases "hyphen for stdin",
"json file arguments", "source query from file", "query file not found",
"json file error json" and the ``-L`` module directory option cases.
"""

import pytest

from conftest import run_gojq

#: Exact contents of the ``testdata`` fixtures used by the native suite.
TESTDATA = {
    "testdata/1.json": '{"foo":10}\n',
    "testdata/2.json": '[{\n"bar"\n:\n[]\n}]\n',
    "testdata/3.json": "{\n",
    "testdata/1.jq": ".foo.bar\n",
    "testdata/4.jq": ('include "5";\nimport "6" as bar;\n'
                      'def f: [., . * 2, h, (bar::i|.+1), bar::g];\n'
                      'def g: { foo: . };\n'),
    "testdata/5.jq": 'import "6" as foo { test: "foo" };\ndef h: . * foo::i;\n',
    "testdata/6.jq": 'import "7" as $x;\ndef i: 3;\ndef g: $x;\n',
    "testdata/7.jq": "def f: 1 +",
    "testdata/7.json": '1\n2\n{ "foo": 42 }\n',
}


def test_hyphen_for_stdin(tmp_path):
    """A ``-`` file argument reads from standard input.

    Native case "hyphen for stdin": with stdin supplied and ``-`` given as
    the only file argument, the input is read from the pipe.
    """
    # CATCHES: "-" as a file argument is stdin, not a file named "-"
    res = run_gojq([".", "-"], stdin="{}", tmp_path=tmp_path)
    assert res.out == "{}\n"
    assert res.err == ""
    assert res.rc == 0


def test_json_file_arguments(tmp_path):
    """Positional arguments after the query are input files.

    Native case "json file arguments": each file's values are processed in
    order, pretty-printed.
    """
    # CATCHES: multiple JSON files processed in argument order
    res = run_gojq([".", "testdata/1.json", "testdata/2.json"],
                   tmp_path=tmp_path, files=TESTDATA)
    assert res.out == '{\n  "foo": 10\n}\n[\n  {\n    "bar": []\n  }\n]\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args", [["-f", "testdata/1.jq"], ["-cfr", "testdata/1.jq"]])
def test_query_from_file(tmp_path, args):
    """-f loads the query from a file; short flags may be clumped.

    Native cases "source query from file" and "source query from file short
    option in clumped options": ``-cfr`` parses as -c, -f and -r clumped,
    with the query file path as -f's argument.
    """
    # CATCHES: clumped short flags "-cfr" take the file path as -f argument
    res = run_gojq(args, stdin='{"foo":{"bar":42}}', tmp_path=tmp_path,
                   files=TESTDATA)
    assert res.out == "42\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args,expected_err", [
    (["-f", "testdata/3.jq"], "gojq: open testdata/3.jq: no such file or directory\n"),
    (["-f"], "gojq: expected a query file for flag `-f'\n"),
])
def test_query_file_errors(tmp_path, args, expected_err):
    """Missing or unspecified query files produce distinct messages.

    Native cases "query file not found" and "query file not specified": both
    exit with the default error code 5.
    """
    # CATCHES: missing file vs missing flag argument are distinct messages
    res = run_gojq(args, tmp_path=tmp_path, files=TESTDATA)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == expected_err


def test_json_file_input_errors(tmp_path):
    """File input errors name the file and processing still covers others.

    Native cases "json file error json" (error message names
    ``testdata/3.json``) and "json file not found error": a missing middle
    file only adds a stderr line; the remaining files are still processed.
    """
    # CATCHES: file name appears in error; later files still fully processed
    res = run_gojq([".", "testdata/3.json"], tmp_path=tmp_path, files=TESTDATA)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == ("gojq: invalid json: testdata/3.json\n"
                       "    {\n"
                       "     ^  unexpected EOF\n")

    res = run_gojq([".", "testdata/1.json", "testdata/6.json", "testdata/2.json"],
                   tmp_path=tmp_path, files=TESTDATA)
    assert res.rc == 5
    assert res.out == '{\n  "foo": 10\n}\n[\n  {\n    "bar": []\n  }\n]\n'
    assert res.err == "gojq: open testdata/6.json: no such file or directory\n"


def test_module_include(tmp_path):
    """-L adds a module search directory for include/import.

    Native case "module directory option": ``include "4"`` pulls in a chain
    of modules (4 -> 5 -> 6 -> 7) including a data module loaded as ``$x``.
    """
    # CATCHES: transitive module include chain resolves against -L directory
    res = run_gojq(["-c", "-L", "testdata", 'include "4"; 1 | f | g'],
                   stdin="0", tmp_path=tmp_path, files=TESTDATA)
    assert res.out == '{"foo":[1,2,3,4,[1,2,{"foo":42}]]}\n'
    assert res.err == ""
    assert res.rc == 0


def test_module_import_data_and_invalid_module(tmp_path):
    """Data modules bind JSON files as variables; bad modules fail at compile.

    Native cases "module directory option" (``import "7" as $foo``) and
    "invalid query in a module": importing ``7`` binds ``7.json`` to ``$foo``
    and its defs to ``$foo::``, while including the module with the invalid
    query ``def f: 1 +`` reports the module's own file name and exit code 3.
    """
    # CATCHES: module file name and line number appear in the compile error
    res = run_gojq(["-c", "--library-path", "testdata",
                    'import "7" as $foo; $foo, $foo::foo'],
                   stdin="0", tmp_path=tmp_path, files=TESTDATA)
    assert res.out == '[1,2,{"foo":42}]\n[1,2,{"foo":42}]\n'
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["-L", "testdata", 'include "7"; .'], stdin="0",
                   tmp_path=tmp_path, files=TESTDATA)
    assert res.rc == 3
    assert res.out == ""
    assert res.err == ('gojq: invalid query: testdata/7.jq:1\n'
                       '    1 | def f: 1 +\n'
                       '                  ^  unexpected EOF\n')
