"""Output formatting options: -c/-r/--raw-output0/-j/--indent/--tab/colors/YAML.

Rewritten from the native suite ``cli/test.yaml`` option cases ("compact
output option", "raw string output", "indent option", "tab option", "color
output option", ...).
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("args,stdin,expected_out,expected_err,rc", [
    (["-c", "."], '{ "foo": ["hello", "world"] }',
     '{"foo":["hello","world"]}\n', "", 0),
    (["--compact-output", "."], '{ "foo": ["hello", "world"] }',
     '{"foo":["hello","world"]}\n', "", 0),
    (["--compact-output=1", "."], "0", "",
     "gojq: boolean flag `--compact-output' cannot have an argument\n", 2),
])
def test_compact_output(tmp_path, args, stdin, expected_out, expected_err, rc):
    """Compact output removes all whitespace between JSON tokens.

    Native cases "compact output option", "compact output long option" and
    "compact output long option with value": attaching ``=1`` to a boolean
    flag is a flag parse error with exit code 2.
    """
    # CATCHES: boolean long flags reject "=value" with exit code 2
    res = run_gojq(args, stdin=stdin, tmp_path=tmp_path)
    assert res.rc == rc
    assert res.out == expected_out
    assert res.err == expected_err


def test_raw_output_prints_strings_raw(tmp_path):
    """-r prints string results without quotes; other values stay JSON.

    Native cases "raw string output long option" and "raw string output
    option against non-string": embedded newlines inside raw strings are
    written as-is, while an object result falls back to pretty JSON.
    """
    # CATCHES: -r only unwraps strings; objects still pretty-print with newlines
    res = run_gojq(["--raw-output", ".foo[]"],
                   stdin='{ "foo": ["hello", "world", "multiple\\nline"] }',
                   tmp_path=tmp_path)
    assert res.out == "hello\nworld\nmultiple\nline\n"
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["-r", "."], stdin='{ "foo": "multiple\\nline" }',
                   tmp_path=tmp_path)
    assert res.out == '{\n  "foo": "multiple\\nline"\n}\n'
    assert res.rc == 0


def test_raw_output0_nul_delimited(tmp_path):
    r"""--raw-output0 terminates every result with a NUL byte.

    Native cases "raw string output with nul delimiter option" and "...error
    with string containing nul character": non-string results are still
    pretty-printed JSON followed by NUL, and a string containing NUL is
    rejected after earlier results were already written.
    """
    # CATCHES: NUL delimiter written after each result incl. pretty JSON ones
    res = run_gojq(["--raw-output0", ".[]"], stdin='["foo",[{},{}],1,[2,3]]',
                   tmp_path=tmp_path)
    assert res.out == "foo\x00[\n  {},\n  {}\n]\x001\x00[\n  2,\n  3\n]\x00"
    assert res.err == ""
    assert res.rc == 0

    res = run_gojq(["--raw-output0", '"foo","bar","b\\u0000a\\u0000z","qux"'],
                   stdin="null", tmp_path=tmp_path)
    assert res.out == "foo\x00bar\x00"
    assert res.err == ('gojq: cannot output a string containing NUL character: '
                       '"b\\x00a\\x00z"\n')
    assert res.rc == 5


def test_join_output(tmp_path):
    """-j joins results with no separator at all.

    Native case "join output option": strings are printed raw and nothing
    (not even a newline) is appended between or after results.
    """
    # CATCHES: -j emits no trailing newline after the last result
    res = run_gojq(["-j", ".[]"], stdin='["foo",1,2,3]', tmp_path=tmp_path)
    assert res.out == "foo123"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("indent,expected_out", [
    ("1", '{\n "foo": [\n  "hello",\n  "world"\n ]\n}\n'),
    ("0", '{\n"foo": [\n"hello",\n"world"\n]\n}\n'),
])
def test_indent_option(tmp_path, indent, expected_out):
    """--indent N replaces the default two-space indentation.

    Native cases "indent option" (N=1) and "indent option with value 0"
    (N=0 still breaks lines, only without leading spaces).
    """
    # CATCHES: indent 0 keeps newlines but drops all leading spaces
    res = run_gojq(["--indent", indent, "."],
                   stdin='{ "foo": ["hello", "world"] }', tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args,expected_err", [
    (["--indent=10", "."], "gojq: too many indentation count: 10\n"),
    (["--indent", "-1", "."], "gojq: negative indentation count: -1\n"),
])
def test_indent_option_out_of_range(tmp_path, args, expected_err):
    """Indentation above 9 or below 0 is rejected before any input is read.

    Native cases "indent option too many indentation count error" and
    "indent option negative indentation count error": exit code is 5
    (default error) and no output is produced.
    """
    # CATCHES: out-of-range indent rejected with exit 5 and empty stdout
    res = run_gojq(args, stdin='{ "foo": { "baz": ["hello", "world"] } }',
                   tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == expected_err


def test_tab_indentation(tmp_path):
    """--tab indents nested values with tab characters.

    Native case "tab option": each nesting level adds one tab.
    """
    # CATCHES: --tab uses literal tab bytes per nesting depth
    res = run_gojq(["--tab", "."],
                   stdin='{ "foo": { "baz": ["hello", ["world", []]] } }',
                   tmp_path=tmp_path)
    assert res.out == ('{\n\t"foo": {\n\t\t"baz": [\n\t\t\t"hello",\n'
                       '\t\t\t[\n\t\t\t\t"world",\n\t\t\t\t[]\n\t\t\t]\n'
                       '\t\t]\n\t}\n}\n')
    assert res.err == ""
    assert res.rc == 0


def test_color_output_ansi_escapes(tmp_path):
    """-C colors every JSON token class even though stdout is a pipe.

    Native case "color output option": object keys are bold blue, numbers
    cyan, strings green, null gray, booleans yellow, and each escape is
    closed with ``\\033[0m``.
    """
    # CATCHES: ANSI colors emitted for a piped stdout when -C forces them on
    res = run_gojq(["-C", "., null, nan, infinite"],
                   stdin='{"x":"foo","y":128,"z":[null,false,true,3.14,"foo",{}]}',
                   tmp_path=tmp_path)
    assert res.out == (
        '{\n  \x1b[34;1m"x"\x1b[0m: \x1b[32m"foo"\x1b[0m,\n'
        '  \x1b[34;1m"y"\x1b[0m: \x1b[36m128\x1b[0m,\n'
        '  \x1b[34;1m"z"\x1b[0m: [\n'
        '    \x1b[90mnull\x1b[0m,\n'
        '    \x1b[33mfalse\x1b[0m,\n'
        '    \x1b[33mtrue\x1b[0m,\n'
        '    \x1b[36m3.14\x1b[0m,\n'
        '    \x1b[32m"foo"\x1b[0m,\n'
        '    {}\n'
        '  ]\n'
        '}\n'
        '\x1b[90mnull\x1b[0m\n'
        '\x1b[90mnull\x1b[0m\n'
        '\x1b[36m1.7976931348623157e+308\x1b[0m\n')
    assert res.err == ""
    assert res.rc == 0


def test_gojq_colors_env_variable(tmp_path):
    """GOJQ_COLORS overrides the eight color classes.

    Native case "color output option configured by environment variable":
    ``31:32:33:34:35:36:41:42`` maps null/false/true/number/string/object
    key/array braces/object braces respectively.
    """
    # CATCHES: GOJQ_COLORS order colors object and array braces (41:42)
    res = run_gojq(["-C", "."],
                   stdin='{ "x": "foo", "y": 128, "z": [null, false, true, 3.14, "foo", {}] }\n',
                   tmp_path=tmp_path,
                   env={"GOJQ_COLORS": "31:32:33:34:35:36:41:42"})
    assert res.out == (
        '\x1b[42m{\x1b[0m\n'
        '  \x1b[36m"x"\x1b[0m\x1b[42m:\x1b[0m \x1b[35m"foo"\x1b[0m\x1b[42m,\x1b[0m\n'
        '  \x1b[36m"y"\x1b[0m\x1b[42m:\x1b[0m \x1b[34m128\x1b[0m\x1b[42m,\x1b[0m\n'
        '  \x1b[36m"z"\x1b[0m\x1b[42m:\x1b[0m \x1b[41m[\x1b[0m\n'
        '    \x1b[31mnull\x1b[0m\x1b[41m,\x1b[0m\n'
        '    \x1b[32mfalse\x1b[0m\x1b[41m,\x1b[0m\n'
        '    \x1b[33mtrue\x1b[0m\x1b[41m,\x1b[0m\n'
        '    \x1b[34m3.14\x1b[0m\x1b[41m,\x1b[0m\n'
        '    \x1b[35m"foo"\x1b[0m\x1b[41m,\x1b[0m\n'
        '    \x1b[42m{\x1b[0m\x1b[42m}\x1b[0m\n'
        '  \x1b[41m]\x1b[0m\n'
        '\x1b[42m}\x1b[0m\n')
    assert res.err == ""
    assert res.rc == 0


def test_color_flag_overrides_no_color_env(tmp_path):
    """-C wins over a set NO_COLOR environment variable.

    Native case "NO_COLOR environment variable with color output option":
    NO_COLOR=1 alone disables colors, but ``--color-output`` re-enables
    them, while ``-M`` next to ``-C`` disables them again.
    """
    # CATCHES: -C forces colors even when NO_COLOR=1 is set in the env
    res = run_gojq(["--color-output", "."], stdin='{"foo":42}', tmp_path=tmp_path,
                   env={"NO_COLOR": "1"})
    assert res.out == '{\n  \x1b[34;1m"foo"\x1b[0m: \x1b[36m42\x1b[0m\n}\n'
    assert res.rc == 0

    res = run_gojq(["-C", "-M", "."], stdin='{"foo":42}', tmp_path=tmp_path,
                   env={"NO_COLOR": "1"})
    assert res.out == '{\n  "foo": 42\n}\n'
    assert res.err == ""
    assert res.rc == 0


def test_yaml_output(tmp_path):
    """--yaml-output emits YAML with sorted keys and dash-style lists.

    Native case "yaml output option": keys are sorted, list items get the
    ``- `` prefix and empty collections print as ``[]``.
    """
    # CATCHES: YAML output sorts object keys and uses "- " list syntax
    res = run_gojq(["--yaml-output", "."],
                   stdin='{"foo": 128, "bar": {"baz": [1,"qux", []]}}',
                   tmp_path=tmp_path)
    assert res.out == "bar:\n  baz:\n    - 1\n    - qux\n    - []\nfoo: 128\n"
    assert res.err == ""
    assert res.rc == 0
