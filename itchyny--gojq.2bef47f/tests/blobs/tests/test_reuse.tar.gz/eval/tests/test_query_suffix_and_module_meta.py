"""Optional suffixes, assignment path forms and module metadata (query.go).

Rewritten from the suffix/assignment handling of the native suite
(``cli/test.yaml`` optional and reduce cases, the constant-path assignment
family) and the module cases "search directory in query", "empty module",
"module directive", "module in query" and "modulemeta function".  Every
expected value below was recorded by running the reference binary.
"""

import pytest

from conftest import run_gojq

#: Module fixtures mirroring the native suite's ``testdata`` directory.
MODULE_FILES = {
    "lib/m.jq": "def f: 42;\n",
    # module metadata holding every const value shape, including the
    # nested object/array forms only metadata can express
    "lib/n.jq": ('module {"x": {"y": [1,2]}, "s": "str", "n": null,'
                 ' "b": true, "fl": 1.5};\ndef g: 43;\n'),
    "testdata/8.jq": "\n",
    "testdata/9.jq": ('module {\n  "name": "sample-module",\n'
                      '  "description": "This is a description",\n'
                      '  x: [\n    [],\n    {},\n    { y: 10, z: 20 }\n  ],\n'
                      '  y: {\n    z: [128, "", false, true, null, [[]]]\n'
                      '  },\n};\n\ndef f($x): $x * .;\n'),
    "testdata/m2/m2.jq": ('import "m3" as x { "search": "./" };\n'
                          'import "m3" as $x { search: "./" };\n\n'
                          'def g: ., x::g, $x[];\n'),
    "testdata/m2/m3.jq": "def g: 43;\n",
    "testdata/m2/m3.json": "44\n",
}


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('[{"b":1},1] | map(.b?)', "null", "[1]\n"),
    ("[1,{\"a\":2}] | map(.a??)", "null", "[2]\n"),
])
def test_optional_suffix_filters_erroring_inputs(tmp_path, query, stdin,
                                                 expected_out):
    """"?"" suppresses errors from the suffixed index, dropping outputs.

    ``map(.b?)`` keeps the results of the inputs where ``.b`` works and
    silently skips the ones where it errors.
    """
    # CATCHES: suppression drops the failing input's output entirely
    # instead of yielding null like try/catch does
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_optional_suffix_binds_to_the_last_suffix_only(tmp_path):
    """in ".a.b?" only ".b" is protected, ".a" still errors.

    The optional suffix wraps the term built from the immediately
    preceding suffix, so an earlier failing index still aborts the query.
    """
    # CATCHES: 1 | .a.b? errors on .a even though a "?" is present
    res = run_gojq(["-c", "1 | .a.b?"], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == "gojq: expected an object but got: number (1)\n"
    assert res.rc == 5


def test_double_optional_suffix(tmp_path):
    """a second "?" stacks another try around the first.

    ``.a??`` keeps the value for every input the index works on and drops
    the others per input value, so a mixed stream keeps its good outputs
    instead of aborting — and an all-erroring input feeds ``//`` its
    "no output" result.
    """
    # CATCHES: .a?? emits 1 and 2 for the two object inputs while silently
    # skipping the number between them, instead of erroring or emitting null
    res = run_gojq(["-c", ".a??"], stdin='{"a":1}\n1\n{"a":2}\n',
                   tmp_path=tmp_path)
    assert res.out == "1\n2\n"
    assert res.err == ""
    assert res.rc == 0
    # CATCHES: the doubled suffix still yields empty (not null), so the
    # alternative operator takes its right side
    res = run_gojq(["-c", '.a?? // "none"'], stdin="1", tmp_path=tmp_path)
    assert res.out == '"none"\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('{"a":1} | .["a"?]', "null", "1\n"),
    ("[1,2] | .[0?]", "null", "1\n"),
])
def test_optional_suffix_inside_index(tmp_path, query, stdin, expected_out):
    """a "?" may follow a constant inside "[...]" and still indexes.

    The suffix disables the constant-folding of the index, but the lookup
    itself behaves like the plain form.
    """
    # CATCHES: .["a"?] returns the value, not an error or null
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_optional_index_does_not_suppress_lookup_error(tmp_path):
    """".[1?]" does not protect the actual array/object lookup.

    The "?" sits on the constant term inside the brackets, so the type
    error from applying that index to an object is not suppressed.
    """
    # CATCHES: {"a":1} | .[1?] errors even though a "?" appears in the query
    res = run_gojq(["-c", '{"a":1} | .[1?]'], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == 'gojq: expected an array but got: object ({"a":1})\n'
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('{"a1":5} | .["a\\(1)"]', "null", "5\n"),
    ('path(.["a\\(1)"])', '{"a1":5}', '["a1"]\n'),
    ('.["a\\(1)"] = 9', "{}", '{"a1":9}\n'),
])
def test_interpolated_string_index_stays_a_path(tmp_path, query, stdin,
                                                expected_out):
    """a string interpolation inside "[...]" is not folded to a constant.

    ``.["a\\(1)"]`` cannot be reduced to a compile-time key, yet it still
    behaves as a real path: it indexes, ``path`` reports the interpolated
    key, and it is assignable on the left of ``=``.
    """
    # CATCHES: the interpolated key resolves at run time to "a1" for both
    # path() and assignment, instead of being folded away or rejected
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    # an iterate suffix on the left assigns to every element
    ('{"a":[1,2]} | .a[] = 0', '{"a":[1,2]}', '{"a":[0,0]}\n'),
    # a parenthesized left side still describes a constant path
    ('{"a":{"x":1}} | (.a).x = 2', "null", '{"a":{"x":2}}\n'),
    ('{"a":1} | .[("a")] = 2', "null", '{"a":2}\n'),
    # negative constant indices on the left address from the end
    ('{"a":[1,2]} | .a[-1] = 9', '{"a":[1,2]}', '{"a":[1,9]}\n'),
    ('{"a":[1,2]} | .a[(-1)] = 9', '{"a":[1,2]}', '{"a":[1,9]}\n'),
    # chains through arrays and objects
    ('{"a":[{"b":1}]} | .a[0].b = 2', "null", '{"a":[{"b":2}]}\n'),
    ("[[1]] | .[0][0] = 5", "null", "[[5]]\n"),
])
def test_assignment_left_hand_path_forms(tmp_path, query, stdin, expected_out):
    """assignment accepts iterate, parenthesized and negative left sides.

    ``.a[] = 0`` updates every element, ``(.a).x`` and ``.[("a")]`` keep
    their parenthesized forms usable as paths, and negative constant
    indices count from the end.
    """
    # CATCHES: .a[] = 0 writes through every position, and .a[(-1)] with
    # the parenthesized minus still addresses the last element
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_parenthesized_left_hand_setpath_error(tmp_path):
    """a parenthesized left side reports failures as setpath errors.

    When ``(.a).x = 2`` meets a non-object at ``.a``, the optimized
    assignment surfaces the internal setpath call with the full path.
    """
    # CATCHES: the error previews the setpath arguments ["a","x"] and 2
    res = run_gojq(["-c", '{"a":1} | (.a).x = 2'], stdin="null",
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == ('gojq: setpath(["a","x"]; 2) cannot be applied to '
                       '{"a":1}: expected an object but got: number (1)\n')
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    ('{"a":[1,2,3]} | .a[1:] = [9]', '{"a":[1,9]}\n'),
    ('{"a":[1,2,3]} | .a[1:2] = [9,9,9]', '{"a":[1,9,9,9,3]}\n'),
])
def test_slice_assignment_splices(tmp_path, query, expected_out):
    """slice assignment replaces the selected range, splicing lengths.

    Assigning a longer array to a one-element slice grows the array in
    place; assigning to an open-ended slice truncates the tail.
    """
    # CATCHES: .a[1:2] = [9,9,9] grows the array instead of overwriting
    # neighbours or rejecting the length mismatch
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args,stdin,expected_out", [
    (["-nc", "module {}; ."], "null", "null\n"),
    (["-c", "-L", "testdata", 'include "8"; .'], "0", "0\n"),
    (["-c", "-L", "testdata", 'include "9"; f(2)'], "3", "6\n"),
    (["-nc", "module {x: [1, {y: 2}], s: \"str\", n: null, b: true, fl: 1.5}; 1"],
     "null", "1\n"),
])
def test_module_directive_forms(tmp_path, args, stdin, expected_out):
    """module directives and empty modules parse and run.

    Native cases "module in query", "empty module" and "module directive":
    a query may start with its own module directive, a module file may be
    empty, and a module's defs stay usable (``f(2)`` multiplies by input).
    """
    # CATCHES: include "9"; f(2) applies the module function to the input,
    # and a module directive with nested const metadata does not error
    res = run_gojq(args, stdin=stdin, tmp_path=tmp_path, files=MODULE_FILES)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_module_metadata_with_every_const_value(tmp_path):
    """module metadata accepts objects, arrays and scalars as values.

    The metadata parser evaluates constant terms only, so nested object
    and array values import cleanly alongside strings, null, booleans and
    floats.
    """
    # CATCHES: nested {"y": [1,2]} and 1.5 metadata values do not break
    # the import; the module's def g is still reachable
    res = run_gojq(["-nc", '-L', "lib", 'import "n" as n {"search": "lib"}; n::g'],
                   tmp_path=tmp_path, files=MODULE_FILES)
    assert res.out == "43\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("args,expected_out", [
    (["-nc", "-L", "testdata", '"9" | modulemeta'],
     '{"defs":["f/1"],"deps":[],"description":"This is a description",'
     '"name":"sample-module","x":[[],{},{"y":10,"z":20}],'
     '"y":{"z":[128,"",false,true,null,[[]]]}}\n'),
    (["-nc", "-L", "testdata", '"8" | modulemeta'],
     '{"defs":[],"deps":[]}\n'),
    (["-nc", "-L", "testdata", '"m2" | modulemeta'],
     '{"defs":["g/0"],"deps":[{"as":"x","is_data":false,"relpath":"m3",'
     '"search":"testdata/m2"},{"as":"x","is_data":true,"relpath":"m3",'
     '"search":"testdata/m2"}]}\n'),
])
def test_modulemeta_reflects_metadata(tmp_path, args, expected_out):
    """modulemeta exposes module metadata and resolved search paths.

    Native case "modulemeta function": const metadata values are reflected
    verbatim (including nested arrays/objects) and dependency entries show
    whether the import binds a value (``is_data``) plus the search path
    resolved relative to the importing module's directory.
    """
    # CATCHES: m2's {"search": "./"} is reported as the resolved directory
    # "testdata/m2", and the data import is flagged is_data: true
    res = run_gojq(args, tmp_path=tmp_path, files=MODULE_FILES)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_modulemeta_module_not_found(tmp_path):
    """modulemeta fails for unknown module names with exit code 5.

    Native case "modulemeta function error": the error is a plain runtime
    error (exit 5), not a compile error.
    """
    # CATCHES: modulemeta not-found is exit 5 with the module name quoted
    res = run_gojq(["-nc", "-L", "testdata", '"3" | modulemeta'],
                   tmp_path=tmp_path, files=MODULE_FILES)
    assert res.out == ""
    assert res.err == 'gojq: module not found: "3"\n'
    assert res.rc == 5


def test_search_metadata_in_query(tmp_path):
    """a search field in import metadata redirects module lookup.

    Native case "search directory in query": ``include "m2" { search: ... }``
    loads m2 from the given directory, and m2's own ``{ "search": "./" }``
    resolves m3 relative to m2's directory — so one g emits the input, the
    function result 43 and the data module value 44.
    """
    # CATCHES: the module's "./" search resolves to its own directory,
    # yielding all three outputs 0, 43 and 44
    res = run_gojq(["-c", 'include "m2" { search: "testdata/m2" }; g'],
                   stdin="0", tmp_path=tmp_path, files=MODULE_FILES)
    assert res.out == "0\n43\n44\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("meta", ['"nowhere"', "1", "null"])
def test_unusable_search_metadata_falls_back(tmp_path, meta):
    """a missing directory or non-string search falls back to the default.

    Only a string search value redirects lookup; a number or null is
    ignored, and a directory that does not exist makes the import fail
    with the standard module-not-found compile error.
    """
    # CATCHES: {"search": 1} does not error about the metadata itself —
    # it silently uses the default paths and reports module not found
    res = run_gojq(["-nc", 'import "m" as m {"search": %s}; m::f' % meta],
                   tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == 'gojq: compile error: module not found: "m"\n'
    assert res.rc == 3


@pytest.mark.parametrize("query,expected_err", [
    ('module {"x": (1)}; 1',
     'gojq: invalid query: module {"x": (1)}; 1\n'
     '    module {"x": (1)}; 1\n'
     '                 ^  unexpected token "("\n'),
    ('import "m" as m {"search": .}; m::f',
     'gojq: invalid query: import "m" as m {"search": .}; m::f\n'
     "    import \"m\" as m {\"search\": .}; m::f\n"
     '                               ^  unexpected token "."\n'),
])
def test_module_metadata_must_be_constant(tmp_path, query, expected_err):
    """module metadata values must be constant terms.

    Parenthesized expressions and queries are rejected at parse time with
    the caret pointing at the offending token.
    """
    # CATCHES: the parse error quotes the whole query, repeats it on the
    # second line and marks the exact column of the "(" or "."
    res = run_gojq(["-nc", query], tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 3
