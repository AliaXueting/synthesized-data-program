"""Arithmetic operator edges: big integers, overflow and json.Number (operator.go).

Rewritten from the operator coverage of the native suite: the big-integer
semantics of ``cli/test.yaml`` (values beyond int64 stay exact), the
number-literal passthrough cases of the library tests (``number_test.go``,
``encoder_test.go``) and the type-error matrix of the operator callbacks.
Every expected value below was recorded by running the reference binary.
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("query,expected_out", [
    # float64 with a big.Int operand widens through float64
    ("1.5 + 10000000000000000000", "10000000000000000000\n"),
    ("10000000000000000000 + 0.5", "10000000000000000000\n"),
    # big.Int arithmetic stays exact instead of degrading to float64
    ("10000000000000000000 * 10000000000000000000",
     "100000000000000000000000000000000000000\n"),
    ("10000000000000000000 - 10000000000000000000", "0\n"),
    ("10000000000000000000 / 10000000000000000000", "1\n"),
    ("10000000000000000001 / 10000000000000000000", "1\n"),
    ("10000000000000000000 % 10000000000000000000", "0\n"),
    # int64 overflow promotes to big.Int in both directions
    ("9223372036854775807 + 1", "9223372036854775808\n"),
    ("0 - 9223372036854775807 - 2", "-9223372036854775809\n"),
    # negating int64 min overflows into a big.Int through every route
    ("(0 - 9223372036854775807 - 1) | -.", "9223372036854775808\n"),
    ("(0 - 9223372036854775807 - 1) * -1", "9223372036854775808\n"),
    ("(0 - 9223372036854775807 - 1) / -1", "9223372036854775808\n"),
])
def test_bigint_and_overflow_arithmetic(tmp_path, query, expected_out):
    """mixed int/float/big.Int operands follow jq's promotion rules.

    A big.Int meets a float64 by widening to float64, while two big.Ints
    stay exact in every operator; int64 overflow promotes to big.Int and
    negating int64 min becomes the positive big.Int 2^63.
    """
    # CATCHES: 1e19 * 1e19 keeps all 39 digits instead of 1e+38, and
    # 9223372036854775807 + 1 does not wrap around to a negative int
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("10000000000000000000 / 0",
     "gojq: cannot divide number (10000000000000000000) by: number (0)\n"),
    ("10000000000000000000 % 0",
     "gojq: cannot modulo number (10000000000000000000) by: number (0)\n"),
    ("10000000000000000000 + \"a\"",
     'gojq: cannot add: number (10000000000000000000) and string ("a")\n'),
    ("10000000000000000000 + [1]",
     "gojq: cannot add: number (10000000000000000000) and array ([1])\n"),
    ("10000000000000000000 - [1]",
     "gojq: cannot subtract: number (10000000000000000000) and array ([1])\n"),
    ("10000000000000000000 % \"x\"",
     'gojq: cannot modulo: number (10000000000000000000) and string ("x")\n'),
])
def test_bigint_operator_errors(tmp_path, query, expected_err):
    """big-Int operands produce the standard operator error previews.

    Division and modulo by zero use the ``cannot divide ... by:`` wording
    (with a colon after "divide"/"modulo"), unlike the "and" wording of
    every other operator type error.
    """
    # CATCHES: the big value is previewed in full, never as 1e+19
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    ("1 + 1 | +.", "2\n"),
    ("1.5 as $x | +$x", "1.5\n"),
    ("+1", "1\n"),
])
def test_unary_plus(tmp_path, query, expected_out):
    """unary plus is the identity on numbers of every width.

    A literal operand like ``+1`` is folded away by the parser, so the
    runtime identity only shows up on computed or bound values.
    """
    # CATCHES: "+." keeps int and float values unchanged instead of erroring
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ('"a" | +.', 'gojq: cannot plus: string ("a")\n'),
    ("[] | +.", "gojq: cannot plus: array ([])\n"),
])
def test_unary_plus_type_errors(tmp_path, query, expected_err):
    """unary plus rejects non-numbers with a "plus" error."""
    # CATCHES: the error verb is "plus", not "add" or "negate"
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,stdin,expected_out", [
    ("+.", "5", "5\n"),
    ("[., -.]", "3\n4", "[3,-3]\n[4,-4]\n"),
    (". + 1", "5", "6\n"),
    (". + 1", "10000000000000000000", "10000000000000000001\n"),
    (". * 2", "10000000000000000000", "20000000000000000000\n"),
])
def test_json_number_input_arithmetic(tmp_path, query, stdin, expected_out):
    """numbers read from input are json.Number until an operator touches them.

    Arithmetic normalizes them (exact for big integers), but the values
    keep their original spelling until then.
    """
    # CATCHES: 10000000000000000000 from input stays exact through + and *,
    # proving input numbers are not parsed to float64 on the way in
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    # negation is a string operation on the unparsed input number
    ("-.", "5", "-5\n"),
    ("-.", "-5", "5\n"),
    ("-.", "0.5", "-0.5\n"),
    ("-.", "1e308", "-1e308\n"),
    # out-of-range literals are negated textually, never clamped to 1.797e308
    ("-.", "1e1000", "-1e1000\n"),
])
def test_unary_minus_on_input_numbers(tmp_path, query, stdin, expected_out):
    """negating an input number flips the sign of its literal text.

    Input numbers survive as json.Number, so ``-.`` prefixes or strips a
    "-" instead of computing; 1e1000 negates to -1e1000 (not the float64
    infinity clamp) because no numeric conversion happens.
    """
    # CATCHES: -1e1000 is echoed textually instead of becoming -1.797e308
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ("5 * -1", "-5\n"),
    ("1 / -1", "-1\n"),
    ("5 % -1", "0\n"),
    ("4 / 2", "2\n"),
    ("6 / 3", "2\n"),
    ("5.5 % 2", "1\n"),
])
def test_division_modulo_special_operands(tmp_path, query, expected_out):
    """divide/modulo special-case -1, 0 and exact division.

    Multiplying or dividing by -1 routes through the negation helper (so
    int64 min would widen to big.Int), x % -1 is 0 and exact integer
    division stays integer.
    """
    # CATCHES: 4 / 2 is the integer 2, not 2.0, and 5 % -1 is 0 not 5
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ("1.5 / 0.0", "gojq: cannot divide number (1.5) by: number (0)\n"),
    ("1.5 / 0", "gojq: cannot divide number (1.5) by: number (0)\n"),
    ("5.5 % 0.5", "gojq: cannot modulo number (5.5) by: number (0.5)\n"),
])
def test_float_division_modulo_by_zero(tmp_path, query, expected_err):
    """float division/modulo by a zero-valued operand is an error.

    A fractional modulus like 0.5 truncates to the integer zero before the
    check, and the error preview shows the original 0.5, not the truncation.
    """
    # CATCHES: 5.5 % 0.5 reports the operand as 0.5, unlike 5.5 % 0
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


@pytest.mark.parametrize("query,expected_out", [
    ('"a,b,c" / ","', '["a","b","c"]\n'),
    ('"abc" / ""', '["a","b","c"]\n'),
    ('"ab" * 3', '"ababab"\n'),
    ('"ab" * 3.9', '"ababab"\n'),
    ('"ab" * -1', "null\n"),
])
def test_string_division_and_repetition(tmp_path, query, expected_out):
    """string / string splits, and string * number repeats.

    Splitting by the empty string explodes into single characters;
    repetition truncates the count toward zero and a negative count
    produces null (no error).
    """
    # CATCHES: "abc" / "" gives per-character strings, and "ab" * -1 is
    # null rather than an error or the empty string
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ("[] + [1,2]", "[1,2]\n"),
    ("[1,2] + []", "[1,2]\n"),
    ('{} + {"a":1}', '{"a":1}\n'),
    ('{"a":1} + {}', '{"a":1}\n'),
    ("{} * {}", "{}\n"),
])
def test_empty_container_operands(tmp_path, query, expected_out):
    """adding an empty array/object returns the other side unchanged.

    The shortcuts apply on either side of ``+`` (including both-empty for
    ``*``, where objects deep-merge).
    """
    # CATCHES: [] + [1,2] returns the right array itself, not a copy that
    # would differ for object identity-sensitive operations
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_err", [
    ('"a" - "b"', 'gojq: cannot subtract: string ("a") and string ("b")\n'),
    ("{} - {}", "gojq: cannot subtract: object ({}) and object ({})\n"),
    ('[] - "a"', 'gojq: cannot subtract: array ([]) and string ("a")\n'),
    ('"abc" - "b"', 'gojq: cannot subtract: string ("abc") and string ("b")\n'),
    ("[] * []", "gojq: cannot multiply: array ([]) and array ([])\n"),
    ('"a" * "b"', 'gojq: cannot multiply: string ("a") and string ("b")\n'),
    ("[] % []", "gojq: cannot modulo: array ([]) and array ([])\n"),
    ("{} % {}", "gojq: cannot modulo: object ({}) and object ({})\n"),
    ('"a" % "b"', 'gojq: cannot modulo: string ("a") and string ("b")\n'),
    ("[] / []", "gojq: cannot divide: array ([]) and array ([])\n"),
    ("{} / {}", "gojq: cannot divide: object ({}) and object ({})\n"),
])
def test_operator_type_error_matrix(tmp_path, query, expected_err):
    """every operator names both operand types and previews in its error.

    Subtraction only accepts numbers and arrays; multiplication only
    numbers, strings and objects; division only numbers and strings; modulo
    only numbers.  Each error quotes the operator verb and both operands.
    """
    # CATCHES: each verb matches its operator ("modulo", not "mod") and the
    # operand order in the message is left-then-right
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5
