"""Black-box CLI test helpers for the gojq reference binary (test_reuse module).

Every test in this suite drives the reference implementation exclusively
through its command line interface, mirroring behaviors mined from the
repository's native Go test suite (``cli/test.yaml``, ``cli/inputs_test.go``,
``cli/error_test.go`` and the library ``*_test.go`` files).

The child process environment is fully pinned so host settings (``NO_COLOR``,
``GOJQ_COLORS``, ``TERM``, ``TZ``, ``HOME``) cannot change the recorded
behavior, and every run happens inside the test's ``tmp_path``.
"""

import os
import subprocess

#: Per-run timeout: the whole suite must stay well under the harness budget.
TIMEOUT_SECONDS = 10

#: Minimal, deterministic environment for the child process.  ``HOME`` is
#: filled in per run with the test's ``tmp_path`` so that the default
#: ``~/.jq`` module search path never resolves to a real file.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "TZ": "UTC",
    "NO_COLOR": "",
    "GOJQ_COLORS": "",
}


def _child_env(home, extra):
    """Build the pinned child environment, merging case-specific overrides."""
    env = dict(BASE_ENV)
    if home is not None:
        env["HOME"] = str(home)
    env.update(extra or {})
    # Coverage instrumentation hook: the pipeline rebuilds the reference with
    # ``go build -cover`` and points ``GOCOVERDIR`` at a counter directory.
    # Pass the variable through so reference-source coverage is measured.
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env.update({"GOCOVERDIR": value})
    return env


class RunResult:
    """Decoded stdout/stderr/exit-code triple of one reference binary run."""

    __slots__ = ("rc", "out", "err")

    def __init__(self, proc):
        self.rc = proc.returncode
        self.out = proc.stdout.decode("utf-8", errors="surrogateescape")
        self.err = proc.stderr.decode("utf-8", errors="surrogateescape")


def run_gojq(args, stdin="", tmp_path=None, files=None, env=None,
             timeout=TIMEOUT_SECONDS):
    """Run the reference gojq binary as a black box and decode its output.

    :param args:     CLI arguments; numbers are converted with ``str()``.
    :param stdin:    text (or bytes) fed to the child's standard input.
    :param tmp_path: working directory (and ``HOME``) for the child process.
    :param files:    mapping of relative path -> text/bytes written under
                     ``tmp_path`` before the child starts.
    :param env:      extra environment variables overriding the pinned base.
    :returns:        :class:`RunResult` with ``rc``, ``out`` and ``err``.
    """
    if tmp_path is not None:
        for rel, content in (files or {}).items():
            target = tmp_path / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(
                content.encode("utf-8") if isinstance(content, str) else content)
    argv = [os.environ["PROGRAMGYM_EXECUTABLE"]] + [str(a) for a in args]
    proc = subprocess.run(
        argv,
        input=stdin.encode("utf-8") if isinstance(stdin, str) else stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(tmp_path) if tmp_path is not None else None,
        env=_child_env(tmp_path, env),
        timeout=timeout,
    )
    return RunResult(proc)
