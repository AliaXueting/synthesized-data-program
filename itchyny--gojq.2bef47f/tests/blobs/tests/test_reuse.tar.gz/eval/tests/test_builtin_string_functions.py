"""String builtins of func.go: trimming, case, explode/implode, split, join,
the regex family (test/match/capture/scan/splits/sub/gsub) and JSON text
conversion.

Rewritten from the native ``cli/test.yaml`` string-function cases
(``ltrimstr function``, ``rtrimstr function``, ``trimstr function``,
``ltrim/rtrim function``, ``startswith/endswith function``, ``explode
function``, ``implode function``, ``split/1 function``, ``split/2
function``, ``splits function``, ``join function``, ``match function``,
``sub function``, ``gsub function``, ``tonumber function``,
``tostring function``).  Expected values recorded from the reference
binary.
"""

import pytest

from conftest import run_gojq

TRIM_STDIN = '""\n"fo"\n"foo"\n"fooo"\n"barfoo"\n'


@pytest.mark.parametrize("query,expected_out", [
    ('ltrimstr("foo")', '""\n"fo"\n""\n"o"\n"barfoo"\n'),
    ('rtrimstr("foo")', '""\n"fo"\n""\n"fooo"\n"bar"\n'),
])
def test_ltrimstr_rtrimstr(tmp_path, query, expected_out):
    """ltrimstr/rtrimstr strip one exact prefix/suffix, not all of them.

    From ``cli/test.yaml``: 'ltrimstr function' and 'rtrimstr function'
    (""/fo/foo/fooo/barfoo against the literal "foo").
    """
    # CATCHES: ltrimstr("foo") only removes one match, "fooo" -> "o"
    res = run_gojq(["-c", query], stdin=TRIM_STDIN, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_trimstr(tmp_path):
    """trimstr removes one prefix and one suffix around the middle.

    From ``cli/test.yaml``: 'trimstr function' (""/fo/foo/fofoo/
    foobarfoo/foofoofoo against "foo").
    """
    # CATCHES: "foofoofoo" -> "foo": one pass from each side, no loop
    res = run_gojq(["-c", 'trimstr("foo")'],
                   stdin='""\n"fo"\n"foo"\n"fofoo"\n"foobarfoo"\n'
                         '"foofoofoo"\n',
                   tmp_path=tmp_path)
    assert res.out == '""\n"fo"\n""\n"fo"\n"bar"\n"foo"\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ('try ("x" | ltrimstr({})) catch .',
     '"ltrimstr({}) cannot be applied to: string (\\"x\\")"\n'),
    ('try (10 | ltrimstr("x")) catch .',
     '"ltrimstr(\\"x\\") cannot be applied to: number (10)"\n'),
    ('try ("x" | rtrimstr(1)) catch .',
     '"rtrimstr(1) cannot be applied to: string (\\"x\\")"\n'),
    ('try (10 | trimstr("x")) catch .',
     '"trimstr(\\"x\\") cannot be applied to: number (10)"\n'),
])
def test_trimstr_family_type_errors(tmp_path, query, expected_out):
    """the trim family requires a string input and a string argument.

    From ``cli/test.yaml``: 'ltrimstr function error', 'rtrimstr
    function error', 'trimstr function error'.
    """
    # CATCHES: both the input type and the argument type are checked
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_startswith_endswith(tmp_path):
    """startswith/endswith test exact literal edges, prefixes exclusive.

    From ``cli/test.yaml``: 'startswith function' and 'endswith
    function'.
    """
    # CATCHES: "fooo" starts with but does not end with "foo"
    res = run_gojq(["-c", 'startswith("fo"), endswith("foo")'],
                   stdin=TRIM_STDIN, tmp_path=tmp_path)
    assert res.out == \
        "false\nfalse\ntrue\nfalse\ntrue\ntrue\ntrue\nfalse\nfalse\ntrue\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ('try ("x" | startswith(1)) catch .',
     '"startswith(1) cannot be applied to: string (\\"x\\")"\n'),
    ('try ("x" | endswith({})) catch .',
     '"endswith({}) cannot be applied to: string (\\"x\\")"\n'),
    ('try (10 | startswith("x")) catch .',
     '"startswith(\\"x\\") cannot be applied to: number (10)"\n'),
])
def test_startswith_endswith_type_errors(tmp_path, query, expected_out):
    """startswith/endswith reject non-string input and argument.

    From ``cli/test.yaml``: 'startswith function error' and 'endswith
    function error'.
    """
    # CATCHES: argument type is checked even when input is valid
    res = run_gojq(["-c", query], stdin="null", tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_ascii_downcase_upcase(tmp_path):
    """ascii case conversion only touches ASCII letters.

    From ``cli/test.yaml``: 'ascii_downcase function' and
    'ascii_upcase function'.
    """
    # CATCHES: symbols and Greek letters pass through unchanged
    res = run_gojq(["-c", "ascii_downcase, ascii_upcase"],
                   stdin='"@ABC XYZ[] `abc xyz{} Αα"\n',
                   tmp_path=tmp_path)
    assert res.out == ('"@abc xyz[] `abc xyz{} Αα"\n'
                       '"@ABC XYZ[] `ABC XYZ{} Αα"\n')
    assert res.err == ""
    assert res.rc == 0


def test_explode(tmp_path):
    """explode maps each string to its Unicode code points."""
    # CATCHES: multibyte chars become single big code points, not bytes
    res = run_gojq(["-c", "explode"],
                   stdin='""\n"foo"\n"АБВ"\n"\U0001F600"\n',
                   tmp_path=tmp_path)
    assert res.out == "[]\n[102,111,111]\n[1040,1041,1042]\n[128512]\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("stdin,expected_out", [
    ("[]\n[102, 111, 111]\n[128512]\n",
     '""\n"foo"\n"\U0001F600"\n'),
    # out-of-range code points turn into U+FFFD and a literal \u0000
    ("[-1, 0, 1114111, 1114112]",
     '"\ufffd\\u0000\U0010ffff\ufffd"\n'),
])
def test_implode(tmp_path, stdin, expected_out):
    """implode turns code points back into a string, clamping invalid.

    From ``cli/test.yaml``: 'implode function' and 'implode function
    replacement character'.
    """
    # CATCHES: code point 0 renders as a six-char escape, not raw NUL
    res = run_gojq(["-c", "implode"], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("stdin,expected_out", [
    ("[[]]", '"implode cannot be applied to: array ([[]])"\n'),
    ("[{}]", '"implode cannot be applied to: array ([{}])"\n'),
])
def test_implode_type_errors(tmp_path, stdin, expected_out):
    """implode requires an array of numbers, not nested containers."""
    # CATCHES: nested arrays/objects are reported with full previews
    res = run_gojq(["-c", "try implode catch ."], stdin=stdin,
                   tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_split_literal_matrix(tmp_path):
    """split/1 splits on a literal separator for every string/sep pair.

    From ``cli/test.yaml``: 'split/1 function' (the 4x4 matrix of
    {"abc","a","b",""} as input and separator).
    """
    # CATCHES: splitting "" by "" gives []; splitting "abc" by "" gives []
    res = run_gojq(["-c", ".[] as $t | .[] as $s | $s | split($t)"],
                   stdin='["abc", "a", "b", ""]\n', tmp_path=tmp_path)
    assert res.out == ('["",""]\n["a"]\n["b"]\n[]\n'
                       '["","bc"]\n["",""]\n["b"]\n[]\n'
                       '["a","c"]\n["a"]\n["",""]\n[]\n'
                       '["a","b","c"]\n["a"]\n["b"]\n[]\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    # split/2 compiles the separator as a regex unless flags are empty
    ('split("a"), split("a+"), split("a+"; ""), split("a+"; "i"), '
     'split(""; "")', '"abaacaAad"',
     '["","b","","c","A","d"]\n["abaacaAad"]\n["","b","c","A","d"]\n'
     '["","b","c","d"]\n'
     '["","a","b","a","a","c","a","A","a","d",""]\n'),
    # splits/1 and splits/2 stream the same pieces split/2 produces
    ('[splits("a")], [splits("a+")], [splits("a+"; "")], '
     '[splits("a+"; "i")], [splits(""; "")]', '"abaacaAad"',
     '["","b","","c","A","d"]\n["","b","c","A","d"]\n["","b","c","A","d"]\n'
     '["","b","c","d"]\n'
     '["","a","b","a","a","c","a","A","a","d",""]\n'),
    ('[splits("\\\\s*")]', '"a1b-c d"',
     '["","a","1","b","-","c","","d",""]\n'),
])
def test_split_and_splits_regex(tmp_path, query, stdin, expected_out):
    """split/2 and splits treat the pattern as regex unless flags are "".

    From ``cli/test.yaml``: 'split/2 function' and 'splits function'
    (against "abaacaAad" and "a1b-c d").
    """
    # CATCHES: empty flags switch the separator back to literal mode
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('try split(",") catch .', "1\n",
     '"split(\\",\\") cannot be applied to: number (1)"\n'),
    ('try split(1) catch .', '"a"\n',
     '"split(1) cannot be applied to: string (\\"a\\")"\n'),
])
def test_split_type_errors(tmp_path, query, stdin, expected_out):
    """split requires a string input and a string separator."""
    # CATCHES: both argument positions produce their own error message
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out,expected_err,expected_rc", [
    ('join(null)', '["a", "b"]\n', '"ab"\n', "", 0),
    # nested array aborts the run after the earlier inputs succeeded
    ('join(",")',
     '[]\n["a", 1, null, true, [1,{"a":2}]]\n["a,b", null, "c\\"d"]\n',
     '""\n"a,b,,c\\"d"\n',
     'gojq: cannot add: string ("a,1,,true,") and array ([1,{"a":2}])\n', 5),
])
def test_join(tmp_path, query, stdin, expected_out, expected_err,
              expected_rc):
    """join flattens one level: nulls vanish, scalars stringify.

    From ``cli/test.yaml``: 'join function null separator', 'join
    function null elements' and the mixed-input 'join function' case.
    """
    # CATCHES: null separator concatenates with nothing at all
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == expected_err
    assert res.rc == expected_rc


@pytest.mark.parametrize("stdin,expected_out", [
    ("null\n0\n{}\n",
     '"join(\\",\\") cannot be applied to: null"\n'
     '"join(\\",\\") cannot be applied to: number (0)"\n'
     '""\n'),
    ("[1, [2]]\n",
     '"cannot add: string (\\"1,\\") and array ([2])"\n'),
    ('[{"a":1}]\n',
     '"cannot add: string (\\"\\") and object ({\\"a\\":1})"\n'),
])
def test_join_type_and_item_errors(tmp_path, stdin, expected_out):
    """join errors name the offending input or the non-scalar element.

    From ``cli/test.yaml``: 'join function error input' and 'join
    function error item'.  Objects join their values without error.
    """
    # CATCHES: {} joins to "" while null/0 are rejected as inputs
    res = run_gojq(["-c", 'try join(",") catch .'], stdin=stdin,
                   tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_regex_test(tmp_path):
    """test/2 answers substring presence with optional flag set."""
    # CATCHES: "i" flag makes the match case-insensitive
    res = run_gojq(
        ["-c", '[test("xyz"), test("bcd"), test("efg"), '
               'test("efg"; "i"), test("☆★")]'],
        stdin='"abcde☆★abcde☆★ABCDEFG"', tmp_path=tmp_path)
    assert res.out == "[false,true,false,true,true]\n"
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,expected_out", [
    ('[match("bcd")], [match("☆★"; "g")], '
     '(("","g","i","ig") as $flag | [match("bcd"; $flag)])',
     '[{"captures":[],"length":3,"offset":1,"string":"bcd"}]\n'
     '[{"captures":[],"length":2,"offset":5,"string":"☆★"},'
     '{"captures":[],"length":2,"offset":12,"string":"☆★"}]\n'
     '[{"captures":[],"length":3,"offset":1,"string":"bcd"}]\n'
     '[{"captures":[],"length":3,"offset":1,"string":"bcd"},'
     '{"captures":[],"length":3,"offset":8,"string":"bcd"}]\n'
     '[{"captures":[],"length":3,"offset":1,"string":"bcd"}]\n'
     '[{"captures":[],"length":3,"offset":1,"string":"bcd"},'
     '{"captures":[],"length":3,"offset":8,"string":"bcd"},'
     '{"captures":[],"length":3,"offset":15,"string":"BCD"}]\n'),
    ('[match("ABC.?D.?E"; "mg")], [match("A(?<bar>B(C)(.?D))(?<foo>.?E)")], '
     '[match("b(?<foo>c)(d)"; "igm")]',
     '[{"captures":[],"length":5,"offset":14,"string":"ABCDE"},'
     '{"captures":[],"length":7,"offset":20,"string":"ABC\\nD\\nE"}]\n'
     '[{"captures":[{"length":3,"name":"bar","offset":15,"string":"BCD"},'
     '{"length":1,"name":null,"offset":16,"string":"C"},'
     '{"length":1,"name":null,"offset":17,"string":"D"},'
     '{"length":1,"name":"foo","offset":18,"string":"E"}],'
     '"length":5,"offset":14,"string":"ABCDE"}]\n'
     '[{"captures":[{"length":1,"name":"foo","offset":2,"string":"c"},'
     '{"length":1,"name":null,"offset":3,"string":"d"}],'
     '"length":3,"offset":1,"string":"bcd"},'
     '{"captures":[{"length":1,"name":"foo","offset":9,"string":"c"},'
     '{"length":1,"name":null,"offset":10,"string":"d"}],'
     '"length":3,"offset":8,"string":"bcd"},'
     '{"captures":[{"length":1,"name":"foo","offset":16,"string":"C"},'
     '{"length":1,"name":null,"offset":17,"string":"D"}],'
     '"length":3,"offset":15,"string":"BCD"}]\n'),
    # unmatched optional groups report offset -1 and null string
    ('[match("bc(c(.*))?d")]',
     '[{"captures":[{"length":0,"name":null,"offset":-1,"string":null},'
     '{"length":0,"name":null,"offset":-1,"string":null}],'
     '"length":3,"offset":1,"string":"bcd"}]\n'),
])
def test_regex_match_objects(tmp_path, query, expected_out):
    """match emits offset/length/string and a captures array.

    From ``cli/test.yaml``: 'match function' (offsets count code points,
    "m" lets ^ and . cross newlines, named and anonymous groups are
    interleaved in order).
    """
    # CATCHES: offsets are code-point based; unmatched groups use -1/null
    res = run_gojq(["-c", query],
                   stdin='"abcde☆★abcde☆★ABCDE☆ABC\\nD\\nE"',
                   tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_regex_capture(tmp_path):
    """capture collects named groups into an object per match."""
    # CATCHES: a match without named groups yields the empty object
    res = run_gojq(
        ["-c", 'capture("bcd"), capture("b(?<foo>c.?(?<bar>d..))"), '
               '[capture("(?<a>b(?<foo>c).?(?<bar>d..))"; "gmi")]'],
        stdin='"abcdeABCDEabcde"', tmp_path=tmp_path)
    assert res.out == ('{}\n'
                       '{"bar":"deA","foo":"cdeA"}\n'
                       '[{"a":"bcdeA","bar":"deA","foo":"c"},'
                       '{"a":"BCDEa","bar":"DEa","foo":"C"}]\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_out", [
    ('[match("a*"; "g").offset]', '"a1b-c d"', "[0,1,2,3,4,5,6,7]\n"),
    ('[scan("[a-z]*")], gsub("[0-9]*"; "#"), split("-*"; "")',
     '"a1b-c d"',
     '["a","","b","","c","","d",""]\n"#a##b#-#c# #d#"\n'
     '["","a","1","b","","c"," ","d",""]\n'),
    ('[scan("(x)?a*")], [match("(a|)"; "g") | [.offset, '
     '.captures[0].offset]], [scan("[^a]*"; "i")]', '"1a-A"',
     '[[null],[null],[null],[null],[null]]\n'
     '[[0,0],[1,1],[2,2],[3,3],[4,4]]\n'
     '["1","","-","",""]\n'),
    # multibyte input: offsets still count code points, not bytes
    ('[scan("[☆★]*")], [match("[☆★]*"; "g").offset], '
     'gsub("[☆★]*"; "#")', '"☆★1☆★"',
     '["☆★","","☆★",""]\n[0,2,3,5]\n"##1##"\n'),
])
def test_regex_empty_matches(tmp_path, query, stdin, expected_out):
    """zero-width matches appear at every position for g-flag patterns.

    From ``cli/test.yaml``: 'match function with empty matches',
    '... and captures', '... against multibyte characters'.
    """
    # CATCHES: empty matches at every boundary; failed groups capture null
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_err", [
    ('match("x"; "g")', "{}",
     'gojq: match("x"; "g") cannot be applied to: object ({})\n'),
    ('match("x"; "a")', '""',
     'gojq: unsupported regular expression flag: "a"\n'),
    ('match("["; "g")', '""',
     'gojq: invalid regular expression "[": error parsing regexp: '
     'missing closing ]: `[`\n'),
])
def test_regex_match_errors(tmp_path, query, stdin, expected_err):
    """regex input, flag and pattern errors each get their own message.

    From ``cli/test.yaml``: 'match function type error', '... flag
    error', '... regular expression error'.
    """
    # CATCHES: Go regexp syntax errors surface verbatim after "invalid"
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


def test_sub(tmp_path):
    """sub replaces the first match; the replacement may be a stream.

    From ``cli/test.yaml``: 'sub function' (multiple replacement values
    fan out, named groups interpolate with \\(.name), anchors match).
    """
    # CATCHES: sub with empty replacement deletes the match once only
    res = run_gojq(
        ["-c", 'sub("a"; "b"), sub("aaa"; "b"), sub("a"; "b","c"), '
               'sub("a(?<a>.)"; "\\(.a)b\\(.a)"; "ig"), '
               'sub("(?<foo>★)"; "\\(.foo)☆\\(.foo)"), '
               'sub("^"; "b"), sub("a"; empty)'],
        stdin='"abc☆★☆ABC"', tmp_path=tmp_path)
    assert res.out == ('"bbc☆★☆ABC"\n"abc☆★☆ABC"\n"bbc☆★☆ABC"\n'
                       '"cbc☆★☆ABC"\n"bbbc☆★☆BbBC"\n"abc☆★☆★☆ABC"\n'
                       '"babc☆★☆ABC"\n"abc☆★☆ABC"\n')
    assert res.err == ""
    assert res.rc == 0


def test_gsub(tmp_path):
    """gsub replaces every match, with stream and interpolation support.

    From ``cli/test.yaml``: 'gsub function'.
    """
    # CATCHES: gsub with empty replacement copies the input unchanged
    res = run_gojq(
        ["-c", 'gsub("a"; "b"), gsub("a.c"; "b"), gsub("a"; "b","c"), '
               'gsub("a(?<a>..)"; "\\(.a+.a)"; "i"), '
               'gsub("(?<foo>★)"; "\\(.foo)☆\\(.foo)"), '
               'gsub("^"; "a"), gsub("a"; empty)'],
        stdin='"abcABC☆★☆ABCabc"', tmp_path=tmp_path)
    assert res.out == ('"bbcABC☆★☆ABCbbc"\n"bABC☆★☆ABCb"\n'
                       '"bbcABC☆★☆ABCbbc"\n"cbcABC☆★☆ABCcbc"\n'
                       '"bcbcBCBC☆★☆BCBCbcbc"\n"abcABC☆★☆★☆ABCabc"\n'
                       '"aabcABC☆★☆ABCabc"\n"abcABC☆★☆ABCabc"\n')
    assert res.err == ""
    assert res.rc == 0


def test_gsub_anchors_and_boundaries(tmp_path):
    """gsub honors ^/$ anchors and \\b word boundaries per match."""
    # CATCHES: (?m) makes ^ match after every newline like Go regexp
    res = run_gojq(
        ["-c", 'gsub("(?m)^a*"; "#"), gsub("\\\\ba*"; "#"), '
               'gsub("(^|-)a*"; "#"), gsub("[a-z]*\\\\b"; "#")'],
        stdin='"a-a b"', tmp_path=tmp_path)
    assert res.out == '"#-a b"\n"##-## #b#"\n"## b"\n"##-## ##"\n'
    assert res.err == ""
    assert res.rc == 0


def test_tojson(tmp_path):
    """tojson renders any value as its compact JSON encoding."""
    # CATCHES: strings get double-escaped, quotes included
    res = run_gojq(["-c", "tojson"],
                   stdin='null\nfalse\ntrue\n3.14\n"foo bar"\n'
                         '{"foo": "-43210"}\n[1,2,3]\n["<&><>"]\n',
                   tmp_path=tmp_path)
    assert res.out == ('"null"\n"false"\n"true"\n"3.14"\n'
                       '"\\"foo bar\\""\n"{\\"foo\\":\\"-43210\\"}"\n'
                       '"[1,2,3]"\n"[\\"<&><>\\"]"\n')
    assert res.err == ""
    assert res.rc == 0


def test_fromjson(tmp_path):
    """fromjson parses a JSON text back into a value."""
    # CATCHES: objects re-serialize with keys sorted on output
    res = run_gojq(["-c", "fromjson"],
                   stdin='"1"\n"{\\"a\\": 1}"\n"[1, 2]"\n"\\"str\\""\n'
                         '"true"\n"null"\n',
                   tmp_path=tmp_path)
    assert res.out == '1\n{"a":1}\n[1,2]\n"str"\ntrue\nnull\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_err", [
    ("fromjson", '"{"',
     'gojq: fromjson cannot be applied to "{": unexpected EOF\n'),
])
def test_fromjson_invalid_json(tmp_path, query, stdin, expected_err):
    """fromjson reports the offending text and the parse failure."""
    # CATCHES: the invalid literal is echoed inside the message
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


def test_fromjson_type_error(tmp_path):
    """fromjson rejects non-string inputs."""
    # CATCHES: numbers are not auto-coerced to strings
    res = run_gojq(["-c", "try fromjson catch ."], stdin="1\n",
                   tmp_path=tmp_path)
    assert res.out == '"fromjson cannot be applied to: number (1)"\n'
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("flags,query,expected_out", [
    # -r prints the trimmed strings raw; only leading whitespace goes
    ("-r", "ltrim", "foo\n  \nx\u3000\ny \xa0\n"),
    ("-r", "rtrim", "  \tfoo\n\u3000x\n\xa0 y\n"),
    ("-r", "trim", "foo\nx\ny\n"),
])
def test_trim_whitespace_functions_raw(tmp_path, flags, query,
                                       expected_out):
    """ltrim/rtrim/trim strip Unicode whitespace from one side or both.

    From ``cli/test.yaml``: 'ltrim function', 'rtrim function' — the
    whitespace set includes U+3000 and U+00A0 and strips the whole run,
    not one character.
    """
    # CATCHES: trim removes full leading/trailing runs incl. U+3000
    res = run_gojq([flags, query],
                   stdin='"  \\tfoo\\n  "\n"\\u3000x\\u3000"\n'
                         '"\\u00a0 y \\u00a0"\n',
                   tmp_path=tmp_path)
    assert res.out == expected_out
    assert res.err == ""
    assert res.rc == 0


def test_trim_whitespace_functions_json(tmp_path):
    """the trim family passes strings through JSON-escaped unchanged."""
    # CATCHES: interior whitespace (including \n) is preserved
    res = run_gojq(["-c", "ltrim, rtrim, trim"],
                   stdin='"  \\tfoo\\n  "\n"\\u3000x\\u3000"\n',
                   tmp_path=tmp_path)
    assert res.out == ('"foo\\n  "\n"  \\tfoo"\n"foo"\n'
                       '"x\u3000"\n"\u3000x"\n"x"\n')
    assert res.err == ""
    assert res.rc == 0


@pytest.mark.parametrize("query,stdin,expected_err", [
    ("ltrim", "1\n", "gojq: ltrim cannot be applied to: number (1)\n"),
    ("trim", "{}\n", "gojq: trim cannot be applied to: object ({})\n"),
])
def test_trim_whitespace_type_errors(tmp_path, query, stdin, expected_err):
    """ltrim/rtrim/trim only accept strings."""
    # CATCHES: func0TypeError wording: "cannot be applied to: <value>"
    res = run_gojq(["-c", query], stdin=stdin, tmp_path=tmp_path)
    assert res.out == ""
    assert res.err == expected_err
    assert res.rc == 5


def test_trim_whitespace_catchable_type_error(tmp_path):
    """rtrim type errors are catchable like every value error."""
    # CATCHES: catching converts the message into a string value
    res = run_gojq(["-c", "try rtrim catch ."], stdin="[]\n",
                   tmp_path=tmp_path)
    assert res.out == '"rtrim cannot be applied to: array ([])"\n'
    assert res.err == ""
    assert res.rc == 0
