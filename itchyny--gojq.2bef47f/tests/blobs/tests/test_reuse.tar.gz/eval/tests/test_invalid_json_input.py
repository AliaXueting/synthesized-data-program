"""Invalid JSON input handling: error format, line numbers, partial output.

Rewritten from the native suite ``cli/test.yaml`` "invalid json" cases and
``cli/inputs_test.go`` (``TestJSONInputIter`` and the buffered-input
retention cases), which pin the caret placement and the ``<line> | `` echo
format used for multi-line inputs.
"""

import pytest

from conftest import run_gojq


@pytest.mark.parametrize("stdin,expected_err", [
    ("{", "gojq: invalid json: <stdin>\n    {\n     ^  unexpected EOF\n"),
    ("{ \"１２３４５\":",
     "gojq: invalid json: <stdin>\n    { \"１２３４５\":\n"
     "                   ^  unexpected EOF\n"),
])
def test_unexpected_eof_errors(tmp_path, stdin, expected_err):
    """Unterminated JSON on stdin fails with exit code 5 and a caret.

    Native cases "invalid json unexpected eof error" and its multibyte
    variant: the caret is placed one past the end of the echoed input, and
    the input name is reported as ``<stdin>``.
    """
    # CATCHES: caret column counts multibyte chars as width 1, input named <stdin>
    res = run_gojq([], stdin=stdin, tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == expected_err


@pytest.mark.parametrize("stdin,expected_err", [
    ("[0\n,[\n",
     "gojq: invalid json: <stdin>:2\n    2 | ,[\n"
     "          ^  unexpected EOF\n"),
    ("{\n  \"１２３４５\" 100\n}\n",
     "gojq: invalid json: <stdin>:2\n    2 |   \"１２３４５\" 100\n"
     "                       ^  invalid character '1' after object key\n"),
])
def test_parse_error_line_number_format(tmp_path, stdin, expected_err):
    r"""Errors past line 1 echo ``<line> | <text>`` with the line number.

    Native cases "invalid json unexpected eof error with multiple lines" and
    "invalid json invalid character with multibyte characters": once the
    error is not on line 1, the echo is prefixed by the line number and the
    caret column is measured in runes (the multibyte key occupies 5 columns).
    """
    # CATCHES: line-numbered echo format "<line> | text" for errors after line 1
    res = run_gojq([], stdin=stdin, tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == expected_err


def test_invalid_string_literal_error(tmp_path):
    r"""A broken null literal reports the offending byte and expectation.

    Native case "invalid json string literal": parsing ``n`` inside an
    object value reports ``invalid character '\n' in literal null
    (expecting 'u')`` — the raw newline is quoted in the message.
    """
    # CATCHES: message names the expected 'u' continuation of literal null
    res = run_gojq([], stdin='{\n  "１２３": n\n}\n', tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == ""
    assert res.err == ("gojq: invalid json: <stdin>:2\n"
                       "    2 |   \"１２３\": n\n"
                       "                     ^  invalid character '\\n' "
                       "in literal null (expecting 'u')\n")


def test_error_line_at_large_offset(tmp_path):
    """Values parsed before the error are printed, then the error follows.

    From ``inputs_test.go`` "large input with unexpected EOF error" and
    "large input with object key error": an error 40 KiB into the input
    still reports the exact line number (40961) and the correct echo line,
    and any complete values parsed earlier are emitted on stdout first.
    """
    # CATCHES: line counter survives 40 KiB of buffered input (reports 40961)
    res = run_gojq(["-c", "."], stdin="0[0," + "\n" * 40960 + "1\n",
                   tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == "0\n"
    assert res.err == ("gojq: invalid json: <stdin>:40961\n"
                       "    40961 | 1\n"
                       "             ^  unexpected EOF\n")

    res = run_gojq(["-c", "."], stdin='0{"a"' + "\n" * 40960 + ":0,1}",
                   tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == "0\n"
    assert res.err == ("gojq: invalid json: <stdin>:40961\n"
                       "    40961 | :0,1}\n"
                       "               ^  invalid character '1' looking for "
                       "beginning of object key string\n")


def test_many_values_then_error(tmp_path):
    """Every valid value before the error is still written to stdout.

    From ``inputs_test.go`` "many input values with value error": 40960
    ``0`` values parse fine, then ``:`` fails; all values are printed and
    the process exits 5 with the error on stderr.
    """
    # CATCHES: 40960 valid values are all emitted before the parse error
    res = run_gojq(["-c", "."], stdin="0\n" * 40960 + ":\n", tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == "0\n" * 40960
    assert res.err == ("gojq: invalid json: <stdin>:40961\n"
                       "    40961 | :\n"
                       "            ^  invalid character ':' looking for "
                       "beginning of value\n")


def test_error_context_retained_after_large_value(tmp_path):
    """A huge value before an error does not corrupt the echoed line.

    From ``inputs_test.go`` ``TestJSONInputIterRetainsBufferedInput``: a
    20 KiB string followed by an invalid escape still reports line 2 with
    the short offending text, not a truncated buffer.
    """
    # CATCHES: 20 KiB value must not evict the error line from the buffer
    res = run_gojq(["-c", "."], stdin='"' + "a" * 20480 + '"\n"\\q"\n',
                   tmp_path=tmp_path)
    assert res.rc == 5
    assert res.out == '"' + "a" * 20480 + '"\n'
    assert res.err == ('gojq: invalid json: <stdin>:2\n'
                       '    2 | "\\q"\n'
                       "          ^  invalid character 'q' in string escape "
                       "code\n")
