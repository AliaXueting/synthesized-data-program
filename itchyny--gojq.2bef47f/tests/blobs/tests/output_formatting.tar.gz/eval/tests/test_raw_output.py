"""Tests for raw and delimited output: -r, -j, --raw-output0.

Pins which value kinds -r unquotes, that non-string values still render
as (pretty) JSON, the absence of any delimiter under -j, the NUL
delimiter of --raw-output0, its NUL-in-string error and how that error
aborts the rest of one input's outputs but not later inputs.
"""

import pytest


@pytest.mark.parametrize("value,expected", [
    ('"hello"', "hello\n"),
    ('"line1\\nline2"', "line1\nline2\n"),
    ('""', "\n"),
    ("42", "42\n"),
    ("null", "null\n"),
    ("true", "true\n"),
    ("false", "false\n"),
])
def test_raw_output_unquotes_strings(run_gojq, value, expected):
    """-r prints strings raw and other values as JSON."""
    # CATCHES: only top-level strings are unquoted; numbers, booleans and
    # null keep their JSON spelling, and embedded newlines stay literal.
    proc = run_gojq(["-r", "."], input_text=value)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_raw_output_keeps_pretty_json(run_gojq):
    """Under -r, non-string values still pretty-print with two spaces."""
    # CATCHES: -r only changes the top-level string case; the JSON
    # encoder (including --indent) is untouched for other values.
    proc = run_gojq(["-r", "."], input_text='{"a":[1,{"b":2}]}')
    assert proc.returncode == 0
    assert proc.stdout == '{\n  "a": [\n    1,\n    {\n      "b": 2\n    }\n  ]\n}\n'
    assert proc.stderr == ""


def test_raw_output_with_indent(run_gojq):
    """--indent applies to the JSON values emitted under -r."""
    # CATCHES: the raw and indent flags are independent; a re-implementation
    # that makes -r imply compact output would lose the indentation.
    proc = run_gojq(["-r", "--indent", "1", "."], input_text='{"a":1}')
    assert proc.returncode == 0
    assert proc.stdout == '{\n "a": 1\n}\n'
    assert proc.stderr == ""


def test_raw_output_with_compact(run_gojq):
    """-r -c compacts the JSON values while strings stay raw."""
    # CATCHES: -c and -r combine; the compact encoder is used for every
    # non-string value while top-level strings lose their quotes.
    proc = run_gojq(["-r", "-c", "."], input_text='{"a":[1,{"b":2}]}')
    assert proc.returncode == 0
    assert proc.stdout == '{"a":[1,{"b":2}]}\n'
    assert proc.stderr == ""


def test_join_output_no_delimiter(run_gojq):
    """-j emits every value with no separator at all, not even a newline."""
    # CATCHES: -j implies -r for strings and drops the newline after each
    # output, so the three values concatenate into one line.
    proc = run_gojq(["-j", "."], input_text='"a"\n"b"\n1\n[2]\n')
    assert proc.returncode == 0
    assert proc.stdout == "ab1[\n  2\n]"
    assert proc.stderr == ""


def test_join_output_object_still_pretty(run_gojq):
    """Under -j a JSON object prints pretty but without a trailing newline."""
    # CATCHES: -j only removes the record delimiter, not the pretty
    # printing; the output ends with '}' and no newline.
    proc = run_gojq(["-j", "."], input_text='{"a":1}')
    assert proc.returncode == 0
    assert proc.stdout == '{\n  "a": 1\n}'
    assert proc.stderr == ""


def test_join_output_allows_nul_in_strings(run_gojq_bytes):
    """-j happily writes strings containing NUL bytes."""
    # CATCHES: the NUL check exists only for --raw-output0, so -j copies
    # the NUL through instead of failing like --raw-output0 does.
    proc = run_gojq_bytes(["-j", '"a\\u0000b"'], input_bytes=b"null")
    assert proc.returncode == 0
    assert proc.stdout == b"a\x00b"
    assert proc.stderr == b""


def test_join_combined_short_flags(run_gojq):
    """-rj in one argument behaves like -r -j."""
    # CATCHES: gojq bundles short flags; a parser treating -rj as one
    # unknown flag would exit 2 instead of joining the raw strings.
    proc = run_gojq(["-rj", "."], input_text='"a"\n"b"\n')
    assert proc.returncode == 0
    assert proc.stdout == "ab"
    assert proc.stderr == ""


def test_raw_output0_nul_delimiter(run_gojq_bytes):
    """--raw-output0 terminates every output with a NUL byte."""
    # CATCHES: strings are unquoted (it implies -r) and the delimiter is
    # \\x00, so consumers can split on NUL even when values contain
    # newlines.
    proc = run_gojq_bytes(["--raw-output0", "."],
                          input_bytes=b'"a"\n"b"\n')
    assert proc.returncode == 0
    assert proc.stdout == b"a\x00b\x00"
    assert proc.stderr == b""


def test_raw_output0_non_string_values(run_gojq_bytes):
    """--raw-output0 renders non-strings as pretty JSON plus NUL."""
    # CATCHES: the NUL delimiter replaces the newline for every value
    # kind, while the JSON body keeps its pretty shape.
    proc = run_gojq_bytes(["--raw-output0", "."],
                          input_bytes=b'1\n{"a":2}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'1\x00{\n  "a": 2\n}\x00'
    assert proc.stderr == b""


def test_raw_output0_empty_string(run_gojq_bytes):
    """An empty string under --raw-output0 outputs just the NUL byte."""
    # CATCHES: the delimiter is written even when the value itself is
    # empty, so the record count stays visible in the byte stream.
    proc = run_gojq_bytes(["--raw-output0", "."], input_bytes=b'""')
    assert proc.returncode == 0
    assert proc.stdout == b"\x00"
    assert proc.stderr == b""


def test_raw_output0_with_compact(run_gojq_bytes):
    """--raw-output0 and -c combine into compact JSON plus NUL."""
    # CATCHES: the flags are independent; compacting must not change the
    # NUL record delimiter.
    proc = run_gojq_bytes(["--raw-output0", "-c", "."],
                          input_bytes=b'{"a":2}')
    assert proc.returncode == 0
    assert proc.stdout == b'{"a":2}\x00'
    assert proc.stderr == b""


def test_raw_output0_wins_over_join(run_gojq_bytes):
    """-j --raw-output0 uses the NUL delimiter, not nothing."""
    # CATCHES: --raw-output0 takes the delimiter branch before -j is
    # consulted, in either flag order.
    for args in (["-j", "--raw-output0"], ["--raw-output0", "-j"]):
        proc = run_gojq_bytes([*args, "."], input_bytes=b'"a"\n"b"\n')
        assert proc.returncode == 0
        assert proc.stdout == b"a\x00b\x00"
        assert proc.stderr == b""


def test_raw_output0_nul_string_error(run_gojq):
    """A string containing NUL under --raw-output0 fails with exit 5."""
    # CATCHES: the error message Go-quotes the offending string (so the
    # NUL appears as the escape text \\x00) and nothing reaches stdout.
    proc = run_gojq(["--raw-output0", '"a\\u0000b"'], input_text="null")
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == (
        'gojq: cannot output a string containing NUL character: "a\\x00b"\n'
    )


def test_raw_output0_midstream_error(run_gojq_bytes):
    """The NUL error aborts the remaining outputs of that input."""
    # CATCHES: outputs already written stay ("a" plus its NUL), but the
    # sibling outputs after the failing one are skipped entirely.
    proc = run_gojq_bytes(
        ["--raw-output0", '"a", "x\\u0000y", "b"'], input_bytes=b"null")
    assert proc.returncode == 5
    assert proc.stdout == b"a\x00"
    assert proc.stderr == (
        b'gojq: cannot output a string containing NUL character: "x\\x00y"\n'
    )


def test_raw_output0_error_does_not_stop_next_input(run_gojq_bytes):
    """After a NUL error, later input values are still processed."""
    # CATCHES: the error only ends the current input's output iteration;
    # the second input value "c" is still marshaled and NUL-terminated.
    proc = run_gojq_bytes(["--raw-output0", "."],
                          input_bytes=b'"a\\u0000b"\n"c"\n')
    assert proc.returncode == 5
    assert proc.stdout == b"c\x00"
    assert proc.stderr == (
        b'gojq: cannot output a string containing NUL character: "a\\x00b"\n'
    )


def test_compact_string_with_nul(run_gojq):
    """Without --raw-output0, a NUL inside a string is just escaped."""
    # CATCHES: ordinary JSON output escapes the NUL as \\u0000 rather
    # than erroring; only the NUL-delimited stream forbids it.
    proc = run_gojq(["-c", '"a\\u0000b"'], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == '"a\\u0000b"\n'
    assert proc.stderr == ""
