"""Tests for colorized output and the GOJQ_COLORS configuration.

Pins the default SGR palette for all eight slots, that colors are off
when stdout is piped, the -C/-M precedence over each other and over the
NO_COLOR/TERM environment, the colon-separated GOJQ_COLORS slot syntax
(empty slots disable, invalid slots error), and how colors interleave
with indentation, raw output, debug and stderr.
"""

import pytest

ESC = "\x1b["

# The default palette: null=90, false=33, true=33, numbers=36,
# strings=32, object keys=34;1, arrays and objects uncolored.
DEFAULT_COMPACT = (
    "{"
    + ESC + '34;1m"k"' + ESC + "0m"
    + ":["
    + ESC + "90mnull" + ESC + "0m"
    + ","
    + ESC + "33mfalse" + ESC + "0m"
    + ","
    + ESC + "33mtrue" + ESC + "0m"
    + ","
    + ESC + "36m1" + ESC + "0m"
    + ","
    + ESC + '32m"s"' + ESC + "0m"
    + ",{}],"
    + ESC + '34;1m"s"' + ESC + "0m"
    + ":"
    + ESC + '32m"str"' + ESC + "0m"
    + "}\n"
)


def test_piped_stdout_disables_color_by_default(run_gojq):
    """With no flags and stdout piped, output carries no ANSI escapes."""
    # CATCHES: color auto-detection is tty-based; a re-implementation
    # that colors by default (or honors TERM only) would emit escapes.
    proc = run_gojq(["-c", "."], input_text='{"k":[null,1,"s"]}')
    assert proc.returncode == 0
    assert proc.stdout == '{"k":[null,1,"s"]}\n'
    assert ESC not in proc.stdout
    assert proc.stderr == ""


def test_color_flag_default_palette(run_gojq):
    """-C colors every value kind with the documented default palette."""
    # CATCHES: the defaults are 90:33:33:36:32:34;1 with arrays and
    # objects left uncolored, so brackets and commas stay plain.
    proc = run_gojq(["-C", "-c", "."],
                    input_text='{"k":[null,false,true,1,"s",{}],"s":"str"}')
    assert proc.returncode == 0
    assert proc.stdout == DEFAULT_COMPACT
    assert proc.stderr == ""


def test_color_long_flag(run_gojq):
    """--color-output is the long spelling of -C."""
    # CATCHES: a flag table missing the long spelling would reject it
    # with an unknown-flag error instead of colorizing.
    proc = run_gojq(["--color-output", "-c", "."], input_text='[null,1]')
    assert proc.returncode == 0
    assert proc.stdout == "[" + ESC + "90mnull" + ESC + "0m," \
           + ESC + "36m1" + ESC + "0m]\n"
    assert proc.stderr == ""


def test_color_pretty_interleaves_with_indent(run_gojq):
    """Pretty-printed color output puts newlines and indent outside spans."""
    # CATCHES: the indent run and the newline are not part of any color
    # span; each value is wrapped separately from the whitespace.
    proc = run_gojq(["-C", "."], input_text='{"a":[1]}')
    assert proc.returncode == 0
    assert proc.stdout == (
        "{\n  " + ESC + '34;1m"a"' + ESC + "0m: [\n    "
        + ESC + "36m1" + ESC + "0m\n  ]\n}\n"
    )
    assert proc.stderr == ""


@pytest.mark.parametrize("args,indent", [
    (["--tab"], "\t"),
    (["--indent", "3"], "   "),
])
def test_color_with_tab_and_indent(run_gojq, args, indent):
    """-C composes with --tab and --indent indentation."""
    # CATCHES: colors must not change the indentation characters; the
    # escape sequences wrap only the key and the value.
    proc = run_gojq(["-C", *args, "."], input_text='{"a":[1]}')
    assert proc.returncode == 0
    assert proc.stdout == (
        "{\n" + indent + ESC + '34;1m"a"' + ESC + "0m: [\n"
        + indent * 2 + ESC + "36m1" + ESC + "0m\n"
        + indent + "]\n}\n"
    )
    assert proc.stderr == ""


def test_color_with_indent_zero(run_gojq):
    """-C with --indent 0 keeps the newline-per-element layout."""
    # CATCHES: the color spans must survive the zero-indent layout where
    # the only whitespace is the newline and the space after ':'.
    proc = run_gojq(["-C", "--indent", "0", "."], input_text='{"a":[1]}')
    assert proc.returncode == 0
    assert proc.stdout == (
        "{\n" + ESC + '34;1m"a"' + ESC + "0m: [\n"
        + ESC + "36m1" + ESC + "0m\n]\n}\n"
    )
    assert proc.stderr == ""


@pytest.mark.parametrize("args", [["-C", "-M"], ["-M", "-C"], ["-CM"], ["-MC"]])
def test_monochrome_wins_over_color(run_gojq, args):
    """-M disables colors even when -C is also given, in any order."""
    # CATCHES: the precedence is fixed (monochrome wins); a re-implementation
    # letting the last flag win would color for ["-C", "-M"].
    proc = run_gojq([*args, "."], input_text='[null,1,"s"]')
    assert proc.returncode == 0
    assert proc.stdout == '[\n  null,\n  1,\n  "s"\n]\n'
    assert ESC not in proc.stdout
    assert proc.stderr == ""


def test_monochrome_long_flag(run_gojq):
    """--monochrome-output is the long spelling of -M."""
    # CATCHES: the long spelling must exist and must override -C.
    proc = run_gojq(["--monochrome-output", "-C", "."], input_text="1")
    assert proc.returncode == 0
    assert proc.stdout == "1\n"
    assert proc.stderr == ""


@pytest.mark.parametrize("env", [
    {"NO_COLOR": "1"},
    {"NO_COLOR": ""},
    {"TERM": "dumb"},
])
def test_color_flag_ignores_color_environment(run_gojq, env):
    """-C forces colors on regardless of NO_COLOR and TERM=dumb."""
    # CATCHES: the environment only matters when neither -C nor -M is
    # given; the explicit flag takes precedence over both variables.
    proc = run_gojq(["-C", "-c", "."], input_text="1", env=env)
    assert proc.returncode == 0
    assert proc.stdout == ESC + "36m1" + ESC + "0m\n"
    assert proc.stderr == ""


def test_gojq_colors_eight_slots(run_gojq):
    """GOJQ_COLORS assigns all eight slots including arrays and objects."""
    # CATCHES: slots seven and eight color the brackets, commas and
    # colons of arrays and objects, which have no color by default.
    proc = run_gojq(["-C", "-c", "."], input_text='{"a":[null,true]}',
                    env={"GOJQ_COLORS": "31:32:33:34:35:36:37:38"})
    assert proc.returncode == 0
    assert proc.stdout == (
        ESC + "38m{" + ESC + "0m"
        + ESC + '36m"a"' + ESC + "0m"
        + ESC + "38m:" + ESC + "0m"
        + ESC + "37m[" + ESC + "0m"
        + ESC + "31mnull" + ESC + "0m"
        + ESC + "37m," + ESC + "0m"
        + ESC + "33mtrue" + ESC + "0m"
        + ESC + "37m]" + ESC + "0m"
        + ESC + "38m}" + ESC + "0m\n"
    )
    assert proc.stderr == ""


def test_gojq_colors_partial_disables_remaining_slots(run_gojq):
    """Specifying fewer slots turns every unspecified slot off."""
    # CATCHES: GOJQ_COLORS is not a prefix override — the missing slots
    # are set to "no color" rather than keeping their defaults.
    proc = run_gojq(["-C", "-c", "."], input_text='[null,1,"s",true]',
                    env={"GOJQ_COLORS": "31"})
    assert proc.returncode == 0
    assert proc.stdout == "[" + ESC + "31mnull" + ESC + "0m,1,\"s\",true]\n"
    assert proc.stderr == ""


def test_gojq_colors_all_empty_disables_everything(run_gojq):
    """Eight empty slots disable coloring completely, even with -C."""
    # CATCHES: an empty slot means "no color", so '::::::' turns every
    # slot off while the flag still requests colors.
    proc = run_gojq(["-C", "-c", "."], input_text="[null,1]",
                    env={"GOJQ_COLORS": "::::::"})
    assert proc.returncode == 0
    assert proc.stdout == "[null,1]\n"
    assert proc.stderr == ""


def test_gojq_colors_empty_value_is_unset(run_gojq):
    """GOJQ_COLORS set to the empty string behaves like unset."""
    # CATCHES: only a non-empty value is parsed, so the default palette
    # stays active.
    proc = run_gojq(["-C", "-c", "."], input_text="[null]",
                    env={"GOJQ_COLORS": ""})
    assert proc.returncode == 0
    assert proc.stdout == "[" + ESC + "90mnull" + ESC + "0m]\n"
    assert proc.stderr == ""


def test_gojq_colors_reset_code_is_a_valid_color(run_gojq):
    """Slot value 0 produces the reset sequence as the color itself."""
    # CATCHES: validColor accepts any digit run, including "0", so the
    # null slot can be set to the reset escape itself.
    proc = run_gojq(["-C", "-c", "."], input_text="[null]",
                    env={"GOJQ_COLORS": "0"})
    assert proc.returncode == 0
    assert proc.stdout == "[" + ESC + "0mnull" + ESC + "0m]\n"
    assert proc.stderr == ""


@pytest.mark.parametrize("color", ["3;1", "1;31;42", "31;32", "90", "4;1"])
def test_gojq_colors_multi_parameter_values(run_gojq, color):
    """Semicolon-separated SGR parameter lists are accepted verbatim."""
    # CATCHES: the value is spliced into "\\x1b[<value>m" without
    # validation beyond digits and semicolons.
    proc = run_gojq(["-C", "-c", "."], input_text="null",
                    env={"GOJQ_COLORS": color})
    assert proc.returncode == 0
    assert proc.stdout == ESC + color + "mnull" + ESC + "0m\n"
    assert proc.stderr == ""


def test_gojq_colors_extra_slots_ignored(run_gojq):
    """More than eight slots: the ninth and later are ignored."""
    # CATCHES: the parser consumes exactly eight slots; a ninth value
    # must not turn into an error or shift the slot mapping.
    proc = run_gojq(["-C", "-c", "."], input_text="[null]",
                    env={"GOJQ_COLORS": "91:92:93:94:95:96:97:98:99"})
    assert proc.returncode == 0
    assert proc.stdout == (
        ESC + "97m[" + ESC + "0m" + ESC + "91mnull" + ESC + "0m"
        + ESC + "97m]" + ESC + "0m\n"
    )
    assert proc.stderr == ""


@pytest.mark.parametrize("colors", ["x", "31;", ";31", "3a1", "31:32:x:34"])
def test_gojq_colors_invalid_values_error(run_gojq, colors):
    """An invalid slot value fails with an exact message and exit 5."""
    # CATCHES: values must be digits separated by semicolons; a trailing
    # or leading semicolon is invalid, and the first bad slot is named.
    proc = run_gojq(["-C", "."], input_text="null",
                    env={"GOJQ_COLORS": colors})
    assert proc.returncode == 5
    assert proc.stdout == ""
    bad = colors.split(":")[2] if colors.startswith("31:32:") else colors
    assert proc.stderr == 'gojq: invalid color: "%s"\n' % bad


@pytest.mark.parametrize("args", [
    ["-c", "."],
    ["-M", "-c", "."],
    ["-M", "-C", "-c", "."],
])
def test_gojq_colors_ignored_when_colors_disabled(run_gojq, args):
    """GOJQ_COLORS is not even parsed when colors are off."""
    # CATCHES: with piped stdout (or -M), an invalid GOJQ_COLORS value
    # must not produce an error; only -C activates the parsing.
    proc = run_gojq(args, input_text="[1]", env={"GOJQ_COLORS": "bogus"})
    assert proc.returncode == 0
    assert proc.stdout == "[1]\n"
    assert proc.stderr == ""


def test_gojq_colors_error_precedes_indent_error(run_gojq):
    """An invalid color is reported before an out-of-range --indent."""
    # CATCHES: the color configuration is validated before the indent
    # count, so the color error wins when both are wrong.
    proc = run_gojq(["-C", "--indent", "10", "."], input_text="null",
                    env={"GOJQ_COLORS": "x"})
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == 'gojq: invalid color: "x"\n'


def test_color_raw_output_strings_uncolored(run_gojq):
    """With -r, raw strings carry no escapes but other values stay colored."""
    # CATCHES: -r writes the string bytes directly, bypassing the color
    # wrapper, while numbers still get their color span.
    proc = run_gojq(["-C", "-r", "."], input_text='"s"')
    assert proc.returncode == 0
    assert proc.stdout == "s\n"
    assert proc.stderr == ""
    proc = run_gojq(["-C", "-r", "."], input_text="1")
    assert proc.returncode == 0
    assert proc.stdout == ESC + "36m1" + ESC + "0m\n"
    assert proc.stderr == ""


def test_color_join_and_raw0(run_gojq):
    """-C composes with -j and --raw-output0 delimiters."""
    # CATCHES: the color span precedes the delimiter byte; for
    # --raw-output0 the record ends with the reset sequence then NUL.
    proc = run_gojq(["-C", "-j", "."], input_text='{"a":1}')
    assert proc.returncode == 0
    assert proc.stdout == ("{\n  " + ESC + '34;1m"a"' + ESC + "0m: "
                           + ESC + "36m1" + ESC + "0m\n}")
    assert proc.stderr == ""
    proc = run_gojq(["-C", "--raw-output0", "."], input_text="1")
    assert proc.returncode == 0
    assert proc.stdout == ESC + "36m1" + ESC + "0m\x00"


def test_color_debug_output(run_gojq):
    """debug's stderr line is compact and colorized when -C is active."""
    # CATCHES: debug uses its own compact encoder but the same palette,
    # so both streams are colored by one flag.
    proc = run_gojq(["-C", "debug"], input_text='{"a":1}')
    assert proc.returncode == 0
    assert proc.stdout == "{\n  " + ESC + '34;1m"a"' + ESC + "0m: " \
           + ESC + "36m1" + ESC + "0m\n}\n"
    assert proc.stderr == ("[" + ESC + '32m"DEBUG:"' + ESC + "0m,{"
                           + ESC + '34;1m"a"' + ESC + "0m:"
                           + ESC + "36m1" + ESC + "0m}]\n")


def test_color_monochrome_debug(run_gojq):
    """-M -C keeps both stdout and the debug line plain."""
    # CATCHES: monochrome wins for the debug encoder as well, not just
    # for the main output stream.
    proc = run_gojq(["-C", "-M", "debug"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "null\n"
    assert proc.stderr == '["DEBUG:",null]\n'


def test_color_gojq_colors_debug(run_gojq):
    """GOJQ_COLORS restyles the debug line on stderr."""
    # CATCHES: the palette is shared, so slot five (strings) recolors
    # the "DEBUG:" label while empty slots drop the other colors.
    proc = run_gojq(["-C", "debug"], input_text='{"a":1}',
                    env={"GOJQ_COLORS": "91::::94"})
    assert proc.returncode == 0
    assert proc.stderr == ("[" + ESC + '94m"DEBUG:"' + ESC + "0m,"
                           '{"a":1}]\n')


def test_color_stderr_builtin(run_gojq):
    """The stderr builtin's output is colorized like stdout values."""
    # CATCHES: stderr writes compact JSON with colors for non-strings,
    # and raw uncolored bytes for strings.
    proc = run_gojq(["-C", "stderr"], input_text="[1]")
    assert proc.returncode == 0
    assert proc.stdout == "[\n  " + ESC + "36m1" + ESC + "0m\n]\n"
    assert proc.stderr == "[" + ESC + "36m1" + ESC + "0m]"
    proc = run_gojq(["-C", '"raw" | stderr'], input_text="null")
    assert proc.returncode == 0
    assert proc.stderr == "raw"


def test_yaml_output_has_no_colors(run_gojq):
    """--yaml-output never emits ANSI escapes, even with -C."""
    # CATCHES: the YAML marshaler replaces the colored JSON encoder
    # entirely, so forcing color has no visible effect.
    proc = run_gojq(["--yaml-output", "-C", "."], input_text='{"a":1}')
    assert proc.returncode == 0
    assert proc.stdout == "a: 1\n"
    assert ESC not in proc.stdout
    assert proc.stderr == ""
