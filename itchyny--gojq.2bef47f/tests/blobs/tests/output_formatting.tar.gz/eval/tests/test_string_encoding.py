"""Tests for jq-flavored string encoding in output.

Pins the escape table (\\", \\\\, \\b, \\f, \\n, \\r, \\t, \\u00xx for
other control bytes and DEL), the absence of HTML escaping, raw UTF-8
passthrough for non-ASCII text, the \\ufffd replacement for invalid
UTF-8 bytes, and surrogate handling in JSON input.
"""

import pytest

# Control bytes below 0x20 that have no named escape, plus 0x7f; all of
# them must appear as \u00xx escapes.
CONTROL_BYTES = [b for b in range(0x00, 0x20)
                 if b not in (0x08, 0x09, 0x0A, 0x0C, 0x0D)] + [0x7F]


@pytest.mark.parametrize("byte", CONTROL_BYTES)
def test_control_bytes_escaped(run_gojq, byte):
    """Control bytes without a named escape render as lowercase \\u00xx."""
    # CATCHES: the named escapes only cover \\b\\f\\n\\r\\t; every other
    # byte below 0x20 (and DEL at 0x7f) uses a four-digit hex escape.
    proc = run_gojq(["."], input_text='"\\u%04x"' % byte)
    assert proc.returncode == 0
    assert proc.stdout == '"\\u%04x"\n' % byte
    assert proc.stderr == ""


def test_named_escapes_table(run_gojq):
    """Quote, backslash and the five named escapes render exactly."""
    # CATCHES: jq uses \\b and \\f; a re-implementation following a
    # different convention might emit \\u0008 or \\u000c instead.
    proc = run_gojq(["-c", '["a\\"b", "c\\\\d", "e\\bf", "g\\fh", "i\\nj",'
                             ' "k\\rl", "m\\tn"]'],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == '["a\\"b","c\\\\d","e\\bf","g\\fh","i\\nj","k\\rl","m\\tn"]\n'
    assert proc.stderr == ""


def test_printable_ascii_needs_no_escaping(run_gojq):
    """Printable ASCII from space to tilde passes through unchanged."""
    # CATCHES: the printable range ends at 0x7e; only " and \\ are
    # special inside it, so every other character stays raw.
    proc = run_gojq(["."],
                    input_text='" !\\"#$%&\'()*+,-./0123456789:;<=>?@'
                               'ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\\\]^_`'
                               'abcdefghijklmnopqrstuvwxyz{|}~"')
    assert proc.returncode == 0
    assert proc.stdout == (
        '" !\\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        '[\\\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"\n'
    )
    assert proc.stderr == ""


def test_no_html_escaping(run_gojq):
    """Angle brackets and ampersands are not escaped, unlike Go json."""
    # CATCHES: encoding/json escapes < > & by default; gojq must not, so
    # the output is not HTML-safe even though quotes are still escaped.
    proc = run_gojq(["-c", '"<&>\\"a\\"<b>&amp;"'], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == '"<&>\\"a\\"<b>&amp;"\n'
    assert proc.stderr == ""


def test_multibyte_unicode_passthrough(run_gojq):
    """Non-ASCII text passes through as raw UTF-8, including emoji."""
    # CATCHES: U+2028/U+2029 that Go's encoding/json escapes must stay
    # raw here, and a BOM is not turned into an escape either.
    proc = run_gojq(
        ["-c", '["\u00e9\u65e5\u672c\u8a9e\U0001f389",'
               ' "\ufeff", "\u2028\u2029", "\u0085"]'],
        input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == (
        '["\u00e9\u65e5\u672c\u8a9e\U0001f389",'
        '"\ufeff","\u2028\u2029","\u0085"]\n')
    assert proc.stderr == ""


def test_invalid_utf8_input_bytes_replaced(run_gojq_bytes):
    """Invalid UTF-8 bytes read as raw input become \\ufffd escapes."""
    # CATCHES: the encoder writes the six characters \\ufffd for each
    # invalid byte instead of copying the byte through or erroring.
    proc = run_gojq_bytes(["-R", "-c", "."], input_bytes=b"a\xff\xfeb")
    assert proc.returncode == 0
    assert proc.stdout == b'"a\\ufffd\\ufffdb"\n'
    assert proc.stderr == b""


def test_invalid_utf8_in_raw_join_output(run_gojq_bytes):
    """Raw output of an invalid-UTF-8 string copies the bytes verbatim."""
    # CATCHES: -j bypasses JSON string encoding, so the invalid byte
    # reaches stdout unchanged rather than being replaced.
    proc = run_gojq_bytes(["-R", "-j", "."], input_bytes=b"a\xffb")
    assert proc.returncode == 0
    assert proc.stdout == b"a\xffb"
    assert proc.stderr == b""


def test_json_input_surrogate_pair(run_gojq_bytes):
    """A JSON \\ud83d\\ude00 pair decodes to the emoji code point."""
    # CATCHES: the JSON decoder combines surrogate pairs, so the output
    # is the four UTF-8 bytes of U+1F600, not a replacement character.
    proc = run_gojq_bytes(["."], input_bytes=b'"\\ud83d\\ude00"')
    assert proc.returncode == 0
    assert proc.stdout == b'"\xf0\x9f\x98\x80"\n'
    assert proc.stderr == b""


def test_json_input_lone_surrogate(run_gojq_bytes):
    """A lone \\ud800 in JSON input decodes to U+FFFD."""
    # CATCHES: an unpaired surrogate cannot be encoded as UTF-8, so the
    # decoder substitutes the replacement character, which then prints
    # as its own three UTF-8 bytes (not a \\ufffd escape sequence).
    proc = run_gojq_bytes(["."], input_bytes=b'"\\ud800"')
    assert proc.returncode == 0
    assert proc.stdout == b'"\xef\xbf\xbd"\n'
    assert proc.stderr == b""


def test_object_keys_are_escaped_like_values(run_gojq):
    """Object keys go through the same string encoder as values."""
    # CATCHES: keys containing newlines, quotes or NUL must be escaped
    # (and stay sorted by their raw byte sequence).
    proc = run_gojq(["-c", '{"a\\nb": 1, "c\\"d": 2, "\\u0000k": 3}'],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == '{"\\u0000k":3,"a\\nb":1,"c\\"d":2}\n'
    assert proc.stderr == ""


def test_string_with_del_and_nel(run_gojq):
    """DEL (0x7f) is escaped while NEL (U+0085) is not."""
    # CATCHES: the boundary between escaped and raw sits between the
    # ASCII DEL byte and the first multibyte character; U+0085 starts
    # with the UTF-8 lead byte 0xc2 and therefore passes through raw.
    proc = run_gojq(["-c", '["\\u007f", "\u0085"]'], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == '["\\u007f","\u0085"]\n'
    assert proc.stderr == ""
