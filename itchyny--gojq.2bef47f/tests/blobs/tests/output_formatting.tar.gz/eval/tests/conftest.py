"""Shared helpers for the output_formatting test module.

The program under test is gojq.  These tests pin how computed values are
rendered: the JSON output shape (pretty-printing, -c, --indent, --tab),
jq-flavored number and string encoding, raw/join/NUL-delimited output,
YAML output, ANSI colorization and its GOJQ_COLORS configuration,
stdout/stderr separation, the debug and stderr builtins, and the exit
codes governed by -e, halt and halt_error.
"""

import os
import subprocess

import pytest

# Fully pinned child environment: no inherited locale, color or gojq
# configuration from the test runner.  TERM is deliberately a "smart"
# terminal value so that the only thing disabling colors by default is
# that stdout is a pipe and not a tty.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "xterm",
}


def _gojq_bin():
    """Resolve the reference binary through PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the gojq binary under test"
        )
    return path


def _child_env(env):
    """The pinned child environment plus per-test overrides.

    A ``None`` value removes the variable from the child environment;
    every other value overrides (or adds) it.  GOCOVERDIR is forwarded
    from the test process at call time so the pipeline can measure the
    source coverage of an instrumented reference binary.
    """
    child = dict(CHILD_ENV)
    for key, value in (env or {}).items():
        if value is None:
            child.pop(key, None)
        else:
            child[key] = value
    for key in ("GOCOVERDIR",):
        value = os.environ.get(key)
        if value:
            child[key] = value
    return child


def run_gojq_bytes(args, input_bytes=b"", env=None, cwd=None, timeout=10,
                   merge_stderr=False):
    """Run gojq and capture the raw stdout/stderr bytes.

    ``merge_stderr`` redirects the child's stderr into stdout so a test
    can pin the interleaving order of the two streams.
    """
    if isinstance(input_bytes, str):
        input_bytes = input_bytes.encode("utf-8")
    return subprocess.run(
        [_gojq_bin(), *args],
        input=input_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT if merge_stderr else subprocess.PIPE,
        env=_child_env(env),
        cwd=cwd,
        timeout=timeout,
    )


def _as_text(proc):
    """A CompletedProcess whose streams are decoded as UTF-8 text."""
    stdout = proc.stdout.decode("utf-8")
    stderr = None if proc.stderr is None else proc.stderr.decode("utf-8")
    return subprocess.CompletedProcess(proc.args, proc.returncode, stdout, stderr)


def run_gojq(args, input_text="", env=None, cwd=None, timeout=10,
             merge_stderr=False):
    """Run gojq with UTF-8 text stdin and capture both streams as text."""
    return _as_text(run_gojq_bytes(args, input_text, env, cwd, timeout,
                                   merge_stderr))


@pytest.fixture(name="run_gojq")
def run_gojq_fixture(tmp_path):
    """The text-mode run helper, running inside an isolated empty cwd."""

    def _run(args, input_text="", env=None, timeout=10, merge_stderr=False):
        return run_gojq(args, input_text, env, str(tmp_path), timeout,
                        merge_stderr)

    return _run


@pytest.fixture(name="run_gojq_bytes")
def run_gojq_bytes_fixture(tmp_path):
    """The byte-mode run helper, running inside an isolated empty cwd."""

    def _run(args, input_bytes=b"", env=None, timeout=10, merge_stderr=False):
        return run_gojq_bytes(args, input_bytes, env, str(tmp_path), timeout,
                              merge_stderr)

    return _run
