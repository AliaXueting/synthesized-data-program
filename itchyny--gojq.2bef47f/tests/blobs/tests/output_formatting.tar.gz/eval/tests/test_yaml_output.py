"""Tests for --yaml-output rendering.

Pins the YAML shape of objects, arrays and scalars, the "---"
document separator between successive outputs, YAML's own string
quoting rules (including line wrapping), how --indent maps onto YAML
(and its clamp below 2), and the flags --yaml-output makes inert.
"""

import pytest


def test_yaml_object_shape(run_gojq):
    """Objects render as mappings, sequences as dash items under the key."""
    # CATCHES: go-yaml indents sequence items under their mapping key by
    # the indent width (not flush with the key like jq's -y would).
    proc = run_gojq(["--yaml-output", "."],
                    input_text='{"a":1,"b":[1,2],"c":{"d":"e"},'
                               '"f":null,"g":true,"h":"str"}')
    assert proc.returncode == 0
    assert proc.stdout == ("a: 1\n"
                           "b:\n"
                           "  - 1\n"
                           "  - 2\n"
                           "c:\n"
                           "  d: e\n"
                           "f: null\n"
                           "g: true\n"
                           "h: str\n")
    assert proc.stderr == ""


def test_yaml_document_separators_between_outputs(run_gojq):
    """Successive outputs are separated by a '---' document start line."""
    # CATCHES: the separator appears only between documents (never
    # before the first), for outputs of one query and of several inputs.
    proc = run_gojq(["--yaml-output", "1, 2"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "1\n---\n2\n"
    assert proc.stderr == ""


def test_yaml_separators_across_inputs(run_gojq):
    """Documents from separate input values also get '---' separators."""
    # CATCHES: the separator state persists across input values, so the
    # third input is still preceded by '---'.
    proc = run_gojq(["--yaml-output", "."], input_text="1\n2\n3\n")
    assert proc.returncode == 0
    assert proc.stdout == "1\n---\n2\n---\n3\n"
    assert proc.stderr == ""


@pytest.mark.parametrize("value,expected", [
    ("null", "null\n"),
    ("true", "true\n"),
    ("false", "false\n"),
    ('"str"', "str\n"),
    ("1", "1\n"),
    ("-2", "-2\n"),
    ("1.5", "1.5\n"),
    ("{}", "{}\n"),
    ("[]", "[]\n"),
])
def test_yaml_scalar_documents(run_gojq, value, expected):
    """Each scalar and empty container renders as its own document."""
    # CATCHES: YAML has no quoting for these plain scalars, and empty
    # containers use flow style even though JSON pretty would expand.
    proc = run_gojq(["--yaml-output", "."], input_text=value)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_yaml_string_quoting_table(run_gojq):
    """Strings that look like numbers/bools are quoted, others plain."""
    # CATCHES: YAML picks double quotes for number-like strings, single
    # quotes for indicator-led strings, and plain style otherwise.
    proc = run_gojq(
        ["--yaml-output",
         '["1", "true", "null", "a b", "", "3.5", "- x", "*y", "#z",'
         ' "yes", "on", "@at", "3:30", "[br]", "{cur}", "|pipe", ">gt",'
         ' "-x", "!bang", "&amp", "~til", "null ", "0x10", "1e5"]'],
        input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == (
        '- "1"\n'
        '- "true"\n'
        '- "null"\n'
        '- a b\n'
        '- ""\n'
        '- "3.5"\n'
        "- '- x'\n"
        "- '*y'\n"
        "- '#z'\n"
        "- 'yes'\n"
        "- 'on'\n"
        "- '@at'\n"
        "- '3:30'\n"
        "- '[br]'\n"
        "- '{cur}'\n"
        "- '|pipe'\n"
        "- '>gt'\n"
        "- -x\n"
        "- '!bang'\n"
        "- '&amp'\n"
        "- ~til\n"
        "- 'null '\n"
        '- "0x10"\n'
        '- "1e5"\n')
    assert proc.stderr == ""


def test_yaml_multiline_strings(run_gojq):
    """Embedded newlines become literal block scalars."""
    # CATCHES: a trailing newline selects '|' (clip) while no trailing
    # newline selects '|-' (strip); both indent the block by two.
    proc = run_gojq(["--yaml-output", '"multi\\nline"'], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "|-\n  multi\n  line\n"
    assert proc.stderr == ""
    proc = run_gojq(["--yaml-output", '"line1\\nline2\\n"'], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "|\n  line1\n  line2\n"
    assert proc.stderr == ""


def test_yaml_control_characters_double_quoted(run_gojq):
    """Tabs and control bytes force double-quoted style with escapes."""
    # CATCHES: YAML cannot express tabs/control bytes in plain or single
    # quotes, so it falls back to double quotes using \\t and \\x01.
    proc = run_gojq(["--yaml-output", '["a\\tb", "a\\u0001b"]'],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == '- "a\\tb"\n- "a\\x01b"\n'
    assert proc.stderr == ""


def test_yaml_line_wrapping(run_gojq):
    """Long plain scalars wrap at width 80 with an indented continuation."""
    # CATCHES: the YAML emitter folds lines near 80 columns; a
    # re-implementation without the width limit would print one line.
    proc = run_gojq(
        ["--yaml-output",
         '"aaaaaaaaaa bbbbbbbbbb cccccccccc dddddddddd eeeeeeeeee'
         ' ffffffffff gggggggggg hhhhhhhhhh iiii"'],
        input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == (
        "aaaaaaaaaa bbbbbbbbbb cccccccccc dddddddddd eeeeeeeeee ffffffffff"
        " gggggggggg hhhhhhhhhh\n  iiii\n")
    assert proc.stderr == ""


def test_yaml_mapping_key_quoting(run_gojq):
    """Keys follow the same style rules as plain scalars."""
    # CATCHES: keys with spaces can stay plain ("a b: 1"), but empty,
    # number-like and boolean-like keys must be quoted.
    proc = run_gojq(
        ["--yaml-output",
         '{"a b": 1, "1": 2, "": 3, "yes": 4, "a:b": 5, "a b c": 6}'],
        input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == ('"": 3\n'
                           '"1": 2\n'
                           "a b: 1\n"
                           "a b c: 6\n"
                           "a:b: 5\n"
                           "'yes': 4\n")
    assert proc.stderr == ""


def test_yaml_empty_containers_in_mapping(run_gojq):
    """Empty arrays and objects inside a mapping use flow style."""
    # CATCHES: only non-empty containers get block style; empties stay
    # inline on the key's line.
    proc = run_gojq(["--yaml-output", "."], input_text='{"a":[],"b":{}}')
    assert proc.returncode == 0
    assert proc.stdout == "a: []\nb: {}\n"
    assert proc.stderr == ""


def test_yaml_nested_structures(run_gojq):
    """Nested arrays use compact dash notation at each level."""
    # CATCHES: sequences nested in sequences print "- - 1" without a
    # blank line, and a mapping inside a sequence indents its items.
    proc = run_gojq(["--yaml-output", "."], input_text="[[1,[2]],{\"a\":[[3]]}]")
    assert proc.returncode == 0
    assert proc.stdout == "- - 1\n  - - 2\n- a:\n    - - 3\n"
    assert proc.stderr == ""


@pytest.mark.parametrize("indent,expected", [
    (2, "a:\n  b:\n    - 1\n"),
    (4, "a:\n    b:\n        - 1\n"),
    (9, "a:\n         b:\n                  - 1\n"),
])
def test_yaml_indent_widths(run_gojq, indent, expected):
    """--indent N is applied to YAML mappings and sequence items."""
    # CATCHES: the sequence dash sits at key indent + N, so the item
    # column moves with N and not just the mapping column.
    proc = run_gojq(["--yaml-output", "--indent", str(indent), "."],
                    input_text='{"a":{"b":[1]}}')
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize("indent", ["0", "1"])
def test_yaml_indent_below_two_clamped(run_gojq, indent):
    """--indent 0 and 1 fall back to two-space YAML indentation."""
    # CATCHES: the JSON --indent 0 semantics do not carry into YAML; the
    # emitter clamps any indent below 2 back to 2.
    proc = run_gojq(["--yaml-output", "--indent", indent, "."],
                    input_text='{"a":{"b":[1]}}')
    assert proc.returncode == 0
    assert proc.stdout == "a:\n  b:\n    - 1\n"
    assert proc.stderr == ""


def test_yaml_tab_error(run_gojq):
    """--yaml-output --tab fails with an exact message and exit 5."""
    # CATCHES: YAML forbids tabs for indentation, and the conflict is
    # detected before any output is written.
    proc = run_gojq(["--yaml-output", "--tab", "."], input_text='{"a":1}')
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: cannot use tabs for YAML output\n"


def test_yaml_indent_error_takes_precedence_over_tab_error(run_gojq):
    """An out-of-range --indent is reported before the YAML/tab conflict."""
    # CATCHES: the checks run in a fixed order (indent range, then the
    # YAML/tab combination), which a re-implementation must keep.
    proc = run_gojq(["--yaml-output", "--tab", "--indent", "10", "."],
                    input_text="{}")
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: too many indentation count: 10\n"


@pytest.mark.parametrize("args,stdin,expected", [
    (["-c"], '{"a":[1,2]}', "a:\n  - 1\n  - 2\n"),
    (["-r"], '"x"', "x\n"),
    (["-j"], "1\n2\n", "1\n---\n2\n"),
    (["--raw-output0"], '"a"\n"b"\n', "a\n---\nb\n"),
])
def test_yaml_makes_other_output_flags_inert(run_gojq, args, stdin, expected):
    """--yaml-output overrides -c, -r, -j and --raw-output0 entirely."""
    # CATCHES: the YAML marshaler replaces the JSON one and its own
    # delimiter logic, so none of the raw/compact flags have any effect.
    proc = run_gojq(["--yaml-output", *args, "."], input_text=stdin)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_yaml_numbers(run_gojq):
    """Big integers quote, floats use YAML notation, NaN/Inf get tags."""
    # CATCHES: a big.Int is rendered as a quoted string (YAML has no
    # bignum), 1e-07 keeps its exponent, and nan/infinite become .nan
    # and .inf.
    proc = run_gojq(
        ["--yaml-output",
         "[1, -2, 1.5, 4722366482869645213696, 1e-7, nan, infinite]"],
        input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == ("- 1\n"
                           "- -2\n"
                           "- 1.5\n"
                           '- "4722366482869645213696"\n'
                           "- 1e-07\n"
                           "- .nan\n"
                           "- .inf\n")
    assert proc.stderr == ""
