"""Tests for jq-flavored number encoding in output.

Pins the int/float/big-int distinction, verbatim echo of input number
literals (json.Number), jq's shortest-round-trip float formatting with
its exponent-form thresholds and "e-09" -> "e-9" cleanup, NaN to null
and infinity clamping, and the compact encoding used by tojson.
"""

import pytest

# Input numbers that do not take part in any operation are echoed
# exactly as they were spelled in the input.
VERBATIM_NUMBERS = [
    "1.0",
    "1E5",
    "1e+2",
    "0.100",
    "1.50",
    "-0.0",
    "0.0",
    "-0",
    "1e400",
    # A 401-digit integer, far beyond float64 precision.
    "1" + "0" * 400,
]


@pytest.mark.parametrize("number", VERBATIM_NUMBERS)
def test_input_numbers_echoed_verbatim(run_gojq, number):
    """A number that no operation touches is printed exactly as written."""
    # CATCHES: gojq keeps input number literals as json.Number and prints
    # them digit-for-digit, so "1.0" stays "1.0" instead of becoming 1.
    proc = run_gojq(["."], input_text=number)
    assert proc.returncode == 0
    assert proc.stdout == number + "\n"
    assert proc.stderr == ""


def test_verbatim_numbers_inside_containers(run_gojq):
    """Verbatim number echo also holds inside arrays and objects."""
    # CATCHES: normalization must not sneak in when the number is merely
    # copied into a larger structure being re-encoded.
    proc = run_gojq(["-c", "."], input_text='{"a":1.0,"b":[1e21],"c":0.10}')
    assert proc.returncode == 0
    assert proc.stdout == '{"a":1.0,"b":[1e21],"c":0.10}\n'
    assert proc.stderr == ""


def test_float_formatting_table(run_gojq):
    """Computed float64 values format like jq: shortest round-trip."""
    # CATCHES: exponent form only below 1e-6 or at/above 1e21, otherwise
    # plain decimal, and the shortest representation wins ("1" for 1.0).
    proc = run_gojq(["-c", "[1e-7, 1e-6, 1.5e-6, 1e-7*1, 1e21, 1e20, "
                             "1e100, 1e-100, 1.5e300, 1.0, -0.0, 0.1, "
                             "100.0, 1e7, 1.23e20, 123456789.123456789]"],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == (
        '[1e-7,0.000001,0.0000015,1e-7,1e+21,100000000000000000000,'
        '1e+100,1e-100,1.5e+300,1,-0,0.1,100,10000000,'
        '123000000000000000000,123456789.12345679]\n'
    )
    assert proc.stderr == ""


def test_exponent_cleanup_single_digit(run_gojq):
    """Negative single-digit exponents lose their leading zero."""
    # CATCHES: Go formats 1e-9 as "1e-09"; jq-style output cleans that to
    # "1e-9" while two-digit exponents like 1e-10 keep their zeros.
    proc = run_gojq(["-c", "[1e-7, 1e-8, 1e-9, 1.5e-9, 2e-8, 1e-10]"],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "[1e-7,1e-8,1e-9,1.5e-9,2e-8,1e-10]\n"
    assert proc.stderr == ""


def test_exponent_threshold_boundaries(run_gojq):
    """9.9e-7 is still "0.000001" territory but 1e21 flips to "1e+21"."""
    # CATCHES: the switch to exponent form happens at abs(x) >= 1e21,
    # and 9.999999999999999e20 stays in decimal form.
    proc = run_gojq(["-c", "[1e21, 9.999999999999999e20, 9.9e-7, 1e-6]"],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "[1e+21,999999999999999900000,9.9e-7,0.000001]\n"
    assert proc.stderr == ""


def test_int_and_float_distinction(run_gojq):
    """A float with integral value prints without a decimal point."""
    # CATCHES: once an operation forces float64 arithmetic, 1.0 + 0
    # prints as "1" even though the untouched input "1.0" prints as 1.0.
    proc = run_gojq(["-c", "[1.0 + 0, 1 + 0, 2.0 * 1]"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "[1,1,2]\n"
    assert proc.stderr == ""


def test_big_integers_preserved(run_gojq):
    """Integers beyond int64 keep every digit in output and arithmetic."""
    # CATCHES: values past int64 become arbitrary-precision integers, so
    # 4722366482869645213696 + 1 must not lose its low digits.
    proc = run_gojq(
        ["-c", "[4722366482869645213696, 4722366482869645213696 + 1, "
               "4722366482869645213696 * 2]"],
        input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == (
        "[4722366482869645213696,4722366482869645213697,"
        "9444732965739290427392]\n"
    )
    assert proc.stderr == ""


def test_int64_overflow_promotes_to_big_int(run_gojq):
    """Arithmetic past int64 promotes to big integers in both directions."""
    # CATCHES: adding 1 to the int64 maximum must not wrap around to a
    # negative number, and negating the minimum goes one digit further.
    proc = run_gojq(["-c", "[9223372036854775807 + 1, "
                           "-9223372036854775807 - 2]"],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "[9223372036854775808,-9223372036854775809]\n"
    assert proc.stderr == ""


def test_huge_integer_input_is_big_int(run_gojq):
    """A 401-digit integer survives an operation digit-for-digit."""
    # CATCHES: a decoder that routes huge integers through float64 would
    # print scientific notation instead of the full digits.
    digits = "9" + "8" * 400
    proc = run_gojq(["-c", ".+0"], input_text=digits)
    assert proc.returncode == 0
    assert proc.stdout == digits + "\n"
    assert proc.stderr == ""


def test_out_of_range_float_input_clamped(run_gojq):
    """1e400 from input becomes +Inf, which prints clamped to MaxFloat64."""
    # CATCHES: infinities are clamped to 1.7976931348623157e+308 rather
    # than printed as "Infinity" or an error.
    proc = run_gojq(["-c", ".+0"], input_text="1e400")
    assert proc.returncode == 0
    assert proc.stdout == "1.7976931348623157e+308\n"
    assert proc.stderr == ""


def test_nan_prints_null(run_gojq):
    """NaN prints as null, at top level and inside containers."""
    # CATCHES: jq prints NaN as null; JSON's Infinity/NaN spellings must
    # never leak into the output.
    proc = run_gojq(["-c", "[nan, [nan], {\"a\": nan}, nan]"],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "[null,[null],{\"a\":null},null]\n"
    assert proc.stderr == ""


def test_infinities_clamped(run_gojq):
    """infinite and -infinite print as the clamped max float magnitude."""
    # CATCHES: infinities are clamped to 1.7976931348623157e+308 with the
    # sign preserved, using exponent notation with an explicit plus.
    proc = run_gojq(["-c", "[infinite, -infinite]"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "[1.7976931348623157e+308,-1.7976931348623157e+308]\n"
    assert proc.stderr == ""


def test_tojson_uses_compact_encoding(run_gojq):
    """tojson emits compact, sorted, jq-flavored JSON as a string."""
    # CATCHES: the library marshaler shares the CLI encoding rules: keys
    # sorted, no spaces, NaN as null, big ints exact, floats jq-style.
    proc = run_gojq(
        ["-c", "[nan, infinite, -infinite, 4722366482869645213696, 1e-7, "
               "1e21, \"a\\nb\", {\"b\":1,\"a\":[2,3]}, 1.0] | tojson"],
        input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == (
        '"[null,1.7976931348623157e+308,-1.7976931348623157e+308,'
        '4722366482869645213696,1e-7,1e+21,\\"a\\\\nb\\",'
        '{\\"a\\":[2,3],\\"b\\":1},1]"\n'
    )
    assert proc.stderr == ""


def test_tojson_object_keys_sorted(run_gojq):
    """tojson sorts object keys the same way output does."""
    # CATCHES: the compact library marshaler must also sort keys rather
    # than preserving the map iteration or input order.
    proc = run_gojq(["-c", "tojson"],
                    input_text='{"b":1,"a":[2,3],"z":{"y":1,"x":2}}')
    assert proc.returncode == 0
    assert proc.stdout == '"{\\"a\\":[2,3],\\"b\\":1,\\"z\\":{\\"x\\":2,\\"y\\":1}}"\n'
    assert proc.stderr == ""


def test_tojson_invalid_utf8(run_gojq_bytes):
    """Invalid UTF-8 in a raw-input string becomes \\ufffd in tojson."""
    # CATCHES: the encoder replaces each invalid byte with the \\ufffd
    # escape sequence instead of emitting the raw byte.
    proc = run_gojq_bytes(["-R", "tojson"], input_bytes=b"a\xffb")
    assert proc.returncode == 0
    assert proc.stdout == b'"\\"a\\\\ufffdb\\""\n'
    assert proc.stderr == b""


def test_atjson_format(run_gojq):
    """The @json format string produces the same jq-flavored encoding."""
    # CATCHES: @json must agree with tojson, including key sorting and
    # the compact separator set.
    proc = run_gojq(["@json"], input_text='{"b":1,"a":2}')
    assert proc.returncode == 0
    assert proc.stdout == '"{\\"a\\":2,\\"b\\":1}"\n'
    assert proc.stderr == ""


def test_negative_numbers_output(run_gojq):
    """Negative integers and floats print with a leading minus sign."""
    # CATCHES: the sign comes from the value itself, not a separate
    # formatting step, so -0.0 keeps its sign while -0 does not.
    proc = run_gojq(["-c", "[-1, -1.5, -1e-7, -4722366482869645213696]"],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "[-1,-1.5,-1e-7,-4722366482869645213696]\n"
    assert proc.stderr == ""
