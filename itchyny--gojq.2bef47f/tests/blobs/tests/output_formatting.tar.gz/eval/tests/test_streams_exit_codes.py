"""Tests for stream separation, debug/stderr builtins and exit codes.

Pins which stream each kind of output goes to, the exact format of the
debug and stderr builtins (and their independence from the output
flags), halt and halt_error behavior including their exit codes, and
the -e exit-status mapping (0/1/4) versus the error exit code 5.
"""

import pytest


def test_results_go_to_stdout_errors_to_stderr(run_gojq):
    """A successful run writes only to stdout; a failing one only stderr."""
    # CATCHES: the value stream and the 'gojq: '-prefixed error message
    # must never mix streams, and errors exit with code 5.
    proc = run_gojq(["."], input_text='{"a":1}')
    assert proc.returncode == 0
    assert proc.stdout == '{\n  "a": 1\n}\n'
    assert proc.stderr == ""
    proc = run_gojq(["error(\"x\")"], input_text="1")
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == "gojq: error: x\n"


def test_debug_format(run_gojq):
    """debug writes compact [\"DEBUG:\",v] plus newline to stderr."""
    # CATCHES: the debug line is always compact JSON regardless of the
    # output flags, and the value still flows through to stdout.
    proc = run_gojq(["debug"], input_text='{"a":1}')
    assert proc.returncode == 0
    assert proc.stdout == '{\n  "a": 1\n}\n'
    assert proc.stderr == '["DEBUG:",{"a":1}]\n'


def test_debug_independent_of_indent_flags(run_gojq):
    """--indent and --tab do not change the compact debug line."""
    # CATCHES: debug builds its own encoder with fixed compact settings,
    # so the main output can be tab-indented while debug stays compact.
    proc = run_gojq(["--indent", "4", "--tab", "[1,{\"a\":2}] | debug"],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "[\n\t1,\n\t{\n\t\t\"a\": 2\n\t}\n]\n"
    assert proc.stderr == '["DEBUG:",[1,{"a":2}]]\n'


def test_debug_interleaves_in_order(run_gojq):
    """debug output appears between the surrounding stdout values."""
    # CATCHES: both streams are unbuffered per value, so merging them
    # preserves the emission order deterministically.
    proc = run_gojq(["1, debug, 2"], input_text="null", merge_stderr=True)
    assert proc.returncode == 0
    assert proc.stdout == '1\n["DEBUG:",null]\nnull\n2\n'


@pytest.mark.parametrize("value,expected", [
    ("null", "null"),
    ("42", "42"),
    ('{"e":"x"}', '{"e":"x"}'),
    ('[1,2]', "[1,2]"),
    ("true", "true"),
])
def test_stderr_builtin_json_values(run_gojq, value, expected):
    """stderr writes non-string values as compact JSON with no newline."""
    # CATCHES: unlike the debug builtin there is no trailing newline,
    # and the encoding ignores --indent/--tab entirely.
    proc = run_gojq(["--indent", "4", "%s | stderr" % value],
                    input_text="null")
    assert proc.returncode == 0
    assert proc.stderr == expected


def test_stderr_builtin_string_is_raw(run_gojq):
    """stderr writes strings raw: no quotes, no newline."""
    # CATCHES: strings bypass JSON encoding just like -r, even though
    # the raw flag was never given.
    proc = run_gojq(['"raw" | stderr'], input_text="null")
    assert proc.returncode == 0
    assert proc.stderr == "raw"


def test_stderr_builtin_passes_value_through(run_gojq):
    """The value written by stderr still reaches stdout afterwards."""
    # CATCHES: stderr is not an output-sink; the input value continues
    # through the pipeline, so 'stderr, 1' prints both values.
    proc = run_gojq(["stderr, 1"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "null\n1\n"
    assert proc.stderr == "null"


def test_halt_stops_execution_with_exit_zero(run_gojq):
    """halt stops the whole program; later outputs never appear."""
    # CATCHES: the value 2 after halt is not evaluated and the exit code
    # is 0, not an error code.
    proc = run_gojq(["1, halt, 2"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "1\n"
    assert proc.stderr == ""


@pytest.mark.parametrize("query,stderr_text,code", [
    ('"boom" | halt_error', "boom", 5),
    ('"msg" | halt_error(7)', "msg", 7),
    ('"x" | halt_error(1)', "x", 1),
    ('"x" | halt_error(4)', "x", 4),
    ('"x" | halt_error(0)', "x", 0),
    ('"x" | halt_error(-1)', "x", 255),
    ('halt_error(300)', "", 44),
])
def test_halt_error_string_values(run_gojq, query, stderr_text, code):
    """halt_error with a string writes it raw with no trailing newline."""
    # CATCHES: strings go to stderr verbatim (no JSON quoting, no
    # newline) and the exit code wraps modulo 256 (-1 becomes 255,
    # 300 becomes 44); the default code is 5.
    proc = run_gojq([query], input_text="null")
    assert proc.returncode == code
    assert proc.stdout == ""
    assert proc.stderr == stderr_text


@pytest.mark.parametrize("query,stderr_text,code", [
    ('42 | halt_error', "42\n", 5),
    ('true | halt_error', "true\n", 5),
    ('[1] | halt_error', "[1]\n", 5),
    ('{"err":"x"} | halt_error', '{"err":"x"}\n', 5),
    ('null | halt_error', "", 5),
])
def test_halt_error_non_string_values(run_gojq, query, stderr_text, code):
    """Non-string halt_error values print as compact JSON plus newline."""
    # CATCHES: only strings are raw; every other value is marshaled
    # compactly with a newline, and null writes nothing at all.
    proc = run_gojq([query], input_text="null")
    assert proc.returncode == code
    assert proc.stdout == ""
    assert proc.stderr == stderr_text


@pytest.mark.parametrize("query,code", [
    (".", 1),
    ("false", 1),
    ("null", 1),
    ("true", 0),
    ("0", 0),
    ('""', 0),
    ("1", 0),
    ("[]", 0),
    ("{}", 0),
])
def test_exit_status_last_value(run_gojq, query, code):
    """-e exits 1 when the last output is null/false, else 0."""
    # CATCHES: jq truthiness applies - 0 and "" are truthy, so only null
    # and false produce exit 1.
    proc = run_gojq(["-e", query], input_text="null")
    assert proc.returncode == code
    assert proc.stderr == ""


def test_exit_status_only_last_value_counts(run_gojq):
    """-e looks at the last output value, not the first."""
    # CATCHES: '1, false' exits 1 while 'false, 1' exits 0 even though
    # both streams contain the same two values.
    proc = run_gojq(["-e", "1, false"], input_text="null")
    assert proc.returncode == 1
    assert proc.stdout == "1\nfalse\n"
    proc = run_gojq(["-e", "false, 1"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "false\n1\n"


@pytest.mark.parametrize("stdin,query", [
    ("null", "empty"),
    ("", "."),
    ("", "empty"),
    ("null\nnull\n", "empty"),
])
def test_exit_status_no_output(run_gojq, stdin, query):
    """-e exits 4 when there is no output at all, even for many inputs."""
    # CATCHES: 4 means "no value was ever produced", which includes an
    # empty stdin as well as a query yielding nothing per input.
    proc = run_gojq(["-e", query], input_text=stdin)
    assert proc.returncode == 4
    assert proc.stdout == ""
    assert proc.stderr == ""


def test_no_exit_status_without_flag(run_gojq):
    """Without -e an empty output exits 0."""
    # CATCHES: the 0/1/4 distinction only exists under -e; a plain run
    # with no output is simply successful.
    proc = run_gojq(["."], input_text="")
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""


@pytest.mark.parametrize("query,code,stderr_text", [
    ('error("x")', 5, "gojq: error: x\n"),
    ('"x" | halt_error(3)', 3, "x"),
    ("halt", 0, ""),
])
def test_exit_status_errors_win(run_gojq, query, code, stderr_text):
    """A failing query overrides the -e code with its own exit code."""
    # CATCHES: -e only decides between 0/1/4 for successful runs; the
    # error's own code (5, or halt_error's argument) takes precedence.
    proc = run_gojq(["-e", query], input_text="null")
    assert proc.returncode == code
    assert proc.stderr == stderr_text


def test_runtime_error_keeps_earlier_stdout(run_gojq):
    """Values printed before a runtime error stay on stdout."""
    # CATCHES: the error does not discard the already-written outputs,
    # and the remaining outputs of the same query are skipped.
    proc = run_gojq(["1, error(\"x\"), 2"], input_text="null")
    assert proc.returncode == 5
    assert proc.stdout == "1\n"
    assert proc.stderr == "gojq: error: x\n"


def test_runtime_error_continues_with_next_input(run_gojq):
    """After an error, the next input value is still processed."""
    # CATCHES: per-input failures do not abort the input loop; the
    # second input is evaluated and the overall exit stays 5.
    proc = run_gojq(["if . == 2 then error(\"bad\") else . end"],
                    input_text="1\n2\n")
    assert proc.returncode == 5
    assert proc.stdout == "1\n"
    assert proc.stderr == "gojq: error: bad\n"


def test_flag_error_exit_code(run_gojq):
    """A flag-parse failure exits 2 and prints the message to stderr."""
    # CATCHES: flag errors (exit 2) are distinct from runtime errors
    # (exit 5) and compile errors (exit 3) in gojq's exit code space.
    proc = run_gojq(["--colour-output", "."], input_text="null")
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr == "gojq: unknown flag `--colour-output'\n"


def test_compile_error_exit_code(run_gojq):
    """A bad query exits 3 with the query parse error on stderr."""
    # CATCHES: exit 3 (not 5) marks compilation failures; nothing is
    # written to stdout and the caret points at the unexpected EOF.
    proc = run_gojq(["[1,"], input_text="null")
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == (
        "gojq: invalid query: [1,\n    [1,\n       ^  unexpected EOF\n"
    )
