"""Tests for the shape of JSON output: pretty-printing, --indent, --tab, -c.

Pins the default two-space pretty-printing, the --indent N range and its
error messages, --tab indentation (including its precedence over
--indent), compact output, sorted object keys and the rendering of empty
containers at every nesting level.
"""

import pytest

DOC = '{"a":[1,{"b":2}],"c":{},"d":[]}'

# One (indent, exact output) pair per accepted --indent width on a fixed
# document; the element inside the nested array sits at depth 3.
INDENT_CASES = [
    (1, '{\n "a": [\n  1\n ]\n}\n'),
    (2, '{\n  "a": [\n    1\n  ]\n}\n'),
    (3, '{\n   "a": [\n      1\n   ]\n}\n'),
    (4, '{\n    "a": [\n        1\n    ]\n}\n'),
    (5, '{\n     "a": [\n          1\n     ]\n}\n'),
    (6, '{\n      "a": [\n            1\n      ]\n}\n'),
    (7, '{\n       "a": [\n              1\n       ]\n}\n'),
    (8, '{\n        "a": [\n                1\n        ]\n}\n'),
    (9, '{\n         "a": [\n                  1\n         ]\n}\n'),
]


def test_default_pretty_two_space(run_gojq):
    """Values print pretty-printed with two-space indentation by default."""
    # CATCHES: a re-implementation defaulting to compact output, or using
    # any other default indent width, fails this exact-bytes assertion.
    proc = run_gojq(["."], input_text=DOC)
    assert proc.returncode == 0
    assert proc.stdout == (
        '{\n  "a": [\n    1,\n    {\n      "b": 2\n    }\n  ],\n'
        '  "c": {},\n  "d": []\n}\n'
    )
    assert proc.stderr == ""


def test_compact_output(run_gojq):
    """-c removes all whitespace, including inside nested containers."""
    # CATCHES: compact output must not keep the space after ':' that the
    # indented pretty-printer emits, and must not break on empty objects.
    proc = run_gojq(["-c", "."], input_text=DOC)
    assert proc.returncode == 0
    assert proc.stdout == '{"a":[1,{"b":2}],"c":{},"d":[]}\n'
    assert proc.stderr == ""


def test_long_flag_compact_output(run_gojq):
    """The long spelling --compact-output behaves exactly like -c."""
    # CATCHES: a flag table that only registers the short spelling would
    # reject --compact-output instead of producing compact output.
    proc = run_gojq(["--compact-output", "."], input_text=DOC)
    assert proc.returncode == 0
    assert proc.stdout == '{"a":[1,{"b":2}],"c":{},"d":[]}\n'
    assert proc.stderr == ""


@pytest.mark.parametrize("indent,expected", INDENT_CASES)
def test_indent_widths(run_gojq, indent, expected):
    """--indent N indents each nesting level by exactly N spaces."""
    # CATCHES: an off-by-one in depth tracking (or clamping N) would
    # change the number of leading spaces on the value line.
    proc = run_gojq(["--indent", str(indent), "."], input_text='{"a":[1]}')
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_indent_zero_keeps_newlines_and_colon_space(run_gojq):
    """--indent 0 keeps the newlines and the space after each colon."""
    # CATCHES: --indent 0 is not the same as -c: elements still go on
    # their own lines and object values keep the single space after ':'.
    proc = run_gojq(["--indent", "0", "."], input_text=DOC)
    assert proc.returncode == 0
    assert proc.stdout == (
        '{\n"a": [\n1,\n{\n"b": 2\n}\n],\n"c": {},"d": []\n}\n'
    )
    assert proc.stderr == ""


def test_indent_nine_deep_nesting(run_gojq):
    """Deep nesting at --indent 9 indents by 9 spaces per level (54 deep)."""
    # CATCHES: the indent writer chunks its space run at 32 bytes; deeper
    # levels must still receive exactly depth*9 spaces.
    proc = run_gojq(["--indent", "9", "."], input_text="[[[[[[1]]]]]]")
    assert proc.returncode == 0
    assert proc.stdout == (
        '[\n         [\n                  [\n                           [\n'
        '                                    [\n                                             [\n'
        '                                                      1\n'
        '                                             ]\n'
        '                                    ]\n'
        '                           ]\n'
        '                  ]\n'
        '         ]\n'
        ']\n'
    )
    assert proc.stderr == ""


@pytest.mark.parametrize("bad,message", [
    (10, "gojq: too many indentation count: 10\n"),
    (99, "gojq: too many indentation count: 99\n"),
    (-1, "gojq: negative indentation count: -1\n"),
    (-9, "gojq: negative indentation count: -9\n"),
])
def test_indent_out_of_range(run_gojq, bad, message):
    """--indent above 9 or below 0 fails with an exact message and exit 5."""
    # CATCHES: the boundary is >9 (9 itself is fine) and the two messages
    # differ; both are plain runtime errors, not flag-parse errors.
    proc = run_gojq(["--indent", str(bad), "."], input_text=DOC)
    assert proc.returncode == 5
    assert proc.stdout == ""
    assert proc.stderr == message


@pytest.mark.parametrize("args", [["--indent=+3"], ["--indent=03"], ["--indent", "3"]])
def test_indent_flag_value_forms(run_gojq, args):
    """Atoi-style flag values: =+3 and =03 both mean indent 3."""
    # CATCHES: the flag parser accepts Go strconv.Atoi spellings, so a
    # stricter parser would reject --indent=+3 or --indent=03.
    proc = run_gojq([*args, "."], input_text='{"a":[1]}')
    assert proc.returncode == 0
    assert proc.stdout == '{\n   "a": [\n      1\n   ]\n}\n'
    assert proc.stderr == ""


@pytest.mark.parametrize("args,message", [
    (["--indent"], "gojq: expected argument for flag `--indent'\n"),
    (["--indent", "x"], "gojq: invalid argument for flag `--indent': "
                        "strconv.Atoi: parsing \"x\": invalid syntax\n"),
    (["--indent", " 3"], "gojq: invalid argument for flag `--indent': "
                         "strconv.Atoi: parsing \" 3\": invalid syntax\n"),
    (["--compact-output=1"], "gojq: boolean flag `--compact-output' "
                             "cannot have an argument\n"),
])
def test_output_flag_parse_errors(run_gojq, args, message):
    """Malformed output flags fail with exact messages and exit code 2."""
    # CATCHES: these are flag-parse errors (exit 2), unlike the out-of-
    # range --indent values which are runtime errors with exit 5.
    proc = run_gojq(args, input_text="null")
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr == message


def test_tab_indentation(run_gojq):
    """--tab indents with one tab character per nesting level."""
    # CATCHES: tabs replace the space run entirely; the space after ':'
    # stays a single space and empty containers still print inline.
    proc = run_gojq(["--tab", "."], input_text=DOC)
    assert proc.returncode == 0
    assert proc.stdout == (
        '{\n\t"a": [\n\t\t1,\n\t\t{\n\t\t\t"b": 2\n\t\t}\n\t],\n'
        '\t"c": {},\n\t"d": []\n}\n'
    )
    assert proc.stderr == ""


def test_tab_deep_nesting(run_gojq):
    """Twenty levels of --tab nesting keep exactly one tab per level."""
    # CATCHES: the tab indenter chunks its run at 16 bytes; the deepest
    # element must still be preceded by exactly twenty tabs.
    proc = run_gojq(["--tab", "."],
                    input_text="[[[[[[[[[[[[[[[[[[[[1]]]]]]]]]]]]]]]]]]]]")
    assert proc.returncode == 0
    assert "\t" * 20 + "1\n" in proc.stdout
    assert proc.stdout.startswith("[\n\t[\n\t\t[\n")
    assert proc.stdout.endswith("\t]\n]\n")


@pytest.mark.parametrize("indent", ["0", "3"])
def test_tab_wins_over_indent(run_gojq, indent):
    """--tab ignores any --indent value, including 0."""
    # CATCHES: --tab takes precedence over --indent, so --tab --indent 0
    # still emits newlines and tabs (unlike plain --indent 0).
    proc = run_gojq(["--tab", "--indent", indent, "."], input_text='{"a":[1]}')
    assert proc.returncode == 0
    assert proc.stdout == '{\n\t"a": [\n\t\t1\n\t]\n}\n'
    assert proc.stderr == ""


@pytest.mark.parametrize("args", [["-c", "--tab"], ["--tab", "-c"],
                                  ["-c", "--indent", "5"],
                                  ["--indent", "5", "-c"]])
def test_compact_wins_over_tab_and_indent(run_gojq, args):
    """-c takes precedence over both --tab and --indent."""
    # CATCHES: the precedence order is compact > tab > indent; a
    # re-implementation applying --indent on top of -c would differ.
    proc = run_gojq([*args, "."], input_text='{"a":[1]}')
    assert proc.returncode == 0
    assert proc.stdout == '{"a":[1]}\n'
    assert proc.stderr == ""


def test_empty_containers_nested(run_gojq):
    """Empty arrays and objects print as [] and {} with no inner newlines."""
    # CATCHES: a pretty-printer that puts newlines inside empty
    # containers (like Python's json with indent) would fail here.
    proc = run_gojq(["--indent", "4", "."], input_text="[[],{},[[]]]")
    assert proc.returncode == 0
    assert proc.stdout == "[\n    [],\n    {},\n    [\n        []\n    ]\n]\n"
    assert proc.stderr == ""


def test_multiple_top_level_values(run_gojq):
    """Every output value is terminated by exactly one newline."""
    # CATCHES: scalars, strings, arrays and objects each get their own
    # pretty-printed top-level value in input order.
    proc = run_gojq(["."], input_text='1\n"a"\n[1]\n{"a":1}\nnull\ntrue\nfalse')
    assert proc.returncode == 0
    assert proc.stdout == '1\n"a"\n[\n  1\n]\n{\n  "a": 1\n}\nnull\ntrue\nfalse\n'
    assert proc.stderr == ""


def test_object_keys_sorted_bytewise(run_gojq):
    """Object keys always emit sorted, by byte value, whatever the input."""
    # CATCHES: gojq has no insertion-order (or --sort-keys) option, so a
    # re-implementation keeping JSON input order would fail this test.
    proc = run_gojq(["-c", "."],
                    input_text='{"b":1,"a":2,"C":3,"_":4,"1":5,"":6,'
                               '"A":7,"ab":8,"a b":9}')
    assert proc.returncode == 0
    assert proc.stdout == '{"":6,"1":5,"A":7,"C":3,"_":4,"a":2,"a b":9,"ab":8,"b":1}\n'
    assert proc.stderr == ""


def test_object_keys_sorted_across_unicode(run_gojq):
    """Key sorting is by UTF-8 bytes: "Z" < "z" < "é" < U+FFFF."""
    # CATCHES: sorting by code point or by collation would order the
    # non-ASCII keys differently than by raw bytes.
    proc = run_gojq(["-c", "."], input_text='{"é":1,"z":2,"￿":3,"Z":4}')
    assert proc.returncode == 0
    assert proc.stdout == '{"Z":4,"z":2,"é":1,"￿":3}\n'
    assert proc.stderr == ""


def test_no_sort_keys_flag(run_gojq):
    """gojq has no --sort-keys flag because keys are always sorted."""
    # CATCHES: a re-implementation adding jq's --sort-keys flag would
    # accept it instead of failing with an unknown-flag error.
    proc = run_gojq(["--sort-keys", "."], input_text='{"b":1}')
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr == "gojq: unknown flag `--sort-keys'\n"


def test_keys_unsorted_unsupported(run_gojq):
    """The jq builtin keys_unsorted does not exist in gojq."""
    # CATCHES: gojq sorts object keys everywhere, so keys_unsorted is a
    # compile error, not an alias of keys.
    proc = run_gojq(["keys_unsorted"], input_text='{"b":1,"a":2}')
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr == "gojq: compile error: function not defined: keys_unsorted/0\n"


def test_flags_after_query(run_gojq):
    """Output flags are accepted after the query argument."""
    # CATCHES: gojq parses flags anywhere on the command line; a parser
    # that stops at the first positional would treat -c as the query.
    proc = run_gojq([".", "-c"], input_text='{"a":[1]}')
    assert proc.returncode == 0
    assert proc.stdout == '{"a":[1]}\n'
    assert proc.stderr == ""


def test_double_dash_stops_flag_parsing(run_gojq):
    """After --, arguments are queries/files rather than flags."""
    # CATCHES: `-- --indent` must not be parsed as a flag; it becomes the
    # query and fails to compile with exit code 3.
    proc = run_gojq(["--", "--indent"], input_text="null")
    assert proc.returncode == 3
    assert proc.stdout == ""
    assert proc.stderr.startswith(
        "gojq: compile error: function not defined: indent/0\n")
