"""Collection builtins: min/max, sort/sort_by, group_by, unique,
transpose, bsearch, combinations, flatten, reverse, any/all and
map/map_values.

The ordering is jq's total order: null < false < true < numbers <
strings < arrays < objects.  All expected values were recorded from the
reference binary.
"""

import pytest

SORT_CASES = [
    pytest.param('[3,1,null,"a",true,[],{}]|sort',
                 '[null,true,1,3,"a",[],{}]', id="total-order-across-types"),
    pytest.param('["banana","apple"]|sort', '["apple","banana"]',
                 id="string-sort"),
    pytest.param("[[1,2],[1],[2]]|sort", "[[1],[1,2],[2]]",
                 id="arrays-compare-element-wise"),
    pytest.param("[1,3,2]|sort_by(-.)", "[3,2,1]", id="sort_by-descending"),
    pytest.param('[{"a":2},{"a":1}]|sort_by(.a)', '[{"a":1},{"a":2}]',
                 id="sort_by-key"),
    pytest.param("[2,1]|sort_by([.])", "[1,2]", id="sort_by-array-key"),
    pytest.param("[1,3,2]|group_by(.%2)", "[[2],[1,3]]",
                 id="group_by-sorts-groups-by-key"),
    pytest.param("[]|group_by(.)", "[]", id="group_by-empty"),
    pytest.param("[1,1,2]|unique", "[1,2]", id="unique-deduplicates"),
    pytest.param("[1,2,1]|unique_by(.%2)", "[2,1]",
                 id="unique_by-keeps-first-per-key"),
    pytest.param('[{"a":1},{"a":1}]|unique_by(.a)', '[{"a":1}]',
                 id="unique_by-object-key"),
    pytest.param("[]|unique", "[]", id="unique-empty"),
    pytest.param("[null,null]|unique", "[null]", id="unique-nulls"),
]


@pytest.mark.parametrize("query,expected", SORT_CASES)
def test_sort_family(jq, query, expected):
    """sort/sort_by/group_by/unique order values with jq's total order."""
    result = jq(query)
    # CATCHES: null sorts before booleans before numbers, group_by emits
    # groups ordered by their key, and unique_by keeps the first element
    # seen for each key (so [2,1] for keys mod 2, not [1,2]).
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


MINMAX_CASES = [
    pytest.param("[]|min", "null", id="min-empty"),
    pytest.param("[]|max", "null", id="max-empty"),
    pytest.param("[1,3,2]|min", "1", id="min-numbers"),
    pytest.param("[1,3,2]|max", "3", id="max-numbers"),
    pytest.param("[1,null]|min", "null", id="min-null-is-smallest"),
    pytest.param('["a",1]|max', '"a"', id="max-string-beats-number"),
    pytest.param("[]|min_by(.)", "null", id="min_by-empty"),
    pytest.param("[]|max_by(.)", "null", id="max_by-empty"),
    pytest.param('[{"a":2},{"a":1}]|min_by(.a)', '{"a":1}', id="min_by-key"),
    pytest.param('[{"a":2},{"a":1}]|max_by(.a)', '{"a":2}', id="max_by-key"),
]


@pytest.mark.parametrize("query,expected", MINMAX_CASES)
def test_min_max_family(jq, query, expected):
    """min/max return null on empty input and honour the total order."""
    result = jq(query)
    # CATCHES: empty arrays give null (not an error), null compares as
    # the smallest value, and the _by variants return whole elements.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


STRUCTURE_CASES = [
    pytest.param("[[1,2],[3]]|transpose", "[[1,3],[2,null]]",
                 id="ragged-rows-padded-with-null"),
    pytest.param("[[1,2]]|transpose", "[[1],[2]]", id="single-row"),
    pytest.param("[[1,2],[3,4,5]]|transpose", "[[1,3],[2,4],[null,5]]",
                 id="longer-second-row"),
    pytest.param("[1,2,2,3]|bsearch(2)", "1", id="bsearch-found-first"),
    pytest.param("[1,2,2,3]|bsearch(4)", "-5",
                 id="bsearch-miss-insertion-point"),
    pytest.param("[1,2,3]|bsearch(0)", "-1", id="bsearch-miss-below"),
    pytest.param("[1,2,3]|bsearch(1.5)", "-2", id="bsearch-miss-middle"),
    pytest.param("[1,[2,[3,[4]]]]|flatten", "[1,2,3,4]", id="flatten-fully"),
    pytest.param("[1,[2,[3]]]|flatten(1)", "[1,2,[3]]", id="flatten-depth-one"),
    pytest.param("[1,[2,[3]]]|flatten(0)", "[1,[2,[3]]]",
                 id="flatten-depth-zero"),
    pytest.param("[1,2]|flatten", "[1,2]", id="flatten-flat-array"),
    pytest.param("[[1,[2]]]|flatten(1.5)", "[1,2]",
                 id="flatten-float-depth-truncated"),
    pytest.param("[1,2]|reverse", "[2,1]", id="reverse-array"),
    pytest.param("[]|reverse", "[]", id="reverse-empty"),
    pytest.param("[null]|reverse", "[null]", id="reverse-single"),
]


@pytest.mark.parametrize("query,expected", STRUCTURE_CASES)
def test_transpose_bsearch_flatten_reverse(jq, query, expected):
    """transpose/bsearch/flatten/reverse reshape arrays in jq's way."""
    result = jq(query)
    # CATCHES: transpose pads short rows with null on the left of each
    # output row, bsearch returns -(insertion point)-1 on a miss, and
    # flatten's depth is truncated toward zero.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('"abc"|reverse',
                 'gojq: reverse cannot be applied to: string ("abc")',
                 id="reverse-string"),
    pytest.param("[1]|flatten(-1)",
                 "gojq: flatten depth should not be negative: -1",
                 id="flatten-negative-depth"),
    pytest.param("1|flatten",
                 "gojq: flatten cannot be applied to: number (1)",
                 id="flatten-non-array"),
    pytest.param("[1]|transpose",
                 "gojq: transpose cannot be applied to: array ([1])",
                 id="transpose-non-rectangular"),
    pytest.param("1|transpose",
                 "gojq: transpose cannot be applied to: number (1)",
                 id="transpose-scalar"),
])
def test_collection_type_errors(jq, query, message):
    """Collection builtins reject wrong shapes with recorded messages."""
    result = jq(query)
    # CATCHES: reverse is array-only in gojq (jq also reverses strings),
    # negative flatten depth is its own error, and transpose requires
    # every element to be an array.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


COMBINATIONS_CASES = [
    pytest.param("[[1,2],[3,4]]|[combinations]",
                 "[[1,3],[1,4],[2,3],[2,4]]",
                 id="cartesian-product"),
    pytest.param("[[1,2],[3]]|[combinations(3)]",
                 "[[[1,2],[1,2],[1,2]],[[1,2],[1,2],[3]],[[1,2],[3],[1,2]],"
                 "[[1,2],[3],[3]],[[3],[1,2],[1,2]],[[3],[1,2],[3]],"
                 "[[3],[3],[1,2]],[[3],[3],[3]]]",
                 id="combinations-with-count"),
]


@pytest.mark.parametrize("query,expected", COMBINATIONS_CASES)
def test_combinations(jq, query, expected):
    """combinations enumerates the cartesian product of inner arrays."""
    result = jq(query)
    # CATCHES: the last inner array varies fastest, and the n-arity form
    # takes the first n of repeat(.) — infinite repetitions of the input
    # — before combining, producing 2**n rows here.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


ANY_ALL_CASES = [
    pytest.param("[false,false]|any", "false", id="any-all-false"),
    pytest.param("[false,true]|all", "false", id="all-one-false"),
    pytest.param("[]|any", "false", id="any-empty-false"),
    pytest.param("[]|all", "true", id="all-empty-true"),
    pytest.param("[1,2,3]|any(.>2)", "true", id="any-with-predicate"),
    pytest.param("[1,2,3]|all(.>0)", "true", id="all-with-predicate"),
    pytest.param('["","x"]|any', "true", id="any-truthy-strings"),
    pytest.param('["","x"]|all', "true", id="all-truthy-strings"),
    pytest.param("[1,2]|any", "true", id="any-numbers-are-truthy"),
    pytest.param("[1,2]|all", "true", id="all-numbers-are-truthy"),
    pytest.param("[[1,2],[3]]|any(.[0]>2)", "true", id="any-arity-two"),
    pytest.param("[[1,2],[3]]|all(.[0]>0)", "true", id="all-arity-two"),
]


@pytest.mark.parametrize("query,expected", ANY_ALL_CASES)
def test_any_all(jq, query, expected):
    """any/all work at both arities with jq truthiness."""
    result = jq(query)
    # CATCHES: every JSON value except null and false is truthy (so
    # ["","x"] is all-true), and any/all of empty is false/true.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_any_all_generator_form(jq):
    """The two-filter arity applies the condition to each generated item."""
    result = jq("[1,2,3]|all(.[]; . > 0)")
    # CATCHES: all(g; y) feeds each output of g through y — the same
    # value flows through both filters, unlike all(y) which iterates.
    assert (result.returncode, result.out, result.err) == (0, "true\n", "")


def test_any_of_non_iterable_errors(jq):
    """any/0 on a non-iterable input reports the iteration error."""
    result = jq("1|any")
    # CATCHES: any/0 is defined as any(.[]; .) in builtin.jq, so a
    # scalar input surfaces the raw ``cannot iterate over`` error.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: cannot iterate over: number (1)\n")


MAP_CASES = [
    pytest.param("[1,2]|map(.*2)", "[2,4]", id="map-doubles"),
    pytest.param('{"a":1}|map_values(.+1)', '{"a":2}',
                 id="map_values-on-object"),
    pytest.param("[1,2]|map(empty)", "[]", id="map-of-empty-empties"),
    pytest.param("[1,2]|map(.,.)", "[1,1,2,2]", id="map-expands-generators"),
]


@pytest.mark.parametrize("query,expected", MAP_CASES)
def test_map_family(jq, query, expected):
    """map and map_values are the builtin.jq-defined wrappers."""
    result = jq(query)
    # CATCHES: map flattens every output of its filter into the array,
    # while map_values updates values in place and drops those whose
    # update produces empty.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_map_error_propagates(jq):
    """map surfaces errors from its filter on the offending element."""
    result = jq("[1,[2]]|map(.+1)")
    # CATCHES: the error names the element that failed (the inner array
    # [2]), not the outer array being mapped.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: cannot add: array ([2]) and number (1)\n")