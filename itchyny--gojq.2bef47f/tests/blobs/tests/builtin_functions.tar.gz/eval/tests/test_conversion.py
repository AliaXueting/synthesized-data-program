"""Value conversion builtins: toboolean, tonumber, tostring, tojson,
fromjson, abs, ascii_downcase/ascii_upcase and explode/implode.

gojq has no NaN/Infinity literals in its JSON output (they become null and
1.7976931348623157e+308), keeps arbitrary-precision integers for tonumber,
and implode substitutes U+FFFD for out-of-range codepoints.  All expected
values below were recorded from the reference binary.
"""

import pytest

TOBOOLEAN_CASES = [
    pytest.param('"true"|toboolean', "true", id="string-true"),
    pytest.param('"false"|toboolean', "false", id="string-false"),
    pytest.param("true|toboolean", "true", id="boolean-identity"),
    pytest.param("false|toboolean", "false", id="boolean-identity-false"),
]


@pytest.mark.parametrize("query,expected", TOBOOLEAN_CASES)
def test_toboolean_accepts(jq, query, expected):
    """toboolean accepts booleans and exactly the two boolean strings."""
    result = jq(query)
    # CATCHES: only the lowercase spellings "true"/"false" convert; the
    # input value itself passes through unchanged when already boolean.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('"yes"|toboolean',
                 'gojq: toboolean cannot be applied to "yes": invalid boolean',
                 id="other-word"),
    pytest.param('"TRUE"|toboolean',
                 'gojq: toboolean cannot be applied to "TRUE": invalid boolean',
                 id="uppercase-true"),
    pytest.param("1|toboolean",
                 "gojq: toboolean cannot be applied to: number (1)",
                 id="number-input"),
    pytest.param("null|toboolean",
                 "gojq: toboolean cannot be applied to: null",
                 id="null-input"),
    pytest.param("[1]|toboolean",
                 "gojq: toboolean cannot be applied to: array ([1])",
                 id="array-input"),
])
def test_toboolean_rejects(jq, query, message):
    """toboolean failures distinguish bad strings from wrong types."""
    result = jq(query)
    # CATCHES: invalid string contents use ``cannot be applied to "s"``:
    # while wrong input types use ``cannot be applied to: type (v)``.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


TONUMBER_CASES = [
    pytest.param('"1"|tonumber', "1", id="integer-string"),
    pytest.param("1|tonumber", "1", id="number-identity"),
    pytest.param("1.5|tonumber", "1.5", id="float-identity"),
    pytest.param('"1e3"|tonumber', "1000", id="exponent-string"),
    pytest.param('"1.0"|tonumber', "1", id="trailing-zero-normalised"),
    pytest.param('"1234567890123456789012345678901234567890"|tonumber',
                 "1234567890123456789012345678901234567890",
                 id="big-integer-keeps-precision"),
]


@pytest.mark.parametrize("query,expected", TONUMBER_CASES)
def test_tonumber_accepts(jq, query, expected):
    """tonumber converts strings and keeps full integer precision."""
    result = jq(query)
    # CATCHES: gojq parses integers as big ints, so a 40-digit string
    # survives round-tripping where a double would have lost digits.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('"0x10"|tonumber',
                 'gojq: tonumber cannot be applied to "0x10": invalid number',
                 id="hex-literal"),
    pytest.param('" 1"|tonumber',
                 'gojq: tonumber cannot be applied to " 1": invalid number',
                 id="leading-space"),
    pytest.param('"abc"|tonumber',
                 'gojq: tonumber cannot be applied to "abc": invalid number',
                 id="letters"),
    pytest.param('"1abc"|tonumber',
                 'gojq: tonumber cannot be applied to "1abc": invalid number',
                 id="trailing-garbage"),
    pytest.param('"NaN"|tonumber',
                 'gojq: tonumber cannot be applied to "NaN": invalid number',
                 id="nan-literal"),
    pytest.param('"Infinity"|tonumber',
                 'gojq: tonumber cannot be applied to "Infinity": invalid number',
                 id="infinity-literal"),
    pytest.param("null|tonumber",
                 "gojq: tonumber cannot be applied to: null",
                 id="null-input"),
    pytest.param("[1]|tonumber",
                 "gojq: tonumber cannot be applied to: array ([1])",
                 id="array-input"),
])
def test_tonumber_rejects(jq, query, message):
    """tonumber rejects non-JSON-number strings with recorded messages."""
    result = jq(query)
    # CATCHES: gojq does not accept JSON extensions (hex, NaN, Infinity,
    # surrounding whitespace) and each rejection names the whole input.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


TOSTRING_CASES = [
    pytest.param('"abc"|tostring', '"abc"', id="string-identity"),
    pytest.param("1|tostring", '"1"', id="number"),
    pytest.param("1.5|tostring", '"1.5"', id="float"),
    pytest.param("null|tostring", '"null"', id="null"),
    pytest.param("true|tostring", '"true"', id="boolean"),
    pytest.param('{"a":1}|tostring', '"{\\"a\\":1}"', id="object-compacted"),
    pytest.param('[1,"a"]|tostring', '"[1,\\"a\\"]"', id="array-compacted"),
    pytest.param('nan|tostring', '"null"', id="nan-renders-as-null"),
    pytest.param('infinite|tostring', '"1.7976931348623157e+308"',
                 id="infinite-renders-as-max-double"),
]


@pytest.mark.parametrize("query,expected", TOSTRING_CASES)
def test_tostring(jq, query, expected):
    """tostring leaves strings alone and compact-encodes everything else."""
    result = jq(query)
    # CATCHES: non-string values are rendered compact (no spaces after
    # colons or commas) and the non-finite numbers become null / max
    # double rather than NaN / Infinity.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,expected", [
    pytest.param('{"a":1}|tojson', '"{\\"a\\":1}"', id="object"),
    pytest.param("1|tojson", '"1"', id="number"),
    pytest.param("null|tojson", '"null"', id="null"),
    pytest.param('nan|tojson', '"null"', id="nan-as-null"),
    pytest.param("[nan]|tojson", '"[null]"', id="nan-inside-array"),
    pytest.param('"[{\\"a\\":1}]"|fromjson', '[{"a":1}]', id="fromjson-object"),
    pytest.param('"1"|fromjson', "1", id="fromjson-number"),
    pytest.param('"null"|fromjson', "null", id="fromjson-null"),
])
def test_json_roundtrip(jq, query, expected):
    """tojson produces a JSON string; fromjson parses one back."""
    result = jq(query)
    # CATCHES: tojson wraps the compact encoding in quotes with backslashes
    # doubled, and NaN serialises as null everywhere, inside arrays too.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('"invalid"|fromjson',
                 "gojq: fromjson cannot be applied to \"invalid\": "
                 "invalid character 'i' looking for beginning of value",
                 id="syntax-error"),
    pytest.param('""|fromjson', 'gojq: fromjson cannot be applied to "": EOF',
                 id="empty-string"),
    pytest.param('"1 2"|fromjson',
                 'gojq: fromjson cannot be applied to: string ("1 2")',
                 id="trailing-data"),
    pytest.param("[1,2]|fromjson",
                 "gojq: fromjson cannot be applied to: array ([1,2])",
                 id="non-string-input"),
])
def test_fromjson_rejects(jq, query, message):
    """fromjson failures mirror encoding/json diagnostics verbatim."""
    result = jq(query)
    # CATCHES: malformed JSON reports the Go decoder error text after a
    # colon, but trailing garbage is reported as a plain type error.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


ABS_CASES = [
    pytest.param("-5|abs", "5", id="negative-int"),
    pytest.param("5|abs", "5", id="positive-int"),
    pytest.param("-5.5|abs", "5.5", id="negative-float"),
    pytest.param('"-5"|abs', '"-5"', id="string-unchanged"),
    pytest.param("0|abs", "0", id="zero"),
    pytest.param("-0.0|abs", "-0", id="negative-zero-stays"),
    pytest.param("9007199254740993|abs", "9007199254740993",
                 id="big-int-keeps-precision"),
    pytest.param("-1e300|abs", "1e+300", id="large-exponent-form"),
]


@pytest.mark.parametrize("query,expected", ABS_CASES)
def test_abs(jq, query, expected):
    """abs is implemented in jq as `if . < 0 then -. else . end`."""
    result = jq(query)
    # CATCHES: -0.0 is not below zero so it survives as -0, non-numbers
    # pass through untouched, and big integers keep every digit.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,expected", [
    pytest.param('"AbC"|ascii_downcase', '"abc"', id="mixed-case"),
    pytest.param('"AbC"|ascii_upcase', '"ABC"', id="mixed-case-up"),
    pytest.param('"ÉA"|ascii_downcase', '"Éa"',
                 id="non-ascii-left-alone"),
    pytest.param('"日本"|ascii_upcase', '"日本"', id="cjk-unchanged"),
])
def test_ascii_case(jq, query, expected):
    """ascii_downcase/ascii_upcase only fold ASCII A-Z and a-z."""
    result = jq(query)
    # CATCHES: the fold is ASCII-only, so Latin-1 and CJK characters are
    # copied through unchanged, unlike Unicode-aware case mapping.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_ascii_downcase_rejects_number(jq):
    """ascii_downcase refuses numbers with the standard type error."""
    result = jq("1|ascii_downcase")
    # CATCHES: the function is string-only; the error names the function
    # and previews the offending value.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: ascii_downcase cannot be applied to: number (1)\n")


EXPLODE_CASES = [
    pytest.param('"日本語"|explode', "[26085,26412,35486]", id="bmp-codepoints"),
    pytest.param('"\\u0080"|explode', "[128]", id="control-range-escape"),
]


@pytest.mark.parametrize("query,expected", EXPLODE_CASES)
def test_explode(jq, query, expected):
    """explode maps each character to its codepoint."""
    result = jq(query)
    # CATCHES: \\u escapes in the query are decoded by the lexer before
    # explode runs, and multibyte UTF-8 counts one codepoint per char.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


IMPLODE_CASES = [
    pytest.param("[26085,26412,35486]|implode", '"日本語"', id="bmp-roundtrip"),
    pytest.param("[128384]|implode", '"\U0001f580"', id="astral-codepoint"),
    pytest.param("[55296]|implode", '"\ufffd"', id="lone-surrogate-becomes-fffd"),
    pytest.param("[-1]|implode", '"\ufffd"', id="negative-becomes-fffd"),
    pytest.param("[1114112]|implode", '"\ufffd"',
                 id="beyond-max-becomes-fffd"),
    pytest.param("[1114111]|implode", '"\U0010ffff"',
                 id="max-valid-codepoint"),
    pytest.param("[1.5]|implode", '"\\u0001"', id="float-truncated-toward-zero"),
    pytest.param("[65.5]|implode", '"A"', id="float-65-5-truncates"),
]


@pytest.mark.parametrize("query,expected", IMPLODE_CASES)
def test_implode(jq, query, expected):
    """implode turns codepoints back into a string, substituting U+FFFD."""
    result = jq(query)
    # CATCHES: invalid codepoints (surrogates, negatives, > 0x10FFFF)
    # each produce one U+FFFD replacement, and floats are truncated
    # toward zero before conversion.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_explode_implode_type_errors(jq):
    """explode and implode reject the wrong input types."""
    explode = jq("null|explode")
    implode = jq('["a"]|implode')
    # CATCHES: both builtins error (exit 5) on mistyped input rather than
    # returning null, with the value preview embedded in the message.
    assert (explode.returncode, explode.err) == (
        5, "gojq: explode cannot be applied to: null\n")
    assert (implode.returncode, implode.err) == (
        5, 'gojq: implode cannot be applied to: array (["a"])\n')
