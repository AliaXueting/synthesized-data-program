"""Mathematical builtins: the unary C-style functions, the two-argument
variants, and the float classification predicates.

gojq has no NaN or Infinity in its JSON model: ``nan`` prints as null,
``infinite`` as the maximum double, and out-of-domain results become
null rather than NaN.  All expected values were recorded from the
reference binary.
"""

import pytest

UNARY_MATH_CASES = [
    pytest.param("2|sqrt", "1.4142135623730951", id="sqrt"),
    pytest.param("-8|cbrt", "-2", id="cbrt-negative"),
    pytest.param("2.5|floor", "2", id="floor"),
    pytest.param("2.5|ceil", "3", id="ceil"),
    pytest.param("2.5|round", "3", id="round-half-away-from-zero"),
    pytest.param("-2.5|round", "-3", id="round-negative-half-away"),
    pytest.param("2.5|nearbyint", "2", id="nearbyint-half-to-even"),
    pytest.param("2.5|rint", "2", id="rint-half-to-even"),
    pytest.param("3.5|rint", "4", id="rint-half-to-even-up"),
    pytest.param("-2.5|trunc", "-2", id="trunc-toward-zero"),
    pytest.param("3.7|fabs", "3.7", id="fabs"),
    pytest.param("-3.7|fabs", "3.7", id="fabs-negative"),
    pytest.param("1|exp", "2.718281828459045", id="exp"),
    pytest.param("1|exp10", "10", id="exp10"),
    pytest.param("1|exp2", "2", id="exp2"),
    pytest.param("1|expm1", "1.718281828459045", id="expm1"),
    pytest.param("1|log", "0", id="log"),
    pytest.param("1|log10", "0", id="log10"),
    pytest.param("1|log2", "0", id="log2"),
    pytest.param("1|log1p", "0.6931471805599453", id="log1p"),
    pytest.param("100|logb", "6", id="logb"),
    pytest.param("24|significand", "1.5", id="significand"),
    pytest.param("1.5|frexp", "[0.75,1]", id="frexp"),
    pytest.param("1.5|modf", "[0.5,1]", id="modf"),
    pytest.param("-1.5|modf", "[-0.5,-1]", id="modf-negative"),
    pytest.param("5|lgamma", "3.1780538303479458", id="lgamma"),
    pytest.param("0.5|gamma", "1.7724538509055159", id="gamma"),
    pytest.param("0.5|tgamma", "1.7724538509055159", id="tgamma"),
    pytest.param("0.5|erf", "0.5204998778130465", id="erf"),
    pytest.param("0.5|erfc", "0.4795001221869535", id="erfc"),
    pytest.param("1|j0", "0.7651976865579666", id="j0-bessel"),
    pytest.param("1|j1", "0.4400505857449335", id="j1-bessel"),
    pytest.param("1|y0", "0.08825696421567697", id="y0-bessel"),
    pytest.param("1|y1", "-0.7812128213002887", id="y1-bessel"),
]


@pytest.mark.parametrize("query,expected", UNARY_MATH_CASES)
def test_unary_math(jq, query, expected):
    """Each unary math builtin computes the recorded double value."""
    result = jq(query)
    # CATCHES: round rounds halves away from zero while rint/nearbyint
    # round to even (2.5->2 but 3.5->4), and frexp/modf return pairs.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


BINARY_MATH_CASES = [
    pytest.param("atan2(1;2)", "0.4636476090008061", id="atan2"),
    pytest.param("pow(2;10)", "1024", id="pow"),
    pytest.param("hypot(3;4)", "5", id="hypot"),
    pytest.param("ldexp(2;3)", "16", id="ldexp"),
    pytest.param("scalb(2;3)", "16", id="scalb"),
    pytest.param("scalbln(2;3)", "16", id="scalbln"),
    pytest.param("fmin(1;2)", "1", id="fmin"),
    pytest.param("fmax(nan;1)", "1", id="fmax-skips-nan"),
    pytest.param("fmin(nan;1)", "1", id="fmin-skips-nan"),
    pytest.param("drem(10;3)", "1", id="drem"),
    pytest.param("fmod(10;3)", "1", id="fmod"),
    pytest.param("remainder(10;3)", "1", id="remainder"),
    pytest.param("drem(10;0)", "null", id="drem-by-zero-null"),
    pytest.param("nextafter(1;2)", "1.0000000000000002", id="nextafter"),
    pytest.param("nexttoward(1;2)", "1.0000000000000002", id="nexttoward"),
    pytest.param("fdim(1;2)", "0", id="fdim-negative-clamped"),
    pytest.param("fdim(5;2)", "3", id="fdim-positive"),
    pytest.param("copysign(1;-2)", "-1", id="copysign-neg"),
    pytest.param("copysign(-1;2)", "1", id="copysign-pos"),
    pytest.param("fma(1;2;3)", "5", id="fma"),
    pytest.param("jn(3;2)", "0.12894324947440208", id="jn-order-bessel"),
    pytest.param("yn(3;2)", "-1.127783776840428", id="yn-order-bessel"),
]


@pytest.mark.parametrize("query,expected", BINARY_MATH_CASES)
def test_binary_math(jq, query, expected):
    """Two-argument math builtins take both operands as filter arguments."""
    result = jq(query)
    # CATCHES: these are f(x;y) filters, not x|f(y) — gojq rejects
    # ``1|atan2(2)`` as a compile error — and fmin/fmax skip NaN
    # operands while drem by zero yields null.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_binary_math_requires_both_arguments(jq):
    """Calling a two-argument math builtin with one argument fails."""
    result = jq("1|atan2(2)")
    # CATCHES: unary application is a compile-time ``function not
    # defined`` error with exit status 3, not a runtime type error.
    assert (result.returncode, result.out, result.err) == (
        3, "", "gojq: compile error: function not defined: atan2/1\n")


DOMAIN_CASES = [
    pytest.param("-1|sqrt", "null", id="sqrt-of-negative"),
    pytest.param("-1|log", "null", id="log-of-negative"),
    pytest.param("0|log", "-1.7976931348623157e+308", id="log-of-zero"),
    pytest.param("1e308|exp10", "1.7976931348623157e+308", id="exp10-overflow"),
    pytest.param("2|asin", "null", id="asin-out-of-domain"),
    pytest.param("2|acos", "null", id="acos-out-of-domain"),
    pytest.param("2|atanh", "null", id="atanh-out-of-domain"),
]


@pytest.mark.parametrize("query,expected", DOMAIN_CASES)
def test_out_of_domain_yields_null(jq, query, expected):
    """Out-of-domain math results become null, never NaN."""
    result = jq(query)
    # CATCHES: gojq has no NaN output — domain errors and infinities are
    # clamped to null or the maximum double instead.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


CLASSIFY_CASES = [
    pytest.param("nan|isnan", "true", id="isnan-of-nan"),
    pytest.param("1|isnan", "false", id="isnan-of-number"),
    pytest.param("nan|isnormal", "false", id="isnormal-of-nan"),
    pytest.param("0|isnormal", "false", id="isnormal-of-zero"),
    pytest.param("1e-320|isnormal", "false", id="isnormal-of-subnormal"),
    pytest.param("1|isnormal", "true", id="isnormal-of-one"),
    pytest.param("infinite|isfinite", "false", id="isfinite-of-infinite"),
    pytest.param("nan|isfinite", "true", id="isfinite-of-nan-is-true"),
    pytest.param("infinite|isinfinite", "true", id="isinfinite-of-infinite"),
    pytest.param("1|isinfinite", "false", id="isinfinite-of-one"),
]


@pytest.mark.parametrize("query,expected", CLASSIFY_CASES)
def test_classification_predicates(jq, query, expected):
    """isnan/isnormal/isfinite/isinfinite classify the float value."""
    result = jq(query)
    # CATCHES: isfinite is only false for the infinite value (NaN counts
    # as finite), and subnormals like 1e-320 are not normal.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


NONFINITE_CASES = [
    pytest.param("infinite", "1.7976931348623157e+308",
                 id="infinite-is-max-double"),
    pytest.param("nan", "null", id="nan-prints-as-null"),
    pytest.param("nan|type", '"number"', id="nan-is-still-a-number"),
    pytest.param("nan == nan", "false", id="nan-not-equal-to-itself"),
    pytest.param("nan < nan", "true", id="nan-compares-below-everything"),
    pytest.param("nan != nan", "true", id="nan-unequal-to-itself"),
    pytest.param("infinite > 1e308", "true", id="infinite-beats-any-double"),
    pytest.param("infinite + 1", "1.7976931348623157e+308",
                 id="infinite-saturates"),
    pytest.param("nan + 1", "null", id="nan-propagates-to-null"),
    pytest.param("-infinite|tostring", '"-1.7976931348623157e+308"',
                 id="negative-infinite-tostring"),
    pytest.param("[nan]|sort", "[null]", id="nan-sorts-as-null"),
    pytest.param("[infinite, 1, -infinite]|sort",
                 "[-1.7976931348623157e+308,1,1.7976931348623157e+308]",
                 id="infinites-sort-at-the-ends"),
]


@pytest.mark.parametrize("query,expected", NONFINITE_CASES)
def test_nonfinite_representation(jq, query, expected):
    """nan and infinite are representable and print without NaN/Inf text."""
    result = jq(query)
    # CATCHES: gojq never emits NaN or Infinity tokens — nan prints as
    # null, infinite as ±1.7976931348623157e+308 — yet nan != nan and
    # nan < nan hold, pinning the internal comparison order.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('"a"|sqrt', 'gojq: sqrt cannot be applied to: string ("a")',
                 id="sqrt-of-string"),
    pytest.param("null|sqrt", "gojq: sqrt cannot be applied to: null",
                 id="sqrt-of-null"),
    pytest.param("true|sqrt", "gojq: sqrt cannot be applied to: boolean (true)",
                 id="sqrt-of-boolean"),
])
def test_math_type_errors(jq, query, message):
    """Math builtins reject non-number inputs with the standard error."""
    result = jq(query)
    # CATCHES: even null is rejected (jq would also error) with the
    # ``cannot be applied to:`` wording and exit status 5.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


PRECISION_CASES = [
    pytest.param("0.1+0.2", "0.30000000000000004", id="float-artifact"),
    pytest.param("9007199254740993+1", "9007199254740994",
                 id="big-int-add-exact"),
    pytest.param("9007199254740993|floor", "9007199254740992",
                 id="floor-loses-int-precision"),
    pytest.param("-infinite|floor", "-1.7976931348623157e+308",
                 id="floor-of-negative-infinite"),
    pytest.param("123456789123456789123456789 * 987654321",
                 "121932631234567900234567900112635269",
                 id="big-int-multiply-exact"),
]


@pytest.mark.parametrize("query,expected", PRECISION_CASES)
def test_integer_precision(jq, query, expected):
    """gojq keeps exact big integers except through float math builtins."""
    result = jq(query)
    # CATCHES: + and * stay exact for arbitrary-precision integers, but
    # floor (a float builtin) rounds 9007199254740993 to ...992.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")
