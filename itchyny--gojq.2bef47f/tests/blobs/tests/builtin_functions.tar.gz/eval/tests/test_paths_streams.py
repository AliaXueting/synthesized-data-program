"""Path manipulation builtins: getpath, setpath, delpaths, del, pick,
paths, tostream/fromstream/truncate_stream, to_entries/from_entries/
with_entries and walk.

gojq has no ``leaf_paths`` (use ``paths(scalars)``), delpaths normalises
its path list before deleting, and setpath grows arrays with nulls.  All
expected values were recorded from the reference binary.
"""

import pytest

GETPATH_CASES = [
    pytest.param('{"a":{"b":5}}|getpath(["a","b"])', "5", id="nested-key-path"),
    pytest.param('null|getpath(["a","b"])', "null", id="null-is-traversed"),
    pytest.param('1|getpath([])', "1", id="empty-path-returns-input"),
]


@pytest.mark.parametrize("query,expected", GETPATH_CASES)
def test_getpath_values(jq, query, expected):
    """getpath walks a path, returning null through missing containers."""
    result = jq(query)
    # CATCHES: walking through a missing key yields null rather than
    # erroring, and an empty path returns the input unchanged even for
    # scalars.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('{"a":1}|getpath(["a","b"])',
                 'gojq: getpath(["a","b"]) cannot be applied to {"a":1}: '
                 "expected an object but got: number (1)",
                 id="descend-into-scalar"),
    pytest.param('[1,2,3]|getpath(["a"])',
                 'gojq: getpath(["a"]) cannot be applied to [1,2,3]: '
                 "expected an object but got: array ([1,2,3])",
                 id="string-key-on-array"),
])
def test_getpath_type_errors(jq, query, message):
    """getpath failures name the path and the offending value."""
    result = jq(query)
    # CATCHES: the error names the full path and the original input
    # value, then explains which type was expected where.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


SETPATH_CASES = [
    pytest.param('null|setpath(["a",0];1)', '{"a":[1]}',
                 id="null-grows-object-then-array"),
    pytest.param("[1,2]|setpath([0];9)", "[9,2]", id="array-element-replaced"),
    pytest.param("[1]|setpath([5];1)", "[1,null,null,null,null,1]",
                 id="array-grown-with-nulls"),
    pytest.param("[1]|setpath([-1];1)", "[1]", id="negative-index-is-noop"),
    pytest.param('{"a":1}|setpath(["b"];2)', '{"a":1,"b":2}',
                 id="object-key-added"),
]


@pytest.mark.parametrize("query,expected", SETPATH_CASES)
def test_setpath(jq, query, expected):
    """setpath builds the containers a path needs as it writes."""
    result = jq(query)
    # CATCHES: setting beyond an array tail pads with nulls, a negative
    # index writes nothing at all, and null sprouts objects for string
    # keys and arrays for number keys.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,expected", [
    pytest.param('{"a":1}|setpath(["a","b"];1)',
                 'gojq: setpath(["a","b"]; 1) cannot be applied to {"a":1}: '
                 "expected an object but got: number (1)",
                 id="descend-into-scalar"),
    pytest.param("[1,2]|setpath([\"a\"];1)",
                 'gojq: setpath(["a"]; 1) cannot be applied to [1,2]: '
                 "expected an object but got: array ([1,2])",
                 id="string-key-into-array"),
])
def test_setpath_type_errors(jq, query, expected):
    """setpath failures embed the path and value in the message."""
    result = jq(query)
    # CATCHES: the error prints the path and the replacement value
    # separated by ``; `` inside the function name.
    assert (result.returncode, result.out, result.err) == (5, "", expected + "\n")


DELPATHS_CASES = [
    pytest.param('{"a":1}|delpaths([["a"]])', "{}", id="delete-key"),
    pytest.param("[1,2,3]|delpaths([[0],[2]])", "[2]",
                 id="delete-two-indices"),
    pytest.param("[1,2,3]|delpaths([[5]])", "[1,2,3]",
                 id="out-of-range-ignored"),
    pytest.param("{}|delpaths([[]])", "null", id="empty-path-deletes-root"),
    pytest.param("1|delpaths([[]])", "null",
                 id="empty-path-deletes-scalar-root"),
    pytest.param("[1,2,3]|delpaths([[2],[0]])", "[2]",
                 id="unsorted-paths-normalised"),
    pytest.param("[1,2,3]|delpaths([[0],[0]])", "[2,3]",
                 id="duplicate-paths-collapse"),
    pytest.param('{"a":1}|del(.a)', "{}", id="del-key"),
    pytest.param("[1,2,3]|del(.[1])", "[1,3]", id="del-index"),
    pytest.param('{"a":1,"b":2,"c":3}|del(.a,.c)', '{"b":2}',
                 id="del-multiple-keys"),
    pytest.param("[1,2,3]|del(.[1:])", "[1]", id="del-slice"),
    pytest.param("[1,2,3]|del(.[])", "[]", id="del-everything"),
]


@pytest.mark.parametrize("query,expected", DELPATHS_CASES)
def test_delpaths_and_del(jq, query, expected):
    """delpaths (and del, which is delpaths of path(f)) remove subvalues."""
    result = jq(query)
    # CATCHES: deleting the empty path replaces the value with null
    # rather than erroring, unsorted and duplicate paths are normalised
    # (duplicates collapse to one deletion), and out-of-range paths are
    # silently ignored.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


PICK_PATHS_CASES = [
    pytest.param('{"a":1,"b":2}|pick(.a)', '{"a":1}', id="pick-one-key"),
    pytest.param("[1,2,3]|pick(.[0],.[2])", "[1,null,3]",
                 id="pick-keeps-index-positions"),
    pytest.param('{"a":{"b":{"c":1}}}|pick(.a.b)', '{"a":{"b":{"c":1}}}',
                 id="pick-keeps-intermediate-containers"),
    pytest.param('{"a":{"b":1}}|[paths]', '[["a"],["a","b"]]',
                 id="paths-lists-all-paths"),
    pytest.param('{"a":{"b":1}}|[paths(numbers)]', '[["a","b"]]',
                 id="paths-filtered"),
    pytest.param('{"a":1,"b":{"c":2}}|[paths(type=="number")]',
                 '[["a"],["b","c"]]', id="paths-type-filter"),
    pytest.param("1|[paths]", "[]", id="paths-of-scalar-empty"),
    pytest.param("null|[paths]", "[]", id="paths-of-null-empty"),
]


@pytest.mark.parametrize("query,expected", PICK_PATHS_CASES)
def test_pick_and_paths(jq, query, expected):
    """pick keeps only the selected paths; paths enumerates them."""
    result = jq(query)
    # CATCHES: pick preserves array length (unpicked indices become
    # null) and keeps every container along a picked path, while paths
    # never yields the empty root path.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_leaf_paths_is_not_implemented(jq):
    """gojq does not provide leaf_paths; it is a compile-time error."""
    result = jq('[{"a":1}]|leaf_paths')
    # CATCHES: unlike jq, leaf_paths/0 is missing and the compiler
    # rejects it with exit status 3 before anything runs.
    assert (result.returncode, result.out, result.err) == (
        3, "", "gojq: compile error: function not defined: leaf_paths/0\n")


TOSTREAM_CASES = [
    pytest.param('[1,[2,{"a":3}]]|[tostream]',
                 '[[[0],1],[[1,0],2],[[1,1,"a"],3],[[1,1,"a"]],[[1,1]],[[1]]]',
                 id="array-with-nesting"),
    pytest.param('{"a":1}|[tostream]', '[[["a"],1],[["a"]]]',
                 id="object-stream"),
    pytest.param("[tostream]", "[[[],null]]", id="scalar-root-stream"),
    pytest.param('null|[fromstream([[],{"a":1}],[["a"],1],[["a"]])]',
                 '[{"a":1},{"a":1}]',
                 id="fromstream-emits-per-top-level"),
    pytest.param("null|[fromstream(1|tostream)]", "[1]",
                 id="fromstream-of-scalar"),
    pytest.param('[1,[2,{"a":3}]]|[tostream]|fromstream(.[])',
                 "[1,[2,{\"a\":3}]]", id="tostream-fromstream-roundtrip"),
]


@pytest.mark.parametrize("query,expected", TOSTREAM_CASES)
def test_tostream_fromstream(jq, query, expected):
    """tostream emits [path, leaf] then closing markers; fromstream undoes it."""
    result = jq(query)
    # CATCHES: after each leaf a one-element [prefix] event closes that
    # level, the root closes with a bare empty path, and fromstream
    # re-emits the value once per completed top-level document.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,expected", [
    pytest.param('1|truncate_stream([1,[2,{"a":3}]]|tostream)',
                 "[[0],2]\n[[1,\"a\"],3]\n[[1,\"a\"]]\n[[1]]\n",
                 id="truncate-depth-one"),
    pytest.param('([1|truncate_stream({"a":{"b":1}}|tostream)]|length)',
                 "2\n", id="truncate-depth-one-counts-events"),
    pytest.param('([2|truncate_stream({"a":{"b":1}}|tostream)]|length)',
                 "0\n", id="truncate-past-depth-empty"),
    pytest.param('0|truncate_stream({"a":1}|tostream)',
                 '[[\"a\"],1]\n[[\"a\"]]\n',
                 id="truncate-depth-zero-keeps-all"),
])
def test_truncate_stream(jq, query, expected):
    """truncate_stream drops the first n path components of each event."""
    result = jq(query)
    # CATCHES: events whose path is shorter than the depth vanish
    # entirely (0 survive at depth 2, 2 at depth 1), and each remaining
    # event keeps its closing marker form.
    assert (result.returncode, result.out, result.err) == (0, expected, "")


ENTRIES_CASES = [
    pytest.param('{"a":1}|to_entries', '[{"key":"a","value":1}]',
                 id="to_entries-shape"),
    pytest.param('[{"key":"a","value":1}]|from_entries', '{"a":1}',
                 id="from_entries-key-value"),
    pytest.param('[{"name":"a","value":1}]|from_entries', '{"a":1}',
                 id="from_entries-name-fallback"),
    pytest.param('[{"Key":"a","Value":1}]|from_entries', '{"a":1}',
                 id="from_entries-capitalised-fallback"),
    pytest.param('{"a":1}|with_entries(.value+=1)', '{"a":2}',
                 id="with_entries-updates-values"),
    pytest.param('{"a":1,"b":2}|with_entries(.key|=ascii_upcase)',
                 '{"A":1,"B":2}', id="with_entries-renames-keys"),
    pytest.param('{"a":{"b":2}}|walk(if type=="number" then .*10 else . end)',
                 '{"a":{"b":20}}', id="walk-object-post-order"),
    pytest.param('[1,[2,[3]]]|walk(if type=="number" then .*10 else . end)',
                 "[10,[20,[30]]]", id="walk-array-post-order"),
    pytest.param('{"a":1}|walk(.)', '{"a":1}', id="walk-identity"),
]


@pytest.mark.parametrize("query,expected", ENTRIES_CASES)
def test_entries_and_walk(jq, query, expected):
    """to_entries/from_entries/with_entries and the post-order walk."""
    result = jq(query)
    # CATCHES: from_entries accepts key/Key/name/Name spellings, and
    # walk applies f bottom-up so parents see already-transformed
    # children.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('[{"key":true}]|from_entries',
                 "gojq: expected a string for object key but got: boolean (true)",
                 id="boolean-key"),
    pytest.param('[{"k":"a","v":1}]|from_entries',
                 "gojq: expected a string for object key but got: null",
                 id="unrecognised-key-field"),
])
def test_from_entries_key_errors(jq, query, message):
    """from_entries rejects entries whose key is not a string."""
    result = jq(query)
    # CATCHES: unknown key fields fall back to null and then fail with a
    # plain ``expected a string for object key`` error, exit status 5.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")
