"""String builtins: split (literal and regex), join, ltrimstr/rtrimstr/
trimstr, ltrim/rtrim/trim, startswith/endswith and gojq's string
indexing/slicing.

gojq extends jq with string indexing (``"abcde"[2]``) and errors on
``null`` inputs where jq returns null silently.  All expected values
were recorded from the reference binary.
"""

import pytest

SPLIT_CASES = [
    pytest.param('"a,b,,c"|split(",")', '["a","b","","c"]',
                 id="keeps-empty-fields"),
    pytest.param('"abc"|split("")', '["a","b","c"]',
                 id="empty-separator-splits-chars"),
    pytest.param('"abc"|split("b")', '["a","c"]', id="middle-separator"),
    pytest.param('"abc"|split("x")', '["abc"]', id="missing-separator"),
    pytest.param('""|split(",")', "[]", id="empty-string-no-separator"),
    pytest.param('"a,b"|split(",";null)', '["a","b"]',
                 id="two-arity-null-flags-is-literal"),
    pytest.param('"a1b22c"|split("[0-9]+";null)', '["a","b","c"]',
                 id="two-arity-regex-split"),
    pytest.param('"abc"|split("B";"i")', '["a","c"]',
                 id="regex-split-with-i-flag"),
]


@pytest.mark.parametrize("query,expected", SPLIT_CASES)
def test_split(jq, query, expected):
    """split/1 is literal; split/2 takes a regex and optional flags."""
    result = jq(query)
    # CATCHES: split/1 never treats its argument as a regex, an empty
    # string input yields [] (not [""]), and split/2 with null flags
    # still compiles the separator as a regex.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


JOIN_CASES = [
    pytest.param('["a","b"]|join(",")', '"a,b"', id="joins-strings"),
    pytest.param('[1,null,true]|join("-")', '"1--true"',
                 id="null-becomes-empty"),
    pytest.param('[]|join(",")', '""', id="empty-array"),
    pytest.param('[null]|join("-")', '""', id="only-null"),
    pytest.param('["a","b"]|join("")', '"ab"', id="empty-separator"),
    pytest.param('[1,2]|join(",")', '"1,2"', id="numbers-stringify"),
]


@pytest.mark.parametrize("query,expected", JOIN_CASES)
def test_join_values(jq, query, expected):
    """join stringifies scalars and renders null as the empty string."""
    result = jq(query)
    # CATCHES: null elements contribute nothing (not the text "null")
    # while booleans and numbers are stringified with tostring.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('"a"|join(",")',
                 'gojq: join(",") cannot be applied to: string ("a")',
                 id="string-input"),
    pytest.param("[1,2]|join(1)",
                 'gojq: cannot add: string ("1") and number (1)',
                 id="number-separator"),
    pytest.param('[[1],[2]]|join(",")',
                 'gojq: cannot add: string ("") and array ([1])',
                 id="array-element"),
    pytest.param("null|join(\",\")",
                 'gojq: join(",") cannot be applied to: null',
                 id="null-input"),
    pytest.param('1|split(",")',
                 'gojq: split(",") cannot be applied to: number (1)',
                 id="split-number-input"),
])
def test_string_type_errors(jq, query, message):
    """join/split reject mistyped inputs with recorded messages."""
    result = jq(query)
    # CATCHES: join of a non-array fails even when the input looks like
    # a single-element list ("1" is rejected as a string), and element
    # type failures surface the + operator error.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


TRIMSTR_CASES = [
    pytest.param('"abc"|ltrimstr("ab")', '"c"', id="ltrimstr-removes-prefix"),
    pytest.param('"abc"|ltrimstr("x")', '"abc"', id="ltrimstr-no-match"),
    pytest.param('"abc"|ltrimstr("")', '"abc"', id="ltrimstr-empty-prefix"),
    pytest.param('"abc"|ltrimstr("abcd")', '"abc"',
                 id="ltrimstr-longer-prefix-ignored"),
    pytest.param('"abc"|rtrimstr("bc")', '"a"', id="rtrimstr-removes-suffix"),
    pytest.param('"aXbXc"|trimstr("a")', '"XbXc"',
                 id="trimstr-only-both-ends"),
    pytest.param('"aaa"|trimstr("a")', '"a"',
                 id="trimstr-strips-one-char-each-end"),
]


@pytest.mark.parametrize("query,expected", TRIMSTR_CASES)
def test_trimstr_family(jq, query, expected):
    """ltrimstr/rtrimstr/trimstr remove at most one occurrence per end."""
    result = jq(query)
    # CATCHES: trimstr("a") on "aaa" leaves "a" — each end loses exactly
    # one copy, and a longer prefix never matches a shorter string.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


TRIM_CASES = [
    pytest.param('"  ab  "|ltrim', '"ab  "', id="ltrim-strips-left-space"),
    pytest.param('"  ab  "|rtrim', '"  ab"', id="rtrim-strips-right-space"),
    pytest.param('"  ab  "|trim', '"ab"', id="trim-strips-both"),
    pytest.param('"\\tab\\n"|trim', '"ab"', id="trim-covers-tab-newline"),
    pytest.param('"ab"|ltrim', '"ab"', id="ltrim-no-whitespace"),
    pytest.param('""|trim', '""', id="trim-empty"),
    pytest.param('" \\t\\n "|trim', '""', id="trim-only-whitespace"),
]


@pytest.mark.parametrize("query,expected", TRIM_CASES)
def test_trim_family(jq, query, expected):
    """ltrim/rtrim/trim strip Unicode whitespace from each end."""
    result = jq(query)
    # CATCHES: the whitespace set includes tabs and newlines, not just
    # spaces, and an all-whitespace string trims to the empty string.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('null|ltrimstr("a")',
                 'gojq: ltrimstr("a") cannot be applied to: null',
                 id="ltrimstr-null-input"),
    pytest.param('null|trimstr("a")',
                 'gojq: trimstr("a") cannot be applied to: null',
                 id="trimstr-null-input"),
    pytest.param('null|split(",")',
                 'gojq: split(",") cannot be applied to: null',
                 id="split-null-input"),
    pytest.param('"a"|ltrimstr(1)',
                 'gojq: ltrimstr(1) cannot be applied to: string ("a")',
                 id="ltrimstr-number-arg"),
    pytest.param('"a"|trimstr(1)',
                 'gojq: trimstr(1) cannot be applied to: string ("a")',
                 id="trimstr-number-arg"),
    pytest.param('"a"|rtrimstr(null)',
                 'gojq: rtrimstr(null) cannot be applied to: string ("a")',
                 id="rtrimstr-null-arg"),
    pytest.param("null|ltrim",
                 "gojq: ltrim cannot be applied to: null",
                 id="ltrim-null-input"),
])
def test_trim_type_errors(jq, query, message):
    """gojq errors on null inputs where jq would pass them through."""
    result = jq(query)
    # CATCHES: jq's ltrimstr/rtrimstr return null unchanged, but gojq
    # treats null (and non-string arguments) as type errors with exit
    # status 5 — a deliberate incompatibility to pin.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


@pytest.mark.parametrize("query,expected", [
    pytest.param('"abc"|startswith("ab")', "true", id="startswith-hit"),
    pytest.param('"abc"|endswith("bc")', "true", id="endswith-hit"),
    pytest.param('"abc"|startswith("x")', "false", id="startswith-miss"),
    pytest.param('"abc"|endswith("x")', "false", id="endswith-miss"),
    pytest.param('"abc"|startswith("")', "true", id="startswith-empty"),
    pytest.param('"abc"|endswith("")', "true", id="endswith-empty"),
    pytest.param('"abc"|startswith("abc")', "true", id="startswith-whole"),
    pytest.param('"abc"|startswith("abcd")', "false",
                 id="startswith-longer-than-input"),
    pytest.param('"abc"|endswith("abcd")', "false",
                 id="endswith-longer-than-input"),
])
def test_startswith_endswith(jq, query, expected):
    """startswith/endswith test literal prefixes and suffixes."""
    result = jq(query)
    # CATCHES: empty needles always match, a needle longer than the
    # input never matches, and the comparison is literal, not a regex.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_startswith_argument_type_error(jq):
    """startswith validates both the input and the argument types."""
    result = jq('"abc"|startswith(1)')
    # CATCHES: the error is attributed to the input value (``cannot be
    # applied to: string``) even though the argument is the wrong type.
    assert (result.returncode, result.out, result.err) == (
        5, "", 'gojq: startswith(1) cannot be applied to: string ("abc")\n')


STRING_INDEX_CASES = [
    pytest.param('"abcde"|.[2]', '"c"', id="index-one-char"),
    pytest.param('"abcde"|.[10]', "null", id="index-past-end-null"),
    pytest.param('"abcde"|.[1:3]', '"bc"', id="slice-mid-string"),
    pytest.param('"abcde"|.[2:]', '"cde"', id="slice-to-end"),
    pytest.param('"abcde"|.[-2:]', '"de"', id="slice-negative-start"),
    pytest.param('"abcde"|.[3:1]', '""', id="reversed-slice-empty"),
    pytest.param('"abc"|getpath([0])', '"a"', id="getpath-indexes-strings"),
]


@pytest.mark.parametrize("query,expected", STRING_INDEX_CASES)
def test_string_indexing(jq, query, expected):
    """gojq supports indexing and slicing strings by codepoint."""
    result = jq(query)
    # CATCHES: string indexing is a gojq extension jq lacks; indexing
    # past the end gives null, and a backwards slice gives "" not null.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")
