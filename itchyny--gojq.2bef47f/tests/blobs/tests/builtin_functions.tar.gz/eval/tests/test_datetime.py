"""Date and time builtins: todate/fromdate (and the iso8601 pair),
gmtime/localtime/mktime, strftime/strptime/strflocaltime and now.

gojq improves on jq here: ``%f`` handles fractional seconds, ``%Z``/``%z``
are parsed by strptime, and timezone offsets are accepted by fromdate.
The child process TZ is pinned (UTC unless a test overrides it) so every
expectation is reproducible.  All values were recorded from the
reference binary.
"""

import pytest

EPOCH_CASES = [
    pytest.param("1700000000|todate", '"2023-11-14T22:13:20Z"',
                 id="todate-renders-utc"),
    pytest.param("1700000000|todateiso8601", '"2023-11-14T22:13:20Z"',
                 id="todateiso8601-matches-todate"),
    pytest.param("0|todate", '"1970-01-01T00:00:00Z"', id="epoch-zero"),
    pytest.param("1700000000|gmtime", "[2023,10,14,22,13,20,2,317]",
                 id="gmtime-broken-down-fields"),
    pytest.param("1700000000.5|gmtime", "[2023,10,14,22,13,20.5,2,317]",
                 id="gmtime-keeps-fractional-seconds"),
    pytest.param("1700000000|gmtime|mktime", "1700000000",
                 id="gmtime-mktime-roundtrip"),
    pytest.param("1700000000.5|gmtime|mktime", "1700000000.5",
                 id="mktime-roundtrip-keeps-fraction"),
    pytest.param('[2023,10,14,22,13,20,2,317]|mktime', "1700000000",
                 id="mktime-full-broken-down"),
    pytest.param("[2023,10,14,22,13,20]|mktime", "1700000000",
                 id="mktime-partial-broken-down"),
    pytest.param('"2023-11-14T22:13:20Z"|fromdateiso8601', "1700000000",
                 id="fromdateiso8601"),
    pytest.param('"2023-11-14T22:13:20Z"|fromdate', "1700000000",
                 id="fromdate-equals-fromdateiso8601"),
    pytest.param('"1970-01-01T00:00:00Z"|fromdate', "0",
                 id="fromdate-epoch-zero"),
    pytest.param('"2023-11-14T22:13:20+09:00"|fromdateiso8601', "1699967600",
                 id="fromdate-parses-plus-offset"),
    pytest.param('"2023-11-14T22:13:20-05:00"|fromdate', "1700018000",
                 id="fromdate-parses-minus-offset"),
    pytest.param('1700000000|strftime("%Y-%m-%dT%H:%M:%SZ")|fromdateiso8601',
                 "1700000000", id="strftime-fromdate-roundtrip"),
]


@pytest.mark.parametrize("query,expected", EPOCH_CASES)
def test_epoch_conversions(jq, query, expected):
    """todate/gmtime/mktime/fromdate convert between epochs and fields."""
    result = jq(query)
    # CATCHES: the broken-down form is 0-based for month and weekday but
    # 1-based for yday (317), fractional seconds survive gmtime and
    # mktime, and fromdate accepts explicit timezone offsets — all gojq
    # improvements over jq.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


STRFTIME_CASES = [
    pytest.param('1700000000|strftime("%Y-%m-%d %H:%M:%S")',
                 '"2023-11-14 22:13:20"', id="common-directives"),
    pytest.param('1700000000|strftime("%A %B %j")', '"Tuesday November 318"',
                 id="weekday-month-yday"),
    pytest.param('1700000000|strftime("%Z %z")', '"UTC +0000"',
                 id="timezone-name-and-offset"),
    pytest.param('1700000000|strftime("%a %b %e %I %p %u %w %C %G %V")',
                 '"Tue Nov 14 10 PM 2 2 20 2023 46"',
                 id="remaining-reference-directives"),
    pytest.param('1700000000.5|strftime("%S.%f")', '"20.500000"',
                 id="f-renders-nanosecond-digits"),
    pytest.param('1700000000|strftime("%f")', '"000000"',
                 id="f-without-fraction-is-zeroes"),
    pytest.param('1700000000|gmtime|strftime("%s")', '"1700000000"',
                 id="s-epoch-seconds"),
    pytest.param('1|strftime("%Y")', '"1970"', id="small-epoch"),
    pytest.param('0|strftime("%Y-%m-%dT%H:%M:%SZ")', '"1970-01-01T00:00:00Z"',
                 id="epoch-zero-format"),
    pytest.param('1700000000|strftime("%!")', '"%!"',
                 id="unknown-directive-passes-through"),
]


@pytest.mark.parametrize("query,expected", STRFTIME_CASES)
def test_strftime(jq, query, expected):
    """strftime renders the reference-C strftime directives plus %f."""
    result = jq(query)
    # CATCHES: %j is 1-based (318 while the gmtime yday field is 317),
    # %f prints exactly six digits, %e space-pads the day, and an
    # unknown directive is copied through verbatim.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


STRPTIME_CASES = [
    pytest.param('"2023-11-14T22:13:20Z"|strptime("%Y-%m-%dT%H:%M:%SZ")',
                 "[2023,10,14,22,13,20,2,317]", id="iso-with-literal-z"),
    pytest.param('"2023-11-14 22:13:20"|strptime("%Y-%m-%d %H:%M:%S")',
                 "[2023,10,14,22,13,20,2,317]", id="space-separated"),
    pytest.param('"2023-11-14T22:13:20+09:00"|strptime("%Y-%m-%dT%H:%M:%S%z")',
                 "[2023,10,14,13,13,20,2,317]", id="z-offset-applied"),
    pytest.param('"2023-11-14T22:13:20+09:00"|strptime("%Y-%m-%dT%H:%M:%S%z")|mktime',
                 "1699967600", id="z-offset-mktime"),
    pytest.param('"2023 +0900"|strptime("%Y %z")|mktime', "1672498800",
                 id="z-numeric-offset-mktime"),
    pytest.param('"2023 UTC"|strptime("%Y %Z")', "[2023,0,1,0,0,0,0,0]",
                 id="Z-timezone-name"),
    pytest.param('"Tue Nov 14 2023"|strptime("%a %b %d %Y")',
                 "[2023,10,14,0,0,0,2,317]", id="weekday-and-month-names"),
    pytest.param('"2023-11-14T22:13:20.123456Z"|strptime("%Y-%m-%dT%H:%M:%S.%fZ")',
                 "[2023,10,14,22,13,20.123456,2,317]",
                 id="f-parses-fractional-seconds"),
]


@pytest.mark.parametrize("query,expected", STRPTIME_CASES)
def test_strptime(jq, query, expected):
    """strptime parses formats including %z offsets, %Z names and %f."""
    result = jq(query)
    # CATCHES: %z converts the wall time to UTC during parsing (22:13
    # becomes 13:13 for +09:00), %Z accepts the zone name, and %f stores
    # the fraction inside the seconds field.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('"2023-11-14T22:13:20"|fromdate',
                 'gojq: strptime("%Y-%m-%dT%H:%M:%S%z") cannot be applied to '
                 '"2023-11-14T22:13:20": failed to parse "2023-11-14T22:13:20" '
                 'with "%Y-%m-%dT%H:%M:%S%z": cannot parse "%z"',
                 id="missing-timezone"),
    pytest.param('"bogus"|fromdate',
                 'gojq: strptime("%Y-%m-%dT%H:%M:%S%z") cannot be applied to '
                 '"bogus": failed to parse "bogus" with '
                 '"%Y-%m-%dT%H:%M:%S%z": cannot parse "%Y"',
                 id="garbage-input"),
    pytest.param('"2023-13-45T99:99:99Z"|fromdateiso8601',
                 'gojq: strptime("%Y-%m-%dT%H:%M:%S%z") cannot be applied to '
                 '"2023-13-45T99:99:99Z": failed to parse "2023-13-45T99:99:99Z" '
                 'with "%Y-%m-%dT%H:%M:%S%z": cannot parse "%m"',
                 id="out-of-range-fields"),
    pytest.param('"2023"|strftime("%Y")',
                 'gojq: strftime("%Y") cannot be applied to: string ("2023")',
                 id="strftime-string-input"),
])
def test_datetime_errors(jq, query, message):
    """Parsing failures name the format and the directive that failed."""
    result = jq(query)
    # CATCHES: strptime errors repeat the format string twice — once in
    # the function prefix and once after "failed to parse" — and end
    # with the specific directive that could not be parsed.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


def test_localtime_respects_tz(jq):
    """localtime and strflocaltime honour the child process TZ."""
    tokyo = jq("1700000000|localtime", extra_env={"TZ": "Asia/Tokyo"})
    # CATCHES: localtime differs from gmtime by the zone offset (here
    # +09:00, moving the date to the next day) while strftime stays UTC.
    assert (tokyo.returncode, tokyo.out, tokyo.err) == (
        0, "[2023,10,15,7,13,20,3,318]\n", "")


@pytest.mark.parametrize("tz,expected", [
    pytest.param("Asia/Tokyo", '"2023-11-15 07:13:20 JST +0900"'),
    pytest.param("America/New_York", '"2023-11-14 17:13:20 EST -0500"'),
])
def test_strflocaltime_respects_tz(jq, tz, expected):
    """strflocaltime renders %Z and %z from the effective timezone."""
    result = jq('1700000000|strflocaltime("%Y-%m-%d %H:%M:%S %Z %z")',
                extra_env={"TZ": tz})
    # CATCHES: the zone abbreviation and numeric offset come from the
    # TZ environment variable of the child process, so a re-implementation
    # must consult it rather than hardcoding UTC.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_strftime_ignores_tz(jq):
    """strftime always renders UTC regardless of TZ."""
    result = jq('1700000000|strftime("%Y-%m-%d %H:%M:%S %Z %z")',
                extra_env={"TZ": "Asia/Tokyo"})
    # CATCHES: only the *local* functions consult TZ — plain strftime
    # reports UTC and +0000 even with TZ set to a non-UTC zone.
    assert (result.returncode, result.out, result.err) == (
        0, '"2023-11-14 22:13:20 UTC +0000"\n', "")


def test_now_returns_a_number(jq):
    """now yields the current epoch as a number (value not pinned)."""
    result = jq("now|type")
    # CATCHES: now is a number-producing builtin with no arguments; the
    # test pins only its type because the value changes every call.
    assert (result.returncode, result.out, result.err) == (0, '"number"\n', "")
