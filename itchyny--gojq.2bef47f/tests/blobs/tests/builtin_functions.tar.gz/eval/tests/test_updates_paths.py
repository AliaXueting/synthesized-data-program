"""Path-update machinery: slice assignment, nested index updates,
del on exotic paths and getpath corner cases.

gojq supports jq 1.7's negative array indexing (.[-1]), truncates float
indices toward zero but ceils float slice bounds, and rejects string
slice assignment outright.  Every expected value below was recorded from
the reference binary.
"""

import pytest

SLICE_UPDATE_CASES = [
    pytest.param("[1,2,3,4]|.[1:3]=[9]", "[1,9,4]",
                 id="shorter-replacement-splices"),
    pytest.param("[1,2,3,4]|.[1:3]=[9,9,9]", "[1,9,9,9,4]",
                 id="longer-replacement-splices"),
    pytest.param("[1,2,3,4]|.[1:3]|=map(.*10)", "[1,20,30,4]",
                 id="update-assignment-maps-slice"),
    pytest.param("[1,2,3,4]|.[:2]=[0]", "[0,3,4]",
                 id="open-start-slice"),
    pytest.param("[1,2,3,4]|.[2:]=[0]", "[1,2,0]",
                 id="open-end-slice"),
    pytest.param("[1,2,3,4]|.[-2:]=[0]", "[1,2,0]",
                 id="negative-start-slice"),
    pytest.param("[1,2,3]|del(.[1:3])", "[1]",
                 id="del-slice"),
]


@pytest.mark.parametrize("query,expected", SLICE_UPDATE_CASES)
def test_slice_updates(jq, query, expected):
    """Assigning to an array slice replaces it in place, resizing."""
    result = jq(query)
    # CATCHES: = on a slice splices (a 3-element value into a 2-element
    # slot grows the array), |= sees the extracted slice as its input,
    # and a negative start counts from the end.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


INDEX_UPDATE_CASES = [
    pytest.param("[1,2,3]|.[1.5]=9", "[1,9,3]",
                 id="float-index-truncates-on-assign"),
    pytest.param("[1,2,3]|.[1.5]", "2",
                 id="float-index-truncates-on-read"),
    pytest.param("[1,2,3]|.[1:2.5]", "[2,3]",
                 id="float-slice-end-ceils"),
    pytest.param("[1,2,3]|.[-1]", "3",
                 id="negative-index-reads-last"),
    pytest.param("[[1,2]]|.[0][1]=9", "[[1,9]]",
                 id="nested-index-assign"),
    pytest.param('{"a":[1,2]}|.a[0]=9', '{"a":[9,2]}',
                 id="object-then-index-assign"),
    pytest.param("[1,2,3]|.[0]|=.+10", "[11,2,3]",
                 id="update-assignment-on-element"),
    pytest.param("[1,2,3]|.[] |= .+1", "[2,3,4]",
                 id="iterate-update-each"),
    pytest.param('{"a":1,"b":2}|.[] += 1', '{"a":2,"b":3}',
                 id="iterate-update-object-values"),
    pytest.param("[[1,2],[3,4]]|.[0] = [9]", "[[9],[3,4]]",
                 id="whole-element-replacement"),
    pytest.param('{"a":{"b":1}}|.a.b = 2', '{"a":{"b":2}}',
                 id="deep-key-assign"),
    pytest.param("[1,2,3]|del(.[0],.[2])", "[2]",
                 id="del-two-indices-at-once"),
    pytest.param("[[1,[2]]]|del(.[0][1][0])", "[[1,[]]]",
                 id="del-deeply-nested"),
]


@pytest.mark.parametrize("query,expected", INDEX_UPDATE_CASES)
def test_index_updates(jq, query, expected):
    """Index updates truncate float indices but ceil float slice bounds."""
    result = jq(query)
    # CATCHES: .[1.5] addresses element 1 on both read and write while
    # .[1:2.5] extends to element 3 (ceil), and .[] |= applies the
    # filter to every slot of arrays and objects alike.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


UPDATE_ERROR_CASES = [
    pytest.param('[1,2,3]|.["a"]=1',
                 'gojq: setpath(["a"]; 1) cannot be applied to [1,2,3]: '
                 "expected an object but got: array ([1,2,3])",
                 id="string-key-into-array"),
    pytest.param('"hello"|.[1:3]="EL"',
                 'gojq: setpath([{"end":3,"start":1}]; "EL") '
                 'cannot be applied to "hello": '
                 'expected an array but got: string ("hello")',
                 id="string-slice-assign-rejected"),
    pytest.param('"hello"|.[1:3]|=ascii_upcase',
                 'gojq: setpath([{"end":3,"start":1}]; "EL") '
                 'cannot be applied to "hello": '
                 'expected an array but got: string ("hello")',
                 id="string-slice-update-rejected"),
]


@pytest.mark.parametrize("query,message", UPDATE_ERROR_CASES)
def test_update_type_errors(jq, query, message):
    """Wrong-shaped update targets fail inside an internal setpath call."""
    result = jq(query)
    # CATCHES: the error names setpath with the raw path ({"end":..,
    # "start":..} objects for slices) even though the query wrote .[1:3],
    # and for |= the computed replacement value ("EL") is what appears
    # in the message — jq 1.7 would allow the string slice update.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


GETPATH_CASES = [
    pytest.param("[1,2,3]|getpath([-1])", "3",
                 id="getpath-negative-index"),
    pytest.param("[1,2,3]|getpath([1.5])", "2",
                 id="getpath-float-index-truncates"),
    pytest.param("getpath([])|type", '"null"',
                 id="empty-path-of-null"),
    pytest.param("null|.a?", "null",
                 id="optional-does-not-swallow-null-result"),
    pytest.param("[.[]?]", "[]",
                 id="optional-iteration-of-null"),
]


@pytest.mark.parametrize("query,expected", GETPATH_CASES)
def test_getpath_exotic(jq, query, expected):
    """getpath accepts negative and float indices like plain indexing."""
    result = jq(query)
    # CATCHES: getpath([-1]) reads the last element (jq 1.7 semantics),
    # float path components truncate toward zero, and the ? operator
    # only suppresses errors — a successful null still flows through.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


GETPATH_ERROR_CASES = [
    pytest.param('null|getpath("a")',
                 'gojq: getpath("a") cannot be applied to: null',
                 id="non-array-path"),
    pytest.param('[1]|getpath(["a"])',
                 'gojq: getpath(["a"]) cannot be applied to [1]: '
                 "expected an object but got: array ([1])",
                 id="string-key-into-array"),
    pytest.param('"abc"|getpath(["a"])',
                 'gojq: getpath(["a"]) cannot be applied to "abc": '
                 'expected an object but got: string ("abc")',
                 id="string-key-into-string"),
    pytest.param('{"1":{"x":10}}|.[1]',
                 'gojq: expected an array but got: object ({"1":{"x":10}})',
                 id="number-index-into-object"),
]


@pytest.mark.parametrize("query,message", GETPATH_ERROR_CASES)
def test_getpath_type_errors(jq, query, message):
    """Bad paths report the offending path inside the message."""
    result = jq(query)
    # CATCHES: a non-array path argument is the plain cannot-be-applied
    # form, while a valid array path with the wrong key type shows the
    # wrapped expected-an-object message — and indexing an object with a
    # NUMBER says expected an array, gojq's inverted wording vs jq.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


INDEX_SLICE_READ_CASES = [
    pytest.param('"abc"|.[1:2]', '"b"', id="string-slice-read"),
    pytest.param('"abc"|.[1:]', '"bc"', id="string-slice-open-end"),
    pytest.param('"日本語"|.[1:2]', '"本"', id="string-slice-multibyte"),
    pytest.param("null|.[1:2]", "null", id="slice-of-null-is-null"),
    pytest.param('null|.["a"]', "null", id="key-of-null-is-null"),
    pytest.param("null|.[0]", "null", id="index-of-null-is-null"),
    pytest.param("null|.[[1]]", "null", id="array-needle-on-null-is-null"),
    pytest.param('"abc"|.[1]', '"b"', id="string-index-read"),
    pytest.param('"abc"|.[-1]', '"c"', id="string-negative-index"),
    pytest.param("[1,2,3]|.[[1]]", "[0]", id="array-needle-returns-indices"),
]


@pytest.mark.parametrize("query,expected", INDEX_SLICE_READ_CASES)
def test_index_and_slice_reads(jq, query, expected):
    """Reading by index or slice: null input yields null, strings slice."""
    result = jq(query)
    # CATCHES: every indexing form on null returns null (no error), and
    # slices work on strings by codepoint — 日本語|.[1:2] is 本 — while
    # indexing an array WITH an array asks where that subarray occurs.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


INDEX_READ_ERROR_CASES = [
    pytest.param('[1,2,3]|.["a"]',
                 "gojq: expected an object but got: array ([1,2,3])",
                 id="string-key-read-into-array"),
    pytest.param("[1,2,3]|.[{}]",
                 'gojq: expected "start" and "end" for slicing '
                 "but got: object ({})",
                 id="index-by-empty-object"),
    pytest.param("[1,2,3]|.[null]",
                 "gojq: expected a number for indexing an array but got: null",
                 id="null-index-into-array"),
    pytest.param('"abc"|.[true]',
                 "gojq: expected a number for indexing a string but got: "
                 "boolean (true)",
                 id="boolean-index-into-string"),
]


@pytest.mark.parametrize("query,message", INDEX_READ_ERROR_CASES)
def test_index_read_errors(jq, query, message):
    """Bad index operands produce distinct message wording per container."""
    result = jq(query)
    # CATCHES: arrays and strings each name their own expectation, an
    # empty object index is treated as a malformed slice request, and a
    # string key into an array is the bare expected-an-object error.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")
