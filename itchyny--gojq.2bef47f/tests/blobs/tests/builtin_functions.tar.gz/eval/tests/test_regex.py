"""The regex family: test, match, capture, scan, splits, split/2, sub, gsub.

gojq compiles patterns with Go's RE2 engine, so only the g, i and m flags
exist — and m means dot-matches-newline (jq uses m for per-line ^/$).
Backreferences and look-around are compile errors, offsets and lengths are
counted in codepoints, and unmatched optional captures appear as null.
Every expected value below was recorded from the reference binary.
"""

import pytest

TEST_CASES = [
    pytest.param('"abc"|test("b")', "true", id="plain-match"),
    pytest.param('"abc"|test("B")', "false", id="case-sensitive-miss"),
    pytest.param('"abc"|test("B";"i")', "true", id="i-flag-ignores-case"),
    pytest.param('"abc"|test("x")', "false", id="no-match"),
    pytest.param('"abc"|test("a";"g")', "true", id="g-flag-accepted-by-test"),
    pytest.param('"abc"|test("[a-z]")', "true", id="character-class"),
    pytest.param('"abc"|test("a";"gi")', "true", id="combined-flags"),
    pytest.param('"x"|test("X";"")', "false", id="empty-flag-string"),
    pytest.param('"a"|test("a";null)', "true", id="null-flags-is-default"),
    pytest.param('"a"|test("(?<x>a)(?<x>b)")', "false",
                 id="duplicate-names-allowed"),
]


@pytest.mark.parametrize("query,expected", TEST_CASES)
def test_regex_test(jq, query, expected):
    """test/1 and test/2 report whether the pattern matches anywhere."""
    result = jq(query)
    # CATCHES: the g flag is accepted by test (unlike jq it is not an
    # error), null flags behave like no flags, and matching is
    # case-sensitive unless i is given.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


MATCH_CASES = [
    pytest.param('"abc"|match("b")',
                 '{"captures":[],"length":1,"offset":1,"string":"b"}',
                 id="match-object-shape"),
    pytest.param('"aXbXc"|[match("X";"g").offset]', "[1,3]", id="g-finds-all"),
    pytest.param('"abcabc"|[match("b";"g").offset]', "[1,4]",
                 id="g-continues-past-first"),
    pytest.param('"a1b2"|[match("[0-9]";"g")|{offset,length,string}]',
                 '[{"length":1,"offset":1,"string":"1"},'
                 '{"length":1,"offset":3,"string":"2"}]',
                 id="fields-per-match"),
    pytest.param('"abc"|match("")',
                 '{"captures":[],"length":0,"offset":0,"string":""}',
                 id="empty-pattern-matches-at-start"),
    pytest.param('"abc"|[match("";"g")]|length', "4",
                 id="empty-pattern-g-gives-len-plus-one"),
    pytest.param('"abc"|match("(?:a)")',
                 '{"captures":[],"length":1,"offset":0,"string":"a"}',
                 id="non-capturing-group"),
    pytest.param('"a"|match("a")|keys',
                 '["captures","length","offset","string"]',
                 id="object-keys"),
    pytest.param('"日本語"|match("本")',
                 '{"captures":[],"length":1,"offset":1,"string":"本"}',
                 id="offset-counts-codepoints"),
    pytest.param('"日本語本"|[match("本";"g").offset]', "[1,3]",
                 id="g-offsets-multibyte"),
    pytest.param('"aé"|match("é")',
                 '{"captures":[],"length":1,"offset":1,"string":"é"}',
                 id="composed-accent-is-one-codepoint"),
]


@pytest.mark.parametrize("query,expected", MATCH_CASES)
def test_regex_match(jq, query, expected):
    """match/1,2 returns {offset,length,string,captures} objects."""
    result = jq(query)
    # CATCHES: offsets are rune counts not byte counts (本 at index 1),
    # the match object has exactly these four keys, and without g only
    # the first match is reported.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


EMPTY_MATCH_CASES = [
    pytest.param('"baaab"|[match("a*";"g")|{offset,length}]',
                 '[{"length":0,"offset":0},{"length":3,"offset":1},'
                 '{"length":0,"offset":4},{"length":0,"offset":5}]',
                 id="empty-matches-before-and-after-run"),
    pytest.param('"xabx"|[match("x*";"g").offset]', "[0,1,2,3,4]",
                 id="empty-match-at-every-position"),
    pytest.param('"ab"|[match("b*";"g")|{offset,length}]',
                 '[{"length":0,"offset":0},{"length":1,"offset":1},'
                 '{"length":0,"offset":2}]',
                 id="trailing-empty-match-reported"),
    pytest.param('""|[match("";"g")]|length', "1",
                 id="empty-subject-empty-pattern"),
    pytest.param('"ab"|[scan("a*")]', '["a","",""]',
                 id="scan-sees-empty-matches-too"),
    pytest.param('"baaab"|gsub("a*";"-")', '"-b--b-"',
                 id="gsub-replaces-empty-matches"),
    pytest.param('"aaa"|gsub("a*";"b")', '"bb"',
                 id="gsub-merges-run-and-trailing-empty"),
]


@pytest.mark.parametrize("query,expected", EMPTY_MATCH_CASES)
def test_regex_empty_matches(jq, query, expected):
    """Empty matches abutting a real match are reported, jq-style."""
    result = jq(query)
    # CATCHES: Go's regexp alone would drop the empty match after a
    # non-empty one; gojq re-adds it, so a* on "baaab" yields four
    # matches and gsub("a*";"-") produces "-b--b-" with a doubled dash
    # where the run and the trailing empty match both replace.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


CAPTURE_SCAN_CASES = [
    pytest.param('"foo"|capture("(?<x>o)")', '{"x":"o"}',
                 id="capture-named-group"),
    pytest.param('"foo foo"|[capture("(?<x>o+)")]', '[{"x":"oo"}]',
                 id="capture-without-g-is-first-only"),
    pytest.param('"a"|capture("(?<x>a)(?<y>x)?")', '{"x":"a","y":null}',
                 id="unmatched-optional-capture-is-null"),
    pytest.param('"ab"|match("(?:(?<x>a)|b)")',
                 '{"captures":[{"length":1,"name":"x","offset":0,"string":"a"}],'
                 '"length":1,"offset":0,"string":"a"}',
                 id="capture-entry-shape"),
    pytest.param('"foo"|[scan("o")]', '["o","o"]',
                 id="scan-without-groups"),
    pytest.param('"foo"|[scan("(?<x>o)")]', '[["o"],["o"]]',
                 id="scan-with-group-wraps-in-array"),
    pytest.param('"abc"|scan("")', '""\n""\n""\n""',
                 id="scan-empty-pattern-stream"),
]


@pytest.mark.parametrize("query,expected", CAPTURE_SCAN_CASES)
def test_regex_capture_scan(jq, query, expected):
    """capture builds {name: string}; scan yields group arrays when named."""
    result = jq(query)
    # CATCHES: an optional group that did not participate in the match
    # maps to null (not empty or ""), and scan switches from bare
    # strings to one array per match as soon as the pattern has a group.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


SPLITS_CASES = [
    pytest.param('"a1b22c"|[splits("[0-9]+")]', '["a","b","c"]',
                 id="splits-regex"),
    pytest.param('"a1b22c"|split("[0-9]+";null)', '["a","b","c"]',
                 id="split-2-null-flags-regex"),
    pytest.param('"abc"|split("B";"i")', '["a","c"]',
                 id="split-2-i-flag"),
    pytest.param('"abc"|[splits("")]', '["","a","b","c",""]',
                 id="splits-empty-pattern-keeps-edges"),
    pytest.param('"abc"|split("";null)', '["","a","b","c",""]',
                 id="split-2-empty-pattern"),
    pytest.param('"a b"|[splits(" ";null)]', '["a","b"]',
                 id="splits-null-flags"),
    pytest.param('"abc"|splits("B";"i")', '"a"\n"c"',
                 id="splits-is-a-stream"),
]


@pytest.mark.parametrize("query,expected", SPLITS_CASES)
def test_regex_splits(jq, query, expected):
    """splits is the streaming regex split; split/2 wraps it in an array."""
    result = jq(query)
    # CATCHES: split/1 is literal (covered elsewhere) but split/2 always
    # compiles a regex even with null flags, and an empty pattern keeps
    # empty leading/trailing fields like jq.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


SUB_CASES = [
    pytest.param('"a1b"|sub("1";"X")', '"aXb"', id="sub-replaces-first"),
    pytest.param('"aXbXc"|sub("X";"Y")', '"aYbXc"',
                 id="sub-leaves-later-matches"),
    pytest.param('"aXbXc"|gsub("X";"Y")', '"aYbYc"',
                 id="gsub-replaces-all"),
    pytest.param('"aXb"|sub("(?<c>X)";"[\\(.c)]")', '"a[X]b"',
                 id="named-capture-interpolation"),
    pytest.param('"aXbXc"|gsub("(?<c>X)";"[\\(.c)]")', '"a[X]b[X]c"',
                 id="gsub-capture-interpolation"),
    pytest.param('"a1b2"|gsub("(?<d>[0-9])";"<\\(.d)>")', '"a<1>b<2>"',
                 id="gsub-digit-captures"),
    pytest.param('"abc"|sub("(?<x>b)";"\\(.x)")', '"abc"',
                 id="empty-replacement-inserts-nothing"),
    pytest.param('"abc"|sub("b";"\\(.)")', '"a{}c"',
                 id="whole-match-interpolation-is-object"),
    pytest.param('"aXbXc"|gsub("X";"Y";"i")', '"aYbYc"',
                 id="gsub-flags-argument"),
    pytest.param('"abc"|sub("b";"X";"g")', '"aXc"',
                 id="g-flag-makes-sub-a-gsub"),
    pytest.param('"Ab"|sub("b";"B";"i")', '"AB"',
                 id="i-flag-pattern-side"),
    pytest.param('"a"|sub("a";"X";"gi")', '"X"',
                 id="gi-combined"),
    pytest.param('"abc"|gsub("";"X")', '"XaXbXcX"',
                 id="gsub-empty-pattern"),
    pytest.param('"abc"|sub("";"X")', '"Xabc"',
                 id="sub-empty-pattern-at-start"),
]


@pytest.mark.parametrize("query,expected", SUB_CASES)
def test_regex_sub_gsub(jq, query, expected):
    """sub/gsub interpolate \\(.name) capture references per match."""
    result = jq(query)
    # CATCHES: sub with the g flag equals gsub, \\(.) is the match
    # OBJECT (printed as {} when empty) while a named capture pastes its
    # string, and gsub("";"X") inserts between every codepoint.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


FLAG_CASES = [
    pytest.param('"a\\nb"|test("a.b")', "false", id="dot-stops-at-newline"),
    pytest.param('"a\\nb"|test("a.b";"m")', "true",
                 id="m-makes-dot-match-newline"),
    pytest.param('"a\\nb"|test("^b$";"m")', "false",
                 id="m-is-not-per-line-anchoring"),
    pytest.param('"A\\nb"|test("a.b";"im")', "true", id="im-combined"),
    pytest.param('"A\\nb"|test("a.b";"ig")', "false", id="ig-no-dotall"),
]


@pytest.mark.parametrize("query,expected", FLAG_CASES)
def test_regex_m_flag_is_dotall(jq, query, expected):
    """gojq's m flag means dot-matches-newline, unlike jq's multiline."""
    result = jq(query)
    # CATCHES: m turns . into a dotall dot (a\\nb matches a.b) but does
    # NOT make ^ and $ anchor per line — the opposite of jq's m.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


FLAG_ERROR_CASES = [
    pytest.param('"abc"|test("a";"s")',
                 'gojq: unsupported regular expression flag: "s"',
                 id="s-flag-unsupported"),
    pytest.param('"abc"|test("a";"x")',
                 'gojq: unsupported regular expression flag: "x"',
                 id="x-flag-unsupported"),
    pytest.param('"abc"|test("a";"n")',
                 'gojq: unsupported regular expression flag: "n"',
                 id="n-flag-unsupported"),
    pytest.param('"abc"|test("a";"q")',
                 'gojq: unsupported regular expression flag: "q"',
                 id="unknown-flag-unsupported"),
]


@pytest.mark.parametrize("query,message", FLAG_ERROR_CASES)
def test_regex_unsupported_flags(jq, query, message):
    """Only g, i and m exist; jq's s, x and n flags are rejected."""
    result = jq(query)
    # CATCHES: the whole flag string is echoed in the error, so a
    # re-implementation must reject exactly these three jq flags.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


COMPILE_ERROR_CASES = [
    pytest.param('"a"|test("(unclosed")',
                 'gojq: invalid regular expression "(unclosed": '
                 "error parsing regexp: missing closing ): `(unclosed`",
                 id="unclosed-paren"),
    pytest.param('"a"|test("a[")',
                 'gojq: invalid regular expression "a[": '
                 "error parsing regexp: missing closing ]: `[`",
                 id="unclosed-bracket"),
    pytest.param('"a"|test("(?=a)")',
                 'gojq: invalid regular expression "(?=a)": '
                 "error parsing regexp: invalid or unsupported Perl syntax: `(?=`",
                 id="lookahead-unsupported"),
    pytest.param('"a"|test("a**")',
                 'gojq: invalid regular expression "a**": '
                 "error parsing regexp: invalid nested repetition operator: `**`",
                 id="nested-repetition"),
    pytest.param('"a"|test("\\\\1")',
                 'gojq: invalid regular expression "\\\\1": '
                 "error parsing regexp: invalid escape sequence: `\\1`",
                 id="backreference-unsupported"),
    pytest.param('"aa"|test("(.)\\\\1")',
                 'gojq: invalid regular expression "(.)\\\\1": '
                 "error parsing regexp: invalid escape sequence: `\\1`",
                 id="backreference-in-group-unsupported"),
]


@pytest.mark.parametrize("query,message", COMPILE_ERROR_CASES)
def test_regex_compile_errors(jq, query, message):
    """RE2 rejects jq-style backreferences and look-around at compile."""
    result = jq(query)
    # CATCHES: the error text embeds the pattern and the Go regexp
    # reason verbatim — ``invalid escape sequence`` for \\1 and
    # ``invalid or unsupported Perl syntax`` for (?=) — neither of which
    # jq's Oniguruma would reject.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


TYPE_ERROR_CASES = [
    pytest.param('1|test("a")',
                 'gojq: test("a"; null) cannot be applied to: number (1)',
                 id="test-non-string-input"),
    pytest.param('"a"|test(1)',
                 'gojq: test(1; null) cannot be applied to: string ("a")',
                 id="test-non-string-pattern"),
    pytest.param('"a"|test("a";1)',
                 'gojq: test("a"; 1) cannot be applied to: string ("a")',
                 id="test-non-string-flags"),
    pytest.param('1|match("a")',
                 'gojq: match("a"; null) cannot be applied to: number (1)',
                 id="match-non-string-input"),
    pytest.param('"a"|match(1)',
                 'gojq: match(1; null) cannot be applied to: string ("a")',
                 id="match-non-string-pattern"),
    pytest.param('1|splits("a")',
                 'gojq: match("a"; "g") cannot be applied to: number (1)',
                 id="splits-non-string-input"),
    pytest.param('"a"|splits(1)',
                 'gojq: match(1; "g") cannot be applied to: string ("a")',
                 id="splits-non-string-pattern"),
    pytest.param('"a"|split(1;null)',
                 'gojq: match(1; "g") cannot be applied to: string ("a")',
                 id="split-2-non-string-pattern"),
    pytest.param('splits("a")',
                 'gojq: match("a"; "g") cannot be applied to: null',
                 id="splits-of-null"),
    pytest.param('"a"|split("a";1)',
                 'gojq: cannot add: number (1) and string ("g")',
                 id="split-2-bad-flags-type-error"),
]


@pytest.mark.parametrize("query,message", TYPE_ERROR_CASES)
def test_regex_type_errors(jq, query, message):
    """Regex builtins print the internal _match signature on type errors."""
    result = jq(query)
    # CATCHES: the message shows both arguments with null for omitted
    # flags — test("a"; null) — and splits/split-2 leak their internal
    # g flag as match("a"; "g"); non-string flags even surface the
    # flags + "g" concatenation as a raw addition error.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


def test_regex_error_is_catchable(jq):
    """try/catch receives the invalid-pattern message as a string."""
    result = jq('try ("a"|test("(unclosed")) catch .')
    # CATCHES: the caught value is the bare message text without the
    # gojq: prefix, and the inner quotes survive JSON re-encoding.
    assert (result.returncode, result.out, result.err) == (
        0, '"invalid regular expression \\"(unclosed\\": '
           "error parsing regexp: missing closing ): `(unclosed`\"\n", "")


def test_regex_test_has_no_third_arity(jq):
    """test/3 does not exist even though test/2 does."""
    result = jq('"x"|test("X";"i";"g")')
    # CATCHES: gojq stops at two arguments for test, reporting the
    # missing arity as a compile-time error with exit status 3.
    assert (result.returncode, result.out, result.err) == (
        3, "", "gojq: compile error: function not defined: test/3\n")
