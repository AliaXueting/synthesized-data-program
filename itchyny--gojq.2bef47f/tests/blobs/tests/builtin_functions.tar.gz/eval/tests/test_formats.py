"""The @format builtins: @text, @json, @html, @uri, @csv, @tsv, @sh,
@base64 and @base64d, plus the format/1 dispatcher.

gojq's @base64d keeps binary data (decoding to raw bytes), @html escapes
the single quote as &apos;, and @csv/@tsv reject rows containing
containers.  All expected values were recorded from the reference binary.
"""

import pytest

TEXT_JSON_CASES = [
    pytest.param('"abc"|@text', '"abc"', id="text-of-string"),
    pytest.param("1|@text", '"1"', id="text-of-number"),
    pytest.param("null|@text", '"null"', id="text-of-null"),
    pytest.param("true|@text", '"true"', id="text-of-boolean"),
    pytest.param('{"a":1}|@text', '"{\\"a\\":1}"', id="text-of-object"),
    pytest.param('[1,"a"]|@text', '"[1,\\"a\\"]"', id="text-of-array"),
    pytest.param('"a"|@json', '"\\"a\\""', id="json-of-string"),
    pytest.param('[1,"a"]|@json', '"[1,\\"a\\"]"', id="json-of-array"),
    pytest.param('{"a":1}|@json', '"{\\"a\\":1}"', id="json-of-object"),
    pytest.param("1|@json", '"1"', id="json-of-number"),
]


@pytest.mark.parametrize("query,expected", TEXT_JSON_CASES)
def test_text_and_json_formats(jq, query, expected):
    """@text is tostring; @json is tojson — both produce strings."""
    result = jq(query)
    # CATCHES: @text and @json agree on scalars but differ on strings
    # (@text keeps the string, @json quotes and escapes it).
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,expected", [
    pytest.param('"<a>&\\"\'"|@html', '"&lt;a&gt;&amp;&quot;&apos;"',
                 id="html-escapes-all-five"),
    pytest.param("1|@html", '"1"', id="html-of-number"),
    pytest.param("true|@html", '"true"', id="html-of-boolean"),
    pytest.param("[1]|@html", '"[1]"', id="html-of-array-json"),
    pytest.param('"a b/c?d"|@uri', '"a%20b%2Fc%3Fd"', id="uri-escapes"),
    pytest.param('"日本"|@uri', '"%E6%97%A5%E6%9C%AC"',
                 id="uri-percent-encodes-utf8"),
    pytest.param('"%~ "|@uri', '"%25~%20"', id="uri-tilde-unescaped"),
    pytest.param('{"a":1}|@uri', '"%7B%22a%22%3A1%7D"',
                 id="uri-of-object-json"),
    pytest.param("1|@uri", '"1"', id="uri-of-number"),
    pytest.param("null|@uri", '"null"', id="uri-of-null"),
    pytest.param("true|@uri", '"true"', id="uri-of-boolean"),
    pytest.param('"~"|@uri', '"~"', id="uri-keeps-tilde"),
    pytest.param('"\\u0080"|@uri', '"%C2%80"', id="uri-of-latin1"),
    pytest.param('[1,"a"]|@uri', '"%5B1%2C%22a%22%5D"',
                 id="uri-of-array-json"),
])
def test_html_and_uri_formats(jq, query, expected):
    """@html and @uri escape their input per the recorded rules."""
    result = jq(query)
    # CATCHES: gojq's @html also escapes the single quote (&apos;),
    # while @uri leaves ~ unescaped (RFC 3986 unreserved) but encodes
    # every other non-alphanumeric byte of the UTF-8 form.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


CSV_TSV_CASES = [
    pytest.param('[1,"<b>"]|@csv', '"1,\\"<b>\\""', id="csv-quotes-strings"),
    pytest.param('["a\\"b"]|@csv', '"\\"a\\"\\"b\\""', id="csv-doubles-quotes"),
    pytest.param("[null]|@csv", '""', id="csv-null-empty"),
    pytest.param("[true,false]|@csv", '"true,false"', id="csv-booleans"),
    pytest.param("[1.5]|@csv", '"1.5"', id="csv-floats"),
    pytest.param("[]|@csv", '""', id="csv-empty-row"),
    pytest.param('[1,"a\\tb"]|@tsv', '"1\\ta\\\\tb"', id="tsv-tab-separated"),
    pytest.param('["a\\tb"]|@tsv', '"a\\\\tb"', id="tsv-escapes-embedded-tab"),
    pytest.param("[null]|@tsv", '""', id="tsv-null-empty"),
    pytest.param("[]|@tsv", '""', id="tsv-empty-row"),
]


@pytest.mark.parametrize("query,expected", CSV_TSV_CASES)
def test_csv_tsv_formats(jq, query, expected):
    """@csv and @tsv render rows with their quoting conventions."""
    result = jq(query)
    # CATCHES: null renders as the empty field in both, CSV doubles
    # embedded quotes while TSV backslash-escapes tabs and newlines.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('{"a":1}|@csv',
                 'gojq: @csv cannot be applied to: object ({"a":1})',
                 id="csv-of-object"),
    pytest.param('"x"|@csv', 'gojq: @csv cannot be applied to: string ("x")',
                 id="csv-of-string"),
    pytest.param("[[1]]|@csv",
                 "gojq: @csv cannot format an array including: array ([1])",
                 id="csv-row-with-array"),
    pytest.param('{"a":1}|@tsv',
                 'gojq: @tsv cannot be applied to: object ({"a":1})',
                 id="tsv-of-object"),
])
def test_csv_tsv_row_errors(jq, query, message):
    """@csv/@tsv demand an array of scalars and name the bad element."""
    result = jq(query)
    # CATCHES: a non-array input and an array with a container element
    # produce two different message shapes — ``cannot be applied to``
    # versus ``cannot format an array including``.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


SH_CASES = [
    pytest.param('"it\'s"|@sh', "\"'it'\\\\''s'\"", id="sh-escapes-quotes"),
    pytest.param('["it\'s","$x"]|@sh', "\"'it'\\\\''s' '$x'\"",
                 id="sh-joins-array-elements"),
    pytest.param("[1,true,null]|@sh", '"1 true null"',
                 id="sh-scalars-unquoted"),
    pytest.param('"x"|@sh', "\"'x'\"", id="sh-single-quotes-strings"),
    pytest.param('""|@sh', "\"''\"", id="sh-empty-string"),
    pytest.param("1|@sh", '"1"', id="sh-of-number"),
    pytest.param("null|@sh", '"null"', id="sh-of-null"),
    pytest.param('["日本"]|@sh', "\"'日本'\"", id="sh-of-non-ascii"),
]


@pytest.mark.parametrize("query,expected", SH_CASES)
def test_sh_format(jq, query, expected):
    """@sh single-quotes strings and leaves other scalars bare."""
    result = jq(query)
    # CATCHES: an embedded single quote becomes '\\'' (close quote,
    # escaped quote, reopen quote), and array elements are joined with
    # single spaces.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param("[[]]|@sh",
                 "gojq: @sh cannot format an array including: array ([])",
                 id="sh-row-with-array"),
    pytest.param('[{"a":1}]|@sh',
                 'gojq: @sh cannot format an array including: object ({"a":1})',
                 id="sh-row-with-object"),
])
def test_sh_row_errors(jq, query, message):
    """@sh rejects container elements inside its input array."""
    result = jq(query)
    # CATCHES: @sh only accepts scalars inside the array, mirroring
    # @csv/@tsv, with the ``cannot format an array including`` message.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


BASE64_CASES = [
    pytest.param('"abc"|@base64', '"YWJj"', id="base64-of-string"),
    pytest.param('""|@base64', '""', id="base64-of-empty"),
    pytest.param("1|@base64", '"MQ=="', id="base64-of-number"),
    pytest.param("[1,2]|@base64", '"WzEsMl0="', id="base64-of-array"),
    pytest.param('{"a":1}|@base64', '"eyJhIjoxfQ=="', id="base64-of-object"),
    pytest.param('"YWJj"|@base64d', '"abc"', id="base64d-of-text"),
    pytest.param('"aGVsbG8="|@base64d', '"hello"', id="base64d-hello"),
    pytest.param("[1,2,3]|@base64|@base64d", '"[1,2,3]"',
                 id="base64-roundtrip"),
    pytest.param('"//4="|@base64d|@base64', '"//4="',
                 id="binary-roundtrip-preserves-bytes"),
    pytest.param('"/w=="|@base64d', '"\\ufffd"',
                 id="binary-decoded-as-utf8-escaped"),
    pytest.param("@base64d", '"\\ufffd\\ufffde"',
                 id="base64d-of-null-input"),
]


@pytest.mark.parametrize("query,expected", BASE64_CASES)
def test_base64_formats(jq, query, expected):
    """@base64 encodes; @base64d decodes keeping binary bytes."""
    result = jq(query)
    # CATCHES: gojq's @base64d allows binary results (jq#1931 fix) —
    # bytes that are not valid UTF-8 print as \\ufffd escapes when JSON
    # encoded, and re-encoding gives back the identical base64 text.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_base64d_raw_output_keeps_binary_bytes(jq):
    """With -r, @base64d writes the decoded bytes verbatim."""
    result = jq('"/w=="|@base64d', flags=("-r",))
    # CATCHES: raw output mode must emit the single 0xff byte unchanged
    # (plus the trailing newline) instead of a replacement character.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"\xff\n", b"")


@pytest.mark.parametrize("query,message", [
    pytest.param('"!!!"|@base64d',
                 'gojq: @base64d cannot be applied to "!!!": '
                 "illegal base64 data at input byte 0",
                 id="invalid-alphabet"),
    pytest.param('"[1,2,3]"|@base64d',
                 'gojq: @base64d cannot be applied to "[1,2,3]": '
                 "illegal base64 data at input byte 0",
                 id="punctuation-in-input"),
    pytest.param("1|@base64d",
                 "gojq: @base64d cannot be applied to 1: "
                 "illegal base64 data at input byte 0",
                 id="non-string-input"),
])
def test_base64d_errors(jq, query, message):
    """@base64d failures use the Go decoder's error wording."""
    result = jq(query)
    # CATCHES: non-string inputs are stringified first (1 becomes "1")
    # and then fail with the byte offset of the first illegal character.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


FORMAT_DISPATCH_CASES = [
    pytest.param('[1,2]|format("csv")', '"1,2"', id="format-csv"),
    pytest.param('"a"|format("text")', '"a"', id="format-text"),
    pytest.param("1|format(\"json\")", '"1"', id="format-json"),
    pytest.param('"hello"|@base64 "\\(.)"', '"aGVsbG8="',
                 id="format-string-interpolation"),
    pytest.param('1|@text "n=\\(.)"', '"n=1"',
                 id="text-interpolation-of-number"),
    pytest.param('"\\(.) world"|@text', '"null world"',
                 id="interpolation-sees-input"),
    pytest.param('"@base64 \\(.)"|@base64', '"QGJhc2U2NCBudWxs"',
                 id="literal-at-in-format-string"),
]


@pytest.mark.parametrize("query,expected", FORMAT_DISPATCH_CASES)
def test_format_dispatcher_and_interpolation(jq, query, expected):
    """format/1 selects a format; @fmt "..." interpolates into it."""
    result = jq(query)
    # CATCHES: a literal @ inside a format string needs no escape, the
    # interpolation runs against the current input, and the whole string
    # (not each fragment) is then formatted.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_format_unknown_name(jq):
    """An unregistered format name is a runtime error naming it."""
    result = jq('[1,2]|format("bogus")')
    # CATCHES: the error prints the missing format with an @ prefix even
    # though the caller passed the bare name, and exits 5.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: format not defined: @bogus\n")


def test_format_applies_to_null_input(jq):
    """@csv of null still validates the row shape."""
    result = jq("format(\"csv\")")
    # CATCHES: format/1 does not special-case null — the row check runs
    # and fails with the standard cannot-be-applied-to message.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: @csv cannot be applied to: null\n")
