"""Generator builtins: range, limit, first/last, nth, skip, while, until,
repeat, isempty, select, recurse, empty and not.

These are defined in jq itself inside builtin.jq, so their exact output
order and their hand-written error strings are pinned here.  All expected
values were recorded from the reference binary.
"""

import pytest

RANGE_CASES = [
    pytest.param("[range(3)]", "[0,1,2]", id="one-arity-counts-from-zero"),
    pytest.param("[range(1;4)]", "[1,2,3]", id="two-arity-exclusive-end"),
    pytest.param("[range(0;10;3)]", "[0,3,6,9]", id="three-arity-step"),
    pytest.param("[range(0;1;0.25)]", "[0,0.25,0.5,0.75]", id="float-step"),
    pytest.param("[range(5;0;-2)]", "[5,3,1]", id="negative-step-descends"),
    pytest.param("[range(0)]", "[]", id="empty-range"),
    pytest.param("[range(3;1)]", "[]", id="reversed-bounds-empty"),
    pytest.param("[range(0;5;0)]", "[]", id="zero-step-is-empty"),
    pytest.param("[range(0;3;1.5)]", "[0,1.5]", id="step-past-end-stops"),
    pytest.param("[range(-2;3)]", "[-2,-1,0,1,2]", id="negative-start"),
    pytest.param("[range(3;0;-1.5)]", "[3,1.5]", id="negative-float-step"),
]


@pytest.mark.parametrize("query,expected", RANGE_CASES)
def test_range(jq, query, expected):
    """range emits every value from start to end exclusive, stepping."""
    result = jq(query)
    # CATCHES: the end is exclusive, a zero step yields nothing at all
    # (rather than looping), and float steps stop before crossing the end.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


LIMIT_CASES = [
    pytest.param("[limit(2; 1,2,3)]", "[1,2]", id="takes-first-n"),
    pytest.param("[limit(0; 1,2)]", "[]", id="zero-limit-empty"),
    pytest.param("[limit(3; 1,2)]", "[1,2]", id="limit-above-length"),
    pytest.param("[limit(1.5; 1,2,3)]", "[1,2]", id="float-limit-truncated"),
    pytest.param("[first(1,2,3)]", "[1]", id="first-takes-one"),
    pytest.param("[last(1,2,3)]", "[3]", id="last-takes-final"),
    pytest.param("[first(empty)]", "[]", id="first-of-empty"),
    pytest.param("[last(empty)]", "[]", id="last-of-empty"),
    pytest.param("[nth(0; 1,2,3)]", "[1]", id="nth-zero-is-first"),
    pytest.param("[nth(1; 1,2,3)]", "[2]", id="nth-indexes-from-zero"),
    pytest.param("[nth(5; 1,2,3)]", "[]", id="nth-past-end-empty"),
    pytest.param("[skip(0; 1,2)]", "[1,2]", id="skip-zero-keeps-all"),
    pytest.param("[skip(2; 1,2,3)]", "[3]", id="skip-drops-first-n"),
    pytest.param("[skip(9; 1,2)]", "[]", id="skip-past-end-empty"),
]


@pytest.mark.parametrize("query,expected", LIMIT_CASES)
def test_limit_first_nth_skip(jq, query, expected):
    """limit/first/last/nth/skip window an upstream generator."""
    result = jq(query)
    # CATCHES: nth indexes from zero, first/last of an empty generator
    # produce nothing (not null), and a float limit is applied by count.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param("[limit(-1; 1,2)]",
                 "gojq: error: limit doesn't support negative count",
                 id="negative-limit"),
    pytest.param("[skip(-1; 1,2)]",
                 "gojq: error: skip doesn't support negative count",
                 id="negative-skip"),
    pytest.param("[nth(-1; 1,2,3)]",
                 "gojq: error: nth doesn't support negative index",
                 id="negative-nth"),
])
def test_negative_counts_error(jq, query, message):
    """Negative counts raise jq-level errors with fixed wording."""
    result = jq(query)
    # CATCHES: these are user-visible error() calls from builtin.jq with
    # exactly this apostrophe-free phrasing and exit status 5.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


LOOP_CASES = [
    pytest.param("1|[while(.<100;.*2)]", "[1,2,4,8,16,32,64]",
                 id="while-doubles-until-bound"),
    pytest.param("3|[while(.<10; .+3)]", "[3,6,9]", id="while-adds-three"),
    pytest.param("[.,1]|until(.[0]>4; [.[0]+1,.[1]])", "[5,1]",
                 id="until-stops-after-condition"),
    pytest.param("[limit(3;repeat(\"x\"))]", '["x","x","x"]',
                 id="repeat-is-infinite-but-limitable"),
    pytest.param("[isempty(empty)]", "[true]", id="isempty-of-empty"),
    pytest.param("[isempty(1,2)]", "[false]", id="isempty-of-generator"),
]


@pytest.mark.parametrize("query,expected", LOOP_CASES)
def test_while_until_repeat_isempty(jq, query, expected):
    """while/until/repeat/isempty implement the jq-defined loops."""
    result = jq(query)
    # CATCHES: while emits the seed before each update, until emits only
    # the final value, and repeat never terminates without limit/first.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


RECURSE_CASES = [
    pytest.param("[recurse]", "[null]", id="recurse-on-scalar"),
    pytest.param("[1,[2]]|[recurse]", "[[1,[2]],1,[2],2]",
                 id="recurse-defaults-to-children"),
    pytest.param("[1,[2]]|[recurse(.[]?)]", "[[1,[2]],1,[2],2]",
                 id="recurse-with-filter"),
    pytest.param("0|[recurse(.+1; .<4)]", "[0,1,2,3]",
                 id="recurse-with-condition"),
    pytest.param("0|[recurse(if .<3 then .+1 else empty end)]", "[0,1,2,3]",
                 id="recurse-filter-ending-in-empty"),
    pytest.param('[1,[2,[3]]]|[recurse|scalars]', "[1,2,3]",
                 id="recurse-composes-with-scalars"),
]


@pytest.mark.parametrize("query,expected", RECURSE_CASES)
def test_recurse(jq, query, expected):
    """recurse walks a structure depth-first, emitting every descendant."""
    result = jq(query)
    # CATCHES: the parent is emitted before its children (pre-order),
    # the 2-arity form stops recursing when the condition fails, and
    # recurse is the same as .. for iteration purposes.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


SELECT_CASES = [
    pytest.param("[1,2,3]|[.[]|select(.>1)]", "[2,3]", id="select-filters"),
    pytest.param("[1,2,3]|[.[]|select(.>9)]", "[]", id="select-none"),
    pytest.param('[1,"a",2]|[.[]|select(type=="number")]', "[1,2]",
                 id="select-on-type"),
    pytest.param("[empty]", "[]", id="empty-produces-nothing"),
    pytest.param("[1,2]|[.[]|not]", "[false,false]", id="not-of-numbers"),
    pytest.param("null|not", "true", id="not-of-null"),
    pytest.param("false|not", "true", id="not-of-false"),
    pytest.param("1|not", "false", id="not-of-truthy"),
    pytest.param('""|not', "false", id="not-of-empty-string"),
    pytest.param("0|not", "false", id="not-of-zero"),
    pytest.param("[]|not", "false", id="not-of-empty-array"),
]


@pytest.mark.parametrize("query,expected", SELECT_CASES)
def test_select_empty_not(jq, query, expected):
    """select, empty and not follow jq truthiness (null/false falsy)."""
    result = jq(query)
    # CATCHES: only null and false are falsy — 0, "" and [] are truthy —
    # and empty yields no output at all, not null.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_limit_propagates_upstream_error(jq):
    """An error inside a limited generator aborts the whole query."""
    result = jq('[limit(2; 1,error("x"),3)]')
    # CATCHES: limit cannot swallow errors raised by its generator — the
    # query dies after emitting nothing, with status 5.
    assert (result.returncode, result.out, result.err) == (5, "", "gojq: error: x\n")


def test_recurse_filter_error_propagates(jq):
    """recurse(f) surfaces iteration errors from f itself."""
    result = jq("[1,[2]]|[recurse(.[])]")
    # CATCHES: unlike recurse/0 (which uses .[]? and stops at leaves),
    # the explicit recurse(.[]) fails when it tries to iterate a number.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: cannot iterate over: number (1)\n")
