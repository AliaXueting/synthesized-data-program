"""Type and shape introspection builtins: type, length, utf8bytelength,
keys, has, in, contains, inside, indices/index/rindex and add.

gojq sorts object keys everywhere (it keeps no insertion order), does not
implement ``keys_unsorted`` at all, and rejects several inputs that jq
silently accepts (``null|ltrimstr``, ``has`` on arrays with string keys).
Every expectation below was recorded from the reference binary.
"""

import pytest

# (query, expected stdout line) pairs for value-shape checks.
SHAPE_CASES = [
    pytest.param('[1,"a",null,true,[],{}]|map(type)',
                 '["number","string","null","boolean","array","object"]',
                 id="type-of-every-json-kind"),
    pytest.param('"hello"|length', "5", id="length-of-string"),
    pytest.param("[]|length", "0", id="length-of-empty-array"),
    pytest.param("{}|length", "0", id="length-of-empty-object"),
    pytest.param("null|length", "0", id="length-of-null-is-zero"),
    pytest.param("3.14|length", "3.14", id="length-of-number-is-itself"),
    pytest.param('"日本語"|utf8bytelength', "9", id="utf8bytelength-of-multibyte"),
    pytest.param('"abc"|utf8bytelength', "3", id="utf8bytelength-of-ascii"),
    pytest.param('{"b":1,"a":2}|keys', '["a","b"]', id="keys-sorts-object-keys"),
    pytest.param("[9,8,7]|keys", "[0,1,2]", id="keys-of-array-are-indices"),
    pytest.param('{"a":{"c":1,"b":2}}|keys', '["a"]', id="keys-of-nested-object"),
    pytest.param('{"b":1,"a":2}|has("a")', "true", id="has-present-key"),
    pytest.param('{"b":1,"a":2}|has("z")', "false", id="has-absent-key"),
    pytest.param("[10,20]|has(1)", "true", id="has-in-range-index"),
    pytest.param("[10,20]|has(2)", "false", id="has-out-of-range-index"),
    pytest.param('null|has("a")', "false", id="has-on-null-is-false"),
    pytest.param('"a"|in({"a":1})', "true", id="in-present-key"),
    pytest.param('"z"|in({"a":1})', "false", id="in-absent-key"),
    pytest.param("0|in([true])", "true", id="in-array-index-hit"),
    pytest.param("2|in([true])", "false", id="in-array-index-miss"),
    pytest.param('"foobar"|contains("oob")', "true", id="contains-substring"),
    pytest.param('"foobar"|contains("z")', "false", id="contains-substring-miss"),
    pytest.param("[1,2,3]|contains([2])", "true", id="contains-array-member"),
    pytest.param("[1,2,3]|contains([2,3])", "true", id="contains-array-run"),
    pytest.param("[[1,2]]|contains([[1]])", "true", id="contains-is-recursive"),
    pytest.param('{"a":1,"b":2}|contains({"b":2})', "true", id="contains-object-subset"),
    pytest.param('{"a":1}|contains({"a":2})', "false", id="contains-object-value-mismatch"),
    pytest.param("[1,2]|inside([1,2,3])", "true", id="inside-array"),
    pytest.param('"ell"|inside("hello")', "true", id="inside-string"),
    pytest.param('{"a":1}|inside({"a":1,"b":2})', "true", id="inside-object"),
    pytest.param('"abab"|indices("b")', "[1,3]", id="indices-all-substring-offsets"),
    pytest.param('"abab"|index("b")', "1", id="index-first-offset"),
    pytest.param('"abab"|rindex("b")', "3", id="rindex-last-offset"),
    pytest.param("[0,1,2,1]|indices(1)", "[1,3]", id="indices-array-member"),
    pytest.param("[0,1,2,1]|indices([1,2])", "[1]", id="indices-array-subsequence"),
    pytest.param('"abc"|index("")', "null", id="index-empty-string-is-null"),
    pytest.param('"abc"|indices("")', "[]", id="indices-empty-string-is-empty"),
    pytest.param("[1,2]|index([1])", "0", id="index-of-subarray"),
    pytest.param("[[],[]]|indices([])", "[]", id="indices-empty-needle-array"),
]


@pytest.mark.parametrize("query,expected", SHAPE_CASES)
def test_type_shape_value(jq, query, expected):
    """Each shape builtin produces the recorded value for the given input."""
    result = jq(query)
    # CATCHES: pin exact values — keys sorts object keys, utf8bytelength
    # counts bytes not codepoints, index("") is null while indices("") is
    # empty, and indices() reports runs of subarrays as single offsets.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_length_rejects_boolean(jq):
    """length on a boolean fails with the gojq type-error wording."""
    result = jq("true|length")
    # CATCHES: gojq formats type errors as ``<fn> cannot be applied to:
    # <type> (<preview>)`` and exits 5, unlike jq's exit code 5 wording.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: length cannot be applied to: boolean (true)\n")


def test_utf8bytelength_rejects_number(jq):
    """utf8bytelength refuses non-string inputs with exit status 5."""
    result = jq("1|utf8bytelength")
    # CATCHES: utf8bytelength is string-only; numbers are rejected with the
    # function-name-prefixed error instead of being coerced or ignored.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: utf8bytelength cannot be applied to: number (1)\n")


def test_keys_rejects_scalar(jq):
    """keys on a scalar input produces the recorded diagnostic per type."""
    result = jq("1|keys")
    # CATCHES: keys errors on numbers (and strings) rather than returning
    # null as some implementations do; the message names the input type.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: keys cannot be applied to: number (1)\n")


def test_keys_unsorted_is_not_implemented(jq):
    """gojq has no keys_unsorted; it is a compile error, not a runtime one."""
    result = jq('{"b":1,"a":2}|keys_unsorted')
    # CATCHES: the missing builtin fails at compile time with exit status 3
    # (not 5) and the ``function not defined: keys_unsorted/0`` message.
    assert (result.returncode, result.out, result.err) == (
        3, "", "gojq: compile error: function not defined: keys_unsorted/0\n")


def test_has_string_key_on_array_errors(jq):
    """has with a string key against an array is a type error."""
    result = jq('[1]|has("a")')
    # CATCHES: gojq validates the key type against the container, so
    # has("a") on an array is rejected instead of returning false.
    assert (result.returncode, result.out, result.err) == (
        5, "", 'gojq: has("a") cannot be applied to: array ([1])\n')


@pytest.mark.parametrize("query,message", [
    pytest.param('[1,2]|contains("1")',
                 'gojq: contains("1") cannot be applied to: array ([1,2])',
                 id="string-needle-into-array"),
    pytest.param('"abc"|contains(1)',
                 'gojq: contains(1) cannot be applied to: string ("abc")',
                 id="number-needle-into-string"),
    pytest.param("1|inside([1])",
                 "gojq: contains(1) cannot be applied to: array ([1])",
                 id="inside-delegates-to-contains"),
])
def test_contains_type_errors(jq, query, message):
    """contains/inside type mismatches fail with the recorded messages."""
    result = jq(query)
    # CATCHES: contains requires matching needle/input kinds and the error
    # repeats the offending argument inside the function name prefix.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


@pytest.mark.parametrize("query,expected", [
    pytest.param("[1,2,3]|add", "6", id="add-numbers"),
    pytest.param("[]|add", "null", id="add-empty-is-null"),
    pytest.param("{}|add", "null", id="add-empty-object-is-null"),
    pytest.param("[null]|add", "null", id="add-of-null"),
    pytest.param("[null,1,null,2]|add", "3", id="null-is-identity-for-add"),
    pytest.param('{"a":1,"b":2}|add', "3", id="add-iterates-object-values"),
    pytest.param('["a","b"]|add', '"ab"', id="add-concatenates-strings"),
    pytest.param("[[1],[2,3]]|add", "[1,2,3]", id="add-concatenates-arrays"),
    pytest.param('[{"a":{"b":1}},{"c":2}]|add', '{"a":{"b":1},"c":2}',
                 id="add-merges-objects"),
    pytest.param("[true]|add", "true", id="add-single-boolean"),
    pytest.param("[1,2]|add(.[]*10)", "30", id="add-filter-arity"),
])
def test_add_values(jq, query, expected):
    """add folds + over the input, with null as the empty sum."""
    result = jq(query)
    # CATCHES: add treats null as the identity element (null+1==1), sums
    # object values, and the filter-arity add(f) folds the outputs of f
    # (jq 1.7 semantics — add(.[]*10) is needed, add(.*10) sees the array).
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_add_filter_arity_evaluates_against_input(jq):
    """add(f) runs f against the input itself, not against each element."""
    result = jq("[1,2]|add(.*10)")
    # CATCHES: unlike map, add(f) does not iterate — f gets the whole input
    # [1,2], so .*10 fails with an array-times-number error, not 30.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: cannot multiply: array ([1,2]) and number (10)\n")


def test_add_null_identity_stops_at_first_mismatch(jq):
    """null keeps folding but a later type clash still errors."""
    result = jq('[null,1,"a"]|add')
    # CATCHES: null+1 folds to 1 first, so the failure pairs 1 with "a"
    # — the operands in the message are (element, accumulator).
    assert (result.returncode, result.out, result.err) == (
        5, "", 'gojq: cannot add: number (1) and string ("a")\n')


def test_add_of_object_with_scalar_errors(jq):
    """Adding an object to a number inside add reports both operands."""
    result = jq('{"a":{"b":1},"c":2}|add')
    # CATCHES: add over an object folds the VALUES ({"b":1}+2), which is
    # an object-plus-number error — the object is never merged with 2.
    assert (result.returncode, result.out, result.err) == (
        5, "", 'gojq: cannot add: object ({"b":1}) and number (2)\n')


def test_add_type_mismatch(jq):
    """add reports the first pair of values it cannot add."""
    result = jq('[1,"a"]|add')
    # CATCHES: the operand order in the message is (element, accumulator)
    # — ``number (1) and string ("a")`` — pinning the fold direction.
    assert (result.returncode, result.out, result.err) == (
        5, "", 'gojq: cannot add: number (1) and string ("a")\n')


def test_add_of_incompatible_booleans(jq):
    """add of two booleans fails because true+true is not defined."""
    result = jq("[true,true]|add")
    # CATCHES: a single boolean folds with null to itself, but two
    # booleans cannot be added and gojq names both operands in the error.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: cannot add: boolean (true) and boolean (true)\n")


def test_indices_null_needle(jq):
    """indices(null) behaves differently for arrays and strings."""
    array = jq("[1,2]|indices(null)")
    string = jq('"abc"|indices(null)')
    # CATCHES: a null needle is ignored for arrays (empty result) but is a
    # type error for strings, mirroring jq's asymmetry between the two.
    assert (array.returncode, array.out, array.err) == (0, "[]\n", "")
    assert (string.returncode, string.out, string.err) == (
        5, "", 'gojq: indices(null) cannot be applied to: string ("abc")\n')
