"""Shared black-box harness for the gojq builtin-function test suite.

Every test drives the program under test exclusively through its command
line interface, resolving the binary from ``PROGRAMGYM_EXECUTABLE``.  All
expectations embedded in the tests were recorded by running the reference
binary; the diagnostics, exit codes and value formatting are pinned so a
re-implementation has to reproduce them byte for byte.
"""

import os
import subprocess
from pathlib import Path

import pytest


def program_path():
    """Resolve the program under test from $PROGRAMGYM_EXECUTABLE."""
    raw = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not raw:
        pytest.fail("PROGRAMGYM_EXECUTABLE must point at the program under test")
    return str(Path(raw))


class RunResult:
    """Outcome of one black-box invocation of the program."""

    def __init__(self, returncode, stdout, stderr):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

    @property
    def out(self):
        """stdout decoded as text."""
        return self.stdout.decode("utf-8", "surrogateescape")

    @property
    def err(self):
        """stderr decoded as text."""
        return self.stderr.decode("utf-8", "surrogateescape")

    def __repr__(self):
        return "RunResult(rc=%d, stdout=%r, stderr=%r)" % (
            self.returncode, self.stdout, self.stderr)


def pinned_env(home, extra=None):
    """A minimal, deterministic child environment.

    ``TZ`` is pinned so the time zone dependent builtins (``localtime``,
    ``strflocaltime``) are reproducible; tests may override it through
    ``extra``.
    """
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": str(home),
        "TMPDIR": str(home),
        "TZ": "UTC",
    }
    if extra:
        env.update(extra)
    # Coverage instrumentation hook: let the pipeline's GOCOVERDIR reach the
    # child so source coverage of the reference binary can be measured.  The
    # value is made absolute because the child runs with cwd inside tmp_path;
    # a relative GOCOVERDIR would otherwise scatter the coverage files into
    # the throwaway sandbox instead of the pipeline's collection directory.
    cov_env = {"GOCOVERDIR": os.path.abspath(v)
               for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    return env


@pytest.fixture
def jq(tmp_path):
    """Run a jq query through the program under test.

    ``stdin=None`` (the default) adds ``-n`` so the query runs against null
    input; passing a string feeds it on standard input instead.  ``flags``
    carries extra command line options (``-c`` compact output by default,
    ``-r`` for raw strings, ``-L dir`` for module lookups, ...).
    """
    tmp_path.joinpath(".jq").exists()  # touch tmp_path so it is materialised

    def _jq(query, stdin=None, flags=("-c",), extra_env=None, timeout=15):
        if isinstance(stdin, str):
            stdin = stdin.encode("utf-8")
        argv = [program_path()]
        if stdin is None:
            argv.append("-n")
        argv.extend(str(f) for f in flags)
        argv.append(query)
        proc = subprocess.run(
            argv,
            input=stdin if stdin is not None else b"",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(tmp_path),
            env=pinned_env(tmp_path, extra_env),
            timeout=timeout,
        )
        return RunResult(proc.returncode, proc.stdout, proc.stderr)

    return _jq


@pytest.fixture
def write(tmp_path):
    """Create files inside ``tmp_path``; parents are created as needed."""

    def _write(relpath, content):
        path = tmp_path / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, str):
            content = content.encode("utf-8")
        path.write_bytes(content)
        return path

    return _write
