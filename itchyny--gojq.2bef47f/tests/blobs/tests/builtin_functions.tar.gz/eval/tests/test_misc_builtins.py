"""Miscellaneous builtins: halt/halt_error, error handling, debug,
@urid, env/$ENV, the builtins list, INDEX/IN/JOIN, input/inputs, the
jq builtins gojq omits, assorted type errors and datetime edges.

gojq omits several jq 1.7 builtins (keys_unsorted, toarray, $__loc__,
input_line_number, the get_*_origin family) as compile-time errors, and
its halt_error writes strings to stderr raw without a trailing newline.
All expected values below were recorded from the reference binary.
"""

import pytest

HALT_CASES = [
    pytest.param("1,halt,2", 0, "1\n", "",
                 id="halt-stops-rest-of-stream"),
    pytest.param('1,("x"|halt_error)', 5, "1\n", "x",
                 id="halt-error-writes-string-raw"),
    pytest.param("1,(null|halt_error)", 5, "1\n", "",
                 id="halt-error-null-writes-nothing"),
    pytest.param("1|halt_error", 5, "", "1\n",
                 id="halt-error-number-json-newline"),
    pytest.param('{"a":1}|halt_error', 5, "", '{"a":1}\n',
                 id="halt-error-object-json"),
    pytest.param('1,("x"|halt_error(1))', 1, "1\n", "x",
                 id="halt-error-argument-sets-exit-code"),
    pytest.param('"x"|halt_error(0)', 0, "", "x",
                 id="halt-error-zero-exit-is-success"),
    pytest.param('"x"|halt_error("no")', 5, "",
                 'gojq: halt_error cannot be applied to: string ("no")\n',
                 id="halt-error-string-argument-rejected"),
]


@pytest.mark.parametrize("query,code,out,err", HALT_CASES)
def test_halt_family(jq, query, code, out, err):
    """halt and halt_error stop the program with precise stream effects."""
    result = jq(query)
    # CATCHES: values printed before the halt still appear, string
    # payloads reach stderr raw (no added newline) while numbers and
    # objects are JSON encoded with one, and the numeric argument to
    # halt_error becomes the process exit status.
    assert (result.returncode, result.out, result.err) == (code, out, err)


ERROR_VALUE_CASES = [
    pytest.param("null|error", "gojq: error: null", id="error-null"),
    pytest.param("error(null)", "gojq: error: null", id="error-null-argument"),
    pytest.param("1|error", "gojq: error: 1", id="error-number"),
    pytest.param('"msg"|error', "gojq: error: msg", id="error-string"),
    pytest.param('{"a":1}|error', 'gojq: error: {"a":1}', id="error-object"),
]


@pytest.mark.parametrize("query,message", ERROR_VALUE_CASES)
def test_error_values(jq, query, message):
    """error renders its payload after ``gojq: error: `` and exits 5."""
    result = jq(query)
    # CATCHES: a string payload is printed bare (no quotes) while null,
    # numbers and objects use their JSON forms.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


ERROR_CATCH_CASES = [
    pytest.param('try error("x") catch .', '"x"', id="catch-string-payload"),
    pytest.param("try (1|error) catch .", "1", id="catch-number-payload"),
    pytest.param("try (null|error) catch .", "null", id="catch-null-payload"),
    pytest.param('try ({"a":1}|error) catch .a', "1",
                 id="catch-object-and-project-field"),
]


@pytest.mark.parametrize("query,expected", ERROR_CATCH_CASES)
def test_error_is_catchable(jq, query, expected):
    """try/catch receives the error payload as a normal value."""
    result = jq(query)
    # CATCHES: whatever type error carried flows into the catch filter
    # unchanged, so catch .a can reach inside a thrown object.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


STREAM_FILTER_CASES = [
    pytest.param("1,(1|error)?,2", "1\n2\n",
                 id="optional-suppresses-one-element"),
    pytest.param("null|.a?", "null\n", id="optional-of-null-field-is-null"),
    pytest.param("[.[]?]", "[]\n", id="optional-iteration-of-null"),
    pytest.param("[empty]", "[]\n", id="empty-yields-nothing"),
    pytest.param("[1,null,false]|map(values)", "[1,false]\n",
                 id="values-drops-null-keeps-false"),
    pytest.param("[null|values]", "[]\n", id="values-of-null-is-empty"),
]


@pytest.mark.parametrize("query,expected", STREAM_FILTER_CASES)
def test_error_optional_empty_values(jq, query, expected):
    """?, empty and values control which stream elements survive."""
    result = jq(query)
    # CATCHES: the ? operator suppresses only the failing element (its
    # neighbours still print), values keeps false but drops null, and
    # empty produces no elements at all so [empty] is [].
    assert (result.returncode, result.out, result.err) == (0, expected, "")


DEBUG_CASES = [
    pytest.param("1|debug", "1\n", '["DEBUG:",1]\n', id="debug-input"),
    pytest.param("[1,2]|debug|length", "2\n", '["DEBUG:",[1,2]]\n',
                 id="debug-passes-input-through"),
    pytest.param('1|debug("tag")', "1\n", '["DEBUG:","tag"]\n',
                 id="debug-message-arity"),
    pytest.param('[1,2]|debug("a","b")', "[1,2]\n",
                 '["DEBUG:","a"]\n["DEBUG:","b"]\n',
                 id="debug-message-streams"),
]


@pytest.mark.parametrize("query,out,err", DEBUG_CASES)
def test_debug(jq, query, out, err):
    """debug writes ["DEBUG:", value] to stderr and returns its input."""
    result = jq(query)
    # CATCHES: the input flows through debug untouched, and a message
    # argument replaces the input in the stderr line — once per value
    # when the message itself is a stream.
    assert (result.returncode, result.out, result.err) == (0, out, err)


URID_CASES = [
    pytest.param('"a%20b"|@urid', '"a b"', id="urid-decodes-percent-escape"),
    pytest.param('"a+b"|@urid', '"a+b"', id="urid-keeps-plus"),
    pytest.param('"%E6%97%A5"|@urid', '"日"', id="urid-decodes-utf8-bytes"),
    pytest.param("1|@urid", '"1"', id="urid-of-number"),
    pytest.param('"abc"|@urid', '"abc"', id="urid-of-plain-string"),
]


@pytest.mark.parametrize("query,expected", URID_CASES)
def test_urid(jq, query, expected):
    """@urid percent-decodes, unlike @uri which percent-encodes."""
    result = jq(query)
    # CATCHES: %XX sequences become their bytes, a lone + is kept (no
    # form-decoding), and non-string inputs are stringified first.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('"100%"|@urid',
                 'gojq: @urid cannot be applied to "100%": invalid URL escape "%"',
                 id="truncated-escape"),
    pytest.param('"a%2zb"|@urid',
                 'gojq: @urid cannot be applied to "a%2zb": invalid URL escape "%2z"',
                 id="non-hex-escape"),
])
def test_urid_errors(jq, query, message):
    """@urid reports the exact malformed escape it choked on."""
    result = jq(query)
    # CATCHES: the message quotes the full input string and the three
    # offending characters (a lone % counts as a full escape attempt).
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


ENV_CASES = [
    pytest.param("env.TZ", '"UTC"', id="env-reads-pinned-tz"),
    pytest.param("env.PATH", '"/usr/bin:/bin"', id="env-reads-pinned-path"),
    pytest.param("[env.TZ, $ENV.TZ]", '["UTC","UTC"]',
                 id="env-and-env-variable-agree"),
    pytest.param("env|type", '"object"', id="env-is-an-object"),
    pytest.param('$ENV|has("HOME")', "true", id="env-has-home"),
    pytest.param("$ENV|keys == (env|keys)", "true", id="env-keys-identical"),
]


@pytest.mark.parametrize("query,expected", ENV_CASES)
def test_env_variables(jq, query, expected):
    """env and $ENV expose the child process environment."""
    result = jq(query)
    # CATCHES: both spellings read the same environment object, so their
    # key sets are equal even though neither is sorted.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


BUILTINS_CASES = [
    pytest.param("builtins|length", "218", id="builtins-count"),
    pytest.param("builtins|type", '"array"', id="builtins-is-array"),
    pytest.param("builtins|sort==builtins", "true", id="builtins-pre-sorted"),
    pytest.param('builtins|map(select(test("^get_")))|length', "0",
                 id="no-underscore-get-builtins"),
    pytest.param('builtins|map(select(endswith("/0")))|length', "115",
                 id="zero-arity-count"),
]


@pytest.mark.parametrize("query,expected", BUILTINS_CASES)
def test_builtins_list(jq, query, expected):
    """builtins lists every defined function as name/arity strings."""
    result = jq(query)
    # CATCHES: the list is already sorted, contains 218 name/arity
    # entries, and not a single one starts with get_ — the get_jq_origin
    # family simply does not exist here.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


BUILTINS_MEMBERSHIP_CASES = [
    pytest.param('"splits/1"|IN(builtins[])', "true", id="has-splits-1"),
    pytest.param('"splits/2"|IN(builtins[])', "true", id="has-splits-2"),
    pytest.param('"type/0"|IN(builtins[])', "true", id="has-type-0"),
    pytest.param('"explode/0"|IN(builtins[])', "true", id="has-explode-0"),
    pytest.param('"halt/0"|IN(builtins[])', "true", id="has-halt-0"),
    pytest.param('"halt_error/0"|IN(builtins[])', "true", id="has-halt-error-0"),
    pytest.param('"error/0"|IN(builtins[])', "true", id="has-error-0"),
    pytest.param('"error/1"|IN(builtins[])', "true", id="has-error-1"),
    pytest.param('"empty/0"|IN(builtins[])', "true", id="has-empty-0"),
    pytest.param('"debug/0"|IN(builtins[])', "true", id="has-debug-0"),
    pytest.param('"debug/1"|IN(builtins[])', "true", id="has-debug-1"),
    pytest.param('"env/0"|IN(builtins[])', "true", id="has-env-0"),
    pytest.param('"builtins/0"|IN(builtins[])', "true", id="has-builtins-0"),
    pytest.param('"getpath/1"|IN(builtins[])', "true", id="has-getpath-1"),
    pytest.param('"setpath/2"|IN(builtins[])', "true", id="has-setpath-2"),
    pytest.param('"delpaths/1"|IN(builtins[])', "true", id="has-delpaths-1"),
    pytest.param('"sub/2"|IN(builtins[])', "true", id="has-sub-2"),
    pytest.param('"gsub/3"|IN(builtins[])', "true", id="has-gsub-3"),
    pytest.param('"test/2"|IN(builtins[])', "true", id="has-test-2"),
    pytest.param('"match/2"|IN(builtins[])', "true", id="has-match-2"),
    pytest.param('"capture/2"|IN(builtins[])', "true", id="has-capture-2"),
    pytest.param('"scan/2"|IN(builtins[])', "true", id="has-scan-2"),
    pytest.param('"INDEX/2"|IN(builtins[])', "true", id="has-index-2"),
    pytest.param('"JOIN/4"|IN(builtins[])', "true", id="has-join-4"),
    pytest.param('"IN/2"|IN(builtins[])', "true", id="has-in-2"),
    pytest.param('"keys_unsorted/0"|IN(builtins[])', "false",
                 id="lacks-keys-unsorted"),
    pytest.param('"toarray/0"|IN(builtins[])', "false", id="lacks-toarray-0"),
    pytest.param('"toarray/1"|IN(builtins[])', "false", id="lacks-toarray-1"),
    pytest.param('"get_jq_origin/0"|IN(builtins[])', "false",
                 id="lacks-get-jq-origin"),
    pytest.param('"input_line_number/0"|IN(builtins[])', "false",
                 id="lacks-input-line-number"),
]


@pytest.mark.parametrize("query,expected", BUILTINS_MEMBERSHIP_CASES)
def test_builtins_membership(jq, query, expected):
    """Specific name/arity pairs are present in or absent from builtins."""
    result = jq(query)
    # CATCHES: gojq keeps the pre-1.7 key set (no keys_unsorted, no
    # toarray) while still providing the regex family and the INDEX/JOIN
    # helpers with the arities tested elsewhere in this suite.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


INDEX_CASES = [
    pytest.param('[{"a":1}]|INDEX(.a)', '{"1":{"a":1}}', id="index-one-row"),
    pytest.param('[{"a":1},{"a":2}]|INDEX(.a)', '{"1":{"a":1},"2":{"a":2}}',
                 id="index-two-rows"),
    pytest.param("INDEX(range(3); tostring)", '{"0":0,"1":1,"2":2}',
                 id="index-of-stream-argument"),
    pytest.param('["a","b"]|INDEX(tostring;ascii_upcase)',
                 '{"[\\"A\\",\\"B\\"]":"[\\"a\\",\\"b\\"]"}',
                 id="index-expression-receives-whole-input"),
]


@pytest.mark.parametrize("query,expected", INDEX_CASES)
def test_index(jq, query, expected):
    """INDEX builds a lookup object keyed by the index expression."""
    result = jq(query)
    # CATCHES: keys are stringified (numbers become strings) and the
    # stream argument is evaluated against the INPUT, so a whole array
    # becomes a single row whose key is its uppercased string form.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


IN_CASES = [
    pytest.param("1|IN(1,2)", "true", id="in-1-found"),
    pytest.param("1|IN(2,3)", "false", id="in-1-missed"),
    pytest.param("IN(1,2;1)", "true", id="in-2-found"),
    pytest.param("IN(1,2;3)", "false", id="in-2-missed"),
    pytest.param("[1,2][]|IN(1,3)", "true\nfalse",
                 id="in-applied-per-element"),
]


@pytest.mark.parametrize("query,expected", IN_CASES)
def test_in(jq, query, expected):
    """IN/1 and IN/2 test membership in a stream of candidates."""
    result = jq(query)
    # CATCHES: IN/1 tests the input against the stream, IN/2 swaps the
    # order (stream first, target second), and piping a stream through
    # IN evaluates it once per element.
    assert (result.returncode, result.out, result.err) == (
        0, expected + "\n", "")


def test_in_2_stream_is_evaluated(jq):
    """IN/2 evaluates its stream argument against the input."""
    result = jq("2|IN(.[]; 2)")
    # CATCHES: the candidate stream .[] runs with the number 2 as its
    # input, which is not iterable, so the whole call is a type error.
    assert (result.returncode, result.out, result.err) == (
        5, "", "gojq: cannot iterate over: number (2)\n")


JOIN_CASES = [
    pytest.param('[{"a":"1"},{"a":"2"}]|JOIN({"1":{"x":10}}; .a)',
                 '[[{"a":"1"},{"x":10}],[{"a":"2"},null]]',
                 id="join-2-pairs-rows-with-index"),
    pytest.param('[{"a":"1"}]|JOIN({"1":{"x":10}}; .[]; .a)',
                 '[{"a":"1"},{"x":10}]', id="join-3-explicit-stream"),
    pytest.param('[{"a":"1"},{"a":"z"}]|JOIN({"1":{"x":10}}; .[]; .a; '
                 '[.[0], (.[1].x // "none")])',
                 '[{"a":"1"},10]\n[{"a":"z"},"none"]',
                 id="join-4-custom-projection"),
]


@pytest.mark.parametrize("query,expected", JOIN_CASES)
def test_join(jq, query, expected):
    """JOIN pairs each row with its index entry; arity 4 reshapes the pair."""
    result = jq(query)
    # CATCHES: rows missing from the index pair with null, and the 4-arity
    # projection receives [row, index-entry] so // can substitute defaults.
    assert (result.returncode, result.out, result.err) == (
        0, expected + "\n", "")


def test_input_reads_the_next_value(jq):
    """input pulls one more JSON value from the input stream."""
    result = jq("input", stdin="1 2")
    # CATCHES: the first stdin value is consumed as `.` and input reads
    # the second, so the output is 2 — a two-value stream yields one.
    assert (result.returncode, result.out, result.err) == (0, "2\n", "")


def test_input_past_end_is_a_break_error(jq):
    """Reading past the last input value raises a break error, exit 5."""
    result = jq("input", stdin="1")
    # CATCHES: with nothing left to read, gojq fails with the bare
    # message ``gojq: break`` rather than returning null like jq does.
    assert (result.returncode, result.out, result.err) == (5, "", "gojq: break\n")


def test_input_break_error_is_catchable(jq):
    """The break error from a drained input stream can be caught."""
    result = jq("try input catch .", stdin="1")
    # CATCHES: the caught payload is the string "break", proving the
    # error carries a value just like error() does.
    assert (result.returncode, result.out, result.err) == (0, '"break"\n', "")


def test_input_inside_array(jq):
    """input may be called mid-expression to pull further values."""
    result = jq("[.,input,input]", stdin="1 2 3")
    # CATCHES: all three stdin values land in one array: the first as
    # `.` and the next two through the two input calls.
    assert (result.returncode, result.out, result.err) == (0, "[1,2,3]\n", "")


def test_inputs_yields_the_remaining_values(jq):
    """inputs streams every input value after the first."""
    result = jq("[inputs]", stdin="1 2 3")
    # CATCHES: `.` consumes 1 and inputs yields 2 and 3 — the array
    # collects only the remainder, not the whole stream.
    assert (result.returncode, result.out, result.err) == (0, "[2,3]\n", "")


def test_first_inputs_with_null_input(jq):
    """With -n, inputs covers the whole stdin stream."""
    result = jq("first(inputs)", stdin="1 2 3", flags=("-n", "-c"))
    # CATCHES: null input consumes nothing, so inputs starts at the very
    # first value and first truncates the stream after it.
    assert (result.returncode, result.out, result.err) == (0, "1\n", "")


UNIMPLEMENTED_CASES = [
    pytest.param("$__loc__",
                 "gojq: compile error: variable not defined: $__loc__",
                 id="loc-variable"),
    pytest.param("input_line_number",
                 "gojq: compile error: function not defined: input_line_number/0",
                 id="input-line-number"),
    pytest.param("get_jq_origin",
                 "gojq: compile error: function not defined: get_jq_origin/0",
                 id="get-jq-origin"),
    pytest.param("get_prog_origin",
                 "gojq: compile error: function not defined: get_prog_origin/0",
                 id="get-prog-origin"),
    pytest.param("get_search_list",
                 "gojq: compile error: function not defined: get_search_list/0",
                 id="get-search-list"),
    pytest.param("toarray",
                 "gojq: compile error: function not defined: toarray/0",
                 id="toarray"),
]


@pytest.mark.parametrize("query,message", UNIMPLEMENTED_CASES)
def test_unimplemented_builtins(jq, query, message):
    """jq builtins gojq omits fail at compile time with exit 3."""
    result = jq(query)
    # CATCHES: these are name-resolution failures, not runtime errors —
    # $__loc__ is reported as an undefined VARIABLE while the rest are
    # undefined functions with their /0 arity.
    assert (result.returncode, result.out, result.err) == (3, "", message + "\n")


ARITY_ERROR_CASES = [
    pytest.param('frexp("x")',
                 "gojq: compile error: function not defined: frexp/1",
                 id="frexp-arity-1"),
    pytest.param('modf("x")',
                 "gojq: compile error: function not defined: modf/1",
                 id="modf-arity-1"),
    pytest.param('isnan("x")',
                 "gojq: compile error: function not defined: isnan/1",
                 id="isnan-arity-1"),
    pytest.param('isinfinite("x")',
                 "gojq: compile error: function not defined: isinfinite/1",
                 id="isinfinite-arity-1"),
    pytest.param("implode(1)",
                 "gojq: compile error: function not defined: implode/1",
                 id="implode-arity-1"),
    pytest.param("length(1)",
                 "gojq: compile error: function not defined: length/1",
                 id="length-arity-1"),
    pytest.param("keys(1)",
                 "gojq: compile error: function not defined: keys/1",
                 id="keys-arity-1"),
    pytest.param("first(1,2;3)",
                 "gojq: compile error: function not defined: first/2",
                 id="first-arity-2"),
    pytest.param("error(1;2)",
                 "gojq: compile error: function not defined: error/2",
                 id="error-arity-2"),
    pytest.param("range(1;2;3;4)",
                 "gojq: compile error: function not defined: range/4",
                 id="range-arity-4"),
    pytest.param('ascii_downcase("ABC")',
                 "gojq: compile error: function not defined: ascii_downcase/1",
                 id="ascii-downcase-arity-1"),
]


@pytest.mark.parametrize("query,message", ARITY_ERROR_CASES)
def test_wrong_arity_is_compile_error(jq, query, message):
    """Calling a builtin with an arity it lacks fails before running."""
    result = jq(query)
    # CATCHES: the arity in the message is the one the CALLER used, and
    # the status is 3 (compile error) even though the argument types
    # would also be wrong at runtime.
    assert (result.returncode, result.out, result.err) == (3, "", message + "\n")


MATH_TYPE_ERROR_CASES = [
    pytest.param('pow(2;"a")',
                 'gojq: pow cannot be applied to: string ("a")',
                 id="pow-second-argument"),
    pytest.param('ldexp(1;"a")',
                 'gojq: ldexp cannot be applied to: string ("a")',
                 id="ldexp-second-argument"),
    pytest.param('drem(1;"a")',
                 'gojq: drem cannot be applied to: string ("a")',
                 id="drem-second-argument"),
    pytest.param('scalb(1;"a")',
                 'gojq: scalb cannot be applied to: string ("a")',
                 id="scalb-second-argument"),
    pytest.param('fmin("x";1)',
                 'gojq: fmin cannot be applied to: string ("x")',
                 id="fmin-first-argument"),
    pytest.param('fma(1;"a";2)',
                 'gojq: fma cannot be applied to: string ("a")',
                 id="fma-second-argument"),
    pytest.param('fma(1;2;"b")',
                 'gojq: fma cannot be applied to: string ("b")',
                 id="fma-third-argument"),
    pytest.param('"x"|frexp',
                 'gojq: frexp cannot be applied to: string ("x")',
                 id="frexp-of-string"),
    pytest.param('"x"|isnan',
                 'gojq: isnan cannot be applied to: string ("x")',
                 id="isnan-of-string"),
]


@pytest.mark.parametrize("query,message", MATH_TYPE_ERROR_CASES)
def test_math_type_errors(jq, query, message):
    """Two-argument math builtins type-check both arguments."""
    result = jq(query)
    # CATCHES: these math functions report the plain cannot-be-applied
    # form (no argument echo) naming the offending value.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


MISC_TYPE_ERROR_CASES = [
    pytest.param("1|ltrim", "gojq: ltrim cannot be applied to: number (1)",
                 id="ltrim-of-number"),
    pytest.param("1|trim", "gojq: trim cannot be applied to: number (1)",
                 id="trim-of-number"),
    pytest.param('[1]|startswith("a")',
                 'gojq: startswith("a") cannot be applied to: array ([1])',
                 id="startswith-of-array"),
    pytest.param('[1]|endswith("a")',
                 'gojq: endswith("a") cannot be applied to: array ([1])',
                 id="endswith-of-array"),
    pytest.param("1|ascii_upcase",
                 "gojq: ascii_upcase cannot be applied to: number (1)",
                 id="ascii-upcase-of-number"),
    pytest.param("1|bsearch(2)",
                 'gojq: bsearch(2) cannot be applied to: number (1)',
                 id="bsearch-of-number"),
    pytest.param('"a"|bsearch("a")',
                 'gojq: bsearch("a") cannot be applied to: string ("a")',
                 id="bsearch-of-string"),
    pytest.param('{"a":1}|contains("x")',
                 'gojq: contains("x") cannot be applied to: object ({"a":1})',
                 id="contains-object-string"),
    pytest.param('[1]|contains({"a":1})',
                 'gojq: contains({"a":1}) cannot be applied to: array ([1])',
                 id="contains-array-object"),
    pytest.param('"a"|implode',
                 'gojq: implode cannot be applied to: string ("a")',
                 id="implode-of-string"),
    pytest.param('"x"|gmtime',
                 'gojq: gmtime cannot be applied to: string ("x")',
                 id="gmtime-of-string"),
    pytest.param('"x"|strptime(1)',
                 'gojq: strptime(1) cannot be applied to: string ("x")',
                 id="strptime-bad-format-argument"),
    pytest.param('range("a")',
                 'gojq: range cannot be applied to: string ("a")',
                 id="range-of-string"),
    pytest.param('range(1;"a")',
                 'gojq: range cannot be applied to: string ("a")',
                 id="range-2-of-string"),
    pytest.param('"a"|endswith(1)',
                 'gojq: endswith(1) cannot be applied to: string ("a")',
                 id="endswith-number-argument"),
    pytest.param('1|rtrimstr("a")',
                 'gojq: rtrimstr("a") cannot be applied to: number (1)',
                 id="rtrimstr-of-number"),
    pytest.param('1|ltrimstr("a")',
                 'gojq: ltrimstr("a") cannot be applied to: number (1)',
                 id="ltrimstr-of-number"),
    pytest.param("1|rtrim", "gojq: rtrim cannot be applied to: number (1)",
                 id="rtrim-of-number"),
    pytest.param('"a"|split(1)',
                 'gojq: split(1) cannot be applied to: string ("a")',
                 id="split-number-argument"),
    pytest.param('{"a":1}|contains(1)',
                 'gojq: contains(1) cannot be applied to: object ({"a":1})',
                 id="contains-number-needle-into-object"),
    pytest.param("[1]|contains(1)",
                 'gojq: contains(1) cannot be applied to: array ([1])',
                 id="contains-number-needle-into-array"),
    pytest.param("{}|delpaths(1)",
                 'gojq: delpaths(1) cannot be applied to: object ({})',
                 id="delpaths-non-array-paths"),
    pytest.param("1|mktime",
                 "gojq: mktime cannot be applied to: number (1)",
                 id="mktime-of-number"),
    pytest.param("1|flatten",
                 "gojq: flatten cannot be applied to: number (1)",
                 id="flatten-of-number"),
    pytest.param("1|flatten(1)",
                 "gojq: flatten cannot be applied to: number (1)",
                 id="flatten-1-of-number"),
    pytest.param("1|transpose",
                 "gojq: transpose cannot be applied to: number (1)",
                 id="transpose-of-number"),
    pytest.param('[1,{"a":2}]|transpose',
                 'gojq: transpose cannot be applied to: array ([1,{"a":2}])',
                 id="transpose-of-non-array-row"),
]


@pytest.mark.parametrize("query,message", MISC_TYPE_ERROR_CASES)
def test_misc_type_errors(jq, query, message):
    """Assorted builtins reject wrong input types with recorded messages."""
    result = jq(query)
    # CATCHES: one-argument forms echo their argument inside the function
    # name — bsearch(2), contains("x") — while zero-argument ones like
    # ltrim and range do not, and range reports the bad bound either way.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


GMTIME_CASES = [
    pytest.param("253402300799|gmtime", "[9999,11,31,23,59,59,5,364]",
                 id="last-second-of-year-9999"),
    pytest.param("253402300800|gmtime", "[10000,0,1,0,0,0,6,0]",
                 id="year-10000-rolls-over"),
    pytest.param("-62135596802|gmtime", "[0,11,31,23,59,58,0,365]",
                 id="two-seconds-before-year-one"),
    pytest.param("-62135596801.5|gmtime", "[0,11,31,23,59,58.5,0,365]",
                 id="fractional-negative-keeps-subsecond"),
    pytest.param('"-62135596801"|tonumber|gmtime', "[0,11,31,23,59,59,0,365]",
                 id="last-second-of-year-zero"),
    pytest.param("0.5|gmtime", "[1970,0,1,0,0,0.5,4,0]",
                 id="fractional-second-kept-in-seconds-field"),
]


@pytest.mark.parametrize("query,expected", GMTIME_CASES)
def test_gmtime_boundaries(jq, query, expected):
    """gmtime handles years 0 through 10000 and fractional seconds."""
    result = jq(query)
    # CATCHES: the broken-down array uses 0-based months (11 is
    # December), keeps fractional seconds in the seconds field, and
    # rolls from year 9999 to 10000 where jq would stop at 9999.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


@pytest.mark.parametrize("query,message", [
    pytest.param('1e30|strftime("%Y")',
                 'gojq: strftime("%Y") cannot be applied to 1e+30: '
                 "number of seconds is out of range",
                 id="strftime-out-of-range"),
    pytest.param("1e30|gmtime",
                 "gojq: gmtime cannot be applied to 1e+30: "
                 "number of seconds is out of range",
                 id="gmtime-out-of-range"),
])
def test_datetime_out_of_range(jq, query, message):
    """Seconds beyond the representable range are runtime errors."""
    result = jq(query)
    # CATCHES: both functions reject 1e30 with the value echoed as
    # 1e+30 (Go float formatting) and a shared explanatory clause.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


def test_out_of_range_error_is_catchable(jq):
    """The out-of-range strftime error carries its message as a value."""
    result = jq('try (1e30|strftime("%Y")) catch .')
    # CATCHES: catching yields the message text (without the gojq:
    # prefix) re-encoded as a JSON string with the inner quotes escaped.
    assert (result.returncode, result.out, result.err) == (
        0, '"strftime(\\"%Y\\") cannot be applied to 1e+30: '
           'number of seconds is out of range"\n', "")


BROKEN_DOWN_CASES = [
    pytest.param('[2023,10,14,17,13,20,0,0]|strftime("%Y-%m-%d")',
                 '"2023-11-14"', id="strftime-month-is-zero-based"),
    pytest.param('[2023,10,14,17,13,20,0,0]|strflocaltime("%Y-%m-%d %H:%M:%S")',
                 '"2023-11-14 17:13:20"', id="strflocaltime-same-fields"),
    pytest.param('1|strftime("%Y")', '"1970"', id="strftime-of-epoch"),
    pytest.param('1.5|todate', '"1970-01-01T00:00:01Z"',
                 id="todate-truncates-fraction"),
    pytest.param('1.5|todateiso8601', '"1970-01-01T00:00:01Z"',
                 id="todateiso8601-truncates-fraction"),
    pytest.param('""|strptime("")', "[1900,0,1,0,0,0,1,0]",
                 id="empty-format-defaults-to-1900"),
]


@pytest.mark.parametrize("query,expected", BROKEN_DOWN_CASES)
def test_broken_down_datetime(jq, query, expected):
    """Broken-down arrays interpret month as 0-based, like C tm structs."""
    result = jq(query)
    # CATCHES: month 10 renders as November, strflocaltime agrees because
    # TZ is pinned to UTC, fractional seconds are truncated (not
    # rounded) by todate, and an empty strptime format yields year 1900.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


MKTIME_CASES = [
    pytest.param("[1969,11,31,23,59,59,0,0]|mktime", "-1",
                 id="mktime-pre-epoch"),
    pytest.param("[1969,11,31,23,59,59.5,0,0]|mktime", "-0.5",
                 id="mktime-keeps-half-second"),
    pytest.param("[0,0,1,0,0,0,0,0]|mktime", "-62167219200",
                 id="mktime-of-year-zero"),
    pytest.param('"2020-01-01T00:00:00Z"|fromdate|gmtime|mktime',
                 "1577836800", id="fromdate-gmtime-mktime-roundtrip"),
]


@pytest.mark.parametrize("query,expected", MKTIME_CASES)
def test_mktime(jq, query, expected):
    """mktime converts broken-down arrays back to epoch seconds."""
    result = jq(query)
    # CATCHES: fractional seconds survive as fractional epoch values,
    # and year 0 (month 0 = January) converts to a large negative number
    # consistent with the gmtime boundaries above.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


def test_length_counts_codepoints(jq):
    """length of a string counts characters, not UTF-8 bytes."""
    result = jq('"日本語"|length')
    # CATCHES: the string is 9 bytes of UTF-8 but length reports 3, one
    # per codepoint.
    assert (result.returncode, result.out, result.err) == (0, "3\n", "")


LENGTH_ABS_CASES = [
    pytest.param("-5|length", "5", id="length-of-negative-int"),
    pytest.param("-1.5|length", "1.5", id="length-of-negative-float"),
    pytest.param("-9007199254740993|length", "9007199254740993",
                 id="length-of-negative-big-int"),
    pytest.param("-1e300|length", "1e+300",
                 id="length-of-negative-exponent"),
]


@pytest.mark.parametrize("query,expected", LENGTH_ABS_CASES)
def test_length_of_negative_numbers(jq, query, expected):
    """length of a number is its absolute value."""
    result = jq(query)
    # CATCHES: length negates negatives of every numeric representation
    # — int, float, big integer and exponent form — so -1e300 gives
    # 1e+300, and the big integer keeps all 16 digits.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


MIN_MAX_CASES = [
    pytest.param("[3,1,2]|min", "1", id="min-of-array"),
    pytest.param("[3,1,2]|max", "3", id="max-of-array"),
    pytest.param("[]|min", "null", id="min-of-empty-is-null"),
    pytest.param("[]|max", "null", id="max-of-empty-is-null"),
]


@pytest.mark.parametrize("query,expected", MIN_MAX_CASES)
def test_min_max(jq, query, expected):
    """min/max reduce an array to its extreme; empty arrays give null."""
    result = jq(query)
    # CATCHES: unlike some builtins that error on empty input, min and
    # max of [] return null (jq's reduce-with-null-seed behaviour).
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


AGGREGATE_ERROR_CASES = [
    pytest.param("1|group_by(.)", "gojq: cannot iterate over: number (1)",
                 id="group-by-of-number"),
    pytest.param("1|unique_by(.)", "gojq: cannot iterate over: number (1)",
                 id="unique-by-of-number"),
    pytest.param("1|min_by(.)", "gojq: cannot iterate over: number (1)",
                 id="min-by-of-number"),
    pytest.param("1|max_by(.)", "gojq: cannot iterate over: number (1)",
                 id="max-by-of-number"),
    pytest.param("1|sort_by(.)", "gojq: cannot iterate over: number (1)",
                 id="sort-by-of-number"),
]


@pytest.mark.parametrize("query,message", AGGREGATE_ERROR_CASES)
def test_aggregate_builtins_require_arrays(jq, query, message):
    """The *_by/group_by family fails on non-array inputs."""
    result = jq(query)
    # CATCHES: all five share one implementation shape and report the
    # generic cannot-iterate-over error rather than naming themselves.
    assert (result.returncode, result.out, result.err) == (5, "", message + "\n")


FLATTEN_TRANSPOSE_CASES = [
    pytest.param("[[1],[2,3]]|flatten", "[1,2,3]", id="flatten-default-depth"),
    pytest.param("[1,[2,[3,[4]]]]|flatten(1)", "[1,2,[3,[4]]]",
                 id="flatten-depth-one"),
    pytest.param("[1,[2],3]|group_by(type)", "[[[2]],[1,3]]",
                 id="group-by-partitions-in-order"),
    pytest.param("[[1,2],[3,4]]|transpose", "[[1,3],[2,4]]",
                 id="transpose-square"),
    pytest.param("[[1,2],[3]]|transpose", "[[1,3],[2,null]]",
                 id="transpose-ragged-pads-null"),
]


@pytest.mark.parametrize("query,expected", FLATTEN_TRANSPOSE_CASES)
def test_flatten_group_transpose(jq, query, expected):
    """flatten, group_by and transpose reshape arrays."""
    result = jq(query)
    # CATCHES: flatten(1) stops after one nesting level, group_by keeps
    # the sorted key order of the groups, and transposing a ragged
    # matrix pads the short rows with null instead of erroring.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


IS_PREDICATE_CASES = [
    pytest.param("null|isnan", "false", id="isnan-of-null"),
    pytest.param("null|isinfinite", "false", id="isinfinite-of-null"),
    pytest.param('"x"|isinfinite', "false", id="isinfinite-of-string"),
    pytest.param("null|isnormal", "false", id="isnormal-of-null"),
    pytest.param('"x"|isnormal', "false", id="isnormal-of-string"),
]


@pytest.mark.parametrize("query,expected", IS_PREDICATE_CASES)
def test_is_predicates_tolerate_non_numbers(jq, query, expected):
    """isinfinite/isnormal answer false for non-numbers; isnan errors."""
    result = jq(query)
    # CATCHES: the predicates are asymmetric — isinfinite and isnormal
    # return false for null and strings while isnan on a string is the
    # type error tested above (only isnan validates its input).
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")


SHORT_BROKEN_DOWN_CASES = [
    pytest.param('[2023,1]|strftime("%Y")', '"2023"',
                 id="strftime-pads-missing-fields"),
    pytest.param('[2023,1,1,0,0,0,0,0]|strftime("%Y")', '"2023"',
                 id="strftime-of-full-array"),
]


@pytest.mark.parametrize("query,expected", SHORT_BROKEN_DOWN_CASES)
def test_strftime_short_arrays(jq, query, expected):
    """strftime accepts broken-down arrays shorter than six fields."""
    result = jq(query)
    # CATCHES: a two-element [year, month] array is zero-filled to a
    # full timestamp (January 1st, midnight) rather than rejected.
    assert (result.returncode, result.out, result.err) == (0, expected + "\n", "")
