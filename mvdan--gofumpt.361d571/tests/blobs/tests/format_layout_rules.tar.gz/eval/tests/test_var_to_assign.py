"""`var x = v` inside a function body becomes `x := v`.

`applyPre`'s `*ast.DeclStmt` case rewrites a single-spec var declaration with
no type into an assignment, using `:=` unless every name is blank, and joins
the value onto the names' line when no comment separates them.
"""

import pytest
from conftest import assert_idempotent, format_source


def test_var_with_value_becomes_define():
    """`var x = 1` in a body becomes `x := 1`."""
    # CATCHES: the declaration keyword is dropped and `:=` is chosen because
    # at least one name is not the blank identifier.
    src = b"package p\n\nfunc f() {\n\tvar x = 1\n\t_ = x\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tx := 1\n\t_ = x\n}\n"


def test_blank_name_next_to_a_real_one_still_defines():
    """`var x, _ = g()` becomes `x, _ := g()`."""
    # CATCHES: the token is DEFINE as long as any name is not blank, so the
    # blank operand does not force a plain `=`.
    src = b"package p\n\nfunc f() {\n\tvar x, _ = g()\n\t_, _ = x, 0\n}\n\nfunc g() (int, int) { return 0, 0 }\n"
    assert format_source(src) == (
        b"package p\n\nfunc f() {\n\tx, _ := g()\n\t_, _ = x, 0\n}\n\nfunc g() (int, int) { return 0, 0 }\n"
    )


def test_all_blank_names_keep_a_plain_assignment():
    """`var _, _ = g()` becomes `_, _ = g()`."""
    # CATCHES: with every name blank the token stays `=`, since `_, _ :=`
    # would be rejected by the compiler.
    src = b"package p\n\nfunc f() {\n\tvar _, _ = g()\n\t_ = 0\n}\n\nfunc g() (int, int) { return 0, 0 }\n"
    assert format_source(src) == (
        b"package p\n\nfunc f() {\n\t_, _ = g()\n\t_ = 0\n}\n\nfunc g() (int, int) { return 0, 0 }\n"
    )


def test_var_with_an_explicit_type_is_kept():
    """`var x int = 1` cannot become an assignment, so it stays."""
    # CATCHES: a ValueSpec with a type has no assignment equivalent, so the
    # declaration is left untouched.
    src = b"package p\n\nfunc f() {\n\tvar x int = 1\n\t_ = x\n}\n"
    assert format_source(src) == src


def test_value_on_the_next_line_is_joined():
    """`var x =` broken before its value joins onto the new `x :=` line."""
    # CATCHES: the rewrite joins the value's line onto the names' line when
    # nothing sits in between, exactly like a plain assignment.
    src = b"package p\n\nfunc f() {\n\tvar x =\n\t\t1\n\t_ = x\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tx := 1\n\t_ = x\n}\n"


def test_comment_between_names_and_value_blocks_the_join():
    """A comment after the names keeps the value on its own line."""
    # CATCHES: joining across a comment would mis-indent the value, so the
    # rewrite still happens but the lines stay apart.
    src = b"package p\n\nfunc f() {\n\tvar x = // c\n\t\t1\n\t_ = x\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tx := // c\n\t\t1\n\t_ = x\n}\n"


def test_const_statement_in_a_body_is_kept():
    """`const c = 1` inside a body is not rewritten."""
    # CATCHES: only var declarations are rewritten; a const statement has no
    # `:=` equivalent and is left as a declaration.
    src = b"package p\n\nfunc f() {\n\tconst c = 1\n\t_ = c\n}\n"
    assert format_source(src) == src
    assert_idempotent(src)
