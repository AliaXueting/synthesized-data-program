"""Standard-library imports are grouped together at the top of the import list.

`joinStdImports` reorders a grouped import declaration so that every standard
library path comes first, separated from the rest by exactly one blank line.
A path is third-party when its first element contains a dot, starts with
`test/` or `example/`, matches the module path prefix given by -modpath, or
carries a name after a blank line; a commented import is never moved.
"""

import pytest

from conftest import assert_idempotent, format_source, run_gofumpt, scratch_dir


def test_std_import_moves_above_third_party_in_a_group():
    """A std import below a third-party one moves up with a blank separator."""
    # CATCHES: the std group is hoisted above the third-party group even when
    # the source listed the third-party path first, and the empty line that
    # separates the two groups is inserted by gofumpt itself.
    src = b'package p\n\nimport (\n\t"example.com/x"\n\t"fmt"\n)\n'
    assert format_source(src) == b'package p\n\nimport (\n\t"fmt"\n\n\t"example.com/x"\n)\n'
    assert_idempotent(src)


def test_commented_std_import_is_never_moved_up():
    """A std import carrying a doc comment stays below third-party imports."""
    # CATCHES: moving an import would strand its comment, so a commented std
    # import is treated as third-party and keeps its place and its comment.
    src = b'package p\n\nimport (\n\t"example.com/x"\n\n\t// doc\n\t"fmt"\n)\n'
    assert format_source(src) == src
    assert_idempotent(src)


def test_named_import_after_a_blank_line_is_not_grouped_with_std():
    """`name "os"` below a blank line stays in the second group."""
    # CATCHES: a named import that no longer sits in the first group counts as
    # third-party, so it is neither moved up nor merged with the std block.
    src = b'package p\n\nimport (\n\t"fmt"\n\n\tname "os"\n)\n'
    assert format_source(src) == src
    assert_idempotent(src)


def test_dotless_import_paths_count_as_std():
    """A path without a dot or known prefix stays in the std group."""
    # CATCHES: only dotted paths (and test/example/module prefixes) are
    # third-party, so `corp/repo` is treated as std and no blank line is
    # inserted between it and `fmt`.
    src = b'package p\n\nimport (\n\t"corp/repo"\n\t"fmt"\n)\n'
    assert format_source(src) == src
    assert_idempotent(src)


def test_modpath_prefix_demotes_matching_imports_to_third_party():
    """-modpath=corp/repo makes `corp/...` third-party, so `fmt` moves up."""
    # CATCHES: the module path's first element is used as a prefix, so with
    # -modpath=corp/repo the dotless `corp/repo` import is demoted below the
    # std group with a blank separator, the opposite of the plain run.
    src = b'package p\n\nimport (\n\t"corp/repo"\n\t"fmt"\n)\n'
    res = run_gofumpt(["-modpath=corp/repo"], stdin=src, cwd=scratch_dir())
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'package p\n\nimport (\n\t"fmt"\n\n\t"corp/repo"\n)\n'


@pytest.mark.parametrize(
    "modpath",
    ["corp", "corp/repo"],
    ids=["no-slash", "with-slash"],
)
def test_modpath_without_a_slash_is_its_own_prefix(modpath):
    """A single-element -modpath is used whole as the demotion prefix."""
    # CATCHES: `-modpath=corp` has no `/`, so the entire value is the prefix
    # instead of its first element; `corp/util` is demoted below `fmt` with a
    # blank separator exactly as it is under the two-element `-modpath=corp/repo`.
    src = b'package p\n\nimport (\n\t"corp/util"\n\t"fmt"\n)\n'
    res = run_gofumpt(["-modpath=" + modpath], stdin=src, cwd=scratch_dir())
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'package p\n\nimport (\n\t"fmt"\n\n\t"corp/util"\n)\n'


def test_modpath_prefix_matches_exactly_or_with_a_slash():
    """`corporate/util` escapes a `corp` prefix; the exact path `corp` does not."""
    # CATCHES: the prefix matches only the whole path or a `/`-suffixed
    # remainder, so `corporate/util` stays in the std group beside `fmt`
    # while the bare `corp` import is demoted below the blank separator.
    src = (
        b'package p\n\nimport (\n\t"corporate/util"\n\t"corp"\n\t"fmt"\n)\n\n'
        b'func f() { fmt.Println(corporate.X, corp.Y) }\n'
    )
    res = run_gofumpt(["-modpath=corp"], stdin=src, cwd=scratch_dir())
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b'package p\n\nimport (\n\t"corporate/util"\n\t"fmt"\n\n\t"corp"\n)\n\n'
        b'func f() { fmt.Println(corporate.X, corp.Y) }\n'
    )
