"""Single-spec groups are unwrapped and lone declarations are merged.

`removeParens` turns a one-spec `var` group into a lone `var` line (hoisting
any comment inside the group into a doc comment), and the `*ast.File` case of
`applyPre` merges contiguous lone var/const/type/import declarations into one
parenthesized group unless something in between forbids it.
"""

import pytest
from conftest import assert_idempotent, format_source


@pytest.mark.parametrize(
    "src,expected",
    [
        (b"package p\n\nvar (\n\tx = 1\n)\n", b"package p\n\nvar x = 1\n"),
        (b"package p\n\nvar (x = 1)\n", b"package p\n\nvar x = 1\n"),
    ],
    ids=["multiline", "same-line"],
)
def test_single_spec_var_group_is_unwrapped(src, expected):
    """A one-spec var group loses its parentheses."""
    # CATCHES: the group's parentheses are dropped so the declaration prints
    # as a lone `var x = 1`, on one line even when the source used three.
    assert format_source(src) == expected


@pytest.mark.parametrize(
    "src",
    [
        b"package p\n\nconst (\n\tx = 1\n)\n",
        b"package p\n\ntype (\n\tT int\n)\n",
        b'package p\n\nimport (\n\t"fmt"\n)\n',
        b"package p\n\nvar (\n\tx = 1\n\ty = 2\n)\n",
    ],
    ids=["const", "type", "import", "two-specs"],
)
def test_only_single_spec_var_groups_are_unwrapped(src):
    """const, type, import and multi-spec var groups keep their parentheses."""
    # CATCHES: removeParens only acts on a var group holding exactly one
    # spec, so the equivalent const/type/import groups are left alone.
    assert format_source(src) == src


def test_var_group_with_doc_comment_keeps_parentheses():
    """A doc comment above `var (` keeps the group."""
    # CATCHES: the comment documents the group as a whole, so unwrapping it
    # would silently turn the group doc into a lone var's doc.
    src = b"package p\n\n// doc\nvar (\n\tx = 1\n)\n"
    assert format_source(src) == src


def test_comment_inside_var_group_becomes_the_declaration_doc():
    """A comment above the only spec is hoisted above the unwrapped var."""
    # CATCHES: the inner comment cannot stay inside a declaration with no
    # parentheses, so it is joined into the decl's doc comment.
    src = b"package p\n\nvar (\n\t// inner\n\tx = 1\n)\n"
    assert format_source(src) == b"package p\n\n// inner\nvar x = 1\n"


def test_inline_comment_inside_var_group_survives_unwrapping():
    """A comment on the spec's own line stays on that line."""
    # CATCHES: the spec's inline comment moves with the value, so the
    # unwrapped `var x = 1` keeps its trailing comment.
    src = b"package p\n\nvar (\n\tx = 1 // inline\n)\n"
    assert format_source(src) == b"package p\n\nvar x = 1 // inline\n"


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nvar x = 1\nvar y = 2\nvar z = 3\n",
            b"package p\n\nvar (\n\tx = 1\n\ty = 2\n\tz = 3\n)\n",
        ),
        (
            b"package p\n\nconst a = 1\nconst b = 2\n",
            b"package p\n\nconst (\n\ta = 1\n\tb = 2\n)\n",
        ),
        (
            b"package p\n\ntype A int\ntype B string\n",
            b"package p\n\ntype (\n\tA int\n\tB string\n)\n",
        ),
        (
            b'package p\n\nimport "fmt"\nimport "os"\n',
            b'package p\n\nimport (\n\t"fmt"\n\t"os"\n)\n',
        ),
    ],
    ids=["var", "const", "type", "import"],
)
def test_contiguous_lone_declarations_are_merged(src, expected):
    """Touching lone declarations of one kind become a parenthesized group."""
    # CATCHES: the merge covers var, const, type and import alike, and the
    # joined imports are re-sorted into path order.
    assert format_source(src) == expected


def test_blank_line_stops_the_merge():
    """An empty line between two lone vars keeps them apart."""
    # CATCHES: the chain is broken by a blank line unless a doc comment sits
    # directly above the following declaration.
    src = b"package p\n\nvar x = 1\n\nvar y = 2\n"
    assert format_source(src) == src


def test_doc_comment_directly_above_joins_into_the_group():
    """A comment on the line right above the next var is kept inside the group."""
    # CATCHES: a comment without a blank line before it does not break the
    # chain, so it ends up inside the merged group.
    src = b"package p\n\nvar x = 1\n// doc\nvar y = 2\n"
    assert format_source(src) == b"package p\n\nvar (\n\tx = 1\n\t// doc\n\ty = 2\n)\n"


def test_directive_comment_stops_the_merge():
    """A //go:generate directive keeps the declarations separate."""
    # CATCHES: directive comments must stay attached to their own
    # declaration, so a blank line plus a directive breaks the chain.
    src = b"package p\n\nvar x = 1\n\n//go:generate foo\nvar y = 2\n"
    assert format_source(src) == src


def test_cgo_import_is_never_merged():
    """`import "C"` is left as its own declaration."""
    # CATCHES: merging a cgo import would move its C preamble, so it is
    # excluded from the chain even though it is a lone import.
    src = b'package p\n\nimport "C"\nimport "fmt"\n'
    assert format_source(src) == src


def test_const_group_mentioning_iota_is_not_merged():
    """Merging would renumber iota, so those const lines stay apart."""
    # CATCHES: iota counts specs inside a group, so the merge is refused for
    # any const declaration that mentions it.
    src = b"package p\n\nconst a = iota\nconst b = iota\n"
    assert format_source(src) == src


def test_import_merge_refuses_to_orphan_a_comment():
    """Joining imports that would be reordered past a comment is refused."""
    # CATCHES: sorting the merged group would move `"fmt"` above `"os"` and
    # strand the trailing comment, so the two imports stay separate.
    src = b'package p\n\nimport "os"\nimport "fmt" // why\n'
    assert format_source(src) == src


def test_merged_group_absorbs_a_following_lone_var():
    """An unwrapped single-spec group merges with the next lone var line."""
    # CATCHES: single-spec groups are unwrapped first so that a var group and
    # a following lone var line merge in a single pass.
    src = b"package p\n\nvar (\n\tx = 1\n)\nvar y = 2\n"
    assert format_source(src) == b"package p\n\nvar (\n\tx = 1\n\ty = 2\n)\n"
    assert_idempotent(src)


def test_std_and_third_party_imports_are_separated_when_merged():
    """Merged imports keep the standard library group on top with a blank."""
    # CATCHES: the merged group sorts the std import first and inserts a
    # blank line before the third-party import.
    src = b'package p\n\nimport "os"\nimport "github.com/x/y"\n'
    assert format_source(src) == (
        b'package p\n\nimport (\n\t"os"\n\n\t"github.com/x/y"\n)\n'
    )


def test_var_group_with_own_line_comment_unwraps_and_separates():
    """A comment on its own line before `)` survives unwrapping, set apart."""
    # CATCHES: the spec is unwrapped onto the `var` line while the comment
    # keeps a line of its own, and a blank line then separates the two.
    src = b"package p\n\nvar (\n\tx = 1\n\t// c\n)\n"
    assert format_source(src) == b"package p\n\nvar x = 1\n\n// c\n"
    assert_idempotent(src)


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nvar x = 1\nvar y = 2 // c\n",
            b"package p\n\nvar (\n\tx = 1\n\ty = 2 // c\n)\n",
        ),
        (
            b"package p\n\nconst a = 1\nconst b = 2 // c\n",
            b"package p\n\nconst (\n\ta = 1\n\tb = 2 // c\n)\n",
        ),
    ],
    ids=["var", "const"],
)
def test_inline_comment_on_the_last_merged_line_stays_in_the_group(src, expected):
    """A trailing inline comment on the last merged declaration is kept."""
    # CATCHES: the merged group's closing `)` is kept off the commented line
    # so the comment stays attached to its own declaration inside the group.
    assert format_source(src) == expected
    assert_idempotent(src)


def test_imports_with_a_comment_between_merge_when_paths_ascend():
    """Lone imports separated by a comment still merge when sorted order holds."""
    # CATCHES: joining is only refused when sorting would move an import away
    # from its comment; ascending paths keep every spec in place, so the
    # comment simply ends up inside the merged group.
    src = b'package p\n\nimport "b"\n// keep\nimport "c"\n'
    assert format_source(src) == b'package p\n\nimport (\n\t"b"\n\t// keep\n\t"c"\n)\n'
    assert_idempotent(src)


def test_merged_import_group_keeps_a_comment_on_the_last_spec():
    """A trailing inline comment on the last of three imports joins the group."""
    # CATCHES: the group's closing parenthesis starts a line of its own so
    # the inline comment stays on the `"c"` spec it was written on.
    src = b'package p\n\nimport "a"\nimport "b"\nimport "c" // keep\n'
    assert format_source(src) == b'package p\n\nimport (\n\t"a"\n\t"b"\n\t"c" // keep\n)\n'
    assert_idempotent(src)
