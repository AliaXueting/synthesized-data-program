"""Adjacent multiline top-level declarations gain exactly one blank line.

`applyPost`'s `*ast.File` case inserts a newline between two declarations that
both span several printed lines and currently touch; a declaration which prints
on a single line never triggers one.
"""

import pytest
from conftest import assert_idempotent, format_source


def test_two_adjacent_multiline_funcs_are_separated():
    """Two touching multi-line functions get one blank line between them."""
    # CATCHES: plain gofmt leaves them touching; gofumpt adds the separator
    # because both declarations print over more than one line.
    src = b"package p\n\nfunc a() {\n\tprintln(1)\n}\nfunc b() {\n\tprintln(2)\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc a() {\n\tprintln(1)\n}\n\nfunc b() {\n\tprintln(2)\n}\n"
    )


def test_multiline_func_and_single_line_var_are_separated():
    """A multi-line declaration followed by a one-line var still gets one."""
    # CATCHES: the lone var is not merged into anything (there is no other
    # var) and gofmt alone would not separate it from the function.
    src = b"package p\n\nfunc a() {\n\tprintln(1)\n}\nvar x = 1\n"
    assert format_source(src) == b"package p\n\nfunc a() {\n\tprintln(1)\n}\n\nvar x = 1\n"


def test_two_single_line_funcs_stay_touching():
    """Two one-line functions are not separated by a blank line."""
    # CATCHES: only declarations which do not print on a single line take
    # part, so `func f() {}` followed by `func g() {}` stays as written.
    src = b"package p\n\nfunc f() {}\nfunc g() {}\n"
    assert format_source(src) == src


def test_multiline_func_followed_by_single_line_func_stays_touching():
    """A one-line function after a multi-line one keeps touching it."""
    # CATCHES: both neighbours must be multi-line, so the second function
    # being single-line suppresses the separator.
    src = b"package p\n\nfunc f() {\n\tprintln(1)\n}\nfunc g() {}\n"
    assert format_source(src) == src


def test_already_separated_declarations_get_no_second_blank():
    """A single existing blank line is left at exactly one line."""
    # CATCHES: the rule is idempotent - it never doubles an existing
    # separator, and gofmt would collapse two blanks to one anyway.
    src = b"package p\n\nfunc a() {\n\tprintln(1)\n}\n\nfunc b() {\n\tprintln(2)\n}\n"
    assert format_source(src) == src
    assert_idempotent(src)


def test_trailing_inline_comment_extends_the_separator():
    """An inline comment after a function counts as part of its end."""
    # CATCHES: the blank line is inserted after the comment, not between the
    # closing brace and the comment, so the comment stays with its function.
    src = b"package p\n\nfunc a() {\n} // c\nfunc b() {\n}\n"
    assert format_source(src) == b"package p\n\nfunc a() {\n} // c\n\nfunc b() {\n}\n"
