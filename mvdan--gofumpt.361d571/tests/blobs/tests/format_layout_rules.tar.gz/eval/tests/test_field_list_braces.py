"""Field lists: empty brace pairs join, leading/trailing blank lines drop.

`matchBraceLines` puts an empty `struct {}`, `interface{}`, `f()` or `func()`
pair on one line and splits a one-line type go/printer would split anyway,
while `applyPre`'s `*ast.FieldList` and `*ast.InterfaceType` cases remove the
blank lines around the members.
"""

import pytest
from conftest import assert_idempotent, format_source


@pytest.mark.parametrize(
    "src,expected",
    [
        (b"package p\n\ntype T struct {\n}\n", b"package p\n\ntype T struct{}\n"),
        (b"package p\n\ntype I interface {\n}\n", b"package p\n\ntype I interface{}\n"),
        (b"package p\n\nvar v = []int{\n}\n", b"package p\n\nvar v = []int{}\n"),
        (
            b"package p\n\nfunc f() {\n\tg(\n\t)\n}\n",
            b"package p\n\nfunc f() {\n\tg()\n}\n",
        ),
        (
            b"package p\n\nvar f = func(\n) {\n}\n",
            b"package p\n\nvar f = func() {\n}\n",
        ),
    ],
    ids=["struct", "interface", "composite", "call", "func-type"],
)
def test_empty_brace_pairs_join_onto_one_line(src, expected):
    """An empty pair of braces or parentheses prints on a single line."""
    # CATCHES: an empty field list or element list holds no newline, so the
    # closing token is pulled up next to the opening one.
    assert format_source(src) == expected


def test_one_line_struct_with_two_fields_is_split():
    """`struct{ x, y int; z int }` is split onto one field per line."""
    # CATCHES: go/printer will not keep that struct on one line, so gofumpt
    # records the split in the line table and gofmt prints it multi-line.
    src = b"package p\n\ntype T struct{ x, y int; z int }\n"
    assert format_source(src) == b"package p\n\ntype T struct {\n\tx, y int\n\tz    int\n}\n"


def test_struct_holding_only_a_comment_is_split():
    """`struct { /* c */ }` keeps the comment but gains a line break."""
    # CATCHES: the empty field list is joined only when no comment sits in
    # it; with one, the closing brace is pushed onto its own line.
    src = b"package p\n\ntype T struct { /* c */ }\n"
    assert format_source(src) == b"package p\n\ntype T struct { /* c */\n}\n"


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\ntype T struct {\n\n\tA int\n\n\tB int\n\n}\n",
            b"package p\n\ntype T struct {\n\tA int\n\n\tB int\n}\n",
        ),
        (
            b"package p\n\ntype I interface {\n\tA()\n\n\n\tB()\n}\n",
            b"package p\n\ntype I interface {\n\tA()\n\n\tB()\n}\n",
        ),
    ],
    ids=["struct", "interface"],
)
def test_field_lists_drop_outer_blank_lines_only(src, expected):
    """Blank lines just inside the braces go; the inner one collapses to one."""
    # CATCHES: only the lines before the first member and after the last are
    # removed, so the author's separator blank between members survives.
    assert format_source(src) == expected


def test_interface_drops_blank_lines_before_the_first_method():
    """`interface {` followed by blank lines loses them."""
    # CATCHES: the InterfaceType case strips the empty lines between the
    # keyword and the first method, or the first comment if there is one.
    src = b"package p\n\ntype I interface {\n\n\tM()\n}\n"
    assert format_source(src) == b"package p\n\ntype I interface {\n\tM()\n}\n"


def test_interface_blank_after_a_leading_comment_is_kept():
    """A doc comment above the first method stops the blank-line removal."""
    # CATCHES: the removal stops at the first comment, so the blank line that
    # follows it inside the interface body is left in place.
    src = b"package p\n\ntype I interface {\n\t// c\n\n\tM()\n}\n"
    assert format_source(src) == src


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nfunc f(\n\n\ta int) {\n}\n",
            b"package p\n\nfunc f(\n\ta int) {\n}\n",
        ),
        (
            b"package p\n\nfunc f(a int,\n\n\tb int) {\n\tprintln(a, b)\n}\n",
            b"package p\n\nfunc f(a int,\n\n\tb int,\n) {\n\tprintln(a, b)\n}\n",
        ),
        (
            b"package p\n\nfunc f() (\n\n\tint) {\n\treturn 0\n}\n",
            b"package p\n\nfunc f() int {\n\treturn 0\n}\n",
        ),
    ],
    ids=["params-leading", "params-inner", "results-leading"],
)
def test_parameter_and_result_lists_lose_outer_blank_lines(src, expected):
    """A signature's field list also drops its leading and trailing blanks."""
    # CATCHES: the empty lines right after `(` or right before `)` vanish,
    # while an empty line between two parameters is preserved; the `) {` split
    # still happens for a non-empty body but is skipped for an empty one.
    assert format_source(src) == expected
    assert_idempotent(src)
