"""Short case clauses collapse onto a single line.

`applyPost`'s `*ast.CaseClause` case joins the clause's expression list onto
the `case` keyword's line when the clause without its body measures under
`shortLineLimit` (60) bytes, and never moves a comment or the body itself.
"""

import pytest
from conftest import assert_idempotent, format_source


def test_short_case_list_is_joined():
    """A case expression list split over lines is collapsed when short."""
    # CATCHES: the join applies to the clause's expression list only, so
    # `case 1,\\n\\t\\t2:` becomes `case 1, 2:` while the body stays put.
    src = b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase 1,\n\t\t2:\n\t\tprintln(1)\n\t}\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase 1, 2:\n\t\tprintln(1)\n\t}\n}\n"
    )


def test_long_case_list_stays_split():
    """A case list whose rendered clause passes 60 bytes keeps its break."""
    # CATCHES: printLength counts the multi-line rendering plus indentation,
    # so a long pair of string literals is left on two lines.
    src = (
        b'package p\n\nfunc f(x string) {\n\tswitch x {\n'
        b'\tcase "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",\n'
        b'\t\t"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb":\n'
        b"\t\tprintln(1)\n\t}\n}\n"
    )
    assert format_source(src) == src


def test_comment_inside_case_list_keeps_the_split():
    """A comment between `case` and the colon blocks the collapse."""
    # CATCHES: comments are never moved, so a clause broken by one keeps its
    # line break even though it is far shorter than the limit.
    src = b'package p\n\nfunc f(x string) {\n\tswitch x {\n\tcase // c\n\t\t"a":\n\t\tprintln(1)\n\t}\n}\n'
    assert format_source(src) == src


def test_body_on_the_colon_line_moves_down():
    """A one-line case body is pushed onto its own line by gofmt."""
    # CATCHES: the clause collapse never pulls the body up; go/printer always
    # starts the body on the line after the colon.
    src = b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase 1: println(1)\n\t}\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase 1:\n\t\tprintln(1)\n\t}\n}\n"
    )
    assert_idempotent(src)


@pytest.mark.parametrize(
    "body",
    [b"\t\tbody()\n", b""],
    ids=["with-body", "empty-body"],
)
def test_trailing_comment_after_the_colon_joins_the_collapse(body):
    """A `// c` sitting after the colon travels with the collapsed clause."""
    # CATCHES: the comment after the colon is not between `case` and the
    # colon, so the collapse still joins the split expression list and the
    # comment stays on the joined line whether or not the clause has a body.
    src = (
        b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n\t\t1: // c\n"
        + body
        + b"\t}\n}\n"
    )
    expected = (
        b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase 1: // c\n"
        + body
        + b"\t}\n}\n"
    )
    assert format_source(src) == expected
    assert format_source(expected) == expected


@pytest.mark.parametrize(
    "comment,expected",
    [
        (b"", b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase someLongValue1, someLongValue2:\n\t\tbody()\n\t}\n}\n"),
        (
            b" // cccccccc",
            b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n\t\tsomeLongValue1, someLongValue2: // cccccccc\n\t\tbody()\n\t}\n}\n",
        ),
    ],
    ids=["no-comment", "with-comment"],
)
def test_trailing_comment_counts_toward_the_collapse_budget(comment, expected):
    """The bytes of a trailing comment are part of the 60-byte measurement."""
    # CATCHES: the clause without its comment fits the collapse limit and is
    # joined, but appending ` // cccccccc` pushes the measured length over 60
    # so the very same clause keeps its break — the comment is counted.
    src = (
        b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n\t\tsomeLongValue1, someLongValue2:"
        + comment
        + b"\n\t\tbody()\n\t}\n}\n"
    )
    assert format_source(src) == expected
    assert format_source(expected) == expected
