"""The long-line splitter is opt-in through GOFUMPT_SPLIT_LONG_LINES=on.

`splitLongLine` runs for every node but returns immediately unless the
environment variable holds exactly `on`.  It then breaks a single line which
passes `longLineLimit` (100) at the start of a list element, provided both
halves keep at least 40% of the limit.
"""

import pytest
from conftest import format_source, run_gofumpt

SPLIT_ENV = {"GOFUMPT_SPLIT_LONG_LINES": "on"}

BINARY_CONCAT = (
    b'package p\n\nvar s = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"'
    b' + "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"\n'
)
BINARY_CONCAT_SPLIT = (
    b'package p\n\nvar s = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" +\n'
    b'\t"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"\n'
)

WIDE_CALL = (
    b'package p\n\nfunc f() {\n\tprintln("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",'
    b' "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb")\n}\n'
)
WIDE_CALL_SPLIT = (
    b'package p\n\nfunc f() {\n\tprintln("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",\n'
    b'\t\t"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb")\n}\n'
)

COMPOSITE_ARG = (
    b'package p\n\nfunc f() {\n\tSomeFunction(argumentNumber1, argumentNumber2, argumentNumber3,'
    b' []string{"aaaaaaaaaaaaaaaaaaaa", "bbbbbbbbbbbbbbbbbbbbbbbbbbbb", "cccccccccccccccccccc"})\n}\n'
)
COMPOSITE_ARG_SPLIT = (
    b'package p\n\nfunc f() {\n\tSomeFunction(argumentNumber1, argumentNumber2, argumentNumber3, []string{\n'
    b'\t\t"aaaaaaaaaaaaaaaaaaaa", "bbbbbbbbbbbbbbbbbbbbbbbbbbbb", "cccccccccccccccccccc",\n\t})\n}\n'
)

WIDE_IF = (
    b'package p\n\nfunc f() {\n\tif condOnexxxxx && condTwoyyyyy && condThreezzzzz &&'
    b' theFinalVeryLongConditionNameToForceTheSplit {\n\t\tprintln(1)\n\t}\n}\n'
)
WIDE_IF_SPLIT = (
    b'package p\n\nfunc f() {\n\tif condOnexxxxx && condTwoyyyyy && condThreezzzzz &&\n'
    b'\t\ttheFinalVeryLongConditionNameToForceTheSplit {\n\t\tprintln(1)\n\t}\n}\n'
)


def test_splitter_is_disabled_by_default():
    """Without the environment variable the long line is left alone."""
    # CATCHES: the splitter is off unless the variable is set, so a 140-byte
    # concatenation stays on one line in a plain run.
    assert format_source(BINARY_CONCAT) == BINARY_CONCAT
    assert format_source(WIDE_IF) == WIDE_IF


@pytest.mark.parametrize(
    "src,expected",
    [
        (BINARY_CONCAT, BINARY_CONCAT_SPLIT),
        (WIDE_CALL, WIDE_CALL_SPLIT),
        (COMPOSITE_ARG, COMPOSITE_ARG_SPLIT),
        (WIDE_IF, WIDE_IF_SPLIT),
    ],
    ids=["binary-concat", "call-arguments", "composite-argument", "if-condition"],
)
def test_splitter_breaks_long_single_lines_when_enabled(src, expected):
    """With the variable on, overlong lines break before a list element."""
    # CATCHES: the break lands before the operand/argument that starts late
    # enough, and a composite literal breaks before its first element rather
    # than before the literal itself.
    assert format_source(src, env=SPLIT_ENV) == expected


def test_splitter_leaves_lines_that_would_not_shrink_enough():
    """A long if condition whose tail is short stays on one line."""
    # CATCHES: both halves must reach the minimum split length, so a
    # condition ending in a short operand is not split even when enabled.
    src = (
        b"package p\n\nfunc f() {\n\tif someCondition && anotherCondition &&"
        b" yetAnotherCondition && aFourthCondition && aFifthCondition {\n\t\tprintln(1)\n\t}\n}\n"
    )
    assert format_source(src, env=SPLIT_ENV) == src


@pytest.mark.parametrize(
    "value",
    [b"ON", b"1", b"true", b"yes", b"on "],
    ids=["upper", "one", "true", "yes", "trailing-space"],
)
def test_only_the_exact_value_on_enables_the_splitter(value):
    """Any other value of the variable keeps the splitter off."""
    # CATCHES: the switch compares the variable with the exact string "on",
    # so near-miss spellings and padded values are all disabled.
    res = run_gofumpt([], stdin=BINARY_CONCAT, env={"GOFUMPT_SPLIT_LONG_LINES": value.decode()})
    assert res.returncode == 0
    assert res.stdout == BINARY_CONCAT


def test_split_output_is_idempotent():
    """Splitting once is enough: a second pass changes nothing."""
    # CATCHES: the splitter must not keep breaking the already-split line,
    # which would move every operand onto its own line; the first pass equals
    # the recorded split bytes and re-running on them returns the same bytes.
    for src, expected in [
        (BINARY_CONCAT, BINARY_CONCAT_SPLIT),
        (COMPOSITE_ARG, COMPOSITE_ARG_SPLIT),
    ]:
        once = format_source(src, env=SPLIT_ENV)
        assert once == expected
        assert format_source(once, env=SPLIT_ENV) == expected


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b'package p\n\nfunc f() {\n\tSomeFunction(argumentNumber1, argumentNumber2, argumentNumber3,'
            b' &[]string{"aaaaaaaaaaaaaaaaaaaa", "bbbbbbbbbbbbbbbbbbbbbbbbbbbb", "cccccccccccccccccccc"})\n}\n',
            b'package p\n\nfunc f() {\n\tSomeFunction(argumentNumber1, argumentNumber2, argumentNumber3, &[]string{\n'
            b'\t\t"aaaaaaaaaaaaaaaaaaaa", "bbbbbbbbbbbbbbbbbbbbbbbbbbbb", "cccccccccccccccccccc",\n\t})\n}\n',
        ),
        (
            b'package p\n\ntype Options struct{ Field1, Field2, Field3 string }\n\nfunc f() {\n\t'
            b'SomeFunction(argumentNumber1, argumentNumber2, argumentNumber3,'
            b' &Options{Field1: "aaaaaaaaaaaaaaaaaaaa", Field2: "bbbbbbbbbbbbbbbbbbbbbbbb"})\n}\n',
            b'package p\n\ntype Options struct{ Field1, Field2, Field3 string }\n\nfunc f() {\n\t'
            b'SomeFunction(argumentNumber1, argumentNumber2, argumentNumber3, &Options{\n'
            b'\t\tField1: "aaaaaaaaaaaaaaaaaaaa", Field2: "bbbbbbbbbbbbbbbbbbbbbbbb",\n\t})\n}\n',
        ),
    ],
    ids=["slice-literal", "struct-literal"],
)
def test_splitter_breaks_inside_a_pointer_composite_argument(src, expected):
    """A `&T{...}` argument splits before the literal's first element."""
    # CATCHES: the pointer counts as its composite literal, so the break goes
    # before the first element inside the braces rather than before the `&`,
    # and the trailing comma joins the last element's line.
    assert format_source(src, env=SPLIT_ENV) == expected
    assert format_source(expected, env=SPLIT_ENV) == expected


NESTED_CALL = (
    b'package p\n\nfunc f() {\n\txx := outer(prettyLongArgumentName, anotherArg)'
    b'(innerFunction(callArgNumberOne, callArgNumberTwo, callArgNumberThree, argFour))\n}\n'
)
NESTED_CALL_SPLIT = (
    b'package p\n\nfunc f() {\n\txx := outer(prettyLongArgumentName, anotherArg)(\n'
    b'\t\tinnerFunction(callArgNumberOne, callArgNumberTwo, callArgNumberThree, argFour))\n}\n'
)


def test_splitter_prefers_a_break_before_the_whole_nested_call():
    """A nested call argument breaks before the call, not before its own args."""
    # CATCHES: for a call the split point is nudged to the average of the
    # call's start and its first argument, so a call starting at column 49 is
    # still eligible and the break lands after the outer `(`, leaving the
    # whole inner call and its argument list on the second line intact.
    assert format_source(NESTED_CALL, env=SPLIT_ENV) == NESTED_CALL_SPLIT
    assert format_source(NESTED_CALL_SPLIT, env=SPLIT_ENV) == NESTED_CALL_SPLIT
    # The same line is untouched when the splitter is off.
    assert format_source(NESTED_CALL) == NESTED_CALL


BINARY_CHAIN = (
    b'package p\n\nfunc f() {\n\txx := outer(prettyLongArgumentName, anotherArg)'
    b'(operandOne + operandTwo + operandThree + operandFour + operandFive + operandSixxx + operandSeven)\n}\n'
)
BINARY_CHAIN_SPLIT = (
    b'package p\n\nfunc f() {\n\txx := outer(prettyLongArgumentName, anotherArg)'
    b'(operandOne + operandTwo + operandThree +\n'
    b'\t\toperandFour + operandFive + operandSixxx + operandSeven)\n}\n'
)


def test_splitter_breaks_a_binary_chain_where_the_operand_ends_past_the_limit():
    """A `+` chain breaks before the first operand that itself runs past col 100."""
    # CATCHES: eligibility uses each operand's own end column, so the break
    # lands before `operandFour` (the first operand ending past the limit)
    # rather than before `operandTwo`, which starts late but ends too early.
    assert format_source(BINARY_CHAIN, env=SPLIT_ENV) == BINARY_CHAIN_SPLIT
    assert format_source(BINARY_CHAIN_SPLIT, env=SPLIT_ENV) == BINARY_CHAIN_SPLIT


PARAMS_SHORT_TAIL = (
    b'package p\n\nfunc transformTheData(inputStream readerType, outputStream writerType,'
    b' firstOption, secondOption, thirdOptionString string) {\n\t_ = inputStream\n}\n'
)
PARAMS_LONG_TAIL = (
    b'package p\n\nfunc transformTheData(inputStream readerType, outputStream writerType,'
    b' firstOption, secondOption, thirdOptionString string, anotherParameter map[string]string) {\n'
    b'\t_ = inputStream\n}\n'
)
PARAMS_LONG_TAIL_SPLIT = (
    b'package p\n\nfunc transformTheData(inputStream readerType, outputStream writerType,\n'
    b'\tfirstOption, secondOption, thirdOptionString string, anotherParameter map[string]string,\n'
    b') {\n\t_ = inputStream\n}\n'
)


def test_top_level_param_split_needs_a_longer_tail_than_the_default():
    """Top-level func params only split when the tail keeps 60 bytes, not 40."""
    # CATCHES: inside a top-level declaration's parameter list the minimum
    # split factor is raised from 0.4 to 0.6, so a last parameter followed by
    # a 53-byte tail stays on the header line even though a body-level line
    # with the same tail would split.
    assert format_source(PARAMS_SHORT_TAIL, env=SPLIT_ENV) == PARAMS_SHORT_TAIL
    assert format_source(PARAMS_LONG_TAIL, env=SPLIT_ENV) == PARAMS_LONG_TAIL_SPLIT
    assert format_source(PARAMS_LONG_TAIL_SPLIT, env=SPLIT_ENV) == PARAMS_LONG_TAIL_SPLIT


BODY_CALL_MODERATE_TAIL = (
    b'package p\n\nfunc f() {\n\tresult := someFunc(firstArgumentNumber, secondArgumentNumber)'
    b'(thirdArgument, fourthArgument, fifthArgument, sixthArgumentNumber, seventhArgumentNumber)\n}\n'
)
BODY_CALL_MODERATE_TAIL_SPLIT = (
    b'package p\n\nfunc f() {\n\tresult := someFunc(firstArgumentNumber, secondArgumentNumber)'
    b'(thirdArgument, fourthArgument,\n'
    b'\t\tfifthArgument, sixthArgumentNumber, seventhArgumentNumber)\n}\n'
)


def test_body_call_with_a_moderate_tail_still_splits():
    """A body-level call argument list splits with only a 45-byte tail."""
    # CATCHES: the default 0.4 factor applies outside parameter lists, so the
    # same tail length that kept the top-level parameters on one line is
    # enough to break this call after `fourthArgument`.
    assert format_source(BODY_CALL_MODERATE_TAIL, env=SPLIT_ENV) == (
        BODY_CALL_MODERATE_TAIL_SPLIT
    )
    assert format_source(BODY_CALL_MODERATE_TAIL_SPLIT, env=SPLIT_ENV) == (
        BODY_CALL_MODERATE_TAIL_SPLIT
    )
