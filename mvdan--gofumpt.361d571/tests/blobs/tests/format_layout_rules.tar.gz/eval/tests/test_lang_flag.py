"""The -lang flag feeds the language version every rule is gated on.

`format.File` normalises a non-empty LangVersion through `goversion.Lang`
before any rule runs; an unparseable version is a hard panic from the
formatting pass itself (exit status 2, empty stdout), not a flag-parse error.
"""

import pytest
from conftest import format_source, run_gofumpt, scratch_dir

LAYOUT_INPUT = (
    b"package p\n\nvar x = 1\n\nfunc f(a int,\n b int) {\n\n\t_ = a\n\n}\n"
)
LAYOUT_EXPECTED = (
    b"package p\n\nvar x = 1\n\nfunc f(a int,\n\tb int,\n) {\n\t_ = a\n}\n"
)


@pytest.mark.parametrize(
    "lang",
    ["go1.16", "go1.21.3", "go1"],
    ids=["minor", "patch", "bare"],
)
def test_valid_lang_versions_still_apply_the_layout_rules(lang):
    """Any parseable -lang value leaves the default layout rules in force."""
    # CATCHES: a valid version only gates version-specific rules, so the
    # multiline signature still gains its trailing comma and `) {` line, and
    # the body still loses its leading and trailing blank lines.
    res = run_gofumpt(["-lang=" + lang], stdin=LAYOUT_INPUT, cwd=scratch_dir())
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == LAYOUT_EXPECTED


@pytest.mark.parametrize(
    "lang",
    ["bogus", "nope.dots"],
    ids=["word", "dotted"],
)
def test_invalid_lang_version_panics_with_exit_two(lang):
    """An unparseable -lang value panics inside the formatting pass."""
    # CATCHES: the version is validated when the rules are about to run, so
    # the failure is a Go panic on stderr with exit status 2 and no formatted
    # bytes on stdout, rather than a usage error printed by the flag parser.
    res = run_gofumpt(["-lang=" + lang], stdin=b"package p\n", cwd=scratch_dir())
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(
        ('panic: invalid Go version: "%s"\n' % lang).encode()
    )


def test_lang_flag_does_not_widen_the_splitter_or_joining():
    """-lang=go1.16 keeps assignment joining exactly as the default run."""
    # CATCHES: the language version must not switch layout rules on or off by
    # itself; a broken assignment is joined onto one line under -lang=go1.16
    # exactly as it is with no flag at all.
    src = b"package p\n\nfunc f() {\n\tx :=\n\t\t1\n\t_ = x\n}\n"
    res = run_gofumpt(["-lang=go1.16"], stdin=src, cwd=scratch_dir())
    assert res.returncode == 0
    assert res.stdout == b"package p\n\nfunc f() {\n\tx := 1\n\t_ = x\n}\n"
    assert res.stdout == format_source(src)


OCTAL_INPUT = (
    b"package p\n\nconst a = 0755\nvar b = 077\nfunc f() int { return 012 }\n"
)

OCTAL_REWRITTEN = (
    b"package p\n\nconst a = 0o755\n\nvar b = 0o77\n\n"
    b"func f() int { return 0o12 }\n"
)

OCTAL_LEGACY = (
    b"package p\n\nconst a = 0755\n\nvar b = 077\n\n"
    b"func f() int { return 012 }\n"
)


@pytest.mark.parametrize(
    "lang",
    ["go1.13", "go1.13.1", "go1.21"],
    ids=["introducing", "patch", "newer"],
)
def test_octal_integers_get_the_zero_o_prefix_from_go1_13(lang):
    """-lang=go1.13 or newer rewrites legacy octal literals to 0o form."""
    # CATCHES: from the Go 1.13 version gate onwards every `0[0-7_]+` integer
    # gains the `0o` prefix -- in a const value, a var value and a return
    # expression alike -- while the gofmt baseline still blank-separates the
    # const/var/func declarations because their keywords change.
    res = run_gofumpt(["-lang=" + lang], stdin=OCTAL_INPUT, cwd=scratch_dir())
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == OCTAL_REWRITTEN
    # The rewrite is idempotent: `0o755` already matches the modern form.
    res2 = run_gofumpt(["-lang=" + lang], stdin=OCTAL_REWRITTEN, cwd=scratch_dir())
    assert res2.stdout == OCTAL_REWRITTEN


@pytest.mark.parametrize(
    "lang",
    [None, "go1", "go1.12"],
    ids=["no-flag", "bare-go1", "older"],
)
def test_octal_integers_stay_legacy_below_go1_13(lang):
    """Without -lang, or below go1.13, legacy octal literals are untouched."""
    # CATCHES: the octal rewrite is gated on the language version, so the
    # default (no flag, minimum version go1) and -lang=go1.12 leave `0755`
    # exactly as written; only the keyword-change blank lines still appear.
    args = [] if lang is None else ["-lang=" + lang]
    res = run_gofumpt(args, stdin=OCTAL_INPUT, cwd=scratch_dir())
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == OCTAL_LEGACY


def test_octal_rewrite_edge_shapes():
    """Underscored and zero-padded octals rewrite; other bases never do."""
    # CATCHES: the rewrite matches `0[0-7_]+` verbatim, so `07_55` becomes
    # `0o7_55` (underscore kept), the degenerate `0_0` becomes `0o_0`, and
    # `00` becomes `0o0`, while a lone `0`, an already-modern `0o755`, hex and
    # binary literals all print unchanged.
    src = (
        b"package p\n\nconst a = 07_55\nconst b = 0_0\nconst c = 0\n"
        b"const d = 0o755\nconst e = 0777\nconst f = 0x1f\nconst g = 0b11\n"
        b"const h = 00\n"
    )
    expected = (
        b"package p\n\nconst (\n\ta = 0o7_55\n\tb = 0o_0\n\tc = 0\n"
        b"\td = 0o755\n\te = 0o777\n\tf = 0x1f\n\tg = 0b11\n\th = 0o0\n)\n"
    )
    res = run_gofumpt(["-lang=go1.13"], stdin=src, cwd=scratch_dir())
    assert res.returncode == 0
    assert res.stdout == expected
    res2 = run_gofumpt(["-lang=go1.13"], stdin=expected, cwd=scratch_dir())
    assert res2.stdout == expected
