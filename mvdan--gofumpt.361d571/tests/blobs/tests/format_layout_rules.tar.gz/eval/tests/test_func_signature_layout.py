"""Multiline function signatures separate `) {` onto its own closing line.

`applyPre`'s `*ast.BlockStmt` case calls `handleMultiLine` on a signature's
parameter and result lists, which moves the closing parenthesis of a list that
ends on the same line as the body's `{` onto a line of its own.
"""

import pytest
from conftest import assert_idempotent, format_source


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nfunc f(a int,\n\tb string) {\n\tprintln(a, b)\n}\n",
            b"package p\n\nfunc f(a int,\n\tb string,\n) {\n\tprintln(a, b)\n}\n",
        ),
        (
            b'package p\n\nfunc f() (a int,\n\tb string) {\n\treturn 0, ""\n}\n',
            b'package p\n\nfunc f() (a int,\n\tb string,\n) {\n\treturn 0, ""\n}\n',
        ),
        (
            b"package p\n\nfunc f(a int,\n\tb string) (c int,\n\td error) {\n\treturn 0, nil\n}\n",
            b"package p\n\nfunc f(a int,\n\tb string) (c int,\n\td error,\n) {\n\treturn 0, nil\n}\n",
        ),
    ],
    ids=["params", "results", "params-and-results"],
)
def test_multiline_signature_pushes_closing_paren(src, expected):
    """A split parameter or result list ends with `)` on a line of its own."""
    # CATCHES: the closing parenthesis is pushed off the last field's line so
    # that `) {` stands alone; gofmt adds the trailing comma while joining.
    assert format_source(src) == expected


def test_single_line_signature_is_untouched():
    """A signature already on one line keeps its `) {` inline."""
    # CATCHES: the rule only fires when the field list spans several source
    # lines, so a compact signature is left exactly as written.
    src = b"package p\n\nfunc f(a int, b string) {\n\tprintln(a, b)\n}\n"
    assert format_source(src) == src


def test_results_are_not_split_one_per_line():
    """A long single-line result list is not broken into one result per line."""
    # CATCHES: the result list's minSplitFactor is set to a huge value so the
    # splitter never breaks it, unlike a parameter list.
    src = b"package p\n\nfunc f() (aaa int, bbb string, ccc bool) {\n\treturn 0, \"\", true\n}\n"
    assert format_source(src) == src


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nvar f = func(a int,\n\tb string) {\n\tprintln(a, b)\n}\n",
            b"package p\n\nvar f = func(a int,\n\tb string,\n) {\n\tprintln(a, b)\n}\n",
        ),
        (
            b"package p\n\ntype T struct{}\n\nfunc (t T) f(a int,\n\tb string) {\n\tprintln(a, b)\n}\n",
            b"package p\n\ntype T struct{}\n\nfunc (t T) f(a int,\n\tb string,\n) {\n\tprintln(a, b)\n}\n",
        ),
    ],
    ids=["func-literal", "method"],
)
def test_func_literals_and_methods_get_the_same_split(src, expected):
    """Func literals and method declarations split like plain functions."""
    # CATCHES: the signature walk covers FuncDecl and FuncLit alike, and a
    # receiver is just another field in the parameter list.
    assert format_source(src) == expected


def test_inline_comment_after_brace_moves_with_it():
    """An inline comment after `{` stays on the `) {` line."""
    # CATCHES: the comment is printed after the body's opening brace, so the
    # split closing parenthesis takes it along instead of losing it.
    src = b"package p\n\nfunc f(a int,\n\tb string) { // c\n\tprintln(a, b)\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc f(a int,\n\tb string,\n) { // c\n\tprintln(a, b)\n}\n"
    )
    assert_idempotent(src)


def test_block_comment_sharing_the_last_param_line_pushes_paren_down():
    """A `/* c */` on the last param's line moves with it, `)` goes down."""
    # CATCHES: the closing parenthesis is pushed onto its own line even when
    # an inline block comment sits between the last field and it, and go/printer
    # adds the trailing comma before the comment's new line.
    src = b"package p\n\nfunc f(\n\ta int,\n\tb int /* c */) {\n\t_ = b\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc f(\n\ta int,\n\tb int, /* c */\n) {\n\t_ = b\n}\n"
    )
    assert_idempotent(src)


def test_multiline_block_comment_before_closing_paren_blocks_the_split():
    """A multi-line block comment before `)` keeps the signature untouched."""
    # CATCHES: go/printer would reformat a column-1 multi-line block comment
    # as a doc comment if `)` started the next line, so the rule refuses to
    # move the closing parenthesis and only reindents the comment body.
    src = b"package p\n\nfunc f(\n\ta int, /* c1\nc2 */\n) {\n\t_ = a\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc f(\n\ta int, /* c1\n\tc2 */\n) {\n\t_ = a\n}\n"
    )
    assert_idempotent(src)


def test_single_multiline_anonymous_result_joins_the_header():
    """A lone anonymous result split over lines collapses into the header."""
    # CATCHES: the signature rule leaves a single-line parameter list alone,
    # and the printer drops the parentheses of a single anonymous result, so
    # `(\n\terror,\n)` becomes plain ` error` on the header line.
    src = b"package p\n\nfunc f(a int) (\n\terror,\n) {\n\t_ = a\n}\n"
    assert format_source(src) == b"package p\n\nfunc f(a int) error {\n\t_ = a\n}\n"
    assert_idempotent(src)


def test_inline_comment_after_the_last_param_keeps_paren_lines_apart():
    """A `// c` after the last param does not pull `)` onto its line."""
    # CATCHES: the comment between the last field and the closing parenthesis
    # is inspected, and since it does not share the `)` line, the signature
    # keeps the split exactly as written.
    src = b"package p\n\nfunc f(\n\ta int,\n\tb int, // c\n) {\n\t_ = b\n}\n"
    assert format_source(src) == src
    assert_idempotent(src)
