"""Observing the layout rules through gofumpt's output channels.

The rules are visible not only on stdout: `-l` names the files whose
formatting differs, `-d` writes a unified diff to stdout and exits 1, `-w`
rewrites the file in place, and an unparsable input reports on stderr with
exit code 2.
"""

from conftest import format_source, run_gofumpt, write_file

SRC = b"package p\n\nvar (\n\tx = 1\n)\n"
FORMATTED = b"package p\n\nvar x = 1\n"


def test_dash_l_lists_only_files_the_rules_would_change(tmp_path):
    """-l prints the path of a file gofumpt would reformat, and only that."""
    # CATCHES: an already-formatted file is not listed, and the exit code
    # stays 0 because -l only reports.
    write_file(tmp_path, "changed.go", SRC)
    write_file(tmp_path, "clean.go", FORMATTED)
    res = run_gofumpt(["-l", "changed.go", "clean.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"changed.go\n"
    assert res.stderr == b""


def test_dash_d_prints_a_unified_diff_on_stdout_and_exits_one(tmp_path):
    """-d writes the diff to stdout, not stderr, and exits 1."""
    # CATCHES: the diff uses `.orig` for the old name, reports the gofumpt
    # rewrite of the var group, and signals a difference via the exit code.
    write_file(tmp_path, "a.go", SRC)
    res = run_gofumpt(["-d", "a.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == (
        b"diff a.go.orig a.go\n"
        b"--- a.go.orig\n"
        b"+++ a.go\n"
        b"@@ -1,5 +1,3 @@\n"
        b" package p\n"
        b" \n"
        b"-var (\n"
        b"-\tx = 1\n"
        b"-)\n"
        b"+var x = 1\n"
    )


def test_dash_w_rewrites_the_file_in_place(tmp_path):
    """-w writes the formatted bytes back to the file and prints nothing."""
    # CATCHES: the rewrite happens on disk, the file keeps its permissions,
    # and nothing is written to stdout or stderr.
    path = write_file(tmp_path, "a.go", SRC)
    res = run_gofumpt(["-w", "a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert path.read_bytes() == FORMATTED


def test_parse_error_goes_to_stderr_with_exit_code_two():
    """A file that does not parse is reported on stderr and nothing is printed."""
    # CATCHES: only the diagnostic goes to stderr, the exit code is 2 (not
    # the 1 that a mere formatting difference uses), and stdout stays empty.
    res = run_gofumpt([], stdin=b"package p\nfunc\n")
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:2:6: expected 'IDENT', found 'EOF'\n"


def test_stdin_accepts_a_program_fragment():
    """Without a package clause, a fragment of declarations is still formatted."""
    # CATCHES: stdin is parsed with fragmentOk, so the lone var lines are
    # merged into one group even with no `package` line in sight.
    assert format_source(b"var x = 1\nvar y = 2\n") == b"var (\n\tx = 1\n\ty = 2\n)\n"
