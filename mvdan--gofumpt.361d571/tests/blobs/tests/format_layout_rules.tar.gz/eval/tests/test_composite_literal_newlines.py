"""Composite literal newlines are made consistent.

`applyPost`'s `*ast.CompositeLit` case makes a break after `{` or before `}`
imply both, and makes a break between two elements imply a break between every
adjacent pair where at least one element is itself a composite literal.  The
same walk removes the blank lines just inside the braces.
"""

import pytest
from conftest import assert_idempotent, format_source


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nfunc f() {\n\tv := []int{\n\t\t1, 2}\n\t_ = v\n}\n",
            b"package p\n\nfunc f() {\n\tv := []int{\n\t\t1, 2,\n\t}\n\t_ = v\n}\n",
        ),
        (
            b"package p\n\nfunc f() {\n\tv := []int{1, 2, 3,\n\t}\n\t_ = v\n}\n",
            b"package p\n\nfunc f() {\n\tv := []int{\n\t\t1, 2, 3,\n\t}\n\t_ = v\n}\n",
        ),
        (
            b'package p\n\nvar m = map[string]int{"a": 1,\n\t"b": 2}\n',
            b'package p\n\nvar m = map[string]int{\n\t"a": 1,\n\t"b": 2,\n}\n',
        ),
    ],
    ids=["after-open", "before-close", "map-pairs"],
)
def test_break_on_one_side_of_braces_forces_both(src, expected):
    """A newline after `{` or before `}` implies a newline on both sides."""
    # CATCHES: half-split literals are completed, so the closing brace always
    # lands on a line of its own once the opening one ends a line.
    assert format_source(src) == expected


def test_lone_top_level_var_with_break_before_close_stays_one_line():
    """A top-level `var v = []int{1, 2, 3,` + newline + `}` collapses fully."""
    # CATCHES: the lone declaration is first joined because go/printer can
    # print its spec on one line, which wins over the literal's own break.
    src = b"package p\n\nvar v = []int{1, 2, 3,\n}\n"
    assert format_source(src) == b"package p\n\nvar v = []int{1, 2, 3}\n"


def test_break_between_composite_elements_forces_all():
    """One break between composite literal elements breaks every element out."""
    # CATCHES: all three elements end up on their own line even though only
    # the last pair was split in the input.
    src = b"package p\n\ntype T struct{ A, B, C int }\n\nvar v = []T{{A: 1}, {A: 2},\n\t{A: 3}}\n"
    assert format_source(src) == (
        b"package p\n\ntype T struct{ A, B, C int }\n\nvar v = []T{\n\t{A: 1},\n\t{A: 2},\n\t{A: 3},\n}\n"
    )


def test_break_between_scalars_does_not_force_each_element():
    """A break between plain values only forces the braces, not each element."""
    # CATCHES: the one-element-per-line rule needs a composite literal in the
    # adjacent pair, so `1, 2` stays together on one line.
    src = b"package p\n\nvar v = []int{1, 2,\n\t3, 4}\n"
    assert format_source(src) == b"package p\n\nvar v = []int{\n\t1, 2,\n\t3, 4,\n}\n"


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\ntype T struct{ A int }\n\nvar v = []interface{}{{A: 1},\n\t2, 3}\n",
            b"package p\n\ntype T struct{ A int }\n\nvar v = []interface{}{\n\t{A: 1},\n\t2, 3,\n}\n",
        ),
        (
            b"package p\n\ntype T struct{ A int }\n\nvar v = []interface{}{1, 2,\n\t{T: 3}}\n",
            b"package p\n\ntype T struct{ A int }\n\nvar v = []interface{}{\n\t1, 2,\n\t{T: 3},\n}\n",
        ),
    ],
    ids=["comp-then-scalar", "scalar-then-comp"],
)
def test_mixed_pairs_split_only_where_a_composite_takes_part(src, expected):
    """A composite/scalar pair breaks; a scalar/scalar pair does not."""
    # CATCHES: the per-element rule walks adjacent pairs, so `2, 3` stays on
    # one line while the pair holding the composite literal is split.
    assert format_source(src) == expected


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nfunc f() {\n\tv := []int{\n\n\t\t1, 2}\n\t_ = v\n}\n",
            b"package p\n\nfunc f() {\n\tv := []int{\n\t\t1, 2,\n\t}\n\t_ = v\n}\n",
        ),
        (
            b"package p\n\nfunc f() {\n\tv := []int{1, 2,\n\n\t}\n\t_ = v\n}\n",
            b"package p\n\nfunc f() {\n\tv := []int{\n\t\t1, 2,\n\t}\n\t_ = v\n}\n",
        ),
    ],
    ids=["leading", "trailing"],
)
def test_blank_lines_just_inside_the_braces_are_removed(src, expected):
    """Empty lines right after `{` or right before `}` disappear."""
    # CATCHES: the literal's own leading/trailing blank lines are dropped
    # while a blank between two elements is kept.
    assert format_source(src) == expected


def test_blank_line_between_elements_is_kept():
    """An empty line between two elements survives the newline normalisation."""
    # CATCHES: only the lines around the braces are merged; the author's
    # grouping blank line between elements stays where it was.
    src = b"package p\n\nfunc f() {\n\tv := []int{1,\n\n\t\t2}\n\t_ = v\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc f() {\n\tv := []int{\n\t\t1,\n\n\t\t2,\n\t}\n\t_ = v\n}\n"
    )


def test_comment_inside_literal_forces_multiline():
    """A comment as the first element makes the literal multiline."""
    # CATCHES: the comment sits on its own line inside the literal, which
    # counts as a break after the brace and forces the closing brace down.
    src = b"package p\n\nfunc f() {\n\tv := []int{\n\t\t// c\n\t\t1}\n\t_ = v\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc f() {\n\tv := []int{\n\t\t// c\n\t\t1,\n\t}\n\t_ = v\n}\n"
    )


def test_comment_between_elements_blocks_the_join():
    """An inline comment between two elements keeps the literal as written."""
    # CATCHES: comments between elements are not moved, so the literal keeps
    # the same two lines it started with.
    src = b"package p\n\nfunc f() {\n\tv := []int{1, // a\n\t\t2}\n\t_ = v\n}\n"
    assert format_source(src) == src


def test_empty_composite_literal_prints_on_one_line():
    """`[]int{` + newline + `}` becomes `[]int{}`."""
    # CATCHES: matchBraceLines joins an empty brace pair, so the literal ends
    # up on a single line instead of keeping the source's two.
    src = b"package p\n\nvar v = []int{\n}\n"
    assert format_source(src) == b"package p\n\nvar v = []int{}\n"
    assert_idempotent(src)
