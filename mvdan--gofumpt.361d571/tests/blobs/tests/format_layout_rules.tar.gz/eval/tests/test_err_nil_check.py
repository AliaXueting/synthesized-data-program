"""The blank line before a simple `if err != nil` disappears.

`fumpter.stmts` removes the empty lines between an assignment whose last
left-hand side is `err` and a following `if err != nil` with no init and no
else.  Anything more elaborate keeps the author's blank line.
"""

import pytest
from conftest import assert_idempotent, format_source


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nfunc f() error {\n\tb, err := g()\n\n\tif err != nil {\n\t\treturn err\n\t}\n\t_ = b\n\treturn nil\n}\n\nfunc g() (int, error) { return 0, nil }\n",
            b"package p\n\nfunc f() error {\n\tb, err := g()\n\tif err != nil {\n\t\treturn err\n\t}\n\t_ = b\n\treturn nil\n}\n\nfunc g() (int, error) { return 0, nil }\n",
        ),
        (
            b"package p\n\nfunc f() error {\n\tvar err error\n\terr = g()\n\n\tif err != nil {\n\t\treturn err\n\t}\n\treturn nil\n}\n\nfunc g() error { return nil }\n",
            b"package p\n\nfunc f() error {\n\tvar err error\n\terr = g()\n\tif err != nil {\n\t\treturn err\n\t}\n\treturn nil\n}\n\nfunc g() error { return nil }\n",
        ),
    ],
    ids=["define", "assign"],
)
def test_blank_line_before_err_check_removed(src, expected):
    """`, err :=` and `, err =` both lose the blank line before the check."""
    # CATCHES: the rule matches both DEFINE and ASSIGN tokens, and only
    # requires err to be the *last* left-hand side operand.
    assert format_source(src) == expected


def test_comment_between_err_assignment_and_check():
    """A comment between the assignment and the check moves up with it."""
    # CATCHES: the blank-line removal goes through removeLinesBetween, which
    # keeps the lines around any comment but still drops the empty ones.
    src = b"package p\n\nfunc f() error {\n\tb, err := g()\n\n\t// c\n\tif err != nil {\n\t\treturn err\n\t}\n\t_ = b\n\treturn nil\n}\n\nfunc g() (int, error) { return 0, nil }\n"
    assert format_source(src) == (
        b"package p\n\nfunc f() error {\n\tb, err := g()\n\t// c\n\tif err != nil {\n\t\treturn err\n\t}\n\t_ = b\n\treturn nil\n}\n\nfunc g() (int, error) { return 0, nil }\n"
    )


def test_err_check_inside_case_clause():
    """The rule also applies to the statement list of a case clause."""
    # CATCHES: `stmts` is called for CaseClause and CommClause bodies as
    # well, not only for BlockStmt bodies.
    src = b"package p\n\nfunc f() {\n\tswitch {\n\tcase true:\n\t\tb, err := g()\n\n\t\tif err != nil {\n\t\t\tprintln(b)\n\t\t}\n\t}\n}\n\nfunc g() (int, error) { return 0, nil }\n"
    assert format_source(src) == (
        b"package p\n\nfunc f() {\n\tswitch {\n\tcase true:\n\t\tb, err := g()\n\t\tif err != nil {\n\t\t\tprintln(b)\n\t\t}\n\t}\n}\n\nfunc g() (int, error) { return 0, nil }\n"
    )


@pytest.mark.parametrize(
    "cond",
    [
        b"err != nil && x",
        b"errors.Is(err, io.EOF)",
        b"v := h(); err != nil",
    ],
    ids=["extra-operand", "wrapped-call", "with-init"],
)
def test_complex_error_checks_keep_the_blank_line(cond):
    """Only the bare `err != nil` condition triggers the removal."""
    # CATCHES: a binary condition with more operands, a call around err, or
    # an if init statement all keep the blank line the author wrote.
    src = (
        b"package p\n\nfunc f() error {\n\t_, err := g()\n\n\tif " + cond + b" {\n\t\treturn err\n\t}\n\treturn nil\n}\n\nfunc g() error { return nil }\n"
    )
    assert format_source(src) == src


def test_err_not_last_operand_keeps_the_blank_line():
    """`err, b := g()` does not match, so its blank line stays."""
    # CATCHES: only the last left-hand side is compared with "err", so an
    # assignment starting with err keeps the empty line before the check.
    src = b"package p\n\nfunc f() error {\n\terr, b := g()\n\n\tif err != nil {\n\t\treturn err\n\t}\n\t_ = b\n\treturn nil\n}\n\nfunc g() (int, error) { return 0, nil }\n"
    assert format_source(src) == src


def test_other_variable_checks_keep_the_blank_line():
    """An assignment not ending in err keeps its blank line before any if."""
    # CATCHES: the name comparison is on the identifier `err`, not on any
    # error-typed variable, so `x := 1; if x == 1` is untouched.
    src = b"package p\n\nfunc f() {\n\tx := 1\n\n\tif x == 1 {\n\t\tprintln(2)\n\t}\n}\n"
    assert format_source(src) == src
    assert_idempotent(src)
