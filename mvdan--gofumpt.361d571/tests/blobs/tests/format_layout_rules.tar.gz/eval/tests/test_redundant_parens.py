"""Definitely-useless parentheses are removed, useful ones are kept.

`applyPre`'s `*ast.ParenExpr` case unwraps inner paren chains and drops the
outer pair when `keepParens` says the enclosed expression does not need them:
a call, selector, index or identifier operand loses its parens, while a
binary, unary or type expression at the outermost level keeps them.
"""

import pytest
from conftest import assert_idempotent, format_source


@pytest.mark.parametrize(
    "src,expected",
    [
        (b"package p\n\nvar x = (f())\n", b"package p\n\nvar x = f()\n"),
        (b"package p\n\nvar x = (a.b).c\n", b"package p\n\nvar x = a.b.c\n"),
        (b"package p\n\nvar y = []int{1}\n\nvar x = (y[0])\n", b"package p\n\nvar y = []int{1}\n\nvar x = y[0]\n"),
        (b"package p\n\nvar x (int)\n", b"package p\n\nvar x int\n"),
    ],
    ids=["call", "selector", "index", "type"],
)
def test_useless_parens_are_removed(src, expected):
    """Parens around a call, selector, index or bare type are dropped."""
    # CATCHES: keepParens only protects the outermost expression of these
    # shapes, so a pair wrapped directly around one is redundant.
    assert format_source(src) == expected


def test_redundant_parens_join_the_lines_they_spanned():
    """A paren pair broken over lines is removed and its lines joined."""
    # CATCHES: dropping the parentheses also merges the lines the pair
    # straddled, so the call keeps its own break but not the parens'.
    src = b"package p\n\nfunc f() {\n\tx := (h(\n\t\t1))\n\t_ = x\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tx := h(\n\t\t1)\n\t_ = x\n}\n"


@pytest.mark.parametrize(
    "src",
    [
        b"package p\n\nvar x = (1 + 2)\n",
        b"package p\n\nvar x = (-y)\n",
        b"package p\n\nvar v = (<-chan int)(nil)\n",
        b"package p\n\nvar x = ( /* c */ 1)\n",
    ],
    ids=["binary", "unary", "chan-conversion", "comment-inside"],
)
def test_meaningful_parens_are_kept(src):
    """Parens around binary/unary/type expressions or comments stay."""
    # CATCHES: binary and unary operands keep their parens for readability,
    # a channel conversion needs them, and a comment inside cannot move.
    assert format_source(src) == src


def test_parens_around_a_composite_literal_argument_are_kept():
    """`g((T{A: 1}))` keeps the inner parens."""
    # CATCHES: a composite literal is always parenthesised when wrapped, so
    # the extra pair survives even where a call's parens would be dropped.
    src = b"package p\n\ntype T struct{ A int }\n\nfunc f() {\n\tg((T{A: 1}))\n}\n"
    assert format_source(src) == src
    assert_idempotent(src)


@pytest.mark.parametrize(
    "src,expected",
    [
        (b"package p\n\nvar s []int\n\nvar x = (s[1:2])\n",
         b"package p\n\nvar s []int\n\nvar x = s[1:2]\n"),
        (b'package p\n\nfunc g[A, B any](a A, b B) {}\n\nvar f = (g[int, string])(1, "")\n',
         b'package p\n\nfunc g[A, B any](a A, b B) {}\n\nvar f = g[int, string](1, "")\n'),
        (b"package p\n\nvar v interface{}\n\nvar y = (v.(int))\n",
         b"package p\n\nvar v interface{}\n\nvar y = v.(int)\n"),
    ],
    ids=["slice", "generic-instantiation", "type-assertion"],
)
def test_useless_parens_around_operators_are_removed(src, expected):
    """Parens wrapping a slice, index list or type assertion are dropped."""
    # CATCHES: keepParens only recurses to keep parens whose leftmost operand
    # needs them, so parens directly around `s[1:2]`, `g[A, B]` or `v.(int)`
    # are removed and the expression prints without them.
    assert format_source(src) == expected
    assert_idempotent(src)


def test_parens_around_a_slice_of_a_composite_kept():
    """`([]int{1, 2}[0:1])[0]` keeps the parens around the slice expression."""
    # CATCHES: the slice expression's leftmost operand is a composite literal,
    # so the parens wrapping it survive just like a bare `T{...}` would.
    src = b"package p\n\nvar z = ([]int{1, 2}[0:1])[0]\n"
    assert format_source(src) == src
    assert_idempotent(src)
