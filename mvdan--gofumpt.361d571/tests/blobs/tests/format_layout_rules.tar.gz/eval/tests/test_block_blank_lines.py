"""Blank lines at the start and end of a block are removed.

`applyPre`'s `*ast.BlockStmt` case strips the empty lines between `{` and the
first statement or comment, and between the last one and `}`.  A case clause's
own body is not a block, so the blank line after its colon survives.
"""

import pytest
from conftest import assert_idempotent, format_source


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nfunc f() {\n\tif true {\n\n\t\tprintln(1)\n\n\t}\n}\n",
            b"package p\n\nfunc f() {\n\tif true {\n\t\tprintln(1)\n\t}\n}\n",
        ),
        (
            b"package p\n\nfunc f() {\n\tfor {\n\n\t\tprintln(1)\n\n\t}\n}\n",
            b"package p\n\nfunc f() {\n\tfor {\n\t\tprintln(1)\n\t}\n}\n",
        ),
        (
            b"package p\n\nfunc f() {\n\tswitch {\n\n\tcase true:\n\t\tprintln(1)\n\n\t}\n}\n",
            b"package p\n\nfunc f() {\n\tswitch {\n\tcase true:\n\t\tprintln(1)\n\t}\n}\n",
        ),
        (
            b"package p\n\nfunc f() {\n\tselect {\n\n\tcase <-ch:\n\t\tprintln(1)\n\n\t}\n}\n",
            b"package p\n\nfunc f() {\n\tselect {\n\tcase <-ch:\n\t\tprintln(1)\n\t}\n}\n",
        ),
    ],
    ids=["if", "for", "switch", "select"],
)
def test_statement_bodies_lose_leading_and_trailing_blanks(src, expected):
    """if/for/switch/select bodies never start or end with a blank line."""
    # CATCHES: the rule covers every statement block, not only function
    # bodies, so the blank after `{` and before `}` disappears in all four.
    assert format_source(src) == expected


def test_function_body_loses_leading_and_trailing_blanks():
    """A function body's first and last blank lines are dropped."""
    # CATCHES: both ends are cleaned in one pass, keeping any blank lines in
    # the middle of the body untouched.
    src = b"package p\n\nfunc f() {\n\n\tprintln(1)\n\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tprintln(1)\n}\n"


def test_body_holding_only_comments_loses_blanks():
    """A body with no statements but a comment still drops its blank lines."""
    # CATCHES: the comment counts as the block's body, so the empty lines
    # around it are removed instead of being kept as a "comment-only" block.
    src = b"package p\n\nfunc f() {\n\n\t// hello\n\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\t// hello\n}\n"


def test_empty_block_keeps_two_lines_but_no_blank():
    """`if x {` followed by a blank line and `}` keeps one line per brace."""
    # CATCHES: an empty block is not collapsed onto `if x {}` - only the
    # blank lines between the braces are merged away.
    src = b"package p\n\nfunc f() {\n\tif x {\n\n\t}\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tif x {\n\t}\n}\n"


def test_else_branch_blanks_removed():
    """Both branches of an if/else have their blank lines trimmed."""
    # CATCHES: the else block is a plain BlockStmt too, so it gets the same
    # treatment as the if block that precedes it.
    src = b"package p\n\nfunc f() {\n\tif true {\n\n\t} else {\n\n\t\tprintln(1)\n\n\t}\n}\n"
    assert format_source(src) == (
        b"package p\n\nfunc f() {\n\tif true {\n\t} else {\n\t\tprintln(1)\n\t}\n}\n"
    )


def test_func_literal_body_blanks_removed():
    """A func literal's body is cleaned like a declared function's body."""
    # CATCHES: the rule keys off the BlockStmt node, so a `var f = func(){}`
    # literal is treated exactly like a top-level func declaration.
    src = b"package p\n\nvar f = func() {\n\n\tprintln(1)\n\n}\n"
    assert format_source(src) == b"package p\n\nvar f = func() {\n\tprintln(1)\n}\n"


def test_blank_line_after_case_colon_is_kept():
    """A blank line directly after `case X:` is not removed."""
    # CATCHES: only BlockStmt braces are cleaned; a case clause's body is a
    # plain statement list, so its leading blank line survives.
    src = b"package p\n\nfunc f() {\n\tswitch {\n\tcase true:\n\n\t\tprintln(1)\n\t}\n}\n"
    assert format_source(src) == src


def test_blank_lines_between_statements_are_kept():
    """Blank lines in the middle of a body collapse to one, never to none."""
    # CATCHES: only the first and last lines of a block are affected, so
    # run-together blank lines between statements become exactly one.
    src = b"package p\n\nfunc f() {\n\tprintln(1)\n\n\n\n\tprintln(2)\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tprintln(1)\n\n\tprintln(2)\n}\n"
    assert_idempotent(src)


@pytest.mark.parametrize(
    "src",
    [
        b"package p\n\nfunc f() {\n\tif x {\n\n\t\tstmt1()\n\t\tstmt2()\n\n\t}\n\t_ = x\n}\n",
        b"package p\n\nfunc f() {\n\tfor {\n\n\t\tstmt1()\n\t\tstmt2()\n\n\t}\n}\n",
        b"package p\n\nfunc f(c chan int) {\n\tselect {\n\n\tcase <-c:\n\t\tstmt1()\n\n\tcase <-c:\n\t\tstmt2()\n\n\t}\n}\n",
        b"package p\n\nfunc f(x int) {\n\tswitch x {\n\n\tcase 1:\n\t\tstmt1()\n\n\tcase 2:\n\t\tstmt2()\n\n\t}\n}\n",
    ],
    ids=["if", "for", "select", "switch"],
)
def test_multistatement_statement_bodies_keep_blank_lines(src):
    """A statement body holding two or more statements keeps its blank lines."""
    # CATCHES: the blank-line trimming only covers single-statement bodies
    # (and function bodies), so an if/for/select/switch body with two
    # statements or two case clauses keeps the blanks at both ends.
    assert format_source(src) == src
    assert_idempotent(src)


def test_multistatement_func_literal_body_still_loses_blanks():
    """A func literal body with two statements still loses its blank lines."""
    # CATCHES: func bodies are exempt from the two-statement limit, as the
    # rule keys off the signature rather than the statement count.
    src = b"package p\n\nvar f = func() {\n\n\tstmt1()\n\tstmt2()\n\n}\n"
    assert format_source(src) == b"package p\n\nvar f = func() {\n\tstmt1()\n\tstmt2()\n}\n"
