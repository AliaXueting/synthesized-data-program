"""The gofmt baseline printing that every gofumpt rule is layered on top of.

The internal go/format package configures the printer with tab-based
indentation, space-based alignment and number normalization, and gofumpt's
layout rules only ever add or remove lines around what that printer emits.
These tests pin the baseline transformations themselves, since a
re-implementation that prints numbers or alignment differently would differ
on otherwise untouched input.
"""

import pytest

from conftest import assert_idempotent, format_source


def test_number_literal_prefixes_and_exponents_are_normalized():
    """`0Xff`/`1E9`/`0B101`/`0O17` print with lowercase prefixes and exponents."""
    # CATCHES: the printer canonicalizes number literal prefixes and exponent
    # markers while digits keep their case, and underscore separators and hex
    # float exponents are left exactly as written.
    src = (
        b"package p\n\nvar (\n\ta = 0Xff\n\tb = 1E9\n\tc = 0B101\n\td = 0O17\n"
        b"\te = 1_000_000\n\tf = 0x1p-2\n\tg = .5E-3\n\th = 0XABCDEFabcdef\n)\n"
    )
    assert format_source(src) == (
        b"package p\n\nvar (\n\ta = 0xff\n\tb = 1e9\n\tc = 0b101\n\td = 0o17\n"
        b"\te = 1_000_000\n\tf = 0x1p-2\n\tg = .5e-3\n\th = 0xABCDEFabcdef\n)\n"
    )
    assert_idempotent(src)


def test_struct_field_alignment_uses_spaces():
    """Struct fields align their types with spaces, not tabs."""
    # CATCHES: the printer indents with tabs but aligns a field list's types
    # with spaces up to the longest field name, so `X` gains padding blanks.
    src = b"package p\n\ntype T struct {\n\tName int\n\tX string\n}\n"
    assert format_source(src) == (
        b"package p\n\ntype T struct {\n\tName int\n\tX    string\n}\n"
    )
    assert_idempotent(src)


def test_hex_float_and_imaginary_literals_are_normalized():
    """Uppercase `P` exponents and imaginary suffixes normalize like `E` ones."""
    # CATCHES: the number normalizer lowercases the exponent marker of hex
    # floats (`0x1P+2` -> `0x1p+2`) and of imaginary literals (`1E9i` ->
    # `1e9i`) while keeping digit case, underscores and the legacy `017`
    # octal spelling exactly as written.
    src = (
        b"package p\n\nvar (\n\ta = 0x1P+2\n\tb = 0X.8P1\n\tc = 1E9i\n"
        b"\td = 0XFFi\n\te = 1_0E1_0\n\tf = 0X_1\n\tg = 017\n"
        b"\th = 0xABCDEFp+2\n)\n"
    )
    assert format_source(src) == (
        b"package p\n\nvar (\n\ta = 0x1p+2\n\tb = 0x.8p1\n\tc = 1e9i\n"
        b"\td = 0xFFi\n\te = 1_0e1_0\n\tf = 0x_1\n\tg = 017\n"
        b"\th = 0xABCDEFp+2\n)\n"
    )
    assert_idempotent(src)


def test_numbers_are_normalized_inside_expressions():
    """Number normalization applies everywhere, not only in var groups."""
    # CATCHES: prefix/exponent canonicalization is a printer-wide pass, so a
    # composite literal element and a call argument are rewritten just like a
    # top-level declaration value would be.
    src = (
        b"package p\n\nfunc f() {\n\tx := []int{0Xff, 0B11, 1E9}\n"
        b"\ty := g(0O17, .5E-3)\n\t_ = x\n\t_ = y\n}\n"
    )
    assert format_source(src) == (
        b"package p\n\nfunc f() {\n\tx := []int{0xff, 0b11, 1e9}\n"
        b"\ty := g(0o17, .5e-3)\n\t_ = x\n\t_ = y\n}\n"
    )
    assert_idempotent(src)


def test_struct_field_columns_align_names_types_tags_and_comments():
    """Fields carrying the same cells align every column with spaces."""
    # CATCHES: when each field has a trailing comment the name, type and
    # comment columns each pad with spaces to their widest member, and a
    # struct tag column only pads when the shorter row also ends in a cell:
    # `Name int `json:"name"`` next to `X string` leaves `int` unpadded
    # because the tagless row's type is its final cell.
    src = (
        b"package p\n\ntype T struct {\n\tName int `json:\"name\"`\n"
        b"\tX string\n}\n\ntype U struct {\n\tName int // first\n"
        b"\tX string // second\n\tLonger bool\n}\n"
    )
    assert format_source(src) == (
        b"package p\n\ntype T struct {\n\tName int `json:\"name\"`\n"
        b"\tX    string\n}\n\ntype U struct {\n\tName   int    // first\n"
        b"\tX      string // second\n\tLonger bool\n}\n"
    )
    assert_idempotent(src)


def test_interface_methods_never_align_their_columns():
    """Interface method results and comments get single spaces, no padding."""
    # CATCHES: unlike struct fields, interface methods form no aligned
    # columns -- `Error() error // the error` keeps one space before both the
    # result type and the comment even beside the longer `String() string`.
    src = (
        b"package p\n\ntype E interface {\n\tError() error // the error\n"
        b"\tString() string\n}\n"
    )
    assert format_source(src) == (
        b"package p\n\ntype E interface {\n\tError() error // the error\n"
        b"\tString() string\n}\n"
    )
    assert_idempotent(src)


def test_const_and_var_specs_align_on_the_name_column():
    """Spec name cells (including commas) pad to the widest name list."""
    # CATCHES: alignment works on the whole name cell, so `a, bb` pads with
    # two spaces to line up with `ccc, d`, and a lone `B` pads to `Alpha`'s
    # width -- the value column itself is never padded.
    src = (
        b"package p\n\nvar (\n\ta, bb = 1, 2\n\tccc, d = 3, 4\n)\n\n"
        b"const (\n\tAlpha = 1\n\tB = 2\n)\n"
    )
    assert format_source(src) == (
        b"package p\n\nvar (\n\ta, bb  = 1, 2\n\tccc, d = 3, 4\n)\n\n"
        b"const (\n\tAlpha = 1\n\tB     = 2\n)\n"
    )
    assert_idempotent(src)


def test_blank_or_comment_lines_split_alignment_groups():
    """A blank line or a standalone comment ends a field/spec alignment run."""
    # CATCHES: padding is computed per contiguous group, so `Name int` before
    # a blank line and `X string` before a `// doc` comment stay unpadded,
    # while the fields after the comment (`Longer`/`Z`) still align with each
    # other, and `After` after a blank line aligns with nothing.
    src = (
        b"package p\n\ntype T struct {\n\tName int\n\n\tX string\n}\n\n"
        b"type U struct {\n\tX string\n\t// doc for Y\n\tLonger bool\n"
        b"\tZ int\n}\n\nvar (\n\tLongName = 10\n\tShort = 2\n\n\tAfter = 3\n)\n"
    )
    assert format_source(src) == (
        b"package p\n\ntype T struct {\n\tName int\n\n\tX string\n}\n\n"
        b"type U struct {\n\tX string\n\t// doc for Y\n\tLonger bool\n"
        b"\tZ      int\n}\n\nvar (\n\tLongName = 10\n\tShort    = 2\n\n"
        b"\tAfter = 3\n)\n"
    )
    assert_idempotent(src)


def test_alignment_at_nested_indentation_pads_after_tabs():
    """Deeply nested field lists indent with tabs, then pad with spaces."""
    # CATCHES: alignment padding is always spaces regardless of depth, so a
    # struct declared inside a function body gets two tab indents and `A`
    # still pads with spaces to line up with `BB`.
    src = (
        b"package p\n\nfunc f() {\n\ttype S struct {\n\tA int\n"
        b"\tBB string\n\t}\n\t_ = S{}\n}\n"
    )
    assert format_source(src) == (
        b"package p\n\nfunc f() {\n\ttype S struct {\n\t\tA  int\n"
        b"\t\tBB string\n\t}\n\t_ = S{}\n}\n"
    )
    assert_idempotent(src)


def test_merged_lone_vars_are_aligned_as_one_group():
    """Vars merged into one group by the layout rules align afterwards."""
    # CATCHES: the lone-var merge rule feeds the printer's alignment pass, so
    # `a`, `Longer` and `b` end up in a single parenthesized group whose name
    # column is padded with spaces to `Longer`'s width.
    src = b"package p\n\nvar a = 1\nvar Longer = 2\nvar b = 3\n"
    assert format_source(src) == (
        b"package p\n\nvar (\n\ta      = 1\n\tLonger = 2\n\tb      = 3\n)\n"
    )
    assert_idempotent(src)


@pytest.mark.parametrize(
    ("src", "expected"),
    [
        (
            b"package p\n\nfunc a() {}\nvar v = 1\n",
            b"package p\n\nfunc a() {}\n\nvar v = 1\n",
        ),
        (
            b"package p\n\nconst c = 1\nvar v = 2\nfunc f() {}\n",
            b"package p\n\nconst c = 1\n\nvar v = 2\n\nfunc f() {}\n",
        ),
        (
            b"package p\n\nvar v = 1\ntype T int\n",
            b"package p\n\nvar v = 1\n\ntype T int\n",
        ),
        (
            b"package p\n\nimport \"fmt\"\nvar v = fmt.Sprint\n",
            b"package p\n\nimport \"fmt\"\n\nvar v = fmt.Sprint\n",
        ),
        (
            b"package p\n\nfunc a() {}\nfunc b() {}\n",
            b"package p\n\nfunc a() {}\nfunc b() {}\n",
        ),
    ],
    ids=["func-var", "const-var-func", "var-type", "import-var", "func-func"],
)
def test_top_level_decls_separate_when_the_keyword_changes(src, expected):
    """The printer inserts a blank line between decls of different kinds."""
    # CATCHES: the gofmt baseline forces one empty line between top-level
    # declarations whenever the leading keyword changes (func/const/var/type/
    # import), even when both decls are single-line and were written touching,
    # while two adjacent single-line funcs stay on consecutive lines.
    assert format_source(src) == expected
    assert_idempotent(src)
