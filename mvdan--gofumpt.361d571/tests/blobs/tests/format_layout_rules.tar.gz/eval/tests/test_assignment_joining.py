"""Joining the right-hand side onto a simple assignment's own line.

`applyPre`'s `*ast.AssignStmt` case removes the newlines between the
assignment token and a single right-hand side which is not a binary
expression and is not separated from the token by a comment.
"""

import pytest
from conftest import format_source


def test_define_operator_joined_to_rhs():
    """`x :=` on its own line is joined with the value that followed it."""
    # CATCHES: the rule only strips the newlines between the operator and a
    # single non-binary right-hand side, so the value moves up to `x :=`.
    src = b"package p\n\nfunc f() {\n\tx :=\n\t\t1\n\t_ = x\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tx := 1\n\t_ = x\n}\n"


def test_plain_assignment_joined_to_rhs():
    """A top-level `var x =` broken before its value is joined as well."""
    # CATCHES: the same newline removal applies to `=` declarations at the
    # top level, and the lone declaration then prints on a single line.
    src = b"package p\n\nvar x =\n\t1\n"
    assert format_source(src) == b"package p\n\nvar x = 1\n"


def test_call_rhs_joined_onto_operator_line():
    """A call or func literal right-hand side is joined too."""
    # CATCHES: only *binary* expressions are exempt, so calls and func
    # literals are pulled up onto the assignment's line.
    src = b"package p\n\nfunc f() {\n\tx :=\n\t\tg()\n\t_ = x\n}\n"
    assert format_source(src) == b"package p\n\nfunc f() {\n\tx := g()\n\t_ = x\n}\n"


def test_multi_value_assignment_not_joined():
    """`x, y :=` keeps its line break before a multi-value right-hand side."""
    # CATCHES: len(node.Rhs) == 1 is required, so a two-value assignment is
    # left exactly as written.
    src = b"package p\n\nfunc f() {\n\tx, y :=\n\t\t1, 2\n\t_, _ = x, y\n}\n"
    assert format_source(src) == src


def test_binary_rhs_not_joined():
    """A long string concatenation keeps its break after the operator."""
    # CATCHES: a binary expression right-hand side is skipped, since a break
    # there usually aids readability of long concatenations.
    src = b'package p\n\nfunc f() {\n\tx := "aaaaaaaaaaaa" +\n\t\t"bbbbbbbbbbbbbbbbbb"\n\t_ = x\n}\n'
    assert format_source(src) == src


def test_comment_between_operator_and_rhs_not_joined():
    """An inline comment between the operator and the value blocks the join."""
    # CATCHES: comments in between make the join produce gofmt-invalid
    # indentation, so the lines are left alone.
    src = b"package p\n\nfunc f() {\n\tx := // c\n\t\t1\n\t_ = x\n}\n"
    assert format_source(src) == src


@pytest.mark.parametrize(
    "src,expected",
    [
        (
            b"package p\n\nfunc f() {\n\tx :=\n\t\t1\n\t_ = x\n}\n",
            b"package p\n\nfunc f() {\n\tx := 1\n\t_ = x\n}\n",
        ),
        (b"package p\n\nvar x =\n\t1\n", b"package p\n\nvar x = 1\n"),
        (
            b"package p\n\nfunc f() {\n\tx, y :=\n\t\t1, 2\n\t_, _ = x, y\n}\n",
            b"package p\n\nfunc f() {\n\tx, y :=\n\t\t1, 2\n\t_, _ = x, y\n}\n",
        ),
    ],
    ids=["define", "var", "multi"],
)
def test_joining_is_idempotent(src, expected):
    """The joined assignment survives a second formatting pass unchanged."""
    # CATCHES: the join must not oscillate - the first pass produces exactly
    # the recorded bytes, and a second pass over them is a byte-for-byte no-op
    # rather than joining or splitting anything further.
    once = format_source(src)
    assert once == expected
    assert format_source(once) == expected
