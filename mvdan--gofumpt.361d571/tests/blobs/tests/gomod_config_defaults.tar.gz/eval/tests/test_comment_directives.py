"""Shebang-looking first lines and the //gofumpt:diagnose rewrite.

The comment-group scan that rewrites `//gofumpt:diagnose` skips an entire
group as soon as one of its lines is a shebang-like line 1 comment (matching
`^//[^ /].*\bbin/`). Whether the directive is rewritten therefore depends on
it not sharing a comment group with such a line — a blank line between them
is enough to restore the rewrite.
"""

from conftest import (
    diagnose_line,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

GOMOD = "module mymod\n\ngo 1.21\n"


def run_in_module(tmp_path, source):
    """Format source as x.go inside a module rooted at tmp_path/m."""
    mod = tmp_path / "m"
    write_module(mod, GOMOD)
    write(mod / "x.go", source)
    return run_gofumpt(["x.go"], cwd=mod)


def test_shebang_group_is_skipped_by_the_diagnose_rewrite(tmp_path):
    """A diagnose directive sharing a group with a shebang line is not rewritten.

    The whole comment group is abandoned when its first line is a shebang, so
    the directive keeps its stale text; the group is still the file's doc
    comment, which is reformatted as prose (a space after `//` and a blank
    comment line before the directive).

    CATCHES: a re-implementation that scans every comment line for the
    directive regardless of its group rewrites the line and reports the
    module's -lang/-modpath here; one that skips the group but not the doc
    reformatting emits the shebang byte-for-byte.
    """
    source = b"//usr/bin/env go run x.go\n//gofumpt:diagnose\npackage p\n\nfunc F() {}\n"
    res = run_in_module(tmp_path, source)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == b"// usr/bin/env go run x.go\n//\n//gofumpt:diagnose\npackage p\n\nfunc F() {}\n"


def test_blank_line_restores_the_diagnose_rewrite_after_a_shebang(tmp_path):
    """A shebang in its own group leaves the next group's directive alone.

    With a blank line between them the two comments are separate groups, so
    only the shebang's group is skipped: it is left byte-identical (no space
    inserted after `//`) while the diagnose line is rewritten with the config
    resolved from the module's go.mod.

    CATCHES: a re-implementation that inserts the doc-comment space into the
    shebang line, or whose group skipping is all-or-nothing for the file,
    breaks one of the two halves of this output.
    """
    source = b"//usr/bin/env go run x.go\n\n//gofumpt:diagnose\npackage p\n\nfunc F() {}\n"
    res = run_in_module(tmp_path, source)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"//usr/bin/env go run x.go\n\n"
        + diagnose_line("go1.21", "mymod")
        + b"\npackage p\n\nfunc F() {}\n"
    )


def test_first_line_without_bin_slash_is_not_a_shebang(tmp_path):
    """Only line-1 comments containing `bin/` count as shebangs.

    `//nobeans here` has no `bin/`, so its group is processed normally: the
    diagnose directive below it is rewritten, and the other line is doc-
    formatted as prose with a space and a blank comment separator.

    CATCHES: a re-implementation that treats any comment on line 1 as a
    shebang skips the group and leaves the directive unwritten; one whose
    pattern matches too broadly does the same for this line.
    """
    source = b"//nobeans here\n//gofumpt:diagnose\npackage p\n\nfunc F() {}\n"
    res = run_in_module(tmp_path, source)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"// nobeans here\n//\n"
        + diagnose_line("go1.21", "mymod")
        + b"\npackage p\n\nfunc F() {}\n"
    )
