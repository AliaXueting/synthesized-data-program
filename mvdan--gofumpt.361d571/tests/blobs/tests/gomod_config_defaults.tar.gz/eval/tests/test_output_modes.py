"""User-observable I/O around the resolved configuration.

How the config-driven rewrite surfaces in gofumpt's output modes (-l, -d,
-w), how generated files skip the rules (and thus the config effects) unless
named explicitly, and how go.mod `ignore` directives skip directories during
walks while explicitly named arguments still get formatted.
"""

from conftest import (
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

DIAGNOSE_FILE = b"package p\n\n//gofumpt:diagnose\nfunc F() {}\n"
NO_CHANGE_FILE = b"package p\n\n//gofumpt:diagnosefoobar\nfunc F() {}\n"
OCTAL_FILE = b"package p\n\nvar x = 0777\n"


def make_module(tmp_path, gomod="module example.com/m\n\ngo 1.21\n"):
    mod = tmp_path / "m"
    write_module(mod, gomod)
    return mod


def test_list_mode_reports_config_driven_change(tmp_path):
    """-l lists exactly the files whose diagnose line gofumpt would rewrite.

    CATCHES: a reimplementation that resolves the config but never compares
    the rewritten comment against the source would list nothing (or list the
    unchanged lookalike file too), and would print something other than the
    bare filename on stdout.
    """
    mod = make_module(tmp_path)
    write(mod / "d.go", DIAGNOSE_FILE)
    write(mod / "nc.go", NO_CHANGE_FILE)
    res = run_gofumpt(["-l", "d.go"], cwd=mod)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"d.go\n"
    # A file without a qualifying directive is not listed.
    res = run_gofumpt(["-l", "nc.go"], cwd=mod)
    assert res.returncode == 0
    assert res.stdout == b""


def test_diff_mode_shows_diagnose_change(tmp_path):
    """-d prints a unified diff of the diagnose rewrite and exits 1.

    CATCHES: a reimplementation exiting 0 on differences, diffing with
    different header names, or leaving the directive out of the diff would
    not produce these exact bytes and exit code.
    """
    mod = make_module(tmp_path)
    write(mod / "d.go", DIAGNOSE_FILE)
    write(mod / "nc.go", NO_CHANGE_FILE)
    res = run_gofumpt(["-d", "d.go"], cwd=mod)
    assert res.returncode == 1
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"diff d.go.orig d.go\n"
        b"--- d.go.orig\n"
        b"+++ d.go\n"
        b"@@ -1,4 +1,4 @@\n"
        b" package p\n"
        b" \n"
        b"-//gofumpt:diagnose\n"
        b"+//gofumpt:diagnose version: <VERSION> flags: -lang=go1.21 -modpath=example.com/m\n"
        b" func F() {}\n"
    )
    # Without a change there is no diff and no failure exit code.
    res = run_gofumpt(["-d", "nc.go"], cwd=mod)
    assert res.returncode == 0
    assert res.stdout == b""


def test_write_mode_persists_resolved_config(tmp_path):
    """-w rewrites the diagnose line in place and is idempotent.

    CATCHES: a reimplementation writing the formatted bytes without applying
    the config (or failing to make the second run a no-op) leaves the stale
    directive on disk; the file content after each -w run pins both.
    """
    mod = make_module(tmp_path)
    write(mod / "d.go", DIAGNOSE_FILE)
    res = run_gofumpt(["-w", "d.go"], cwd=mod)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    expected = (
        b"package p\n\n//gofumpt:diagnose version: <VERSION>"
        b" flags: -lang=go1.21 -modpath=example.com/m\nfunc F() {}\n"
    )
    assert normalize_version((mod / "d.go").read_bytes()) == expected
    # A second -w run changes nothing further, and -l now reports nothing.
    res = run_gofumpt(["-w", "d.go"], cwd=mod)
    assert res.returncode == 0
    assert normalize_version((mod / "d.go").read_bytes()) == expected
    res = run_gofumpt(["-l", "d.go"], cwd=mod)
    assert res.returncode == 0
    assert res.stdout == b""


def test_list_walk_across_modules(tmp_path):
    """-l over a walk lists each file under its own module's resolution.

    CATCHES: a reimplementation listing files in argument or glob order (or
    resolving one module for the walk) would reorder the listing or miss
    plain/pl.go, which only changes because it inherits the root module.
    """
    tree = tmp_path / "mix"
    write_module(tree, "module example.com/mix\n\ngo 1.12\n")
    write(tree / "root.go", DIAGNOSE_FILE)
    write_module(tree / "in", "module example.com/in\n\ngo 1.13\n")
    write(tree / "in" / "in.go", DIAGNOSE_FILE)
    write(tree / "plain" / "pl.go", DIAGNOSE_FILE)
    res = run_gofumpt(["-l", "."], cwd=tree)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"in/in.go\nplain/pl.go\nroot.go\n"


def test_generated_files_skip_rules_unless_explicit(tmp_path):
    """Walked generated files get no gofumpt rules; explicit ones do.

    CATCHES: a reimplementation applying the config-driven rewrites to
    generated files during walks would rewrite the diagnose line and the
    octal literal in gen.go even when it is only found by walking, where the
    reference leaves the file completely untouched.
    """
    gen = make_module(tmp_path, "module example.com/gen\n\ngo 1.21\n")
    source = (
        b"// Code generated by tool. DO NOT EDIT.\n\npackage p\n\n"
        b"//gofumpt:diagnose\n\nvar x = 0777\n"
    )
    write(gen / "gen.go", source)
    # Found by walking: printed unchanged (plain gofmt output only).
    res = run_gofumpt(["."], cwd=gen)
    assert res.returncode == 0, res.stderr
    assert res.stdout == source
    # Named explicitly: the gofumpt rules (and the resolved config) apply.
    res = run_gofumpt(["gen.go"], cwd=gen)
    assert res.returncode == 0, res.stderr
    assert normalize_version(res.stdout) == (
        b"// Code generated by tool. DO NOT EDIT.\n\npackage p\n\n"
        b"//gofumpt:diagnose version: <VERSION> flags: -lang=go1.21 -modpath=example.com/gen\n"
        b"\nvar x = 0o777\n"
    )


def test_ignore_directives_skip_walked_directories(tmp_path):
    """go.mod `ignore` entries remove directories from recursive walks.

    CATCHES: a reimplementation skipping the whole subtree of an ignored
    directory would also drop skipme/deep, and one ignoring unrooted entries
    by exact path only would format x/sub; only these three files are listed.
    """
    ig = tmp_path / "ig"
    write_module(ig, "module example.com/ig\n\ngo 1.21\n\nignore ./skipme\nignore x/sub\n")
    for rel in ("root", "skipme/s", "skipme/deep/d", "x/sub/s", "x/top", "keep/k"):
        write(ig / (rel + ".go"), OCTAL_FILE)
    res = run_gofumpt(["-l", "."], cwd=ig)
    assert res.returncode == 0
    assert res.stderr == b""
    # skipme/ is skipped as a directory; x/sub matches the unrooted entry.
    assert res.stdout == b"keep/k.go\nroot.go\nx/top.go\n"


def test_ignored_directory_named_explicitly_is_formatted(tmp_path):
    """Naming an ignored directory explicitly formats it, including subdirs.

    CATCHES: a reimplementation applying `ignore` to explicit arguments (or
    cascading a rooted ./entry to its subdirectories) would skip skipme/
    entirely or list only skipme/s.go instead of both files below.
    """
    ig = tmp_path / "ig"
    write_module(ig, "module example.com/ig\n\ngo 1.21\n\nignore ./skipme\nignore x/sub\n")
    for rel in ("skipme/s", "skipme/deep/d", "x/sub/s", "x/top"):
        write(ig / (rel + ".go"), OCTAL_FILE)
    res = run_gofumpt(["-l", "skipme"], cwd=ig)
    assert res.returncode == 0
    assert res.stdout == b"skipme/deep/d.go\nskipme/s.go\n"
    # x itself is not ignored, only x/sub, so x/top.go still shows up.
    res = run_gofumpt(["-l", "x"], cwd=ig)
    assert res.returncode == 0
    assert res.stdout == b"x/top.go\n"


def test_ignore_entry_for_a_file_has_no_effect(tmp_path):
    """`ignore` only applies to directories; a file entry changes nothing.

    CATCHES: a reimplementation applying ignore entries to walked files
    would skip skip.go during the walk, leaving keep.go as the only listed
    file instead of both.
    """
    igf = tmp_path / "igf"
    write_module(igf, "module example.com/igf\n\ngo 1.21\n\nignore ./skip.go\n")
    write(igf / "skip.go", OCTAL_FILE)
    write(igf / "keep.go", OCTAL_FILE)
    res = run_gofumpt(["-l", "."], cwd=igf)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"keep.go\nskip.go\n"
