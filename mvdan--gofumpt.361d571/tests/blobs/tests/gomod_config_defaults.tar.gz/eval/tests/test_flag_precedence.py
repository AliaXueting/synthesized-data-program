"""Precedence and validation of the -lang and -modpath flags.

Explicit -lang/-modpath flags win, per flag, over the values discovered in
go.mod. Flag values are normalized like Go versions, invalid values make the
binary panic with a specific first line and exit status 2, and empty flag
values fall back to the go.mod defaults. Stdin honours the flags the same way
file arguments do.
"""

import pytest

from conftest import (
    DIAGNOSE_SOURCE,
    diagnose_output,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

MOD_GOMOD = "module example.com/mymod\n\ngo 1.21.2\n"


def make_module(tmp_path, gomod=MOD_GOMOD):
    mod = tmp_path / "m"
    write_module(mod, gomod)
    write(mod / "a.go", DIAGNOSE_SOURCE)
    return mod


def assert_clean(res, lang, modpath):
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == diagnose_output(lang, modpath)


def test_flags_override_gomod_per_flag(tmp_path):
    """Each flag replaces only its own go.mod default, leaving the other alone.

    CATCHES: a reimplementation where passing one flag suppresses the go.mod
    lookup for both would lose -modpath=example.com/mymod when only -lang is
    given, and vice versa.
    """
    mod = make_module(tmp_path)
    # -lang wins, -modpath still comes from go.mod.
    assert_clean(run_gofumpt(["-lang=go1.13", "a.go"], cwd=mod), "go1.13", "example.com/mymod")
    # -modpath wins, -lang still comes from go.mod.
    assert_clean(run_gofumpt(["-modpath=other.io/x", "a.go"], cwd=mod), "go1.21", "other.io/x")
    # Both flags win.
    assert_clean(run_gofumpt(["-lang=go1.17", "-modpath=zz", "a.go"], cwd=mod), "go1.17", "zz")


def test_empty_flag_values_fall_back_to_gomod(tmp_path):
    """Passing -lang= or -modpath= is the same as not passing the flag at all.

    CATCHES: a reimplementation treating an explicitly empty flag as an
    override would report -lang= or -modpath= as final values instead of
    falling back to go1.21/example.com/mymod.
    """
    mod = make_module(tmp_path)
    assert_clean(run_gofumpt(["-lang=", "a.go"], cwd=mod), "go1.21", "example.com/mymod")
    assert_clean(run_gofumpt(["-modpath=", "a.go"], cwd=mod), "go1.21", "example.com/mymod")


def test_lang_flag_value_normalized(tmp_path):
    """The -lang flag value is normalized like go/version.Lang before use.

    CATCHES: a reimplementation echoing the flag verbatim would print
    -lang=go1.13.5, -lang=go1.14rc2 or -lang=go1.0 in the diagnose line
    instead of the normalized go1.13/go1.14/go1 forms.
    """
    mod = make_module(tmp_path)
    for flag_value, normalized in (
        ("go1.13.5", "go1.13"),
        ("go1.14rc2", "go1.14"),
        ("go1.14beta1", "go1.14"),
        ("go1", "go1"),
    ):
        assert_clean(
            run_gofumpt(["-lang=" + flag_value, "a.go"], cwd=mod),
            normalized,
            "example.com/mymod",
        )


@pytest.mark.parametrize("bad_lang", ["1.13", "foo", "v1.13"])
def test_invalid_lang_flag_panics(tmp_path, bad_lang):
    """An invalid -lang value panics with a fixed first line and exit code 2.

    CATCHES: a reimplementation that silently ignores an unparseable -lang
    (falling back to go1) or exits with a different status/message would miss
    the exact `panic: invalid Go version: "..."` contract.
    """
    mod = make_module(tmp_path)
    res = run_gofumpt(["-lang=" + bad_lang, "a.go"], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(
        ('panic: invalid Go version: "%s"\n' % bad_lang).encode()
    )


def test_flag_syntax_variants(tmp_path):
    """--flag, space-separated and repeated flags all resolve as Go's flag package does.

    CATCHES: a reimplementation with its own argument parser would mishandle
    the double-dash form, the "-lang go1.15" spelling, or last-flag-wins
    repetition, reporting a different -lang in the diagnose line.
    """
    mod = make_module(tmp_path)
    assert_clean(run_gofumpt(["--lang=go1.15", "a.go"], cwd=mod), "go1.15", "example.com/mymod")
    assert_clean(run_gofumpt(["-lang", "go1.15", "a.go"], cwd=mod), "go1.15", "example.com/mymod")
    assert_clean(
        run_gofumpt(["-lang=go1.15", "-lang=go1.16", "a.go"], cwd=mod),
        "go1.16",
        "example.com/mymod",
    )


def test_modpath_flag_with_equals_sign(tmp_path):
    """An '=' inside the -modpath value is kept verbatim.

    CATCHES: a reimplementation splitting flag values on '=' would truncate
    -modpath=a=b to "a" (or error), instead of reporting -modpath=a=b.
    """
    mod = make_module(tmp_path)
    assert_clean(run_gofumpt(["-modpath=a=b", "a.go"], cwd=mod), "go1.21", "a=b")


def test_flags_apply_when_gomod_is_invalid(tmp_path):
    """With an unparseable go.mod the flags still take effect.

    CATCHES: a reimplementation that aborts module loading entirely (or lets
    the broken go.mod clobber the flags) would report go1/empty instead of
    the explicitly passed values.
    """
    mod = make_module(tmp_path, "module example.com/mymod\n\ngo 1.x\n")
    assert_clean(run_gofumpt(["-lang=go1.20", "a.go"], cwd=mod), "go1.20", "")
    assert_clean(run_gofumpt(["-modpath=corp/x", "a.go"], cwd=mod), "go1", "corp/x")


def test_flags_apply_without_any_module(tmp_path):
    """Outside any module, the flags are the only source of configuration.

    CATCHES: a reimplementation keying configuration entirely off go.mod
    would ignore the flags here and report go1 with an empty -modpath.
    """
    nomod = tmp_path / "nomod"
    write(nomod / "a.go", DIAGNOSE_SOURCE)
    assert_clean(run_gofumpt(["-lang=go1.20", "a.go"], cwd=nomod), "go1.20", "")
    assert_clean(run_gofumpt(["-modpath=corp/lib", "a.go"], cwd=nomod), "go1", "corp/lib")
    assert_clean(
        run_gofumpt(["-lang=go1.13", "-modpath=corp/lib", "a.go"], cwd=nomod),
        "go1.13",
        "corp/lib",
    )


def test_stdin_respects_flags(tmp_path):
    """Stdin formatting honours -lang/-modpath exactly like file arguments.

    CATCHES: a reimplementation wiring flags only into the file-argument code
    path would format stdin with the go.mod defaults (go1.21 here) instead
    of the flag values.
    """
    mod = make_module(tmp_path)
    res = run_gofumpt(["-lang=go1.15", "-modpath=flagged/path"], cwd=mod, stdin=DIAGNOSE_SOURCE)
    assert_clean(res, "go1.15", "flagged/path")


def test_unknown_extra_rule_is_a_flag_error(tmp_path):
    """-extra with an unknown rule name fails flag parsing with a fixed message.

    CATCHES: a reimplementation accepting unknown rule names (or printing a
    different usage text) would not produce this exact stderr and exit code.
    """
    mod = make_module(tmp_path)
    res = run_gofumpt(["-extra=bogus", "a.go"], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b'invalid boolean value "bogus" for -extra: unknown rule: "bogus"\n'
        b"usage: gofumpt [flags] [path ...]\n"
        b"\t-version  show version and exit\n"
        b"\n"
        b"\t-d        display diffs instead of rewriting files\n"
        b"\t-e        report all errors (not just the first 10 on different lines)\n"
        b"\t-l        list files whose formatting differs from gofumpt's\n"
        b"\t-w        write result to (source) file instead of stdout\n"
        b"\t-extra    enable extra rules, e.g. -extra=group_params,clothe_returns\n"
        b"\n"
        b'\t-lang       str    target Go version in the form "go1.X" (default from go.mod)\n'
        b"\t-modpath    str    Go module path containing the source file (default from go.mod)\n"
    )
