"""Print-measurement rules for multi-line conditions and declarations.

Round 5's coverage target is internal/govendor/go/format/format.go, the
vendored go/format package. The CLI reaches it only through helpers that
print a candidate node to predict what go/printer will do; rounds 2-4
pinned the empty-brace, lone-decl and case-clause measurements. This file
pins the last two reachable callers:

- a block whose if/for condition spans source lines: when the printed
  condition stays multi-line (go/printer preserves a break at a binary
  operator, and a line comment forces one), gofumpt keeps the blank line
  after the `{`; when the printer joins the condition's lines (a unary
  `!` operand break is not preserved), the blank line is removed like any
  other;
- adjacent top-level declarations: a declaration that occupies ONE source
  line but PRINTS over several lines (a one-line func holding a switch or
  a for loop) counts as multi-line, so adjacent such declarations gain a
  blank line between them, while a func that prints on one line (a plain
  call body, `select {}`) keeps them adjacent.
"""

import pytest

from conftest import run_gofumpt, write


def fmt(tmp_path, source, args=()):
    """Write source to a.go under tmp_path and format it as an explicit file."""
    write(tmp_path / "a.go", source)
    res = run_gofumpt(list(args) + ["a.go"], cwd=tmp_path)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    return res.stdout


def test_binary_condition_break_is_preserved(tmp_path):
    """A binary condition's line break survives, and so does the blank line.

    go/printer keeps a source break at a binary operator, so the condition
    still prints on two lines; gofumpt then leaves the blank line after the
    `{` in place instead of removing it as it normally would at a block
    start.

    CATCHES: a re-implementation that always removes leading blank lines
    in a block (or always joins condition lines) changes this output.
    """
    source = (
        b"package p\n\nfunc f(x, y bool) {\n\tif x &&\n\t\ty {\n\n\t\tz()\n\t}\n}\n"
    )
    assert fmt(tmp_path, source) == source


def test_line_comment_in_condition_keeps_the_split(tmp_path):
    """A line comment inside the condition keeps it multi-line.

    The comment is printed with the condition (the helper passes the
    enclosing comments along), so the printed condition cannot fit on one
    line and the blank line after the `{` is kept.

    CATCHES: a re-implementation that measures the condition without its
    comments joins `x && // c\n\ty` onto one line and drops the blank line.
    """
    source = (
        b"package p\n\nfunc f(x, y bool) {\n\tif x && // c\n\t\ty {\n\n\t\tz()\n\t}\n}\n"
    )
    assert fmt(tmp_path, source) == source


@pytest.mark.parametrize("keyword", [b"if", b"for"], ids=["if", "for"])
def test_unary_condition_is_joined_and_blank_removed(tmp_path, keyword):
    """A unary operand break is not preserved, so the blank line goes too.

    `!\\n\\tx` prints as `!x` on one line, the condition no longer counts as
    multi-line, and gofumpt removes the blank line after the `{` while
    joining the condition — for both if and for statements.

    CATCHES: a re-implementation that treats any source line span in the
    condition as multi-line keeps `!\\n\\tx` split and the blank line too.
    """
    source = (
        b"package p\n\nfunc f(x bool) {\n\t"
        + keyword
        + b" !\n\t\tx {\n\n\t\tz()\n\t}\n}\n"
    )
    assert fmt(tmp_path, source) == (
        b"package p\n\nfunc f(x bool) {\n\t"
        + keyword
        + b" !x {\n\t\tz()\n\t}\n}\n"
    )


def test_single_line_condition_blank_line_removed(tmp_path):
    """With a one-line condition the leading blank line is removed.

    This is the control for the two tests above: without a multi-line
    condition nothing keeps the blank line after the `{`.

    CATCHES: a re-implementation that preserves leading blank lines in
    blocks unconditionally fails here, so the pair together pins that it
    is the printed condition shape that decides.
    """
    assert fmt(
        tmp_path,
        b"package p\n\nfunc f(x bool) {\n\tif x {\n\n\t\tz()\n\t}\n}\n",
    ) == b"package p\n\nfunc f(x bool) {\n\tif x {\n\t\tz()\n\t}\n}\n"


@pytest.mark.parametrize(
    "body,printed_body",
    [
        (b"switch { case 1: }", b"switch {\n\tcase 1:\n\t}"),
        (b"for { break }", b"for {\n\t\tbreak\n\t}"),
    ],
    ids=["switch", "for"],
)
def test_one_line_func_printing_multiline_gains_blank_line(tmp_path, body, printed_body):
    """Adjacent one-line funcs that print multi-line get a blank line.

    Each declaration sits on a single source line, so only printing the
    declaration (through the vendored go/format) reveals that go/printer
    will break its body across lines; two such declarations are separated
    by a blank line exactly like hand-written multi-line ones.

    CATCHES: a re-implementation deciding "multi-line" from source line
    spans alone leaves the two one-line funcs adjacent with no blank line.
    """
    source = (
        b"package p\n\nfunc a() { " + body + b" }\nfunc b() { " + body + b" }\n"
    )
    expected = (
        b"package p\n\nfunc a() {\n\t" + printed_body + b"\n}\n\n"
        b"func b() {\n\t" + printed_body + b"\n}\n"
    )
    assert fmt(tmp_path, source) == expected


@pytest.mark.parametrize(
    "body",
    [b"z()", b"select {}"],
    ids=["plain-call", "select"],
)
def test_one_line_func_printing_one_line_stays_adjacent(tmp_path, body):
    """One-line funcs that really print on one line stay adjacent.

    A plain call body and an empty select both print on a single line, so
    no blank line is inserted between the two declarations.

    CATCHES: a re-implementation that separates every pair of one-line
    funcs (or that mispredicts `select {}` as multi-line) inserts a blank
    line here.
    """
    source = b"package p\n\nfunc a() { " + body + b" }\nfunc b() { " + body + b" }\n"
    assert fmt(tmp_path, source) == source


def test_blank_line_between_each_pair_of_three(tmp_path):
    """Three one-line switch-funcs get a blank line between each pair.

    CATCHES: a re-implementation that only separates the first pair (or
    that collapses the run) misses the blank line between b and c.
    """
    assert fmt(
        tmp_path,
        b"package p\n\n"
        b"func a() { switch { case 1: } }\n"
        b"func b() { switch { case 1: } }\n"
        b"func c() { switch { case 1: } }\n",
    ) == (
        b"package p\n\n"
        b"func a() {\n\tswitch {\n\tcase 1:\n\t}\n}\n\n"
        b"func b() {\n\tswitch {\n\tcase 1:\n\t}\n}\n\n"
        b"func c() {\n\tswitch {\n\tcase 1:\n\t}\n}\n"
    )


def test_single_line_decl_between_multiline_decls_stays_adjacent(tmp_path):
    """The blank line needs BOTH declarations to print multi-line.

    A plain one-line func between two switch-funcs stays attached to both:
    no blank line is inserted around a declaration that prints on one line,
    even next to one that does not.

    CATCHES: a re-implementation that inserts a blank line after any
    multi-line declaration (instead of requiring both sides) separates
    func b from its neighbors here.
    """
    assert fmt(
        tmp_path,
        b"package p\n\n"
        b"func a() { switch { case 1: } }\n"
        b"func b() { z() }\n"
        b"func c() { switch { case 1: } }\n",
    ) == (
        b"package p\n\n"
        b"func a() {\n\tswitch {\n\tcase 1:\n\t}\n}\n"
        b"func b() { z() }\n"
        b"func c() {\n\tswitch {\n\tcase 1:\n\t}\n}\n"
    )


def test_trailing_comment_extends_the_declaration(tmp_path):
    """A trailing comment on the decl's line comes before the blank line.

    The inline `// keep` comment extends the first declaration's effective
    end, so the inserted blank line lands after the comment, not between
    the closing brace and the comment.

    CATCHES: a re-implementation inserting the newline at the decl's End()
    (before the comment) prints `} // keep` and then the comment again on
    the wrong side of the blank line.
    """
    assert fmt(
        tmp_path,
        b"package p\n\n"
        b"func a() { switch { case 1: } } // keep\n"
        b"func b() { switch { case 1: } }\n",
    ) == (
        b"package p\n\n"
        b"func a() {\n\tswitch {\n\tcase 1:\n\t}\n} // keep\n\n"
        b"func b() {\n\tswitch {\n\tcase 1:\n\t}\n}\n"
    )


def test_already_separated_multiline_decls_are_left_alone(tmp_path):
    """An existing blank line between the funcs is not doubled.

    CATCHES: a re-implementation inserting a blank line per adjacency
    check without testing for one already present leaves two blank lines
    between the expanded bodies.
    """
    assert fmt(
        tmp_path,
        b"package p\n\n"
        b"func a() { switch { case 1: } }\n\n"
        b"func b() { switch { case 1: } }\n",
    ) == (
        b"package p\n\n"
        b"func a() {\n\tswitch {\n\tcase 1:\n\t}\n}\n\n"
        b"func b() {\n\tswitch {\n\tcase 1:\n\t}\n}\n"
    )
