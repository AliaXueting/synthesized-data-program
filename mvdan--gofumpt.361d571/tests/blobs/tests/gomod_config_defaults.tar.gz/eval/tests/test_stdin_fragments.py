"""Standard input as a partial source file under the resolved config.

With no path arguments gofumpt reads stdin, and unlike a file it accepts a
program fragment (a declaration or statement list without a `package`
clause). The configuration still comes from the working directory's go.mod
(or the flags), so the version-gated rewrites and the diagnose line can be
observed on fragments exactly as on whole files.
"""

from conftest import diagnose_line, normalize_version, run_gofumpt, write_module

GOMOD = "module frag\n\ngo 1.13\n"


def make_module(tmp_path):
    mod = tmp_path / "m"
    write_module(mod, GOMOD)
    return mod


def test_decl_fragment_uses_module_lang(tmp_path):
    """A declaration-list fragment gets the go.mod's version gate.

    CATCHES: the octal rewrite needs -lang >= go1.13; the fragment path
    must resolve the module from the working directory just like whole
    files, rewriting `0777` to `0o777` with no added wrapping.
    """
    mod = make_module(tmp_path)
    res = run_gofumpt([], cwd=mod, stdin=b"var x = 0777\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"var x = 0o777\n"


def test_stmt_fragment_uses_module_lang(tmp_path):
    """A statement-list fragment is also formatted with the module config.

    CATCHES: statements get wrapped in a synthetic function to parse; a
    reimplementation that skips the version-gated rules on that path would
    leave `0777` instead of the observed `0o777`.
    """
    mod = make_module(tmp_path)
    res = run_gofumpt([], cwd=mod, stdin=b"x := 0777\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"x := 0o777\n"


def test_fragment_diagnose_reports_module_config(tmp_path):
    """The diagnose directive is rewritten in a fragment with the go.mod values.

    CATCHES: the resolved -lang=go1.13 -modpath=frag pair from the working
    directory's go.mod must appear in the rewritten comment even though the
    input has no package clause; the octal rewrite confirms the same config.
    """
    mod = make_module(tmp_path)
    res = run_gofumpt([], cwd=mod, stdin=b"//gofumpt:diagnose\nvar x = 0777\n")
    assert res.returncode == 0
    assert normalize_version(res.stdout) == (
        diagnose_line("go1.13", "frag") + b"\nvar x = 0o777\n"
    )


def test_fragment_without_module_keeps_octal(tmp_path):
    """Outside any module a fragment behaves like go1: the octal stays.

    CATCHES: without a go.mod the effective language version must be the
    go1 default (no rewrite), while an explicit -lang flag still wins on
    the very same fragment input.
    """
    res = run_gofumpt([], cwd=tmp_path, stdin=b"var x = 0777\n")
    assert res.returncode == 0
    assert res.stdout == b"var x = 0777\n"
    res = run_gofumpt(["-lang=go1.13"], cwd=tmp_path, stdin=b"var x = 0777\n")
    assert res.returncode == 0
    assert res.stdout == b"var x = 0o777\n"


def test_indented_fragment_preserves_indentation(tmp_path):
    """A fragment indented with tabs keeps its indentation in the output.

    CATCHES: the fragment formatter re-indents by the first code line's
    tab count; dropping or doubling it would change these exact bytes.
    """
    mod = make_module(tmp_path)
    res = run_gofumpt([], cwd=mod, stdin=b"\tx := 0777\n\ty := 0\n")
    assert res.returncode == 0
    assert res.stdout == b"\tx := 0o777\n\ty := 0\n"
