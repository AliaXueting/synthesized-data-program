"""Line-measurement rules: join/split decisions made by printing nodes.

Round 2's coverage target is internal/govendor/go/format/format.go — the
vendored go/format package. The CLI only reaches that file through gofumpt's
node-measurement helpers, which print a candidate node (via the vendored
format.Node) to decide whether the lines it spans may be joined: empty
braces, lone var/const declarations, case clauses, and adjacent multi-line
top-level declarations. These tests pin those join/split decisions
byte-for-byte, including the exact length threshold (the printed bytes plus
one tab per enclosing block must fit within 60 columns) and the module
config interactions: the go.mod-resolved -lang rewrites 0777 to 0o777 before
a case clause is measured, so the very same source joins or splits depending
on the governing go.mod, and the -modpath from go.mod separates joined lone
imports into std and non-std sections.
"""

import pytest

from conftest import diagnose_line, normalize_version, run_gofumpt, write, write_module

# The case-clause expression whose "case <expr>:" form is exactly one byte
# shorter than the join threshold at switch depth 1: rewriting the octal
# literal to 0o777 grows it past the threshold.
BOUNDARY_A30 = "a" * 30
BOUNDARY_EXPR = "0777 + " + BOUNDARY_A30
# The two recorded outcomes for BOUNDARY_EXPR under the two lang versions.
JOIN_0777 = (
    "package p\n\nfunc f(x int) {\n\tswitch x {\n"
    "\tcase 0777 + %s:\n\t\tf(1)\n\t}\n}\n" % BOUNDARY_A30
)
SPLIT_0O777 = (
    "package p\n\nfunc f(x int) {\n\tswitch x {\n"
    "\tcase\n\t\t0o777 + %s:\n\t\tf(1)\n\t}\n}\n" % BOUNDARY_A30
)


def assert_output(res, expected):
    """Assert a clean run whose stdout is exactly the recorded bytes."""
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == expected


def fmt_source(tmp_path, source, args=()):
    """Write source to a.go under tmp_path and format it as an explicit file."""
    write(tmp_path / "a.go", source)
    return run_gofumpt(list(args) + ["a.go"], cwd=tmp_path)


def split_case_source(expr, nested):
    """A switch whose single case clause is split over two source lines.

    With nested=True the switch sits inside an if, one block deeper, so the
    measured line carries one more tab of indentation.
    """
    if nested:
        return (
            "package p\n\nfunc f(x int) {\n\tif x {\n\t\tswitch x {\n"
            "\t\tcase\n\t\t\t%s:\n\t\t\tf(1)\n\t\t}\n\t}\n}\n" % expr
        )
    return (
        "package p\n\nfunc f(x int) {\n\tswitch x {\n"
        "\tcase\n\t\t%s:\n\t\tf(1)\n\t}\n}\n" % expr
    )


def joined_case_output(expr, nested):
    """The same switch after gofumpt joined the case clause onto one line."""
    if nested:
        return (
            "package p\n\nfunc f(x int) {\n\tif x {\n\t\tswitch x {\n"
            "\t\tcase %s:\n\t\t\tf(1)\n\t\t}\n\t}\n}\n" % expr
        )
    return (
        "package p\n\nfunc f(x int) {\n\tswitch x {\n"
        "\tcase %s:\n\t\tf(1)\n\t}\n}\n" % expr
    )


# Each pair is (input, recorded output): an empty pair of braces split over
# two lines is joined, whatever kind of node holds the braces.
EMPTY_BRACES = [
    pytest.param(
        "package p\n\ntype T struct {\n}\n",
        "package p\n\ntype T struct{}\n",
        id="struct",
    ),
    pytest.param(
        "package p\n\ntype I interface {\n}\n",
        "package p\n\ntype I interface{}\n",
        id="interface",
    ),
    pytest.param(
        "package p\n\nvar x = map[string]int{\n}\n",
        "package p\n\nvar x = map[string]int{}\n",
        id="map-composite",
    ),
    pytest.param(
        "package p\n\nvar y = []int{\n}\n",
        "package p\n\nvar y = []int{}\n",
        id="slice-composite",
    ),
    pytest.param(
        "package p\n\nvar x = T{\n}\n",
        "package p\n\nvar x = T{}\n",
        id="composite",
    ),
    pytest.param(
        "package p\n\nfunc f() {\n\tg(\n\t)\n}\n",
        "package p\n\nfunc f() {\n\tg()\n}\n",
        id="call",
    ),
]


@pytest.mark.parametrize("source,expected", EMPTY_BRACES)
def test_empty_braces_joined(tmp_path, source, expected):
    """Empty braces split over two lines are collapsed onto one line.

    CATCHES: a re-implementation that only joins some brace kinds (say struct
    and interface but not empty composite literals or call arguments) emits
    different bytes for the shapes it misses.
    """
    assert_output(fmt_source(tmp_path, source), expected.encode())


def test_blank_line_inside_empty_braces_still_joined(tmp_path):
    """A blank line between empty braces does not keep the lines apart.

    CATCHES: only comments keep empty braces split; a re-implementation
    treating any blank line like a comment would leave "type T struct {\n\n}"
    unjoined.
    """
    assert_output(
        fmt_source(tmp_path, "package p\n\ntype T struct {\n\n}\n"),
        b"package p\n\ntype T struct{}\n",
    )


@pytest.mark.parametrize(
    "source",
    [
        pytest.param("package p\n\ntype T struct {\n\t// keep apart\n}\n", id="struct"),
        pytest.param(
            "package p\n\nvar y = T{\n\t// keep apart too\n}\n", id="composite"
        ),
    ],
)
def test_comment_between_brace_lines_keeps_them_apart(tmp_path, source):
    """A comment between empty braces keeps them on separate lines.

    CATCHES: a re-implementation joining empty braces without checking for
    comments in between would swallow the comment's line and change output.
    """
    assert_output(fmt_source(tmp_path, source), source.encode())


@pytest.mark.parametrize(
    "source,expected",
    [
        pytest.param(
            "package p\n\ntype T struct { /* keep */ }\n",
            "package p\n\ntype T struct { /* keep */\n}\n",
            id="struct",
        ),
        pytest.param(
            "package p\n\ntype I interface { /* keep */ }\n",
            "package p\n\ntype I interface { /* keep */\n}\n",
            id="interface",
        ),
    ],
)
def test_one_line_braces_with_inline_comment_split_at_close(tmp_path, source, expected):
    """Braces already on one line, but not printing on one line, gain one.

    When a block comment inside the braces makes the node print over
    multiple lines, a newline is inserted before the closing brace.

    CATCHES: a re-implementation that only ever removes lines between braces
    (never adding one) leaves "struct { /* keep */ }" untouched instead of
    pushing the closing brace onto its own line.
    """
    assert_output(fmt_source(tmp_path, source), expected.encode())


@pytest.mark.parametrize(
    "source,expected",
    [
        pytest.param(
            "package p\n\nvar\nx =\n\t1\n", "package p\n\nvar x = 1\n", id="var"
        ),
        pytest.param(
            "package p\n\nconst\ny = 2\n", "package p\n\nconst y = 2\n", id="const"
        ),
    ],
)
def test_lone_decl_lines_collapsed(tmp_path, source, expected):
    """A lone var/const declaration split over lines is joined onto one.

    CATCHES: a re-implementation that only normalizes spacing within a line
    (never joining "var\nx =\n\t1" into "var x = 1") keeps the split form.
    """
    assert_output(fmt_source(tmp_path, source), expected.encode())


def test_lone_decl_trailing_comment_still_collapses(tmp_path):
    """A comment after the lone declaration's value does not block the join.

    CATCHES: the measurement only counts comments inside the measured node;
    a re-implementation counting the trailing "// trailing" comment as part
    of the spec would keep the declaration split over lines.
    """
    assert_output(
        fmt_source(tmp_path, "package p\n\nvar\nz = 1 // trailing\n"),
        b"package p\n\nvar z = 1 // trailing\n",
    )


def test_comment_between_keyword_and_spec_blocks_collapse(tmp_path):
    """A comment between the var keyword and its spec keeps the lines apart.

    CATCHES: a re-implementation joining lone declarations without checking
    for comments between the keyword and the spec would pull "// doc" onto
    the joined line.
    """
    source = "package p\n\nvar\n// doc\nx = 1\n"
    assert_output(fmt_source(tmp_path, source), source.encode())


def test_short_case_clause_joined(tmp_path):
    """A case clause split before its value is joined when it is short.

    CATCHES: a re-implementation that never collapses "case\n\t1:" back onto
    one line leaves every split case clause as-is in the output.
    """
    assert_output(
        fmt_source(tmp_path, split_case_source("1", nested=False)),
        joined_case_output("1", nested=False).encode(),
    )


@pytest.mark.parametrize(
    "nested,length,joins",
    [
        pytest.param(False, 37, True, id="depth1-len37-joins"),
        pytest.param(False, 38, False, id="depth1-len38-stays-split"),
        pytest.param(True, 29, True, id="depth2-len29-joins"),
        pytest.param(True, 30, False, id="depth2-len30-stays-split"),
    ],
)
def test_case_clause_length_boundary(tmp_path, nested, length, joins):
    """Case clauses join only while the measured line fits 60 columns.

    The measured bytes are the printed "case <expr>:" plus one tab per
    enclosing block, so the same expression length joins at one nesting
    depth but not one block deeper.

    CATCHES: a re-implementation with an off-by-one in the 60-column
    threshold (or one that ignores indentation depth when measuring) joins
    the 38-byte or depth-2 30-byte cases that must stay split.
    """
    expr = ("a" if not nested else "b") * length
    source = split_case_source(expr, nested)
    res = fmt_source(tmp_path, source)
    if joins:
        assert_output(res, joined_case_output(expr, nested).encode())
    else:
        # Too long to collapse: the output is byte-identical to the input.
        assert_output(res, source.encode())


def test_case_clause_inline_comment_counted(tmp_path):
    """An inline comment after the case value counts toward the 60 columns.

    CATCHES: a re-implementation measuring only "case <expr>:" without the
    trailing "// cccccccc" comment joins both clauses here; the reference
    joins the bare one and leaves the commented one split.
    """
    expr = "a" * 30
    assert_output(
        fmt_source(tmp_path, split_case_source(expr, nested=False)),
        joined_case_output(expr, nested=False).encode(),
    )
    # The same expression with an inline comment after the colon: the
    # comment's bytes count toward the threshold, so the clause stays split.
    source = (
        "package p\n\nfunc f(x int) {\n\tswitch x {\n"
        "\tcase\n\t\t%s: // cccccccc\n\t\tf(2)\n\t}\n}\n" % expr
    )
    assert_output(fmt_source(tmp_path, source), source.encode())


def test_comment_between_case_and_value_blocks_collapse(tmp_path):
    """A comment between the case keyword and its value keeps lines apart.

    CATCHES: a re-implementation joining case clauses without checking for
    comments between "case" and the value would move "// why" onto the
    joined line.
    """
    source = (
        "package p\n\nfunc f(x int) {\n\tswitch x {\n"
        "\tcase\n\t\t// why\n\t\t1:\n\t\tf(1)\n\t}\n}\n"
    )
    assert_output(fmt_source(tmp_path, source), source.encode())


def test_adjacent_multiline_decls_separated_by_blank_line(tmp_path):
    """Adjacent multi-line declarations gain a blank line between them.

    CATCHES: a re-implementation that only decides separation from source
    line spans of the declarations themselves (not from whether each prints
    on one line) leaves these two multi-line funcs glued together.
    """
    assert_output(
        fmt_source(
            tmp_path, "package p\n\nfunc f(\n\ta int,\n) {\n}\nfunc g(\n\tb int,\n) {\n}\n"
        ),
        b"package p\n\nfunc f(\n\ta int,\n) {\n}\n\nfunc g(\n\tb int,\n) {\n}\n",
    )


@pytest.mark.parametrize(
    "go_directive,lang_flag,joins",
    [
        pytest.param("go 1.12", None, True, id="gomod-1.12-joins"),
        pytest.param("go 1.13", None, False, id="gomod-1.13-splits"),
        pytest.param("go 1.12", "-lang=go1.13", False, id="flag-1.13-splits"),
        pytest.param("go 1.13", "-lang=go1.12", True, id="flag-1.12-joins"),
    ],
)
def test_octal_rewrite_length_flips_case_join(tmp_path, go_directive, lang_flag, joins):
    """The -lang-resolved octal rewrite changes the measured case length.

    The expression is sized so "case 0777 + <30 a's>:" fits the 60-column
    join threshold but "case 0o777 + <30 a's>:" does not: the same source
    joins under a go 1.12 module and stays split under go 1.13, and an
    explicit -lang flag flips the decision in either direction.

    CATCHES: a re-implementation that applies the octal rewrite only after
    measuring lines (or that resolves -lang without the go.mod go directive)
    joins the case clause in every one of these runs, missing the
    version-dependent flip.
    """
    mod = tmp_path / "m"
    write_module(mod, "module example.com/m\n\n%s\n" % go_directive)
    write(mod / "a.go", split_case_source(BOUNDARY_EXPR, nested=False))
    args = [lang_flag] if lang_flag else []
    res = run_gofumpt(args + ["a.go"], cwd=mod)
    if joins:
        assert_output(res, JOIN_0777.encode())
    else:
        assert_output(res, SPLIT_0O777.encode())


@pytest.mark.parametrize(
    "gomod,expected",
    [
        pytest.param(
            "module mymod\n\ngo 1.16\n",
            b'package p\n\nimport (\n\t"fmt"\n\n\t"mymod/sub"\n)\n',
            id="with-dotless-module",
        ),
        pytest.param(
            None,
            b'package p\n\nimport (\n\t"fmt"\n\t"mymod/sub"\n)\n',
            id="without-module",
        ),
    ],
)
def test_lone_imports_joined_with_modpath_separation(tmp_path, gomod, expected):
    """Joined lone imports split into std/non-std per the resolved -modpath.

    Contiguous lone import lines merge into one group; whether "mymod/sub"
    (no dot, so not third-party by spelling) is separated by a blank line
    depends entirely on the dotless module path discovered from go.mod.

    CATCHES: a re-implementation that joins lone imports but classifies them
    without the go.mod-resolved -modpath keeps "mymod/sub" next to "fmt"
    inside the module, or separates it even outside any module.
    """
    mod = tmp_path / "m"
    if gomod is not None:
        write_module(mod, gomod)
    else:
        mod.mkdir(parents=True, exist_ok=True)
    write(mod / "a.go", 'package p\n\nimport "fmt"\nimport "mymod/sub"\n')
    assert_output(run_gofumpt(["a.go"], cwd=mod), expected)


def test_diagnose_and_case_collapse_together(tmp_path):
    """The diagnose rewrite and the case join apply in one pass.

    The rewritten //gofumpt:diagnose line reports the config resolved from
    the governing go.mod while the same run joins the file's split case
    clause, pinning both observables in a single output.

    CATCHES: a re-implementation that resolves the module config only on a
    separate code path from the formatting rules gets either the diagnose
    flags or the joined "case 1:" line wrong here.
    """
    mod = tmp_path / "m"
    write_module(mod, "module example.com/m113\n\ngo 1.13\n")
    write(
        mod / "b.go",
        "package p\n\n//gofumpt:diagnose\n"
        "func f(x int) {\n\tswitch x {\n\tcase\n\t\t1:\n\t\tf(1)\n\t}\n}\n",
    )
    res = run_gofumpt(["b.go"], cwd=mod)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"package p\n\n"
        + diagnose_line("go1.13", "example.com/m113")
        + b"\nfunc f(x int) {\n\tswitch x {\n\tcase 1:\n\t\tf(1)\n\t}\n}\n"
    )
