"""Module-path-gated formatting: import grouping via -modpath.

-modpath affects import grouping: import paths sharing the module path's
prefix are treated as non-std and kept out of the top std group, separated
by an empty line. Only the first path element of the module path is used as
the matching prefix, and an exact match or a "prefix/" match qualifies.
"""

from conftest import (
    run_gofumpt,
    write,
    write_module,
)

IMPORTS_SOURCE = (
    b'package p\n\nimport (\n\t"corp/lib/util"\n\t"fmt"\n)\n\n'
    b"func F() { util.U(); fmt.Println() }\n"
)

# With a matching -modpath, the corp import is non-std: std first, then a
# blank line, then the rest. Without it, "corp/lib/util" has no dot in its
# first element, so it counts as std and stays in the one group.
GROUPED = (
    b'package p\n\nimport (\n\t"fmt"\n\n\t"corp/lib/util"\n)\n\n'
    b"func F() { util.U(); fmt.Println() }\n"
)
UNGROUPED = IMPORTS_SOURCE


def format_imports(tmp_path, gomod=None, flags=()):
    """Write IMPORTS_SOURCE under the given go.mod and format it."""
    mod = tmp_path / "m"
    if gomod is not None:
        write_module(mod, gomod)
    else:
        mod.mkdir(parents=True, exist_ok=True)
    write(mod / "a.go", IMPORTS_SOURCE)
    return run_gofumpt(list(flags) + ["a.go"], cwd=mod)


def assert_output(res, expected):
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == expected


def test_module_path_separates_imports_from_std(tmp_path):
    """A go.mod module path moves same-prefix imports out of the std group.

    CATCHES: a reimplementation ignoring the discovered -modpath for import
    grouping leaves "corp/lib/util" in the single std group (no blank line),
    even though the diagnose report would show the right -modpath.
    """
    assert_output(
        format_imports(tmp_path, "module corp/lib\n\ngo 1.21\n"),
        GROUPED,
    )


def test_no_module_keeps_single_import_group(tmp_path):
    """Without a module the same import stays in the std group.

    CATCHES: a reimplementation guessing third-party imports from naming
    conventions would also split this group, which only a matching -modpath
    may do.
    """
    assert_output(format_imports(tmp_path), UNGROUPED)


def test_modpath_flag_matches_module_default(tmp_path):
    """An explicit -modpath has the same grouping effect as the go.mod default.

    CATCHES: a reimplementation wiring -modpath only into the diagnose report
    (not into the formatter options) keeps the single std group here.
    """
    assert_output(format_imports(tmp_path, flags=["-modpath=corp/lib"]), GROUPED)


def test_unrelated_modpath_leaves_group_alone(tmp_path):
    """Only a matching module path regroups imports; other values do nothing.

    CATCHES: a reimplementation splitting any non-dot import out of the std
    group (or overriding the module path with a non-matching flag value
    incorrectly) would separate "corp/lib/util" in both of these runs.
    """
    # A module whose path shares nothing with the import.
    assert_output(format_imports(tmp_path, "module other/thing\n\ngo 1.21\n"), UNGROUPED)
    # A flag that overrides the matching module path with a non-matching one.
    assert_output(
        format_imports(tmp_path, "module corp/lib\n\ngo 1.21\n", flags=["-modpath=zzz"]),
        UNGROUPED,
    )


def test_module_prefix_matching_rules(tmp_path):
    """Prefix matching uses the first path element, at a slash boundary.

    CATCHES: a reimplementation matching the whole module path as a plain
    string prefix would fail for "module corp" (whole path, no slash) and
    wrongly group "corp/lib/util" under "module corporation" (substring
    match) instead of requiring an exact or "prefix/" boundary.
    """
    # Module path without a slash: the whole path is the prefix.
    assert_output(format_imports(tmp_path, "module corp\n\ngo 1.21\n"), GROUPED)
    # A longer first element does not match ("corp" is not a prefix of
    # "corporation" at a path boundary... the import does not match here).
    assert_output(format_imports(tmp_path, "module corporation\n\ngo 1.21\n"), UNGROUPED)
    # A nested module still matches via its first path element.
    nested = tmp_path / "nested"
    write_module(nested, "module corp/outer\n\ngo 1.21\n")
    write_module(nested / "inner", "module corp/nested\n\ngo 1.19\n")
    write(nested / "inner" / "a.go", IMPORTS_SOURCE)
    assert_output(run_gofumpt(["inner/a.go"], cwd=nested), GROUPED)


def test_dotted_imports_are_third_party_without_module(tmp_path):
    """Imports with a dot in the first element are non-std even with no module.

    CATCHES: a reimplementation treating every import as std unless -modpath
    matches would keep "example.com/foo/bar" in the top group; the dot rule
    alone must separate it.
    """
    mod = tmp_path / "m"
    mod.mkdir()
    write(
        mod / "a.go",
        b'package p\n\nimport (\n\t"example.com/foo/bar"\n\t"fmt"\n)\n\nfunc F() {}\n',
    )
    res = run_gofumpt(["a.go"], cwd=mod)
    assert_output(
        res,
        b'package p\n\nimport (\n\t"fmt"\n\n\t"example.com/foo/bar"\n)\n\nfunc F() {}\n',
    )


def test_exact_prefix_import_match(tmp_path):
    """An import equal to the module prefix itself is non-std.

    CATCHES: a reimplementation only matching "prefix/..." (never the bare
    prefix) would leave the "corp" import in the std group.
    """
    mod = tmp_path / "m"
    write_module(mod, "module corp\n\ngo 1.21\n")
    write(mod / "a.go", b'package p\n\nimport (\n\t"corp"\n\t"fmt"\n)\n\nfunc F() {}\n')
    res = run_gofumpt(["a.go"], cwd=mod)
    assert_output(res, b'package p\n\nimport (\n\t"fmt"\n\n\t"corp"\n)\n\nfunc F() {}\n')


def test_modpath_flag_with_trailing_slash(tmp_path):
    """A -modpath ending in a slash still yields a usable prefix.

    CATCHES: a reimplementation using the raw flag value as the prefix would
    require "corp/" (with the slash) to match "corp/lib/util" and fail to
    regroup; the reference strips at the first slash regardless.
    """
    assert_output(format_imports(tmp_path, flags=["-modpath=corp/"]), GROUPED)
