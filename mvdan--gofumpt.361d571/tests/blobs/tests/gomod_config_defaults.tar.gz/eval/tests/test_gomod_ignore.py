"""go.mod `ignore` entries: spellings, malformed directives, and nesting.

`ignore` is read from the same go.mod that supplies the -lang and -modpath
defaults, and it removes directories from recursive walks. The entry may be
spelled rooted or unrooted, with or without trailing/duplicated slashes, and
it is matched against the directory's own nearest go.mod — not against the
module the walk started in. A malformed `ignore` line is a go.mod parse
error, which discards the whole module configuration.
"""

import pytest

from conftest import (
    diagnose_line,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

# Carries both observables: the diagnose line (always rewritten) and an octal
# literal (only rewritten once the resolved -lang reaches go1.13).
DIAGNOSE_OCTAL = b"package p\n\n//gofumpt:diagnose\nvar x = 0777\n"

# Differs under any language version, so -l reports it wherever it is walked.
UNFORMATTED = b"package p\n\n\n\nvar x = 1\n"


def make_tree(tmp_path, name, ignore_lines):
    """Create a module with x/sub/a.go and y/b.go plus the given ignore lines."""
    mod = tmp_path / name
    write_module(mod, "module example.com/m\n\ngo 1.21\n\n" + "\n".join(ignore_lines) + "\n")
    write(mod / "x" / "sub" / "a.go", DIAGNOSE_OCTAL)
    write(mod / "y" / "b.go", b"package q\n\n//gofumpt:diagnose\n")
    return mod


@pytest.mark.parametrize(
    "entry",
    ["./x", "x", "/x", "./x/", "./x/sub"],
)
def test_ignore_entry_spellings_all_skip_the_tree(tmp_path, entry):
    """Rooted, unrooted, slashed and nested ignore entries all skip x/.

    `./x` compares the directory's path exactly, while `x`, `/x` and `./x/`
    normalise to the same directory after the leading `./` is cut and slashes
    are added on both sides; `./x/sub` matches once the walk descends into
    x/sub. All five leave y/b.go as the only file the walk reports.

    CATCHES: a re-implementation that only implements the rooted `./x` form
    (or that forgets to normalise slashes) would format x/sub/a.go for the
    unrooted or trailing-slash spellings and list it too.
    """
    mod = make_tree(tmp_path, "ig", [f"ignore {entry}"])
    res = run_gofumpt(["-l", "."], cwd=mod)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"y/b.go\n"


@pytest.mark.parametrize(
    "ignore_line",
    ["ignore ./x ./y", "ignore"],
    ids=["two-paths-on-one-line", "missing-path"],
)
def test_malformed_ignore_discards_the_whole_module(tmp_path, ignore_line):
    """A malformed `ignore` line is a go.mod parse error, losing every default.

    Both an `ignore` with two paths on one line and one with no path at all
    make the go.mod unparseable, so no module is found: -lang falls back to
    go1 (the octal literal is left alone), -modpath is empty, and no
    directory is ignored any more.

    CATCHES: a re-implementation that skips only the bad `ignore` line but
    keeps the rest of the go.mod still resolves -lang=go1.21
    -modpath=example.com/m and rewrites 0777, and keeps skipping x/ during
    the walk; the reference does neither.
    """
    mod = make_tree(tmp_path, "bad", [ignore_line])
    # Nothing is ignored any more, so both files show up in the walk.
    res = run_gofumpt(["-l", "."], cwd=mod)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"x/sub/a.go\ny/b.go\n"
    # And the module config itself is gone.
    res = run_gofumpt(["x/sub/a.go"], cwd=mod)
    assert res.returncode == 0, res.stderr
    assert normalize_version(res.stdout) == (
        b"package p\n\n" + diagnose_line("go1", "") + b"\nvar x = 0777\n"
    )


def test_ignore_matches_against_the_nearest_gomod(tmp_path):
    """`ignore` from an outer module does not reach into a nested module.

    Walking the outer module skips ./inner only when inner/ has no go.mod of
    its own: with a nested module present, the directory resolves to its own
    go.mod, relative to which it is the module root and matches nothing. The
    file itself still uses the nested module's older `go` directive.

    CATCHES: a re-implementation that resolves `ignore` against the module
    the walk started in (or that caches one module for the whole walk) skips
    inner/deep here, and would also apply the outer module's go version to
    the file when it is named explicitly.
    """
    outer = tmp_path / "outer"
    write_module(outer, "module example.com/outer\n\ngo 1.21\n\nignore ./inner\n")
    write_module(outer / "inner", "module example.com/inner\n\ngo 1.12\n")
    write(outer / "inner" / "deep" / "a.go", UNFORMATTED)
    write(outer / "keep" / "b.go", UNFORMATTED)

    # The nested module's own go.mod is what inner/ resolves against, so the
    # outer module's `ignore ./inner` does not apply and both files appear.
    res = run_gofumpt(["-l", "."], cwd=outer)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"inner/deep/a.go\nkeep/b.go\n"

    # Naming inner as the argument walks it as the root, which is never ignored.
    res = run_gofumpt(["-l", "inner"], cwd=outer)
    assert res.returncode == 0
    assert res.stdout == b"inner/deep/a.go\n"

    # Without the nested go.mod, the outer module's ignore entry takes over.
    (outer / "inner" / "go.mod").unlink()
    res = run_gofumpt(["-l", "."], cwd=outer)
    assert res.returncode == 0
    assert res.stdout == b"keep/b.go\n"
