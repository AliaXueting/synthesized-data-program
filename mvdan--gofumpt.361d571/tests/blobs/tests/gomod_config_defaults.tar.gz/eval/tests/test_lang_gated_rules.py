"""Version-gated formatting rules: the octal literal rewrite.

The octal literal rewrite (0777 -> 0o777) only happens when the effective
language version is go1.13 or later, which is exactly what the -lang default
resolved from go.mod feeds into. The source below also carries an underscored
octal (0_777) and an already-modern literal (0o777) so each outcome pins all
three spellings.
"""

import pytest

from conftest import (
    run_gofumpt,
    write,
    write_module,
)

OCTAL_SOURCE = b"package p\n\nvar x = 0777\nvar y = 0_777\nvar z = 0o777\n"

# Octal literals were introduced in Go 1.13: below that version the old
# spellings are kept, at or above it they are rewritten (0_777 -> 0o_777).
REWRITTEN = b"package p\n\nvar (\n\tx = 0o777\n\ty = 0o_777\n\tz = 0o777\n)\n"
KEPT = b"package p\n\nvar (\n\tx = 0777\n\ty = 0_777\n\tz = 0o777\n)\n"

# (go.mod contents, expected output) for the go1.13 boundary.
GATING_CASES = [
    ("module example.com/oct\n\ngo 1.12\n", KEPT),
    ("module example.com/oct\n\ngo 1.12rc5\n", KEPT),  # rc normalizes below 1.13
    ("module example.com/oct\n\ngo 1.13\n", REWRITTEN),
    ("module example.com/oct\n\ngo 1.13rc1\n", REWRITTEN),  # rc normalizes to 1.13
    ("module example.com/oct\n\ngo 1.13alpha1\n", REWRITTEN),  # alpha does too
    ("module example.com/oct\n\ngo 1.16\n", REWRITTEN),
    ("module example.com/oct\n\ngo 1.20\n", REWRITTEN),
    ("module example.com/oct\n", REWRITTEN),  # missing go directive -> go1.16
]


@pytest.mark.parametrize("gomod,expected", GATING_CASES)
def test_octal_rewrite_gated_by_effective_lang(tmp_path, gomod, expected):
    """0777 -> 0o777 happens only at go1.13 or later, per the go.mod default.

    CATCHES: a reimplementation comparing the raw go.mod version string (or
    always rewriting) keeps 0777 under `go 1.13rc1`/missing-go-directive or
    rewrites it under `go 1.12rc5`, and never produces the 0o_777 quirk.
    """
    mod = tmp_path / "m"
    write_module(mod, gomod)
    write(mod / "a.go", OCTAL_SOURCE)
    res = run_gofumpt(["a.go"], cwd=mod)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == expected


def test_octal_kept_without_module_or_with_invalid_gomod(tmp_path):
    """No module at all behaves like go1, and an unparseable go.mod likewise.

    CATCHES: a reimplementation defaulting the language to its own toolchain
    version (or to go1.16) when no go.mod is found would rewrite 0777 here,
    where the reference keeps the legacy spellings.
    """
    nomod = tmp_path / "nomod"
    write(nomod / "a.go", OCTAL_SOURCE)
    res = run_gofumpt(["a.go"], cwd=nomod)
    assert res.returncode == 0, res.stderr
    assert res.stdout == KEPT

    broken = tmp_path / "broken"
    write_module(broken, "module example.com/oct\n\ngo 1.20\ngo 1.21\n")
    write(broken / "a.go", OCTAL_SOURCE)
    res = run_gofumpt(["a.go"], cwd=broken)
    assert res.returncode == 0, res.stderr
    assert res.stdout == KEPT


def test_lang_flag_controls_octal_rewrite(tmp_path):
    """-lang overrides the go.mod version for the octal gate in both directions.

    CATCHES: a reimplementation gating the rule on the go.mod value while the
    diagnose line shows the flag (or vice versa) rewrites 0777 under
    -lang=go1.12 or keeps it under -lang=go1.13.
    """
    below = tmp_path / "below"
    write_module(below, "module example.com/oct\n\ngo 1.12\n")
    write(below / "a.go", OCTAL_SOURCE)
    # Flag raises the effective version above the module's.
    res = run_gofumpt(["-lang=go1.13", "a.go"], cwd=below)
    assert res.returncode == 0, res.stderr
    assert res.stdout == REWRITTEN

    above = tmp_path / "above"
    write_module(above, "module example.com/oct\n\ngo 1.13\n")
    write(above / "a.go", OCTAL_SOURCE)
    # Flag lowers the effective version below the module's.
    res = run_gofumpt(["-lang=go1.12", "a.go"], cwd=above)
    assert res.returncode == 0, res.stderr
    assert res.stdout == KEPT

    nomod = tmp_path / "nomod"
    write(nomod / "a.go", OCTAL_SOURCE)
    # The flag also enables the rewrite with no module in sight.
    res = run_gofumpt(["-lang=go1.13", "a.go"], cwd=nomod)
    assert res.returncode == 0, res.stderr
    assert res.stdout == REWRITTEN


def test_octal_walk_resolves_version_per_file(tmp_path):
    """A directory walk applies each file's own module version to the gate.

    CATCHES: a reimplementation resolving -lang once for the whole walk would
    rewrite both files the same way; the recorded output has the root file
    (go 1.12) keeping 0777 while the sub-module file (go 1.14) is rewritten.
    """
    tree = tmp_path / "tree"
    write_module(tree, "module example.com/ow\n\ngo 1.12\n")
    write(tree / "a.go", b"package p\n\nvar x = 0777\n")
    write_module(tree / "sub", "module example.com/owsub\n\ngo 1.14\n")
    write(tree / "sub" / "b.go", b"package p\n\nvar x = 0777\n")
    res = run_gofumpt(["."], cwd=tree)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar x = 0777\npackage p\n\nvar x = 0o777\n"
