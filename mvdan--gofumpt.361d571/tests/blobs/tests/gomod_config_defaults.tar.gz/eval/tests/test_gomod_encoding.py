"""go.mod files with unusual byte layouts: CRLF endings and a UTF-8 BOM.

The go.mod parser tolerates Windows line endings, so a CRLF go.mod still
supplies both defaults. A leading byte-order mark, on the other hand, makes
the file unparseable, which turns it into "no module" for every file it
would have governed.
"""

import pytest

from conftest import (
    diagnose_line,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

# Reports the resolved -lang/-modpath and shows whether the go1.13 octal
# rewrite fired, i.e. both observable effects of the module config.
SOURCE = b"package p\n\n//gofumpt:diagnose\nvar x = 0777\n"


def test_crlf_gomod_still_supplies_both_defaults(tmp_path):
    """A go.mod with Windows line endings is parsed normally.

    The `module` and `go` directives are read despite the trailing carriage
    returns, so the module path comes out without a stray `\\r` and the go1.13
    version gates the octal rewrite.

    CATCHES: a re-implementation that splits go.mod on bare `\\n` keeps the
    `\\r` on the module path (or fails to find the directives at all),
    reporting a different -modpath and leaving 0777 untouched.
    """
    mod = tmp_path / "m"
    write_module(mod, b"module example.com/crlf\r\n\r\ngo 1.13\r\n")
    write(mod / "a.go", SOURCE)
    res = run_gofumpt(["a.go"], cwd=mod)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"package p\n\n" + diagnose_line("go1.13", "example.com/crlf") + b"\nvar x = 0o777\n"
    )


@pytest.mark.parametrize(
    "gomod",
    [
        b"\xef\xbb\xbfmodule example.com/bom\n\ngo 1.13\n",
        b"\xef\xbb\xbfmodule example.com/bc\r\n\r\ngo 1.13\r\n",
    ],
    ids=["bom-only", "bom-and-crlf"],
)
def test_bom_gomod_counts_as_no_module(tmp_path, gomod):
    """A byte-order mark in front of `module` makes the whole go.mod invalid.

    The file no longer parses, so it is as if there were no module: -lang
    falls back to go1 (the octal literal is left as written), -modpath is
    empty, and the diagnose line reports that pair.

    CATCHES: a re-implementation that strips a BOM before parsing (or that
    reads the directives leniently) resolves -lang=go1.13 and
    -modpath=example.com/... here and rewrites 0777 to 0o777.
    """
    mod = tmp_path / "m"
    write_module(mod, gomod)
    write(mod / "a.go", SOURCE)
    res = run_gofumpt(["a.go"], cwd=mod)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"package p\n\n" + diagnose_line("go1", "") + b"\nvar x = 0777\n"
    )
