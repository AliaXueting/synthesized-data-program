"""Shared black-box helpers for gofumpt's go.mod configuration tests.

The module under test owns gofumpt's configuration discovery: when -lang or
-modpath is not passed on the command line, gofumpt locates the go.mod
governing each formatted file (walking up from the file's directory) and
defaults -lang from its `go` directive and -modpath from its `module`
directive. The `//gofumpt:diagnose` comment directive reports the resolved
pair on stdout:

    //gofumpt:diagnose version: <gofumpt version> (<go version>) flags: \
-lang=<lang> -modpath=<modpath>

The version portion depends on how the binary under test was built, so these
tests normalize exactly that portion (VERSION_RE below) and pin every other
byte of every observed output.
"""

import os
import pathlib
import re
import subprocess

import pytest

# Matches the "version: (devel) (go1.26.0)" portion of a diagnose line. The
# gofumpt version and Go toolchain version come from the binary's build info,
# which a re-implementation is free to build differently; everything else in
# the line is pinned byte-for-byte by the tests.
VERSION_RE = re.compile(rb"version: [^ ]+ \([^)]*\)")
VERSION_PLACEHOLDER = b"version: <VERSION>"

# The standard source used to observe the resolved configuration.
DIAGNOSE_SOURCE = b"package p\n\n//gofumpt:diagnose\nfunc F() {}\n"


def normalize_version(output):
    """Mask the build-dependent version portion of diagnose lines."""
    return VERSION_RE.sub(VERSION_PLACEHOLDER, output)


def run_gofumpt(args, cwd, stdin=b""):
    """Run the binary under test (PROGRAMGYM_EXECUTABLE) and return the result.

    The child runs with a fully pinned environment, no TTY, and only the
    given working directory touched, so the tests are hermetic.
    """
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not exe:
        pytest.fail("PROGRAMGYM_EXECUTABLE is not set; run the tests via eval/run.sh")
    proc = subprocess.run(
        [exe] + [str(a) for a in args],
        cwd=str(cwd),
        input=stdin if isinstance(stdin, bytes) else stdin.encode(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=child_env(),
        timeout=30,
    )
    return proc


def child_env():
    """Build the pinned, hermetic environment for the child process.

    Nothing is inherited from the test process except GOCOVERDIR, which the
    coverage pipeline needs in order to measure the binary under test.
    """
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": "/nonexistent",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
    }
    # Coverage instrumentation hook: copy GOCOVERDIR through when present.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    return env


def write(path, content):
    """Write content (str or bytes) to path, creating parent directories."""
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, str):
        content = content.encode()
    path.write_bytes(content)
    return path


def write_module(dirpath, gomod):
    """Create dirpath/go.mod with the given contents and return its path."""
    return write(pathlib.Path(dirpath) / "go.mod", gomod)


def diagnose_line(lang, modpath, extra=""):
    """The expected rewritten //gofumpt:diagnose line for a resolved config."""
    flags = "-lang=%s -modpath=%s" % (lang, modpath)
    if extra:
        flags += " -extra=%s" % extra
    return b"//gofumpt:diagnose " + VERSION_PLACEHOLDER + b" flags: " + flags.encode()


def diagnose_output(lang, modpath, extra=""):
    """Expected stdout for DIAGNOSE_SOURCE under the given resolved config."""
    return b"package p\n\n" + diagnose_line(lang, modpath, extra) + b"\nfunc F() {}\n"
