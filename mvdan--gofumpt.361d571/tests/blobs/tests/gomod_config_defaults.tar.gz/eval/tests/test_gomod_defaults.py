"""go.mod discovery and the -lang/-modpath defaults gofumpt derives from it.

When -lang or -modpath is not given, gofumpt finds the go.mod governing each
file being formatted - starting at the file's directory and walking up through
parents - and defaults -lang to the `go` directive normalized like
go/version.Lang and -modpath to the `module` directive's path. A go.mod that
cannot be parsed counts as no module at all. Every test observes the resolved
configuration through the rewritten //gofumpt:diagnose line on stdout.
"""

import pytest

from conftest import (
    DIAGNOSE_SOURCE,
    diagnose_output,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)


def assert_clean_diagnose(res, lang, modpath):
    """Assert a successful run whose stdout is the diagnose observation."""
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == diagnose_output(lang, modpath)


# The `go` directive value -> the -lang reported by //gofumpt:diagnose.
VERSION_CASES = [
    ("1.21.2", "go1.21"),  # patch release is stripped
    ("1.21rc3", "go1.21"),  # release candidate is stripped
    ("1.21alpha1", "go1.21"),  # alpha suffix is stripped
    ("1.21beta2", "go1.21"),  # beta suffix is stripped
    ("1.22.0", "go1.22"),  # .0 patch is stripped
    ("1.100", "go1.100"),  # multi-digit minor is kept
    ("1.0", "go1"),  # minor .0 collapses to the bare major
]


@pytest.mark.parametrize("go_version,expected_lang", VERSION_CASES)
def test_go_directive_version_normalized(tmp_path, go_version, expected_lang):
    """-lang defaults to the `go` directive normalized like go/version.Lang.

    CATCHES: a reimplementation passing the raw go.mod version through would
    report -lang=go1.21.2, -lang=go1.21rc3 or -lang=go1.0 instead of go1.21
    or go1, so any missing normalization step shows up in the diagnose line.
    """
    mod = tmp_path / "m"
    write_module(mod, "module example.com/mymod\n\ngo %s\n" % go_version)
    write(mod / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=mod), expected_lang, "example.com/mymod")


# go.mod contents that x/mod/modfile refuses to parse. In every case the
# whole file counts as no module: neither -lang nor -modpath gets a default.
UNPARSEABLE_GOMODS = [
    "module example.com/mymod\n\ngo 1.x\n",  # invalid version syntax
    "module example.com/mymod\n\ngo 1\n",  # missing minor version
    "module example.com/mymod\n\ngo 1.21.2.3\n",  # four version parts
    "module example.com/mymod\n\ngo 1.19\ngo 1.20\n",  # repeated go statement
    "module\ngo 1.19\n",  # module directive without an argument
]


@pytest.mark.parametrize("gomod", UNPARSEABLE_GOMODS)
def test_unparseable_gomod_counts_as_no_module(tmp_path, gomod):
    """A go.mod that modfile cannot parse yields no -lang and no -modpath defaults.

    CATCHES: a reimplementation that salvages directives from a broken go.mod
    (e.g. still reading `go 1.19` out of the four-part or repeated-directive
    cases) would report a nonempty -lang/-modpath instead of go1 and empty.
    """
    mod = tmp_path / "m"
    write_module(mod, gomod)
    write(mod / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=mod), "go1", "")


def test_missing_go_directive_assumes_go1_16(tmp_path):
    """A go.mod without a `go` directive defaults -lang to go1.16.

    CATCHES: per go.dev/ref/mod#go-mod-file-go the assumption is exactly
    go1.16; a reimplementation defaulting to go1 (or the toolchain's own
    version) would print a different -lang in the diagnose line.
    """
    mod = tmp_path / "m"
    write_module(mod, "module example.com/mymod\n")
    write(mod / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=mod), "go1.16", "example.com/mymod")


def test_missing_module_directive_gives_no_modpath(tmp_path):
    """A go.mod with only a `go` directive still defaults -lang but not -modpath.

    CATCHES: a reimplementation that treats a missing `module` directive as a
    parse failure would lose the go1.19 -lang default too, or one that
    invents a modpath would show a nonempty -modpath.
    """
    mod = tmp_path / "m"
    write_module(mod, "go 1.19\n")
    write(mod / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=mod), "go1.19", "")


@pytest.mark.parametrize("gomod", ["", "// just a comment\n"])
def test_gomod_without_any_directives(tmp_path, gomod):
    """An empty or comment-only go.mod parses fine and yields go1.16 plus no modpath.

    CATCHES: a reimplementation that rejects an effectively empty go.mod as
    unparseable would fall back to -lang=go1 instead of the go1.16 default
    that a present-but-empty module file produces.
    """
    mod = tmp_path / "m"
    write_module(mod, gomod)
    write(mod / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=mod), "go1.16", "")


# go.mod contents whose `module` argument is accepted verbatim by modfile
# parsing (it only unquotes; it does not validate the path).
MODULE_PATH_CASES = [
    ('module "example.com/quoted"\n\ngo 1.18\n', "example.com/quoted"),
    ('module "a b"\n\ngo 1.18\n', "a b"),
    ("module Example.com/Foo\n\ngo 1.18\n", "Example.com/Foo"),
    ("module ./foo\n\ngo 1.18\n", "./foo"),
    ('module ""\n\ngo 1.18\n', ""),
]


@pytest.mark.parametrize("gomod,expected_modpath", MODULE_PATH_CASES)
def test_module_path_recorded_verbatim(tmp_path, gomod, expected_modpath):
    """-modpath defaults to the module directive's argument, unquoted but unchecked.

    CATCHES: a reimplementation that runs module path validation (rejecting
    uppercase, "./" prefixes, spaces or empty strings) would treat these
    go.mod files as invalid and drop the go1.18 -lang default as well.
    """
    mod = tmp_path / "m"
    write_module(mod, gomod)
    write(mod / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=mod), "go1.18", expected_modpath)


EXTRA_DIRECTIVE_GOMODS = [
    # `go` before `module`: directive order does not matter.
    "go 1.19\n\nmodule example.com/gofirst\n",
    # a toolchain directive is accepted and ignored for -lang.
    "module example.com/tc\n\ngo 1.22.0\n\ntoolchain go1.22.3\n",
    # a godebug directive is accepted and ignored for -lang.
    "module example.com/gd\n\ngo 1.23\n\ngodebug default=go1.23\n",
    # comments and extra blank lines/whitespace around directives.
    "module   example.com/spaced\n\n\ngo    1.16\n",
]


@pytest.mark.parametrize("gomod,expected_lang,expected_modpath", [
    (EXTRA_DIRECTIVE_GOMODS[0], "go1.19", "example.com/gofirst"),
    (EXTRA_DIRECTIVE_GOMODS[1], "go1.22", "example.com/tc"),
    (EXTRA_DIRECTIVE_GOMODS[2], "go1.23", "example.com/gd"),
    (EXTRA_DIRECTIVE_GOMODS[3], "go1.16", "example.com/spaced"),
])
def test_other_gomod_shapes_parse(tmp_path, gomod, expected_lang, expected_modpath):
    """Directive order, comments and newer go.mod directives do not break loading.

    CATCHES: a reimplementation using a stricter or looser go.mod parser
    (e.g. one that rejects `toolchain`/`godebug` or requires `module` first)
    resolves a different -lang/-modpath pair for these files.
    """
    mod = tmp_path / "m"
    write_module(mod, gomod)
    write(mod / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=mod), expected_lang, expected_modpath)


def test_file_outside_any_module(tmp_path):
    """A file with no go.mod anywhere above it gets neither default.

    CATCHES: a reimplementation that falls back to some ambient module (the
    process's working directory, $GOPATH, or a default language version other
    than go1) would print a nonempty -lang/-modpath here.
    """
    nomod = tmp_path / "nomod" / "deeper"
    write(nomod / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=nomod), "go1", "")


def test_gomod_found_in_parent_directory(tmp_path):
    """The search walks up from the file's directory until a go.mod is found.

    CATCHES: a reimplementation that only looks in the file's own directory
    would find no go.mod for sub/deep/a.go and report go1 with no modpath
    instead of the parent module's go1.17 and parent/mod.
    """
    mod = tmp_path / "m"
    write_module(mod, "module parent/mod\n\ngo 1.17\n")
    write(mod / "sub" / "deep" / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["sub/deep/a.go"], cwd=mod), "go1.17", "parent/mod")


def test_nested_modules_nearest_wins(tmp_path):
    """With nested go.mod files, the nearest one to the file governs.

    CATCHES: a reimplementation that stops at the first go.mod found while
    walking down from the tree root (or that caches one module for the whole
    walk) would give inner/inner.go the outer module's go1.18/outer/mod.
    """
    outer = tmp_path / "tree"
    write_module(outer, "module outer/mod\n\ngo 1.18\n")
    write(outer / "outer.go", DIAGNOSE_SOURCE)
    write_module(outer / "inner", "module inner/mod\n\ngo 1.21\n")
    write(outer / "inner" / "inner.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["inner/inner.go"], cwd=outer), "go1.21", "inner/mod")
    assert_clean_diagnose(run_gofumpt(["outer.go"], cwd=outer), "go1.18", "outer/mod")


def test_walk_resolves_each_files_own_module(tmp_path):
    """Walking a tree resolves the go.mod per file, in deterministic walk order.

    CATCHES: a reimplementation resolving the module once per invocation
    would format both files with one module's values; the walk order (inner/
    before outer.go) and each diagnose line pin the per-file resolution.
    """
    outer = tmp_path / "tree"
    write_module(outer, "module outer/mod\n\ngo 1.18\n")
    write(outer / "outer.go", DIAGNOSE_SOURCE)
    write_module(outer / "inner", "module inner/mod\n\ngo 1.21\n")
    write(outer / "inner" / "inner.go", DIAGNOSE_SOURCE)
    res = run_gofumpt(["."], cwd=outer)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        diagnose_output("go1.21", "inner/mod") + diagnose_output("go1.18", "outer/mod")
    )


def test_unreadable_gomod_entry_keeps_walking_up(tmp_path):
    """A go.mod that cannot be read as a file is skipped and the walk continues.

    CATCHES: with a directory named go.mod in badgo/, only a reimplementation
    that keeps walking up finds the enclosing module; one that treats any
    go.mod path as authoritative would report no module (go1, empty).
    """
    outer = tmp_path / "outer"
    write_module(outer, "module example.com/outer\n\ngo 1.17\n")
    badgo = outer / "badgo"
    badgo.mkdir()
    (badgo / "go.mod").mkdir()  # a *directory* named go.mod
    write(badgo / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["badgo/a.go"], cwd=outer), "go1.17", "example.com/outer")


def test_gomod_directory_without_parent_is_no_module(tmp_path):
    """When the unreadable go.mod has no module above it, the file gets no defaults.

    CATCHES: the fallback path must end in "no module" (go1, empty modpath),
    not an error; a reimplementation that errors out or falls back to some
    default module would fail this quiet-degradation contract.
    """
    lone = tmp_path / "lone"
    lone.mkdir()
    (lone / "go.mod").mkdir()  # a *directory* named go.mod, no parent module
    write(lone / "a.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a.go"], cwd=lone), "go1", "")


def test_cwd_does_not_override_file_module(tmp_path):
    """For file arguments the file's own go.mod wins over the working directory.

    CATCHES: a reimplementation resolving the module from the process's
    working directory would format modA/a.go with modB's go1.22 config when
    invoked from modB, and would mishandle ./ and ../ argument spellings.
    """
    mod_a = tmp_path / "modA"
    write_module(mod_a, "module example.com/a\n\ngo 1.19\n")
    write(mod_a / "a.go", DIAGNOSE_SOURCE)
    mod_b = tmp_path / "modB"
    write_module(mod_b, "module example.com/b\n\ngo 1.22\n")
    write(mod_b / "b.go", DIAGNOSE_SOURCE)
    expected = diagnose_output("go1.19", "example.com/a")
    invocations = [
        ([str(mod_a / "a.go")], mod_b),  # absolute path from inside another module
        (["a.go"], mod_a),  # plain relative name
        (["./a.go"], mod_a),  # dotted relative name
        (["../modA/a.go"], mod_b),  # ..-relative name from a sibling module
    ]
    for args, cwd in invocations:
        res = run_gofumpt(args, cwd=cwd)
        assert res.returncode == 0, res.stderr
        assert normalize_version(res.stdout) == expected


def test_arguments_processed_in_given_order(tmp_path):
    """Multiple file arguments keep their command-line order in the output.

    CATCHES: a reimplementation that (con)sorts outputs by module or path
    would emit the two diagnose blocks in the same order regardless of the
    argument order; the recorded outputs differ per order.
    """
    mod_a = tmp_path / "modA"
    write_module(mod_a, "module example.com/a\n\ngo 1.19\n")
    write(mod_a / "a.go", DIAGNOSE_SOURCE)
    mod_b = tmp_path / "modB"
    write_module(mod_b, "module example.com/b\n\ngo 1.22\n")
    write(mod_b / "b.go", DIAGNOSE_SOURCE)
    out_a_first = run_gofumpt(["modA/a.go", "modB/b.go"], cwd=tmp_path)
    assert normalize_version(out_a_first.stdout) == (
        diagnose_output("go1.19", "example.com/a") + diagnose_output("go1.22", "example.com/b")
    )
    out_b_first = run_gofumpt(["modB/b.go", "modA/a.go"], cwd=tmp_path)
    assert normalize_version(out_b_first.stdout) == (
        diagnose_output("go1.22", "example.com/b") + diagnose_output("go1.19", "example.com/a")
    )
    assert out_a_first.returncode == 0 and out_b_first.returncode == 0


def test_gowork_is_not_consulted(tmp_path):
    """A go.work file is ignored: each file uses its own module's go.mod.

    CATCHES: a reimplementation honoring workspaces would resolve the files
    in a/ and b/ against go.work (e.g. its `go 1.99` line) instead of their
    own go.mod files, and would give top.go a module it does not have.
    """
    ws = tmp_path / "ws"
    write(ws / "go.work", "go 1.99\n\nuse ./a\nuse ./b\n")
    write_module(ws / "a", "module example.com/wa\n\ngo 1.18\n")
    write(ws / "a" / "a.go", DIAGNOSE_SOURCE)
    write_module(ws / "b", "module example.com/wb\n\ngo 1.20\n")
    write(ws / "b" / "b.go", DIAGNOSE_SOURCE)
    write(ws / "top.go", DIAGNOSE_SOURCE)
    assert_clean_diagnose(run_gofumpt(["a/a.go"], cwd=ws), "go1.18", "example.com/wa")
    assert_clean_diagnose(run_gofumpt(["b/b.go"], cwd=ws), "go1.20", "example.com/wb")
    assert_clean_diagnose(run_gofumpt(["top.go"], cwd=ws), "go1", "")
    # The same holds when walking: a, b, then top.go, each with its own config.
    res = run_gofumpt(["."], cwd=ws)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        diagnose_output("go1.18", "example.com/wa")
        + diagnose_output("go1.20", "example.com/wb")
        + diagnose_output("go1", "")
    )


def test_stdin_uses_working_directory_module(tmp_path):
    """Stdin is treated as <standard input> in the cwd, so the cwd's go.mod applies.

    CATCHES: a reimplementation skipping module lookup for stdin (or keying
    it on the file's nonexistent directory) reports go1/empty instead of the
    enclosing module's values, including when the cwd is a module subdirectory.
    """
    mod_a = tmp_path / "modA"
    write_module(mod_a, "module example.com/a\n\ngo 1.19\n")
    write(mod_a / "sub" / "keep.go", b"package p\n")
    mod_b = tmp_path / "modB"
    write_module(mod_b, "module example.com/b\n\ngo 1.22\n")
    for cwd, lang, modpath in (
        (mod_a, "go1.19", "example.com/a"),
        (mod_a / "sub", "go1.19", "example.com/a"),
        (mod_b, "go1.22", "example.com/b"),
    ):
        res = run_gofumpt([], cwd=cwd, stdin=DIAGNOSE_SOURCE)
        assert res.returncode == 0, res.stderr
        assert normalize_version(res.stdout) == diagnose_output(lang, modpath)
