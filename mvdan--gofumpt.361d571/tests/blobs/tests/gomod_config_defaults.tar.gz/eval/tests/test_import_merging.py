"""Merging contiguous lone import/var/const lines, with the module config.

gofumpt joins neighbouring one-line `import`/`var`/`const` declarations into
a single parenthesised group. The join is gated by what sits between the
declarations (a blank line, a directive, or a comment that sorting would
strand) and, for imports, the merged group is then re-sorted and split into
std/non-std using the -modpath resolved from go.mod.
"""

import pytest

from conftest import run_gofumpt, write, write_module

GOMOD = "module mymod\n\ngo 1.21\n"


def run_in(tmp_path, source, gomod=GOMOD):
    """Format source as x.go inside a module (or with no module if gomod is None)."""
    mod = tmp_path / "m"
    if gomod is None:
        mod.mkdir(parents=True, exist_ok=True)
    else:
        write_module(mod, gomod)
    write(mod / "x.go", source)
    return run_gofumpt(["x.go"], cwd=mod)


def assert_unchanged(res, source):
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == source


@pytest.mark.parametrize("gomod", [GOMOD, None])
def test_merged_lone_imports_split_on_the_module_path(tmp_path, gomod):
    """Joining two lone imports re-sorts them and splits on the resolved -modpath.

    ``import "mymod/a"`` followed by ``import "fmt"`` merges into one group
    whose members are then re-sorted, so "fmt" lands first; whether a blank
    line separates "mymod/a" from it depends entirely on go.mod being found.

    CATCHES: a re-implementation that merges the declarations but classifies
    the paths without the go.mod-resolved -modpath keeps "mymod/a" in the std
    group inside the module, or inserts the separating blank line even
    outside any module.
    """
    source = b'package p\n\nimport "mymod/a"\nimport "fmt"\n\nvar _ = []any{fmt.Print, a.X}\n'
    res = run_in(tmp_path, source, gomod)
    expected = (
        b'package p\n\nimport (\n\t"fmt"\n\n\t"mymod/a"\n)\n\nvar _ = []any{fmt.Print, a.X}\n'
        if gomod
        else b'package p\n\nimport (\n\t"fmt"\n\t"mymod/a"\n)\n\nvar _ = []any{fmt.Print, a.X}\n'
    )
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == expected


def test_inline_comment_ends_the_merged_import_group(tmp_path):
    """An inline comment on a merged import closes the group after itself.

    ``import "os" // note`` extends the group's end past the comment, so the
    group gains a line break at that point; the following lone import is then
    no longer adjacent and stays a declaration of its own.

    CATCHES: a re-implementation that measures the merged group's end at the
    import path alone would also swallow ``import "bytes"`` into the group, or
    would drop/misplace the "// note" comment when closing the parenthesis.
    """
    source = (
        b"package p\n\n"
        b'import "fmt"\nimport "os" // note\nimport "bytes"\n\n'
        b"var _ = []any{fmt.Print, os.Args, bytes.MinRead}\n"
    )
    res = run_in(tmp_path, source)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == (
        b"package p\n\n"
        b'import (\n\t"fmt"\n\t"os" // note\n)\nimport "bytes"\n\n'
        b"var _ = []any{fmt.Print, os.Args, bytes.MinRead}\n"
    )


@pytest.mark.parametrize(
    "source",
    [
        # The commented import sorts before the previous one, so joining would
        # strand its comment outside the group.
        b'package p\n\nimport "os"\nimport "fmt" // keep\n\nvar _ = []any{fmt.Print, os.Args}\n',
        # A blank line between the two lone imports ends the chain.
        b'package p\n\nimport "fmt"\n\nimport "os"\n\nvar _ = []any{fmt.Print, os.Args}\n',
    ],
    ids=["commented-import-would-resort", "blank-line-between"],
)
def test_lone_imports_that_cannot_join_stay_separate(tmp_path, source):
    """Neither a stranding comment nor a blank line may join lone imports.

    CATCHES: a re-implementation that merges every neighbouring lone import
    unconditionally would pull "fmt // keep" up next to "os" (losing its
    comment to the re-sort) and would collapse the blank-line-separated pair
    into one group.
    """
    assert_unchanged(run_in(tmp_path, source), source)


def test_commented_import_already_in_order_still_joins(tmp_path):
    """A commented import joins when sorting leaves it where it is.

    Because "os" already sorts after "fmt", joining the two cannot move the
    commented spec, so the merge goes ahead and keeps the comment attached.

    CATCHES: a re-implementation that refuses to merge any commented import
    (rather than only those that sorting would move) leaves these two lines
    as separate declarations instead of one group.
    """
    source = b'package p\n\nimport "fmt"\nimport "os" // keep\n\nvar _ = []any{fmt.Print, os.Args}\n'
    res = run_in(tmp_path, source)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == (
        b'package p\n\nimport (\n\t"fmt"\n\t"os" // keep\n)\n\nvar _ = []any{fmt.Print, os.Args}\n'
    )


def test_lone_consts_mentioning_iota_never_join(tmp_path):
    """Appending a const spec would renumber iota, so the lines stay apart.

    CATCHES: a re-implementation that merges lone const declarations without
    checking for iota silently changes the constant values (b would become 1
    instead of 0), which is a semantic change invisible in the output alone;
    the unmerged source is the only correct answer.
    """
    source = b"package p\n\nconst a = iota\nconst b = iota\n"
    assert_unchanged(run_in(tmp_path, source), source)


def test_doc_comment_in_step_still_joins_lone_vars(tmp_path):
    """A comment exactly one line below keeps lone var declarations joining.

    The doc comment travels with its declaration into the merged group, so
    the result is one parenthesised var with the comment inside it.

    CATCHES: a re-implementation that treats any interleaved comment as a
    hard separator leaves two lone var lines; one that merges but drops the
    comment, or moves it above the group, also fails the byte-exact output.
    """
    source = b"package p\n\nvar a = 1\n// doc for b\nvar b = 2\n"
    res = run_in(tmp_path, source)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar (\n\ta = 1\n\t// doc for b\n\tb = 2\n)\n"


def test_directive_comment_separates_lone_vars(tmp_path):
    """A directive comment between lone vars breaks the join and gains a blank line.

    ``//go:generate`` is a directive rather than prose, so it must not be
    pulled inside a merged group; the two declarations stay separate and a
    blank line is inserted before the directive.

    CATCHES: a re-implementation that merges across a directive comment (or
    that omits the inserted blank line) produces a different byte stream for
    this file.
    """
    source = b"package p\n\nvar a = 1\n//go:generate x\nvar b = 2\n"
    res = run_in(tmp_path, source)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar a = 1\n\n//go:generate x\nvar b = 2\n"
