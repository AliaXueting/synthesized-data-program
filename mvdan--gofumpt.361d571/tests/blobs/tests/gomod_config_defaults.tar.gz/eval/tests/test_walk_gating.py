"""Directory-walk gating around the go.mod config machinery.

shouldIgnore decides which directories a recursive walk descends into:
`vendor` and `testdata` are always skipped (the go.mod `ignore`-directive
half is covered in test_output_modes.py), and the lookup consults the module
cache even when there is no enclosing module at all. Also pinned here: the
error surface for arguments that cannot be walked, which flows through the
same reporter that carries parse and formatting errors.
"""

import pytest

from conftest import (
    diagnose_line,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

GOMOD = "module example.com/w\n\ngo 1.21\n"

# A file that needs the resolved config to change: the octal rewrite only
# happens under -lang >= go1.13, so seeing 0o777 proves the module's `go 1.21`
# was applied, and the diagnose line pins the whole resolved config.
NEEDS_CONFIG = b"package p\n\n//gofumpt:diagnose\nvar x = 0777\n"

# (directory base name, file that must survive the walk inside it)
SPECIAL_DIRS = [
    ("vendor", "sub/v.go"),
    ("testdata", "td.go"),
]


def make_tree(root, with_module=True):
    """A module tree whose special dirs hold files a walk must skip."""
    if with_module:
        write_module(root, GOMOD)
    for base, rel in SPECIAL_DIRS:
        write(root / base / rel, b"package p\n\nvar x = 0777\n")
    write(root / "plain" / "p.go", NEEDS_CONFIG)
    return root


@pytest.mark.parametrize("base,rel", SPECIAL_DIRS)
def test_special_dir_skipped_on_walk(tmp_path, base, rel):
    """A recursive walk formats plain/ but never touches vendor/ or testdata/.

    CATCHES: a reimplementation that walks into vendor or testdata would
    rewrite the octal literal in the skipped file and list it, changing both
    stdout and the exit-relevant diff set.
    """
    root = make_tree(tmp_path)
    res = run_gofumpt(["-l", str(root)], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    # Only the file outside the special directories is listed; the skipped
    # files keep their unformatted octal literal on disk.
    assert res.stdout == ("%s\n" % (root / "plain" / "p.go")).encode()
    assert (root / base / rel).read_bytes() == b"package p\n\nvar x = 0777\n"


@pytest.mark.parametrize("base,rel", SPECIAL_DIRS)
def test_special_dir_named_explicitly_is_formatted(tmp_path, base, rel):
    """Naming a file inside vendor/ or testdata/ directly still formats it.

    CATCHES: the walk-skip must only apply to discovered paths, not to
    explicit arguments; gating on the name alone would leave the explicitly
    requested file unformatted (no octal rewrite, stale diagnose line).
    """
    root = make_tree(tmp_path)
    target = root / base / rel
    target.write_bytes(NEEDS_CONFIG)
    res = run_gofumpt([str(target)], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"package p\n\n"
        + diagnose_line("go1.21", "example.com/w")
        + b"\nvar x = 0o777\n"
    )


def test_walk_outside_any_module_still_skips_special_dirs(tmp_path):
    """Without any enclosing go.mod, vendor/testdata are still skipped.

    CATCHES: a reimplementation that ties the skip decision to having found
    a module would descend into vendor/ here; also, with no module the
    resolved config must be -lang=go1 (no octal rewrite) and no modpath.
    """
    root = make_tree(tmp_path, with_module=False)
    res = run_gofumpt(["-l", str(root)], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == ("%s\n" % (root / "plain" / "p.go")).encode()
    # The surviving file resolves to the no-module defaults.
    res = run_gofumpt([str(root / "plain" / "p.go")], cwd=tmp_path)
    assert normalize_version(res.stdout) == (
        b"package p\n\n" + diagnose_line("go1", "") + b"\nvar x = 0777\n"
    )


@pytest.mark.parametrize(
    "arg",
    [
        "nosuchdir",
        "nosuch.go",
        "-",
    ],
)
def test_unwalkable_argument_is_lstat_error(tmp_path, arg):
    """An argument that cannot be lstat'ed is reported on stderr with exit 2.

    CATCHES: the walk root itself failing (missing file/dir, or a bare `-`
    which is not a stdin marker) must produce the exact `lstat` error line
    on stderr, empty stdout, and exit code 2 — not a panic, usage text, or
    silent success.
    """
    res = run_gofumpt([arg], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == ("lstat %s: no such file or directory\n" % arg).encode()
