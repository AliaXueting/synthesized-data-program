"""Recognition and rewriting of the //gofumpt:diagnose comment directive.

gofumpt rewrites a `//gofumpt:diagnose` directive - optionally followed by
trailing text such as a stale version - into a single line reporting the
resolved configuration. Lookalikes that are not the directive are left
untouched. These tests pin exactly which comments qualify and what the
rewritten line looks like.
"""

from conftest import (
    diagnose_line,
    diagnose_output,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

MOD_GOMOD = "module example.com/mymod\n\ngo 1.21.2\n"
MOD_LANG = "go1.21"
MOD_PATH = "example.com/mymod"


def make_module(tmp_path):
    mod = tmp_path / "m"
    write_module(mod, MOD_GOMOD)
    return mod


def run_source(tmp_path, source):
    """Write source as a.go in the standard module and format it."""
    mod = make_module(tmp_path)
    write(mod / "a.go", source)
    return run_gofumpt(["a.go"], cwd=mod)


def assert_rewritten(res, extra=""):
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == diagnose_output(MOD_LANG, MOD_PATH, extra)


def assert_untouched(res, source):
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert res.stdout == source


def test_stale_diagnose_line_is_rewritten(tmp_path):
    """Trailing text after //gofumpt:diagnose (a stale report) is replaced.

    CATCHES: a reimplementation only matching the bare directive would leave
    the stale "version: v0.1.0 (go1.15) flags: ..." text in place instead of
    collapsing the whole comment into the fresh single-line report.
    """
    res = run_source(
        tmp_path,
        b"package p\n\n//gofumpt:diagnose version: v0.1.0 (go1.15) flags:"
        b" -lang=go1.15 -modpath=\nfunc F() {}\n",
    )
    assert_rewritten(res)
    # The short stale spelling "//gofumpt:diagnose v0.1.0" is rewritten too.
    res = run_source(tmp_path, b"package p\n\n//gofumpt:diagnose v0.1.0\nfunc F() {}\n")
    assert_rewritten(res)


def test_trailing_whitespace_after_diagnose(tmp_path):
    """Trailing spaces or tabs after the directive still count as the directive.

    CATCHES: a reimplementation matching the comment text without first
    trimming trailing whitespace would not recognize "//gofumpt:diagnose<tab>"
    and would leave the directive unwritten.
    """
    res = run_source(tmp_path, b"package p\n\n//gofumpt:diagnose   \t\nfunc F() {}\n")
    assert_rewritten(res)


def test_lookalike_comments_are_untouched(tmp_path):
    """Comments that merely resemble the directive are left byte-for-byte alone.

    CATCHES: a reimplementation matching on a prefix would also rewrite
    "//gofumpt:diagnosefoobar"; one ignoring the no-space-after-// rule would
    rewrite "// gofumpt:diagnose"; and a /*-style comment never qualifies.
    """
    sources = [
        b"package p\n\n//gofumpt:diagnosefoobar\nfunc F() {}\n",
        b"package p\n\n// gofumpt:diagnose\nfunc F() {}\n",
        b"package p\n\n/*gofumpt:diagnose*/\nfunc F() {}\n",
    ]
    for source in sources:
        assert_untouched(run_source(tmp_path, source), source)


def test_diagnose_rewritten_anywhere_in_file(tmp_path):
    """The directive is rewritten wherever it appears in the file.

    CATCHES: a reimplementation only scanning doc comments (or only top-level
    comments) would miss the directive inside a function body or before the
    package clause, and would misplace the rewritten line.
    """
    # Inside a function body, keeping its indentation.
    res = run_source(
        tmp_path, b"package p\n\nfunc F() {\n\t//gofumpt:diagnose\n\t_ = 0\n}\n"
    )
    assert res.returncode == 0, res.stderr
    assert normalize_version(res.stdout) == (
        b"package p\n\nfunc F() {\n\t" + diagnose_line(MOD_LANG, MOD_PATH) + b"\n\t_ = 0\n}\n"
    )
    # Before the package clause.
    res = run_source(tmp_path, b"//gofumpt:diagnose\npackage p\n\nfunc F() {}\n")
    assert normalize_version(res.stdout) == (
        diagnose_line(MOD_LANG, MOD_PATH) + b"\npackage p\n\nfunc F() {}\n"
    )
    # As the second line of a doc comment: the doc formatter inserts an
    # empty "//" line before the directive.
    res = run_source(
        tmp_path, b"package p\n\n// some doc line\n//gofumpt:diagnose\nfunc F() {}\n"
    )
    assert normalize_version(res.stdout) == (
        b"package p\n\n// some doc line\n//\n"
        + diagnose_line(MOD_LANG, MOD_PATH) + b"\nfunc F() {}\n"
    )


def test_only_first_directive_line_of_group_rewritten(tmp_path):
    """A directive-looking line ends the scan of its comment group.

    CATCHES: a reimplementation examining every comment in a group would also
    rewrite the *second* //gofumpt:diagnose line, and one that does not stop
    at any directive would rewrite the diagnose line following //nolint:foo.
    """
    # Two diagnose lines in one group: only the first is rewritten; the
    # second (stale) one is left exactly as it was.
    res = run_source(
        tmp_path,
        b"package p\n\n//gofumpt:diagnose\n//gofumpt:diagnose version: stale\nfunc F() {}\n",
    )
    assert res.returncode == 0, res.stderr
    assert normalize_version(res.stdout) == (
        b"package p\n\n"
        + diagnose_line(MOD_LANG, MOD_PATH)
        + b"\n//gofumpt:diagnose version: stale\nfunc F() {}\n"
    )
    # Another directive first in the group blocks the diagnose rewrite.
    source = b"package p\n\n//nolint:foo\n//gofumpt:diagnose\nfunc F() {}\n"
    assert_untouched(run_source(tmp_path, source), source)


def test_extra_words_after_diagnose_ignored(tmp_path):
    """Arbitrary trailing text after the directive name is discarded.

    CATCHES: a reimplementation that tries to parse or preserve the trailing
    words would emit them (or fail to match), instead of replacing the whole
    comment with the canonical report line.
    """
    res = run_source(tmp_path, b"package p\n\n//gofumpt:diagnose extra words here\nfunc F() {}\n")
    assert_rewritten(res)


def test_diagnose_version_matches_version_flag(tmp_path):
    """The version embedded in the diagnose line is exactly `-version`'s output.

    CATCHES: a reimplementation printing a different version string in the
    diagnose report than in `-version` (e.g. hardcoding one of them) breaks
    the self-consistency these two outputs must have.
    """
    mod = make_module(tmp_path)
    write(mod / "a.go", b"package p\n\n//gofumpt:diagnose\nfunc F() {}\n")
    version_res = run_gofumpt(["-version"], cwd=tmp_path)
    assert version_res.returncode == 0
    build_version = version_res.stdout.strip()
    assert build_version  # non-empty, e.g. "(devel) (go1.26.0)"
    res = run_gofumpt(["a.go"], cwd=mod)
    assert res.returncode == 0, res.stderr
    expected_tail = b" flags: -lang=" + MOD_LANG.encode() + b" -modpath=" + MOD_PATH.encode() + b"\n"
    assert b"//gofumpt:diagnose version: " + build_version + expected_tail in res.stdout


def test_extra_rules_listed_in_diagnose(tmp_path):
    """Enabled extra rules are appended to the diagnose line, in fixed order.

    CATCHES: a reimplementation that omits the -extra section, orders the rule
    names differently, or lists them when -extra=false would produce a
    different flags tail on the rewritten comment.
    """
    mod = make_module(tmp_path)
    write(mod / "a.go", b"package p\n\n//gofumpt:diagnose\nfunc F() {}\n")
    for flag_value, extra in (
        ("true", "group_params,clothe_returns,balance_calls"),
        ("group_params", "group_params"),
        ("clothe_returns,balance_calls", "clothe_returns,balance_calls"),
    ):
        res = run_gofumpt(["-extra=" + flag_value, "a.go"], cwd=mod)
        assert res.returncode == 0, res.stderr
        assert normalize_version(res.stdout) == diagnose_output(MOD_LANG, MOD_PATH, extra)
    # -extra=false leaves the diagnose line without an -extra section.
    res = run_gofumpt(["-extra=false", "a.go"], cwd=mod)
    assert normalize_version(res.stdout) == diagnose_output(MOD_LANG, MOD_PATH)
    # Outside any module the -extra tail follows the empty -modpath= flag.
    nomod = tmp_path / "nomod"
    write(nomod / "a.go", b"package p\n\n//gofumpt:diagnose\nfunc F() {}\n")
    res = run_gofumpt(["-extra", "a.go"], cwd=nomod)
    assert res.returncode == 0, res.stderr
    assert normalize_version(res.stdout) == diagnose_output(
        "go1", "", "group_params,clothe_returns,balance_calls"
    )
