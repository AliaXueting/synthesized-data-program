"""The -extra group_params rule: merging adjacent parameter fields.

Round 5's coverage target is internal/govendor/go/format/format.go, the
vendored go/format package, for the fourth time. Rounds 2-4 established and
re-measured that the CLI can only reach that file through gofumpt's
node-printing helpers; after the measurement helpers pinned in round 2, the
one remaining reachable caller is the adjacent-field merge: gofumpt prints
the two candidate field types (via the vendored format.Node, with an empty
FileSet so positions are ignored) and merges the fields when the printed
bytes are equal. These tests pin that merge matrix with -extra, including
its boundaries (struct fields and embedded interface elements never merge,
unnamed parameters never merge) and its sharpest edge: two interface
METHODS with equal signatures merge into one field, and the printer then
emits only the first method name, silently dropping the others.
"""

import pytest

from conftest import (
    diagnose_line,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

MODULE = b"module example.com/m\n\ngo 1.21\n"
DIAGNOSE_SOURCE = b"package p\n\n//gofumpt:diagnose\nfunc f(a int, b int) {}\n"


def fmt_extra(tmp_path, source, args=("-extra",)):
    """Format source as an explicit file with the given extra-rule flags."""
    write(tmp_path / "a.go", source)
    res = run_gofumpt(list(args) + ["a.go"], cwd=tmp_path)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    return res.stdout


def test_adjacent_same_type_params_merge(tmp_path):
    """Two same-line parameters with the same type become one field.

    `func f(a int, b int)` is rewritten to `func f(a, b int)`: the two
    fields start on the same source line and their types print to the same
    bytes, so their name lists are concatenated.

    CATCHES: a re-implementation that never merges adjacent parameters (or
    that merges on name rather than printed type) leaves the two fields
    separate and fails this byte-exact comparison.
    """
    assert fmt_extra(tmp_path, b"package p\n\nfunc f(a int, b int) {}\n") == (
        b"package p\n\nfunc f(a, b int) {}\n"
    )


def test_without_extra_nothing_merges(tmp_path):
    """The merge is an extra rule: without -extra parameters stay as written.

    CATCHES: a re-implementation that applies group_params unconditionally
    merges the parameters here even though no extra rule was requested.
    """
    assert fmt_extra(tmp_path, b"package p\n\nfunc f(a int, b int) {}\n", args=()) == (
        b"package p\n\nfunc f(a int, b int) {}\n"
    )


@pytest.mark.parametrize(
    "source,expected",
    [
        # Different printed types never merge.
        (b"package p\n\nfunc f(a int, b string) {}\n",
         b"package p\n\nfunc f(a int, b string) {}\n"),
        # Unnamed parameters have no names to merge.
        (b"package p\n\nfunc f(int, int) {}\n",
         b"package p\n\nfunc f(int, int) {}\n"),
        # A variadic parameter prints differently from a slice.
        (b"package p\n\nfunc f(a []int, b ...int) {}\n",
         b"package p\n\nfunc f(a []int, b ...int) {}\n"),
        # Same reflect kind but different printed types.
        (b"package p\n\nfunc f(a *int, b *string) {}\n",
         b"package p\n\nfunc f(a *int, b *string) {}\n"),
        # Same pointer type merges.
        (b"package p\n\nfunc f(a *int, b *int) {}\n",
         b"package p\n\nfunc f(a, b *int) {}\n"),
        # `chan <- int` prints identically to `chan<- int`, so they merge.
        (b"package p\n\nfunc f(a chan<- int, b chan <- int) {}\n",
         b"package p\n\nfunc f(a, b chan<- int) {}\n"),
    ],
    ids=["different-types", "nameless", "variadic-vs-slice", "ptr-different",
         "ptr-same", "chan-direction-spelling"],
)
def test_merge_matrix(tmp_path, source, expected):
    """The merge fires only when the printed field types are equal.

    The decision prints each candidate type through the vendored go/format
    and compares the bytes, so spelling that the printer canonicalizes
    (the space in `chan <- int`) merges while any real type difference does
    not, whatever the AST shapes involved.

    CATCHES: a re-implementation comparing type syntax textually (or only
    the AST node kind) merges `*int` with `*string`, or refuses to merge
    `chan<- int` with `chan <- int`.
    """
    assert fmt_extra(tmp_path, source) == expected


def test_param_and_result_chains(tmp_path):
    """Merging chains across a whole list and applies to results too.

    Four parameters collapse into two fields, and the result list
    `(a int, b int)` collapses the same way.

    CATCHES: a re-implementation that merges only one pair per list, or
    only parameters and not results, produces extra fields here.
    """
    assert fmt_extra(
        tmp_path,
        b"package p\n\nfunc f(a int, b int, c string, d string) {}\n",
    ) == b"package p\n\nfunc f(a, b int, c, d string) {}\n"
    assert fmt_extra(
        tmp_path,
        b"package p\n\nfunc f() (a int, b int) { return 0, 0 }\n",
    ) == b"package p\n\nfunc f() (a, b int) { return 0, 0 }\n"


@pytest.mark.parametrize(
    "source,expected",
    [
        (b"package p\n\nvar f = func(a int, b int) {}\n",
         b"package p\n\nvar f = func(a, b int) {}\n"),
        (b"package p\n\ntype T struct{}\n\nfunc (t T) M(a int, b int) {}\n",
         b"package p\n\ntype T struct{}\n\nfunc (t T) M(a, b int) {}\n"),
    ],
    ids=["func-literal", "method"],
)
def test_func_literal_and_method_params_merge(tmp_path, source, expected):
    """Function literals and methods merge their parameters like funcs.

    CATCHES: a re-implementation wiring the merge only into top-level
    FuncDecl nodes leaves literals' and methods' parameters unmerged.
    """
    assert fmt_extra(tmp_path, source) == expected


def test_struct_fields_never_merge(tmp_path):
    """Struct fields on one line are deliberately never merged.

    The rule applies to parameter lists only; same-line struct fields are
    merely split onto separate lines by the printer.

    CATCHES: a re-implementation that merges any adjacent FieldList
    rewrites `a int; b int` into `a, b int` inside the struct.
    """
    assert fmt_extra(
        tmp_path, b"package p\n\ntype T struct {\n\ta int; b int\n}\n"
    ) == b"package p\n\ntype T struct {\n\ta int\n\tb int\n}\n"


def test_multiline_param_list_merges_same_line_pair(tmp_path):
    """Only parameters sharing a source line merge in a split list.

    In a parenthesized list spanning lines, `a int, b int` on one line
    merges while `c string` on its own line stays a separate field; the
    merged signature keeps the multi-line shape.

    CATCHES: a re-implementation keying the merge on the list rather than
    the line merges nothing here (or everything, flattening the list).
    """
    assert fmt_extra(
        tmp_path, b"package p\n\nfunc f(\n\ta int, b int,\n\tc string,\n) {}\n"
    ) == b"package p\n\nfunc f(\n\ta, b int,\n\tc string,\n) {\n}\n"


def test_interface_method_params_and_results_merge(tmp_path):
    """Parameters and results of an interface method merge as well.

    CATCHES: a re-implementation skipping FieldLists whose parent is an
    interface method's FuncType leaves `Foo(a int, b int) (x int, y int)`
    untouched.
    """
    assert fmt_extra(
        tmp_path,
        b"package p\n\ntype I interface {\n\tFoo(a int, b int) (x int, y int)\n}\n",
    ) == b"package p\n\ntype I interface {\n\tFoo(a, b int) (x, y int)\n}\n"


@pytest.mark.parametrize(
    "source",
    [
        b"package p\n\ntype I interface {\n\tFoo(int); Bar(int)\n}\n",
        b"package p\n\ntype I interface { Foo(int); Bar(int) }\n",
        b"package p\n\ntype I interface { Foo(int); Bar(int); Baz(int) }\n",
    ],
    ids=["multiline-braces", "one-line-braces", "three-methods"],
)
def test_interface_methods_with_equal_signatures_collapse(tmp_path, source):
    """Interface methods with equal signatures merge and DROP the names.

    Two (or three) methods on one line whose signatures print identically
    merge into a single field, and the printer emits only the first method
    name: `Foo(int); Bar(int)` formats as just `Foo(int)`. The dropped
    names are the recorded behavior of the reference, whatever a "fixed"
    version would do, and the layout of the interface braces does not
    change the outcome.

    CATCHES: a re-implementation that refuses to merge interface methods,
    or that merges them and prints every name (`Foo, Bar(int)`), differs
    from the reference on all three spellings.
    """
    assert fmt_extra(tmp_path, source) == (
        b"package p\n\ntype I interface {\n\tFoo(int)\n}\n"
    )


def test_interface_method_and_embedded_element_stay_separate(tmp_path):
    """A method and an embedded interface never merge.

    Their types have different AST kinds (FuncType vs selector), so the
    printed-type comparison fails and both survive as separate elements.

    CATCHES: a re-implementation merging any two same-line interface
    elements drops the embedded io.Reader here.
    """
    assert fmt_extra(
        tmp_path, b"package p\n\ntype I interface {\n\tFoo(int); io.Reader\n}\n"
    ) == b"package p\n\ntype I interface {\n\tFoo(int)\n\tio.Reader\n}\n"


def test_embedded_interface_elements_never_merge(tmp_path):
    """Embedded interfaces have no names, so they never merge.

    CATCHES: a re-implementation ignoring the name requirement rewrites
    `io.Reader; io.Writer` into one field and drops one of the two.
    """
    assert fmt_extra(
        tmp_path, b"package p\n\ntype I interface {\n\tio.Reader; io.Writer\n}\n"
    ) == b"package p\n\ntype I interface {\n\tio.Reader\n\tio.Writer\n}\n"


def test_group_params_rule_alone_merges_and_is_reported(tmp_path):
    """-extra=group_params alone merges params and is named in diagnose.

    The rule can be requested individually; the diagnose line then reports
    exactly that rule next to the module's resolved -lang/-modpath, and the
    merge still happens in the same output.

    CATCHES: a re-implementation that treats -extra as all-or-nothing
    either leaves the parameters unmerged or lists all three rules in the
    diagnose line.
    """
    mod = tmp_path / "m"
    write_module(mod, MODULE)
    write(mod / "a.go", DIAGNOSE_SOURCE)
    res = run_gofumpt(["-extra=group_params", "a.go"], cwd=mod)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"package p\n\n"
        + diagnose_line("go1.21", "example.com/m", "group_params")
        + b"\nfunc f(a, b int) {}\n"
    )


def test_full_extra_set_merges_and_lists_rules(tmp_path):
    """-extra with the module resolved lists every rule and merges params.

    CATCHES: a re-implementation whose diagnose line omits or reorders the
    rule list (group_params must come first), or that fails to apply the
    merge when the whole extra set is on, breaks this byte-exact output.
    """
    mod = tmp_path / "m"
    write_module(mod, MODULE)
    write(mod / "a.go", DIAGNOSE_SOURCE)
    res = run_gofumpt(["-extra", "a.go"], cwd=mod)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"package p\n\n"
        + diagnose_line("go1.21", "example.com/m", "group_params,clothe_returns,balance_calls")
        + b"\nfunc f(a, b int) {}\n"
    )


def test_extra_merging_applies_without_any_module(tmp_path):
    """Extra rules apply with no module, alongside the go1 defaults.

    Outside any module the diagnose line reports -lang=go1 with an empty
    -modpath, and the parameter merge is unaffected by the missing module.

    CATCHES: a re-implementation that ties the extra rules to module
    resolution skips the merge here, or reports a different default pair.
    """
    write(tmp_path / "a.go", DIAGNOSE_SOURCE)
    res = run_gofumpt(["-extra", "a.go"], cwd=tmp_path)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"package p\n\n"
        + diagnose_line("go1", "", "group_params,clothe_returns,balance_calls")
        + b"\nfunc f(a, b int) {}\n"
    )
