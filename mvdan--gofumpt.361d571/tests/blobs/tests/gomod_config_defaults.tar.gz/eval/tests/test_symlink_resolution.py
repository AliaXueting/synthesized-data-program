"""Module resolution for symlinked paths and unreadable link targets.

gofumpt resolves the go.mod from the directory of the path it was given, so
a symlink picks up the config of the directory holding the *link*, not the
directory holding the target file. A dangling symlink surfaces as an `open`
error (the walk itself lstat'ed the link successfully).
"""

import os

from conftest import (
    diagnose_line,
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)


def make_two_modules(tmp_path):
    """modA (go 1.12) holding a link to a file inside modB (go 1.21)."""
    mod_a = tmp_path / "modA"
    mod_b = tmp_path / "modB"
    write_module(mod_a, "module example.com/a\n\ngo 1.12\n")
    write_module(mod_b, "module example.com/b\n\ngo 1.21\n")
    write(
        mod_b / "target.go",
        b"package q\n\n//gofumpt:diagnose\nvar x = 0777\n",
    )
    link = mod_a / "link.go"
    os.symlink(os.path.join("..", "modB", "target.go"), link)
    return mod_a, mod_b, link


def test_symlink_resolves_module_from_link_directory(tmp_path):
    """A symlink's go.mod defaults come from where the link lives.

    CATCHES: resolving the module from the target's directory instead of
    the link's would report go1.21/example.com/b and rewrite the octal
    literal; the link's own module (go1.12) must win, keeping `0777`.
    """
    mod_a, mod_b, link = make_two_modules(tmp_path)
    res = run_gofumpt(["link.go"], cwd=mod_a)
    assert res.returncode == 0
    assert res.stderr == b""
    assert normalize_version(res.stdout) == (
        b"package q\n\n"
        + diagnose_line("go1.12", "example.com/a")
        + b"\nvar x = 0777\n"
    )
    # The target file itself still resolves its own module when named
    # directly from its own directory.
    res = run_gofumpt(["target.go"], cwd=mod_b)
    assert normalize_version(res.stdout) == (
        b"package q\n\n"
        + diagnose_line("go1.21", "example.com/b")
        + b"\nvar x = 0o777\n"
    )


def test_dangling_symlink_is_open_error(tmp_path):
    """A symlink whose target is missing fails with `open` on stderr.

    CATCHES: the walk lstat'ed the link itself, so the failure only appears
    when reading it: stderr must be exactly the open error line, stdout
    empty, and the exit code 2 — not an lstat error or a crash.
    """
    mod_a, mod_b, link = make_two_modules(tmp_path)
    dangling = mod_a / "dangling.go"
    os.symlink("nowhere.go", dangling)
    res = run_gofumpt(["dangling.go"], cwd=mod_a)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"open dangling.go: no such file or directory\n"


def test_walk_with_dangling_symlink_formats_sibling(tmp_path):
    """A dangling symlink in a walked tree does not hide its sibling file.

    CATCHES: the walk must keep going past the unreadable entry: the
    symlinked-but-valid file is still listed by -l with the module config
    of the walked directory, while the open error goes to stderr (exit 2).
    """
    mod_a, mod_b, link = make_two_modules(tmp_path)
    os.symlink("nowhere.go", mod_a / "dangling.go")
    res = run_gofumpt(["-l", "modA"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b"modA/link.go\n"
    assert res.stderr == b"open modA/dangling.go: no such file or directory\n"
