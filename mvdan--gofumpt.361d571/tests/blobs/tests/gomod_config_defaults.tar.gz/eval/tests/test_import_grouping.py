"""Blank lines and comments inside an import block vs the module path.

joinStdImports keeps the standard-library imports together at the top and
pushes everything else (imports matching the resolved -modpath prefix,
third-party paths, or named imports in later groups) below, separated by an
empty line. Comments and blank lines inside the block change which imports
may be moved: a commented import is never hoisted, and a blank line ends
the "first group" that gets hoisted into.
"""

import pytest

from conftest import run_gofumpt, write, write_module

GOMOD = "module mymod\n\ngo 1.21\n"


def run_module(tmp_path, source):
    """Format source as x.go inside a module rooted at tmp_path."""
    mod = tmp_path / "m"
    write_module(mod, GOMOD)
    write(mod / "x.go", source)
    return run_gofumpt(["x.go"], cwd=mod)


def imports_body(lines):
    return b"package p\n\nimport (\n" + lines + b")\n\nvar _ = fmt.Print\n"


HOISTED = imports_body(b'\t"fmt"\n\n\t"mymod/a"\n')


@pytest.mark.parametrize(
    "sep",
    [
        # An empty line between the two imports...
        b'\t"mymod/a"\n\n\t"fmt"\n',
        # ...or none at all: the std import is hoisted either way.
        b'\t"mymod/a"\n\t"fmt"\n',
    ],
)
def test_std_import_hoisted_above_module_import(tmp_path, sep):
    """`fmt` joins the top group above the module-prefix import.

    CATCHES: with the module path resolved, "mymod/a" is non-std, so the
    std import must land above it with exactly one empty line between the
    groups; a reimplementation that drops or doubles that line, or leaves
    "fmt" below, fails the byte-exact comparison.
    """
    res = run_module(tmp_path, imports_body(sep))
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == HOISTED


def test_hoisting_requires_a_module(tmp_path):
    """Without a module, "mymod/a" counts as std and no line is inserted.

    CATCHES: the separation is driven by the resolved -modpath: with no
    go.mod anywhere, both imports are standard-library-like and collapse
    into a single group with no empty line, even when the source had one.
    """
    write(tmp_path / "x.go", imports_body(b'\t"mymod/a"\n\n\t"fmt"\n'))
    res = run_gofumpt(["x.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == imports_body(b'\t"fmt"\n\t"mymod/a"\n')


def test_doc_comment_blocks_hoisting(tmp_path):
    """A std import with a doc comment in a later group is left alone.

    CATCHES: moving a commented import would strand its comment, so the
    doc-commented `fmt` below the blank line must NOT be hoisted above
    "mymod/a" — the whole block is reproduced byte-for-byte unchanged.
    """
    source = imports_body(b'\t"mymod/a"\n\n\t// keep fmt here\n\t"fmt"\n')
    res = run_module(tmp_path, source)
    assert res.returncode == 0
    assert res.stdout == source


def test_comment_between_imports_keeps_them_adjacent(tmp_path):
    """A plain comment inside the group does not split it apart.

    CATCHES: the comment is not an empty line, so it neither ends the first
    group nor gets a separating blank line added around it; the import
    block is emitted unchanged with the comment between the two imports.
    """
    source = imports_body(b'\t"fmt"\n\t// middle comment\n\t"mymod/a"\n')
    res = run_module(tmp_path, source)
    assert res.returncode == 0
    assert res.stdout == source


def test_named_std_import_in_second_group_not_hoisted(tmp_path):
    """A named import after a blank line stays out of the top group.

    CATCHES: an import with a name that is not in the first group is
    deliberately treated as non-std, so `foo "os"` is not pulled up next
    to "fmt"; the block (and its blank line) is emitted unchanged.
    """
    source = (
        b"package p\n\nimport (\n"
        b'\t"fmt"\n\n\tfoo "os"\n'
        b")\n\nvar _ = []any{fmt.Print, foo.Stdout}\n"
    )
    res = run_module(tmp_path, source)
    assert res.returncode == 0
    assert res.stdout == source
