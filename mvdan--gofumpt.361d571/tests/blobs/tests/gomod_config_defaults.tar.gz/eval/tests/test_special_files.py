"""Arguments that are not regular files: symlinks pointing at directories.

gofumpt's walk stats every argument, so a symlink is followed with os.Stat to
learn its weight; when that resolves to a directory the entry is not a
regular file and gets exclusive weight, and the subsequent read fails with
`is a directory`. During a walk the same symlink is only picked up when its
own name looks like a Go file.
"""

import os

from conftest import run_gofumpt, write, write_module

GOMOD = "module mymod\n\ngo 1.21\n"

# 0777 so the file's content also proves which module config was applied.
OCTAL_FILE = b"package p\n\nvar x = 0777\n"

FORMATTED = b"package p\n\nvar x = 0o777\n"


def make_module(tmp_path):
    """Create a module with real/a.go and keep.go, and return its path."""
    mod = tmp_path / "m"
    write_module(mod, GOMOD)
    write(mod / "real" / "a.go", OCTAL_FILE)
    write(mod / "keep.go", b"package q\n\nvar x = 0777\n")
    return mod


def test_symlink_to_directory_named_explicitly(tmp_path):
    """A symlink to a directory, named as an argument, fails at read time.

    The symlink is stat'ed through to the directory, so it is not treated as
    a walkable directory but as a single file argument; opening it succeeds
    and reading it fails, printing `read <name>: is a directory` on stderr
    with nothing on stdout and exit status 2.

    CATCHES: a re-implementation that resolves symlinks before deciding
    whether an argument is a directory would walk into it and format the
    files inside; one that skips non-regular arguments silently exits 0
    instead.
    """
    mod = make_module(tmp_path)
    os.symlink(mod / "real", mod / "adir")
    res = run_gofumpt(["adir"], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"read adir: is a directory\n"


def test_symlink_to_directory_named_like_a_go_file(tmp_path):
    """A directory symlink with a .go name is read (and fails) even on a walk.

    WalkDir does not follow symlinks, but the entry's name ends in .go so it
    is handed to the formatter like any other file; the read fails the same
    way, while the regular sibling is still formatted on stdout.

    CATCHES: a re-implementation that filters walked entries by their
    resolved type (following the symlink and recursing into the directory)
    would print real/a.go's contents a second time instead of the error.
    """
    mod = make_module(tmp_path)
    os.symlink(mod / "real", mod / "dirlike.go")
    res = run_gofumpt(["."], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b"package q\n\nvar x = 0o777\n" + FORMATTED
    assert res.stderr == b"read dirlike.go: is a directory\n"


def test_symlink_to_directory_skipped_when_not_go_named(tmp_path):
    """A directory symlink whose name is not a .go file is ignored by walks.

    The same symlink under a non-Go name is never handed to the formatter, so
    the walk of the module succeeds, formats the real directory's file with
    the module's config, and writes nothing to stderr.

    CATCHES: a re-implementation that follows directory symlinks during walks
    would format real/a.go twice (once via the symlink), and one that reports
    an error for unreadable directory entries would not exit 0 here.
    """
    mod = make_module(tmp_path)
    os.symlink(mod / "real", mod / "notgo")
    res = run_gofumpt(["."], cwd=mod)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package q\n\nvar x = 0o777\n" + FORMATTED


def test_symlink_to_directory_without_go_extension_still_explicit(tmp_path):
    """Explicitly naming a non-Go-named directory symlink still formats it.

    Arguments are formatted whatever their name, so the same symlink that the
    walk ignored is read when named directly, reproducing the `is a
    directory` error and exit status 2.

    CATCHES: a re-implementation that applies the walked-file name filter to
    explicit arguments would ignore this argument and exit 0 silently.
    """
    mod = make_module(tmp_path)
    os.symlink(mod / "real", mod / "notgo")
    res = run_gofumpt(["notgo"], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"read notgo: is a directory\n"
