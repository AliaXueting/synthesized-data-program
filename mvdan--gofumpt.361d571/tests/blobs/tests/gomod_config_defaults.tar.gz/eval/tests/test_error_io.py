"""Error reporting and exit codes around file parsing and output modes.

How parse failures surface on stderr (and only stderr) while sibling files
still get formatted with their resolved configuration; how -e changes which
parse errors are reported; how -w over stdin is rejected; and how the final
exit code reflects the *last* reported condition when a walk both diffs a
file and fails to parse another.
"""

import pytest

from conftest import (
    normalize_version,
    run_gofumpt,
    write,
    write_module,
)

GOMOD = "module example.com/o\n\ngo 1.21\n"

# Two `var` statements with invalid identifiers on one line: without -e the
# parser only reports the first error per line; with -e it reports both.
TWO_ERRORS = b"package p\n\nfunc F() { var 1 = 2; var 3 = 4 }\n"
FIRST_ERROR = b"bad.go:3:16: expected 'IDENT', found 1\n"
SECOND_ERROR = b"bad.go:3:27: expected 'IDENT', found 3\n"

GOOD_FILE = b"package ok\n\n//gofumpt:diagnose\nvar x = 0777\n"
GOOD_FORMATTED = (
    b"package ok\n\n"
    b"//gofumpt:diagnose version: <VERSION> flags: -lang=go1.21 -modpath=example.com/o\n"
    b"var x = 0o777\n"
)


def make_module(tmp_path):
    mod = tmp_path / "m"
    write_module(mod, GOMOD)
    return mod


def test_parse_error_first_per_line(tmp_path):
    """A parse failure prints one `file:line:col: msg` line and exits 2.

    CATCHES: a reimplementation must report only the first error per line
    by default, keep stdout empty, and use exit code 2 (not 1, which is
    reserved for formatting differences).
    """
    mod = make_module(tmp_path)
    write(mod / "bad.go", TWO_ERRORS)
    res = run_gofumpt(["bad.go"], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == FIRST_ERROR


def test_all_errors_flag_reports_every_error(tmp_path):
    """-e keeps reporting further parse errors on the same line.

    CATCHES: without -e the second `expected 'IDENT'` on line 3 is dropped;
    a reimplementation that always collects all errors would print both
    lines even without the flag, or still collapse them with it.
    """
    mod = make_module(tmp_path)
    write(mod / "bad.go", TWO_ERRORS)
    res = run_gofumpt(["-e", "bad.go"], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == FIRST_ERROR + SECOND_ERROR


def test_write_with_stdin_is_rejected(tmp_path):
    """-w combined with reading from standard input is a hard error.

    CATCHES: the message and exit code are pinned: stderr exactly
    `error: cannot use -w with standard input`, empty stdout, exit 2 —
    not a panic or a silent no-op, and stdin is never consumed as a file.
    """
    res = run_gofumpt(["-w"], cwd=tmp_path, stdin=b"package p\n")
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: cannot use -w with standard input\n"


def test_walk_mixed_good_and_bad_separates_streams(tmp_path):
    """A parse failure in one file does not stop the others being formatted.

    CATCHES: stdout must carry the formatted good file with the module's
    resolved config (diagnose line + octal rewrite) while stderr carries
    only the parse error, and the exit code is 2.
    """
    mod = make_module(tmp_path)
    write(mod / "bad.go", TWO_ERRORS)
    write(mod / "good.go", GOOD_FILE)
    res = run_gofumpt(["."], cwd=mod)
    assert res.returncode == 2
    assert normalize_version(res.stdout) == GOOD_FORMATTED
    assert res.stderr == FIRST_ERROR


def test_list_with_parse_error_still_lists_good_file(tmp_path):
    """-l keeps listing files whose formatting differs despite a bad file.

    CATCHES: the parse error must not abort the walk: stdout lists the
    config-changed file only, stderr holds the parse error, exit code 2.
    """
    mod = make_module(tmp_path)
    write(mod / "bad.go", TWO_ERRORS)
    write(mod / "good.go", GOOD_FILE)
    res = run_gofumpt(["-l", "."], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b"good.go\n"
    assert res.stderr == FIRST_ERROR


def expected_diff(name):
    """The exact -d stdout for GOOD_FILE walked as `name` in the module."""
    return (
        "diff %s.orig %s\n"
        "--- %s.orig\n"
        "+++ %s\n"
        "@@ -1,4 +1,4 @@\n"
        " package ok\n"
        " \n"
        "-//gofumpt:diagnose\n"
        "-var x = 0777\n"
        "+//gofumpt:diagnose version: <VERSION> flags: -lang=go1.21 -modpath=example.com/o\n"
        "+var x = 0o777\n" % (name, name, name, name)
    ).encode()


@pytest.mark.parametrize(
    "good_name,bad_name,expected_exit",
    [
        # bad.go sorts before good.go: the diff report comes last -> exit 1.
        ("good.go", "bad.go", 1),
        # aaa_good.go sorts before zzz_bad.go: the parse error comes last -> exit 2.
        ("aaa_good.go", "zzz_bad.go", 2),
    ],
)
def test_diff_exit_code_depends_on_last_report(
    tmp_path, good_name, bad_name, expected_exit
):
    """With -d, a walk that both diffs and errors exits with the last report.

    CATCHES: the exit code is whatever condition was reported last in walk
    order (formatting-differs -> 1, parse error -> 2), not e.g. the maximum
    or always 2; both orderings are pinned with their exact streams.
    """
    mod = make_module(tmp_path)
    write(mod / good_name, GOOD_FILE)
    write(mod / bad_name, TWO_ERRORS)
    res = run_gofumpt(["-d", "."], cwd=mod)
    assert res.returncode == expected_exit
    assert normalize_version(res.stdout) == expected_diff(good_name)
    assert res.stderr == ("%s:3:16: expected 'IDENT', found 1\n" % bad_name).encode()


def test_write_with_parse_error_still_writes_good_file(tmp_path):
    """-w persists the good file's resolved config despite a sibling error.

    CATCHES: partial completion semantics: the parse failure must not roll
    back or skip other files — good.go is rewritten on disk (diagnose line
    plus octal rewrite), the error goes to stderr, and the exit code is 2.
    """
    mod = make_module(tmp_path)
    write(mod / "aaa_good.go", GOOD_FILE)
    write(mod / "zzz_bad.go", TWO_ERRORS)
    res = run_gofumpt(["-w", "."], cwd=mod)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"zzz_bad.go:3:16: expected 'IDENT', found 1\n"
    assert normalize_version((mod / "aaa_good.go").read_bytes()) == GOOD_FORMATTED
