"""Black-box tests for assorted layout rules from the native testscripts.

Mined from the repository's ``testdata/script/interface.txtar``,
``testdata/script/linedirectives.txtar``, ``testdata/script/typeparams.txtar``,
``testdata/script/long-lines.txtar``, ``testdata/script/newline-errcheck.txtar``,
``testdata/script/comment-shebang.txtar`` and ``testdata/script/decls-separated.txtar``.
"""

INTERFACE_IN = """package p

type i1 interface {

	a(x int) int



	b(x int) int

	c(x int) int

	D()

	E()

	f()
}

type leadingLine1 interface {


	a(x int) int
}

type leadingLine2 interface {

	// comment

	// comment for a
	a(x int) int
}

type leadingLine8 interface {
	// comment
}

type ii1 interface {
	DoA()
	DoB()

	UndoA()
	UndoB()
}
"""

INTERFACE_OUT = """package p

type i1 interface {
	a(x int) int

	b(x int) int

	c(x int) int

	D()

	E()

	f()
}

type leadingLine1 interface {
	a(x int) int
}

type leadingLine2 interface {
	// comment

	// comment for a
	a(x int) int
}

type leadingLine8 interface {
	// comment
}

type ii1 interface {
	DoA()
	DoB()

	UndoA()
	UndoB()
}
"""

TYPEPARAMS_IN = """package p

func Foo[A, B any](x A, y B) {}

type Vector[T any] []T

var v Vector[int  ]

func Caller() {
	Foo[int,int](1,2)
}

func multilineParams[V any](p1 V,
	p2 V) {

	println("body")

}

func issue263[
	T any,
](v T) (ok bool) {
	_ = v
	return true
}
"""

TYPEPARAMS_OUT = """package p

func Foo[A, B any](x A, y B) {}

type Vector[T any] []T

var v Vector[int]

func Caller() {
	Foo[int, int](1, 2)
}

func multilineParams[V any](p1 V,
	p2 V,
) {
	println("body")
}

func issue263[
	T any,
](v T) (ok bool) {
	_ = v
	return true
}
"""

ERRCHECK_IN = """package p

var Do2 func() (int, error)

func f() {
	n1, err := Do2()
	if err != nil {
		panic(err)
	}

	n3, err := Do2()

	if err != nil {
		panic(err)
	}

	n4, err := Do2()

	if err != nil && err.Error() == "complex condition" {
		panic(err)
	}
}
"""

ERRCHECK_OUT = """package p

var Do2 func() (int, error)

func f() {
	n1, err := Do2()
	if err != nil {
		panic(err)
	}

	n3, err := Do2()
	if err != nil {
		panic(err)
	}

	n4, err := Do2()

	if err != nil && err.Error() == "complex condition" {
		panic(err)
	}
}
"""

BODIES_IN = """package p

func switch1() { switch {} }
func switch2() { switch {} }

func short()                         { println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") }
func longerNameAlignedWithShort()    { println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") }
func evenLongerNameAlignedWithShort() { println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") }
"""

BODIES_OUT = """package p

func switch1() {
	switch {
	}
}

func switch2() {
	switch {
	}
}

func short()                          { println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") }
func longerNameAlignedWithShort()     { println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") }
func evenLongerNameAlignedWithShort() { println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") }
"""

LONG_LINE = ('package p\n\nfunc _() {\n\tif err := f(argument1, argument2, '
             'argument3, argument4, argument5, argument6, argument7, argument8, '
             'argument9, argument10); err != nil {\n\t\tpanic(err)\n\t}\n}\n')

LONG_LINE_SPLIT = ('package p\n\nfunc _() {\n\tif err := f(argument1, argument2, '
                   'argument3, argument4, argument5, argument6, argument7,\n'
                   '\t\targument8, argument9, argument10); err != nil {\n'
                   '\t\tpanic(err)\n\t}\n}\n')

LINE_DIRECTIVE = ('//line foo/bar.y:4\npackage main\n//line foo/bar.y:60\n'
                  'func main() { \n//line foo/bar.y:297\n\tf, l := 0, 0\n'
                  '//line foo/bar.y:104\n\tl = 104\n'
                  '//line foo/bar.y:285\n\treturn\n}\n')

LINE_DIRECTIVE_OUT = ('//line foo/bar.y:4\npackage main\n\n'
                      '//line foo/bar.y:60\nfunc main() {\n'
                      '//line foo/bar.y:297\n\tf, l := 0, 0\n'
                      '//line foo/bar.y:104\n\tl = 104\n'
                      '//line foo/bar.y:285\n\treturn\n}\n')


def test_interface_leading_lines_are_removed(write, run):
    """Blank lines at the top of an interface body vanish, others stay.

    CATCHES: a run of blank lines before the first method collapses, but
    the blank line separating two methods is kept and a doc comment before
    the first method survives with its preceding blank line.
    """
    write("foo.go", INTERFACE_IN)
    result = run(["foo.go"])
    assert result.out == INTERFACE_OUT
    assert result.returncode == 0


def test_line_directives_do_not_confuse_line_merging(write, run):
    """//line directives keep their own lines and are ignored by the rules.

    CATCHES: a blank line is still inserted after "package main" and the
    trailing space after "func main() { " is dropped, while the directives
    stay glued to the statements that follow them.
    """
    write("foo.go", LINE_DIRECTIVE)
    result = run(["foo.go"])
    assert result.out == LINE_DIRECTIVE_OUT
    assert result.returncode == 0


def test_type_parameter_lists_get_trailing_commas(write, run):
    """Multiline type/parameter lists gain a trailing comma, others do not.

    CATCHES: "Vector[int  ]" loses its inner spaces, call arguments gain
    spaces after commas, and a type parameter list that already ends in a
    comma keeps it.
    """
    write("go.mod", "module test\n\ngo 1.18\n")
    write("foo.go", TYPEPARAMS_IN)
    result = run(["foo.go"])
    assert result.out == TYPEPARAMS_OUT
    assert result.returncode == 0


def test_blank_line_before_error_check_is_removed(write, run):
    """A single blank line between an assignment and its error check goes.

    CATCHES: the rule only joins a plain "if err != nil" check; a compound
    condition keeps the separating blank line.
    """
    write("foo.go", ERRCHECK_IN)
    result = run(["foo.go"])
    assert result.out == ERRCHECK_OUT
    assert result.returncode == 0


def test_one_line_bodies_with_control_flow_are_expanded(write, run):
    """A one-line body containing a control statement is split over lines.

    CATCHES: plain one-line bodies stay on one line but the aligned comment
    column shifts by one because the longest function name grew.
    """
    write("bodies.go", BODIES_IN)
    result = run(["bodies.go"])
    assert result.out == BODIES_OUT
    assert result.returncode == 0


def test_long_lines_are_only_split_when_opted_in(write, run):
    """GOFUMPT_SPLIT_LONG_LINES=on enables splitting lines over 100 columns.

    CATCHES: the environment variable is the only switch for the rule, and
    splitting happens after the last comma that still fits, leaving the
    "if err := ...; err != nil" shape intact.
    """
    write("foo.go", LONG_LINE)
    default = run(["foo.go"])
    assert default.out == LONG_LINE
    assert default.returncode == 0

    split = run(["foo.go"], extra_env={"GOFUMPT_SPLIT_LONG_LINES": "on"})
    assert split.out == LONG_LINE_SPLIT
    assert split.returncode == 0
    assert run(["-d", "foo.go"],
               extra_env={"GOFUMPT_SPLIT_LONG_LINES": "on"}).returncode == 1


def test_shebang_first_line_is_left_alone(write, run):
    """A leading "//usr/bin/env" shebang is preserved verbatim.

    CATCHES: the shebang is only special on the very first line; the same
    comment further down is treated as prose and gains a space, which shows
    up as a diff when -d is used.
    """
    write("foo.go", '//usr/bin/env go run "$0" "$@"; exit "$?"\n\n'
                    'package main\n\nfunc main() {}\n')
    result = run(["foo.go"])
    assert result.out == ('//usr/bin/env go run "$0" "$@"; exit "$?"\n\n'
                          'package main\n\nfunc main() {}\n')
    assert result.returncode == 0
    assert run(["-d", "foo.go"]).stdout == b""

    write("bar.go", 'package p\n\n//usr/bin/env go run not on first line\n')
    plain = run(["bar.go"])
    assert plain.out == 'package p\n\n// usr/bin/env go run not on first line\n'
    assert plain.returncode == 0
    diffed = run(["-d", "bar.go"])
    assert diffed.returncode == 1
    assert "-//usr/bin/env go run not on first line" in diffed.out
    assert "+// usr/bin/env go run not on first line" in diffed.out
