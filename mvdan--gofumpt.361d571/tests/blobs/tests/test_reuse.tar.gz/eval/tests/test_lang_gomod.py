"""Black-box tests for the Go language version gate and module discovery.

Mined from the repository's native ``testdata/script/octal-literals.txtar``,
``testdata/script/gomod.txtar``, ``testdata/script/workspaces.txtar`` and
``testdata/script/cgo.txtar`` testscripts.
"""

OCTAL_CONSTS = """package p

const (
	i = 0
	j = 022
	k = 0o_7_5_5
	l = 1022
)
"""

OCTAL_MODERN = """package p

const (
	i = 0
	j = 0o22
	k = 0o_7_5_5
	l = 1022
)
"""


def test_octal_literals_gated_by_module_version(write, run):
    """Legacy 0NNN octals only convert when the module is go1.13 or newer.

    CATCHES: the go directive of the nearest go.mod decides the rule, so
    "022" survives with go 1.12 and becomes "0o22" with go 1.13.
    """
    write("go.mod", "module test\n\ngo 1.12\n")
    write("foo.go", OCTAL_CONSTS)
    old = run(["foo.go"])
    assert old.out == OCTAL_CONSTS
    assert old.returncode == 0

    write("go.mod", "module test\n\ngo 1.13\n")
    new = run(["foo.go"])
    assert new.out == OCTAL_MODERN
    assert new.returncode == 0


def test_lang_flag_overrides_the_module_version(write, run):
    """An explicit -lang beats the go.mod version in either direction.

    CATCHES: -lang=go1.13 turns the octal into 0o22 even under a go 1.12
    module, and -lang=go1.0 keeps the legacy literal under a go 1.13 one.
    """
    write("go.mod", "module test\n\ngo 1.12\n")
    write("foo.go", OCTAL_CONSTS)
    assert run(["-lang=go1.13", "foo.go"]).out == OCTAL_MODERN

    write("go.mod", "module test\n\ngo 1.13\n")
    assert run(["-lang=go1.0", "foo.go"]).out == OCTAL_CONSTS


def test_nested_module_version_wins_over_parent(write, run):
    """A nested go.mod overrides the parent module's language version.

    CATCHES: the lookup finds the closest go.mod, so the file inside the
    nested module keeps its legacy octal while the outer one is rewritten.
    """
    write("go.mod", "module test\n\ngo 1.13\n")
    write("foo.go", OCTAL_CONSTS)
    write("nested/go.mod", "module nested\n\ngo 1.11\n")
    write("nested/nested.go", OCTAL_CONSTS)

    outer = run(["-l", "."])
    assert outer.out == "foo.go\n"
    assert run(["foo.go"]).out == OCTAL_MODERN
    assert run(["nested/nested.go"]).out == OCTAL_CONSTS


def test_go_work_file_is_ignored_in_favour_of_go_mod(write, run):
    """A go.work file never provides the language version.

    CATCHES: the tool reads go.mod only, so the go.work "go 1.18" line is
    irrelevant and the nested module's own go directive is used.
    """
    write("go.work", "go 1.18\nuse ./a\nuse ./b\n")
    write("a/go.mod", "module a\ngo 1.18\n")
    write("b/go.mod", "module b\ngo 1.11\n")
    write("a/go112.go", "package main\n\nconst x = 0777\n")
    write("b/legacy.go", "package b\n\nconst x = 0777\n")

    assert run(["a/go112.go"]).out == "package main\n\nconst x = 0o777\n"
    assert run(["b/legacy.go"]).out == "package b\n\nconst x = 0777\n"


def test_running_from_inside_the_module_directory(write, run):
    """The result is the same when invoked from inside the module.

    CATCHES: resolving the go.mod relative to the file rather than to the
    process working directory means "cd a && gofumpt go112.go" formats with
    the same -lang as "gofumpt a/go112.go".
    """
    write("a/go.mod", "module a\ngo 1.18\n")
    write("a/go112.go", "package main\n\nconst x = 0777\n")
    from_outside = run(["a/go112.go"])
    from_inside = run(["go112.go"], cwd="a")
    assert from_outside.out == from_inside.out
    assert from_inside.out == "package main\n\nconst x = 0o777\n"


def test_cgo_imports_are_never_grouped_or_moved(write, run):
    """An ``import "C"`` block stays separate from the other imports.

    CATCHES: raw-quoted and double-quoted C imports are both left alone, and
    the following std import group is neither merged into nor sorted with
    the cgo block.
    """
    write("foo.go", 'package p\n\nimport "C"\nimport "os"\n\nimport `C`\n'
                    'import "os"\n\nimport "C"\nimport (\n\t"io"\n\t"utf8"\n)\n')
    result = run(["foo.go"])
    assert result.out == ('package p\n\nimport "C"\nimport "os"\n\n'
                          'import "C"\nimport "os"\n\nimport "C"\n'
                          'import (\n\t"io"\n\t"utf8"\n)\n')
    assert result.returncode == 0
