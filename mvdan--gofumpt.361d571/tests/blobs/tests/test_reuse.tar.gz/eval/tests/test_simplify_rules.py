"""Black-box tests for the always-on simplification pass.

Mined from the repository's native ``testdata/script/simplify.txtar``
testscript and from ``format/format_test.go`` (TestSourceIncludesSimplify,
TestSourceSortsImportsFirst), which assert the same behaviour through the
public ``format.Source`` API.
"""

UNFORMATTED = """package p

const ()

const (
// Comment
)

type ()

type (
// Comment
)

var ()

var (
// Comment
)

var _ = [][]int{[]int{1}}
"""

SIMPLIFIED = """package p

const (
// Comment
)

type (
// Comment
)

var (
// Comment
)

var _ = [][]int{{1}}
"""

SIMPLIFIED_DIFF = (
    "diff foo.go.orig foo.go\n"
    "--- foo.go.orig\n"
    "+++ foo.go\n"
    "@@ -1,21 +1,15 @@\n"
    " package p\n"
    " \n"
    "-const ()\n"
    "-\n"
    " const (\n"
    " // Comment\n"
    " )\n"
    " \n"
    "-type ()\n"
    "-\n"
    " type (\n"
    " // Comment\n"
    " )\n"
    " \n"
    "-var ()\n"
    "-\n"
    " var (\n"
    " // Comment\n"
    " )\n"
    " \n"
    "-var _ = [][]int{[]int{1}}\n"
    "+var _ = [][]int{{1}}\n"
)


def test_empty_parenthesised_decls_are_removed(write, run):
    """Empty const/type/var groups vanish, but commented ones are kept.

    CATCHES: simplification deletes a declaration group with no specs, yet
    a group holding only a comment is preserved verbatim, and -d reports
    the removals as a diff while exiting 1 like the diff utility.
    """
    write("foo.go", UNFORMATTED)
    result = run(["foo.go"])
    assert result.out == SIMPLIFIED
    assert result.returncode == 0
    diffed = run(["-d", "foo.go"])
    assert diffed.out == SIMPLIFIED_DIFF
    assert diffed.stderr == b""
    assert diffed.returncode == 1


def test_simplified_output_is_stable(write, run):
    """Formatting the already-simplified output changes nothing.

    CATCHES: the simplification rules must reach a fixed point, otherwise
    repeated runs would keep churn the file.
    """
    write("foo.go", SIMPLIFIED)
    result = run(["foo.go"])
    assert result.out == SIMPLIFIED
    assert run(["-d", "foo.go"]).stdout == b""


def test_range_clauses_drop_redundant_assignment(write, run):
    """``for _ = range v`` becomes ``for range v`` via simplification.

    CATCHES: this is the gofmt -s rule that gofumpt always applies, and it
    is applied together with the removal of the empty ``var ()`` group.
    """
    write("in.go", "package p\n\nvar ()\n\nfunc f() {\n\tfor _ = range v {\n"
                   "\t}\n}\n")
    result = run(["in.go"])
    assert result.out == ("package p\n\nfunc f() {\n\tfor range v {\n\t}\n}\n")
    assert result.returncode == 0


def test_imports_are_sorted_before_std_grouping(write, run):
    """Imports get sorted first, then std and non-std groups are split.

    CATCHES: a commented import is never moved, so sorting has to happen
    before the grouping rule runs for the std import to end up on top.
    """
    write("in.go", 'package p\n\nimport (\n\t"zz.dev/q"\n\t"go/ast" // c\n)\n')
    result = run(["in.go"])
    assert result.out == ('package p\n\nimport (\n\t"go/ast" // c\n\n'
                          '\t"zz.dev/q"\n)\n')
    assert result.returncode == 0
