"""Black-box tests for one-line node printing decisions.

gofumpt asks the vendored go/printer (via ``govendor/go/format``'s
``Node`` with a ``CommentedNode`` wrapper) whether a node still prints on
a single line before joining or splitting source lines. These tests pin
the observable outcomes of those probes.
"""

ONE_LINE_STRUCT_IN = """package p

type T struct{ /* c */ A int }

type U struct {
	// doc
	A int
}
"""

ONE_LINE_STRUCT_OUT = """package p

type T struct { /* c */
	A int
}

type U struct {
	// doc
	A int
}
"""

LONE_VAR_IN = """package p

var
x = 1

var
y = 2
"""

LONE_VAR_OUT = """package p

var x = 1

var y = 2
"""


def test_one_line_struct_with_inner_comment_is_split(write, run):
    """A brace-one-line struct holding a comment is broken onto lines.

    CATCHES: the inner "/* c */" comment stops the struct type from
    printing on one line, so gofumpt splits it: the comment stays next to
    the opening brace and the field moves to its own tab-indented line
    before the closing brace.
    """
    write("struct.go", ONE_LINE_STRUCT_IN)
    result = run(["struct.go"])
    assert result.out == ONE_LINE_STRUCT_OUT
    assert result.returncode == 0


def test_lone_var_spanning_lines_is_joined(write, run):
    """A lone var split across source lines is collapsed to one line.

    CATCHES: "var\\nx = 1" prints on a single line, so the newlines between
    the keyword and the spec are removed, while the blank line between the
    two declarations keeps them from merging into one var group.
    """
    write("lone.go", LONE_VAR_IN)
    result = run(["lone.go"])
    assert result.out == LONE_VAR_OUT
    assert result.returncode == 0
