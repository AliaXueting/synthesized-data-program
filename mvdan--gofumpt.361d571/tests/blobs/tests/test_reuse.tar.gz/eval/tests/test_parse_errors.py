"""Black-box tests for error reporting and exit codes.

Mined from the repository's native testscripts plus the reporter/sequencer
logic in ``gofmt.go``: parse failures exit 2, a found diff exits 1, and a
failure for one argument does not stop the others being processed.
"""

GOOD = 'package p\n\nfunc f() {\nprintln(1)\n}\n'
GOOD_FORMATTED = 'package p\n\nfunc f() {\n\tprintln(1)\n}\n'


def test_missing_path_reports_lstat_error(write, run):
    """A non-existent argument produces a bare lstat error and exit code 2.

    CATCHES: the message is the raw *fs.PathError text with no "gofumpt:"
    prefix and no usage banner, unlike an unknown flag.
    """
    result = run(["nosuch.go"])
    assert result.stdout == b""
    assert result.err == "lstat nosuch.go: no such file or directory\n"
    assert result.returncode == 2


def test_missing_directory_argument_is_cleaned_in_message(write, run):
    """A missing directory argument is reported after path cleaning.

    CATCHES: "nodir/" is normalised to "nodir" before the lstat, so the
    error text has no trailing slash.
    """
    result = run(["nodir/"])
    assert result.err == "lstat nodir: no such file or directory\n"
    assert result.returncode == 2


def test_syntax_error_reports_position_and_exits_two(write, run):
    """A parse failure names the file, line and column of the first problem.

    CATCHES: the diagnostic follows go/scanner's format
    "<file>:<line>:<col>: <message>" on stderr with exit code 2.
    """
    write("bad.go", "package p\n\nfunc (\n")
    result = run(["bad.go"])
    assert result.stdout == b""
    assert result.err == "bad.go:3:8: expected ')', found 'EOF'\n"
    assert result.returncode == 2


def test_all_errors_flag_reports_the_full_diagnostic_list(write, run):
    """-e lifts the ten-error-per-line cap of the go parser.

    CATCHES: without -e only the first error on each differing line is
    kept (two lines here), while -e prints every recoverable error.
    """
    write("bad.go", "package p\n\nfunc (((((\nvar (((\nconst (((\ntype (((\n")
    few = run(["bad.go"])
    assert few.err == ("bad.go:4:1: expected type, found 'var'\n"
                       "bad.go:6:10: expected ')', found 'EOF'\n")
    assert few.returncode == 2

    allerr = run(["-e", "bad.go"])
    assert allerr.err.splitlines()[0] == "bad.go:4:1: expected type, found 'var'"
    assert len(allerr.err.splitlines()) == 11
    assert allerr.err.endswith("bad.go:6:10: missing ',' in parameter list\n")
    assert allerr.returncode == 2


def test_error_does_not_stop_later_arguments(write, run):
    """A failing argument is reported but the remaining ones still format.

    CATCHES: the sequencer keeps going after an error, so the good file's
    formatted bytes still reach stdout while the exit code stays 2.
    """
    write("ok.go", GOOD)
    result = run(["nosuch.go", "ok.go"])
    assert result.err == "lstat nosuch.go: no such file or directory\n"
    assert result.out == GOOD_FORMATTED
    assert result.returncode == 2


def test_parse_error_does_not_stop_later_arguments(write, run):
    """A file with a syntax error is skipped but later files still format.

    CATCHES: the failure of one file never aborts the whole run, and the
    formatted output of the good file is still emitted in full.
    """
    write("bad.go", "package p\n\nfunc (\n")
    write("ok.go", GOOD)
    result = run(["bad.go", "ok.go"])
    assert result.err == "bad.go:3:8: expected ')', found 'EOF'\n"
    assert result.out == GOOD_FORMATTED
    assert result.returncode == 2


def test_missing_import_is_not_reported(write, run):
    """An unresolved import is not an error; gofumpt only reformats source.

    CATCHES: the tool parses without type checking, so referencing an
    unimported package leaves the file otherwise untouched and exits 0.
    """
    write("foo.go", "package p\n\nvar _ bytes.Buffer\n")
    result = run(["foo.go"])
    assert result.out == "package p\n\nvar _ bytes.Buffer\n"
    assert result.stderr == b""
    assert result.returncode == 0
    assert run(["-d", "foo.go"]).stdout == b""
