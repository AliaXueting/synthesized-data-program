"""Black-box tests for expression-list column alignment in literals.

Mined from the geometric-mean alignment heuristic of the vendored
``internal/govendor/go/printer`` package: when a multi-line key:value
list is printed, each entry's key width is compared against the
geometric mean of the preceding key widths (``nodes.go`` using the
``log2ish``/``exp2ish`` helpers from ``math.go``). An entry whose ratio
to that mean leaves the [0.4, 2.5] band — or whose key width exceeds 40
while no earlier width was recorded — is printed after a formfeed, which
starts a new tabwriter section and drops column alignment with the
previous entries. All expected bytes below were recorded from the
reference binary.
"""

import pytest

SHORT_IN = """package p

var _ = map[string]int{
	"a": 1,
	"bb": 22,
	"ccc": 333,
}
"""

SHORT_OUT = """package p

var _ = map[string]int{
	"a":   1,
	"bb":  22,
	"ccc": 333,
}
"""

LONGKEY_IN = """package p

var _ = map[string]int{
	"a": 1,
	"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx": 2,
	"c": 3,
}
"""

MIDKEYS_IN = """package p

var _ = map[string]int{
	"aaaaaaaaaaaaaaaaaaaaaaaaaaaa": 1,
	"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb": 2,
	"c": 3,
}
"""

MIDKEYS_OUT = """package p

var _ = map[string]int{
	"aaaaaaaaaaaaaaaaaaaaaaaaaaaa":                     1,
	"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb": 2,
	"c": 3,
}
"""

# A 38-byte key (40 bytes with quotes) still aligns with the short key;
# the padding below pads `"a":` out to the wide key's value column.
BOUND_ALIGNED = (
    "package p\n\nvar _ = map[string]int{\n"
    '\t"a":' + " " * 38 + "1,\n"
    '\t"' + "b" * 38 + '": 2,\n'
    "}\n"
)

# One byte more and the wide key starts its own section instead.
BOUND_BROKEN = (
    "package p\n\nvar _ = map[string]int{\n"
    '\t"a": 1,\n'
    '\t"' + "b" * 39 + '": 2,\n'
    "}\n"
)

TWOLONG_IN = """package p

var _ = map[string]int{
	"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": 1,
	"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb": 2,
	"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": 3,
}
"""

TWOLONG_OUT = """package p

var _ = map[string]int{
	"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": 1,
	"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb":   2,
	"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": 3,
}
"""

CHAIN_IN = """package p

var _ = map[string]int{
	"cccccccccccccccccccccccccccccccccccccccccccc": 1,
	"dddddddddddddddddddddddddddddddddddddddddddddd": 2,
	"ee": 3,
	"eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee": 4,
}
"""

CHAIN_OUT = """package p

var _ = map[string]int{
	"cccccccccccccccccccccccccccccccccccccccccccc":   1,
	"dddddddddddddddddddddddddddddddddddddddddddddd": 2,
	"ee": 3,
	"eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee": 4,
}
"""

NESTED_IN = """package p

var _ = map[string][]int{
	"a": {
		1,
	},
	"bbbb": {22},
	"c": {3},
}
"""

NESTED_OUT = """package p

var _ = map[string][]int{
	"a": {
		1,
	},
	"bbbb": {22},
	"c":    {3},
}
"""

BLANK_IN = """package p

var _ = map[string]int{
	"aaaa": 1,

	"b": 2,
}
"""

SAMILINE_IN = """package p

var _ = map[string]int{
	"aaaa": 1, "b": 2,
	"cc": 33,
}
"""

LONGVAL_IN = """package p

var _ = map[string]int{
	"a": 111111111111111111111111111111111111111111111111111111111111,
	"bb": 22,
}
"""

LONGVAL_OUT = """package p

var _ = map[string]int{
	"a":  111111111111111111111111111111111111111111111111111111111111,
	"bb": 22,
}
"""


def test_short_keys_align_in_one_column(write, run):
    """Entries of a multiline map literal share one value column.

    CATCHES: keys of different widths are padded so every value starts
    at the same column; a printer that emits a single space after every
    colon loses the column alignment.
    """
    write("foo.go", SHORT_IN)
    result = run(["foo.go"])
    assert result.out == SHORT_OUT
    assert result.returncode == 0


def test_oversized_key_after_a_short_one_breaks_alignment(write, run):
    """A very wide key after a short one drops alignment for all entries.

    CATCHES: the 50-byte key is ~17x the previous key width, so each
    entry is printed in its own tabwriter section and no padding is
    added, unlike the aligned short-key case.
    """
    write("foo.go", LONGKEY_IN)
    result = run(["foo.go"])
    assert result.out == LONGKEY_IN
    assert result.returncode == 0


def test_oversized_key_within_ratio_keeps_column_alignment(write, run):
    """A wide key whose ratio to the mean is mild keeps the column.

    CATCHES: the 50-byte key is only ~1.7x the 30-byte key before it,
    so both stay aligned while the short key after them starts a new
    section; keying on an absolute width alone would misalign the pair.
    """
    write("foo.go", MIDKEYS_IN)
    result = run(["foo.go"])
    assert result.out == MIDKEYS_OUT
    assert result.returncode == 0


@pytest.mark.parametrize("key_len,expected", [
    (38, BOUND_ALIGNED),
    (39, BOUND_BROKEN),
])
def test_alignment_breaks_above_forty_key_bytes(write, run, key_len, expected):
    """Key width 40 keeps the column; width 41 starts a new section.

    CATCHES: the small-size cutoff is exactly 40 bytes including the
    quotes, so a 38-char key still pads the short key out to its column
    while a 39-char key leaves both entries unpadded.
    """
    src = ('package p\n\nvar _ = map[string]int{\n'
           '\t"a": 1,\n'
           '\t"' + "b" * key_len + '": 2,\n'
           '}\n')
    write("foo.go", src)
    result = run(["foo.go"])
    assert result.out == expected
    assert result.returncode == 0


def test_close_oversized_keys_stay_aligned_together(write, run):
    """Several oversized keys of near-equal width keep one column.

    CATCHES: 46- and 44-byte keys are within the ratio band of each
    other, so the narrower one is padded to the wider column even
    though every key exceeds the 40-byte small-size cutoff.
    """
    write("foo.go", TWOLONG_IN)
    result = run(["foo.go"])
    assert result.out == TWOLONG_OUT
    assert result.returncode == 0


def test_mixed_sizes_break_alignment_per_ratio(write, run):
    """A longer chain breaks sections exactly where ratios leave the band.

    CATCHES: the first two wide keys align, the short "ee" key after
    them starts its own section, and the final wide key (about 4x the
    running geometric mean) starts yet another one instead of rejoining
    the first column.
    """
    write("foo.go", CHAIN_IN)
    result = run(["foo.go"])
    assert result.out == CHAIN_OUT
    assert result.returncode == 0


def test_multiline_value_entry_resets_alignment(write, run):
    """An entry whose value spans lines gets its own alignment section.

    CATCHES: the multiline entry carries no single-line key width, so
    the entries after it are formfeed-separated from it while aligning
    with each other ("bbbb" and "c" share a column).
    """
    write("foo.go", NESTED_IN)
    result = run(["foo.go"])
    assert result.out == NESTED_OUT
    assert result.returncode == 0


def test_blank_line_between_entries_ends_the_column(write, run):
    """A blank line between entries is kept and breaks the column.

    CATCHES: the blank line survives formatting and the entry after it
    is not padded to the previous entry's column, even though both keys
    are narrow enough to align if adjacent.
    """
    write("foo.go", BLANK_IN)
    result = run(["foo.go"])
    assert result.out == BLANK_IN
    assert result.returncode == 0


def test_pairs_sharing_a_line_form_their_own_section(write, run):
    """Two pairs on one source line stay put and break the next column.

    CATCHES: the shared line keeps both pairs with single spaces, and
    the pair on the following line is not padded to their column
    because the line change after a shared line is a section break.
    """
    write("foo.go", SAMILINE_IN)
    result = run(["foo.go"])
    assert result.out == SAMILINE_IN
    assert result.returncode == 0


def test_value_width_does_not_affect_alignment(write, run):
    """Only key widths feed the alignment decision, not value widths.

    CATCHES: a 63-byte value leaves the short keys aligned in one
    column, so a heuristic that measures the whole entry instead of the
    key would split the section.
    """
    write("foo.go", LONGVAL_IN)
    result = run(["foo.go"])
    assert result.out == LONGVAL_OUT
    assert result.returncode == 0


def test_aligned_literal_output_is_a_fixed_point(write, run):
    """The aligned and section-split outputs do not change on a second pass.

    CATCHES: re-formatting the padded columns must reproduce them
    byte-for-byte (no diff in -d mode and identical stdout), so the
    alignment decisions are stable rather than oscillating.
    """
    write("mid.go", MIDKEYS_OUT)
    write("chain.go", CHAIN_OUT)
    assert run(["-d", "mid.go"]).stdout == b""
    assert run(["-d", "chain.go"]).stdout == b""
    assert run(["mid.go"]).out == MIDKEYS_OUT
    assert run(["chain.go"]).out == CHAIN_OUT
