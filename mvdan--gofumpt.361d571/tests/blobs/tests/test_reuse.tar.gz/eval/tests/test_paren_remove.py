"""Black-box tests for redundant parenthesis removal.

Mined from the repository's native ``testdata/script/paren-remove.txtar``
testscript.
"""

PARENS_IN = """package p

import "fmt"

type T struct{ x int }

func (T) Foo() int { return 0 }

type C chan (int)

type C2 chan (<-chan int)

type C3 chan (chan int)

var _ = (*T)(nil)

func f(x int) int { return x }

var a, b bool

var mm map[T]int

func g() {
	_ = f((3))
	_ = ((3))
	_ = (f(3))
	_ = (fmt.Sprintln(3))
	_ = (T{}).x
	_ = ([]int{1, 2})[0]
	xs := []int{1, 2, 3}
	_ = (xs[1:2])

	// Keep parens in binary/unary expressions for readability.
	_ = (1 + 2) * 3
	_ = -(1 + 2)
	_ = !(a || b)

	// Keep parens with inner comment.
	_ = ( /* keep */ 3)

	// Keep parens around composite literals in conditions.
	if (T{x: 3}) == (T{x: 3}) {
	}

	// Keep parens when the expression begins with a composite literal.
	if 1 == (T{}.Foo()) {
	}
	for (T{}.Foo()) == 1 {
	}
	switch (T{}.x) {
	}
	if ([]int{1}[0]) == 0 {
	}
	_ = ([]int{1, 2, 3}[1:2])

	// Drop parens when the composite literal is enclosed in parens or brackets.
	if ((T{}).Foo()) == 0 {
	}
	_ = (mm[T{}])
	_ = (fmt.Sprintln(T{}))

	// Drop double parens.
	_ = ((f(3)))

	// Drop parens around call args.
	_ = f((f(3)))

	// Drop the parens along with the line break after them.
	_ = (
		f(3))
}
"""

PARENS_OUT = """package p

import "fmt"

type T struct{ x int }

func (T) Foo() int { return 0 }

type C chan int

type C2 chan (<-chan int)

type C3 chan (chan int)

var _ = (*T)(nil)

func f(x int) int { return x }

var a, b bool

var mm map[T]int

func g() {
	_ = f(3)
	_ = 3
	_ = f(3)
	_ = fmt.Sprintln(3)
	_ = (T{}).x
	_ = ([]int{1, 2})[0]
	xs := []int{1, 2, 3}
	_ = xs[1:2]

	// Keep parens in binary/unary expressions for readability.
	_ = (1 + 2) * 3
	_ = -(1 + 2)
	_ = !(a || b)

	// Keep parens with inner comment.
	_ = ( /* keep */ 3)

	// Keep parens around composite literals in conditions.
	if (T{x: 3}) == (T{x: 3}) {
	}

	// Keep parens when the expression begins with a composite literal.
	if 1 == (T{}.Foo()) {
	}
	for (T{}.Foo()) == 1 {
	}
	switch (T{}.x) {
	}
	if ([]int{1}[0]) == 0 {
	}
	_ = ([]int{1, 2, 3}[1:2])

	// Drop parens when the composite literal is enclosed in parens or brackets.
	if (T{}).Foo() == 0 {
	}
	_ = mm[T{}]
	_ = fmt.Sprintln(T{})

	// Drop double parens.
	_ = f(3)

	// Drop parens around call args.
	_ = f(f(3))

	// Drop the parens along with the line break after them.
	_ = f(3)
}
"""


def test_redundant_parens_are_dropped_but_readable_ones_kept(write, run):
    """Parens that do not change grouping go; readability parens stay.

    CATCHES: ``chan (int)`` loses its parens while ``chan (<-chan int)``
    keeps them, and parens around composite literals in conditions survive
    even when the same literal is unwrapped elsewhere.
    """
    write("foo.go", PARENS_IN)
    result = run(["foo.go"])
    assert result.out == PARENS_OUT
    assert result.returncode == 0


def test_paren_removal_is_stable(write, run):
    """The paren-stripped output is a fixed point of the formatter.

    CATCHES: a second pass must not find anything left to remove, which is
    checked with the silent -d mode over the recorded golden output.
    """
    write("foo.go", PARENS_OUT)
    assert run(["-d", "foo.go"]).stdout == b""
    assert run(["foo.go"]).out == PARENS_OUT


def test_double_parens_and_line_break_after_open_paren(write, run):
    """A paren pair split across lines is removed along with the break.

    CATCHES: removing "(\n" has to pull the call onto one line, and nested
    redundant parens around a call argument are stripped recursively.
    """
    write("split.go", 'package p\n\nfunc f(x int) int { return x }\n\n'
                      'func g() {\n\t_ = (\n\t\tf(3))\n\t_ = f((f(3)))\n}\n')
    result = run(["split.go"])
    assert result.out == ('package p\n\nfunc f(x int) int { return x }\n\n'
                          'func g() {\n\t_ = f(3)\n\t_ = f(f(3))\n}\n')
    assert result.returncode == 0
