"""Black-box tests for the ``-d`` diff mode.

Mined from the repository's native ``testdata/script/diff.txtar``
testscript: gofumpt's ``-d`` behaves like the ``diff`` utility and exits
non-zero when a difference is found, unlike upstream gofmt.
"""

CLEAN = 'package p\n\nfunc f() {\n\tprintln("well formatted")\n}\n'
DIRTY = 'package p\n\nfunc f() {\nprintln("not well formatted")\n}\n'
DIRTY_DIFF = ("diff bad.go.orig bad.go\n"
              "--- bad.go.orig\n"
              "+++ bad.go\n"
              "@@ -1,5 +1,5 @@\n"
              " package p\n"
              " \n"
              " func f() {\n"
              "-println(\"not well formatted\")\n"
              "+\tprintln(\"not well formatted\")\n"
              " }\n")


def test_diff_clean_file_is_silent(write, run):
    """A well-formatted file yields no diff, no stderr and exit code 0.

    CATCHES: -d must not print anything at all when the file already
    matches gofumpt's output, including no header lines, so mixing it with
    an unformatted file must print only that one file's diff.
    """
    write("good.go", CLEAN)
    result = run(["-d", "good.go"])
    assert result.stdout == b""
    assert result.stderr == b""
    assert result.returncode == 0

    write("bad.go", DIRTY)
    mixed = run(["-d", "good.go", "bad.go"])
    assert mixed.out == DIRTY_DIFF
    assert mixed.stderr == b""
    assert mixed.returncode == 1


def test_diff_unformatted_file_exact_output(write, run):
    """An unformatted file produces a unified diff against the ".orig" name.

    CATCHES: the headers, the @@ hunk range and the tab-indented "+" line
    are byte-exact, and the run exits 1 while stderr stays empty.
    """
    write("bad.go", DIRTY)
    result = run(["-d", "bad.go"])
    assert result.out == DIRTY_DIFF
    assert result.stderr == b""
    assert result.returncode == 1


def test_diff_does_not_modify_the_file(write, run, read):
    """-d never rewrites the file on disk, unlike -w.

    CATCHES: the diff is displayed only, so the original unformatted bytes
    must still be on disk after a non-zero exit, while the same content
    passed to -w is rewritten to the formatted form.
    """
    write("bad.go", DIRTY)
    write("writable.go", DIRTY)
    result = run(["-d", "bad.go"])
    assert result.out == DIRTY_DIFF
    assert result.returncode == 1
    assert read("bad.go") == DIRTY

    rewritten = run(["-w", "writable.go"])
    assert rewritten.stdout == b""
    assert rewritten.returncode == 0
    assert read("writable.go") == 'package p\n\nfunc f() {\n' \
                                  '\tprintln("not well formatted")\n}\n'


def test_diff_with_multiple_hunks(write, run):
    """Separately changed regions produce one hunk each in a single diff.

    CATCHES: the hunk header counts every line of the file (@@ -1,11 +1,11 @@)
    rather than just the changed lines, and the unchanged context in between
    is repeated in both hunks.
    """
    write("multi.go", 'package p\n\nfunc a() {\nprintln("a")\n}\n\n'
                      'var x = []int{1, 2}\n\nfunc b() {\nprintln("b")\n}\n')
    result = run(["-d", "multi.go"])
    assert result.out == (
        "diff multi.go.orig multi.go\n"
        "--- multi.go.orig\n"
        "+++ multi.go\n"
        "@@ -1,11 +1,11 @@\n"
        " package p\n"
        " \n"
        " func a() {\n"
        "-println(\"a\")\n"
        "+\tprintln(\"a\")\n"
        " }\n"
        " \n"
        " var x = []int{1, 2}\n"
        " \n"
        " func b() {\n"
        "-println(\"b\")\n"
        "+\tprintln(\"b\")\n"
        " }\n"
    )
    assert result.returncode == 1


def test_diff_paths_are_cleaned_and_ordered_by_argument(write, run):
    """Diff headers use the cleaned path and follow the argument order.

    CATCHES: "./sub//deep.go" is normalised to "sub/deep.go" in the header,
    and two files are diffed in the order they were given on the command
    line rather than in walk order.
    """
    write("sub/deep.go", DIRTY)
    write("other.go", 'package p\n\nfunc g() {\nprintln("g")\n}\n')
    one = run(["-d", "./sub//deep.go"])
    assert one.out.startswith("diff sub/deep.go.orig sub/deep.go\n")

    both = run(["-d", "other.go", "sub/deep.go"])
    assert both.out.index("diff other.go.orig other.go") < \
        both.out.index("diff sub/deep.go.orig sub/deep.go")
    assert both.returncode == 1


def test_diff_combined_with_list(write, run):
    """-l and -d together print the filename before its diff.

    CATCHES: both outputs are produced for the same file and the exit code
    is still the diff-specific 1 rather than the list-specific 0.
    """
    write("bad.go", DIRTY)
    result = run(["-l", "-d", "bad.go"])
    assert result.out == "bad.go\n" + DIRTY_DIFF
    assert result.returncode == 1
