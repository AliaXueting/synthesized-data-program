"""Black-box tests for flag parsing, the usage banner and version output.

Mined from the repository's native ``testdata/script/deprecated-flags.txtar``
testscript plus the ``usage``/``version`` handling in ``gofmt.go``.
"""

USAGE = """usage: gofumpt [flags] [path ...]
\t-version  show version and exit

\t-d        display diffs instead of rewriting files
\t-e        report all errors (not just the first 10 on different lines)
\t-l        list files whose formatting differs from gofumpt's
\t-w        write result to (source) file instead of stdout
\t-extra    enable extra rules, e.g. -extra=group_params,clothe_returns

\t-lang       str    target Go version in the form "go1.X" (default from go.mod)
\t-modpath    str    Go module path containing the source file (default from go.mod)
"""

UNFORMATTED = "package p\n\nfunc f() {\nprintln(\"foo\")\n}\n"


def test_usage_banner_on_help(write, run):
    """-h and --help print the full usage banner on stderr and exit 0.

    CATCHES: the banner is byte-exact (tab-indented flag list, the blank
    separator lines) and goes to stderr, not stdout.
    """
    for flag in ("-h", "--help"):
        result = run([flag])
        assert result.stdout == b""
        assert result.err == USAGE
        assert result.returncode == 0


def test_unknown_flag_prints_error_then_usage(write, run):
    """An undefined flag reports itself and dumps usage, exiting with code 2.

    CATCHES: gofumpt reuses Go's flag package error wording and prepends it
    to the same usage banner used by -h, but exits 2 rather than 0.
    """
    result = run(["-zzz"])
    assert result.stdout == b""
    assert result.err == "flag provided but not defined: -zzz\n" + USAGE
    assert result.returncode == 2


def test_version_flag_prints_build_and_go_version(write, run):
    """-version prints "<module version> (<go version>)" and nothing else.

    CATCHES: GO_VERSION_TEST overrides the reported Go toolchain version,
    which pins the otherwise build-dependent half of the string.
    """
    result = run(["-version"], extra_env={"GO_VERSION_TEST": "go1.18.29"})
    assert result.out == "(devel) (go1.18.29)\n"
    assert result.stderr == b""
    assert result.returncode == 0


def test_rewrite_flag_is_rejected_and_file_untouched(write, run, read):
    """-r aborts before any file is read, so nothing is rewritten.

    CATCHES: the friendly "use gofmt -r" message goes to stderr as a single
    newline-terminated line and the process exits 2, leaving the file untouched.
    """
    write("foo.go", UNFORMATTED)
    result = run(["-w", "-r", "foo", "foo.go"])
    assert result.stdout == b""
    assert result.err == ('the rewrite flag is no longer available; '
                         'use "gofmt -r" instead\n')
    assert result.returncode == 2
    assert read("foo.go") == UNFORMATTED


def test_simplify_flag_warns_but_still_formats(write, run, read):
    """-s only warns; simplification is always on so the file is rewritten.

    CATCHES: the deprecation warning is a single stderr line, the exit code
    stays 0 and -w still rewrites the file in place.
    """
    write("foo.go", "package p\n\nfunc f() {\n\n\tprintln(\"foo\")\n\n}\n")
    result = run(["-w", "-s", "foo.go"])
    assert result.stdout == b""
    assert result.err == "warning: -s is deprecated as it is always enabled\n"
    assert result.returncode == 0
    assert read("foo.go") == 'package p\n\nfunc f() {\n\tprintln("foo")\n}\n'


def test_simplify_flag_alone_does_not_write(write, run):
    """Without -w the -s warning still appears while the code goes to stdout.

    CATCHES: the warning and the formatted program are correctly split
    between stderr and stdout even when both streams are produced.
    """
    write("foo.go", UNFORMATTED)
    result = run(["-s", "foo.go"])
    assert result.err == "warning: -s is deprecated as it is always enabled\n"
    assert result.out == 'package p\n\nfunc f() {\n\tprintln("foo")\n}\n'
    assert result.returncode == 0
