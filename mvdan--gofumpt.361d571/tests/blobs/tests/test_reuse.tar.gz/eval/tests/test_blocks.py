"""Black-box tests for removing blank lines inside blocks and single bodies.

Mined from the repository's native ``testdata/script/block-empty.txtar``
and ``testdata/script/block-single.txtar`` testscripts.
"""

EMPTY_IN = """package p

func f() {
	if true {
		// lone comment
	}
	{

	}

	{

		// lone comment

	}

	type S struct {


		// lone comment


	}

	type I interface {


		// lone comment


	}


}

type SOut struct {

	// lone comment

}

type IOut interface {


	// lone comment


}

func g() {

/* unindented
comment */
	println()
}
"""

EMPTY_OUT = """package p

func f() {
	if true {
		// lone comment
	}
	{
	}

	{
		// lone comment
	}

	type S struct {
		// lone comment
	}

	type I interface {
		// lone comment
	}
}

type SOut struct {
	// lone comment
}

type IOut interface {
	// lone comment
}

func g() {
	/* unindented
	   comment */
	println()
}
"""

SINGLE_IN = """package p

func f() {
	if true {

		println()
	}

	for true {
		println()

	}

	{


		println(1, 2,
			3, 4, `foo
			bar`)


	}

	{

		// comment directly before
		println()

		// comment after

	}

	// For readability; the empty line helps separate the multi-line
	// condition from the body.
	if true &&
		true {

		println()
	}
	for true &&
		true {

		println()
	}

	// The condition is printed on one line.
	if !
	true {

		println()
	}
}
"""

SINGLE_OUT = """package p

func f() {
	if true {
		println()
	}

	for true {
		println()
	}

	{
		println(1, 2,
			3, 4, `foo
			bar`)
	}

	{
		// comment directly before
		println()

		// comment after
	}

	// For readability; the empty line helps separate the multi-line
	// condition from the body.
	if true &&
		true {

		println()
	}
	for true &&
		true {

		println()
	}

	// The condition is printed on one line.
	if !true {
		println()
	}
}
"""

LONE_COMMENT_IN = """package p

const (
//
)

var _ = struct {
//
}{}

var _ = []int{
//
}

func f() {
	g(
//
	)
}

func h() string {
	s :=
//
"value"
	return s
}

func
//
beforeIdent() {}

func i() int {
	println()
//
return 1
}

var _ = []int{
	1,
//
2,
}
"""

LONE_COMMENT_OUT = """package p

var _ = struct{}{}

var _ = []int{}

func f() {
	g(
	//
	)
}

func h() string {
	s := "value"
	return s
}

func
//
beforeIdent() {
}

func i() int {
	println()
	return 1
}

var _ = []int{
	1,
	2,
}
"""


def test_empty_lines_around_lone_comments_are_removed(write, run):
    """Runs of blank lines collapse to at most one around a lone comment.

    CATCHES: empty struct/interface bodies keep exactly one comment line,
    and an unindented block comment is re-indented with its continuation
    lines aligned by three spaces.
    """
    write("foo.go", EMPTY_IN)
    result = run(["foo.go"])
    assert result.out == EMPTY_OUT
    assert result.returncode == 0


def test_single_statement_body_loses_its_blank_lines(write, run):
    """A one-statement body keeps no leading/trailing blank lines.

    CATCHES: the rule only fires for single-statement bodies; a multi-line
    condition still keeps the separating blank line, and a body with both a
    leading and a trailing comment keeps the blank line between them.
    """
    write("foo.go", SINGLE_IN)
    result = run(["foo.go"])
    assert result.out == SINGLE_OUT
    assert result.returncode == 0


def test_lone_comment_specs_empty_their_containers(write, run):
    """A group holding only a "//" line is deleted along with the group.

    CATCHES: composite literals collapse to "{}" while a call keeps its
    parens and re-indents the surviving lone comment by exactly one tab,
    and a lone comment between the func keyword and the name is preserved.
    """
    write("empty-comments.go", LONE_COMMENT_IN)
    result = run(["empty-comments.go"])
    assert result.out == LONE_COMMENT_OUT
    assert result.returncode == 0


def test_empty_doc_groups_before_decls_are_dropped(write, run):
    """A "//"-only doc comment before a declaration group is deleted.

    CATCHES: the lone comment above ``import "os"`` survives because it is
    a real doc position, while the ones above var/type groups disappear
    together with the now-empty parenthesised group.
    """
    write("empty-docs.go", 'package p\n\n//\nimport "os"\n\n//\nvar (\n'
                            '\tlone = 1\n)\n\ntype embedsPointer struct {\n//\n'
                            '*int\n}\n')
    result = run(["empty-docs.go"])
    assert result.out == ('package p\n\n//\nimport "os"\n\nvar lone = 1\n\n'
                          'type embedsPointer struct {\n\t*int\n}\n')
    assert result.returncode == 0
