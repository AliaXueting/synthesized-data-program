"""Black-box tests for the opt-in ``-extra`` rules.

Mined from the repository's native ``testdata/script/func-merge-parameters.txtar``
and ``testdata/script/call-multiline.txtar`` and
``testdata/script/clothe-returns.txtar`` testscripts.
"""

GROUP_PARAMS_IN = """package p

type f func(x int, y int) int

type i interface {
	add(x int, y int)
}

type s struct {
	x int
	y int
}

func mergeAdjacent(x int, y int) {}

func mergeThreeAdjacent(x int, y int, z int) {}

func mergeOneWithTwo(x, y int, z int) {}

func mergeTwoWithOne(x int, y, z int) {}

func mergeWithComment(
	x int, y int, // comment
)

func mergeAllSyntax(x chan []*foo.Bar, y chan []*foo.Bar) {}

func dontMergeAnonymousParams(int, int) {}

func dontMergeMultipleLines(
	x int,
	y int,
) {
}

func dontMergeDifferentKinds(format string, args ...string) {}

func dontMergeDifferentTypesReturn() (n int, err error) {}

func mergeIgnoresPositions(a func(x int), b func(
	x int)) {
}
"""

GROUP_PARAMS_OUT = """package p

type f func(x, y int) int

type i interface {
	add(x, y int)
}

type s struct {
	x int
	y int
}

func mergeAdjacent(x, y int) {}

func mergeThreeAdjacent(x, y, z int) {}

func mergeOneWithTwo(x, y, z int) {}

func mergeTwoWithOne(x, y, z int) {}

func mergeWithComment(
	x, y int, // comment
)

func mergeAllSyntax(x, y chan []*foo.Bar) {}

func dontMergeAnonymousParams(int, int) {}

func dontMergeMultipleLines(
	x int,
	y int,
) {
}

func dontMergeDifferentKinds(format string, args ...string) {}

func dontMergeDifferentTypesReturn() (n int, err error) {}

func mergeIgnoresPositions(a, b func(x int),
) {
}
"""

CLOTHE_IN = """package p

func foo() (err error) {
	if true {
		return
	}
	if false {
		return func() (err2 error) {
			return
		}
	}
	return
}

func bar() (_ int, err error) {
	return
}

func baz() (a, b, c int) {
	return
}

func qux() (file string, b int, err error) {
	if err == nil {
		return
	}

	// A comment
	return
}

func unnamed() int { return }

// quux does quuxy things
func quux() {}
"""

CLOTHE_OUT = """package p

func foo() (err error) {
	if true {
		return err
	}
	if false {
		return func() (err2 error) {
			return err2
		}
	}
	return err
}

func bar() (_ int, err error) {
	return
}

func baz() (a, b, c int) {
	return a, b, c
}

func qux() (file string, b int, err error) {
	if err == nil {
		return file, b, err
	}

	// A comment
	return file, b, err
}

func unnamed() int { return }

// quux does quuxy things
func quux() {}
"""

BALANCE_IN = """package p

func _() {
	// opening paren at end of line, closing paren not at start of line:
	// move closing paren so both are consistent.
	_ = call(
		a,
		b,
		c)

	// inline comment after the last argument should still cause the
	// closing paren to be moved to its own line.
	_ = call(
		a,
		b,
		c) // trailing

	// nested calls
	_ = outer(inner(
		a,
		b))
}
"""

BALANCE_OUT = """package p

func _() {
	// opening paren at end of line, closing paren not at start of line:
	// move closing paren so both are consistent.
	_ = call(
		a,
		b,
		c,
	)

	// inline comment after the last argument should still cause the
	// closing paren to be moved to its own line.
	_ = call(
		a,
		b,
		c,
	) // trailing

	// nested calls
	_ = outer(inner(
		a,
		b,
	))
}
"""


def test_group_params_is_off_by_default(write, run):
    """Adjacent same-type parameters are only merged with -extra.

    CATCHES: without the rule the parameter list is left completely alone,
    so the identical input must round-trip through the formatter unchanged.
    """
    write("foo.go", GROUP_PARAMS_IN)
    result = run(["foo.go"])
    assert result.out == GROUP_PARAMS_IN
    assert result.returncode == 0
    assert run(["-d", "foo.go"]).stdout == b""


def test_group_params_merges_adjacent_parameters(write, run):
    """-extra=group_params collapses runs of identically typed parameters.

    CATCHES: struct fields are never merged, multi-line parameter lists and
    variadic/mixed kinds are skipped, and a trailing comma is added when the
    merged list still spans lines.
    """
    write("foo.go", GROUP_PARAMS_IN)
    result = run(["-extra=group_params", "foo.go"])
    assert result.out == GROUP_PARAMS_OUT
    assert result.returncode == 0
    assert run(["-extra=group_params", "-d", "foo.go"]).stdout != b""


def test_group_params_strips_redundant_type_parens(write, run):
    """Parenthesised element types are normalised before merging.

    CATCHES: "(int)" and "[]((int))" are reduced to their bare forms so the
    two parameters compare equal and get merged.
    """
    write("parens.go", 'package p\n\nfunc mergeParens(x (int), y int) {}\n\n'
                       'func mergeNestedParens(x []((int)), y []int) {}\n')
    result = run(["-extra=group_params", "parens.go"])
    assert result.out == ('package p\n\nfunc mergeParens(x, y int) {}\n\n'
                          'func mergeNestedParens(x, y []int) {}\n')
    assert result.returncode == 0


def test_clothe_returns_fills_in_named_results(write, run):
    """-extra=clothe_returns turns bare returns into explicit ones.

    CATCHES: every return gains the named result list, but a blank
    identifier result, an unnamed result and a function with no results are
    all left as plain "return".
    """
    write("foo.go", CLOTHE_IN)
    result = run(["-extra=clothe_returns", "foo.go"])
    assert result.out == CLOTHE_OUT
    assert result.returncode == 0
    assert run(["foo.go"]).out == CLOTHE_IN


def test_balance_calls_moves_closing_parens(write, run):
    """-extra=balance_calls puts the closing paren on its own line.

    CATCHES: the rule only fires when the opening paren ends a line, adds a
    trailing comma before the moved paren, and leaves a trailing comment
    after the paren rather than before it.
    """
    write("foo.go", BALANCE_IN)
    result = run(["-extra=balance_calls", "foo.go"])
    assert result.out == BALANCE_OUT
    assert result.returncode == 0
    assert run(["foo.go"]).out == BALANCE_IN
