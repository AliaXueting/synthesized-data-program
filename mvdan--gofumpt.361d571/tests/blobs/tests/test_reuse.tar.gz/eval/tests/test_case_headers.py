"""Black-box tests for joining multi-line switch case headers.

gofumpt collapses a ``case`` header that spans several source lines onto a
single line when the header (measured without its body, plus a trailing
comment if any, plus eight bytes of indentation per enclosing block) fits a
60-byte budget. The measurement goes through the go/format ``Node`` print
path, so these tests also pin that printing behaviour end-to-end.
"""

SHORT_IN = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase foo,\n"
    "\t\tbar:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)
SHORT_OUT = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase foo, bar:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)

# Two switches in one file: expr lengths 17+18 (header fits the budget) and
# 1+35 (one byte over), everything else identical.
BOUNDARY_IN = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase %s,\n"
    "\t\t%s:\n"
    "\t\tbody()\n"
    "\t}\n"
    "\tswitch x {\n"
    "\tcase %s,\n"
    "\t\t%s:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n" % ("a" * 17, "b" * 18, "a", "b" * 35)
)
BOUNDARY_OUT = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase aaaaaaaaaaaaaaaaa, bbbbbbbbbbbbbbbbbb:\n"
    "\t\tbody()\n"
    "\t}\n"
    "\tswitch x {\n"
    "\tcase a,\n"
    "\t\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)

# One block deeper (if inside func): foo/bar still joins, but a 14+14 pair
# that would easily join at the outer level no longer fits.
NESTED_IN = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tif x {\n"
    "\t\tswitch x {\n"
    "\t\tcase foo,\n"
    "\t\t\tbar:\n"
    "\t\t\tbody()\n"
    "\t\t}\n"
    "\t\tswitch x {\n"
    "\t\tcase %s,\n"
    "\t\t\t%s:\n"
    "\t\t\tbody()\n"
    "\t\t}\n"
    "\t}\n"
    "}\n" % ("a" * 14, "b" * 14)
)
NESTED_OUT = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tif x {\n"
    "\t\tswitch x {\n"
    "\t\tcase foo, bar:\n"
    "\t\t\tbody()\n"
    "\t\t}\n"
    "\t\tswitch x {\n"
    "\t\tcase aaaaaaaaaaaaaa,\n"
    "\t\t\tbbbbbbbbbbbbbb:\n"
    "\t\t\tbody()\n"
    "\t\t}\n"
    "\t}\n"
    "}\n"
)

COMMENT_IN = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase foo, // keep\n"
    "\t\tbar:\n"
    "\t\tbody()\n"
    "\t}\n"
    "\tswitch x {\n"
    "\tcase foo,\n"
    "\t\tbar:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)
COMMENT_OUT = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase foo, // keep\n"
    "\t\tbar:\n"
    "\t\tbody()\n"
    "\t}\n"
    "\tswitch x {\n"
    "\tcase foo, bar:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)

# 16+17 header: joins when bare, stays split when a trailing comment after
# the colon pushes the measured size over the budget.
COLON_COMMENT_IN = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase %s,\n"
    "\t\t%s: // c\n"
    "\t\tbody()\n"
    "\t}\n"
    "\tswitch x {\n"
    "\tcase %s,\n"
    "\t\t%s:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n" % ("a" * 16, "b" * 17, "a" * 16, "b" * 17)
)
COLON_COMMENT_OUT = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase aaaaaaaaaaaaaaaa,\n"
    "\t\tbbbbbbbbbbbbbbbbb: // c\n"
    "\t\tbody()\n"
    "\t}\n"
    "\tswitch x {\n"
    "\tcase aaaaaaaaaaaaaaaa, bbbbbbbbbbbbbbbbb:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)

BODILESS_IN = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase foo,\n"
    "\t\tbar:\n"
    "\tcase baz:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)
BODILESS_OUT = (
    "package p\n"
    "\n"
    "func f(x int) {\n"
    "\tswitch x {\n"
    "\tcase foo, bar:\n"
    "\tcase baz:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)

TYPESWITCH_IN = (
    "package p\n"
    "\n"
    "func f(y any) {\n"
    "\tswitch y.(type) {\n"
    "\tcase int,\n"
    "\t\tstring:\n"
    "\t\tbody()\n"
    "\t}\n"
    "\tswitch y.(type) {\n"
    "\tcase aaaaaaaaaaaaaaaaaaaaaaaaaa,\n"
    "\t\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)
TYPESWITCH_OUT = (
    "package p\n"
    "\n"
    "func f(y any) {\n"
    "\tswitch y.(type) {\n"
    "\tcase int, string:\n"
    "\t\tbody()\n"
    "\t}\n"
    "\tswitch y.(type) {\n"
    "\tcase aaaaaaaaaaaaaaaaaaaaaaaaaa,\n"
    "\t\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb:\n"
    "\t\tbody()\n"
    "\t}\n"
    "}\n"
)


def test_short_case_header_is_joined(write, run):
    """A multi-line ``case`` header collapses onto the colon's line.

    CATCHES: the expressions are joined with ", " separators while the
    body stays on its own line after the colon, and the joined result is
    a formatting fixed point.
    """
    write("in.go", SHORT_IN)
    result = run(["in.go"])
    assert result.out == SHORT_OUT
    assert result.stderr == b""
    assert result.returncode == 0
    write("in.go", SHORT_OUT)
    again = run(["-d", "in.go"])
    assert again.stdout == b""
    assert again.returncode == 0


def test_case_header_join_budget_is_sixty_bytes(write, run):
    """A 17+18 byte expression pair joins; a 1+35 byte pair does not.

    CATCHES: the header is measured as printed (without the body) plus
    eight bytes of indentation per enclosing block against a 60-byte
    budget, so a single byte of expression length flips the decision.
    """
    write("in.go", BOUNDARY_IN)
    result = run(["in.go"])
    assert result.out == BOUNDARY_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_deeper_nesting_tightens_the_join_budget(write, run):
    """Each enclosing block steals eight bytes from the join budget.

    CATCHES: inside an extra ``if`` block the same short header still
    joins, but a 14+14 byte pair that would join at the outer level stays
    split because the deeper indentation is counted.
    """
    write("in.go", NESTED_IN)
    result = run(["in.go"])
    assert result.out == NESTED_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_comment_inside_the_header_blocks_the_join(write, run):
    """A line comment between the expressions and the colon blocks joining.

    CATCHES: comments inside the header refuse the collapse regardless of
    length, while the identical header without the comment joins.
    """
    write("in.go", COMMENT_IN)
    result = run(["in.go"])
    assert result.out == COMMENT_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_trailing_comment_after_the_colon_counts_toward_the_budget(write, run):
    """A comment after the colon is measured with the header.

    CATCHES: the same 16+17 header joins when bare but stays split when a
    trailing ``// c`` comment after the colon pushes it over the budget.
    """
    write("in.go", COLON_COMMENT_IN)
    result = run(["in.go"])
    assert result.out == COLON_COMMENT_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_bodiless_case_header_is_joined(write, run):
    """A case clause with no body still has its header joined.

    CATCHES: the collapse only looks at the header, so an empty case
    clause keeps its (now joined) header and empty body.
    """
    write("in.go", BODILESS_IN)
    result = run(["in.go"])
    assert result.out == BODILESS_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_type_switch_case_headers_follow_the_same_rule(write, run):
    """Type-switch case headers join under the same budget.

    CATCHES: ``switch y.(type)`` clauses collapse exactly like expression
    switch clauses: the short header joins while the long one keeps its
    line break.
    """
    write("in.go", TYPESWITCH_IN)
    result = run(["in.go"])
    assert result.out == TYPESWITCH_OUT
    assert result.stderr == b""
    assert result.returncode == 0
    write("in.go", TYPESWITCH_OUT)
    again = run(["-d", "in.go"])
    assert again.stdout == b""
    assert again.returncode == 0
