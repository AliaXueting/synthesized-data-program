"""Black-box tests for doc comment normalisation.

gofumpt inherits gofmt's Go 1.19+ doc comment reformatting: a column-1
comment abutting a declaration is parsed (``go/doc/comment``) and reprinted
(``go/doc/comment/print.go``) in canonical form. These tests pin headings,
lists, links, quotes and block-comment round-trips, all recorded from the
reference binary.
"""

import pytest

HEADINGS_IN = """package p

// Docs for f.
//
// Old Heading Style
//
// After.
func f() {}
"""

HEADINGS_OUT = """package p

// Docs for f.
//
// # Old Heading Style
//
// After.
func f() {}
"""

BLOCK_HEADINGS_IN = """package p

/*
Para one.

Old Heading

Para two after.
*/
func f() {}
"""

BLOCK_HEADINGS_OUT = """package p

/*
Para one.

# Old Heading

Para two after.
*/
func f() {}
"""

HASH_SPACING_IN = """package p

// Docs for g.
//
// #   Spaced heading
//
// After.
func g() {}
"""

HASH_SPACING_OUT = """package p

// Docs for g.
//
// # Spaced heading
//
// After.
func g() {}
"""

HASH_NOT_HEADINGS_IN = """package p

// #NoSpace heading
//
// #
func f() {}
"""

HASH_NOT_HEADINGS_OUT = """package p

// #NoSpace heading
//
// #
func f() {}
"""

HEADING_AFTER_CODE_IN = """package p

// Docs.
//
//	code
// # Heading after code
//
// after
func g() {}
"""

HEADING_AFTER_CODE_OUT = """package p

// Docs.
//
//	code
//
// # Heading after code
//
// after
func g() {}
"""

INLINE_HASH_IN = """package p

// Para
// # Not a heading
//
// After.
func g() {}
"""

HEADING_LINK_IN = """package p

// # Heading with [math.Sin] link
//
// body
func q() {}
"""

BULLETS_IN = """package p

// Bullets:
//   * one
//   + two
//   - three
//   • four
func f() {}

// Deep:
//    - four space indent
//	- tab indent marker
func h() {}
"""

BULLETS_OUT = """package p

// Bullets:
//   - one
//   - two
//   - three
//   - four
func f() {}

// Deep:
//   - four space indent
//   - tab indent marker
func h() {}
"""

NUMBERED_IN = """package p

// Numbered:
//  1) first
//  2) second
//  10. tenth
func g() {}

// Nums:
//  01. zero one
//  2. two
func q() {}
"""

NUMBERED_OUT = """package p

// Numbered:
//  1. first
//  2. second
//  10. tenth
func g() {}

// Nums:
//  01. zero one
//  2. two
func q() {}
"""

LOOSE_IN = """package p

// Loose:
//   - a
//
//   - b
func h() {}
"""

LOOSE_OUT = """package p

// Loose:
//
//   - a
//
//   - b
func h() {}
"""

CONTINUATION_IN = """package p

// Items:
//   - first item
//     continues here
//   - second item
//
//     second paragraph of second item
func f() {}
"""

CONTINUATION_OUT = """package p

// Items:
//
//   - first item
//     continues here
//
//   - second item
//
//     second paragraph of second item
func f() {}
"""

CODE_LIST_MERGE_IN = """package p

// Mixed code:
//
//	code block
//	here
//
//   - item after code
func g() {}
"""

CODE_LIST_MERGE_OUT = """package p

// Mixed code:
//
//		code block
//		here
//
//	  - item after code
func g() {}
"""

LINK_ORDER_IN = """package p

// See [the docs] and [unused] for more.
//
// [the docs]: https://example.com/docs
// [unused]: https://example.com/other
func f() {}
"""

LINK_ORDER_OUT = """package p

// See [the docs] and [unused] for more.
//
// [the docs]: https://example.com/docs
// [unused]: https://example.com/other
func f() {}
"""

LINK_MOVE_IN = """package p

// Mid [link] here.
//
// [link]: https://example.com/x
//
// Trailing paragraph.
func g() {}
"""

LINK_MOVE_OUT = """package p

// Mid [link] here.
//
// Trailing paragraph.
//
// [link]: https://example.com/x
func g() {}
"""

BAD_LINKS_IN = "package p\n\n// See [x] and [y].\n//\n" \
    "// [x]: HTTPS://example.com\n// [y]:    https://example.com/spaced   \n" \
    "func f() {}\n"

BAD_LINKS_OUT = "package p\n\n// See [x] and [y].\n//\n" \
    "// [x]: HTTPS://example.com\n// [y]:    https://example.com/spaced\n" \
    "func f() {}\n"

LINK_ONLY_IN = """package p

// [x]: https://example.com/only
func g() {}
"""

LINK_ONLY_OUT = """package p

//
// [x]: https://example.com/only
func g() {}
"""

BLOCK_DOCS_IN = """package p

/*
Docs in a block comment.

Old Heading

  * bullet one
  * bullet two
*/
func f() {}

/* single line stays */
func g() {}

/*
 * Starred
 * block
 */
func h() {}
"""

BLOCK_DOCS_OUT = """package p

/*
Docs in a block comment.

Old Heading

  - bullet one
  - bullet two
*/
func f() {}

/* single line stays */
func g() {}

/*
 * Starred
 * block
 */
func h() {}
"""

FIELD_DOCS_IN = """package p

type T struct {
// Docs for F abutting an identifier
//   * bullet stays
F int
}

type U struct {
// Docs for G abutting a keyword
//   * bullet goes
G int
}
"""

FIELD_DOCS_OUT = """package p

type T struct {
	// Docs for F abutting an identifier
	//   * bullet stays
	F int
}

type U struct {
	// Docs for G abutting a keyword
	//   * bullet goes
	G int
}
"""

DETACHED_IN = """package p

// Floating:
//   * bullet
//  1) numbered

// Real:
//   * bullet
func f() {}
"""

DETACHED_OUT = """package p

// Floating:
//   * bullet
//  1) numbered

// Real:
//   - bullet
func f() {}
"""

DEEP_CONTINUATION_IN = """package p

// Para line one
//     continued with deep indent
func f() {}
"""

DEEP_CONTINUATION_OUT = """package p

// Para line one
//
//	continued with deep indent
func f() {}
"""

BLANK_COLLAPSE_IN = """package p

// Para one.


// Para two after many blanks.
func g() {}
"""

BLANK_COLLAPSE_OUT = """package p

// Para one.

// Para two after many blanks.
func g() {}
"""

WHOLE_LIST_IN = """package p

//   - first at start
//   - second
func h() {}
"""

WHOLE_LIST_OUT = """package p

// - first at start
// - second
func h() {}
"""

WHOLE_NUMBERED_IN = """package p

//  1. one
//  2. two
func q() {}
"""

WHOLE_NUMBERED_OUT = """package p

// 1. one
// 2. two
func q() {}
"""

VERBATIM_LINKS_IN = """package p

// Links to [math.Sin], [math], [*math.Sin], [encoding/json.Marshal],
// [Foo.Bar], [undefined], and https://example.com/auto plus
// [math.Cos] again.
func f() {}
"""

QUOTES_IN = """package p

// Quotes ``x'' and ``y'' stay?
func q() {}
"""

QUOTES_OUT = """package p

// Quotes “x” and “y” stay?
func q() {}
"""

DIRECTIVES_IN = """package p

// Docs here.
//go:generate foo
func h() {}

// Text:
//   - item
//go:generate bar
func i() {}
"""

DIRECTIVES_OUT = """package p

// Docs here.
//
//go:generate foo
func h() {}

// Text:
//   - item
//
//go:generate bar
func i() {}
"""

CODE_JOINS_ITEM_IN = """package p

// Text:
//   - item
//	code after item
func f() {}
"""

CODE_JOINS_ITEM_OUT = """package p

// Text:
//   - item
//     code after item
func f() {}
"""


@pytest.mark.parametrize("source,expected", [
    (HEADINGS_IN, HEADINGS_OUT),
    (BLOCK_HEADINGS_IN, BLOCK_HEADINGS_OUT),
])
def test_old_style_headings_are_promoted_to_hash(write, run, source, expected):
    """A lone capitalised line between blanks becomes a "# " heading.

    CATCHES: both // and /* */ doc comments reformat through the same
    parser, so "Old Heading Style" is reprinted as "# Old Heading Style".
    """
    write("headings.go", source)
    result = run(["headings.go"])
    assert result.out == expected
    assert result.returncode == 0


@pytest.mark.parametrize("source,expected", [
    (HASH_SPACING_IN, HASH_SPACING_OUT),
    (HASH_NOT_HEADINGS_IN, HASH_NOT_HEADINGS_OUT),
])
def test_hash_heading_spacing_is_normalised(write, run, source, expected):
    """Heading inner spacing collapses, but "#" needs a space to qualify.

    CATCHES: "#   Spaced heading  " prints as "# Spaced heading" while
    "#NoSpace heading" and a bare "#" are plain paragraph text and survive
    untouched apart from trailing-space trimming.
    """
    write("hash.go", source)
    result = run(["hash.go"])
    assert result.out == expected
    assert result.returncode == 0


def test_heading_after_code_gets_a_blank_line(write, run):
    """A heading directly after a code block gains a separating blank.

    CATCHES: the blank // line is inserted between the tab-indented code
    block and the "# Heading after code" line even though the input had
    none, because every non-list block needs a blank line before it.
    """
    write("codehead.go", HEADING_AFTER_CODE_IN)
    result = run(["codehead.go"])
    assert result.out == HEADING_AFTER_CODE_OUT
    assert result.returncode == 0


def test_inline_hash_line_is_not_a_heading(write, run):
    """A "# ..." line glued to prose stays part of the paragraph.

    CATCHES: headings must sit on their own span between blank lines, so
    "// Para" followed immediately by "// # Not a heading" is reprinted
    unchanged instead of being promoted.
    """
    write("inline.go", INLINE_HASH_IN)
    result = run(["inline.go"])
    assert result.out == INLINE_HASH_IN
    assert result.returncode == 0


def test_heading_text_is_not_link_parsed(write, run):
    """Doc links inside heading text stay literal.

    CATCHES: only paragraph and list text go through link parsing, so the
    "[math.Sin]" inside "# Heading with [math.Sin] link" is kept verbatim
    rather than being resolved or respaced.
    """
    write("headlink.go", HEADING_LINK_IN)
    result = run(["headlink.go"])
    assert result.out == HEADING_LINK_IN
    assert result.returncode == 0


def test_bullet_markers_and_indents_normalise(write, run):
    """*, +, • and over-indented markers all become "  - ".

    CATCHES: every bullet flavour is reprinted as two spaces plus a dash,
    and a four-space or tab-indented marker line is pulled back to the same
    two-space form.
    """
    write("bullets.go", BULLETS_IN)
    result = run(["bullets.go"])
    assert result.out == BULLETS_OUT
    assert result.returncode == 0


def test_numbered_markers_normalise_to_dots(write, run):
    """")" markers become "." and numbers are kept verbatim, unrenumbered.

    CATCHES: "1) first" turns into "1. first" while multi-digit and
    zero-padded numbers like "10." and "01." pass through unchanged, and
    the two-space indent is used for every item.
    """
    write("numbered.go", NUMBERED_IN)
    result = run(["numbered.go"])
    assert result.out == NUMBERED_OUT
    assert result.returncode == 0


def test_loose_lists_gain_blank_separators(write, run):
    """A list containing a blank line becomes loose and gets separated.

    CATCHES: the blank line between items forces blank lines between every
    item AND a blank // line between the intro paragraph and the list,
    which the tight input did not have.
    """
    write("loose.go", LOOSE_IN)
    result = run(["loose.go"])
    assert result.out == LOOSE_OUT
    assert result.returncode == 0


def test_list_continuations_use_four_space_indents(write, run):
    """Item continuation lines and later paragraphs keep four-space indent.

    CATCHES: a wrapped item line prints with four spaces after the marker
    line's text, a second paragraph of an item is separated by a blank and
    also indented four spaces, and the loose list gains a blank after the
    intro paragraph.
    """
    write("continuation.go", CONTINUATION_IN)
    result = run(["continuation.go"])
    assert result.out == CONTINUATION_OUT
    assert result.returncode == 0


def test_code_block_and_list_merge_into_one_code_block(write, run):
    """A list after a code block is absorbed as more code, then indented.

    CATCHES: both indented spans form ONE code block, so the code lines
    gain a second leading tab and the "- item after code" line is printed
    with a tab plus two spaces rather than as a normalised list item.
    """
    write("merge.go", CODE_LIST_MERGE_IN)
    result = run(["merge.go"])
    assert result.out == CODE_LIST_MERGE_OUT
    assert result.returncode == 0


def test_used_link_definitions_precede_unused_ones(write, run):
    """Referenced definitions are printed before unreferenced ones.

    CATCHES: both definitions survive at the end of the comment, but the
    used "[the docs]" is emitted first and the unused "[unused]" second,
    each in "[text]: url" form.
    """
    write("order.go", LINK_ORDER_IN)
    result = run(["order.go"])
    assert result.out == LINK_ORDER_OUT
    assert result.returncode == 0


def test_link_definitions_are_moved_after_trailing_text(write, run):
    """A definition block sandwiched mid-comment is relocated to the end.

    CATCHES: the "[link]: ..." lines vanish from between the paragraphs and
    reappear after the trailing paragraph, keeping the link next to where
    it can be pruned.
    """
    write("move.go", LINK_MOVE_IN)
    result = run(["move.go"])
    assert result.out == LINK_MOVE_OUT
    assert result.returncode == 0


def test_malformed_link_definitions_stay_in_the_paragraph(write, run):
    """Definitions with a bad scheme or spacing are plain text.

    CATCHES: "HTTPS://example.com" (uppercase scheme) fails the scheme
    check, and because one line of the paragraph is not a definition the
    neighbouring well-formed "[y]" line is kept as text too; only the
    trailing spaces of each line are trimmed.
    """
    write("badlinks.go", BAD_LINKS_IN)
    result = run(["badlinks.go"])
    assert result.out == BAD_LINKS_OUT
    assert result.returncode == 0


def test_link_only_doc_comment_gains_a_leading_blank(write, run):
    """A comment that is only a link definition keeps a leading blank line.

    CATCHES: the paragraph block disappears into the link table, so the
    reprinted comment starts with an empty "//" separator line before the
    "[x]: ..." definition instead of dropping it.
    """
    write("linkonly.go", LINK_ONLY_IN)
    result = run(["linkonly.go"])
    assert result.out == LINK_ONLY_OUT
    assert result.returncode == 0


def test_block_comment_doc_reformatting(write, run):
    """/* */ docs reformat, but single-line and starred ones do not.

    CATCHES: bullets inside a multi-line block comment become dashes, a
    one-line /* */ comment is returned untouched, and an old-style
    all-starred block is left alone because reformatting it would only
    make it worse.
    """
    write("block.go", BLOCK_DOCS_IN)
    result = run(["block.go"])
    assert result.out == BLOCK_DOCS_OUT
    assert result.returncode == 0


def test_struct_field_docs_are_indented_but_not_reformatted(write, run):
    """Column-1 field docs re-indent to the field yet keep their bullets.

    CATCHES: the doc comment rewriter only fires when the comment abuts a
    column-1 token, so inside a struct the "*" bullets survive verbatim
    even though gofumpt re-indents the comment lines to the field's tab.
    """
    write("fields.go", FIELD_DOCS_IN)
    result = run(["fields.go"])
    assert result.out == FIELD_DOCS_OUT
    assert result.returncode == 0


def test_detached_comment_groups_are_not_reformatted(write, run):
    """Only the comment group abutting the declaration is reformatted.

    CATCHES: the blank line between the two groups detaches the first one
    from any declaration, so its "*" and "1)" markers survive verbatim
    while the identical markers in the abutting group become "-" and ".".
    """
    write("detached.go", DETACHED_IN)
    result = run(["detached.go"])
    assert result.out == DETACHED_OUT
    assert result.returncode == 0


def test_indented_continuation_becomes_a_code_block(write, run):
    """A deeply indented prose continuation turns into tab-indented code.

    CATCHES: the five-space "continued with deep indent" line no longer
    belongs to the paragraph; it is reprinted as a code block with a blank
    // separator and a leading tab.
    """
    write("deepcont.go", DEEP_CONTINUATION_IN)
    result = run(["deepcont.go"])
    assert result.out == DEEP_CONTINUATION_OUT
    assert result.returncode == 0


def test_extra_blank_lines_between_paragraphs_collapse(write, run):
    """Runs of blank comment lines shrink to a single blank line.

    CATCHES: the two empty "//" lines between the paragraphs are reprinted
    as exactly one, matching the one-blank-per-block canonical layout.
    """
    write("blanks.go", BLANK_COLLAPSE_IN)
    result = run(["blanks.go"])
    assert result.out == BLANK_COLLAPSE_OUT
    assert result.returncode == 0


@pytest.mark.parametrize("source,expected", [
    (WHOLE_LIST_IN, WHOLE_LIST_OUT),
    (WHOLE_NUMBERED_IN, WHOLE_NUMBERED_OUT),
])
def test_list_spanning_the_whole_comment_loses_its_indent(write, run, source,
                                                          expected):
    """A list that is the entire comment is demoted to plain text.

    CATCHES: the common indent of every line is stripped before span
    parsing, so markers landing at column zero no longer count as a list;
    the lines keep their dashes but lose the two-space indent.
    """
    write("whole.go", source)
    result = run(["whole.go"])
    assert result.out == expected
    assert result.returncode == 0


def test_doc_links_urls_and_brackets_survive_verbatim(write, run):
    """Doc links, auto URLs and unknown brackets all round-trip unchanged.

    CATCHES: [math.Sin], [math], [*math.Sin] and the std import path form
    are recognised doc links yet reprint as the same text, while [Foo.Bar]
    and [undefined] are not links at all; a bare URL is auto-linked and
    also prints identically.
    """
    write("verbatim.go", VERBATIM_LINKS_IN)
    result = run(["verbatim.go"])
    assert result.out == VERBATIM_LINKS_IN
    assert result.returncode == 0


def test_smart_quotes_replace_ascii_quotes(write, run):
    """Double-backtick/prime pairs become typographic quotes.

    CATCHES: ``x'' and ``y'' are rewritten to U+201C/U+201D in the
    reprinted doc comment while the surrounding prose is untouched.
    """
    write("quotes.go", QUOTES_IN)
    result = run(["quotes.go"])
    assert result.out == QUOTES_OUT
    assert result.returncode == 0


def test_directives_move_to_the_end_of_doc_comments(write, run):
    """Comment directives are pulled out and re-emitted after a blank //.

    CATCHES: "//go:generate ..." leaves the middle of the doc comment and
    is appended at the end behind an empty "//" separator line, both for a
    prose-only comment and for one holding a list.
    """
    write("directives.go", DIRECTIVES_IN)
    result = run(["directives.go"])
    assert result.out == DIRECTIVES_OUT
    assert result.returncode == 0


def test_code_line_after_a_list_item_joins_the_item(write, run):
    """A tab-indented line under a list item becomes item text, not code.

    CATCHES: the span belongs to the list, so "code after item" is trimmed
    and printed as a four-space continuation of the "- item" entry rather
    than as a tab-indented code block.
    """
    write("joins.go", CODE_JOINS_ITEM_IN)
    result = run(["joins.go"])
    assert result.out == CODE_JOINS_ITEM_OUT
    assert result.returncode == 0
