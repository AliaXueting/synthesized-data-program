"""Black-box tests for composite-literal type elision during simplification.

The always-on simplify pass (``format/simplify.go``) drops the type of an
inner composite literal when it structurally equals the outer literal's
element (or key) type, using the reflective ``match`` helper from
``format/rewrite.go``. These tests pin which type shapes compare equal and
which do not, through the CLI only.
"""

STRUCT_IN = "package p\n\nvar _ = []struct{ X int }{struct{ X int }{X: 1}}\n"
STRUCT_OUT = "package p\n\nvar _ = []struct{ X int }{{X: 1}}\n"

ARRAYLEN_IN = (
    "package p\n"
    "\n"
    "var _ = [][5]int{[5]int{1, 2, 3, 4, 5}}\n"
    "\n"
    "var _ = [][]int{[5]int{1, 2, 3, 4, 5}}\n"
)
ARRAYLEN_OUT = (
    "package p\n"
    "\n"
    "var _ = [][5]int{{1, 2, 3, 4, 5}}\n"
    "\n"
    "var _ = [][]int{[5]int{1, 2, 3, 4, 5}}\n"
)

MAPVAL_IN = (
    'package p\n\nvar _ = map[string]map[string]int{"a": map[string]int{"b": 1}}\n'
)
MAPVAL_OUT = 'package p\n\nvar _ = map[string]map[string]int{"a": {"b": 1}}\n'

MAPKEY_IN = (
    'package p\n\ntype Point struct{ X, Y int }\n\n'
    'var _ = map[Point]string{Point{1, 2}: "a"}\n'
)
MAPKEY_OUT = (
    'package p\n\ntype Point struct{ X, Y int }\n\n'
    'var _ = map[Point]string{{1, 2}: "a"}\n'
)

PTR_IN = (
    "package p\n"
    "\n"
    "type T struct{ X int }\n"
    "\n"
    "type U struct{ X int }\n"
    "\n"
    "var _ = []*T{&T{X: 1}}\n"
    "\n"
    "var _ = []*T{&U{X: 1}}\n"
)
PTR_OUT = (
    "package p\n"
    "\n"
    "type T struct{ X int }\n"
    "\n"
    "type U struct{ X int }\n"
    "\n"
    "var _ = []*T{{X: 1}}\n"
    "\n"
    "var _ = []*T{&U{X: 1}}\n"
)

PTR_STRUCT_IN = (
    "package p\n\nvar _ = []*struct{ X int }{&struct{ X int }{X: 1}}\n"
)
PTR_STRUCT_OUT = "package p\n\nvar _ = []*struct{ X int }{{X: 1}}\n"

GENERIC_IN = (
    "package p\n\ntype List[T any] struct{ v []T }\n\n"
    "var _ = []List[int]{List[int]{v: nil}}\n"
)
GENERIC_OUT = (
    "package p\n\ntype List[T any] struct{ v []T }\n\n"
    "var _ = []List[int]{{v: nil}}\n"
)

KIND_IN = (
    'package p\n\nvar _ = []any{[]string{"a"}}\n\nvar _ = [][]string{[]string{"a"}}\n'
)
KIND_OUT = 'package p\n\nvar _ = []any{[]string{"a"}}\n\nvar _ = [][]string{{"a"}}\n'

FIELD_COUNT_IN = (
    "package p\n"
    "\n"
    "var _ = []struct{ X int }{struct{ X int }{X: 1}}\n"
    "\n"
    "var _ = []struct{ X, Y int }{struct{ X int }{X: 1}}\n"
)
FIELD_COUNT_OUT = (
    "package p\n"
    "\n"
    "var _ = []struct{ X int }{{X: 1}}\n"
    "\n"
    "var _ = []struct{ X, Y int }{struct{ X int }{X: 1}}\n"
)

FIELD_NAME_IN = (
    "package p\n"
    "\n"
    "var _ = []struct{ X int }{struct{ X int }{X: 1}}\n"
    "\n"
    "var _ = []struct{ X int }{struct{ Y int }{Y: 1}}\n"
)
FIELD_NAME_OUT = (
    "package p\n"
    "\n"
    "var _ = []struct{ X int }{{X: 1}}\n"
    "\n"
    "var _ = []struct{ X int }{struct{ Y int }{Y: 1}}\n"
)

NESTED_STRUCT_IN = (
    "package p\n\nvar _ = [][]struct{ X int }{[]struct{ X int }{{X: 1}}}\n"
)
NESTED_STRUCT_OUT = "package p\n\nvar _ = [][]struct{ X int }{{{X: 1}}}\n"

RECURSIVE_IN = "package p\n\nvar _ = [][][]int{[][]int{[]int{1}}}\n"
RECURSIVE_OUT = "package p\n\nvar _ = [][][]int{{{1}}}\n"

KV_ARRAY_IN = "package p\n\nvar _ = [2][2]int{0: [2]int{1, 2}}\n"
KV_ARRAY_OUT = "package p\n\nvar _ = [2][2]int{0: {1, 2}}\n"

MAP_STRUCT_IN = (
    'package p\n\nvar _ = map[string]struct{ X int }{"a": struct{ X int }{X: 1}}\n'
)
MAP_STRUCT_OUT = (
    'package p\n\nvar _ = map[string]struct{ X int }{"a": {X: 1}}\n'
)

TAG_DIFF_IN = (
    "package p\n\nvar _ = []struct{ X int }{struct{ X int `json:\"x\"` }{X: 1}}\n"
)
TAG_DIFF_OUT = (
    "package p\n\nvar _ = []struct{ X int }{struct {\n\tX int `json:\"x\"`\n}{X: 1}}\n"
)
TAG_SAME_IN = (
    "package p\n\n"
    "var _ = []struct{ X int `json:\"x\"` }{struct{ X int `json:\"x\"` }{X: 1}}\n"
)
TAG_SAME_OUT = (
    "package p\n\nvar _ = []struct {\n\tX int `json:\"x\"`\n}{{X: 1}}\n"
)

PAREN_IN = (
    "package p\n\ntype T struct{ X int }\n\n"
    "var _ = []T{T{X: 1}}\n\nvar _ = []T{(T{X: 1})}\n"
)
PAREN_OUT = (
    "package p\n\ntype T struct{ X int }\n\n"
    "var _ = []T{{X: 1}}\n\nvar _ = []T{(T{X: 1})}\n"
)

ELLIPSIS_IN = "package p\n\nvar _ = [...][5]int{[5]int{1, 2, 3, 4, 5}}\n"
ELLIPSIS_OUT = "package p\n\nvar _ = [...][5]int{{1, 2, 3, 4, 5}}\n"


def test_struct_type_elision(write, run):
    """An inner struct literal drops its type when it equals the element type.

    CATCHES: the elision is decided by a recursive structural comparison of
    the two struct types (field list, names, types), not by the outer type
    being named; an anonymous struct must match field-for-field.
    """
    write("in.go", STRUCT_IN)
    result = run(["in.go"])
    assert result.out == STRUCT_OUT
    assert result.stderr == b""
    assert result.returncode == 0
    write("in.go", STRUCT_OUT)
    assert run(["-d", "in.go"]).stdout == b""


def test_array_length_elision_and_mismatch(write, run):
    """``[5]int`` elides against ``[][5]int`` but not against ``[]int``.

    CATCHES: array length expressions take part in the type comparison, so
    an inner ``[5]int`` matches an element type of ``[5]int`` while the same
    literal under a ``[]int`` element type keeps its type.
    """
    write("in.go", ARRAYLEN_IN)
    result = run(["in.go"])
    assert result.out == ARRAYLEN_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_map_value_type_elision(write, run):
    """Nested map values lose their redundant map type.

    CATCHES: the value type of a map is elided like a slice element type,
    so ``map[string]int{...}`` inside a ``map[string]map[string]int``
    collapses to a bare braced literal.
    """
    write("in.go", MAPVAL_IN)
    result = run(["in.go"])
    assert result.out == MAPVAL_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_map_key_type_elision(write, run):
    """Composite-literal map keys drop their redundant type too.

    CATCHES: simplification runs over map keys as well as values, turning
    ``Point{1, 2}: "a"`` into a bare ``{1, 2}`` key while the outer key
    type stays ``Point``.
    """
    write("in.go", MAPKEY_IN)
    result = run(["in.go"])
    assert result.out == MAPKEY_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_pointer_elements_drop_their_address_and_type(write, run):
    """``&T{...}`` in a ``[]*T`` loses both the ``&`` and the ``T``.

    CATCHES: for pointer element types the address-of and the inner type
    are dropped together, but only when the pointed-to type matches the
    element type; ``&U{...}`` keeps its address and type.
    """
    write("in.go", PTR_IN)
    result = run(["in.go"])
    assert result.out == PTR_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_pointer_struct_type_elision(write, run):
    """``&struct{...}{...}`` collapses inside a ``[]*struct{...}``.

    CATCHES: the pointer rule and the structural struct comparison compose:
    an anonymous struct behind an ``&`` is compared field-by-field with the
    pointed-to element type before both are stripped.
    """
    write("in.go", PTR_STRUCT_IN)
    result = run(["in.go"])
    assert result.out == PTR_STRUCT_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_generic_instantiation_elision(write, run):
    """``List[int]{...}`` elides inside a ``[]List[int]``.

    CATCHES: generic instantiations are compared structurally as index
    expressions, so a matching type argument list lets the inner
    instantiation be dropped.
    """
    write("in.go", GENERIC_IN)
    result = run(["in.go"])
    assert result.out == GENERIC_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_element_kind_mismatch_keeps_the_type(write, run):
    """An ``any`` element keeps its slice literal, a slice element does not.

    CATCHES: when the inner literal's type node has a different kind than
    the outer element type (``any`` vs ``[]string``) the comparison fails
    before any recursion, so the type survives while the same literal one
    level down is elided.
    """
    write("in.go", KIND_IN)
    result = run(["in.go"])
    assert result.out == KIND_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_struct_field_count_mismatch_keeps_the_type(write, run):
    """A struct with fewer fields does not match a wider element type.

    CATCHES: the field lists are compared element-by-element including
    their length, so ``struct{ X int }`` is not elided under an element
    type of ``struct{ X, Y int }`` even though its single field matches.
    """
    write("in.go", FIELD_COUNT_IN)
    result = run(["in.go"])
    assert result.out == FIELD_COUNT_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_struct_field_name_mismatch_keeps_the_type(write, run):
    """A renamed field keeps the inner literal's type.

    CATCHES: field names are compared identifier by identifier, so
    ``struct{ Y int }`` does not match an element type of
    ``struct{ X int }`` and the inner type is kept.
    """
    write("in.go", FIELD_NAME_IN)
    result = run(["in.go"])
    assert result.out == FIELD_NAME_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_nested_slice_of_struct_elision(write, run):
    """Elision composes through nested slices of anonymous structs.

    CATCHES: the inner ``[]struct{ X int }`` element loses its type after
    its own elements were elided, all within a single formatting pass,
    yielding a triple brace.
    """
    write("in.go", NESTED_STRUCT_IN)
    result = run(["in.go"])
    assert result.out == NESTED_STRUCT_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_elision_applies_innermost_first(write, run):
    """A three-deep literal chain collapses to ``{{{1}}}`` in one pass.

    CATCHES: each element is walked and simplified before its parent's
    type is compared, so the whole chain of ``[][][]int{[][]int{[]int{1}}}``
    collapses at once rather than one level per run.
    """
    write("in.go", RECURSIVE_IN)
    result = run(["in.go"])
    assert result.out == RECURSIVE_OUT
    assert result.stderr == b""
    assert result.returncode == 0
    write("in.go", RECURSIVE_OUT)
    assert run(["-d", "in.go"]).stdout == b""


def test_indexed_array_elements_elide(write, run):
    """Keyed array elements get their value types elided.

    CATCHES: for ``{0: [2]int{1, 2}}`` the keyed value is simplified like
    a positional element, dropping the redundant ``[2]int`` while keeping
    the index key.
    """
    write("in.go", KV_ARRAY_IN)
    result = run(["in.go"])
    assert result.out == KV_ARRAY_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_map_value_struct_elision(write, run):
    """Struct values inside maps elide their anonymous struct type.

    CATCHES: the keyed map value is compared against the map's value type
    structurally, so ``"a": struct{ X int }{X: 1}`` becomes a bare
    braced literal.
    """
    write("in.go", MAP_STRUCT_IN)
    result = run(["in.go"])
    assert result.out == MAP_STRUCT_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_struct_tags_participate_in_the_comparison(write, run):
    """Struct tags count during matching and change how types print.

    CATCHES: a tagged inner struct does not match an untagged element
    type, while identical tags on both sides still elide; either way a
    struct type containing a tag is printed across multiple lines.
    """
    write("tag_diff.go", TAG_DIFF_IN)
    write("tag_same.go", TAG_SAME_IN)
    diff = run(["tag_diff.go"])
    assert diff.out == TAG_DIFF_OUT
    assert diff.stderr == b""
    assert diff.returncode == 0
    same = run(["tag_same.go"])
    assert same.out == TAG_SAME_OUT
    assert same.stderr == b""
    assert same.returncode == 0


def test_parenthesised_literal_types_are_not_elided(write, run):
    """A parenthesised composite literal keeps its type.

    CATCHES: ``(T{X: 1})`` is a parenthesised expression rather than a
    composite literal node, so its inner type is never elided even though
    the unparenthesised sibling on the line above is.
    """
    write("in.go", PAREN_IN)
    result = run(["in.go"])
    assert result.out == PAREN_OUT
    assert result.stderr == b""
    assert result.returncode == 0


def test_ellipsis_array_length_elision(write, run):
    """``[...]`` on the outer array survives and the inner type elides.

    CATCHES: the ellipsis length belongs to the outer literal only, and the
    inner ``[5]int`` still matches the ``[5]int`` element type, so the
    output keeps ``[...]`` while dropping the inner type.
    """
    write("in.go", ELLIPSIS_IN)
    result = run(["in.go"])
    assert result.out == ELLIPSIS_OUT
    assert result.stderr == b""
    assert result.returncode == 0
