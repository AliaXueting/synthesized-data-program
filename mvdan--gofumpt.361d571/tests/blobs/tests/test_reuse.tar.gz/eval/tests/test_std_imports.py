"""Black-box tests for std/non-std import grouping.

Mined from the repository's native ``testdata/script/std-imports.txtar``
testscript. The module path in go.mod decides which imports count as
"local", so every case here runs inside a module.
"""

GO_MOD = "module nodomainmod/mod1\n\ngo 1.16\n"

GROUPING_IN = """package p

import (
	"io"
	"io/ioutil" // if the user keeps them in the top group, obey that
	_ "io/ioutil"

	_ "image/png"

	"bufio" // the above is for a side effect; this one has a comment
)

import (
	"os"

	"foo.local/one"

	bytes_ "bytes"

	"io"
)

import (
	"foo.local/two"

	"fmt"
)
"""

GROUPING_OUT = """package p

import (
	"io"
	"io/ioutil" // if the user keeps them in the top group, obey that
	_ "io/ioutil"

	_ "image/png"

	"bufio" // the above is for a side effect; this one has a comment
)

import (
	"io"
	"os"

	"foo.local/one"

	bytes_ "bytes"
)

import (
	"fmt"

	"foo.local/two"
)
"""

SPLIT_IN = """package p

// We need to split std vs non-std in this case too.
import (
	"foo.local"
	"foo.local/three"
	math "math"
)

// This used to crash gofumpt, as there's no space to insert an extra newline.
import (
"std"
"non.std/pkg"
)

// Moving std imports up must not leave empty lines behind; see issue 225.
import (
	"path/filepath"
	"time"
	"github.com/tinkerbell/tink/pkg/apis/core/v1alpha1"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/yaml"
)

// Never move an import with comments, as they would be left behind.
import (
	"foo.local/pkg"
	"os" // why we need os
	"strings"
)

// Separate the groups of unindented imports too.
import (
"bytes"
"foo.local/bar"
)
"""

SPLIT_OUT = """package p

// We need to split std vs non-std in this case too.
import (
	math "math"

	"foo.local"
	"foo.local/three"
)

// This used to crash gofumpt, as there's no space to insert an extra newline.
import (
	"std"

	"non.std/pkg"
)

// Moving std imports up must not leave empty lines behind; see issue 225.
import (
	"path/filepath"
	"time"

	"github.com/tinkerbell/tink/pkg/apis/core/v1alpha1"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/yaml"
)

// Never move an import with comments, as they would be left behind.
import (
	"strings"

	"foo.local/pkg"
	"os" // why we need os
)

// Separate the groups of unindented imports too.
import (
	"bytes"

	"foo.local/bar"
)
"""

COMMENTS_IN = """package p

//moving "os" up keeps this comment spaced
import (
	"aa.dev/q"
	"os"
)

import ("os" // sorted onto the closing parenthesis
	b "bb.dev/q")

import (
	// documents the import sorted below it
	"os"
	b "bb.dev/q"
)
"""

COMMENTS_OUT = """package p

// moving "os" up keeps this comment spaced
import (
	"os"

	"aa.dev/q"
)

import (
	"os"

	b "bb.dev/q"
) // sorted onto the closing parenthesis

import (
	"os"
	// documents the import sorted below it
	b "bb.dev/q"
)
"""


def test_std_imports_are_lifted_above_third_party(write, run):
    """std imports move to the top of each group without breaking the rest.

    CATCHES: a blank line separates the lifted std imports from the rest,
    and an import that already sits in the top group with a comment is left
    exactly where the user put it.
    """
    write("go.mod", GO_MOD)
    write("foo.go", GROUPING_IN)
    result = run(["foo.go"])
    assert result.out == GROUPING_OUT
    assert result.returncode == 0


def test_std_imports_split_and_crash_regression(write, run):
    """Mixed groups are split, and unindented imports no longer crash.

    CATCHES: the historical crash case (an unindented import block with no
    room to insert a newline) must still produce a blank line between the
    std and non-std groups.
    """
    write("go.mod", GO_MOD)
    write("foo.go", SPLIT_IN)
    result = run(["foo.go"])
    assert result.out == SPLIT_OUT
    assert result.returncode == 0


def test_std_imports_with_comments(write, run):
    """Comments attached to imports travel with them, and doc comments split.

    CATCHES: the package doc comment gains a space, the closing-parenthesis
    comment is moved after the paren, and a leading doc comment stays
    attached to the import it documents rather than being lifted.
    """
    write("go.mod", GO_MOD)
    write("comments.go", COMMENTS_IN)
    result = run(["comments.go"])
    assert result.out == COMMENTS_OUT
    assert result.returncode == 0


def test_std_imports_module_path_prefix_is_third_party(write, run):
    """Imports under the module path itself are treated as third-party.

    CATCHES: "nodomainmod" and "nodomainmodextra" differ only by suffix, so
    the grouping must compare full path prefixes rather than substrings.
    """
    write("go.mod", GO_MOD)
    write("foo.go", 'package p\n\nimport (\n\t"io"\n\n\t"nodomainmod"\n'
                    '\t"nodomainmod/mod1/pkg1"\n\t"nodomainmod/mod2"\n'
                    '\t"nodomainmodextra"\n)\n')
    result = run(["foo.go"])
    assert result.out == ('package p\n\nimport (\n\t"io"\n\t"nodomainmodextra"\n\n'
                          '\t"nodomainmod"\n\t"nodomainmod/mod1/pkg1"\n'
                          '\t"nodomainmod/mod2"\n)\n')
    assert result.returncode == 0
