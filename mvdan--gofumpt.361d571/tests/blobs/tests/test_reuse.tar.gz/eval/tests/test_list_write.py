"""Black-box tests for the ``-l`` list mode and ``-w`` in-place rewrite.

Mined from the repository's native testscripts (``diff.txtar``,
``deprecated-flags.txtar``, ``generated.txtar``, ``ignore.txtar``).
"""

DIRTY = 'package p; func badlyformatted() {}'


def dirty(name):
    """An unformatted but valid Go file body."""
    return 'package p\n\nfunc f() {\nprintln("%s")\n}\n' % name


def test_list_names_files_that_differ(write, run):
    """-l prints one relative path per unformatted file and exits 0.

    CATCHES: the exit code stays 0 even though formatting differences were
    found, which is what makes -l usable as a plain filter.
    """
    write("a.go", dirty("a"))
    write("b.go", "package p\n")
    result = run(["-l", "a.go", "b.go"])
    assert result.out == "a.go\n"
    assert result.stderr == b""
    assert result.returncode == 0


def test_list_walks_directories_in_lexical_order(write, run):
    """A directory argument is walked and .go files are listed sorted.

    CATCHES: hidden dotfiles are skipped by the walker while underscore
    prefixed files are kept, and sub-directories are visited after their
    parent's own files.
    """
    write("d/a.go", dirty("a"))
    write("d/_under.go", dirty("u"))
    write("d/.hidden.go", dirty("h"))
    write("d/notes.txt", "not go\n")
    write("d/sub/b.go", dirty("b"))
    result = run(["-l", "d"])
    assert result.out == "d/_under.go\nd/a.go\nd/sub/b.go\n"
    assert result.returncode == 0


def test_list_repeats_explicitly_named_files(write, run):
    """Naming a directory and a file inside it processes the file twice.

    CATCHES: there is no de-duplication, so the walked entry and the
    explicit entry both appear in the list output.
    """
    write("m/a.go", dirty("a"))
    write("m/z.go", dirty("z"))
    result = run(["-l", "m/z.go", "m/a.go"])
    assert result.out == "m/z.go\nm/a.go\n"
    repeated = run(["-l", "m", "m/a.go"])
    assert repeated.out == "m/a.go\nm/z.go\nm/a.go\n"


def test_write_rewrites_file_in_place_and_is_quiet(write, run, read):
    """-w rewrites the file on disk and prints nothing to stdout.

    CATCHES: the replacement is byte-exact (tab indentation, single blank
    line) and the exit code is 0 because -w does not act like -d.
    """
    write("foo.go", dirty("foo"))
    result = run(["-w", "foo.go"])
    assert result.stdout == b""
    assert result.stderr == b""
    assert result.returncode == 0
    assert read("foo.go") == 'package p\n\nfunc f() {\n\tprintln("foo")\n}\n'


FORMATTED = 'package p\n\nfunc f() {\n\tprintln("foo")\n}\n'


def test_write_is_idempotent(write, run, read):
    """A second -w run leaves the already-formatted bytes untouched.

    CATCHES: the first run must really rewrite the file into canonical
    gofumpt form (tab indent, no stray blank lines), and the formatter must
    be a fixed point on that output, so the second run neither changes the
    bytes nor reports the file through -l again.
    """
    write("foo.go", dirty("foo"))
    assert run(["-w", "foo.go"]).stdout == b""
    assert read("foo.go") == FORMATTED
    second = run(["-w", "foo.go"])
    assert second.returncode == 0
    assert second.stdout == b""
    assert second.stderr == b""
    assert read("foo.go") == FORMATTED
    assert run(["-l", "foo.go"]).stdout == b""


def test_write_reports_the_file_when_combined_with_list(write, run):
    """-l alongside -w still names the file that was rewritten.

    CATCHES: both flags are honoured at once, so the path is printed even
    though the formatted bytes never reach stdout.
    """
    write("c.go", dirty("c"))
    result = run(["-w", "-l", "c.go"])
    assert result.out == "c.go\n"
    assert result.returncode == 0


def test_list_and_write_skip_non_go_files_during_walks(write, run):
    """A walked non-.go file is never listed even when unformatted.

    CATCHES: only files whose base name does not start with a dot and ends
    in ".go" are considered during walks; everything else is skipped
    silently rather than reported as an error.
    """
    write("d/a.go", dirty("a"))
    write("d/script.sh", "this is not go source\n")
    write("d/README.md", "nor is this\n")
    result = run(["-l", "d"])
    assert result.out == "d/a.go\n"
    assert result.stderr == b""
    assert result.returncode == 0
