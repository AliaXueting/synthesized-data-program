"""Black-box tests for the "use := instead of var with initialiser" rule.

Mined from the repository's native ``testdata/script/short-decl.txtar``
testscript.
"""

DECLS_IN = """package p

var global = x

func f() {
	var local = x
	var local2, local3 = x, y

	var onlyType T

	var typeAndVar T = x

	var _ = unused

	var (
		aligned = x
		vars    = y
		here    = y
	)
}
"""

DECLS_OUT = """package p

var global = x

func f() {
	local := x
	local2, local3 := x, y

	var onlyType T

	var typeAndVar T = x

	_ = unused

	var (
		aligned = x
		vars    = y
		here    = y
	)
}
"""

COMMENTS_IN = """package p

func f() {
	var comment = // comment
		x
	var comment2, comment3 = // comment
		x, y
	var commentBefore /* comment */ =
		x

	var nextLine =
		x
	var nextLine2, nextLine3 =
		x, y
	var nextLineBinary =
		x +
			y
}
"""

COMMENTS_OUT = """package p

func f() {
	comment := // comment
		x
	comment2, comment3 := // comment
		x, y
	commentBefore := /* comment */
		x

	nextLine := x
	nextLine2, nextLine3 := x, y
	nextLineBinary := x +
		y
}
"""


def test_short_var_decls_become_assignments(write, run):
    """Local ``var x = v`` turns into ``x := v`` only inside functions.

    CATCHES: the rule is scoped to function bodies, skips declarations with
    an explicit type, and rewrites ``var _ = unused`` to a plain assignment.
    """
    write("foo.go", DECLS_IN)
    result = run(["foo.go"])
    assert result.out == DECLS_OUT
    assert result.returncode == 0


def test_short_decl_result_is_stable(write, run):
    """The rewritten declarations are a fixed point of the formatter.

    CATCHES: running the rule over its own output must be a no-op, checked
    through the silent -d mode.
    """
    write("foo.go", DECLS_OUT)
    assert run(["-d", "foo.go"]).stdout == b""
    assert run(["foo.go"]).out == DECLS_OUT


def test_short_decl_keeps_inline_comments(write, run):
    """Inline comments stay attached while the value moves up one line.

    CATCHES: a comment between the keyword and the value survives the
    rewrite, and a value that sat on its own line is joined onto the
    declaration line.
    """
    write("comment.go", COMMENTS_IN)
    result = run(["comment.go"])
    assert result.out == COMMENTS_OUT
    assert result.returncode == 0
    assert run(["-d", "comment.go"]).returncode == 1
