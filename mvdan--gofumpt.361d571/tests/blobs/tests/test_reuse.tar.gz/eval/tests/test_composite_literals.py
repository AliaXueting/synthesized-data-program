"""Black-box tests for composite literal newlines and trailing commas.

Mined from the repository's native
``testdata/script/composite-multiline.txtar`` and
``testdata/script/composite-literals-leading-lines.txtar`` testscripts.
"""

LEADING_IN = """package p

var _ = []string{


	"foo",
}

var _ = []string{

	"foo",
}

var _ = []string{

	// joint comment
	"foo",
}

var _ = []string{
	// separate comment

	"foo",
}

var _ = map[string]string{


	"foo": "bar",
}

var _ = []int{

	1, 2}

var _ = []int{

/* unindented
comment */
	1,
}
"""

LEADING_OUT = """package p

var _ = []string{
	"foo",
}

var _ = []string{
	"foo",
}

var _ = []string{
	// joint comment
	"foo",
}

var _ = []string{
	// separate comment

	"foo",
}

var _ = map[string]string{
	"foo": "bar",
}

var _ = []int{
	1, 2,
}

var _ = []int{
	/* unindented
	   comment */
	1,
}
"""

MULTILINE_IN = """package p

var _ = []int{
}

var _ = []int{1, 2,
	3, 4}

var _ = []int{
	1, 2, 3, 4}

var _ = [][]string{{
	"no need for more newlines",
	"if wrapping a single expression",
}}

var _ = []string{`
	no need for newlines
	`, `
	if no elements are surrounded by newlines
`}

var _ = []struct{ a int }{
	{ // consistent
		a: 1,
	},
	{
		a: 2,
	}, { // inconsistent
		a: 3,
	},
}

var _ = []struct{ a int }{{
	a: 1,
}, {
	a: 2,
}, {
	a: 3,
}}

var _ interface{
}

func _(struct{
})

var _ = []interface {
}{1, 2, 3}

func _(
)

type T struct {
	Foo          // comment
	Bar struct { // comment
	}
}
"""

MULTILINE_OUT = """package p

var _ = []int{}

var _ = []int{
	1, 2,
	3, 4,
}

var _ = []int{
	1, 2, 3, 4,
}

var _ = [][]string{{
	"no need for more newlines",
	"if wrapping a single expression",
}}

var _ = []string{`
	no need for newlines
	`, `
	if no elements are surrounded by newlines
`}

var _ = []struct{ a int }{
	{ // consistent
		a: 1,
	},
	{
		a: 2,
	},
	{ // inconsistent
		a: 3,
	},
}

var _ = []struct{ a int }{{
	a: 1,
}, {
	a: 2,
}, {
	a: 3,
}}

var _ interface{}

func _(struct{})

var _ = []interface{}{1, 2, 3}

func _()

type T struct {
	Foo          // comment
	Bar struct { // comment
	}
}
"""


def test_leading_blank_lines_in_literals_are_removed(write, run):
    """Blank lines at the start of a literal body collapse to nothing.

    CATCHES: a blank line before the first element is dropped, but a blank
    line between a comment and the element is kept because the comment is
    attached to it.
    """
    write("foo.go", LEADING_IN)
    result = run(["foo.go"])
    assert result.out == LEADING_OUT
    assert result.returncode == 0


def test_multiline_literals_get_a_trailing_comma(write, run):
    """A literal whose elements span lines gains a trailing comma.

    CATCHES: literals that were already multiline but lacked the final
    comma get one, while single-line literals stay single-line and
    empty ones collapse to "{}".
    """
    write("foo.go", MULTILINE_IN)
    result = run(["foo.go"])
    assert result.out == MULTILINE_OUT
    assert result.returncode == 0


def test_multiline_literal_output_is_stable(write, run):
    """The reformatted literals are a fixed point of the formatter.

    CATCHES: the trailing comma that was added must not trigger further
    changes on a second pass, verified with the silent -d mode.
    """
    write("foo.go", MULTILINE_OUT)
    assert run(["-d", "foo.go"]).stdout == b""
    assert run(["foo.go"]).out == MULTILINE_OUT


def test_element_braces_are_put_on_their_own_lines(write, run):
    """Two elements sharing a closing/opening brace line get split apart.

    CATCHES: "}, {" in a multiline composite literal becomes a newline
    between the elements, and an inline comment stays on the opening brace
    line it was attached to.
    """
    write("cons.go", 'package p\n\nvar _ = []struct{ a int }{\n'
                     '\t{ // consistent\n\t\ta: 1,\n\t},\n\t{\n\t\ta: 2,\n\t}, '
                     '{ // inconsistent\n\t\ta: 3,\n\t},\n}\n')
    result = run(["cons.go"])
    assert result.out == ('package p\n\nvar _ = []struct{ a int }{\n'
                          '\t{ // consistent\n\t\ta: 1,\n\t},\n'
                          '\t{\n\t\ta: 2,\n\t},\n'
                          '\t{ // inconsistent\n\t\ta: 3,\n\t},\n}\n')
    assert result.returncode == 0
