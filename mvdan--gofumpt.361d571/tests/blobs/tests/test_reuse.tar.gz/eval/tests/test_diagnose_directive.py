"""Black-box tests for the ``//gofumpt:diagnose`` magic comment.

Mined from the repository's native ``testdata/script/diagnose.txtar`` and
``testdata/script/gomod.txtar`` testscripts. The directive makes the
formatter print the effective version and flag set back into the source,
which is the only way the CLI exposes its resolved ``-lang``/``-modpath``
defaults.
"""

DIAGNOSE_VERSION = "go1.18.29"


def diagnose_file(body=""):
    """A Go file whose only content is the diagnose directive."""
    return "package p\n\n//gofumpt:diagnose\n" + body


def test_diagnose_prints_version_and_resolved_flags(write, run):
    """The directive is replaced by a line naming version, lang and modpath.

    A re-implementation that resolves -lang/-modpath differently, or that
    formats the directive line differently, changes this exact output.
    """
    write("go.mod", "module test\n\ngo 1.16\n")
    write("foo.go", diagnose_file())
    result = run(["foo.go"], extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
    assert result.out == (
        "package p\n"
        "\n"
        "//gofumpt:diagnose version: (devel) (%s) "
        "flags: -lang=go1.16 -modpath=test\n" % DIAGNOSE_VERSION
    )
    assert result.returncode == 0
    assert result.stderr == b""


def test_diagnose_ignores_trailing_whitespace_and_arguments(write, run):
    """A trailing tab or a stale version argument is overwritten wholesale.

    The whole comment text after the directive is replaced, so leftovers
    such as " v0.1.0" must not survive into the output.
    """
    write("go.mod", "module test\n\ngo 1.16\n")
    write("outdated.go", "package p\n\n//gofumpt:diagnose v0.1.0\n")
    write("trailing.go", "package p\n\n//gofumpt:diagnose\t\n")
    expected = (
        "package p\n"
        "\n"
        "//gofumpt:diagnose version: (devel) (%s) "
        "flags: -lang=go1.16 -modpath=test\n" % DIAGNOSE_VERSION
    )
    for name in ("outdated.go", "trailing.go"):
        result = run([name], extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
        assert result.out == expected
        assert result.returncode == 0


def test_diagnose_is_not_a_prefix_match(write, run):
    """Only the exact directive text triggers; lookalikes are untouched.

    CATCHES: 'diagnosefoobar' and a spaced '// gofumpt:diagnose' are echoed
    back byte-for-byte rather than being rewritten into a version line, so
    a prefix or substring match would produce a spurious diagnose line.
    """
    write("go.mod", "module test\n\ngo 1.16\n")
    write("nochange.go", "package p\n\n//gofumpt:diagnosefoobar\n")
    write("spaced.go", "package p\n\n// gofumpt:diagnose\n")
    for name, comment in (("nochange.go", "//gofumpt:diagnosefoobar"),
                          ("spaced.go", "// gofumpt:diagnose")):
        result = run([name], extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
        assert result.out == "package p\n\n%s\n" % comment
        assert result.stderr == b""
        assert result.returncode == 0
        listed = run(["-l", name],
                     extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
        assert listed.stdout == b""
        assert listed.returncode == 0


def test_diagnose_extra_rules_listing(write, run):
    """-extra lists the enabled rule names in a fixed order.

    The bare -extra flag enables all three rules and prints them sorted by
    name, which a re-implementation with a different ordering breaks.
    """
    write("go.mod", "module test\n\ngo 1.16\n")
    write("foo.go", diagnose_file())
    result = run(["-extra", "foo.go"],
                 extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
    assert result.out.endswith(
        "flags: -lang=go1.16 -modpath=test "
        "-extra=group_params,clothe_returns,balance_calls\n"
    )
    assert result.returncode == 0


def test_diagnose_extra_rules_selection_and_disable(write, run):
    """-extra=<names> lists only the requested rules; =false disables all.

    CATCHES: the flag is a comma-separated rule list whose printed order is
    normalised, and "-extra=false" must print no -extra flag at all.
    """
    write("go.mod", "module test\n\ngo 1.16\n")
    write("foo.go", diagnose_file())
    one = run(["-extra=group_params", "foo.go"],
              extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
    assert one.out.endswith(
        "flags: -lang=go1.16 -modpath=test -extra=group_params\n")
    reordered = run(["-extra=clothe_returns,group_params", "foo.go"],
                    extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
    assert reordered.out.endswith(
        "flags: -lang=go1.16 -modpath=test -extra=group_params,clothe_returns\n")
    off = run(["-extra=false", "foo.go"],
              extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
    assert off.out.endswith("flags: -lang=go1.16 -modpath=test\n")
    assert "-extra=" not in off.out


def test_diagnose_lang_flag_overrides_go_mod(write, run):
    """An explicit -lang wins over the go.mod version and is echoed verbatim.

    CATCHES: -lang=go1 is accepted un-normalised, so the echoed value must
    stay "go1" rather than being rounded to a released Go version.
    """
    write("go.mod", "module test\n\ngo 1.16\n")
    write("foo.go", diagnose_file())
    result = run(["-lang=go1", "foo.go"],
                 extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
    assert result.out.endswith(
        "flags: -lang=go1 -modpath=test\n")


def test_diagnose_lang_from_go_mod_variants(write, run):
    """The go directive is normalised through x/mod's version parsing.

    CATCHES: a patch release ("1.21.2") and a release candidate ("1.21rc3")
    both resolve to go1.21, a missing go directive falls back to go1.16,
    and a go.mod with no module directive yields an empty -modpath.
    """
    cases = [
        ("module a\n\ngo 1.21.2\n", "-lang=go1.21 -modpath=a"),
        ("module a\n\ngo 1.21rc3\n", "-lang=go1.21 -modpath=a"),
        ("module a\n", "-lang=go1.16 -modpath=a"),
        ("", "-lang=go1.16 -modpath="),
    ]
    for go_mod, flags in cases:
        write("go.mod", go_mod)
        write("a.go", "package a\n\n//gofumpt:diagnose\n")
        result = run(["a.go"], extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
        assert result.out == (
            "package a\n\n//gofumpt:diagnose version: (devel) (%s) flags: %s\n"
            % (DIAGNOSE_VERSION, flags)
        )


def test_diagnose_lang_from_nested_and_parent_modules(write, run):
    """Module info comes from the nearest enclosing go.mod, walked upwards.

    CATCHES: a nested module shadows the outer one, and a directory with no
    go.mod of its own inherits the parent module's -lang and -modpath.
    """
    write("outer/go.mod", "module outer\n\ngo 1.16\n")
    write("outer/plain/a.go", "package a\n\n//gofumpt:diagnose\n")
    write("outer/nested/go.mod", "module nested\n\ngo 1.21\n")
    write("outer/nested/a.go", "package a\n\n//gofumpt:diagnose\n")

    inherited = run(["outer/plain/a.go"],
                    extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
    assert inherited.out.endswith("flags: -lang=go1.16 -modpath=outer\n")

    nested = run(["outer/nested/a.go"],
                 extra_env={"GO_VERSION_TEST": DIAGNOSE_VERSION})
    assert nested.out.endswith("flags: -lang=go1.21 -modpath=nested\n")
