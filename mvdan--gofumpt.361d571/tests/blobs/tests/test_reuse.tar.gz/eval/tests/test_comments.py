"""Black-box tests for comment spacing and directive detection.

Mined from the repository's native ``testdata/script/comment-code.txtar``
and ``testdata/script/comment-spaced.txtar`` testscripts.
"""

CODE_IN = """package p

//foo()

//if x == y {
//	doSomething()
//}

//for i := 0; i < 10; i++ {
//}

//switch v := x.(type) {
//case int:
//}

//var x = 1

//type T struct{}

//Note that we ignore prose with letters.

//returns the value when condition holds
"""

CODE_OUT = """package p

//foo()

//if x == y {
//	doSomething()
//}

//for i := 0; i < 10; i++ {
//}

//switch v := x.(type) {
//case int:
//}

//var x = 1

//type T struct{}

// Note that we ignore prose with letters.

// returns the value when condition holds
"""

DIRECTIVES_IN = """package p

//go:build tag
// +build tag

//go:generate some command

//go:unknowndirective

//nolint

//nolint // explanation

//nolint:somelinter // explanation

//NOSONAR

//noinspection ALL

//#nosec

//not actually: a directive

//https://just.one/url

//TODO: do something

//export CgoFunc

//extern open
func c_open(name *byte, mode int, perm int) int

//line 123

//sys   Unlink(path string) (err error)

//foo:bar_one

//foo:barOne

//foo is foo.
type foo int

//	comment with a tab.

//  comment with many spaces

//comment group
//123 numbers too

// comment group
//123 numbers too

//{
//this is probably code
//}

////////////
// ascii art
//----------

//

func f() {
	_ = 1 //comment ending a block

}

type T struct {
	A int //comment ending a field list

}
"""

DIRECTIVES_OUT = """//go:build tag
// +build tag

package p

//go:generate some command

//go:unknowndirective

//nolint

//nolint // explanation

//nolint:somelinter // explanation

//NOSONAR

//noinspection ALL

//#nosec

// not actually: a directive

// https://just.one/url

// TODO: do something

//export CgoFunc

//extern open
func c_open(name *byte, mode int, perm int) int

//line 123

//sys   Unlink(path string) (err error)

//foo:bar_one

//foo:barOne

// foo is foo.
type foo int

//	comment with a tab.

//  comment with many spaces

// comment group
// 123 numbers too

// comment group
// 123 numbers too

//{
//this is probably code
//}

////////////
// ascii art
//----------

//

func f() {
	_ = 1 // comment ending a block
}

type T struct {
	A int // comment ending a field list
}
"""

INDENTED_DOC_IN = """//	indented
//package doc
package p

//	indented
//func doc
func f() {}

 //
func emptyDoc() {}

var (
//	indented
//before the closing paren
)
"""

INDENTED_DOC_OUT = """//	indented
//
// package doc
package p

//	indented
//
// func doc
func f() {}

func emptyDoc() {}

var (
//	indented
//
// before the closing paren
)
"""

BUILD_BETWEEN_IN = """//
// +build linux
// Package p does things.
package p

// F
// +build amd64
// does things.

// G does things.
func G() {}

/* H */
// +build arm64
// does things.
func H() {}
"""

BUILD_BETWEEN_OUT = """//go:build linux && amd64 && arm64
// +build linux,amd64,arm64

// Package p does things.
package p

// F
// does things.

// G does things.
func G() {}

/* H */
// does things.
func H() {}
"""


def test_code_like_comments_are_left_alone(write, run):
    """Comments that look like Go code keep no space; prose gains one.

    CATCHES: the heuristic parses the comment text as a statement, so
    "//var x = 1" is code while "//Note that we ignore..." is prose.
    """
    write("foo.go", CODE_IN)
    result = run(["foo.go"])
    assert result.out == CODE_OUT
    assert result.returncode == 0


def test_known_directives_are_never_respaced(write, run):
    """Build, linter and cgo directives keep their original spacing.

    CATCHES: "//nolint", "//NOSONAR", "//export ..." and "//sys   ..." are
    all recognised by pattern, while "//not actually: a directive" and a
    plain URL are not and therefore get a space inserted. The build tags
    are also hoisted above the package clause with a blank line after.
    """
    write("foo.go", DIRECTIVES_IN)
    result = run(["foo.go"])
    assert result.out == DIRECTIVES_OUT
    assert result.returncode == 0


def test_indented_doc_comments_get_a_separator_line(write, run):
    """A tab-indented line in a doc comment is a code block.

    CATCHES: the blank "//" separator is inserted between the indented code
    block and the following prose line both for the package doc and inside
    a var group, and a whitespace-only doc comment is dropped entirely.
    """
    write("doc.go", INDENTED_DOC_IN)
    result = run(["doc.go"])
    assert result.out == INDENTED_DOC_OUT
    assert result.returncode == 0


def test_legacy_build_tags_are_merged_and_moved(write, run):
    """Scattered "// +build" lines merge into one go1.17 build constraint.

    CATCHES: the //go:build expression is the conjunction of every tag and
    the legacy line is rewritten as a comma-separated list, both placed
    before the package clause with a blank line after.
    """
    write("build.go", BUILD_BETWEEN_IN)
    result = run(["build.go"])
    assert result.out == BUILD_BETWEEN_OUT
    assert result.returncode == 0


def test_line_directive_trailing_space_is_trimmed(write, run):
    """A "//line " comment with trailing spaces becomes "// line".

    CATCHES: trailing whitespace turns the directive into a plain comment
    which then gets the space inserted, and the following var declarations
    are joined into a single group.
    """
    write("directive.go", 'package p\n\nvar x = 1 //line \n\nvar a = 1\n'
                          '//line \nvar b = 2\n\nfunc f() {\n\t//foo\n\t//  \n'
                          '\t//bar\n}\n')
    result = run(["directive.go"])
    assert result.out == ('package p\n\nvar x = 1 // line\n\nvar (\n'
                          '\ta = 1\n\t// line\n\tb = 2\n)\n\nfunc f() {\n'
                          '\t// foo\n\t//\n\t// bar\n}\n')
    assert result.returncode == 0
