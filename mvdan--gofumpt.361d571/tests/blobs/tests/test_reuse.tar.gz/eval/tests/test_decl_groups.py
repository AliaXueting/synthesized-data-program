"""Black-box tests for joining and collapsing top-level declaration groups.

Mined from the repository's native ``testdata/script/decl-group-single.txtar``
and ``testdata/script/decl-group-many.txtar`` testscripts.
"""

SINGLE_IN = """package p

var single = "foo"

var (
	// verbose is verbose.
	verbose = "bar"
)

// This entire block has a comment.
var (
	groupComment = "bar"
)

var (
	multiple1 string
	multiple2 string
)

const (
	first = iota
)

var (
	multiline = []string{
		"foo",
		"bar",
	}
)

var (
	foo = "foo"
	// bar = "bar"
	// baz = "baz"
)
"""

SINGLE_OUT = """package p

var single = "foo"

// verbose is verbose.
var verbose = "bar"

// This entire block has a comment.
var (
	groupComment = "bar"
)

var (
	multiple1 string
	multiple2 string
)

const (
	first = iota
)

var multiline = []string{
	"foo",
	"bar",
}

var foo = "foo"

// bar = "bar"
// baz = "baz"
"""

ADJACENT_IN = """package p

import "strings"
import "bytes"

var _ = bytes.Buffer{}
var _ = strings.Builder{}
"""

ADJACENT_OUT = """package p

import (
	"bytes"
	"strings"
)

var (
	_ = bytes.Buffer{}
	_ = strings.Builder{}
)
"""

DOC_IN = """package p

var ( //  line comment
	x = 1
)

var ( //
	z = 1
)

var ( // paren comment
	// spec comment
	y = 1
)

var ( //
//
w = 1
)
"""

DOC_OUT = """package p

// line comment
var x = 1

var z = 1

// paren comment
// spec comment
var y = 1

var w = 1
"""

SEMICOLON_IN = """package p

var a = 0
var b = 1; const c = 2 // c

var d = 0
var e = 1; func f() {} // f
"""

SEMICOLON_OUT = """package p

var (
	a = 0
	b = 1
)

const c = 2 // c

var (
	d = 0
	e = 1
)

func f() {} // f
"""


def test_single_spec_groups_are_collapsed(write, run):
    """A one-spec parenthesised group is unwrapped and its doc comment lifted.

    CATCHES: the comment moves above the keyword, and a group whose only
    specs are commented out is split into a bare decl plus trailing
    comments.
    """
    write("f1.go", SINGLE_IN)
    result = run(["f1.go"])
    assert result.out == SINGLE_OUT
    assert result.returncode == 0

    write("f1.golden", SINGLE_OUT)
    assert run(["-d", "f1.golden"]).stdout == b""
    assert run(["f1.golden"]).out == SINGLE_OUT


def test_adjacent_decls_of_the_same_kind_are_joined(write, run):
    """Neighbouring import and var declarations merge into one group.

    CATCHES: the joined group is re-aligned and sorted, so the two imports
    end up alphabetically ordered inside a single parenthesised block.
    """
    write("f3.go", ADJACENT_IN)
    result = run(["f3.go"])
    assert result.out == ADJACENT_OUT
    assert result.returncode == 0


def test_paren_and_spec_comments_are_lifted_together(write, run):
    """Comments before the specs are hoisted above the unwrapped declaration.

    CATCHES: a "//"-only comment next to the opening paren is dropped, and
    the paren comment and spec comment are concatenated in that order.
    """
    write("doc.go", DOC_IN)
    result = run(["doc.go"])
    assert result.out == DOC_OUT
    assert result.returncode == 0


def test_semicolon_separated_decls_are_split_before_grouping(write, run):
    """Two decls on one line split apart, but not across different keywords.

    CATCHES: only same-kind neighbours are joined into a group, so the
    trailing const and func stay standalone while keeping their comments.
    """
    write("next.go", SEMICOLON_IN)
    result = run(["next.go"])
    assert result.out == SEMICOLON_OUT
    assert result.returncode == 0


def test_trailing_comment_specs_are_detached(write, run):
    """A commented-out spec after the last real one becomes a floating comment.

    CATCHES: the group is collapsed to the single real spec and the
    commented-out lines are re-emitted as a standalone comment block.
    """
    write("trailing.go", 'package p\n\nvar (\n\tx = 1\n\t//y = 2\n)\n'
                         'var z = 3\n\nvar (\n\ta = 1\n\t/* b */)\nvar c = 3\n')
    result = run(["trailing.go"])
    assert result.out == ('package p\n\nvar x = 1\n\n//y = 2\n\nvar z = 3\n\n'
                          'var a = 1\n\n/* b */\n\nvar c = 3\n')
    assert result.returncode == 0
