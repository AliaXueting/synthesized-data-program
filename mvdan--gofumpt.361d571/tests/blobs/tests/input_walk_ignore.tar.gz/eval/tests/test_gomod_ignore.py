"""go.mod ``ignore`` directives excluding directories from walks.

A walked directory is skipped when the enclosing module's go.mod lists it.
``ignore ./dir`` (rooted) matches only that exact directory relative to the
module root, while ``ignore dir`` matches any walked directory whose
slash-normalized path relative to the module root ends with ``/dir/``.  Naming
an ignored directory directly on the command line still formats it (covered by
test_explicit_paths.py).

Unless a test says otherwise the walked directory *is* the module root, which
is how gofumpt is normally used.
"""

from __future__ import annotations

import pytest

from conftest import go_mod, run_gofumpt, seed

ROOTED = "module example.com/m\n\ngo 1.25\n\nignore ./dir\n"


def test_rooted_ignore_matches_only_that_directory(tmp_path):
    """``ignore ./dir`` excludes exactly module-root/dir, no near misses."""
    go_mod(tmp_path / "tree", ROOTED)
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/prefixignore/dir/p.go",
                    "tree/sub/dir/s.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "tree/prefixignore/dir/p.go\n"
        "tree/sub/dir/s.go\n"
        "tree/top.go\n"
    )
    assert res.stderr == ""
    # CATCHES: treating the rooted form as a suffix match would also drop
    # tree/prefixignore/dir/p.go and tree/sub/dir/s.go.


def test_unrooted_ignore_matches_nested_directories(tmp_path):
    """``ignore dir`` excludes every walked directory ending in /dir/."""
    go_mod(tmp_path / "tree", "module example.com/m\n\ngo 1.25\n\nignore dir\n")
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/sub/dir/s.go",
                    "tree/prefixignore/dir/p.go", "tree/mydir/m.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/mydir/m.go\ntree/top.go\n"
    # CATCHES: matching only the exact name (rooted behaviour) would leave
    # tree/dir/d.go, tree/sub/dir/s.go and tree/prefixignore/dir/p.go listed,
    # while a plain substring match would also drop tree/mydir/m.go.


def test_rooted_ignore_with_nested_path(tmp_path):
    """``ignore ./sub/dir`` excludes only that subdirectory."""
    go_mod(tmp_path / "tree", "module example.com/m\n\ngo 1.25\n\nignore ./sub/dir\n")
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/sub/dir/sd.go",
                    "tree/sub/other.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/dir/d.go\ntree/sub/other.go\ntree/top.go\n"
    # CATCHES: matching only the last path element (the unrooted behaviour)
    # would also drop tree/dir/d.go.


def test_quoted_ignore_directive(tmp_path):
    """A quoted directive argument is unquoted before matching."""
    go_mod(tmp_path / "tree", 'module example.com/m\n\ngo 1.25\n\nignore "./dir"\n')
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/sub/dir/s.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/sub/dir/s.go\ntree/top.go\n"
    # CATCHES: comparing the raw quoted token (including the double quotes)
    # against the directory name would match nothing at all.


def test_ignore_directive_with_trailing_slash(tmp_path):
    """A trailing slash on the directive path still matches the directory."""
    go_mod(tmp_path / "tree", "module example.com/m\n\ngo 1.25\n\nignore ./dir/\n")
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/sub/dir/s.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/sub/dir/s.go\ntree/top.go\n"
    # CATCHES: a naive exact compare of the raw directive text against the
    # directory name would fail to match "dir/" to "dir".


@pytest.mark.parametrize("directive", ["ignore /dir", "ignore dir"])
def test_leading_slash_ignore_is_not_rooted(tmp_path, directive):
    """Only the ``./`` prefix makes a directive rooted."""
    go_mod(tmp_path / "tree",
           "module example.com/m\n\ngo 1.25\n\n%s\n" % directive)
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/sub/dir/s.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/top.go\n"
    # CATCHES: treating any leading slash as "rooted at the module root" would
    # keep tree/sub/dir/s.go listed for both spellings.


def test_parent_relative_ignore_matches_nothing(tmp_path):
    """``ignore ../dir`` never matches a directory inside the module."""
    go_mod(tmp_path / "tree", "module example.com/m\n\ngo 1.25\n\nignore ../dir\n")
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/dir/d.go\ntree/top.go\n"
    # CATCHES: stripping ".." (or resolving it against the module root) would
    # turn the directive into "ignore ./dir" and drop tree/dir/d.go.


def test_multiple_ignore_directives_accumulate(tmp_path):
    """Several ignore lines are all honoured."""
    go_mod(tmp_path / "tree",
           "module example.com/m\n\ngo 1.25\n\nignore ./one\nignore ./two\n")
    seed(tmp_path, ["tree/top.go", "tree/one/a.go", "tree/two/b.go",
                    "tree/three/c.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/three/c.go\ntree/top.go\n"
    # CATCHES: honouring only the first (or last) directive would list one of
    # tree/one/a.go and tree/two/b.go.


def test_invalid_ignore_directive_disables_ignoring(tmp_path):
    """A go.mod that fails to parse is ignored - and silently."""
    go_mod(tmp_path / "tree",
           "module example.com/m\n\ngo 1.25\n\nignore ./dir extra\n")
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/dir/d.go\ntree/top.go\n"
    assert res.stderr == ""
    # CATCHES: a re-implementation that reports the malformed go.mod (or that
    # still honours the first argument of the directive) would differ.


def test_unknown_directive_makes_go_mod_invalid(tmp_path):
    """Any unparsable directive makes the whole module file unusable."""
    go_mod(tmp_path / "tree",
           "module example.com/m\n\ngo 1.25\n\nignore ./dir\nbogus x\n")
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/dir/d.go\ntree/top.go\n"
    assert res.stderr == ""
    # CATCHES: parsing the go.mod leniently (ignoring unknown lines) would
    # still skip tree/dir/d.go.


def test_without_go_mod_nothing_is_ignored(tmp_path):
    """Outside any module no directory is excluded by a directive."""
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/dir/d.go\ntree/top.go\n"
    # CATCHES: this pins that a merely-named "dir" directory cannot be excluded
    # without a go.mod, so a later directive test cannot pass by accident.


def test_invalid_go_mod_shields_enclosing_module(tmp_path):
    """A broken go.mod stops the upward search for an enclosing module."""
    go_mod(tmp_path / "outer", "module example.com/outer\n\ngo 1.25\n\nignore ./dir\n")
    (tmp_path / "outer" / "shield" / "go.mod").parent.mkdir(parents=True)
    (tmp_path / "outer" / "shield" / "go.mod").write_text(
        "not a valid go.mod at all\n", encoding="utf-8")
    seed(tmp_path, ["outer/top.go", "outer/dir/d.go", "outer/shield/dir/sd.go",
                    "outer/shield/keep/k.go"])
    res = run_gofumpt(["-l", "outer"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "outer/shield/dir/sd.go\n"
        "outer/shield/keep/k.go\n"
        "outer/top.go\n"
    )
    # CATCHES: walking past an invalid go.mod to the enclosing module would
    # apply outer's ignore and drop outer/shield/dir/sd.go.


def test_ignore_honored_when_walking_from_above_the_module(tmp_path):
    """The module is found even when the walk starts above its directory."""
    go_mod(tmp_path, "module example.com/m\n\ngo 1.25\n\nignore ./m/dir\n")
    seed(tmp_path, ["m/top.go", "m/dir/d.go", "m/keep.go"])
    res = run_gofumpt(["-l", "."], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "m/keep.go\nm/top.go\n"
    # CATCHES: resolving the go.mod relative to the *walk root* instead of the
    # walked directory would find nothing and list m/dir/d.go.


def test_ignore_is_module_relative_for_subdirectory_walks(tmp_path):
    """Walking one subdirectory still matches ignores against the module root."""
    go_mod(tmp_path, "module example.com/m\n\ngo 1.25\n\nignore ./sub/dir\n")
    seed(tmp_path, ["sub/ok.go", "sub/dir/s.go"])
    res = run_gofumpt(["-l", "sub"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "sub/ok.go\n"
    # CATCHES: computing the ignored path relative to the walk root (instead
    # of the module root) would look for "dir" under sub/ and match nothing.


def test_walking_module_root_with_dot_argument(tmp_path):
    """``.`` inside the module works like any other walk root."""
    go_mod(tmp_path, "module example.com/m\n\ngo 1.25\n\nignore dir\n")
    seed(tmp_path, ["top.go", "dir/d.go", "sub/dir/s.go", "sub/ok.go"])
    res = run_gofumpt(["-l", "."], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "sub/ok.go\ntop.go\n"
    # CATCHES: a relative-path bug that makes "." never resolve to a module
    # would list dir/d.go and sub/dir/s.go as well.


def test_nested_module_governs_its_own_subtree(tmp_path):
    """A nested go.mod takes over for the directories below it."""
    go_mod(tmp_path / "outer", "module example.com/outer\n\ngo 1.25\n\nignore ./skipme\n")
    go_mod(tmp_path / "outer" / "inner",
           "module example.com/inner\n\ngo 1.25\n\nignore ./inner\n")
    seed(tmp_path, ["outer/top.go", "outer/skipme/s.go", "outer/inner/ok.go",
                    "outer/inner/inner/ii.go"])
    res = run_gofumpt(["-l", "outer"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "outer/inner/ok.go\nouter/top.go\n"
    # CATCHES: using the outermost module for every directory would fail to
    # skip outer/inner/inner, and self-matching would skip outer/inner itself.


def test_module_never_ignores_its_own_root(tmp_path):
    """A rooted ignore never matches the directory holding the go.mod."""
    go_mod(tmp_path / "m", "module example.com/m\n\ngo 1.25\n\nignore ./m\n")
    seed(tmp_path, ["m/top.go", "m/a.go"])
    res = run_gofumpt(["-l", "."], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "m/a.go\nm/top.go\n"
    # CATCHES: matching the module directory itself against its own directive
    # would skip the whole module during a walk from its parent.


@pytest.mark.parametrize("gomod", [
    "module example.com/m\n\ngo 1.25\n\nignore ./dir\n",
    "module example.com/m\n\ngo 1.21\n\nignore ./dir\n",
    "module example.com/m\n\nignore ./dir\n",
])
def test_ignore_regardless_of_go_directive(tmp_path, gomod):
    """The ignore directive works with any (or no) go version line."""
    go_mod(tmp_path / "tree", gomod)
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/top.go\n"
    # CATCHES: gating ignore support on go >= 1.25 (or requiring a go line at
    # all) would let tree/dir/d.go through for the older spellings.


def test_ignore_does_not_match_partial_name(tmp_path):
    """``ignore dir`` needs the slashes, so ``mydir`` is not excluded."""
    go_mod(tmp_path / "tree", "module example.com/m\n\ngo 1.25\n\nignore dir\n")
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/mydir/m.go",
                    "tree/sub/mydir/sm.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/mydir/m.go\ntree/sub/mydir/sm.go\ntree/top.go\n"
    # CATCHES: a plain strings.HasSuffix(relPath, "dir") (without the slashes)
    # would also skip both mydir directories.


def test_ignored_directory_skipped_without_error(tmp_path):
    """Skipping an ignored directory produces no diagnostics at all."""
    go_mod(tmp_path / "tree", ROOTED)
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/dir/nested/n.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/top.go\n"
    assert res.stderr == ""
    # CATCHES: a re-implementation that reports the skipped directory (as a
    # warning, or as a walk error) would write something to stderr here.


def test_explicit_file_inside_ignored_directory_is_formatted(tmp_path):
    """A single file below an ignored directory can still be named directly."""
    go_mod(tmp_path / "tree", ROOTED)
    seed(tmp_path, ["tree/dir/d.go"])
    res = run_gofumpt(["-l", "tree/dir/d.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/dir/d.go\n"
    # CATCHES: applying the ignore directive to every path below the ignored
    # directory (not just to walked directories) would skip this file.


def test_directory_below_ignored_one_is_not_listed(tmp_path):
    """The walk never enters an ignored directory, so nothing below shows up."""
    go_mod(tmp_path / "tree", ROOTED)
    seed(tmp_path, ["tree/top.go", "tree/dir/d.go", "tree/dir/sub/deep/x.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/top.go\n"
    # CATCHES: an implementation that ignores only the directory itself but
    # still walks into it would list tree/dir/sub/deep/x.go.
