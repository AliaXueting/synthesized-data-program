"""Reading from standard input when no path arguments are given.

With no arguments at all gofumpt formats stdin instead of walking anything.
Stdin is treated as an explicitly named file, so it always receives gofumpt's
full rule set, it is reported under the placeholder name
``<standard input>``, and ``-w`` (which needs a real file) is rejected.
"""

from __future__ import annotations

from conftest import CLEAN, DIRTY, run_gofumpt, seed


def test_no_arguments_reads_stdin(tmp_path):
    """With no arguments the formatted source goes to stdout."""
    res = run_gofumpt([], stdin=DIRTY, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == CLEAN
    assert res.stderr == ""
    # CATCHES: a re-implementation that requires a path argument (or that
    # writes nothing when stdin is not a terminal) would print nothing.


def test_stdin_list_reports_placeholder_name(tmp_path):
    """-l names the standard input ``<standard input>``."""
    res = run_gofumpt(["-l"], stdin=DIRTY, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "<standard input>\n"
    assert res.stderr == ""
    # CATCHES: using the empty string (or "stdin") as the file name would make
    # -l print a different line here.


def test_stdin_list_is_quiet_for_clean_source(tmp_path):
    """-l prints nothing when stdin is already gofumpt-clean."""
    res = run_gofumpt(["-l"], stdin=CLEAN, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    # CATCHES: a re-implementation that always echoes the input name under -l
    # would print "<standard input>" here.


def test_write_flag_with_stdin_is_rejected(tmp_path):
    """-w cannot work without a file to rewrite."""
    res = run_gofumpt(["-w"], stdin=DIRTY, cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == "error: cannot use -w with standard input\n"
    # CATCHES: a re-implementation that ignores the combination would print
    # the formatted source to stdout and exit 0.


def test_stdin_parse_error_uses_placeholder_name(tmp_path):
    """Parse errors on stdin are reported against ``<standard input>``."""
    res = run_gofumpt([], stdin="package p\nfunc f() {\n", cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == "<standard input>:2:12: expected '}', found 'EOF'\n"
    # CATCHES: reporting the error against an empty file name, or against the
    # process's working directory, would change the message prefix.


def test_empty_stdin_is_accepted(tmp_path):
    """Empty input produces empty output and a zero exit status."""
    res = run_gofumpt([], stdin="", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    # CATCHES: a re-implementation that reports an unexpected-EOF parse error
    # for empty stdin would exit 2 with a message.


def test_stdin_is_ignored_when_arguments_are_given(tmp_path):
    """Path arguments win; the piped input is never read."""
    seed(tmp_path, ["tree/a.go"])
    res = run_gofumpt(["tree"], stdin=DIRTY, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == CLEAN
    # CATCHES: also formatting stdin when arguments are present would print
    # the formatted source twice.
