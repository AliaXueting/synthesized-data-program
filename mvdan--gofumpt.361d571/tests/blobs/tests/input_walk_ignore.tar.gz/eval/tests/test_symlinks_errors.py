"""Symlinks encountered by the walk, and walk failures.

``filepath.WalkDir`` does not follow symbolic links: a symlink is just a
non-regular entry.  A symlink with a ``.go`` name is therefore handed to the
formatter like any other file, which either works (the target is a file) or
produces the underlying open/read error (the target is a directory or is
missing).  A symlink without a ``.go`` name is skipped silently like any other
walked non-Go file.
"""

from __future__ import annotations

import os

import pytest

from conftest import DIRTY, run_gofumpt, seed


def _symlink(target, link):
    os.symlink(target, link)
    return link


def test_symlinked_directory_is_not_followed(tmp_path):
    """A symlink to a directory is not recursed into."""
    seed(tmp_path, ["tree/realdir/inner.go", "tree/top.go"])
    _symlink("realdir", tmp_path / "tree" / "linkdir")
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/realdir/inner.go\ntree/top.go\n"
    assert res.stderr == ""
    # CATCHES: following symlinks during the walk would list the entries again
    # through tree/linkdir/inner.go (or loop forever on a self-link).


def test_symlink_to_file_with_go_name_is_formatted(tmp_path):
    """A walked symlink whose name ends in .go is formatted like a file."""
    seed(tmp_path, ["tree/target.go"])
    _symlink("target.go", tmp_path / "tree" / "link.go")
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/link.go\ntree/target.go\n"
    # CATCHES: skipping all symlinks during walks would drop tree/link.go,
    # while formatting through the target's name would print tree/target.go.


def test_symlink_to_directory_with_go_name_is_an_error(tmp_path):
    """A .go-named symlink to a directory fails when read as a file."""
    seed(tmp_path, ["tree/realdir/inner.go"])
    _symlink("realdir", tmp_path / "tree" / "linkdir.go")
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == "tree/realdir/inner.go\n"
    assert res.stderr == "read tree/linkdir.go: is a directory\n"
    # CATCHES: statting the symlink to decide it is a directory would skip it
    # instead of trying to read it and reporting the failure.


def test_broken_symlink_with_go_name_is_an_error(tmp_path):
    """A .go-named symlink whose target is missing reports the open error."""
    (tmp_path / "tree").mkdir()
    _symlink("nowhere", tmp_path / "tree" / "broken.go")
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == "open tree/broken.go: no such file or directory\n"
    # CATCHES: a walk that filters entries by whether they can be opened
    # would silently skip the broken link and exit 0.


def test_broken_symlink_without_go_name_is_skipped(tmp_path):
    """A broken symlink that does not look like Go is skipped silently."""
    (tmp_path / "tree").mkdir()
    _symlink("nowhere", tmp_path / "tree" / "brokenlink")
    seed(tmp_path, ["tree/keep.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/keep.go\n"
    assert res.stderr == ""
    # CATCHES: reporting every dangling symlink as a walk error would exit 2
    # with an "open tree/brokenlink" message.


def test_symlink_errors_do_not_hide_the_rest_of_the_walk(tmp_path):
    """The other entries of a directory are still formatted."""
    seed(tmp_path, ["tree/realdir/inner.go", "tree/target.go", "tree/top.go"])
    _symlink("nowhere", tmp_path / "tree" / "a_broken.go")
    _symlink("realdir", tmp_path / "tree" / "z_linkdir.go")
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == (
        "tree/realdir/inner.go\n"
        "tree/target.go\n"
        "tree/top.go\n"
    )
    assert res.stderr == (
        "open tree/a_broken.go: no such file or directory\n"
        "read tree/z_linkdir.go: is a directory\n"
    )
    # CATCHES: aborting the walk at the first failing entry would drop the
    # remaining files from stdout and the second error from stderr.


@pytest.mark.parametrize("arg", ["missing.go", "missing", "missing/sub/x.go"])
def test_missing_path_reports_lstat_error(tmp_path, arg):
    """A path that does not exist is reported with its cleaned spelling."""
    res = run_gofumpt([arg], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == "lstat %s: no such file or directory\n" % arg
    # CATCHES: the message must be the walk's lstat failure naming the
    # argument as given (after cleaning), not an open or stat error.


def test_missing_path_alone_writes_nothing_to_stdout(tmp_path):
    """A single missing argument exits 2 without touching stdout."""
    res = run_gofumpt(["gone"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == "lstat gone: no such file or directory\n"
    # CATCHES: a re-implementation that prints the directory contents (or an
    # empty formatted file) before failing would write to stdout.
