"""Directory exclusions applied while walking: vendor and testdata.

``shouldIgnore`` skips walked directories whose base name is exactly
``vendor`` or ``testdata``.  The check happens for directories only, and only
for entries that are not the walk root, so naming either one directly still
formats it (that part is covered by test_explicit_paths.py).
"""

from __future__ import annotations

from conftest import CLEAN, DIRTY, run_gofumpt, seed


def test_walk_skips_vendor_directories(tmp_path):
    """A vendor directory found during a walk is skipped entirely."""
    seed(tmp_path, ["tree/top.go", "tree/vendor/v.go", "tree/vendor/nested/n.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/top.go\n"
    assert res.stderr == ""
    # CATCHES: a re-implementation that formats vendor contents would also
    # print tree/vendor/v.go and tree/vendor/nested/n.go.


def test_walk_skips_testdata_directories(tmp_path):
    """A testdata directory found during a walk is skipped entirely."""
    seed(tmp_path, ["tree/top.go", "tree/testdata/t.go", "tree/testdata/nested/n.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/top.go\n"
    assert res.stderr == ""
    # CATCHES: a re-implementation that formats testdata contents would also
    # print tree/testdata/t.go and tree/testdata/nested/n.go.


def test_walk_skips_nested_vendor_and_testdata(tmp_path):
    """The exclusion applies at any depth, not only at the walk root."""
    seed(tmp_path, [
        "tree/sub/ok.go",
        "tree/sub/vendor/sv.go",
        "tree/sub/testdata/st.go",
        "tree/deep/deeper/vendor/dv.go",
    ])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/sub/ok.go\n"
    # CATCHES: only checking the immediate children of the walk root would let
    # tree/sub/vendor/sv.go and tree/deep/deeper/vendor/dv.go through.


def test_near_miss_directory_names_are_not_skipped(tmp_path):
    """vendorx/testdatax and other near-miss names are not excluded."""
    seed(tmp_path, [
        "tree/vendorx/v.go",
        "tree/testdatax/t.go",
        "tree/myvendor/m.go",
        "tree/test_data/d.go",
    ])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "tree/myvendor/m.go\n"
        "tree/test_data/d.go\n"
        "tree/testdatax/t.go\n"
        "tree/vendorx/v.go\n"
    )
    # CATCHES: prefix or substring matching on the base name would skip all
    # four of these directories.


def test_write_flag_only_touches_selected_files(tmp_path):
    """-w rewrites exactly the files the walk selected."""
    seed(tmp_path, [
        "tree/top.go",
        "tree/vendor/v.go",
        "tree/skip.txt",
        "tree/keep/k.go",
    ])
    res = run_gofumpt(["-w", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert (tmp_path / "tree" / "top.go").read_text(encoding="utf-8") == CLEAN
    assert (tmp_path / "tree" / "keep" / "k.go").read_text(encoding="utf-8") == CLEAN
    # Unselected files keep their original bytes.
    assert (tmp_path / "tree" / "vendor" / "v.go").read_text(encoding="utf-8") == DIRTY
    assert (tmp_path / "tree" / "skip.txt").read_text(encoding="utf-8") == DIRTY
    # No backup files are left behind next to the rewritten ones.
    assert sorted(p.name for p in (tmp_path / "tree").iterdir()) == [
        "keep", "skip.txt", "top.go", "vendor",
    ]
    # CATCHES: a walk that selects vendor/v.go (or the .txt file) would have
    # rewritten those too, which is observable in the on-disk contents.


def test_explicit_file_named_vendor_is_formatted(tmp_path):
    """The vendor exclusion is about directories; a file named vendor is fine."""
    seed(tmp_path, ["tree/vendor"])
    res = run_gofumpt(["-l", "tree/vendor"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/vendor\n"
    assert res.stderr == ""
    # CATCHES: skipping anything whose base name is "vendor" - without
    # checking that it is a directory - would print nothing here.


def test_walk_root_below_an_excluded_directory_is_reached(tmp_path):
    """A directory beneath vendor is walked normally when named directly."""
    seed(tmp_path, ["tree/vendor/sub/a.go", "tree/vendor/sub/vendor/b.go"])
    res = run_gofumpt(["-l", "tree/vendor/sub"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/vendor/sub/a.go\n"
    # CATCHES: excluding by path prefix ("anything under vendor/") would skip
    # tree/vendor/sub/a.go even though it is below an explicit root.
