"""Explicit arguments: the path named on the command line itself.

Everything found *beneath* an argument is "walked"; the argument's own entry
is "explicit".  That distinction drives two relaxations: an explicit entry is
formatted whatever its name (so ``gofumpt -w foo.go.txt`` works), and an
explicit directory bypasses the vendor/testdata/go.mod-ignore exclusions that
would otherwise skip it during a walk.
"""

from __future__ import annotations

import os

from conftest import CLEAN, DIRTY, go_mod, run_gofumpt, seed


def test_explicit_non_go_file_is_formatted(tmp_path):
    """A file named directly is parsed as Go whatever its extension."""
    seed(tmp_path, ["src.txt"])
    res = run_gofumpt(["src.txt"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == CLEAN
    assert res.stderr == ""
    # CATCHES: a re-implementation that applies the .go name test to explicit
    # arguments too would print nothing at all.


def test_explicit_extensionless_and_hidden_files_are_formatted(tmp_path):
    """Dotfiles and files without any extension are formatted when explicit."""
    seed(tmp_path, ["Makefile", ".hidden"])
    res = run_gofumpt(["Makefile", ".hidden"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == CLEAN + CLEAN
    # CATCHES: rejecting a leading dot or a missing extension for explicit
    # arguments would drop one of the two formatted copies.


def test_explicit_file_inside_vendor_is_formatted(tmp_path):
    """A single file below a vendor directory can still be named directly."""
    seed(tmp_path, ["vendor/inner.go"])
    res = run_gofumpt(["-l", "vendor/inner.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "vendor/inner.go\n"
    # CATCHES: applying the vendor exclusion by path *prefix* rather than to
    # walked directories only would skip this explicit file.


def test_explicit_file_inside_testdata_is_formatted(tmp_path):
    """A single file below a testdata directory can still be named directly."""
    seed(tmp_path, ["testdata/inner.go"])
    res = run_gofumpt(["-l", "testdata/inner.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "testdata/inner.go\n"
    # CATCHES: applying the testdata exclusion by path prefix would skip this
    # explicit file and print nothing.


def test_explicit_vendor_directory_is_walked(tmp_path):
    """Naming ``vendor`` itself formats its contents."""
    seed(tmp_path, ["vendor/a.go", "vendor/sub/b.go"])
    res = run_gofumpt(["-l", "vendor"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "vendor/a.go\nvendor/sub/b.go\n"
    # CATCHES: excluding vendor unconditionally would print nothing here.


def test_explicit_testdata_directory_is_walked(tmp_path):
    """Naming ``testdata`` itself formats its contents."""
    seed(tmp_path, ["testdata/a.go"])
    res = run_gofumpt(["-l", "testdata"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "testdata/a.go\n"
    # CATCHES: excluding testdata unconditionally would print nothing here.


def test_unclean_vendor_spelling_is_still_explicit(tmp_path):
    """Unclean spellings of an excluded directory still count as explicit."""
    seed(tmp_path, ["tree/vendor/a.go"])
    for arg in ["tree//vendor", "tree/./vendor/", "./tree/vendor/"]:
        res = run_gofumpt(["-l", arg], cwd=tmp_path)
        assert res.returncode == 0, arg
        assert res.stdout == "tree/vendor/a.go\n", arg
    # CATCHES: comparing the raw argument against "vendor" (instead of the
    # cleaned walk root) would treat these spellings as walked and skip them.


def test_nested_vendor_below_explicit_vendor_root_is_skipped(tmp_path):
    """Only the walk root is explicit; a deeper vendor directory is skipped."""
    seed(tmp_path, ["vendor/a.go", "vendor/sub/b.go", "vendor/sub/vendor/c.go"])
    res = run_gofumpt(["-l", "vendor"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "vendor/a.go\nvendor/sub/b.go\n"
    # CATCHES: treating everything under an explicit vendor root as explicit
    # would also list vendor/sub/vendor/c.go.


def test_explicit_ignored_directory_formats_whole_subtree(tmp_path):
    """A directory excluded by go.mod is formatted when named directly."""
    go_mod(tmp_path, "module example.com/m\n\ngo 1.25\n\nignore ./skipme\n")
    seed(tmp_path, ["skipme/a.go", "skipme/deep/b.go", "keep.go"])
    res = run_gofumpt(["-l", "skipme"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "skipme/a.go\nskipme/deep/b.go\n"
    # CATCHES: honouring the ignore directive for the argument itself would
    # print nothing, so `gofumpt -w skipme` could not reformat it.


def test_dash_prefixed_path_after_double_dash(tmp_path):
    """``--`` lets an argument start with a dash."""
    seed(tmp_path, ["-weird.go"])
    res = run_gofumpt(["-l", "--", "-weird.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "-weird.go\n"
    # CATCHES: a re-implementation whose flag parser consumes the path after
    # "--" (or treats it as a flag) would fail with a flag error instead.


def test_explicit_symlink_to_file_is_formatted(tmp_path):
    """A symlink to a Go file, named directly, is followed and formatted."""
    seed(tmp_path, ["target.go"])
    os.symlink("target.go", tmp_path / "link.go")
    res = run_gofumpt(["-l", "link.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "link.go\n"
    # CATCHES: refusing to lstat-follow symlinks for explicit arguments would
    # report the file as missing.


def test_explicit_symlink_to_directory_reports_read_error(tmp_path):
    """A symlink to a directory is not a directory for the walk root."""
    seed(tmp_path, ["realdir/inner.go"])
    os.symlink("realdir", tmp_path / "linkdir")
    res = run_gofumpt(["-l", "linkdir"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == "read linkdir: is a directory\n"
    # CATCHES: following the symlink with Stat instead of Lstat would walk the
    # directory and list realdir/inner.go.


def test_explicit_empty_go_file_is_a_parse_error(tmp_path):
    """An explicit but empty file fails to parse with the file's name."""
    (tmp_path / "empty.go").write_text("", encoding="utf-8")
    res = run_gofumpt(["empty.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == "empty.go:1:1: expected 'package', found 'EOF'\n"
    # CATCHES: silently skipping unparseable or empty explicit files would
    # exit 0 with no message instead.


def test_explicit_non_go_file_parse_error_names_the_file(tmp_path):
    """Parse errors for explicit non-.go arguments name that argument."""
    (tmp_path / "notes.txt").write_text("not go at all\n", encoding="utf-8")
    res = run_gofumpt(["notes.txt"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == "notes.txt:1:1: expected 'package', found not\n"
    # CATCHES: reporting the error against a synthesized name (or against
    # "<standard input>") would lose the argument spelling.


def test_write_flag_on_explicit_non_go_file(tmp_path):
    """-w rewrites an explicit non-.go argument, which is the documented use."""
    seed(tmp_path, ["notes.go.txt"])
    res = run_gofumpt(["-w", "notes.go.txt"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    assert (tmp_path / "notes.go.txt").read_text(encoding="utf-8") == CLEAN
    assert sorted(p.name for p in tmp_path.iterdir()) == ["notes.go.txt"]
    # CATCHES: rejecting non-.go arguments under -w (or writing to a
    # synthesized .go name) would leave the original bytes untouched.


def test_trailing_slash_on_a_file_argument_is_cleaned(tmp_path):
    """A file argument spelled with a trailing slash is still that file."""
    seed(tmp_path, ["src.go"])
    res = run_gofumpt(["-l", "src.go/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "src.go\n"
    assert res.stderr == ""
    # CATCHES: keeping the trailing slash would make the path a directory for
    # the walk and produce a "read src.go/: is a directory" error.


def test_walked_parse_error_does_not_hide_sibling(tmp_path):
    """A broken file in a walk is reported while its sibling is still printed."""
    (tmp_path / "bad.go").write_text("junk\n", encoding="utf-8")
    seed(tmp_path, ["good.go"])
    res = run_gofumpt(["."], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == CLEAN
    assert res.stderr == "bad.go:1:1: expected 'package', found junk\n"
    # CATCHES: letting one file's error abort the walk would drop good.go's
    # formatted output from stdout.
