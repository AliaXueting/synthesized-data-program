"""Recursive walking of the path arguments and which files it selects.

gofumpt hands every non-flag argument to ``filepath.WalkDir`` after cleaning
it, so the interesting behaviour is the callback's filtering: only walked
entries whose base name ends in ``.go`` and does not start with ``.`` are
formatted, directories are always recursed into, and the walk order is the
lexical order of the directory entries.
"""

from __future__ import annotations

from conftest import CLEAN, run_gofumpt, seed


def test_walk_formats_go_files_recursively(tmp_path):
    """A directory argument is walked recursively and lists every .go file."""
    seed(tmp_path, ["tree/a.go", "tree/sub/b.go", "tree/sub/deep/c.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/a.go\ntree/sub/b.go\ntree/sub/deep/c.go\n"
    assert res.stderr == ""
    # CATCHES: a re-implementation that only looks at the top level of a
    # directory argument, or that forgets to recurse into subdirectories,
    # would only report tree/a.go.


def test_walk_visits_entries_in_lexical_byte_order(tmp_path):
    """Walk order is the byte order of the entry names, not case-insensitive."""
    seed(tmp_path, ["tree/Z.go", "tree/a.go", "tree/A.go", "tree/0.go",
                    "tree/_.go", "tree/-.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "tree/-.go\n"
        "tree/0.go\n"
        "tree/A.go\n"
        "tree/Z.go\n"
        "tree/_.go\n"
        "tree/a.go\n"
    )
    # CATCHES: sorting names case-insensitively or locale-aware would put
    # a.go next to A.go and drop the '-'/'0'/'_' entries to the wrong places.


def test_walk_recurses_depth_first_in_name_order(tmp_path):
    """A subdirectory is recursed where it appears, between its siblings."""
    seed(tmp_path, ["tree/a.go", "tree/b/x.go", "tree/b/z/y.go", "tree/c.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == (
        "tree/a.go\n"
        "tree/b/x.go\n"
        "tree/b/z/y.go\n"
        "tree/c.go\n"
    )
    # CATCHES: walking files before directories (breadth-first) would print
    # a.go, c.go and only then the b/ subtree.


def test_walk_skips_files_without_go_suffix(tmp_path):
    """Walked files that are not Go sources are skipped silently."""
    seed(tmp_path, ["tree/keep.go", "tree/notes.txt", "tree/Makefile",
                    "tree/noext"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/keep.go\n"
    assert res.stderr == ""
    # CATCHES: a re-implementation that reports skipped files, or that parses
    # every walked file regardless of its name, would print extra lines.


def test_walk_skips_dot_prefixed_go_files(tmp_path):
    """A leading dot in the base name disqualifies a walked .go file."""
    seed(tmp_path, ["tree/keep.go", "tree/.hidden.go", "tree/.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/keep.go\n"
    assert res.stderr == ""
    # CATCHES: checking only the .go suffix would also format .hidden.go and
    # the file literally named ".go".


def test_walk_go_suffix_is_case_sensitive(tmp_path):
    """Only a lowercase ``.go`` suffix counts; ``.GO`` and ``.go.txt`` do not."""
    seed(tmp_path, ["tree/keep.go", "tree/upper.GO", "tree/double.go.txt",
                    "tree/backup.go.bak"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/keep.go\n"
    # CATCHES: a case-insensitive suffix test (or a "contains .go" test)
    # would pick up upper.GO and double.go.txt as well.


def test_walk_enters_dot_named_directory(tmp_path):
    """The dot rule applies to file names only, not to directory names."""
    seed(tmp_path, ["tree/keep.go", "tree/.hid/inner.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/.hid/inner.go\ntree/keep.go\n"
    # CATCHES: filtering whole directories by the file-name rule would skip
    # .hid/ and lose tree/.hid/inner.go.


def test_walk_recurses_into_directory_named_like_go_file(tmp_path):
    """A directory called ``d.go`` is recursed into, not formatted."""
    seed(tmp_path, ["tree/keep.go", "tree/d.go/inner.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/d.go/inner.go\ntree/keep.go\n"
    # CATCHES: a walk that treats any *.go name as a file would fail to open
    # the directory and report an error instead of listing its contents.


def test_walk_formats_vendor_go_and_testdata_go_filenames(tmp_path):
    """Files named vendor.go/testdata.go are formatted; only the directories are excluded."""
    seed(tmp_path, ["tree/vendor.go", "tree/testdata.go", "tree/vendor/inner.go",
                    "tree/testdata/inner.go"])
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "tree/testdata.go\ntree/vendor.go\n"
    # CATCHES: matching the *substring* "vendor"/"testdata" instead of the
    # exact base name would drop tree/vendor.go and tree/testdata.go.


def test_walk_of_directory_without_go_files_is_silent(tmp_path):
    """Walking a directory without matching files prints nothing, exits 0."""
    (tmp_path / "tree").mkdir()
    (tmp_path / "tree" / "notes.txt").write_text("hello\n", encoding="utf-8")
    res = run_gofumpt(["-l", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == ""
    assert res.stderr == ""
    # CATCHES: a re-implementation that echoes the directory itself, or that
    # fails to exit cleanly on a matchless walk, would differ here.


def test_multiple_arguments_processed_in_given_order(tmp_path):
    """Arguments are walked one after another, in the order given."""
    seed(tmp_path, ["one/a.go", "one/sub/b.go", "two/c.go"])
    res = run_gofumpt(["-l", "two", "one"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "two/c.go\none/a.go\none/sub/b.go\n"
    # CATCHES: sorting or de-duplicating the arguments before walking would
    # emit the "one" tree first.


def test_duplicate_argument_is_processed_twice(tmp_path):
    """The same path given twice is formatted twice."""
    seed(tmp_path, ["tree/a.go"])
    res = run_gofumpt(["tree/a.go", "tree/a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == CLEAN + CLEAN
    assert res.stderr == ""
    # CATCHES: collapsing duplicate arguments (as a set of paths) would print
    # the formatted source only once.


def test_redundant_separators_are_cleaned(tmp_path):
    """Unclean argument spellings still name the same walk root."""
    seed(tmp_path, ["tree/sub/a.go"])
    for arg in ["tree//sub", "tree/./sub/", "tree/sub/../sub"]:
        res = run_gofumpt(["-l", arg], cwd=tmp_path)
        assert res.returncode == 0, arg
        assert res.stdout == "tree/sub/a.go\n", arg
        assert res.stderr == "", arg
    # CATCHES: without path cleaning the walked paths would keep the double
    # slashes and "./" segments, so the echoed file name would differ.


def test_dot_argument_walks_working_directory(tmp_path):
    """``.`` walks the process working directory and prints relative names."""
    seed(tmp_path, ["a.go", "sub/b.go"])
    res = run_gofumpt(["-l", "."], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "a.go\nsub/b.go\n"
    # CATCHES: joining the root onto every entry without cleaning would
    # produce names like "./a.go" instead of "a.go".


def test_dotdot_argument_walks_parent(tmp_path):
    """A ``..`` argument is cleaned and walked like any other directory."""
    seed(tmp_path, ["a.go", "sub/b.go"])
    res = run_gofumpt(["-l", ".."], cwd=tmp_path / "sub")
    assert res.returncode == 0
    assert res.stdout == "../a.go\n../sub/b.go\n"
    # CATCHES: not cleaning ".." would keep it as part of the walked paths and
    # the echoed names would start with "../..".


def test_empty_string_argument_behaves_like_dot(tmp_path):
    """An empty argument is cleaned to ``.`` and walks the working directory."""
    seed(tmp_path, ["a.go", "sub/b.go"])
    res = run_gofumpt(["-l", ""], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "a.go\nsub/b.go\n"
    # CATCHES: rejecting the empty argument (or treating it as a missing file)
    # would print a lstat error and exit 2 instead of walking.


def test_absolute_argument_prints_absolute_paths(tmp_path):
    """An absolute argument is walked and the echoed paths stay absolute."""
    seed(tmp_path, ["tree/a.go"])
    res = run_gofumpt(["-l", str(tmp_path / "tree")], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == "%s/tree/a.go\n" % tmp_path
    # CATCHES: re-implementations that re-root the walked paths relative to
    # the working directory would print "tree/a.go" instead.


def test_walk_error_does_not_stop_later_arguments(tmp_path):
    """A failing argument is reported but the remaining ones are still walked."""
    seed(tmp_path, ["good/a.go"])
    res = run_gofumpt(["-l", "missing", "good"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == "good/a.go\n"
    assert res.stderr == "lstat missing: no such file or directory\n"
    # CATCHES: aborting the whole run on the first walk error would lose
    # good/a.go from stdout.


def test_diff_flag_names_the_walked_path(tmp_path):
    """-d headers the diff with the path exactly as the walk produced it."""
    seed(tmp_path, ["tree/a.go"])
    res = run_gofumpt(["-d", "tree"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == ""
    assert res.stdout == (
        "diff tree/a.go.orig tree/a.go\n"
        "--- tree/a.go.orig\n"
        "+++ tree/a.go\n"
        "@@ -1,7 +1,6 @@\n"
        " package p\n"
        " \n"
        " func f() {\n"
        "-\n"
        "-\tvar x = 1\n"
        "+\tx := 1\n"
        " \t_ = x\n"
        " }\n"
    )
    # CATCHES: a walk that echoes paths relative to the working directory (or
    # with the cleaned argument spelled differently) would change the header.


def test_every_missing_argument_is_reported(tmp_path):
    """Each missing argument produces its own error line, in order."""
    res = run_gofumpt(["nope1", "nope2"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == ""
    assert res.stderr == (
        "lstat nope1: no such file or directory\n"
        "lstat nope2: no such file or directory\n"
    )
    # CATCHES: reporting only the first failure, or exiting before the second
    # walk, would drop the second lstat line.
