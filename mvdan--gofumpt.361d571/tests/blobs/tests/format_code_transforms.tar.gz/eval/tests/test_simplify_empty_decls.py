"""Empty declaration groups such as ``var ()`` are removed.

The removal only happens for groups with no specs and no comments inside.
"""

EMPTY_DECLS_SRC = """\
package p

var ()
const (
)
type ()

func f() {}
"""

EMPTY_DECLS_OUT = b"package p\n\nfunc f() {}\n"

KEPT_DECLS_SRC = """\
package p

var (
\t// keep me
)
const (
\t// keep me too
)

func f() {}
"""

KEPT_DECLS_OUT = (
    b"package p\n"
    b"\n"
    b"var (\n"
    b"// keep me\n"
    b")\n"
    b"\n"
    b"const (\n"
    b"// keep me too\n"
    b")\n"
    b"\n"
    b"func f() {}\n"
)


def test_empty_decl_groups_removed(run):
    """var (), const () and type () vanish entirely from the output.

    CATCHES: a re-implementation that keeps empty declaration groups, or only
    removes the parentheses while leaving a bare ``var`` keyword behind.
    """
    result = run([], stdin=EMPTY_DECLS_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == EMPTY_DECLS_OUT
    assert result.stderr == b""


def test_empty_decl_group_with_comment_kept(run):
    """An empty group holding a comment is not empty, so it stays.

    CATCHES: removing the group anyway, which would silently delete the
    user's comment.
    """
    result = run([], stdin=KEPT_DECLS_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == KEPT_DECLS_OUT


def test_empty_decl_groups_between_declarations(run):
    """Empty groups between real declarations disappear without a trace.

    CATCHES: leaving a blank line or a stray keyword where the empty group
    used to be, which would change the spacing of the remaining decls.
    """
    src = (
        b"package p\n"
        b"\n"
        b"var ()\n"
        b"\n"
        b"const ()\n"
        b"\n"
        b"var x = 1\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"package p\n\nvar x = 1\n"


def test_empty_import_group_removed(run):
    """An empty ``import ()`` group is dropped like the other empty groups.

    CATCHES: an implementation that only strips var/const/type, leaving an
    empty import declaration in the output.
    """
    src = b"package p\n\nimport (\n)\n\nfunc f() {}\n"
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"package p\n\nfunc f() {}\n"


def test_file_with_only_an_empty_group(run):
    """A file whose only declaration is empty is left with just the package.

    CATCHES: an implementation that emits nothing at all, or that keeps a
    trailing blank line after the package clause.
    """
    result = run([], stdin=b"package p\n\nvar ()\n")
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"package p\n"


def test_empty_decl_group_removal_is_idempotent(run):
    """The removal does not disturb anything on a second pass.

    CATCHES: a rewrite that only removes the first empty group per run, or
    that breaks the output of its own first run.
    """
    first = run([], stdin=EMPTY_DECLS_SRC.encode())
    second = run([], stdin=first.stdout)
    assert second.returncode == 0, second.stderr
    assert second.stdout == EMPTY_DECLS_OUT
