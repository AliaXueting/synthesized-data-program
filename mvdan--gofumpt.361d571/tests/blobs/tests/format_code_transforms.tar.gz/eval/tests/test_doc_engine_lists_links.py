"""Doc comment engine corners: list shapes, link definitions, old-style
headings and quote conversion.

These exercise the vendored go/doc/comment printer/parser paths beyond the
basic paragraph/code reflow: loose and numbered lists, multi-paragraph list
items, link-definition blocks, the old-style heading -> "# " conversion and
the `` '' -> curly-quote rewrite.
"""

LOOSE_SRC = """\
package p

// A loose list:
//
//   - one
//
//   - two
func f() {}
"""

NUMBERED_SRC = """\
package p

// Numbered:
//
//   1. one
//   2. two
func f() {}
"""

NUMBERED_OUT = (
    b"package p\n"
    b"\n"
    b"// Numbered:\n"
    b"//\n"
    b"//  1. one\n"
    b"//  2. two\n"
    b"func f() {}\n"
)

STAR_SRC = """\
package p

// Star bullets:
//
//   * one
//   * two
func f() {}
"""

STAR_OUT = (
    b"package p\n"
    b"\n"
    b"// Star bullets:\n"
    b"//\n"
    b"//   - one\n"
    b"//   - two\n"
    b"func f() {}\n"
)

TWO_PARA_SRC = """\
package p

// Two para item:
//
//   - first paragraph
//
//     second paragraph
func f() {}
"""

MIXED_SRC = """\
package p

// Mixed markers:
//
//   1. one
//   - two
func f() {}
"""

MIXED_OUT = (
    b"package p\n"
    b"\n"
    b"// Mixed markers:\n"
    b"//\n"
    b"//  1. one\n"
    b"//     - two\n"
    b"func f() {}\n"
)

DEFS_BOTH_USED_SRC = """\
package p

// See [Go] and [Py].
//
// [Go]: https://go.dev
// [Py]: https://python.org
func f() {}
"""

DEFS_ONE_USED_SRC = """\
package p

// See [Go].
//
// [Go]: https://go.dev
// [Py]: https://python.org
func f() {}
"""

DEFS_ONE_USED_OUT = (
    b"package p\n"
    b"\n"
    b"// See [Go].\n"
    b"//\n"
    b"// [Go]: https://go.dev\n"
    b"//\n"
    b"// [Py]: https://python.org\n"
    b"func f() {}\n"
)

DEFS_MIDDLE_SRC = """\
package p

// Intro.
//
// [Go]: https://go.dev
//
// Outro uses [Go].
func f() {}
"""

DEFS_MIDDLE_OUT = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"// Outro uses [Go].\n"
    b"//\n"
    b"// [Go]: https://go.dev\n"
    b"func f() {}\n"
)

DOC_LINKS_SRC = """\
package p

// See [*fmt.Stringer], [Recv.Method], word[math.Sin], [Foo], [bytes.Buffer].
func f() {}
"""

OLD_HEADING_SRC = """\
package p

// Intro text.
//
// Section Heading Here
//
// More text after.
func f() {}
"""

OLD_HEADING_OUT = (
    b"package p\n"
    b"\n"
    b"// Intro text.\n"
    b"//\n"
    b"// # Section Heading Here\n"
    b"//\n"
    b"// More text after.\n"
    b"func f() {}\n"
)

OLD_HEADING_DOT_SRC = """\
package p

// Text.
//
// Foo.Bar Baz
//
// More.
func f() {}
"""

OLD_HEADING_DOT_OUT = (
    b"package p\n"
    b"\n"
    b"// Text.\n"
    b"//\n"
    b"// # Foo.Bar Baz\n"
    b"//\n"
    b"// More.\n"
    b"func f() {}\n"
)

OLD_HEADING_REJECTS_SRC = """\
package p

// Intro text.
//
// Not a heading: colon
//
// also not heading
//
// 1.5 starts with digit
//
// End.
func f() {}
"""

QUOTES_SRC = "package p\n\n// Use ``quoted'' and [math.Sin] and [math/rand.Sqrt] plus [fmt] here.\nfunc f() {}\n"

QUOTES_OUT = (
    "package p\n"
    "\n"
    "// Use “quoted” and [math.Sin] and [math/rand.Sqrt] plus [fmt] here.\n"
    "func f() {}\n"
).encode()


def test_loose_list_keeps_blank_lines_between_items(run):
    """A blank line between list items survives; the list stays loose.

    CATCHES: an implementation that normalizes every list to tight form,
    dropping the blank lines the author put between items.
    """
    result = run([], stdin=LOOSE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == LOOSE_SRC.encode()
    assert result.stderr == b""


def test_numbered_list_normalized_to_one_space_indent(run):
    """Numbered items keep their numbers and print with a single space.

    CATCHES: an implementation that renumbers items as dashes or prints the
    ``1.`` marker with the bullet-style two-space indent.
    """
    result = run([], stdin=NUMBERED_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == NUMBERED_OUT


def test_star_bullets_normalized_to_dashes(run):
    """``*`` bullet markers are rewritten to the canonical ``-`` marker.

    CATCHES: an implementation that keeps the author's bullet character
    instead of normalizing every unnumbered item to a dash.
    """
    result = run([], stdin=STAR_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == STAR_OUT


def test_list_item_second_paragraph_kept_indented(run):
    """A second paragraph in a list item stays, indented by four spaces.

    CATCHES: an implementation that drops the continuation paragraph or
    prints it at the item's dash column instead of the four-space indent.
    """
    result = run([], stdin=TWO_PARA_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == TWO_PARA_SRC.encode()


def test_mixed_markers_absorb_dash_into_numbered_item(run):
    """A dash line after a numbered item becomes part of that item.

    CATCHES: an implementation that starts a second (bullet) list for the
    ``- two`` line instead of treating it as a continuation paragraph of
    item one.
    """
    result = run([], stdin=MIXED_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == MIXED_OUT


def test_link_definitions_used_and_unused_reordered(run):
    """Used link defs print as one block after the text, unused ones last.

    CATCHES: an implementation that leaves definitions where they were
    written, or that drops the blank line between the used and unused
    definition blocks.
    """
    both = run([], stdin=DEFS_BOTH_USED_SRC.encode())
    assert both.returncode == 0, both.stderr
    assert both.stdout == DEFS_BOTH_USED_SRC.encode()

    one = run([], stdin=DEFS_ONE_USED_SRC.encode())
    assert one.returncode == 0, one.stderr
    assert one.stdout == DEFS_ONE_USED_OUT


def test_link_definition_between_paragraphs_moves_to_end(run):
    """A definition block written mid-comment is reprinted after the text.

    CATCHES: an implementation that keeps the definition paragraph between
    the two text paragraphs instead of collecting all definitions at the
    end of the doc comment.
    """
    result = run([], stdin=DEFS_MIDDLE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == DEFS_MIDDLE_OUT


def test_doc_links_and_non_links_roundtrip(run):
    """Doc links to std symbols round-trip; unresolved brackets stay text.

    CATCHES: an implementation that escapes or drops the brackets around
    [pkg.Sym] forms, or one that turns plain bracketed prose like [Foo] or
    word[math.Sin] into links.
    """
    result = run([], stdin=DOC_LINKS_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == DOC_LINKS_SRC.encode()


def test_old_style_heading_converted_to_hash(run):
    """A surrounded all-caps-style heading line gains the ``# `` prefix.

    CATCHES: an implementation that misses the pre-Go-1.19 heading syntax,
    leaving the heading line as a plain paragraph without ``# ``.
    """
    result = run([], stdin=OLD_HEADING_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == OLD_HEADING_OUT


def test_old_style_heading_allows_inner_dots(run):
    """Dots followed by a non-space do not disqualify an old heading.

    CATCHES: an implementation that rejects any heading line containing a
    period, diverging on ``Foo.Bar Baz`` which the engine accepts.
    """
    result = run([], stdin=OLD_HEADING_DOT_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == OLD_HEADING_DOT_OUT


def test_old_style_heading_rejections(run):
    """Colons, lowercase starts, digit starts stay plain paragraphs.

    CATCHES: an implementation that converts any short line between blanks
    into a heading, ignoring the punctuation and capitalization rules.
    """
    result = run([], stdin=OLD_HEADING_REJECTS_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == OLD_HEADING_REJECTS_SRC.encode()


def test_double_backticks_and_quotes_become_curly(run):
    """`` `` `` and ``''`` pairs are rewritten to Unicode curly quotes.

    CATCHES: an implementation that leaves ASCII double-backtick/quote
    pairs in doc text instead of converting them to “ and ”.
    """
    result = run([], stdin=QUOTES_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == QUOTES_OUT
