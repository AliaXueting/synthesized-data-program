"""Where a comment sits decides who formats it.

gofumpt adds the ``// `` space itself, but a comment group in the first
column that ends right before a token (a closing bracket included) is
instead formatted by go/printer as a doc comment, which also reflows its
lists and separates it from the preceding line.  An indented group never
gets that treatment, and neither does a group whose last line already
starts with a space.  Empty ``//`` groups are dropped only when they sit
right before such a token, and build-constraint lines are split out of a
mixed comment group before anything is printed.
"""

# A comment at column 1 inside a call's argument list: go/printer treats it
# as a doc comment, so it stays unindented and a blank line separates it
# from the argument above.
CALL_COL1_SRC = b"package p\n\nvar x = f(\n\t1,\n//foo\n)\n"
CALL_COL1_OUT = (
    b"package p\n"
    b"\n"
    b"var x = f(\n"
    b"\t1,\n"
    b"\n"
    b"// foo\n"
    b")\n"
)

# The same comment indented is an ordinary floating comment: no blank line,
# and it keeps the body's indentation.
CALL_IND_SRC = b"package p\n\nvar x = f(\n\t1,\n\t//foo\n)\n"
CALL_IND_OUT = (
    b"package p\n"
    b"\n"
    b"var x = f(\n"
    b"\t1,\n"
    b"\t// foo\n"
    b")\n"
)

# A column-1 group before a composite literal's closing brace is
# doc-formatted, so its list items are re-indented to the doc printer's
# three-space marker column.
LIT_COL1_SRC = (
    b"package p\n\nvar x = []int{\n\t1,\n//Foo bar.\n//  - a\n//  - b\n}\n"
)
LIT_COL1_OUT = (
    b"package p\n"
    b"\n"
    b"var x = []int{\n"
    b"\t1,\n"
    b"\t// Foo bar.\n"
    b"\t//   - a\n"
    b"\t//   - b\n"
    b"}\n"
)

# Indented, the very same group only gains the space after "//"; the list
# keeps its original two-space indentation.
LIT_IND_SRC = (
    b"package p\n\nvar x = []int{\n\t1,\n\t//Foo bar.\n\t//  - a\n"
    b"\t//  - b\n}\n"
)
LIT_IND_OUT = (
    b"package p\n"
    b"\n"
    b"var x = []int{\n"
    b"\t1,\n"
    b"\t// Foo bar.\n"
    b"\t//  - a\n"
    b"\t//  - b\n"
    b"}\n"
)

# Comments at column 1 inside parentheses, type assertions, index
# expressions and a generic type's brackets.  Each closing token counts as
# a doc token, so each group is measured and printed differently from a
# plain indented comment: one tab for brackets, and the parenthesised
# expression pulls the comment in with it.
BRACKETS_SRC = (
    b"package p\n\n"
    b"var m = map[string]int{}\n\n"
    b"func g(x any) {\n"
    b"\t_ = x.(\n"
    b"//foo\n"
    b"\tint)\n"
    b"\t_ = m[\n"
    b"//bar\n"
    b'\t"k"]\n'
    b"}\n\n"
    b"func h() {\n"
    b"\t_ = (1 +\n"
    b"//baz\n"
    b"\t2)\n"
    b"}\n\n"
    b"type L[K, V any] struct{}\n\n"
    b"var v L[\n"
    b"//qux\n"
    b"int, string]\n"
)
BRACKETS_OUT = (
    b"package p\n"
    b"\n"
    b"var m = map[string]int{}\n"
    b"\n"
    b"func g(x any) {\n"
    b"\t_ = x.(\n"
    b"\t// foo\n"
    b"\tint)\n"
    b"\t_ = m[\n"
    b"\t// bar\n"
    b'\t"k"]\n'
    b"}\n"
    b"\n"
    b"func h() {\n"
    b"\t_ = (1 +\n"
    b"\t\t// baz\n"
    b"\t\t2)\n"
    b"}\n"
    b"\n"
    b"type L[K, V any] struct{}\n"
    b"\n"
    b"var v L[\n"
    b"\t// qux\n"
    b"\tint, string]\n"
)

# An empty comment group before a statement that is indented (so the group
# does not end right before a token) is kept.
EMPTY_KEPT_SRC = b"package p\n\nfunc f() {\n//\nx := 1\n_ = x\n}\n"
EMPTY_KEPT_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t//\n"
    b"\tx := 1\n"
    b"\t_ = x\n"
    b"}\n"
)

# The same empty group right before a top-level token is dropped, like
# go/printer drops an empty doc comment.
EMPTY_VAR_SRC = b"package p\n\n//\nvar x = 1\n"
EMPTY_VAR_OUT = b"package p\n\nvar x = 1\n"

EMPTY_RBRACE_SRC = b"package p\n\nfunc f() {\n//\n}\n"
EMPTY_RBRACE_OUT = b"package p\n\nfunc f() {\n}\n"

EMPTY_IMPORT_SRC = b"package p\n\nimport (\n\t\"fmt\"\n//\n)\n"
EMPTY_IMPORT_OUT = b"package p\n\nimport (\n\t\"fmt\"\n)\n"

# A /* */ doc comment is never pushed through the doc engine: even when it
# is indented (so go/printer would not format it either) it is kept
# verbatim, only re-indented to the declaration's column.
INDENTED_BLOCK_DOC_SRC = b"package p\n\n\t/* doc */\nvar x = 1\n"
INDENTED_BLOCK_DOC_OUT = b"package p\n\n/* doc */\nvar x = 1\n"

# An indented doc comment with text is formatted by gofumpt itself, since
# go/printer only formats first-column groups; the result matches what a
# column-1 doc comment would print.
INDENTED_LIST_DOC_SRC = b"package p\n\n\t// Foo.\n\t//  - a\nvar x = 1\n"
INDENTED_LIST_DOC_OUT = b"package p\n\n// Foo.\n//   - a\nvar x = 1\n"
COL1_LIST_DOC_SRC = b"package p\n\n// Foo.\n//  - a\nvar x = 1\n"

# An indented doc comment without any text is dropped, exactly like the
# column-1 one above.
INDENTED_EMPTY_DOC_SRC = b"package p\n\n\t//\nvar x = 1\n"
INDENTED_EMPTY_DOC_OUT = b"package p\n\nvar x = 1\n"

# A //go:build line in the middle of a doc comment is split into its own
# group, which go/printer then moves above the package clause; the prose
# lines it leaves behind stay adjacent, with no empty "//" line inserted.
BC_MID_SRC = b"package p\n\n// Foo.\n//go:build linux\n// More.\nfunc F() {}\n"
BC_MID_OUT = (
    b"//go:build linux\n"
    b"\n"
    b"package p\n"
    b"\n"
    b"// Foo.\n"
    b"// More.\n"
    b"func F() {}\n"
)

# With explicit "//" separator lines the paragraphs around the build line
# survive as separate paragraphs.
BC_PARA_SRC = (
    b"package p\n\n// Foo does things.\n//\n//go:build linux\n//\n"
    b"// More docs.\nfunc F() {}\n"
)
BC_PARA_OUT = (
    b"//go:build linux\n"
    b"\n"
    b"package p\n"
    b"\n"
    b"// Foo does things.\n"
    b"//\n"
    b"// More docs.\n"
    b"func F() {}\n"
)

# A blank line after the build lines leaves one blank line behind once the
# build lines are moved away, while a doc group that ends on the build
# lines' last line stays glued to its declaration.
BC_BLANK_AFTER_SRC = (
    b"package p\n\n// Doc for F.\n//go:build linux\n// +build linux\n\n"
    b"func G() {}\n\nfunc F() {}\n"
)
BC_BLANK_AFTER_OUT = (
    b"//go:build linux\n"
    b"// +build linux\n"
    b"\n"
    b"package p\n"
    b"\n"
    b"// Doc for F.\n"
    b"\n"
    b"func G() {}\n"
    b"\n"
    b"func F() {}\n"
)
BC_CLEAN_SRC = (
    b"package p\n\n// Doc for F.\n//go:build linux\n// +build linux\nfunc F() {}\n"
)
BC_CLEAN_OUT = (
    b"//go:build linux\n"
    b"// +build linux\n"
    b"\n"
    b"package p\n"
    b"\n"
    b"// Doc for F.\n"
    b"func F() {}\n"
)

# A group holding a call statement is code, so it is left completely alone.
CODE_MIXED_SRC = b"package p\n\nfunc f() {\n\t//x\n\t//a.B()\n}\n"

# Groups that parse as only identifier paths or labels are not code, so
# they do get the space.
CODE_TRIVIAL_SRC = b"package p\n\nfunc f() {\n\t//x\n\t//a.B\n}\n"
CODE_TRIVIAL_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t// x\n"
    b"\t// a.B\n"
    b"}\n"
)
CODE_LABEL_SRC = b"package p\n\nfunc f() {\n\t//L:\n\t//y\n}\n"
CODE_LABEL_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t// L:\n"
    b"\t// y\n"
    b"}\n"
)


def test_column1_comment_in_call_is_separated_and_unindented(run):
    """A column-1 comment in a call gets a blank line and no indent.

    CATCHES: an implementation that indents a first-column comment inside a
    call's argument list like an ordinary floating comment, instead of
    letting the printer treat it as a doc comment with a blank line before
    it.
    """
    col1 = run([], stdin=CALL_COL1_SRC)
    assert col1.returncode == 0, col1.stderr
    assert col1.stdout == CALL_COL1_OUT

    indented = run([], stdin=CALL_IND_SRC)
    assert indented.returncode == 0, indented.stderr
    assert indented.stdout == CALL_IND_OUT


def test_column1_comment_group_before_literal_is_doc_formatted(run):
    """A column-1 group before "}" is reflowed; an indented one is not.

    CATCHES: an implementation that only ever adds the "// " space, never
    running the doc-comment engine on a first-column group that ends right
    before a composite literal's closing brace (which re-indents list items
    from two to three spaces).
    """
    col1 = run([], stdin=LIT_COL1_SRC)
    assert col1.returncode == 0, col1.stderr
    assert col1.stdout == LIT_COL1_OUT

    indented = run([], stdin=LIT_IND_SRC)
    assert indented.returncode == 0, indented.stderr
    assert indented.stdout == LIT_IND_OUT


def test_column1_comments_inside_brackets_are_indented(run):
    """Comments in parens, assertions, indexes and type brackets survive.

    CATCHES: an implementation that loses or mis-indents a first-column
    comment sitting inside a parenthesised expression, type assertion,
    index expression or generic type argument list.
    """
    result = run([], stdin=BRACKETS_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == BRACKETS_OUT


def test_empty_comment_dropped_before_a_doc_token(run):
    """A lone "//" right before a token disappears, like an empty doc.

    CATCHES: an implementation that keeps an empty comment group before a
    declaration, a function's closing brace or an import group's closing
    parenthesis instead of dropping it as an empty doc comment.
    """
    var = run([], stdin=EMPTY_VAR_SRC)
    assert var.returncode == 0, var.stderr
    assert var.stdout == EMPTY_VAR_OUT

    rbrace = run([], stdin=EMPTY_RBRACE_SRC)
    assert rbrace.returncode == 0, rbrace.stderr
    assert rbrace.stdout == EMPTY_RBRACE_OUT

    imp = run([], stdin=EMPTY_IMPORT_SRC)
    assert imp.returncode == 0, imp.stderr
    assert imp.stdout == EMPTY_IMPORT_OUT


def test_empty_comment_kept_before_an_indented_statement(run):
    """A lone "//" above an indented statement is kept and indented.

    CATCHES: an implementation that drops every empty comment group,
    including one whose following statement is indented and therefore not a
    token the group could be a doc comment for.
    """
    result = run([], stdin=EMPTY_KEPT_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == EMPTY_KEPT_OUT


def test_indented_block_doc_comment_left_verbatim(run):
    """An indented /* */ doc is never pushed through the doc engine.

    CATCHES: an implementation that reflows a block-style doc comment (or
    drops it for having no text) rather than leaving its text untouched and
    only re-indenting it to the declaration's column.
    """
    result = run([], stdin=INDENTED_BLOCK_DOC_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == INDENTED_BLOCK_DOC_OUT


def test_indented_line_doc_comment_is_reflowed_by_gofumpt(run):
    """An indented // doc is formatted by gofumpt, matching a column-1 one.

    CATCHES: an implementation that only formats first-column doc comments,
    leaving an indented doc comment's list markers at their original
    indentation.
    """
    indented = run([], stdin=INDENTED_LIST_DOC_SRC)
    assert indented.returncode == 0, indented.stderr
    assert indented.stdout == INDENTED_LIST_DOC_OUT

    col1 = run([], stdin=COL1_LIST_DOC_SRC)
    assert col1.returncode == 0, col1.stderr
    assert col1.stdout == INDENTED_LIST_DOC_OUT


def test_indented_empty_doc_comment_is_dropped(run):
    """An indented doc comment without text disappears.

    CATCHES: an implementation that keeps an empty indented doc comment
    because the empty-comment dropper only looks at column 1, forgetting
    that the doc formatter must drop it too.
    """
    result = run([], stdin=INDENTED_EMPTY_DOC_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == INDENTED_EMPTY_DOC_OUT


def test_build_line_between_prose_leaves_no_empty_comment_line(run):
    """A //go:build line inside prose is split out without a "//" gap.

    CATCHES: an implementation that moves the build line out of a mixed
    comment group but leaves an empty "//" separator line behind between
    the two prose lines.
    """
    result = run([], stdin=BC_MID_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == BC_MID_OUT


def test_build_line_split_keeps_paragraphs(run):
    """Explicit "//" separators around a build line stay paragraphs.

    CATCHES: an implementation that merges the paragraphs surrounding a
    moved //go:build line into one, or drops the blank comment lines that
    separated them.
    """
    result = run([], stdin=BC_PARA_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == BC_PARA_OUT


def test_removed_build_lines_leave_a_blank_line_behind(run):
    """A blank line after build lines survives their removal.

    CATCHES: an implementation that swallows the blank line left behind
    when the build lines move above the package clause, or that separates a
    doc group ending on a build line from its declaration.
    """
    after = run([], stdin=BC_BLANK_AFTER_SRC)
    assert after.returncode == 0, after.stderr
    assert after.stdout == BC_BLANK_AFTER_OUT

    clean = run([], stdin=BC_CLEAN_SRC)
    assert clean.returncode == 0, clean.stderr
    assert clean.stdout == BC_CLEAN_OUT


def test_code_looking_group_with_a_call_stays_verbatim(run):
    """A group parsing as a call statement is treated as code.

    CATCHES: an implementation that adds "// " to a comment group holding a
    call like "a.B()" because the identifier-path check alone said it was
    not code.
    """
    result = run([], stdin=CODE_MIXED_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == CODE_MIXED_SRC


def test_trivial_code_looking_groups_get_spaces(run):
    """Identifier paths and labels are trivial, so they get the space.

    CATCHES: an implementation that rejects any comment group which parses
    as Go code, even when every statement is a bare identifier path or a
    label with no body.
    """
    trivial = run([], stdin=CODE_TRIVIAL_SRC)
    assert trivial.returncode == 0, trivial.stderr
    assert trivial.stdout == CODE_TRIVIAL_OUT

    label = run([], stdin=CODE_LABEL_SRC)
    assert label.returncode == 0, label.stderr
    assert label.stdout == CODE_LABEL_OUT
