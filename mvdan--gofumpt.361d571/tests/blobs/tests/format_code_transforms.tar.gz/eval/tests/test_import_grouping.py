"""Import grouping: std imports gather at the top, separated from the rest.

Std-ness is heuristic: a dot in the first path element, a ``test/`` or
``example/`` prefix, the -modpath's first element, a name on an import
outside the first group, or an attached comment all make an import non-std;
commented imports are never moved, and the cgo ``import "C"`` is never
merged or reformatted.
"""

SPLIT_SRC = """\
package p

import (
\t"fmt"
\t"example.com/foo"
\t"os"
)

func f() { fmt.Println(os.Args) }
"""

SPLIT_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b'\t"os"\n'
    b"\n"
    b'\t"example.com/foo"\n'
    b")\n"
    b"\n"
    b"func f() { fmt.Println(os.Args) }\n"
)

MOVED_SRC = """\
package p

import (
\t"zoo.com/z"
\t"b.com/b"
\t"zap.org/x"
\t"errors"
\t"bufio"
)

var _ = errors.New
"""

MOVED_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"bufio"\n'
    b'\t"errors"\n'
    b"\n"
    b'\t"b.com/b"\n'
    b'\t"zap.org/x"\n'
    b'\t"zoo.com/z"\n'
    b")\n"
    b"\n"
    b"var _ = errors.New\n"
)

RESERVED_SRC = """\
package p

import (
\t"test/foo"
\t"example/bar"
\t"foo/bar.com/baz"
\t"real/foo"
)
"""

RESERVED_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"foo/bar.com/baz"\n'
    b'\t"real/foo"\n'
    b"\n"
    b'\t"example/bar"\n'
    b'\t"test/foo"\n'
    b")\n"
)

MODPATH_SRC = """\
package p

import (
\t"mymod/foo/bar"
\t"mymod/fooother"
\t"mymod"
\t"fmt"
)
"""

MODPATH_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b"\n"
    b'\t"mymod"\n'
    b'\t"mymod/foo/bar"\n'
    b'\t"mymod/fooother"\n'
    b")\n"
)

CGO_PREAMBLE_SRC = """\
package p

/*
#include <stdio.h>
*/
import "C"

import "fmt"

func f() { fmt.Println(1) }
"""

LONE_JOINED_SRC = """\
package p

import "z.com/z"
import "fmt"
import "a.com/a"

func f() { fmt.Println() }
"""

LONE_JOINED_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b"\n"
    b'\t"a.com/a"\n'
    b'\t"z.com/z"\n'
    b")\n"
    b"\n"
    b"func f() { fmt.Println() }\n"
)


def test_std_imports_gathered_above_non_std(run):
    """Std imports move above non-std ones with a blank line in between.

    CATCHES: an implementation that sorts imports without separating std
    from third-party paths, or that puts the separator in the wrong place.
    """
    result = run([], stdin=SPLIT_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == SPLIT_OUT
    assert result.stderr == b""


def test_std_imports_moved_up_are_resorted(run):
    """Std imports pulled out of an unsorted block arrive sorted.

    CATCHES: an implementation that moves std imports up but keeps their
    original relative order instead of re-sorting the merged group.
    """
    result = run([], stdin=MOVED_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == MOVED_OUT


def test_reserved_prefixes_and_dot_heuristic(run):
    """test/ and example/ prefixes are non-std; later-element dots are not.

    CATCHES: an implementation treating any dot anywhere in the path as
    third-party, or ignoring the reserved test/example prefixes.
    """
    result = run([], stdin=RESERVED_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == RESERVED_OUT


def test_modpath_prefix_covers_its_first_element(run):
    """-modpath mymod/foo makes every mymod... path non-std.

    CATCHES: an implementation matching the full module path instead of its
    first element, which would wrongly keep mymod/fooother in the std group.
    """
    result = run(["-modpath", "mymod/foo"], stdin=MODPATH_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == MODPATH_OUT


def test_named_import_outside_first_group_is_non_std(run):
    """A named import after the first group is treated as third-party.

    CATCHES: an implementation that ignores import names, which would hoist
    ``foo "strings"`` into the std group and break its alias.
    """
    src = (
        b"package p\n"
        b"\n"
        b"import (\n"
        b'\t"fmt"\n'
        b"\n"
        b'\tfoo "strings"\n'
        b'\t"bytes"\n'
        b")\n"
        b"\n"
        b"var _ = foo.TrimSpace\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"import (\n"
        b'\t"bytes"\n'
        b'\t"fmt"\n'
        b"\n"
        b'\tfoo "strings"\n'
        b")\n"
        b"\n"
        b"var _ = foo.TrimSpace\n"
    )


def test_named_import_inside_first_group_stays_std(run):
    """A named import in the top group is still std and sorts with the rest.

    CATCHES: an implementation treating ANY named import as non-std, which
    would push ``foo "strings"`` below the blank separator.
    """
    src = (
        b"package p\n"
        b"\n"
        b"import (\n"
        b'\tfoo "strings"\n'
        b'\t"bytes"\n'
        b'\t"example.com/e"\n'
        b")\n"
        b"\n"
        b"var _ = foo.TrimSpace\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"import (\n"
        b'\t"bytes"\n'
        b'\tfoo "strings"\n'
        b"\n"
        b'\t"example.com/e"\n'
        b")\n"
        b"\n"
        b"var _ = foo.TrimSpace\n"
    )


def test_commented_import_is_never_moved(run):
    """A doc comment above a std import keeps it out of the top group.

    CATCHES: an implementation that hoists a commented std import up anyway,
    stranding its comment away from the import it documents.
    """
    src = (
        b"package p\n"
        b"\n"
        b"import (\n"
        b'\t"fmt"\n'
        b"\n"
        b"\t// doc for errors\n"
        b'\t"errors"\n'
        b')\n'
        b"\n"
        b"var _ = errors.New\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"import (\n"
        b'\t"fmt"\n'
        b"\n"
        b"\t// doc for errors\n"
        b'\t"errors"\n'
        b")\n"
        b"\n"
        b"var _ = errors.New\n"
    )


def test_cgo_import_and_preamble_untouched(run):
    """import "C" with its /* */ preamble is neither merged nor reformatted.

    CATCHES: an implementation that joins the cgo import into the next import
    group or rewraps the C preamble comment, corrupting cgo builds.
    """
    result = run([], stdin=CGO_PREAMBLE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == CGO_PREAMBLE_SRC.encode()


def test_cgo_backtick_import_normalized_but_kept_separate(run):
    """import `C` prints as import "C" and still never joins other imports.

    CATCHES: an implementation that only recognizes the double-quoted form
    of the cgo import and merges it into the following import block.
    """
    src = b'package p\n\nimport `C`\n\nimport "fmt"\n'
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == b'package p\n\nimport "C"\n\nimport "fmt"\n'


def test_lone_import_lines_joined_into_one_group(run):
    """Adjacent lone import declarations merge, sort and split std/non-std.

    CATCHES: an implementation that leaves lone ``import "x"`` lines alone
    instead of joining them into a single parenthesized block.
    """
    result = run([], stdin=LONE_JOINED_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == LONE_JOINED_OUT


def test_lone_import_separators_prevent_joining(run):
    """A blank line or a doc comment keeps lone import declarations apart.

    CATCHES: an implementation that joins lone imports across empty lines or
    comment boundaries, which would swallow the doc comment placement.
    """
    blank = b'package p\n\nimport "z.com/z"\n\nimport "fmt"\n'
    result = run([], stdin=blank)
    assert result.returncode == 0, result.stderr
    assert result.stdout == blank

    doc = (
        b"package p\n"
        b"\n"
        b'import "z.com/z"\n'
        b"\n"
        b"// doc keeps me\n"
        b'import "fmt"\n'
    )
    result = run([], stdin=doc)
    assert result.returncode == 0, result.stderr
    assert result.stdout == doc
