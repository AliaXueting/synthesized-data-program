"""The opt-in ``-extra`` rules: group_params, clothe_returns, balance_calls.

Each rule is off unless named in -extra (or enabled wholesale by -extra=true,
disabled by -extra=false); an unknown rule name is a hard flag error.
"""

GROUP_PARAMS_SRC = """\
package p

func f(a int, b int, c string, d string) {}

type T func(a int, b int)

var fn = func(a int, b int) {}

type I interface{ M(a int, b int) }
"""

GROUP_PARAMS_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a, b int, c, d string) {}\n"
    b"\n"
    b"type T func(a, b int)\n"
    b"\n"
    b"var fn = func(a, b int) {}\n"
    b"\n"
    b"type I interface{ M(a, b int) }\n"
)

STRUCT_FIELDS_SRC = """\
package p

type S struct{ a int; b int }
"""

STRUCT_FIELDS_OUT = (
    b"package p\n"
    b"\n"
    b"type S struct {\n"
    b"\ta int\n"
    b"\tb int\n"
    b"}\n"
)

SPLIT_PARAMS_SRC = """\
package p

func f(a int,
\tb int,
) {}
"""

SPLIT_PARAMS_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a int,\n"
    b"\tb int,\n"
    b") {\n"
    b"}\n"
)

CLOTHE_SRC = """\
package p

func f() (a int, b string) {
\treturn
}

func g() (int, string) {
\treturn 1, "x"
}

func h() (_ int, b string) {
\treturn
}

func k() (a int, _ string) {
\treturn
}
"""

CLOTHE_OUT = (
    b"package p\n"
    b"\n"
    b"func f() (a int, b string) {\n"
    b"\treturn a, b\n"
    b"}\n"
    b"\n"
    b'func g() (int, string) {\n'
    b'\treturn 1, "x"\n'
    b"}\n"
    b"\n"
    b"func h() (_ int, b string) {\n"
    b"\treturn\n"
    b"}\n"
    b"\n"
    b"func k() (a int, _ string) {\n"
    b"\treturn\n"
    b"}\n"
)

BALANCE_SRC = """\
package p

func f() {
\tg(
\t\t1,
\t\t2)
\th(1,
\t\t2)
\ti(
\t\t1, 2)
}
"""

BALANCE_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\tg(\n"
    b"\t\t1,\n"
    b"\t\t2,\n"
    b"\t)\n"
    b"\th(1,\n"
    b"\t\t2)\n"
    b"\ti(\n"
    b"\t\t1, 2,\n"
    b"\t)\n"
    b"}\n"
)

ALL_RULES_SRC = """\
package p

func f(a int, b int) (x int) {
\tg(
\t\t1,
\t\t2)
\treturn
}
"""

ALL_RULES_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a, b int) (x int) {\n"
    b"\tg(\n"
    b"\t\t1,\n"
    b"\t\t2,\n"
    b"\t)\n"
    b"\treturn x\n"
    b"}\n"
)

NOOP_SRC = """\
package p

func f(a int, b int) (x int) {
\tg(
\t\t1,
\t\t2)
\treturn
}
"""


def test_group_params_merges_all_declaration_kinds(run):
    """Adjacent same-type params merge in funcs, func types and interfaces.

    CATCHES: an implementation that only rewrites top-level func decls and
    misses func literals, named func types or interface methods.
    """
    result = run(["-extra=group_params"], stdin=GROUP_PARAMS_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == GROUP_PARAMS_OUT
    assert result.stderr == b""


def test_group_params_never_merges_struct_fields(run):
    """Struct fields with the same type are left as separate fields.

    CATCHES: an implementation applying the param merge to struct field
    lists, which would change the struct's field set.
    """
    result = run(["-extra=group_params"], stdin=STRUCT_FIELDS_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == STRUCT_FIELDS_OUT


def test_group_params_respects_line_breaks(run):
    """Params written on separate lines are never merged.

    CATCHES: an implementation merging across newlines, discarding the
    author's deliberate split.
    """
    result = run(["-extra=group_params"], stdin=SPLIT_PARAMS_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == SPLIT_PARAMS_OUT


def test_clothe_returns_dresses_named_results(run):
    """A bare return in a fully-named-result func becomes ``return a, b``.

    CATCHES: an implementation that leaves naked returns alone or clothes
    them with the types instead of the result names.
    """
    result = run(["-extra=clothe_returns"], stdin=CLOTHE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == CLOTHE_OUT


def test_balance_calls_puts_closing_paren_on_its_own_line(run):
    """A multi-line call opened at end-of-line closes on a new line.

    CATCHES: an implementation that also moves the paren for calls whose
    opening paren shares its line with the first argument (``h(1,``).
    """
    result = run(["-extra=balance_calls"], stdin=BALANCE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == BALANCE_OUT


def test_extra_true_enables_all_rules_at_once(run):
    """-extra=true turns on every extra rule in one declaration.

    CATCHES: an implementation treating -extra=true as a no-op or enabling
    only a subset of the three rules.
    """
    result = run(["-extra=true"], stdin=ALL_RULES_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == ALL_RULES_OUT


def test_extra_false_is_a_noop(run):
    """-extra=false disables everything; the input only gets gofmt'd.

    CATCHES: an implementation where -extra=false still applies some rules,
    or that rejects the explicit false value.
    """
    result = run(["-extra=false"], stdin=NOOP_SRC.encode())
    assert result.returncode == 0, result.stderr
    # Unchanged by the extra rules; gofmt alone does not alter this input.
    assert result.stdout == NOOP_SRC.encode()


def test_extra_unknown_rule_is_rejected(run):
    """An unknown -extra rule name fails with usage on stderr and exit 2.

    CATCHES: an implementation that silently ignores misspelled rule names
    instead of rejecting the flag.
    """
    result = run(["-extra=bogus_rule"], stdin=b"package p\n")
    assert result.returncode == 2
    assert result.stdout == b""
    assert (
        b'invalid boolean value "bogus_rule" for -extra: unknown rule:'
        b' "bogus_rule"\n' in result.stderr
    )
    assert b"usage: gofumpt" in result.stderr


def test_extra_rules_off_by_default(run):
    """Without -extra none of the three rules fire.

    CATCHES: an implementation enabling group_params, clothe_returns or
    balance_calls without being asked to.
    """
    result = run([], stdin=ALL_RULES_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == ALL_RULES_SRC.encode()
