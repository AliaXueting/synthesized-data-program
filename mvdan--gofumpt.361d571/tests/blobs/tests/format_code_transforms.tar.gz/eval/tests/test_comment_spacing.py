"""Comment spacing: plain ``//foo`` comments gain a space, the rest do not.

A line comment whose body starts with a letter, digit or space gets ``// ``
prepended, unless the comment group holds a directive, looks like commented-
out code, is a ``/* */`` comment, or is a first-line shebang.
"""

PLAIN_SRC = """\
package p

func f() {
\t//foo
\tx := 1 //inline c
\t//über café
\t//123nums
\t// spaced
}
"""

PLAIN_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t// foo\n"
    b"\tx := 1 // inline c\n"
    + "\t// über café\n".encode("utf-8") +
    b"\t// 123nums\n"
    b"\t// spaced\n"
    b"}\n"
)

DIRECTIVES_SRC = """\
package p

func f() {
\t//go:generate foo
\t//nolint:gosec
\t//#nosec
\t//NOSONAR
\t//sys alert
\t//sysnb alert
\t//export Foo
\t//extern foo
\t//line foo:1
\t//todo:x
\t//noinspection all
}
"""

CODE_GROUP_SRC = """\
package p

func f() {
\t//x := 1
\t//fmt.Println()
}
"""

IF_GROUP_SRC = """\
package p

func f() {
\t//if err != nil {
\t//\treturn err
\t//}
}
"""

NOT_CODE_SRC = """\
package p

func f() {
\t//x := 1
\t//real prose here

\t//foo
\t//a.B
}
"""

NOT_CODE_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t// x := 1\n"
    b"\t// real prose here\n"
    b"\n"
    b"\t// foo\n"
    b"\t// a.B\n"
    b"}\n"
)

MISC_SRC = """\
package p

func f() {
\t//  two spaces
\t//\ttab start
\t//
\t/*block foo*/
\t_ = 1
}
"""

MISC_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t//  two spaces\n"
    b"\t//\ttab start\n"
    b"\t//\n"
    b"\t/*block foo*/\n"
    b"\t_ = 1\n"
    b"}\n"
)

EXPORT_ALONE_SRC = """\
package p

func f() {
\t//export

\t//syscall
\t//exploit
}
"""

EXPORT_ALONE_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t// export\n"
    b"\n"
    b"\t// syscall\n"
    b"\t// exploit\n"
    b"}\n"
)


def test_plain_comment_bodies_gain_a_space(run):
    """``//foo`` becomes ``// foo`` everywhere a comment can appear.

    CATCHES: an implementation that forgets the space rule for inline
    comments, or that skips bodies starting with digits or non-ASCII letters.
    """
    result = run([], stdin=PLAIN_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == PLAIN_OUT
    assert result.stderr == b""


def test_directive_lines_keep_their_exact_text(run):
    """Tool directives like //go:generate and //nolint:gosec stay verbatim.

    CATCHES: an implementation that adds a space after // for directive
    comments, breaking tools that match them byte-for-byte.
    """
    result = run([], stdin=DIRECTIVES_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == DIRECTIVES_SRC.encode()


def test_comment_groups_that_parse_as_code_are_untouched(run):
    """Groups of commented-out Go statements keep their missing space.

    CATCHES: an implementation without the "looks like code" heuristic, which
    would rewrite ``//x := 1`` to ``// x := 1`` inside function bodies.
    """
    for src in (CODE_GROUP_SRC, IF_GROUP_SRC):
        result = run([], stdin=src.encode())
        assert result.returncode == 0, result.stderr
        assert result.stdout == src.encode()


def test_groups_failing_the_code_parse_still_get_spaces(run):
    """A group with prose lines or only trivial statements is not code.

    CATCHES: an implementation whose code-detection accepts any group holding
    a code-looking line, or one that treats bare identifier paths as code.
    """
    result = run([], stdin=NOT_CODE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == NOT_CODE_OUT


def test_block_comments_and_whitespace_bodies_unchanged(run):
    """/* */ comments and bodies already starting with space are left alone.

    CATCHES: an implementation that adds a space to /* */ comments or
    normalizes ``//  two spaces`` and ``//\\ttab start`` bodies.
    """
    result = run([], stdin=MISC_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == MISC_OUT


def test_directive_prefix_needs_trailing_word(run):
    """``//export`` alone is prose; ``//export Foo`` and ``//sys a`` are not.

    CATCHES: an implementation matching directive prefixes like ``export``
    without requiring the following space/word boundary.
    """
    result = run([], stdin=EXPORT_ALONE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == EXPORT_ALONE_OUT


def test_shebang_line_left_verbatim_when_not_doc(run):
    """A first-line ``//usr/bin/env`` shebang followed by a blank line stays.

    CATCHES: an implementation that forgets the shebang exemption and adds a
    space, producing a shebang no Unix loader would accept.
    """
    src = b"//usr/bin/env go run x.go\n\npackage p\n"
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == src


def test_shebang_as_abutting_package_doc_is_reformatted(run):
    """A shebang directly above ``package`` is a doc comment and reformats.

    CATCHES: an implementation whose doc-comment pass never sees the shebang
    because the spacing rule already skipped it; the reference still prints
    ``// usr/bin/env ...`` with the space via the doc engine.
    """
    result = run([], stdin=b"//usr/bin/env go run x.go\npackage p\n")
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"// usr/bin/env go run x.go\npackage p\n"


def test_third_party_markers_in_doc_position_get_spaces(run):
    """In doc position //#nosec and friends are prose to the doc engine.

    CATCHES: an implementation that skips the whole doc group because one
    line matches a directive pattern; only real //tool:name directives are
    separated, the rest is reflowed as text with a space.
    """
    src = b"package p\n\n//#nosec\n//NOSONAR\n//sys alert\nfunc f() {}\n"
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n\n// #nosec\n// NOSONAR\n// sys alert\nfunc f() {}\n"
    )


def test_build_constraint_lines_stay_on_top(run):
    """//go:build stays first; a lone // +build gets //go:build synthesized.

    CATCHES: an implementation that drops or reorders build constraint lines
    or fails to add the modern //go:build form next to a // +build line.
    """
    modern = b"//go:build linux\n// +build linux\n\npackage p\n"
    result = run([], stdin=modern)
    assert result.returncode == 0, result.stderr
    assert result.stdout == modern

    result = run([], stdin=b"// +build linux\n\npackage p\n")
    assert result.returncode == 0, result.stderr
    assert result.stdout == modern
