"""Guards inside the opt-in -extra rules.

Two of the extra rules stop at boundaries the basic tests never crossed:
clothe_returns only dresses a bare ``return`` with the results of the
function it is directly inside (an inner func literal without results
keeps its bare return), and balance_calls leaves calls alone when they
have no arguments at all or already fit on one line -- while an inline
comment after the last argument still rides along when the closing
parenthesis moves to its own line.
"""

CLOTHE_NESTED_SRC = (
    b"package p\n"
    b"\n"
    b"func outer() (a int) {\n"
    b"\tinner := func() {\n"
    b"\t\treturn\n"
    b"\t}\n"
    b"\tinner()\n"
    b"\treturn\n"
    b"}\n"
)
CLOTHE_NESTED_OUT = (
    b"package p\n"
    b"\n"
    b"func outer() (a int) {\n"
    b"\tinner := func() {\n"
    b"\t\treturn\n"
    b"\t}\n"
    b"\tinner()\n"
    b"\treturn a\n"
    b"}\n"
)

BALANCE_GUARDS_SRC = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\tg( // keep\n"
    b"\t)\n"
    b"\th(1)\n"
    b"\tk(\n"
    b"\t\t1,\n"
    b"\t\t2 /* c */)\n"
    b"}\n"
)
BALANCE_GUARDS_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\tg( // keep\n"
    b"\t)\n"
    b"\th(1)\n"
    b"\tk(\n"
    b"\t\t1,\n"
    b"\t\t2, /* c */\n"
    b"\t)\n"
    b"}\n"
)


def test_clothe_returns_skips_an_inner_func_without_results(run):
    """Only the innermost function's results dress a bare return.

    CATCHES: an implementation that walks to the enclosing function when
    the inner func literal has no results, rewriting the inner bare
    ``return`` as ``return a`` too.
    """
    result = run(["-extra=true"], stdin=CLOTHE_NESTED_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == CLOTHE_NESTED_OUT


def test_balance_calls_guards_and_inline_comment(run):
    """Zero-arg and single-line calls stay; a trailing comment rides along.

    CATCHES: an implementation that balances the zero-argument call
    across its comment, or moves ``)`` without keeping the inline
    ``/* c */`` comment on the last argument's line.
    """
    result = run(["-extra=true"], stdin=BALANCE_GUARDS_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == BALANCE_GUARDS_OUT
