"""Code-detection corners of the comment spacing rule.

gofumpt adds a space after ``//`` unless the comment group parses as Go
code with at least one non-trivial statement. A bare identifier or a
label is trivial prose, and so is a lone semicolon: the group below
parses as one identifier statement plus an empty statement, both
trivial, so the group is prose and gains its space.
"""

SEMICOLON_GROUP_SRC = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t//foo\n"
    b"\t// ;\n"
    b"}\n"
)
SEMICOLON_GROUP_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\t// foo\n"
    b"\t// ;\n"
    b"}\n"
)


def test_lone_semicolon_line_is_trivial_not_code(run):
    """A comment group holding ``foo`` and ``;`` counts as prose.

    CATCHES: an implementation that treats an empty statement as code,
    leaving ``//foo`` without its space because the group "parses as Go"
    instead of only trivial statements.
    """
    result = run([], stdin=SEMICOLON_GROUP_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == SEMICOLON_GROUP_OUT
