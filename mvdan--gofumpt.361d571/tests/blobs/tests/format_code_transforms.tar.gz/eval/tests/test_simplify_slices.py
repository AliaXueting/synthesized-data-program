"""gofmt -s style slice simplification: ``s[a:len(s)]`` becomes ``s[a:]``.

gofumpt always simplifies (the -s flag was dropped), but only when the sliced
expression is a plain identifier matching the argument of len, and only for
two-index slices.
"""

SIMPLIFIED = """\
package p

func f(s []int) {
\t_ = s[0:len(s)]
\t_ = s[1:len(s)]
\t_ = s[a:len(s)]
\t_ = s[:len(s)]
\t_ = s[len(s):len(s)]
}
"""

SIMPLIFIED_OUT = (
    b"package p\n"
    b"\n"
    b"func f(s []int) {\n"
    b"\t_ = s[0:]\n"
    b"\t_ = s[1:]\n"
    b"\t_ = s[a:]\n"
    b"\t_ = s[:]\n"
    b"\t_ = s[len(s):]\n"
    b"}\n"
)

KEPT = """\
package p

func f(s, t []int) {
\t_ = s[0:len(t)]
\t_ = t[0:len(s)]
\t_ = s[a:len(s):b]
\t_ = f()[0:len(f())]
\t_ = s[0:len(s, 1)]
\t_ = s[0:len(s...)]
\t_ = s[0:LEN(s)]
\t_ = x.arr[0:len(x.arr)]
\t_ = s[0:cap(s)]
}
"""

KEPT_OUT = (
    b"package p\n"
    b"\n"
    b"func f(s, t []int) {\n"
    b"\t_ = s[0:len(t)]\n"
    b"\t_ = t[0:len(s)]\n"
    b"\t_ = s[a:len(s):b]\n"
    b"\t_ = f()[0:len(f())]\n"
    b"\t_ = s[0:len(s, 1)]\n"
    b"\t_ = s[0:len(s...)]\n"
    b"\t_ = s[0:LEN(s)]\n"
    b"\t_ = x.arr[0:len(x.arr)]\n"
    b"\t_ = s[0:cap(s)]\n"
    b"}\n"
)


def test_slice_len_simplified(run):
    """len(s) as the high bound of a slice of s is dropped entirely.

    CATCHES: a re-implementation that leaves ``s[a:len(s)]`` alone (no
    gofmt -s equivalent) or only handles the ``s[0:len(s)]`` spelling.
    """
    result = run([], stdin=SIMPLIFIED.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == SIMPLIFIED_OUT
    assert result.stderr == b""


def test_slice_len_kept_for_non_matching_shapes(run):
    """Slices whose receiver or len argument do not match keep their len().

    CATCHES: dropping len() for 3-index slices, non-identifier receivers,
    multi-argument or ellipsis len calls, or a mismatched len argument.
    """
    result = run([], stdin=KEPT.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == KEPT_OUT


def test_slice_simplification_is_idempotent(run):
    """Running the already-simplified output through gofumpt changes nothing.

    CATCHES: a re-implementation whose simplification is not stable, e.g. one
    that would keep stripping ``s[0:]`` down to something else on a second run.
    """
    first = run([], stdin=SIMPLIFIED.encode())
    second = run([], stdin=first.stdout)
    assert second.returncode == 0, second.stderr
    assert second.stdout == SIMPLIFIED_OUT
    assert second.stdout == first.stdout


def test_slice_simplification_in_stdin_fragment(run):
    """A stdin program fragment (no package clause) is simplified too.

    CATCHES: only formatting whole files, so a fragment passed on stdin would
    reach the printer without the AST simplification pass.
    """
    result = run([], stdin=b"s[0:len(s)]\n")
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"s[0:]\n"


def test_slice_simplification_from_file_argument(run, work):
    """The same simplification applies when the source is a file argument.

    CATCHES: a code path that only runs the rewrite for stdin input.
    """
    path = work / "slice.go"
    path.write_text(SIMPLIFIED)
    result = run([path])
    assert result.returncode == 0, result.stderr
    assert result.stdout == SIMPLIFIED_OUT


def test_slice_simplification_inside_composite_literal(run):
    """Simplification runs inside composite literals and call arguments.

    CATCHES: an implementation that only simplifies top-level assignment
    statements and misses nested expression contexts.
    """
    src = (
        b"package p\n"
        b"\n"
        b"func f(s []int) {\n"
        b"\t_ = []int{s[0:len(s)], s[1:len(s)]}\n"
        b"\tg(s[0:len(s)])\n"
        b"}\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"func f(s []int) {\n"
        b"\t_ = []int{s[0:], s[1:]}\n"
        b"\tg(s[0:])\n"
        b"}\n"
    )
