"""Composite-literal simplification: redundant element types are elided.

Inside ``[]T{...}`` an inner ``T{...}`` loses its type; the same goes for map
values and map keys.  Inside a ``[]*T`` an ``&T{...}`` becomes ``T{...}``.
"""

ELIDE_SRC = """\
package p

type T struct{ A, B int }
type Point struct{ X, Y int }

func f() {
\t_ = []T{T{1, 2}, T{3, 4}}
\t_ = []T{{1, 2}, {3, 4}}
\t_ = [2]T{T{}, T{}}
\t_ = map[string]T{"a": T{1, 2}, "b": T{3, 4}}
\t_ = map[Point]string{Point{1, 2}: "a"}
\t_ = [][]int{[]int{1}, []int{2}}
\t_ = map[string][]int{"a": []int{1}}
\t_ = [][][]int{[][]int{[]int{1}}}
}
"""

ELIDE_OUT = (
    b"package p\n"
    b"\n"
    b"type (\n"
    b"\tT     struct{ A, B int }\n"
    b"\tPoint struct{ X, Y int }\n"
    b")\n"
    b"\n"
    b"func f() {\n"
    b"\t_ = []T{{1, 2}, {3, 4}}\n"
    b"\t_ = []T{{1, 2}, {3, 4}}\n"
    b"\t_ = [2]T{{}, {}}\n"
    b'\t_ = map[string]T{"a": {1, 2}, "b": {3, 4}}\n'
    b'\t_ = map[Point]string{{1, 2}: "a"}\n'
    b"\t_ = [][]int{{1}, {2}}\n"
    b'\t_ = map[string][]int{"a": {1}}\n'
    b"\t_ = [][][]int{{{1}}}\n"
    b"}\n"
)

POINTER_SRC = """\
package p

type Point struct{ X, Y int }
type I interface{ M() }

func f() {
\t_ = []*Point{&Point{1, 2}}
\t_ = []*Point{{1, 2}}
\t_ = map[string]*Point{"a": &Point{1, 2}}
\t_ = []Point{&Point{1, 2}}
\t_ = []**Point{&Point{}}
\t_ = []I{&Point{}}
\t_ = []*Point{&Point{}, &Point{}}
\t_ = []*Point{&Point{X: 1}, 3: &Point{}}
}
"""

POINTER_OUT = (
    b"package p\n"
    b"\n"
    b"type (\n"
    b"\tPoint struct{ X, Y int }\n"
    b"\tI     interface{ M() }\n"
    b")\n"
    b"\n"
    b"func f() {\n"
    b"\t_ = []*Point{{1, 2}}\n"
    b"\t_ = []*Point{{1, 2}}\n"
    b'\t_ = map[string]*Point{"a": {1, 2}}\n'
    b"\t_ = []Point{&Point{1, 2}}\n"
    b"\t_ = []**Point{&Point{}}\n"
    b"\t_ = []I{&Point{}}\n"
    b"\t_ = []*Point{{}, {}}\n"
    b"\t_ = []*Point{{X: 1}, 3: {}}\n"
    b"}\n"
)


def test_redundant_element_types_elided(run):
    """Inner literal types matching the outer element type are removed.

    CATCHES: a re-implementation without gofmt -s composite-literal elision,
    which would print ``[]T{T{1, 2}}`` and ``map[Point]string{Point{...}}``
    back unchanged.
    """
    result = run([], stdin=ELIDE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == ELIDE_OUT
    assert result.stderr == b""


def test_address_of_elided_in_pointer_slice(run):
    """``&T{...}`` inside a ``[]*T`` drops both the type and the ``&``.

    CATCHES: dropping only the type (``&{...}``), only the ``&``
    (``*T{...}``), or applying the rewrite where the outer type is not a
    matching pointer type.
    """
    result = run([], stdin=POINTER_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == POINTER_OUT


def test_pointer_elision_not_applied_to_mismatched_types(run):
    """&T{} survives when the outer element type is not exactly *T.

    CATCHES: an implementation matching the element type by name only, which
    would wrongly strip ``&Point{}`` inside a []**Point or a []I.
    """
    src = (
        b"package p\n"
        b"\n"
        b"type Point struct{ X int }\n"
        b"\n"
        b"func f() {\n"
        b"\t_ = []**Point{&Point{}}\n"
        b"\t_ = []interface{ M() }{&Point{}}\n"
        b"}\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    # The single type decl stays on its own line, and both literals keep
    # their & and their type.
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"type Point struct{ X int }\n"
        b"\n"
        b"func f() {\n"
        b"\t_ = []**Point{&Point{}}\n"
        b"\t_ = []interface{ M() }{&Point{}}\n"
        b"}\n"
    )


def test_elision_across_multiline_literals(run):
    """The rewrite also applies to multi-line composite literals.

    CATCHES: an implementation that only rewrites single-line literals and
    loses the inner type when the literal spans lines.
    """
    src = (
        b"package p\n"
        b"\n"
        b"type T struct{ A int }\n"
        b"\n"
        b"func f() {\n"
        b"\t_ = []T{\n"
        b"\t\tT{A: 1},\n"
        b"\t\tT{A: 2},\n"
        b"\t}\n"
        b"}\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"type T struct{ A int }\n"
        b"\n"
        b"func f() {\n"
        b"\t_ = []T{\n"
        b"\t\t{A: 1},\n"
        b"\t\t{A: 2},\n"
        b"\t}\n"
        b"}\n"
    )


SHAPE_SRC = """\
package p

var a = []struct{ x int }{struct{ x int }{1}}
var m = map[[2]int]int{[2]int{1, 2}: 3}
var s = [][2]int{[2]int{1, 2}}
var q = []pkg.T{pkg.T{1}}
var l = []List[int]{List[int]{1}}
var d = []List[[2]int]{List[[2]int]{1}}
var pd = []*pkg.T{&pkg.T{1}}
"""

SHAPE_OUT = (
    b"package p\n"
    b"\n"
    b"var (\n"
    b"\ta  = []struct{ x int }{{1}}\n"
    b"\tm  = map[[2]int]int{{1, 2}: 3}\n"
    b"\ts  = [][2]int{{1, 2}}\n"
    b"\tq  = []pkg.T{{1}}\n"
    b"\tl  = []List[int]{{1}}\n"
    b"\td  = []List[[2]int]{{1}}\n"
    b"\tpd = []*pkg.T{{1}}\n"
    b")\n"
)

MISMATCH_SRC = """\
package p

var a = []struct{ x int }{struct{ x, y int }{x: 1}}
var b = []struct{ x int }{struct{ y int }{x: 1}}
var c = [][2]int{[3]int{1, 2, 3}}
var d = []**T{&T{}}
var e = [][]*T{[]*T{&T{}}}
"""

MISMATCH_OUT = (
    b"package p\n"
    b"\n"
    b"var (\n"
    b"\ta = []struct{ x int }{struct{ x, y int }{x: 1}}\n"
    b"\tb = []struct{ x int }{struct{ y int }{x: 1}}\n"
    b"\tc = [][2]int{[3]int{1, 2, 3}}\n"
    b"\td = []**T{&T{}}\n"
    b"\te = [][]*T{{{}}}\n"
    b")\n"
)


def test_elision_for_struct_array_qualified_and_generic_types(run):
    """Elision is not limited to plain identifiers as element types.

    CATCHES: an implementation whose type match only compares identifier
    names, missing struct types, fixed-size arrays, ``pkg.T`` selectors and
    generic instantiations like ``List[int]``.
    """
    result = run([], stdin=SHAPE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == SHAPE_OUT


def test_elision_is_syntactic_and_keeps_mismatched_shapes(run):
    """Structs with different field counts/names and arrays with different
    lengths keep their inner types; double pointers keep ``&``.

    CATCHES: an implementation that elides by type-checking-like leniency
    (merging ``struct{ x int }`` with ``struct{ x, y int }``) instead of the
    strict syntactic match, or one that drops ``&`` under ``[]**T``.
    """
    result = run([], stdin=MISMATCH_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == MISMATCH_OUT


def test_pointer_elision_composes_with_type_elision(run):
    """A ``[][]*T`` literal loses both the inner slice type and the ``&``.

    CATCHES: an implementation that stops simplifying after the first
    matching rule and keeps either ``[]*T{...}`` or ``&T{}`` at the inner
    level.
    """
    src = b"package p\n\nvar e = [][]*T{[]*T{&T{}}}\n"
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"package p\n\nvar e = [][]*T{{{}}}\n"
