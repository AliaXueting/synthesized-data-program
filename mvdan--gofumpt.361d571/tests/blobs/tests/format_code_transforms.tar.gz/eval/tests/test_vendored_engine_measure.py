"""Decisions the binary makes by printing nodes through the vendored engine.

The binary never formats whole files with internal/govendor/go/format, but
it does hand sub-file nodes to that engine to measure them: a multi-line
case clause is only collapsed when the engine's byte count says it is
short, and two parameter types only merge under -extra when the engine
prints them identically -- which it does with number literals normalised,
so ``[0X1]int`` equals ``[0x1]int``.
"""

CC_SHORT_SRC = (
    b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase a +\n\t\tb:\n"
    b"\t\tbody()\n\t}\n}\n"
)
CC_SHORT_OUT = (
    b"package p\n"
    b"\n"
    b"func f(x int) {\n"
    b"\tswitch x {\n"
    b"\tcase a + b:\n"
    b"\t\tbody()\n"
    b"\t}\n"
    b"}\n"
)

# 42+39 characters of expression: well past the 60-byte estimate even
# before the indentation allowance, so the clause stays split.
CC_LONG_SRC = (
    b"package p\n\nfunc f(x int) {\n\tswitch x {\n"
    b"\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa +\n"
    b"\t\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb:\n"
    b"\t\tbody()\n\t}\n}\n"
)
CC_LONG_OUT = (
    b"package p\n"
    b"\n"
    b"func f(x int) {\n"
    b"\tswitch x {\n"
    b"\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa +\n"
    b"\t\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb:\n"
    b"\t\tbody()\n"
    b"\t}\n"
    b"}\n"
)

# The estimate includes an approximation of the indentation level (two
# blocks here), so 33 a's still collapse and 34 do not: the boundary sits
# between "case " + 33*"a" + " + b:" and the 34-a variant.
CC_JUST_UNDER_SRC = (
    b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase " + b"a" * 33 +
    b" +\n\t\tb:\n\t\tbody()\n\t}\n}\n"
)
CC_JUST_UNDER_OUT = (
    b"package p\n"
    b"\n"
    b"func f(x int) {\n"
    b"\tswitch x {\n"
    b"\tcase " + b"a" * 33 + b" + b:\n"
    b"\t\tbody()\n"
    b"\t}\n"
    b"}\n"
)
CC_JUST_OVER_SRC = (
    b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase " + b"a" * 34 +
    b" +\n\t\tb:\n\t\tbody()\n\t}\n}\n"
)
CC_JUST_OVER_OUT = (
    b"package p\n"
    b"\n"
    b"func f(x int) {\n"
    b"\tswitch x {\n"
    b"\tcase " + b"a" * 34 + b" +\n"
    b"\t\tb:\n"
    b"\t\tbody()\n"
    b"\t}\n"
    b"}\n"
)

# An inline comment after the colon is part of the clause's printed length
# but still follows the collapsed case onto one line.
CC_COMMENT_SRC = (
    b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase a +\n\t\tb: // note\n"
    b"\t\tbody()\n\t}\n}\n"
)
CC_COMMENT_OUT = (
    b"package p\n"
    b"\n"
    b"func f(x int) {\n"
    b"\tswitch x {\n"
    b"\tcase a + b: // note\n"
    b"\t\tbody()\n"
    b"\t}\n"
    b"}\n"
)

# The engine prints both types of each pair identically only because it
# normalises number literals, so group_params merges them.
NUM_MERGE_SRC = (
    b"package p\n\n"
    b"func f(a [0X1]int, b [0x1]int) {}\n\n"
    b"func g(a [0B1]int, b [0b1]int) {}\n\n"
    b"func h(a [1E0]int, b [1e0]int) {}\n\n"
    b"func i(a [0O1]int, b [0o1]int) {}\n"
)
NUM_MERGE_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a, b [0x1]int) {}\n"
    b"\n"
    b"func g(a, b [0b1]int) {}\n"
    b"\n"
    b"func h(a, b [1e0]int) {}\n"
    b"\n"
    b"func i(a, b [0o1]int) {}\n"
)

# Different values never merge, whatever their notation.
NUM_NO_MERGE_SRC = (
    b"package p\n\n"
    b"func f(a [0x1]int, b [0x2]int) {}\n\n"
    b"func g(a [1E0]int, b [2e0]int) {}\n"
)
NUM_NO_MERGE_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a [0x1]int, b [0x2]int) {}\n"
    b"\n"
    b"func g(a [1e0]int, b [2e0]int) {}\n"
)

# Without -extra nothing merges, and the literals are still normalised by
# the final print.
NUM_NO_EXTRA_SRC = b"package p\n\nfunc f(a [0X1]int, b [0x1]int) {}\n"
NUM_NO_EXTRA_OUT = b"package p\n\nfunc f(a [0x1]int, b [0x1]int) {}\n"

# Embedded interface elements have no parameter names, so the merge never
# applies to them, unlike named methods which do collapse.
EMB_IFACE_SRC = b"package p\n\ntype I interface{ Foo; Bar }\n"
EMB_IFACE_OUT = (
    b"package p\n"
    b"\n"
    b"type I interface {\n"
    b"\tFoo\n"
    b"\tBar\n"
    b"}\n"
)
EMB_METHODS_SRC = b"package p\n\ntype I interface{ M1(); M2() }\n"
EMB_METHODS_OUT = (
    b"package p\n"
    b"\n"
    b"type I interface {\n"
    b"\tM1()\n"
    b"}\n"
)

# A -modpath without a slash is its own whole prefix: "mymod/foo" is
# non-std, but "mymodfoo/bar" still counts as std.
MODPATH_SRC = (
    b"package p\n\nimport (\n\t\"fmt\"\n\t\"mymod/foo\"\n\t\"mymodfoo/bar\"\n)\n"
)
MODPATH_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b'\t"mymodfoo/bar"\n'
    b"\n"
    b'\t"mymod/foo"\n'
    b")\n"
)

# Only ADJACENT parameters of the same type merge: the differently-typed
# parameter in the middle keeps the outer two apart even though they share
# a type.
MERGE_ADJACENT_SRC = (
    b"package p\n\n"
    b"func f(a int, b *int, c int) {}\n\n"
    b"func g(a *T, b T, c *T) {}\n\n"
    b"type T struct{}\n"
)
MERGE_ADJACENT_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a int, b *int, c int) {}\n"
    b"\n"
    b"func g(a *T, b T, c *T) {}\n"
    b"\n"
    b"type T struct{}\n"
)


def test_short_multiline_case_clause_collapses(run):
    """A multi-line case expression short enough collapses onto one line.

    CATCHES: an implementation that never measures a split case clause, so
    a short "case a +\\n\\tb:" stays split instead of joining into
    "case a + b:".
    """
    result = run([], stdin=CC_SHORT_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == CC_SHORT_OUT


def test_long_multiline_case_clause_stays_split(run):
    """A long case expression is left on its two lines.

    CATCHES: an implementation that collapses every multi-line case clause
    regardless of the length estimate, producing an over-long line.
    """
    result = run([], stdin=CC_LONG_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == CC_LONG_OUT


def test_case_clause_collapse_sits_on_a_length_boundary(run):
    """One extra character in the case expression flips the collapse.

    CATCHES: an implementation whose length estimate for a case clause
    differs from the reference's (which counts the printed bytes plus an
    indentation allowance), moving the collapse threshold.
    """
    under = run([], stdin=CC_JUST_UNDER_SRC)
    assert under.returncode == 0, under.stderr
    assert under.stdout == CC_JUST_UNDER_OUT

    over = run([], stdin=CC_JUST_OVER_SRC)
    assert over.returncode == 0, over.stderr
    assert over.stdout == CC_JUST_OVER_OUT


def test_case_clause_with_inline_comment_collapses(run):
    """The inline comment after the colon rides along on the collapsed line.

    CATCHES: an implementation that drops or relocates the "// note" after
    the colon when joining the case expression onto one line.
    """
    result = run([], stdin=CC_COMMENT_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == CC_COMMENT_OUT


def test_number_normalisation_makes_param_types_equal(run):
    """Params whose types differ only in literal case merge under -extra.

    CATCHES: an implementation that compares parameter types by their raw
    text instead of printing them through the normalising engine, so
    "[0X1]int" and "[0x1]int" (and the 0B/1E/0O variants) never merge.
    """
    merged = run(["-extra=true"], stdin=NUM_MERGE_SRC)
    assert merged.returncode == 0, merged.stderr
    assert merged.stdout == NUM_MERGE_OUT

    plain = run([], stdin=NUM_NO_EXTRA_SRC)
    assert plain.returncode == 0, plain.stderr
    assert plain.stdout == NUM_NO_EXTRA_OUT


def test_number_normalisation_does_not_merge_different_values(run):
    """Types that differ in value stay separate under -extra.

    CATCHES: an implementation that merges parameter types because their
    literals merely look similar, turning two distinct array types into one
    shared parameter type.
    """
    result = run(["-extra=true"], stdin=NUM_NO_MERGE_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == NUM_NO_MERGE_OUT


def test_embedded_interface_elements_never_merge(run):
    """Embedded interface elements survive -extra; named methods do not.

    CATCHES: an implementation that applies the param merge to unnamed
    interface elements (which have no names to merge), or that keeps both
    M1() and M2() where the reference collapses the same-line methods.
    """
    embedded = run(["-extra=true"], stdin=EMB_IFACE_SRC)
    assert embedded.returncode == 0, embedded.stderr
    assert embedded.stdout == EMB_IFACE_OUT

    methods = run(["-extra=true"], stdin=EMB_METHODS_SRC)
    assert methods.returncode == 0, methods.stderr
    assert methods.stdout == EMB_METHODS_OUT


def test_modpath_without_slash_is_its_own_prefix(run):
    """-modpath mymod excludes mymod/... but keeps mymodfoo std.

    CATCHES: an implementation that only strips a prefix at a slash (or
    matches any path starting with the modpath letters), so "mymodfoo/bar"
    would wrongly be moved out of the standard-library group.
    """
    result = run(["-modpath", "mymod"], stdin=MODPATH_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == MODPATH_OUT


def test_param_merge_is_strictly_adjacent(run):
    """A differently-typed parameter keeps its neighbours apart.

    CATCHES: an implementation that groups every parameter of a shared type
    regardless of what sits between them, instead of only merging adjacent
    pairs whose types print identically.
    """
    result = run(["-extra=true"], stdin=MERGE_ADJACENT_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == MERGE_ADJACENT_OUT
