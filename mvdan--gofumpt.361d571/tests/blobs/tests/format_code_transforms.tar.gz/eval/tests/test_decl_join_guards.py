"""Guards on joining lone declaration lines.

gofumpt joins contiguous lone ``var``/``const``/``import`` lines into a
group, but only when the join is safe: a directive in the first
declaration's doc, an ``iota`` in a following ``const``, or comments that a
sort would displace all block the join.  These tests pin when the join
happens anyway and what happens to the comments in between.
"""

VAR_JOIN_SRC = b"package p\n\nvar a = 1\nvar b = 2\n"
VAR_JOIN_OUT = (
    b"package p\n"
    b"\n"
    b"var (\n"
    b"\ta = 1\n"
    b"\tb = 2\n"
    b")\n"
)

# A //go: directive in the first lone declaration's doc stops the chain
# from starting, so both lines stay separate.
VAR_DIRECTIVE_SRC = b"package p\n\n//go:generate foo\nvar a = 1\nvar b = 2\n"
VAR_DIRECTIVE_OUT = (
    b"package p\n"
    b"\n"
    b"//go:generate foo\n"
    b"var a = 1\n"
    b"var b = 2\n"
)

IMPORT_JOIN_SRC = b"package p\n\nimport \"fmt\"\nimport \"os\"\n"
IMPORT_JOIN_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b'\t"os"\n'
    b")\n"
)

IMPORT_DIRECTIVE_SRC = (
    b"package p\n\n//go:generate foo\nimport \"fmt\"\nimport \"os\"\n"
)
IMPORT_DIRECTIVE_OUT = (
    b"package p\n"
    b"\n"
    b"//go:generate foo\n"
    b'import "fmt"\n'
    b'import "os"\n'
)

CONST_PLAIN_SRC = b"package p\n\nconst a = 1\nconst b = 2\n"
CONST_PLAIN_OUT = (
    b"package p\n"
    b"\n"
    b"const (\n"
    b"\ta = 1\n"
    b"\tb = 2\n"
    b")\n"
)

# Appending an iota const to a group would renumber it, so it is never
# joined.
CONST_IOTA_SRC = b"package p\n\nconst a = 1\nconst b = iota\n"
CONST_IOTA_OUT = (
    b"package p\n"
    b"\n"
    b"const a = 1\n"
    b"const b = iota\n"
)

# Joining sorts the imports, which would displace a comment between them,
# so the comments may only ride along when the paths already ascend.
IJ_ASC_SRC = b"package p\n\nimport \"fmt\"\n// c\nimport \"os\"\n"
IJ_ASC_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b"\t// c\n"
    b'\t"os"\n'
    b")\n"
)

IJ_DESC_SRC = b"package p\n\nimport \"os\"\n// c\nimport \"fmt\"\n"
IJ_DESC_OUT = (
    b"package p\n"
    b"\n"
    b'import "os"\n'
    b"\n"
    b"// c\n"
    b'import "fmt"\n'
)

IJ_INLINE_FIRST_SRC = b"package p\n\nimport \"fmt\" // c\nimport \"os\"\n"
IJ_INLINE_FIRST_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt" // c\n'
    b'\t"os"\n'
    b")\n"
)

IJ_INLINE_LAST_SRC = b"package p\n\nimport \"fmt\"\nimport \"os\" // c\n"
IJ_INLINE_LAST_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b'\t"os" // c\n'
    b")\n"
)

IJ_TWO_COMMENTS_SRC = (
    b"package p\n\nimport \"fmt\"\n// a\nimport \"os\"\n// b\nimport \"sync\"\n"
)
IJ_TWO_COMMENTS_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b"\t// a\n"
    b'\t"os"\n'
    b"\t// b\n"
    b'\t"sync"\n'
    b")\n"
)

# A directive between two lone imports ends the chain, and go/printer
# separates it from the import above with a blank line.
IJ_DIRECTIVE_MID_SRC = (
    b"package p\n\nimport \"fmt\"\n//go:generate foo\nimport \"os\"\n"
)
IJ_DIRECTIVE_MID_OUT = (
    b"package p\n"
    b"\n"
    b'import "fmt"\n'
    b"\n"
    b"//go:generate foo\n"
    b'import "os"\n'
)

# A blank line before the comment also ends the chain, since the comment no
# longer lines up with the declaration above it.
IJ_COMMENT_GAP_SRC = b"package p\n\nimport \"fmt\"\n\n// c\nimport \"os\"\n"
IJ_COMMENT_GAP_OUT = (
    b"package p\n"
    b"\n"
    b'import "fmt"\n'
    b"\n"
    b"// c\n"
    b'import "os"\n'
)


def test_lone_var_lines_join_into_a_group(run):
    """Two lone var lines merge into one var group.

    CATCHES: an implementation that leaves contiguous lone var declarations
    as separate lines instead of collecting them into a parenthesised
    group.
    """
    result = run([], stdin=VAR_JOIN_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == VAR_JOIN_OUT


def test_directive_doc_prevents_lone_var_joining(run):
    """A //go: directive above the first lone var blocks the join.

    CATCHES: an implementation that joins lone declarations without first
    checking their doc comments for directives, which would pull a
    //go:generate line into the middle of a var group.
    """
    result = run([], stdin=VAR_DIRECTIVE_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == VAR_DIRECTIVE_OUT


def test_lone_import_lines_join_into_a_group(run):
    """Two lone import lines merge into one import group.

    CATCHES: an implementation that keeps lone import declarations apart
    instead of joining contiguous ones into a single sorted group.
    """
    result = run([], stdin=IMPORT_JOIN_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == IMPORT_JOIN_OUT


def test_directive_doc_prevents_lone_import_joining(run):
    """A //go: directive above the first lone import blocks the join.

    CATCHES: an implementation that joins lone imports regardless of a
    directive in the leading doc comment, which would strand the directive
    above a group it was not attached to.
    """
    result = run([], stdin=IMPORT_DIRECTIVE_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == IMPORT_DIRECTIVE_OUT


def test_lone_const_lines_join_into_a_group(run):
    """Two lone const lines merge into one const group.

    CATCHES: an implementation that only joins var and import lines but
    leaves contiguous lone const declarations separate.
    """
    result = run([], stdin=CONST_PLAIN_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == CONST_PLAIN_OUT


def test_iota_in_a_following_const_blocks_joining(run):
    """A lone const mentioning iota is never appended to another.

    CATCHES: an implementation that joins const declarations without
    checking for iota, which would silently change the value the second
    const's iota resolves to.
    """
    result = run([], stdin=CONST_IOTA_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == CONST_IOTA_OUT


def test_commented_lone_imports_join_when_paths_ascending(run):
    """A comment between lone imports rides along when sorted already.

    CATCHES: an implementation that refuses to join any commented lone
    import, or that joins them but drops the "// c" line instead of keeping
    it attached to its import inside the group.
    """
    result = run([], stdin=IJ_ASC_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == IJ_ASC_OUT


def test_commented_lone_imports_do_not_join_when_descending(run):
    """Descending paths plus a comment keep the lone imports apart.

    CATCHES: an implementation that joins commented lone imports even when
    the sort would move an import across the comment, leaving the comment
    behind next to the wrong import.
    """
    result = run([], stdin=IJ_DESC_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == IJ_DESC_OUT


def test_inline_comment_on_a_joined_import_rides_along(run):
    """An inline import comment stays on its import after the join.

    CATCHES: an implementation that loses the trailing "// c" of a lone
    import when folding it into a group, or that lets it fall onto the
    closing parenthesis line.
    """
    first = run([], stdin=IJ_INLINE_FIRST_SRC)
    assert first.returncode == 0, first.stderr
    assert first.stdout == IJ_INLINE_FIRST_OUT

    last = run([], stdin=IJ_INLINE_LAST_SRC)
    assert last.returncode == 0, last.stderr
    assert last.stdout == IJ_INLINE_LAST_OUT


def test_two_commented_lone_imports_join(run):
    """A chain of commented lone imports joins with every comment kept.

    CATCHES: an implementation that joins only the first pair of commented
    lone imports, or that reorders the comments away from their imports.
    """
    result = run([], stdin=IJ_TWO_COMMENTS_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == IJ_TWO_COMMENTS_OUT


def test_directive_between_lone_imports_blocks_joining(run):
    """A //go: directive above the second lone import ends the chain.

    CATCHES: an implementation that only checks the first declaration's doc
    for directives, letting a //go:generate line be swallowed into the
    middle of a joined import group.
    """
    result = run([], stdin=IJ_DIRECTIVE_MID_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == IJ_DIRECTIVE_MID_OUT


def test_comment_separated_by_a_blank_line_blocks_joining(run):
    """A blank line before the comment keeps the lone imports apart.

    CATCHES: an implementation that joins lone imports across a blank line
    as long as a comment sits above the second one, stranding that comment
    between the two declarations.
    """
    result = run([], stdin=IJ_COMMENT_GAP_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == IJ_COMMENT_GAP_OUT
