"""Language-version-gated octal literal rewrite: ``0755`` becomes ``0o755``.

The rewrite only happens when the effective -lang is go1.13 or later, so the
same source formats differently depending on -lang, the go.mod above the
file, or the default of go1 when neither is present.
"""

import pytest

MODERN_SRC = """\
package p

const c = 0755

func f() {
\t_ = 0777
\t_ = 0
\t_ = 00
\t_ = 0_1
\t_ = 0x1f
\t_ = 0o755
\t_ = 1e5
\t_ = 0.5
}
"""

MODERN_OUT = (
    b"package p\n"
    b"\n"
    b"const c = 0o755\n"
    b"\n"
    b"func f() {\n"
    b"\t_ = 0o777\n"
    b"\t_ = 0\n"
    b"\t_ = 0o0\n"
    b"\t_ = 0o_1\n"
    b"\t_ = 0x1f\n"
    b"\t_ = 0o755\n"
    b"\t_ = 1e5\n"
    b"\t_ = 0.5\n"
    b"}\n"
)

LEGACY_SRC = """\
package p

func f() {
\t_ = 0755
}
"""

POSITIONS_SRC = """\
package p

var m = map[int]int{0755: 1}

func f(x int) int { return x + 0755 }

type T struct{ a int }

var t = T{a: 0755}
"""

POSITIONS_OUT = (
    b"package p\n"
    b"\n"
    b"var m = map[int]int{0o755: 1}\n"
    b"\n"
    b"func f(x int) int { return x + 0o755 }\n"
    b"\n"
    b"type T struct{ a int }\n"
    b"\n"
    b"var t = T{a: 0o755}\n"
)


@pytest.mark.parametrize("lang", ["go1.13", "go1.14", "go1.21"])
def test_octal_modernized_from_go1_13(run, lang):
    """Legacy octal ints become 0o-prefixed once -lang >= go1.13.

    CATCHES: an implementation that applies the octal rewrite regardless of
    the language version, or that misses the ``00`` and ``0_1`` corner cases
    matched by the octal pattern.
    """
    result = run(["-lang", lang], stdin=MODERN_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == MODERN_OUT
    assert result.stderr == b""


@pytest.mark.parametrize("args", [["-lang", "go1.12"], ["-lang", "go1.9"], []])
def test_octal_kept_below_go1_13(run, args):
    """With -lang < go1.13 (or no lang at all) legacy octals stay verbatim.

    CATCHES: an implementation that rewrites ``0755`` even when the effective
    language version predates Go 1.13's 0o literal syntax.
    """
    result = run(args, stdin=LEGACY_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == LEGACY_SRC.encode()
    assert result.stderr == b""


def test_octal_rewrite_across_syntactic_positions(run):
    """The rewrite hits octals in const decls, map keys, exprs and literals.

    CATCHES: an implementation that only rewrites octals in simple assignment
    statements and leaves map keys or composite-literal values untouched.
    """
    result = run(["-lang", "go1.14"], stdin=POSITIONS_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == POSITIONS_OUT


def test_octal_rewrite_is_idempotent(run):
    """Reformatting already-modernized output changes nothing.

    CATCHES: a rewrite that mangles already-0o literals on a second pass,
    e.g. producing ``0oo755`` or reordering digits; pinning the recorded
    first-pass bytes also catches a formatter that outputs nothing at all.
    """
    once = run(["-lang", "go1.21"], stdin=MODERN_SRC.encode())
    assert once.returncode == 0, once.stderr
    assert once.stdout == MODERN_OUT
    twice = run(["-lang", "go1.21"], stdin=MODERN_OUT)
    assert twice.returncode == 0, twice.stderr
    assert twice.stdout == MODERN_OUT


def test_go_mod_lang_gates_octal_and_flag_overrides(run, work):
    """go.mod's go directive gates the rewrite; an explicit -lang wins.

    CATCHES: an implementation that ignores the go.mod language version or
    lets it override an explicit -lang flag on the command line.
    """
    (work / "go.mod").write_text("module example.com/foo\n\ngo 1.16\n")
    from_mod = run([], stdin=LEGACY_SRC.encode())
    assert from_mod.returncode == 0, from_mod.stderr
    assert from_mod.stdout == (
        b"package p\n"
        b"\n"
        b"func f() {\n"
        b"\t_ = 0o755\n"
        b"}\n"
    )
    overridden = run(["-lang", "go1.12"], stdin=LEGACY_SRC.encode())
    assert overridden.returncode == 0, overridden.stderr
    assert overridden.stdout == LEGACY_SRC.encode()


def test_invalid_lang_version_panics(run):
    """A malformed -lang makes the run fail with a panic, not a clean diff.

    CATCHES: an implementation that silently accepts an invalid language
    version instead of failing loudly with a nonzero exit and panic text.
    """
    result = run(["-lang", "garbage"], stdin=b"package p\n")
    assert result.returncode == 2
    assert result.stdout == b""
    assert b'panic: invalid Go version: "garbage"' in result.stderr
