"""Span-level heuristics of the vendored doc comment engine.

The go/doc/comment parser recovers common misindentations inside doc
comments before deciding what is a paragraph, a list or a code block:
an unindented line ending in ``{`` donates itself to the indented block
below it, an unindented ``}`` is absorbed by the indented block above,
and an unindented list whose wrap is indented is re-read as a real list.
The remaining tests pin the smaller gates: whitespace-only doc edges are
dropped, apostrophes and dots can disqualify an old-style heading, a
malformed link definition stays inline text, and numbered markers need
more than digits to make a list.
"""

MISINDENTED_CODE_SRC = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"// func main() {\n"
    b"//\tx := 1\n"
    b"// }\n"
    b"//\n"
    b"// After.\n"
    b"func f() {}\n"
)
MISINDENTED_CODE_OUT = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"//\tfunc main() {\n"
    b"//\t\tx := 1\n"
    b"//\t}\n"
    b"//\n"
    b"// After.\n"
    b"func f() {}\n"
)

# Only the closing brace is unindented here; it still joins the code block.
BRACE_AFTER_CODE_SRC = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"//\tx := 1\n"
    b"// }\n"
    b"//\n"
    b"// After.\n"
    b"func f() {}\n"
)
BRACE_AFTER_CODE_OUT = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"//\t\tx := 1\n"
    b"//\t}\n"
    b"//\n"
    b"// After.\n"
    b"func f() {}\n"
)

UNINDENTED_LIST_SRC = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"// - a\n"
    b"// - b\n"
    b"//   cont\n"
    b"//\n"
    b"// After.\n"
    b"func f() {}\n"
)
UNINDENTED_LIST_OUT = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"//   - a\n"
    b"//   - b\n"
    b"//     cont\n"
    b"//\n"
    b"// After.\n"
    b"func f() {}\n"
)

# A tab-only comment line is whitespace after the "// " prefix is cut, so
# the doc text has whitespace-only edge lines; the engine drops them.
WS_EDGE_SRC = b"package p\n\n//\t\n// Foo bar.\n//\t\nfunc f() {}\n"
WS_EDGE_OUT = b"package p\n\n// Foo bar.\nfunc f() {}\n"

APOSTROPHE_REJECT_SRC = (
    b"package p\n\n// Intro.\n//\n// Don't Panic\n//\n// End.\nfunc f() {}\n"
)
APOSTROPHE_REJECT_OUT = (
    b"package p\n\n// Intro.\n//\n// Don't Panic\n//\n// End.\nfunc f() {}\n"
)
APOSTROPHE_ALLOW_SRC = (
    b"package p\n\n// Intro.\n//\n// Foo's Bar\n//\n// End.\nfunc f() {}\n"
)
APOSTROPHE_ALLOW_OUT = (
    b"package p\n\n// Intro.\n//\n// # Foo's Bar\n//\n// End.\nfunc f() {}\n"
)

DOT_REJECT_SRC = (
    b"package p\n\n// Intro.\n//\n// Go 1. Released\n//\n// End.\nfunc f() {}\n"
)
DOT_REJECT_OUT = (
    b"package p\n\n// Intro.\n//\n// Go 1. Released\n//\n// End.\nfunc f() {}\n"
)

# Both malformed definitions stay paragraph text while the one well-formed
# definition is reordered below the paragraph.
DEF_NO_SPACE_SRC = (
    b"package p\n"
    b"\n"
    b"// [real]: https://example.com\n"
    b"//\n"
    b"// [foo]:bar is not a definition\n"
    b"func f() {}\n"
)
DEF_NO_SPACE_OUT = (
    b"package p\n"
    b"\n"
    b"// [foo]:bar is not a definition\n"
    b"//\n"
    b"// [real]: https://example.com\n"
    b"func f() {}\n"
)
DEF_BAD_SCHEME_SRC = (
    b"package p\n"
    b"\n"
    b"// [real]: https://example.com\n"
    b"//\n"
    b"// [foo]: notaurl\n"
    b"func f() {}\n"
)
DEF_BAD_SCHEME_OUT = (
    b"package p\n"
    b"\n"
    b"// [foo]: notaurl\n"
    b"//\n"
    b"// [real]: https://example.com\n"
    b"func f() {}\n"
)

MULTIDIGIT_SRC = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"//  10. ten\n"
    b"//  11. eleven\n"
    b"//\n"
    b"// End.\n"
    b"func f() {}\n"
)
MULTIDIGIT_OUT = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"//  10. ten\n"
    b"//  11. eleven\n"
    b"//\n"
    b"// End.\n"
    b"func f() {}\n"
)

# Each tab-indented line starts its own span (the unindented "stays" lines
# split them), and none of them parses as a list marker: digits without a
# period, "1.5" with no space after the dot, and a bare dash all stay code.
DIGIT_LED_SRC = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"// \t123abc\n"
    b"// stays\n"
    b"// \t1.5\n"
    b"// stays\n"
    b"// \t-\n"
    b"//\n"
    b"// End.\n"
    b"func f() {}\n"
)
DIGIT_LED_OUT = (
    b"package p\n"
    b"\n"
    b"// Intro.\n"
    b"//\n"
    b"//\t123abc\n"
    b"//\n"
    b"// stays\n"
    b"//\n"
    b"//\t1.5\n"
    b"//\n"
    b"// stays\n"
    b"//\n"
    b"//\t-\n"
    b"//\n"
    b"// End.\n"
    b"func f() {}\n"
)
LIST_CONTRAST_SRC = (
    b"package p\n\n// Intro.\n//\n//  1. 5\n//\n// End.\nfunc f() {}\n"
)
LIST_CONTRAST_OUT = (
    b"package p\n\n// Intro.\n//\n//  1. 5\n//\n// End.\nfunc f() {}\n"
)


def test_misindented_code_lines_are_reindented_into_a_code_block(run):
    """Unindented ``func main() {`` plus indented body becomes code.

    CATCHES: an implementation that treats the unindented opening line as
    prose and the indented body as a separate code block, instead of
    donating the ``{`` line to the block below it.
    """
    result = run([], stdin=MISINDENTED_CODE_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == MISINDENTED_CODE_OUT


def test_unindented_closing_brace_joins_the_code_block(run):
    """A column-1 ``}`` line is absorbed by the code block above it.

    CATCHES: an implementation that leaves the closing brace unindented
    as paragraph text, breaking the pasted func literal in two.
    """
    result = run([], stdin=BRACE_AFTER_CODE_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == BRACE_AFTER_CODE_OUT


def test_unindented_list_with_indented_wrap_is_reparsed_as_a_list(run):
    """Unindented bullets plus an indented wrap become a real list.

    CATCHES: an implementation that keeps the unindented marker lines as
    plain paragraph text instead of re-reading them as a bullet list with
    the continuation indented under its item.
    """
    result = run([], stdin=UNINDENTED_LIST_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == UNINDENTED_LIST_OUT


def test_whitespace_only_doc_edges_are_dropped(run):
    """Tab-only comment lines at the doc's edges vanish after reflow.

    CATCHES: an implementation that keeps the whitespace-only lines as
    empty ``//`` lines around the paragraph instead of trimming the doc
    text's blank edges.
    """
    result = run([], stdin=WS_EDGE_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == WS_EDGE_OUT


def test_old_heading_apostrophe_rules(run):
    """``Don't Panic`` stays a paragraph; ``Foo's Bar`` becomes a heading.

    CATCHES: an implementation that ignores the possessive-apostrophe
    rule, either converting ``Don't Panic`` to a ``#`` heading or
    refusing to convert the allowed ``Foo's Bar`` form.
    """
    reject = run([], stdin=APOSTROPHE_REJECT_SRC)
    assert reject.returncode == 0, reject.stderr
    assert reject.stdout == APOSTROPHE_REJECT_OUT

    allow = run([], stdin=APOSTROPHE_ALLOW_SRC)
    assert allow.returncode == 0, allow.stderr
    assert allow.stdout == APOSTROPHE_ALLOW_OUT


def test_dot_followed_by_space_rejects_old_heading(run):
    """``Go 1. Released`` is not a heading because the dot ends a word.

    CATCHES: an implementation that accepts any dotted line as an
    old-style heading, adding ``# `` to text whose period is followed by
    a space.
    """
    result = run([], stdin=DOT_REJECT_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == DOT_REJECT_OUT


def test_malformed_link_definitions_stay_inline(run):
    """Defs missing a space or a scheme stay text; the real one moves.

    CATCHES: an implementation that treats ``[foo]:bar`` or
    ``[foo]: notaurl`` as link definitions, reordering them to the end
    instead of leaving them as ordinary paragraph lines.
    """
    nospace = run([], stdin=DEF_NO_SPACE_SRC)
    assert nospace.returncode == 0, nospace.stderr
    assert nospace.stdout == DEF_NO_SPACE_OUT

    badscheme = run([], stdin=DEF_BAD_SCHEME_SRC)
    assert badscheme.returncode == 0, badscheme.stderr
    assert badscheme.stdout == DEF_BAD_SCHEME_OUT


def test_multidigit_numbered_list_markers(run):
    """Numbers with two or more digits keep their multi-digit markers.

    CATCHES: an implementation whose list marker scan only handles a
    single digit, mangling ``10.``/``11.`` items or dropping their
    numbers entirely.
    """
    result = run([], stdin=MULTIDIGIT_SRC)
    assert result.returncode == 0, result.stderr
    assert result.stdout == MULTIDIGIT_OUT


def test_digit_led_indented_lines_stay_code(run):
    """``123abc``, ``1.5`` and a bare ``-`` are code, ``1. 5`` is a list.

    CATCHES: an implementation that parses digit-led lines as list items
    without requiring a marker plus space, turning code fragments into
    numbered lists -- while the true ``1. 5`` marker form must stay a
    list with spaces rather than a tab.
    """
    code = run([], stdin=DIGIT_LED_SRC)
    assert code.returncode == 0, code.stderr
    assert code.stdout == DIGIT_LED_OUT

    lst = run([], stdin=LIST_CONTRAST_SRC)
    assert lst.returncode == 0, lst.stderr
    assert lst.stdout == LIST_CONTRAST_OUT
