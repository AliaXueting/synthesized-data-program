"""gofmt -s style range simplification: blank range keys/values are dropped.

``for x, _ = range v`` becomes ``for x = range v`` and ``for _ = range v``
becomes ``for range v``.  gofumpt always simplifies; there is no -s flag.
"""

RANGE_SRC = """\
package p

func f() {
\tvar v []int
\tfor x, _ = range v {
\t}
\tfor _ = range v {
\t}
\tfor _, _ = range v {
\t}
\tfor x, _ := range v {
\t}
\tfor _ := range v {
\t}
\tfor x, y := range v {
\t}
\tfor range v {
\t}
\tfor _ = range 5 {
\t}
\tfor _ = range "abc" {
\t}
\tfor _ = range make(chan int) {
\t}
}
"""

RANGE_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\tvar v []int\n"
    b"\tfor x = range v {\n"
    b"\t}\n"
    b"\tfor range v {\n"
    b"\t}\n"
    b"\tfor range v {\n"
    b"\t}\n"
    b"\tfor x := range v {\n"
    b"\t}\n"
    b"\tfor range v {\n"
    b"\t}\n"
    b"\tfor x, y := range v {\n"
    b"\t}\n"
    b"\tfor range v {\n"
    b"\t}\n"
    b"\tfor range 5 {\n"
    b"\t}\n"
    b"\tfor range \"abc\" {\n"
    b"\t}\n"
    b"\tfor range make(chan int) {\n"
    b"\t}\n"
    b"}\n"
)


def test_range_blank_key_and_value_simplified(run):
    """Blank range variables are removed, for both = and := forms.

    CATCHES: a re-implementation without the gofmt -s range rewrite, which
    would print ``for x, _ = range v`` and ``for _ = range v`` unchanged.
    """
    result = run([], stdin=RANGE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == RANGE_OUT
    assert result.stderr == b""


def test_range_non_blank_variables_kept(run):
    """Range statements with two real variables are left alone.

    CATCHES: an over-eager rewrite that also drops a non-blank value or key.
    """
    src = (
        b"package p\n"
        b"\n"
        b"func f(m map[string]int) {\n"
        b"\tfor k, v := range m {\n"
        b"\t\t_ = k\n"
        b"\t\t_ = v\n"
        b"\t}\n"
        b"\tfor _, err := range m {\n"
        b"\t\t_ = err\n"
        b"\t}\n"
        b"}\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"func f(m map[string]int) {\n"
        b"\tfor k, v := range m {\n"
        b"\t\t_ = k\n"
        b"\t\t_ = v\n"
        b"\t}\n"
        b"\tfor _, err := range m {\n"
        b"\t\t_ = err\n"
        b"\t}\n"
        b"}\n"
    )


def test_range_simplification_with_inline_comment(run):
    """A comment between the range keyword and its body survives the rewrite.

    CATCHES: losing or moving an inline comment while dropping the blank
    range variable.
    """
    src = (
        b"package p\n"
        b"\n"
        b"func f() {\n"
        b"\tvar v []int\n"
        b"\tfor _ = range v { // over v\n"
        b"\t}\n"
        b"}\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"func f() {\n"
        b"\tvar v []int\n"
        b"\tfor range v { // over v\n"
        b"\t}\n"
        b"}\n"
    )


def test_range_and_slice_simplification_together(run):
    """The range and slice rewrites apply in the same statement.

    CATCHES: an implementation that applies only one AST rewrite per
    statement, or that re-parses between rules and loses the second one.
    """
    src = (
        b"package p\n"
        b"\n"
        b"func f() {\n"
        b"\tvar s []int\n"
        b"\tfor _, _ = range s[0:len(s)] {\n"
        b"\t}\n"
        b"}\n"
    )
    result = run([], stdin=src)
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        b"package p\n"
        b"\n"
        b"func f() {\n"
        b"\tvar s []int\n"
        b"\tfor range s[0:] {\n"
        b"\t}\n"
        b"}\n"
    )
