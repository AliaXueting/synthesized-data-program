"""Doc comments are reflowed through the go/doc/comment engine.

The package doc and declaration docs get canonical paragraph, list, code
block and directive layout; import docs (potential cgo preambles) and
old-style /* */ docs are never touched, and a doc left with no text
disappears entirely.
"""

DOC_SHAPE_SRC = """\
package p

// Foo does something.
//
// More detail here   with   extra spaces.
//
// A list:
//   - one
//   - two
//
// Code:
//     x := 1
//     y := 2
func f() {}
"""

DOC_SHAPE_OUT = (
    b"package p\n"
    b"\n"
    b"// Foo does something.\n"
    b"//\n"
    b"// More detail here   with   extra spaces.\n"
    b"//\n"
    b"// A list:\n"
    b"//   - one\n"
    b"//   - two\n"
    b"//\n"
    b"// Code:\n"
    b"//\n"
    b"//\tx := 1\n"
    b"//\ty := 2\n"
    b"func f() {}\n"
)

BLOCK_DOC_SRC = """\
package p

/*
Foo does something.


More detail.
*/
func f() {}
"""

BLOCK_DOC_OUT = (
    b"package p\n"
    b"\n"
    b"/*\n"
    b"Foo does something.\n"
    b"\n"
    b"More detail.\n"
    b"*/\n"
    b"func f() {}\n"
)

STAR_DOC_SRC = """\
package p

/**
 * Foo does something.
 */
func f() {}
"""

SINGLE_LINE_DOC_SRC = """\
package p

/* foo bar */
func f() {}
"""

IMPORT_DOC_SRC = """\
package p

// preamble
//    indented line
import "C"
"""

FUNC_DOC_SAME_SHAPE_SRC = """\
package p

// preamble
//    indented line
func f() {}
"""

FUNC_DOC_SAME_SHAPE_OUT = (
    b"package p\n"
    b"\n"
    b"// preamble\n"
    b"//\n"
    b"//\tindented line\n"
    b"func f() {}\n"
)

DIRECTIVE_DOC_SRC = """\
package p

// Deprecated: use g.
//go:noinline
func f() {}
"""

DIRECTIVE_DOC_OUT = (
    b"package p\n"
    b"\n"
    b"// Deprecated: use g.\n"
    b"//\n"
    b"//go:noinline\n"
    b"func f() {}\n"
)

DIRECTIVE_ONLY_DOC_SRC = """\
package p

//go:generate foo
func f() {}
"""

LINKS_DOC_SRC = """\
package p

// See [Foo] and [#Anchor] plus https://example.com docs.
//
// # Heading
//
// Text under heading.
func f() {}
"""


def test_doc_paragraphs_lists_and_code_blocks(run):
    """Paragraphs keep inner spacing, code blocks re-indent to tabs.

    CATCHES: an implementation that misses the blank // line the engine
    inserts before an indented code block, or re-indents it with spaces.
    """
    result = run([], stdin=DOC_SHAPE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == DOC_SHAPE_OUT
    assert result.stderr == b""


def test_doc_with_no_text_is_dropped(run):
    """A doc comment holding only empty // lines vanishes with its lines.

    CATCHES: an implementation that keeps the empty comment lines above the
    declaration instead of removing the whole group.
    """
    result = run([], stdin=b"package p\n\n//\n//\nfunc f() {}\n")
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"package p\n\nfunc f() {}\n"


def test_block_doc_comment_is_reflowed(run):
    """A multi-line /* */ doc is reprinted with normalized blank lines.

    CATCHES: an implementation leaving /* */ docs byte-identical, or one that
    collapses the paragraph-separating blank line entirely.
    """
    result = run([], stdin=BLOCK_DOC_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == BLOCK_DOC_OUT


def test_star_style_and_single_line_block_docs_untouched(run):
    """All-stars /** ... */ docs and one-line /* */ docs stay verbatim.

    CATCHES: an implementation that reflows the old star-continuation style
    or a single-line block comment, mangling historical doc formats.
    """
    for src in (STAR_DOC_SRC, SINGLE_LINE_DOC_SRC):
        result = run([], stdin=src.encode())
        assert result.returncode == 0, result.stderr
        assert result.stdout == src.encode()


def test_import_doc_is_never_formatted(run):
    """A doc comment on import "C" keeps its irregular lines untouched.

    CATCHES: an implementation that runs the doc engine over import docs,
    which would re-indent the cgo preamble's indented lines and break C code.
    """
    result = run([], stdin=IMPORT_DOC_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == IMPORT_DOC_SRC.encode()

    # The identical comment shape on a func declaration IS reflowed, proving
    # the import exemption is what made the difference above.
    result = run([], stdin=FUNC_DOC_SAME_SHAPE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == FUNC_DOC_SAME_SHAPE_OUT


def test_doc_text_prints_before_its_directives(run):
    """Directives in a doc comment move after the text behind a bare //.

    CATCHES: an implementation printing directives in place, interleaved with
    the reflowed paragraphs.
    """
    result = run([], stdin=DIRECTIVE_DOC_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == DIRECTIVE_DOC_OUT

    # A doc made only of directives keeps its single line unchanged.
    result = run([], stdin=DIRECTIVE_ONLY_DOC_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == DIRECTIVE_ONLY_DOC_SRC.encode()


def test_doc_links_and_headings_survive_reflow(run):
    """Doc links, anchors, URLs and headings round-trip unchanged.

    CATCHES: an implementation whose doc reflow escapes or drops bracketed
    link syntax or heading lines starting with "# ".
    """
    result = run([], stdin=LINKS_DOC_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == LINKS_DOC_SRC.encode()
