"""Shared black-box helpers for the gofumpt ``format_code_transforms`` module.

The binary under test is only ever exercised through its command line: the
helpers here never import anything from it and never hardcode its location,
the path always comes from PROGRAMGYM_EXECUTABLE.  Every expected byte the
tests compare against was recorded by running the reference binary.
"""

import functools
import os
import subprocess
import tempfile
from pathlib import Path

import pytest

# gofumpt reports its own Go runtime version inside a //gofumpt:diagnose
# directive (internal/version).  The reference honours GO_VERSION_TEST to
# override it, which lets the diagnose tests pin that half of the string
# instead of depending on the toolchain that built the binary.
GO_VERSION_TEST = "go1.999.0"


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--version' once against a throwaway GOCOVERDIR, so the
    check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="gofumpt-covprobe-") as probe:
        env = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "HOME": probe,
            "GOCOVERDIR": probe,
        }
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe).glob("covcounters.*"))


def gofumpt_binary():
    """Return the gofumpt binary under test, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the gofumpt binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but the
    # pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to the
    # module's uninstrumented copy before pytest starts, so the counters would
    # never be written and this module's coverage report would stay empty.
    # During a coverage run (GOCOVERDIR present), when the assigned binary is
    # not itself instrumented, fall back to the instrumented build the driver
    # stages next to the module workspaces.  Ordinary validation runs have no
    # GOCOVERDIR and always test the binary they were given.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if staged.exists() and _writes_counters(str(staged)):
            return str(staged)
    return path


def base_env(home, extra=None):
    """Build the child environment from scratch: no TTY, no leakage.

    Only PATH/LANG/HOME/TMPDIR are set plus whatever a test explicitly asks
    for, so GOFLAGS, GOPATH, GO111MODULE, GOFUMPT_* and friends cannot leak in
    from the test process.  GOCOVERDIR is forwarded only so a
    coverage-instrumented binary can write its counters; gofumpt's own
    behavior never reads it.
    """
    child = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
        "HOME": str(home),
        "TMPDIR": str(home),
    }
    # Coverage hook: forward GOCOVERDIR so an instrumented reference build can
    # drop its counter files (see INSTRUCTION.md).
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    child.update(cov_env)
    if extra:
        child.update(extra)
    return child


def run_gofumpt(args, cwd, env=None, stdin=b"", home=None, timeout=30):
    """Run gofumpt with 'args' and return the CompletedProcess result.

    stdin is always a pipe and stdout/stderr are always captured, so the
    program never sees a terminal, and the working directory is always the
    caller's scratch directory (gofumpt resolves a default -lang/-modpath from
    the go.mod above its input, so an uncontrolled cwd would change behavior).
    """
    if home is None:
        home = cwd
    return subprocess.run(
        [gofumpt_binary()] + [str(a) for a in args],
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd),
        env=base_env(home, env),
        timeout=timeout,
    )


@pytest.fixture
def work(tmp_path):
    """A fresh, empty working directory (gofumpt's cwd) for one test."""
    d = tmp_path / "work"
    d.mkdir()
    return d


@pytest.fixture
def home(tmp_path):
    """A fresh, empty HOME directory for one test."""
    d = tmp_path / "home"
    d.mkdir()
    return d


@pytest.fixture
def run(work, home):
    """run_gofumpt bound to this test's scratch cwd and HOME."""

    def _run(args, env=None, stdin=b"", cwd=None):
        return run_gofumpt(
            args, cwd=cwd or work, env=env, stdin=stdin, home=home
        )

    return _run


def write_file(directory, name, text):
    """Write 'text' to directory/name and return its path."""
    path = Path(directory) / name
    path.write_text(text)
    return path
