"""The ``//gofumpt:diagnose`` directive reports version and resolved flags.

Any comment line parsed as a gofumpt tool directive named "diagnose" is
replaced by a single line echoing the gofumpt version plus the effective
-lang, -modpath and -extra settings, wherever the comment sits.

The version half of the line is whatever the binary reports for --version
(it varies with how the binary was built), so the tests take it from a
--version run in the same environment; everything around it is asserted
byte-for-byte.
"""

# The go-toolchain half of the reported version comes from the Go runtime and
# is pinned through GO_VERSION_TEST, an environment variable the reference
# honours for exactly this purpose.
PIN_ENV = {"GO_VERSION_TEST": "go1.999.0"}


def reported_version(run, env=None):
    """Return the version string this build reports for --version."""
    result = run(["--version"], env=env)
    assert result.returncode == 0, result.stderr
    return result.stdout.decode().rstrip("\n")


def test_diagnose_basic_rewrite(run):
    """A bare diagnose directive becomes a version+flags line, verbatim shape.

    CATCHES: an implementation that gets the wording, spacing or ordering of
    the reported fields wrong, or that leaves the directive untouched.
    """
    version = reported_version(run)
    result = run([], stdin=b"//gofumpt:diagnose\npackage p\n")
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        "//gofumpt:diagnose version: %s flags: -lang=go1 -modpath="
        "\npackage p\n" % version
    ).encode()


def test_diagnose_reflects_lang_and_modpath_flags(run):
    """The reported -lang/-modpath echo the flags actually in effect.

    CATCHES: an implementation reporting hardcoded or wrongly-resolved flag
    values instead of the effective ones.
    """
    version = reported_version(run, PIN_ENV)
    result = run(
        ["-lang", "go1.23", "-modpath", "example.com/foo"],
        env=PIN_ENV,
        stdin=b"//gofumpt:diagnose\npackage p\n",
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        "//gofumpt:diagnose version: %s flags: -lang=go1.23"
        " -modpath=example.com/foo\npackage p\n" % version
    ).encode()


def test_diagnose_reflects_extra_rules(run):
    """Enabled extra rules are listed as -extra= in their fixed order.

    CATCHES: an implementation that omits -extra when rules are on, or lists
    them in a different order than group_params,clothe_returns,balance_calls.
    """
    version = reported_version(run, PIN_ENV)
    result = run(
        ["-extra=group_params", "-lang", "go1.21"],
        env=PIN_ENV,
        stdin=b"//gofumpt:diagnose\npackage p\n",
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        "//gofumpt:diagnose version: %s flags: -lang=go1.21 -modpath="
        " -extra=group_params\npackage p\n" % version
    ).encode()

    all_rules = run(
        ["-extra=true"],
        env=PIN_ENV,
        stdin=b"//gofumpt:diagnose\npackage p\n",
    )
    assert all_rules.returncode == 0, all_rules.stderr
    assert all_rules.stdout == (
        "//gofumpt:diagnose version: %s flags: -lang=go1 -modpath="
        " -extra=group_params,clothe_returns,balance_calls\npackage p\n"
        % version
    ).encode()


def test_diagnose_trailing_text_is_replaced(run):
    """Text after the directive name is discarded, not appended.

    CATCHES: an implementation that keeps the user's trailing words around,
    producing a diagnose line that grows on every run.
    """
    version = reported_version(run, PIN_ENV)
    result = run(
        ["-lang", "go1.21"],
        env=PIN_ENV,
        stdin=b"//gofumpt:diagnose trailing words here\npackage p\n",
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        "//gofumpt:diagnose version: %s flags: -lang=go1.21 -modpath="
        "\npackage p\n" % version
    ).encode()


def test_diagnose_inside_function_body(run):
    """A diagnose comment in a statement list is rewritten like any other.

    CATCHES: an implementation that only rewrites the directive when it is a
    doc comment attached to a declaration.
    """
    version = reported_version(run, PIN_ENV)
    result = run(
        ["-lang", "go1.22"],
        env=PIN_ENV,
        stdin=b"package p\n\nfunc f() {\n\t//gofumpt:diagnose\n}\n",
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        "package p\n\nfunc f() {\n\t//gofumpt:diagnose version: %s"
        " flags: -lang=go1.22 -modpath=\n}\n" % version
    ).encode()


def test_diagnose_in_doc_comment_moves_after_text(run):
    """A diagnose line inside a doc comment is reordered to the directives.

    CATCHES: an implementation that rewrites the directive in place, which
    would leave it interleaved with the doc paragraphs instead of moved to
    the blank-// separated directive block at the end.
    """
    version = reported_version(run, PIN_ENV)
    result = run(
        ["-lang", "go1.20"],
        env=PIN_ENV,
        stdin=b"package p\n\n// Doc line.\n//gofumpt:diagnose\n"
        b"// More doc.\nfunc f() {}\n",
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        "package p\n\n// Doc line.\n// More doc.\n//\n"
        "//gofumpt:diagnose version: %s flags: -lang=go1.20 -modpath="
        "\nfunc f() {}\n" % version
    ).encode()


def test_diagnose_reports_go_version_env(run):
    """GO_VERSION_TEST replaces the Go-toolchain half of the version.

    CATCHES: an implementation that does not honour the environment override,
    reporting the build toolchain instead of the requested version.
    """
    plain = reported_version(run)
    pinned = reported_version(run, PIN_ENV)
    assert pinned != plain
    assert pinned.endswith("(go1.999.0)")

    result = run([], env=PIN_ENV, stdin=b"//gofumpt:diagnose\npackage p\n")
    assert result.returncode == 0, result.stderr
    assert ("//gofumpt:diagnose version: %s flags: -lang=go1 -modpath="
            "\npackage p\n" % pinned).encode() in result.stdout
    assert plain.encode() not in result.stdout
