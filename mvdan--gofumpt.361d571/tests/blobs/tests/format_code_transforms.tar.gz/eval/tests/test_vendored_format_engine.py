"""Behaviors that flow through the vendored go/format engine.

The binary never prints whole files via internal/govendor/go/format; it
reaches that package only when gofumpt measures or compares sub-file nodes
(group_params' type printing with an empty FileSet, one-line-ness probes of
specs and types, and long-line length estimates).  These tests pin the
observable decisions those vendored-format calls make.
"""

IFACE_MERGE_SRC = """\
package p

func f(a interface{ M() }, b interface {
\tM()
}) {}
"""

# Merging happens because both types PRINT identically once positions are
# dropped; the printer then re-expands the surviving multi-line type, which
# leaves a trailing comma and a blank line before the closing paren.
IFACE_MERGE_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a, b interface{ M() },\n"
    b"\n"
    b") {\n"
    b"}\n"
)

STRUCT_MERGE_SRC = """\
package p

func f(a struct{ x int }, b struct {
\tx int
}) {}
"""

STRUCT_MERGE_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a, b struct{ x int },\n"
    b"\n"
    b") {\n"
    b"}\n"
)

IFACE_METHODS_MERGE_SRC = """\
package p

type I interface{ M1(); M2() }
"""

IFACE_METHODS_MERGE_OUT = (
    b"package p\n"
    b"\n"
    b"type I interface {\n"
    b"\tM1()\n"
    b"}\n"
)

IFACE_METHODS_DIFFER_SRC = """\
package p

type I interface{ M1(a int); M2(b int) }
"""

IFACE_METHODS_DIFFER_OUT = (
    b"package p\n"
    b"\n"
    b"type I interface {\n"
    b"\tM1(a int)\n"
    b"\tM2(b int)\n"
    b"}\n"
)

DIFFERENT_PRINT_SRC = """\
package p

func g(a (int), b int) {}

func h(a chan int, b chan<- int) {}

func i(a []int, b [2]int, c []int) {}
"""

# Redundant parens are dropped before the merge, so (int) joins b int;
# direction and size variants print differently and never merge.
DIFFERENT_PRINT_OUT = (
    b"package p\n"
    b"\n"
    b"func g(a, b int) {}\n"
    b"\n"
    b"func h(a chan int, b chan<- int) {}\n"
    b"\n"
    b"func i(a []int, b [2]int, c []int) {}\n"
)

COMMENT_STRUCT_SRC = """\
package p

type T struct{}
type U struct{ /* c */ }
"""

COMMENT_STRUCT_OUT = (
    b"package p\n"
    b"\n"
    b"type (\n"
    b"\tT struct{}\n"
    b"\tU struct { /* c */\n"
    b"\t}\n"
    b")\n"
)

LONE_VAR_JOINED_SRC = """\
package p

var
x = 1
"""

LONE_VAR_JOINED_OUT = b"package p\n\nvar x = 1\n"

LONE_VAR_COMMENT_SRC = """\
package p

var // c
x = 1
"""

LONE_VAR_INLINE_COMMENT_SRC = """\
package p

var
x /* c */ = 1
"""

LONE_VAR_INLINE_COMMENT_OUT = b"package p\n\nvar x = /* c */ 1\n"

PAREN_COMMENT_SRC = """\
package p

func f() {
\tx := 1
\t_ = (x)
\t_ = ( /* c */ x)
\t_ = (x + 1)
\t_ = ((x))
}
"""

PAREN_COMMENT_OUT = (
    b"package p\n"
    b"\n"
    b"func f() {\n"
    b"\tx := 1\n"
    b"\t_ = x\n"
    b"\t_ = ( /* c */ x)\n"
    b"\t_ = (x + 1)\n"
    b"\t_ = x\n"
    b"}\n"
)

SPLIT_COMPOSITE_SRC = (
    b'package p\n'
    b'\n'
    b'var s = []string{"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '
    b'strings.Repeat("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", 1)}\n'
)

SPLIT_COMPOSITE_OUT = (
    b"package p\n"
    b"\n"
    b"var s = []string{\n"
    b'\t"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",\n'
    b'\tstrings.Repeat("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", 1),\n'
    b"}\n"
)


def test_group_params_merges_types_differing_only_in_newlines(run):
    """Types equal only after dropping positions still merge under -extra.

    CATCHES: an implementation that compares parameter types with their
    real positions, so ``interface{ M() }`` and a multi-line ``interface
    { M() }`` never merge the way the empty-FileSet print does.
    """
    result = run(["-extra=true"], stdin=IFACE_MERGE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == IFACE_MERGE_OUT


def test_group_params_struct_types_merge_across_newlines(run):
    """The newline-only type equality also merges struct-typed params.

    CATCHES: an implementation special-casing interface types in the merge
    comparison instead of printing every field type through the engine.
    """
    result = run(["-extra=true"], stdin=STRUCT_MERGE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == STRUCT_MERGE_OUT


def test_group_params_same_line_interface_methods_collapse(run):
    """Same-line interface methods with equal signatures merge, dropping
    every method after the first.

    CATCHES: an implementation that guards interface method lists from the
    param merge, keeping M2() alive where the reference collapses
    ``M1(); M2()`` down to a single M1() signature.
    """
    result = run(["-extra=true"], stdin=IFACE_METHODS_MERGE_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == IFACE_METHODS_MERGE_OUT


def test_group_params_interface_methods_with_differring_sigs_kept(run):
    """Interface methods whose signatures print differently are kept.

    CATCHES: an implementation that merges any two one-line methods
    regardless of their parameter lists.
    """
    result = run(["-extra=true"], stdin=IFACE_METHODS_DIFFER_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == IFACE_METHODS_DIFFER_OUT


def test_group_params_types_that_print_differently_never_merge(run):
    """Direction and size variants stay separate; (int) merges after
    paren removal.

    CATCHES: an implementation that compares type ASTs loosely (e.g. by
    name only), merging ``chan int`` with ``chan<- int`` or ``[]int`` with
    ``[2]int``.
    """
    result = run(["-extra=true"], stdin=DIFFERENT_PRINT_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == DIFFERENT_PRINT_OUT


def test_comment_inside_one_line_struct_forces_multiline(run):
    """A block comment inside a one-line struct keeps it split over lines.

    CATCHES: an implementation that collapses ``struct{ /* c */ }`` onto a
    single line even though the engine's one-line probe says the printer
    splits it.
    """
    result = run([], stdin=COMMENT_STRUCT_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == COMMENT_STRUCT_OUT


def test_lone_var_on_multiple_lines_joins_unless_comment_breaks(run):
    """A lone var split across lines joins; a keyword comment blocks it.

    CATCHES: an implementation that joins ``var // c\\nx = 1`` into one
    line, or that fails to join the comment-free ``var\\nx = 1`` at all.
    """
    joined = run([], stdin=LONE_VAR_JOINED_SRC.encode())
    assert joined.returncode == 0, joined.stderr
    assert joined.stdout == LONE_VAR_JOINED_OUT

    blocked = run([], stdin=LONE_VAR_COMMENT_SRC.encode())
    assert blocked.returncode == 0, blocked.stderr
    assert blocked.stdout == LONE_VAR_COMMENT_SRC.encode()


def test_inline_comment_between_lone_var_name_and_value_rides_along(run):
    """A comment between the spec's name and value survives the join.

    CATCHES: an implementation that drops the inline ``/* c */`` when it
    collapses the multi-line lone var onto a single line.
    """
    result = run([], stdin=LONE_VAR_INLINE_COMMENT_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == LONE_VAR_INLINE_COMMENT_OUT


def test_parens_containing_a_comment_are_kept(run):
    """Parens around a plain operand drop; a comment inside blocks it.

    CATCHES: an implementation that strips parentheses without checking
    for comments inside them, which would relocate or lose the comment.
    """
    result = run([], stdin=PAREN_COMMENT_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == PAREN_COMMENT_OUT


def test_split_long_lines_prefers_break_before_first_element(run):
    """With GOFUMPT_SPLIT_LONG_LINES=on a long literal breaks per element.

    CATCHES: an implementation that splits the over-long line somewhere
    other than right before the first composite literal element, or that
    keeps the line whole.
    """
    off = run([], stdin=SPLIT_COMPOSITE_SRC)
    assert off.returncode == 0, off.stderr
    assert off.stdout == SPLIT_COMPOSITE_SRC

    on = run([], env={"GOFUMPT_SPLIT_LONG_LINES": "on"}, stdin=SPLIT_COMPOSITE_SRC)
    assert on.returncode == 0, on.stderr
    assert on.stdout == SPLIT_COMPOSITE_OUT
