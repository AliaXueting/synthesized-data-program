"""Cross-rule interactions: transforms combining on one input, config, and
idempotency of the whole pipeline.
"""

COMBINED_SRC = """\
package p

import (
\t"example.com/x"
\t"fmt"
)

//doc comment
func f(s []int) {
\t//c
\t_ = s[0:len(s)]
\t_ = 0755
\tfor _, _ = range s {
\t}
}
"""

COMBINED_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b"\n"
    b'\t"example.com/x"\n'
    b")\n"
    b"\n"
    b"// doc comment\n"
    b"func f(s []int) {\n"
    b"\t// c\n"
    b"\t_ = s[0:]\n"
    b"\t_ = 0o755\n"
    b"\tfor range s {\n"
    b"\t}\n"
    b"}\n"
)

EXTRA_SIMPLIFY_SRC = """\
package p

func f(a int, b int) (x []int) {
\ty := [][]int{[]int{1}, []int{2}}
\t_ = y
\treturn
}
"""

EXTRA_SIMPLIFY_OUT = (
    b"package p\n"
    b"\n"
    b"func f(a, b int) (x []int) {\n"
    b"\ty := [][]int{{1}, {2}}\n"
    b"\t_ = y\n"
    b"\treturn x\n"
    b"}\n"
)

IDEMPOTENT_SRC = """\
package p

import (\n\t"example.com/x"
\t"fmt"
)

func f(s []int) {
\t_ = s[0:len(s)]
\t_ = 0755
}
"""

# Recorded from the reference with -lang go1.21 on IDEMPOTENT_SRC: every
# transform (import regrouping, octal rewrite, slice simplification) fires
# on the first pass, and none of them may fire again on the second.
IDEMPOTENT_OUT = (
    b"package p\n"
    b"\n"
    b"import (\n"
    b'\t"fmt"\n'
    b"\n"
    b'\t"example.com/x"\n'
    b")\n"
    b"\n"
    b"func f(s []int) {\n"
    b"\t_ = s[0:]\n"
    b"\t_ = 0o755\n"
    b"}\n"
)

SPLIT_LINE_SRC = """\
package p

var s = "{a}" + "{b}"
"""


def test_all_transforms_apply_together(run):
    """Simplify, octal rewrite, import grouping and comment spacing compose.

    CATCHES: an implementation where one rule's rewrite hides another's
    input, e.g. the range simplification running after comment collection
    and losing the "//c" comment.
    """
    result = run(["-lang", "go1.21"], stdin=COMBINED_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == COMBINED_OUT
    assert result.stderr == b""


def test_extra_rules_compose_with_simplification(run):
    """-extra=true and the always-on simplification both apply.

    CATCHES: an implementation that runs either the extra rules or the
    simplifier but not both on the same file.
    """
    result = run(["-extra=true"], stdin=EXTRA_SIMPLIFY_SRC.encode())
    assert result.returncode == 0, result.stderr
    assert result.stdout == EXTRA_SIMPLIFY_OUT


def test_full_pipeline_is_idempotent(run):
    """Formatting already-gofumpted output is a byte-for-byte no-op.

    CATCHES: a non-idempotent rewrite chain, e.g. an import regrouping or
    comment spacing that keeps mutating on every further pass; pinning the
    recorded first-pass bytes also catches a pipeline that outputs nothing.
    """
    once = run(["-lang", "go1.21"], stdin=IDEMPOTENT_SRC.encode())
    assert once.returncode == 0, once.stderr
    assert once.stdout == IDEMPOTENT_OUT
    twice = run(["-lang", "go1.21"], stdin=IDEMPOTENT_OUT)
    assert twice.returncode == 0, twice.stderr
    assert twice.stdout == IDEMPOTENT_OUT


def test_split_long_lines_env_gate(run):
    """GOFUMPT_SPLIT_LONG_LINES=on splits over-long binary-expression lines.

    CATCHES: an implementation that splits long lines without the env gate,
    or that ignores the variable when it is set to "on".
    """
    src = SPLIT_LINE_SRC.format(a="a" * 50, b="b" * 50).encode()
    off = run([], stdin=src)
    assert off.returncode == 0, off.stderr
    assert off.stdout == src

    on = run([], env={"GOFUMPT_SPLIT_LONG_LINES": "on"}, stdin=src)
    assert on.returncode == 0, on.stderr
    assert on.stdout == (
        b'package p\n'
        b'\n'
        b'var s = "' + b"a" * 50 + b'" +\n'
        b'\t"' + b"b" * 50 + b'"\n'
    )


def test_go_mod_defaults_reported_by_diagnose(run, work):
    """A go.mod in the directory supplies -lang and -modpath to diagnose.

    CATCHES: an implementation that does not resolve the effective language
    version and module path from the go.mod governing the file.
    """
    (work / "go.mod").write_text("module example.com/foo\n\ngo 1.16\n")
    version = run(["--version"], env={"GO_VERSION_TEST": "go1.999.0"})
    assert version.returncode == 0, version.stderr
    reported = version.stdout.decode().rstrip("\n")
    result = run(
        [],
        env={"GO_VERSION_TEST": "go1.999.0"},
        stdin=b"//gofumpt:diagnose\npackage p\n",
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout == (
        "//gofumpt:diagnose version: %s"
        " flags: -lang=go1.16 -modpath=example.com/foo\npackage p\n" % reported
    ).encode()
