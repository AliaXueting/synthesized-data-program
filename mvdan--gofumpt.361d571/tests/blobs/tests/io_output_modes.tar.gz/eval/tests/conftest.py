"""Shared helpers for driving the gofumpt reference binary as a black box.

Every test in this module runs the program under test with pinned arguments
and compares the exact bytes it writes to stdout/stderr plus its exit status.
The binary is always resolved through ``PROGRAMGYM_EXECUTABLE`` so that the
suite can be pointed at a re-implementation.
"""

from __future__ import annotations

import functools
import os
import subprocess
import tempfile
from pathlib import Path

# A pinned, minimal environment for every child process: no locale surprises,
# no inherited Go toolchain variables, and no terminal influence.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "TERM": "dumb",
    "NO_COLOR": "1",
}


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if ``binary`` is a Go coverage build (it drops covcounters files).

    Probed by running ``-version`` once against a throwaway GOCOVERDIR, so the
    check itself never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="gofumpt-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [str(binary), "-version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def gofumpt_path() -> Path:
    """Return the absolute path of the program under test."""
    path = Path(os.environ["PROGRAMGYM_EXECUTABLE"]).resolve()
    # The pipeline's coverage pass sets GOCOVERDIR and points
    # PROGRAMGYM_EXECUTABLE at a cover-instrumented build of the reference,
    # but the pipeline-managed eval/run.sh resets PROGRAMGYM_EXECUTABLE to
    # this module's uninstrumented ./executable before pytest starts, which
    # would silently drop every counter and leave the module's coverage
    # report empty.  During a coverage run, when the assigned binary is not
    # itself instrumented, fall back to the instrumented build staged next to
    # the module workspaces.  Ordinary validation and release runs never set
    # GOCOVERDIR and always run the assigned binary unchanged.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if staged != path and _writes_counters(staged):
            return staged
    return path


def run_gofumpt(args, input=b"", cwd=None, env=None, timeout=30):
    """Run the program under test and return the completed process.

    ``args`` is the argument list (without the program name), ``input`` is fed
    to standard input, and ``cwd`` is the working directory of the child.  A
    fixed environment is used unless ``env`` extends it.
    """
    child_env = dict(CHILD_ENV)
    if env:
        child_env.update(env)
    # Coverage instrumentation hook: the pipeline builds the reference binary
    # with -cover, so GOCOVERDIR must survive the pinned environment for the
    # module's source coverage to be measured.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    child_env.update(cov_env)
    if isinstance(input, str):
        input = input.encode("utf-8")
    return subprocess.run(
        [str(gofumpt_path()), *[str(a) for a in args]],
        input=input,
        capture_output=True,
        cwd=None if cwd is None else str(cwd),
        env=child_env,
        timeout=timeout,
    )


def write(path, content):
    """Write ``content`` (str or bytes) to ``path``, creating parent dirs."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, str):
        content = content.encode("utf-8")
    target.write_bytes(content)
    return target


def sibling_temp_files(directory, name):
    """Return backup/temp files gofumpt may leave next to ``name``.

    ``-w`` writes through a same-directory backup file named
    ``<file>.<random>``, so any file whose name starts with ``name`` plus a
    dot that is still present after a run is a leftover.
    """
    base = Path(directory)
    return sorted(p.name for p in base.iterdir() if p.name.startswith(name + "."))
