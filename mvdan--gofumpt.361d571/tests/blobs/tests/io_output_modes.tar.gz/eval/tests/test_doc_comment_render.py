"""Doc-comment rendering: the vendored go/doc/comment engine.

Doc comments above declarations are not printed verbatim: the rendering
engine re-lays them out with the vendored go/doc/comment formatter -
paragraphs keep their line breaks but lists, code blocks, headings and
directive lines get canonical placement - and a doc comment the printer
itself would skip (indented, or not ending right before the next token)
is formatted by the exported wrapper instead.  These tests pin the
resulting bytes for each shape.
"""

from conftest import run_gofumpt, write


def fmt_file(tmp_path, src):
    """Write src.go, run gofumpt on it and return the completed process."""
    write(tmp_path / "src.go", src)
    return run_gofumpt(["src.go"], cwd=tmp_path)


def test_indented_doc_comment_moves_to_column_one(tmp_path):
    """An indented doc comment is re-rendered at column one."""
    # CATCHES: an indented doc comment is one go/printer would skip, so it
    # is routed through the exported formatter wrapper and comes back
    # unindented - losing the stray tab entirely.
    src = "package p\n\n\t// indented doc comment\nfunc f() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\n// indented doc comment\nfunc f() {}\n"


def test_plain_paragraph_doc_comment_is_untouched(tmp_path):
    """A plain column-one paragraph doc comment prints unchanged."""
    # CATCHES: when the comment is at column one and ends right before the
    # declaration the printer formats it itself and nothing moves - the
    # two source lines are byte-identical in the output.
    src = "package p\n\n// a wrapped sentence\n// continues here.\nfunc f() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


def test_long_paragraph_line_is_not_rewrapped(tmp_path):
    """Doc paragraph text is never re-wrapped to a width."""
    # CATCHES: the doc engine preserves paragraph line breaks, so an
    # over-long line stays one long line instead of being refilled to some
    # column limit.
    long_line = (
        "// This paragraph is deliberately made very long so that any doc "
        "comment re-wrapping behavior would show up in the printed output "
        "line breaks."
    )
    src = f"package p\n\n{long_line}\nfunc a() {{}}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == f"package p\n\n{long_line}\nfunc a() {{}}\n".encode()


def test_list_items_are_separated_by_blank_comment_lines(tmp_path):
    """Consecutive list items each get a blank comment line between."""
    # CATCHES: the doc engine canonicalizes list spacing - even items that
    # sat on adjacent lines gain a "//" separator line, while the intro
    # sentence stays attached to the first item.
    src = "package p\n\n// A list:\n//   - one\n//   - two\n//\n//   - three\nfunc b() {}\n"
    expected = (
        "package p\n\n// A list:\n//\n//   - one\n//\n//   - two\n//\n//   - three\nfunc b() {}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected.encode()


def test_list_directly_after_intro_stays_attached(tmp_path):
    """A single list item directly after the intro keeps its position."""
    # CATCHES: the blank-line insertion happens between list items, not
    # between the intro paragraph and the first item, so this shape is
    # already canonical and prints unchanged.
    src = "package p\n\n// intro:\n//   - item\nfunc b() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


def test_heading_followed_by_text_stays_attached(tmp_path):
    """A heading line directly followed by text gains no blank line."""
    # CATCHES: unlike list items, a heading does not force a separator
    # after it, so the input shape is canonical and passes through.
    src = "package p\n\n// # A Heading\n// text directly after\nfunc a() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


def test_directive_moves_after_doc_text(tmp_path):
    """A directive line before doc text is reordered to the end."""
    # CATCHES: directive lines such as //go:generate are accumulated
    # separately from the doc text and re-emitted after it, gaining a
    # blank comment separator - the text and the directive swap places.
    src = "package p\n\n//go:generate foo\n// Some doc text after a directive.\nfunc d() {}\n"
    expected = (
        "package p\n\n// Some doc text after a directive.\n//\n//go:generate foo\nfunc d() {}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected.encode()


def test_text_before_directive_gains_separator(tmp_path):
    """Doc text followed by a directive only gains the blank line."""
    # CATCHES: with the text already first the reordering is a no-op except
    # for the inserted "//" separator, confirming the canonical form the
    # previous test's swap produces.
    src = "package p\n\n// text before directive\n//go:generate foo\nfunc d() {}\n"
    expected = "package p\n\n// text before directive\n//\n//go:generate foo\nfunc d() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected.encode()


def test_directive_only_doc_comment_is_untouched(tmp_path):
    """A doc comment that is only a directive stays as it is."""
    # CATCHES: with no doc text to order against, the directive remains
    # the whole comment with no separator or movement.
    src = "package p\n\n//go:generate just this\nfunc c() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


def test_code_block_lines_are_tab_indented_and_separated(tmp_path):
    """Tab-indented doc lines become a code block set off by a blank."""
    # CATCHES: a tab-indented run inside a doc comment is a code block: it
    # keeps its tab but must be separated from following plain text by a
    # blank comment line that was not in the input.
    src = "package p\n\n//\tcode line one\n//\tcode line two\n// regular text\nfunc e() {}\n"
    expected = (
        "package p\n\n//\tcode line one\n//\tcode line two\n//\n// regular text\nfunc e() {}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected.encode()


def test_repeated_blank_comment_lines_collapse(tmp_path):
    """Multiple blank comment lines between text collapse to one."""
    # CATCHES: paragraph spacing inside a doc comment is canonicalized to a
    # single blank line, so runs of two or more "//" separators shrink.
    src = "package p\n\n// text\n//\n//\n//\n// more text\nfunc f() {}\n"
    expected = "package p\n\n// text\n//\n// more text\nfunc f() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected.encode()


def test_trailing_blank_comment_line_is_dropped(tmp_path):
    """A blank comment line at the end of a doc comment disappears."""
    # CATCHES: trailing paragraph separators are not part of the canonical
    # form, so a doc comment ending in "//" loses that line entirely.
    src = "package p\n\n// trailing blank\n//\nfunc e() {}\n"
    expected = "package p\n\n// trailing blank\nfunc e() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected.encode()


def test_block_doc_comment_is_relaid_out(tmp_path):
    """A /* */ doc comment is re-printed in the canonical block shape."""
    # CATCHES: the doc engine rewrites block comments that hold doc text:
    # the opener goes on its own line, the paragraph follows, and the
    # indented continuation becomes a blank-separated tab-indented code
    # block before the closer.
    src = "package p\n\n/* block doc comment\n   with two lines */\nfunc g() {}\n"
    expected = "package p\n\n/*\nblock doc comment\n\n\twith two lines\n*/\nfunc g() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected.encode()
