"""The -cpuprofile debugging flag's effect on output and exit status.

``-cpuprofile`` asks gofumpt to write a CPU profile to a file while it
formats normally: the flag is processed before any input, so a profile path
that cannot be created stops the run before anything is formatted (an error
on stderr and exit 2), while a creatable path leaves stdout, stderr and the
exit status exactly as an unflagged run and merely drops a non-empty profile
file next to the output.
"""

from conftest import write, run_gofumpt


def test_cpuprofile_writes_profile_and_formats_normally(tmp_path):
    """A creatable profile path leaves the run's output unchanged."""
    # CATCHES: the profile is started and stopped around the normal
    # processing, so the file is still formatted to stdout with exit 0 and
    # empty stderr, and a non-empty profile file appears at the given path.
    write(tmp_path / "a.go", b"package p\n\nvar  x=1\n")
    res = run_gofumpt(["-cpuprofile=prof.out", "a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar x = 1\n"
    prof = tmp_path / "prof.out"
    assert prof.is_file()
    assert prof.stat().st_size > 0


def test_cpuprofile_works_with_stdin(tmp_path):
    """Profiling a stdin run still formats the fragment."""
    # CATCHES: the flag is accepted together with the no-arguments stdin
    # mode, so the fragment is formatted to stdout as usual and the profile
    # file is created even though no input file was ever opened.
    res = run_gofumpt(["-cpuprofile=prof.out"], input=b"var  x=1\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"var x = 1\n"
    prof = tmp_path / "prof.out"
    assert prof.is_file()
    assert prof.stat().st_size > 0


def test_cpuprofile_bad_path_is_an_error(tmp_path):
    """A profile path that cannot be created aborts before formatting."""
    # CATCHES: creating the profile happens before any input is read, so a
    # missing parent directory reports the wrapped os error on stderr with
    # exit 2 and produces no stdout and no profile file.
    write(tmp_path / "a.go", b"package p\n\nvar  x=1\n")
    res = run_gofumpt(["-cpuprofile=nodir/prof.out", "a.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"creating cpu profile: open nodir/prof.out: no such file or directory\n"
    )
    assert not (tmp_path / "nodir").exists()
