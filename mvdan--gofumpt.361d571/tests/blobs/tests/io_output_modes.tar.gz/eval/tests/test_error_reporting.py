"""Error reporting: format, limits and the inputs that produce errors.

These pin the `<file>:<line>:<col>: <msg>` shape gofumpt borrows from
scanner.PrintError, the default cap of eleven errors with same-line
de-duplication, -e lifting both, and the I/O errors (missing path, dangling
symlink, file changing size while being read).
"""

import os
import re
import subprocess
import sys
import time

from conftest import run_gofumpt, write


def many_errors(n):
    """A file whose first `n` lines after the package clause are all wrong."""
    src = b"package p\n"
    for i in range(n):
        src += b"var %d = = %d\n" % (i, i)
    return src


def test_parse_error_format(tmp_path):
    """A parse error is one `<file>:<line>:<col>: <msg>` line on stderr."""
    # CATCHES: the position and message come straight from the parser in the
    # scanner.PrintError shape, and stdout stays empty.
    write(tmp_path / "a.go", b"package p\nfunc {\n")
    res = run_gofumpt(["a.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"a.go:2:6: expected 'IDENT', found '{'\n"


def test_default_mode_caps_at_eleven_errors(tmp_path):
    """By default parsing stops after eleven reported errors."""
    # CATCHES: the parser bails out once it has recorded eleven errors, so a
    # file with fifteen broken lines yields exactly eleven stderr lines.
    write(tmp_path / "many.go", many_errors(15))
    res = run_gofumpt(["many.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    lines = res.stderr.splitlines()
    assert len(lines) == 11
    assert lines[0] == b"many.go:2:5: expected 'IDENT', found 0"
    assert lines[10] == b"many.go:12:1: expected ';', found 'var'"


def test_eleven_errors_are_all_reported(tmp_path):
    """Exactly eleven errors are not truncated - the cap is on adding a 12th."""
    # CATCHES: the cutoff triggers when a twelfth error would be recorded, so
    # a file with exactly eleven bad lines reports every one of them.
    write(tmp_path / "eleven.go", many_errors(11))
    res = run_gofumpt(["eleven.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert len(res.stderr.splitlines()) == 11


def test_dash_e_reports_all_errors(tmp_path):
    """-e keeps parsing past the cap and reports every error."""
    # CATCHES: with -e neither the eleven-error bail-out nor the same-line
    # de-duplication applies, so far more lines are printed.
    write(tmp_path / "many.go", many_errors(13))
    res = run_gofumpt(["-e", "many.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    lines = res.stderr.splitlines()
    assert len(lines) == 39
    assert lines[0] == b"many.go:2:5: expected 'IDENT', found 0"
    assert lines[-1] == b"many.go:14:15: expected ';', found 'EOF'"


def test_repeated_errors_on_one_line_are_dropped(tmp_path):
    """Without -e, later errors on the same line as the previous one vanish."""
    # CATCHES: only the first error of each line is kept by default, so a line
    # with several problems yields a single stderr line.
    write(tmp_path / "same.go", b"package p\nvar x = = = = 1\n")
    res = run_gofumpt(["same.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"same.go:2:9: expected operand, found '='\n"


def test_dash_e_reports_same_line_errors(tmp_path):
    """With -e the remaining errors on that line are reported too."""
    # CATCHES: -e must lift the same-line de-duplication, not just the cap.
    write(tmp_path / "same.go", b"package p\nvar x = = = = 1\n")
    res = run_gofumpt(["-e", "same.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"same.go:2:9: expected operand, found '='\n"
        b"same.go:2:17: expected ';', found 'EOF'\n"
    )


def test_errors_from_several_files_in_argument_order(tmp_path):
    """Each broken file contributes its own error lines, in argument order."""
    # CATCHES: the reporter serializes stderr too, so two broken files keep
    # the order they were named in.
    write(tmp_path / "a.go", b"package p\nfunc {\n")
    write(tmp_path / "b.go", b"package p\nvar = 1\n")
    res = run_gofumpt(["a.go", "b.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"a.go:2:6: expected 'IDENT', found '{'\n"
        b"b.go:2:5: expected 'IDENT', found '='\n"
    )


def test_missing_file_is_a_lstat_error(tmp_path):
    """A named path that does not exist fails the walk with a lstat message."""
    # CATCHES: the error wording is the walk's `lstat <path>: ...`, not the
    # later `open <path>: ...`, because the file is never even stat'ed.
    res = run_gofumpt(["gone.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"lstat gone.go: no such file or directory\n"


def test_missing_directory_is_a_lstat_error(tmp_path):
    """A missing directory argument reports the same way as a missing file."""
    # CATCHES: directory arguments are walked too, so a missing one is a stat
    # failure rather than an empty walk.
    res = run_gofumpt(["nodir"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"lstat nodir: no such file or directory\n"


def test_dangling_symlink_is_an_open_error(tmp_path):
    """A symlink whose target is gone fails when the file is opened."""
    # CATCHES: the link itself lstat's fine, so the failure happens later with
    # the `open` wording - a different message than a missing path.
    (tmp_path / "dangling.go").symlink_to(tmp_path / "missing.go")
    res = run_gofumpt(["dangling.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"open dangling.go: no such file or directory\n"


def test_empty_file_is_a_parse_error(tmp_path):
    """A zero-byte .go file has no package clause and is an error."""
    # CATCHES: an empty file is not silently skipped - it is reported at 1:1
    # with the EOF token and exit status 2.
    write(tmp_path / "empty.go", b"")
    res = run_gofumpt(["empty.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"empty.go:1:1: expected 'package', found 'EOF'\n"


def test_comment_only_file_is_a_parse_error(tmp_path):
    """A file with only a comment still needs a package clause."""
    # CATCHES: the column points just past the comment, showing the file was
    # scanned to EOF before the missing package was reported.
    write(tmp_path / "cmt.go", b"// hi\n")
    res = run_gofumpt(["cmt.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"cmt.go:1:7: expected 'package', found 'EOF'\n"


def test_error_in_a_directory_walk(tmp_path):
    """A broken file found while walking is reported like an explicit one."""
    # CATCHES: the walked path (including the directory prefix) is used in the
    # error message, matching the -l listing form.
    write(tmp_path / "tree" / "a.go", b"package p\nfunc {\n")
    res = run_gofumpt(["tree"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"tree/a.go:2:6: expected 'IDENT', found '{'\n"


# The size-change error needs the file to grow between the walk's stat and the
# read, so a helper process appends to it continuously while gofumpt runs.
APPENDER = (
    "import sys,time\n"
    "path,deadline=sys.argv[1],time.time()+float(sys.argv[2])\n"
    "f=open(path,'ab')\n"
    "while time.time()<deadline:\n"
    "    f.write(b'x'); f.flush(); time.sleep(0.0001)\n"
    "f.close()\n"
)

SIZE_CHANGED = re.compile(
    rb"^error: size of big\.go changed during reading "
    rb"\(from (\d+) to >=(\d+) bytes\)\n$"
)


def test_size_change_during_read_is_an_error(tmp_path):
    """A file that grows while it is read is refused, not half-formatted."""
    # CATCHES: gofumpt stats the file, then reads stat-size+1 bytes so that a
    # concurrent write is detected and reported instead of corrupting output;
    # the message reports the stale size and at least one extra byte.
    big = write(tmp_path / "big.go", b"\n" * (20 * 1024 * 1024))
    appender = subprocess.Popen(
        [sys.executable, "-c", APPENDER, str(big), "10"]
    )
    try:
        # Give the appender a head start so the file is already growing when
        # gofumpt walks the directory.
        time.sleep(0.05)
        res = run_gofumpt(["-l", "big.go"], cwd=tmp_path, timeout=25)
    finally:
        appender.terminate()
        appender.wait()
    assert res.returncode == 2
    assert res.stdout == b""
    match = SIZE_CHANGED.match(res.stderr)
    assert match is not None, res.stderr
    before, after = int(match.group(1)), int(match.group(2))
    assert after == before + 1
    assert before >= 20 * 1024 * 1024


# The shrinking variant needs the file to get smaller between the walk's
# stat and the end of the read, so a helper process truncates a large sparse
# file shortly after gofumpt starts: the stat has already seen the full size
# while the read is still in progress, and the truncated file ends the read
# early with fewer bytes than were statted.
SHRINKER = (
    "import os,sys,time\n"
    "path=sys.argv[1]\n"
    "time.sleep(0.2)\n"
    "fd=os.open(path, os.O_WRONLY)\n"
    "os.ftruncate(fd, 256*1024*1024)\n"
    "os.close(fd)\n"
)

SIZE_SHRANK = re.compile(
    rb"^error: size of big\.go changed during reading "
    rb"\(from (\d+) to (\d+) bytes\)\n$"
)

# 1 GiB keeps the read busy for well over the helper's delay; the file is
# sparse, so nothing is ever written to disk.
SHRINK_SIZE = 1024 * 1024 * 1024


def test_file_shrink_during_read_is_an_error(tmp_path):
    """A file that shrinks while it is read is refused, not half-formatted."""
    # CATCHES: reading stat-size+1 bytes detects the truncated file and the
    # message reports the statted size and the shorter byte count actually
    # read (the "from N to M bytes" form, without the >= of the grown form).
    big = tmp_path / "big.go"
    fd = os.open(big, os.O_CREAT | os.O_WRONLY, 0o644)
    os.ftruncate(fd, SHRINK_SIZE)
    os.close(fd)
    shrinker = subprocess.Popen(
        [sys.executable, "-c", SHRINKER, str(big)]
    )
    try:
        res = run_gofumpt(["-l", "big.go"], cwd=tmp_path, timeout=25)
    finally:
        shrinker.wait()
    assert res.returncode == 2
    assert res.stdout == b""
    match = SIZE_SHRANK.match(res.stderr)
    assert match is not None, res.stderr
    before, after = int(match.group(1)), int(match.group(2))
    assert before == SHRINK_SIZE
    assert after < before
