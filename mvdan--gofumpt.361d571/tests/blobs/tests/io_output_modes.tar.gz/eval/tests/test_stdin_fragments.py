"""Standard input: whole files and the Go fragment wrapping.

With no path arguments gofumpt reads stdin, always applies its own rules, and
accepts fragments - a declaration list, a statement list or a bare expression
- because internal.go wraps them in `package p;` / `func _() { ... }` before
parsing and strips the wrapper plus one level of indentation afterwards.
"""

import pytest

from conftest import run_gofumpt


def test_stdin_declaration_list(tmp_path):
    """A declaration list is formatted as itself, without a package clause."""
    # CATCHES: the wrapper `package p;` is stripped again, so the output is
    # just the formatted declarations with no added context.
    res = run_gofumpt([], input=b"var x = 1\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"var x = 1\n"
    assert res.stderr == b""


def test_stdin_unformatted_declaration_list(tmp_path):
    """A messy declaration list is cleaned up like a real file would be."""
    # CATCHES: stdin gets the full gofumpt treatment, not just gofmt's
    # printer, so spacing inside the fragment is normalized too.
    res = run_gofumpt([], input=b"var  x  =  1\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"var x = 1\n"
    assert res.stderr == b""


def test_stdin_statement_list(tmp_path):
    """A statement list is wrapped in a function, formatted, and unwrapped."""
    # CATCHES: `x := 1` is not a valid file, yet it comes back as the single
    # formatted statement with no `func _()` wrapper and no leading tab.
    res = run_gofumpt([], input=b"x := 1\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"x := 1\n"
    assert res.stderr == b""


def test_stdin_multiple_statements(tmp_path):
    """Several statements keep their relative order and line breaks."""
    # CATCHES: the wrapper removal must not merge or reorder statements.
    res = run_gofumpt([], input=b"x := 1\ny  =  2\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"x := 1\ny = 2\n"
    assert res.stderr == b""


def test_stdin_bare_expression(tmp_path):
    """A bare expression is formatted as an expression statement."""
    # CATCHES: the statement-list fallback also covers expressions, and the
    # printer inserts the spaces gofmt would put around the operator.
    res = run_gofumpt([], input=b"1+2\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"1 + 2\n"
    assert res.stderr == b""


def test_stdin_function_declaration(tmp_path):
    """A func declaration is a declaration fragment, not a statement."""
    # CATCHES: the declaration-list path is tried before the statement path,
    # so a complete function comes back unwrapped.
    res = run_gofumpt([], input=b"func  f() {}\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"func f() {}\n"
    assert res.stderr == b""


def test_stdin_multiline_type_declaration(tmp_path):
    """A multi-line struct fragment is re-indented inside the fragment."""
    # CATCHES: the un-wrapper strips exactly one level, so struct fields end
    # up indented with a tab and the columns aligned with spaces.
    res = run_gofumpt([], input=b"type T struct {\nA int\nBB string\n}\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"type T struct {\n\tA  int\n\tBB string\n}\n"
    assert res.stderr == b""


def test_stdin_block_statement(tmp_path):
    """A control-flow statement keeps its nested indentation."""
    # CATCHES: the statement wrapper adds one indent level that must be
    # subtracted again, leaving the body indented exactly one tab.
    res = run_gofumpt([], input=b"if x {\ny()\n}\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"if x {\n\ty()\n}\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "fragment,expected",
    [
        pytest.param(b"\tvar x = 1\n", b"\tvar x = 1\n", id="one-tab"),
        pytest.param(b"\t\t\tvar x = 1\n", b"\t\t\tvar x = 1\n", id="three-tabs"),
        pytest.param(b"    var x = 1\n", b"\tvar x = 1\n", id="four-spaces"),
        pytest.param(b"\t \t var x = 1\n", b"\t\tvar x = 1\n", id="tabs-and-spaces"),
    ],
)
def test_stdin_leading_indentation(tmp_path, fragment, expected):
    """Leading indentation is measured in tabs; spaces collapse to one tab."""
    # CATCHES: the fragment path re-emits the original indentation depth as
    # tabs - four leading spaces become one tab, and stray spaces between
    # tabs are dropped rather than kept.
    res = run_gofumpt([], input=fragment, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_stdin_leading_blank_lines_are_kept(tmp_path):
    """Blank lines before the fragment are preserved verbatim."""
    # CATCHES: the formatter keeps the leading whitespace block of the source
    # instead of trimming it away.
    res = run_gofumpt([], input=b"\n\nvar x = 1\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"\n\nvar x = 1\n"
    assert res.stderr == b""


def test_stdin_trailing_whitespace_is_kept(tmp_path):
    """Trailing spaces and blank lines after the fragment are preserved."""
    # CATCHES: only the code part is reformatted; the original trailing
    # whitespace block is appended byte for byte, spaces included.
    res = run_gofumpt([], input=b"x  :=  1   \n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"x := 1   \n"
    assert res.stderr == b""


def test_stdin_blank_lines_after_fragment(tmp_path):
    """Trailing blank lines survive the wrap/unwrap round trip."""
    # CATCHES: the trailing whitespace is copied from the input, so three
    # trailing newlines stay three trailing newlines.
    res = run_gofumpt([], input=b"x := 1\n\n\n\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"x := 1\n\n\n\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "src",
    [
        pytest.param(b"\n\n", id="blank-lines"),
        pytest.param(b"   \n", id="spaces-then-newline"),
        pytest.param(b"   ", id="spaces-only"),
    ],
)
def test_stdin_whitespace_only_is_returned_unchanged(tmp_path, src):
    """Whitespace-only input has nothing to format and is echoed as-is."""
    # CATCHES: an empty adjusted result means the original bytes are the
    # answer, so even the three spaces come back untouched.
    res = run_gofumpt([], input=src, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == b""


def test_stdin_comment_only_fragment(tmp_path):
    """A lone comment is accepted as a fragment and echoed."""
    # CATCHES: on stdin a comment is not an error (unlike in a file), because
    # it parses once the package clause is prepended.
    res = run_gofumpt([], input=b"// hi\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"// hi\n"
    assert res.stderr == b""


def test_stdin_comment_above_declaration(tmp_path):
    """A leading comment stays attached to the declaration below it."""
    # CATCHES: the wrapper insertion must not push the comment into the
    # package clause or duplicate it.
    res = run_gofumpt([], input=b"// hi\nvar x = 1\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"// hi\nvar x = 1\n"
    assert res.stderr == b""


def test_stdin_gofumpt_rules_apply_to_fragments(tmp_path):
    """Fragments get gofumpt's own rules, not only the printer's."""
    # CATCHES: the leading blank line inside the block is a gofumpt rule, so
    # stdin must run the same rule set as files on disk.
    res = run_gofumpt([], input=b"if x {\n\n\ty()\n}\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"if x {\n\ty()\n}\n"
    assert res.stderr == b""


def test_stdin_error_keeps_line_numbers(tmp_path):
    """Errors in a wrapped fragment report the fragment's own line numbers."""
    # CATCHES: the wrapper is joined with `;` instead of a newline precisely
    # so that line numbers stay those of the piped source - the broken
    # statement is on line 2 of the input and is reported as line 2.
    res = run_gofumpt([], input=b"x := 1\ny := =\n", cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:2:6: expected operand, found '='\n"
        b"<standard input>:5:2: expected ';', found 'EOF'\n"
    )


def test_stdin_error_on_first_line_includes_wrapper_offset(tmp_path):
    """A first-line fragment error keeps the wrapper's column offset."""
    # CATCHES: the statement wrapper `package p; func _() {` is 22 columns
    # wide and sits on the same line, so the reported column of a first-line
    # error is shifted by that much (5 becomes 27).
    res = run_gofumpt([], input=b"x := =\n", cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"<standard input>:1:27: expected operand, found '='\n"
        b"<standard input>:4:2: expected ';', found 'EOF'\n"
    )


def test_stdin_error_names_standard_input(tmp_path):
    """Errors from stdin use the `<standard input>` file name."""
    # CATCHES: the pseudo-filename is what a user must grep for, so it has to
    # match the -l listing name exactly.
    res = run_gofumpt([], input=b"package p\nfunc {\n", cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:2:6: expected 'IDENT', found '{'\n"


def test_stdin_incomplete_statement_falls_back_to_statement_list(tmp_path):
    """An expression that is neither file nor declaration is still tried."""
    # CATCHES: parse tries whole file, then declarations, then statements, so
    # a bare `123` still formats instead of erroring out.
    res = run_gofumpt([], input=b"123\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"123\n"
    assert res.stderr == b""


def test_stdin_package_then_statement_is_an_error(tmp_path):
    """A package clause makes the whole input a file, so a statement fails."""
    # CATCHES: once a `package` line parses, the fragment fallbacks are not
    # tried and the statement is reported as a declaration error.
    res = run_gofumpt([], input=b"package p\nx := 1\n", cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"<standard input>:2:1: expected declaration, found x\n"
