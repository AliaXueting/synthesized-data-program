"""The -w mode: rewriting files in place, safely and only when needed.

These pin that -w rewrites only files whose bytes change, preserves their
permissions, truncates properly when the result shrinks, leaves no backup
files behind, and refuses to be combined with standard input.
"""

import os

import pytest

from conftest import run_gofumpt, sibling_temp_files, write

BAD = b"package p\n\nfunc  f() {\nx:=1\n}\n"
FORMATTED = b"package p\n\nfunc f() {\n\tx := 1\n}\n"
GOOD = b"package p\n\nfunc g() {\n\ty := 2\n}\n"


def test_rewrites_file_in_place(tmp_path):
    """-w replaces the file contents and prints nothing to stdout."""
    # CATCHES: -w must be silent on stdout and write the formatted bytes into
    # the original path rather than next to it.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-w", "a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "a.go").read_bytes() == FORMATTED


def test_write_leaves_formatted_file_untouched(tmp_path):
    """-w rewrites the dirty file but not the one whose bytes would not change."""
    # CATCHES: an implementation that rewrites unconditionally would clobber
    # the mtime of every clean file in a repository for no benefit.
    clean = write(tmp_path / "clean.go", GOOD)
    dirty = write(tmp_path / "dirty.go", BAD)
    old = 1000000000
    os.utime(clean, (old, old))
    res = run_gofumpt(["-w", "clean.go", "dirty.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert clean.read_bytes() == GOOD
    assert clean.stat().st_mtime == old
    assert dirty.read_bytes() == FORMATTED


def test_write_truncates_when_result_is_shorter(tmp_path):
    """-w truncates the file when the formatted output is shorter."""
    # CATCHES: the file is opened without O_TRUNC, so a missing explicit
    # truncate would leave stale bytes from the longer original behind.
    long_src = b"package p\n\n\n\nfunc  f()  {\n\n\n\n\tx  :=  111111111111111\n\n\n\n}\n\n\n\n"
    expected = b"package p\n\nfunc f() {\n\tx := 111111111111111\n}\n"
    write(tmp_path / "shrink.go", long_src)
    res = run_gofumpt(["-w", "shrink.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "shrink.go").read_bytes() == expected
    assert (tmp_path / "shrink.go").stat().st_size == len(expected)
    assert len(long_src) > len(expected)


@pytest.mark.parametrize(
    "mode",
    [
        pytest.param(0o755, id="0755"),
        pytest.param(0o600, id="0600"),
        pytest.param(0o444, id="0444"),
    ],
)
def test_write_preserves_permissions(tmp_path, mode):
    """-w keeps the file's permission bits exactly as they were."""
    # CATCHES: the rewrite goes through a backup file created with the
    # original's perms and reopens the original with them, so 0444 or 0755
    # must survive the rewrite.
    path = write(tmp_path / "perm.go", BAD)
    os.chmod(path, mode)
    res = run_gofumpt(["-w", "perm.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert path.read_bytes() == FORMATTED
    assert path.stat().st_mode & 0o777 == mode


def test_write_leaves_no_backup_files(tmp_path):
    """After a successful -w no `<file>.<random>` backup remains."""
    # CATCHES: -w writes through a same-directory temporary backup and must
    # remove it on success; leftovers would pollute version control.
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "b.go", BAD)
    write(tmp_path / "clean.go", GOOD)
    res = run_gofumpt(["-w", "a.go", "b.go", "clean.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "a.go").read_bytes() == FORMATTED
    assert (tmp_path / "b.go").read_bytes() == FORMATTED
    for name in ("a.go", "b.go", "clean.go"):
        assert sibling_temp_files(tmp_path, name) == []
    assert sorted(p.name for p in tmp_path.iterdir()) == [
        "a.go",
        "b.go",
        "clean.go",
    ]


def test_write_backup_goes_in_the_same_directory(tmp_path):
    """-w on a file in a subdirectory leaves that directory clean too."""
    # CATCHES: the backup file is created next to the target (not in the
    # current directory or /tmp), so a nested rewrite leaves no debris.
    write(tmp_path / "sub" / "a.go", BAD)
    res = run_gofumpt(["-w", "sub/a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "sub" / "a.go").read_bytes() == FORMATTED
    assert sorted(p.name for p in (tmp_path / "sub").iterdir()) == ["a.go"]
    assert sorted(p.name for p in tmp_path.iterdir()) == ["sub"]


def test_write_with_stdin_is_rejected(tmp_path):
    """-w with no path arguments fails before reading stdin."""
    # CATCHES: rewriting standard input is meaningless, so the exact error
    # line and exit status 2 must be produced without consuming the input.
    res = run_gofumpt(["-w"], input=b"package p\nvar  x=1\n", cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: cannot use -w with standard input\n"


def test_write_directory_tree(tmp_path):
    """-w over a directory rewrites the differing .go files it finds."""
    # CATCHES: the walk finds the nested unformatted files, rewrites them, and
    # leaves non-Go files and formatted files byte-identical.
    write(tmp_path / "tree" / "a.go", BAD)
    write(tmp_path / "tree" / "sub" / "b.go", BAD)
    write(tmp_path / "tree" / "clean.go", GOOD)
    write(tmp_path / "tree" / "notes.txt", BAD)
    res = run_gofumpt(["-w", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "tree" / "a.go").read_bytes() == FORMATTED
    assert (tmp_path / "tree" / "sub" / "b.go").read_bytes() == FORMATTED
    assert (tmp_path / "tree" / "clean.go").read_bytes() == GOOD
    assert (tmp_path / "tree" / "notes.txt").read_bytes() == BAD


def test_write_follows_symlink_to_target(tmp_path):
    """-w on a symlink writes through to the target and keeps the link."""
    # CATCHES: gofumpt rewrites the file *behind* the link instead of
    # replacing the link with a regular file.
    target = write(tmp_path / "real.go", BAD)
    (tmp_path / "link.go").symlink_to(target)
    res = run_gofumpt(["-w", "link.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert target.read_bytes() == FORMATTED
    assert (tmp_path / "link.go").is_symlink()


def test_write_with_list_lists_and_writes(tmp_path):
    """-l and -w combine: the differing paths are listed and rewritten."""
    # CATCHES: both flags take effect for the same file, and the exit status
    # stays 0 because -l does not treat differences as an error.
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "clean.go", GOOD)
    res = run_gofumpt(["-l", "-w", "a.go", "clean.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"a.go\n"
    assert res.stderr == b""
    assert (tmp_path / "a.go").read_bytes() == FORMATTED
    assert (tmp_path / "clean.go").read_bytes() == GOOD


def test_write_non_go_file(tmp_path):
    """-w rewrites an explicitly named non-.go file."""
    # CATCHES: explicit arguments bypass the .go suffix filter even for the
    # in-place writing path.
    write(tmp_path / "snippet.txt", BAD)
    res = run_gofumpt(["-w", "snippet.txt"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "snippet.txt").read_bytes() == FORMATTED


def test_write_with_parse_error_writes_others(tmp_path):
    """-w still rewrites the good files when another one fails to parse."""
    # CATCHES: a single broken file must not abort the whole run; the others
    # are still written and the exit status becomes 2.
    write(tmp_path / "good.go", BAD)
    write(tmp_path / "broken.go", b"package p\nfunc {\n")
    res = run_gofumpt(["-w", "good.go", "broken.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"broken.go:2:6: expected 'IDENT', found '{'\n"
    assert (tmp_path / "good.go").read_bytes() == FORMATTED
    assert (tmp_path / "broken.go").read_bytes() == b"package p\nfunc {\n"
    assert sibling_temp_files(tmp_path, "good.go") == []


def test_write_adds_missing_final_newline(tmp_path):
    """-w appends the missing final newline to the file on disk."""
    # CATCHES: the one-byte difference counts as a change, so the file is
    # rewritten with the trailing newline the printer always emits.
    write(tmp_path / "a.go", b"package p\n\nvar x = 1")
    res = run_gofumpt(["-w", "a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "a.go").read_bytes() == b"package p\n\nvar x = 1\n"
