"""The vendored go/format engine's node-printing entry points.

gofumpt's rules never guess how a construct will be laid out: they push
candidate nodes back through the vendored go/format format.Node - the same
frozen printer configuration (tab indent of width 8 and number-literal
normalization) that renders the final file - and act on what comes back.
Three entry points are reachable from the CLI: printing two field types
and comparing the bytes to decide -extra parameter grouping, pushing a
clause through a byte counter to measure whether it fits on one line,
and printing a node wrapped with its interior comments to test for a
single line.  These tests pin the decisions that engine makes, down to
the exact byte budget of the measurement.
"""

import pytest

from conftest import write, run_gofumpt


def fmt_file(tmp_path, src, args=()):
    """Write src.go, run gofumpt on it and return the completed process."""
    write(tmp_path / "src.go", src)
    return run_gofumpt([*args, "src.go"], cwd=tmp_path)


@pytest.mark.parametrize(
    "src,expected",
    [
        pytest.param(
            "package p\n\nfunc f(a [0X1]int, b [0x1]int) {}\n",
            b"package p\n\nfunc f(a, b [0x1]int) {}\n",
            id="hex-prefix",
        ),
        pytest.param(
            "package p\n\nfunc f(a [1E9]int, b [1e9]int) {}\n",
            b"package p\n\nfunc f(a, b [1e9]int) {}\n",
            id="decimal-exponent",
        ),
        pytest.param(
            "package p\n\nfunc f(a [0B101]int, b [0b101]int) {}\n",
            b"package p\n\nfunc f(a, b [0b101]int) {}\n",
            id="binary",
        ),
        pytest.param(
            "package p\n\nfunc f(a [0O17]int, b [0o17]int) {}\n",
            b"package p\n\nfunc f(a, b [0o17]int) {}\n",
            id="octal",
        ),
    ],
)
def test_extra_merge_compares_normalized_number_literals(tmp_path, src, expected):
    """-extra merges params whose types differ only by literal casing."""
    # CATCHES: the engine prints both types through the vendored go/format
    # Node before comparing, and that printer config normalizes number
    # literals, so "[0X1]int" and "[0x1]int" print the same bytes and the
    # parameters merge - a comparison over the raw source would keep them.
    res = fmt_file(tmp_path, src, args=["-extra"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_extra_merge_keeps_differently_cased_hex_digits_apart(tmp_path):
    """Hex digits keep their case in the printed type comparison."""
    # CATCHES: number normalization only lowercases the 0x prefix and the
    # exponent marker, never the hex digits themselves, so "[0xabc]int" and
    # "[0xABC]int" print different bytes and the params stay unmerged.
    res = fmt_file(
        tmp_path,
        "package p\n\nfunc f(a [0xabc]int, b [0xABC]int) {}\n",
        args=["-extra"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f(a [0xabc]int, b [0xABC]int) {}\n"


@pytest.mark.parametrize(
    "src,expected",
    [
        pytest.param(
            "package p\n\nfunc f(a [0X1]int, b [0X2]int) {}\n",
            b"package p\n\nfunc f(a [0x1]int, b [0x2]int) {}\n",
            id="different-values",
        ),
        pytest.param(
            "package p\n\nfunc f(a [0X1]int, b [0x1]string) {}\n",
            b"package p\n\nfunc f(a [0x1]int, b [0x1]string) {}\n",
            id="different-elem-types",
        ),
    ],
)
def test_extra_merge_rejects_unequal_printed_types(tmp_path, src, expected):
    """Params whose printed types differ do not merge under -extra."""
    # CATCHES: the merge compares the printed type bytes, so a different
    # array length or element type keeps the parameters separate even
    # though both normalize to lowercase prefixes in the final output.
    res = fmt_file(tmp_path, src, args=["-extra"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_extra_merge_is_inert_without_the_flag(tmp_path):
    """Without -extra the equal printed types are left alone."""
    # CATCHES: parameter grouping is opt-in through -extra, so the very
    # input that merges under the flag keeps two separate parameters when
    # the flag is absent.
    res = fmt_file(tmp_path, "package p\n\nfunc f(a [0X1]int, b [0x1]int) {}\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f(a [0x1]int, b [0x1]int) {}\n"


def test_extra_merge_stops_at_the_first_mismatch(tmp_path):
    """Only the leading run of equal printed types is merged."""
    # CATCHES: the engine walks adjacent pairs and stops merging at the
    # first pair whose printed types differ, so a and b join while the
    # differently-sized c parameter stays on its own.
    res = fmt_file(
        tmp_path,
        "package p\n\nfunc f(a [0X1]int, b [0x1]int, c [0X2]int) {}\n",
        args=["-extra"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f(a, b [0x1]int, c [0x2]int) {}\n"


@pytest.mark.parametrize(
    "src,expected",
    [
        pytest.param(
            "package p\n\nfunc f() (a int, b int) { return 0, 0 }\n",
            b"package p\n\nfunc f() (a, b int) { return 0, 0 }\n",
            id="result-list",
        ),
        pytest.param(
            "package p\n\nfunc f() (a [0X1]int, b [0x1]int) { return [1]int{}, [1]int{} }\n",
            b"package p\n\nfunc f() (a, b [0x1]int) { return [1]int{}, [1]int{} }\n",
            id="result-list-numbers",
        ),
        pytest.param(
            "package p\n\nvar f = func(a int, b int) {}\n",
            b"package p\n\nvar f = func(a, b int) {}\n",
            id="func-literal",
        ),
        pytest.param(
            "package p\n\nfunc (t T) m(a int, b int) {}\n",
            b"package p\n\nfunc (t T) m(a, b int) {}\n",
            id="method",
        ),
        pytest.param(
            "package p\n\nfunc f[T any, U any](x T) {}\n",
            b"package p\n\nfunc f[T, U any](x T) {}\n",
            id="type-params",
        ),
    ],
)
def test_extra_merge_runs_on_every_parameter_list(tmp_path, src, expected):
    """-extra groups results, literals, methods and type params alike."""
    # CATCHES: the printed-type comparison drives every field list hanging
    # off a function - named results, func literals, methods with
    # receivers and generic type parameter lists - not just plain params.
    res = fmt_file(tmp_path, src, args=["-extra"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_extra_never_merges_struct_fields(tmp_path):
    """Struct fields on one line are split, never grouped by -extra."""
    # CATCHES: struct field lists are deliberately excluded from parameter
    # grouping, so "a int; b int" inside a struct becomes one field per
    # line instead of the merged "a, b int" a function would get.
    res = fmt_file(
        tmp_path,
        "package p\n\ntype T struct{ a int; b int }\n",
        args=["-extra"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\ntype T struct {\n\ta int\n\tb int\n}\n"


def test_extra_merges_same_line_interface_methods(tmp_path):
    """-extra merges same-line interface methods into the first one."""
    # CATCHES: interface method lists go through the same printed-type
    # comparison, so two identical signatures on one line merge their
    # names - and the printer only renders the first name, dropping M2.
    res = fmt_file(
        tmp_path,
        "package p\n\ntype I interface{ M1(); M2() }\n",
        args=["-extra"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\ntype I interface {\n\tM1()\n}\n"


def test_extra_merges_a_whole_run_of_interface_methods(tmp_path):
    """Three same-line methods with equal types collapse to one."""
    # CATCHES: the merge is a loop over adjacent same-line fields, so all
    # three identical methods merge into a single field whose printed
    # form keeps only the first name, M1.
    res = fmt_file(
        tmp_path,
        "package p\n\ntype I interface{ M1(); M2(); M3() }\n",
        args=["-extra"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\ntype I interface {\n\tM1()\n}\n"


@pytest.mark.parametrize(
    "src,args,expected",
    [
        pytest.param(
            "package p\n\ntype I interface{ M1(); M2() }\n",
            [],
            b"package p\n\ntype I interface {\n\tM1()\n\tM2()\n}\n",
            id="without-extra",
        ),
        pytest.param(
            "package p\n\ntype I interface{ M1(); M2(x int) }\n",
            ["-extra"],
            b"package p\n\ntype I interface {\n\tM1()\n\tM2(x int)\n}\n",
            id="distinct-types",
        ),
    ],
)
def test_interface_methods_survive_without_merge(tmp_path, src, args, expected):
    """Interface methods only merge under -extra with equal types."""
    # CATCHES: without the -extra flag, or when the printed method types
    # differ, both methods survive and are split onto their own lines.
    res = fmt_file(tmp_path, src, args=args)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def case_clause_src(ident, nested):
    """Build a switch whose case keyword and list sit on separate lines."""
    if nested:
        return (
            "package p\n\nfunc f(x int) {\n\tif true {\n\t\tswitch x {\n"
            f"\t\tcase\n\t\t{ident}:\n\t\t\t_ = x\n\t\t}}\n\t}}\n}}\n"
        )
    return (
        "package p\n\nfunc f(x int) {\n\tswitch x {\n"
        f"\tcase\n\t{ident}:\n\t\t_ = x\n\t}}\n}}\n"
    )


@pytest.mark.parametrize(
    "ident_len,nested,expected",
    [
        # "case " + 37 identifier chars + ":" prints 43 bytes; with the
        # printer's trailing newline and one 8-column tab per enclosing
        # block that measures exactly 60, the budget, so it collapses.
        pytest.param(
            37,
            False,
            b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n\t\t_ = x\n\t}\n}\n",
            id="func-level-fits",
        ),
        pytest.param(
            38,
            False,
            b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n\t\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n\t\t_ = x\n\t}\n}\n",
            id="func-level-too-long",
        ),
        # One more enclosing block (the if) adds another 8 columns, so
        # only 29 identifier characters fit under the same budget.
        pytest.param(
            29,
            True,
            b"package p\n\nfunc f(x int) {\n\tif true {\n\t\tswitch x {\n\t\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n\t\t\t_ = x\n\t\t}\n\t}\n}\n",
            id="nested-fits",
        ),
        pytest.param(
            30,
            True,
            b"package p\n\nfunc f(x int) {\n\tif true {\n\t\tswitch x {\n\t\tcase\n\t\t\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n\t\t\t_ = x\n\t\t}\n\t}\n}\n",
            id="nested-too-long",
        ),
    ],
)
def test_case_clause_collapse_boundary(tmp_path, ident_len, nested, expected):
    """Case clauses collapse only within the engine's byte budget."""
    # CATCHES: the clause without its body is printed through the byte
    # counter and compared against a 60-byte budget that includes the
    # trailing newline and one 8-column tab per enclosing block, so the
    # collapse flips exactly between 37 and 38 identifier characters at
    # func level and between 29 and 30 one block deeper.
    res = fmt_file(tmp_path, case_clause_src("a" * ident_len, nested))
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_case_clause_inline_comment_counts_toward_the_budget(tmp_path):
    """A trailing comment after the colon eats into the byte budget."""
    # CATCHES: the measurement adds the inline comment that sits between
    # the colon and the first body statement, so a clause that fits on its
    # own (43 bytes at func level) no longer collapses once " // note" is
    # appended to the colon line.
    ident = "a" * 37
    src = (
        f"package p\n\nfunc f(x int) {{\n\tswitch x {{\n\tcase\n"
        f"\t{ident}: // note\n\t\t_ = x\n\t}}\n}}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        f"package p\n\nfunc f(x int) {{\n\tswitch x {{\n\tcase\n"
        f"\t\t{ident}: // note\n\t\t_ = x\n\t}}\n}}\n"
    ).encode()


@pytest.mark.parametrize(
    "src",
    [
        pytest.param(
            "package p\n\nvar x = /* c */\n1\n",
            id="block-comment",
        ),
        pytest.param(
            "package p\n\nvar x = // c\n1\n",
            id="line-comment",
        ),
        pytest.param(
            "package p\n\nvar // c\nx = 1\n",
            id="comment-after-keyword",
        ),
    ],
)
def test_lone_var_decl_with_interior_comment_is_not_joined(tmp_path, src):
    """A comment inside a spread lone var decl blocks the line join."""
    # CATCHES: the one-line probe prints the spec wrapped with the
    # comments inside it, and a comment forces a newline into the printed
    # bytes, so "var x = /* c */\n1" stays split instead of collapsing to
    # the single "var x = /* c */ 1" line a comment-less print would give.
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


@pytest.mark.parametrize(
    "keyword",
    [
        pytest.param("if", id="if"),
        pytest.param("for", id="for"),
    ],
)
def test_multiline_printed_condition_keeps_blank_line_after_brace(tmp_path, keyword):
    """A condition that stays multi-line keeps the blank line after {."""
    # CATCHES: the engine re-prints the condition to see whether the
    # printer joins it; a binary expression keeps its source line break,
    # so the blank line between the open brace and the body is kept for
    # readability instead of being squeezed out.
    src = (
        f"package p\n\nfunc f(x, aaa, bbb bool) {{\n\t{keyword} x || (aaa &&\n"
        "\t\tbbb) {\n\n\t\t_ = x\n\t}\n}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


@pytest.mark.parametrize(
    "keyword",
    [
        pytest.param("if", id="if"),
        pytest.param("for", id="for"),
    ],
)
def test_joined_printed_condition_drops_blank_line_after_brace(tmp_path, keyword):
    """A condition the printer joins loses the blank line after {."""
    # CATCHES: "!x" prints on a single line, so the same rule that kept
    # the blank line for a split binary condition now removes it, joining
    # "!\nx" into "!x" and pulling the body statement up to the brace.
    src = (
        f"package p\n\nfunc f(x bool) {{\n\t{keyword} !\nx {{\n\n\t\t_ = x\n\t}}\n}}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        f"package p\n\nfunc f(x bool) {{\n\t{keyword} !x {{\n\t\t_ = x\n\t}}\n}}\n"
    ).encode()


def test_multiline_condition_still_drops_blank_line_before_rbrace(tmp_path):
    """The blank line before } is dropped even for a split condition."""
    # CATCHES: only the blank line after the open brace is preserved for
    # a multi-line condition; blank lines between the last statement and
    # the closing brace are removed regardless.
    src = (
        "package p\n\nfunc f(x, aaa, bbb bool) {\n\tif x || (aaa &&\n"
        "\t\tbbb) {\n\t\t_ = x\n\n\t}\n}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "package p\n\nfunc f(x, aaa, bbb bool) {\n\tif x || (aaa &&\n"
        "\t\tbbb) {\n\t\t_ = x\n\t}\n}\n"
    ).encode()
