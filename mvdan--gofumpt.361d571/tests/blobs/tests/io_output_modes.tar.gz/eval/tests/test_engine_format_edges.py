"""Edge decisions of the vendored go/format probing entry points.

The rules package pushes candidate nodes back through the vendored
go/format format.Node with the same frozen printer configuration that
renders the final file.  Round 4 pinned the headline decisions; these
tests pin the edges of the same three entry points: the -extra field
merge prints both types through an EMPTY token.FileSet so that only
the canonical one-line rendering is compared - two types that differ
solely in where their source line breaks sit print the same bytes and
merge - while the case-clause budget counts raw BYTES through the byte
counter, including the comment text exactly as the printer will render
it, and the lone-var join probes the spec alone, blind to the
declaration's doc comment and to comments after the spec's end.
"""

import pytest

from conftest import write, run_gofumpt


def fmt_file(tmp_path, src, args=()):
    """Write src.go, run gofumpt on it and return the completed process."""
    write(tmp_path / "src.go", src)
    return run_gofumpt([*args, "src.go"], cwd=tmp_path)


@pytest.mark.parametrize(
    "src,expected",
    [
        pytest.param(
            "package p\n\ntype I interface {\n\tM1() struct{ x int }; M2() struct {\n\t\tx int\n\t}\n}\n",
            b"package p\n\ntype I interface {\n\tM1() struct{ x int }\n}\n",
            id="interface-methods",
        ),
        pytest.param(
            "package p\n\nfunc f(a struct{ x int }, b struct {\n\tx int\n}) {}\n",
            b"package p\n\nfunc f(a, b struct{ x int },\n\n) {\n}\n",
            id="func-params",
        ),
        pytest.param(
            "package p\n\nfunc f[T struct{ x int }, U struct {\n\tx int\n}](t T) {}\n",
            b"package p\n\nfunc f[T, U struct{ x int },\n\n](t T) {\n}\n",
            id="type-params",
        ),
        pytest.param(
            "package p\n\nfunc f() (a struct{ x int }, b struct {\n\tx int\n}) { return struct{ x int }{}, struct{ x int }{} }\n",
            b"package p\n\nfunc f() (a, b struct{ x int },\n\n) {\n\treturn struct{ x int }{}, struct{ x int }{}\n}\n",
            id="result-list",
        ),
        pytest.param(
            "package p\n\nfunc f(a chan struct{ x int }, b chan struct {\n\tx int\n}) {}\n",
            b"package p\n\nfunc f(a, b chan struct{ x int },\n\n) {\n}\n",
            id="chan-elem",
        ),
        pytest.param(
            "package p\n\ntype I interface {\n\tM1() interface{ M() }; M2() interface {\n\t\tM()\n\t}\n}\n",
            b"package p\n\ntype I interface {\n\tM1() interface{ M() }\n}\n",
            id="interface-in-type",
        ),
    ],
)
def test_extra_merge_ignores_source_line_breaks_in_types(tmp_path, src, expected):
    """-extra merges same-line fields whose types differ only in line breaks."""
    # CATCHES: the printed-type comparison runs against an empty FileSet, so
    # positions and source line breaks are invisible to it: a struct type
    # spanning several source lines prints as "struct{ x int }" and matches
    # the one-liner next to it, merging the fields.  Printing with the real
    # positions would keep the multi-line type apart and block every merge.
    res = fmt_file(tmp_path, src, args=["-extra"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_extra_merge_line_break_insensitivity_requires_the_flag(tmp_path):
    """Without -extra the line-break-insensitive merge never happens."""
    # CATCHES: the empty-FileSet comparison only drives -extra parameter
    # grouping, so the very shapes that merge under the flag keep both
    # fields - M2 and its multi-line struct type survive untouched.
    res = fmt_file(
        tmp_path,
        "package p\n\ntype I interface {\n\tM1() struct{ x int }; M2() struct {\n\t\tx int\n\t}\n}\n",
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"package p\n\ntype I interface {\n\tM1() struct{ x int }\n"
        b"\tM2() struct {\n\t\tx int\n\t}\n}\n"
    )


def test_extra_merge_still_requires_equal_printed_types(tmp_path):
    """Types that differ beyond line breaks do not merge under -extra."""
    # CATCHES: ignoring positions does not mean ignoring content - the two
    # printed types must still be byte-equal, so a struct holding "y int"
    # never matches one holding "x int" however their lines are laid out.
    res = fmt_file(
        tmp_path,
        "package p\n\ntype I interface {\n\tM1() struct{ x int }; M2() struct {\n\t\ty int\n\t}\n}\n",
        args=["-extra"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"package p\n\ntype I interface {\n\tM1() struct{ x int }\n"
        b"\tM2() struct {\n\t\ty int\n\t}\n}\n"
    )


@pytest.mark.parametrize(
    "src,expected",
    [
        pytest.param(
            "package p\n\ntype I interface {\n\tM1()\n\tM2()\n}\n",
            b"package p\n\ntype I interface {\n\tM1()\n\tM2()\n}\n",
            id="interface-methods",
        ),
        pytest.param(
            "package p\n\nfunc f(a int,\n\tb int) {}\n",
            b"package p\n\nfunc f(a int,\n\tb int) {\n}\n",
            id="func-params",
        ),
    ],
)
def test_extra_never_merges_fields_starting_on_separate_lines(tmp_path, src, expected):
    """Fields on separate source lines are never merged by -extra."""
    # CATCHES: before any printing, the merge requires both fields to START
    # on the same source line - "trust the user if they used separate
    # lines" - so identical signatures stacked vertically stay separate.
    res = fmt_file(tmp_path, src, args=["-extra"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_extra_never_merges_embedded_elements(tmp_path):
    """Embedded interface elements have no names, so they never merge."""
    # CATCHES: the merge concatenates field NAMES, and an embedded element
    # like "~int" has none, so the name check rejects the pair even under
    # -extra with two identical type elements on one line.
    res = fmt_file(
        tmp_path,
        "package p\n\ntype I interface{ ~int; ~int }\n",
        args=["-extra"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\ntype I interface {\n\t~int\n\t~int\n}\n"


def test_extra_merge_resumes_after_a_mismatch(tmp_path):
    """Merging continues with the next pair after a rejected one."""
    # CATCHES: the walk keeps the last unmerged field as the comparison
    # base, so after "a" fails to merge with "b", "b" merges with the
    # equal-typed "c" - grouping resumes instead of stopping for the rest
    # of the list at the first mismatch.
    res = fmt_file(
        tmp_path,
        "package p\n\nfunc f(a [0X1]int, b [0X2]int, c [0X2]int) {}\n",
        args=["-extra"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f(a [0x1]int, b, c [0x2]int) {}\n"


def case_src(ident, suffix=""):
    """Build a switch whose case keyword, list and suffix sit on their lines."""
    return (
        "package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n"
        f"\t\t{ident}:{suffix}\n\t\t_ = x\n\t}}\n}}\n"
    )


@pytest.mark.parametrize(
    "ident,expected",
    [
        # "case " + 37 ASCII chars + ":" is 43 printed bytes - exactly the
        # budget at this nesting - so it collapses (pinned in round 4 too).
        pytest.param(
            "a" * 37,
            b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n\t\t_ = x\n\t}\n}\n",
            id="ascii-37-chars-37-bytes",
        ),
        # The same 37 characters with one two-byte rune are 38 BYTES, one
        # over the budget, so the clause stays split even though a
        # character-counting implementation would still collapse it.
        pytest.param(
            "a" * 36 + "é",
            "package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n\t\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaé:\n\t\t_ = x\n\t}\n}\n".encode(),
            id="37-chars-38-bytes",
        ),
        # Dropping to 36 characters (37 bytes) brings it back under the
        # budget even with the two-byte rune, so it collapses again.
        pytest.param(
            "a" * 35 + "é",
            "package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaé:\n\t\t_ = x\n\t}\n}\n".encode(),
            id="36-chars-37-bytes",
        ),
    ],
)
def test_case_clause_budget_counts_bytes_not_runes(tmp_path, ident, expected):
    """The case-clause collapse budget is counted in bytes, not characters."""
    # CATCHES: the clause is measured through a byte counter, so a
    # two-byte rune in the label costs two units: 37 characters with one
    # accented letter stay split while the all-ASCII 37-character label
    # collapses, flipping exactly where a rune- or column-counting
    # implementation would not.
    res = fmt_file(tmp_path, case_src(ident))
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


@pytest.mark.parametrize(
    "ident,expected",
    [
        # 32 ASCII chars print 38 bytes; the inline comment counts as the
        # five bytes " // x" once rewritten and trimmed, totalling exactly
        # the 43-byte budget, so the clause collapses.
        pytest.param(
            "a" * 32,
            b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa: // x\n\t\t_ = x\n\t}\n}\n",
            id="fits-with-trimmed-comment",
        ),
        # One more character pushes the total one byte over the budget and
        # the clause stays split, proving the comment's rendered text (not
        # the raw "//x  " with its trailing blanks) is what is counted.
        pytest.param(
            "a" * 33,
            b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n\t\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa: // x\n\t\t_ = x\n\t}\n}\n",
            id="one-over-with-trimmed-comment",
        ),
    ],
)
def test_case_clause_budget_counts_the_rendered_comment_text(tmp_path, ident, expected):
    """The budget counts the comment as the printer renders it, trimmed."""
    # CATCHES: the inline comment "//x  " is counted as " // x" - the
    # trailing whitespace is dropped and the space the rewrite inserts
    # after "//" is included - so the collapse boundary sits between 32
    # and 33 identifier characters, where counting the raw comment text
    # would shift it.
    res = fmt_file(tmp_path, case_src(ident, suffix=" //x  "))
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


@pytest.mark.parametrize(
    "suffix,expected",
    [
        # A comment on its own line after the colon is not on the colon's
        # line, so it costs nothing and the clause still collapses.
        pytest.param(
            "\n\t\t// note",
            b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n\t\t// note\n\t\t_ = x\n\t}\n}\n",
            id="own-line-comment-is-free",
        ),
        # A /*-style comment on the colon's line counts just like a line
        # comment, pushing the clause over the budget.
        pytest.param(
            " /* note */",
            b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n\t\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa: /* note */\n\t\t_ = x\n\t}\n}\n",
            id="block-comment-on-colon-line-counts",
        ),
    ],
)
def test_case_clause_budget_counts_comments_only_on_the_colon_line(
    tmp_path, suffix, expected
):
    """Only a comment sharing the colon's line eats into the byte budget."""
    # CATCHES: the measurement picks the first comment after the clause
    # that sits ON the colon's line and before the first body statement,
    # whatever its style; a comment on the following line is ignored by
    # the budget even though it precedes the body too.
    res = fmt_file(tmp_path, case_src("a" * 37, suffix=suffix))
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_lone_var_decl_join_ignores_the_decls_doc_comment(tmp_path):
    """A doc comment above a spread lone var decl does not block the join."""
    # CATCHES: the one-line probe prints the SPEC alone rather than the
    # whole declaration, precisely because the printer would emit the
    # declaration's doc comment above it and that extra line would read as
    # a split; here the spec joins onto "var" with the doc left above.
    res = fmt_file(tmp_path, "package p\n\n// doc\nvar\nx = 1\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\n// doc\nvar x = 1\n"


def test_lone_var_decl_join_ignores_comment_after_the_spec(tmp_path):
    """A trailing comment after the spec's last token does not block joining."""
    # CATCHES: the probe wraps the spec with the comments strictly between
    # its own start and end, so the "// c" sitting after the value on the
    # same line is outside the probed node: the spec still measures as one
    # line and "var\nx = 1 // c" collapses to a single line.
    res = fmt_file(tmp_path, "package p\n\nvar\nx = 1 // c\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar x = 1 // c\n"
