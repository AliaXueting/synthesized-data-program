"""Named pipes as explicit input arguments.

A FIFO is not a regular file, so gofumpt cannot trust a stat size for it:
the reader falls back to reading the pipe to EOF.  These tests feed a named
pipe named like a Go file as an explicit argument and pin that its contents
are formatted to stdout, that parse errors are reported against the pipe's
path, and that -l lists it like any other unformatted input.
"""

import os
import threading

from conftest import run_gofumpt


def feed_fifo(path, payload):
    """Open ``path`` (a FIFO) for writing and feed ``payload`` into it.

    Opening blocks until gofumpt opens the read end, so this is meant to run
    in a daemon thread while the child process is blocked in open().
    """
    with open(path, "wb") as fifo:
        fifo.write(payload)


def run_with_fifo(tmp_path, payload, args):
    """Create pipe.go, feed payload through it, and run gofumpt on it."""
    fifo = tmp_path / "pipe.go"
    os.mkfifo(fifo)
    writer = threading.Thread(target=feed_fifo, args=(fifo, payload), daemon=True)
    writer.start()
    try:
        return run_gofumpt([*args, "pipe.go"], cwd=tmp_path, timeout=15)
    finally:
        writer.join(timeout=15)


def test_fifo_argument_is_read_and_formatted(tmp_path):
    """A named pipe's contents are formatted like a regular file's."""
    # CATCHES: the pipe is not a regular file, so its size cannot be statted
    # ahead of the read; the reader must fall back to reading to EOF, and
    # the formatted result reaches stdout with exit 0.
    res = run_with_fifo(tmp_path, b"package p\n\nvar  x=1\n", [])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar x = 1\n"


def test_fifo_parse_error_names_the_fifo(tmp_path):
    """A syntax error inside piped content reports the pipe's path."""
    # CATCHES: the error position is reported as pipe.go:line:col exactly as
    # for a regular file, so the pseudo-name of the input survives the
    # size-less read path.
    res = run_with_fifo(tmp_path, b"package p\nfunc {\n", [])
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"pipe.go:2:6: expected 'IDENT', found '{'\n"


def test_fifo_is_listed_when_unformatted(tmp_path):
    """-l reports the pipe itself when its contents need formatting."""
    # CATCHES: the differing-bytes check works the same for the pipe's
    # in-memory source, so the pipe's path is the listed name and the exit
    # status stays 0 like any other -l listing.
    res = run_with_fifo(tmp_path, b"package p\n\nvar  x=1\n", ["-l"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"pipe.go\n"
