"""List layout decisions made by the vendored printer's alignment engine.

When the printer lays out a list of key:value elements over several lines it
aligns the values in tabwriter columns, but the decision is guarded by a
geometric-mean heuristic over the sizes already printed: an element whose key
is an outlier compared with the running geometric mean makes the printer break
the alignment section (a formfeed) so the following elements re-align among
themselves, while keys of similar size keep one shared column.  Separately,
multi-line string literals suspend column alignment for the rest of their
line, and adjacent operator tokens that would lex as one token (``- -``,
``/ *``, ``& ^``) must be separated by a blank.  These tests pin those
byte-level outcomes of the rendering engine.
"""

from conftest import write, run_gofumpt


def fmt_file(tmp_path, src):
    """Write src.go, run gofumpt on it and return the completed process."""
    write(tmp_path / "src.go", src)
    return run_gofumpt(["src.go"], cwd=tmp_path)


def test_short_map_keys_align_values(tmp_path):
    """Keys of similar short size share one value column."""
    # CATCHES: the printer pads the shorter key with an extra space so both
    # values start in the same tabwriter column; a printer without column
    # alignment would leave the single-space layout of the input.
    src = (
        "package p\n"
        "\n"
        "var m = map[string]string{\n"
        '\t"a": "one",\n'
        '\t"bb": "two",\n'
        "}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "package p\n"
        "\n"
        "var m = map[string]string{\n"
        '\t"a":  "one",\n'
        '\t"bb": "two",\n'
        "}\n"
    ).encode()


def test_outlier_long_key_breaks_alignment_sections(tmp_path):
    """A key far larger than the running mean splits the aligned column."""
    # CATCHES: the geometric-mean heuristic sees the 48-byte key as an
    # outlier and inserts formfeeds around it, so every entry ends up in its
    # own tabwriter section with single-space padding instead of one wide
    # shared column reaching across all three entries.
    src = (
        "package p\n"
        "\n"
        "var m = map[string]string{\n"
        '\t"a":                                                "one",\n'
        '\t"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": "two",\n'
        '\t"bb":                                               "three",\n'
        "}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "package p\n"
        "\n"
        "var m = map[string]string{\n"
        '\t"a": "one",\n'
        '\t"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": "two",\n'
        '\t"bb": "three",\n'
        "}\n"
    ).encode()


def test_similarly_long_keys_stay_aligned(tmp_path):
    """Two oversized keys of similar size keep one shared column."""
    # CATCHES: when the key size ratio against the running geometric mean is
    # inside the threshold band the printer keeps using newlines (not
    # formfeeds), so both long entries stay aligned to each other's width.
    src = (
        "package p\n"
        "\n"
        "var m = map[string]string{\n"
        '\t"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": "one",\n'
        '\t"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb": "two",\n'
        "}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "package p\n"
        "\n"
        "var m = map[string]string{\n"
        '\t"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": "one",\n'
        '\t"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb": "two",\n'
        "}\n"
    ).encode()


def test_multiline_raw_value_starts_new_alignment_section(tmp_path):
    """A value spanning lines ends the alignment of the entries after it."""
    # CATCHES: the newline inside the raw string sets the printer's
    # end-alignment flag, so the line break after that entry becomes a
    # formfeed; the following short entries re-align with each other but no
    # longer with the raw entry, whose value is padded with a single space.
    src = (
        "package p\n"
        "\n"
        "var m = map[string]string{\n"
        '\t"a":  `multi\n'
        'line`,\n'
        '\t"bb": "x",\n'
        '\t"c":  "y",\n'
        "}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "package p\n"
        "\n"
        "var m = map[string]string{\n"
        '\t"a": `multi\n'
        'line`,\n'
        '\t"bb": "x",\n'
        '\t"c":  "y",\n'
        "}\n"
    ).encode()


def test_raw_string_value_degrades_alignment_on_same_line(tmp_path):
    """A vtab after a multi-line literal is downgraded to a plain space."""
    # CATCHES: while column alignment is suspended the printer rewrites
    # pending tab/vtab whitespace as spaces, so the pair following a raw
    # string value on the same line keeps single-space padding instead of
    # being pushed into an aligned column.
    src = (
        "package p\n"
        "\n"
        'var m = map[string]string{"a": `x\n'
        'y`, "bb": "z"}\n'
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "package p\n"
        "\n"
        'var m = map[string]string{"a": `x\n'
        'y`, "bb": "z"}\n'
    ).encode()


def test_compact_high_precedence_operators_have_no_blanks(tmp_path):
    """Mixed precedences drop the blanks around the tighter operator."""
    # CATCHES: when a binary expression tree mixes precedence levels the
    # printer renders the higher-precedence operator without surrounding
    # blanks (b/c, b&c, a*b) while keeping them around the lower one.
    src = (
        "package p\n"
        "\n"
        "var (\n"
        "\t_ = a + b / c\n"
        "\t_ = a + b & c\n"
        "\t_ = a * b + c\n"
        ")\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "package p\n"
        "\n"
        "var (\n"
        "\t_ = a + b/c\n"
        "\t_ = a + b&c\n"
        "\t_ = a*b + c\n"
        ")\n"
    ).encode()


def test_compact_operator_before_unary_operand_keeps_the_token_apart(tmp_path):
    """A compact operator still separates from a unary operand token."""
    # CATCHES: after a blank-less operator the next token still goes through
    # the may-combine check, keeping b/-c, b&-c and b%-c legal; a printer
    # that dropped the operator blanks without that check would emit tokens
    # that lex differently.
    src = (
        "package p\n"
        "\n"
        "var (\n"
        "\t_ = a + b / -c\n"
        "\t_ = a + b & -c\n"
        "\t_ = a + b % -c\n"
        ")\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "package p\n"
        "\n"
        "var (\n"
        "\t_ = a + b/-c\n"
        "\t_ = a + b&-c\n"
        "\t_ = a + b%-c\n"
        ")\n"
    ).encode()


def test_division_by_dereference_keeps_separator_blanks(tmp_path):
    """A / followed by * keeps blanks so no comment token is formed."""
    # CATCHES: the printer's walk of the expression tree flags the / and *
    # pair and raises the blank threshold for it, printing b / *c with
    # spaces; without that guard the compact form would start a comment.
    src = "package p\n\nvar _ = a + b/ *c\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar _ = a + b / *c\n"


def test_unary_sign_chains_keep_separator_blank(tmp_path):
    """Two unary signs in a row are printed with a blank between them."""
    # CATCHES: the printer notices the previous token and the next byte
    # would combine into -- or ++ and inserts a blank, so - -b and + +b stay
    # two operators instead of reading as the decrement/increment tokens.
    src = (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = - -b\n"
        "\ty = + +b\n"
        ")\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


def test_trailing_spec_comment_survives_group_unwrap(tmp_path):
    """A line comment on the spec moves out with it when parens unwrap."""
    # CATCHES: the single-spec var group is unwrapped and re-printed on one
    # line, and the spec's trailing comment is carried along to the right of
    # the joined declaration rather than dropped or hoisted above it.
    src = (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1 // trailing\n"
        ")\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar x = 1 // trailing\n"
