"""Build-constraint comments: //go:build and // +build normalization.

The rendering engine does not print build-constraint comments where it
found them: the vendored printer's fixGoBuildLines collects every
//go:build and // +build line of the file, re-derives the canonical
//go:build expression, regenerates the // +build lines from it, and
places the whole block just after the last blank line of the leading
comment block.  These tests pin the observable results of that machinery
through every output mode.
"""

import pytest

from conftest import run_gofumpt, sibling_temp_files, write


def fmt_file(tmp_path, src, args=()):
    """Write src.go, run gofumpt on it and return the completed process."""
    write(tmp_path / "src.go", src)
    return run_gofumpt([*args, "src.go"], cwd=tmp_path)


def as_bytes(text):
    """Encode a str (or pass bytes through) for exact comparison."""
    return text.encode() if isinstance(text, str) else text


@pytest.mark.parametrize(
    "line,expected",
    [
        pytest.param("//go:build linux&&amd64", "//go:build linux && amd64", id="and-spacing"),
        pytest.param("//go:build a||b", "//go:build a || b", id="or-spacing"),
        pytest.param("//go:build !a&&b", "//go:build !a && b", id="not-spacing"),
        pytest.param("//go:build a&&(b||c)", "//go:build a && (b || c)", id="needed-parens-kept"),
        pytest.param("//go:build (linux)", "//go:build linux", id="redundant-parens-dropped"),
        pytest.param("//go:build !!linux", "//go:build !!linux", id="double-negation-kept"),
        pytest.param("//go:build  linux", "//go:build linux", id="double-space-collapsed"),
        pytest.param("//go:build\tlinux", "//go:build linux", id="tab-separator-collapsed"),
        pytest.param(
            "//go:build (linux || darwin) && !windows",
            "//go:build (linux || darwin) && !windows",
            id="already-canonical",
        ),
    ],
)
def test_gobuild_expression_is_reprinted_from_its_parse(tmp_path, line, expected):
    """A lone //go:build line is re-printed from the parsed expression."""
    # CATCHES: the printer parses the constraint and prints x.String(), so
    # operator spacing is canonicalized, redundant parens disappear while
    # semantically required parens stay, instead of echoing the input bytes.
    res = fmt_file(tmp_path, line + "\n\npackage p\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == as_bytes(expected) + b"\n\npackage p\n"


@pytest.mark.parametrize(
    "plus_lines,expected_block",
    [
        pytest.param(["// +build linux"], "//go:build linux\n// +build linux", id="single-tag"),
        pytest.param(["// +build !windows"], "//go:build !windows\n// +build !windows", id="negated-tag"),
        pytest.param(["//+build linux"], "//go:build linux\n// +build linux", id="no-space-after-slashes"),
        pytest.param(["//  +build linux"], "//go:build linux\n// +build linux", id="two-spaces-after-slashes"),
        pytest.param(["// +build linux "], "//go:build linux\n// +build linux", id="trailing-space-dropped"),
        pytest.param(["// +build !!!"], "//go:build ignore\n// +build ignore", id="bang-run-is-tag-ignore"),
        pytest.param(["// +build a,"], "//go:build a && ignore\n// +build a,ignore", id="trailing-comma-is-ignore"),
        pytest.param(
            ["// +build linux,amd64", "// +build darwin"],
            "//go:build linux && amd64 && darwin\n// +build linux,amd64,darwin",
            id="two-lines-and-flattened",
        ),
        pytest.param(
            ["// +build linux,amd64 darwin"],
            "//go:build (linux && amd64) || darwin\n// +build linux,amd64 darwin",
            id="or-syntax",
        ),
        pytest.param(
            ["// +build linux,amd64", "// +build !!!"],
            "//go:build linux && amd64 && ignore\n// +build linux,amd64,ignore",
            id="mixed-with-bang-run",
        ),
    ],
)
def test_plus_build_only_synthesizes_go_build_line(tmp_path, plus_lines, expected_block):
    """// +build lines with no //go:build line gain a synthesized one."""
    # CATCHES: the go:build expression is synthesized by ANDing the parsed
    # +build lines (two lines flatten into one && chain, spaces mean || and
    # need parens), and the +build lines are then regenerated from it.
    res = fmt_file(tmp_path, "\n".join(plus_lines) + "\n\npackage p\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == as_bytes(expected_block) + b"\n\npackage p\n"


@pytest.mark.parametrize(
    "gobuild,plus_lines,expected_gobuild,expected_plus",
    [
        pytest.param(
            "//go:build linux",
            ["// +build darwin"],
            "//go:build linux",
            ["// +build linux"],
            id="inconsistent-plus-replaced",
        ),
        pytest.param(
            "//go:build linux",
            ["// +build linux", "// +build darwin"],
            "//go:build linux",
            ["// +build linux"],
            id="multiple-plus-collapse-to-one",
        ),
        pytest.param(
            "//go:build go1.20",
            ["// +build go1.20"],
            "//go:build go1.20",
            ["// +build go1.20"],
            id="release-tag-pair-passthrough",
        ),
        pytest.param(
            "//go:build go1.16 && (linux || windows)",
            ["// +build go1.16"],
            "//go:build go1.16 && (linux || windows)",
            ["// +build go1.16", "// +build linux windows"],
            id="or-needs-second-line",
        ),
        pytest.param(
            "//go:build !(linux && amd64)",
            ["// +build linux,amd64"],
            "//go:build !(linux && amd64)",
            ["// +build !linux !amd64"],
            id="not-and-expanded-de-morgan",
        ),
        pytest.param(
            "//go:build (a || b) && (c || d)",
            ["// +build a"],
            "//go:build (a || b) && (c || d)",
            ["// +build a b", "// +build c d"],
            id="or-of-ands-two-lines",
        ),
        pytest.param(
            "//go:build linux && (amd64 || arm64) || darwin",
            ["// +build linux"],
            "//go:build (linux && (amd64 || arm64)) || darwin",
            ["// +build error: expression too complex for // +build lines"],
            id="unrepresentable-plus-becomes-error",
        ),
    ],
)
def test_plus_build_lines_are_regenerated_from_go_build(
    tmp_path, gobuild, plus_lines, expected_gobuild, expected_plus
):
    """When both forms are present the //go:build line is the truth."""
    # CATCHES: every // +build line in the file is discarded and re-derived
    # from the parsed go:build expression - an inconsistent darwin line
    # becomes linux, several lines collapse to one, nesting go:build cannot
    # express produces a literal "// +build error: ..." line, and && inside
    # || gains parens in the reprinted go:build line.
    src = gobuild + "\n" + "\n".join(plus_lines) + "\n\npackage p\n"
    expected = expected_gobuild + "\n" + "\n".join(expected_plus) + "\n\npackage p\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == as_bytes(expected)


@pytest.mark.parametrize(
    "src,expected",
    [
        pytest.param("//go:build\n\npackage p\n", "//go:build\n\npackage p\n", id="bare-directive"),
        pytest.param(
            "//go:build linux &&\n\npackage p\n",
            "//go:build linux &&\n\npackage p\n",
            id="dangling-operator",
        ),
        pytest.param(
            "//go:build my-tag\n\npackage p\n",
            "//go:build my-tag\n\npackage p\n",
            id="invalid-tag-char",
        ),
        pytest.param(
            "//go:build linux\n//go:build darwin\n\npackage p\n",
            "//go:build linux\n//go:build darwin\n\npackage p\n",
            id="two-adjacent",
        ),
        pytest.param(
            "//go:build linux\n\npackage p\n\n//go:build darwin\n\nfunc f() {}\n",
            "//go:build linux\n//go:build darwin\n\npackage p\n\nfunc f() {}\n",
            id="two-separated-brought-together",
        ),
    ],
)
def test_unparseable_gobuild_lines_are_brought_together_verbatim(tmp_path, src, expected):
    """Build lines with no single valid truth move to the top unchanged."""
    # CATCHES: when the go:build expression cannot be parsed (bare, dangling
    # operator, bad tag) or there are two go:build lines, no normalization
    # happens - the raw lines are just collected at the top of the leading
    # comment block, even when one was originally after the package clause.
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == as_bytes(expected)


def test_missing_blank_line_before_package_is_added(tmp_path):
    """The build block is followed by a blank line before package."""
    # CATCHES: the regenerated block always ends with a blank separator, so
    # a file whose build comment sat directly on the package line gains one.
    res = fmt_file(tmp_path, "//go:build linux\npackage p\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"//go:build linux\n\npackage p\n"


def test_leading_blank_line_is_dropped(tmp_path):
    """A blank line before the build comment disappears from the output."""
    # CATCHES: the block is inserted at the top of the printed file, and the
    # printer emits nothing for blank lines that precede the first comment,
    # so a leading empty line is lost rather than preserved.
    res = fmt_file(tmp_path, "\n//go:build linux\n\npackage p\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"//go:build linux\n\npackage p\n"


def test_copyright_comment_stays_above_build_block(tmp_path):
    """A copyright header keeps its blank line, then the build block."""
    # CATCHES: the insertion point is after the last blank line of the
    # leading comment block, so a copyright header followed by a blank line
    # keeps exactly that shape with the build lines after the blank.
    src = "// Copyright 2020\n\n//go:build linux\n\npackage p\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


def test_plain_comment_above_build_line_stays_above(tmp_path):
    """An unseparated comment above the build line stays above it."""
    # CATCHES: with no blank line between them the whole group is the
    # leading comment block and the build line keeps its place after the
    # plain comment, only gaining the blank line before the package clause.
    res = fmt_file(tmp_path, "// note\n//go:build linux\n\npackage p\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"// note\n//go:build linux\n\npackage p\n"


def test_build_comment_after_package_is_hoisted(tmp_path):
    """A build comment below the package clause moves above it."""
    # CATCHES: any //go:build comment anywhere in the file is relocated to
    # the top - one sitting after the package clause is hoisted before it
    # and the original line is removed from where it was.
    src = "package p\n\n//go:build linux\n\nfunc f() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"//go:build linux\n\npackage p\n\nfunc f() {}\n"


def test_indented_build_comment_inside_function_is_hoisted_with_tab(tmp_path):
    """An indented //go:build inside a function body is hoisted, tab kept."""
    # CATCHES: an indented build comment is recorded at its indentation, so
    # the parse of its text fails and the raw line - leading tab included -
    # is moved to line 1 unnormalized instead of being rewritten.
    src = "package p\n\nfunc f() {\n\t//go:build linux\n\t_ = 1\n}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"\t//go:build linux\n\npackage p\n\nfunc f() {\n\t_ = 1\n}\n"


def test_indented_build_comment_inside_struct_is_hoisted_with_tab(tmp_path):
    """The same hoisting happens for a build comment inside a type."""
    # CATCHES: the relocation is position-based, not clause-based - a build
    # comment nested in a struct body is pulled to the file header the same
    # way one inside a function body is, keeping its indentation tab.
    src = "package p\n\ntype T struct {\n\t//go:build linux\n\tA int\n}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"\t//go:build linux\n\npackage p\n\ntype T struct {\n\tA int\n}\n"


def test_trailing_build_comment_on_package_line_loses_final_newline(tmp_path):
    """A build comment trailing the package line is hoisted; \\n is lost."""
    # CATCHES: the deleted comment line carried the file's final newline, so
    # after hoisting the output ends with "package p" and no trailing
    # newline - the only input shape where gofumpt drops the final byte.
    res = fmt_file(tmp_path, "package p //go:build linux\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"//go:build linux\n\npackage p"


def test_build_comment_on_own_line_after_package_keeps_newline(tmp_path):
    """A build comment on its own last line hoists but keeps the newline."""
    # CATCHES: with the comment on its own line the deleted line and the
    # file's final newline are separate, so unlike the same-line trailing
    # form the hoisted output still ends with exactly one newline and the
    # blank line before the package clause is not doubled.
    res = fmt_file(tmp_path, "package p\n//go:build linux\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"//go:build linux\n\npackage p\n"


def test_indented_plus_build_inside_function_is_hoisted_raw(tmp_path):
    """An indented // +build line is hoisted raw, without synthesis."""
    # CATCHES: the indented +build line's recorded text starts with the tab,
    # so parsing it fails: no //go:build line is synthesized and the raw
    # // +build line (tab included) is just moved to the top of the file.
    src = "package p\n\nfunc f() {\n\t// +build linux\n\t_ = 1\n}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"\t// +build linux\n\npackage p\n\nfunc f() {\n\t_ = 1\n}\n"


def test_plus_build_before_gobuild_is_left_and_duplicated(tmp_path):
    """A // +build line above the //go:build line survives plus a copy."""
    # CATCHES: only lines at or after the insertion point are deleted, so a
    # +build line placed before the go:build line stays untouched at the
    # top while the regenerated block below it repeats it.
    src = "// +build linux\n//go:build linux\n\npackage p\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"// +build linux\n//go:build linux\n// +build linux\n\npackage p\n"


def test_plus_build_pair_moves_above_later_comment(tmp_path):
    """The synthesized pair goes to the very top, above other comments."""
    # CATCHES: when a +build line sits above a blank line and another
    # comment, the insertion point would be after the blank, but the +build
    # position pulls the regenerated pair back to line 1 instead.
    src = "// +build linux\n\n// other\n\npackage p\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"//go:build linux\n// +build linux\n\n// other\n\npackage p\n"


def test_gobuild_stays_first_when_blank_then_other_comment(tmp_path):
    """A go:build line already first stays above a later comment block."""
    # CATCHES: the go:build position is before the natural insertion point
    # here too, so the normalized line stays on line 1 while the unrelated
    # comment below keeps its blank-line separation.
    src = "//go:build linux\n\n// other\n\npackage p\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


def test_stray_plus_build_after_package_is_merged_into_top_block(tmp_path):
    """A stray // +build line below the package clause joins the top pair."""
    # CATCHES: the stray +build line after the package clause is deleted
    # from its original spot and the top block is regenerated from the
    # go:build truth, so the darwin tag is replaced by linux.
    src = "//go:build linux\n\npackage p\n\n// +build darwin\n\nfunc f() {}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"//go:build linux\n// +build linux\n\npackage p\n\nfunc f() {}\n"


def test_colon_form_is_not_a_directive(tmp_path):
    """//go:build:x is an ordinary comment, not a build constraint."""
    # CATCHES: only "//go:build" followed by a space or end-of-line counts
    # as a directive, so the colon form is passed through untouched and no
    # blank line is inserted or expression normalized.
    src = "//go:build:x\n\npackage p\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == src.encode()


def test_list_mode_reports_synthesized_go_build(tmp_path):
    """-l lists a file whose only change is the synthesized //go:build."""
    # CATCHES: the +build-only file differs after formatting only because
    # the engine synthesizes the go:build line, so -l reports it (exit 0)
    # while the already-canonical pair next to it is not listed.
    write(tmp_path / "dirty.go", "// +build linux\n\npackage p\n")
    write(tmp_path / "clean.go", "//go:build linux\n// +build linux\n\npackage p\n")
    res = run_gofumpt(["-l", "dirty.go", "clean.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"dirty.go\n"


def test_diff_mode_shows_synthesis_and_exits_one(tmp_path):
    """-d prints the added //go:build line and exits 1 for the difference."""
    # CATCHES: build-constraint synthesis counts as a difference for the CI
    # contract, so the diff shows the added line and the exit status is 1,
    # while an already-canonical build file diffs to nothing and exits 0.
    write(tmp_path / "dirty.go", "// +build linux\n\npackage p\n")
    write(tmp_path / "clean.go", "//go:build linux\n// +build linux\n\npackage p\n")
    res = run_gofumpt(["-d", "dirty.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == (
        b"diff dirty.go.orig dirty.go\n"
        b"--- dirty.go.orig\n"
        b"+++ dirty.go\n"
        b"@@ -1,3 +1,4 @@\n"
        b"+//go:build linux\n"
        b" // +build linux\n"
        b" \n"
        b" package p\n"
    )
    clean = run_gofumpt(["-d", "clean.go"], cwd=tmp_path)
    assert clean.returncode == 0
    assert clean.stdout == b""


def test_write_mode_rewrites_plus_build_only(tmp_path):
    """-w writes the synthesized pair in place and leaves no backups."""
    # CATCHES: the synthesized pair is what lands in the file under -w, a
    # second run changes nothing (idempotent, so -l then lists nothing),
    # and no same-directory backup file survives the rewrite.
    write(tmp_path / "w.go", "// +build linux\n\npackage p\n")
    res = run_gofumpt(["-w", "w.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "w.go").read_bytes() == b"//go:build linux\n// +build linux\n\npackage p\n"
    assert sibling_temp_files(tmp_path, "w.go") == []
    again = run_gofumpt(["-w", "w.go"], cwd=tmp_path)
    assert again.returncode == 0
    assert (tmp_path / "w.go").read_bytes() == b"//go:build linux\n// +build linux\n\npackage p\n"
    listed = run_gofumpt(["-l", "w.go"], cwd=tmp_path)
    assert listed.returncode == 0
    assert listed.stdout == b""


def test_write_mode_fixes_inconsistent_pair(tmp_path):
    """-w rewrites an inconsistent +build line to match the go:build one."""
    # CATCHES: regeneration is not cosmetic - the on-disk darwin tag is
    # replaced by linux because the go:build expression is the truth.
    write(tmp_path / "inc.go", "//go:build linux\n// +build darwin\n\npackage p\n")
    res = run_gofumpt(["-w", "inc.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "inc.go").read_bytes() == b"//go:build linux\n// +build linux\n\npackage p\n"


def test_list_walk_covers_build_tagged_files(tmp_path):
    """A directory walk reports build-tagged files in lexical order."""
    # CATCHES: build-constraint-only differences are detected while walking
    # directories too, with subdirectories visited depth-first in sorted
    # order and already-canonical files skipped.
    write(tmp_path / "walk" / "a.go", "// +build linux\n\npackage p\n")
    write(tmp_path / "walk" / "b.go", "//go:build linux\n// +build linux\n\npackage p\n")
    write(tmp_path / "walk" / "sub" / "c.go", "// +build darwin\n\npackage p\n")
    res = run_gofumpt(["-l", "walk"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"walk/a.go\nwalk/sub/c.go\n"


def test_stdin_decl_fragment_with_gobuild_comment(tmp_path):
    """A //go:build comment in a stdin declaration fragment mangles it."""
    # CATCHES: the wrapper adds "package p;" before the fragment, so the
    # hoisted build comment lands before the package clause and the wrapper
    # stripping then cuts into the wrong bytes - "linux" survives on the
    # first line and "package p var x = 1" follows without final newline.
    res = run_gofumpt([], input=b"//go:build linux\nvar x = 1")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"linux\n\npackage p var x = 1"


def test_stdin_indented_decl_fragment_with_gobuild_comment(tmp_path):
    """An indented fragment keeps its measured indent in the mangled output."""
    # CATCHES: the fragment's two leading tabs become the printer's base
    # indent, so even "package p" is printed after them, the build comment
    # hoists before that, and the indent plus "inux" is what remains after
    # the wrapper bytes are chopped - pinning the indent measurement too.
    res = run_gofumpt([], input=b"\t\t//go:build linux\n\t\tvar x = 1")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"\t\tinux\n\n\t\tpackage p   var x = 1"


def test_stdin_stmt_fragment_with_gobuild_comment(tmp_path):
    """The statement-list wrapper variant of the same interaction."""
    # CATCHES: with the "func _() {" wrapper the stripping removes a longer
    # prefix, so a different slice of the hoisted comment survives ("kage
    # p") - the mangled bytes differ per fragment kind but stay exact.
    res = run_gofumpt([], input=b"//go:build linux\nx := 1")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"kage p\n\nfunc _() { x := 1"
