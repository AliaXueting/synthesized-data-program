"""The -l mode: list which files differ, and nothing else.

These pin that -l prints one path per line for exactly the files whose
formatting differs, keeps a zero exit status for unformatted files, and that
the listed path is the cleaned argument/walk path.
"""

import pytest

from conftest import run_gofumpt, write

BAD = b"package p\n\nfunc  f() {\nx:=1\n}\n"
FORMATTED = b"package p\n\nfunc f() {\n\tx := 1\n}\n"
BAD2 = b"package p\n\nfunc  g() {\ny:=2\n}\n"


def test_lists_only_differing_files(tmp_path):
    """-l prints the path of each unformatted file, one per line."""
    # CATCHES: -l must not print any source bytes, only newline-terminated
    # paths, and must skip the files that are already formatted.
    write(tmp_path / "unformatted.go", BAD)
    write(tmp_path / "formatted.go", FORMATTED)
    res = run_gofumpt(["-l", "unformatted.go", "formatted.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"unformatted.go\n"
    assert res.stderr == b""


def test_unformatted_files_still_exit_zero(tmp_path):
    """Finding formatting differences with -l is not a failure (exit 0)."""
    # CATCHES: unlike -d, the -l contract reports differences with a zero
    # exit status so `gofumpt -l` can be used as a plain listing tool.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-l", "a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"a.go\n"
    assert res.stderr == b""


def test_formatted_file_lists_nothing(tmp_path):
    """A formatted file contributes no line to the -l listing."""
    # CATCHES: there is no path line, no diff and no source for the clean
    # file, while the unformatted sibling still gets exactly one line.
    write(tmp_path / "clean.go", FORMATTED)
    write(tmp_path / "dirty.go", BAD)
    res = run_gofumpt(["-l", "clean.go", "dirty.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"dirty.go\n"
    assert res.stderr == b""
    assert (tmp_path / "clean.go").read_bytes() == FORMATTED


@pytest.mark.parametrize(
    "order,expected",
    [
        (["a.go", "b.go"], b"a.go\nb.go\n"),
        (["b.go", "a.go"], b"b.go\na.go\n"),
    ],
)
def test_lists_in_argument_order(tmp_path, order, expected):
    """-l lists paths in the order the files were named."""
    # CATCHES: the sequencer emits the per-file reports in argument order even
    # though the files are processed concurrently.
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "b.go", BAD2)
    res = run_gofumpt(["-l", *order], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_lists_directory_walk_in_lexical_order(tmp_path):
    """-l over a directory lists unformatted .go files in walk order."""
    # CATCHES: only .go files are considered while walking, and nested
    # directories are visited depth-first in lexical order.
    write(tmp_path / "z.go", BAD)
    write(tmp_path / "a.go", BAD2)
    write(tmp_path / "formatted.go", FORMATTED)
    write(tmp_path / "readme.txt", BAD)
    write(tmp_path / "sub" / "d.go", BAD)
    write(tmp_path / "sub" / "deep" / "f.go", BAD2)
    write(tmp_path / "sub" / "e.go", FORMATTED)
    res = run_gofumpt(["-l", "."], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"a.go\nsub/d.go\nsub/deep/f.go\nz.go\n"
    )


def test_list_with_parse_error_still_lists_others(tmp_path):
    """A broken file is reported on stderr; the rest are still listed."""
    # CATCHES: one bad file must not abort the run - the others still get
    # their path lines on stdout and the exit status becomes 2.
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "broken.go", b"package p\nfunc {\n")
    write(tmp_path / "b.go", BAD2)
    res = run_gofumpt(["-l", "a.go", "broken.go", "b.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b"a.go\nb.go\n"
    assert res.stderr == b"broken.go:2:6: expected 'IDENT', found '{'\n"


def test_list_stdin_names_standard_input(tmp_path):
    """-l with stdin lists the pseudo-path `<standard input>`."""
    # CATCHES: stdin has no real filename, so the reporter uses the same
    # placeholder that error messages use.
    res = run_gofumpt(["-l"], input=b"var  x  =  1\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"<standard input>\n"
    assert res.stderr == b""


def test_list_stdin_formatted_lists_nothing(tmp_path):
    """-l with already-formatted stdin writes nothing; a change is listed."""
    # CATCHES: fragments are compared like files, so an unchanged fragment
    # produces no listing at all while a changed one names standard input.
    clean = run_gofumpt(["-l"], input=b"var x = 1\n", cwd=tmp_path)
    assert clean.returncode == 0
    assert clean.stdout == b""
    assert clean.stderr == b""
    dirty = run_gofumpt(["-l"], input=b"var  x  =  1\n", cwd=tmp_path)
    assert dirty.returncode == 0
    assert dirty.stdout == b"<standard input>\n"
    assert dirty.stderr == b""


def test_list_explicit_non_go_file(tmp_path):
    """-l lists a non-.go file that was named explicitly."""
    # CATCHES: the -l listing follows the explicit-argument rule, not the .go
    # suffix filter used while walking directories.
    write(tmp_path / "snippet.txt", BAD)
    res = run_gofumpt(["-l", "snippet.txt"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"snippet.txt\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "arg,listed",
    [
        ("./a.go", b"a.go\n"),
        ("a.go", b"a.go\n"),
        ("sub/../a.go", b"a.go\n"),
        ("sub//a.go", b"sub/a.go\n"),
    ],
)
def test_list_prints_cleaned_paths(tmp_path, arg, listed):
    """The listed path is the filepath.Clean-ed argument."""
    # CATCHES: `./a.go` and `sub/../a.go` must be listed as `a.go`, so a
    # consumer comparing the listing against its own path list still matches.
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "sub" / "a.go", BAD)
    res = run_gofumpt(["-l", arg], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == listed
    assert res.stderr == b""


def test_list_absolute_path_is_kept_absolute(tmp_path):
    """An absolute argument is listed unchanged as an absolute path."""
    # CATCHES: cleaning must not relativize an absolute argument; the listing
    # keeps the exact absolute form the user passed.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-l", str(tmp_path / "a.go")], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == str(tmp_path / "a.go").encode() + b"\n"
    assert res.stderr == b""


def test_list_detects_missing_final_newline(tmp_path):
    """A file that only lacks the final newline is still 'differing'."""
    # CATCHES: -l compares bytes, not tokens, so a one-byte newline difference
    # counts as needing formatting.
    write(tmp_path / "a.go", b"package p\n\nvar x = 1")
    res = run_gofumpt(["-l", "a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"a.go\n"
    assert res.stderr == b""


def test_list_many_files_stays_ordered(tmp_path):
    """300 files are listed in exact walk order despite concurrency."""
    # CATCHES: the sequencer must keep the reporter output deterministic even
    # when hundreds of files are formatted concurrently.
    names = []
    for i in range(300):
        name = "f%03d.go" % i
        names.append(name)
        write(tmp_path / "many" / name, BAD.replace(b"f()", b"f%d()" % i))
    res = run_gofumpt(["-l", "many"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"".join(b"many/" + n.encode() + b"\n" for n in names)
