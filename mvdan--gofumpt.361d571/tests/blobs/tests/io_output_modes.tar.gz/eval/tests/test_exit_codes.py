"""Exit codes and the flag-level errors that produce them.

These pin the exit-status contract (0 success, 1 only for -d differences,
2 for any other reported error) plus the deprecated/unknown flag messages,
which are the only diagnostics gofumpt prints before any file is read.
"""

import pytest

from conftest import run_gofumpt, write

BAD = b"package p\n\nfunc  f() {\nx:=1\n}\n"
FORMATTED = b"package p\n\nfunc f() {\n\tx := 1\n}\n"

USAGE = (
    b"usage: gofumpt [flags] [path ...]\n"
    b"\t-version  show version and exit\n"
    b"\n"
    b"\t-d        display diffs instead of rewriting files\n"
    b"\t-e        report all errors (not just the first 10 on different lines)\n"
    b"\t-l        list files whose formatting differs from gofumpt's\n"
    b"\t-w        write result to (source) file instead of stdout\n"
    b"\t-extra    enable extra rules, e.g. -extra=group_params,clothe_returns\n"
    b"\n"
    b'\t-lang       str    target Go version in the form "go1.X" '
    b"(default from go.mod)\n"
    b"\t-modpath    str    Go module path containing the source file "
    b"(default from go.mod)\n"
)


DIFF_A = (
    b"diff a.go.orig a.go\n"
    b"--- a.go.orig\n"
    b"+++ a.go\n"
    b"@@ -1,5 +1,5 @@\n"
    b" package p\n"
    b" \n"
    b"-func  f() {\n"
    b"-x:=1\n"
    b"+func f() {\n"
    b"+\tx := 1\n"
    b" }\n"
)


@pytest.mark.parametrize(
    "args,exit_code,stdout",
    [
        pytest.param([], 0, FORMATTED, id="default"),
        pytest.param(["-l"], 0, b"a.go\n", id="list"),
        pytest.param(["-w"], 0, b"", id="write"),
        pytest.param(["-d"], 1, DIFF_A, id="diff"),
        pytest.param(["-l", "-w"], 0, b"a.go\n", id="list+write"),
        pytest.param(["-l", "-d"], 1, b"a.go\n" + DIFF_A, id="list+diff"),
    ],
)
def test_exit_code_matrix(tmp_path, args, exit_code, stdout):
    """Each mode combination maps to its exit status and stdout shape."""
    # CATCHES: only -d turns formatting differences into a nonzero status;
    # -l and -w report the same differences with status 0, and the modes
    # combine by concatenating their outputs.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt([*args, "a.go"], cwd=tmp_path)
    assert res.returncode == exit_code
    assert res.stderr == b""
    assert res.stdout == stdout
    # Whatever the status, -w actually rewrote the file when given.
    assert (tmp_path / "a.go").read_bytes() == (
        FORMATTED if "-w" in args else BAD
    )


def test_exit_two_for_parse_error(tmp_path):
    """A syntax error exits 2 and writes nothing to stdout."""
    # CATCHES: parse failures use the generic error status 2, never -d's 1.
    write(tmp_path / "a.go", b"package p\nfunc {\n")
    res = run_gofumpt(["-d", "a.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"a.go:2:6: expected 'IDENT', found '{'\n"


def test_exit_two_for_missing_file(tmp_path):
    """A path that does not exist is an error with status 2."""
    # CATCHES: the walk fails before any formatting happens, and the stat
    # failure is reported on stderr with the exact lstat wording.
    res = run_gofumpt(["missing.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"lstat missing.go: no such file or directory\n"


def test_deprecated_s_flag_only_warns(tmp_path):
    """-s prints a deprecation warning and still formats normally."""
    # CATCHES: -s is accepted for gofmt compatibility, does not fail, and the
    # formatted bytes still reach stdout with exit 0.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-s", "a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b"warning: -s is deprecated as it is always enabled\n"


def test_rewrite_flag_is_rejected(tmp_path):
    """-r is refused with a pointer to gofmt and exit status 2."""
    # CATCHES: the message names the replacement command, and no formatting
    # happens at all even though a valid file was given.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-r=p", "a.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b'the rewrite flag is no longer available; use "gofmt -r" instead\n'
    )
    assert (tmp_path / "a.go").read_bytes() == BAD


def test_unknown_flag_prints_usage(tmp_path):
    """An undefined flag reports itself and the usage text, exiting 2."""
    # CATCHES: the Go flag package's diagnostic is followed by the full usage
    # block on stderr, and stdout stays empty.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-z", "a.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"flag provided but not defined: -z\n" + USAGE


def test_flag_missing_value_prints_usage(tmp_path):
    """A value flag given without its value reports the flag and usage."""
    # CATCHES: -lang needs an argument; the run dies with status 2 before any
    # file is read.
    res = run_gofumpt(["-lang"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"flag needs an argument: -lang\n" + USAGE


@pytest.mark.parametrize("flag", ["-h", "-help"])
def test_help_flag_prints_usage_and_exits_zero(tmp_path, flag):
    """-h/-help print the usage to stderr and exit 0."""
    # CATCHES: asking for help is not an error, so the status is 0 even though
    # the text lands on stderr like the other diagnostics.
    res = run_gofumpt([flag], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == USAGE


def test_flag_after_paths_is_a_path(tmp_path):
    """Flags after the first path argument are treated as paths."""
    # CATCHES: gofumpt uses the standard flag parser, which stops at the first
    # non-flag argument, so `-d` after a file name is stat'ed as a file.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["a.go", "-d"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == FORMATTED
    assert res.stderr == (
        b"lstat -d: no such file or directory\n"
    )
