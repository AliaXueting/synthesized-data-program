"""Node-printing decisions made through the vendored go/format engine.

The gofumpt rules do not guess how the printer will lay a construct out:
they re-print candidate nodes through the vendored go/format format.Node
(the same shared printer configuration that renders the final file) and
measure or compare the bytes - printing a case clause through a byte
counter to decide whether it fits on one line, printing specs, types and
conditions to test for a single line, printing function types to compare
adjacent fields, and printing whole declarations to decide blank-line
separation.  These tests pin the observable decisions that engine makes.
"""

import pytest

from conftest import write, run_gofumpt


def fmt_file(tmp_path, src, args=()):
    """Write src.go, run gofumpt on it and return the completed process."""
    write(tmp_path / "src.go", src)
    return run_gofumpt([*args, "src.go"], cwd=tmp_path)


def test_short_case_clause_is_collapsed(tmp_path):
    """A case keyword and its list on separate lines are joined."""
    # CATCHES: the engine prints the clause without its body through the
    # byte counter and collapses the lines when the result fits, so "case"
    # alone on a line with the list below becomes a single "case 1:" line.
    src = "package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase\n\t1:\n\t\t_ = x\n\t}\n}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f(x int) {\n\tswitch x {\n\tcase 1:\n\t\t_ = x\n\t}\n}\n"


def test_long_case_clause_is_not_collapsed(tmp_path):
    """A case line too long for the engine keeps its line split."""
    # CATCHES: the same measurement refuses to join once the printed clause
    # exceeds the short-line budget (plus the indentation estimate), so a
    # long list stays on its own line under the case keyword.
    idents = "veryLongIdentifierNumberOne, veryLongIdentifierNumberTwo"
    src = f"package p\n\nfunc f(x int) {{\n\tswitch x {{\n\tcase\n\t{idents}:\n\t\t_ = x\n\t}}\n}}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        f"package p\n\nfunc f(x int) {{\n\tswitch x {{\n\tcase\n\t\t{idents}:\n\t\t_ = x\n\t}}\n}}\n"
    ).encode()


def test_multiline_lone_var_decl_is_joined(tmp_path):
    """A lone var declaration spread over lines is printed on one line."""
    # CATCHES: the spec is printed on its own to test whether the printer
    # would put it on a single line (the declaration's own keyword lines
    # are ignored), and it is, so the source lines are removed.
    res = fmt_file(tmp_path, "package p\n\nvar\nx =\n1\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar x = 1\n"


def test_empty_struct_type_is_printed_on_one_line(tmp_path):
    """An empty struct spanning lines collapses to inline braces."""
    # CATCHES: after the empty braces are joined onto one line the engine
    # prints the bare type to confirm the printer renders it as
    # "struct{}", and only then are the source lines removed.
    res = fmt_file(tmp_path, "package p\n\ntype T struct {\n}\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\ntype T struct{}\n"


def test_empty_interface_type_is_printed_on_one_line(tmp_path):
    """An empty interface collapses to inline braces the same way."""
    # CATCHES: the one-line check runs for interface types too, not just
    # structs, so "interface {}" spanning two lines becomes "interface{}".
    res = fmt_file(tmp_path, "package p\n\ntype I interface {\n}\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\ntype I interface{}\n"


def test_if_condition_lines_are_joined(tmp_path):
    """A condition broken across lines is joined when it prints on one."""
    # CATCHES: the engine prints the condition expression itself; "!x"
    # fits on one line, so the newline between "!" and "x" is dropped.
    src = "package p\n\nfunc f(x bool) {\n\tif !\nx {\n\t\t_ = x\n\t}\n}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f(x bool) {\n\tif !x {\n\t\t_ = x\n\t}\n}\n"


def test_adjacent_multiline_decls_are_blank_separated(tmp_path):
    """Two multi-line declarations gain a blank line between them."""
    # CATCHES: each declaration is printed to decide whether it is
    # "multi"; two adjacent multi-line ones are separated by a blank line,
    # which a printer that never re-prints nodes would leave adjacent.
    src = "package p\n\nvar (\n\taaa = 1\n\tbbb = 2\n)\nvar (\n\tccc = 3\n\tddd = 4\n)\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"package p\n\nvar (\n\taaa = 1\n\tbbb = 2\n)\n\nvar (\n\tccc = 3\n\tddd = 4\n)\n"
    )


@pytest.mark.parametrize(
    "src,expected",
    [
        pytest.param(
            "package p\n\nfunc f(a int, b int) {}\n",
            b"package p\n\nfunc f(a, b int) {}\n",
            id="ident-types",
        ),
        pytest.param(
            "package p\n\nfunc g(a func(int) error, b func(int) error) {}\n",
            b"package p\n\nfunc g(a, b func(int) error) {}\n",
            id="func-types",
        ),
        pytest.param(
            "package p\n\nfunc g(a int, b int, c string) {}\n",
            b"package p\n\nfunc g(a, b int, c string) {}\n",
            id="merge-stops-at-different-type",
        ),
    ],
)
def test_extra_param_merging_prints_and_compares_types(tmp_path, src, expected):
    """-extra merges same-line params only when their printed types match."""
    # CATCHES: adjacent parameters merge only when the engine prints both
    # types and the bytes are equal - "a int, b int" becomes "a, b int" and
    # so do two func literals of equal shape, while a trailing string param
    # with different bytes stops the merge.
    res = fmt_file(tmp_path, src, args=["-extra"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected
