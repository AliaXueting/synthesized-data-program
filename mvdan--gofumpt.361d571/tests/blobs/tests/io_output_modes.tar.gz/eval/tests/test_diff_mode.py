"""The -d mode: a unified diff on stdout and a failing exit status.

These pin the exact bytes of the anchored diff gofumpt prints (headers with
the `.orig` suffix, hunk headers, the no-newline marker), that unchanged
files produce no output, and that any difference makes the process exit 1.
"""

import pytest

from conftest import run_gofumpt, write

BAD = b"package p\n\nfunc  f() {\nx:=1\n}\n"
FORMATTED = b"package p\n\nfunc f() {\n\tx := 1\n}\n"
GOOD = b"package p\n\nfunc g() {\n\ty := 2\n}\n"

DIFF_A = (
    b"diff a.go.orig a.go\n"
    b"--- a.go.orig\n"
    b"+++ a.go\n"
    b"@@ -1,5 +1,5 @@\n"
    b" package p\n"
    b" \n"
    b"-func  f() {\n"
    b"-x:=1\n"
    b"+func f() {\n"
    b"+\tx := 1\n"
    b" }\n"
)


def test_diff_bytes_and_exit_status(tmp_path):
    """-d prints the unified diff of one changed file and exits 1."""
    # CATCHES: the whole stdout must match the anchored diff byte for byte,
    # including the leading `diff old new` line and the exit status 1 that
    # makes `gofumpt -d` usable as a CI check.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-d", "a.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == DIFF_A
    assert res.stderr == b""
    assert (tmp_path / "a.go").read_bytes() == BAD


def test_diff_of_formatted_file_is_empty(tmp_path):
    """-d prints nothing at all for a clean file in a mixed run."""
    # CATCHES: no headers, no hunks and no blank separator for the formatted
    # file, so the output starts directly with the dirty file's diff.
    write(tmp_path / "clean.go", GOOD)
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-d", "clean.go", "a.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == DIFF_A
    assert res.stderr == b""


def test_diff_headers_use_path_plus_orig(tmp_path):
    """The headers name the walked path with an `.orig` suffix."""
    # CATCHES: the old side is `<path>.orig` and the new side is `<path>`,
    # keeping the prefix directory the file was found under.
    write(tmp_path / "sub" / "a.go", BAD)
    res = run_gofumpt(["-d", "sub/a.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout.startswith(
        b"diff sub/a.go.orig sub/a.go\n--- sub/a.go.orig\n+++ sub/a.go\n"
    )
    assert res.stderr == b""


def test_diff_two_hunks(tmp_path):
    """Two distant changes produce two hunks with 3 context lines each."""
    # CATCHES: the vendored diff engine emits standard `@@ -a,b +c,d @@`
    # headers and clamps context at chunk boundaries.
    middle = b"".join(b"\tcall%d()\n" % i for i in range(12))
    write(
        tmp_path / "two.go",
        b"package p\n\nfunc f() {\n\tx :=  1\n" + middle + b"\ty  :=  2\n}\n",
    )
    res = run_gofumpt(["-d", "two.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == (
        b"diff two.go.orig two.go\n"
        b"--- two.go.orig\n"
        b"+++ two.go\n"
        b"@@ -1,7 +1,7 @@\n"
        b" package p\n"
        b" \n"
        b" func f() {\n"
        b"-\tx :=  1\n"
        b"+\tx := 1\n"
        b" \tcall0()\n"
        b" \tcall1()\n"
        b" \tcall2()\n"
        b"@@ -14,5 +14,5 @@\n"
        b" \tcall9()\n"
        b" \tcall10()\n"
        b" \tcall11()\n"
        b"-\ty  :=  2\n"
        b"+\ty := 2\n"
        b" }\n"
    )


def test_diff_marks_missing_final_newline(tmp_path):
    """A file without a final newline gets the `\\ No newline` marker."""
    # CATCHES: the diff must flag the missing newline on the old side rather
    # than showing it as an ordinary line change.
    write(tmp_path / "a.go", b"package p\n\nvar x = 1")
    res = run_gofumpt(["-d", "a.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == (
        b"diff a.go.orig a.go\n"
        b"--- a.go.orig\n"
        b"+++ a.go\n"
        b"@@ -1,3 +1,3 @@\n"
        b" package p\n"
        b" \n"
        b"-var x = 1\n"
        b"\\ No newline at end of file\n"
        b"+var x = 1\n"
    )


DIFF_B = (
    b"diff b.go.orig b.go\n"
    b"--- b.go.orig\n"
    b"+++ b.go\n"
    b"@@ -1,5 +1,5 @@\n"
    b" package p\n"
    b" \n"
    b"-func  g() {\n"
    b"-x:=1\n"
    b"+func g() {\n"
    b"+\tx := 1\n"
    b" }\n"
)


def test_diff_multiple_files_are_concatenated(tmp_path):
    """Diffs for several files follow each other in argument order."""
    # CATCHES: only the differing files contribute a diff, and the chunks are
    # concatenated in the order the files were named.
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "good.go", GOOD)
    write(tmp_path / "b.go", b"package p\n\nfunc  g() {\nx:=1\n}\n")
    res = run_gofumpt(["-d", "a.go", "good.go", "b.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == DIFF_A + DIFF_B


def test_diff_with_list_combines(tmp_path):
    """-l -d lists the path and then prints its diff, exiting 1."""
    # CATCHES: the modes combine, so the path line precedes the diff for each
    # differing file and the exit status is -d's 1, not -l's 0.
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "good.go", GOOD)
    res = run_gofumpt(["-l", "-d", "a.go", "good.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == b"a.go\n" + DIFF_A


def test_diff_with_write_writes_and_exits_one(tmp_path):
    """-w -d rewrites the file and still exits 1 because of the difference."""
    # CATCHES: -w does not soften -d's failing exit status, and the diff still
    # shows the pre-write contents as the old side.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["-w", "-d", "a.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == DIFF_A
    assert res.stderr == b""
    assert (tmp_path / "a.go").read_bytes() == FORMATTED


def test_diff_directory_lists_only_differing_files(tmp_path):
    """-d over a directory diffs only the files that need formatting."""
    # CATCHES: walking produces one diff per unformatted .go file, in walk
    # order, and skips formatted and non-Go files entirely.
    write(tmp_path / "tree" / "a.go", BAD)
    write(tmp_path / "tree" / "good.go", GOOD)
    write(tmp_path / "tree" / "notes.txt", BAD)
    res = run_gofumpt(["-d", "tree"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == DIFF_A.replace(b"a.go", b"tree/a.go")


def test_diff_stdin_headers(tmp_path):
    """-d with stdin uses the `<standard input>` pseudo-path in the headers."""
    # CATCHES: the diff headers are derived from the same placeholder name the
    # -l listing and error messages use.
    res = run_gofumpt(["-d"], input=b"var  x  =  1\n", cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == (
        b"diff <standard input>.orig <standard input>\n"
        b"--- <standard input>.orig\n"
        b"+++ <standard input>\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-var  x  =  1\n"
        b"+var x = 1\n"
    )


def test_diff_stdin_formatted_prints_nothing(tmp_path):
    """-d with formatted stdin prints nothing; a change still diffs."""
    # CATCHES: a fragment that formats to itself produces no diff output at
    # all, while a changed fragment still gets the pseudo-name headers.
    clean = run_gofumpt(["-d"], input=b"var x = 1\n", cwd=tmp_path)
    assert clean.returncode == 0
    assert clean.stdout == b""
    assert clean.stderr == b""
    dirty = run_gofumpt(["-d"], input=b"var  x  =  1\n", cwd=tmp_path)
    assert dirty.returncode == 1
    assert dirty.stdout == (
        b"diff <standard input>.orig <standard input>\n"
        b"--- <standard input>.orig\n"
        b"+++ <standard input>\n"
        b"@@ -1,1 +1,1 @@\n"
        b"-var  x  =  1\n"
        b"+var x = 1\n"
    )
    assert dirty.stderr == b""


def test_diff_collapses_repeated_blank_lines(tmp_path):
    """The anchored diff removes each dropped blank line as its own line."""
    # CATCHES: gofumpt collapses the run of blank lines to one, and the diff
    # must show all four removed lines rather than reusing blank lines to
    # minimize the hunk, which is what the anchored algorithm guarantees.
    write(tmp_path / "blank.go", b"package p\n\n\n\n\nvar x =  1\n")
    res = run_gofumpt(["-d", "blank.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == (
        b"diff blank.go.orig blank.go\n"
        b"--- blank.go.orig\n"
        b"+++ blank.go\n"
        b"@@ -1,6 +1,3 @@\n"
        b" package p\n"
        b" \n"
        b"-\n"
        b"-\n"
        b"-\n"
        b"-var x =  1\n"
        b"+var x = 1\n"
    )


def test_diff_anchors_on_unique_context(tmp_path):
    """A change inside one of two similar functions anchors on its header."""
    # CATCHES: the diff must pick the `func b()` context lines, so the change
    # is reported inside the second function instead of drifting into the
    # identical first one.
    src = b"package p\n\nfunc a() {\n\tx := 1\n}\n\nfunc b() {\n\tx :=  2\n}\n"
    write(tmp_path / "dup.go", src)
    res = run_gofumpt(["-d", "dup.go"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b""
    assert res.stdout == (
        b"diff dup.go.orig dup.go\n"
        b"--- dup.go.orig\n"
        b"+++ dup.go\n"
        b"@@ -5,5 +5,5 @@\n"
        b" }\n"
        b" \n"
        b" func b() {\n"
        b"-\tx :=  2\n"
        b"+\tx := 2\n"
        b" }\n"
    )


@pytest.mark.parametrize(
    "order,expected_exit",
    [
        (["bad.go", "diffme.go"], 1),
        (["diffme.go", "bad.go"], 2),
    ],
)
def test_diff_exit_code_is_last_reported(tmp_path, order, expected_exit):
    """A later report wins: a diff after an error gives 1, the reverse gives 2."""
    # CATCHES: the exit code is a single slot that the last reported error
    # overwrites, so the ordering of files decides between 1 and 2.
    write(tmp_path / "bad.go", b"package p\nfunc {\n")
    write(tmp_path / "diffme.go", BAD)
    res = run_gofumpt(["-d", *order], cwd=tmp_path)
    assert res.returncode == expected_exit
    assert res.stderr == b"bad.go:2:6: expected 'IDENT', found '{'\n"
    # The diff is printed in both orders, before the error line on stderr.
    assert res.stdout == DIFF_A.replace(b"a.go", b"diffme.go")
