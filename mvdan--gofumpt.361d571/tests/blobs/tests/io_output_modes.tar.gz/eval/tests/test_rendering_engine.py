"""The rendering engine: the vendored go/printer and go/format output.

The printer is configured with tab indentation (width 8) plus spaces for
alignment and number normalization, so the printed bytes - not just the AST -
are part of the contract.  These pin the observable rendering decisions,
including the number-literal canonicalization the frozen printer performs.
"""

import pytest

from conftest import run_gofumpt, write


def fmt_file(tmp_path, src, args=()):
    """Write src.go, run gofumpt on it and return the completed process."""
    write(tmp_path / "src.go", src)
    return run_gofumpt([*args, "src.go"], cwd=tmp_path)


@pytest.mark.parametrize(
    "literal,expected",
    [
        # hex float: prefix and exponent lowercased
        pytest.param(b"0X1P-2", b"0x1p-2", id="hex-float"),
        pytest.param(b"0X1P+2", b"0x1p+2", id="hex-float-plus"),
        pytest.param(b"0B101", b"0b101", id="binary"),
        pytest.param(b"0O17", b"0o17", id="octal"),
        pytest.param(b"1E9", b"1e9", id="decimal-exponent"),
        pytest.param(b".5E-3", b".5e-3", id="fraction-exponent"),
        pytest.param(b"0xABCDEF", b"0xABCDEF", id="hex-digits-kept"),
        pytest.param(b"1_000_000", b"1_000_000", id="separators-kept"),
        pytest.param(b"0765i", b"765i", id="imaginary-leading-zeros"),
        pytest.param(b"0.5i", b"0.5i", id="imaginary-float"),
    ],
)
def test_number_literals_are_normalized(tmp_path, literal, expected):
    """The printer canonicalizes number prefixes and exponents."""
    # CATCHES: the vendored printer normalizes 0X/0B/0O/1E forms while
    # printing regardless of the language version, so the bytes change even
    # though the AST is identical.
    src = b"package p\n\nfunc f() {\n\t_ = " + literal + b"\n}\n"
    res = fmt_file(tmp_path, src, args=["-lang=go1.12"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f() {\n\t_ = " + expected + b"\n}\n"


def test_legacy_octal_is_lang_gated_not_printer(tmp_path):
    """`0775` stays `0775` when the language version predates Go 1.13."""
    # CATCHES: the printer never rewrites legacy 0-prefix octal; that is
    # gofumpt's separate lang-gated rule, so with -lang=go1.12 the digits are
    # untouched even though 0O17 would still become 0o17.
    src = b"package p\n\nfunc f() {\n\t_ = 0775\n\t_ = 0O17\n}\n"
    res = fmt_file(tmp_path, src, args=["-lang=go1.12"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f() {\n\t_ = 0775\n\t_ = 0o17\n}\n"


def test_legacy_octal_is_rewritten_for_modern_lang(tmp_path):
    """With a modern -lang the 0-prefix octal becomes the 0o form."""
    # CATCHES: the same input flips to `0o775` once the language version is
    # go1.13 or newer, which distinguishes the rule from the printer's own
    # normalization.
    src = b"package p\n\nfunc f() {\n\t_ = 0775\n}\n"
    res = fmt_file(tmp_path, src, args=["-lang=go1.13"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nfunc f() {\n\t_ = 0o775\n}\n"


def test_tabs_indent_and_spaces_align(tmp_path):
    """Indentation uses tabs while columns are aligned with spaces."""
    # CATCHES: the printer's TabIndent|UseSpaces configuration means each
    # field line starts with a tab and the types are padded with spaces to a
    # common column, not with more tabs.
    src = b"package p\n\ntype T struct {\nA int\nBB string\nCCC []int\n}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"package p\n\ntype T struct {\n\tA   int\n\tBB  string\n"
        b"\tCCC []int\n}\n"
    )


def test_struct_tags_are_aligned(tmp_path):
    """Struct tags line up in their own space-aligned column."""
    # CATCHES: alignment spans the whole field block, so the tag column is
    # placed after the widest type, padded with spaces.
    src = (
        b"package p\n\ntype T struct {\n"
        b'A int `json:"a"`\n'
        b'BB string `json:"bb"`\n'
        b"}\n"
    )
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"package p\n\ntype T struct {\n"
        b'\tA  int    `json:"a"`\n'
        b'\tBB string `json:"bb"`\n'
        b"}\n"
    )


def test_trailing_comments_are_aligned(tmp_path):
    """Trailing line comments in a block are aligned with spaces."""
    # CATCHES: the comment column is computed from the statements in the
    # block, so both comments end up in the same column.
    src = b"package p\n\nfunc f() {\n\t_ = 1 // one\n\t_ = 22 // two\n}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"package p\n\nfunc f() {\n\t_ = 1  // one\n\t_ = 22 // two\n}\n"
    )


def test_nested_blocks_indent_one_tab_each(tmp_path):
    """Each nesting level adds exactly one tab."""
    # CATCHES: the tab width is 8 for column computation but indentation is a
    # single tab per level, never the expanded spaces.
    src = b"package p\n\nfunc f() {\nif x {\ny()\n}\n}\n"
    res = fmt_file(tmp_path, src)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"package p\n\nfunc f() {\n\tif x {\n\t\ty()\n\t}\n}\n"
    )


def test_crlf_line_endings_become_lf(tmp_path):
    """CRLF line endings are normalized to plain LF in the output."""
    # CATCHES: the printer emits LF only, so a CRLF file is reported as
    # differing and prints back with Unix endings.
    write(tmp_path / "crlf.go", b"package p\r\nvar x=1\r\n")
    res = run_gofumpt(["crlf.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar x = 1\n"


def test_utf8_bom_is_stripped(tmp_path):
    """A UTF-8 byte order mark is dropped from the output."""
    # CATCHES: the scanner consumes the BOM as whitespace, so the formatted
    # bytes do not start with it anymore.
    write(tmp_path / "bom.go", b"\xef\xbb\xbfpackage p\nvar x=1\n")
    res = run_gofumpt(["bom.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"package p\n\nvar x = 1\n"


def test_output_is_idempotent(tmp_path):
    """Feeding gofumpt's own output back produces the same bytes."""
    # CATCHES: the renderer must be a fixed point - a second pass over the
    # result changes nothing, and the first pass really did produce the
    # normalized form rather than echoing the input.
    src = b"package p\n\nfunc  f() {\nx:=1\n_ = 0X1P-2\n}\n"
    expected = b"package p\n\nfunc f() {\n\tx := 1\n\t_ = 0x1p-2\n}\n"
    write(tmp_path / "a.go", src)
    first = run_gofumpt(["a.go"], cwd=tmp_path)
    assert first.returncode == 0
    assert first.stdout == expected
    second = run_gofumpt([], input=first.stdout, cwd=tmp_path)
    assert second.returncode == 0
    assert second.stderr == b""
    assert second.stdout == expected


def test_stdin_fragment_renders_with_same_engine(tmp_path):
    """A fragment is rendered by the same printer as a whole file."""
    # CATCHES: the wrapped fragment goes through the identical printer config,
    # so tabs, alignment and number normalization all apply to stdin too.
    res = run_gofumpt([], input=b"_ = 0X1P-2\n", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"_ = 0x1p-2\n"
