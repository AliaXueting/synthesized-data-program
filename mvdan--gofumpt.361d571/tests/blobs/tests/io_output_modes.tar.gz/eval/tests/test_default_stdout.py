"""Default output mode: the formatted bytes always go to stdout.

These pin where gofumpt's result goes when none of -l/-w/-d is given: the
formatted source is printed for every processed file, changed or not, and
with several files the outputs concatenate in argument (or walk) order.
"""

import pytest

from conftest import run_gofumpt, write

# An unformatted file: two gofmt-level problems (double space, missing tabs).
BAD = b"package p\n\nfunc  f() {\nx:=1\n}\n"
# The same file after gofumpt has formatted it.
FORMATTED = b"package p\n\nfunc f() {\n\tx := 1\n}\n"
# A second unformatted file, so multi-file ordering is observable.
BAD2 = b"package p\n\nfunc  g() {\ny:=2\n}\n"
FORMATTED2 = b"package p\n\nfunc g() {\n\ty := 2\n}\n"


def test_changed_file_is_printed_to_stdout(tmp_path):
    """A reformatted file's new bytes are written to stdout, exit 0."""
    # CATCHES: default mode must print the *formatted* result, never echo the
    # original bytes, and must not touch the file on disk.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b""
    assert (tmp_path / "a.go").read_bytes() == BAD


def test_unchanged_file_is_still_printed(tmp_path):
    """An already-formatted file is echoed to stdout, not skipped."""
    # CATCHES: unlike -l/-d, default mode always emits the formatted bytes,
    # even when gofumpt made no change at all.
    write(tmp_path / "a.go", FORMATTED)
    res = run_gofumpt(["a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b""


def test_package_only_file_round_trips(tmp_path):
    """A minimal but complete file prints exactly its own bytes."""
    # CATCHES: the smallest valid file must round-trip byte for byte, with no
    # extra blank line or missing trailing newline added by the printer.
    src = b"package p\n"
    write(tmp_path / "a.go", src)
    res = run_gofumpt(["a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == src
    assert res.stderr == b""


@pytest.mark.parametrize("order", [["a.go", "b.go"], ["b.go", "a.go"]])
def test_outputs_concatenate_in_argument_order(tmp_path, order):
    """Several files concatenate on stdout in the order they were named."""
    # CATCHES: the reporter must serialize the concurrent per-file tasks in
    # argument order, not in completion or lexical order.
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "b.go", BAD2)
    res = run_gofumpt(order, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    if order[0] == "a.go":
        assert res.stdout == FORMATTED + FORMATTED2
    else:
        assert res.stdout == FORMATTED2 + FORMATTED


def test_directory_walk_output_is_lexical(tmp_path):
    """A directory argument prints every .go file in walk order."""
    # CATCHES: walking is lexical and depth-first, so sub/d.go comes before
    # sub/deeper/f.go and both before sub/e.go.
    write(tmp_path / "b.go", BAD2)
    write(tmp_path / "a.go", BAD)
    write(tmp_path / "notgo.txt", BAD)
    write(tmp_path / "sub" / "d.go", BAD)
    write(tmp_path / "sub" / "deeper" / "f.go", BAD2)
    write(tmp_path / "sub" / "e.go", BAD)
    res = run_gofumpt(["."], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    # a.go, b.go, then sub/d.go, sub/deeper/f.go, sub/e.go
    assert res.stdout == (
        FORMATTED + FORMATTED2 + FORMATTED + FORMATTED2 + FORMATTED
    )


def test_repeated_argument_is_printed_twice(tmp_path):
    """Naming the same file twice prints its output twice."""
    # CATCHES: there is no de-duplication of path arguments; each walk entry
    # becomes its own output chunk.
    write(tmp_path / "a.go", BAD)
    res = run_gofumpt(["a.go", "a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED + FORMATTED
    assert res.stderr == b""


def test_explicit_non_go_file_is_formatted(tmp_path):
    """A non-.go file named explicitly is still formatted as Go."""
    # CATCHES: only *walked* files are filtered by the .go suffix; an explicit
    # argument is always treated as Go source.
    write(tmp_path / "script.txt", BAD)
    res = run_gofumpt(["script.txt"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b""


def test_missing_trailing_newline_is_added(tmp_path):
    """A file without a final newline gets one when printed."""
    # CATCHES: the printer always terminates the last line, so the output is
    # one byte longer than a naive echo of the source.
    write(tmp_path / "a.go", b"package p\nvar x=1")
    res = run_gofumpt(["a.go"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"package p\n\nvar x = 1\n"
    assert res.stderr == b""


def test_stdout_still_prints_good_files_when_one_fails(tmp_path):
    """A parse error in one file does not suppress the others' stdout."""
    # CATCHES: the error only goes to stderr and flips the exit code to 2; the
    # successfully formatted files are still printed, in argument order.
    write(tmp_path / "good1.go", BAD)
    write(tmp_path / "bad.go", b"package p\nfunc {\n")
    write(tmp_path / "good2.go", BAD2)
    res = run_gofumpt(["good1.go", "bad.go", "good2.go"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stdout == FORMATTED + FORMATTED2
    assert res.stderr == b"bad.go:2:6: expected 'IDENT', found '{'\n"


def test_empty_stdin_prints_nothing(tmp_path):
    """Empty stdin formats to nothing, while whitespace-only stdin echoes."""
    # CATCHES: an empty fragment is not an error (no bytes, exit 0), and a
    # fragment that is only whitespace is echoed unchanged rather than
    # trimmed - the two cases must not be confused.
    empty = run_gofumpt([], input=b"", cwd=tmp_path)
    assert empty.returncode == 0
    assert empty.stdout == b""
    assert empty.stderr == b""
    spaces = run_gofumpt([], input=b"   \n", cwd=tmp_path)
    assert spaces.returncode == 0
    assert spaces.stdout == b"   \n"
    assert spaces.stderr == b""


def test_stdin_whole_file(tmp_path):
    """A complete Go file piped through stdin is formatted like a file."""
    # CATCHES: with no path arguments gofumpt reads stdin and writes the
    # formatted result to stdout with no filename decoration.
    res = run_gofumpt([], input=BAD, cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == FORMATTED
    assert res.stderr == b""
