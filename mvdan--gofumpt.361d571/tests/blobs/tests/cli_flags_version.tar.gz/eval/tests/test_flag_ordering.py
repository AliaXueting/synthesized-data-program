"""Argument parsing order: flags before paths, `--`, and the stdin fallback."""

MESSY_SOURCE = "package p\nfunc  f( ) {\nx:=1\n_ = x\n}\n"
MESSY_FORMATTED = "package p\n\nfunc f() {\n\tx := 1\n\t_ = x\n}\n"


def test_flag_after_a_path_is_treated_as_a_path(run_gofumpt, tmp_path):
    """The first non-flag argument ends flag parsing, so a later -extra is a path."""
    # CATCHES: `gofumpt file.go -extra` formats file.go and then fails walking
    # the literal path `-extra`; it must not apply the extra rules.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt(path.name, "-extra")
    assert result.returncode == 2
    assert result.out == MESSY_FORMATTED
    assert result.err == "lstat -extra: no such file or directory\n"


def test_flag_after_a_path_does_not_change_formatting(run_gofumpt, tmp_path):
    """A `-l` appearing after a path is a path, not the list flag."""
    # CATCHES: the same rule for every flag spelling: a trailing `-l` must not
    # switch the run into list mode and must not suppress stdout.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt(path.name, "-l")
    assert result.returncode == 2
    assert result.out == MESSY_FORMATTED
    assert result.err == "lstat -l: no such file or directory\n"


def test_double_dash_terminates_flag_parsing(run_gofumpt, tmp_path):
    """`gofumpt -- file.go` formats the file named after the terminator."""
    # CATCHES: `--` ends the flag list, so the following argument is a path
    # even though it is not a flag at all.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("--", path.name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == MESSY_FORMATTED


def test_flags_before_double_dash_still_apply(run_gofumpt, tmp_path):
    """`-extra=true -- file.go` applies the flag and then treats the rest as paths."""
    # CATCHES: the terminator only stops parsing; earlier flags keep their
    # effect on the files named after it.
    source = "package p\n\nfunc f(a int, b int) {}\n"
    path = tmp_path / "params.go"
    path.write_text(source)
    result = run_gofumpt("-extra=true", "--", path.name)
    assert result.returncode == 0
    assert result.out == "package p\n\nfunc f(a, b int) {}\n"


def test_double_dash_makes_a_flag_shaped_argument_a_path(run_gofumpt):
    """`gofumpt -- -version` does not print the version: -version is a path."""
    # CATCHES: after `--` nothing is a flag anymore, so the program tries to
    # walk the literal file `-version` and fails with exit 2.
    result = run_gofumpt("--", "-version")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "lstat -version: no such file or directory\n"


def test_lone_dash_is_a_path(run_gofumpt):
    """A single `-` argument is a path, not a flag and not stdin."""
    # CATCHES: unlike many Unix tools, gofumpt does not use `-` for stdin; it
    # walks it as a filename and reports the lstat failure.
    result = run_gofumpt("-")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "lstat -: no such file or directory\n"


def test_string_flag_value_may_look_like_a_flag(run_gofumpt):
    """`-lang -version` consumes `-version` as the value, then panics on it."""
    # CATCHES: a string flag swallows the next argv element blindly, so the
    # program ends up with an invalid language version and panics on stdin.
    result = run_gofumpt("-lang", "-version")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err.startswith('panic: invalid Go version: "-version"')


def test_multiple_paths_are_all_formatted_in_order(run_gofumpt, tmp_path):
    """Several path arguments are formatted one after another onto stdout."""
    # CATCHES: every argument is walked and printed in argument order with no
    # separator added between the formatted files.
    first = tmp_path / "a.go"
    second = tmp_path / "b.go"
    first.write_text("package p\nvar a = 1\n")
    second.write_text("package q\nvar b = 2\n")
    result = run_gofumpt(first.name, second.name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\nvar a = 1\npackage q\n\nvar b = 2\n"


def test_missing_path_is_an_lstat_error(run_gofumpt):
    """A nonexistent path is reported as an lstat error with exit 2."""
    # CATCHES: the message names the argument verbatim and uses the lstat
    # syscall error wording, with nothing on stdout.
    result = run_gofumpt("nosuchfile.go")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "lstat nosuchfile.go: no such file or directory\n"


def test_missing_directory_is_an_lstat_error(run_gofumpt):
    """A nonexistent directory argument fails the same way as a missing file."""
    # CATCHES: directories and files go through the same walk, so the error
    # text is identical apart from the argument itself.
    result = run_gofumpt("nosuchdir/sub")
    assert result.returncode == 2
    assert result.err == "lstat nosuchdir/sub: no such file or directory\n"


def test_no_arguments_reads_standard_input(run_gofumpt):
    """With no paths, gofumpt formats the Go source piped on stdin."""
    # CATCHES: the empty-argv case falls back to reading stdin instead of
    # erroring, and writes the formatted source to stdout with exit 0.
    result = run_gofumpt(stdin=b"package p\nfunc  f( ) {\nx:=1\n_ = x\n}\n")
    assert result.returncode == 0
    assert result.stderr == b""
    assert result.out == MESSY_FORMATTED


def test_no_arguments_and_empty_stdin_outputs_nothing(run_gofumpt):
    """Empty stdin with no paths produces empty stdout and exit 0."""
    # CATCHES: an empty stream is not an error; it must not print anything or
    # change the exit status, while the same invocation with real source on
    # stdin still formats it, proving stdin is read rather than ignored.
    result = run_gofumpt(stdin=b"")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    control = run_gofumpt(stdin=b"package p\nfunc  f( ) {\nx:=1\n_ = x\n}\n")
    assert control.returncode == 0
    assert control.stderr == b""
    assert control.out == MESSY_FORMATTED


def test_no_arguments_with_write_flag_is_an_error(run_gofumpt):
    """`gofumpt -w` with no paths refuses to rewrite standard input."""
    # CATCHES: -w is rejected for stdin with the exact error wording and exit
    # status 2, and nothing is read from or written to the streams.
    result = run_gofumpt("-w", stdin=b"package p\n")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "error: cannot use -w with standard input\n"


def test_stdin_accepts_a_statement_fragment(run_gofumpt):
    """A statement list without a package clause is formatted as a fragment."""
    # CATCHES: stdin (unlike files) accepts program fragments, so `x:=1` is
    # reformatted rather than rejected as a parse error.
    result = run_gofumpt(stdin=b"x:=1\n")
    assert result.returncode == 0
    assert result.stderr == b""
    assert result.out == "x := 1\n"


def test_stdin_honours_the_lang_flag(run_gofumpt):
    """`-lang=go1.13` also applies to source read from standard input."""
    # CATCHES: value flags apply to the stdin fallback path exactly as they do
    # to named files, including the octal literal rewrite.
    result = run_gofumpt("-lang=go1.13", stdin=b"package p\n\nvar x = 0777\n")
    assert result.returncode == 0
    assert result.out == "package p\n\nvar x = 0o777\n"


def test_stdin_reports_parse_errors_with_exit_two(run_gofumpt):
    """Invalid Go on stdin is reported on stderr with exit status 2."""
    # CATCHES: the stdin path uses the standard input's pseudo-filename in the
    # error positions, and the exit status is the parse-error status.
    result = run_gofumpt(stdin=b"package p\nfunc (\n")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "<standard input>:2:8: expected ')', found 'EOF'\n"


def test_write_flag_rewrites_the_file_in_place(run_gofumpt, tmp_path):
    """`-w` rewrites the named file and prints nothing to stdout."""
    # CATCHES: the -w flag redirects the formatted output into the file, so
    # stdout stays empty and the on-disk bytes are replaced.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("-w", path.name)
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.err == ""
    assert path.read_text() == MESSY_FORMATTED


def test_list_flag_names_files_that_differ(run_gofumpt, tmp_path):
    """`-l` prints the path of a file whose formatting differs, exit 0."""
    # CATCHES: -l lists rather than prints the source, keeps exit status 0 and
    # stays silent for an already well-formatted file.
    messy = tmp_path / "messy.go"
    clean = tmp_path / "clean.go"
    messy.write_text(MESSY_SOURCE)
    clean.write_text(MESSY_FORMATTED)
    result = run_gofumpt("-l", messy.name, clean.name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == [messy.name]


def test_diff_flag_on_a_clean_file_is_silent_and_exits_zero(run_gofumpt, tmp_path):
    """`-d` prints nothing and exits 0 when the file already matches gofumpt."""
    # CATCHES: the exit-1 status of -d is reserved for real differences, so an
    # already formatted file must produce no diff and no error at all, while
    # the same run over a dirty file does print the diff and exits 1.
    path = tmp_path / "clean.go"
    path.write_text(MESSY_FORMATTED)
    result = run_gofumpt("-d", path.name)
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    dirty = tmp_path / "dirty.go"
    dirty.write_text(MESSY_SOURCE)
    contrast = run_gofumpt("-d", dirty.name)
    assert contrast.returncode == 1
    assert contrast.err == ""
    assert contrast.out == (
        "diff dirty.go.orig dirty.go\n"
        "--- dirty.go.orig\n"
        "+++ dirty.go\n"
        "@@ -1,5 +1,6 @@\n"
        " package p\n"
        "-func  f( ) {\n"
        "-x:=1\n"
        "-_ = x\n"
        "+\n"
        "+func f() {\n"
        "+\tx := 1\n"
        "+\t_ = x\n"
        " }\n"
    )


def test_list_and_write_flags_combine(run_gofumpt, tmp_path):
    """`-l -w` both rewrites the file and lists its name, exiting 0."""
    # CATCHES: -l and -w are independent modes that can be combined; the file
    # is listed on stdout and rewritten on disk in the same run.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("-l", "-w", path.name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == [path.name]
    assert path.read_text() == MESSY_FORMATTED


def test_diff_and_list_flags_combine(run_gofumpt, tmp_path):
    """`-d -l` lists the file first and then prints the diff, exiting 1."""
    # CATCHES: with both output modes requested the filename line comes before
    # the diff on stdout and the exit status is still the -d status of 1.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("-d", "-l", path.name)
    assert result.returncode == 1
    assert result.err == ""
    assert result.out == (
        "messy.go\n"
        "diff messy.go.orig messy.go\n"
        "--- messy.go.orig\n"
        "+++ messy.go\n"
        "@@ -1,5 +1,6 @@\n"
        " package p\n"
        "-func  f( ) {\n"
        "-x:=1\n"
        "-_ = x\n"
        "+\n"
        "+func f() {\n"
        "+\tx := 1\n"
        "+\t_ = x\n"
        " }\n"
    )


def test_diff_flag_exits_one_when_formatting_differs(run_gofumpt, tmp_path):
    """`-d` prints a unified diff and exits 1 when the file needs changes."""
    # CATCHES: gofumpt's -d changes the exit status to 1 (unlike gofmt) while
    # still writing the unified diff to stdout, and adds nothing on stderr.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("-d", path.name)
    assert result.returncode == 1
    assert result.err == ""
    assert result.out == (
        "diff messy.go.orig messy.go\n"
        "--- messy.go.orig\n"
        "+++ messy.go\n"
        "@@ -1,5 +1,6 @@\n"
        " package p\n"
        "-func  f( ) {\n"
        "-x:=1\n"
        "-_ = x\n"
        "+\n"
        "+func f() {\n"
        "+\tx := 1\n"
        "+\t_ = x\n"
        " }\n"
    )
