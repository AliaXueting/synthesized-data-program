"""Round-5 coverage target: internal/govendor/go/format/format.go.

That file's CLI-reachable surface is its ``Node`` entry point with sub-file
nodes, driven by gofumpt's internal probes: "does this node print on one
line?" (struct/interface types anywhere in the tree, lone declaration specs,
if/for conditions, whole declarations), "how many bytes would this node
print as, plus the current brace depth?" (split case clause headers) and
"do these two field types print the same bytes when positions are ignored?"
(-extra=group_params merging).  The tests below pin further CLI-visible
consequences of those probe decisions that the earlier probe test files do
not cover: nested one-line composite types, the lone-import join, call and
selector conditions, the depth-dependent case collapse limit, the default
clause, comment-aware declaration separation, and newline-insensitive type
merging.
"""

import pytest


def write_go(tmp_path, source):
    """Write a Go source file into ``tmp_path`` and return its name."""
    path = tmp_path / "src.go"
    path.write_text(source)
    return path.name


@pytest.mark.parametrize(
    "decl",
    [
        "func f(s struct{ x int }) {}\n",
        "type A = struct{ x int }\n",
    ],
    ids=["param", "alias"],
)
def test_one_line_struct_type_in_other_positions_stays(run_gofumpt, tmp_path, decl):
    """A one-line single-member struct stays collapsed outside type decls."""
    # CATCHES: the one-line brace rule applies to every struct type in the
    # tree, not just declarations, so a single-member struct used as a
    # parameter type or the right side of a type alias is kept on one line
    # instead of being split like a multi-member one-liner.
    name = write_go(tmp_path, "package p\n\n" + decl)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\n" + decl


def test_nested_one_line_interface_inside_struct_stays(run_gofumpt, tmp_path):
    """A one-line interface nested in a one-line struct stays collapsed."""
    # CATCHES: the probe runs on every composite type recursively, and a
    # single-method interface still prints on one line when nested inside a
    # single-field struct, so the whole declaration stays on one line.
    source = "package p\n\ntype S struct{ i interface{ m() } }\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source


def test_nested_two_member_interface_splits_both_levels(run_gofumpt, tmp_path):
    """A nested two-member interface splits inside its split struct host."""
    # CATCHES: the inner two-method interface does not print on one line, so
    # both the interface braces and the enclosing struct braces are split,
    # each member getting its own line at its own indentation level.
    source = "package p\n\ntype S struct{ i interface{ m(); n() } }\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "type S struct {\n"
        "\ti interface {\n"
        "\t\tm()\n"
        "\t\tn()\n"
        "\t}\n"
        "}\n"
    )


def test_lone_import_decl_is_joined(run_gofumpt, tmp_path):
    """A lone `import` spread over lines collapses onto one line."""
    # CATCHES: the lone-declaration join is not limited to var/const/type:
    # an unparenthesized import whose spec prints on one line has the
    # newlines between the keyword and the path removed too.
    source = "package p\n\nimport\n\"fmt\"\n\nfunc f() { fmt.Println() }\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\nimport \"fmt\"\n\nfunc f() { fmt.Println() }\n"


def test_lone_var_with_func_literal_spec_is_joined(run_gofumpt, tmp_path):
    """A lone var whose value is a one-line func literal is joined."""
    # CATCHES: the spec `f = func() {}` prints on one line, so the split
    # between the keyword, the name and the value is removed and the whole
    # declaration collapses, func literal braces included.
    source = "package p\n\nvar\nf = func() {}\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\nvar f = func() {}\n"


def test_multiline_call_condition_keeps_blank_after_brace(run_gofumpt, tmp_path):
    """A condition holding a multi-line call keeps the blank after `{`."""
    # CATCHES: a call with a trailing comma always prints over multiple
    # lines, so the blank line after the opening brace is preserved for the
    # single-statement body instead of being dropped as usual.
    source = (
        "package p\n"
        "\n"
        "func f() {\n"
        "\tif g(\n"
        "\t\t1,\n"
        "\t) {\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source


def test_split_selector_condition_keeps_blank_after_brace(run_gofumpt, tmp_path):
    """A selector split after the dot keeps the blank line after `{`."""
    # CATCHES: go/printer preserves a source line break after the dot of a
    # selector, so the condition prints over multiple lines and the blank
    # line after the opening brace survives for the single-statement body.
    source = (
        "package p\n"
        "\n"
        "func f(a A) {\n"
        "\tif a.\n"
        "\t\tB {\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source


def test_case_header_collapse_limit_depends_on_nesting_depth(run_gofumpt, tmp_path):
    """The same split case header collapses one block deep but not two."""
    # CATCHES: the collapse limit for a split case header counts the printed
    # bytes plus eight per enclosing brace block, so a 35-byte expression
    # collapses onto the `case` line inside a plain function body yet stays
    # split once the switch sits in a further nested block.
    flat = (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tswitch x {\n"
        "\tcase\n"
        "\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    nested = (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tif true {\n"
        "\t\tswitch x {\n"
        "\t\tcase\n"
        "\t\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n"
        "\n"
        "\t\t\t_ = 1\n"
        "\t\t}\n"
        "\t}\n"
        "}\n"
    )
    flat_name = write_go(tmp_path, flat)
    result = run_gofumpt(flat_name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tswitch x {\n"
        "\tcase aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    nested_name = (tmp_path / "nested.go").name
    (tmp_path / nested_name).write_text(nested)
    result = run_gofumpt(nested_name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tif true {\n"
        "\t\tswitch x {\n"
        "\t\tcase\n"
        "\t\t\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:\n"
        "\n"
        "\t\t\t_ = 1\n"
        "\t\t}\n"
        "\t}\n"
        "}\n"
    )


def test_split_default_clause_is_collapsed(run_gofumpt, tmp_path):
    """A `default` header split before its colon collapses back together."""
    # CATCHES: the case-header collapse applies to the default clause too:
    # with no expression list the header prints far below the limit, so the
    # newline between `default` and `:` is removed and the body moves onto
    # the line after the reassembled `default:`.
    source = (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tswitch x {\n"
        "\tdefault\n"
        "\t:\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tswitch x {\n"
        "\tdefault:\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )


def test_case_body_on_the_colon_line_moves_down(run_gofumpt, tmp_path):
    """A body written on the colon's line is moved onto its own line."""
    # CATCHES: after the split header collapses onto `case 1:`, the printer
    # moves a body that shared the colon's line onto the next line, so the
    # assignment ends up indented under the case instead of beside it.
    source = (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tswitch x {\n"
        "\tcase\n"
        "\t1: _ = 2\n"
        "\t}\n"
        "}\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tswitch x {\n"
        "\tcase 1:\n"
        "\t\t_ = 2\n"
        "\t}\n"
        "}\n"
    )


def test_multi_expression_case_list_is_collapsed(run_gofumpt, tmp_path):
    """A case list of several expressions collapses onto the case line."""
    # CATCHES: the length check covers the whole expression list, and
    # `1, 2` prints well below the limit, so the header joins onto one line
    # while the blank line after the colon is left untouched.
    source = (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tswitch x {\n"
        "\tcase\n"
        "\t1, 2:\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(x int) {\n"
        "\tswitch x {\n"
        "\tcase 1, 2:\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )


def test_multiline_group_separator_is_idempotent(run_gofumpt, tmp_path):
    """Two multi-line groups already apart get no second blank line."""
    # CATCHES: the separator is only inserted between adjacent multi-line
    # declarations, so a blank line the source already has between the two
    # groups is kept exactly as-is instead of being doubled.
    source = (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2\n"
        ")\n"
        "\n"
        "var (\n"
        "\tz = 3\n"
        "\tw = 4\n"
        ")\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source


def test_three_multiline_groups_get_pairwise_separators(run_gofumpt, tmp_path):
    """Three adjacent multi-line groups gain a blank line between each pair."""
    # CATCHES: the separation walk compares every declaration with the one
    # before it, so all three adjacent multi-line groups end up divided by
    # blank lines, not just the first pair.
    source = (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2\n"
        ")\n"
        "var (\n"
        "\tz = 3\n"
        "\tw = 4\n"
        ")\n"
        "var (\n"
        "\tv = 5\n"
        "\tu = 6\n"
        ")\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2\n"
        ")\n"
        "\n"
        "var (\n"
        "\tz = 3\n"
        "\tw = 4\n"
        ")\n"
        "\n"
        "var (\n"
        "\tv = 5\n"
        "\tu = 6\n"
        ")\n"
    )


def test_one_line_decl_between_groups_blocks_separators(run_gofumpt, tmp_path):
    """A one-line declaration between two multi-line groups stays glued."""
    # CATCHES: the separator needs both neighbours to be multi-line, so a
    # lone one-line `var z = 3` between the two groups blocks every blank
    # line: neither the group above nor the group below is separated from it.
    source = (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2\n"
        ")\n"
        "var z = 3\n"
        "var (\n"
        "\tv = 5\n"
        "\tu = 6\n"
        ")\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source


def test_trailing_line_comment_still_separates_groups(run_gofumpt, tmp_path):
    """A trailing comment on the group's last line does not block the separator."""
    # CATCHES: the walk extends a declaration's effective end past a comment
    # that shares its last line, so the blank line still lands after the
    # group's closing parenthesis rather than before the comment or nowhere.
    source = (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2 // keep\n"
        ")\n"
        "var (\n"
        "\tz = 3\n"
        "\tw = 4\n"
        ")\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2 // keep\n"
        ")\n"
        "\n"
        "var (\n"
        "\tz = 3\n"
        "\tw = 4\n"
        ")\n"
    )


def test_separator_is_added_before_a_standalone_comment(run_gofumpt, tmp_path):
    """The new blank line lands between the group and a comment above the next."""
    # CATCHES: a comment starting the line after the first group is treated
    # as the second declaration's new start, so the separator blank line is
    # inserted before the comment, keeping the comment attached to the group
    # it precedes.
    source = (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2\n"
        ")\n"
        "// standalone comment\n"
        "var (\n"
        "\tz = 3\n"
        "\tw = 4\n"
        ")\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2\n"
        ")\n"
        "\n"
        "// standalone comment\n"
        "var (\n"
        "\tz = 3\n"
        "\tw = 4\n"
        ")\n"
    )


def test_group_params_merges_types_written_with_different_line_breaks(
    run_gofumpt, tmp_path
):
    """group_params merges same types even when written across lines."""
    # CATCHES: the merge prints both field types with positions ignored, so
    # a func type split over lines still compares equal to its one-line twin
    # and the names join; the surviving positions of the removed field leave
    # the reassembled parameter list ending in a dangling comma and blank
    # before the closing parenthesis.
    source = (
        "package p\n"
        "\n"
        "func f(a func(x int) error, b func(\n"
        "\tx int,\n"
        ") error) {}\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt("-extra=group_params", name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(a, b func(x int) error,\n"
        "\n"
        ") {\n"
        "}\n"
    )


@pytest.mark.parametrize(
    "params,formatted",
    [
        ("func f(a chan int, b chan int) {}\n", "func f(a, b chan int) {}\n"),
        (
            "func f(a []int, b []int, c map[string]int) {}\n",
            "func f(a, b []int, c map[string]int) {}\n",
        ),
        ("func f(a *T, b *T) {}\n", "func f(a, b *T) {}\n"),
    ],
    ids=["chan", "slice-map", "pointer"],
)
def test_group_params_merges_composite_type_fields(
    run_gofumpt, tmp_path, params, formatted
):
    """group_params merges adjacent parameters of identical composite types."""
    # CATCHES: the type comparison is on printed bytes, not on identifier
    # names, so channel, slice, map and pointer types merge their names just
    # like plain `int` parameters do when the printed types match exactly.
    name = write_go(tmp_path, "package p\n\n" + params)
    result = run_gofumpt("-extra=group_params", name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\n" + formatted


def test_group_params_keeps_different_chan_element_types_apart(
    run_gofumpt, tmp_path
):
    """group_params does not merge channels with different element types."""
    # CATCHES: `chan int` and `chan string` print different bytes, so the
    # two parameters stay separate even though both types are channels; only
    # byte-identical printed types are merged.
    source = "package p\n\nfunc f(a chan int, b chan string) {}\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt("-extra=group_params", name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source
