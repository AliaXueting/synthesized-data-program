"""Friendly handling of the gofmt flags gofumpt dropped: -s and -r."""

import re

REWRITE_MSG = 'the rewrite flag is no longer available; use "gofmt -r" instead\n'

SIMPLIFY_SOURCE = (
    "package p\n"
    "\n"
    "func f(x []int) {\n"
    "\tfor _ = range x {\n"
    "\t}\n"
    "\t_ = x[0:len(x)]\n"
    "}\n"
)

SIMPLIFY_EXPECTED = (
    "package p\n"
    "\n"
    "func f(x []int) {\n"
    "\tfor range x {\n"
    "\t}\n"
    "\t_ = x[0:]\n"
    "}\n"
)

MESSY_SOURCE = "package p\nfunc  f( ) {\nx:=1\n_ = x\n}\n"


def test_simplify_flag_prints_deprecation_warning(run_gofumpt, tmp_path):
    """`gofumpt -s file.go` warns on stderr but formats the file normally."""
    # CATCHES: -s is accepted (not an undefined flag) and prints the exact
    # warning line, while formatting still happens and exit status stays 0.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("-s", path.name)
    assert result.returncode == 0
    assert result.err == "warning: -s is deprecated as it is always enabled\n"
    assert "package p\n\nfunc f() {\n\tx := 1\n\t_ = x\n}\n" in result.out


def test_simplify_flag_warning_goes_only_to_stderr(run_gofumpt):
    """The -s warning never leaks into the formatted output on stdout."""
    # CATCHES: stream separation -- stdout carries only Go source, stderr only
    # the warning, so a wrong implementation mixing them fails.
    result = run_gofumpt("-s")
    assert result.returncode == 0
    assert result.err == "warning: -s is deprecated as it is always enabled\n"
    assert result.stdout == b""


def test_simplify_is_always_enabled_without_the_flag(run_gofumpt, tmp_path):
    """gofmt -s transformations apply even without -s, with identical output."""
    # CATCHES: simplification is unconditional in gofumpt, so `for _ = range`
    # and `x[0:len(x)]` are rewritten with and without -s to the same bytes.
    path = tmp_path / "simp.go"
    path.write_text(SIMPLIFY_SOURCE)
    plain = run_gofumpt(path.name)
    with_flag = run_gofumpt("-s", path.name)
    assert plain.returncode == 0
    assert with_flag.returncode == 0
    assert plain.out == SIMPLIFY_EXPECTED
    assert with_flag.out == SIMPLIFY_EXPECTED


def test_simplify_false_is_silent(run_gofumpt, tmp_path):
    """`-s=false` prints no warning at all and formats normally."""
    # CATCHES: only a truthy -s triggers the warning; the explicit false
    # spelling must be accepted and stay completely silent.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("-s=false", path.name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\nfunc f() {\n\tx := 1\n\t_ = x\n}\n"


def test_rewrite_flag_fails_with_exit_two_and_no_usage(run_gofumpt):
    """`gofumpt -r x` prints only the refusal message and exits 2."""
    # CATCHES: unlike an unknown flag, -r prints no usage trailer; only the
    # single refusal line on stderr with exit status 2.
    result = run_gofumpt("-r", "x")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == REWRITE_MSG


def test_rewrite_flag_equals_and_double_dash_spellings(run_gofumpt):
    """`-r=x` and `--r=x` hit the same refusal path as `-r x`."""
    # CATCHES: every accepted spelling of the string flag must reach the
    # refusal branch, not the undefined-flag branch.
    for argv in (("-r=x",), ("--r=x",)):
        result = run_gofumpt(*argv)
        assert result.returncode == 2
        assert result.err == REWRITE_MSG


def test_rewrite_flag_never_touches_files(run_gofumpt, tmp_path):
    """`gofumpt -r x -w messy.go` leaves the file byte-for-byte unchanged."""
    # CATCHES: the -r check exits before any file is opened or written, so -w
    # must not have any effect on the file's contents.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("-r", "x", "-w", path.name)
    assert result.returncode == 2
    assert path.read_bytes() == MESSY_SOURCE.encode()


def test_rewrite_flag_runs_before_any_path_is_walked(run_gofumpt):
    """`gofumpt -r x nosuchfile.go` reports only -r, never a missing path."""
    # CATCHES: the -r check precedes path walking, so no lstat error for the
    # nonexistent argument may appear alongside the refusal message.
    result = run_gofumpt("-r", "x", "nosuchfile.go", "alsonotadir/")
    assert result.returncode == 2
    assert result.err == REWRITE_MSG


def test_rewrite_flag_empty_value_is_ignored(run_gofumpt):
    """`-r ""` is treated as unset, so the run proceeds normally."""
    # CATCHES: the refusal only triggers on a non-empty rule string, so an
    # explicitly empty -r must fall through to -version and exit 0.
    result = run_gofumpt("-r", "", "-version")
    assert result.returncode == 0
    assert result.stderr == b""
    assert re.match(r"^[^\s]+ \([^\s()]+\)\n$", result.out)


def test_simplify_warning_precedes_rewrite_refusal(run_gofumpt):
    """`-s -r x` prints the warning first, then the refusal, and exits 2."""
    # CATCHES: the -s warning is emitted before the -r hard failure, so the
    # two lines appear in that fixed order on stderr.
    result = run_gofumpt("-s", "-r", "x")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == (
        "warning: -s is deprecated as it is always enabled\n" + REWRITE_MSG
    )


def test_rewrite_flag_order_does_not_matter(run_gofumpt):
    """`-r x -s` prints the same two stderr lines as `-s -r x`."""
    # CATCHES: the message order follows the program's internal check order
    # (-s before -r), not the order the flags were given on the command line.
    result = run_gofumpt("-r", "x", "-s")
    assert result.returncode == 2
    assert result.err == (
        "warning: -s is deprecated as it is always enabled\n" + REWRITE_MSG
    )


def test_rewrite_flag_refuses_before_extra_rule_validation_runs(
    run_gofumpt, tmp_path
):
    """`-r x` wins over a later formatting run even with -extra and a path."""
    # CATCHES: no formatting work at all happens once -r is seen; the file is
    # left alone and stdout stays empty even though a real path was given.
    path = tmp_path / "messy.go"
    path.write_text(MESSY_SOURCE)
    result = run_gofumpt("-extra", "-l", "-r", "rule", path.name)
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == REWRITE_MSG
    assert path.read_bytes() == MESSY_SOURCE.encode()
