"""-version reporting: single stdout line, exit 0, and its precedence rules."""

import re

#: `<version> (<go version>)` -- one line, no trailing spaces.
VERSION_LINE_RE = re.compile(r"^[^\s]+ \([^\s()]+\)\n$")


def test_version_prints_one_line_to_stdout_and_exits_zero(run_gofumpt):
    """`gofumpt -version` prints exactly one `<version> (<go version>)` line."""
    # CATCHES: the output is a single newline-terminated line on stdout in the
    # `<version> (<go version>)` shape; extra lines or stderr output break it.
    result = run_gofumpt("-version")
    assert result.returncode == 0
    assert result.stderr == b""
    assert VERSION_LINE_RE.match(result.out), repr(result.out)


def test_version_double_dash_form(run_gofumpt):
    """`--version` behaves exactly like `-version`."""
    # CATCHES: the Go flag package accepts one or two leading dashes, so both
    # spellings must produce the same single-line version report.
    short = run_gofumpt("-version")
    long = run_gofumpt("--version")
    assert short.returncode == 0
    assert VERSION_LINE_RE.match(short.out), repr(short.out)
    assert long.returncode == 0
    assert long.stderr == b""
    assert VERSION_LINE_RE.match(long.out), repr(long.out)
    assert long.stdout == short.stdout


def test_version_ignores_path_arguments(run_gofumpt):
    """`gofumpt -version nosuchfile.go` succeeds without touching the path."""
    # CATCHES: -version returns before any path is walked, so a missing file
    # must not turn into an error and must not change the printed line.
    plain = run_gofumpt("-version")
    assert plain.returncode == 0
    assert VERSION_LINE_RE.match(plain.out), repr(plain.out)
    with_path = run_gofumpt("-version", "nosuchfile.go")
    assert with_path.returncode == 0
    assert with_path.stderr == b""
    assert VERSION_LINE_RE.match(with_path.out), repr(with_path.out)
    assert with_path.stdout == plain.stdout


def test_version_ignores_stdin(run_gofumpt):
    """`gofumpt -version` never reads stdin, even when it holds Go source."""
    # CATCHES: -version must not fall back to formatting standard input, which
    # would echo the piped source to stdout instead of the version line.
    plain = run_gofumpt("-version")
    result = run_gofumpt("-version", stdin=b"package p\nfunc  f( ) {\nx:=1\n}\n")
    assert result.returncode == 0
    assert result.stderr == b""
    assert result.stdout == plain.stdout
    assert VERSION_LINE_RE.match(result.out)


def test_version_wins_over_lang_validation(run_gofumpt):
    """`-version -lang=nonsense` still exits 0 with the version line."""
    # CATCHES: an invalid -lang only panics once a file is formatted, and
    # -version returns before that, so no panic trace may be printed.
    result = run_gofumpt("-version", "-lang=nonsense")
    assert result.returncode == 0
    assert result.stderr == b""
    assert VERSION_LINE_RE.match(result.out)


def test_version_wins_over_stdin_write_flag(run_gofumpt):
    """`-w -version` prints the version instead of the -w/stdin error."""
    # CATCHES: the -w-with-stdin check runs after the -version branch, so the
    # combination must succeed rather than fail with exit 2.
    result = run_gofumpt("-w", "-version")
    assert result.returncode == 0
    assert result.stderr == b""
    assert VERSION_LINE_RE.match(result.out)


def test_version_wins_over_cpuprofile(run_gofumpt, tmp_path):
    """`-cpuprofile=<file> -version` prints the version and creates no profile."""
    # CATCHES: the CPU profile is only started after the -version branch, so
    # no file may be created for this combination.
    profile = tmp_path / "cpu.out"
    result = run_gofumpt("-cpuprofile=%s" % profile, "-version")
    assert result.returncode == 0
    assert VERSION_LINE_RE.match(result.out)
    assert not profile.exists()


def test_version_with_deprecated_simplify_flag(run_gofumpt):
    """`-version -s` prints both the -s warning and the version line."""
    # CATCHES: the -s deprecation warning is emitted before -version is
    # handled, so stderr keeps the warning while stdout keeps the version.
    result = run_gofumpt("-version", "-s")
    assert result.returncode == 0
    assert result.err == "warning: -s is deprecated as it is always enabled\n"
    assert VERSION_LINE_RE.match(result.out)


def test_version_is_suppressed_by_rewrite_flag(run_gofumpt):
    """`-version -r x` exits 2 with only the -r message and no version line."""
    # CATCHES: the dropped -r flag is checked before -version, so its hard
    # failure wins: exit 2, empty stdout, no version anywhere.
    result = run_gofumpt("-version", "-r", "x")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == 'the rewrite flag is no longer available; use "gofmt -r" instead\n'


def test_version_is_reached_after_flag_parse_errors(run_gofumpt):
    """`-version -extra=bogus` fails at flag parsing: no version, exit 2."""
    # CATCHES: flag syntax errors abort before -version is honored, so the
    # unknown-rule message and usage are printed instead of the version.
    result = run_gofumpt("-version", "-extra=bogus")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err.startswith('invalid boolean value "bogus" for -extra: unknown rule: "bogus"\n')
    assert "usage: gofumpt [flags] [path ...]" in result.err


def test_version_after_double_dash_terminator(run_gofumpt):
    """`-version --` still prints the version because `--` ends the flags."""
    # CATCHES: `--` only terminates flag parsing, it does not turn -version
    # into a path argument, so the version branch is still taken.
    result = run_gofumpt("-version", "--")
    assert result.returncode == 0
    assert result.stderr == b""
    assert VERSION_LINE_RE.match(result.out)


def test_version_line_has_no_build_info_marker_noise(run_gofumpt):
    """The version line is a single line without trailing blank lines."""
    # CATCHES: the report must be exactly one line; implementations that also
    # print build settings or an extra blank line would fail this.
    result = run_gofumpt("-version")
    assert result.returncode == 0
    assert len(result.out_lines) == 1
    assert VERSION_LINE_RE.match(result.out)


def test_version_go_version_comes_from_the_go_version_test_hook(run_gofumpt):
    """GO_VERSION_TEST overrides the reported toolchain version verbatim."""
    # CATCHES: internal/version reads GO_VERSION_TEST before falling back to
    # runtime.Version(), so the parenthesised part of the line follows the
    # environment variable byte for byte, however non-version-like it is.
    result = run_gofumpt("-version", extra_env={"GO_VERSION_TEST": "go1.99.1"})
    assert result.returncode == 0
    assert result.stderr == b""
    assert result.out.endswith("(go1.99.1)\n")
    assert VERSION_LINE_RE.match(result.out)


def test_version_go_version_hook_accepts_any_string(run_gofumpt):
    """The GO_VERSION_TEST hook is not validated: any string is echoed."""
    # CATCHES: the hook is a raw string override, so even a non-version string
    # reaches the output unchanged instead of being rejected or normalised.
    plain = run_gofumpt("-version")
    result = run_gofumpt("-version", extra_env={"GO_VERSION_TEST": "not-a-version"})
    assert result.returncode == 0
    assert result.out.endswith("(not-a-version)\n")
    assert result.out != plain.out
