"""Value-taking flags: -lang, -modpath, -e and -cpuprofile."""

import pytest

OCTAL_SOURCE = "package p\n\nvar x = 0777\n"

IMPORTS_SOURCE = (
    "package p\n"
    "\n"
    "import (\n"
    '\t"example.com/x"\n'
    '\t"mypkg/foo"\n'
    '\t"fmt"\n'
    ")\n"
)

IMPORTS_DEFAULT = (
    "package p\n\nimport (\n\t\"fmt\"\n\t\"mypkg/foo\"\n\n\t\"example.com/x\"\n)\n"
)

IMPORTS_WITH_MODPATH = (
    "package p\n\nimport (\n\t\"fmt\"\n\n\t\"example.com/x\"\n\t\"mypkg/foo\"\n)\n"
)

#: Twenty broken const declarations produce more than ten parser errors on
#: distinct lines, which is what the -e cap is about.
MANY_ERRORS = "package p\n" + "".join(
    "const c%d = = %d\n" % (i, i) for i in range(20)
)


def test_lang_go1_13_is_reported_verbatim(run_gofumpt, diag_file):
    """`-lang=go1.13` reaches the formatter as the go1.13 language version."""
    # CATCHES: the flag value is passed through to the formatter state and is
    # observable in the diagnose dump next to the default -modpath.
    result = run_gofumpt("-lang=go1.13", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.13 -modpath="


def test_lang_space_separated_form(run_gofumpt, diag_file):
    """`-lang go1.13` (value as the next argument) is accepted too."""
    # CATCHES: string flags take their value either after `=` or as the next
    # argv element, and both spellings must set the same state.
    equals = run_gofumpt("-lang=go1.13", diag_file)
    spaced = run_gofumpt("-lang", "go1.13", diag_file)
    assert spaced.returncode == 0
    assert spaced.diagnose_flags() == equals.diagnose_flags()


def test_lang_empty_value_falls_back_to_go1(run_gofumpt, diag_file):
    """`-lang=` behaves like omitting the flag: the default becomes go1."""
    # CATCHES: an empty string is indistinguishable from "not set", so the
    # diagnose dump reports the go1 default rather than an empty -lang=.
    result = run_gofumpt("-lang=", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath="


def test_lang_patch_release_is_normalised(run_gofumpt, diag_file):
    """`-lang=go1.21.0` is normalised to `go1.21` in the flag dump."""
    # CATCHES: the value is run through Go version normalisation, so a full
    # semver-ish spelling is reported with only major.minor.
    result = run_gofumpt("-lang=go1.21.0", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.21 -modpath="


@pytest.mark.parametrize("value", ["nonsense", "1.13", "go1.x", "GO1.13"])
def test_lang_invalid_value_panics_with_exit_two(run_gofumpt, tmp_path, value):
    """An invalid -lang panics only once a file is formatted: exit 2, no stdout."""
    # CATCHES: validation happens lazily inside the formatter, so the failure
    # is a Go panic (`panic: invalid Go version: ...`) with a goroutine trace
    # on stderr and exit status 2, not a flag error and not a usage dump.
    path = tmp_path / "ok.go"
    path.write_text("package p\n\nvar x = 0777\n")
    result = run_gofumpt("-lang=%s" % value, path.name)
    assert result.returncode == 2
    assert result.stdout == b""
    lines = result.err.splitlines()
    assert lines[0] == 'panic: invalid Go version: "%s"' % value
    assert lines[1] == ""
    assert len(lines) > 10  # a goroutine stack dump follows the panic message
    assert "usage: gofumpt [flags] [path ...]" not in result.err


def test_lang_go1_13_rewrites_octal_literals(run_gofumpt, tmp_path):
    """`-lang=go1.13` makes gofumpt rewrite `0777` into `0o777`."""
    # CATCHES: the version-gated octal rule keys off the parsed -lang value,
    # proving the flag value is really used by the formatter.
    path = tmp_path / "oct.go"
    path.write_text(OCTAL_SOURCE)
    new = run_gofumpt("-lang=go1.13", path.name)
    assert new.returncode == 0
    assert new.out == "package p\n\nvar x = 0o777\n"


def test_lang_go1_12_keeps_legacy_octal_literals(run_gofumpt, tmp_path):
    """`-lang=go1.12` leaves `0777` alone because 0o literals need go1.13."""
    # CATCHES: the language gate is a real comparison, not just "any -lang";
    # an older version must keep the legacy literal spelling.
    path = tmp_path / "oct.go"
    path.write_text(OCTAL_SOURCE)
    old = run_gofumpt("-lang=go1.12", path.name)
    assert old.returncode == 0
    assert old.out == OCTAL_SOURCE


def test_modpath_is_reported_verbatim(run_gofumpt, diag_file):
    """`-modpath=example.com/foo` is passed through to the formatter state."""
    # CATCHES: any string is accepted; the diagnose dump echoes it next to the
    # default (empty) -lang.
    result = run_gofumpt("-modpath=example.com/foo", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath=example.com/foo"


def test_modpath_empty_is_the_default(run_gofumpt, diag_file):
    """`-modpath=` reports an empty module path, exactly like omitting it."""
    # CATCHES: empty means "not inside a module" and is dumped as `-modpath=`.
    result = run_gofumpt("-modpath=", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath="


def test_modpath_changes_std_import_grouping(run_gofumpt, tmp_path):
    """`-modpath=mypkg` stops `mypkg/foo` from being treated as standard."""
    # CATCHES: the module path really feeds the import grouping heuristic, so
    # a dotted-less import sharing the module prefix stays in the second group.
    path = tmp_path / "imp.go"
    path.write_text(IMPORTS_SOURCE)
    default = run_gofumpt(path.name)
    with_flag = run_gofumpt("-modpath=mypkg", path.name)
    assert default.returncode == 0
    assert default.out == IMPORTS_DEFAULT
    assert with_flag.out == IMPORTS_WITH_MODPATH


def test_lang_and_modpath_and_extra_combine(run_gofumpt, diag_file):
    """All three gofumpt value flags can be given in one command line."""
    # CATCHES: the flags are independent and all reach the formatter state at
    # once, dumped together by the diagnose directive.
    result = run_gofumpt(
        "-lang=go1.16",
        "-modpath=example.com/bar",
        "-extra=clothe_returns",
        diag_file,
    )
    assert result.returncode == 0
    assert result.diagnose_flags() == (
        "-lang=go1.16 -modpath=example.com/bar -extra=clothe_returns"
    )


def test_e_reports_errors_beyond_the_ten_line_cap(run_gofumpt, tmp_path):
    """Without -e, only the first ten errors on different lines are printed."""
    # CATCHES: the default parser mode truncates the error list, so a file with
    # twenty broken declarations yields exactly eleven error lines and exit 2.
    path = tmp_path / "many.go"
    path.write_text(MANY_ERRORS)
    result = run_gofumpt(path.name)
    assert result.returncode == 2
    assert result.stdout == b""
    assert len(result.err_lines) == 11
    assert result.err_lines[0] == "%s:2:12: expected operand, found '='" % path.name
    assert result.err_lines[10] == "%s:12:1: expected ';', found 'const'" % path.name


def test_e_prints_every_parse_error(run_gofumpt, tmp_path):
    """With -e, all parse errors are printed, including several per line."""
    # CATCHES: -e switches the parser into AllErrors mode, which keeps errors
    # that share a line and never truncates the list at ten.
    path = tmp_path / "many.go"
    path.write_text(MANY_ERRORS)
    result = run_gofumpt("-e", path.name)
    assert result.returncode == 2
    assert result.stdout == b""
    assert len(result.err_lines) == 40
    assert result.err_lines[0] == "%s:2:12: expected operand, found '='" % path.name
    assert result.err_lines[1] == "%s:3:1: expected ';', found 'const'" % path.name
    assert result.err_lines[2] == "%s:3:12: expected operand, found '='" % path.name


def test_e_false_matches_the_default_truncation(run_gofumpt, tmp_path):
    """`-e=false` prints exactly the same truncated error list as no flag."""
    # CATCHES: the explicit false spelling must equal the default behaviour,
    # byte for byte.
    path = tmp_path / "many.go"
    path.write_text(MANY_ERRORS)
    plain = run_gofumpt(path.name)
    disabled = run_gofumpt("-e=false", path.name)
    assert disabled.returncode == plain.returncode
    assert disabled.stderr == plain.stderr
    assert len(disabled.err_lines) == 11


def test_e_keeps_first_error_identical(run_gofumpt, tmp_path):
    """The first reported error is the same with and without -e."""
    # CATCHES: -e only widens the report; it must not reorder or reword the
    # errors that the truncated mode already printed.
    path = tmp_path / "many.go"
    path.write_text(MANY_ERRORS)
    plain = run_gofumpt(path.name)
    all_errors = run_gofumpt("-e", path.name)
    assert all_errors.err_lines[0] == plain.err_lines[0]
    assert len(all_errors.err_lines) > len(plain.err_lines)


def test_cpuprofile_writes_a_profile_file(run_gofumpt, tmp_path):
    """`-cpuprofile=<file>` writes a gzip-compressed pprof profile."""
    # CATCHES: the flag must create the named file (relative to the working
    # directory) as a real pprof stream starting with the gzip magic bytes.
    path = tmp_path / "ok.go"
    path.write_text("package p\n")
    result = run_gofumpt("-cpuprofile=cpu.out", path.name)
    assert result.returncode == 0
    assert result.err == ""
    profile = tmp_path / "cpu.out"
    assert profile.exists()
    assert profile.stat().st_size > 0
    assert profile.read_bytes()[:2] == b"\x1f\x8b"


def test_cpuprofile_with_unwritable_path_fails_before_formatting(run_gofumpt, tmp_path):
    """A profile path that cannot be created aborts with exit 2 and no output."""
    # CATCHES: the profile is opened before any file is formatted, so a bad
    # path yields a `creating cpu profile: ...` error and empty stdout.
    path = tmp_path / "ok.go"
    path.write_text("package p\n")
    result = run_gofumpt("-cpuprofile=missing-dir/cpu.out", path.name)
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == (
        "creating cpu profile: open missing-dir/cpu.out: no such file or directory\n"
    )
