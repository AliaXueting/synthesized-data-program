"""Path arguments: directories are walked and arguments are cleaned first."""

import pytest

MESSY_A = "package p\nfunc  a( ) {\nx:=1\n}\n"
MESSY_A_FORMATTED = "package p\n\nfunc a() {\n\tx := 1\n}\n"
MESSY_C = "package q\nfunc  c( ) {\ny:=2\n}\n"
MESSY_C_FORMATTED = "package q\n\nfunc c() {\n\ty := 2\n}\n"


@pytest.fixture
def tree(tmp_path):
    """Create a small tree: a.go, b.txt, .hidden.go and sub/c.go."""
    (tmp_path / "a.go").write_text(MESSY_A)
    (tmp_path / "b.txt").write_text("not go source\n")
    (tmp_path / ".hidden.go").write_text("package r\nvar z = 3\n")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "c.go").write_text(MESSY_C)
    return tmp_path


def test_directory_argument_is_walked_recursively(run_gofumpt, tree):
    """A directory argument formats every Go file found below it, in order."""
    # CATCHES: the path arguments are walked depth-first in lexical order, so
    # a.go is printed before sub/c.go with no separator in between.
    result = run_gofumpt(".")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == MESSY_A_FORMATTED + MESSY_C_FORMATTED


def test_directory_walk_skips_non_go_and_hidden_files(run_gofumpt, tree):
    """Walking a directory only lists .go files that do not start with a dot."""
    # CATCHES: b.txt and .hidden.go live in the walked directory but must be
    # skipped, while sub/c.go is reached through the subdirectory.
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == ["a.go", "sub/c.go"]


def test_subdirectory_argument_only_walks_that_subtree(run_gofumpt, tree):
    """Passing `sub` walks only the files under sub, not its parent."""
    # CATCHES: each path argument is an independent walk root, so the sibling
    # a.go in the parent directory is never touched.
    result = run_gofumpt("sub")
    assert result.returncode == 0
    assert result.out == MESSY_C_FORMATTED
    assert result.err == ""


@pytest.mark.parametrize("argument", ["./sub/", "sub/../sub", "./sub/../sub"])
def test_path_arguments_are_cleaned_before_walking(run_gofumpt, tree, argument):
    """A messy path argument is cleaned, so reported names use the clean form."""
    # CATCHES: filepath.Clean runs on every argument, so `./sub/` and
    # `sub/../sub` both report `sub/c.go` instead of echoing the raw argument.
    result = run_gofumpt("-l", argument)
    assert result.returncode == 0
    assert result.out_lines == ["sub/c.go"]


def test_explicit_file_argument_is_cleaned(run_gofumpt, tree):
    """`gofumpt -l ./a.go` reports the cleaned name `a.go`."""
    # CATCHES: the cleaning applies to plain file arguments too, so the listed
    # name drops the `./` prefix instead of matching the typed argument.
    result = run_gofumpt("-l", "./a.go")
    assert result.returncode == 0
    assert result.out_lines == ["a.go"]


def test_write_flag_applies_to_files_found_by_a_walk(run_gofumpt, tree):
    """`-w` on a directory rewrites every Go file the walk finds."""
    # CATCHES: the write mode follows the walk, so both a.go and sub/c.go are
    # rewritten on disk while the non-Go files stay untouched.
    result = run_gofumpt("-w", ".")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.err == ""
    assert (tree / "a.go").read_text() == MESSY_A_FORMATTED
    assert (tree / "sub" / "c.go").read_text() == MESSY_C_FORMATTED
    assert (tree / "b.txt").read_text() == "not go source\n"


@pytest.fixture
def ignored_tree(tmp_path):
    """Create a tree holding vendor/, testdata/ and a plain Go file."""
    (tmp_path / "main.go").write_text(MESSY_A)
    (tmp_path / "vendor" / "example.com").mkdir(parents=True)
    (tmp_path / "vendor" / "example.com" / "v.go").write_text(MESSY_C)
    (tmp_path / "testdata").mkdir()
    (tmp_path / "testdata" / "t.go").write_text(MESSY_C)
    return tmp_path


def test_walk_skips_vendor_and_testdata_directories(run_gofumpt, ignored_tree):
    """A recursive walk does not descend into vendor/ or testdata/."""
    # CATCHES: those two directory names are pruned during walks, so only
    # main.go shows up in the -l listing even though the others are unformatted.
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == ["main.go"]


def test_vendor_directory_named_explicitly_is_formatted(run_gofumpt, ignored_tree):
    """Naming `vendor` directly still formats the files inside it."""
    # CATCHES: the pruning only applies to directories found *during* a walk;
    # an explicit argument is always walked, so the vendor file is listed.
    result = run_gofumpt("-l", "vendor")
    assert result.returncode == 0
    assert result.out_lines == ["vendor/example.com/v.go"]


def test_testdata_directory_named_explicitly_is_formatted(run_gofumpt, ignored_tree):
    """Naming `testdata` directly still formats the files inside it."""
    # CATCHES: same exception as vendor -- the argument itself is explicit, so
    # the testdata subtree is walked and its file is listed.
    result = run_gofumpt("-l", "testdata")
    assert result.returncode == 0
    assert result.out_lines == ["testdata/t.go"]


def test_explicit_vendor_file_is_formatted(run_gofumpt, ignored_tree):
    """A file inside vendor/ named directly is formatted like any other."""
    # CATCHES: the skip is directory-based and only for non-explicit paths, so
    # naming the file itself bypasses it entirely.
    result = run_gofumpt("-l", "vendor/example.com/v.go")
    assert result.returncode == 0
    assert result.out_lines == ["vendor/example.com/v.go"]


GENERATED_SOURCE = (
    "// Code generated by tool. DO NOT EDIT.\n"
    "\n"
    "package p\n"
    "\n"
    "import (\n"
    '\t"fmt"\n'
    '\t"example.com/x"\n'
    ")\n"
    "\n"
    "func f() {\n"
    "\n"
    "\tx := 1\n"
    "\t_ = x\n"
    "}\n"
)

#: gofumpt's own rules: std imports split from third-party, no blank line
#: after the opening brace.
GENERATED_EXPLICIT = (
    "// Code generated by tool. DO NOT EDIT.\n"
    "\n"
    "package p\n"
    "\n"
    "import (\n"
    '\t"fmt"\n'
    "\n"
    '\t"example.com/x"\n'
    ")\n"
    "\n"
    "func f() {\n"
    "\tx := 1\n"
    "\t_ = x\n"
    "}\n"
)

#: plain gofmt only: imports merely sorted, blank line kept.
GENERATED_WALKED = (
    "// Code generated by tool. DO NOT EDIT.\n"
    "\n"
    "package p\n"
    "\n"
    "import (\n"
    '\t"example.com/x"\n'
    '\t"fmt"\n'
    ")\n"
    "\n"
    "func f() {\n"
    "\n"
    "\tx := 1\n"
    "\t_ = x\n"
    "}\n"
)


@pytest.fixture
def generated_tree(tmp_path):
    """Create a generated Go file both at the root and inside a subdirectory."""
    (tmp_path / "gen.go").write_text(GENERATED_SOURCE)
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "gen.go").write_text(GENERATED_SOURCE)
    return tmp_path


def test_generated_file_named_explicitly_gets_gofumpt_rules(run_gofumpt, generated_tree):
    """A generated file passed directly is formatted with all gofumpt rules."""
    # CATCHES: the `// Code generated ... DO NOT EDIT.` marker only relaxes the
    # rules for files found during a walk, never for explicit arguments.
    result = run_gofumpt("gen.go")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == GENERATED_EXPLICIT


def test_generated_file_found_by_a_walk_skips_gofumpt_rules(run_gofumpt, generated_tree):
    """The same generated file, reached through a directory, keeps plain gofmt."""
    # CATCHES: only gofmt's own formatting is applied to walked generated
    # files, so the imports stay in one sorted group and the blank line after
    # the opening brace survives.
    result = run_gofumpt("sub")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == GENERATED_WALKED
