"""Help/usage surface of the gofumpt CLI: -h/--help output and flag errors."""

import pytest

USAGE = (
    "usage: gofumpt [flags] [path ...]\n"
    "\t-version  show version and exit\n"
    "\n"
    "\t-d        display diffs instead of rewriting files\n"
    "\t-e        report all errors (not just the first 10 on different lines)\n"
    "\t-l        list files whose formatting differs from gofumpt's\n"
    "\t-w        write result to (source) file instead of stdout\n"
    "\t-extra    enable extra rules, e.g. -extra=group_params,clothe_returns\n"
    "\n"
    '\t-lang       str    target Go version in the form "go1.X" (default from go.mod)\n'
    "\t-modpath    str    Go module path containing the source file (default from go.mod)\n"
)

#: Flags that take a separate string value; omitting it is a usage error.
VALUE_FLAGS = ["lang", "modpath", "cpuprofile", "r"]


def test_help_h_prints_usage_on_stderr_and_exits_zero(run_gofumpt):
    """`gofumpt -h` prints the usage text to stderr and exits with status 0."""
    # CATCHES: help must go to stderr (not stdout) and still exit 0, unlike a
    # flag error which reuses the same text but exits 2.
    result = run_gofumpt("-h")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.err == USAGE


def test_help_long_form_matches_short_form(run_gofumpt):
    """--help, -help and -h all print byte-identical usage text and exit 0."""
    # CATCHES: the Go flag package treats -h, -help and --help alike; a
    # re-implementation that only special-cases one spelling would differ.
    results = [run_gofumpt(flag) for flag in ("-h", "-help", "--help")]
    for result in results:
        assert result.returncode == 0
        assert result.stdout == b""
    assert results[0].stderr == results[1].stderr == results[2].stderr == USAGE.encode()


def test_help_text_documents_every_flag(run_gofumpt):
    """The usage text lists each documented flag with its exact help line."""
    # CATCHES: the wording, tab indentation and column alignment of every
    # documented flag (-d -e -l -w -extra -lang -modpath -version) is pinned.
    result = run_gofumpt("--help")
    lines = result.err.splitlines()
    assert lines[0] == "usage: gofumpt [flags] [path ...]"
    for expected in (
        "\t-version  show version and exit",
        "\t-d        display diffs instead of rewriting files",
        "\t-e        report all errors (not just the first 10 on different lines)",
        "\t-l        list files whose formatting differs from gofumpt's",
        "\t-w        write result to (source) file instead of stdout",
        "\t-extra    enable extra rules, e.g. -extra=group_params,clothe_returns",
        '\t-lang       str    target Go version in the form "go1.X" (default from go.mod)',
        "\t-modpath    str    Go module path containing the source file (default from go.mod)",
    ):
        assert expected in lines


def test_help_is_printed_even_when_other_flags_precede_it(run_gofumpt):
    """A valid flag before -h does not stop -h from printing usage, exit 0."""
    # CATCHES: flag parsing happens before any main work, so `-extra -h`
    # must still be help (exit 0) rather than an error or a format run.
    result = run_gofumpt("-extra", "-h")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.err == USAGE


def test_help_wins_over_version(run_gofumpt):
    """`-version -h` prints usage only: -h short-circuits before -version."""
    # CATCHES: the ordering between help handling and the -version branch;
    # a wrong implementation would print the version line on stdout too.
    result = run_gofumpt("-version", "-h")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.err == USAGE


def test_help_wins_over_dropped_rewrite_flag(run_gofumpt):
    """`-r x -h` exits 0 with usage only, without the -r refusal message."""
    # CATCHES: -r is normally a hard error, but flag.Parse handles -h first,
    # so help must win over the "rewrite flag is no longer available" path.
    result = run_gofumpt("-r", "x", "-h")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.err == USAGE


def test_help_wins_over_deprecated_simplify_flag(run_gofumpt):
    """`-s -h` prints no -s deprecation warning, only the usage text."""
    # CATCHES: the -s warning is emitted after flag parsing, so help must
    # suppress it entirely rather than printing warning plus usage.
    result = run_gofumpt("-s", "-h")
    assert result.returncode == 0
    assert result.err == USAGE


def test_unknown_flag_reports_error_then_usage_and_exits_two(run_gofumpt):
    """An undefined flag prints `flag provided but not defined` plus usage, exit 2."""
    # CATCHES: exact error line, the usage trailer, the stderr stream and the
    # exit status 2 (not 1, and nothing at all on stdout).
    result = run_gofumpt("-foobar")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "flag provided but not defined: -foobar\n" + USAGE


def test_unknown_flag_long_and_equals_forms(run_gofumpt):
    """`--foobar` and `-foobar=1` produce the same undefined-flag error."""
    # CATCHES: single/double dash and =value spellings must all reach the
    # undefined-flag path with the flag's bare name in the message.
    for argv in (("--foobar",), ("-foobar=1",)):
        result = run_gofumpt(*argv)
        assert result.returncode == 2
        assert result.stdout == b""
        assert result.err.startswith("flag provided but not defined: -foobar\n")
        assert result.err.endswith(USAGE)


@pytest.mark.parametrize("flag", VALUE_FLAGS)
def test_value_flag_without_argument_is_a_usage_error(run_gofumpt, flag):
    """`-lang` with no value prints `flag needs an argument` plus usage, exit 2."""
    # CATCHES: -lang/-modpath/-cpuprofile/-r all require a following value;
    # dropping it must be reported as a flag error, never as an empty value.
    result = run_gofumpt("-%s" % flag)
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "flag needs an argument: -%s\n" % flag + USAGE


def test_flag_error_beats_everything_else(run_gofumpt):
    """An undefined flag aborts before any path is walked or file is read."""
    # CATCHES: parse errors take precedence over missing files, so pointing at
    # a nonexistent path must not add an lstat error to the output.
    result = run_gofumpt("-nope", "definitely-missing.go")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "flag provided but not defined: -nope\n" + USAGE


def test_help_exit_status_differs_from_flag_error_status(run_gofumpt):
    """Help exits 0 while an unknown flag exits 2 though both print usage."""
    # CATCHES: the two exit codes are the only observable difference between
    # the help path and the flag-error path once the text is byte-equal.
    help_result = run_gofumpt("-h")
    error_result = run_gofumpt("-definitely-not-a-flag")
    assert help_result.returncode == 0
    assert error_result.returncode == 2
    assert error_result.err.endswith(help_result.err)
    assert len(help_result.err) == len(USAGE.encode())
