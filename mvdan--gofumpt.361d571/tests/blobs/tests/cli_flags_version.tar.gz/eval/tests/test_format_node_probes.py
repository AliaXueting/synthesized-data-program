"""Round-4 coverage target: internal/govendor/go/format/format.go.

The CLI binary never calls that file's Source entry point and never hands an
*ast.File to its Node entry point (both would only happen through the library
API gofumpt.FormatSource, which the command does not use).  Everything the CLI
does reach is ``format.Node`` with sub-file nodes, invoked by gofumpt's
internal probes: "does this node print on one line?" (structs, interfaces,
specs, if/for conditions, whole declarations) and "how many bytes would this
node print as?" (case clause headers).  The tests below pin the CLI-visible
consequences of those probe decisions.
"""

import pytest


def write_go(tmp_path, source):
    """Write a Go source file into ``tmp_path`` and return its name."""
    path = tmp_path / "src.go"
    path.write_text(source)
    return path.name


@pytest.mark.parametrize(
    "header",
    ["if", "for"],
)
def test_split_condition_keeps_blank_line_after_brace(run_gofumpt, tmp_path, header):
    """A condition the printer keeps split preserves the blank after `{`."""
    # CATCHES: a single-statement body normally loses the blank line right
    # after the opening brace, but a condition printed over multiple lines
    # (binary operator kept on its own line) makes gofumpt keep that blank
    # line for readability instead of removing it.
    source = (
        "package p\n"
        "\n"
        "func f(a, b bool) {\n"
        "\t%s a &&\n"
        "\t\tb {\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n" % header
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source


@pytest.mark.parametrize(
    "header",
    ["if", "for"],
)
def test_printer_joined_condition_loses_blank_line(run_gofumpt, tmp_path, header):
    """A condition the printer joins removes the blank after `{`."""
    # CATCHES: the source splits the condition after the `!`, but go/printer
    # joins `!` and its operand back onto one line, so the blank line after
    # the opening brace is dropped and the header collapses to `!x {`.
    source = (
        "package p\n"
        "\n"
        "func f(x bool) {\n"
        "\t%s !\n"
        "\t\tx {\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n" % header
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(x bool) {\n"
        "\t%s !x {\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n" % header
    )


def test_split_condition_still_drops_the_trailing_blank_line(run_gofumpt, tmp_path):
    """A multi-line condition keeps the leading blank but not the trailing one."""
    # CATCHES: only the blank line directly after the opening brace is
    # preserved for multi-line conditions; the blank line before the closing
    # brace is removed all the same, so the body's last statement sticks to
    # the `}`.
    source = (
        "package p\n"
        "\n"
        "func f(a, b bool) {\n"
        "\tif a &&\n"
        "\t\tb {\n"
        "\t\t_ = 1\n"
        "\n"
        "\t}\n"
        "}\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(a, b bool) {\n"
        "\tif a &&\n"
        "\t\tb {\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )


def test_commented_split_condition_keeps_blank_line(run_gofumpt, tmp_path):
    """An inline comment inside the split condition keeps the blank after `{`."""
    # CATCHES: the comment sharing the condition's first line makes the
    # condition print over multiple lines even though `a && b` would fit, so
    # the blank line after the opening brace survives and the comment stays
    # exactly where the source put it.
    source = (
        "package p\n"
        "\n"
        "func f(a, b bool) {\n"
        "\tif a && // c\n"
        "\t\tb {\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source


def test_two_statement_body_keeps_blank_line_after_brace(run_gofumpt, tmp_path):
    """The blank after `{` survives for two-statement bodies regardless."""
    # CATCHES: the blank-line removal after an opening brace only targets
    # single-statement bodies, so a body holding two statements keeps its
    # blank line even when the condition sits on one line.
    multi = (
        "package p\n"
        "\n"
        "func f(x bool) {\n"
        "\tif x {\n"
        "\n"
        "\t\t_ = 1\n"
        "\t\t_ = 2\n"
        "\t}\n"
        "}\n"
    )
    single = (
        "package p\n"
        "\n"
        "func f(x bool) {\n"
        "\tif x {\n"
        "\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    kept = write_go(tmp_path, multi)
    result = run_gofumpt(kept)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == multi
    dropped = write_go(tmp_path, single)
    result = run_gofumpt(dropped)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f(x bool) {\n"
        "\tif x {\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )


def test_func_body_blank_line_after_brace_is_removed(run_gofumpt, tmp_path):
    """A func body always loses the blank line right after `{`."""
    # CATCHES: unlike if/for blocks with multi-line conditions, a function
    # body has no condition to preserve a blank line, so the blank after the
    # opening brace is removed for its single statement.
    name = write_go(tmp_path, "package p\n\nfunc f() {\n\n\t_ = 1\n}\n")
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\nfunc f() {\n\t_ = 1\n}\n"


@pytest.mark.parametrize(
    "decl",
    [
        "type S struct{ x int }\n",
        "type I interface{ m() }\n",
    ],
    ids=["struct", "interface"],
)
def test_one_line_composite_type_with_single_member_stays(run_gofumpt, tmp_path, decl):
    """A one-line struct or interface with one member stays on one line."""
    # CATCHES: a single member prints on one line, so gofumpt keeps the whole
    # declaration collapsed instead of splitting the braces onto their own
    # lines like it does for multi-member one-liners.
    name = write_go(tmp_path, "package p\n\n" + decl)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\n" + decl


def test_spaced_one_line_struct_is_normalised_but_kept(run_gofumpt, tmp_path):
    """`struct { x int }` loses the stray space but stays on one line."""
    # CATCHES: the space between the keyword and the brace is dropped while
    # the single-field struct itself is still printed on one line, so the
    # output is `struct{ x int }` and not a split field list.
    name = write_go(tmp_path, "package p\n\ntype S struct { x int }\n")
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\ntype S struct{ x int }\n"


@pytest.mark.parametrize(
    "decl,formatted",
    [
        (
            "type S struct{ a int; b int }\n",
            "type S struct {\n\ta int\n\tb int\n}\n",
        ),
        (
            "type I interface{ a(); b() }\n",
            "type I interface {\n\ta()\n\tb()\n}\n",
        ),
    ],
    ids=["struct", "interface"],
)
def test_one_line_composite_type_with_two_members_is_split(
    run_gofumpt, tmp_path, decl, formatted
):
    """A one-line struct or interface with two members is split apart."""
    # CATCHES: two members on one line do not print on one line, so the brace
    # pair is split and every member gets a line of its own, with no -extra
    # flag involved.
    name = write_go(tmp_path, "package p\n\n" + decl)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\n" + formatted


def test_one_line_interface_with_inline_comment_splits_brace(run_gofumpt, tmp_path):
    """An interface holding an inline comment has its closing brace split off."""
    # CATCHES: the inline comment stops the interface from printing on one
    # line, so the closing brace moves onto its own line while the comment
    # stays on the opening line, mirroring what happens to structs.
    name = write_go(tmp_path, "package p\n\ntype I interface { /* c */ }\n")
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\ntype I interface { /* c */\n}\n"


@pytest.mark.parametrize(
    "keyword",
    ["var", "const"],
)
def test_lone_decl_spanning_lines_is_joined(run_gofumpt, tmp_path, keyword):
    """A lone `var`/`const` decl spread over lines collapses onto one line."""
    # CATCHES: the lone spec prints on one line, so the newlines between the
    # keyword, the name and the value are all removed and `var\nx =\n\t1`
    # comes out as `var x = 1` (same for const).
    source = "package p\n\n%s\nx =\n\t1\n" % keyword
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\n%s x = 1\n" % keyword


def test_lone_var_decl_with_multiline_spec_keeps_the_split(run_gofumpt, tmp_path):
    """A lone var whose spec prints multi-line only joins keyword and name."""
    # CATCHES: when the spec itself prints over multiple lines, like a
    # composite literal split across lines, the declaration is not collapsed
    # onto one line; only the keyword and the spec start are joined.
    source = "package p\n\nvar\nx = []int{\n\t1,\n}\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\nvar x = []int{\n\t1,\n}\n"


def test_comment_between_keyword_and_spec_blocks_the_join(run_gofumpt, tmp_path):
    """A line comment after the keyword keeps the spec on its own line."""
    # CATCHES: a comment that breaks the line between `var` and its spec
    # stops the lone declaration from being joined, so `var // c` keeps the
    # name below it instead of collapsing onto one line.
    source = "package p\n\nvar // c\nx = 1\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source


def test_adjacent_multiline_groups_gain_a_separator_line(run_gofumpt, tmp_path):
    """Two multi-line var groups on adjacent lines gain a blank line between."""
    # CATCHES: both groups print over multiple lines, so gofumpt separates
    # them with an empty line instead of leaving the second `var (` glued to
    # the first group's closing parenthesis.
    source = "package p\n\nvar (\n\tx = 1\n\ty = 2\n)\nvar (\n\tz = 3\n\tw = 4\n)\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "var (\n"
        "\tx = 1\n"
        "\ty = 2\n"
        ")\n"
        "\n"
        "var (\n"
        "\tz = 3\n"
        "\tw = 4\n"
        ")\n"
    )


def test_adjacent_single_spec_groups_are_merged(run_gofumpt, tmp_path):
    """Two single-spec var groups merge into one group."""
    # CATCHES: single-spec parenthesized groups are unwrapped and joined like
    # plain lone var lines, so the two groups collapse into a single `var (`
    # group holding all the specs rather than staying separate.
    source = "package p\n\nvar (\n\tx = 1\n)\nvar (\n\ty = 2\n)\n"
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\nvar (\n\tx = 1\n\ty = 2\n)\n"


def test_long_one_line_funcs_stay_adjacent_without_separator(run_gofumpt, tmp_path):
    """One-line funcs that still print on one line get no separating blank."""
    # CATCHES: however long their lines are, one-line func bodies that the
    # printer keeps on a single line are not considered multi-line, so no
    # blank line is inserted between the two adjacent declarations.
    source = (
        "package p\n"
        "\n"
        'func f() { _ = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" }\n'
        'func g() { _ = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb" }\n'
    )
    name = write_go(tmp_path, source)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == source
