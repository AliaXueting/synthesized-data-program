"""Symlink arguments: resolution, error reporting and write-through.

gofumpt's walk never follows symlinked directories, but a symlink named on
the command line (or a ``*.go`` symlink met during a walk) is opened like any
other file, which resolves through the link. These tests pin how the CLI
reports the two failure shapes of that resolution: a dangling link and a link
pointing at a directory.
"""

import os

import pytest

MESSY_A = "package p\nfunc  a( ) {\nx:=1\n}\n"
MESSY_A_FORMATTED = "package p\n\nfunc a() {\n\tx := 1\n}\n"
MESSY_B = "package q\nfunc  b( ) {\ny:=2\n}\n"
MESSY_B_FORMATTED = "package q\n\nfunc b() {\n\ty := 2\n}\n"


@pytest.fixture
def linked_tree(tmp_path):
    """Create real.go, link.go -> real.go and subdir/b.go, all messy."""
    (tmp_path / "real.go").write_text(MESSY_A)
    os.symlink("real.go", str(tmp_path / "link.go"))
    (tmp_path / "subdir").mkdir()
    (tmp_path / "subdir" / "b.go").write_text(MESSY_B)
    return tmp_path


def test_symlink_argument_formats_the_target_file(run_gofumpt, linked_tree):
    """A symlink named as an argument is read through to its target."""
    # CATCHES: the file is opened via the link, so the formatted contents of
    # the target are printed even though the argument names the link.
    result = run_gofumpt("link.go")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == MESSY_A_FORMATTED


def test_symlink_is_listed_under_its_own_name(run_gofumpt, linked_tree):
    """`-l` reports the symlink's name, not the target's."""
    # CATCHES: the walk tracks the name it was given, so the differing file
    # is listed as link.go even though the bytes compared belong to real.go.
    result = run_gofumpt("-l", "link.go")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == ["link.go"]


def test_write_flag_rewrites_through_a_symlink(run_gofumpt, linked_tree):
    """`-w` on a symlink rewrites the target and keeps the link itself."""
    # CATCHES: writing opens the path through the symlink, so real.go ends
    # up formatted while link.go remains a symlink, and no random backup
    # file is left behind next to either name.
    result = run_gofumpt("-w", "link.go")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.err == ""
    assert (linked_tree / "real.go").read_text() == MESSY_A_FORMATTED
    assert os.path.islink(str(linked_tree / "link.go"))
    assert (linked_tree / "link.go").read_text() == MESSY_A_FORMATTED
    assert sorted(p.name for p in linked_tree.iterdir()) == ["link.go", "real.go", "subdir"]


def test_dangling_symlink_argument_reports_open_error(run_gofumpt, tmp_path):
    """A symlink pointing nowhere fails with the raw open error and exit 2."""
    # CATCHES: the walk lstats the link itself so it looks like a file, and
    # only the later open of the missing target fails; the message is the
    # bare os.Open error with no filename prefix or usage text.
    os.symlink("missing.go", str(tmp_path / "dangling.go"))
    result = run_gofumpt("dangling.go")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "open dangling.go: no such file or directory\n"


def test_symlink_to_directory_argument_reports_read_error(run_gofumpt, tmp_path):
    """A symlink pointing at a directory fails with a read error and exit 2."""
    # CATCHES: the link itself is not a directory as far as the walk's lstat
    # is concerned, so it is treated as a file argument; opening it succeeds
    # but reading fails with EISDIR, reported as a bare error on stderr.
    (tmp_path / "subdir").mkdir()
    (tmp_path / "subdir" / "b.go").write_text(MESSY_B)
    os.symlink("subdir", str(tmp_path / "linkdir"))
    result = run_gofumpt("linkdir")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err == "read linkdir: is a directory\n"


def test_walk_continues_past_a_dangling_symlink(run_gofumpt, linked_tree):
    """A dangling symlink inside a walk errors, but the walk keeps going."""
    # CATCHES: the failing entry only contributes an error (exit 2) while
    # every other file in the tree is still listed, and the error line is
    # exactly the open error for the walked relative name.
    os.symlink("missing.go", str(linked_tree / "dangling.go"))
    result = run_gofumpt("-l", ".")
    assert result.returncode == 2
    assert result.err == "open dangling.go: no such file or directory\n"
    assert result.out_lines == ["link.go", "real.go", "subdir/b.go"]


def test_walk_formats_symlink_and_target_separately(run_gofumpt, linked_tree):
    """A walked *.go symlink and its target are both processed as files."""
    # CATCHES: the walk does not deduplicate a symlink against its target,
    # so the formatted target contents are printed twice, once per name,
    # before the subdirectory's file.
    result = run_gofumpt(".")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == MESSY_A_FORMATTED + MESSY_A_FORMATTED + MESSY_B_FORMATTED
