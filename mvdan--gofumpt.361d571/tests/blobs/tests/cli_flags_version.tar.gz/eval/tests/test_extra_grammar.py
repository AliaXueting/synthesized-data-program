"""The -extra flag grammar: boolean-ish values, rule subsets and overrides."""

import pytest

ALL = "group_params,clothe_returns,balance_calls"

#: One function exercising all three extra rules at once.
EXTRA_SOURCE = (
    "package p\n"
    "\n"
    "func f(a int, b int) (x int, err error) {\n"
    "\tg(\n"
    "\t\t1,\n"
    "\t\t2)\n"
    "\treturn\n"
    "}\n"
)

PLAIN = (
    "package p\n\nfunc f(a int, b int) (x int, err error) {\n"
    "\tg(\n\t\t1,\n\t\t2)\n\treturn\n}\n"
)
GROUPED = (
    "package p\n\nfunc f(a, b int) (x int, err error) {\n"
    "\tg(\n\t\t1,\n\t\t2)\n\treturn\n}\n"
)
CLOTHED = (
    "package p\n\nfunc f(a int, b int) (x int, err error) {\n"
    "\tg(\n\t\t1,\n\t\t2)\n\treturn x, err\n}\n"
)
BALANCED = (
    "package p\n\nfunc f(a int, b int) (x int, err error) {\n"
    "\tg(\n\t\t1,\n\t\t2,\n\t)\n\treturn\n}\n"
)
EVERYTHING = (
    "package p\n\nfunc f(a, b int) (x int, err error) {\n"
    "\tg(\n\t\t1,\n\t\t2,\n\t)\n\treturn x, err\n}\n"
)


def write_extra_file(tmp_path):
    path = tmp_path / "extra.go"
    path.write_text(EXTRA_SOURCE)
    return path.name


def test_extra_bare_flag_enables_all_three_rules(run_gofumpt, diag_file):
    """A bare `-extra` turns on group_params, clothe_returns and balance_calls."""
    # CATCHES: -extra is registered as a boolean-ish flag, so it needs no
    # `=value` and defaults to enabling every extra rule.
    result = run_gofumpt("-extra", diag_file)
    assert result.returncode == 0
    assert result.err == ""
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=%s" % ALL


def test_extra_true_enables_all_three_rules(run_gofumpt, diag_file):
    """`-extra=true` is the explicit spelling of "enable every extra rule"."""
    # CATCHES: the literal string "true" is special-cased to mean all rules
    # rather than being parsed as a rule name.
    result = run_gofumpt("-extra=true", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=%s" % ALL


def test_extra_false_disables_all_rules(run_gofumpt, diag_file):
    """`-extra=false` leaves the default (no extra rules) state in place."""
    # CATCHES: "false" clears the rule set; the diagnose dump then omits the
    # -extra=... part entirely instead of printing an empty value.
    result = run_gofumpt("-extra=false", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath="


def test_extra_without_flag_leaves_rules_off(run_gofumpt, diag_file):
    """With no -extra flag at all, the diagnose dump reports no extra rules."""
    # CATCHES: the default state has no extra rule enabled and no -extra=
    # token in the flag dump, which is what a fresh flag value must produce.
    result = run_gofumpt(diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath="


@pytest.mark.parametrize(
    "rule",
    ["group_params", "clothe_returns", "balance_calls"],
)
def test_extra_single_rule_enables_only_that_rule(run_gofumpt, diag_file, rule):
    """`-extra=<name>` enables exactly one rule and leaves the others off."""
    # CATCHES: the comma grammar names individual rules, so selecting one must
    # not silently enable its siblings.
    result = run_gofumpt("-extra=%s" % rule, diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=%s" % rule


def test_extra_rule_pair_enables_only_that_subset(run_gofumpt, diag_file):
    """`-extra=group_params,clothe_returns` enables a two-rule subset."""
    # CATCHES: comma-separated lists are unions, and the reported order is the
    # canonical field order rather than the order typed by the user.
    result = run_gofumpt("-extra=group_params,clothe_returns", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == (
        "-lang=go1 -modpath= -extra=group_params,clothe_returns"
    )


def test_extra_reversed_order_is_normalised(run_gofumpt, diag_file):
    """Listing all rules in a shuffled order still reports the canonical order."""
    # CATCHES: the rule set is a struct of booleans, so the diagnose dump
    # prints group_params,clothe_returns,balance_calls regardless of input.
    result = run_gofumpt("-extra=balance_calls,group_params,clothe_returns", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=%s" % ALL


def test_extra_explicit_all_equals_true(run_gofumpt, diag_file):
    """Naming all three rules explicitly equals `-extra=true`."""
    # CATCHES: there is no hidden "all" token; the full list and "true" must
    # produce identical flag state.
    listed = run_gofumpt("-extra=%s" % ALL, diag_file)
    literal = run_gofumpt("-extra=true", diag_file)
    assert listed.returncode == 0
    assert listed.diagnose_flags() == literal.diagnose_flags()
    assert listed.diagnose_flags().endswith(ALL)


def test_extra_repeated_rule_name_is_harmless(run_gofumpt, diag_file):
    """`-extra=group_params,group_params` still reports a single rule."""
    # CATCHES: the grammar is idempotent per name, so duplicates collapse
    # instead of erroring or duplicating output.
    result = run_gofumpt("-extra=group_params,group_params", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=group_params"


def test_extra_double_dash_form(run_gofumpt, diag_file):
    """`--extra=group_params` works exactly like the single-dash spelling."""
    # CATCHES: the Go flag package accepts two leading dashes for every flag,
    # including the Var-registered -extra.
    result = run_gofumpt("--extra=group_params", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=group_params"


def test_extra_unknown_rule_is_a_flag_error(run_gofumpt):
    """`-extra=bogus` fails with `unknown rule:` plus usage and exit 2."""
    # CATCHES: the flag package wraps the Set error, so the message is
    # `invalid boolean value "bogus" for -extra: unknown rule: "bogus"` and is
    # followed by the usage text; nothing is formatted.
    result = run_gofumpt("-extra=bogus")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err.startswith(
        'invalid boolean value "bogus" for -extra: unknown rule: "bogus"\n'
    )
    assert "usage: gofumpt [flags] [path ...]" in result.err


def test_extra_unknown_rule_in_a_list_names_the_offender(run_gofumpt):
    """A bad name inside a list is reported while the good names are dropped."""
    # CATCHES: validation walks the comma-separated pieces in order and reports
    # the first unknown one; the whole flag value is still rejected.
    result = run_gofumpt("-extra=group_params,bogus")
    assert result.returncode == 2
    assert result.stdout == b""
    assert result.err.startswith(
        'invalid boolean value "group_params,bogus" for -extra: unknown rule: "bogus"\n'
    )


def test_extra_trailing_comma_is_an_unknown_empty_rule(run_gofumpt):
    """`-extra=group_params,` fails because the empty name is unknown."""
    # CATCHES: splitting is naive, so an empty trailing piece is validated as
    # a rule name and reported as `unknown rule: ""`.
    result = run_gofumpt("-extra=group_params,")
    assert result.returncode == 2
    assert result.err.startswith(
        'invalid boolean value "group_params," for -extra: unknown rule: ""\n'
    )


@pytest.mark.parametrize("value", ["TRUE", "True", "1", "0", "yes", "all"])
def test_extra_non_boolean_spellings_are_rejected(run_gofumpt, value):
    """Only the exact strings true/false and rule names are accepted."""
    # CATCHES: the value is case-sensitive and not parsed with strconv.Bool,
    # so TRUE/1/0/yes/all all fall through to the unknown-rule error.
    result = run_gofumpt("-extra=%s" % value)
    assert result.returncode == 2
    assert result.stdout == b""
    assert 'unknown rule: "%s"' % value in result.err
    assert "usage: gofumpt [flags] [path ...]" in result.err


def test_extra_repeated_flags_last_one_wins_subset(run_gofumpt, diag_file):
    """A later `-extra=group_params` after a bare `-extra` keeps only that rule."""
    # CATCHES: each -extra occurrence resets the rule set before applying its
    # own value, so the last flag wins instead of accumulating.
    result = run_gofumpt("-extra", "-extra=group_params", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=group_params"


def test_extra_repeated_flags_last_one_wins_all(run_gofumpt, diag_file):
    """A bare `-extra` after `-extra=group_params` re-enables every rule."""
    # CATCHES: overriding works in both directions, from a subset back to the
    # full rule set.
    result = run_gofumpt("-extra=group_params", "-extra", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=%s" % ALL


def test_extra_repeated_flags_true_then_false(run_gofumpt, diag_file):
    """`-extra=true -extra=false` ends up with no extra rules enabled."""
    # CATCHES: "false" clears the whole set, so the final state is the default
    # one even though an earlier flag turned everything on.
    result = run_gofumpt("-extra=true", "-extra=false", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath="


def test_extra_repeated_flags_subset_then_other_subset(run_gofumpt, diag_file):
    """`-extra=group_params -extra=clothe_returns` keeps only clothe_returns."""
    # CATCHES: later flags replace rather than merge, so the earlier
    # group_params selection must be gone.
    result = run_gofumpt("-extra=group_params", "-extra=clothe_returns", diag_file)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath= -extra=clothe_returns"


def test_extra_bare_flag_formats_with_all_rules(run_gofumpt, tmp_path):
    """A bare `-extra` makes all three extra rewrites visible in the output."""
    # CATCHES: the flag must actually reach the formatter, changing parameter
    # grouping, naked returns and the multi-line call's closing parenthesis.
    name = write_extra_file(tmp_path)
    result = run_gofumpt("-extra", name)
    assert result.returncode == 0
    assert result.out == EVERYTHING


def test_extra_false_leaves_source_untouched(run_gofumpt, tmp_path):
    """`-extra=false` keeps the default formatting for the same source."""
    # CATCHES: explicitly disabling must reproduce the no-flag output exactly.
    name = write_extra_file(tmp_path)
    result = run_gofumpt("-extra=false", name)
    assert result.returncode == 0
    assert result.out == PLAIN


@pytest.mark.parametrize(
    "value,expected",
    [
        ("group_params", GROUPED),
        ("clothe_returns", CLOTHED),
        ("balance_calls", BALANCED),
    ],
)
def test_extra_each_rule_has_its_own_formatting_effect(
    run_gofumpt, tmp_path, value, expected
):
    """Each single-rule -extra value triggers only its own rewrite."""
    # CATCHES: the grammar maps names to independent rules, so enabling one
    # must not apply the transformations owned by the other two.
    name = write_extra_file(tmp_path)
    result = run_gofumpt("-extra=%s" % value, name)
    assert result.returncode == 0
    assert result.out == expected


def test_extra_pair_applies_both_rewrites(run_gofumpt, tmp_path):
    """`-extra=group_params,clothe_returns` applies both and only those rules."""
    # CATCHES: the union of a subset is visible in the output: parameters are
    # grouped and the return is clothed, but the call stays unbalanced.
    name = write_extra_file(tmp_path)
    result = run_gofumpt("-extra=group_params,clothe_returns", name)
    assert result.returncode == 0
    assert result.out == (
        "package p\n\nfunc f(a, b int) (x int, err error) {\n"
        "\tg(\n\t\t1,\n\t\t2)\n\treturn x, err\n}\n"
    )


def test_extra_flag_does_not_change_exit_status(run_gofumpt, tmp_path):
    """-extra with a clean file still exits 0 with empty stderr."""
    # CATCHES: enabling extra rules must not be mistaken for an error; the
    # run stays successful and reports nothing on stderr.
    name = write_extra_file(tmp_path)
    result = run_gofumpt("-extra=true", name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == EVERYTHING
