"""go.mod integration: -lang/-modpath defaults, nested modules, ignore directives.

gofumpt consults the go.mod enclosing each processed file for the default
-lang (the `go` directive), the default -modpath (the `module` directive) and
the `ignore` directives that prune recursive walks. All of this is invisible
to the flag parser itself, so every test here observes the resolved state
through the ``//gofumpt:diagnose`` comment or through formatting effects that
are gated on those values.
"""

import pytest

#: A diagnose-carrying file: when the gofumpt rules run, the directive is
#: rewritten into a dump of the resolved flag state.
DIAG_SOURCE = "package p\n\n//gofumpt:diagnose\n\nfunc f() {}\n"

#: Version-gated source: 0755 only becomes 0o755 when -lang >= go1.13.
OCTAL_SOURCE = "package p\n\nvar x = 0755\n"

#: Messy sources used to make -l list the files that a walk actually reaches.
MESSY_A = "package p\nfunc  a( ) {\nx:=1\n}\n"
MESSY_A_FORMATTED = "package p\n\nfunc a() {\n\tx := 1\n}\n"
MESSY_G = "package g\nfunc  x( ) {\nx:=1\n}\n"
MESSY_S = "package s\nfunc  y( ) {\ny:=2\n}\n"
MESSY_P = "package q\nfunc  z( ) {\nz:=3\n}\n"
MESSY_P_FORMATTED = "package q\n\nfunc z() {\n\tz := 3\n}\n"
MESSY_W = "package ag\nfunc  w( ) {\nw:=4\n}\n"
MESSY_W_FORMATTED = "package ag\n\nfunc w() {\n\tw := 4\n}\n"

#: Import grouping source: with -modpath=mypkg the "mypkg/foo" import is
#: pulled into the third-party group next to "example.com/x".
IMPORTS_SOURCE = (
    "package p\n"
    "\n"
    "import (\n"
    '\t"example.com/x"\n'
    '\t"mypkg/foo"\n'
    '\t"fmt"\n'
    ")\n"
)
IMPORTS_WITH_MODPATH = (
    'package p\n\nimport (\n\t"fmt"\n\n\t"example.com/x"\n\t"mypkg/foo"\n)\n'
)

#: Files reachable in the canonical module tree when nothing is ignored.
ALL_LISTED = ["a/gen/w.go", "a.go", "gen/sub/y.go", "gen/x.go", "plain/z.go"]


def write_diag(directory, name="diag.go"):
    """Write a diagnose-carrying file into directory and return its name."""
    (directory / name).write_text(DIAG_SOURCE)
    return name


@pytest.fixture
def module_tree(tmp_path):
    """Create the canonical module tree: a.go, gen/, gen/sub/, plain/, a/gen/.

    Every Go file holds messy source so ``-l`` lists exactly the files the
    walk reaches. The go.mod content is written by each test.
    """
    (tmp_path / "a.go").write_text(MESSY_A)
    (tmp_path / "gen").mkdir()
    (tmp_path / "gen" / "x.go").write_text(MESSY_G)
    (tmp_path / "gen" / "sub").mkdir()
    (tmp_path / "gen" / "sub" / "y.go").write_text(MESSY_S)
    (tmp_path / "plain").mkdir()
    (tmp_path / "plain" / "z.go").write_text(MESSY_P)
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "gen").mkdir()
    (tmp_path / "a" / "gen" / "w.go").write_text(MESSY_W)
    return tmp_path


@pytest.fixture
def go_mod(tmp_path):
    """Return a helper that writes the module's go.mod."""

    def _write(text):
        (tmp_path / "go.mod").write_text(text)

    return _write


@pytest.mark.parametrize(
    "directive,lang",
    [("go 1.12", "go1.12"), ("go 1.13", "go1.13"), ("go 1.21.0", "go1.21")],
)
def test_lang_defaults_to_the_go_directive(run_gofumpt, tmp_path, go_mod, directive, lang):
    """The `go` directive of the enclosing go.mod becomes the default -lang."""
    # CATCHES: -lang is resolved from go.mod when the flag is absent, and a
    # patch release like `go 1.21.0` is normalised down to go1.21.
    go_mod("module example.com/foo\n%s\n" % directive)
    diag = write_diag(tmp_path)
    result = run_gofumpt(diag)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=%s -modpath=example.com/foo" % lang


def test_modpath_defaults_to_the_module_directive(run_gofumpt, tmp_path, go_mod):
    """The `module` directive becomes the default -modpath."""
    # CATCHES: with no -modpath flag the module path reaches the formatter,
    # and a go.mod without a `go` directive still defaults the lang to go1.16.
    go_mod("module example.com/foo\n")
    diag = write_diag(tmp_path)
    result = run_gofumpt(diag)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.16 -modpath=example.com/foo"


@pytest.mark.parametrize("content", ["", "go 1.16\n"])
def test_go_mod_without_module_directive_keeps_modpath_empty(
    run_gofumpt, tmp_path, go_mod, content
):
    """A go.mod lacking a `module` line leaves -modpath at the empty default."""
    # CATCHES: only a real `module` directive feeds -modpath; a bare `go`
    # directive (or an empty go.mod) must not invent a module path.
    go_mod(content)
    diag = write_diag(tmp_path)
    result = run_gofumpt(diag)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.16 -modpath="


@pytest.mark.parametrize(
    "content",
    [
        "nonsense directive here\n",
        "go 1.x\n",
        "module\n",
        "go\n",
        "module example.com/foo\ngo 1.16\nignore ./gen extra\n",
    ],
)
def test_invalid_go_mod_falls_back_to_the_bare_defaults(
    run_gofumpt, tmp_path, go_mod, content
):
    """A go.mod that fails to parse is ignored: -lang=go1 and no -modpath."""
    # CATCHES: modfile parse errors (unknown verb, bad version, missing or
    # extra arguments) silently disable the go.mod defaults rather than
    # failing the run.
    go_mod(content)
    diag = write_diag(tmp_path)
    result = run_gofumpt(diag)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1 -modpath="


def test_lang_flag_overrides_the_go_mod_version(run_gofumpt, tmp_path, go_mod):
    """An explicit -lang wins over the go.mod `go` directive."""
    # CATCHES: the flag value replaces the go.mod default, so a go1.13 module
    # formatted with -lang=go1.12 keeps the legacy octal spelling.
    go_mod("module example.com/foo\ngo 1.13\n")
    (tmp_path / "oct.go").write_text(OCTAL_SOURCE)
    result = run_gofumpt("-lang=go1.12", "oct.go")
    assert result.returncode == 0
    assert result.out == OCTAL_SOURCE
    assert result.err == ""


def test_lang_flag_override_is_visible_in_the_flag_state(run_gofumpt, tmp_path, go_mod):
    """The diagnose dump shows the flag's -lang next to go.mod's -modpath."""
    # CATCHES: -lang and -modpath are resolved independently, so overriding
    # one still leaves the other sourced from go.mod.
    go_mod("module example.com/foo\ngo 1.12\n")
    diag = write_diag(tmp_path)
    result = run_gofumpt("-lang=go1.14", diag)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.14 -modpath=example.com/foo"


def test_modpath_flag_overrides_the_go_mod_module(run_gofumpt, tmp_path, go_mod):
    """An explicit -modpath wins over the go.mod `module` directive."""
    # CATCHES: the flag value replaces the module path while the lang still
    # comes from the `go` directive.
    go_mod("module example.com/foo\ngo 1.12\n")
    diag = write_diag(tmp_path)
    result = run_gofumpt("-modpath=other.example/bar", diag)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.12 -modpath=other.example/bar"


def test_both_flags_given_leave_go_mod_unused(run_gofumpt, tmp_path, go_mod):
    """With -lang and -modpath both set, go.mod contributes nothing."""
    # CATCHES: the go.mod lookup only fills in missing values, so a fully
    # flagged invocation reports exactly the flag values.
    go_mod("module example.com/foo\ngo 1.12\n")
    diag = write_diag(tmp_path)
    result = run_gofumpt("-lang=go1.19", "-modpath=other.example/bar", diag)
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.19 -modpath=other.example/bar"


def test_go_mod_in_parent_directory_applies_to_subdir_file(run_gofumpt, tmp_path, go_mod):
    """A file in a subdirectory picks up the go.mod living above it."""
    # CATCHES: the go.mod search walks up from the file's directory, so
    # sub/ files resolve the same module defaults as the root files.
    go_mod("module example.com/foo\ngo 1.12\n")
    sub = tmp_path / "sub"
    sub.mkdir()
    write_diag(sub)
    result = run_gofumpt("sub/diag.go")
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.12 -modpath=example.com/foo"


def test_stdin_resolves_go_mod_from_the_working_directory(run_gofumpt, tmp_path, go_mod):
    """Standard input is treated as <standard input> inside the cwd's module."""
    # CATCHES: stdin has no real directory, so its go.mod is looked up from
    # the working directory, exactly like a file named <standard input> there.
    go_mod("module example.com/foo\ngo 1.12\n")
    result = run_gofumpt(stdin=DIAG_SOURCE.encode())
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.12 -modpath=example.com/foo"


def test_stdin_in_subdir_resolves_parent_go_mod(run_gofumpt, tmp_path, go_mod):
    """Stdin run from a subdirectory still finds the module go.mod above."""
    # CATCHES: the parent-walking go.mod search applies to the synthetic
    # <standard input> path as well, not only to real files.
    go_mod("module example.com/foo\ngo 1.13\n")
    sub = tmp_path / "sub"
    sub.mkdir()
    result = run_gofumpt(cwd=sub, stdin=DIAG_SOURCE.encode())
    assert result.returncode == 0
    assert result.diagnose_flags() == "-lang=go1.13 -modpath=example.com/foo"


@pytest.mark.parametrize(
    "directive,expected",
    [
        ("go 1.12", OCTAL_SOURCE),
        ("go 1.13", "package p\n\nvar x = 0o755\n"),
        ("module example.com/foo", "package p\n\nvar x = 0o755\n"),
    ],
)
def test_octal_literals_follow_the_go_mod_language_version(
    run_gofumpt, tmp_path, go_mod, directive, expected
):
    """The go.mod-resolved -lang gates the version-dependent octal rewrite."""
    # CATCHES: the go.mod `go` directive is not cosmetic; it changes real
    # formatting output exactly like passing -lang on the command line.
    go_mod("%s\n" % directive)
    (tmp_path / "oct.go").write_text(OCTAL_SOURCE)
    result = run_gofumpt("oct.go")
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_import_grouping_uses_the_go_mod_module_path(run_gofumpt, tmp_path, go_mod):
    """The go.mod module path drives the import grouping heuristic."""
    # CATCHES: `mypkg/foo` is only pulled out of the standard-library group
    # when the resolved -modpath is mypkg, which here comes from go.mod.
    go_mod("module mypkg\ngo 1.16\n")
    (tmp_path / "imp.go").write_text(IMPORTS_SOURCE)
    result = run_gofumpt("imp.go")
    assert result.returncode == 0
    assert result.out == IMPORTS_WITH_MODPATH
    assert result.err == ""


def test_flag_and_go_mod_state_combine_in_diagnose(run_gofumpt, tmp_path, go_mod):
    """-extra combines with go.mod-sourced -lang and -modpath in one dump."""
    # CATCHES: the three values are resolved from different sources (flag,
    # go.mod, go.mod) yet reported together as one flag state.
    go_mod("module example.com/foo\ngo 1.16\n")
    diag = write_diag(tmp_path)
    result = run_gofumpt("-extra=group_params", diag)
    assert result.returncode == 0
    assert result.diagnose_flags() == (
        "-lang=go1.16 -modpath=example.com/foo -extra=group_params"
    )


def test_nested_module_file_uses_the_nearest_go_mod(run_gofumpt, tmp_path):
    """A file in a nested module resolves that module's go.mod, not the outer."""
    # CATCHES: the go.mod search starts at the file's own directory, so the
    # inner module's directives shadow the enclosing module's.
    (tmp_path / "go.mod").write_text("module example.com/outer\ngo 1.12\n")
    inner = tmp_path / "inner"
    inner.mkdir()
    (inner / "go.mod").write_text("module example.com/inner\ngo 1.17\n")
    write_diag(tmp_path)
    write_diag(inner)
    outer = run_gofumpt("diag.go")
    inner = run_gofumpt("inner/diag.go")
    assert outer.returncode == 0
    assert outer.diagnose_flags() == "-lang=go1.12 -modpath=example.com/outer"
    assert inner.returncode == 0
    assert inner.diagnose_flags() == "-lang=go1.17 -modpath=example.com/inner"


def test_ignore_rooted_path_skips_directory_during_walk(run_gofumpt, module_tree, go_mod):
    """`ignore ./gen` prunes gen/ from a recursive walk of the module root."""
    # CATCHES: the go.mod ignore directive removes the directory (and its
    # whole subtree) from the walk while every other directory is still
    # reached, in the same lexical order as without a module.
    go_mod("module example.com/foo\ngo 1.16\nignore ./gen\n")
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == ["a/gen/w.go", "a.go", "plain/z.go"]


def test_ignore_targets_subdirectory_only(run_gofumpt, module_tree, go_mod):
    """`ignore ./gen/sub` prunes only that subdirectory, not gen/ itself."""
    # CATCHES: a rooted ignore path matches the exact directory only, so
    # gen/x.go is still formatted while gen/sub/y.go disappears.
    go_mod("module example.com/foo\ngo 1.16\nignore ./gen/sub\n")
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.out_lines == ["a/gen/w.go", "a.go", "gen/x.go", "plain/z.go"]


def test_ignored_directory_named_explicitly_is_still_formatted(
    run_gofumpt, module_tree, go_mod
):
    """Naming the ignored directory directly formats everything under it."""
    # CATCHES: the walk root itself is never ignore-checked, and the rooted
    # `./gen` does not extend to `gen/sub`, so both files are reached and
    # listed in walk order (sub/ before x.go).
    go_mod("module example.com/foo\ngo 1.16\nignore ./gen\n")
    result = run_gofumpt("-l", "gen")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == ["gen/sub/y.go", "gen/x.go"]


def test_ignore_unrooted_matches_at_any_depth(run_gofumpt, module_tree, go_mod):
    """`ignore gen` (no ./ prefix) suffix-matches gen/ at every depth."""
    # CATCHES: an unrooted ignore path matches any directory whose path ends
    # with /gen/, so both gen/ and a/gen/ vanish from the walk.
    go_mod("module example.com/foo\ngo 1.16\nignore gen\n")
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.out_lines == ["a.go", "plain/z.go"]


def test_multiple_ignore_directives_all_apply(run_gofumpt, module_tree, go_mod):
    """Several `ignore` lines each prune their own directory."""
    # CATCHES: every ignore directive in the go.mod is honoured in one walk,
    # not just the first or the last one.
    go_mod("module example.com/foo\ngo 1.16\nignore ./gen\nignore ./plain\n")
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.out_lines == ["a/gen/w.go", "a.go"]


def test_ignore_quoted_path_is_unquoted(run_gofumpt, module_tree, go_mod):
    """A quoted `ignore "./gen"` behaves exactly like the bare spelling."""
    # CATCHES: the go.mod string literal is unquoted during parsing, so the
    # ignore still matches the gen/ directory during the walk.
    go_mod('module example.com/foo\ngo 1.16\nignore "./gen"\n')
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.out_lines == ["a/gen/w.go", "a.go", "plain/z.go"]


def test_ignore_with_two_arguments_invalidates_the_go_mod(
    run_gofumpt, module_tree, go_mod
):
    """`ignore` with two arguments fails go.mod parsing, disabling it all."""
    # CATCHES: the malformed directive does not just drop that one line; the
    # whole go.mod is rejected, so nothing is ignored and the defaults fall
    # back to -lang=go1 with an empty -modpath.
    go_mod("module example.com/foo\ngo 1.16\nignore ./gen extra\n")
    listed = run_gofumpt("-l", ".")
    assert listed.returncode == 0
    assert listed.out_lines == ALL_LISTED
    diag = write_diag(module_tree)
    diagnosed = run_gofumpt(diag)
    assert diagnosed.returncode == 0
    assert diagnosed.diagnose_flags() == "-lang=go1 -modpath="


def test_ignore_directive_for_missing_path_is_harmless(run_gofumpt, module_tree, go_mod):
    """An `ignore` path that matches nothing changes no walk results."""
    # CATCHES: unmatched ignore entries are simply skipped, and the walk
    # still reaches every directory of the module.
    go_mod("module example.com/foo\ngo 1.16\nignore ./nosuch\n")
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.out_lines == ALL_LISTED


def test_write_walk_skips_ignored_directories(run_gofumpt, module_tree, go_mod):
    """`-w` over the module root rewrites everything but the ignored dir."""
    # CATCHES: the ignore pruning happens during the walk, before any file
    # is opened for writing, so gen/x.go keeps its original messy bytes.
    go_mod("module example.com/foo\ngo 1.16\nignore ./gen\n")
    result = run_gofumpt("-w", ".")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.err == ""
    assert (module_tree / "a.go").read_text() == MESSY_A_FORMATTED
    assert (module_tree / "plain" / "z.go").read_text() == MESSY_P_FORMATTED
    assert (module_tree / "a" / "gen" / "w.go").read_text() == MESSY_W_FORMATTED
    assert (module_tree / "gen" / "x.go").read_text() == MESSY_G
    assert (module_tree / "gen" / "sub" / "y.go").read_text() == MESSY_S


def test_walk_from_parent_directory_honours_ignore(run_gofumpt, tmp_path):
    """Walking the module directory from its parent still applies ignore."""
    # CATCHES: the ignore check resolves absolute paths before consulting
    # go.mod, so it works no matter which directory the walk is started from,
    # and the reported names keep the mod/ prefix of the argument.
    mod = tmp_path / "mod"
    (mod / "gen").mkdir(parents=True)
    (mod / "plain").mkdir()
    (mod / "a.go").write_text(MESSY_A)
    (mod / "gen" / "x.go").write_text(MESSY_G)
    (mod / "plain" / "z.go").write_text(MESSY_P)
    (mod / "go.mod").write_text("module example.com/foo\ngo 1.16\nignore ./gen\n")
    result = run_gofumpt("-l", "mod")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == ["mod/a.go", "mod/plain/z.go"]


def test_nested_go_mod_shadows_outer_ignore(run_gofumpt, module_tree, go_mod):
    """A directory with its own go.mod escapes an outer rooted ignore."""
    # CATCHES: shouldIgnore consults the go.mod nearest to the directory
    # being visited, so a nested module directory is never matched against
    # the enclosing module's `ignore ./a/gen` line.
    go_mod("module example.com/foo\ngo 1.16\nignore ./a/gen\n")
    (module_tree / "a" / "gen" / "go.mod").write_text("module example.com/foo/sub\n")
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.err == ""
    assert result.out_lines == ALL_LISTED


def test_vendor_and_testdata_remain_skipped_inside_a_module(
    run_gofumpt, module_tree, go_mod
):
    """vendor/ and testdata/ are pruned by name even inside a module."""
    # CATCHES: the base-name check runs before any go.mod consultation, so a
    # module walk still skips vendor/ and testdata/ directories.
    go_mod("module example.com/foo\ngo 1.16\n")
    (module_tree / "vendor").mkdir()
    (module_tree / "vendor" / "v.go").write_text(MESSY_G)
    (module_tree / "testdata").mkdir()
    (module_tree / "testdata" / "t.go").write_text(MESSY_S)
    result = run_gofumpt("-l", ".")
    assert result.returncode == 0
    assert result.out_lines == ALL_LISTED


def test_generated_marker_after_package_clause_is_not_generated(run_gofumpt, tmp_path):
    """A `// Code generated` marker after the package clause is ignored."""
    # CATCHES: generated-file detection only scans comment groups that start
    # before the package keyword, so a marker placed after it leaves the
    # gofumpt rules enabled for a file found by a walk: the diagnose
    # directive is rewritten and the octal literal modernised.
    after_dir = tmp_path / "wa"
    after_dir.mkdir()
    (after_dir / "after.go").write_text(
        "package p\n\n// Code generated by tool. DO NOT EDIT.\n\n"
        "//gofumpt:diagnose\n\nvar x = 0755\n"
    )
    after = run_gofumpt("-lang=go1.16", "wa")
    assert after.returncode == 0
    assert after.err == ""
    assert after.diagnose_flags() == "-lang=go1.16 -modpath="
    directive_lines = [
        line for line in after.out_lines if line.startswith("//gofumpt:")
    ]
    assert len(directive_lines) == 1
    assert directive_lines[0].endswith("flags: -lang=go1.16 -modpath=")
    assert after.out_lines[-1] == "var x = 0o755"

    before_dir = tmp_path / "wb"
    before_dir.mkdir()
    (before_dir / "before.go").write_text(
        "// Code generated by tool. DO NOT EDIT.\n\npackage p\n\n"
        "//gofumpt:diagnose\n\nvar x = 0755\n"
    )
    before = run_gofumpt("-lang=go1.16", "wb")
    assert before.returncode == 0
    assert before.err == ""
    assert before.out == (
        "// Code generated by tool. DO NOT EDIT.\n\npackage p\n\n"
        "//gofumpt:diagnose\n\nvar x = 0755\n"
    )
