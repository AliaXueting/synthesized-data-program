"""CLI-observable behaviors routed through the vendored go/format helper.

The round-2 coverage target is internal/govendor/go/format/format.go.  The CLI
never calls its Source entry point; it reaches the vendored format.Node only
through gofumpt's internal probes ("does this node print on one line?", "how
long would this node print?") and through the -extra=group_params type
comparison, which prints both field types to decide whether they match.  The
tests below pin the CLI-visible consequences of those probes.
"""

import pytest


def write_go(tmp_path, source):
    """Write a Go source file into ``tmp_path`` and return its name."""
    path = tmp_path / "src.go"
    path.write_text(source)
    return path.name


def test_one_line_switch_funcs_are_split_and_separated(run_gofumpt, tmp_path):
    """One-line funcs holding a switch are split and separated by a blank line."""
    # CATCHES: whether a declaration counts as multi-line is decided by how the
    # printer renders it, not by its source lines: a switch body always prints
    # split, so both funcs are expanded and gain the blank separator between
    # them even though each fits on one source line.
    name = write_go(
        tmp_path,
        "package p\n"
        "\n"
        "func f() { switch x { case 1: } }\n"
        "func g() { switch y { case 2: } }\n",
    )
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == (
        "package p\n"
        "\n"
        "func f() {\n"
        "\tswitch x {\n"
        "\tcase 1:\n"
        "\t}\n"
        "}\n"
        "\n"
        "func g() {\n"
        "\tswitch y {\n"
        "\tcase 2:\n"
        "\t}\n"
        "}\n"
    )


def test_one_line_struct_with_comment_is_split(run_gofumpt, tmp_path):
    """A one-line struct holding a comment has its closing brace split off."""
    # CATCHES: the printer cannot keep a commented struct type on one line, so
    # the closing brace moves onto its own line while the comment stays on the
    # opening line, instead of the whole declaration staying on one line.
    name = write_go(tmp_path, "package p\n\ntype T struct { /* c */ }\n")
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\ntype T struct { /* c */\n}\n"


@pytest.mark.parametrize(
    "body,formatted",
    [
        ("type T struct {\n}\n", "type T struct{}\n"),
        ("var x = []int{\n}\n", "var x = []int{}\n"),
        ("func h() {\n\tf(\n\t)\n}\n", "func h() {\n\tf()\n}\n"),
    ],
    ids=["struct", "composite", "call"],
)
def test_empty_brace_pairs_are_joined(run_gofumpt, tmp_path, body, formatted):
    """An empty pair of braces or parentheses never keeps its newline."""
    # CATCHES: whatever the node kind, an empty field list, composite literal
    # or call is joined onto one line rather than keeping the split the source
    # used, so the closing token lands right after the opening one.
    name = write_go(tmp_path, "package p\n\n" + body)
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\n" + formatted


def test_multiline_lone_type_decl_is_joined(run_gofumpt, tmp_path):
    """A lone `type` declaration spread over lines is joined onto one line."""
    # CATCHES: a declaration spanning several source lines is joined back
    # together when the printer would render its single spec on one line, so
    # the keyword and the spec end up on the same line.
    name = write_go(tmp_path, "package p\n\ntype\nT int\n")
    result = run_gofumpt(name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\ntype T int\n"


def test_short_case_split_is_collapsed_but_a_long_one_is_not(run_gofumpt, tmp_path):
    """A case expression split over lines is collapsed only when short enough."""
    # CATCHES: the collapse of a split case header is bounded by the printed
    # length of the clause: `case\\n1:` becomes `case 1:`, while a selector
    # long enough to overshoot the limit keeps its own line after `case`.
    short = write_go(
        tmp_path,
        "package p\n"
        "\n"
        "func h() {\n"
        "\tswitch x {\n"
        "\tcase\n"
        "\t1:\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n",
    )
    collapsed = run_gofumpt(short)
    assert collapsed.returncode == 0
    assert collapsed.err == ""
    assert collapsed.out == (
        "package p\n"
        "\n"
        "func h() {\n"
        "\tswitch x {\n"
        "\tcase 1:\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    long_source = (
        "package p\n"
        "\n"
        "func h() {\n"
        "\tswitch x {\n"
        "\tcase\n"
        "\t\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.bbbb:\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    kept = write_go(tmp_path, long_source)
    uncollapsed = run_gofumpt(kept)
    assert uncollapsed.returncode == 0
    assert uncollapsed.err == ""
    assert uncollapsed.out == long_source


def test_case_inline_comment_counts_toward_the_collapse_limit(run_gofumpt, tmp_path):
    """An inline comment after the colon is measured when deciding to collapse."""
    # CATCHES: the comment sharing the case header's line adds to its printed
    # length, so a short one still collapses onto `case 1: // c` while a long
    # one keeps the split header and re-indents the expression as a
    # continuation line one level under `case`.
    short = write_go(
        tmp_path,
        "package p\n"
        "\n"
        "func h() {\n"
        "\tswitch x {\n"
        "\tcase\n"
        "\t1: // c\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n",
    )
    collapsed = run_gofumpt(short)
    assert collapsed.returncode == 0
    assert collapsed.err == ""
    assert collapsed.out == (
        "package p\n"
        "\n"
        "func h() {\n"
        "\tswitch x {\n"
        "\tcase 1: // c\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    long_input = (
        "package p\n"
        "\n"
        "func h() {\n"
        "\tswitch x {\n"
        "\tcase\n"
        "\t1: // cccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )
    kept = write_go(tmp_path, long_input)
    uncollapsed = run_gofumpt(kept)
    assert uncollapsed.returncode == 0
    assert uncollapsed.err == ""
    assert uncollapsed.out == (
        "package p\n"
        "\n"
        "func h() {\n"
        "\tswitch x {\n"
        "\tcase\n"
        "\t\t1: // cccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n"
        "\t\t_ = 1\n"
        "\t}\n"
        "}\n"
    )


def test_group_params_merges_same_line_params_with_identical_types(
    run_gofumpt, tmp_path
):
    """-extra=group_params merges `a (int), b int` into `a, b int`."""
    # CATCHES: the redundant parentheses around the first type are dropped
    # before the merge, and the merge itself compares how the two types print
    # rather than their syntax nodes, so the params end up grouped.
    name = write_go(tmp_path, "package p\n\nfunc f(a (int), b int) {}\n")
    result = run_gofumpt("-extra=group_params", name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\nfunc f(a, b int) {}\n"


def test_group_params_never_merges_struct_fields(run_gofumpt, tmp_path):
    """-extra=group_params deliberately leaves struct fields unmerged."""
    # CATCHES: the grouping rule applies to parameter and interface field
    # lists only, so same-line struct fields with the same type are split onto
    # separate lines instead of being joined into `a, b int`.
    name = write_go(tmp_path, "package p\n\ntype S struct { a int; b int }\n")
    result = run_gofumpt("-extra=group_params", name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\ntype S struct {\n\ta int\n\tb int\n}\n"


def test_group_params_merges_identical_interface_methods(run_gofumpt, tmp_path):
    """-extra=group_params merges same-line interface methods that match."""
    # CATCHES: two methods whose signatures print identically are merged into
    # a single spec, which the printer then renders with only the first name,
    # so `a(int); b(int)` comes out as just the `a(int)` method.
    name = write_go(tmp_path, "package p\n\ntype I interface { a(int); b(int) }\n")
    result = run_gofumpt("-extra=group_params", name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\ntype I interface {\n\ta(int)\n}\n"


@pytest.mark.parametrize(
    "body,formatted",
    [
        (
            "type I interface { a(x int); b(y int) }\n",
            "type I interface {\n\ta(x int)\n\tb(y int)\n}\n",
        ),
        ("func f(a int, b string) {}\n", "func f(a int, b string) {}\n"),
    ],
    ids=["interface", "params"],
)
def test_group_params_keeps_distinct_signatures_separate(
    run_gofumpt, tmp_path, body, formatted
):
    """Fields whose printed types differ are never merged by group_params."""
    # CATCHES: the merge requires the two field types to print to equal bytes,
    # so differing parameter names inside a signature, or outright different
    # types, keep the fields apart under -extra=group_params.
    name = write_go(tmp_path, "package p\n\n" + body)
    result = run_gofumpt("-extra=group_params", name)
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == "package p\n\n" + formatted
