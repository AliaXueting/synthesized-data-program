"""Shared black-box helpers for the gofumpt ``cli_flags_version`` module.

The program under test is always resolved through ``PROGRAMGYM_EXECUTABLE`` so
the exact same suite runs against the reference binary and against any
re-implementation produced later.
"""

import os
import re
import subprocess

import pytest

#: Environment variable that carries the path of the binary under test.
PROGRAMGYM_ENV_VAR = "PROGRAMGYM_EXECUTABLE"

#: Fully pinned child environment.  Nothing is inherited from the test process
#: on purpose: the binary under test must behave identically no matter what
#: GO* / DEBUG / locale variables happen to be set around the test run.
#: ``HOME`` and ``TMPDIR`` are pointed at the per-test directory at run time.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "LANG": "C",
    "LC_ALL": "C",
}

#: Default wall-clock budget for one run of the program under test.
DEFAULT_TIMEOUT = 30

#: Matches the ``//gofumpt:diagnose`` comment gofumpt rewrites.  The version
#: part is build/toolchain dependent, so tests only inspect the ``flags:``
#: tail, which is a faithful dump of the parsed -lang/-modpath/-extra state.
DIAGNOSE_RE = re.compile(
    r"^//gofumpt:diagnose version: \S+ \([^)]*\) flags: (?P<flags>.*)$",
    re.MULTILINE,
)

#: Canonical, always-ordered list of the three -extra rule names.
ALL_RULES = "group_params,clothe_returns,balance_calls"


def resolve_program():
    """Return the path of the binary under test, failing loudly if unset."""
    path = os.environ.get(PROGRAMGYM_ENV_VAR)
    if not path:
        pytest.fail("%s must point at the gofumpt binary under test" % PROGRAMGYM_ENV_VAR)
    return path


def build_child_env(cwd, extra_env=None):
    """Build the hermetic child environment for one run."""
    env = dict(CHILD_ENV)
    env["HOME"] = str(cwd)
    env["TMPDIR"] = str(cwd)
    # Coverage instrumentation hook: the pipeline measures source coverage of
    # the reference binary through GOCOVERDIR, so it must survive the pinning.
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env["GOCOVERDIR"] = value
    if extra_env:
        env.update(extra_env)
    return env


class RunResult(object):
    """Recorded outcome of one run of the program under test."""

    def __init__(self, argv, returncode, stdout, stderr):
        self.argv = tuple(argv)
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

    @property
    def out(self):
        """stdout decoded as UTF-8 text."""
        return self.stdout.decode("utf-8", "replace")

    @property
    def err(self):
        """stderr decoded as UTF-8 text."""
        return self.stderr.decode("utf-8", "replace")

    @property
    def out_lines(self):
        return self.out.splitlines()

    @property
    def err_lines(self):
        return self.err.splitlines()

    def diagnose_flags(self):
        """Return the ``flags: ...`` tail of a ``//gofumpt:diagnose`` run."""
        match = DIAGNOSE_RE.search(self.out)
        assert match is not None, (
            "expected a //gofumpt:diagnose comment in stdout, got:\n%s" % self.out
        )
        return match.group("flags")


def run_program(args, cwd, stdin=b"", extra_env=None, timeout=DEFAULT_TIMEOUT):
    """Run the binary under test with a pinned environment and capture output."""
    argv = [resolve_program()] + [str(a) for a in args]
    completed = subprocess.run(
        argv,
        cwd=str(cwd),
        env=build_child_env(cwd, extra_env),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    return RunResult(argv[1:], completed.returncode, completed.stdout, completed.stderr)


@pytest.fixture
def run_gofumpt(tmp_path):
    """Return a helper that runs the program under test inside ``tmp_path``.

    The helper takes the argv elements as positional arguments and forwards
    keyword arguments to :func:`run_program` (``stdin``, ``extra_env``,
    ``timeout`` and ``cwd`` to override the working directory).
    """

    def _run(*args, **kwargs):
        kwargs.setdefault("cwd", tmp_path)
        return run_program(args, **kwargs)

    return _run


@pytest.fixture
def diag_file(tmp_path):
    """Write a Go file carrying a ``//gofumpt:diagnose`` directive.

    gofumpt rewrites that directive into a dump of the parsed flag state, which
    makes the otherwise invisible -lang/-modpath/-extra values observable
    without depending on any particular formatting rule.
    """
    path = tmp_path / "diag.go"
    path.write_text("package p\n\n//gofumpt:diagnose\n\nfunc f() {}\n")
    return path.name
