"""Black-box tests for the `edit-config-template` command.

`edit-config-template` opens the config template (`.chezmoi.toml.tmpl` in the
source directory) in the editor, creating it from the current config file if
it does not exist yet.  The tests replace the editor with a script that
records its arguments.
"""

import re

RECORD_EDITOR = (
    "#!/bin/sh\n"
    "{\n"
    '  echo "editor=$0"\n'
    '  for a in "$@"; do echo "arg=$a"; done\n'
    "} > "
)


def recording_editor(sb):
    """Write an editor script that records its arguments, and the record path."""
    record = sb.root / "editor-record.txt"
    script = sb.script("recording-editor.sh", RECORD_EDITOR + str(record))
    return script, record


def test_edit_config_template_seeds_a_new_template_from_the_config_file(sb):
    """`edit-config-template` creates the template from the config contents."""
    # CATCHES: when no config template exists yet, the command creates
    # .chezmoi.toml.tmpl in the source directory seeded with the current
    # config file contents and passes exactly that one path to the editor.
    editor, record = recording_editor(sb)
    res = sb.run(["edit-config-template"], env={"EDITOR": str(editor)})
    assert res.returncode == 0, res.stderr
    template = sb.source / ".chezmoi.toml.tmpl"
    assert template.read_text(encoding="utf-8") == "umask = 18\n"
    assert record.read_text(encoding="utf-8") == (
        "editor={editor}\narg={template}\n".format(editor=editor, template=template)
    )
    # The editor ran quickly, so chezmoi warns about it on stderr.
    assert re.fullmatch(
        r"chezmoi: warning: {editor} {template}: returned in less than 1s\n".format(
            editor=re.escape(str(editor)), template=re.escape(str(template))
        ),
        res.stderr,
    )


def test_edit_config_template_edits_the_existing_template(sb):
    """An existing config template is edited in place, not reseeded."""
    # CATCHES: the editor is pointed at the existing .chezmoi.toml.tmpl and
    # its contents are left exactly as they were - the config file is not
    # written into it again.
    editor, record = recording_editor(sb)
    sb.write(
        ".chezmoi.toml.tmpl",
        contents='umask = 18\n\n[data]\n    x = "{{ .chezmoi.os }}"\n',
    )
    res = sb.run(["edit-config-template"], env={"EDITOR": str(editor)})
    assert res.returncode == 0, res.stderr
    template = sb.source / ".chezmoi.toml.tmpl"
    assert template.read_text(encoding="utf-8") == (
        'umask = 18\n\n[data]\n    x = "{{ .chezmoi.os }}"\n'
    )
    assert record.read_text(encoding="utf-8") == (
        "editor={editor}\narg={template}\n".format(editor=editor, template=template)
    )
