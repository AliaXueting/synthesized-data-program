"""Black-box tests for the `execute-template` command.

`execute-template` renders templates given as arguments, read from files, or
read from standard input, with the standard chezmoi template data and
functions.  The `--init` flag additionally registers the prompt template
functions in their simulation form.
"""


def test_execute_template_renders_arguments_and_stdin(sb):
    """Template arguments are rendered and concatenated; stdin is a template."""
    # CATCHES: multiple arguments are executed in order and their outputs are
    # concatenated with no separator, while with no arguments the template is
    # read from standard input - and template errors name the argument.
    res = sb.run(["execute-template", "hello {{ .chezmoi.os }}", "{{ .chezmoi.arch }}"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "hello linuxamd64"
    res = sb.run(["execute-template"], input="x={{ .chezmoi.os }}\n")
    assert res.returncode == 0, res.stderr
    assert res.stdout == "x=linux\n"
    res = sb.run(["execute-template", "{{ frobnicate }}"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'chezmoi: template: arg1:1: function "frobnicate" not defined\n'


def test_execute_template_reads_templates_from_files_and_stdin_data(sb):
    """`--file` renders files and `--with-stdin` exposes stdin as template data."""
    # CATCHES: with --file each argument is a filename whose contents become
    # the template, a missing file is an open error, and --with-stdin publishes
    # the raw standard input as .chezmoi.stdin.
    template = sb.root / "tpl.tmpl"
    template.write_text("from-file {{ .chezmoi.os }}\n", encoding="utf-8")
    res = sb.run(["execute-template", "--file", template])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "from-file linux\n"
    res = sb.run(["execute-template", "--file", sb.root / "absent.tmpl"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "chezmoi: open {path}: no such file or directory\n".format(
        path=sb.root / "absent.tmpl"
    )
    res = sb.run(
        ["execute-template", "--with-stdin", "stdin={{ .chezmoi.stdin }}"],
        input="payload\n",
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == "stdin=payload\n"


def test_execute_template_supports_custom_delimiters(sb):
    """`--left-delimiter`/`--right-delimiter` replace the {{ }} delimiters."""
    # CATCHES: with custom delimiters [[ ]] becomes the template delimiter and
    # the original {{ }} syntax is emitted verbatim instead of being executed.
    res = sb.run(
        [
            "execute-template",
            "--left-delimiter",
            "[[",
            "--right-delimiter",
            "]]",
            "d=[[ .chezmoi.os ]] g={{ .chezmoi.os }}",
        ]
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == "d=linux g={{ .chezmoi.os }}"


def test_execute_template_init_mode_simulates_prompt_functions(sb):
    """`--init` registers prompt functions driven by the simulation flags."""
    # CATCHES: in init mode promptString returns the prompt itself when no
    # simulation value is given, a simulation flag overrides it, a default
    # argument is returned when no value is simulated, and promptChoice
    # validates its simulated value against the choices.
    res = sb.run(["execute-template", "--init", 'g={{ promptString "greeting" }}'])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "g=greeting"
    res = sb.run(
        [
            "execute-template",
            "--init",
            "--promptString",
            "greeting=hi",
            'g={{ promptString "greeting" }} d={{ promptString "other" "dflt" }}',
        ]
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == "g=hi d=dflt"
    res = sb.run(
        [
            "execute-template",
            "--init",
            "--promptChoice",
            "pick=second",
            'c={{ promptChoice "pick" (list "first" "second") }}',
        ]
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == "c=second"
    res = sb.run(
        [
            "execute-template",
            "--init",
            "--promptInt",
            "number=42",
            "i={{ promptInt \"number\" }} b={{ promptBool \"flag\" true }}",
        ]
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == "i=42 b=true"
    res = sb.run(
        [
            "execute-template",
            "--init",
            "--promptChoice",
            "pick=absent",
            'c={{ promptChoice "pick" (list "first" "second") }}',
        ]
    )
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr.endswith("error calling promptChoice: absent: invalid choice\n")
