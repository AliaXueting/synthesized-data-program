"""Black-box tests for the interactive prompt machinery.

`chezmoi internal-test` exposes the prompt primitives (promptBool,
promptChoice, promptInt, promptMultichoice, promptString and readPassword)
as subcommands, which makes them directly observable without a TTY: with
`--no-tty` the prompt is written to stdout and the answer is read from
standard input.
"""

import pytest

INTERNAL_TEST_HELP_PREFIX = """\
Expose functionality for testing

Usage:
  chezmoi internal-test [command]

Available Commands:
  prompt-bool        Run promptBool
  prompt-choice      Run promptChoice
  prompt-int         Run promptInt
  prompt-multichoice Run promptMultichoice
  prompt-string      Run promptString
  read-password      Read a password

Flags:
  -h, --help   help for internal-test

Global Flags:
"""


def test_internal_test_help_lists_prompt_subcommands(sb):
    """`internal-test` without arguments prints its subcommand help."""
    # CATCHES: the command group exposes exactly six prompt subcommands in a
    # fixed order and ends with the "Use ... [command] --help" footer, while
    # the global flags section derives its default directories from the
    # sandbox's XDG environment.
    res = sb.run(["internal-test"])
    assert res.returncode == 0, res.stderr
    assert res.stdout.startswith(INTERNAL_TEST_HELP_PREFIX)
    assert res.stdout.endswith(
        'Use "chezmoi internal-test [command] --help" '
        "for more information about a command.\n"
    )
    # The default cache directory follows XDG_CACHE_HOME from the environment.
    assert f"(default {sb.root / 'xdg-cache' / 'chezmoi'})" in res.stdout


@pytest.mark.parametrize(
    "args,stdin,stdout,stderr,returncode",
    [
        pytest.param(
            ["prompt-bool", "Continue?"],
            "yes\n",
            "Continue?? true\n",
            "",
            0,
            id="no-default-answer-yes",
        ),
        pytest.param(
            ["prompt-bool", "Continue?", "true"],
            "\n",
            "Continue? (default true)? true\n",
            "",
            0,
            id="default-empty-line",
        ),
        pytest.param(
            ["prompt-bool", "Continue?", "true"],
            "maybe\nno\n",
            "Continue? (default true)? Continue? (default true)? false\n",
            "",
            0,
            id="invalid-answer-reprompts",
        ),
        pytest.param(
            ["prompt-bool", "Q"],
            "",
            "Q? ",
            "chezmoi: EOF\n",
            1,
            id="eof",
        ),
        pytest.param(
            ["prompt-bool", "q", "frobnicate"],
            "",
            "",
            'chezmoi: strconv.ParseBool: parsing "frobnicate": invalid syntax\n',
            1,
            id="bad-default",
        ),
        pytest.param(
            ["prompt-bool", "q", "true", "false"],
            "",
            "",
            "chezmoi: accepts between 1 and 2 arg(s), received 3\n",
            1,
            id="too-many-args",
        ),
    ],
)
def test_prompt_bool(sb, args, stdin, stdout, stderr, returncode):
    """promptBool renders its prompt, default and answer on one line."""
    # CATCHES: the prompt text is "P? " (or "P (default D)? " when a default
    # is given), invalid answers re-prompt on the same line, the answer is
    # echoed after the prompt, and EOF becomes a "chezmoi: EOF" error on
    # stderr while the half-written prompt stays on stdout.
    res = sb.run(["--no-tty", "internal-test", *args], input=stdin)
    assert res.returncode == returncode
    assert res.stdout == stdout
    assert res.stderr == stderr


@pytest.mark.parametrize(
    "args,stdin,stdout,stderr,returncode",
    [
        pytest.param(
            ["prompt-choice", "Pick color", "red,green,blue"],
            "g\n",
            "Pick color (red/green/blue)? green\n",
            "",
            0,
            id="abbreviation",
        ),
        pytest.param(
            ["prompt-choice", "Pick color", "red,green,blue"],
            "x\nb\n",
            "Pick color (red/green/blue)? Pick color (red/green/blue)? blue\n",
            "",
            0,
            id="invalid-then-valid",
        ),
        pytest.param(
            ["prompt-choice", "Pick color", "red,green,blue", "red"],
            "\n",
            "Pick color (red/green/blue, default red)? red\n",
            "",
            0,
            id="default-empty-line",
        ),
        pytest.param(
            ["prompt-choice", "Pick", "red,green", "yellow"],
            "",
            "",
            "chezmoi: yellow: invalid default value\n",
            1,
            id="invalid-default",
        ),
        pytest.param(
            ["prompt-int", "Count", "7"],
            "42\n",
            "Count (default 7)? 42\n",
            "",
            0,
            id="int-with-default",
        ),
        pytest.param(
            ["prompt-int", "Count", "7"],
            "\n",
            "Count (default 7)? 7\n",
            "",
            0,
            id="int-default-empty-line",
        ),
        pytest.param(
            ["prompt-int", "Count"],
            "x\n-3\n",
            "Count? Count? -3\n",
            "",
            0,
            id="int-invalid-then-negative",
        ),
        pytest.param(
            ["prompt-int", "Count", "frob"],
            "",
            "",
            'chezmoi: strconv.ParseInt: parsing "frob": invalid syntax\n',
            1,
            id="int-bad-default",
        ),
        pytest.param(
            ["prompt-string", "Username", "root"],
            "bob\n",
            'Username (default "root")? bob\n',
            "",
            0,
            id="string-with-default",
        ),
        pytest.param(
            ["prompt-string", "Username", "root"],
            " \n",
            'Username (default "root")? root\n',
            "",
            0,
            id="string-whitespace-uses-default",
        ),
        pytest.param(
            ["read-password"],
            "hunter2\n",
            "Password? hunter2\n",
            "",
            0,
            id="read-password",
        ),
    ],
)
def test_prompt_choice_int_string_password(
    sb, args, stdin, stdout, stderr, returncode
):
    """Each prompt type renders its choices/default in a fixed format."""
    # CATCHES: choices are shown as "(a/b/c)" with the default appended after
    # a comma, promptInt prints "(default 7)" unquoted while promptString
    # quotes it, promptChoice accepts unambiguous abbreviations and
    # readPassword prompts with "Password? " and echoes the value.
    res = sb.run(["--no-tty", "internal-test", *args], input=stdin)
    assert res.returncode == returncode
    assert res.stdout == stdout
    assert res.stderr == stderr


def test_prompt_multichoice_selection_and_defaults(sb):
    """promptMultichoice loops until an empty line and honors defaults."""
    # CATCHES: the prompt prints the question, a "Choices (a/b)" line and one
    # "Choice (ENTER to stop)> " per answer, stops on an empty line, prints
    # one selected value per line, and a "Default [x]" line appears when
    # defaults are given (an empty line then selects them).
    res = sb.run(
        ["--no-tty", "internal-test", "prompt-multichoice", "Days", "mon,tue"],
        input="mon\n\n",
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        "Days?\n"
        "Choices (mon/tue)\n"
        "Choice (ENTER to stop)> "
        "Choice (ENTER to stop)> "
        "mon\n"
    )
    res = sb.run(
        [
            "--no-tty",
            "internal-test",
            "prompt-multichoice",
            "Days",
            "mon,tue,sat",
            "sat",
        ],
        input="\n",
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        "Days?\n"
        "Choices (mon/tue/sat)\n"
        "Default [sat]\n"
        "Choice (ENTER to stop)> "
        "sat\n"
    )
    # With two defaults the selected values are printed in unspecified order.
    res = sb.run(
        [
            "--no-tty",
            "internal-test",
            "prompt-multichoice",
            "Days",
            "mon,tue,sat,sun",
            "sat,sun",
        ],
        input="\n",
    )
    assert res.returncode == 0, res.stderr
    prefix = (
        "Days?\n"
        "Choices (mon/tue/sat/sun)\n"
        "Default [sat, sun]\n"
        "Choice (ENTER to stop)> "
    )
    assert res.stdout.startswith(prefix)
    assert sorted(res.stdout[len(prefix) :].splitlines()) == ["sat", "sun"]


def test_prompt_multichoice_rejects_invalid_default(sb):
    """A default that is not one of the choices is rejected up front."""
    # CATCHES: each default value must be a choice; the first offending value
    # is reported with its index in the argument list, before any prompt is
    # printed.
    res = sb.run(
        [
            "--no-tty",
            "internal-test",
            "prompt-multichoice",
            "Days",
            "mon,tue",
            "fri,sat",
        ],
    )
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "chezmoi: fri: invalid default value (index 1)\n"
