"""Black-box tests for the `chattr` command.

`chezmoi chattr` rewrites the attribute prefixes of entries in the source
state, renaming the source files (and directories) accordingly.  These tests
pin the modifier grammar (`+attr`, `-attr`, bare `attr` and the short
aliases), the canonical prefix order of the renamed files, and the error
paths.
"""

import pytest


def source_names(sb):
    """Return the sorted relative names of all files in the source directory."""
    return sorted(
        str(path.relative_to(sb.source))
        for path in sb.source.rglob("*")
        if path.is_file()
    )


def test_chattr_adds_and_clears_attribute_prefixes(sb):
    """`chattr +private` renames the source file; `-private` renames it back."""
    # CATCHES: the attribute is encoded by renaming dot_file to
    # private_dot_file (and back), and the private attribute pins the target
    # permissions to 0o600 (owner read/write only).
    sb.write("dot_file", contents="# contents of .file\n")
    target = sb.home / ".file"
    res = sb.run(["chattr", "+private", target])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert source_names(sb) == ["private_dot_file"]
    state = sb.run(["dump"])
    assert state.returncode == 0
    assert '"perm": 384' in state.stdout  # 0o600: private clears group/other bits
    res = sb.run(["chattr", "--", "-private", target])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["dot_file"]
    res = sb.run(["chattr", "noprivate", target])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["dot_file"]


def test_chattr_short_aliases_and_canonical_prefix_order(sb):
    """Comma-separated short aliases rename to the canonical prefix order."""
    # CATCHES: `+p,+x` renames dot_file to private_executable_dot_file - the
    # private_ prefix always precedes executable_ regardless of modifier order,
    # and clearing both aliases is a single comma-separated modifier argument.
    sb.write("dot_file", contents="# contents of .file\n")
    res = sb.run(["chattr", "+p,+x", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["private_executable_dot_file"]
    res = sb.run(["chattr", "+p", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["private_executable_dot_file"]
    res = sb.run(["chattr", "nop,nox", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["dot_file"]


def test_chattr_template_and_directory_attributes(sb):
    """`+template` appends the .tmpl suffix; `+exact` renames directories."""
    # CATCHES: the template attribute is stored as a suffix rather than a
    # prefix, and directory attributes rename the whole source directory.
    sb.write("dot_file", contents="# contents of .file\n")
    sb.write("dot_dir/f", contents="# contents of .dir/f\n")
    res = sb.run(["chattr", "template", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["dot_dir/f", "dot_file.tmpl"]
    res = sb.run(["chattr", "+exact", sb.home / ".dir"])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["dot_file.tmpl", "exact_dot_dir/f"]
    res = sb.run(["chattr", "notemplate", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["dot_file", "exact_dot_dir/f"]


def test_chattr_empty_modifier_is_a_noop_for_create_files(sb):
    """`chattr +empty` renames plain files but not `create_` files."""
    # CATCHES: for create_ files the empty attribute is wired to the encrypted
    # modifier, so `+empty` leaves create_dot_file untouched while the same
    # modifier renames a plain dot_file to empty_dot_file.
    sb.write("create_dot_file", contents="# contents of .file\n")
    res = sb.run(["chattr", "+empty", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["create_dot_file"]
    sb.write("dot_plain", contents="# contents of .plain\n")
    res = sb.run(["chattr", "+empty", sb.home / ".plain"])
    assert res.returncode == 0, res.stderr
    assert source_names(sb) == ["create_dot_file", "empty_dot_plain"]


@pytest.mark.parametrize(
    "args, message",
    [
        (
            ["chattr", "+frobnicate", "{home}/.file"],
            "chezmoi: frobnicate: unknown attribute\n",
        ),
        (
            ["chattr", "+private", "{home}/.absent"],
            "chezmoi: {home}/.absent: not managed\n",
        ),
        (
            ["chattr", "+private"],
            "chezmoi: requires at least 2 arg(s), only received 1\n",
        ),
    ],
)
def test_chattr_rejects_bad_modifiers_and_targets(sb, args, message):
    """Invalid modifiers or unmanaged targets are reported on stderr."""
    # CATCHES: unknown attributes, unmanaged targets and missing arguments
    # each produce a distinct diagnostic and exit code 1.
    sb.write("dot_file", contents="# contents of .file\n")
    resolved = [arg.format(home=sb.home) for arg in args]
    res = sb.run(resolved)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message.format(home=sb.home)
