"""Black-box tests for the `edit` and `edit-encrypted` commands.

Both commands hand files to an external editor.  The tests replace the
editor with a script inside the sandbox that records its arguments and
appends a line to every file it is given, so the effect of the edit is
observable without any real editor (and without a terminal).
"""

import re


def appending_editor(sb):
    """Return an editor script that appends a line to each argument."""
    return sb.script(
        "appending-editor.sh",
        '#!/bin/sh\nfor f in "$@"; do printf "# appended by editor\\n" >> "$f"; done\n',
    )


def recording_editor(sb):
    """Return an editor script that records its arguments to a file."""
    record = sb.root / "editor-record.txt"
    return sb.script(
        "recording-editor.sh",
        '#!/bin/sh\n{{ echo "editor=$0"; for a in "$@"; do echo "arg=$a"; done; }} > {record}\n'.format(
            record=record
        ),
    )


def test_edit_updates_source_state_through_hardlink(sb):
    """`edit` runs the editor on a hardlink named after the target."""
    # CATCHES: by default edit does not pass the source file itself to the
    # editor but a hardlink in a temporary directory named `.file`, and it
    # warns when the editor returns in less than the configured 1s minimum.
    sb.write("dot_file", contents="# original\n")
    editor = appending_editor(sb)
    res = sb.run(["edit", sb.home / ".file"], env={"EDITOR": str(editor)})
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert re.search(
        r"^chezmoi: warning: {editor} .+: returned in less than 1s\n$".format(
            editor=re.escape(str(editor))
        ),
        res.stderr,
    )
    assert (
        sb.source / "dot_file"
    ).read_text(encoding="utf-8") == "# original\n# appended by editor\n"
    assert not any(sb.home.iterdir())


def test_edit_apply_applies_the_edit_to_the_destination(sb):
    """`edit --apply` applies the source state after the editor returns."""
    # CATCHES: the destination file is only written after the editor exits,
    # so the appended line appears in both the source state and `.file`.
    sb.write("dot_file", contents="# original\n")
    editor = appending_editor(sb)
    res = sb.run(["edit", "--apply", sb.home / ".file"], env={"EDITOR": str(editor)})
    assert res.returncode == 0, res.stderr
    expected = "# original\n# appended by editor\n"
    assert (sb.source / "dot_file").read_text(encoding="utf-8") == expected
    assert (sb.home / ".file").read_text(encoding="utf-8") == expected


def test_edit_without_arguments_edits_the_source_directory(sb):
    """`edit` with no targets passes the source directory to the editor."""
    # CATCHES: with no arguments the editor is invoked once with the source
    # directory rather than with any target file.
    sb.write("dot_file", contents="# contents of .file\n")
    record = sb.root / "editor-record.txt"
    editor = recording_editor(sb)
    res = sb.run(["edit"], env={"EDITOR": str(editor)})
    assert res.returncode == 0, res.stderr
    assert record.read_text(encoding="utf-8") == "editor={}\narg={}\n".format(
        editor, sb.source
    )


def test_edit_encrypted_round_trips_a_home_file(sb):
    """`edit-encrypted` decrypts, edits and re-encrypts a file under home."""
    # CATCHES: the editor runs on a decrypted copy in a temporary directory
    # and the file named on the command line is written back encrypted, so it
    # never holds plaintext at rest and `decrypt` returns the appended line.
    keys = sb.run(["age-keygen"])
    assert keys.returncode == 0, keys.stderr
    recipient = next(
        line
        for line in keys.stdout.splitlines()
        if line.startswith("# public key: ")
    )[len("# public key: ") :]
    identity = sb.root / "age" / "identity.txt"
    identity.parent.mkdir(parents=True, exist_ok=True)
    identity.write_text(
        next(
            line
            for line in keys.stdout.splitlines()
            if line.startswith("AGE-SECRET-KEY-1")
        )
        + "\n",
        encoding="utf-8",
    )
    sb.write_config(
        'encryption = "age"\n\n[age]\n'
        '    identity = "{}"\n'
        '    recipient = "{}"\n'.format(identity, recipient)
    )
    encrypted = sb.run(["encrypt"], input="# plaintext\n")
    assert encrypted.returncode == 0, encrypted.stderr
    secret = sb.home / ".secret"
    secret.write_text(encrypted.stdout, encoding="utf-8")
    editor = appending_editor(sb)
    res = sb.run(["edit-encrypted", secret], env={"EDITOR": str(editor)})
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert re.fullmatch(
        r"chezmoi: warning: {editor} {tmp}/chezmoi-edit-encrypted\d+/\.secret: "
        r"returned in less than 1s\n".format(
            editor=re.escape(str(editor)), tmp=re.escape(str(sb.tmp))
        ),
        res.stderr,
    )
    ciphertext = secret.read_text(encoding="utf-8")
    assert ciphertext.startswith("-----BEGIN AGE ENCRYPTED FILE-----\n")
    decrypted = sb.run(["decrypt"], input=ciphertext)
    assert decrypted.returncode == 0, decrypted.stderr
    assert decrypted.stdout == "# plaintext\n# appended by editor\n"


def test_edit_and_edit_encrypted_error_paths(sb):
    """Missing targets and missing arguments are diagnosed on stderr."""
    # CATCHES: both commands require their targets to exist (edit resolves
    # them through the source state, edit-encrypted through the filesystem),
    # enforce their minimum argument counts, and edit-encrypted additionally
    # refuses to touch an existing file when no encryption is configured.
    sb.write("dot_file", contents="# contents of .file\n")
    editor = appending_editor(sb)
    res = sb.run(["edit", sb.home / ".absent"], env={"EDITOR": str(editor)})
    assert res.returncode == 1
    assert res.stderr == "chezmoi: {}: not managed\n".format(sb.home / ".absent")
    res = sb.run(["edit-encrypted", sb.home / ".absent"], env={"EDITOR": str(editor)})
    assert res.returncode == 1
    assert res.stderr == "chezmoi: open {}: no such file or directory\n".format(
        sb.home / ".absent"
    )
    res = sb.run(["edit-encrypted"], env={"EDITOR": str(editor)})
    assert res.returncode == 1
    assert res.stderr == "chezmoi: requires at least 1 arg(s), only received 0\n"
    unencrypted = sb.home / ".plain"
    unencrypted.write_text("# plaintext\n", encoding="utf-8")
    res = sb.run(["edit-encrypted", unencrypted], env={"EDITOR": str(editor)})
    assert res.returncode == 1
    assert res.stderr == "chezmoi: encryption not configured\n"
