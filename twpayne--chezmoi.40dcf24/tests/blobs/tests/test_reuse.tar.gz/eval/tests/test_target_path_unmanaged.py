"""Black-box tests for the `target-path` and `unmanaged` commands.

`target-path` translates paths in the source directory to the target paths
they manage, and `unmanaged` lists the files in the destination directory that
chezmoi does not manage.
"""

import pytest


def test_target_path_prints_the_destination_and_maps_source_names(sb):
    """`target-path` prints the destination, then maps source paths to targets."""
    # CATCHES: attribute prefixes and the .tmpl suffix are stripped when
    # translating a source path to its target path, directories map to
    # directories, and with no arguments the destination directory is printed.
    sb.write("dot_file", contents="# contents of .file\n")
    sb.write("private_executable_dot_priv", contents="# contents of .priv\n")
    sb.write("dot_dir/nested_dot_file", contents="# contents of .dir/f\n")
    sb.write("dot_tmpl.tmpl", contents="{{ .chezmoi.os }}\n")
    res = sb.run(["target-path"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "{home}\n".format(home=sb.home)
    res = sb.run(
        [
            "target-path",
            sb.source / "dot_file",
            sb.source / "private_executable_dot_priv",
            sb.source / "dot_dir",
            sb.source / "dot_dir/nested_dot_file",
            sb.source / "dot_tmpl.tmpl",
        ]
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        "{home}/.file\n"
        "{home}/.priv\n"
        "{home}/.dir\n"
        "{home}/.dir/nested_dot_file\n"
        "{home}/.tmpl\n"
    ).format(home=sb.home)
    # Relative arguments are resolved against the working directory.
    res = sb.run(["target-path", "source/dot_file"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "{home}/.file\n".format(home=sb.home)


def test_target_path_rejects_paths_outside_the_source_directory(sb):
    """`target-path` refuses paths outside the source directory and stat errors."""
    # CATCHES: a path that is not inside the source directory is rejected with
    # a `not in` diagnostic naming both paths, and a missing path inside the
    # source directory is a stat error.
    sb.write("dot_file", contents="# contents of .file\n")
    (sb.home / ".file").write_text("# contents of .file\n", encoding="utf-8")
    res = sb.run(["target-path", sb.home / ".file"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "chezmoi: {home}/.file: not in {source}\n".format(
        home=sb.home, source=sb.source
    )
    res = sb.run(["target-path", sb.source / "dot_absent"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "chezmoi: stat {source}/dot_absent: no such file or directory\n".format(
        source=sb.source
    )


@pytest.mark.parametrize(
    "style, expected",
    [
        (
            [],
            ".dir/unmanaged2\n.dot_dir\n.unmanaged\n",
        ),
        (
            ["--path-style", "absolute"],
            None,  # filled in by the test: absolute destination paths
        ),
        (
            ["--tree"],
            ".dir\n  unmanaged2\n.dot_dir\n.unmanaged\n",
        ),
    ],
)
def test_unmanaged_lists_unmanaged_files(sb, style, expected):
    """`unmanaged` lists destination files not in the source state."""
    # CATCHES: unmanaged directories are listed but not descended into,
    # managed directories are descended into so only their unmanaged children
    # are listed, output is sorted, and --path-style/--tree change the format.
    sb.write("dot_dir/managed", contents="# contents of .dir/managed\n")
    (sb.home / ".dir").mkdir(parents=True, exist_ok=True)
    (sb.home / ".dir" / "unmanaged2").write_text("y\n", encoding="utf-8")
    (sb.home / ".dot_dir").mkdir()
    (sb.home / ".unmanaged").write_text("x\n", encoding="utf-8")
    res = sb.run(["unmanaged", *style])
    assert res.returncode == 0, res.stderr
    if expected is None:
        expected = "".join(
            "{home}/{path}\n".format(home=sb.home, path=path)
            for path in (".dir/unmanaged2", ".dot_dir", ".unmanaged")
        )
    assert res.stdout == expected


def test_unmanaged_restricts_output_to_the_given_path(sb):
    """`unmanaged path` only lists unmanaged files under that path."""
    # CATCHES: passing a destination path restricts the walk to that subtree,
    # so unmanaged files elsewhere in the destination are not listed.
    sb.write("dot_dir/managed", contents="# contents of .dir/managed\n")
    (sb.home / ".dir").mkdir(parents=True, exist_ok=True)
    (sb.home / ".dir" / "unmanaged2").write_text("y\n", encoding="utf-8")
    (sb.home / ".other").write_text("z\n", encoding="utf-8")
    res = sb.run(["unmanaged", sb.home / ".dir"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ".dir/unmanaged2\n"
