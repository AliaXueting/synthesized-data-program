"""Black-box tests for the password-manager template functions.

The `keepassxc` and `bitwarden` template functions shell out to the
`keepassxc-cli` and `bw` commands.  The tests replace both with scripts
inside the sandbox that record their arguments and print canned output, so
no password manager is ever needed.
"""

KEEPASSXC_SCRIPT = (
    "#!/bin/sh\n"
    'echo "keepassxc-cli $*" >> '
    + "{record}"
    + "\n"
    + "case \" $* \" in\n"
    + '  *" --attributes "*)\n'
    + '    attribute=$(echo "$*" | sed \'s/.* --attributes \\([^ ]*\\) .*/\\1/\')\n'
    + '    printf \'%s: value-of-%s\\n\' "$attribute" "$attribute"\n'
    + "    ;;\n"
    + "  *)\n"
    + "    printf 'Username: user\\nPassword: secret\\nNotes: first\\n  second\\n'\n"
    + "    ;;\n"
    + "esac\n"
)

BITWARDEN_JSON = (
    '{"login":{"password":"secret","username":"user@example.com"},'
    '"fields":[{"name":"f1","value":"v1"}],"id":"42"}'
)


def keepassxc_sandbox(sb):
    """Configure a sandbox with a fake keepassxc-cli and return the record."""
    record = sb.root / "keepassxc-record.txt"
    script = sb.script(
        "keepassxc-cli", KEEPASSXC_SCRIPT.replace("{record}", str(record))
    )
    sb.write_config(
        "[keepassxc]\n"
        "    command = \"" + str(script) + "\"\n"
        '    database = "' + str(sb.root / "db.kdbx") + '"\n'
        '    mode = "cache-password"\n'
        "    prompt = false\n"
    )
    return record


def test_keepassxc_template_funcs_invoke_the_cli_and_parse_output(sb):
    """`keepassxc` parses key/value output; `keepassxcAttribute` re-queries."""
    # CATCHES: keepassxc runs `show <database> --quiet --show-protected <entry>`
    # and parses `Key: value` pairs (multi-line values are joined), while
    # keepassxcAttribute passes the attribute name with --attributes and
    # returns the CLI's output for that query verbatim (trimmed).
    record = keepassxc_sandbox(sb)
    res = sb.run(["execute-template", '{{ (keepassxc "group/entry").Password }}'])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "secret"
    res = sb.run(["execute-template", '{{ (keepassxc "group/entry").Username }}'])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "user"
    res = sb.run(["execute-template", '{{ (keepassxc "group/entry").Notes }}'])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "first\n  second"
    res = sb.run(
        ["execute-template", '{{ keepassxcAttribute "group/entry" "Password" }}']
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == "Password: value-of-Password"
    assert record.read_text(encoding="utf-8") == (
        "keepassxc-cli show {database} --quiet --show-protected group/entry\n"
        "keepassxc-cli show {database} --quiet --show-protected group/entry\n"
        "keepassxc-cli show {database} --quiet --show-protected group/entry\n"
        "keepassxc-cli show {database} group/entry --attributes Password --quiet --show-protected\n"
    ).format(database=sb.root / "db.kdbx")


def test_keepassxc_prompts_for_the_database_password(sb):
    """With prompting enabled the database password is read from stdin."""
    # CATCHES: the `Enter password to unlock <database>: ` prompt is printed
    # to stdout, the answer is read from standard input, and the same prompt
    # line is followed by the rendered template value.
    record = sb.root / "keepassxc-record.txt"
    script = sb.script(
        "keepassxc-cli", KEEPASSXC_SCRIPT.replace("{record}", str(record))
    )
    sb.write_config(
        "[keepassxc]\n"
        "    command = \"" + str(script) + "\"\n"
        '    database = "' + str(sb.root / "db.kdbx") + '"\n'
        '    mode = "cache-password"\n'
    )
    res = sb.run(
        ["--no-tty", "execute-template", '{{ (keepassxc "group/entry").Password }}'],
        input="pw\n",
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == "Enter password to unlock {database}: secret".format(
        database=sb.root / "db.kdbx"
    )


def test_keepassxc_requires_a_configured_database(sb):
    """Calling keepassxc without a database configuration is an error."""
    # CATCHES: the template function panics with `keepassxc.database not set`
    # when no database is configured, and the error is wrapped as a template
    # execution error with a non-zero exit code.
    script = sb.script("keepassxc-cli", "#!/bin/sh\nprintf 'Password: p\\n'\n")
    sb.write_config(
        "[keepassxc]\n"
        "    command = \"" + str(script) + "\"\n"
        '    mode = "cache-password"\n'
        "    prompt = false\n"
    )
    res = sb.run(["execute-template", '{{ (keepassxc "entry").Password }}'])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr.endswith("error calling keepassxc: keepassxc.database not set\n")


def test_bitwarden_template_funcs_invoke_the_cli_and_parse_json(sb):
    """`bitwarden` parses JSON output; attachments are returned raw."""
    # CATCHES: bitwarden runs `bw get item <id>` and parses the JSON reply,
    # bitwardenFields indexes the fields array by name, bitwardenAttachment
    # runs `bw get attachment <name> --itemid <id> --raw` and returns the raw
    # bytes, and a failing `bw` command is reported as a template error that
    # also names the exit status.
    record = sb.root / "bitwarden-record.txt"
    script = sb.script(
        "bw",
        "#!/bin/sh\n"
        "echo \"bw $*\" >> " + str(record) + "\n"
        "printf '%s\\n' '" + BITWARDEN_JSON + "'\n",
    )
    sb.write_config("[bitwarden]\n    command = \"" + str(script) + '"\n')
    res = sb.run(["execute-template", '{{ (bitwarden "item" "1234").login.password }}'])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "secret"
    res = sb.run(["execute-template", '{{ (bitwarden "item" "1234").login.username }}'])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "user@example.com"
    res = sb.run(["execute-template", '{{ (bitwardenFields "item" "1234").f1.value }}'])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "v1"
    res = sb.run(["execute-template", '{{ bitwardenAttachment "att.txt" "1234" }}'])
    assert res.returncode == 0, res.stderr
    assert res.stdout == BITWARDEN_JSON + "\n"
    assert record.read_text(encoding="utf-8") == (
        "bw get item 1234\n"
        "bw get item 1234\n"
        "bw get item 1234\n"
        "bw get attachment att.txt --itemid 1234 --raw\n"
    )
    failing = sb.script("bw", "#!/bin/sh\necho 'boom' >&2\nexit 3\n")
    sb.write_config("[bitwarden]\n    command = \"" + str(failing) + '"\n')
    res = sb.run(["execute-template", '{{ (bitwarden "item" "x").login }}'])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "boom\n"
        "chezmoi: template: arg1:1:4: executing \"arg1\" at <bitwarden \"item\" \"x\">: "
        "error calling bitwarden: {script} get item x: exit status 3\n"
    ).format(script=failing)
