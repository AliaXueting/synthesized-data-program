"""Shared helpers for driving the chezmoi reference binary as a black box.

Every test builds a throwaway workspace (source directory, destination
directory, config file, cache directory and persistent state file) inside
``tmp_path`` and runs the program under test with a fully pinned environment.
The binary is always resolved through ``PROGRAMGYM_EXECUTABLE`` so that the
suite can be pointed at a re-implementation.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest


def chezmoi_program() -> Path:
    """Return the absolute path of the program under test."""
    return Path(os.environ["PROGRAMGYM_EXECUTABLE"]).resolve()


# The default configuration written into every sandbox.  chezmoi derives the
# permissions of managed files from the file attributes combined with the
# *process* umask, so pinning `umask` in the config file (0o022) makes every
# reported and applied permission byte-for-byte reproducible no matter which
# umask the test harness itself runs under.
DEFAULT_CONFIG = "umask = 18\n"

# The environment every child process runs with: a fixed PATH, a C locale, no
# color and no terminal so that output is byte-for-byte reproducible.  HOME,
# TMPDIR and the XDG variables are filled in per-run by Sandbox.env().
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "TERM": "dumb",
    "NO_COLOR": "1",
    "SHELL": "/bin/sh",
    "EDITOR": "/bin/true",
}


def run_chezmoi(args, *, input="", cwd=None, env=None, timeout=30, binary=False):
    """Run the program under test and return the completed process.

    ``args`` is the argument list without the program name, ``input`` is fed
    to standard input and ``cwd`` is the child's working directory.  ``env``
    overrides entries of the pinned child environment.  With ``binary`` the
    output is captured as raw bytes (for commands like ``archive`` that write
    non-UTF-8 data) and ``input`` must be bytes.
    """

    def pin_umask():
        # Pin the process umask so that commands reporting the umask (doctor)
        # and files created by the child are independent of the umask the
        # test harness itself happens to run under.
        os.umask(0o002)

    child_env = dict(CHILD_ENV)
    if env:
        child_env.update(env)
    # Coverage instrumentation hook: the pipeline builds the reference binary
    # with -cover, so GOCOVERDIR must survive the pinned environment for the
    # module's source coverage to be measured.  The value is made absolute
    # because children run inside per-test temporary directories.
    cov_env = {
        "GOCOVERDIR": os.path.abspath(value)
        for value in [os.environ.get("GOCOVERDIR")]
        if value
    }
    child_env.update(cov_env)
    return subprocess.run(
        [str(chezmoi_program()), *[str(arg) for arg in args]],
        input=input,
        capture_output=True,
        text=not binary,
        encoding=None if binary else "utf-8",
        cwd=None if cwd is None else str(cwd),
        env=child_env,
        timeout=timeout,
        preexec_fn=pin_umask,
    )


class Sandbox:
    """A disposable chezmoi workspace rooted at ``root``.

    The layout keeps every directory the program can write to inside the
    pytest temporary directory so that no test ever touches the real home
    directory, the real XDG directories, or any path outside ``tmp_path``.
    """

    def __init__(self, root):
        self.root = Path(root)
        self.source = self.root / "source"
        self.home = self.root / "home"
        self.config_dir = self.root / "config" / "chezmoi"
        self.cache = self.root / "cache"
        self.state_dir = self.root / "state"
        self.tmp = self.root / "tmp"
        for directory in (
            self.source,
            self.home,
            self.config_dir,
            self.cache,
            self.state_dir,
            self.tmp,
        ):
            directory.mkdir(parents=True, exist_ok=True)
        self.config_file = self.config_dir / "chezmoi.toml"
        self.state_file = self.state_dir / "chezmoistate.boltdb"
        self.config_file.write_text(DEFAULT_CONFIG, encoding="utf-8")

    # ------------------------------------------------------------------
    # helper-script support
    # ------------------------------------------------------------------
    def script(self, name, contents):
        """Write an executable helper script inside the sandbox and return it.

        Several chezmoi commands (cd, edit, merge, and the secret-manager
        template functions) run external programs.  The tests replace those
        programs with tiny scripts inside ``tmp_path`` so that no test ever
        depends on - or launches - a real editor, shell or password manager.
        """
        path = self.root / "bin" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(contents, encoding="utf-8")
        path.chmod(0o755)
        return path

    # ------------------------------------------------------------------
    # source state helpers
    # ------------------------------------------------------------------
    def source_path(self, *parts):
        """Return a path inside the source directory."""
        return self.source.joinpath(*parts)

    def write(self, *parts, contents=""):
        """Write a file into the source state, creating parent directories."""
        path = self.source_path(*parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(contents, encoding="utf-8")
        return path

    def write_config(self, contents):
        """Write the chezmoi configuration file, keeping the pinned umask."""
        self.config_file.write_text(DEFAULT_CONFIG + contents, encoding="utf-8")
        return self.config_file

    # ------------------------------------------------------------------
    # process helpers
    # ------------------------------------------------------------------
    def env(self, **extra):
        """Return the child environment for this workspace."""
        child_env = {
            "HOME": str(self.home),
            "TMPDIR": str(self.tmp),
            "XDG_CONFIG_HOME": str(self.root / "config"),
            "XDG_CONFIG_DIRS": str(self.root / "xdg-config-dirs"),
            "XDG_CACHE_HOME": str(self.root / "xdg-cache"),
            "XDG_DATA_HOME": str(self.root / "xdg-data"),
        }
        child_env.update(extra)
        return child_env

    def _flags(self):
        return [
            "--source",
            self.source,
            "--destination",
            self.home,
            "--cache",
            self.cache,
            "--persistent-state",
            self.state_file,
        ]

    def run(self, args, *, input="", cwd=None, env=None, binary=False):
        """Run chezmoi against this workspace with every directory pinned."""
        command = [
            "--config",
            self.config_file,
            *self._flags(),
            *[str(arg) for arg in args],
        ]
        return run_chezmoi(
            command,
            input=input,
            cwd=self.root if cwd is None else cwd,
            env=self.env(**(env or {})),
            binary=binary,
        )

    def run_discovered(self, args, *, input="", cwd=None, env=None, binary=False):
        """Run chezmoi without --config so the config file is discovered."""
        return run_chezmoi(
            [*self._flags(), *[str(arg) for arg in args]],
            input=input,
            cwd=self.root if cwd is None else cwd,
            env=self.env(**(env or {})),
            binary=binary,
        )


@pytest.fixture
def sb(tmp_path):
    """Return a fresh sandboxed chezmoi workspace."""
    return Sandbox(tmp_path)


def lines(*ls):
    """Join lines into the exact text chezmoi prints, with the final EOL."""
    return "\n".join(ls) + "\n"
