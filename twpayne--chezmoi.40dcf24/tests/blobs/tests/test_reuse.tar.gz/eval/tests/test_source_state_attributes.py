"""Black-box tests for source state name attributes.

chezmoi encodes a target's attributes in the names of the files and
directories in the source state (`dot_`, `empty_`, `executable_`, `private_`,
`readonly_`, `symlink_`, `create_`, `literal_`, `exact_`, `remove_`, ...).
These tests pin how each attribute shapes the target state reported by
`dump` and how `apply` materialises it.
"""

import json

import pytest

from conftest import lines

# The canonical source state used by several tests below, mirroring the layout
# used by the repository's own test suite.
CANONICAL = {
    "create_dot_create": "# contents of .create\n",
    "dot_dir/file": "# contents of .dir/file\n",
    "dot_dir/exact_subdir/file": "# contents of .dir/subdir/file\n",
    "dot_remove": "",
    "empty_dot_empty": "",
    "executable_dot_executable": "# contents of .executable\n",
    "dot_file": "# contents of .file\n",
    "private_dot_private": "# contents of .private\n",
    "readonly_dot_readonly": "# contents of .readonly\n",
    "symlink_dot_symlink": ".dir/subdir/file\n",
    "dot_template.tmpl": 'key = {{ "value" }}\n',
}


def build_canonical(sb):
    """Create the canonical source state and return the sandbox."""
    for name, contents in CANONICAL.items():
        sb.write(*name.split("/"), contents=contents)
    return sb


def dump(sb, *args):
    """Return the JSON target state as a dict."""
    res = sb.run(["dump", *args])
    assert res.returncode == 0, res.stderr
    return json.loads(res.stdout)


def test_dot_prefix_maps_to_a_hidden_file(sb):
    """`dot_file` in the source state manages `.file` with its contents."""
    # CATCHES: the `dot_` prefix is replaced by a literal dot, so the target
    # name is `.file` and not `dot_file`.
    sb.write("dot_file", contents="# contents of .file\n")
    state = dump(sb)
    assert state == {
        ".file": {
            "type": "file",
            "name": ".file",
            "contents": "# contents of .file\n",
            "perm": 0o644,
        }
    }


def test_empty_attribute_manages_an_empty_file(sb):
    """`empty_dot_empty` creates a zero-byte target; without `empty_` it does not."""
    # CATCHES: a source file with empty contents is normally interpreted as a
    # request to *remove* the target, so the `empty_` attribute is what makes
    # the empty file a real target.
    sb.write("empty_dot_empty", contents="")
    sb.write("dot_file", contents="# contents of .file\n")
    state = dump(sb)
    assert state[".empty"] == {
        "type": "file",
        "name": ".empty",
        "contents": "",
        "perm": 0o644,
    }
    # An empty source file without the empty_ attribute removes the target.
    sb.write("dot_file", contents="")
    state = dump(sb)
    assert ".file" not in state


def test_empty_source_file_removes_existing_destination_file(sb):
    """A source file whose contents are only whitespace removes the target."""
    # CATCHES: `isEmpty` trims whitespace, so a whitespace-only file counts as
    # empty and apply deletes an existing destination file instead of writing.
    sb.write("dot_file", contents="# contents of .file\n")
    target = sb.home / ".file"
    target.write_text("old contents\n", encoding="utf-8")
    res = sb.run(["apply", "--force", target])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert target.exists()
    sb.write("dot_file", contents="   \n\t\n")
    res = sb.run(["apply", "--force", target])
    assert res.returncode == 0, res.stderr
    assert not target.exists()


@pytest.mark.parametrize(
    "source_name, target_name, contents, perm",
    [
        ("dot_file", ".file", "# contents of .file\n", 0o644),
        (
            "executable_dot_executable",
            ".executable",
            "# contents of .executable\n",
            0o755,
        ),
        (
            "private_dot_private",
            ".private",
            "# contents of .private\n",
            0o600,
        ),
        (
            "readonly_dot_readonly",
            ".readonly",
            "# contents of .readonly\n",
            0o444,
        ),
        (
            "private_executable_dot_both",
            ".both",
            "# contents of .both\n",
            0o700,
        ),
        (
            "private_readonly_dot_rp",
            ".rp",
            "# contents of .rp\n",
            0o400,
        ),
    ],
)
def test_permission_attributes(sb, source_name, target_name, contents, perm):
    """`executable_`, `private_` and `readonly_` set the target mode."""
    # CATCHES: each prefix clears specific permission bits, so the mode
    # reported by dump and the mode on disk must match exactly.
    sb.write(source_name, contents=contents)
    state = dump(sb)
    assert state[target_name]["perm"] == perm
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert (sb.home / target_name).stat().st_mode & 0o777 == perm


def test_attribute_prefixes_are_parsed_in_a_fixed_order(sb):
    """Out-of-order attribute prefixes are kept as part of the target name."""
    # CATCHES: chezmoi strips attribute prefixes in a fixed order
    # (private_ before readonly_ before executable_), so `executable_private_`
    # only strips `executable_` and the rest of the name stays literal.
    sb.write("executable_private_dot_both", contents="# contents of .both\n")
    sb.write("readonly_private_dot_rp", contents="# contents of .rp\n")
    state = dump(sb)
    assert set(state) == {"private_dot_both", "private_dot_rp"}
    assert state["private_dot_both"] == {
        "type": "file",
        "name": "private_dot_both",
        "contents": "# contents of .both\n",
        "perm": 0o755,
    }
    assert state["private_dot_rp"] == {
        "type": "file",
        "name": "private_dot_rp",
        "contents": "# contents of .rp\n",
        "perm": 0o444,
    }


def test_symlink_attribute_creates_a_symlink(sb):
    """`symlink_dot_symlink` manages a symlink whose target is the file body."""
    # CATCHES: the file contents are the link target and the trailing newline
    # is stripped, so `.dir/subdir/file\n` links to `.dir/subdir/file`.
    sb.write("symlink_dot_symlink", contents=".dir/subdir/file\n")
    state = dump(sb)
    assert state == {
        ".symlink": {
            "type": "symlink",
            "name": ".symlink",
            "linkname": ".dir/subdir/file",
        }
    }
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert (sb.home / ".symlink").is_symlink()
    import os

    assert os.readlink(sb.home / ".symlink") == ".dir/subdir/file"


def test_literal_prefix_suppresses_attribute_parsing(sb):
    """`literal_` keeps the rest of the name verbatim."""
    # CATCHES: `literal_` strips only itself, so `literal_dot_keep` manages a
    # target really named `dot_keep` (no hidden-file mapping at all).
    sb.write("literal_dot_keep", contents="plain\n")
    sb.write("literal_literal_foo", contents="literal contents\n")
    sb.write("literal_dir/f", contents="x\n")
    state = dump(sb)
    assert set(state) == {"dot_keep", "literal_foo", "dir", "dir/f"}
    assert state["dot_keep"]["contents"] == "plain\n"
    assert state["literal_foo"]["contents"] == "literal contents\n"
    assert state["dir/f"]["contents"] == "x\n"


def test_create_attribute_only_creates_missing_targets(sb):
    """`create_` files are only applied when the target does not exist."""
    # CATCHES: create_ is a no-op once the destination file exists, even when
    # its contents differ from the source state.
    sb.write("create_dot_create", contents="# contents of .create\n")
    target = sb.home / ".create"
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert target.read_text(encoding="utf-8") == "# contents of .create\n"
    target.write_text("user edited\n", encoding="utf-8")
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert target.read_text(encoding="utf-8") == "user edited\n"


def test_nested_directories_and_exact_subdirectory(sb):
    """Directory names map recursively and `exact_` applies to one level only."""
    # CATCHES: `dot_dir/exact_subdir` maps to `.dir/subdir`, and the exact_
    # prefix applies only to the directory it is attached to, not to `.dir`.
    build_canonical(sb)
    state = dump(sb)
    assert state[".dir"] == {"type": "dir", "name": ".dir", "perm": 0o755}
    assert state[".dir/subdir"] == {
        "type": "dir",
        "name": ".dir/subdir",
        "perm": 0o755,
    }
    assert state[".dir/subdir/file"]["contents"] == "# contents of .dir/subdir/file\n"
    assert set(state[".dir"].keys()) == {"type", "name", "perm"}


def test_exact_directory_removes_unmanaged_entries(sb):
    """Entries in an `exact_` directory that are not managed are removed."""
    # CATCHES: apply removes `.dir/file2` and `.dir/subdir` from the exact
    # directory but leaves `.unmanaged` (outside it) alone.
    sb.write("exact_dot_dir/file1", contents="# contents of .dir/file1\n")
    sb.home.joinpath(".dir").mkdir(parents=True)
    sb.home.joinpath(".dir", "file1").write_text("old\n", encoding="utf-8")
    sb.home.joinpath(".dir", "file2").write_text("unmanaged\n", encoding="utf-8")
    sb.home.joinpath(".dir", "subdir").mkdir()
    sb.home.joinpath(".unmanaged").write_text("keep\n", encoding="utf-8")
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert sorted(p.name for p in (sb.home / ".dir").iterdir()) == ["file1"]
    assert (sb.home / ".unmanaged").exists()
    assert (sb.home / ".dir" / "file1").read_text(encoding="utf-8") == "# contents of .dir/file1\n"


def test_exact_directory_creates_new_entries(sb):
    """Files added to an `exact_` directory are created on the next apply."""
    # CATCHES: apply creates `.dir/file3` because the whole directory is
    # exact, not because the file was named on the command line.
    sb.write("exact_dot_dir/file1", contents="# contents of .dir/file1\n")
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    sb.write("exact_dot_dir/file3", contents="# contents of .dir/file2\n")
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert (sb.home / ".dir" / "file3").read_text(encoding="utf-8") == "# contents of .dir/file2\n"


def test_remove_attribute_removes_empty_directories(sb):
    """A `remove_` directory is deleted once apply has emptied it."""
    # CATCHES: remove_ only removes the directory when nothing is left inside,
    # so a directory with an unmanaged file is left in place.
    sb.write("remove_dot_emptydir/.keep", contents="")
    sb.home.joinpath(".emptydir").mkdir()
    sb.home.joinpath(".keepdir").mkdir()
    sb.write("remove_dot_keepdir/.keep", contents="")
    sb.home.joinpath(".keepdir", "leftover").write_text("x\n", encoding="utf-8")
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert not (sb.home / ".emptydir").exists()
    assert (sb.home / ".keepdir").exists()
    assert (sb.home / ".keepdir" / "leftover").exists()


def test_chaizmoiremove_patterns_delete_destination_entries(sb):
    """`.chezmoiremove` patterns remove matching destination entries."""
    # CATCHES: patterns support `*` wildcards and a full `apply` removes every
    # matching destination entry, while naming one target removes only that
    # one and `--dry-run` removes nothing at all.
    sb.home.joinpath(".dir").mkdir()
    sb.home.joinpath(".dir", "file").write_text("# contents of .dir/file\n", encoding="utf-8")
    sb.home.joinpath(".file1").write_text("c1\n", encoding="utf-8")
    sb.home.joinpath(".file2").write_text("c2\n", encoding="utf-8")
    sb.write(".chezmoiremove", contents=".dir\n.file*\n")
    res = sb.run(["apply", "--dry-run", "--force"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert sorted(p.name for p in sb.home.iterdir()) == [".dir", ".file1", ".file2"]
    res = sb.run(["apply", "--force", sb.home / ".file1"])
    assert res.returncode == 0, res.stderr
    assert not (sb.home / ".file1").exists()
    assert (sb.home / ".file2").exists()
    assert (sb.home / ".dir").exists()
    res = sb.run(["apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert sorted(p.name for p in sb.home.iterdir()) == []


def test_chaizmoiremove_conflicting_with_target_is_inconsistent(sb):
    """A target both present and matched by `.chezmoiremove` is an error."""
    # CATCHES: chezmoi refuses to apply and reports an inconsistent state
    # listing the conflicting source path.
    sb.write("dot_file", contents="# contents of .file\n")
    sb.write(".chezmoiremove", contents=".file\n")
    sb.home.joinpath(".file").write_text("# contents of .file\n", encoding="utf-8")
    res = sb.run(["apply", "--force"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "chezmoi: .file: inconsistent state ({}, remove)\n".format(
            sb.source / "dot_file"
        )
    )


def test_template_attribute_renders_target_contents(sb):
    """A `.tmpl` suffix turns a source file into a template."""
    # CATCHES: the rendered target contents replace the template text while
    # the source file itself is left untouched.
    sb.write("dot_template.tmpl", contents='key = {{ "value" }}\n')
    state = dump(sb)
    assert state[".template"]["contents"] == "key = value\n"
    res = sb.run(["cat", sb.home / ".template"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "key = value\n"


def test_chaizmoiroot_selects_a_subdirectory_of_the_source(sb):
    """`.chezmoiroot` makes chezmoi read the source state from a subdirectory."""
    # CATCHES: source-path and managed both resolve through the root file, so
    # `home/dot_file` manages `.file` and reports the source path under home/.
    sb.write("home/dot_file", contents="# contents of .file\n")
    sb.write(".chezmoiroot", contents="home\n")
    res = sb.run(["managed"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ".file\n"
    res = sb.run(["source-path", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == "{}\n".format(sb.source / "home" / "dot_file")


def test_source_directory_may_be_a_symlink(sb):
    """`--source` accepts a symlink to the real source directory."""
    # CATCHES: chezmoi resolves the symlink rather than rejecting it, so the
    # target file is created exactly as with a direct path.
    sb.write("dot_file", contents="# contents of .file\n")
    link = sb.root / "linked-source"
    link.symlink_to(sb.source, target_is_directory=True)
    res = sb.run(["--source", link, "apply", "--force"])
    assert res.returncode == 0, res.stderr
    assert (sb.home / ".file").read_text(encoding="utf-8") == "# contents of .file\n"


def test_dot_chaizmoiignore_excludes_targets(sb):
    """`.chezmoiignore` patterns exclude targets from the source state."""
    # CATCHES: `ignored` lists the matching target paths, `managed` omits them
    # and apply leaves the existing destination files alone.
    sb.write("dot_dir/file", contents="# contents of .dir/file\n")
    sb.write("dot_readonly", contents="# contents of .readonly\n")
    sb.write("dot_template.tmpl", contents="key = value\n")
    sb.write(".chezmoiignore", contents=".dir/subdir # Comment following pattern\n.read*\n**/file\n.template\n")
    res = sb.run(["ignored"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == lines(".dir/file", ".readonly", ".template")
    res = sb.run(["managed"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ".dir\n"
    state = dump(sb)
    assert set(state) == {".dir"}
