"""Black-box tests for the `age` command.

`chezmoi age encrypt`/`age decrypt` implement passphrase-based age
encryption.  With `--no-tty` the passphrase prompts are printed to stdout and
the answers read from standard input; the data itself is read from file
arguments and the result written to stdout.
"""

PROMPTS = "Enter passphrase: Confirm passphrase: "


def encrypt(sb, path, passphrase="s3cret", confirm=None):
    """Encrypt path with a passphrase and return the armored ciphertext."""
    confirm = passphrase if confirm is None else confirm
    res = sb.run(
        ["--no-tty", "age", "encrypt", "--passphrase", path],
        input=passphrase + "\n" + confirm + "\n",
    )
    return res


def test_age_passphrase_roundtrip(sb):
    """`age encrypt --passphrase` and `age decrypt --passphrase` round-trip."""
    # CATCHES: both passphrase prompts are printed to stdout before the
    # armored ciphertext, the plaintext comes from the file argument, and
    # decrypting the ciphertext with the same passphrase writes the original
    # plaintext to stdout after its single prompt.
    plain = sb.root / "plain.txt"
    plain.write_text("# plaintext\n", encoding="utf-8")
    res = encrypt(sb, plain)
    assert res.returncode == 0, res.stderr
    assert res.stderr == ""
    assert res.stdout.startswith(PROMPTS)
    ciphertext = res.stdout[len(PROMPTS) :]
    assert ciphertext.startswith("-----BEGIN AGE ENCRYPTED FILE-----\n")
    assert ciphertext.rstrip().endswith("-----END AGE ENCRYPTED FILE-----")
    encrypted = sb.root / "plain.txt.age"
    encrypted.write_text(ciphertext, encoding="utf-8")
    res = sb.run(
        ["--no-tty", "age", "decrypt", "--passphrase", encrypted], input="s3cret\n"
    )
    assert res.returncode == 0, res.stderr
    assert res.stderr == ""
    assert res.stdout == "Enter passphrase: # plaintext\n"


def test_age_error_paths(sb):
    """Missing flags, mismatched confirmations and bad passphrases fail."""
    # CATCHES: without --passphrase the command refuses to run at all, a
    # mismatched passphrase confirmation is an error after both prompts, an
    # empty ciphertext file is a header parse error, and a wrong passphrase
    # produces the dedicated `incorrect passphrase` diagnostic.
    res = sb.run(["age", "encrypt"], input="x\n")
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "chezmoi: only passphrase encryption is supported\n"
    res = sb.run(["age", "decrypt"], input="x\n")
    assert res.returncode == 1
    assert res.stderr == "chezmoi: only passphrase encryption is supported\n"
    res = sb.run(
        ["--no-tty", "age", "encrypt", "--passphrase"], input="s3cret\nother\n"
    )
    assert res.returncode == 1
    assert res.stdout == PROMPTS
    assert res.stderr == "chezmoi: passphrases didn't match\n"
    empty = sb.root / "empty.age"
    empty.write_text("", encoding="utf-8")
    res = sb.run(["--no-tty", "age", "decrypt", "--passphrase", empty], input="s3cret\n")
    assert res.returncode == 1
    # The header is parsed before the passphrase is requested, so no prompt.
    assert res.stdout == ""
    assert res.stderr == "chezmoi: failed to read header: parsing age header: file is empty\n"
    plain = sb.root / "plain.txt"
    plain.write_text("# plaintext\n", encoding="utf-8")
    res = encrypt(sb, plain)
    assert res.returncode == 0
    encrypted = sb.root / "plain.txt.age"
    encrypted.write_text(res.stdout[len(PROMPTS) :], encoding="utf-8")
    res = sb.run(
        ["--no-tty", "age", "decrypt", "--passphrase", encrypted], input="wrong\n"
    )
    assert res.returncode == 1
    assert res.stdout == "Enter passphrase: "
    assert res.stderr == "chezmoi: incorrect passphrase\n"
