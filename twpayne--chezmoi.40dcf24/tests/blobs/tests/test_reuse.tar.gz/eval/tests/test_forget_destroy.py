"""Black-box tests for the `forget` and `destroy` commands.

`forget` removes an entry from the source state (leaving the destination
alone) while `destroy` removes it from both the source state and the
destination directory.  Without `--force` both commands ask for confirmation;
the tests answer the questions on standard input with `--no-tty` so no
terminal is ever needed.
"""

import pytest


def source_files(sb):
    """Return the sorted relative names of the files in the source directory."""
    return sorted(
        str(path.relative_to(sb.source))
        for path in sb.source.rglob("*")
        if path.is_file()
    )


def test_forget_removes_the_source_entry_and_keeps_the_destination(sb):
    """`forget --force` deletes the source file but never touches the target."""
    # CATCHES: forget operates on the source state only - the already-applied
    # destination file survives, the entry disappears from `managed`, and
    # re-applying does not recreate the removed file.
    sb.write("dot_file", contents="# contents of .file\n")
    sb.write("dot_keep", contents="# contents of .keep\n")
    assert sb.run(["apply"]).returncode == 0
    res = sb.run(["forget", "--force", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert res.stderr == ""
    assert source_files(sb) == ["dot_keep"]
    assert (sb.home / ".file").read_text(encoding="utf-8") == "# contents of .file\n"
    managed = sb.run(["managed"])
    assert managed.returncode == 0
    assert managed.stdout == ".keep\n"
    reapplied = sb.run(["apply"])
    assert reapplied.returncode == 0
    assert (sb.home / ".file").read_text(encoding="utf-8") == "# contents of .file\n"


def test_forget_prompts_for_each_target_without_force(sb):
    """`forget` asks yes/no/all/quit per target and honours abbreviations."""
    # CATCHES: the confirmation question names the source path, is printed to
    # stdout without a trailing newline, and `y` is accepted as an
    # abbreviation of `yes` while `n` leaves the source file in place.
    sb.write("dot_file", contents="# contents of .file\n")
    sb.write("dot_keep", contents="# contents of .keep\n")
    res = sb.run(
        ["--no-tty", "forget", sb.home / ".file", sb.home / ".keep"],
        input="n\ny\n",
    )
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        "Remove {source}/dot_file (yes/no/all/quit)? "
        "Remove {source}/dot_keep (yes/no/all/quit)? "
    ).format(source=sb.source)
    assert source_files(sb) == ["dot_file"]


@pytest.mark.parametrize(
    "args, message",
    [
        (["forget", "--force", "{home}/.absent"], "chezmoi: {home}/.absent: not managed\n"),
        (["forget"], "chezmoi: requires at least 1 arg(s), only received 0\n"),
    ],
)
def test_forget_rejects_unmanaged_targets_and_missing_arguments(sb, args, message):
    """Unmanaged targets and missing arguments are diagnosed on stderr."""
    # CATCHES: forget resolves its targets through the source state, so an
    # unknown target is `not managed`, and the command needs at least one
    # target argument.
    sb.write("dot_file", contents="# contents of .file\n")
    resolved = [arg.format(home=sb.home) for arg in args]
    res = sb.run(resolved)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message.format(home=sb.home)


def test_destroy_removes_targets_from_source_and_destination(sb):
    """`destroy --force` deletes both the source entry and the target."""
    # CATCHES: destroy removes the file from the destination directory as
    # well as from the source state, and whole directories need --recursive.
    sb.write("dot_file", contents="# contents of .file\n")
    sb.write("dot_dir/f", contents="# contents of .dir/f\n")
    assert sb.run(["apply"]).returncode == 0
    res = sb.run(["destroy", "--force", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert res.stderr == ""
    assert not (sb.home / ".file").exists()
    assert source_files(sb) == ["dot_dir/f"]
    res = sb.run(["destroy", "--force", "--recursive", sb.home / ".dir"])
    assert res.returncode == 0, res.stderr
    assert source_files(sb) == []
    assert not (sb.home / ".dir").exists()
    assert list(sb.home.iterdir()) == []


def test_destroy_prompts_without_force_and_can_be_declined(sb):
    """`destroy` names both paths in its question and honours a `no`."""
    # CATCHES: the confirmation question lists the destination path and the
    # source path, answering `no` keeps everything and answering `yes` removes
    # both the destination file and its source state entry.
    sb.write("dot_file", contents="# contents of .file\n")
    assert sb.run(["apply"]).returncode == 0
    res = sb.run(["--no-tty", "destroy", sb.home / ".file"], input="no\n")
    assert res.returncode == 0, res.stderr
    assert res.stdout == (
        "Destroy {home}/.file and {source}/dot_file (yes/no/all/quit)? "
    ).format(home=sb.home, source=sb.source)
    assert (sb.home / ".file").exists()
    assert (sb.source / "dot_file").exists()
    res = sb.run(["--no-tty", "destroy", sb.home / ".file"], input="yes\n")
    assert res.returncode == 0, res.stderr
    assert not (sb.home / ".file").exists()
    assert not (sb.source / "dot_file").exists()
