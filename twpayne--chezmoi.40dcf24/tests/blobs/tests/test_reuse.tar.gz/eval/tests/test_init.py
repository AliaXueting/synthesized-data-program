"""Black-box tests for the `init` command.

`init` sets up the source directory and renders the config template
(`.chezmoi.toml.tmpl` in the source directory) to the config file.  The tests
pre-create a `.git` directory in the source directory so that init never runs
git, keeping them hermetic.
"""


def git_sandbox(sb):
    """Mark the source directory as an existing git working tree."""
    (sb.source / ".git").mkdir()
    return sb


def test_init_renders_the_config_template_to_the_config_file(sb):
    """`init` executes .chezmoi.toml.tmpl and writes the result to the config."""
    # CATCHES: the config template is rendered with the chezmoi template data
    # (here .chezmoi.os) and the rendered config is what later commands see
    # through `data` and `cat-config`.
    git_sandbox(sb)
    sb.write(
        ".chezmoi.toml.tmpl",
        contents='umask = 18\n\n[data]\n    os = "{{ .chezmoi.os }}"\n',
    )
    res = sb.run(["init"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert res.stderr == ""
    assert sb.config_file.read_text(encoding="utf-8") == (
        'umask = 18\n\n[data]\n    os = "linux"\n'
    )
    data = sb.run(["data", "--format", "json"])
    assert data.returncode == 0
    assert '        "os": "linux"' in data.stdout
    cat_config = sb.run(["cat-config"])
    assert cat_config.returncode == 0
    assert cat_config.stdout == 'umask = 18\n\n[data]\n    os = "linux"\n'


def test_init_prompts_for_template_data(sb):
    """Config templates can prompt; answers come from stdin or the flags."""
    # CATCHES: with --no-tty the promptString template function writes its
    # question to stdout and reads the answer from standard input, while the
    # --promptString flag supplies the answer without any prompt output.
    git_sandbox(sb)
    sb.write(
        ".chezmoi.toml.tmpl",
        contents='umask = 18\n\n[data]\n    greeting = "{{ promptString "greeting" }}"\n',
    )
    res = sb.run(["--no-tty", "init"], input="hello\n")
    assert res.returncode == 0, res.stderr
    assert res.stdout == "greeting? "
    assert sb.config_file.read_text(encoding="utf-8") == (
        'umask = 18\n\n[data]\n    greeting = "hello"\n'
    )
    sb.write_config("")
    res = sb.run(["init", "--promptString", "greeting=hi"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert sb.config_file.read_text(encoding="utf-8") == (
        'umask = 18\n\n[data]\n    greeting = "hi"\n'
    )


def test_init_apply_updates_the_destination_directory(sb):
    """`init --apply` renders the config and applies the source state."""
    # CATCHES: --apply applies the source state in the same run, so the
    # destination file exists immediately after init even though the config
    # file was rewritten first.
    git_sandbox(sb)
    sb.write(".chezmoi.toml.tmpl", contents="umask = 18\n")
    sb.write("dot_file", contents="# from source\n")
    res = sb.run(["init", "--apply"])
    assert res.returncode == 0, res.stderr
    assert (sb.home / ".file").read_text(encoding="utf-8") == "# from source\n"
    assert sb.config_file.read_text(encoding="utf-8") == "umask = 18\n"
