"""Black-box tests for the `purge` command.

`purge` removes everything chezmoi owns - the cache directory, the
configuration file and its directory, the persistent state and the source
directory - but never the managed files in the destination directory.  Without
`--force` it asks for confirmation for every path.
"""


def relative_tree(root):
    """Return the sorted paths of everything under root, files and dirs."""
    return sorted(str(path.relative_to(root)) for path in root.rglob("*"))


def test_purge_force_removes_chazmoi_data_but_not_destination(sb):
    """`purge --force` removes config, cache, state and source, not the home."""
    # CATCHES: purge deletes every chezmoi-owned path (cache, config dir and
    # file, persistent state, working tree and source directory) while the
    # applied destination files survive untouched.
    sb.write("dot_file", contents="# contents of .file\n")
    assert sb.run(["apply"]).returncode == 0
    assert (sb.state_file).exists()
    res = sb.run(["purge", "--force"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert res.stderr == ""
    assert relative_tree(sb.root) == ["config", "home", "home/.file", "state", "tmp"]
    assert (sb.home / ".file").read_text(encoding="utf-8") == "# contents of .file\n"


def test_purge_prompts_for_every_path_without_force(sb):
    """`purge` asks about each path in a fixed order and can be declined."""
    # CATCHES: without --force purge asks about every path it would remove -
    # cache, config directory, config file, persistent state, working tree and
    # source directory (twice, as both working tree and source) - and a `no`
    # answer keeps every path on disk.
    sb.write("dot_file", contents="# contents of .file\n")
    assert sb.run(["apply"]).returncode == 0
    res = sb.run(
        ["--no-tty", "purge"],
        input="no\nno\nno\nno\nno\nno\n",
    )
    assert res.returncode == 0, res.stderr
    questions = [
        "Remove {path} (yes/no/all/quit)? ".format(path=path)
        for path in (
            sb.cache,
            sb.config_dir,
            sb.config_file,
            sb.state_file,
            sb.source,
            sb.source,
        )
    ]
    assert res.stdout == "".join(questions)
    assert (sb.source / "dot_file").exists()
    assert sb.config_file.exists()
    assert sb.state_file.exists()
    assert sb.cache.exists()
    res = sb.run(["--no-tty", "purge"], input="all\n")
    assert res.returncode == 0, res.stderr
    assert res.stdout == "Remove {cache} (yes/no/all/quit)? ".format(cache=sb.cache)
    assert not sb.source.exists()
    assert not sb.config_file.exists()
