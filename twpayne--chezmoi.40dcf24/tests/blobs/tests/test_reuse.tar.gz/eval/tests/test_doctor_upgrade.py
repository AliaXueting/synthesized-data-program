"""Black-box tests for the `doctor` and `upgrade` commands.

`doctor` runs a battery of environment checks and prints a tab-aligned
RESULT/CHECK/MESSAGE table; `upgrade` refuses to run for a dev build unless
forced.  The doctor probes here always pass `--no-network` so that no test
ever touches the network.
"""

import re


DOCTOR_ROWS = [
    r"^ok\s+source-dir\s+{source} is a directory$",
    r"^ok\s+dest-dir\s+~ is a directory$",
    r"^ok\s+hardlink\s+created hardlink from {source} to {tmp}$",
    r"^ok\s+symlink\s+created symlink from \.new-name to \.old-name$",
    r"^ok\s+umask\s+002$",
    r"^ok\s+cd-command\s+found /bin/sh$",
    r"^ok\s+cd-args\s+/bin/sh$",
    r"^ok\s+edit-command\s+found /bin/true$",
    r"^info\s+diff-command\s+not set$",
    r"^info\s+bitwarden-command\s+bw not found in \$PATH$",
    r"^info\s+keepassxc-command\s+keepassxc-cli not found in \$PATH$",
    r"^skipped\s+latest-version\s+no network$",
    r"^ok\s+config-file\s+found .+chezmoi\.toml, last modified .+$",
]


def test_doctor_prints_check_table(sb):
    """`doctor --no-network` prints the RESULT/CHECK/MESSAGE check table."""
    # CATCHES: every check is reported as a padded table row whose status
    # reflects the sandboxed environment, the home directory is concealed as
    # `~`, and warnings alone (the dev version) do not fail the command.
    sb.write("dot_file", contents="# contents of .file\n")
    res = sb.run(["doctor", "--no-network"])
    assert res.returncode == 0, res.stderr
    assert res.stderr == ""
    lines = res.stdout.splitlines()
    assert re.match(r"RESULT\s+CHECK\s+MESSAGE$", lines[0])
    patterns = [
        pattern.format(
            source=re.escape(str(sb.source)),
            tmp=re.escape(str(sb.tmp)),
        )
        for pattern in DOCTOR_ROWS
    ]
    for pattern in patterns:
        assert re.search(pattern, res.stdout, re.MULTILINE), pattern
    for line in lines[1:]:
        assert re.match(r"^(ok|info|warning|skipped)\s+\S+\s+\S", line), line


def test_doctor_reports_missing_config_file(sb):
    """`doctor` downgrades the config-file check when the file is absent."""
    # CATCHES: with a configured-but-missing config file the config-file row
    # becomes `info` naming the exact path, and the command still succeeds.
    absent = sb.config_dir / "absent.toml"
    res = sb.run(["--config", absent, "doctor", "--no-network"])
    assert res.returncode == 0, res.stderr
    assert re.search(
        r"^info\s+config-file\s+{}: not found$".format(re.escape(str(absent))),
        res.stdout,
        re.MULTILINE,
    )


def test_doctor_rejects_arguments(sb):
    """`doctor` takes no arguments and reports them as an unknown command."""
    # CATCHES: extra arguments are rejected with cobra's unknown-command
    # diagnostic for the `chezmoi doctor` command path, not silently ignored.
    res = sb.run(["doctor", "--no-network", "extra"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'chezmoi: unknown command "extra" for "chezmoi doctor"\n'


def test_upgrade_dev_version_requires_force(sb):
    """`upgrade` refuses to upgrade a dev build without `--force`."""
    # CATCHES: the reference is a dev build with no release version, so
    # `upgrade` fails before any network access with a dedicated message.
    res = sb.run(["upgrade"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "chezmoi: cannot upgrade dev version to latest released version "
        "unless --force is set\n"
    )
