"""Black-box tests for the `re-add` and `merge` commands.

`re-add` re-adds files whose contents in the destination directory differ
from the target state, `merge` hands a three-way merge to an external command.
The tests replace the merge command with a script inside the sandbox that
prints its arguments, so no real merge tool is ever needed.
"""

import re

import pytest

MERGE_SCRIPT = (
    "#!/bin/sh\n"
    'for a in "$@"; do echo "arg=$a"; done\n'
    'echo "target-contents:"\n'
    'cat "$3" 2>/dev/null || true\n'
)


def test_re_add_updates_modified_files_but_not_templates(sb):
    """`re-add` copies modified destination files back into the source state."""
    # CATCHES: only files whose destination contents differ from the target
    # state are re-added - unchanged files and template files are left alone.
    sb.write("dot_file", contents="# original\n")
    sb.write("dot_keep", contents="# keep\n")
    sb.write("dot_tmpl.tmpl", contents="{{ .chezmoi.os }}\n")
    assert sb.run(["apply"]).returncode == 0
    (sb.home / ".file").write_text("# modified\n", encoding="utf-8")
    res = sb.run(["re-add"])
    assert res.returncode == 0, res.stderr
    assert res.stdout == ""
    assert res.stderr == ""
    assert (sb.source / "dot_file").read_text(encoding="utf-8") == "# modified\n"
    assert (sb.source / "dot_keep").read_text(encoding="utf-8") == "# keep\n"
    assert (sb.source / "dot_tmpl.tmpl").read_text(encoding="utf-8") == "{{ .chezmoi.os }}\n"


def test_re_add_synchronizes_exact_directories(sb):
    """`re-add` adds new and removes deleted files inside exact_ directories."""
    # CATCHES: exact_ directories are synchronized in both directions - a file
    # created in the destination is added to the source state and a file
    # deleted from the destination is removed from the source state.
    sb.write("exact_dot_dir/keep", contents="# keep\n")
    sb.write("exact_dot_dir/gone", contents="# gone\n")
    assert sb.run(["apply"]).returncode == 0
    (sb.home / ".dir" / "new").write_text("# new\n", encoding="utf-8")
    (sb.home / ".dir" / "gone").unlink()
    res = sb.run(["re-add"])
    assert res.returncode == 0, res.stderr
    source_names = sorted(
        str(path.relative_to(sb.source))
        for path in sb.source.rglob("*")
        if path.is_file()
    )
    assert source_names == ["exact_dot_dir/keep", "exact_dot_dir/new"]
    # Re-applying the synchronized source state removes the deleted file's
    # state and keeps the new file.
    reapplied = sb.run(["apply"])
    assert reapplied.returncode == 0
    assert (sb.home / ".dir" / "new").exists()
    assert not (sb.home / ".dir" / "gone").exists()


def test_re_add_limits_scope_to_the_given_targets(sb):
    """`re-add target...` only re-adds the requested targets."""
    # CATCHES: passing a target restricts the re-add to that target, so other
    # modified destination files keep their stale source state.
    sb.write("dot_file", contents="# original\n")
    sb.write("dot_two", contents="# two\n")
    assert sb.run(["apply"]).returncode == 0
    (sb.home / ".file").write_text("# modified\n", encoding="utf-8")
    (sb.home / ".two").write_text("# modified two\n", encoding="utf-8")
    res = sb.run(["re-add", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    assert (sb.source / "dot_file").read_text(encoding="utf-8") == "# modified\n"
    assert (sb.source / "dot_two").read_text(encoding="utf-8") == "# two\n"


def test_merge_invokes_the_merge_command_with_destination_source_target(sb):
    """`merge` runs the merge command with the destination, source and target."""
    # CATCHES: the merge command receives exactly three arguments - the
    # destination path, the source path and a temporary file holding the
    # target state - and configured non-template args are prepended to them.
    merge_script = sb.script("merge.sh", MERGE_SCRIPT)
    sb.write("dot_file", contents="# source contents\n")
    assert sb.run(["apply"]).returncode == 0
    (sb.home / ".file").write_text("# dest contents\n", encoding="utf-8")
    sb.write_config('[merge]\n    command = "{script}"\n'.format(script=merge_script))
    res = sb.run(["merge", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    pattern = (
        r"arg={home}/\.file\n"
        r"arg={source}/dot_file\n"
        r"arg={tmp}/chezmoi-merge\d+/\.file\n"
        r"target-contents:\n"
        r"# source contents\n"
    ).format(
        home=re.escape(str(sb.home)),
        source=re.escape(str(sb.source)),
        tmp=re.escape(str(sb.tmp)),
    )
    assert re.fullmatch(pattern, res.stdout), res.stdout
    # A plain merge.args value is prepended, the three paths still appended.
    sb.write_config(
        '[merge]\n    command = "{script}"\n    args = ["--flag"]\n'.format(
            script=merge_script
        )
    )
    res = sb.run(["merge", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    pattern = (
        r"arg=--flag\n"
        r"arg={home}/\.file\n"
        r"arg={source}/dot_file\n"
        r"arg={tmp}/chezmoi-merge\d+/\.file\n"
        r"target-contents:\n"
        r"# source contents\n"
    ).format(
        home=re.escape(str(sb.home)),
        source=re.escape(str(sb.source)),
        tmp=re.escape(str(sb.tmp)),
    )
    assert re.fullmatch(pattern, res.stdout), res.stdout


def test_merge_template_args_replace_the_default_arguments(sb):
    """Template merge.args replace the automatic destination/source/target."""
    # CATCHES: when any merge.args entry is a template, chezmoi stops
    # appending the destination, source and target paths - the invocation is
    # exactly the rendered merge.args.
    merge_script = sb.script("merge.sh", MERGE_SCRIPT)
    sb.write("dot_file", contents="# source contents\n")
    assert sb.run(["apply"]).returncode == 0
    (sb.home / ".file").write_text("# dest contents\n", encoding="utf-8")
    sb.write_config(
        '[merge]\n'
        '    command = "{script}"\n'
        '    args = ["--target", "{{{{ .Target }}}}"]\n'.format(script=merge_script)
    )
    res = sb.run(["merge", sb.home / ".file"])
    assert res.returncode == 0, res.stderr
    pattern = (
        r"arg=--target\n"
        r"arg={tmp}/chezmoi-merge\d+/\.file\n"
        r"target-contents:\n"
    ).format(tmp=re.escape(str(sb.tmp)))
    assert re.fullmatch(pattern, res.stdout), res.stdout


@pytest.mark.parametrize(
    "args, message",
    [
        (["merge", "{home}/.absent"], "chezmoi: {home}/.absent: not managed\n"),
        (["merge"], "chezmoi: requires at least 1 arg(s), only received 0\n"),
    ],
)
def test_merge_rejects_unmanaged_targets_and_missing_arguments(sb, args, message):
    """Unmanaged targets and missing arguments are diagnosed on stderr."""
    # CATCHES: merge resolves its targets through the source state, so an
    # unknown target is `not managed`, and the command needs at least one
    # target argument.
    sb.write("dot_file", contents="# contents of .file\n")
    resolved = [arg.format(home=sb.home) for arg in args]
    res = sb.run(resolved)
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == message.format(home=sb.home)
