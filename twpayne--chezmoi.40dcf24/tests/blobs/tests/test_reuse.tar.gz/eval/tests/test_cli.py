"""Black-box tests for the top-level command line interface.

These cover the help/version/licence/completion surface and the error
reporting for unknown commands and flags.
"""

import re

import pytest

from conftest import lines

LICENSE = lines(
    "",
    "  The MIT License (MIT)",
    "",
    "  Copyright (c) 2018 Tom Payne",
    "",
    "  Permission is hereby granted, free of charge, to any person obtaining a copy",
    "  of this software and associated documentation files (the \"Software\"), to",
    "  deal in the Software without restriction, including without limitation the",
    "  rights to use, copy, modify, merge, publish, distribute, sublicense, and/or",
    "  sell copies of the Software, and to permit persons to whom the Software is",
    "  furnished to do so, subject to the following conditions:",
    "",
    "  The above copyright notice and this permission notice shall be included in",
    "  all copies or substantial portions of the Software.",
    "",
    "  THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR",
    "  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,",
    "  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE",
    "  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER",
    "  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING",
    "  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS",
    "  IN THE SOFTWARE.",
    "",
)

COMPLETION_HEADS = {
    "bash": "# bash completion V2 for chezmoi",
    "zsh": "#compdef chezmoi",
    "fish": "# fish completion for chezmoi",
    "powershell": "# powershell completion for chezmoi",
}


def test_root_help_prints_usage_and_command_groups(sb):
    """`chezmoi --help` prints the description, usage and command groups."""
    # CATCHES: the synopsis, the command grouping headers and the trailing
    # global flags section must all be present on stdout with exit code 0.
    res = sb.run(["--help"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout.startswith(
        "Manage your dotfiles across multiple diverse machines, securely\n\n"
        "Usage:\n  chezmoi [command]\n"
    )
    for header in (
        "Documentation commands:",
        "Daily commands:",
        "Template commands:",
        "Advanced commands:",
        "Encryption commands:",
        "Remote commands:",
        "Migration commands:",
        "Internal commands:",
        "Flags:",
    ):
        assert header in res.stdout
    assert "  apply                Update the destination directory to match the target state" in res.stdout
    assert "-S, --source path" in res.stdout


def test_no_arguments_prints_help_to_stdout(sb):
    """Running chezmoi with no arguments prints help and exits successfully."""
    # CATCHES: an empty invocation is not an error - it prints the same help
    # text to stdout and exits 0 rather than exiting non-zero.
    res = sb.run([])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout.startswith(
        "Manage your dotfiles across multiple diverse machines, securely\n\n"
        "Usage:\n  chezmoi [command]\n"
    )


def test_help_command_matches_help_flag(sb):
    """`chezmoi help` prints the same help as `--help` minus two flag lines."""
    # CATCHES: the help subcommand reuses the flag renderer but omits the
    # `-h, --help` and `--version` lines that cobra only adds for `--help`.
    via_flag = sb.run(["--help"])
    via_command = sb.run(["help"])
    assert via_flag.returncode == 0
    assert via_command.returncode == 0
    assert via_command.stderr == ""
    assert via_flag.stdout.startswith(
        "Manage your dotfiles across multiple diverse machines, securely\n\n"
        "Usage:\n  chezmoi [command]\n"
    )
    assert via_command.stdout.startswith(
        "Manage your dotfiles across multiple diverse machines, securely\n\n"
        "Usage:\n  chezmoi [command]\n"
    )
    help_only = [
        line
        for line in via_flag.stdout.splitlines()
        if line not in via_command.stdout.splitlines()
    ]
    assert help_only == [
        "  -h, --help                                           help for chezmoi",
        "      --version                                        version for chezmoi",
    ]
    stripped = via_flag.stdout
    for line in help_only:
        stripped = stripped.replace(line + "\n", "")
    assert via_command.stdout == stripped


def test_help_subcommand_describes_add(sb):
    """`chezmoi help add` prints the long description of the add command."""
    # CATCHES: subcommand help starts with a Description section and lists the
    # `manage` alias rather than only the short one-line synopsis.
    res = sb.run(["help", "add"])
    assert res.returncode == 0
    assert res.stdout.startswith(
        "Description\n"
        "  Add targets to the source state. If any target is already in the source\n"
        "  state, then its source state is replaced with its current state in the\n"
        "  destination directory.\n"
        "\n"
        "Usage:\n"
        "  chezmoi add targets... [flags]\n"
    )
    assert "Aliases:\n  add, manage" in res.stdout


def test_version_reports_commit_and_build_metadata(sb):
    """`chezmoi --version` prints one line of version metadata."""
    # CATCHES: the version line is comma-separated and always contains the
    # version, the commit hash and the build timestamp; the trailing
    # `built by` field is present only in builds that define it.
    res = sb.run(["--version"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert re.fullmatch(
        r"chezmoi version [^,]+, commit [0-9a-f]{7,40}, "
        r"built at \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z"
        r"(, built by \S+)?\n",
        res.stdout,
    )


def test_license_prints_mit_licence_text(sb):
    """`chezmoi license` prints the MIT licence verbatim."""
    # CATCHES: the licence is indented by two spaces, starts with a blank line
    # and ends with a blank line; it is not merely a pointer to a file.
    res = sb.run(["license"])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout == LICENSE


def test_unknown_command_is_reported_on_stderr(sb):
    """An unknown subcommand is an error naming the offending command."""
    # CATCHES: the diagnostic goes to stderr prefixed with `chezmoi:` and
    # quotes the unknown command name.
    res = sb.run(["frobnicate"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == 'chezmoi: unknown command "frobnicate" for "chezmoi"\n'


def test_unknown_flag_is_reported_on_stderr(sb):
    """An unknown global flag is an error naming the offending flag."""
    # CATCHES: unknown flags are reported as `unknown flag:` and never fall
    # through to being interpreted as a target argument.
    res = sb.run(["--frobnicate"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "chezmoi: unknown flag: --frobnicate\n"


def test_missing_source_directory_is_an_error(sb):
    """Applying from a non-existent source directory reports a stat error."""
    # CATCHES: the message names the missing path and the errno string, and
    # the destination directory is left untouched.
    res = sb.run(["--source", sb.root / "absent", "apply"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == (
        "chezmoi: stat {}: no such file or directory\n".format(
            sb.root / "absent"
        )
    )


@pytest.mark.parametrize("shell, header", sorted(COMPLETION_HEADS.items()))
def test_completion_generates_shell_script(sb, shell, header):
    """`chezmoi completion SHELL` writes a shell-specific script to stdout."""
    # CATCHES: each shell gets a different, non-empty script whose first line
    # identifies the shell, and the output goes to stdout with exit code 0.
    res = sb.run(["completion", shell])
    assert res.returncode == 0
    assert res.stderr == ""
    assert res.stdout.startswith(header)
    assert len(res.stdout) > 2000


def test_completion_rejects_unsupported_shell(sb):
    """An unsupported shell name is rejected with a diagnostic."""
    # CATCHES: only bash, zsh, fish and powershell are accepted; anything else
    # is reported as `unsupported shell`, not silently ignored.
    res = sb.run(["completion", "tcsh"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "chezmoi: tcsh: unsupported shell\n"


def test_completion_requires_exactly_one_argument(sb):
    """`chezmoi completion` without a shell is an argument count error."""
    # CATCHES: the completion command takes exactly one argument and reports
    # the count it actually received.
    res = sb.run(["completion"])
    assert res.returncode == 1
    assert res.stdout == ""
    assert res.stderr == "chezmoi: accepts 1 arg(s), received 0\n"
