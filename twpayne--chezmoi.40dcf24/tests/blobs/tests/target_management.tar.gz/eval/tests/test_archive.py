"""Tests for ``chezmoi archive``."""

import gzip
import io
import tarfile
import zipfile

import pytest


@pytest.fixture()
def populated(chez):
    """A source state with a dir, files, a symlink and a script."""
    chez.write(".plain", "plain-content\n")
    chez.write(".tpl", "os={{ .chezmoi.os }}\n")
    chez.write(".tgt", "t\n")
    chez.symlink(".tgt", ".sl")
    chez.write(".d/f", "df\n")
    assert chez.run("add", ".plain", ".sl", ".d").returncode == 0
    assert chez.run("add", "--template", ".tpl").returncode == 0
    chez.write_source("run_once_script.sh", "#!/bin/sh\necho hello-script\n")
    return chez


def _tar_members(data):
    """Parse a tar from bytes and return {name: (mode, size, linkname, body)}."""
    members = {}
    with tarfile.open(fileobj=io.BytesIO(data)) as tar:
        for info in tar.getmembers():
            body = b""
            if info.isfile():
                body = tar.extractfile(info).read()
            members[info.name] = (
                info.mode,
                info.size,
                info.linkname,
                body,
            )
    return members


def test_archive_tar(populated):
    """archive --format tar writes the rendered target state to stdout."""
    # CATCHES: a wrong re-implementation breaks: tar archive: 0755 dirs, 0644 files, 0700 scripts, rendered templates.
    result = populated.run("archive", "--format", "tar")
    assert result.returncode == 0
    assert result.stderr == b""
    members = _tar_members(result.stdout)
    assert sorted(members) == [
        ".d",
        ".d/f",
        ".plain",
        ".sl",
        ".tpl",
        "script.sh",
    ]
    # directories carry 0755, plain files 0644 and scripts 0700
    assert members[".d"][0] == 0o755
    assert members[".d/f"] == (0o644, 3, "", b"df\n")
    assert members[".plain"] == (0o644, 14, "", b"plain-content\n")
    # the template entry is archived already rendered
    assert members[".tpl"] == (0o644, 9, "", b"os=linux\n")
    # symlinks are stored as linknames
    assert members[".sl"] == (0, 0, ".tgt", b"")
    assert members["script.sh"] == (0o700, 28, "", b"#!/bin/sh\necho hello-script\n")


@pytest.mark.parametrize("fmt", ["tar.gz", "tgz"])
def test_archive_gzip_formats(populated, fmt):
    """--format tar.gz and tgz both produce gzip-compressed tars."""
    # CATCHES: a wrong re-implementation breaks: tar.gz and tgz both produce gzip streams of the same tar.
    result = populated.run("archive", "--format", fmt)
    assert result.returncode == 0
    members = _tar_members(gzip.decompress(result.stdout))
    assert sorted(members) == [".d", ".d/f", ".plain", ".sl", ".tpl", "script.sh"]
    assert members[".plain"][3] == b"plain-content\n"


def test_archive_gzip_flag(populated):
    """-z/--gzip compresses the default tar format."""
    # CATCHES: a wrong re-implementation breaks: -z emits a gzip stream (1f 8b magic) of the tar target state.
    result = populated.run("archive", "--gzip")
    assert result.returncode == 0
    assert result.stdout[:2] == b"\x1f\x8b"
    members = _tar_members(gzip.decompress(result.stdout))
    assert sorted(members) == [".d", ".d/f", ".plain", ".sl", ".tpl", "script.sh"]


def test_archive_zip(populated):
    """--format zip stores attrs in the external attributes."""
    # CATCHES: a wrong re-implementation breaks: zip attrs: dirs without slash, 0o120000 symlinks, 0700 scripts.
    result = populated.run("archive", "--format", "zip")
    assert result.returncode == 0
    assert result.stderr == b""
    zf = zipfile.ZipFile(io.BytesIO(result.stdout))
    infos = {i.filename: i for i in zf.infolist()}
    # directory entries carry no trailing slash but do carry the dir mode
    assert sorted(infos) == [".d", ".d/f", ".plain", ".sl", ".tpl", "script.sh"]
    assert (infos[".d"].external_attr >> 16) == 0o40755
    assert zf.read(".d/f") == b"df\n"
    assert (infos[".d/f"].external_attr >> 16) == 0o100644
    assert zf.read(".plain") == b"plain-content\n"
    assert zf.read(".tpl") == b"os=linux\n"
    # symlinks store mode 0o120000 and the link target as the contents
    assert (infos[".sl"].external_attr >> 16) == 0o120000
    assert zf.read(".sl") == b".tgt"
    # scripts are archived executable-only by the owner
    assert (infos["script.sh"].external_attr >> 16) == 0o100700
    assert zf.read("script.sh") == b"#!/bin/sh\necho hello-script\n"


def test_archive_output_file(populated):
    """-o/--output writes the archive to a file instead of stdout."""
    # CATCHES: a wrong re-implementation breaks: -o writes the archive to a file and leaves stdout empty.
    out = populated.root / "out.tar"
    result = populated.run("archive", "--format", "tar", "--output", str(out))
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    members = _tar_members(out.read_bytes())
    assert sorted(members) == [".d", ".d/f", ".plain", ".sl", ".tpl", "script.sh"]


def test_archive_target_filter(populated):
    """archive with a target argument archives only that target."""
    # CATCHES: a wrong re-implementation breaks: archive with a target argument archives only that target.
    result = populated.run("archive", "--format", "tar", ".plain")
    assert result.returncode == 0
    members = _tar_members(result.stdout)
    assert sorted(members) == [".plain"]
    assert members[".plain"][3] == b"plain-content\n"


def test_archive_unmanaged_target(populated):
    """archive of an unmanaged target fails."""
    # CATCHES: a wrong re-implementation breaks: archive of an unmanaged target fails with 'not managed'.
    result = populated.run("archive", "--format", "zip", ".nope")
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: .nope: not managed\n"


def test_archive_invalid_format(populated):
    """archive rejects unknown formats."""
    # CATCHES: a wrong re-implementation breaks: archive rejects unknown --format values via the flag validator.
    result = populated.run("archive", "--format", "bogus")
    assert result.returncode == 1
    assert result.stderr == (
        b'chezmoi: invalid argument "bogus" for "-f, --format" flag: '
        b"invalid value\n"
    )


def test_archive_empty_source(chez):
    """An empty source state archives to a valid empty tar."""
    # CATCHES: a wrong re-implementation breaks: an empty source state archives to a 1024-byte empty tar.
    chez.source.mkdir(parents=True, exist_ok=True)
    result = chez.run("archive", "--format", "tar")
    assert result.returncode == 0
    assert result.stderr == b""
    assert len(result.stdout) == 1024
    assert _tar_members(result.stdout) == {}


def test_archive_missing_source_dir(chez):
    """archive fails when the source directory does not exist."""
    # CATCHES: a wrong re-implementation breaks: archive on a missing source directory reports the stat error.
    result = chez.run("archive", "--format", "tar")
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: stat @HOME@/dot: no such file or directory\n"
    )
