"""Tests for ``chezmoi add`` (alias ``manage``)."""

import pytest


def test_add_plain_file(chez):
    """Adding a dotfile creates the dot_-prefixed source state entry."""
    # CATCHES: a wrong re-implementation breaks: dot_ source naming for files directly in the destination root.
    chez.write(".bashrc", "hello world\n")
    result = chez.run("add", ".bashrc")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert chez.source_paths() == ["dot_bashrc"]
    assert chez.read_source("dot_bashrc") == b"hello world\n"


def test_add_derives_attributes_from_mode(chez):
    """File mode bits on disk become private_/executable_/readonly_ prefixes."""
    # CATCHES: a wrong re-implementation breaks: private_/executable_/readonly_ prefixes derived from on-disk mode bits.
    chez.write(".plain", "p\n", mode=0o644)
    chez.write(".priv", "secret\n", mode=0o600)
    chez.write(".exe", "run\n", mode=0o755)
    chez.write(".ro", "ro\n", mode=0o400)
    result = chez.run("add", ".plain", ".priv", ".exe", ".ro")
    assert result.returncode == 0
    assert chez.source_paths() == [
        "dot_plain",
        "executable_dot_exe",
        "private_dot_priv",
        "private_readonly_dot_ro",
    ]
    assert chez.read_source("private_dot_priv") == b"secret\n"
    assert chez.read_source("executable_dot_exe") == b"run\n"


def test_add_symlink(chez):
    """A symlink becomes a symlink_-prefixed file holding the link target."""
    # CATCHES: a wrong re-implementation breaks: symlinks become symlink_ files holding the link target plus newline.
    chez.write(".tgt", "t\n")
    chez.symlink(".tgt", ".rel")
    result = chez.run("add", ".rel")
    assert result.returncode == 0
    assert chez.source_paths() == ["symlink_dot_rel"]
    assert chez.read_source("symlink_dot_rel") == b".tgt\n"


def test_add_follow_symlink(chez):
    """-f/--follow adds the symlink target's contents as a regular file."""
    # CATCHES: a wrong re-implementation breaks: --follow stores the symlink target's contents as a regular file.
    chez.mkdir("fd2")
    chez.write("fd2/real", "tc\n")
    chez.symlink("fd2/real", ".fl")
    result = chez.run("add", "--follow", ".fl")
    assert result.returncode == 0
    assert chez.source_paths() == ["dot_fl"]
    assert chez.read_source("dot_fl") == b"tc\n"


def test_add_directory_recursive_by_default(chez):
    """Adding a directory adds the whole tree; -r defaults to true."""
    # CATCHES: a wrong re-implementation breaks: add on a directory walks the whole tree without needing -r.
    chez.write("rd/top", "top\n")
    chez.write("rd/sub/f1", "f1\n")
    result = chez.run("add", "rd")
    assert result.returncode == 0
    assert chez.source_paths() == ["rd", "rd/sub", "rd/sub/f1", "rd/top"]


def test_add_exact_directory(chez):
    """--exact records the directory as exact_ so later deletes propagate."""
    # CATCHES: a wrong re-implementation breaks: --exact prefixes the directory source name with exact_.
    chez.write("foodir/a", "a\n")
    chez.write("foodir/b", "b\n")
    result = chez.run("add", "--exact", "foodir")
    assert result.returncode == 0
    assert chez.source_paths() == ["exact_foodir", "exact_foodir/a", "exact_foodir/b"]


def test_add_empty_directory_creates_keep(chez):
    """Empty directories are represented by a zero-byte .keep file."""
    # CATCHES: a wrong re-implementation breaks: empty directories are stored as a zero-byte 0644 .keep file.
    chez.mkdir("emptydir")
    result = chez.run("add", "emptydir")
    assert result.returncode == 0
    assert chez.source_paths() == ["emptydir", "emptydir/.keep"]
    assert chez.read_source("emptydir/.keep") == b""
    assert chez.source_mode("emptydir/.keep") == "0o644"


def test_add_template_flag(chez):
    """-T/--template appends .tmpl and stores the file verbatim."""
    # CATCHES: a wrong re-implementation breaks: -T appends .tmpl to the source name and stores contents verbatim.
    chez.write(".tmplfile", "v1\n")
    result = chez.run("add", "--template", ".tmplfile")
    assert result.returncode == 0
    assert chez.source_paths() == ["dot_tmplfile.tmpl"]
    assert chez.read_source("dot_tmplfile.tmpl") == b"v1\n"


def test_add_autotemplate_escapes_markers(chez):
    """--autotemplate escapes literal template markers into template syntax."""
    # CATCHES: a wrong re-implementation breaks: autotemplate escapes {{ and }} into {{ "{{" }} style literals.
    chez.write(".at", "host={{ .chezmoi.hostname }}\nliteral {{{{ raw }}}}\n")
    result = chez.run("add", "--autotemplate", ".at")
    assert result.returncode == 0
    assert chez.source_paths() == ["dot_at.tmpl"]
    assert chez.read_source("dot_at.tmpl") == (
        b'host={{ "{{" }} .chezmoi.hostname {{ "}}" }}\n'
        b'literal {{ "{{{{" }} raw {{ "}}}}" }}\n'
    )


def test_add_autotemplate_substitutes_paths(chez):
    """--autotemplate replaces known data values with template references."""
    # CATCHES: a wrong re-implementation breaks: autotemplate rewrites known data values into template references.
    chez.write(".hf", "path=%s/.vimrc\n" % chez.home)
    result = chez.run("add", "--autotemplate", ".hf")
    assert result.returncode == 0
    assert chez.read_source("dot_hf.tmpl") == (
        b"path={{ .chezmoi.commandDir }}{{ .chezmoi.pathSeparator }}.vimrc\n"
    )


def test_add_create_flag(chez):
    """--create stores the file with the create_ attribute."""
    # CATCHES: a wrong re-implementation breaks: --create maps the target to a create_ source entry.
    chez.write(".cf", "content\n")
    result = chez.run("add", "--create", ".cf")
    assert result.returncode == 0
    assert chez.source_paths() == ["create_dot_cf"]
    assert chez.read_source("create_dot_cf") == b"content\n"


def test_add_new_flag(chez):
    """--new adds a missing target with the empty_ attribute only."""
    # CATCHES: a wrong re-implementation breaks: --new only records empty_; the file appears after apply.
    result = chez.run("add", "--new", ".brandnew")
    assert result.returncode == 0
    # the destination file is not created by add itself...
    assert not (chez.home / ".brandnew").exists()
    assert chez.source_paths() == ["empty_dot_brandnew"]
    assert chez.read_source("empty_dot_brandnew") == b""
    # ...but applying the target state creates it empty
    assert chez.run("apply").returncode == 0
    assert (chez.home / ".brandnew").read_bytes() == b""


def test_add_nonexistent_target(chez):
    """Adding a missing target fails with an lstat error."""
    # CATCHES: a wrong re-implementation breaks: exact lstat error message and exit code for missing targets.
    result = chez.run("add", ".nope")
    assert result.returncode == 1
    assert result.stdout == b""
    assert chez.norm(result.stderr) == (
        b"chezmoi: lstat @HOME@/.nope: no such file or directory\n"
    )


def test_add_requires_target(chez):
    """add without arguments reports the argument count error."""
    # CATCHES: a wrong re-implementation breaks: zero-argument add fails with the argument-count message.
    result = chez.run("add")
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b"chezmoi: requires at least 1 arg(s), only received 0\n"
    )


def test_add_target_outside_destination(chez):
    """Targets outside the destination directory are refused."""
    # CATCHES: a wrong re-implementation breaks: targets outside the destination directory are refused with both paths.
    outside = chez.root / "outside.txt"
    outside.write_text("x\n")
    result = chez.run("add", "../outside.txt")
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @ROOT@/outside.txt: not in destination directory (@HOME@)\n"
    )


@pytest.mark.parametrize(
    "target,mk",
    [
        # the source directory itself is protected
        ("dot", lambda c: c.source.mkdir(parents=True, exist_ok=True)),
        # the cache directory is protected
        (
            ".cache/chezmoi",
            lambda c: c.mkdir(".cache/chezmoi"),
        ),
    ],
)
def test_add_refuses_protected_directories(chez, target, mk):
    """chezmoi refuses to add its own source or cache directory."""
    # CATCHES: a wrong re-implementation breaks: the source and cache directories are protected from being added.
    mk(chez)
    result = chez.run("add", target)
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @HOME@/" + target.encode() +
        b": cannot add chezmoi file to chezmoi (@HOME@/" + target.encode() +
        b" is protected)\n"
    )


def test_add_refuses_working_tree(chez):
    """chezmoi refuses to add the working tree directory."""
    # CATCHES: a wrong re-implementation breaks: the working tree directory is protected from being added.
    wt = chez.mkdir("wt")
    chez.source = wt / "dot"
    chez.source.mkdir(parents=True, exist_ok=True)
    chez.write("wt/keepfile", "k\n")
    result = chez.run(
        "add", str(wt),
        global_args=[
            "--source", str(chez.source),
            "--destination", str(chez.home),
            "-W", str(wt),
        ],
    )
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @HOME@/wt: cannot add chezmoi file to chezmoi "
        b"(@HOME@/wt is protected)\n"
    )


def test_add_refuses_config_file(chez):
    """chezmoi refuses to add its own config file."""
    # CATCHES: a wrong re-implementation breaks: adding chezmoi's config file suggests a config file template instead.
    chez.write(".config/chezmoi/chezmoi.toml", "# config\n")
    result = chez.run("add", ".config/chezmoi/chezmoi.toml")
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @HOME@/.config/chezmoi/chezmoi.toml: cannot add chezmoi's "
        b"config file to chezmoi, use a config file template instead\n"
    )


def test_add_secrets_flag_validation(chez):
    """--secrets rejects values outside ignore|warning|error."""
    # CATCHES: a wrong re-implementation breaks: --secrets only accepts ignore, warning or error.
    chez.write(".f1", "x\n")
    result = chez.run("add", "--secrets", "bogus", ".f1")
    assert result.returncode == 1
    assert result.stderr == (
        b'chezmoi: invalid argument "bogus" for "--secrets" flag: invalid value\n'
    )


def test_add_exclude_flag_validation(chez):
    """-x/--exclude only accepts entry type names."""
    # CATCHES: a wrong re-implementation breaks: -x rejects non-entry-type values with the flag-argument error.
    chez.write(".excl1", "1\n")
    result = chez.run("add", "--exclude", ".excl1", "--", ".excl1")
    assert result.returncode == 1
    assert result.stderr == (
        b'chezmoi: invalid argument ".excl1" for "-x, --exclude" flag: '
        b".excl1: unknown entry type\n"
    )


def test_add_exclude_files(chez):
    """-x files excludes regular files from the add."""
    # CATCHES: a wrong re-implementation breaks: -x files silently skips regular files during add.
    chez.write(".excl1", "1\n")
    chez.write(".excl2", "2\n")
    result = chez.run("add", "--exclude", "files", "--", ".excl1", ".excl2")
    assert result.returncode == 0
    assert chez.source_paths() == []


def test_add_include_dirs_only(chez):
    """-i dirs adds only directory entries, not the files inside."""
    # CATCHES: a wrong re-implementation breaks: -i dirs adds only the directory entries of the tree.
    chez.write("id/sub/f", "i\n")
    result = chez.run("add", "--include", "dirs", "id")
    assert result.returncode == 0
    assert chez.source_paths() == ["id", "id/sub"]


def test_add_include_files_missing_parent(chez):
    """-i files fails because parent directories are not in the source state."""
    # CATCHES: a wrong re-implementation breaks: -i files fails because parent dirs are missing from the source state.
    chez.write("if/sub/a", "a\n")
    chez.write("if/b", "b\n")
    result = chez.run("add", "--include", "files", "if")
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @HOME@/if/b: parent directory not in source state\n"
    )


def test_add_prompt_yes(chez):
    """-p --no-tty reads the answer from stdin; yes adds the entry."""
    # CATCHES: a wrong re-implementation breaks: -p --no-tty prints the source-dir prompt and reads y from stdin.
    chez.write(".p1", "a\n")
    result = chez.run("add", "--prompt", "--no-tty", ".p1", stdin=b"y\n")
    assert result.returncode == 0
    assert chez.norm(result.stdout) == b"add @HOME@/dot/.p1 (yes/no/all/quit)? "
    assert result.stderr == b""
    assert chez.source_paths() == ["dot_p1"]


def test_add_prompt_no(chez):
    """Answering no to the add prompt leaves the source state empty."""
    # CATCHES: a wrong re-implementation breaks: answering n to the add prompt leaves the source state empty.
    chez.write(".p2", "b\n")
    result = chez.run("add", "--prompt", "--no-tty", ".p2", stdin=b"n\n")
    assert result.returncode == 0
    assert chez.norm(result.stdout) == b"add @HOME@/dot/.p2 (yes/no/all/quit)? "
    assert chez.source_paths() == []


def test_add_prompt_eof(chez):
    """A closed stdin turns the prompt into an EOF error."""
    # CATCHES: a wrong re-implementation breaks: empty stdin on the add prompt yields chezmoi: EOF and exit 1.
    chez.write(".p3", "c\n")
    result = chez.run("add", "--prompt", "--no-tty", ".p3", stdin=b"")
    assert result.returncode == 1
    assert chez.norm(result.stdout) == b"add @HOME@/dot/.p3 (yes/no/all/quit)? "
    assert result.stderr == b"chezmoi: EOF\n"


def test_add_template_symlinks_into_home(chez):
    """--template-symlinks templatizes symlinks pointing into the home dir."""
    # CATCHES: a wrong re-implementation breaks: --template-symlinks emits {{ .chezmoi.homeDir }} for in-home targets.
    chez.mkdir("fdir")
    chez.write("fdir/real", "r\n")
    chez.symlink(str(chez.home / "fdir" / "real"), ".tsym")
    result = chez.run("add", "--template-symlinks", ".tsym")
    assert result.returncode == 0
    assert chez.source_paths() == ["symlink_dot_tsym.tmpl"]
    assert chez.read_source("symlink_dot_tsym.tmpl") == (
        b"{{ .chezmoi.homeDir }}/fdir/real\n"
    )


def test_add_template_symlinks_outside_home(chez):
    """--template-symlinks leaves symlinks outside the home dir literal."""
    # CATCHES: a wrong re-implementation breaks: symlinks outside the home dir stay literal under --template-symlinks.
    chez.symlink("/usr/share", ".ts2")
    result = chez.run("add", "--template-symlinks", ".ts2")
    assert result.returncode == 0
    assert chez.source_paths() == ["symlink_dot_ts2"]
    assert chez.read_source("symlink_dot_ts2") == b"/usr/share\n"


def test_add_template_bom_warning(chez):
    """-T on a UTF-16LE file warns about the byte order mark but still adds."""
    # CATCHES: a wrong re-implementation breaks: UTF-16LE byte order marks trigger the ensure-UTF-8 template warning.
    chez.write(".bom", b"\xff\xfeh\x00i\x00\n\x00")
    result = chez.run("add", "--template", ".bom")
    assert result.returncode == 0
    assert result.stderr == (
        b"chezmoi: .bom: invalid UTF-8\n"
        b"chezmoi: .bom: detected UTF-16 (LE) byte order mark, "
        b"ensure that template is in UTF-8\n"
    )
    assert chez.source_paths() == ["dot_bom.tmpl"]


def test_add_invalid_utf8_template_warning(chez):
    """-T warns on invalid UTF-8 even with --quiet."""
    # CATCHES: a wrong re-implementation breaks: invalid UTF-8 still warns when --quiet is given.
    chez.write(".q1", b"\x80bad\n")
    result = chez.run("add", "--quiet", "--template", ".q1")
    assert result.returncode == 0
    assert result.stderr == b"chezmoi: .q1: invalid UTF-8\n"
    assert chez.source_paths() == ["dot_q1.tmpl"]


def test_add_follow_recursive_conflict(chez):
    """-f on a directory conflicts with the default-true --recursive."""
    # CATCHES: a wrong re-implementation breaks: --follow conflicts with the default-true --recursive for directories.
    chez.write("adir/f", "a\n")
    result = chez.run("add", "--follow", "adir")
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @HOME@/adir: follow and recursive are mutually exclusive "
        b"for directories\n"
    )


def test_add_replaces_existing_entry(chez):
    """Re-adding an existing target replaces the source state contents."""
    # CATCHES: a wrong re-implementation breaks: re-adding an entry replaces the previous source contents.
    chez.write(".r1", "v1\n")
    assert chez.run("add", ".r1").returncode == 0
    chez.write(".r1", "v2\n")
    result = chez.run("add", ".r1")
    assert result.returncode == 0
    assert chez.read_source("dot_r1") == b"v2\n"


def test_add_attribute_loss_prompts(chez):
    """Re-adding without an attribute prompts before dropping it."""
    # CATCHES: a wrong re-implementation breaks: dropping an attribute asks 'would remove private attribute, continue?'.
    chez.write(".pp", "p\n", mode=0o600)
    assert chez.run("add", ".pp").returncode == 0
    chez.write(".pp", "p\n", mode=0o644)
    result = chez.run("add", ".pp")
    assert result.returncode == 1
    assert result.stdout == b"adding .pp would remove private attribute, continue?\n"
    assert result.stderr == (
        b"chezmoi: could not open a new TTY: open /dev/tty: "
        b"no such device or address\n"
    )
    # without an answer the old attribute is kept
    assert chez.source_paths() == ["private_dot_pp"]


def test_add_attribute_loss_with_force(chez):
    """--force drops the attribute without prompting."""
    # CATCHES: a wrong re-implementation breaks: --force re-adds without the attribute-loss prompt.
    chez.write(".pf", "p\n", mode=0o600)
    assert chez.run("add", ".pf").returncode == 0
    chez.write(".pf", "p\n", mode=0o644)
    result = chez.run("add", "--force", ".pf")
    assert result.returncode == 0
    assert result.stdout == b""
    assert chez.source_paths() == ["dot_pf"]


def test_add_refuses_persistent_state_file(chez):
    """chezmoi refuses to add the persistent state file."""
    # CATCHES: a wrong re-implementation breaks: the persistent state file is protected.
    ps = chez.home / "chezmoistate.boltdb"
    ps.write_bytes(b"")
    result = chez.run(
        "add", "chezmoistate.boltdb",
        global_args=[
            "--source", str(chez.source),
            "--destination", str(chez.home),
            "--persistent-state", str(ps),
        ],
    )
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @HOME@/chezmoistate.boltdb: cannot add chezmoi file to "
        b"chezmoi (@HOME@/chezmoistate.boltdb is protected)\n"
    )
