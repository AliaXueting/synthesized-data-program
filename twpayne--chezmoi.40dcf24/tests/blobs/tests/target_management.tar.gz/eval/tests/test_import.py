"""Tests for ``chezmoi import``."""

import bz2
import gzip
import io
import lzma
import tarfile
import zipfile

import pytest


def _basic_tar_bytes():
    """A tar with a 0644 file and a 0755 file in a subdirectory."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tar:
        data = b"hello\n"
        info = tarfile.TarInfo("somefile")
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
        script = b"#!/bin/sh\necho x\n"
        info2 = tarfile.TarInfo("sub/run.sh")
        info2.size = len(script)
        info2.mode = 0o755
        tar.addfile(info2, io.BytesIO(script))
    return buf.getvalue()


@pytest.fixture()
def basic_tar(tmp_path):
    path = tmp_path / "basic.tar"
    path.write_bytes(_basic_tar_bytes())
    return path


def test_import_tar_from_file(chez, basic_tar):
    """import reads a tar and maps modes onto source state attributes."""
    # CATCHES: a wrong re-implementation breaks: import maps 0755 archive members to executable_ source names.
    result = chez.run("import", str(basic_tar))
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert chez.source_paths() == ["somefile", "sub", "sub/executable_run.sh"]
    assert chez.read_source("somefile") == b"hello\n"
    assert chez.read_source("sub/executable_run.sh") == b"#!/bin/sh\necho x\n"


def test_import_zip(chez, tmp_path):
    """import reads a zip; python's default 0600 entries become private_."""
    # CATCHES: a wrong re-implementation breaks: zip members with 0600 attrs become private_ source entries.
    path = tmp_path / "basic.zip"
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("somefile", "hello\n")
        info = zipfile.ZipInfo("sub/run.sh")
        info.external_attr = 0o755 << 16
        zf.writestr(info, "#!/bin/sh\necho x\n")
    result = chez.run("import", str(path))
    assert result.returncode == 0
    assert chez.source_paths() == [
        "private_somefile",
        "sub",
        "sub/executable_run.sh",
    ]
    assert chez.read_source("private_somefile") == b"hello\n"


def test_import_from_stdin(chez, basic_tar):
    """import reads the archive from stdin when no file argument is given."""
    # CATCHES: a wrong re-implementation breaks: import reads the archive from stdin when no file is given.
    result = chez.run("import", stdin=basic_tar.read_bytes())
    assert result.returncode == 0
    assert chez.source_paths() == ["somefile", "sub", "sub/executable_run.sh"]


def test_import_destination_prefix(chez, basic_tar):
    """--destination imports below an existing source state directory."""
    # CATCHES: a wrong re-implementation breaks: --destination places imports below an existing source directory.
    chez.write("pfx/.pf", "p\n")
    assert chez.run("add", "pfx/.pf").returncode == 0
    result = chez.run("import", "--destination", "pfx", str(basic_tar))
    assert result.returncode == 0
    assert chez.source_paths() == [
        "pfx",
        "pfx/dot_pf",
        "pfx/somefile",
        "pfx/sub",
        "pfx/sub/executable_run.sh",
    ]


def test_import_destination_missing_parent(chez, basic_tar):
    """--destination fails when the prefix is not in the source state."""
    # CATCHES: a wrong re-implementation breaks: --destination fails when the prefix is not in the source state.
    result = chez.run("import", "--destination", "sub2", str(basic_tar))
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @HOME@/sub2/somefile: parent directory not in source state\n"
    )


def test_import_strip_components(chez, basic_tar):
    """--strip-components drops the leading path element of each entry."""
    # CATCHES: a wrong re-implementation breaks: --strip-components drops leading parts, removing shallow files.
    result = chez.run("import", "--strip-components", "1", str(basic_tar))
    assert result.returncode == 0
    # somefile has only one component and disappears entirely
    assert chez.source_paths() == ["executable_run.sh"]


def test_import_strip_components_too_deep(chez, basic_tar):
    """Stripping more components than any entry has imports nothing."""
    # CATCHES: a wrong re-implementation breaks: stripping deeper than any entry imports nothing, successfully.
    result = chez.run("import", "--strip-components", "5", str(basic_tar))
    assert result.returncode == 0
    assert chez.source_paths() == []


def test_import_exact(chez, basic_tar):
    """--exact marks imported top-level directories exact_."""
    # CATCHES: a wrong re-implementation breaks: --exact marks imported top-level directories exact_.
    result = chez.run("import", "--exact", str(basic_tar))
    assert result.returncode == 0
    assert chez.source_paths() == [
        "exact_sub",
        "exact_sub/executable_run.sh",
        "somefile",
    ]


def test_import_remove_destination(chez, basic_tar):
    """-r/--remove-destination imports over an existing source state."""
    # CATCHES: a wrong re-implementation breaks: -r re-imports over an existing source state, replacing entries.
    assert chez.run("import", str(basic_tar)).returncode == 0
    chez.write_source("somefile", "stale\n")
    result = chez.run("import", "--remove-destination", str(basic_tar))
    assert result.returncode == 0
    assert chez.source_paths() == ["somefile", "sub", "sub/executable_run.sh"]
    assert chez.read_source("somefile") == b"hello\n"


def test_import_rejects_traversal(chez, tmp_path):
    """Archives containing .. paths are rejected."""
    # CATCHES: a wrong re-implementation breaks: archive entries containing .. are rejected as invalid paths.
    path = tmp_path / "evil.tar"
    with tarfile.open(path, "w") as tar:
        data = b"evil\n"
        info = tarfile.TarInfo("../evil.txt")
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
    result = chez.run("import", str(path))
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: ../evil.txt: invalid path\n"
    assert chez.source_paths() == []


@pytest.mark.parametrize(
    "suffix,compress",
    [
        ("gz", gzip.compress),
        ("bz2", bz2.compress),
        ("xz", lzma.compress),
        ("zst", None),
    ],
)
def test_import_compressed_formats(chez, tmp_path, suffix, compress):
    """import decompresses gzip, bzip2, xz and zstd archives by extension."""
    # CATCHES: a wrong re-implementation breaks: gz/bz2/xz/zst archives are decompressed by file extension.
    data = _basic_tar_bytes()
    if suffix == "zst":
        import subprocess

        data = subprocess.run(
            ["zstd", "-q", "-c", "-"], input=data, stdout=subprocess.PIPE,
            check=True,
        ).stdout
    else:
        data = compress(data)
    path = tmp_path / ("basic.tar." + suffix)
    path.write_bytes(data)
    result = chez.run("import", str(path))
    assert result.returncode == 0
    assert chez.source_paths() == ["somefile", "sub", "sub/executable_run.sh"]


def test_import_magic_bytes_gzip(chez, tmp_path):
    """Gzip data under a non-archive extension is detected by magic bytes."""
    # CATCHES: a wrong re-implementation breaks: gzip data is detected by magic bytes despite the extension.
    path = tmp_path / "plainname.bin"
    path.write_bytes(gzip.compress(_basic_tar_bytes()))
    result = chez.run("import", str(path))
    assert result.returncode == 0
    assert chez.source_paths() == ["somefile", "sub", "sub/executable_run.sh"]


def test_import_magic_bytes_zip(chez, tmp_path):
    """Zip data under a .tar-named file is detected by magic bytes."""
    # CATCHES: a wrong re-implementation breaks: zip data is detected by magic bytes despite the extension.
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("somefile", "hello\n")
    path = tmp_path / "zipnamed.bin"
    path.write_bytes(buf.getvalue())
    result = chez.run("import", str(path))
    assert result.returncode == 0
    assert chez.source_paths() == ["private_somefile"]


def test_import_nonexistent_file(chez, tmp_path):
    """import of a missing file fails with an open error."""
    # CATCHES: a wrong re-implementation breaks: importing a missing file reports the open error and exits 1.
    result = chez.run("import", str(tmp_path / "nothere.tar"))
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: open @ROOT@/nothere.tar: no such file or directory\n"
    )


def test_import_corrupt_archive(chez, tmp_path):
    """Trailing garbage is reported as an unexpected EOF."""
    # CATCHES: a wrong re-implementation breaks: a non-archive file is rejected with 'unexpected EOF'.
    path = tmp_path / "bogus.tar"
    path.write_bytes(b"not an archive")
    result = chez.run("import", str(path))
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: unexpected EOF\n"


def test_import_directory_argument(chez, tmp_path):
    """Passing a directory fails with a read error."""
    # CATCHES: a wrong re-implementation breaks: passing a directory fails with 'read ...: is a directory'.
    result = chez.run("import", str(tmp_path))
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: read @ROOT@: is a directory\n"
    )


def test_import_exclude_dirs(chez, basic_tar):
    """-x dirs leaves file parents out of the source state and fails."""
    # CATCHES: a wrong re-implementation breaks: -x dirs on import fails on the missing parent directory.
    result = chez.run("import", "--exclude", "dirs", str(basic_tar))
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: @HOME@/sub/run.sh: parent directory not in source state\n"
    )


def test_import_empty_stdin(chez):
    """import with no arguments and empty stdin succeeds importing nothing."""
    # CATCHES: a wrong re-implementation breaks: empty stdin is a valid empty archive for import.
    result = chez.run("import", stdin=b"")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
