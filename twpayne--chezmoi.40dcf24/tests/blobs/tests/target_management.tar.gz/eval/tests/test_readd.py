"""Tests for ``chezmoi re-add``."""


def test_readd_updates_drifted_file(chez):
    """re-add refreshes the source state of a modified target."""
    # CATCHES: a wrong re-implementation breaks: re-add refreshes the source state of a modified file.
    chez.write(".ra", "v1\n")
    assert chez.run("add", ".ra").returncode == 0
    chez.write(".ra", "v2\n")
    result = chez.run("re-add", ".ra")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert chez.read_source("dot_ra") == b"v2\n"


def test_readd_without_drift(chez):
    """re-add of an unmodified target is a successful no-op."""
    # CATCHES: a wrong re-implementation breaks: re-add of an unchanged file is a successful no-op.
    chez.write(".rb", "v1\n")
    assert chez.run("add", ".rb").returncode == 0
    result = chez.run("re-add", ".rb")
    assert result.returncode == 0
    assert chez.read_source("dot_rb") == b"v1\n"


def test_readd_skips_templates(chez):
    """re-add never overwrites template sources."""
    # CATCHES: a wrong re-implementation breaks: re-add never overwrites .tmpl sources.
    chez.write(".rt", "t1\n")
    assert chez.run("add", "--template", ".rt").returncode == 0
    chez.write(".rt", "t2\n")
    result = chez.run("re-add", ".rt")
    assert result.returncode == 0
    assert chez.read_source("dot_rt.tmpl") == b"t1\n"


def test_readd_updates_permissions(chez):
    """re-add picks up permission drift as attribute changes."""
    # CATCHES: a wrong re-implementation breaks: permission drift turns dot_ into private_ on re-add.
    chez.write(".rp", "p\n", mode=0o644)
    assert chez.run("add", ".rp").returncode == 0
    assert chez.source_paths() == ["dot_rp"]
    chez.write(".rp", "p\n", mode=0o600)
    result = chez.run("re-add", ".rp")
    assert result.returncode == 0
    assert chez.source_paths() == ["private_dot_rp"]


def test_readd_exact_directory_sync(chez):
    """re-add syncs exact_ directories: new files appear, deleted ones go."""
    # CATCHES: a wrong re-implementation breaks: re-add syncs exact_ dirs, adding new and dropping deleted files.
    chez.write("ex/keep", "k\n")
    chez.write("ex/gone", "g\n")
    assert chez.run("add", "--exact", "ex").returncode == 0
    (chez.home / "ex" / "gone").unlink()
    chez.write("ex/new", "n\n")
    result = chez.run("re-add", "ex")
    assert result.returncode == 0
    assert chez.source_paths() == ["exact_ex", "exact_ex/keep", "exact_ex/new"]
    assert chez.read_source("exact_ex/new") == b"n\n"


def test_readd_exact_directory_removes_deleted(chez):
    """Files deleted from an exact_ directory are removed from the source."""
    # CATCHES: a wrong re-implementation breaks: files deleted from an exact_ dir leave the source state.
    chez.write("ex/keep", "k\n")
    chez.write("ex/drop", "d\n")
    assert chez.run("add", "--exact", "ex").returncode == 0
    (chez.home / "ex" / "keep").unlink()
    result = chez.run("re-add", "ex")
    assert result.returncode == 0
    assert chez.source_paths() == ["exact_ex", "exact_ex/drop"]


def test_readd_unmanaged(chez):
    """re-add of an unmanaged target fails."""
    # CATCHES: a wrong re-implementation breaks: re-add of an unmanaged target fails with 'not managed'.
    chez.write(".ok", "o\n")
    assert chez.run("add", ".ok").returncode == 0
    result = chez.run("re-add", ".nope")
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: .nope: not managed\n"


def test_readd_missing_source_dir(chez):
    """re-add fails when the source directory does not exist."""
    # CATCHES: a wrong re-implementation breaks: re-add on a missing source directory reports the stat error.
    result = chez.run("re-add")
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: stat @HOME@/dot: no such file or directory\n"
    )
