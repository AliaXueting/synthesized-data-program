"""Tests for ``chezmoi forget``, ``chezmoi destroy`` and the ``remove`` stub."""

import tarfile
import io

import pytest


def test_forget_removes_source_keeps_dest(chez):
    """forget removes only the source state entry, never the destination."""
    # CATCHES: a wrong re-implementation breaks: forget deletes only the source entry, never the destination file.
    chez.write(".f1", "f1\n")
    assert chez.run("add", ".f1").returncode == 0
    result = chez.run("forget", "--force", ".f1")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert chez.source_paths() == []
    assert (chez.home / ".f1").read_bytes() == b"f1\n"


def test_forget_unmanaged(chez):
    """Forgetting a target that is not managed fails."""
    # CATCHES: a wrong re-implementation breaks: forget of an unmanaged target prints '<target>: not managed'.
    result = chez.run("forget", "--force", ".nope")
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: .nope: not managed\n"


def test_forget_prompts_without_force(chez):
    """Without --force forget asks on stdout and fails without a TTY."""
    # CATCHES: a wrong re-implementation breaks: the forget prompt goes to stdout and needs a TTY without --force.
    chez.write(".f2", "f2\n")
    assert chez.run("add", ".f2").returncode == 0
    result = chez.run("forget", ".f2")
    assert result.returncode == 1
    assert chez.norm(result.stdout) == b"Remove @HOME@/dot/dot_f2?\n"
    assert result.stderr == (
        b"chezmoi: could not open a new TTY: open /dev/tty: "
        b"no such device or address\n"
    )
    assert chez.source_paths() == ["dot_f2"]


def test_forget_no_tty_yes(chez):
    """--no-tty reads the confirmation from stdin."""
    # CATCHES: a wrong re-implementation breaks: --no-tty turns the prompt into a stdin yes/no/all/quit question.
    chez.write(".f3", "f3\n")
    assert chez.run("add", ".f3").returncode == 0
    result = chez.run("forget", "--no-tty", ".f3", stdin=b"y\n")
    assert result.returncode == 0
    assert chez.norm(result.stdout) == (
        b"Remove @HOME@/dot/dot_f3 (yes/no/all/quit)? "
    )
    assert chez.source_paths() == []


def test_forget_no_tty_no(chez):
    """Answering no to the forget prompt keeps the source entry."""
    # CATCHES: a wrong re-implementation breaks: answering n keeps the source entry and still exits 0.
    chez.write(".f4", "f4\n")
    assert chez.run("add", ".f4").returncode == 0
    result = chez.run("forget", "--no-tty", ".f4", stdin=b"n\n")
    assert result.returncode == 0
    assert chez.source_paths() == ["dot_f4"]
    assert (chez.home / ".f4").read_bytes() == b"f4\n"


def test_unmanage_alias(chez):
    """unmanage is an alias of forget."""
    # CATCHES: a wrong re-implementation breaks: unmanage behaves exactly like forget.
    chez.write(".f5", "f5\n")
    assert chez.run("add", ".f5").returncode == 0
    result = chez.run("unmanage", "--force", ".f5")
    assert result.returncode == 0
    assert chez.source_paths() == []
    assert (chez.home / ".f5").read_bytes() == b"f5\n"


def test_forget_directory_tree(chez):
    """forgetting a directory removes its whole subtree from the source."""
    # CATCHES: a wrong re-implementation breaks: forgetting a directory removes its whole source subtree.
    chez.write("dd/x", "x\n")
    assert chez.run("add", "dd").returncode == 0
    assert chez.source_paths() == ["dd", "dd/x"]
    result = chez.run("forget", "--force", "dd")
    assert result.returncode == 0
    assert chez.source_paths() == []
    assert (chez.home / "dd" / "x").read_bytes() == b"x\n"


def test_forget_remove_origin_warning(chez):
    """Entries listed in .chezmoiremove cannot be forgotten."""
    # CATCHES: a wrong re-implementation breaks: .chezmoiremove entries cannot be forgotten, only warned about.
    chez.write(".gone", "g\n")
    chez.write_source(".chezmoiremove", ".gone\n")
    chez.write(".kept", "k\n")
    assert chez.run("add", ".kept").returncode == 0
    result = chez.run("forget", "--force", ".gone")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: warning: .gone: cannot forget entry from remove\n"
    # both the .chezmoiremove file and the destination file survive
    assert chez.source_paths() == [".chezmoiremove", "dot_kept"]
    assert (chez.home / ".gone").read_bytes() == b"g\n"


def test_forget_external_warning(chez):
    """External targets cannot be forgotten; a warning is printed instead."""
    # CATCHES: a wrong re-implementation breaks: externals are refused with the external URL and the defining file.
    ext = chez.root / "ext.tar"
    with tarfile.open(ext, "w") as t:
        data = b"extfile\n"
        info = tarfile.TarInfo("x")
        info.size = len(data)
        t.addfile(info, io.BytesIO(data))
    chez.write_source(
        ".chezmoiexternal.toml",
        '[".extdir"]\ntype = "archive"\nurl = "file://%s"\n' % ext,
    )
    assert chez.run("apply").returncode == 0
    result = chez.run("forget", "--force", ".extdir")
    assert result.returncode == 0
    assert chez.norm(result.stderr.decode()) == (
        "chezmoi: warning: .extdir: cannot forget entry from external "
        "file://@ROOT@/ext.tar defined in @HOME@/dot/.chezmoiexternal.toml\n"
    )
    assert chez.source_paths() == [".chezmoiexternal.toml"]


def test_destroy_removes_source_and_dest(chez):
    """destroy removes the entry from the source and the destination."""
    # CATCHES: a wrong re-implementation breaks: destroy deletes the target from both source and destination.
    chez.write(".dz", "dz\n")
    assert chez.run("add", ".dz").returncode == 0
    result = chez.run("destroy", "--force", ".dz")
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert chez.source_paths() == []
    assert not (chez.home / ".dz").exists()


def test_destroy_prompts_without_force(chez):
    """Without --force destroy names both paths and fails without a TTY."""
    # CATCHES: a wrong re-implementation breaks: the destroy prompt names both destination and source paths.
    chez.write(".dz2", "dz2\n")
    assert chez.run("add", ".dz2").returncode == 0
    result = chez.run("destroy", ".dz2")
    assert result.returncode == 1
    assert chez.norm(result.stdout) == (
        b"Destroy @HOME@/.dz2 and @HOME@/dot/dot_dz2?\n"
    )
    assert result.stderr == (
        b"chezmoi: could not open a new TTY: open /dev/tty: "
        b"no such device or address\n"
    )
    assert chez.source_paths() == ["dot_dz2"]


def test_destroy_unmanaged(chez):
    """destroying an unmanaged target fails."""
    # CATCHES: a wrong re-implementation breaks: destroy of an unmanaged target fails with 'not managed'.
    result = chez.run("destroy", "--force", ".nada")
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: .nada: not managed\n"


def test_destroy_directory(chez):
    """destroy removes a managed directory from both states."""
    # CATCHES: a wrong re-implementation breaks: destroy removes a managed directory tree from the destination.
    chez.write("destd/y", "y\n")
    assert chez.run("add", "destd").returncode == 0
    result = chez.run("destroy", "--force", "destd")
    assert result.returncode == 0
    assert chez.source_paths() == []
    assert not (chez.home / "destd").exists()


def test_destroy_external_warning(chez):
    """destroy skips external targets with a warning."""
    # CATCHES: a wrong re-implementation breaks: destroy skips externals with 'warning: skipping external'.
    ext = chez.root / "ext2.tar"
    with tarfile.open(ext, "w") as t:
        data = b"extfile\n"
        info = tarfile.TarInfo("x")
        info.size = len(data)
        t.addfile(info, io.BytesIO(data))
    chez.write_source(
        ".chezmoiexternal.toml",
        '[".extdir2"]\ntype = "archive"\nurl = "file://%s"\n' % ext,
    )
    assert chez.run("apply").returncode == 0
    result = chez.run("destroy", "--force", ".extdir2")
    assert result.returncode == 0
    assert result.stderr == b"chezmoi: warning: skipping external .extdir2\n"


@pytest.mark.parametrize("argv", [["forget"], ["destroy"]])
def test_forget_destroy_require_args(chez, argv):
    """forget and destroy both require at least one target argument."""
    # CATCHES: a wrong re-implementation breaks: both commands require at least one target argument.
    result = chez.run(*argv)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b"chezmoi: requires at least 1 arg(s), only received 0\n"
    )


@pytest.mark.parametrize("argv", [["remove", ".f1"], ["remove"]])
def test_remove_deprecated_stub(chez, argv):
    """The hidden remove command always exits 1 with a deprecation notice."""
    # CATCHES: a wrong re-implementation breaks: the hidden remove stub always exits 1 with the deprecation text.
    result = chez.run(*argv)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'Command "remove" is deprecated, use forget or destroy instead\n'
    )
