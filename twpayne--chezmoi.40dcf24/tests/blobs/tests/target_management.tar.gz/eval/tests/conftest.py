"""Shared harness for the ``target_management`` module tests.

Every test drives the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hard-coded path).  The main entry point is :meth:`Chez.run`, which returns a
completed process with byte-exact ``stdout``/``stderr`` so that recorded
expectations can be asserted verbatim after path normalisation.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import pytest


def executable_path() -> str:
    """Return the candidate path from PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE", "")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; the suite cannot drive the candidate"
        )
    return path


# Randomised subdirectories that chezmoi creates below TMPDIR while editing or
# merging (e.g. ``chezmoi-edit1234567890``); normalised so that expectations
# stay byte-comparable across runs.
_TEMPDIR_RE = re.compile(rb"chezmoi-(edit|merge|merge-plaintext)\d+")
_TEMPDIR_RE_STR = re.compile(r"chezmoi-(edit|merge|merge-plaintext)\d+")


class Chez:
    """A hermetic chezmoi environment rooted in a pytest temporary directory.

    The destination directory, ``HOME`` and the working directory of the child
    process are all ``<root>/home``; the source directory is ``<root>/home/dot``
    and the child's ``TMPDIR`` is ``<root>/home/tmp`` so that no absolute path
    outside the test directory is ever touched.
    """

    def __init__(self, root):
        self.root = Path(root)
        self.home = self.root / "home"
        self.source = self.home / "dot"
        self.tmpdir = self.home / "tmp"
        self.home.mkdir(parents=True, exist_ok=True)
        self.tmpdir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # process driving

    def run(self, *argv, stdin=b"", env=None, timeout=30, global_args=None):
        """Run the candidate and return the completed process.

        ``argv`` is the sub-command and its arguments.  The global ``--source``
        and ``--destination`` flags are prepended (unless ``global_args``
        replaces them).  ``env`` is merged over the pinned child environment.
        """
        if global_args is None:
            global_args = ["--source", str(self.source), "--destination", str(self.home)]
        merged = {
            "PATH": "/usr/bin:/bin",
            "HOME": str(self.home),
            "TMPDIR": str(self.tmpdir),
            "LANG": "C",
            "LC_ALL": "C",
        }
        if env:
            merged.update(env)
        # Coverage instrumentation hook (REQUIRED): copy GOCOVERDIR from the
        # test process environment into the child env when present, so the
        # pipeline can measure source coverage of the reference binary.
        cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
        merged.update(cov_env)
        data = stdin if isinstance(stdin, bytes) else stdin.encode()
        return subprocess.run(
            [executable_path()] + list(global_args) + list(argv),
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(self.home),
            env=merged,
            timeout=timeout,
            # Pin the umask so that file modes (and therefore private_ /
            # executable_ attribute derivation) are deterministic.
            preexec_fn=lambda: os.umask(0o022),
        )

    # ------------------------------------------------------------------
    # filesystem helpers

    def write(self, relpath, data, mode=None):
        """Write a file inside the destination directory."""
        path = self.home / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(data, str):
            data = data.encode()
        path.write_bytes(data)
        if mode is not None:
            path.chmod(mode)
        return path

    def mkdir(self, relpath):
        """Create a directory inside the destination directory."""
        path = self.home / relpath
        path.mkdir(parents=True, exist_ok=True)
        return path

    def symlink(self, target, relpath):
        """Create a symlink inside the destination directory."""
        path = self.home / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        path.symlink_to(target)
        return path

    def write_source(self, relpath, data, mode=None):
        """Write a file directly into the source directory."""
        path = self.source / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(data, str):
            data = data.encode()
        path.write_bytes(data)
        if mode is not None:
            path.chmod(mode)
        return path

    def source_paths(self):
        """Return the sorted relative paths of all entries in the source dir."""
        if not self.source.exists():
            return []
        entries = []
        for dirpath, dirnames, filenames in os.walk(self.source):
            rel = Path(dirpath).relative_to(self.source)
            for name in sorted(dirnames):
                entries.append(str(rel / name) if str(rel) != "." else name)
            for name in sorted(filenames):
                entries.append(str(rel / name) if str(rel) != "." else name)
        return sorted(entries)

    def read_source(self, relpath):
        """Return the bytes of a file in the source directory."""
        return (self.source / relpath).read_bytes()

    def source_mode(self, relpath):
        """Return the octal mode string of a file in the source directory."""
        return oct((self.source / relpath).stat().st_mode & 0o7777)

    # ------------------------------------------------------------------
    # normalisation

    def norm(self, data):
        """Normalise output: home -> @HOME@, root -> @ROOT@, random temp dirs.

        The return type matches the input type (str in, str out).
        """
        if isinstance(data, str):
            data = data.replace(str(self.home), "@HOME@")
            data = data.replace(str(self.root), "@ROOT@")
            return _TEMPDIR_RE_STR.sub(r"chezmoi-\1@N@", data)
        data = data.replace(str(self.home).encode(), b"@HOME@")
        data = data.replace(str(self.root).encode(), b"@ROOT@")
        return _TEMPDIR_RE.sub(rb"chezmoi-\1@N@", data)


@pytest.fixture()
def chez(tmp_path):
    """A fresh chezmoi environment for one test."""
    return Chez(tmp_path)
