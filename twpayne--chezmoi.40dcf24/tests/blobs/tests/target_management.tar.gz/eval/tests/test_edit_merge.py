"""Tests for ``chezmoi edit``, ``chezmoi merge`` and ``chezmoi merge-all``."""

import os

import pytest


@pytest.fixture()
def log_path(tmp_path):
    """A path that helper scripts append their arguments to."""
    return tmp_path / "log.txt"


def _append_editor(chez, log_path, body='printf "edited-line\\n" >> "$1"\n'):
    """Write an editor script that logs its arguments and appends a line."""
    script = chez.root / "editor.sh"
    script.write_text(
        "#!/bin/sh\n"
        'echo "ARG:$1" >> "%s"\n' % log_path
        + body
    )
    script.chmod(0o755)
    return script


def _merge_config(chez, command, args=None):
    """Write a merge configuration outside the destination directory."""
    cfg = chez.root / "cfg.toml"
    lines = [
        'sourceDir = "%s"' % chez.source,
        'destDir = "%s"' % chez.home,
        "[merge]",
        'command = "%s"' % command,
    ]
    if args is not None:
        lines.append("args = [%s]" % ", ".join('"%s"' % a for a in args))
    cfg.write_text("\n".join(lines) + "\n")
    return cfg


def _merge_recorder(chez, log_path):
    """A merge command that records its argv and exits successfully."""
    script = chez.root / "merger.sh"
    script.write_text(
        "#!/bin/sh\n"
        '{ echo "MERGE $#"; for a in "$@"; do echo "  <$a>"; done; } '
        '>> "%s"\n' % log_path
    )
    script.chmod(0o755)
    return script


def test_edit_updates_source_not_dest(chez, log_path):
    """edit runs $EDITOR on a temp copy and writes back only the source."""
    # CATCHES: a wrong re-implementation breaks: edit edits a temp copy, warns on fast editors, and skips the dest.
    editor = _append_editor(chez, log_path)
    chez.write(".e1", "orig\n")
    assert chez.run("add", ".e1").returncode == 0
    result = chez.run("edit", ".e1", env={"EDITOR": str(editor)})
    assert result.returncode == 0
    # the editor saw the target name inside a chezmoi-edit temp directory
    assert chez.norm(log_path.read_text()) == "ARG:@HOME@/tmp/chezmoi-edit@N@/.e1\n"
    # the fast editor triggers a warning naming editor and temp file
    assert chez.norm(result.stderr) == (
        "chezmoi: warning: @ROOT@/editor.sh "
        "@HOME@/tmp/chezmoi-edit@N@/.e1: returned in less than 1s\n"
    ).encode()
    assert result.stdout == b""
    assert chez.read_source("dot_e1") == b"orig\nedited-line\n"
    # the destination is untouched without --apply
    assert (chez.home / ".e1").read_bytes() == b"orig\n"


def test_edit_apply_updates_dest(chez, log_path):
    """edit --apply also applies the edited source state to the destination."""
    # CATCHES: a wrong re-implementation breaks: --apply propagates the edited source to the destination.
    editor = _append_editor(chez, log_path)
    chez.write(".e2", "orig\n")
    assert chez.run("add", ".e2").returncode == 0
    result = chez.run("edit", "--apply", ".e2", env={"EDITOR": str(editor)})
    assert result.returncode == 0
    assert chez.read_source("dot_e2") == b"orig\nedited-line\n"
    assert (chez.home / ".e2").read_bytes() == b"orig\nedited-line\n"


def test_edit_unmanaged(chez, log_path):
    """edit of an unmanaged target fails."""
    # CATCHES: a wrong re-implementation breaks: edit of an unmanaged target fails with 'not managed'.
    editor = _append_editor(chez, log_path)
    chez.write(".managed", "m\n")
    assert chez.run("add", ".managed").returncode == 0
    result = chez.run("edit", ".unm", env={"EDITOR": str(editor)})
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: .unm: not managed\n"
    assert not log_path.exists()


def test_edit_failing_editor(chez):
    """A non-zero editor exit is reported with the editor's exit status."""
    # CATCHES: a wrong re-implementation breaks: a failing editor is reported with its exact exit status.
    editor = chez.root / "fail.sh"
    editor.write_text("#!/bin/sh\nexit 7\n")
    editor.chmod(0o755)
    chez.write(".e3", "x\n")
    assert chez.run("add", ".e3").returncode == 0
    result = chez.run("edit", ".e3", env={"EDITOR": str(editor)})
    assert result.returncode == 1
    # the fast failing editor first triggers the returned-in-less-than-1s warning
    assert chez.norm(result.stderr) == (
        b"chezmoi: warning: @ROOT@/fail.sh "
        b"@HOME@/tmp/chezmoi-edit@N@/.e3: returned in less than 1s\n"
        b"chezmoi: @ROOT@/fail.sh: exit status 7\n"
    )


def test_edit_no_args_edits_source_dir(chez, log_path):
    """edit without arguments passes the source directory to the editor."""
    # CATCHES: a wrong re-implementation breaks: edit with no arguments passes the source dir itself to $EDITOR.
    script = chez.root / "lister.sh"
    script.write_text('#!/bin/sh\necho "ARG:$1" >> "%s"\n' % log_path)
    script.chmod(0o755)
    chez.write(".e4", "x\n")
    assert chez.run("add", ".e4").returncode == 0
    result = chez.run("edit", env={"EDITOR": str(script)})
    assert result.returncode == 0
    assert chez.norm(log_path.read_text()) == "ARG:@HOME@/dot\n"


def test_edit_hardlink(chez, log_path):
    """--hardlink gives the editor a second link to the source file."""
    # CATCHES: a wrong re-implementation breaks: --hardlink gives the editor a second link to the source file.
    script = chez.root / "nlink.sh"
    script.write_text(
        '#!/bin/sh\n'
        'echo "nlink:$(stat -c %%h "$1")" >> "%s"\n'
        'printf "hardlinked\\n" > "$1"\n' % log_path
    )
    script.chmod(0o755)
    chez.write(".hl", "hl\n")
    assert chez.run("add", ".hl").returncode == 0
    result = chez.run("edit", "--hardlink", ".hl", env={"EDITOR": str(script)})
    assert result.returncode == 0
    assert log_path.read_text() == "nlink:2\n"
    assert chez.read_source("dot_hl") == b"hardlinked\n"
    assert (chez.home / ".hl").read_bytes() == b"hl\n"


def test_edit_renders_template_on_apply(chez, log_path):
    """--apply renders templates when applying the edited source."""
    # CATCHES: a wrong re-implementation breaks: --apply renders templates when writing the destination.
    script = chez.root / "tmpl.sh"
    script.write_text('#!/bin/sh\nprintf "os={{ .chezmoi.os }}\\n" > "$1"\n')
    script.chmod(0o755)
    chez.write(".et", "start\n")
    assert chez.run("add", "--template", ".et").returncode == 0
    result = chez.run("edit", "--apply", ".et", env={"EDITOR": str(script)})
    assert result.returncode == 0
    assert chez.read_source("dot_et.tmpl") == b"os={{ .chezmoi.os }}\n"
    assert (chez.home / ".et").read_bytes() == b"os=linux\n"


def test_edit_editor_with_arguments(chez, log_path):
    """EDITOR is split on spaces so flags reach the editor."""
    # CATCHES: a wrong re-implementation breaks: EDITOR is split on spaces so flags reach the editor.
    script = chez.root / "flaggy.sh"
    script.write_text(
        '#!/bin/sh\n'
        'echo "N:$#" >> "%s"\n'
        'for a in "$@"; do echo "  <$a>" >> "%s"; done\n' % (log_path, log_path)
    )
    script.chmod(0o755)
    chez.write(".e5", "x\n")
    assert chez.run("add", ".e5").returncode == 0
    result = chez.run("edit", ".e5", env={"EDITOR": str(script) + " --flag"})
    assert result.returncode == 0
    lines = chez.norm(log_path.read_text()).splitlines()
    assert lines[0] == "N:2"
    assert lines[1] == "  <--flag>"
    assert lines[2].startswith("  <@HOME@/tmp/chezmoi-edit")


def test_merge_default_args(chez, log_path):
    """merge passes destination, source and rendered target to the command."""
    # CATCHES: a wrong re-implementation breaks: merge passes dest, source and rendered target in a temp dir.
    merger = _merge_recorder(chez, log_path)
    cfg = _merge_config(chez, merger)
    chez.write(".m", "dest version\n")
    assert chez.run("add", ".m").returncode == 0
    chez.write_source("dot_m", "source version\n")
    result = chez.run("merge", ".m", global_args=["-c", str(cfg)])
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert chez.norm(log_path.read_text()).splitlines() == [
        "MERGE 3",
        "  <@HOME@/.m>",
        "  <@HOME@/dot/dot_m>",
        "  <@HOME@/tmp/chezmoi-merge@N@/.m>",
    ]


def test_merge_template_args(chez, log_path):
    """merge.args templates {{ .Destination }}, {{ .Source }}, {{ .Target }}."""
    # CATCHES: a wrong re-implementation breaks: merge.args templates {{ .Destination }}/.Source/.Target are rendered.
    merger = _merge_recorder(chez, log_path)
    cfg = _merge_config(
        chez, merger,
        args=["--dest", "{{ .Destination }}", "--src", "{{ .Source }}",
              "--tgt", "{{ .Target }}"],
    )
    chez.write(".m", "dest version\n")
    assert chez.run("add", ".m").returncode == 0
    chez.write_source("dot_m", "source version\n")
    result = chez.run("merge", ".m", global_args=["-c", str(cfg)])
    assert result.returncode == 0
    assert chez.norm(log_path.read_text()).splitlines() == [
        "MERGE 6",
        "  <--dest>",
        "  <@HOME@/.m>",
        "  <--src>",
        "  <@HOME@/dot/dot_m>",
        "  <--tgt>",
        "  <@HOME@/tmp/chezmoi-merge@N@/.m>",
    ]


def test_merge_plain_args_appended(chez, log_path):
    """Without template args, dest/source/target are appended after them."""
    # CATCHES: a wrong re-implementation breaks: plain merge.args get dest/source/target appended after them.
    merger = _merge_recorder(chez, log_path)
    cfg = _merge_config(chez, merger, args=["-d"])
    chez.write(".m", "dest version\n")
    assert chez.run("add", ".m").returncode == 0
    chez.write_source("dot_m", "source version\n")
    result = chez.run("merge", ".m", global_args=["-c", str(cfg)])
    assert result.returncode == 0
    assert chez.norm(log_path.read_text()).splitlines() == [
        "MERGE 4",
        "  <-d>",
        "  <@HOME@/.m>",
        "  <@HOME@/dot/dot_m>",
        "  <@HOME@/tmp/chezmoi-merge@N@/.m>",
    ]


def test_merge_unmanaged(chez, log_path):
    """merge of an unmanaged target fails."""
    # CATCHES: a wrong re-implementation breaks: merge of an unmanaged target fails with 'not managed'.
    merger = _merge_recorder(chez, log_path)
    cfg = _merge_config(chez, merger)
    chez.write(".managed", "m\n")
    assert chez.run("add", ".managed").returncode == 0
    result = chez.run("merge", ".nom", global_args=["-c", str(cfg)])
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: .nom: not managed\n"
    assert not log_path.exists()


def test_merge_requires_args(chez):
    """merge without arguments reports the argument count error."""
    # CATCHES: a wrong re-implementation breaks: merge without targets reports the argument-count error.
    result = chez.run("merge")
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: requires at least 1 arg(s), only received 0\n"


def test_merge_failing_command(chez):
    """A failing merge command is reported with the target name prefix."""
    # CATCHES: a wrong re-implementation breaks: merge errors are prefixed with the target name.
    failer = chez.root / "merger2.sh"
    failer.write_text("#!/bin/sh\nexit 3\n")
    failer.chmod(0o755)
    cfg = _merge_config(chez, failer)
    chez.write(".m", "dest version\n")
    assert chez.run("add", ".m").returncode == 0
    chez.write_source("dot_m", "source version\n")
    result = chez.run("merge", ".m", global_args=["-c", str(cfg)])
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: .m: @ROOT@/merger2.sh: exit status 3\n"
    )


def test_merge_directory(chez, log_path):
    """merge refuses directory targets."""
    # CATCHES: a wrong re-implementation breaks: merge refuses directories with 'not a file'.
    merger = _merge_recorder(chez, log_path)
    cfg = _merge_config(chez, merger)
    chez.write("md/f", "m\n")
    assert chez.run("add", "md").returncode == 0
    result = chez.run("merge", "md", global_args=["-c", str(cfg)])
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: md: not a file\n"
    assert not log_path.exists()


def test_merge_all_modified_files(chez, log_path):
    """merge-all invokes the merge command once per modified file."""
    # CATCHES: a wrong re-implementation breaks: merge-all invokes the merge command once per modified file.
    merger = _merge_recorder(chez, log_path)
    cfg = _merge_config(chez, merger)
    chez.write(".m1", "d1\n")
    chez.write(".m2", "d2\n")
    assert chez.run("add", ".m1", ".m2").returncode == 0
    chez.write_source("dot_m1", "s1\n")
    chez.write_source("dot_m2", "s2\n")
    result = chez.run("merge-all", global_args=["-c", str(cfg)])
    assert result.returncode == 0
    lines = chez.norm(log_path.read_text()).splitlines()
    assert [line for line in lines if line == "MERGE 3"] == ["MERGE 3", "MERGE 3"]
    assert "  <@HOME@/.m1>" in lines
    assert "  <@HOME@/.m2>" in lines


def test_merge_all_no_modified_files(chez, log_path):
    """merge-all is a no-op when the destination matches the target state."""
    # CATCHES: a wrong re-implementation breaks: merge-all is a no-op when destination matches the target state.
    merger = _merge_recorder(chez, log_path)
    cfg = _merge_config(chez, merger)
    # pin the mode so the actual state matches the target state's 0644
    chez.write(".m", "same\n", mode=0o644)
    assert chez.run("add", ".m").returncode == 0
    result = chez.run("merge-all", global_args=["-c", str(cfg)])
    assert result.returncode == 0
    assert not log_path.exists()
