"""Tests for ``chezmoi cat`` and ``chezmoi dump``."""

import json

import pytest


@pytest.fixture()
def populated(chez):
    """A source state with a file, a template, a symlink, a dir and a script."""
    chez.write(".plain", "plain-content\n")
    chez.write(".tpl", "os={{ .chezmoi.os }}\n")
    chez.write(".tgt", "t\n")
    chez.symlink(".tgt", ".sl")
    chez.write(".d/f", "df\n")
    assert chez.run("add", ".plain", ".sl", ".d").returncode == 0
    assert chez.run("add", "--template", ".tpl").returncode == 0
    chez.write_source("run_once_script.sh", "#!/bin/sh\necho hello-script\n")
    return chez


def test_cat_plain_file(populated):
    """cat prints the stored contents of a managed file."""
    # CATCHES: a wrong re-implementation breaks: cat prints the stored source contents verbatim on stdout.
    result = populated.run("cat", ".plain")
    assert result.returncode == 0
    assert result.stdout == b"plain-content\n"
    assert result.stderr == b""


def test_cat_renders_template(populated):
    """cat prints the rendered target, not the raw template."""
    # CATCHES: a wrong re-implementation breaks: cat renders templates ({{ .chezmoi.os }} becomes linux) before printing.
    result = populated.run("cat", ".tpl")
    assert result.returncode == 0
    assert result.stdout == b"os=linux\n"


def test_cat_symlink(populated):
    """cat prints the link target of a managed symlink."""
    # CATCHES: a wrong re-implementation breaks: cat of a symlink prints the link target with a trailing newline.
    result = populated.run("cat", ".sl")
    assert result.returncode == 0
    assert result.stdout == b".tgt\n"


def test_cat_script(populated):
    """cat prints the contents of a script target."""
    # CATCHES: a wrong re-implementation breaks: scripts are printed under their derived target name script.sh.
    result = populated.run("cat", "script.sh")
    assert result.returncode == 0
    assert result.stdout == b"#!/bin/sh\necho hello-script\n"


def test_cat_multiple_targets(populated):
    """cat concatenates the output of multiple targets in argument order."""
    # CATCHES: a wrong re-implementation breaks: cat concatenates multiple targets in argument order.
    result = populated.run("cat", ".plain", ".tpl")
    assert result.returncode == 0
    assert result.stdout == b"plain-content\nos=linux\n"


def test_cat_directory_error(populated):
    """cat refuses directories with a dedicated message."""
    # CATCHES: a wrong re-implementation breaks: directories are refused with 'not a file, script, or symlink'.
    result = populated.run("cat", ".d")
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: .d: not a file, script, or symlink\n"


def test_cat_unmanaged(chez):
    """cat of an unmanaged target fails."""
    # CATCHES: a wrong re-implementation breaks: cat of an unmanaged target fails with 'not managed'.
    chez.write(".managed", "m\n")
    assert chez.run("add", ".managed").returncode == 0
    result = chez.run("cat", ".nope")
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: .nope: not managed\n"


def test_dump_json(populated):
    """dump prints the whole target state as sorted, indented JSON."""
    # CATCHES: a wrong re-implementation breaks: JSON dump shape: type/name/contents/perm and condition once for scripts.
    result = populated.run("dump")
    assert result.returncode == 0
    assert result.stderr == b""
    assert json.loads(result.stdout) == {
        ".d": {"type": "dir", "name": ".d", "perm": 493},
        ".d/f": {
            "type": "file",
            "name": ".d/f",
            "contents": "df\n",
            "perm": 420,
        },
        ".plain": {
            "type": "file",
            "name": ".plain",
            "contents": "plain-content\n",
            "perm": 420,
        },
        ".sl": {"type": "symlink", "name": ".sl", "linkname": ".tgt"},
        ".tpl": {
            "type": "file",
            "name": ".tpl",
            "contents": "os=linux\n",
            "perm": 420,
        },
        "script.sh": {
            "type": "script",
            "name": "script.sh",
            "contents": "#!/bin/sh\necho hello-script\n",
            "condition": "once",
        },
    }
    # the exact wire format is pinned too: two-space indent, sorted keys
    lines = result.stdout.decode().splitlines()
    assert lines[:3] == ['{', '  ".d": {', '    "type": "dir",']
    assert lines[-1] == "}"


def test_dump_json_permission_bits(chez):
    """dump reports target permissions in decimal (0600 -> 384, 0755 -> 493)."""
    # CATCHES: a wrong re-implementation breaks: dump reports perms decimally: 0600 becomes 384 and 0755 becomes 493.
    chez.write(".priv", "p\n", mode=0o600)
    chez.write(".exe", "e\n", mode=0o755)
    assert chez.run("add", ".priv", ".exe").returncode == 0
    result = chez.run("dump")
    assert result.returncode == 0
    data = json.loads(result.stdout)
    assert data[".priv"]["perm"] == 384
    assert data[".exe"]["perm"] == 493


def test_dump_yaml(populated):
    """--format=yaml dumps the same state as YAML (condition becomes 2)."""
    # CATCHES: a wrong re-implementation breaks: YAML dump uses block scalars and encodes the script condition as 2.
    result = populated.run("dump", "--format=yaml")
    assert result.returncode == 0
    assert result.stderr == b""
    assert result.stdout.decode().splitlines() == [
        ".d:",
        "  type: dir",
        "  name: .d",
        "  perm: 493",
        ".d/f:",
        "  type: file",
        "  name: .d/f",
        "  contents: |",
        "    df",
        "  perm: 420",
        ".plain:",
        "  type: file",
        "  name: .plain",
        "  contents: |",
        "    plain-content",
        "  perm: 420",
        ".sl:",
        "  type: symlink",
        "  name: .sl",
        "  linkname: .tgt",
        ".tpl:",
        "  type: file",
        "  name: .tpl",
        "  contents: |",
        "    os=linux",
        "  perm: 420",
        "script.sh:",
        "  type: script",
        "  name: script.sh",
        '  contents: "#!/bin/sh\\necho hello-script\\n"',
        "  condition: 2",
    ]


def test_dump_filters_targets(populated):
    """dump with a target argument prints only that target."""
    # CATCHES: a wrong re-implementation breaks: dump with a target argument prints only that target's object.
    result = populated.run("dump", ".plain")
    assert result.returncode == 0
    assert json.loads(result.stdout) == {
        ".plain": {
            "type": "file",
            "name": ".plain",
            "contents": "plain-content\n",
            "perm": 420,
        }
    }


def test_dump_invalid_format(populated):
    """dump rejects unknown formats."""
    # CATCHES: a wrong re-implementation breaks: dump rejects unknown --format values via the flag validator.
    result = populated.run("dump", "--format=bogus")
    assert result.returncode == 1
    assert result.stderr == (
        b'chezmoi: invalid argument "bogus" for "-f, --format" flag: '
        b"invalid value\n"
    )


def test_dump_unmanaged(populated):
    """dump of an unmanaged target fails."""
    # CATCHES: a wrong re-implementation breaks: dump of an unmanaged target fails with 'not managed'.
    result = populated.run("dump", ".nope")
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: .nope: not managed\n"


def test_dump_missing_source_dir(chez):
    """dump fails when the source directory does not exist."""
    # CATCHES: a wrong re-implementation breaks: dump on a missing source directory reports the stat error.
    result = chez.run("dump")
    assert result.returncode == 1
    assert chez.norm(result.stderr) == (
        b"chezmoi: stat @HOME@/dot: no such file or directory\n"
    )
