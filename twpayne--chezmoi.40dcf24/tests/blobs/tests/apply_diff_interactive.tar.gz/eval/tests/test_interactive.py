"""Tests for the interactive layer: --no-tty prompts, apply confirmations,
pinentry, and the internal-test prompt commands.

All prompts are exercised in ``--no-tty`` mode, where they become plain
line-based reads from stdin with ``(default X)`` fallbacks and unique-choice
abbreviations, printed on stdout.
"""

import re

import pytest

from conftest import Chezmoi, run_chezmoi, script


@pytest.fixture()
def cz(tmp_path):
    return Chezmoi(tmp_path)


# --------------------------------------------------------------------------
# internal-test prompt commands (--no-tty line-based mode)
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("stdin", "expected"),
    [
        ("y\n", "Proceed (default false)? true\n"),
        ("true\n", "Proceed (default false)? true\n"),
        ("no\n", "Proceed (default false)? false\n"),
        ("0\n", "Proceed (default false)? false\n"),
        ("\n", "Proceed (default true)? true\n"),
    ],
)
def test_prompt_bool_accepts_bool_spellings(stdin, expected):
    """prompt-bool prints the default and parses many boolean spellings."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-bool", "Proceed", "false" if stdin != "\n" else "true"],
        input=stdin,
    )
    # CATCHES: the prompt is "<prompt> (default <bool>)? " on stdout followed
    # by the echoed result line; 0/1 and yes/no are accepted like Go's strconv
    # style parsing used by chezmoi.
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_prompt_bool_without_default():
    """prompt-bool omits the default clause when none is given."""
    proc = run_chezmoi(["--no-tty", "internal-test", "prompt-bool", "Proceed"], input="1\n")
    # CATCHES: with no default argument the prompt is exactly "Proceed? "
    # and the answer cannot be an empty line.
    assert proc.returncode == 0
    assert proc.stdout == "Proceed? true\n"


def test_prompt_bool_reprompts_on_invalid_input():
    """An unparsable answer reprints the prompt until a valid one arrives."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-bool", "Proceed", "false"],
        input="maybe\nyes\n",
    )
    # CATCHES: invalid input is not an error: the same prompt is printed
    # again and the loop continues reading lines.
    assert proc.returncode == 0
    assert proc.stdout == "Proceed (default false)? Proceed (default false)? true\n"


def test_prompt_bool_eof_is_an_error():
    """Closing stdin mid-prompt surfaces as a chezmoi EOF error."""
    proc = run_chezmoi(["--no-tty", "internal-test", "prompt-bool", "Proceed", "false"], input="")
    # CATCHES: EOF on stdin produces the wrapped error "chezmoi: EOF" with
    # exit code 1 while the prompt itself was already printed.
    assert proc.returncode == 1
    assert proc.stdout == "Proceed (default false)? "
    assert proc.stderr == "chezmoi: EOF\n"


@pytest.mark.parametrize(
    ("stdin", "expected"),
    [
        ("b\n", "Pick (red/green/blue, default red)? blue\n"),
        ("g\n", "Pick (red/green/blue, default red)? green\n"),
        ("r\n", "Pick (red/green/blue, default red)? red\n"),
        ("green\n", "Pick (red/green/blue, default red)? green\n"),
        ("\n", "Pick (red/green/blue, default red)? red\n"),
    ],
)
def test_prompt_choice_abbreviations_and_default(stdin, expected):
    """prompt-choice accepts unique prefixes, full words, or an empty line."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-choice", "Pick", "red,green,blue", "red"],
        input=stdin,
    )
    # CATCHES: choices are listed slash-separated with ", default X" inside
    # the parentheses; any unambiguous prefix resolves to its choice.
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_prompt_choice_without_default():
    """prompt-choice without a default shows no default clause."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-choice", "Pick", "red,green,blue"],
        input="green\n",
    )
    # CATCHES: the prompt ends at the closing parenthesis with no default
    # fallback offered.
    assert proc.returncode == 0
    assert proc.stdout == "Pick (red/green/blue)? green\n"


def test_prompt_choice_invalid_default_value():
    """A default that is not among the choices is rejected up front."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-choice", "Pick", "red,green", "purple"],
        input="\n",
    )
    # CATCHES: validation happens before any prompting, so nothing is printed
    # on stdout and the error names the invalid default.
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "chezmoi: purple: invalid default value\n"


def test_prompt_choice_ambiguous_prefix_reprompts():
    """An ambiguous prefix is invalid and the prompt repeats."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-choice", "Pick", "yes,yesterday"],
        input="ye\nyes\n",
    )
    # CATCHES: "ye" matches both choices so it is not accepted; only the
    # exact or unambiguous input terminates the loop.
    assert proc.returncode == 0
    assert proc.stdout == "Pick (yes/yesterday)? Pick (yes/yesterday)? yes\n"


@pytest.mark.parametrize(
    ("stdin", "expected"),
    [
        ("\n", "Count (default 42)? 42\n"),
        ("17\n", "Count (default 42)? 17\n"),
        ("-3\n", "Count (default 42)? -3\n"),
        ("x\n9\n", "Count (default 1)? Count (default 1)? 9\n"),
    ],
)
def test_prompt_int_values_and_reprompt(stdin, expected):
    """prompt-int parses integers, falls back to the default, re-prompts."""
    default = "42" if "42" in expected else "1"
    proc = run_chezmoi(["--no-tty", "internal-test", "prompt-int", "Count", default], input=stdin)
    # CATCHES: the default is printed in decimal and unparsable input causes
    # an identical second prompt, mirroring prompt-bool's loop.
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    ("stdin", "expected"),
    [
        ("\n", 'Name (default "root")? root\n'),
        ("user\n", "Name? user\n"),
        ("  spaced  \n", "Name? spaced\n"),
    ],
)
def test_prompt_string_go_quoted_default(stdin, expected):
    """prompt-string renders the default Go-quoted and trims input."""
    args = ["--no-tty", "internal-test", "prompt-string", "Name"] + (["root"] if "root" in expected else [])
    proc = run_chezmoi(args, input=stdin)
    # CATCHES: the string default is displayed with Go strconv.Quote quoting
    # ("root") and the typed answer is whitespace-trimmed.
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_prompt_multichoice_header_and_single_select():
    """prompt-multichoice prints a header then repeated entry prompts."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-multichoice", "Days", "mon,tue,wed", "mon"],
        input="t\n\n",
    )
    # CATCHES: the header is "<prompt>?\nChoices (a/b/c)\nDefault [x]\n" and
    # each line read prints "Choice (ENTER to stop)> "; an empty line ends
    # the selection and the chosen values print one per line.
    assert proc.returncode == 0
    assert proc.stdout == (
        "Days?\nChoices (mon/tue/wed)\nDefault [mon]\n"
        "Choice (ENTER to stop)> Choice (ENTER to stop)> tue\n"
    )


def test_prompt_multichoice_empty_input_takes_defaults():
    """An empty first line selects the default list verbatim."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-multichoice", "Days", "mon,tue,wed", "mon,wed"],
        input="\n",
    )
    # CATCHES: with no selection the defaults are returned as-is, one per
    # line in the order given, and only one entry prompt is printed.
    assert proc.returncode == 0
    assert proc.stdout == "Days?\nChoices (mon/tue/wed)\nDefault [mon, wed]\nChoice (ENTER to stop)> mon\nwed\n"


def test_prompt_multichoice_brackets_select_nothing():
    """The literal ``[]`` answer selects an empty list."""
    proc = run_chezmoi(
        ["--no-tty", "internal-test", "prompt-multichoice", "Days", "mon,tue,wed", "mon"],
        input="[]\n",
    )
    # CATCHES: "[]" short-circuits to an empty selection: no value lines are
    # printed after the single entry prompt and the command still exits 0.
    assert proc.returncode == 0
    assert proc.stdout == "Days?\nChoices (mon/tue/wed)\nDefault [mon]\nChoice (ENTER to stop)> "


def test_read_password_no_tty_reads_line():
    """read-password becomes a plain echoed line read with --no-tty."""
    proc = run_chezmoi(["--no-tty", "internal-test", "read-password"], input="secret\n")
    # CATCHES: the prompt text is "Password? " (no "(default ...)" clause)
    # and the entered line is echoed back on stdout.
    assert proc.returncode == 0
    assert proc.stdout == "Password? secret\n"


# --------------------------------------------------------------------------
# apply --interactive / --less-interactive confirmations
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("answers", "file_applied", "other_applied", "rc", "prompts"),
    [
        ("y\nq\n", True, False, 0, 2),
        ("n\nq\n", False, False, 0, 2),
        ("q\n", False, False, 0, 1),
        ("yes\nno\n", True, False, 0, 2),
    ],
)
def test_apply_interactive_yes_no_quit(cz, answers, file_applied, other_applied, rc, prompts):
    """``--interactive`` asks per target with diff/yes/no/all/quit choices."""
    cz.add("dot_file.txt", "hello\n")
    cz.add("dot_other.txt", "other\n")
    proc = cz.apply("--no-tty", "--interactive", input=answers)
    # CATCHES: every entry gets its own "Apply <target> (diff/yes/no/all/
    # quit)? " prompt on stdout; yes applies, no and quit skip without error,
    # and quit on the first prompt stops before the second is shown.
    assert proc.returncode == rc
    assert proc.stdout == (
        "Apply .file.txt (diff/yes/no/all/quit)? "
        + ("Apply .other.txt (diff/yes/no/all/quit)? " if prompts == 2 else "")
    )
    assert (cz.dest / ".file.txt").exists() is file_applied
    assert (cz.dest / ".other.txt").exists() is other_applied


def test_apply_interactive_all_suppresses_further_prompts(cz):
    """Answering ``all`` applies the rest without prompting again."""
    cz.add("dot_file.txt", "hello\n")
    cz.add("dot_other.txt", "other\n")
    proc = cz.apply("--no-tty", "--interactive", input="a\n")
    # CATCHES: the single-letter abbreviation "a" is accepted for "all" and
    # only one prompt is printed even though two entries are applied.
    assert proc.returncode == 0
    assert proc.stdout == "Apply .file.txt (diff/yes/no/all/quit)? "
    assert cz.read_dest(".file.txt") == "hello\n"
    assert cz.read_dest(".other.txt") == "other\n"


def test_apply_interactive_diff_answer_prints_patch_then_reprompts(cz):
    """The ``diff`` answer prints the git patch inline and asks again."""
    cz.add("dot_file.txt", "hello\n")
    proc = cz.apply("--no-tty", "--interactive", input="d\ny\n")
    # CATCHES: choosing diff prints the full unified patch between the
    # prompt and the repeated identical prompt for the same target.
    assert proc.returncode == 0
    assert proc.stdout == (
        "Apply .file.txt (diff/yes/no/all/quit)? "
        "diff --git a/.file.txt b/.file.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..ce013625030ba8dba906f756967f9e9ca394464a\n"
        "--- /dev/null\n"
        "+++ b/.file.txt\n"
        "@@ -0,0 +1 @@\n"
        "+hello\n"
        "Apply .file.txt (diff/yes/no/all/quit)? "
    )
    assert cz.read_dest(".file.txt") == "hello\n"


def test_apply_interactive_eof_mid_prompt(cz):
    """Running out of stdin during a prompt fails with the target's EOF."""
    cz.add("dot_file.txt", "hello\n")
    cz.add("dot_other.txt", "other\n")
    proc = cz.apply("--no-tty", "--interactive", input="y\n")
    # CATCHES: after the first target is applied, EOF on the second prompt
    # aborts with "<target>: EOF" naming the pending target, exit code 1.
    assert proc.returncode == 1
    assert proc.stderr == "chezmoi: .other.txt: EOF\n"
    assert (cz.dest / ".file.txt").exists()


def test_apply_force_and_interactive_are_mutually_exclusive(cz):
    """``--force`` plus ``--interactive`` is rejected before any work."""
    cz.add("dot_file.txt", "hello\n")
    proc = cz.apply("--no-tty", "--force", "--interactive")
    # CATCHES: the two flags cannot be combined: the error message is exact
    # and nothing is applied or prompted.
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "chezmoi: the --force and --interactive flags are mutually exclusive\n"
    assert not (cz.dest / ".file.txt").exists()


def test_apply_default_mode_prompts_for_dirty_target(cz):
    """Without flags, apply only prompts for targets changed since last write."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".file.txt", "dirty\n")
    proc = cz.apply("--no-tty", input="o\n")
    # CATCHES: the default conflict prompt reads "<target> has changed since
    # chezmoi last wrote it (diff/overwrite/all-overwrite/skip/quit)? " and
    # "o" is a unique abbreviation for overwrite.
    assert proc.returncode == 0
    assert proc.stdout == (
        ".file.txt has changed since chezmoi last wrote it "
        "(diff/overwrite/all-overwrite/skip/quit)? "
    )
    assert cz.read_dest(".file.txt") == "hello\n"


def test_apply_default_mode_dirty_eof_is_error(cz):
    """EOF at the default-mode conflict prompt aborts with exit 1."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".file.txt", "dirty\n")
    proc = cz.apply("--no-tty", input="")
    # CATCHES: the prompt appears on stdout before the read fails, and the
    # error names the target whose prompt hit EOF.
    assert proc.returncode == 1
    assert proc.stdout == (
        ".file.txt has changed since chezmoi last wrote it "
        "(diff/overwrite/all-overwrite/skip/quit)? "
    )
    assert proc.stderr == "chezmoi: .file.txt: EOF\n"


@pytest.mark.parametrize(
    ("answer", "final_content"),
    [("o\n", "hello\n"), ("s\n", "pre-existing\n"), ("skip\n", "pre-existing\n")],
)
def test_apply_less_interactive_pre_existing(cz, answer, final_content):
    """``--less-interactive`` prompts for pre-existing targets."""
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "pre-existing\n")
    proc = cz.apply("--no-tty", "--less-interactive", input=answer)
    # CATCHES: the prompt text is "<target> already exists (diff/overwrite/
    # all-overwrite/skip/quit)? " and skip leaves the destination untouched.
    assert proc.returncode == 0
    assert proc.stdout == ".file.txt already exists (diff/overwrite/all-overwrite/skip/quit)? "
    assert cz.read_dest(".file.txt") == final_content


def test_apply_less_interactive_dirty_prompt(cz):
    """``--less-interactive`` uses the changed-since-last-write wording."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".file.txt", "externally-modified\n")
    proc = cz.apply("--no-tty", "--less-interactive", input="ao\n")
    # CATCHES: for a dirty target the wording is "has changed since chezmoi
    # last wrote it"; "ao" is NOT a prefix of "all-overwrite" so it is
    # invalid, the prompt repeats, and EOF then fails the run.
    assert proc.returncode == 1
    assert proc.stdout == 2 * (
        ".file.txt has changed since chezmoi last wrote it "
        "(diff/overwrite/all-overwrite/skip/quit)? "
    )
    assert proc.stderr == "chezmoi: .file.txt: EOF\n"
    assert cz.read_dest(".file.txt") == "externally-modified\n"


def test_apply_dirty_prompt_diff_answer_applies_textconv(cz):
    """The diff answer routes through diffFile, which applies textConv."""
    cz.add("dot_doc.md", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".doc.md", "HELLO\n")
    # The pattern matches the relative path used by the prompt's diff path,
    # unlike the diff command which matches absolute paths.
    cz.set_config('textConv = [{ pattern = "*.md", command = "tr", args = ["a-z", "A-Z"] }]\n')
    proc = cz.apply("--no-tty", input="d\no\n")
    # CATCHES: the inline diff from the "diff" answer runs the textConv
    # filter on both sides, so the patch collapses to its header line only.
    assert proc.returncode == 0
    assert proc.stdout == (
        ".doc.md has changed since chezmoi last wrote it "
        "(diff/overwrite/all-overwrite/skip/quit)? "
        "diff --git a/.doc.md b/.doc.md\n"
        ".doc.md has changed since chezmoi last wrote it "
        "(diff/overwrite/all-overwrite/skip/quit)? "
    )
    assert cz.read_dest(".doc.md") == "hello\n"


def test_apply_init_prompt_bool_once_and_int_once(cz):
    """promptBoolOnce/promptIntOnce prompt once each in config templates."""
    cz.add(
        ".chezmoi.toml.tmpl",
        "data = { flag = {{ promptBoolOnce . \"flag\" \"Enable?\" false }}, "
        "num = {{ promptIntOnce . \"num\" \"Num?\" 3 }} }\n",
    )
    proc = cz.apply("--no-tty", "--init", input="true\n7\n")
    # CATCHES: the *Once functions fall back to prompting with their default
    # values shown, in template order, and the answers land in the config.
    assert proc.returncode == 0
    assert proc.stdout == "Enable? (default false)? Num? (default 3)? "
    assert cz.config_file.read_text() == "data = { flag = true, num = 7 }\n"


# --------------------------------------------------------------------------
# pinentry
# --------------------------------------------------------------------------


def test_pinentry_command_replaces_password_prompt(tmp_path):
    """``pinentry.command`` is spoken to via the assuan protocol."""
    log = tmp_path / "pinentry.log"
    fake = script(
        tmp_path / "fake-pinentry",
        "#!/bin/sh\n"
        "printf 'OK Pleased to meet you\\n'\n"
        "while IFS= read -r line; do\n"
        f'  printf "%s\\n" "$line" >> {log}\n'
        '  case "$line" in\n'
        '    GETPIN) printf "D pinentry-secret\\nOK\\n" ;;\n'
        '    *) printf "OK\\n" ;;\n'
        "  esac\n"
        "done\n",
    )
    cz = Chezmoi(tmp_path / "env", config=f'pinentry = {{ command = "{fake}" }}\n')
    proc = cz.run("internal-test", "read-password")
    # CATCHES: chezmoi talks assuan to the configured pinentry binary (no
    # prompt on stdout) and echoes the returned PIN; the SETPROMPT line
    # carries the "Password? " prompt text.
    assert proc.returncode == 0
    assert proc.stdout == "pinentry-secret\n"
    commands = log.read_text().splitlines()
    assert commands[:2] == ["OPTION allow-external-password-cache", "SETPROMPT Password? "]
    assert "SETTITLE chezmoi" in commands
    assert "GETPIN" in commands


def test_pinentry_no_tty_takes_precedence(tmp_path):
    """``--no-tty`` bypasses pinentry and reads from stdin instead."""
    fake = script(
        tmp_path / "fake-pinentry",
        '#!/bin/sh\nprintf "OK\\n"\nwhile IFS= read -r l; do printf "OK\\n"; done\n',
    )
    cz = Chezmoi(tmp_path / "env", config=f'pinentry = {{ command = "{fake}" }}\n')
    proc = cz.run("internal-test", "read-password", "--no-tty", input="stdin-secret\n")
    # CATCHES: no-tty mode wins over the pinentry configuration: the plain
    # "Password? " prompt is printed and the stdin line becomes the password.
    assert proc.returncode == 0
    assert proc.stdout == "Password? stdin-secret\n"


# --------------------------------------------------------------------------
# prompt* template functions in config templates (apply --init)
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("template", "answer", "prompt", "config_line"),
    [
        (
            'data = { b = {{ promptBool "Enable?" false }} }\n',
            "y\n",
            "Enable? (default false)? ",
            "data = { b = true }\n",
        ),
        (
            'data = { n = {{ promptInt "Count" 5 }} }\n',
            "9\n",
            "Count (default 5)? ",
            "data = { n = 9 }\n",
        ),
        (
            'data = { s = "{{ promptString "Name" }}" }\n',
            "  spaced  \n",
            "Name? ",
            'data = { s = "spaced" }\n',
        ),
    ],
)
def test_config_template_prompt_functions(cz, template, answer, prompt, config_line):
    """promptBool/promptInt/promptString run interactively in config templates."""
    cz.add(".chezmoi.toml.tmpl", template)
    cz.add("dot_x.txt", "x\n")
    proc = cz.apply("--no-tty", "--init", input=answer)
    # CATCHES: the non-Once prompt functions read from stdin during config
    # template rendering (with the same "(default X)? " suffixes as the
    # internal-test commands) and the answers land verbatim in the config file.
    assert proc.returncode == 0
    assert proc.stdout == prompt
    assert cz.config_file.read_text() == config_line
    # CATCHES: the rendered config is reloaded and the apply continues in the
    # same run.
    assert cz.read_dest(".x.txt") == "x\n"


def test_config_template_prompt_choice_with_split_list(cz):
    """promptChoice needs a real list; splitList builds one and re-prompts."""
    cz.add(
        ".chezmoi.toml.tmpl",
        'data = { c = "{{ promptChoice "Pick" (splitList "," "red,green,blue") "red" }}" }\n',
    )
    cz.add("dot_x.txt", "x\n")
    proc = cz.apply("--no-tty", "--init", input="x\ng\n")
    # CATCHES: an invalid answer re-prints the identical choice prompt before
    # a valid one is accepted, and the chosen value is written to the config.
    assert proc.returncode == 0
    assert proc.stdout == "Pick (red/green/blue, default red)? " * 2
    assert cz.config_file.read_text() == 'data = { c = "green" }\n'


def test_config_template_prompt_choice_string_is_not_a_list(cz):
    """A comma-separated string is one choice, so the default is invalid."""
    cz.add(
        ".chezmoi.toml.tmpl",
        'data = { c = "{{ promptChoice "Pick" "red,green,blue" "red" }}" }\n',
    )
    cz.add("dot_x.txt", "x\n")
    proc = cz.apply("--no-tty", "--init", input="b\n")
    # CATCHES: choices are not split on commas inside templates, so the whole
    # string is a single choice and the default fails validation with the
    # template position in the error; no config is written.
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "chezmoi: template: chezmoi.toml:1:17: executing \"chezmoi.toml\" "
        "at <promptChoice \"Pick\" \"red,green,blue\" \"red\">: "
        "error calling promptChoice: red: invalid default value\n"
    )
    # The pre-created (empty) config file was left untouched.
    assert cz.config_file.read_text() == ""


@pytest.mark.parametrize(
    ("answer", "result"),
    [
        ("\n", "[mon]"),
        ("m\nw\n\n", "[mon wed]"),
    ],
)
def test_config_template_prompt_multichoice(cz, answer, result):
    """promptMultichoice in a config template returns a list of picks."""
    cz.add(
        ".chezmoi.toml.tmpl",
        'data = { m = "{{ promptMultichoice "Days" (splitList "," "mon,tue,wed") '
        '(splitList "," "mon") }}" }\n',
    )
    cz.add("dot_x.txt", "x\n")
    proc = cz.apply("--no-tty", "--init", input=answer)
    # CATCHES: the multichoice header and per-entry prompts are printed and
    # the resulting []string is rendered by the template as "[a b]"; the
    # selections are accumulated in a Go map, so their rendered order is
    # random and only the set of picks is asserted.
    assert proc.returncode == 0
    assert proc.stdout == (
        "Days?\n"
        "Choices (mon/tue/wed)\n"
        "Default [mon]\n"
        + "Choice (ENTER to stop)> " * (1 if answer == "\n" else 3)
    )
    rendered = re.fullmatch(r'data = \{ m = "\[([^"]*)\]" \}\n', cz.config_file.read_text())
    assert rendered is not None
    assert sorted(rendered.group(1).split(" ")) == sorted(result[1:-1].split(" "))


def test_config_template_prompt_eof_is_a_template_error(cz):
    """EOF at a config-template prompt surfaces as a template error."""
    cz.add(".chezmoi.toml.tmpl", 'data = { s = "{{ promptString "Name" }}" }\n')
    cz.add("dot_x.txt", "x\n")
    proc = cz.apply("--no-tty", "--init", input="")
    # CATCHES: the prompt is printed before stdin ends, and the EOF is wrapped
    # in the Go template error naming the function and its position; the run
    # aborts without writing the config or the destination.
    assert proc.returncode == 1
    assert proc.stdout == "Name? "
    assert proc.stderr == (
        "chezmoi: template: chezmoi.toml:1:17: executing \"chezmoi.toml\" "
        "at <promptString \"Name\">: error calling promptString: EOF\n"
    )
    assert not (cz.dest / ".x.txt").exists()


def test_prompt_once_uses_existing_chezmoi_data_without_prompting(cz):
    """``*Once`` functions return values already present in the data map."""
    cz.add(
        ".chezmoi.toml.tmpl",
        'data = { os = "{{ promptStringOnce . "chezmoi.os" "OS?" }}", '
        'c = "{{ promptChoiceOnce . "chezmoi.os" "OS?" "linux,darwin" }}" }\n',
    )
    cz.add("dot_x.txt", "x\n")
    proc = cz.apply("--no-tty", "--init", input="")
    # CATCHES: the config template's data map already contains the .chezmoi
    # variables, so promptStringOnce/promptChoiceOnce return them silently
    # instead of prompting (empty stdin would otherwise be an EOF error).
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert cz.config_file.read_text() == 'data = { os = "linux", c = "linux" }\n'
    assert cz.read_dest(".x.txt") == "x\n"


def test_prompt_bool_once_reflects_command_flags(cz):
    """``promptBoolOnce`` can read the parsed command flags from the data map."""
    cz.add(
        ".chezmoi.toml.tmpl",
        "data = { f = {{ promptBoolOnce . \"chezmoi.flags.force\" \"Force?\" false }} }\n",
    )
    cz.add("dot_x.txt", "x\n")
    plain = cz.apply("--no-tty", "--init", input="")
    # CATCHES: chezmoi.flags.force is a bool in the data map, so the Once
    # lookup returns it directly: false without the flag...
    assert plain.returncode == 0
    assert plain.stdout == ""
    assert cz.config_file.read_text() == "data = { f = false }\n"
    forced = cz.apply("--no-tty", "--init", "--force", input="")
    # CATCHES: ...and true when --force is passed, still without prompting.
    assert forced.returncode == 0
    assert forced.stdout == ""
    assert cz.config_file.read_text() == "data = { f = true }\n"


def test_prompt_once_functions_prompt_when_path_missing(cz):
    """``*Once`` functions prompt when the path is absent from the data map."""
    cz.add(
        ".chezmoi.toml.tmpl",
        'data = { c = "{{ promptChoiceOnce . "color" "Color?" (splitList "," "red,green") "red" }}", '
        's = "{{ promptStringOnce . "name" "Name?" "root" }}", '
        'm = "{{ promptMultichoiceOnce . "days" "Days?" (splitList "," "mon,tue") '
        '(splitList "," "mon") }}" }\n',
    )
    cz.add("dot_x.txt", "x\n")
    proc = cz.apply("--no-tty", "--init", input="g\nuser\n\n")
    # CATCHES: missing paths fall through to the plain prompt functions, in
    # template order, each with its own default syntax (the choice and string
    # prompts append "(default X)? " to the prompt text that already ends in
    # "?", and multichoice appends another "?").
    assert proc.returncode == 0
    assert proc.stdout == (
        "Color? (red/green, default red)? "
        'Name? (default "root")? '
        "Days??\n"
        "Choices (mon/tue)\n"
        "Default [mon]\n"
        "Choice (ENTER to stop)> "
    )
    assert cz.config_file.read_text() == 'data = { c = "green", s = "user", m = "[mon]" }\n'
