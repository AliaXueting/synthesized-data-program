"""Tests for ``chezmoi verify``: the ErrorOnWriteSystem-backed checker.

verify runs the same apply pipeline against a system that fails on the first
write, so it exits 0 only when the destination already matches the target
state (including scripts having run).  It never prints anything itself.
"""

import pytest

from conftest import Chezmoi


@pytest.fixture()
def cz(tmp_path):
    return Chezmoi(tmp_path)


def test_verify_passes_when_destination_matches(cz):
    """A fully applied tree verifies with exit 0 and no output."""
    cz.add("dot_file.txt", "hello\n")
    cz.add("sub/dot_nested.txt", "nested\n")
    before = cz.verify()
    assert before.returncode == 1
    assert before.stdout == ""
    assert before.stderr == ""
    cz.apply("--no-tty")
    after = cz.verify()
    # CATCHES: verify must flip from 1 to 0 after a successful apply and stay
    # completely silent on both streams in both cases.
    assert after.returncode == 0
    assert after.stdout == ""
    assert after.stderr == ""
    # The status report agrees that nothing is pending.
    assert cz.status().stdout == ""


def test_verify_fails_on_modified_file(cz):
    """An externally modified destination file fails verification."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".file.txt", "changed\n")
    proc = cz.verify()
    # CATCHES: content drift is detected via the recorded entry state, and
    # verify reports it only through the exit code (no diff is printed).
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert cz.read_dest(".file.txt") == "changed\n"


def test_verify_fails_on_deleted_file(cz):
    """A destination file deleted after apply fails verification."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    (cz.dest / ".file.txt").unlink()
    proc = cz.verify()
    # CATCHES: deletion counts as a difference from the target state, so the
    # ErrorOnWriteSystem would need to re-create the file and verify fails.
    assert proc.returncode == 1
    assert not (cz.dest / ".file.txt").exists()


def test_verify_fails_on_pre_existing_different_file(cz):
    """A pre-existing destination file differing from the target fails."""
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "pre\n")
    proc = cz.verify()
    # CATCHES: verify checks files chezmoi has never written too; the
    # pre-existing content differs so verification must fail.
    assert proc.returncode == 1
    assert cz.read_dest(".file.txt") == "pre\n"


def test_verify_fails_while_script_pending(cz):
    """A pending run_once script fails verification even if files match."""
    cz.add("run_once_echo.sh", "#!/bin/sh\ntrue\n")
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty", "--include", "files")
    pending = cz.verify()
    # CATCHES: scripts count towards the target state: with the script not
    # yet run, verify fails; after running it (via apply) verify passes.
    assert pending.returncode == 1
    cz.apply("--no-tty")
    assert cz.status().stdout == ""
    done = cz.verify()
    assert done.returncode == 0
    assert done.stdout == ""


def test_verify_target_subset(cz):
    """Target arguments restrict verification to the named entry."""
    cz.add("dot_a.txt", "a\n")
    cz.add("dot_b.txt", "b\n")
    only_b = cz.verify(cz.dest / ".b.txt")
    # CATCHES: verify with a single target reports only that target's state,
    # so the untouched sibling does not influence the result.
    assert only_b.returncode == 1
    cz.apply("--no-tty", cz.dest / ".b.txt")
    assert cz.verify(cz.dest / ".b.txt").returncode == 0
    # The other target is still unverified on its own.
    assert cz.verify(cz.dest / ".a.txt").returncode == 1


def test_verify_missing_directory_is_not_created(cz):
    """A missing parent directory fails verification without being created."""
    cz.add("sub/dot_a.txt", "contents\n")
    status = cz.status()
    proc = cz.verify()
    # CATCHES: the destination directory is created through the same
    # error-on-write system as file writes, so verify fails on the missing
    # directory (Mkdir) and must leave the destination completely empty.
    assert status.stdout == " A sub\n A sub/.a.txt\n"
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert list(cz.dest.iterdir()) == []
    # After a real apply the tree exists and verifies clean.
    cz.apply("--no-tty")
    assert cz.verify().returncode == 0
    assert cz.read_dest("sub/.a.txt") == "contents\n"


def test_verify_mode_only_differences_are_not_fixed(cz):
    """Permission-only drift fails verification and is not repaired."""
    cz.add("executable_dot_x.txt", "same\n")
    cz.mkdir("sub")
    cz.add("sub/dot_a.txt", "a\n")
    cz.apply("--no-tty")
    (cz.dest / ".x.txt").chmod(0o600)
    (cz.dest / "sub").chmod(0o700)
    status = cz.status()
    diff = cz.diff()
    proc = cz.verify()
    # CATCHES: a mode-only difference is repaired by chmod, not by rewriting
    # the file; verify blocks it, so both modes must survive unchanged while
    # status reports "MM" and diff shows only the mode lines.
    assert status.stdout == "MM .x.txt\nMM sub\n"
    assert diff.stdout == (
        "diff --git a/.x.txt b/.x.txt\n"
        "old mode 100600\n"
        "new mode 100755\n"
        "diff --git a/sub b/sub\n"
        "old mode 40700\n"
        "new mode 40755\n"
    )
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert (cz.dest / ".x.txt").stat().st_mode & 0o777 == 0o600
    assert (cz.dest / "sub").stat().st_mode & 0o777 == 0o700
    assert cz.read_dest(".x.txt") == "same\n"


def test_verify_removal_and_symlink_writes_are_blocked(cz):
    """Removals and symlink creation/replacement fail verification silently."""
    cz.add("symlink_dot_l", "elsewhere\n")
    cz.add("dot_gone.txt", "old\n")
    cz.apply("--no-tty")
    # An empty source file means the target is absent, so the destination
    # file would have to be removed.
    cz.add("dot_gone.txt", "")
    # A wrong existing symlink would have to be removed and rewritten.
    (cz.dest / ".l").unlink()
    (cz.dest / ".l").symlink_to("wrong")
    status = cz.status()
    proc = cz.verify()
    # CATCHES: RemoveAll (for the absent target), and RemoveAll+WriteSymlink
    # (for the wrong link) all go through the error-on-write system, so
    # verify fails while the destination keeps the stale file and link.  The
    # codes differ: the absent target is " D" (last write was a file), while
    # the wrong link is "MM" (link changed since the last write).
    assert status.stdout == " D .gone.txt\nMM .l\n"
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert cz.read_dest(".gone.txt") == "old\n"
    assert (cz.dest / ".l").readlink().name == "wrong"


def test_verify_missing_symlink_is_not_created(cz):
    """A missing symlink target fails verification without creating it."""
    cz.add("symlink_dot_l", "elsewhere\n")
    diff = cz.diff()
    proc = cz.verify()
    # CATCHES: creating the symlink is a write, so verify fails and the
    # destination must not contain any link even though diff shows the
    # new-file patch for it.
    assert diff.returncode == 0
    assert "new file mode 120000" in diff.stdout
    assert proc.returncode == 1
    assert not (cz.dest / ".l").exists()
    assert not (cz.dest / ".l").is_symlink()
    cz.apply("--no-tty")
    assert (cz.dest / ".l").readlink().name == "elsewhere"
    assert cz.verify().returncode == 0


def test_verify_script_entry_type_filter(cz):
    """--include/--exclude scripts toggle whether scripts are verified."""
    cz.add("dot_a.txt", "a\n")
    cz.add("run_once_hello.sh", "#!/bin/sh\necho hi\n")
    cz.apply("--no-tty", "--include", "files")
    plain = cz.verify()
    excluded = cz.verify("--exclude", "scripts")
    included = cz.verify("--include", "scripts")
    # CATCHES: the pending script is what makes verification fail; excluding
    # script entries makes verify pass, while including only scripts still
    # fails because the script itself has not run.
    assert plain.returncode == 1
    assert plain.stdout == ""
    assert plain.stderr == ""
    assert cz.status().stdout == " R hello.sh\n"
    assert excluded.returncode == 0
    assert included.returncode == 1
    # Once the script has really run, the unfiltered verify passes.
    cz.apply("--no-tty")
    assert cz.verify().returncode == 0
