"""Tests for ``chezmoi apply``: the core reconciliation engine.

Every test builds a throwaway source/destination/config triplet through the
``Chezmoi`` helper, runs the reference binary, and asserts the exact bytes it
produced plus the resulting state of the destination directory.
"""

import os

import pytest

from conftest import Chezmoi


@pytest.fixture()
def cz(tmp_path):
    return Chezmoi(tmp_path)


def test_apply_creates_files_with_exact_contents_and_mode(cz):
    """A plain apply writes each source file, silently, with mode 0644."""
    cz.add("dot_file.txt", "hello\n")
    proc = cz.apply("--no-tty")
    # CATCHES: apply must be silent (empty stdout/stderr) and exit 0, and the
    # dot_ prefix must map to a hidden file created with the default 0644 mode.
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert cz.read_dest(".file.txt") == "hello\n"
    assert os.stat(cz.dest / ".file.txt").st_mode & 0o777 == 0o644


def test_apply_creates_persistent_state_database(cz):
    """Applying creates chezmoistate.boltdb next to the config file."""
    cz.add("dot_file.txt", "hello\n")
    assert not cz.state_file.exists()
    proc = cz.apply("--no-tty")
    # CATCHES: the persistent state must live next to the config file, named
    # chezmoistate.boltdb, and must be created by a successful apply.
    assert proc.returncode == 0
    assert cz.state_file.is_file()


def test_apply_verbose_prints_git_diff(cz):
    """``apply -v`` echoes the change as a git-style unified diff."""
    cz.add("dot_file.txt", "hello\n")
    proc = cz.apply("--no-tty", "-v")
    # CATCHES: verbose apply routes through the git diff system: the output is
    # a full unified diff with blob hashes, not a plain message.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..ce013625030ba8dba906f756967f9e9ca394464a\n"
        "--- /dev/null\n"
        "+++ b/.file.txt\n"
        "@@ -0,0 +1 @@\n"
        "+hello\n"
    )
    assert proc.stderr == ""


def test_apply_dry_run_modifies_nothing(cz):
    """``-n/--dry-run`` leaves the destination and state database untouched."""
    cz.add("dot_file.txt", "hello\n")
    for flag in ("-n", "--dry-run"):
        proc = cz.apply("--no-tty", flag)
        # CATCHES: DryRunSystem must not create the destination file, must not
        # create the persistent state database, and must still exit 0.
        assert proc.returncode == 0
        assert proc.stdout == ""
        assert not (cz.dest / ".file.txt").exists()
        assert not cz.state_file.exists()
    assert cz.status().stdout == " A .file.txt\n"


def test_apply_dry_run_verbose_prints_diff(cz):
    """``apply -n -v`` previews the diff without writing anything."""
    cz.add("dot_file.txt", "hello\n")
    proc = cz.apply("--no-tty", "-n", "-v")
    # CATCHES: dry-run verbose output is identical to the real verbose diff,
    # proving the diff system is layered under dry-run rather than skipped.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..ce013625030ba8dba906f756967f9e9ca394464a\n"
        "--- /dev/null\n"
        "+++ b/.file.txt\n"
        "@@ -0,0 +1 @@\n"
        "+hello\n"
    )
    assert not (cz.dest / ".file.txt").exists()


def test_apply_target_subset_applies_only_named_targets(cz):
    """Target arguments restrict apply to the named destination entries."""
    cz.add("dot_a.txt", "a\n")
    cz.add("sub/dot_b.txt", "b\n")
    proc = cz.apply("--no-tty", cz.dest / ".a.txt")
    # CATCHES: applying one target must not create sibling entries nor even
    # the unrelated ``sub`` directory.
    assert proc.returncode == 0
    assert (cz.dest / ".a.txt").read_text() == "a\n"
    assert not (cz.dest / "sub").exists()


def test_apply_directory_target_recurses(cz):
    """A directory target applies the whole subtree, nested dirs included."""
    cz.add("sub/dot_b.txt", "b\n")
    cz.add("sub/inner/dot_d.txt", "d\n")
    proc = cz.apply("--no-tty", cz.dest / "sub")
    # CATCHES: a directory argument applies every entry below it even without
    # --recursive, including files in nested subdirectories.
    assert proc.returncode == 0
    assert (cz.dest / "sub" / ".b.txt").read_text() == "b\n"
    assert (cz.dest / "sub" / "inner" / ".d.txt").read_text() == "d\n"


def test_apply_parent_dirs_flag_creates_missing_ancestors(cz):
    """``-P`` applies parent directories of the target before the file."""
    cz.add("deep/dir/dot_b.txt", "b\n")
    plain = cz.apply("--no-tty", cz.dest / "deep" / "dir" / ".b.txt")
    # CATCHES: without -P a file whose parent directories do not exist fails
    # with a stat error naming the missing directory; -P creates them first.
    assert plain.returncode == 1
    assert plain.stderr == (
        f"chezmoi: deep/dir/.b.txt: stat {cz.dest}/deep/dir: no such file or directory\n"
    )
    assert not (cz.dest / "deep").exists()
    with_parents = cz.apply("--no-tty", "-P", cz.dest / "deep" / "dir" / ".b.txt")
    assert with_parents.returncode == 0
    assert (cz.dest / "deep" / "dir" / ".b.txt").read_text() == "b\n"


def test_apply_replaces_destination_file_with_directory(cz):
    """A file occupying a needed directory path is replaced, but status fails."""
    cz.add("dot_a/dot_b.txt", "f\n")
    cz.write_dest(".a", "iamfile\n")
    error = f"chezmoi: .a/.b.txt: lstat {cz.dest}/.a/.b.txt: not a directory\n"
    status = cz.status()
    # CATCHES: status stats every destination entry up front and fails with
    # the raw lstat error when a file sits where a directory is needed.
    assert status.returncode == 1
    assert status.stdout == ""
    assert status.stderr == error
    diff = cz.diff()
    # CATCHES: diff still renders the file-to-directory transition for .a
    # (a deletion patch followed by a 100644->40755 mode patch) before
    # failing on the nested entry with the same lstat error.
    assert diff.returncode == 1
    assert diff.stdout == (
        "diff --git a/.a b/.a\n"
        "deleted file mode 100644\n"
        "index 6aeccf1c3617d24276da7731e7b9954e2e029352..0000000000000000000000000000000000000000\n"
        "--- a/.a\n"
        "+++ /dev/null\n"
        "@@ -1 +0,0 @@\n"
        "-iamfile\n"
        "diff --git a/.a b/.a\n"
        "old mode 100644\n"
        "new mode 40755\n"
        "index 6aeccf1c3617d24276da7731e7b9954e2e029352..e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\n"
        "--- a/.a\n"
        "+++ b/.a\n"
        "@@ -1 +0,0 @@\n"
        "-iamfile\n"
    )
    assert diff.stderr == error
    proc = cz.apply("--no-tty")
    # CATCHES: apply, unlike status, removes the obstructing file and creates
    # the directory and the file inside it.
    assert proc.returncode == 0
    assert proc.stderr == ""
    assert (cz.dest / ".a").is_dir()
    assert (cz.dest / ".a" / ".b.txt").read_text() == "f\n"
    after = cz.status()
    assert after.returncode == 0
    assert after.stdout == ""


def test_apply_relative_target_resolved_against_cwd(cz):
    """Relative target arguments are resolved against the working directory."""
    cz.add("dot_a.txt", "a\n")
    proc = cz.apply("--no-tty", "../dest/.a.txt", cwd=cz.src)
    # CATCHES: target args are paths, not patterns: ``../dest/.a.txt`` run
    # from inside the source directory must resolve to the destination file.
    assert proc.returncode == 0
    assert (cz.dest / ".a.txt").read_text() == "a\n"


@pytest.mark.parametrize(
    "target",
    ["zzz.txt", "dest"],
)
def test_apply_invalid_target_errors(cz, tmp_path, target):
    """Unmanaged or out-of-tree targets fail with precise error messages."""
    cz.add("dot_a.txt", "a\n")
    if target == "zzz.txt":
        proc = cz.apply("--no-tty", cz.dest / "zzz.txt")
        # CATCHES: a destination path that is not managed must be reported as
        # "not managed" with the absolute path, not silently ignored.
        assert proc.stderr == f"chezmoi: {cz.dest}/zzz.txt: not managed\n"
    else:
        proc = cz.apply("--no-tty", tmp_path / "elsewhere.txt")
        # CATCHES: targets outside the destination directory are rejected with
        # a "not in destination directory" error naming both paths.
        assert proc.stderr == (
            f"chezmoi: {tmp_path}/elsewhere.txt: not in destination directory ({cz.dest})\n"
        )
    assert proc.returncode == 1
    assert not (cz.dest / ".a.txt").exists()


def test_apply_keep_going_continues_after_script_failure(cz):
    """``-k/--keep-going`` records the error but applies remaining targets."""
    cz.add("run_aaa.sh", "#!/bin/sh\nexit 3\n")
    cz.add("plain_zzz.txt", "z\n")
    stopped = cz.apply("--no-tty")
    # CATCHES: without -k the first failing script aborts the whole run; with
    # -k the error is printed but later entries are still applied, exit 1.
    assert stopped.returncode == 1
    assert stopped.stderr == "chezmoi: aaa.sh: exit status 3\n"
    assert not (cz.dest / "plain_zzz.txt").exists()
    kept = cz.apply("--no-tty", "-k")
    assert kept.returncode == 1
    assert kept.stderr == "chezmoi: aaa.sh: exit status 3\n"
    assert (cz.dest / "plain_zzz.txt").read_text() == "z\n"


def test_apply_force_overwrites_externally_modified_file(cz):
    """``--force`` rewrites a file changed since the last apply, silently."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".file.txt", "externally-modified\n")
    proc = cz.apply("--no-tty", "--force")
    # CATCHES: --force suppresses the default-mode conflict prompt entirely:
    # no prompt bytes on stdout, exit 0, and the target content restored.
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert cz.read_dest(".file.txt") == "hello\n"


def test_apply_error_on_conflict_exits_one_without_prompt(cz):
    """``--error-on-conflict`` turns a dirty target into a silent exit 1."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".file.txt", "dirty\n")
    proc = cz.apply("--no-tty", "--error-on-conflict")
    # CATCHES: with --error-on-conflict the conflict prompt is replaced by a
    # bare exit code 1 with no prompt and no error text on any stream.
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert cz.read_dest(".file.txt") == "dirty\n"


def test_apply_entry_types_symlink_private_executable(cz):
    """Attribute prefixes produce symlinks, private and executable files."""
    cz.add("symlink_dot_link", "target-file\n")
    cz.add("private_dot_secret.txt", "s3cret\n")
    cz.add("executable_dot_run.sh", "#!/bin/sh\n")
    proc = cz.apply("--no-tty")
    # CATCHES: symlink_ creates a symbolic link (not a file), private_ forces
    # mode 0600 regardless of umask, and executable_ forces mode 0755.
    assert proc.returncode == 0
    assert os.path.islink(cz.dest / ".link")
    assert os.readlink(cz.dest / ".link") == "target-file"
    assert os.stat(cz.dest / ".secret.txt").st_mode & 0o777 == 0o600
    assert os.stat(cz.dest / ".run.sh").st_mode & 0o777 == 0o755


def test_apply_create_and_remove_directives(cz):
    """``create_`` never overwrites; ``remove_`` deletes existing files."""
    cz.add("create_dot_maybe.txt", "created\n")
    cz.add("remove_dot_gone.txt", "")
    cz.write_dest(".maybe.txt", "pre-existing\n")
    cz.write_dest(".gone.txt", "to-be-removed\n")
    proc = cz.apply("--no-tty")
    # CATCHES: create_ must leave an existing destination file untouched while
    # remove_ must delete the destination file and record nothing for it.
    assert proc.returncode == 0
    assert cz.read_dest(".maybe.txt") == "pre-existing\n"
    assert not (cz.dest / ".gone.txt").exists()


def test_apply_umask_config_scales_file_modes(cz, tmp_path):
    """A ``umask`` config entry is applied to every created file mode."""
    import json

    umask_cz = Chezmoi(tmp_path / "umask", config="umask = 0o077\n")
    umask_cz.add("dot_a.txt", "a\n")
    umask_cz.add("executable_dot_b.sh", "#!/bin/sh\n")
    proc = umask_cz.apply("--no-tty")
    # CATCHES: the umask from the config file (not the process umask) is used
    # both for the destination files and for the mode recorded in the state.
    assert proc.returncode == 0
    assert os.stat(umask_cz.dest / ".a.txt").st_mode & 0o777 == 0o600
    assert os.stat(umask_cz.dest / ".b.sh").st_mode & 0o777 == 0o700
    dump = umask_cz.state("dump")
    assert dump.returncode == 0
    entry_state = json.loads(dump.stdout)["entryState"]
    assert entry_state[f"{umask_cz.dest}/.a.txt"]["mode"] == 384  # 0o600
    assert entry_state[f"{umask_cz.dest}/.b.sh"]["mode"] == 448  # 0o700


def test_apply_script_stdout_and_stderr_forwarded(cz):
    """Script output goes to the matching chezmoi stream, in sorted order."""
    cz.add("run_before_a.sh", "#!/bin/sh\necho before\n")
    cz.add("run_z.sh", "#!/bin/sh\necho during-err >&2\n")
    cz.add("run_after_b.sh", "#!/bin/sh\necho after\n")
    proc = cz.apply("--no-tty")
    # CATCHES: scripts run before/after regular entries by prefix, their
    # stdout/stderr are forwarded to chezmoi's own stdout/stderr.
    assert proc.returncode == 0
    assert proc.stdout == "before\nafter\n"
    assert proc.stderr == "during-err\n"


def test_apply_once_script_runs_only_once(cz):
    """``run_once_`` scripts execute once per persistent state lifetime."""
    cz.add("run_once_echo.sh", "#!/bin/sh\necho once-ran\n")
    first = cz.apply("--no-tty")
    second = cz.apply("--no-tty")
    # CATCHES: the second apply must not re-run the script and must produce no
    # output at all, because scriptState remembers the run.
    assert first.returncode == 0
    assert first.stdout == "once-ran\n"
    assert second.returncode == 0
    assert second.stdout == ""
    deleted = cz.state("delete-bucket", "--bucket", "scriptState")
    assert deleted.returncode == 0
    third = cz.apply("--no-tty")
    assert third.returncode == 0
    assert third.stdout == "once-ran\n"


def test_apply_onchange_script_reruns_on_content_change(cz):
    """``run_onchange_`` scripts re-run when their contents change."""
    cz.add("run_onchange_dot_x.txt.sh", "#!/bin/sh\necho onchange-ran\n")
    first = cz.apply("--no-tty")
    second = cz.apply("--no-tty")
    cz.add("run_onchange_dot_x.txt.sh", "#!/bin/sh\necho onchange-ran2\n")
    third = cz.apply("--no-tty")
    # CATCHES: an unchanged onchange script is skipped on re-apply, but a
    # content change invalidates the stored hash and triggers a re-run.
    assert first.stdout == "onchange-ran\n"
    assert second.stdout == ""
    assert third.stdout == "onchange-ran2\n"


def test_apply_dry_run_still_prompts_for_dirty_target(cz):
    """``-n`` does not suppress the default conflict prompt."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".file.txt", "dirty\n")
    proc = cz.apply("--no-tty", "-n", input="")
    # CATCHES: dry-run goes through the same pre-apply confirmation as a real
    # apply, so a dirty target still prompts and EOF still errors, while the
    # destination is left untouched.
    assert proc.returncode == 1
    assert proc.stdout == (
        ".file.txt has changed since chezmoi last wrote it "
        "(diff/overwrite/all-overwrite/skip/quit)? "
    )
    assert proc.stderr == "chezmoi: .file.txt: EOF\n"
    assert cz.read_dest(".file.txt") == "dirty\n"


def test_apply_init_prompts_for_config_template(cz):
    """``apply --init`` renders .chezmoi.toml.tmpl (with prompts) and reloads."""
    cz.add(".chezmoi.toml.tmpl", 'data = { greeting = "{{ promptString "greeting" "hello" }}" }\n')
    cz.add("dot_greet.txt.tmpl", "{{ .greeting }}\n")
    proc = cz.apply("--no-tty", "--init", input="world\n")
    # CATCHES: --init executes the config template with the interactive
    # template functions (promptString), writes the config, and the rest of
    # the same apply run already uses the reloaded config's data.
    assert proc.returncode == 0
    assert proc.stdout == 'greeting (default "hello")? '
    assert cz.config_file.read_text() == 'data = { greeting = "world" }\n'
    assert cz.read_dest(".greet.txt") == "world\n"
