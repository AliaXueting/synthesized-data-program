"""Tests for ``chezmoi status``: the git-style two-column change report.

The first column (x) compares the last state written by chezmoi with the
actual destination; the second column (y) compares the destination with the
target state.  These tests pin the exact characters and path formatting.
"""

import pytest

from conftest import Chezmoi


@pytest.fixture()
def cz(tmp_path):
    return Chezmoi(tmp_path)


def test_status_before_apply_shows_added_and_run(cz):
    """Unapplied entries report ``A`` in column y; scripts report ``R``."""
    cz.add("dot_file.txt", "hello\n")
    cz.add("dot_sub/dot_nested.txt", "nested\n")
    cz.add("run_once_hello.sh", "#!/bin/sh\ntrue\n")
    proc = cz.status()
    # CATCHES: pending files and directories get " A" (space, A) while a
    # pending run_ script gets " R" in the second column, dirs included.
    assert proc.returncode == 0
    assert proc.stdout == " A .file.txt\n A .sub\n A .sub/.nested.txt\n R hello.sh\n"
    assert proc.stderr == ""


def test_status_clean_after_apply_and_exit_zero_with_changes(cz):
    """Status prints nothing once applied and always exits 0."""
    cz.add("dot_file.txt", "hello\n")
    dirty = cz.status()
    assert dirty.returncode == 0
    assert dirty.stdout == " A .file.txt\n"
    cz.apply("--no-tty")
    clean = cz.status()
    # CATCHES: status itself exits 0 whether or not differences exist (unlike
    # git status) and prints nothing when everything is applied.
    assert clean.returncode == 0
    assert clean.stdout == ""
    assert clean.stderr == ""


def test_status_modified_file_is_mm(cz):
    """A file edited after apply reports ``MM`` (dirty from both views)."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    cz.write_dest(".file.txt", "changed\n")
    proc = cz.status()
    # CATCHES: an externally modified file differs both from the last written
    # state (x=M) and from the target state (y=M), giving "MM".
    assert proc.returncode == 0
    assert proc.stdout == "MM .file.txt\n"


def test_status_deleted_file_is_da(cz):
    """A file deleted after apply reports ``DA``."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    (cz.dest / ".file.txt").unlink()
    proc = cz.status()
    # CATCHES: deletion shows D in column x (was deleted since last write) and
    # A in column y (apply would re-create it).
    assert proc.returncode == 0
    assert proc.stdout == "DA .file.txt\n"


def test_status_pre_existing_file_is_space_m(cz):
    """A never-written destination file reports `` M`` (column x blank)."""
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "pre\n")
    proc = cz.status()
    # CATCHES: for a pre-existing file chezmoi has no last-written state, so
    # the first column stays a space and only the y column shows M.
    assert proc.returncode == 0
    assert proc.stdout == " M .file.txt\n"


def test_status_mixed_entries_sorted(cz):
    """Multiple differing entries print in sorted target order."""
    cz.add("dot_b.txt", "b\n")
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    cz.write_dest(".a.txt", "mod\n")
    (cz.dest / ".b.txt").unlink()
    cz.add("dot_new.txt", "new\n")
    proc = cz.status()
    # CATCHES: entries are always reported in sorted order regardless of the
    # order files were created in, mixing MM/DA/ A codes.
    assert proc.returncode == 0
    assert proc.stdout == "MM .a.txt\nDA .b.txt\n A .new.txt\n"


def test_status_path_style_absolute_and_relative(cz):
    """``-p absolute`` prints destination-rooted absolute paths."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    (cz.dest / ".file.txt").unlink()
    absolute = cz.status("-p", "absolute")
    # CATCHES: with absolute path style the line is "DA <abs path>" where the
    # path is the destination directory joined with the target name.
    assert absolute.returncode == 0
    assert absolute.stdout == f"DA {cz.dest}/.file.txt\n"
    relative = cz.status("--path-style", "relative")
    assert relative.returncode == 0
    assert relative.stdout == "DA .file.txt\n"


def test_status_path_style_invalid_value_rejected(cz):
    """An unknown --path-style value is a flag parse error."""
    cz.add("dot_file.txt", "hello\n")
    proc = cz.status("--path-style", "bogus")
    # CATCHES: only absolute and relative are accepted; anything else fails
    # with cobra's "invalid argument ... invalid value" wording and exit 1.
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == 'chezmoi: invalid argument "bogus" for "-p, --path-style" flag: invalid value\n'


def test_status_include_exclude_scripts(cz):
    """``--include``/``--exclude`` filter entry types in the report."""
    cz.add("run_once_hello.sh", "#!/bin/sh\ntrue\n")
    cz.add("dot_a.txt", "a\n")
    # CATCHES: the entry type filter must accept the plural "scripts" value;
    # including only scripts hides the file and vice versa.
    only_scripts = cz.status("--include", "scripts")
    assert only_scripts.returncode == 0
    assert only_scripts.stdout == " R hello.sh\n"
    no_scripts = cz.status("--exclude", "scripts")
    assert no_scripts.returncode == 0
    assert no_scripts.stdout == " A .a.txt\n"


def test_status_target_subset(cz):
    """Target arguments restrict status to the named entry."""
    cz.add("dot_a.txt", "a\n")
    cz.add("dot_b.txt", "b\n")
    proc = cz.status(cz.dest / ".b.txt")
    # CATCHES: status with a target argument reports only that target, using
    # the same two-column format as the full run.
    assert proc.returncode == 0
    assert proc.stdout == " A .b.txt\n"


def test_status_directory_names_follow_source_conventions(cz):
    """Source directory names are interpreted like file names."""
    cz.add("sub/dot_a.txt", "a\n")
    cz.add("dot_sub3/dot_c.txt", "c\n")
    proc = cz.status()
    # CATCHES: a bare source directory keeps its name while a dot_ prefixed
    # directory maps to a hidden target directory, and both appear in status.
    assert proc.returncode == 0
    assert proc.stdout == " A .sub3\n A .sub3/.c.txt\n A sub\n A sub/.a.txt\n"
