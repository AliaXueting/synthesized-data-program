"""Tests for the global ``--mode`` flag / ``mode`` config option.

``--mode symlink`` makes chezmoi install plain source files as symbolic links
to the source directory instead of copying their contents.
"""

import hashlib
import os

import pytest

from conftest import Chezmoi


@pytest.fixture()
def cz(tmp_path):
    return Chezmoi(tmp_path)


def git_blob(data):
    """The git blob object hash of ``data``, as printed in diff index lines."""
    if isinstance(data, str):
        data = data.encode()
    return hashlib.sha1(b"blob %d\x00" % len(data) + data).hexdigest()


def test_mode_symlink_applies_plain_files_as_symlinks(cz):
    """``--mode symlink`` links plain files but keeps special files as files."""
    cz.add("dot_p.txt", "plain\n")
    cz.add("dot_t.tmpl", "v={{ .chezmoi.os }}\n")
    cz.add("executable_dot_tool.sh", "#!/bin/sh\ntrue\n")
    proc = cz.run("--mode", "symlink", "apply", "--no-tty")
    # CATCHES: only plain files become symlinks; templates are rendered and
    # executable_ files are copied, because the symlink shortcut excludes
    # encrypted, executable, private and template entries.
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""
    link = cz.dest / ".p.txt"
    assert link.is_symlink()
    assert os.readlink(link) == str(cz.src / "dot_p.txt")
    assert not (cz.dest / ".t").is_symlink()
    assert cz.read_dest(".t") == "v=linux\n"
    tool = cz.dest / ".tool.sh"
    assert not tool.is_symlink()
    assert tool.stat().st_mode & 0o777 == 0o755
    # CATCHES: verify accepts the symlinked destination in symlink mode.
    assert cz.run("--mode", "symlink", "verify").returncode == 0


def test_mode_symlink_diff_and_status(cz):
    """Diff output for a pending symlink has mode 120000 and the link target."""
    cz.add("dot_plain.txt", "hello\n")
    status = cz.run("--mode", "symlink", "status")
    assert status.returncode == 0
    assert status.stdout == " A .plain.txt\n"
    diff = cz.run("--mode", "symlink", "diff", "--no-pager")
    # CATCHES: the diff shows a "new file mode 120000" entry whose added line
    # is the absolute source path, hashed as a git blob with a trailing
    # newline in the index line.
    assert diff.returncode == 0
    linkname = f"{cz.src}/dot_plain.txt"
    assert diff.stdout == (
        "diff --git a/.plain.txt b/.plain.txt\n"
        "new file mode 120000\n"
        "index 0000000000000000000000000000000000000000.."
        + git_blob(linkname + "\n")
        + "\n--- /dev/null\n"
        "+++ b/.plain.txt\n"
        "@@ -0,0 +1 @@\n"
        f"+{linkname}\n"
    )
    assert cz.run("--mode", "symlink", "apply", "--no-tty").returncode == 0
    # CATCHES: after the symlink exists, status is clean and verify passes.
    after = cz.run("--mode", "symlink", "status")
    assert after.returncode == 0
    assert after.stdout == ""
    assert cz.run("--mode", "symlink", "verify").returncode == 0


def test_mode_symlink_diff_replaces_regular_file(cz):
    """A regular destination file is replaced by the link in two patches."""
    cz.add("dot_p.txt", "hello\n")
    cz.write_dest(".p.txt", "hello\n")
    diff = cz.run("--mode", "symlink", "diff", "--no-pager")
    # CATCHES: the file-to-symlink transition is rendered as a deletion of
    # the regular file followed by a mode-change patch creating the link.
    assert diff.returncode == 0
    linkname = f"{cz.src}/dot_p.txt"
    assert diff.stdout == (
        "diff --git a/.p.txt b/.p.txt\n"
        "deleted file mode 100644\n"
        "index ce013625030ba8dba906f756967f9e9ca394464a..0000000000000000000000000000000000000000\n"
        "--- a/.p.txt\n"
        "+++ /dev/null\n"
        "@@ -1 +0,0 @@\n"
        "-hello\n"
        "diff --git a/.p.txt b/.p.txt\n"
        "old mode 100644\n"
        "new mode 120000\n"
        "index ce013625030ba8dba906f756967f9e9ca394464a.."
        + git_blob(linkname + "\n")
        + "\n--- a/.p.txt\n"
        "+++ b/.p.txt\n"
        "@@ -1 +1 @@\n"
        "-hello\n"
        f"+{linkname}\n"
    )
    assert cz.run("--mode", "symlink", "apply", "--no-tty").returncode == 0
    assert (cz.dest / ".p.txt").is_symlink()
    assert os.readlink(cz.dest / ".p.txt") == str(cz.src / "dot_p.txt")


def test_mode_symlink_after_file_apply_reports_modification(cz):
    """Switching modes makes the previously applied file look modified."""
    cz.add("dot_plain.txt", "hello\n")
    assert cz.apply("--no-tty").returncode == 0
    assert (cz.dest / ".plain.txt").is_file()
    status = cz.run("--mode", "symlink", "status")
    # CATCHES: the regular file written by the default mode does not satisfy
    # the symlink target state, so status reports " M" and verify fails.
    assert status.returncode == 0
    assert status.stdout == " M .plain.txt\n"
    assert cz.run("--mode", "symlink", "verify").returncode == 1
    assert cz.run("--mode", "symlink", "apply", "--no-tty").returncode == 0
    fixed = cz.run("--mode", "symlink", "status")
    assert fixed.returncode == 0
    assert fixed.stdout == ""


def test_mode_symlink_empty_source_file_removes_destination(cz):
    """In symlink mode an empty source file targets an absent entry."""
    cz.add("dot_empty.txt", "")
    cz.write_dest(".empty.txt", "stale\n")
    status = cz.run("--mode", "symlink", "status")
    # CATCHES: empty contents make the symlink-mode target state absent, so
    # the existing destination file is reported as " D" and then deleted.
    assert status.returncode == 0
    assert status.stdout == " D .empty.txt\n"
    diff = cz.run("--mode", "symlink", "diff", "--no-pager")
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.empty.txt b/.empty.txt\n"
        "deleted file mode 100644\n"
        "index 8427fc236f921196257ed1c20f6e4d195240063f..0000000000000000000000000000000000000000\n"
        "--- a/.empty.txt\n"
        "+++ /dev/null\n"
        "@@ -1 +0,0 @@\n"
        "-stale\n"
    )
    assert cz.run("--mode", "symlink", "apply", "--no-tty").returncode == 0
    assert not (cz.dest / ".empty.txt").exists()
    # CATCHES: with the file gone the absent target verifies clean.
    assert cz.run("--mode", "symlink", "verify").returncode == 0


def test_mode_invalid_value_is_rejected(cz):
    """``--mode`` only accepts file or symlink; there is no shorthand."""
    cz.add("dot_a.txt", "a\n")
    proc = cz.run("--mode", "bogus", "status")
    # CATCHES: an invalid mode fails at flag parsing time with the checker's
    # own "invalid mode" text embedded in cobra's argument error.
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'chezmoi: invalid argument "bogus" for "--mode" flag: invalid mode: bogus\n'
    )
    shorthand = cz.run("status", "-m", "symlink")
    # CATCHES: no -m shorthand exists for --mode.
    assert shorthand.returncode == 1
    assert shorthand.stderr == "chezmoi: unknown shorthand flag: 'm' in -m\n"


def test_mode_file_flag_matches_default(cz):
    """``--mode file`` is an explicit no-op equal to the default behavior."""
    cz.add("dot_plain.txt", "hello\n")
    proc = cz.run("--mode", "file", "apply", "--no-tty")
    assert proc.returncode == 0
    plain = cz.dest / ".plain.txt"
    # CATCHES: the explicit file mode writes a regular file with the source
    # contents, exactly like the default.
    assert plain.is_file()
    assert not plain.is_symlink()
    assert cz.read_dest(".plain.txt") == "hello\n"


def test_mode_config_option(cz, tmp_path):
    """The ``mode`` config option selects the mode; invalid values pass through."""
    symlink_cz = Chezmoi(tmp_path / "sym", config='mode = "symlink"\n')
    symlink_cz.add("dot_p.txt", "hello\n")
    proc = symlink_cz.apply("--no-tty")
    # CATCHES: mode = "symlink" in the config file has the same effect as the
    # --mode symlink flag.
    assert proc.returncode == 0
    assert (symlink_cz.dest / ".p.txt").is_symlink()
    assert os.readlink(symlink_cz.dest / ".p.txt") == str(symlink_cz.src / "dot_p.txt")
    bogus_cz = Chezmoi(tmp_path / "bogus", config='mode = "bogus"\n')
    bogus_cz.add("dot_p.txt", "hello\n")
    bogus = bogus_cz.apply("--no-tty")
    # CATCHES: unlike the flag, the config value is not validated: an unknown
    # mode string is silently treated as the default file mode.
    assert bogus.returncode == 0
    assert bogus.stderr == ""
    assert (bogus_cz.dest / ".p.txt").is_file()
    assert not (bogus_cz.dest / ".p.txt").is_symlink()
