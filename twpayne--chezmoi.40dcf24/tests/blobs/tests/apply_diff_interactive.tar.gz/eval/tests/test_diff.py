"""Tests for ``chezmoi diff``: builtin git diff, external tools, pager, textconv."""

import os
import re

import pytest

from conftest import Chezmoi, script


@pytest.fixture()
def cz(tmp_path):
    return Chezmoi(tmp_path)


def test_diff_new_file(cz):
    """A pending file diffs against /dev/null like git would."""
    cz.add("dot_file.txt", "hello\n")
    proc = cz.diff()
    # CATCHES: the builtin diff prints git's exact unified format including
    # the blob hash of the new contents and "new file mode 100644".
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..ce013625030ba8dba906f756967f9e9ca394464a\n"
        "--- /dev/null\n"
        "+++ b/.file.txt\n"
        "@@ -0,0 +1 @@\n"
        "+hello\n"
    )
    assert proc.stderr == ""


def test_diff_modified_file(cz):
    """A modified destination file diffs destination -> target."""
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "changed\n")
    proc = cz.diff()
    # CATCHES: the minus side is the destination contents and the plus side
    # is the target state, with a two-way index line of both blob hashes.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "index 5ea2ed416fbd4a4cbe227b75fe255dd7fa6bd4d6..ce013625030ba8dba906f756967f9e9ca394464a 100644\n"
        "--- a/.file.txt\n"
        "+++ b/.file.txt\n"
        "@@ -1 +1 @@\n"
        "-changed\n"
        "+hello\n"
    )


def test_diff_reverse_flips_sides(cz):
    """``--reverse`` swaps the from/to sides of the diff."""
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "changed\n")
    proc = cz.diff("--reverse")
    # CATCHES: --reverse exchanges both the index hashes and the +/- lines so
    # the diff reads target -> destination.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "index ce013625030ba8dba906f756967f9e9ca394464a..5ea2ed416fbd4a4cbe227b75fe255dd7fa6bd4d6 100644\n"
        "--- a/.file.txt\n"
        "+++ b/.file.txt\n"
        "@@ -1 +1 @@\n"
        "-hello\n"
        "+changed\n"
    )


def test_diff_deleted_destination_shows_recreation(cz):
    """A file deleted from the destination diffs as a new file."""
    cz.add("dot_file.txt", "hello\n")
    cz.apply("--no-tty")
    (cz.dest / ".file.txt").unlink()
    proc = cz.diff()
    # CATCHES: deleting the destination file makes the diff identical to the
    # never-applied case: creation from /dev/null with full contents.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..ce013625030ba8dba906f756967f9e9ca394464a\n"
        "--- /dev/null\n"
        "+++ b/.file.txt\n"
        "@@ -0,0 +1 @@\n"
        "+hello\n"
    )


def test_diff_pre_existing_file(cz):
    """A pre-existing unmanaged destination file diffs against its contents."""
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "pre\n")
    proc = cz.diff()
    # CATCHES: the pre-existing destination contents become the minus side
    # even though chezmoi never wrote that file.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "index ecca61d996a1db3eaad55e9f061f4e76a0983d47..ce013625030ba8dba906f756967f9e9ca394464a 100644\n"
        "--- a/.file.txt\n"
        "+++ b/.file.txt\n"
        "@@ -1 +1 @@\n"
        "-pre\n"
        "+hello\n"
    )


def test_diff_script_contents_default_on_and_flag_off(cz):
    """Pending scripts diff with their contents shown by default."""
    cz.add("run_once_hello.sh", "#!/bin/sh\necho hi\n")
    default = cz.diff()
    # CATCHES: this build shows script contents in diffs by default (mode
    # 100755 and the script text as added lines).
    assert default.returncode == 0
    assert default.stdout == (
        "diff --git a/hello.sh b/hello.sh\n"
        "new file mode 100755\n"
        "index 0000000000000000000000000000000000000000..4163036efa65bd4a469e752267498f01ea36a55c\n"
        "--- /dev/null\n"
        "+++ b/hello.sh\n"
        "@@ -0,0 +1,2 @@\n"
        "+#!/bin/sh\n"
        "+echo hi\n"
    )
    suppressed = cz.diff("--script-contents=false")
    # CATCHES: --script-contents=false replaces the contents with the empty
    # blob hash (e69de29...) and drops the hunk entirely.
    assert suppressed.returncode == 0
    assert suppressed.stdout == (
        "diff --git a/hello.sh b/hello.sh\n"
        "new file mode 100755\n"
        "index 0000000000000000000000000000000000000000..e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\n"
        "--- /dev/null\n"
        "+++ b/hello.sh\n"
    )


def test_diff_modified_symlink(cz):
    """A symlink pointing at the wrong target produces a double patch."""
    cz.add("symlink_dot_link", "target-file\n")
    os.symlink("wrong-target", cz.dest / ".link")
    proc = cz.diff()
    # CATCHES: a wrong symlink is rendered as a deletion patch for the old
    # link followed by a mode+content patch for the new link.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.link b/.link\n"
        "deleted file mode 120777\n"
        "index 9a43a8a36de3ea4cbac2f1281bf57d30fa96ab17..0000000000000000000000000000000000000000\n"
        "--- a/.link\n"
        "+++ /dev/null\n"
        "@@ -1 +0,0 @@\n"
        "-wrong-target\n"
        "diff --git a/.link b/.link\n"
        "old mode 120777\n"
        "new mode 120000\n"
        "index 9a43a8a36de3ea4cbac2f1281bf57d30fa96ab17..b9969fd17deccdee24270fae0cf5c1adc8b99f72\n"
        "--- a/.link\n"
        "+++ b/.link\n"
        "@@ -1 +1 @@\n"
        "-wrong-target\n"
        "+target-file\n"
    )


def test_diff_target_subset(cz):
    """Target arguments restrict the diff to the named entry."""
    cz.add("dot_a.txt", "a\n")
    cz.add("dot_b.txt", "b\n")
    proc = cz.diff(cz.dest / ".b.txt")
    # CATCHES: diff with a target argument shows only that target's patch.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.b.txt b/.b.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..61780798228d17af2d34fce4cfbdf35556832472\n"
        "--- /dev/null\n"
        "+++ b/.b.txt\n"
        "@@ -0,0 +1 @@\n"
        "+b\n"
    )


def test_diff_external_command_invocation_and_output(cz, tmp_path):
    """``diff.command`` receives the destination file and a temp copy."""
    log = tmp_path / "difflog"
    logger = script(
        tmp_path / "difflogger.sh",
        "#!/bin/sh\n"
        f'printf "ARG1=%s\\nARG2=%s\\n" "$1" "$2" >> {log}\n'
        'echo "external diff ran"\n',
    )
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{logger}"\n')
    proc = cz.run("diff", "--no-pager")
    # CATCHES: the external diff tool is invoked as `command <dest> <temp>`
    # where the temp file lives in a chezmoi-diff directory with the same
    # basename, and its stdout becomes chezmoi's diff output verbatim.
    assert proc.returncode == 0
    assert proc.stdout == "external diff ran\n"
    log_text = log.read_text()
    arg1, arg2 = log_text.splitlines()
    assert arg1 == f"ARG1={cz.dest}/.file.txt"
    assert re.fullmatch(r"ARG2=\S*chezmoi-diff\d+/.file\.txt", arg2), log_text


def test_diff_external_command_used_by_verbose_apply(cz, tmp_path):
    """``apply -v`` routes its diff output through diff.command too."""
    logger = script(
        tmp_path / "mydiff.sh",
        '#!/bin/sh\necho "verbose-external-diff"\n',
    )
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{logger}"\n')
    proc = cz.apply("--no-tty", "-v")
    # CATCHES: verbose apply shares the diff system with the diff command, so
    # a configured external diff command is used there as well.
    assert proc.returncode == 0
    assert proc.stdout == "verbose-external-diff\n"
    assert cz.read_dest(".file.txt") == "hello\n"


def test_diff_use_builtin_diff_overrides_command(cz, tmp_path):
    """``--use-builtin-diff`` bypasses a configured diff.command."""
    logger = script(
        tmp_path / "mydiff.sh",
        '#!/bin/sh\necho "external-diff-output"\n',
    )
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{logger}"\n')
    proc = cz.run("diff", "--no-pager", "--use-builtin-diff")
    # CATCHES: --use-builtin-diff forces the builtin git diff even when the
    # config file sets diff.command, producing the unified patch instead.
    assert proc.returncode == 0
    assert proc.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "index cc628ccd10742baea8241c5924df992b5c019f71..ce013625030ba8dba906f756967f9e9ca394464a 100644\n"
        "--- a/.file.txt\n"
        "+++ b/.file.txt\n"
        "@@ -1 +1 @@\n"
        "-world\n"
        "+hello\n"
    )


def test_diff_pager_receives_diff_with_less_frx_env(cz, tmp_path):
    """A configured pager gets the diff on stdin with LESS=FRX and LV=-c."""
    log = tmp_path / "pagerlog"
    pager = script(
        tmp_path / "pager.sh",
        "#!/bin/sh\n"
        f'printf "ARGS=%s LESS=%s LV=%s\\n" "$*" "$LESS" "$LV" > {log}\n'
        f"cat >> {log}\n",
    )
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.pager = "{pager}"\n')
    proc = cz.run("diff")
    # CATCHES: the pager is spawned with no arguments, with LESS=FRX and
    # LV=-c in its environment, and the diff is piped to its stdin while
    # chezmoi's own stdout stays empty.
    assert proc.returncode == 0
    assert proc.stdout == ""
    log_text = log.read_text()
    header, *patch = log_text.split("\n", 1)
    assert header == "ARGS= LESS=FRX LV=-c"
    assert patch[0] == (
        "diff --git a/.file.txt b/.file.txt\n"
        "index cc628ccd10742baea8241c5924df992b5c019f71..ce013625030ba8dba906f756967f9e9ca394464a 100644\n"
        "--- a/.file.txt\n"
        "+++ b/.file.txt\n"
        "@@ -1 +1 @@\n"
        "-world\n"
        "+hello\n"
    )


def test_diff_pager_flag_and_no_pager_override(cz, tmp_path):
    """``--pager`` overrides config; ``--no-pager`` bypasses both."""
    log = tmp_path / "pagerlog"
    pager = script(
        tmp_path / "pager.sh",
        "#!/bin/sh\n"
        f'printf "PAGER-RAN\\n" > {log}\n'
        "cat > /dev/null\n",
    )
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    proc = cz.run("diff", "--pager", pager)
    # CATCHES: --pager takes precedence over the default pager selection and
    # the diff still does not leak to stdout.
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert log.read_text() == "PAGER-RAN\n"
    no_pager = cz.run("diff", "--pager", pager, "--no-pager")
    # CATCHES: --no-pager wins over --pager and prints the diff directly.
    assert no_pager.returncode == 0
    assert no_pager.stdout.startswith("diff --git a/.file.txt b/.file.txt\n")
    assert "-world\n+hello\n" in no_pager.stdout
    env_pager = cz.run("diff", env={"PAGER": str(pager)})
    # CATCHES: when no pager is configured, the PAGER environment variable is
    # used, so the diff goes to the pager and stdout stays empty.
    assert env_pager.returncode == 0
    assert env_pager.stdout == ""
    assert log.read_text() == "PAGER-RAN\n"


def test_diff_textconv_converts_both_sides(cz):
    """A matching textConv filter converts both diff sides before comparing."""
    cz.add("doc.md", "hello\n")
    cz.write_dest("doc.md", "HELLO\n")
    cz.set_config('textConv = [{ pattern = "**/*.md", command = "tr", args = ["a-z", "A-Z"] }]\n')
    proc = cz.diff()
    # CATCHES: textConv patterns match the absolute destination path (hence
    # **/*.md), the filter runs on both sides, and equal converted contents
    # collapse the patch to just the "diff --git" header line.
    assert proc.returncode == 0
    assert proc.stdout == "diff --git a/doc.md b/doc.md\n"
    # Status and verify do NOT use textconv: the file still counts as
    # modified and verify still fails.
    assert cz.status().stdout == " M doc.md\n"
    assert cz.verify().returncode == 1


def test_diff_textconv_failing_command_is_an_error(cz):
    """A textConv command that exits non-zero aborts the diff."""
    cz.add("doc.md", "hello\n")
    cz.write_dest("doc.md", "HELLO\n")
    cz.set_config('textConv = [{ pattern = "**/*.md", command = "false" }]\n')
    proc = cz.diff()
    # CATCHES: the exit status of the textConv command is wrapped in a
    # chezmoi error naming the target, and the diff exits 1 with no patch.
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "chezmoi: doc.md: exit status 1\n"


def test_diff_root_destination_arg_is_not_managed(cz):
    """Passing the destination root itself as a target is an error."""
    cz.add("dot_a.txt", "a\n")
    proc = cz.diff("-r", cz.dest)
    # CATCHES: the destination directory itself is not a managed entry, so it
    # must be rejected with "not managed" rather than diffing everything.
    assert proc.returncode == 1
    assert proc.stderr == f"chezmoi: {cz.dest}: not managed\n"


# --------------------------------------------------------------------------
# external diff tool (diff.command) internals
# --------------------------------------------------------------------------


def argv_logger(tmp_path, extra=""):
    """An external diff tool that logs its argv (plus ``extra`` shell code).

    The generated script exposes the log file as ``$LOG`` so ``extra`` lines
    can append to it too.
    """
    log = tmp_path / "difflog"
    body = (
        "#!/bin/sh\n"
        f"LOG={log}\n"
        'printf "ARGS:" >> "$LOG"\n'
        'for a in "$@"; do printf " [%s]" "$a" >> "$LOG"; done\n'
        'printf "\\n" >> "$LOG"\n' + extra
    )
    return log, script(tmp_path / "difflogger.sh", body)


def test_diff_external_command_new_directory(cz, tmp_path):
    """A pending directory is itself diffed before the file inside it."""
    log, logger = argv_logger(tmp_path)
    cz.add("sub/dot_b.txt", "b\n")
    cz.set_config(f'diff.command = "{logger}"\n')
    proc = cz.run("diff", "--no-pager")
    # CATCHES: the external tool is invoked once for the directory (created
    # under the temp root, /dev/null as the "from" side) and once for the file,
    # and both invocations share the same chezmoi-diff temp directory.
    assert proc.returncode == 0
    assert proc.stdout == ""
    lines = log.read_text().splitlines()
    assert len(lines) == 2
    match0 = re.fullmatch(r"ARGS: \[/dev/null\] \[(\S*chezmoi-diff\d+)/sub\]", lines[0])
    match1 = re.fullmatch(r"ARGS: \[/dev/null\] \[(\S*chezmoi-diff\d+)/sub/\.b\.txt\]", lines[1])
    assert match0 and match1
    assert match0.group(1) == match1.group(1)


def test_diff_external_command_removal_uses_devnull_target(cz, tmp_path):
    """A target whose state is absent diffs the destination against /dev/null."""
    log, logger = argv_logger(tmp_path)
    cz.add("dot_gone.txt", "")
    cz.write_dest(".gone.txt", "stale\n")
    cz.set_config(f'diff.command = "{logger}"\n')
    proc = cz.run("diff", "--no-pager")
    # CATCHES: for a removal the destination path is the first argument and
    # /dev/null the second, mirroring git's deleted-file convention.
    assert proc.returncode == 0
    assert log.read_text().splitlines() == [f"ARGS: [{cz.dest}/.gone.txt] [/dev/null]"]


def test_diff_external_command_script_writes_temp_script(cz, tmp_path):
    """Pending scripts are diffed from a temp copy of their contents."""
    log, logger = argv_logger(
        tmp_path,
        extra=(
            'printf "CONTENTS:" >> "$LOG"\n'
            'cat "$2" >> "$LOG"\n'
            'printf "\\n---\\n" >> "$LOG"\n'
        ),
    )
    cz.add("run_once_hello.sh", "#!/bin/sh\necho hi\n")
    cz.set_config(f'diff.command = "{logger}"\n')
    proc = cz.run("diff", "--no-pager")
    # CATCHES: the script is materialized in the temp directory under its
    # script name and the tool receives it as the "to" side with /dev/null as
    # the "from" side; the temp copy holds the real script text.
    assert proc.returncode == 0
    text = log.read_text()
    header, *rest = text.split("\n", 1)
    assert re.fullmatch(r"ARGS: \[/dev/null\] \[\S*chezmoi-diff\d+/hello\.sh\]", header)
    assert rest[0] == "CONTENTS:#!/bin/sh\necho hi\n\n---\n"
    log.unlink()
    suppressed = cz.run("diff", "--no-pager", "--script-contents=false")
    # CATCHES: --script-contents=false still invokes the tool on the script's
    # temp path but writes an empty file there.
    assert suppressed.returncode == 0
    text = log.read_text()
    header, *rest = text.split("\n", 1)
    assert re.fullmatch(r"ARGS: \[/dev/null\] \[\S*chezmoi-diff\d+/hello\.sh\]", header)
    assert rest[0] == "CONTENTS:\n---\n"


def test_diff_external_command_reverse_swaps_arguments(cz, tmp_path):
    """``--reverse`` swaps the two paths handed to the external tool."""
    log, logger = argv_logger(tmp_path)
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{logger}"\n')
    proc = cz.run("diff", "--no-pager", "--reverse")
    # CATCHES: with --reverse the temp copy of the target state becomes the
    # first argument and the destination file the second.
    assert proc.returncode == 0
    [line] = log.read_text().splitlines()
    assert re.fullmatch(
        rf"ARGS: \[\S*chezmoi-diff\d+/\.file\.txt\] \[{re.escape(str(cz.dest))}/\.file\.txt\]",
        line,
    )


def test_diff_external_command_plain_args_get_paths_appended(cz, tmp_path):
    """Plain ``diff.args`` are prepended and both paths appended."""
    log, logger = argv_logger(tmp_path)
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{logger}"\ndiff.args = ["-u"]\n')
    proc = cz.run("diff", "--no-pager")
    # CATCHES: args without templates keep the pre-2.1.5 behavior: the
    # configured args come first and the destination and temp paths are
    # appended after them.
    assert proc.returncode == 0
    [line] = log.read_text().splitlines()
    assert re.fullmatch(
        rf"ARGS: \[-u\] \[{re.escape(str(cz.dest))}/\.file\.txt\] \[\S*chezmoi-diff\d+/\.file\.txt\]",
        line,
    )


def test_diff_external_command_template_args_suppress_paths(cz, tmp_path):
    """Template ``diff.args`` receive the paths but stop them being appended."""
    log, logger = argv_logger(tmp_path)
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{logger}"\ndiff.args = ["X{{{{ .Destination }}}}"]\n')
    proc = cz.run("diff", "--no-pager")
    # CATCHES: an arg that changes when executed as a template marks the whole
    # arg list as templates, so chezmoi no longer appends the two paths; the
    # tool receives exactly the one expanded argument.
    assert proc.returncode == 0
    assert log.read_text().splitlines() == [f"ARGS: [X{cz.dest}/.file.txt]"]


def test_diff_external_command_exit_status_one_is_swallowed(cz, tmp_path):
    """Exit status 1 of the tool is not an error when the entries differ."""
    failer = script(
        tmp_path / "fail1.sh",
        '#!/bin/sh\necho "tool-output"\nexit 1\n',
    )
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{failer}"\n')
    proc = cz.run("diff", "--no-pager")
    # CATCHES: diff tools conventionally exit 1 when files differ, so chezmoi
    # swallows exactly exit status 1 and passes the tool's output through.
    assert proc.returncode == 0
    assert proc.stdout == "tool-output\n"
    assert proc.stderr == ""


def test_diff_external_command_exit_status_two_is_an_error(cz, tmp_path):
    """Exit statuses other than 1 abort the diff with the target's error."""
    failer = script(
        tmp_path / "fail2.sh",
        '#!/bin/sh\necho "tool-output"\nexit 2\n',
    )
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{failer}"\n')
    proc = cz.run("diff", "--no-pager")
    # CATCHES: only status 1 is special-cased; status 2 surfaces as an error
    # naming the target, after the tool's output was already printed.
    assert proc.returncode == 1
    assert proc.stdout == "tool-output\n"
    assert proc.stderr == "chezmoi: .file.txt: exit status 2\n"


def test_diff_external_command_symlink_write_not_diffed(cz, tmp_path):
    """Symlink creation is not routed through the external diff tool."""
    log, logger = argv_logger(tmp_path)
    cz.add("symlink_dot_link", "target-file\n")
    cz.set_config(f'diff.command = "{logger}"\n')
    created = cz.run("diff", "--no-pager")
    # CATCHES: writing a new symlink never invokes the external tool (only
    # file, directory, removal and script operations are diffed).
    assert created.returncode == 0
    assert created.stdout == ""
    assert not log.exists()
    os.symlink("wrong-target", cz.dest / ".link")
    replaced = cz.run("diff", "--no-pager")
    # CATCHES: replacing an existing wrong link diffs only its removal, so the
    # tool sees the destination link and /dev/null and nothing else.
    assert replaced.returncode == 0
    assert log.read_text().splitlines() == [f"ARGS: [{cz.dest}/.link] [/dev/null]"]


def test_diff_external_command_textconv_converted_temp_copies(cz, tmp_path):
    """textConv copies both sides into ``a/`` and ``b/`` under the temp root."""
    log, logger = argv_logger(
        tmp_path,
        extra=(
            'printf "FROM:" >> "$LOG"; cat "$1" >> "$LOG"\n'
            'printf "TO:" >> "$LOG"; cat "$2" >> "$LOG"\n'
        ),
    )
    cz.add("doc.md", "hELLO\n")
    cz.write_dest("doc.md", "Hello\n")
    cz.set_config(
        f'diff.command = "{logger}"\n'
        'textConv = [{ pattern = "**/*.md", command = "tr", args = ["a-z", "A-Z"] }]\n'
    )
    proc = cz.run("diff", "--no-pager")
    # CATCHES: with a matching filter the destination copy is converted into
    # <temp>/a/<name> and the target into <temp>/b/<name>, and both hold the
    # converted bytes (so case-only differences vanish for the tool).
    assert proc.returncode == 0
    text = log.read_text()
    header, *rest = text.split("\n", 1)
    assert re.fullmatch(
        r"ARGS: \[(\S*chezmoi-diff\d+)/a/doc\.md\] \[\1/b/doc\.md\]", header
    )
    assert rest[0] == "FROM:HELLO\nTO:HELLO\n"


def test_diff_external_command_output_piped_to_pager(cz, tmp_path):
    """The external tool's output is piped through the configured pager."""
    logger = script(
        tmp_path / "difflogger.sh",
        '#!/bin/sh\necho "external-diff-line"\n',
    )
    pagerout = tmp_path / "pagerout"
    pager = script(
        tmp_path / "pager.sh",
        "#!/bin/sh\n"
        f"OUT={pagerout}\n"
        'cat > "$OUT"\n'
        'printf "LESS=%s LV=%s\\n" "$LESS" "$LV" >> "$OUT"\n',
    )
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "world\n")
    cz.set_config(f'diff.command = "{logger}"\ndiff.pager = "{pager}"\n')
    proc = cz.run("diff")
    # CATCHES: with a pager configured the tool writes to a pipe feeding the
    # pager (not to chezmoi's stdout), and the pager runs with LESS=FRX LV=-c.
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert pagerout.read_text() == "external-diff-line\nLESS=FRX LV=-c\n"


def test_diff_mode_only_change_builtin_vs_external(cz, tmp_path):
    """A pure permission change is shown by the builtin diff only."""
    log, logger = argv_logger(tmp_path)
    cz.add("dot_file.txt", "hello\n")
    cz.write_dest(".file.txt", "hello\n")
    (cz.dest / ".file.txt").chmod(0o600)
    builtin = cz.diff("--use-builtin-diff")
    # CATCHES: equal contents with a different mode produce a mode-only patch
    # (no index line, no hunk) and the entry still counts as modified.
    assert builtin.returncode == 0
    assert builtin.stdout == (
        "diff --git a/.file.txt b/.file.txt\n"
        "old mode 100600\n"
        "new mode 100644\n"
    )
    assert cz.status().stdout == " M .file.txt\n"
    assert cz.verify().returncode == 1
    cz.set_config(f'diff.command = "{logger}"\n')
    external = cz.run("diff", "--no-pager")
    # CATCHES: the external tool is never invoked for a mode-only change
    # (chmods are not routed through diff.command) and nothing is printed.
    assert external.returncode == 0
    assert external.stdout == ""
    assert not log.exists()


def test_diff_init_renders_config_template_as_diff(cz):
    """``diff --init`` shows the would-be config file as a diff, unwritten."""
    cz.add(".chezmoi.toml.tmpl", 'data = { s = "{{ promptString "Name" "root" }}" }\n')
    cz.add("dot_n.tmpl", "{{ .s }}\n")
    cz.config_file = cz.dest / "chezmoi.toml"
    proc = cz.run("--no-tty", "diff", "--no-pager", "--init", input="diffuser\n")
    # CATCHES: --init prompts for the config template, then the diff system
    # renders the config file it *would* write (mode 0600, inside the
    # destination) along with the destination directory mode change and the
    # regular entries, while writing nothing at all.
    assert proc.returncode == 0
    assert proc.stdout == (
        'Name (default "root")? '
        "diff --git a/ b/\n"
        "old mode 40755\n"
        "new mode 40777\n"
        "diff --git a/chezmoi.toml b/chezmoi.toml\n"
        "new file mode 100600\n"
        "index 0000000000000000000000000000000000000000..be75e5babf575b1eb84cc75990f2e34805e00bd5\n"
        "--- /dev/null\n"
        "+++ b/chezmoi.toml\n"
        "@@ -0,0 +1 @@\n"
        '+data = { s = "diffuser" }\n'
        "diff --git a/.n b/.n\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..b994be4a75e901ab8f941243ecba3e4ffcf6c741\n"
        "--- /dev/null\n"
        "+++ b/.n\n"
        "@@ -0,0 +1 @@\n"
        "+diffuser\n"
    )
    assert proc.stderr == ""
    assert not cz.config_file.exists()
    assert not (cz.dest / ".n").exists()


def test_diff_init_with_config_outside_dest_panics(cz):
    """``diff --init`` with the config outside the destination crashes."""
    cz.add(".chezmoi.toml.tmpl", 'data = { s = "{{ promptString "Name" "root" }}" }\n')
    proc = cz.run("--no-tty", "diff", "--no-pager", "--init", input="diffuser\n")
    # CATCHES: recreating the config makes the diff system mkdir the config
    # file's directory; because that directory is outside the destination
    # directory the reference aborts with a Go panic (exit code 2) after the
    # prompt was already printed.
    assert proc.returncode == 2
    assert proc.stdout == 'Name (default "root")? '
    assert proc.stderr.splitlines()[0] == f"panic: {cz.root}: not in {cz.dest}"
