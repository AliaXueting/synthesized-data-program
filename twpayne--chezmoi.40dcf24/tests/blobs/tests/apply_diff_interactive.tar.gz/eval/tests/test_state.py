"""Tests for ``chezmoi state`` and the bbolt-backed persistent state."""

import fcntl
import hashlib
import json

import pytest

from conftest import Chezmoi


@pytest.fixture()
def cz(tmp_path):
    return Chezmoi(tmp_path)


def test_state_set_get_roundtrip(cz):
    """``state set`` stores raw bytes; ``state get`` returns them verbatim."""
    missing = cz.state("get", "--bucket", "b", "--key", "k")
    # CATCHES: reading a missing key (or missing database) is not an error:
    # exit 0 with completely empty output, not even a newline.
    assert missing.returncode == 0
    assert missing.stdout == ""
    assert missing.stderr == ""
    set_proc = cz.state("set", "--bucket", "mybucket", "--key", "mykey", "--value", "myvalue")
    assert set_proc.returncode == 0
    assert set_proc.stdout == ""
    assert set_proc.stderr == ""
    # CATCHES: the database file is created next to the config file and get
    # prints the value without appending a newline.
    assert cz.state_file.is_file()
    got = cz.state("get", "--bucket", "mybucket", "--key", "mykey")
    assert got.returncode == 0
    assert got.stdout == "myvalue"
    absent = cz.state("get", "--bucket", "mybucket", "--key", "nope")
    assert absent.returncode == 0
    assert absent.stdout == ""


def test_state_delete_and_delete_bucket(cz):
    """``state delete`` removes one key; ``delete-bucket`` removes them all."""
    cz.state("set", "--bucket", "b", "--key", "k1", "--value", "v1")
    cz.state("set", "--bucket", "b", "--key", "k2", "--value", "v2")
    deleted = cz.state("delete", "--bucket", "b", "--key", "k1")
    # CATCHES: deleting state entries is silent and succeeds even though the
    # remaining key is untouched.
    assert deleted.returncode == 0
    assert deleted.stdout == ""
    assert cz.state("get", "--bucket", "b", "--key", "k1").stdout == ""
    assert cz.state("get", "--bucket", "b", "--key", "k2").stdout == "v2"
    bucket_gone = cz.state("delete-bucket", "--bucket", "b")
    assert bucket_gone.returncode == 0
    assert cz.state("get", "--bucket", "b", "--key", "k2").stdout == ""


def test_state_get_bucket_parses_json_values(cz):
    """``get-bucket`` re-marshals values that are valid JSON."""
    cz.state("set", "--bucket", "jb", "--key", "k1", "--value", '{"a": 1}')
    proc = cz.state("get-bucket", "--bucket", "jb")
    # CATCHES: get-bucket decodes each value as JSON and pretty-prints the
    # bucket as an object, sorted by key.
    assert proc.returncode == 0
    assert proc.stdout == '{\n  "k1": {\n    "a": 1\n  }\n}\n'
    as_yaml = cz.state("get-bucket", "--bucket", "jb", "--format", "yaml")
    assert as_yaml.returncode == 0
    assert as_yaml.stdout == "k1:\n  a: 1\n"


def test_state_get_bucket_rejects_non_json_values(cz):
    """A non-JSON value makes get-bucket fail with the JSON decode error."""
    cz.state("set", "--bucket", "mybucket", "--key", "mykey", "--value", "myvalue")
    proc = cz.state("get-bucket", "--bucket", "mybucket")
    # CATCHES: get-bucket blindly json.Unmarshals values, so a plain string
    # value surfaces Go's decoding error and exit code 1.
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == "chezmoi: invalid character 'm' looking for beginning of value\n"


def test_state_data_shows_raw_buckets(cz):
    """``state data`` dumps only existing buckets with raw string values."""
    cz.state("set", "--bucket", "mybucket", "--key", "mykey", "--value", "myvalue")
    cz.state("set", "--bucket", "mybucket", "--key", "zzz", "--value", "42")
    proc = cz.state("data", "--format", "yaml")
    # CATCHES: raw data keeps values as strings (note the quoted "42") and
    # omits buckets that were never created, unlike state dump.
    assert proc.returncode == 0
    assert proc.stdout == 'mybucket:\n  mykey: myvalue\n  zzz: "42"\n'


def test_state_dump_lists_all_buckets_in_json(cz):
    """``state dump`` reports every well-known bucket, existing or not."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    proc = cz.state("dump")
    # CATCHES: dump always lists the ten well-known buckets (even empty ones)
    # with entryState keys being absolute destination paths and modes in
    # decimal (420 = 0644).
    assert proc.returncode == 0
    data = json.loads(proc.stdout)
    assert set(data) == {
        "configState", "entryState", "gitHubKeysState", "gitHubLatestReleaseState",
        "gitHubReleasesState", "gitHubTagsState", "gitHubVersionReleaseState",
        "gitRepoExternalState", "scriptState",
    }
    assert data["entryState"] == {
        f"{cz.dest}/.a.txt": {
            "contentsSHA256": "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7",
            "mode": 420,
            "type": "file",
        }
    }
    assert data["scriptState"] == {}


def test_state_dump_yaml_format(cz):
    """``state dump --format yaml`` mirrors the JSON dump in YAML."""
    proc = cz.state("dump", "--format", "yaml")
    # CATCHES: the yaml output uses the same bucket names with empty-mapping
    # syntax and is accepted before any state exists.
    assert proc.returncode == 0
    assert proc.stdout == (
        "configState: {}\n"
        "entryState: {}\n"
        "gitHubKeysState: {}\n"
        "gitHubLatestReleaseState: {}\n"
        "gitHubReleasesState: {}\n"
        "gitHubTagsState: {}\n"
        "gitHubVersionReleaseState: {}\n"
        "gitRepoExternalState: {}\n"
        "scriptState: {}\n"
    )


def test_state_invalid_format_flag(cz):
    """An unknown --format value is rejected at flag parsing time."""
    proc = cz.state("dump", "--format", "xml")
    # CATCHES: only json and yaml are valid formats; the error names the flag
    # and the rejected value.
    assert proc.returncode == 1
    assert proc.stderr == 'chezmoi: invalid argument "xml" for "-f, --format" flag: invalid value\n'


def test_state_entry_state_raw_value(cz):
    """A single entry state can be fetched raw by its absolute path key."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    proc = cz.state("get", "--bucket", "entryState", "--key", f"{cz.dest}/.a.txt")
    # CATCHES: the stored value is the JSON encoding of the entry state with
    # fields ordered type, mode, contentsSHA256 and a trailing newline.
    assert proc.returncode == 0
    assert proc.stdout == (
        '{\n  "type": "file",\n'
        '  "mode": 420,\n'
        '  "contentsSHA256": "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7"\n}\n'
    )


def test_state_script_state_records_run(cz):
    """A run_once script records its name under a hash key in scriptState."""
    cz.add("run_once_echo.sh", "#!/bin/sh\ntrue\n")
    cz.apply("--no-tty")
    proc = cz.state("get-bucket", "--bucket", "scriptState")
    # CATCHES: the scriptState key is the SHA-256 of the script name+contents
    # and the value holds at least the script's target name (runAt varies).
    assert proc.returncode == 0
    script_state = json.loads(proc.stdout)
    [(key, value)] = script_state.items()
    assert key == hashlib.sha256(b"#!/bin/sh\ntrue\n").hexdigest()
    assert value["name"] == "echo.sh"


def test_state_reset_prompts_in_no_tty_mode(cz):
    """``state reset`` asks yes/no/quit on stdin with --no-tty."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    assert cz.state_file.exists()
    no = cz.state("reset", "--no-tty", input="n\n")
    # CATCHES: without --force, reset prompts "Remove <path> (yes/no/quit)? "
    # on stdout and reads the answer from stdin in --no-tty mode.
    assert no.returncode == 0
    assert no.stdout == f"Remove {cz.state_file} (yes/no/quit)? "
    assert cz.state_file.exists()
    yes = cz.state("reset", "--no-tty", input="y\n")
    assert yes.returncode == 0
    assert yes.stdout == f"Remove {cz.state_file} (yes/no/quit)? "
    assert not cz.state_file.exists()
    # After the reset, chezmoi has lost the entry state, so editing the file
    # now reports " M" (never written, modified) instead of "MM".
    cz.write_dest(".a.txt", "mod\n")
    assert cz.status().stdout == " M .a.txt\n"


def test_state_reset_force_is_silent(cz):
    """``state reset --force`` deletes the database without prompting."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    dump = cz.state("dump")
    # CATCHES: the precondition is a genuinely populated database: the dump
    # must contain the entry state that apply recorded.
    assert dump.returncode == 0
    assert json.loads(dump.stdout)["entryState"] == {
        f"{cz.dest}/.a.txt": {
            "contentsSHA256": "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7",
            "mode": 420,
            "type": "file",
        }
    }
    assert cz.read_dest(".a.txt") == "a\n"
    proc = cz.state("reset", "--force")
    # CATCHES: --force skips the confirmation prompt entirely: no stdout at
    # all, exit 0, database gone.
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""
    assert not cz.state_file.exists()
    # CATCHES: dumping the now-missing database reports empty buckets and,
    # being a read-only command, does not recreate the file.
    after = cz.state("dump")
    assert after.returncode == 0
    assert json.loads(after.stdout)["entryState"] == {}
    assert not cz.state_file.exists()
    # CATCHES: with the entry state gone a matching destination file is not
    # reported by status; re-applying records the state again so that a
    # subsequent modification shows MM rather than " M".
    assert cz.status().stdout == ""
    cz.apply("--no-tty")
    cz.write_dest(".a.txt", "mod\n")
    assert cz.status().stdout == "MM .a.txt\n"


def test_state_lock_timeout_message(cz):
    """A held database lock produces the friendly timeout error."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    with open(cz.state_file, "r+") as db_file:
        fcntl.flock(db_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        locked = cz.state("dump")
        # CATCHES: when another process holds the bbolt file lock, chezmoi
        # retries for its timeout and then fails with the "is another
        # instance of chezmoi running?" message and exit 1.
        assert locked.returncode == 1
        assert locked.stdout == ""
        assert locked.stderr == (
            "chezmoi: timeout obtaining persistent state lock, "
            "is another instance of chezmoi running?\n"
        )
        fcntl.flock(db_file.fileno(), fcntl.LOCK_UN)
    unlocked = cz.state("dump")
    assert unlocked.returncode == 0
    assert json.loads(unlocked.stdout)["entryState"] != {}


def test_persistent_state_flag_relocates_database(cz, tmp_path):
    """``--persistent-state`` moves the database to a custom path."""
    cz.add("dot_a.txt", "a\n")
    custom = tmp_path / "custom.boltdb"
    proc = cz.apply("--no-tty", "--persistent-state", custom)
    # CATCHES: the custom path is used for both writing and reading state,
    # and no chezmoistate.boltdb appears next to the config file.
    assert proc.returncode == 0
    assert custom.is_file()
    assert not cz.state_file.exists()
    dump = cz.run("state", "dump", "--persistent-state", custom)
    assert dump.returncode == 0
    assert json.loads(dump.stdout)["entryState"] != {}
    # With the default (missing) state database the file counts as never
    # written by chezmoi, so a modification shows " M" rather than "MM".
    cz.write_dest(".a.txt", "mod\n")
    fresh = cz.status()
    assert fresh.returncode == 0
    assert fresh.stdout == " M .a.txt\n"


def test_read_commands_never_create_the_database(cz):
    """status/diff/verify never create chezmoistate.boltdb."""
    cz.add("dot_a.txt", "a\n")
    status = cz.status()
    # CATCHES: status really read the source state (it reports the file as
    # added) yet no database file may appear next to the config file.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n"
    assert status.stderr == ""
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stderr == ""
    assert diff.stdout == (
        "diff --git a/.a.txt b/.a.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..78981922613b2afb6025042ff6bd878ac1994e85\n"
        "--- /dev/null\n"
        "+++ b/.a.txt\n"
        "@@ -0,0 +1 @@\n"
        "+a\n"
    )
    verify = cz.verify()
    # CATCHES: verify exits 1 because the destination file is missing, but
    # stays completely silent on both streams.
    assert verify.returncode == 1
    assert verify.stdout == ""
    assert verify.stderr == ""
    # CATCHES: the read commands open the persistent state in read-only
    # mode with a mock overlay, so no database file may appear.
    assert not cz.state_file.exists()
    assert not (cz.dest / ".a.txt").exists()


def test_read_commands_and_dry_run_leave_database_unchanged(cz):
    """diff/status/dry-run copy state to a mock and never write it back."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    before = cz.state("dump").stdout
    # CATCHES: the reference point is a populated database: apply must have
    # recorded the entry state that the following commands must preserve.
    assert json.loads(before)["entryState"] == {
        f"{cz.dest}/.a.txt": {
            "contentsSHA256": "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7",
            "mode": 420,
            "type": "file",
        }
    }
    cz.write_dest(".a.txt", "mod\n")
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.a.txt b/.a.txt\n"
        "index 2680cfddbd9fa03c059ac60d2bec5e59a1c34281..78981922613b2afb6025042ff6bd878ac1994e85 100644\n"
        "--- a/.a.txt\n"
        "+++ b/.a.txt\n"
        "@@ -1 +1 @@\n"
        "-mod\n"
        "+a\n"
    )
    assert cz.status().stdout == "MM .a.txt\n"
    dry_run = cz.apply("--no-tty", "-n", "--force")
    # CATCHES: the dry-run apply would overwrite the file and update the
    # entry state, but neither happens: no output and no destination change.
    assert dry_run.returncode == 0
    assert dry_run.stdout == ""
    assert dry_run.stderr == ""
    assert cz.read_dest(".a.txt") == "mod\n"
    assert cz.status().stdout == "MM .a.txt\n"
    # CATCHES: diff, status and the dry-run apply all observed the entry
    # state through a mock, so the real database dump is byte-identical.
    assert cz.state("dump").stdout == before


def test_config_state_bucket_after_apply_init(cz):
    """``apply --init`` records the config template hash in configState."""
    template = 'data = { greeting = "{{ promptString "greeting" "hello" }}" }\n'
    cz.add(".chezmoi.toml.tmpl", template)
    cz.apply("--no-tty", "--init", input="world\n")
    proc = cz.state("get-bucket", "--bucket", "configState")
    # CATCHES: the configState bucket stores the SHA-256 hex digest of the
    # rendered-from template contents under the literal key configState.
    assert proc.returncode == 0
    expected_hash = hashlib.sha256(template.encode()).hexdigest()
    assert json.loads(proc.stdout) == {
        "configState": {"configTemplateContentsSHA256": expected_hash}
    }


def test_config_template_change_warns_until_force(cz):
    """A changed config template warns on stderr until ``--force`` re-records it."""
    cz.add(".chezmoi.toml.tmpl", 'data = { greeting = "first" }\n')
    cz.apply("--no-tty", "--init")
    cz.add(".chezmoi.toml.tmpl", 'data = { greeting = "second" }\n')
    cz.add("dot_x.txt", "x\n")
    warning = (
        "chezmoi: warning: config file template has changed, "
        "run chezmoi init to regenerate config file\n"
    )
    status = cz.status()
    # CATCHES: every command that applies the source state compares the
    # config template's hash with the configState bucket and warns on stderr
    # (not stdout) when the template changed since the config was generated.
    assert status.returncode == 0
    assert status.stdout == " A .x.txt\n"
    assert status.stderr == warning
    verify = cz.verify()
    assert verify.returncode == 1
    assert verify.stdout == ""
    assert verify.stderr == warning
    plain_apply = cz.apply("--no-tty")
    assert plain_apply.returncode == 0
    assert plain_apply.stderr == warning
    forced = cz.apply("--no-tty", "--force")
    # CATCHES: --force regenerates the recorded hash instead of warning, so
    # subsequent commands are quiet again and the bucket holds the new hash.
    assert forced.returncode == 0
    assert forced.stderr == ""
    quiet = cz.status()
    assert quiet.returncode == 0
    assert quiet.stdout == ""
    assert quiet.stderr == ""
    bucket = cz.state("get-bucket", "--bucket", "configState")
    assert bucket.returncode == 0
    new_hash = hashlib.sha256(b'data = { greeting = "second" }\n').hexdigest()
    assert json.loads(bucket.stdout) == {
        "configState": {"configTemplateContentsSHA256": new_hash}
    }


def test_dry_run_state_set_is_discarded(cz):
    """``-n state set`` writes to the in-memory mock, not the database."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    key = f"{cz.dest}/.a.txt"
    original = cz.state("get", "--bucket", "entryState", "--key", key)
    assert original.returncode == 0
    # The stored entry state is the pretty-printed JSON recorded by apply.
    assert json.loads(original.stdout)["type"] == "file"
    # A global dry-run redirects state writes into a mock overlay: the set
    # succeeds but nothing reaches chezmoistate.boltdb.
    overwritten = cz.run("-n", "state", "set", "--bucket", "entryState", "--key", key,
                         "--value", '{"type":"remove"}')
    fresh = cz.run("-n", "state", "set", "--bucket", "freshBucket", "--key", "k",
                   "--value", "{}")
    # CATCHES: both dry-run sets exit 0 silently, yet the database still
    # holds the original entry state and the new bucket was never created.
    assert overwritten.returncode == 0
    assert overwritten.stdout == ""
    assert overwritten.stderr == ""
    assert fresh.returncode == 0
    assert cz.state("get", "--bucket", "entryState", "--key", key).stdout == original.stdout
    assert json.loads(cz.state("get-bucket", "--bucket", "freshBucket").stdout) == {}
    # A real set (without -n) does change the database, proving the contrast.
    real = cz.state("set", "--bucket", "entryState", "--key", key, "--value", '{"type":"remove"}')
    assert real.returncode == 0
    assert cz.state("get", "--bucket", "entryState", "--key", key).stdout == '{"type":"remove"}'


def test_dry_run_state_delete_is_discarded(cz):
    """``-n state delete`` removes keys only from the mock overlay."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    key = f"{cz.dest}/.a.txt"
    original = cz.state("get", "--bucket", "entryState", "--key", key)
    assert json.loads(original.stdout)["type"] == "file"
    existing = cz.run("-n", "state", "delete", "--bucket", "entryState", "--key", key)
    missing = cz.run("-n", "state", "delete", "--bucket", "noSuchBucket", "--key", "k")
    # CATCHES: deleting an existing key and deleting from a bucket that does
    # not exist both exit 0 silently under -n, and the real database still
    # contains the original entry state afterwards.
    assert existing.returncode == 0
    assert existing.stdout == ""
    assert existing.stderr == ""
    assert missing.returncode == 0
    assert missing.stderr == ""
    assert cz.state("get", "--bucket", "entryState", "--key", key).stdout == original.stdout
    # A real delete removes the key, in contrast to the dry-run above.
    real = cz.state("delete", "--bucket", "entryState", "--key", key)
    assert real.returncode == 0
    assert cz.state("get", "--bucket", "entryState", "--key", key).stdout == ""


def test_dry_run_state_delete_bucket_is_discarded(cz):
    """``-n state delete-bucket`` never drops the real bucket."""
    cz.add("dot_a.txt", "a\n")
    cz.add("dot_b.txt", "b\n")
    cz.apply("--no-tty")
    bucket = json.loads(cz.state("get-bucket", "--bucket", "entryState").stdout)
    assert sorted(bucket) == [f"{cz.dest}/.a.txt", f"{cz.dest}/.b.txt"]
    dry = cz.run("-n", "state", "delete-bucket", "--bucket", "entryState")
    # CATCHES: the dry-run delete-bucket reports success, but the bucket and
    # both of its keys are still present in the database afterwards.
    assert dry.returncode == 0
    assert dry.stdout == ""
    assert dry.stderr == ""
    after = json.loads(cz.state("get-bucket", "--bucket", "entryState").stdout)
    assert after == bucket
    # The real delete-bucket empties the bucket for real.
    real = cz.state("delete-bucket", "--bucket", "entryState")
    assert real.returncode == 0
    assert json.loads(cz.state("get-bucket", "--bucket", "entryState").stdout) == {}


def test_dry_run_state_reset_leaves_database_intact(cz):
    """``-n state reset`` prompts and "succeeds" without deleting the file."""
    cz.add("dot_a.txt", "a\n")
    cz.apply("--no-tty")
    dump = json.loads(cz.state("dump").stdout)
    assert "entryState" in dump
    prompted = cz.run("-n", "--no-tty", "state", "reset", input="y\n")
    # CATCHES: reset still asks yes/no/quit in --no-tty mode under a global
    # dry-run, accepts the answer, but the removal is routed through the
    # dry-run system so the database file and its contents survive.
    assert prompted.returncode == 0
    assert prompted.stdout == f"Remove {cz.state_file} (yes/no/quit)? "
    assert prompted.stderr == ""
    assert cz.state_file.is_file()
    assert json.loads(cz.state("dump").stdout) == dump
    forced = cz.run("-n", "state", "reset", "--force")
    assert forced.returncode == 0
    assert forced.stdout == ""
    assert forced.stderr == ""
    assert cz.state_file.is_file()
    assert json.loads(cz.state("dump").stdout) == dump
    # Without the dry-run the same forced reset really deletes the file.
    cz.state("reset", "--force")
    assert not cz.state_file.exists()
