"""Tests for how the source directory is interpreted: ignore files, data
files, named templates, directory and file attributes, and the version file.
"""

import hashlib
import json
import os

import pytest

from conftest import Chezmoi


@pytest.fixture()
def cz(tmp_path):
    return Chezmoi(tmp_path)


def test_chezmoiignore_matches_target_names_not_source_names(cz):
    """``.chezmoiignore`` patterns are matched against target paths."""
    cz.add("dot_a.txt", "a\n")
    cz.add("dot_b.txt", "b\n")
    cz.add("dot_c.skip", "s\n")
    cz.add(".chezmoiignore", "# a comment\n\ndot_a.txt\n.b.txt\n*.skip\n")
    status = cz.status()
    # CATCHES: patterns match the *target* names, so ".b.txt" and "*.skip"
    # ignore their files while the source name "dot_a.txt" matches nothing.
    # Comment and blank lines are skipped.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n"
    apply_proc = cz.apply("--no-tty")
    assert apply_proc.returncode == 0
    assert apply_proc.stdout == ""
    assert (cz.dest / ".a.txt").read_text(encoding="utf-8") == "a\n"
    assert not (cz.dest / ".b.txt").exists()
    assert not (cz.dest / ".c.skip").exists()


def test_chezmoiignore_is_executed_as_a_template(cz):
    """``.chezmoiignore`` itself is a template over chezmoi's data."""
    cz.add("dot_linux.txt", "L\n")
    cz.add("dot_kept.txt", "K\n")
    cz.add(
        ".chezmoiignore",
        '{{ if eq .chezmoi.os "linux" }}.linux.txt{{ end }}\n',
    )
    status = cz.status()
    # CATCHES: the ignore file is rendered with the .chezmoi.os variable, so
    # on linux the pattern ".linux.txt" appears and the file is ignored.
    assert status.returncode == 0
    assert status.stdout == " A .kept.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert not (cz.dest / ".linux.txt").exists()
    assert (cz.dest / ".kept.txt").read_text(encoding="utf-8") == "K\n"


def test_chezmoiignore_directory_and_glob_patterns(cz):
    """Ignore patterns address single files, directories and subtrees."""
    cz.mkdir("dot_sub")
    cz.add("dot_sub/dot_a.txt", "a\n")
    cz.add("dot_sub/dot_b.txt", "b\n")
    cz.add("dot_keep.txt", "k\n")
    cz.add(".chezmoiignore", ".sub/.a.txt\n")
    single = cz.status()
    # CATCHES: ignoring ".sub/.a.txt" removes only that entry; the parent
    # directory itself is still reported as pending.
    assert single.returncode == 0
    assert single.stdout == " A .keep.txt\n A .sub\n A .sub/.b.txt\n"
    cz.add(".chezmoiignore", ".sub/**\n")
    subtree = cz.status()
    # CATCHES: the ".sub/**" glob swallows the whole subtree including the
    # directory entry, leaving only the unrelated file.
    assert subtree.returncode == 0
    assert subtree.stdout == " A .keep.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert sorted(p.name for p in cz.dest.iterdir()) == [".keep.txt"]


def test_chezmoiignore_suppresses_scripts(cz):
    """An ignored script never runs and is absent from status and diff."""
    cz.add("run_once_m.sh", "#!/bin/sh\necho hi\n")
    cz.add("dot_a.txt", "a\n")
    cz.add(".chezmoiignore", "m.sh\n")
    status = cz.status()
    # CATCHES: scripts are ignored by their script name (the leading run_ and
    # once_ attributes are stripped), so no " R m.sh" line is printed.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n"
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.a.txt b/.a.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..78981922613b2afb6025042ff6bd878ac1994e85\n"
        "--- /dev/null\n"
        "+++ b/.a.txt\n"
        "@@ -0,0 +1 @@\n"
        "+a\n"
    )
    first = cz.apply("--no-tty")
    # CATCHES: the ignored script produces no output (it never ran) and no
    # scriptState entry is recorded, so a second apply is equally silent.
    assert first.returncode == 0
    assert first.stdout == ""
    second = cz.apply("--no-tty")
    assert second.returncode == 0
    assert second.stdout == ""
    script_state = cz.state("get-bucket", "--bucket", "scriptState")
    assert script_state.returncode == 0
    assert script_state.stdout == "{}\n"


def test_chezmoidata_and_config_data_merge_into_template_data(cz):
    """``.chezmoidata`` files and config ``data`` both feed templates."""
    cz.set_config('data = { fromConfig = "cfg" }\n')
    cz.add(".chezmoidata.toml", 'fromData = "dat"\n')
    cz.add("dot_m.tmpl", "c={{ .fromConfig }} d={{ .fromData }}\n")
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: variables from the config file's data section and from the
    # .chezmoidata.toml file are merged into the same template namespace.
    assert cz.read_dest(".m") == "c=cfg d=dat\n"


def test_chezmoitemplates_provides_named_templates(cz):
    """Templates in ``.chezmoitemplates`` are callable by name."""
    cz.add(".chezmoidata.toml", 'greeting = "hi there"\n')
    cz.add(".chezmoitemplates/greet", "G={{ .greeting }}\n")
    cz.add("dot_t.tmpl", 'template "greet": {{ template "greet" . }}\n')
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: the named template is executed with the caller's data and
    # contributes its own trailing newline, and the .chezmoitemplates
    # directory itself produces no target entries.
    assert cz.read_dest(".t") == 'template "greet": G=hi there\n\n'
    assert sorted(p.name for p in cz.dest.iterdir()) == [".t"]


def test_chezmoi_builtin_template_variables(cz):
    """Built-in ``.chezmoi`` variables expose the OS and source directory."""
    cz.add("dot_os.tmpl", "os={{ .chezmoi.os }}\nsd={{ .chezmoi.sourceDir }}\n")
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: .chezmoi.os reports the operating system and .chezmoi.sourceDir
    # the absolute path of the source directory given on the command line.
    assert cz.read_dest(".os") == f"os=linux\nsd={cz.src}\n"


def test_exact_directory_removes_unmanaged_files(cz):
    """``exact_`` directories delete destination entries not in the source."""
    cz.add("exact_dot_conf/dot_managed.txt", "managed\n")
    cz.write_dest(".conf/stray.txt", "junk\n")
    cz.write_dest(".conf/.hidden_stray", "keep\n")
    status = cz.status()
    # CATCHES: entries in the destination but not in the exact_ directory are
    # reported with " D" and sorted alongside the managed " A" entry.
    assert status.returncode == 0
    assert status.stdout == (
        " D .conf/.hidden_stray\n"
        " A .conf/.managed.txt\n"
        " D .conf/stray.txt\n"
    )
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.conf/.hidden_stray b/.conf/.hidden_stray\n"
        "deleted file mode 100644\n"
        "index 2fa992c0b8b5c6acd2bdd4fa31de29d29799bdd5..0000000000000000000000000000000000000000\n"
        "--- a/.conf/.hidden_stray\n"
        "+++ /dev/null\n"
        "@@ -1 +0,0 @@\n"
        "-keep\n"
        "diff --git a/.conf/.managed.txt b/.conf/.managed.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..2d0f4af845f90e23d657947ded1657d55dc17451\n"
        "--- /dev/null\n"
        "+++ b/.conf/.managed.txt\n"
        "@@ -0,0 +1 @@\n"
        "+managed\n"
        "diff --git a/.conf/stray.txt b/.conf/stray.txt\n"
        "deleted file mode 100644\n"
        "index a941931010167fd6cd8c7ea895d3468f26e67bde..0000000000000000000000000000000000000000\n"
        "--- a/.conf/stray.txt\n"
        "+++ /dev/null\n"
        "@@ -1 +0,0 @@\n"
        "-junk\n"
    )
    assert cz.apply("--no-tty").returncode == 0
    assert sorted(p.name for p in (cz.dest / ".conf").iterdir()) == [".managed.txt"]
    # CATCHES: after the cleanup the exact directory verifies clean.
    assert cz.verify().returncode == 0
    assert cz.status().stdout == ""


def test_exact_directory_removes_unmanaged_directories(cz):
    """``exact_`` pruning removes whole unmanaged subdirectories."""
    cz.add("exact_dot_conf/sub/dot_m.txt", "m\n")
    (cz.dest / ".conf" / "other").mkdir(parents=True)
    status = cz.status()
    # CATCHES: the unmanaged subdirectory is reported as a single " D" entry
    # while the managed subdirectory and its file are reported separately.
    assert status.returncode == 0
    assert status.stdout == (
        " D .conf/other\n"
        " A .conf/sub\n"
        " A .conf/sub/.m.txt\n"
    )
    assert cz.apply("--no-tty").returncode == 0
    remaining = sorted(str(p.relative_to(cz.dest)) for p in cz.dest.rglob("*"))
    # CATCHES: apply deleted the unmanaged directory tree, keeping only the
    # managed file.
    assert remaining == [".conf", ".conf/sub", ".conf/sub/.m.txt"]


def test_plain_directory_leaves_unmanaged_files_alone(cz):
    """Without ``exact_`` apply never touches unmanaged destination files."""
    cz.add("dot_conf/dot_m.txt", "m\n")
    cz.write_dest(".conf/stray.txt", "stray\n")
    status = cz.status()
    # CATCHES: the stray file is not mentioned by status because chezmoi does
    # not manage it, unlike in an exact_ directory.
    assert status.returncode == 0
    assert status.stdout == " A .conf/.m.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert sorted(p.name for p in (cz.dest / ".conf").iterdir()) == [
        ".m.txt",
        "stray.txt",
    ]


def test_modify_script_reads_stdin_and_replaces_contents(cz):
    """``modify_`` scripts transform the current file via stdin/stdout."""
    cz.write_dest(".mod.txt", "orig line\n")
    cz.add("modify_dot_mod.txt", '#!/bin/sh\necho "prepended"\ncat\n')
    status = cz.status()
    # CATCHES: the modified target is reported as " M" because its computed
    # contents (script output) differ from the destination.
    assert status.returncode == 0
    assert status.stdout == " M .mod.txt\n"
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.mod.txt b/.mod.txt\n"
        "index 8199773a5e5c09fe8b124803ff6af16670675b42..fff4e5770f3ed3e533189af2301cb9bd54a4e679 100644\n"
        "--- a/.mod.txt\n"
        "+++ b/.mod.txt\n"
        "@@ -1 +1,2 @@\n"
        "+prepended\n"
        " orig line\n"
    )
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: the script receives the current contents on stdin and its
    # stdout becomes the new file contents.
    assert cz.read_dest(".mod.txt") == "prepended\norig line\n"


def test_modify_script_interpreter_extension_is_stripped(cz):
    """A known interpreter extension names the target, not the interpreter."""
    cz.write_dest(".mod.txt", "orig\n")
    cz.add(
        "modify_dot_mod.txt.py",
        '#!/usr/bin/env python3\nimport sys\nsys.stdout.write("py:" + sys.stdin.read())\n',
    )
    status = cz.status()
    # CATCHES: ".py" selects the python3 interpreter and is removed from the
    # target name, so the entry is ".mod.txt" and no ".mod.txt.py" appears.
    assert status.returncode == 0
    assert status.stdout == " M .mod.txt\n"
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.mod.txt b/.mod.txt\n"
        "index dcc27807b20456027b6a152f9756c62360e229d6..ae32fe4c08ff5b4d9adf949bf417eb23cb1ccc99 100644\n"
        "--- a/.mod.txt\n"
        "+++ b/.mod.txt\n"
        "@@ -1 +1 @@\n"
        "-orig\n"
        "+py:orig\n"
    )
    assert cz.apply("--no-tty").returncode == 0
    assert cz.read_dest(".mod.txt") == "py:orig\n"
    assert sorted(p.name for p in cz.dest.iterdir()) == [".mod.txt"]


def test_modify_script_on_missing_destination_creates_file(cz):
    """A ``modify_`` script on a missing target creates it from scratch."""
    cz.add("modify_dot_new.txt", '#!/bin/sh\necho fresh\ncat\n')
    status = cz.status()
    # CATCHES: with no destination file the script's stdin is empty, so the
    # target is a new file containing just the script's stdout.
    assert status.returncode == 0
    assert status.stdout == " A .new.txt\n"
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.new.txt b/.new.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000..92d5444121bba43a7654dcfb037c209cb2a5d403\n"
        "--- /dev/null\n"
        "+++ b/.new.txt\n"
        "@@ -0,0 +1 @@\n"
        "+fresh\n"
    )
    assert cz.apply("--no-tty").returncode == 0
    assert cz.read_dest(".new.txt") == "fresh\n"


def test_literal_attribute_disables_name_interpretation(cz):
    """``literal_`` keeps the remainder of the name verbatim."""
    cz.add("literal_dot_bashrc", "l\n")
    status = cz.status()
    # CATCHES: the literal_ attribute suppresses the dot_ translation, so the
    # target is a file literally named "dot_bashrc" in the destination.
    assert status.returncode == 0
    assert status.stdout == " A dot_bashrc\n"
    assert cz.apply("--no-tty").returncode == 0
    assert (cz.dest / "dot_bashrc").read_text(encoding="utf-8") == "l\n"
    assert not (cz.dest / ".bashrc").exists()


def test_empty_source_file_removes_destination_file(cz):
    """An empty source file (without ``empty_``) means the target is absent."""
    cz.add("dot_gone.txt", "")
    cz.write_dest(".gone.txt", "stale\n")
    status = cz.status()
    # CATCHES: an empty source file is not a no-op: it makes the target state
    # "absent", reported as " D" while the destination file still exists.
    assert status.returncode == 0
    assert status.stdout == " D .gone.txt\n"
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.gone.txt b/.gone.txt\n"
        "deleted file mode 100644\n"
        "index 8427fc236f921196257ed1c20f6e4d195240063f..0000000000000000000000000000000000000000\n"
        "--- a/.gone.txt\n"
        "+++ /dev/null\n"
        "@@ -1 +0,0 @@\n"
        "-stale\n"
    )
    assert cz.verify().returncode == 1
    assert cz.apply("--no-tty").returncode == 0
    assert not (cz.dest / ".gone.txt").exists()


def test_empty_attribute_creates_empty_file(cz):
    """``empty_`` opts into managing a zero-length file."""
    cz.add("empty_dot_keep", "")
    cz.add("dot_void.txt", "")
    status = cz.status()
    # CATCHES: only the empty_ attributed file is reported; the plain empty
    # file produces no target at all when the destination is already absent.
    assert status.returncode == 0
    assert status.stdout == " A .keep\n"
    assert cz.apply("--no-tty").returncode == 0
    keep = cz.dest / ".keep"
    assert keep.is_file()
    # CATCHES: the empty file is really created with zero bytes and mode 0644.
    assert keep.stat().st_size == 0
    assert keep.stat().st_mode & 0o777 == 0o644
    assert not (cz.dest / ".void.txt").exists()


def test_chezmoiroot_relocates_the_source_state_root(cz):
    """``.chezmoiroot`` restricts the source state to a subdirectory."""
    cz.add(".chezmoiroot", "state2\n")
    cz.add("state2/dot_r.txt", "r\n")
    cz.add("dot_top.txt", "top\n")
    status = cz.status()
    # CATCHES: only files under the directory named by .chezmoiroot are part
    # of the source state; the top-level file is ignored entirely.
    assert status.returncode == 0
    assert status.stdout == " A .r.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert sorted(p.name for p in cz.dest.iterdir()) == [".r.txt"]


def test_chezmoiversion_must_be_dotted_tri(cz):
    """``.chezmoiversion`` must contain a dotted-tri semantic version."""
    cz.add(".chezmoiversion", "bogus\n")
    cz.add("dot_x.txt", "x\n")
    error = (
        f'chezmoi: {cz.src}/.chezmoiversion: "bogus\\n": '
        "bogus is not in dotted-tri format\n"
    )
    status = cz.status()
    # CATCHES: the version file is parsed before anything else; the error
    # names the file, quotes its raw bytes and rejects non-semver contents.
    assert status.returncode == 1
    assert status.stdout == ""
    assert status.stderr == error
    diff = cz.diff()
    assert diff.returncode == 1
    assert diff.stdout == ""
    assert diff.stderr == error
    cz.add(".chezmoiversion", "2.0.0\n")
    ok = cz.status()
    # CATCHES: a valid (older) version is accepted and processing continues.
    assert ok.returncode == 0
    assert ok.stdout == " A .x.txt\n"


def test_scripts_in_chezmoiscripts_directory(cz):
    """Scripts may live in the ``.chezmoiscripts`` directory."""
    cz.add(".chezmoiscripts/run_once_s.sh", "#!/bin/sh\necho inner\n")
    apply_proc = cz.apply("--no-tty")
    # CATCHES: the script runs during apply with its stdout forwarded, and it
    # is recorded in scriptState under a name that keeps the .chezmoiscripts
    # prefix while the run_/once_ attributes are stripped.
    assert apply_proc.returncode == 0
    assert apply_proc.stdout == "inner\n"
    script_state = cz.state("get-bucket", "--bucket", "scriptState")
    assert script_state.returncode == 0
    contents = b"#!/bin/sh\necho inner\n"
    [(key, value)] = json.loads(script_state.stdout).items()
    # CATCHES: the scriptState key is the SHA-256 of the script contents and
    # the value's name keeps the .chezmoiscripts prefix (runAt varies).
    assert key == hashlib.sha256(contents).hexdigest()
    assert value["name"] == ".chezmoiscripts/s.sh"


def test_template_execution_error_message(cz):
    """A failing template surfaces the template error with its position."""
    cz.add("dot_t.tmpl", "x={{ .missing }}\n")
    status = cz.status()
    # CATCHES: template failures abort the command with the Go text/template
    # error, including the source file name and the byte offset of the error.
    assert status.returncode == 1
    assert status.stdout == ""
    assert status.stderr == (
        'chezmoi: .t: template: dot_t.tmpl:1:5: executing "dot_t.tmpl" '
        'at <.missing>: map has no entry for key "missing"\n'
    )


def test_once_script_reruns_after_state_reset(cz):
    """``run_once_`` state lives in the database and reset clears it."""
    cz.add("run_once_x.sh", "#!/bin/sh\necho ran >> log.txt\n", mode=0o755)
    assert cz.apply("--no-tty").returncode == 0
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: the second apply did not re-run the script because scriptState
    # still records it.
    assert cz.read_dest("log.txt") == "ran\n"
    assert cz.state("reset", "--force").returncode == 0
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: resetting the persistent state forgot that the script already
    # ran, so it executes again and appends a second line.
    assert cz.read_dest("log.txt") == "ran\nran\n"


# --------------------------------------------------------------------------
# .chezmoiremove, per-directory ignores, and data sources
# --------------------------------------------------------------------------


def test_chezmoiremove_deletes_matching_destinations(cz):
    """``.chezmoiremove`` patterns turn matching dest entries into removals."""
    cz.add("dot_a.txt", "a\n")
    cz.write_dest("gone1.txt", "x\n")
    cz.write_dest("gone2.txt", "x\n")
    cz.write_dest("keep.txt", "x\n")
    cz.add(".chezmoiremove", "gone*\n")
    status = cz.status()
    # CATCHES: glob patterns match destination paths that chezmoi does not
    # otherwise manage, reporting them as " D" deletions alongside additions.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n D gone1.txt\n D gone2.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: apply really deletes the matched files and only those.
    assert sorted(p.name for p in cz.dest.iterdir()) == [".a.txt", "keep.txt"]


def test_chezmoiremove_is_executed_as_a_template(cz):
    """``.chezmoiremove.tmpl`` is rendered before its patterns are used."""
    cz.add("dot_a.txt", "a\n")
    cz.write_dest(".linux-only.txt", "x\n")
    cz.write_dest(".keep.txt", "x\n")
    cz.add(
        ".chezmoiremove.tmpl",
        '{{ if eq .chezmoi.os "linux" }}.linux-only.txt{{ end }}\n',
    )
    status = cz.status()
    # CATCHES: the remove patterns file is a template over the same data as
    # .chezmoiignore, so the pattern only appears on the matching OS.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n D .linux-only.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert not (cz.dest / ".linux-only.txt").exists()
    assert (cz.dest / ".keep.txt").read_text(encoding="utf-8") == "x\n"


def test_chezmoiremove_removes_directories(cz):
    """A remove pattern matching a directory removes the whole subtree."""
    cz.add("dot_a.txt", "a\n")
    cz.write_dest(".olddir/f.txt", "x\n")
    cz.add(".chezmoiremove", ".olddir\n")
    status = cz.status()
    # CATCHES: the directory is reported as one " D" entry (no per-file lines)
    # and applying removes it recursively in a single step.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n D .olddir\n"
    assert cz.apply("--no-tty").returncode == 0
    assert not (cz.dest / ".olddir").exists()
    assert sorted(p.name for p in cz.dest.iterdir()) == [".a.txt"]


def test_chezmoiignore_overrides_chezmoiremove(cz):
    """A target matched by both files is ignored, not removed."""
    cz.add("dot_a.txt", "a\n")
    cz.write_dest(".old.txt", "old\n")
    cz.add(".chezmoiremove", ".old.txt\n")
    cz.add(".chezmoiignore", ".old.txt\n")
    status = cz.status()
    # CATCHES: ignore patterns are applied to remove-generated entries too, so
    # the file is neither reported nor deleted by apply.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert (cz.dest / ".old.txt").read_text(encoding="utf-8") == "old\n"


def test_subdirectory_chezmoiignore_scopes_to_its_directory(cz):
    """A ``.chezmoiignore`` inside a source subdirectory applies below it."""
    cz.mkdir("sub")
    cz.add("sub/dot_a.txt", "a\n")
    cz.add("sub/dot_b.txt", "b\n")
    cz.add("dot_top.txt", "t\n")
    cz.add("sub/.chezmoiignore", ".a.txt\n")
    status = cz.status()
    # CATCHES: ignore files are read while walking each directory, so the
    # pattern only hides sub/.a.txt while the identically named top-level file
    # would still be managed (here .top.txt stays visible).
    assert status.returncode == 0
    assert status.stdout == " A .top.txt\n A sub\n A sub/.b.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert sorted(p.name for p in (cz.dest / "sub").iterdir()) == [".b.txt"]


def test_chezmoidata_directory_merges_all_formats(cz):
    """A ``.chezmoidata`` directory merges every data file inside it."""
    cz.add(".chezmoidata/a.toml", 'fromTOML = "t"\n')
    cz.add(".chezmoidata/b.yaml", "fromYAML: y\n")
    cz.add(".chezmoidata/c.json", '{"fromJSON": "j"}\n')
    cz.add("dot_m.tmpl", "T={{ .fromTOML }} Y={{ .fromYAML }} J={{ .fromJSON }}\n")
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: files in the .chezmoidata directory are keyed by their format
    # extension and all merge into one template namespace; the directory
    # itself produces no destination entry.
    assert cz.read_dest(".m") == "T=t Y=y J=j\n"
    assert sorted(p.name for p in cz.dest.iterdir()) == [".m"]


def test_chezmoidata_yaml_and_json_files(cz):
    """``.chezmoidata.<format>`` files are picked by their extension."""
    cz.add(".chezmoidata.yaml", "fromYAML: y\n")
    cz.add(".chezmoidata.json", '{"fromJSON": "j"}\n')
    cz.add("dot_m.tmpl", "Y={{ .fromYAML }} J={{ .fromJSON }}\n")
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: both the YAML and the JSON variant are recognized and merged
    # alongside (not instead of) the TOML one from other tests.
    assert cz.read_dest(".m") == "Y=y J=j\n"


def test_chezmoidata_directory_rejects_chezmoi_entries(cz):
    """Special ``.chezmoi*`` names are not allowed inside ``.chezmoidata``."""
    cz.add(".chezmoidata/.chezmoibad.toml", "x = 1\n")
    cz.add("dot_a.txt", "a\n")
    status = cz.status()
    # CATCHES: the walk refuses .chezmoi-prefixed files inside the data
    # directory with an error naming the offending file, before any target is
    # reported.
    assert status.returncode == 1
    assert status.stdout == ""
    assert status.stderr == (
        f"chezmoi: {cz.src}/.chezmoidata/.chezmoibad.toml: "
        "not allowed in .chezmoidata directory\n"
    )


def test_scripts_are_rendered_as_templates(cz):
    """Scripts with a ``.tmpl`` suffix are rendered before running."""
    cz.add("run_once_x.sh.tmpl", '#!/bin/sh\necho "os={{ .chezmoi.os }}"\n')
    status = cz.status()
    # CATCHES: the .tmpl suffix is stripped from the script name (status shows
    # " R x.sh", not x.sh.tmpl) and the script counts as pending.
    assert status.returncode == 0
    assert status.stdout == " R x.sh\n"
    proc = cz.apply("--no-tty")
    # CATCHES: the script body is executed as a template over the usual data,
    # so the echo prints the rendered OS name.
    assert proc.returncode == 0
    assert proc.stdout == "os=linux\n"
    script_state = cz.state("get-bucket", "--bucket", "scriptState")
    assert script_state.returncode == 0
    [(key, value)] = json.loads(script_state.stdout).items()
    # CATCHES: scriptState is keyed by the SHA-256 of the *rendered* contents
    # and the recorded name is the target script name.
    rendered = b'#!/bin/sh\necho "os=linux"\n'
    assert key == hashlib.sha256(rendered).hexdigest()
    assert value["name"] == "x.sh"


def test_modify_script_templates(cz):
    """A ``modify_`` script may itself be a template."""
    cz.write_dest(".m.txt", "orig\n")
    cz.add(
        "modify_dot_m.txt.tmpl",
        '#!/bin/sh\ncat\necho "appended-{{ .chezmoi.os }}"\n',
    )
    status = cz.status()
    # CATCHES: the .tmpl suffix is stripped from the target name (".m.txt")
    # and the computed contents differ, so the entry is modified.
    assert status.returncode == 0
    assert status.stdout == " M .m.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: the script is rendered before execution, so its echo emits the
    # template-expanded text after the original contents.
    assert cz.read_dest(".m.txt") == "orig\nappended-linux\n"
    assert sorted(p.name for p in cz.dest.iterdir()) == [".m.txt"]


def test_private_directory_and_private_executable_file_modes(cz):
    """``private_`` applies to directories and combines with ``executable_``."""
    cz.add("private_dot_pd/dot_f.txt", "f\n")
    cz.add("private_executable_dot_pe.sh", "x\n")
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: private_ scales a directory to 0700 (not just files) and a
    # private_executable_ file keeps private's rw plus the execute bits (0700,
    # not 0755 and not 0600).
    assert os.stat(cz.dest / ".pd").st_mode & 0o777 == 0o700
    assert os.stat(cz.dest / ".pd" / ".f.txt").st_mode & 0o777 == 0o644
    assert os.stat(cz.dest / ".pe.sh").st_mode & 0o777 == 0o700


def test_symlink_template_renders_linkname(cz):
    """A ``symlink_`` source with a ``.tmpl`` suffix renders the target."""
    cz.add("symlink_dot_l.tmpl", "link-{{ .chezmoi.os }}\n")
    status = cz.status()
    # CATCHES: the .tmpl suffix is stripped from the target name, so the entry
    # is the symlink .l, and its (rendered) contents are the link target.
    assert status.returncode == 0
    assert status.stdout == " A .l\n"
    assert cz.apply("--no-tty").returncode == 0
    assert os.path.islink(cz.dest / ".l")
    assert os.readlink(cz.dest / ".l") == "link-linux"


def test_chezmoiignore_tmpl_template_variant(cz):
    """``.chezmoiignore.tmpl`` is rendered before its patterns apply."""
    cz.add("dot_a.txt", "a\n")
    cz.add("dot_b.txt", "b\n")
    cz.add(
        ".chezmoiignore.tmpl",
        '{{ if eq .chezmoi.os "linux" }}.a.txt{{ end }}\n',
    )
    status = cz.status()
    # CATCHES: the ignore file is recognized by its .tmpl suffix too and is
    # executed as a template, so the pattern only exists on matching systems.
    assert status.returncode == 0
    assert status.stdout == " A .b.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert not (cz.dest / ".a.txt").exists()
    assert (cz.dest / ".b.txt").read_text(encoding="utf-8") == "b\n"


def test_chezmoitemplates_subdirectory_names_include_the_path(cz):
    """Templates in ``.chezmoitemplates`` subdirectories keep their subdir."""
    cz.add(".chezmoidata.toml", 'g = "hi"\n')
    cz.add(".chezmoitemplates/nested/inner", "N={{ .g }}\n")
    cz.add("dot_t.tmpl", 'include: {{ template "nested/inner" . }}\n')
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: a template in a subdirectory is named by its path below
    # .chezmoitemplates ("nested/inner"), and the .chezmoitemplates tree
    # itself still produces no destination entries.
    assert cz.read_dest(".t") == "include: N=hi\n\n"
    assert sorted(p.name for p in cz.dest.iterdir()) == [".t"]


def test_chezmoitemplates_rejects_chezmoi_entries(cz):
    """``.chezmoi``-prefixed names are refused inside ``.chezmoitemplates``."""
    cz.add(".chezmoitemplates/.chezmoibad", "x\n")
    cz.add("dot_a.txt", "a\n")
    status = cz.status()
    # CATCHES: the templates directory walk rejects special .chezmoi* names
    # with an error naming the file, before any target is reported.
    assert status.returncode == 1
    assert status.stdout == ""
    assert status.stderr == (
        f"chezmoi: {cz.src}/.chezmoitemplates/.chezmoibad: "
        "not allowed in .chezmoitemplates directory\n"
    )


def test_chezmoiscripts_subdirectory_scripts(cz):
    """Scripts may be nested in subdirectories of ``.chezmoiscripts``."""
    cz.add(".chezmoiscripts/sub/run_once_s.sh", "#!/bin/sh\necho sub-script\n")
    proc = cz.apply("--no-tty")
    # CATCHES: the script still runs during apply with its output forwarded,
    # and its scriptState name keeps the path below .chezmoiscripts while the
    # run_/once_ attributes are stripped.
    assert proc.returncode == 0
    assert proc.stdout == "sub-script\n"
    script_state = cz.state("get-bucket", "--bucket", "scriptState")
    assert script_state.returncode == 0
    [(key, value)] = json.loads(script_state.stdout).items()
    assert value["name"] == ".chezmoiscripts/sub/s.sh"


def test_readonly_attribute_creates_readonly_file(cz):
    """``readonly_`` files are applied with mode 0444."""
    cz.add("readonly_dot_r.txt", "r\n")
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: readonly_ produces a world-readable, non-writable file (0444)
    # unlike the default 0644.
    assert os.stat(cz.dest / ".r.txt").st_mode & 0o777 == 0o444
    assert cz.read_dest(".r.txt") == "r\n"


def test_dot_prefixed_source_files_are_ignored(cz):
    """Source files starting with a dot are not part of the target state."""
    cz.add("dot_a.txt", "a\n")
    cz.add(".gitignore", "dot_a.txt\n")
    cz.add("._plain.txt", "plain\n")
    cz.add(".hidden", "h\n")
    status = cz.status()
    # CATCHES: only the special .chezmoi* files are interpreted; every other
    # dot-prefixed file in the source directory (like a .gitignore used to
    # track the source state itself) is skipped entirely.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert sorted(p.name for p in cz.dest.iterdir()) == [".a.txt"]


def test_chezmoiversion_rejects_bad_versions(cz):
    """``.chezmoiversion`` must be three dot-separated integers."""
    cz.add("dot_a.txt", "a\n")
    cz.add(".chezmoiversion", "v2.0.0\n")
    verror = cz.status()
    # CATCHES: a leading "v" is rejected with the raw strconv error (each
    # component is parsed as an integer), quoting the file's exact bytes.
    assert verror.returncode == 1
    assert verror.stderr == (
        f'chezmoi: {cz.src}/.chezmoiversion: "v2.0.0\\n": '
        "strconv.ParseInt: parsing \"v2\": invalid syntax\n"
    )
    cz.add(".chezmoiversion", "2.0\n")
    terror = cz.status()
    # CATCHES: two components are rejected by the dotted-tri check which names
    # the offending text.
    assert terror.returncode == 1
    assert terror.stderr == (
        f'chezmoi: {cz.src}/.chezmoiversion: "2.0\\n": '
        "2.0 is not in dotted-tri format\n"
    )
    cz.add(".chezmoiversion", " 2.0.0 \n")
    padded = cz.status()
    # CATCHES: surrounding whitespace is trimmed before parsing, so a padded
    # version is accepted.
    assert padded.returncode == 0
    assert padded.stdout == " A .a.txt\n"


def test_create_template_renders_but_never_overwrites(cz):
    """``create_`` with a ``.tmpl`` suffix renders once and never overwrites."""
    cz.add("create_dot_c.txt.tmpl", "os={{ .chezmoi.os }}\n")
    assert cz.apply("--no-tty").returncode == 0
    # CATCHES: the create_ target is rendered as a template when the file is
    # missing and created from that output.
    assert cz.read_dest(".c.txt") == "os=linux\n"
    cz.write_dest(".c.txt", "user-written\n")
    status = cz.status()
    # CATCHES: a pre-existing file is never reported and never overwritten,
    # even though its contents differ from the rendered template.
    assert status.returncode == 0
    assert status.stdout == ""
    assert cz.diff().stdout == ""
    assert cz.apply("--no-tty").returncode == 0
    assert cz.read_dest(".c.txt") == "user-written\n"


# ---------------------------------------------------------------------------
# Externals (`.chezmoiexternal*` files, `external_` directories).  All URLs
# are file:// URLs pointing at files inside the sandbox, so no network access
# ever happens: chezmoi reads file:// URLs straight from disk.
# ---------------------------------------------------------------------------


def make_tar_gz(path, entries):
    """Write a gzipped tar archive with the given (name, mode, data) entries.

    Directory entries must end with "/" in their name, matching what GNU tar
    writes, and ``data=None`` marks a directory.
    """
    import gzip
    import io
    import tarfile

    with tarfile.open(path, "w:gz", format=tarfile.GNU_FORMAT) as tar:
        for name, mode, data in entries:
            info = tarfile.TarInfo(name)
            info.mode = mode
            if data is None:
                info.type = tarfile.DIRTYPE
                tar.addfile(info)
            else:
                info.size = len(data)
                tar.addfile(info, io.BytesIO(data))
    return path


def standard_archive(cz):
    """Create the pkg-1.0.tar.gz archive used by the external tests."""
    return make_tar_gz(
        cz.root / "ext.tar.gz",
        [
            ("pkg-1.0/", 0o755, None),
            ("pkg-1.0/one.txt", 0o644, b"one\n"),
            ("pkg-1.0/two.txt", 0o644, b"two\n"),
            ("pkg-1.0/sub/", 0o755, None),
            ("pkg-1.0/sub/three.txt", 0o644, b"nested\n"),
        ],
    )


def write_external(cz, text):
    """Write the root .chezmoiexternal.toml with the given body."""
    return cz.add(".chezmoiexternal.toml", text)


def test_external_archive_status_diff_apply_verify(cz):
    """An archive external unpacks a target tree from a file:// URL."""
    archive = standard_archive(cz)
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n'
        f'    stripComponents = 1\n',
    )
    status = cz.status()
    # CATCHES: the external contributes its target directory, the archive's
    # own directories, and each file, all reported as added in sorted order.
    assert status.returncode == 0
    assert status.stdout == (
        " A .mytree\n"
        " A .mytree/one.txt\n"
        " A .mytree/sub\n"
        " A .mytree/sub/three.txt\n"
        " A .mytree/two.txt\n"
    )
    diff = cz.diff()
    assert diff.returncode == 0
    assert diff.stdout == (
        "diff --git a/.mytree b/.mytree\n"
        "new file mode 40755\n"
        "index 0000000000000000000000000000000000000000"
        "..e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\n"
        "--- /dev/null\n"
        "+++ b/.mytree\n"
        "diff --git a/.mytree/one.txt b/.mytree/one.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000"
        "..5626abf0f72e58d7a153368ba57db4c673c0e171\n"
        "--- /dev/null\n"
        "+++ b/.mytree/one.txt\n"
        "@@ -0,0 +1 @@\n"
        "+one\n"
        "diff --git a/.mytree/sub b/.mytree/sub\n"
        "new file mode 40755\n"
        "index 0000000000000000000000000000000000000000"
        "..e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\n"
        "--- /dev/null\n"
        "+++ b/.mytree/sub\n"
        "diff --git a/.mytree/sub/three.txt b/.mytree/sub/three.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000"
        "..79c53955ef856f16f2107446bc721c8879a1bd2e\n"
        "--- /dev/null\n"
        "+++ b/.mytree/sub/three.txt\n"
        "@@ -0,0 +1 @@\n"
        "+nested\n"
        "diff --git a/.mytree/two.txt b/.mytree/two.txt\n"
        "new file mode 100644\n"
        "index 0000000000000000000000000000000000000000"
        "..f719efd430d52bcfc8566a43b2eb655688d38871\n"
        "--- /dev/null\n"
        "+++ b/.mytree/two.txt\n"
        "@@ -0,0 +1 @@\n"
        "+two\n"
    )
    apply_proc = cz.apply("--no-tty")
    # CATCHES: apply really extracts the archive: contents and permissions
    # come from the archive entries, and afterwards status is empty and
    # verify passes.
    assert apply_proc.returncode == 0
    assert apply_proc.stdout == ""
    assert cz.read_dest(".mytree/one.txt") == "one\n"
    assert cz.read_dest(".mytree/sub/three.txt") == "nested\n"
    assert (cz.dest / ".mytree/sub").stat().st_mode & 0o777 == 0o755
    assert cz.status().stdout == ""
    assert cz.verify().returncode == 0
    # A modified extracted file is reported like any managed file.
    cz.write_dest(".mytree/two.txt", "changed\n")
    assert cz.status().stdout == "MM .mytree/two.txt\n"
    assert cz.verify().returncode == 1


def test_external_archive_strip_components(cz):
    """stripComponents removes leading path elements inside the archive."""
    archive = standard_archive(cz)
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n',
    )
    # CATCHES: without stripComponents the pkg-1.0/ prefix is kept as a real
    # directory level under the target; with stripComponents = 1 (tested
    # above) it disappears, so the two trees differ by exactly that level.
    status = cz.status()
    assert status.returncode == 0
    assert status.stdout == (
        " A .mytree\n"
        " A .mytree/pkg-1.0\n"
        " A .mytree/pkg-1.0/one.txt\n"
        " A .mytree/pkg-1.0/sub\n"
        " A .mytree/pkg-1.0/sub/three.txt\n"
        " A .mytree/pkg-1.0/two.txt\n"
    )
    cz.apply("--no-tty")
    assert cz.read_dest(".mytree/pkg-1.0/one.txt") == "one\n"


def test_external_archive_include_exclude_patterns(cz):
    """include/exclude filter archive members before stripping components."""
    archive = standard_archive(cz)
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n'
        f'    stripComponents = 1\n'
        f'    include = ["pkg-1.0/one.txt"]\n',
    )
    included = cz.status()
    # CATCHES: include patterns match the un-stripped archive names, so only
    # one.txt (plus the target directory itself) survives.
    assert included.returncode == 0
    assert included.stdout == " A .mytree\n A .mytree/one.txt\n"
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n'
        f'    stripComponents = 1\n'
        f'    exclude = ["pkg-1.0/sub"]\n',
    )
    excluded = cz.status()
    # CATCHES: excluding a directory pattern drops the directory and
    # everything inside it, but keeps the other members.
    assert excluded.returncode == 0
    assert excluded.stdout == (
        " A .mytree\n"
        " A .mytree/one.txt\n"
        " A .mytree/two.txt\n"
    )


def test_external_archive_exact_removes_stray_files(cz):
    """exact = true turns the external directory into an exact_ directory."""
    archive = standard_archive(cz)
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n'
        f'    stripComponents = 1\n'
        f'    exact = true\n',
    )
    cz.write_dest(".mytree/stray.txt", "stray\n")
    status = cz.status()
    # CATCHES: with exact = true the pre-existing unmanaged file is reported
    # as deleted, while without it (see test_external_archive_status...) it
    # would be ignored entirely.
    assert status.returncode == 0
    assert status.stdout == (
        " A .mytree/one.txt\n"
        " D .mytree/stray.txt\n"
        " A .mytree/sub\n"
        " A .mytree/sub/three.txt\n"
        " A .mytree/two.txt\n"
    )
    apply_proc = cz.apply("--no-tty")
    assert apply_proc.returncode == 0
    assert not (cz.dest / ".mytree/stray.txt").exists()
    assert cz.read_dest(".mytree/one.txt") == "one\n"


def test_external_checksums_and_warnings(cz):
    """Checksums verify the downloaded data; insecure hashes warn on stderr."""
    archive = standard_archive(cz)
    sha = hashlib.sha256(archive.read_bytes()).hexdigest()
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n'
        f'    stripComponents = 1\n'
        f'    checksum.sha256 = "{sha}"\n',
    )
    ok = cz.status()
    # CATCHES: a matching SHA256 checksum is accepted silently, but a wrong
    # one aborts the command with the expected/got hex digests.
    assert ok.returncode == 0
    assert ok.stderr == ""
    assert " A .mytree/one.txt" in ok.stdout
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n'
        f'    stripComponents = 1\n'
        f'    checksum.sha256 = "00000000000000000000000000000000'
        f'00000000000000000000000000000000"\n',
    )
    bad = cz.status()
    assert bad.returncode == 1
    assert bad.stdout == ""
    assert bad.stderr == (
        "chezmoi: .mytree: SHA256 mismatch: "
        "expected 00000000000000000000000000000000"
        "00000000000000000000000000000000, "
        f"got {sha}\n"
    )


def test_external_insecure_checksum_warnings(cz):
    """MD5 and size-only checks warn on stderr but still verify the data."""
    payload = cz.root / "remote.txt"
    payload.write_text("remote file contents\n", encoding="utf-8")
    md5 = hashlib.md5(payload.read_bytes()).hexdigest()
    write_external(
        cz,
        f'[".md5file"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n'
        f'    checksum.md5 = "{md5}"\n',
    )
    md5proc = cz.status()
    # CATCHES: an MD5 checksum is honored (status proceeds and reports the
    # file) but prints an insecurity warning on stderr, not stdout.
    assert md5proc.returncode == 0
    assert md5proc.stdout == " A .md5file\n"
    assert md5proc.stderr == (
        "chezmoi: .md5file: warning: insecure MD5 checksum will be removed, "
        "use a secure hash like SHA256 instead\n"
    )
    write_external(
        cz,
        f'[".sizefile"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n'
        f'    checksum.size = 99\n',
    )
    sizeproc = cz.status()
    # CATCHES: a size mismatch is an error, but the size-only check also
    # warns that it is insecure first; both lines go to stderr.
    assert sizeproc.returncode == 1
    assert sizeproc.stdout == ""
    assert sizeproc.stderr == (
        "chezmoi: .sizefile: warning: insecure size check without secure "
        "hash will be removed\n"
        "chezmoi: .sizefile: size mismatch: expected 99, got 21\n"
    )


def test_external_file_type_attributes(cz):
    """type = "file" materializes a single file with permission attributes."""
    payload = cz.root / "remote.txt"
    payload.write_text("remote file contents\n", encoding="utf-8")
    write_external(
        cz,
        f'[".exfile.sh"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n'
        f'    executable = true\n'
        f'[".privfile"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n'
        f'    private = true\n',
    )
    status = cz.status()
    diff = cz.diff()
    # CATCHES: file externals appear like ordinary added files; executable
    # and private translate to 0755/0600 destination modes.
    assert status.returncode == 0
    assert status.stdout == " A .exfile.sh\n A .privfile\n"
    assert "new file mode 100755" in diff.stdout
    assert "new file mode 100600" in diff.stdout
    assert "+remote file contents" in diff.stdout
    apply_proc = cz.apply("--no-tty")
    assert apply_proc.returncode == 0
    assert cz.read_dest(".exfile.sh") == "remote file contents\n"
    assert (cz.dest / ".exfile.sh").stat().st_mode & 0o777 == 0o755
    assert (cz.dest / ".privfile").stat().st_mode & 0o777 == 0o600


def test_external_urls_fallback_and_failure(cz):
    """The urls list is tried in order; the first error is reported."""
    payload = cz.root / "remote.txt"
    payload.write_text("remote file contents\n", encoding="utf-8")
    missing1 = cz.root / "missing1.txt"
    missing2 = cz.root / "missing2.txt"
    write_external(
        cz,
        f'[".fallback.txt"]\n'
        f'    type = "file"\n'
        f'    urls = ["file://{missing1}", "file://{payload}"]\n',
    )
    status = cz.status()
    # CATCHES: a failing first URL is skipped and the second one is used, so
    # the external is still reported and applied with the second URL's data.
    assert status.returncode == 0
    assert status.stdout == " A .fallback.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert cz.read_dest(".fallback.txt") == "remote file contents\n"
    write_external(
        cz,
        f'[".fallback.txt"]\n'
        f'    type = "file"\n'
        f'    urls = ["file://{missing1}", "file://{missing2}"]\n',
    )
    failed = cz.status()
    # CATCHES: when every URL fails, the error names the FIRST URL, not the
    # last one.
    assert failed.returncode == 1
    assert failed.stdout == ""
    assert failed.stderr == (
        f"chezmoi: .fallback.txt: open {missing1}: no such file or directory\n"
    )


def test_external_decompress_and_filter(cz):
    """decompress inflates the downloaded data; filter pipes it through a command."""
    import gzip

    payload = cz.root / "payload.gz"
    payload.write_bytes(gzip.compress(b"compressed payload\n"))
    plain = cz.root / "unfiltered.txt"
    plain.write_text("filter me\n", encoding="utf-8")
    write_external(
        cz,
        f'[".decompressed.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n'
        f'    decompress = "gzip"\n'
        f'[".filtered.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{plain}"\n'
        f'    filter.command = "tr"\n'
        f'    filter.args = ["a-z", "A-Z"]\n',
    )
    apply_proc = cz.apply("--no-tty")
    # CATCHES: the destination receives the decompressed/filtered bytes, not
    # the raw download: gzip data is inflated and tr uppercases the text.
    assert apply_proc.returncode == 0
    assert cz.read_dest(".decompressed.txt") == "compressed payload\n"
    assert cz.read_dest(".filtered.txt") == "FILTER ME\n"


def test_external_archive_file_extracts_single_path(cz):
    """type = "archive-file" extracts one member of an archive as a file."""
    archive = standard_archive(cz)
    write_external(
        cz,
        f'[".extracted.txt"]\n'
        f'    type = "archive-file"\n'
        f'    url = "file://{archive}"\n'
        f'    path = "pkg-1.0/one.txt"\n',
    )
    status = cz.status()
    # CATCHES: only the named member is extracted, and it becomes a plain
    # file at the target path (not a directory like type = "archive").
    assert status.returncode == 0
    assert status.stdout == " A .extracted.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert cz.read_dest(".extracted.txt") == "one\n"
    assert (cz.dest / ".extracted.txt").is_file()
    write_external(
        cz,
        f'[".extracted.txt"]\n'
        f'    type = "archive-file"\n'
        f'    url = "file://{archive}"\n',
    )
    missing_path = cz.status()
    assert missing_path.returncode == 1
    assert missing_path.stderr == "chezmoi: .extracted.txt: missing path\n"
    write_external(
        cz,
        f'[".extracted.txt"]\n'
        f'    type = "archive-file"\n'
        f'    url = "file://{archive}"\n'
        f'    path = "pkg-1.0/nope.txt"\n',
    )
    absent = cz.status()
    # CATCHES: a path that is not in the archive names the member and the
    # URL it was searched in.
    assert absent.returncode == 1
    assert absent.stderr == (
        f"chezmoi: pkg-1.0/nope.txt: path not found in file://{archive}\n"
    )


def test_external_definition_file_formats(cz):
    """Externals can be defined in yaml, templates, and .chezmoiexternals/."""
    payload = cz.root / "remote.txt"
    payload.write_text("remote file contents\n", encoding="utf-8")
    cz.add(".chezmoiexternal.yaml", f'".yaml-ext.txt":\n    type: file\n    url: file://{payload}\n')
    status = cz.status()
    # CATCHES: the externals file format is chosen by the file extension, so
    # a YAML definition works exactly like the TOML one.
    assert status.returncode == 0
    assert status.stdout == " A .yaml-ext.txt\n"
    (cz.src / ".chezmoiexternal.yaml").unlink()
    cz.add(
        ".chezmoiexternal.toml.tmpl",
        f'[".tmpl-{{{{ .chezmoi.os }}}}.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n',
    )
    templated = cz.status()
    # CATCHES: a .chezmoiexternal.toml.tmpl is executed as a template first,
    # so the target name embeds the rendered chezmoi.os variable.
    assert templated.returncode == 0
    assert templated.stdout == " A .tmpl-linux.txt\n"
    (cz.src / ".chezmoiexternal.toml.tmpl").unlink()
    cz.mkdir(".chezmoiexternals")
    cz.add(
        ".chezmoiexternals/extfile.toml",
        f'[".from-externals-dir.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n',
    )
    from_dir = cz.status()
    # CATCHES: every file directly inside .chezmoiexternals/ acts as a root
    # -level externals definition.
    assert from_dir.returncode == 0
    assert from_dir.stdout == " A .from-externals-dir.txt\n"
    cz.add(".chezmoiexternals/x/.chezmoiignore", "")
    rejected = cz.status()
    # CATCHES: .chezmoi* files are not allowed inside .chezmoiexternals/,
    # and the error names the offending absolute path.
    assert rejected.returncode == 1
    assert rejected.stdout == ""
    assert rejected.stderr == (
        f"chezmoi: {cz.src}/.chezmoiexternals/x/.chezmoiignore: "
        "not allowed in .chezmoiexternals directory\n"
    )


def test_external_appledouble_files(cz):
    """AppleDouble files in archives are skipped unless explicitly kept."""
    archive = make_tar_gz(
        cz.root / "ext.tar.gz",
        [
            ("pkg/", 0o755, None),
            ("pkg/top.txt", 0o644, b"top\n"),
            ("pkg/sub/", 0o755, None),
            ("pkg/sub/real.txt", 0o644, b"real\n"),
            ("pkg/sub/._real.txt", 0o644,
             b"\x00\x05\x16\x07\x00\x02\x00\x00apple-double-junk"),
        ],
    )
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n',
    )
    status = cz.status()
    # CATCHES: a ._foo member with the AppleDouble magic is silently dropped
    # from the target state, so it never reaches the destination.
    assert status.returncode == 0
    assert status.stdout == (
        " A .mytree\n"
        " A .mytree/pkg\n"
        " A .mytree/pkg/sub\n"
        " A .mytree/pkg/sub/real.txt\n"
        " A .mytree/pkg/top.txt\n"
    )
    write_external(
        cz,
        f'[".mytree"]\n'
        f'    type = "archive"\n'
        f'    url = "file://{archive}"\n'
        f'    [".mytree".archive]\n'
        f'        extractAppleDoubleFiles = true\n',
    )
    kept = cz.status()
    # CATCHES: archive.extractAppleDoubleFiles = true disables the filter,
    # so the ._real.txt member becomes a normal target file.
    assert kept.returncode == 0
    assert kept.stdout == (
        " A .mytree\n"
        " A .mytree/pkg\n"
        " A .mytree/pkg/sub\n"
        " A .mytree/pkg/sub/._real.txt\n"
        " A .mytree/pkg/sub/real.txt\n"
        " A .mytree/pkg/top.txt\n"
    )


def test_external_definition_path_errors(cz):
    """Invalid external definitions are rejected with precise errors."""
    payload = cz.root / "remote.txt"
    payload.write_text("remote file contents\n", encoding="utf-8")
    external_file = cz.src / ".chezmoiexternal.toml"
    write_external(
        cz,
        f'[".notype"]\n'
        f'    url = "file://{payload}"\n',
    )
    notype = cz.status()
    # CATCHES: an external without a type aborts the whole command.
    assert notype.returncode == 1
    assert notype.stderr == "chezmoi: .notype: missing external type\n"
    write_external(
        cz,
        f'[".nourl"]\n'
        f'    type = "file"\n',
    )
    nourl = cz.status()
    assert nourl.returncode == 1
    assert nourl.stderr == "chezmoi: .nourl: no URL\n"
    write_external(
        cz,
        f'["/abs/path.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n',
    )
    absolute = cz.status()
    # CATCHES: the path key must be relative, and the error names the
    # definition file, the offending key, and the reason.
    assert absolute.returncode == 1
    assert absolute.stderr == (
        f"chezmoi: {external_file}: /abs/path.txt: path is not relative\n"
    )
    write_external(
        cz,
        f'["../outside.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n',
    )
    outside = cz.status()
    assert outside.returncode == 1
    assert outside.stderr == (
        f"chezmoi: {external_file}: ../outside.txt: "
        "relative path outside target directory\n"
    )
    write_external(
        cz,
        f'[""]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n',
    )
    empty = cz.status()
    assert empty.returncode == 1
    assert empty.stderr == f"chezmoi: {external_file}: empty path\n"


def test_external_ignore_interplay(cz):
    """.chezmoiignore hides external targets but not their parent dirs."""
    payload = cz.root / "remote.txt"
    payload.write_text("remote file contents\n", encoding="utf-8")
    write_external(
        cz,
        f'[".ext.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n'
        f'[".other.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n',
    )
    cz.add(".chezmoiignore", ".ext.txt\n")
    status = cz.status()
    # CATCHES: the ignore pattern is matched against the external's target
    # path, so that external disappears while its sibling survives.
    assert status.returncode == 0
    assert status.stdout == " A .other.txt\n"
    (cz.src / ".chezmoiignore").unlink()
    write_external(
        cz,
        f'[".hidden/pack/file.txt"]\n'
        f'    type = "file"\n'
        f'    url = "file://{payload}"\n',
    )
    cz.add(".chezmoiignore", ".hidden\n")
    nested = cz.status()
    # CATCHES: only the external's own target path is checked against the
    # ignore patterns: ignoring the parent directory does NOT hide the
    # external, whose implicit parent directories are still reported and
    # created by apply.
    assert nested.returncode == 0
    assert nested.stdout == (
        " A .hidden\n"
        " A .hidden/pack\n"
        " A .hidden/pack/file.txt\n"
    )
    apply_proc = cz.apply("--no-tty")
    assert apply_proc.returncode == 0
    assert cz.read_dest(".hidden/pack/file.txt") == "remote file contents\n"


def test_external_source_dir_attribute(cz):
    """An external_ source directory is applied with literal names."""
    cz.mkdir("external_vendored/sub")
    cz.add("external_vendored/lib.txt", "vendored lib\n")
    cz.add("external_vendored/run.sh", "#!/bin/sh\ntrue\n").chmod(0o755)
    cz.add("external_vendored/sub/nested.txt", "nested vendored\n")
    (cz.src / "external_vendored/sub").chmod(0o700)
    (cz.src / "external_vendored/link.txt").symlink_to("lib.txt")
    status = cz.status()
    # CATCHES: file names inside an external_ directory are taken literally
    # (no attribute interpretation), subdirectory modes are preserved, and
    # symlinks are applied as symlinks instead of being followed.
    assert status.returncode == 0
    assert status.stdout == (
        " A vendored\n"
        " A vendored/lib.txt\n"
        " A vendored/link.txt\n"
        " A vendored/run.sh\n"
        " A vendored/sub\n"
        " A vendored/sub/nested.txt\n"
    )
    apply_proc = cz.apply("--no-tty")
    assert apply_proc.returncode == 0
    assert cz.read_dest("vendored/lib.txt") == "vendored lib\n"
    assert (cz.dest / "vendored/link.txt").readlink().name == "lib.txt"
    assert cz.read_dest("vendored/link.txt") == "vendored lib\n"
    assert (cz.dest / "vendored/run.sh").stat().st_mode & 0o777 == 0o755
    assert (cz.dest / "vendored/sub").stat().st_mode & 0o777 == 0o700
    # The top-level external directory is not exact: unmanaged files in it
    # are neither reported nor removed.
    cz.write_dest("vendored/stray.txt", "stray\n")
    assert cz.status().stdout == ""
    assert cz.apply("--no-tty").returncode == 0
    assert cz.read_dest("vendored/stray.txt") == "stray\n"


def test_remove_dir_attribute_removes_empty_directories(cz):
    """A remove_ directory is deleted by apply if (and only if) empty."""
    cz.add("dot_a.txt", "a\n")
    cz.mkdir("remove_emptydir")
    (cz.dest / "emptydir").mkdir()
    status = cz.status()
    # CATCHES: status never reports the remove_ directory itself (the target
    # dir state matches the existing empty directory), and apply performs
    # the removal only as a post-apply step.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n"
    apply_proc = cz.apply("--no-tty")
    assert apply_proc.returncode == 0
    assert apply_proc.stdout == ""
    assert not (cz.dest / "emptydir").exists()
    # After the removal the persistent state records a "remove" entry state
    # for the directory, so it shows up as added and fails verification.
    bucket = json.loads(cz.state("get-bucket", "--bucket", "entryState").stdout)
    assert bucket[f"{cz.dest}/emptydir"] == {"type": "remove"}
    assert cz.status().stdout == " A emptydir\n"
    assert cz.verify().returncode == 1
    diff = cz.diff()
    assert "diff --git a/emptydir b/emptydir" in diff.stdout
    assert "new file mode 40755" in diff.stdout
    # Re-applying recreates and then removes the directory again: the net
    # effect of every apply is that the empty directory stays gone.
    assert cz.apply("--no-tty").returncode == 0
    assert not (cz.dest / "emptydir").exists()


def test_remove_dir_attribute_edge_cases(cz):
    """remove_ over a file errors; over a non-empty directory it is a no-op."""
    cz.add("dot_a.txt", "a\n")
    cz.mkdir("remove_afile")
    cz.write_dest("afile", "i am a file\n")
    status = cz.status()
    # CATCHES: when the target of a remove_ directory is a regular file,
    # status fails with "not a directory" naming the absolute destination
    # path, while apply removes the file and succeeds silently.
    assert status.returncode == 1
    assert status.stdout == ""
    assert status.stderr == f"chezmoi: {cz.dest}/afile: not a directory\n"
    (cz.src / "remove_afile").rmdir()
    cz.mkdir("remove_partial")
    (cz.dest / "partial").mkdir()
    cz.write_dest("partial/keepme.txt", "keep\n")
    status = cz.status()
    # CATCHES: a non-empty directory is kept without any error or report;
    # only empty directories are removed.
    assert status.returncode == 0
    assert status.stdout == " A .a.txt\n"
    assert cz.apply("--no-tty").returncode == 0
    assert cz.read_dest("partial/keepme.txt") == "keep\n"


def test_source_symlinks_are_followed(cz):
    """Symlinks in the source directory apply as their target's type."""
    cz.add("real.txt", "real contents\n")
    (cz.src / "dot_followed.txt").symlink_to("real.txt")
    cz.mkdir("realsub")
    cz.add("realsub/inner.txt", "in sub\n")
    (cz.src / "dot_followedsub").symlink_to("realsub")
    status = cz.status()
    # CATCHES: a symlink to a file in the source state is followed and
    # applied as a regular file with the target's contents, and a symlink
    # to a directory becomes an (empty) directory whose children are only
    # taken from the real directory entry.
    assert status.returncode == 0
    assert status.stdout == (
        " A .followed.txt\n"
        " A .followedsub\n"
        " A real.txt\n"
        " A realsub\n"
        " A realsub/inner.txt\n"
    )
    apply_proc = cz.apply("--no-tty")
    assert apply_proc.returncode == 0
    assert cz.read_dest(".followed.txt") == "real contents\n"
    assert not (cz.dest / ".followed.txt").is_symlink()
    assert (cz.dest / ".followedsub").is_dir()
    assert list((cz.dest / ".followedsub").iterdir()) == []
    assert cz.read_dest("realsub/inner.txt") == "in sub\n"
