"""Shared helpers for driving the chezmoi reference binary as a black box.

Every test in this module manipulates a throwaway source directory, destination
directory, config file, and persistent state database, then runs the program
under test and compares the exact bytes it writes to stdout/stderr (or its exit
status).  The binary is always resolved through ``PROGRAMGYM_EXECUTABLE`` so the
suite can be pointed at a re-implementation.
"""

from __future__ import annotations

import functools
import os
import subprocess
import tempfile
import time
from pathlib import Path

# A pinned, minimal environment for every child process: no locale surprises,
# no pager, no color, no editor, and no variables that could influence chezmoi.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "TERM": "dumb",
    "NO_COLOR": "1",
    "PAGER": "",
    "EDITOR": "",
    "VISUAL": "",
}

# chezmoi computes every target permission as ``perm &^ umask``, and those
# permissions are printed by ``status``/``diff`` and stored in the persistent
# state, so the umask of the child must be pinned.  Children inherit the umask
# of this process, so pin it once here instead of relying on the harness.
os.umask(0o022)


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if ``binary`` is a Go coverage build (it drops covcounters files).

    Probed by running ``--version`` once against a throwaway GOCOVERDIR, so the
    check itself never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="chezmoi-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [str(binary), "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def chezmoi_path() -> Path:
    """Return the absolute path of the program under test."""
    path = Path(os.environ["PROGRAMGYM_EXECUTABLE"]).resolve()
    # The pipeline's coverage pass sets GOCOVERDIR and points
    # PROGRAMGYM_EXECUTABLE at a cover-instrumented build of the reference, but
    # the pipeline-managed eval/run.sh resets PROGRAMGYM_EXECUTABLE to this
    # module's uninstrumented ./executable before pytest starts, which would
    # silently drop every counter and leave the module's coverage report empty.
    # During a coverage run, when the assigned binary is not itself
    # instrumented, fall back to the instrumented build staged next to the
    # module workspaces.  Ordinary validation runs never set GOCOVERDIR and
    # always run the assigned binary unchanged.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(staged):
            return staged
    return path


def run_chezmoi(args, input="", cwd=None, env=None, timeout=60):
    """Run the program under test and return the completed process.

    ``args`` is the argument list (without the program name), ``input`` is fed
    to standard input, and ``cwd`` is the working directory of the child.  A
    fixed environment is used unless ``env`` extends it.
    """
    child_env = dict(CHILD_ENV)
    if env:
        child_env.update(env)
    # Coverage instrumentation hook: the pipeline builds the reference binary
    # with -cover, so GOCOVERDIR must survive the pinned environment for the
    # module's source coverage to be measured.  The value is made absolute
    # because children run inside per-test temporary directories; a relative
    # GOCOVERDIR would be resolved against those directories instead of the
    # pipeline's counter directory, and the cover runtime would then fail to
    # write its counters.
    cov_env = {
        "GOCOVERDIR": os.path.abspath(v)
        for v in [os.environ.get("GOCOVERDIR")]
        if v
    }
    child_env.update(cov_env)
    return subprocess.run(
        [str(chezmoi_path()), *[str(a) for a in args]],
        input=input,
        capture_output=True,
        text=True,
        encoding="utf-8",
        cwd=None if cwd is None else str(cwd),
        env=child_env,
        timeout=timeout,
    )


class Chezmoi:
    """A throwaway chezmoi environment rooted in a temporary directory.

    It provides a source directory (``src``), a destination directory
    (``dest``), an empty config file (``chezmoi.toml``) and therefore a
    per-test persistent state database (``chezmoistate.boltdb``, created next
    to the config file on first write).
    """

    def __init__(self, root, config="", source="src", dest="dest"):
        self.root = Path(root)
        self.src = self.root / source
        self.dest = self.root / dest
        self.src.mkdir(parents=True, exist_ok=True)
        self.dest.mkdir(parents=True, exist_ok=True)
        self.config_file = self.root / "chezmoi.toml"
        self.config_file.write_text(config, encoding="utf-8")

    # -- fixture helpers ---------------------------------------------------
    def add(self, relpath, contents="", mode=None):
        """Create a file in the source directory (parents are created)."""
        path = self.src / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(contents, str):
            path.write_text(contents, encoding="utf-8")
        else:
            path.write_bytes(contents)
        if mode is not None:
            path.chmod(mode)
        return path

    def mkdir(self, relpath):
        """Create a directory in the source directory."""
        path = self.src / relpath
        path.mkdir(parents=True, exist_ok=True)
        return path

    def dest_file(self, relpath):
        return self.dest / relpath

    def write_dest(self, relpath, contents=""):
        path = self.dest / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(contents, str):
            path.write_text(contents, encoding="utf-8")
        else:
            path.write_bytes(contents)
        return path

    def read_dest(self, relpath):
        return (self.dest / relpath).read_text(encoding="utf-8")

    def set_config(self, text):
        """Replace the config file contents."""
        self.config_file.write_text(text, encoding="utf-8")
        return self.config_file

    @property
    def state_file(self):
        return self.root / "chezmoistate.boltdb"

    # -- running -----------------------------------------------------------
    def args(self, *args):
        """The common --source/--destination/--config flags plus ``args``."""
        return [
            *args,
            "--source",
            self.src,
            "--destination",
            self.dest,
            "--config",
            self.config_file,
        ]

    def run(self, *args, **kwargs):
        """Run chezmoi against this environment."""
        env = kwargs.pop("env", None)
        cwd = kwargs.pop("cwd", None)
        return run_chezmoi(
            self.args(*args),
            env=dict({"HOME": str(self.root)}, **(env or {})),
            cwd=str(cwd or self.root),
            **kwargs,
        )

    def apply(self, *args, **kwargs):
        return self.run("apply", *args, **kwargs)

    def status(self, *args, **kwargs):
        return self.run("status", *args, **kwargs)

    def diff(self, *args, **kwargs):
        return self.run("diff", "--no-pager", *args, **kwargs)

    def verify(self, *args, **kwargs):
        return self.run("verify", *args, **kwargs)

    def state(self, *args, **kwargs):
        return self.run("state", *args, **kwargs)

    def applied(self):
        """Apply everything, returning the completed process."""
        return self.apply("--no-tty")


def script(path, contents, mode=0o755):
    """Write an executable helper script and return its path."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(contents, encoding="utf-8")
    path.chmod(mode)
    return path


def wait_for_file(path, timeout=5.0):
    """Block until ``path`` exists (used by pager/external-tool tests)."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if Path(path).exists():
            return True
        time.sleep(0.02)
    return False
