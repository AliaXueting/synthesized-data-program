"""Shared fixtures and helpers for the repo_lifecycle_environment module tests.

Every test spawns the chezmoi binary under test as a child process with a fully
pinned environment (its own ``HOME``, ``PATH``, ``TMPDIR`` and git identity) so
that the observed behaviour does not depend on the machine or on the user
running the suite.
"""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
import shutil
import socket
import ssl
import subprocess
import tarfile
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

import pytest

EXECUTABLE = os.environ.get("PROGRAMGYM_EXECUTABLE", "chezmoi")

SYSTEM_PATH = "/usr/bin:/bin"


@dataclass
class Result:
    """The recorded outcome of one chezmoi invocation."""

    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0


# Fake command implementations written as shell scripts. They record their
# arguments (one file per argument) in the directory named by $RECORD_DIR so
# that tests can assert on the exact argv passed by chezmoi.
_RECORDER = """#!/bin/sh
d="${RECORD_DIR:?}"
mkdir -p "$d"
i=0
for a in "$@"; do
    i=$((i+1))
    printf '%s' "$a" > "$d/arg$i"
done
printf '%s\\n' "$i" > "$d/count"
"""

# A git stand-in that records its arguments and then runs the real git, so a
# test can observe every git invocation chezmoi makes without changing the
# result.
_GIT_WRAPPER = """#!/bin/sh
printf '%s\\n' "$*" >> "${RECORD_DIR:?}/git.log"
exec /usr/bin/git "$@"
"""

# A git stand-in that only records its arguments and pretends to succeed.
_GIT_FAKE = """#!/bin/sh
printf '%s\\n' "$*" >> "${RECORD_DIR:?}/git.log"
case "$1" in
    clone)
        last=""
        for a in "$@"; do last="$a"; done
        mkdir -p "$last/.git"
        ;;
esac
exit 0
"""


def child_env(
    home: Path,
    *,
    path: str = SYSTEM_PATH,
    tmpdir: Path | None = None,
    shell: str = "/bin/bash",
    git_config: Path | None = None,
    **extra: str | None,
) -> dict[str, str]:
    """Return the pinned environment used for every child process."""
    if tmpdir is None:
        tmpdir = home / "tmp"
    tmpdir.mkdir(parents=True, exist_ok=True)
    env = {
        "HOME": str(home),
        "PATH": path,
        "SHELL": shell,
        "TMPDIR": str(tmpdir),
        "LC_ALL": "C",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": str(git_config) if git_config else os.devnull,
    }
    for key, value in extra.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    return env


def _child_hook(umask: int | None, uid: int | None):
    """Build the pre-exec hook applied to the child process, if any."""

    def hook() -> None:
        if umask is not None:
            os.umask(umask)
        if uid is not None:
            # Drop every privilege before exec: the sudo-prefixed upgrade
            # methods are only reachable for a non-root caller.
            os.setgroups([])
            os.setgid(uid)
            os.setuid(uid)

    return hook


def run_chezmoi(
    args,
    *,
    env: dict[str, str],
    cwd: Path | str | None = None,
    stdin: bytes = b"",
    exe: str | None = None,
    timeout: int = 90,
    umask: int | None = None,
    uid: int | None = None,
) -> Result:
    """Run the chezmoi binary under test and record its exact output."""
    # Coverage instrumentation hook: the pipeline measures source coverage of
    # the reference binary through GOCOVERDIR, so it must reach the child.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    env = {**env, **cov_env}
    # Pin the child's umask when asked: the inherited umask depends on how the
    # suite itself was launched (eval/run.sh sets 0002, a plain shell 0022).
    # Run it as another uid when asked (see _child_hook).
    preexec = _child_hook(umask, uid) if (umask is not None or uid is not None) else None
    proc = subprocess.run(
        [exe or EXECUTABLE, *args],
        env=env,
        cwd=None if cwd is None else str(cwd),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        preexec_fn=preexec,
    )
    return Result(proc.returncode, proc.stdout.decode(), proc.stderr.decode())


def run_git(env: dict[str, str], cwd: Path, *args: str) -> subprocess.CompletedProcess:
    """Run real git in cwd with the same pinned environment."""
    return subprocess.run(
        ["git", *args],
        env=env,
        cwd=str(cwd),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=60,
    )


def write_script(path: Path, contents: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(contents)
    path.chmod(0o755)
    return path


def write_config(home: Path, contents: str, name: str = "chezmoi.toml") -> Path:
    """Write a chezmoi config file in home's XDG config directory."""
    config_dir = home / ".config" / "chezmoi"
    config_dir.mkdir(parents=True, exist_ok=True)
    path = config_dir / name
    path.write_text(contents)
    return path


def source_dir(home: Path) -> Path:
    return home / ".local" / "share" / "chezmoi"


def record_dir(tmp_path: Path, name: str = "record") -> Path:
    d = tmp_path / name
    d.mkdir(parents=True, exist_ok=True)
    return d


def recorded_args(record: Path) -> list[str]:
    """Return the arguments recorded by the fake commands, in order."""
    count_file = record / "count"
    if not count_file.exists():
        return []
    count = int(count_file.read_text().strip())
    return [(record / f"arg{i}").read_text() for i in range(1, count + 1)]


def make_git_env(home: Path, tmp_path: Path, **extra) -> dict[str, str]:
    """An environment with a git identity so commits can be created."""
    return child_env(
        home,
        tmpdir=tmp_path / "tmp",
        GIT_AUTHOR_NAME="Tester",
        GIT_AUTHOR_EMAIL="tester@example.com",
        GIT_COMMITTER_NAME="Tester",
        GIT_COMMITTER_EMAIL="tester@example.com",
        **extra,
    )


@pytest.fixture
def home(tmp_path: Path) -> Path:
    """An empty home directory with a scratch temp directory next to it."""
    home = tmp_path / "home"
    home.mkdir()
    (tmp_path / "tmp").mkdir(exist_ok=True)
    return home


@pytest.fixture
def binary_copy():
    """A runnable copy of the binary under test, in a neutral directory.

    chezmoi refuses to remove an executable whose path contains "test" (it
    assumes it is a `go test` binary), and pytest's own temporary tree always
    contains that substring, so the copy is placed in a private directory
    outside it and removed again afterwards.
    """
    directory = tempfile.mkdtemp(prefix="chezmoi-copy-")
    binary = Path(directory) / "chezmoi"
    binary.write_bytes(Path(EXECUTABLE).read_bytes())
    binary.chmod(0o755)
    try:
        yield binary
    finally:
        shutil.rmtree(directory, ignore_errors=True)


@pytest.fixture
def env(home: Path, tmp_path: Path) -> dict[str, str]:
    """The default pinned child environment."""
    return child_env(home, tmpdir=tmp_path / "tmp")


@pytest.fixture
def bin_dir(tmp_path: Path) -> Path:
    """A directory of fake commands prepended to PATH."""
    d = tmp_path / "bin"
    d.mkdir()
    return d


@pytest.fixture
def fake_bin(home: Path, tmp_path: Path, bin_dir: Path) -> tuple[dict[str, str], Path]:
    """An environment whose PATH starts with a directory of fake commands.

    Returns the environment and the directory in which the fakes record their
    arguments.
    """
    record = record_dir(tmp_path)
    e = child_env(
        home,
        tmpdir=tmp_path / "tmp",
        path=f"{bin_dir}:{SYSTEM_PATH}",
        RECORD_DIR=str(record),
    )
    return e, record


@pytest.fixture
def git_home(home: Path, tmp_path: Path) -> tuple[Path, dict[str, str]]:
    """A home directory whose source directory is an empty git repository."""
    sd = source_dir(home)
    sd.mkdir(parents=True)
    e = make_git_env(home, tmp_path)
    run_git(e, sd, "init", "--quiet")
    return home, e


def init_source_repo(env: dict[str, str], home: Path, files: dict[str, str]) -> Path:
    """Populate the source directory with files and an initial commit."""
    sd = source_dir(home)
    sd.mkdir(parents=True, exist_ok=True)
    run_git(env, sd, "init", "--quiet", "-b", "main")
    for rel_path, contents in files.items():
        target = sd / rel_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(contents)
    run_git(env, sd, "add", ".")
    run_git(env, sd, "commit", "--quiet", "--allow-empty", "-m", "initial")
    return sd


def make_remote(tmp_path: Path, env: dict[str, str], files: dict[str, str], name: str = "remote.git") -> Path:
    """Create a bare repository containing files and return its path."""
    work = tmp_path / (name.removesuffix(".git") + "-seed")
    work.mkdir(parents=True, exist_ok=True)
    run_git(env, work, "init", "--quiet", "-b", "main")
    for rel_path, contents in files.items():
        target = work / rel_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(contents)
    run_git(env, work, "add", ".")
    run_git(env, work, "commit", "--quiet", "-m", "initial")
    remote = tmp_path / name
    run_git(env, work, "clone", "--quiet", "--bare", str(work), str(remote))
    return remote


def commit_to_remote(env: dict[str, str], remote: Path, files: dict[str, str], message: str) -> None:
    """Add a commit to a bare repository through a temporary clone."""
    work = remote.parent / (remote.name.removesuffix(".git") + "-work")
    if work.exists():
        shutil.rmtree(work)
    run_git(env, remote.parent, "clone", "--quiet", str(remote), str(work))
    for rel_path, contents in files.items():
        target = work / rel_path
        target.parent.mkdir(parents=True, exist_ok=True)
        if contents is None:
            target.unlink(missing_ok=True)
        else:
            target.write_text(contents)
    run_git(env, work, "add", "-A")
    run_git(env, work, "commit", "--quiet", "-m", message)
    run_git(env, work, "push", "--quiet", "origin", "HEAD:main")


def doctor_lines(result: Result) -> dict[str, str]:
    """Parse doctor's RESULT/CHECK/MESSAGE table into a check->message map."""
    lines = {}
    for line in result.stdout.splitlines():
        parts = line.split(None, 2)
        if len(parts) == 3 and line.startswith(("ok", "warning", "error", "info", "skipped", "failed")):
            lines[parts[1]] = line
    return lines


def jsonify(value) -> str:
    return json.dumps(value)


# ---------------------------------------------------------------------------
# A loopback HTTPS proxy with which `chezmoi upgrade`'s GitHub traffic can be
# answered without any real network access. The child process is pointed at
# the proxy with HTTPS_PROXY and trusts its certificate through SSL_CERT_FILE
# (both standard behavior of the reference binary's HTTP stack); every byte
# then stays on 127.0.0.1.

UPGRADE_RELEASE_TAG = "v2.60.0"
UPGRADE_CHECKSUMS_ASSET = "chezmoi_2.60.0_checksums.txt"
UPGRADE_MUSL_ASSET = "chezmoi_2.60.0_linux-musl_amd64.tar.gz"
UPGRADE_GLIBC_ASSET = "chezmoi_2.60.0_linux-glibc_amd64.tar.gz"
UPGRADE_PLAIN_ASSET = "chezmoi_2.60.0_linux_amd64.tar.gz"
UPGRADE_DEB_ASSET = "chezmoi_2.60.0_linux_amd64.deb"
UPGRADE_API_PATH = "/repos/twpayne/chezmoi/releases/latest"
UPGRADE_DOWNLOAD_BASE = (
    "https://github.com/twpayne/chezmoi/releases/download/v2.60.0"
)

# The "executable" inside a fake release archive: a shell script whose
# `--version` output is trivially recognisable in chezmoi's stdout.
FAKE_UPGRADED_BINARY = b"#!/bin/sh\necho 'fake-upgraded-chezmoi 2.60.0'\n"
FAKE_DEB_DATA = b"FAKE DEB CONTENT"

# Fake commands placed on the child's $PATH. They record their arguments (one
# file per argument) in $RECORD_DIR and print a fixed line, since chezmoi
# streams a run command's stdout/stderr straight into its own. Tool paths are
# absolute so the fakes keep working when $PATH holds only their directory.
_RECORDER_BODY = """#!/bin/sh
d="${RECORD_DIR:?}"
/usr/bin/mkdir -p "$d"
i=0
for a in "$@"; do
    i=$((i+1))
    printf '%s' "$a" > "$d/arg$i"
done
printf '%s\\n' "$i" > "$d/count"
"""
FAKE_BREW = _RECORDER_BODY + "echo 'fake-brew-ran'\n"
FAKE_SNAP = _RECORDER_BODY + "echo 'fake-snap-ran'\n"
FAKE_DPKG = _RECORDER_BODY + """if [ "$1" = "-i" ] && [ -f "$2" ]; then
    /usr/bin/cp "$2" "$d/package-copy"
    /usr/bin/stat -c '%a' "$2" > "$d/pkg-mode"
fi
echo 'fake-dpkg-ran'
"""
FAKE_SUDO = (
    _RECORDER_BODY.replace("${RECORD_DIR:?}", "${RECORD_DIR:?}/sudo")
    + "echo 'fake-sudo-ran'\n"
)
FAKE_FAILING_INSTALLER = "#!/bin/sh\nexit 3\n"
FAKE_LDD_OK = "#!/bin/sh\nexit 0\n"
FAKE_LDD_FAIL = "#!/bin/sh\nexit 1\n"
FAKE_PATH_CHEZMOI = "#!/bin/sh\necho 'fake-path-chezmoi-ran'\n"


class _ConnectionClosed(Exception):
    """Raised when a proxy connection ends before a full request arrives."""


def _read_head(sock, buffer: bytes) -> tuple[bytes, bytes]:
    """Read from sock until a complete request header block is buffered."""
    while b"\r\n\r\n" not in buffer:
        chunk = sock.recv(4096)
        if not chunk:
            raise _ConnectionClosed()
        buffer += chunk
    head, _, rest = buffer.partition(b"\r\n\r\n")
    return head, rest


class LoopbackHTTPSProxy:
    """A loopback proxy answering HTTPS CONNECTs from canned routes.

    ``routes`` maps a URL path to the response body served for it (any other
    path gets a 404). ``requests`` records ``(method, path)`` for every
    request the binary made, in order, so tests can pin exactly which URLs
    were fetched.
    """

    def __init__(self, cert: Path, key: Path, ca: Path):
        self.ca = ca
        self.routes: dict[str, bytes] = {}
        self.requests: list[tuple[str, str]] = []
        self._requests_lock = threading.Lock()
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(cert), str(key))
        self._tls = context
        self._listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._listener.bind(("127.0.0.1", 0))
        self._listener.listen(16)
        self.port = self._listener.getsockname()[1]
        threading.Thread(target=self._accept_loop, daemon=True).start()

    @property
    def url(self) -> str:
        """The proxy URL to hand to the child through HTTPS_PROXY."""
        return f"http://127.0.0.1:{self.port}"

    def requested_paths(self) -> list[str]:
        """Every request path the binary asked for, in order."""
        with self._requests_lock:
            return [path for _, path in self.requests]

    def close(self) -> None:
        self._listener.close()

    def _accept_loop(self) -> None:
        while True:
            try:
                conn, _ = self._listener.accept()
            except OSError:
                return
            threading.Thread(target=self._serve_connection, args=(conn,), daemon=True).start()

    def _serve_connection(self, conn: socket.socket) -> None:
        try:
            conn.settimeout(30)
            try:
                head, _ = _read_head(conn, b"")
            except _ConnectionClosed:
                return
            if not head.startswith(b"CONNECT "):
                return
            conn.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")
            tls = self._tls.wrap_socket(conn, server_side=True)
            buffer = b""
            while True:
                try:
                    head, buffer = _read_head(tls, buffer)
                except _ConnectionClosed:
                    return
                parts = head.split(b"\r\n")[0].split(b" ")
                method, path = parts[0].decode(), parts[1].decode()
                with self._requests_lock:
                    self.requests.append((method, path))
                body = self.routes.get(path)
                if body is None:
                    status, body = "404 Not Found", b"not found\n"
                else:
                    status = "200 OK"
                tls.sendall(
                    (
                        f"HTTP/1.1 {status}\r\n"
                        "Content-Type: application/octet-stream\r\n"
                        f"Content-Length: {len(body)}\r\n"
                        "Connection: keep-alive\r\n"
                        "\r\n"
                    ).encode()
                    + body
                )
        except OSError:
            pass


def tar_gz_executable(script: bytes) -> bytes:
    """Build a release archive whose single `chezmoi` entry holds script."""
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.GNU_FORMAT) as archive:
        info = tarfile.TarInfo("chezmoi")
        info.size = len(script)
        info.mode = 0o755
        archive.addfile(info, io.BytesIO(script))
    # A pinned gzip mtime keeps the archive, and so its checksum, stable.
    return gzip.compress(raw.getvalue(), mtime=0)


@dataclass
class FakeRelease:
    """The artifacts served for the canned release."""

    archive: bytes
    deb: bytes


def _download_path(asset: str) -> str:
    return f"/twpayne/chezmoi/releases/download/v2.60.0/{asset}"


def serve_release(
    proxy: LoopbackHTTPSProxy,
    *,
    script: bytes = FAKE_UPGRADED_BINARY,
    deb_data: bytes = FAKE_DEB_DATA,
    checksums: str = "correct",
    include_archives: bool = True,
    include_checksums: bool = True,
    include_deb: bool = True,
    drop_downloads: tuple[str, ...] = (),
) -> FakeRelease:
    """Install a canned v2.60.0 GitHub release into the proxy's routes.

    checksums selects what checksums.txt claims: "correct" (real SHA-256
    hashes), "zeros" (hashes that never match) or "unrelated" (no entry for
    any archive). drop_downloads lists assets that stay in the release but
    whose download URL answers 404.
    """
    archive = tar_gz_executable(script)
    assets: dict[str, str] = {}
    if include_checksums:
        assets[UPGRADE_CHECKSUMS_ASSET] = f"{UPGRADE_DOWNLOAD_BASE}/{UPGRADE_CHECKSUMS_ASSET}"
    archive_names = (
        UPGRADE_MUSL_ASSET,
        UPGRADE_GLIBC_ASSET,
        UPGRADE_PLAIN_ASSET,
    )
    if include_archives:
        for name in archive_names:
            assets[name] = f"{UPGRADE_DOWNLOAD_BASE}/{name}"
    if include_deb:
        assets[UPGRADE_DEB_ASSET] = f"{UPGRADE_DOWNLOAD_BASE}/{UPGRADE_DEB_ASSET}"

    if checksums == "correct":
        entries = [(name, archive) for name in archive_names]
        if include_deb:
            entries.append((UPGRADE_DEB_ASSET, deb_data))
        sums = "".join(f"{hashlib.sha256(data).hexdigest()}  {name}\n" for name, data in entries)
    elif checksums == "zeros":
        sums = "".join(f"{'0' * 64}  {name}\n" for name in assets if name != UPGRADE_CHECKSUMS_ASSET)
    else:  # "unrelated"
        sums = f"{hashlib.sha256(b'unrelated').hexdigest()}  other-file.txt\n"

    routes = {
        UPGRADE_API_PATH: json.dumps(
            {
                "name": UPGRADE_RELEASE_TAG,
                "tag_name": UPGRADE_RELEASE_TAG,
                "assets": [
                    {"name": name, "browser_download_url": url}
                    for name, url in assets.items()
                ],
            }
        ).encode(),
    }
    if include_checksums:
        routes[_download_path(UPGRADE_CHECKSUMS_ASSET)] = sums.encode()
    if include_archives:
        for name in archive_names:
            routes[_download_path(name)] = archive
    if include_deb:
        routes[_download_path(UPGRADE_DEB_ASSET)] = deb_data
    for name in drop_downloads:
        routes.pop(_download_path(name), None)

    proxy.routes = routes
    proxy.requests.clear()
    return FakeRelease(archive=archive, deb=deb_data)


@pytest.fixture(scope="session")
def tls_ca():
    """A CA and a server certificate for the GitHub hostnames, via openssl.

    The certificate is generated once per worker into a world-readable
    directory outside pytest's own temporary tree: tests that drop privileges
    to another uid must be able to read the CA through SSL_CERT_FILE, and
    every directory of pytest's tree is mode 0700.
    """
    if shutil.which("openssl") is None:
        pytest.skip("openssl is required to serve fake HTTPS endpoints")
    directory = Path(tempfile.mkdtemp(prefix="chezmoi-tls-"))
    ca_key, ca_pem = directory / "ca.key", directory / "ca.pem"
    server_key, server_csr, server_pem = (
        directory / "srv.key",
        directory / "srv.csr",
        directory / "srv.pem",
    )
    extensions = directory / "ext.cnf"
    extensions.write_text(
        "subjectAltName=DNS:api.github.com,DNS:github.com,"
        "DNS:objects.githubusercontent.com\n"
    )
    try:
        for args in (
            [
                "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(ca_key), "-out", str(ca_pem),
                "-subj", "/CN=chezmoi-test-ca", "-days", "2",
            ],
            [
                "req", "-new", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(server_key), "-out", str(server_csr),
                "-subj", "/CN=api.github.com",
            ],
            [
                "x509", "-req", "-in", str(server_csr),
                "-CA", str(ca_pem), "-CAkey", str(ca_key), "-CAcreateserial",
                "-out", str(server_pem), "-extfile", str(extensions), "-days", "2",
            ],
        ):
            subprocess.run(
                ["openssl", *args], check=True, capture_output=True, timeout=60
            )
        os.chmod(directory, 0o755)
        os.chmod(ca_pem, 0o644)
        yield SimpleNamespace(ca=ca_pem, cert=server_pem, key=server_key)
    finally:
        shutil.rmtree(directory, ignore_errors=True)


@pytest.fixture
def github_proxy(tls_ca: SimpleNamespace) -> LoopbackHTTPSProxy:
    """A loopback HTTPS proxy the binary under test can be pointed at."""
    proxy = LoopbackHTTPSProxy(tls_ca.cert, tls_ca.key, tls_ca.ca)
    yield proxy
    proxy.close()


@dataclass
class NonrootTree:
    """A scratch tree that an unprivileged user can read, write and run in."""

    root: Path
    home: Path
    tmp: Path
    bin: Path
    record: Path
    exe: Path
    target: Path


@pytest.fixture
def nonroot_tree():
    """Build nonroot_tree outside pytest's own temporary tree.

    The sudo-prefixed upgrade methods only appear for a non-root caller, so
    some tests run the binary as uid 1000. pytest's tmp_path (and every
    directory above it) is mode 0700, which such a child cannot even
    traverse, so this fixture builds an equivalent world-accessible tree
    under /tmp instead and removes it afterwards.
    """
    root = Path(tempfile.mkdtemp(prefix="chezmoi-nonroot-"))
    tree = NonrootTree(
        root=root,
        home=root / "home",
        tmp=root / "tmp",
        bin=root / "bin",
        record=root / "record",
        exe=root / "chezmoi-copy",
        target=root / "elsewhere" / "chezmoi",
    )
    for directory in (tree.home, tree.tmp, tree.bin, tree.record, tree.target.parent):
        directory.mkdir(parents=True)
    for binary in (tree.exe, tree.target):
        binary.write_bytes(Path(EXECUTABLE).read_bytes())
        binary.chmod(0o755)
    for directory, mode in (
        (root, 0o755),
        (tree.target.parent, 0o755),
        (tree.bin, 0o755),
        # The unprivileged child creates its HTTP cache under $HOME and its
        # package temporary directory under $TMPDIR, and the fake commands
        # record their arguments in $RECORD_DIR.
        (tree.home, 0o777),
        (tree.tmp, 0o777),
        (tree.record, 0o777),
    ):
        os.chmod(directory, mode)
    try:
        yield tree
    finally:
        shutil.rmtree(root, ignore_errors=True)


def _os_release_fields() -> dict[str, str]:
    """Parse the fields of the machine's os-release file, if any."""
    fields: dict[str, str] = {}
    for candidate in (Path("/etc/os-release"), Path("/usr/lib/os-release")):
        if candidate.exists():
            for line in candidate.read_text().splitlines():
                key, separator, value = line.partition("=")
                if separator:
                    fields[key.strip()] = value.strip().strip('"')
            break
    return fields


@pytest.fixture
def deb_distro():
    """Skip when the machine is not deb-based.

    The package upgrade tests serve a .deb release asset and fake dpkg,
    matching the reference behavior recorded on this suite's Ubuntu image;
    on another distribution chezmoi would name and install a different
    package.
    """
    fields = _os_release_fields()
    ids = [fields.get("ID", ""), *fields.get("ID_LIKE", "").split()]
    if not any(dist in ("debian", "ubuntu") for dist in ids):
        pytest.skip(f"deb-based distribution required, got ID={fields.get('ID')!r}")
