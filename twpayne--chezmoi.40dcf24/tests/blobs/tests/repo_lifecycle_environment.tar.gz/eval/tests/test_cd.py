"""Tests for `chezmoi cd`: launching a shell in the working tree.

Every test uses a fake shell (a script on $SHELL or cd.command) that records
its working directory, environment and arguments, so the exact directory the
shell lands in, the variables it sees and the command line it was started with
are all observable without a TTY.
"""

from __future__ import annotations

import pytest

from conftest import (
    SYSTEM_PATH,
    child_env,
    make_git_env,
    run_chezmoi,
    run_git,
    source_dir,
    write_script,
)

# The fake shell used for most tests: it records its state in $RECORD_DIR,
# prints one line on each stream, and exits 0.
FAKE_SHELL = """#!/bin/sh
{
    printf 'PWD=%s\\n' "$PWD"
    printf 'SUBSHELL=%s\\n' "$CHEZMOI_SUBSHELL"
    printf 'CHEZMOI=%s\\n' "$CHEZMOI"
    printf 'NARGS=%s\\n' "$#"
    printf 'ARGV0=%s\\n' "$0"
    for a in "$@"; do
        printf 'ARG=%s\\n' "$a"
    done
} > "${RECORD_DIR:?}/shell.txt"
echo shell-stdout-marker
echo shell-stderr-marker >&2
"""

# Prints only the deterministic CHEZMOI* variables it was given.
ENV_SHELL = """#!/bin/sh
env | grep -E '^(CHEZMOI|CHEZMOI_COMMAND|CHEZMOI_CONFIG_FILE|CHEZMOI_DEST_DIR|CHEZMOI_HOME_DIR|CHEZMOI_SOURCE_DIR|CHEZMOI_SUBSHELL|CHEZMOI_WORKING_TREE)=' | sort
"""


def run(env, *args, **kwargs):
    return run_chezmoi(["cd", *args], env=env, **kwargs)


def cd_env(home, tmp_path, shell, **extra):
    """The pinned child environment with $SHELL pointing at the fake shell."""
    return child_env(home, tmpdir=tmp_path / "tmp", shell=str(shell), **extra)


def shell_state(record):
    """Parse the fake shell's recorded state into a dict.

    The ARG=<value> lines repeat once per argument; they are collected under
    the single key "ARG" as a list.
    """
    lines = (record / "shell.txt").read_text().splitlines()
    state: dict[str, object] = {}
    args: list[str] = []
    for line in lines:
        key, sep, value = line.partition("=")
        if not sep:
            continue
        if key == "ARG":
            args.append(value)
        else:
            state[key] = value
    if args:
        state["ARG"] = args
    return state


def make_source_tree(home, env):
    """Create a source directory with a managed file and two directories.

    A git repository is initialized only so the working-tree detection sees a
    conventional layout; the entries themselves need no commits.
    """
    sd = source_dir(home)
    (sd / "dot_config").mkdir(parents=True)
    (sd / "dot_config" / "foo.txt").write_text("foo\n")
    (sd / "exact_dot_edir").mkdir()
    (sd / "exact_dot_edir" / "e.txt").write_text("e\n")
    (sd / "dot_vimrc").write_text("vimrc-content\n")
    run_git(env, sd, "init", "--quiet", "-b", "main")
    return sd


class TestCDBasics:
    def test_cd_spawns_shell_in_source_directory(self, home, tmp_path, bin_dir):
        """cd spawns $SHELL in the source directory with CHEZMOI_SUBSHELL=1."""
        # CATCHES: the shell runs with the source directory as its cwd (not
        # the destination or the caller's cwd), the CHEZMOI_SUBSHELL variable
        # is exported to it, and both of its output streams pass through
        # chezmoi unchanged.
        record = tmp_path / "record"
        record.mkdir()
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        e = cd_env(home, tmp_path, shell, RECORD_DIR=str(record))

        result = run(e)

        assert result.returncode == 0
        assert result.stdout == "shell-stdout-marker\n"
        assert result.stderr == "shell-stderr-marker\n"
        assert shell_state(record) == {
            "PWD": str(sd),
            "SUBSHELL": "1",
            "CHEZMOI": "1",
            "NARGS": "0",
            "ARGV0": str(shell),
        }

    def test_cd_passes_stdin_to_shell(self, home, tmp_path):
        """the spawned shell inherits chezmoi's stdin."""
        # CATCHES: stdin is wired straight through to the child, so a
        # non-interactive `sh` reads its commands from the caller's pipe.
        env = make_git_env(home, tmp_path)
        make_source_tree(home, env)

        result = run_chezmoi(
            ["cd"], env=child_env(home, tmpdir=tmp_path / "tmp", shell="/bin/sh"),
            stdin=b"echo line-from-stdin\n",
        )

        assert result.returncode == 0
        assert result.stdout == "line-from-stdin\n"
        assert result.stderr == ""

    def test_cd_subshell_environment_variables(self, home, tmp_path, bin_dir):
        """the subshell sees the chezmoi directory variables."""
        # CATCHES: cd exports the full set of CHEZMOI* directory variables,
        # including CHEZMOI_SOURCE_DIR and CHEZMOI_WORKING_TREE both pointing
        # at the source directory and CHEZMOI_COMMAND naming the command.
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        shell = write_script(bin_dir / "envshell", ENV_SHELL)
        e = child_env(home, tmpdir=tmp_path / "tmp", shell=str(shell))

        result = run(e)

        assert result.returncode == 0
        assert result.stdout.splitlines() == [
            "CHEZMOI=1",
            "CHEZMOI_COMMAND=cd",
            f"CHEZMOI_CONFIG_FILE={home}/.config/chezmoi/chezmoi.toml",
            f"CHEZMOI_DEST_DIR={home}",
            f"CHEZMOI_HOME_DIR={home}",
            f"CHEZMOI_SOURCE_DIR={sd}",
            "CHEZMOI_SUBSHELL=1",
            f"CHEZMOI_WORKING_TREE={sd}",
        ]

    def test_cd_shell_nonzero_exit_is_an_error(self, home, tmp_path, bin_dir):
        """a shell exiting nonzero makes cd fail with a wrapped error."""
        # CATCHES: the child's exit status is not passed through; cd exits 1
        # and reports the resolved shell path alongside the status.
        env = make_git_env(home, tmp_path)
        make_source_tree(home, env)
        shell = write_script(bin_dir / "exit7shell", "#!/bin/sh\nexit 7\n")
        e = cd_env(home, tmp_path, shell)

        result = run(e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == f"chezmoi: {shell}: exit status 7\n"

    def test_cd_error_reports_configured_command_name(self, home, tmp_path, bin_dir):
        """a failing cd.command is named verbatim, not as its resolved path."""
        # CATCHES: when cd.command is a bare name resolved through $PATH, the
        # error message still uses the configured name, unlike the $SHELL
        # case which reports the absolute path.
        env = make_git_env(home, tmp_path)
        make_source_tree(home, env)
        write_script(bin_dir / "exit7bare", "#!/bin/sh\nexit 7\n")
        (home / ".config" / "chezmoi").mkdir(parents=True)
        (home / ".config" / "chezmoi" / "chezmoi.toml").write_text(
            '[cd]\n    command = "exit7bare"\n'
        )
        e = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{bin_dir}:{SYSTEM_PATH}",
            shell="/bin/bash",
        )

        result = run(e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: exit7bare: exit status 7\n"


class TestCDCdCommand:
    def test_cd_command_and_args_from_config(self, home, tmp_path, bin_dir):
        """cd.command and cd.args replace the shell and add arguments."""
        # CATCHES: cd.command wins over $SHELL even when $SHELL names a real
        # shell, a bare command name is resolved through $PATH, and cd.args
        # are appended as individual arguments.
        record = tmp_path / "record"
        record.mkdir()
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        (home / ".config" / "chezmoi").mkdir(parents=True)
        (home / ".config" / "chezmoi" / "chezmoi.toml").write_text(
            '[cd]\n    command = "fakeshell"\n    args = ["--login", "-i"]\n'
        )
        e = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{bin_dir}:{SYSTEM_PATH}",
            shell="/bin/bash",
            RECORD_DIR=str(record),
        )

        result = run(e)

        assert result.returncode == 0
        state = shell_state(record)
        assert state["PWD"] == str(sd)
        assert state["ARGV0"] == str(shell)
        assert state["NARGS"] == "2"
        assert state["ARG"] == ["--login", "-i"]

    def test_cd_args_merge_with_detected_shell(self, home, tmp_path, bin_dir):
        """cd.args are passed to the detected $SHELL when command is unset."""
        # CATCHES: cd.args apply to the shell detected from $SHELL too, so a
        # login-shell flag can be added without replacing the shell itself.
        record = tmp_path / "record"
        record.mkdir()
        env = make_git_env(home, tmp_path)
        make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        (home / ".config" / "chezmoi").mkdir(parents=True)
        (home / ".config" / "chezmoi" / "chezmoi.toml").write_text(
            '[cd]\n    args = ["--login", "--norc"]\n'
        )
        e = cd_env(home, tmp_path, shell, RECORD_DIR=str(record))

        result = run(e)

        assert result.returncode == 0
        state = shell_state(record)
        assert state["ARGV0"] == str(shell)
        assert state["NARGS"] == "2"
        assert state["ARG"] == ["--login", "--norc"]

    def test_cd_command_with_spaces_is_not_shell_parsed(self, home, tmp_path):
        """a cd.command containing spaces is one command name, not a line."""
        # CATCHES: unlike $SHELL (which is split on whitespace), cd.command is
        # used verbatim, so "echo hello" is looked up as a single program name
        # and fails with the exec-not-found error.
        env = make_git_env(home, tmp_path)
        make_source_tree(home, env)
        (home / ".config" / "chezmoi").mkdir(parents=True)
        (home / ".config" / "chezmoi" / "chezmoi.toml").write_text(
            '[cd]\n    command = "echo hello-not-run"\n'
        )
        e = child_env(home, tmpdir=tmp_path / "tmp")

        result = run(e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: echo hello-not-run: exec: "echo hello-not-run": '
            "executable file not found in $PATH\n"
        )

    def test_cd_shell_with_spaces_is_split(self, home, tmp_path, bin_dir):
        """a $SHELL value containing spaces is split into command and args."""
        # CATCHES: when $SHELL does not name an existing file, its value is
        # parsed like a shell command line: the first word is the program and
        # the remaining words become its arguments.
        env = make_git_env(home, tmp_path)
        make_source_tree(home, env)
        shell = write_script(
            bin_dir / "spacedshell",
            '#!/bin/sh\nprintf "nargs=%s\\n" "$#"\nfor a in "$@"; do printf "arg:%s\\n" "$a"; done\n',
        )
        e = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            shell=f"{shell} -c echo-hi",
            path=f"{bin_dir}:{SYSTEM_PATH}",
        )

        result = run(e)

        assert result.returncode == 0
        assert result.stdout == "nargs=2\narg:-c\narg:echo-hi\n"

    @pytest.mark.parametrize(
        "shell_value,expected_stderr",
        [
            pytest.param(
                None,
                'chezmoi: no-such-cd-command: exec: "no-such-cd-command": '
                "executable file not found in $PATH\n",
                id="missing-command",
            ),
            pytest.param("", "chezmoi: : exec: no command\n", id="empty-shell"),
        ],
    )
    def test_cd_unresolvable_command_errors(
        self, home, tmp_path, shell_value, expected_stderr
    ):
        """an unresolvable cd command is reported as a chezmoi error."""
        # CATCHES: a cd.command absent from $PATH and an empty $SHELL value
        # both abort with exit status 1 and chezmoi's exec wrapping, with no
        # shell ever started.
        env = make_git_env(home, tmp_path)
        make_source_tree(home, env)
        if shell_value is None:
            (home / ".config" / "chezmoi").mkdir(parents=True)
            (home / ".config" / "chezmoi" / "chezmoi.toml").write_text(
                '[cd]\n    command = "no-such-cd-command"\n'
            )
            e = child_env(home, tmpdir=tmp_path / "tmp")
        else:
            e = child_env(home, tmpdir=tmp_path / "tmp", shell=shell_value)

        result = run(e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == expected_stderr


class TestCDShellResolution:
    def test_cd_shell_from_passwd_database_when_unset(self, home, tmp_path, bin_dir):
        """without $SHELL the shell comes from the passwd database."""
        # CATCHES: the reference binary is built without cgo, so the fallback
        # shell is looked up by running `getent passwd <user>` from $PATH; a
        # fake getent therefore selects which program cd runs.
        record = tmp_path / "record"
        record.mkdir()
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        write_script(
            bin_dir / "getent",
            f'#!/bin/sh\n[ "$1 $2" = "passwd root" ] && echo "root:x:0:0:root:/root:{shell}"\nexit 0\n',
        )
        e = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{bin_dir}:{SYSTEM_PATH}",
            RECORD_DIR=str(record),
            SHELL=None,
        )

        result = run(e)

        assert result.returncode == 0
        assert result.stdout == "shell-stdout-marker\n"
        assert shell_state(record)["PWD"] == str(sd)


class TestCDArguments:
    @pytest.mark.parametrize(
        "arg_factory",
        [
            pytest.param(lambda home: str(home), id="absolute-home"),
            pytest.param(lambda home: ".", id="dot-from-home"),
        ],
    )
    def test_cd_dest_dir_argument_maps_to_source_dir(
        self, home, tmp_path, bin_dir, arg_factory
    ):
        """an argument naming the destination directory means the source dir."""
        # CATCHES: cd treats the destination directory itself as a request for
        # the source directory, whether given absolutely or as "." from a cwd
        # inside the destination.
        record = tmp_path / "record"
        record.mkdir()
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        e = cd_env(home, tmp_path, shell, RECORD_DIR=str(record))

        result = run(e, arg_factory(home), cwd=home)

        assert result.returncode == 0
        assert shell_state(record)["PWD"] == str(sd)

    @pytest.mark.parametrize(
        "target,source_entry",
        [
            pytest.param(".config", "dot_config", id="dot-config"),
            pytest.param(".edir", "exact_dot_edir", id="exact-dir"),
        ],
    )
    def test_cd_target_dir_argument(self, home, tmp_path, bin_dir, target, source_entry):
        """a managed directory argument resolves to its source entry."""
        # CATCHES: the argument is interpreted as a *target* path and mapped
        # back to the corresponding source-state entry (dot_ and exact_
        # prefixes included), whose directory becomes the shell's cwd.
        record = tmp_path / "record"
        record.mkdir()
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        e = cd_env(home, tmp_path, shell, RECORD_DIR=str(record))

        result = run(e, str(home / target))

        assert result.returncode == 0
        assert shell_state(record)["PWD"] == str(sd / source_entry)

    @pytest.mark.parametrize(
        "arg_factory",
        [
            pytest.param(lambda home: str(home / ".vimrc"), id="absolute"),
            pytest.param(lambda home: ".vimrc", id="relative-from-home"),
        ],
    )
    def test_cd_target_file_argument_is_not_a_directory(
        self, home, tmp_path, bin_dir, arg_factory
    ):
        """a managed *file* argument resolves to a path that is not a dir."""
        # CATCHES: the target-to-source mapping yields the source file itself
        # (dot_vimrc), and cd refuses it with "not a directory" instead of
        # cd-ing into its parent.
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        e = cd_env(home, tmp_path, shell)

        result = run(e, arg_factory(home), cwd=home)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == f"chezmoi: {sd}/dot_vimrc: not a directory\n"

    @pytest.mark.parametrize(
        "name",
        ["unmanaged", "outside-destination", "symlink-to-destination", "source-dir-itself"],
    )
    def test_cd_rejects_unresolvable_arguments(self, home, tmp_path, bin_dir, name):
        """arguments that are not managed targets are refused with errors."""
        # CATCHES: an unmanaged destination path reports "not managed", a
        # path outside the destination (including a symlink pointing into it)
        # reports "not in destination directory", and even the source
        # directory's own path is treated as a target and rejected.
        outside = tmp_path / "outside"
        outside.mkdir()
        (outside / "home-link").symlink_to(home, target_is_directory=True)
        record = tmp_path / "record"
        record.mkdir()
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        e = cd_env(home, tmp_path, shell, RECORD_DIR=str(record))
        if name == "unmanaged":
            arg, expected = str(home / "nope.txt"), f"chezmoi: {home}/nope.txt: not managed\n"
        elif name == "outside-destination":
            arg = str(outside)
            expected = f"chezmoi: {outside}: not in destination directory ({home})\n"
        elif name == "symlink-to-destination":
            arg = str(outside / "home-link")
            expected = (
                f"chezmoi: {outside}/home-link: not in destination directory ({home})\n"
            )
        else:
            arg, expected = str(sd), f"chezmoi: {sd}: not managed\n"

        result = run(e, arg)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == expected
        assert not (record / "shell.txt").exists()

    def test_cd_rejects_multiple_arguments(self, home, tmp_path, bin_dir):
        """cd accepts at most one argument."""
        # CATCHES: cobra's MaximumNArgs(1) check produces the standard
        # "accepts at most 1 arg(s), received 2" error, wrapped by chezmoi.
        env = make_git_env(home, tmp_path)
        make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        e = cd_env(home, tmp_path, shell)

        result = run(e, "one", "two")

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: accepts at most 1 arg(s), received 2\n"


class TestCDDirectories:
    def test_cd_creates_missing_source_directory(self, home, tmp_path, bin_dir):
        """cd creates the source directory when it does not exist yet."""
        # CATCHES: cd does not require an existing source directory; it makes
        # it first and then launches the shell inside the new directory.
        record = tmp_path / "record"
        record.mkdir()
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        e = cd_env(
            home,
            tmp_path,
            shell,
            path=f"{bin_dir}:{SYSTEM_PATH}",
            RECORD_DIR=str(record),
        )
        sd = source_dir(home)
        assert not sd.exists()

        result = run(e)

        assert result.returncode == 0
        assert result.stdout == "shell-stdout-marker\n"
        assert sd.is_dir()
        assert shell_state(record)["PWD"] == str(sd)

    def test_cd_source_dir_is_a_file(self, home, tmp_path, bin_dir):
        """a source directory path occupied by a file is a mkdir error."""
        # CATCHES: cd insists on creating the source directory itself, and a
        # regular file in its place surfaces as a "file exists" mkdir error
        # before any shell is started.
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        sd = source_dir(home)
        sd.parent.mkdir(parents=True)
        sd.write_text("not a directory\n")
        e = cd_env(home, tmp_path, shell, path=f"{bin_dir}:{SYSTEM_PATH}")

        result = run(e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == f"chezmoi: mkdir {sd}: file exists\n"

    @pytest.mark.parametrize(
        "git_parent,expected_pwd",
        [
            pytest.param("local-share", "local-share", id="git-above-source"),
            pytest.param("home", "source-dir", id="git-in-home-ignored"),
        ],
    )
    def test_cd_working_tree_discovery(
        self, home, tmp_path, bin_dir, git_parent, expected_pwd
    ):
        """the working tree is the nearest repo above the source directory."""
        # CATCHES: cd launches the shell in the *working tree*, which is the
        # closest ancestor of the source directory containing .git — but the
        # home directory itself is never chosen, so a repo in $HOME leaves the
        # shell in the source directory.
        record = tmp_path / "record"
        record.mkdir()
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / "dot_vimrc").write_text("vimrc\n")
        (home / ".local" / "share").mkdir(parents=True, exist_ok=True)
        if git_parent == "local-share":
            (home / ".local" / "share" / ".git").mkdir()
            expected = home / ".local" / "share"
        else:
            (home / ".git").mkdir()
            expected = sd
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        e = cd_env(
            home,
            tmp_path,
            shell,
            path=f"{bin_dir}:{SYSTEM_PATH}",
            RECORD_DIR=str(record),
        )

        result = run(e)

        assert result.returncode == 0
        assert shell_state(record)["PWD"] == str(expected)

    def test_cd_working_tree_flag(self, home, tmp_path, bin_dir):
        """-W/--working-tree overrides the discovered working tree."""
        # CATCHES: -W selects the directory the shell lands in, and when the
        # source directory is not inside it, cd refuses with "not in".
        record = tmp_path / "record"
        record.mkdir()
        env = make_git_env(home, tmp_path)
        sd = make_source_tree(home, env)
        shell = write_script(bin_dir / "fakeshell", FAKE_SHELL)
        e = cd_env(
            home,
            tmp_path,
            shell,
            path=f"{bin_dir}:{SYSTEM_PATH}",
            RECORD_DIR=str(record),
        )

        result = run_chezmoi(["-W", str(home / ".local"), "cd"], env=e)

        assert result.returncode == 0
        assert shell_state(record)["PWD"] == str(home / ".local")

        result = run_chezmoi(["-W", str(home / "elsewhere"), "cd"], env=e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == f"chezmoi: {sd}: not in {home}/elsewhere\n"
