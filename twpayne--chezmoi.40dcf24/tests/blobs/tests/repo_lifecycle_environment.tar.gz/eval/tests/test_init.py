"""Tests for `chezmoi init`: source directory creation, cloning and config."""

from __future__ import annotations

import stat

import pytest

from conftest import (
    EXECUTABLE,
    _GIT_FAKE,
    child_env,
    init_source_repo,
    make_git_env,
    make_remote,
    run_chezmoi,
    source_dir,
    write_script,
)


CONFIG_TEMPLATE = '[data]\n    email = "{{ promptString "email" }}"\n'


def run(env, home, *args, **kwargs):
    return run_chezmoi(["init", *args], env=env, cwd=home, **kwargs)


def clone_env(home, tmp_path, bin_dir, record):
    """An environment using the argument-recording fake git."""
    write_script(bin_dir / "git", _GIT_FAKE)
    return child_env(
        home,
        tmpdir=tmp_path / "tmp",
        path=f"{bin_dir}:/usr/bin:/bin",
        RECORD_DIR=str(record),
    )


def clone_args(record):
    """The arguments of the single git clone recorded by the fake git."""
    return (record / "git.log").read_text().splitlines()[0].split(" ")


class TestInitBasics:
    def test_init_creates_git_source_directory(self, home, env):
        """init with no repo creates ~/.local/share/chezmoi as a git repo."""
        result = run(env, home)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        git_dir = source_dir(home) / ".git"
        assert git_dir.is_dir()
        assert (git_dir / "HEAD").is_file()

    def test_init_runs_git_init_quiet(self, home, tmp_path, bin_dir):
        """init with no repo invokes system git as `git init --quiet`."""
        record = tmp_path / "record"
        record.mkdir()
        e = clone_env(home, tmp_path, bin_dir, record)
        result = run(e, home)
        assert result.returncode == 0
        assert (record / "git.log").read_text().splitlines() == ["init --quiet"]

    def test_init_is_idempotent(self, home, tmp_path):
        """a second init does not re-initialize an existing working tree."""
        e = make_git_env(home, tmp_path)
        assert run(e, home).returncode == 0
        marker = source_dir(home) / "dot_marker"
        marker.write_text("kept\n")
        head_before = (source_dir(home) / ".git" / "HEAD").read_text()
        result = run(e, home)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert marker.read_text() == "kept\n"
        assert (source_dir(home) / ".git" / "HEAD").read_text() == head_before

    def test_init_clone_from_local_repository(self, home, tmp_path):
        """init <repo> clones the repository into the source directory."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(
            tmp_path,
            e,
            {"dot_dotfiles/README.md": "cloned contents\n"},
        )
        result = run(e, home, str(remote), "--guess-repo-url=false")
        assert result.returncode == 0
        assert (source_dir(home) / "dot_dotfiles" / "README.md").read_text() == "cloned contents\n"
        assert (source_dir(home) / ".git").is_dir()

    def test_init_clone_into_non_empty_directory_fails(self, home, tmp_path):
        """cloning into an existing non-empty source directory is an error."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(tmp_path, e, {"dot_a": "a\n"})
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / "junk").write_text("junk\n")
        result = run(e, home, str(remote), "--guess-repo-url=false")
        assert result.returncode == 1
        assert "already exists and is not an empty directory" in result.stderr
        assert "chezmoi: git: exit status 128" in result.stderr


class TestInitConfigFile:
    def test_init_creates_config_from_template(self, home, tmp_path):
        """a .chezmoi.toml.tmpl in the repo becomes ~/.config/chezmoi/chezmoi.toml."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(tmp_path, e, {".chezmoi.toml.tmpl": CONFIG_TEMPLATE})
        result = run(e, home, str(remote), "--guess-repo-url=false", "--promptString", "email=x@y.z")
        assert result.returncode == 0
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        assert config.read_text() == '[data]\n    email = "x@y.z"\n'
        assert stat.S_IMODE(config.stat().st_mode) == 0o600

    def test_init_config_path_flag(self, home, tmp_path):
        """--config-path writes the generated config elsewhere."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(tmp_path, e, {".chezmoi.toml.tmpl": CONFIG_TEMPLATE})
        custom = home / "generated.toml"
        result = run(
            e,
            home,
            str(remote),
            "--guess-repo-url=false",
            "--promptString",
            "email=x@y.z",
            "--config-path",
            str(custom),
        )
        assert result.returncode == 0
        assert custom.read_text() == '[data]\n    email = "x@y.z"\n'
        assert not (home / ".config" / "chezmoi" / "chezmoi.toml").exists()

    def test_init_prompt_reads_stdin_without_tty(self, home, tmp_path):
        """with --no-tty promptString reads its answer from stdin."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(tmp_path, e, {".chezmoi.toml.tmpl": CONFIG_TEMPLATE})
        result = run(
            e,
            home,
            str(remote),
            "--guess-repo-url=false",
            "--no-tty",
            stdin=b"from-stdin\n",
        )
        assert result.returncode == 0
        assert result.stdout == "email? "
        assert (home / ".config" / "chezmoi" / "chezmoi.toml").read_text() == (
            '[data]\n    email = "from-stdin"\n'
        )

    def test_init_prompt_without_tty_fails(self, home, tmp_path):
        """a prompt with no TTY and no answer aborts init with an error."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(tmp_path, e, {".chezmoi.toml.tmpl": CONFIG_TEMPLATE})
        result = run(e, home, str(remote), "--guess-repo-url=false")
        assert result.returncode == 1
        assert result.stderr.endswith(
            "chezmoi: template: chezmoi.toml:2:16: executing \"chezmoi.toml\" at "
            "<promptString \"email\">: error calling promptString: could not open a new TTY: "
            "open /dev/tty: no such device or address\n"
        )
        assert not (home / ".config" / "chezmoi" / "chezmoi.toml").exists()

    def test_init_prompt_flags(self, home, tmp_path):
        """--prompt* flags answer the matching prompts without interaction."""
        e = make_git_env(home, tmp_path)
        template = (
            "[data]\n"
            "    boolv = {{ promptBool \"Use bool?\" false }}\n"
            "    intv = {{ promptInt \"Pick int\" 42 }}\n"
            '    strv = "{{ promptString \"Give string\" \"dflt\" }}"\n'
            '    choicev = "{{ promptChoice \"Pick one\" (list \"a\" \"b\" \"c\") }}"\n'
        )
        remote = make_remote(tmp_path, e, {".chezmoi.toml.tmpl": template})
        result = run(
            e,
            home,
            str(remote),
            "--guess-repo-url=false",
            "--promptBool",
            "Use bool?=true",
            "--promptInt",
            "Pick int=7",
            "--promptString",
            "Give string=hello",
            "--promptChoice",
            "Pick one=b",
        )
        assert result.returncode == 0
        assert (home / ".config" / "chezmoi" / "chezmoi.toml").read_text() == (
            '[data]\n    boolv = true\n    intv = 7\n    strv = "hello"\n    choicev = "b"\n'
        )

    def test_init_prompt_defaults(self, home, tmp_path):
        """--promptDefaults makes prompt functions return their defaults."""
        e = make_git_env(home, tmp_path)
        template = (
            "[data]\n"
            "    boolv = {{ promptBool \"Use bool?\" false }}\n"
            "    intv = {{ promptInt \"Pick int\" 42 }}\n"
            '    strv = "{{ promptString \"Give string\" \"dflt\" }}"\n'
        )
        remote = make_remote(tmp_path, e, {".chezmoi.toml.tmpl": template})
        result = run(e, home, str(remote), "--guess-repo-url=false", "--promptDefaults")
        assert result.returncode == 0
        assert (home / ".config" / "chezmoi" / "chezmoi.toml").read_text() == (
            '[data]\n    boolv = false\n    intv = 42\n    strv = "dflt"\n'
        )

    def test_init_prompt_bool_rejects_invalid_value(self, home, tmp_path):
        """an unparsable --promptBool value is reported as a template error."""
        e = make_git_env(home, tmp_path)
        template = "[data]\n    boolv = {{ promptBool \"Use bool?\" false }}\n"
        remote = make_remote(tmp_path, e, {".chezmoi.toml.tmpl": template})
        result = run(
            e,
            home,
            str(remote),
            "--guess-repo-url=false",
            "--promptBool",
            "Use bool?=notabool",
        )
        assert result.returncode == 1
        assert (
            "error calling promptBool: strconv.ParseBool: parsing \"notabool\": invalid syntax"
            in result.stderr
        )


class TestInitPurge:
    def test_init_purge_force(self, home, tmp_path):
        """--purge --force removes the config, source dir and working tree."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(
            tmp_path,
            e,
            {".chezmoi.toml.tmpl": CONFIG_TEMPLATE, "dot_dotfiles/README.md": "contents\n"},
        )
        result = run(
            e,
            home,
            str(remote),
            "--guess-repo-url=false",
            "--promptString",
            "email=x@y.z",
            "--apply",
            "--purge",
            "--force",
        )
        assert result.returncode == 0
        assert not (home / ".config" / "chezmoi").exists()
        assert not source_dir(home).exists()
        # the destination directory is not purged
        assert (home / ".dotfiles" / "README.md").read_text() == "contents\n"

    def test_init_one_shot(self, home, tmp_path, binary_copy):
        """--one-shot applies, purges everything and removes the binary."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(
            tmp_path,
            e,
            {".chezmoi.toml.tmpl": CONFIG_TEMPLATE, "dot_dotfiles/README.md": "one-shot\n"},
        )
        result = run(
            e,
            home,
            str(remote),
            "--guess-repo-url=false",
            "--promptString",
            "email=x@y.z",
            "--one-shot",
            exe=str(binary_copy),
        )
        assert result.returncode == 0
        assert not binary_copy.exists()
        assert not source_dir(home).exists()
        assert not (home / ".config" / "chezmoi").exists()
        assert (home / ".dotfiles" / "README.md").read_text() == "one-shot\n"


class TestInitFlags:
    @pytest.mark.parametrize(
        "flags",
        [
            ["--branch", "devel", "--tag", "v1"],
            ["--branch", "devel", "--revision", "abc123"],
            ["--tag", "v1", "--revision", "abc123"],
            ["--branch", "a", "--tag", "b", "--revision", "c"],
        ],
        ids=["branch+tag", "branch+revision", "tag+revision", "all-three"],
    )
    def test_init_rejects_multiple_revision_flags(self, home, env, flags):
        """--branch, --revision and --tag are mutually exclusive."""
        result = run(env, home, *flags)
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: the --branch, --revision, and --tag flags are mutally exclusive\n"
        )

    @pytest.mark.parametrize(
        ("repo", "expected"),
        [
            ("user", "https://github.com/user/dotfiles.git"),
            ("user/dots", "https://github.com/user/dots.git"),
            ("codeberg.org/user", "https://codeberg.org/user/dotfiles.git"),
            ("gitlab.com/user/dots", "https://gitlab.com/user/dots.git"),
            ("sr.ht/~user", "https://git.sr.ht/~user/dotfiles"),
            ("sr.ht/~user/dots", "https://git.sr.ht/~user/dots"),
            ("https://github.com/foo/bar", "https://github.com/foo/bar.git"),
        ],
    )
    def test_init_guesses_https_repo_url(self, home, tmp_path, bin_dir, repo, expected):
        """a bare repo argument is expanded to a full HTTPS URL."""
        record = tmp_path / "record"
        record.mkdir()
        e = clone_env(home, tmp_path, bin_dir, record)
        assert run(e, home, repo).returncode == 0
        args = clone_args(record)
        assert args[0] == "clone"
        assert args[1] == "--recurse-submodules"
        assert expected in args

    @pytest.mark.parametrize(
        ("repo", "expected"),
        [
            ("user", "git@github.com:user/dotfiles.git"),
            ("user/dots", "git@github.com:user/dots.git"),
            ("codeberg.org/user", "git@codeberg.org:user/dotfiles.git"),
            ("sr.ht/~user", "git@git.sr.ht:~user/dotfiles"),
            ("http://github.com/foo/bar", "git@github.com:foo/bar.git"),
        ],
    )
    def test_init_guesses_ssh_repo_url(self, home, tmp_path, bin_dir, repo, expected):
        """--ssh expands repo arguments to scp-like SSH URLs."""
        record = tmp_path / "record"
        record.mkdir()
        e = clone_env(home, tmp_path, bin_dir, record)
        assert run(e, home, repo, "--ssh").returncode == 0
        assert expected in clone_args(record)

    def test_init_guess_repo_url_can_be_disabled(self, home, tmp_path, bin_dir):
        """--guess-repo-url=false passes the repo argument through unchanged."""
        record = tmp_path / "record"
        record.mkdir()
        e = clone_env(home, tmp_path, bin_dir, record)
        assert run(e, home, "/some/local/path", "--guess-repo-url=false").returncode == 0
        assert "/some/local/path" in clone_args(record)

    @pytest.mark.parametrize(
        ("extra_flags", "expected_args"),
        [
            (["--branch", "devel"], ["--recurse-submodules", "--branch", "devel"]),
            (["--tag", "v1.2.3"], ["--recurse-submodules", "--tag", "v1.2.3"]),
            (["--revision", "abc123"], ["--recurse-submodules", "--revision", "abc123"]),
            (["--depth", "2"], ["--recurse-submodules", "--depth", "2"]),
            (["--recurse-submodules=false"], []),
        ],
        ids=["branch", "tag", "revision", "depth", "no-recurse-submodules"],
    )
    def test_init_clone_flag_translation(self, home, tmp_path, bin_dir, extra_flags, expected_args):
        """init's clone options are translated into git clone arguments."""
        record = tmp_path / "record"
        record.mkdir()
        e = clone_env(home, tmp_path, bin_dir, record)
        assert run(e, home, "user", *extra_flags).returncode == 0
        assert clone_args(record)[1:] == [
            *expected_args,
            "https://github.com/user/dotfiles.git",
            str(source_dir(home)),
        ]

    def test_init_builtin_git_refuses_ssh(self, home, env):
        """the builtin git cannot clone over ssh and says so."""
        result = run(env, home, "user", "--ssh", "--use-builtin-git=true")
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: builtin git does not support cloning repos over ssh, please install git\n"
        )

    def test_init_builtin_git_clones_local_repository(self, home, tmp_path):
        """--use-builtin-git clones a local repository with go-git."""
        e = make_git_env(home, tmp_path)
        remote = make_remote(tmp_path, e, {"dot_builtin": "builtin clone\n"})
        result = run(e, home, str(remote), "--guess-repo-url=false", "--use-builtin-git=true")
        assert result.returncode == 0
        assert (source_dir(home) / "dot_builtin").read_text() == "builtin clone\n"

    def test_init_invalid_chezmoiname_version(self, home, tmp_path):
        """an unparsable .chezmoiversion file is a hard error."""
        e = make_git_env(home, tmp_path)
        init_source_repo(e, home, {".chezmoiversion": "notaversion\n"})
        result = run(e, home)
        assert result.returncode == 1
        assert result.stderr == (
            'chezmoi: %s: "notaversion\\n": notaversion is not in dotted-tri format\n'
            % (source_dir(home) / ".chezmoiversion")
        )
