"""Tests for `chezmoi push`: add, commit and push the source state.

The git identity *and* commit timestamps are pinned, so every hash in git's
own commit and push output is a deterministic function of the test setup and
the exact stdout/stderr bytes can be compared. A git wrapper in $PATH records
the exact argv of every git invocation chezmoi makes.
"""

from __future__ import annotations

import shutil

import pytest

from conftest import (
    _GIT_WRAPPER,
    SYSTEM_PATH,
    child_env,
    make_git_env,
    record_dir,
    run_chezmoi,
    run_git,
    source_dir,
    write_config,
    write_script,
)

PINNED_DATE = "2026-01-01T00:00:00Z"

# A git wrapper that logs into the shared order log, for tests that need the
# git invocations and the hooks interleaved in one place.
_ORDER_GIT_WRAPPER = """#!/bin/sh
printf 'git: %s\\n' "$*" >> "${RECORD_DIR:?}/order.log"
exec /usr/bin/git "$@"
"""

# A hook command: it logs its name and working directory, then prints a line
# so its stdout streaming is observable.
_HOOK_CMD = """#!/bin/sh
printf '%s pwd=%s\\n' "$1" "$PWD" >> "${RECORD_DIR:?}/order.log"
printf '%s-hook-ran\\n' "$1"
"""

# A hook command that fails.
_FAILING_HOOK = """#!/bin/sh
printf 'failing-hook-ran\\n'
exit 3
"""


def push_env(home, tmp_path, bin_dir, record, **extra):
    """A pinned environment whose git logs argv before running for real.

    Author and committer timestamps are pinned so the abbreviated hashes that
    git prints are deterministic.
    """
    write_script(bin_dir / "git", _GIT_WRAPPER)
    return child_env(
        home,
        tmpdir=tmp_path / "tmp",
        path=f"{bin_dir}:{SYSTEM_PATH}",
        RECORD_DIR=str(record),
        GIT_AUTHOR_NAME="Tester",
        GIT_AUTHOR_EMAIL="tester@example.com",
        GIT_COMMITTER_NAME="Tester",
        GIT_COMMITTER_EMAIL="tester@example.com",
        GIT_AUTHOR_DATE=PINNED_DATE,
        GIT_COMMITTER_DATE=PINNED_DATE,
        TZ="UTC",
        **extra,
    )


def push_repo(env, home, tmp_path, *, with_remote=True):
    """A source repository with two files, optionally tracking a bare remote."""
    sd = source_dir(home)
    sd.mkdir(parents=True)
    run_git(env, sd, "init", "--quiet", "-b", "main")
    (sd / "dot_vimrc").write_text("original\n")
    (sd / "plain.txt").write_text("keep\n")
    run_git(env, sd, "add", ".")
    run_git(env, sd, "commit", "--quiet", "-m", "initial")
    if not with_remote:
        return sd, None
    remote = tmp_path / "remote.git"
    run_git(env, sd, "clone", "--quiet", "--bare", ".", str(remote))
    run_git(env, sd, "remote", "add", "origin", str(remote))
    run_git(env, sd, "push", "--quiet", "-u", "origin", "main")
    return sd, remote


def short_head(env, repo):
    """The abbreviated hash of repo's HEAD, as git itself prints it."""
    proc = run_git(env, repo, "rev-parse", "--short", "HEAD")
    assert proc.returncode == 0, proc.stderr
    return proc.stdout.decode().strip()


def last_message(env, repo):
    """The full commit message of repo's HEAD.

    git log appends a separator newline after the body, which is stripped so
    the result is exactly the stored message.
    """
    proc = run_git(env, repo, "log", "--format=%B", "-n1")
    assert proc.returncode == 0, proc.stderr
    out = proc.stdout.decode()
    return out[:-1] if out.endswith("\n") else out


def clear_logs(record, *names):
    """Remove the wrapper logs so only the chezmoi run's entries remain."""
    for name in names:
        (record / name).unlink(missing_ok=True)


class TestPushBasics:
    def test_push_commits_and_pushes_new_file(self, home, tmp_path, bin_dir):
        """push stages, commits with a generated message and pushes."""
        # CATCHES: git commit's summary goes to stdout and git push's ref
        # update to stderr, both streamed through unchanged, the commit
        # message is generated from the status ("Add" + the *target* name,
        # dot_newfile -> .newfile), and the remote receives the commit.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, remote = push_repo(e, home, tmp_path)
        old = short_head(e, sd)
        (sd / "dot_newfile").write_text("new\n")

        result = run_chezmoi(["push"], env=e)

        new = short_head(e, sd)
        assert result.returncode == 0
        assert result.stdout == (
            f"[main {new}] Add .newfile\n"
            " 1 file changed, 1 insertion(+)\n"
            " create mode 100644 dot_newfile\n"
        )
        assert result.stderr == f"To {remote}\n   {old}..{new}  main -> main\n"
        assert last_message(e, sd) == "Add .newfile\n"
        assert short_head(e, remote) == new

    @pytest.mark.parametrize(
        "change,expected_message",
        [
            pytest.param("add", "Add .newfile", id="add"),
            pytest.param("update", "Update .vimrc", id="update"),
            pytest.param("remove", "Remove plain.txt", id="remove"),
            pytest.param("rename", "Change attributes of renamed.txt", id="rename"),
        ],
    )
    def test_push_commit_message_verbs(
        self, home, tmp_path, bin_dir, change, expected_message
    ):
        """the commit message verb matches the staged status letter."""
        # CATCHES: the generated message uses Add/Update/Remove for A./M./D.
        # entries, a rename becomes "Change attributes of" the new target
        # name, and in every case the path is the target path (dot_ prefix
        # stripped), not the source path.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, remote = push_repo(e, home, tmp_path)
        if change == "add":
            (sd / "dot_newfile").write_text("new\n")
        elif change == "update":
            (sd / "dot_vimrc").write_text("changed\n")
        elif change == "remove":
            (sd / "plain.txt").unlink()
        else:
            run_git(e, sd, "mv", "plain.txt", "renamed.txt")

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 0
        assert last_message(e, sd) == f"{expected_message}\n"
        assert short_head(e, remote) == short_head(e, sd)

    def test_push_multiple_files_message(self, home, tmp_path, bin_dir):
        """several changes produce one commit with one message line each."""
        # CATCHES: each staged entry contributes its own line to the message
        # (sorted), git's summary line joins them with spaces, and the
        # per-file create-mode lines are streamed in sorted order.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, remote = push_repo(e, home, tmp_path)
        (sd / "sub").mkdir()
        (sd / "sub" / "dot_foo").write_text("a\n")
        (sd / "toplevel.txt").write_text("b\n")

        result = run_chezmoi(["push"], env=e)

        new = short_head(e, sd)
        assert result.returncode == 0
        assert result.stdout == (
            f"[main {new}] Add sub/.foo Add toplevel.txt\n"
            " 2 files changed, 2 insertions(+)\n"
            " create mode 100644 sub/dot_foo\n"
            " create mode 100644 toplevel.txt\n"
        )
        assert last_message(e, sd) == "Add sub/.foo\nAdd toplevel.txt\n"
        assert short_head(e, remote) == new

    def test_push_clean_tree(self, home, tmp_path, bin_dir):
        """push with nothing staged neither commits nor pushes."""
        # CATCHES: git add and git status still run, but an empty status
        # short-circuits the commit, the push *and* their hooks, and chezmoi
        # exits 0 with no output at all.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, remote = push_repo(e, home, tmp_path)
        old = short_head(e, sd)
        clear_logs(record, "git.log")

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert (record / "git.log").read_text().splitlines() == [
            "add .",
            "status --porcelain=v2",
        ]
        assert short_head(e, sd) == old
        assert short_head(e, remote) == old

    def test_push_rejects_arguments(self, home, tmp_path, bin_dir):
        """push takes no arguments at all."""
        # CATCHES: push uses NoArgs, whose message reads like an unknown
        # subcommand, and the rejection happens before git is ever invoked.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        push_repo(e, home, tmp_path)
        clear_logs(record, "git.log")

        result = run_chezmoi(["push", "extra"], env=e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == 'chezmoi: unknown command "extra" for "chezmoi push"\n'
        assert not (record / "git.log").exists()

    def test_push_without_remote_commits_but_fails(self, home, tmp_path, bin_dir):
        """a missing push remote fails only after the commit succeeded."""
        # CATCHES: the commit is created and its output printed to stdout
        # before git push runs, so the local repository keeps the commit even
        # though the command as a whole exits 1 with git's fatal message and
        # chezmoi's exit-status wrapping on stderr.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path, with_remote=False)
        old = short_head(e, sd)
        (sd / "dot_newfile").write_text("new\n")

        result = run_chezmoi(["push"], env=e)

        new = short_head(e, sd)
        assert result.returncode == 1
        assert result.stdout == (
            f"[main {new}] Add .newfile\n"
            " 1 file changed, 1 insertion(+)\n"
            " create mode 100644 dot_newfile\n"
        )
        assert result.stderr == (
            "fatal: No configured push destination.\n"
            "Either specify the URL from the command-line or configure "
            "a remote repository using\n"
            "\n"
            "    git remote add <name> <url>\n"
            "\n"
            "and then push using the remote name\n"
            "\n"
            "    git push <name>\n"
            "\n"
            "chezmoi: git: exit status 128\n"
        )
        assert new != old
        assert last_message(e, sd) == "Add .newfile\n"

    def test_push_in_non_repository_fails(self, home, tmp_path, bin_dir):
        """push in a source directory that is not a git repo fails."""
        # CATCHES: the very first git invocation (`add .`) fails, its fatal
        # message passes through to stderr, and chezmoi wraps the exit status
        # of git itself (128), not of chezmoi.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / "dot_a").write_text("a\n")

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "fatal: not a git repository (or any of the parent directories): .git\n"
            "chezmoi: git: exit status 128\n"
        )

    def test_push_missing_source_directory(self, home, tmp_path, bin_dir):
        """push requires the source directory to exist."""
        # CATCHES: the source-directory check reports the raw stat error for
        # the missing directory before any git command runs.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == f"chezmoi: stat {source_dir(home)}: no such file or directory\n"
        assert not (record / "git.log").exists()


class TestPushGitInvocation:
    def test_push_git_command_sequence(self, home, tmp_path, bin_dir):
        """push drives git with an exact, minimal sequence of commands."""
        # CATCHES: the recorded argv is `add .`, `status --porcelain=v2`,
        # `commit --message <generated message>` and `push` — nothing else —
        # and the message argument carries a trailing newline (visible as the
        # empty log line), while the status output is captured, not streamed.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path)
        (sd / "dot_newfile").write_text("new\n")
        clear_logs(record, "git.log")

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 0
        assert (record / "git.log").read_text().splitlines() == [
            "add .",
            "status --porcelain=v2",
            "commit --message Add .newfile",
            "",
            "push",
        ]


class TestPushHooks:
    @pytest.fixture
    def hooked_env(self, home, tmp_path, bin_dir):
        """An environment with all four git-auto-* hooks configured.

        Each hook is the same command with a distinct name argument; both the
        hooks and the git wrapper append to a single order log.
        """
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        write_script(bin_dir / "git", _ORDER_GIT_WRAPPER)
        hook = write_script(bin_dir / "hookcmd", _HOOK_CMD)
        write_config(
            home,
            f"""[hooks.git-auto-commit.pre]
    command = "{hook}"
    args = ["commit-pre"]
[hooks.git-auto-commit.post]
    command = "{hook}"
    args = ["commit-post"]
[hooks.git-auto-push.pre]
    command = "{hook}"
    args = ["push-pre"]
[hooks.git-auto-push.post]
    command = "{hook}"
    args = ["push-post"]
""",
        )
        return e, record

    def test_push_hooks_around_commit_and_push(self, home, tmp_path, hooked_env):
        """the git-auto-commit/push pre and post hooks bracket each step."""
        # CATCHES: the pre-commit hook runs after add+status but before the
        # commit, the post-commit and pre-push hooks follow, and the
        # post-push hook runs last; every hook's cwd is the home directory,
        # and their stdout is interleaved with git's in execution order.
        e, record = hooked_env
        sd, remote = push_repo(e, home, tmp_path)
        (sd / "dot_newfile").write_text("new\n")
        clear_logs(record, "order.log")

        result = run_chezmoi(["push"], env=e)

        # Read the order log before any helper runs git through the wrapper.
        order = (record / "order.log").read_text().splitlines()
        new = short_head(e, sd)
        assert result.returncode == 0
        assert result.stdout == (
            f"commit-pre-hook-ran\n"
            f"[main {new}] Add .newfile\n"
            " 1 file changed, 1 insertion(+)\n"
            " create mode 100644 dot_newfile\n"
            "commit-post-hook-ran\n"
            "push-pre-hook-ran\n"
            "push-post-hook-ran\n"
        )
        assert order == [
            "git: add .",
            "git: status --porcelain=v2",
            f"commit-pre pwd={home}",
            "git: commit --message Add .newfile",
            "",
            f"commit-post pwd={home}",
            f"push-pre pwd={home}",
            "git: push",
            f"push-post pwd={home}",
        ]

    def test_push_pre_commit_hook_failure(self, home, tmp_path, bin_dir):
        """a failing pre-commit hook aborts before the commit."""
        # CATCHES: the hook's stdout is still streamed, the error names the
        # hook (git-auto-commit), its phase (pre) and the command's exit
        # status, and neither a commit nor a push happens.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, remote = push_repo(e, home, tmp_path)
        hook = write_script(bin_dir / "failhook", _FAILING_HOOK)
        write_config(home, f'[hooks.git-auto-commit.pre]\n    command = "{hook}"\n')
        (sd / "dot_newfile").write_text("new\n")
        old = short_head(e, sd)
        clear_logs(record, "git.log")

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 1
        assert result.stdout == "failing-hook-ran\n"
        assert result.stderr == f"chezmoi: git-auto-commit: pre: {hook}: exit status 3\n"
        assert (record / "git.log").read_text().splitlines() == [
            "add .",
            "status --porcelain=v2",
        ]
        assert short_head(e, sd) == old
        assert short_head(e, remote) == old

    def test_push_post_push_hook_failure(self, home, tmp_path, bin_dir):
        """a failing post-push hook errors after the push completed."""
        # CATCHES: the commit and the push have already happened when the
        # post hook fails, so the remote is up to date even though chezmoi
        # exits 1 with the git-auto-push/post wrapping.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, remote = push_repo(e, home, tmp_path)
        hook = write_script(bin_dir / "failhook", _FAILING_HOOK)
        write_config(home, f'[hooks.git-auto-push.post]\n    command = "{hook}"\n')
        (sd / "dot_newfile").write_text("new\n")
        old = short_head(e, sd)

        result = run_chezmoi(["push"], env=e)

        new = short_head(e, sd)
        assert result.returncode == 1
        assert result.stdout == (
            f"[main {new}] Add .newfile\n"
            " 1 file changed, 1 insertion(+)\n"
            " create mode 100644 dot_newfile\n"
            "failing-hook-ran\n"
        )
        assert result.stderr == (
            f"To {remote}\n"
            f"   {old}..{new}  main -> main\n"
            f"chezmoi: git-auto-push: post: {hook}: exit status 3\n"
        )
        assert short_head(e, remote) == new

    def test_push_hook_command_and_script_conflict(self, home, tmp_path, bin_dir):
        """a hook cannot set both command and script."""
        # CATCHES: the conflict is detected when the hook runs, so git add
        # and git status have already executed and the error carries no
        # command name, only the hook and phase.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path)
        script = write_script(bin_dir / "hook.sh", "#!/bin/sh\ntrue\n")
        write_config(
            home,
            f'[hooks.git-auto-commit.pre]\n    command = "true"\n    script = "{script}"\n',
        )
        (sd / "dot_newfile").write_text("new\n")

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: git-auto-commit: pre: cannot specify both command and script\n"

    @pytest.mark.parametrize(
        "kind",
        ["sh-direct", "py-interpreter", "custom-interpreter"],
    )
    def test_push_hook_script_execution(self, home, tmp_path, bin_dir, kind):
        """script hooks run under the interpreter registered for them."""
        # CATCHES: an extension with no registered interpreter is executed
        # directly; .py is run as `python3 <script>`; and an interpreter can
        # be registered in the config, in which case the script path and hook
        # args are appended to the interpreter's command.
        if kind == "py-interpreter" and shutil.which("python3") is None:
            pytest.skip("python3 is required for the .py script hook")
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path)
        if kind == "sh-direct":
            script = write_script(tmp_path / "hook.sh", "#!/bin/sh\necho sh-script-hook-ran\n")
            write_config(home, f'[hooks.git-auto-commit.pre]\n    script = "{script}"\n')
            marker = "sh-script-hook-ran"
        elif kind == "py-interpreter":
            script = tmp_path / "hook.py"
            script.write_text('print("py-script-hook-ran")\n')
            write_config(home, f'[hooks.git-auto-commit.pre]\n    script = "{script}"\n')
            marker = "py-script-hook-ran"
        else:
            script = tmp_path / "hook.myh"
            script.write_text("ignored by the interpreter\n")
            write_script(
                bin_dir / "myinterp",
                '#!/bin/sh\nprintf "myinterp argv: %s\\n" "$*"\n',
            )
            write_config(
                home,
                f"""[interpreters.myh]
    command = "myinterp"
[hooks.git-auto-commit.pre]
    script = "{script}"
    args = ["extra-arg"]
""",
            )
            marker = f"myinterp argv: {script} extra-arg"
        (sd / "dot_newfile").write_text("new\n")

        result = run_chezmoi(["push"], env=e)

        new = short_head(e, sd)
        assert result.returncode == 0
        assert result.stdout == (
            f"{marker}\n"
            f"[main {new}] Add .newfile\n"
            " 1 file changed, 1 insertion(+)\n"
            " create mode 100644 dot_newfile\n"
        )


class TestPushCommitMessageTemplate:
    def test_push_custom_commit_message_template(self, home, tmp_path, bin_dir):
        """git.commitMessageTemplate replaces the built-in template."""
        # CATCHES: the template sees the full chezmoi template data
        # (.chezmoi.username) and the parsed status, whose XY status letters
        # are bytes rendered as their decimal value (A -> 65); the rendered
        # message is passed verbatim to git commit --message.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path)
        write_config(
            home,
            '[git]\n'
            '    commitMessageTemplate = "custom {{ .chezmoi.username }}:'
            '{{ range .chezmoi.status.Ordinary }}{{ .X }}={{ .Path }},{{ end }}"\n',
        )
        (sd / "z1.txt").write_text("z1\n")
        (sd / "z2.txt").write_text("z2\n")

        result = run_chezmoi(["push"], env=e)

        new = short_head(e, sd)
        assert result.returncode == 0
        assert last_message(e, sd) == "custom root:65=z1.txt,65=z2.txt,\n"
        assert result.stdout == (
            f"[main {new}] custom root:65=z1.txt,65=z2.txt,\n"
            " 2 files changed, 2 insertions(+)\n"
            " create mode 100644 z1.txt\n"
            " create mode 100644 z2.txt\n"
        )

    def test_push_commit_message_template_file(self, home, tmp_path, bin_dir):
        """git.commitMessageTemplateFile is read from the source directory."""
        # CATCHES: the template file is looked up inside the source directory
        # (and, being a new untracked file there, is itself staged by
        # `git add .` and so appears in its own commit's message).
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path)
        (sd / ".chezmoi-commit-template").write_text(
            "file-template: {{ range .chezmoi.status.Ordinary }}[{{ .Path }}]{{ end }}\n"
        )
        write_config(home, '[git]\n    commitMessageTemplateFile = ".chezmoi-commit-template"\n')
        (sd / "z3.txt").write_text("z3\n")

        result = run_chezmoi(["push"], env=e)

        new = short_head(e, sd)
        assert result.returncode == 0
        assert result.stdout == (
            f"[main {new}] file-template: [.chezmoi-commit-template][z3.txt]\n"
            " 2 files changed, 2 insertions(+)\n"
            " create mode 100644 .chezmoi-commit-template\n"
            " create mode 100644 z3.txt\n"
        )
        assert last_message(e, sd) == "file-template: [.chezmoi-commit-template][z3.txt]\n"

    def test_push_missing_template_file(self, home, tmp_path, bin_dir):
        """a missing commitMessageTemplateFile is a raw open error."""
        # CATCHES: the error is the bare os.Open message for the path inside
        # the source directory (no hook or template name in the wrapping).
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path)
        write_config(home, '[git]\n    commitMessageTemplateFile = "no-such-template-file"\n')
        (sd / "z4.txt").write_text("z4\n")

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            f"chezmoi: open {sd}/no-such-template-file: no such file or directory\n"
        )

    def test_push_invalid_commit_message_template(self, home, tmp_path, bin_dir):
        """a syntactically invalid template names it in the error."""
        # CATCHES: the parse error is reported with the config key
        # git.commitMessageTemplate as the template name, after the status
        # was already computed but before any commit is made.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path)
        write_config(home, '[git]\n    commitMessageTemplate = "bad {{ "\n')
        (sd / "z5.txt").write_text("z5\n")

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: template: git.commitMessageTemplate:1: unclosed action\n"

    def test_push_empty_commit_message(self, home, tmp_path, bin_dir):
        """a template rendering to an empty message aborts the commit."""
        # CATCHES: chezmoi passes the empty message on to git, whose own
        # "Aborting commit due to empty commit message" error (followed by
        # chezmoi's wrapping) surfaces on stderr with exit status 1.
        record = record_dir(tmp_path)
        e = push_env(home, tmp_path, bin_dir, record)
        sd, _ = push_repo(e, home, tmp_path)
        write_config(home, '[git]\n    commitMessageTemplate = "{{ if false }}never{{ end }}"\n')
        (sd / "z6.txt").write_text("z6\n")
        old = short_head(e, sd)

        result = run_chezmoi(["push"], env=e)

        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "Aborting commit due to empty commit message.\n"
            "chezmoi: git: exit status 1\n"
        )
        assert short_head(e, sd) == old
