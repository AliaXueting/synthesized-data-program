"""Tests for `chezmoi update`: pulling the source repo and applying."""

from __future__ import annotations

import pytest

from conftest import (
    _GIT_WRAPPER,
    child_env,
    init_source_repo,
    make_git_env,
    make_remote,
    run_chezmoi,
    run_git,
    source_dir,
    write_config,
    write_script,
)


UPDATER_SCRIPT = """#!/bin/sh
printf 'UPDATER args=%s\\n' "$*"
printf 'UPDATER cwd=%s\\n' "$(pwd)"
"""


def run(env, *args, **kwargs):
    return run_chezmoi(["update", *args], env=env, **kwargs)


def wrapper_env(home, tmp_path, bin_dir, record):
    """An environment where git logs its arguments before running for real."""
    write_script(bin_dir / "git", _GIT_WRAPPER)
    return child_env(
        home,
        tmpdir=tmp_path / "tmp",
        path=f"{bin_dir}:/usr/bin:/bin",
        RECORD_DIR=str(record),
        GIT_AUTHOR_NAME="Tester",
        GIT_AUTHOR_EMAIL="tester@example.com",
        GIT_COMMITTER_NAME="Tester",
        GIT_COMMITTER_EMAIL="tester@example.com",
    )


def clone_remote(home, tmp_path, files):
    """Clone a fresh remote into home's source directory via chezmoi init."""
    env = make_git_env(home, tmp_path)
    remote = make_remote(tmp_path, env, files)
    result = run_chezmoi(
        ["init", str(remote), "--guess-repo-url=false"],
        env=env,
        cwd=home,
    )
    assert result.returncode == 0, result.stderr
    return env, remote


class TestUpdateGitPull:
    def test_update_runs_git_pull_autostash_rebase(self, home, tmp_path, bin_dir):
        """update pulls with --autostash --rebase --recurse-submodules by default."""
        # CATCHES: --recurse-submodules defaults to true, so the plain git
        # invocation already carries the flag alongside --autostash --rebase.
        record = tmp_path / "record"
        record.mkdir()
        env, _ = clone_remote(home, tmp_path, {"dot_pulled": "original\n"})
        e = wrapper_env(home, tmp_path, bin_dir, record)
        assert run(e, cwd=home).returncode == 0
        assert (record / "git.log").read_text().splitlines() == [
            "pull --autostash --rebase --recurse-submodules"
        ]

    def test_update_recurse_submodules_flag(self, home, tmp_path, bin_dir):
        """--recurse-submodules=false drops the flag from git pull."""
        # CATCHES: passing --recurse-submodules=false is the only way to get
        # a bare `pull --autostash --rebase` from update.
        record = tmp_path / "record"
        record.mkdir()
        clone_remote(home, tmp_path, {"dot_pulled": "original\n"})
        e = wrapper_env(home, tmp_path, bin_dir, record)
        assert run(e, "--recurse-submodules=false", cwd=home).returncode == 0
        assert (record / "git.log").read_text().splitlines() == ["pull --autostash --rebase"]

    def test_update_in_non_repository_fails(self, home, tmp_path):
        """update in a source directory that is not a git repo is an error."""
        # CATCHES: git's own fatal message is passed through to stderr before
        # chezmoi wraps the exit status, and nothing is applied on failure.
        e = make_git_env(home, tmp_path)
        source_dir(home).mkdir(parents=True)
        (source_dir(home) / "dot_a").write_text("a\n")
        result = run(e, cwd=home)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "fatal: not a git repository (or any of the parent directories): .git\n"
            "chezmoi: git: exit status 128\n"
        )
        assert not (home / ".a").exists()


class TestUpdateCustomCommand:
    def test_update_custom_command(self, home, tmp_path, bin_dir):
        """update.command replaces git pull and runs in the working tree."""
        # CATCHES: the custom command completely replaces git pull (git is
        # never invoked) and runs with the working tree as its cwd.
        write_script(bin_dir / "myupdater", UPDATER_SCRIPT)
        e = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{bin_dir}:/usr/bin:/bin",
        )
        init_source_repo(e, home, {"dot_a": "a\n"})
        write_config(home, '[update]\n    command = "myupdater"\n    args = ["--flag", "value"]\n')
        result = run(e, cwd=home)
        assert result.returncode == 0
        assert result.stdout == (
            "UPDATER args=--flag value\nUPDATER cwd=%s\n" % source_dir(home)
        )
        # apply defaults to true, so the source state is applied afterwards.
        assert (home / ".a").read_text() == "a\n"

    def test_update_custom_command_skips_apply(self, home, tmp_path, bin_dir):
        """--apply=false runs the custom command but applies nothing."""
        # CATCHES: --apply=false only suppresses the apply step; the custom
        # update command still runs and prints its output.
        write_script(bin_dir / "myupdater", UPDATER_SCRIPT)
        e = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{bin_dir}:/usr/bin:/bin",
        )
        init_source_repo(e, home, {"dot_a": "a\n"})
        write_config(home, '[update]\n    command = "myupdater"\n')
        result = run(e, "--apply=false", cwd=home)
        assert result.returncode == 0
        assert result.stdout == "UPDATER args=\nUPDATER cwd=%s\n" % source_dir(home)
        assert not (home / ".a").exists()


class TestUpdateApply:
    def test_update_apply_flag(self, home, tmp_path):
        """-a/--apply applies the target state after pulling."""
        env, remote = clone_remote(home, tmp_path, {"dot_dotfiles/README.md": "version one\n"})
        run_git(env, remote.parent, "clone", "--quiet", str(remote), str(tmp_path / "pushdir"))
        pushdir = tmp_path / "pushdir"
        (pushdir / "dot_dotfiles" / "README.md").write_text("version two\n")
        run_git(env, pushdir, "add", "-A")
        run_git(env, pushdir, "commit", "--quiet", "-m", "second")
        run_git(env, pushdir, "push", "--quiet", "origin", "HEAD:main")

        assert not (home / ".dotfiles" / "README.md").exists()
        result = run(env, "--apply", cwd=home)
        assert result.returncode == 0
        assert (home / ".dotfiles" / "README.md").read_text() == "version two\n"

    def test_update_without_apply_leaves_destination(self, home, tmp_path):
        """--apply=false pulls into the source dir but leaves the destination."""
        # CATCHES: the pull still updates the source directory, only the
        # apply step is skipped, so no target file appears in the home dir.
        env, remote = clone_remote(home, tmp_path, {"dot_dotfiles/README.md": "version one\n"})
        run_git(env, remote.parent, "clone", "--quiet", str(remote), str(tmp_path / "pushdir"))
        pushdir = tmp_path / "pushdir"
        (pushdir / "dot_dotfiles" / "README.md").write_text("version two\n")
        run_git(env, pushdir, "add", "-A")
        run_git(env, pushdir, "commit", "--quiet", "-m", "second")
        run_git(env, pushdir, "push", "--quiet", "origin", "HEAD:main")

        result = run(env, "--apply=false", cwd=home)
        assert result.returncode == 0
        assert (source_dir(home) / "dot_dotfiles" / "README.md").read_text() == "version two\n"
        assert not (home / ".dotfiles").exists()

    def test_update_apply_from_config(self, home, tmp_path):
        """update.apply = true in the config file applies after pulling."""
        env, remote = clone_remote(home, tmp_path, {"dot_dotfiles/README.md": "version one\n"})
        write_config(home, "[update]\n    apply = true\n")
        run_git(env, remote.parent, "clone", "--quiet", str(remote), str(tmp_path / "pushdir"))
        pushdir = tmp_path / "pushdir"
        (pushdir / "dot_dotfiles" / "README.md").write_text("version three\n")
        run_git(env, pushdir, "add", "-A")
        run_git(env, pushdir, "commit", "--quiet", "-m", "second")
        run_git(env, pushdir, "push", "--quiet", "origin", "HEAD:main")

        result = run(env, cwd=home)
        assert result.returncode == 0
        assert (home / ".dotfiles" / "README.md").read_text() == "version three\n"


class TestUpdateBuiltinGit:
    def test_update_builtin_git_no_repository(self, home, tmp_path):
        """the builtin git reports a missing repository."""
        e = make_git_env(home, tmp_path)
        source_dir(home).mkdir(parents=True)
        (source_dir(home) / "dot_a").write_text("a\n")
        result = run(e, "--use-builtin-git=true", cwd=home)
        assert result.returncode == 1
        assert result.stderr == "chezmoi: repository does not exist\n"

    def test_update_builtin_git_unstaged_changes(self, home, tmp_path):
        """the builtin git refuses to pull a dirty worktree with changes due."""
        # CATCHES: the builtin (go-git) pull only reports unstaged changes
        # when there is actually something to pull, and leaves the local
        # modification untouched.
        env, remote = clone_remote(home, tmp_path, {"dot_pulled": "original\n"})
        run_git(env, remote.parent, "clone", "--quiet", str(remote), str(tmp_path / "pushdir"))
        pushdir = tmp_path / "pushdir"
        (pushdir / "dot_pulled").write_text("changed upstream\n")
        run_git(env, pushdir, "add", "-A")
        run_git(env, pushdir, "commit", "--quiet", "-m", "second")
        run_git(env, pushdir, "push", "--quiet", "origin", "HEAD:main")

        (source_dir(home) / "dot_pulled").write_text("modified locally\n")
        result = run(env, "--use-builtin-git=true", cwd=home)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: worktree contains unstaged changes\n"
        assert (source_dir(home) / "dot_pulled").read_text() == "modified locally\n"

    def test_update_builtin_git_pulls_silently(self, home, tmp_path):
        """the builtin git pulls without printing anything."""
        env, remote = clone_remote(home, tmp_path, {"dot_dotfiles/README.md": "version one\n"})
        run_git(env, remote.parent, "clone", "--quiet", str(remote), str(tmp_path / "pushdir"))
        pushdir = tmp_path / "pushdir"
        (pushdir / "dot_dotfiles" / "README.md").write_text("builtin version\n")
        run_git(env, pushdir, "add", "-A")
        run_git(env, pushdir, "commit", "--quiet", "-m", "second")
        run_git(env, pushdir, "push", "--quiet", "origin", "HEAD:main")

        result = run(env, "--use-builtin-git=true", "--apply", cwd=home)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert (home / ".dotfiles" / "README.md").read_text() == "builtin version\n"
