"""Tests for `chezmoi upgrade`: the self-upgrade command and its guard rails.

The binary under test reports itself as a development version (its version
string is not a semantic version), so without --force the command refuses
before doing anything else. These tests pin that guard and the command's
argument handling; the download-and-replace flow behind --force is covered
by test_upgrade_flow.py, which drives it through a loopback proxy.
"""

from __future__ import annotations

import pytest

from conftest import child_env, run_chezmoi

DEV_REFUSAL = "chezmoi: cannot upgrade dev version to latest released version unless --force is set\n"


def run(env, *args, **kwargs):
    return run_chezmoi(["upgrade", *args], env=env, **kwargs)


class TestUpgradeDevVersion:
    def test_upgrade_dev_version_refuses(self, home, tmp_path):
        """upgrade refuses to run for a development version."""
        env = child_env(home, tmpdir=tmp_path / "tmp")
        result = run(env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: the refusal happens before any network access, with the
        # exact wording mentioning --force, and nothing is printed on stdout.
        assert result.stderr == DEV_REFUSAL

    @pytest.mark.parametrize(
        "flag",
        [
            "--method=brew-upgrade",
            "--method=bogus",
            "--executable=/tmp/chezmoi-replacement",
        ],
    )
    def test_upgrade_dev_refusal_with_flags(self, home, tmp_path, flag):
        """--method and --executable do not bypass the dev-version refusal."""
        env = child_env(home, tmpdir=tmp_path / "tmp")
        result = run(env, flag)
        # CATCHES: the version guard runs before the method or executable is
        # even looked at, so an invalid method still reports the dev-version
        # refusal rather than "invalid method".
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == DEV_REFUSAL


class TestUpgradeArguments:
    def test_upgrade_rejects_arguments(self, home, tmp_path):
        """upgrade takes no positional arguments."""
        env = child_env(home, tmpdir=tmp_path / "tmp")
        result = run(env, "extraarg")
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == 'chezmoi: unknown command "extraarg" for "chezmoi upgrade"\n'
