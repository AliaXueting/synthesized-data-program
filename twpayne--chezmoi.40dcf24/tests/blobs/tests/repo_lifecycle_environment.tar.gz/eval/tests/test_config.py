"""Tests for the shared configuration machinery in internal/cmd/config.go.

These exercise the black-box behavior of config file discovery and parsing
(XDG search order, format detection, `--config-format`), the `[env]` config
section and the CHEZMOI_* variables exported to child processes, source
directory discovery (`.chezmoiroot`, XDG data dirs), `.chezmoiversion`
checking, the config-file-template-changed warning, and the diff pager. All
expected outputs were recorded from `./executable`.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from conftest import (
    SYSTEM_PATH,
    child_env,
    run_chezmoi,
    source_dir,
    write_config,
    write_script,
)


def sh_env(home: Path, tmp_path: Path, **extra) -> dict[str, str]:
    """An environment whose $SHELL is /bin/sh, fed a command on stdin."""
    return child_env(home, tmpdir=tmp_path / "tmp", shell="/bin/sh", **extra)


def subshell(home: Path, tmp_path: Path, command: str, **extra):
    """Run `chezmoi cd` whose shell prints the expansion of command."""
    return run_chezmoi(
        ["cd"], env=sh_env(home, tmp_path, **extra), stdin=command.encode()
    )


class TestStartup:
    def test_home_unset_startup_error(self, tmp_path):
        """without $HOME chezmoi fails before running any command."""
        # CATCHES: the home directory is resolved in newConfig before cobra
        # sees a single flag, so even `--help` dies with the raw os.UserHomeDir
        # error instead of printing usage.
        env = {"PATH": SYSTEM_PATH, "TMPDIR": str(tmp_path), "LC_ALL": "C"}
        result = run_chezmoi(["--help"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: $HOME is not defined\n"

    def test_multiple_config_files_error(self, home, tmp_path):
        """two config files in one config directory are refused."""
        # CATCHES: discovery collects every chezmoi.<format> in the first
        # config directory holding any, and refuses the ambiguity instead of
        # silently picking one by extension order.
        write_config(home, 'a = 1\n')
        write_config(home, "a: 1\n", name="chezmoi.yaml")
        e = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["apply"], env=e)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: multiple config files: "
            f"{home}/.config/chezmoi/chezmoi.toml and {home}/.config/chezmoi/chezmoi.yaml\n"
        )

    @pytest.mark.parametrize(
        "which",
        [
            pytest.param("config-home-first", id="config-home-first"),
            pytest.param("config-dirs-fallback", id="config-dirs-fallback"),
        ],
    )
    def test_config_file_search_order(self, home, tmp_path, which):
        """the config file is found via the XDG search order."""
        # CATCHES: $XDG_CONFIG_HOME (defaulting to ~/.config) is searched
        # before the directories in $XDG_CONFIG_DIRS, and the latter are only
        # consulted when the config home has no chezmoi directory at all.
        dirs_conf = tmp_path / "xdg-config-dirs" / "chezmoi"
        dirs_conf.mkdir(parents=True)
        (dirs_conf / "chezmoi.toml").write_text('[env]\n  FROM = "config-dirs"\n')
        if which == "config-home-first":
            write_config(home, '[env]\n  FROM = "config-home"\n')
        result = subshell(
            home,
            tmp_path,
            'echo "FROM=$FROM"\n',
            XDG_CONFIG_DIRS=str(tmp_path / "xdg-config-dirs"),
        )
        assert result.returncode == 0
        assert result.stdout == f"FROM={'config-home' if which == 'config-home-first' else 'config-dirs'}\n"
        assert result.stderr == ""


class TestConfigFormats:
    @pytest.mark.parametrize(
        "format_flag,contents,expected",
        [
            pytest.param(
                "toml",
                '[env]\n  MYVAR = "toml-rescued"\n',
                "toml-rescued",
                id="toml",
            ),
            pytest.param(
                "json",
                '{"env": {"MYVAR": "json-rescued"}}\n',
                "json-rescued",
                id="json",
            ),
        ],
    )
    def test_config_format_flag_rescues_unknown_extension(
        self, home, tmp_path, format_flag, contents, expected
    ):
        """--config-format parses a config file with any file name."""
        # CATCHES: the format is taken from the flag, not the file name, so a
        # config at an arbitrary path is honored once the format is given.
        conf = home / "conf"
        conf.mkdir()
        (conf / "myconf.txt").write_text(contents)
        e = child_env(home, tmpdir=tmp_path / "tmp", shell="/bin/sh")
        result = run_chezmoi(
            ["-c", str(conf / "myconf.txt"), "--config-format", format_flag, "cd"],
            env=e,
            stdin=b'echo "MYVAR=$MYVAR"\n',
        )
        assert result.returncode == 0
        assert result.stdout == f"MYVAR={expected}\n"
        assert result.stderr == ""

    def test_config_unknown_extension_is_invalid_config(self, home, tmp_path):
        """a config file without a known extension cannot be parsed."""
        # CATCHES: without --config-format the format comes from the file name
        # extension, and an unknown extension is an error naming the extension.
        conf = home / "conf"
        conf.mkdir()
        (conf / "myconf.txt").write_text('a = 1\n')
        e = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["-c", str(conf / "myconf.txt"), "apply"], env=e)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            f"chezmoi: invalid config: {conf}/myconf.txt: .txt: unknown format\n"
        )

    def test_config_format_flag_invalid_value(self, home, tmp_path):
        """--config-format only accepts its enumerated values."""
        # CATCHES: the flag is a choice flag validated before the config file
        # is read, with pflag's invalid-argument wording.
        e = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["--config-format", "bogus", "apply"], env=e)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: invalid argument "bogus" for "--config-format" flag: invalid value\n'
        )


class TestEnvConfig:
    def test_env_config_visible_to_subprocesses(self, home, tmp_path):
        """[env] entries and --verbose reach spawned subprocesses."""
        # CATCHES: setEnvironmentVariables exports the [env] config to the
        # process (so every child inherits it) and --verbose additionally
        # exports CHEZMOI_VERBOSE=1; CHEZMOI_COMMAND names the subcommand.
        write_config(home, '[env]\n  MYVAR = "from-config"\n')
        result = run_chezmoi(
            ["--verbose", "cd"],
            env=sh_env(home, tmp_path),
            stdin=b'echo "MYVAR=$MYVAR V=$CHEZMOI_VERBOSE C=$CHEZMOI_COMMAND"\n',
        )
        assert result.returncode == 0
        assert result.stdout == "MYVAR=from-config V=1 C=cd\n"
        assert result.stderr == ""

    def test_env_reserved_variable_warns_and_still_sets(self, home, tmp_path):
        """[env] may set a reserved CHEZMOI_ variable, with a warning."""
        # CATCHES: keys with the CHEZMOI_ prefix produce a warning on stderr
        # but are still exported to child processes.
        write_config(home, '[env]\n  CHEZMOI_RESERVED = "custom-value"\n')
        result = subshell(home, tmp_path, 'echo "R=$CHEZMOI_RESERVED"\n')
        assert result.returncode == 0
        assert result.stdout == "R=custom-value\n"
        assert result.stderr == (
            "chezmoi: warning: CHEZMOI_RESERVED: "
            "overriding reserved environment variable\n"
        )

    def test_env_and_script_env_conflict(self, home, tmp_path):
        """setting both [env] and [scriptEnv] is a configuration error."""
        # CATCHES: the two sections are mutually exclusive and the conflict is
        # detected in the pre-run phase, before any command output.
        write_config(
            home, '[env]\n  A = "1"\n[scriptEnv]\n  B = "2"\n'
        )
        e = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["apply"], env=e)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: only one of env or scriptEnv may be set\n"


class TestSourceDirDiscovery:
    @pytest.mark.parametrize(
        "which",
        [
            pytest.param("data-dirs-fallback", id="data-dirs-fallback"),
            pytest.param("data-home-first", id="data-home-first"),
        ],
    )
    def test_source_dir_from_xdg_data_dirs(self, home, tmp_path, which):
        """the source directory is discovered through the XDG data search."""
        # CATCHES: $XDG_DATA_HOME (default ~/.local/share) is searched before
        # the entries of $XDG_DATA_DIRS, and a chezmoi directory in the data
        # dirs is used only when the data home has none.
        dd = tmp_path / "xdg-data-dirs" / "chezmoi"
        dd.mkdir(parents=True)
        (dd / "dot_ddfile").write_text("fromdatadirs\n")
        if which == "data-home-first":
            sd = source_dir(home)
            sd.mkdir(parents=True)
            (sd / "dot_homefile").write_text("fromdatahome\n")
        e = child_env(
            home, tmpdir=tmp_path / "tmp", XDG_DATA_DIRS=str(tmp_path / "xdg-data-dirs")
        )
        result = run_chezmoi(["apply"], env=e)
        assert result.returncode == 0
        assert result.stderr == ""
        if which == "data-home-first":
            assert (home / ".homefile").read_text() == "fromdatahome\n"
            assert not (home / ".ddfile").exists()
        else:
            assert (home / ".ddfile").read_text() == "fromdatadirs\n"

    def test_chezmoiroot_redirects_source_dir(self, home, tmp_path):
        """a .chezmoiroot file redirects the source directory."""
        # CATCHES: the source state is read from the subdirectory named by
        # .chezmoiroot (whitespace-trimmed), which is also what
        # CHEZMOI_SOURCE_DIR reports to subshells.
        sd = source_dir(home)
        (sd / "mydots").mkdir(parents=True)
        (sd / ".chezmoiroot").write_text("mydots\n")
        (sd / "mydots" / "dot_subfile").write_text("fromsub\n")
        (sd / "dot_topfile").write_text("fromtop\n")
        result = subshell(home, tmp_path, 'echo "SRC=$CHEZMOI_SOURCE_DIR"\n')
        assert result.returncode == 0
        assert result.stdout == f"SRC={sd}/mydots\n"
        assert result.stderr == ""
        apply = run_chezmoi(["apply"], env=child_env(home, tmpdir=tmp_path / "tmp"))
        assert apply.returncode == 0
        assert (home / ".subfile").read_text() == "fromsub\n"
        assert not (home / ".topfile").exists()

    @pytest.mark.parametrize(
        "content",
        [
            pytest.param("/etc\n", id="absolute"),
            pytest.param("../evil\n", id="parent"),
        ],
    )
    def test_chezmoiroot_invalid(self, home, tmp_path, content):
        """an untrusted .chezmoiroot value is rejected."""
        # CATCHES: only a plain relative path is accepted; absolute paths and
        # parent traversal make every command that reads the source state fail
        # with the .chezmoiroot file named in the error.
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / ".chezmoiroot").write_text(content)
        stripped = content.strip()
        e = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["apply"], env=e)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            f"chezmoi: .chezmoiroot: {stripped}: invalid path\n"
        )


class TestChezmoiversion:
    @pytest.mark.parametrize(
        "content,expected_error",
        [
            pytest.param(
                "notasemver\n",
                '"notasemver\\n": notasemver is not in dotted-tri format',
                id="not-semver",
            ),
            pytest.param(
                "  v2.0.0 \n",
                '"  v2.0.0 \\n": strconv.ParseInt: parsing "v2": invalid syntax',
                id="v-prefix",
            ),
            pytest.param("1.0.0\n", None, id="valid"),
        ],
    )
    def test_chezmoiversion(self, home, tmp_path, content, expected_error):
        """.chezmoiversion must parse as a bare semantic version."""
        # CATCHES: the file's raw bytes appear %q-quoted (with the trailing
        # newline visible) in the error, and unlike elsewhere chezmoi does NOT
        # strip a "v" prefix here; a valid version is silently accepted.
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / ".chezmoiversion").write_text(content)
        (sd / "dot_vfile").write_text("v\n")
        e = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["apply"], env=e)
        if expected_error is None:
            assert result.returncode == 0
            assert result.stderr == ""
            assert (home / ".vfile").read_text() == "v\n"
        else:
            assert result.returncode == 1
            assert result.stdout == ""
            assert result.stderr == (
                f"chezmoi: {sd}/.chezmoiversion: {expected_error}\n"
            )


class TestConfigTemplateWarning:
    def test_config_template_changed_warning(self, home, tmp_path):
        """a changed config template warns unless --force accepts it."""
        # CATCHES: the template's hash is remembered in the persistent state
        # by init; apply warns (only when warnings.configFileTemplateHasChanged
        # is enabled) when it differs, --force re-records it silently, and the
        # same happens when the template is deleted; deleting the template
        # under --force also clears the remembered state.
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / ".chezmoi.toml.tmpl").write_text('value = "one"\n')
        (sd / "dot_hello").write_text("hello\n")
        e = child_env(home, tmpdir=tmp_path / "tmp")
        assert run_chezmoi(["init", "--apply"], env=e).returncode == 0
        assert (home / ".config" / "chezmoi" / "chezmoi.toml").read_text() == (
            'value = "one"\n'
        )

        # Enable the warning and change the template.
        write_config(
            home,
            'value = "one"\n[warnings]\n  configFileTemplateHasChanged = true\n',
        )
        (sd / ".chezmoi.toml.tmpl").write_text('value = "two"\n')
        result = run_chezmoi(["apply"], env=e)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: warning: config file template has changed, "
            "run chezmoi init to regenerate config file\n"
        )

        # --force accepts the new template and records its hash.
        forced = run_chezmoi(["apply", "--force"], env=e)
        assert forced.returncode == 0
        assert forced.stderr == ""
        again = run_chezmoi(["apply"], env=e)
        assert again.returncode == 0
        assert again.stderr == ""

        # Deleting the template warns again, and --force clears the state.
        (sd / ".chezmoi.toml.tmpl").unlink()
        removed = run_chezmoi(["apply"], env=e)
        assert removed.returncode == 0
        assert removed.stderr == (
            "chezmoi: warning: config file template has changed, "
            "run chezmoi init to regenerate config file\n"
        )
        forced2 = run_chezmoi(["apply", "--force"], env=e)
        assert forced2.returncode == 0
        assert forced2.stderr == ""
        final = run_chezmoi(["apply"], env=e)
        assert final.returncode == 0
        assert final.stderr == ""
        assert (home / ".hello").read_text() == "hello\n"

    def test_multiple_config_templates_error(self, home, tmp_path):
        """two config file templates in the source directory are refused."""
        # CATCHES: only one .chezmoi.<format>.tmpl may exist; the error lists
        # both source paths joined with "and" and ends with a literal space
        # (a quirk of the upstream format string).
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / ".chezmoi.toml.tmpl").write_text('value = "one"\n')
        (sd / ".chezmoi.yaml.tmpl").write_text("value: one\n")
        e = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["init"], env=e)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: multiple config file templates: "
            f"{sd}/.chezmoi.toml.tmpl and {sd}/.chezmoi.yaml.tmpl \n"
        )

    @pytest.mark.parametrize(
        "template,expected_error",
        [
            pytest.param(
                'value = "x"\n[[[\n',
                "toml: line 2: expected '.' or ']' to end table name, "
                "but got '[' instead",
                id="bad-toml",
            ),
            pytest.param(
                'value = "{{ .bogus }}"\n',
                'template: chezmoi.toml:1:12: executing "chezmoi.toml" '
                'at <.bogus>: map has no entry for key "bogus"',
                id="template-error",
            ),
        ],
    )
    def test_init_renders_invalid_config(self, home, tmp_path, template, expected_error):
        """init refuses to write a config that does not parse."""
        # CATCHES: the rendered config is validated before it is written, and
        # the error names the template's source path and, for template
        # failures, the template name "chezmoi.toml" (the target file name,
        # not the .tmpl source name).
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / ".chezmoi.toml.tmpl").write_text(template)
        e = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["init"], env=e)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == f"chezmoi: {sd}/.chezmoi.toml.tmpl: {expected_error}\n"
        assert not (home / ".config" / "chezmoi" / "chezmoi.toml").exists()


class TestEditConfig:
    def test_edit_config_verifies_modified_config(self, home, tmp_path, bin_dir):
        """edit-config warns when the editor leaves an unparseable config."""
        # CATCHES: after the editor exits the post-run hook re-reads the
        # config file and reports the parse error as a warning (the command
        # still succeeds); the editor sleeps past edit.minDuration's default
        # of 1s so that the separate "returned in less than 1s" warning does
        # not also fire.
        write_config(home, '[env]\n  A = "1"\n')
        editor = write_script(
            bin_dir / "sloweditor",
            "#!/bin/sh\nsleep 1.1\nprintf 'not toml at all [[[' >> \"$1\"\necho EDITOR-RAN\n",
        )
        assert editor.exists()
        e = child_env(
            home, tmpdir=tmp_path / "tmp", path=f"{bin_dir}:{SYSTEM_PATH}", EDITOR="sloweditor"
        )
        result = run_chezmoi(["edit-config"], env=e)
        assert result.returncode == 0
        assert result.stdout == "EDITOR-RAN\n"
        assert result.stderr == (
            f"chezmoi: warning: {home}/.config/chezmoi/chezmoi.toml: "
            'toml: line 3 (last key "env"): '
            "expected '.' or '=', but got 't' instead\n"
        )


class TestDiffPager:
    """The pager that verbose diff output is piped through (config.go)."""

    # A pager that reports the environment chezmoi gives it and tags every
    # line it reads, so both the env and the piping are observable.
    PAGER = """#!/bin/sh
printf 'PAGER-START LESS=%s LV=%s\\n' "$LESS" "$LV"
sed -e 's/^/PAGER| /'
printf 'PAGER-END\\n'
"""

    # A pager that only prints its arguments, to observe pagerArgs and which
    # pager config section won.
    ARGS_PAGER = """#!/bin/sh
echo "MYARGS:[$*]"
"""

    def paged_env(self, home, tmp_path, bin_dir, config):
        write_script(bin_dir / "mypager", self.PAGER)
        write_script(bin_dir / "mypager2", self.ARGS_PAGER)
        write_config(home, config)
        return child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{bin_dir}:{SYSTEM_PATH}",
            LESS=None,
            LV=None,
        )

    def add_newfile(self, env, home, contents="newstuff\n"):
        (home / ".newfile").write_text(contents)
        return run_chezmoi(["add", "--verbose", str(home / ".newfile")], env=env)

    def test_pager_receives_verbose_diff_and_default_env(
        self, home, tmp_path, bin_dir
    ):
        """verbose add output is piped through the configured pager."""
        # CATCHES: the diff never reaches stdout directly (the pager's own
        # output does), and the pager is started with LESS=FRX and LV=-c set
        # the way git sets them for its pagers.
        source_dir(home).mkdir(parents=True)
        (source_dir(home) / "dot_managed").write_text("orig\n")
        e = self.paged_env(home, tmp_path, bin_dir, 'pager = "mypager"\n')
        result = self.add_newfile(e, home)
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == (
            "PAGER-START LESS=FRX LV=-c\n"
            "PAGER| diff --git a/dot_newfile b/dot_newfile\n"
            "PAGER| new file mode 100644\n"
            "PAGER| index 0000000000000000000000000000000000000000"
            "..fb65374e693493f10699632360565492618b8e66\n"
            "PAGER| --- /dev/null\n"
            "PAGER| +++ b/dot_newfile\n"
            "PAGER| @@ -0,0 +1 @@\n"
            "PAGER| +newstuff\n"
            "PAGER-END\n"
        )

    def test_no_pager_flag_writes_diff_directly(self, home, tmp_path, bin_dir):
        """--no-pager bypasses the configured pager."""
        # CATCHES: with --no-pager the diff is written straight to stdout with
        # no pager process in between (no PAGER-START/PAGER-END framing).
        source_dir(home).mkdir(parents=True)
        (source_dir(home) / "dot_managed").write_text("orig\n")
        e = self.paged_env(home, tmp_path, bin_dir, 'pager = "mypager"\n')
        (home / ".newfile").write_text("newstuff\n")
        result = run_chezmoi(
            ["add", "--verbose", "--no-pager", str(home / ".newfile")], env=e
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == (
            "diff --git a/dot_newfile b/dot_newfile\n"
            "new file mode 100644\n"
            "index 0000000000000000000000000000000000000000"
            "..fb65374e693493f10699632360565492618b8e66\n"
            "--- /dev/null\n"
            "+++ b/dot_newfile\n"
            "@@ -0,0 +1 @@\n"
            "+newstuff\n"
        )

    def test_pager_with_spaces_runs_via_shell(self, home, tmp_path):
        """a pager containing whitespace is executed through the shell."""
        # CATCHES: a multi-word pager string is run as `$SHELL -c <string>`,
        # so shell syntax like `;` works and the diff is filtered by the
        # shell command, not exec'ed as a single program name.
        source_dir(home).mkdir(parents=True)
        (source_dir(home) / "dot_managed").write_text("orig\n")
        write_config(
            home, 'pager = "tr a-z A-Z ; echo PAGERDONE"\n'
        )
        e = child_env(home, tmpdir=tmp_path / "tmp", shell="/bin/bash")
        (home / ".newfile").write_text("newstuff\n")
        result = run_chezmoi(
            ["add", "--verbose", str(home / ".newfile")], env=e
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == (
            "DIFF --GIT A/DOT_NEWFILE B/DOT_NEWFILE\n"
            "NEW FILE MODE 100644\n"
            "INDEX 0000000000000000000000000000000000000000"
            "..FB65374E693493F10699632360565492618B8E66\n"
            "--- /DEV/NULL\n"
            "+++ B/DOT_NEWFILE\n"
            "@@ -0,0 +1 @@\n"
            "+NEWSTUFF\n"
            "PAGERDONE\n"
        )

    def test_diff_pager_overrides_pager(self, home, tmp_path, bin_dir):
        """diff.pager and diff.pagerArgs override pager and pagerArgs."""
        # CATCHES: the diff.pager section takes precedence over the top-level
        # pager, and its pagerArgs are passed to the winning command while
        # the top-level pagerArgs are ignored.
        source_dir(home).mkdir(parents=True)
        (source_dir(home) / "dot_managed").write_text("orig\n")
        e = self.paged_env(
            home,
            tmp_path,
            bin_dir,
            'pager = "mypager"\npagerArgs = ["unused"]\n'
            '[diff]\n  pager = "mypager2"\n  pagerArgs = ["from-diff"]\n',
        )
        result = self.add_newfile(e, home)
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == "MYARGS:[from-diff]\n"
