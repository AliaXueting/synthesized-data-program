"""Tests for `chezmoi upgrade`'s download-and-replace flow.

Every step of the flow sits behind a call to the GitHub API, so these tests
point the binary's HTTPS traffic at a loopback proxy (the child gets
HTTPS_PROXY and trusts the proxy's certificate via SSL_CERT_FILE): all
requests stay on 127.0.0.1 and are answered from a canned v2.60.0 release.
That makes the release lookup, archive download, checksum verification,
executable replacement and installer invocations observable without any
network access. Expected outputs below were all recorded from the reference
binary through that proxy.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path

import pytest

from conftest import (
    EXECUTABLE,
    FAKE_BREW,
    FAKE_DEB_DATA,
    FAKE_DPKG,
    FAKE_FAILING_INSTALLER,
    FAKE_LDD_FAIL,
    FAKE_LDD_OK,
    FAKE_PATH_CHEZMOI,
    FAKE_SNAP,
    FAKE_SUDO,
    FAKE_UPGRADED_BINARY,
    SYSTEM_PATH,
    UPGRADE_API_PATH,
    UPGRADE_CHECKSUMS_ASSET,
    UPGRADE_DEB_ASSET,
    UPGRADE_GLIBC_ASSET,
    UPGRADE_MUSL_ASSET,
    UPGRADE_RELEASE_TAG,
    child_env,
    doctor_lines,
    record_dir,
    recorded_args,
    run_chezmoi,
    serve_release,
    write_script,
)

# The reference binary's own version line, as printed by `--version` and by
# the "before:" half of a verbose upgrade.
VERSION_LINE = (
    "chezmoi version dev, commit 40dcf243fbdda2b8dc912aa02f7ddb2219b96f6b, "
    "built at 2026-10-16T14:44:24Z, built by source"
)
NEW_BINARY_STDOUT = "fake-upgraded-chezmoi 2.60.0\n"
DEV_REFUSAL = (
    "chezmoi: cannot upgrade dev version to latest released version "
    "unless --force is set\n"
)
DEAD_PROXY = "http://127.0.0.1:1"
PROXYCONNECT_ERROR = (
    'chezmoi: Get "https://api.github.com/repos/twpayne/chezmoi/releases/latest": '
    "proxyconnect tcp: dial tcp 127.0.0.1:1: connect: connection refused\n"
)


def download_path(asset: str) -> str:
    return f"/twpayne/chezmoi/releases/download/{UPGRADE_RELEASE_TAG}/{asset}"


def put_binary(path: Path) -> Path:
    """Place a runnable copy of the binary under test at path."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(Path(EXECUTABLE).read_bytes())
    path.chmod(0o755)
    return path


def proxy_env(home: Path, tmp_path: Path, proxy, *, fbin: Path | None = None, **extra):
    """The pinned child environment, routed through the loopback proxy."""
    path = f"{fbin}:{SYSTEM_PATH}" if fbin is not None else SYSTEM_PATH
    return child_env(
        home,
        tmpdir=tmp_path / "tmp",
        path=path,
        HTTPS_PROXY=proxy.url,
        SSL_CERT_FILE=str(proxy.ca),
        **extra,
    )


class TestUpgradeReplaceExecutable:
    def test_upgrade_force_replaces_executable_in_home(
        self, home, tmp_path, github_proxy
    ):
        """upgrade --force downloads, verifies and swaps the target binary."""
        serve_release(github_proxy)
        target = put_binary(home / "bin" / "chezmoi")
        env = proxy_env(home, tmp_path, github_proxy)
        result = run_chezmoi(["upgrade", "--force", f"--executable={target}"], env=env)
        assert result.returncode == 0
        assert result.stdout == NEW_BINARY_STDOUT
        assert result.stderr == ""
        # CATCHES: the archive's chezmoi entry replaces the target file
        # byte-for-byte, is installed with mode 0755, and the new version is
        # then exec'ed with --version with its output on stdout.
        assert target.read_bytes() == FAKE_UPGRADED_BINARY
        assert target.stat().st_mode & 0o777 == 0o755

    def test_upgrade_verbose_prints_before_and_after(self, home, tmp_path, github_proxy):
        """a verbose upgrade prints the old version, then the new one's."""
        serve_release(github_proxy)
        target = put_binary(home / "bin" / "chezmoi")
        env = proxy_env(home, tmp_path, github_proxy)
        result = run_chezmoi(
            ["upgrade", "--force", "-v", f"--executable={target}"], env=env
        )
        assert result.returncode == 0
        assert result.stderr == ""
        # CATCHES: -v prints "before: <full version line>" and a trailing
        # "after: " with no newline, so the replaced binary's --version
        # output continues that same line.
        assert result.stdout == f"before: {VERSION_LINE}\nafter: {NEW_BINARY_STDOUT}"

    def test_upgrade_glibc_archive_when_ldd_succeeds(
        self, home, tmp_path, github_proxy, bin_dir
    ):
        """a target that ldd accepts selects the glibc archive."""
        serve_release(github_proxy)
        write_script(bin_dir / "ldd", FAKE_LDD_OK)
        target = put_binary(home / "bin" / "chezmoi")
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir)
        result = run_chezmoi(["upgrade", "--force", f"--executable={target}"], env=env)
        assert result.returncode == 0
        assert result.stdout == NEW_BINARY_STDOUT
        paths = github_proxy.requested_paths()
        # CATCHES: ldd succeeding on the target switches the downloaded
        # archive name from linux-musl to linux-glibc.
        assert download_path(UPGRADE_GLIBC_ASSET) in paths
        assert download_path(UPGRADE_MUSL_ASSET) not in paths


class TestUpgradeChecksums:
    def test_upgrade_checksum_mismatch(self, home, tmp_path, github_proxy, bin_dir):
        """a wrong checksum in checksums.txt aborts the replacement."""
        release = serve_release(github_proxy, checksums="zeros")
        write_script(bin_dir / "ldd", FAKE_LDD_FAIL)
        target = put_binary(home / "bin" / "chezmoi")
        original = target.read_bytes()
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir)
        result = run_chezmoi(["upgrade", "--force", f"--executable={target}"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        got = hashlib.sha256(release.archive).hexdigest()
        # CATCHES: the failure message names the archive, the checksum that
        # checksums.txt claimed and the checksum actually computed, and the
        # target binary is left untouched.
        assert result.stderr == (
            f"chezmoi: {UPGRADE_MUSL_ASSET}: checksum failed "
            f"(want {'0' * 64}, got {got})\n"
        )
        assert target.read_bytes() == original

    def test_upgrade_checksum_entry_missing(self, home, tmp_path, github_proxy, bin_dir):
        """an archive absent from checksums.txt cannot be verified."""
        serve_release(github_proxy, checksums="unrelated")
        write_script(bin_dir / "ldd", FAKE_LDD_FAIL)
        target = put_binary(home / "bin" / "chezmoi")
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir)
        result = run_chezmoi(["upgrade", "--force", f"--executable={target}"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: the download itself succeeded; it is the lookup in
        # checksums.txt that fails, with the archive named in the message.
        assert result.stderr == f"chezmoi: {UPGRADE_MUSL_ASSET}: checksum not found\n"

    def test_upgrade_archive_asset_not_in_release(self, home, tmp_path, github_proxy, bin_dir):
        """a release without a matching archive fails before any download."""
        serve_release(github_proxy, include_archives=False)
        write_script(bin_dir / "ldd", FAKE_LDD_FAIL)
        target = put_binary(home / "bin" / "chezmoi")
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir)
        result = run_chezmoi(["upgrade", "--force", f"--executable={target}"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: only the release lookup happens; no archive and no
        # checksums.txt is fetched for a release lacking the asset.
        assert result.stderr == f"chezmoi: {UPGRADE_MUSL_ASSET}: cannot find release asset\n"
        assert github_proxy.requested_paths() == [UPGRADE_API_PATH]

    def test_upgrade_checksums_asset_not_in_release(
        self, home, tmp_path, github_proxy, bin_dir
    ):
        """a release without checksums.txt fails after the archive download."""
        serve_release(github_proxy, include_checksums=False)
        write_script(bin_dir / "ldd", FAKE_LDD_FAIL)
        target = put_binary(home / "bin" / "chezmoi")
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir)
        result = run_chezmoi(["upgrade", "--force", f"--executable={target}"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: the archive is downloaded first and only then is the
        # checksums.txt asset looked up, so exactly two requests are made.
        assert result.stderr == (
            f"chezmoi: {UPGRADE_CHECKSUMS_ASSET}: cannot find release asset\n"
        )
        assert github_proxy.requested_paths() == [
            UPGRADE_API_PATH,
            download_path(UPGRADE_MUSL_ASSET),
        ]

    def test_upgrade_download_returns_404(self, home, tmp_path, github_proxy, bin_dir):
        """a download URL that answers 404 is reported with the full URL."""
        serve_release(github_proxy, drop_downloads=(UPGRADE_MUSL_ASSET,))
        write_script(bin_dir / "ldd", FAKE_LDD_FAIL)
        target = put_binary(home / "bin" / "chezmoi")
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir)
        result = run_chezmoi(["upgrade", "--force", f"--executable={target}"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: the error carries the complete browser download URL and
        # the HTTP status text, not just the asset name.
        assert result.stderr == (
            "chezmoi: https://github.com/twpayne/chezmoi/releases/download/"
            f"{UPGRADE_RELEASE_TAG}/{UPGRADE_MUSL_ASSET}: 404 Not Found\n"
        )


class TestUpgradeMethods:
    def test_upgrade_invalid_method_checked_after_release_fetch(self, home, tmp_path, github_proxy):
        """an unknown --method fails only after the release is fetched."""
        serve_release(github_proxy)
        env = proxy_env(home, tmp_path, github_proxy)
        result = run_chezmoi(["upgrade", "--force", "--method=bogus"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: the method is validated after the GitHub release lookup,
        # not before it: the release request is made even for a bogus method.
        assert result.stderr == "chezmoi: bogus: invalid method\n"
        assert github_proxy.requested_paths() == [UPGRADE_API_PATH]

    def test_upgrade_winget_method_unsupported_on_unix(self, home, tmp_path, github_proxy):
        """winget-upgrade is refused on this platform."""
        serve_release(github_proxy)
        env = proxy_env(home, tmp_path, github_proxy)
        result = run_chezmoi(
            ["upgrade", "--force", "--method=winget-upgrade"], env=env
        )
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: the Windows-only method has its own "unsupported upgrade
        # method" error, distinct from the "invalid method" wording.
        assert result.stderr == "chezmoi: unsupported upgrade method\n"

    def test_upgrade_brew_upgrade_runs_brew_then_needs_chezmoi(
        self, home, tmp_path, github_proxy, bin_dir
    ):
        """brew-upgrade runs `brew upgrade chezmoi` and then needs chezmoi."""
        serve_release(github_proxy)
        record = record_dir(tmp_path)
        write_script(bin_dir / "brew", FAKE_BREW)
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir, RECORD_DIR=str(record))
        result = run_chezmoi(["upgrade", "--force", "--method=brew-upgrade"], env=env)
        assert result.returncode == 1
        # CATCHES: brew's stdout is streamed into chezmoi's stdout, brew is
        # invoked as `upgrade chezmoi`, and the command then fails because
        # the new version must be found in $PATH (nothing was replaced).
        assert result.stdout == "fake-brew-ran\n"
        assert result.stderr == 'chezmoi: exec: "chezmoi": executable file not found in $PATH\n'
        assert recorded_args(record) == ["upgrade", "chezmoi"]

    def test_upgrade_brew_upgrade_execs_chezmoi_from_path(
        self, home, tmp_path, github_proxy, bin_dir
    ):
        """after brew-upgrade the new version comes from $PATH."""
        serve_release(github_proxy)
        record = record_dir(tmp_path)
        write_script(bin_dir / "brew", FAKE_BREW)
        write_script(bin_dir / "chezmoi", FAKE_PATH_CHEZMOI)
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir, RECORD_DIR=str(record))
        result = run_chezmoi(["upgrade", "--force", "--method=brew-upgrade"], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        # CATCHES: unlike replace-executable, brew-upgrade does not exec the
        # --executable path but whatever `chezmoi` resolves to in $PATH.
        assert result.stdout == "fake-brew-ran\nfake-path-chezmoi-ran\n"
        assert recorded_args(record) == ["upgrade", "chezmoi"]

    def test_upgrade_snap_refresh_runs_snap(self, home, tmp_path, github_proxy, bin_dir):
        """snap-refresh runs `snap refresh chezmoi` and then $PATH's chezmoi."""
        serve_release(github_proxy)
        record = record_dir(tmp_path)
        write_script(bin_dir / "snap", FAKE_SNAP)
        write_script(bin_dir / "chezmoi", FAKE_PATH_CHEZMOI)
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir, RECORD_DIR=str(record))
        result = run_chezmoi(["upgrade", "--force", "--method=snap-refresh"], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == "fake-snap-ran\nfake-path-chezmoi-ran\n"
        # CATCHES: the snap method shells out to `snap refresh chezmoi`
        # rather than downloading anything itself.
        assert recorded_args(record) == ["refresh", "chezmoi"]


class TestUpgradePackage:
    def test_upgrade_package_downloads_and_installs_deb(
        self, home, tmp_path, github_proxy, bin_dir, deb_distro
    ):
        """upgrade-package downloads the .deb and runs dpkg -i on it."""
        serve_release(github_proxy)
        record = record_dir(tmp_path)
        write_script(bin_dir / "dpkg", FAKE_DPKG)
        write_script(bin_dir / "chezmoi", FAKE_PATH_CHEZMOI)
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir, RECORD_DIR=str(record))
        result = run_chezmoi(["upgrade", "--force", "--method=upgrade-package"], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == "fake-dpkg-ran\nfake-path-chezmoi-ran\n"
        # CATCHES: the package is fetched, checksum-verified and written
        # under $TMPDIR (mode 0644) before `dpkg -i <path>` runs, and the
        # exact release asset name is used for the file.
        assert github_proxy.requested_paths() == [
            UPGRADE_API_PATH,
            download_path(UPGRADE_DEB_ASSET),
            download_path(UPGRADE_CHECKSUMS_ASSET),
        ]
        args = recorded_args(record)
        assert args[0] == "-i"
        assert args[1].startswith(str(tmp_path / "tmp") + "/chezmoi")
        assert args[1].endswith("/" + UPGRADE_DEB_ASSET)
        assert (record / "package-copy").read_bytes() == FAKE_DEB_DATA
        assert (record / "pkg-mode").read_text() == "644\n"

    def test_upgrade_package_installer_failure(self, home, tmp_path, github_proxy, bin_dir, deb_distro):
        """a failing package installer aborts the upgrade."""
        serve_release(github_proxy)
        write_script(bin_dir / "dpkg", FAKE_FAILING_INSTALLER)
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir)
        result = run_chezmoi(["upgrade", "--force", "--method=upgrade-package"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: the installer's exit status is reported wrapped in the
        # installer's own name, here `dpkg: exit status 3`.
        assert result.stderr == "chezmoi: dpkg: exit status 3\n"


class TestUpgradeMethodDetection:
    def test_upgrade_executable_stat_error(self, home, tmp_path, github_proxy):
        """a nonexistent --executable fails when the method is detected."""
        serve_release(github_proxy)
        missing = tmp_path / "nope" / "chezmoi"
        env = proxy_env(home, tmp_path, github_proxy)
        result = run_chezmoi(
            ["upgrade", "--force", f"--executable={missing}"], env=env
        )
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: with no --method, the upgrade stats the executable to
        # detect the method and reports the raw stat error for a missing
        # file, after the release has been fetched.
        assert result.stderr == f"chezmoi: stat {missing}: no such file or directory\n"

    def test_upgrade_executable_owned_by_other_user(self, home, tmp_path, github_proxy):
        """an executable owned by another user cannot be upgraded."""
        serve_release(github_proxy)
        target = put_binary(tmp_path / "elsewhere" / "chezmoi")
        os.chown(target, 1000, 1000)
        original = target.read_bytes()
        env = proxy_env(home, tmp_path, github_proxy)
        result = run_chezmoi(["upgrade", "--force", f"--executable={target}"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: outside $HOME and $TMPDIR, an executable owned by a user
        # that is neither the caller nor root is refused with the path in
        # the message; the file is not modified.
        assert result.stderr == (
            f"chezmoi: {target}: cannot upgrade executable owned by "
            "non-current non-root user\n"
        )
        assert target.read_bytes() == original

    def test_upgrade_method_flag_overrides_detection(self, home, tmp_path, github_proxy):
        """--method=replace-executable works outside $HOME too."""
        serve_release(github_proxy)
        target = put_binary(tmp_path / "elsewhere" / "chezmoi")
        env = proxy_env(home, tmp_path, github_proxy)
        result = run_chezmoi(
            [
                "upgrade",
                "--force",
                "--method=replace-executable",
                f"--executable={target}",
            ],
            env=env,
        )
        assert result.returncode == 0
        assert result.stdout == NEW_BINARY_STDOUT
        # CATCHES: this root-owned location would otherwise pick the
        # upgrade-package method; the explicit flag forces replacement.
        assert target.read_bytes() == FAKE_UPGRADED_BINARY

    def test_upgrade_without_executable_uses_running_binary(
        self, home, tmp_path, github_proxy, binary_copy, bin_dir, deb_distro
    ):
        """without --executable the running binary itself is the target."""
        serve_release(github_proxy)
        record = record_dir(tmp_path)
        write_script(bin_dir / "dpkg", FAKE_DPKG)
        write_script(bin_dir / "chezmoi", FAKE_PATH_CHEZMOI)
        env = proxy_env(home, tmp_path, github_proxy, fbin=bin_dir, RECORD_DIR=str(record))
        result = run_chezmoi(["upgrade", "--force"], env=env, exe=str(binary_copy))
        assert result.returncode == 0
        assert result.stderr == ""
        # CATCHES: the invoked binary lives outside $HOME and $TMPDIR and is
        # root-owned, so the detected method is upgrade-package and dpkg is
        # pointed at the downloaded .deb.
        assert result.stdout == "fake-dpkg-ran\nfake-path-chezmoi-ran\n"
        args = recorded_args(record)
        assert args[0] == "-i"
        assert args[1].endswith("/" + UPGRADE_DEB_ASSET)


class TestUpgradeNetworkErrors:
    def test_upgrade_reports_network_errors(self, home, tmp_path):
        """an unreachable proxy produces a wrapped network error."""
        env = child_env(home, tmpdir=tmp_path / "tmp", HTTPS_PROXY=DEAD_PROXY)
        result = run_chezmoi(["upgrade", "--force"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: --force bypasses the dev-version guard, and the GitHub
        # API request then fails with the transport error, including the
        # API URL, wrapped in chezmoi's own error prefix.
        assert result.stderr == PROXYCONNECT_ERROR

    def test_upgrade_dev_guard_precedes_network(self, home, tmp_path):
        """the dev-version guard runs before any network access."""
        env = child_env(home, tmpdir=tmp_path / "tmp", HTTPS_PROXY=DEAD_PROXY)
        result = run_chezmoi(["upgrade"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        # CATCHES: even with the network unreachable, a dev version without
        # --force reports the --force refusal, never the network error.
        assert result.stderr == DEV_REFUSAL


class TestUpgradeAsNonRoot:
    def test_upgrade_nonroot_uses_sudo_prefix(self, nonroot_tree, github_proxy, deb_distro):
        """a non-root caller upgrades a root-owned binary via sudo."""
        serve_release(github_proxy)
        write_script(nonroot_tree.bin / "sudo", FAKE_SUDO)
        write_script(nonroot_tree.bin / "chezmoi", FAKE_PATH_CHEZMOI)
        env = child_env(
            nonroot_tree.home,
            tmpdir=nonroot_tree.tmp,
            path=f"{nonroot_tree.bin}:{SYSTEM_PATH}",
            HTTPS_PROXY=github_proxy.url,
            SSL_CERT_FILE=str(github_proxy.ca),
            RECORD_DIR=str(nonroot_tree.record),
        )
        result = run_chezmoi(
            ["upgrade", "--force", f"--executable={nonroot_tree.target}"],
            env=env,
            exe=str(nonroot_tree.exe),
            uid=1000,
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == "fake-sudo-ran\nfake-path-chezmoi-ran\n"
        args = recorded_args(nonroot_tree.record / "sudo")
        # CATCHES: because sudo is found in $PATH, the package is installed
        # through `sudo dpkg -i <package>` rather than dpkg directly.
        assert args[:2] == ["dpkg", "-i"]
        assert args[2].startswith(str(nonroot_tree.tmp) + "/chezmoi")
        assert args[2].endswith("/" + UPGRADE_DEB_ASSET)

    def test_upgrade_nonroot_without_sudo(self, nonroot_tree, github_proxy, deb_distro):
        """without sudo in $PATH the package is installed directly."""
        serve_release(github_proxy)
        write_script(nonroot_tree.bin / "dpkg", FAKE_DPKG)
        write_script(nonroot_tree.bin / "chezmoi", FAKE_PATH_CHEZMOI)
        env = child_env(
            nonroot_tree.home,
            tmpdir=nonroot_tree.tmp,
            # A $PATH holding only the fake commands: the machine's real
            # sudo in /usr/bin must not be visible for this variant.
            path=str(nonroot_tree.bin),
            HTTPS_PROXY=github_proxy.url,
            SSL_CERT_FILE=str(github_proxy.ca),
            RECORD_DIR=str(nonroot_tree.record),
        )
        result = run_chezmoi(
            ["upgrade", "--force", f"--executable={nonroot_tree.target}"],
            env=env,
            exe=str(nonroot_tree.exe),
            uid=1000,
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == "fake-dpkg-ran\nfake-path-chezmoi-ran\n"
        args = recorded_args(nonroot_tree.record)
        # CATCHES: dpkg runs without a sudo prefix, and the verified package
        # it is pointed at still carries the release asset's exact bytes.
        assert args[0] == "-i"
        assert args[1].endswith("/" + UPGRADE_DEB_ASSET)
        assert (nonroot_tree.record / "package-copy").read_bytes() == FAKE_DEB_DATA

    def test_doctor_nonroot_reports_sudo_upgrade_method(self, nonroot_tree):
        """doctor shows the sudo-prefixed method for a non-root caller."""
        write_script(nonroot_tree.bin / "sudo", "#!/bin/sh\nexit 0\n")
        env = child_env(
            nonroot_tree.home,
            tmpdir=nonroot_tree.tmp,
            path=f"{nonroot_tree.bin}:{SYSTEM_PATH}",
        )
        result = run_chezmoi(
            ["doctor", "--no-network"], env=env, exe=str(nonroot_tree.exe), uid=1000
        )
        lines = doctor_lines(result)
        # CATCHES: the same root-owned executable that reports
        # upgrade-package for root reports sudo-upgrade-package for another
        # user, because sudo is found in that user's $PATH.
        assert lines["upgrade-method"] == (
            "ok        upgrade-method              sudo-upgrade-package"
        )
