"""Tests for `chezmoi doctor`: the system check table and its exit code."""

from __future__ import annotations

import datetime
import os
import re
import shutil
from pathlib import Path

import pytest

from conftest import (
    EXECUTABLE,
    child_env,
    doctor_lines,
    make_git_env,
    run_chezmoi,
    run_git,
    source_dir,
    write_script,
)

# The doctor output is a tabwriter table: the RESULT column is padded to the
# width of its longest entry ("warning"/"skipped", 7 chars) plus three spaces,
# and the CHECK column to "bitwarden-secrets-command" (25 chars) plus three.
# Every expected line below was recorded from the reference binary.
COLUMN_RESULT_WIDTH = 10
COLUMN_CHECK_WIDTH = 28

# Checks whose message depends on the build or on the machine running the
# suite (version string, Go version, build flags, os-release, the invoked
# executable's own path and owner).
VOLATILE_CHECKS = {"version", "os-arch", "build-info", "go-version", "upgrade-method"}

# A fixed timestamp (UTC) used to pin the config file's modification time.
MTIME_EPOCH = int(
    datetime.datetime(2026, 1, 2, 3, 4, 5, tzinfo=datetime.timezone.utc).timestamp()
)

FAKE_UNAME = "Linux fakekernel 1.2.3-phony #7 SMP PREEMPT x86_64 GNU/Linux"

# The git stand-in used by the full-table test: it answers `--version` itself
# (so the recorded version is stable) and forwards everything else to the real
# git, which doctor invokes for the working-tree checks.
FAKE_GIT = """#!/bin/sh
if [ "$1" = "--version" ]; then
    printf 'git version 9.99.1\\n'
    exit 0
fi
exec /usr/bin/git "$@"
"""


def dline(result: str, check: str, message: str) -> str:
    """Render one expected line of doctor's table."""
    return f"{result:<{COLUMN_RESULT_WIDTH}}{check:<{COLUMN_CHECK_WIDTH}}{message}"


def link_executable(destination: Path) -> Path:
    """Place a runnable copy of the binary under test at destination."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(EXECUTABLE, destination)
    except OSError:
        shutil.copy2(EXECUTABLE, destination)
    return destination


def write_fakes(home: Path, fakes: dict[str, str]) -> Path:
    """Write fake commands into ~/bin; values are printf format strings."""
    bin_dir = home / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    for name, format_string in fakes.items():
        write_script(bin_dir / name, f"#!/bin/sh\nprintf '{format_string}'\n")
    return bin_dir


# The fake commands used by the full-table test. `myeditor`, `mymerge` and
# `mysecret` only need to exist; the others print a parsable version.
STANDARD_FAKES = {
    "uname": FAKE_UNAME + r"\n",
    "myeditor": "",
    "mymerge": "",
    "myage": "age 1.1.1\\n",
    "mygpg": "gpg (GnuPG) 2.4.4\\n",
    "mypinentry": "pinentry-cli (pinentry) 1.2.1\\n",
    "mysecret": "",
}


def write_standard_fakes(home: Path) -> Path:
    bin_dir = write_fakes(home, STANDARD_FAKES)
    write_script(bin_dir / "git", FAKE_GIT)
    return bin_dir


STANDARD_CONFIG = """\
encryption = "gpg"

[diff]
    command = "nosuchdiff"

[age]
    command = "myage"

[gpg]
    command = "mygpg"

[pinentry]
    command = "mypinentry"

[merge]
    command = "mymerge"

[keepassxc]
    database = "~/missing.kdbx"

[secret]
    command = "mysecret"
"""

# The table printed for the setup above, with the home directory concealed as
# ~ and the config file's modification time pinned. The "executable" line
# names the binary under test and is filled in at run time; the five
# VOLATILE_CHECKS lines are matched by regex instead.
STANDARD_TABLE = """\
RESULT    CHECK                       MESSAGE
skipped   latest-version              no network
ok        uname                       Linux fakekernel 1.2.3-phony #7 SMP PREEMPT x86_64 GNU/Linux
ok        executable                  {executable}
ok        config-file                 found ~/.config/chezmoi/chezmoi.toml, last modified 2026-01-02T03:04:05Z
ok        source-dir                  ~/.local/share/chezmoi is a directory
ok        suspicious-entries          no suspicious entries
ok        working-tree                ~/.local/share/chezmoi is a directory
ok        dest-dir                    ~ is a directory
ok        hardlink                    created hardlink from ~/.local/share/chezmoi to ~/tmp
ok        symlink                     created symlink from .new-name to .old-name
ok        umask                       022
ok        cd-command                  found /bin/bash
ok        cd-args                     /bin/bash
warning   diff-command                nosuchdiff not found in $PATH
ok        edit-command                found ~/bin/myeditor
ok        edit-args                   ~/bin/myeditor
ok        git-command                 found ~/bin/git, version 9.99.1
ok        merge-command               found ~/bin/mymerge
ok        shell-command               found /bin/bash
ok        shell-args                  /bin/bash
ok        age-command                 found ~/bin/myage, version 1.1.1
ok        gpg-command                 found ~/bin/mygpg, version 2.4.4
ok        pinentry-command            found ~/bin/mypinentry, version 1.2.1
info      1password-command           op not found in $PATH
info      bitwarden-command           bw not found in $PATH
info      bitwarden-secrets-command   bws not found in $PATH
info      dashlane-command            dcli not found in $PATH
info      doppler-command             doppler not found in $PATH
info      gopass-command              gopass not found in $PATH
info      keepassxc-command           keepassxc-cli not found in $PATH
info      keepassxc-db                ~/missing.kdbx does not exist
info      keeper-command              keeper not found in $PATH
info      lastpass-command            lpass not found in $PATH
info      pass-command                pass not found in $PATH
info      passhole-command            ph not found in $PATH
info      protonpass-command          pass-cli not found in $PATH
info      rbw-command                 rbw not found in $PATH
info      vault-command               vault not found in $PATH
ok        secret-command              found ~/bin/mysecret
"""

# Every optional binary doctor reports on when nothing is configured: the
# password managers (absent from the system PATH) and the unset commands.
MISSING_BINARY_LINES = [
    ("age-command", "age not found in $PATH"),
    ("1password-command", "op not found in $PATH"),
    ("bitwarden-command", "bw not found in $PATH"),
    ("bitwarden-secrets-command", "bws not found in $PATH"),
    ("dashlane-command", "dcli not found in $PATH"),
    ("doppler-command", "doppler not found in $PATH"),
    ("gopass-command", "gopass not found in $PATH"),
    ("keepassxc-command", "keepassxc-cli not found in $PATH"),
    ("keeper-command", "keeper not found in $PATH"),
    ("lastpass-command", "lpass not found in $PATH"),
    ("pass-command", "pass not found in $PATH"),
    ("passhole-command", "ph not found in $PATH"),
    ("protonpass-command", "pass-cli not found in $PATH"),
    ("rbw-command", "rbw not found in $PATH"),
    ("vault-command", "vault not found in $PATH"),
    ("diff-command", "not set"),
    ("pinentry-command", "not set"),
    ("keepassxc-db", "not set"),
    ("secret-command", "not set"),
]


def run_doctor(env, *args, **kwargs):
    return run_chezmoi(["doctor", "--no-network", *args], env=env, **kwargs)


class TestDoctorTable:
    def test_doctor_full_table(self, home, tmp_path):
        """doctor prints the whole check table, home concealed as ~."""
        write_standard_fakes(home)
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        config.parent.mkdir(parents=True, exist_ok=True)
        config.write_text(STANDARD_CONFIG)
        os.utime(config, (MTIME_EPOCH, MTIME_EPOCH))
        source_dir(home).mkdir(parents=True)
        (home / "tmp").mkdir()
        env = child_env(
            home,
            tmpdir=home / "tmp",
            path=f"{home}/bin:/usr/bin:/bin",
            TZ="UTC",
            EDITOR="myeditor",
        )
        result = run_doctor(env, umask=0o022)
        assert result.returncode == 0
        assert result.stderr == ""

        stable = [
            line
            for line in result.stdout.splitlines()
            if line.split(None, 2)[1] not in VOLATILE_CHECKS
        ]
        expected = STANDARD_TABLE.format(executable=os.path.abspath(EXECUTABLE))
        assert stable == expected.splitlines()

        lines = doctor_lines(result)
        # CATCHES: a dev build reports its full version string as a warning,
        # while the platform, build info and Go version are plain facts.
        assert re.fullmatch(
            r"warning\s+version\s+dev, commit [0-9a-f]{7,40}, built at \S+, built by source",
            lines["version"],
        )
        assert re.match(r"ok\s+os-arch\s+linux/amd64 \(", lines["os-arch"])
        assert re.match(r"info\s+build-info\s+\S", lines["build-info"])
        assert re.match(r"ok\s+go-version\s+go\d+\.\d+(\.\d+)? \(gc\)", lines["go-version"])

    def test_doctor_missing_source_dir_errors(self, home, tmp_path):
        """a missing source directory makes source-dir and working-tree error."""
        env = child_env(home, tmpdir=tmp_path / "tmp", TZ="UTC")
        result = run_doctor(env)
        assert result.returncode == 1
        lines = doctor_lines(result)
        # CATCHES: each missing directory is reported as an error, not a
        # warning, so doctor exits 1 even though no check was configured.
        assert lines["source-dir"] == dline(
            "error", "source-dir", "open ~/.local/share/chezmoi: no such file or directory"
        )
        assert lines["working-tree"] == dline(
            "error", "working-tree", "open ~/.local/share/chezmoi: no such file or directory"
        )
        assert lines["hardlink"] == dline(
            "failed", "hardlink", "stat ~/.local/share/chezmoi: no such file or directory"
        )
        assert lines["config-file"] == dline(
            "info", "config-file", "~/.config/chezmoi/chezmoi.toml: not found"
        )


class TestDoctorWorkingTree:
    @pytest.mark.parametrize("dirty", [False, True], ids=["clean", "dirty"])
    def test_doctor_working_tree_status(self, home, tmp_path, dirty):
        """source-dir and working-tree report the git status of the repo."""
        env = make_git_env(home, tmp_path)
        sd = source_dir(home)
        sd.mkdir(parents=True)
        run_git(env, sd, "init", "--quiet", "-b", "main")
        (sd / "dot_ok").write_text("ok\n")
        run_git(env, sd, "add", ".")
        run_git(env, sd, "commit", "--quiet", "-m", "initial")
        if dirty:
            (sd / "dot_uncommitted").write_text("dirty\n")

        result = run_doctor(env)
        lines = doctor_lines(result)
        status = "dirty" if dirty else "clean"
        result_word = "warning" if dirty else "ok"
        # CATCHES: a dirty working tree is only a warning, so doctor still
        # exits 0; both source-dir and working-tree show the same status.
        assert lines["source-dir"] == dline(
            result_word,
            "source-dir",
            f"~/.local/share/chezmoi is a git working tree ({status})",
        )
        assert lines["working-tree"] == dline(
            result_word,
            "working-tree",
            f"~/.local/share/chezmoi is a git working tree ({status})",
        )
        assert result.returncode == 0

    def test_doctor_suspicious_entries(self, home, tmp_path):
        """unknown .chezmoi-prefixed entries are reported as suspicious."""
        sd = source_dir(home)
        sd.mkdir(parents=True)
        (sd / "dot_normal").write_text("normal\n")
        (sd / ".chezmoiunknown").write_text("suspicious\n")
        (sd / ".chezmoisomedir").mkdir()
        (sd / ".chezmoisomedir" / "inner").write_text("x\n")
        env = child_env(home, tmpdir=tmp_path / "tmp", TZ="UTC")
        result = run_doctor(env)
        lines = doctor_lines(result)
        # CATCHES: suspicious entries are joined with "and" and both the file
        # and the directory are listed, but this stays a warning (exit 0).
        assert lines["suspicious-entries"] == dline(
            "warning",
            "suspicious-entries",
            "~/.local/share/chezmoi/.chezmoisomedir and ~/.local/share/chezmoi/.chezmoiunknown",
        )
        assert result.returncode == 0


class TestDoctorConfigFile:
    def test_doctor_config_file_found(self, home, tmp_path):
        """the config file check reports the path with ~ and the mtime."""
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        config.parent.mkdir(parents=True)
        config.write_text("# doctor test config\n")
        os.utime(config, (MTIME_EPOCH, MTIME_EPOCH))
        source_dir(home).mkdir(parents=True)
        env = child_env(home, tmpdir=tmp_path / "tmp", TZ="UTC")
        result = run_doctor(env)
        # CATCHES: the modification time is printed in RFC 3339 in the local
        # timezone (pinned to UTC here), with the home directory as ~.
        assert doctor_lines(result)["config-file"] == dline(
            "ok",
            "config-file",
            "found ~/.config/chezmoi/chezmoi.toml, last modified 2026-01-02T03:04:05Z",
        )

        custom = home / "custom.toml"
        custom.write_text("# doctor test config\n")
        os.utime(custom, (MTIME_EPOCH, MTIME_EPOCH))
        # CATCHES: -c relocates the config file and the check follows it.
        result = run_doctor(env, "--config", str(custom))
        assert doctor_lines(result)["config-file"] == dline(
            "ok", "config-file", "found ~/custom.toml, last modified 2026-01-02T03:04:05Z"
        )

    @pytest.mark.parametrize("kind", ["is-dir", "bad-toml"])
    def test_doctor_config_file_invalid(self, home, tmp_path, kind):
        """an unusable config file is an error that makes doctor exit 1."""
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        config.parent.mkdir(parents=True)
        if kind == "is-dir":
            config.mkdir()
            expected = dline(
                "error", "config-file", "found ~/.config/chezmoi/chezmoi.toml, which is a dir"
            )
        else:
            config.write_text("this is not = valid toml [[[\n")
            expected = dline(
                "error",
                "config-file",
                "~/.config/chezmoi/chezmoi.toml: ~/.config/chezmoi/chezmoi.toml: "
                "toml: line 1: expected '.' or '=', but got 'i' instead",
            )
        source_dir(home).mkdir(parents=True)
        env = child_env(home, tmpdir=tmp_path / "tmp", TZ="UTC")
        result = run_doctor(env)
        # CATCHES: doctor still runs with a broken config (the table is
        # printed) but the config-file check is an error, so it exits 1.
        assert doctor_lines(result)["config-file"] == expected
        assert result.returncode == 1


class TestDoctorBinaries:
    def test_doctor_missing_binary_checks(self, home, tmp_path):
        """unconfigured optional binaries are info lines, never errors."""
        source_dir(home).mkdir(parents=True)
        env = child_env(home, tmpdir=tmp_path / "tmp", TZ="UTC")
        result = run_doctor(env)
        assert result.returncode == 0
        lines = doctor_lines(result)
        for check, message in MISSING_BINARY_LINES:
            # CATCHES: every optional binary that is absent is reported as
            # "not found in $PATH" (or "not set" when there is no default)
            # with result "info", unlike required commands which error.
            assert lines[check] == dline("info", check, message), check

    @pytest.mark.parametrize(
        "section,check,fake,version,need",
        [
            ("onepassword", "1password-command", "myop", "1.9.0", "2.0.0"),
            ("rbw", "rbw-command", "myrbw", "1.0.0", "1.7.0"),
            ("keepassxc", "keepassxc-command", "mykeepassxc", "1.0.0", "2.7.0"),
        ],
    )
    def test_doctor_min_version_errors(self, home, tmp_path, section, check, fake, version, need):
        """a password manager older than the minimum version is an error."""
        outputs = {
            "myop": "1.9.0\\n",
            "myrbw": "rbw 1.0.0\\n",
            "mykeepassxc": "1.0.0\\n",
        }
        write_fakes(home, {fake: outputs[fake]})
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        config.parent.mkdir(parents=True)
        config.write_text(f'[{section}]\n    command = "{fake}"\n')
        source_dir(home).mkdir(parents=True)
        env = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{home}/bin:/usr/bin:/bin",
            TZ="UTC",
        )
        result = run_doctor(env)
        # CATCHES: the version is parsed from the command's --version output
        # and compared against the minimum; being too old is an error that
        # makes doctor exit 1.
        assert doctor_lines(result)[check] == dline(
            "error", check, f"found ~/bin/{fake}, version {version}, need {need}"
        )
        assert result.returncode == 1

    def test_doctor_unparseable_version_warning(self, home, tmp_path):
        """a binary whose version cannot be parsed is a warning."""
        write_fakes(home, {"mygpg": "gpg (GnuPG) no version here"})
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        config.parent.mkdir(parents=True)
        config.write_text('encryption = "gpg"\n\n[gpg]\n    command = "mygpg"\n')
        source_dir(home).mkdir(parents=True)
        env = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{home}/bin:/usr/bin:/bin",
            TZ="UTC",
        )
        result = run_doctor(env)
        # CATCHES: when the version regexp does not match the output, doctor
        # reports the trimmed output verbatim as a warning, not an error.
        assert doctor_lines(result)["gpg-command"] == dline(
            "warning",
            "gpg-command",
            "found ~/bin/mygpg, cannot parse version from gpg (GnuPG) no version here",
        )
        assert result.returncode == 0


class TestDoctorUpgradeMethod:
    @pytest.mark.parametrize(
        "location,method",
        [
            ("bin/chezmoi", "replace-executable"),
            (".linuxbrew/bin/chezmoi", "brew-upgrade"),
        ],
    )
    def test_doctor_upgrade_method_of_copy(self, home, tmp_path, location, method):
        """the upgrade method is deduced from the executable's location."""
        exe = link_executable(home / location)
        source_dir(home).mkdir(parents=True)
        env = child_env(home, tmpdir=tmp_path / "tmp", TZ="UTC")
        result = run_chezmoi(["doctor", "--no-network"], env=env, exe=str(exe))
        lines = doctor_lines(result)
        # CATCHES: an executable under the user's home directory upgrades by
        # replacing itself, while a linuxbrew path selects brew-upgrade and
        # wins over the home-directory rule that is checked after it.
        assert lines["upgrade-method"] == dline("ok", "upgrade-method", method)
        assert lines["executable"] == dline("ok", "executable", f"~/{location}")

    def test_doctor_upgrade_method_in_tmpdir(self, home, tmp_path):
        """an executable inside $TMPDIR also uses replace-executable."""
        tmpdir = tmp_path / "tmp"
        exe = link_executable(tmpdir / "sub" / "chezmoi")
        source_dir(home).mkdir(parents=True)
        env = child_env(home, tmpdir=tmpdir, TZ="UTC")
        result = run_chezmoi(["doctor", "--no-network"], env=env, exe=str(exe))
        # CATCHES: the temp-directory test uses the $TMPDIR seen by the child
        # process and wins over the executable-owner test that follows it.
        assert doctor_lines(result)["upgrade-method"] == dline(
            "ok", "upgrade-method", "replace-executable"
        )
        assert doctor_lines(result)["executable"] == dline("ok", "executable", str(exe))

    def test_doctor_upgrade_method_of_stock_executable(self, home, tmp_path):
        """a root-owned system executable upgrades via the package manager."""
        source_dir(home).mkdir(parents=True)
        env = child_env(home, tmpdir=tmp_path / "tmp", TZ="UTC")
        result = run_doctor(env)
        lines = doctor_lines(result)
        # CATCHES: the binary under test is owned by uid 0 (the suite runs as
        # root) and lives outside $HOME and $TMPDIR, so the upgrade method is
        # upgrade-package rather than replace-executable.
        assert lines["upgrade-method"] == dline("ok", "upgrade-method", "upgrade-package")
        assert lines["executable"] == dline("ok", "executable", os.path.abspath(EXECUTABLE))


class TestDoctorEnvironment:
    def test_doctor_umask(self, home, tmp_path):
        """the umask check reports the process umask and warns on odd ones."""
        source_dir(home).mkdir(parents=True)
        for mask, result_word, text in [
            (0o022, "ok", "022"),
            (0o077, "warning", "077"),
        ]:
            env = child_env(home, tmpdir=tmp_path / "tmp", TZ="UTC")
            result = run_doctor(env, umask=mask)
            # CATCHES: only 002 and 022 are considered healthy; anything else
            # (like 077) is a warning, and the value is printed in octal.
            assert doctor_lines(result)["umask"] == dline(result_word, "umask", text)

    def test_doctor_shell_editor_and_destination(self, home, tmp_path):
        """cd/shell come from $SHELL, edit from $EDITOR and dest-dir from -D."""
        write_fakes(home, {"myeditor": ""})
        write_script(home / "myshell", "#!/bin/sh\nexit 0\n")
        (home / "dest").mkdir()
        source_dir(home).mkdir(parents=True)
        env = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{home}/bin:/usr/bin:/bin",
            shell=f"{home}/myshell -l",
            TZ="UTC",
            EDITOR="myeditor",
        )
        result = run_doctor(env, "--destination", str(home / "dest"))
        lines = doctor_lines(result)
        # CATCHES: $SHELL is split into command and arguments for both the
        # cd-command and shell-command checks, $EDITOR is resolved through
        # $PATH, and --destination is reflected in the dest-dir check.
        assert lines["cd-command"] == dline("ok", "cd-command", "found ~/myshell")
        assert lines["cd-args"] == dline("ok", "cd-args", "~/myshell -l")
        assert lines["shell-command"] == dline("ok", "shell-command", "found ~/myshell")
        assert lines["shell-args"] == dline("ok", "shell-args", "~/myshell -l")
        assert lines["edit-command"] == dline("ok", "edit-command", "found ~/bin/myeditor")
        assert lines["edit-args"] == dline("ok", "edit-args", "~/bin/myeditor")
        assert lines["dest-dir"] == dline("ok", "dest-dir", "~/dest is a directory")

    @pytest.mark.parametrize(
        "section,binary",
        [
            ("gpg", "gpg"),
            ("age", "age"),
        ],
    )
    def test_doctor_encryption_warning(self, home, tmp_path, section, binary):
        """configuring encryption without `encryption` warns on stderr."""
        write_fakes(home, {"mygpg": "gpg (GnuPG) 2.4.4\\n", "myage": "age 1.1.1\\n"})
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        config.parent.mkdir(parents=True)
        config.write_text(f'[{section}]\n    command = "my{binary}"\n')
        source_dir(home).mkdir(parents=True)
        env = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            path=f"{home}/bin:/usr/bin:/bin",
            TZ="UTC",
        )
        result = run_doctor(env)
        # CATCHES: the backwards-compatibility warning goes to stderr while
        # the whole check table still goes to stdout.
        assert result.stderr == (
            f"chezmoi: warning: 'encryption' not set, using {binary} configuration. "
            "Check if 'encryption' is correctly set as the top-level key.\n"
        )
        assert result.stdout.startswith("RESULT    CHECK                       MESSAGE")


class TestDoctorArguments:
    def test_doctor_rejects_arguments(self, home, tmp_path):
        """doctor takes no positional arguments."""
        env = child_env(home, tmpdir=tmp_path / "tmp")
        result = run_chezmoi(["doctor", "extra"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == 'chezmoi: unknown command "extra" for "chezmoi doctor"\n'
