"""Environment variables exported to scripts run by chezmoi."""

from __future__ import annotations

import json
import os
import platform
import pwd
import grp
from pathlib import Path

import pytest

from conftest import EXECUTABLE, run_chezmoi, write_config

ARCH_BY_MACHINE = {
    "x86_64": "amd64",
    "aarch64": "arm64",
    "i386": "386",
    "i686": "386",
    "armv7l": "arm",
    "ppc64le": "ppc64le",
    "riscv64": "riscv64",
    "s390x": "s390x",
}

ENV_DUMP_SCRIPT = '#!/bin/sh\nenv | LC_ALL=C sort > "$HOME/env.txt"\n'

VARS_SCRIPT = (
    "#!/bin/sh\n"
    'echo "PATH=$PATH" > "$HOME/vars.txt"\n'
    'echo "GREETING=$GREETING" >> "$HOME/vars.txt"\n'
    'echo "FAREWELL=$FAREWELL" >> "$HOME/vars.txt"\n'
)


def make_script(src: Path, name: str, contents: str) -> None:
    scripts = src / ".chezmoiscripts"
    scripts.mkdir(parents=True, exist_ok=True)
    script = scripts / name
    script.write_text(contents)
    script.chmod(0o755)


def dump_script_env(home: Path, env: dict, src: Path, *args, cwd=None, name="run_once_dumpenv.sh") -> dict:
    """Run apply with an env-dumping script and return the script's environment.

    ``name`` selects the script name and is embedded as a trailing comment so
    each invocation's script has distinct contents: run_once scripts are
    recorded in the persistent state under the SHA-256 of their contents, so
    two run_once scripts with identical contents run only once between them.
    """
    make_script(src, name, ENV_DUMP_SCRIPT + "# " + name + "\n")
    result = run_chezmoi(["apply", "--source", str(src), *args], env=env, cwd=cwd)
    assert result.returncode == 0
    assert result.stderr == ""
    lines = (home / "env.txt").read_text().splitlines()
    return dict(line.split("=", 1) for line in lines if "=" in line)


def read_os_release_raw() -> dict:
    result = {}
    for line in Path("/etc/os-release").read_text().splitlines():
        token = line.strip()
        if not token or token.startswith("#"):
            continue
        key, _, value = token.partition("=")
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        result[key] = value
    return result


class TestScriptEnvironment:
    def test_core_chezmoi_variables(self, home, env, src, tmp_path):
        """Scripts run by apply see the documented CHEZMOI_* variables."""
        script_env = dump_script_env(home, env, src, cwd=tmp_path)
        assert script_env["CHEZMOI"] == "1"
        assert script_env["CHEZMOI_OS"] == "linux"
        assert script_env["CHEZMOI_ARCH"] == ARCH_BY_MACHINE.get(
            platform.machine(), platform.machine()
        )
        assert script_env["CHEZMOI_SOURCE_DIR"] == str(src)
        assert script_env["CHEZMOI_SOURCE_FILE"] == ".chezmoiscripts/run_once_dumpenv.sh"
        assert script_env["CHEZMOI_DEST_DIR"] == str(home)
        assert script_env["CHEZMOI_CONFIG_FILE"] == str(
            home / ".config" / "chezmoi" / "chezmoi.toml"
        )
        assert script_env["CHEZMOI_HOME_DIR"] == str(home)
        assert script_env["CHEZMOI_RAW_HOME_DIR"] == str(home)
        assert script_env["CHEZMOI_CACHE_DIR"] == str(home / ".cache" / "chezmoi")
        assert script_env["CHEZMOI_COMMAND"] == "apply"
        assert script_env["CHEZMOI_COMMAND_DIR"] == str(tmp_path)
        assert script_env["CHEZMOI_WORKING_TREE"] == str(src)
        assert script_env["CHEZMOI_EXECUTABLE"] == EXECUTABLE
        assert script_env["CHEZMOI_ARGS"] == "%s apply --source %s" % (EXECUTABLE, src)
        assert script_env["HOME"] == str(home)
        assert script_env["PATH"] == "/usr/bin:/bin"
        # CATCHES: every documented variable is exported with the value derived
        # from the actual invocation (args space-joined, cwd as command dir),
        # and the parent PATH is passed through unchanged.

    def test_version_kernel_os_release_variables(self, home, env, src):
        """Version, kernel and os-release groups are exported as flat variables."""
        script_env = dump_script_env(home, env, src)
        assert script_env["CHEZMOI_VERSION_COMMIT"] == "40dcf243fbdda2b8dc912aa02f7ddb2219b96f6b"
        assert script_env["CHEZMOI_VERSION_BUILT_BY"] == "source"
        assert script_env["CHEZMOI_VERSION_DATE"] == "1792161864"
        assert script_env["CHEZMOI_VERSION_VERSION"] == ""
        kernel_base = Path("/proc/sys/kernel")
        assert script_env["CHEZMOI_KERNEL_OSTYPE"] == (kernel_base / "ostype").read_text().strip()
        assert script_env["CHEZMOI_KERNEL_OSRELEASE"] == (kernel_base / "osrelease").read_text().strip()
        assert script_env["CHEZMOI_KERNEL_VERSION"] == (kernel_base / "version").read_text().strip()
        expected_os_release = {
            "CHEZMOI_OS_RELEASE_" + key: value
            for key, value in read_os_release_raw().items()
        }
        actual = {
            key: value for key, value in script_env.items()
            if key.startswith("CHEZMOI_OS_RELEASE_")
        }
        assert actual == expected_os_release
        # CATCHES: every /etc/os-release key becomes CHEZMOI_OS_RELEASE_<KEY>
        # with the raw UPPER_SNAKE_CASE name and unquoted value, and the
        # windows version group exports nothing on Linux.

    def test_identity_variables(self, home, env, src):
        """User and hostname identity is exported as strings."""
        script_env = dump_script_env(home, env, src)
        assert script_env["CHEZMOI_USERNAME"] == pwd.getpwuid(os.getuid()).pw_name
        assert script_env["CHEZMOI_UID"] == str(os.getuid())
        assert script_env["CHEZMOI_GID"] == str(os.getgid())
        assert script_env["CHEZMOI_GROUP"] == grp.getgrgid(os.getgid()).gr_name
        hostname = script_env["CHEZMOI_HOSTNAME"]
        assert hostname == script_env["CHEZMOI_FQDN_HOSTNAME"].split(".")[0]
        assert "CHEZMOI_WINDOWS_VERSION" not in script_env
        # CATCHES: uid/gid are exported as decimal strings and the windows
        # version variable is absent entirely on Linux rather than empty.

    def test_verbose_flag_sets_chezmoi_verbose(self, home, env, src):
        """CHEZMOI_VERBOSE is only exported when --verbose is given."""
        script_env = dump_script_env(home, env, src, name="run_once_dumpenv_plain.sh")
        assert "CHEZMOI_VERBOSE" not in script_env
        script_env = dump_script_env(
            home, env, src, "--verbose", name="run_once_dumpenv_verbose.sh"
        )
        assert script_env["CHEZMOI_VERBOSE"] == "1"
        # CATCHES: the variable is not merely empty when verbose is off; it is
        # unset, and --verbose sets it to exactly "1". Each apply must actually
        # run its script, so the two runs use distinct run_once names.


class TestConfiguredEnvironment:
    def test_scriptenv_reaches_script_and_replaces_path(self, home, env, src):
        """[scriptEnv] values are exported to scripts, including PATH."""
        write_config(home, '[scriptEnv]\n    GREETING = "hi"\n    PATH = "/custom"\n')
        make_script(src, "run_once_vars.sh", VARS_SCRIPT)
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert (home / "vars.txt").read_text() == "PATH=/custom\nGREETING=hi\nFAREWELL=\n"
        # CATCHES: scriptEnv entries fully replace the inherited environment
        # variables (PATH included) and unset names expand to empty strings.

    def test_env_reaches_script(self, home, env, src):
        """[env] values are exported to scripts."""
        write_config(home, '[env]\n    FAREWELL = "bye"\n')
        make_script(src, "run_once_vars.sh", VARS_SCRIPT)
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert (home / "vars.txt").read_text() == (
            "PATH=/usr/bin:/bin\nGREETING=\nFAREWELL=bye\n"
        )
        # CATCHES: [env] and [scriptEnv] are separate sections feeding the
        # same export mechanism for scripts.

    def test_env_and_scriptenv_are_mutually_exclusive(self, home, env, src):
        """Setting both [env] and [scriptEnv] is a configuration error."""
        write_config(
            home,
            '[env]\n    FAREWELL = "bye"\n\n[scriptEnv]\n    GREETING = "hi"\n',
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: only one of env or scriptEnv may be set\n"
        # CATCHES: the exclusivity check runs before any script executes and
        # produces a single-line error.

    def test_reserved_env_name_warns(self, home, env, src):
        """A [env] name starting with CHEZMOI_ triggers a warning but succeeds."""
        write_config(home, '[env]\n    CHEZMOI_FOO = "x"\n')
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: warning: CHEZMOI_FOO: overriding reserved environment variable\n"
        )
        # CATCHES: reserved names warn on stderr (with a trailing newline) and
        # still exit successfully.


class TestEnvInput:
    @pytest.mark.parametrize(
        ("var", "key"),
        [
            pytest.param("CHEZMOI_SOURCE_DIR", "sourceDir", id="source-dir"),
            pytest.param("CHEZMOI_DEST_DIR", "destDir", id="dest-dir"),
            pytest.param("CHEZMOI_CONFIG_FILE", "configFile", id="config-file"),
        ],
    )
    def test_chezmoi_env_vars_are_not_config_input(self, home, tmp_path, var, key):
        """CHEZMOI_* variables are outputs only and never read as settings."""
        env = {
            "HOME": str(home),
            "PATH": "/usr/bin:/bin",
            "SHELL": "/bin/sh",
            "TMPDIR": str(tmp_path / "tmp"),
            "LC_ALL": "C",
            var: "/bogus/value",
        }
        (tmp_path / "tmp").mkdir(exist_ok=True)
        result = run_chezmoi(["data"], env=env)
        assert result.returncode == 0
        chezmoi = json.loads(result.stdout)["chezmoi"]
        assert chezmoi[key] != "/bogus/value"
        # CATCHES: exporting CHEZMOI_SOURCE_DIR/DEST_DIR/CONFIG_FILE in the
        # parent environment must not influence the corresponding settings.
