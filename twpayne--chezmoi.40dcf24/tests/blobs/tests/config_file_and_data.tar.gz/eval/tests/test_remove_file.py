"""`.chezmoiremove` handling.

These pin the removeName special file (internal/chezmoi/chezmoi.go): its
patterns are globs rooted at the destination directory, which is what
chezmoi.ensureSuffix guarantees by appending the trailing path separator to
the destination directory before matching.
"""

from __future__ import annotations

from conftest import run_chezmoi


class TestRemoveFile:
    def test_globs_are_relative_to_the_destination_dir(self, home, env, src):
        """Patterns name destination paths, with comments and blanks ignored."""
        (src / ".chezmoiremove").write_text("sub/junk*\n# comment\n\nexact.txt\n")
        (src / "dot_kept").write_text("content\n")
        (home / "sub").mkdir()
        (home / "sub" / "junk1").write_text("x\n")
        (home / "sub" / "keep").write_text("x\n")
        (home / "exact.txt").write_text("x\n")
        (home / "other").write_text("x\n")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert sorted(p.name for p in home.iterdir() if p.name != "sub") == [
            ".config",
            ".kept",
            "other",
        ]
        assert sorted(p.name for p in (home / "sub").iterdir()) == ["keep"]
        assert (home / ".kept").read_text() == "content\n"
        # CATCHES: the patterns are matched against paths relative to the
        # destination directory (not the source directory, not the pattern
        # file's own directory) and comment and blank lines are skipped.

    def test_directories_are_removed_recursively(self, home, env, src):
        """A pattern matching a directory removes it with all its contents."""
        (src / ".chezmoiremove").write_text("obsolete*\n")
        (home / "obsolete1").write_text("x\n")
        (home / "obsoletedir").mkdir()
        (home / "obsoletedir" / "nested").mkdir()
        (home / "obsoletedir" / "nested" / "f").write_text("x\n")
        (home / "kept").write_text("x\n")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert not (home / "obsolete1").exists()
        assert not (home / "obsoletedir").exists()
        assert (home / "kept").read_text() == "x\n"
        # CATCHES: a glob that matches a directory removes the whole subtree,
        # and entries that do not match any pattern are left untouched.
