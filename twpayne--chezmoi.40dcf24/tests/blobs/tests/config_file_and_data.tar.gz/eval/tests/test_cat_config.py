"""`chezmoi cat-config`: raw output of the config file."""

from __future__ import annotations

import pytest

from conftest import run_chezmoi, write_config


class TestCatConfig:
    @pytest.mark.parametrize(
        "contents",
        [
            pytest.param('# leading comment\nsourceDir = "/x" # trailing', id="no-final-newline"),
            pytest.param('sourceDir = "/x"\n\n[edit]\n    command = "vi"\n', id="blank-lines"),
        ],
    )
    def test_prints_file_bytes_verbatim(self, home, env, contents):
        """cat-config writes the config file's bytes without reformatting."""
        write_config(home, contents)
        result = run_chezmoi(["cat-config"], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == contents
        # CATCHES: output must be the raw file, not a re-serialization, so
        # comments, blank lines and a missing final newline survive.

    def test_config_flag_selects_file(self, home, env, tmp_path):
        """--config chooses which file cat-config prints."""
        write_config(home, 'sourceDir = "/main"\n')
        other = tmp_path / "other.toml"
        other.write_text("other = 1\n")
        result = run_chezmoi(["cat-config", "--config", str(other)], env=env)
        assert result.returncode == 0
        assert result.stdout == "other = 1\n"
        # CATCHES: cat-config must honor --config instead of always using the
        # discovered config file.

    def test_missing_file_error_creates_config_dir(self, home, env):
        """A missing config file is an open error, but the config dir is created."""
        result = run_chezmoi(["cat-config"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        expected_path = home / ".config" / "chezmoi" / "chezmoi.toml"
        assert result.stderr == "chezmoi: open %s: no such file or directory\n" % expected_path
        assert (home / ".config" / "chezmoi").is_dir()
        # CATCHES: the error is the raw os.Open error naming the default file,
        # and the config directory is still created first.

    def test_rejects_extra_arguments(self, home, env):
        """cat-config takes no positional arguments."""
        write_config(home, 'sourceDir = "/x"\n')
        result = run_chezmoi(["cat-config", "extra-arg"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == 'chezmoi: unknown command "extra-arg" for "chezmoi cat-config"\n'
        # CATCHES: excess args are routed to the unknown-subcommand error with
        # the full command path in the message.
