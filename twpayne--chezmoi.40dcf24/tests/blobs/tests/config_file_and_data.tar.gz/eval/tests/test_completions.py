"""Shell completion output for the configuration and data commands.

These exercise chezmoi.FlagCompletionFunc in internal/chezmoi/chezmoi.go and
the allowed-value tables of choiceFlag and autoBool (internal/cmd/choiceflag.go
and internal/cmd/autobool.go) through cobra's hidden ``__complete`` command,
which is what ``chezmoi completion`` generates shell code for.
"""

from __future__ import annotations

import json

import pytest

from conftest import run_chezmoi

# cobra's "no file completions" directive, printed after the completions.
DIRECTIVE = ":4"
DIRECTIVE_NOTICE = "Completion ended with directive: ShellCompDirectiveNoFileComp\n"

# The completion list of every autoBool flag (color, progress, use-builtin-age,
# use-builtin-git), in registration order.
AUTO_BOOL_VALUES = [
    "1", "t", "T", "true", "TRUE", "True",
    "0", "f", "F", "false", "FALSE", "False",
    "auto", "AUTO", "Auto",
]


def completions_of(env, *args):
    """Return the completion lines printed by `chezmoi __complete <args>`."""
    result = run_chezmoi(["__complete", *args], env=env)
    assert result.returncode == 0
    assert result.stderr == DIRECTIVE_NOTICE
    lines = result.stdout.split("\n")
    assert lines[-1] == ""
    assert lines[-2] == DIRECTIVE
    return lines[:-2]


class TestFormatFlagCompletions:
    @pytest.mark.parametrize(
        ("args", "expected"),
        [
            pytest.param(
                ["dump-config", "--format", ""],
                ["", "json", "yaml"],
                id="dump-config-no-prefix",
            ),
            pytest.param(["data", "--format", ""], ["", "json", "yaml"], id="data-no-prefix"),
            pytest.param(
                ["--config-format", ""],
                ["", "json", "toml", "yaml"],
                id="config-format-no-prefix",
            ),
            pytest.param(["--config-format", "j"], ["json"], id="config-format-j"),
            pytest.param(["--config-format", "to"], ["toml"], id="config-format-to"),
            pytest.param(["--config-format", "ya"], ["yaml"], id="config-format-ya"),
            pytest.param(["--config-format", "zz"], [], id="config-format-no-match"),
            pytest.param(["dump-config", "--format", "ya"], ["yaml"], id="dump-config-ya"),
            pytest.param(["data", "--format", "j"], ["json"], id="data-j"),
            pytest.param(["dump-config", "--format", "t"], [], id="dump-config-t"),
        ],
    )
    def test_format_completions(self, home, env, args, expected):
        """Format flags complete their allowed values, filtered by prefix."""
        assert completions_of(env, *args) == expected
        # CATCHES: the completion list is the sorted set of allowed values
        # (including the empty string that means "infer from the extension")
        # filtered by the prefix being completed, so "t" completes nothing for
        # a json/yaml-only flag while "ya" completes yaml.

    def test_empty_completion_is_a_real_value(self, home, env, src):
        """The empty completion line corresponds to an accepted flag value."""
        assert "" in completions_of(env, "--config-format", "")
        result = run_chezmoi(
            ["dump-config", "--config-format", "", "--source", str(src)], env=env
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert json.loads(result.stdout)["format"] == "json"
        # CATCHES: the empty string is not just cosmetic in the completion
        # list, it is an accepted --config-format value that leaves the output
        # format to be inferred (here: the JSON default, not an error).


class TestAutoBoolCompletions:
    def test_color_completes_all_values_in_order(self, home, env):
        """--color with no prefix completes every autoBool value in order."""
        assert completions_of(env, "--color", "") == AUTO_BOOL_VALUES
        # CATCHES: the autoBool completion list is a fixed, ordered set mixing
        # strconv.ParseBool spellings with the three casings of "auto".

    @pytest.mark.parametrize(
        ("prefix", "expected"),
        [
            pytest.param("A", ["AUTO", "Auto"], id="upper-a"),
            pytest.param("a", ["auto"], id="lower-a"),
            pytest.param("T", ["T", "TRUE", "True"], id="upper-t"),
            pytest.param("t", ["t", "true"], id="lower-t"),
            pytest.param("tru", ["true"], id="tru"),
            pytest.param("F", ["F", "FALSE", "False"], id="upper-f"),
            pytest.param("FALSE", ["FALSE"], id="false"),
            pytest.param("0", ["0"], id="zero"),
            pytest.param("z", [], id="no-match"),
        ],
    )
    def test_color_prefix_matching_is_case_sensitive(self, home, env, prefix, expected):
        """--color completions match the prefix byte-for-byte."""
        assert completions_of(env, "--color", prefix) == expected
        # CATCHES: prefix matching is a plain strings.HasPrefix, so "A" only
        # completes the upper-case spellings while "a" only completes "auto".


class TestCommandCompletions:
    def test_module_commands_are_listed_with_descriptions(self, home, env):
        """Completing the empty command name lists every command."""
        completions = completions_of(env, "")
        for line in [
            "cat-config\tPrint the configuration file",
            "data\tPrint the template data",
            "dump-config\tDump the configuration values",
            "edit-config\tEdit the configuration file",
            "edit-config-template\tEdit the configuration file template",
            "execute-template\tExecute the given template(s)",
            "init\tSetup the source directory and update the destination "
            "directory to match the target state",
        ]:
            assert line in completions
        # CATCHES: each completion line is the command name, a tab, and its
        # short description exactly as printed by `chezmoi --help`.

    def test_command_names_filtered_by_prefix(self, home, env):
        """Completing "d" lists only the commands starting with "d"."""
        assert completions_of(env, "d") == [
            "data\tPrint the template data",
            "decrypt\tDecrypt file or standard input",
            "destroy\tPermanently delete an entry from the source state, the "
            "destination directory, and the state",
            "diff\tPrint the diff between the target state and the "
            "destination state",
            "docker\tUse your dotfiles in a Docker container",
            "doctor\tCheck your system for potential problems",
            "dump\tGenerate a dump of the target state",
            "dump-config\tDump the configuration values",
        ]
        # CATCHES: command-name completion filters the command tree by prefix
        # and keeps the declaration order rather than sorting it.

    def test_command_abbreviation_is_not_completed(self, home, env):
        """Completing "dump-conf" offers only the full command name."""
        assert completions_of(env, "dump-conf") == [
            "dump-config\tDump the configuration values"
        ]
        # CATCHES: unlike flag values, command names have no unique
        # abbreviations, so a partial name completes the full name only.

    def test_no_args_command_completes_nothing(self, home, env):
        """A command that takes no arguments completes no positional args."""
        assert completions_of(env, "cat-config", "") == []
        assert completions_of(env, "dump-config", "") == []
        # CATCHES: cat-config and dump-config accept no arguments, so the
        # completion of a positional argument is empty rather than the
        # filenames in the current directory.
