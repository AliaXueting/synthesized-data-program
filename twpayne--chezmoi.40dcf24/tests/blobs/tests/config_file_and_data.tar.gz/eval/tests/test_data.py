"""`chezmoi data`: template data, data file merging, and overrides."""

from __future__ import annotations

import grp
import json
import os
import pwd
import socket
from pathlib import Path

import pytest
import yaml

from conftest import EXECUTABLE, run_chezmoi, write_config

WELL_KNOWN_ABBREVIATIONS = {"ANSI", "CPE", "ID", "URL"}


def upper_to_camel(key: str) -> str:
    words = key.split("_")
    result = words[0].lower()
    for word in words[1:]:
        if word in WELL_KNOWN_ABBREVIATIONS:
            result += word
        else:
            result += word.capitalize()
    return result


def expected_os_release() -> dict:
    result = {}
    for line in Path("/etc/os-release").read_text().splitlines():
        token = line.strip()
        if not token or token.startswith("#"):
            continue
        key, _, value = token.partition("=")
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        result[key] = value
    return {upper_to_camel(k): v for k, v in result.items()}


def expected_kernel() -> dict:
    result = {}
    for name in ("osrelease", "ostype", "version"):
        path = Path("/proc/sys/kernel") / name
        if path.exists():
            result[name] = path.read_text().strip()
    return result


def expected_fqdn_hostname() -> str:
    hostname = socket.gethostname()
    if "." in hostname:
        return hostname
    try:
        from_file = Path("/etc/hostname").read_text().strip()
        if from_file:
            return from_file
    except OSError:
        pass
    return hostname


def run_data(env, *args, cwd=None):
    result = run_chezmoi(["data", *args], env=env, cwd=cwd)
    assert result.returncode == 0
    return json.loads(result.stdout)


class TestBuiltinData:
    def test_chezmoi_key_set(self, home, env, src):
        """The builtin chezmoi map contains exactly the documented keys."""
        data = run_data(env, "--source", str(src))
        assert sorted(data) == ["chezmoi"]
        assert sorted(data["chezmoi"]) == [
            "arch",
            "args",
            "cacheDir",
            "command",
            "commandDir",
            "config",
            "configFile",
            "destDir",
            "executable",
            "flags",
            "fqdnHostname",
            "gid",
            "group",
            "homeDir",
            "hostname",
            "kernel",
            "os",
            "osRelease",
            "pathListSeparator",
            "pathSeparator",
            "rawHomeDir",
            "sourceDir",
            "uid",
            "username",
            "version",
            "windowsVersion",
            "workingTree",
        ]
        # CATCHES: the template data surface is fixed; extra keys (e.g. a
        # persistentState entry) or missing ones change template behavior.

    def test_builtin_paths_and_command(self, home, env, src, tmp_path):
        """Path and command builtin values reflect flags and environment."""
        data = run_data(env, "--source", str(src), cwd=tmp_path)
        chezmoi = data["chezmoi"]
        assert chezmoi["sourceDir"] == str(src)
        assert chezmoi["destDir"] == str(home)
        assert chezmoi["cacheDir"] == str(home / ".cache" / "chezmoi")
        assert chezmoi["workingTree"] == str(src)
        assert chezmoi["configFile"] == str(home / ".config" / "chezmoi" / "chezmoi.toml")
        assert chezmoi["homeDir"] == str(home)
        assert chezmoi["rawHomeDir"] == str(home)
        assert chezmoi["commandDir"] == str(tmp_path)
        assert chezmoi["command"] == "data"
        assert chezmoi["executable"] == EXECUTABLE
        assert chezmoi["args"] == [EXECUTABLE, "data", "--source", str(src)]
        assert chezmoi["os"] == "linux"
        assert chezmoi["pathSeparator"] == "/"
        assert chezmoi["pathListSeparator"] == ":"
        assert chezmoi["arch"] in ("386", "amd64", "arm", "arm64", "arm64be", "loong64", "ppc64le", "riscv64", "s390x")
        # CATCHES: HOME drives homeDir/rawHomeDir, the cwd drives commandDir,
        # and args mirrors the exact argv including the executable path.

    def test_os_release_keys_are_camel_cased(self, home, env, src):
        """os-release keys are converted from UPPER_SNAKE_CASE to camelCase."""
        data = run_data(env, "--source", str(src))
        assert data["chezmoi"]["osRelease"] == expected_os_release()
        # CATCHES: the conversion lowercases the first word, title-cases the
        # rest, but keeps well-known abbreviations (ID, URL) upper, so
        # BUG_REPORT_URL becomes bugReportURL and ID_LIKE becomes idLike.

    def test_kernel_and_windows_version(self, home, env, src):
        """kernel data comes from /proc/sys/kernel; windowsVersion is empty."""
        data = run_data(env, "--source", str(src))
        assert data["chezmoi"]["kernel"] == expected_kernel()
        assert data["chezmoi"]["windowsVersion"] == {}
        # CATCHES: kernel keys keep their /proc filenames (osrelease, ostype,
        # version) and non-Windows systems report an empty windowsVersion.

    def test_version_map(self, home, env, src):
        """The version map exposes the build information verbatim."""
        data = run_data(env, "--source", str(src))
        assert data["chezmoi"]["version"] == {
            "builtBy": "source",
            "commit": "40dcf243fbdda2b8dc912aa02f7ddb2219b96f6b",
            "date": "1792161864",
            "version": "",
        }
        # CATCHES: version fields are reported as strings with the empty
        # release version and the exact commit/date of the reference build.

    def test_hostname_user_group(self, home, env, src):
        """Identity values are reported as strings from the OS."""
        data = run_data(env, "--source", str(src))
        chezmoi = data["chezmoi"]
        fqdn = expected_fqdn_hostname()
        assert chezmoi["fqdnHostname"] == fqdn
        assert chezmoi["hostname"] == fqdn.split(".")[0]
        assert chezmoi["username"] == pwd.getpwuid(os.getuid()).pw_name
        assert chezmoi["uid"] == str(os.getuid())
        assert chezmoi["gid"] == str(os.getgid())
        assert chezmoi["group"] == grp.getgrgid(os.getgid()).gr_name
        # CATCHES: uid/gid serialize as decimal strings (not numbers) and
        # hostname is the first dot-separated component of the FQDN.

    def test_flags_reflect_command_line(self, home, env, src):
        """The flags map mirrors the persistent command-line flags."""
        data = run_data(env, "--source", str(src))
        assert data["chezmoi"]["flags"] == {
            "dryRun": False,
            "force": False,
            "keepGoing": False,
            "noPager": False,
            "noTTY": False,
        }
        data = run_data(
            env,
            "--source",
            str(src),
            "--dry-run",
            "--force",
            "--keep-going",
            "--no-pager",
            "--no-tty",
        )
        assert data["chezmoi"]["flags"] == {
            "dryRun": True,
            "force": True,
            "keepGoing": True,
            "noPager": True,
            "noTTY": True,
        }
        # CATCHES: exactly these five flags are exposed (no --verbose entry)
        # and each flips independently.


class TestDataFormats:
    def test_yaml_output(self, home, env, src):
        """data -f y emits YAML with the same content."""
        result = run_chezmoi(["data", "--format", "y", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout.startswith("chezmoi:\n")
        data = yaml.safe_load(result.stdout)
        assert data["chezmoi"]["os"] == "linux"
        assert data["chezmoi"]["command"] == "data"
        # CATCHES: the YAML output is rooted at chezmoi: (no outer wrapper)
        # and preserves the same values as the JSON form.

    @pytest.mark.parametrize("value", ["toml", "jsonc", "YA"])
    def test_format_flag_invalid_values(self, home, env, src, value):
        """data only supports json and yaml output formats."""
        result = run_chezmoi(["data", "--source", str(src), "-f", value], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: invalid argument "%s" for "-f, --format" flag: invalid value\n' % value
        )
        # CATCHES: the write-format registry for data is narrower than the
        # config-format registry; toml is invalid here.

    def test_rejects_extra_arguments(self, home, env, src):
        """data takes no positional arguments."""
        result = run_chezmoi(["data", "--source", str(src), "extra"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == 'chezmoi: unknown command "extra" for "chezmoi data"\n'
        # CATCHES: extra args are rejected with the unknown-command error
        # naming the data command.

    def test_source_flag_pointing_at_file(self, home, env, tmp_path):
        """A --source that is a regular file fails when reading the source state."""
        marker = tmp_path / "afile.txt"
        marker.write_text("hello\n")
        result = run_chezmoi(["data", "--source", str(marker)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: open %s/.chezmoiversion: not a directory\n" % marker
        # CATCHES: the source path is used as a directory, so the
        # .chezmoiversion read underneath it produces the not-a-directory error.


class TestChezmoidataFiles:
    def test_walk_order_last_format_wins(self, home, env, src):
        """.chezmoidata.<format> files merge in a fixed order."""
        (src / ".chezmoidata.json").write_text('{"k": "fromjson"}\n')
        (src / ".chezmoidata.toml").write_text('k = "fromtoml"\n')
        data = run_data(env, "--source", str(src))
        assert data["k"] == "fromtoml"
        # CATCHES: json is read before toml and later files overwrite earlier
        # ones key-by-key instead of erroring on the conflict.

    def test_directory_merge_and_hidden_files(self, home, env, src):
        """.chezmoidata/ subdirectories merge recursively; hidden files are skipped."""
        (src / ".chezmoidata").mkdir()
        (src / ".chezmoidata" / "base.toml").write_text('a = 1\nb = "top"\n')
        (src / ".chezmoidata" / "sub").mkdir()
        (src / ".chezmoidata" / "sub" / "inner.yaml").write_text("b: sub\nc:\n  - 1\n  - 2\n")
        (src / ".chezmoidata" / ".hidden.toml").write_text("ignored = true\n")
        data = run_data(env, "--source", str(src))
        assert data["a"] == 1
        assert data["b"] == "sub"
        assert data["c"] == [1, 2]
        assert "ignored" not in data
        # CATCHES: files in subdirectories become nested maps that deep-merge
        # over the top-level files, and dotfiles are invisible to the walk.

    def test_jsonc_comments_accepted(self, home, env, src):
        """A .chezmoidata.jsonc file may contain // comments."""
        (src / ".chezmoidata").mkdir()
        (src / ".chezmoidata" / "file.jsonc").write_text('// comment\n{"x": 1}\n')
        data = run_data(env, "--source", str(src))
        assert data["x"] == 1
        # CATCHES: jsonc is a distinct accepted format that strips // line
        # comments before JSON decoding.

    def test_merges_into_builtin_chezmoi_key(self, home, env, src):
        """A chezmoidata key named chezmoi merges into the builtin map."""
        (src / ".chezmoidata.json").write_text('{"chezmoi": {"custom": "x"}}\n')
        data = run_data(env, "--source", str(src))
        assert data["chezmoi"]["custom"] == "x"
        assert data["chezmoi"]["os"] == "linux"
        # CATCHES: user data merges into (not replaces) the builtin chezmoi
        # map, so existing keys survive.

    @pytest.mark.parametrize(
        ("filename", "contents", "expected_stderr"),
        [
            pytest.param(
                ".chezmoisomething.toml",
                "x = 1\n",
                "chezmoi: {path}: not allowed in .chezmoidata directory",
                id="chezmoi-prefixed-name",
            ),
            pytest.param(
                "file.ini",
                "x = 1\n",
                "chezmoi: {path}: .ini: unknown format",
                id="unknown-extension",
            ),
            pytest.param(
                "file.json",
                "bad json\n",
                "chezmoi: {path}: invalid character 'b' looking for beginning of value",
                id="invalid-json",
            ),
        ],
    )
    def test_directory_file_errors(self, home, env, src, filename, contents, expected_stderr):
        """Invalid files inside .chezmoidata/ are hard errors naming the file."""
        data_dir = src / ".chezmoidata"
        data_dir.mkdir()
        path = data_dir / filename
        path.write_text(contents)
        result = run_chezmoi(["data", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == expected_stderr.format(path=path) + "\n"
        # CATCHES: the error names the exact offending file and reason; the
        # .chezmoi prefix is reserved inside the data directory.

    def test_yaml_file_with_scalar_top_level(self, home, env, src):
        """A YAML data file whose top level is not a mapping errors with context."""
        data_dir = src / ".chezmoidata"
        data_dir.mkdir()
        path = data_dir / "inner.yaml"
        path.write_text('b = "sub"\nc = [1,2]\n')
        result = run_chezmoi(["data", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: %s: [1:1] string was used where mapping is expected\n"
            '>  1 | b = "sub"\n'
            "   2 | c = [1,2]\n"
            "       ^\n"
            "\n" % path
        )
        # CATCHES: YAML errors include the annotated source context (line
        # marker, following line, and caret) exactly as the parser emits it.


class TestConfigData:
    def test_config_data_merges_over_chezmoidata(self, home, env, src):
        """Config [data] deep-merges with .chezmoidata files and wins."""
        write_config(
            home,
            '[data]\n    email = "cfg@example.com"\n\n    [data.nested]\n        a = 1\n        b = 2\n',
        )
        (src / ".chezmoidata.json").write_text('{"nested": {"a": 9}, "arr": [1, 2]}\n')
        data = run_data(env, "--source", str(src))
        assert data["email"] == "cfg@example.com"
        assert data["nested"] == {"a": 1, "b": 2}
        assert data["arr"] == [1, 2]
        # CATCHES: config data has higher precedence than .chezmoidata files
        # while still merging recursively rather than replacing the map.

    def test_config_data_visible_in_dump_config(self, home, env):
        """dump-config exposes the config file's [data] section."""
        write_config(home, '[data]\n    email = "cfg@example.com"\n')
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 0
        assert json.loads(result.stdout)["data"] == {"email": "cfg@example.com"}
        # CATCHES: [data] is part of the config document itself, so it appears
        # in dump-config but .chezmoidata files do not.


class TestOverrideData:
    def test_override_data_flag_preserves_types(self, home, env, src):
        """--override-data decodes JSON with native number types."""
        data = run_data(
            env,
            "--source",
            str(src),
            "--override-data",
            '{"o": 3, "f": 2.5, "n": {"a": 1}}',
        )
        assert data["o"] == 3
        assert isinstance(data["o"], int)
        assert data["f"] == 2.5
        assert isinstance(data["f"], float)
        assert data["n"] == {"a": 1}
        # CATCHES: integers stay integers and floats stay floats through the
        # merge and re-serialization (no stringification of numbers).

    def test_override_data_beats_file(self, home, env, src):
        """--override-data wins when both it and --override-data-file are given."""
        override_file = src / "ov.toml"
        override_file.write_text('ov = "fromfile"\n')
        data = run_data(
            env,
            "--source",
            str(src),
            "--override-data",
            '{"ov": "fromflag"}',
            "--override-data-file",
            str(override_file),
        )
        assert data["ov"] == "fromflag"
        # CATCHES: the flag value is applied after the file, so it takes
        # precedence rather than being ignored or merged.

    @pytest.mark.parametrize(
        ("value", "expected_stderr"),
        [
            pytest.param(
                "not-json",
                "chezmoi: invalid character 'o' in literal null (expecting 'u')\n",
                id="bare-word",
            ),
            pytest.param(
                "[1,2]",
                "chezmoi: json: cannot unmarshal array into Go value of type "
                "map[string]interface {}\n",
                id="top-level-array",
            ),
        ],
    )
    def test_override_data_flag_errors(self, home, env, src, value, expected_stderr):
        """Invalid --override-data values produce the raw JSON decode error."""
        result = run_chezmoi(
            ["data", "--source", str(src), "--override-data", value], env=env
        )
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == expected_stderr
        # CATCHES: the value is parsed as a JSON object; scalars and arrays
        # fail with encoding/json's own error messages.

    def test_override_data_file_formats(self, home, env, src):
        """--override-data-file reads toml, json and yaml by extension."""
        toml_file = src / "ov.toml"
        toml_file.write_text('ov = "fromfile"\n')
        data = run_data(env, "--source", str(src), "--override-data-file", str(toml_file))
        assert data["ov"] == "fromfile"
        json_file = src / "ov.json"
        json_file.write_text('{"ovf": 1}\n')
        data = run_data(env, "--source", str(src), "--override-data-file", str(json_file))
        assert data["ovf"] == 1
        # CATCHES: the file's parser is chosen by extension, and the full
        # range of config formats is accepted here.

    def test_override_data_file_errors(self, home, env, src):
        """Missing and unparseable --override-data-file values are errors."""
        ini_file = src / "ov.ini"
        ini_file.write_text("x = 1\n")
        result = run_chezmoi(
            ["data", "--source", str(src), "--override-data-file", str(ini_file)], env=env
        )
        assert result.returncode == 1
        assert result.stderr == "chezmoi: %s: unknown format\n" % ini_file
        missing = src / "nofile.toml"
        result = run_chezmoi(
            ["data", "--source", str(src), "--override-data-file", str(missing)], env=env
        )
        assert result.returncode == 1
        assert result.stderr == "chezmoi: open %s: no such file or directory\n" % missing
        # CATCHES: an existing file with an unknown extension fails after the
        # open, while a missing file fails at the open itself.


class TestSystemDataSurfaces:
    """The os-release and kernel data of internal/chezmoi/data.go, pinned with
    the values recorded from this machine's /etc/os-release (a fixed part of
    the image) and reachable both from `chezmoi data` and from templates."""

    def test_os_release_recorded_values(self, home, env, src):
        """The os-release map is the exact parsed /etc/os-release content."""
        data = run_data(env, "--source", str(src))
        assert data["chezmoi"]["osRelease"] == {
            "bugReportURL": "https://bugs.launchpad.net/ubuntu/",
            "homeURL": "https://www.ubuntu.com/",
            "id": "ubuntu",
            "idLike": "debian",
            "logo": "ubuntu-logo",
            "name": "Ubuntu",
            "prettyName": "Ubuntu 24.04 LTS",
            "privacyPolicyURL": "https://www.ubuntu.com/legal/terms-and-policies/privacy-policy",
            "supportURL": "https://help.ubuntu.com/",
            "ubuntuCodename": "noble",
            "version": "24.04 LTS (Noble Numbat)",
            "versionCodename": "noble",
            "versionID": "24.04",
        }
        # CATCHES: the parser strips the double quotes around quoted values
        # (PRETTY_NAME, VERSION, the URLs) while keeping unquoted values
        # (VERSION_CODENAME, LOGO) verbatim, and camelCases every key with
        # the well-known abbreviations (URL, ID) left upper case.

    def test_os_release_and_kernel_available_to_templates(self, home, env, src):
        """execute-template exposes the same osRelease and kernel maps."""
        template = (
            "{{ .chezmoi.osRelease.prettyName }}|{{ .chezmoi.osRelease.id }}"
            "|{{ .chezmoi.kernel.ostype }}|{{ .chezmoi.osRelease.bugReportURL }}"
        )
        result = run_chezmoi(
            ["execute-template", "--source", str(src), template], env=env
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == (
            "Ubuntu 24.04 LTS|ubuntu|Linux|https://bugs.launchpad.net/ubuntu/"
        )
        # CATCHES: the /etc/os-release and /proc/sys/kernel data gathered by
        # the data module is part of the template data map, with the same
        # unquoted values and camelCased keys that `chezmoi data` prints.
