"""`chezmoi dump-config`: serialized config output and its format flag."""

from __future__ import annotations

import json

import pytest

from conftest import current_umask, run_chezmoi, write_config


class TestDumpConfigDefaults:
    def test_default_json_structure(self, home, env, tmp_path):
        """dump-config with no config file prints the full default config."""
        result = run_chezmoi(["dump-config"], env=env, cwd=tmp_path)
        assert result.returncode == 0
        assert result.stderr == ""
        data = json.loads(result.stdout)
        assert data["color"] == "auto"
        assert data["format"] == "json"
        assert data["safe"] is True
        assert data["verbose"] is False
        assert data["interactive"] is False
        assert data["mode"] == "file"
        assert data["progress"] == "auto"
        assert data["umask"] == current_umask()
        assert data["destDir"] == str(home)
        assert data["sourceDir"] == str(home / ".local" / "share" / "chezmoi")
        assert data["workingTree"] == str(home / ".local" / "share" / "chezmoi")
        assert data["cacheDir"] == str(home / ".cache" / "chezmoi")
        assert data["persistentState"] == ""
        assert data["scriptTempDir"] == ""
        assert data["encryption"] == ""
        assert data["lessInteractive"] is False
        assert data["tempDir"] == str(tmp_path / "tmp")
        assert data["data"] == {}
        assert data["env"] is None
        assert data["hooks"] is None
        assert data["textConv"] is None
        assert sorted(data) == [
            "add",
            "age",
            "awsSecretsManager",
            "azureKeyVault",
            "bitwarden",
            "bitwardenSecrets",
            "cacheDir",
            "cd",
            "color",
            "completion",
            "dashlane",
            "data",
            "destDir",
            "diff",
            "docker",
            "doppler",
            "edit",
            "ejson",
            "encryption",
            "env",
            "format",
            "git",
            "gitHub",
            "gopass",
            "gpg",
            "hooks",
            "interactive",
            "interpreters",
            "keepassxc",
            "keeper",
            "lastpass",
            "lessInteractive",
            "merge",
            "mode",
            "onepassword",
            "pager",
            "pagerArgs",
            "pass",
            "passhole",
            "persistentState",
            "pinentry",
            "progress",
            "protonPass",
            "rbw",
            "safe",
            "scriptEnv",
            "scriptTempDir",
            "secret",
            "sourceDir",
            "status",
            "tempDir",
            "template",
            "textConv",
            "umask",
            "update",
            "useBuiltinAge",
            "useBuiltinGit",
            "vault",
            "verbose",
            "verify",
            "warnings",
            "workingTree",
        ]
        # CATCHES: the marshaled default config must include every documented
        # default (safe=true, mode=file, empty persistentState, ...) with the
        # exact top-level field set of the ConfigFile struct.

    def test_default_sections(self, home, env):
        """Nested default sections marshal with their exact field sets."""
        result = run_chezmoi(["dump-config"], env=env)
        data = json.loads(result.stdout)
        assert data["edit"] == {
            "command": "",
            "args": None,
            "hardlink": True,
            "minDuration": 1000000000,
            "watch": False,
            "apply": False,
        }
        assert data["template"] == {"options": ["missingkey=error"]}
        assert data["diff"] == {
            "command": "",
            "args": None,
            "exclude": [],
            "pager": "\x00",
            "pagerArgs": None,
            "reverse": False,
            "scriptContents": True,
        }
        assert data["git"] == {
            "command": "git",
            "autoadd": False,
            "autocommit": False,
            "autopush": False,
            "commitMessageTemplate": "",
            "commitMessageTemplateFile": "",
            "lfs": False,
        }
        assert data["gitHub"] == {"refreshPeriod": 60000000000}
        assert data["status"] == {"exclude": [], "pathStyle": "relative"}
        # CATCHES: durations marshal as nanosecond integers, the unset diff
        # pager serializes as a NUL sentinel byte, and booleans match defaults.

    def test_interpreters_defaults(self, home, env):
        """The interpreter table lists every builtin extension."""
        result = run_chezmoi(["dump-config"], env=env)
        data = json.loads(result.stdout)
        assert data["interpreters"] == {
            "bat": {"command": "", "args": None},
            "cmd": {"command": "", "args": None},
            "com": {"command": "", "args": None},
            "exe": {"command": "", "args": None},
            "nu": {"command": "nu", "args": None},
            "pl": {"command": "perl", "args": None},
            "ps1": {"command": "", "args": None},
            "py": {"command": "python3", "args": None},
            "rb": {"command": "ruby", "args": None},
        }
        # CATCHES: the default interpreter set and commands (python3, perl,
        # ruby, nu; empty for Windows extensions) must match exactly.


class TestDumpConfigFormats:
    def test_yaml_output(self, home, env):
        """-f y produces YAML with duration strings and empty-map renders."""
        result = run_chezmoi(["dump-config", "--format", "y"], env=env)
        assert result.returncode == 0
        assert result.stdout.startswith("configfile:\n")
        assert "  color: auto\n" in result.stdout
        assert "  format: json\n" in result.stdout
        assert "  mode: file\n" in result.stdout
        assert "  env: {}\n" in result.stdout
        assert "  hooks: {}\n" in result.stdout
        assert "  pager: \"\"\n" in result.stdout
        assert "    refreshPeriod: 1m0s\n" in result.stdout
        assert "    minDuration: 1s\n" in result.stdout
        assert "    pager: \x00\n" in result.stdout
        # CATCHES: YAML renders null maps as {}, durations as Go duration
        # strings, and keeps the NUL diff.pager sentinel as a raw byte.

    @pytest.mark.parametrize("value", ["toml", "jsonc", "YA"])
    def test_format_flag_invalid_values(self, home, env, value):
        """dump-config only supports json and yaml output."""
        result = run_chezmoi(["dump-config", "-f", value], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: invalid argument "%s" for "-f, --format" flag: invalid value\n' % value
        )
        # CATCHES: the data-format flag accepts unique abbreviations of json
        # and yaml only; toml/jsonc/case-mismatched values are rejected.

    def test_rejects_extra_arguments(self, home, env):
        """dump-config takes no positional arguments."""
        result = run_chezmoi(["dump-config", "extra"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == 'chezmoi: unknown command "extra" for "chezmoi dump-config"\n'
        # CATCHES: positional args produce the unknown-command error naming
        # dump-config itself.


class TestDumpConfigOutput:
    def test_output_flag_writes_file(self, home, env, tmp_path):
        """--output writes the dump to a file and leaves stdout empty."""
        out = tmp_path / "dump.json"
        result = run_chezmoi(["dump-config", "--output", str(out)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        data = json.loads(out.read_text())
        assert data["color"] == "auto"
        assert data["format"] == "json"
        # CATCHES: the output path redirects the serialization instead of
        # stdout, and the file must contain the same JSON document.

    def test_output_dash_writes_literal_dash_file(self, home, env, tmp_path):
        """--output - is treated as a relative path, not stdout."""
        result = run_chezmoi(["dump-config", "--output", "-"], env=env, cwd=tmp_path)
        assert result.returncode == 0
        assert result.stdout == ""
        assert (tmp_path / "-").is_file()
        assert json.loads((tmp_path / "-").read_text())["color"] == "auto"
        # CATCHES: the path is not special-cased, so "-" creates a file named
        # "-" in the working directory while stdout stays empty.


class TestDumpConfigWithConfigFile:
    def test_reflects_config_file(self, home, env):
        """Settings from the config file appear in the dump."""
        write_config(
            home,
            'color = false\npager = "more"\npagerArgs = ["-r"]\n\n[data]\n    email = "cfg@example.com"\n',
        )
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data["color"] is False
        assert data["pager"] == "more"
        assert data["pagerArgs"] == ["-r"]
        assert data["data"] == {"email": "cfg@example.com"}
        # CATCHES: dump-config shows the merged config, including [data], so
        # the config file must actually be decoded before marshaling.

    def test_format_from_config_file(self, home, env):
        """format = yaml in the config file switches the dump to YAML."""
        write_config(home, 'format = "yaml"\n')
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 0
        assert "  format: yaml\n" in result.stdout
        assert "  color: auto\n" in result.stdout
        # CATCHES: the config's own format key selects the output format,
        # overriding the json default without any command-line flag.
