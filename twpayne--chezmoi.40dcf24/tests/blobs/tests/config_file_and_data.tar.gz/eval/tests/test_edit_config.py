"""`chezmoi edit-config` and `chezmoi edit-config-template`: editor invocation.

These pin how the configured editor is resolved ($VISUAL, $EDITOR, or the
edit.command/edit.args config keys), what file it is pointed at, the
edit.minDuration warning, and how edit-config-template seeds a missing
.chezmoi.<format>.tmpl from the current config file.
"""

from __future__ import annotations

import stat
from pathlib import Path

import pytest

from conftest import current_umask, run_chezmoi, write_config

EDITOR_SCRIPT = (
    "#!/bin/sh\n"
    'printf \'%s\\n\' "$*" > "$HOME/edargs"\n'
    'pwd > "$HOME/edpwd"\n'
)

FAILING_SCRIPT = "#!/bin/sh\nexit 7\n"


@pytest.fixture
def editor(tmp_path: Path) -> Path:
    """An editor script recording its arguments and working directory."""
    path = tmp_path / "editor.sh"
    path.write_text(EDITOR_SCRIPT)
    path.chmod(0o755)
    return path


def make_editor(tmp_path: Path, name: str, contents: str) -> Path:
    path = tmp_path / name
    path.write_text(contents)
    path.chmod(0o755)
    return path


def edargs(home: Path) -> str:
    return (home / "edargs").read_text().rstrip("\n")


class TestEditConfig:
    def test_editor_receives_config_file_path(self, home, env, tmp_path, editor):
        """edit-config runs $EDITOR with the config file path as its only arg."""
        write_config(home, '[edit]\n    minDuration = "1h"\n')
        result = run_chezmoi(["edit-config"], env={**env, "EDITOR": str(editor)}, cwd=tmp_path)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: warning: %s %s: returned in less than 1h0m0s\n"
            % (editor, home / ".config" / "chezmoi" / "chezmoi.toml")
        )
        assert edargs(home) == str(home / ".config" / "chezmoi" / "chezmoi.toml")
        assert (home / "edpwd").read_text() == str(tmp_path) + "\n"
        # CATCHES: the editor gets exactly the config file path, inherits the
        # command's working directory, and an editor returning faster than
        # edit.minDuration draws a warning naming the shell-quoted command.

    def test_min_duration_zero_disables_warning(self, home, env, editor):
        """edit.minDuration = 0 suppresses the returned-too-fast warning."""
        write_config(home, "[edit]\n    minDuration = 0\n")
        result = run_chezmoi(["edit-config"], env={**env, "EDITOR": str(editor)})
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert edargs(home) == str(home / ".config" / "chezmoi" / "chezmoi.toml")
        # CATCHES: zero is the documented sentinel disabling the duration
        # check, not a duration that is always exceeded.

    def test_visual_preferred_over_editor(self, home, env, editor):
        """$VISUAL wins over $EDITOR when both are set."""
        write_config(home, "[edit]\n    minDuration = 0\n")
        env = {**env, "VISUAL": str(editor), "EDITOR": "/nonexistent-editor"}
        result = run_chezmoi(["edit-config"], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert edargs(home) == str(home / ".config" / "chezmoi" / "chezmoi.toml")
        # CATCHES: had $EDITOR been used the command would have failed to
        # start, so success pins the VISUAL-over-EDITOR precedence.

    def test_editor_value_split_into_words(self, home, env, tmp_path, editor):
        """An $EDITOR containing spaces is split like a shell command."""
        write_config(home, "[edit]\n    minDuration = 0\n")
        result = run_chezmoi(
            ["edit-config"], env={**env, "EDITOR": "%s --flag" % editor}, cwd=tmp_path
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert edargs(home) == "--flag %s" % (home / ".config" / "chezmoi" / "chezmoi.toml")
        # CATCHES: the editor string is word-split (flag before the file path)
        # rather than treated as a single program name.

    def test_edit_command_from_config_beats_env(self, home, env, tmp_path, editor):
        """edit.command/edit.args from the config override $EDITOR entirely."""
        write_config(
            home,
            '[edit]\n    command = "%s"\n    args = ["--cfg"]\n    minDuration = 0\n' % editor,
        )
        result = run_chezmoi(
            ["edit-config"], env={**env, "EDITOR": "/nonexistent-editor"}, cwd=tmp_path
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert edargs(home) == "--cfg %s" % (home / ".config" / "chezmoi" / "chezmoi.toml")
        # CATCHES: the config keys take precedence over the environment and
        # their args are prepended to the file argument.

    def test_missing_editor_reports_exec_error(self, home, env):
        """An unresolvable editor fails the command with the exec error."""
        write_config(home, '[edit]\n    minDuration = "1h"\n')
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        result = run_chezmoi(["edit-config"], env={**env, "EDITOR": "no-such-editor-xyz"})
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: warning: no-such-editor-xyz %s: returned in less than 1h0m0s\n"
            "chezmoi: no-such-editor-xyz: exec: \"no-such-editor-xyz\": "
            "executable file not found in $PATH\n" % config
        )
        # CATCHES: the duration warning is printed before the exec failure is
        # reported, and the error keeps the unresolved command name.

    def test_editor_failure_exit_status(self, home, env, tmp_path):
        """A failing editor's exit status is reported and fails the command."""
        failing = make_editor(tmp_path, "failing.sh", FAILING_SCRIPT)
        write_config(home, '[edit]\n    minDuration = "1h"\n')
        config = home / ".config" / "chezmoi" / "chezmoi.toml"
        result = run_chezmoi(["edit-config"], env={**env, "EDITOR": str(failing)})
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: warning: %s %s: returned in less than 1h0m0s\n"
            "chezmoi: %s: exit status 7\n" % (failing, config, failing)
        )
        # CATCHES: the child's exit status is surfaced as "exit status 7" with
        # the editor path, and the run still returns the warning first.

    def test_edit_config_creates_config_dir(self, home, env, editor):
        """edit-config creates the default config directory when missing."""
        result = run_chezmoi(["edit-config"], env={**env, "EDITOR": str(editor)})
        assert result.returncode == 0
        assert result.stdout == ""
        assert edargs(home) == str(home / ".config" / "chezmoi" / "chezmoi.toml")
        assert (home / ".config" / "chezmoi").is_dir()
        # CATCHES: the command creates the config directory before launching
        # the editor even when no config file exists anywhere.

    def test_config_flag_selects_edited_file(self, home, env, tmp_path, editor):
        """--config redirects edit-config to the given file."""
        custom = tmp_path / "other.toml"
        custom.write_text("[edit]\n    minDuration = 0\n")
        result = run_chezmoi(
            ["edit-config", "--config", str(custom)], env={**env, "EDITOR": str(editor)}
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert edargs(home) == str(custom)
        # CATCHES: the editor edits the --config path, not the default
        # ~/.config/chezmoi/chezmoi.toml location.

    def test_rejects_arguments(self, home, env, editor):
        """edit-config takes no positional arguments and runs no editor."""
        result = run_chezmoi(["edit-config", "extra"], env={**env, "EDITOR": str(editor)})
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == 'chezmoi: unknown command "extra" for "chezmoi edit-config"\n'
        assert not (home / "edargs").exists()
        # CATCHES: argument validation fails before any editor process is
        # started, with the unknown-command error naming edit-config.


class TestEditConfigTemplate:
    def test_edits_existing_template(self, home, env, src, editor):
        """With a template present, the editor opens the template itself."""
        write_config(home, "[edit]\n    minDuration = 0\n")
        (src / ".chezmoi.toml.tmpl").write_text('sourceDir = "/x"\n')
        result = run_chezmoi(
            ["edit-config-template", "--source", str(src)], env={**env, "EDITOR": str(editor)}
        )
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert edargs(home) == str(src / ".chezmoi.toml.tmpl")
        assert (src / ".chezmoi.toml.tmpl").read_text() == 'sourceDir = "/x"\n'
        assert sorted(p.name for p in src.iterdir()) == [".chezmoi.toml.tmpl"]
        # CATCHES: the existing template is passed to the editor unchanged and
        # no additional template file is created in the source directory.

    def test_seeds_template_from_config_file(self, home, env, src, editor):
        """Without a template, the config file's bytes seed a new template."""
        config = 'color = false\n\n[edit]\n    minDuration = 0\n'
        write_config(home, config)
        result = run_chezmoi(
            ["edit-config-template", "--source", str(src)], env={**env, "EDITOR": str(editor)}
        )
        assert result.returncode == 0
        assert result.stderr == ""
        template = src / ".chezmoi.toml.tmpl"
        assert edargs(home) == str(template)
        assert template.read_text() == config
        assert stat.S_IMODE(template.stat().st_mode) == 0o666 & ~current_umask()
        # CATCHES: the new .chezmoi.toml.tmpl is a verbatim copy of the whole
        # config file (including the [edit] section) written with mode
        # 0666 modified by the process umask.

    def test_no_config_file_no_template_written(self, home, env, src, editor):
        """With neither template nor config file, nothing is seeded."""
        result = run_chezmoi(
            ["edit-config-template", "--source", str(src)], env={**env, "EDITOR": str(editor)}
        )
        assert result.returncode == 0
        assert result.stdout == ""
        assert edargs(home) == str(src / ".chezmoi.toml.tmpl")
        assert not (src / ".chezmoi.toml.tmpl").exists()
        # CATCHES: the editor is still invoked on the would-be template path,
        # but the file itself must not be created when there is no config to
        # copy from.

    def test_creates_missing_source_dir(self, home, env, tmp_path, editor):
        """A missing source directory is created for the new template."""
        new_src = tmp_path / "newsrc"
        result = run_chezmoi(
            ["edit-config-template", "--source", str(new_src)],
            env={**env, "EDITOR": str(editor)},
        )
        assert result.returncode == 0
        assert result.stdout == ""
        assert edargs(home) == str(new_src / ".chezmoi.toml.tmpl")
        assert new_src.is_dir()
        assert stat.S_IMODE(new_src.stat().st_mode) == 0o777 & ~current_umask()
        assert not (new_src / ".chezmoi.toml.tmpl").exists()
        # CATCHES: the source directory is created (mode 0777 modified by the
        # umask) before the editor runs, even with no config file to seed from.

    def test_yaml_config_names_yaml_template(self, home, env, src, editor):
        """The template extension follows the config file's own extension."""
        config = "color: false\nedit:\n    minDuration: 0\n"
        write_config(home, config, "chezmoi.yaml")
        result = run_chezmoi(
            ["edit-config-template", "--source", str(src)], env={**env, "EDITOR": str(editor)}
        )
        assert result.returncode == 0
        assert result.stderr == ""
        template = src / ".chezmoi.yaml.tmpl"
        assert edargs(home) == str(template)
        assert template.read_text() == config
        assert not (src / ".chezmoi.toml.tmpl").exists()
        # CATCHES: a chezmoi.yaml config produces .chezmoi.yaml.tmpl (not
        # .chezmoi.toml.tmpl), seeded with the YAML config's exact bytes.

    def test_config_flag_names_template(self, home, env, src, tmp_path, editor):
        """--config controls both the seeding source and the template name."""
        custom = tmp_path / "other.toml"
        custom.write_text('color = false\n\n[edit]\n    minDuration = 0\n')
        result = run_chezmoi(
            ["edit-config-template", "--source", str(src), "--config", str(custom)],
            env={**env, "EDITOR": str(editor)},
        )
        assert result.returncode == 0
        assert result.stderr == ""
        template = src / ".other.toml.tmpl"
        assert edargs(home) == str(template)
        assert template.read_text() == custom.read_text()
        # CATCHES: the template is named after the --config file's base name
        # (.other.toml.tmpl) and seeded from that file, not the default one.

    def test_default_source_dir_used(self, home, env, editor):
        """Without --source the template goes to ~/.local/share/chezmoi."""
        config = 'color = false\n\n[edit]\n    minDuration = 0\n'
        write_config(home, config)
        result = run_chezmoi(["edit-config-template"], env={**env, "EDITOR": str(editor)})
        assert result.returncode == 0
        assert result.stderr == ""
        template = home / ".local" / "share" / "chezmoi" / ".chezmoi.toml.tmpl"
        assert edargs(home) == str(template)
        assert template.read_text() == config
        # CATCHES: the default source directory is the XDG data home
        # (~/.local/share/chezmoi) and is created together with the seeded
        # template when no --source is given.

    def test_rejects_arguments(self, home, env, src, editor):
        """edit-config-template takes no positional arguments."""
        result = run_chezmoi(
            ["edit-config-template", "extra", "--source", str(src)],
            env={**env, "EDITOR": str(editor)},
        )
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: unknown command "extra" for "chezmoi edit-config-template"\n'
        )
        assert not (home / "edargs").exists()
        # CATCHES: argument validation fails before the source directory is
        # touched or any editor process is started.
