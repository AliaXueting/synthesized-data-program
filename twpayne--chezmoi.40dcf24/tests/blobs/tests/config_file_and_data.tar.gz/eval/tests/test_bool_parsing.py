"""Boolean value parsing across the configuration surfaces.

These exercise chezmoi.ParseBool in internal/chezmoi/chezmoi.go, which is
stricter than the Go standard library's strconv.ParseBool: it additionally
accepts the on/off and y/n spellings, case insensitively and with surrounding
whitespace. It is reached through the autoBool flags (--color and friends),
through the config file's color key, and through execute-template --init's
--promptBool.
"""

from __future__ import annotations

import json

import pytest

from conftest import run_chezmoi, write_config


def dump_color(env, *args):
    """Return the value of the color key reported by dump-config."""
    result = run_chezmoi(["dump-config", *args], env=env)
    assert result.returncode == 0
    return json.loads(result.stdout)["color"]


class TestCliColorFlag:
    @pytest.mark.parametrize(
        ("value", "expected"),
        [
            pytest.param("on", True, id="on"),
            pytest.param("ON", True, id="ON"),
            pytest.param("y", True, id="y"),
            pytest.param("Y", True, id="Y"),
            pytest.param("yes", True, id="yes"),
            pytest.param("YES", True, id="YES"),
            pytest.param("n", False, id="n"),
            pytest.param("no", False, id="no"),
            pytest.param("NO", False, id="NO"),
            pytest.param("off", False, id="off"),
            pytest.param("OFF", False, id="OFF"),
            pytest.param("1", True, id="1"),
            pytest.param("0", False, id="0"),
            pytest.param("t", True, id="t"),
            pytest.param("F", False, id="F"),
            pytest.param("True", True, id="True"),
            pytest.param("FALSE", False, id="FALSE"),
            pytest.param("auto", "auto", id="auto"),
            pytest.param("AUTO", "auto", id="AUTO"),
            pytest.param("Auto", "auto", id="Auto"),
        ],
    )
    def test_color_flag_values(self, home, env, value, expected):
        """--color accepts the on/off and y/n spellings plus "auto"."""
        assert dump_color(env, "--color=%s" % value) == expected
        # CATCHES: the flag is a tri-state autoBool whose non-auto values go
        # through a parser that accepts more spellings than strconv.ParseBool
        # and whose auto value is matched case insensitively.

    def test_color_flag_is_restored_after_the_config_is_read(self, home, env):
        """A --color flag survives a config file that also sets color."""
        write_config(home, "color = false\n")
        assert dump_color(env, "--color=on") is True
        assert dump_color(env) is False
        # CATCHES: the values of the flags the user actually passed are saved
        # before the config file is decoded and restored afterwards, so the
        # flag wins over the config file in the same run.


class TestConfigColorKey:
    @pytest.mark.parametrize(
        ("literal", "expected"),
        [
            pytest.param('color = "on"', True, id="on"),
            pytest.param('color = "no"', False, id="no"),
            pytest.param('color = "yes"', True, id="yes"),
            pytest.param('color = "off"', False, id="off"),
            pytest.param("color = true", True, id="true"),
            pytest.param("color = false", False, id="false"),
            pytest.param('color = "auto"', "auto", id="auto"),
        ],
    )
    def test_config_color_values(self, home, env, literal, expected):
        """The config file's color key uses the same parser as the flag."""
        write_config(home, literal + "\n")
        assert dump_color(env) == expected
        # CATCHES: the mapstructure decode hook accepts both booleans and
        # strings and resolves them with the same extended bool parser.


class TestPromptBool:
    @pytest.mark.parametrize(
        ("value", "expected"),
        [
            pytest.param("yes", "true", id="yes"),
            pytest.param("y", "true", id="y"),
            pytest.param("on", "true", id="on"),
            pytest.param("ON", "true", id="ON"),
            pytest.param("YES", "true", id="YES"),
            pytest.param("n", "false", id="n"),
            pytest.param("no", "false", id="no"),
            pytest.param("NO", "false", id="NO"),
            pytest.param("off", "false", id="off"),
            pytest.param("OFF", "false", id="OFF"),
            pytest.param(" yes ", "true", id="padded"),
            pytest.param("true", "true", id="true"),
            pytest.param("1", "true", id="one"),
            pytest.param("0", "false", id="zero"),
        ],
    )
    def test_prompt_bool_values(self, home, env, src, value, expected):
        """--promptBool parses its values with the extended bool parser."""
        result = run_chezmoi(
            ["execute-template", "--init", "--promptBool", "x=%s" % value,
             "--source", str(src), '{{ promptBool "x" }}'],
            env=env,
        )
        assert result.returncode == 0
        assert result.stdout == expected
        assert result.stderr == ""
        # CATCHES: the value is lowercased and trimmed before being matched
        # against the on/off and y/n spellings, and execute-template writes
        # the result without appending a newline.

    def test_prompt_bool_default_argument(self, home, env, src):
        """promptBool falls back to its default when no value is supplied."""
        result = run_chezmoi(
            ["execute-template", "--init", "--source", str(src),
             '{{ promptBool "unanswered" true }}'],
            env=env,
        )
        assert result.returncode == 0
        assert result.stdout == "true"
        # CATCHES: an unset --promptBool key makes promptBool return its
        # second argument instead of erroring or prompting.


class TestInvalidBoolValues:
    def test_invalid_color_flag(self, home, env):
        """An unparsable --color value is reported by pflag."""
        result = run_chezmoi(["dump-config", "--color=2"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: invalid argument "2" for "--color" flag: '
            'strconv.ParseBool: parsing "2": invalid syntax\n'
        )
        # CATCHES: the extended parser falls back to strconv.ParseBool, whose
        # error is wrapped in the pflag invalid-argument error.

    def test_invalid_config_color(self, home, env):
        """An unparsable color in the config file is a decoding error."""
        path = write_config(home, 'color = "yeah"\n')
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: invalid config: %s: decoding failed due to the following "
            "error(s): 'color' strconv.ParseBool: parsing \"yeah\": invalid syntax\n" % path
        )
        # CATCHES: the same parser error surfaces as a mapstructure decoding
        # error that names the config file and the offending key.

    def test_invalid_prompt_bool(self, home, env, src):
        """An unparsable --promptBool value is reported before any output."""
        result = run_chezmoi(
            ["execute-template", "--init", "--promptBool", "x=bogus",
             "--source", str(src), '{{ promptBool "x" }}'],
            env=env,
        )
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: strconv.ParseBool: parsing "bogus": invalid syntax\n'
        )
        # CATCHES: --promptBool values are parsed before the template runs, so
        # the error is the bare strconv error with no template or key context.

    def test_invalid_prompt_bool_keeps_the_original_spacing(self, home, env, src):
        """The unparsable value is reported verbatim, padding included."""
        result = run_chezmoi(
            ["execute-template", "--init", "--promptBool", "x= bogus ",
             "--source", str(src), '{{ promptBool "x" }}'],
            env=env,
        )
        assert result.returncode == 1
        assert result.stderr == (
            'chezmoi: strconv.ParseBool: parsing " bogus ": invalid syntax\n'
        )
        # CATCHES: leading and trailing whitespace is trimmed for the
        # successful spellings but the error message quotes the value as given.
