"""Config file contents: decoding, precedence, defaults, and validation."""

from __future__ import annotations

import json
import os

import pytest

from conftest import current_umask, run_chezmoi, write_config


def dump(env, *args):
    """Run dump-config and return (returncode, parsed JSON or None)."""
    result = run_chezmoi(["dump-config", *args], env=env)
    data = json.loads(result.stdout) if result.returncode == 0 else None
    return result, data


class TestPrecedence:
    def test_dest_dir_cli_overrides_config(self, home, env, src, tmp_path):
        """--destination beats a destDir set in the config file."""
        write_config(home, 'destDir = "%s"\n' % (tmp_path / "fromcfg"))
        result = run_chezmoi(["data", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert json.loads(result.stdout)["chezmoi"]["destDir"] == str(tmp_path / "fromcfg")
        result = run_chezmoi(
            ["data", "--source", str(src), "--destination", str(tmp_path / "fromcli")], env=env
        )
        assert result.returncode == 0
        assert json.loads(result.stdout)["chezmoi"]["destDir"] == str(tmp_path / "fromcli")
        # CATCHES: changed command-line flags must be saved and restored around
        # the config read so they win over the config file.

    def test_color_from_config_and_cli(self, home, env):
        """color accepts booleans and bool-ish strings from config and CLI."""
        write_config(home, "color = false\n")
        result, data = dump(env)
        assert data["color"] is False
        write_config(home, 'color = "yes"\n')
        result, data = dump(env)
        assert data["color"] is True
        result, data = dump(env, "--color=false")
        assert data["color"] is False
        # CATCHES: the tri-state (auto/true/false) must marshal as the string
        # "auto" or a JSON boolean, and "yes" must parse as true.

    @pytest.mark.parametrize(
        ("contents", "name", "expected"),
        [
            pytest.param(
                'color = "bogus"\n',
                "chezmoi.toml",
                "chezmoi: invalid config: {path}: decoding failed due to the following "
                "error(s): 'color' strconv.ParseBool: parsing \"bogus\": invalid syntax\n",
                id="bad-bool-string",
            ),
            pytest.param(
                '{"color": 1}\n',
                "chezmoi.json",
                "chezmoi: invalid config: {path}: decoding failed due to the following "
                "error(s): 'color' expected a bool or string, got a int64\n",
                id="bad-bool-int",
            ),
        ],
    )
    def test_color_invalid_values(self, home, env, contents, name, expected):
        """Unparsable color values produce mapstructure decode errors."""
        path = write_config(home, contents, name)
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stderr == expected.format(path=path)
        # CATCHES: the autoBool decoder accepts strings via ParseBool but must
        # reject other types with the exact decode error.

    def test_color_invalid_cli_value(self, home, env):
        """An unparsable --color flag value is a flag error, not a config error."""
        result = run_chezmoi(["dump-config", "--color=weird"], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: invalid argument \"weird\" for \"--color\" flag: "
            "strconv.ParseBool: parsing \"weird\": invalid syntax\n"
        )
        # CATCHES: CLI parsing of autoBool happens in the flag Set method, so
        # the pflag-style error must be produced before any config is read.


class TestDecoding:
    @pytest.mark.parametrize(
        ("contents", "name"),
        [
            pytest.param("[unknown]\n    x = 1\n", "chezmoi.toml", id="toml"),
            pytest.param("unknown:\n    x: 1\n", "chezmoi.yaml", id="yaml"),
            pytest.param("# just a comment\n", "chezmoi.toml", id="comment-only"),
        ],
    )
    def test_unknown_keys_and_comments_ignored(self, home, env, contents, name):
        """Unknown config keys and empty configs are accepted silently."""
        write_config(home, contents, name)
        result, data = dump(env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert data["color"] == "auto"
        assert data["format"] == "json"
        # CATCHES: the decoder must not error on unrecognized keys (no strict
        # mode) and a comment-only file must decode to defaults.

    @pytest.mark.parametrize(
        ("contents", "name", "got"),
        [
            pytest.param("sourceDir = 1\n", "chezmoi.toml", "int64", id="toml"),
            pytest.param('{"sourceDir": 1}\n', "chezmoi.json", "int64", id="json"),
            pytest.param("sourceDir: 1\n", "chezmoi.yaml", "uint64", id="yaml"),
        ],
    )
    def test_wrong_type_error_names_source_type(self, home, env, contents, name, got):
        """A sourceDir of the wrong type names the Go type of the raw value."""
        path = write_config(home, contents, name)
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: invalid config: %s: decoding failed due to the following error(s): "
            "'sourceDir' expected a string, got a %s\n" % (path, got)
        )
        # CATCHES: each format decoder produces different Go integer types
        # (int64 for toml/json, uint64 for yaml) and the error names them.

    def test_json_trailing_garbage_rejected(self, home, env):
        """Extra data after a JSON config object is an error."""
        path = write_config(home, '{"sourceDir": "x"} trailing\n', "chezmoi.json")
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stderr == "chezmoi: invalid config: %s: expected EOF\n" % path
        # CATCHES: the JSON decoder must check for trailing content after the
        # top-level value instead of stopping at the first decode.

    def test_json_top_level_array_rejected(self, home, env):
        """A JSON config that is not an object is an error."""
        path = write_config(home, "[1,2]\n", "chezmoi.json")
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: invalid config: %s: json: cannot unmarshal array into Go value "
            "of type map[string]interface {}\n" % path
        )
        # CATCHES: config files must decode into a map, and the raw json
        # package error must be surfaced verbatim.


class TestTypedSettings:
    def test_umask(self, home, env):
        """umask defaults to the process umask; config values are octal."""
        result, data = dump(env)
        assert data["umask"] == current_umask()
        write_config(home, "umask = 63\n")
        result, data = dump(env)
        assert data["umask"] == 63
        write_config(home, "umask = 0o777\n")
        result, data = dump(env)
        assert data["umask"] == 511
        # CATCHES: umask marshals as a decimal number (0o777 -> 511) and the
        # default is inherited from the process umask.

    def test_umask_string_rejected(self, home, env):
        """A quoted umask cannot be converted to fs.FileMode."""
        path = write_config(home, 'umask = "022"\n')
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: invalid config: %s: decoding failed due to the following error(s): "
            "'umask' expected type 'fs.FileMode', got unconvertible type 'string'\n" % path
        )
        # CATCHES: umask only accepts TOML integers, never strings, and the
        # decode error must name the target Go type.

    def test_mode_flag_invalid(self, home, env):
        """--mode only accepts its registered values."""
        result = run_chezmoi(["dump-config", "--mode", "bogus"], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            'chezmoi: invalid argument "bogus" for "--mode" flag: invalid mode: bogus\n'
        )
        # CATCHES: mode is a choiceFlag whose Set must reject unknown values
        # with the "invalid mode" reason.

    def test_format_config_key_controls_output(self, home, env):
        """format = yaml in the config makes dump-config emit YAML; toml fails."""
        write_config(home, 'format = "yaml"\n')
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 0
        assert result.stdout.startswith("configfile:\n")
        assert "  color: auto\n" in result.stdout
        write_config(home, 'format = "toml"\n')
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stderr == "chezmoi: toml: invalid format\n"
        # CATCHES: the config decoder accepts any format string (choiceFlag
        # hook) but the marshaler only supports json/yaml, so toml fails late.

    def test_git_commit_message_template_conflict(self, home, env):
        """git.commitMessageTemplate and ...File are mutually exclusive."""
        path = write_config(
            home,
            "[git]\n    commitMessageTemplate = \"t\"\n    commitMessageTemplateFile = \"f\"\n",
        )
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: invalid config: %s: cannot specify both git.commitMessageTemplate "
            "and git.commitMessageTemplateFile\n" % path
        )
        # CATCHES: the post-decode validation must run before any command
        # output and name both conflicting keys.

    def test_pager_from_env_and_config(self, home, env, tmp_path):
        """PAGER seeds the default; config pager/pagerArgs override it."""
        env = {**env, "PAGER": "less"}
        result, data = dump(env)
        assert data["pager"] == "less"
        assert data["pagerArgs"] is None
        write_config(home, 'pager = "more"\npagerArgs = ["-r"]\n')
        result, data = dump(env)
        assert data["pager"] == "more"
        assert data["pagerArgs"] == ["-r"]
        # CATCHES: the PAGER environment variable is only a default and the
        # config file wins over it.

    def test_paths_expand_tilde_and_relative(self, home, env, src, tmp_path):
        """~ expands to HOME; relative paths resolve against the cwd."""
        write_config(home, 'sourceDir = "~/src"\n')
        result = run_chezmoi(["data"], env=env, cwd=tmp_path)
        assert json.loads(result.stdout)["chezmoi"]["sourceDir"] == str(home / "src")
        write_config(home, 'sourceDir = "rel"\n')
        cwd = tmp_path / "cwd"
        cwd.mkdir()
        result = run_chezmoi(["data"], env=env, cwd=cwd)
        assert json.loads(result.stdout)["chezmoi"]["sourceDir"] == str(cwd / "rel")
        result = run_chezmoi(["data", "--source", "~/s2"], env=env, cwd=tmp_path)
        assert json.loads(result.stdout)["chezmoi"]["sourceDir"] == str(home / "s2")
        # CATCHES: tilde expansion applies to config strings and flag values
        # alike, and relative values resolve against the working directory.

    def test_cache_and_working_tree_from_config_and_cli(self, home, env, src, tmp_path):
        """cacheDir/workingTree are settable from config and --cache/--working-tree."""
        write_config(home, 'cacheDir = "~/mycache"\nworkingTree = "~/mywt"\n')
        result = run_chezmoi(["data", "--source", str(src)], env=env)
        chezmoi = json.loads(result.stdout)["chezmoi"]
        assert chezmoi["cacheDir"] == str(home / "mycache")
        assert chezmoi["workingTree"] == str(home / "mywt")
        result = run_chezmoi(
            [
                "data",
                "--source",
                str(src),
                "--cache",
                str(tmp_path / "c2"),
                "--working-tree",
                str(tmp_path / "w2"),
            ],
            env=env,
        )
        chezmoi = json.loads(result.stdout)["chezmoi"]
        assert chezmoi["cacheDir"] == str(tmp_path / "c2")
        assert chezmoi["workingTree"] == str(tmp_path / "w2")
        # CATCHES: both settings flow into the template data and the CLI flags
        # override the config file.

    def test_persistent_state_flag(self, home, env, tmp_path):
        """--persistent-state is reflected in dump-config output."""
        result, data = dump(env, "--persistent-state", str(tmp_path / "p2"))
        assert data["persistentState"] == str(tmp_path / "p2")
        # CATCHES: the persistent state path is configurable and marshals as a
        # plain string (empty by default).


class TestCompoundSettings:
    def test_interpreters_defaults_and_override(self, home, env):
        """Interpreter defaults are builtin; config can override one entry."""
        result, data = dump(env)
        assert data["interpreters"] == {
            "bat": {"command": "", "args": None},
            "cmd": {"command": "", "args": None},
            "com": {"command": "", "args": None},
            "exe": {"command": "", "args": None},
            "nu": {"command": "nu", "args": None},
            "pl": {"command": "perl", "args": None},
            "ps1": {"command": "", "args": None},
            "py": {"command": "python3", "args": None},
            "rb": {"command": "ruby", "args": None},
        }
        write_config(home, '[interpreters]\n    py = { command = "python2" }\n')
        result, data = dump(env)
        assert data["interpreters"]["py"] == {"command": "python2", "args": None}
        assert data["interpreters"]["pl"] == {"command": "perl", "args": None}
        # CATCHES: overriding one interpreter must not clobber the others, and
        # unset commands serialize as empty strings with null args.

    def test_template_options_override(self, home, env):
        """template.options defaults to missingkey=error and is overridable."""
        result, data = dump(env)
        assert data["template"] == {"options": ["missingkey=error"]}
        write_config(home, '[template]\n    options = ["missingkey=zero"]\n')
        result, data = dump(env)
        assert data["template"] == {"options": ["missingkey=zero"]}
        # CATCHES: template options are a list setting that replaces (not
        # appends to) the default.

    def test_use_builtin_age_git(self, home, env):
        """useBuiltinAge/useBuiltinGit accept bools and bool-ish strings."""
        write_config(home, "useBuiltinGit = false\nuseBuiltinAge = true\n")
        result, data = dump(env)
        assert data["useBuiltinAge"] is True
        assert data["useBuiltinGit"] is False
        path = write_config(home, 'useBuiltinAge = "bogus"\n')
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: invalid config: %s: decoding failed due to the following error(s): "
            "'useBuiltinAge' strconv.ParseBool: parsing \"bogus\": invalid syntax\n" % path
        )
        # CATCHES: these are autoBool settings like color, so they accept the
        # same value forms and fail with the same decode error.

    def test_hooks_and_textconv_shape(self, home, env):
        """Hooks and textConv decode into their documented nested shapes."""
        write_config(home, "[hooks]\n    apply = { pre = { command = \"echo\" } }\n")
        result, data = dump(env)
        assert data["hooks"] == {
            "apply": {
                "pre": {"command": "echo", "script": "", "args": None},
                "post": {"command": "", "script": "", "args": None},
            }
        }
        write_config(home, '[[textConv]]\n    pattern = ".*"\n    command = "echo"\n')
        result, data = dump(env)
        assert data["textConv"] == [{"pattern": ".*", "command": "echo", "args": None}]
        # CATCHES: partially-specified hook entries must fill in empty
        # post-command structures, and textConv is an array of tables.
