"""Error values surfaced through the CLI: version files, file types, source names.

These exercise the error types in internal/chezmoi/errors.go (TooOldError's
version-file parsing, UnsupportedFileTypeError, InvalidPathError and
InconsistentStateError) as they reach the user, including the file mode type
names that UnsupportedFileTypeError borrows from chezmoi.FileModeTypeNames.
"""

from __future__ import annotations

import os
import socket
import stat

import pytest

from conftest import run_chezmoi


class TestVersionFile:
    def test_invalid_version_file_rejected_by_init(self, home, env, src):
        """init fails when .chezmoiversion is not a dotted-tri version."""
        (src / ".git").mkdir(exist_ok=True)
        (src / ".chezmoiversion").write_text("bogus\n")
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: %s: "bogus\\n": bogus is not in dotted-tri format\n' % (src / ".chezmoiversion")
        )
        # CATCHES: the raw file bytes are shown with Go %q escaping (the
        # newline appears as \n) and the underlying semver complaint is
        # appended verbatim.

    @pytest.mark.parametrize("command", ["apply", "data"], ids=["apply", "data"])
    def test_invalid_version_file_rejected_by_apply_and_data(self, home, env, src, command):
        """apply and data both refuse a source state with a bad .chezmoiversion."""
        (src / ".chezmoiversion").write_text("oops\n")
        result = run_chezmoi([command, "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: %s: "oops\\n": oops is not in dotted-tri format\n' % (src / ".chezmoiversion")
        )
        # CATCHES: the version file is parsed while reading the source state,
        # so even the read-only data command fails before printing anything.

    def test_future_version_not_enforced(self, home, env, src):
        """A .chezmoiversion newer than the binary is accepted, not rejected."""
        (src / ".chezmoiversion").write_text("99.0.0\n")
        (src / "dot_file.txt").write_text("content\n")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert (home / ".file.txt").read_text() == "content\n"
        # CATCHES: this build reports no version, so the "source state requires
        # chezmoi version X or later" check is skipped entirely instead of
        # failing the apply.

    def test_version_file_whitespace_trimmed(self, home, env, src):
        """Leading and trailing whitespace in .chezmoiversion is ignored."""
        (src / ".chezmoiversion").write_text("  1.2.3  \n")
        (src / "dot_file.txt").write_text("content\n")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert (home / ".file.txt").read_text() == "content\n"
        # CATCHES: the version string is trimmed before parsing, so padded
        # whitespace must not produce a dotted-tri format error and the source
        # state is still applied.


class TestUnsupportedFileTypes:
    def test_fifo_in_source_dir_rejected(self, home, env, src):
        """A named pipe in the source directory aborts the apply."""
        os.mkfifo(src / "dot_fifo")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: %s: unsupported file type named pipe\n" % (src / "dot_fifo")
        # CATCHES: special files are reported with their source path and the
        # mode type name ("named pipe"), not skipped or treated as regular
        # files.

    def test_fifo_in_dest_dir_rejected(self, home, env, src):
        """A named pipe in the destination directory aborts the apply."""
        (src / "dot_target").write_text("content\n")
        os.mkfifo(home / ".target")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .target: %s: unsupported file type named pipe\n" % (home / ".target")
        )
        # CATCHES: the actual-state error names both the target-relative path
        # and the absolute destination path before the file type.


    def test_socket_in_source_dir_rejected(self, home, env, src):
        """A unix socket in the source directory aborts the apply."""
        sock = socket.socket(socket.AF_UNIX)
        sock.bind(str(src / "dot_sock"))
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: %s: unsupported file type socket\n" % (src / "dot_sock")
        # CATCHES: a socket is reported with the mode type name "socket",
        # distinct from the "named pipe" name used for fifos.

    def test_socket_at_managed_target_rejected(self, home, env, src):
        """A unix socket where a managed file should be aborts the apply."""
        (src / "dot_target").write_text("content\n")
        sock = socket.socket(socket.AF_UNIX)
        sock.bind(str(home / ".target"))
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .target: %s: unsupported file type socket\n" % (home / ".target")
        )
        # CATCHES: the actual state of a managed target must be a file, so a
        # socket there fails with the target-relative path first, then the
        # absolute path, then the type name.

    @pytest.mark.parametrize(
        ("kind", "name"),
        [pytest.param("fifo", ".unmanaged-fifo", id="fifo"), pytest.param("socket", ".unmanaged-sock", id="socket")],
    )
    def test_special_files_at_unmanaged_dest_paths_are_ignored(self, home, env, src, kind, name):
        """Special files that chezmoi does not manage are left alone."""
        (src / "dot_file.txt").write_text("content\n")
        if kind == "fifo":
            os.mkfifo(home / name)
        else:
            sock = socket.socket(socket.AF_UNIX)
            sock.bind(str(home / name))
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        mode = os.stat(home / name).st_mode
        assert (stat.S_ISFIFO(mode) if kind == "fifo" else stat.S_ISSOCK(mode))
        assert (home / ".file.txt").read_text() == "content\n"
        # CATCHES: the destination directory is not scanned for special files
        # in general, only the paths that are actually managed, so an
        # unrelated fifo or socket neither fails the apply nor is removed.


class TestInvalidSourceNames:
    def test_empty_target_name_rejected(self, home, env, src):
        """A source entry whose target name is empty is an invalid path."""
        (src / "dot_").write_text("content\n")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: dot_: invalid path\n"
        # CATCHES: the dot_ attribute with nothing after it leaves an empty
        # target name, which must fail with the source name and "invalid path".

    def test_inconsistent_state_rejected(self, home, env, src):
        """Two source entries for the same target are an inconsistent state."""
        (src / "dot_x").write_text("a\n")
        (src / "create_dot_x").write_text("b\n")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .x: inconsistent state (%s, %s)\n"
            % (src / "create_dot_x", src / "dot_x")
        )
        # CATCHES: the message names the target path and the sorted origin
        # source paths of every entry mapping to it, joined with ", ".
