"""The persistent state as seen through `chezmoi state dump` and `state get`.

These pin the marshaling of chezmoi.HexBytes (internal/chezmoi/hexbytes.go):
the contentsSHA256 of every entry and the configTemplateContentsSHA256 of the
config state are lowercase hex strings in JSON and bare scalars in YAML, and a
zero-length hash is omitted entirely.
"""

from __future__ import annotations

import hashlib
import json

import pytest

from conftest import current_umask, run_chezmoi, write_config

# A umask that differs from the usual 0o022 so that the recorded modes prove
# that the config file's umask reaches the persistent state.
UMASK = "0o077"
FILE_MODE = 0o666 & ~0o077
DIR_MODE = (1 << 31) | (0o777 & ~0o077)


def sha256_hex(data):
    """Return the lowercase hex SHA-256 of data, as chezmoi stores it."""
    return hashlib.sha256(data).hexdigest()


def state_dump(env, src, fmt="json"):
    """Run `chezmoi state dump` and return the parsed state."""
    args = ["state", "dump", "--source", str(src)]
    if fmt != "json":
        args += ["--format", fmt]
    result = run_chezmoi(args, env=env)
    assert result.returncode == 0
    return result


def entry_state(env, src):
    """Return the entryState bucket of the persistent state."""
    return json.loads(state_dump(env, src).stdout)["entryState"]


@pytest.fixture
def umask_config(home):
    """A config file that pins the umask to 0o077."""
    write_config(home, "umask = %s\n" % UMASK)
    return home


class TestEntryStateHashes:
    def test_file_entry_hash_and_mode(self, home, env, src, umask_config):
        """A file entry stores the SHA-256 of its contents and its mode."""
        (src / "dot_file.txt").write_text("content\n")
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert entry_state(env, src) == {
            "%s/.file.txt" % home: {
                "contentsSHA256": sha256_hex(b"content\n"),
                "mode": FILE_MODE,
                "type": "file",
            }
        }
        # CATCHES: the stored hash is the plain lowercase hex SHA-256 of the
        # target contents (not of the source file, not base64) and the stored
        # mode is the permission bits after the config umask, as a decimal
        # number.

    def test_yaml_hash_is_a_bare_scalar(self, home, env, src, umask_config):
        """In YAML the hash is an unquoted scalar, not a quoted string."""
        (src / "dot_file.txt").write_text("content\n")
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        result = state_dump(env, src, "yaml")
        assert "    contentsSHA256: %s\n" % sha256_hex(b"content\n") in result.stdout
        assert '"%s"' % sha256_hex(b"content\n") not in result.stdout
        assert json.loads(state_dump(env, src).stdout)["entryState"][
            "%s/.file.txt" % home
        ]["contentsSHA256"] == sha256_hex(b"content\n")
        # CATCHES: the same hash is marshaled as a bare scalar in YAML and as
        # a JSON string, so the two formats agree on the value.

    def test_dir_entry_has_no_hash(self, home, env, src, umask_config):
        """A directory entry stores only its mode, with the ModeDir bit."""
        (src / "dot_dir").mkdir()
        (src / "dot_dir" / "dot_inner").write_text("x\n")
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert entry_state(env, src)["%s/.dir" % home] == {
            "mode": DIR_MODE,
            "type": "dir",
        }
        # CATCHES: a directory has no contents hash at all (an empty hash is
        # omitted, not written as an empty string) and its mode has the Go
        # ModeDir bit set on top of the permission bits.

    def test_symlink_entry_hash_is_the_linkname_hash(self, home, env, src, umask_config):
        """A symlink entry stores the SHA-256 of the linkname, and no mode."""
        (src / "symlink_dot_link").write_text("/tmp/target\n")
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert entry_state(env, src) == {
            "%s/.link" % home: {
                "contentsSHA256": sha256_hex(b"/tmp/target"),
                "type": "symlink",
            }
        }
        assert (home / ".link").is_symlink()
        # CATCHES: the symlink's hash is taken over the linkname with the
        # surrounding whitespace of the source entry trimmed, and a symlink
        # entry has no mode key.

    def test_empty_prefix_file_hash_is_the_empty_hash(self, home, env, src, umask_config):
        """An empty_ file keeps its target and stores the SHA-256 of nothing."""
        (src / "empty_dot_empty").write_text("")
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert entry_state(env, src) == {
            "%s/.empty" % home: {
                "contentsSHA256": sha256_hex(b""),
                "mode": FILE_MODE,
                "type": "file",
            }
        }
        assert (home / ".empty").exists()
        assert (home / ".empty").read_text() == ""
        # CATCHES: the empty_ attribute changes the meaning of empty contents
        # from "remove the target" to "create an empty file", whose hash is
        # the SHA-256 of the empty string.

    def test_empty_contents_without_empty_prefix_removes_the_target(
        self, home, env, src, umask_config
    ):
        """A source file with empty contents and no empty_ prefix removes."""
        (src / "dot_gone.txt").write_text("")
        (home / ".gone.txt").write_text("old contents\n")
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert not (home / ".gone.txt").exists()
        assert entry_state(env, src) == {"%s/.gone.txt" % home: {"type": "remove"}}
        # CATCHES: empty contents mean "absent" unless the empty_ attribute is
        # set, so the target is deleted and the entry state records a remove
        # with neither a hash nor a mode.

    def test_script_state_is_keyed_by_the_content_hash(self, home, env, src):
        """A run_once script is recorded under the SHA-256 of its contents."""
        script = "#!/bin/sh\necho hi\n"
        (src / "run_once_install.sh").write_text(script)
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        state = json.loads(state_dump(env, src).stdout)
        assert list(state["scriptState"]) == [sha256_hex(script.encode())]
        assert state["scriptState"][sha256_hex(script.encode())]["name"] == "install.sh"
        assert state["entryState"]["%s/install.sh" % home] == {
            "contentsSHA256": sha256_hex(script.encode()),
            "type": "script",
        }
        # CATCHES: the scriptState bucket is keyed by the hex SHA-256 of the
        # script contents (so two run_once scripts with identical contents run
        # only once) and the entry state repeats that hash with type "script".


class TestConfigState:
    def test_config_state_hash_via_state_get(self, home, env, src):
        """`state get` prints the config state as indented JSON."""
        template = 'sourceDir = "/v1"\n'
        (src / ".chezmoi.toml.tmpl").write_text(template)
        assert run_chezmoi(["init", "--source", str(src)], env=env).returncode == 0
        result = run_chezmoi(
            ["state", "get", "--bucket", "configState", "--key", "configState",
             "--source", str(src)],
            env=env,
        )
        assert result.returncode == 0
        assert result.stdout == (
            '{\n  "configTemplateContentsSHA256": "%s"\n}\n'
            % sha256_hex(template.encode())
        )
        # CATCHES: the configState bucket holds the hex SHA-256 of the raw
        # template bytes under the key configState, pretty printed with
        # two-space indentation.

    def test_config_state_hash_in_yaml_dump(self, home, env, src):
        """The config state hash is also a bare scalar in YAML."""
        template = 'sourceDir = "/v1"\n'
        (src / ".chezmoi.toml.tmpl").write_text(template)
        assert run_chezmoi(["init", "--source", str(src)], env=env).returncode == 0
        result = state_dump(env, src, "yaml")
        assert (
            "  configTemplateContentsSHA256: %s\n" % sha256_hex(template.encode())
            in result.stdout
        )
        # CATCHES: the same HexBytes value is written unquoted in the YAML
        # dump of the persistent state.

class TestCorruptState:
    def state_set(self, env, src, key, value):
        """Store a raw value in the entryState bucket."""
        result = run_chezmoi(
            ["state", "set", "--bucket", "entryState", "--key", key,
             "--value", value, "--source", str(src)],
            env=env,
        )
        assert result.returncode == 0

    def test_non_hex_hash_in_entry_state_is_an_error(self, home, env, src):
        """A contentsSHA256 that is not hexadecimal aborts apply and status."""
        (src / "dot_file.txt").write_text("content\n")
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        self.state_set(
            env, src, "%s/.file.txt" % home,
            '{"contentsSHA256":"zz","mode":420,"type":"file"}',
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .file.txt: encoding/hex: invalid byte: U+007A 'z'\n"
        )
        result = run_chezmoi(["status", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            "chezmoi: .file.txt: encoding/hex: invalid byte: U+007A 'z'\n"
        )
        # CATCHES: the stored hash is decoded as hexadecimal when the entry
        # state is read back, and a non-hex value is reported with the target
        # path and Go's encoding/hex error, not silently ignored.

    def test_empty_hash_in_entry_state_is_repaired(self, home, env, src):
        """An empty contentsSHA256 is accepted and rewritten by the next apply."""
        (src / "dot_file.txt").write_text("content\n")
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        self.state_set(
            env, src, "%s/.file.txt" % home,
            '{"contentsSHA256":"","mode":420,"type":"file"}',
        )
        assert entry_state(env, src)["%s/.file.txt" % home]["contentsSHA256"] == ""
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert entry_state(env, src) == {
            "%s/.file.txt" % home: {
                "contentsSHA256": sha256_hex(b"content\n"),
                "mode": 0o666 & ~current_umask(),
                "type": "file",
            }
        }
        # CATCHES: an empty hash decodes to no hash at all instead of failing,
        # so the entry is treated as not yet recorded and the next apply
        # rewrites it with the real hash.

    def test_state_get_of_a_missing_key_is_not_destructive(self, home, env, src):
        """Reading a missing key prints nothing and keeps the state."""
        template = 'sourceDir = "/v1"\n'
        (src / ".chezmoi.toml.tmpl").write_text(template)
        assert run_chezmoi(["init", "--source", str(src)], env=env).returncode == 0
        result = run_chezmoi(
            ["state", "get", "--bucket", "nope", "--key", "nope", "--source", str(src)],
            env=env,
        )
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        state = json.loads(state_dump(env, src).stdout)
        assert state["configState"]["configState"] == {
            "configTemplateContentsSHA256": sha256_hex(template.encode())
        }
        # CATCHES: a missing bucket or key is not an error and does not reset
        # or rewrite the persistent state database.
