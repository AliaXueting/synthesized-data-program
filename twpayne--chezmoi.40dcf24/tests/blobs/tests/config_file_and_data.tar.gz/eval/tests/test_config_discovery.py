"""Config file discovery: XDG search order, format detection, and --config."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from conftest import child_env, run_chezmoi, write_config


def data_with(env, source, *extra):
    """Run `chezmoi data` and return the parsed chezmoi map."""
    result = run_chezmoi(["data", "--source", str(source), *extra], env=env)
    assert result.returncode == 0
    return json.loads(result.stdout)["chezmoi"]


def data_env(env, *args):
    """Run `chezmoi data` with explicit arguments and return the chezmoi map."""
    result = run_chezmoi(["data", *args], env=env)
    assert result.returncode == 0
    return json.loads(result.stdout)["chezmoi"]


def put_config(base: Path, name: str, contents: str) -> Path:
    d = base / "chezmoi"
    d.mkdir(parents=True, exist_ok=True)
    path = d / name
    path.write_text(contents)
    return path


class TestDefaultLocation:
    def test_default_config_file_is_home_config_chezmoi_toml(self, home, env, src):
        """With no config file anywhere, the default config path is used silently."""
        chezmoi = data_with(env, src)
        assert chezmoi["configFile"] == str(home / ".config" / "chezmoi" / "chezmoi.toml")
        # CATCHES: the fallback filename must be chezmoi.toml (not .json/.yaml) and
        # a missing config file must not be an error.

    def test_config_found_in_xdg_config_home(self, home, tmp_path):
        """A config file in XDG_CONFIG_HOME is read and its settings applied."""
        put_config(tmp_path / "xdg", "chezmoi.toml", 'sourceDir = "%s"\n' % (tmp_path / "xdgsrc"))
        env = child_env(home, tmpdir=tmp_path / "tmp", XDG_CONFIG_HOME=str(tmp_path / "xdg"))
        chezmoi = data_env(env)
        assert chezmoi["configFile"] == str(tmp_path / "xdg" / "chezmoi" / "chezmoi.toml")
        assert chezmoi["sourceDir"] == str(tmp_path / "xdgsrc")
        # CATCHES: XDG_CONFIG_HOME replaces the ~/.config default entirely, and
        # the file found there is actually parsed (sourceDir comes from it).

    def test_cli_source_flag_beats_config_file(self, home, tmp_path):
        """A --source flag overrides the sourceDir found in the config file."""
        put_config(tmp_path / "xdg", "chezmoi.toml", 'sourceDir = "%s"\n' % (tmp_path / "fromconfig"))
        env = child_env(home, tmpdir=tmp_path / "tmp", XDG_CONFIG_HOME=str(tmp_path / "xdg"))
        chezmoi = data_env(env, "--source", str(tmp_path / "fromflag"))
        assert chezmoi["configFile"] == str(tmp_path / "xdg" / "chezmoi" / "chezmoi.toml")
        assert chezmoi["sourceDir"] == str(tmp_path / "fromflag")
        # CATCHES: the flag value the user actually passed is restored after
        # the config file is decoded, so the CLI wins over the config file
        # even though the config file was found and parsed.

    def test_config_format_from_extension_json(self, home, tmp_path):
        """A .json config file in XDG_CONFIG_HOME is parsed as JSON."""
        put_config(
            tmp_path / "xdg",
            "chezmoi.json",
            json.dumps({"sourceDir": str(tmp_path / "jsonsrc")}) + "\n",
        )
        env = child_env(home, tmpdir=tmp_path / "tmp", XDG_CONFIG_HOME=str(tmp_path / "xdg"))
        chezmoi = data_env(env)
        assert chezmoi["configFile"] == str(tmp_path / "xdg" / "chezmoi" / "chezmoi.json")
        assert chezmoi["sourceDir"] == str(tmp_path / "jsonsrc")
        # CATCHES: the config parser is selected by file extension, so a .json
        # file must be accepted wherever chezmoi.toml would be.


class TestXDGConfigDirs:
    def test_first_matching_dir_wins(self, home, tmp_path):
        """Only the first XDG_CONFIG_DIRS entry containing a config is used."""
        put_config(tmp_path / "d1", "chezmoi.toml", 'sourceDir = "%s"\n' % (tmp_path / "one"))
        put_config(tmp_path / "d2", "chezmoi.toml", 'sourceDir = "%s"\n' % (tmp_path / "two"))
        env = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            XDG_CONFIG_DIRS="%s:%s" % (tmp_path / "d1", tmp_path / "d2"),
        )
        chezmoi = data_env(env)
        assert chezmoi["configFile"] == str(tmp_path / "d1" / "chezmoi" / "chezmoi.toml")
        assert chezmoi["sourceDir"] == str(tmp_path / "one")
        # CATCHES: XDG_CONFIG_DIRS is searched front-to-back and later entries
        # are never merged or preferred.

    def test_empty_dir_falls_through_to_next(self, home, tmp_path):
        """A config dir without a config file is skipped, not an error."""
        (tmp_path / "d1").mkdir()
        put_config(tmp_path / "d2", "chezmoi.toml", 'sourceDir = "%s"\n' % (tmp_path / "two"))
        env = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            XDG_CONFIG_DIRS="%s:%s" % (tmp_path / "d1", tmp_path / "d2"),
        )
        chezmoi = data_env(env)
        assert chezmoi["configFile"] == str(tmp_path / "d2" / "chezmoi" / "chezmoi.toml")
        assert chezmoi["sourceDir"] == str(tmp_path / "two")
        # CATCHES: a directory in XDG_CONFIG_DIRS with no chezmoi config must
        # be skipped so later directories are still considered.

    def test_config_home_beats_config_dirs(self, home, tmp_path):
        """XDG_CONFIG_HOME takes precedence over XDG_CONFIG_DIRS."""
        put_config(tmp_path / "xdg", "chezmoi.toml", 'sourceDir = "%s"\n' % (tmp_path / "fromhome"))
        put_config(tmp_path / "d2", "chezmoi.toml", 'sourceDir = "%s"\n' % (tmp_path / "fromdirs"))
        env = child_env(
            home,
            tmpdir=tmp_path / "tmp",
            XDG_CONFIG_HOME=str(tmp_path / "xdg"),
            XDG_CONFIG_DIRS=str(tmp_path / "d2"),
        )
        chezmoi = data_env(env)
        assert chezmoi["configFile"] == str(tmp_path / "xdg" / "chezmoi" / "chezmoi.toml")
        assert chezmoi["sourceDir"] == str(tmp_path / "fromhome")
        # CATCHES: the search must try XDG_CONFIG_HOME before XDG_CONFIG_DIRS.


class TestAmbiguity:
    @pytest.mark.parametrize(
        ("names", "expected"),
        [
            (
                ["chezmoi.json", "chezmoi.toml"],
                "{json} and {toml}",
            ),
            (
                ["chezmoi.json", "chezmoi.toml", "chezmoi.yaml"],
                "{json}, {toml}, and {yaml}",
            ),
        ],
        ids=["two-formats", "three-formats"],
    )
    def test_multiple_config_files_rejected(self, home, env, names, expected):
        """Two or more config formats in one directory are a hard error."""
        config_dir = home / ".config" / "chezmoi"
        config_dir.mkdir(parents=True)
        paths = {}
        for name in names:
            path = config_dir / name
            path.write_text('sourceDir = "/x"\n' if name.endswith("toml") else "{}\n")
            paths[name.split(".")[1]] = str(path)
        result = run_chezmoi(["dump-config"], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: multiple config files: %s\n" % (
            expected.format(**paths)
        )
        # CATCHES: the extension scan order (json before toml before yaml) and
        # the Oxford-comma listing must match exactly.


class TestConfigFlag:
    def test_config_flag_replaces_search(self, home, env, tmp_path):
        """--config bypasses the search and uses the given file."""
        write_config(home, 'sourceDir = "%s"\n' % (tmp_path / "fromdefault"))
        custom = tmp_path / "custom.toml"
        custom.write_text('sourceDir = "%s"\n' % (tmp_path / "fromcustom"))
        result = run_chezmoi(["data", "--config", str(custom)], env=env)
        assert result.returncode == 0
        chezmoi = json.loads(result.stdout)["chezmoi"]
        assert chezmoi["configFile"] == str(custom)
        assert chezmoi["sourceDir"] == str(tmp_path / "fromcustom")
        # CATCHES: --config replaces discovery entirely: the config file found
        # at the default location is ignored even though it exists and parses.

    def test_missing_config_flag_file_is_not_an_error(self, home, env, src):
        """A --config path that does not exist yields defaults, not an error."""
        missing = home / "nope.toml"
        result = run_chezmoi(["data", "--source", str(src), "--config", str(missing)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        chezmoi = json.loads(result.stdout)["chezmoi"]
        assert chezmoi["configFile"] == str(missing)
        assert chezmoi["sourceDir"] == str(src)
        # CATCHES: a missing explicit config file is silently ignored but still
        # reported as the config file path.

    def test_unknown_extension_rejected(self, home, env):
        """--config with an unparseable extension is an invalid config."""
        path = home / "x.ini"
        path.write_text("x = 1\n")
        result = run_chezmoi(["dump-config", "--config", str(path)], env=env)
        assert result.returncode == 1
        assert result.stderr == "chezmoi: invalid config: %s: .ini: unknown format\n" % path
        # CATCHES: the format registry must reject unknown extensions instead
        # of guessing or ignoring the file.

    def test_directory_as_config_rejected(self, home, env):
        """--config pointing at a directory produces an unknown format error."""
        result = run_chezmoi(["dump-config", "--config", str(home)], env=env)
        assert result.returncode == 1
        assert result.stderr == "chezmoi: invalid config: %s: : unknown format\n" % home
        # CATCHES: a directory has an empty extension which must surface as an
        # "unknown format" error, not a crash or silent success.


class TestConfigFormat:
    @pytest.mark.parametrize(
        ("flag", "config_name", "config_contents", "expected_stderr"),
        [
            pytest.param(
                "toml",
                "chezmoi.json",
                '{"sourceDir": "/tmp/fromjson"}\n',
                'chezmoi: invalid config: {path}: toml: line 1: expected \'.\' or \'=\', '
                "but got '{' instead\n",
                id="toml-on-json",
            ),
            pytest.param(
                "t",
                "chezmoi.json",
                '{"sourceDir": "/tmp/fromjson"}\n',
                'chezmoi: invalid config: {path}: toml: line 1: expected \'.\' or \'=\', '
                "but got '{' instead\n",
                id="t-abbreviation",
            ),
            pytest.param(
                "yaml",
                "chezmoi.toml",
                'sourceDir = "/fromtoml"\n',
                'chezmoi: invalid config: {path}: [1:1] string was used where mapping is '
                'expected\n>  1 | sourceDir = "/fromtoml"\n       ^\n\n',
                id="yaml-on-toml",
            ),
            pytest.param(
                "ya",
                "chezmoi.toml",
                'sourceDir = "/fromtoml"\n',
                'chezmoi: invalid config: {path}: [1:1] string was used where mapping is '
                'expected\n>  1 | sourceDir = "/fromtoml"\n       ^\n\n',
                id="ya-abbreviation",
            ),
            pytest.param(
                "json",
                "chezmoi.toml",
                'sourceDir = "/fromtoml"\n',
                "chezmoi: invalid config: {path}: invalid character 's' looking for "
                "beginning of value\n",
                id="json-on-toml",
            ),
            pytest.param(
                "j",
                "chezmoi.toml",
                'sourceDir = "/fromtoml"\n',
                "chezmoi: invalid config: {path}: invalid character 's' looking for "
                "beginning of value\n",
                id="j-abbreviation",
            ),
        ],
    )
    def test_format_overrides_extension(
        self, home, env, flag, config_name, config_contents, expected_stderr
    ):
        """--config-format forces the parser regardless of file extension."""
        path = write_config(home, config_contents, config_name)
        result = run_chezmoi(["dump-config", "--config-format", flag], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == expected_stderr.replace("{path}", str(path))
        # CATCHES: the flag must select the parser (toml/yaml/json, with
        # unambiguous prefixes t/ya/j) and each parser's distinct error text
        # must surface, including the YAML source-context annotation.

    def test_empty_format_infers_from_extension(self, home, env, tmp_path):
        """--config-format '' falls back to extension-based detection."""
        write_config(
            home,
            json.dumps({"sourceDir": str(tmp_path / "inferred")}) + "\n",
            "chezmoi.json",
        )
        result = run_chezmoi(["data", "--config-format", ""], env=env)
        assert result.returncode == 0
        chezmoi = json.loads(result.stdout)["chezmoi"]
        assert chezmoi["configFile"] == str(home / ".config" / "chezmoi" / "chezmoi.json")
        assert chezmoi["sourceDir"] == str(tmp_path / "inferred")
        # CATCHES: the empty string must disable the override so the .json
        # extension is honored again.

    @pytest.mark.parametrize("value", ["jsonc", "yml", "YA"])
    def test_invalid_format_value_rejected(self, home, env, value):
        """Unsupported --config-format values are rejected by the flag parser."""
        result = run_chezmoi(["dump-config", "--config-format", value], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            'chezmoi: invalid argument "%s" for "--config-format" flag: invalid value\n' % value
        )
        # CATCHES: only json/toml/yaml (and prefixes) are accepted; jsonc, yml
        # and case-mismatched values must fail with the pflag error text.
