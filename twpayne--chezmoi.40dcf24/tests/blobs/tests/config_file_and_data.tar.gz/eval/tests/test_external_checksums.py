"""HexBytes end to end: .chezmoiexternal checksums and run_onchange scripts.

These exercise internal/chezmoi/hexbytes.go through the CLI. The checksum
fields of `.chezmoiexternal` files are HexBytes, decoded by every format
(goccy YAML through UnmarshalYAML, JSON/JSONC/TOML through UnmarshalText) and
rendered back with String in the mismatch reports. run_onchange scripts
compare the stored entry state hash with the current one through Bytes.
`file://` URLs keep everything hermetic: chezmoi always reads them from disk,
never from the network or the external cache.
"""

from __future__ import annotations

import hashlib
import io
import json
import tarfile

import pytest

from conftest import run_chezmoi

PAYLOAD = b"payload contents\n"

# RIPEMD-160 of the empty string. The reference computes
# ripemd160.New().Sum(data) without writing anything to the hash, so the
# digest it reports is the downloaded data itself followed by this constant.
RIPEMD160_OF_EMPTY = "9c1185a5c5e9fc54612808977ee8f548b2258d31"

SECURE_ALGS = {
    "sha256": hashlib.sha256,
    "sha384": hashlib.sha384,
    "sha512": hashlib.sha512,
}

ARCHIVE_MEMBER = b"hello from archive\n"


def file_url(path) -> str:
    """Return the file:// URL for path."""
    return "file://" + str(path)


def write_external(src, body, name=".chezmoiexternal.yaml"):
    """Write a .chezmoiexternal file and return its path."""
    path = src / name
    path.write_text(body)
    return path


def external_yaml(target, url, checksums):
    """Build a .chezmoiexternal.yaml body for one external of type file.

    checksums is a list of (key, rendered-value) pairs so that multi-checksum
    files keep a deterministic order.
    """
    lines = ['"%s":' % target, "    type: file", "    url: %s" % url, "    checksum:"]
    for key, value in checksums:
        lines.append("        %s: %s" % (key, value))
    return "\n".join(lines) + "\n"


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def entry_state(env, src) -> dict:
    """Return the entryState bucket after a successful state dump."""
    result = run_chezmoi(["state", "dump", "--source", str(src)], env=env)
    assert result.returncode == 0
    return json.loads(result.stdout)["entryState"]


@pytest.fixture
def payload(tmp_path):
    """A local file that externals download through a file:// URL."""
    path = tmp_path / "payload.txt"
    path.write_bytes(PAYLOAD)
    return path


class TestRunOnChangeScripts:
    def test_run_onchange_runs_once_until_the_contents_change(self, home, env, src):
        """A run_onchange script reruns only when its contents change."""
        contents = '#!/bin/sh\necho run >> "$HOME/oneshot.log"\n'
        script = src / "run_onchange_thing.sh"
        script.write_text(contents)
        script.chmod(0o755)
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert (home / "oneshot.log").read_text() == "run\n"
        state = entry_state(env, src)
        assert state["%s/thing.sh" % home] == {
            "contentsSHA256": sha256_hex(contents.encode()),
            "type": "script",
        }
        # The stored hash equals the current hash: the script is skipped.
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert (home / "oneshot.log").read_text() == "run\n"
        # New contents mean a new hash, so the script runs again.
        contents += "# changed\n"
        script.write_text(contents)
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert (home / "oneshot.log").read_text() == "run\nrun\n"
        assert (
            entry_state(env, src)["%s/thing.sh" % home]["contentsSHA256"]
            == sha256_hex(contents.encode())
        )
        # CATCHES: the skip decision decodes the stored entry state and
        # compares its contentsSHA256 (as raw bytes) with the SHA-256 of the
        # current script contents, so the script reruns exactly when the
        # contents hash changes, not on every apply.

    def test_identical_run_onchange_scripts_run_independently(self, home, env, src):
        """Two run_onchange scripts with identical contents each run once."""
        contents = '#!/bin/sh\necho run >> "$HOME/twice.log"\n'
        for name in ("run_onchange_a.sh", "run_onchange_b.sh"):
            script = src / name
            script.write_text(contents)
            script.chmod(0o755)
        for _ in range(2):
            assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        assert (home / "twice.log").read_text() == "run\nrun\n"
        # CATCHES: run_onchange state is keyed by the script's target path
        # (a.sh and b.sh), unlike run_once which is keyed by the SHA-256 of
        # the contents, so identical scripts do not swallow each other's run.


class TestChecksumDecoding:
    @pytest.mark.parametrize("quoting", ["unquoted", "single-quoted"])
    def test_yaml_checksum_rejects_non_double_quoted_values(
        self, home, env, src, payload, quoting
    ):
        """A YAML checksum that is not a double-quoted string is a syntax error."""
        sha = sha256_hex(PAYLOAD)
        rendered = {"unquoted": sha, "single-quoted": "'%s'" % sha}[quoting]
        path = write_external(
            src, external_yaml(".extfile", file_url(payload), [("sha256", rendered)])
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: %s: invalid syntax\n" % path
        # CATCHES: the YAML decoder hands the raw node bytes to
        # HexBytes.UnmarshalYAML, which strconv.Unquotes them, so only
        # double-quoted strings decode: the very same valid checksum fails
        # with "invalid syntax" when unquoted or single-quoted.

    def test_yaml_double_quoted_checksum_is_accepted(self, home, env, src, payload):
        """The same checksum in double quotes verifies and applies the file."""
        sha = sha256_hex(PAYLOAD)
        write_external(
            src,
            external_yaml(".extfile", file_url(payload), [("sha256", '"%s"' % sha)]),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert (home / ".extfile").read_bytes() == PAYLOAD
        # CATCHES: the quoted checksum is unquoted to its hex digits and then
        # decoded, so a matching SHA-256 applies the downloaded bytes
        # verbatim with no output and no warning.

    def test_yaml_invalid_hex_byte_error(self, home, env, src, payload):
        """A quoted checksum that is not hex fails with the hex error."""
        path = write_external(
            src,
            external_yaml(".extfile", file_url(payload), [("sha256", '"zzzz"')]),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: %s: encoding/hex: invalid byte: U+007A 'z'\n" % path
        )
        # CATCHES: after unquoting, the hex decode error is reported verbatim
        # with the .chezmoiexternal.yaml path as the only prefix.

    def test_yaml_odd_length_hex_error(self, home, env, src, payload):
        """An odd number of hex digits fails with the hex length error."""
        path = write_external(
            src, external_yaml(".extfile", file_url(payload), [("sha256", '"abc"')])
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: %s: encoding/hex: odd length hex string\n" % path
        # CATCHES: the checksum length is not validated against the hash
        # algorithm, any even number of hex digits decodes and only the
        # odd-length string is rejected by encoding/hex itself.

    def test_empty_checksum_string_behaves_as_absent(self, home, env, src, payload):
        """An empty checksum string is treated as no checksum at all."""
        write_external(
            src, external_yaml(".extfile", file_url(payload), [("md5", '""')])
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert (home / ".extfile").read_bytes() == PAYLOAD
        # CATCHES: UnmarshalYAML maps the empty string to a nil checksum, so
        # no verification happens AND no "insecure MD5" warning is printed,
        # exactly as if the checksum key were absent.

    def test_json_invalid_hex_byte_error(self, home, env, src, payload):
        """A JSON external reports the hex error with the file path."""
        path = write_external(
            src,
            '{".extfile": {"type": "file", "url": "%s", "checksum": {"sha256": "zzzz"}}}\n'
            % file_url(payload),
            name=".chezmoiexternal.json",
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: %s: encoding/hex: invalid byte: U+007A 'z'\n" % path
        )
        # CATCHES: JSON decodes the checksum through UnmarshalText and fails
        # before anything is downloaded, with no line or key information in
        # the message, unlike the TOML decoder.

    def test_jsonc_comments_are_accepted_and_hex_checked(self, home, env, src, payload):
        """A JSONC external may contain comments; the hex check still runs."""
        path = write_external(
            src,
            "// packed by hand\n"
            '/* block */ {".extfile": {"type": "file", "url": "%s", '
            '"checksum": {"sha256": "zzzz"}}}\n' % file_url(payload),
            name=".chezmoiexternal.jsonc",
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: %s: encoding/hex: invalid byte: U+007A 'z'\n" % path
        )
        # CATCHES: .chezmoiexternal.jsonc is parsed as JSONC (line and block
        # comments stripped before decoding), and the checksum error is
        # identical to the plain JSON one.

    def test_toml_invalid_hex_byte_error(self, home, env, src, payload):
        """A TOML external reports the hex error with line and key context."""
        body = (
            '[".extfile"]\n'
            'type = "file"\n'
            'url = "%s"\n'
            'checksum.sha256 = "zzzz"\n' % file_url(payload)
        )
        path = write_external(src, body, name=".chezmoiexternal.toml")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: %s: toml: line 4 (last key \"\\\".extfile\\\".checksum.sha256\"): "
            "encoding/hex: invalid byte: U+007A 'z'\n" % path
        )
        # CATCHES: the TOML decoder wraps the hex error with the line number
        # and the quoted dotted key that failed, so the message names
        # line 4 and key ".extfile".checksum.sha256.

    def test_toml_quoting_the_whole_path_makes_a_new_entry(self, home, env, src, payload):
        """[".extfile.checksum"] is one key, not a checksum sub-table."""
        body = (
            '[".extfile"]\n'
            'type = "file"\n'
            'url = "%s"\n'
            '\n'
            '[".extfile.checksum"]\n'
            'sha256 = "zzzz"\n' % file_url(payload)
        )
        write_external(src, body, name=".chezmoiexternal.toml")
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: .extfile.checksum: missing external type\n"
        # CATCHES: the target paths are raw map keys, so quoting the whole
        # dotted string creates a second external named .extfile.checksum
        # which fails the type check instead of populating the checksum.

    @pytest.mark.parametrize(
        "command",
        ["apply", "managed", "status", "diff", "dump", "verify", "cat"],
    )
    def test_parse_error_is_surfaced_by_every_source_state_command(
        self, home, env, src, payload, command
    ):
        """Every command that reads the source state decodes .chezmoiexternal."""
        sha = sha256_hex(PAYLOAD)
        path = write_external(
            src, external_yaml(".extfile", file_url(payload), [("sha256", sha)])
        )
        args = [command, "--source", str(src)]
        if command == "cat":
            args.append(str(home / ".extfile"))
        result = run_chezmoi(args, env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == "chezmoi: %s: invalid syntax\n" % path
        # CATCHES: apply, managed, status, diff, dump, verify and cat all
        # parse the externals file before doing any work, and fail with the
        # same decode error, while nothing is written to stdout.

    def test_data_does_not_read_the_external_file(self, home, env, src, payload):
        """`chezmoi data` does not parse .chezmoiexternal at all."""
        sha = sha256_hex(PAYLOAD)
        write_external(
            src, external_yaml(".extfile", file_url(payload), [("sha256", sha)])
        )
        result = run_chezmoi(["data", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert json.loads(result.stdout)["chezmoi"]["sourceDir"] == str(src)
        # CATCHES: data only gathers template data and never walks the
        # externals, so the very same file that fails every source state
        # command leaves `chezmoi data` succeeding.


class TestChecksumVerification:
    @pytest.mark.parametrize("alg", ["sha256", "sha384", "sha512"])
    def test_secure_hash_mismatch_message(self, home, env, src, payload, alg):
        """A wrong secure checksum fails with the expected/got hex digests."""
        digest_len = {"sha256": 64, "sha384": 96, "sha512": 128}[alg]
        got = SECURE_ALGS[alg](PAYLOAD).hexdigest()
        write_external(
            src,
            external_yaml(
                ".extfile", file_url(payload), [(alg, '"%s"' % ("0" * digest_len))]
            ),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: %s mismatch: expected %s, got %s\n"
            % (alg.upper(), "0" * digest_len, got)
        )
        # CATCHES: the "expected" digest is the configured HexBytes rendered
        # as plain lowercase hex and "got" is the hash of the downloaded
        # bytes, and secure hashes never print an insecure warning.

    def test_md5_insecure_warning_and_mismatch(self, home, env, src, payload):
        """A wrong MD5 warns about the insecure hash and then fails."""
        write_external(
            src,
            external_yaml(
                ".extfile", file_url(payload), [("md5", '"%s"' % ("0" * 32))]
            ),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: warning: insecure MD5 checksum will be removed, "
            "use a secure hash like SHA256 instead\n"
            "chezmoi: .extfile: MD5 mismatch: expected %s, got %s\n"
            % ("0" * 32, hashlib.md5(PAYLOAD).hexdigest())
        )
        # CATCHES: the insecure-hash warning is printed even though the
        # checksum also mismatches, and both lines are prefixed with the
        # external's target path, not the URL.

    def test_sha1_insecure_warning_and_mismatch(self, home, env, src, payload):
        """A wrong SHA1 warns about the insecure hash and then fails."""
        write_external(
            src,
            external_yaml(
                ".extfile", file_url(payload), [("sha1", '"%s"' % ("0" * 40))]
            ),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: warning: insecure SHA1 checksum will be removed, "
            "use a secure hash like SHA256 instead\n"
            "chezmoi: .extfile: SHA1 mismatch: expected %s, got %s\n"
            % ("0" * 40, hashlib.sha1(PAYLOAD).hexdigest())
        )
        # CATCHES: SHA1 is treated exactly like MD5 (warning plus mismatch)
        # while SHA256/384/512 mismatch without any warning.

    def test_ripemd160_mismatch_matches_the_reference_digest_quirk(
        self, home, env, src, payload
    ):
        """The RIPEMD-160 "got" digest is the data plus the empty digest."""
        write_external(
            src,
            external_yaml(
                ".extfile",
                file_url(payload),
                [("ripemd160", '"%s"' % ("0" * 40))],
            ),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: warning: insecure RIPEMD-160 checksum will be "
            "removed, use a secure hash like SHA256 instead\n"
            "chezmoi: .extfile: RIPEMD-160 mismatch: expected %s, got %s%s\n"
            % ("0" * 40, PAYLOAD.hex(), RIPEMD160_OF_EMPTY)
        )
        # CATCHES: the reference computes ripemd160.New().Sum(data) without
        # writing to the hash, so the reported digest is the hex of the
        # downloaded data followed by the RIPEMD-160 of the empty string,
        # which no correct implementation would produce.

    def test_size_mismatch_without_a_secure_hash_warns(self, home, env, src, payload):
        """A bare size check warns that it is not a secure hash."""
        write_external(
            src, external_yaml(".extfile", file_url(payload), [("size", "3")])
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: warning: insecure size check without secure hash "
            "will be removed\n"
            "chezmoi: .extfile: size mismatch: expected 3, got %d\n" % len(PAYLOAD)
        )
        # CATCHES: a size without a SHA256/384/512 warns before failing, and
        # the size is compared against the length of the downloaded bytes.

    def test_size_mismatch_with_a_secure_hash_does_not_warn(
        self, home, env, src, payload
    ):
        """A size check next to a secure hash fails without the warning."""
        write_external(
            src,
            external_yaml(
                ".extfile",
                file_url(payload),
                [("sha256", '"%s"' % sha256_hex(PAYLOAD)), ("size", "3")],
            ),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: size mismatch: expected 3, got %d\n" % len(PAYLOAD)
        )
        # CATCHES: the insecure-size warning is suppressed whenever any
        # secure hash is configured, even one that matches, while the size
        # mismatch itself is still reported.

    def test_correct_checksums_accept_the_file(self, home, env, src, payload):
        """Matching md5, sha512 and size apply the file despite the warning."""
        write_external(
            src,
            external_yaml(
                ".extfile",
                file_url(payload),
                [
                    ("md5", '"%s"' % hashlib.md5(PAYLOAD).hexdigest()),
                    ("sha512", '"%s"' % hashlib.sha512(PAYLOAD).hexdigest()),
                    ("size", str(len(PAYLOAD))),
                ],
            ),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: warning: insecure MD5 checksum will be removed, "
            "use a secure hash like SHA256 instead\n"
        )
        assert (home / ".extfile").read_bytes() == PAYLOAD
        # CATCHES: a matching insecure checksum still warns on stderr but the
        # apply succeeds and writes the downloaded bytes to the target.

    def test_multiple_mismatches_are_reported_together(self, home, env, src, payload):
        """All mismatch errors are joined under a single path prefix."""
        write_external(
            src,
            external_yaml(
                ".extfile",
                file_url(payload),
                [
                    ("md5", '"%s"' % ("0" * 32)),
                    ("sha256", '"%s"' % ("0" * 64)),
                    ("size", "3"),
                ],
            ),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: warning: insecure MD5 checksum will be removed, "
            "use a secure hash like SHA256 instead\n"
            "chezmoi: .extfile: size mismatch: expected 3, got %d\n"
            "MD5 mismatch: expected %s, got %s\n"
            "SHA256 mismatch: expected %s, got %s\n"
            % (
                len(PAYLOAD),
                "0" * 32,
                hashlib.md5(PAYLOAD).hexdigest(),
                "0" * 64,
                sha256_hex(PAYLOAD),
            )
        )
        # CATCHES: the warning is emitted immediately with its own prefix,
        # while the collected errors are joined with newlines so only the
        # first line carries the "chezmoi: .extfile:" prefix, in the fixed
        # order size, MD5, SHA256.

    def test_missing_file_url_reports_the_open_error(self, home, env, src, tmp_path):
        """A file:// URL that does not exist fails with the open error."""
        missing = tmp_path / "no-such-file"
        write_external(
            src, external_yaml(".extfile", file_url(missing), [("sha256", '"%s"' % ("0" * 64))])
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: open %s: no such file or directory\n" % missing
        )
        # CATCHES: file:// URLs are read straight from disk (never cached or
        # fetched over HTTP), so a missing file surfaces as the raw os open
        # error with the absolute path from the URL.

    def test_archive_checksum_covers_the_archive_bytes(self, home, env, src, tmp_path):
        """An archive external verifies the checksum of the archive itself."""
        archive = tmp_path / "archive.tar.gz"
        with tarfile.open(archive, "w:gz") as tar:
            info = tarfile.TarInfo("member.txt")
            info.size = len(ARCHIVE_MEMBER)
            tar.addfile(info, io.BytesIO(ARCHIVE_MEMBER))
        body = (
            '"archdir":\n'
            "    type: archive\n"
            "    url: %s\n"
            '    checksum:\n'
            '        sha256: "%s"\n' % (file_url(archive), sha256_hex(archive.read_bytes()))
        )
        write_external(src, body)
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert (home / "archdir" / "member.txt").read_bytes() == ARCHIVE_MEMBER
        # The same archive with a wrong checksum fails on the archive bytes.
        write_external(
            src,
            body.replace(sha256_hex(archive.read_bytes()), "0" * 64),
        )
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: archdir: SHA256 mismatch: expected %s, got %s\n"
            % ("0" * 64, sha256_hex(archive.read_bytes()))
        )
        # CATCHES: the checksum is verified against the downloaded archive
        # bytes, not against any extracted member, and a mismatch leaves the
        # previously extracted tree untouched.

    @pytest.mark.parametrize("command", ["status", "diff", "verify", "dump", "cat"])
    def test_every_walking_command_verifies_the_checksum(
        self, home, env, src, payload, command
    ):
        """status, diff, verify, dump and cat all verify external checksums."""
        write_external(
            src,
            external_yaml(
                ".extfile", file_url(payload), [("sha256", '"%s"' % ("0" * 64))]
            ),
        )
        args = [command, "--source", str(src)]
        if command == "cat":
            args.append(str(home / ".extfile"))
        result = run_chezmoi(args, env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: .extfile: SHA256 mismatch: expected %s, got %s\n"
            % ("0" * 64, sha256_hex(PAYLOAD))
        )
        # CATCHES: the checksum is verified whenever the external's data is
        # needed, not only by apply, so even read-only commands like cat and
        # dump fail on a mismatch before printing anything.
