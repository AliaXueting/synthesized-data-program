"""`chezmoi doctor`'s suspicious-entry report for the source directory.

These exercise chezmoi.IsSuspiciousSourceDirEntry and the knownPrefixedFiles /
knownPrefixedDirs / knownTargetFiles tables in internal/chezmoi/chezmoi.go:
doctor walks the source directory and lists every entry that chezmoi would
otherwise silently ignore or misinterpret.
"""

from __future__ import annotations

import os
import re
import socket

import pytest

from conftest import run_chezmoi

# doctor's table is written by text/tabwriter: a RESULT column, a CHECK column
# and the message, padded with spaces.
SUSPICIOUS_ENTRY_RX = re.compile(r"^(?P<result>\S+)\s+suspicious-entries\s+(?P<message>.*)$")
HEADER_LINE = "RESULT    CHECK                       MESSAGE"


def doctor(env, src):
    """Run `chezmoi doctor --no-network` against src and return the result."""
    return run_chezmoi(["doctor", "--no-network", "--source", str(src)], env=env)


def suspicious_entries(env, src):
    """Return (result, message) of doctor's suspicious-entries check."""
    result = doctor(env, src)
    assert result.returncode == 0
    for line in result.stdout.splitlines():
        match = SUSPICIOUS_ENTRY_RX.match(line)
        if match:
            return match.group("result"), match.group("message")
    raise AssertionError("no suspicious-entries line in doctor output:\n" + result.stdout)


class TestDoctorOutput:
    def test_table_header_and_result_columns(self, home, env, src):
        """doctor prints a fixed RESULT/CHECK/MESSAGE table header."""
        result = doctor(env, src)
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout.splitlines()[0] == HEADER_LINE
        # CATCHES: the report is a space-padded three column table whose
        # column widths are fixed by the longest check name, not a tab or
        # comma separated list.

    def test_doctor_exits_zero_despite_warnings(self, home, env, src):
        """A suspicious source directory is a warning, not an error."""
        (src / ".chezmoibogus").write_text("x\n")
        result = doctor(env, src)
        assert result.returncode == 0
        assert result.stdout.splitlines()[0] == HEADER_LINE
        check, message = suspicious_entries(env, src)
        assert check == "warning"
        assert message == "%s/.chezmoibogus" % src
        # CATCHES: suspicious entries never change the exit status, they only
        # downgrade the suspicious-entries check from ok to warning.


class TestNotSuspicious:
    def test_ordinary_source_entries(self, home, env, src):
        """Normal files, directories and scripts are not suspicious."""
        (src / "dot_file.txt").write_text("content\n")
        (src / "dot_dir").mkdir()
        (src / "run_once_install.sh").write_text("#!/bin/sh\ntrue\n")
        assert suspicious_entries(env, src) == ("ok", "no suspicious entries")
        # CATCHES: only .chezmoi-prefixed names and known target file names
        # are reported, so an ordinary source state stays clean.

    def test_known_special_names(self, home, env, src):
        """Every documented .chezmoi name is accepted without a warning."""
        for name in [
            ".chezmoiignore",
            ".chezmoiremove",
            ".chezmoidata.toml",
            ".chezmoiversion",
            ".chezmoi.toml.tmpl",
            ".chezmoi.json.tmpl",
            ".chezmoi.yaml.tmpl",
            ".chezmoiexternal.yaml",
            ".chezmoiroot",
        ]:
            (src / name).write_text("x\n")
        for name in [
            ".chezmoitemplates",
            ".chezmoiscripts",
            ".chezmoidata",
            ".chezmoiexternals",
        ]:
            (src / name).mkdir()
        (src / ".chezmoitemplates" / "helper.tmpl").write_text("x\n")
        assert suspicious_entries(env, src) == ("ok", "no suspicious entries")
        # CATCHES: the knownPrefixedFiles and knownPrefixedDirs tables accept
        # every documented special name (including the .tmpl config templates
        # and the files inside .chezmoitemplates) without a warning.


class TestSuspicious:
    def test_unknown_chezmoi_prefixed_file(self, home, env, src):
        """An unrecognized .chezmoi-prefixed file is suspicious."""
        (src / ".chezmoibogus").write_text("x\n")
        check, message = suspicious_entries(env, src)
        assert check == "warning"
        assert message == "%s/.chezmoibogus" % src
        # CATCHES: a typo like .chezmoibogus is not silently ignored, doctor
        # reports the absolute path of the unrecognized file.

    def test_unknown_chezmoi_prefixed_directory(self, home, env, src):
        """An unrecognized .chezmoi-prefixed directory is suspicious."""
        (src / ".chezmoiweirddir").mkdir()
        check, message = suspicious_entries(env, src)
        assert check == "warning"
        assert message == "%s/.chezmoiweirddir" % src
        # CATCHES: the knownPrefixedDirs table is much smaller than the file
        # table, so an unknown .chezmoi directory is reported by path.

    def test_chezmoi_prefixed_symlink(self, home, env, src):
        """A .chezmoi-prefixed symlink is always suspicious."""
        (src / "dot_target").write_text("content\n")
        os.symlink("dot_target", src / ".chezmoisym")
        check, message = suspicious_entries(env, src)
        assert check == "warning"
        assert message == "%s/.chezmoisym" % src
        # CATCHES: symlinks are rejected by name alone even when they point at
        # a perfectly valid entry in the same source directory.

    @pytest.mark.parametrize(
        "name",
        ["chezmoi.toml", "chezmoi.json", "chezmoi.yaml", "chezmoistate.boltdb"],
    )
    def test_known_target_files_are_suspicious(self, home, env, src, name):
        """Source entries whose target is a chezmoi file are suspicious."""
        (src / name).write_text("x\n")
        check, message = suspicious_entries(env, src)
        assert check == "warning"
        assert message == "%s/%s" % (src, name)
        # CATCHES: a source entry that would manage chezmoi's own config file
        # or its persistent state database is reported, because the entry
        # attributes are parsed with every encrypted suffix before being
        # checked against the known target file names.

    @pytest.mark.parametrize("kind", ["fifo", "socket"])
    def test_special_file_types_are_suspicious(self, home, env, src, kind):
        """A fifo or socket in the source directory is suspicious."""
        if kind == "fifo":
            os.mkfifo(src / "dot_special")
        else:
            sock = socket.socket(socket.AF_UNIX)
            sock.bind(str(src / "dot_special"))
        check, message = suspicious_entries(env, src)
        assert check == "warning"
        assert message == "%s/dot_special" % src
        # CATCHES: any file type other than a regular file, a directory or a
        # (non-.chezmoi) symlink is reported, whatever its name.

    def test_multiple_entries_are_listed_in_walk_order(self, home, env, src):
        """Several suspicious entries are joined as an Oxford series."""
        (src / ".chezmoibogus").write_text("x\n")
        (src / ".chezmoisym").mkdir()
        (src / "dot_target").write_text("content\n")
        os.symlink("dot_target", src / ".chezmoilink")
        (src / "chezmoi.toml").write_text("x\n")
        check, message = suspicious_entries(env, src)
        assert check == "warning"
        assert message == "%s" % ", ".join(
            [
                "%s/.chezmoibogus" % src,
                "%s/.chezmoilink" % src,
                "%s/.chezmoisym" % src,
                "and %s/chezmoi.toml" % src,
            ]
        )
        # CATCHES: the entries are listed in the source directory walk order
        # (lexicographic, dot-prefixed names first) and joined with ", " and a
        # final "and", not with a bare comma or a newline.


class TestOSArchCheck:
    def test_os_arch_row_shows_os_release_name_and_version(self, home, env, src):
        """doctor's os-arch row embeds the unquoted os-release NAME/VERSION."""
        result = doctor(env, src)
        assert result.returncode == 0
        assert (
            "ok        os-arch                     "
            "linux/amd64 (Ubuntu 24.04 LTS (Noble Numbat))"
        ) in result.stdout.splitlines()
        # CATCHES: the check re-reads /etc/os-release through the same parser
        # as `chezmoi data` (quotes stripped, NAME and VERSION joined with a
        # space in parentheses), not the raw quoted file values, and reports
        # result "ok" with the goos/goarch of the binary.
