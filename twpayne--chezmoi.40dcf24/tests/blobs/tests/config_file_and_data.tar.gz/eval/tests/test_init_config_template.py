"""Config file templates: `init`, `apply --init`, and init-only template funcs."""

from __future__ import annotations

import hashlib
import json
import stat

import pytest

from conftest import run_chezmoi, write_config

CONFIG_PATH = [".config", "chezmoi", "chezmoi.toml"]


def write_template(src, contents, name=".chezmoi.toml.tmpl"):
    """Write a config template into the source directory."""
    path = src / name
    path.write_text(contents)
    return path


def config_file(home):
    return home.joinpath(*CONFIG_PATH)


@pytest.fixture(autouse=True)
def git_repo(src):
    """Mark the source dir as an existing repo so init skips `git init`."""
    src.joinpath(".git").mkdir(exist_ok=True)


class TestInitConfigTemplate:
    def test_init_renders_template_to_config(self, home, env, src):
        """init renders .chezmoi.toml.tmpl and writes the config file."""
        write_template(src, 'sourceDir = "{{ .chezmoi.sourceDir }}"\n')
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        config = config_file(home)
        assert config.read_text() == 'sourceDir = "%s"\n' % src
        assert stat.S_IMODE(config.stat().st_mode) == 0o600
        assert (home / ".config" / "chezmoi" / "chezmoistate.boltdb").is_file()
        # CATCHES: the rendered config is written with 0600 permissions, the
        # template data includes the source dir, and the state DB records the
        # template next to the config.

    def test_config_template_hash_stored_in_state(self, home, env, src):
        """init stores the template's SHA-256 in the configState bucket."""
        first = 'sourceDir = "/v1"\n'
        write_template(src, first)
        assert run_chezmoi(["init", "--source", str(src)], env=env).returncode == 0
        result = run_chezmoi(["state", "dump", "--source", str(src)], env=env)
        assert result.returncode == 0
        state = json.loads(result.stdout)
        assert state["configState"] == {
            "configState": {
                "configTemplateContentsSHA256": hashlib.sha256(first.encode()).hexdigest()
            }
        }
        # A plain apply after changing the template warns but keeps the old hash.
        write_template(src, 'sourceDir = "/v2"\n')
        assert run_chezmoi(["apply", "--source", str(src)], env=env).returncode == 0
        result = run_chezmoi(["state", "dump", "--source", str(src)], env=env)
        assert json.loads(result.stdout)["configState"]["configState"][
            "configTemplateContentsSHA256"
        ] == hashlib.sha256(first.encode()).hexdigest()
        # apply --init regenerates the config and updates the stored hash.
        assert run_chezmoi(["apply", "--init", "--source", str(src)], env=env).returncode == 0
        result = run_chezmoi(["state", "dump", "--source", str(src)], env=env)
        assert json.loads(result.stdout)["configState"]["configState"][
            "configTemplateContentsSHA256"
        ] == hashlib.sha256(b'sourceDir = "/v2"\n').hexdigest()
        # CATCHES: the stored value is the lowercase hex SHA-256 of the raw
        # template bytes, it is only refreshed by init/apply --init, and the
        # bucket/key names are configState/configState.

    def test_init_is_idempotent(self, home, env, src):
        """A second init with the same template rewrites the same config."""
        write_template(src, 'sourceDir = "/x"\n')
        assert run_chezmoi(["init", "--source", str(src)], env=env).returncode == 0
        first = config_file(home).read_text()
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert config_file(home).read_text() == first
        # CATCHES: re-running init must not error, prompt, or corrupt the
        # already-generated config file.

    def test_apply_init_regenerates_config(self, home, env, src):
        """apply --init recreates the config from the current template."""
        write_template(src, 'sourceDir = "/v1"\n')
        assert run_chezmoi(["init", "--source", str(src)], env=env).returncode == 0
        assert config_file(home).read_text() == 'sourceDir = "/v1"\n'
        write_template(src, 'sourceDir = "/v2"\n')
        result = run_chezmoi(["apply", "--init", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert config_file(home).read_text() == 'sourceDir = "/v2"\n'
        # CATCHES: --init on a root command reruns the template generation so
        # the new template content reaches the config file.

    def test_apply_without_init_warns_and_keeps_config(self, home, env, src):
        """A changed template without --init warns and leaves the config alone."""
        write_template(src, 'sourceDir = "/v1"\n')
        assert run_chezmoi(["init", "--source", str(src)], env=env).returncode == 0
        write_template(src, 'sourceDir = "/changed"\n')
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: warning: config file template has changed, "
            "run chezmoi init to regenerate config file\n"
        )
        assert config_file(home).read_text() == 'sourceDir = "/v1"\n'
        # CATCHES: the stale-template warning goes to stderr with a trailing
        # newline, exits zero, and never rewrites the config by itself.

    def test_warning_can_be_disabled(self, home, env, src):
        """warnings.configFileTemplateHasChanged = false silences the warning."""
        (src / "dot_file.txt").write_text("content\n")
        write_template(src, 'sourceDir = "/v1"\n')
        assert run_chezmoi(["init", "--source", str(src)], env=env).returncode == 0
        write_template(src, 'sourceDir = "/v2"\n')
        warnings_config = "[warnings]\n    configFileTemplateHasChanged = false\n"
        write_config(home, warnings_config)
        result = run_chezmoi(["apply", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert (home / ".file.txt").read_text() == "content\n"
        assert config_file(home).read_text() == warnings_config
        # CATCHES: the warning is gated on the documented warnings config key,
        # the source state is still applied (dot_file.txt reaches the home
        # directory), and the config file itself stays untouched.

    def test_apply_init_without_template(self, home, env, src):
        """apply --init with no template creates no config file or warning."""
        (src / "dot_file.txt").write_text("content\n")
        result = run_chezmoi(["apply", "--init", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert (home / ".file.txt").read_text() == "content\n"
        assert not (home / ".config" / "chezmoi" / "chezmoi.toml").exists()
        # CATCHES: with no template in the source dir, --init must not create
        # any config file (only the state database directory appears) while the
        # source state is still applied to the destination directory.

    def test_multiple_templates_rejected(self, home, env, src):
        """Two config templates in the source dir are an error."""
        toml_template = write_template(src, "a = 1\n")
        yaml_template = write_template(src, "b = 2\n", name=".chezmoi.yaml.tmpl")
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: multiple config file templates: %s and %s \n"
            % (toml_template, yaml_template)
        )
        # CATCHES: the error message ends with a trailing space after the
        # second path and lists templates in name order.

    def test_invalid_toml_output_rejected(self, home, env, src):
        """A template that renders invalid TOML fails with the parser error."""
        template = write_template(src, "this is not toml\n")
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            "chezmoi: %s: toml: line 1: expected '.' or '=', but got 'i' instead\n" % template
        )
        # CATCHES: the rendered output is validated as TOML before being
        # written, and the error names the template file and token.

    def test_failed_render_leaves_config_untouched(self, home, env, src):
        """A template error leaves an existing config file unchanged."""
        write_config(home, 'sourceDir = "/original"\n')
        write_template(src, 'sourceDir = "{{ .nope }}"\n')
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: template: chezmoi.toml:1:16: executing "chezmoi.toml" at <.nope>: '
            'map has no entry for key "nope"\n'
        )
        assert config_file(home).read_text() == 'sourceDir = "/original"\n'
        # CATCHES: the existing config is only replaced after a successful
        # render, and template errors use text/template's execution format.

    def test_unknown_keys_written_verbatim(self, home, env, src):
        """Rendered config content is not validated for unknown keys."""
        write_template(src, 'unknownKey = "kept"\n')
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stderr == ""
        assert config_file(home).read_text() == 'unknownKey = "kept"\n'
        # CATCHES: init only parses the output, it does not reject unknown
        # config keys the way a hand-written config eventually would not.

    def test_config_path_flag_redirects_output(self, home, env, src, tmp_path):
        """--config-path / -C write the generated config elsewhere."""
        write_template(src, 'sourceDir = "/x"\n')
        custom = tmp_path / "generated.toml"
        result = run_chezmoi(
            ["init", "--source", str(src), "--config-path", str(custom)], env=env
        )
        assert result.returncode == 0
        assert custom.read_text() == 'sourceDir = "/x"\n'
        assert not config_file(home).exists()
        assert (home / ".config" / "chezmoi" / "chezmoistate.boltdb").is_file()
        result = run_chezmoi(
            ["init", "--source", str(src), "-C", str(tmp_path / "gen2.toml")], env=env
        )
        assert result.returncode == 0
        assert (tmp_path / "gen2.toml").read_text() == 'sourceDir = "/x"\n'
        # CATCHES: the config location moves but the persistent state DB stays
        # in the default config directory.

    def test_yaml_template_writes_yaml_config(self, home, env, src):
        """A .chezmoi.yaml.tmpl produces a chezmoi.yaml config file."""
        write_template(src, "sourceDir: /yaml\n", name=".chezmoi.yaml.tmpl")
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 0
        yaml_config = home / ".config" / "chezmoi" / "chezmoi.yaml"
        assert yaml_config.read_text() == "sourceDir: /yaml\n"
        assert not config_file(home).exists()
        # CATCHES: the output filename extension follows the template's own
        # extension rather than always writing chezmoi.toml.


class TestTemplateFuncs:
    def test_exit_function_sets_exit_code(self, home, env, src):
        """{{ exit N }} terminates init with exit code N and no error output."""
        write_template(src, "{{ exit 42 }}\n")
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 42
        assert result.stdout == ""
        assert result.stderr == ""
        assert not config_file(home).exists()
        # CATCHES: exit aborts the template silently with the given status (not
        # 1) and no config file is written afterwards.

    def test_write_to_stdout(self, home, env, src):
        """{{ writeToStdout }} writes its concatenated args to stdout."""
        write_template(src, '{{ writeToStdout "hello " "world" }}\nsourceDir = "/x"\n')
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert result.stdout == "hello world"
        assert result.stderr == ""
        assert config_file(home).read_text() == '\nsourceDir = "/x"\n'
        # CATCHES: writeToStdout output goes to stdout immediately (before the
        # config file is written), the template's own newline after the action
        # stays in the rendered config, and no trailing newline is appended to
        # the stdout bytes.

    @pytest.mark.parametrize(
        ("template", "stdin", "expected_stdout", "expected_config"),
        [
            pytest.param(
                '[data]\n    color = "{{ promptChoice "Color" (list "red" "green") }}"\n',
                "red\n",
                "Color (red/green)? ",
                '[data]\n    color = "red"\n',
                id="choice-full-answer",
            ),
            pytest.param(
                '[data]\n    color = "{{ promptChoice "Color" (list "red" "green") }}"\n',
                "r\n",
                "Color (red/green)? ",
                '[data]\n    color = "red"\n',
                id="choice-abbreviation",
            ),
            pytest.param(
                '[data]\n    color = "{{ promptChoice "Color" (list "red" "green") "red" }}"\n',
                "\n",
                "Color (red/green, default red)? ",
                '[data]\n    color = "red"\n',
                id="choice-default-enter",
            ),
            pytest.param(
                '[data]\n    name = "{{ promptString "Name" "dflt" }}"\n',
                "\n",
                'Name (default "dflt")? ',
                '[data]\n    name = "dflt"\n',
                id="string-default-enter",
            ),
            pytest.param(
                "[data]\n    flag = {{ promptBool \"Flag\" true }}\n",
                "\n",
                "Flag (default true)? ",
                "[data]\n    flag = true\n",
                id="bool-default-enter",
            ),
            pytest.param(
                "[data]\n    num = {{ promptInt \"Num\" 5 }}\n",
                "-4\n",
                "Num (default 5)? ",
                "[data]\n    num = -4\n",
                id="int-negative-answer",
            ),
        ],
    )
    def test_prompt_functions_render_on_stdout(
        self, home, env, src, template, stdin, expected_stdout, expected_config
    ):
        """With --no-tty prompts are written to stdout and read from stdin."""
        write_template(src, template)
        result = run_chezmoi(
            ["init", "--source", str(src), "--no-tty"], env=env, stdin=stdin.encode()
        )
        assert result.returncode == 0
        assert result.stderr == ""
        assert result.stdout == expected_stdout
        assert config_file(home).read_text() == expected_config
        # CATCHES: each prompt type has a distinct exact prompt string
        # (choices in parens, defaults quoted for strings but not bools/ints),
        # none end with a newline, and ENTER selects the default.

    def test_prompt_string_bool_int_sequence(self, home, env, src):
        """Multiple prompts consume stdin lines in order."""
        write_template(
            src,
            '[data]\n'
            '    name = "{{ promptString "Name" }}"\n'
            "    flag = {{ promptBool \"Flag\" false }}\n"
            "    num = {{ promptInt \"Num\" 5 }}\n",
        )
        result = run_chezmoi(
            ["init", "--source", str(src), "--no-tty"],
            env=env,
            stdin=b"myname\nyes\n-4\n",
        )
        assert result.returncode == 0
        assert result.stdout == "Name? Flag (default false)? Num (default 5)? "
        assert config_file(home).read_text() == (
            '[data]\n    name = "myname"\n    flag = true\n    num = -4\n'
        )
        # CATCHES: answers are consumed in template order, "yes" parses as
        # true, and negative integers survive into the rendered output.

    def test_prompt_multichoice(self, home, env, src):
        """promptMultichoice prompts repeatedly and renders a TOML list."""
        write_template(src, "[data]\n    multi = {{ promptMultichoice \"Pick some\" (list \"a\" \"b\" \"c\") }}\n")
        result = run_chezmoi(
            ["init", "--source", str(src), "--no-tty"], env=env, stdin=b"[]\n"
        )
        assert result.returncode == 0
        assert result.stdout == "Pick some?\nChoices (a/b/c)\nChoice (ENTER to stop)> "
        assert config_file(home).read_text() == "[data]\n    multi = []\n"
        template = write_template(src, "[data]\n    multi = {{ promptMultichoice \"Pick some\" (list \"a\" \"b\" \"c\") (list \"b\") }}\n")
        result = run_chezmoi(
            ["init", "--source", str(src), "--no-tty"], env=env, stdin=b"\n"
        )
        assert result.returncode == 1
        assert result.stdout == (
            "Pick some?\nChoices (a/b/c)\nDefault [b]\nChoice (ENTER to stop)> "
        )
        assert result.stderr == (
            "chezmoi: %s: toml: line 2 (last key \"data.multi\"): "
            'expected value but found "b" instead\n' % template
        )
        # CATCHES: the default is shown as an unquoted bracket list, ENTER
        # accepts it, and string selections render unquoted (invalid TOML)
        # which fails validation with the "last key" annotation.

    def test_prompt_string_once_reads_config_data(self, home, env, src):
        """promptStringOnce returns existing config [data] without prompting."""
        write_config(home, '[data]\n    email = "existing@example.com"\n')
        write_template(
            src,
            '[data]\n'
            '    email = "{{ promptStringOnce . "email" "Email address" }}"\n'
            '    extra = "{{ promptString "Extra" }}"\n',
        )
        result = run_chezmoi(
            ["init", "--source", str(src), "--no-tty"], env=env, stdin=b"typed\n"
        )
        assert result.returncode == 0
        assert result.stdout == "Extra? "
        assert result.stderr == ""
        assert config_file(home).read_text() == (
            '[data]\n    email = "existing@example.com"\n    extra = "typed"\n'
        )
        # CATCHES: the Once variant looks up the path in the current config
        # data first, so only the second (absent) key prompts — stdout shows
        # "Extra? " and no "Email address" prompt at all.

    def test_prompt_string_once_prompts_when_absent(self, home, env, src):
        """promptStringOnce falls back to prompting when the key is missing."""
        write_template(src, '[data]\n    email = "{{ promptStringOnce . "email" "Email address" }}"\n')
        result = run_chezmoi(
            ["init", "--source", str(src), "--no-tty"], env=env, stdin=b"typed@example.com\n"
        )
        assert result.returncode == 0
        assert result.stdout == "Email address? "
        assert config_file(home).read_text() == '[data]\n    email = "typed@example.com"\n'
        # CATCHES: without a stored value the Once variant behaves like
        # promptString, reading the answer from stdin under --no-tty.

    @pytest.mark.parametrize("function", ["promptString", "promptBool", "promptInt", "promptChoice", "promptMultichoice", "promptStringOnce", "exit", "writeToStdout"])
    def test_init_funcs_not_defined_in_execute_template(self, home, env, function):
        """Init-only template functions are absent from execute-template."""
        result = run_chezmoi(["execute-template", "{{ %s }}" % function], env=env)
        assert result.returncode == 1
        assert result.stdout == ""
        assert result.stderr == (
            'chezmoi: template: arg1:1: function "%s" not defined\n' % function
        )
        # CATCHES: the init template funcs are only injected for config
        # templates, not for general template execution.

    def test_execute_template_still_works(self, home, env):
        """Regular template data remains available to execute-template."""
        result = run_chezmoi(["execute-template", "{{ .chezmoi.os }}"], env=env)
        assert result.returncode == 0
        assert result.stdout == "linux"
        # CATCHES: excluding init funcs must not break the normal template
        # function set or data.


class TestTemplateData:
    def test_config_data_available_without_data_flag(self, home, env, src):
        """Config [data] is visible to the config template by default."""
        write_config(home, '[data]\n    email = "existing@example.com"\n')
        write_template(src, 'sourceDir = "/x"\nemail = "{{ .email }}"\n')
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 0
        assert config_file(home).read_text() == (
            'sourceDir = "/x"\nemail = "existing@example.com"\n'
        )
        # CATCHES: the existing config's [data] section is merged into the
        # template data, so templates can reuse stored answers.

    def test_data_flag_keeps_config_data(self, home, env, src):
        """--data still exposes config [data] to the config template."""
        write_config(home, '[data]\n    email = "existing@example.com"\n')
        write_template(src, 'sourceDir = "/x"\nemail = "{{ .email }}"\n')
        result = run_chezmoi(["init", "--source", str(src), "--data"], env=env)
        assert result.returncode == 0
        assert result.stdout == ""
        assert result.stderr == ""
        assert config_file(home).read_text() == (
            'sourceDir = "/x"\nemail = "existing@example.com"\n'
        )
        # CATCHES: --data does not restrict the template to builtin data; the
        # config file's [data] keys remain top-level template variables and the
        # rendered config is still written on success.

    def test_chezmoidata_not_available_to_config_template(self, home, env, src):
        """.chezmoidata files are not part of the config template's data."""
        (src / ".chezmoidata.json").write_text('{"k": "v"}\n')
        write_template(src, 'sourceDir = "/x"\nk = "{{ .k }}"\n')
        result = run_chezmoi(["init", "--source", str(src)], env=env)
        assert result.returncode == 1
        assert result.stderr == (
            'chezmoi: template: chezmoi.toml:2:8: executing "chezmoi.toml" at <.k>: '
            'map has no entry for key "k"\n'
        )
        # CATCHES: .chezmoidata files only feed target templates, not the
        # config template itself, even though both render during init.
