"""Shared fixtures and helpers for the config_file_and_data module tests.

Every test spawns the chezmoi binary under test as a child process with a
fully pinned environment (its own ``HOME``, ``PATH`` and ``TMPDIR``) so that
the observed behaviour depends neither on the machine nor on the user running
the suite.
"""

from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path

import pytest

EXECUTABLE = os.environ.get("PROGRAMGYM_EXECUTABLE", "chezmoi")

SYSTEM_PATH = "/usr/bin:/bin"


@dataclass
class Result:
    """The recorded outcome of one chezmoi invocation."""

    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0


def child_env(home: Path, *, tmpdir: Path | None = None, **extra: str | None) -> dict[str, str]:
    """Return the pinned environment used for every child process.

    XDG variables are deliberately left unset so that chezmoi falls back to
    their defaults under ``HOME``; individual tests add them explicitly.
    """
    if tmpdir is None:
        tmpdir = home / "tmp"
    tmpdir.mkdir(parents=True, exist_ok=True)
    env = {
        "HOME": str(home),
        "PATH": SYSTEM_PATH,
        "SHELL": "/bin/sh",
        "TMPDIR": str(tmpdir),
        "LC_ALL": "C",
    }
    for key, value in extra.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    return env


def run_chezmoi(
    args,
    *,
    env: dict[str, str],
    cwd: Path | str | None = None,
    stdin: bytes = b"",
    timeout: int = 60,
) -> Result:
    """Run the chezmoi binary under test and record its exact output."""
    # Coverage instrumentation hook: the pipeline measures source coverage of
    # the reference binary through GOCOVERDIR, so it must reach the child.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    env = {**env, **cov_env}
    proc = subprocess.run(
        [EXECUTABLE, *args],
        env=env,
        cwd=None if cwd is None else str(cwd),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    return Result(proc.returncode, proc.stdout.decode(), proc.stderr.decode())


def write_config(home: Path, contents: str, name: str = "chezmoi.toml") -> Path:
    """Write a chezmoi config file in home's XDG config directory."""
    config_dir = home / ".config" / "chezmoi"
    config_dir.mkdir(parents=True, exist_ok=True)
    path = config_dir / name
    path.write_text(contents)
    return path


def current_umask() -> int:
    """Return the process umask without permanently changing it."""
    umask = os.umask(0o022)
    os.umask(umask)
    return umask


def write_script(path: Path, contents: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(contents)
    path.chmod(0o755)
    return path


def data_json(result: Result) -> dict:
    """Parse the JSON produced by `chezmoi data` (or dump-config)."""
    return json.loads(result.stdout)


def chezmoi_key(result: Result) -> dict:
    """Return the built-in `chezmoi` map from a `chezmoi data` run."""
    return data_json(result)["chezmoi"]


@pytest.fixture
def home(tmp_path: Path) -> Path:
    """An empty home directory for the child process."""
    h = tmp_path / "home"
    h.mkdir()
    (tmp_path / "tmp").mkdir(exist_ok=True)
    return h


@pytest.fixture
def env(home: Path, tmp_path: Path) -> dict[str, str]:
    """The default pinned child environment."""
    return child_env(home, tmpdir=tmp_path / "tmp")


@pytest.fixture
def src(tmp_path: Path) -> Path:
    """An empty source directory (not a git repository)."""
    s = tmp_path / "src"
    s.mkdir()
    return s
