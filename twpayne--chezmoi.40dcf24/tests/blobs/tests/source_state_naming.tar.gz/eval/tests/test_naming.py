"""The source-directory naming language: file names -> target names.

Every expectation below was recorded by running the reference binary over a
source directory containing exactly these entries and capturing
``target-path``'s stdout byte for byte.
"""

from __future__ import annotations

import pytest

from conftest import make_age_config


def target_paths(env, names):
    """Run `target-path` over NAMES (source entries), return normalized stdout."""
    result = env.run(["target-path", *env.flags(), *[str(env.src / n) for n in names]])
    assert result.returncode == 0, result.stderr
    return env.norm(result.stdout).decode()


def test_target_path_attribute_prefixes(env):
    """Each attribute prefix is stripped and the remainder is the target name.

    create_/modify_/remove_/symlink_/run_/empty_/executable_/private_/
    readonly_/encrypted_ all map `X_foo` to the target `foo`, and the script
    condition modifiers (once_, onchange_, before_, after_) are stripped
    around run_.
    """
    table = [
        ("dot_bashrc", ".bashrc"),
        ("plain", "plain"),
        ("empty_foo", "foo"),
        ("executable_foo", "foo"),
        ("private_foo", "foo"),
        ("readonly_foo", "foo"),
        ("encrypted_foo", "foo"),
        ("create_foo", "foo"),
        ("create_dot_foo", ".foo"),
        ("modify_foo", "foo"),
        ("modify_dot_foo", ".foo"),
        ("remove_foo", "foo"),
        ("remove_dot_foo", ".foo"),
        ("symlink_foo", "foo"),
        ("run_foo", "foo"),
        ("run_once_foo", "foo"),
        ("run_onchange_foo", "foo"),
        ("run_before_foo", "foo"),
        ("run_after_foo", "foo"),
        ("run_once_before_foo", "foo"),
        ("dot_foo.tmpl", ".foo"),
    ]
    for name, _ in table:
        env.write(name, "x\n")
    lines = target_paths(env, [name for name, _ in table]).splitlines()
    # CATCHES: the attribute prefixes are a closed set that is stripped in one
    # pass; a re-implementation that loops until no prefix matches (or that
    # treats run_once_ etc. as attributes) produces different target names.
    assert lines == ["@ROOT@/home/" + target for _, target in table]


def test_target_path_prefix_stripping_order_is_fixed(env):
    """Prefix stripping follows a fixed per-type order, not repeated matching.

    `create_` only strips create_ then the attribute prefixes once, so a
    second create_ survives; `modify_` does not strip empty_; `run_` strips
    no attribute prefixes at all.
    """
    table = [
        # create_ branch: create_, encrypted_, private_, readOnly_, empty_,
        # executable_ -- in that order, once.
        ("create_empty_executable_private_readonly_dot_foo", "private_readonly_dot_foo"),
        ("create_executable_private_dot_foo", "private_dot_foo"),
        ("create_private_empty_executable_dot_foo", ".foo"),
        ("create_create_foo", "create_foo"),
        # modify_ branch has no empty_.
        ("modify_empty_dot_x", "empty_dot_x"),
        ("modify_executable_private_readonly_dot_y", "private_readonly_dot_y"),
        # run_ branch strips only run_ and the condition modifiers.
        ("run_private_foo", "private_foo"),
        ("run_once_private_foo", "private_foo"),
        # symlink_/remove_ strip only their own prefix.
        ("symlink_private_dot_w", "private_dot_w"),
        ("remove_create_x", "create_x"),
    ]
    for name, _ in table:
        env.write(name, "x\n")
    lines = target_paths(env, [name for name, _ in table]).splitlines()
    # CATCHES: parseFileAttr is a fixed-order switch, not a loop; the exact
    # leftovers (private_readonly_dot_foo, empty_dot_x, ...) encode which
    # prefixes each branch strips.
    assert lines == ["@ROOT@/home/" + target for _, target in table]


def test_target_path_literal_prefix(env):
    """literal_ suppresses all further prefix and suffix interpretation."""
    table = [
        ("literal_dot_bashrc", "dot_bashrc"),
        ("literal_create_foo", "create_foo"),
        ("literal_remove_bar", "remove_bar"),
        ("literal_empty_foo", "empty_foo"),
        ("literal_run_foo", "run_foo"),
        ("literal_foo", "foo"),
        ("literal_dot_foo.tmpl", "dot_foo"),
        ("literal_dot_foo.tmpl.literal", "dot_foo.tmpl"),
        ("dot_literal_foo", ".literal_foo"),
    ]
    for name, _ in table:
        env.write(name, "x\n")
    lines = target_paths(env, [name for name, _ in table]).splitlines()
    # CATCHES: literal_ is applied AFTER the attribute prefixes, and unlike
    # every other prefix it leaves the rest of the name completely untouched
    # (dot_bashrc stays dot_bashrc, .tmpl does not become a template).
    assert lines == ["@ROOT@/home/" + target for _, target in table]


def test_target_path_suffixes(env):
    """.literal beats .tmpl, and both are stripped to form the target name."""
    table = [
        ("foo.tmpl", "foo"),
        ("foo.literal", "foo"),
        ("foo.tmpl.literal", "foo.tmpl"),
        ("dot_foo.tmpl", ".foo"),
    ]
    for name, _ in table:
        env.write(name, "x\n")
    lines = target_paths(env, [name for name, _ in table]).splitlines()
    # CATCHES: .literal takes precedence over .tmpl and is stripped first,
    # so foo.tmpl.literal targets foo.tmpl -- not foo, and not foo.literal.
    assert lines == ["@ROOT@/home/" + target for _, target in table]


def test_target_path_encryption_suffixes_without_encryption(env):
    """Without encryption configured, .age/.asc are ordinary name parts."""
    table = [
        ("dot_foo.age", ".foo.age"),
        ("encrypted_dot_foo.age", ".foo.age"),
        ("encrypted_foo.asc", "foo.asc"),
    ]
    for name, _ in table:
        env.write(name, "x\n")
    lines = target_paths(env, [name for name, _ in table]).splitlines()
    # CATCHES: the encryption suffix is only stripped when the encrypted_
    # attribute prefix is present AND encryption is configured; a bare .age
    # suffix is left alone (dot_foo.age -> .foo.age, not .foo).
    assert lines == ["@ROOT@/home/" + target for _, target in table]


def test_target_path_age_suffix_with_encryption(env):
    """With age configured, encrypted_ + the age suffix are both stripped."""
    config, _ = make_age_config(env)
    env.write("encrypted_dot_e.age", "x\n")
    env.write("dot_foo.age", "x\n")
    env.write("encrypted_foo.asc", "x\n")
    result = env.run(
        [
            "target-path",
            "-c",
            str(config),
            *env.flags(),
            str(env.src / "encrypted_dot_e.age"),
            str(env.src / "dot_foo.age"),
            str(env.src / "encrypted_foo.asc"),
        ]
    )
    assert result.returncode == 0, result.stderr
    lines = env.norm(result.stdout).decode().splitlines()
    # CATCHES: only the configured suffix (.age) is stripped for encrypted
    # entries; dot_foo.age still maps to .foo.age and the .asc suffix of
    # encrypted_foo.asc is not the configured suffix so it survives.
    assert lines == ["@ROOT@/home/.e", "@ROOT@/home/.foo.age", "@ROOT@/home/foo.asc"]


def test_target_path_custom_age_suffix(env):
    """A custom [age] suffix changes which suffix encrypted_ strips."""
    config, recipient = make_age_config(env)
    identity = env.root / "age-identity.txt"
    custom = env.root / "custom-age.toml"
    custom.write_text(
        'encryption = "age"\n'
        "[age]\n"
        f'    identity = "{identity}"\n'
        f'    recipient = "{recipient}"\n'
        '    suffix = ".age2"\n'
    )
    env.write("dot_bar.age2", "x\n")
    env.write("dot_foo.age", "x\n")
    result = env.run(
        [
            "target-path",
            "-c",
            str(custom),
            *env.flags(),
            str(env.src / "dot_bar.age2"),
            str(env.src / "dot_foo.age"),
        ]
    )
    assert result.returncode == 0, result.stderr
    lines = env.norm(result.stdout).decode().splitlines()
    # CATCHES: the suffix comes from the encryption configuration, so with
    # suffix=".age2" a bare .age file is an ordinary name and keeps .age.
    assert lines == ["@ROOT@/home/.bar.age2", "@ROOT@/home/.foo.age"]


def test_target_path_empty_name_after_dot_is_invalid(env):
    """dot_ with nothing left after suffix stripping is an invalid path."""
    env.write("dot_.tmpl", "x\n")
    result = env.run(["target-path", *env.flags(), str(env.src / "dot_.tmpl")])
    assert result.returncode == 1
    # CATCHES: dot_ + .tmpl leaves an empty relative path, which is rejected
    # with this exact error rather than silently targeting the dest dir.
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: dot_.tmpl: invalid path\n"


def test_target_path_directory_names(env):
    """Directory prefixes: dot_, exact_, external_, private_, readonly_, literal_."""
    table = [
        ("dot_plain_d", ".plain_d"),
        ("exact_dot_d", ".d"),
        ("external_dot_d", ".d"),
        ("private_dot_d", ".d"),
        ("readonly_dot_d", ".d"),
        ("literal_d", "d"),
        ("literal_dot_d", "dot_d"),
        ("literal_exact_d", "exact_d"),
        ("private_exact_external_dot_d", "exact_external_dot_d"),
    ]
    for name, _ in table:
        env.mkdir(name)
    result = env.run(
        ["target-path", *env.flags(), *[str(env.src / name) for name, _ in table]]
    )
    assert result.returncode == 0, result.stderr
    lines = env.norm(result.stdout).decode().splitlines()
    # CATCHES: only exact_/external_ (and the attribute prefixes) are
    # recognized before dot_; literal_ disables all of them, and a prefix
    # that is not a dir prefix (like a second exact_) is left in the name.
    assert lines == ["@ROOT@/home/" + target for _, target in table]


def test_target_path_dir_entry_has_no_trailing_slash(env):
    """A source subdirectory maps to the target directory path, no slash."""
    env.mkdir("dot_vim")
    env.write("dot_vim/vimrc", "set nocompatible\n")
    result = env.run(["target-path", *env.flags(), str(env.src / "dot_vim")])
    assert result.returncode == 0, result.stderr
    # CATCHES: subdirectory targets print without a trailing separator,
    # unlike the source dir itself (see test_no_args_prints_directories).
    assert env.norm(result.stdout) == b"@ROOT@/home/.vim\n"


def test_no_args_prints_directories(env):
    """target-path/source-path with no args print dest/source dir, rc 0."""
    env.write("dot_bashrc", "hello\n")
    tp = env.run(["target-path", *env.flags()])
    sp = env.run(["source-path", *env.flags()])
    assert tp.returncode == 0
    assert sp.returncode == 0
    # CATCHES: with no arguments neither command errors; target-path prints
    # the destination directory and source-path the source directory, and
    # both are plain paths with no trailing slash.
    assert env.norm(tp.stdout) == b"@ROOT@/home\n"
    assert env.norm(sp.stdout) == b"@ROOT@/src\n"


def test_target_path_source_dir_itself_gets_trailing_slash(env):
    """target-path of the source directory prints the dest dir with a slash."""
    env.write("dot_bashrc", "hello\n")
    result = env.run(["target-path", *env.flags(), str(env.src)])
    assert result.returncode == 0, result.stderr
    # CATCHES: the source dir maps to an empty SourceRelDirPath whose target
    # form is dest + "/", a trailing slash that no other input produces.
    assert env.norm(result.stdout) == b"@ROOT@/home/\n"


def test_target_path_special_file_names(env):
    """.chezmoi* config file names and unknown-prefix names pass through."""
    env.write(".chezmoiignore", ".keep\n")
    env.write("plain_private_empty_executable_readonly_dot_q", "x\n")
    result = env.run(
        [
            "target-path",
            *env.flags(),
            str(env.src / ".chezmoiignore"),
            str(env.src / "plain_private_empty_executable_readonly_dot_q"),
        ]
    )
    assert result.returncode == 0, result.stderr
    lines = env.norm(result.stdout).decode().splitlines()
    # CATCHES: attribute prefixes are only stripped at the START of the name;
    # a file literally named plain_private_..._dot_q keeps its whole name,
    # and .chezmoiignore is a target in its own right, not a special case.
    assert lines == [
        "@ROOT@/home/.chezmoiignore",
        "@ROOT@/home/plain_private_empty_executable_readonly_dot_q",
    ]


@pytest.mark.parametrize(
    "name,target",
    [
        ("dot_bashrc", ".bashrc"),
        ("run_once_before_foo", "foo"),
        ("literal_dot_foo.tmpl.literal", "dot_foo.tmpl"),
    ],
)
def test_target_path_single_names(env, name, target):
    """Spot-check single name mappings with byte-exact full-line output."""
    env.write(name, "x\n")
    # CATCHES: each mapping is checked as a complete line (path prefix and
    # newline included), so a wrong target name or missing newline fails.
    assert target_paths(env, [name]) == f"@ROOT@/home/{target}\n"
