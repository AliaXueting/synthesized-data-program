"""The ``external_`` source-directory prefix.

Entries inside an ``external_`` directory are read literally: no attribute,
name, or suffix interpretation happens at all.  These tests pin the literal
reading, the target modes derived from the source files' own permissions,
the exact_ semantics of the external root vs. its subdirectories, the path
mapping round trip, and the interaction with ignore patterns.
"""

from __future__ import annotations

import os
import stat

from conftest import Env


def make_external_tree(env: Env) -> None:
    """Create src/external_dot_cfg with literal-named entries of all kinds."""
    env.write("dot_z", "z\n")
    cfg = env.src / "external_dot_cfg"
    cfg.mkdir()
    (cfg / "dot_plain").write_text("plain\n")
    (cfg / "dot_tpl.tmpl").write_text("not a template {{ .chezmoi.homeDir }}\n")
    (cfg / "run.sh").write_text("#!/bin/sh\necho would-run\n")
    (cfg / "secret").write_text("secret\n")
    (cfg / "locked").write_text("locked\n")
    (cfg / "empty").write_bytes(b"")
    os.symlink("dot_plain", cfg / "link")
    (cfg / "dot_sub").mkdir()
    (cfg / "dot_sub" / "nested").write_text("nested\n")
    # Source-side modes drive the applied target modes.
    os.chmod(cfg / "dot_plain", 0o644)
    os.chmod(cfg / "run.sh", 0o755)
    os.chmod(cfg / "secret", 0o600)
    os.chmod(cfg / "locked", 0o444)


def test_external_dir_names_are_literal(env):
    """external_ dir entries keep their raw names; nothing is interpreted."""
    make_external_tree(env)
    result = env.run(["managed", *env.flags()])
    # CATCHES: inside external_dot_cfg the names dot_plain, dot_tpl.tmpl and
    # run.sh are NOT parsed -- no dot_ stripping, no .tmpl template, no run_
    # script -- so the targets are .cfg/dot_plain, .cfg/dot_tpl.tmpl and
    # .cfg/run.sh verbatim, and the dir itself targets .cfg.
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == (
        ".cfg\n"
        ".cfg/dot_plain\n"
        ".cfg/dot_sub\n"
        ".cfg/dot_sub/nested\n"
        ".cfg/dot_tpl.tmpl\n"
        ".cfg/empty\n"
        ".cfg/link\n"
        ".cfg/locked\n"
        ".cfg/run.sh\n"
        ".cfg/secret\n"
        ".z\n"
    )
    source_relative = env.run(["managed", "-p", "source-relative", *env.flags()])
    # CATCHES: source-relative names are the literal external_ dir paths,
    # including the external_ prefix itself and the untouched dot_-style
    # file names inside.
    assert source_relative.returncode == 0, source_relative.stderr
    assert source_relative.stdout.decode() == (
        "dot_z\n"
        "external_dot_cfg\n"
        "external_dot_cfg/dot_plain\n"
        "external_dot_cfg/dot_sub\n"
        "external_dot_cfg/dot_sub/nested\n"
        "external_dot_cfg/dot_tpl.tmpl\n"
        "external_dot_cfg/empty\n"
        "external_dot_cfg/link\n"
        "external_dot_cfg/locked\n"
        "external_dot_cfg/run.sh\n"
        "external_dot_cfg/secret\n"
    )
    applied = env.run(["apply", *env.flags()])
    assert applied.returncode == 0, applied.stderr
    assert applied.stdout == b""
    # CATCHES: the .tmpl file is served byte-for-byte (no template engine),
    # the 0-byte file is KEPT (externals never treat empty as remove), and
    # the symlink is recreated pointing at the literal sibling name.
    assert (env.home / ".cfg/dot_tpl.tmpl").read_text() == (
        "not a template {{ .chezmoi.homeDir }}\n"
    )
    assert (env.home / ".cfg/empty").stat().st_size == 0
    assert stat.S_ISLNK(os.lstat(env.home / ".cfg/link").st_mode)
    assert os.readlink(env.home / ".cfg/link") == "dot_plain"
    contents = env.run(["cat", *env.flags(), str(env.home / ".cfg/dot_tpl.tmpl")])
    assert contents.returncode == 0, contents.stderr
    assert contents.stdout == b"not a template {{ .chezmoi.homeDir }}\n"


def test_external_dir_modes_come_from_source_files(env):
    """Target modes mirror the source files' own permission bits."""
    make_external_tree(env)
    result = env.run(["apply", *env.flags()], umask="022")
    assert result.returncode == 0, result.stderr
    modes = {
        name: stat.S_IMODE(os.stat(env.home / ".cfg" / name).st_mode)
        for name in ("dot_plain", "run.sh", "secret", "locked")
    }
    # CATCHES: a 0600 source file is applied 0600 (private), a 0444 file
    # 0444 (read-only), a 0755 file 0755 (executable), a 0644 file 0644 --
    # the modes are taken from the external_ dir entries themselves, not
    # from any name prefix, and not from the plain-file default 0666&~umask.
    assert modes == {
        "dot_plain": 0o644,
        "run.sh": 0o755,
        "secret": 0o600,
        "locked": 0o444,
    }
    assert stat.S_IMODE(os.stat(env.home / ".cfg").st_mode) == 0o755


def test_external_dir_root_not_exact_but_subdirs_are(env):
    """Strays survive directly under the external target, not in subdirs."""
    make_external_tree(env)
    env.write_home(".cfg/stray", "stray\n")
    env.write_home(".cfg/dot_sub/stray", "stray\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the external_ root .cfg is NOT exact (its strays survive),
    # but every directory inside it is exact (the .cfg/dot_sub stray is
    # removed by the same apply) -- asymmetric by construction.
    assert (env.home / ".cfg/stray").exists()
    assert not (env.home / ".cfg/dot_sub/stray").exists()
    assert (env.home / ".cfg/dot_sub/nested").exists()
    unmanaged = env.run(["unmanaged", *env.flags()])
    assert unmanaged.returncode == 0, unmanaged.stderr
    assert unmanaged.stdout.decode() == ".cfg/stray\n"


def test_external_dir_exact_root_removes_strays(env):
    """external_exact_ makes the external root exact too."""
    env.write("external_exact_dot_x/dot_a", "a\n")
    env.write_home(".x/stray", "stray\n")
    listed = env.run(["managed", *env.flags()])
    # CATCHES: with external_ AND exact_ combined, the pre-existing
    # unmanaged .x/stray becomes a managed REMOVE entry (listed by the
    # plain managed output before any apply).
    assert listed.returncode == 0, listed.stderr
    assert listed.stdout.decode() == ".x\n.x/dot_a\n.x/stray\n"
    applied = env.run(["apply", *env.flags()])
    assert applied.returncode == 0, applied.stderr
    assert not (env.home / ".x/stray").exists()
    assert (env.home / ".x/dot_a").read_text() == "a\n"


def test_external_dir_entries_are_not_externals_entry_type(env):
    """external_ dir entries never match the externals entry-type filter."""
    make_external_tree(env)
    default = env.run(["managed", *env.flags()])
    assert default.returncode == 0, default.stderr
    assert default.stdout != b""
    included = env.run(["managed", "-i", "externals", *env.flags()])
    # CATCHES: unlike .chezmoiexternal-declared externals, entries read from
    # an external_ directory have no external source attribute, so -i
    # externals lists NOTHING (rc 0) while -x externals keeps every entry.
    assert included.returncode == 0, included.stderr
    assert included.stdout == b""
    excluded = env.run(["managed", "-x", "externals", *env.flags()])
    assert excluded.returncode == 0, excluded.stderr
    assert excluded.stdout == default.stdout


def test_external_dir_path_mapping_round_trip_asymmetry(env):
    """source-path maps to literal names; target-path re-parses them."""
    make_external_tree(env)
    home = str(env.home)
    source_paths = env.run(
        [
            "source-path",
            *env.flags(),
            f"{home}/.cfg/dot_plain",
            f"{home}/.cfg/dot_sub",
            f"{home}/.cfg",
        ]
    )
    # CATCHES: source-path of external_ dir targets returns the LITERAL
    # source paths (no name decoding): .cfg maps to external_dot_cfg with
    # no trailing slash, .cfg/dot_sub to external_dot_cfg/dot_sub.
    assert source_paths.returncode == 0, source_paths.stderr
    assert env.normtext(source_paths.stdout.decode()) == (
        "@ROOT@/src/external_dot_cfg\n"
        "@ROOT@/src/external_dot_cfg/dot_plain\n"
        "@ROOT@/src/external_dot_cfg/dot_sub\n"
    )
    target_paths = env.run(
        [
            "target-path",
            *env.flags(),
            "src/external_dot_cfg/dot_plain",
            "src/external_dot_cfg",
        ]
    )
    # CATCHES: target-path PARSES the source name with the normal attribute
    # grammar, so external_dot_cfg/dot_plain maps to .cfg/.plain (dot_
    # stripped to a dot) -- the mapping does not round-trip through
    # source-path, which returned the literal external_dot_cfg/dot_plain.
    assert target_paths.returncode == 0, target_paths.stderr
    assert env.normtext(target_paths.stdout.decode()) == (
        "@ROOT@/home/.cfg/.plain\n@ROOT@/home/.cfg\n"
    )


def test_external_dir_ignore_patterns_filter_entries(env):
    """.chezmoiignore filters entries inside external_ directories."""
    make_external_tree(env)
    env.write(".chezmoiignore", ".cfg/dot_plain\n.cfg/dot_sub\n")
    result = env.run(["managed", *env.flags()])
    # CATCHES: ignore patterns are matched against the TARGET paths of
    # external_ dir entries, removing both the file .cfg/dot_plain and the
    # whole .cfg/dot_sub subtree from the listing while the other literal
    # entries survive.
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == (
        ".cfg\n"
        ".cfg/dot_tpl.tmpl\n"
        ".cfg/empty\n"
        ".cfg/link\n"
        ".cfg/locked\n"
        ".cfg/run.sh\n"
        ".cfg/secret\n"
        ".z\n"
    )


def test_fifo_in_external_dir_is_silently_ignored(env):
    """A FIFO inside an external_ dir is skipped, not an error."""
    env.write("dot_a", "a\n")
    cfg = env.src / "external_dot_cfg"
    cfg.mkdir()
    os.mkfifo(cfg / "pipename")
    (cfg / "file").write_text("f\n")
    listed = env.run(["managed", *env.flags()])
    # CATCHES: a FIFO anywhere else in the source dir aborts the command
    # with "unsupported file type named pipe", but inside an external_
    # directory it is silently dropped -- managed lists only .cfg and
    # .cfg/file, and apply succeeds without creating the FIFO.
    assert listed.returncode == 0, listed.stderr
    assert listed.stdout.decode() == ".a\n.cfg\n.cfg/file\n"
    applied = env.run(["apply", *env.flags()])
    assert applied.returncode == 0, applied.stderr
    assert applied.stdout == b""
    assert not os.path.lexists(env.home / ".cfg/pipename")
    assert (env.home / ".cfg/file").read_text() == "f\n"
