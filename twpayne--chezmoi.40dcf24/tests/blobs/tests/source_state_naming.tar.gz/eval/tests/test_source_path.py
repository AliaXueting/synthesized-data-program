"""source-path / target-path argument handling, errors and directory config."""

from __future__ import annotations


def test_source_path_maps_targets_to_source_names(env):
    """source-path prints the source path for managed dest entries."""
    env.write("dot_bashrc", "hello\n")
    env.mkdir("dot_vim")
    env.write("dot_vim/vimrc", "set nocompatible\n")
    env.mkdir("exact_dot_config")
    env.write("exact_dot_config/foo", "x\n")
    result = env.run(
        [
            "source-path",
            *env.flags(),
            str(env.home / ".bashrc"),
            str(env.home / ".vim"),
            str(env.home / ".vim/vimrc"),
            str(env.home / ".config"),
            str(env.home / ".config/foo"),
        ]
    )
    assert result.returncode == 0, result.stderr
    lines = env.norm(result.stdout).decode().splitlines()
    # CATCHES: the mapping is the exact inverse of the naming language
    # (.bashrc -> dot_bashrc, .config -> exact_dot_config), and with
    # multiple arguments the results come back sorted by TARGET path
    # (.bashrc, .config, .config/foo, .vim, .vim/vimrc), not in argument
    # order.
    assert lines == [
        "@ROOT@/src/dot_bashrc",
        "@ROOT@/src/exact_dot_config",
        "@ROOT@/src/exact_dot_config/foo",
        "@ROOT@/src/dot_vim",
        "@ROOT@/src/dot_vim/vimrc",
    ]


def test_source_path_relative_argument_error(env):
    """Relative target arguments resolve against the cwd, then fail."""
    env.write("dot_bashrc", "hello\n")
    result = env.run(["source-path", *env.flags(), ".bashrc"])
    assert result.returncode == 1
    # CATCHES: source-path does not interpret bare names against the dest
    # dir; the argument is joined to the process cwd, which in this harness
    # is the scratch root, producing this exact message.
    assert result.stdout == b""
    assert (
        env.norm(result.stderr)
        == b"chezmoi: @ROOT@/.bashrc: not in destination directory (@ROOT@/home)\n"
    )


def test_source_path_unmanaged_target(env):
    """A dest path that exists but is not managed is `not managed`."""
    env.write("dot_bashrc", "hello\n")
    env.write_home(".untracked", "u\n")
    result = env.run(["source-path", *env.flags(), str(env.home / ".untracked")])
    assert result.returncode == 1
    # CATCHES: unmanaged-but-existing dest paths get "not managed" (rc 1),
    # distinct from the "not in destination directory" shape for outside
    # paths, and stdout stays empty.
    assert result.stdout == b""
    assert env.norm(result.stderr) == b"chezmoi: @ROOT@/home/.untracked: not managed\n"


def test_target_path_argument_outside_source(env):
    """target-path rejects arguments outside the source directory."""
    result = env.run(["target-path", *env.flags(), str(env.root / "dot_bashrc")])
    assert result.returncode == 1
    # CATCHES: the error names the offending path and the source dir, and
    # the path is the cwd-joined argument (@ROOT@/dot_bashrc), not a dest
    # path -- target-path args are source paths.
    assert env.norm(result.stderr) == b"chezmoi: @ROOT@/dot_bashrc: not in @ROOT@/src\n"


def test_target_path_missing_source_entry(env):
    """target-path of a nonexistent source path fails with a stat error."""
    result = env.run(["target-path", *env.flags(), str(env.src / "nope")])
    assert result.returncode == 1
    # CATCHES: the error is the raw stat error including the source path,
    # not a chezmoi-specific "not managed" message.
    assert env.norm(result.stderr) == (
        b"chezmoi: stat @ROOT@/src/nope: no such file or directory\n"
    )


def test_source_dir_from_config_file(env):
    """The sourceDir config key selects the source directory."""
    other = env.root / "elsewhere"
    other.mkdir()
    (other / "dot_bashrc").write_text("hello\n")
    config = env.root / "config.toml"
    config.write_text(f'sourceDir = "{other}"\n')
    result = env.run(
        [
            "managed",
            "-c",
            str(config),
            "--destination",
            str(env.home),
            "-p",
            "source-absolute",
        ]
    )
    assert result.returncode == 0, result.stderr
    # CATCHES: with no --source flag the config file's sourceDir wins over
    # the default ~/.local/share/chezmoi, and managed reports entries from
    # that directory.
    assert env.norm(result.stdout) == b"@ROOT@/elsewhere/dot_bashrc\n"


def test_source_flag_overrides_config(env):
    """-S/--source takes precedence over the sourceDir config key."""
    other = env.root / "elsewhere"
    other.mkdir()
    (other / "dot_elsewhere").write_text("x\n")
    env.write("dot_insrc", "y\n")
    config = env.root / "config.toml"
    config.write_text(f'sourceDir = "{other}"\n')
    result = env.run(
        [
            "managed",
            "-c",
            str(config),
            *env.flags(),
            "-p",
            "source-absolute",
        ]
    )
    assert result.returncode == 0, result.stderr
    # CATCHES: --source beats the config file's sourceDir; the listing comes
    # from the flag directory and the config entry dot_elsewhere is absent.
    assert env.norm(result.stdout) == b"@ROOT@/src/dot_insrc\n"


def test_dest_dir_from_config_file(env):
    """The destDir config key selects the destination directory."""
    dest = env.root / "mydest"
    dest.mkdir()
    config = env.root / "config.toml"
    config.write_text(f'destDir = "{dest}"\n')
    env.write("dot_bashrc", "hello\n")
    result = env.run(
        ["managed", "-c", str(config), "--source", str(env.src), "-p", "absolute"]
    )
    assert result.returncode == 0, result.stderr
    # CATCHES: destDir from the config changes the absolute path style even
    # though HOME points elsewhere; managed lists @ROOT@/mydest/.bashrc.
    assert env.norm(result.stdout) == b"@ROOT@/mydest/.bashrc\n"


def test_relative_source_flag_resolves_against_cwd(env):
    """A relative --source value is resolved against the working directory."""
    env.write("dot_bashrc", "hello\n")
    result = env.run(
        ["managed", "--source", "src", "--destination", str(env.home), "-p", "absolute"]
    )
    assert result.returncode == 0, result.stderr
    # CATCHES: relative --source is cwd-relative (here the scratch root), so
    # "src" finds the source dir and the absolute listing is @ROOT@/home/...
    assert env.norm(result.stdout) == b"@ROOT@/home/.bashrc\n"
