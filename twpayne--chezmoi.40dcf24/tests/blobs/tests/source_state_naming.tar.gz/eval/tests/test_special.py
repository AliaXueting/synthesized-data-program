"""Special source files: .chezmoiroot, .chezmoiversion, .chezmoitemplates,
.chezmoidata, and inconsistent-state detection."""

from __future__ import annotations

import pytest


def test_chezmoiroot_selects_subdirectory(env):
    """.chezmoiroot points the source state at a repo subdirectory."""
    env.mkdir("src-home/dot_vim")
    env.write("src-home/dot_bashrc", "rc\n")
    env.write("src-home/dot_vim/vimrc", "vim\n")
    env.write(".chezmoiroot", "src-home\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: with .chezmoiroot = src-home the entries under src-home/
    # are the source state (targets .bashrc, .vim, .vim/vimrc) while the
    # .chezmoiroot file itself is not a managed target.
    assert result.stdout.decode() == ".bashrc\n.vim\n.vim/vimrc\n"


def test_chezmoiroot_entries_resolve_via_source_path(env):
    """source-path maps through the .chezmoiroot indirection."""
    env.mkdir("src-home")
    env.write("src-home/dot_bashrc", "rc\n")
    env.write(".chezmoiroot", "src-home\n")
    result = env.run(["source-path", *env.flags(), str(env.home / ".bashrc")])
    assert result.returncode == 0, result.stderr
    # CATCHES: the source path keeps the src-home component in it, proving
    # the root file relocates the source state rather than renaming files.
    assert env.norm(result.stdout) == b"@ROOT@/src/src-home/dot_bashrc\n"


def test_chezmoiroot_nonexistent_content_is_empty(env):
    """.chezmoiroot naming a missing directory lists nothing, rc 0."""
    env.mkdir("src-home")
    env.write("src-home/dot_bashrc", "rc\n")
    env.write(".chezmoiroot", "src-home\n")
    working = env.run(["managed", *env.flags()])
    assert working.returncode == 0, working.stderr
    assert working.stdout.decode() == ".bashrc\n"
    env.write(".chezmoiroot", "does-not-exist\n")
    result = env.run(["managed", *env.flags()])
    # CATCHES: the same source dir that listed .bashrc via a valid
    # .chezmoiroot lists nothing once the root points at a missing
    # directory -- a dangling .chezmoiroot is not an error, managed exits 0
    # with empty output exactly like a missing source directory.
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""


@pytest.mark.parametrize("version", ["999.0.0\n", "1.0.0\n"])
def test_chezmoiversion_valid(env, version):
    """A dotted-tri .chezmoiversion parses without error at any value."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiversion", version)
    result = env.run(["managed", *env.flags()])
    # CATCHES: version checking is parse-only here (no comparison against
    # the binary's own version); even a future version like 999.0.0 is
    # accepted and managed lists normally.
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == ".a\n"


@pytest.mark.parametrize(
    "version,message",
    [
        (
            "notaversion\n",
            b'chezmoi: @ROOT@/src/.chezmoiversion: "notaversion\\n": '
            b"notaversion is not in dotted-tri format\n",
        ),
        (
            "2.0\n",
            b'chezmoi: @ROOT@/src/.chezmoiversion: "2.0\\n": '
            b"2.0 is not in dotted-tri format\n",
        ),
        (
            "\n",
            b'chezmoi: @ROOT@/src/.chezmoiversion: "\\n": '
            b"is not in dotted-tri format\n",
        ),
        (
            "v2.0.0\n",
            b'chezmoi: @ROOT@/src/.chezmoiversion: "v2.0.0\\n": '
            b'strconv.ParseInt: parsing "v2": invalid syntax\n',
        ),
    ],
)
def test_chezmoiversion_invalid(env, version, message):
    """Malformed .chezmoiversion contents fail with the parsed text in %q form."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiversion", version)
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: the raw file bytes (including the newline) are printed in Go
    # %q quoting, and each malformation has its own message: a non-version,
    # a missing component (2.0), empty content, and a v-prefixed number
    # that fails integer parsing on its first field.
    assert result.stdout == b""
    assert env.norm(result.stderr) == message


def test_templates_directory_include(env):
    """.chezmoitemplates files are included via includeTemplate."""
    env.mkdir(".chezmoitemplates")
    env.write(".chezmoitemplates/greeting.tmpl", "Hello from template {{ .name }}\n")
    env.write(".chezmoitemplates/frag.txt", "value-from-template\n")
    env.write("dot_greeting.tmpl", '{{ includeTemplate "greeting.tmpl" (dict "name" "world") }}')
    env.write("dot_frag.tmpl", 'x{{ includeTemplate "frag.txt" }}y\n')
    greeting = env.run(["cat", *env.flags(), str(env.home / ".greeting")])
    frag = env.run(["cat", *env.flags(), str(env.home / ".frag")])
    assert greeting.returncode == frag.returncode == 0
    # CATCHES: includeTemplate executes the named file from
    # .chezmoitemplates with the given argument dict, and a non-.tmpl
    # template file (frag.txt) is included as literal text; note the
    # trailing newline of the included file is preserved (frag's y lands
    # on its own line).
    assert greeting.stdout == b"Hello from template world\n"
    assert frag.stdout == b"xvalue-from-template\ny\n"


def test_template_data_merged_from_data_files(env):
    """.chezmoidata.yaml and .chezmoidata/ files merge into template data."""
    env.write(".chezmoidata.yaml", "name: myname\n")
    env.mkdir(".chezmoidata")
    env.write(".chezmoidata/extra.toml", 'other = "data2"\n')
    env.write("dot_data.tmpl", "data:{{ .name }}:{{ .other }}\n")
    result = env.run(["cat", *env.flags(), str(env.home / ".data")])
    assert result.returncode == 0, result.stderr
    # CATCHES: the top-level .chezmoidata.yaml and every file inside
    # .chezmoidata/ contribute keys to the same template data map, so one
    # template can use .name and .other from two different files.
    assert result.stdout == b"data:myname:data2\n"


def test_template_source_file_variable(env):
    """.chezmoi.sourceFile is set to the source name during execution."""
    env.write("dot_sf.tmpl", "src:{{ .chezmoi.sourceFile }}\n")
    result = env.run(["cat", *env.flags(), str(env.home / ".sf")])
    assert result.returncode == 0, result.stderr
    # CATCHES: the special .chezmoi.sourceFile variable holds the source
    # file's name (dot_sf.tmpl), not the target name (.sf).
    assert result.stdout == b"src:dot_sf.tmpl\n"


def test_template_missing_include_error(env):
    """includeTemplate of a nonexistent template fails with a template error."""
    env.mkdir(".chezmoitemplates")
    env.write(".chezmoitemplates/greeting.tmpl", "Hello\n")
    env.write("dot_bad.tmpl", '{{ includeTemplate "nope.tmpl" }}')
    result = env.run(["cat", *env.flags(), str(env.home / ".bad")])
    assert result.returncode == 1
    # CATCHES: the error is a text/template execution error naming the
    # template file (dot_bad.tmpl), the line:column (1:3) and the open
    # failure of the missing file under the source directory.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b'chezmoi: .bad: template: dot_bad.tmpl:1:3: executing "dot_bad.tmpl" '
        b"at <includeTemplate \x22nope.tmpl\x22>: error calling includeTemplate: "
        b"open @ROOT@/src/nope.tmpl: no such file or directory\n"
    )


def test_inconsistent_state_file(env):
    """Two source entries mapping to one target is an inconsistent state."""
    env.write("dot_bad", "a\n")
    env.write("dot_bad.tmpl", "a\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: a file and its .tmpl sibling both target .bad; the error
    # lists every colliding source path sorted, and no managed output is
    # produced at all.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: .bad: inconsistent state "
        b"(@ROOT@/src/dot_bad, @ROOT@/src/dot_bad.tmpl)\n"
    )


def test_inconsistent_state_scripts(env):
    """run_ and run_once_ for the same script name are inconsistent."""
    env.write("run_script.sh", "#!/bin/sh\necho hi\n")
    env.write("run_once_script.sh", "#!/bin/sh\necho hi\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: both scripts target script.sh; the collision is reported
    # with both source paths in sorted order and aborts the whole command.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: script.sh: inconsistent state "
        b"(@ROOT@/src/run_once_script.sh, @ROOT@/src/run_script.sh)\n"
    )


def test_inconsistent_state_directories(env):
    """Multiple dir prefixes mapping to one dir are inconsistent."""
    for name in ("exact_dot_d", "external_dot_d", "private_dot_d", "readonly_dot_d"):
        env.mkdir(name)
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: exact_/external_/private_/readonly_ all target .d; the error
    # enumerates all four source dirs sorted -- only ONE dir attribute
    # combination per target is legal.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: .d: inconsistent state (@ROOT@/src/exact_dot_d, "
        b"@ROOT@/src/external_dot_d, @ROOT@/src/private_dot_d, "
        b"@ROOT@/src/readonly_dot_d)\n"
    )


def test_inconsistent_state_with_remove_origin(env):
    """A .chezmoiremove entry colliding with a source file reports `remove`."""
    env.write("dot_x", "a\n")
    env.write(".chezmoiremove", ".x\n")
    env.write_home(".x", "x\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: the .chezmoiremove-generated absent entry has no source
    # path, so its origin in the inconsistent-state error is the literal
    # string "remove" -- sorted after the colliding source file's path --
    # and the collision aborts the whole command with no listing.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: .x: inconsistent state (@ROOT@/src/dot_x, remove)\n"
    )


def test_hidden_source_entries_are_skipped(env):
    """Dot entries in the source dir are skipped unless .chezmoi-prefixed."""
    env.write("dot_a", "a\n")
    env.mkdir(".git")
    env.write(".git/config", "[core]\n")
    env.write(".hidden", "h\n")
    env.mkdir(".hidden_dir")
    env.write(".hidden_dir/f", "f\n")
    env.write(".chezmoiunknown", "x\n")
    env.write("run_noshebang.sh", "no shebang\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: files and dirs starting with a dot are ignored by the source
    # walk (including .git and unknown .chezmoi* files), but run_ scripts
    # without a shebang or exec bit are still managed entries.
    assert result.stdout.decode() == ".a\nnoshebang.sh\n"
