"""HTTP externals: the response cache under <cacheDir>/httpcache.

url externals fetched over http:// go through chezmoi's caching HTTP
transport, which stores responses on disk under the --cache directory and
re-serves them without re-downloading while they are fresh.  The servers
here are loopback-only (127.0.0.1 on an ephemeral port), so no external
network is involved.
"""

from __future__ import annotations

import http.server
import socketserver
import threading


class LoopbackServer:
    """A tiny loopback HTTP server whose body and status are mutable.

    Every GET is recorded in ``requests`` as the value of its
    If-Modified-Since header (None when absent), so tests can assert
    exactly how many times the candidate actually reached the wire.
    """

    def __init__(self, last_modified=None):
        self.body = b"body-one\n"
        self.status = 200
        self.requests = []
        outer = self

        class Handler(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def do_GET(self):
                outer.requests.append(self.headers.get("If-Modified-Since"))
                body = outer.body
                self.send_response(outer.status)
                self.send_header("Content-Type", "text/plain")
                self.send_header("Content-Length", str(len(body)))
                if last_modified:
                    self.send_header("Last-Modified", last_modified)
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        self.server = socketserver.ThreadingTCPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *exc):
        self.server.shutdown()
        self.server.server_close()

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}/plug.txt"

    def define_external(self, env):
        env.write(
            ".chezmoiexternal.toml",
            f'[".h"]\n    type = "file"\n    url = "{self.url}"\n',
        )


def test_http_external_response_cache_serves_second_fetch(env):
    """A response with a validator is re-served from the cache, not the wire."""
    with LoopbackServer(last_modified="Fri, 01 Jan 2021 00:00:00 GMT") as server:
        server.define_external(env)
        first = env.run(["cat", *env.flags(), str(env.home / ".h")])
        assert first.returncode == 0, first.stderr
        assert first.stdout == b"body-one\n"
        server.body = b"body-two\n"
        second = env.run(
            ["cat", *env.flags(), "-R=always", str(env.home / ".h")]
        )
        # CATCHES: -R=always bypasses the externals download cache but NOT
        # the HTTP response cache: the stored body-one is re-served even
        # though the server now returns body-two, and the server sees just
        # the one original request (no revalidation either) -- while the
        # cache directory under --cache holds the persisted entries.
        assert second.returncode == 0, second.stderr
        assert second.stdout == b"body-one\n"
        assert second.stderr == b""
        assert server.requests == [None]
        httpcache = env.cache / "httpcache"
        assert httpcache.is_dir()
        assert list(httpcache.iterdir()) != []


def test_http_external_refetched_without_validator(env):
    """A response without validators is re-downloaded on every fetch."""
    with LoopbackServer() as server:
        server.define_external(env)
        first = env.run(["cat", *env.flags(), str(env.home / ".h")])
        assert first.returncode == 0, first.stderr
        assert first.stdout == b"body-one\n"
        server.body = b"body-two\n"
        second = env.run(
            ["cat", *env.flags(), "-R=always", str(env.home / ".h")]
        )
        # CATCHES: with no Last-Modified and no Cache-Control the stored
        # response cannot be proven fresh, so the second fetch goes back to
        # the wire: the new body-two is served and the server recorded a
        # second unconditional GET.
        assert second.returncode == 0, second.stderr
        assert second.stdout == b"body-two\n"
        assert server.requests == [None, None]


def test_http_external_error_status(env):
    """A non-2xx HTTP status becomes an error naming target, URL and status."""
    with LoopbackServer() as server:
        server.define_external(env)
        server.status = 404
        result = env.run(["cat", *env.flags(), str(env.home / ".h")])
        # CATCHES: the 404 response body is discarded; the error text is
        # "<target>: <url>: <status line>" with no wrapper around it, and
        # nothing is written to stdout or to the target.
        assert result.returncode == 1
        assert result.stdout == b""
        assert result.stderr == (
            f"chezmoi: .h: {server.url}: 404 Not Found\n".encode()
        )
        assert not (env.home / ".h").exists()
