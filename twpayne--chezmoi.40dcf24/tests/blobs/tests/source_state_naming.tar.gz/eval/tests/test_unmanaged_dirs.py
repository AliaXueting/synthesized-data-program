"""unmanaged listings and directory-attribute behavior on apply."""

from __future__ import annotations


def populate(env):
    """Dest with managed .config/c and unmanaged siblings (the u1 tree)."""
    env.mkdir("dot_config")
    env.write("dot_a", "a\n")
    env.write("dot_config/c", "c\n")
    env.write_home(".config/c", "x\n")
    env.write_home(".config/other", "y\n")
    env.write_home(".untracked/f", "z\n")
    env.write_home(".plain", "")


def test_unmanaged_lists_dest_only_entries(env):
    """unmanaged lists dest files not covered by the source state."""
    populate(env)
    result = env.run(["unmanaged", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: a partially-managed directory (.config) is not itself
    # listed, only its unmanaged child (.config/other); an unmanaged
    # DIRECTORY (.untracked) is listed alone without its children.
    assert result.stdout.decode() == ".config/other\n.plain\n.untracked\n"


def test_unmanaged_tree(env):
    """unmanaged -t nests unmanaged files under their directories."""
    populate(env)
    result = env.run(["unmanaged", *env.flags(), "-t"])
    assert result.returncode == 0, result.stderr
    # CATCHES: tree mode re-indents .config/other under a .config node
    # that flat mode never prints, while .untracked (a dir with children)
    # still prints as a single leaf.
    assert result.stdout.decode() == ".config\n  other\n.plain\n.untracked\n"


def test_unmanaged_nul(env):
    """unmanaged -0 separates and terminates entries with NUL."""
    populate(env)
    result = env.run(["unmanaged", *env.flags(), "-0"])
    assert result.returncode == 0, result.stderr
    # CATCHES: NUL mode emits one \0 per entry including the last, with no
    # trailing newline -- byte-identical structure to managed -0.
    assert result.stdout == b".config/other\x00.plain\x00.untracked\x00"


def test_unmanaged_argument_filter(env):
    """A positional argument restricts unmanaged to paths under it."""
    populate(env)
    result = env.run(["unmanaged", *env.flags(), str(env.home / ".config")])
    assert result.returncode == 0, result.stderr
    # CATCHES: filtering by the .config dest dir yields only
    # .config/other; the managed .config/c is excluded and .plain /
    # .untracked fall outside the subtree.
    assert result.stdout.decode() == ".config/other\n"


def test_exact_dir_removes_unmanaged_leftovers(env):
    """exact_ dirs delete dest entries not present in the source."""
    env.mkdir("exact_dot_ed")
    env.write("exact_dot_ed/a", "a\n")
    env.write_home(".ed/extra", "x\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: apply prunes .ed/extra because exact_ declares the dest dir
    # an exact mirror of the source; only .ed/a remains.
    assert sorted(str(p.relative_to(env.home)) for p in env.home.rglob("*")) == [
        ".ed",
        ".ed/a",
    ]


def test_plain_dir_keeps_unmanaged_entries(env):
    """A plain dot_ dir leaves unmanaged dest entries alone."""
    env.mkdir("dot_keep")
    env.write("dot_keep/b", "b\n")
    env.write_home(".keep/sub/y", "y\n")
    env.write_home(".keep/stray", "s\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    found = sorted(str(p.relative_to(env.home)) for p in env.home.rglob("*"))
    # CATCHES: without exact_, apply adds .keep/b but neither deletes nor
    # rewrites the pre-existing sub/ and stray entries.
    assert found == [".keep", ".keep/b", ".keep/stray", ".keep/sub", ".keep/sub/y"]


def test_remove_dir_removed_once_emptied(env):
    """remove_ entries are removed children-first, then the emptied dir."""
    env.mkdir("remove_dot_rd")
    env.write("remove_dot_rd/remove_dot_file", "r\n")
    env.write_home(".rd/.file", "x\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: remove_dot_file targets .rd/.file (the dot_ survives the
    # remove_ prefix); apply deletes it first and then, finding the remove_
    # directory empty, removes .rd itself -- the dest dir ends up empty.
    assert list(env.home.iterdir()) == []


def test_remove_dir_removed_even_when_vacant(env):
    """An empty remove_ source dir removes a pre-existing empty dest dir."""
    env.mkdir("remove_dot_rd")
    env.mkdir("dot_keep")
    env.write("dot_keep/b", "b\n")
    (env.home / ".rd").mkdir()
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    found = sorted(str(p.relative_to(env.home)) for p in env.home.rglob("*"))
    # CATCHES: a remove_ dir with no source children removes the dest
    # directory (here a pre-existing empty .rd) while the sibling plain
    # dir .keep is populated normally.
    assert found == [".keep", ".keep/b"]


def test_remove_dir_kept_when_stray_entries_remain(env):
    """A remove_ dir with an unmanaged leftover entry is not removed."""
    env.mkdir("remove_dot_rd2")
    env.write("dot_marker", "m\n")
    (env.home / ".rd2/leftover").mkdir(parents=True)
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    found = sorted(str(p.relative_to(env.home)) for p in env.home.rglob("*"))
    # CATCHES: apply demonstrably ran (the sibling dot_marker was created),
    # yet the empty-directory removal only fires when the dir is actually
    # empty; the unmanaged .rd2/leftover directory blocks it, so .rd2
    # survives with the stray directory inside.
    assert found == [".marker", ".rd2", ".rd2/leftover"]
    assert (env.home / ".marker").read_text() == "m\n"
