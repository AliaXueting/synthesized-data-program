"""git-repo externals: the SourceStateCommand clone/pull lifecycle.

A `type = "git-repo"` external becomes a synthetic command entry in the
source state: `git clone` when the destination directory is absent, `git
pull` when it exists.  git's own stdout/stderr pass through to chezmoi's,
and re-running the command is gated by the persistent state and
refreshPeriod exactly like url externals.
"""

from __future__ import annotations

import subprocess
import time

GIT_ENV = {
    "PATH": "/usr/bin:/bin",
    "GIT_CONFIG_GLOBAL": "/dev/null",
    "GIT_CONFIG_NOSYSTEM": "1",
}


def git(repo, *args):
    """Run git in REPO and return the completed process."""
    return subprocess.run(
        ["git", *args],
        cwd=str(repo),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**GIT_ENV, "HOME": str(repo.parent / "home")},
        check=True,
    )


def make_repo(env):
    """Create a local git repository with one committed file f.txt."""
    repo = env.root / "repo"
    repo.mkdir(parents=True)
    git(repo, "init", "-q", "-b", "main")
    git(repo, "config", "user.email", "t@example.com")
    git(repo, "config", "user.name", "t")
    (repo / "f.txt").write_text("one\n")
    git(repo, "add", "-A")
    git(repo, "commit", "-qm", "one")
    return repo


def commit(repo, name, content):
    """Commit a new file NAME with CONTENT into REPO."""
    (repo / name).write_text(content)
    git(repo, "add", "-A")
    git(repo, "commit", "-qm", "add " + name)


def define_git_external(env, repo, target=".plug", extra=""):
    """Write a .chezmoiexternal.toml defining a git-repo external."""
    return env.write(
        ".chezmoiexternal.toml",
        f'["{target}"]\n    type = "git-repo"\n    url = "file://{repo}"\n{extra}',
    )


def test_gitrepo_managed_listing(env):
    """managed lists the git-repo target; its source name is empty."""
    repo = make_repo(env)
    define_git_external(env, repo)
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the git-repo external contributes exactly one listing entry,
    # its target path .plug, under the default include set and under both
    # -i externals and -i dirs -- and its source-relative name is the EMPTY
    # string (the synthetic command entry has no source file), so
    # source-relative prints a single blank line.
    assert result.stdout == b".plug\n"
    for include in ("externals", "dirs"):
        filtered = env.run(["managed", *env.flags(), "-i", include])
        assert filtered.returncode == 0, (include, filtered.stderr)
        assert filtered.stdout == b".plug\n", include
    source_names = env.run(["managed", *env.flags(), "-p", "source-relative"])
    assert source_names.returncode == 0, source_names.stderr
    assert source_names.stdout == b"\n"


def test_gitrepo_apply_clones(env):
    """apply clones the repository into the destination directory."""
    repo = make_repo(env)
    define_git_external(env, repo)
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the clone runs `git clone <url> <dest>`; git's progress goes
    # to stderr byte-exactly ("Cloning into '<dest>'...") with nothing on
    # stdout, and the working tree (including .git) lands under .plug.
    assert result.stdout == b""
    assert env.norm(result.stderr) == b"Cloning into '@ROOT@/home/.plug'...\n"
    assert (env.home / ".plug/f.txt").read_text() == "one\n"
    assert (env.home / ".plug/.git").is_dir()


def test_gitrepo_apply_repulls_only_when_forced(env):
    """After cloning, a default apply never re-pulls; -R=always does."""
    repo = make_repo(env)
    define_git_external(env, repo)
    assert env.run(["apply", *env.flags()]).returncode == 0
    commit(repo, "second.txt", "second\n")
    skipped = env.run(["apply", *env.flags()])
    # CATCHES: with no refreshPeriod the recorded run state skips the pull
    # forever -- a default apply prints NOTHING (no git output at all) and
    # the new upstream commit is not fetched, even though the clone from
    # the same test demonstrably worked.
    assert skipped.returncode == 0, skipped.stderr
    assert skipped.stdout == b""
    assert skipped.stderr == b""
    assert not (env.home / ".plug/second.txt").exists()
    assert (env.home / ".plug/f.txt").read_text() == "one\n"
    forced = env.run(["apply", *env.flags(), "-R=always"])
    # CATCHES: -R=always bypasses the skip state and pulls: second.txt
    # arrives, and a second forced pull with nothing to fetch prints git's
    # exact "Already up to date." line on stdout and nothing on stderr.
    assert forced.returncode == 0, forced.stderr
    assert (env.home / ".plug/second.txt").read_text() == "second\n"
    forced_again = env.run(["apply", *env.flags(), "-R=always"])
    assert forced_again.returncode == 0, forced_again.stderr
    assert forced_again.stdout == b"Already up to date.\n"
    assert forced_again.stderr == b""


def test_gitrepo_refresh_period_expiry_repulls(env):
    """An elapsed refreshPeriod re-pulls without any -R flag."""
    repo = make_repo(env)
    define_git_external(env, repo, extra='    refreshPeriod = "1ms"\n')
    assert env.run(["apply", *env.flags()]).returncode == 0
    commit(repo, "second.txt", "second\n")
    time.sleep(0.05)
    result = env.run(["apply", *env.flags()])
    # CATCHES: refreshPeriod gates the persistent-state skip: once the 1ms
    # period has elapsed a plain auto apply re-runs the pull and fetches
    # second.txt, with no -R=always needed.
    assert result.returncode == 0, result.stderr
    assert (env.home / ".plug/second.txt").read_text() == "second\n"


def test_gitrepo_pull_fails_when_dest_is_not_a_repo(env):
    """An existing non-repo destination turns the pull into an error."""
    repo = make_repo(env)
    define_git_external(env, repo)
    (env.home / ".plug").mkdir()
    result = env.run(["apply", *env.flags()])
    # CATCHES: because .plug exists chezmoi runs `git pull` in it; git's
    # fatal line passes through to stderr and chezmoi wraps the exit status
    # as "<target>: <dest>: exit status 128".
    assert result.returncode == 1
    assert result.stdout == b""
    assert b"fatal: not a git repository (or any of the parent directories): .git\n" in result.stderr
    assert env.norm(result.stderr).endswith(
        b"chezmoi: .plug: @ROOT@/home/.plug: exit status 128\n"
    )


def test_gitrepo_clone_failure(env):
    """A clone from a nonexistent repository reports git's failure."""
    define_git_external(env, env.root / "no-such-repo", target=".bad")
    result = env.run(["apply", *env.flags()])
    # CATCHES: git's own diagnostics stream through, and chezmoi's error
    # names the external's target and the destination path with git's exit
    # status -- the clone failed, it is not retried or ignored.
    assert result.returncode == 1
    assert result.stdout == b""
    assert b"does not appear to be a git repository" in result.stderr
    assert env.norm(result.stderr).endswith(
        b"chezmoi: .bad: @ROOT@/home/.bad: exit status 128\n"
    )


def test_gitrepo_cloned_dir_is_managed(env):
    """After cloning, the repo directory counts as managed and quiet."""
    repo = make_repo(env)
    define_git_external(env, repo)
    assert env.run(["apply", *env.flags()]).returncode == 0
    assert (env.home / ".plug/f.txt").read_text() == "one\n"
    # CATCHES: the cloned .plug (with its .git inside) is managed by the
    # external, so unmanaged lists nothing, diff and status print nothing,
    # and a repeat default apply is silent -- the repo is not unmanaged
    # noise nor a perpetual diff.
    for argv in (["unmanaged"], ["diff"], ["status"], ["apply"]):
        result = env.run([argv[0], *env.flags()])
        assert result.returncode == 0, (argv, result.stderr)
        assert result.stdout == b"", argv
        assert result.stderr == b"", argv
