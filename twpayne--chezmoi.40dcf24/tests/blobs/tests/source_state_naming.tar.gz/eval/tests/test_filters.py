"""Entry-type include/exclude filters of the managed command."""

from __future__ import annotations

import pytest

# The f1 fixture source: every entry type exactly once. The recorded target
# names come from running managed on this tree.
DEFAULT_MANAGED = (
    ".create\n"
    ".dir\n"
    ".dir/f\n"
    ".empty\n"
    ".file\n"
    ".link\n"
    ".removed\n"
    ".tmpl\n"
    "always_script2.sh\n"
    "empty_dir\n"
    "script.sh\n"
)


def populate(env):
    """Create one source entry of each type (the recorded f1 tree)."""
    env.mkdir("dot_dir")
    env.write("dot_dir/f", "f\n")
    env.mkdir("empty_dir")
    env.write("dot_file", "file\n")
    env.write("create_dot_create", "cre\n")
    env.write("remove_dot_removed", "rm\n")
    env.write("run_once_script.sh", "#!/bin/sh\necho hi\n")
    env.write("run_always_script2.sh", "#!/bin/sh\necho hi\n")
    env.write("symlink_dot_link", "target\n")
    env.write("dot_tmpl.tmpl", "{{ 1 + 1 }}\n")
    env.write("empty_dot_empty", "x\n")


def test_managed_default_lists_everything(env):
    """The default include set covers all entry types, even empty dirs."""
    populate(env)
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the default listing includes dir entries, file entries,
    # remove_ targets, scripts (with their target names script.sh /
    # always_script2.sh), symlinks, templates AND an empty source dir
    # (empty_dir) -- sorted by target path.
    assert result.stdout.decode() == DEFAULT_MANAGED


@pytest.mark.parametrize(
    "include,expected",
    [
        ("dirs", ".dir\nempty_dir\n"),
        ("files", ".create\n.dir/f\n.empty\n.file\n.tmpl\n"),
        ("remove", ".removed\n"),
        ("scripts", "always_script2.sh\nscript.sh\n"),
        ("symlinks", ".link\n"),
        ("templates", ".tmpl\n"),
        ("always", "always_script2.sh\n"),
        ("all", DEFAULT_MANAGED),
    ],
)
def test_managed_include_entry_types(env, include, expected):
    """-i selects entries by type using the recorded type taxonomy."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-i", include])
    assert result.returncode == 0, (include, result.stderr)
    # CATCHES: the type taxonomy is behavioral, not lexical: `always`
    # matches only run_always_ scripts, `files` includes create_ files and
    # templates' rendered files but not symlinks or scripts, and `dirs`
    # includes the empty dir. A name-prefix-based re-implementation would
    # misclassify create_/remove_ entries.
    assert result.stdout.decode() == expected, include


def test_managed_include_none_lists_nothing(env):
    """-i none filters out every entry, unlike the unfiltered default."""
    populate(env)
    everything = env.run(["managed", *env.flags()])
    assert everything.returncode == 0, everything.stderr
    assert everything.stdout.decode() == DEFAULT_MANAGED
    result = env.run(["managed", *env.flags(), "-i", "none"])
    # CATCHES: the same tree that lists eleven entries by default yields
    # rc 0 with completely empty stdout under -i none -- `none` is a real
    # member of the type set, not an error, and it subtracts every bit.
    assert result.returncode == 0, result.stderr
    assert result.stdout == b""
    assert result.stderr == b""


def test_managed_include_encrypted_with_age(env):
    """-i encrypted lists only age-encrypted source files."""
    from conftest import make_age_config

    config, _ = make_age_config(env)
    env.write("dot_plain", "plain\n")
    env.write("dot_secret", "secret\n")
    encrypted = env.run(
        ["chattr", "-c", str(config), *env.flags(), "+encrypted", str(env.home / ".secret")]
    )
    assert encrypted.returncode == 0, encrypted.stderr
    result = env.run(
        ["managed", "-c", str(config), *env.flags(), "-i", "encrypted"]
    )
    # CATCHES: the encrypted bit is carried by the entry, not the name:
    # -i encrypted reports the target of encrypted_dot_secret.age (.secret)
    # while the sibling plain file is filtered out, and -x encrypted keeps
    # exactly the complement (.plain).
    assert result.returncode == 0, result.stderr
    assert result.stdout == b".secret\n"
    complement = env.run(
        ["managed", "-c", str(config), *env.flags(), "-x", "encrypted"]
    )
    assert complement.returncode == 0, complement.stderr
    assert complement.stdout == b".plain\n"


def test_managed_include_externals_with_external_definition(env):
    """-i externals lists only entries originating from .chezmoiexternal."""
    env.root.joinpath("plug.txt").write_bytes(b"plug\n")
    env.write("dot_plain", "plain\n")
    env.write(
        ".chezmoiexternal.toml",
        f'[".plug/file"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n',
    )
    result = env.run(["managed", *env.flags(), "-i", "externals"])
    # CATCHES: -i externals keeps only the external FILE entry (.plug/file)
    # -- the plain dot_plain file is filtered out even though it is a
    # managed file, because externals is an origin bit, not a name shape.
    assert result.returncode == 0, result.stderr
    assert result.stdout == b".plug/file\n"


def test_managed_include_comma_list(env):
    """Multiple -i types can be given as a single comma-separated list."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-i", "files,dirs"])
    assert result.returncode == 0, result.stderr
    # CATCHES: "files,dirs" is one flag value parsed as a set union -- the
    # output is the merged, still-sorted listing, not two blocks.
    assert result.stdout.decode() == (
        ".create\n.dir\n.dir/f\n.empty\n.file\n.tmpl\nempty_dir\n"
    )


def test_managed_include_negation(env):
    """A `no`-prefixed include value excludes that type from the default set."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-i", "noscripts"])
    assert result.returncode == 0, result.stderr
    # CATCHES: `noscripts` drops only the plain script (script.sh) while
    # the run_always_ script stays -- always scripts carry the `always`
    # type in addition to `scripts`, and the negation removes just one bit.
    assert result.stdout.decode() == (
        ".create\n.dir\n.dir/f\n.empty\n.file\n.link\n.removed\n.tmpl\n"
        "always_script2.sh\nempty_dir\n"
    )


def test_managed_exclude_files(env):
    """-x excludes a type from the default include set."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-x", "files"])
    assert result.returncode == 0, result.stderr
    # CATCHES: excluding `files` keeps dirs, the remove_ target, symlink,
    # scripts and the empty dir, but also drops .dir/f (a file inside a
    # kept directory) -- exclusion applies per entry, not per top dir.
    assert result.stdout.decode() == (
        ".dir\n.link\n.removed\nalways_script2.sh\nempty_dir\nscript.sh\n"
    )


def test_managed_include_all_exclude_types(env):
    """-i all combined with -x subtracts the excluded types."""
    populate(env)
    result = env.run(
        ["managed", *env.flags(), "-i", "all", "-x", "scripts,remove"]
    )
    assert result.returncode == 0, result.stderr
    # CATCHES: include wins first, then exclude subtracts; scripts and the
    # remove_ target vanish while the empty dir and symlink remain.
    assert result.stdout.decode() == (
        ".create\n.dir\n.dir/f\n.empty\n.file\n.link\n.tmpl\nempty_dir\n"
    )


def test_managed_scripts_in_chezmoiscripts_dir(env):
    """Scripts in .chezmoiscripts/ keep that directory in their target path."""
    env.mkdir(".chezmoiscripts")
    env.write(".chezmoiscripts/run_scriptdir.sh", "#!/bin/sh\necho hi\n")
    env.write("run_root.sh", "#!/bin/sh\necho hi\n")
    result = env.run(["managed", *env.flags(), "-i", "scripts"])
    assert result.returncode == 0, result.stderr
    # CATCHES: scripts at the top level target <name> in the dest dir, but
    # scripts under .chezmoiscripts/ target .chezmoiscripts/<name> -- the
    # special directory name survives into the target path.
    assert result.stdout.decode() == ".chezmoiscripts/scriptdir.sh\nroot.sh\n"
