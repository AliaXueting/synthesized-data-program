"""chattr: changing source entry attributes by renaming in place."""

from __future__ import annotations

import pytest

from conftest import make_age_config


def add_plain(env):
    env.write("dot_plain", "content\n")


def chattr(env, args, config=None):
    """Run chattr with ARGS (attribute spec, then target)."""
    argv = ["chattr"]
    if config is not None:
        argv += ["-c", str(config)]
    argv += env.flags() + list(args)
    return env.run(argv)


def source_names(env):
    return sorted(p.name for p in env.src.iterdir())


def test_chattr_private_adds_prefix(env):
    """+private renames dot_plain to private_dot_plain."""
    add_plain(env)
    result = chattr(env, ["+private", str(env.home / ".plain")])
    assert result.returncode == 0, result.stderr
    # CATCHES: the attribute is added as a prefix BEFORE dot_ (private_
    # dot_plain), not appended or substituted, and chattr prints nothing.
    assert source_names(env) == ["private_dot_plain"]
    assert result.stdout == b""


def test_chattr_multiple_attributes_chain(env):
    """Attributes accumulate in a fixed order regardless of request order."""
    add_plain(env)
    result = chattr(env, ["+empty,+executable", str(env.home / ".plain")])
    assert result.returncode == 0, result.stderr
    # CATCHES: requesting +empty,+executable on dot_plain yields
    # empty_executable_dot_plain with the canonical attribute order
    # (empty_ before executable_), not the order given on the command line.
    assert source_names(env) == ["empty_executable_dot_plain"]


def test_chattr_template_toggle(env):
    """+template adds the .tmpl suffix; notemplate removes it."""
    add_plain(env)
    assert chattr(env, ["+template", str(env.home / ".plain")]).returncode == 0
    assert source_names(env) == ["dot_plain.tmpl"]
    result = chattr(env, ["notemplate", str(env.home / ".plain")])
    assert result.returncode == 0, result.stderr
    # CATCHES: the attribute is encoded as a name SUFFIX for templates and
    # the `no`-prefixed spelling reverts it, renaming back to dot_plain.
    assert source_names(env) == ["dot_plain"]


def test_chattr_no_reverts_attribute(env):
    """The `no` form drops a single attribute, keeping the others."""
    add_plain(env)
    assert chattr(env, ["+empty,+executable", str(env.home / ".plain")]).returncode == 0
    result = chattr(env, ["noempty", str(env.home / ".plain")])
    assert result.returncode == 0, result.stderr
    # CATCHES: noempty removes only empty_ from
    # empty_executable_dot_plain, leaving executable_dot_plain.
    assert source_names(env) == ["executable_dot_plain"]


def test_chattr_minus_form_requires_separator(env):
    """Attribute specs starting with - need `--` so they are not flags."""
    add_plain(env)
    assert chattr(env, ["+p,+e,+x", str(env.home / ".plain")]).returncode == 0
    assert source_names(env) == ["private_empty_executable_dot_plain"]
    result = chattr(env, ["--", "-p,-e", str(env.home / ".plain")])
    assert result.returncode == 0, result.stderr
    # CATCHES: after `--`, -p,-e is parsed as an attribute spec and removes
    # private_ and empty_ but keeps executable_.
    assert source_names(env) == ["executable_dot_plain"]


def test_chattr_minus_without_separator_is_flag_error(env):
    """A leading-dash attribute without `--` is parsed as a shorthand flag."""
    add_plain(env)
    result = chattr(env, ["-private,template", str(env.home / ".plain")])
    assert result.returncode == 1
    # CATCHES: pflag consumes -private,... as an unknown shorthand flag
    # before chattr ever sees it -- the error names the first letter.
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: unknown shorthand flag: 'p' in -private,template\n"


def test_chattr_type_modifiers(env):
    """+script/+create/+symlink/+modify change the entry's type prefix."""
    import shutil

    for attribute, expected in [
        ("+script", "run_dot_plain"),
        ("+create", "create_dot_plain"),
        ("+symlink", "symlink_dot_plain"),
        ("+modify", "modify_dot_plain"),
    ]:
        shutil.rmtree(env.src)
        env.src.mkdir()
        add_plain(env)
        result = chattr(env, [attribute, str(env.home / ".plain")])
        assert result.returncode == 0, (attribute, result.stderr)
        # CATCHES: the type modifiers REPLACE the file's type prefix (the
        # plain file dot_plain becomes run_/create_/symlink_/modify_...),
        # never stacking two type prefixes.
        assert source_names(env) == [expected], attribute


def test_chattr_noscript_round_trip(env):
    """noscript removes an existing run_ prefix and is a no-op without one."""
    add_plain(env)
    assert chattr(env, ["+script", str(env.home / ".plain")]).returncode == 0
    assert source_names(env) == ["run_dot_plain"]
    result = chattr(env, ["noscript", str(env.home / ".plain")])
    assert result.returncode == 0, result.stderr
    # CATCHES: noscript strips the run_ prefix that +script just added
    # (run_dot_plain -> dot_plain) and prints nothing; a second noscript on
    # the now-plain file succeeds without mangling the name further.
    assert source_names(env) == ["dot_plain"]
    again = chattr(env, ["noscript", str(env.home / ".plain")])
    assert again.returncode == 0, again.stderr
    assert source_names(env) == ["dot_plain"]


def test_chattr_script_condition_modifiers(env):
    """once/before/after/onchange modify the run_ prefix of a script."""
    env.write("run_s.sh", "#!/bin/sh\necho hi\n")
    for attribute, expected in [
        ("+once,+before", "run_once_before_s.sh"),
        ("+after", "run_once_after_s.sh"),
        ("noafter", "run_once_s.sh"),
        ("+onchange", "run_onchange_s.sh"),
    ]:
        result = chattr(env, [attribute, str(env.home / "s.sh")])
        assert result.returncode == 0, (attribute, result.stderr)
        # CATCHES: condition modifiers slot between run_ and the name, and
        # +onchange on a run_once_ script REPLACES once_ rather than
        # stacking (run_onchange_s.sh, not run_once_onchange_s.sh).
        assert source_names(env) == [expected], attribute


def test_chattr_directory_modifiers(env):
    """exact/remove/external modify directory entries and can stack."""
    env.mkdir("dot_dir")
    for attribute, expected in [
        ("+exact", "exact_dot_dir"),
        ("+remove", "remove_exact_dot_dir"),
        ("+external", "remove_external_exact_dot_dir"),
    ]:
        result = chattr(env, [attribute, str(env.home / ".dir")])
        assert result.returncode == 0, (attribute, result.stderr)
        # CATCHES: directory attributes accumulate as prefixes in the order
        # they are added (exact_, then remove_, then external_) and apply
        # to directory entries exactly like file attributes do to files.
        assert source_names(env) == [expected], attribute


def test_chattr_abbreviations(env):
    """Single-letter abbreviations and bare forms are accepted."""
    add_plain(env)
    result = chattr(env, ["p", str(env.home / ".plain")])
    assert result.returncode == 0, result.stderr
    # CATCHES: the attribute parser accepts abbreviations (p = private)
    # in the same bare form as full names, without a + prefix.
    assert source_names(env) == ["private_dot_plain"]


def test_chattr_unknown_attribute(env):
    """An unknown attribute name is rejected, including after `no`."""
    add_plain(env)
    result = chattr(env, ["+zzz", str(env.home / ".plain")])
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: zzz: unknown attribute\n"
    # CATCHES: `no` + unknown name reports the name with `no` stripped
    # (pprivate), showing the parser peels the prefix before lookup.
    result = chattr(env, ["nopprivate", str(env.home / ".plain")])
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: pprivate: unknown attribute\n"


def test_chattr_requires_two_args(env):
    """chattr with only an attribute spec fails the arity check."""
    result = chattr(env, ["+private"])
    assert result.returncode == 1
    # CATCHES: the command needs at least attribute + target; cobra's
    # MinimumNArgs(2) produces this exact message with the received count.
    assert result.stderr == b"chezmoi: requires at least 2 arg(s), only received 1\n"


def test_chattr_unmanaged_target(env):
    """A dest path that is not managed is rejected."""
    result = chattr(env, ["+private", str(env.home / ".nonexistent")])
    assert result.returncode == 1
    # CATCHES: chattr resolves the target against the source state; a
    # missing dest entry is `not managed` -- and the source directory is
    # untouched (no files are created).
    assert env.norm(result.stderr) == (
        b"chezmoi: @ROOT@/home/.nonexistent: not managed\n"
    )
    assert result.stdout == b""
    assert source_names(env) == []


def test_chattr_target_outside_destination(env):
    """A target outside the destination directory is rejected."""
    add_plain(env)
    result = chattr(env, ["+private", str(env.root / ".plain")])
    assert result.returncode == 1
    # CATCHES: the path resolves against the cwd (the scratch root) and is
    # then rejected for being outside the dest dir, with the dest dir named
    # in the message.
    assert env.norm(result.stderr) == (
        b"chezmoi: @ROOT@/.plain: not in destination directory (@ROOT@/home)\n"
    )


def test_chattr_encrypted_toggle_with_age(env):
    """+encrypted with age config encrypts; -- -encrypted restores plaintext."""
    config, _ = make_age_config(env)
    env.write("dot_secret", "secret\n")
    result = chattr(env, ["+encrypted", str(env.home / ".secret")], config)
    assert result.returncode == 0, result.stderr
    assert source_names(env) == ["encrypted_dot_secret.age"]
    # CATCHES: +encrypted renames to encrypted_<name> PLUS the configured
    # age suffix (.age) and rewrites the contents as age ciphertext; cat
    # transparently decrypts back to the original plaintext.
    assert env.run(["cat", "-c", str(config), *env.flags(), str(env.home / ".secret")]).stdout == b"secret\n"
    listing = env.run(
        ["managed", "-c", str(config), *env.flags(), "-p", "source-relative", "-i", "encrypted"]
    )
    assert listing.returncode == 0, listing.stderr
    assert listing.stdout == b"encrypted_dot_secret.age\n"
    revert = chattr(env, ["--", "-encrypted", str(env.home / ".secret")], config)
    assert revert.returncode == 0, revert.stderr
    # CATCHES: -- -encrypted renames back to dot_secret and DECRYPTS the
    # stored ciphertext so the source file holds the plaintext again.
    assert source_names(env) == ["dot_secret"]
    assert (env.src / "dot_secret").read_bytes() == b"secret\n"


def test_chattr_encrypted_without_encryption_configured(env):
    """+encrypted fails outright when no encryption is configured."""
    add_plain(env)
    result = chattr(env, ["+encrypted", str(env.home / ".plain")])
    assert result.returncode == 1
    # CATCHES: without an encryption configuration chattr refuses with this
    # exact message and leaves the source name untouched (still dot_plain).
    assert result.stderr == b"chezmoi: encryption not configured\n"
    assert source_names(env) == ["dot_plain"]
