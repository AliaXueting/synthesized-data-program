"""The managed/list command: path styles, formats, tree and NUL output."""

from __future__ import annotations

import json


def populate(env):
    """Create the recorded source tree: .bashrc, .vim/vimrc, .config/foo."""
    env.write("dot_bashrc", "hello\n")
    env.mkdir("dot_vim")
    env.write("dot_vim/vimrc", "set nocompatible\n")
    env.mkdir("exact_dot_config")
    env.write("exact_dot_config/foo", "x\n")


RELATIVE = ".bashrc\n.config\n.config/foo\n.vim\n.vim/vimrc\n"
ABSOLUTE = (
    "@ROOT@/home/.bashrc\n"
    "@ROOT@/home/.config\n"
    "@ROOT@/home/.config/foo\n"
    "@ROOT@/home/.vim\n"
    "@ROOT@/home/.vim/vimrc\n"
)
SOURCE_ABSOLUTE = (
    "@ROOT@/src/dot_bashrc\n"
    "@ROOT@/src/dot_vim\n"
    "@ROOT@/src/dot_vim/vimrc\n"
    "@ROOT@/src/exact_dot_config\n"
    "@ROOT@/src/exact_dot_config/foo\n"
)
SOURCE_RELATIVE = (
    "dot_bashrc\n"
    "dot_vim\n"
    "dot_vim/vimrc\n"
    "exact_dot_config\n"
    "exact_dot_config/foo\n"
)


def test_managed_default_relative(env):
    """managed lists target-relative paths sorted by target path."""
    populate(env)
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the default listing is target-relative (not source names),
    # sorted by target path (.bashrc, .config, .config/foo, .vim, .vim/vimrc)
    # -- directory entries are listed before their children.
    assert env.norm(result.stdout).decode() == RELATIVE


def test_list_alias_matches_managed(env):
    """`list` is an alias producing byte-identical output."""
    populate(env)
    managed = env.run(["managed", *env.flags()])
    listing = env.run(["list", *env.flags()])
    # CATCHES: the alias must produce exactly the recorded bytes of the
    # managed listing (five target-relative paths, trailing newline, sort
    # order) with the same exit code -- not a different default style.
    assert listing.returncode == managed.returncode == 0
    assert listing.stdout == managed.stdout == RELATIVE.encode()
    assert listing.stderr == managed.stderr == b""


def test_managed_path_styles(env):
    """-p absolute/relative/source-absolute/source-relative select the style."""
    populate(env)
    for style, expected in [
        ("absolute", ABSOLUTE),
        ("relative", RELATIVE),
        ("source-absolute", SOURCE_ABSOLUTE),
        ("source-relative", SOURCE_RELATIVE),
    ]:
        result = env.run(["managed", *env.flags(), "-p", style])
        assert result.returncode == 0, (style, result.stderr)
        # CATCHES: source-absolute/source-relative expose the raw source
        # names (dot_vim, exact_dot_config) while absolute/relative show
        # target names (.vim, .config) -- the styles are not mere prefixes.
        assert env.norm(result.stdout).decode() == expected, style


def test_managed_path_style_all_json(env):
    """-p all prints a pretty-printed JSON map keyed by target path."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-p", "all", "-f", "json"])
    assert result.returncode == 0, result.stderr
    text = env.norm(result.stdout).decode()
    # CATCHES: -p all emits one JSON object with the three path styles per
    # entry, 2-space indented, keys sorted; parsing it back must yield the
    # exact recorded mapping.
    assert json.loads(text) == {
        ".bashrc": {
            "absolute": "@ROOT@/home/.bashrc",
            "sourceAbsolute": "@ROOT@/src/dot_bashrc",
            "sourceRelative": "dot_bashrc",
        },
        ".config": {
            "absolute": "@ROOT@/home/.config",
            "sourceAbsolute": "@ROOT@/src/exact_dot_config",
            "sourceRelative": "exact_dot_config",
        },
        ".config/foo": {
            "absolute": "@ROOT@/home/.config/foo",
            "sourceAbsolute": "@ROOT@/src/exact_dot_config/foo",
            "sourceRelative": "exact_dot_config/foo",
        },
        ".vim": {
            "absolute": "@ROOT@/home/.vim",
            "sourceAbsolute": "@ROOT@/src/dot_vim",
            "sourceRelative": "dot_vim",
        },
        ".vim/vimrc": {
            "absolute": "@ROOT@/home/.vim/vimrc",
            "sourceAbsolute": "@ROOT@/src/dot_vim/vimrc",
            "sourceRelative": "dot_vim/vimrc",
        },
    }


def test_managed_path_style_all_json_layout(env):
    """-p all JSON has the exact recorded key order and indentation."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-p", "all", "-f", "json"])
    assert result.returncode == 0, result.stderr
    expected = (
        "{\n"
        '  ".bashrc": {\n'
        '    "absolute": "@ROOT@/home/.bashrc",\n'
        '    "sourceAbsolute": "@ROOT@/src/dot_bashrc",\n'
        '    "sourceRelative": "dot_bashrc"\n'
        "  },\n"
        '  ".config": {\n'
        '    "absolute": "@ROOT@/home/.config",\n'
        '    "sourceAbsolute": "@ROOT@/src/exact_dot_config",\n'
        '    "sourceRelative": "exact_dot_config"\n'
        "  },\n"
        '  ".config/foo": {\n'
        '    "absolute": "@ROOT@/home/.config/foo",\n'
        '    "sourceAbsolute": "@ROOT@/src/exact_dot_config/foo",\n'
        '    "sourceRelative": "exact_dot_config/foo"\n'
        "  },\n"
        '  ".vim": {\n'
        '    "absolute": "@ROOT@/home/.vim",\n'
        '    "sourceAbsolute": "@ROOT@/src/dot_vim",\n'
        '    "sourceRelative": "dot_vim"\n'
        "  },\n"
        '  ".vim/vimrc": {\n'
        '    "absolute": "@ROOT@/home/.vim/vimrc",\n'
        '    "sourceAbsolute": "@ROOT@/src/dot_vim/vimrc",\n'
        '    "sourceRelative": "dot_vim/vimrc"\n'
        "  }\n"
        "}\n"
    )
    # CATCHES: the serialization is json.MarshalIndent with two spaces and
    # HTML-escaped quotes untouched; a re-implementation using a different
    # indent or key order breaks this byte comparison.
    assert env.norm(result.stdout).decode() == expected


def test_managed_path_style_all_yaml(env):
    """-p all -f yaml prints the same mapping as YAML with 2-space indent."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-p", "all", "-f", "yaml"])
    assert result.returncode == 0, result.stderr
    expected = (
        ".bashrc:\n"
        "  absolute: @ROOT@/home/.bashrc\n"
        "  sourceAbsolute: @ROOT@/src/dot_bashrc\n"
        "  sourceRelative: dot_bashrc\n"
        ".config:\n"
        "  absolute: @ROOT@/home/.config\n"
        "  sourceAbsolute: @ROOT@/src/exact_dot_config\n"
        "  sourceRelative: exact_dot_config\n"
        ".config/foo:\n"
        "  absolute: @ROOT@/home/.config/foo\n"
        "  sourceAbsolute: @ROOT@/src/exact_dot_config/foo\n"
        "  sourceRelative: exact_dot_config/foo\n"
        ".vim:\n"
        "  absolute: @ROOT@/home/.vim\n"
        "  sourceAbsolute: @ROOT@/src/dot_vim\n"
        "  sourceRelative: dot_vim\n"
        ".vim/vimrc:\n"
        "  absolute: @ROOT@/home/.vim/vimrc\n"
        "  sourceAbsolute: @ROOT@/src/dot_vim/vimrc\n"
        "  sourceRelative: dot_vim/vimrc\n"
    )
    # CATCHES: -p all only takes effect with a structured format; the YAML
    # flavor is block style with sorted keys and no document separator.
    assert env.norm(result.stdout).decode() == expected


def test_managed_format_json_without_all_is_plain_lines(env):
    """-f json without -p all still prints one plain path per line."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-f", "json"])
    assert result.returncode == 0, result.stderr
    # CATCHES: the format flag only changes output when the path style is
    # `all`; otherwise paths print as plain lines exactly like the default.
    assert env.norm(result.stdout).decode() == RELATIVE


def test_managed_tree(env):
    """-t prints a 2-space indented tree of target-relative paths."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-t"])
    assert result.returncode == 0, result.stderr
    # CATCHES: tree output indents children by two spaces per level and
    # prints directory entries without trailing slashes or separators.
    assert result.stdout == b".bashrc\n.config\n  foo\n.vim\n  vimrc\n"


def test_managed_tree_absolute_nests_all_components(env):
    """-t -p absolute nests every path component from the filesystem root."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-t", "-p", "absolute"])
    assert result.returncode == 0, result.stderr
    components = str(env.home).split("/")
    depth = len(components)
    expected = ["  " * index + component for index, component in enumerate(components)]
    expected += [
        "  " * depth + ".bashrc",
        "  " * depth + ".config",
        "  " * (depth + 1) + "foo",
        "  " * depth + ".vim",
        "  " * (depth + 1) + "vimrc",
    ]
    # CATCHES: the absolute tree starts with an empty root line (the empty
    # component before the leading "/"), indents one level per path
    # component, and interleaves children directly under their parent
    # (.config then foo, .vim then vimrc) in target-sorted order.
    assert env.norm(result.stdout).decode().splitlines() == expected


def test_managed_nul_separator(env):
    """-0 separates paths with NUL bytes, including a trailing NUL."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-0"])
    assert result.returncode == 0, result.stderr
    # CATCHES: NUL mode replaces the newline after every entry, so the
    # output both separates and terminates with \0 (no final newline).
    assert result.stdout == b".bashrc\x00.config\x00.config/foo\x00.vim\x00.vim/vimrc\x00"


def test_managed_argument_filters_subtree(env):
    """Positional args restrict the listing to managed paths under them."""
    populate(env)
    result = env.run(["managed", *env.flags(), str(env.home / ".config")])
    assert result.returncode == 0, result.stderr
    # CATCHES: the argument is a destination path; the listing keeps the
    # .config dir entry itself plus its managed children, and drops
    # everything outside the subtree.
    assert result.stdout == b".config\n.config/foo\n"


def test_managed_argument_with_no_managed_entries(env):
    """A positional arg with nothing managed under it exits 0 with no output."""
    populate(env)
    unfiltered = env.run(["managed", *env.flags()])
    assert unfiltered.returncode == 0, unfiltered.stderr
    assert unfiltered.stdout.decode() == RELATIVE
    env.write_home(".untracked/f", "z\n")
    result = env.run(["managed", *env.flags(), str(env.home / ".untracked")])
    # CATCHES: the same tree that lists five entries unfiltered yields rc 0
    # with empty stdout when filtered to an unmanaged subtree -- filtering
    # is not an error, unlike source-path which reports "not managed".
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""


def test_managed_missing_source_dir(env):
    """A missing source directory yields rc 0 and empty output."""
    import shutil

    populate(env)
    populated = env.run(["managed", *env.flags()])
    assert populated.returncode == 0, populated.stderr
    assert populated.stdout.decode() == RELATIVE
    shutil.rmtree(env.src)
    result = env.run(["managed", *env.flags()])
    # CATCHES: the source dir that listed five entries a moment earlier can
    # be deleted outright; managed then tolerates the nonexistent source
    # dir (rc 0, no output, no stderr) rather than reporting a stat error
    # like target-path does.
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""


def test_managed_path_style_abbreviations(env):
    """-p accepts any unambiguous prefix of an allowed path style."""
    populate(env)
    for value, expected in [
        ("ab", ABSOLUTE),
        ("r", RELATIVE),
        ("source-a", SOURCE_ABSOLUTE),
        ("source-r", SOURCE_RELATIVE),
    ]:
        result = env.run(["managed", *env.flags(), "-p", value])
        assert result.returncode == 0, (value, result.stderr)
        # CATCHES: the path-style flag resolves unique prefixes to their
        # full values (ab -> absolute, r -> relative, source-a/source-r ->
        # the two source styles split at the first differing letter) --
        # the expansion happens before the style is applied, so the output
        # is byte-identical to the full spelling.
        assert env.norm(result.stdout).decode() == expected, value


def test_managed_ambiguous_abbreviation_rejected(env):
    """A prefix shared by two allowed values is rejected, not guessed."""
    populate(env)
    result = env.run(["managed", *env.flags(), "-p", "a"])
    # CATCHES: "a" is a prefix of both absolute and all, and the flag
    # refuses to choose: the error is the plain "invalid value" form (the
    # same text as a wholly unknown value) and nothing is listed.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'chezmoi: invalid argument "a" for "-p, --path-style" flag: '
        b"invalid value\n"
    )


def test_managed_abbreviated_all_and_format(env):
    """-p al expands to all, and -f j/-f y to json/yaml, together."""
    env.write("dot_bashrc", "hello\n")
    json_result = env.run(["managed", *env.flags(), "-p", "al", "-f", "j"])
    assert json_result.returncode == 0, json_result.stderr
    # CATCHES: two different flags expand abbreviations independently:
    # "al" selects the all path style (whose default format is json) and
    # "j" the json writer, producing the exact three-style mapping for the
    # single entry.
    assert env.norm(json_result.stdout).decode() == (
        "{\n"
        '  ".bashrc": {\n'
        '    "absolute": "@ROOT@/home/.bashrc",\n'
        '    "sourceAbsolute": "@ROOT@/src/dot_bashrc",\n'
        '    "sourceRelative": "dot_bashrc"\n'
        "  }\n"
        "}\n"
    )
    yaml_result = env.run(["managed", *env.flags(), "-p", "al", "-f", "y"])
    assert yaml_result.returncode == 0, yaml_result.stderr
    # CATCHES: "y" expands to yaml, switching the all-style serialization
    # from JSON braces to YAML block mapping with the same keys.
    assert env.norm(yaml_result.stdout).decode() == (
        ".bashrc:\n"
        "  absolute: @ROOT@/home/.bashrc\n"
        "  sourceAbsolute: @ROOT@/src/dot_bashrc\n"
        "  sourceRelative: dot_bashrc\n"
    )


def test_managed_invalid_flag_values(env):
    """Invalid -p/-f/-i values are rejected with the pflag error shape."""
    populate(env)
    for flag, expected in [
        ("-p", b'chezmoi: invalid argument "bogus" for "-p, --path-style" flag: invalid value\n'),
        ("-f", b'chezmoi: invalid argument "bogus" for "-f, --format" flag: invalid value\n'),
        (
            "-i",
            b'chezmoi: invalid argument "bogus" for "-i, --include" flag: bogus: unknown entry type\n',
        ),
    ]:
        result = env.run(["managed", *env.flags(), flag, "bogus"])
        assert result.returncode == 1, flag
        # CATCHES: each choice flag has its own error text; path-style and
        # format say just "invalid value" while include names the unknown
        # entry type.
        assert result.stdout == b""
        assert result.stderr == expected, flag
