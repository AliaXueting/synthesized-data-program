"""--refresh-externals semantics and the on-disk external cache.

The cache lives at <cacheDir>/external/<sha256(url)>; poisoning it lets us
exercise refresh behavior without any network (the http URLs point at
127.0.0.1:9, which refuses connections in this environment).
"""

from __future__ import annotations

import hashlib
import os
import time

import pytest

URL = "http://127.0.0.1:9/x"
CACHED = b"this came from the cache\n"
REFUSED = (
    b'chezmoi: .cached: Get "http://127.0.0.1:9/x": '
    b"dial tcp 127.0.0.1:9: connect: connection refused\n"
)


def poison_cache(env, age_seconds=None):
    """Seed the external cache for URL and optionally backdate its mtime."""
    key = hashlib.sha256(URL.encode()).hexdigest()
    directory = env.cache / "external"
    directory.mkdir(parents=True, exist_ok=True)
    entry = directory / key
    entry.write_bytes(CACHED)
    if age_seconds is not None:
        stamp = time.time() - age_seconds
        os.utime(entry, (stamp, stamp))
    return entry


def define_external(env, body=None):
    env.write(
        ".chezmoiexternal.toml",
        body or f'[".cached"]\n    type = "file"\n    url = "{URL}"\n',
    )


def cat(env, *extra):
    return env.run(["cat", *env.flags(), *extra, str(env.home / ".cached")])


def test_refresh_never_uses_cache_without_network(env):
    """-R=never serves the cached copy and never touches the network."""
    poison_cache(env)
    define_external(env)
    result = cat(env, "-R=never")
    # CATCHES: with refresh=never a poisoned cache entry is served verbatim
    # (no freshness check, no request), so the connection-refused URL is
    # never contacted and rc stays 0.
    assert result.returncode == 0, result.stderr
    assert result.stdout == CACHED


def test_refresh_auto_with_fresh_cache(env):
    """-R=auto keeps the cache while its mtime is newer than the period."""
    poison_cache(env)
    define_external(env)
    for extra in ([], ["-R=auto"]):
        result = cat(env, *extra)
        # CATCHES: auto is the default and treats a just-written cache as
        # fresh, so the cached bytes are served with no network access.
        assert result.returncode == 0, (extra, result.stderr)
        assert result.stdout == CACHED


def test_refresh_always_refetches(env):
    """-R=always ignores the cache and attempts a fresh download."""
    poison_cache(env)
    define_external(env)
    result = cat(env, "-R=always")
    # CATCHES: always bypasses even a fresh cache, which here surfaces as
    # the exact connection-refused error for the unreachable URL.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == REFUSED


def test_refresh_bare_flag_means_always(env):
    """A bare -R (no value) behaves like always."""
    poison_cache(env)
    define_external(env)
    result = cat(env, "-R")
    # CATCHES: -R without =value defaults to always, not auto -- the flag
    # is registered with a NoOptDefVal, so the bare form still forces a
    # (failing) refresh.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == REFUSED


def test_refresh_false_means_never(env):
    """-R=false parses as a disabled refresh and serves the cache."""
    poison_cache(env)
    define_external(env)
    result = cat(env, "-R=false")
    # CATCHES: the value parser accepts "false" as a synonym for never,
    # an odd corner of the flag's value grammar (always|auto|never plus
    # booleans).
    assert result.returncode == 0, result.stderr
    assert result.stdout == CACHED


@pytest.mark.parametrize("value", ["on", "ON", "y", "yes", "1", "true"])
def test_refresh_truthy_spellings_force_refresh(env, value):
    """Every truthy boolean spelling of -R= behaves like always."""
    poison_cache(env)
    define_external(env)
    result = cat(env, f"-R={value}")
    # CATCHES: beyond always/never, the value grammar accepts on/ON/y/yes/
    # 1/true (case-insensitively) as truthy -- each forces a refresh past
    # the poisoned cache into the connection-refused error.
    assert result.returncode == 1, value
    assert result.stdout == b""
    assert result.stderr == REFUSED, value


@pytest.mark.parametrize("value", ["off", "OFF", "n", "no", "0"])
def test_refresh_falsy_spellings_serve_cache(env, value):
    """Every falsy boolean spelling of -R= behaves like never."""
    poison_cache(env)
    define_external(env)
    result = cat(env, f"-R={value}")
    # CATCHES: off/OFF/n/no/0 parse as falsy and disable refreshing, so
    # the poisoned cache entry is served verbatim with rc 0.
    assert result.returncode == 0, (value, result.stderr)
    assert result.stdout == CACHED, value
    assert result.stderr == b""


def test_refresh_unparsable_value_is_flag_error(env):
    """A value that is neither keyword nor boolean is a flag parse error."""
    poison_cache(env)
    define_external(env)
    result = cat(env, "-R=notabool")
    # CATCHES: the value falls through to strconv.ParseBool, and the flag
    # machinery wraps its error with the flag's own name, so the message
    # reads "invalid argument ... for \"-R, --refresh-externals\" flag:
    # strconv.ParseBool: parsing \"notabool\": invalid syntax".
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'chezmoi: invalid argument "notabool" for "-R, --refresh-externals" '
        b'flag: strconv.ParseBool: parsing "notabool": invalid syntax\n'
    )


def test_refresh_value_binds_only_with_equals(env):
    """A space-separated -R value becomes a positional argument instead."""
    poison_cache(env)
    define_external(env)
    result = cat(env, "-R", "never")
    assert result.returncode == 1
    # CATCHES: `-R never` does NOT set refresh-externals; "never" is
    # treated as a target path, resolved against the cwd and rejected with
    # the destination-directory error. Only `-R=never` binds the value.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: @ROOT@/never: not in destination directory (@ROOT@/home)\n"
    )


def test_refresh_long_flag_space_form_is_positional_too(env):
    """--refresh-externals never (space form) also misparses as a target."""
    poison_cache(env)
    define_external(env)
    result = env.run(["managed", *env.flags(), "--refresh-externals", "never"])
    assert result.returncode == 1
    # CATCHES: the same binding rule holds for the long flag; managed then
    # rejects the stray "never" argument with its own not-in-dest message.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: @ROOT@/never: not in @ROOT@/home\n"
    )


def test_refresh_period_expiry_forces_refetch(env):
    """An expired refreshPeriod makes auto treat the cache as stale."""
    poison_cache(env, age_seconds=3600)
    define_external(
        env,
        f'[".cached"]\n    type = "file"\n    url = "{URL}"\n'
        '    refreshPeriod = "1ms"\n',
    )
    result = cat(env)
    # CATCHES: with refreshPeriod=1ms an hour-old cache entry is stale, so
    # auto attempts a refresh (which fails here with connection refused)
    # instead of serving the cached bytes.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == REFUSED


def test_refresh_period_zero_is_always_fresh(env):
    """refreshPeriod = 0s disables expiry regardless of cache age."""
    poison_cache(env, age_seconds=3600)
    define_external(
        env,
        f'[".cached"]\n    type = "file"\n    url = "{URL}"\n'
        '    refreshPeriod = "0s"\n',
    )
    result = cat(env)
    # CATCHES: a zero period means never-expire (not always-refresh), so
    # the hour-old cache entry is still served without any network access.
    assert result.returncode == 0, result.stderr
    assert result.stdout == CACHED


def test_external_encrypted_flag_decrypts(env):
    """encrypted = true decrypts the external with the configured age key."""
    from conftest import make_age_config

    config, _ = make_age_config(env)
    # Produce age ciphertext via chattr +encrypted on a throwaway source.
    env.write("dot_secret", "encrypted payload\n")
    assert env.run(
        ["chattr", "-c", str(config), *env.flags(), "+encrypted", str(env.home / ".secret")]
    ).returncode == 0
    cipher = env.src / "encrypted_dot_secret.age"
    data = cipher.read_bytes()
    cipher.unlink()
    served = env.root / "cipher.age"
    served.write_bytes(data)
    env.write(
        ".chezmoiexternal.toml",
        f'[".enc"]\n    type = "file"\n    url = "file://{served}"\n'
        "    encrypted = true\n",
    )
    result = env.run(
        ["cat", "-c", str(config), *env.flags(), str(env.home / ".enc")]
    )
    # CATCHES: with encrypted=true the fetched bytes are run through the
    # configured age decryption before being written, so the target holds
    # the plaintext while the source URL serves an age ciphertext.
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"encrypted payload\n"


def test_external_without_encrypted_flag_serves_ciphertext(env):
    """Without the encrypted flag the ciphertext is served as-is."""
    from conftest import make_age_config

    config, _ = make_age_config(env)
    env.write("dot_secret", "encrypted payload\n")
    assert env.run(
        ["chattr", "-c", str(config), *env.flags(), "+encrypted", str(env.home / ".secret")]
    ).returncode == 0
    cipher = env.src / "encrypted_dot_secret.age"
    data = cipher.read_bytes()
    cipher.unlink()
    served = env.root / "cipher.age"
    served.write_bytes(data)
    env.write(
        ".chezmoiexternal.toml",
        f'[".enc"]\n    type = "file"\n    url = "file://{served}"\n',
    )
    result = env.run(
        ["cat", "-c", str(config), *env.flags(), str(env.home / ".enc")]
    )
    # CATCHES: the encrypted flag is what triggers decryption; without it
    # the age ciphertext (starting with the armor header) becomes the
    # target contents verbatim, rc 0.
    assert result.returncode == 0, result.stderr
    assert result.stdout.startswith(b"-----BEGIN AGE ENCRYPTED FILE-----\n")
    assert result.stdout == data
