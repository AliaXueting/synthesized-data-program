"""apply semantics of the naming language: file types, modify scripts,
script conditions and ordering."""

from __future__ import annotations


def test_apply_file_type_attributes(env):
    """create_ preserves existing files; remove_ deletes; symlink_ links."""
    env.write("create_dot_existing", "new\n")
    env.write("remove_dot_gone", "x\n")
    env.write("symlink_dot_link", "target\n")
    env.write("dot_plain", "plain\n")
    env.write_home(".existing", "existing\n")
    env.write_home(".gone", "x\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: create_ never overwrites an existing dest file (the old
    # contents survive), remove_ deletes the dest entry, symlink_ creates
    # a symlink whose linkname is the file's contents, and a plain file
    # is written normally.
    assert (env.home / ".existing").read_text() == "existing\n"
    assert not (env.home / ".gone").exists()
    assert (env.home / ".link").is_symlink()
    import os

    assert os.readlink(env.home / ".link") == "target"
    assert (env.home / ".plain").read_text() == "plain\n"


def test_apply_empty_attribute(env):
    """empty_ permits empty target files; without it they are deleted."""
    env.write("empty_dot_true_empty", "")
    env.write("empty_dot_nonempty", "ignored contents\n")
    env.write("dot_normal", "content\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: empty_ only opts the target OUT of the delete-if-empty
    # rule -- it does not truncate: a truly empty source yields an empty
    # target (.true_empty, 0 bytes) while a non-empty empty_ source keeps
    # its full contents (.nonempty, 17 bytes).
    assert (env.home / ".true_empty").read_bytes() == b""
    assert (env.home / ".nonempty").read_bytes() == b"ignored contents\n"
    assert (env.home / ".normal").read_bytes() == b"content\n"


def test_apply_removes_dest_file_that_became_empty_source(env):
    """An empty source without empty_ removes the target, even a real file."""
    env.write("dot_vanishing", "")
    env.write("dot_preexisting", "")
    env.write_home(".preexisting", "pre\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: an empty target with no empty_ attribute is deleted -- both
    # when it never existed and when a real dest file was there before;
    # empty_ is what opts out of this removal.
    assert not (env.home / ".vanishing").exists()
    assert not (env.home / ".preexisting").exists()


def test_apply_modify_script_transforms_contents(env):
    """A modify_ script receives the current contents on stdin."""
    env.write("modify_dot_conf", '#!/bin/sh\necho "modified: $(cat)"\n')
    env.write_home(".conf", "orig\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the modifier runs with the dest file's current contents on
    # stdin and its stdout replaces the file -- here wrapping it in
    # "modified: ".
    assert (env.home / ".conf").read_text() == "modified: orig\n"


def test_apply_modify_template_header(env):
    """A plain modify_ file with the chezmoi:modify-template header is a template.

    Without a .tmpl suffix the {{ ... }} text survives to the
    modify-template pass, where .chezmoi.stdin holds the current contents.
    """
    env.write(
        "modify_dot_conf",
        '#!/usr/bin/env chezmoi:modify-template\n'
        '{{ .chezmoi.stdin | replace "AAA" "XXX" }}\n',
    )
    env.write_home(".conf", "AAA\nBBB\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the header line routes the modifier through the template
    # engine with the dest contents as .chezmoi.stdin (AAA -> XXX); the
    # header line itself is stripped, but the template body's own trailing
    # newline survives, so the result is the replaced stdin PLUS one \n.
    assert (env.home / ".conf").read_text() == "XXX\nBBB\n\n"


def test_apply_modify_tmpl_stdin_not_available(env):
    """A .tmpl modify_ file cannot use .chezmoi.stdin directly."""
    env.write(
        "modify_dot_conf.tmpl",
        '#!/usr/bin/env chezmoi:modify-template\n'
        '{{ .chezmoi.stdin | replace "AAA" "XXX" }}\n',
    )
    env.write_home(".conf", "AAA\nBBB\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 1
    # CATCHES: the .tmpl suffix makes chezmoi execute the file as a normal
    # template FIRST, in a context without .chezmoi.stdin -- the map has
    # no entry for key "stdin" -- so the file is left unchanged.
    assert result.stdout == b""
    assert result.stderr == (
        b"chezmoi: .conf: template: modify_dot_conf.tmpl:2:11: executing "
        b'"modify_dot_conf.tmpl" at <.chezmoi.stdin>: '
        b"map has no entry for key \"stdin\"\n"
    )
    assert (env.home / ".conf").read_text() == "AAA\nBBB\n"


def test_apply_modify_tmpl_escaped_delimiters(env):
    """Escaping the delimiters lets a .tmpl modifier reach the second pass."""
    env.write(
        "modify_dot_conf.tmpl",
        '#!/usr/bin/env chezmoi:modify-template\n'
        '{{ "{{" }} .chezmoi.stdin | replace "AAA" "ZZZ" {{ "}}" }}\n',
    )
    env.write_home(".conf", "AAA\nBBB\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the first template pass renders the escaped delimiters into
    # literal {{ ... }} text, which the modify-template pass then executes
    # against the dest contents (AAA -> ZZZ); the template body's trailing
    # newline survives both passes, so one extra \n lands in the result.
    assert (env.home / ".conf").read_text() == "ZZZ\nBBB\n\n"


def test_apply_modify_empty_and_missing_target(env):
    """An empty modifier leaves the file untouched; a missing target stays missing."""
    env.write("modify_dot_conf", "")
    env.write("dot_marker", "m\n")
    env.write_home(".conf", "AAA\n")
    first = env.run(["apply", *env.flags()])
    assert first.returncode == 0, first.stderr
    assert (env.home / ".conf").read_text() == "AAA\n"
    # CATCHES: the same apply demonstrably ran (the sibling dot_marker was
    # created), yet an empty modify_ script is a no-op -- not a truncation:
    # .conf keeps its exact contents instead of becoming empty.
    assert (env.home / ".marker").read_text() == "m\n"
    (env.home / ".conf").unlink()
    second = env.run(["apply", *env.flags()])
    # CATCHES: when the target does not exist apply does not create it --
    # modify_ only ever transforms existing contents, so .conf stays
    # missing while .marker is refreshed unchanged.
    assert second.returncode == 0, second.stderr
    assert not (env.home / ".conf").exists()
    assert (env.home / ".marker").read_text() == "m\n"


def test_apply_run_script_executes_every_time(env):
    """run_ scripts execute on every apply."""
    log = env.root / "log"
    env.write("run_counter.sh", f"#!/bin/sh\necho tick >> {log}\n")
    for _ in range(2):
        result = env.run(["apply", *env.flags()])
        assert result.returncode == 0, result.stderr
    # CATCHES: run_ has no persistent-state guard, so two applies produce
    # two log lines; the script's stdout is captured by chezmoi and never
    # appears on the command's stdout.
    assert log.read_text() == "tick\ntick\n"


def test_apply_run_once_runs_once_and_reruns_on_change(env):
    """run_once_ keys on the script's content hash, not its name."""
    log = env.root / "log"
    env.write("run_once_setup.sh", f"#!/bin/sh\necho v1 >> {log}\n")
    assert env.run(["apply", *env.flags()]).returncode == 0
    assert env.run(["apply", *env.flags()]).returncode == 0
    assert log.read_text() == "v1\n"
    env.write("run_once_setup.sh", f"#!/bin/sh\necho v2 >> {log}\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the second apply with unchanged contents does not re-run
    # the script, but editing the script's CONTENT invalidates the
    # once-state and runs it again -- v2 appears after the edit.
    assert log.read_text() == "v1\nv2\n"


def test_apply_run_onchange_reruns_on_change(env):
    """run_onchange_ re-runs whenever the script contents change."""
    log = env.root / "log"
    env.write("run_onchange_watch.sh", f"#!/bin/sh\necho a >> {log}\n")
    assert env.run(["apply", *env.flags()]).returncode == 0
    env.write("run_onchange_watch.sh", f"#!/bin/sh\necho b >> {log}\n")
    assert env.run(["apply", *env.flags()]).returncode == 0
    # CATCHES: onchange behaves like once for the first run and re-runs
    # only when the contents differ from the recorded hash.
    assert log.read_text() == "a\nb\n"


def test_apply_script_ordering(env):
    """Scripts run before_ them, then dir scripts, then plain, then after_."""
    log = env.root / "log"
    env.write("run_before_b.sh", f"#!/bin/sh\necho before >> {log}\n")
    env.write("run_during_d.sh", f"#!/bin/sh\necho during >> {log}\n")
    env.write("run_after_a.sh", f"#!/bin/sh\necho after >> {log}\n")
    env.mkdir(".chezmoiscripts")
    env.write(
        ".chezmoiscripts/run_scriptdir.sh", f"#!/bin/sh\necho scriptdir >> {log}\n"
    )
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the recorded order is before, .chezmoiscripts dir scripts,
    # plain run_ scripts, after -- alphabetical within each group, and
    # script names (b/d/a) do not influence the group ordering.
    assert log.read_text().splitlines() == ["before", "scriptdir", "during", "after"]
