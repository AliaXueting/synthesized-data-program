"""The --progress flag: reading HTTP responses with progress enabled.

``--progress=true`` asks chezmoi to render a progress bar (or a spinner,
when the server sends no Content-Length) while downloading url externals.
Rendering needs a TTY: the bubbletea program opens ``/dev/tty`` when stdin
is not a terminal, so with no controlling terminal the read fails with a
precise error.  Every forcing test here starts the candidate in a new
session (``setsid=True``) so it has no controlling terminal and the outcome
cannot depend on whether the test process itself is attached to a TTY.
The servers are loopback-only (127.0.0.1 on an ephemeral port).
"""

from __future__ import annotations

import http.server
import socketserver
import threading

import pytest


class LoopbackServer:
    """A loopback HTTP server recording every GET's If-Modified-Since.

    With CHUNKED the response is sent with ``Transfer-Encoding: chunked``
    and no Content-Length, so the client cannot know its length up front.
    """

    def __init__(self, chunked=False):
        self.body = b"body-one\n"
        self.requests = []
        self.chunked = chunked
        outer = self

        class Handler(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def do_GET(self):
                outer.requests.append(self.headers.get("If-Modified-Since"))
                body = outer.body
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                if outer.chunked:
                    self.send_header("Transfer-Encoding", "chunked")
                    self.end_headers()
                    self.wfile.write(b"%x\r\n%s\r\n" % (len(body), body))
                    self.wfile.write(b"0\r\n\r\n")
                else:
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Last-Modified", "Fri, 01 Jan 2021 00:00:00 GMT")
                    self.end_headers()
                    self.wfile.write(body)

            def log_message(self, *args):
                pass

        self.server = socketserver.ThreadingTCPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *exc):
        self.server.shutdown()
        self.server.server_close()

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}/plug.txt"

    def define_external(self, env):
        env.write(
            ".chezmoiexternal.toml",
            f'[".h"]\n    type = "file"\n    url = "{self.url}"\n',
        )


TTY_ERROR = (
    b"chezmoi: .h: could not open a new TTY: open /dev/tty: "
    b"no such device or address\n"
)


def test_progress_true_without_tty_is_an_error(env):
    """--progress=true makes the HTTP read fail when no TTY exists."""
    with LoopbackServer() as server:
        server.define_external(env)
        result = env.run(
            ["cat", *env.flags(), "--progress=true", str(env.home / ".h")],
            setsid=True,
        )
        # CATCHES: with progress forced on and no controlling terminal the
        # response reader cannot open /dev/tty and the whole command fails
        # with this exact error; the target is never written, exactly one
        # unconditional GET reached the wire, and nothing is cached under
        # <cacheDir>/external because the download never completed.
        assert result.returncode == 1
        assert result.stdout == b""
        assert result.stderr == TTY_ERROR
        assert not (env.home / ".h").exists()
        assert server.requests == [None]
        assert not (env.cache / "external").exists()


def test_progress_true_chunked_response_same_error(env):
    """A response without Content-Length takes the spinner path, same error."""
    with LoopbackServer(chunked=True) as server:
        server.define_external(env)
        result = env.run(
            ["cat", *env.flags(), "--progress=true", str(env.home / ".h")],
            setsid=True,
        )
        # CATCHES: a chunked response (no Content-Length) selects the
        # spinner model instead of the progress bar, but without a TTY the
        # read still fails with the identical /dev/tty error and the single
        # request that was made stayed unconditional.
        assert result.returncode == 1
        assert result.stdout == b""
        assert result.stderr == TTY_ERROR
        assert server.requests == [None]


def test_progress_error_repeats_on_second_fetch(env):
    """The TTY error repeats when the response is re-served from the cache."""
    with LoopbackServer() as server:
        server.define_external(env)
        first = env.run(
            ["cat", *env.flags(), "--progress=true", str(env.home / ".h")],
            setsid=True,
        )
        second = env.run(
            ["cat", *env.flags(), "--progress=true", str(env.home / ".h")],
            setsid=True,
        )
        # CATCHES: the failed download still leaves the response usable in
        # the HTTP response cache, and the second run reads THAT response
        # through the same progress reader, so it fails with the same error
        # instead of succeeding; the target is never created either time.
        assert first.returncode == 1
        assert first.stderr == TTY_ERROR
        assert second.returncode == 1
        assert second.stderr == TTY_ERROR
        assert not (env.home / ".h").exists()


def test_progress_no_tty_flag_short_circuits(env):
    """--no-tty disables the progress reader even with --progress=true."""
    with LoopbackServer() as server:
        server.define_external(env)
        result = env.run(
            [
                "cat",
                *env.flags(),
                "--no-tty",
                "--progress=true",
                str(env.home / ".h"),
            ],
        )
        # CATCHES: --no-tty takes precedence over --progress=true: the
        # response body is read plainly and the external is served despite
        # the forced progress setting.
        assert result.returncode == 0, result.stderr
        assert result.stdout == b"body-one\n"
        assert result.stderr == b""


def test_progress_true_ignored_for_file_urls(env):
    """--progress=true does not affect file:// externals."""
    payload = env.root / "plug.txt"
    payload.write_bytes(b"plug\n")
    env.write(
        ".chezmoiexternal.toml",
        f'[".h"]\n    type = "file"\n    url = "file://{payload}"\n',
    )
    result = env.run(
        ["cat", *env.flags(), "--progress=true", str(env.home / ".h")],
        setsid=True,
    )
    # CATCHES: the progress reader is only used for HTTP responses; a
    # file:// external is read straight from disk and succeeds with
    # progress forced on and no TTY available.
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"plug\n"
    assert result.stderr == b""


@pytest.mark.parametrize(
    "value,returncode,stdout,stderr",
    [
        ("auto", 0, b"body-one\n", b""),
        (
            "garbage",
            1,
            b"",
            b'chezmoi: invalid argument "garbage" for "--progress" flag: '
            b'strconv.ParseBool: parsing "garbage": invalid syntax\n',
        ),
    ],
)
def test_progress_value_grammar(env, value, returncode, stdout, stderr):
    """--progress accepts auto and bool spellings; others are flag errors."""
    with LoopbackServer() as server:
        server.define_external(env)
        result = env.run(
            ["cat", *env.flags(), f"--progress={value}", str(env.home / ".h")],
        )
        # CATCHES: auto resolves against stdout (a pipe here, so progress
        # stays off and the body is served untouched), while an unparsable
        # value fails flag parsing with the strconv error before the
        # command runs at all.
        assert result.returncode == returncode
        assert result.stdout == stdout
        assert result.stderr == stderr
