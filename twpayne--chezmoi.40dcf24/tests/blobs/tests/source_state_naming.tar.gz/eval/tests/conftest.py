"""Shared harness for the ``source_state_naming`` module tests.

Every test drives the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hard-coded path).  The entry point is ``Env.run``, which executes the candidate
inside a pinned, hermetic per-test environment and returns the completed
process with byte-exact ``stdout``/``stderr``.

Each ``Env`` owns a scratch root (a pytest ``tmp_path``) containing:

* ``src``   -- the source directory (passed with ``--source``),
* ``home``  -- the destination directory and the child's ``HOME``,
* ``xdg``   -- ``XDG_CONFIG_HOME``/``XDG_CACHE_HOME`` so that the persistent
  state and any default config lookup stay inside the scratch root,
* ``cache`` -- the ``--cache`` directory,
* ``tmp``   -- the child's ``TMPDIR`` (scripts are copied here before running).

``Env.norm`` rewrites the scratch root to ``@ROOT@`` so recorded expectations
can be embedded as literal strings.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

# A fixed, pinned child environment: no dependence on the ambient environment,
# no network, and a PATH that only reaches the standard system programs.
# GIT_CONFIG_* pins git (used by git-repo externals) to its built-in defaults
# so a global or system gitconfig can never change its behavior.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "LANG": "C",
    "LC_ALL": "C",
    "GIT_CONFIG_GLOBAL": "/dev/null",
    "GIT_CONFIG_NOSYSTEM": "1",
}

ROOT_PLACEHOLDER = b"@ROOT@"


def executable_path() -> str:
    """Return the candidate path from PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE", "")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; the suite cannot drive the candidate"
        )
    return path


class Env:
    """A hermetic chezmoi environment rooted inside a pytest tmp_path."""

    def __init__(self, root: Path):
        self.root = root
        self.src = root / "src"
        self.home = root / "home"
        self.xdg = root / "xdg"
        self.cache = root / "cache"
        self.tmp = root / "tmp"
        for directory in (self.src, self.home, self.xdg, self.cache, self.tmp):
            directory.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ files

    def write(self, relpath: str, data) -> Path:
        """Write DATA (str or bytes) into the source directory at RELPATH."""
        path = self.src / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(data, str):
            data = data.encode()
        path.write_bytes(data)
        return path

    def write_home(self, relpath: str, data) -> Path:
        """Write DATA into the destination directory at RELPATH."""
        path = self.home / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(data, str):
            data = data.encode()
        path.write_bytes(data)
        return path

    def mkdir(self, relpath: str) -> Path:
        """Create a directory in the source directory at RELPATH."""
        path = self.src / relpath
        path.mkdir(parents=True, exist_ok=True)
        return path

    def source_names(self) -> list[str]:
        """Return the sorted top-level source entry names."""
        return sorted(entry.name for entry in self.src.iterdir())

    # ------------------------------------------------------------------- run

    def flags(self, *extra: str) -> list[str]:
        """The standard --source/--destination/--cache flags, plus EXTRA."""
        return [
            "--source",
            str(self.src),
            "--destination",
            str(self.home),
            "--cache",
            str(self.cache),
            *extra,
        ]

    def env(self) -> dict[str, str]:
        """Build the pinned child environment for this scratch root."""
        merged = dict(BASE_ENV)
        for key in list(merged):
            if key.startswith(("XDG_", "CHEZMOI")):
                del merged[key]
        merged.update(
            {
                "HOME": str(self.home),
                "TMPDIR": str(self.tmp),
                "XDG_CONFIG_HOME": str(self.xdg),
                "XDG_CACHE_HOME": str(self.cache),
            }
        )
        # Coverage instrumentation hook (REQUIRED): copy GOCOVERDIR from the
        # test process environment into the child env when present, so the
        # pipeline can measure source coverage of the reference binary.
        cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
        merged.update(cov_env)
        return merged

    def run(
        self,
        argv,
        *,
        stdin: bytes = b"",
        timeout: int = 30,
        setsid: bool = False,
        umask: str | None = None,
    ):
        """Run the candidate with ARGV and return the completed process.

        stdout and stderr are always bytes.  The child runs with the pinned
        environment from ``Env.env`` and its working directory at the scratch
        root, so relative path arguments resolve against ``@ROOT@``.

        With SETSID the child starts a new session and therefore has no
        controlling terminal, making TTY-dependent behavior (e.g. opening
        /dev/tty) deterministic regardless of whether the test process
        itself is attached to a terminal.

        With UMASK (an octal string like ``"022"``) the candidate is started
        through ``bash -c 'umask ...; exec "$0" "$@"'`` so that the process
        umask chezmoi reads at startup is pinned; this makes file-mode
        assertions deterministic no matter what umask pytest inherits.
        """
        data = stdin if isinstance(stdin, bytes) else stdin.encode()
        if umask is None:
            command = [executable_path()] + list(argv)
        else:
            command = [
                "bash",
                "-c",
                f'umask {umask}; exec "$0" "$@"',
                executable_path(),
                *list(argv),
            ]
        return subprocess.run(
            command,
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(self.root),
            env=self.env(),
            timeout=timeout,
            start_new_session=setsid,
        )

    # ------------------------------------------------------------- normalize

    def norm(self, data) -> bytes:
        """Rewrite the scratch root path in DATA (bytes or str) to ``@ROOT@``."""
        root_bytes = str(self.root).encode()
        if isinstance(data, str):
            return data.replace(str(self.root), "@ROOT@").encode()
        return data.replace(root_bytes, ROOT_PLACEHOLDER)

    def normtext(self, data) -> str:
        """``Env.norm`` as str, for building readable expected strings."""
        return self.norm(data).decode()


def make_age_config(env: Env) -> tuple[Path, str]:
    """Generate an age identity and a chezmoi config enabling age encryption.

    Returns ``(config_path, recipient)``.  The identity and config live inside
    the scratch root so nothing leaks outside the test's tmp_path.
    """
    identity = env.root / "age-identity.txt"
    result = env.run(["age-keygen", "-o", str(identity)])
    assert result.returncode == 0, result.stderr
    recipient = ""
    for line in identity.read_text().splitlines():
        if line.startswith("# public key: "):
            recipient = line[len("# public key: ") :]
    assert recipient, "age-keygen did not produce a recipient"
    config = env.root / "age-config.toml"
    config.write_text(
        'encryption = "age"\n'
        "[age]\n"
        f'    identity = "{identity}"\n'
        f'    recipient = "{recipient}"\n'
    )
    return config, recipient


@pytest.fixture()
def env(tmp_path):
    """A fresh hermetic environment for one test."""
    return Env(tmp_path / "scratch")
