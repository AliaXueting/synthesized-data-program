"""Unsupported file types and doctor's suspicious-entry detection."""

from __future__ import annotations

import os
import stat


def test_fifo_in_source_dir_is_unsupported(env):
    """A named pipe in the source dir aborts state-reading commands."""
    env.write("dot_a", "a\n")
    os.mkfifo(env.src / "pipename")
    result = env.run(["managed", *env.flags()])
    # CATCHES: reading the source state refuses non-regular, non-dir,
    # non-symlink entries: a FIFO aborts managed with the absolute source
    # path and the mode's human name "named pipe" -- not a skip, and the
    # same error comes from unmanaged, which also walks the source state.
    assert result.returncode == 1
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: @ROOT@/src/pipename: unsupported file type named pipe\n"
    )
    unmanaged = env.run(["unmanaged", *env.flags()])
    assert unmanaged.returncode == 1
    assert unmanaged.stdout == b""
    assert env.norm(unmanaged.stderr) == (
        b"chezmoi: @ROOT@/src/pipename: unsupported file type named pipe\n"
    )


def test_apply_onto_fifo_target_is_unsupported(env):
    """Applying a file whose destination is a FIFO fails, keeping the FIFO."""
    env.write("dot_pipe", "contents\n")
    os.mkfifo(env.home / ".pipe")
    result = env.run(["apply", *env.flags()])
    # CATCHES: apply reads the actual state of the target before writing;
    # a FIFO there is unsupported ("named pipe"), the error is prefixed
    # with the target's relative path AND the destination path, and the
    # FIFO is left exactly as it was (not removed or replaced).
    assert result.returncode == 1
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: .pipe: @ROOT@/home/.pipe: unsupported file type named pipe\n"
    )
    assert stat.S_ISFIFO(os.stat(env.home / ".pipe").st_mode)


def test_doctor_reports_suspicious_source_entries(env):
    """doctor flags unknown .chezmoi* names and known target file names."""
    env.write("dot_a", "a\n")
    env.write(".chezmoibogus", "x\n")
    env.mkdir(".chezmoiunknowndir")
    env.write("literal_chezmoi.toml", "y\n")
    result = env.run(["doctor", "--no-network", *env.flags()])
    lines = [
        line
        for line in env.normtext(result.stdout.decode()).splitlines()
        if "suspicious-entries" in line
    ]
    # CATCHES: doctor walks the source dir and reports exactly the entries
    # that are .chezmoi-prefixed but unknown (.chezmoibogus file,
    # .chezmoiunknowndir dir) plus any name whose TARGET is a reserved
    # config file (literal_chezmoi.toml -> chezmoi.toml) -- comma-joined
    # with "and" before the last, in the fixed RESULT/CHECK columns.
    assert lines == [
        "warning   suspicious-entries          "
        "@ROOT@/src/.chezmoibogus, "
        "@ROOT@/src/.chezmoiunknowndir, "
        "and @ROOT@/src/literal_chezmoi.toml"
    ]
    suspicious = env.run(["managed", *env.flags()])
    # CATCHES: the suspicious entries are only a doctor warning: the state
    # reader skips the unknown .chezmoi* names but still manages the
    # literal_chezmoi.toml entry as an ordinary file targeting chezmoi.toml.
    assert suspicious.returncode == 0, suspicious.stderr
    assert suspicious.stdout.decode() == ".a\nchezmoi.toml\n"


def test_doctor_clean_source_has_no_suspicious_entries(env):
    """A clean source dir yields the ok suspicious-entries line."""
    env.write("dot_a", "a\n")
    env.mkdir("dot_vim")
    env.write("dot_vim/vimrc", "x\n")
    result = env.run(["doctor", "--no-network", *env.flags()])
    lines = [
        line
        for line in result.stdout.decode().splitlines()
        if "suspicious-entries" in line
    ]
    # CATCHES: ordinary dot_-prefixed files and directories are never
    # suspicious -- the ok line reads "no suspicious entries" in the same
    # fixed-column layout as the warning form.
    assert lines == ["ok        suspicious-entries          no suspicious entries"]


def test_doctor_flags_chezmoi_symlinks_and_fifos(env):
    """doctor flags any .chezmoi* symlink and any FIFO, by type alone."""
    env.write("dot_a", "a\n")
    env.mkdir("plaindir")
    os.symlink("dot_a", env.src / ".chezmoi_link")
    os.symlink("plaindir", env.src / ".chezmoi_dirlink")
    os.symlink("nowhere", env.src / ".chezmoi_dangle")
    os.symlink("dot_a", env.src / "plainlink")
    os.mkfifo(env.src / "plainfifo")
    result = env.run(["doctor", "--no-network", *env.flags()])
    lines = [
        line
        for line in env.normtext(result.stdout.decode()).splitlines()
        if "suspicious-entries" in line
    ]
    # CATCHES: symlinks are suspicious purely because of their .chezmoi
    # name prefix -- no matter whether the target is a file, a directory,
    # or missing -- while a non-.chezmoi symlink is fine; a FIFO is
    # suspicious regardless of its plain, dot-free name.
    assert lines == [
        "warning   suspicious-entries          "
        "@ROOT@/src/.chezmoi_dangle, "
        "@ROOT@/src/.chezmoi_dirlink, "
        "@ROOT@/src/.chezmoi_link, "
        "and @ROOT@/src/plainfifo"
    ]


def test_doctor_flags_unparsable_source_name(env):
    """doctor flags a source file whose name cannot be parsed at all."""
    env.write("dot_a", "a\n")
    env.write("dot_", "empty target name\n")
    result = env.run(["doctor", "--no-network", *env.flags()])
    lines = [
        line
        for line in env.normtext(result.stdout.decode()).splitlines()
        if "suspicious-entries" in line
    ]
    # CATCHES: dot_ leaves an empty target name after prefix stripping, so
    # the name cannot be parsed as an attribute sequence at all -- doctor
    # flags it as suspicious, and managed fails outright with the invalid
    # path error, showing why the entry is unusable.
    assert lines == ["warning   suspicious-entries          @ROOT@/src/dot_"]
    broken = env.run(["managed", *env.flags()])
    assert broken.returncode == 1
    assert broken.stdout == b""
    assert broken.stderr == b"chezmoi: dot_: invalid path\n"
