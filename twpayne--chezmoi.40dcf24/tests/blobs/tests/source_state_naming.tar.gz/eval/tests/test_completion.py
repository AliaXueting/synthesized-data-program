"""Shell flag completion for the state-reading commands.

Cobra's hidden ``__complete`` command drives the registered flag completion
functions, which enumerate the allowed values of the managed command's
choice flags (path styles, formats) and the entry-type filter flags.
"""

from __future__ import annotations

PATH_STYLES = [
    "absolute",
    "all",
    "relative",
    "source-absolute",
    "source-relative",
]

ENTRY_TYPES = [
    "all",
    "always",
    "dirs",
    "encrypted",
    "externals",
    "files",
    "noalways",
    "nodirs",
    "noencrypted",
    "noexternals",
    "nofiles",
    "none",
    "noremove",
    "noscripts",
    "nosymlinks",
    "notemplates",
    "remove",
    "scripts",
    "symlinks",
    "templates",
]


def test_path_style_flag_completion(env):
    """Completing --path-style enumerates every path style, filtered by prefix."""
    result = env.run(["__complete", "managed", *env.flags(), "--path-style", ""])
    # CATCHES: the flag completion lists all five path styles in sorted
    # order for an empty prefix and ends with cobra's :4 directive on
    # stdout; the directive is also explained on stderr, rc 0.
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == "\n".join(PATH_STYLES) + "\n:4\n"
    assert result.stderr == (
        b"Completion ended with directive: ShellCompDirectiveNoFileComp\n"
    )
    prefixed = env.run(
        ["__complete", "managed", *env.flags(), "--path-style", "source-a"]
    )
    # CATCHES: only completions with the given PREFIX survive: source-a
    # expands to source-absolute alone (not source-relative).
    assert prefixed.returncode == 0, prefixed.stderr
    assert prefixed.stdout.decode() == "source-absolute\n:4\n"
    nomatch = env.run(
        ["__complete", "managed", *env.flags(), "--path-style", "z"]
    )
    # CATCHES: a prefix matching nothing yields no completions, but the
    # command still succeeds with the directive line only.
    assert nomatch.returncode == 0, nomatch.stderr
    assert nomatch.stdout.decode() == ":4\n"
    short = env.run(["__complete", "managed", *env.flags(), "-p", ""])
    # CATCHES: the completion is registered for the flag itself, so the -p
    # short form enumerates the same five styles as --path-style.
    assert short.returncode == 0, short.stderr
    assert short.stdout.decode() == "\n".join(PATH_STYLES) + "\n:4\n"


def test_include_flag_completion(env):
    """Completing --include enumerates entry types and their no- negations."""
    result = env.run(["__complete", "managed", *env.flags(), "--include", ""])
    # CATCHES: the include completion offers every entry type together
    # with its no- negation plus all/none, sorted, and ends with the :6
    # directive (NoSpace, so a comma list can keep being typed).
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == "\n".join(ENTRY_TYPES) + "\n:6\n"
    assert result.stderr == (
        b"Completion ended with directive: "
        b"ShellCompDirectiveNoSpace, ShellCompDirectiveNoFileComp\n"
    )
    prefixed = env.run(
        ["__complete", "managed", *env.flags(), "--include", "noex"]
    )
    # CATCHES: only values with the typed PREFIX are offered: noex yields
    # noexternals alone (noencrypted starts "noen", not "noex").
    assert prefixed.returncode == 0, prefixed.stderr
    assert prefixed.stdout.decode() == "noexternals\n:6\n"
    comma = env.run(
        ["__complete", "managed", *env.flags(), "--include", "dirs,noex"]
    )
    # CATCHES: completion works on the LAST element of a comma list and
    # re-prepends the already-typed elements, offering "dirs,noexternals".
    assert comma.returncode == 0, comma.stderr
    assert comma.stdout.decode() == "dirs,noexternals\n:6\n"
