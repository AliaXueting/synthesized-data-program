"""External definitions: .chezmoiexternal files, checksums, filters,
decompression, url failover, refresh-externals and the cache."""

from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess

import pytest

PLUG = b"hello-plugin\n"
PLUG_SHA256 = "b9b77bed3570c24421550fec964aa2cb840d51143bc84f09728e89012eb3484a"
DEAD_URL = "http://127.0.0.1:9/x"


def make_payload(env):
    """Create a tgz archive payload-1.0/{top.txt,sub/deep.txt} in the root."""
    payload = env.root / "payload-1.0"
    (payload / "sub").mkdir(parents=True)
    (payload / "top.txt").write_text("payload-top\n")
    (payload / "sub/deep.txt").write_text("payload-sub\n")
    import subprocess

    archive = env.root / "payload.tgz"
    subprocess.run(
        ["tar", "czf", str(archive), "payload-1.0"],
        cwd=str(env.root),
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return archive


def external_toml(env, body):
    """Write src/.chezmoiexternal.toml with BODY and return its path."""
    return env.write(".chezmoiexternal.toml", body)


def test_external_file_managed_listing(env):
    """A file external yields three managed entries, two for the parent dir."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".plug/file"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n',
    )
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the external file produces THREE entries: the implicit
    # parent dir twice (once with an empty source path, once with the
    # reverse-mapped name dot_plug) and the file itself -- default managed
    # output prints .plug, .plug, .plug/file.
    assert result.stdout.decode() == ".plug\n.plug\n.plug/file\n"


def test_external_file_source_names(env):
    """The synthetic source names of a file external and its parent dir."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".plug/file"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n',
    )
    result = env.run(["managed", *env.flags(), "-p", "source-relative"])
    assert result.returncode == 0, result.stderr
    # CATCHES: -p source-relative reveals the invented source names: the
    # parent dir maps to the source dir itself (empty line) and to dot_plug,
    # and the file becomes dot_plug/create_empty_ -- names no real file has.
    assert result.stdout.decode() == "\ndot_plug\ndot_plug/create_empty_\n"


def test_external_file_cat_apply_and_filters(env):
    """cat reads through the external, apply materializes it, -i externals
    selects just the file, and unmanaged stays empty."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".plug/file"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n',
    )
    cat = env.run(["cat", *env.flags(), str(env.home / ".plug/file")])
    assert cat.returncode == 0, cat.stderr
    assert cat.stdout == PLUG
    apply = env.run(["apply", *env.flags()])
    assert apply.returncode == 0, apply.stderr
    assert (env.home / ".plug/file").read_bytes() == PLUG
    externals = env.run(["managed", *env.flags(), "-i", "externals"])
    # CATCHES: -i externals lists only the FILE entry (.plug/file), not the
    # implicit dir entries, and after apply the only unmanaged path would
    # be nothing because the persistent state lives outside the dest dir.
    assert externals.returncode == 0, externals.stderr
    assert externals.stdout.decode() == ".plug/file\n"
    unmanaged = env.run(["unmanaged", *env.flags()])
    assert unmanaged.returncode == 0, unmanaged.stderr
    assert unmanaged.stdout == b""


def test_external_archive_apply(env):
    """An archive external extracts all members under the target dir."""
    archive = make_payload(env)
    external_toml(
        env,
        f'[".arc"]\n    type = "archive"\n    url = "file://{archive}"\n',
    )
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    found = sorted(
        str(p.relative_to(env.home)) for p in env.home.rglob("*")
    )
    # CATCHES: archive members keep their inner paths (payload-1.0/...)
    # under the target, including the sub/ directory hierarchy.
    assert found == [
        ".arc",
        ".arc/payload-1.0",
        ".arc/payload-1.0/sub",
        ".arc/payload-1.0/sub/deep.txt",
        ".arc/payload-1.0/top.txt",
    ]


def test_external_archive_strip_components(env):
    """stripComponents removes leading path components of each member."""
    archive = make_payload(env)
    external_toml(
        env,
        f'[".arc"]\n    type = "archive"\n    url = "file://{archive}"\n'
        "    stripComponents = 1\n",
    )
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    found = sorted(str(p.relative_to(env.home)) for p in env.home.rglob("*"))
    # CATCHES: stripping one component drops payload-1.0/ from every member
    # path, so top.txt and sub/deep.txt land directly under .arc.
    assert found == [".arc", ".arc/sub", ".arc/sub/deep.txt", ".arc/top.txt"]


def test_external_archive_include_exclude(env):
    """include/exclude filter members by their full archive paths."""
    archive = make_payload(env)
    external_toml(
        env,
        f'[".arc"]\n    type = "archive"\n    url = "file://{archive}"\n'
        '    include = ["payload-1.0/top.txt"]\n'
        '    exclude = ["payload-1.0/sub/**"]\n',
    )
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    found = sorted(str(p.relative_to(env.home)) for p in env.home.rglob("*"))
    # CATCHES: include and exclude both match the FULL inner path of the
    # archive member (payload-1.0/top.txt), not the stripped target path,
    # and include wins over the unfiltered members.
    assert found == [".arc", ".arc/payload-1.0", ".arc/payload-1.0/top.txt"]


def test_external_archive_file_extracts_single_member(env):
    """type archive-file extracts exactly one member as a regular file."""
    archive = make_payload(env)
    external_toml(
        env,
        f'[".af"]\n    type = "archive-file"\n    url = "file://{archive}"\n'
        '    path = "payload-1.0/top.txt"\n',
    )
    listing = env.run(["managed", *env.flags()])
    assert listing.returncode == 0, listing.stderr
    assert listing.stdout.decode() == ".af\n"
    cat = env.run(["cat", *env.flags(), str(env.home / ".af")])
    # CATCHES: archive-file yields a single managed entry (.af, no parent
    # dir entry like the file type) whose content is the named member.
    assert cat.returncode == 0, cat.stderr
    assert cat.stdout == b"payload-top\n"


def test_external_checksum_sha256(env):
    """A matching sha256 passes; a mismatch aborts with both hashes."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".oksum"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'    [".oksum".checksum]\n        sha256 = "{PLUG_SHA256}"\n',
    )
    ok = env.run(["cat", *env.flags(), str(env.home / ".oksum")])
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == PLUG
    external_toml(
        env,
        f'[".badsum"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        '    [".badsum".checksum]\n'
        '        sha256 = "0000000000000000000000000000000000000000000000000000000000000000"\n',
    )
    bad = env.run(["cat", *env.flags(), str(env.home / ".badsum")])
    # CATCHES: the mismatch error prints the expected hash, the ACTUAL hash
    # of the downloaded data and exits 1 before any content is written.
    assert bad.returncode == 1
    assert bad.stdout == b""
    assert bad.stderr == (
        f"chezmoi: .badsum: SHA256 mismatch: expected "
        f"{'0' * 64}, got {PLUG_SHA256}\n"
    ).encode()


def test_external_checksum_md5_warns_but_succeeds(env):
    """An md5 checksum warns on stderr and still returns the content."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    digest = hashlib.md5(PLUG).hexdigest()
    external_toml(
        env,
        f'[".md5"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'    [".md5".checksum]\n        md5 = "{digest}"\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".md5")])
    # CATCHES: the insecure-hash warning goes to STDERR while the content
    # still arrives on stdout with rc 0 -- the warning never pollutes the
    # data stream.
    assert result.returncode == 0, result.stderr
    assert result.stdout == PLUG
    assert result.stderr == (
        b"chezmoi: .md5: warning: insecure MD5 checksum will be removed, "
        b"use a secure hash like SHA256 instead\n"
    )


def test_external_checksum_sha1_warns_and_verifies(env):
    """An sha1 checksum warns on stderr, verifies, and rejects mismatches."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    digest = hashlib.sha1(PLUG).hexdigest()
    external_toml(
        env,
        f'[".s1"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'    [".s1".checksum]\n        sha1 = "{digest}"\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".s1")])
    # CATCHES: sha1 is treated exactly like md5 -- the insecure-hash
    # warning names SHA1 and goes to stderr while the content still arrives
    # on stdout with rc 0.
    assert result.returncode == 0, result.stderr
    assert result.stdout == PLUG
    assert result.stderr == (
        b"chezmoi: .s1: warning: insecure SHA1 checksum will be removed, "
        b"use a secure hash like SHA256 instead\n"
    )
    external_toml(
        env,
        f'[".s1"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'    [".s1".checksum]\n        sha1 = "{"0" * 40}"\n',
    )
    rejected = env.run(["cat", *env.flags(), str(env.home / ".s1")])
    # CATCHES: a wrong sha1 digest fails the fetch with the mismatch error
    # (expected vs got) after the same insecure warning, rc 1.
    assert rejected.returncode == 1
    assert rejected.stdout == b""
    assert rejected.stderr == (
        b"chezmoi: .s1: warning: insecure SHA1 checksum will be removed, "
        b"use a secure hash like SHA256 instead\n"
        b"chezmoi: .s1: SHA1 mismatch: expected "
        + b"0" * 40
        + b", got "
        + digest.encode()
        + b"\n"
    )


def test_external_archive_preserves_member_modes(env):
    """Archive members are applied with their own archived permission bits."""
    payload = env.root / "payload-1.0"
    payload.mkdir()
    for name, text, mode in [
        ("secret.txt", "sec\n", 0o600),
        ("locked.txt", "ro\n", 0o444),
        ("tool.sh", "x\n", 0o755),
        ("plain.txt", "p\n", 0o644),
    ]:
        member = payload / name
        member.write_text(text)
        member.chmod(mode)
    archive = env.root / "payload.tgz"
    subprocess.run(
        ["tar", "czf", str(archive), "payload-1.0"],
        cwd=str(env.root),
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    external_toml(
        env,
        f'[".arc"]\n    type = "archive"\n    url = "file://{archive}"\n',
    )
    result = env.run(["apply", *env.flags()], umask="022")
    assert result.returncode == 0, result.stderr
    modes = {
        name: stat.S_IMODE(os.stat(env.home / ".arc/payload-1.0" / name).st_mode)
        for name in ("secret.txt", "locked.txt", "tool.sh", "plain.txt")
    }
    # CATCHES: member modes come from the archive entries themselves: 0600
    # is applied as private 0600, 0444 as read-only 0444, 0755 as
    # executable 0755 -- not flattened to the plain-file default.
    assert modes == {
        "secret.txt": 0o600,
        "locked.txt": 0o444,
        "tool.sh": 0o755,
        "plain.txt": 0o644,
    }


def test_external_checksum_sha384_and_sha512(env):
    """sha384/sha512 checksums verify silently, with no insecurity warning."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    for algorithm, digest in [
        ("sha384", hashlib.sha384(PLUG).hexdigest()),
        ("sha512", hashlib.sha512(PLUG).hexdigest()),
    ]:
        external_toml(
            env,
            f'[".sum"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
            f'    [".sum".checksum]\n        {algorithm} = "{digest}"\n',
        )
        result = env.run(["cat", *env.flags(), str(env.home / ".sum")])
        # CATCHES: sha384 and sha512 are accepted as secure checksums: the
        # content is served with rc 0 and stderr stays completely empty --
        # no "insecure" warning unlike md5/sha1/ripemd160.
        assert result.returncode == 0, (algorithm, result.stderr)
        assert result.stdout == PLUG, algorithm
        assert result.stderr == b"", algorithm


def test_external_checksum_ripemd160_quirk(env):
    """RIPEMD-160 warns and hashes contents||ripemd160(""), not the contents."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    real = hashlib.new("ripemd160", PLUG).hexdigest()
    empty_digest = hashlib.new("ripemd160", b"").digest()
    quirk = (PLUG + empty_digest).hex()
    warning = (
        b"chezmoi: .ripemd: warning: insecure RIPEMD-160 checksum will be "
        b"removed, use a secure hash like SHA256 instead\n"
    )
    external_toml(
        env,
        f'[".ripemd"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'    [".ripemd".checksum]\n        ripemd160 = "{real}"\n',
    )
    rejected = env.run(["cat", *env.flags(), str(env.home / ".ripemd")])
    # CATCHES: the reference does NOT compute ripemd160(contents) -- it
    # appends the hash of the EMPTY input to the contents, so a genuine
    # RIPEMD-160 of the payload is REJECTED with a mismatch error whose
    # "got" side is hex(contents || ripemd160("")).
    assert rejected.returncode == 1
    assert rejected.stdout == b""
    assert rejected.stderr == (
        warning
        + b"chezmoi: .ripemd: RIPEMD-160 mismatch: expected "
        + real.encode()
        + b", got "
        + quirk.encode()
        + b"\n"
    )
    external_toml(
        env,
        f'[".ripemd"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'    [".ripemd".checksum]\n        ripemd160 = "{quirk}"\n',
    )
    accepted = env.run(["cat", *env.flags(), str(env.home / ".ripemd")])
    # CATCHES: feeding back exactly hex(contents || ripemd160("")) makes
    # the check pass (with the insecurity warning), pinning the quirk from
    # the accepting side as well.
    assert accepted.returncode == 0, accepted.stderr
    assert accepted.stdout == PLUG
    assert accepted.stderr == warning


def test_external_checksum_size(env):
    """A size-only check warns; a wrong size fails with both sizes."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".size"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'    [".size".checksum]\n        size = {len(PLUG)}\n',
    )
    ok = env.run(["cat", *env.flags(), str(env.home / ".size")])
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout == PLUG
    assert ok.stderr == (
        b"chezmoi: .size: warning: insecure size check without secure hash "
        b"will be removed\n"
    )
    external_toml(
        env,
        f'[".sizebad"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        '    [".sizebad".checksum]\n        size = 999\n',
    )
    bad = env.run(["cat", *env.flags(), str(env.home / ".sizebad")])
    # CATCHES: a size mismatch emits BOTH the warning line and the mismatch
    # line on stderr (two lines, in that order) and exits 1.
    assert bad.returncode == 1
    assert bad.stdout == b""
    assert bad.stderr == (
        b"chezmoi: .sizebad: warning: insecure size check without secure "
        b"hash will be removed\n"
        b"chezmoi: .sizebad: size mismatch: expected 999, got 13\n"
    )


def test_external_filter_command(env):
    """filter.command pipes the downloaded data through a program."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".f"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        '    [".f".filter]\n        command = "tr"\n        args = ["a-z", "A-Z"]\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".f")])
    # CATCHES: the filter runs with the external data on stdin and its
    # stdout becomes the target contents (tr uppercases hello-plugin).
    assert result.returncode == 0, result.stderr
    assert result.stdout == b"HELLO-PLUGIN\n"


def test_external_filter_bad_command(env):
    """A missing filter command fails with the exec error and full URL."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".f"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        '    [".f".filter]\n        command = "definitely-not-a-command-xyz"\n'
        '        args = []\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".f")])
    assert result.returncode == 1
    # CATCHES: the error embeds the file:// URL being fetched and the raw
    # exec failure text for the missing command from $PATH.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: .f: file://@ROOT@/plug.txt: exec: "
        b'"definitely-not-a-command-xyz": executable file not found in $PATH\n'
    )


def test_external_decompress_gzip(env):
    """decompress = gzip inflates the downloaded data."""
    import gzip

    env.root.joinpath("plug.gz").write_bytes(gzip.compress(PLUG))
    external_toml(
        env,
        f'[".g"]\n    type = "file"\n    url = "file://{env.root}/plug.gz"\n'
        '    decompress = "gzip"\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".g")])
    # CATCHES: decompression happens after download and before checksums/
    # output, so the target holds the inflated plaintext.
    assert result.returncode == 0, result.stderr
    assert result.stdout == PLUG


def test_external_decompress_invalid_format_name(env):
    """An unknown decompress format name fails when the data is read."""
    import gzip

    env.root.joinpath("plug.gz").write_bytes(gzip.compress(PLUG))
    external_toml(
        env,
        f'[".g"]\n    type = "file"\n    url = "file://{env.root}/plug.gz"\n'
        '    decompress = "gz"\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".g")])
    # CATCHES: the format name must be exactly "gzip"; the abbreviation
    # "gz" is rejected with the format name echoed in the error, even
    # though the downloaded data really is gzip-compressed.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: .g: gz: unknown compression format\n"


def test_external_decompress_wrong_format_data(env):
    """Applying a valid format to non-conforming data reports the codec error."""
    env.root.joinpath("plain.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".bogus"]\n    type = "file"\n    url = "file://{env.root}/plain.txt"\n'
        '    decompress = "flate"\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".bogus")])
    # CATCHES: "flate" is an accepted format name, so the failure comes
    # from the decompressor rejecting the plaintext body, with the codec's
    # own error text surfaced unchanged.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: .bogus: flate: unknown compression format\n"


def test_external_urls_failover(env):
    """urls are tried in order until one succeeds."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".fo"]\n    type = "file"\n'
        f'    urls = ["{DEAD_URL}", "file://{env.root}/plug.txt"]\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".fo")])
    # CATCHES: a dead first URL is skipped silently (no warning, no retry
    # noise) and the second URL serves the content; rc stays 0.
    assert result.returncode == 0, result.stderr
    assert result.stdout == PLUG


def test_external_urls_all_dead(env):
    """When every URL fails the first URL's error is reported."""
    external_toml(
        env,
        f'[".dead"]\n    type = "file"\n'
        f'    urls = ["{DEAD_URL}", "http://127.0.0.1:9/y"]\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".dead")])
    # CATCHES: the reported failure is the FIRST url (/x), not the last
    # (/y), with the exact Go http error for a refused local connection.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'chezmoi: .dead: Get "http://127.0.0.1:9/x": '
        b"dial tcp 127.0.0.1:9: connect: connection refused\n"
    )


def test_external_url_takes_precedence_over_urls(env):
    """A url field wins over the urls list."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".up"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'    urls = ["{DEAD_URL}"]\n',
    )
    result = env.run(["cat", *env.flags(), str(env.home / ".up")])
    # CATCHES: url is preferred over urls, so the dead entry in urls is
    # never attempted and the good file:// url serves the content.
    assert result.returncode == 0, result.stderr
    assert result.stdout == PLUG


def test_external_config_formats_and_dir(env):
    """json/yaml top-level files and the .chezmoiexternals/ dir all merge."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    env.write(
        ".chezmoiexternal.json",
        json.dumps({".jsonext": {"type": "file", "url": f"file://{env.root}/plug.txt"}}) + "\n",
    )
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == ".jsonext\n"
    (env.src / ".chezmoiexternal.json").unlink()
    env.write(
        ".chezmoiexternal.yaml",
        f".yamlext:\n    type: file\n    url: file://{env.root}/plug.txt\n",
    )
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == ".yamlext\n"
    (env.src / ".chezmoiexternal.yaml").unlink()
    env.mkdir(".chezmoiexternals")
    env.write(
        ".chezmoiexternals/one.toml",
        f'[".fromtoml"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n',
    )
    env.write(
        ".chezmoiexternals/two.yaml",
        f".fromyaml:\n    type: file\n    url: file://{env.root}/plug.txt\n",
    )
    result = env.run(["managed", *env.flags()])
    # CATCHES: every supported format (.chezmoiexternal.{json,toml,yaml} and
    # any file in .chezmoiexternals/) defines externals independently, and
    # multiple files in the directory are merged into one source state.
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == ".fromtoml\n.fromyaml\n"


def test_external_no_url_is_lazy(env):
    """A type=file external without url lists fine but fails on cat."""
    external_toml(env, '[".nourl"]\n    type = "file"\n')
    listing = env.run(["managed", *env.flags()])
    assert listing.returncode == 0, listing.stderr
    assert listing.stdout.decode() == ".nourl\n"
    cat = env.run(["cat", *env.flags(), str(env.home / ".nourl")])
    # CATCHES: the URL is only needed when the external's data is actually
    # read -- managed never fetches, so only cat reports `no URL`.
    assert cat.returncode == 1
    assert cat.stdout == b""
    assert cat.stderr == b"chezmoi: .nourl: no URL\n"


@pytest.mark.parametrize(
    "body,message",
    [
        (
            '[".notype"]\n    type = "nosuchtype"\n    url = "file:///x"\n',
            b'chezmoi: @ROOT@/src/.chezmoiexternal.toml: toml: line 2 '
            b'(last key "\\".notype\\".type"): nosuchtype: invalid external type\n',
        ),
        (
            '[""]\n    type = "file"\n    url = "file:///x"\n',
            b"chezmoi: @ROOT@/src/.chezmoiexternal.toml: empty path\n",
        ),
        (
            '["/abs"]\n    type = "file"\n    url = "file:///x"\n',
            b"chezmoi: @ROOT@/src/.chezmoiexternal.toml: /abs: path is not relative\n",
        ),
        (
            '[".bad"]\n    type = "file"\n    url = "file:///x"\n    checksum = "sha256-0"\n',
            b'chezmoi: @ROOT@/src/.chezmoiexternal.toml: toml: line 4 '
            b'(last key "\\".bad\\".checksum"): type mismatch for '
            b"chezmoi.ExternalChecksum: expected table but found string\n",
        ),
        (
            '[".fo"]\n    type = "file"\n    url = "file:///x"\n'
            '    refreshPeriod = "notaduration"\n',
            b'chezmoi: @ROOT@/src/.chezmoiexternal.toml: toml: line 4 '
            b'(last key "\\".fo\\".refreshPeriod"): time: invalid duration '
            b'"notaduration"\n',
        ),
    ],
)
def test_external_config_errors(env, body, message):
    """Malformed external definitions abort with the toml key position."""
    external_toml(env, body)
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: toml decode errors report the file, the 1-based line and the
    # last key being parsed in Go's quoted form; semantic errors (empty or
    # absolute path) use their own message shapes.
    assert result.stdout == b""
    assert env.norm(result.stderr) == message


def test_external_chezmoi_file_in_externals_dir_rejected(env):
    """A .chezmoi* file inside .chezmoiexternals/ is refused."""
    env.mkdir(".chezmoiexternals")
    env.write(".chezmoiexternals/.chezmoifoo.toml", '[".x"]\n    type = "file"\n')
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: only non-.chezmoi files may define externals in that
    # directory; the offending file's full path is named in the error.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: @ROOT@/src/.chezmoiexternals/.chezmoifoo.toml: "
        b"not allowed in .chezmoiexternals directory\n"
    )


def test_external_hidden_file_in_externals_dir_skipped(env):
    """A hidden non-.chezmoi file in .chezmoiexternals/ is silently ignored."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    env.mkdir(".chezmoiexternals")
    env.write(".chezmoiexternals/.hidden.toml", "not toml at all\n")
    env.write(
        ".chezmoiexternals/valid.toml",
        f'[".plug/file"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n',
    )
    result = env.run(["managed", *env.flags()])
    # CATCHES: hidden files are skipped by the externals-dir walk before
    # parsing, so even invalid TOML in .hidden.toml causes no error, while
    # the visible valid.toml sibling still defines a working external.
    assert result.returncode == 0, result.stderr
    assert result.stdout.decode() == ".plug\n.plug\n.plug/file\n"
    cat = env.run(["cat", *env.flags(), str(env.home / ".plug/file")])
    assert cat.returncode == 0, cat.stderr
    assert cat.stdout == PLUG


def test_external_conflicting_definitions(env):
    """The same target defined twice is an inconsistent state."""
    env.root.joinpath("a.txt").write_bytes(PLUG)
    env.root.joinpath("b.txt").write_bytes(b"other\n")
    external_toml(
        env,
        f'[".dirext"]\n    type = "file"\n    url = "file://{env.root}/a.txt"\n',
    )
    env.mkdir(".chezmoiexternals")
    env.write(
        ".chezmoiexternals/one.toml",
        f'[".dirext"]\n    type = "file"\n    url = "file://{env.root}/b.txt"\n',
    )
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: both definitions are listed in the error with their URLs and
    # the defining files, proving both were parsed before the conflict was
    # detected at target-assembly time.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: .dirext: inconsistent state "
        b"(file://@ROOT@/a.txt defined in @ROOT@/src/.chezmoiexternal.toml, "
        b"file://@ROOT@/b.txt defined in @ROOT@/src/.chezmoiexternals/one.toml)\n"
    )


def test_source_path_of_external_targets(env):
    """source-path maps external targets to invented source names."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".plug/file"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'[".config/nested/tool"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n',
    )
    result = env.run(
        [
            "source-path",
            *env.flags(),
            str(env.home / ".plug"),
            str(env.home / ".plug/file"),
            str(env.home / ".config/nested/tool"),
        ]
    )
    assert result.returncode == 0, result.stderr
    # CATCHES: implicit parent directories of externals have no source
    # entry of their own, so .plug maps to the source directory itself,
    # while the external files map to invented names
    # (dot_config/nested/create_empty_, dot_plug/create_empty_) -- and the
    # results come back sorted by TARGET path, not argument order.
    assert env.norm(result.stdout) == (
        b"@ROOT@/src/dot_config/nested/create_empty_\n"
        b"@ROOT@/src\n"
        b"@ROOT@/src/dot_plug/create_empty_\n"
    )
    back = env.run(
        [
            "target-path",
            *env.flags(),
            str(env.src / "dot_plug" / "create_empty_"),
        ]
    )
    # CATCHES: the invented source name does not exist on disk, so feeding
    # it back to target-path fails with a raw stat error -- the
    # source-path mapping for externals does not round-trip.
    assert back.returncode == 1
    assert env.norm(back.stderr) == (
        b"chezmoi: stat @ROOT@/src/dot_plug/create_empty_: "
        b"no such file or directory\n"
    )


def test_managed_source_relative_nested_external(env):
    """Nested externals contribute implicit dir entries at every level."""
    env.root.joinpath("plug.txt").write_bytes(PLUG)
    external_toml(
        env,
        f'[".plug/file"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n'
        f'[".config/nested/tool"]\n    type = "file"\n    url = "file://{env.root}/plug.txt"\n',
    )
    result = env.run(["managed", *env.flags(), "-p", "source-relative"])
    assert result.returncode == 0, result.stderr
    # CATCHES: every parent level of an external target (.config,
    # .config/nested, .plug) contributes an implicit dir entry with an
    # EMPTY source name (the three blank lines), in addition to the
    # external's own synthetic dir names (dot_config/nested, dot_plug) and
    # file names (dot_config/nested/create_empty_, dot_plug/create_empty_).
    assert result.stdout == (
        b"\n\n\ndot_config/nested\ndot_config/nested/create_empty_\n"
        b"dot_plug\ndot_plug/create_empty_\n"
    )
