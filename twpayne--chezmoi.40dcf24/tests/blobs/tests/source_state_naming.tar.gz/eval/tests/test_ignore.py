""".chezmoiignore / .chezmoiremove pattern sets and the ignored command."""

from __future__ import annotations

import pytest


def test_ignore_patterns_filter_managed(env):
    """Ignore patterns match target paths; comments and blanks are skipped."""
    env.mkdir("dot_config")
    env.write("dot_a", "a\n")
    env.write("dot_keep", "k\n")
    env.write("dot_x.tmp", "t\n")
    env.write("dot_config/c", "c\n")
    env.write(".chezmoiignore", "# comment\n\n.keep\n*.tmp\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: patterns are matched against TARGET names (.keep matches
    # dot_keep's target), comment lines and blank lines are ignored, and
    # *.tmp matches .x.tmp -- the dot_ prefix never leaks into matching.
    assert result.stdout.decode() == ".a\n.config\n.config/c\n"


def test_ignore_pattern_negation(env):
    """A `!` pattern re-includes a previously ignored target."""
    env.write("dot_a", "a\n")
    env.write("dot_x.tmp", "t\n")
    env.write(".chezmoiignore", "*.tmp\n!.x.tmp\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: negation is order-sensitive -- !.x.tmp after *.tmp restores
    # .x.tmp to managed; the pattern must name the TARGET (.x.tmp), naming
    # the source (dot_x.tmp) matches nothing.
    assert result.stdout.decode() == ".a\n.x.tmp\n"


def test_ignore_star_does_not_cross_slash(env):
    """* matches within one path component only."""
    env.mkdir("dot_config")
    env.write("dot_a", "a\n")
    env.write("dot_x.tmp", "t\n")
    env.write("dot_config/c", "c\n")
    env.write("dot_config/b.tmp", "b\n")
    env.write(".chezmoiignore", "*.tmp\n!.x.tmp\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: *.tmp removes top-level .x.tmp's sibling only via negation,
    # while .config/b.tmp stays managed because * does not cross "/";
    # ignoring nested names needs an explicit pattern per level.
    assert result.stdout.decode() == ".a\n.config\n.config/b.tmp\n.config/c\n.x.tmp\n"


def test_ignore_whole_directory(env):
    """A directory pattern ignores the directory and everything under it."""
    env.mkdir("dot_config")
    env.write("dot_a", "a\n")
    env.write("dot_x.tmp", "t\n")
    env.write("dot_config/c", "c\n")
    for pattern in (".config\n", ".config/**\n"):
        env.write(".chezmoiignore", pattern)
        result = env.run(["managed", *env.flags()])
        assert result.returncode == 0, (pattern, result.stderr)
        # CATCHES: both ".config" and ".config/**" make the whole directory
        # disappear from managed -- the dir entry itself and its children;
        # .x.tmp at top level is untouched by either pattern.
        assert result.stdout.decode() == ".a\n.x.tmp\n", pattern


def test_ignored_lists_ignored_source_entries(env):
    """The ignored command lists targets of ignored SOURCE entries only."""
    env.mkdir("dot_config")
    env.write("dot_a", "a\n")
    env.write("dot_keep", "k\n")
    env.write("dot_x.tmp", "t\n")
    env.write("dot_config/c", "c\n")
    env.write(".chezmoiignore", "# ignore\n.keep\n*.tmp\n!dot_x.tmp\n")
    result = env.run(["ignored", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: ignored prints the TARGET paths of source entries matched by
    # the ignore set (.keep from dot_keep, .x.tmp from dot_x.tmp); touching
    # unmanaged files in the destination never changes this listing, and
    # !dot_x.tmp matches nothing because patterns see target names.
    assert result.stdout.decode() == ".keep\n.x.tmp\n"


def test_ignored_ignores_destination_files(env):
    """ignored reports ignored SOURCE entries, never dest-only files."""
    env.write("dot_a", "a\n")
    env.write("dot_keep", "k\n")
    env.write(".chezmoiignore", ".keep\n*.tmp\n")
    first = env.run(["ignored", *env.flags()])
    env.write_home(".config/keep.tmp", "x\n")
    env.write_home("zz.tmp", "x\n")
    second = env.run(["ignored", *env.flags()])
    # CATCHES: the ignored set is populated while reading the SOURCE state:
    # dot_keep's target .keep is listed both times, while the dest-only
    # .config/keep.tmp and zz.tmp -- which MATCH ignore patterns -- are
    # never listed, before or after they are created.
    assert first.returncode == second.returncode == 0
    assert first.stdout == second.stdout == b".keep\n"
    assert first.stderr == second.stderr == b""


def test_ignored_tree_and_nul(env):
    """ignored supports -t tree and -0 NUL output like managed."""
    env.write("dot_a", "a\n")
    env.write("dot_keep", "k\n")
    env.write("dot_x.tmp", "t\n")
    env.write(".chezmoiignore", ".keep\n*.tmp\n")
    tree = env.run(["ignored", *env.flags(), "-t"])
    nul = env.run(["ignored", *env.flags(), "-0"])
    assert tree.returncode == nul.returncode == 0
    # CATCHES: flat ignored entries print one per line in tree mode (no
    # nesting without directories) and are NUL-terminated in -0 mode.
    assert tree.stdout == b".keep\n.x.tmp\n"
    assert nul.stdout == b".keep\x00.x.tmp\x00"


def test_ignore_template_is_executed(env):
    """.chezmoiignore.tmpl is executed as a template before matching."""
    env.write("dot_a", "a\n")
    env.write("dot_b", "b\n")
    env.write(".chezmoiignore.tmpl", "{{ if true }}.b{{ end }}\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the .tmpl variant runs through the template engine first
    # ({{ if true }} .b {{ end }} yields the pattern .b) and only then
    # feeds the resulting lines to the pattern set.
    assert result.stdout.decode() == ".a\n"


def test_ignore_invalid_pattern_error(env):
    """An unparsable pattern aborts with the file, line and reason."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiignore", "[\n")
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: the error names the ignore file, the 1-based line number and
    # the regexp compile error -- pattern problems fail the whole command.
    assert result.stdout == b""
    assert env.norm(result.stderr) == (
        b"chezmoi: @ROOT@/src/.chezmoiignore:1: [: invalid pattern\n"
    )


@pytest.mark.parametrize(
    "pattern,message",
    [
        ("../b\n", b"chezmoi: @ROOT@/src/.chezmoiignore:1: ../b: invalid path\n"),
        ("/a\n", b"chezmoi: @ROOT@/src/.chezmoiignore:1: /a: invalid path\n"),
    ],
)
def test_ignore_invalid_path_errors(env, pattern, message):
    """Patterns escaping the target directory are rejected."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiignore", pattern)
    result = env.run(["managed", *env.flags()])
    assert result.returncode == 1
    # CATCHES: both ..-relative and absolute patterns are rejected as
    # invalid paths (not invalid patterns) with the pattern text included.
    assert result.stdout == b""
    assert env.norm(result.stderr) == message


def test_remove_file_deletes_on_apply(env):
    """.chezmoiremove entries are removed from the dest dir on apply."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiremove", ".old1\n")
    env.write_home(".old1", "")
    env.write_home(".old2", "")
    env.write_home("keep", "")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: only .old1 (named in .chezmoiremove) is deleted; .old2 and
    # keep survive even though they are unmanaged, and .a is created.
    assert sorted(p.name for p in env.home.iterdir()) == [".a", ".old2", "keep"]


def test_remove_file_excluded_from_unmanaged(env):
    """Files scheduled by .chezmoiremove do not show up as unmanaged."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiremove", ".old1\n")
    env.write_home(".old1", "x\n")
    env.write_home("other", "y\n")
    result = env.run(["unmanaged", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: .old1 counts as managed-for-removal so unmanaged skips it,
    # while the unrelated unmanaged file `other` is still listed.
    assert result.stdout.decode() == "other\n"


def test_managed_remove_type_lists_existing_pattern_targets(env):
    """-i remove lists .chezmoiremove patterns that match existing dest files."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiremove", ".old1\n")
    env.write_home(".old1", "x\n")
    listed = env.run(["managed", *env.flags(), "-i", "remove"])
    assert listed.returncode == 0, listed.stderr
    # CATCHES: each .chezmoiremove pattern that matches an EXISTING dest
    # file becomes a remove-type entry, so -i remove reports .old1 before
    # any apply has run.
    assert listed.stdout == b".old1\n"
    (env.home / ".old1").unlink()
    gone = env.run(["managed", *env.flags(), "-i", "remove"])
    # CATCHES: once the dest file no longer exists the pattern contributes
    # nothing -- remove entries are materialized from the destination
    # state, not from the pattern list alone.
    assert gone.returncode == 0, gone.stderr
    assert gone.stdout == b""


def test_remove_template_is_executed(env):
    """.chezmoiremove.tmpl is executed as a template before matching."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiremove.tmpl", "{{ if true }}.old1{{ end }}\n")
    env.write_home(".old1", "x\n")
    env.write_home(".old2", "x\n")
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: the .tmpl variant renders first and the rendered line
    # (.old1) drives removal; .old2 is untouched because the template
    # emitted only one pattern.
    assert sorted(p.name for p in env.home.iterdir()) == [".a", ".old2"]


def test_remove_file_negation_excludes_matches(env):
    """A `!` pattern in .chezmoiremove cancels an earlier matching pattern."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiremove", "*.old\n!keep.old\n")
    for name in ("a.old", "keep.old", "other"):
        env.write_home(name, "x\n")
    listed = env.run(["managed", *env.flags(), "-i", "remove"])
    assert listed.returncode == 0, listed.stderr
    # CATCHES: the remove entry set is the glob of the include patterns
    # minus the exclude patterns: a.old matches *.old and stays a remove
    # entry, keep.old is cancelled by !keep.old, and other never matched
    # any pattern at all.
    assert listed.stdout == b"a.old\n"
    unmanaged = env.run(["unmanaged", *env.flags()])
    assert unmanaged.returncode == 0, unmanaged.stderr
    # CATCHES: keep.old is not a remove entry, so it counts as unmanaged
    # exactly like other; only a.old disappeared from the unmanaged list.
    assert unmanaged.stdout == b"keep.old\nother\n"
    result = env.run(["apply", *env.flags()])
    assert result.returncode == 0, result.stderr
    # CATCHES: apply deletes only a.old; the negated keep.old and the
    # never-matched other survive next to the freshly created .a.
    assert sorted(p.name for p in env.home.iterdir()) == [".a", "keep.old", "other"]


def test_remove_entries_have_empty_source_names(env):
    """Remove entries report the source directory itself as their source."""
    env.write("dot_a", "a\n")
    env.write(".chezmoiremove", ".old1\n")
    env.write_home(".old1", "x\n")
    env.mkdir("exact_dot_config")
    env.write_home(".config/stray", "s\n")
    plain = env.run(["managed", *env.flags()])
    assert plain.returncode == 0, plain.stderr
    assert plain.stdout == b".a\n.config\n.config/stray\n.old1\n"
    relative = env.run(
        ["managed", *env.flags(), "-p", "source-relative", "-i", "remove"]
    )
    assert relative.returncode == 0, relative.stderr
    # CATCHES: both remove entries (.old1 from .chezmoiremove and
    # .config/stray from the exact_ directory) print an EMPTY source
    # relative name -- a remove entry has no source file of its own, even
    # though the state internally records where each removal came from.
    assert relative.stdout == b"\n\n"
    absolute = env.run(
        ["managed", *env.flags(), "-p", "source-absolute", "-i", "remove"]
    )
    assert absolute.returncode == 0, absolute.stderr
    # CATCHES: the empty source-relative name joined onto the source dir
    # makes both remove entries print the source directory itself, once
    # per remove entry.
    assert env.norm(absolute.stdout) == b"@ROOT@/src\n@ROOT@/src\n"
