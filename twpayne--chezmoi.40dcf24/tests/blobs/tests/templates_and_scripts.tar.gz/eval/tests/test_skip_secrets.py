"""Black-box tests for --skip-secrets (the "skip template" sentinel).

`--skip-secrets` makes every secrets template function abort the whole
template instead of running.  The functions are exercised through `secret`
and `secretJSON`, which need no external tools or network: without the flag
they run the configured secret command (empty by default, so they fail with
an exec error), with the flag they raise the internal "skip template"
sentinel before touching the command.  During apply the sentinel is
recovered per entry: the affected file or script is silently skipped and
nothing is recorded in the persistent state; during execute-template it
surfaces as a template execution error.
"""


def test_secret_function_without_configured_command_fails(sb):
    """secret without --skip-secrets tries to run the empty secret command."""
    # CATCHES: with no [secret] command configured the exec of the empty
    # command fails, and the error names the passed arguments ('' foo: exec:
    # no command) rather than skipping the template.
    res = sb.run(["execute-template", 'A{{ secret "foo" }}B'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:4: executing "arg1" at <secret "foo">: '
        b"error calling secret: '' foo: exec: no command\n"
    )


def test_skip_secrets_secret_function_reports_skip_template(sb):
    """--skip-secrets turns the secret call into a skip template error."""
    # CATCHES: the sentinel surfaces as the literal error message "skip
    # template" (exit code 1), and text around the call is discarded because
    # the template aborts.
    res = sb.run(["--skip-secrets", "execute-template", 'A{{ secret "foo" }}B'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:4: executing "arg1" at <secret "foo">: '
        b"error calling secret: skip template\n"
    )


def test_skip_secrets_secret_json_reports_skip_template(sb):
    """secretJSON is skipped the same way as secret."""
    # CATCHES: every secrets function checks --skip-secrets first, so
    # secretJSON fails with the same sentinel and its own function name.
    res = sb.run(
        ["--skip-secrets", "execute-template", 'A{{ secretJSON "foo" }}B']
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:4: executing "arg1" at <secretJSON "foo">: '
        b"error calling secretJSON: skip template\n"
    )


def test_skip_secrets_stdin_template_error_names_stdin(sb):
    """A skipped secrets function on stdin names the template stdin."""
    # CATCHES: the skip sentinel propagates out of a stdin template too and
    # the diagnostic prefix names "stdin" rather than "arg1".
    res = sb.run(
        ["--skip-secrets", "execute-template"], input=b'{{ secret "x" }}'
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: stdin:1:3: executing "stdin" at <secret "x">: '
        b"error calling secret: skip template\n"
    )


def test_apply_secret_template_error_names_source_template(sb):
    """Applying a secret template without the flag fails with the exec error."""
    # CATCHES: the apply error prefixes the target name, then the full
    # template error naming the source .tmpl file and its own line:col.
    sb.write_source("secretfile.txt.tmpl", contents="token={{ secret \"api\" }}\n")
    res = sb.apply()
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: secretfile.txt: template: secretfile.txt.tmpl:1:9: "
        b'executing "secretfile.txt.tmpl" at <secret "api">: '
        b"error calling secret: '' api: exec: no command\n"
    )


def test_skip_secrets_apply_skips_secret_files_but_applies_the_rest(sb):
    """apply --skip-secrets silently skips the secret template's file."""
    # CATCHES: the sentinel is recovered per entry during apply: the command
    # exits 0 with no output, the secret file is not created at all, and the
    # neighbouring plain file is still applied normally.
    sb.write_source("secretfile.txt.tmpl", contents="token={{ secret \"api\" }}\n")
    sb.write_source("normal.txt", contents="plain-ok")
    res = sb.run(["apply", "--skip-secrets"])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert not (sb.home / "secretfile.txt").exists()
    assert (sb.home / "normal.txt").read_bytes() == b"plain-ok"


def test_skip_secrets_skips_before_running_the_secret_command(sb):
    """--skip-secrets skips the template without invoking the command."""
    # CATCHES: the skip happens before the secret command runs: with the flag
    # the file is skipped even though the configured command would succeed,
    # and without the flag the command's output lands in the applied file
    # (trailing whitespace trimmed).
    sb.write_config('[secret]\ncommand = "echo"\n')
    sb.write_source("secretfile.txt.tmpl", contents="token={{ secret \"api\" }}\n")
    skipped = sb.run(["apply", "--skip-secrets"])
    assert skipped.returncode == 0
    assert skipped.stderr == b""
    assert not (sb.home / "secretfile.txt").exists()
    applied = sb.apply()
    assert applied.returncode == 0
    assert applied.stderr == b""
    assert (sb.home / "secretfile.txt").read_bytes() == b"token=api\n"


def test_skip_secrets_skips_templated_scripts_without_recording_state(sb):
    """A .tmpl script using secrets is skipped and not recorded as run."""
    # CATCHES: the skip fires while rendering the script, so the script is
    # neither executed nor recorded in the persistent state - the next apply
    # without the flag runs it (substituting the secret command's output)
    # and only then records the run.
    sb.write_config('[secret]\ncommand = "echo"\n')
    sb.write_source(
        "run_once_secret.sh.tmpl",
        contents='#!/bin/sh\necho "TOKEN={{ secret "api" }}"\n',
    )
    skipped = sb.run(["apply", "--skip-secrets"])
    assert skipped.returncode == 0
    assert skipped.stdout == b""
    assert skipped.stderr == b""
    first = sb.apply()
    assert first.returncode == 0
    assert first.stderr == b""
    assert first.stdout == b"TOKEN=api\n"
    second = sb.apply()
    assert second.returncode == 0
    assert second.stdout == b""
