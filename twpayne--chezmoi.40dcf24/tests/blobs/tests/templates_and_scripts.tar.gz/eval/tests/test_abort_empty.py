"""Black-box tests for abortEmpty in .tmpl files during apply.

`abortEmpty` stops template execution and makes the whole result the empty
string.  When a .tmpl source file renders through it, the target state
becomes "empty file", which chezmoi's default empty-file semantics handle
like any empty target: without the empty_ attribute the file is not created,
with it a zero-byte file is created.  (The execute-template side of the
sentinel is covered in test_template_functions.py.)
"""


def test_abort_empty_tmpl_without_empty_attribute_creates_no_file(sb):
    """A .tmpl file aborted by abortEmpty is not created during apply."""
    # CATCHES: the sentinel is recovered into empty contents (not an error),
    # and by default an empty target means the file is removed/not created -
    # the apply still succeeds and applies the neighbouring plain file.
    sb.write_source("plain.txt", contents="plain-content")
    sb.write_source("aborted.txt.tmpl", contents="BEFORE{{ abortEmpty }}AFTER")
    res = sb.apply()
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert not (sb.home / "aborted.txt").exists()
    assert (sb.home / "plain.txt").read_bytes() == b"plain-content"


def test_abort_empty_tmpl_with_empty_attribute_creates_empty_file(sb):
    """The empty_ attribute turns the aborted template into a 0-byte file."""
    # CATCHES: with empty_ the empty render result is kept, so apply creates
    # the target as an existing, zero-byte file instead of skipping it -
    # everything rendered before and after the abortEmpty call is gone.
    sb.write_source("empty_keep.txt.tmpl", contents="X{{ abortEmpty }}Y")
    res = sb.apply()
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    keep = sb.home / "keep.txt"
    assert keep.exists()
    assert keep.read_bytes() == b""


def test_abort_empty_in_include_template_aborts_all_execution(sb):
    """abortEmpty inside an included template aborts the whole template."""
    # CATCHES: the sentinel raised in a sub-template reached through
    # includeTemplate discards the entire result - the text before and after
    # the includeTemplate call disappears too - while a normal sub-template
    # renders in place.
    sb.write_source(".chezmoitemplates", "aborts", contents="in-{{ abortEmpty }}-sub")
    sb.write_source(".chezmoitemplates", "oksub", contents="OK-SUB")
    aborted = sb.run(["execute-template", 'A{{ includeTemplate "aborts" }}B'])
    assert aborted.returncode == 0
    assert aborted.stderr == b""
    assert aborted.stdout == b""
    control = sb.run(["execute-template", 'A{{ includeTemplate "oksub" }}B'])
    assert control.returncode == 0
    assert control.stderr == b""
    assert control.stdout == b"AOK-SUBB"
