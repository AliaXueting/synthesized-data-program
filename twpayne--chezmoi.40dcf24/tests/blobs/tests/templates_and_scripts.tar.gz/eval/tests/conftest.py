"""Shared helpers for driving the chezmoi binary as a black box.

Every test builds a throwaway workspace (source directory, destination/home
directory, config directory, cache directory, persistent state file and temp
directory) inside ``tmp_path`` and runs the program under test with a fully
pinned environment.  The binary is always resolved through
``PROGRAMGYM_EXECUTABLE`` so the suite can be pointed at a re-implementation.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest


def chezmoi_program() -> Path:
    """Return the absolute path of the program under test."""
    return Path(os.environ["PROGRAMGYM_EXECUTABLE"]).resolve()


# The pinned environment for every child process: a fixed PATH holding only
# the interpreters the script tests need (python3, perl, sh), a C locale, no
# color and no terminal so output is byte-for-byte reproducible.  HOME, TMPDIR
# and the XDG variables are filled in per-run by Sandbox.env().
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "TERM": "dumb",
    "NO_COLOR": "1",
    "SHELL": "/bin/sh",
}


def run_chezmoi(args, *, input=b"", cwd=None, env=None, timeout=30):
    """Run the program under test and return the completed process.

    ``args`` is the argument list without the program name, ``input`` is fed
    to standard input (bytes), ``cwd`` is the child's working directory and
    ``env`` overrides entries of the pinned child environment.  Standard
    output and standard error are captured as bytes because several template
    encodings (UTF-16, BOMs, CRLF) are only observable at the byte level.
    """
    child_env = dict(CHILD_ENV)
    if env:
        child_env.update(env)
    # Coverage instrumentation hook: the pipeline builds the reference binary
    # with -cover, so GOCOVERDIR must survive the pinned environment for the
    # module's source coverage to be measured.  The value is made absolute
    # because children run inside per-test temporary directories.
    cov_env = {
        "GOCOVERDIR": os.path.abspath(value)
        for value in [os.environ.get("GOCOVERDIR")]
        if value
    }
    child_env.update(cov_env)
    return subprocess.run(
        [str(chezmoi_program()), *[str(arg) for arg in args]],
        input=input,
        capture_output=True,
        cwd=None if cwd is None else str(cwd),
        env=child_env,
        timeout=timeout,
    )


class Sandbox:
    """A disposable chezmoi workspace rooted at ``root``.

    The layout keeps every directory the program can write to inside the
    pytest temporary directory so that no test ever touches the real home
    directory, the real XDG directories, or any path outside ``tmp_path``.
    The config file lives at ``<root>/config/chezmoi/chezmoi.toml`` which is
    exactly where chezmoi looks when XDG_CONFIG_HOME is ``<root>/config``.
    """

    def __init__(self, root):
        self.root = Path(root)
        self.source = self.root / "source"
        self.home = self.root / "home"
        self.config_dir = self.root / "config" / "chezmoi"
        self.cache = self.root / "cache"
        self.state_dir = self.root / "state"
        self.tmp = self.root / "tmp"
        for directory in (
            self.source,
            self.home,
            self.config_dir,
            self.cache,
            self.state_dir,
            self.tmp,
        ):
            directory.mkdir(parents=True, exist_ok=True)
        self.config_file = self.config_dir / "chezmoi.toml"
        self.state_file = self.state_dir / "chezmoistate.boltdb"

    # ------------------------------------------------------------------
    # workspace helpers
    # ------------------------------------------------------------------
    def path(self, *parts):
        """Return a path inside the workspace root."""
        return self.root.joinpath(*parts)

    def write(self, *parts, contents="", mode=None):
        """Write a file into the workspace, creating parent directories."""
        path = self.root.joinpath(*parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(contents, str):
            contents = contents.encode("utf-8")
        path.write_bytes(contents)
        if mode is not None:
            path.chmod(mode)
        return path

    def write_source(self, *parts, contents="", mode=None):
        """Write a file into the source state, creating parent directories."""
        return self.write("source", *parts, contents=contents, mode=mode)

    def write_config(self, contents):
        """Write the chezmoi configuration file (discovered via XDG)."""
        return self.write("config", "chezmoi", "chezmoi.toml", contents=contents)

    def env(self, **extra):
        """Return the child environment for this workspace."""
        child_env = {
            "HOME": str(self.home),
            "TMPDIR": str(self.tmp),
            "XDG_CONFIG_HOME": str(self.root / "config"),
            "XDG_CONFIG_DIRS": str(self.root / "xdg-config-dirs"),
            "XDG_CACHE_HOME": str(self.root / "xdg-cache"),
            "XDG_DATA_HOME": str(self.root / "xdg-data"),
        }
        child_env.update(extra)
        return child_env

    # ------------------------------------------------------------------
    # process helpers
    # ------------------------------------------------------------------
    def _flags(self):
        return [
            "--source",
            self.source,
            "--destination",
            self.home,
            "--cache",
            self.cache,
            "--persistent-state",
            self.state_file,
        ]

    def run(self, args, *, input=b"", cwd=None, env=None):
        """Run chezmoi against this workspace with every directory pinned."""
        return run_chezmoi(
            [*self._flags(), *[str(arg) for arg in args]],
            input=input,
            cwd=self.root if cwd is None else cwd,
            env=self.env(**(env or {})),
        )

    def apply(self, **kwargs):
        """Run `chezmoi apply` against this workspace."""
        return self.run(["apply"], **kwargs)


@pytest.fixture
def sb(tmp_path):
    """Return a fresh sandboxed chezmoi workspace."""
    return Sandbox(tmp_path)


def decode(raw):
    """Decode captured bytes as UTF-8 text."""
    return raw.decode("utf-8")
