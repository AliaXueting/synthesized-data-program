"""Black-box tests for hooks.<name>.pre/post command and script execution.

A hook entry may specify a command (run as command + args) or a script
(dispatched through the interpreters map by the script's extension); the two
are mutually exclusive.  Hook scripts run with the home directory as their
working directory.
"""

import pytest

SH = "#!/bin/sh\n"


def test_hook_command_runs(sb):
    """A hooks.apply.pre command hook runs before the apply."""
    # CATCHES: the command and its args are executed with stdout wired to
    # chezmoi's stdout, before any apply work.
    sb.write_config('[hooks.apply.pre]\ncommand = "echo"\nargs = ["CMD HOOK"]\n')
    sb.write_source("plain.txt", contents="content\n")
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"CMD HOOK\n"
    assert (sb.home / "plain.txt").read_bytes() == b"content\n"


def test_hook_python_script_runs_via_interpreters(sb):
    """A hook script with a recognized extension runs through the interpreter."""
    # CATCHES: script hooks are dispatched by extension like apply scripts,
    # so a .py hook runs under python3 with the home directory as cwd (the
    # bare filename resolves because exec sets cmd.Dir to home).
    sb.write_config('[hooks.apply.pre]\nscript = "hookpre.py"\n')
    sb.write("home", "hookpre.py", contents='print("PY HOOK")\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"PY HOOK\n"


def test_hook_shell_script_must_be_executable(sb):
    """A .sh hook script runs directly and therefore needs the exec bit."""
    # CATCHES: .sh maps to the pass-through interpreter, so the script file
    # itself is exec'd; without the executable bit the hook fails with a
    # permission denied error wrapped in the hook name.
    sb.write_config('[hooks.apply.pre]\nscript = "./prehook.sh"\n')
    sb.write("home", "prehook.sh", contents=SH + 'echo "EXEC HOOK"\n')
    res = sb.apply()
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: apply: pre: ./prehook.sh: fork/exec ./prehook.sh: permission denied\n"
    )


def test_hook_shell_script_executable_runs(sb):
    """An executable .sh hook script runs with home as its directory."""
    # CATCHES: with the exec bit set the pass-through hook script runs
    # directly, and its relative path resolves against the home directory.
    sb.write_config('[hooks.apply.pre]\nscript = "./prehook.sh"\n')
    sb.write("home", "prehook.sh", contents=SH + 'echo "EXEC HOOK"\n', mode=0o755)
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"EXEC HOOK\n"


def test_hook_absolute_python_script(sb):
    """A hook script given by absolute path works for post hooks too."""
    # CATCHES: post hooks run after the apply and absolute script paths are
    # passed to the interpreter unchanged.
    sb.write_config(
        "[hooks.apply.post]\nscript = \"{}\"\n".format(sb.source / "posthook.py")
    )
    sb.write_source("posthook.py", contents='print("ABS PY HOOK")\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"ABS PY HOOK\n"


def test_hook_command_and_script_are_mutually_exclusive(sb):
    """Specifying both command and script for a hook is a config error."""
    # CATCHES: the hook runner rejects the combination before running
    # anything, with the error wrapped in the hook name and phase.
    sb.write_config('[hooks.apply.pre]\ncommand = "echo"\nscript = "x.sh"\n')
    res = sb.apply()
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: apply: pre: cannot specify both command and script\n"


def test_failing_pre_hook_aborts_apply(sb):
    """A pre hook that exits non-zero aborts the apply with its status."""
    # CATCHES: the hook failure is reported with the hook name, phase, the
    # command and its exit status, and the apply does not proceed.
    sb.write_config('[hooks.apply.pre]\ncommand = "false"\n')
    sb.write_source("plain.txt", contents="content\n")
    res = sb.apply()
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: apply: pre: false: exit status 1\n"
    assert not (sb.home / "plain.txt").exists()


def test_hook_script_missing_is_reported(sb):
    """A hook script that cannot be found reports the exec lookup failure."""
    # CATCHES: a bare .sh filename without a slash is looked up in PATH
    # (relative to no directory), which fails with "executable file not
    # found in $PATH" rather than a file open error.
    sb.write_config('[hooks.apply.pre]\nscript = "prehook.sh"\n')
    sb.write("home", "prehook.sh", contents=SH + 'echo "never"\n', mode=0o755)
    res = sb.apply()
    assert res.returncode == 1
    assert res.stderr == (
        b'chezmoi: apply: pre: prehook.sh: exec: "prehook.sh": '
        b"executable file not found in $PATH\n"
    )
