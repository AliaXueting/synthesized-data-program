"""Black-box tests for the chezmoi:template: directives.

Directives are lines matching `chezmoi:template:` at the start of a template
(anywhere in the file); they configure the template engine (missing-key,
line-ending, encoding, delimiters, format indentation) and the directive
lines themselves are removed from the template before parsing.
"""

import pytest


def test_missing_key_zero_prints_no_value(sb):
    """missing-key=zero renders missing map keys as <no value>."""
    # CATCHES: the missingkey=zero option makes an absent key print the
    # literal text <no value> instead of aborting execution.
    res = sb.run(
        ["execute-template", "# chezmoi:template:missing-key=zero\n[{{ .nope }}]"]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"[<no value>]"


def test_missing_key_error_aborts(sb):
    """missing-key=error aborts the template with the missing key name."""
    # CATCHES: with missingkey=error the execution fails, naming the map and
    # the key that has no entry.
    res = sb.run(
        ["execute-template", "# chezmoi:template:missing-key=error\n[{{ .nope }}]"]
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b'executing "arg1" at <.nope>: map has no entry for key "nope"\n'
    )


def test_missing_key_invalid_behaves_like_zero(sb):
    """missing-key=invalid also renders <no value>."""
    # CATCHES: the Go text/template "invalid" option prints the placeholder
    # like zero rather than failing.
    res = sb.run(
        ["execute-template", "# chezmoi:template:missing-key=invalid\n[{{ .nope }}]"]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"[<no value>]"


def test_default_missing_key_is_error(sb):
    """Without a directive a missing key aborts the template."""
    # CATCHES: chezmoi's default is the strict missingkey=error behavior, so
    # the directive is what relaxes it.
    res = sb.run(["execute-template", "[{{ .nope }}]"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b'executing "arg1" at <.nope>: map has no entry for key "nope"\n'
    )


def test_directive_line_is_removed_from_output(sb):
    """The line containing a directive is stripped from the template."""
    # CATCHES: directives never leak into the rendered output, even when the
    # directive appears between other text lines.
    res = sb.run(
        ["execute-template", "X\n# chezmoi:template:line-ending=crlf\nY\n"]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"X\r\nY\r\n"


def test_directive_in_the_middle_of_a_template(sb):
    """A directive may appear anywhere in the template, not only at the top."""
    # CATCHES: directives are scanned across the whole file, so a
    # missing-key directive after the first line still configures the engine.
    res = sb.run(
        ["execute-template", "A\n# chezmoi:template:missing-key=zero\nB{{ .missing }}"]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"A\nB<no value>"


def test_line_endings_directive_aliases(sb):
    """line-ending and line-endings are both accepted."""
    # CATCHES: both spellings of the directive key work identically and
    # rewrite every newline in the rendered output.
    for key in ("line-ending", "line-endings"):
        res = sb.run(["execute-template", "# chezmoi:template:{}=crlf\na\nb\n".format(key)])
        assert res.returncode == 0
        assert res.stdout == b"a\r\nb\r\n"


def test_line_endings_lf_converts_crlf(sb):
    """line-endings=lf rewrites existing CRLF sequences to LF."""
    # CATCHES: the rewrite replaces existing CRLF pairs, proving the
    # replacement operates on the rendered text, not the raw input.
    res = sb.run(
        ["execute-template", "# chezmoi:template:line-endings=lf\na\r\n"],
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"a\n"


def test_line_ending_native_is_lf_on_linux(sb):
    """line-ending=native resolves to LF on Linux."""
    # CATCHES: the native alias maps to the platform line ending, which is
    # \n on Linux.
    res = sb.run(["execute-template", "# chezmoi:template:line-ending=native\na\nb\n"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"a\nb\n"


def test_line_ending_custom_string(sb):
    """A quoted custom line ending replaces every newline."""
    # CATCHES: any other value (here "%%% ") is used verbatim as the line
    # terminator, including embedded spaces.
    res = sb.run(
        ['execute-template', '# chezmoi:template:line-ending="%%% "\na\nb\n']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"a%%% b%%% "


def test_unknown_encoding_directive(sb):
    """An unrecognized encoding directive fails before rendering."""
    # CATCHES: only utf-8/utf-8-bom/utf-16-be/le(/-bom) are valid; anything
    # else is a parse-time error with the value echoed back.
    res = sb.run(["execute-template", "# chezmoi:template:encoding=latin-1\nx"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: latin-1: unknown encoding\n"


@pytest.mark.parametrize(
    "directive, expected",
    [
        ("encoding=utf-8", b"hi\n"),
        ("encoding=utf-8-bom", b"\xef\xbb\xbfhi\n"),
        ("encoding=utf-16-le", b"h\x00i\x00\n\x00"),
        ("encoding=utf-16-be", b"\x00h\x00i\x00\n"),
        ("encoding=utf-16-le-bom", b"\xff\xfeh\x00i\x00\n\x00"),
        ("encoding=utf-16-be-bom", b"\xfe\xff\x00h\x00i\x00\n"),
    ],
)
def test_encoding_directives_produce_exact_bytes(sb, directive, expected):
    """Each encoding directive re-encodes the rendered output."""
    # CATCHES: the encoder applies after line-ending rewriting and emits
    # exact byte sequences, with BOMs only for the -bom variants.
    res = sb.run(["execute-template", "# chezmoi:template:{}\nhi\n".format(directive)])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_format_indent_width_changes_all_serializers(sb):
    """format-indent-width=4 re-indents toToml output."""
    # CATCHES: the format-indent-width directive replaces the toJson/toToml/
    # toYaml functions with versions indenting by the given number of spaces.
    res = sb.run(
        [
            "execute-template",
            "# chezmoi:template:format-indent-width=4\n{{ toToml (dict \"a\" (dict \"b\" 1)) }}",
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"[a]\n    b = 1\n"


def test_format_indent_width_json_and_yaml(sb):
    """format-indent-width also re-indents toJson and toYaml."""
    # CATCHES: each serializer honors the directive: toJson gains an indent
    # (and keeps its trailing newline), toYaml indents nested mappings.
    json_res = sb.run(
        [
            "execute-template",
            "# chezmoi:template:format-indent-width=3\n{{ toJson (dict \"a\" (dict \"b\" 1)) }}",
        ]
    )
    assert json_res.stdout == b'{\n   "a": {\n      "b": 1\n   }\n}\n'
    yaml_res = sb.run(
        [
            "execute-template",
            "# chezmoi:template:format-indent-width=2\n{{ toYaml (dict \"a\" (dict \"b\" (dict \"c\" 1))) }}",
        ]
    )
    assert yaml_res.returncode == 0
    assert yaml_res.stdout == b"a:\n  b:\n    c: 1\n"


def test_format_indent_tab_counts_as_eight_columns(sb):
    """format-indent with a tab indents YAML by the tab's display width."""
    # CATCHES: a literal tab is expanded to width 8 (1 + 7) for the YAML
    # encoder, not counted as a single character.
    res = sb.run(
        [
            "execute-template",
            '# chezmoi:template:format-indent="\\t"\n{{ toYaml (dict "a" (dict "b" 1)) }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"a:\n        b: 1\n"


def test_format_indent_width_negative_is_invalid(sb):
    """A negative format-indent-width is rejected."""
    # CATCHES: widths are validated to be non-negative, with the value echoed
    # in the error.
    res = sb.run(
        ["execute-template", "# chezmoi:template:format-indent-width=-1\nx"]
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: -1: invalid format-indent-width\n"


def test_format_indent_width_non_numeric_is_rejected(sb):
    """A non-numeric format-indent-width fails with the raw Atoi error."""
    # CATCHES: the width is parsed with strconv.Atoi before the range check,
    # so a non-numeric value surfaces as the bare parse error, not as an
    # "invalid format-indent-width" message.
    res = sb.run(
        ["execute-template", "# chezmoi:template:format-indent-width=abc\nx"]
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: strconv.Atoi: parsing "abc": invalid syntax\n'


def test_format_indent_width_zero_uses_default_serializers(sb):
    """format-indent-width=0 leaves the serializers in compact default mode."""
    # CATCHES: a width of zero produces an empty indent string, which is
    # treated as "no custom indent", so toJson stays compact on one line
    # exactly like a template without the directive.
    res = sb.run(
        [
            "execute-template",
            "# chezmoi:template:format-indent-width=0\n{{ toJson (dict \"a\" (dict \"b\" 1)) }}",
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{"a":{"b":1}}'


def test_format_indent_accepts_arbitrary_strings(sb):
    """format-indent is used verbatim, not validated to whitespace."""
    # CATCHES: the indent string is not restricted to spaces and tabs - the
    # literal value "xy" is passed straight through to the JSON encoder and
    # appears as the indentation of every nested level.
    res = sb.run(
        [
            "execute-template",
            "# chezmoi:template:format-indent=xy\n{{ toJson (dict \"a\" (dict \"b\" 1)) }}",
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{\nxy"a": {\nxyxy"b": 1\nxy}\n}\n'


def test_delimiter_directives_change_action_delimiters(sb):
    """left-delimiter/right-delimiter directives reprogram the delimiters."""
    # CATCHES: the directive (like the flag) changes what marks an action;
    # here @@ ... @@ renders the os while {{ }} stays literal.
    res = sb.run(
        [
            "execute-template",
            "# chezmoi:template:left-delimiter=@@ right-delimiter=@@\n@@ .chezmoi.os @@ {{ literal }}",
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"linux {{ literal }}"


def test_delimiter_directives_accept_quoted_values(sb):
    """Delimiter values may be quoted and may differ from each other."""
    # CATCHES: quoted directive values are unquoted before use and the left
    # and right delimiters can be different strings.
    res = sb.run(
        [
            "execute-template",
            '# chezmoi:template:left-delimiter="(("\n# chezmoi:template:right-delimiter="))"\n(( .chezmoi.os ))',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"linux"
