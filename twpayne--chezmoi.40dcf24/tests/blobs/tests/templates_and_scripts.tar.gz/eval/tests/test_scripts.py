"""Black-box tests for script execution during apply.

Scripts are run_/run_once_/run_onchange_ source files (optionally with a
before_/after_ ordering modifier and/or a .tmpl suffix).  They are written to
a private temporary file and executed through the configured interpreter with
CHEZMOI_SOURCE_FILE set and a working directory that exists.
"""

import re

import pytest

SH = "#!/bin/sh\n"


def test_run_script_executes_on_every_apply(sb):
    """A run_ script runs on every apply with its stdout on chezmoi's stdout."""
    # CATCHES: run_ scripts have no state - both applies execute the script
    # and its output is passed through unchanged.
    sb.write_source("run_print.sh", contents=SH + 'echo "run_print ran"\n')
    first = sb.apply()
    assert first.returncode == 0
    assert first.stderr == b""
    assert first.stdout == b"run_print ran\n"
    second = sb.apply()
    assert second.returncode == 0
    assert second.stdout == b"run_print ran\n"


def test_run_once_script_runs_only_once(sb):
    """A run_once_ script is skipped on the second apply."""
    # CATCHES: the persistent state records that the script already ran, so
    # the second apply produces no output and exit code 0.
    sb.write_source("run_once_print.sh", contents=SH + 'echo "once ran"\n')
    first = sb.apply()
    assert first.returncode == 0
    assert first.stdout == b"once ran\n"
    second = sb.apply()
    assert second.returncode == 0
    assert second.stderr == b""
    assert second.stdout == b""


def test_run_once_script_reruns_when_contents_change(sb):
    """A run_once_ script whose contents change runs again."""
    # CATCHES: the once-state is keyed by a hash of the script contents, so
    # editing the script invalidates the recorded run.
    sb.write_source("run_once_keyed.sh", contents=SH + 'echo "A"\n')
    assert sb.apply().stdout == b"A\n"
    sb.write_source("run_once_keyed.sh", contents=SH + 'echo "B"\n')
    again = sb.apply()
    assert again.returncode == 0
    assert again.stdout == b"B\n"


def test_run_onchange_script_reruns_on_change_only(sb):
    """A run_onchange_ script runs when its contents change."""
    # CATCHES: like run_once_, the recorded hash gates execution: unchanged
    # contents are skipped, changed contents re-run the script.
    sb.write_source("run_onchange_print.sh", contents=SH + 'echo "onchange ran v1"\n')
    assert sb.apply().stdout == b"onchange ran v1\n"
    assert sb.apply().stdout == b""
    sb.write_source("run_onchange_print.sh", contents=SH + 'echo "onchange ran v2"\n')
    changed = sb.apply()
    assert changed.returncode == 0
    assert changed.stdout == b"onchange ran v2\n"


def test_scripts_run_alphabetically_within_a_class(sb):
    """Same-class scripts run in target name order."""
    # CATCHES: the apply order for scripts of the same class follows the
    # (sorted) target names, here a before b.
    sb.write_source("run_b.sh", contents=SH + 'echo "B"\n')
    sb.write_source("run_a.sh", contents=SH + 'echo "A"\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stdout == b"A\nB\n"


def test_before_and_after_script_ordering(sb):
    """run_before_ scripts run first and run_after_ scripts run last."""
    # CATCHES: the before_/after_ modifiers reorder execution within the
    # directory regardless of alphabetical order of the script names.
    sb.write_source("run_after_last.sh", contents=SH + 'echo "AFTER"\n')
    sb.write_source("run_before_first.sh", contents=SH + 'echo "BEFORE"\n')
    sb.write_source("run_middle.sh", contents=SH + 'echo "MIDDLE"\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"BEFORE\nMIDDLE\nAFTER\n"


def test_run_once_before_combination(sb):
    """run_once_ combines with the before_ modifier."""
    # CATCHES: the once_ and before_ attributes combine into a single
    # script that runs once and orders before the plain scripts.
    sb.write_source("run_once_before_combo.sh", contents=SH + 'echo "ONCE_BEFORE"\n')
    sb.write_source("run_zzz.sh", contents=SH + 'echo "PLAIN"\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stdout == b"ONCE_BEFORE\nPLAIN\n"
    again = sb.apply()
    assert again.stdout == b"PLAIN\n"


def test_python_script_runs_with_python3(sb):
    """A .py script runs through python3 without needing a shebang."""
    # CATCHES: the .py extension is dispatched to the python3 interpreter
    # with the temporary script file as its argument.
    sb.write_source("run_once_print.py", contents='print("py script ran")\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"py script ran\n"


def test_perl_script_runs_with_perl(sb):
    """A .pl script runs through perl without needing a shebang."""
    # CATCHES: the .pl extension is dispatched to the perl interpreter.
    sb.write_source("run_once_print.pl", contents='print "pl script ran\\n";\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"pl script ran\n"


def test_py_and_pl_scripts_interleave_alphabetically(sb):
    """Scripts with different extensions still order by target name."""
    # CATCHES: interpreter dispatch happens per script but the ordering is
    # by target name across all extensions.
    sb.write_source("run_b.py", contents='print("PY-B")\n')
    sb.write_source("run_a.pl", contents='print "PL-A\\n";\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stdout == b"PL-A\nPY-B\n"


def test_custom_interpreter_from_config(sb):
    """The interpreters config maps new extensions to interpreters."""
    # CATCHES: a config [interpreters.<ext>] entry with a command (and
    # optional args) overrides the built-in map for that extension.
    sb.write_config(
        '[interpreters.myx]\ncommand = "python3"\nargs = ["-u"]\n'
    )
    sb.write_source("run_once_argtest.myx", contents='print("custom interp")\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"custom interp\n"


def test_missing_interpreter_error(sb):
    """A configured interpreter that does not exist fails the apply."""
    # CATCHES: the interpreter is looked up in PATH and the error names both
    # the script (without its run_ prefix) and the missing interpreter.
    sb.write_config('[interpreters.myx]\ncommand = "definitely-not-an-interpreter"\n')
    sb.write_source("run_once_broken.myx", contents='print("never runs")\n')
    res = sb.apply()
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: broken.myx: exec: \"definitely-not-an-interpreter\": "
        b"executable file not found in $PATH\n"
    )


def test_script_environment_and_working_directory(sb):
    """Scripts get CHEZMOI_SOURCE_FILE and run in the destination directory."""
    # CATCHES: CHEZMOI_SOURCE_FILE is the source-relative script name and
    # the working directory is the corresponding destination directory.
    sb.write_source(
        "run_env.sh",
        contents=SH + 'echo "SF=$CHEZMOI_SOURCE_FILE"\npwd\n',
    )
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == "SF=run_env.sh\n{}\n".format(sb.home).encode()


def test_subdirectory_script_working_directory(sb):
    """A script in a source subdirectory runs in the mirrored destination dir."""
    # CATCHES: the working directory is the script's destination directory
    # (created by apply if necessary), not the destination root.
    sb.write_source("sub", "run_once_inner.sh", contents=SH + "pwd\n")
    res = sb.apply()
    assert res.returncode == 0
    assert res.stdout == "{}\n".format(sb.home / "sub").encode()


def test_failing_script_fails_apply_with_status(sb):
    """A script exiting non-zero fails apply and its stderr is preserved."""
    # CATCHES: the script's own stderr is printed first, then the chezmoi
    # error naming the script (without run_ prefixes) and its exit status.
    sb.write_source("run_fail.sh", contents=SH + 'echo "about to fail" >&2\nexit 3\n')
    res = sb.apply()
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"about to fail\nchezmoi: fail.sh: exit status 3\n"


def test_script_stdout_and_stderr_are_separate_streams(sb):
    """Script stdout goes to chezmoi stdout and stderr to chezmoi stderr."""
    # CATCHES: the script's two output streams are wired straight through to
    # the corresponding chezmoi streams without merging.
    sb.write_source(
        "run_err.sh", contents=SH + 'echo "to-stdout"\necho "to-stderr" >&2\n'
    )
    res = sb.apply()
    assert res.returncode == 0
    assert res.stdout == b"to-stdout\n"
    assert res.stderr == b"to-stderr\n"


def test_script_receives_stdin(sb):
    """A script's stdin is connected to chezmoi's stdin."""
    # CATCHES: scripts inherit the parent's standard input, so piped data
    # reaches them.
    sb.write_source("run_once_cat.sh", contents=SH + "cat\n")
    res = sb.apply(input=b"piped-stdin-data\n")
    assert res.returncode == 0
    assert res.stdout == b"piped-stdin-data\n"


def test_shebangless_sh_script_fails(sb):
    """A .sh script without a shebang fails with exec format error."""
    # CATCHES: .sh scripts are executed directly (no interpreter), so a
    # missing shebang fails; the error reveals the private temp file path
    # (<scriptTempDir>/<random>.run_noshebang.sh).
    sb.write_source("run_noshebang.sh", contents='echo "no shebang"\n')
    res = sb.apply()
    assert res.returncode == 1
    assert res.stdout == b""
    assert re.fullmatch(
        r"chezmoi: noshebang\.sh: fork/exec [^\n]*[/\\][0-9]+\.noshebang\.sh: "
        r"exec format error\n".encode(),
        res.stderr,
    )
    # The temporary script lives in the configured temp dir (TMPDIR here).
    assert str(sb.tmp).encode() in res.stderr


def test_script_env_config(sb):
    """The scriptEnv config adds environment variables for scripts."""
    # CATCHES: scriptEnv entries are exported to every script's environment
    # alongside CHEZMOI_SOURCE_FILE.
    sb.write_config('[scriptEnv]\nFROM_SCRIPT_ENV = "hello"\n')
    sb.write_source("run_once_env.sh", contents=SH + 'echo "ENV=$FROM_SCRIPT_ENV"\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"ENV=hello\n"


def test_script_temp_dir_config(sb):
    """The scriptTempDir config relocates the private script temp files."""
    # CATCHES: temporary script files are created inside the configured
    # scriptTempDir (0700), visible through the script's $0.
    script_tmp = sb.root / "scripttmp"
    script_tmp.mkdir()
    sb.write_config("scriptTempDir = \"{}\"\n".format(script_tmp))
    sb.write_source("run_once_self.sh", contents=SH + 'echo "SELF=$(dirname "$0")"\n')
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == "SELF={}\n".format(script_tmp).encode()
    # The temp script is cleaned up after the run.
    assert list(script_tmp.iterdir()) == []


def test_templated_script_is_rendered_before_running(sb):
    """A .tmpl script is rendered as a template, then executed."""
    # CATCHES: the .tmpl suffix is stripped for state tracking and the
    # rendered contents (with template data substituted) are what runs.
    sb.write_source(
        "run_once_templated.sh.tmpl",
        contents='#!/bin/sh\necho "os={{ .chezmoi.os }}"\n',
    )
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"os=linux\n"


def test_onchange_templated_script_tracks_rendered_contents(sb):
    """run_onchange_ on a .tmpl script hashes the rendered output."""
    # CATCHES: the recorded hash is of the rendered script, so changing the
    # template's output re-runs it even if the change is only in the
    # template logic.
    sb.write_source(
        "run_onchange_t.sh.tmpl", contents='#!/bin/sh\necho "static"\n'
    )
    assert sb.apply().stdout == b"static\n"
    assert sb.apply().stdout == b""
    sb.write_source(
        "run_onchange_t.sh.tmpl", contents='#!/bin/sh\necho "static2"\n'
    )
    changed = sb.apply()
    assert changed.returncode == 0
    assert changed.stdout == b"static2\n"


def test_script_can_use_include_template(sb):
    """A templated script may include .chezmoitemplates entries."""
    # CATCHES: includeTemplate is available while rendering scripts, so
    # shared template snippets can be embedded into script bodies.
    sb.write_source(".chezmoitemplates", "greet", contents="Greetings {{ . }}")
    sb.write_source(
        "run_once_greet.sh.tmpl",
        contents='#!/bin/sh\ncat <<EOF\n{{ includeTemplate "greet" "World" }}\nEOF\n',
    )
    res = sb.apply()
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"Greetings World\n"


def test_dry_run_does_not_execute_scripts(sb):
    """apply --dry-run does not run scripts."""
    # CATCHES: dry-run executes no scripts and records no script state: the
    # marker file is absent afterwards and the subsequent real apply still
    # runs the run_once_ script (a second apply then stays silent).
    sb.write_source(
        "run_once_marker.sh",
        contents=SH + 'echo "DRY RAN"\ntouch marker-file\n',
    )
    dry = sb.run(["apply", "--dry-run"])
    assert dry.returncode == 0
    assert dry.stdout == b""
    assert dry.stderr == b""
    assert not (sb.home / "marker-file").exists()
    real = sb.apply()
    assert real.returncode == 0
    assert real.stderr == b""
    assert real.stdout == b"DRY RAN\n"
    assert (sb.home / "marker-file").exists()
    second = sb.apply()
    assert second.returncode == 0
    assert second.stdout == b""


def test_exclude_scripts_skips_scripts(sb):
    """apply --exclude scripts applies everything but scripts."""
    # CATCHES: the scripts entry type filter suppresses script execution
    # while regular files are still applied, and the skipped script is not
    # recorded as run, so a later plain apply executes it.
    sb.write_source("excluded.txt", contents="file-content")
    sb.write_source("run_excluded.sh", contents=SH + 'echo "SHOULD-NOT-RUN"\n')
    res = sb.run(["apply", "--exclude", "scripts"])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (sb.home / "excluded.txt").read_bytes() == b"file-content"
    followup = sb.apply()
    assert followup.returncode == 0
    assert followup.stderr == b""
    assert followup.stdout == b"SHOULD-NOT-RUN\n"


def test_verbose_apply_shows_script_diff_before_running(sb):
    """--verbose prints a git-style diff of the script before running it."""
    # CATCHES: verbose apply prints the script contents as a new-file diff
    # (with the content-addressed blob hash) followed by the script output.
    sb.write_source("run_verbose.sh", contents=SH + 'echo "VOUT"\n')
    res = sb.run(["--verbose", "apply"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"diff --git a/verbose.sh b/verbose.sh\n"
        b"new file mode 100755\n"
        b"index 0000000000000000000000000000000000000000.."
        b"a8a325bc4770abdee236132d890b9781fa96d2fa\n"
        b"--- /dev/null\n"
        b"+++ b/verbose.sh\n"
        b"@@ -0,0 +1,2 @@\n"
        b"+#!/bin/sh\n"
        b'+echo "VOUT"\n'
        b"VOUT\n"
    )


def test_debug_apply_logs_script_run_with_interpreter(sb):
    """--debug logs each script run with its interpreter configuration."""
    # CATCHES: the debug log line for a script names the script and how it
    # was interpreted - the built-in .py mapping logs interpreter.command
    # with no args attribute, while a configured interpreter with args logs
    # interpreter.args as a Go slice.
    sb.write_source("run_once_dbg.py", contents='print("debug-py")\n')
    res = sb.run(["--debug", "apply"])
    assert res.returncode == 0
    assert res.stderr != b""
    assert res.stdout == b"debug-py\n"
    assert b"level=INFO msg=RunScript component=system scriptName=dbg.py" in res.stderr
    assert b"interpreter.command=python3 condition=once" in res.stderr
    sb.write_config('[interpreters.myx]\ncommand = "python3"\nargs = ["-u"]\n')
    sb.write_source("run_once_dbg2.myx", contents='print("CUSTOMX")\n')
    custom = sb.run(["--debug", "apply"])
    assert custom.returncode == 0
    assert custom.stdout == b"CUSTOMX\n"
    assert b"scriptName=dbg2.myx" in custom.stderr
    assert b"interpreter.command=python3 interpreter.args=[-u]" in custom.stderr
