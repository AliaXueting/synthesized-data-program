"""Black-box tests for .chezmoitemplates, include/includeTemplate and the
rendering of .tmpl source files during apply.
"""

import pytest


def write_template(sb, name, contents):
    """Write a file into .chezmoitemplates and return its path."""
    return sb.write_source(".chezmoitemplates", name, contents=contents)


def test_chezmoi_templates_are_registered_as_named_templates(sb):
    """Files in .chezmoitemplates become named templates for {{ template }}."""
    # CATCHES: execute-template pre-parses every .chezmoitemplates file and
    # makes it invocable with the standard `template` action under its
    # source-relative name (subdirectories included).
    write_template(sb, "greeting", "Hello {{ .name }}!")
    res = sb.run(["execute-template", '{{ template "greeting" (dict "name" "World") }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"Hello World!"


def test_named_templates_in_subdirectories(sb):
    """Template names keep their subdirectory path below .chezmoitemplates."""
    # CATCHES: a template at .chezmoitemplates/sub/nested is invoked as
    # "sub/nested", not just "nested".
    write_template(sb, "sub/nested", "nested-content")
    via_template = sb.run(["execute-template", '{{ template "sub/nested" }}'])
    assert via_template.returncode == 0
    assert via_template.stdout == b"nested-content"
    via_include = sb.run(["execute-template", '{{ includeTemplate "sub/nested" }}'])
    assert via_include.returncode == 0
    assert via_include.stdout == b"nested-content"


def test_include_template_renders_with_data(sb):
    """includeTemplate parses the file as a template with the given data."""
    # CATCHES: includeTemplate searches .chezmoitemplates first and executes
    # the file as a template with the argument as the data.
    write_template(sb, "greeting", "Hello {{ .name }}!")
    res = sb.run(["execute-template", '{{ includeTemplate "greeting" (dict "name" "Etaoin") }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"Hello Etaoin!"


def test_include_template_without_data(sb):
    """includeTemplate without data executes the template against nil data."""
    # CATCHES: the template still runs and fails on the field access with
    # the "nil data; no entry for key" message naming the included template.
    write_template(sb, "greeting", "Hello {{ .name }}!")
    res = sb.run(["execute-template", '{{ includeTemplate "greeting" }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b'error calling includeTemplate: greeting:1:9: executing "greeting" '
        b'at <.name>: nil data; no entry for key "name"\n'
    )


def test_include_template_argument_arity(sb):
    """includeTemplate accepts at most one data argument."""
    # CATCHES: two data arguments are rejected with the expected arity
    # message.
    write_template(sb, "greeting", "x")
    res = sb.run(["execute-template", '{{ includeTemplate "greeting" 1 2 }}'])
    assert res.returncode == 1
    assert res.stderr.endswith(
        b"error calling includeTemplate: expected 0 or 1 arguments, got 2\n"
    )


def test_include_reads_raw_source_dir_files(sb):
    """include returns raw file contents from the source directory."""
    # CATCHES: include does NOT search .chezmoitemplates and does NOT render
    # templates - it returns the literal bytes from the source directory.
    write_template(sb, "raw", "literal {{ 1 }} braces")
    sb.write_source("other.txt", contents="srcdir file")
    raw = sb.run(["execute-template", '{{ include ".chezmoitemplates/raw" }}'])
    assert raw.returncode == 0
    assert raw.stdout == b"literal {{ 1 }} braces"
    other = sb.run(["execute-template", '{{ include "other.txt" }}'])
    assert other.returncode == 0
    assert other.stdout == b"srcdir file"


def test_include_missing_file_error(sb):
    """include of a missing file reports the searched source directory path."""
    # CATCHES: the error names the exact absolute path that was tried
    # (<source dir>/<name>) with the standard open error.
    res = sb.run(["execute-template", '{{ include "definitely-missing" }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        "chezmoi: template: arg1:1:3: executing \"arg1\" at <include "
        "\"definitely-missing\">: error calling include: open {}/definitely-missing: "
        "no such file or directory\n".format(sb.source).encode()
    )


def test_include_absolute_path(sb):
    """include with an absolute path reads that file directly."""
    # CATCHES: absolute paths bypass the source directory search.
    target = sb.write("absfile.txt", contents="absolute contents")
    res = sb.run(["execute-template", '{{ include "' + str(target) + '" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"absolute contents"


def test_include_template_processes_directives(sb):
    """includeTemplate honors chezmoi:template: directives in the included file."""
    # CATCHES: the included template is parsed by the chezmoi parser, so its
    # own directives (here line-ending=crlf) take effect.
    write_template(sb, "dir", "# chezmoi:template:line-ending=crlf\nx\n")
    res = sb.run(["execute-template", '{{ includeTemplate "dir" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"x\r\n"


def test_init_flag_hides_named_templates_but_not_include_template(sb):
    """--init skips loading .chezmoitemplates while includeTemplate still works."""
    # CATCHES: with --init the pre-parsed named templates are not registered
    # ({{ template }} fails) but includeTemplate reads the file directly.
    write_template(sb, "greeting", "Hello {{ .name }}!")
    named = sb.run(
        ["execute-template", "--init", '{{ template "greeting" (dict "name" "World") }}']
    )
    assert named.returncode == 1
    assert named.stderr.endswith(b'template "greeting" not defined\n')
    included = sb.run(
        [
            "execute-template",
            "--init",
            '{{ includeTemplate "greeting" (dict "name" "World") }}',
        ]
    )
    assert included.returncode == 0
    assert included.stdout == b"Hello World!"


def test_tmpl_source_file_is_rendered_on_apply(sb):
    """A .tmpl source file is rendered to the destination on apply."""
    # CATCHES: apply renders the template with the chezmoi data and writes
    # the result to the destination path without the .tmpl suffix.
    sb.write_source("hello.tmpl", contents="OS={{ .chezmoi.os }}\n")
    res = sb.apply()
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (sb.home / "hello").read_bytes() == b"OS=linux\n"


def test_tmpl_source_file_with_directives_on_apply(sb):
    """Directives in a .tmpl source file apply to the rendered target."""
    # CATCHES: the directive machinery is identical for source state
    # templates, so line-ending=crlf ends up in the destination file.
    sb.write_source("crlf.tmpl", contents="# chezmoi:template:line-ending=crlf\na\nb\n")
    res = sb.apply()
    assert res.returncode == 0
    assert (sb.home / "crlf").read_bytes() == b"a\r\nb\r\n"


def test_tmpl_apply_error_names_target_and_template(sb):
    """A failing .tmpl template reports both the target and the source name."""
    # CATCHES: the error is prefixed with the destination target name and
    # then the source template name with line/column information.
    sb.write_source("hello.tmpl", contents="name={{ .name }}\n")
    res = sb.apply()
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"chezmoi: hello: template: hello.tmpl:1:8: executing \"hello.tmpl\" "
        b'at <.name>: map has no entry for key "name"\n'
    )


def test_tmpl_source_file_in_subdirectory(sb):
    """A .tmpl file in a source subdirectory renders into that subdirectory."""
    # CATCHES: the directory structure is mirrored into the destination.
    sb.write_source("sub", "inner.tmpl", contents="static-content\n")
    res = sb.apply()
    assert res.returncode == 0
    assert (sb.home / "sub" / "inner").read_bytes() == b"static-content\n"


def test_tmpl_source_file_data_variables(sb):
    """.chezmoi.sourceFile and .chezmoi.targetFile expose the file names."""
    # CATCHES: sourceFile is the source-relative template name while
    # targetFile is the absolute destination path.
    sb.write_source("meta.tmpl", contents="src={{ .chezmoi.sourceFile }} tgt={{ .chezmoi.targetFile }}\n")
    res = sb.apply()
    assert res.returncode == 0
    assert (sb.home / "meta").read_bytes() == (
        "src=meta.tmpl tgt={}\n".format(sb.home / "meta").encode()
    )


def test_broken_named_template_fails_execute_template(sb):
    """A parse error in .chezmoitemplates fails before any rendering."""
    # CATCHES: named templates are parsed while reading the source state,
    # so a broken one aborts execute-template with the template's own name
    # in the diagnostic - not arg1/stdin, which never get rendered.
    sb.write_source(".chezmoitemplates", "broken", contents="{{ notAFunction }}")
    res = sb.run(["execute-template", "never-rendered"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: broken:1: function "notAFunction" not defined\n'
    )
