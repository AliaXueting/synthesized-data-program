"""Black-box tests for the `chezmoi execute-template` command line.

These cover where templates are read from (arguments, stdin, files), where
the rendered output goes (stdout, --output), the delimiter flags, the
--with-stdin data injection and the exit codes and diagnostics for broken
templates.
"""

import re

import pytest


def test_template_arguments_are_rendered_and_concatenated(sb):
    """Multiple template arguments are rendered in order and concatenated."""
    # CATCHES: no separator is inserted between the rendered arguments and
    # each argument is an independent template named arg1, arg2, ...
    res = sb.run(["execute-template", 'a{{ "one" }}', 'b{{ "two" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"aonebtwo"


def test_template_read_from_stdin_when_no_arguments(sb):
    """With no arguments the template itself is read from standard input."""
    # CATCHES: stdin is used verbatim as the template and its rendered output
    # goes to stdout with no extra newline appended.
    res = sb.run(["execute-template"], input=b"OS={{ .chezmoi.os }}\n")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"OS=linux\n"


def test_empty_stdin_renders_empty_output(sb):
    """An empty template on stdin succeeds and produces no output."""
    # CATCHES: empty input is a valid (empty) template, not an argument count
    # error; the identical invocation with content renders it, proving the
    # command really executed and only the empty input yields empty output.
    populated = sb.run(["execute-template"], input=b"marker={{ .chezmoi.os }}\n")
    assert populated.returncode == 0
    assert populated.stderr == b""
    assert populated.stdout == b"marker=linux\n"
    res = sb.run(["execute-template"], input=b"")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b""


def test_unknown_function_error_names_argument(sb):
    """An undefined template function fails with the argument's template name."""
    # CATCHES: the diagnostic identifies the template as "arg1" (the implicit
    # name given to the first argument) and names the missing function.
    res = sb.run(["execute-template", "{{ notAFunction }}"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1: function "notAFunction" not defined\n'
    )


def test_stdin_template_is_named_stdin(sb):
    """A template error on stdin reports the template name as "stdin"."""
    # CATCHES: the stdin template is named "stdin" rather than "arg1", which
    # shows up in the error prefix.
    res = sb.run(["execute-template"], input=b"{{ notAFunction }}\n")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: template: stdin:1: function "notAFunction" not defined\n'


def test_parse_error_in_argument(sb):
    """A parse error reports the offending position with chezmoi's prefix."""
    # CATCHES: parse errors are prefixed with "chezmoi: template: arg1:1:"
    # and go to stderr with exit code 1.
    res = sb.run(["execute-template", "{{"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: template: arg1:1: unclosed action\n"


def test_partial_output_is_discarded_when_execution_fails(sb):
    """Output rendered before a failing action is discarded, not printed."""
    # CATCHES: the template engine buffers output and only writes it on
    # success, so "XY" never reaches stdout when a later action fails.
    res = sb.run(["execute-template", 'X{{ "Y" }}{{ notAFunction }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: template: arg1:1: function "notAFunction" not defined\n'


def test_second_argument_failure_names_arg2(sb):
    """When the second argument fails the first argument's output is dropped."""
    # CATCHES: arguments are rendered into one buffer that is only written
    # after every argument succeeds; the error names the failing argument.
    res = sb.run(["execute-template", "ok{{ 1 }}", "{{ notAFunction }}"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: template: arg2:1: function "notAFunction" not defined\n'


def test_file_flag_renders_each_file_in_order(sb):
    """-f/--file treats the arguments as filenames rendered in order."""
    # CATCHES: with --file the arguments are file paths whose contents are
    # concatenated in argument order, exactly like literal arguments.
    sb.write_source("first.tmpl", contents="one\n")
    sb.write_source("second.tmpl", contents="two\n")
    res = sb.run(["execute-template", "--file", sb.source / "first.tmpl", sb.source / "second.tmpl"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"one\ntwo\n"


def test_file_flag_missing_file_error(sb):
    """-f with a non-existent file reports the open error."""
    # CATCHES: the diagnostic is the raw os.ReadFile error prefixed with
    # chezmoi's "chezmoi:" prefix and the path exactly as given.
    res = sb.run(["execute-template", "-f", "definitely-missing.tmpl"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: open definitely-missing.tmpl: no such file or directory\n"
    )


def test_file_flag_directory_error(sb):
    """-f with a directory reports a read error, not a template error."""
    # CATCHES: reading a directory fails before any template parsing with
    # the "is a directory" message.
    res = sb.run(["execute-template", "-f", sb.source])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == "chezmoi: read {}: is a directory\n".format(sb.source).encode()


def test_file_flag_source_file_data_is_relative_to_source(sb):
    """.chezmoi.sourceFile is relative to the source dir for -f files in it."""
    # CATCHES: a file inside the source directory is executed under its
    # source-relative name while a file outside keeps its absolute path.
    sb.write_source("sub", "deep.tmpl", contents="srcfile={{ .chezmoi.sourceFile }}\n")
    inside = sb.run(["execute-template", "-f", sb.source / "sub" / "deep.tmpl"])
    assert inside.returncode == 0
    assert inside.stderr == b""
    assert inside.stdout == b"srcfile=sub/deep.tmpl\n"
    outside_path = sb.write("outside.tmpl", contents="srcfile={{ .chezmoi.sourceFile }}\n")
    outside = sb.run(["execute-template", "-f", outside_path])
    assert outside.returncode == 0
    assert outside.stdout == "srcfile={}\n".format(outside_path).encode()


def test_output_flag_writes_rendered_result_to_file(sb):
    """-o/--output writes the result to a file instead of stdout."""
    # CATCHES: stdout stays completely empty and the file receives exactly
    # the rendered bytes.
    res = sb.run(["execute-template", "-o", "out.txt", "rendered-bytes"])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (sb.root / "out.txt").read_bytes() == b"rendered-bytes"


def test_output_flag_missing_parent_directory(sb):
    """-o into a missing directory fails with the absolute path."""
    # CATCHES: the output path is resolved to an absolute path before the
    # open, and the error names that absolute path.
    res = sb.run(["execute-template", "--output", "missing-dir/out.txt", "x"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        "chezmoi: open {}/missing-dir/out.txt: no such file or directory\n".format(
            sb.root
        ).encode()
    )


def test_output_file_not_written_when_template_fails(sb):
    """A failing template leaves the --output file uncreated."""
    # CATCHES: rendering happens before the output file is opened, so a
    # template error means no file is created at all.
    res = sb.run(["execute-template", "-o", "out.txt", "{{ notAFunction }}"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert not (sb.root / "out.txt").exists()


def test_delimiter_flags_change_action_syntax(sb):
    """--left-delimiter/--right-delimiter reprogram the action delimiters."""
    # CATCHES: with the delimiters changed the default {{ }} syntax becomes
    # literal text and the new delimiters delimit actions.
    res = sb.run(
        [
            "execute-template",
            "--left-delimiter",
            "((",
            "--right-delimiter",
            "))",
            "os=(( .chezmoi.os )) literal={{ .chezmoi.os }}",
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"os=linux literal={{ .chezmoi.os }}"


def test_empty_delimiter_flag_keeps_defaults(sb):
    """Passing an empty delimiter flag leaves the default delimiters."""
    # CATCHES: an empty --left-delimiter is ignored rather than producing an
    # empty (match-anywhere) delimiter.
    res = sb.run(["execute-template", "--left-delimiter", "", "{{ 1 }}"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"1"


def test_with_stdin_exposes_stdin_contents(sb):
    """--with-stdin injects the stdin bytes as .chezmoi.stdin."""
    # CATCHES: the raw stdin bytes (newlines included) become the
    # .chezmoi.stdin template variable when template arguments are given.
    res = sb.run(
        ["execute-template", "--with-stdin", "[{{ .chezmoi.stdin }}]"],
        input=b"line1\nline2\n",
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"[line1\nline2\n]"


def test_with_stdin_without_arguments_errors(sb):
    """--with-stdin does not apply when the template comes from stdin."""
    # CATCHES: .chezmoi.stdin is only populated when template arguments are
    # present; with stdin as the template the key is missing and the default
    # missingkey=error option aborts execution.
    res = sb.run(["execute-template", "--with-stdin"], input=b"[{{ .chezmoi.stdin }}]")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: stdin:1:12: executing "stdin" at '
        b'<.chezmoi.stdin>: map has no entry for key "stdin"\n'
    )


def test_stdinisatty_flag_is_accepted_and_reports_false(sb):
    """stdinIsATTY returns false for a pipe even with --stdinisatty."""
    # CATCHES: the --stdinisatty flag is accepted, but the stdinIsATTY
    # template function reports the real (non-TTY) stdin: false.
    res = sb.run(["execute-template", "--stdinisatty", "{{ stdinIsATTY }}"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"false"


def test_execute_template_help_lists_module_flags(sb):
    """`execute-template --help` documents the flags of the command."""
    # CATCHES: the help text names every template-related flag including the
    # -p shorthand for --promptString and the (default true) on --stdinisatty.
    res = sb.run(["execute-template", "--help"])
    assert res.returncode == 0
    assert res.stderr == b""
    for fragment in (
        "Execute templates. This is useful for testing templates or for calling",
        "chezmoi execute-template [template]... [flags]",
        "-f, --file                               Treat arguments as filenames",
        "-i, --init                               Simulate chezmoi init",
        "      --left-delimiter string              Set left template delimiter",
        "-p, --promptString stringToString        Simulate promptString",
        "      --stdinisatty                        Simulate stdinIsATTY (default true)",
        "      --with-stdin                         Set .chezmoi.stdin to the contents of the standard input",
    ):
        assert fragment in res.stdout.decode()


def test_init_flag_keeps_builtin_template_data(sb):
    """--init still exposes the built-in .chezmoi data variables."""
    # CATCHES: simulating init replaces the prompt functions but keeps the
    # standard chezmoi template data (os, arch, sourceFile).
    res = sb.run(["execute-template", "--init", "{{ .chezmoi.os }}/{{ .chezmoi.arch }}"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"linux/amd64"
