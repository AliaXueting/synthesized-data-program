"""Black-box tests for the --init prompt/exit/writeToStdout template functions.

`chezmoi execute-template --init` simulates `chezmoi init`: it registers the
promptBool/promptChoice/promptInt/promptMultichoice/promptString family (and
their *Once variants) backed by the --prompt* command line flags, plus the
exit and writeToStdout functions.  Without --init none of these functions
exist.
"""

import pytest


def test_prompt_functions_require_init(sb):
    """promptString is not defined unless --init is given."""
    # CATCHES: the prompt functions are only registered in init mode; without
    # it the template fails to parse with "function not defined".
    res = sb.run(["execute-template", '{{ promptString "name" }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: template: arg1:1: function "promptString" not defined\n'


def test_prompt_string_flag_value(sb):
    """--promptString supplies the answer for the matching prompt name."""
    # CATCHES: the flag key must equal the prompt string passed to the
    # function; the value is substituted verbatim.
    res = sb.run(
        ["execute-template", "--init", "--promptString", "name=alice", '{{ promptString "name" }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"alice"


def test_prompt_string_short_flag_and_default(sb):
    """-p is the shorthand and a missing key falls back to the default."""
    # CATCHES: with one extra argument the function returns that default when
    # no --promptString flag matches the prompt name.
    res = sb.run(
        ["execute-template", "--init", "-p", "other=bob", '{{ promptString "name" "fallback" }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"fallback"


def test_prompt_string_returns_prompt_text_without_flag(sb):
    """promptString with no flag value and no default echoes the prompt."""
    # CATCHES: the zero-argument form returns the prompt text itself, not an
    # error and not an empty string.
    res = sb.run(["execute-template", "--init", '{{ promptString "your name" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"your name"


def test_prompt_string_once_uses_data_map_first(sb):
    """promptStringOnce prefers an existing key in the data map."""
    # CATCHES: the *Once functions look the field up in the given map before
    # consulting the prompt flags; "email" in . yields the stored value.
    res = sb.run(
        [
            "execute-template",
            "--init",
            "--promptString",
            "Email?=flag@x",
            '{{ promptStringOnce . "email" "Email?" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"flag@x"


def test_prompt_string_once_falls_back_to_prompt(sb):
    """promptStringOnce with an unmatched flag returns the prompt text."""
    # CATCHES: when neither the data map nor the flag has the value, the
    # prompt string itself (not the flag default) is the fallback.
    res = sb.run(
        [
            "execute-template",
            "--init",
            "--promptString",
            "email=ignored@x",
            '{{ promptStringOnce . "email" "Email?" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"Email?"


def test_prompt_bool_flag_and_default(sb):
    """--promptBool parses a bool, and the default is used when unset."""
    # CATCHES: bool prompts fall back to the given default (true) when no
    # flag matches, and the flag form accepts true/false literals.
    flagged = sb.run(["execute-template", "--init", "--promptBool", "ok=true", '{{ promptBool "ok" }}'])
    assert flagged.returncode == 0
    assert flagged.stdout == b"true"
    fallback = sb.run(["execute-template", "--init", '{{ promptBool "ok" true }}'])
    assert fallback.returncode == 0
    assert fallback.stdout == b"true"


def test_prompt_bool_invalid_value_is_a_flag_error(sb):
    """--promptBool with a non-boolean value fails before rendering."""
    # CATCHES: values are validated with strconv.ParseBool up front, so the
    # error is a raw parse error (not a template error) and appears even
    # without --init.
    res = sb.run(["execute-template", "--promptBool", "ok=maybe", "template"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: strconv.ParseBool: parsing "maybe": invalid syntax\n'


def test_prompt_int_flag_and_default(sb):
    """--promptInt supplies integers and the default is used when unset."""
    # CATCHES: int prompts return the flag value, and with no matching flag
    # the single extra argument is the default.
    flagged = sb.run(["execute-template", "--init", "--promptInt", "n=42", '{{ promptInt "n" }}'])
    assert flagged.returncode == 0
    assert flagged.stdout == b"42"
    fallback = sb.run(["execute-template", "--init", '{{ promptInt "n" 7 }}'])
    assert fallback.returncode == 0
    assert fallback.stdout == b"7"


def test_prompt_int_invalid_flag_value(sb):
    """--promptInt with a non-integer value is a cobra flag error."""
    # CATCHES: the stringToInt flag parser rejects bad values with the
    # "invalid argument" wrapper naming the flag and the raw Atoi error.
    res = sb.run(["execute-template", "--init", "--promptInt", "n=abc", "x"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: invalid argument "n=abc" for "--promptInt" flag: '
        b"strconv.Atoi: parsing \"abc\": invalid syntax\n"
    )


def test_prompt_choice_valid_and_invalid(sb):
    """--promptChoice validates the answer against the offered choices."""
    # CATCHES: a choice not in the list is rejected at execution time with
    # the "invalid choice" error, while a valid one is returned.
    valid = sb.run(
        [
            "execute-template",
            "--init",
            "--promptChoice",
            "color=red",
            '{{ promptChoice "color" (list "red" "green") }}',
        ]
    )
    assert valid.returncode == 0
    assert valid.stdout == b"red"
    invalid = sb.run(
        [
            "execute-template",
            "--init",
            "--promptChoice",
            "color=purple",
            '{{ promptChoice "color" (list "red" "green") }}',
        ]
    )
    assert invalid.returncode == 1
    assert invalid.stdout == b""
    assert invalid.stderr.endswith(b'error calling promptChoice: purple: invalid choice\n')


def test_prompt_choice_without_flag_returns_prompt(sb):
    """promptChoice with no flag value echoes the prompt text."""
    # CATCHES: like promptString, the zero-default form returns the prompt
    # string when no --promptChoice flag matches.
    res = sb.run(
        ["execute-template", "--init", '{{ promptChoice "color" (list "red" "green") }}']
    )
    assert res.returncode == 0
    assert res.stdout == b"color"


def test_prompt_multichoice_splits_on_slashes(sb):
    """--promptMultichoice answers are split on '/' into a list."""
    # CATCHES: the flag value "hat/coat" becomes the two-element list
    # [hat coat], joinable and printable as a Go slice.
    res = sb.run(
        [
            "execute-template",
            "--init",
            "--promptMultichoice",
            "tops=hat/coat",
            '{{ promptMultichoice "tops" (list "hat" "coat" "shoes") | join "," }}',
        ]
    )
    assert res.returncode == 0
    assert res.stdout == b"hat,coat"


def test_prompt_multichoice_default_argument(sb):
    """promptMultichoice with a default list returns that list."""
    # CATCHES: the first extra argument is the list of default choices used
    # when no flag matches the prompt.
    res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptMultichoice "m" (list "a" "b") (list "b" "a") | join "," }}',
        ]
    )
    assert res.returncode == 0
    assert res.stdout == b"b,a"


def test_prompt_bool_too_many_arguments(sb):
    """promptBool rejects more than one default argument."""
    # CATCHES: the init prompt functions check their arity and report "want
    # 1 or 2 arguments, got 3" as an execution error.
    res = sb.run(["execute-template", "--init", '{{ promptBool "x" true false }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling promptBool: want 1 or 2 arguments, got 3\n"
    )


def test_prompt_string_once_requires_three_arguments(sb):
    """promptStringOnce needs the map, the path and the prompt."""
    # CATCHES: the *Once functions need at least three arguments; passing two
    # is rejected by the template engine's arity check.
    res = sb.run(["execute-template", "--init", '--promptString', "email=x", '{{ promptStringOnce . "email" }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert b"wrong number of args for promptStringOnce: want at least 3 got 2" in res.stderr


def test_exit_function_sets_process_exit_code(sb):
    """The init-only exit function terminates with the given status."""
    # CATCHES: `exit 3` aborts the process immediately with exit code 3 and
    # no output at all on either stream.
    res = sb.run(["execute-template", "--init", "{{ exit 3 }}"])
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b""


def test_exit_zero_discards_remaining_output(sb):
    """`exit 0` exits successfully without rendering the rest."""
    # CATCHES: exit aborts template execution even with status 0; the
    # buffered remainder ("ok") is discarded while a writeToStdout call made
    # before the exit was already written directly to stdout and survives.
    res = sb.run(
        ["execute-template", "--init", '{{ writeToStdout "A" }}{{ exit 0 }}ok']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"A"


def test_exit_function_argument_validation(sb):
    """exit requires exactly one integer argument."""
    # CATCHES: exit with no argument is an arity error and a string argument
    # is a type error, both reported as template errors.
    no_args = sb.run(["execute-template", "--init", "{{ exit }}"])
    assert no_args.returncode == 1
    assert no_args.stderr.endswith(b"wrong number of args for exit: want 1 got 0\n")
    wrong_type = sb.run(["execute-template", "--init", '{{ exit "x" }}'])
    assert wrong_type.returncode == 1
    assert wrong_type.stderr.endswith(b'expected integer; found "x"\n')


def test_write_to_stdout_writes_directly(sb):
    """writeToStdout emits text immediately, before the template result."""
    # CATCHES: writeToStdout bypasses the template buffer, so its output
    # precedes the rendered remainder even though it appears later in the
    # template body.
    res = sb.run(
        ["execute-template", "--init", '{{ writeToStdout "A" }}{{ writeToStdout "B" }}C']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"ABC"


@pytest.mark.parametrize(
    "flag, flag_args, template, expected",
    [
        ("--promptBool", ["ok=false"], '{{ promptBool "ok" true }}', b"false"),
        ("--promptInt", ["n=42"], '{{ promptInt "n" 7 }}', b"42"),
        ("-p", ["name=alice"], '{{ promptString "name" "default" }}', b"alice"),
    ],
)
def test_prompt_flag_value_overrides_default_argument(
    sb, flag, flag_args, template, expected
):
    """A matching prompt flag beats the default given as extra argument."""
    # CATCHES: with two arguments (prompt + default) the flag answer still
    # wins over the default for the string, bool and int prompt functions.
    res = sb.run(["execute-template", "--init", flag, *flag_args, template])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_prompt_bool_once_uses_bool_from_data_map(sb):
    """promptBoolOnce returns a stored bool, and falls back on other types."""
    # CATCHES: the data map is only consulted for actual bool values - a
    # string under the same key is ignored and the flag (or the zero value)
    # is used instead.
    stored = sb.run(
        ["execute-template", "--init", '{{ promptBoolOnce (dict "ok" true) "ok" "ok?" }}']
    )
    assert stored.returncode == 0
    assert stored.stderr == b""
    assert stored.stdout == b"true"
    non_bool = sb.run(
        [
            "execute-template",
            "--init",
            "--promptBool",
            "ok=false",
            '{{ promptBoolOnce (dict "ok" "yes") "ok" "ok?" }}',
        ]
    )
    assert non_bool.returncode == 0
    assert non_bool.stderr == b""
    assert non_bool.stdout == b"false"


def test_prompt_int_once_ignores_non_int64_map_values(sb):
    """promptIntOnce only recognizes int64 map values, not template ints."""
    # CATCHES: a literal 42 in the data map is a Go int (not int64), so it
    # is skipped: the prompt flag is consulted next (here yielding 9), and
    # without a flag the zero value 0 is returned.
    flagged = sb.run(
        [
            "execute-template",
            "--init",
            "--promptInt",
            "n=9",
            '{{ promptIntOnce (dict "n" 42) "n" "n" }}',
        ]
    )
    assert flagged.returncode == 0
    assert flagged.stderr == b""
    assert flagged.stdout == b"9"
    unflagged = sb.run(
        ["execute-template", "--init", '{{ promptIntOnce (dict "n" 42) "n" "n" }}']
    )
    assert unflagged.returncode == 0
    assert unflagged.stderr == b""
    assert unflagged.stdout == b"0"


def test_prompt_string_once_and_choice_once_use_map_values(sb):
    """promptStringOnce/promptChoiceOnce return the stored map string."""
    # CATCHES: a string in the data map at the given path short-circuits
    # both functions, so neither the prompt flags nor the choice list is
    # consulted (blue is not among the offered choices).
    string_res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptStringOnce (dict "email" "a@b") "email" "Email?" }}',
        ]
    )
    assert string_res.returncode == 0
    assert string_res.stderr == b""
    assert string_res.stdout == b"a@b"
    choice_res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptChoiceOnce (dict "color" "blue") "color" "Color?" (list "red" "blue") }}',
        ]
    )
    assert choice_res.returncode == 0
    assert choice_res.stderr == b""
    assert choice_res.stdout == b"blue"


def test_prompt_multichoice_once_splits_comma_separated_map_value(sb):
    """promptMultichoiceOnce splits a stored string on commas."""
    # CATCHES: unlike the flag (which splits on /), a value found in the
    # data map is split on commas, yielding the two-element list [x y].
    res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptMultichoiceOnce (dict "m" "x,y") "m" "M?" (list "x") | join "," }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"x,y"


def test_prompt_multichoice_without_flag_or_default_returns_prompt(sb):
    """promptMultichoice with no flag and no default list echoes the prompt."""
    # CATCHES: with no matching flag and no default argument the function
    # returns the single-element list containing the prompt text itself.
    res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptMultichoice "pick" (list "a" "b") | join "," }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"pick"


def test_prompt_multichoice_extra_arguments_use_first_default(sb):
    """promptMultichoice ignores extra default arguments beyond the first."""
    # CATCHES: the function has no arity check - only the first default
    # argument is used and further arguments are silently discarded.
    res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptMultichoice "m" (list "a") (list "b") (list "c") }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"[b]"


def test_prompt_multichoice_invalid_choice_is_an_error(sb):
    """Every slash-separated flag answer must be among the choices."""
    # CATCHES: unlike promptChoice (which validates only the flag value),
    # promptMultichoice checks each element of the split flag value, and the
    # error echoes the whole flag value, not the offending element.
    res = sb.run(
        [
            "execute-template",
            "--init",
            "--promptMultichoice",
            "tops=hat/shoes",
            '{{ promptMultichoice "tops" (list "hat" "coat") }}',
        ]
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" at '
        b'<promptMultichoice "tops" (list "hat" "coat")>: '
        b"error calling promptMultichoice: hat/shoes: invalid choice\n"
    )


def test_prompt_string_once_invalid_path_type(sb):
    """promptStringOnce validates the path like the at-path functions."""
    # CATCHES: the *Once prompt functions run the same path validation as
    # setValueAtPath, so an integer path fails with the invalid path type
    # error naming the value.
    res = sb.run(
        ["execute-template", "--init", '{{ promptStringOnce . 1 "x" }}']
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" at '
        b'<promptStringOnce . 1 "x">: '
        b"error calling promptStringOnce: 1: invalid path type int\n"
    )


def test_prompt_choice_default_argument(sb):
    """promptChoice's optional default is used only without a flag value."""
    # CATCHES: the default (third argument) is returned when no flag matches
    # the prompt name, and a matching flag still wins over the default.
    flagged = sb.run(
        [
            "execute-template",
            "--init",
            "--promptChoice",
            "color=red",
            '{{ promptChoice "color" (list "red" "green") "blue" }}',
        ]
    )
    assert flagged.returncode == 0
    assert flagged.stderr == b""
    assert flagged.stdout == b"red"
    fallback = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptChoice "color" (list "red" "green") "blue" }}',
        ]
    )
    assert fallback.returncode == 0
    assert fallback.stderr == b""
    assert fallback.stdout == b"blue"


@pytest.mark.parametrize(
    "template, message",
    [
        (
            '{{ promptChoice "c" (list "r") "a" "b" }}',
            b"error calling promptChoice: want 2 or 3 arguments, got 3\n",
        ),
        (
            '{{ promptInt "n" 1 2 }}',
            b"error calling promptInt: want 1 or 2 arguments, got 3\n",
        ),
        (
            '{{ promptString "a" "b" "c" }}',
            b"error calling promptString: want 1 or 2 arguments, got 3\n",
        ),
    ],
)
def test_prompt_arity_errors(sb, template, message):
    """Extra default arguments are arity errors for the prompt functions."""
    # CATCHES: each prompt function checks its arity at execution time;
    # promptChoice counts the prompt plus choices, the others count the
    # prompt plus defaults.
    res = sb.run(["execute-template", "--init", template])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(message)


def test_prompt_once_non_string_map_values_fall_back(sb):
    """*Once functions skip non-string map values and fall back."""
    # CATCHES: promptChoiceOnly/promptMultichoiceOnce only use string map
    # values - an integer under the key is ignored and the ordinary prompt
    # function runs with the default argument (or the prompt text itself
    # when there is none).
    choice = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptChoiceOnce (dict "color" 5) "color" "Color?" (list "red" "green") "red" }}',
        ]
    )
    assert choice.returncode == 0
    assert choice.stderr == b""
    assert choice.stdout == b"red"
    multichoice = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptMultichoiceOnce (dict "m" 5) "m" "M?" (list "x" "y") | join "," }}',
        ]
    )
    assert multichoice.returncode == 0
    assert multichoice.stderr == b""
    assert multichoice.stdout == b"M?"


def test_prompt_int_once_returns_int64_from_parsed_json(sb):
    """promptIntOnce uses an int64 stored by fromJson in the data map."""
    # CATCHES: only int64 values are taken from the data map - fromJson
    # produces int64 numbers, so its 42 is returned directly (unlike a
    # template literal 42, which is an int and is skipped).
    res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptIntOnce (fromJson "{\\"n\\": 42}") "n" "n?" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"42"


def test_prompt_string_once_walks_dotted_paths(sb):
    """promptStringOnce resolves dotted paths against nested data maps."""
    # CATCHES: a dotted path like a.b is split and walked into nested maps
    # (whether built with dict or parsed by fromJson), so the deep value
    # wins; a scalar intermediate or a non-string leaf falls back to the
    # prompt text.
    res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptStringOnce (dict "a" (dict "b" "nested")) "a.b" "P?" }}|'
            '{{ promptStringOnce (dict "a" "scalar") "a.b" "P?" }}|'
            '{{ promptStringOnce (dict "a" (dict "b" 5)) "a.b" "P?" }}|'
            '{{ promptStringOnce (fromJson "{\\"a\\":{\\"b\\":\\"deep\\"}}") "a.b" "P?" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"nested|P?|P?|deep"


def test_typed_prompt_once_functions_walk_dotted_paths(sb):
    """The typed prompt*Once variants also resolve dotted paths."""
    # CATCHES: promptIntOnce/promptBoolOnce/promptChoiceOnce and
    # promptMultichoiceOnce all walk dotted paths into nested maps and keep
    # the stored value's type (int64 from fromJson, bool, choice string)
    # with multichoice splitting the stored string on commas.
    res = sb.run(
        [
            "execute-template",
            "--init",
            '{{ promptIntOnce (fromJson "{\\"a\\":{\\"b\\":7}}") "a.b" "n" }}|'
            '{{ promptBoolOnce (dict "a" (dict "b" true)) "a.b" "ok?" }}|'
            '{{ promptChoiceOnce (dict "a" (dict "b" "blue")) "a.b" "C?" (list "red" "blue") }}|'
            '{{ promptMultichoiceOnce (dict "a" (dict "b" "x,y")) "a.b" "M?" (list "x") | join "," }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"7|true|blue|x,y"
