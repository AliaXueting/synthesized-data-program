"""Black-box tests for the built-in template functions.

These exercise the chezmoi-specific functions layered on top of sprig:
parsers (fromJson/fromJsonc/fromToml/fromYaml/fromIni), serializers
(toJson/toPrettyJson/toToml/toYaml/toIni), jq, glob, executable lookup,
stat/lstat, process helpers (output/outputList/exec), text helpers, quoting,
hex, regex, and the message/abort functions.
"""

import pytest


def test_from_json_number_types(sb):
    """fromJson keeps integers as integers and floats as floats."""
    # CATCHES: chezmoi's fromJson (unlike encoding/json) returns int64 for
    # integer literals so they print without a decimal point.
    res = sb.run(
        [
            "execute-template",
            '{{ fromJson "3" }} {{ fromJson "3.5" }} {{ fromJson "{\\"a\\":1}" | toJson }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'3 3.5 {"a":1}'


def test_from_json_error(sb):
    """fromJson reports the JSON syntax error at the offending position."""
    # CATCHES: parse failures surface as "error calling fromJson" with the
    # underlying decoder message.
    res = sb.run(["execute-template", '{{ fromJson "{bad" }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling fromJson: invalid character 'b' looking for beginning of object key string\n"
    )


def test_from_jsonc_strips_comments(sb):
    """fromJsonc accepts JSON with // comments."""
    # CATCHES: the separate fromJsonc function tolerates comment lines that
    # plain fromJson would reject.
    res = sb.run(
        ["execute-template", '{{ fromJsonc "// c\\n{\\"a\\":2}" | toJson }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{"a":2}'


def test_from_toml_and_from_yaml(sb):
    """fromToml and fromYaml parse into maps usable by toJson."""
    # CATCHES: both parsers produce chezmoi maps (all keys present) that
    # round-trip through toJson.
    toml_res = sb.run(["execute-template", '{{ fromToml "a = 3" | toJson }}'])
    assert toml_res.returncode == 0
    assert toml_res.stdout == b'{"a":3}'
    yaml_res = sb.run(["execute-template", '{{ fromYaml "a: hi" | toJson }}'])
    assert yaml_res.returncode == 0
    assert yaml_res.stdout == b'{"a":"hi"}'


def test_from_yaml_error(sb):
    """fromYaml fails with the parser's annotated error."""
    # CATCHES: YAML errors include the go-yaml position diagram, which is
    # part of the observable stderr.
    res = sb.run(["execute-template", '{{ fromYaml "a: [" }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling fromYaml: [1:4] sequence end token ']' not found\n>  1 | a: [\n          ^\n\n"
    )


def test_to_json_sorts_keys_and_escapes_html(sb):
    """toJson sorts keys and escapes < > & like encoding/json."""
    # CATCHES: keys are emitted in sorted order and HTML characters are
    # escaped as \\u003c-style sequences.
    res = sb.run(["execute-template", '{{ toJson (dict "b" 2 "a" "x") }}'])
    assert res.returncode == 0
    assert res.stdout == b'{"a":"x","b":2}'
    escaped = sb.run(["execute-template", '{{ toJson (dict "h" "<b>&") }}'])
    assert escaped.returncode == 0
    assert escaped.stdout == b'{"h":"\\u003cb\\u003e\\u0026"}'


def test_to_pretty_json(sb):
    """toPrettyJson pretty-prints with two spaces and does not escape HTML."""
    # CATCHES: toPrettyJson indents, adds a trailing newline and leaves
    # HTML characters unescaped (unlike toJson).
    res = sb.run(["execute-template", '{{ toPrettyJson (dict "b" 2 "a" "x") }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{\n  "a": "x",\n  "b": 2\n}\n'
    no_escape = sb.run(["execute-template", '{{ toPrettyJson (dict "h" "<b>&") }}'])
    assert no_escape.stdout == b'{\n  "h": "<b>&"\n}\n'


def test_to_pretty_json_custom_indent(sb):
    """toPrettyJson accepts a custom indent string as its first argument."""
    # CATCHES: the two-argument form uses the first argument as the indent.
    res = sb.run(
        ["execute-template", '{{ toPrettyJson "  " (dict "a" (dict "b" 1)) }}']
    )
    assert res.returncode == 0
    assert res.stdout == b'{\n  "a": {\n    "b": 1\n  }\n}\n'


def test_to_toml_and_to_yaml(sb):
    """toToml and toYaml serialize maps in the libraries' formats."""
    # CATCHES: toToml emits `key = value` lines and toYaml nests mappings
    # with two-space indentation.
    toml_res = sb.run(["execute-template", '{{ toToml (dict "a" 1 "b" "s") }}'])
    assert toml_res.returncode == 0
    assert toml_res.stdout == b'a = 1\nb = "s"\n'
    yaml_res = sb.run(["execute-template", '{{ toYaml (dict "a" 1 "b" (dict "c" true)) }}'])
    assert yaml_res.returncode == 0
    assert yaml_res.stdout == b"a: 1\nb:\n  c: true\n"


def test_ini_round_trip_and_value_quoting(sb):
    """toIni writes sections after keys and quotes ambiguous values."""
    # CATCHES: scalars come first, subsections follow after a blank line,
    # and string values that look like bools/floats (or are empty) are
    # double-quoted.
    res = sb.run(["execute-template", '{{ toIni (dict "a" 1 "sec" (dict "k" "v")) }}'])
    assert res.returncode == 0
    assert res.stdout == b"a = 1\n\n[sec]\nk = v\n"
    quoted = sb.run(["execute-template", '{{ toIni (dict "a" "true" "b" "1.5" "c" "") }}'])
    assert quoted.returncode == 0
    assert quoted.stdout == b'a = "true"\nb = "1.5"\nc = ""\n'
    parsed = sb.run(["execute-template", '{{ fromIni "x = 1\\n[s]\\ny = 2\\n" | toJson }}'])
    assert parsed.returncode == 0
    assert parsed.stdout == b'{"s":{"y":"2"},"x":"1"}'


def test_to_ini_nested_sections_and_value_quoting(sb):
    """toIni nests maps as dotted sections and quotes only when needed."""
    # CATCHES: a map inside a map becomes a [section], a map inside that
    # becomes [section.sub] (each preceded by a blank line), and only values
    # that need it (here: one containing a space) are double-quoted while
    # plain strings and integers stay bare.
    res = sb.run(
        [
            "execute-template",
            '{{ toIni (dict "top" "v" "section" (dict "k" "v" "sub" (dict "x" 1))) }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"top = v\n\n[section]\nk = v\n\n[section.sub]\nx = 1\n"
    quoted = sb.run(
        [
            "execute-template",
            '{{ toIni (dict "k" "has space" "j" "plain" "n" 42) }}',
        ]
    )
    assert quoted.returncode == 0
    assert quoted.stderr == b""
    assert quoted.stdout == b'j = plain\nk = "has space"\nn = 42\n'
    scalars = sb.run(
        ["execute-template", '{{ toIni (dict "flag" true "f" 1.5) }}']
    )
    assert scalars.returncode == 0
    assert scalars.stderr == b""
    # CATCHES: bools render as %t and floats with %f (six decimals), not the
    # quoting or compact float formatting used elsewhere.
    assert scalars.stdout == b"f = 1.500000\nflag = true\n"


def test_to_ini_rejects_lists(sb):
    """toIni fails on list values with an unsupported-type error."""
    # CATCHES: the INI writer only handles scalars and maps, so a list value
    # aborts the template, naming the key and the Go type of the value.
    res = sb.run(["execute-template", '{{ toIni (dict "list" (list "a" "b")) }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling toIni: list: []interface {}: unsupported type\n"
    )


def test_from_ini_child_sections_appear_nested_and_top_level(sb):
    """fromIni parses dotted sections both nested and as their own keys."""
    # CATCHES: [sec.sub] is attached to the sec map as a nested "sec.sub" key
    # AND also shows up as a top-level "sec.sub" key, because the INI
    # library registers the child section under both its parent and root.
    res = sb.run(
        [
            "execute-template",
            '{{ fromIni "top = 1\\n[sec]\\nk = v\\n[sec.sub]\\nx = 2" | toJson }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b'{"sec":{"k":"v","sec.sub":{"x":"2"}},"sec.sub":{"x":"2"},"top":"1"}'
    )


def test_jq_function(sb):
    """jq runs gojq queries and returns every result in a list."""
    # CATCHES: the result is always a list of the query's outputs, so a
    # mapping query prints as [z] and a list query as [[2 4 6]].
    mapped = sb.run(["execute-template", '{{ jq "[.[] * 2]" (list 1 2 3) }}'])
    assert mapped.returncode == 0
    assert mapped.stdout == b"[[2 4 6]]"
    field = sb.run(["execute-template", '{{ jq ".a" (dict "a" "z") }}'])
    assert field.returncode == 0
    assert field.stdout == b"[z]"
    error = sb.run(["execute-template", '{{ jq ".[" (dict) }}'])
    assert error.returncode == 1
    assert error.stderr.endswith(b"error calling jq: unexpected EOF\n")


def test_jq_runtime_error_is_a_template_error(sb):
    """A gojq error() during evaluation aborts the template."""
    # CATCHES: query parse errors and runtime errors are reported
    # differently - a runtime error("boom") surfaces as "error calling jq:
    # error: boom" with exit code 1.
    res = sb.run(
        ["execute-template", '{{ jq ".a | error(\\"boom\\")" (dict "a" 1) }}']
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" at '
        b'<jq ".a | error(\\"boom\\")" (dict "a" 1)>: '
        b"error calling jq: error: boom\n"
    )


@pytest.mark.parametrize(
    "pattern, expected",
    [
        ("*", b"[A.txt sub]"),
        ("*.txt", b"[A.txt]"),
        ("**/*.txt", b"[A.txt sub/B.txt]"),
        ("*.zzz", b"[]"),
    ],
)
def test_glob_function(sb, pattern, expected):
    """glob matches the destination directory and returns sorted results."""
    # CATCHES: patterns are resolved relative to the destination directory
    # (not the working directory), ** crosses directory boundaries, and a
    # non-matching pattern yields an empty slice printed as [].
    sb.write("home", "A.txt", contents="A")
    sb.write("home", "sub", "B.txt", contents="B")
    res = sb.run(["execute-template", '{{ glob "' + pattern + '" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_glob_case_insensitive(sb):
    """globCaseInsensitive matches patterns regardless of case."""
    # CATCHES: the case-insensitive variant finds A.txt with an uppercase
    # extension in the pattern, which plain glob would not.
    sb.write("home", "A.txt", contents="A")
    res = sb.run(["execute-template", '{{ globCaseInsensitive "*.TXT" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"[A.txt]"


def test_glob_absolute_pattern(sb):
    """glob accepts absolute patterns and returns absolute paths."""
    # CATCHES: an absolute pattern is used as-is and the results keep the
    # absolute form.
    sb.write("home", "g", "x.txt", contents="x")
    pattern = sb.home / "g" / "*.txt"
    res = sb.run(["execute-template", '{{ glob "' + str(pattern) + '" }}'])
    assert res.returncode == 0
    assert res.stdout == "[{}]".format(sb.home / "g" / "x.txt").encode()


def test_join_path(sb):
    """joinPath cleans and joins path elements."""
    # CATCHES: joinPath uses path cleaning (.. is resolved) and an empty
    # argument list yields the empty string.
    res = sb.run(
        ["execute-template", '{{ joinPath "a" "b" "c" }} {{ joinPath "/x" "../y" }} {{ joinPath }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"a/b/c /y "


def test_look_path(sb):
    """lookPath resolves via PATH and returns "" for missing commands."""
    # CATCHES: the resolved path honors the child's PATH (/usr/bin first)
    # and a missing command yields an empty string, not an error.
    res = sb.run(
        [
            "execute-template",
            '{{ lookPath "sh" }}|{{ lookPath "definitely-not-a-command" }}|',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"/usr/bin/sh||"


def test_find_and_is_executable(sb):
    """findExecutable/findOneExecutable search path lists; isExecutable stats."""
    # CATCHES: findExecutable searches the given directories in order (here
    # /bin before /usr/bin), findOneExecutable tries a list of names, a
    # missing candidate yields "" rather than an error, and isExecutable
    # returns false for non-executable or missing files.
    res = sb.run(
        [
            "execute-template",
            '{{ findExecutable "sh" (list "/bin" "/usr/bin") }}|'
            "{{ findExecutable \"definitely-not-here\" (list \"/bin\") }}|"
            '{{ findOneExecutable (list "definitely-not-here" "sh") (list "/bin" "/usr/bin") }}|'
            "{{ isExecutable \"/bin/sh\" }} {{ isExecutable \"/etc/hostname\" }} {{ isExecutable \"/no/such/file\" }}",
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"/bin/sh||/bin/sh|true false false"


def test_stat_and_lstat(sb):
    """stat/lstat expose name, size, perm and type; missing paths are nil."""
    # CATCHES: stat follows symlinks (the target's type) while lstat reports
    # the symlink itself, and a missing path renders as <no value>.
    sb.write("f.txt", contents="0123456789", mode=0o644)
    sb.path("link").symlink_to(sb.path("f.txt"))
    res = sb.run(
        [
            "execute-template",
            '{{ (stat "f.txt").name }} {{ (stat "f.txt").size }} {{ (stat "f.txt").perm }} '
            '{{ (stat "f.txt").type }} {{ (lstat "link").type }} {{ stat "missing-file" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"f.txt 10 420 file symlink <no value>"


def test_stat_directory(sb):
    """stat on a directory reports isDir and the dir type."""
    # CATCHES: directories report type "dir" and isDir true, distinguishing
    # them from regular files.
    sb.write("subdir", ".keep", contents="")
    res = sb.run(
        ["execute-template", '{{ (stat "subdir").type }} {{ (stat "subdir").isDir }}']
    )
    assert res.returncode == 0
    assert res.stdout == b"dir true"


def test_lstat_missing_file_is_no_value(sb):
    """lstat on a missing path returns nil, rendered as <no value>."""
    # CATCHES: like stat, lstat maps a missing path to nil rather than an
    # error, and the nil result prints as the <no value> placeholder while a
    # real path still yields its fields.
    sb.write("f.txt", contents="data")
    res = sb.run(
        ["execute-template", '{{ (lstat "f.txt").name }} {{ lstat "missing-file" }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"f.txt <no value>"


def test_output_function(sb):
    """output captures stdout of a command and passes stderr through."""
    # CATCHES: only the command's stdout is returned as the function value;
    # its stderr is forwarded to chezmoi's stderr unchanged.
    res = sb.run(["execute-template", '{{ output "sh" "-c" "echo E >&2; echo O" }}'])
    assert res.returncode == 0
    assert res.stdout == b"O\n"
    assert res.stderr == b"E\n"


def test_output_list_function(sb):
    """outputList passes a list of arguments to the command."""
    # CATCHES: the arguments arrive as one list parameter and are flattened
    # into the command line.
    res = sb.run(["execute-template", '{{ outputList "echo" (list "a" "b") }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"a b\n"


def test_output_function_errors(sb):
    """output panics on non-zero exit and missing commands."""
    # CATCHES: a failing command is an execution error naming the resolved
    # binary path and its exit status; a missing command reports the exec
    # lookup failure.
    failing = sb.run(["execute-template", '{{ output "false" }}'])
    assert failing.returncode == 1
    assert failing.stderr.endswith(b"error calling output: /usr/bin/false: exit status 1\n")
    missing = sb.run(["execute-template", '{{ output "definitely-not-a-command" }}'])
    assert missing.returncode == 1
    assert missing.stderr.endswith(
        b'error calling output: definitely-not-a-command: exec: "definitely-not-a-command": '
        b"executable file not found in $PATH\n"
    )


def test_exec_function(sb):
    """exec reports success/failure as a bool and errors on missing commands."""
    # CATCHES: exec swallows exit-status failures (returning false) but a
    # command that cannot be found is still a template error.
    res = sb.run(
        [
            "execute-template",
            '{{ exec "true" }} {{ exec "false" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"true false"
    missing = sb.run(["execute-template", '{{ exec "definitely-not-a-command" }}'])
    assert missing.returncode == 1
    assert missing.stderr.endswith(
        b'error calling exec: exec: "definitely-not-a-command": executable file not found in $PATH\n'
    )


def test_comment_function(sb):
    """comment prefixes every line, including the final empty one."""
    # CATCHES: comment operates per line and preserves whether each line had
    # a trailing newline; "a\nb" gains no trailing newline after b.
    res = sb.run(["execute-template", '{{ comment "# " "a\\nb" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"# a\n# b"
    trailing = sb.run(["execute-template", '{{ comment "#" "x\\n" }}'])
    assert trailing.returncode == 0
    assert trailing.stdout == b"#x\n"


def test_ensure_line_prefix(sb):
    """ensureLinePrefix adds a prefix to lines missing it."""
    # CATCHES: the two-argument form checks and adds the same prefix (lines
    # already prefixed are untouched); the three-argument form checks the
    # first prefix but adds the second.
    two = sb.run(["execute-template", '{{ ensureLinePrefix "- " "a\\n- b\\n" }}'])
    assert two.returncode == 0
    assert two.stdout == b"- a\n- b\n"
    three = sb.run(["execute-template", '{{ ensureLinePrefix "- " "* " "a\\nb\\n" }}'])
    assert three.returncode == 0
    assert three.stdout == b"* a\n* b\n"


def test_ensure_line_prefix_arity(sb):
    """ensureLinePrefix requires two or three arguments."""
    # CATCHES: one argument is rejected at execution time with the expected
    # arity message.
    res = sb.run(["execute-template", '{{ ensureLinePrefix "- " }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling ensureLinePrefix: expected 2 or 3 arguments, got 1\n"
    )


def test_eq_fold(sb):
    """eqFold compares ASCII case-insensitively across all arguments."""
    # CATCHES: eqFold returns true when any argument equals the first
    # case-insensitively and false otherwise.
    res = sb.run(["execute-template", '{{ eqFold "Go" "go" "GO" }} {{ eqFold "Go" "py" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"true false"


def test_eq_fold_checks_later_arguments_only_after_the_second(sb):
    """eqFold falls through to the remaining arguments, never the default."""
    # CATCHES: the second argument is checked first, then each extra
    # argument in order; a match on the third still yields true while no
    # match at all yields false.
    res = sb.run(
        [
            "execute-template",
            '{{ eqFold "a" "b" "A" }} {{ eqFold "a" "b" "c" }} {{ eqFold "a" "b" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"true false false"


def test_dict_manipulation_functions(sb):
    """pruneEmptyDicts, deleteValueAtPath and setValueAtPath edit maps."""
    # CATCHES: pruneEmptyDicts removes empty nested maps recursively,
    # deleteValueAtPath removes a key (returning the map unchanged when the
    # path is absent), and setValueAtPath creates intermediate maps.
    res = sb.run(
        [
            "execute-template",
            '{{ pruneEmptyDicts (dict "a" (dict) "b" (dict "c" 1)) | toJson }} '
            '{{ deleteValueAtPath "a.b" (dict "a" (dict "b" 1 "c" 2)) | toJson }} '
            '{{ deleteValueAtPath "a.z" (dict "a" (dict "b" 1)) | toJson }} '
            '{{ setValueAtPath "a.b" 2 (dict "x" 9) | toJson }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b'{"b":{"c":1}} {"a":{"c":2}} {"a":{"b":1}} {"a":{"b":2},"x":9}'
    )


def test_set_value_at_path_accepts_list_paths(sb):
    """setValueAtPath also accepts a list of path elements."""
    # CATCHES: unlike deleteValueAtPath, the path argument is untyped, so a
    # list of strings is treated as the path elements and nested maps are
    # created for each element.
    res = sb.run(
        ["execute-template", '{{ setValueAtPath (list "a" "b") 1 (dict) | toJson }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{"a":{"b":1}}'


def test_delete_value_at_path_requires_a_string_path(sb):
    """deleteValueAtPath rejects a list path with a type error."""
    # CATCHES: deleteValueAtPath's path parameter is declared as a plain
    # string, so passing a list is rejected by the template engine's
    # argument checking (not by the function's own path validation).
    res = sb.run(
        [
            "execute-template",
            '{{ deleteValueAtPath (list "a" "b") (dict "a" (dict "b" 2 "c" 3)) }}',
        ]
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:31: executing "arg1" at <"b">: '
        b"wrong type for value; expected string; got []interface {}\n"
    )


def test_delete_value_at_path_non_map_intermediate_is_unchanged(sb):
    """deleteValueAtPath returns the map unchanged when a step is not a map."""
    # CATCHES: walking the path stops silently at a scalar intermediate
    # value instead of erroring, leaving the dictionary exactly as it was.
    res = sb.run(
        ["execute-template", '{{ deleteValueAtPath "a.b" (dict "a" 1) | toJson }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{"a":1}'


def test_set_value_at_path_arity(sb):
    """setValueAtPath requires exactly three arguments."""
    # CATCHES: the template engine's arity check message for setValueAtPath
    # is observable behavior.
    res = sb.run(["execute-template", '{{ setValueAtPath "a.b" 2 }}'])
    assert res.returncode == 1
    assert res.stderr.endswith(
        b"wrong number of args for setValueAtPath: want 3 got 2\n"
    )


@pytest.mark.parametrize(
    "template, message",
    [
        ('{{ setValueAtPath "" 1 (dict) }}', b"error calling setValueAtPath: empty path\n"),
        (
            '{{ setValueAtPath "a..b" 1 (dict) }}',
            b"error calling setValueAtPath: empty path element at index 1\n",
        ),
        (
            "{{ setValueAtPath 1 2 (dict) }}",
            b"error calling setValueAtPath: 1: invalid path type int\n",
        ),
        ('{{ deleteValueAtPath "" (dict) }}', b"error calling deleteValueAtPath: empty path\n"),
        (
            '{{ deleteValueAtPath "a..b" (dict) }}',
            b"error calling deleteValueAtPath: empty path element at index 1\n",
        ),
    ],
)
def test_path_validation_errors(sb, template, message):
    """The *AtPath functions validate dotted paths before mutating maps."""
    # CATCHES: an empty path, an empty element (from "..") and a non-string
    # path each produce their own distinct error message.
    res = sb.run(["execute-template", template])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(message)


def test_to_pretty_json_indent_type_and_arity(sb):
    """toPrettyJson validates its optional indent argument and arity."""
    # CATCHES: a non-string indent and a zero-argument call are both
    # execution errors with distinct messages.
    bad_indent = sb.run(["execute-template", '{{ toPrettyJson 1 (dict "a" 1) }}'])
    assert bad_indent.returncode == 1
    assert bad_indent.stderr.endswith(
        b"error calling toPrettyJson: arg 1: expected a string, got a int\n"
    )
    no_args = sb.run(["execute-template", "{{ toPrettyJson }}"])
    assert no_args.returncode == 1
    assert no_args.stderr.endswith(
        b"error calling toPrettyJson: expected 1 or 2 arguments, got 0\n"
    )


def test_hex_functions(sb):
    """hexEncode/hexDecode round-trip bytes."""
    # CATCHES: hexEncode returns lowercase hex and hexDecode errors on
    # non-hex input with the encoding/hex message.
    res = sb.run(["execute-template", '{{ hexEncode "hi" }} {{ hexDecode "6869" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"6869 hi"
    error = sb.run(["execute-template", '{{ hexDecode "zz" }}'])
    assert error.returncode == 1
    assert error.stderr.endswith(
        b"error calling hexDecode: encoding/hex: invalid byte: U+007A 'z'\n"
    )


def test_replace_all_regex(sb):
    """replaceAllRegex substitutes regexp matches including $1 groups."""
    # CATCHES: the replacement supports Go regexp group references like $2.
    res = sb.run(
        [
            "execute-template",
            '{{ replaceAllRegex "o+" "0" "foo boo" }} {{ replaceAllRegex "(\\\\w+)@(\\\\w+)" "$2:$1" "me@home" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"f0 b0 home:me"


def test_quoting_functions(sb):
    """quote/squote/quoteList/shellQuote/shellQuoteList/splitList formats."""
    # CATCHES: quote uses Go strconv quoting (and drops nil), squote wraps in
    # single quotes, shellQuote POSIX-quotes (empty becomes '' and embedded
    # quotes use the '\'' idiom), and quoteList/shellQuoteList map over lists.
    res = sb.run(
        [
            "execute-template",
            '{{ quote "a b" "c" }}|{{ quote nil "x" }}|{{ squote "a b" }}|'
            "{{ quoteList (list \"a\" \"b c\") }}|"
            "{{ shellQuote \"simple\" }}|{{ shellQuote \"has space\" }}|"
            "{{ shellQuote \"\" }}|{{ shellQuote \"it's\" }}|"
            "{{ shellQuoteList \"a\" \"b c\" }}|"
            '{{ splitList "," "a,b,c" }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b'"a b" "c"|"x"|\'a b\'|["a" "b c"]|'
        b"simple|'has space'|''|'it'\\''s'|"
        b"[a 'b c']|[a b c]"
    )


def test_to_string_and_to_strings(sb):
    """toString/toStrings render scalars and flatten values to strings."""
    # CATCHES: floats print without trailing zeros, nil-typed values are
    # dropped by toString, and toStrings flattens nested lists.
    res = sb.run(
        [
            "execute-template",
            '{{ toString 42 }}|{{ toString 4.5 }}|{{ toString true }}|'
            "{{ toString (list 1 2) }}|{{ toStrings 1 \"a\" (list 2 3) }}",
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"42|4.5|true|[1 2]|[1 a 2 3]"


def test_abort_empty_discards_output_and_exits_zero(sb):
    """abortEmpty makes the whole result empty with exit code 0."""
    # CATCHES: the abort-empty sentinel discards everything rendered so far
    # and reports success with empty output rather than an error; without
    # the call the same template renders normally, proving the empty result
    # comes from the abort.
    control = sb.run(["execute-template", 'X{{ "Z" }}Y'])
    assert control.returncode == 0
    assert control.stderr == b""
    assert control.stdout == b"XZY"
    res = sb.run(["execute-template", "X{{ abortEmpty }}Y"])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_warnf_writes_to_stderr(sb):
    """warnf writes a "warning:" line to stderr and renders empty."""
    # CATCHES: the message is formatted onto stderr with the chezmoi: and
    # warning: prefixes while the function itself returns "".
    res = sb.run(["execute-template", 'A{{ warnf "careful %s" "now" }}B'])
    assert res.returncode == 0
    assert res.stdout == b"AB"
    assert res.stderr == b"chezmoi: warning: careful now\n"


def test_debugf_only_with_verbose(sb):
    """debugf is silent unless the global --verbose flag is set."""
    # CATCHES: debugf returns "" either way but only prints a "debug:" line
    # to stderr in verbose mode.
    quiet = sb.run(["execute-template", 'A{{ debugf "dbg %d" 7 }}B'])
    assert quiet.returncode == 0
    assert quiet.stdout == b"AB"
    assert quiet.stderr == b""
    verbose = sb.run(["--verbose", "execute-template", '{{ debugf "dbg %d" 7 }}'])
    assert verbose.returncode == 0
    assert verbose.stdout == b""
    assert verbose.stderr == b"chezmoi: debug: dbg 7\n"


def test_stdin_is_atty_false_without_tty(sb):
    """stdinIsATTY reports false for a pipe."""
    # CATCHES: with stdin connected to a pipe (as in every test run) the
    # function returns the boolean false.
    res = sb.run(["execute-template", "{{ stdinIsATTY }}"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"false"


def test_ioreg_returns_empty_map_on_linux(sb):
    """ioreg returns an empty map on non-macOS platforms."""
    # CATCHES: on Linux the ioreg function is a no-op returning an empty map
    # (printed by the template engine as map[]) rather than an error.
    res = sb.run(["execute-template", "{{ ioreg }}"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"map[]"


def test_mozilla_install_hash(sb):
    """mozillaInstallHash computes the fixed install hash for a path."""
    # CATCHES: the hash is a deterministic 16-character uppercase hex string
    # for the given input.
    res = sb.run(["execute-template", '{{ mozillaInstallHash "thunderbird" }}'])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"9E79F3819B9E69A0"


def test_git_hub_refresh_period_config_validation(sb):
    """The gitHub.refreshPeriod config value must parse as a duration."""
    # CATCHES: an invalid duration aborts every command with the config
    # decode error naming the config file path and the offending key; the
    # gitHub* template functions themselves need network access, but their
    # configuration is validated up front.
    sb.write_config('[gitHub]\nrefreshPeriod = "bogus"\n')
    res = sb.run(["execute-template", "x"])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"chezmoi: invalid config: " + str(sb.config_file).encode()
        + b": decoding failed due to the following error(s): "
        b"'gitHub.refreshPeriod' time: invalid duration\n"
    )
    sb.write_config('[gitHub]\nrefreshPeriod = "1m"\n')
    ok = sb.run(["execute-template", "x"])
    assert ok.returncode == 0
    assert ok.stdout == b"x"


def test_completion_template_function(sb):
    """The completion template function emits shell scripts."""
    # CATCHES: `completion "bash"` returns the multi-kilobyte completion
    # script whose first line identifies it, and an unsupported shell is an
    # execution error.
    head = sb.run(
        ["execute-template", '{{ completion "bash" | splitList "\\n" | first }}']
    )
    assert head.returncode == 0
    assert head.stderr == b""
    assert head.stdout.startswith(b"# bash completion V2 for chezmoi")
    bad = sb.run(["execute-template", '{{ completion "tcsh" }}'])
    assert bad.returncode == 1
    assert bad.stderr.endswith(b"error calling completion: tcsh: unsupported shell\n")


def test_sprig_functions_are_available(sb):
    """The sprig function library is registered alongside chezmoi's."""
    # CATCHES: sprig functions like upper and b64enc coexist with the
    # chezmoi replacements (toJson etc.).
    res = sb.run(
        ["execute-template", '{{ upper "abc" }} {{ b64enc "hi" }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"ABC aGk="


def test_source_file_data_of_argument(sb):
    """.chezmoi.sourceFile names the template being executed."""
    # CATCHES: each argument template is named argN and that name is exposed
    # through the .chezmoi.sourceFile template variable.
    res = sb.run(["execute-template", "{{ .chezmoi.sourceFile }}"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"arg1"


def test_set_value_at_path_walks_into_existing_maps(sb):
    """setValueAtPath descends through intermediate maps that already exist."""
    # CATCHES: a dotted path whose intermediate keys already hold maps is
    # walked into rather than replaced, so the sibling key c survives while
    # b is set inside the existing map.
    res = sb.run(
        ["execute-template", '{{ setValueAtPath "a.b" 1 (dict "a" (dict "c" 9)) | toJson }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{"a":{"b":1,"c":9}}'


def test_set_value_at_path_replaces_non_map_intermediate(sb):
    """setValueAtPath overwrites a scalar intermediate with a fresh map."""
    # CATCHES: when a path element already exists but holds a scalar (here
    # the 5 under a), it is silently replaced by a new empty map instead of
    # erroring or coercing the scalar.
    res = sb.run(
        ["execute-template", '{{ setValueAtPath "a.b" 1 (dict "a" 5) | toJson }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{"a":{"b":1}}'


def test_set_value_at_path_builds_a_new_map_for_non_dict_argument(sb):
    """setValueAtPath starts from scratch when the third argument is not a dict."""
    # CATCHES: a string third argument is discarded entirely and a brand-new
    # map is built, so the result contains only the newly set path.
    res = sb.run(
        ["execute-template", '{{ setValueAtPath "a.b" 1 "notadict" | toJson }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{"a":{"b":1}}'


def test_delete_value_at_path_missing_intermediate_is_unchanged(sb):
    """deleteValueAtPath returns the map unchanged when an intermediate key is absent."""
    # CATCHES: deleting a.b when a itself does not exist is a silent no-op
    # that returns the original map (here z is preserved) rather than an
    # error or a partially created path.
    res = sb.run(
        ["execute-template", '{{ deleteValueAtPath "a.b" (dict "z" 1) | toJson }}']
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{"z":1}'


@pytest.mark.parametrize(
    "template, message",
    [
        ("{{ setValueAtPath (list) 1 (dict) }}", b"error calling setValueAtPath: empty path\n"),
        (
            '{{ setValueAtPath (list 1 "b") 1 (dict) }}',
            b"error calling setValueAtPath: 1: invalid path element type int\n",
        ),
        (
            '{{ setValueAtPath (list "" "b") 1 (dict) }}',
            b"error calling setValueAtPath: empty path element at index 0\n",
        ),
        (
            '{{ setValueAtPath (fromJson "null") 1 (dict) }}',
            b"error calling setValueAtPath: empty path\n",
        ),
        (
            '{{ setValueAtPath (glob "*.zzz") 1 (dict) }}',
            b"error calling setValueAtPath: empty path\n",
        ),
    ],
)
def test_set_value_at_path_invalid_list_paths(sb, template, message):
    """setValueAtPath validates list, nil and glob-result paths element by element."""
    # CATCHES: an empty list, a nil path (fromJson null), an empty glob
    # result and non-string or empty list elements each fail with their own
    # message before anything is mutated.
    res = sb.run(["execute-template", template])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(message)


def test_set_value_at_path_accepts_a_glob_result_path(sb):
    """setValueAtPath treats glob's string slice result as path elements."""
    # CATCHES: glob returns a []string which setValueAtPath accepts as a
    # path: one match sets a top-level key while several matches (sorted)
    # are walked as nested path elements.
    sb.write("home", "only.txt", contents="x")
    sb.write("home", "other.txt", contents="y")
    one = sb.run(
        ["execute-template", '{{ setValueAtPath (glob "only.txt") 7 (dict) | toJson }}']
    )
    assert one.returncode == 0
    assert one.stderr == b""
    assert one.stdout == b'{"only.txt":7}'
    two = sb.run(
        ["execute-template", '{{ setValueAtPath (glob "*.txt") 7 (dict) | toJson }}']
    )
    assert two.returncode == 0
    assert two.stderr == b""
    assert two.stdout == b'{"only.txt":{"other.txt":7}}'


def test_string_slice_arguments_are_flattened(sb):
    """glob's []string results are flattened by the list-taking functions."""
    # CATCHES: toStrings, quoteList and joinPath accept glob's []string
    # result and flatten it into its elements - joinPath then joins the
    # matched paths with separators rather than stringifying the slice.
    sb.write("home", "only.txt", contents="x")
    sb.write("home", "other.txt", contents="y")
    res = sb.run(
        [
            "execute-template",
            '{{ toStrings (glob "*.txt") }}|'
            '{{ quoteList (glob "*.txt") }}|'
            '{{ joinPath (glob "*.txt") }}|',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'[only.txt other.txt]|["only.txt" "other.txt"]|only.txt/other.txt|'


def test_int_slice_arguments_are_stringified(sb):
    """sprig's until returns an int slice that the list helpers flatten."""
    # CATCHES: quoteList stringifies each element of a []int (so until 3
    # becomes three quoted strings) and joinPath joins them, while the
    # []any-typed outputList rejects the []int with a type error.
    res = sb.run(
        [
            "execute-template",
            '{{ quoteList (until 3) }}|{{ joinPath (until 3) }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'["0" "1" "2"]|0/1/2'
    typed = sb.run(["execute-template", '{{ outputList "echo" (until 3) }}'])
    assert typed.returncode == 1
    assert typed.stdout == b""
    assert typed.stderr.endswith(
        b"wrong type for value; expected []interface {}; got []int\n"
    )


def test_nested_list_arguments_are_flattened(sb):
    """Nested lists are flattened when converted to string slices."""
    # CATCHES: outputList, toStrings, quoteList and shellQuoteList all
    # flatten nested list arguments into their elements (echo receives a,
    # b and c as separate arguments) instead of stringifying the inner
    # list.
    res = sb.run(
        [
            "execute-template",
            '{{ outputList "echo" (list "a" (list "b" "c")) }}'
            '{{ toStrings (list "a" (list "b" "c")) }}|'
            '{{ quoteList (list "a" (list "b" "c")) }}|'
            '{{ shellQuoteList (list "a b" (list "c")) }}',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"a b c\n[a b c]|[\"a\" \"b\" \"c\"]|['a b' c]"


def test_quote_and_squote_skip_nil_arguments(sb):
    """quote/squote drop nil elements instead of rendering them."""
    # CATCHES: a nil element (the literal nil or fromJson null) is skipped
    # entirely by both quoting functions, so only the remaining arguments
    # appear in the output.
    res = sb.run(
        [
            "execute-template",
            '[{{ quote nil "a" }}]|[{{ squote (fromJson "null") "b" }}]',
        ]
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'["a"]|[\'b\']'


def test_look_path_missing_slash_path_and_directory(sb):
    """lookPath maps a missing slash path to "" but errors on a directory."""
    # CATCHES: an argument containing a slash is stat'ed directly rather
    # than searched in PATH - a missing one yields the empty string while
    # an existing directory is a hard template error carrying exec's
    # "is a directory" message.
    missing = sb.run(["execute-template", '{{ lookPath "no/such/file" }}|'])
    assert missing.returncode == 0
    assert missing.stderr == b""
    assert missing.stdout == b"|"
    directory = sb.run(["execute-template", '{{ lookPath "%s" }}' % sb.home])
    assert directory.returncode == 1
    assert directory.stdout == b""
    assert directory.stderr.endswith(
        b'error calling lookPath: exec: "%s": is a directory\n'
        % str(sb.home).encode()
    )


def test_stat_functions_error_when_a_component_is_a_file(sb):
    """stat/lstat/isExecutable fail when a path component is a regular file."""
    # CATCHES: a trailing component under a regular file fails with ENOTDIR
    # which is not fs.ErrNotExist, so instead of nil/false the functions
    # raise a template error naming the underlying syscall operation (stat
    # for stat and isExecutable, lstat for lstat).
    sb.write("f.txt", contents="data")
    stat = sb.run(["execute-template", '{{ stat "f.txt/x" }}'])
    assert stat.returncode == 1
    assert stat.stdout == b""
    assert stat.stderr.endswith(b"error calling stat: stat f.txt/x: not a directory\n")
    lstat = sb.run(["execute-template", '{{ lstat "f.txt/x" }}'])
    assert lstat.returncode == 1
    assert lstat.stdout == b""
    assert lstat.stderr.endswith(b"error calling lstat: lstat f.txt/x: not a directory\n")
    is_executable = sb.run(["execute-template", '{{ isExecutable "f.txt/x" }}'])
    assert is_executable.returncode == 1
    assert is_executable.stdout == b""
    assert is_executable.stderr.endswith(
        b"error calling isExecutable: stat f.txt/x: not a directory\n"
    )


@pytest.mark.parametrize("function", ["glob", "globCaseInsensitive"])
def test_glob_invalid_pattern_is_an_error(sb, function):
    """glob and globCaseInsensitive reject syntactically invalid patterns."""
    # CATCHES: an unterminated character class fails with doublestar's bare
    # "syntax error in pattern" message (no pattern detail), for both the
    # case-sensitive and the case-insensitive variant.
    res = sb.run(["execute-template", '{{ %s "[" }}' % function])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling %s: syntax error in pattern\n" % function.encode()
    )


def test_to_string_uses_the_value_stringer_for_time_values(sb):
    """toString renders non-builtin types through their String method."""
    # CATCHES: anyToString's fmt.Stringer branch — a re-implementation that
    # only understands string/number/bool values cannot render a time.Time
    # produced by sprig's toDate.
    res = sb.run(
        [
            "execute-template",
            '{{ toString (toDate "2006-01-02 15:04:05" "2021-03-05 12:34:56") }}',
        ],
        env={"TZ": "UTC"},
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"2021-03-05 12:34:56 +0000 UTC"


def test_to_date_with_an_unparseable_value_returns_the_zero_time(sb):
    """sprig toDate swallows parse errors and yields the zero time."""
    # CATCHES: a bad layout/value pair still renders (no template error) as
    # time.Time's zero value instead of aborting the template.
    res = sb.run(
        ["execute-template", '{{ toString (toDate "bogus" "x") }}'],
        env={"TZ": "UTC"},
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"0001-01-01 00:00:00 +0000 UTC"


def test_stringer_values_flow_through_stringifying_functions(sb):
    """Time values pass through every anyToString-based helper as text."""
    # CATCHES: quote/squote/joinPath/toStrings/quoteList/shellQuoteList all
    # flatten a fmt.Stringer value to its String() text (quoting it verbatim,
    # spaces and all) before joining or serializing.
    template = (
        '{{ $t := toDate "2006-01-02" "2021-03-05" }}'
        "{{ quote $t }}|{{ squote $t }}|"
        '{{ joinPath "x" $t }}|'
        "{{ toStrings (list $t 7) | toJson }}|"
        "{{ quoteList (list $t) | toJson }}|"
        "{{ shellQuoteList $t | toJson }}"
    )
    res = sb.run(["execute-template", template], env={"TZ": "UTC"})
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b'"2021-03-05 00:00:00 +0000 UTC"'
        b"|'2021-03-05 00:00:00 +0000 UTC'|"
        b"x/2021-03-05 00:00:00 +0000 UTC|"
        b'["2021-03-05 00:00:00 +0000 UTC","7"]|'
        b'["\\"2021-03-05 00:00:00 +0000 UTC\\""]|'
        b"[\"'2021-03-05 00:00:00 +0000 UTC'\"]"
    )


@pytest.mark.parametrize(
    "url,message",
    [
        ("http://[::1", b'parse "http://[::1": missing \']\' in host'),
        ("://bad", b'parse "://bad": missing protocol scheme'),
    ],
)
def test_get_redirected_url_unparseable_url_is_an_error(sb, url, message):
    """getRedirectedURL fails before any request when the URL cannot parse."""
    # CATCHES: the request URL is parsed eagerly, so a malformed URL aborts
    # the template with the raw net/url parse error and exit code 1 without
    # attempting any HTTP request.
    res = sb.run(["execute-template", '{{ getRedirectedURL "%s" }}' % url])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(b"error calling getRedirectedURL: " + message + b"\n")


def test_get_redirected_url_without_a_host_panics(sb):
    """A hostless URL makes getRedirectedURL die with a runtime panic."""
    # CATCHES: with a URL that has no host to dial, the caching HTTP client
    # panics inside client.Do before any request is sent (no network is
    # touched), surfacing as a nil-pointer dereference template error with
    # exit code 1 rather than a graceful http error message.
    res = sb.run(["execute-template", '{{ getRedirectedURL "not-a-url" }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling getRedirectedURL: runtime error: "
        b"invalid memory address or nil pointer dereference\n"
    )


def test_no_tty_flag_short_circuits_stdinisatty(sb):
    """--no-tty makes stdinIsATTY false and exposes .chezmoi.flags.noTTY."""
    # CATCHES: the persistent --no-tty flag is consulted before the stdin
    # type check inside stdinIsATTY, while remaining observable through the
    # .chezmoi.flags template data.
    flagged = sb.run(
        ["--no-tty", "execute-template", "{{ .chezmoi.flags.noTTY }}:{{ stdinIsATTY }}"]
    )
    assert flagged.returncode == 0
    assert flagged.stderr == b""
    assert flagged.stdout == b"true:false"
    control = sb.run(
        ["execute-template", "{{ .chezmoi.flags.noTTY }}:{{ stdinIsATTY }}"]
    )
    assert control.returncode == 0
    assert control.stderr == b""
    assert control.stdout == b"false:false"


def test_regex_find_all_empty_matches_are_rejected_as_paths(sb):
    """regexFindAll can return empty strings, which setValueAtPath rejects."""
    # CATCHES: a []string path (from regexFindAll) containing an empty match
    # fails with the emptyPathElementError, unlike glob-result paths whose
    # elements are always non-empty.
    control = sb.run(
        ["execute-template", '{{ regexFindAll "b*" "abc" -1 | toJson }}']
    )
    assert control.returncode == 0
    assert control.stderr == b""
    assert control.stdout == b'["","b",""]'
    res = sb.run(
        [
            "execute-template",
            '{{ setValueAtPath (regexFindAll "b*" "abc" -1) 1 (dict) }}',
        ]
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling setValueAtPath: empty path element at index 0\n"
    )


def test_replace_all_regex_invalid_pattern_is_an_error(sb):
    """replaceAllRegex compiles the pattern eagerly and fails on bad regex."""
    # CATCHES: regexp.MustCompile's panic is converted into a template error
    # naming replaceAllRegex, with the full regexp compile message including
    # the backquoted pattern.
    res = sb.run(["execute-template", '{{ replaceAllRegex "[" "x" "abc" }}'])
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr.endswith(
        b"error calling replaceAllRegex: regexp: Compile(`[`): "
        b"error parsing regexp: missing closing ]: `[`\n"
    )
