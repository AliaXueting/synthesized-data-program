"""The ``chezmoi generate`` command group and ``chezmoi license``.

``generate`` prints files embedded from ``assets/templates``: the install
script, the install-init-shell script (a template executed with the positional
arguments) and a git commit message rendered from the repo status.  Every
expectation below is the exact bytes recorded from ``./executable``.
"""

from __future__ import annotations

import subprocess

import pytest

from conftest import replace_home, run_chezmoi
from expected import (
    GENERATE_HELP,
    INSTALL_INIT_SHELL_SH,
    INSTALL_SH,
    LICENSE,
)

# A pinned environment for the git helper: only the standard programs, and no
# global or system git configuration that could perturb the recorded setup.
GIT_ENV = {
    "PATH": "/usr/bin:/bin",
    "GIT_CONFIG_GLOBAL": "/dev/null",
    "GIT_CONFIG_SYSTEM": "/dev/null",
}


def git(repo, *args):
    """Run git in REPO with a pinned identity; the result is returned."""
    return subprocess.run(
        ["git", "-C", str(repo), "-c", "user.email=t@example.com",
         "-c", "user.name=T", *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=GIT_ENV,
        timeout=30,
    )


def make_repo(home):
    """Create an empty git repository at the default source directory."""
    repo = home / ".local" / "share" / "chezmoi"
    repo.mkdir(parents=True)
    assert git(repo, "init", "-q").returncode == 0
    return repo


def test_license_prints_the_embedded_template(home):
    """`chezmoi license` prints the embedded MIT license text."""
    res = run_chezmoi(["license"], home=home)
    # CATCHES: the license is the embedded template from assets/templates,
    # printed verbatim (1112 bytes starting with a blank line) to stdout.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == LICENSE.encode()
    assert res.stdout.startswith(b"\n  The MIT License (MIT)\n")


def test_generate_install_sh(home):
    """`chezmoi generate install.sh` prints the embedded install script."""
    res = run_chezmoi(["generate", "install.sh"], home=home)
    # CATCHES: the script is the embedded install.sh template, printed
    # byte-for-byte; it needs no config, source state or working git tree.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == INSTALL_SH.encode()
    assert res.stdout.startswith(b"#!/bin/sh\n")


def test_generate_install_init_shell_sh(home):
    """`generate install-init-shell.sh USER` splices USER into the script."""
    res = run_chezmoi(["generate", "install-init-shell.sh", "somebody"], home=home)
    # CATCHES: the positional argument is passed to the template and appears
    # in the generated `${chezmoi} init --apply USER` line.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == INSTALL_INIT_SHELL_SH.encode()
    assert b"${chezmoi} init --apply somebody\n" in res.stdout


@pytest.mark.parametrize(
    "args,init_line",
    [
        (["some body"], b"${chezmoi} init --apply 'some body'\n"),
        (["a", "b", "c"], b"${chezmoi} init --apply a b c\n"),
        (["it's"], b"${chezmoi} init --apply 'it'\\''s'\n"),
    ],
)
def test_generate_install_init_shell_sh_quotes_arguments(args, init_line, home):
    """Positional arguments are POSIX-shell-quoted into the init line."""
    res = run_chezmoi(["generate", "install-init-shell.sh"] + args, home=home)
    # CATCHES: the template pipes .args through shellQuoteList, so arguments
    # containing spaces are single-quoted, several arguments are joined by
    # spaces, and an embedded quote uses the '\'' escape.
    assert res.returncode == 0
    assert res.stderr == b""
    assert init_line in res.stdout


def test_generate_install_init_shell_sh_requires_an_argument(home):
    """`generate install-init-shell.sh` without arguments is an error."""
    res = run_chezmoi(["generate", "install-init-shell.sh"], home=home)
    # CATCHES: the command is registered with MinimumNArgs(1), and the
    # arg-count error is a single stderr line with no usage dump.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: requires at least 1 arg(s), only received 0\n"


def test_generate_install_init_shell_sh_shell_flag(home):
    """`--shell=false` omits the trailing shell execution epilogue."""
    with_shell = run_chezmoi(["generate", "install-init-shell.sh", "somebody"], home=home)
    without = run_chezmoi(
        ["generate", "install-init-shell.sh", "--shell=false", "somebody"], home=home
    )
    # CATCHES: --shell defaults to true and appends the passwd-derived
    # `exec "${shell}"` epilogue; disabling it removes exactly those lines
    # and leaves the rest of the script unchanged.
    assert with_shell.returncode == 0
    assert with_shell.stderr == b""
    assert without.returncode == 0
    assert without.stderr == b""
    assert with_shell.stdout == INSTALL_INIT_SHELL_SH.encode()
    epilogue = with_shell.stdout.splitlines()[-3:]
    assert epilogue[0] == b""
    assert epilogue[2] == b'exec "${shell}"'
    assert without.stdout.splitlines() + epilogue == with_shell.stdout.splitlines()


def test_generate_install_init_shell_sh_package_manager(home):
    """`-p apk` splices the apk install branch into the script."""
    res = run_chezmoi(
        ["generate", "install-init-shell.sh", "-p", "apk", "somebody"], home=home
    )
    # CATCHES: the --package-manager value selects which installation branch
    # the template emits; apk adds the `${sudo}apk add chezmoi` lines while
    # the curl fallback branch remains.
    assert res.returncode == 0
    assert res.stderr == b""
    assert b"elif is_command apk; then\n\t${sudo}apk add chezmoi\n" in res.stdout
    assert b"get.chezmoi.io" in res.stdout
    assert res.stdout != INSTALL_INIT_SHELL_SH.encode()


def test_generate_install_init_shell_sh_unknown_package_manager(home):
    """An unknown `--package-manager` value is silently ignored."""
    res = run_chezmoi(
        ["generate", "install-init-shell.sh", "-p", "bogus", "somebody"], home=home
    )
    # CATCHES: no template branch matches an unknown package manager, so the
    # generated script is byte-identical to the default one.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == INSTALL_INIT_SHELL_SH.encode()


def test_generate_install_sh_rejects_arguments(home):
    """`generate install.sh extra` reports the surplus word as a command."""
    res = run_chezmoi(["generate", "install.sh", "extra"], home=home)
    # CATCHES: install.sh takes NoArgs, and cobra's validator reports the
    # leftover positional as an unknown *command* of install.sh itself.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: unknown command "extra" for "chezmoi generate install.sh"\n'


@pytest.mark.parametrize("argv", [["generate"], ["generate", "bogus"]])
def test_generate_group_prints_help(argv, home):
    """A bare or unmatched `generate` invocation prints the group help."""
    res = run_chezmoi(argv, home=home)
    # CATCHES: cobra's legacy args handling only rejects unknown subcommands
    # at the root, so `generate bogus` falls through to the group help on
    # stdout with exit 0 instead of an unknown-command error.
    assert res.returncode == 0
    assert res.stderr == b""
    assert replace_home(res.stdout, home).decode() == GENERATE_HELP


def test_generate_git_commit_message_needs_a_working_tree(home):
    """`generate git-commit-message` without a source directory fails."""
    res = run_chezmoi(["generate", "git-commit-message"], home=home)
    # CATCHES: the command runs git in the working tree, and the missing
    # default source directory surfaces as the raw chdir error on a single
    # stderr line.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: chdir %s/.local/share/chezmoi: no such file or directory\n"
        % str(home).encode()
    )


def test_generate_git_commit_message_add_line(home):
    """A staged new source file becomes an `Add <target>` line."""
    repo = make_repo(home)
    target = repo / "dot_dotfiles" / "newfile"
    target.parent.mkdir()
    target.write_text("staged content\n")
    assert git(repo, "add", "-A").returncode == 0
    res = run_chezmoi(["generate", "git-commit-message"], home=home)
    # CATCHES: the message is rendered from the embedded template over
    # `git status --porcelain=v2`; a staged `A.` entry yields `Add <path>`
    # with the `dot_` prefix translated to a literal leading dot.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"Add .dotfiles/newfile\n"


def test_generate_git_commit_message_update_and_remove_lines(home):
    """Staged modifications and deletions become Update/Remove lines."""
    repo = make_repo(home)
    target = repo / "dot_dotfiles" / "file"
    target.parent.mkdir()
    target.write_text("first\n")
    assert git(repo, "add", "-A").returncode == 0
    assert git(repo, "commit", "-qm", "initial").returncode == 0
    target.write_text("second\n")
    assert git(repo, "add", "-A").returncode == 0
    modified = run_chezmoi(["generate", "git-commit-message"], home=home)
    # CATCHES: a staged `M.` entry renders as `Update <path>` with the same
    # dot_ prefix translation as the Add line.
    assert modified.returncode == 0
    assert modified.stderr == b""
    assert modified.stdout == b"Update .dotfiles/file\n"
    assert git(repo, "commit", "-qm", "modified").returncode == 0
    assert git(repo, "rm", "-q", "dot_dotfiles/file").returncode == 0
    deleted = run_chezmoi(["generate", "git-commit-message"], home=home)
    # CATCHES: a staged deletion (`D.`) renders as `Remove <path>`.
    assert deleted.returncode == 0
    assert deleted.stderr == b""
    assert deleted.stdout == b"Remove .dotfiles/file\n"


def test_generate_git_commit_message_warns_on_untracked_only(home):
    """With only untracked files the message is empty and a warning prints."""
    repo = make_repo(home)
    tracked = repo / "dot_dotfiles" / "file"
    tracked.parent.mkdir()
    tracked.write_text("content\n")
    assert git(repo, "add", "-A").returncode == 0
    assert git(repo, "commit", "-qm", "initial").returncode == 0
    (repo / "untracked_file").write_text("not added\n")
    res = run_chezmoi(["generate", "git-commit-message"], home=home)
    # CATCHES: the template emits no message line for untracked entries but
    # warns on stderr, and the command still exits 0 with empty stdout.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: warning: untracked files\n"
