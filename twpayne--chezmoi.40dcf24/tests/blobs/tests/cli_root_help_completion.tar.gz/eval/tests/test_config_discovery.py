"""Config file discovery, format selection and validation.

``defaultConfigFile`` / ``decodeConfigFile`` / ``setEnvironmentVariables`` in
``internal/cmd/config.go`` decide which config file is read and how: the XDG
search refuses an ambiguous config directory, ``--config-format`` overrides the
file extension, semantic conflicts are rejected after decoding, ``scriptEnv``
entries are exported exactly like ``env`` entries, and a ``.chezmoiversion``
that cannot be read aborts the source state.
"""

from __future__ import annotations

from pathlib import Path

from conftest import run_chezmoi
from expected import LICENSE

# The recorded license text as exact stdout bytes.
LICENSE_BYTES = LICENSE.encode()

# The recorded bash completion script (see test_completion.py).
COMPLETION_BASH = (Path(__file__).parent / "data" / "completion.bash").read_bytes()


def write_config(tmp_path, name, text):
    """Write TEXT to a config file and return its path."""
    path = Path(tmp_path) / name
    path.write_text(text)
    return path


def test_multiple_config_files_are_an_error(tmp_path, home):
    """Two config files in one config directory abort the command."""
    config_dir = tmp_path / "xdgconf" / "chezmoi"
    config_dir.mkdir(parents=True)
    (config_dir / "chezmoi.toml").write_text('sourceDir = "/toml"\n')
    (config_dir / "chezmoi.yaml").write_text("sourceDir: /yaml\n")
    res = run_chezmoi(
        ["managed"],
        home=home,
        extra={"XDG_CONFIG_HOME": str(tmp_path / "xdgconf")},
    )
    # CATCHES: defaultConfigFile refuses a config directory holding more than
    # one chezmoi.* file, naming both candidates joined by "and", before any
    # command output; the exit status is 1 and stdout stays empty.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        "chezmoi: multiple config files: "
        f"{config_dir}/chezmoi.toml and {config_dir}/chezmoi.yaml\n"
    ).encode()


def test_three_config_files_are_listed_oxford_style(tmp_path, home):
    """Three config files are listed with an Oxford-comma series."""
    config_dir = tmp_path / "xdgconf" / "chezmoi"
    config_dir.mkdir(parents=True)
    for name in ("chezmoi.json", "chezmoi.toml", "chezmoi.yaml"):
        (config_dir / name).write_text("{}\n")
    res = run_chezmoi(
        ["managed"],
        home=home,
        extra={"XDG_CONFIG_HOME": str(tmp_path / "xdgconf")},
    )
    # CATCHES: with three candidates the error enumerates every file in the
    # format-extension order (json, toml, yaml) as an "a, b, and c" series.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        "chezmoi: multiple config files: "
        f"{config_dir}/chezmoi.json, "
        f"{config_dir}/chezmoi.toml, and "
        f"{config_dir}/chezmoi.yaml\n"
    ).encode()


def test_completion_runs_despite_multiple_config_files(tmp_path, home):
    """`completion` is doesNotRequireValidConfig and ignores the ambiguity."""
    config_dir = tmp_path / "xdgconf" / "chezmoi"
    config_dir.mkdir(parents=True)
    (config_dir / "chezmoi.toml").write_text('sourceDir = "/toml"\n')
    (config_dir / "chezmoi.yaml").write_text("sourceDir: /yaml\n")
    res = run_chezmoi(
        ["completion", "bash"],
        home=home,
        extra={"XDG_CONFIG_HOME": str(tmp_path / "xdgconf")},
    )
    # CATCHES: the completion command swallows config discovery errors, so it
    # still prints the full recorded script even though `managed` aborts on
    # the same config directory.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == COMPLETION_BASH


def test_config_format_yaml_parses_an_unknown_extension(tmp_path, home):
    """--config-format yaml reads YAML content from a .conf-named file."""
    source = tmp_path / "source"
    (source / "dot_vim").mkdir(parents=True)
    (source / "dot_vim" / "vimrc").write_text("syntax on\n")
    config = write_config(tmp_path, "config.conf", f"sourceDir: {source}\n")
    res = run_chezmoi(
        ["-c", str(config), "--config-format", "yaml", "managed"],
        home=home,
    )
    # CATCHES: --config-format yaml makes decodeConfigFile parse the file as
    # YAML regardless of its .conf extension, so the sourceDir it defines is
    # honored and managed lists the source state below it.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b".vim\n.vim/vimrc\n"


def test_unknown_config_extension_without_format_flag_is_an_error(tmp_path, home):
    """Without --config-format a non-format extension is a hard error."""
    config = write_config(tmp_path, "config.conf", 'sourceDir = "/nowhere"\n')
    res = run_chezmoi(["-c", str(config), "managed"], home=home)
    # CATCHES: decodeConfigFile derives the format from the file extension
    # only, so an extension it does not know fails with `unknown format`
    # wrapped in `invalid config` and the file path.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        f"chezmoi: invalid config: {config}: .conf: unknown format\n"
    ).encode()


def test_commit_message_template_and_file_are_mutually_exclusive(tmp_path, home):
    """Setting both git commit message keys is rejected after decoding."""
    config = write_config(
        tmp_path,
        "conflict.toml",
        "[git]\n"
        'commitMessageTemplate = "x"\n'
        'commitMessageTemplateFile = "y"\n',
    )
    res = run_chezmoi(["-c", str(config), "managed"], home=home)
    # CATCHES: decodeConfigFile rejects a config that names both a commit
    # message template and a template file with `cannot specify both ...`,
    # wrapped in `invalid config` and the config path.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        f"chezmoi: invalid config: {config}: cannot specify both "
        "git.commitMessageTemplate and git.commitMessageTemplateFile\n"
    ).encode()


def test_scriptenv_is_exported_to_hook_commands(tmp_path, home):
    """`[scriptEnv]` entries are exported like `[env]` entries."""
    config = write_config(
        tmp_path,
        "scriptenv.toml",
        '[scriptEnv]\nSVAR = "script-value"\n'
        '[hooks.license.pre]\ncommand = "printenv"\nargs = ["SVAR"]\n',
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: setEnvironmentVariables exports the scriptEnv map exactly like
    # the env map, so a hook child observes the variable before the license
    # text is printed.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"script-value\n" + LICENSE_BYTES


def test_chezmoiversion_directory_is_a_read_error(tmp_path, home):
    """A .chezmoiversion that is a directory aborts with a read error."""
    source = tmp_path / "source"
    source.mkdir()
    (source / ".chezmoiversion").mkdir()
    res = run_chezmoi(["-S", str(source), "managed"], home=home)
    # CATCHES: checkVersion reads .chezmoiversion before building the source
    # state and surfaces a non-NotExist read failure verbatim as
    # `read <path>: is a directory`, unlike a missing file which is ignored.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        f"chezmoi: read {source}/.chezmoiversion: is a directory\n"
    ).encode()
