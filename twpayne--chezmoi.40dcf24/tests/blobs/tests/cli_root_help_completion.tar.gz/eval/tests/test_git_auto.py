"""The ``[git] autoAdd`` / ``autoCommit`` / ``autoPush`` configuration.

``persistentPostRunRootE`` in ``internal/cmd/config.go`` runs the automatic git
commands after any command annotated ``modifiesSourceDirectory`` (here
``add``): ``gitAdd`` stages everything and parses the status,
``gitCommit`` renders the commit message from the default template and
commits it, and ``gitPush`` pushes -- failing when no remote is configured.
The ``git-auto-commit`` and ``git-auto-push`` hooks bracket those commands.
Every expectation below was recorded from ``./executable``.
"""

from __future__ import annotations

import re
import subprocess

import pytest

from conftest import run_chezmoi

# A pinned environment for every git invocation (chezmoi's own git children
# included): only the standard programs and no user or system git config.
GIT_ENV = {
    "PATH": "/usr/bin:/bin",
    "GIT_CONFIG_GLOBAL": "/dev/null",
    "GIT_CONFIG_SYSTEM": "/dev/null",
}


def git(repo, *args):
    """Run git in REPO with a pinned environment; the result is returned."""
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=GIT_ENV,
        timeout=30,
    )


@pytest.fixture()
def git_home(home):
    """A HOME whose source directory is a git repo with a local identity."""
    repo = home / ".local" / "share" / "chezmoi"
    (home / ".config" / "chezmoi").mkdir(parents=True)
    repo.mkdir(parents=True)
    assert git(repo, "init", "-q").returncode == 0
    assert git(repo, "config", "user.email", "t@example.com").returncode == 0
    assert git(repo, "config", "user.name", "T").returncode == 0
    return home, repo


def write_git_config(home, text):
    """Write the default config file with the given [git] settings."""
    path = home / ".config" / "chezmoi" / "chezmoi.toml"
    path.write_text(text)
    return path


def normalize_hash(data):
    """Replace the commit hashes git prints with a fixed marker."""
    return re.sub(rb"[0-9a-f]{7,40}", b"HASH", data)


def test_auto_add_and_commit_create_a_commit(git_home):
    """``autoAdd`` + ``autoCommit`` commit the added source file."""
    home, repo = git_home
    write_git_config(home, "[git]\nautoAdd = true\nautoCommit = true\n")
    (home / ".newfile").write_text("hello\n")
    res = run_chezmoi(["add", ".newfile"], home=home, cwd=home, extra=GIT_ENV)
    # CATCHES: gitAdd stages the source directory and gitCommit commits with
    # the default commit message template ("Add <target>"), with git's own
    # progress output passed through to stdout; the working tree ends clean.
    assert res.returncode == 0
    assert res.stderr == b""
    assert normalize_hash(res.stdout) == (
        b"[master (root-commit) HASH] Add .newfile\n"
        b" 1 file changed, 1 insertion(+)\n"
        b" create mode 100644 dot_newfile\n"
    )
    assert git(repo, "log", "--pretty=format:%s").stdout == b"Add .newfile"
    assert git(repo, "status", "--porcelain").stdout == b""


def test_auto_commit_skips_an_empty_status(git_home):
    """Nothing new to commit means no new commit and no output."""
    home, repo = git_home
    write_git_config(home, "[git]\nautoAdd = true\nautoCommit = true\n")
    (home / ".newfile").write_text("hello\n")
    assert run_chezmoi(["add", ".newfile"], home=home, cwd=home, extra=GIT_ENV).returncode == 0
    res = run_chezmoi(["add", ".newfile"], home=home, cwd=home, extra=GIT_ENV)
    # CATCHES: gitCommit returns early when the parsed status is empty, so the
    # second run prints nothing and leaves exactly one commit behind.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert len(git(repo, "log", "--oneline").stdout.splitlines()) == 1


def test_auto_push_without_a_remote_fails_after_committing(git_home):
    """``autoPush`` commits first and then fails on the missing remote."""
    home, repo = git_home
    write_git_config(
        home, "[git]\nautoAdd = true\nautoCommit = true\nautoPush = true\n"
    )
    (home / ".other").write_text("second\n")
    res = run_chezmoi(["add", ".other"], home=home, cwd=home, extra=GIT_ENV)
    # CATCHES: the commit is created before gitPush runs `git push`, whose
    # failure is reported as `git: exit status 128` after git's own message,
    # and the commit stays in the repository.
    assert res.returncode == 1
    assert normalize_hash(res.stdout) == (
        b"[master (root-commit) HASH] Add .other\n"
        b" 1 file changed, 1 insertion(+)\n"
        b" create mode 100644 dot_other\n"
    )
    assert res.stderr == (
        b"fatal: No configured push destination.\n"
        b"Either specify the URL from the command-line or configure a remote "
        b"repository using\n"
        b"\n"
        b"    git remote add <name> <url>\n"
        b"\n"
        b"and then push using the remote name\n"
        b"\n"
        b"    git push <name>\n"
        b"\n"
        b"chezmoi: git: exit status 128\n"
    )
    assert git(repo, "log", "--pretty=format:%s").stdout == b"Add .other"


def test_git_auto_commit_hooks_bracket_the_commit(git_home):
    """The ``git-auto-commit`` pre and post hooks run around the commit."""
    home, repo = git_home
    write_git_config(
        home,
        "[git]\nautoAdd = true\nautoCommit = true\n"
        '[hooks."git-auto-commit".pre]\ncommand = "echo"\nargs = ["HOOK-PRE"]\n'
        '[hooks."git-auto-commit".post]\ncommand = "echo"\nargs = ["HOOK-POST"]\n',
    )
    (home / ".fourth").write_text("fourth\n")
    res = run_chezmoi(["add", ".fourth"], home=home, cwd=home, extra=GIT_ENV)
    # CATCHES: gitCommit runs the git-auto-commit hooks by that literal hook
    # name, before and after the `git commit` child process.
    assert res.returncode == 0
    assert res.stderr == b""
    assert normalize_hash(res.stdout) == (
        b"HOOK-PRE\n"
        b"[master (root-commit) HASH] Add .fourth\n"
        b" 1 file changed, 1 insertion(+)\n"
        b" create mode 100644 dot_fourth\n"
        b"HOOK-POST\n"
    )
