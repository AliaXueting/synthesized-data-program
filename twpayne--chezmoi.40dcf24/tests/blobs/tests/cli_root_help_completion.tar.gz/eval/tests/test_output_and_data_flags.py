"""The ``--output`` and ``--override-data`` flags, and two template funcs.

``writeOutput`` in ``internal/cmd/config.go`` implements ``-o`` (a literal
``-`` names a file, and an existing file's mode is narrowed to the write
permission); ``newSourceState`` merges ``--override-data`` /
``--override-data-file`` over ``.chezmoidata`` as priority template data; the
``completion`` template function exposes the completion generator to
templates; and the ``output`` template function runs external commands,
reporting failures through ``cmdOutputError`` from ``internal/cmd/errors.go``
(shell-quoted command, exit status, and captured output).
"""

from __future__ import annotations

import json
import stat
from pathlib import Path

import pytest

from conftest import run_chezmoi
from expected import LICENSE

# The recorded license text as exact stdout bytes.
LICENSE_BYTES = LICENSE.encode()

# The recorded bash completion script (see test_completion.py).
COMPLETION_BASH = (Path(__file__).parent / "data" / "completion.bash").read_bytes()


@pytest.fixture()
def source(tmp_path):
    """A source state whose .chezmoidata.yml defines one key."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    (source_dir / ".chezmoidata.yml").write_text("foo: original\n")
    return source_dir


def run_data(source, home, *args):
    """Run `chezmoi -S SOURCE data ARGS...` and return the result."""
    return run_chezmoi(["-S", str(source), "data", *args], home=home)


def test_output_dash_writes_a_file_named_dash(tmp_path, home):
    """`-o -` names a literal dash file instead of stdout."""
    res = run_chezmoi(["license", "-o", "-"], home=home, cwd=tmp_path)
    # CATCHES: the -o flag value is made absolute against the working
    # directory before the stdout comparison, so `-` is an ordinary file name
    # in the cwd and stdout itself stays empty.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "-").read_bytes() == LICENSE_BYTES


def test_output_narrows_an_existing_file_permissions(tmp_path, home):
    """-o chmods a too-permissive existing file down to the write mode."""
    target = tmp_path / "out"
    target.write_text("stale contents\n")
    target.chmod(0o777)
    res = run_chezmoi(["license", "-o", str(target)], home=home)
    # CATCHES: writeOutput stats the output file and removes any permission
    # bits beyond the 0o666 it writes with, so the previous 0o777 is narrowed
    # to exactly 0o666 (an absolute chmod, not masked by the umask).
    assert res.returncode == 0
    assert res.stdout == b""
    assert target.read_bytes() == LICENSE_BYTES
    assert stat.S_IMODE(target.stat().st_mode) == 0o666


def test_output_keeps_stricter_existing_permissions(tmp_path, home):
    """-o never widens the permissions of an existing file."""
    target = tmp_path / "out"
    target.write_text("stale contents\n")
    target.chmod(0o600)
    res = run_chezmoi(["license", "-o", str(target)], home=home)
    # CATCHES: the narrowing only clears bits outside the write permission,
    # so a 0o600 file keeps its mode instead of being raised to 0o666.
    assert res.returncode == 0
    assert target.read_bytes() == LICENSE_BYTES
    assert stat.S_IMODE(target.stat().st_mode) == 0o600


def test_override_data_flag_overrides_chezmoidata(source, home):
    """--override-data replaces a .chezmoidata.yml value."""
    baseline = run_data(source, home)
    overridden = run_data(source, home, "--override-data", '{"foo": "overridden"}')
    # CATCHES: --override-data is parsed as JSON and recursively merged over
    # the source state's data with priority, so the same key that
    # .chezmoidata.yml defines is replaced in the `data` dump.
    assert baseline.returncode == 0
    assert overridden.returncode == 0
    assert overridden.stderr == b""
    assert json.loads(baseline.stdout)["foo"] == "original"
    assert json.loads(overridden.stdout)["foo"] == "overridden"


def test_override_data_file_merges_over_chezmoidata(source, home, tmp_path):
    """--override-data-file reads a YAML file and merges it the same way."""
    override = tmp_path / "override.yaml"
    override.write_text("foo: from-file\n")
    res = run_data(source, home, "--override-data-file", str(override))
    # CATCHES: the override file's format follows its own extension, so a
    # .yaml file is parsed as YAML and its keys override .chezmoidata.yml.
    assert res.returncode == 0
    assert res.stderr == b""
    assert json.loads(res.stdout)["foo"] == "from-file"


def test_override_data_rejects_invalid_json(source, home):
    """--override-data with non-JSON content fails with the parse error."""
    res = run_data(source, home, "--override-data", "not json")
    # CATCHES: the flag value is unmarshalled with encoding/json, whose
    # error text (here choking on the `o` after starting `null`) reaches
    # stderr verbatim as a single `chezmoi:` line.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: invalid character 'o' in literal null (expecting 'u')\n"
    )


def test_override_data_file_missing_is_an_error(source, home, tmp_path):
    """--override-data-file with a nonexistent path fails with the open error."""
    missing = tmp_path / "nope.yaml"
    res = run_data(source, home, "--override-data-file", str(missing))
    # CATCHES: the override file is read before the source state, so a
    # missing file aborts with the raw `open <path>: no such file or
    # directory` error and no data dump.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == f"chezmoi: open {missing}: no such file or directory\n".encode()


def test_override_data_file_rejects_invalid_yaml(source, home, tmp_path):
    """A malformed override file fails with the YAML parser's annotation."""
    bad = tmp_path / "bad.yaml"
    bad.write_text("foo: [unclosed\n")
    res = run_data(source, home, "--override-data-file", str(bad))
    # CATCHES: the YAML error carries the parser's source annotation (the
    # offending line with a caret under the token position) after the
    # `chezmoi:` prefix, on its own lines.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: [1:6] sequence end token ']' not found\n"
        b">  1 | foo: [unclosed\n"
        b"            ^\n"
        b"\n"
    )


def test_completion_template_function_prints_the_script(home):
    """The `completion` template function generates the same script."""
    res = run_chezmoi(
        ["execute-template", '{{ completion "bash" }}'],
        home=home,
    )
    # CATCHES: persistentPreRunRootE registers a `completion` template
    # function backed by the same generator as the completion command, so a
    # template gets the byte-identical bash script.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == COMPLETION_BASH


def test_completion_template_function_rejects_unknown_shells(home):
    """The `completion` template function rejects unknown shell names."""
    res = run_chezmoi(
        ["execute-template", '{{ completion "bogus" }}'],
        home=home,
    )
    # CATCHES: the template function wraps the completion generator's
    # `unsupported shell` error in the standard template error location
    # (`arg1:1:3` and the calling expression).
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" at '
        b'<completion "bogus">: error calling completion: bogus: unsupported shell\n'
    )


def test_output_template_function_runs_a_command(home):
    """The `output` template function returns a command's stdout."""
    res = run_chezmoi(
        ["execute-template", '{{ output "echo" "hello" "world" }}'],
        home=home,
    )
    # CATCHES: `output` runs the named command with its arguments and the
    # template evaluates to the captured stdout bytes.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"hello world\n"


def test_output_template_function_passes_stderr_through(home):
    """A command's stderr goes to chezmoi's stderr, not into the template."""
    res = run_chezmoi(
        ["execute-template", '{{ output "sh" "-c" "echo to-stderr >&2; echo to-stdout" }}'],
        home=home,
    )
    # CATCHES: the child's stderr is wired to chezmoi's own stderr while
    # only stdout is captured for the template value.
    assert res.returncode == 0
    assert res.stdout == b"to-stdout\n"
    assert res.stderr == b"to-stderr\n"


def test_output_template_function_includes_output_on_failure(home):
    """A failing command's partial output is appended to the error."""
    res = run_chezmoi(
        ["execute-template", '{{ output "sh" "-c" "echo partial; exit 3" }}'],
        home=home,
    )
    # CATCHES: cmdOutputError formats a failure as the shell-quoted command
    # (arguments containing spaces single-quoted), the exit status, and the
    # captured stdout on following lines.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" at '
        b'<output "sh" "-c" "echo partial; exit 3">: error calling output: '
        b"/usr/bin/sh -c 'echo partial; exit 3': exit status 3\n"
        b"partial\n"
        b"\n"
    )


def test_output_template_function_failure_without_output(home):
    """A failing command with no output errors without an output section."""
    res = run_chezmoi(["execute-template", "{{ output \"false\" }}"], home=home)
    # CATCHES: when the command produced no stdout, cmdOutputError's message
    # is just the shell-quoted command and the exit status.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" at '
        b'<output "false">: error calling output: /usr/bin/false: exit status 1\n'
    )


def test_output_template_function_command_not_found(home):
    """A command missing from PATH is reported with the exec error."""
    res = run_chezmoi(
        ["execute-template", "{{ output \"no-such-cmd-xyz\" }}"],
        home=home,
    )
    # CATCHES: the command name is not resolved to a path when lookup fails,
    # so the error names the argument as given followed by the exec failure.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" at '
        b'<output "no-such-cmd-xyz">: error calling output: '
        b'no-such-cmd-xyz: exec: "no-such-cmd-xyz": '
        b"executable file not found in $PATH\n"
    )
