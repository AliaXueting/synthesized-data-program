"""Output errors of the marshalling commands.

``marshal`` in ``internal/cmd/config.go`` renders the structured output of
``list``/``dump`` and hands it to ``writeOutput``, which opens the ``-o``
path with ``os.OpenFile``.  A path that cannot be opened is reported as a
single ``chezmoi:`` line on stderr with the raw error, and the command exits
1 without a usage dump.  Every expectation below was recorded from
``./executable``.
"""

from __future__ import annotations

from conftest import run_chezmoi


def make_source_state(home):
    """Create a source state with a single file target."""
    source = home / ".local" / "share" / "chezmoi"
    source.mkdir(parents=True)
    (source / "dot_bashrc").write_text("x\n")
    return source


def test_list_output_flag_into_a_missing_directory(home):
    """``list --format json -o`` into a missing directory fails cleanly."""
    make_source_state(home)
    target = "/no/such/dir/out.json"
    res = run_chezmoi(["list", "--format", "json", "-o", target], home=home)
    # CATCHES: marshal's writeOutput surfaces the raw os.Open error of the -o
    # path, prefixed by chezmoi and with no usage dump, exiting 1.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: open " + target.encode() + b": no such file or directory\n"
    )


def test_list_output_flag_to_a_directory(home):
    """``-o`` naming an existing directory fails with `is a directory`."""
    make_source_state(home)
    res = run_chezmoi(["list", "--format", "json", "-o", str(home)], home=home)
    # CATCHES: opening a directory for writing fails with the `is a directory`
    # error, again as a single stderr line and exit code 1.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: open " + str(home).encode() + b": is a directory\n"
    )
