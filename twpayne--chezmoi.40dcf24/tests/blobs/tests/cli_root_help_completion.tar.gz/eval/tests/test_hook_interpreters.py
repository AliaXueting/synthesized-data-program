"""Hook scripts run through the configured interpreter.

``runHook`` in ``internal/cmd/config.go`` resolves a hook's ``script`` by its
extension: an extension present in the ``[interpreters]`` map (``py`` maps to
``python3`` by default) runs the script through that interpreter with the
hook's ``args`` appended, anything else is executed directly from the working
directory.  The hook always runs in the home directory.  Every expectation
below was recorded from ``./executable``.
"""

from __future__ import annotations

from conftest import run_chezmoi
from expected import LICENSE


def write_config(home, text):
    """Write the default config file and return its path."""
    path = home / ".config" / "chezmoi" / "chezmoi.toml"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path


def test_a_python_hook_script_runs_through_python3(home):
    """A ``.py`` hook script is executed by the default python3 interpreter."""
    (home / "hook.py").write_text(
        "import sys, os\n"
        "print('PY argv:', sys.argv[1:], 'cwd:', os.getcwd())\n"
    )
    write_config(
        home,
        '[hooks.license.pre]\nscript = "hook.py"\nargs = ["a1", "a2"]\n',
    )
    res = run_chezmoi(["license"], home=home)
    # CATCHES: runHook looks the script's extension up in the interpreters map,
    # so hook.py runs as `python3 hook.py a1 a2` in the home directory rather
    # than being executed directly (which would need the exec bit).
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout.startswith(
        f"PY argv: ['a1', 'a2'] cwd: {home}\n".encode()
    )
    assert res.stdout.endswith(LICENSE.encode())


def test_a_custom_interpreter_is_used_for_a_hook_script(home):
    """A custom ``[interpreters]`` entry runs the script with its args."""
    (home / "hook.mytool").write_text("import sys\nprint('TOOL argv:', sys.argv[1:])\n")
    write_config(
        home,
        "[interpreters]\n"
        'mytool = { command = "python3", args = ["-B"] }\n'
        '[hooks.license.pre]\nscript = "hook.mytool"\nargs = ["x"]\n',
    )
    res = run_chezmoi(["license"], home=home)
    # CATCHES: the interpreter is taken from the config's [interpreters] map
    # keyed by the script extension, and the interpreter's own args come before
    # the script name and the hook's args.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout.startswith(b"TOOL argv: ['x']\n")
    assert res.stdout.endswith(LICENSE.encode())
