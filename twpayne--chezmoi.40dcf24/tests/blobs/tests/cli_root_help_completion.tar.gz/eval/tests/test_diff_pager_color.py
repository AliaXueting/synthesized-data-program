"""Diff output plumbing: the ``--color``, pager and persistent state flags.

``persistentPreRunRootE`` in ``internal/cmd/config.go`` wires the diff writer
for any ``outputsDiff`` command: ``getDiffPager``/``getDiffPagerCmd`` start the
configured pager (``--no-pager`` disables it), ``colorAutoFunc`` resolves
``--color`` (an explicit value beats ``NO_COLOR``, ``auto`` is off for pipes),
``persistentStateFile`` locates the bolt database (``--persistent-state``, the
config directory, or next to ``-c``), and ``targetRelPathsBySourcePath``
implements the ``--source-path`` target selector.  The diff command is the
vehicle; every expectation is a root-flag effect, recorded byte-exactly.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from conftest import run_chezmoi

# `chezmoi diff` with the fixture below: a modified .file and a new .second.
DIFF_PLAIN = (
    b"diff --git a/.file b/.file\n"
    b"index e70bb2627ffdafc80821b7b0c55d62d7e1090bea"
    b"..014fd71bde5393ad8b79305d1af6ec907557f828 100644\n"
    b"--- a/.file\n"
    b"+++ b/.file\n"
    b"@@ -1 +1 @@\n"
    b"-old contents\n"
    b"+new contents\n"
    b"diff --git a/.second b/.second\n"
    b"new file mode 100644\n"
    b"index 0000000000000000000000000000000000000000"
    b"..1c59427adc4b205a270d8f810310394962e79a8b\n"
    b"--- /dev/null\n"
    b"+++ b/.second\n"
    b"@@ -0,0 +1 @@\n"
    b"+second file\n"
)

# The same diff with --color=true (git-style ANSI attributes).
DIFF_COLORED = (
    b"\x1b[1mdiff --git a/.file b/.file\n"
    b"index e70bb2627ffdafc80821b7b0c55d62d7e1090bea"
    b"..014fd71bde5393ad8b79305d1af6ec907557f828 100644\n"
    b"--- a/.file\n"
    b"+++ b/.file\x1b[m\n"
    b"\x1b[36m@@ -1 +1 @@\x1b[m\n"
    b"\x1b[31m-old contents\x1b[m\n"
    b"\x1b[32m+new contents\x1b[m\n"
    b"\x1b[1mdiff --git a/.second b/.second\n"
    b"new file mode 100644\n"
    b"index 0000000000000000000000000000000000000000"
    b"..1c59427adc4b205a270d8f810310394962e79a8b\n"
    b"--- /dev/null\n"
    b"+++ b/.second\x1b[m\n"
    b"\x1b[36m@@ -0,0 +1 @@\x1b[m\n"
    b"\x1b[32m+second file\x1b[m\n"
)

# The same diff after passing through the `tr a-z A-Z` pager.
DIFF_UPPERED = (
    b"DIFF --GIT A/.FILE B/.FILE\n"
    b"INDEX E70BB2627FFDAFC80821B7B0C55D62D7E1090BEA"
    b"..014FD71BDE5393AD8B79305D1AF6EC907557F828 100644\n"
    b"--- A/.FILE\n"
    b"+++ B/.FILE\n"
    b"@@ -1 +1 @@\n"
    b"-OLD CONTENTS\n"
    b"+NEW CONTENTS\n"
    b"DIFF --GIT A/.SECOND B/.SECOND\n"
    b"NEW FILE MODE 100644\n"
    b"INDEX 0000000000000000000000000000000000000000"
    b"..1C59427ADC4B205A270D8F810310394962E79A8B\n"
    b"--- /DEV/NULL\n"
    b"+++ B/.SECOND\n"
    b"@@ -0,0 +1 @@\n"
    b"+SECOND FILE\n"
)

# Only the .second part of the fixture diff.
DIFF_SECOND = DIFF_PLAIN[DIFF_PLAIN.index(b"diff --git a/.second") :]


@pytest.fixture()
def source(tmp_path, home):
    """A source state with two files, one of which exists in the destination."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    (source_dir / "dot_file").write_text("new contents\n")
    (source_dir / "dot_second").write_text("second file\n")
    (home / ".file").write_text("old contents\n")
    # Pin every mode: chezmoi derives target modes from the source file mode
    # and the process umask, and the diff records those modes.
    (source_dir / "dot_file").chmod(0o644)
    (source_dir / "dot_second").chmod(0o644)
    (home / ".file").chmod(0o644)
    return source_dir


def run_diff(source, home, *args, extra=None):
    """Run `chezmoi -S SOURCE diff ARGS...` with a pinned umask."""
    merged = {"SHELL": "/bin/sh"}
    if extra:
        merged.update(extra)
    return run_chezmoi(
        ["-S", str(source), "diff", *args],
        home=home,
        extra=merged,
        umask=0o022,
    )


def write_config(tmp_path, name, text):
    """Write TEXT to a config file and return its path."""
    path = Path(tmp_path) / name
    path.write_text(text)
    return path


def run_diff_config(config, source, home, *args, extra=None):
    """Run `chezmoi -c CONFIG -S SOURCE diff ARGS...` with a pinned umask."""
    merged = {"SHELL": "/bin/sh"}
    if extra:
        merged.update(extra)
    return run_chezmoi(
        ["-c", str(config), "-S", str(source), "diff", *args],
        home=home,
        extra=merged,
        umask=0o022,
    )


def test_diff_prints_the_unified_diff(source, home):
    """Without flags the builtin diff writes plain bytes to stdout."""
    res = run_diff(source, home)
    # CATCHES: the default is the builtin git-style diff, uncolored, on
    # stdout with no pager in between and exit status 0.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_PLAIN


def test_color_flag_colorizes_the_diff(source, home):
    """--color=true adds git-style ANSI attributes to the diff."""
    res = run_diff(source, home, "--color=true")
    # CATCHES: an explicit --color=true turns on the color encoder, which
    # bolds the headers, colors the hunk line cyan and the -/+ lines red and
    # green, and resets each attribute with ESC[m.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_COLORED


def test_color_auto_is_off_when_stdout_is_a_pipe(source, home):
    """--color=auto stays uncolored because stdout is not a terminal."""
    res = run_diff(source, home, "--color=auto")
    # CATCHES: colorAutoFunc resolves auto by testing whether stdout is a
    # terminal, so a piped run produces the plain bytes despite auto being
    # the documented default.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_PLAIN


def test_explicit_color_wins_over_the_no_color_variable(source, home):
    """NO_COLOR does not undo an explicit --color=true."""
    res = run_diff(source, home, "--color=true", extra={"NO_COLOR": "1"})
    # CATCHES: NO_COLOR only feeds the auto resolution, so an explicitly set
    # --color=true still colorizes the diff when NO_COLOR is present.
    assert res.returncode == 0
    assert res.stdout == DIFF_COLORED


def test_no_color_disables_auto_color(source, home):
    """NO_COLOR turns --color=auto off even before the terminal test."""
    res = run_diff(source, home, "--color=auto", extra={"NO_COLOR": "1"})
    # CATCHES: colorAutoFunc checks NO_COLOR first and returns false without
    # looking at stdout, so the output is the plain diff.
    assert res.returncode == 0
    assert res.stdout == DIFF_PLAIN


def test_configured_pager_filters_the_diff(source, home, tmp_path):
    """A pager command string is run through the shell with the diff on stdin."""
    config = write_config(tmp_path, "tr.toml", 'pager = "tr a-z A-Z"\n')
    res = run_diff_config(config, source, home)
    # CATCHES: a pager containing spaces is executed via the user's shell
    # (`sh -c 'tr a-z A-Z'`) and the diff is piped through it, so stdout is
    # the diff uppercased, proving the data flowed stdin->pager->stdout.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_UPPERED


def test_no_pager_flag_disables_the_configured_pager(source, home, tmp_path):
    """--no-pager writes the diff directly despite a configured pager."""
    config = write_config(tmp_path, "tr.toml", 'pager = "tr a-z A-Z"\n')
    res = run_diff_config(config, source, home, "--no-pager")
    # CATCHES: getDiffPager returns no pager at all when --no-pager is set,
    # so the configured `tr` never runs and the raw diff reaches stdout.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_PLAIN


def test_diff_pager_flag_overrides_the_config_file(source, home, tmp_path):
    """`diff --pager` beats the pager configured in the config file."""
    config = write_config(
        tmp_path, "both.toml", 'pager = "tr a-z A-Z"\n[diff]\npager = "cat"\n'
    )
    res = run_diff_config(
        config, source, home, "--pager", "tr a-z A-Z"
    )
    # CATCHES: the --pager flag sets Diff.Pager after the config file is
    # read, so it wins over both the [diff] and the top-level pager.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_UPPERED


def test_diff_pager_overrides_the_top_level_pager(source, home, tmp_path):
    """`[diff] pager` takes precedence over the top-level `pager`."""
    config = write_config(
        tmp_path, "both.toml", 'pager = "tr a-z A-Z"\n[diff]\npager = "cat"\n'
    )
    res = run_diff_config(config, source, home)

    # CATCHES: getDiffPager prefers the [diff] pager over the top-level pager
    # when both are configured, so `cat` passes the diff through unchanged
    # and the `tr` top-level pager is never used.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_PLAIN


def test_pager_receives_less_and_lv_environment(source, home, tmp_path):
    """The pager runs with git-style LESS=FRX and LV=-c defaults."""
    config = write_config(
        tmp_path, "env.toml", 'pager = "cat > /dev/null; printenv LESS LV"\n'
    )
    res = run_diff_config(config, source, home)

    # CATCHES: getDiffPagerCmd appends LESS=FRX and LV=-c to the pager's
    # environment when the parent does not define them, exactly like git, so
    # after the pager has drained the diff the two values are printed.  The
    # `cat` drain also keeps the run deterministic: a pager that exits with
    # the pipe still open can deadlock chezmoi's io.Pipe-based lazyWriter.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"FRX\n-c\n"


def test_pager_args_are_passed_to_a_directly_executed_pager(source, home, tmp_path):
    """A pager without spaces is executed directly with `pagerArgs`."""
    config = write_config(
        tmp_path,
        "args.toml",
        'pager = "tr"\npagerArgs = ["a-z", "A-Z"]\n',
    )
    res = run_diff_config(config, source, home)
    # CATCHES: a single-word pager skips the shell entirely and its arguments
    # come from the pagerArgs config key, so `tr` is exec'd directly as
    # `tr a-z A-Z` and the whole diff reaches stdout uppercased (through the
    # shell it would instead run as a bare `tr` with no operands and fail).
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_UPPERED


def test_failing_pager_warns_on_stderr_but_exits_zero(source, home, tmp_path):
    """A pager that exits non-zero only produces a warning line."""
    config = write_config(
        tmp_path, "false.toml", 'pager = "cat > /dev/null; exit 3"\n'
    )
    res = run_diff_config(config, source, home)
    # CATCHES: the pager is waited for in the deferred finalize, which only
    # writes `error: failed to wait for diff pager to close` with the pager's
    # own exit status to stderr, so the command still exits 0 and produces no
    # diff output.  The `cat` drain keeps the close ordering deterministic.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: error: failed to wait for diff pager to close: exit status 3\n"
    )


def test_missing_pager_command_fails_the_diff(source, home, tmp_path):
    """A pager that cannot be started fails the diff with the target name."""
    config = write_config(
        tmp_path, "missing.toml", 'pager = "no-such-pager-xyz"\n'
    )
    res = run_diff_config(config, source, home)
    # CATCHES: starting the pager is lazy, happening on the first diff write,
    # so the exec failure surfaces wrapped in the first target's name and
    # aborts the command with status 1 and no stdout.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: .file: exec: "no-such-pager-xyz": '
        b"executable file not found in $PATH\n"
    )


def test_source_path_flag_selects_targets_by_source_name(source, home):
    """--source-path picks targets by their name in the source directory."""
    res = run_diff(source, home, "--source-path", str(source / "dot_second"))
    # CATCHES: targetRelPathsBySourcePath resolves each argument inside the
    # source directory and diffs only the matching target, so the .file
    # modification is left out of the output entirely.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == DIFF_SECOND


def test_source_path_flag_rejects_unknown_names(source, home):
    """--source-path with a name absent from the source state is an error."""
    res = run_diff(source, home, "--source-path", str(source / "nope"))
    # CATCHES: an argument that is inside the source directory but matches no
    # source state entry fails with `not in source state` naming the path.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == f"chezmoi: {source}/nope: not in source state\n".encode()


def test_persistent_state_flag_selects_the_database(source, home, tmp_path):
    """--persistent-state names the bolt database the command reads."""
    state = write_config(tmp_path, "state.boltdb", "not a bolt database\n")
    res = run_diff(source, home, "--persistent-state", str(state))
    # CATCHES: the diff command copies the persistent state read-only from
    # the file named by --persistent-state, so a non-bolt file there fails
    # with `open <path>: invalid database` before any diff output.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == f"chezmoi: open {state}: invalid database\n".encode()


def test_default_persistent_state_lives_in_the_config_directory(source, home):
    """Without --persistent-state the database sits next to the config file."""
    config_dir = home / ".config" / "chezmoi"
    config_dir.mkdir(parents=True)
    state = config_dir / "chezmoistate.boltdb"
    state.write_text("not a bolt database\n")
    res = run_diff(source, home)
    # CATCHES: persistentStateFile derives the default database path from
    # the config file's directory ($HOME/.config/chezmoi), not from the
    # source or destination directories.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == f"chezmoi: open {state}: invalid database\n".encode()


def test_custom_config_file_moves_the_persistent_state(source, home, tmp_path):
    """With -c the database is looked up next to the custom config file."""
    config = write_config(tmp_path, "custom.toml", "# empty config\n")
    state = write_config(tmp_path, "chezmoistate.boltdb", "not a bolt database\n")
    res = run_diff_config(config, source, home)

    # CATCHES: persistentStateFile joins the *config file's* directory with
    # chezmoistate.boltdb, so a -c config relocates the database to its own
    # directory, here tmp_path rather than the home config directory.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == f"chezmoi: open {state}: invalid database\n".encode()
