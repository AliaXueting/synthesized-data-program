"""Dispatch of unknown commands to ``chezmoi-<name>`` executables on PATH.

When cobra reports an unknown command, chezmoi looks for a
``chezmoi-<name>`` executable on PATH and runs it with the remaining
arguments, the same stdin/stdout/stderr, and a ``CHEZMOI_*`` environment
describing the invocation.  The lookup is keyed on the raw first argument,
so any flag before the name disables the dispatch, and built-in commands
always win over a plugin of the same name.
"""

from __future__ import annotations

import stat
from pathlib import Path

from conftest import executable_path, replace_home, run_chezmoi, write_plugin
from expected import LICENSE

# The recorded license text as exact stdout bytes.
LICENSE_BYTES = LICENSE.encode()

# The plugin dumps its arguments one per line so the exact argv (including
# flags and quoted words) can be compared byte for byte.
ARGDUMP = (
    "echo \"argc=$#\"\n"
    "i=1\n"
    'for a in "$@"; do echo "arg$i=<$a>"; i=$((i+1)); done\n'
)


def with_plugin_bin(tmp_path):
    """Create a plugin bin directory and return (path, PATH value) for it."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    return bin_dir, f"{bin_dir}:/usr/bin:/bin"


def test_plugin_receives_remaining_arguments_verbatim(tmp_path, home):
    """A plugin gets every argument after its name, flags included."""
    bin_dir, path = with_plugin_bin(tmp_path)
    write_plugin(bin_dir, "argdump", ARGDUMP)
    res = run_chezmoi(
        ["argdump", "-v", "foo", "--bar", "two words"],
        home=home,
        extra={"PATH": path},
    )
    # CATCHES: the dispatch passes args[1:] through verbatim — chezmoi does
    # not parse (or strip) flags after the plugin name, so even "-v" and
    # "--bar" reach the plugin as ordinary positional arguments.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"argc=4\n"
        b"arg1=<-v>\n"
        b"arg2=<foo>\n"
        b"arg3=<--bar>\n"
        b"arg4=<two words>\n"
    )


def test_plugin_stdin_stdout_and_stderr_are_passed_through(tmp_path, home):
    """The plugin shares chezmoi's stdin, stdout and stderr."""
    bin_dir, path = with_plugin_bin(tmp_path)
    write_plugin(bin_dir, "copier", "cat\necho to-stderr >&2\n")
    res = run_chezmoi(
        ["copier"],
        stdin=b"payload\n",
        home=home,
        extra={"PATH": path},
    )
    # CATCHES: the plugin process is wired to chezmoi's own stdin/stdout/
    # stderr, so stdin is forwarded and the plugin's stderr reaches chezmoi's
    # stderr without chezmoi wrapping or prefixing it.
    assert res.returncode == 0
    assert res.stdout == b"payload\n"
    assert res.stderr == b"to-stderr\n"


def test_plugin_exit_status_is_reported_as_an_error(tmp_path, home):
    """A failing plugin produces a `chezmoi: <path>: exit status N` line."""
    bin_dir, path = with_plugin_bin(tmp_path)
    plugin = write_plugin(bin_dir, "failer", "echo failing\nexit 7\n")
    res = run_chezmoi(["failer"], home=home, extra={"PATH": path})
    # CATCHES: the plugin's non-zero exit does not become chezmoi's exit
    # code; the run error is reported as a single stderr line naming the
    # resolved plugin path and the exit status, and chezmoi itself exits 1.
    assert res.returncode == 1
    assert res.stdout == b"failing\n"
    assert res.stderr == f"chezmoi: {plugin}: exit status 7\n".encode()


def test_flags_before_the_plugin_name_prevent_dispatch(tmp_path, home):
    """A global flag before the unknown name blocks the plugin lookup."""
    bin_dir, path = with_plugin_bin(tmp_path)
    write_plugin(bin_dir, "argdump", ARGDUMP)
    res = run_chezmoi(["-v", "argdump"], home=home, extra={"PATH": path})
    # CATCHES: the plugin is looked up as "chezmoi-" + args[0], and with a
    # flag first args[0] is "-v", so no plugin is found and the plain
    # unknown-command error is reported instead of dispatching.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: unknown command "argdump" for "chezmoi"\n'


def test_builtin_command_takes_precedence_over_plugin(tmp_path, home):
    """A plugin named like a built-in command never shadows it."""
    bin_dir, path = with_plugin_bin(tmp_path)
    write_plugin(bin_dir, "license", "echo I AM THE PLUGIN\n")
    res = run_chezmoi(["license"], home=home, extra={"PATH": path})
    # CATCHES: dispatch only happens after cobra failed to find the command,
    # so a chezmoi-license on PATH is ignored and the real `license` runs.
    assert res.returncode == 0
    assert res.stdout == LICENSE_BYTES
    assert b"I AM THE PLUGIN" not in res.stdout
    assert res.stderr == b""


def test_non_executable_plugin_is_not_dispatched(tmp_path, home):
    """A `chezmoi-<name>` file without the executable bit is not a plugin."""
    bin_dir, path = with_plugin_bin(tmp_path)
    (bin_dir / "chezmoi-noexec").write_text("#!/bin/sh\necho nope\n")
    (bin_dir / "chezmoi-noexec").chmod(0o644)
    res = run_chezmoi(["noexec"], home=home, extra={"PATH": path})
    # CATCHES: the dispatch uses exec.LookPath semantics, which skips files
    # without the executable bit, so the run falls through to the plain
    # unknown-command error.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: unknown command "noexec" for "chezmoi"\n'


def test_unknown_command_near_miss_offers_suggestions(home):
    """An unknown command close to a real one lists it as a suggestion."""
    res = run_chezmoi(["inert"], home=home)
    # CATCHES: cobra's unknown-command error appends a `Did you mean this?`
    # block naming near-miss command names (here `init`), still prefixed by
    # the single `chezmoi:` line and exiting 1.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: unknown command "inert" for "chezmoi"\n'
        b"\n"
        b"Did you mean this?\n"
        b"\tinit\n"
        b"\n"
    )


def test_plugin_receives_the_chezmoi_environment(tmp_path, home):
    """Chezmoi exports a CHEZMOI_* environment to the plugin."""
    bin_dir, path = with_plugin_bin(tmp_path)
    write_plugin(
        bin_dir,
        "probe",
        "echo CHEZMOI=$CHEZMOI\n"
        "echo COMMAND=$CHEZMOI_COMMAND\n"
        "echo HOME_DIR=$CHEZMOI_HOME_DIR\n"
        "echo SOURCE_DIR=$CHEZMOI_SOURCE_DIR\n"
        "echo DEST_DIR=$CHEZMOI_DEST_DIR\n"
        "echo CACHE_DIR=$CHEZMOI_CACHE_DIR\n"
        "echo CONFIG_FILE=$CHEZMOI_CONFIG_FILE\n"
        "echo ARGS=$CHEZMOI_ARGS\n",
    )
    res = run_chezmoi(
        ["probe", "one"],
        home=home,
        extra={"PATH": path},
    )
    # CATCHES: persistentPreRunRootE exports the invocation's template data
    # as environment variables before running the plugin, so the plugin sees
    # CHEZMOI=1, the plugin name as CHEZMOI_COMMAND, the HOME-derived
    # default directories, and the raw os.Args joined by spaces.
    assert res.returncode == 0
    assert res.stderr == b""
    assert replace_home(res.stdout, home) == (
        "CHEZMOI=1\n"
        "COMMAND=probe\n"
        "HOME_DIR=@HOME@\n"
        "SOURCE_DIR=@HOME@/.local/share/chezmoi\n"
        "DEST_DIR=@HOME@\n"
        "CACHE_DIR=@HOME@/.cache/chezmoi\n"
        "CONFIG_FILE=@HOME@/.config/chezmoi/chezmoi.toml\n"
        f"ARGS={executable_path()} probe one\n"
    ).encode()


def test_plugin_dispatch_ignores_an_invalid_config_file(tmp_path, home):
    """A broken config file does not stop the dispatch."""
    config_dir = home / ".config" / "chezmoi"
    config_dir.mkdir(parents=True)
    (config_dir / "chezmoi.toml").write_text("this is not valid toml [[[\n")
    bin_dir, path = with_plugin_bin(tmp_path)
    write_plugin(bin_dir, "probe", "echo probe-ran\n")
    res = run_chezmoi(["probe"], home=home, extra={"PATH": path})
    # CATCHES: the synthesized plugin command is annotated
    # doesNotRequireValidConfig, so an unparseable config file is ignored for
    # the dispatch — where a config-requiring command fails on the same file.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"probe-ran\n"
    failing = run_chezmoi(["managed"], home=home)
    assert failing.returncode == 1
    assert failing.stderr.startswith(b"chezmoi: invalid config: ")


def test_xdg_runtime_dir_is_created_for_plugins(tmp_path, home):
    """The plugin run creates $XDG_RUNTIME_DIR if it is missing."""
    bin_dir, path = with_plugin_bin(tmp_path)
    write_plugin(bin_dir, "probe", "echo probe-ran\n")
    runtime_dir = tmp_path / "runtime-dir"
    res = run_chezmoi(
        ["probe"],
        home=home,
        extra={"PATH": path, "XDG_RUNTIME_DIR": str(runtime_dir)},
    )
    # CATCHES: plugins are annotated runsCommands, for which chezmoi creates
    # the (missing) XDG runtime directory with mode 0o700 before spawning the
    # child process, so the plugin runs and the directory exists afterwards.
    assert res.returncode == 0
    assert res.stdout == b"probe-ran\n"
    assert runtime_dir.is_dir()
    assert stat.S_IMODE(runtime_dir.stat().st_mode) == 0o700


def test_pre_hook_runs_for_plugin_commands(tmp_path, home):
    """A `[hooks.<plugin-name>.pre]` hook runs before the plugin."""
    config_dir = home / ".config" / "chezmoi"
    config_dir.mkdir(parents=True)
    (config_dir / "chezmoi.toml").write_text(
        "[hooks.probe.pre]\ncommand = \"echo\"\nargs = [\"PROBE-HOOK\"]\n"
    )
    bin_dir, path = with_plugin_bin(tmp_path)
    write_plugin(bin_dir, "probe", "echo probe-ran\n")
    res = run_chezmoi(["probe"], home=home, extra={"PATH": path})
    # CATCHES: the dispatch runs persistentPreRunRootE for the synthesized
    # command, so the pre-hook registered for the plugin's name executes
    # before the plugin itself.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"PROBE-HOOK\nprobe-ran\n"
