"""Target-path completion behind ``[completion] custom``.

``targetValidArgs`` in ``internal/cmd/config.go`` is the ``ValidArgsFunction``
of every command that takes targets (``apply``, ``diff``, ``cat``, …).  It is
disabled unless the config file sets ``[completion] custom = true``: then
``chezmoi __complete <command> <prefix>`` offers the destination paths of the
whole source state, directories suffixed with ``/``, matched by prefix and
rewritten relative to the process working directory when the prefix itself is
relative.  Every expectation below was recorded from ``./executable``.
"""

from __future__ import annotations

from pathlib import Path

from conftest import run_chezmoi

# `chezmoi __complete apply ""` from HOME with the fixture below: every target
# of the source state, directories with a trailing slash, and the
# ShellCompDirectiveNoFileComp directive (:4) on the last line.
ALL_TARGETS = (
    b".bashrc\n"
    b".config/\n"
    b".config/chezmoi/\n"
    b".config/chezmoi/chezmoi.toml\n"
    b".vim/\n"
    b".vim/vimrc\n"
    b":4\n"
)
DIRECTIVE_NOFILECOMP = b"Completion ended with directive: ShellCompDirectiveNoFileComp\n"
DIRECTIVE_DEFAULT = b"Completion ended with directive: ShellCompDirectiveDefault\n"


def make_source_state(home):
    """Create a source state with a file, nested dirs and a nested file."""
    source = home / ".local" / "share" / "chezmoi"
    (source / "dot_config" / "chezmoi").mkdir(parents=True)
    (source / "dot_vim").mkdir()
    (source / "dot_bashrc").write_text("x\n")
    (source / "dot_config" / "chezmoi" / "chezmoi.toml").write_text("x\n")
    (source / "dot_vim" / "vimrc").write_text("x\n")
    return source


def write_custom_config(home, enabled=True):
    """Write the default config file with `[completion] custom` set or unset."""
    config_dir = home / ".config" / "chezmoi"
    config_dir.mkdir(parents=True, exist_ok=True)
    text = "[completion]\ncustom = true\n" if enabled else "[completion]\ncustom = false\n"
    (config_dir / "chezmoi.toml").write_text(text)
    return config_dir / "chezmoi.toml"


def test_custom_completion_lists_every_target(home):
    """`custom = true` completes all destination paths, dirs with a slash."""
    make_source_state(home)
    write_custom_config(home)
    res = run_chezmoi(["__complete", "apply", ""], home=home, cwd=home)
    # CATCHES: targetValidArgs offers the DestDir-relative path of every
    # target, appends "/" to directory targets and returns NoFileComp (:4)
    # instead of the shell's file completion.
    assert res.returncode == 0
    assert res.stdout == ALL_TARGETS
    assert res.stderr == DIRECTIVE_NOFILECOMP


def test_custom_completion_is_relative_to_the_working_directory(tmp_path, home):
    """A relative prefix yields paths relative to the process's directory."""
    make_source_state(home)
    write_custom_config(home)
    res = run_chezmoi(["__complete", "apply", ""], home=home, cwd=tmp_path)
    # CATCHES: with a relative (here: empty) toComplete the absolute
    # completions are trimmed of the commandDirAbsPath prefix, so they are
    # printed relative to the working directory, not to the destination.
    assert res.returncode == 0
    assert res.stdout == (
        b"home/.bashrc\n"
        b"home/.config/\n"
        b"home/.config/chezmoi/\n"
        b"home/.config/chezmoi/chezmoi.toml\n"
        b"home/.vim/\n"
        b"home/.vim/vimrc\n"
        b":4\n"
    )
    assert res.stderr == DIRECTIVE_NOFILECOMP


def test_custom_completion_filters_by_prefix(home):
    """Only the targets with the given prefix are offered."""
    make_source_state(home)
    write_custom_config(home)
    res = run_chezmoi(["__complete", "apply", ".config"], home=home, cwd=home)
    # CATCHES: the prefix match is a plain string HasPrefix on the completed
    # destination path, so ".config" keeps the directory itself and everything
    # below it while ".bashrc" and ".vim" are dropped.
    assert res.returncode == 0
    assert res.stdout == b".config/\n.config/chezmoi/\n.config/chezmoi/chezmoi.toml\n:4\n"
    assert res.stderr == DIRECTIVE_NOFILECOMP


def test_custom_completion_with_an_absolute_prefix(home):
    """An absolute prefix is matched against the absolute target paths."""
    make_source_state(home)
    write_custom_config(home)
    res = run_chezmoi(["__complete", "apply", str(home / ".v")], home=home, cwd=home)
    # CATCHES: an absolute toComplete disables the commandDir trimming, so the
    # completions are the full destination paths.
    assert res.returncode == 0
    assert res.stdout == (
        f"{home}/.vim/\n{home}/.vim/vimrc\n:4\n".encode()
    )
    assert res.stderr == DIRECTIVE_NOFILECOMP


def test_custom_completion_without_a_match_is_still_nofilecomp(home):
    """A prefix matching nothing prints only the directive."""
    make_source_state(home)
    write_custom_config(home)
    res = run_chezmoi(["__complete", "apply", "zzz"], home=home, cwd=home)
    # CATCHES: no completion is offered but the directive stays :4 (suppress
    # file completion) rather than falling back to the shell's default.
    assert res.returncode == 0
    assert res.stdout == b":4\n"
    assert res.stderr == DIRECTIVE_NOFILECOMP


def test_without_custom_the_targets_are_left_to_the_shell(home):
    """Without `[completion] custom` the shell's own file completion is used."""
    make_source_state(home)
    config = write_custom_config(home, enabled=False)
    res = run_chezmoi(["__complete", "apply", ""], home=home, cwd=home)
    # CATCHES: the guard clause of targetValidArgs returns no completions and
    # the ShellCompDirectiveDefault directive (:0), deferring to the shell.
    assert res.returncode == 0
    assert res.stdout == b":0\n"
    assert res.stderr == DIRECTIVE_DEFAULT
    assert config.read_text() == "[completion]\ncustom = false\n"


def test_complete_ignores_the_config_flag_for_its_configuration(tmp_path, home):
    """`__complete` reads only the default config file, not ``-c``."""
    make_source_state(home)
    other = Path(tmp_path) / "custom.toml"
    other.write_text("[completion]\ncustom = true\n")
    res = run_chezmoi(
        ["-c", str(other), "__complete", "apply", ""],
        home=home,
        cwd=home,
    )
    # CATCHES: cobra's hidden __complete command parses no flags, so a -c
    # config file never reaches targetValidArgs and the default (unset)
    # completion behaviour is used.
    assert res.returncode == 0
    assert res.stdout == b":0\n"
    assert res.stderr == DIRECTIVE_DEFAULT


def test_custom_completion_reports_source_state_errors(home):
    """A broken source state is reported as a completion error."""
    source = make_source_state(home)
    write_custom_config(home)
    (source / ".chezmoiversion").write_text("not-semver\n")
    res = run_chezmoi(["__complete", "apply", ""], home=home, cwd=home)
    # CATCHES: getSourceState failing inside targetValidArgs prints a
    # cobra CompError line on stderr and the ShellCompDirectiveError (:1)
    # directive on stdout, while the exit code stays 0.
    assert res.returncode == 0
    assert res.stdout == b":1\n"
    assert res.stderr == (
        b'[Debug] [Error] '
        + str(home / ".local" / "share" / "chezmoi" / ".chezmoiversion").encode()
        + b': "not-semver\\n": not is not in dotted-tri format\n'
        + b"Completion ended with directive: ShellCompDirectiveError\n"
    )
