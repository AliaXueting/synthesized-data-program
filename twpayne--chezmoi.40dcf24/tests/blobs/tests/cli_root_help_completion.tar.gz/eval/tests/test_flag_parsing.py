"""Root persistent flag parsing: syntax, value types and error reporting.

chezmoi registers all of its global flags as cobra *persistent* flags on the
root command, so they are accepted before or after the subcommand.  Every
expectation below was recorded by running ``./executable``.
"""

from __future__ import annotations

import os
import stat

import pytest

from conftest import run_chezmoi
from expected import LICENSE

# The license command writes a fixed 1112 bytes to stdout and needs no source
# state, so it is the canonical probe for "the global flags were accepted".
LICENSE_BYTES = 1112


def license_ok(argv, home, **kwargs):
    """Assert ARGV runs `license` successfully and prints it to stdout."""
    res = run_chezmoi(argv, home=home, **kwargs)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    assert len(res.stdout) == LICENSE_BYTES
    assert res.stdout == LICENSE.encode()
    return res


@pytest.mark.parametrize(
    "argv",
    [
        ["--verbose", "license"],
        ["-v", "license"],
        ["--verbose=true", "license"],
        ["--verbose=1", "license"],
        ["--verbose=0", "license"],
        ["-v=true", "license"],
        ["--dry-run=false", "license"],
        ["-n", "license"],
        ["-nv", "license"],
        ["--mode", "file", "license"],
        ["--mode", "symlink", "license"],
        ["--mode=file", "license"],
        ["--color=auto", "license"],
        ["--color=true", "license"],
        ["--color=0", "license"],
        ["--progress=auto", "license"],
        ["--config-format", "json", "license"],
        ["--config-format=json", "license"],
        ["--use-builtin-age=auto", "license"],
        ["--use-builtin-git=false", "license"],
        ["--use-builtin-diff", "license"],
        ["--source-path", "license"],
        ["--no-pager", "license"],
        ["--no-tty", "license"],
        ["--skip-secrets", "license"],
        ["--error-on-conflict", "license"],
        ["--force", "license"],
        ["--interactive", "license"],
        ["--less-interactive", "license"],
        ["--keep-going", "license"],
        ["--override-data", "a=b", "license"],
        ["--override-data-file", "/dev/null", "license"],
        ["--persistent-state", "unused.boltdb", "license"],
        ["--working-tree", "/nonexistent-working-tree", "license"],
        ["--cache", "/nonexistent-cache", "license"],
        ["--source", "/nonexistent-source", "license"],
        ["--destination", "/nonexistent-destination", "license"],
        ["--safe", "license"],
    ],
)
def test_global_flag_is_accepted(argv, home):
    """Every documented global flag parses and does not disturb the output."""
    # CATCHES: all of these are persistent root flags; a re-implementation
    # that registers any of them as a local flag of a subcommand, or that
    # rejects the `=` spelling, fails here.
    license_ok(argv, home)


def test_global_flags_accepted_after_the_subcommand(home):
    """Persistent flags may be given after the subcommand, not only before."""
    before = license_ok(["--verbose", "--no-pager", "license"], home)
    after = license_ok(["license", "--verbose", "--no-pager"], home)
    # CATCHES: cobra's Find() reorders flags so both spellings behave the
    # same and print the identical license text; a local-only flag
    # registration would reject the second form.
    assert after.stdout == before.stdout == LICENSE.encode()


@pytest.mark.parametrize(
    "argv,stderr",
    [
        (
            ["--frob"],
            b"chezmoi: unknown flag: --frob\n",
        ),
        (
            ["-Z"],
            b"chezmoi: unknown shorthand flag: 'Z' in -Z\n",
        ),
        (
            ["-Zv", "license"],
            b"chezmoi: unknown shorthand flag: 'Z' in -Zv\n",
        ),
        (
            ["-nZ", "license"],
            b"chezmoi: unknown shorthand flag: 'Z' in -Z\n",
        ),
        (
            ["--config"],
            b"chezmoi: flag needs an argument: --config\n",
        ),
        (
            ["-c"],
            b"chezmoi: flag needs an argument: 'c' in -c\n",
        ),
        (
            ["-o"],
            b"chezmoi: flag needs an argument: 'o' in -o\n",
        ),
        (
            ["--color"],
            b"chezmoi: flag needs an argument: --color\n",
        ),
        (
            ["--verbose=maybe", "license"],
            b'chezmoi: invalid argument "maybe" for "-v, --verbose" flag: '
            b"strconv.ParseBool: parsing \"maybe\": invalid syntax\n",
        ),
        (
            ["--color=bogus", "license"],
            b'chezmoi: invalid argument "bogus" for "--color" flag: '
            b"strconv.ParseBool: parsing \"bogus\": invalid syntax\n",
        ),
        (
            ["--progress=bogus", "license"],
            b'chezmoi: invalid argument "bogus" for "--progress" flag: '
            b"strconv.ParseBool: parsing \"bogus\": invalid syntax\n",
        ),
        (
            ["--use-builtin-git=bogus", "license"],
            b'chezmoi: invalid argument "bogus" for "--use-builtin-git" flag: '
            b"strconv.ParseBool: parsing \"bogus\": invalid syntax\n",
        ),
        (
            ["--mode=bogus", "license"],
            b'chezmoi: invalid argument "bogus" for "--mode" flag: invalid mode: bogus\n',
        ),
        (
            ["--config-format=bogus", "license"],
            b'chezmoi: invalid argument "bogus" for "--config-format" flag: invalid value\n',
        ),
        (
            ["--refresh-externals=bogus", "license"],
            b'chezmoi: invalid argument "bogus" for "-R, --refresh-externals" flag: '
            b"strconv.ParseBool: parsing \"bogus\": invalid syntax\n",
        ),
    ],
)
def test_flag_errors_are_single_stderr_lines(argv, stderr, home):
    """Flag errors print one `chezmoi: ...` line on stderr and exit 1."""
    res = run_chezmoi(argv, home=home)
    # CATCHES: SilenceUsage suppresses cobra's usage dump, so a flag error is
    # reported as a single stderr line with no usage text and no stdout.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == stderr


def test_flag_error_never_prints_usage(home):
    """No flag error ever dumps the usage/help text onto stderr."""
    for argv in (["--frob"], ["-Z"], ["--color"], ["--mode=x", "license"]):
        res = run_chezmoi(argv, home=home)
        # CATCHES: the root command sets SilenceUsage, so stderr contains no
        # "Usage:" block -- unlike plain cobra defaults.
        assert b"Usage:" not in res.stderr
        assert res.stderr.count(b"\n") == 1


def test_boolean_flags_without_value_consume_next_word(home):
    """`--progress license` treats `license` as the flag's value."""
    res = run_chezmoi(["--progress", "license"], home=home)
    # CATCHES: `--progress` is a plain bool|auto flag, so the following word
    # is consumed as its value and fails to parse as a boolean.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: invalid argument "license" for "--progress" flag: '
        b'strconv.ParseBool: parsing "license": invalid syntax\n'
    )


def test_refresh_externals_has_an_optional_value(home):
    """`--refresh-externals` has NoOptDefVal, so it consumes no argument."""
    res = run_chezmoi(["--refresh-externals", "always", "license"], home=home)
    # CATCHES: unlike --progress, --refresh-externals is registered with a
    # NoOptDefVal, so `always` is left over as a positional and reported as an
    # unknown command instead of being eaten by the flag.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: unknown command "always" for "chezmoi"\n'


def test_refresh_externals_bare_flag_is_a_no_op(home):
    """`-R` alone and `--refresh-externals` alone both parse."""
    for argv in (["-R", "license"], ["--refresh-externals", "license"]):
        # CATCHES: the shorthand and long form both default to `always`
        # without needing a value.
        license_ok(argv, home)


@pytest.mark.parametrize("value", ["always", "auto", "never", "true", "false", "ALWAYS"])
def test_refresh_externals_accepted_values(value, home):
    """`--refresh-externals=VALUE` accepts the enum and booleans, case-insensitively."""
    # CATCHES: the Set method lowercases its input before matching the enum,
    # and falls back to ParseBool, so `true` means `always`.
    license_ok(["--refresh-externals=" + value, "license"], home)


def test_refresh_externals_shorthand_does_not_absorb_value(home):
    """`-Ralways` is rejected: the shorthand form never takes a joined value."""
    res = run_chezmoi(["-Ralways", "license"], home=home)
    # CATCHES: pflag splits `-Ralways` into `-R` (using its NoOptDefVal) plus
    # the remaining shorthands, so the first letter of `always` is reported.
    assert res.returncode == 1
    assert res.stderr == b"chezmoi: unknown shorthand flag: 'a' in -always\n"


def test_double_dash_stops_flag_parsing_at_root(home):
    """`chezmoi -- --frob` prints the root help; `--frob` is not a flag."""
    res = run_chezmoi(["--", "--frob"], home=home)
    # CATCHES: after `--` everything is a positional argument, and the root
    # command ignores positional arguments entirely and prints help.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout.startswith(b"Manage your dotfiles across multiple diverse machines, securely\n")


def test_double_dash_before_subcommand_arguments(home):
    """`chezmoi license -- --frob` reports --frob as an unknown command."""
    res = run_chezmoi(["license", "--", "--frob"], home=home)
    # CATCHES: `license` takes NoArgs, so cobra's default NoArgs validator
    # reports the leftover positional as an unknown *command*.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: unknown command "--frob" for "chezmoi license"\n'


def test_output_flag_writes_stdout_to_a_file(home, tmp_path):
    """`-o` redirects the command's output to a file instead of stdout."""
    target = tmp_path / "license.txt"
    res = run_chezmoi(["-o", str(target), "license"], home=home)
    # CATCHES: with -o the license text goes to the file (created 0o666) and
    # stdout stays empty.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert len(target.read_bytes()) == LICENSE_BYTES


def test_output_flag_file_mode_is_666(home, tmp_path):
    """`-o` creates the file with mode 0o666 masked by the process umask."""
    target = tmp_path / "license.txt"
    res = run_chezmoi(["--output", str(target), "license"], home=home)
    # CATCHES: writeOutputString is called with 0o666 for license, so the
    # resulting mode is 0o666 & ~umask, never 0o600 and never executable.
    assert res.returncode == 0
    umask = os.umask(0)
    os.umask(umask)
    assert stat.S_IMODE(target.stat().st_mode) == 0o666 & ~umask


def test_output_flag_install_script_is_executable(home, tmp_path):
    """`-o` for `generate install.sh` creates an executable file (0o777)."""
    target = tmp_path / "install.sh"
    res = run_chezmoi(["-o", str(target), "generate", "install.sh"], home=home)
    # CATCHES: runGenerateInstallShCmd calls writeOutput with 0o777, unlike
    # license's 0o666 -- the executable bit survives the umask.
    assert res.returncode == 0
    assert res.stdout == b""
    umask = os.umask(0)
    os.umask(umask)
    assert stat.S_IMODE(target.stat().st_mode) == 0o777 & ~umask


def test_output_flag_overwrites_an_existing_file(home, tmp_path):
    """`-o` truncates an existing output file."""
    target = tmp_path / "license.txt"
    target.write_bytes(b"PRE-EXISTING CONTENT THAT IS LONGER THAN NEEDED\n")
    res = run_chezmoi(["-o", str(target), "license"], home=home)
    # CATCHES: the output file is opened with O_TRUNC, so no stale bytes from
    # the previous content survive.
    assert res.returncode == 0
    assert len(target.read_bytes()) == LICENSE_BYTES


def test_output_flag_missing_parent_directory(home, tmp_path):
    """`-o` into a non-existent directory reports the open error."""
    target = tmp_path / "no-such-dir" / "out.txt"
    res = run_chezmoi(["-o", str(target), "license"], home=home)
    # CATCHES: the error is the raw os.Open error, prefixed by chezmoi and
    # reported without a usage dump.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: open %s: no such file or directory\n" % str(target).encode()
    )


def test_age_recipient_without_encryption_warns(home):
    """`--age-recipient` without an `encryption` config prints a warning."""
    res = run_chezmoi(["--age-recipient", "age1example", "license"], home=home)
    # CATCHES: using the age override without a matching top-level config key
    # emits a `chezmoi: warning:` line on stderr but still exits 0.
    assert res.returncode == 0
    assert len(res.stdout) == LICENSE_BYTES
    assert res.stderr == (
        b"chezmoi: warning: 'encryption' not set, using age configuration. "
        b"Check if 'encryption' is correctly set as the top-level key.\n"
    )


def test_debug_flag_logs_to_stderr(home):
    """`--debug` emits structured logs on stderr without changing stdout."""
    res = run_chezmoi(["--debug", "license"], home=home)
    # CATCHES: --debug switches the logger on; the first record is
    # persistentPreRunRootE and carries the version info as attributes.
    assert res.returncode == 0
    assert len(res.stdout) == LICENSE_BYTES
    assert b"level=INFO msg=persistentPreRunRootE" in res.stderr
    assert b"version.builtBy=" in res.stderr


def test_version_flag_is_root_only(home):
    """`--version` is not a persistent flag: subcommands reject it."""
    res = run_chezmoi(["license", "--version"], home=home)
    # CATCHES: the version flag is auto-added to the root command only, so a
    # subcommand reports it as an unknown flag.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: unknown flag: --version\n"
