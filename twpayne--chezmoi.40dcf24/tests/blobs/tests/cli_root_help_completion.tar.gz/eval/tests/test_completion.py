"""The ``chezmoi completion`` command: shell completion script generation.

``completion`` is a cobra command taking exactly one shell name from its
ValidArgs list (bash, fish, powershell, zsh); the generated scripts are cobra's
dynamic completion scripts, byte-identical to the files committed in
``completions/``.  Every expectation below is the exact bytes recorded from
``./executable`` (kept in ``data/``).
"""

from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from conftest import run_chezmoi

DATA_DIR = Path(__file__).parent / "data"

# Recorded `chezmoi completion SHELL` outputs (byte-exact).
COMPLETION_SCRIPTS = {
    "bash": DATA_DIR / "completion.bash",
    "zsh": DATA_DIR / "completion.zsh",
    "fish": DATA_DIR / "completion.fish",
    "powershell": DATA_DIR / "completion.powershell",
}

# The first line of each generated script.
FIRST_LINES = {
    "bash": "# bash completion V2 for chezmoi",
    "zsh": "#compdef chezmoi",
    "fish": "# fish completion for chezmoi",
    "powershell": "# powershell completion for chezmoi",
}


@pytest.mark.parametrize("shell", ["bash", "zsh", "fish", "powershell"])
def test_completion_script_exact_bytes(shell, home):
    """`chezmoi completion SHELL` prints the recorded script to stdout."""
    res = run_chezmoi(["completion", shell], home=home)
    # CATCHES: the generated script must be byte-identical to the recorded
    # one (and to the file committed in completions/), not merely similar.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == COMPLETION_SCRIPTS[shell].read_bytes()


@pytest.mark.parametrize("shell,first_line", sorted(FIRST_LINES.items()))
def test_completion_script_headers(shell, first_line, home):
    """Each generated script starts with its generator's signature header."""
    res = run_chezmoi(["completion", shell], home=home)
    # CATCHES: bash's "V2" marker and zsh's #compdef hook line distinguish
    # the generators, and every script carries the -*- shell-script -*- mode
    # marker on its description line.
    assert res.returncode == 0
    assert res.stdout.splitlines()[0].startswith(first_line.encode())
    assert any(b"-*- shell-script -*-" in line for line in res.stdout.splitlines()[:4])
    if shell == "zsh":
        assert b"compdef _chezmoi chezmoi\n" in res.stdout


# How each generated script invokes the hidden `__complete` command.
COMPLETE_INVOCATIONS = {
    "bash": b'requestComp="${words[0]} __complete ${args[*]}"',
    "zsh": b'requestComp="${words[1]} __complete ${words[2,-1]}"',
    "fish": b'set -l requestComp "CHEZMOI_ACTIVE_HELP=0 $args[1] __complete '
            b'$args[2..-1] $lastArg"',
    "powershell": b'$RequestComp="$Program __complete $Arguments"',
}


@pytest.mark.parametrize("shell,invocation", sorted(COMPLETE_INVOCATIONS.items()))
def test_completion_scripts_are_dynamic(shell, invocation, home):
    """The scripts complete at runtime via the hidden `__complete` command."""
    out = run_chezmoi(["completion", shell], home=home).stdout
    # CATCHES: cobra's generators emit a dynamic completer that shells out to
    # `chezmoi __complete` at runtime; no command or flag names are baked into
    # the script, so a new subcommand needs no regenerated script.
    assert invocation in out
    assert b"--refresh-externals" not in out
    assert b"execute-template" not in out


def test_completion_unsupported_shell(home):
    """`chezmoi completion badshell` fails with a single error line."""
    res = run_chezmoi(["completion", "badshell"], home=home)
    # CATCHES: the shell name is matched by the completion function's switch,
    # and an unmatched name is reported as `<name>: unsupported shell` with
    # no usage dump and nothing on stdout.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: badshell: unsupported shell\n"


def test_completion_shell_name_is_case_sensitive(home):
    """`BASH` is not accepted: shell names match case-sensitively."""
    res = run_chezmoi(["completion", "BASH"], home=home)
    # CATCHES: the switch on the shell name is case-sensitive, so the
    # uppercase spelling is rejected with the same unsupported-shell error.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: BASH: unsupported shell\n"


@pytest.mark.parametrize(
    "argv,stderr",
    [
        (["completion"], b"chezmoi: accepts 1 arg(s), received 0\n"),
        (["completion", "bash", "zsh"], b"chezmoi: accepts 1 arg(s), received 2\n"),
    ],
)
def test_completion_arg_count_errors(argv, stderr, home):
    """`completion` takes exactly one argument; other counts are errors."""
    res = run_chezmoi(argv, home=home)
    # CATCHES: cobra's ExactArgs(1) error is rendered as a single `chezmoi:`
    # line on stderr with exit code 1 -- no usage dump, no stdout.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == stderr


def test_completion_has_no_custom_flag(home):
    """This build registers no `--custom` flag on the completion command."""
    res = run_chezmoi(["completion", "--custom", "bash"], home=home)
    # CATCHES: `--custom` is reported as an unknown flag (there is no such
    # flag in this build), so the completion command's only surface is the
    # single shell positional.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: unknown flag: --custom\n"


def test_completion_output_flag(home, tmp_path):
    """`-o` writes the script to a file instead of stdout, mode 0o666."""
    target = tmp_path / "chezmoi.bash"
    res = run_chezmoi(["-o", str(target), "completion", "bash"], home=home)
    # CATCHES: runCompletionCmd writes its output with 0o666 permissions, so
    # the redirected file is a plain non-executable file holding exactly the
    # script bytes, and stdout stays empty.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert target.read_bytes() == COMPLETION_SCRIPTS["bash"].read_bytes()
    umask = os.umask(0)
    os.umask(umask)
    assert stat.S_IMODE(target.stat().st_mode) == 0o666 & ~umask


@pytest.mark.parametrize(
    "to_complete,expected_stdout",
    [
        ("", b"bash\nfish\npowershell\nzsh\n:4\n"),
        ("b", b"bash\n:4\n"),
        ("z", b"zsh\n:4\n"),
        ("x", b":4\n"),
    ],
)
def test_hidden_complete_command_offers_valid_shells(to_complete, expected_stdout, home):
    """`chezmoi __complete completion PREFIX` offers the four ValidArgs shells."""
    res = run_chezmoi(["__complete", "completion", to_complete], home=home)
    # CATCHES: the shells are registered as cobra ValidArgs on the completion
    # command, so the hidden __complete machinery offers exactly those four
    # names (in registration order) plus the NoFileComp directive `:4`, and
    # an unmatchable prefix offers nothing but still ends with the directive.
    assert res.returncode == 0
    assert res.stdout == expected_stdout
    assert res.stderr == (
        b"Completion ended with directive: ShellCompDirectiveNoFileComp\n"
    )


def test_completion_ignores_an_invalid_config(home, tmp_path):
    """`completion` runs even when the config file cannot be parsed."""
    bad_config = tmp_path / "bad.toml"
    bad_config.write_text("this is not valid toml [[[\n")
    res = run_chezmoi(["--config", str(bad_config), "completion", "zsh"], home=home)
    # CATCHES: completion is annotated doesNotRequireValidConfig, so a broken
    # config file is ignored entirely and the full script is still printed,
    # where a config-requiring command fails on the same file.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == COMPLETION_SCRIPTS["zsh"].read_bytes()
    failing = run_chezmoi(["--config", str(bad_config), "managed"], home=home)
    assert failing.returncode == 1
    assert failing.stderr.startswith(b"chezmoi: invalid config: ")


def test_completion_output_is_independent_of_home(home, tmp_path):
    """The generated scripts embed no HOME-derived paths."""
    other_home = tmp_path / "other-home"
    other_home.mkdir()
    first = run_chezmoi(["completion", "bash"], home=home).stdout
    second = run_chezmoi(["completion", "bash"], home=other_home).stdout
    # CATCHES: unlike the help output, whose flag defaults embed the user's
    # directories, the completion scripts are static and per-user-path-free,
    # so two different homes produce identical bytes.
    assert second == first == COMPLETION_SCRIPTS["bash"].read_bytes()
