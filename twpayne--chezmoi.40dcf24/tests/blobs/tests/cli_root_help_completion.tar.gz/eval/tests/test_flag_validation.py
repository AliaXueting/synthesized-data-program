"""Cross-flag validation and flag values resolved in persistentPreRunRootE.

These tests pin the root command's flag semantics beyond parsing: the
mutual exclusion of --force and --interactive, the accepted spellings of
the autoBool flags, and the errors produced when -S/--source names
something that is not a usable source directory.
"""

from __future__ import annotations

import pytest

from conftest import run_chezmoi
from expected import LICENSE

# The recorded license text as exact stdout bytes.
LICENSE_BYTES = LICENSE.encode()


@pytest.mark.parametrize(
    "argv",
    [
        ["--force", "--interactive", "license"],
        ["--interactive", "--force", "license"],
        ["--force", "--interactive", "license", "--debug"],
    ],
)
def test_force_and_interactive_are_mutually_exclusive(argv, home):
    """--force conflicts with --interactive."""
    res = run_chezmoi(argv, home=home)
    # CATCHES: persistentPreRunRootE rejects --force together with
    # --interactive (in either order, and wherever the flags appear) before
    # any output, with a single usage-free error line.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: the --force and --interactive flags are mutually exclusive\n"
    )


@pytest.mark.parametrize(
    "argv",
    [
        ["--force", "--interactive=false", "license"],
        ["--force", "--less-interactive", "license"],
    ],
)
def test_force_accepts_non_interactive_prompting_flags(argv, home):
    """--force only conflicts with an enabled --interactive."""
    res = run_chezmoi(argv, home=home)
    # CATCHES: the exclusion checks the Interactive field alone, so an
    # explicit --interactive=false (and the separate --less-interactive flag,
    # which sets a different field) run fine alongside --force.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == LICENSE_BYTES


@pytest.mark.parametrize(
    "value",
    ["on", "off", "y", "n", "1", "0", "t", "f", "yes", "no", "True", "FALSE", "AUTO"],
)
def test_color_flag_accepts_every_bool_spelling(value, home):
    """--color takes ParseBool spellings plus auto, case-insensitively."""
    res = run_chezmoi(["--color", value, "license"], home=home)
    # CATCHES: the autoBool flag value goes through chezmoi's ParseBool
    # (on/off/y/n/yes/no plus strconv's spellings, case-insensitive) or the
    # case-insensitive `auto`; every spelling is accepted and leaves the
    # license output untouched.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == LICENSE_BYTES


def test_source_flag_rejects_a_regular_file(home, tmp_path):
    """-S pointing at a regular file fails the source-directory check."""
    plain = tmp_path / "plainfile"
    plain.write_text("not a directory\n")
    res = run_chezmoi(["-S", str(plain), "dump"], home=home)
    # CATCHES: commands that require a source directory stat the -S path in
    # persistentPreRunRootE; a regular file exists but is not a directory and
    # is reported as `<path>: not a directory` with no usage dump.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == f"chezmoi: {plain}: not a directory\n".encode()


def test_source_flag_rejects_a_missing_path(home, tmp_path):
    """--source pointing at a missing path reports the stat error."""
    missing = tmp_path / "missing"
    res = run_chezmoi(["--source", str(missing), "dump"], home=home)
    # CATCHES: the long spelling of the flag behaves identically to -S, and
    # a missing path surfaces the raw stat error `stat <path>: no such file
    # or directory` on a single stderr line.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        f"chezmoi: stat {missing}: no such file or directory\n".encode()
    )
