"""Root command help surface of chezmoi.

Recorded from ``./executable`` with ``HOME`` pointed at an empty temporary
directory; the derived default directories are normalised to ``@HOME@``.
"""

from __future__ import annotations

from conftest import replace_home, run_chezmoi
from expected import LICENSE

# Exact bytes of `chezmoi --help` (and of bare `chezmoi`, and `chezmoi -h`).
ROOT_HELP = """\
Manage your dotfiles across multiple diverse machines, securely

Usage:
  chezmoi [command]

Documentation commands:
  doctor               Check your system for potential problems
  help                 Print help about a command
  license              Print license

Daily commands:
  add                  Add an existing file, directory, or symlink to the source state
  apply                Update the destination directory to match the target state
  chattr               Change the attributes of a target in the source state
  diff                 Print the diff between the target state and the destination state
  edit                 Edit the source state of a target
  forget               Remove a target from the source state
  init                 Setup the source directory and update the destination directory to match the target state
  merge                Perform a three-way merge between the destination state, the source state, and the target state
  merge-all            Perform a three-way merge for each modified file
  push                 Add, commit, and push all changes in the source state
  re-add               Re-add modified files
  status               Show the status of targets
  update               Pull and apply any changes

Template commands:
  cat                  Print the target contents of a file, script, or symlink
  data                 Print the template data
  execute-template     Execute the given template(s)

Advanced commands:
  cd                   Launch a shell in the source directory
  edit-config          Edit the configuration file
  edit-config-template Edit the configuration file template
  generate             Generate a file for use with chezmoi
  git                  Run git in the source directory
  ignored              Print ignored targets
  managed              List the managed entries in the destination directory
  unmanaged            List the unmanaged files in the destination directory
  verify               Exit with success if the destination state matches the target state, fail otherwise

Encryption commands:
  age                  Interact with age
  age-keygen           Generate an age identity or convert an age identity to an age recipient
  decrypt              Decrypt file or standard input
  edit-encrypted       Edit an encrypted file
  encrypt              Encrypt file or standard input

Remote commands:
  docker               Use your dotfiles in a Docker container
  ssh                  SSH to a host and initialize dotfiles

Migration commands:
  archive              Generate a tar archive of the target state
  destroy              Permanently delete an entry from the source state, the destination directory, and the state
  import               Import an archive into the source state
  purge                Purge chezmoi's configuration and data
  upgrade              Upgrade chezmoi to the latest released version

Internal commands:
  cat-config           Print the configuration file
  completion           Generate shell completion code
  dump                 Generate a dump of the target state
  dump-config          Dump the configuration values
  secret               Interact with a secret manager
  source-path          Print the source path of a target
  state                Manipulate the persistent state
  target-path          Print the target path of a source path

Flags:
      --age-recipient string                           Override age recipient
      --age-recipient-file string                      Override age recipient
      --cache path                                     Set cache directory (default @HOME@/.cache/chezmoi)
      --color bool|auto                                Colorize output (default auto)
  -c, --config path                                    Set config file
      --config-format <none>|json|toml|yaml            Set config file format
      --debug                                          Include debug information in output
  -D, --destination path                               Set destination directory (default @HOME@)
  -n, --dry-run                                        Do not make any modifications to the destination directory
      --error-on-conflict                              Error on conflict
      --force                                          Make all changes without prompting
  -h, --help                                           help for chezmoi
      --interactive                                    Prompt for all changes
  -k, --keep-going                                     Keep going as far as possible after an error
      --less-interactive                               Prompt for changed or pre-existing targets
      --mode file|symlink                              Mode (default file)
      --no-pager                                       Do not use the pager
      --no-tty                                         Do not attempt to get a TTY for prompts
  -o, --output path                                    Write output to path instead of stdout
      --override-data string                           Override data
      --override-data-file path                        Override data with file
      --persistent-state path                          Set persistent state file
      --progress bool|auto                             Display progress bars (default auto)
  -R, --refresh-externals always|auto|never[=always]   Refresh external cache (default auto)
      --skip-secrets                                   Skip all templates containing secrets
  -S, --source path                                    Set source directory (default @HOME@/.local/share/chezmoi)
      --source-path                                    Specify targets by source path
      --use-builtin-age bool|auto                      Use builtin age (default auto)
      --use-builtin-diff                               Use builtin diff
      --use-builtin-git bool|auto                      Use builtin git (default auto)
  -v, --verbose                                        Make output more verbose
      --version                                        version for chezmoi
  -W, --working-tree path                              Set working tree directory

Use "chezmoi [command] --help" for more information about a command.
"""

# The eight cobra command groups, in the order cobra prints them.
GROUP_HEADERS = [
    "Documentation commands:",
    "Daily commands:",
    "Template commands:",
    "Advanced commands:",
    "Encryption commands:",
    "Remote commands:",
    "Migration commands:",
    "Internal commands:",
]

GROUPS = {
    "Documentation commands:": ["doctor", "help", "license"],
    "Daily commands:": [
        "add", "apply", "chattr", "diff", "edit", "forget", "init",
        "merge", "merge-all", "push", "re-add", "status", "update",
    ],
    "Template commands:": ["cat", "data", "execute-template"],
    "Advanced commands:": [
        "cd", "edit-config", "edit-config-template", "generate", "git",
        "ignored", "managed", "unmanaged", "verify",
    ],
    "Encryption commands:": [
        "age", "age-keygen", "decrypt", "edit-encrypted", "encrypt",
    ],
    "Remote commands:": ["docker", "ssh"],
    "Migration commands:": [
        "archive", "destroy", "import", "purge", "upgrade",
    ],
    "Internal commands:": [
        "cat-config", "completion", "dump", "dump-config", "secret",
        "source-path", "state", "target-path",
    ],
}


def root_help(home):
    """Return the root help with HOME-derived paths normalised."""
    res = run_chezmoi(["--help"], home=home)
    assert res.returncode == 0
    return replace_home(res.stdout, home).decode()


def test_no_arguments_prints_help_on_stdout(home):
    """`chezmoi` with no arguments prints the root help and exits 0."""
    res = run_chezmoi([], home=home)
    # CATCHES: the root command has no Run function, so cobra falls back to
    # printing help to stdout (not stderr) with exit code 0.
    assert res.returncode == 0
    assert res.stderr == b""
    assert replace_home(res.stdout, home).decode() == ROOT_HELP


def test_long_help_flag_matches_bare_invocation(home):
    """`--help`, `-h` and no arguments produce byte-identical root help."""
    no_args = run_chezmoi([], home=home).stdout
    long_flag = run_chezmoi(["--help"], home=home).stdout
    short_flag = run_chezmoi(["-h"], home=home).stdout
    # CATCHES: all three entry points funnel through the same root help
    # template; a re-implementation that printed usage on stderr, or that
    # treated a bare invocation as an error, would break here.
    assert long_flag == no_args
    assert short_flag == no_args
    assert replace_home(no_args, home).decode() == ROOT_HELP


def test_help_subcommand_omits_help_and_version_flags(home):
    """`chezmoi help` lacks the `-h, --help` and `--version` flag lines.

    The `help` command is what actually executes, so cobra only initialises
    the automatic help/version flags on *that* command, not on the root.
    """
    res = run_chezmoi(["help"], home=home)
    # CATCHES: `chezmoi help` is not the same bytes as `chezmoi --help`; it
    # is missing exactly the two auto-added root flags.
    assert res.returncode == 0
    assert res.stderr == b""
    expected = ROOT_HELP.replace("  -h, --help                                           help for chezmoi\n", "")
    expected = expected.replace("      --version                                        version for chezmoi\n", "")
    assert replace_home(res.stdout, home).decode() == expected


def test_help_subcommand_accepts_no_arguments_group(home):
    """`chezmoi help` still lists `help` itself under Documentation commands."""
    out = root_help(home)
    # CATCHES: the help command is a real first-class command in the
    # Documentation group, not a synthetic cobra entry.
    assert "  help                 Print help about a command\n" in out


def test_eight_command_groups_in_order(home):
    """The root help groups subcommands under the eight cobra groups, in order."""
    out = root_help(home)
    positions = [out.index(header) for header in GROUP_HEADERS]
    # CATCHES: group order and group titles come from the cobra Group list;
    # a missing, extra or re-ordered group breaks the recorded layout.
    assert positions == sorted(positions)
    assert out.count("commands:") == 8


def test_group_membership_is_exact(home):
    """Each group lists exactly its recorded commands, in the recorded order."""
    out = root_help(home)
    lines = out.splitlines()
    # CATCHES: which command belongs to which group is part of the public
    # CLI surface; moving e.g. `license` out of Documentation breaks this.
    for index, header in enumerate(GROUP_HEADERS):
        start = lines.index(header) + 1
        end = next(
            (i for i in range(start, len(lines)) if not lines[i].startswith("  ")),
            len(lines),
        )
        names = [line.split()[0] for line in lines[start:end]]
        assert names == GROUPS[header], header


def test_hidden_commands_are_not_listed(home):
    """Hidden commands (`internal-test`, `remove`, `mackup`) never appear."""
    out = root_help(home)
    # CATCHES: `internal-test` and `remove` are registered but Hidden, so the
    # root help must not advertise them even though they still execute; the
    # visible listing is exactly the recorded one.
    assert out == ROOT_HELP
    for hidden in ("internal-test", "remove", "mackup", "__complete"):
        assert hidden not in out


def test_hidden_safe_flag_is_accepted_but_not_listed(home):
    """`--safe` is registered and hidden: absent from help, still parseable."""
    res = run_chezmoi(["--safe", "license"], home=home)
    # CATCHES: `--safe` exists (MarkHidden) so it must parse and `license`
    # still prints its full text, but the help listing -- which does show the
    # other 33 flags -- must not mention it.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == LICENSE.encode()
    help_stdout = run_chezmoi(["--help"], home=home).stdout
    assert b"  -v, --verbose " in help_stdout
    assert b"--safe" not in help_stdout


def test_flag_defaults_derive_from_home(home):
    """The `--cache`, `--destination` and `--source` defaults derive from HOME."""
    out = run_chezmoi(["--help"], home=home).stdout.decode()
    # CATCHES: the defaults are computed at flag registration time from the
    # user's home directory and rendered into the flag usages block.
    assert (
        "      --cache path                                     "
        "Set cache directory (default %s/.cache/chezmoi)\n" % home
    ) in out
    assert (
        "  -D, --destination path                               "
        "Set destination directory (default %s)\n" % home
    ) in out
    assert (
        "  -S, --source path                                    "
        "Set source directory (default %s/.local/share/chezmoi)\n" % home
    ) in out


def test_cache_default_follows_xdg_cache_home(home, tmp_path):
    """XDG_CACHE_HOME overrides the `--cache` default shown in help."""
    cache = tmp_path / "xdg-cache"
    cache.mkdir()
    res = run_chezmoi(["--help"], home=home, extra={"XDG_CACHE_HOME": str(cache)})
    # CATCHES: the cache default comes from Go's os.UserCacheDir, which
    # honours XDG_CACHE_HOME, while the source/destination defaults do not.
    line = ("      --cache path                                     "
            "Set cache directory (default %s/chezmoi)\n" % cache).encode()
    assert line in res.stdout


def test_displayed_default_ignores_supplied_value(home):
    """Passing `-D` does not change the default rendered in the flag usages."""
    res = run_chezmoi(["--destination", "/nonexistent/elsewhere", "--help"], home=home)
    # CATCHES: pflag prints the registration-time DefValue, so the help block
    # is stable no matter what the user passed on the command line.
    line = ("  -D, --destination path                               "
            "Set destination directory (default %s)\n" % home).encode()
    assert line in res.stdout
    assert b"/nonexistent/elsewhere" not in res.stdout


def test_trailing_hint_line(home):
    """The root help ends with the cobra "more information" hint."""
    out = root_help(home)
    # CATCHES: the final line is cobra's UseLine hint, not a blank line or a
    # version string.
    assert out.endswith('Use "chezmoi [command] --help" for more information about a command.\n')


def test_usage_line_and_short_description(home):
    """The root help starts with the short description and `chezmoi [command]`."""
    out = root_help(home)
    # CATCHES: the first line is the root command's Short, and the usage line
    # is `chezmoi [command]` -- there is no `[flags]` placeholder.
    assert out.splitlines()[0] == "Manage your dotfiles across multiple diverse machines, securely"
    assert out.splitlines()[2] == "Usage:"
    assert out.splitlines()[3] == "  chezmoi [command]"


def test_root_help_lists_global_flags_separately(home):
    """The root `Flags:` block contains only the persistent root flags."""
    out = root_help(home)
    flags_block = out.split("Flags:\n", 1)[1].split("\n\nUse ", 1)[0]
    lines = flags_block.splitlines()
    # CATCHES: the root help has exactly one flag block, holding the 31
    # persistent flags plus the two auto-added ones -- never a subcommand's
    # own flags (e.g. `--template` of `add`).
    assert len(lines) == 33
    assert all(not line.startswith("  -T, --template") for line in lines)
    assert "  -x, --exclude types" not in flags_block


def test_command_name_column_is_aligned_to_widest(home):
    """Command names are padded to the widest name, `edit-config-template`."""
    out = root_help(home)
    # CATCHES: cobra pads the command column using the longest command name in
    # the whole tree, so `doctor` gets 15 trailing spaces.
    assert "  doctor               Check your system for potential problems\n" in out
    assert ("  edit-config-template Edit the configuration file template\n") in out
