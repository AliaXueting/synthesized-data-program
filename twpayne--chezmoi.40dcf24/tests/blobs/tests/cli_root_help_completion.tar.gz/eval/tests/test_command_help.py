"""Per-command long help of chezmoi.

The long help of every command is generated from the markdown under
``assets/chezmoi.io/docs/reference/commands`` into ``internal/cmd/helps.gen.go``
and is prefixed with a ``Description`` header.  All expectations below are the
exact bytes recorded from ``./executable``.
"""

from __future__ import annotations

import pytest

from conftest import replace_home, run_chezmoi
from expected import (
    ADD_HELP,
    COMPLETION_HELP,
    DOCKER_HELP,
    FORGET_HELP,
    GENERATE_HELP,
    GENERATE_INSTALL_INIT_HELP,
    GENERATE_INSTALL_SH_HELP,
    HELP_ADD,
    HELP_GENERATE_INSTALL,
    HELP_HELP,
    INTERNAL_TEST_HELP,
    LICENSE_HELP,
    MANAGED_HELP,
    RM_HELP,
)


def help_text(argv, home):
    """Run ARGV and return the normalised stdout help text."""
    res = run_chezmoi(argv, home=home)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b""
    return replace_home(res.stdout, home).decode()


def test_help_command_long_help(home):
    """`chezmoi help help` prints the help command's own long help."""
    # CATCHES: the help command is the executed command, so unlike every other
    # `chezmoi help X` invocation it *does* get its `-h, --help` flag printed.
    assert help_text(["help", "help"], home) == HELP_HELP


def test_help_command_usage_line_has_flags_suffix(home):
    """The help command's usage line is `chezmoi help [command] [flags]`."""
    out = help_text(["help", "help"], home)
    # CATCHES: cobra appends `[flags]` only when the command has local flags
    # other than the auto-added help flag -- `help` has none, yet the suffix
    # still appears because the help flag was initialised on it.
    assert "Usage:\n  chezmoi help [command] [flags]\n" in out


def test_add_help_exact(home):
    """`chezmoi add --help` prints Description, Aliases, Examples and Flags."""
    # CATCHES: the long help is the generated markdown prefixed with a
    # Description header, and includes the alias list and the example block.
    assert help_text(["add", "--help"], home) == ADD_HELP


def test_help_add_is_help_minus_the_help_flag(home):
    """`chezmoi help add` differs from `chezmoi add --help` by exactly one line."""
    res_flag = run_chezmoi(["add", "--help"], home=home).stdout
    res_help = run_chezmoi(["help", "add"], home=home).stdout
    # CATCHES: `chezmoi help add` never initialises the automatic help flag on
    # `add`, so its Flags block is missing the `-h, --help` entry.
    assert res_help != res_flag
    assert help_text(["help", "add"], home) == HELP_ADD
    assert res_flag.replace(b"  -h, --help                           help for add\n", b"") == res_help


def test_help_add_extra_arguments_are_ignored(home):
    """`chezmoi help add extra` still prints the help for `add`."""
    # CATCHES: runHelpCmd resolves the deepest matching command and ignores
    # anything after it, rather than erroring on the surplus argument.
    assert help_text(["help", "add", "extra", "more"], home) == HELP_ADD


def test_license_help_exact(home):
    """`chezmoi license --help` prints the license command's long help."""
    # CATCHES: `license` has an Examples section but no Aliases section.
    assert help_text(["license", "--help"], home) == LICENSE_HELP


def test_completion_help_exact(home):
    """`chezmoi completion --help` prints the completion command's long help."""
    # CATCHES: the usage line is `chezmoi completion shell [flags]` -- the
    # positional is named `shell`, and there is no `--custom` flag documented.
    assert help_text(["completion", "--help"], home) == COMPLETION_HELP
    assert "--custom" not in COMPLETION_HELP


def test_generate_help_exact(home):
    """`chezmoi generate --help` lists its three subcommands."""
    # CATCHES: `generate` is a command group; its help shows Available Commands
    # rather than a Description section, because it has no long help of its own.
    assert help_text(["generate", "--help"], home) == GENERATE_HELP


def test_generate_help_has_description_header(home):
    """The `generate` group help starts with a Description section."""
    out = help_text(["generate", "--help"], home)
    # CATCHES: `generate` has its own entry in helps.gen.go, so its help is
    # prefixed with the generated Description header like every other command.
    assert out.startswith("Description\n  Generates output for use with chezmoi.")


def test_help_generate_install_sh_has_no_flags_section(home):
    """`chezmoi help generate install.sh` prints help without a Flags block."""
    # CATCHES: the help flag is only added to the command that actually runs,
    # so a nested `help` target has no local flags at all and the standalone
    # `Flags:` section disappears entirely (only `Global Flags:` remains).
    assert help_text(["help", "generate", "install.sh"], home) == HELP_GENERATE_INSTALL
    assert "Flags:" not in HELP_GENERATE_INSTALL.split("Global Flags:")[0]
    assert HELP_GENERATE_INSTALL.split("Global Flags:")[1].startswith("\n      --age-recipient string")


def test_hidden_remove_command_is_still_reachable(home):
    """`chezmoi rm --help` works even though `remove` is hidden."""
    res = run_chezmoi(["rm", "--help"], home=home)
    # CATCHES: hidden commands are only hidden from listings; they still run,
    # and a deprecated command additionally warns on stderr.
    assert res.returncode == 0
    assert res.stderr == b'Command "remove" is deprecated, use forget or destroy instead\n'
    assert replace_home(res.stdout, home).decode() == RM_HELP


def test_remove_command_help_is_reached_by_canonical_name(home):
    """The hidden remove command's help is rendered under its canonical name."""
    res = run_chezmoi(["remove", "--help"], home=home)
    # CATCHES: cobra renders the usage line from `Use` ("remove"), never from
    # the alias ("rm") that the user typed, and reaching the command by its
    # canonical name still prints the deprecation warning on stderr.
    assert res.returncode == 0
    assert res.stderr == b'Command "remove" is deprecated, use forget or destroy instead\n'
    out = replace_home(res.stdout, home).decode()
    assert out == RM_HELP
    assert "Usage:\n  chezmoi remove [flags]\n" in out
    assert "Aliases:\n  remove, rm\n" in out


def test_deprecated_warning_only_on_invocation(home):
    """The deprecation warning is printed even when the command fails."""
    res = run_chezmoi(["rm"], home=home)
    # CATCHES: runRemoveCmd returns an ExitCodeError(1), which Main turns into
    # a bare exit status -- no `chezmoi: ...` error line is printed at all.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'Command "remove" is deprecated, use forget or destroy instead\n'


def test_hidden_internal_test_command_help(home):
    """`chezmoi internal-test --help` exposes its six prompt subcommands."""
    # CATCHES: `internal-test` is hidden from the root listing but is a fully
    # functional command group with its own subcommands.
    assert help_text(["internal-test", "--help"], home) == INTERNAL_TEST_HELP
    assert "read-password      Read a password\n" in INTERNAL_TEST_HELP


def test_help_for_unknown_command_errors(home):
    """`chezmoi help nosuchcmd` fails with the single-line chezmoi error."""
    res = run_chezmoi(["help", "nosuchcmd"], home=home)
    # CATCHES: runHelpCmd returns `unknown command` when Find fails, which Main
    # renders as one `chezmoi: ...` line on stderr with exit code 1.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'chezmoi: unknown command "nosuchcmd" for "chezmoi"\n'


def test_every_documented_command_help_starts_with_description(home):
    """Every command with generated long help starts with a Description header."""
    commands = [
        "add", "apply", "archive", "cat", "cat-config", "cd", "chattr",
        "completion", "data", "decrypt", "destroy", "diff", "doctor", "dump",
        "dump-config", "edit", "edit-config", "edit-config-template",
        "edit-encrypted", "encrypt", "execute-template", "forget", "generate",
        "git", "ignored", "import", "init", "license", "managed", "merge",
        "merge-all", "purge", "push", "re-add", "secret", "source-path",
        "state", "status", "target-path", "unmanaged", "update", "upgrade",
        "verify",
    ]
    # CATCHES: mustLongHelp prefixes every generated help with "Description";
    # a command whose markdown is missing would panic at startup instead.
    for command in commands:
        res = run_chezmoi([command, "--help"], home=home)
        assert res.returncode == 0, command
        assert res.stdout.startswith(b"Description\n"), command


@pytest.mark.parametrize(
    "argv,expected_usage",
    [
        (["add", "--help"], "  chezmoi add targets... [flags]"),
        (["license", "--help"], "  chezmoi license [flags]"),
        (["completion", "--help"], "  chezmoi completion shell [flags]"),
        (["generate", "--help"], "  chezmoi generate [command]"),
        (["help", "help"], "  chezmoi help [command] [flags]"),
    ],
)
def test_usage_lines(argv, expected_usage, home):
    """Usage lines are rendered from each command's `Use` string verbatim."""
    out = help_text(argv, home)
    # CATCHES: the `Use` field (including its positional-argument placeholder)
    # is reproduced exactly, so `add targets...` is not normalised to `[args]`.
    assert "Usage:\n%s\n" % expected_usage in out


def test_global_flags_block_matches_root_persistent_flags(home):
    """A subcommand's Global Flags block holds the root persistent flags only."""
    out = help_text(["license", "--help"], home)
    block = out.split("Global Flags:\n", 1)[1]
    # CATCHES: `--safe` is a hidden persistent flag, so it is absent here too,
    # and the auto-added `--version` (root-only) never appears either.
    assert "--safe" not in block
    assert "--version" not in block
    assert "  -v, --verbose " in block
    assert block.endswith("  -W, --working-tree path                              Set working tree directory\n")


def test_subcommand_local_flags_are_separate_from_global(home):
    """`add --help` lists add's own flags in Flags: and the root's in Global Flags:"""
    out = help_text(["add", "--help"], home)
    flags, global_flags = out.split("Flags:\n", 1)[1].split("Global Flags:\n")
    # CATCHES: cobra splits a command's own flags from the inherited persistent
    # ones into two differently-titled sections.
    assert "  -T, --template                       Add files as templates\n" in flags
    assert "-T, --template" not in global_flags
    assert "  -n, --dry-run " not in flags
    assert "  -n, --dry-run " in global_flags


def test_generate_install_init_shell_sh_flags(home):
    """`generate install-init-shell.sh --help` documents its three local flags."""
    # CATCHES: the flags are registered with non-zero defaults
    # (`--interactive` and `--shell` default to true), which cobra renders as
    # `(default true)` even for bool flags.
    assert help_text(["generate", "install-init-shell.sh", "--help"], home) == GENERATE_INSTALL_INIT_HELP
    assert "  -i, --interactive              Set interactive (default true)\n" in GENERATE_INSTALL_INIT_HELP
    assert "  -p, --package-manager string   Package manager\n" in GENERATE_INSTALL_INIT_HELP


def test_help_of_generate_subcommand_without_long_help_uses_short(home):
    """`generate install.sh` has no generated long help, so Short is used."""
    out = help_text(["generate", "install.sh", "--help"], home)
    # CATCHES: only top-level commands have entries in helps.gen.go; nested
    # subcommands fall back to their Short description as the first line and
    # never get a generated Description header.
    assert out == GENERATE_INSTALL_SH_HELP
    assert out.startswith("Generate an install script\n")
    assert not out.startswith("Description\n")
    # The flag form is the `help` form plus the auto-added help flag block.
    assert out == HELP_GENERATE_INSTALL.replace(
        "Usage:\n  chezmoi generate install.sh [flags]\n",
        "Usage:\n  chezmoi generate install.sh [flags]\n\nFlags:\n  -h, --help   help for install.sh\n",
    )


def test_help_output_is_not_colorised(home):
    """Help output is byte-identical with NO_COLOR set or unset."""
    plain = run_chezmoi(["license", "--help"], home=home).stdout
    # CATCHES: help is rendered through text/template with no color codes, so
    # the NO_COLOR convention cannot change it and no ESC [ sequence appears.
    assert replace_home(plain, home).decode() == LICENSE_HELP
    no_color = run_chezmoi(
        ["license", "--help"], home=home, extra={"NO_COLOR": "1"}
    ).stdout
    assert no_color == plain
    assert b"\x1b[" not in plain


def test_forget_and_managed_help_use_canonical_usage(home):
    """Alias-having commands render usage from the canonical name."""
    # CATCHES: `forget` (alias unmanage) and `managed` (alias list) print
    # `chezmoi forget ...` and `chezmoi managed ...`, never the alias.
    assert "Usage:\n  chezmoi forget target... [flags]\n" in FORGET_HELP
    assert "Aliases:\n  forget, unmanage\n" in FORGET_HELP
    assert "Usage:\n  chezmoi managed [path]... [flags]\n" in MANAGED_HELP
    assert "Aliases:\n  managed, list\n" in MANAGED_HELP
    assert help_text(["forget", "--help"], home) == FORGET_HELP
    assert help_text(["managed", "--help"], home) == MANAGED_HELP


def test_docker_help_documents_podman_alias(home):
    """`docker --help` documents the `podman` alias."""
    # CATCHES: the alias is declared on the docker command and surfaced in the
    # Aliases section of its help.
    assert "Aliases:\n  docker, podman\n" in DOCKER_HELP
    assert help_text(["docker", "--help"], home) == DOCKER_HELP
