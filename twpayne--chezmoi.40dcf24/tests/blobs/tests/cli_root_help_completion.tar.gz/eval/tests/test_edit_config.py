"""``edit-config``: editor resolution and the post-run config verification.

``edit-config`` is driven by three functions of ``internal/cmd/config.go``:
``editor`` resolves the editor (``edit.command`` verbatim, otherwise
``$VISUAL``/``$EDITOR``/the built-in default, word-split by ``parseCommand``
when the value contains spaces and resolved through ``$PATH`` when it does
not), ``runEditor`` runs it and warns when it returns faster than
``edit.minDuration`` (one second by default), and ``persistentPostRunRootE``
re-reads the config file afterwards, reporting a file that no longer decodes
as a ``warning:`` line while still exiting zero.  Every expectation below was
recorded from ``./executable``.
"""

from __future__ import annotations

import pytest

from conftest import run_chezmoi

# The default location of the config file inside the child's HOME.
CONFIG_NAME = ".config/chezmoi/chezmoi.toml"


@pytest.fixture()
def editor_home(home):
    """A HOME with a bin directory of editor stubs on the child's PATH."""
    bin_dir = home / "bin"
    bin_dir.mkdir()
    return home, bin_dir


def make_editor(bin_dir, name, body):
    """Write an executable editor stub NAME into BIN_DIR."""
    path = bin_dir / name
    path.write_text("#!/bin/sh\n" + body)
    path.chmod(0o755)
    return path


def child_env(home):
    """The child environment: the stub editors come first on PATH."""
    return {"PATH": f"{home}/bin:/usr/bin:/bin"}


def write_config(home, text):
    """Write the default config file and return its path."""
    path = home / CONFIG_NAME
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path


def test_edit_command_receives_the_config_file_path(editor_home):
    """``edit.command`` is run with the config file path as its argument."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "myeditor", 'echo "MYEDITOR args: $*"\n')
    config = write_config(home, '[edit]\ncommand = "myeditor"\n')
    res = run_chezmoi(["edit-config"], home=home, extra=child_env(home))
    # CATCHES: runEditor passes the config file path as the only argument, and
    # the default edit.minDuration of 1s warns because the stub returns at
    # once -- the warning names the unquoted command and the path.
    assert res.returncode == 0
    assert res.stdout == f"MYEDITOR args: {config}\n".encode()
    assert res.stderr == (
        f"chezmoi: warning: myeditor {config}: returned in less than 1s\n".encode()
    )


def test_edit_args_are_prepended_to_the_config_path(editor_home):
    """``edit.args`` are placed between the command and the config path."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "myeditor", 'echo "MYEDITOR args: $*"\n')
    config = write_config(home, '[edit]\ncommand = "myeditor"\nargs = ["prearg"]\n')
    res = run_chezmoi(["edit-config"], home=home, extra=child_env(home))
    # CATCHES: editor() appends the config path to edit.args, so the stub
    # receives "prearg <config>" in that order.
    assert res.returncode == 0
    assert res.stdout == f"MYEDITOR args: prearg {config}\n".encode()
    assert res.stderr == (
        f"chezmoi: warning: myeditor prearg {config}: returned in less than 1s\n".encode()
    )


def test_editor_that_corrupts_the_config_warns_but_exits_zero(editor_home):
    """A config file that no longer parses is reported as a warning."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "badeditor", 'echo "not valid toml {{{" > "$1"\n')
    config = write_config(home, '[edit]\ncommand = "badeditor"\n')
    res = run_chezmoi(["edit-config"], home=home, extra=child_env(home))
    # CATCHES: persistentPostRunRootE re-reads the modified config file after
    # the editor returns and reports the TOML parse error with a `warning:`
    # prefix (not as a failure); the exit code stays 0.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == (
        f"chezmoi: warning: badeditor {config}: returned in less than 1s\n".encode()
        + f"chezmoi: warning: {config}: toml: line 1: "
        "expected '.' or '=', but got 'v' instead\n".encode()
    )
    assert config.read_text() == "not valid toml {{{\n"


def test_editor_that_breaks_a_value_warns_with_the_decode_error(editor_home):
    """A syntactically valid but wrongly typed config also warns."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "badeditor2", 'printf "color = 123\\n" > "$1"\n')
    config = write_config(home, '[edit]\ncommand = "badeditor2"\n')
    res = run_chezmoi(["edit-config"], home=home, extra=child_env(home))
    # CATCHES: the post-run verification decodes the rewritten file into a
    # ConfigFile, so a value of the wrong type is reported as a mapstructure
    # decoding failure, spread over several lines, and the command still
    # exits 0.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == (
        f"chezmoi: warning: badeditor2 {config}: returned in less than 1s\n".encode()
        + f"chezmoi: warning: {config}: decoding failed due to the following "
        "error(s):\n\n'color' expected a bool or string, got a int64\n".encode()
    )


def test_visual_is_word_split_and_preferred_over_editor(editor_home):
    """``$VISUAL`` wins over ``$EDITOR`` and is split into words."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "myeditor", 'echo "MYEDITOR args: $*"\n')
    config = write_config(home, "# no edit configuration\n")
    res = run_chezmoi(
        ["edit-config"],
        home=home,
        extra={**child_env(home), "VISUAL": "myeditor visual", "EDITOR": "myeditor editorvar"},
    )
    # CATCHES: parseCommand splits a $VISUAL containing whitespace into a
    # command and arguments (like a shell would) and $VISUAL is preferred over
    # $EDITOR, so the stub sees "visual <config>".
    assert res.returncode == 0
    assert res.stdout == f"MYEDITOR args: visual {config}\n".encode()
    assert res.stderr == (
        f"chezmoi: warning: myeditor visual {config}: returned in less than 1s\n".encode()
    )


def test_editor_is_used_when_visual_is_unset(editor_home):
    """``$EDITOR`` is the fallback when ``$VISUAL`` is not set."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "myeditor", 'echo "MYEDITOR args: $*"\n')
    config = write_config(home, "# no edit configuration\n")
    res = run_chezmoi(
        ["edit-config"],
        home=home,
        extra={**child_env(home), "EDITOR": "myeditor editorvar"},
    )
    # CATCHES: the editor lookup order is edit.command, $VISUAL, $EDITOR and
    # then the built-in default; a bare $EDITOR is word-split too.
    assert res.returncode == 0
    assert res.stdout == f"MYEDITOR args: editorvar {config}\n".encode()
    assert res.stderr == (
        f"chezmoi: warning: myeditor editorvar {config}: returned in less than 1s\n".encode()
    )


def test_a_bare_editor_name_is_resolved_through_path(editor_home):
    """A single-word ``$EDITOR`` is resolved to its full path."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "myeditor", 'echo "MYEDITOR args: $*"\n')
    config = home / CONFIG_NAME
    res = run_chezmoi(
        ["edit-config"],
        home=home,
        extra={**child_env(home), "EDITOR": "myeditor"},
    )
    # CATCHES: parseCommand runs chezmoi.LookPath first, so a command without
    # spaces is executed by its resolved absolute path -- visible in the
    # minDuration warning, which names the resolved path.
    assert res.returncode == 0
    assert config.parent.is_dir()
    assert res.stdout == f"MYEDITOR args: {config}\n".encode()
    assert res.stderr == (
        f"chezmoi: warning: {home}/bin/myeditor {config}: returned in less than 1s\n".encode()
    )


def test_the_config_directory_is_created_when_missing(editor_home):
    """``edit-config`` creates the config directory if it does not exist."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "myeditor", 'echo "MYEDITOR args: $*"\n')
    config = home / CONFIG_NAME
    res = run_chezmoi(
        ["edit-config"],
        home=home,
        extra={**child_env(home), "EDITOR": "myeditor"},
    )
    # CATCHES: edit-config is annotated requiresConfigDirectory, so the config
    # directory is created before the editor runs even though no config file
    # exists; the editor is then started on the (still missing) file path.
    assert res.returncode == 0
    assert config.parent.is_dir()
    assert not config.exists()
    assert res.stdout == f"MYEDITOR args: {config}\n".encode()


def test_min_duration_is_configurable(editor_home):
    """``edit.minDuration`` is printed with Go's duration formatting."""
    home, bin_dir = editor_home
    make_editor(bin_dir, "myeditor", 'echo "MYEDITOR args: $*"\n')
    config = write_config(home, '[edit]\ncommand = "myeditor"\nminDuration = "1h"\n')
    res = run_chezmoi(["edit-config"], home=home, extra=child_env(home))
    # CATCHES: the warning renders the configured duration as time.Duration's
    # String() would ("1h0m0s" for one hour), not as the configured text.
    assert res.returncode == 0
    assert res.stdout == f"MYEDITOR args: {config}\n".encode()
    assert res.stderr == (
        f"chezmoi: warning: myeditor {config}: returned in less than 1h0m0s\n".encode()
    )
