"""Shared harness for the ``cli_root_help_completion`` module tests.

Every test drives the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hard-coded path).  The main entry point is ``run_chezmoi``, which returns the
completed process with byte-exact ``stdout``/``stderr`` so that recorded
expectations can be asserted verbatim.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path

import pytest

# A fixed, pinned child environment: no dependence on the ambient environment,
# no network, and a PATH that only reaches the standard system programs.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/root",
    "TMPDIR": "/tmp",
    "LANG": "C",
    "LC_ALL": "C",
}

# Temporary homes created for individual runs; cleaned up per test.
_HOMES: list[tempfile.TemporaryDirectory] = []


def executable_path() -> str:
    """Return the candidate path from PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE", "")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; the suite cannot drive the candidate"
        )
    return path


def new_home() -> Path:
    """Create a fresh, empty HOME directory for a single run."""
    temp_dir = tempfile.TemporaryDirectory(prefix="chezmoi-home-")
    _HOMES.append(temp_dir)
    return Path(temp_dir.name)


def make_home(path) -> Path:
    """Ensure PATH exists as a directory and return it (used by fixtures)."""
    home = Path(path)
    home.mkdir(parents=True, exist_ok=True)
    return home


@pytest.fixture(autouse=True)
def _cleanup_homes():
    """Discard the temporary HOME directories created during a test."""
    yield
    while _HOMES:
        _HOMES.pop().cleanup()


@pytest.fixture()
def home(tmp_path):
    """A per-test empty HOME directory for the candidate process."""
    home_dir = tmp_path / "home"
    home_dir.mkdir()
    return home_dir


def merge_env(env=None, extra=None):
    """Build the child environment: BASE_ENV, replaced by env, patched by extra.

    XDG_* and CHEZMOI* variables are stripped so the pinned defaults cannot be
    perturbed by the ambient environment.
    """
    if env is None:
        merged = dict(BASE_ENV)
    else:
        merged = dict(env)
    for key in list(merged):
        if key.startswith(("XDG_", "CHEZMOI")):
            del merged[key]
    if extra:
        merged.update(extra)
    # Coverage instrumentation hook (REQUIRED): copy GOCOVERDIR from the
    # test process environment into the child env when present, so the
    # pipeline can measure source coverage of the reference binary.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    merged.update(cov_env)
    return merged


def run_chezmoi(
    argv,
    *,
    stdin=b"",
    home=None,
    cwd=None,
    env=None,
    extra=None,
    timeout=30,
    umask=None,
):
    """Run the candidate with the argument vector ARGV and return the result.

    ``home`` selects the child's HOME (a fresh empty directory by default, so
    the ``--cache``/``--destination``/``--source`` defaults shown in help are
    deterministic).  ``umask`` pins the child's umask, which chezmoi folds
    into the file modes it reports in diffs.  stdout/stderr are always bytes.
    """
    if home is None:
        home = new_home()
    merged_env = merge_env(env, extra)
    merged_env["HOME"] = str(home)
    data = stdin if isinstance(stdin, bytes) else stdin.encode()
    # Only set preexec_fn when needed: it forces the slower fork path.
    preexec_fn = None
    if umask is not None:
        preexec_fn = lambda: os.umask(umask)  # noqa: E731
    return subprocess.run(
        [executable_path()] + list(argv),
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd else os.getcwd(),
        env=merged_env,
        timeout=timeout,
        preexec_fn=preexec_fn,
    )


def replace_home(data, home):
    """Replace HOME's path in DATA (bytes or str) with ``@HOME@``.

    Help output embeds the derived default directories; normalising them keeps
    the recorded expectations readable and independent of the temp directory.
    """
    home_bytes = str(home).encode()
    if isinstance(data, str):
        return data.replace(str(home), "@HOME@")
    return data.replace(home_bytes, b"@HOME@")


def write_plugin(directory, name, body):
    """Write an executable ``chezmoi-NAME`` plugin into DIRECTORY."""
    path = Path(directory) / ("chezmoi-" + name)
    path.write_text("#!/bin/sh\n" + body, encoding="utf-8")
    path.chmod(0o755)
    return path
