"""Pre- and post-command hooks and the ``CHEZMOI_*`` environment they expose.

``[hooks.<command>.pre]`` / ``[hooks.<command>.post]`` in the config file run
child processes bracketing every command; because they are children of the
chezmoi process they observe both the configuration and the parsed global
flags, which makes them the visible surface of the root command's environment
setup in ``internal/cmd/config.go``.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from conftest import replace_home, run_chezmoi
from expected import LICENSE

# The recorded license text as exact stdout bytes.
LICENSE_BYTES = LICENSE.encode()


def write_config(tmp_path, name, text):
    """Write TEXT to a config file and return its path."""
    path = Path(tmp_path) / name
    path.write_text(text)
    return path


def hook_config(var):
    """A config whose license pre-hook prints the environment variable VAR."""
    return (
        "[hooks.license.pre]\n"
        'command = "printenv"\n'
        f'args = ["{var}"]\n'
    )


def test_pre_and_post_hooks_bracket_the_command_output(tmp_path, home):
    """Pre-hook output precedes and post-hook output follows the command."""
    config = write_config(
        tmp_path,
        "bracket.toml",
        '[hooks.license.pre]\ncommand = "echo"\nargs = ["pre-hook"]\n'
        '[hooks.license.post]\ncommand = "echo"\nargs = ["post-hook"]\n',
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: persistentPreRunRootE runs the pre hook before the command and
    # persistentPostRunRootE the post hook after it, all on the same stdout,
    # so the license text is bracketed by the hook lines in order.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"pre-hook\n" + LICENSE_BYTES + b"post-hook\n"


def test_hook_runs_in_the_home_directory(tmp_path, home):
    """Hook commands execute with HOME as the working directory."""
    config = write_config(
        tmp_path, "pwd.toml", '[hooks.license.pre]\ncommand = "pwd"\n'
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: runHook invokes the hook through c.run with homeDirAbsPath as
    # the process directory, so `pwd` prints HOME, not the caller's cwd.
    assert res.returncode == 0
    assert res.stdout.startswith(str(home).encode() + b"\n")
    assert res.stdout.endswith(LICENSE_BYTES)


def test_hooks_only_run_for_the_matching_command_name(tmp_path, home):
    """A hook configured for another command does not run."""
    config = write_config(
        tmp_path,
        "other.toml",
        '[hooks.add.pre]\ncommand = "echo"\nargs = ["ADD-HOOK"]\n',
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: hooks are looked up by cmd.Name(), so the license run finds no
    # add hook and prints the license text and nothing else.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == LICENSE_BYTES


def test_hook_command_not_found_is_reported(tmp_path, home):
    """A hook command missing from PATH fails with a single error line."""
    config = write_config(
        tmp_path,
        "missing.toml",
        '[hooks.license.pre]\ncommand = "no-such-command-xyz"\n',
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: the hook's exec failure is wrapped by the hook name and the
    # run error, producing `license: pre: <cmd>: exec: ...` and aborting the
    # command before any of its own output.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"chezmoi: license: pre: no-such-command-xyz: "
        b'exec: "no-such-command-xyz": executable file not found in $PATH\n'
    )


def test_pre_hook_failure_aborts_the_command(tmp_path, home):
    """A failing pre hook stops the command from running."""
    config = write_config(
        tmp_path, "pre-fail.toml", '[hooks.license.pre]\ncommand = "false"\n'
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: the pre-hook error propagates out of persistentPreRunRootE so
    # the command itself never runs; the exit status is wrapped as
    # `license: pre: false: exit status 1`.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: license: pre: false: exit status 1\n"


def test_post_hook_failure_follows_the_command_output(tmp_path, home):
    """A failing post hook errors after the command output is printed."""
    config = write_config(
        tmp_path, "post-fail.toml", '[hooks.license.post]\ncommand = "false"\n'
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: persistentPostRunRootE runs after the command, so the license
    # text is already on stdout when the post hook fails, and the wrapped
    # `license: post: ...` error sets the exit code to 1.
    assert res.returncode == 1
    assert res.stdout == LICENSE_BYTES
    assert res.stderr == b"chezmoi: license: post: false: exit status 1\n"


def test_hook_cannot_set_both_command_and_script(tmp_path, home):
    """A hook with both a command and a script is a configuration error."""
    config = write_config(
        tmp_path,
        "both.toml",
        '[hooks.license.pre]\ncommand = "echo"\nscript = "x"\n',
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: runHook rejects hooks that set both fields with `cannot
    # specify both command and script`, wrapped in the hook kind and name.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: license: pre: cannot specify both command and script\n"


def test_script_hook_is_executed_with_arguments(tmp_path, home):
    """A `script` hook is found on PATH and receives the configured args."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    script = bin_dir / "hook.sh"
    script.write_text('#!/bin/sh\necho "script-hook ran: $*"\necho "cwd=$(pwd)"\n')
    script.chmod(0o755)
    config = write_config(
        tmp_path,
        "script.toml",
        '[hooks.license.pre]\nscript = "hook.sh"\nargs = ["one", "two"]\n',
    )
    res = run_chezmoi(
        ["-c", str(config), "license"],
        home=home,
        extra={"PATH": f"{bin_dir}:/usr/bin:/bin"},
    )
    # CATCHES: `.sh` has no interpreter in the default interpreter map, so a
    # script hook is executed directly (resolved via PATH) with the hook's
    # args appended, and runs in the home directory like a command hook.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout.startswith(
        f"script-hook ran: one two\ncwd={home}\n".encode()
    )
    assert res.stdout.endswith(LICENSE_BYTES)


def test_config_env_vars_are_exported_to_hooks(tmp_path, home):
    """`[env]` entries are exported to hook processes."""
    config = write_config(
        tmp_path,
        "env.toml",
        "[env]\nMYVAR = \"from-config\"\nCHEZMOI_RESERVED = \"kept\"\n"
        '[hooks.license.pre]\ncommand = "sh"\n'
        'args = ["-c", "echo MYVAR=$MYVAR RESERVED=$CHEZMOI_RESERVED"]\n',
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: setEnvironmentVariables exports the configured env map before
    # the hooks run (so the hook sees the values) and warns on stderr for
    # keys in the reserved CHEZMOI_ namespace without dropping them.
    assert res.returncode == 0
    assert res.stderr == (
        b"chezmoi: warning: CHEZMOI_RESERVED: "
        b"overriding reserved environment variable\n"
    )
    assert res.stdout.startswith(b"MYVAR=from-config RESERVED=kept\n")
    assert res.stdout.endswith(LICENSE_BYTES)


def test_env_and_scriptenv_are_mutually_exclusive(tmp_path, home):
    """Setting both `env` and `scriptEnv` is an error."""
    config = write_config(
        tmp_path,
        "both-env.toml",
        '[env]\nA = "1"\n[scriptEnv]\nB = "2"\n',
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: setEnvironmentVariables refuses a config that sets both env
    # maps with `only one of env or scriptEnv may be set`, before any output.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: only one of env or scriptEnv may be set\n"


@pytest.mark.parametrize(
    "flag_args,variable,expected",
    [
        (["-S", "/custom-source"], "CHEZMOI_SOURCE_DIR", "/custom-source"),
        (["-D", "/custom-dest"], "CHEZMOI_DEST_DIR", "/custom-dest"),
        (["-W", "/custom-tree"], "CHEZMOI_WORKING_TREE", "/custom-tree"),
        (["--cache", "/custom-cache"], "CHEZMOI_CACHE_DIR", "/custom-cache"),
        (["-v"], "CHEZMOI_VERBOSE", "1"),
    ],
)
def test_global_flags_set_chezmoi_environment(
    flag_args, variable, expected, tmp_path, home
):
    """Each directory/verbosity global flag exports its value to children."""
    config = write_config(tmp_path, "envflag.toml", hook_config(variable))
    res = run_chezmoi(
        ["-c", str(config)] + flag_args + ["license"],
        home=home,
    )
    # CATCHES: the persistent flags registered by newRootCmd feed the
    # template data that persistentPreRunRootE exports as CHEZMOI_* variables,
    # so a hook child observes exactly the directory each flag selected (and
    # -v exports CHEZMOI_VERBOSE=1).
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected.encode() + b"\n" + LICENSE_BYTES


def test_config_flag_sets_chezmoi_config_file(tmp_path, home):
    """-c is reported to children as CHEZMOI_CONFIG_FILE."""
    config = write_config(
        tmp_path, "self.toml", hook_config("CHEZMOI_CONFIG_FILE")
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: CHEZMOI_CONFIG_FILE mirrors the --config path actually used,
    # i.e. the -c value and not the default ~/.config/chezmoi/chezmoi.toml.
    assert res.returncode == 0
    assert res.stdout == str(config).encode() + b"\n" + LICENSE_BYTES


def test_default_chezmoi_environment_variables(tmp_path, home):
    """Without flags the exported directories are the HOME-derived defaults."""
    config = write_config(
        tmp_path,
        "defaults.toml",
        "[hooks.license.pre]\n"
        'command = "printenv"\n'
        'args = ["CHEZMOI_SOURCE_DIR", "CHEZMOI_DEST_DIR", '
        '"CHEZMOI_WORKING_TREE", "CHEZMOI_CACHE_DIR"]\n',
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: with no flags set, the exported source/destination/working
    # tree/cache directories are the XDG defaults under HOME (the working
    # tree falls back to the source directory when no .git is found above it).
    assert res.returncode == 0
    assert res.stderr == b""
    assert replace_home(res.stdout, home).startswith(
        "@HOME@/.local/share/chezmoi\n"
        "@HOME@\n"
        "@HOME@/.local/share/chezmoi\n"
        "@HOME@/.cache/chezmoi\n".encode()
    )
    assert res.stdout.endswith(LICENSE_BYTES)


def test_xdg_data_and_cache_home_override_the_defaults(tmp_path, home):
    """XDG_DATA_HOME/XDG_CACHE_HOME move the exported source/cache dirs."""
    config = write_config(
        tmp_path,
        "xdg.toml",
        "[hooks.license.pre]\n"
        'command = "printenv"\n'
        'args = ["CHEZMOI_SOURCE_DIR", "CHEZMOI_CACHE_DIR"]\n',
    )
    res = run_chezmoi(
        ["-c", str(config), "license"],
        home=home,
        extra={
            "XDG_DATA_HOME": str(tmp_path / "xdgdata"),
            "XDG_CACHE_HOME": str(tmp_path / "xdgcache"),
        },
    )
    # CATCHES: defaultSourceDir and the cache default follow the XDG base
    # directory variables, so a hook sees <XDG_DATA_HOME>/chezmoi and
    # <XDG_CACHE_HOME>/chezmoi instead of the HOME-derived paths.
    assert res.returncode == 0
    assert res.stdout.startswith(
        (
            str(tmp_path / "xdgdata" / "chezmoi")
            + "\n"
            + str(tmp_path / "xdgcache" / "chezmoi")
            + "\n"
        ).encode()
    )
    assert res.stdout.endswith(LICENSE_BYTES)


def test_xdg_config_home_locates_the_config_file(tmp_path, home):
    """The default config file is read from $XDG_CONFIG_HOME/chezmoi."""
    config_dir = tmp_path / "xdgconf" / "chezmoi"
    config_dir.mkdir(parents=True)
    (config_dir / "chezmoi.toml").write_text(hook_config("CHEZMOI_COMMAND"))
    res = run_chezmoi(
        ["license"],
        home=home,
        extra={"XDG_CONFIG_HOME": str(tmp_path / "xdgconf")},
    )
    # CATCHES: defaultConfigFile resolves the config file through the XDG
    # base directories, so with XDG_CONFIG_HOME set the hook defined in
    # $XDG_CONFIG_HOME/chezmoi/chezmoi.toml runs without any -c flag.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"license\n" + LICENSE_BYTES


def test_config_format_flag_overrides_the_file_extension(tmp_path, home):
    """--config-format parses TOML content in a .json-named file."""
    config = write_config(
        tmp_path,
        "actually-toml.json",
        hook_config("CHEZMOI_COMMAND"),
    )
    res = run_chezmoi(
        ["-c", str(config), "--config-format", "toml", "license"],
        home=home,
    )
    # CATCHES: with --config-format toml the config is parsed as TOML
    # regardless of its .json extension, so the hook it defines runs.
    assert res.returncode == 0
    assert res.stdout == b"license\n" + LICENSE_BYTES


def test_config_file_with_a_wrong_extension_is_ignored(tmp_path, home):
    """Without --config-format the parser follows the file extension."""
    config = write_config(
        tmp_path,
        "toml-in-json.json",
        hook_config("CHEZMOI_COMMAND"),
    )
    res = run_chezmoi(["-c", str(config), "license"], home=home)
    # CATCHES: the same TOML file named .json fails to parse as JSON; license
    # is doesNotRequireValidConfig so the error is swallowed and the hook it
    # (would have) defined never runs.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == LICENSE_BYTES
