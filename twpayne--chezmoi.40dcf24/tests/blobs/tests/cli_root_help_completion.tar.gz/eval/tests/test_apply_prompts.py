"""The apply-time prompting flags: ``--force``, ``--interactive``,
``--less-interactive``, ``--no-tty`` and ``--error-on-conflict``.

``defaultPreApplyFunc`` in ``internal/cmd/config.go`` decides, per target,
whether applying needs a confirmation: ``--force`` never prompts, a target that
chezmoi has written before and that changed since is a conflict, and
``--error-on-conflict`` turns a conflict into exit code 1 without any output.
``--no-tty`` moves the prompt from bubbletea to plain stdin/stdout lines, where
the ``diff`` choice renders the diff through ``diffFile`` (``builtinDiffFile``
plus ``pageDiffOutput``, or ``externalDiffFile`` with its temporary directory
when ``[diff] command`` is configured).  Every expectation below was recorded
from ``./executable``.
"""

from __future__ import annotations

import re

import pytest

from conftest import run_chezmoi

# The prompt of --interactive (promptYesNoAll): written to stdout without a
# trailing newline, then a line is read from stdin.
PROMPT_INTERACTIVE = b"Apply .bashrc (diff/yes/no/all/quit)? "
# The prompt of a conflict (promptConflict), used by --less-interactive and by
# the default mode for a target chezmoi has written before.
PROMPT_CONFLICT = (
    b".bashrc has changed since chezmoi last wrote it "
    b"(diff/overwrite/all-overwrite/skip/quit)? "
)

# The builtin diff of the fixture (dest "changed" -> target "original"),
# as printed by the `diff` prompt choice.
DIFF_CHANGED_TO_ORIGINAL = (
    b"diff --git a/.bashrc b/.bashrc\n"
    b"index 5ea2ed416fbd4a4cbe227b75fe255dd7fa6bd4d6"
    b"..4b48deed3a433909bfd6b6ab3d4b91348b6af464 100644\n"
    b"--- a/.bashrc\n"
    b"+++ b/.bashrc\n"
    b"@@ -1 +1 @@\n"
    b"-changed\n"
    b"+original\n"
)


def run_apply(argv, *, home, stdin=b""):
    """Run an apply command with the child's umask pinned to 022.

    chezmoi folds its umask into the file modes of the diffs it prints, so the
    recorded `100644` mode lines only hold when the umask is pinned (the
    pipeline runner itself runs the tests under umask 0002).
    """
    return run_chezmoi(argv, home=home, stdin=stdin, umask=0o022)


@pytest.fixture()
def dirty_target(home):
    """A target applied once and then modified outside of chezmoi."""
    source = home / ".local" / "share" / "chezmoi"
    source.mkdir(parents=True)
    (source / "dot_bashrc").write_text("original\n")
    assert run_apply(["apply"], home=home).returncode == 0
    (home / ".bashrc").write_text("changed\n")
    return home / ".bashrc"


@pytest.fixture()
def unmanaged_target(home):
    """A target that exists on disk but was never written by chezmoi."""
    source = home / ".local" / "share" / "chezmoi"
    source.mkdir(parents=True)
    (source / "dot_bashrc").write_text("original\n")
    (home / ".bashrc").write_text("pre-existing\n")
    return home / ".bashrc"


def test_interactive_diff_choice_prints_the_builtin_diff(dirty_target):
    """Answering `diff` then `yes` shows the diff and applies the target."""
    res = run_apply(
        ["apply", "--interactive", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"diff\nyes\n",
    )
    # CATCHES: the diff choice renders the pending change through diffFile ->
    # builtinDiffFile -> pageDiffOutput, between the two prompts, and `yes`
    # then applies it; the prompt itself has no trailing newline.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_INTERACTIVE + DIFF_CHANGED_TO_ORIGINAL + PROMPT_INTERACTIVE
    assert dirty_target.read_text() == "original\n"


def test_interactive_diff_choice_honours_the_output_flag(tmp_path, dirty_target):
    """The diff shown by the prompt goes to ``-o``, the prompts do not."""
    out = tmp_path / "diff.txt"
    res = run_apply(
        ["apply", "--interactive", "--no-tty", "-o", str(out)],
        home=dirty_target.parent,
        stdin=b"diff\nyes\n",
    )
    # CATCHES: pageDiffOutput writes through writeOutput, so --output
    # redirects only the diff while the prompts keep going to stdout.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_INTERACTIVE + PROMPT_INTERACTIVE
    assert out.read_bytes() == DIFF_CHANGED_TO_ORIGINAL
    assert dirty_target.read_text() == "original\n"


def test_interactive_diff_choice_is_paged(dirty_target):
    """The diff shown by the prompt is filtered by the configured pager."""
    home = dirty_target.parent
    config = home / ".config" / "chezmoi" / "chezmoi.toml"
    config.parent.mkdir(parents=True, exist_ok=True)
    config.write_text('pager = "tr a-z A-Z"\n')
    res = run_apply(
        ["apply", "--interactive", "--no-tty"],
        home=home,
        stdin=b"diff\nyes\n",
    )
    # CATCHES: pageDiffOutput starts the pager with the diff on its stdin, so
    # the diff choice shows the pager's output (here upper-cased) rather than
    # the raw diff.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        PROMPT_INTERACTIVE + DIFF_CHANGED_TO_ORIGINAL.upper() + PROMPT_INTERACTIVE
    )
    assert dirty_target.read_text() == "original\n"


def test_interactive_diff_choice_uses_the_external_diff_command(dirty_target):
    """`[diff] command` receives the target and a temporary copy."""
    home = dirty_target.parent
    config = home / ".config" / "chezmoi" / "chezmoi.toml"
    config.parent.mkdir(parents=True, exist_ok=True)
    config.write_text('[diff]\ncommand = "echo"\nargs = ["EXT"]\n')
    res = run_apply(
        ["apply", "--interactive", "--no-tty"],
        home=home,
        stdin=b"diff\nyes\n",
    )
    # CATCHES: externalDiffFile passes the actual destination path as the
    # "from" file and writes the target contents into a fresh temporary
    # directory (chezmoi-diff-toNNN) for the "to" file.
    assert res.returncode == 0
    assert res.stderr == b""
    normalized = re.sub(
        rb"chezmoi-diff-to\d+", b"chezmoi-diff-toNNN", res.stdout
    )
    assert normalized == (
        PROMPT_INTERACTIVE
        + b"EXT "
        + str(dirty_target).encode()
        + b" /tmp/chezmoi-diff-toNNN/.bashrc\n"
        + PROMPT_INTERACTIVE
    )
    assert dirty_target.read_text() == "original\n"


def test_interactive_no_choice_skips_the_target(dirty_target):
    """Answering `no` leaves the target untouched and exits zero."""
    res = run_apply(
        ["apply", "--interactive", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"no\n",
    )
    # CATCHES: `no` returns fs.SkipDir for the target, so nothing is applied,
    # no error is reported and the exit code is 0.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_INTERACTIVE
    assert dirty_target.read_text() == "changed\n"


def test_interactive_quit_choice_exits_zero(dirty_target):
    """Answering `quit` aborts the apply but still exits zero."""
    res = run_apply(
        ["apply", "--interactive", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"quit\n",
    )
    # CATCHES: quit returns chezmoi.ExitCodeError(0), which Main translates
    # into a zero exit status rather than an error.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_INTERACTIVE
    assert dirty_target.read_text() == "changed\n"


def test_interactive_all_choice_applies_without_further_prompts(dirty_target):
    """Answering `all` applies the target and disables prompting."""
    res = run_apply(
        ["apply", "--interactive", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"all\n",
    )
    # CATCHES: `all` clears c.Interactive for the rest of the run and applies
    # the target, so exactly one prompt is printed.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_INTERACTIVE
    assert dirty_target.read_text() == "original\n"


def test_interactive_invalid_choice_is_asked_again(dirty_target):
    """An unknown answer re-prompts; end of input then fails the target."""
    res = run_apply(
        ["apply", "--interactive", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"bogus\n",
    )
    # CATCHES: readChoice loops on invalid input, so the prompt is printed a
    # second time and the exhausted stdin surfaces as `EOF` wrapped in the
    # target's name.
    assert res.returncode == 1
    assert res.stdout == PROMPT_INTERACTIVE + PROMPT_INTERACTIVE
    assert res.stderr == b"chezmoi: .bashrc: EOF\n"
    assert dirty_target.read_text() == "changed\n"


def test_error_on_conflict_fails_silently_on_a_dirty_target(dirty_target):
    """``--error-on-conflict`` turns the conflict into a bare exit code 1."""
    res = run_apply(["apply", "--error-on-conflict"], home=dirty_target.parent)
    # CATCHES: the conflict is reported as chezmoi.ExitCodeError(1) before any
    # prompt is built, so nothing at all is printed and the target is kept.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b""
    assert dirty_target.read_text() == "changed\n"


def test_error_on_conflict_passes_when_there_is_no_conflict(home):
    """``--error-on-conflict`` does not disturb an ordinary apply."""
    source = home / ".local" / "share" / "chezmoi"
    source.mkdir(parents=True)
    (source / "dot_bashrc").write_text("original\n")
    res = run_apply(["apply", "--error-on-conflict"], home=home)
    # CATCHES: a target chezmoi has never written cannot conflict, so
    # --error-on-conflict leaves the apply alone: the target is created with
    # no output at all, exactly like a plain apply.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (home / ".bashrc").read_text() == "original\n"


def test_error_on_conflict_does_not_stop_the_interactive_prompt(dirty_target):
    """``--interactive`` prompts even together with ``--error-on-conflict``."""
    res = run_apply(
        ["apply", "--interactive", "--error-on-conflict", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"yes\n",
    )
    # CATCHES: --error-on-conflict only short-circuits the conflict prompt;
    # the yes/no/all prompt of --interactive still runs and `yes` applies.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_INTERACTIVE
    assert dirty_target.read_text() == "original\n"


def test_force_applies_a_dirty_target_without_prompting(dirty_target):
    """``--force`` overwrites the changed target silently."""
    res = run_apply(["apply", "--force"], home=dirty_target.parent)
    # CATCHES: --force returns from defaultPreApplyFunc before any prompt
    # mode is selected, so the target is applied with no output at all.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert dirty_target.read_text() == "original\n"


def test_default_mode_prompts_for_a_dirty_target_without_a_tty(dirty_target):
    """Without ``--no-tty`` the conflict prompt needs a TTY and fails."""
    res = run_apply(["apply"], home=dirty_target.parent)
    # CATCHES: in the default mode a dirty target is a conflict, and the
    # bubbletea prompt cannot open /dev/tty when neither stream is a terminal,
    # so the command fails with the target name wrapping the TTY error.
    assert res.returncode == 1
    assert res.stdout == b".bashrc has changed since chezmoi last wrote it?\n"
    assert res.stderr == (
        b"chezmoi: .bashrc: could not open a new TTY: "
        b"open /dev/tty: no such device or address\n"
    )
    assert dirty_target.read_text() == "changed\n"


def test_less_interactive_overwrite_choice_applies(dirty_target):
    """``--less-interactive`` offers the conflict choices; overwrite applies."""
    res = run_apply(
        ["apply", "--less-interactive", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"overwrite\n",
    )
    # CATCHES: --less-interactive uses the overwrite/all-overwrite/skip/quit
    # prompt for a dirty target, and `overwrite` applies just this target.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_CONFLICT
    assert dirty_target.read_text() == "original\n"


def test_less_interactive_skip_choice_keeps_the_target(dirty_target):
    """Answering `skip` at the conflict prompt keeps the changed target."""
    res = run_apply(
        ["apply", "--less-interactive", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"skip\n",
    )
    # CATCHES: `skip` returns fs.SkipDir like `no` does for --interactive.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_CONFLICT
    assert dirty_target.read_text() == "changed\n"


def test_less_interactive_diff_then_overwrite(dirty_target):
    """The conflict prompt also offers the `diff` choice."""
    res = run_apply(
        ["apply", "--less-interactive", "--no-tty"],
        home=dirty_target.parent,
        stdin=b"diff\noverwrite\n",
    )
    # CATCHES: diffFile is reached from the conflict prompt too, and the diff
    # is followed by a fresh prompt before the answer is applied.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == PROMPT_CONFLICT + DIFF_CHANGED_TO_ORIGINAL + PROMPT_CONFLICT
    assert dirty_target.read_text() == "original\n"


def test_less_interactive_error_on_conflict_on_a_pre_existing_target(unmanaged_target):
    """``--less-interactive`` prompts for pre-existing targets too."""
    res = run_apply(
        ["apply", "--less-interactive", "--error-on-conflict"],
        home=unmanaged_target.parent,
    )
    # CATCHES: a target that exists but was never written by chezmoi counts as
    # pre-existing for --less-interactive, so --error-on-conflict fails.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b""
    assert unmanaged_target.read_text() == "pre-existing\n"


def test_default_mode_overwrites_a_pre_existing_target(unmanaged_target):
    """In the default mode a pre-existing target is applied without prompting."""
    res = run_apply(["apply"], home=unmanaged_target.parent)
    # CATCHES: with no last written state the default prompt mode is
    # promptNone, so a pre-existing file is overwritten silently -- only
    # --less-interactive (or a dirty target) would prompt.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert unmanaged_target.read_text() == "original\n"


def test_interactive_diff_of_a_removed_target_diffs_against_dev_null(home):
    """The `diff` choice diffs a missing target against /dev/null."""
    source = home / ".local" / "share" / "chezmoi"
    source.mkdir(parents=True)
    (source / "dot_bashrc").write_text("original\n")
    assert run_apply(["apply"], home=home).returncode == 0
    (home / ".bashrc").unlink()
    res = run_apply(
        ["apply", "--interactive", "--no-tty"],
        home=home,
        stdin=b"diff\nyes\n",
    )
    # CATCHES: when the target is missing its actual state is Remove, so the
    # "from" side of the diff is /dev/null and the diff is a new-file diff.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        PROMPT_INTERACTIVE
        + b"diff --git a/.bashrc b/.bashrc\n"
        b"new file mode 100644\n"
        b"index 0000000000000000000000000000000000000000"
        b"..4b48deed3a433909bfd6b6ab3d4b91348b6af464\n"
        b"--- /dev/null\n"
        b"+++ b/.bashrc\n"
        b"@@ -0,0 +1 @@\n"
        b"+original\n"
        + PROMPT_INTERACTIVE
    )
    assert (home / ".bashrc").read_text() == "original\n"
