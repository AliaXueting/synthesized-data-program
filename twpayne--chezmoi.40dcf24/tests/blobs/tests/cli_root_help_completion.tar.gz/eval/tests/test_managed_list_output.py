"""Output of the ``managed`` command through its ``list`` alias.

``list`` is the documented alias of ``managed``; both render the source
state's target paths through ``Config.writePaths`` / ``Config.marshal`` in
``internal/cmd/config.go`` — plain or NUL-separated path lists, an indented
tree, the four path styles, and the structured `--path-style all` JSON/YAML
dump.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from conftest import replace_home, run_chezmoi


@pytest.fixture()
def source_dir(tmp_path):
    """A minimal source state: one file, two nested dirs, .chezmoiversion."""
    source = tmp_path / "source"
    (source / "dot_config" / "chezmoi").mkdir(parents=True)
    (source / "dot_vim").mkdir()
    (source / "dot_bashrc").write_text("export FOO=1\n")
    (source / "dot_vim" / "vimrc").write_text("syntax on\n")
    (source / "dot_config" / "chezmoi" / "chezmoi.toml").write_text("# config\n")
    (source / ".chezmoiversion").write_text("2.0.0\n")
    return source


def run_list(source_dir, home, *args):
    """Run `chezmoi -S SOURCE list ARGS...` and return the result."""
    return run_chezmoi(
        ["-S", str(source_dir), "list", *args],
        home=home,
    )


def normalize(data, home, source_dir):
    """Replace HOME and the source directory with placeholders."""
    text = replace_home(data, home)
    if isinstance(text, bytes):
        return text.replace(str(source_dir).encode(), b"@SRC@")
    return text.replace(str(source_dir), "@SRC@")


# The six target paths of the fixture, relative to the destination directory.
RELATIVE_PATHS = (
    ".bashrc\n"
    ".config\n"
    ".config/chezmoi\n"
    ".config/chezmoi/chezmoi.toml\n"
    ".vim\n"
    ".vim/vimrc\n"
)


def test_list_alias_prints_the_same_as_managed(source_dir, home):
    """`list` resolves to `managed` and prints the sorted target paths."""
    alias = run_list(source_dir, home)
    canonical = run_chezmoi(
        ["-S", str(source_dir), "managed"], home=home
    )
    # CATCHES: the list alias must produce byte-identical output to the
    # canonical managed command: the sorted list of target paths, one per
    # line, with the dot_ prefix stripped and .chezmoiversion itself absent.
    assert alias.returncode == 0
    assert alias.stderr == b""
    assert alias.stdout == RELATIVE_PATHS.encode()
    assert canonical.stdout == alias.stdout


def test_list_nul_path_separator(source_dir, home):
    """-0 separates paths with NUL instead of newline."""
    res = run_list(source_dir, home, "-0")
    # CATCHES: writePaths switches the path separator byte to NUL, so the
    # output is every path NUL-terminated with no newlines at all.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == RELATIVE_PATHS.replace("\n", "\x00").encode()


def test_list_tree_format(source_dir, home):
    """-t prints the paths as a two-space-indented tree."""
    res = run_list(source_dir, home, "-t")
    # CATCHES: the tree renderer indents each level by two spaces and prints
    # directory names without trailing separators, in sorted order.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        ".bashrc\n"
        ".config\n"
        "  chezmoi\n"
        "    chezmoi.toml\n"
        ".vim\n"
        "  vimrc\n"
    ).encode()


@pytest.mark.parametrize(
    "path_style,expected",
    [
        (
            "relative",
            RELATIVE_PATHS,
        ),
        (
            "absolute",
            "@HOME@/.bashrc\n"
            "@HOME@/.config\n"
            "@HOME@/.config/chezmoi\n"
            "@HOME@/.config/chezmoi/chezmoi.toml\n"
            "@HOME@/.vim\n"
            "@HOME@/.vim/vimrc\n",
        ),
        (
            "source-absolute",
            "@SRC@/dot_bashrc\n"
            "@SRC@/dot_config\n"
            "@SRC@/dot_config/chezmoi\n"
            "@SRC@/dot_config/chezmoi/chezmoi.toml\n"
            "@SRC@/dot_vim\n"
            "@SRC@/dot_vim/vimrc\n",
        ),
        (
            "source-relative",
            "dot_bashrc\n"
            "dot_config\n"
            "dot_config/chezmoi\n"
            "dot_config/chezmoi/chezmoi.toml\n"
            "dot_vim\n"
            "dot_vim/vimrc\n",
        ),
    ],
)
def test_list_path_styles(path_style, expected, source_dir, home):
    """-p selects the target/destination or source naming of each path."""
    res = run_list(source_dir, home, "-p", path_style)
    # CATCHES: each path style renders the same entries against a different
    # base — the destination-relative target name, the destination-absolute
    # path, or the source-absolute/relative path with its dot_ prefix.
    assert res.returncode == 0
    assert res.stderr == b""
    assert normalize(res.stdout, home, source_dir) == expected.encode()


# The `--path-style all` structured dump: one record per target path with the
# destination-absolute, source-absolute and source-relative names.
ALL_JSON = (
    "{\n"
    '  ".bashrc": {\n'
    '    "absolute": "@HOME@/.bashrc",\n'
    '    "sourceAbsolute": "@SRC@/dot_bashrc",\n'
    '    "sourceRelative": "dot_bashrc"\n'
    "  },\n"
    '  ".config": {\n'
    '    "absolute": "@HOME@/.config",\n'
    '    "sourceAbsolute": "@SRC@/dot_config",\n'
    '    "sourceRelative": "dot_config"\n'
    "  },\n"
    '  ".config/chezmoi": {\n'
    '    "absolute": "@HOME@/.config/chezmoi",\n'
    '    "sourceAbsolute": "@SRC@/dot_config/chezmoi",\n'
    '    "sourceRelative": "dot_config/chezmoi"\n'
    "  },\n"
    '  ".config/chezmoi/chezmoi.toml": {\n'
    '    "absolute": "@HOME@/.config/chezmoi/chezmoi.toml",\n'
    '    "sourceAbsolute": "@SRC@/dot_config/chezmoi/chezmoi.toml",\n'
    '    "sourceRelative": "dot_config/chezmoi/chezmoi.toml"\n'
    "  },\n"
    '  ".vim": {\n'
    '    "absolute": "@HOME@/.vim",\n'
    '    "sourceAbsolute": "@SRC@/dot_vim",\n'
    '    "sourceRelative": "dot_vim"\n'
    "  },\n"
    '  ".vim/vimrc": {\n'
    '    "absolute": "@HOME@/.vim/vimrc",\n'
    '    "sourceAbsolute": "@SRC@/dot_vim/vimrc",\n'
    '    "sourceRelative": "dot_vim/vimrc"\n'
    "  }\n"
    "}\n"
)

ALL_YAML = (
    ".bashrc:\n"
    "  absolute: @HOME@/.bashrc\n"
    "  sourceAbsolute: @SRC@/dot_bashrc\n"
    "  sourceRelative: dot_bashrc\n"
    ".config:\n"
    "  absolute: @HOME@/.config\n"
    "  sourceAbsolute: @SRC@/dot_config\n"
    "  sourceRelative: dot_config\n"
    ".config/chezmoi:\n"
    "  absolute: @HOME@/.config/chezmoi\n"
    "  sourceAbsolute: @SRC@/dot_config/chezmoi\n"
    "  sourceRelative: dot_config/chezmoi\n"
    ".config/chezmoi/chezmoi.toml:\n"
    "  absolute: @HOME@/.config/chezmoi/chezmoi.toml\n"
    "  sourceAbsolute: @SRC@/dot_config/chezmoi/chezmoi.toml\n"
    "  sourceRelative: dot_config/chezmoi/chezmoi.toml\n"
    ".vim:\n"
    "  absolute: @HOME@/.vim\n"
    "  sourceAbsolute: @SRC@/dot_vim\n"
    "  sourceRelative: dot_vim\n"
    ".vim/vimrc:\n"
    "  absolute: @HOME@/.vim/vimrc\n"
    "  sourceAbsolute: @SRC@/dot_vim/vimrc\n"
    "  sourceRelative: dot_vim/vimrc\n"
)


@pytest.mark.parametrize(
    "args,expected",
    [
        (["--path-style", "all"], ALL_JSON),
        (["--path-style", "all", "--format", "json"], ALL_JSON),
        (["--path-style", "all", "--format", "yaml"], ALL_YAML),
    ],
)
def test_list_path_style_all_structured_dump(args, expected, source_dir, home):
    """--path-style all marshals the entries as JSON or YAML."""
    res = run_list(source_dir, home, *args)
    # CATCHES: with path style all the entries go through marshal: every
    # target path maps to its absolute/sourceAbsolute/sourceRelative names,
    # rendered as indented JSON (the default, also selected by --format
    # json) or as YAML.
    assert res.returncode == 0
    assert res.stderr == b""
    assert normalize(res.stdout, home, source_dir) == expected.encode()


def test_list_output_flag_writes_to_a_file(source_dir, home, tmp_path):
    """-o redirects the path list into a file."""
    target = tmp_path / "managed.txt"
    res = run_chezmoi(
        ["-S", str(source_dir), "-o", str(target), "list"], home=home
    )
    # CATCHES: writePaths writes through writeOutputString, which honours
    # the global -o flag, so the file receives the exact path list that
    # would otherwise go to stdout, and stdout stays empty.
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert target.read_bytes() == RELATIVE_PATHS.encode()


def test_list_rejects_toml_format(source_dir, home):
    """`managed --format` accepts only json and yaml."""
    res = run_list(source_dir, home, "--path-style", "all", "--format", "toml")
    # CATCHES: the --format choice flag of the managed command is restricted
    # to json/yaml, so toml is rejected as an invalid flag argument.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'chezmoi: invalid argument "toml" for "-f, --format" flag: '
        b"invalid value\n"
    )


def test_invalid_chezmoiversion_is_rejected(source_dir, home):
    """A malformed .chezmoiversion aborts the command with its raw bytes."""
    (source_dir / ".chezmoiversion").write_text("not-a-version\n")
    res = run_list(source_dir, home)
    # CATCHES: checkVersion parses the source state's .chezmoiversion and
    # reports a parse failure naming the file and its raw contents (Go-quoted,
    # so the trailing newline appears as \n) on a single stderr line.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        f'chezmoi: {source_dir}/.chezmoiversion: "not-a-version\\n": '
        f"not is not in dotted-tri format\n".encode()
    )
