"""`--version` output of the root command.

The reference binary was built with
``-X main.builtBy=source`` and no ``-X main.version``, so the version string is
assembled at runtime as ``version <version>, commit <sha>, built at <rfc3339>,
built by <builtBy>`` with the commit and date filled in from Go's build info.

The exact commit and build date are properties of the build, not of the
program, so these tests pin the *shape* of the line; the reference's own value
at recording time was::

    chezmoi version dev, commit 40dcf243fbdda2b8dc912aa02f7ddb2219b96f6b, built at 2026-10-16T14:44:24Z, built by source
"""

from __future__ import annotations

import re

from conftest import run_chezmoi

# Shape of the reference's version line.
VERSION_RE = re.compile(
    rb"^chezmoi version [^,]+"
    rb"(, commit [0-9a-f]+(?:-dirty)?)?"
    rb"(, built at \S+)?"
    rb"(, built by \S+)?\n$"
)


def test_version_is_a_single_stdout_line(home):
    """`--version` prints one line to stdout and exits 0."""
    res = run_chezmoi(["--version"], home=home)
    # CATCHES: the version goes to stdout (not stderr) as a single
    # newline-terminated line, and the process exits 0.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout.count(b"\n") == 1
    assert res.stdout.endswith(b"\n")


def test_version_line_shape(home):
    """The version line is `chezmoi version <v>, commit <sha>, built at <d>, built by <b>`."""
    res = run_chezmoi(["--version"], home=home)
    # CATCHES: the version string is assembled from the VersionInfo fields by
    # joining the non-empty elements with ", " -- a re-implementation that
    # dropped the "commit"/"built at" elements or changed their wording fails.
    assert VERSION_RE.match(res.stdout), res.stdout
    assert res.stdout.startswith(b"chezmoi version ")
    assert b", commit " in res.stdout
    assert b", built at " in res.stdout
    assert b", built by " in res.stdout


def test_version_flag_wins_over_positional_arguments(home):
    """`chezmoi --version license` prints the version and ignores `license`."""
    res = run_chezmoi(["--version", "license"], home=home)
    # CATCHES: cobra checks the version flag before validating arguments, so
    # the surplus argument never becomes an "unknown command" error and the
    # full version line is still printed.
    assert res.returncode == 0
    assert res.stderr == b""
    assert VERSION_RE.match(res.stdout), res.stdout
    assert res.stdout == run_chezmoi(["--version"], home=home).stdout


def test_version_flag_wins_over_unknown_flags_after_it(home):
    """`--version` is checked after flag parsing, so bad flags still win."""
    res = run_chezmoi(["--version", "--frob"], home=home)
    # CATCHES: flag parsing happens first, so an unknown flag after --version
    # is still reported as an error rather than being ignored.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"chezmoi: unknown flag: --frob\n"


def test_no_uppercase_version_shorthand(home):
    """There is no `-V` shorthand; only `--version` exists."""
    res = run_chezmoi(["-V"], home=home)
    # CATCHES: the version flag is registered without a shorthand, so `-V` is
    # an unknown shorthand flag.
    assert res.returncode == 1
    assert res.stderr == b"chezmoi: unknown shorthand flag: 'V' in -V\n"


def test_version_is_only_listed_in_root_help(home):
    """`--version` appears in the root flag list but not in a subcommand's."""
    root = run_chezmoi(["--help"], home=home).stdout
    sub = run_chezmoi(["license", "--help"], home=home).stdout
    # CATCHES: the auto-added version flag belongs to the root command only,
    # so it shows up in the root flag block and never in Global Flags.
    assert b"--version                                        version for chezmoi\n" in root
    assert b"--version" not in sub
