"""Value completion for the root command's persistent flags.

The global flags registered in ``newRootCmd`` carry flag completion
functions: the ``autoBool`` flags offer the bool + ``auto`` spellings,
``--config-format`` and ``--mode`` offer their choice lists, and
``--refresh-externals`` (which has a NoOptDefVal) completes the next word
instead of a value.  Everything is driven through the hidden ``__complete``
command that the generated shell scripts invoke.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from conftest import run_chezmoi

DATA_DIR = Path(__file__).parent / "data"

# The `__complete` machinery's fixed stderr trailer for these directives.
NO_FILE_COMP = b"Completion ended with directive: ShellCompDirectiveNoFileComp\n"

# Every value an autoBool flag offers, in registration order.
AUTO_BOOL_VALUES = (
    b"1\nt\nT\ntrue\nTRUE\nTrue\n0\nf\nF\nfalse\nFALSE\nFalse\n"
    b"auto\nAUTO\nAuto\n:4\n"
)

# The root command's subcommand list offered by `__complete ""` (recorded).
ROOT_COMPLETION = (DATA_DIR / "root_command_completion.txt").read_bytes()


@pytest.mark.parametrize(
    "flag",
    ["--color", "--progress", "--use-builtin-age", "--use-builtin-git"],
)
def test_auto_bool_flags_offer_bool_and_auto_values(flag, home):
    """The autoBool flags complete the bool spellings plus `auto`."""
    res = run_chezmoi(["__complete", flag, ""], home=home)
    # CATCHES: --color, --progress and the --use-builtin-* flags are
    # registered with the shared autoBool completion, offering exactly the
    # strconv bool spellings (both cases) plus auto/AUTO/Auto, and ending
    # with the NoFileComp directive so the shell offers no filenames.
    assert res.returncode == 0
    assert res.stdout == AUTO_BOOL_VALUES
    assert res.stderr == NO_FILE_COMP


def test_auto_bool_completion_filters_by_prefix(home):
    """A typed prefix narrows the autoBool offers."""
    res = run_chezmoi(["__complete", "--color", "t"], home=home)
    # CATCHES: only the values starting with the prefix survive (here `t`
    # and `true`, not `TRUE` or `True`), still followed by the directive.
    assert res.returncode == 0
    assert res.stdout == b"t\ntrue\n:4\n"
    assert res.stderr == NO_FILE_COMP


def test_config_format_flag_completion_offers_formats(home):
    """--config-format completes the (empty) default and the three formats."""
    res = run_chezmoi(["__complete", "--config-format", ""], home=home)
    # CATCHES: the choice list includes the empty value first (the
    # extension-based default) before json/toml/yaml, so the completion
    # output begins with an empty line.
    assert res.returncode == 0
    assert res.stdout == b"\njson\ntoml\nyaml\n:4\n"
    assert res.stderr == NO_FILE_COMP


def test_mode_flag_completion_offers_modes(home):
    """--mode completes the two target modes."""
    res = run_chezmoi(["__complete", "--mode", ""], home=home)
    # CATCHES: --mode is a choice flag with exactly `file` and `symlink`.
    assert res.returncode == 0
    assert res.stdout == b"file\nsymlink\n:4\n"
    assert res.stderr == NO_FILE_COMP


def test_refresh_externals_flag_takes_no_value(home):
    """--refresh-externals has a default value, so it completes a command."""
    res = run_chezmoi(["__complete", "--refresh-externals", ""], home=home)
    # CATCHES: --refresh-externals is registered with NoOptDefVal (the bare
    # flag means `always`), so completing the following word offers the
    # root command's subcommand list rather than refresh values.
    assert res.returncode == 0
    assert res.stdout == ROOT_COMPLETION
    assert res.stderr == NO_FILE_COMP
    # Hidden commands and aliases are not offered, but `help` is.
    for name in (
        b"internal-test",
        b"remove",
        b"list",
        b"manage",
        b"unmanage",
        b"rm",
        b"podman",
        b"__complete",
    ):
        assert name + b"\t" not in res.stdout
    assert b"help\tPrint help about a command\n" in res.stdout


def test_flag_completion_works_after_the_subcommand(home):
    """Persistent flag completion is available in subcommand context."""
    res = run_chezmoi(["__complete", "license", "--color", ""], home=home)
    # CATCHES: the root's persistent flags belong to every subcommand, so
    # completing `license --color <TAB>` offers the same autoBool values as
    # at the root level.
    assert res.returncode == 0
    assert res.stdout == AUTO_BOOL_VALUES
    assert res.stderr == NO_FILE_COMP
