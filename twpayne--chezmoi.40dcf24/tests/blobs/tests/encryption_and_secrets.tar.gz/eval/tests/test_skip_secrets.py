"""The --skip-secrets safety net.

With --skip-secrets, any template calling a secret-function (or encrypt)
fails with "skip template" instead of invoking the backing command, both
for execute-template and for apply of a source template.
"""

import pytest

from conftest import TemplateRunner, age_keypair, make_home, run_chezmoi

SKIP_CASES = [
    pytest.param(
        "bitwarden", "",
        'x {{ (bitwarden "item").password }} y',
        'chezmoi: template: arg1:1:6: executing "arg1" at <bitwarden "item">: '
        "error calling bitwarden: skip template\n",
        id="bitwarden",
    ),
    pytest.param(
        "onepassword", "prompt = false",
        'x {{ (onepassword "item").fields }} y',
        'chezmoi: template: arg1:1:6: executing "arg1" at <onepassword "item">: '
        "error calling onepassword: skip template\n",
        id="onepassword",
    ),
    pytest.param(
        "gopass", "",
        'x {{ gopass "s" }} y',
        'chezmoi: template: arg1:1:5: executing "arg1" at <gopass "s">: '
        "error calling gopass: skip template\n",
        id="gopass",
    ),
    pytest.param(
        "pass", "",
        'x {{ pass "s" }} y',
        'chezmoi: template: arg1:1:5: executing "arg1" at <pass "s">: '
        "error calling pass: skip template\n",
        id="pass",
    ),
    pytest.param(
        "vault", "",
        'x {{ (vault "s").d }} y',
        'chezmoi: template: arg1:1:6: executing "arg1" at <vault "s">: '
        "error calling vault: skip template\n",
        id="vault",
    ),
    pytest.param(
        "secret", "",
        'x {{ secret "s" }} y',
        'chezmoi: template: arg1:1:5: executing "arg1" at <secret "s">: '
        "error calling secret: skip template\n",
        id="secret",
    ),
    pytest.param(
        "", "",
        '{{ keyring "s" "u" }}',
        'chezmoi: template: arg1:1:3: executing "arg1" at <keyring "s" "u">: '
        "error calling keyring: skip template\n",
        id="keyring",
    ),
    pytest.param(
        "keepassxc", 'database = "/nonexistent.kdbx"',
        '{{ keepassxc "e" }}',
        'chezmoi: template: arg1:1:3: executing "arg1" at <keepassxc "e">: '
        "error calling keepassxc: skip template\n",
        id="keepassxc",
    ),
    pytest.param(
        "azureKeyVault", 'defaultVault = "myvault"',
        '{{ azureKeyVault "s" }}',
        'chezmoi: template: arg1:1:3: executing "arg1" at <azureKeyVault "s">: '
        "error calling azureKeyVault: skip template\n",
        id="azureKeyVault",
    ),
    pytest.param(
        "awsSecretsManager", 'region = "us-east-1"',
        '{{ awsSecretsManagerRaw "arn:x" }}',
        'chezmoi: template: arg1:1:3: executing "arg1" '
        'at <awsSecretsManagerRaw "arn:x">: '
        "error calling awsSecretsManagerRaw: skip template\n",
        id="awsSecretsManagerRaw",
    ),
    pytest.param(
        "awsSecretsManager", 'region = "us-east-1"',
        '{{ (awsSecretsManager "arn:x").p }}',
        'chezmoi: template: arg1:1:4: executing "arg1" '
        'at <awsSecretsManager "arn:x">: '
        "error calling awsSecretsManager: skip template\n",
        id="awsSecretsManager",
    ),
]


@pytest.mark.parametrize(
    ("section", "extra_cfg", "template", "expected_stderr"), SKIP_CASES
)
def test_skip_secrets_skips_secret_functions(
    tmp_path, section, extra_cfg, template, expected_stderr
):
    """--skip-secrets aborts each secret template function identically."""
    r = TemplateRunner(tmp_path, make_home(tmp_path))
    result = r.run(
        section,
        template,
        extra_cfg=extra_cfg,
        flags=["--skip-secrets"],
    )
    # CATCHES: every secret function family is gated by the same flag - the
    # template execution fails with "skip template" naming the function,
    # and the backing command is never invoked.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == expected_stderr
    assert not r.log.exists()


def test_skip_secrets_skips_encrypt(tmp_path):
    """--skip-secrets also gates the encrypt template function."""
    r = TemplateRunner(tmp_path, make_home(tmp_path))
    identity, recipient = age_keypair(tmp_path, r.home)
    result = r.run(
        "",
        'x {{ encrypt "hello" }} y',
        extra_cfg='encryption = "age"\n[age]\nrecipient = "%s"\n' % recipient,
        flags=["--skip-secrets"],
    )
    # CATCHES: even a fully configured encryption setup is skipped under
    # --skip-secrets, so no ciphertext is produced.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'chezmoi: template: arg1:1:5: executing "arg1" at <encrypt "hello">: '
        "error calling encrypt: skip template\n"
    )


def test_skip_secrets_skips_apply(tmp_path):
    """apply --skip-secrets leaves a secret-using template unmaterialized."""
    home = make_home(tmp_path)
    r = TemplateRunner(tmp_path, home)
    config = r.config("secret", "")
    source = home / ".local/share/chezmoi/secret_file.txt.tmpl"
    source.write_text('p = {{ secret "item1" }}\n')

    skipped = run_chezmoi(
        ["--config", config, "--skip-secrets", "apply"],
        cwd=home,
        home=home,
        env={"FAKE_LOG": r.log, "FAKE_STDIN_LOG": "", "FAKE_OUT": "sekret-value\n"},
    )
    # CATCHES: apply succeeds (exit 0) but simply omits the target whose
    # template uses a secret - it neither renders nor errors.
    assert skipped.returncode == 0
    assert skipped.stdout == b""
    assert skipped.stderr == b""
    assert not (home / "secret_file.txt").exists()

    applied = run_chezmoi(
        ["--config", config, "apply"],
        cwd=home,
        home=home,
        env={"FAKE_LOG": r.log, "FAKE_STDIN_LOG": "", "FAKE_OUT": "sekret-value\n"},
    )
    # CATCHES: without the flag the same template renders with the trimmed
    # secret value.
    assert applied.returncode == 0
    assert (home / "secret_file.txt").read_text() == "p = sekret-value\n"
