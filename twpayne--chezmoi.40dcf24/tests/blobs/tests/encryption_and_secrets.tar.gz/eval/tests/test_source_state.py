"""Encryption in the source state: add/cat/status/verify/apply/diff/chattr.

Covers the end-to-end lifecycle of encrypted files: `add --encrypt`
creating encrypted_<name><suffix> source files, transparent decryption by
cat/apply/status/verify/diff, attribute changes with chattr, configurable
suffixes, transparent encryption, encrypted and plain externals, edit and
edit-encrypted re-encryption, and a real gpg roundtrip.
"""

import os
import re
import subprocess

import pytest

from conftest import (
    MINIMAL_PATH,
    age_keypair,
    make_home,
    run_chezmoi,
    write_config,
    write_script,
)


def age_config(tmp_path, home, extra=""):
    """A config with a fresh age key pair; returns (config, recipient)."""
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\nrecipient = "%s"\nidentity = "%s"\n%s'
        % (recipient, identity, extra),
    )
    return config, recipient


def test_add_encrypt_creates_encrypted_source_file(tmp_path):
    """`add --encrypt` stores the file as encrypted_<name>.age in the source."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    (home / "secret.txt").write_text("secret contents\n")
    result = run_chezmoi(
        ["--config", config, "add", "--encrypt", "secret.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: the source file is renamed with the encrypted_ prefix and the
    # .age suffix, and holds age ASCII armor rather than the plaintext.
    assert result.returncode == 0
    source = home / ".local/share/chezmoi/encrypted_secret.txt.age"
    assert source.exists()
    assert source.read_text().startswith("-----BEGIN AGE ENCRYPTED FILE-----\n")

    cat = run_chezmoi(
        ["--config", config, "cat", "secret.txt"], cwd=home, home=home
    )
    assert cat.returncode == 0
    assert cat.stdout == b"secret contents\n"


def test_status_and_verify_in_sync(tmp_path):
    """status and verify are silent and successful when nothing changed."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    (home / "secret.txt").write_text("secret contents\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "secret.txt"],
        cwd=home,
        home=home,
    )
    status = run_chezmoi(
        ["--config", config, "status"], cwd=home, home=home
    )
    verify = run_chezmoi(
        ["--config", config, "verify"], cwd=home, home=home
    )
    # CATCHES: an in-sync encrypted target produces no status output and a
    # zero exit from verify, proving the decryption round-tripped exactly.
    assert status.returncode == 0
    assert status.stdout == b""
    assert status.stderr == b""
    assert verify.returncode == 0
    assert verify.stdout == b""
    assert verify.stderr == b""


def test_apply_prompts_when_target_removed(tmp_path):
    """Removing the target makes apply prompt before recreating it."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    (home / "secret.txt").write_text("secret contents\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "secret.txt"],
        cwd=home,
        home=home,
    )
    (home / "secret.txt").unlink()
    result = run_chezmoi(["--config", config, "apply"], cwd=home, home=home)
    # CATCHES: because the persistent state says chezmoi wrote the file but
    # it is now missing, apply asks "has changed since chezmoi last wrote
    # it?" on stdout and then fails on the unavailable TTY - the file is
    # not recreated without an answer.
    assert result.returncode == 1
    assert result.stdout == b"secret.txt has changed since chezmoi last wrote it?\n"
    assert result.stderr == (
        b"chezmoi: secret.txt: could not open a new TTY: "
        b"open /dev/tty: no such device or address\n"
    )
    assert not (home / "secret.txt").exists()


def test_apply_force_recreates_removed_target(tmp_path):
    """`apply --force` recreates a removed encrypted target without prompting."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    (home / "secret.txt").write_text("secret contents\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "secret.txt"],
        cwd=home,
        home=home,
    )
    (home / "secret.txt").unlink()
    result = run_chezmoi(
        ["--config", config, "apply", "--force"], cwd=home, home=home
    )
    # CATCHES: --force answers the persistent-state prompt affirmatively,
    # so the decrypted contents are rewritten byte for byte.
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert (home / "secret.txt").read_text() == "secret contents\n"


def test_status_reports_modified_target(tmp_path):
    """A locally modified target is reported as MM by status."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    (home / "secret.txt").write_text("secret contents\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "secret.txt"],
        cwd=home,
        home=home,
    )
    (home / "secret.txt").write_text("modified\n")
    result = run_chezmoi(
        ["--config", config, "status"], cwd=home, home=home
    )
    # CATCHES: both status columns are set (source state differs from the
    # actual file and the entry would modify the actual file).
    assert result.returncode == 0
    assert result.stdout == b"MM secret.txt\n"
    assert result.stderr == b""


def test_verify_fails_silently_when_modified(tmp_path):
    """verify exits non-zero for a modified target but prints nothing."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    (home / "secret.txt").write_text("secret contents\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "secret.txt"],
        cwd=home,
        home=home,
    )
    (home / "secret.txt").write_text("modified\n")
    result = run_chezmoi(
        ["--config", config, "verify"], cwd=home, home=home
    )
    # CATCHES: verify signals the mismatch only through its exit code -
    # neither the differing content nor an error message is printed.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b""


def test_diff_shows_plaintext_changes(tmp_path):
    """diff of an encrypted target shows the decrypted plaintext."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    target = home / "secret.txt"
    target.write_text("secret contents\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "secret.txt"],
        cwd=home,
        home=home,
    )
    target.write_text("modified\n")
    # Give the file the mode the target entry computes (0666 masked by the
    # current umask) so the diff reports only the content change.
    umask = os.umask(0)
    os.umask(umask)
    default_mode = 0o666 & ~umask
    target.chmod(default_mode)
    result = run_chezmoi(["--config", config, "diff"], cwd=home, home=home)
    # CATCHES: diff decrypts the source state and compares plaintexts, so
    # the git-style hunks (including content-derived blob hashes) refer to
    # the plaintext, never the ciphertext.
    assert result.returncode == 0
    assert result.stdout == (
        b"diff --git a/secret.txt b/secret.txt\n"
        b"index 2e0996000b7e9019eabcad29391bf0f5c7702f0b"
        b"..f220556a13cdf13cc3b99a1ec5f0825f08d7bb24 100%o\n" % default_mode
        + b"--- a/secret.txt\n"
        b"+++ b/secret.txt\n"
        b"@@ -1 +1 @@\n"
        b"-modified\n"
        b"+secret contents\n"
    )
    assert result.stderr == b""


def test_chattr_toggles_encrypted_attribute(tmp_path):
    """chattr +encrypted encrypts a plain source file, and - undoes it."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    (home / "plain.txt").write_text("plain data\n")
    run_chezmoi(
        ["--config", config, "add", "plain.txt"], cwd=home, home=home
    )
    added = run_chezmoi(
        ["--config", config, "chattr", "+encrypted", "plain.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: +encrypted renames the source file to encrypted_plain.txt.age
    # (encrypting the contents) and the file still decrypts transparently.
    assert added.returncode == 0
    assert (home / ".local/share/chezmoi/encrypted_plain.txt.age").exists()
    cat = run_chezmoi(
        ["--config", config, "cat", "plain.txt"], cwd=home, home=home
    )
    assert cat.returncode == 0
    assert cat.stdout == b"plain data\n"

    removed = run_chezmoi(
        ["--config", config, "chattr", "--", "-encrypted", "plain.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: -encrypted decrypts the source file back to plain.txt with
    # the plaintext contents.
    assert removed.returncode == 0
    source = home / ".local/share/chezmoi/plain.txt"
    assert source.exists()
    assert source.read_text() == "plain data\n"


def test_chattr_requires_two_args(tmp_path):
    """chattr without attributes reports the argument shortfall."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    result = run_chezmoi(
        ["--config", config, "chattr"], cwd=home, home=home
    )
    # CATCHES: chattr needs at least one attribute and one target; the
    # error spells out the minimum and the number received.
    assert result.returncode == 1
    assert result.stderr == b"chezmoi: requires at least 2 arg(s), only received 0\n"


def test_age_suffix_is_configurable(tmp_path):
    """The [age] suffix config changes the encrypted source file extension."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home, 'suffix = ".bin"\n')
    (home / "s.txt").write_text("suffix data\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "s.txt"], cwd=home, home=home
    )
    # CATCHES: the suffix is used verbatim for the source file name, and
    # cat still finds and decrypts the file regardless of the suffix.
    assert (home / ".local/share/chezmoi/encrypted_s.txt.bin").exists()
    cat = run_chezmoi(["--config", config, "cat", "s.txt"], cwd=home, home=home)
    assert cat.returncode == 0
    assert cat.stdout == b"suffix data\n"


def test_transparent_encryption_passthrough(tmp_path):
    """encryption = "transparent" stores data unencrypted, in and out."""
    home = make_home(tmp_path)
    config = write_config(tmp_path, 'encryption = "transparent"\n')
    (home / "trans.txt").write_text("some data\n")
    added = run_chezmoi(
        ["--config", config, "add", "--encrypt", "trans.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: transparent encryption keeps the raw contents in the source
    # file (prefixed encrypted_ but with NO suffix) and passes them through
    # unchanged on cat.
    assert added.returncode == 0
    source = home / ".local/share/chezmoi/encrypted_trans.txt"
    assert source.exists()
    assert source.read_text() == "some data\n"
    cat = run_chezmoi(
        ["--config", config, "cat", "trans.txt"], cwd=home, home=home
    )
    assert cat.returncode == 0
    assert cat.stdout == b"some data\n"

    (home / "trans.txt").unlink()
    applied = run_chezmoi(
        ["--config", config, "apply", "--force"], cwd=home, home=home
    )
    assert applied.returncode == 0
    assert (home / "trans.txt").read_text() == "some data\n"

    encrypted = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"cipher\n"
    )
    decrypted = run_chezmoi(
        ["--config", config, "decrypt"], cwd=home, home=home, stdin=b"cipher\n"
    )
    # CATCHES: the encrypt/decrypt commands are also raw passthroughs.
    assert encrypted.returncode == 0
    assert encrypted.stdout == b"cipher\n"
    assert decrypted.returncode == 0
    assert decrypted.stdout == b"cipher\n"


def test_encrypted_external_is_decrypted(tmp_path):
    """An external with encrypted=true is decrypted from its URL contents."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    external_dir = tmp_path / "ext"
    external_dir.mkdir()
    encrypted = run_chezmoi(
        ["--config", config, "encrypt"],
        cwd=home,
        home=home,
        stdin=b"external secret data\n",
    )
    assert encrypted.returncode == 0
    (external_dir / "enc.txt").write_bytes(encrypted.stdout)
    (home / ".local/share/chezmoi/.chezmoiexternal.toml").write_text(
        '["enc.txt"]\n    type = "file"\n    url = "file://%s"\n'
        "    encrypted = true\n" % (external_dir / "enc.txt")
    )
    cat = run_chezmoi(
        ["--config", config, "cat", "enc.txt"], cwd=home, home=home
    )
    # CATCHES: the external's ciphertext is fetched from the URL and run
    # through the configured decryption before being shown.
    assert cat.returncode == 0
    assert cat.stdout == b"external secret data\n"

    applied = run_chezmoi(
        ["--config", config, "apply"], cwd=home, home=home
    )
    # CATCHES: apply materializes the decrypted contents as the target file.
    assert applied.returncode == 0
    assert (home / "enc.txt").read_text() == "external secret data\n"


def test_plain_external_is_not_decrypted(tmp_path):
    """An external without encrypted=true is passed through verbatim."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    external_dir = tmp_path / "ext"
    external_dir.mkdir()
    encrypted = run_chezmoi(
        ["--config", config, "encrypt"],
        cwd=home,
        home=home,
        stdin=b"external secret data\n",
    )
    assert encrypted.returncode == 0
    (external_dir / "enc.txt").write_bytes(encrypted.stdout)
    (home / ".local/share/chezmoi/.chezmoiexternal.toml").write_text(
        '["enc.txt"]\n    type = "file"\n    url = "file://%s"\n'
        % (external_dir / "enc.txt")
    )
    cat = run_chezmoi(
        ["--config", config, "cat", "enc.txt"], cwd=home, home=home
    )
    # CATCHES: without encrypted=true the (ciphertext) URL contents are
    # shown as-is - the age armor header appears in the output.
    assert cat.returncode == 0
    assert cat.stdout.startswith(b"-----BEGIN AGE ENCRYPTED FILE-----\n")


def test_edit_reencrypts_modified_target(tmp_path):
    """`edit` on an encrypted target decrypts, edits, and re-encrypts."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    editor = write_script(
        tmp_path / "editor.sh", '#!/bin/sh\nprintf \'added by editor\\n\' >> "$1"\n'
    )
    (home / "editable.txt").write_text("edit me\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "editable.txt"],
        cwd=home,
        home=home,
    )
    result = run_chezmoi(
        ["--config", config, "--no-tty", "edit", "editable.txt"],
        cwd=home,
        home=home,
        env={"EDITOR": editor},
    )
    # CATCHES: the target is decrypted into a private chezmoi-encrypted
    # temp dir for editing, and because the editor returned in under a
    # second chezmoi warns about it on stderr before re-encrypting.
    assert result.returncode == 0
    assert re.fullmatch(
        r"chezmoi: warning: %s /\S*chezmoi-encrypted\d+/editable\.txt: "
        r"returned in less than 1s\n" % re.escape(str(editor)),
        result.stderr.decode(),
    )
    cat = run_chezmoi(
        ["--config", config, "cat", "editable.txt"], cwd=home, home=home
    )
    assert cat.returncode == 0
    assert cat.stdout == b"edit me\nadded by editor\n"


def test_edit_encrypted_command(tmp_path):
    """`edit-encrypted` edits the encrypted source file directly."""
    home = make_home(tmp_path)
    config, _ = age_config(tmp_path, home)
    editor = write_script(
        tmp_path / "editor.sh", '#!/bin/sh\nprintf \'added by editor\\n\' >> "$1"\n'
    )
    (home / "ee.txt").write_text("ee secret\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "ee.txt"], cwd=home, home=home
    )
    source_rel = ".local/share/chezmoi/encrypted_ee.txt.age"
    result = run_chezmoi(
        ["--config", config, "--no-tty", "edit-encrypted", source_rel],
        cwd=home,
        home=home,
        env={"EDITOR": editor},
    )
    # CATCHES: edit-encrypted takes a source path relative to the home
    # directory, decrypts into a chezmoi-edit-encrypted temp dir mirroring
    # the source layout, and warns about the fast-returning editor.
    assert result.returncode == 0
    assert re.fullmatch(
        r"chezmoi: warning: %s /\S*chezmoi-edit-encrypted\d+/%s: "
        r"returned in less than 1s\n" % (re.escape(str(editor)), re.escape(source_rel)),
        result.stderr.decode(),
    )
    cat = run_chezmoi(
        ["--config", config, "cat", "ee.txt"], cwd=home, home=home
    )
    assert cat.returncode == 0
    assert cat.stdout == b"ee secret\nadded by editor\n"
    # CATCHES: the restored target keeps normal file permissions (0666
    # masked by the umask) - readable and writable by its owner, not
    # world-writable.
    mode = (home / "ee.txt").stat().st_mode & 0o777
    assert mode & 0o600 == 0o600
    assert mode & 0o002 == 0


@pytest.fixture(scope="session")
def gpg_key(tmp_path_factory):
    """Generate one real gpg encryption key; return its GNUPGHOME path."""
    gnupg_home = tmp_path_factory.mktemp("gnupg")
    gnupg_home.chmod(0o700)
    subprocess.run(
        [
            "gpg", "--batch", "--pinentry-mode", "loopback", "--passphrase", "",
            "--quick-generate-key", "Test User <test@example.com>",
            "rsa2048", "encr", "0",
        ],
        env={"HOME": str(gnupg_home), "PATH": MINIMAL_PATH,
             "GNUPGHOME": str(gnupg_home)},
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=60,
        check=True,
    )
    return gnupg_home


def test_real_gpg_roundtrip(tmp_path, gpg_key):
    """Real gpg encryption and decryption through the CLI commands."""
    home = make_home(tmp_path)
    config = write_config(
        tmp_path,
        'encryption = "gpg"\n[gpg]\nrecipient = "Test User <test@example.com>"\n',
    )
    encrypted = run_chezmoi(
        ["--config", config, "encrypt"],
        cwd=tmp_path,
        home=home,
        stdin=b"real gpg secret\n",
        env={"GNUPGHOME": gpg_key},
    )
    # CATCHES: chezmoi invokes gpg with --armor, so stdout is a 12-line
    # armored PGP message even though the plaintext was piped on stdin.
    assert encrypted.returncode == 0
    lines = encrypted.stdout.splitlines()
    assert lines[0] == b"-----BEGIN PGP MESSAGE-----"
    assert lines[-1] == b"-----END PGP MESSAGE-----"
    assert len(lines) == 12

    decrypted = run_chezmoi(
        ["--config", config, "decrypt"],
        cwd=tmp_path,
        home=home,
        stdin=encrypted.stdout,
        env={"GNUPGHOME": gpg_key},
    )
    # CATCHES: gpg's own status output (naming the decryption key) is
    # forwarded on stderr while the plaintext appears on stdout.
    assert decrypted.returncode == 0
    assert decrypted.stdout == b"real gpg secret\n"
    assert b'"Test User <test@example.com>"' in decrypted.stderr


def test_gpg_add_encrypt_uses_asc_suffix(tmp_path, gpg_key):
    """`add --encrypt` with gpg stores encrypted_<name>.asc in the source."""
    home = make_home(tmp_path)
    config = write_config(
        tmp_path,
        'encryption = "gpg"\n[gpg]\nrecipient = "Test User <test@example.com>"\n',
    )
    (home / "gf.txt").write_text("gpg file secret\n")
    added = run_chezmoi(
        ["--config", config, "add", "--encrypt", "gf.txt"],
        cwd=home,
        home=home,
        env={"GNUPGHOME": gpg_key},
    )
    # CATCHES: the gpg suffix .asc is used for the encrypted source file,
    # and cat decrypts it back through the real gpg key.
    assert added.returncode == 0
    source = home / ".local/share/chezmoi/encrypted_gf.txt.asc"
    assert source.exists()
    assert source.read_text().startswith("-----BEGIN PGP MESSAGE-----\n")
    cat = run_chezmoi(
        ["--config", config, "cat", "gf.txt"],
        cwd=home,
        home=home,
        env={"GNUPGHOME": gpg_key},
    )
    assert cat.returncode == 0
    assert cat.stdout == b"gpg file secret\n"
