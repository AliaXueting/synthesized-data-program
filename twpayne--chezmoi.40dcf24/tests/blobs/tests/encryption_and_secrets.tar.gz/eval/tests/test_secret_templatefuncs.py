"""Generic and vault-style secret template functions.

Covers secret/secretJSON (with args, trimming, and failure reporting),
vault, lastpass/lastpassRaw (including note parsing), pass/passFields/
passRaw, gopass/gopassCat/gopassRaw plus gopass modes, rbw/rbwFields,
keeper/keeperDataFields/keeperFindPassword, dashlaneNote/dashlanePassword,
ejsonDecrypt, azureKeyVault, and awsSecretsManager error paths.

Every test drives the standard fake secret command and asserts both the
rendered template output and the exact argv the fake recorded.
"""

import pytest

from conftest import TemplateRunner, make_home


def runner(tmp_path):
    return TemplateRunner(tmp_path, make_home(tmp_path))


def test_secret_trims_command_output(tmp_path):
    """secret returns the command output with surrounding whitespace removed."""
    r = runner(tmp_path)
    result = r.run(
        "secret",
        'value = {{ secret "item1" }}|',
        fake_out="  secret-value-for-item1\n",
    )
    # CATCHES: the raw output is trimmed on both sides before being returned
    # to the template, and the item is passed as the only argument.
    assert result.returncode == 0
    assert result.stdout == b"value = secret-value-for-item1|"
    assert result.stderr == b""
    assert r.log_lines() == ["ARGS: [item1]"]


def test_secret_config_args_and_secretjson(tmp_path):
    """Config args are prepended to the item; secretJSON parses the output."""
    r = runner(tmp_path)
    with_args = r.run(
        "secret",
        'value = {{ secret "item1" }}|',
        fake_out="out\n",
        extra_cfg='args = ["--global", "-x"]',
    )
    assert with_args.returncode == 0
    assert with_args.stdout == b"value = out|"
    assert r.log_lines() == ["ARGS: [--global] [-x] [item1]"]

    r.log.unlink()
    as_json = r.run(
        "secret",
        'pw = {{ (secretJSON "x").password }} n = {{ (secretJSON "x").n }}',
        fake_out='{"password": "pw-x", "n": 42}\n',
        extra_cfg='args = ["--json"]',
    )
    # CATCHES: secretJSON runs the same command with the same args and
    # unmarshals the JSON, so numbers stay numbers in the template.
    assert as_json.returncode == 0
    assert as_json.stdout == b"pw = pw-x n = 42"
    assert r.log_lines() == ["ARGS: [--json] [x]"]


def test_secret_failure_includes_child_output(tmp_path):
    """A failing secret command surfaces stderr, argv, and captured stdout."""
    r = runner(tmp_path)
    result = r.run(
        "secret",
        '{{ secret "x" }}',
        fake_out="some stdout\n",
        fake_err="some stderr\n",
        fake_exit="3",
    )
    # CATCHES: the template error contains the child's stderr position
    # (printed first), the full command line with the exit status, and the
    # child's captured stdout appended after a newline.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        "some stderr\n"
        'chezmoi: template: arg1:1:3: executing "arg1" at <secret "x">: '
        "error calling secret: %s x: exit status 3\n"
        "some stdout\n"
        "\n" % r.fake
    )


def test_vault_template_func(tmp_path):
    """vault fetches kv data as JSON with a -format=json flag."""
    r = runner(tmp_path)
    result = r.run(
        "vault",
        '{{ (vault "kv/mysecret").data.password }}',
        fake_out='{"data":{"password":"vault-pw"}}',
    )
    # CATCHES: vault is invoked as `vault kv get -format=json <key>` and
    # the JSON document is exposed to the template as a nested map.
    assert result.returncode == 0
    assert result.stdout == b"vault-pw"
    assert result.stderr == b""
    assert r.log_lines() == ["ARGS: [kv] [get] [-format=json] [kv/mysecret]"]


def test_lastpass_username_and_raw_note(tmp_path):
    """lastpassRaw returns the raw JSON; lastpass parses it into structs."""
    r = runner(tmp_path)
    result = r.run(
        "lastpass",
        'u = {{ (index (lastpassRaw "Site") 0).username }} '
        'n = {{ (index (lastpassRaw "Site") 0).note }}',
        fake_out='[{"username":"lp2","note":"rawnote"}]',
    )
    # CATCHES: both functions run `lpass show --json <site>`; lastpassRaw
    # keeps the raw decoded JSON while lastpass converts each entry into a
    # struct with typed fields.
    assert result.returncode == 0
    assert result.stdout == b"u = lp2 n = rawnote"
    assert result.stderr == b""
    assert r.log_lines() == ["ARGS: [show] [--json] [Site]"]


def test_lastpass_note_parsing(tmp_path):
    """The lastpass note "NoteType:" line becomes the noteType map key."""
    r = runner(tmp_path)
    result = r.run(
        "lastpass",
        'u = {{ range lastpass "Site" }}{{ .username }}{{ end }} '
        'n = {{ (index (lastpass "Site") 0).note.noteType }}|',
        fake_out='[{"username":"lp-user","note":"NoteType: some note\\nBody Text"}]',
    )
    # CATCHES: a note beginning "NoteType:" is split into a map whose key
    # is the lower-cased first word; the value keeps the leading space and
    # all following lines of the note.
    assert result.returncode == 0
    assert result.stdout == b"u = lp-user n =  some note\nBody Text|"
    assert result.stderr == b""
    assert r.log_lines() == ["ARGS: [show] [--json] [Site]"]

    plain = r.run(
        "lastpass",
        'u = {{ range lastpass "Site" }}{{ .username }}:'
        '{{ .note.NoteType }}:{{ .note.Value }}{{ end }}',
        fake_out='[{"username":"lp-user","note":"NoteType: some note"}]',
    )
    # CATCHES: notes without a NoteType line stay plain strings, so the
    # capitalized .NoteType key does not exist on the map.
    assert plain.returncode == 1
    assert plain.stdout == b""
    assert plain.stderr == (
        b'chezmoi: template: arg1:1:55: executing "arg1" at <.note.NoteType>: '
        b'map has no entry for key "NoteType"\n'
    )


def test_pass_template_funcs(tmp_path):
    """pass returns the first line; passFields the key/value map; passRaw all."""
    r = runner(tmp_path)
    result = r.run(
        "pass",
        'p = {{ pass "email/pass" }} u = {{ (passFields "email/pass").user }} '
        'r = {{ passRaw "email/pass" }}|',
        fake_out="the-password\nuser: someone\nurl: http://x",
    )
    # CATCHES: one `pass show <id>` invocation serves all three functions -
    # the first line is the password, the colon lines become map fields,
    # and passRaw is the full output including later lines.
    assert result.returncode == 0
    assert result.stdout == (
        b"p = the-password u = someone r = the-password\n"
        b"user: someone\nurl: http://x|"
    )
    assert result.stderr == b""
    assert r.log_lines() == ["ARGS: [show] [email/pass]"]


def test_gopass_template_funcs(tmp_path):
    """gopass modes map to three different command-line shapes."""
    r = runner(tmp_path)
    result = r.run(
        "gopass",
        'p = {{ gopass "show/secret" }} c = {{ gopassCat "show/secret" }}| '
        'r = {{ gopassRaw "show/secret" }}|',
        fake_out="gopass-pw\nmore data",
    )
    # CATCHES: gopass requests only the first line (--password), gopassCat
    # the whole secret (cat), and gopassRaw disables secret parsing
    # (--noparsing) - three separate invocations of the same command.
    assert result.returncode == 0
    assert result.stdout == (
        b"p = gopass-pw c = gopass-pw\nmore data| r = gopass-pw\nmore data|"
    )
    assert result.stderr == b""
    assert r.log_lines() == [
        "ARGS: [show] [--password] [show/secret]",
        "ARGS: [cat] [show/secret]",
        "ARGS: [show] [--noparsing] [show/secret]",
    ]


@pytest.mark.parametrize(
    ("extra_cfg", "message"),
    [
        pytest.param(
            'mode = "builtin"',
            "error calling gopass: password store not initialized. "
            "run 'gopass setup' first",
            id="builtin",
        ),
        pytest.param(
            'mode = "bogus"',
            "error calling gopass: bogus: invalid mode",
            id="invalid",
        ),
    ],
)
def test_gopass_mode_errors(tmp_path, extra_cfg, message):
    """gopass builtin mode and unknown modes fail without running a command."""
    r = runner(tmp_path)
    result = r.run("gopass", '{{ gopass "secret" }}', extra_cfg=extra_cfg)
    # CATCHES: mode = "builtin" reads the password store from disk (and
    # reports it as uninitialized), while any other unknown mode value is
    # rejected by name - neither shells out to the configured command.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode().endswith(
        'chezmoi: template: arg1:1:3: executing "arg1" at <gopass "secret">: '
        + message + "\n"
    )
    assert not r.log.exists()


def test_rbw_template_funcs(tmp_path):
    """rbw and rbwFields both use `rbw get --raw`."""
    r = runner(tmp_path)
    result = r.run(
        "rbw",
        'p = {{ (rbw "github").data.password }} '
        'v = {{ (rbwFields "github").f1.value }}',
        fake_out='{"data":{"password":"rbw-pw"},"fields":[{"name":"f1","value":"v1"}]}',
    )
    # CATCHES: the full JSON document is available for field access and the
    # fields array is indexed by name through rbwFields.
    assert result.returncode == 0
    assert result.stdout == b"p = rbw-pw v = v1"
    assert result.stderr == b""
    assert r.log_lines() == ["ARGS: [get] [--raw] [github]"]


def test_keeper_template_funcs(tmp_path):
    """keeper fetches records as JSON; keeperFindPassword trims plain output."""
    r = runner(tmp_path)
    record = r.run(
        "keeper",
        'f = {{ (keeper "record").data.fields }} '
        'df = {{ (keeperDataFields "record").login }}',
        fake_out='{"data":{"fields":[{"type":"login","value":"keeper-login"}]}}',
    )
    assert record.returncode == 0
    assert record.stdout == b"f = [map[type:login value:keeper-login]] df = keeper-login"
    assert record.stderr == b""
    assert r.log_lines() == ["ARGS: [get] [--format=json] [record]"]

    r.log.unlink()
    password = r.run(
        "keeper",
        'p = {{ keeperFindPassword "record" }}|',
        fake_out="  keeper-pw\n",
    )
    # CATCHES: keeperFindPassword runs `keeper find-password <record>` and
    # trims the plain-text output like secret does.
    assert password.returncode == 0
    assert password.stdout == b"p = keeper-pw|"
    assert r.log_lines() == ["ARGS: [find-password] [record]"]


def test_dashlane_template_funcs(tmp_path):
    """dashlaneNote returns raw text; dashlanePassword parses JSON output."""
    r = runner(tmp_path)
    note = r.run(
        "dashlane",
        'n = {{ dashlaneNote "filter" }}',
        fake_out="dashlane-note-contents",
    )
    assert note.returncode == 0
    assert note.stdout == b"n = dashlane-note-contents"
    assert note.stderr == b""
    assert r.log_lines() == ["ARGS: [note] [filter]"]

    r.log.unlink()
    password = r.run(
        "dashlane",
        'p = {{ (dashlanePassword "filter").password }} '
        'l = {{ (dashlanePassword "filter").login }}',
        fake_out='{"password":"dl-pw","login":"dl-login"}',
    )
    # CATCHES: dashlanePassword passes `--output json` so the credential
    # fields are addressable as a map.
    assert password.returncode == 0
    assert password.stdout == b"p = dl-pw l = dl-login"
    assert r.log_lines() == ["ARGS: [password] [--output] [json] [filter]"]


@pytest.mark.parametrize(
    ("file_content", "message"),
    [
        pytest.param(
            None,
            lambda path: "stat %s: no such file or directory" % path,
            id="missing-file",
        ),
        pytest.param(
            "not json",
            lambda path: "invalid character 'o' in literal null (expecting 'u')",
            id="invalid-json",
        ),
        pytest.param(
            '{"foo":"bar"}',
            lambda path: "public key not present in EJSON file",
            id="no-public-key",
        ),
    ],
)
def test_ejson_decrypt_errors(tmp_path, file_content, message):
    """ejsonDecrypt distinguishes missing, invalid, and key-less inputs."""
    r = runner(tmp_path)
    path = tmp_path / "secret.ejson"
    if file_content is not None:
        path.write_text(file_content)
    result = r.run("", '{{ ejsonDecrypt "%s" }}' % path)
    # CATCHES: each failure mode has its own message - the stat error for a
    # missing file, the JSON decode error for garbage, and the EJSON
    # semantic error for a document without a _public_key field.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode().endswith(
        'chezmoi: template: arg1:1:3: executing "arg1" at <ejsonDecrypt "%s">: '
        "error calling ejsonDecrypt: %s\n" % (path, message(path))
    )


def test_azure_keyvault_errors(tmp_path):
    """azureKeyVault requires a default vault and at most two arguments."""
    r = runner(tmp_path)
    no_vault = r.run("", '{{ azureKeyVault "secret" }}')
    # CATCHES: without azureKeyVault.defaultVault configured the call is
    # rejected before any network access is attempted.
    assert no_vault.returncode == 1
    assert no_vault.stdout == b""
    assert no_vault.stderr.decode().endswith(
        'chezmoi: template: arg1:1:3: executing "arg1" at <azureKeyVault "secret">: '
        "error calling azureKeyVault: no value set in azureKeyVault.defaultVault\n"
    )

    three_args = r.run(
        "azureKeyVault",
        '{{ azureKeyVault "s" "v" "extra" }}',
        extra_cfg='defaultVault = "v"',
    )
    # CATCHES: the arity check counts the received arguments and allows
    # only the secret name plus an optional vault override.
    assert three_args.returncode == 1
    assert three_args.stderr.decode().endswith(
        'chezmoi: template: arg1:1:3: executing "arg1" at '
        '<azureKeyVault "s" "v" "extra">: '
        "error calling azureKeyVault: expected 1 or 2 arguments, got 3\n"
    )


def test_azure_keyvault_credential_construction_error(tmp_path):
    """azureKeyVault surfaces DefaultAzureCredential construction errors."""
    r = runner(tmp_path)
    two_args = r.run(
        "",
        '{{ azureKeyVault "s" "v" }}',
        env={"AZURE_TOKEN_CREDENTIALS": "bogus"},
    )
    # CATCHES: with an explicit vault argument the call gets as far as
    # building the DefaultAzureCredential chain, and an invalid
    # AZURE_TOKEN_CREDENTIALS value is reported verbatim (no network access
    # is attempted).
    assert two_args.returncode == 1
    assert two_args.stdout == b""
    assert two_args.stderr.decode() == (
        'chezmoi: template: arg1:1:3: executing "arg1" at <azureKeyVault "s" "v">: '
        "error calling azureKeyVault: invalid AZURE_TOKEN_CREDENTIALS value "
        '"bogus". Valid values are "dev", "prod", or the name of any '
        "credential type in the default chain. See "
        "https://aka.ms/azsdk/go/identity/docs#DefaultAzureCredential "
        "for more information\n"
    )

    one_arg = r.run(
        "azureKeyVault",
        '{{ azureKeyVault "s" }}',
        extra_cfg='defaultVault = "myvault"',
        env={"AZURE_TOKEN_CREDENTIALS": "bogus"},
    )
    # CATCHES: the one-argument form uses the configured defaultVault and
    # fails at the same credential construction step.
    assert one_arg.returncode == 1
    assert one_arg.stdout == b""
    assert one_arg.stderr.decode() == (
        'chezmoi: template: arg1:1:3: executing "arg1" at <azureKeyVault "s">: '
        "error calling azureKeyVault: invalid AZURE_TOKEN_CREDENTIALS value "
        '"bogus". Valid values are "dev", "prod", or the name of any '
        "credential type in the default chain. See "
        "https://aka.ms/azsdk/go/identity/docs#DefaultAzureCredential "
        "for more information\n"
    )


def test_azure_keyvault_skip_secrets(tmp_path):
    """--skip-secrets gates azureKeyVault before any credential work."""
    r = runner(tmp_path)
    result = r.run(
        "azureKeyVault",
        '{{ azureKeyVault "s" }}',
        extra_cfg='defaultVault = "myvault"',
        flags=["--skip-secrets"],
    )
    # CATCHES: the skip happens before the default vault is even read, so
    # no credential chain is constructed and no network access attempted.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'chezmoi: template: arg1:1:3: executing "arg1" at <azureKeyVault "s">: '
        "error calling azureKeyVault: skip template\n"
    )


def test_aws_secrets_manager_without_credentials(tmp_path):
    """awsSecretsManager fails after the EC2 IMDS credential lookup times out."""
    r = runner(tmp_path)
    result = r.run(
        "awsSecretsManager",
        '{{ awsSecretsManager "mysecret" }}',
        extra_cfg='region = "us-east-1"',
        timeout=30,
    )
    # CATCHES: with no credentials the AWS SDK probes EC2 instance metadata
    # and fails with a context deadline; the error names the GetSecretValue
    # operation and the credential refresh failure.
    assert result.returncode == 1
    assert result.stdout == b""
    assert (
        "error calling awsSecretsManager: operation error Secrets Manager: "
        "GetSecretValue, get identity: get credentials: failed to refresh "
        "cached credentials, no EC2 IMDS role found" in result.stderr.decode()
    )
