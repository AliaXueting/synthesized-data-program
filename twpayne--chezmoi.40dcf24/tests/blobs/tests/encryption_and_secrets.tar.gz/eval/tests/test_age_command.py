"""The `chezmoi age` subcommand: standalone passphrase encryption.

Covers: the passphrase-only restriction, prompt/confirm behavior on stdout
with --no-tty, the armored scrypt ciphertext format, and error paths
(wrong passphrase, mismatched confirmation, EOF, missing TTY).
"""

import base64

from conftest import make_home, run_chezmoi


def _encrypt_with_passphrase(tmp_path, home, ciphertext, stdin):
    plaintext = tmp_path / "pt.txt"
    plaintext.write_text("roundtrip secret\n")
    return run_chezmoi(
        ["age", "encrypt", "-p", "--no-tty", "-o", ciphertext, plaintext],
        cwd=tmp_path,
        home=home,
        stdin=stdin,
    )


def test_age_encrypt_requires_passphrase_flag(tmp_path):
    """`age encrypt` without -p is rejected: only passphrases are supported."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age", "encrypt"], cwd=tmp_path, home=home, stdin=b"data\n"
    )
    # CATCHES: the age subcommand intentionally supports passphrase
    # encryption only; recipient-based encryption belongs to `chezmoi
    # encrypt` with a config.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: only passphrase encryption is supported\n"


def test_age_decrypt_requires_passphrase_flag(tmp_path):
    """`age decrypt` without -p is rejected the same way as encrypt."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age", "decrypt"], cwd=tmp_path, home=home, stdin=b"data\n"
    )
    # CATCHES: the passphrase-only restriction applies symmetrically to
    # decryption, before any input is read.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: only passphrase encryption is supported\n"


def test_age_passphrase_roundtrip(tmp_path):
    """Encrypt then decrypt with the same passphrase via stdin prompts."""
    home = make_home(tmp_path)
    ciphertext = tmp_path / "ct.age"
    encrypted = _encrypt_with_passphrase(
        tmp_path, home, ciphertext, b"hunter2\nhunter2\n"
    )
    # CATCHES: with --no-tty the "Enter passphrase:" and "Confirm
    # passphrase:" prompts are written to stdout while the passphrase lines
    # are consumed from stdin; the ciphertext goes to the -o file.
    assert encrypted.returncode == 0
    assert encrypted.stdout == b"Enter passphrase: Confirm passphrase: "
    assert encrypted.stderr == b""

    decrypted = run_chezmoi(
        ["age", "decrypt", "-p", "--no-tty", ciphertext],
        cwd=tmp_path,
        home=home,
        stdin=b"hunter2\n",
    )
    assert decrypted.returncode == 0
    assert decrypted.stdout == b"Enter passphrase: roundtrip secret\n"
    assert decrypted.stderr == b""


def test_age_ciphertext_is_armored_scrypt(tmp_path):
    """The passphrase ciphertext is age ASCII armor over an scrypt header."""
    home = make_home(tmp_path)
    ciphertext = tmp_path / "ct.age"
    encrypted = _encrypt_with_passphrase(
        tmp_path, home, ciphertext, b"hunter2\nhunter2\n"
    )
    assert encrypted.returncode == 0
    lines = ciphertext.read_text().splitlines()
    # CATCHES: the output is 7 lines of ASCII armor, and the base64-decoded
    # body starts with the age file header naming the scrypt KDF and its
    # work factor 18.
    assert len(lines) == 7
    assert lines[0] == "-----BEGIN AGE ENCRYPTED FILE-----"
    assert lines[-1] == "-----END AGE ENCRYPTED FILE-----"
    decoded = base64.b64decode("".join(lines[1:-1]))
    assert decoded.startswith(b"age-encryption.org/v1\n-> scrypt ")
    assert b" 18\n" in decoded[:80]


def test_age_decrypt_wrong_passphrase(tmp_path):
    """A wrong passphrase fails after the prompt with a specific error."""
    home = make_home(tmp_path)
    ciphertext = tmp_path / "ct.age"
    _encrypt_with_passphrase(tmp_path, home, ciphertext, b"hunter2\nhunter2\n")
    result = run_chezmoi(
        ["age", "decrypt", "-p", "--no-tty", ciphertext],
        cwd=tmp_path,
        home=home,
        stdin=b"wrongpass\n",
    )
    # CATCHES: the prompt has already been printed to stdout when the
    # scrypt KDF rejects the passphrase, and the error is the age library's
    # "incorrect passphrase" message.
    assert result.returncode == 1
    assert result.stdout == b"Enter passphrase: "
    assert result.stderr == b"chezmoi: incorrect passphrase\n"


def test_age_encrypt_passphrase_mismatch(tmp_path):
    """Mismatched confirmation passphrase aborts before encrypting."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age", "encrypt", "-p", "--no-tty"],
        cwd=tmp_path,
        home=home,
        stdin=b"aaa\nbbb\n",
    )
    # CATCHES: both prompts appear on stdout, then the comparison of the
    # two read values fails with "passphrases didn't match".
    assert result.returncode == 1
    assert result.stdout == b"Enter passphrase: Confirm passphrase: "
    assert result.stderr == b"chezmoi: passphrases didn't match\n"


def test_age_encrypt_confirmation_eof(tmp_path):
    """A single stdin line leaves the confirmation read at EOF."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age", "encrypt", "-p", "--no-tty"],
        cwd=tmp_path,
        home=home,
        stdin=b"onlyone\n",
    )
    # CATCHES: the enter prompt consumes the only line, the confirm prompt
    # then hits EOF, which surfaces as a bare "chezmoi: EOF" error.
    assert result.returncode == 1
    assert result.stdout == b"Enter passphrase: Confirm passphrase: "
    assert result.stderr == b"chezmoi: EOF\n"


def test_age_encrypt_to_stdout_interleaves_prompts(tmp_path):
    """Without -o the armored ciphertext follows the prompts on stdout."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age", "encrypt", "-p", "--no-tty"],
        cwd=tmp_path,
        home=home,
        stdin=b"hunter2\nhunter2\n",
    )
    # CATCHES: prompts and ciphertext share stdout in order - the armor
    # header begins immediately after "Confirm passphrase: ".
    assert result.returncode == 0
    assert result.stdout.startswith(
        b"Enter passphrase: Confirm passphrase: "
        b"-----BEGIN AGE ENCRYPTED FILE-----\n"
    )
    assert result.stderr == b""


def test_age_needs_tty_without_no_tty_flag(tmp_path):
    """Without --no-tty the passphrase prompt requires a TTY."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age", "encrypt", "-p"],
        cwd=tmp_path,
        home=home,
        stdin=b"hunter2\nhunter2\n",
    )
    # CATCHES: when opening /dev/tty for the prompt fails (no controlling
    # terminal), the raw open error is wrapped in "could not open a new TTY".
    assert result.returncode == 1
    assert result.stderr == (
        b"chezmoi: could not open a new TTY: open /dev/tty: "
        b"no such device or address\n"
    )


def test_age_unknown_subcommand_prints_help(tmp_path):
    """An unknown `age` subcommand prints the age help on stdout, exit 0."""
    home = make_home(tmp_path)
    result = run_chezmoi(["age", "foo"], cwd=tmp_path, home=home)
    # CATCHES: unlike top-level unknown commands, `age <unknown>` is not an
    # error - the age command help is printed to stdout and the exit code
    # is zero.
    assert result.returncode == 0
    assert result.stdout.startswith(b"Interact with age\n\nUsage:\n  chezmoi age ")
    assert result.stderr == b""
