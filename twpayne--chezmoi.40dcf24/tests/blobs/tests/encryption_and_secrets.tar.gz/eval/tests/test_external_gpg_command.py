"""External gpg command mode: the argument matrix.

chezmoi always runs gpg with --armor, pipes the plaintext through a
private temp file, and reads the ciphertext back from a second temp file
whose name is <ciphertext><suffix>. These tests record the exact argv for
encrypt and decrypt in every configuration shape.
"""

import pytest

from conftest import (
    FAKE_GPG_TEMPLATE,
    make_home,
    normalize_temp_paths,
    run_chezmoi,
    write_config,
    write_script,
)


def args_line(args):
    """Render an argv the way the fake command logs it."""
    return "ARGS:" + "".join(" [%s]" % a for a in args)


def run_gpg_external(tmp_path, extra_cfg, args, stdin=b""):
    """Run chezmoi with the fake gpg; return (result, log)."""
    home = make_home(tmp_path)
    fake = write_script(tmp_path / "fake-gpg.sh", FAKE_GPG_TEMPLATE)
    log = tmp_path / "gpglog.txt"
    config = write_config(
        tmp_path,
        'encryption = "gpg"\n[gpg]\ncommand = "%s"\n%s\n' % (fake, extra_cfg),
    )
    result = run_chezmoi(
        ["--config", config] + list(args),
        cwd=tmp_path,
        home=home,
        stdin=stdin,
        env={"FAKE_LOG": log},
    )
    return result, log


def normalized_log(log):
    """Log lines with the random private temp directory masked out."""
    return [normalize_temp_paths(line) for line in log.read_text().splitlines()]


ENCRYPT_CASES = [
    pytest.param(
        'recipient = "user@example.com"',
        ["--armor", "--output", "<TMP>/ciphertext.asc", "--recipient",
         "user@example.com", "--encrypt", "<TMP>/plaintext"],
        id="recipient",
    ),
    pytest.param(
        'recipients = ["r1@x", "r2@x"]',
        ["--armor", "--output", "<TMP>/ciphertext.asc", "--recipient",
         "r1@x", "--recipient", "r2@x", "--encrypt", "<TMP>/plaintext"],
        id="recipients-list",
    ),
    pytest.param(
        "symmetric = true",
        ["--armor", "--output", "<TMP>/ciphertext.asc", "--symmetric",
         "<TMP>/plaintext"],
        id="symmetric",
    ),
    pytest.param(
        'suffix = ".gpg"',
        ["--armor", "--output", "<TMP>/ciphertext.gpg", "--encrypt",
         "<TMP>/plaintext"],
        id="suffix",
    ),
    pytest.param(
        'recipient = "user@example.com"\nargs = ["--extra1", "--extra2"]',
        ["--armor", "--output", "<TMP>/ciphertext.asc", "--recipient",
         "user@example.com", "--extra1", "--extra2", "--encrypt",
         "<TMP>/plaintext"],
        id="config-args-before-encrypt",
    ),
]


@pytest.mark.parametrize(("extra_cfg", "expected"), ENCRYPT_CASES)
def test_gpg_external_encrypt_args(tmp_path, extra_cfg, expected):
    """Each [gpg] config shape maps to a fixed external gpg encrypt argv."""
    result, log = run_gpg_external(tmp_path, extra_cfg, ["encrypt"], b"x\n")
    # CATCHES: gpg encryption always uses --armor and a temp file pair -
    # the ciphertext is read back from <tmp>/ciphertext<suffix>, recipients
    # are expanded before config args, symmetric replaces --recipient
    # entirely and drops --encrypt, and the suffix config renames the
    # ciphertext temp file.
    assert result.returncode == 0
    assert result.stdout == b"GPGFAKE-CIPHERTEXT\n"
    assert result.stderr == b""
    assert normalized_log(log) == [args_line(expected)]


DECRYPT_CASES = [
    pytest.param(
        "",
        ["--output", "<TMP>/plaintext", "--decrypt", "<TMP>/ciphertext.asc"],
        id="plain",
    ),
    pytest.param(
        'args = ["--extra1"]',
        ["--output", "<TMP>/plaintext", "--extra1", "--decrypt",
         "<TMP>/ciphertext.asc"],
        id="config-args-before-decrypt",
    ),
    pytest.param(
        'suffix = ".gpg"',
        ["--output", "<TMP>/plaintext", "--decrypt", "<TMP>/ciphertext.gpg"],
        id="suffix",
    ),
]


@pytest.mark.parametrize(("extra_cfg", "expected"), DECRYPT_CASES)
def test_gpg_external_decrypt_args(tmp_path, extra_cfg, expected):
    """Decrypt configurations map to --output/--decrypt over temp files."""
    result, log = run_gpg_external(
        tmp_path, extra_cfg, ["decrypt"], b"ciphertext\n"
    )
    # CATCHES: decryption writes the plaintext to <tmp>/plaintext and
    # decrypts <tmp>/ciphertext<suffix>, with config args inserted between
    # --output and --decrypt.
    assert result.returncode == 0
    assert result.stdout == b"GPGFAKE-CIPHERTEXT\n"
    assert result.stderr == b""
    assert normalized_log(log) == [args_line(expected)]
