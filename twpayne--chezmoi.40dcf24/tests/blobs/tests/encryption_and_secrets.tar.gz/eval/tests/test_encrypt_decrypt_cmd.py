"""The `chezmoi encrypt` / `chezmoi decrypt` commands and template funcs.

Covers: stdin-to-stdout operation, multiple file arguments (concatenated
output), -o output files, missing file errors, the builtin age roundtrip,
the `encrypt`/`decrypt` template functions, and --debug logging of
plaintext/ciphertext through the encryption component.
"""

import base64

from conftest import (
    FAKE_TEMPLATE,
    age_keypair,
    make_home,
    run_chezmoi,
    write_config,
    write_script,
)


def _external_config(tmp_path):
    """A config using the standard fake external age command."""
    fake = write_script(tmp_path / "fake-age.sh", FAKE_TEMPLATE)
    return write_config(
        tmp_path,
        'encryption = "age"\n[age]\ncommand = "%s"\nrecipient = "r"\n' % fake,
    )


def test_encrypt_multiple_files_concatenates_output(tmp_path):
    """Encrypting several file arguments concatenates each result."""
    home = make_home(tmp_path)
    config = _external_config(tmp_path)
    (tmp_path / "f1.txt").write_text("one\n")
    (tmp_path / "f2.txt").write_text("two\n")
    result = run_chezmoi(
        ["--config", config, "encrypt", "f1.txt", "f2.txt"],
        cwd=tmp_path,
        home=home,
        env={"FAKE_LOG": tmp_path / "log.txt", "FAKE_OUT": "FAKEAGE-OUTPUT\n"},
    )
    # CATCHES: with file arguments each file is encrypted separately and the
    # ciphertexts are written to stdout back to back, in argument order.
    assert result.returncode == 0
    assert result.stdout == b"FAKEAGE-OUTPUT\nFAKEAGE-OUTPUT\n"
    assert result.stderr == b""


def test_encrypt_output_flag_writes_file(tmp_path):
    """-o redirects the ciphertext to a file and silences stdout."""
    home = make_home(tmp_path)
    config = _external_config(tmp_path)
    (tmp_path / "f1.txt").write_text("one\n")
    output = tmp_path / "out.bin"
    result = run_chezmoi(
        ["--config", config, "-o", output, "encrypt", "f1.txt"],
        cwd=tmp_path,
        home=home,
        env={"FAKE_LOG": tmp_path / "log.txt", "FAKE_OUT": "FAKEAGE-OUTPUT\n"},
    )
    # CATCHES: with -o nothing is printed and the concatenated ciphertext
    # lands in the named file instead.
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert output.read_bytes() == b"FAKEAGE-OUTPUT\n"


def test_encrypt_missing_file_argument(tmp_path):
    """A missing file argument is reported with the file's path."""
    home = make_home(tmp_path)
    config = _external_config(tmp_path)
    missing = tmp_path / "nope.txt"
    result = run_chezmoi(
        ["--config", config, "encrypt", missing],
        cwd=tmp_path,
        home=home,
        env={"FAKE_LOG": tmp_path / "log.txt", "FAKE_OUT": "FAKEAGE-OUTPUT\n"},
    )
    # CATCHES: file arguments are read before the encryption command runs,
    # so the failure is a plain open error naming the argument.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        "chezmoi: open %s: no such file or directory\n" % missing
    ).encode()


def test_decrypt_multiple_files_concatenates_output(tmp_path):
    """Decrypting several file arguments concatenates each plaintext."""
    home = make_home(tmp_path)
    config = _external_config(tmp_path)
    (tmp_path / "g1.age").write_text("A\n")
    (tmp_path / "g2.age").write_text("B\n")
    result = run_chezmoi(
        ["--config", config, "decrypt", "g1.age", "g2.age"],
        cwd=tmp_path,
        home=home,
        env={"FAKE_LOG": tmp_path / "log.txt", "FAKE_OUT": "FAKEAGE-OUTPUT\n"},
    )
    # CATCHES: decrypt mirrors encrypt - one invocation per file argument,
    # outputs concatenated on stdout.
    assert result.returncode == 0
    assert result.stdout == b"FAKEAGE-OUTPUT\nFAKEAGE-OUTPUT\n"
    assert result.stderr == b""


def test_builtin_age_roundtrip_via_commands(tmp_path):
    """Builtin age encrypt/decrypt roundtrip through the CLI commands."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    recipient_config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\nrecipient = "%s"\n' % recipient,
        name="recipient.toml",
    )
    identity_config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\nidentity = "%s"\n' % identity,
        name="identity.toml",
    )
    encrypted = run_chezmoi(
        ["--config", recipient_config, "encrypt"],
        cwd=tmp_path,
        home=home,
        stdin=b"top secret data\n",
    )
    # CATCHES: with no age command configured the builtin library is used,
    # producing age ASCII armor on stdout with no stderr noise.
    assert encrypted.returncode == 0
    assert encrypted.stderr == b""
    assert encrypted.stdout.startswith(b"-----BEGIN AGE ENCRYPTED FILE-----\n")
    assert encrypted.stdout.endswith(b"-----END AGE ENCRYPTED FILE-----\n")

    decrypted = run_chezmoi(
        ["--config", identity_config, "decrypt"],
        cwd=tmp_path,
        home=home,
        stdin=encrypted.stdout,
    )
    assert decrypted.returncode == 0
    assert decrypted.stdout == b"top secret data\n"
    assert decrypted.stderr == b""


def test_encrypt_decrypt_template_func_roundtrip(tmp_path):
    """The encrypt/decrypt template functions invert each other in one template."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\nrecipient = "%s"\nidentity = "%s"\n'
        % (recipient, identity),
    )
    result = run_chezmoi(
        ["--config", config, "--no-tty", "execute-template",
         '{{ decrypt (encrypt "roundtrip text") }}'],
        cwd=tmp_path,
        home=home,
    )
    # CATCHES: template encryption is in-memory: encrypt produces the
    # armored ciphertext and decrypt consumes it within the same template
    # execution, yielding exactly the input string.
    assert result.returncode == 0
    assert result.stdout == b"roundtrip text"
    assert result.stderr == b""


def test_encrypt_template_func_produces_x25519_armor(tmp_path):
    """The encrypt template function emits X25519 age armor."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nrecipient = "%s"\n' % recipient
    )
    result = run_chezmoi(
        ["--config", config, "--no-tty", "execute-template",
         '{{ encrypt "hello template" }}'],
        cwd=tmp_path,
        home=home,
    )
    # CATCHES: the template output is 7 lines of age ASCII armor whose
    # decoded body begins with the age header naming the X25519 recipient
    # stanza.
    assert result.returncode == 0
    assert result.stderr == b""
    lines = result.stdout.decode().splitlines()
    assert len(lines) == 7
    assert lines[0] == "-----BEGIN AGE ENCRYPTED FILE-----"
    assert lines[-1] == "-----END AGE ENCRYPTED FILE-----"
    decoded = base64.b64decode("".join(lines[1:-1]))
    assert decoded.startswith(b"age-encryption.org/v1\n-> X25519 ")


def test_encrypt_template_func_without_configuration(tmp_path):
    """The encrypt template function fails when nothing is configured."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["--no-tty", "execute-template", 'x {{ encrypt "hi" }} y'],
        cwd=tmp_path,
        home=home,
    )
    # CATCHES: without any encryption config the template function errors
    # with the same "encryption not configured" message as the command.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'chezmoi: template: arg1:1:5: executing "arg1" at <encrypt "hi">: '
        b"error calling encrypt: encryption not configured\n"
    )


def test_debug_encrypt_logs_plaintext(tmp_path):
    """--debug logs the plaintext handed to the encryption component."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nrecipient = "%s"\n' % recipient
    )
    result = run_chezmoi(
        ["--config", config, "--debug", "encrypt"],
        cwd=tmp_path,
        home=home,
        stdin=b"debug data\n",
    )
    # CATCHES: the debug log line for encryption names the component and
    # includes the full plaintext (and truncated ciphertext) as attributes.
    assert result.returncode == 0
    assert 'msg=Encrypt component=encryption plaintext="debug data\\n"' in result.stderr.decode()


def test_debug_decrypt_logs_plaintext(tmp_path):
    """--debug logs the plaintext produced by the decryption component."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\nrecipient = "%s"\nidentity = "%s"\n'
        % (recipient, identity),
    )
    encrypted = run_chezmoi(
        ["--config", config, "encrypt"],
        cwd=tmp_path,
        home=home,
        stdin=b"recovered data\n",
    )
    assert encrypted.returncode == 0
    result = run_chezmoi(
        ["--config", config, "--debug", "decrypt"],
        cwd=tmp_path,
        home=home,
        stdin=encrypted.stdout,
    )
    # CATCHES: decryption is logged symmetrically - msg=Decrypt with the
    # component name and the recovered plaintext attribute.
    assert result.returncode == 0
    assert result.stdout == b"recovered data\n"
    stderr = result.stderr.decode()
    assert "msg=Decrypt component=encryption" in stderr
    assert 'plaintext="recovered data\\n"' in stderr
