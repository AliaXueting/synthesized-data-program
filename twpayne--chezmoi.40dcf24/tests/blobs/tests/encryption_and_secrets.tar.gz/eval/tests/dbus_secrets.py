"""A fake session bus + org.freedesktop.secrets service, in pure Python.

chezmoi's keyring support (github.com/zalando/go-keyring) talks to the
freedesktop Secret Service over D-Bus.  This module implements just enough
of the D-Bus wire protocol with the standard library (a unix socket, the
SASL handshake and the few org.freedesktop.Secret.* methods go-keyring
calls) to let the keyring template function and the `secret keyring`
subcommands run their success paths hermetically, while recording every
method call so tests can assert on the exact call sequence (e.g. that
chezmoi caches lookups within a template).

The bus implements exactly what godbus (go-keyring's D-Bus client) needs:
EXTERNAL auth, org.freedesktop.DBus.Hello, and the Secret Service methods
OpenSession / Unlock / SearchItems / GetSecret / CreateItem / Delete /
Close.  Prompts are always "/" so no signal round-trips are required.
"""

import os
import socket
import struct
import sys
import threading


def _debug(fmt, *args):
    """Log protocol steps to stderr when DBUS_FAKE_DEBUG is set."""
    if os.environ.get("DBUS_FAKE_DEBUG"):
        print("dbus-fake: " + (fmt % args), file=sys.stderr, flush=True)

# ---------------------------------------------------------------------------
# Signature parsing
# ---------------------------------------------------------------------------

_BASIC = "ybnqiuxtdsogvh"


def _split_one(sig, i):
    """Return (complete type at sig[i:], index after it)."""
    c = sig[i]
    if c in _BASIC:
        return c, i + 1
    if c == "a":
        t, j = _split_one(sig, i + 1)
        return "a" + t, j
    if c == "(":
        out, j = "(", i + 1
        while sig[j] != ")":
            t, j = _split_one(sig, j)
            out += t
        return out + ")", j + 1
    if c == "{":
        t1, j = _split_one(sig, i + 1)
        t2, j = _split_one(sig, j)
        return "{" + t1 + t2 + "}", j + 1
    raise ValueError("bad signature %r at %d" % (sig, i))


def sig_types(sig):
    """Split a signature into its complete types."""
    types, i = [], 0
    while i < len(sig):
        t, i = _split_one(sig, i)
        types.append(t)
    return types


_BASIC_ALIGN = {
    "y": 1, "b": 4, "n": 2, "q": 2, "i": 4, "u": 4, "x": 8, "t": 8,
    "d": 8, "s": 4, "o": 4, "g": 1, "v": 1,
}


def type_align(t):
    if t[0] == "a":
        return 4
    if t[0] in "({":
        return 8
    return _BASIC_ALIGN[t[0]]


# ---------------------------------------------------------------------------
# Marshalling
# ---------------------------------------------------------------------------


class _Buf:
    """A byte buffer that tracks its absolute position for alignment."""

    def __init__(self, pos=0):
        self.b = bytearray()
        self.pos = pos

    def align(self, n):
        pad = (-self.pos) % n
        self.b += b"\x00" * pad
        self.pos += pad

    def put(self, data):
        self.b += data
        self.pos += len(data)


def marshal(buf, sig, values):
    types = sig_types(sig)
    if len(types) != len(values):
        raise ValueError("signature %r wants %d values, got %d"
                         % (sig, len(types), len(values)))
    for t, v in zip(types, values):
        _marshal_one(buf, t, v)


def _marshal_one(buf, t, v):
    c = t[0]
    if c == "y":
        buf.align(1)
        buf.put(bytes([v & 0xFF]))
    elif c == "b":
        buf.align(4)
        buf.put(struct.pack("<I", 1 if v else 0))
    elif c in "nq":
        buf.align(2)
        buf.put(struct.pack("<h" if c == "n" else "<H", v))
    elif c in "iux":
        buf.align(4)
        buf.put(struct.pack("<i" if c == "i" else "<I", v))
    elif c == "t":
        buf.align(8)
        buf.put(struct.pack("<Q", v))
    elif c == "d":
        buf.align(8)
        buf.put(struct.pack("<d", v))
    elif c in "so":
        data = v.encode()
        buf.align(4)
        buf.put(struct.pack("<I", len(data)))
        buf.put(data)
        buf.put(b"\x00")
    elif c == "g":
        data = v.encode()
        buf.put(bytes([len(data)]))
        buf.put(data)
        buf.put(b"\x00")
    elif c == "v":
        inner_sig, val = v
        _marshal_one(buf, "g", inner_sig)
        _marshal_one(buf, inner_sig, val)
    elif c == "a":
        elem = t[1:]
        buf.align(4)
        len_at = len(buf.b)
        buf.put(b"\x00\x00\x00\x00")
        # godbus' decoder aligns to the element alignment even for empty
        # arrays, so the padding must always be present.
        buf.align(type_align(elem))
        start = len(buf.b)
        if elem.startswith("{"):
            pairs = v.items() if isinstance(v, dict) else v
            for k, vv in pairs:
                buf.align(8)
                _marshal_one(buf, elem[1], k)
                _marshal_one(buf, elem[2:-1], vv)
        else:
            for item in v:
                _marshal_one(buf, elem, item)
        struct.pack_into("<I", buf.b, len_at, len(buf.b) - start)
    elif c == "(":
        buf.align(8)
        inner = sig_types(t[1:-1])
        for tt, vv in zip(inner, v):
            _marshal_one(buf, tt, vv)
    elif c == "{":
        buf.align(8)
        _marshal_one(buf, t[1], v[0])
        _marshal_one(buf, t[2:-1], v[1])
    else:
        raise ValueError("cannot marshal %r" % t)


# ---------------------------------------------------------------------------
# Unmarshalling
# ---------------------------------------------------------------------------


class _Cur:
    def __init__(self, data, pos=0):
        self.d = data
        self.pos = pos

    def align(self, n):
        self.pos += (-self.pos) % n

    def take(self, n):
        out = self.d[self.pos:self.pos + n]
        if len(out) != n:
            raise EOFError("short read")
        self.pos += n
        return out


def unmarshal(cur, sig):
    return [_unmarshal_one(cur, t) for t in sig_types(sig)]


def _unmarshal_one(cur, t):
    c = t[0]
    if c == "y":
        return cur.take(1)[0]
    if c == "b":
        cur.align(4)
        return struct.unpack("<I", cur.take(4))[0] != 0
    if c in "nq":
        cur.align(2)
        return struct.unpack("<h" if c == "n" else "<H", cur.take(2))[0]
    if c in "iux":
        cur.align(4)
        return struct.unpack("<i" if c == "i" else "<I", cur.take(4))[0]
    if c == "t":
        cur.align(8)
        return struct.unpack("<Q", cur.take(8))[0]
    if c == "d":
        cur.align(8)
        return struct.unpack("<d", cur.take(8))[0]
    if c in "so":
        cur.align(4)
        n = struct.unpack("<I", cur.take(4))[0]
        s = cur.take(n).decode()
        cur.take(1)
        return s
    if c == "g":
        n = cur.take(1)[0]
        s = cur.take(n).decode()
        cur.take(1)
        return s
    if c == "v":
        inner = _unmarshal_one(cur, "g")
        return (inner, _unmarshal_one(cur, inner))
    if c == "a":
        elem = t[1:]
        cur.align(4)
        length = struct.unpack("<I", cur.take(4))[0]
        cur.align(type_align(elem))
        end = cur.pos + length
        if elem.startswith("{"):
            out = {}
            while cur.pos < end:
                cur.align(8)
                k = _unmarshal_one(cur, elem[1])
                v = _unmarshal_one(cur, elem[2:-1])
                out[k] = v
            return out
        if elem == "y":
            # go-keyring's secret struct uses []byte fields; mirror them as
            # bytes rather than a list of ints.
            return bytes(cur.take(length))
        out = []
        while cur.pos < end:
            out.append(_unmarshal_one(cur, elem))
        return out
    if c == "(":
        cur.align(8)
        return unmarshal(cur, t[1:-1])
    if c == "{":
        cur.align(8)
        k = _unmarshal_one(cur, t[1])
        v = _unmarshal_one(cur, t[2:-1])
        return (k, v)
    raise ValueError("cannot unmarshal %r" % t)


# ---------------------------------------------------------------------------
# Message framing
# ---------------------------------------------------------------------------

METHOD_CALL = 1
METHOD_RETURN = 2
ERROR = 3

FIELD_PATH = 1
FIELD_INTERFACE = 2
FIELD_MEMBER = 3
FIELD_ERROR_NAME = 4
FIELD_REPLY_SERIAL = 5
FIELD_DESTINATION = 6
FIELD_SENDER = 7
FIELD_SIGNATURE = 8
FIELD_UNIX_FDS = 9


def build_message(msg_type, flags, serial, fields, body_sig, body):
    """Build one D-Bus message.

    fields is a list of (code, wire signature, value); body_sig/body the
    marshalled body (("", []) for no body).
    """
    buf = _Buf()
    buf.put(b"l" + bytes([msg_type, flags, 1]))
    buf.put(struct.pack("<I", 0))  # body length, patched below
    buf.put(struct.pack("<I", serial))
    buf.put(struct.pack("<I", 0))  # header array length, patched below
    # Header field array a(yv); its elements begin at offset 16, which is
    # already 8-aligned.
    arr_start = len(buf.b)
    for code, sig, value in fields:
        buf.align(8)
        buf.put(bytes([code]))
        _marshal_one(buf, "v", (sig, value))
    struct.pack_into("<I", buf.b, 12, len(buf.b) - arr_start)
    buf.align(8)
    body_start = buf.pos
    if body:
        marshal(buf, body_sig, body)
    struct.pack_into("<I", buf.b, 4, buf.pos - body_start)
    return bytes(buf.b)


# ---------------------------------------------------------------------------
# The fake bus + Secret Service
# ---------------------------------------------------------------------------

SERVICE_NAME = "org.freedesktop.secrets"
SERVICE_PATH = "/org/freedesktop/secrets"
COLLECTION_PATH = "/org/freedesktop/secrets/collection/login"
ALIAS_PATH = "/org/freedesktop/secrets/aliases/default"
CONTENT_TYPE = "text/plain; charset=utf8"

_GUID = "a1b2c3d4e5f60718293a4b5c6d7e8f90"


class FakeSecretService:
    """A thread that accepts one or more D-Bus client connections.

    Behaves as the session bus (Hello) and as org.freedesktop.secrets with a
    single "login" collection.  Every method call is recorded in ``calls``
    as (interface.Member, arguments) for assertions.
    """

    def __init__(self, socket_path):
        self.socket_path = str(socket_path)
        self.address = "unix:path=" + self.socket_path
        self.items = {}  # object path -> {attrs, value, label}
        self._next_item = 0
        self._next_session = 0
        self._sessions = set()
        self.calls = []  # ("Service.OpenSession", args) tuples
        self._serial = 1
        self._lock = threading.Lock()
        self._lsock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._lsock.bind(self.socket_path)
        self._lsock.listen(4)
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()

    # -- public helpers ----------------------------------------------------

    def method_names(self):
        return [name for name, _ in self.calls]

    def close(self):
        try:
            self._lsock.close()
        except OSError:
            pass

    # -- socket serving ----------------------------------------------------

    def _serve(self):
        while True:
            try:
                conn, _ = self._lsock.accept()
            except OSError:
                return
            try:
                self._handle_connection(conn)
            except Exception:
                pass
            finally:
                try:
                    conn.close()
                except OSError:
                    pass

    def _handle_connection(self, conn):
        f = conn.makefile("rb")

        # SASL handshake: godbus sends a NUL byte, bare AUTH, then
        # AUTH EXTERNAL <hex uid>, optionally NEGOTIATE_UNIX_FD, BEGIN.
        f.read(1)
        while True:
            line = f.readline()
            if not line:
                return
            line = line.strip().decode()
            if line == "AUTH":
                conn.sendall(b"REJECTED EXTERNAL DBUS_COOKIE_SHA1\r\n")
            elif line.startswith("AUTH EXTERNAL"):
                conn.sendall(b"OK " + _GUID.encode() + b"\r\n")
            elif line == "NEGOTIATE_UNIX_FD":
                conn.sendall(b"AGREE_UNIX_FD\r\n")
            elif line == "BEGIN":
                break
            else:
                conn.sendall(b"ERROR\r\n")

        while True:
            fixed = self._read_exact(f, 16)
            if fixed is None:
                return
            if fixed[0] != ord("l"):
                return
            msg_type, flags = fixed[1], fixed[2]
            body_len, serial, hlen = struct.unpack("<III", fixed[4:16])
            pad = (-(16 + hlen)) % 8
            rest = self._read_exact(f, hlen + pad + body_len)
            if rest is None:
                return
            fields = self._parse_header_fields(rest[:hlen])
            body_sig = fields.get(FIELD_SIGNATURE, "")
            body_off = hlen + pad
            body = []
            if body_sig:
                cur = _Cur(rest, body_off)
                body = unmarshal(cur, body_sig)
            _debug("recv type=%d serial=%d path=%r iface=%r member=%r sig=%r body=%r",
                   msg_type, serial, fields.get(FIELD_PATH, ""),
                   fields.get(FIELD_INTERFACE, ""), fields.get(FIELD_MEMBER, ""),
                   body_sig, body)
            reply = self._dispatch(
                fields.get(FIELD_PATH, ""),
                fields.get(FIELD_INTERFACE, ""),
                fields.get(FIELD_MEMBER, ""),
                body,
            )
            if reply is None:
                continue
            reply_type, reply_sig, reply_body, error_name = reply
            out_fields = [
                (FIELD_REPLY_SERIAL, "u", serial),
                (FIELD_SENDER, "s", ":1.0"),
            ]
            if reply_sig:
                out_fields.append((FIELD_SIGNATURE, "g", reply_sig))
            if error_name:
                out_fields.append((FIELD_ERROR_NAME, "s", error_name))
            with self._lock:
                self._serial += 1
                out_serial = self._serial
            conn.sendall(build_message(
                reply_type, 1, out_serial, out_fields, reply_sig, reply_body,
            ))

    @staticmethod
    def _read_exact(f, n):
        data = f.read(n)
        if data is None or len(data) != n:
            return None
        return data

    @staticmethod
    def _parse_header_fields(array_bytes):
        # The array length prefix lives in the fixed header (bytes 12-16);
        # array_bytes holds the struct elements only.  They are 8-aligned
        # relative to the message start, and the array begins at message
        # offset 16, so relative and absolute alignment coincide.
        cur = _Cur(array_bytes, 0)
        fields = {}
        while cur.pos < len(array_bytes):
            cur.align(8)
            code = cur.take(1)[0]
            _sig, value = _unmarshal_one(cur, "v")
            fields[code] = value
        return fields

    # -- method dispatch ---------------------------------------------------

    def _dispatch(self, path, interface, member, body):
        key = interface + "." + member
        with self._lock:
            self.calls.append((key, body))

        if interface == "org.freedesktop.DBus":
            if member == "Hello":
                return METHOD_RETURN, "s", [":1.1"], None
            return METHOD_RETURN, "", [], None

        if interface == "org.freedesktop.DBus.Properties":
            # go-keyring asks for the Service's Collections property to
            # decide between the "login" collection and the default alias.
            prop = body[1] if len(body) > 1 else ""
            if prop == "Collections":
                return METHOD_RETURN, "v", [("ao", [COLLECTION_PATH])], None
            return ERROR, "s", ["no such property " + prop], \
                "org.freedesktop.DBus.Error.InvalidArgs"

        if interface == "org.freedesktop.Secret.Service":
            if member == "OpenSession":
                with self._lock:
                    self._next_session += 1
                    session = "%s/session/s%d" % (
                        SERVICE_PATH, self._next_session,
                    )
                    self._sessions.add(session)
                return METHOD_RETURN, "vo", [("s", ""), session], None
            if member == "Unlock":
                paths = body[0]
                return METHOD_RETURN, "aoo", [paths, "/"], None
            return self._unknown(key)

        if interface == "org.freedesktop.Secret.Collection":
            if member == "SearchItems":
                attrs = body[0]
                matches = [
                    item_path
                    for item_path, item in self.items.items()
                    if all(item["attrs"].get(k) == v for k, v in attrs.items())
                ]
                return METHOD_RETURN, "ao", [matches], None
            if member == "CreateItem":
                properties = body[0]
                secret = body[1]
                attrs = properties.get("org.freedesktop.Secret.Item.Attributes",
                                       ({}, ""))[1]
                label = properties.get("org.freedesktop.Secret.Item.Label",
                                       ("", ""))[1]
                value = secret[2].decode()
                with self._lock:
                    for item_path, item in self.items.items():
                        if item["attrs"] == attrs:
                            item["value"] = value
                            item["label"] = label
                            return METHOD_RETURN, "oo", [item_path, "/"], None
                    self._next_item += 1
                    item_path = "%s/i%d" % (COLLECTION_PATH, self._next_item)
                    self.items[item_path] = {
                        "attrs": attrs, "value": value, "label": label,
                    }
                return METHOD_RETURN, "oo", [item_path, "/"], None
            return self._unknown(key)

        if interface == "org.freedesktop.Secret.Item":
            if member == "GetSecret":
                session = body[0]
                item = self.items.get(path)
                if item is None:
                    return ERROR, "s", ["no such item"], \
                        "org.freedesktop.Secret.Error.NoSuchObject"
                return METHOD_RETURN, "(oayays)", [
                    (session, [], item["value"].encode(), CONTENT_TYPE),
                ], None
            if member == "Delete":
                self.items.pop(path, None)
                return METHOD_RETURN, "o", ["/"], None
            return self._unknown(key)

        if interface == "org.freedesktop.Secret.Session":
            if member == "Close":
                self._sessions.discard(path)
                return METHOD_RETURN, "", [], None
            return self._unknown(key)

        return self._unknown(key)

    @staticmethod
    def _unknown(key):
        return ERROR, "s", ["no such method " + key], \
            "org.freedesktop.DBus.Error.UnknownMethod"
