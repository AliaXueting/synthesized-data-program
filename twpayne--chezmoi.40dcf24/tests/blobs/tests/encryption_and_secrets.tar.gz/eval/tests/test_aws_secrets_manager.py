"""The awsSecretsManager / awsSecretsManagerRaw template functions.

The AWS SDK honors the AWS_ENDPOINT_URL_SECRETS_MANAGER environment
override, so both functions run hermetically against a loopback HTTP
server speaking the Secrets Manager JSON protocol.  The server records
every request (target header, SigV4 Authorization, body), which exposes
the client options chezmoi passes to the SDK: the configured region and
profile, environment credentials, the retry cap of a single attempt, and
the per-template result caches.
"""

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from conftest import make_home, run_chezmoi, write_config, write_script

AWS_ENV = {
    "AWS_ACCESS_KEY_ID": "AKIATESTTESTTESTTEST",
    "AWS_SECRET_ACCESS_KEY": "secretkey",
}
REGION_CONFIG = '[awsSecretsManager]\nregion = "us-east-1"\n'
# The binary secret is base64-encoded twice on the wire: the SDK decodes
# the JSON encoding of the SecretBinary bytes, chezmoi decodes the
# resulting payload again.  This is base64(base64("plain-text-binary")).
BINARY_WIRE = "Y0d4aGFXNHRkR1Y0ZEMxaWFXNWhjbms9"
# The same payload encoded only once: chezmoi's second decode fails.
BINARY_WIRE_SINGLE = "cGxhaW4tdGV4dC1iaW5hcnk="


class _Handler(BaseHTTPRequestHandler):
    """Dispatch Secrets Manager GetSecretValue calls by SecretId."""

    def do_POST(self):
        server = self.server
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        try:
            payload = json.loads(body.decode())
        except ValueError:
            payload = {}
        secret_id = payload.get("SecretId", "")
        server.requests.append({
            "target": self.headers.get("X-Amz-Target"),
            "auth": self.headers.get("Authorization"),
            "secret_id": secret_id,
        })
        if secret_id in server.errors:
            status, document = server.errors[secret_id]
            self.send_response(status)
            self.send_header("x-amzn-RequestId", "REQ-1234-5678")
            self.end_headers()
            self.wfile.write(json.dumps(document).encode())
            return
        if secret_id not in server.secrets:
            raise AssertionError("unexpected SecretId %r" % secret_id)
        document = dict(server.secrets[secret_id])
        document.setdefault("Name", secret_id)
        document["ARN"] = (
            "arn:aws:secretsmanager:us-east-1:123456789012:secret:x"
        )
        document["VersionId"] = "V1"
        document["CreatedDate"] = 1.7e9
        self.send_response(200)
        self.send_header("Content-Type", "application/x-amz-json-1.1")
        self.end_headers()
        self.wfile.write(json.dumps(document).encode())

    def log_message(self, *args):
        pass


@pytest.fixture
def secrets_manager():
    """A loopback Secrets Manager endpoint recording every request."""
    server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    server.secrets = {}
    server.errors = {}
    server.requests = []
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield server
    server.shutdown()
    server.server_close()


def run_aws_template(server, tmp_path, template, *, config=REGION_CONFIG,
                     env=None):
    """Run execute-template against the fake endpoint with env credentials."""
    home = make_home(tmp_path)
    child_env = dict(AWS_ENV)
    child_env["AWS_ENDPOINT_URL_SECRETS_MANAGER"] = (
        "http://127.0.0.1:%d" % server.server_address[1]
    )
    if env:
        child_env.update(env)
    return run_chezmoi(
        [
            "--no-tty",
            "--config", write_config(tmp_path, config),
            "execute-template", template,
        ],
        cwd=home,
        home=home,
        env=child_env,
    )


def test_aws_secrets_manager_raw_returns_secret_string(
    tmp_path, secrets_manager
):
    """awsSecretsManagerRaw returns SecretString verbatim over SigV4."""
    secrets_manager.secrets["arn:raw"] = {"SecretString": "the-secret-value"}
    result = run_aws_template(
        secrets_manager, tmp_path, '{{ awsSecretsManagerRaw "arn:raw" }}'
    )
    # CATCHES: the raw function returns the SecretString field unchanged,
    # addressed by a signed secretsmanager.GetSecretValue call carrying the
    # environment credentials.
    assert result.returncode == 0
    assert result.stdout == b"the-secret-value"
    assert result.stderr == b""
    assert len(secrets_manager.requests) == 1
    request = secrets_manager.requests[0]
    assert request["target"] == "secretsmanager.GetSecretValue"
    assert request["secret_id"] == "arn:raw"
    assert "Credential=AKIATESTTESTTESTTEST/" in request["auth"]


def test_aws_secrets_manager_raw_caches_repeated_lookups(
    tmp_path, secrets_manager
):
    """Two identical raw lookups in one template make one API call."""
    secrets_manager.secrets["arn:raw"] = {"SecretString": "the-secret-value"}
    result = run_aws_template(
        secrets_manager, tmp_path,
        '{{ awsSecretsManagerRaw "arn:raw" }}+'
        '{{ awsSecretsManagerRaw "arn:raw" }}',
    )
    # CATCHES: the raw cache is keyed by ARN, so the second template call
    # is served from memory and the endpoint sees a single request.
    assert result.returncode == 0
    assert result.stdout == b"the-secret-value+the-secret-value"
    assert len(secrets_manager.requests) == 1


def test_aws_secrets_manager_json_parses_and_caches(
    tmp_path, secrets_manager
):
    """awsSecretsManager parses the secret as JSON and caches the map."""
    secrets_manager.secrets["arn:json"] = {
        "SecretString": '{"password": "hunter2", "nested": {"deep": "leaf"}}'
    }
    result = run_aws_template(
        secrets_manager, tmp_path,
        '{{ (awsSecretsManager "arn:json").nested.deep }}'
        '|{{ (awsSecretsManager "arn:json").password }}',
    )
    # CATCHES: the JSON function decodes the secret into a map (nested
    # field access works) and its own cache serves the second call, so the
    # secret is fetched once for both lookups.
    assert result.returncode == 0
    assert result.stdout == b"leaf|hunter2"
    assert len(secrets_manager.requests) == 1


def test_aws_secrets_manager_json_reuses_raw_fetch(
    tmp_path, secrets_manager
):
    """The JSON function shares its fetch with the raw function's cache."""
    raw_json = '{"password": "hunter2", "nested": {"deep": "leaf"}}'
    secrets_manager.secrets["arn:json"] = {"SecretString": raw_json}
    result = run_aws_template(
        secrets_manager, tmp_path,
        '{{ (awsSecretsManager "arn:json").password }}'
        '|{{ awsSecretsManagerRaw "arn:json" }}',
    )
    # CATCHES: awsSecretsManager delegates to the raw function for the
    # fetch, and a following raw call for the same ARN is served from the
    # shared cache: one request, both views of the secret.
    assert result.returncode == 0
    assert result.stdout == b"hunter2|" + raw_json.encode()
    assert len(secrets_manager.requests) == 1


def test_aws_secrets_manager_json_rejects_non_json_secret(
    tmp_path, secrets_manager
):
    """A non-JSON secret fails inside awsSecretsManager's json.Unmarshal."""
    secrets_manager.secrets["arn:badjson"] = {
        "SecretString": "hunter2-not-json"
    }
    result = run_aws_template(
        secrets_manager, tmp_path,
        '{{ (awsSecretsManager "arn:badjson").x }}',
    )
    # CATCHES: the raw fetch succeeds but the JSON decode of the
    # non-JSON secret panics with encoding/json's error, wrapped in the
    # template error context of the awsSecretsManager call.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'chezmoi: template: arg1:1:4: executing "arg1" '
        'at <awsSecretsManager "arn:badjson">: '
        "error calling awsSecretsManager: "
        "invalid character 'h' looking for beginning of value\n"
    )


def test_aws_secrets_manager_binary_secret_is_decoded_twice(
    tmp_path, secrets_manager
):
    """SecretBinary payloads go through a second base64 decode."""
    secrets_manager.secrets["arn:binary"] = {"SecretBinary": BINARY_WIRE}
    result = run_aws_template(
        secrets_manager, tmp_path, '{{ awsSecretsManagerRaw "arn:binary" }}'
    )
    # CATCHES: the SDK hands over the decoded SecretBinary bytes and
    # chezmoi base64-decodes them a second time - a single-encoded
    # payload of "plain-text-binary" is therefore returned as plaintext.
    assert result.returncode == 0
    assert result.stdout == b"plain-text-binary"
    assert result.stderr == b""


def test_aws_secrets_manager_binary_requires_base64_payload(
    tmp_path, secrets_manager
):
    """SecretBinary bytes that are not base64 fail the second decode."""
    secrets_manager.secrets["arn:binary1"] = {
        "SecretBinary": BINARY_WIRE_SINGLE
    }
    result = run_aws_template(
        secrets_manager, tmp_path, '{{ awsSecretsManagerRaw "arn:binary1" }}'
    )
    # CATCHES: only base64 text can survive the second decode - the raw
    # bytes "plain-text-binary" are rejected at the first non-alphabet
    # character, with the byte offset in the error.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'chezmoi: template: arg1:1:3: executing "arg1" '
        'at <awsSecretsManagerRaw "arn:binary1">: '
        "error calling awsSecretsManagerRaw: "
        "illegal base64 data at input byte 5\n"
    )


def test_aws_secrets_manager_http_error_names_the_exception(
    tmp_path, secrets_manager
):
    """A 400 response surfaces as the typed operation error."""
    secrets_manager.errors["arn:denied"] = (
        400,
        {
            "__type": "ResourceNotFoundException",
            "Message": "Secrets Manager can't find the requested secret.",
        },
    )
    result = run_aws_template(
        secrets_manager, tmp_path, '{{ awsSecretsManagerRaw "arn:denied" }}'
    )
    # CATCHES: the SDK error is reported with the operation name, the HTTP
    # status, the x-amzn-RequestId header, and the __type/Message pair
    # from the error document - all in one line.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'chezmoi: template: arg1:1:3: executing "arg1" '
        'at <awsSecretsManagerRaw "arn:denied">: '
        "error calling awsSecretsManagerRaw: "
        "operation error Secrets Manager: GetSecretValue, "
        "https response error StatusCode: 400, "
        "RequestID: REQ-1234-5678, "
        "ResourceNotFoundException: "
        "Secrets Manager can't find the requested secret.\n"
    )


def test_aws_secrets_manager_does_not_retry(
    tmp_path, secrets_manager
):
    """A 500 response is attempted exactly once."""
    secrets_manager.errors["arn:boom"] = (
        500,
        {"__type": "InternalServiceError", "Message": "boom"},
    )
    result = run_aws_template(
        secrets_manager, tmp_path, '{{ awsSecretsManagerRaw "arn:boom" }}'
    )
    # CATCHES: chezmoi configures the client with a single retry attempt,
    # so one failing request is enough - the error reports the exhausted
    # retry budget ("exceeded maximum number of attempts, 1") and the
    # endpoint saw exactly one request.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'chezmoi: template: arg1:1:3: executing "arg1" '
        'at <awsSecretsManagerRaw "arn:boom">: '
        "error calling awsSecretsManagerRaw: "
        "operation error Secrets Manager: GetSecretValue, "
        "exceeded maximum number of attempts, 1, "
        "https response error StatusCode: 500, "
        "RequestID: REQ-1234-5678, "
        "InternalServiceError: boom\n"
    )
    assert len(secrets_manager.requests) == 1


def test_aws_secrets_manager_missing_profile_fails_without_requests(
    tmp_path, secrets_manager
):
    """An unknown profile fails at SDK config load, before any request."""
    secrets_manager.secrets["arn:raw"] = {"SecretString": "the-secret-value"}
    result = run_aws_template(
        secrets_manager, tmp_path,
        '{{ awsSecretsManagerRaw "arn:raw" }}',
        config='[awsSecretsManager]\nregion = "us-east-1"\n'
               'profile = "nonexistent-profile"\n',
    )
    # CATCHES: the profile key is passed to the SDK as the shared config
    # profile; a profile missing from ~/.aws/config fails immediately with
    # the profile name, and no HTTP request is made.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'chezmoi: template: arg1:1:3: executing "arg1" '
        'at <awsSecretsManagerRaw "arn:raw">: '
        "error calling awsSecretsManagerRaw: "
        "failed to get shared config profile, nonexistent-profile\n"
    )
    assert secrets_manager.requests == []


def test_aws_secrets_manager_profile_uses_shared_config_credentials(
    tmp_path, secrets_manager
):
    """A configured profile switches credentials away from the environ."""
    home = tmp_path / "home"
    make_home(tmp_path)
    cred_script = write_script(
        tmp_path / "cred.sh",
        "#!/bin/sh\n"
        "printf '%s\\n' "
        "'{\"Version\":1,\"AccessKeyId\":\"AKIAPROFILECREDS\","
        "\"SecretAccessKey\":\"PROFILESECRET\"}'\n",
    )
    (home / ".aws").mkdir()
    (home / ".aws" / "config").write_text(
        "[profile goodprofile]\n"
        "endpoint_url = http://127.0.0.1:%d\n"
        "credential_process = %s\n"
        % (secrets_manager.server_address[1], cred_script)
    )
    secrets_manager.secrets["arn:raw"] = {"SecretString": "the-secret-value"}
    result = run_aws_template(
        secrets_manager, tmp_path,
        '{{ awsSecretsManagerRaw "arn:raw" }}',
        config='[awsSecretsManager]\nregion = "us-east-1"\n'
               'profile = "goodprofile"\n',
    )
    # CATCHES: with a profile set, the SDK credential chain resolves
    # through the shared config's credential_process - the request is
    # signed with AKIAPROFILECREDS even though environment credentials
    # are present (the profile wins).
    assert result.returncode == 0
    assert result.stdout == b"the-secret-value"
    assert result.stderr == b""
    assert len(secrets_manager.requests) == 1
    assert "Credential=AKIAPROFILECREDS/" in secrets_manager.requests[0]["auth"]


def test_aws_secrets_manager_region_is_optional_with_endpoint(
    tmp_path, secrets_manager
):
    """An empty [awsSecretsManager] section still fetches the secret."""
    secrets_manager.secrets["arn:raw"] = {"SecretString": "the-secret-value"}
    result = run_aws_template(
        secrets_manager, tmp_path,
        '{{ awsSecretsManagerRaw "arn:raw" }}',
        config="[awsSecretsManager]\n",
    )
    # CATCHES: the region key is only forwarded to the SDK when set - an
    # empty section works because the endpoint override makes a region
    # unnecessary (the request is signed with an empty region scope).
    assert result.returncode == 0
    assert result.stdout == b"the-secret-value"
    assert result.stderr == b""
