"""The keyring success paths, driven through a fake D-Bus Secret Service.

eval/tests/dbus_secrets.py implements just enough of the D-Bus wire
protocol and the org.freedesktop.secrets API - in pure Python, on a unix
socket inside the test's tmp_path - for chezmoi's keyring support to run
its success paths hermetically: `secret keyring set/get/delete` and the
`keyring` template function.  Every method call is recorded, so the tests
assert not only the CLI behavior but also the exact Secret Service
protocol each operation follows, and that the template function caches
lookups.
"""

import pytest

from conftest import make_home, run_chezmoi
from dbus_secrets import FakeSecretService

NOT_FOUND = b"chezmoi: secret not found in keyring\n"

# The exact method-call sequence go-keyring uses for a lookup: connect
# (Hello), find the default collection (Properties.Get + Unlock), search
# by attributes, open a session, unlock the found item, read the secret,
# close the session.
GET_SEQUENCE = [
    "org.freedesktop.DBus.Hello",
    "org.freedesktop.DBus.Properties.Get",
    "org.freedesktop.Secret.Service.Unlock",
    "org.freedesktop.Secret.Collection.SearchItems",
    "org.freedesktop.Secret.Service.OpenSession",
    "org.freedesktop.Secret.Service.Unlock",
    "org.freedesktop.Secret.Item.GetSecret",
    "org.freedesktop.Secret.Session.Close",
]

DELETE_SEQUENCE = [
    "org.freedesktop.DBus.Hello",
    "org.freedesktop.DBus.Properties.Get",
    "org.freedesktop.Secret.Service.Unlock",
    "org.freedesktop.Secret.Collection.SearchItems",
    "org.freedesktop.Secret.Item.Delete",
]


@pytest.fixture
def service(tmp_path):
    """A fake session bus + Secret Service recording every method call."""
    fake = FakeSecretService(tmp_path / "keyring-bus")
    yield fake
    fake.close()


def run_keyring(service, tmp_path, args, *, stdin=b""):
    """Run a `secret keyring` subcommand against the fake service."""
    home = make_home(tmp_path)
    return run_chezmoi(
        ["--no-tty"] + args,
        cwd=home,
        home=home,
        env={"DBUS_SESSION_BUS_ADDRESS": service.address},
        stdin=stdin,
    )


def run_template(service, tmp_path, template):
    """Run execute-template with the fake bus as the session bus."""
    home = make_home(tmp_path)
    return run_chezmoi(
        ["--no-tty", "execute-template", template],
        cwd=home,
        home=home,
        env={"DBUS_SESSION_BUS_ADDRESS": service.address},
    )


def test_keyring_set_get_delete_roundtrip(tmp_path, service):
    """set stores a secret, get prints it, delete removes it again."""
    set_result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "set", "--service", "svc", "--user", "usr",
         "--value", "the-password"],
    )
    assert set_result.returncode == 0
    assert set_result.stdout == b""
    assert set_result.stderr == b""
    get_result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "get", "--service", "svc", "--user", "usr"],
    )
    assert get_result.returncode == 0
    assert get_result.stdout == b"the-password"
    assert get_result.stderr == b""
    delete_result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "delete", "--service", "svc", "--user", "usr"],
    )
    assert delete_result.returncode == 0
    assert delete_result.stdout == b""
    assert delete_result.stderr == b""
    after = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "get", "--service", "svc", "--user", "usr"],
    )
    # CATCHES: `get` writes the stored value with no trailing newline and
    # is silent on stderr; after `delete` removes the item the same lookup
    # reports "secret not found in keyring" - the library's ErrNotFound.
    assert after.returncode == 1
    assert after.stdout == b""
    assert after.stderr == NOT_FOUND


def test_keyring_get_follows_secret_service_protocol(tmp_path, service):
    """A lookup runs the full Secret Service call sequence."""
    run_keyring(
        service, tmp_path,
        ["secret", "keyring", "set", "--service", "svc", "--user", "usr",
         "--value", "the-password"],
    )
    before = len(service.calls)
    result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "get", "--service", "svc", "--user", "usr"],
    )
    assert result.returncode == 0
    assert result.stdout == b"the-password"
    calls = service.calls[before:]
    # CATCHES: the lookup follows the recorded Secret Service protocol
    # exactly: search by {username, service} attributes in the login
    # collection, open a plain session for the secret transfer, unlock the
    # found item (not just the collection), and close the session - and
    # GetSecret names the session opened in this same sequence.
    assert [name for name, _ in calls] == GET_SEQUENCE
    assert calls[3][1] == [{"username": "usr", "service": "svc"}]
    assert calls[4][1][0] == "plain"
    assert calls[4][1][1] == ("s", "")
    assert calls[5][1] == [["/org/freedesktop/secrets/collection/login/i1"]]
    assert calls[6][1] == ["/org/freedesktop/secrets/session/s2"]


def test_keyring_set_creates_item_with_attributes(tmp_path, service):
    """set creates a Secret Service item with go-keyring's label format."""
    result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "set", "--service", "mysvc",
         "--user", "myuser", "--value", "pw123"],
    )
    assert result.returncode == 0
    calls = dict((name, body) for name, body in service.calls)
    # CATCHES: CreateItem receives the go-keyring label format
    # "Password for '<user>' on '<service>'", the {username, service}
    # attribute map used for later searches, the secret transferred over
    # the session opened by this same command with a text/plain content
    # type, and replace=true.
    create = calls["org.freedesktop.Secret.Collection.CreateItem"]
    properties, secret, replace = create
    assert properties["org.freedesktop.Secret.Item.Label"] == (
        "s", "Password for 'myuser' on 'mysvc'"
    )
    assert properties["org.freedesktop.Secret.Item.Attributes"] == (
        "a{ss}", {"username": "myuser", "service": "mysvc"}
    )
    assert secret[0] == "/org/freedesktop/secrets/session/s1"
    assert secret[1] == b""
    assert secret[2] == b"pw123"
    assert secret[3] == "text/plain; charset=utf8"
    assert replace is True


def test_keyring_set_prompts_and_reads_value_from_stdin(tmp_path, service):
    """set without --value prompts "Value: " and reads stdin."""
    result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "set", "--service", "svc", "--user", "usr"],
        stdin=b"typed-secret\n",
    )
    assert result.returncode == 0
    assert result.stdout == b"Value: "
    assert result.stderr == b""
    stored = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "get", "--service", "svc", "--user", "usr"],
    )
    # CATCHES: the interactive prompt is exactly "Value: " on stdout (no
    # newline) and the line read from stdin is stored as the secret.
    assert stored.returncode == 0
    assert stored.stdout == b"typed-secret"


def test_keyring_set_overwrites_existing_secret(tmp_path, service):
    """Setting an existing service/user pair replaces the stored value."""
    for value in ("first-value", "second-value"):
        result = run_keyring(
            service, tmp_path,
            ["secret", "keyring", "set", "--service", "svc",
             "--user", "usr", "--value", value],
        )
        assert result.returncode == 0
    stored = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "get", "--service", "svc", "--user", "usr"],
    )
    # CATCHES: a second set for the same attribute map runs CreateItem
    # with replace semantics again, so the stored value is the latest one
    # (no duplicate items are created).
    assert stored.returncode == 0
    assert stored.stdout == b"second-value"
    assert service.method_names().count(
        "org.freedesktop.Secret.Collection.CreateItem"
    ) == 2
    assert len(service.items) == 1


def test_keyring_get_missing_secret_reports_not_found(tmp_path, service):
    """get of a never-stored pair reports the library's not-found error."""
    result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "get", "--service", "svc", "--user", "nobody"],
    )
    # CATCHES: an empty search result is translated to go-keyring's
    # ErrNotFound message with the chezmoi prefix, on stderr only.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == NOT_FOUND


def test_keyring_delete_missing_secret_reports_not_found(tmp_path, service):
    """delete of a never-stored pair reports the same not-found error."""
    result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "delete", "--service", "svc", "--user", "nobody"],
    )
    # CATCHES: delete runs the same attribute search and reports the
    # not-found error for an empty result instead of touching the
    # collection.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == NOT_FOUND
    assert "org.freedesktop.Secret.Item.Delete" not in service.method_names()


def test_keyring_delete_follows_secret_service_protocol(tmp_path, service):
    """delete searches by attributes and deletes the found item."""
    run_keyring(
        service, tmp_path,
        ["secret", "keyring", "set", "--service", "svc", "--user", "usr",
         "--value", "the-password"],
    )
    before = len(service.calls)
    result = run_keyring(
        service, tmp_path,
        ["secret", "keyring", "delete", "--service", "svc", "--user", "usr"],
    )
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    calls = service.calls[before:]
    # CATCHES: deletion needs no secret transfer - the sequence stops
    # after the attribute search and the Item.Delete call (no session is
    # opened, nothing is unlocked beyond the collection).
    assert [name for name, _ in calls] == DELETE_SEQUENCE
    assert calls[3][1] == [{"username": "usr", "service": "svc"}]


def test_keyring_template_func_returns_secret(tmp_path, service):
    """The keyring template function returns the stored secret."""
    run_keyring(
        service, tmp_path,
        ["secret", "keyring", "set", "--service", "svc", "--user", "usr",
         "--value", "the-password"],
    )
    result = run_template(
        service, tmp_path, '{{ keyring "svc" "usr" }}'
    )
    # CATCHES: the template function returns the same value the CLI
    # reports, rendered straight into the template output.
    assert result.returncode == 0
    assert result.stdout == b"the-password"
    assert result.stderr == b""


def test_keyring_template_func_caches_lookups(tmp_path, service):
    """Two identical template lookups make a single Secret Service call."""
    run_keyring(
        service, tmp_path,
        ["secret", "keyring", "set", "--service", "svc", "--user", "usr",
         "--value", "the-password"],
    )
    before = len(service.calls)
    result = run_template(
        service, tmp_path, '{{ keyring "svc" "usr" }}+{{ keyring "svc" "usr" }}'
    )
    assert result.returncode == 0
    assert result.stdout == b"the-password+the-password"
    calls = service.calls[before:]
    # CATCHES: the template function caches lookups by (service, user) -
    # both template calls are served by one full Secret Service sequence
    # (a single SearchItems and a single GetSecret).
    assert [name for name, _ in calls] == GET_SEQUENCE


def test_keyring_template_func_missing_secret_error(tmp_path, service):
    """The template function wraps the not-found error with service/user."""
    result = run_template(
        service, tmp_path, '{{ keyring "testservice" "nobody" }}'
    )
    # CATCHES: a failed lookup inside a template reports the go-keyring
    # error prefixed with the "<service> <user>" pair from the call, in
    # the standard template error location format.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.decode() == (
        'chezmoi: template: arg1:1:3: executing "arg1" '
        'at <keyring "testservice" "nobody">: '
        "error calling keyring: "
        "testservice nobody: secret not found in keyring\n"
    )


def test_keyring_template_func_preserves_special_characters(tmp_path, service):
    """Secrets with newlines, quotes, and dollars survive verbatim."""
    value = 'line1\nline2 "quoted" $dollar'
    run_keyring(
        service, tmp_path,
        ["secret", "keyring", "set", "--service", "svc", "--user", "usr",
         "--value", value],
    )
    result = run_template(service, tmp_path, '{{ keyring "svc" "usr" }}')
    # CATCHES: the secret is transferred as raw bytes (not through a
    # shell or template escaping), so newlines, double quotes, and dollar
    # signs come back exactly as stored.
    assert result.returncode == 0
    assert result.stdout == value.encode()
