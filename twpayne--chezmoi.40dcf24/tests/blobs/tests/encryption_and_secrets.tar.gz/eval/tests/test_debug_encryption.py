"""The debugEncryption wrapper's file-oriented methods.

`--debug` routes every encryption operation through a slog logger with
`component=encryption`.  The `encrypt`/`decrypt` command tests already
assert the msg=Encrypt and msg=Decrypt records; these tests drive the
remaining methods - DecryptToFile and EncryptFile - through
`edit-encrypted` and `edit`, including their error paths, asserting the
exact log records (with the random private temp directories normalized).
"""

import re

from conftest import (
    age_keypair,
    make_home,
    run_chezmoi,
    write_config,
    write_script,
)

# chezmoi's debug log truncates the ciphertext attribute after a fixed
# length; the age ASCII armor always begins with the same header, so the
# truncated value is deterministic ("\n" is the escaped newline in the
# quoted slog value).
TRUNCATED_CIPHERTEXT = (
    r'ciphertext="-----BEGIN AGE ENCRYPTED FILE-----\\n'
    r'YWdlLWVuY3J5cHRpb24ub3JnL3YxC\.\.\."'
)

DECRYPT_TO_FILE_RE = re.compile(
    r"level=INFO msg=DecryptToFile component=encryption "
    r"plaintextAbsPath=/tmp/(chezmoi-edit-encrypted\d+)/"
    r"\.local/share/chezmoi/encrypted_ee\.txt\.age "
    + TRUNCATED_CIPHERTEXT
)

ENCRYPT_FILE_RE = re.compile(
    r"level=INFO msg=EncryptFile component=encryption "
    r"plaintextAbsPath=/tmp/(chezmoi-edit-encrypted\d+)/"
    r"\.local/share/chezmoi/encrypted_ee\.txt\.age "
    + TRUNCATED_CIPHERTEXT
)

DECRYPT_LINE_RE = re.compile(
    r"level=INFO msg=Decrypt component=encryption "
    + TRUNCATED_CIPHERTEXT
    + r' plaintext="ee secret\\n"'
)

EDIT_ENCRYPT_FILE_RE = re.compile(
    r"level=INFO msg=EncryptFile component=encryption "
    r"plaintextAbsPath=/tmp/chezmoi-encrypted\d+/ee\.txt "
    + TRUNCATED_CIPHERTEXT
)

DECRYPT_TO_FILE_ERROR_RE = re.compile(
    r'level=ERROR msg=DecryptToFile component=encryption '
    r'err="failed to read header: parsing age header: '
    r'unexpected intro: \\"this is not ciphertext\\"" '
    r"plaintextAbsPath=/tmp/chezmoi-edit-encrypted\d+/"
    r"\.local/share/chezmoi/encrypted_corrupt\.txt\.age "
    r'ciphertext="this is not ciphertext\\n"'
)

ENCRYPT_FILE_ERROR_RE = re.compile(
    r'level=ERROR msg=EncryptFile component=encryption '
    r'err="no recipients specified" '
    r"plaintextAbsPath=/tmp/chezmoi-encrypted\d+/ee\.txt "
    r'ciphertext=""'
)


def age_config(tmp_path, home):
    """A config with a fresh age key pair; return the config path."""
    identity, recipient = age_keypair(tmp_path, home)
    return write_config(
        tmp_path,
        'encryption = "age"\n[age]\nrecipient = "%s"\nidentity = "%s"\n'
        % (recipient, identity),
    )


def encryption_lines(stderr):
    """Extract the component=encryption debug records, timestamps stripped."""
    lines = []
    for line in stderr.decode().splitlines():
        if " component=encryption " in line:
            lines.append(re.sub(r"^time=\S+ ", "", line))
    return lines


def test_debug_edit_encrypted_logs_decrypt_to_file_and_encrypt_file(tmp_path):
    """--debug edit-encrypted logs DecryptToFile then EncryptFile."""
    home = make_home(tmp_path)
    config = age_config(tmp_path, home)
    editor = write_script(
        tmp_path / "editor.sh", '#!/bin/sh\nprintf \'added by editor\\n\' >> "$1"\n'
    )
    (home / "ee.txt").write_text("ee secret\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "ee.txt"], cwd=home, home=home
    )
    result = run_chezmoi(
        ["--config", config, "--no-tty", "--debug", "edit-encrypted",
         ".local/share/chezmoi/encrypted_ee.txt.age"],
        cwd=home,
        home=home,
        env={"EDITOR": editor},
    )
    # CATCHES: edit-encrypted decrypts the source file into a private
    # chezmoi-edit-encrypted temp dir (msg=DecryptToFile) and re-encrypts
    # the edited copy from the same temp path (msg=EncryptFile) - both
    # records name the temp file and the truncated ciphertext.
    assert result.returncode == 0
    lines = encryption_lines(result.stderr)
    assert len(lines) == 2
    match_decrypt = DECRYPT_TO_FILE_RE.fullmatch(lines[0])
    match_encrypt = ENCRYPT_FILE_RE.fullmatch(lines[1])
    assert match_decrypt, lines[0]
    assert match_encrypt, lines[1]
    assert match_decrypt.group(1) == match_encrypt.group(1)
    cat = run_chezmoi(
        ["--config", config, "cat", "ee.txt"], cwd=home, home=home
    )
    assert cat.returncode == 0
    assert cat.stdout == b"ee secret\nadded by editor\n"


def test_debug_edit_logs_decrypt_and_encrypt_file(tmp_path):
    """--debug edit logs the in-memory Decrypt and the EncryptFile write."""
    home = make_home(tmp_path)
    config = age_config(tmp_path, home)
    editor = write_script(
        tmp_path / "editor.sh", '#!/bin/sh\nprintf \'added by editor\\n\' >> "$1"\n'
    )
    (home / "ee.txt").write_text("ee secret\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "ee.txt"], cwd=home, home=home
    )
    result = run_chezmoi(
        ["--config", config, "--no-tty", "--debug", "edit", "ee.txt"],
        cwd=home,
        home=home,
        env={"EDITOR": editor},
    )
    # CATCHES: `edit` decrypts the source state in memory (msg=Decrypt
    # with both the truncated ciphertext and the full plaintext), writes
    # it to a chezmoi-encrypted temp dir for the editor, and re-encrypts
    # that temp file (msg=EncryptFile naming the temp path).
    assert result.returncode == 0
    lines = encryption_lines(result.stderr)
    assert len(lines) == 2
    assert DECRYPT_LINE_RE.fullmatch(lines[0]), lines[0]
    assert EDIT_ENCRYPT_FILE_RE.fullmatch(lines[1]), lines[1]
    cat = run_chezmoi(
        ["--config", config, "cat", "ee.txt"], cwd=home, home=home
    )
    assert cat.returncode == 0
    assert cat.stdout == b"ee secret\nadded by editor\n"


def test_debug_decrypt_to_file_error_is_logged(tmp_path):
    """A corrupt encrypted source logs an ERROR DecryptToFile record."""
    home = make_home(tmp_path)
    config = age_config(tmp_path, home)
    marker = tmp_path / "editor-ran"
    editor = write_script(
        tmp_path / "editor.sh",
        '#!/bin/sh\nprintf x > "%s"\nprintf \'added by editor\\n\' >> "$1"\n'
        % marker,
    )
    source = home / ".local/share/chezmoi/encrypted_corrupt.txt.age"
    source.write_text("this is not ciphertext\n")
    result = run_chezmoi(
        ["--config", config, "--no-tty", "--debug", "edit-encrypted",
         ".local/share/chezmoi/encrypted_corrupt.txt.age"],
        cwd=home,
        home=home,
        env={"EDITOR": editor},
    )
    # CATCHES: a source file that is not age armor fails inside
    # DecryptToFile - the ERROR record keeps the age header-parse error
    # with the offending line quoted, plus the plaintext temp path and
    # the raw input as the ciphertext attribute - and the command aborts
    # before the editor runs.
    assert result.returncode == 1
    lines = encryption_lines(result.stderr)
    assert len(lines) == 1
    assert DECRYPT_TO_FILE_ERROR_RE.fullmatch(lines[0]), lines[0]
    assert result.stderr.decode().endswith(
        'chezmoi: failed to read header: parsing age header: '
        'unexpected intro: "this is not ciphertext"\n'
    )
    assert source.read_text() == "this is not ciphertext\n"
    assert not marker.exists()


def test_debug_encrypt_file_error_is_logged(tmp_path):
    """A failing re-encrypt logs an ERROR EncryptFile record."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\nrecipient = "%s"\nidentity = "%s"\n'
        % (recipient, identity),
    )
    editor = write_script(
        tmp_path / "editor.sh", '#!/bin/sh\nprintf \'added by editor\\n\' >> "$1"\n'
    )
    (home / "ee.txt").write_text("ee secret\n")
    run_chezmoi(
        ["--config", config, "add", "--encrypt", "ee.txt"], cwd=home, home=home
    )
    identity_only = write_config(
        tmp_path,
        'encryption = "age"\n[age]\nidentity = "%s"\n' % identity,
        name="identity-only.toml",
    )
    result = run_chezmoi(
        ["--config", identity_only, "--no-tty", "--debug", "edit", "ee.txt"],
        cwd=home,
        home=home,
        env={"EDITOR": editor},
    )
    # CATCHES: with an identity-only config the decrypt succeeds (msg=
    # Decrypt at INFO) but the re-encrypt of the edited temp file fails
    # with the age error and an empty ciphertext attribute in the ERROR
    # msg=EncryptFile record.
    assert result.returncode == 1
    lines = encryption_lines(result.stderr)
    assert len(lines) == 2
    assert DECRYPT_LINE_RE.fullmatch(lines[0]), lines[0]
    assert ENCRYPT_FILE_ERROR_RE.fullmatch(lines[1]), lines[1]
    assert result.stderr.decode().endswith("chezmoi: no recipients specified\n")
