"""keepassxc template functions beyond the basic `show` flow.

Covers the builtin mode (chezmoi parses the .kdbx file itself with
gokeepasslib, prompting for the database password on stdin), attachment
handling in both cache-password and builtin mode, the interactive `open` mode
(chezmoi drives `keepassxc-cli open` through a pseudo-terminal console), and
the --skip-secrets gating of all three functions.
"""

import base64
import re

from conftest import make_home, run_chezmoi, write_config, write_script

# A KDBX 3.1 database (AES, gzip) generated once with gokeepasslib v3.7.0 and
# locked with password "db-password". Its layout:
#   Root group
#     email/  -> gmail (UserName alice@example.com, Password gmail-secret
#                [protected], Notes "line one\nline two", attachment att.txt
#                "attachment payload\n"), imap (UserName bob)
#     servers/prod/ -> dbhost (Password prod-secret)
KDBX_B64 = """
A9mimmf7S7UBAAMAAhAAMcHy5r9xQ1C+WAUhavxa/wMEAAEAAAAEIAAUHBk5v854N+yS2PFEY8Ry
A8F5cAx4vxWPmrAO5JrG3AUgAJ7jKXjjLSI2o/GMo5GmAcMK/uRl+/9BIh8nhRw5I79lBggAcBcA
AAAAAAAHEAD5/k+i5WUUpoFKP3jc3a9xCCAAbG99UHxtfsI//qGHS2P7BD16Ka6k4sMzXdx8aFCt
b8oJIABDlZXSHwvgnyZsFB2l+zYNR8DS0oxINb2EEC2iIrMTugoEAAIAAAAABAANCg0Ktrdc/h6y
w+AC+IqU50EOTdUr9pcD58qR93L0PP/qAQ90kWG6gKelz0OR+6rMbWRa080RBACBuR3OvEWcQX7M
fqo6AcVbPzQxoN/zNqKdXgTK/iNGvo04iWr24slxcCHQS9C1q4HLHA6C2Dv/TMso8tD5r7MyHgdH
Fl9NiRwLfICM+SD842s+62IGMuHFlDa6kSM+RrzMBeFIvx7f866zjkRK5L9TAheOoLlytE5o64dm
SfrJYePfO7jm6XsY8SfW4KwcocC+LxbxwTTScJPbp3CeCUJKDaUem0NERXNN42XvzSdaru/LxgzK
fntjhANuunoc8N8peOqFaLxYvGVUdRGTF9aiHOJ14zi57epnjOSo3tz1/betlavZRc8TkoCZrlJV
A22ZDC1v6sEeU3N9i4k5fHTvcSYnF6I9KlFWCEu3Elvk7NtUVAPg+4TGWOhBT5VBkh7ZzjP9CsEe
wKnTTUmLv0YVN9CDQZc9qz4Ty7joRWBWMD/yfRqjhVkXKSASzUwKUHyN2xzxwicWePZZj/pj4orK
uusemxS9kQWZ/NzmqTcnxR3u3qpUfyLwlfNNZnhEcfiJvig3AEkl9MwRappq2nFhzAZ5pbny/wLM
rFvdGiMKby18Oofi0eS3SiJD3q03Tpgon6j1GpVltLOyjZdLC9t7jgNz6Z1PIpJAnZpkOJ+Up1Hm
4QH0Jfm29ywZZpFOazWvdBKryXG4fs0eU5sFlr8xe7FqM4K032FjBG07f9FXbIMFdBz95c2A/Xia
RxFglXJlMK3C1gjomWYH/ep1aYOIxLV4a6MG9I5WtLDKOD0hdRjpiwP6UE+9y5Ir0uA8XolvesI5
S6kbUwLCaIrtikgxQcYtyUbE1dAduHPPHmfcdizozFC171qxikbCNzVmrgbtzQdn5rchHkOChU2c
eJvi8Ni2hcgBG0u6tpJodzqTvKgj+pNgCMdK4byTYXGFF7VyjdFDm2qTjFGlEOZ8yNNniM3KuYR8
qS2sPzdDbohh1fzO0ID0bkHzLQrWBd1LFwMKUH2IW3xqiKQQMd4jrd0ARlRg/hR7FBa98niVTy/X
D4TdRF4ATD5kLOOy5ZHTgAIe/am6uMRbANj5+0SicFtmy2pLWKb2nq+e3Vwr3cFDThQGvIRx3Cso
m/KWj+ZmRilqW3yRWtO2AL+xE6TlCaoVMvvM9YOg8zn8azTmCP+pc1W0JNjwA0gYbxBLxT1rqKtn
um+pX4d729SVr+bt+LZ6o4vWbaAAXH475xEU4TqHsOAsBfQEu8mHFA/tK7PP8JPGrtbpPCkFDtHi
5Jo2H+tFmbVhEmwugjdP9ix8Q1cd2nL8hRwlpWhl6By4WAQFkzOWDHzPi9+41nzNfYOMphjvGObJ
h5uyeXyQPU5Qxi4XkTB8B537JqxeoLJHczriVGKFCgjgZhplw3JW+210SkZ53Ia01bGJTd+6e8Dr
6nUQPVZ4iNes6WP5SvMaumKgvmenYTzCMBkfGjvsTmXp8NoqMBWyO1ER5dcTxL52zP4syXvK8i0R
Ln6ciBcWGCc+MypHlHBHM3vR2rwIBO0BwREgwIWAj0iyny4tR8G6G31GLj/VwsPdeJ8hjgF6rkmj
QtYyAvo3MUjdcu+X3GrWsQsAVJzbTnUZxp6fEzVPIGzvBlQ95H2nad6fDrDpd/DPkqJMv7r1e3U4
IlRCFekhJg8z3FkZnqP6uoypVNPKxTqkW1AJ+emYS16kCvEr+PDVedXzHpU3pT/tTHIU4btKHvSw
UrZgr5fof8g/dpv18ZjSDv6282qYmuGlbArrVDoudnG3VAWe02VrzG6H6ZBIw5ffXnydN/OfMHgm
KA3dU/F1TpCq4MWV1CWpBa9iU9SvCTtCEOwX5o3OsohwCGrREoIZUD/q2+X+cbB/moy+a+Rz1DW+
pjSvlBbRqSsLW+nXLXCA7bsNQ/9S25cxeTWPuN82euHWd9YZm+wEDV4DolOlXnq0bSYS2dtX9hou
9K4+Z6aiUYR5Gr+DSp9xcYdoQWmfgvGpInfLCEEuxiPyLxXAKJhCcGvJaID9Hs5ve0P/Qdb9rT0S
qdHnqu2U1BQrQPuCmvnAhqDC86GSUhAxtnnsAttRvjmyg/hMa4pnuZ6/fYfXqWh8v3zXUIc3z8o3
j92O50kwZ7Xhc9JZjbpx7QkWk8mb9KUx8kwEuZ5kcRkPgbIYl9bEUhPUpKsVUw==
"""

KDBX_PASSWORD = "db-password"


def write_kdbx(tmp_path):
    """Write the fixture database into tmp_path; return its path."""
    database = tmp_path / "test.kdbx"
    database.write_bytes(base64.b64decode(KDBX_B64))
    return database


def run_keepassxc_template(tmp_path, template, *, extra_cfg="", stdin=b"", env=None,
                           flags=(), home=None):
    """Run execute-template with a [keepassxc] config; return the result."""
    home = home if home is not None else make_home(tmp_path)
    config = write_config(tmp_path, "[keepassxc]\n" + extra_cfg)
    return run_chezmoi(
        ["--config", config, "--no-tty"] + list(flags)
        + ["execute-template", template],
        cwd=home,
        home=home,
        env=env,
        stdin=stdin,
    )


def builtin_cfg(database, prompt=True):
    return 'database = "%s"\nmode = "builtin"\nprompt = %s\n' % (
        database, "true" if prompt else "false"
    )


# Fake `keepassxc-cli` for cache-password mode: logs its arguments and writes
# $FAKE_ATT to its last argument (the temporary file chezmoi passes to
# attachment-export).
FAKE_ATTACHMENT_CLI = """#!/bin/bash
{ printf 'ARGS:'; for a in "$@"; do printf ' [%s]' "$a"; done; printf '\\n'; } >> "$FAKE_LOG"
last="${@: -1}"
printf '%s' "$FAKE_ATT" > "$last"
printf '%s' "$FAKE_OUT"
"""

# Fake `keepassxc-cli open` for prompt=false: prints the console prompt
# immediately, answers `show` lines, writes attachments for
# `attachment-export` lines, and exits on the `exit` line.
FAKE_OPEN_NO_PROMPT = """#!/bin/bash
printf 'open-argv:' >> "$FAKE_LOG"
for a in "$@"; do printf ' [%s]' "$a" >> "$FAKE_LOG"; done
printf '\\n' >> "$FAKE_LOG"
printf 'Passwords> '
while IFS= read -r line; do
  printf 'LINE:[%s]\\n' "$line" >> "$FAKE_LOG"
  case "$line" in
    show*--attributes*) printf 'attr-value\\n' ;;
    show*) printf 'Username: open-user\\nPassword: open-pass\\n' ;;
    attachment-export*) set -- $line; printf 'att-data' > "${@: -1}" ;;
    exit) exit 0 ;;
  esac
  printf 'Passwords> '
done
exit 0
"""

# Fake `keepassxc-cli open` for prompt=true: demands the database password
# first (the pseudo-terminal echoes it back) before the console prompt.
FAKE_OPEN_PROMPT = """#!/bin/bash
printf 'Enter password to unlock %s: ' "$2"
read -r pw
printf 'Passwords> '
while IFS= read -r line; do
  case "$line" in
    show*) printf 'Username: open-user\\nPassword: open-pass\\n' ;;
    exit) exit 0 ;;
  esac
  printf 'Passwords> '
done
exit 0
"""


def normalize_keepassxc_temps(text):
    """Replace chezmoi's random keepassxc temp paths with placeholders."""
    return re.sub(
        r"chezmoi-keepassxc\d+/attachment-\d+", "chezmoi-keepassxc-N/attachment-N",
        text,
    )


def test_keepassxc_builtin_fields(tmp_path):
    """builtin mode reads entries straight out of the .kdbx file."""
    database = write_kdbx(tmp_path)
    result = run_keepassxc_template(
        tmp_path,
        'u = {{ (keepassxc "email/gmail").UserName }} '
        'p = {{ (keepassxc "email/gmail").Password }} '
        'n = {{ (keepassxc "email/gmail").Notes }}',
        extra_cfg=builtin_cfg(database),
        stdin=b"db-password\n",
    )
    # CATCHES: builtin mode prompts for the database password on stdout,
    # reads it from stdin, unlocks protected values (the Password field is
    # stored Salsa20-protected in the file) and returns multiline notes
    # verbatim.
    assert result.returncode == 0
    assert result.stdout == (
        "Enter password to unlock %s: u = alice@example.com p = gmail-secret "
        "n = line one\nline two" % database
    ).encode()
    assert result.stderr == b""


def test_keepassxc_builtin_nested_group(tmp_path):
    """builtin mode addresses entries by group/subgroup/entry path."""
    database = write_kdbx(tmp_path)
    result = run_keepassxc_template(
        tmp_path,
        'nested = {{ (keepassxc "servers/prod/dbhost").Password }}',
        extra_cfg=builtin_cfg(database),
        stdin=b"db-password\n",
    )
    # CATCHES: entries in nested groups are addressed by the full
    # group/subgroup/entry path, not just the entry title.
    assert result.returncode == 0
    assert result.stdout == (
        "Enter password to unlock %s: nested = prod-secret" % database
    ).encode()
    assert result.stderr == b""


def test_keepassxc_builtin_attribute(tmp_path):
    """keepassxcAttribute works standalone and reuses a decoded entry."""
    database = write_kdbx(tmp_path)

    fresh = run_keepassxc_template(
        tmp_path,
        'attr = {{ keepassxcAttribute "email/gmail" "UserName" }}',
        extra_cfg=builtin_cfg(database),
        stdin=b"db-password\n",
    )
    # CATCHES: keepassxcAttribute does not require a keepassxc call first -
    # it decodes the entry itself and returns the raw field value.
    assert fresh.returncode == 0
    assert fresh.stdout == (
        "Enter password to unlock %s: attr = alice@example.com" % database
    ).encode()

    cached = run_keepassxc_template(
        tmp_path,
        'u = {{ (keepassxc "email/imap").UserName }} '
        'a = {{ keepassxcAttribute "email/imap" "UserName" }}',
        extra_cfg=builtin_cfg(database),
        stdin=b"db-password\n",
    )
    # CATCHES: after keepassxc has decoded an entry, keepassxcAttribute
    # returns the same value from the cache (a single password prompt for
    # both calls).
    assert cached.returncode == 0
    assert cached.stdout == (
        "Enter password to unlock %s: u = bob a = bob" % database
    ).encode()

    missing = run_keepassxc_template(
        tmp_path,
        'm = [{{ keepassxcAttribute "email/gmail" "Nope" }}]',
        extra_cfg=builtin_cfg(database),
        stdin=b"db-password\n",
    )
    # CATCHES: a missing attribute is not an error in builtin mode - the
    # empty string is returned.
    assert missing.returncode == 0
    assert missing.stdout == (
        "Enter password to unlock %s: m = []" % database
    ).encode()


def test_keepassxc_builtin_attachment(tmp_path):
    """keepassxcAttachment returns the binary, but panics when called first."""
    database = write_kdbx(tmp_path)

    after_keepassxc = run_keepassxc_template(
        tmp_path,
        'u = {{ (keepassxc "email/gmail").UserName }} '
        'a = {{ keepassxcAttachment "email/gmail" "att.txt" }}',
        extra_cfg=builtin_cfg(database),
        stdin=b"db-password\n",
    )
    # CATCHES: the attachment binary is decoded from the database and
    # returned byte-for-byte (including its trailing newline), but only
    # because the preceding keepassxc call initialized the entry cache.
    assert after_keepassxc.returncode == 0
    assert after_keepassxc.stdout == (
        "Enter password to unlock %s: u = alice@example.com "
        "a = attachment payload\n" % database
    ).encode()

    alone = run_keepassxc_template(
        tmp_path,
        'a = {{ keepassxcAttachment "email/gmail" "att.txt" }}',
        extra_cfg=builtin_cfg(database),
        stdin=b"db-password\n",
    )
    # CATCHES: calling keepassxcAttachment as the first builtin-mode function
    # fails before decoding anything because the entry cache was never
    # initialized ("assignment to entry in nil map").
    assert alone.returncode == 1
    assert alone.stdout == (
        "Enter password to unlock %s: " % database
    ).encode()
    assert alone.stderr == (
        'chezmoi: template: arg1:1:7: executing "arg1" at '
        '<keepassxcAttachment "email/gmail" "att.txt">: '
        "error calling keepassxcAttachment: assignment to entry in nil map\n"
    ).encode()


def test_keepassxc_builtin_wrong_password(tmp_path):
    """a wrong database password fails the integrity check."""
    database = write_kdbx(tmp_path)
    result = run_keepassxc_template(
        tmp_path,
        '{{ (keepassxc "email/gmail").UserName }}',
        extra_cfg=builtin_cfg(database),
        stdin=b"wrong-password\n",
    )
    # CATCHES: the builtin decoder recognizes a bad password by the
    # StreamStartBytes integrity check and reports the gokeepasslib error
    # text verbatim.
    assert result.returncode == 1
    assert result.stdout == (
        "Enter password to unlock %s: " % database
    ).encode()
    assert result.stderr == (
        'chezmoi: template: arg1:1:4: executing "arg1" at '
        '<keepassxc "email/gmail">: error calling keepassxc: '
        "Wrong password? Database integrity check failed\n"
    ).encode()


def test_keepassxc_builtin_prompt_disabled(tmp_path):
    """without prompt the empty password is used and decryption fails."""
    database = write_kdbx(tmp_path)
    result = run_keepassxc_template(
        tmp_path,
        '{{ (keepassxc "email/gmail").UserName }}',
        extra_cfg=builtin_cfg(database, prompt=False),
    )
    # CATCHES: prompt = false silently uses an empty password (there is no
    # other way to supply one), so decoding fails the integrity check, and
    # no prompt is printed.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        'chezmoi: template: arg1:1:4: executing "arg1" at '
        '<keepassxc "email/gmail">: error calling keepassxc: '
        "Wrong password? Database integrity check failed\n"
    ).encode()


def test_keepassxc_builtin_bad_database(tmp_path):
    """a missing or corrupt database file fails with distinct errors."""
    missing = run_keepassxc_template(
        tmp_path,
        '{{ (keepassxc "e/x").UserName }}',
        extra_cfg=builtin_cfg(tmp_path / "nope.kdbx"),
        stdin=b"db-password\n",
    )
    # CATCHES: the database file is opened before the password is requested,
    # so a missing file is an open error and no prompt appears.
    assert missing.returncode == 1
    assert missing.stdout == b""
    assert missing.stderr == (
        'chezmoi: template: arg1:1:4: executing "arg1" at <keepassxc "e/x">: '
        "error calling keepassxc: open %s: no such file or directory\n"
        % (tmp_path / "nope.kdbx")
    ).encode()

    garbage = tmp_path / "garbage.kdbx"
    garbage.write_bytes(b"this is not a kdbx file at all\n")
    corrupt = run_keepassxc_template(
        tmp_path,
        '{{ (keepassxc "e/x").UserName }}',
        extra_cfg=builtin_cfg(garbage),
        stdin=b"db-password\n",
    )
    # CATCHES: a file that is not a KDBX database still prompts for the
    # password first and then fails while parsing the header.
    assert corrupt.returncode == 1
    assert corrupt.stdout == (
        "Enter password to unlock %s: " % garbage
    ).encode()
    assert corrupt.stderr == (
        'chezmoi: template: arg1:1:4: executing "arg1" at <keepassxc "e/x">: '
        "error calling keepassxc: unexpected EOF\n"
    ).encode()


def test_keepassxc_attachment_cache_password_mode(tmp_path):
    """cache-password mode exports attachments through a temp file."""
    database = tmp_path / "db.kdbx"
    database.write_bytes(b"kdbx\n")
    fake = write_script(tmp_path / "fake-keepassxc", FAKE_ATTACHMENT_CLI)
    log = tmp_path / "log.txt"
    result = run_keepassxc_template(
        tmp_path,
        'a1 = {{ keepassxcAttachment "entry1" "att.txt" }} '
        'a2 = {{ keepassxcAttachment "entry1" "att.txt" }}',
        extra_cfg='command = "%s"\ndatabase = "%s"\nmode = "cache-password"\n'
        'prompt = false\nargs = ["--global"]\n' % (fake, database),
        env={"FAKE_LOG": log, "FAKE_OUT": "show-output", "FAKE_ATT": "attachment-data"},
    )
    # CATCHES: the attachment is fetched with `attachment-export --quiet
    # <entry> <name> <tempfile>` (after the config args and the database),
    # its file contents are returned unmodified, and - unlike the entry
    # cache - attachments are NOT cached: the same call runs the command
    # twice, each time into a fresh temporary file.
    assert result.returncode == 0
    assert result.stdout == b"a1 = attachment-data a2 = attachment-data"
    assert result.stderr == b""
    assert [
        normalize_keepassxc_temps(line) for line in log.read_text().splitlines()
    ] == [
        "ARGS: [attachment-export] [--global] [%s] [--quiet] [entry1] [att.txt] "
        "[/tmp/chezmoi-keepassxc-N/attachment-N]" % database,
        "ARGS: [attachment-export] [--global] [%s] [--quiet] [entry1] [att.txt] "
        "[/tmp/chezmoi-keepassxc-N/attachment-N]" % database,
    ]


def test_keepassxc_open_mode_attribute_and_attachment(tmp_path):
    """open mode sends commands to one interactive keepassxc-cli console."""
    database = tmp_path / "db.kdbx"
    database.write_bytes(b"kdbx\n")
    fake = write_script(tmp_path / "fake-open", FAKE_OPEN_NO_PROMPT)
    log = tmp_path / "log.txt"
    result = run_keepassxc_template(
        tmp_path,
        'a = {{ keepassxcAttribute "e1" "Notes" }} '
        'b = {{ keepassxcAttachment "e2" "att.txt" }}',
        extra_cfg='command = "%s"\ndatabase = "%s"\nmode = "open"\n'
        "prompt = false\n" % (fake, database),
        env={"FAKE_LOG": log},
    )
    # CATCHES: open mode starts `keepassxc-cli open <database>` once on a
    # pseudo-terminal and reuses it for every function: attribute lookups
    # send `show <entry> --attributes <attr> --quiet --show-protected`,
    # attachments send `attachment-export --quiet <entry> <name> <tempfile>`
    # and read the data back from the temp file, and the session is closed
    # with an `exit` line afterwards.
    assert result.returncode == 0
    assert result.stdout == b"a = attr-value b = att-data"
    assert result.stderr == b""
    assert [
        normalize_keepassxc_temps(line) for line in log.read_text().splitlines()
    ] == [
        "open-argv: [open] [%s]" % database,
        "LINE:[show e1 --attributes Notes --quiet --show-protected]",
        "LINE:[attachment-export --quiet e2 att.txt "
        "/tmp/chezmoi-keepassxc-N/attachment-N]",
        "LINE:[exit]",
    ]


def test_keepassxc_open_mode_prompt(tmp_path):
    """open mode unlocks the database through the console password prompt."""
    database = tmp_path / "db.kdbx"
    database.write_bytes(b"kdbx\n")
    fake = write_script(tmp_path / "fake-open", FAKE_OPEN_PROMPT)
    result = run_keepassxc_template(
        tmp_path,
        'u = {{ (keepassxc "entry1").Username }}',
        extra_cfg='command = "%s"\ndatabase = "%s"\nmode = "open"\n'
        "prompt = true\n" % (fake, database),
        stdin=b"the-password\n",
    )
    # CATCHES: with prompt = true chezmoi waits for the tool's
    # "Enter password to unlock ...: " line, re-prints it on its own stdout,
    # reads the password from stdin and sends it to the console before the
    # first command.
    assert result.returncode == 0
    assert result.stdout == (
        "Enter password to unlock %s: u = open-user\nPassword: open-pass"
        % database
    ).encode()
    assert result.stderr == b""


def test_keepassxc_open_mode_map_parsing_and_cache(tmp_path):
    """open mode output parsing and per-entry caching."""
    database = tmp_path / "db.kdbx"
    database.write_bytes(b"kdbx\n")
    fake = write_script(tmp_path / "fake-open", FAKE_OPEN_NO_PROMPT)
    log = tmp_path / "log.txt"
    result = run_keepassxc_template(
        tmp_path,
        'u1 = {{ (keepassxc "e1").Username }} u2 = {{ (keepassxc "e1").Username }}',
        extra_cfg='command = "%s"\ndatabase = "%s"\nmode = "open"\n'
        "prompt = false\n" % (fake, database),
        env={"FAKE_LOG": log},
    )
    # CATCHES: the echoed command line and the trailing prompt are trimmed
    # from the console output, so the final "Password: open-pass" line loses
    # its newline and is appended to the previous key's value; the entry is
    # cached, so two lookups send only a single `show` command.
    assert result.returncode == 0
    assert result.stdout == (
        b"u1 = open-user\nPassword: open-pass u2 = open-user\nPassword: open-pass"
    )
    assert result.stderr == b""
    assert [line for line in log.read_text().splitlines()][1:] == [
        "LINE:[show --quiet --show-protected e1]",
        "LINE:[exit]",
    ]


def test_keepassxc_open_mode_single_line_response(tmp_path):
    """a one-line response yields an empty map in open mode."""
    database = tmp_path / "db.kdbx"
    database.write_bytes(b"kdbx\n")
    single = write_script(
        tmp_path / "fake-open",
        "#!/bin/bash\n"
        "printf 'Passwords> '\n"
        "while IFS= read -r line; do\n"
        "  case \"$line\" in\n"
        "    show*) printf 'Username: solo\\n' ;;\n"
        "    exit) exit 0 ;;\n"
        "  esac\n"
        "  printf 'Passwords> '\n"
        "done\n"
        "exit 0\n",
    )
    result = run_keepassxc_template(
        tmp_path,
        'u = {{ (keepassxc "e1").Username }}',
        extra_cfg='command = "%s"\ndatabase = "%s"\nmode = "open"\n'
        "prompt = false\n" % (single, database),
    )
    # CATCHES: after trimming the echoed command and the prompt, a
    # single-line response has no trailing newline, so it is not parsed as a
    # key/value pair and the entry map is empty.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        'chezmoi: template: arg1:1:18: executing "arg1" at <"e1">: '
        'map has no entry for key "Username"\n'
    ).encode()


def test_keepassxc_skip_secrets(tmp_path):
    """--skip-secrets gates all three keepassxc functions."""
    database = write_kdbx(tmp_path)
    entry = run_keepassxc_template(
        tmp_path,
        '{{ keepassxc "e" }}',
        extra_cfg=builtin_cfg(database),
        flags=["--skip-secrets"],
    )
    # CATCHES: the entry function is skipped before the database is even
    # opened (no password prompt is printed).
    assert entry.returncode == 1
    assert entry.stdout == b""
    assert entry.stderr == (
        'chezmoi: template: arg1:1:3: executing "arg1" at <keepassxc "e">: '
        "error calling keepassxc: skip template\n"
    ).encode()

    attachment = run_keepassxc_template(
        tmp_path,
        '{{ keepassxcAttachment "e" "n" }}',
        extra_cfg=builtin_cfg(database),
        flags=["--skip-secrets"],
    )
    # CATCHES: keepassxcAttachment is gated by the same flag with the
    # function name in the error.
    assert attachment.returncode == 1
    assert attachment.stderr == (
        'chezmoi: template: arg1:1:3: executing "arg1" at '
        '<keepassxcAttachment "e" "n">: '
        "error calling keepassxcAttachment: skip template\n"
    ).encode()

    attribute = run_keepassxc_template(
        tmp_path,
        '{{ keepassxcAttribute "e" "n" }}',
        extra_cfg=builtin_cfg(database),
        flags=["--skip-secrets"],
    )
    # CATCHES: keepassxcAttribute is gated by the same flag with the
    # function name in the error.
    assert attribute.returncode == 1
    assert attribute.stderr == (
        'chezmoi: template: arg1:1:3: executing "arg1" at '
        '<keepassxcAttribute "e" "n">: '
        "error calling keepassxcAttribute: skip template\n"
    ).encode()
