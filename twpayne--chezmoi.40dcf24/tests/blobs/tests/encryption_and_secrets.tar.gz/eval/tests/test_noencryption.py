"""The unconfigured-encryption backend (NoEncryption).

When no encryption is configured, every operation that needs a backend fails
with "encryption not configured": edit-encrypted, edit of an encrypted source
file, cat/apply of an encrypted target, add --encrypt, chattr +encrypted, and
merge of an encrypted source file. The encrypted_ attribute itself still works
(with an empty suffix), so target-path resolves encrypted_secret.txt to
secret.txt.
"""

from conftest import make_home, run_chezmoi, write_config


def _encrypted_source_home(tmp_path):
    """Create a HOME whose source state holds encrypted_secret.txt."""
    home = make_home(tmp_path)
    (home / ".local" / "share" / "chezmoi" / "encrypted_secret.txt").write_bytes(
        b"ciphertext-bytes\n"
    )
    return home


def test_edit_encrypted_without_config(tmp_path):
    """edit-encrypted fails before running the editor when no backend is set."""
    home = make_home(tmp_path)
    (home / "cipher.txt").write_bytes(b"ciphertext-bytes\n")
    config = write_config(tmp_path, "")
    result = run_chezmoi(
        ["--config", config, "--no-tty", "edit-encrypted", "cipher.txt"],
        cwd=home,
        home=home,
        env={"EDITOR": "/bin/true"},
    )
    # CATCHES: edit-encrypted decrypts the named file to a temp directory
    # first; with no backend configured that decrypt fails immediately with
    # "encryption not configured" and the editor is never launched.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: encryption not configured\n"
    # the ciphertext is left untouched
    assert (home / "cipher.txt").read_bytes() == b"ciphertext-bytes\n"


def test_edit_encrypted_missing_file_under_home(tmp_path):
    """edit-encrypted reports a missing file with its home-relative path."""
    home = make_home(tmp_path)
    config = write_config(tmp_path, "")
    result = run_chezmoi(
        ["--config", config, "--no-tty", "edit-encrypted", "missing.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: the argument is resolved relative to the working directory
    # (not the source directory) and a missing file is an open error naming
    # the absolute path under HOME.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        "chezmoi: open %s: no such file or directory\n" % (home / "missing.txt")
    ).encode()


def test_edit_encrypted_source_file_without_config(tmp_path):
    """edit of a file with an encrypted source fails with no backend."""
    home = _encrypted_source_home(tmp_path)
    config = write_config(tmp_path, "")
    result = run_chezmoi(
        ["--config", config, "--no-tty", "edit", "secret.txt"],
        cwd=home,
        home=home,
        env={"EDITOR": "/bin/true"},
    )
    # CATCHES: edit needs the decrypted plaintext of the encrypted_ source
    # file before it can start the editor, and fails with the shared
    # "encryption not configured" error.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: encryption not configured\n"


def test_cat_encrypted_source_without_config(tmp_path):
    """cat of an encrypted target names the target in the error."""
    home = _encrypted_source_home(tmp_path)
    config = write_config(tmp_path, "")
    result = run_chezmoi(
        ["--config", config, "--no-tty", "cat", "secret.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: unlike the bare command errors, cat prefixes the failure with
    # the target path being decrypted.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: secret.txt: encryption not configured\n"


def test_add_encrypt_without_config(tmp_path):
    """add --encrypt refuses to store a file without a backend."""
    home = make_home(tmp_path)
    (home / "file.txt").write_bytes(b"data\n")
    config = write_config(tmp_path, "")
    result = run_chezmoi(
        ["--config", config, "--no-tty", "add", "--encrypt", "file.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: add --encrypt needs to encrypt the file contents before
    # writing encrypted_file.txt to the source state and fails with the
    # shared error.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: encryption not configured\n"
    assert not (home / ".local/share/chezmoi/encrypted_file.txt").exists()


def test_chattr_add_encrypted_without_config(tmp_path):
    """chattr +encrypted fails and leaves the plain source file in place."""
    home = make_home(tmp_path)
    (home / ".local" / "share" / "chezmoi" / "plain.txt").write_bytes(b"plain-bytes\n")
    config = write_config(tmp_path, "")
    result = run_chezmoi(
        ["--config", config, "--no-tty", "chattr", "+encrypted", "plain.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: setting the encrypted attribute requires re-encrypting the
    # file contents; the error is raised before anything is renamed or
    # written, so the plain source file survives unchanged.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: encryption not configured\n"
    source_dir = home / ".local/share/chezmoi"
    assert [p.name for p in source_dir.iterdir()] == ["plain.txt"]
    assert (source_dir / "plain.txt").read_bytes() == b"plain-bytes\n"


def test_merge_encrypted_source_without_config(tmp_path):
    """merge of an encrypted source fails after the merge tool runs."""
    home = _encrypted_source_home(tmp_path)
    config = write_config(tmp_path, '[merge]\ncommand = "/bin/true"\n')
    result = run_chezmoi(
        ["--config", config, "--no-tty", "merge", "secret.txt"],
        cwd=home,
        home=home,
    )
    # CATCHES: merge decrypts the encrypted source entry to merge it; with
    # no backend the operation fails with the shared error even though the
    # configured merge command itself succeeds.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: encryption not configured\n"


def test_target_path_of_encrypted_source_without_config(tmp_path):
    """target-path strips the encrypted_ prefix with an empty suffix."""
    home = _encrypted_source_home(tmp_path)
    config = write_config(tmp_path, "")
    result = run_chezmoi(
        [
            "--config", config, "--no-tty", "target-path",
            ".local/share/chezmoi/encrypted_secret.txt",
        ],
        cwd=home,
        home=home,
    )
    # CATCHES: with no backend the encrypted suffix is the empty string, so
    # the source name encrypted_secret.txt maps to the target secret.txt
    # (prefix stripped, nothing appended) and the absolute target path is
    # printed.
    assert result.returncode == 0
    assert result.stdout == ("%s/secret.txt\n" % home).encode()
    assert result.stderr == b""
