"""Password manager template functions with interactive/unlock flows.

Covers bitwarden (session passthrough, unlock=auto/true flows, attachments),
bitwardenSecrets, onepassword (account/connect modes, prompt-based signin,
read/document), doppler (project/config overrides, caching), passhole and
keepassxc (password prompts on stdin), and protonPass (JSON and attachment
downloads via a temp output file).

Every test drives the standard fake command, which records its argv, its
BW_SESSION environment, and the stdin it received.
"""

import re

from conftest import TemplateRunner, make_home


def runner(tmp_path):
    return TemplateRunner(tmp_path, make_home(tmp_path))


def test_bitwarden_template_funcs(tmp_path):
    """bitwarden and bitwardenFields parse the `bw get item` JSON."""
    r = runner(tmp_path)
    result = r.run(
        "bitwarden",
        'p = {{ (bitwarden "item").password }} '
        'u = {{ (bitwardenFields "item").user.value }}',
        fake_out='{"password":"bw-pw","fields":[{"name":"user","value":"bw-user"}]}',
    )
    # CATCHES: a single `bw get item <item>` invocation backs both the item
    # accessors and the name-indexed custom fields map.
    assert result.returncode == 0
    assert result.stdout == b"p = bw-pw u = bw-user"
    assert result.stderr == b""
    assert r.log_lines() == ["ARGS: [get] [item]"]


def test_bitwarden_session_passthrough(tmp_path):
    """An existing BW_SESSION is forwarded to the bitwarden command."""
    r = runner(tmp_path)
    result = r.run(
        "bitwarden",
        'p = {{ (bitwarden "item").password }}',
        fake_out='{"password":"bw-pw2"}',
        env={"BW_SESSION": "existing-session"},
    )
    # CATCHES: BW_SESSION is passed through unchanged and no unlock/lock
    # cycle happens while a session is already set.
    assert result.returncode == 0
    assert result.stdout == b"p = bw-pw2"
    assert r.log_lines() == ["ARGS: [get] [item] BW_SESSION=existing-session"]


def test_bitwarden_unlock_auto(tmp_path):
    """unlock = "auto" unlocks only when BW_SESSION is unset."""
    r = runner(tmp_path)
    fake_out = '{"password":"bw-pw3","id":"item-123"}'
    result = r.run(
        "bitwarden",
        'p = {{ (bitwarden "item").password }}',
        fake_out=fake_out,
        extra_cfg='unlock = "auto"',
    )
    # CATCHES: `bw unlock --raw` runs first, its output becomes BW_SESSION
    # for the item fetch, and the vault is locked again afterwards with the
    # same session value.
    assert result.returncode == 0
    assert result.stdout == b"p = bw-pw3"
    assert r.log_lines() == [
        "ARGS: [unlock] [--raw]",
        "ARGS: [get] [item] BW_SESSION=%s" % fake_out,
        "ARGS: [lock] BW_SESSION=%s" % fake_out,
    ]


def test_bitwarden_unlock_true_even_with_session(tmp_path):
    """unlock = true re-unlocks even when BW_SESSION is already set."""
    r = runner(tmp_path)
    fake_out = '{"password":"bw-pw4","id":"item-9"}'
    result = r.run(
        "bitwarden",
        'p = {{ (bitwarden "item").password }}',
        fake_out=fake_out,
        extra_cfg="unlock = true",
        env={"BW_SESSION": "already"},
    )
    # CATCHES: the boolean unlock forces the unlock/lock cycle regardless
    # of an existing session, and the fetch uses the NEW session token.
    assert result.returncode == 0
    assert result.stdout == b"p = bw-pw4"
    assert r.log_lines() == [
        "ARGS: [unlock] [--raw] BW_SESSION=already",
        "ARGS: [get] [item] BW_SESSION=%s" % fake_out,
        "ARGS: [lock] BW_SESSION=%s" % fake_out,
    ]


def test_bitwarden_attachment_funcs(tmp_path):
    """Attachment downloads use --raw; ByRef resolves the item id first."""
    r = runner(tmp_path)
    direct = r.run(
        "bitwarden",
        'a = {{ bitwardenAttachment "file.txt" "item-123" }}|',
        fake_out="att-data",
    )
    assert direct.returncode == 0
    assert direct.stdout == b"a = att-data|"
    assert r.log_lines() == [
        "ARGS: [get] [attachment] [file.txt] [--itemid] [item-123] [--raw]"
    ]

    r.log.unlink()
    by_ref = r.run(
        "bitwarden",
        'a = {{ bitwardenAttachmentByRef "file.txt" "item" }}|',
        fake_out='{"id":"item-777"}',
    )
    # CATCHES: ByRef first fetches the item to learn its id, then downloads
    # the attachment against that resolved id.
    assert by_ref.returncode == 0
    assert by_ref.stdout == b'a = {"id":"item-777"}|'
    assert r.log_lines() == [
        "ARGS: [get] [item]",
        "ARGS: [get] [attachment] [file.txt] [--itemid] [item-777] [--raw]",
    ]


def test_bitwarden_secrets_template_func(tmp_path):
    """bitwardenSecrets accepts an optional access token argument."""
    r = runner(tmp_path)
    plain = r.run(
        "bitwardenSecrets",
        'v = {{ (bitwardenSecrets "secret-id").value }}',
        fake_out='{"value":"bws-value"}',
    )
    assert plain.returncode == 0
    assert plain.stdout == b"v = bws-value"
    assert r.log_lines() == ["ARGS: [secret] [get] [secret-id]"]

    r.log.unlink()
    with_token = r.run(
        "bitwardenSecrets",
        'v = {{ (bitwardenSecrets "secret-id" "tok123").value }}',
        fake_out='{"value":"bws-value2"}',
    )
    # CATCHES: the second argument becomes `--access-token <token>` after
    # the secret id, for service-account authentication.
    assert with_token.returncode == 0
    assert with_token.stdout == b"v = bws-value2"
    assert r.log_lines() == [
        "ARGS: [secret] [get] [secret-id] [--access-token] [tok123]"
    ]


def test_onepassword_template_funcs(tmp_path):
    """DetailsFields matches by field id; ItemFields by label; item is raw."""
    r = runner(tmp_path)
    result = r.run(
        "onepassword",
        'u = {{ (onepasswordDetailsFields "item").username.value }} '
        'p = {{ (onepasswordItemFields "item").Password.value }} '
        'f = {{ (onepassword "item").fields }}',
        fake_out='{"fields":[{"id":"username","value":"op-user"},'
        '{"label":"Password","value":"op-pw","section":{"id":"s1"}}]}',
        extra_cfg="prompt = false",
    )
    # CATCHES: all three functions run one `op item get --format json` call;
    # onepasswordDetailsFields indexes by field id while onepasswordItemFields
    # indexes by label, and the section maps survive into the raw item.
    assert result.returncode == 0
    assert result.stdout == (
        b"u = op-user p = op-pw f = [map[id:username value:op-user] "
        b"map[label:Password section:map[id:s1] value:op-pw]]"
    )
    assert result.stderr == b""
    assert r.log_lines() == ["ARGS: [item] [get] [--format] [json] [item]"]


def test_onepassword_vault_argument(tmp_path):
    """A second onepassword argument adds --vault to the item fetch."""
    r = runner(tmp_path)
    result = r.run(
        "onepassword",
        '{{ (onepassword "item" "vault1").fields }}',
        fake_out='{"fields":[]}',
        extra_cfg="prompt = false",
    )
    # CATCHES: the optional vault argument is appended as `--vault <vault>`
    # after the item name, and an empty fields list renders as [].
    assert result.returncode == 0
    assert result.stdout == b"[]"
    assert r.log_lines() == [
        "ARGS: [item] [get] [--format] [json] [item] [--vault] [vault1]"
    ]


def test_onepassword_read_and_document(tmp_path):
    """onepasswordRead and onepasswordDocument have their own op verbs."""
    r = runner(tmp_path)
    read = r.run(
        "onepassword",
        'r = {{ onepasswordRead "op://Vault/Item/Field" }}',
        fake_out="op-read-value",
        extra_cfg="prompt = false",
    )
    assert read.returncode == 0
    assert read.stdout == b"r = op-read-value"
    assert r.log_lines() == ["ARGS: [read] [--no-newline] [op://Vault/Item/Field]"]

    r.log.unlink()
    document = r.run(
        "onepassword",
        'd = {{ onepasswordDocument "doc" }}',
        fake_out="doc-contents",
        extra_cfg="prompt = false",
    )
    # CATCHES: read uses `op read --no-newline <uri>` and document uses
    # `op document get <name>`.
    assert document.returncode == 0
    assert document.stdout == b"d = doc-contents"
    assert r.log_lines() == ["ARGS: [document] [get] [doc]"]


def test_onepassword_prompt_signs_in_first(tmp_path):
    """With the default prompt setting, `op signin --raw` runs before the item."""
    r = runner(tmp_path)
    fake_out = '{"fields":[{"id":"username","value":"op2"}]}'
    result = r.run(
        "onepassword",
        'u = {{ (onepassword "item").fields }}',
        fake_out=fake_out,
    )
    # CATCHES: the signin output (here the fake's stdout) becomes the
    # `--session` value for the subsequent item fetch.
    assert result.returncode == 0
    assert result.stdout == b"u = [map[id:username value:op2]]"
    assert r.log_lines() == [
        "ARGS: [signin] [--raw]",
        "ARGS: [--session] [%s] [item] [get] [--format] [json] [item]"
        % fake_out,
    ]


def test_onepassword_mode_conflicts(tmp_path):
    """Service account and connect modes refuse to run without their env."""
    r = runner(tmp_path)
    service_account = r.run(
        "onepassword",
        '{{ (onepassword "item").fields }}',
        extra_cfg="prompt = false",
        env={"OP_SERVICE_ACCOUNT_TOKEN": "tok"},
    )
    # CATCHES: the account mode is incompatible with OP_SERVICE_ACCOUNT_TOKEN
    # being set, and the error names both sides of the conflict.
    assert service_account.returncode == 1
    assert service_account.stdout == b""
    assert service_account.stderr.decode().endswith(
        'chezmoi: template: arg1:1:4: executing "arg1" at <onepassword "item">: '
        "error calling onepassword: onepassword.mode is account, "
        "but OP_SERVICE_ACCOUNT_TOKEN is set\n"
    )

    connect = r.run(
        "onepassword",
        '{{ (onepassword "item").fields }}',
        extra_cfg='mode = "connect"',
    )
    # CATCHES: connect mode requires OP_CONNECT_HOST; without it the call
    # fails before contacting any server.
    assert connect.returncode == 1
    assert connect.stderr.decode().endswith(
        'chezmoi: template: arg1:1:4: executing "arg1" at <onepassword "item">: '
        "error calling onepassword: onepassword.mode is connect, "
        "but OP_CONNECT_HOST is not set\n"
    )


def test_doppler_template_funcs(tmp_path):
    """doppler args override the configured project and config."""
    r = runner(tmp_path)
    plain = r.run(
        "doppler",
        'v = {{ doppler "API_KEY" }}',
        fake_out='{"API_KEY":"doppler-value"}',
    )
    assert plain.returncode == 0
    assert plain.stdout == b"v = doppler-value"
    assert r.log_lines() == ["ARGS: [secrets] [download] [--json] [--no-file]"]

    r.log.unlink()
    configured = r.run(
        "doppler",
        'v = {{ (dopplerProjectJson).API_KEY }}',
        fake_out='{"API_KEY":"dpj-value"}',
        extra_cfg='project = "proj"\nconfig = "cfg"',
    )
    assert configured.returncode == 0
    assert configured.stdout == b"v = dpj-value"
    assert r.log_lines() == [
        "ARGS: [secrets] [download] [--json] [--no-file] "
        "[--project] [proj] [--config] [cfg]"
    ]

    r.log.unlink()
    overridden = r.run(
        "doppler",
        'v = {{ doppler "K" "proj2" "cfg2" }}',
        fake_out='{"K":"v2"}',
        extra_cfg='project = "proj"\nconfig = "cfg"',
    )
    # CATCHES: template arguments replace the config values: one
    # `secrets download --json --no-file` invocation with --project/--config
    # flags, taken from the template when given.
    assert overridden.returncode == 0
    assert overridden.stdout == b"v = v2"
    assert r.log_lines() == [
        "ARGS: [secrets] [download] [--json] [--no-file] "
        "[--project] [proj2] [--config] [cfg2]"
    ]


def test_doppler_caches_output(tmp_path):
    """Two doppler lookups in one template run the command only once."""
    r = runner(tmp_path)
    result = r.run(
        "doppler",
        'a = {{ doppler "A" }} b = {{ doppler "B" }}',
        fake_out='{"A":"1","B":"2"}',
    )
    # CATCHES: the whole secret set is downloaded once and both keys are
    # served from the cached JSON.
    assert result.returncode == 0
    assert result.stdout == b"a = 1 b = 2"
    assert r.log_lines() == ["ARGS: [secrets] [download] [--json] [--no-file]"]


def test_doppler_missing_key_error(tmp_path):
    """A key absent from the doppler response is an explicit error."""
    r = runner(tmp_path)
    result = r.run(
        "doppler",
        'v = {{ doppler "NOPE" }}',
        fake_out='{"OTHER":"x"}',
    )
    # CATCHES: the error names the missing key.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'chezmoi: template: arg1:1:7: executing "arg1" at <doppler "NOPE">: '
        b"error calling doppler: could not find requested secret: NOPE\n"
    )


def test_passhole_template_func(tmp_path):
    """passhole prompts on stdout and feeds the password to the command."""
    r = runner(tmp_path)
    result = r.run(
        "passhole",
        'v = {{ passhole "Entry/Path" "password" }}',
        fake_out="ph-secret-value",
        stdin=b"db-password\n",
    )
    # CATCHES: the database password is read from stdin after an "Enter
    # database password:" prompt on stdout, and passed to the command via
    # `--password -` before the show arguments.
    assert result.returncode == 0
    assert result.stdout == b"Enter database password: v = ph-secret-value"
    assert result.stderr == b""
    assert r.stdin_text() == "db-password\n"
    assert r.log_lines() == [
        "ARGS: [--password] [-] [show] [--field] [password] [Entry/Path]"
    ]


def test_passhole_prompt_false(tmp_path):
    """prompt = false drops the --password - stdin plumbing."""
    r = runner(tmp_path)
    result = r.run(
        "passhole",
        'v = {{ passhole "Entry" "user" }}',
        fake_out="ph2",
        extra_cfg='prompt = false\nargs = ["--globalarg"]',
    )
    # CATCHES: without the prompt there is no --password flag, no stdin
    # forwarding, and no prompt text on stdout; config args come first.
    assert result.returncode == 0
    assert result.stdout == b"v = ph2"
    assert result.stderr == b""
    assert r.log_lines() == [
        "ARGS: [--globalarg] [show] [--field] [user] [Entry]"
    ]


def test_keepassxc_template_funcs(tmp_path):
    """keepassxc prompts per database and parses key/value output."""
    r = runner(tmp_path)
    database = tmp_path / "db.kdbx"
    fake_out = "Username: kx-user\nPassword: kx-pw\nNotes: line one\n line two\n"
    result = r.run(
        "keepassxc",
        'u = {{ (keepassxc "entry1").Username }} '
        'p = {{ (keepassxc "entry1").Password }} '
        'n = {{ (keepassxc "entry1").Notes }} '
        'a = {{ keepassxcAttribute "entry1" "Password" }}|',
        fake_out=fake_out,
        extra_cfg='database = "%s"' % database,
        stdin=b"db-password\n",
    )
    # CATCHES: the database unlock prompt names the configured database
    # file, `keepassxc` parses the "Key: value" lines into fields, and
    # keepassxcAttribute fetches the same entry again with --attributes
    # and returns the whole (trailing-newline-trimmed) output.
    assert result.returncode == 0
    assert result.stdout == (
        "Enter password to unlock %s: u = kx-user p = kx-pw "
        "n = line one\n line two a = %s|" % (database, fake_out.rstrip("\n"))
    ).encode()
    assert result.stderr == b""
    assert r.stdin_text() == "db-password\n"
    assert r.log_lines() == [
        "ARGS: [show] [%s] [--quiet] [--show-protected] [entry1]" % database,
        "ARGS: [show] [%s] [entry1] [--attributes] [Password] "
        "[--quiet] [--show-protected]" % database,
    ]


def test_keepassxc_requires_database(tmp_path):
    """keepassxc without a configured database fails immediately."""
    r = runner(tmp_path)
    result = r.run("keepassxc", '{{ keepassxc "entry1" }}')
    # CATCHES: the database is a hard requirement and the error names the
    # config key that must be set.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" at <keepassxc "entry1">: '
        b"error calling keepassxc: keepassxc.database not set\n"
    )
    assert not r.log.exists()


def test_protonpass_template_funcs(tmp_path):
    """protonPass returns raw text; protonPassJSON adds --output=json."""
    r = runner(tmp_path)
    plain = r.run(
        "protonPass",
        'v = {{ protonPass "item" }}|',
        fake_out="pp-value",
    )
    assert plain.returncode == 0
    assert plain.stdout == b"v = pp-value|"
    assert r.log_lines() == ["ARGS: [item] [view] [item]"]

    r.log.unlink()
    as_json = r.run(
        "protonPass",
        'j = {{ (protonPassJSON "item").password }}',
        fake_out='{"password":"pp-json"}',
    )
    # CATCHES: the JSON variant appends --output=json to the same
    # `pass-cli item view` invocation.
    assert as_json.returncode == 0
    assert as_json.stdout == b"j = pp-json"
    assert r.log_lines() == ["ARGS: [item] [view] [item] [--output=json]"]


def test_protonpass_attachment(tmp_path):
    """protonPassAttachment downloads through a temp --output file."""
    r = runner(tmp_path)
    result = r.run(
        "protonPass",
        'a = {{ protonPassAttachment "share1" "item1" "att1" }}|',
        fake_out="attachment-contents",
    )
    # CATCHES: the attachment is downloaded with share/item/attachment ids
    # and an --output temp file, whose contents become the return value.
    assert result.returncode == 0
    assert result.stdout == b"a = attachment-contents|"
    assert result.stderr == b""
    (line,) = r.log_lines()
    normalized = re.sub(
        r"[^\[\s]*chezmoi-proton-pass\d+/attachment-\d+", "<TMPATT>", line
    )
    assert normalized == (
        "ARGS: [item] [attachment] [download] [--share-id] [share1] "
        "[--item-id] [item1] [--attachment-id] [att1] [--output] [<TMPATT>]"
    )
