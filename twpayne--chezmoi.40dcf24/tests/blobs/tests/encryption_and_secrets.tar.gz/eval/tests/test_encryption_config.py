"""Configuration selection and validation of the encryption subsystem.

Covers: unset/empty/unknown `encryption` values, age/gpg auto-detection
warnings, malformed recipients, missing identity/recipients files, builtin
age recipient requirements, dump-config defaults, and the --use-builtin-age
flag resolution rules.
"""

import json

from conftest import (
    age_keypair,
    make_home,
    run_chezmoi,
    write_config,
    write_script,
    FAKE_GPG_TEMPLATE,
)


def test_encrypt_without_configuration(tmp_path):
    """Encrypting with no configuration at all must fail with a clear error."""
    home = make_home(tmp_path)
    result = run_chezmoi(["encrypt"], cwd=home, home=home, stdin=b"hello world\n")
    # CATCHES: encryption is never a silent passthrough; with no config file
    # chezmoi refuses to encrypt instead of emitting the plaintext untouched.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: encryption not configured\n"


def test_encrypt_with_empty_config_file(tmp_path):
    """An existing but empty config file is treated as no configuration."""
    home = make_home(tmp_path)
    config = write_config(tmp_path, "")
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: an empty config still leaves `encryption` unset, and the same
    # explicit error is produced as with no config file at all.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: encryption not configured\n"


def test_unknown_encryption_value(tmp_path):
    """An unrecognized encryption backend name is rejected at startup."""
    home = make_home(tmp_path)
    config = write_config(tmp_path, 'encryption = "bogus"\n')
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: the configured backend name is validated and echoed back in
    # the error, so typos in `encryption` are diagnosable.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: bogus: unknown encryption\n"


def test_age_configuration_autodetected_with_warning(tmp_path):
    """An [age] block without `encryption` still works but warns on stderr."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(tmp_path, '[age]\nrecipient = "%s"\n' % recipient)
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: for backwards compatibility the [age] block alone selects age
    # encryption, but every run prints a warning naming the missing top-level
    # `encryption` key.
    assert result.returncode == 0
    assert result.stdout.startswith(b"-----BEGIN AGE ENCRYPTED FILE-----\n")
    assert result.stderr == (
        b"chezmoi: warning: 'encryption' not set, using age configuration. "
        b"Check if 'encryption' is correctly set as the top-level key.\n"
    )


def test_gpg_configuration_autodetected_with_warning(tmp_path):
    """A [gpg] block without `encryption` selects gpg and warns on stderr."""
    home = make_home(tmp_path)
    log = tmp_path / "gpglog.txt"
    fake_gpg = write_script(tmp_path / "fake-gpg.sh", FAKE_GPG_TEMPLATE)
    config = write_config(
        tmp_path,
        '[gpg]\ncommand = "%s"\nrecipient = "user@example.com"\n' % fake_gpg,
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"],
        cwd=home,
        home=home,
        stdin=b"x\n",
        env={"FAKE_LOG": log},
    )
    # CATCHES: the [gpg] block alone selects gpg encryption (the ciphertext
    # comes from the configured command) and prints the same shape of
    # 'encryption' not set warning as the age case.
    assert result.returncode == 0
    assert result.stdout == b"GPGFAKE-CIPHERTEXT\n"
    assert result.stderr == (
        b"chezmoi: warning: 'encryption' not set, using gpg configuration. "
        b"Check if 'encryption' is correctly set as the top-level key.\n"
    )


def test_gpg_preferred_when_both_blocks_configured(tmp_path):
    """With both [age] and [gpg] blocks and no `encryption`, gpg wins."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    log = tmp_path / "gpglog.txt"
    fake_gpg = write_script(tmp_path / "fake-gpg.sh", FAKE_GPG_TEMPLATE)
    config = write_config(
        tmp_path,
        '[age]\nrecipient = "%s"\n[gpg]\ncommand = "%s"\n'
        'recipient = "u@e.com"\n' % (recipient, fake_gpg),
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"],
        cwd=home,
        home=home,
        stdin=b"x\n",
        env={"FAKE_LOG": log},
    )
    # CATCHES: gpg is checked before age during auto-detection (backwards
    # compatibility), and only the gpg warning is printed - not both.
    assert result.returncode == 0
    assert result.stdout == b"GPGFAKE-CIPHERTEXT\n"
    assert result.stderr == (
        b"chezmoi: warning: 'encryption' not set, using gpg configuration. "
        b"Check if 'encryption' is correctly set as the top-level key.\n"
    )


def test_malformed_age_recipient(tmp_path):
    """A syntactically invalid age recipient fails with a parse position."""
    home = make_home(tmp_path)
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nrecipient = "age1xyz"\n'
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: builtin age parses recipients itself and reports the bech32
    # separator position and input length in the error message.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'chezmoi: malformed recipient "age1xyz": '
        b"separator '1' at invalid position: pos=3, len=7\n"
    )


def test_decrypt_with_recipient_only_config(tmp_path):
    """Decrypting with only a recipient configured has no identity to use."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nrecipient = "%s"\n' % recipient
    )
    encrypted = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    assert encrypted.returncode == 0
    result = run_chezmoi(
        ["--config", config, "decrypt"],
        cwd=home,
        home=home,
        stdin=encrypted.stdout,
    )
    # CATCHES: encrypt needs recipients but decrypt needs identities; a
    # recipient-only config fails decryption with an explicit message.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: no identities specified\n"


def test_missing_identity_file_is_config_error(tmp_path):
    """A configured age identity file that does not exist fails at startup."""
    home = make_home(tmp_path)
    missing = tmp_path / "missing-key.txt"
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nidentity = "%s"\n' % missing
    )
    result = run_chezmoi(
        ["--config", config, "decrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: identity files are read when the config is loaded, so the
    # error is a plain open error with the configured path, not a template
    # or decryption error.
    assert result.returncode == 1
    assert result.stderr == (
        "chezmoi: open %s: no such file or directory\n" % missing
    ).encode()


def test_missing_recipients_file_is_config_error(tmp_path):
    """A configured age recipients file that does not exist fails at startup."""
    home = make_home(tmp_path)
    missing = tmp_path / "missing-r.txt"
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nrecipientsFile = "%s"\n' % missing
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: recipients files are validated during config load even though
    # only the recipient count would matter for the encryption itself.
    assert result.returncode == 1
    assert result.stderr == (
        "chezmoi: open %s: no such file or directory\n" % missing
    ).encode()


def test_builtin_age_passphrase_without_recipients(tmp_path):
    """Builtin age with passphrase=true and no recipients cannot encrypt."""
    home = make_home(tmp_path)
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\npassphrase = true\n'
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: the passphrase/symmetric config keys only add flags for the
    # external age command; builtin age still requires explicit recipients.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: no recipients specified\n"


def test_builtin_age_symmetric_without_recipients(tmp_path):
    """Builtin age with symmetric=true and no recipients cannot encrypt."""
    home = make_home(tmp_path)
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nsymmetric = true\n'
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: symmetric=true behaves like passphrase=true for builtin age -
    # neither substitutes for a configured recipient.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: no recipients specified\n"


def test_dump_config_defaults(tmp_path):
    """dump-config reports the default commands and modes of every backend."""
    home = make_home(tmp_path)
    result = run_chezmoi(["dump-config"], cwd=home, home=home)
    assert result.returncode == 0
    data = json.loads(result.stdout)
    # CATCHES: every secret-manager backend has a fixed default command and
    # mode; these defaults are part of the observable CLI contract.
    expected = {
        ("encryption",): "",
        ("useBuiltinAge",): "auto",
        ("age", "command"): "age",
        ("age", "suffix"): ".age",
        ("gpg", "command"): "gpg",
        ("gpg", "suffix"): ".asc",
        ("bitwarden", "command"): "bw",
        ("bitwardenSecrets", "command"): "bws",
        ("dashlane", "command"): "dcli",
        ("doppler", "command"): "doppler",
        ("ejson", "keyDir"): "/opt/ejson/keys",
        ("gopass", "command"): "gopass",
        ("keepassxc", "mode"): "cache-password",
        ("keeper", "command"): "keeper",
        ("lastpass", "command"): "lpass",
        ("onepassword", "mode"): "account",
        ("pass", "command"): "pass",
        ("passhole", "command"): "ph",
        ("protonPass", "command"): "pass-cli",
        ("rbw", "command"): "rbw",
        ("secret", "command"): "",
        ("vault", "command"): "vault",
    }
    for path, value in expected.items():
        node = data
        for component in path:
            node = node[component]
        assert node == value, "%s: expected %r, got %r" % (".".join(path), value, node)


def test_age_use_builtin_config_key_must_be_bool(tmp_path):
    """The [age] useBuiltin config key only accepts a boolean."""
    home = make_home(tmp_path)
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nuseBuiltin = "auto"\n'
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: "auto" is a value of the global --use-builtin-age flag, but
    # the [age] config key is strictly boolean and rejects the string.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        "chezmoi: invalid config: %s: decoding failed due to the following "
        "error(s): 'age.useBuiltin' expected type 'bool', got unconvertible "
        "type 'string'\n" % config
    ).encode()


def test_age_use_builtin_config_key_is_overridden(tmp_path):
    """The [age] useBuiltin=true key is ignored; command presence decides."""
    home = make_home(tmp_path)
    log = tmp_path / "agelog.txt"
    fake_age = write_script(
        tmp_path / "fake-age.sh",
        "#!/bin/sh\n"
        '{ printf \'ARGS:\'; for a in "$@"; do printf \' [%s]\' "$a"; done; '
        "printf '\\n'; } >> \"$FAKE_LOG\"\n"
        "printf 'FAKEAGE-OUTPUT\\n'\n",
    )
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\ncommand = "%s"\nuseBuiltin = true\n'
        'recipient = "%s"\n' % (fake_age, recipient),
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"],
        cwd=home,
        home=home,
        stdin=b"x\n",
        env={"FAKE_LOG": log},
    )
    # CATCHES: when encryption = "age", the [age] useBuiltin value is
    # overwritten by the global flag's auto resolution, so even an explicit
    # useBuiltin = true does not force the builtin library when the
    # configured command exists.
    assert result.returncode == 0
    assert result.stdout == b"FAKEAGE-OUTPUT\n"
    assert log.read_text().splitlines() == [
        "ARGS: [--armor] [--encrypt] [--recipient] [%s]" % recipient
    ]


def test_use_builtin_age_false_without_age_binary(tmp_path):
    """--use-builtin-age=false requires a real age command on PATH."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path, 'encryption = "age"\n[age]\nrecipient = "%s"\n' % recipient
    )
    result = run_chezmoi(
        ["--config", config, "--use-builtin-age=false", "encrypt"],
        cwd=home,
        home=home,
        stdin=b"x\n",
    )
    # CATCHES: the flag disables the builtin library unconditionally, and
    # with no age binary on PATH the exec failure is reported verbatim.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b'chezmoi: exec: "age": executable file not found in $PATH\n'


def test_missing_age_command_falls_back_to_builtin(tmp_path):
    """Auto resolution silently uses builtin age when the command is absent."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\ncommand = "/nonexistent/age"\n'
        'recipient = "%s"\n' % recipient,
    )
    result = run_chezmoi(
        ["--config", config, "encrypt"], cwd=home, home=home, stdin=b"x\n"
    )
    # CATCHES: "auto" checks whether the configured command exists and falls
    # back to the builtin library without any warning or error.
    assert result.returncode == 0
    assert result.stdout.startswith(b"-----BEGIN AGE ENCRYPTED FILE-----\n")
    assert result.stderr == b""
