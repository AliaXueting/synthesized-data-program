"""Shared helpers for the chezmoi encryption_and_secrets black-box tests.

Every test drives the reference binary through ``run_chezmoi`` so that the
candidate binary is always resolved from ``PROGRAMGYM_EXECUTABLE`` and always
runs with a pinned, hermetic environment.
"""

import os
import re
import stat
import subprocess
from pathlib import Path

# A minimal PATH that contains gpg (needed for the real-gpg tests) but does
# NOT contain an `age` binary, so chezmoi's builtin age is the default.
MINIMAL_PATH = "/usr/bin:/bin"

# Standard fake command used by the secret-manager template function tests.
# It records its arguments (and BW_SESSION when present) to $FAKE_LOG,
# records its stdin to $FAKE_STDIN_LOG, prints $FAKE_OUT, optionally writes
# $FAKE_OUT to the file following --output, prints $FAKE_ERR on stderr and
# exits with $FAKE_EXIT.
FAKE_TEMPLATE = """#!/bin/bash
{ printf 'ARGS:'; for a in "$@"; do printf ' [%s]' "$a"; done
  if [ -n "$BW_SESSION" ]; then printf ' BW_SESSION=%s' "$BW_SESSION"; fi
  printf '\\n'; } >> "$FAKE_LOG"
if [ -n "$FAKE_STDIN_LOG" ]; then cat > "$FAKE_STDIN_LOG"; fi
out=""; prev=""
for a in "$@"; do
  if [ "$prev" = "--output" ]; then out="$a"; fi
  prev="$a"
done
if [ -n "$out" ]; then printf '%s' "$FAKE_OUT" > "$out"; fi
if [ -n "$FAKE_ERR" ]; then printf '%s' "$FAKE_ERR" >&2; fi
printf '%s' "$FAKE_OUT"
exit ${FAKE_EXIT:-0}
"""

# Fake gpg: records its arguments and writes a marker ciphertext to the file
# that follows --output (chezmoi reads the result back from that file).
FAKE_GPG_TEMPLATE = """#!/bin/sh
{ printf 'ARGS:'; for a in "$@"; do printf ' [%s]' "$a"; done; printf '\\n'; } >> "$FAKE_LOG"
out=""; prev=""
for a in "$@"; do
  if [ "$prev" = "--output" ]; then out="$a"; fi
  prev="$a"
done
printf 'GPGFAKE-CIPHERTEXT\\n' > "$out"
"""


def _coverage_env():
    """Coverage instrumentation hook: copy GOCOVERDIR into the child env."""
    gocoverdir = os.environ.get("GOCOVERDIR")
    return {"GOCOVERDIR": gocoverdir} if gocoverdir else {}


def run_chezmoi(args, *, cwd, home, env=None, stdin=b"", timeout=60):
    """Run the candidate chezmoi binary with a pinned environment.

    Returns the completed subprocess (returncode, stdout and stderr as bytes).
    """
    executable = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not executable:
        raise RuntimeError("PROGRAMGYM_EXECUTABLE is not set")
    child_env = {
        "HOME": str(home),
        "PATH": MINIMAL_PATH,
    }
    child_env.update(_coverage_env())
    if env:
        child_env.update({k: str(v) for k, v in env.items()})
    return subprocess.run(
        [executable] + [str(a) for a in args],
        cwd=str(cwd),
        env=child_env,
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )


def make_home(tmp_path):
    """Create a HOME directory with an empty source state; return its path."""
    home = tmp_path / "home"
    (home / ".local" / "share" / "chezmoi").mkdir(parents=True, exist_ok=True)
    return home


def write_config(tmp_path, body, name="chezmoi.toml"):
    """Write a chezmoi config file in its own directory; return its path."""
    cfg_dir = tmp_path / "cfg"
    cfg_dir.mkdir(exist_ok=True)
    config = cfg_dir / name
    config.write_text(body)
    return config


def write_script(path, body):
    """Write an executable script; return its path."""
    path.write_text(body)
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def age_keypair(tmp_path, home, name="identity.txt"):
    """Generate an age key pair with `age-keygen`.

    Returns (identity_file_path, recipient_string).
    """
    identity = tmp_path / name
    result = run_chezmoi(["age-keygen", "-o", identity], cwd=tmp_path, home=home)
    assert result.returncode == 0
    match = re.search(
        r"^# public key: (age1[0-9a-z]+)$",
        identity.read_text(),
        re.MULTILINE,
    )
    assert match, "age-keygen produced no public key comment"
    return identity, match.group(1)


def normalize_temp_paths(text):
    """Replace chezmoi's random private temp directories with <TMP>."""
    return re.sub(r"[^\[\s]*chezmoi-encryption\d+/", "<TMP>/", text)


class TemplateRunner:
    """Harness for the secret-manager template function tests.

    Writes a config with one [section] whose command is the standard fake
    command, runs `execute-template`, and exposes the fake's argument log.
    """

    def __init__(self, tmp_path, home):
        self.tmp_path = tmp_path
        self.home = home
        self.fake = write_script(tmp_path / "fake.bash", FAKE_TEMPLATE)
        self.log = tmp_path / "log.txt"
        self.stdin_log = tmp_path / "stdin.txt"

    def config(self, section, extra=""):
        if section:
            body = "[%s]\ncommand = \"%s\"\n%s\n" % (section, self.fake, extra)
        else:
            body = "%s\n" % extra
        return write_config(self.tmp_path, body)

    def run(self, section, template, *, fake_out="", fake_err="", fake_exit="",
            extra_cfg="", stdin=b"", env=None, flags=(), timeout=60):
        config = self.config(section, extra_cfg)
        child_env = {
            "FAKE_LOG": self.log,
            "FAKE_STDIN_LOG": self.stdin_log,
            "FAKE_OUT": fake_out,
            "FAKE_ERR": fake_err,
            "FAKE_EXIT": fake_exit,
        }
        if env:
            child_env.update(env)
        result = run_chezmoi(
            ["--config", config, "--no-tty"] + list(flags)
            + ["execute-template", template],
            cwd=self.home,
            home=self.home,
            env=child_env,
            stdin=stdin,
            timeout=timeout,
        )
        return result

    def log_lines(self):
        if not self.log.exists():
            return []
        return self.log.read_text().splitlines()

    def stdin_text(self):
        if not self.stdin_log.exists():
            return ""
        return self.stdin_log.read_text()
