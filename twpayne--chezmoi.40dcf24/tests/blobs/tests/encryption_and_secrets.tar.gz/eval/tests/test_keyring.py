"""The `chezmoi secret keyring` command and the keyring template function.

The system has no D-Bus secret service (org.freedesktop.secrets), which
these tests exploit: every operation that would talk to the keyring fails
with the D-Bus error, exposing the CLI's flag validation and prompt
behavior along the way.
"""

from conftest import make_home, run_chezmoi

DBUS_ERROR = (
    b"chezmoi: The name org.freedesktop.secrets was not provided "
    b"by any .service files\n"
)


def test_keyring_get_requires_service_and_user(tmp_path):
    """`secret keyring get` without --service/--user fails on required flags."""
    home = make_home(tmp_path)
    result = run_chezmoi(["secret", "keyring", "get"], cwd=tmp_path, home=home)
    # CATCHES: both flags are required and cobra reports them together,
    # before any keyring access is attempted.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b'chezmoi: required flag(s) "service", "user" not set\n'


def test_keyring_delete_requires_service_and_user(tmp_path):
    """`secret keyring delete` enforces the same required flags."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["secret", "keyring", "delete"], cwd=tmp_path, home=home
    )
    # CATCHES: the required-flag check is per subcommand, so delete fails
    # identically to get.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b'chezmoi: required flag(s) "service", "user" not set\n'


def test_keyring_get_rejects_value_flag(tmp_path):
    """--value belongs to set, not to get."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        [
            "secret", "keyring", "get",
            "--service", "foo", "--user", "bar", "--value", "v",
        ],
        cwd=tmp_path,
        home=home,
    )
    # CATCHES: get has no --value flag and the unknown flag is rejected
    # before the required-flag validation runs.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: unknown flag: --value\n"


def test_keyring_set_prompts_for_value(tmp_path):
    """`secret keyring set` without --value prompts "Value: " on stdout."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        [
            "--no-tty",
            "secret", "keyring", "set",
            "--service", "foo", "--user", "bar",
        ],
        cwd=tmp_path,
        home=home,
        stdin=b"",
    )
    # CATCHES: the value is read interactively after a "Value: " prompt on
    # stdout; with no input the read fails with EOF before the keyring is
    # touched.
    assert result.returncode == 1
    assert result.stdout == b"Value: "
    assert result.stderr == b"chezmoi: EOF\n"


def test_keyring_operations_report_missing_secret_service(tmp_path):
    """get/delete/set against the keyring surface the D-Bus service error."""
    home = make_home(tmp_path)
    for args in (
        ["secret", "keyring", "get", "--service", "foo", "--user", "bar"],
        ["secret", "keyring", "delete", "--service", "foo", "--user", "bar"],
        [
            "secret", "keyring", "set",
            "--service", "foo", "--user", "bar", "--value", "secretpw",
        ],
    ):
        result = run_chezmoi(args, cwd=tmp_path, home=home)
        # CATCHES: all three operations go through the same keyring
        # library, whose D-Bus error is reported verbatim with the chezmoi
        # prefix and nothing on stdout.
        assert result.returncode == 1
        assert result.stdout == b""
        assert result.stderr == DBUS_ERROR


def test_keyring_template_func_reports_secret_service(tmp_path):
    """The keyring template function wraps the D-Bus error with service/user."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["--no-tty", "execute-template", '{{ keyring "service" "user" }}'],
        cwd=tmp_path,
        home=home,
    )
    # CATCHES: the template function prefixes the keyring error with the
    # "<service> <user>" pair it was called with.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'chezmoi: template: arg1:1:3: executing "arg1" '
        b'at <keyring "service" "user">: error calling keyring: '
        b"service user: The name org.freedesktop.secrets was not provided "
        b"by any .service files\n"
    )


def test_secret_command_help(tmp_path):
    """`chezmoi secret` with no subcommand prints help and exits zero."""
    home = make_home(tmp_path)
    result = run_chezmoi(["secret"], cwd=tmp_path, home=home)
    # CATCHES: the secret command groups the keyring subcommand and shows
    # the three keyring examples in its help text.
    assert result.returncode == 0
    assert result.stderr == b""
    text = result.stdout.decode()
    assert "chezmoi secret [command]" in text
    assert "keyring     Interact with keyring" in text
    assert (
        "chezmoi secret keyring set --service=service --user=user "
        "--value=password" in text
    )
    assert (
        "chezmoi secret keyring get --service=service --user=user" in text
    )
    assert (
        "chezmoi secret keyring delete --service=service --user=user" in text
    )


def test_secret_keyring_help_lists_subcommands(tmp_path):
    """`chezmoi secret keyring` lists its get/set/delete subcommands."""
    home = make_home(tmp_path)
    result = run_chezmoi(["secret", "keyring"], cwd=tmp_path, home=home)
    # CATCHES: keyring's own help enumerates delete, get and set with their
    # one-line descriptions.
    assert result.returncode == 0
    assert result.stderr == b""
    text = result.stdout.decode()
    assert "chezmoi secret keyring [command]" in text
    assert "delete      Delete a value from keyring" in text
    assert "get         Get a value from keyring" in text
    assert "set         Set a value in keyring" in text
