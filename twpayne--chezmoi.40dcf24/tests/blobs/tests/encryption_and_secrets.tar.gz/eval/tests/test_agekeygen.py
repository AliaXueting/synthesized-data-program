"""The `chezmoi age-keygen` command.

Covers: output format on stdout and with -o (including file mode),
--convert/-y recipient extraction from identities, error paths (empty or
invalid identity input, --pq/--convert conflict, arity), and post-quantum
key generation.
"""

import re

from conftest import age_keypair, make_home, run_chezmoi


def _parse_keygen(text):
    """Return (created_comment, public_comment, identity_line)."""
    lines = text.splitlines()
    assert len(lines) == 3
    return lines[0], lines[1], lines[2]


def test_age_keygen_output_format(tmp_path):
    """Plain `age-keygen` writes a 3-line identity to stdout."""
    home = make_home(tmp_path)
    result = run_chezmoi(["age-keygen"], cwd=tmp_path, home=home)
    # CATCHES: the output is exactly three lines - a creation timestamp
    # comment, a public key comment, and the secret key - with nothing on
    # stderr.
    assert result.returncode == 0
    assert result.stderr == b""
    created, public, identity = _parse_keygen(result.stdout.decode())
    assert re.fullmatch(
        r"# created: \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}",
        created,
    )
    assert re.match(r"^# public key: age1[0-9a-z]+$", public)
    assert identity.startswith("AGE-SECRET-KEY-1")
    assert public.split(": ")[1] != identity


def test_age_keygen_output_file(tmp_path):
    """`age-keygen -o file` writes the same 3 lines with mode 0600."""
    home = make_home(tmp_path)
    output = tmp_path / "k1.txt"
    result = run_chezmoi(["age-keygen", "-o", output], cwd=tmp_path, home=home)
    # CATCHES: with -o nothing is printed; the key file is created with
    # owner-only permissions because it holds a private key.
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == b""
    assert output.stat().st_mode & 0o777 == 0o600
    created, public, identity = _parse_keygen(output.read_text())
    assert re.fullmatch(
        r"# created: \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}",
        created,
    )
    assert re.match(r"^# public key: age1[0-9a-z]+$", public)
    assert identity.startswith("AGE-SECRET-KEY-1")


def test_age_keygen_convert_from_stdin(tmp_path):
    """`age-keygen -y` derives the recipient from an identity on stdin."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    result = run_chezmoi(
        ["age-keygen", "-y"],
        cwd=tmp_path,
        home=home,
        stdin=identity.read_bytes(),
    )
    # CATCHES: -y strips the private key and prints only the bech32
    # recipient corresponding to the identity, one line, nothing else.
    assert result.returncode == 0
    assert result.stdout == recipient.encode() + b"\n"
    assert result.stderr == b""


def test_age_keygen_convert_from_file(tmp_path):
    """`--convert file` reads the identity from the file argument."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    result = run_chezmoi(
        ["age-keygen", "--convert", identity], cwd=tmp_path, home=home
    )
    # CATCHES: --convert is the long spelling of -y with a file operand
    # instead of stdin, producing the identical recipient line.
    assert result.returncode == 0
    assert result.stdout == recipient.encode() + b"\n"
    assert result.stderr == b""


def test_age_keygen_convert_multiple_identities(tmp_path):
    """Converting two concatenated identities prints two recipients."""
    home = make_home(tmp_path)
    identity1, recipient1 = age_keypair(tmp_path, home, "identity1.txt")
    identity2, recipient2 = age_keypair(tmp_path, home, "identity2.txt")
    combined = identity1.read_bytes() + identity2.read_bytes()
    result = run_chezmoi(
        ["age-keygen", "-y"], cwd=tmp_path, home=home, stdin=combined
    )
    # CATCHES: every identity in the stream is converted, in input order,
    # one recipient per line.
    assert result.returncode == 0
    assert result.stdout.decode().splitlines() == [recipient1, recipient2]
    assert result.stderr == b""


def test_age_keygen_convert_empty_input(tmp_path):
    """Converting empty input finds no identities."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age-keygen", "-y"], cwd=tmp_path, home=home, stdin=b""
    )
    # CATCHES: an empty identity stream is an explicit error rather than an
    # empty recipient output.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: no identities found\n"


def test_age_keygen_convert_invalid_identity(tmp_path):
    """A line that is not an identity fails with its line number."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age-keygen", "-y"],
        cwd=tmp_path,
        home=home,
        stdin=b"not an identity\n",
    )
    # CATCHES: the parser reports the offending line number and the reason
    # (unknown identity type) instead of skipping the line.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: error at line 1: unknown identity type\n"


def test_age_keygen_pq_conflicts_with_convert(tmp_path):
    """--pq cannot be combined with --convert."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age-keygen", "--pq", "--convert"], cwd=tmp_path, home=home, stdin=b""
    )
    # CATCHES: generating a post-quantum key and converting an existing
    # identity are mutually exclusive operations on the same command.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: --pq cannot be used with --convert\n"


def test_age_keygen_pq_generates_pq_keypair(tmp_path):
    """`age-keygen --pq` generates a post-quantum key pair."""
    home = make_home(tmp_path)
    result = run_chezmoi(["age-keygen", "--pq"], cwd=tmp_path, home=home)
    # CATCHES: the post-quantum recipient and identity use their own bech32
    # prefixes (age1pq / AGE-SECRET-KEY-PQ-) in the same 3-line format.
    assert result.returncode == 0
    assert result.stderr == b""
    created, public, identity = _parse_keygen(result.stdout.decode())
    assert re.fullmatch(
        r"# created: \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}",
        created,
    )
    assert public.startswith("# public key: age1pq")
    assert identity.startswith("AGE-SECRET-KEY-PQ-")


def test_age_keygen_rejects_two_arguments(tmp_path):
    """age-keygen accepts at most one positional argument."""
    home = make_home(tmp_path)
    result = run_chezmoi(
        ["age-keygen", "a", "b"], cwd=tmp_path, home=home
    )
    # CATCHES: the arity check counts the received arguments and reports
    # both bounds in the error.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"chezmoi: accepts at most 1 arg(s), received 2\n"


def test_age_keygen_rejects_positional_output(tmp_path):
    """A positional argument is not accepted as an output path."""
    home = make_home(tmp_path)
    target = tmp_path / "kx.txt"
    result = run_chezmoi(["age-keygen", target], cwd=tmp_path, home=home)
    # CATCHES: unlike many chezmoi commands, age-keygen has no positional
    # operand; the argument is rejected as an unknown subcommand and no
    # output file is created.
    assert result.returncode == 1
    assert not target.exists()
    assert result.stderr == (
        'chezmoi: unknown command "%s" for "chezmoi age-keygen"\n' % target
    ).encode()
