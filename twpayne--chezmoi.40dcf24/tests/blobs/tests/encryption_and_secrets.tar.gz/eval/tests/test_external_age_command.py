"""External age command mode: the argument matrix and flag overrides.

When `encryption = "age"` and the configured age command exists, chezmoi
shells out to it. These tests record the exact argv that chezmoi builds for
every recipient/identity/passphrase/symmetric/args configuration, and the
--age-recipient / --age-recipient-file flag overrides.
"""

import pytest

from conftest import (
    FAKE_TEMPLATE,
    age_keypair,
    make_home,
    run_chezmoi,
    write_config,
    write_script,
)


def args_line(args):
    """Render an argv the way the fake command logs it."""
    return "ARGS:" + "".join(" [%s]" % a for a in args)


def run_age_external(tmp_path, extra_cfg, args, stdin=b"", extra_flags=()):
    """Run chezmoi with the standard fake age command; return (result, log)."""
    home = make_home(tmp_path)
    fake = write_script(tmp_path / "fake-age.sh", FAKE_TEMPLATE)
    log = tmp_path / "agelog.txt"
    config = write_config(
        tmp_path,
        'encryption = "age"\n[age]\ncommand = "%s"\n%s\n' % (fake, extra_cfg),
    )
    result = run_chezmoi(
        ["--config", config] + list(extra_flags) + list(args),
        cwd=tmp_path,
        home=home,
        stdin=stdin,
        env={"FAKE_LOG": log, "FAKE_OUT": "FAKEAGE-OUTPUT\n"},
    )
    return result, log


def log_lines(log):
    return log.read_text().splitlines()


ENCRYPT_CASES = [
    pytest.param(
        lambda tmp_path: ('recipient = "r1"',
                          ["--armor", "--encrypt", "--recipient", "r1"]),
        id="recipient",
    ),
    pytest.param(
        lambda tmp_path: ('recipients = ["r1", "r2"]',
                          ["--armor", "--encrypt", "--recipient", "r1",
                           "--recipient", "r2"]),
        id="recipients-list",
    ),
    pytest.param(
        lambda tmp_path: ('recipient = "cfg-r"\nrecipients = ["r1", "r2"]',
                          ["--armor", "--encrypt", "--recipient", "cfg-r",
                           "--recipient", "r1", "--recipient", "r2"]),
        id="recipient-and-recipients-merged-in-order",
    ),
    pytest.param(
        lambda tmp_path: ('passphrase = true',
                          ["--armor", "--encrypt", "--passphrase"]),
        id="passphrase",
    ),
    pytest.param(
        lambda tmp_path: ('symmetric = true',
                          ["--armor", "--encrypt"]),
        id="symmetric",
    ),
    pytest.param(
        lambda tmp_path: ('recipient = "r1"\nargs = ["--extra1", "--extra2"]',
                          ["--armor", "--encrypt", "--recipient", "r1",
                           "--extra1", "--extra2"]),
        id="config-args-appended-last",
    ),
    pytest.param(
        lambda tmp_path: ('recipientsFile = "%s"' % (tmp_path / "recips"),
                          ["--armor", "--encrypt", "--recipients-file",
                           str(tmp_path / "recips")]),
        id="recipients-file",
    ),
    pytest.param(
        lambda tmp_path: ('recipientsFiles = ["%s", "%s"]'
                          % (tmp_path / "r1", tmp_path / "r2"),
                          ["--armor", "--encrypt", "--recipients-file",
                           str(tmp_path / "r1"), "--recipients-file",
                           str(tmp_path / "r2")]),
        id="recipients-files-list",
    ),
    pytest.param(
        lambda tmp_path: ('symmetric = true\nidentity = "%s"'
                          % (tmp_path / "ident"),
                          ["--armor", "--encrypt", "--identity",
                           str(tmp_path / "ident")]),
        id="symmetric-with-identity",
    ),
]


@pytest.mark.parametrize("case", ENCRYPT_CASES)
def test_age_external_encrypt_args(tmp_path, case):
    """Each [age] config shape maps to a fixed external age encrypt argv."""
    extra_cfg, expected = case(tmp_path)
    for path in ("recips", "r1", "r2", "ident"):
        (tmp_path / path).write_text("age1placeholder\n")
    result, log = run_age_external(tmp_path, extra_cfg, ["encrypt"], b"x\n")
    # CATCHES: chezmoi always prepends --armor and --encrypt, expands every
    # configured recipient into repeated --recipient flags (config `recipient`
    # first, then `recipients`), maps passphrase/symmetric/identity config to
    # their flags, and appends config `args` at the very end.
    assert result.returncode == 0
    assert result.stdout == b"FAKEAGE-OUTPUT\n"
    assert result.stderr == b""
    assert log_lines(log) == [args_line(expected)]


DECRYPT_CASES = [
    pytest.param(
        lambda tmp_path: ('identity = "%s"' % (tmp_path / "ident"),
                          ["--decrypt", "--identity", str(tmp_path / "ident")]),
        id="identity",
    ),
    pytest.param(
        lambda tmp_path: ('identities = ["%s", "%s"]'
                          % (tmp_path / "id1", tmp_path / "id2"),
                          ["--decrypt", "--identity", str(tmp_path / "id1"),
                           "--identity", str(tmp_path / "id2")]),
        id="identities-list",
    ),
]


@pytest.mark.parametrize("case", DECRYPT_CASES)
def test_age_external_decrypt_args(tmp_path, case):
    """Decrypt configurations map to --decrypt with repeated --identity."""
    extra_cfg, expected = case(tmp_path)
    for path in ("ident", "id1", "id2"):
        (tmp_path / path).write_text("AGE-SECRET-KEY-1PLACEHOLDER\n")
    result, log = run_age_external(
        tmp_path, extra_cfg, ["decrypt"], b"ciphertext\n"
    )
    # CATCHES: decryption passes --decrypt first and one --identity flag
    # per configured identity, with the ciphertext streamed on stdin and
    # the command's stdout passed through as the plaintext.
    assert result.returncode == 0
    assert result.stdout == b"FAKEAGE-OUTPUT\n"
    assert result.stderr == b""
    assert log_lines(log) == [args_line(expected)]


def test_age_recipient_flag_overrides_config(tmp_path):
    """--age-recipient replaces all recipients from the config."""
    home = make_home(tmp_path)
    identity, recipient = age_keypair(tmp_path, home)
    result, log = run_age_external(
        tmp_path,
        'recipients = ["cfg1", "cfg2"]',
        ["encrypt"],
        b"x\n",
        extra_flags=["--age-recipient", recipient],
    )
    # CATCHES: the flag does not add to the configured recipients - the
    # config list is dropped entirely and only the flag value is passed.
    assert result.returncode == 0
    assert result.stdout == b"FAKEAGE-OUTPUT\n"
    assert log_lines(log) == [
        args_line(["--armor", "--encrypt", "--recipient", recipient])
    ]


def test_age_recipient_file_flag_overrides_config(tmp_path):
    """--age-recipient-file replaces config recipients with a file flag."""
    recipients_file = tmp_path / "rf"
    recipients_file.write_text("recipient-from-file\n")
    result, log = run_age_external(
        tmp_path,
        'recipients = ["cfg1", "cfg2"]',
        ["encrypt"],
        b"x\n",
        extra_flags=["--age-recipient-file", recipients_file],
    )
    # CATCHES: the recipient-file flag takes the --recipients-file form and,
    # like --age-recipient, discards the configured recipient list.
    assert result.returncode == 0
    assert result.stdout == b"FAKEAGE-OUTPUT\n"
    assert log_lines(log) == [
        args_line(["--armor", "--encrypt", "--recipients-file",
                   str(recipients_file)])
    ]


def test_age_recipient_flags_are_mutually_exclusive(tmp_path):
    """--age-recipient and --age-recipient-file cannot both be set."""
    recipients_file = tmp_path / "rf"
    recipients_file.write_text("recipient-from-file\n")
    result, log = run_age_external(
        tmp_path,
        'recipients = ["cfg1"]',
        ["encrypt"],
        b"x\n",
        extra_flags=["--age-recipient", "a", "--age-recipient-file",
                     recipients_file],
    )
    # CATCHES: the two recipient flags are validated against each other
    # before any recipient parsing or command execution happens.
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b"chezmoi: --age-recipient and --age-recipient-file cannot both be set\n"
    )
    assert not log.exists()
