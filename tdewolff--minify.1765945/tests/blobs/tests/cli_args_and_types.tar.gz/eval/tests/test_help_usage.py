"""--help / -h output, usage rendering and option-parsing diagnostics.

These tests pin the exact bytes of the usage screen, which stream each part is
written to, the exit codes, and the way a bad option name is reported.
"""

import os
import re
import shutil

import pytest

from conftest import USAGE, assigned_executable, run_minify, write_file


def test_help_long_flag_prints_usage_on_stdout():
    """--help writes the full usage screen to stdout and exits 0."""
    # CATCHES: a reimplementation that prints help to stderr, exits non-zero,
    # or drops/renames a single option line from the usage screen.
    proc = run_minify(["--help"])
    assert proc.returncode == 0
    assert proc.stdout == USAGE
    assert proc.stderr == b""


def test_help_short_flag_is_identical_to_long_flag():
    """-h produces byte-identical output to --help."""
    # CATCHES: a reimplementation that registers -h as a different option or
    # that only implements one of the two spellings.
    short = run_minify(["-h"])
    long = run_minify(["--help"])
    assert short.returncode == 0
    assert short.stdout == long.stdout == USAGE
    assert short.stderr == long.stderr == b""


@pytest.mark.parametrize("flag", ["--help", "-h"])
def test_help_beats_version_list_and_bad_type(flag):
    """--help short-circuits --version, --list and filetype validation."""
    # CATCHES: the reference handles help inside the argument parser, so help
    # wins over every later check; a reimplementation that checks --version or
    # --list first would print something else entirely.
    for extra in (["--version"], ["--list"], ["--type", "bogus"], ["--type"]):
        proc = run_minify([flag] + extra)
        assert proc.returncode == 0
        assert proc.stdout == USAGE
        assert proc.stderr == b""


def test_help_with_a_positional_input_still_prints_usage():
    """A trailing input filename does not stop --help from being handled."""
    # CATCHES: a reimplementation that only prints help when no positional
    # arguments are present would try to minify the file instead.
    proc = run_minify(["--help", "somefile.css"])
    assert proc.returncode == 0
    assert proc.stdout == USAGE
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "argv,stderr",
    [
        (["--bogus"], b"unknown option --bogus\n\n"),
        (["--typ"], b"unknown option --typ\n\n"),
        (["--type2"], b"unknown option --type2\n\n"),
        (["-z"], b"unknown option -z\n\n"),
        (["-type"], b"unknown option -t\n\n"),
        (["-Z"], b"unknown option -Z\n\n"),
    ],
)
def test_unknown_option_reports_name_and_exit_code(argv, stderr):
    """An unrecognised option exits 2 with `unknown option <name>` on stderr."""
    # CATCHES: the exact diagnostic text (including the trailing blank line),
    # the exit code 2 (not 1), and that long names are never abbreviated while
    # a single dash is parsed as a short option, so `-type` reports `-t`.
    proc = run_minify(argv)
    assert proc.returncode == 2
    assert proc.stderr == stderr
    assert proc.stdout == USAGE


def test_parse_error_writes_usage_to_stdout_and_message_to_stderr():
    """Streams are split: usage on stdout, the diagnostic on stderr."""
    # CATCHES: a reimplementation that prints the whole diagnostic block to one
    # stream, or that omits the empty line after the message.
    proc = run_minify(["--nope"])
    assert proc.returncode == 2
    assert proc.stdout == USAGE
    assert proc.stderr == b"unknown option --nope\n\n"
    assert b"Usage:" in proc.stdout
    assert b"unknown option" not in proc.stdout
    assert b"Usage:" not in proc.stderr


def test_help_does_not_beat_an_unknown_option():
    """An unknown option still fails with exit 2 even when -h is present."""
    # CATCHES: the parser scans every argument before honouring help, so
    # `-h --bogus` is a usage error rather than a clean help screen.
    proc = run_minify(["-h", "--bogus"])
    assert proc.returncode == 2
    assert proc.stdout == USAGE
    assert proc.stderr == b"unknown option --bogus\n\n"


def test_usage_line_is_derived_from_argv0_basename(tmp_path):
    """The usage line names the program after the basename of argv[0]."""
    # CATCHES: a reimplementation that hardcodes the program name would keep
    # printing `minify` when the binary is invoked under another name.
    copy = tmp_path / "renamed-minify"
    shutil.copyfile(assigned_executable(), str(copy))
    copy.chmod(0o755)
    proc = run_minify(["--help"], binary=str(copy))
    assert proc.returncode == 0
    lines = proc.stdout.split(b"\n")
    assert lines[0] == b"Usage: renamed-minify [options] inputs..."
    assert b"\n".join(lines[1:]) == USAGE.split(b"\n", 1)[1]


def test_usage_documents_the_rest_argument():
    """The usage screen ends with an Arguments block for `inputs`."""
    # CATCHES: the positional rest argument and its description are part of the
    # contract; a reimplementation that forgets the block, or pads the column
    # differently, changes these bytes.
    proc = run_minify(["-h"])
    assert proc.stdout.endswith(
        b"Arguments:\n"
        b"  inputs    Input files or directories, leave blank to use stdin\n"
    )
    assert proc.stdout.count(b"Arguments:\n") == 1


def test_option_lines_are_sorted_by_short_name_then_long_name():
    """Options are listed in one lexicographic merge of short and long names."""
    # CATCHES: a reimplementation that lists options in registration order, or
    # that sorts short-named and long-named options separately, reorders the
    # block (e.g. `-p` must sit between `--mime` and `-q`).
    proc = run_minify(["--help"])
    assert proc.returncode == 0
    assert proc.stdout == USAGE
    body = proc.stdout.split(b"\nOptions:\n", 1)[1]
    names = []
    pattern = re.compile(rb"^(?:  -(\w), --| {6}--)([A-Za-z0-9_-]+)")
    for line in body.split(b"\n"):
        match = pattern.match(line)
        if match:
            names.append(match.group(1) or match.group(2))
    assert names == sorted(names)
    assert names == [
        b"a", b"b", b"css-precision", b"css-version", b"exclude", b"ext", b"h",
        b"html-keep-comments", b"html-keep-conditional-comments",
        b"html-keep-default-attrvals", b"html-keep-document-tags",
        b"html-keep-end-tags", b"html-keep-quotes", b"html-keep-special-comments",
        b"html-keep-whitespace", b"i", b"include", b"js-keep-var-names",
        b"js-precision", b"js-version", b"json-keep-numbers", b"json-precision",
        b"l", b"match", b"mime", b"o", b"p", b"q", b"r", b"s",
        b"svg-keep-comments", b"svg-keep-namespaces", b"svg-precision", b"type",
        b"url", b"v", b"version", b"w", b"xml-keep-whitespace",
    ]


def test_double_dash_turns_the_rest_into_positional_inputs():
    """After `--` nothing is treated as an option, not even --help."""
    # CATCHES: a reimplementation that keeps parsing options after `--` would
    # show the usage screen instead of treating `--help` as a filename.
    proc = run_minify(["--", "--help"])
    assert proc.returncode == 0
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: stat --help: no such file or directory\n"


def test_empty_argument_is_dropped_not_treated_as_input(tmp_path):
    """A zero-length argument is ignored rather than becoming an input."""
    # CATCHES: the reference skips empty argv entries, so `--type css ""` reads
    # stdin instead of trying to open an empty path.
    proc = run_minify(["--type", "css", ""], stdin=b"a { color: red; }\n")
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b""


def test_help_is_not_wrapped_when_stdout_is_a_pipe():
    """Every option description stays on one line because stdin is not a tty."""
    # CATCHES: the reference only wraps descriptions to the terminal width; a
    # reimplementation that always wraps would break these exact bytes.
    proc = run_minify(["--help"])
    assert proc.stdout == USAGE
    for line in proc.stdout.split(b"\n"):
        if line.startswith(b"      --css-version"):
            assert line.endswith(b"by default 0 is the latest version")
            break
    else:
        raise AssertionError("css-version line missing from usage screen")
