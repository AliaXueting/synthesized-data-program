"""CSS shorthand-property minification as reached through the CLI.

This module pins the property-specific rewrites that `--type css` performs
inside css/css.go's minifyProperty and its helpers: the font shorthand scan,
the url/src local() unquoting, background origin/clip/size/repeat/position
folding, box-model and box-shadow list handling, colour minification per
property family, rgb()/rgba() argument validation, unicode-range parsing,
unit lowercasing, and the recursion/size guards for deeply nested functions
and very long value lists.  Every expected byte sequence was recorded by
running `./executable`.
"""

import pytest

from conftest import run_minify


def minify_css(body, *flags):
    """Run the reference with --type css and return the CompletedProcess."""
    return run_minify(["--type", "css", *flags], stdin=body.encode())


# ------------------------------------------------------------------- font


@pytest.mark.parametrize(
    "body",
    ["a{font:12px xx-small Georgia}", "a{font:12px 0 Georgia}"],
    ids=["size-keyword", "number"],
)
def test_font_family_scan_stops_before_non_family(body):
    """The font shorthand's family scan breaks on keywords and numbers."""
    # CATCHES: while walking back over the family list the scanner stops at a
    # font-size keyword (xx-small) and at any non-ident token (0), so the
    # strange middle token is left in place and the declaration round-trips
    # byte for byte instead of being mis-parsed as a family name.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


def test_font_weight_bold_becomes_700():
    """font-weight:bold is rewritten to its numeric form."""
    # CATCHES: the keyword weight is replaced by the number 700, matching the
    # normal-to-400 rewrite already covered for font-weight:normal.
    proc = minify_css("a{font-weight:bold}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{font-weight:700}"
    assert proc.stderr == b""


def test_font_family_keeps_quotes_when_content_is_not_an_ident():
    """A quoted family that is not a plain ident stays quoted but lowercased."""
    # CATCHES: `!` is not allowed in an unquoted identifier so the quotes are
    # kept, yet the string contents are still lowercased inside the quotes.
    proc = minify_css('a{font-family:"Foo Bar!"}')
    assert proc.returncode == 0
    assert proc.stdout == b'a{font-family:"foo bar!"}'
    assert proc.stderr == b""


# -------------------------------------------------------------- url / src


@pytest.mark.parametrize(
    "body,expected",
    [
        ('a{url:local("Arial")}', b"a{url:local(Arial)}"),
        ('a{url:local("a b")}', b'a{url:local("a b")}'),
    ],
    ids=["unquoted", "kept-quoted"],
)
def test_url_property_unquotes_local_source(body, expected):
    """The url property unquotes local() sources that are legal idents."""
    # CATCHES: a declaration named url is recognised and its local("Arial")
    # argument loses its quotes because Arial is a valid unquoted URL, while a
    # space inside the string forces the quotes to stay.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_url_with_space_stays_quoted():
    """A url() whose target needs quoting keeps its quotes."""
    # CATCHES: the space in the file name is not allowed unquoted, so the
    # rewritten token keeps the double quotes around a b.png.
    proc = minify_css('a{background:url("a b.png")}')
    assert proc.returncode == 0
    assert proc.stdout == b'a{background:url("a b.png")}'
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("@import url( a.css );", b'@import "a.css";'),
        ("@import url( a );", b'@import "";'),
    ],
    ids=["padded", "all-whitespace"],
)
def test_import_unquoted_url_gets_requoted(body, expected):
    """@import rewrites a padded unquoted url() into a quoted string."""
    # CATCHES: the whitespace padding inside url() is trimmed and the target
    # is emitted as a quoted string; when the padding eats the whole target
    # the result is an empty quoted string, not a mangled URL.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


# ------------------------------------------------------------- background


def test_background_leading_comma_is_kept():
    """An empty background layer keeps its leading comma."""
    # CATCHES: the layer loop skips the empty list before the comma without
    # deleting the separator, so malformed input round-trips unchanged.
    proc = minify_css("a{background:,red}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:,red}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{background:url(a.png) 0 0/auto auto}", b"a{background:url(a.png)}"),
        ("a{background:url(a.png) 0 0/10px auto}", b"a{background:url(a.png)0 0/10px}"),
    ],
    ids=["auto-auto", "10px-auto"],
)
def test_background_size_after_slash_is_folded(body, expected):
    """The /size part of the background shorthand is minimized in place."""
    # CATCHES: `/auto auto` collapses to nothing and the position keeps no
    # space before the slash once the size is a single value, proving the
    # size list is re-minified as the background-size property.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_background_origin_and_clip_cancel_out():
    """padding-box border-box in the background shorthand is removed."""
    # CATCHES: the origin (padding-box) and the clip (border-box) are the
    # initial values, so both idents are deleted and the empty layer falls
    # back to the `0 0` position, not to `none`.
    proc = minify_css("a{background:padding-box border-box}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:0 0}"
    assert proc.stderr == b""


def test_background_transparent_black_hex_is_removed():
    """#0000 as a background layer is deleted entirely."""
    # CATCHES: the four-digit hex with zero alpha is dropped from the layer
    # and the layer regenerates as `0 0`, unlike #000 which survives.
    proc = minify_css("a{background:#0000}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:0 0}"
    assert proc.stderr == b""


def test_background_var_function_is_untouched():
    """A var() in the background shorthand is left alone."""
    # CATCHES: custom-property references are skipped by every background
    # rewrite (colour, repeat and position), so the declaration is returned
    # byte for byte.
    proc = minify_css("a{background:var(--x)}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:var(--x)}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{background-repeat:no-repeat repeat}", b"a{background-repeat:repeat-y}"),
        ("a{background-repeat:,repeat}", b"a{background-repeat:,repeat}"),
    ],
    ids=["vertical-fold", "leading-comma"],
)
def test_background_repeat_vertical_and_empty_list(body, expected):
    """repeat-y folding and empty-list handling in background-repeat."""
    # CATCHES: `no-repeat repeat` folds to the vertical keyword repeat-y,
    # while an empty first layer keeps its leading comma exactly as given.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{background-size:,10px}", b"a{background-size:,10px}"),
        ("a{background-size:10px auto}", b"a{background-size:10px}"),
        ("a{background-size:10px,20px}", b"a{background-size:10px,20px}"),
    ],
    ids=["leading-comma", "auto-dropped", "two-layers"],
)
def test_background_size_property_folds_auto(body, expected):
    """background-size drops a trailing auto and skips empty layers."""
    # CATCHES: `10px auto` loses the redundant auto, but the two-layer list
    # is kept comma-separated and the empty layer keeps its comma.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{background-position:,left}", b"a{background-position:,0}"),
        ("a{background-position:left 0 top 20px}", b"a{background-position:0 20px}"),
        ("a{background-position:left top 20px}", b"a{background-position:0 20px}"),
        ("a{background-position:left 50%}", b"a{background-position:0}"),
        ("a{background-position:0% 0%}", b"a{background-position:0 0}"),
        ("a{background-position:left 10px center}", b"a{background-position:10px}"),
        ("a{background-position:center top 10px}", b"a{background-position:50% 10px}"),
        ("a{background-position:right 10% bottom 20%}", b"a{background-position:90% 90%}"),
        ("a{background-position:right 10% bottom 60%}", b"a{background-position:90% 90%}"),
        ("a{background-position:left 10% bottom 20%}", b"a{background-position:10% 80%}"),
        ("a{background-position:right 10% top 20%}", b"a{background-position:90% 20%}"),
    ],
    ids=[
        "leading-comma",
        "zero-offset-removed",
        "implicit-zero",
        "left-50",
        "zero-percent",
        "center-left",
        "center-top",
        "both-percent",
        "both-percent-60",
        "bottom-percent-only",
        "right-percent-only",
    ],
)
def test_background_position_rewrites(body, expected):
    """background-position keyword/offset combinations are normalized."""
    # CATCHES: keywords become numbers or percentages, zero offsets are
    # deleted, `center` merges the pair into a single value, and right/bottom
    # percentages flip to left/top with 100-n; when both offsets are
    # rewritten the two emitted values share one buffer, so `right 10%
    # bottom 20%` and `right 10% bottom 60%` both print as `90% 90%`.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


# ------------------------------------------------------- boxes and shadow


def test_margin_function_values_fold_by_equality():
    """Two equal calc() margins fold to one."""
    # CATCHES: the box-model comparison must recurse into function arguments
    # to see the two calc(1px + 1px) tokens as equal, so the four-value pair
    # collapses to a single value.
    proc = minify_css("a{margin:calc(1px + 1px) calc(1px + 1px)}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{margin:calc(1px + 1px)}"
    assert proc.stderr == b""


def test_margin_three_values_fold_to_two():
    """margin:1px 2px 1px drops the repeated third value."""
    # CATCHES: the three-value form compares the first and third values and
    # keeps only the first two when they match, exactly like the four-value
    # form does.
    proc = minify_css("a{margin:1px 2px 1px}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{margin:1px 2px}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body",
    ["a{box-shadow:0 0 red,}", "a{box-shadow:,0 0 red}"],
    ids=["trailing-comma", "leading-comma"],
)
def test_box_shadow_empty_layer_keeps_its_comma(body):
    """Empty box-shadow layers survive with their comma."""
    # CATCHES: an empty layer in a comma list is skipped, not deleted, so the
    # stray trailing or leading comma round-trips unchanged.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


def test_outline_color_is_minified():
    """A colour in the outline shorthand is shortened."""
    # CATCHES: `outline:2px dashed #ff0000` rewrites the hex to the keyword
    # red, proving the outline branch runs the shared colour minifier on its
    # colour value and not only on the `invert none medium` collapse.
    proc = minify_css("a{outline:2px dashed #ff0000}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{outline:2px dashed red}"
    assert proc.stderr == b""


# -------------------------------------------------------- colour families


def test_background_color_property_minifies_hex():
    """background-color:#ff0000 shortens to the keyword."""
    # CATCHES: the standalone background-color property runs the colour
    # minifier, giving `red` just like the color property does.
    proc = minify_css("a{background-color:#ff0000}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{background-color:red}"
    assert proc.stderr == b""


def test_border_color_with_distinct_sides_is_kept():
    """border-color:red blue keeps both values."""
    # CATCHES: the four sides differ, so the collapse-to-one-value rewrite is
    # skipped and both colours survive.
    proc = minify_css("a{border-color:red blue}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{border-color:red blue}"
    assert proc.stderr == b""


def test_border_edge_color_is_minified():
    """border-top-color shortens its hex value."""
    # CATCHES: the per-side border colour property takes the colour-minifier
    # branch (not the currentcolor-to-initial branch) and rewrites #ff0000 to
    # red.
    proc = minify_css("a{border-top-color:#ff0000}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{border-top-color:red}"
    assert proc.stderr == b""


def test_column_rule_color_is_minified():
    """A hex colour inside column-rule is shortened."""
    # CATCHES: the width and style are untouched while #ff0000 becomes red,
    # showing the colour branch of the column-rule shorthand.
    proc = minify_css("a{column-rule:3px double #ff0000}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{column-rule:3px double red}"
    assert proc.stderr == b""


def test_text_shadow_color_is_minified():
    """A hex colour inside text-shadow is shortened."""
    # CATCHES: every value of the shadow is passed through the colour
    # minifier, so the offsets stay and #ff0000 becomes red.
    proc = minify_css("a{text-shadow:1px 2px #ff0000}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{text-shadow:1px 2px red}"
    assert proc.stderr == b""


def test_text_emphasis_emptied_list_falls_back_to_none():
    """text-emphasis whose values are all removed becomes none."""
    # CATCHES: `none currentcolor` has every value stripped by the filter,
    # and the empty list is replaced by the single keyword none rather than
    # an empty declaration.
    proc = minify_css("a{text-emphasis:none currentcolor}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{text-emphasis:none}"
    assert proc.stderr == b""


# ------------------------------------------------------------------ flex


def test_flex_three_values_with_zero_basis():
    """flex:2 0 0 drops the zero basis and keeps grow and shrink."""
    # CATCHES: the two-value syntax is emitted as `2 0` because the basis is
    # zero while the shrink is not one, distinct from the `flex:2` collapse
    # that a shrink of one would trigger.
    proc = minify_css("a{flex:2 0 0}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{flex:2 0}"
    assert proc.stderr == b""


# --------------------------------------------------------- unicode-range


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{unicode-range:U+5,red}", b"a{unicode-range:U+5,red}"),
        ("a{unicode-range:U+ab-cd}", b"a{unicode-range:U+AB-CD}"),
    ],
    ids=["non-range-value", "uppercased-hex"],
)
def test_unicode_range_validation_and_hex_parsing(body, expected):
    """unicode-range rejects non-range values and uppercases hex digits."""
    # CATCHES: a non-unicode-range token inside the list aborts the whole
    # rewrite (the list is returned untouched), while a valid range with
    # lowercase hex digits is parsed and re-emitted in uppercase.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


# ----------------------------------------------------------------- units


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{margin:1PX}", b"a{margin:1px}"),
        ("a{padding:1PX 2PX}", b"a{padding:1px 2px}"),
        ("a{margin:10EM}", b"a{margin:10em}"),
    ],
    ids=["px", "px-pair", "em"],
)
def test_dimension_units_are_lowercased(body, expected):
    """Uppercase CSS units are rewritten in lowercase."""
    # CATCHES: the unit suffix is lowercased in place for every dimension
    # token, whatever the unit and however many values the list has.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


# ---------------------------------------------------- rgb / rgba handling


@pytest.mark.parametrize(
    "body",
    [
        "a{color:rgb(red,0,0)}",
        "a{color:rgb(1e40%,0%,0%)}",
        "a{color:rgb(1e400,0,0)}",
    ],
    ids=["ident-arg", "overflow-percent", "overflow-number"],
)
def test_rgb_argument_validation_failures(body):
    """Invalid rgb() arguments leave the function untouched."""
    # CATCHES: an identifier argument and float32-overflowing percentages or
    # numbers all fail validation, so the function is not converted to a hex
    # colour and round-trips unchanged.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{color:rgba(0%,20%,40%,.5)}", b"a{color:rgba(0,51,102,.5)}"),
        ("a{color:rgba(60%,80%,100%,.5)}", b"a{color:rgba(153,204,255,.5)}"),
        ("a{color:rgba(10%,20%,40%,.5)}", b"a{color:rgba(10%,20%,40%,.5)}"),
    ],
    ids=["exact-multiples", "upper-multiples", "not-multiples"],
)
def test_rgba_percent_channels_become_bytes(body, expected):
    """Percent channels that are multiples of 20% switch to 0-255 numbers."""
    # CATCHES: with a non-opaque alpha the channels 0%,20%,40% become
    # 0,51,102 and 60%,80%,100% become 153,204,255, while 10% is not a
    # multiple of 20% so the percentages are kept.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


# ------------------------------------------------------- grammar corners


def test_parenthesized_declaration_skips_property_minify():
    """A bare paren group in a value list disables property rewrites."""
    # CATCHES: `(1px) 2px` contains a parenthesis token, so the declaration
    # is treated as a complex value and no box-model folding happens.
    proc = minify_css("a{margin:(1px) 2px}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{margin:(1px) 2px}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [("@foo;", b"@foo;"), ("@media", b"@media;")],
    ids=["unknown", "known-no-block"],
)
def test_at_rule_without_block_round_trips(body, expected):
    """A blockless at-rule is emitted with its semicolon."""
    # CATCHES: an at-rule statement with no block is written back as-is, and
    # a known keyword without a block gains the trailing semicolon.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_cdo_token_is_preserved():
    """An HTML comment opener in stylesheet text is kept."""
    # CATCHES: the CDO token falls through to the default grammar branch and
    # is written verbatim after the preceding rule.
    proc = minify_css("a{color:red}<!--")
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}<!--"
    assert proc.stderr == b""


def test_nested_parens_inside_calc_round_trip():
    """Nested parentheses inside a function are tracked and preserved."""
    # CATCHES: the function parser counts nested parentheses so the inner
    # group survives with its `*2` intact.
    proc = minify_css("a{width:calc((1px + 1px)*2)}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{width:calc((1px + 1px)*2)}"
    assert proc.stderr == b""


# ---------------------------------------------------------------- guards


@pytest.mark.parametrize(
    "depth,minified",
    [(99, True), (100, False), (101, False)],
    ids=["depth-99", "depth-100", "depth-101"],
)
def test_function_nesting_depth_guard(depth, minified):
    """Minification stops recursing past one hundred nested functions."""
    # CATCHES: at 99 nested calc() calls the innermost 1.0px is still
    # shortened to 1px, but from 100 levels on the recursion guard leaves
    # the innermost number as 1.0px.
    body = "a{width:" + "calc(" * depth + "1.0px" + ")" * depth + "}"
    expected = (
        "a{width:" + "calc(" * depth + ("1px" if minified else "1.0px") + ")" * depth + "}"
    )
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected.encode()
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "none_commas,folded",
    [(50, True), (51, False)],
    ids=["hundred-tokens", "hundred-one-tokens"],
)
def test_property_value_count_guard(none_commas, folded):
    """Properties with more than one hundred tokens skip rewrites."""
    # CATCHES: fifty `none,` pairs make exactly one hundred tokens and every
    # layer still folds to `0 0`, while one more value crosses the guard and
    # the whole declaration is returned untouched.
    body = "a{background:" + "none," * none_commas + "}"
    expected = "a{background:" + ("0 0," if folded else "none,") * none_commas + "}"
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected.encode()
    assert proc.stderr == b""
