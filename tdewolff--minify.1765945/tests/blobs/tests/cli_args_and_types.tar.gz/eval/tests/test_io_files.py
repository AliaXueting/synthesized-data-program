"""Input and output plumbing: files, directories, bundles and filters.

Covers the task machinery behind the positional inputs: creating output
files (including missing parent directories), in-place minification, the
concatenating reader used by --bundle (with its JavaScript separator),
recursive directory walks with --match/--include/--exclude patterns, --sync
copies, symlink handling and the diagnostics for inputs that are neither a
file nor a directory.  All expectations were recorded from `./executable`;
when several files are minified at once the progress lines can appear in any
order (the run is parallel), so those tests compare the parsed set of lines.
"""

import os
import re
import stat as statmod

import pytest

from conftest import assert_stats_line, parse_stats_output, run_minify, write_file

CSS_A = b"a { color: red; }\n"
CSS_B = b"b { color: blue; }\n"


@pytest.fixture
def css_file(tmp_path):
    return write_file(tmp_path, "a.css", CSS_A)


@pytest.fixture
def tree(tmp_path):
    """A directory tree with visible, hidden and nested minifiable files."""
    root = tmp_path / "tree"
    root.mkdir()
    (root / "a.css").write_bytes(CSS_A)
    (root / "b.css").write_bytes(CSS_B)
    (root / "c.js").write_bytes(b"j();\n")
    (root / "d.txt").write_bytes(b"x\n")
    (root / ".hid.css").write_bytes(b"h { }\n")
    (root / ".hiddir").mkdir()
    (root / ".hiddir" / "g.css").write_bytes(b"g { }\n")
    (root / "sub").mkdir()
    (root / "sub" / "s.css").write_bytes(CSS_A)
    return root


def test_output_file_creates_missing_parent_directories(tmp_path, css_file):
    """-o may point into directories that do not exist yet."""
    # CATCHES: the output path's parent directories are created on demand, so
    # deep/nested/out.css is written and the progress line names the full
    # destination path.
    proc = run_minify(["a.css", "-o", "deep/nested/out.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    assert_stats_line(proc.stdout, "a.css", "deep/nested/out.css", "18 B", "12 B", "66.7%")
    assert (tmp_path / "deep" / "nested" / "out.css").read_bytes() == b"a{color:red}"


def test_inplace_minifies_and_prints_a_single_name(tmp_path):
    """-i rewrites the input and reports one name, not `x to y`."""
    # CATCHES: with --inplace source and destination coincide, so the progress
    # line has no ` to ` part, and the file itself now holds the minified
    # bytes.
    write_file(tmp_path, "i.css", CSS_A)
    proc = run_minify(["-i", "i.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    rows = parse_stats_output(proc.stdout)
    assert rows == [("i.css", None, "18 B", "12 B", "66.7%")]
    assert (tmp_path / "i.css").read_bytes() == b"a{color:red}"


def test_output_equal_to_input_minifies_in_place(tmp_path, css_file):
    """Naming the input as the output rewrites it without leaving a .bak."""
    # CATCHES: the binary notices the two paths name the same file, renames
    # the original to a .bak sibling while minifying, and removes it again, so
    # afterwards only the minified a.css exists.
    proc = run_minify(["a.css", "-o", "a.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    rows = parse_stats_output(proc.stdout)
    assert rows == [("a.css", None, "18 B", "12 B", "66.7%")]
    assert (tmp_path / "a.css").read_bytes() == b"a{color:red}"
    assert not (tmp_path / "a.css.bak").exists()


def test_bundle_concatenates_css_files_without_a_separator(tmp_path):
    """--bundle joins files by plain concatenation."""
    # CATCHES: CSS sources are concatenated with no separator at all, so the
    # two minified rules end up directly glued together on stdout.
    write_file(tmp_path, "a.css", CSS_A)
    write_file(tmp_path, "b.css", CSS_B)
    proc = run_minify(["--bundle", "a.css", "b.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}b{color:blue}"
    assert proc.stderr == b""


def test_bundle_to_a_file_reports_the_joined_source_names(tmp_path):
    """A bundled run names every source in parentheses in its progress line."""
    # CATCHES: the source name becomes `(a.css + b.css)` and the byte counts
    # are the totals over the concatenated stream, 37 B read and 25 B written.
    write_file(tmp_path, "a.css", CSS_A)
    write_file(tmp_path, "b.css", CSS_B)
    proc = run_minify(["--bundle", "a.css", "b.css", "-o", "bundle.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    assert_stats_line(
        proc.stdout, "(a.css + b.css)", "bundle.css", "37 B", "25 B", "67.6%"
    )
    assert (tmp_path / "bundle.css").read_bytes() == b"a{color:red}b{color:blue}"


def test_bundle_joins_javascript_files_with_a_separator(tmp_path):
    """Bundled JavaScript sources are joined with `;` so they stay valid."""
    # CATCHES: only the JavaScript mimetype gets a `;\\n` separator between
    # bundled sources; without it `var x=1` followed by `var y=2` would be the
    # syntax error `var x=1var y=2`, with it the two declarations merge into
    # one comma-separated statement.
    write_file(tmp_path, "p1.js", b"var x=1")
    write_file(tmp_path, "p2.js", b"var y=2")
    proc = run_minify(["--bundle", "p1.js", "p2.js"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b"var x=1,y=2"
    assert proc.stderr == b""


def test_bundle_of_mixed_filetypes_requires_type(tmp_path):
    """Bundling different extensions without --type fails with a warning."""
    # CATCHES: the mimetype inferred for the second source is compared with
    # the first, and a mismatch aborts the whole run with the exact WARNING
    # line and exit code 1.
    write_file(tmp_path, "a.css", CSS_A)
    write_file(tmp_path, "b.js", b"j();\n")
    proc = run_minify(["--bundle", "a.css", "b.js"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == (
        b"WARNING: inferred mimetype application/javascript of b.js"
        b" for concatenation unequal to previous mimetypes, set --type explicitly\n"
    )


def test_multiple_inputs_to_stdout_require_bundle(tmp_path):
    """Two inputs with stdout destination and no --bundle is an error."""
    # CATCHES: concatenating to stdout would interleave two documents, so the
    # binary refuses with the recorded message and exit code 1.
    write_file(tmp_path, "a.css", CSS_A)
    write_file(tmp_path, "b.css", CSS_B)
    proc = run_minify(["a.css", "b.css"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: must specify --bundle for multiple input files with stdout destination\n"


def test_bundle_with_a_directory_destination_is_rejected(tmp_path, css_file):
    """--bundle cannot write into a directory destination."""
    # CATCHES: a trailing-slash destination with --bundle is refused up front
    # with the recorded message.
    proc = run_minify(["--bundle", "a.css", "-o", "out/"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: --bundle requires destination to be stdout or a file\n"


def test_mixing_files_and_stdin_is_rejected(tmp_path, css_file):
    """A `-` among the inputs next to real files is an error."""
    # CATCHES: stdin may only appear alone; combined with file names the run
    # stops before minifying anything.
    proc = run_minify(["--type", "css", "a.css", "-"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: cannot mix files and stdin as input\n"


def test_output_to_an_existing_directory_is_an_open_error(tmp_path, css_file):
    """-o pointing at an existing directory (no slash) fails when opening."""
    # CATCHES: without a trailing slash the destination is treated as a file
    # name, and opening a directory for writing fails with the wrapped
    # `open output file` diagnostic.
    (tmp_path / "dd").mkdir()
    proc = run_minify(["a.css", "-o", "dd"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b'ERROR: open output file "dd": open dd: is a directory\n'


def test_failed_minify_still_writes_the_original_to_the_destination(tmp_path, css_file):
    """When no minifier exists the original bytes are copied to the output."""
    # CATCHES: a minifier-lookup failure does not leave the output empty; the
    # input is copied verbatim, the progress line reports a 100% ratio, and
    # the run still exits 1.
    proc = run_minify(["--type", "text/plain", "a.css", "-o", "fail.css"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stderr == b"ERROR: cannot minify a.css: minifier does not exist for mimetype\n"
    assert_stats_line(proc.stdout, "a.css", "fail.css", "18 B", "18 B", "100.0%")
    assert (tmp_path / "fail.css").read_bytes() == CSS_A


def test_stdin_to_an_output_file_warns_about_the_missing_source(tmp_path):
    """Reading stdin into a file warns that the `-` source cannot be stat'ed."""
    # CATCHES: attribute preservation stats the source path `-`, which fails,
    # so every stdin-to-file run carries this WARNING on stderr while still
    # exiting 0 and writing the minified file; -q hides the warning and the
    # progress line together.
    proc = run_minify(["--type", "css", "-o", "out.css"], stdin=CSS_A, cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b"WARNING: stat -: no such file or directory\n"
    assert_stats_line(proc.stdout, "-", "out.css", "18 B", "12 B", "66.7%")
    assert (tmp_path / "out.css").read_bytes() == b"a{color:red}"
    quiet = run_minify(["-q", "--type", "css", "-o", "out2.css"], stdin=CSS_A, cwd=tmp_path)
    assert quiet.returncode == 0
    assert quiet.stdout == b""
    assert quiet.stderr == b""
    assert (tmp_path / "out2.css").read_bytes() == b"a{color:red}"


def test_output_file_inherits_source_mode_and_timestamps(tmp_path):
    """By default the output file copies the source's mode and mtime."""
    # CATCHES: mode and timestamps are preserved even without --preserve,
    # because the option defaults to `mode timestamps` when not given.
    src = write_file(tmp_path, "a.css", CSS_A)
    os.chmod(src, 0o700)
    os.utime(src, (1577836800, 1577836800))
    proc = run_minify(["a.css", "-o", "out.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    out = tmp_path / "out.css"
    assert out.read_bytes() == b"a{color:red}"
    assert statmod.S_IMODE(os.stat(out).st_mode) == 0o700
    assert int(os.stat(out).st_mtime) == 1577836800


def test_recursive_walk_minifies_every_recognized_file(tree, tmp_path):
    """-r descends into subdirectories and skips unknown and hidden files."""
    # CATCHES: d.txt has no known extension and the dot-files are hidden, so
    # exactly a.css, b.css, c.js and sub/s.css are minified into mirrored
    # paths under the output directory, each with its recorded byte counts.
    proc = run_minify(["-r", "tree/", "-o", "out/"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    rows = sorted(parse_stats_output(proc.stdout))
    assert rows == sorted(
        [
            ("tree/a.css", "out/a.css", "18 B", "12 B", "66.7%"),
            ("tree/b.css", "out/b.css", "19 B", "13 B", "68.4%"),
            ("tree/c.js", "out/c.js", "5 B", "3 B", "60.0%"),
            ("tree/sub/s.css", "out/sub/s.css", "18 B", "12 B", "66.7%"),
        ]
    )
    assert (tmp_path / "out" / "a.css").read_bytes() == b"a{color:red}"
    assert (tmp_path / "out" / "b.css").read_bytes() == b"b{color:blue}"
    assert (tmp_path / "out" / "c.js").read_bytes() == b"j()"
    assert (tmp_path / "out" / "sub" / "s.css").read_bytes() == b"a{color:red}"
    assert not (tmp_path / "out" / "d.txt").exists()
    assert not (tmp_path / "out" / ".hid.css").exists()


def test_recursive_with_all_processes_hidden_files(tree, tmp_path):
    """-a adds hidden files and files inside hidden directories."""
    # CATCHES: without -a those files are silently skipped; with it, .hid.css
    # and .hiddir/g.css are minified as well and even shrink to 0 B, while
    # d.txt is still skipped because its extension maps to no mimetype.
    proc = run_minify(["-r", "-a", "tree/", "-o", "out/"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    rows = sorted(parse_stats_output(proc.stdout))
    assert rows == sorted(
        [
            ("tree/a.css", "out/a.css", "18 B", "12 B", "66.7%"),
            ("tree/b.css", "out/b.css", "19 B", "13 B", "68.4%"),
            ("tree/c.js", "out/c.js", "5 B", "3 B", "60.0%"),
            ("tree/.hid.css", "out/.hid.css", "6 B", "0 B", "0.0%"),
            ("tree/.hiddir/g.css", "out/.hiddir/g.css", "6 B", "0 B", "0.0%"),
            ("tree/sub/s.css", "out/sub/s.css", "18 B", "12 B", "66.7%"),
        ]
    )
    assert (tmp_path / "out" / ".hid.css").read_bytes() == b""
    assert (tmp_path / "out" / ".hiddir" / "g.css").read_bytes() == b""
    assert not (tmp_path / "out" / "d.txt").exists()


def test_directory_without_recursive_warns_and_creates_nothing(tree, tmp_path):
    """A directory input without -r only produces a warning."""
    # CATCHES: the directory is omitted with the exact WARNING line, no file
    # is minified, and the run still exits 0 having created the (empty)
    # destination directory.
    proc = run_minify(["tree/", "-o", "out/"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b""
    assert proc.stderr == b"WARNING: --recursive not specified, omitting directory tree\n"
    assert (tmp_path / "out").is_dir()
    assert list((tmp_path / "out").iterdir()) == []


def test_match_pattern_selects_files_by_basename(tree, tmp_path):
    """--match globs are matched against the file name, not its path."""
    # CATCHES: `*.css` selects every css file in the walk, while the full path
    # `tree/a.css` matches nothing at all because only the basename is tested.
    proc = run_minify(["-r", "tree/", "-o", "out/", "--match", "*.css"], cwd=tmp_path)
    assert proc.returncode == 0
    rows = sorted(parse_stats_output(proc.stdout))
    assert rows == sorted(
        [
            ("tree/a.css", "out/a.css", "18 B", "12 B", "66.7%"),
            ("tree/b.css", "out/b.css", "19 B", "13 B", "68.4%"),
            ("tree/sub/s.css", "out/sub/s.css", "18 B", "12 B", "66.7%"),
        ]
    )
    proc = run_minify(["-r", "tree/", "-o", "out2/", "--match", "tree/a.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b""
    assert proc.stderr == b""
    assert (tmp_path / "out2").is_dir()
    assert list((tmp_path / "out2").iterdir()) == []


def test_match_accepts_a_regex_after_a_tilde(tree, tmp_path):
    """A --match pattern starting with `~` is used as a raw regex."""
    # CATCHES: only `~` switches from glob to regex, so `~^c` matches the
    # basename c.js while an equivalent glob would not.
    proc = run_minify(["-r", "tree/", "-o", "out/", "--match", "~^c"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    rows = parse_stats_output(proc.stdout)
    assert rows == [("tree/c.js", "out/c.js", "5 B", "3 B", "60.0%")]


def test_exclude_glob_does_not_cross_directory_separators(tree, tmp_path):
    """`--exclude '*.js'` excludes nothing inside a walked directory."""
    # CATCHES: a single `*` in a glob stands for `[^/]*`, and the filter is
    # matched against the whole walked path `tree/c.js`, so the pattern cannot
    # match across the slash and c.js is still minified; `**` widens the glob
    # to `.*` and does exclude it.
    proc = run_minify(["-r", "tree/", "-o", "out/", "--exclude", "*.js"], cwd=tmp_path)
    assert proc.returncode == 0
    rows = sorted(parse_stats_output(proc.stdout))
    assert [row[0] for row in rows] == [
        "tree/a.css",
        "tree/b.css",
        "tree/c.js",
        "tree/sub/s.css",
    ]
    excluded = run_minify(["-r", "tree/", "-o", "out2/", "--exclude", "**.js"], cwd=tmp_path)
    assert excluded.returncode == 0
    rows2 = sorted(parse_stats_output(excluded.stdout))
    assert [row[0] for row in rows2] == ["tree/a.css", "tree/b.css", "tree/sub/s.css"]


def test_exclude_of_a_subdirectory_prefix(tree, tmp_path):
    """Excluding `tree/sub/*` drops the files inside sub but nothing else."""
    # CATCHES: the exclusion glob is anchored to the full walked path on both
    # ends, so `tree/sub/*` removes exactly sub/s.css from the task list.
    proc = run_minify(["-r", "tree/", "-o", "out/", "--exclude", "tree/sub/*"], cwd=tmp_path)
    assert proc.returncode == 0
    rows = sorted(parse_stats_output(proc.stdout))
    assert [row[0] for row in rows] == ["tree/a.css", "tree/b.css", "tree/c.js"]
    assert not (tmp_path / "out" / "sub").exists()


@pytest.mark.parametrize(
    "option", ["--match", "--include", "--exclude"], ids=["match", "include", "exclude"]
)
def test_invalid_regex_pattern_is_a_runtime_error(option, tmp_path, css_file):
    """An unparsable `~regex` filter aborts the run with the regexp error."""
    # CATCHES: the pattern is compiled after argument parsing, so the Go
    # regexp error text is printed as an ERROR line with exit code 1 and no
    # usage screen on stdout.
    proc = run_minify([option, "~[", "a.css"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: error parsing regexp: missing closing ]: `[`\n"


def test_sync_copies_files_that_cannot_be_minified(tree, tmp_path):
    """--sync copies unknown-extension files verbatim and minifies the rest."""
    # CATCHES: without -v the copies are silent; with -v each copied file gets
    # an `INFO: copy` line on stderr and, because verbose forces sequential
    # processing, the progress lines come out in walk order.
    proc = run_minify(["-r", "--sync", "tree/", "-o", "out/"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    assert (tmp_path / "out" / "d.txt").read_bytes() == b"x\n"
    assert (tmp_path / "out" / "a.css").read_bytes() == b"a{color:red}"
    verbose = run_minify(["-r", "--sync", "-v", "tree/", "-o", "out2/"], cwd=tmp_path)
    assert verbose.returncode == 0
    assert re.fullmatch(
        rb"INFO: copy tree/d\.txt to out2/d\.txt\n" rb"INFO: finished in \S+\n",
        verbose.stderr,
    )
    rows = parse_stats_output(verbose.stdout)
    assert rows == [
        ("tree/a.css", "out2/a.css", "18 B", "12 B", "66.7%"),
        ("tree/b.css", "out2/b.css", "19 B", "13 B", "68.4%"),
        ("tree/c.js", "out2/c.js", "5 B", "3 B", "60.0%"),
        ("tree/sub/s.css", "out2/sub/s.css", "18 B", "12 B", "66.7%"),
    ]


def test_sync_cannot_be_combined_with_type(tmp_path, css_file):
    """--sync and --type are mutually exclusive."""
    # CATCHES: with a mimetype given there is nothing left to infer per file,
    # so the binary refuses the combination with the recorded message.
    proc = run_minify(["--sync", "--type", "css", "a.css", "-o", "out/"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: must specify either --sync or --type\n"


def test_symlink_input_is_dereferenced_by_default(tmp_path, css_file):
    """A symlink to a file is followed and its target minified."""
    # CATCHES: without --preserve links the target's content is what gets
    # minified, and the symlink itself is left untouched.
    (tmp_path / "link.css").symlink_to(tmp_path / "a.css")
    proc = run_minify(["link.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b""
    assert (tmp_path / "link.css").is_symlink()


def test_preserve_links_without_sync_is_an_error(tmp_path, css_file):
    """--preserve links refuses to do anything with a symlink unless --sync."""
    # CATCHES: copying a symlink somewhere else only makes sense in sync mode,
    # so without it the run stops with the exact error naming the link.
    (tmp_path / "link.css").symlink_to(tmp_path / "a.css")
    proc = run_minify(["--preserve", "links", "link.css"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: --sync not specified, omitting symbolic link link.css\n"


def test_sync_and_preserve_links_copies_the_symlink_itself(tmp_path, css_file):
    """--sync --preserve links recreates the symlink at the destination."""
    # CATCHES: the copy is a brand new symlink pointing at the same target
    # (readlink shows the recorded a.css), created silently with no progress
    # line, while the regular file next to it is minified normally.
    os.symlink("a.css", tmp_path / "link.css")
    proc = run_minify(
        ["--preserve", "links", "--sync", "a.css", "link.css", "-o", "out/"], cwd=tmp_path
    )
    assert proc.returncode == 0
    assert proc.stderr == b""
    rows = parse_stats_output(proc.stdout)
    assert rows == [("a.css", "out/a.css", "18 B", "12 B", "66.7%")]
    assert (tmp_path / "out" / "link.css").is_symlink()
    assert os.readlink(tmp_path / "out" / "link.css") == "a.css"


def test_dangling_symlink_is_reported_but_not_fatal(tmp_path):
    """A symlink whose target is gone logs a stat error and exits 0."""
    # CATCHES: the failing input is skipped with an ERROR line but does not
    # change the exit code, and nothing is written to stdout.
    (tmp_path / "dang.css").symlink_to(tmp_path / "nowhere.css")
    proc = run_minify(["dang.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: stat dang.css: no such file or directory\n"


def test_directory_symlink_is_descended_into(tree, tmp_path):
    """A symlink to a directory is followed during a recursive walk."""
    # CATCHES: the walk dereferences the symlink and reports the files under
    # the link's own path, so the destination keeps the tlink/ prefix.
    (tmp_path / "tlink").symlink_to(tmp_path / "tree")
    proc = run_minify(["-r", "tlink/", "-o", "out/"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    rows = sorted(parse_stats_output(proc.stdout))
    assert rows == sorted(
        [
            ("tlink/a.css", "out/a.css", "18 B", "12 B", "66.7%"),
            ("tlink/b.css", "out/b.css", "19 B", "13 B", "68.4%"),
            ("tlink/c.js", "out/c.js", "5 B", "3 B", "60.0%"),
            ("tlink/sub/s.css", "out/sub/s.css", "18 B", "12 B", "66.7%"),
        ]
    )


def test_fifo_input_is_neither_file_nor_directory(tmp_path):
    """A named pipe as input is rejected with the not-a-file diagnostic."""
    # CATCHES: anything that is not a regular file or a directory (here a
    # FIFO) makes task creation fail with exit code 1; the binary never
    # blocks trying to open the pipe.
    os.mkfifo(tmp_path / "pipe")
    proc = run_minify(["pipe", "-o", "pipe.out"], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: not a file or directory pipe\n"


def test_missing_input_files_are_skipped_not_fatal(tmp_path):
    """A nonexistent input is reported and dropped; the rest still minifies."""
    # CATCHES: the stat failure only logs an ERROR line and skips that input,
    # so the surviving file is still bundled to stdout and the run exits 0
    # rather than treating the missing file as fatal.
    write_file(tmp_path, "a.css", CSS_A)
    proc = run_minify(["--bundle", "a.css", "missing.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b"ERROR: stat missing.css: no such file or directory\n"


def test_verbose_runs_multiple_tasks_in_input_order(tmp_path):
    """With -vv several files are processed sequentially, in list order."""
    # CATCHES: verbose mode disables the parallel workers, so the two progress
    # lines always come out in input order, and the DEBUG lines record the
    # inferred mimetype and the output-directory destination.
    write_file(tmp_path, "a.css", CSS_A)
    write_file(tmp_path, "b.css", CSS_B)
    proc = run_minify(["-vv", "a.css", "b.css", "-o", "out/"], cwd=tmp_path)
    assert proc.returncode == 0
    rows = parse_stats_output(proc.stdout)
    assert rows == [
        ("a.css", "out/a.css", "18 B", "12 B", "66.7%"),
        ("b.css", "out/b.css", "19 B", "13 B", "68.4%"),
    ]
    assert re.fullmatch(
        rb"DEBUG: infer mimetype from file extensions\n"
        rb"DEBUG: minify to output directory out/\n"
        rb"INFO: finished in \S+\n",
        proc.stderr,
    )
