"""HTML minifier option handling, tag/attribute normalization and embedding.

Every expectation in this module was recorded by running the reference binary
with --type html on the exact input shown and capturing its stdout/stderr, so
the tests pin the black-box behaviour of the html, html/hash and minify/v2
packages: comment and whitespace policies, document/end-tag omission, default
attribute values, attribute quoting rules, mimetype routing for embedded CSS,
JS, JSON, SVG and MathML, data-URI and --url rewriting, and the error paths.
"""

import pytest

from conftest import USAGE, run_minify


def run_html(body, *flags):
    """Run the reference with --type html over body and return the result."""
    if isinstance(body, str):
        body = body.encode()
    return run_minify(["--type", "html", *flags], stdin=body)


def test_doctype_is_normalized_to_plain_html5():
    """A long legacy doctype is rewritten to the bare `<!doctype html>`."""
    # CATCHES: a reimplementation that preserves the public/system identifiers
    # or keeps the uppercase spelling would emit different bytes here.
    proc = run_html(
        b'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" '
        b'"http://www.w3.org/TR/html4/strict.dtd"><p>a'
    )
    assert proc.returncode == 0
    assert proc.stdout == b"<!doctype html><p>a"


def test_doctype_is_kept_when_it_applies_midway():
    """A doctype token after content is still emitted, not dropped."""
    # CATCHES: the reference normalizes doctypes wherever they appear; one that
    # only handles a leading doctype would lose it from the output.
    proc = run_html(b"<p>a</p><!doctype html>")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a</p><!doctype html>"


def test_comments_are_removed_by_default():
    """An ordinary comment and everything in it disappears by default."""
    # CATCHES: a reimplementation that keeps comments, or keeps an empty
    # placeholder, changes the output bytes.
    proc = run_html(b"<!-- hello --><p>a")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a"


@pytest.mark.parametrize(
    "body",
    [b"<!----><p>a", b"<!--! keep --><p>a", b"<? bogus ?><p>a"],
)
def test_degenerate_comments_are_removed(body):
    """Empty, bang-prefixed and bogus comments are all dropped."""
    # CATCHES: the `<!--!`-style and `<?`-style leftovers must be treated as
    # comments and removed, not passed through to the output.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a"


def test_keep_comments_flag_preserves_every_comment():
    """--html-keep-comments writes the comment tokens out verbatim."""
    # CATCHES: a reimplementation that re-serializes comments (e.g. trims
    # inner whitespace or rewrites the delimiters) differs from the reference.
    proc = run_html(b"<!-- hello --><p>a", "--html-keep-comments")
    assert proc.returncode == 0
    assert proc.stdout == b"<!-- hello --><p>a"


def test_conditional_comments_are_removed_by_default():
    """A downlevel-hidden IE conditional comment is dropped entirely."""
    # CATCHES: the whole `<!--[if ...]>...<![endif]-->` block including the
    # inner markup must vanish when no keep flag is given.
    proc = run_html(b"<!--[if lt IE 9]><p>a<![endif]--><p>b")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>b"


@pytest.mark.parametrize(
    "flag",
    ["--html-keep-comments", "--html-keep-special-comments"],
)
def test_conditional_comments_survive_the_keep_flags(flag):
    """Both keep flags preserve a downlevel-hidden conditional comment."""
    # CATCHES: the two flags overlap for this input; a reimplementation that
    # only handles one of them, or reorders the inner markup, differs.
    proc = run_html(b"<!--[if lt IE 9]><p>a<![endif]--><p>b", flag)
    assert proc.returncode == 0
    assert proc.stdout == b"<!--[if lt IE 9]><p>a<![endif]--><p>b"


def test_downlevel_revealed_comment_is_removed_by_default():
    """A bare `<!--<![endif]-->` marker counts as a removable comment."""
    # CATCHES: downlevel-revealed fragments must follow the same removal rule
    # as normal comments even though they are not well-formed comments.
    proc = run_html(b"<!--<![endif]--><p>a")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a"


def test_keep_special_comments_preserves_downlevel_revealed():
    """--html-keep-special-comments keeps the downlevel-revealed marker."""
    # CATCHES: only the special-comments flag (not plain keep-comments rules
    # for ordinary comments) applies to this shape; both spellings differ.
    proc = run_html(b"<!--<![endif]--><p>a", "--html-keep-special-comments")
    assert proc.returncode == 0
    assert proc.stdout == b"<!--<![endif]--><p>a"


def test_keep_special_comments_preserves_ssi_directives():
    """Comments starting with `#` (SSI directives) survive the flag."""
    # CATCHES: the SSI branch is keyed on the leading hash, so a reimplementation
    # that only looks for `[if`/`[endif]` markers loses this directive.
    proc = run_html(b'<!--# echo var="x" --><p>a', "--html-keep-special-comments")
    assert proc.returncode == 0
    assert proc.stdout == b'<!--# echo var="x" --><p>a'


def test_deprecated_conditional_flag_prints_a_notice_and_keeps():
    """--html-keep-conditional-comments prints a deprecation notice first."""
    # CATCHES: the deprecated alias still enables the behaviour but writes a
    # notice line to stdout before the minified document; both must be exact.
    proc = run_html(
        b"<!--[if lt IE 9]><p>a<![endif]--><p>b",
        "--html-keep-conditional-comments",
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b"DEPRECATED: KeepConditionalComments is replaced by KeepSpecialComments\n"
        b"<!--[if lt IE 9]><p>a<![endif]--><p>b"
    )
    assert proc.stderr == b""


def test_deprecated_notice_survives_quiet_mode():
    """-q does not suppress the deprecation notice on stdout."""
    # CATCHES: the notice is printed unconditionally by the flag handler, so a
    # reimplementation that routes it through the quiet-aware logger differs.
    proc = run_html(b"<p>a", "--html-keep-conditional-comments", "-q")
    assert proc.returncode == 0
    assert proc.stdout == (
        b"DEPRECATED: KeepConditionalComments is replaced by KeepSpecialComments\n<p>a"
    )


def test_multiple_spaces_in_text_collapse_to_one():
    """Runs of spaces inside a text node collapse to a single space."""
    # CATCHES: a reimplementation that leaves interior whitespace alone, or
    # removes it entirely instead of collapsing, differs on this input.
    proc = run_html(b"<p>a  b</p>")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a b"


def test_text_is_trimmed_inside_block_elements():
    """Leading and trailing whitespace of text in a block is removed."""
    # CATCHES: only the outer edges of the text node are trimmed; the single
    # interior space between `a` and `b` must survive.
    proc = run_html(b"<div>  a  b  </div>")
    assert proc.returncode == 0
    assert proc.stdout == b"<div>a b</div>"


@pytest.mark.parametrize(
    "body",
    [b"<span>a</span> <span>b</span>", b"<i>a</i> <i>b</i>", b"a <code>x</code> b"],
)
def test_whitespace_around_phrasing_content_is_kept(body):
    """Spaces between inline-level elements are significant and preserved."""
    # CATCHES: collapsing whitespace between phrasing tags would join words in
    # the rendered document, so the reference keeps a single space.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == body


def test_newlines_around_block_elements_are_removed():
    """Indentation newlines between blocks disappear entirely."""
    # CATCHES: a reimplementation that collapses but does not trim between
    # block tags would emit a stray space or newline before each `<p>`.
    proc = run_html(b"<div>\n  <p>x</p>\n  <p>y</p>\n</div>")
    assert proc.returncode == 0
    assert proc.stdout == b"<div><p>x<p>y</div>"


def test_keep_whitespace_flag_preserves_edge_whitespace():
    """--html-keep-whitespace keeps single edge spaces but still collapses."""
    # CATCHES: the flag is not a full passthrough: `a  b` still collapses to
    # `a b` while the trimmed edges around it are restored.
    proc = run_html(b"<div>  a  b  </div>", "--html-keep-whitespace")
    assert proc.returncode == 0
    assert proc.stdout == b"<div> a b </div>"


def test_whitespace_between_block_siblings_is_removed():
    """A text node of pure whitespace between block tags vanishes."""
    # CATCHES: `<p>a</p> <p>b</p>` must not keep the separating space, unlike
    # the phrasing-content case where the space is significant.
    proc = run_html(b"<p>a</p> \n <p>b</p>")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a<p>b"


@pytest.mark.parametrize(
    "body",
    [
        b"<pre>  a\n b  </pre>",
        b"<textarea>  a  </textarea>",
    ],
)
def test_pre_and_textarea_content_is_verbatim(body):
    """Raw-text elements keep their content byte-for-byte."""
    # CATCHES: whitespace is significant inside pre/textarea, so any collapsing
    # or trimming there would corrupt the document.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == body


def test_document_edge_whitespace_is_removed():
    """Whitespace surrounding the whole document is dropped."""
    # CATCHES: leading indentation and the trailing newline after the last tag
    # are both outside any element and must not survive.
    proc = run_html(b"  \n <p>a</p> \n ")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a"


@pytest.mark.parametrize(
    "body,expected",
    [(b"<div>a</div> b", b"<div>a</div>b"), (b"a <div>b</div>", b"a<div>b</div>")],
)
def test_spaces_adjacent_to_block_tags_are_trimmed(body, expected):
    """A space right after or right before a block-level tag is removed."""
    # CATCHES: the reference decides per-boundary using the block trait, so a
    # blanket keep-or-drop rule gets one of the two cases wrong.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_trailing_space_is_trimmed_after_at_most_100_end_tags():
    """The whitespace lookahead gives up after 100 tokens but still trims."""
    # CATCHES: the reference caps its lookahead at 100 tokens to bound runtime;
    # exactly 100 non-blocking end tags still reach EOF and trim the space.
    proc = run_html(b"<div>a " + b"</i>" * 100)
    assert proc.returncode == 0
    assert proc.stdout == b"<div>a" + b"</i>" * 100


def test_trailing_space_survives_beyond_100_end_tags():
    """With 101 following end tags the lookahead cap keeps the space."""
    # CATCHES: this is the boundary of the 100-token guard: one more end tag
    # and the trailing space is no longer trimmed.
    proc = run_html(b"<div>a " + b"</i>" * 101)
    assert proc.returncode == 0
    assert proc.stdout == b"<div>a " + b"</i>" * 101


def test_removed_comment_does_not_space_adjacent_texts():
    """A comment between two words leaves no gap behind."""
    # CATCHES: the words around a removed comment must be joined without any
    # inserted separator, exactly as if the comment were never there.
    proc = run_html(b"<p>a<!-- c -->b</p>")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>ab"


@pytest.mark.parametrize(
    "body",
    [b"a &amp; b", b"a &#38; b", b"a &#x26; b"],
)
def test_entities_are_decoded_in_text_when_shorter(body):
    """Named, decimal and hex ampersand entities all decode to a bare `&`."""
    # CATCHES: the reference only rewrites an entity when the decoded form is
    # not longer, and must handle all three syntaxes identically.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == b"a & b"


def test_lt_is_reescaped_but_gt_is_emitted_raw():
    """`&lt;` stays escaped while `&gt;` may safely become a literal `>`."""
    # CATCHES: the output text is re-escaped selectively; a reimplementation
    # that escapes both or neither produces different bytes.
    proc = run_html(b"&lt;b&gt;")
    assert proc.returncode == 0
    assert proc.stdout == b"&lt;b>"


def test_nbsp_round_trips_through_its_named_entity():
    """A non-breaking space is re-encoded as `&nbsp;`, not as UTF-8 bytes."""
    # CATCHES: the text re-encoding table maps the decoded codepoint back to
    # the named entity, keeping the document ASCII where possible.
    proc = run_html(b"a&nbsp;b")
    assert proc.returncode == 0
    assert proc.stdout == b"a&nbsp;b"


def test_hellip_is_shortened_to_the_mldr_entity():
    """`&hellip;` is rewritten to the shorter synonym `&mldr;`."""
    # CATCHES: the reverse-entity table prefers the shortest name, so
    # `&copy;` is untouched while `&hellip;` shrinks.
    proc = run_html(b"&copy;&hellip;")
    assert proc.returncode == 0
    assert proc.stdout == b"&copy;&mldr;"


def test_numeric_character_references_stay_numeric():
    """Numeric references that decode to multi-byte runes are left as-is."""
    # CATCHES: re-encoding `&#8216;` as a named entity or raw UTF-8 would be
    # longer, so the reference keeps the numeric spelling.
    proc = run_html(b"<p>&#8216;q&#8217;</p>")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>&#8216;q&#8217;"


def test_unknown_entities_are_left_alone():
    """An entity-like sequence that is not in the table is untouched."""
    # CATCHES: a reimplementation that strips the trailing semicolon or drops
    # the sequence entirely corrupts the visible text.
    proc = run_html(b"a &nosuchentity; b")
    assert proc.returncode == 0
    assert proc.stdout == b"a &nosuchentity; b"


def test_document_tags_are_stripped_by_default():
    """html, head and body tags are removed, keeping only real content."""
    # CATCHES: the title inside head survives while all three document
    # wrappers disappear, including the end tags.
    proc = run_html(b"<html><head><title>t</title></head><body><p>a</p></body></html>")
    assert proc.returncode == 0
    assert proc.stdout == b"<title>t</title><p>a"


def test_keep_document_tags_flag_preserves_the_wrappers():
    """--html-keep-document-tags keeps html/head/body even when empty."""
    # CATCHES: the flag restores all three wrappers; `</p>` before `</body>`
    # is still omitted because that rule is governed by --html-keep-end-tags.
    proc = run_html(
        b"<html><head><title>t</title></head><body><p>a</p></body></html>",
        "--html-keep-document-tags",
    )
    assert proc.returncode == 0
    assert proc.stdout == b"<html><head><title>t</title></head><body><p>a</body></html>"


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<html lang="en"><p>a</p></html>',
            b"<html lang=en><p>a",
        ),
        (
            b'<body class="x"><p>a</p></body>',
            b"<body class=x><p>a",
        ),
    ],
)
def test_document_tags_with_attributes_are_kept(body, expected):
    """html/body tags carrying attributes survive the stripping rule."""
    # CATCHES: only the attribute-less wrappers are dropped, so `lang=en` on
    # html or `class=x` on body keeps the tag (and drops its end tag).
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_list_item_end_tags_are_omitted():
    """`</li>` before the next `<li>` or the list end is removed."""
    # CATCHES: a reimplementation that keeps list item end tags, or also drops
    # the `</ul>`, differs on these bytes.
    proc = run_html(b"<ul><li>a</li><li>b</li></ul>")
    assert proc.returncode == 0
    assert proc.stdout == b"<ul><li>a<li>b</ul>"


def test_keep_end_tags_flag_preserves_every_end_tag():
    """--html-keep-end-tags disables all end-tag omission."""
    # CATCHES: with the flag set the input is reproduced exactly, proving the
    # omission logic is entirely behind the flag.
    proc = run_html(b"<ul><li>a</li><li>b</li></ul>", "--html-keep-end-tags")
    assert proc.returncode == 0
    assert proc.stdout == b"<ul><li>a</li><li>b</li></ul>"


def test_table_end_tags_are_omitted():
    """thead/tr/th/tbody/td end tags all disappear, `</table>` stays."""
    # CATCHES: the table section end tags are dropped even across sections
    # (`</thead>` before `<tbody>`), while the outer `</table>` remains.
    proc = run_html(
        b"<table><thead><tr><th>a</th></tr></thead><tbody><tr><td>b</td></tr></tbody></"
        b"table>",
    )
    assert proc.returncode == 0
    assert proc.stdout == b"<table><thead><tr><th>a<tbody><tr><td>b</table>"


@pytest.mark.parametrize(
    "body,expected",
    [
        (b"<p>a</p><div>b</div>", b"<p>a<div>b</div>"),
        (b"<p>a</p><h1>b</h1>", b"<p>a<h1>b</h1>"),
        (b"<p>a</p><p>b</p>", b"<p>a<p>b"),
        (b"<p>a</p>b", b"<p>a</p>b"),
        (b"<p>a</p><span>b</span>", b"<p>a</p><span>b</span>"),
        (b"<p>a</p><!-- c --><div>b</div>", b"<p>a</p><div>b</div>"),
        (b"<p>a</p>", b"<p>a"),
    ],
)
def test_p_end_tag_omission_depends_on_the_follower(body, expected):
    """`</p>` is dropped only before block-level tags or end of input."""
    # CATCHES: a follower that is text or phrasing content keeps `</p>`; a
    # comment is transparent, so the div behind it still triggers omission.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_select_and_option_text_and_end_tags():
    """Options lose their end tags and the whitespace between them."""
    # CATCHES: text directly inside `<select>` is skipped as inter-option
    # whitespace, and each `</option>` is dropped before the next option.
    proc = run_html(b"<select><option>a</option><option>b</option></select>")
    assert proc.returncode == 0
    assert proc.stdout == b"<select><option>a<option>b</select>"


def test_optgroup_end_tag_is_omitted_before_the_next_optgroup():
    """`</optgroup>` disappears while `</option>` also stays omitted."""
    # CATCHES: the optgroup rule looks ahead past option tags; a reimplementation
    # that closes the group early or keeps the end tag differs.
    proc = run_html(
        b"<select><optgroup><option>a</option></optgroup>"
        b"<optgroup><option>b</option></optgroup></select>"
    )
    assert proc.returncode == 0
    assert proc.stdout == b"<select><optgroup><option>a<optgroup><option>b</select>"


@pytest.mark.parametrize(
    "body,expected",
    [
        (b"<dl><dt>a</dt><dd>b</dd></dl>", b"<dl><dt>a<dd>b</dl>"),
        (
            b"<ruby>a<rp>(</rp><rt>b</rt><rp>)</rp></ruby>",
            b"<ruby>a<rp>(<rt>b<rp>)</ruby>",
        ),
    ],
)
def test_description_list_and_ruby_end_tags_are_omitted(body, expected):
    """dt/dd and rp/rt end tags follow the same omission rules as li."""
    # CATCHES: the omission list covers the rarely used ruby and definition
    # list elements, not just the common table and list tags.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_template_content_keeps_its_end_tags():
    """Inside `<template>` end-tag omission is switched off."""
    # CATCHES: template contents are inert script-like data, so the reference
    # keeps `</p>` and `</li>` there even though it would omit them outside.
    proc = run_html(b"<template><p>a</p><li>b</li></template>")
    assert proc.returncode == 0
    assert proc.stdout == b"<template><p>a</p><li>b</li></template>"


def test_colgroup_without_attributes_is_removed():
    """An empty `<colgroup>` wrapper is dropped from the table."""
    # CATCHES: colgroup is on the superfluous-tag list together with the
    # document tags, so only an attribute-less occurrence disappears.
    proc = run_html(b"<table><colgroup></colgroup><tr><td>a</td></tr></table>")
    assert proc.returncode == 0
    assert proc.stdout == b"<table><tr><td>a</table>"


@pytest.mark.parametrize(
    "body,expected",
    [
        (b'<input disabled="">', b"<input disabled>"),
        (b'<input disabled="disabled">', b"<input disabled>"),
        (b'<input disabled="x">', b"<input disabled>"),
        (b"<input disabled>", b"<input disabled>"),
        (b'<foo disabled="">y</foo>', b"<foo disabled>y</foo>"),
    ],
)
def test_boolean_attribute_values_are_dropped(body, expected):
    """A boolean attribute never keeps an `=value` part, on any tag."""
    # CATCHES: even a non-canonical value like `disabled="x"` collapses to the
    # bare attribute, and unknown tags follow the same rule.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<input hidden="">',
            b"<input hidden>",
        ),
        (
            b'<input hidden="hidden">',
            b"<input hidden=hidden>",
        ),
    ],
)
def test_hidden_is_not_treated_as_a_boolean_attribute(body, expected):
    """`hidden` only trims: `hidden="hidden"` keeps its redundant value."""
    # CATCHES: the reference has not marked hidden as boolean, so unlike
    # `disabled` the canonical value form is preserved verbatim.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<table><tr><td colspan="one">a</td></tr></table>',
            b"<table><tr><td>a</table>",
        ),
        (
            b'<table><tr><td colspan="1">a</td></tr></table>',
            b"<table><tr><td colspan=1>a</table>",
        ),
        (
            b'<table><tr><td colspan="2">a</td></tr></table>',
            b"<table><tr><td colspan=2>a</table>",
        ),
    ],
)
def test_colspan_is_compared_against_the_word_one(body, expected):
    """Only the literal value `one` counts as the default for colspan."""
    # CATCHES: the reference compares against the string `one` rather than
    # `1`, so `colspan="1"` survives while `colspan="one"` is removed.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_keep_default_attrvals_disables_the_one_comparison():
    """--html-keep-default-attrvals keeps even `rowspan=one`."""
    # CATCHES: the odd string comparison sits behind the same flag as the
    # ordinary default-value removals.
    proc = run_html(
        b'<table><tr><td rowspan="one">a</td></tr></table>',
        "--html-keep-default-attrvals",
    )
    assert proc.returncode == 0
    assert proc.stdout == b"<table><tr><td rowspan=one>a</table>"


def test_input_type_text_and_empty_value_are_removed():
    """`type=text` and an empty `value` both collapse `<input>` to bare."""
    # CATCHES: the type comparison is case-insensitive and the empty value
    # rule applies to non-radio inputs only.
    proc = run_html(b'<input type="TEXT" value="">')
    assert proc.returncode == 0
    assert proc.stdout == b"<input>"


def test_input_radio_value_on_is_removed():
    """For radio inputs the value `on` is the removable default."""
    # CATCHES: the radio case checks for the string `on`, not emptiness, so
    # `value=on` disappears while the type itself is kept.
    proc = run_html(b'<input type="radio" value="on">')
    assert proc.returncode == 0
    assert proc.stdout == b"<input type=radio>"


def test_radio_value_on_is_not_a_default_attrval():
    """--html-keep-default-attrvals does not rescue radio `value=on`."""
    # CATCHES: the radio rule lives outside the KeepDefaultAttrVals gate, so
    # the flag keeps `type=radio` but still drops the value.
    proc = run_html(b'<input type="radio" value="on">', "--html-keep-default-attrvals")
    assert proc.returncode == 0
    assert proc.stdout == b"<input type=radio>"


@pytest.mark.parametrize(
    "body,flags,expected",
    [
        (b'<button type="submit">Go</button>', [], b"<button>Go</button>"),
        (
            b'<button type="submit">Go</button>',
            ["--html-keep-default-attrvals"],
            b"<button type=submit>Go</button>",
        ),
        (b'<button type="button">Go</button>', [], b'<button type=button>Go</button>'),
    ],
)
def test_button_submit_type_is_removed_unless_flag(body, flags, expected):
    """`type=submit` is the default for buttons; other types are kept."""
    # CATCHES: only the submit default is removed, and only without
    # --html-keep-default-attrvals.
    proc = run_html(body, *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,flags,expected",
    [
        (b'<form method="GET" action=""></form>', [], b"<form></form>"),
        (
            b'<form method="GET" action=""></form>',
            ["--html-keep-default-attrvals"],
            b"<form method=GET></form>",
        ),
        (b'<area shape="RECT" coords="1,2,3">', [], b"<area coords=1,2,3>"),
        (
            b'<area shape="RECT" coords="1,2,3">',
            ["--html-keep-default-attrvals"],
            b"<area shape=RECT coords=1,2,3>",
        ),
    ],
)
def test_method_and_shape_defaults_are_removed_unless_flag(body, flags, expected):
    """`method=GET` and `shape=RECT` are case-insensitive defaults."""
    # CATCHES: both comparisons ignore case, and an empty form action is
    # dropped as an empty-value attribute regardless of the flag.
    proc = run_html(body, *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_anchor_name_is_dropped_when_equal_to_id():
    """`<a name=x id=x>` keeps only the id attribute."""
    # CATCHES: the name attribute is redundant with a matching id; with
    # differing values both attributes must survive.
    proc = run_html(b'<a id="x" name="x">a</a>')
    assert proc.returncode == 0
    assert proc.stdout == b"<a id=x>a</a>"


def test_anchor_name_is_kept_when_different_from_id():
    """A name that does not match the id is preserved."""
    # CATCHES: the removal is an equality check, not a blanket drop of name
    # attributes on anchors.
    proc = run_html(b'<a id="x" name="y">a</a>')
    assert proc.returncode == 0
    assert proc.stdout == b'<a id=x name=y>a</a>'


@pytest.mark.parametrize(
    "body,flags,expected",
    [
        (
            b'<style media="all">a{color:red}</style>',
            [],
            b"<style>a{color:red}</style>",
        ),
        (
            b'<style media="all">a{color:red}</style>',
            ["--html-keep-default-attrvals"],
            b'<style media=all>a{color:red}</style>',
        ),
        (
            b'<style media="print">a{color:red}</style>',
            [],
            b'<style media=print>a{color:red}</style>',
        ),
    ],
)
def test_style_media_all_is_removed_unless_flag(body, flags, expected):
    """`media=all` is the default for style elements, `print` is not."""
    # CATCHES: the media default only applies to the style tag and only to
    # the exact (case-insensitive) value `all`.
    proc = run_html(body, *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<script src="x.js" charset="utf-8"></script>',
            b"<script src=x.js></script>",
        ),
        (
            b'<script charset="utf-8">a=1</script>',
            b"<script charset=utf-8>a=1</script>",
        ),
        (
            b'<script src="x.js" type="text/javascript" charset="utf-8"></script>',
            b"<script src=x.js></script>",
        ),
    ],
)
def test_script_charset_is_removed_only_alongside_src(body, expected):
    """A script charset goes away only when a src attribute is present."""
    # CATCHES: the removal needs both attributes; the third case shows the
    # js mimetype `type` is dropped at the same time.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,flags,expected",
    [
        (
            b'<link rel="stylesheet" type="text/css" href="a.css">',
            [],
            b"<link rel=stylesheet href=a.css>",
        ),
        (
            b'<link rel="stylesheet" type="text/css" href="a.css">',
            ["--html-keep-default-attrvals"],
            b'<link rel=stylesheet type=text/css href=a.css>',
        ),
    ],
)
def test_link_css_type_is_removed_unless_flag(body, flags, expected):
    """`type=text/css` is the default for stylesheet links."""
    # CATCHES: the removal is specific to the link tag and gated by the flag.
    proc = run_html(body, *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<div class="">a</div>',
            b"<div>a</div>",
        ),
        (
            b'<div id="">a</div>',
            b"<div>a</div>",
        ),
        (
            b'<div style="color:red" class="">a</div>',
            b'<div style=color:red>a</div>',
        ),
    ],
)
def test_empty_class_and_id_are_removed(body, expected):
    """Empty class/id attributes are omitted entirely."""
    # CATCHES: the empty-value omission list covers class/dir/id/name (and
    # form action), while other attributes collapse to their bare name.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<img src=a.png alt="">',
            b"<img src=a.png alt>",
        ),
        (
            b'<div lang="">a</div>',
            b"<div lang>a</div>",
        ),
        (
            b"<a href>a</a>",
            b"<a href>a</a>",
        ),
    ],
)
def test_other_empty_attributes_collapse_to_bare_names(body, expected):
    """alt/lang without a value stay present but lose the `=`."""
    # CATCHES: outside the omit-list, an empty value still writes the
    # attribute name without a value part.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,expected",
    [
        (b'<input disabled="x">', b"<input disabled>"),
        (b'<input hidden="hidden">', b"<input hidden=hidden>"),
        (b'<input type="text" value="">', b'<input type=text>'),
        (b'<form method="GET" action=""></form>', b"<form method=GET></form>"),
        (
            b'<style media="all">a{color:red}</style>',
            b'<style media=all>a{color:red}</style>',
        ),
        (
            b'<link rel="stylesheet" type="text/css" href="a.css">',
            b'<link rel=stylesheet type=text/css href=a.css>',
        ),
        (b'<button type="submit">Go</button>', b'<button type=submit>Go</button>'),
        (b'<area shape="RECT" coords="1,2,3">', b'<area shape=RECT coords=1,2,3>'),
    ],
)
def test_keep_default_attrvals_flag_matrix(body, expected):
    """--html-keep-default-attrvals restores every dropped default value."""
    # CATCHES: with the flag set all default-value removals are disabled while
    # unrelated rules (quoting, case folding) keep applying.
    proc = run_html(body, "--html-keep-default-attrvals")
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_class_whitespace_is_collapsed_and_trimmed():
    """class values collapse internal runs and lose edge whitespace."""
    # CATCHES: class is a trimming attribute: ` a   b ` becomes `a b`, quoted
    # only because the surviving space forces quoting.
    proc = run_html(b'<div class=" a   b ">a</div>')
    assert proc.returncode == 0
    assert proc.stdout == b'<div class="a b">a</div>'


@pytest.mark.parametrize(
    "body",
    [
        b'<div id=" a ">a</div>',
        b'<div title=" a  b ">a</div>',
        b'<div title="  x  ">a</div>',
    ],
)
def test_id_and_title_are_not_trimmed(body):
    """id and title values keep their whitespace verbatim."""
    # CATCHES: only some attributes are trimming ones; id and title keep even
    # leading/trailing spaces, forcing a quoted output.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == body


@pytest.mark.parametrize(
    "body,expected",
    [
        (b"<div title='a\"b'>x</div>", b'<div title=\'a"b\'>x</div>'),
        (b'<div title="a\'b">x</div>', b'<div title="a\'b">x</div>'),
        (b'<div title="a&apos;b">x</div>', b'<div title="a\'b">x</div>'),
        (b"<div title='a&quot;b'>x</div>", b'<div title=\'a"b\'>x</div>'),
    ],
)
def test_quote_character_is_chosen_to_avoid_escaping(body, expected):
    """The output picks the quote character not present in the value."""
    # CATCHES: an entity-encoded quote is decoded first and then determines
    # the quoting; no `&#34;`/`&#39;` escape is produced for a lone quote.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,expected",
    [
        (b'<div title="a b">x</div>', b'<div title="a b">x</div>'),
        (b'<div title="a=b">x</div>', b'<div title="a=b">x</div>'),
        (b'<div title="a<b">x</div>', b'<div title="a<b">x</div>'),
        (b'<div title="a`b">x</div>', b'<div title="a`b">x</div>'),
    ],
)
def test_values_with_special_characters_stay_double_quoted(body, expected):
    """Spaces, equals, angle brackets and backticks force double quotes."""
    # CATCHES: each of these characters is unsafe unquoted, so the value stays
    # quoted even though it contains no quote character at all.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body",
    [
        b'<div title="a\tb">x</div>',
        b'<div title="a\nb">x</div>',
    ],
)
def test_tab_and_newline_are_kept_raw_in_quoted_values(body):
    """Raw control characters inside a value are not escaped."""
    # CATCHES: a reimplementation that rewrites tab/newline to `&#9;`/`&#10;`
    # changes these bytes.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == body


def test_ampersand_is_reescaped_in_attribute_values():
    """`&amp;` round-trips: decoded for the quote decision, re-encoded out."""
    # CATCHES: an unquoted value containing a bare `&` would be ambiguous, so
    # the reference writes `a&amp;b` back without quotes.
    proc = run_html(b'<div title="a&amp;b">x</div>')
    assert proc.returncode == 0
    assert proc.stdout == b"<div title=a&amp;b>x</div>"


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<div title="ab">x</div>',
            b'<div title="ab">x</div>',
        ),
        (
            b"<div title='ab'>x</div>",
            b"<div title='ab'>x</div>",
        ),
    ],
)
def test_keep_quotes_flag_preserves_original_quoting(body, expected):
    """--html-keep-quotes keeps the quotes exactly as they were written."""
    # CATCHES: both single and double quoted inputs survive byte-for-byte;
    # without the flag the reference would drop both sets of quotes.
    proc = run_html(body, "--html-keep-quotes")
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_rdfa_attributes_are_always_double_quoted():
    """RDFa attributes keep double quotes even when unquoted would work."""
    # CATCHES: vocab/typeof/property/about/... are always quoted for XML
    # compatibility, unlike ordinary attributes which lose their quotes.
    proc = run_html(
        b'<div property="a b" vocab="c" typeof="d" about="e" resource="f" '
        b'prefix="g" content="h" rev="i" datatype="j" inlist="">x</div>'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'<div property="a b" vocab="c" typeof="d" about="e" resource="f" '
        b'prefix="g" content="h" rev="i" datatype="j" inlist>x</div>'
    )


def test_tag_and_attribute_names_are_lowercased():
    """Uppercase tag and attribute names are rewritten in lowercase."""
    # CATCHES: HTML tag and attribute names are case-insensitive and the
    # reference normalizes them; the attribute VALUE keeps its case.
    proc = run_html(b'<DIV CLASS="A">x</DIV>')
    assert proc.returncode == 0
    assert proc.stdout == b'<div class=A>x</div>'


def test_unknown_tags_skip_default_value_and_boolean_logic():
    """Attributes on an unknown tag keep defaults but are still trimmed."""
    # CATCHES: the tag has no traits, so `colspan=one` and `hidden=hidden`
    # survive while class trimming still applies.
    proc = run_html(
        b'<foo class=" a  b " colspan="one" hidden="hidden" title="  x  ">y</foo>',
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'<foo class="a b" colspan=one hidden=hidden title="  x  ">y</foo>'
    )


def test_attribute_names_longer_than_the_hash_table_are_kept():
    """A data- attribute with a 32-character name passes through."""
    # CATCHES: the name is longer than the hash table's maximum length and
    # must still be written out unchanged with its value.
    proc = run_html(b'<div data-abcdefghijklmnopqrstuvwxyz0123="1">a</div>')
    assert proc.returncode == 0
    assert proc.stdout == b'<div data-abcdefghijklmnopqrstuvwxyz0123=1>a</div>'


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<div foobar="x">a</div>',
            b"<div foobar=x>a</div>",
        ),
        (
            b"<Foo>text</Foo>",
            b"<foo>text</foo>",
        ),
    ],
)
def test_unknown_names_are_lowercased_and_kept(body, expected):
    """Unknown attribute and tag names are preserved, in lowercase."""
    # CATCHES: unknown names miss the lookup tables but are still emitted,
    # and the case folding applies to them as well.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_meta_content_type_is_rewritten_to_charset():
    """`<meta http-equiv=content-type ...>` becomes `<meta charset=utf-8>`."""
    # CATCHES: the reference detects the text/html;charset=utf-8 combination
    # and replaces both attributes with a single charset one.
    proc = run_html(
        b'<meta http-equiv="Content-Type" content="text/html; charset=utf-8">',
    )
    assert proc.returncode == 0
    assert proc.stdout == b"<meta charset=utf-8>"


def test_meta_content_type_for_other_charsets_is_only_normalized():
    """A non-utf-8 charset keeps the http-equiv form, normalized."""
    # CATCHES: the mediatype is still minified (space after `;` removed,
    # charset value lowercased) but the rewrite is utf-8 only.
    proc = run_html(
        b'<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">',
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'<meta http-equiv=content-type content="text/html;charset=iso-8859-1">'
    )


def test_existing_charset_wins_over_the_http_equiv_rewrite():
    """A meta that already has charset keeps its http-equiv form intact."""
    # CATCHES: the rewrite only fires when no charset attribute exists; the
    # original attribute order and casing are preserved otherwise.
    proc = run_html(
        b'<meta charset="utf-8" http-equiv="Content-Type" content="text/html; charset=u'
        b'tf-8">',
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'<meta charset=utf-8 http-equiv=Content-Type content="text/html; charset=utf-8'
        b'">'
    )


@pytest.mark.parametrize(
    "content,expected",
    [
        (b"a, b, c", b"a,b,c"),
        (b"a,b, c", b"a,b,c"),
    ],
)
def test_meta_keywords_drop_spaces_after_commas(content, expected):
    """`<meta name=keywords>` removes the space after each comma."""
    # CATCHES: only the exact `, ` sequence is replaced, so the first form
    # loses both spaces while other spacing would be untouched.
    proc = run_html(b'<meta name="keywords" content="' + content + b'">')
    assert proc.returncode == 0
    assert proc.stdout == b'<meta name=keywords content="' + expected + b'">'


@pytest.mark.parametrize(
    "name,content,expected",
    [
        (
            b"viewport",
            b"width = 480, initial-scale = 1.00",
            b"width=480,initial-scale=1",
        ),
        (
            b"VIEWPORT",
            b"width=device-width, minimum-scale=0.50",
            b"width=device-width,minimum-scale=.5",
        ),
    ],
)
def test_meta_viewport_content_is_minified(name, content, expected):
    """viewport contents lose spaces and shorten their numbers."""
    # CATCHES: the name match is case-insensitive, spaces are stripped, and
    # `1.00`/`0.50` are rewritten as `1`/`.5` by number minification.
    proc = run_html(b'<meta name="' + name + b'" content="' + content + b'">')
    assert proc.returncode == 0
    assert proc.stdout == b'<meta name=' + name + b' content="' + expected + b'">'


@pytest.mark.parametrize(
    "body,expected",
    [
        (b'<a type="TEXT/HTML">x</a>', b"<a type=text/html>x</a>"),
        (
            b'<object type="APPLICATION/X-FOO"></object>',
            b"<object type=application/x-foo></object>",
        ),
        (
            b'<form enctype="MULTIPART/FORM-DATA"></form>',
            b"<form enctype=multipart/form-data></form>",
        ),
        (b'<form accept="image/png"></form>', b"<form accept=image/png></form>"),
    ],
)
def test_mediatype_attributes_are_lowercased(body, expected):
    """type/enctype/accept values are parsed and re-emitted as mediatypes."""
    # CATCHES: the mediatype normalization lowercases the whole value on the
    # tags where the attribute is a mediatype, unlike ordinary attributes.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "body,expected",
    [
        (b'<script type="text/javascript">a=1\n</script>', b"<script>a=1</script>"),
        (b'<script type="TEXT/JavaScript">a=1\n</script>', b"<script>a=1\n</script>"),
        (
            b'<script type="text/javascript; charset=utf-8">a=1\n</script>',
            b'<script type="text/javascript;charset=utf-8">a=1</script>',
        ),
        (
            b'<script type="application/ecmascript">a=1\n</script>',
            b"<script type=application/ecmascript>a=1</script>",
        ),
    ],
)
def test_script_type_value_drives_both_removal_and_routing(body, expected):
    """The type value decides attribute removal and content routing alike."""
    # CATCHES: only the two exact JS mimetypes drop the attribute; a mixed-case
    # value is removed for the lookup but fails to route the content (raw
    # `a=1\n` survives), parameters keep a normalized type, and ecmascript is
    # minified through the pattern registry while keeping its type attribute.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_style_attribute_is_css_minified():
    """Inline style values run through the CSS minifier."""
    # CATCHES: the trailing space and semicolon are removed by CSS minification
    # and the surviving `:` makes the value unsafe to leave unquoted.
    proc = run_html(b'<div style="color: red; ">a</div>')
    assert proc.returncode == 0
    assert proc.stdout == b"<div style=color:red>a</div>"


def test_empty_style_attribute_is_removed():
    """A style attribute that minifies away is dropped entirely."""
    # CATCHES: an empty CSS value leaves nothing to write, so the whole
    # attribute disappears rather than staying as a bare `style`.
    proc = run_html(b'<div style="">a</div>')
    assert proc.returncode == 0
    assert proc.stdout == b"<div>a</div>"


def test_unclosed_css_in_a_style_attribute_is_tolerated():
    """A style value the CSS minifier cannot parse is passed through."""
    # CATCHES: unlike the JS event-handler path, a CSS failure here does not
    # fail the run: the original value is emitted unchanged.
    proc = run_html(b'<div style="a{">a</div>')
    assert proc.returncode == 0
    assert proc.stdout == b"<div style=a{>a</div>"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body",
    [b'<a onclick="javascript:x = 1;">a</a>', b'<a onclick="JAVASCRIPT:x=1;">a</a>'],
)
def test_event_handlers_are_js_minified_with_scheme_stripped(body):
    """on* attributes are JS-minified and lose a `javascript:` prefix."""
    # CATCHES: the scheme prefix removal is case-insensitive and happens
    # before minification; the result keeps quotes because of the `=`.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == b'<a onclick="x=1">a</a>'


def test_empty_event_handler_is_removed():
    """An on* attribute that minifies to nothing disappears."""
    # CATCHES: the empty result rule removes the attribute entirely, just as
    # for style attributes.
    proc = run_html(b'<a onclick="">a</a>')
    assert proc.returncode == 0
    assert proc.stdout == b"<a>a</a>"


def test_js_error_in_an_event_handler_fails_the_run():
    """A JS syntax error in an on* attribute aborts with exit code 1."""
    # CATCHES: the reference prints the located error to stderr, exits 1, and
    # falls back to writing the original input to stdout.
    body = b'<a onclick="a~~~">a</a>'
    proc = run_html(body)
    assert proc.returncode == 1
    assert proc.stdout == body
    assert proc.stderr == (
        b"ERROR: cannot minify -: unexpected ~ in expression on line 1 "
        b"and column 14\n    1: a~~~\n        ^\n"
    )


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<a href="HTTP://Example.COM/x">a</a>',
            b"<a href=http://Example.COM/x>a</a>",
        ),
        (
            b'<a href="HTTPS://Example.COM/x">a</a>',
            b"<a href=https://Example.COM/x>a</a>",
        ),
        (b'<a href="  http://a.com  ">a</a>', b"<a href=http://a.com>a</a>"),
        (b'<a href="mailto:x@y.z">m</a>', b"<a href=mailto:x@y.z>m</a>"),
        (b'<a href="http:">a</a>', b"<a href=http:>a</a>"),
    ],
)
def test_url_values_are_trimmed_and_scheme_lowercased(body, expected):
    """Without --url only the scheme is lowercased and edges trimmed."""
    # CATCHES: the host keeps its case, short values are left alone, and a
    # five-character limit guards the scheme sniffing.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "base,body,expected",
    [
        (
            "http://a.com/",
            b'<a href="http://a.com/x">a</a>',
            b"<a href=//a.com/x>a</a>",
        ),
        (
            "https://a.com/",
            b'<a href="https://a.com/x">a</a>',
            b"<a href=//a.com/x>a</a>",
        ),
        (
            "http://a.com/",
            b'<a href="http://b.com/x">a</a>',
            b"<a href=//b.com/x>a</a>",
        ),
        (
            "https://a.com/",
            b'<img src="https://a.com/i.png" alt="x">',
            b"<img src=//a.com/i.png alt=x>",
        ),
    ],
)
def test_matching_scheme_becomes_scheme_relative(base, body, expected):
    """--url strips a same-scheme http(s) URL down to `//host/path`."""
    # CATCHES: the rewrite applies to every url attribute (href, src, ...)
    # and drops the scheme entirely rather than making the URL relative.
    proc = run_html(body, "--url", base)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "base,body,expected",
    [
        (
            "http://a.com/",
            b'<a href="https://a.com/x">a</a>',
            b"<a href=https://a.com/x>a</a>",
        ),
        (
            "https://a.com/",
            b'<a href="http://a.com/x">a</a>',
            b"<a href=http://a.com/x>a</a>",
        ),
        (
            "//a.com/",
            b'<a href="http://a.com/x">a</a>',
            b"<a href=http://a.com/x>a</a>",
        ),
    ],
)
def test_scheme_mismatch_keeps_the_absolute_url(base, body, expected):
    """A different scheme (or a scheme-less --url) disables stripping."""
    # CATCHES: only an exact scheme match rewrites the URL; an https base
    # leaves http URLs absolute, and vice versa.
    proc = run_html(body, "--url", base)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_srcset_is_not_rewritten_by_the_url_option():
    """--url leaves a srcset attribute untouched."""
    # CATCHES: this version has no srcset handling, so even the absolute URL
    # inside it stays http:// while an href would have been rewritten.
    proc = run_html(
        b'<img srcset="a.png 1x, http://b.com/c.png 2x">',
        "--url",
        "http://a.com/",
    )
    assert proc.returncode == 0
    assert proc.stdout == b'<img srcset="a.png 1x, http://b.com/c.png 2x">'


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<a href="data:text/css,body{ color:red; }">a</a>',
            b"<a href=data:text/css,body%7Bcolor:red%7D>a</a>",
        ),
        (b'<a href="data:text/plain,abc">a</a>', b"<a href=data:,abc>a</a>"),
        (
            b'<a href="data:text/plain;charset=utf-8,abc">a</a>',
            b'<a href="data:;charset=utf-8,abc">a</a>',
        ),
        (b'<a href="data:foo/bar,abc">a</a>', b"<a href=data:foo/bar,abc>a</a>"),
        (b'<a href="data:,a b">a</a>', b"<a href=data:,a%20b>a</a>"),
        (
            b'<a href="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%'
            b'22%3E%3C%2Fsvg%3E">a</a>',
            b'<a href="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%'
            b'22/%3E">a</a>',
        ),
    ],
)
def test_data_uris_are_minified_and_percent_encoded(body, expected):
    """data: URLs are minified by mediatype and re-encoded safely."""
    # CATCHES: text/plain is dropped as the default mediatype, unknown
    # mediatypes pass through, spaces become %20, braces become %7B/%7D, and
    # an embedded SVG is minified (self-closing the empty svg element).
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_invalid_url_option_is_a_fatal_error():
    """An unparseable --url value aborts before reading any input."""
    # CATCHES: the URL is parsed up front; a reimplementation that ignored the
    # error would proceed and emit the document instead of failing.
    proc = run_html(b"<p>a", "--url", "://")
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b'ERROR: parse "://": missing protocol scheme\n'


def test_url_option_without_a_scheme_is_accepted():
    """A scheme-less --url value is valid and simply disables rewriting."""
    # CATCHES: only a malformed URL is fatal; a bare word parses fine and the
    # document is minified normally.
    proc = run_html(b"<p>a", "--url", "foo")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a"


def test_script_content_is_js_minified():
    """A plain script body is run through the JS minifier."""
    # CATCHES: the comment and trailing newline inside the script disappear,
    # proving the content was parsed as JavaScript rather than trimmed.
    proc = run_html(b"<script>a=1; // c\n</script>")
    assert proc.returncode == 0
    assert proc.stdout == b"<script>a=1</script>"


@pytest.mark.parametrize(
    "body",
    [
        b"<p>a</p><script></script><p>b</p>",
        b"<p>a</p><style></style><p>b</p>",
    ],
)
def test_empty_script_and_style_tags_are_removed(body):
    """Attribute-less empty script/style elements vanish completely."""
    # CATCHES: the reference skips the start/end tag pair, so not even the
    # empty tags reach the output.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a</p><p>b"


def test_script_with_attributes_is_never_removed():
    """An empty script carrying attributes is kept."""
    # CATCHES: the removal requires an attribute-less tag; async plus
    # custom-element keep the empty element alive.
    proc = run_html(b'<script async custom-element="amp-ad"></script><p>a')
    assert proc.returncode == 0
    assert proc.stdout == b"<script async custom-element=amp-ad></script><p>a"


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<script type="application/ld+json">{"a": 1}\n</script>',
            b'<script type=application/ld+json>{"a":1}</script>',
        ),
        (
            b'<script type="importmap">{"imports": {"a": "b"}}\n</script>',
            b'<script type=importmap>{"imports":{"a":"b"}}</script>',
        ),
        (
            b'<script type="speculationrules">{"prefetch": [{"source": "document"}]}\n<'
            b'/script>',
            b'<script type=speculationrules>{"prefetch":[{"source":"document"}]}</scrip'
            b't>',
        ),
    ],
)
def test_script_json_mimetypes_are_minified(body, expected):
    """ld+json, importmap and speculationrules contents are JSON-minified."""
    # CATCHES: the routing keys on the exact mimetype string while keeping the
    # type attribute (it is not a JS default) and minifying the body as JSON.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_script_template_type_keeps_its_content_raw():
    """`type=text/template` content is data and is not minified."""
    # CATCHES: the inner HTML keeps its whitespace, showing the content is
    # deliberately left untouched rather than routed to a minifier.
    proc = run_html(b'<script type="text/template"><div>  a  </div></script>')
    assert proc.returncode == 0
    assert proc.stdout == b'<script type=text/template><div>  a  </div></script>'


def test_script_module_is_minified_as_an_es_module():
    """`type=module` routes to the JS minifier in module mode."""
    # CATCHES: the space in `from "b"` is removed, which only happens for
    # module-aware parsing of import declarations.
    proc = run_html(b'<script type="module">import a from "b";\n</script>')
    assert proc.returncode == 0
    assert proc.stdout == b'<script type=module>import a from"b"</script>'


def test_script_unknown_mediatype_content_is_kept_raw():
    """No minifier for the mimetype means the content passes through."""
    # CATCHES: the unminifiable body keeps its spacing and trailing newline
    # while the type attribute itself is preserved.
    proc = run_html(b'<script type="text/unknown">a  =  1\n</script>')
    assert proc.returncode == 0
    assert proc.stdout == b"<script type=text/unknown>a  =  1\n</script>"


def test_js_version_flag_applies_to_inline_scripts():
    """--js-version 5 keeps `let` declarations intact."""
    # CATCHES: the global JS option reaches the embedded script minifier; in
    # ES5 mode `let` is left alone rather than renamed or dropped.
    proc = run_html(b"<script>let a=1;</script>", "--js-version", "5")
    assert proc.returncode == 0
    assert proc.stdout == b"<script>let a=1</script>"


def test_style_content_is_css_minified():
    """A plain style body is run through the CSS minifier."""
    # CATCHES: the whitespace around the declaration disappears, proving the
    # content was parsed as CSS rather than whitespace-collapsed as text.
    proc = run_html(b"<style>a { color: red; }\n</style>")
    assert proc.returncode == 0
    assert proc.stdout == b"<style>a{color:red}</style>"


def test_style_type_text_css_is_removed():
    """`type=text/css` on a style element is a removable default."""
    # CATCHES: the style-tag default differs from the script one (which also
    # accepts JS mimetype patterns); the exact css mimetype is dropped.
    proc = run_html(b'<style type="text/css">a{color:red}</style>')
    assert proc.returncode == 0
    assert proc.stdout == b"<style>a{color:red}</style>"


def test_style_amp_boilerplate_content_is_kept_raw():
    """`<style amp-boilerplate>` content is deliberately not minified."""
    # CATCHES: the same CSS is minified without the attribute but kept
    # verbatim with it, because AMP requires the exact boilerplate bytes.
    proc = run_html(b'<style amp-boilerplate="">body { color : red }</style>')
    assert proc.returncode == 0
    assert proc.stdout == b"<style amp-boilerplate>body { color : red }</style>"


def test_iframe_content_is_minified_as_html():
    """The body of an iframe is HTML and is minified recursively."""
    # CATCHES: the inner whitespace is collapsed and `</p>` omitted, showing
    # the iframe content was routed back through the HTML minifier.
    proc = run_html(b"<iframe><p> a  b </p>\n</iframe>")
    assert proc.returncode == 0
    assert proc.stdout == b"<iframe><p>a b</iframe>"


@pytest.mark.parametrize(
    "body",
    [
        b"<p>a</p><iframe></iframe><p>b",
        b"<i>a</i>" + b"</i>" * 100,
    ],
)
def test_empty_iframe_and_stray_end_tags_pass_through(body):
    """An empty iframe is kept and stray end tags are echoed verbatim."""
    # CATCHES: unlike script/style, an attribute-less empty iframe survives,
    # and unbalanced end tags are output as-is rather than dropped.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == body


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b"<script>a=1",
            b"<script>a=1",
        ),
        (
            b"<style>a{color:red}",
            b"<style>a{color:red}",
        ),
    ],
)
def test_unclosed_raw_tags_swallow_the_rest_of_the_input(body, expected):
    """A script/style without an end tag extends to the end of input."""
    # CATCHES: the lexer keeps the rest of the document as raw content, and
    # it is minified (or kept) exactly as a closed tag's content would be.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_inline_svg_path_data_is_minified():
    """An inline `<svg>` block is routed to the SVG minifier."""
    # CATCHES: the path data is rewritten to exponent notation (`1e2`) and a
    # lowercase `z`, which only the SVG path-data minifier produces.
    proc = run_html(b'<svg><path d="M 100 100 L 200 200 Z"/></svg>')
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><path d="M1e2 1e2 2e2 2e2z"/></svg>'


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            b'<svg viewBox="0 0 10 10"><path d="M 1 1"/></svg>',
            b'<svg viewBox="0 0 10 10"><path d="M1 1"/></svg>',
        ),
        (b'<svg><g><path d="M 1 1"/></g></svg>', b'<svg><g><path d="M1 1"/></g></svg>'),
        (
            b'<svg xmlns="http://www.w3.org/2000/svg"><path d="M 1 1"/></svg>',
            b'<svg><path d="M1 1"/></svg>',
        ),
        (b'<SVG><PATH d="M 1 1"/></SVG>', b'<svg><PATH d="M1 1"/></SVG>'),
    ],
)
def test_svg_attributes_and_namespaces(body, expected):
    """SVG attributes are kept, the default namespace dropped, case folded."""
    # CATCHES: the outer svg element name is lowercased while inner element
    # names keep their case, and the xmlns default is removed as redundant.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_svg_keep_comments_flag_applies_to_inline_svg():
    """--svg-keep-comments reaches the inline SVG minifier too."""
    # CATCHES: the comment inside the svg block survives with the flag while
    # the path data is still minified.
    proc = run_html(
        b'<svg><!-- c --><path d="M 100 100"/></svg>',
        "--svg-keep-comments",
    )
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><!-- c --><path d="M1e2 1e2"/></svg>'


def test_svg_keep_namespaces_takes_a_list_value():
    """--svg-keep-namespaces needs an explicit value and keeps only extras."""
    # CATCHES: the option is a list, so a missing value is a usage error (the
    # usage screen is printed to stdout, exit code 2) and naming the default
    # svg namespace still does not keep the redundant xmlns attribute.
    proc = run_html(b'<svg xmlns="http://www.w3.org/2000/svg"><path d="M 1 1"/></svg>')
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><path d="M1 1"/></svg>'

    named = run_html(
        b'<svg xmlns="http://www.w3.org/2000/svg"><path d="M 1 1"/></svg>',
        "--svg-keep-namespaces",
        "svg",
    )
    assert named.returncode == 0
    assert named.stdout == b'<svg><path d="M1 1"/></svg>'

    missing = run_html(b"<p>a", "--svg-keep-namespaces")
    assert missing.returncode == 2
    assert missing.stdout == USAGE
    assert missing.stderr == b"option --svg-keep-namespaces: missing value\n\n"


def test_inline_mathml_is_minified_as_xml():
    """An inline `<math>` block is routed to the XML minifier."""
    # CATCHES: the newlines and indentation inside the math element are
    # collapsed, which is XML whitespace handling, not the HTML text rules.
    proc = run_html(b"<math>\n  <mi>a</mi>\n  <mo>+</mo>\n  <mi>b</mi>\n</math>")
    assert proc.returncode == 0
    assert proc.stdout == b"<math><mi>a</mi><mo>+</mo><mi>b</mi></math>"


def test_math_is_not_whitespace_significant_to_html():
    """Spaces around a math element follow the block-tag rule."""
    # CATCHES: the space between `</p>` and `<math>` is removed even though
    # math is inline-ish content, and the math end tag survives.
    proc = run_html(b"<p>x</p> <math><mi>a</mi></math> <p>y")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>x</p><math><mi>a</mi></math><p>y"


def test_math_attributes_are_preserved():
    """Attributes on the math element pass through unchanged."""
    # CATCHES: display=block is not a default for mathml, so the attribute
    # keeps both name and value.
    proc = run_html(b'<math display="block"><mi>a</mi></math>')
    assert proc.returncode == 0
    assert proc.stdout == b'<math display="block"><mi>a</mi></math>'


@pytest.mark.parametrize(
    "body,expected",
    [
        (b"<p>a {{ 1 + 2 }} b</p>", b"<p>a {{ 1 + 2 }} b"),
        (b'<div class="a{{ x }}b">y</div>', b'<div class="a{{ x }}b">y</div>'),
        (b"<svg>{{ x }}</svg>", b"<svg>{{ x }}</svg>"),
        (b"<math><mi>{{ x }}</mi></math>", b"<math><mi>{{ x }}</mi></math>"),
    ],
)
def test_template_expressions_are_passed_through(body, expected):
    """`{{ ... }}` template expressions survive untouched everywhere."""
    # CATCHES: the inner spacing of the expression is kept, attributes
    # containing templates skip minification, and svg/math content with a
    # template is not handed to their minifiers (the first case also shows
    # `</p>` still omitted at end of input around a template).
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_template_tag_content_is_minified_but_keeps_end_tags():
    """HTML inside `<template>` is minified with end tags intact."""
    # CATCHES: the inner text loses its edge whitespace while `</div>` stays,
    # combining the normal text rules with the template end-tag exception.
    proc = run_html(b"<template><div>  a  </div></template>")
    assert proc.returncode == 0
    assert proc.stdout == b"<template><div>a</div></template>"


@pytest.mark.parametrize(
    "body,expected",
    [
        (b'<?xml version="1.0" encoding="UTF-8"?>text', b"text"),
        (b'<p>a<?xml version="1.0"?>b</p>', b"<p>ab"),
        (b'<?xml-stylesheet type="text/css" href="x.css"?><p>a', b"<p>a"),
    ],
)
def test_xml_processing_instructions_are_removed(body, expected):
    """`<?xml ...?>` processing instructions do not reach the output."""
    # CATCHES: the declaration and any other leading PI disappear while the
    # surrounding text is preserved and joined without inserted whitespace.
    proc = run_html(body)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_cdata_sections_are_passed_through():
    """A CDATA section in text is written out verbatim."""
    # CATCHES: the reference has no CDATA handling in HTML mode, so the whole
    # `<![CDATA[...]]>` sequence survives inside the text node.
    proc = run_html(b"<p>a<![CDATA[x]]>b</p>")
    assert proc.returncode == 0
    assert proc.stdout == b"<p>a<![CDATA[x]]>b"
