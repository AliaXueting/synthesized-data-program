"""JavaScript variable handling (js/vars.go) as reached through the CLI.

This module pins the parts of the JS minifier that move, merge, hoist and
rename variable declarations: hoisting var declarations onto the cheapest
surviving declaration, converting hoisted declarations back into
expressions, merging declarations with assignments (including assignments
whose variable lives in another declaration), the sort that puts
defaultless bindings first, the let/const binding-usage analysis that keeps
or drops single-statement blocks, interference detection for
destructuring right-hand sides, the frequency-sorted renamer alphabet
including its keyword-collision skip, and the ten-thousand-item hoisting
threshold.  Every expected byte sequence was recorded by running
`./executable`.
"""

import pytest

from conftest import run_minify


def run_js(body, *flags):
    """Run the reference with --type js on 'body' and return the result."""
    if isinstance(body, str):
        body = body.encode()
    return run_minify(["--type", "js", *flags], stdin=body)


# ------------------------------------------------------ hoisting / merging


def test_two_var_decls_merge_inside_function():
    """Two var declarations in a function merge into one and get renamed."""
    # CATCHES: inside the function the second declaration is hoisted onto
    # the first, printing as a single `var e=1,t=2` with the frequency
    # alphabet's first two names.
    proc = run_js("function f(){var a=1;var b=2}")
    assert proc.returncode == 0
    assert proc.stdout == b"function f(){var e=1,t=2}"
    assert proc.stderr == b""


def test_hoisted_decl_prints_as_expression():
    """A hoisted declaration survives as a plain assignment expression."""
    # CATCHES: the second declaration loses its `var` keyword and joins the
    # following call in a comma expression, while its binding (without a
    # default) is prepended to the surviving declaration as `var e,t=1`.
    proc = run_js("function f(){var a=1;c();var b=2}")
    assert proc.returncode == 0
    assert proc.stdout == b"function f(){var e,t=1;c(),e=2}"
    assert proc.stderr == b""


def test_comma_wrapped_decl_merges_forward():
    """A declaration inside a comma expression merges into a later var."""
    # CATCHES: the hoisted `var b=2` is wrapped in a comma with c(), and the
    # following four-variable declaration (too expensive to hoist) pulls the
    # b=2 definition out of the comma, leaving `c()` behind in the
    # expression and `var e=2,t=3,n=4,s=5,o=6` as the declaration.
    proc = run_js("function f(){c();var b=2;var d=3,e=4,f=5,g=6}")
    assert proc.returncode == 0
    assert proc.stdout == b"function f(){c();var e=2,t=3,n=4,s=5,o=6}"
    assert proc.stderr == b""


def test_comma_assignment_merges_forward():
    """An assignment in a comma expression merges into a later var."""
    # CATCHES: here the comma is `e=2,c()` so the assignment (not the
    # declaration) is pulled forward into the var statement; the surviving
    # declaration re-declares e while the comma keeps only c().
    proc = run_js("function f(){var b=2;c();var d=3,e=4,f=5,g=6}")
    assert proc.returncode == 0
    assert proc.stdout == b"function f(){e=2,c();var e,t=3,n=4,s=5,o=6}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            "function f(){var x,y=1,z=2,w=3;f();var a=1,b=2,c=3,d=4;x=5}",
            b"function f(){var t=1,n=2,s=3;f();var o=1,i=2,a=3,r=4,e=5}",
        ),
        (
            "function f(){var x,y=1,z=2,w=3;f();x=5;var a=1,b=2,c=3,d=4}",
            b"function f(){var t=1,n=2,s=3;f();var e=5,o=1,i=2,a=3,r=4}",
        ),
    ],
    ids=["assignment-after", "assignment-before"],
)
def test_definition_moved_between_declarations(body, expected):
    """An assignment merges into the adjacent var from another declaration."""
    # CATCHES: x is declared without a default in the first (unhoisted)
    # declaration, so merging `x=5` into the adjacent one must find and
    # delete x in the *other* declaration list; reverse order prepends the
    # definition (e=5 first) while forward order appends it (e=5 last).
    proc = run_js(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_for_init_decl_absorbs_preceding_declaration():
    """A hoisted for-init declaration merges with the preceding var."""
    # CATCHES: the for-loop's `var i` has no defaults, so the preceding
    # four-variable declaration is moved into the for initializer and the
    # loop keeps its own `var` keyword with the defaultless binding first.
    proc = run_js("function f(){var a=1,b=2,c=3,d=4;for(var i;;)f(i)}")
    assert proc.returncode == 0
    assert proc.stdout == b"function f(){for(var e,t=1,n=2,s=3,o=4;;)f(e)}"
    assert proc.stderr == b""


def test_assignment_links_to_later_declaration():
    """An assignment before the declaration links to the declared binding."""
    # CATCHES: `a=1` precedes `var a`, and the binding resolution must link
    # the assignment to the later declaration so both collapse into the
    # merged `var t=1,e=2` with the return expression renamed to match.
    proc = run_js("function f(){a=1;var b=2;var a;return a+b}")
    assert proc.returncode == 0
    assert proc.stdout == b"function f(){var t=1,e=2;return t+e}"
    assert proc.stderr == b""


def test_defaultless_binding_sorts_before_defined_one():
    """A var list puts the defaultless binding before the defined one."""
    # CATCHES: `var b=1,a` is reordered to `var a,b=1` because bindings
    # without defaults sort first, and the top-level names are not renamed.
    proc = run_js("var b=1,a;f(a,b)")
    assert proc.returncode == 0
    assert proc.stdout == b"var a,b=1;f(a,b)"
    assert proc.stderr == b""


# --------------------------------------------------------- let / const


def test_let_array_binding_rotates_to_front():
    """A let list rotates its array binding to the first position."""
    # CATCHES: moving `[c]=d` in front of the two plain bindings saves the
    # separating space, so the third item is rotated past two others rather
    # than swapped with its single neighbour.
    proc = run_js("let a=1,b=2,[c]=d")
    assert proc.returncode == 0
    assert proc.stdout == b"let[c]=d,a=1,b=2"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("if(x){let a=f(a)}", b"if(x){let e=f(e)}"),
        ("if(x){let [a]=f(a)}", b"if(x){let[e]=f(e)}"),
        ("if(x){let [a,...r]=f(a,r)}", b"if(x){let[e,...t]=f(e,t)}"),
        ("if(x){let {a}=f(a)}", b"if(x){let{a:e}=f(e)}"),
        ("if(x){let {a,...r}=f(a,r)}", b"if(x){let{a:e,...t}=f(e,t)}"),
    ],
    ids=["call", "array", "array-rest", "object", "object-rest"],
)
def test_used_let_binding_keeps_its_block(body, expected):
    """A let block whose bindings are used keeps its braces."""
    # CATCHES: using the binding (in the initializer itself) blocks the
    # empty-scope removal, and the used binding is renamed consistently in
    # every binding shape: plain, array, array-with-rest, object and
    # object-with-rest.
    proc = run_js(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body",
    ["let a=1,[b,...r]=[a]", "let a=1,{b,...r}={a}"],
    ids=["array-rest", "object-rest"],
)
def test_let_rest_element_referencing_decl_interferes(body):
    """A rest element using the declared variable blocks reordering."""
    # CATCHES: the rest element references a, so the destructuring cannot
    # move in front of `a=1` and the declaration list round-trips unchanged.
    proc = run_js(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


def test_computed_object_key_referencing_decl_interferes():
    """A computed key using the declared variable blocks reordering."""
    # CATCHES: the computed key `[a]` inside the object literal reads a, so
    # the array binding stays after `a=1` and the statement is unchanged.
    proc = run_js("let a=1,[b]={[a]:1}")
    assert proc.returncode == 0
    assert proc.stdout == b"let a=1,[b]={[a]:1}"
    assert proc.stderr == b""


def test_binary_rhs_referencing_decl_interferes():
    """A binary right-hand side using the declared variable blocks moves."""
    # CATCHES: `a+c` on the right of the destructuring references a, so the
    # binding cannot rotate to the front of the let list.
    proc = run_js("let a=1,[b]=a+c")
    assert proc.returncode == 0
    assert proc.stdout == b"let a=1,[b]=a+c"
    assert proc.stderr == b""


def test_function_default_param_referencing_decl_interferes():
    """A default parameter keeps its declaration order and gets renamed."""
    # CATCHES: the parameter default `c=a` reads a, so the function
    # expression moves to the front of the let list, the outer a stays
    # unrenamed (module scope) while the inner parameter becomes e.
    proc = run_js("let a=1,[b]=(function(c=a){return c});f(b)")
    assert proc.returncode == 0
    assert proc.stdout == b"let[b]=function(e=a){return e},a=1;f(b)"
    assert proc.stderr == b""


# -------------------------------------------------------------- renamer

# The renamer's single-character names in assignment order (frequency-sorted
# alphabet), recorded from the reference's output.
SINGLE_CHAR_NAMES = "etnsoiarclduhmfpgvbjy_wOxCEkASMFTzDNLRPHIBV$WUKqYGXQZJ"

# The names for a 172-variable function, recorded verbatim from the
# reference's output: 54 single-character names, then two-character names
# built from the same alphabet, skipping the keyword `in` (position 167).
NAMES_172 = (
    "e t n s o i a r c l d u h m f p g v b j y _ w O x C E k A S M F T"
    " z D N L R P H I B V $ W U K q Y G X Q Z J"
    " ee te ne se oe ie ae re ce le de ue he me fe pe ge ve be je ye _e we"
    " Oe xe Ce Ee ke Ae Se Me Fe Te ze De Ne Le Re Pe He Ie Be Ve $e We Ue"
    " Ke qe Ye Ge Xe Qe Ze Je"
    " et tt nt st ot it at rt ct lt dt ut ht mt ft pt gt vt bt jt yt _t wt"
    " Ot xt Ct Et kt At St Mt Ft Tt zt Dt Nt Lt Rt Pt Ht It Bt Vt $t Wt Ut"
    " Kt qt Yt Gt Xt Qt Zt Jt"
    " en tn nn sn on an rn cn ln dn"
).split()


def _renamer_function(n, names):
    """Build the n-variable function and its recorded minified form."""
    body = "function f(){var %s;return %s}" % (
        ",".join("v%d=%d" % (i, i) for i in range(n)),
        "+".join("v%d" % i for i in range(n)),
    )
    expected = "function f(){var %s;return %s}" % (
        ",".join("%s=%d" % (names[i], i) for i in range(n)),
        "+".join(names[i] for i in range(n)),
    )
    return body, expected


@pytest.mark.parametrize("count", [60, 172], ids=["sixty", "hundred-seventy-two"])
def test_renamer_alphabet_and_keyword_skip(count):
    """The renamer walks its alphabet and skips two-char keyword collisions."""
    # CATCHES: with 60 variables the names run through all 54 single
    # characters and start the two-character series (ee,te,...), and with
    # 172 variables the series reaches the n-column where the 167th name
    # would be the reserved word `in`, so `an` follows `on` directly.
    names = NAMES_172[:count]
    body, expected = _renamer_function(count, names)
    proc = run_js(body)
    assert proc.returncode == 0
    assert proc.stdout == expected.encode()
    assert proc.stderr == b""


# ------------------------------------------------------------ threshold


def _shortest_number(i):
    """The recorded number spelling the reference emits for the value i."""
    if i == 10000:
        return "1e4"
    if 1000 <= i <= 9000 and i % 1000 == 0:
        return "%de3" % (i // 1000)
    return str(i)


@pytest.mark.parametrize("count,hoisted", [(10000, True), (10001, False)], ids=["at-limit", "over-limit"])
def test_hoisting_threshold_ten_thousand_items(count, hoisted):
    """Hoisting merges up to ten thousand items in the target declaration."""
    # CATCHES: with 10000 items the trailing `var b=1` is still hoisted into
    # the big declaration (`var b,a0=0,...` and `x&&(b=1)`), while 10001
    # items crosses the guard and the declaration is left as its own
    # `if(x)var b=1` statement; the recorded spellings include the 1e3/1e4
    # shortening of round thousands.
    decl = ",".join("a%d=%s" % (i, _shortest_number(i)) for i in range(count))
    body = "var %s;if(x)var b=1" % decl
    if hoisted:
        expected = "var b,%s;x&&(b=1)" % decl
    else:
        expected = "var %s;if(x)var b=1" % decl
    proc = run_js(body)
    assert proc.returncode == 0
    assert proc.stdout == expected.encode()
    assert proc.stderr == b""
