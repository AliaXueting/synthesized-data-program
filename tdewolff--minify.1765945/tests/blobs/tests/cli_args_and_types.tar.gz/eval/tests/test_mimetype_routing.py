"""The mimetype-to-minifier routing registry behind `--type` and `--ext`.

The binary keeps a registry of literal mimetypes (text/css, text/html,
image/svg+xml, importmap, speculationrules, the template mimetypes), of
regular-expression patterns (the JavaScript variants, `[/+]json$` and
`[/+]xml$`), and nothing else.  These tests pin, through the CLI only, which
mimetype reaches which minifier and what happens to a mimetype that no
registered pattern accepts.  Every expectation was recorded by running
`./executable`.
"""

import pytest

from conftest import run_minify, write_file

CSS = b"a { color: red; }\n"
JS = b"let x = 1 ;\n"
JSON = b'{"a" : 1}'
XML = b"<root >  x  </root >"

JAVASCRIPT_MIMETYPES = [
    "application/javascript",
    "text/javascript",
    "application/x-javascript",
    "text/ecmascript",
    "application/ecmascript",
    "application/livescript",
    "application/jscript",
    "application/javascript1.5",
]

JSON_SUFFIX_MIMETYPES = [
    "application/json",
    "text/json",
    "application/ld+json",
    "application/vnd.api+json",
    "application/manifest+json",
]

XML_SUFFIX_MIMETYPES = [
    "application/xml",
    "text/xml",
    "application/rss+xml",
    "application/xhtml+xml",
]

CURLY_TEMPLATE_MIMETYPES = [
    "text/x-template",
    "text/x-go-template",
    "text/x-mustache-template",
    "text/x-handlebars-template",
]


@pytest.mark.parametrize("mimetype", JAVASCRIPT_MIMETYPES)
def test_javascript_variants_all_reach_the_js_minifier(mimetype):
    """Every spelling the JS regex accepts is minified as JavaScript."""
    # CATCHES: the pattern matches (application|text)/(x-)?(java|ecma|j|live)
    # script plus the legacy 1.0-1.5 version suffixes, so all of these collapse
    # `let x = 1 ;` to the same recorded bytes.
    proc = run_minify(["--type", mimetype], stdin=JS)
    assert proc.returncode == 0
    assert proc.stdout == b"let x=1"
    assert proc.stderr == b""


def test_newer_javascript_version_suffix_has_no_minifier():
    """application/javascript1.6 falls outside the JS pattern."""
    # CATCHES: the version suffix in the pattern stops at 1.5, so 1.6 leaves
    # the input untouched on stdout, reports `minifier does not exist` on
    # stderr and exits 1.
    proc = run_minify(["--type", "application/javascript1.6"], stdin=JS)
    assert proc.returncode == 1
    assert proc.stdout == JS
    assert proc.stderr == b"ERROR: cannot minify -: minifier does not exist for mimetype\n"


@pytest.mark.parametrize("mimetype", JSON_SUFFIX_MIMETYPES)
def test_json_suffix_mimetypes_reach_the_json_minifier(mimetype):
    """Any mimetype ending in /json or +json is minified as JSON."""
    # CATCHES: the JSON pattern is a suffix match, so vendor and LD variants
    # are covered without being listed literally.
    proc = run_minify(["--type", mimetype], stdin=JSON)
    assert proc.returncode == 0
    assert proc.stdout == b'{"a":1}'
    assert proc.stderr == b""


def test_json_suffix_needs_a_slash_or_plus_delimiter():
    """application/x-json does not match because of the hyphen."""
    # CATCHES: the pattern is `[/+]json$`, so a hyphenated variant with the
    # same `json` tail has no minifier and the original bytes pass through.
    proc = run_minify(["--type", "application/x-json"], stdin=JSON)
    assert proc.returncode == 1
    assert proc.stdout == JSON
    assert proc.stderr == b"ERROR: cannot minify -: minifier does not exist for mimetype\n"


@pytest.mark.parametrize("mimetype", XML_SUFFIX_MIMETYPES)
def test_xml_suffix_mimetypes_reach_the_xml_minifier(mimetype):
    """Any mimetype ending in /xml or +xml is minified as XML."""
    # CATCHES: the XML pattern is a suffix match too, so RSS and XHTML
    # documents get the XML minifier (not the HTML one) and keep their
    # attribute-value whitespace untouched.
    proc = run_minify(["--type", mimetype], stdin=XML)
    assert proc.returncode == 0
    assert proc.stdout == b"<root>x</root>"
    assert proc.stderr == b""


def test_svg_literal_beats_the_xml_pattern():
    """image/svg+xml gets the SVG minifier, not the XML one."""
    # CATCHES: literal entries are tried before the patterns, so the same
    # document is path-data-minified under image/svg+xml but left byte-for-
    # byte identical under the pattern-matched application/xhtml+xml.
    svg = b'<svg xmlns="http://www.w3.org/2000/svg"><path d="M 0 0 L 10 10 z"/></svg>'
    svg_proc = run_minify(["--type", "image/svg+xml"], stdin=svg)
    assert svg_proc.returncode == 0
    assert svg_proc.stdout == (
        b'<svg xmlns="http://www.w3.org/2000/svg"><path d="M0 0 10 10z"/></svg>'
    )
    xml_proc = run_minify(["--type", "application/xhtml+xml"], stdin=svg)
    assert xml_proc.returncode == 0
    assert xml_proc.stdout == svg


@pytest.mark.parametrize("ext,literal", [("im", "importmap"), ("sr", "speculationrules")])
def test_extensionless_literals_reach_the_json_minifier(tmp_path, ext, literal):
    """importmap and speculationrules are registered literals without a slash."""
    # CATCHES: `--type` rejects them (no slash, not in the extension map), but
    # an --ext mapping can hand the literal to the registry, which routes both
    # to the JSON minifier.
    src = write_file(tmp_path, "input." + ext, JSON)
    proc = run_minify(["--ext.%s=%s" % (ext, literal), src.name], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b'{"a":1}'
    assert proc.stderr == b""


@pytest.mark.parametrize("mimetype", CURLY_TEMPLATE_MIMETYPES)
def test_curly_template_mimetypes_keep_template_whitespace(mimetype):
    """Go/Mustache/Handlebars mimetypes route to HTML with `{{ }}` delims."""
    # CATCHES: inside the template delimiters the HTML minifier must not touch
    # whitespace, so the double space in `{{ .Name  }}` survives while the
    # spaces around it collapse.
    proc = run_minify(["--type", mimetype], stdin=b"<div>  {{ .Name  }}  </div>")
    assert proc.returncode == 0
    assert proc.stdout == b"<div>{{ .Name  }}</div>"
    assert proc.stderr == b""


@pytest.mark.parametrize("mimetype", ["text/asp", "text/x-ejs-template"])
def test_asp_style_templates_keep_template_whitespace(mimetype):
    """text/asp and text/x-ejs-template route to HTML with `<% %>` delims."""
    # CATCHES: a different template delimiter pair is installed for these
    # mimetypes, so the content between `<%` and `%>` is passed through
    # verbatim while the surrounding HTML is minified.
    proc = run_minify(["--type", mimetype], stdin=b"<div>  <% .Name  %>  </div>")
    assert proc.returncode == 0
    assert proc.stdout == b"<div><% .Name  %></div>"
    assert proc.stderr == b""


def test_php_template_mimetype_keeps_template_whitespace():
    """application/x-httpd-php routes to HTML with `<? ?>` delimiters."""
    # CATCHES: the PHP delimiter pair protects the template body from HTML
    # whitespace collapsing.
    proc = run_minify(["--type", "application/x-httpd-php"], stdin=b"<div>  <? .Name  ?>  </div>")
    assert proc.returncode == 0
    assert proc.stdout == b"<div><? .Name  ?></div>"
    assert proc.stderr == b""


def test_plain_html_collapses_template_whitespace():
    """Under plain text/html the template braces hold no special meaning."""
    # CATCHES: without template delimiters the HTML minifier collapses runs of
    # whitespace everywhere, including inside `{{ .Name  }}`, which every
    # template mimetype above preserves.
    proc = run_minify(["--type", "text/html"], stdin=b"<div>  {{ .Name  }}  </div>")
    assert proc.returncode == 0
    assert proc.stdout == b"<div>{{ .Name }}</div>"
    assert proc.stderr == b""


def test_mimetype_matching_is_case_sensitive():
    """TEXT/CSS is not the same mimetype as text/css."""
    # CATCHES: the registry lookup is case sensitive, so an upper-case
    # mimetype finds no minifier and the original input passes through.
    proc = run_minify(["--type", "TEXT/CSS"], stdin=CSS)
    assert proc.returncode == 1
    assert proc.stdout == CSS
    assert proc.stderr == b"ERROR: cannot minify -: minifier does not exist for mimetype\n"


@pytest.mark.parametrize("mediatype", ["text/css; charset=utf-8", "text/css ;charset=utf-8"])
def test_mimetype_parameters_are_ignored(mediatype):
    """A `;parameter` tail on --type is split off before the lookup."""
    # CATCHES: the mediatype is parsed into mimetype plus parameters first, so
    # `text/css; charset=utf-8` still matches the literal text/css entry
    # regardless of the spaces around the semicolon.
    proc = run_minify(["--type", mediatype], stdin=CSS)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b""


def test_wildcard_mimetypes_have_no_minifier():
    """`text/*` looks like a wildcard but matches nothing."""
    # CATCHES: the registry only knows literals and suffix patterns, so a
    # star mimetype is just an unknown string and the run fails.
    proc = run_minify(["--type", "text/*"], stdin=CSS)
    assert proc.returncode == 1
    assert proc.stdout == CSS
    assert proc.stderr == b"ERROR: cannot minify -: minifier does not exist for mimetype\n"


def test_module_mimetype_is_not_a_known_filetype():
    """`module` is a registered JS mimetype but not a --type filetype."""
    # CATCHES: a --type value without a slash must resolve through the
    # extension map, and `module` is not an extension, so the failure is the
    # unknown-filetype message rather than a minifier lookup.
    proc = run_minify(["--type", "module"], stdin=JS)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: unknown filetype \n"


def test_ext_mapping_to_an_unregistered_mimetype_fails(tmp_path):
    """--ext can point an extension at a mimetype nothing minifies."""
    # CATCHES: --ext stores the raw mimetype without validation, and the
    # failure only surfaces at minify time as `cannot minify`, with the
    # original file content passed through to stdout.
    src = write_file(tmp_path, "data.zzz", CSS)
    proc = run_minify(["--ext.zzz=bogus/mime", src.name], cwd=tmp_path)
    assert proc.returncode == 1
    assert proc.stdout == CSS
    assert proc.stderr == (
        b"ERROR: cannot minify data.zzz: minifier does not exist for mimetype\n"
    )


@pytest.mark.parametrize("filetype", ["SVG", "CSS"])
def test_short_type_names_are_case_sensitive(filetype):
    """A --type short name must match the extension map's lower-case key."""
    # CATCHES: `SVG` and `CSS` are not looked up case-insensitively, so they
    # fail with the unknown-filetype error even though the lower-case
    # spellings are the canonical short names.
    proc = run_minify(["--type", filetype], stdin=b"<svg/>")
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: unknown filetype \n"


def test_file_extension_lookup_is_case_sensitive(tmp_path):
    """A `.SVG` suffix cannot be inferred; the lower-case `.svg` can."""
    # CATCHES: the extension-to-mimetype inference is case-sensitive, so the
    # upper-case suffix fails with the set --type hint while the lower-case
    # copy of the same file minifies through the SVG route.
    body = "<svg><g></g></svg>"
    upper = write_file(tmp_path, "pic.SVG", body)
    lower = write_file(tmp_path, "pic.svg", body)
    bad = run_minify([upper.name], cwd=tmp_path)
    assert bad.returncode == 1
    assert bad.stdout == b""
    assert bad.stderr == (
        b"ERROR: cannot infer mimetype from extension in pic.SVG,"
        b" set --type explicitly\n"
    )
    good = run_minify([lower.name], cwd=tmp_path)
    assert good.returncode == 0
    assert good.stdout == b"<svg><g/></svg>"
    assert good.stderr == b""


def test_ext_value_resolves_short_names_for_file_routing(tmp_path):
    """An --ext mapping may name a short filetype, resolved through the map."""
    # CATCHES: `--ext.s=svg` stores image/svg+xml (not the literal `svg`), so
    # a `.s` file is routed to the SVG minifier and its empty <g> collapses.
    src = write_file(tmp_path, "drawing.s", "<svg><g></g></svg>")
    proc = run_minify(["--ext.s=svg", src.name], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><g/></svg>"
    assert proc.stderr == b""
