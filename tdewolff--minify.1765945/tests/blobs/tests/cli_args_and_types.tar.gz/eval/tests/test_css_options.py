"""The `--css-*` options and CSS minification as reached through the CLI.

This module owns only the plumbing of the per-format flags, so these tests
pin how `--css-precision` and `--css-version` change the output of the CSS
minifier the `--type css` route selects, plus a spread of CSS constructs that
the same route produces.  Every expected byte sequence was recorded by
running `./executable`.
"""

import pytest

from conftest import run_minify


def minify_css(body, *flags):
    """Run the reference with --type css and return the CompletedProcess."""
    return run_minify(["--type", "css", *flags], stdin=body.encode())


@pytest.mark.parametrize(
    "precision,expected",
    [
        (None, b"a{margin:.63748471em}"),
        ("0", b"a{margin:.63748471em}"),
        ("3", b"a{margin:.637em}"),
        ("1", b"a{margin:.6em}"),
    ],
)
def test_css_precision_rounds_to_significant_digits(precision, expected):
    """--css-precision caps the significant digits kept in numbers."""
    # CATCHES: 0 (the default) keeps every digit, 3 keeps `.637` and 1 keeps
    # `.6`, and the leading zero is dropped in all cases.
    flags = [] if precision is None else ["--css-precision", precision]
    proc = minify_css("a{margin:0.63748471em}", *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "flags",
    [[], ["--css-version", "2"], ["--css-version", "3"]],
    ids=["default", "css2", "css3"],
)
def test_hex_colors_shorten_under_every_css_version(flags):
    """#FFFFFF becomes #fff regardless of the --css-version given."""
    # CATCHES: the hex shortening is not gated on a CSS version, so all three
    # spellings produce the identical recorded output.
    proc = minify_css("a{color:#FFFFFF}", *flags)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:#fff}"
    assert proc.stderr == b""


def test_zero_units_and_leading_zeroes_are_dropped():
    """0px becomes 0 and 0.5em becomes .5em."""
    # CATCHES: units on zero are removed and the leading zero of a fraction is
    # dropped, including for negative numbers.
    proc = minify_css("a{margin:0px;padding:0.5em;top:-0.5px}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{margin:0;padding:.5em;top:-.5px}"
    assert proc.stderr == b""


def test_font_shorthand_normalizes_weight_and_spelling():
    """`bold` becomes `700` and the font list loses its spaces."""
    # CATCHES: the font shorthand is rewritten, not just re-spaced: the
    # keyword weight is turned into its numeric form and the comma in the
    # family list is no longer followed by a space.
    proc = minify_css("a{font:italic bold 12px/30px Georgia, serif}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{font:italic 700 12px/30px Georgia,serif}"
    assert proc.stderr == b""


def test_rgb_color_is_replaced_by_its_name():
    """rgb(255, 0, 0) becomes the shorter keyword red."""
    # CATCHES: the minifier converts rgb() notation to a color name when that
    # is the shorter spelling, not merely stripping the spaces.
    proc = minify_css("a{color:rgb(255, 0, 0)}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b""


def test_at_rule_preconditions_are_compacted():
    """@media and @supports lose the space before their parenthesis."""
    # CATCHES: at-rule prelude punctuation is compacted to `(min-width:100px)`
    # while the inner declaration block is minified like any other.
    proc = minify_css("@media (min-width: 100px) { a { color: red; } }")
    assert proc.returncode == 0
    assert proc.stdout == b"@media(min-width:100px){a{color:red}}"
    assert proc.stderr == b""
    proc = minify_css("@supports (display: grid) { a { color: red; } }")
    assert proc.returncode == 0
    assert proc.stdout == b"@supports(display:grid){a{color:red}}"
    assert proc.stderr == b""


def test_url_quotes_are_removed():
    """Quoted url() arguments come back unquoted."""
    # CATCHES: url("img.png") keeps its argument but loses the quotes, the
    # baseline URL handling the --url option builds on.
    proc = minify_css('a{background:url("img.png")}')
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:url(img.png)}"
    assert proc.stderr == b""


def test_selector_punctuation_loses_its_padding():
    """Combinators and attribute filters are squeezed to their minimum."""
    # CATCHES: the spaces around `>`, `+` and `~` disappear, and the quotes
    # around an attribute selector value are dropped where they are optional.
    proc = minify_css("a:not(.b) > c + d ~ e { color: red; }")
    assert proc.returncode == 0
    assert proc.stdout == b"a:not(.b)>c+d~e{color:red}"
    assert proc.stderr == b""
    proc = minify_css('input[type="text"] { color: red; }')
    assert proc.returncode == 0
    assert proc.stdout == b"input[type=text]{color:red}"
    assert proc.stderr == b""


def test_custom_properties_keep_their_case_and_value():
    """--custom-var declarations survive with their value whitespace squeezed."""
    # CATCHES: custom property names and var() references are passed through
    # verbatim; only the padding around the value's colon is removed.
    proc = minify_css("a{--custom-var: value; color: var(--custom-var)}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{--custom-var:value;color:var(--custom-var)}"
    assert proc.stderr == b""


def test_empty_declarations_and_comments_disappear():
    """Redundant semicolons and comments are removed outright."""
    # CATCHES: `;;;` collapses to nothing after the last declaration and the
    # leading comment is dropped without leaving a gap.
    proc = minify_css("a{color:red;;;}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b""
    proc = minify_css("/* comment */ a{color:red}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b""


def test_css_short_type_name_matches_the_full_mimetype():
    """`--type css` and `--type text/css` produce identical output."""
    # CATCHES: the short name is resolved through the extension map before the
    # registry lookup, so both spellings reach the same CSS minifier and
    # return the same bytes for the same input.
    body = "a { color: red; }\n"
    short = run_minify(["--type", "css"], stdin=body.encode())
    full = run_minify(["--type", "text/css"], stdin=body.encode())
    assert short.returncode == full.returncode == 0
    assert short.stdout == full.stdout == b"a{color:red}"
    assert short.stderr == full.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{color:rgba(0, 0, 0, 0)}", b"a{color:transparent}"),
        ("a{color:rgba(255, 0, 0, 1)}", b"a{color:red}"),
        ("a{color:hsl(0, 100%, 50%)}", b"a{color:red}"),
        ("a{color:rgb(0%, 20%, 40%)}", b"a{color:#036}"),
        ("a{color:#ff0000}", b"a{color:red}"),
        ("a{color:rgb(255 0 0)}", b"a{color:red}"),
    ],
)
def test_color_notation_is_reduced_to_its_shortest_form(body, expected):
    """Color functions collapse to names, hex or transparent, whichever is shorter."""
    # CATCHES: rgba with full transparency becomes the keyword transparent, an
    # opaque rgba/hsl is converted to a name, exact percentages fold into a
    # three-digit hex, and the space-separated rgb() syntax is understood too.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_uppercase_keywords_are_not_lowercased():
    """A value written as RED keeps its case."""
    # CATCHES: values are matched case-insensitively but emitted verbatim, so
    # the output preserves the author's spelling instead of normalizing it.
    proc = minify_css("a{background:RED}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:RED}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{margin:1px 1px 1px 1px}", b"a{margin:1px}"),
        ("a{margin:1px 2px 1px 2px}", b"a{margin:1px 2px}"),
        ("a{margin:1px 2px 3px 2px}", b"a{margin:1px 2px 3px}"),
        ("a{padding:.5em .5em}", b"a{padding:.5em}"),
    ],
)
def test_box_model_shorthands_fold_equal_edges(body, expected):
    """Equal edges of a margin/padding shorthand are folded away."""
    # CATCHES: four equal values collapse to one, `t b t b` to two, `t b l b`
    # to three, and a two-value padding with equal values to one.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_font_weight_keyword_becomes_its_number():
    """font-weight:bold is rewritten as 700."""
    # CATCHES: the standalone font-weight property, like the font shorthand,
    # trades the keyword for its shorter numeric form.
    proc = minify_css("a{font-weight:bold}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{font-weight:700}"
    assert proc.stderr == b""


@pytest.mark.parametrize("body", ['@import url("foo.css");', "@import url( foo.css );"])
def test_import_url_is_normalized_to_a_string(body):
    """@import url(...) is rewritten as @import "..." with the padding gone."""
    # CATCHES: the url() wrapper is dropped for a plain quoted string, and any
    # whitespace inside the parentheses is stripped before quoting.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == b'@import "foo.css";'
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body",
    ["@import url(foo.css) screen;", '@import "foo.css";', '@charset "UTF-8";'],
    ids=["url-with-media", "string-form", "charset"],
)
def test_other_at_rule_preludes_are_untouched(body):
    """@import/@charset forms the rewriter does not recognize pass through."""
    # CATCHES: the url-to-string rewrite needs exactly two prelude values, so
    # a media query after the url, the plain string form and @charset all
    # keep their original spacing and spelling.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        (
            'a{background:url("data:text/css,a { color: red }")}',
            b"a{background:url(data:text/css,a%7Bcolor:red%7D)}",
        ),
        (
            "a{background:url('data:text/plain,hello')}",
            b"a{background:url(data:,hello)}",
        ),
        (
            'a{background:url("data:;charset=us-ascii,hello")}',
            b"a{background:url(data:,hello)}",
        ),
        (
            'a{background:url("data:text/plain;base64,aGVsbG8=")}',
            b"a{background:url(data:,hello)}",
        ),
    ],
    ids=[
        "css-minified-and-percent-encoded",
        "text-plain-prefix-stripped",
        "charset-us-ascii-stripped",
        "base64-decoded-to-percent",
    ],
)
def test_data_uris_are_minified_and_reencoded(body, expected):
    """url(data:...) payloads run through the matching minifier again."""
    # CATCHES: the inner CSS is minified (`a { color: red }` to a{color:red})
    # and percent-encoded so the url can drop its quotes, the default
    # text/plain mediatype and ;charset=us-ascii parameter are removed, and
    # base64 loses out to the shorter percent encoding.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_data_uri_with_a_nested_svg_is_minified():
    """A data:image/svg+xml URI's payload goes through the SVG minifier."""
    # CATCHES: <g></g> inside the URI collapses to <g/> and the result is
    # percent-encoded (%3C, %20, %22, %3E) with the url quotes removed,
    # showing the registry routes the nested mediatype to the SVG minifier.
    body = (
        'a{background:url("data:image/svg+xml,'
        '<svg xmlns=%22http://www.w3.org/2000/svg%22><g></g></svg>")}'
    )
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == (
        b"a{background:url(data:image/svg+xml,"
        b"%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg/%3E%3C/svg%3E)}"
    )
    assert proc.stderr == b""


def test_data_uri_with_an_unknown_mimetype_is_only_reencoded():
    """A data: URI nothing minifies keeps its payload but is re-encoded."""
    # CATCHES: text/x-bogus has no registered minifier, so the payload keeps
    # its spaces and braces, yet the URI is still rewritten without quotes
    # and with the payload percent-encoded.
    body = 'a{background:url("data:text/x-bogus,a { color: red }")}'
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:url(data:text/x-bogus,a%20%7B%20color:%20red%20%7D)}"
    assert proc.stderr == b""


def test_inline_mediatype_param_minifies_bare_declarations():
    """`--type text/css;inline=1` parses a declaration list without a selector."""
    # CATCHES: the mediatype parameter reaches the CSS minifier and switches
    # it to inline mode, so `color: red; margin: 0px` becomes
    # color:red;margin:0, while plain `--type css` can only echo the
    # selector-less text verbatim.
    body = "color: red; margin: 0px"
    inline = run_minify(["--type", "text/css;inline=1"], stdin=body.encode())
    assert inline.returncode == 0
    assert inline.stdout == b"color:red;margin:0"
    assert inline.stderr == b""
    plain = run_minify(["--type", "css"], stdin=body.encode())
    assert plain.returncode == 0
    assert plain.stdout == b"color: red; margin: 0px"
    assert plain.stderr == b""


def test_progid_dximagetransform_filter_is_shortened():
    """The legacy IE filter progid:...Microsoft.Alpha(...) becomes alpha(...)."""
    # CATCHES: the whole progid:DXImageTransform.Microsoft. prefix is cut and
    # only `alpha(opacity=...)` is kept, with the property name lowercased;
    # !important survives behind it and keeps its space only under version 2.
    proc = minify_css("a{filter:progid:DXImageTransform.Microsoft.Alpha(Opacity=50)}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{filter:alpha(opacity=50)}"
    assert proc.stderr == b""
    proc = minify_css("a{filter:progid:DXImageTransform.Microsoft.Alpha(Opacity=50) !important}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{filter:alpha(opacity=50)!important}"
    assert proc.stderr == b""
    proc = minify_css(
        "a{filter:progid:DXImageTransform.Microsoft.Alpha(Opacity=50) !important}",
        "--css-version",
        "2",
    )
    assert proc.returncode == 0
    assert proc.stdout == b"a{filter:alpha(opacity=50) !important}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], b"a{color:red!important}"),
        (["--css-version", "2"], b"a{color:red !important}"),
    ],
    ids=["css3", "css2"],
)
def test_important_keeps_its_space_under_css_version_2(flags, expected):
    """`!important` loses its preceding space only from CSS 3 on."""
    # CATCHES: --css-version 2 preserves the historical ` !important`
    # spelling while the default (version 3) removes the space.
    proc = minify_css("a{color:red !important}", *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,flags,expected",
    [
        ("a{width:1000px}", [], b"a{width:1e3px}"),
        ("a{width:1000px}", ["--css-version", "2"], b"a{width:1000px}"),
        ("a{width:1000%}", [], b"a{width:1e3%}"),
        ("a{width:1000%}", ["--css-version", "2"], b"a{width:1000%}"),
    ],
    ids=["dimension-css3", "dimension-css2", "percentage-css3", "percentage-css2"],
)
def test_exponent_notation_is_gated_on_css_version(body, flags, expected):
    """1000px and 1000% become exponent form only from CSS 3 on."""
    # CATCHES: version 3 shortens 1000 to 1e3 for dimensions and percentages
    # alike, while --css-version 2 keeps the plain decimals in both cases,
    # the core numeric difference between versions.
    proc = minify_css(body, *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_integer_valued_properties_keep_their_number_spelling():
    """z-index, orphans and widows never run through the number minifier."""
    # CATCHES: 1.50 keeps its trailing zero, 0012 keeps its leading zeroes
    # and 1e3 is not rewritten, because these properties are integers whose
    # spelling must not change.
    body = "a{z-index:1.50;orphans:0012;widows:1e3}"
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


def test_rgb_percentages_fold_into_a_hex_color():
    """rgb(20%,40%,60%) becomes the equivalent #369."""
    # CATCHES: the exact twentieths 20/40/60% map to 51/102/153, which the
    # color shortening then collapses to the three-digit hex form.
    proc = minify_css("a{color:rgb(20%,40%,60%)}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:#369}"
    assert proc.stderr == b""


def test_rgb_slash_alpha_keeps_the_function():
    """The space-separated rgb() with a slash alpha only loses padding."""
    # CATCHES: `255 0 0 / 50%` stays a function (an alpha of .5 is not
    # collapsible to a hex), the spaces around `/` vanish and 50% becomes .5.
    proc = minify_css("a{color:rgb(255 0 0 / 50%)}")
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:rgb(255 0 0/.5)}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{color:rgb(20%,40%,60%,.5)}", b"a{color:rgb(51,102,153,.5)}"),
        ("a{color:rgba(20%,40%,60%,.5)}", b"a{color:rgba(51,102,153,.5)}"),
    ],
    ids=["rgb", "rgba"],
)
def test_rgb_percentages_with_an_alpha_become_numbers(body, expected):
    """A translucent rgb() keeps its percentages only as exact integers."""
    # CATCHES: with a fourth alpha argument the function survives (no hex can
    # encode it), the exact twentieths 20/40/60% turn into 51/102/153 and the
    # rgb/rgba spelling chosen by the author is preserved.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_escaped_newlines_in_strings_and_urls_are_removed():
    """A backslash-newline continuation inside quotes is deleted."""
    # CATCHES: `"a\<newline>b"` folds to `"ab"` in a string value and the same
    # escape inside url("...") disappears as well, leaving an unquoted url(ab).
    proc = minify_css('a{content:"a\\\nb"}')
    assert proc.returncode == 0
    assert proc.stdout == b'a{content:"ab"}'
    assert proc.stderr == b""
    proc = minify_css('a{background:url("a\\\nb")}')
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:url(ab)}"
    assert proc.stderr == b""


def test_bang_comments_are_preserved_and_squeezed():
    """/*! ... */ survives with its internal whitespace collapsed."""
    # CATCHES: only comments starting with `!` are kept, and their inner runs
    # of whitespace shrink to nothing (`keep me` to `keep me` without the
    # surrounding spaces).
    proc = minify_css("/*! keep me */a{color:red}")
    assert proc.returncode == 0
    assert proc.stdout == b"/*!keep me*/a{color:red}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{--x: ;color:red}", b"a{--x: ;color:red}"),
        ("a{--x:}", b"a{--x:}"),
    ],
    ids=["space-only-value", "empty-value"],
)
def test_custom_property_values_keep_their_shape(body, expected):
    """A whitespace-only custom property value stays a single space."""
    # CATCHES: `--x: ` is not trimmed to nothing; the value keeps exactly one
    # space (so the semicolon stays separated), and `--x:` with no value at
    # all is equally legal and unchanged.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_selector_attribute_quoting_rules():
    """Attribute selector values unquote only when they are identifiers."""
    # CATCHES: `"foo bar"` needs its quotes (a space is not an identifier)
    # while `"FOO"` loses them, and the case-insensitive ` i` flag keeps its
    # mandatory space before the bracket closes.
    proc = minify_css('a[href="foo bar"]{color:red}')
    assert proc.returncode == 0
    assert proc.stdout == b'a[href="foo bar"]{color:red}'
    assert proc.stderr == b""
    proc = minify_css('a[href="FOO" i]{color:red}')
    assert proc.returncode == 0
    assert proc.stdout == b"a[href=FOO i]{color:red}"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("a{content:\"x", b'a{content:"x}'),
        ("a{color:red", b"a{color:red}"),
    ],
    ids=["unterminated-string", "unterminated-block"],
)
def test_unterminated_constructs_are_tolerated(body, expected):
    """Truncated CSS is echoed and closed, never a failed run."""
    # CATCHES: an unterminated string keeps its bytes but still gains the
    # closing brace the minifier adds for the ruleset, with exit code 0.
    proc = minify_css(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_url_option_leaves_relative_urls_alone():
    """--url is accepted but does not rewrite url() references."""
    # CATCHES: the flag parses and the run succeeds, yet url(foo.png) is
    # emitted unchanged, so URL rewriting is not part of the CSS route.
    proc = run_minify(
        ["--type", "css", "--url", "http://example.com/"],
        stdin=b"a{background:url(foo.png)}",
    )
    assert proc.returncode == 0
    assert proc.stdout == b"a{background:url(foo.png)}"
    assert proc.stderr == b""
