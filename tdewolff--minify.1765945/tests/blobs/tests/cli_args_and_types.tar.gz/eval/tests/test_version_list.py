"""--version and --list: what they print, and how --quiet silences them.

`--version` and `--list` are handled before any argument validation, so they
win over bad `--type` values and over missing inputs; both are suppressed by
`--quiet`.  The version stamp itself is build metadata (the reference prints
`minify 1765945`, a coverage build of the same tree prints `minify built from
source`), so only its shape is pinned here.
"""

import re

import pytest

from conftest import EXT_MAP, LIST_OUTPUT, USAGE, run_minify

# The reference prints `minify <stamp>`; the stamp is build metadata.  The
# released reference prints a single token (`minify 1765945`) while a coverage
# build of the same tree prints `minify built from source`, so the pinned shape
# is: the program name, one space, then a non-empty stamp of non-space words,
# and nothing else on the line.
VERSION_RE = re.compile(rb"^minify \S+( \S+)*\n$")


def test_version_prints_program_name_and_stamp():
    """--version prints `minify <stamp>` on stdout and exits 0."""
    # CATCHES: the line starts with the program name (not argv[0], which is
    # `minify` here), carries one non-space stamp and nothing else.
    proc = run_minify(["--version"])
    assert proc.returncode == 0
    assert VERSION_RE.match(proc.stdout) is not None
    assert proc.stderr == b""


def test_quiet_suppresses_version_output():
    """-q silences --version entirely while still exiting 0."""
    # CATCHES: the reference checks --quiet before printing the version, so
    # `-q --version` produces no stdout at all instead of the version line.
    loud = run_minify(["--version"])
    quiet = run_minify(["--quiet", "--version"])
    assert loud.stdout != b""
    assert quiet.returncode == 0
    assert quiet.stdout == b""
    assert quiet.stderr == b""
    assert run_minify(["--version", "-q"]).stdout == b""


def test_version_beats_list_and_type_validation():
    """--version is handled before --list and before filetype resolution."""
    # CATCHES: a reimplementation that resolves --type first would fail on the
    # bogus filetype instead of printing the version.
    for extra in (["--list"], ["--type", "bogus"], ["--type", "text/plain"]):
        proc = run_minify(["--version"] + extra)
        assert proc.returncode == 0
        assert VERSION_RE.match(proc.stdout) is not None
        assert proc.stderr == b""


def test_version_with_input_files_still_prints_version(tmp_path):
    """Positional inputs do not stop --version from being handled."""
    # CATCHES: a reimplementation that runs the minify tasks before looking at
    # --version would try to open the file instead.
    (tmp_path / "a.css").write_bytes(b"a { color: red; }\n")
    proc = run_minify(["--version", "a.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert VERSION_RE.match(proc.stdout) is not None
    assert proc.stderr == b""


@pytest.mark.parametrize("flag", ["--list", "-l"])
def test_list_prints_the_sorted_extension_table(flag):
    """--list prints every built-in extension, sorted, in one aligned column."""
    # CATCHES: the exact table, its sort order and its column width (widest
    # extension `webmanifest` plus two spaces).
    proc = run_minify([flag])
    assert proc.returncode == 0
    assert proc.stdout == LIST_OUTPUT
    assert proc.stderr == b""


def test_list_rows_are_sorted_and_column_aligned():
    """Each row is `<ext>` padded to the widest extension plus two spaces."""
    # CATCHES: a reimplementation that pads to a fixed width, or that sorts the
    # mimetypes instead of the extensions, produces different bytes.
    proc = run_minify(["--list"])
    rows = proc.stdout.decode().splitlines()
    assert len(rows) == len(EXT_MAP)
    extensions = [row[:11].rstrip() for row in rows]
    assert extensions == sorted(ext for ext, _ in EXT_MAP)
    for row, (ext, mime) in zip(rows, EXT_MAP):
        assert row == ext.ljust(13) + mime


def test_quiet_suppresses_list_output():
    """-q silences --list entirely while still exiting 0."""
    # CATCHES: like --version, --list is gated on --quiet, so nothing at all is
    # printed for `-q --list` even though the same invocation without -q prints
    # the full recorded table.
    loud = run_minify(["--list"])
    assert loud.returncode == 0
    assert loud.stdout == LIST_OUTPUT
    assert loud.stderr == b""
    for argv in (["--quiet", "--list"], ["--list", "--quiet"], ["-q", "-l"]):
        quiet = run_minify(argv)
        assert quiet.returncode == 0
        assert quiet.stdout == b""
        assert quiet.stderr == b""


def test_list_beats_type_validation():
    """--list is printed even when --type names an unknown filetype."""
    # CATCHES: the extension table is printed before the filetype is resolved,
    # so a bad --type must not be reported here.
    proc = run_minify(["--list", "--type", "bogus"])
    assert proc.returncode == 0
    assert proc.stdout == LIST_OUTPUT
    assert proc.stderr == b""


def test_list_with_ext_option_inserts_the_new_extension():
    """--ext.scss=text/css adds scss in sorted position, same column width."""
    # CATCHES: the added row is merged into the sorted table rather than
    # appended, and the column width stays tied to `webmanifest`.
    proc = run_minify(["--ext.scss=text/css", "--list"])
    assert proc.returncode == 0
    assert proc.stdout.decode().splitlines()[13] == "scss         text/css"
    assert proc.stdout.decode().splitlines()[14] == "svg          image/svg+xml"
    assert len(proc.stdout.decode().splitlines()) == 19


def test_list_with_braced_ext_map_matches_dotted_form():
    """--ext {scss:text/css} and --ext.scss=text/css give the same table."""
    # CATCHES: the two accepted spellings of a map value must be equivalent,
    # and both must merge scss into the built-in table in sorted position with
    # the column width still derived from webmanifest.
    merged = dict(EXT_MAP)
    merged["scss"] = "text/css"
    expected = "".join(
        ext.ljust(13) + merged[ext] + "\n" for ext in sorted(merged)
    ).encode()
    dotted = run_minify(["--ext.scss=text/css", "--list"])
    braced = run_minify(["--ext", "{scss:text/css}", "--list"])
    assert dotted.returncode == braced.returncode == 0
    assert dotted.stdout == expected
    assert braced.stdout == expected
    assert braced.stderr == b""


def test_list_with_braced_map_spanning_argv_tokens():
    """A brace map split across argv tokens yields one entry per `key:value`."""
    # CATCHES: the brace form is scanned across argument boundaries, so
    # `{a:b c:d e:f}` delivered as three argv tokens produces three separate
    # extensions, each merged into the sorted table.
    proc = run_minify(["--ext", "{a:b", "c:d", "e:f}", "--list"])
    assert proc.returncode == 0
    rows = proc.stdout.decode().splitlines()
    assert rows[0] == "a            b"
    assert rows[2] == "c            d"
    assert rows[4] == "e            f"
    assert rows[1] == "asp          text/asp"
    assert len(rows) == 21


def test_list_with_braced_map_inside_one_argv_token():
    """A brace map inside one argv token keeps the spaces in the value."""
    # CATCHES: inside a single token the space is not a separator, so only the
    # first `key:value` becomes an entry and the rest lands in its value.
    proc = run_minify(["--ext", "{a:b c:d e:f}", "--list"])
    assert proc.returncode == 0
    rows = proc.stdout.decode().splitlines()
    assert rows[0] == "a            b c:d e:f"
    assert rows[1] == "asp          text/asp"
    assert len(rows) == 19


def test_list_widens_the_column_for_a_longer_extension():
    """A new longest extension widens the whole table column."""
    # CATCHES: the padding is `max(len(ext)) + 2`, recomputed over the merged
    # map, so a 17-character extension pushes every mimetype 6 columns right.
    proc = run_minify(["--ext", "{verylongextension:text/css}", "--list"])
    assert proc.returncode == 0
    rows = proc.stdout.decode().splitlines()
    assert rows[0] == "asp                text/asp"
    assert rows[15] == "verylongextension  text/css"
    assert rows[16] == "webmanifest        application/manifest+json"
    assert all(row[18] == " " or row == "" for row in rows if row)


def test_list_resolves_an_ext_value_through_the_extension_map():
    """--ext.scss=css stores the mimetype that `css` already maps to."""
    # CATCHES: when the value of an --ext entry is itself a known extension it
    # is translated through the built-in map before being stored.
    proc = run_minify(["--ext.scss=css", "--list"])
    assert proc.returncode == 0
    assert proc.stdout.decode().splitlines()[13] == "scss         text/css"


def test_list_overrides_an_existing_extension():
    """--ext.css=text/html replaces the built-in mapping for that extension."""
    # CATCHES: --ext overrides rather than only adds, and the row keeps its
    # original place in the sorted table.
    proc = run_minify(["--ext.css=text/html", "--list"])
    assert proc.returncode == 0
    rows = proc.stdout.decode().splitlines()
    assert rows[1] == "css          text/html"
    assert rows[5] == "htm          text/html"


def test_list_keeps_an_unknown_ext_value_verbatim():
    """--ext.scss=importmap stores the raw string, unmapped and unvalidated."""
    # CATCHES: only values that are known extensions are translated; anything
    # else is stored verbatim, even when it is not a mimetype with a slash.
    proc = run_minify(["--ext.scss=importmap", "--list"])
    assert proc.returncode == 0
    assert proc.stdout.decode().splitlines()[13] == "scss         importmap"


def test_list_with_empty_braced_map_changes_nothing():
    """--ext {} is accepted as an empty map and leaves the table untouched."""
    # CATCHES: an empty brace pair is valid syntax, not an `invalid map` error.
    proc = run_minify(["--ext", "{}", "--list"])
    assert proc.returncode == 0
    assert proc.stdout == LIST_OUTPUT
    assert proc.stderr == b""
