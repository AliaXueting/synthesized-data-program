"""The `--svg-*` options and SVG minification as reached through the CLI.

This module pins the plumbing of the per-format flags (`--svg-precision`,
`--svg-keep-comments`, `--svg-keep-namespaces`) and the behaviours of the SVG
minifier that the `--type svg` / `.svg` / `image/svg+xml` routes select:
embedded CSS in `<style>` and `style="..."`, the mimetype-parameter bypass,
dimension/viewBox/color/path shortening, namespace skipping, and the exact
quoting and tag-collapsing rules.  Every expected byte sequence was recorded
by running `./executable`.
"""

import pytest

from conftest import USAGE, run_minify, write_file


def minify_svg(body, *flags):
    """Run the reference with --type svg and return the CompletedProcess."""
    return run_minify(["--type", "svg", *flags], stdin=body.encode())


def test_svg_route_short_name_full_mimetype_and_extension(tmp_path):
    """`--type svg`, `--type image/svg+xml` and a `.svg` file agree."""
    # CATCHES: the short name is resolved through the extension map, the full
    # mimetype through the literal registry, and the file through its `.svg`
    # suffix; all three must land in the SVG minifier and emit equal bytes.
    body = '<svg xmlns="http://www.w3.org/2000/svg"><g>  </g></svg>'
    expected = b'<svg xmlns="http://www.w3.org/2000/svg"><g/></svg>'
    short = run_minify(["--type", "svg"], stdin=body.encode())
    full = run_minify(["--type", "image/svg+xml"], stdin=body.encode())
    src = write_file(tmp_path, "a.svg", body)
    via_file = run_minify([src.name], cwd=tmp_path)
    assert short.returncode == full.returncode == via_file.returncode == 0
    assert short.stdout == full.stdout == via_file.stdout == expected
    assert short.stderr == full.stderr == via_file.stderr == b""


def test_default_svg_attributes_are_dropped():
    """Redundant attributes of the root <svg> tag disappear."""
    # CATCHES: version=1.1, x=0, y=0, preserveAspectRatio=xMidYMid meet,
    # baseProfile=none, contentScriptType and contentStyleType=text/css are
    # all defaults and are removed, while xmlns survives.
    body = (
        '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" x="0" y="0"'
        ' preserveAspectRatio="xMidYMid meet" baseProfile="none"'
        ' contentScriptType="application/ecmascript"'
        ' contentStyleType="text/css"><rect/></svg>'
    )
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><rect/></svg>'
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "version,expected",
    [
        ('version="1.1"', b"<svg><rect/></svg>"),
        ('version="1.1 "', b"<svg><rect/></svg>"),
        ('version="1.0"', b'<svg version="1.0"><rect/></svg>'),
    ],
    ids=["one-dot-one", "trailing-space", "one-dot-zero"],
)
def test_version_attribute_removal_depends_on_the_value(version, expected):
    """Only version="1.1" (after value trimming) is treated as the default."""
    # CATCHES: the attribute value is whitespace-trimmed before comparison, so
    # `1.1 ` is removed too, while 1.0 survives with its spelling untouched
    # (the version attribute is exempt from number shortening).
    proc = minify_svg("<svg %s><rect/></svg>" % version)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_zero_x_and_y_survive_on_non_svg_tags():
    """x="0" and y="0" are only defaults on the root <svg> tag."""
    # CATCHES: the zero-coordinate removal is keyed on the tag name, so the
    # same attributes on <rect> are kept verbatim.
    proc = minify_svg('<svg><rect x="0" y="0"/></svg>')
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><rect x="0" y="0"/></svg>'
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "inner",
    ["<g></g>", "<g>   </g>", "<g>\n</g>"],
    ids=["no-content", "spaces", "newline"],
)
def test_empty_elements_collapse_to_void_tags(inner):
    """An element with only whitespace text becomes a self-closing tag."""
    # CATCHES: `<g></g>` and `<g>   </g>` both collapse to `<g/>`, so the
    # whitespace-only text token between the tags is dropped, not kept.
    proc = minify_svg("<svg>%s</svg>" % inner)
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><g/></svg>"
    assert proc.stderr == b""


def test_whitespace_between_tags_is_dropped():
    """Padding around child elements disappears entirely."""
    # CATCHES: inter-tag whitespace is trimmed to nothing rather than
    # collapsed to a single space or newline.
    proc = minify_svg("<svg>\n   <rect/>\n   <circle/>\n</svg>")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><rect/><circle/></svg>"
    assert proc.stderr == b""


def test_style_element_is_minified_as_css():
    """The text of <style> runs through the CSS minifier."""
    # CATCHES: `a { color: red; }` inside <style> becomes `a{color:red}`,
    # the type="text/css" attribute is dropped as the default, while another
    # attribute such as media survives.
    proc = minify_svg("<svg><style>a { color: red; }</style></svg>")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><style>a{color:red}</style></svg>"
    assert proc.stderr == b""
    proc = minify_svg('<svg><style type="text/css">a{color:red}</style></svg>')
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><style>a{color:red}</style></svg>"
    assert proc.stderr == b""
    proc = minify_svg('<svg><style media="screen">a { color: red }</style></svg>')
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><style media="screen">a{color:red}</style></svg>'
    assert proc.stderr == b""


def test_style_attribute_is_minified_as_inline_css():
    """A style="..." attribute value is minified as an inline declaration list."""
    # CATCHES: the attribute runs through the CSS minifier in inline mode,
    # squeezing `fill: red; stroke: blue` to `fill:red;stroke:blue`.
    proc = minify_svg('<svg><rect style="fill: red; stroke: blue"/></svg>')
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><rect style="fill:red;stroke:blue"/></svg>'
    assert proc.stderr == b""


def test_content_style_type_is_lowercased_and_kept():
    """A non-default contentStyleType is normalized but not removed."""
    # CATCHES: `TEXT/CSS` fails the literal default check, is kept, and is
    # rewritten by the mediatype minifier to lowercase `text/css` while the
    # <style> body is still minified as CSS.
    proc = minify_svg('<svg contentStyleType="TEXT/CSS"><style>a { color: red }</style></svg>')
    assert proc.returncode == 0
    assert proc.stdout == b'<svg contentStyleType="text/css"><style>a{color:red}</style></svg>'
    assert proc.stderr == b""


def test_content_style_type_text_plain_disables_style_minification():
    """Pointing contentStyleType at an unminified mimetype keeps the CSS verbatim."""
    # CATCHES: <style> is routed to whatever mimetype contentStyleType names,
    # so text/plain (no registered minifier) leaves `a { color: red }` as-is.
    body = '<svg contentStyleType="text/plain"><style>a { color: red }</style></svg>'
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


def test_style_cdata_is_minified_and_unwrapped():
    """CDATA inside <style> is minified and the wrapper is dropped."""
    # CATCHES: the CDATA section's payload is minified as CSS and, because the
    # result needs no escaping, written as plain text without `<![CDATA[`.
    proc = minify_svg("<svg><style><![CDATA[a { color: red; }]]></style></svg>")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><style>a{color:red}</style></svg>"
    assert proc.stderr == b""


def test_text_cdata_is_escaped_and_trimmed():
    """CDATA in normal text is trimmed and re-escaped as plain text."""
    # CATCHES: the CDATA payload keeps its `<` only in escaped form and loses
    # its surrounding whitespace: `  a  <  b  ` becomes `a &lt; b`.
    proc = minify_svg("<svg><text><![CDATA[  a  <  b  ]]></text></svg>")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><text>a &lt; b</text></svg>"
    assert proc.stderr == b""


def test_named_entities_stay_and_numeric_refs_decode():
    """Named entities in text survive; numeric character references decode."""
    # CATCHES: `&amp;`/`&lt;`/`&gt;` are kept spelled out while `&#65;` is
    # replaced by the raw character `A`.
    proc = minify_svg("<svg><text>a &amp; b &lt; c &gt; d</text><text>x&#65;y</text></svg>")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><text>a &amp; b &lt; c &gt; d</text><text>xAy</text></svg>"
    assert proc.stderr == b""


def test_xml_space_preserve_is_removed():
    """xml:space="preserve" is dropped and the text is collapsed anyway."""
    # CATCHES: the attribute is a recognized default that disappears, so
    # `a  b` collapses to `a b` even though the source asked to preserve it.
    proc = minify_svg('<svg><text xml:space="preserve">a  b</text></svg>')
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><text>a b</text></svg>"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "value,expected",
    [
        ("0 0 100.50 50.0", b"0 0 100.5 50"),
        ("0,0,100.50,50", b"0 0 100.5 50"),
        ("abc", b"abc"),
        ("0 0 100", b"0 0 100"),
    ],
    ids=["trailing-zeros", "commas", "garbage", "three-values"],
)
def test_viewbox_is_normalized(value, expected):
    """viewBox numbers are shortened and commas become spaces."""
    # CATCHES: each of the four dimensions is shortened independently
    # (`100.50` to `100.5`, `50.0` to `50`), comma separators are rewritten to
    # spaces, and a non-numeric value is passed through untouched.
    proc = minify_svg('<svg viewBox="%s"></svg>' % value)
    assert proc.returncode == 0
    assert proc.stdout == b'<svg viewBox="%s"/>' % expected
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "attr,value,expected",
    [
        ("width", "100px", b"100"),
        ("height", "1000", b"1e3"),
        ("width", "10PT", b"10pt"),
        ("height", "10Px", b"10px"),
        ("stroke-width", "0em", b"0"),
        ("height", "0.50pt", b".5pt"),
        ("x", "-0.5", b"-.5"),
    ],
    ids=[
        "px-unit-dropped",
        "exponent-introduced",
        "uppercase-unit-lowercased",
        "mixed-case-unit",
        "zero-loses-unit",
        "leading-zero-dropped",
        "negative-leading-zero",
    ],
)
def test_dimension_attributes_are_shortened(attr, value, expected):
    """Whole-value dimensions are number-minified with unit rules."""
    # CATCHES: the px unit is removed, other units are lowercased, a zero
    # drops its unit, leading zeroes vanish, and 1000 becomes the shorter
    # exponent form 1e3 while 100 stays decimal.
    proc = minify_svg('<svg><rect %s="%s"/></svg>' % (attr, value))
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><rect %s="%s"/></svg>' % (attr.encode(), expected)
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "attr,value,expected",
    [
        ("fill", "#ff0000", b"red"),
        ("fill", "#ff00ff", b"#f0f"),
        ("fill", "#aabbcc", b"#abc"),
        ("stroke", "#112233", b"#123"),
        ("stroke", "aliceblue", b"#f0f8ff"),
        ("fill", "url(#g)", b"url(#g)"),
        ("fill", "RED", b"RED"),
    ],
    ids=[
        "hex-to-name",
        "hex-pairs-fold",
        "hex-pairs-fold-2",
        "hex-pairs-fold-3",
        "name-to-hex",
        "url-untouched",
        "case-sensitive",
    ],
)
def test_color_attributes_take_their_shortest_spelling(attr, value, expected):
    """Known colors flip to whichever spelling is shorter; unknowns stay."""
    # CATCHES: #ff0000 becomes the name red, a seven-digit hex whose digit
    # pairs repeat folds to three digits (#aabbcc to #abc), aliceblue becomes
    # the shorter hex #f0f8ff, url(...) paint servers are left alone, and the
    # name lookup is case-sensitive so RED survives verbatim.
    proc = minify_svg('<svg><rect %s="%s"/></svg>' % (attr, value))
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><rect %s="%s"/></svg>' % (attr.encode(), expected)
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "path,expected",
    [
        ("M 10 10 L 20.50 20 Z", b"M10 10 20.5 20z"),
        ("M 10 10 A 5 5 0 1 0 20 20 z", b"M10 10A5 5 0 1020 20z"),
    ],
    ids=["line-merged", "arc-flags-squeezed"],
)
def test_path_data_is_shortened(path, expected):
    """The d attribute is compacted by the path data minifier."""
    # CATCHES: implicit line-to continuation drops the `L`, the trailing `Z`
    # is lowercased, numbers lose padding, and the arc's flag arguments
    # `1 0` merge into `1020` with no separators at all.
    proc = minify_svg('<svg><path d="%s"/></svg>' % path)
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><path d="%s"/></svg>' % expected
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "precision,expected",
    [
        (None, b"M1.23456789012345 2"),
        ("0", b"M1.23456789012345 2"),
        ("3", b"M1.23 2"),
        ("16", b"M1.23456789012345 2"),
        ("-2", b"M1.23456789012345 2"),
    ],
    ids=["default", "zero", "three", "over-fifteen", "negative"],
)
def test_svg_precision_rounds_path_numbers(precision, expected):
    """--svg-precision caps significant digits; 0, >15 and negative mean all."""
    # CATCHES: 3 keeps `1.23`, while the default, an explicit 0, a value above
    # the 15-digit double limit and a negative value all keep every digit.
    flags = [] if precision is None else ["--svg-precision", precision]
    proc = minify_svg('<svg><path d="M1.23456789012345 2"/></svg>', *flags)
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><path d="%s"/></svg>' % expected
    assert proc.stderr == b""


def test_svg_precision_also_rounds_dimension_attributes():
    """--svg-precision applies to attribute numbers, not just path data."""
    # CATCHES: width="1.23456789" becomes 1.2 under precision 2, proving the
    # flag feeds the same number shortening used for the d attribute.
    proc = minify_svg('<svg><rect width="1.23456789"/></svg>', "--svg-precision", "2")
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><rect width="1.2"/></svg>'
    assert proc.stderr == b""


def test_comments_are_dropped_unless_keep_comments():
    """<!-- --> vanishes by default and survives with --svg-keep-comments."""
    # CATCHES: the flag is the only way to keep a comment, and with it the
    # comment bytes are emitted verbatim between the tags.
    proc = minify_svg("<svg><!-- hello --><rect/></svg>")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><rect/></svg>"
    assert proc.stderr == b""
    proc = minify_svg("<svg><!-- hello --><rect/></svg>", "--svg-keep-comments")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><!-- hello --><rect/></svg>"
    assert proc.stderr == b""


def test_metadata_element_is_skipped():
    """A <metadata> element and its contents are removed entirely."""
    # CATCHES: the whole subtree disappears, including nested paired tags and
    # their children, not just the metadata tags themselves.
    proc = minify_svg("<svg><metadata>keep me <x><y/>deep</x></metadata><rect/></svg>")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><rect/></svg>"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "prologue",
    [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<?xml-stylesheet href="a.css" type="text/css"?>',
    ],
    ids=["xml-declaration", "xml-stylesheet"],
)
def test_processing_instructions_are_skipped(prologue):
    """<? ... ?> processing instructions before the root are dropped."""
    # CATCHES: both the XML declaration and an xml-stylesheet PI disappear
    # completely rather than being passed through or minified.
    proc = minify_svg(prologue + "<svg><rect/></svg>")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><rect/></svg>"
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "doctype,expected",
    [
        (
            '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" '
            '"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">',
            b"",
        ),
        ('<!DOCTYPE svg [ <!ENTITY x "y"> ]>', b'<!DOCTYPE svg [ <!ENTITY x "y"> ]>'),
    ],
    ids=["external-dtd-dropped", "internal-subset-kept"],
)
def test_doctype_is_kept_only_with_an_internal_subset(doctype, expected):
    """A DOCTYPE survives verbatim only when it ends with an internal subset."""
    # CATCHES: the plain PUBLIC DOCTYPE is removed, while one whose text ends
    # in `]` (an internal DTD subset) is copied through byte for byte,
    # internal whitespace included.
    proc = minify_svg(doctype + "<svg><rect/></svg>")
    assert proc.returncode == 0
    assert proc.stdout == expected + b"<svg><rect/></svg>"
    assert proc.stderr == b""


def test_foreign_namespace_tags_and_attributes_are_skipped():
    """inkscape-namespaced tags and attributes disappear by default."""
    # CATCHES: both the <inkscape:custom> element (with its children) and the
    # inkscape:label attribute are dropped, along with the xmlns:inkscape
    # declaration itself.
    body = (
        '<svg xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape">'
        '<inkscape:custom x="1"/><rect inkscape:label="hi"/></svg>'
    )
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><rect/></svg>"
    assert proc.stderr == b""


def test_keep_namespaces_rescues_a_namespace():
    """--svg-keep-namespaces keeps the named namespace's tags and attributes."""
    # CATCHES: with the flag, <inkscape:custom>, its x attribute, the
    # inkscape:label attribute and the xmlns declaration all survive verbatim.
    body = (
        '<svg xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape">'
        '<inkscape:custom x="1"/><rect inkscape:label="hi"/></svg>'
    )
    proc = minify_svg(body, "--svg-keep-namespaces", "inkscape")
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


def test_keep_namespaces_takes_one_value_per_occurrence():
    """The flag is a plain list option: a second bare token is an input file."""
    # CATCHES: repeating the flag keeps two namespaces, but `ink sodi` in one
    # occurrence leaves `sodi` as the only positional input, so stdin is never
    # read: stdout is empty, the missing file is only an ERROR line, and the
    # exit code stays 0.
    body = '<svg xmlns:ink="http://i" xmlns:sodi="http://s"><ink:a sodi:b="1"/><rect/></svg>'
    proc = minify_svg(
        body,
        "--svg-keep-namespaces",
        "ink",
        "--svg-keep-namespaces",
        "sodi",
    )
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""

    proc = run_minify(
        ["--type", "svg", "--svg-keep-namespaces", "ink", "sodi"],
        stdin=body.encode(),
    )
    assert proc.returncode == 0
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: stat sodi: no such file or directory\n"


def test_keep_namespaces_without_a_value_is_a_usage_error():
    """A trailing --svg-keep-namespaces is a typed-option usage error."""
    # CATCHES: the slice option demands a value, so the run exits 2 with the
    # option's name in the message and the usage screen on stdout.
    proc = run_minify(["--type", "svg", "--svg-keep-namespaces"])
    assert proc.returncode == 2
    assert proc.stderr == b"option --svg-keep-namespaces: missing value\n\n"
    assert proc.stdout == USAGE


def test_xlink_namespace_is_kept_by_default():
    """xlink is the one namespace kept without any flag."""
    # CATCHES: xlink:href and the xmlns:xlink declaration survive without
    # --svg-keep-namespaces because xlink is the built-in keep entry.
    body = '<svg xmlns:xlink="http://www.w3.org/1999/xlink"><a xlink:href="foo"/></svg>'
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


def test_svg_prefix_is_stripped_from_start_tags_only():
    """`svg:` disappears from start tags but stays on the end tag."""
    # CATCHES: <svg:svg> and <svg:rect> are rewritten to <svg> and <rect>
    # (with width="4px" shortened to 4) while the closing </svg:svg> keeps
    # its prefix, exactly as the reference emits it.
    body = '<svg:svg xmlns:svg="http://www.w3.org/2000/svg"><svg:rect width="4px"/></svg:svg>'
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><rect width=\"4\"/></svg:svg>"
    assert proc.stderr == b""


def test_foreign_object_content_passes_through_verbatim():
    """Whatever sits inside <foreignObject> is printed unminified."""
    # CATCHES: the embedded HTML keeps its doubled spaces and padding because
    # the foreignObject subtree is echoed raw instead of being minified, and a
    # nested <foreignObject> is treated the same way.
    body = '<svg><foreignObject><div   class="x">hi  there</div></foreignObject></svg>'
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""
    nested = (
        "<svg><foreignObject><foreignObject>"
        '<div   class="x">hi  there</div>'
        "</foreignObject></foreignObject></svg>"
    )
    proc = minify_svg(nested)
    assert proc.returncode == 0
    assert proc.stdout == nested.encode()
    assert proc.stderr == b""


def test_valueless_attribute_gets_an_empty_value():
    """An attribute with no value comes back as name="". """
    # CATCHES: `<rect required/>` is not an error; it is normalized to
    # `required=""` rather than dropped or passed through bare.
    proc = minify_svg("<svg><rect required/></svg>")
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><rect required=""/></svg>'
    assert proc.stderr == b""


def test_attribute_quotes_follow_the_value():
    """The quote character is chosen per value to avoid escaping."""
    # CATCHES: a value containing a single quote keeps double quotes and a
    # value containing a double quote keeps single quotes, so neither is
    # rewritten to a &quot;/&apos; escape.
    body = "<svg><rect fill=\"it's\" other='say \"hi\"'/></svg>"
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "body,expected",
    [
        ("<svg><g >a</g ><rect/></svg>", b"<svg><g>a</g><rect/></svg>"),
        ("<svg><g  ><a/></g  ></svg>", b"<svg><g><a/></g></svg>"),
    ],
    ids=["end-tag-space", "both-sides-doubled"],
)
def test_tag_punctuation_spaces_are_trimmed(body, expected):
    """Spaces before `>` in a tag are removed from start and end tags."""
    # CATCHES: `<g >` and `</g >` lose their padding (also when doubled),
    # and the element is not collapsed to a void tag because it has content.
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_content_after_the_root_survives():
    """Trailing text after the closing root tag is still written."""
    # CATCHES: `abc` after </svg> is neither an error nor dropped; it is
    # appended to the output and the run still exits 0.
    proc = minify_svg("<svg><rect/></svg>abc")
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><rect/></svg>abc"
    assert proc.stderr == b""


def test_truncated_style_tag_is_tolerated():
    """Input ending inside the closing </style tag is echoed, not failed."""
    # CATCHES: the unterminated tag is no parse error: the CSS minified so
    # far is written and the partial `</style` remainder is copied verbatim
    # with exit code 0.
    body = "<svg><style>a{color:red}</style"
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == body.encode()
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "css,expected",
    [
        ("}", b"}"),
        ("a{color:", b"a{color:}"),
    ],
    ids=["stray-brace", "valueless-colon"],
)
def test_style_parse_errors_are_copied_verbatim(css, expected):
    """CSS the parser rejects inside <style> is written out unchanged."""
    # CATCHES: a parse error does not fail the SVG run (exit 0) and the
    # offending declaration is passed through byte for byte, with a closing
    # brace still added for the ruleset.
    proc = minify_svg("<svg><style>%s</style><rect/></svg>" % css)
    assert proc.returncode == 0
    assert proc.stdout == b"<svg><style>%s</style><rect/></svg>" % expected
    assert proc.stderr == b""


def test_inline_mediatype_param_removes_the_xmlns_attribute():
    """`--type image/svg+xml;inline=1` switches the SVG minifier to inline mode."""
    # CATCHES: the mediatype parameter is parsed out of --type and reaches the
    # minifier, whose inline mode treats xmlns as removable; without the
    # parameter the attribute stays.
    body = '<svg xmlns="http://www.w3.org/2000/svg"><rect/></svg>'
    plain = run_minify(["--type", "image/svg+xml"], stdin=body.encode())
    assert plain.returncode == 0
    assert plain.stdout == body.encode()
    inline = run_minify(["--type", "image/svg+xml;inline=1"], stdin=body.encode())
    assert inline.returncode == 0
    assert inline.stdout == b"<svg><rect/></svg>"
    assert inline.stderr == b""


def test_data_uri_inside_a_style_attribute_is_minified():
    """A data:text/css URI in a style attribute is minified and re-encoded."""
    # CATCHES: the inline CSS minifier routes the URI through the data-URI
    # minifier (inner CSS squeezed to a{color:red}), percent-encodes the
    # braces, and drops the now-needless quotes around the url.
    body = "<svg><rect style='background:url(\"data:text/css,a { color: red }\")'/></svg>"
    proc = minify_svg(body)
    assert proc.returncode == 0
    assert proc.stdout == b'<svg><rect style="background:url(data:text/css,a%7Bcolor:red%7D)"/></svg>'
    assert proc.stderr == b""
