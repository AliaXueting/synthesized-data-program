"""Option syntax: how a value is attached to an option, and how it is typed.

Covers the long (`--opt value`, `--opt=value`), short (`-o value`, `-ovalue`,
`-o=value`) and clustered (`-qv`) spellings, the counted `-v` flag, options that
take a list or a map, and the diagnostics produced when a value has the wrong
shape for the option's type.
"""

import re

import pytest

from conftest import USAGE, assert_stats_line, run_minify, write_file

CSS = b"a { color: red; }\n"


@pytest.fixture
def css_file(tmp_path):
    return write_file(tmp_path, "a.css", CSS)


@pytest.mark.parametrize(
    "argv",
    [
        ["--output", "out.css"],
        ["--output=out.css"],
        ["-o", "out.css"],
        ["-oout.css"],
        ["-o=out.css"],
    ],
)
def test_every_value_spelling_writes_the_same_file(argv, tmp_path, css_file):
    """`--opt value`, `--opt=value`, `-o value`, `-ovalue`, `-o=value` agree."""
    # CATCHES: a glued short value must not keep the `=` (`-o=x` writes `x`,
    # not `=x`), and a long option must accept both spellings.
    proc = run_minify(argv + ["a.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert_stats_line(proc.stdout, "a.css", "out.css", "18 B", "12 B", "66.7%")
    assert proc.stderr == b""
    assert (tmp_path / "out.css").read_bytes() == b"a{color:red}"


@pytest.mark.parametrize(
    "cluster,count",
    [
        ("-qv", b"1"),
        ("-vq", b"1"),
        ("-vqv", b"2"),
        ("-qvv", b"2"),
    ],
)
def test_clustered_short_flags_are_all_recognised(cluster, count):
    """`-qv`, `-vq`, `-vqv`, `-qvv`: every letter in a cluster is parsed."""
    # CATCHES: a cluster must fall through to the next letter when a flag takes
    # no value, and repeated letters each count, which the echoed `--verbose=N`
    # value in the usage screen makes directly observable: the help text is the
    # recorded usage with only that one line changed.
    proc = run_minify([cluster, "--help"])
    assert proc.returncode == 0
    expected = USAGE.replace(
        b"  -v, --verbose int           Verbose mode, set twice for more verbosity",
        b"  -v, --verbose=" + count + b" int         Verbose mode, set twice for more verbosity",
    )
    assert proc.stdout == expected
    assert proc.stderr == b""


def test_clustered_flags_still_run_a_real_minification(tmp_path, css_file):
    """`-qv` on a real run applies -q (no progress line) and still writes."""
    # CATCHES: the cluster must not stop -q from suppressing the progress line
    # while the minified file is still produced, so the output file holds the
    # recorded bytes and stdout stays completely empty.
    proc = run_minify(["-qv", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b""
    assert proc.stderr == b""
    assert (tmp_path / "out.css").read_bytes() == b"a{color:red}"


def test_equals_false_turns_a_boolean_flag_off(tmp_path, css_file):
    """`--quiet=false` leaves the progress line enabled."""
    # CATCHES: boolean options accept an explicit value, so `=false` must clear
    # the flag rather than being rejected or ignored.
    proc = run_minify(["--quiet=false", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert_stats_line(proc.stdout, "a.css", "out.css", "18 B", "12 B", "66.7%")
    quiet = run_minify(["--quiet=true", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert quiet.returncode == 0
    assert quiet.stdout == b""


def test_repeated_type_option_uses_the_last_value():
    """Specifying --type twice keeps only the second value."""
    # CATCHES: a reimplementation that keeps the first value, or that errors on
    # a repeat, would handle `--type css --type text/plain` differently.
    good = run_minify(["--type", "text/plain", "--type", "css"], stdin=CSS)
    assert good.returncode == 0
    assert good.stdout == b"a{color:red}"
    bad = run_minify(["--type", "css", "--type", "text/plain"], stdin=CSS)
    assert bad.returncode == 1
    assert bad.stderr == b"ERROR: cannot minify -: minifier does not exist for mimetype\n"


def test_missing_value_for_a_string_option_is_just_empty():
    """A trailing `--type` with nothing after it is empty, not a parse error."""
    # CATCHES: string options fall back to the empty string when the argument
    # list ends, so the failure comes later from the stdin validation.
    proc = run_minify(["--type"])
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: must specify --type for stdin\n"


def test_option_value_may_start_with_a_dash():
    """The token after an option is its value even when it looks like a flag."""
    # CATCHES: the parser does not stop at `-`-prefixed tokens, so `--list` is
    # swallowed as the value of --type and never acts as the list flag.
    proc = run_minify(["--type", "--list"])
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: unknown filetype \n"


@pytest.mark.parametrize(
    "argv,message",
    [
        (["--ext"], b"option --ext: missing value\n\n"),
        (["--ext", "scss=text/css"], b"option --ext: invalid map\n\n"),
        (["--ext", "{scss:text/css"], b"option --ext: invalid map\n\n"),
        (["--ext", "{scss:text/css}x"], b"option --ext: invalid map\n\n"),
        (["--ext", "="], b"option --ext: invalid map\n\n"),
        (["--preserve"], b"option --preserve: missing value\n\n"),
        (["--css-precision", "abc"], b"option --css-precision: invalid integer 'abc'\n\n"),
        (["--css-version", "1.5"], b"option --css-version: invalid integer '1.5'\n\n"),
        (["--js-precision", ""], b"option --js-precision: invalid integer ''\n\n"),
        (["--ext.s.cs=x"], b"option --ext.s.cs: unexpected . in name .cs\n\n"),
    ],
)
def test_badly_typed_option_values_exit_2(argv, message):
    """A value the option cannot scan is a usage error with the option's name."""
    # CATCHES: the message names the option and the offending value, the usage
    # screen goes to stdout, and the exit code is 2 (not the 1 used for
    # minify-time failures).
    proc = run_minify(argv)
    assert proc.returncode == 2
    assert proc.stderr == message
    assert proc.stdout == USAGE


def test_negative_integer_is_accepted_for_a_signed_option():
    """--js-version is a signed int, so a negative value parses fine."""
    # CATCHES: a reimplementation that refuses values starting with `-` would
    # report a usage error instead of accepting the number.
    proc = run_minify(["--js-version", "-2019", "--type", "css"], stdin=CSS)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b""


def test_invalid_url_is_reported_as_a_runtime_error():
    """An unparseable --url fails with exit 1 and the url.Parse message."""
    # CATCHES: the URL is parsed after task creation, so this is a minify-time
    # ERROR line on stderr, not an argument-parsing usage error.
    proc = run_minify(["--url", ":", "--type", "css"], stdin=CSS)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b'ERROR: parse ":": missing protocol scheme\n'


@pytest.mark.parametrize(
    "argv,expected",
    [
        (["-v"], b"  -v, --verbose=1 int         Verbose mode, set twice for more verbosity"),
        (["-vv"], b"  -v, --verbose=2 int         Verbose mode, set twice for more verbosity"),
        (["-vvv"], b"  -v, --verbose=3 int         Verbose mode, set twice for more verbosity"),
        (["-v3"], b"  -v, --verbose=3 int         Verbose mode, set twice for more verbosity"),
        (["-v=2"], b"  -v, --verbose=2 int         Verbose mode, set twice for more verbosity"),
        (["--verbose", "3"], b"  -v, --verbose=3 int         Verbose mode, set twice for more verbosity"),
        (["--verbose=2"], b"  -v, --verbose=2 int         Verbose mode, set twice for more verbosity"),
        (["--verbose", "x"], b"  -v, --verbose=1 int         Verbose mode, set twice for more verbosity"),
    ],
)
def test_verbose_is_counted_and_echoed_in_the_usage_screen(argv, expected):
    """-v counts occurrences, and the count is echoed as `--verbose=<n>`."""
    # CATCHES: only a digit glued or following the flag sets the count directly;
    # anything else just increments it, and the usage screen shows the result.
    proc = run_minify(list(argv) + ["--help"])
    assert proc.returncode == 0
    assert expected in proc.stdout.splitlines()


def test_verbose_digit_arg_is_consumed_not_treated_as_input():
    """`--verbose 3` eats the 3, but `--verbose x` leaves x as an input."""
    # CATCHES: a digit after --verbose is its value; a non-digit is left behind
    # and becomes a positional input the binary then fails to stat, which also
    # means stdin is never read (no minified stdout) even though the run still
    # exits 0, and the verbose INFO summary lands on stderr after the ERROR.
    eaten = run_minify(["--verbose", "3", "--type", "css"], stdin=CSS)
    assert eaten.returncode == 0
    assert eaten.stdout == b"a{color:red}"
    assert re.fullmatch(
        rb"DEBUG: use mimetype text/css\n"
        rb"DEBUG: minify from stdin\n"
        rb"DEBUG: minify to stdout\n"
        rb"INFO: finished in \S+\n",
        eaten.stderr,
    )
    left = run_minify(["--verbose", "x", "--type", "css"], stdin=CSS)
    assert left.returncode == 0
    assert left.stdout == b""
    assert re.fullmatch(
        rb"ERROR: stat x: no such file or directory\n" rb"INFO: finished in \S+\n",
        left.stderr,
    )


def test_usage_screen_echoes_match_values():
    """Parsed --match values are shown as the option's value in --help."""
    # CATCHES: --match is a custom list option whose help text is generated
    # from the parsed value, so `[x]` appears where a plain option shows none.
    one = run_minify(["--match", "x", "--help"])
    assert b"      --match=[x] []string    Filename matching pattern, only matching filenames are processed" in one.stdout.splitlines()
    two = run_minify(["--match", "x", "--match", "y", "--help"])
    assert b"      --match='[x y]' []string" in two.stdout.splitlines()


def test_usage_screen_shows_one_shared_list_for_include_and_exclude():
    """--include and --exclude append to the same list, shown for both options."""
    # CATCHES: include entries are prefixed `+` and exclude entries `-`, and
    # because both flags share one slice the combined list is printed twice.
    proc = run_minify(["--include", "a", "--exclude", "b", "--help"])
    lines = proc.stdout.splitlines()
    assert b"      --exclude='[+a -b]' []string" in lines
    assert b"      --include='[+a -b]' []string" in lines
    only_include = run_minify(["--include", "a", "--help"])
    assert b"      --include=[+a] []string Path inclusion pattern, includes paths previously excluded" in only_include.stdout.splitlines()
    only_exclude = run_minify(["--exclude", "b", "--help"])
    assert b"      --exclude=[-b] []string Path exclusion pattern, excludes paths from being processed" in only_exclude.stdout.splitlines()


def test_match_option_consumes_the_following_non_dash_tokens():
    """--match swallows every following non-dash token, including inputs."""
    # CATCHES: the list option greedily takes the tokens after it, so the input
    # filename disappears and the binary falls back to stdin.
    proc = run_minify(["--match", "*.css", "a.css"], cwd=None)
    assert proc.returncode == 1
    assert proc.stdout == b""
    assert proc.stderr == b"ERROR: must specify --type for stdin\n"


def test_match_option_stops_at_the_next_option(tmp_path, css_file):
    """--match stops consuming as soon as a token starts with a dash."""
    # CATCHES: the same greedy scan breaks on `-`, so a later flag is still
    # parsed as a flag and a later positional is still an input; the minified
    # output appears exactly once, proving the first `a.css` was eaten by
    # --match and only the trailing one was used as the input file.
    proc = run_minify(["--match", "a.css", "--type", "css", "a.css"], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == b""


def test_plain_slice_option_takes_exactly_one_value():
    """A []string option such as --svg-keep-namespaces consumes a single token."""
    # CATCHES: unlike --match, a plain slice option stops after one value when
    # the value is not bracketed, so the next token becomes a positional input.
    proc = run_minify(["--svg-keep-namespaces", "keep", "b", "--type", "svg"])
    assert proc.returncode == 0
    assert proc.stderr == b"ERROR: stat b: no such file or directory\n"


def test_trailing_equals_takes_the_next_token_as_the_value(tmp_path):
    """`--opt=` with nothing after the `=` reads its value from the next argv."""
    # CATCHES: `--output= out.css` must not be treated as an empty value; the
    # following token becomes the value, so the run writes out.css and reports
    # the stdin source `-` in its progress line, while `--preserve=` swallows
    # the would-be input file and leaves the run on stdin without a --type.
    proc = run_minify(["--type", "css", "--output=", "out.css"], stdin=CSS, cwd=tmp_path)
    assert proc.returncode == 0
    assert_stats_line(proc.stdout, "-", "out.css", "18 B", "12 B", "66.7%")
    assert proc.stderr == b"WARNING: stat -: no such file or directory\n"
    assert (tmp_path / "out.css").read_bytes() == b"a{color:red}"
    swallowed = run_minify(["--preserve=", "a.css", "-o", "p.css"], cwd=tmp_path)
    assert swallowed.returncode == 1
    assert swallowed.stdout == b""
    assert swallowed.stderr == b"ERROR: must specify --type for stdin\n"


def test_deprecated_mime_option_warns_and_still_minifies():
    """--mime prints a deprecation warning naming --type, then works."""
    # CATCHES: the warning goes to stderr with the ERROR prefix (not WARNING),
    # echoes the raw --mime value verbatim, and the run still exits 0 with the
    # minified bytes on stdout.
    proc = run_minify(["--mime", "text/css"], stdin=CSS)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert (
        proc.stderr
        == b"ERROR: deprecated use of '--mime text/css', please use '--type text/css' instead\n"
    )


def test_deprecated_mime_accepts_an_extension_short_name():
    """`--mime css` resolves through the extension map like --type would."""
    # CATCHES: the warning text echoes the short name as given, but the value
    # is afterwards translated through the built-in extension map, so `css`
    # still reaches the CSS minifier.
    proc = run_minify(["--mime", "css"], stdin=CSS)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert (
        proc.stderr
        == b"ERROR: deprecated use of '--mime css', please use '--type css' instead\n"
    )


def test_deprecated_mime_overrides_type():
    """When both are given, --mime wins over --type."""
    # CATCHES: the deprecated option is applied after --type, so a working
    # --mime beats a broken --type and vice versa; exactly one warning line is
    # printed, naming only the --mime value.
    proc = run_minify(["--type", "text/plain", "--mime", "css"], stdin=CSS)
    assert proc.returncode == 0
    assert proc.stdout == b"a{color:red}"
    assert proc.stderr == (
        b"ERROR: deprecated use of '--mime css', please use '--type css' instead\n"
    )
    broken = run_minify(["--type", "css", "--mime", "text/plain"], stdin=CSS)
    assert broken.returncode == 1
    assert broken.stdout == CSS
    assert broken.stderr == (
        b"ERROR: deprecated use of '--mime text/plain', please use '--type text/plain' instead\n"
        b"ERROR: cannot minify -: minifier does not exist for mimetype\n"
    )
