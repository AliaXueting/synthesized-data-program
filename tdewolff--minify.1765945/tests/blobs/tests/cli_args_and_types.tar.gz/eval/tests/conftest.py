"""Shared black-box helpers for the cli_args_and_types test module.

Every expectation embedded below was recorded by running the reference `minify`
binary through its command line interface only.  Tests never call into the
binary's internals and never hardcode a path to it: the executable location
always comes from PROGRAMGYM_EXECUTABLE.
"""

import functools
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

# Exact bytes that '--help', '-h' and every option-parsing error print on
# standard output (49 lines).  The first line is the usage line, which is built
# from the basename of argv[0]; every test in this module invokes the binary
# through a copy named `minify`, see minify_executable().
USAGE = b"""Usage: minify [options] inputs...

Options:
  -a, --all                   Minify all files, including hidden files and files in hidden directories
  -b, --bundle                Bundle files by concatenation into a single file
      --css-precision int     Number of significant digits to preserve in numbers, 0 is all
      --css-version int       CSS version to toggle supported optimizations (e.g. 2), by default 0 is the latest version
      --exclude []string      Path exclusion pattern, excludes paths from being processed
      --ext map[string]string Filename extension mapping to filetype (eg. css or text/css)
  -h, --help                  Help
      --html-keep-comments    Preserve all comments
      --html-keep-conditional-comments
                              Preserve all IE conditional comments (DEPRECATED)
      --html-keep-default-attrvals
                              Preserve default attribute values
      --html-keep-document-tags
                              Preserve html, head and body tags
      --html-keep-end-tags    Preserve all end tags
      --html-keep-quotes      Preserve quotes around attribute values
      --html-keep-special-comments
                              Preserve all IE conditionals and SSI tags
      --html-keep-whitespace  Preserve whitespace characters but still collapse multiple into one
  -i, --inplace               Minify input files in-place instead of setting output
      --include []string      Path inclusion pattern, includes paths previously excluded
      --js-keep-var-names     Preserve original variable names
      --js-precision int      Number of significant digits to preserve in numbers, 0 is all
      --js-version int        ECMAScript version to toggle supported optimizations (e.g. 2019, 2020), by default 0 is the latest version
      --json-keep-numbers     Preserve original numbers instead of minifying them
      --json-precision int    Number of significant digits to preserve in numbers, 0 is all
  -l, --list                  List all accepted filetypes
      --match []string        Filename matching pattern, only matching filenames are processed
      --mime string           Mimetype (eg. text/css), optional for input filenames (DEPRECATED, use --type)
  -o, --output string         Output file or directory, leave blank to use stdout
  -p, --preserve='[mode ownership timestamps]' []string
                              Preserve options (mode, ownership, timestamps, links, all)
  -q, --quiet                 Quiet mode to suppress all output
  -r, --recursive             Recursively minify directories
  -s, --sync                  Copy all files to destination directory and minify when filetype matches
      --svg-keep-comments     Preserve all comments
      --svg-keep-namespaces []string
                              Namespaces to keep, besides xlink
      --svg-precision int     Number of significant digits to preserve in numbers, 0 is all
      --type string           Filetype (eg. css or text/css), optional when specifying inputs
      --url string            URL of file to enable URL minification
  -v, --verbose int           Verbose mode, set twice for more verbosity
      --version               Version
  -w, --watch                 Watch files and minify upon changes
      --xml-keep-whitespace   Preserve whitespace characters but still collapse multiple into one

Arguments:
  inputs    Input files or directories, leave blank to use stdin
"""

# Exact bytes printed by '--list' / '-l': the built-in extension map, sorted by
# extension and padded so that every mimetype starts in the same column.
LIST_OUTPUT = b"""asp          text/asp
css          text/css
ejs          text/x-ejs-template
gohtml       text/x-go-template
handlebars   text/x-handlebars-template
htm          text/html
html         text/html
js           application/javascript
json         application/json
mjs          application/javascript
mustache     text/x-mustache-template
php          application/x-httpd-php
rss          application/rss+xml
svg          image/svg+xml
tmpl         text/x-template
webmanifest  application/manifest+json
xhtml        application/xhtml+xml
xml          text/xml
"""

# The built-in extension -> mimetype map, as --list prints it.  Order matters:
# it is the exact sorted order of the table.
EXT_MAP = [
    ("asp", "text/asp"),
    ("css", "text/css"),
    ("ejs", "text/x-ejs-template"),
    ("gohtml", "text/x-go-template"),
    ("handlebars", "text/x-handlebars-template"),
    ("htm", "text/html"),
    ("html", "text/html"),
    ("js", "application/javascript"),
    ("json", "application/json"),
    ("mjs", "application/javascript"),
    ("mustache", "text/x-mustache-template"),
    ("php", "application/x-httpd-php"),
    ("rss", "application/rss+xml"),
    ("svg", "image/svg+xml"),
    ("tmpl", "text/x-template"),
    ("webmanifest", "application/manifest+json"),
    ("xhtml", "application/xhtml+xml"),
    ("xml", "text/xml"),
]

# Shape of the one-line progress report the binary prints on stdout when the
# destination is a real file.  Only the elapsed time and the derived speed vary
# between runs; byte counts, ratio and the names are deterministic.
# Nothing at all is printed when the destination is stdout.
STATS_LINE_RE = re.compile(
    r"^\((?P<dur>[^,]+),"
    r" (?P<read> *\d[\d.]* *[kMGTP]?B),"
    r" (?P<wrote> *\d[\d.]* *[kMGTP]?B),"
    r" (?P<ratio> *[\d.]+%),"
    r" (?P<speed>[^)]+)\)"
    r" - (?P<src>.+) to (?P<dst>.+)$"
)

# Same progress line in its single-name form, used when source and destination
# are the same file (--inplace, `-o .`, or `-o <the input itself>`).
STATS_INPLACE_RE = re.compile(
    r"^\((?P<dur>[^,]+),"
    r" (?P<read> *\d[\d.]* *[kMGTP]?B),"
    r" (?P<wrote> *\d[\d.]* *[kMGTP]?B),"
    r" (?P<ratio> *[\d.]+%),"
    r" (?P<speed>[^)]+)\)"
    r" - (?P<src>.+)$"
)


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--version' once against a throwaway GOCOVERDIR, so the
    check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="minify-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def assigned_executable():
    """Return the binary the pipeline assigned, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the minify binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but the
    # pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to the
    # module's uninstrumented copy before pytest starts, so the counters would
    # never be written and this module's coverage report would stay empty.
    # During a coverage run (GOCOVERDIR present), when the assigned binary is
    # not itself instrumented, fall back to the instrumented build the driver
    # stages next to the module workspaces.  The staged file only exists in
    # that layout, so ordinary validation and release runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(str(staged)):
            return str(staged)
    return path


@functools.lru_cache(maxsize=None)
def minify_executable():
    """Path to a private copy of the binary that is literally named `minify`.

    The usage line the program prints is derived from the basename of argv[0],
    so running a copy with a fixed name keeps the recorded help text identical
    no matter what the pipeline called the file it handed us.
    """
    directory = tempfile.mkdtemp(prefix="minify-bin-")
    target = os.path.join(directory, "minify")
    shutil.copyfile(assigned_executable(), target)
    os.chmod(target, 0o755)
    return target


def _pinned_env(cwd=None, env=None):
    """Build the child environment from scratch: no TTY, no color, no noise."""
    child = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
    }
    # Forwarded only so a coverage-instrumented binary can write its counters;
    # the minify behavior under test never reads these.
    for passthrough in ("GOCOVERDIR",):
        if os.environ.get(passthrough):
            child[passthrough] = os.environ[passthrough]
    if cwd is not None:
        # Point HOME at the sandbox directory so nothing user-level leaks in.
        child["HOME"] = str(cwd)
    if env:
        child.update(env)
    return child


def run_minify(args, stdin=b"", cwd=None, env=None, timeout=30, binary=None):
    """Run the binary with 'args' and return the CompletedProcess result.

    stdin is always a pipe and stdout/stderr are always captured, so the program
    never sees a terminal and the help text is never wrapped to a width.
    'binary' overrides the resolved executable, for tests that need a copy of
    the program under a different name.
    """
    return subprocess.run(
        [binary or minify_executable()] + list(args),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=_pinned_env(cwd, env),
        timeout=timeout,
    )


def write_file(directory, name, content):
    """Write 'content' into directory/name and return the path object."""
    path = Path(directory) / name
    if isinstance(content, str):
        content = content.encode()
    path.write_bytes(content)
    return path


def assert_stats_line(stdout, src, dst, read, wrote, ratio):
    """Assert stdout is exactly one progress line with the recorded numbers.

    The elapsed time and throughput differ between runs, everything else in the
    line is a pure function of the input, so those fields are checked exactly.
    """
    rows = parse_stats_output(stdout)
    assert rows == [(src, dst, read, wrote, ratio)]


def parse_stats_line(line):
    """Check one progress line, returning (src, dst-or-None, read, wrote, ratio).

    dst is None for the single-name form the binary prints when a file is
    minified onto itself.
    """
    match = STATS_LINE_RE.match(line)
    if match is None:
        match = STATS_INPLACE_RE.match(line)
    assert match is not None, "progress line has the wrong shape: %r" % line
    groups = match.groupdict()
    return (
        groups["src"],
        groups.get("dst"),
        groups["read"].strip(),
        groups["wrote"].strip(),
        groups["ratio"].strip(),
    )


def parse_stats_output(stdout):
    """Parse every stdout line as a progress line, in order.

    Returns a list of (src, dst-or-None, read, wrote, ratio) tuples so that
    multi-file runs (whose line order is not deterministic) can be compared
    after sorting.  Fails when stdout holds anything but progress lines.
    """
    text = stdout.decode("utf-8")
    lines = text.splitlines()
    assert lines, "expected progress lines on stdout, got none"
    return [parse_stats_line(line) for line in lines]
