"""The `--js-*` options and JavaScript minification as reached through the CLI.

The JavaScript minifier (js/js.go, js/util.go) is only observable through the
command line as the bytes `--type js` (or a `.js` file, or a `<script>` tag)
writes for a given input, so this module pins that mapping: number bases and
precision, string/regexp/template literals, dead-code elimination, boolean and
nullish rewrites, statement merging, function/class/destructuring syntax, the
`--js-version` / `--js-precision` / `--js-keep-var-names` flags, and the
mimetype routes that select the JS minifier.  Every expected byte sequence was
recorded by running `./executable`.
"""

import pytest

from conftest import run_minify, write_file


def run_js(body, *flags):
    """Run the reference with --type js on 'body' and return the result."""
    if isinstance(body, str):
        body = body.encode()
    return run_minify(["--type", "js", *flags], stdin=body)


# ---------------------------------------------------------------- numbers


def test_number_bases_are_converted_to_decimal():
    """Binary, octal and hex literals are rewritten as plain decimals."""
    # CATCHES: 0b/0o/0x prefixes in both cases are converted to their decimal
    # value, not kept or shortened to another base.
    proc = run_js('a=[0b1010,0B0110,0o17,0O777,0xFF,0Xabc]\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=[10,6,15,511,255,2748]'


def test_decimal_notation_is_shortened():
    """Trailing zeros, leading zeroes and magnitudes switch to shortest form."""
    # CATCHES: 1000 becomes 1e3 but 100 stays decimal, 0.0001 becomes 1e-4,
    # 0.0001234 becomes 1234e-7, and `5.` loses its dot while `-0` is kept.
    proc = run_js(
        'a=[12.50,1e3,1E-2,.5,5.,0.1000,1000,100,10000000,0.0001,0.0001234,-0]\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == b'a=[12.5,1e3,.01,.5,5,.1,1e3,100,1e7,1e-4,1234e-7,-0]'


def test_numeric_separators_are_removed():
    """Underscore digit separators are stripped from numbers."""
    # CATCHES: 1_000 minifies to 1e3 and 1_000.5 to 1000.5; a reimplementation
    # that keeps the separator (or rejects it) would differ.
    proc = run_js('a=[1_000,1_000.5]\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=[1e3,1000.5]'


def test_bigint_suffix_survives_base_conversion():
    """BigInt literals convert bases but keep the trailing n."""
    # CATCHES: 0b1010n becomes 10n and 0xFFn becomes 255n, proving the `n`
    # suffix is tracked separately from the base conversion.
    proc = run_js('a=[123n,0b1010n,0xFFn,0o17n]\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=[123n,10n,255n,15n]'


def test_hex_literals_with_leading_e_or_f_digit_stay_hex():
    """Ten-digit hex literals starting with E/F are shorter left as hex."""
    # CATCHES: 0xD000000000 converts to 893353197568 and 0xC0000000 to
    # 3221225472, but 0xE000000000 and 0xFfffffffff stay hexadecimal, and
    # leading zeros (0x00ff) do not block conversion.
    proc = run_js('a=[0xD000000000,0xE000000000,0xFfffffffff,0xC0000000,0x00ff]\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=[893353197568,0xE000000000,0xFfffffffff,3221225472,255]'


@pytest.mark.parametrize(
    "precision,expected",
    [
        (None, b"a=[255,1.23456,123456789,1234e-7]"),
        ("0", b"a=[255,1.23456,123456789,1234e-7]"),
        ("1", b"a=[300,1,1e8,1e-4]"),
        ("2", b"a=[255,1.2,12e7,12e-5]"),
        ("3", b"a=[255,1.23,123e6,123e-6]"),
    ],
)
def test_js_precision_rounds_to_significant_digits(precision, expected):
    """--js-precision caps the significant digits kept in numbers."""
    # CATCHES: 0 is the same as the default (no rounding), and 255 rounds to
    # 300 under precision 1, showing rounding applies after hex conversion.
    flags = [] if precision is None else ["--js-precision", precision]
    proc = run_js('a=[0xFF,1.23456,123456789,0.0001234]\n', *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_js_precision_applies_to_every_number_base():
    """Precision rounding sees converted decimals, not the original base."""
    # CATCHES: under --js-precision 1 the binary 0b1010 stays 10 and the
    # octal 0o17 stays 15 while the hex 0xFF becomes 300, because rounding
    # happens on the decimal text produced by the base conversion.
    proc = run_js(
        'a=[0b1010,0o17,0xFF,1.23456,123456789,1e-5]\n',
        '--js-precision',
        '1',
    )
    assert proc.returncode == 0
    assert proc.stdout == b'a=[10,15,300,1,1e8,1e-5]'


def test_negative_precision_value_is_accepted():
    """--js-precision accepts a negative integer and means no rounding."""
    # CATCHES: a signed option value starting with a dash is consumed as the
    # value (not parsed as a flag), and a negative precision leaves numbers
    # untouched just like 0.
    proc = run_js('a=1.23456\n', '--js-precision', '-1')
    assert proc.returncode == 0
    assert proc.stdout == b'a=1.23456'


# ---------------------------------------------------------------- strings


def test_string_quotes_switch_to_avoid_escapes():
    """String delimiters flip to whichever quote needs no escapes."""
    # CATCHES: "abc" keeps double quotes, "d'e" keeps them too, but a string
    # containing a double quote switches to single quotes and back.
    proc = run_js('a=["abc",\'d\\\'e\',"ab\\"cd"]\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=["abc","d\'e",\'ab"cd\']'


def test_string_escapes_are_decoded_to_their_characters():
    r"""Hex, unicode and code-point escapes decode into raw UTF-8 bytes."""
    # CATCHES: "\x41B" becomes "AB", é becomes the two UTF-8 bytes
    # for e-acute, \u{1F600} the emoji, and a \t escape becomes a raw tab.
    proc = run_js(
        'a=["\\x41\\u0042",\'tab\\there\',"\\u00e9","\\u{1F600}","cafe\\u0301"]\n',
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'a=["AB","tab\there","\xc3\xa9","\xf0\x9f\x98\x80","cafe\xcc\x81"]'
    )


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], b"a=`he said \"hi\" to 'me'`"),
        (["--js-version", "5"], b'a="he said \\"hi\\" to \'me\'"'),
    ],
)
def test_strings_needing_both_quotes_become_templates(flags, expected):
    """A string containing both quote styles becomes a template literal."""
    # CATCHES: only under ES2015+ (the default); --js-version 5 must keep the
    # escaped double-quoted form instead of using a backtick template.
    proc = run_js('a="he said \\"hi\\" to \'me\'"\n', *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], b"b=`line1\nline2`"),
        (["--js-version", "5"], b'b="line1\\nline2"'),
    ],
)
def test_newline_escape_becomes_a_multiline_template(flags, expected):
    r"""A \n escape turns into a literal newline inside a template literal."""
    # CATCHES: the default output embeds a real newline byte between line1 and
    # line2 inside backticks, while --js-version 5 keeps the two-character
    # backslash-n escape.
    proc = run_js('b="line1\\nline2"\n', *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_template_literals_keep_substitutions_and_drop_padding():
    """Template literals survive with substitutions and nested templates."""
    # CATCHES: `x${b}y` is kept verbatim, a \n escape inside a template
    # becomes a literal newline, tagged templates keep their tag, and the
    # spaces around a nested ${ } substitution are removed.
    proc = run_js('a=`x${b}y`;c=`a\\nb`;d=tag`raw${x}`;e=`x${ `n${b}` }y`\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=`x${b}y`,c=`a\nb`,d=tag`raw${x}`,e=`x${`n${b}`}y`'


def test_html_scripts_escape_html_comment_sequences():
    """JS inside <script> escapes <!-- so it cannot open an HTML comment."""
    # CATCHES: routed through --type text/html the string "=>"<!--"" gains a
    # backslash before the exclamation mark, and so does a /<!--/ regexp,
    # while the same input through --type js stays unescaped.
    for body, expected in [
        (b'<script>a="<!--"</script>\n', b'<script>a="<\\!--"</script>'),
        (b"<script>a=/<!--/</script>\n", b"<script>a=/<\\!--/</script>"),
    ]:
        proc = run_minify(["--type", "text/html"], stdin=body)
        assert proc.returncode == 0
        assert proc.stdout == expected
    proc = run_js('a="<!--"')
    assert proc.returncode == 0
    assert proc.stdout == b'a="<!--"'


# ---------------------------------------------------------------- regexps


def test_regex_unescapes_only_safe_characters():
    """A backslash before an ordinary character is dropped in regexps."""
    # CATCHES: /a\-b/ becomes /a-b/ outside a character class, while escape
    # sequences like \x41 and \d are kept because removing the backslash
    # there would change the pattern.
    proc = run_js('a=[/^\\x41+/i,/a\\-b/]\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=[/^\\x41+/i,/a-b/]'


def test_regex_character_class_escape_rules():
    """Inside [...] a dash or caret is unescaped only when safe."""
    # CATCHES: [a\-b] keeps its escaped dash (it would otherwise make a
    # range) but [a\-] and [a\^] lose the backslash, while [\^] at the start
    # and [\d] keep theirs.
    proc = run_js('a=[/[a\\-b]/,/[a\\-]/,/[\\^]/,/[a\\^]/,/[\\d]/,/[{]/,/[}]/]\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=[/[a\\-b]/,/[a-]/,/[\\^]/,/[a^]/,/[\\d]/,/[{]/,/[}]/]'


def test_regex_flags_are_preserved_verbatim():
    """Regexp flags are echoed in their original order."""
    # CATCHES: /x/mgi stays mgi and /x/iym stays iym; the minifier does not
    # sort or deduplicate the flag letters.
    proc = run_js('a=[/x/mgi,/x/iym,/x/gs]\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=[/x/mgi,/x/iym,/x/gs]'


# ------------------------------------------------- dead code and booleans


def test_true_condition_bodies_merge_into_a_for_initializer():
    """Constant conditions are folded and merged with the following loop."""
    # CATCHES: if(true) with an else drops the else branch, if(false) is
    # deleted outright, the surviving if(true) bodies become the initializer
    # of the merged while(true) loop, and true prints as !0.
    proc = run_js(
        'if(true){a()}else{b()};if(false){c()};if(1){d()};while(true){e()};for(;true;){'
        'f()}\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == b'for(a(),d();!0;)e();for(;!0;)f()'


def test_false_if_body_vanishes_entirely():
    """A statically false if produces no output at all."""
    # CATCHES: if(false){f()} minifies to zero bytes on stdout, while the
    # else branch of a false if survives and comma-merges with the next
    # statement.
    proc = run_js('if(false){f()}\n')
    assert proc.returncode == 0
    assert proc.stdout == b''
    proc = run_js('if(false)a();else b();c()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'b(),c()'


def test_while_false_becomes_a_never_true_for():
    """while(false) is rewritten, not deleted, unlike if(false)."""
    # CATCHES: the unreachable loop body survives as for(;!1;)g() with the
    # condition spelled !1, so only the if-form of dead code is dropped.
    proc = run_js('while(false){g()}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'for(;!1;)g()'


def test_if_else_becomes_conditional_or_logical_expression():
    """Statement-level if/else chains rewrites as expressions."""
    # CATCHES: if(a){b()}else{c()} becomes a?b():c(), a dangling else binds
    # to the inner if producing a&&(b?c():d()), and a nested then-block
    # without else becomes a?b&&c():d().
    proc = run_js(
        'if(a){b()}else{c()};if(a)if(b)c();else d();if(a){if(b){c()}}else d()\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == b'a?b():c(),a&&(b?c():d()),a?b&&c():d()'


def test_boolean_valued_conditionals_collapse():
    """Ternaries returning true/false collapse to boolean operators."""
    # CATCHES: i?true:false becomes !!i, k?true:g becomes !!k||g, and
    # m?false:true becomes !m, but equal number literals (x?1:1) are left
    # alone while equal variable branches fold to (x,y).
    proc = run_js('a=i?true:false;j=k?true:g;l=m?false:true;n=!(!o);p=x?1:1;q=x?y:y\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=!!i,j=!!k||g,l=!m,n=!!o,p=x?1:1,q=(x,y)'


def test_empty_if_body_becomes_logical_or():
    """An if with an empty then-branch reduces to a logical or."""
    # CATCHES: both if(a){}else b() and if(a);else b() minify to a||b(),
    # so an empty block and an empty statement are treated the same.
    proc = run_js('if(a){}else b();if(a);else b()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a||b(),a||b()'


# ------------------------------------------------------ nullish / undefined


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], b"a=b??c"),
        (["--js-version", "2020"], b"a=b??c"),
        (["--js-version", "2019"], b"a=b!=null?b:c"),
        (["--js-version", "5"], b"a=b!=null?b:c"),
    ],
)
def test_nullish_coalescing_needs_es2020(flags, expected):
    """b!=null?b:c becomes ?? only when the ES version allows it."""
    # CATCHES: the nullish coalescing rewrite is gated on --js-version 2020
    # or newer; 2019 and 5 keep the explicit !=null comparison.
    proc = run_js('a=b!=null?b:c\n', *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


def test_undefined_or_null_chain_becomes_loose_equality():
    """a===undefined||a===null collapses to a==null regardless of version."""
    # CATCHES: the strict-or-null rewrite is not version gated, and the whole
    # statement chain around it still comma-merges (f=... after catch{}).
    proc = run_js(
        'a=b!=null?b:c;try{d()}catch(e){}f=a===undefined||a===null?x:y;g=h!=null?h:i\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == b'a=b??c;try{d()}catch{}f=a==null?x:y,g=h??i'


def test_undefined_becomes_indexing_zero():
    """undefined and void 0 are rewritten as 0[0]."""
    # CATCHES: both the global identifier and the void expression become the
    # five-character 0[0], which is the reference's shortest undefined.
    proc = run_js('a=b===undefined;e=void 0\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=b===0[0],e=0[0]'


@pytest.mark.parametrize(
    "flags,expected",
    [
        ([], b"try{d()}catch{}"),
        (["--js-version", "2020"], b"try{d()}catch{}"),
        (["--js-version", "2018"], b"try{d()}catch(e){}"),
        (["--js-version", "5"], b"try{d()}catch(e){}"),
        (["--js-version", "2019"], b"try{d()}catch{}"),
    ],
)
def test_optional_catch_binding_needs_es2019(flags, expected):
    """An unused catch binding is dropped only for ES2019+."""
    # CATCHES: catch(e){} loses its parameter entirely under the default and
    # 2019, but --js-version 2018 or 5 must keep catch(e){}.
    proc = run_js('try{d()}catch(e){}\n', *flags)
    assert proc.returncode == 0
    assert proc.stdout == expected


# ---------------------------------------------------------------- statements


def test_if_return_chain_becomes_a_nested_ternary():
    """Consecutive if/return statements fold into one return expression."""
    # CATCHES: function f(){if(a)return 1;if(b)return 2;return 3} collapses
    # to a single return with the nested conditional a?1:b?2:3.
    proc = run_js('function f(){if(a)return 1;if(b)return 2;return 3}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'function f(){return a?1:b?2:3}'


def test_while_becomes_for_and_keeps_labels():
    """while loops print as for(;cond;) and labels are preserved."""
    # CATCHES: label:while(a){break label} becomes label:for(;a;)break label
    # and an unlabeled while(a){b()} becomes for(;a;)b().
    proc = run_js('label:while(a){break label};while(a){b()}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'label:for(;a;)break label;for(;a;)b()'


def test_do_while_semicolons_are_elided_before_statements():
    """No semicolon is inserted after a do-while, even before a statement."""
    # CATCHES: do;while(a);b=1 prints as do;while(a)b=1 and do a();while(b);
    # (function(){})() as do a();while(b)(function(){})() -- the reference
    # drops the separator entirely instead of protecting the ASI hazard.
    proc = run_js('do;while(a);b=1\n')
    assert proc.returncode == 0
    assert proc.stdout == b'do;while(a)b=1'
    proc = run_js('do a();while(b);(function(){})()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'do a();while(b)(function(){})()'


def test_do_block_braces_are_dropped():
    """A do-while with a single-statement block loses its braces."""
    # CATCHES: do{a()}while(b) becomes do a();while(b) with no trailing
    # semicolon at the end of the program.
    proc = run_js('do{a()}while(b)\n')
    assert proc.returncode == 0
    assert proc.stdout == b'do a();while(b)'


def test_with_body_braces_are_dropped():
    """A with statement with a single-statement block loses its braces."""
    # CATCHES: with(o){x=1} minifies to with(o)x=1, keeping the mandatory
    # parentheses around the object but dropping the block.
    proc = run_js('with(o){x=1}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'with(o)x=1'


def test_statement_merging_rules():
    """Adjacent statements merge by kind, with var declarations hoisted."""
    # CATCHES: plain expressions comma-merge (a=1,b=2), consecutive var / let
    # / const declarations merge into one declarator list, the later var j=9
    # is hoisted into the first var as an undefined binding (var j,c=3,d=4;
    # j=9), and a var never merges with a following let.
    proc = run_js(
        'a=1;b=2;var c=3;var d=4;let e=5;let g=6;const h=7;const i=8;var j=9;let k=10\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'a=1,b=2;var j,c=3,d=4;let e=5,g=6;const h=7,i=8;j=9;let k=10'
    )


def test_empty_statements_and_bodies_disappear():
    """Empty statements are dropped and an empty if feeds the next loop."""
    # CATCHES: if(a){} followed by while(a); merges into for(a;a;); (the
    # empty if condition becomes the for initializer) and the stray ;;
    # statements around a=1 vanish.
    proc = run_js('if(a){};while(a);;a=1;;\n')
    assert proc.returncode == 0
    assert proc.stdout == b'for(a;a;);a=1'


def test_directives_and_debugger():
    """Directive prologues keep their semicolon; debugger keeps none."""
    # CATCHES: "use strict"; keeps the semicolon separating it from the next
    # statement (dropping it would change the directive), while debugger; at
    # the end of the program loses its semicolon.
    proc = run_js('"use strict";a=1;function f(){"use strict";b=2};debugger;\n')
    assert proc.returncode == 0
    assert proc.stdout == b'"use strict";a=1;function f(){"use strict";b=2}debugger'


def test_flow_statements_skip_their_semicolons():
    """return and throw need no trailing semicolon inside a function."""
    # CATCHES: if(a)return;if(b)throw c is printed without semicolons after
    # the flow statements, because a newline is sufficient there.
    proc = run_js('function f(){if(a)return;if(b)throw c}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'function f(){if(a)return;if(b)throw c}'


def test_switch_and_try_keep_braces_and_case_colons():
    """switch and try/catch/finally bodies are never unbraced."""
    # CATCHES: switch keeps every case colon and the break before default,
    # an empty case body prints as `case 2:` with nothing before the colon,
    # and a used catch binding stays parenthesised while an unused one drops.
    proc = run_js(
        'switch(a){case 1:b();break;case 2:;default:c()};try{a()}catch{}finally{c()};tr'
        'y{b()}finally{c()};try{d()}catch(e){f(e)}\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'switch(a){case 1:b();break;case 2:default:c()}try{a()}catch{}finally{c()}try{'
        b'b()}finally{c()}try{d()}catch(e){f(e)}'
    )


def test_newline_before_paren_is_not_an_asi_boundary():
    """The reference joins statements across newlines without separators."""
    # CATCHES: a=1 followed by a newline and (function(){b()})() prints as
    # a=1(function(){b()})() (no semicolon inserted), while a=1 newline +2
    # merges into a=1+2 because + continues the expression.
    proc = run_js(b'a=1\n(function(){b()})()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=1(function(){b()})()'
    proc = run_js(b'a=1\n+2\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=1+2'


def test_shebang_comment_swallows_the_next_statement():
    """A hashbang line loses its newline and absorbs the first statement."""
    # CATCHES: #!/usr/bin/env node followed by a=1_000 prints as the single
    # line #!/usr/bin/env nodea=1e3 -- the reference drops the newline after
    # the hashbang comment, so the statement text ends up inside the comment.
    proc = run_js('#!/usr/bin/env node\na=1_000\n')
    assert proc.returncode == 0
    assert proc.stdout == b'#!/usr/bin/env nodea=1e3'


def test_important_comments_survive():
    r"""/*! and //! comments are kept while plain /* ... */ comments drop."""
    # CATCHES: the bang comments are preserved verbatim (with the newline
    # after //! kept so it cannot swallow the code) and the ordinary comment
    # disappears entirely.
    proc = run_js('/*! kept */a=1;//! also\nb=2;/* dropped */c=3\n')
    assert proc.returncode == 0
    assert proc.stdout == b'/*! kept *///! also\na=1,b=2,c=3'


# ----------------------------------------------------------- declarations


def test_trailing_unused_parameters_are_dropped():
    """Unused parameters are removed only when they are trailing."""
    # CATCHES: function f(a,b){return a} loses b entirely (f(e)), a two
    # parameter arrow (a,b)=>a prints as (e)=>e with parens kept, and a
    # trailing comma in the parameter list is dropped.
    proc = run_js('function f(a,b){return a};const i=(a,b)=>a;const j=(a,)=>a\n')
    assert proc.returncode == 0
    assert proc.stdout == b'function f(e){return e}const i=(e)=>e,j=e=>e'
    proc = run_js('function g(a,b,c){return a+c}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'function g(e,t,n){return e+n}'


def test_arrow_parentheses_rules():
    """Arrow parameter parens are kept only when required."""
    # CATCHES: a block body returning the parameter collapses to an
    # expression body (x)=>{return x} becomes e=>e, () and two-parameter
    # arrows keep their parentheses, and async(x)=>x becomes async e=>e.
    proc = run_js(
        'const g=(x)=>{return x};const h=()=>1;const k=(a,b)=>a;const m=async(x)=>x\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == b'const g=e=>e,h=()=>1,k=(e)=>e,m=async e=>e'


def test_class_members():
    """Class member syntax minifies with members renamed to short names."""
    # CATCHES: semicolons between members disappear, private fields are
    # renamed (#p to #e), static private and getter members print without a
    # space after the keyword (static#t=3, get#n(){}), and the field pair
    # `declare c` prints as declare;c.
    proc = run_js(
        'class A extends B{constructor(){super()};static s=1;#p=2;get x(){return 1};set'
        ' x(v){};static m(){};async n(){};*gen(){};["c"](){};static#q=3;get#r(){};decla'
        're c}\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'class A extends B{constructor(){super()}static s=1;#e=2;get x(){return 1}set '
        b'x(e){}static m(){}async n(){}*gen(){}["c"](){}static#t=3;get#n(){}declare;c}'
    )


def test_object_literal_members():
    """Object literals use shorthand and drop method colons."""
    # CATCHES: {b:b} becomes {b}, an expression-bodied arrow property keeps
    # its arrow (d:()=>1), a plain function property keeps function(){},
    # and computed keys and spread keep their brackets and dots.
    proc = run_js(
        'a={b:b,c:function(){},d:()=>1,e(){},get f(){},set f(v){},["g"]:1,...h,[i]:j}\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'a={b,c:function(){},d:()=>1,e(){},get f(){},set f(e){},["g"]:1,...h,[i]:j}'
    )


def test_destructuring():
    """Binding patterns minify and assignment targets keep their parens."""
    # CATCHES: var{a,b:c}=o drops the space after var, renamed pattern
    # defaults keep their equals, rest keeps its dots, and the two
    # expression-statement patterns merge into one comma expression with
    # their protective parentheses kept.
    proc = run_js(
        'var {a,b:c}=o;var [d,e]=arr;let {x=1,y:z=2}=o;function f({a,b=2}){};const [p,.'
        '..q]=r;({a}=o);[d]=arr\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'var{a,b:c}=o,[d,e]=arr;let{x=1,y:z=2}=o;function f({a:e,b:t=2}){}const[p,...q'
        b']=r;({a}=o,[d]=arr)'
    )


def test_module_imports_and_exports_pass_through():
    """import/export statements survive with their quotes and aliases."""
    # CATCHES: module syntax is echoed with minimal spacing (from"m"), the
    # import * as and export * forms keep their spaces around the star, and
    # aliases keep their `as` keyword.
    proc = run_js(
        'import a from"m";import{b as c,d}from"n";import*as e from"o";export default a;'
        'export{c};export*from"p";export const f=1\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'import a from"m";import{b as c,d}from"n";import*as e from"o";export default a'
        b';export{c};export*from"p";export const f=1'
    )


def test_modern_syntax_is_preserved():
    """Optional chaining, exponents, spread and meta references survive."""
    # CATCHES: b?.[c] and b?.() keep their brackets and parens, ** and **=
    # are not rewritten, import.meta and new.target stay, and two yields in
    # a generator merge into one comma expression.
    proc = run_js(
        'a=b?.c;d=b?.[c];e=b?.();f=a**b;g=a**=b;h=[...i];j=f(...a);k=import.meta;l=new.'
        'target;function*g(){yield*x;yield y}\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'a=b?.c,d=b?.[c],e=b?.(),f=a**b,g=a**=b,h=[...i],j=f(...a),k=import.meta,l=new'
        b'.target;function*g(){yield*x,yield y}'
    )


def test_keep_var_names_preserves_identifiers():
    """--js-keep-var-names disables the identifier renamer."""
    # CATCHES: without the flag longName's parameter shrinks to e; with it
    # both the function parameter and class method parameter keep their
    # original multi-character names.
    proc = run_js('function longName(anotherLong){return anotherLong}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'function longName(e){return e}'
    proc = run_js(
        'function longName(anotherLong){return anotherLong}\n',
        '--js-keep-var-names',
    )
    assert proc.returncode == 0
    assert proc.stdout == b'function longName(anotherLong){return anotherLong}'
    proc = run_js(
        'class MyClass{myMethod(myParam){return myParam}}\n',
        '--js-keep-var-names',
    )
    assert proc.returncode == 0
    assert proc.stdout == b'class MyClass{myMethod(myParam){return myParam}}'


# ----------------------------------------------------------- expressions


def test_parentheses_follow_precedence():
    """Grouping parens are dropped when precedence allows and kept when not."""
    # CATCHES: (b+c)+d loses its parens but (b+c)*d keeps them, -(-a) prints
    # as - -a with a space, typeof(s) drops its parens, and (1).toString(16)
    # becomes 1..toString(16) while (1,2,3) and (e,f) keep their groups.
    proc = run_js(
        'y=(b+c)*d;z=(b+c)+d;w=-(-a);v=!!u;t=typeof(s);r=(1).toString(16);c=(1,2,3);d2='
        '(e,f)\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'y=(b+c)*d,z=b+c+d,w=- -a,v=!!u,t=typeof s,r=1..toString(16),c=(1,2,3),d2=(e,f'
        b')'
    )


def test_keyword_operators_keep_their_spaces():
    """Word operators print with the spaces their grammar requires."""
    # CATCHES: new D() becomes new D without call parens, while typeof, in
    # and instanceof keep exactly one space on each side.
    proc = run_js('a=typeof b;c=new D();delete a.e;f="x"in g;h=i instanceof J\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=typeof b,c=new D,delete a.e,f="x"in g,h=i instanceof J'


# --------------------------------------------- expression rewrites (round 3)


def test_adjacent_string_concatenations_are_merged():
    """Adjacent string literals in a + chain fold into one literal."""
    # CATCHES: "x"+"y" becomes "xy" and the trailing "r"+"s" merges even
    # around the variable q, while 1+2 and "x"+(1+2) are left untouched
    # (number folding and parenthesised groups do not merge).
    proc = run_js('a="x"+"y";b="p"+q+"r"+"s";c="a"+"b"+"c";d=1+2;e="x"+(1+2)\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a="xy",b="p"+q+"rs",c="abc",d=1+2,e="x"+(1+2)'


def test_negated_comparisons_flip_their_operator():
    """!(a==b) style negations invert the comparison instead."""
    # CATCHES: ==, != and === become their opposite without the !, while a
    # negated relational operator like a<b keeps its parens and bang.
    proc = run_js('x=!(a==b);y=!(a!=b);z=!(a===b);t=!(a<b)\n')
    assert proc.returncode == 0
    assert proc.stdout == b'x=a!=b,y=a==b,z=a!==b,t=!(a<b)'


def test_negated_logical_operators_de_morgan():
    """!(a||b) and !(a&&b) rewrite by De Morgan; double negation stays."""
    # CATCHES: !(a||b) becomes !a&&!b and !(a&&b) becomes !a||!b, while
    # !(!a) collapses to the canonical !!a rather than to a.
    proc = run_js('w=!(a||b);v=!(a&&b);u=!(!a)\n')
    assert proc.returncode == 0
    assert proc.stdout == b'w=!a&&!b,v=!a||!b,u=!!a'


def test_nullish_guards_become_optional_chains():
    """a==null?undefined:a.c collapses to optional chaining."""
    # CATCHES: the undefined-branch rewrite only fires when the chain's base
    # is the tested variable, so d[f] on another variable keeps the ternary
    # with undefined spelled 0[0].
    proc = run_js(
        'a=b==null?undefined:b.c;d=e==null?undefined:d[f];g=h==null?undefined:h()\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == b'a=b?.c,d=e==null?0[0]:d[f],g=h?.()'


def test_nullish_rewrite_direction_depends_on_branch_order():
    """Only the branch orders that map onto ?? are rewritten."""
    # CATCHES: a==null?b:a and a!=null?a:b become a??b, while a==null?a:b
    # and a!=null?b:a keep the explicit comparison because their branches
    # are the wrong way round for the coalescing operator.
    proc = run_js('i=j==null?k:j;l=m!=null?n:m;c=b==null?b:d\n')
    assert proc.returncode == 0
    assert proc.stdout == b'i=j??k,l=m!=null?n:m,c=b==null?b:d'


def test_boolean_literal_operands_are_folded():
    """true/false operands of && and || are folded away."""
    # CATCHES: b&&true and true&&d reduce to the other operand and
    # f||false to f, but the remaining literals print as !1 and !0.
    proc = run_js('a=b&&true;c=true&&d;e=f||false;g=false&&h;i=true||j\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=b,c=d,e=f,g=!1&&h,i=!0||j'


@pytest.mark.parametrize(
    "body,expected",
    [
        (b'if("")a();else b()\n', b"a()"),
        (b"if(0)c();else d()\n", b"d()"),
        (b"if(undefined)f()\n", b"0[0]"),
        (b"if(NaN)g()\n", b"NaN"),
    ],
)
def test_falsy_keyword_conditions(body, expected):
    """Each falsy literal condition is handled by its own rule."""
    # CATCHES: an empty string is NOT folded (its then-branch survives),
    # 0 takes the else branch, and the undefined and NaN identifiers
    # survive as bare 0[0] / NaN statements.
    proc = run_js(body)
    assert proc.returncode == 0
    assert proc.stderr == b""
    assert proc.stdout == expected


def test_null_condition_drops_the_whole_statement():
    """A null condition removes the if without touching its neighbours."""
    # CATCHES: if(null)e() alone minifies to zero bytes while the statement
    # after it survives, and the else branch of a null condition is kept --
    # the statement is dropped, not turned into an empty expression.
    proc = run_js(b'if(null)e();x()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'x()'
    proc = run_js(b'if(null)e();else g()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'g()'
    proc = run_js(b"if(null)e()\n")
    assert proc.returncode == 0
    assert proc.stdout == b""
    assert proc.stderr == b""


def test_truthy_unknown_conditions_become_logical_and():
    """Conditions of unknown truthiness become cond&&body()."""
    # CATCHES: if([])h() prints as []&&h(), and the object form keeps
    # protective parentheses because a bare {} would start a block.
    proc = run_js('if([])h()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'[]&&h()'
    proc = run_js('if({})i()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'({}&&i())'


def test_string_escapes_for_control_characters():
    r"""Control-character escapes either decode or stay escaped by kind."""
    # CATCHES: \v \u{7} \b \f decode to their raw single control bytes while
    # \0 \r \\ a\0b and \x00 keep their escape text, and \u000a (a newline)
    # switches the literal to a backtick template holding a raw newline.
    proc = run_js(
        'a=["\\0","\\r","\\v","\\\\","a\\0b","\\u{7}","\\x00","\\u000a","\\b","\\f"]\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == (
        b'a=["\\0","\\r","\x0b","\\\\","a\\0b","\x07","\\x00",`\n`,"\x08","\x0c"]'
    )


def test_arrow_bodies_and_parens():
    """Arrow function bodies shrink to their minimal form."""
    # CATCHES: ()=>{return} becomes ()=>{} (empty body), a call body keeps
    # its braces, an async arrow keeps await, and ()=>({}) keeps the object
    # parens because {} would be a block.
    proc = run_js('f=()=>{return};g=()=>{a()};h=async()=>{await b()};i=()=>({})\n')
    assert proc.returncode == 0
    assert proc.stdout == b'f=()=>{},g=()=>{a()},h=async()=>{await b()},i=()=>({})'


def test_if_bodies_with_declarations_stay_braced_or_vanish():
    """Declaration bodies follow hoisting instead of unbracing."""
    # CATCHES: an if whose branches are only unused const declarations
    # disappears (its condition merges into the next if as a comma), the
    # var form hoists the else binding into the then-branch
    # (if(a,a)var y,x=3;else y=4), and let keeps its braces in the loop.
    proc = run_js(
        'if(a){const x=1}else{const y=2};if(a){var x=3}else{var y=4};while(a){let z=5}'
        '\n'
    )
    assert proc.returncode == 0
    assert proc.stdout == b'if(a,a)var y,x=3;else y=4;for(;a;){let e=5}'


def test_catch_binding_patterns():
    """Object and array catch bindings keep their pattern shape."""
    # CATCHES: catch({message:e}) keeps the braces and renames the property
    # binding, and catch([f]) keeps the array pattern while renaming f.
    proc = run_js('try{a()}catch({message:e}){b(e)};try{c()}catch([f]){}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'try{a()}catch({message:e}){b(e)}try{c()}catch([e]){}'


def test_reversed_undefined_comparison_still_folds():
    """undefined===b||null===b folds like the forward spelling."""
    # CATCHES: the operand order inside the null/undefined comparison does
    # not matter; both collapse to b==null.
    proc = run_js('a=undefined===b||null===b?x:y\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=b==null?x:y'


def test_labelled_blocks_drop_their_braces():
    """A labelled block prints as label:stmt without the braces."""
    # CATCHES: l1:{break l1} becomes l1:break l1 and l2:{continue l2}
    # becomes l2:continue l2, with no trailing semicolons.
    proc = run_js('l1:{break l1};l2:{continue l2}\n')
    assert proc.returncode == 0
    assert proc.stdout == b'l1:break l1;l2:continue l2'


def test_void_only_collapses_for_side_effect_free_operands():
    """void a and void f() are kept; only void <literal> becomes 0[0]."""
    # CATCHES: the void rewrite is skipped when its operand may have side
    # effects (a variable read or a call), unlike void 0 from the earlier
    # undefined test.
    proc = run_js('x=void a;y=void f()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'x=void a,y=void f()'


def test_lone_default_switch_and_bare_if_forms():
    """A default-only switch keeps its braces; bare ifs compress."""
    # CATCHES: switch(c){default:1} is preserved verbatim, an if without
    # else becomes a&&b(), and the following if/else becomes a ternary.
    proc = run_js('switch(c){default:1};if(a)b();if(c)d();else e()\n')
    assert proc.returncode == 0
    assert proc.stdout == b'switch(c){default:1}a&&b(),c?d():e()'


# ------------------------------------------------- routing and CLI plumbing


def test_type_js_equals_full_mimetype_and_mime_warns():
    """--type js, --type application/javascript and --mime js agree."""
    # CATCHES: the short name resolves through the extension map to the same
    # minifier as the full mimetype, and the deprecated --mime prints its
    # deprecation warning naming --type on stderr while producing identical
    # stdout with exit code 0.
    body = "a=1_000\n"
    for args in (["--type", "js"], ["--type", "application/javascript"]):
        proc = run_js(body, *args)
        assert proc.returncode == 0
        assert proc.stdout == b'a=1e3'
    proc = run_minify(["--mime", "js"], stdin=body.encode())
    assert proc.returncode == 0
    assert proc.stdout == b"a=1e3"
    assert proc.stderr == (
        b"ERROR: deprecated use of '--mime js', please use '--type js' "
        b"instead\n"
    )


def test_module_mimetype_routes_to_the_js_minifier(tmp_path):
    """The extensionless `module` mimetype is a registered JS type."""
    # CATCHES: --ext can map an extension to the literal mimetype `module`,
    # which the JS pattern (not the extension map) resolves to the JS
    # minifier, both via --type and via a real file's extension.
    proc = run_js('a=1_000\n', '--ext', '{x:module}', '--type', 'x')
    assert proc.returncode == 0
    assert proc.stdout == b'a=1e3'
    src = write_file(tmp_path, "a.x", "a=1_000\n")
    proc = run_minify(["--ext", "{x:module}", src.name], cwd=tmp_path)
    assert proc.returncode == 0
    assert proc.stderr == b""
    assert proc.stdout == b"a=1e3"


def test_html_script_routes_by_type_attribute():
    """<script> content is minified per the type attribute's mimetype."""
    # CATCHES: a bare <script> runs the JS minifier (1_000 becomes 1e3),
    # type=module hits the JS pattern, and type=application/json runs the
    # JSON minifier on the tag body while the newline before </script> goes.
    for body, expected in [
        (b"<script>a=1_000</script>\n", b"<script>a=1e3</script>"),
        (b"<script type=module>a=1_000</script>\n",
         b"<script type=module>a=1e3</script>"),
        (b'<script type=application/json>{"a": 1, "b": [2, 3]}\n</script>\n',
         b'<script type=application/json>{"a":1,"b":[2,3]}</script>'),
    ]:
        proc = run_minify(["--type", "text/html"], stdin=body)
        assert proc.returncode == 0
        assert proc.stderr == b""
        assert proc.stdout == expected


def test_empty_input_minifies_to_nothing():
    """Zero bytes of JS input produce zero bytes of output and exit 0."""
    # CATCHES: an empty stdin through --type js is not an error; the exit
    # code is 0 and neither stream receives any bytes, while the same route
    # with one statement does return minified bytes -- an empty result means
    # empty input, not a binary that prints nothing.
    proc = run_js('a=1_000\n')
    assert proc.returncode == 0
    assert proc.stdout == b'a=1e3'
    proc = run_js(b"")
    assert proc.returncode == 0
    assert proc.stdout == b""
    assert proc.stderr == b""


@pytest.mark.parametrize(
    "mimetype,args,stdin,stderr",
    [
        (
            "js",
            ["--type", "js"],
            b"function{}\n",
            b"ERROR: cannot minify -: expected Identifier instead of { in "
            b"function declaration on line 1 and column 9\n"
            b"    1: function{}\n"
            b"               ^\n",
        ),
        (
            "js",
            ["--type", "js"],
            b"a=/unterminated\n",
            b"ERROR: cannot minify -: unexpected EOF or newline in regular "
            b"expression on line 1 and column 16\n"
            b"    1: a=/unterminated\n"
            b"                      ^\n",
        ),
        (
            "js",
            ["--type", "js"],
            b"a=\n",
            b"ERROR: cannot minify -: unexpected EOF in expression on line 2 "
            b"and column 1\n"
            b"    2: \n"
            b"       ^\n",
        ),
        (
            "js",
            ["--type", "js"],
            b'a="unterminated\n',
            b"ERROR: cannot minify -: unterminated string literal in "
            b"expression on line 1 and column 3\n"
            b'    1: a="unterminated\n'
            b"         ^\n",
        ),
        (
            "html",
            ["--type", "text/html"],
            b'<script>a="</script>";b=1</script>\n',
            b"ERROR: cannot minify -: unterminated string literal in "
            b"expression on line 1 and column 11\n"
            b'    1: a="\n'
            b"         ^\n",
        ),
    ],
)
def test_parse_errors_report_line_and_column(mimetype, args, stdin, stderr):
    """JS parse failures print a located ERROR block and pass input through."""
    # CATCHES: stderr carries the exact three-line report (message with line
    # and column, the numbered source line, and a caret aligned under the
    # column) while stdout receives the original unminified bytes, with exit
    # code 1; the HTML case shows </script> terminating the JS lexing early.
    proc = run_minify(args, stdin=stdin)
    assert proc.returncode == 1
    assert proc.stderr == stderr
    assert proc.stdout == stdin
