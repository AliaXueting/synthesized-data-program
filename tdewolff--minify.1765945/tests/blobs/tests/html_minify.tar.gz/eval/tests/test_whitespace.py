"""Whitespace collapsing rules of the HTML minifier.

Runs of whitespace collapse to a single character (a newline survives if the
run contained one); leading and trailing spaces are dropped around block-level
tags but preserved around inline and embedded-object tags; <pre> is untouched.
"""

import pytest
from conftest import minify_html


def test_runs_collapse_to_a_single_space():
    """Multiple spaces and tabs between words become one space."""
    # CATCHES: a re-implementation that drops the space entirely or keeps all
    # of the original characters.
    assert minify_html("cats  and \tdogs ") == b"cats and dogs"


def test_newline_survives_inside_a_whitespace_run():
    """A run containing a newline collapses to that newline, not a space."""
    # CATCHES: the collapsed character is chosen from the run's content, so a
    # newline anywhere in the run wins over the leading tab.
    assert minify_html("<p>a \t\n b</p>") == b"<p>a\nb"
    assert minify_html("<p>a\r\nb</p>") == b"<p>a\nb"
    assert minify_html("<p>a\t\tb</p>") == b"<p>a b"
    assert minify_html("<p>a\x0cb</p>") == b"<p>a b"


def test_leading_and_trailing_spaces_drop_around_block_tags():
    """Spaces touching a block element on either side are removed."""
    # CATCHES: block tags such as div strip whitespace on both boundaries.
    assert minify_html("<div>  a  </div>  <div>  b  </div>") == b"<div>a</div><div>b</div>"
    assert minify_html("a <div>x</div> b") == b"a<div>x</div>b"
    assert minify_html("<div>x</div> a") == b"<div>x</div>a"


def test_spaces_survive_around_inline_tags():
    """Spaces around phrasing content tags are kept on one side."""
    # CATCHES: inline tags are not block tags, so the trailing space before
    # the closing tag is preserved.
    assert minify_html("<span>  a  </span>  <span>  b  </span>") == b"<span>a </span><span>b</span>"
    assert minify_html("a <span>x</span>") == b"a <span>x</span>"
    assert minify_html("a <code> code </code> b") == b"a <code>code </code>b"


def test_spaces_survive_around_object_tags():
    """Embedded-object tags (img, input, button, object) keep their spaces."""
    # CATCHES: objectTag traits disable the space trimming that block tags do.
    assert minify_html('a <img src="x"> b') == b"a <img src=x> b"
    assert minify_html("a <button>x</button> b") == b"a <button>x</button> b"
    assert minify_html("<object>  a  </object><embed>  b") == b"<object> a </object><embed> b"
    assert minify_html("text <img> text") == b"text <img> text"


def test_document_leading_and_trailing_whitespace_is_dropped():
    """Whitespace at the very start and end of the document disappears."""
    # CATCHES: the initial omitSpace state trims the leading run, and EOF
    # trims the trailing one.
    assert minify_html("\n\n  <p>a</p>\n\n") == b"<p>a"
    assert minify_html("  <p>a</p>  ") == b"<p>a"


def test_whitespace_around_the_doctype():
    """Spaces around the doctype and the html/body wrappers all collapse."""
    # CATCHES: the doctype is written first and the html/head/body tags are
    # dropped together with their surrounding whitespace.
    assert minify_html(
        " <!doctype html> <!--comment--> <html> <body><p></p></body></html> "
    ) == b"<!doctype html><p>"


def test_pre_content_is_untouched():
    """Everything inside <pre> keeps its exact bytes, including newlines."""
    # CATCHES: pre must disable both collapsing and trimming.
    assert minify_html("<pre>  a\n\n  b  </pre>") == b"<pre>  a\n\n  b  </pre>"
    assert minify_html("<div><pre>x   y</pre></div>") == b"<div><pre>x   y</pre></div>"
    assert minify_html("<pre> <x> a  b </x> </pre>") == b"<pre> <x> a  b </x> </pre>"


def test_pre_end_tag_reenables_normal_processing():
    """After </pre> the ordinary whitespace rules apply again."""
    # CATCHES: inPre is cleared by the end tag, not by the next text token.
    assert minify_html("<pre>x</pre>  <p>  a  </p>") == b"<pre>x</pre><p>a"


def test_raw_text_tags_keep_their_content_verbatim():
    """textarea content is raw text and is never collapsed."""
    # CATCHES: raw tags bypass the whitespace replacement entirely.
    assert minify_html("<textarea>  a  b  </textarea>") == b"<textarea>  a  b  </textarea>"


def test_keep_whitespace_flag_preserves_boundary_spaces():
    """--html-keep-whitespace keeps one space where it would be dropped."""
    # CATCHES: the flag still collapses runs, so it is not a no-op passthrough.
    assert minify_html(
        "<div>  a  </div>  <div>  b  </div>", "--html-keep-whitespace"
    ) == b"<div> a </div> <div> b </div>"
    assert minify_html(
        " <div> <i> test </i> <b> test </b> </div> ", "--html-keep-whitespace"
    ) == b"<div> <i> test </i> <b> test </b> </div>"
    assert minify_html("<p>x<br> y", "--html-keep-whitespace") == b"<p>x<br> y"
    assert minify_html("<strong>x </strong> y", "--html-keep-whitespace") == b"<strong>x </strong> y"


def test_keep_whitespace_flag_does_not_touch_pre():
    """--html-keep-whitespace leaves <pre> exactly as it was."""
    # CATCHES: pre is handled before the flag is even consulted.
    assert minify_html("<pre>  a  </pre>", "--html-keep-whitespace") == b"<pre>  a  </pre>"
    assert minify_html("cats  and \tdogs ", "--html-keep-whitespace") == b"cats and dogs"


def test_whitespace_between_empty_inline_elements():
    """An empty inline element pair keeps the surrounding spaces."""
    # CATCHES: the 'keep space after phrasing tags' rule for FontAwesome-style
    # markup such as <i class=fas></i> followed by text.
    assert minify_html('a <span></span> b') == b"a <span></span> b"
    assert minify_html('a <code></code> b') == b"a <code></code> b"
    assert minify_html('<i class="fas"> </i> Text') == b'<i class=fas></i>Text'
    assert minify_html('<i class="fas"></i> Text') == b'<i class=fas></i> Text'


def test_whitespace_lookahead_stops_at_text():
    """A trailing space is kept when real text follows, even via many tags."""
    # CATCHES: the lookahead walks following tokens until it hits text, a
    # non-block start tag, or the token limit.
    assert minify_html("<p>x </b> <b> y") == b"<p>x </b><b>y"
    assert minify_html("<strong>x </strong>y") == b"<strong>x </strong>y"
    assert minify_html("<strong>x </strong> y") == b"<strong>x </strong>y"


def test_multiline_text_keeps_one_newline_per_run():
    """Each whitespace run keeps a newline if and only if it had one."""
    # CATCHES: two separate runs in one text node collapse independently.
    assert minify_html("<h5>\n    Lorem & ipsum\n    dolor sid amet\n</h5>") == (
        b"<h5>Lorem & ipsum\ndolor sid amet</h5>"
    )
    assert minify_html("text\n<!--comment-->\ntext") == b"text\ntext"


def test_whitespace_inside_attribute_values_is_trimmed_for_class():
    """class values are whitespace-normalised, not just quoted differently."""
    # CATCHES: trimAttr attributes collapse internal runs and trim the ends.
    assert minify_html('<p class="  name  ">') == b"<p class=name>"
    assert minify_html('<p class="  name  other  ">') == b'<p class="name other">'
    assert minify_html('<a rel=" noopener  external ">') == b'<a rel="noopener external">'


def test_non_trimmed_attribute_values_keep_their_spaces():
    """placeholder and value are not trimAttr, so inner spaces survive."""
    # CATCHES: only some attributes are whitespace-normalised.
    assert minify_html('<input placeholder=" a " value=" b ">') == (
        b'<input placeholder=" a " value=" b ">'
    )
    assert minify_html('<p title="  x  ">t</p>') == b'<p title="  x  ">t'


def test_whitespace_between_script_tags_is_dropped():
    """A script element behaves like a block tag for surrounding spaces."""
    # CATCHES: raw tags also carry the blockTag trait for style and script.
    assert minify_html("a <script>script</script> b") == b"a <script>script</script>b"
    assert minify_html(
        "<script src=a></script> <script src=b></script> <span></span>"
    ) == b"<script src=a></script><script src=b></script><span></span>"


def test_whitespace_with_many_following_tokens():
    """More than a hundred following tags still trim the trailing space."""
    # CATCHES: the lookahead is bounded but must still handle long runs.
    doc = "<p>a </p>" + "<i></i>" * 120 + "<p>b</p>"
    assert minify_html(doc) == b"<p>a</p>" + b"<i></i>" * 120 + b"<p>b"
    doc = "<p>a </p>" + "<span></span>" * 120 + " b"
    assert minify_html(doc) == b"<p>a</p>" + b"<span></span>" * 120 + b" b"


def test_whitespace_lookahead_cap_boundaries_with_comments():
    """The trailing-space lookahead gives up after 100 skipped tokens."""
    # CATCHES: comments are skipped by the lookahead, so with 100 of them it
    # still reaches the block tag and drops the space, but from 101 on the
    # cap fires first and the space before <div> survives.
    assert minify_html("<p>a " + "<!--c-->" * 100 + "<div>b</div>") == (
        b"<p>a<div>b</div>"
    )
    assert minify_html("<p>a " + "<!--c-->" * 101 + "<div>b</div>") == (
        b"<p>a <div>b</div>"
    )
    assert minify_html("<p>a " + "<!--c-->" * 120 + "<div>b</div>") == (
        b"<p>a <div>b</div>"
    )
