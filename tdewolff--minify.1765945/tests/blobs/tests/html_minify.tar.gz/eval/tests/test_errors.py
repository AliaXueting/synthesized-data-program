"""Error reporting: nested minifier failures, message format and exit codes.

Parse errors abort with 'cannot minify ...: <error>' on stderr, exit code 1,
and the original bytes on stdout.
"""

import pytest
from conftest import run_minify, write_input


def test_javascript_error_inside_a_script():
    """A JS syntax error aborts the whole document with exit code 1."""
    # CATCHES: the message names '-', the error, and a caret-annotated excerpt
    # of the offending line, with the column relative to the document.
    res = run_minify(["--type", "html"], stdin=b"<script>var 1 = </script>")
    assert res.returncode == 1
    assert res.stdout == b"<script>var 1 = </script>"
    assert res.stderr == (
        b"ERROR: cannot minify -: unexpected 1 in binding "
        b"on line 1 and column 13\n    1: var 1 = \n           ^\n"
    )


def test_json_error_inside_a_json_script():
    """A JSON syntax error in a typed script aborts the document."""
    # CATCHES: the column is counted from the start of the whole document.
    res = run_minify(
        ["--type", "html"], stdin=b'<script type=application/json>{bad}</script>'
    )
    assert res.returncode == 1
    assert res.stdout == b"<script type=application/json>{bad}</script>"
    assert res.stderr == (
        b"ERROR: cannot minify -: expected object key to be a quoted string "
        b"on line 1 and column 32\n    1: {bad}\n        ^\n"
    )


def test_error_in_a_file_names_the_file(tmp_path):
    """The same error names the input file instead of '-'."""
    # CATCHES: the source name in the message is the path as given.
    write_input(tmp_path, "bad.html", b"<script>var 1 = </script>")
    res = run_minify(["bad.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b"<script>var 1 = </script>"
    assert res.stderr.startswith(
        b"ERROR: cannot minify bad.html: unexpected 1 in binding "
        b"on line 1 and column 13\n"
    )


def test_error_with_a_file_destination_writes_the_original(tmp_path):
    """With -o the original document lands in the destination file."""
    # CATCHES: the fallback copy is the unminified input, byte for byte.
    write_input(tmp_path, "bad.html", b"<script>var 1 = </script>")
    res = run_minify(["-q", "-o", "out.html", "bad.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert (tmp_path / "out.html").read_bytes() == b"<script>var 1 = </script>"


def test_null_byte_inside_a_script_is_an_error():
    """A NUL byte in JavaScript is reported, not silently dropped."""
    # CATCHES: the excerpt renders the NUL byte as a middle dot.
    res = run_minify(["--type", "html"], stdin=b"<script>var a = 1; \x00 </script>")
    assert res.returncode == 1
    assert res.stdout == b"<script>var a = 1; \x00 </script>"
    assert res.stderr == (
        b"ERROR: cannot minify -: unexpected 0x00 on line 1 and column 20\n"
        b"    1: var a = 1; \xc2\xb7 \n                  ^\n"
    )


def test_null_byte_in_text_is_passed_through():
    """A NUL byte in ordinary text content is legal and preserved."""
    # CATCHES: only raw-tag content validates its bytes.
    res = run_minify(["--type", "html"], stdin=b"<p>a\x00b</p>")
    assert res.returncode == 0
    assert res.stdout == b"<p>a\x00b"
    assert res.stderr == b""


def test_unclosed_css_is_not_an_error():
    """An unterminated CSS block inside <style> still minifies."""
    # CATCHES: the CSS minifier tolerates EOF inside a block.
    res = run_minify(["--type", "html"], stdin=b"<style>body{</style>")
    assert res.returncode == 0
    assert res.stdout == b"<style></style>"
    assert res.stderr == b""


def test_style_attribute_error_is_tolerated():
    """Broken CSS in a style attribute does not abort the document."""
    # CATCHES: the CSS minifier is lenient, so the value is still rewritten.
    res = run_minify(["--type", "html"], stdin=b'<p style="color:red;;;}">x</p>')
    assert res.returncode == 0
    assert res.stdout == b"<p style=color:red;}>x"
    assert res.stderr == b""


def test_event_handler_error_aborts():
    """A JavaScript error in an on* attribute aborts the document."""
    # CATCHES: inline JS errors are fatal and the column is document-relative.
    res = run_minify(["--type", "html"], stdin=b'<p onclick="var 1 = ">x</p>')
    assert res.returncode == 1
    assert res.stdout == b'<p onclick="var 1 = ">x</p>'
    assert res.stderr == (
        b"ERROR: cannot minify -: unexpected 1 in binding "
        b"on line 1 and column 17\n    1: var 1 =\n           ^\n"
    )


def test_error_message_prefix_is_on_stderr_only():
    """Every error line is prefixed with ERROR: and ends with a newline."""
    # CATCHES: the logger writes to stderr with the ERROR: prefix while the
    # original document still goes to stdout.
    res = run_minify(["--type", "text/bogus"], stdin=b"<p>x</p>")
    assert res.returncode == 1
    assert res.stderr == (
        b"ERROR: cannot minify -: minifier does not exist for mimetype\n"
    )
    assert res.stdout == b"<p>x</p>"


def test_successful_run_writes_nothing_to_stderr():
    """A clean minification leaves standard error completely empty."""
    # CATCHES: no deprecation or statistics noise on the error stream, and
    # each flag has its own exact stdout: the comment following </p> keeps
    # the end tag, while --html-keep-whitespace preserves the inner spaces.
    expected = {
        (): b"<p>a</p>",
        ("--html-keep-comments",): b"<p>a</p><!-- c -->",
        ("--html-keep-whitespace",): b"<p> a </p>",
    }
    for flags, stdout in expected.items():
        res = run_minify(
            ["--type", "html"] + list(flags), stdin=b"<p>  a  </p><!-- c -->"
        )
        assert res.returncode == 0
        assert res.stderr == b""
        assert res.stdout == stdout
