"""URL-valued attributes: trimming, data: re-encoding and --url rewriting.

href/src/action/cite/poster and similar values are trimmed; data: URIs are
re-encoded as base64 or percent-encoding, whichever is shorter; with --url
http://host/ matching absolute URLs become protocol-relative //host/...
"""

import pytest
from conftest import minify_html, run_minify


def test_url_attributes_are_trimmed():
    """Leading and trailing whitespace around a URL value is removed."""
    # CATCHES: the trim happens before quoting, so no quotes are needed.
    assert minify_html('<a href="  http://example.com/a  ">x</a>') == (
        b"<a href=http://example.com/a>x</a>"
    )
    assert minify_html('<q cite=" x ">q</q><video poster=" p ">v</video>') == (
        b"<q cite=x>q</q><video poster=p>v</video>"
    )


def test_url_scheme_is_lower_cased():
    """HTTP:// in a URL value is rewritten in lower case."""
    # CATCHES: only the scheme is lowered, the rest of the URL keeps its case.
    assert minify_html('<a href="HTTP://Example.COM/A">x</a>') == (
        b"<a href=http://Example.COM/A>x</a>"
    )


def test_non_url_attributes_are_not_trimmed():
    """title is not a URL attribute, so its spaces survive."""
    # CATCHES: trimming is opt-in per attribute, not a global rule.
    assert minify_html('<p title="  x  ">t</p>') == b'<p title="  x  ">t'
    assert minify_html('<p url="http://test">') == b"<p url=http://test>"


def test_data_uri_percent_encoding_wins_when_shorter():
    """A base64 data: URI is re-encoded when percent-encoding is shorter."""
    # CATCHES: the whole payload is decoded and re-encoded, not copied.
    assert minify_html('<img src="data:image/png;base64,iVBORw0KGgo=">') == (
        b"<img src=data:image/png,%89PNG%0D%0A%1A%0A>"
    )
    assert minify_html(
        '<img src="data:application/octet-stream;base64,AAAA">'
    ) == b"<img src=data:application/octet-stream,%00%00%00>"


def test_data_uri_base64_wins_when_shorter():
    """A long base64 payload stays base64."""
    # CATCHES: the shorter of the two encodings is chosen.
    assert minify_html(
        '<img src="data:image/gif;base64,'
        'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7">'
    ) == (
        b"<img src=data:image/gif;base64,"
        b"R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7>"
    )


def test_data_uri_content_is_minified_for_known_mimetypes():
    """A data: URI holding HTML or CSS is minified before re-encoding."""
    # CATCHES: the decoded payload is run through the matching minifier.
    assert minify_html('<img src="data:text/html,<p>  hi  </p>">') == (
        b"<img src=data:text/html,%3Cp%3Ehi>"
    )
    assert minify_html('<img src="data:text/css,a {  color : red }">') == (
        b"<img src=data:text/css,a%7Bcolor:red%7D>"
    )


def test_data_uri_default_mimetype_and_charset_are_dropped():
    """text/plain and charset=utf-8 disappear from a data: URI."""
    # CATCHES: the URI parameters are simplified like a mediatype.
    assert minify_html('<img src="data:text/plain,hello%20world">') == (
        b"<img src=data:,hello%20world>"
    )
    assert minify_html('<link href="data:text/plain, data">') == (
        b"<link href=data:,%20data>"
    )


def test_data_uri_with_uppercase_scheme_is_untouched():
    """DATA: is not recognised as a data: URI scheme."""
    # CATCHES: only the lower-case prefix triggers the data: URI handling.
    assert minify_html('<img src="DATA:text/plain,a">') == b"<img src=DATA:text/plain,a>"


def test_data_uri_for_svg_is_re_encoded():
    """An inline SVG data: URI is percent-encoded, not base64."""
    # CATCHES: the SVG payload is minified first and then percent-encoded.
    assert minify_html(
        "<img src=\"data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'/>\">"
    ) == (
        b'<img src="data:image/svg+xml,%3Csvg%20xmlns=%22'
        b'http://www.w3.org/2000/svg%22/%3E">'
    )
    assert minify_html(
        '<img src="data:image/svg+xml;base64,'
        'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4=">'
    ) == (
        b'<img src="data:image/svg+xml,%3Csvg%20xmlns=%22'
        b'http://www.w3.org/2000/svg%22/%3E">'
    )


def test_short_url_values_are_left_alone():
    """Values shorter than six characters skip the scheme handling."""
    # CATCHES: the http/https and data: checks need at least six bytes.
    assert minify_html('<a href="http:">x</a>') == b'<a href=http:>x</a>'
    assert minify_html('<a href="data:">x</a>') == b"<a href=data:>x</a>"


def test_url_flag_makes_matching_scheme_relative():
    """--url http://host/ turns http URLs into protocol-relative ones."""
    # CATCHES: the host does not have to match; only the scheme does.
    res = run_minify(
        ["--type", "html", "--url", "http://example.com/"],
        stdin=b'<a href="http://example.com/">link</a>',
    )
    assert res.returncode == 0
    assert res.stdout == b"<a href=//example.com/>link</a>"
    assert res.stderr == b""

    res = run_minify(
        ["--type", "html", "--url", "http://example.com/"],
        stdin=b'<a href="http://other.com/a">x</a>',
    )
    assert res.stdout == b"<a href=//other.com/a>x</a>"


def test_url_flag_only_matches_the_same_scheme():
    """A https URL stays absolute when --url is http."""
    # CATCHES: the protocol-relative form is only used for the same scheme.
    res = run_minify(
        ["--type", "html", "--url", "https://example.com/"],
        stdin=b'<a href="http://example.com/">link</a>',
    )
    assert res.stdout == b"<a href=http://example.com/>link</a>"

    res = run_minify(
        ["--type", "html", "--url", "http://example.com/"],
        stdin=b'<a href="https://example.com/">link</a>',
    )
    assert res.stdout == b"<a href=https://example.com/>link</a>"

    res = run_minify(
        ["--type", "html", "--url", "https://example.com/"],
        stdin=b'<a href="https://example.com/">link</a>',
    )
    assert res.stdout == b"<a href=//example.com/>link</a>"


def test_url_flag_applies_after_trimming():
    """A padded absolute URL is trimmed and then made protocol-relative."""
    # CATCHES: both transformations happen to the same value.
    res = run_minify(
        ["--type", "html", "--url", "http://example.com/"],
        stdin=b'<a href="   http://example.com  ">x</a>',
    )
    assert res.stdout == b"<a href=//example.com>x</a>"


def test_url_flag_applies_to_xmlns_and_link():
    """xmlns and link href values are also rewritten."""
    # CATCHES: xmlns is a URL attribute too, and the tag is kept because it
    # has an attribute.
    res = run_minify(
        ["--type", "html", "--url", "http://example.com/"],
        stdin=b'<html xmlns="http://www.w3.org/1999/xhtml"></html>',
    )
    assert res.stdout == b"<html xmlns=//www.w3.org/1999/xhtml>"

    res = run_minify(
        ["--type", "html", "--url", "http://example.com/"],
        stdin=b'<link rel="stylesheet" type="text/css" href="http://example.com">',
    )
    assert res.stdout == b"<link rel=stylesheet href=//example.com>"


def test_url_flag_ignores_relative_and_unknown_schemes():
    """Relative paths and other schemes are untouched by --url."""
    # CATCHES: only http and https values are rewritten.
    res = run_minify(
        ["--type", "html", "--url", "http://example.com/"],
        stdin=b'<a href="/rel/path">x</a><a href="httpx://example.com/">y</a>',
    )
    assert res.stdout == b'<a href=/rel/path>x</a><a href=httpx://example.com/>y</a>'


def test_url_flag_uppercase_scheme_is_lowered_not_rewritten():
    """HTTPS:// is lower-cased but stays absolute under an http --url."""
    # CATCHES: scheme comparison happens on the lower-cased prefix.
    res = run_minify(
        ["--type", "html", "--url", "http://example.com/"],
        stdin=b'<a href="HTTPS://EXAMPLE.COM/A">x</a>',
    )
    assert res.stdout == b"<a href=https://EXAMPLE.COM/A>x</a>"
