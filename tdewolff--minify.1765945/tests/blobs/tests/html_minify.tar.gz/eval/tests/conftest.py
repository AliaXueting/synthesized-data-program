"""Shared black-box helpers for the html_minify test module.

Every expectation embedded in this module's tests was recorded by running the
reference `minify` binary through its command line interface only.  Tests never
call into the binary's internals and never hardcode a path to it: the
executable location always comes from PROGRAMGYM_EXECUTABLE.
"""

import functools
import os
import subprocess
import tempfile
from pathlib import Path

# Exact bytes printed on standard error when the deprecated
# --html-keep-conditional-comments flag is used.  The notice itself is written
# to STDOUT by the HTML minifier, before the minified document.
DEPRECATED_NOTICE = (
    b"DEPRECATED: KeepConditionalComments is replaced by KeepSpecialComments\n"
)


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running '--version' once against a throwaway GOCOVERDIR, so the
    check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="minify-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--version"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def minify_executable():
    """Return the binary under test, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the minify binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but the
    # pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to the
    # module's uninstrumented copy before pytest starts, so the counters would
    # never be written and this module's coverage report would stay empty.
    # During a coverage run (GOCOVERDIR present), when the assigned binary is
    # not itself instrumented, fall back to the instrumented build the driver
    # stages next to the module workspaces.  The staged file only exists in
    # that layout, so ordinary validation and release runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if staged.exists() and _writes_counters(str(staged)):
            return str(staged)
    return path


def _pinned_env(cwd=None, env=None):
    """Build the child environment from scratch: no TTY, no color, no noise.

    TERM, NO_COLOR and FORCE_COLOR are deliberately absent unless a test asks
    for them, and HOME always points inside the sandbox so no user-level
    configuration file can leak into a run.
    """
    home = str(cwd) if cwd is not None else tempfile.gettempdir()
    child = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
        "HOME": home,
    }
    # Forwarded only so a coverage-instrumented binary can write its counters;
    # the minify behavior under test never reads these.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    child.update(cov_env)
    if env:
        child.update(env)
    return child


def run_minify(args, stdin=b"", cwd=None, env=None, timeout=60):
    """Run the binary with 'args' and return the CompletedProcess result.

    stdin is always a pipe and stdout/stderr are always captured, so the
    program never sees a terminal.
    """
    return subprocess.run(
        [minify_executable()] + list(args),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=_pinned_env(cwd, env),
        timeout=timeout,
    )


def minify_html(text, *flags, typ="html"):
    """Minify 'text' as the given filetype on standard input.

    Returns the raw stdout bytes; the reference never appends a newline.
    """
    if isinstance(text, str):
        text = text.encode("utf-8")
    res = run_minify(["--type", typ] + list(flags), stdin=text)
    assert res.returncode == 0, (res.returncode, res.stdout, res.stderr)
    assert res.stderr == b"", res.stderr
    return res.stdout


def minify_html_err(text, *flags, typ="html"):
    """Like minify_html but returns the whole CompletedProcess (errors allowed)."""
    if isinstance(text, str):
        text = text.encode("utf-8")
    return run_minify(["--type", typ] + list(flags), stdin=text)


def write_input(directory, name, content):
    """Write 'content' into directory/name and return the path object."""
    path = Path(directory) / name
    if isinstance(content, str):
        content = content.encode("utf-8")
    path.write_bytes(content)
    return path
