"""Where HTML input comes from and where the result goes.

Covers standard input versus path arguments, filetype dispatch by extension
and by --type, the deprecated --mime flag, output destinations and exit codes.
"""

import pytest
from conftest import run_minify, write_input

DOC = b"<html>\n  <body>\n    <p>hello   world</p>\n  </body>\n</html>\n"
DOC_OUT = b"<p>hello world"

# (extension, expected stdout for TEMPLATE_SOURCES)
# The </p> end tag survives in every dialect because a template token
# follows it, and templates are treated like inline content.
TEMPLATE_EXTS = [
    ("php", b'<p>a</p><?php echo "x";  ?>'),
    ("asp", b"<p>a</p><%= foo  %>"),
    ("ejs", b"<p>a</p><%= foo  %>"),
    ("tmpl", b"<p>a</p>{{ .Name  }}"),
    ("gohtml", b"<p>a</p>{{ .Name  }}"),
    ("mustache", b"<p>a</p>{{ name  }}"),
    ("handlebars", b"<p>a</p>{{ name  }}"),
]


def test_stdin_with_type_flag():
    """stdin plus --type html is minified to stdout with no trailing newline."""
    # CATCHES: a re-implementation that appends a newline, or that requires a
    # file argument, would produce different bytes here.
    res = run_minify(["--type", "html"], stdin=DOC)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert res.stderr == b""


def test_stdin_with_full_mimetype():
    """--type accepts the full mimetype text/html as well as the short form."""
    # CATCHES: only the bare 'html' alias being recognised would break this.
    res = run_minify(["--type", "text/html"], stdin=DOC)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert res.stderr == b""


def test_stdin_without_type_is_an_error():
    """Reading stdin without --type fails instead of guessing the filetype."""
    # CATCHES: the specific 'must specify --type for stdin' diagnostics.
    res = run_minify([], stdin=DOC)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: must specify --type for stdin\n"


def test_explicit_dash_reads_stdin():
    """A single '-' argument is the explicit way to name standard input."""
    # CATCHES: treating '-' as a file name would report a stat error instead.
    res = run_minify(["-", "--type", "html"], stdin=b"<p>  a  </p>")
    assert res.returncode == 0
    assert res.stdout == b"<p>a"
    assert res.stderr == b""


def test_empty_stdin_produces_empty_output(tmp_path):
    """An empty document minifies to nothing, successfully."""
    # CATCHES: emitting a doctype, a newline or an error for empty input,
    # while an empty file bundled with a real one contributes no bytes.
    res = run_minify(["--type", "html"], stdin=b"")
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    write_input(tmp_path, "empty.html", b"")
    write_input(tmp_path, "full.html", b"<p>  hello   world  </p>")
    res = run_minify(["--bundle", "empty.html", "full.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"<p>hello world"
    assert res.stderr == b""


def test_unknown_filetype_is_rejected():
    """--type with a value that is neither alias nor mimetype is an error."""
    # CATCHES: the exact 'unknown filetype' wording and the empty operand.
    res = run_minify(["--type", "bogus"], stdin=DOC)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: unknown filetype \n"


def test_unregistered_mimetype_is_an_error():
    """A well-formed but unregistered mimetype fails and echoes the input."""
    # CATCHES: on failure the original bytes are still written to stdout.
    res = run_minify(["--type", "text/bogus"], stdin=DOC)
    assert res.returncode == 1
    assert res.stdout == DOC
    assert res.stderr == (
        b"ERROR: cannot minify -: minifier does not exist for mimetype\n"
    )


def test_deprecated_mime_flag_still_works():
    """--mime is deprecated: it works but prints a warning on stderr."""
    # CATCHES: the deprecation notice goes to stderr while stdout stays clean.
    res = run_minify(["--mime", "text/html"], stdin=DOC)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert res.stderr == (
        b"ERROR: deprecated use of '--mime text/html', "
        b"please use '--type text/html' instead\n"
    )


def test_last_type_flag_wins():
    """Repeated --type flags override each other; the final one is used."""
    # CATCHES: 'html css' must end up as CSS, so the <p> tag survives.
    res = run_minify(["--type", "html", "--type", "css"], stdin=b"<p>  a  </p>")
    assert res.returncode == 0
    assert res.stdout == b"<p>a </p>"
    assert res.stderr == b""


def test_html_file_writes_minified_result_to_stdout(tmp_path):
    """A .html path argument is minified to stdout with no progress line."""
    # CATCHES: statistics or a trailing newline must not pollute stdout when
    # the destination is the terminal-less standard output.
    write_input(tmp_path, "page.html", DOC)
    res = run_minify(["page.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert res.stderr == b""


def test_htm_extension(tmp_path):
    """The .htm extension selects the HTML minifier just like .html."""
    # CATCHES: extension dispatch must cover both spellings.
    write_input(tmp_path, "page.htm", DOC)
    res = run_minify(["page.htm"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert res.stderr == b""


def test_type_flag_overrides_the_file_extension(tmp_path):
    """--type wins over the mimetype inferred from the extension."""
    # CATCHES: a .css file asked to be html must be minified as HTML.
    write_input(tmp_path, "style.css", DOC)
    res = run_minify(["--type", "html", "style.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert res.stderr == b""


def test_unknown_extension_is_an_error(tmp_path):
    """An extension with no mimetype mapping aborts with an ERROR line."""
    # CATCHES: the message names the offending path and suggests --type.
    write_input(tmp_path, "page.xyz", DOC)
    res = run_minify(["page.xyz"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"ERROR: cannot infer mimetype from extension in page.xyz, "
        b"set --type explicitly\n"
    )


def test_missing_input_file_reports_stat_error():
    """A nonexistent path reports a stat error but still exits zero."""
    # CATCHES: the surprising exit code 0 for an unreadable input.
    res = run_minify(["nope.html"], stdin=b"")
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b"ERROR: stat nope.html: no such file or directory\n"


def test_ext_flag_maps_a_custom_extension(tmp_path):
    """--ext={ext=filetype} teaches the walker a new extension mapping."""
    # CATCHES: the curly-brace map syntax and its effect on dispatch.
    write_input(tmp_path, "note.txt", DOC)
    res = run_minify(["--ext={txt:html}", "note.txt"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert res.stderr == b""


def test_output_file_flag_writes_result_to_file(tmp_path):
    """-o writes the minified bytes to a file and -q silences the stats line."""
    # CATCHES: the destination file holds exactly the minified document.
    write_input(tmp_path, "in.html", DOC)
    res = run_minify(["-q", "-o", "out.html", "in.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "out.html").read_bytes() == DOC_OUT


def test_output_dash_writes_to_stdout(tmp_path):
    """An explicit '-o -' destination keeps standard output as the target."""
    # CATCHES: '-o -' must not create a file literally named '-'.
    write_input(tmp_path, "in.html", DOC)
    res = run_minify(["-o", "-", "in.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert res.stderr == b""
    assert not (tmp_path / "-").exists()


def test_inplace_flag_rewrites_the_input(tmp_path):
    """-i overwrites the input file with its minified contents."""
    # CATCHES: the file on disk is replaced, not left untouched.
    path = write_input(tmp_path, "ip.html", DOC)
    res = run_minify(["-q", "-i", "ip.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert path.read_bytes() == DOC_OUT


def test_two_inputs_to_stdout_need_bundle(tmp_path):
    """Multiple inputs with a stdout destination require --bundle."""
    # CATCHES: the specific error text and the failing exit code.
    write_input(tmp_path, "a.html", DOC)
    write_input(tmp_path, "b.html", DOC)
    res = run_minify(["a.html", "b.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"ERROR: must specify --bundle for multiple input files "
        b"with stdout destination\n"
    )


def test_bundle_concatenates_inputs(tmp_path):
    """--bundle concatenates the minified inputs into one stdout stream."""
    # CATCHES: bundling minifies each input and joins them back to back.
    write_input(tmp_path, "a.html", b"<p>  a  </p>")
    write_input(tmp_path, "b.html", b"<p>  b  </p>")
    res = run_minify(["--bundle", "a.html", "b.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"<p>a<p>b"
    assert res.stderr == b""


def test_recursive_needs_an_output_directory(tmp_path):
    """-r with a stdout destination is rejected instead of walked."""
    # CATCHES: the recursive walk refuses to run without a real destination.
    (tmp_path / "sub").mkdir()
    write_input(tmp_path / "sub", "b.html", b"<div>  b  </div>\n")
    res = run_minify(["-r", "sub"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"ERROR: --recursive doesn't work with stdout, "
        b"specify output or use --bundle\n"
    )


def test_recursive_into_directory_output(tmp_path):
    """-r -o dir mirrors the tree and minifies every .html below it."""
    # CATCHES: the output preserves the relative subdirectory layout.
    (tmp_path / "sub").mkdir()
    write_input(tmp_path / "sub", "b.html", b"<div>  b  </div>\n")
    res = run_minify(["-q", "-r", "-o", "outdir", "sub"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert (tmp_path / "outdir" / "sub" / "b.html").read_bytes() == b"<div>b</div>"


def test_xhtml_extension_uses_the_xml_minifier(tmp_path):
    """.xhtml dispatches to the XML minifier, which keeps end tags."""
    # CATCHES: the same document minifies differently as xhtml than as html.
    write_input(tmp_path, "page.xhtml", b"<p>  a  </p><br/>")
    res = run_minify(["page.xhtml"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"<p>a</p><br/>"
    assert res.stderr == b""


TEMPLATE_SOURCES = {
    "php": '<p>  a  </p><?php echo "x";  ?>',
    "asp": "<p>  a  </p><%= foo  %>",
    "ejs": "<p>  a  </p><%= foo  %>",
    "tmpl": "<p>  a  </p>{{ .Name  }}",
    "gohtml": "<p>  a  </p>{{ .Name  }}",
    "mustache": "<p>  a  </p>{{ name  }}",
    "handlebars": "<p>  a  </p>{{ name  }}",
}


@pytest.mark.parametrize(
    "ext,expected",
    TEMPLATE_EXTS,
    ids=[e for e, _ in TEMPLATE_EXTS],
)
def test_template_extension_passes_delimiters_through(tmp_path, ext, expected):
    """Template extensions minify HTML while leaving delimiters untouched."""
    # CATCHES: only the HTML around the dialect delimiters is collapsed.
    write_input(tmp_path, "page." + ext, TEMPLATE_SOURCES[ext])
    res = run_minify(["page." + ext], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_type_accepts_template_mimetype_on_stdin():
    """Template dialects are reachable from stdin through their mimetype."""
    # CATCHES: --type php must select the PHP-delimiter HTML minifier.
    res = run_minify(
        ["--type", "php"], stdin=b'<div class="foo">\n<?php\necho "hello";\n?>\n</div>\n'
    )
    assert res.returncode == 0
    assert res.stdout == b'<div class=foo><?php\necho "hello";\n?></div>'
    assert res.stderr == b""


def test_large_generated_document(tmp_path):
    """A document with thousands of tags minifies exactly and quickly."""
    # CATCHES: the whitespace lookahead heuristic must stay correct on long
    # token runs, and the run must not blow up.
    parts = ["<ul>"]
    for i in range(2000):
        parts.append("<li> item   %d </li>" % i)
    parts.append("</ul>")
    doc = "".join(parts)
    res = run_minify(["--type", "html"], stdin=doc.encode())
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        "<ul>" + "".join("<li>item %d" % i for i in range(2000)) + "</ul>"
    ).encode()
