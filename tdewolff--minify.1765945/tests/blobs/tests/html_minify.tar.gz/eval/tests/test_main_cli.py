"""Command line driver behaviours: flags, destinations, walking and errors.

These tests exercise the cmd/minify driver around the HTML minifier: --version
and --list, verbose logging, destination resolution (files, directories,
bundles, in-place), recursive walks with --match/--include/--exclude/--all,
--sync copying, --preserve, and the exact error messages and exit codes for
every rejected flag combination.  All expectations were recorded by running
the reference binary through its command line only.
"""

import os
import re

import pytest

from conftest import run_minify, write_input

DOC = b"<p>hello   world</p>\n"
DOC_OUT = b"<p>hello world"

# Exact bytes of `minify --list`: the extension map, sorted, each key padded
# to the width of the longest key ("webmanifest") plus two spaces.
LIST_OUTPUT = b"".join(
    line + b"\n"
    for line in [
        b"asp          text/asp",
        b"css          text/css",
        b"ejs          text/x-ejs-template",
        b"gohtml       text/x-go-template",
        b"handlebars   text/x-handlebars-template",
        b"htm          text/html",
        b"html         text/html",
        b"js           application/javascript",
        b"json         application/json",
        b"mjs          application/javascript",
        b"mustache     text/x-mustache-template",
        b"php          application/x-httpd-php",
        b"rss          application/rss+xml",
        b"svg          image/svg+xml",
        b"tmpl         text/x-template",
        b"webmanifest  application/manifest+json",
        b"xhtml        application/xhtml+xml",
        b"xml          text/xml",
    ]
)


def make_tree(tmp_path):
    """Create tree/one.html, tree/sub/two.html and tree/sub/readme.txt."""
    (tmp_path / "tree" / "sub").mkdir(parents=True)
    write_input(tmp_path / "tree", "one.html", b"<p>one</p>\n")
    write_input(tmp_path / "tree" / "sub", "two.html", b"<p>two  two</p>\n")
    write_input(tmp_path / "tree" / "sub", "readme.txt", b"plain  txt\n")
    return tmp_path / "tree"


def walked(out_dir):
    """Return the sorted relative paths of all files below out_dir."""
    return sorted(
        str(p.relative_to(out_dir)) for p in out_dir.rglob("*") if p.is_file()
    )


def test_version_flag_prints_one_line():
    """--version prints 'minify <version>' to stdout and nothing else."""
    # CATCHES: the version goes to stdout as one 'minify <version>' line,
    # --version -q prints nothing at all, and neither form writes to stderr.
    res = run_minify(["--version"])
    assert res.returncode == 0
    assert re.fullmatch(rb"minify [^\n]+\n", res.stdout)
    assert res.stderr == b""
    res = run_minify(["--version", "--quiet"])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_list_flag_prints_the_extension_map():
    """--list prints every known extension with its mimetype, sorted."""
    # CATCHES: the exact 18-entry table with column padding, and -q silences
    # even the listing while still exiting successfully.
    res = run_minify(["--list"])
    assert res.returncode == 0
    assert res.stdout == LIST_OUTPUT
    assert res.stderr == b""
    res = run_minify(["-l", "-q"])
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_list_includes_custom_ext_mapping(tmp_path):
    """--ext teaches the driver a new extension, visible in --list and used."""
    # CATCHES: the filetype alias 'html' is translated to text/html in the
    # listing, and a .foo file is then minified as HTML.
    res = run_minify(["--ext={foo:html}", "--list"])
    assert res.returncode == 0
    assert res.stdout == LIST_OUTPUT.replace(
        b"ejs          text/x-ejs-template\n",
        b"ejs          text/x-ejs-template\nfoo          text/html\n",
    )
    write_input(tmp_path, "page.foo", b"<p>  custom  </p>")
    res = run_minify(["--ext={foo:html}", "page.foo"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"<p>custom"
    assert res.stderr == b""


def test_invalid_ext_map_is_a_usage_error(tmp_path):
    """An --ext value without the {ext:filetype} shape aborts with usage."""
    # CATCHES: the exit code is 2 (not 1), the complaint lands on stderr while
    # the full option usage is printed to stdout.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["--ext=foo", "a.html"], cwd=tmp_path)
    assert res.returncode == 2
    assert res.stderr == b"option --ext: invalid map\n\n"
    assert b"--html-keep-comments" in res.stdout
    assert b"[options] inputs..." in res.stdout


def test_verbose_once_logs_finish_line(tmp_path):
    """-v adds a single INFO timing line on stderr, stdout stays clean."""
    # CATCHES: verbosity goes to stderr only; the minified document is still
    # the whole of stdout.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["-v", "a.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert re.fullmatch(rb"INFO: finished in .+\n", res.stderr)


def test_verbose_twice_logs_debug_lines(tmp_path):
    """-vv traces the mimetype inference and destination on stderr."""
    # CATCHES: the debug lines name the inference and 'minify to stdout',
    # and the INFO finish line still comes last.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["-vv", "a.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT
    assert b"DEBUG: infer mimetype from file extensions\n" in res.stderr
    assert b"DEBUG: minify to stdout\n" in res.stderr
    assert re.fullmatch(
        rb"DEBUG: infer mimetype from file extensions\n"
        rb"DEBUG: minify to stdout\n"
        rb"INFO: finished in .+\n",
        res.stderr,
    )


def test_inplace_conflicts(tmp_path):
    """--inplace refuses stdin and refuses a simultaneous --output."""
    # CATCHES: two distinct error texts, each with exit code 1.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["-i", "--type", "html"], stdin=DOC)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: --inplace doesn't work with stdin, specify input\n"
    res = run_minify(["-i", "-o", "o.html", "a.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: cannot specify both --inplace and --output\n"


@pytest.mark.parametrize(
    "flag,message",
    [
        ("--watch", b"--watch doesn't work with stdin and stdout, specify input and output\n"),
        ("--sync", b"--sync doesn't work with stdin and stdout, specify input and output\n"),
        ("--bundle", b"--bundle doesn't work with stdin, specify input\n"),
        ("--recursive", b"--recursive doesn't work with stdin, specify input\n"),
    ],
    ids=["watch", "sync", "bundle", "recursive"],
)
def test_long_running_flags_reject_stdin(flag, message):
    """--watch/--sync/--bundle/--recursive all refuse a stdio run."""
    # CATCHES: each flag has its own refusal text and exit code 1.
    res = run_minify([flag, "--type", "html"], stdin=DOC)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: " + message


def test_sync_with_type_is_rejected(tmp_path):
    """--sync and --type are mutually exclusive."""
    # CATCHES: the driver refuses to guess per-file mimetypes in sync mode.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["--type", "html", "--sync", "-o", "o.html", "a.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: must specify either --sync or --type\n"


def test_preserve_flag_rejected_with_stdin():
    """--preserve cannot be combined with stdin."""
    # CATCHES: only an explicitly set --preserve is refused; the implicit
    # default preserve list is silently dropped for stdio runs.
    res = run_minify(["--preserve=mode", "--type", "html"], stdin=DOC)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"ERROR: --preserve cannot be used together with stdin, "
        b"stdout or --inplace\n"
    )
    res = run_minify(["--type", "html"], stdin=DOC)
    assert res.returncode == 0
    assert res.stdout == DOC_OUT


def test_mixing_files_and_stdin_fails(tmp_path):
    """A '-' operand next to real file paths aborts the run."""
    # CATCHES: the mixture is detected before any file is opened.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["--type", "html", "a.html", "-"], stdin=DOC, cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: cannot mix files and stdin as input\n"


def test_invalid_url_is_an_error():
    """An unparseable --url value aborts before any minification."""
    # CATCHES: the raw url.Parse error text is surfaced with the ERROR prefix.
    res = run_minify(["--type", "html", "--url", ":"], stdin=DOC)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'ERROR: parse ":": missing protocol scheme\n'


def test_invalid_match_pattern_is_an_error(tmp_path):
    """A ~-prefixed --match pattern is a raw regexp and can fail to compile."""
    # CATCHES: the regexp compile error aborts with exit code 1 before the
    # input is touched.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["--match", "~[", "-o", "o.html", "a.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: error parsing regexp: missing closing ]: `[`\n"


@pytest.mark.parametrize("filter_flag", ["--exclude", "--include"])
def test_invalid_filter_pattern_is_an_error(tmp_path, filter_flag):
    """A ~-prefixed --exclude/--include pattern must compile as a regexp."""
    # CATCHES: the filter patterns share the same ~-regexp syntax as --match
    # and a broken one aborts before any file is walked.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify([filter_flag, "~[", "-o", "o.html", "a.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: error parsing regexp: missing closing ]: `[`\n"


def test_match_filters_by_basename(tmp_path):
    """--match takes several patterns and matches them against basenames."""
    # CATCHES: 'readme*' matches the .txt basename so it is minified as HTML
    # under --type html, while two.html is left out entirely.
    tree = make_tree(tmp_path)
    res = run_minify(
        ["-q", "--type", "html", "-r", "--match", "one*", "readme*", "-o", "out", "tree"],
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert walked(tmp_path / "out") == [
        "tree/one.html",
        "tree/sub/readme.txt",
    ]
    assert (tmp_path / "out" / "tree" / "sub" / "readme.txt").read_bytes() == b"plain txt"


def test_exclude_matches_full_paths_not_basenames(tmp_path):
    """--exclude patterns are matched against the whole walked path."""
    # CATCHES: '*.txt' cannot match 'tree/sub/readme.txt' because * does not
    # cross directory separators, while '**.txt' can, so only the latter
    # removes the file from the walk.
    make_tree(tmp_path)
    res = run_minify(
        ["-q", "--type", "html", "-r", "--exclude", "**.txt", "-o", "out1", "tree"],
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert walked(tmp_path / "out1") == ["tree/one.html", "tree/sub/two.html"]
    res = run_minify(
        ["-q", "--type", "html", "-r", "--exclude", "*.txt", "-o", "out2", "tree"],
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert walked(tmp_path / "out2") == [
        "tree/one.html",
        "tree/sub/readme.txt",
        "tree/sub/two.html",
    ]
    assert (tmp_path / "out2" / "tree" / "sub" / "readme.txt").read_bytes() == b"plain txt"


def test_exclude_then_include_reincludes(tmp_path):
    """A later --include re-admits paths an earlier --exclude removed."""
    # CATCHES: the filters are evaluated in order and the last matching one
    # wins, so '**two*' survives the blanket '**' exclusion.
    make_tree(tmp_path)
    res = run_minify(
        [
            "-q", "--type", "html", "-r",
            "--exclude", "**", "--include", "**two*",
            "-o", "out", "tree",
        ],
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert walked(tmp_path / "out") == ["tree/sub/two.html"]
    assert (tmp_path / "out" / "tree" / "sub" / "two.html").read_bytes() == b"<p>two two"


def test_hidden_files_need_the_all_flag(tmp_path):
    """Dotfiles and hidden directories are skipped during walks unless -a."""
    # CATCHES: the walker checks the first byte of every entry name, and a
    # hidden directory prunes the whole subtree, not just its own entry.
    (tmp_path / "tree" / "sub").mkdir(parents=True)
    (tmp_path / "tree" / ".cache").mkdir(parents=True)
    write_input(tmp_path / "tree", ".hidden.html", b"<p>  hid  </p>")
    write_input(tmp_path / "tree" / ".cache", "h.html", b"<p>  cache  </p>")
    write_input(tmp_path / "tree", "one.html", b"<p>one</p>\n")
    res = run_minify(["-q", "-r", "-o", "out1", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert walked(tmp_path / "out1") == ["tree/one.html"]
    res = run_minify(["-q", "-r", "-a", "-o", "out2", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert walked(tmp_path / "out2") == [
        "tree/.cache/h.html",
        "tree/.hidden.html",
        "tree/one.html",
    ]
    assert (tmp_path / "out2" / "tree" / ".hidden.html").read_bytes() == b"<p>hid"
    assert (tmp_path / "out2" / "tree" / ".cache" / "h.html").read_bytes() == b"<p>cache"


def test_type_flag_covers_every_walked_file(tmp_path):
    """With --type every walked file is minified, whatever its extension."""
    # CATCHES: the .txt file is minified as HTML (its double space collapses)
    # because --type disables per-extension dispatch.
    make_tree(tmp_path)
    res = run_minify(["-q", "--type", "html", "-r", "-o", "out", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert walked(tmp_path / "out") == [
        "tree/one.html",
        "tree/sub/readme.txt",
        "tree/sub/two.html",
    ]
    assert (tmp_path / "out" / "tree" / "sub" / "readme.txt").read_bytes() == b"plain txt"


def test_multiple_inputs_share_an_output_directory(tmp_path):
    """Several inputs with one -o name are written into a directory."""
    # CATCHES: the plain -o value is promoted to a directory destination, and
    # each input keeps its own name and own mimetype dispatch.
    write_input(tmp_path, "a.html", DOC)
    write_input(tmp_path, "b.css", b"body{a:b}")
    res = run_minify(["-q", "-o", "out", "a.html", "b.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert walked(tmp_path / "out") == ["a.html", "b.css"]
    assert (tmp_path / "out" / "a.html").read_bytes() == DOC_OUT
    assert (tmp_path / "out" / "b.css").read_bytes() == b"body{a:b}"


def test_bundle_destination_conflicts(tmp_path):
    """--bundle refuses directory destinations and --inplace."""
    # CATCHES: a trailing slash on -o makes it a directory, which --bundle
    # rejects; --bundle with --inplace is refused as well.
    write_input(tmp_path, "a.html", DOC)
    write_input(tmp_path, "b.html", b"<div>  x  </div>\n")
    res = run_minify(["--bundle", "-o", "out/", "a.html", "b.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: --bundle requires destination to be stdout or a file\n"
    res = run_minify(["-b", "-i", "a.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == b"ERROR: --bundle cannot be used together with --inplace\n"


def test_output_directory_conflicting_with_a_file(tmp_path):
    """A -o that names an existing file cannot become a directory."""
    # CATCHES: two inputs turn the destination into a directory, and creating
    # 'bundle.html/' over the regular file fails with mkdir's own error.
    write_input(tmp_path, "a.html", DOC)
    write_input(tmp_path, "b.html", b"<div>  x  </div>\n")
    write_input(tmp_path, "bundle.html", b"occupied")
    res = run_minify(["-o", "bundle.html", "a.html", "b.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: mkdir bundle.html/: file exists\n"
    assert (tmp_path / "bundle.html").read_bytes() == b"occupied"


def test_bundle_to_output_file_and_stats(tmp_path):
    """--bundle -o file concatenates and reports the source list."""
    # CATCHES: the file holds both minified documents back to back and the
    # stats line names the bundle as '(a.html + b.html)'.
    write_input(tmp_path, "a.html", DOC)
    write_input(tmp_path, "b.html", b"<div>  x  </div>\n")
    res = run_minify(["--bundle", "-o", "bundle.html", "a.html", "b.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (tmp_path / "bundle.html").read_bytes() == b"<p>hello world<div>x</div>"
    assert res.stdout.endswith(b") - (a.html + b.html) to bundle.html\n")
    assert b",   38 B,   26 B,  68.4%, " in res.stdout


def test_stats_line_for_file_destination(tmp_path):
    """A file destination without -q prints a statistics line on stdout."""
    # CATCHES: the byte counts and ratio are exact for this input, the source
    # and destination names are appended, and -q removes the line entirely.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["-o", "st.html", "a.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout.endswith(b") - a.html to st.html\n")
    assert b",   21 B,   14 B,  66.7%, " in res.stdout
    res = run_minify(["-q", "-o", "st.html", "a.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_recursive_walks_subdirectories(tmp_path):
    """-r mirrors the input tree under the output directory."""
    # CATCHES: subdirectory layout is preserved and every file is minified;
    # with more than one task the driver fans out to its worker pool.
    make_tree(tmp_path)
    res = run_minify(["-q", "-r", "-o", "out", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert walked(tmp_path / "out") == ["tree/one.html", "tree/sub/two.html"]
    assert (tmp_path / "out" / "tree" / "one.html").read_bytes() == b"<p>one"
    assert (tmp_path / "out" / "tree" / "sub" / "two.html").read_bytes() == b"<p>two two"


def test_directory_input_without_recursive_warns(tmp_path):
    """A directory operand without -r is skipped with a warning."""
    # CATCHES: the run still succeeds with exit code 0, the empty output
    # directory is created anyway, and nothing is minified.
    make_tree(tmp_path)
    res = run_minify(["-o", "out", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b"WARNING: --recursive not specified, omitting directory tree\n"
    assert (tmp_path / "out").is_dir()
    assert walked(tmp_path / "out") == []


def test_sync_copies_files_it_cannot_minify(tmp_path):
    """--sync mirrors every file and minifies only the known extensions."""
    # CATCHES: readme.txt is copied byte for byte while the .html files are
    # minified into the same tree.
    make_tree(tmp_path)
    res = run_minify(["-q", "-s", "-r", "-o", "out", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert walked(tmp_path / "out") == [
        "tree/one.html",
        "tree/sub/readme.txt",
        "tree/sub/two.html",
    ]
    assert (tmp_path / "out" / "tree" / "sub" / "readme.txt").read_bytes() == b"plain  txt\n"
    assert (tmp_path / "out" / "tree" / "one.html").read_bytes() == b"<p>one"


def test_recursive_trailing_slash_and_single_file(tmp_path):
    """A trailing slash on the input changes the output layout."""
    # CATCHES: 'tree/' makes the tree itself the root, so files land directly
    # under the output directory without the tree/ level; -r also accepts a
    # plain file operand.
    make_tree(tmp_path)
    res = run_minify(["-q", "-r", "-o", "out", "tree/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert walked(tmp_path / "out") == ["one.html", "sub/two.html"]
    write_input(tmp_path, "solo.html", b"<p>  solo  </p>")
    res = run_minify(["-q", "-r", "-o", "solo-out.html", "solo.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "solo-out.html").read_bytes() == b"<p>solo"


def test_match_with_unknown_extension_fails(tmp_path):
    """A --match hit on a file with an unknown extension is an error."""
    # CATCHES: the match filter admits note.txt, but the driver cannot infer
    # its mimetype and aborts with exit code 1 naming the file.
    write_input(tmp_path, "note.txt", b"note")
    res = run_minify(["--match", "*.txt", "-o", "o.html", "note.txt"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"ERROR: cannot infer mimetype from extension in note.txt, "
        b"set --type explicitly\n"
    )


def test_bundle_with_unequal_mimetypes_fails(tmp_path):
    """--bundle refuses inputs whose extensions infer different mimetypes."""
    # CATCHES: the second file's mimetype is reported in the warning and the
    # exit code is 1 even though both files exist and parse.
    write_input(tmp_path, "a.html", DOC)
    write_input(tmp_path, "b.css", b"body{a:b}")
    res = run_minify(["--bundle", "a.html", "b.css"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b"WARNING: inferred mimetype text/css of b.css for concatenation "
        b"unequal to previous mimetypes, set --type explicitly\n"
    )


def test_output_parents_are_created(tmp_path):
    """Missing parent directories of the -o target are created."""
    # CATCHES: the destination deep/nested/o.html did not exist and the run
    # still succeeds, writing the minified file through the new directories.
    write_input(tmp_path, "a.html", DOC)
    res = run_minify(["-q", "-o", "deep/nested/o.html", "a.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (tmp_path / "deep" / "nested" / "o.html").read_bytes() == DOC_OUT


def test_output_equal_to_input_uses_backup(tmp_path):
    """Naming the input as -o rewrites it in place through a .bak file."""
    # CATCHES: the file ends up minified, the temporary .bak is removed
    # afterwards, and the stats line shows the same name twice.
    path = write_input(tmp_path, "s.html", b"<p>  same  </p>")
    res = run_minify(["-o", "s.html", "s.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert path.read_bytes() == b"<p>same"
    assert not (tmp_path / "s.html.bak").exists()
    assert re.fullmatch(rb"\(.+\) - s\.html\n", res.stdout)
    assert b",   15 B,    7 B,  46.7%, " in res.stdout


def test_inplace_over_multiple_files(tmp_path):
    """-i rewrites each named file in place."""
    # CATCHES: both files are replaced by their minified contents and nothing
    # is written to stdout.
    p1 = write_input(tmp_path, "b.html", b"<div>  x  </div>\n")
    p2 = write_input(tmp_path, "c.html", b"<p>x</p>")
    res = run_minify(["-q", "-i", "b.html", "c.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert p1.read_bytes() == b"<div>x</div>"
    assert p2.read_bytes() == b"<p>x"


def test_fifo_input_is_rejected(tmp_path):
    """A named pipe operand is neither file nor directory and aborts."""
    # CATCHES: only regular files and directories are accepted operands.
    os.mkfifo(str(tmp_path / "pipe.html"))
    res = run_minify(["pipe.html"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: not a file or directory pipe.html\n"


def test_preserve_links_requires_sync_for_symlinks(tmp_path):
    """--preserve links refuses to follow a symlink without --sync."""
    # CATCHES: the driver names the link and demands --sync before it will
    # copy a symbolic link as is.
    write_input(tmp_path, "a.html", DOC)
    os.symlink("a.html", str(tmp_path / "link.html"))
    res = run_minify(
        ["--preserve=links", "-o", "out.html", "link.html"], cwd=tmp_path
    )
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: --sync not specified, omitting symbolic link link.html\n"


def test_broken_symlink_in_a_walk_is_skipped(tmp_path):
    """A dangling symlink met during a walk is reported and then skipped."""
    # CATCHES: the stat failure becomes an ERROR line on stderr but not a
    # failing exit code, and the link produces no file in the output tree.
    make_tree(tmp_path)
    os.symlink("/nonexistent/target", str(tmp_path / "tree" / "sub" / "broken.html"))
    res = run_minify(["-r", "-o", "out", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == (
        b"ERROR: stat tree/sub/broken.html: no such file or directory\n"
    )
    assert walked(tmp_path / "out") == ["tree/one.html", "tree/sub/two.html"]


def test_preserve_links_walk_warns_then_sync_copies(tmp_path):
    """In walks --preserve=links without --sync only warns, --sync copies."""
    # CATCHES: unlike a direct symlink operand (a hard error), a symlink met
    # during a recursive walk is omitted with a WARNING and exit code 0, and
    # with --sync the very same link is recreated verbatim in the output.
    make_tree(tmp_path)
    os.symlink("one.html", str(tmp_path / "tree" / "lnk.html"))
    res = run_minify(["--preserve=links", "-r", "-o", "out1", "tree"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == (
        b"WARNING: --sync not specified, omitting symbolic link tree/lnk.html\n"
    )
    assert walked(tmp_path / "out1") == ["tree/one.html", "tree/sub/two.html"]
    res = run_minify(
        ["-q", "--preserve=links", "--sync", "-r", "-o", "out2", "tree"],
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert walked(tmp_path / "out2") == [
        "tree/lnk.html",
        "tree/one.html",
        "tree/sub/readme.txt",
        "tree/sub/two.html",
    ]
    copied = tmp_path / "out2" / "tree" / "lnk.html"
    assert copied.is_symlink()
    assert os.readlink(str(copied)) == "one.html"
    assert (tmp_path / "out2" / "tree" / "one.html").read_bytes() == b"<p>one"
    assert (tmp_path / "out2" / "tree" / "sub" / "readme.txt").read_bytes() == b"plain  txt\n"


def test_recursive_failure_aggregates_through_workers(tmp_path):
    """One bad file fails the run while the other files still minify."""
    # CATCHES: with several tasks the driver fans out to workers; the bad
    # file aborts with exit code 1 and its ORIGINAL bytes are written to the
    # destination, while the good file is minified normally.
    (tmp_path / "src").mkdir()
    write_input(tmp_path / "src", "good.html", b"<p>ok</p>")
    bad = write_input(tmp_path / "src", "bad.html", b"<script>var 1 = </script>")
    res = run_minify(["-q", "-r", "-o", "out", "src"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b""
    res = run_minify(["-r", "-o", "out", "src"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr.startswith(
        b"ERROR: cannot minify src/bad.html: unexpected 1 in binding "
        b"on line 1 and column 13\n"
    )
    assert b"src/good.html to out/src/good.html" in res.stdout
    assert (tmp_path / "out" / "src" / "good.html").read_bytes() == b"<p>ok"
    assert (tmp_path / "out" / "src" / "bad.html").read_bytes() == bad.read_bytes()


def test_mode_and_timestamps_are_preserved_by_default(tmp_path):
    """By default the output inherits the input's mode and mtime."""
    # CATCHES: the 0640 permissions and the year-2000 modification time of
    # the source reappear on the minified destination file, and the explicit
    # --preserve=all spelling behaves exactly the same.
    src = write_input(tmp_path, "pm.html", b"<p>  m  </p>")
    os.chmod(str(src), 0o640)
    os.utime(str(src), (946699200, 946699200))
    res = run_minify(["-q", "-o", "po.html", "pm.html"], cwd=tmp_path)
    assert res.returncode == 0
    out = tmp_path / "po.html"
    assert out.read_bytes() == b"<p>m"
    assert os.stat(str(out)).st_mode & 0o777 == 0o640
    assert os.stat(str(out)).st_mtime == 946699200
    os.utime(str(src), (946699200, 946699200))
    res = run_minify(["-q", "--preserve=all", "-o", "po2.html", "pm.html"], cwd=tmp_path)
    assert res.returncode == 0
    out = tmp_path / "po2.html"
    assert os.stat(str(out)).st_mode & 0o777 == 0o640
    assert os.stat(str(out)).st_mtime == 946699200


def test_stdin_to_output_file(tmp_path):
    """stdin with -o writes the file and warns about the '-' source."""
    # CATCHES: the destination holds the minified stdin, the stats line is
    # '- - to so.html', and stderr carries exactly one warning because the
    # driver tries to stat the stdin placeholder for attribute preservation.
    res = run_minify(
        ["--type", "html", "-o", "so.html"], stdin=b"<p>  s  </p>", cwd=tmp_path
    )
    assert res.returncode == 0
    assert res.stderr == b"WARNING: stat -: no such file or directory\n"
    assert res.stdout.endswith(b" - - to so.html\n")
    assert b",   12 B,    4 B,  33.3%, " in res.stdout
    assert (tmp_path / "so.html").read_bytes() == b"<p>s"
