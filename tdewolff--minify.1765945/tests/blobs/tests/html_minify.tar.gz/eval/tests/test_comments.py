"""Comment handling: default removal, keep flags and special comments.

Comments are removed by default; --html-keep-comments keeps all of them;
--html-keep-special-comments keeps IE conditional comments (recursively
minified when downlevel-hidden) and SSI comments; the deprecated
--html-keep-conditional-comments prints a notice on stdout and then behaves
like --html-keep-special-comments.
"""

from conftest import DEPRECATED_NOTICE, minify_html, minify_html_err


def test_comments_are_removed_by_default():
    """An ordinary comment produces no output at all."""
    # CATCHES: the whole comment token is dropped, leaving no separator.
    assert minify_html("<p>a</p><!-- hello --><p>b</p>") == b"<p>a</p><p>b"
    assert minify_html("text\n<!--comment-->\ntext") == b"text\ntext"
    assert minify_html("<!-- a --><!-- b -->") == b""


def test_ssi_comments_are_removed_by_default():
    """<!--#...--> SSI directives are comments like any other by default."""
    # CATCHES: the surrounding document survives while the SSI tag vanishes,
    # so an implementation that keeps SSI tags unconditionally breaks this.
    assert minify_html(
        '<p>a</p><!--#include virtual="header.html" --><p>b</p>'
    ) == b"<p>a</p><p>b"


def test_conditional_comments_are_removed_by_default():
    """Downlevel-hidden and downlevel-revealed conditionals are dropped."""
    # CATCHES: both syntaxes vanish without the special-comments flag, but the
    # revealed inner markup is still minified.
    assert minify_html("<!--[if IE 6]><p>old</p><![endif]-->") == b""
    assert minify_html("<![if !IE]><p>  x  </p><![endif]>") == b"<p>x</p>"


def test_keep_comments_flag_keeps_everything():
    """--html-keep-comments writes the comment bytes back verbatim."""
    # CATCHES: the comment data is not re-minified in any way.
    assert minify_html(
        "<p>a</p><!-- hello --><p>b</p>", "--html-keep-comments"
    ) == b"<p>a</p><!-- hello --><p>b"
    assert minify_html(
        "<!--[if IE 6]><p>  old  </p><![endif]-->", "--html-keep-comments"
    ) == b"<!--[if IE 6]><p>  old  </p><![endif]-->"
    assert minify_html("<!--\n multi\n line\n-->", "--html-keep-comments") == (
        b"<!--\n multi\n line\n-->"
    )


def test_special_comments_keeps_downlevel_hidden_and_minifies_it():
    """A downlevel-hidden conditional is kept and its body is minified."""
    # CATCHES: only the inner document is re-minified; the wrappers are exact.
    assert minify_html(
        "<!--[if IE 6]><p>old</p><![endif]-->", "--html-keep-special-comments"
    ) == b"<!--[if IE 6]><p>old<![endif]-->"
    assert minify_html(
        "<!--[if IE 6]><p>  old  </p><![endif]-->", "--html-keep-special-comments"
    ) == b"<!--[if IE 6]><p>old<![endif]-->"
    assert minify_html(
        "<!--[if lt IE 9]><p>a  b</p><![endif]-->", "--html-keep-special-comments"
    ) == b"<!--[if lt IE 9]><p>a b<![endif]-->"


def test_special_comments_keeps_downlevel_revealed_verbatim():
    """A downlevel-revealed conditional is written back untouched."""
    # CATCHES: revealed conditionals are not recursively minified.
    assert minify_html(
        "<![if !IE]><p>x</p><![endif]>", "--html-keep-special-comments"
    ) == b"<![if !IE]><p>x</p><![endif]>"
    assert minify_html(
        "<![if IE 6]> <b> </b> <![endif]>", "--html-keep-special-comments"
    ) == b"<![if IE 6]><b></b><![endif]>"


def test_special_comments_keeps_split_conditional_markers():
    """Conditionals written as separate comments are all preserved."""
    # CATCHES: the [endif] suffix detection also matches the split form.
    assert minify_html(
        "<!--[if IE 6]--> <b> </b> <!--[endif]-->", "--html-keep-special-comments"
    ) == b"<!--[if IE 6]--><b></b><!--[endif]-->"
    assert minify_html(
        "<!--[if !mso]><!--> <b> </b> <!--<![endif]-->", "--html-keep-special-comments"
    ) == b"<!--[if !mso]><!--><b></b><!--<![endif]-->"
    assert minify_html(
        "<!--[if gt IE 6]><!--> <b> </b> <![endif]>", "--html-keep-special-comments"
    ) == b"<!--[if gt IE 6]><!--><b></b><![endif]>"


def test_special_comments_keeps_short_and_nested_forms():
    """Short downlevel-hidden and deeply nested conditionals survive."""
    # CATCHES: the [if IE]foo<![endif]--> form has no '>' to split on.
    assert minify_html(
        "<!--[if IE]><![endif]-->", "--html-keep-special-comments"
    ) == b"<!--[if IE]><![endif]-->"
    assert minify_html(
        "<!--[if IE]foo<![endif]-->", "--html-keep-special-comments"
    ) == b"<!--[if IE]foo<![endif]-->"


def test_special_comments_keeps_ssi_tags():
    """<!--#...--> SSI directives are preserved byte for byte."""
    # CATCHES: the leading '#' in the comment text is the discriminator.
    assert minify_html(
        '<!--#include virtual="header.html" -->', "--html-keep-special-comments"
    ) == b'<!--#include virtual="header.html" -->'
    assert minify_html(
        "<!--# SSI-->", "--html-keep-special-comments"
    ) == b"<!--# SSI-->"


def test_special_comments_drops_ordinary_comments():
    """--html-keep-special-comments still removes normal comments."""
    # CATCHES: the flag is narrower than --html-keep-comments.
    assert minify_html(
        "<p>a</p><!-- hello --><p>b</p>", "--html-keep-special-comments"
    ) == b"<p>a</p><p>b"


def test_deprecated_conditional_comments_flag_behaves_like_special():
    """The deprecated flag prints a stdout notice then keeps special comments."""
    # CATCHES: the notice goes to STDOUT (before the document), not stderr.
    res = minify_html_err(
        "<!--[if IE 6]><p>old</p><![endif]-->", "--html-keep-conditional-comments"
    )
    assert res.returncode == 0
    assert res.stdout == (
        DEPRECATED_NOTICE + b"<!--[if IE 6]><p>old<![endif]-->"
    )
    assert res.stderr == b""


def test_deprecated_flag_notice_is_printed_once():
    """The deprecation notice appears exactly once per run."""
    # CATCHES: two conditional comments must not print the notice twice.
    res = minify_html_err(
        "<!--[if IE]><![endif]--><!--[if IE]><![endif]-->",
        "--html-keep-conditional-comments",
    )
    assert res.returncode == 0
    assert res.stdout == DEPRECATED_NOTICE + b"<!--[if IE]><![endif]--><!--[if IE]><![endif]-->"
    assert res.stderr == b""


def test_deprecated_flag_still_removes_ordinary_comments():
    """The deprecated flag does not imply --html-keep-comments."""
    # CATCHES: only special comments are kept by the deprecated flag.
    res = minify_html_err(
        "<!-- ordinary --><!--[if IE]><![endif]-->", "--html-keep-conditional-comments"
    )
    assert res.returncode == 0
    assert res.stdout == DEPRECATED_NOTICE + b"<!--[if IE]><![endif]-->"
    assert res.stderr == b""


def test_empty_downlevel_hidden_comment_is_kept_verbatim():
    """A downlevel-hidden conditional with no body stays byte for byte."""
    # CATCHES: even with nothing between the wrappers, the whole marker
    # sequence survives --html-keep-special-comments unchanged.
    assert minify_html("<!--[if lt IE 9]><![endif]-->", "--html-keep-special-comments") == (
        b"<!--[if lt IE 9]><![endif]-->"
    )


def test_downlevel_hidden_javascript_error_aborts():
    """A JavaScript error inside a downlevel-hidden conditional aborts."""
    # CATCHES: exit code 1, the original comment bytes still on stdout, and
    # the JS error on stderr with its two-line source excerpt.
    res = minify_html_err(
        "<!--[if lt IE 9]><script>a(</script><![endif]-->",
        "--html-keep-special-comments",
    )
    assert res.returncode == 1
    assert res.stdout == b"<!--[if lt IE 9]><script>a(</script><![endif]-->"
    assert res.stderr == (
        b"ERROR: cannot minify -: expected ) instead of EOF in arguments"
        b" on line 1 and column 11\n"
        b"    1: a(\n"
        b"         ^\n"
    )
