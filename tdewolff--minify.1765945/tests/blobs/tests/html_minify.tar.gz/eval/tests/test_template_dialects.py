"""Template dialects: go templates, PHP, ASP/EJS and the {{ }} family.

Everything between the dialect's delimiters passes through untouched, while
the HTML around it is minified normally.  Attributes and raw-tag bodies that
contain a template are skipped entirely.
"""

import pytest
from conftest import minify_html, run_minify


def test_go_template_in_an_attribute_value():
    """An unquoted {{ .Link }} attribute value survives verbatim."""
    # CATCHES: the template is not mistaken for attribute syntax, and the
    # trailing solidus of the void tag is dropped.
    assert minify_html("<a href={{ .Link }} />", typ="text/x-go-template") == (
        b"<a href={{ .Link }}>"
    )


def test_go_template_next_to_a_real_value():
    """A template inside a longer attribute value keeps its quotes."""
    # CATCHES: the quotes cannot be dropped because the value is not simple.
    assert minify_html(
        '<input type="file" accept="{{ .Accept }}, image/jpeg">',
        typ="text/x-go-template",
    ) == b'<input type=file accept="{{ .Accept }}, image/jpeg">'


def test_go_template_as_a_bare_attribute():
    """A template used as a whole attribute is written back as-is."""
    # CATCHES: the bare template attribute keeps its case verbatim (it is not
    # lower-cased like ordinary attribute names) and the optional </option>
    # is omitted; the same text under plain --type html IS lower-cased,
    # because only template mimetypes recognise the delimiters.
    assert minify_html(
        '<option value="0" {{ if eq .Type 0 }}selected{{ end }}>Foo</option>',
        typ="text/x-go-template",
    ) == b"<option value=0 {{ if eq .Type 0 }}selected{{ end }}>Foo"
    assert minify_html(
        '<option value="0" {{ if eq .Type 0 }}selected{{ end }}>Foo</option>',
        typ="html",
    ) == b"<option value=0 {{ if eq .type 0 }}selected{{ end }}>Foo"
    assert minify_html(
        "<tr{{if .Deleted}} class=\"is-disabled\"{{end}}>", typ="text/x-go-template"
    ) == b'<tr{{if .Deleted}} class="is-disabled"{{end}}>'


def test_go_template_inside_style_and_script():
    """Templates inside raw tags disable the CSS and JS minifiers."""
    # CATCHES: the whole raw body is passed through when it has a template.
    assert minify_html(
        "<style>a { color: {{.Color}} }</style>", typ="text/x-go-template"
    ) == b"<style>a { color: {{.Color}} }</style>"
    assert minify_html(
        "<script>alert( {{.Alert}} )</script>", typ="text/x-go-template"
    ) == b"<script>alert( {{.Alert}} )</script>"
    assert minify_html(
        '<div style=" color: {{.Color}} ">', typ="text/x-go-template"
    ) == b'<div style=" color: {{.Color}} ">'
    assert minify_html(
        '<button onclick=" alert( {{.Alert}} ) ">', typ="text/x-go-template"
    ) == b'<button onclick=" alert( {{.Alert}} ) ">'


def test_go_template_whitespace_handling():
    """Whitespace around templates follows the ordinary tag rules."""
    # CATCHES: a template token acts like a tag boundary for whitespace.
    assert minify_html("a<p>  {{a}}  </p>b", typ="text/x-go-template") == b"a<p>{{a}}</p>b"
    assert minify_html("a<span>  {{a}}  </span>b", typ="text/x-go-template") == (
        b"a<span> {{a}} </span>b"
    )
    assert minify_html("  {{a}}  {{b}}  ", typ="text/x-go-template") == b"{{a}} {{b}}"
    assert minify_html('{{ printf "  !  " }}', typ="text/x-go-template") == (
        b'{{ printf "  !  " }}'
    )


def test_go_template_in_select_and_option():
    """range/end templates around options are preserved exactly."""
    # CATCHES: the option text skipping must not swallow the templates.
    assert minify_html(
        "<select>{{ range . }}<option>{{ . }}{{ end }}</select>",
        typ="text/x-go-template",
    ) == b"<select>{{ range . }}<option>{{ . }}{{ end }}</select>"
    assert minify_html(
        "<select><option>Default</option>{{range $i, $lang := .Languages}}"
        "<option>{{$lang}}</option>{{end}}</select>",
        typ="text/x-go-template",
    ) == (
        b"<select><option>Default{{range $i, $lang := .Languages}}"
        b"<option>{{$lang}}{{end}}</select>"
    )


def test_php_template_keeps_its_whitespace():
    """A multi-line PHP block keeps its internal newlines."""
    # CATCHES: only the HTML around <?php ... ?> is rewritten.
    assert minify_html(
        '\n<div class="foo">\n<?php\necho "hello";\n?>\n</div>\n',
        typ="application/x-httpd-php",
    ) == b'<div class=foo><?php\necho "hello";\n?></div>'


def test_php_short_tags_are_also_delimiters():
    """<? without php is a valid opening delimiter."""
    # CATCHES: both <?php and <? open a template region.
    assert minify_html("<p>  a  </p><?= foo  ?>", typ="application/x-httpd-php") == (
        b"<p>a</p><?= foo  ?>"
    )


def test_asp_and_ejs_use_percent_delimiters():
    """<% %> regions pass through for both the asp and ejs mimetypes."""
    # CATCHES: the two mimetypes share the same delimiter configuration.
    for typ in ("text/asp", "text/x-ejs-template"):
        assert minify_html("<p>  a  </p><%= foo  %>", typ=typ) == b"<p>a</p><%= foo  %>"


@pytest.mark.parametrize(
    "typ",
    [
        "text/x-template",
        "text/x-go-template",
        "text/x-mustache-template",
        "text/x-handlebars-template",
    ],
)
def test_curly_brace_dialects_share_delimiters(typ):
    """All four {{ }} mimetypes use the same template delimiters."""
    # CATCHES: only the HTML between the delimiters is minified.
    assert minify_html("<p>  a  </p>{{ .Name  }}", typ=typ) == b"<p>a</p>{{ .Name  }}"


def test_html_mimetype_has_no_template_delimiters():
    """Plain HTML does not treat {{ }} or <? ?> specially."""
    # CATCHES: {{a}} is plain text so </p> is omitted at EOF, while <? ... ?>
    # parses as a bogus comment that is removed but still keeps the end tag.
    assert minify_html("<p>  {{a}}  </p>", typ="html") == b"<p>{{a}}"
    assert minify_html("<p>  a  </p><?= foo  ?>", typ="html") == b"<p>a</p>"
