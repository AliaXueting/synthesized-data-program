"""Document structure: doctype, html/head/body, optional end tags.

Any doctype becomes <!doctype html>; attr-less html, head and body tags are
omitted unless --html-keep-document-tags; optional end tags are omitted unless
--html-keep-end-tags; empty script and style elements disappear.
"""

import pytest
from conftest import minify_html

DOCTYPES = [
    "<!DOCTYPE html>",
    "<!doctype HTML>",
    '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">',
    '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">',
    "<!doctype\n  html\n>",
]


@pytest.mark.parametrize("doctype", DOCTYPES)
def test_every_doctype_becomes_the_html5_one(doctype):
    """The doctype is rewritten to the fixed string <!doctype html>."""
    # CATCHES: case and the public/system identifiers must all be discarded.
    assert minify_html(doctype) == b"<!doctype html>"


def test_document_tags_are_removed_when_attr_less():
    """html, head and body without attributes disappear entirely."""
    # CATCHES: the output keeps only the real content of the document.
    assert minify_html("<html><head></head><body>x</body></html>") == b"x"


def test_text_directly_inside_select_and_optgroup_is_dropped():
    """Loose text in select/optgroup is skipped, not whitespace-collapsed."""
    # CATCHES: only option/optgroup elements survive inside a select, so both
    # the text before the option and the text after its end tag vanish.
    assert minify_html("<select>  dropped  <option>a</option>more</select>") == (
        b"<select><option>a</select>"
    )
    assert minify_html("<optgroup label=g>  drop  <option>a</option></optgroup>") == (
        b"<optgroup label=g><option>a"
    )
    assert minify_html(
        "<html>\n  <head>\n    <title>T</title>\n  </head>\n  <body>\n    <p>a</p>\n  </body>\n</html>\n"
    ) == b"<title>T</title><p>a"


def test_document_tags_with_attributes_are_kept():
    """An attribute on html, head or body prevents its removal."""
    # CATCHES: only the attr-less forms are considered superfluous.
    assert minify_html('<html lang="mn-Cyrl-MN">') == b"<html lang=mn-Cyrl-MN>"
    assert minify_html('<body id="main"></body>') == b"<body id=main>"
    assert minify_html("abc\n</body>\ndef") == b"abc\ndef"


def test_keep_document_tags_flag():
    """--html-keep-document-tags preserves html, head and body."""
    # CATCHES: the flag must keep the wrappers but still minify their content.
    assert minify_html(
        "<html><head></head><body>x</body></html>", "--html-keep-document-tags"
    ) == b"<html><head></head><body>x</body></html>"
    assert minify_html(
        "<html>\n  <head>\n    <title>T</title>\n  </head>\n  <body>\n    <p>a</p>\n  </body>\n</html>\n",
        "--html-keep-document-tags",
    ) == b"<html><head><title>T</title></head><body><p>a</body></html>"


OPTIONAL_END_TAGS = [
    ("<ul><li>one</li><li>two</li></ul>", b"<ul><li>one<li>two</ul>"),
    (
        "<table><tr><td>a</td><td>b</td></tr></table>",
        b"<table><tr><td>a<td>b</table>",
    ),
    (
        "<table><thead><tr><th>h</th></tr></thead><tbody><tr><td>d</td></tr></tbody></table>",
        b"<table><thead><tr><th>h<tbody><tr><td>d</table>",
    ),
    ("<select><option>a</option><option>b</option></select>", b"<select><option>a<option>b</select>"),
    ("<dl><dt>t</dt><dd>d</dd></dl>", b"<dl><dt>t<dd>d</dl>"),
    ("<p>a</p><p>b</p>", b"<p>a<p>b"),
    ("<div>a</div><div>b</div>", b"<div>a</div><div>b</div>"),
]


@pytest.mark.parametrize(
    "source,expected",
    OPTIONAL_END_TAGS,
    ids=["li", "td", "thead", "option", "dt-dd", "p", "kept-div"],
)
def test_optional_end_tags_are_omitted(source, expected):
    """Optional end tags are dropped while structural ones stay."""
    # CATCHES: exactly which end tags are considered optional by HTML5.
    assert minify_html(source) == expected


def test_keep_end_tags_flag():
    """--html-keep-end-tags keeps every end tag in place."""
    # CATCHES: the flag restores </li>, </td>, </p> and friends.
    assert minify_html("<p></p><p></p>", "--html-keep-end-tags") == b"<p></p><p></p>"
    assert minify_html(
        "<ul><li></li><li></li></ul>", "--html-keep-end-tags"
    ) == b"<ul><li></li><li></li></ul>"
    assert minify_html(
        "<table><tr><td>a</td></tr></table>", "--html-keep-end-tags"
    ) == b"<table><tr><td>a</td></tr></table>"


def test_p_end_tag_omission_depends_on_the_next_tag():
    """</p> is dropped before block tags but kept before keepPTag tags."""
    # CATCHES: the p-end-tag rule looks ahead at the following tag's traits.
    assert minify_html("<p>a</p><div>b</div>") == b"<p>a<div>b</div>"
    assert minify_html("<p>a</p><p>b</p>") == b"<p>a<p>b"
    assert minify_html("<p>a</p><a href=#>x</a>") == b'<p>a</p><a href=#>x</a>'
    assert minify_html("<p>a</p></label>") == b"<p>a</p></label>"
    assert minify_html("<div>\n <p>a</p>\n</div>") == b"<div><p>a</div>"


def test_template_contents_keep_their_end_tags():
    """Inside <template> the optional end tags are not omitted."""
    # CATCHES: inTemplate disables the end-tag omission for the subtree.
    assert minify_html("<template><li>a</li><div>b</div></template>") == (
        b"<template><li>a</li><div>b</div></template>"
    )
    assert minify_html("<template><li>a</li></template>", "--html-keep-end-tags") == (
        b"<template><li>a</li></template>"
    )


def test_empty_script_and_style_elements_are_removed():
    """<script></script> and <style></style> disappear completely."""
    # CATCHES: the removal happens before the closing tag is written.
    assert minify_html("<script></script>") == b""
    assert minify_html("<style></style>") == b""
    assert minify_html("a<style></style>b") == b"ab"
    assert minify_html("<style>a{color:red}</style><style></style>") == b"<style>a{color:red}</style>"


def test_script_with_attributes_is_not_removed():
    """An empty script that carries attributes is kept."""
    # CATCHES: the removal only applies to the attribute-less form.
    assert minify_html('<script src="a.js" charset="utf-8"></script>') == (
        b"<script src=a.js></script>"
    )


def test_colgroup_is_removed():
    """An attr-less colgroup is dropped like the document tags."""
    # CATCHES: colgroup is in the superfluous-tag list even with the flag off.
    assert minify_html("<table><colgroup></colgroup><tr><td>a</td></tr></table>") == (
        b"<table><tr><td>a</table>"
    )


def test_self_closing_tags_lose_their_solidus():
    """A trailing /> in HTML is normalised to a plain >."""
    # CATCHES: the void-element syntax is HTML, not XHTML.
    assert minify_html("<br/>") == b"<br>"
    assert minify_html('<img src="a.png" alt="x"/>') == b'<img src=a.png alt=x>'
    assert minify_html('<meta charset="utf-8" />') == b"<meta charset=utf-8>"


def test_end_tag_attributes_are_stripped_to_the_name():
    """A verbose end tag is rewritten to </name>."""
    # CATCHES: anything after the tag name in an end tag is discarded.
    assert minify_html("</span >") == b"</span>"
    assert minify_html("<p></p >") == b"<p>"


def test_tag_and_attribute_names_are_lower_cased():
    """Tag names and attribute names are rewritten in lower case."""
    # CATCHES: HTML is case-insensitive, so <DIV TITLE=...> becomes <div title=...>.
    assert minify_html('<DIV TITLE="blah">boo</DIV>') == b'<div title=blah>boo</div>'
    assert minify_html('<span Selected="selected"></span>') == b"<span selected></span>"
    assert minify_html('<td COLSPAN="1">x') == b"<td colspan=1>x"


def test_noscript_still_minifies_its_contents():
    """noscript content is minified as HTML, including tag removal."""
    # CATCHES: a nested <html> inside noscript is still dropped.
    assert minify_html('<noscript><html><img id="x"></noscript>') == (
        b"<noscript><img id=x></noscript>"
    )
    assert minify_html("<noscript><p>  x  </p></noscript>") == b"<noscript><p>x</p></noscript>"


def test_malformed_fragments_are_passed_through():
    """Unterminated tags at EOF are echoed rather than rejected."""
    # CATCHES: the lexer is lenient; truncated markup produces output, not an
    # error, and the partial tag is still normalised.
    assert minify_html("</b") == b"</b"
    assert minify_html("<title></") == b"<title></"
    assert minify_html("<meta e t n content=ful><a b") == b"<meta e t n content=ful><a b>"


def test_unterminated_svg_and_script_fragments():
    """Truncated raw tags still produce the closing part of the element."""
    # CATCHES: the SVG and script lexers recover differently at EOF.
    assert minify_html("<svg <") == b'<svg <=""'
    assert minify_html('<svg "') == b'<svg "=""'
    assert minify_html("<svg></") == b"<svg/>"
    assert minify_html("<script><!--<") == b"<script>"


def test_optgroup_end_tag_omission_looks_past_text():
    """</optgroup> is omitted only when no <option> follows the loose text."""
    # CATCHES: the optgroup end-tag lookahead skips text tokens (the loose
    # text inside the select is dropped either way), so the end tag survives
    # before a next <option> but is omitted at the end of the select; with
    # --html-keep-end-tags the end tag stays while the text is still gone.
    assert minify_html("<select><optgroup><option>a</optgroup>hello<option>b</select>") == (
        b"<select><optgroup><option>a</optgroup><option>b</select>"
    )
    assert minify_html("<select><optgroup><option>a</optgroup>hello</select>") == (
        b"<select><optgroup><option>a</select>"
    )
    assert minify_html(
        "<select><optgroup><option>a</optgroup>hello</select>", "--html-keep-end-tags"
    ) == b"<select><optgroup><option>a</optgroup></select>"
