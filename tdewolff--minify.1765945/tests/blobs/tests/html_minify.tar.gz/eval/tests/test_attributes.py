"""Attribute minification: quoting, booleans, defaults and special tags.

Quotes are omitted or switched to whichever quote character needs fewer
escapes; boolean attributes lose =value; default attribute values are removed
unless --html-keep-default-attrvals; empty class/id/name attributes are
dropped; meta tags are rewritten; character references use their shortest form.
"""

import pytest
from conftest import minify_html


@pytest.mark.parametrize(
    "source,expected",
    [
        ('<p a="x" b=\'y\' c=z></p>', b"<p a=x b=y c=z>"),
        ("<span attr='test&apos;test'></span>", b'<span attr="test\'test"></span>'),
        ('<span attr="test&quot;test"></span>', b"<span attr='test\"test'></span>"),
        ("<span attr='test\"\"&apos;&amp;test'></span>", b"<span attr='test\"\"&#39;&amp;test'></span>"),
        ("<span attr=\"test/\"></span>", b"<span attr=test/></span>"),
        ("<span attr=\"a'b\"></span>", b"<span attr=\"a'b\"></span>"),
        ("<span attr='a\"b'></span>", b"<span attr='a\"b'></span>"),
        ("<span attr=\"a'b'c\"></span>", b"<span attr=\"a'b'c\"></span>"),
        ("<span attr='a\"b\"c'></span>", b"<span attr='a\"b\"c'></span>"),
        ("<span attr=\"\"></span>", b"<span attr></span>"),
        ("<img alt=a'b=\"\"></img>", b'<img alt=\'a&#39;b=""\'></img>'),
    ],
    ids=[
        "plain",
        "single-inside",
        "double-inside",
        "both",
        "trailing-slash",
        "apos",
        "quote",
        "apos-twice",
        "quote-twice",
        "empty",
        "go-fuzz",
    ],
)
def test_attribute_quoting(source, expected):
    """Quotes are dropped, or switched to the character needing no escapes."""
    # CATCHES: the quote character is chosen by counting escapes in the value.
    assert minify_html(source) == expected


def test_keep_quotes_flag():
    """--html-keep-quotes keeps the original quoting of each attribute."""
    # CATCHES: unquoted values stay unquoted, and a value that would need
    # escaping inside the original quote character still switches quotes.
    assert minify_html('<p attr="test">', "--html-keep-quotes") == b'<p attr="test">'
    assert minify_html("<p attr='test'>", "--html-keep-quotes") == b"<p attr='test'>"
    assert minify_html("<p attr=test>", "--html-keep-quotes") == b"<p attr=test>"
    assert minify_html(
        '<p attr="test&quot;test">', "--html-keep-quotes"
    ) == b"<p attr='test\"test'>"
    assert minify_html(
        "<meta name='viewport' content='width=device-width, initial-scale=1'>",
        "--html-keep-quotes",
    ) == b"<meta name='viewport' content='width=device-width,initial-scale=1'>"


@pytest.mark.parametrize(
    "source,expected",
    [
        ('<input disabled="disabled" checked required=required>', b"<input disabled checked required>"),
        ('<input type="checkbox" checked="checked" disabled>', b"<input type=checkbox checked disabled>"),
        ("<select multiple><option selected>a</select>", b"<select multiple><option selected>a</select>"),
        ('<span Selected="selected"></span>', b"<span selected></span>"),
    ],
    ids=["input", "checkbox", "select", "case"],
)
def test_boolean_attributes_lose_their_value(source, expected):
    """Boolean attributes are written without =value."""
    # CATCHES: the value is dropped even when it repeats the attribute name.
    assert minify_html(source) == expected


DEFAULT_ATTRVAL_CASES = [
    ('<form method="get">', b"<form>"),
    ('<input type="text">', b"<input>"),
    ('<button type="submit">go</button>', b"<button>go</button>"),
    ('<style type="text/css">a{b:c}</style>', b"<style>a{b:c}</style>"),
    ('<script type="text/javascript">var a=1</script>', b"<script>var a=1</script>"),
    ('<link rel="stylesheet" type="text/css" href="a.css">', b'<link rel=stylesheet href=a.css>'),
    ('<form enctype="application/x-www-form-urlencoded" action="a">', b"<form action=a>"),
    ('<a href="x" shape="rect">', b"<a href=x>"),
    ('<style media="all">x</style>', b"<style>x</style>"),
]


@pytest.mark.parametrize(
    "source,expected",
    DEFAULT_ATTRVAL_CASES,
    ids=["method", "input-type", "button-type", "style-type", "script-type",
         "link-type", "enctype", "shape", "media"],
)
def test_default_attribute_values_are_removed(source, expected):
    """Known default values are omitted from the output."""
    # CATCHES: the removal is per (tag, attribute) pair, not global.
    assert minify_html(source) == expected


KEEP_DEFAULT_ATTRVAL_CASES = [
    ('<form method="get">', b"<form method=get>"),
    ('<input type="text">', b"<input type=text>"),
    ('<button type="submit">go</button>', b"<button type=submit>go</button>"),
    ('<style type="text/css">a{b:c}</style>', b"<style type=text/css>a{b:c}</style>"),
    ('<script type="text/javascript">var a=1</script>', b"<script type=text/javascript>var a=1</script>"),
    ('<link rel="stylesheet" type="text/css" href="a.css">', b'<link rel=stylesheet type=text/css href=a.css>'),
    ('<form enctype="application/x-www-form-urlencoded" action="a">', b"<form enctype=application/x-www-form-urlencoded action=a>"),
    ('<a href="x" shape="rect">', b"<a href=x shape=rect>"),
    ('<style media="all">x</style>', b"<style media=all>x</style>"),
]


@pytest.mark.parametrize(
    "source,expected",
    KEEP_DEFAULT_ATTRVAL_CASES,
    ids=["method", "input-type", "button-type", "style-type", "script-type",
         "link-type", "enctype", "shape", "media"],
)
def test_keep_default_attrvals_flag(source, expected):
    """--html-keep-default-attrvals preserves the default values."""
    # CATCHES: every default listed above survives the flag and is merely
    # unquoted where that is legal.
    assert minify_html(source, "--html-keep-default-attrvals") == expected


def test_empty_class_id_name_dir_are_dropped():
    """Empty class, id, name and dir attributes disappear."""
    # CATCHES: only these attributes are dropped when empty, not all of them.
    assert minify_html('<p class="" id="" name="" dir=""></p>') == b"<p>"
    assert minify_html('<a id="" value="">y</a>') == b"<a value>y</a>"
    assert minify_html('<input title=""><input lang="">') == b"<input title><input lang>"


def test_colspan_and_rowspan_of_one_are_kept():
    """colspan=1 and rowspan=1 are not stripped despite being defaults."""
    # CATCHES: the reference does not recognise these attribute names, so the
    # documented default-removal does not apply to them.
    assert minify_html('<td colspan="1" rowspan="1">x') == b"<td colspan=1 rowspan=1>x"


def test_rdfa_attributes_always_stay_double_quoted():
    """RDFa attributes keep double quotes even when unquoted would be legal."""
    # CATCHES: the isXML list forces double quotes regardless of the value.
    assert minify_html('<meta property="rdfa" content="data">') == (
        b'<meta property="rdfa" content="data">'
    )
    assert minify_html(
        '<div vocab="http://schema.org/" typeof="Person" property="name" '
        'resource="#me" prefix="og: http://ogp.me/ns#" about="#x" rev="x" '
        'datatype="string" inlist>Fred</div>'
    ) == (
        b'<div vocab="http://schema.org/" typeof="Person" property="name" '
        b'resource="#me" prefix="og: http://ogp.me/ns#" about="#x" rev="x" '
        b'datatype="string" inlist>Fred</div>'
    )


def test_meta_content_type_becomes_charset():
    """The content-type meta is rewritten to a plain charset meta."""
    # CATCHES: the http-equiv and content attributes are replaced by a single
    # charset attribute, whatever the original case and spacing.
    assert minify_html('<meta http-equiv="content-type" content="text/html; charset=utf-8">') == (
        b"<meta charset=utf-8>"
    )
    assert minify_html('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />') == (
        b"<meta charset=utf-8>"
    )
    assert minify_html(
        '<meta http-equiv=" content-type " content=" text/html;  charset=utf-8 ">'
    ) == b"<meta charset=utf-8>"


def test_other_meta_http_equiv_values_are_only_minified():
    """A non-content-type http-equiv meta keeps both attributes."""
    # CATCHES: the charset rewrite only happens for content-type.
    assert minify_html(
        '<meta http-equiv="Content-Security-Policy" content="default-src \'self\';">'
    ) == b"<meta http-equiv=Content-Security-Policy content=\"default-src 'self';\">"


def test_meta_content_type_with_existing_charset_is_left_alone():
    """An explicit charset attribute wins over the http-equiv rewrite."""
    # CATCHES: the rewrite is skipped when charset is already present, and the
    # content value then keeps its original spacing.
    assert minify_html(
        '<meta http-equiv="content-type" content="text/html; charset=utf-8" charset="utf-8">'
    ) == b'<meta http-equiv=content-type content="text/html; charset=utf-8" charset=utf-8>'


def test_meta_keywords_drop_the_space_after_commas():
    """keywords content values lose the space after each comma."""
    # CATCHES: only ', ' is replaced, so other spacing is untouched.
    assert minify_html('<meta name="keywords" content="a, b, c">') == (
        b'<meta name=keywords content="a,b,c">'
    )
    assert minify_html('<meta name="keywords" content="A, B">') == (
        b'<meta name=keywords content="A,B">'
    )


def test_meta_viewport_is_normalised():
    """viewport content loses its spaces and shortens its numbers."""
    # CATCHES: numbers after '=' are re-rendered in their shortest form, and
    # the '=' inside the value keeps the whole value double-quoted.
    assert minify_html(
        '<meta name=viewport content="width=0.1, initial-scale=1.0 , maximum-scale=1000">'
    ) == b'<meta name=viewport content="width=.1,initial-scale=1,maximum-scale=1e3">'
    assert minify_html(
        '<meta name="viewport" content="width = 1000, initial-scale = 1.00, minimum-scale=1">'
    ) == b'<meta name=viewport content="width=1e3,initial-scale=1,minimum-scale=1">'


def test_character_references_are_rewritten_to_the_shortest_form():
    """Entities in text are replaced by their shortest encoding."""
    # CATCHES: &lt; stays escaped while &gt; and &quot; become literal.
    assert minify_html("<p>&amp; &lt; &gt; &quot; &#65; &copy; &nbsp;</p>") == (
        b"<p>& &lt; > \" A &copy; &nbsp;"
    )
    assert minify_html("<code>&quot;&rsquor;</code>") == b"<code>\"&#8217;</code>"
    assert minify_html("<small>&#160;</small>") == b"<small>&#160;</small>"
    assert minify_html("<p>a&nbsp;</p>") == b"<p>a&nbsp;"


def test_character_references_in_attribute_values():
    """Entities in attribute values are decoded before re-quoting."""
    # CATCHES: the decoded value decides the quote character, and < stays raw
    # inside an attribute.
    assert minify_html('<span name="&lt;&apos;">a</span>') == b'<span name="<\'">a</span>'
    assert minify_html('<p title="a&amp;b">') == b"<p title=a&amp;b>"
    assert minify_html('<p data-x="&lt;script&gt;">') == b"<p data-x=\"<script>\">"


def test_input_radio_and_value_special_cases():
    """input type=radio keeps its value unless it is exactly 'on'."""
    # CATCHES: the empty-value removal differs between radio and other inputs.
    assert minify_html('<input type="radio" value="">') == b"<input type=radio value>"
    assert minify_html('<input type="radio" value="on">') == b"<input type=radio>"
    assert minify_html('<input type="text" value="">') == b"<input>"


def test_anchor_id_and_name_are_deduplicated():
    """<a> drops name when it equals id."""
    # CATCHES: the duplicate name attribute disappears in either order.
    assert minify_html('<a id="abc" name="abc">y</a>') == b"<a id=abc>y</a>"
    assert minify_html('<a name="abc" id="abc">y</a>') == b"<a id=abc>y</a>"


def test_script_charset_is_dropped_when_src_is_present():
    """charset on <script> is removed once src is given."""
    # CATCHES: the removal only happens for the src+charset combination.
    assert minify_html('<script charset="x" src="y"></script>') == b"<script src=y></script>"
    assert minify_html('<script src=y charset=x></script>') == b"<script src=y></script>"
    assert minify_html('<script charset="x">var a=1</script>') == b"<script charset=x>var a=1</script>"


def test_mediatype_attributes_are_minified():
    """accept, enctype and type values are reformatted as mediatypes."""
    # CATCHES: whitespace around the separators of a mediatype list is removed.
    assert minify_html('<input accept="image/png, image/jpeg">') == (
        b"<input accept=image/png,image/jpeg>"
    )
    assert minify_html('<meta http-equiv="content-type" content="text/plain, text/html">') == (
        b'<meta http-equiv=content-type content="text/plain,text/html">'
    )
    assert minify_html('<source type=\'video/mp4; codecs="av01.0.05M.08"\'>') == (
        b"<source type='video/mp4;codecs=\"av01.0.05M.08\"'>"
    )


def test_attribute_values_that_are_removed_entirely():
    """Empty style and on* handlers make the attribute vanish."""
    # CATCHES: minifying to nothing removes the attribute, not just its value.
    assert minify_html("<span style=>") == b"<span>"
    assert minify_html("<button onclick=>") == b"<button>"
    assert minify_html('<p style=" ">x</p>') == b"<p>x"


def test_attribute_without_a_value_keeps_no_equals_sign():
    """A bare attribute name never grows an equals sign."""
    # CATCHES: valueless attributes from the input stay valueless.
    assert minify_html("<p hidden data-x>x") == b"<p hidden data-x>x"


def test_attributes_across_newlines_and_tabs():
    """Attribute lists may be spread over several lines."""
    # CATCHES: the newlines inside a tag are removed with the other spaces.
    assert minify_html('<p title\n\n\t  =\n     "bar">foo</p>') == b"<p title=bar>foo"
    assert minify_html("<span ></span>") == b"<span></span>"
    assert minify_html('<input maxlength="     5 ">') == b"<input maxlength=5>"
