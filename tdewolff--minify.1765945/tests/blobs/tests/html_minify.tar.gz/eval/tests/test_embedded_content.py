"""Embedded content: CSS, JavaScript, JSON, SVG and iframes.

style attributes and <style> contents are minified as inline CSS and dropped
when they become empty; on* handlers are minified as inline JavaScript with a
leading javascript: stripped; <script> contents are minified as JavaScript
(with </script> escaping) or as JSON for the JSON mediatypes.
"""

import pytest
from conftest import minify_html


def test_style_contents_are_minified_as_css():
    """<style> bodies run through the CSS minifier."""
    # CATCHES: the CSS result replaces the original body inside the element.
    assert minify_html("<style>body {  color: red;  margin : 0px; }</style>") == (
        b"<style>body{color:red;margin:0}</style>"
    )
    assert minify_html("<style>a{color:red}</style>") == b"<style>a{color:red}</style>"
    assert minify_html("<style><!--\ncss\n--></style>") == b"<style><!--css --></style>"


def test_style_attribute_is_minified_as_inline_css():
    """A style attribute value is minified with inline CSS rules."""
    # CATCHES: the trailing semicolon is dropped and the value unquoted.
    assert minify_html('<p style="color: red; margin: 0px;">x</p>') == (
        b"<p style=color:red;margin:0>x"
    )
    assert minify_html(
        '<div style="font-family: Arial, &#39;sans-serif&#39;; font-size: 22px;">'
    ) == b"<div style=font-family:Arial,sans-serif;font-size:22px>"


def test_style_amp_boilerplate_is_not_css_minified():
    """<style amp-boilerplate> content skips the CSS minifier."""
    # CATCHES: the CSS is left structurally intact, but whitespace runs are
    # still collapsed by the ordinary text rules.
    assert minify_html(
        "<style amp-boilerplate>body{-webkit-animation:-amp-start 8s    "
        "steps(1,end) 0s 1 normal both;}</style>"
    ) == (
        b"<style amp-boilerplate>body{-webkit-animation:-amp-start 8s "
        b"steps(1,end) 0s 1 normal both;}</style>"
    )


def test_script_contents_are_minified_as_javascript():
    """<script> bodies run through the JavaScript minifier."""
    # CATCHES: whitespace, the trailing semicolon and the var spacing change.
    assert minify_html("<script>var a = 1; console.log( a );</script>") == (
        b"<script>var a=1;console.log(a)</script>"
    )
    assert minify_html("<script>script</script>") == b"<script>script</script>"


def test_script_closing_tag_is_escaped():
    """A literal </script> inside the code is escaped as <\\/script>."""
    # CATCHES: the escape applies to the minified output, in either case.
    assert minify_html('<script>var s = "</scr" + "ipt>";</script>') == (
        b'<script>var s="<\\/script>"</script>'
    )
    assert minify_html('<script>var a="<\\/SCRIPT>"</script>') == (
        b'<script>var a="<\\/SCRIPT>"</script>'
    )
    assert minify_html('<script>x< /SCRIPT>/</script>') == b"<script>x< /SCRIPT>/</script>"


@pytest.mark.parametrize(
    "mediatype",
    ["application/json", "importmap", "speculationrules", "application/ld+json"],
)
def test_script_json_mimetypes_are_minified_as_json(mediatype):
    """JSON script types are minified with the JSON minifier."""
    # CATCHES: the type attribute survives while its body is reformatted.
    assert minify_html(
        '<script type="%s">{"a": 1, "b": [1,2]}</script>' % mediatype
    ) == ('<script type=%s>{"a":1,"b":[1,2]}</script>' % mediatype).encode()


def test_script_javascript_mimetypes_are_removed_with_the_body_minified():
    """JavaScript mimetypes on script are defaults and disappear."""
    # CATCHES: the content is still minified as JavaScript after the type
    # attribute is dropped.
    assert minify_html('<script type="text/javascript">var a=1</script>') == (
        b"<script>var a=1</script>"
    )
    assert minify_html('<script type="application/ecmascript" src="a"></script>') == (
        b'<script type=application/ecmascript src=a></script>'
    )
    assert minify_html('<script type="module">var  a  =  1</script>') == (
        b"<script type=module>var a=1</script>"
    )


def test_event_handlers_are_minified_as_inline_javascript():
    """on* attributes are minified, with a leading javascript: stripped."""
    # CATCHES: the scheme prefix is removed before the JS minifier runs.
    assert minify_html('<p onclick="javascript:alert(1);">x</p>') == (
        b"<p onclick=alert(1)>x"
    )
    assert minify_html('<p onclick="  javascript:lala  ">', ) == b"<p onclick=lala>"
    assert minify_html('<span onload="javascript:x;"></span>') == b"<span onload=x></span>"
    assert minify_html('<p onclick=" JavaScript: x">x</p>') == b"<p onclick=x>x"


def test_event_handler_minification_can_rewrite_the_code():
    """The inline JS minifier may restructure the handler expression."""
    # CATCHES: 'return false' becomes '!1' and sequences become comma
    # expressions, so the handler is not just whitespace-trimmed.
    assert minify_html('<button onclick="return false">') == b"<button onclick=return!1>"
    assert minify_html('<button onclick="  doIt( 1 ) ;  return false">x</button>') == (
        b'<button onclick="return doIt(1),!1">x</button>'
    )


def test_inline_svg_is_minified_as_svg():
    """An inline <svg> element is handed to the SVG minifier."""
    # CATCHES: the default xmlns is dropped and numbers and colours shorten.
    assert minify_html(
        '<svg width="100" height="50" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="1.0" y="2" width="10" height="10" fill="#ff0000"/></svg>'
    ) == b'<svg width="100" height="50"><rect x="1" y="2" width="10" height="10" fill="red"/></svg>'
    assert minify_html("<svg><!-- c --><rect width=\"10\"/></svg>") == (
        b'<svg><rect width="10"/></svg>'
    )
    assert minify_html('<svg><style>/*c*/a{b:c}</style></svg>') == (
        b"<svg><style>a{b:c}</style></svg>"
    )


def test_iframe_contents_are_minified_as_html():
    """<iframe> bodies are minified as nested HTML documents."""
    # CATCHES: the nested html/body tags are removed inside the iframe too.
    assert minify_html("<iframe><html> <p> x </p> </html></iframe>") == (
        b"<iframe><p>x</iframe>"
    )
    assert minify_html("<iframe><p>  hello  </p></iframe>") == b"<iframe><p>hello</iframe>"


def test_mathml_content_is_passed_through():
    """Inline MathML keeps its text (the MathML minifier is not registered)."""
    # CATCHES: the content is written back with only the surrounding spaces
    # removed.
    assert minify_html("<math> &int;_a_^b^{f(x)<over>1+x} dx </math>") == (
        b"<math>&int;_a_^b^{f(x)<over>1+x} dx</math>"
    )


def test_raw_tag_contents_are_not_entity_decoded():
    """script and style bodies keep their entities and ampersands."""
    # CATCHES: raw text is not run through the entity replacement.
    assert minify_html("<style>&</style>") == b"<style>&</style>"
    assert minify_html("<script>a&&b</script>") == b"<script>a&&b</script>"


def test_title_and_textarea_are_raw_text():
    """title content is collapsed like text, textarea is not."""
    # CATCHES: title is a raw tag but still gets whitespace-normalised here.
    assert minify_html("<title>  t  </title>") == b"<title>t</title>"
    assert minify_html("<textarea>  a  b  </textarea>") == b"<textarea>  a  b  </textarea>"


def test_style_attribute_becoming_empty_is_removed():
    """A style attribute that minifies to nothing disappears."""
    # CATCHES: the attribute is dropped rather than written with an empty value.
    assert minify_html('<p style=" ">x</p>') == b"<p>x"
    assert minify_html("<span style=>") == b"<span>"
