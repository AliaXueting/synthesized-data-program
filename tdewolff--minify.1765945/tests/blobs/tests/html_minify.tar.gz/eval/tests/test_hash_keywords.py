"""Keyword-table behaviours: which tag and attribute names get special handling.

The minifier resolves every lower-cased tag and attribute name through a
generated perfect-hash keyword table (html/hash.go) and applies per-keyword
trait bitmasks (html/table.go).  These tests pin the exact membership of
those keyword tables as observed through the CLI: which attributes are
boolean and lose =value, which have their value's whitespace trimmed (and
the three mediatype keywords that collapse further), which are treated as
URLs, which RDFa keywords keep their quotes, which tags are block tags that
trim surrounding whitespace (against the phrasing tags that keep it,
including the removed and experimental tags), and before which tags a </p>
end tag may be omitted.  Recognition is case-insensitive.  Every expectation
below was recorded by running the reference binary through its command line
interface only.
"""

import pytest

from conftest import minify_html

# The 25 booleanAttr keywords from the attribute trait table.
BOOLEAN_ATTRS = [
    "allowfullscreen",
    "async",
    "autofocus",
    "autoplay",
    "checked",
    "controls",
    "default",
    "defer",
    "disabled",
    "formnovalidate",
    "inert",
    "ismap",
    "itemscope",
    "loop",
    "multiple",
    "muted",
    "nomodule",
    "novalidate",
    "open",
    "playsinline",
    "readonly",
    "required",
    "reversed",
    "selected",
    "shadowrootdelegatesfocus",
]

# The 80 trimAttr keywords whose value is only whitespace-trimmed.
TRIM_ATTRS = [
    "accept-charset",
    "accesskey",
    "allow",
    "as",
    "autocapitalize",
    "autocomplete",
    "blocking",
    "capture",
    "charset",
    "class",
    "color",
    "cols",
    "colspan",
    "contenteditable",
    "coords",
    "crossorigin",
    "datetime",
    "decoding",
    "dir",
    "draggable",
    "enterkeyhint",
    "fetchpriority",
    "for",
    "form",
    "formmethod",
    "formtarget",
    "headers",
    "height",
    "hidden",
    "high",
    "hreflang",
    "http-equiv",
    "imagesizes",
    "imagesrcset",
    "inputmode",
    "is",
    "itemprop",
    "itemref",
    "itemtype",
    "kind",
    "lang",
    "list",
    "loading",
    "low",
    "max",
    "maxlength",
    "media",
    "method",
    "min",
    "minlength",
    "optimum",
    "pattern",
    "ping",
    "popover",
    "popovertarget",
    "popovertargetaction",
    "preload",
    "referrerpolicy",
    "rel",
    "rows",
    "rowspan",
    "sandbox",
    "scope",
    "shadowrootmode",
    "shape",
    "size",
    "sizes",
    "span",
    "spellcheck",
    "srclang",
    "srcset",
    "start",
    "step",
    "tabindex",
    "target",
    "translate",
    "type",
    "usemap",
    "width",
    "wrap",
]

# The 10 urlAttr keywords whose value is minified as a URL.
URL_ATTRS = [
    "action",
    "cite",
    "data",
    "formaction",
    "href",
    "itemid",
    "poster",
    "profile",
    "src",
    "xmlns",
]

# The 10 RDFa keywords that never drop their quotes (html.go's isXML list).
RDFA_ATTRS = [
    "vocab",
    "typeof",
    "property",
    "resource",
    "prefix",
    "content",
    "about",
    "rev",
    "datatype",
    "inlist",
]

# The blockTag keywords: whitespace next to them is removed on both sides.
# html, head, body and colgroup are absent (attr-less they are removed
# outright), option is covered separately (it drops following text), and
# script is absent because it is not a block tag.
BLOCK_TAGS = [
    "address",
    "article",
    "aside",
    "blockquote",
    "br",
    "caption",
    "col",
    "dd",
    "details",
    "div",
    "dl",
    "dt",
    "fieldset",
    "figcaption",
    "figure",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "header",
    "hgroup",
    "hr",
    "legend",
    "li",
    "main",
    "menu",
    "nav",
    "noscript",
    "ol",
    "p",
    "pre",
    "section",
    "summary",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "title",
    "tr",
    "ul",
    "style",
    "center",
    "dir",
    "marquee",
    "noembed",
    "noframes",
    "xmp",
]

# The phrasing keywords (normalTag and objectTag traits): the spaces around
# them survive.  This includes every removed tag that is NOT a block tag and
# the experimental portal/rb/rtc.  rawTag keywords (script, textarea, iframe,
# svg, math) are covered by the embedded-content tests instead.
PHRASING_TAGS = [
    "abbr",
    "area",
    "b",
    "bdi",
    "bdo",
    "bb",
    "button",
    "canvas",
    "cite",
    "code",
    "datalist",
    "del",
    "dfn",
    "dialog",
    "em",
    "embed",
    "i",
    "img",
    "input",
    "ins",
    "kbd",
    "label",
    "link",
    "map",
    "mark",
    "meter",
    "meta",
    "object",
    "output",
    "param",
    "picture",
    "progress",
    "q",
    "rt",
    "samp",
    "slot",
    "small",
    "source",
    "span",
    "strong",
    "sub",
    "sup",
    "time",
    "u",
    "var",
    "video",
    "wbr",
    "track",
    "data",
    "ruby",
    "s",
    "acronym",
    "applet",
    "basefont",
    "big",
    "font",
    "frame",
    "frameset",
    "image",
    "menuitem",
    "nobr",
    "plaintext",
    "strike",
    "tt",
    "portal",
    "rb",
    "rtc",
]

# Tags with the omitPTag trait: a preceding </p> end tag is omitted.
OMIT_P_TAGS = [
    "address",
    "article",
    "aside",
    "blockquote",
    "details",
    "div",
    "dl",
    "fieldset",
    "figcaption",
    "figure",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "header",
    "hr",
    "main",
    "menu",
    "nav",
    "ol",
    "p",
    "pre",
    "section",
    "table",
    "ul",
]

# Tags without the omitPTag trait: a preceding </p> end tag survives, even
# for block tags like br, li, td, title or the removed center/dir/marquee.
KEEP_P_TAGS = [
    "br",
    "caption",
    "col",
    "dd",
    "dt",
    "hgroup",
    "legend",
    "li",
    "noscript",
    "summary",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "title",
    "tr",
    "center",
    "dir",
    "marquee",
    "noembed",
    "noframes",
    "xmp",
    "span",
    "b",
    "i",
    "button",
    "img",
    "object",
]


@pytest.mark.parametrize("attr", BOOLEAN_ATTRS)
def test_boolean_attribute_keywords_lose_their_value(attr):
    """Every booleanAttr keyword drops the =value part entirely."""
    # CATCHES: the exact 25-keyword membership of the boolean attribute
    # table; a re-implementation that misses one keyword, or wrongly
    # booleanises e.g. hidden (only trimAttr), breaks this.
    assert minify_html('<div %s="yes">x</div>' % attr) == (
        "<div %s>x</div>" % attr
    ).encode()


def test_non_boolean_attribute_keywords_keep_their_value():
    """Attributes outside the boolean table keep =value."""
    # CATCHES: id, title, data-* and hidden all keep their value; hidden is
    # on the trimAttr list but is NOT a boolean keyword.
    assert minify_html('<div id="yes">x</div>') == b"<div id=yes>x</div>"
    assert minify_html('<div title="yes">x</div>') == b"<div title=yes>x</div>"
    assert minify_html('<div data-flag="yes">x</div>') == b"<div data-flag=yes>x</div>"
    assert minify_html('<div hidden="yes">x</div>') == b"<div hidden=yes>x</div>"


@pytest.mark.parametrize("attr", TRIM_ATTRS)
def test_trim_attribute_keywords_trim_their_value(attr):
    """trimAttr keywords collapse and trim the value's whitespace."""
    # CATCHES: the exact trimAttr membership; a run of spaces, newlines and
    # tabs inside the value becomes a single newline, for all 80 keywords.
    assert minify_html("<div %s=' a\n  b '>x</div>" % attr) == (
        "<div %s='a\nb'>x</div>" % attr
    ).encode()


def test_mediatype_trim_keywords_collapse_their_whole_value():
    """The mediatype trimAttr keywords are minified as mimetypes."""
    # CATCHES: accept, enctype and formenctype go through the mediatype
    # minifier, so ' a ;  b ' collapses to 'ab' instead of 'a;b'.
    assert minify_html("<div accept=' a\n  b '>x</div>") == b"<div accept=ab>x</div>"
    assert minify_html("<div enctype=' a\n  b '>x</div>") == b"<div enctype=ab>x</div>"
    assert minify_html("<div formenctype=' a\n  b '>x</div>") == (
        b"<div formenctype=ab>x</div>"
    )


def test_id_attribute_value_is_not_trimmed():
    """The id keyword is on none of the special attribute lists."""
    # CATCHES: id is neither trimAttr nor urlAttr, so its value keeps every
    # space and newline and keeps its original single quotes.
    assert minify_html("<div id=' a\n  b '>x</div>") == b"<div id=' a\n  b '>x</div>"


@pytest.mark.parametrize("attr", URL_ATTRS)
def test_url_attribute_keywords_trim_their_value(attr):
    """urlAttr keywords have their value whitespace-trimmed as URLs."""
    # CATCHES: the exact urlAttr membership beyond href/src: action, cite,
    # data, formaction, itemid, poster, profile and xmlns all trim.
    assert minify_html("<div %s=' a '>x</div>" % attr) == (
        "<div %s=a>x</div>" % attr
    ).encode()


@pytest.mark.parametrize("attr", RDFA_ATTRS)
def test_rdfa_attribute_keywords_keep_their_quotes(attr):
    """RDFa keywords never have their quotes removed."""
    # CATCHES: the ten isXML keywords keep double quotes for a value that
    # every other attribute (title, id, class) writes unquoted.
    assert minify_html('<div %s="ab">x</div>' % attr) == (
        '<div %s="ab">x</div>' % attr
    ).encode()
    assert minify_html('<div title="ab">x</div>') == b"<div title=ab>x</div>"
    assert minify_html('<div id="ab">x</div>') == b"<div id=ab>x</div>"
    assert minify_html('<div class="ab">x</div>') == b"<div class=ab>x</div>"


def test_rdfa_attribute_keywords_keep_their_original_quoting():
    """RDFa keywords keep whichever quoting the source used."""
    # CATCHES: quotes are kept, not normalised: single stays single,
    # unquoted stays unquoted, and only switching to the cheaper quote
    # character is still allowed.
    assert minify_html("<div property='v'>x</div>") == b"<div property='v'>x</div>"
    assert minify_html("<div property=v>x</div>") == b"<div property=v>x</div>"
    assert minify_html('<div property="a&quot;b">x</div>') == b"<div property='a\"b'>x</div>"


@pytest.mark.parametrize("tag", BLOCK_TAGS)
def test_block_tag_keywords_trim_surrounding_whitespace(tag):
    """blockTag keywords remove the spaces on both sides of the element."""
    # CATCHES: the exact blockTag membership, including style and the
    # removed tags center/dir/marquee/noembed/noframes/xmp; --html-keep-end-
    # tags isolates the whitespace trait from end-tag omission.
    assert minify_html("a <%s>x</%s> b" % (tag, tag), "--html-keep-end-tags") == (
        "a<%s>x</%s>b" % (tag, tag)
    ).encode()


@pytest.mark.parametrize("tag", PHRASING_TAGS)
def test_phrasing_tag_keywords_keep_surrounding_whitespace(tag):
    """normalTag and objectTag keywords keep the spaces around them."""
    # CATCHES: no phrasing keyword trims surrounding whitespace — including
    # all the removed tags (acronym, applet, basefont, big, font, frame,
    # frameset, image, menuitem, nobr, plaintext, strike, tt) which are NOT
    # block tags, unlike center/dir/marquee/noembed/noframes/xmp.
    source = "a <%s>x</%s> b" % (tag, tag)
    assert minify_html(source, "--html-keep-end-tags") == source.encode()


def test_keyword_recognition_is_case_insensitive():
    """Tag and attribute keywords match regardless of letter case."""
    # CATCHES: <DIV CLASS=...> still hits the trimAttr keyword, <ADDRESS>
    # still trims as a block tag, <DeFeR> is still boolean, an upper-case
    # href is still a URL attribute, and an unknown tag keeps its spaces.
    assert minify_html("<DIV CLASS=' a\n  b '>x</DIV>") == b"<div class='a\nb'>x</div>"
    assert minify_html('<INPUT CHECKED="YES">') == b"<input checked>"
    assert minify_html('<div DeFeR="1">x</div>') == b"<div defer>x</div>"
    assert minify_html("a <ADDRESS>x</ADDRESS> b", "--html-keep-end-tags") == (
        b"a<address>x</address>b"
    )
    assert minify_html("<p>a</p><DIV>b") == b"<p>a<div>b"
    assert minify_html("<A HREF=' a '>x</A>") == b"<a href=a>x</a>"
    assert minify_html("a <CUSTOM-TAG>x</CUSTOM-TAG> b", "--html-keep-end-tags") == (
        b"a <custom-tag>x</custom-tag> b"
    )
    assert minify_html("<p>a</p><custom-tag>b") == b"<p>a</p><custom-tag>b"


@pytest.mark.parametrize("tag", OMIT_P_TAGS)
def test_p_end_tag_is_omitted_before_omit_p_keywords(tag):
    """</p> disappears before a keyword with the omitPTag trait."""
    # CATCHES: the exact 29-keyword omitPTag list; only this subset of block
    # tags may swallow a preceding paragraph end tag.
    assert minify_html("<p>a</p><%s>b" % tag) == ("<p>a<%s>b" % tag).encode()


@pytest.mark.parametrize("tag", KEEP_P_TAGS)
def test_p_end_tag_stays_before_other_keywords(tag):
    """</p> survives before block tags without omitPTag and phrasing tags."""
    # CATCHES: blockness alone does not omit </p> — br, li, td, title and
    # the removed center/dir/marquee keep it, as do phrasing tags.
    assert minify_html("<p>a</p><%s>b" % tag) == ("<p>a</p><%s>b" % tag).encode()


def test_select_keyword_drops_the_text_after_its_start_tag():
    """Text directly after a <select> start tag is dropped, </p> survives."""
    # CATCHES: select is an objectTag (so </p> is kept) and the keyword
    # marks its content as text-free: the loose text is swallowed.
    assert minify_html("<p>a</p><select>b") == b"<p>a</p><select>"
    assert minify_html("a <select></select> b") == b"a <select></select> b"


def test_option_and_optgroup_keywords_drop_following_text():
    """Text right after an option/optgroup end tag is dropped entirely."""
    # CATCHES: option is a block tag (drops the leading space) while
    # optgroup is not (keeps it), and both swallow the text token that
    # follows their end tag — even outside any <select>.
    assert minify_html("a <option></option> b") == b"a<option>"
    assert minify_html("a <optgroup></optgroup> b") == b"a <optgroup>"


def test_empty_script_and_style_pairs_collapse_their_spaces():
    """An empty script or style pair is removed and the two spaces merge."""
    # CATCHES: the rawTag keywords' empty elements are deleted, so the
    # surrounding text runs collapse into one space: 'a b', not 'a  b'.
    assert minify_html("a <script></script> b") == b"a b"
    assert minify_html("a <style></style> b") == b"a b"
