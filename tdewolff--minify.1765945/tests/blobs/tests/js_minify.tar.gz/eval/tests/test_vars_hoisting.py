"""vars.go behaviours: generated-name allocation (reserved keyword and global
collisions), class-private renaming order, let/const destructuring reordering
with its TDZ interference analysis, unused let-binding erasure, and var
hoisting target selection across statements."""

import pytest


def test_generated_names_skip_reserved_two_char_keywords(js):
    """Two-char generated names never collide with keywords like 'in'."""
    decls = ",".join("v%03d" % i for i in range(170))
    result = js("function f(){var %s}f()\n" % decls)
    # CATCHES: the 168th generated name would be the keyword 'in'; it is
    # skipped so 'on' is followed by 'an', and no keyword appears as a name.
    assert (result.returncode, result.stderr) == (0, b"")
    assert result.stdout == (
        b"function f(){var e,t,n,s,o,i,a,r,c,l,d,u,h,m,f,p,g,v,b,j,y,_,w,"
        b"O,x,C,E,k,A,S,M,F,T,z,D,N,L,R,P,H,I,B,V,$,W,U,K,q,Y,G,X,Q,Z,J,"
        b"ee,te,ne,se,oe,ie,ae,re,ce,le,de,ue,he,me,fe,pe,ge,ve,be,je,ye,"
        b"_e,we,Oe,xe,Ce,Ee,ke,Ae,Se,Me,Fe,Te,ze,De,Ne,Le,Re,Pe,He,Ie,Be,"
        b"Ve,$e,We,Ue,Ke,qe,Ye,Ge,Xe,Qe,Ze,Je,et,tt,nt,st,ot,it,at,rt,ct,"
        b"lt,dt,ut,ht,mt,ft,pt,gt,vt,bt,jt,yt,_t,wt,Ot,xt,Ct,Et,kt,At,St,"
        b"Mt,Ft,Tt,zt,Dt,Nt,Lt,Rt,Pt,Ht,It,Bt,Vt,$t,Wt,Ut,Kt,qt,Yt,Gt,Xt,"
        b"Qt,Zt,Jt,en,tn,nn,sn,on,an,rn,cn}f()")


def test_generated_names_skip_all_two_char_keywords(js):
    """Every two-char keyword ('in', 'as', 'do') is skipped in sequence."""
    decls = ",".join("v%03d" % i for i in range(290))
    result = js("function f(){var %s}f()\n" % decls)
    # CATCHES: 290 names cross the 'in', 'as' and 'do' positions; each is
    # skipped, e.g. 'on' is followed by 'an' and 'lo' by 'uo'.
    assert (result.returncode, result.stderr) == (0, b"")
    assert result.stdout == (
        b"function f(){var e,t,n,s,o,i,a,r,c,l,d,u,h,m,f,p,g,v,b,j,y,_,w,"
        b"O,x,C,E,k,A,S,M,F,T,z,D,N,L,R,P,H,I,B,V,$,W,U,K,q,Y,G,X,Q,Z,J,"
        b"ee,te,ne,se,oe,ie,ae,re,ce,le,de,ue,he,me,fe,pe,ge,ve,be,je,ye,"
        b"_e,we,Oe,xe,Ce,Ee,ke,Ae,Se,Me,Fe,Te,ze,De,Ne,Le,Re,Pe,He,Ie,Be,"
        b"Ve,$e,We,Ue,Ke,qe,Ye,Ge,Xe,Qe,Ze,Je,et,tt,nt,st,ot,it,at,rt,ct,"
        b"lt,dt,ut,ht,mt,ft,pt,gt,vt,bt,jt,yt,_t,wt,Ot,xt,Ct,Et,kt,At,St,"
        b"Mt,Ft,Tt,zt,Dt,Nt,Lt,Rt,Pt,Ht,It,Bt,Vt,$t,Wt,Ut,Kt,qt,Yt,Gt,Xt,"
        b"Qt,Zt,Jt,en,tn,nn,sn,on,an,rn,cn,ln,dn,un,hn,mn,fn,pn,gn,vn,bn,"
        b"jn,yn,_n,wn,On,xn,Cn,En,kn,An,Sn,Mn,Fn,Tn,zn,Dn,Nn,Ln,Rn,Pn,Hn,"
        b"In,Bn,Vn,$n,Wn,Un,Kn,qn,Yn,Gn,Xn,Qn,Zn,Jn,es,ts,ns,ss,os,is,rs,"
        b"cs,ls,ds,us,hs,ms,fs,ps,gs,vs,bs,js,ys,_s,ws,Os,xs,Cs,Es,ks,As,"
        b"Ss,Ms,Fs,Ts,zs,Ds,Ns,Ls,Rs,Ps,Hs,Is,Bs,Vs,$s,Ws,Us,Ks,qs,Ys,Gs,"
        b"Xs,Qs,Zs,Js,eo,to,no,so,oo,io,ao,ro,co,lo,uo,ho,mo,fo,po,go,vo,"
        b"bo,jo,yo,_o,wo}f()")


def test_two_char_generated_name_skips_used_global(js):
    """A two-char generated name colliding with a used global is skipped."""
    decls = ",".join("v%03d" % i for i in range(56))
    result = js("function f(){var %s;ee}f()\n" % decls)
    # CATCHES: the 55th name would be 'ee' but the function reads the global
    # 'ee', so names jump from 'J' straight to 'te' and 'ne'.
    assert (result.returncode, result.stderr) == (0, b"")
    assert result.stdout.startswith(
        b"function f(){var e,t,n,s,o,i,a,r,c,l,d,u,h,m,f,p,g,v,b,j,y,_,w,"
        b"O,x,C,E,k,A,S,M,F,T,z,D,N,L,R,P,H,I,B,V,$,W,U,K,q,Y,G,X,Q,Z,J,")
    assert result.stdout.endswith(b",te,ne;ee}f()")


@pytest.mark.parametrize("source,expected", [
    ("class C{#aaa;#bbb;#ccc;m(){this.#bbb;this.#bbb;this.#aaa}}\n",
     b"class C{#t;#e;#n;m(){this.#e,this.#e,this.#t}}"),
    ("class C{#aaa;#bbb;m(){this.#aaa;this.#bbb}}\n",
     b"class C{#e;#t;m(){this.#e,this.#t}}"),
    ("class C{#aaa;#bbb;}\n", b"class C{#e;#t}"),
    ("class C{#aaa=1;#bbb=2;m(){return this.#bbb+this.#aaa}}\n",
     b"class C{#e=1;#t=2;m(){return this.#t+this.#e}}"),
])
def test_class_private_names_ordered_by_use_count(js, source, expected):
    """Private class members are renamed most-used first."""
    result = js(source)
    # CATCHES: private names are allocated in use-count order (#bbb twice ->
    # '#e'), but each declaration slot keeps its position, only the name swaps.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("let a=1,[b]=[c];print(a,b)\n", b"let[b]=[c],a=1;print(a,b)"),
    ("let a=1,{b}={c:2};print(a,b)\n", b"let{b}={c:2},a=1;print(a,b)"),
    ("const a=1,[b]=[2];print(a,b)\n", b"const[b]=[2],a=1;print(a,b)"),
    ("let a=1,b2=2,[c]=[3],d=4;print(a,b2,c,d)\n",
     b"let[c]=[3],a=1,b2=2,d=4;print(a,b2,c,d)"),
    ("let a=1,[b]=[a],[c]=[2];print(a,b,c)\n",
     b"let[c]=[2],a=1,[b]=[a];print(a,b,c)"),
    ("let a=1,[b]=[new Q];print(a,b)\n", b"let[b]=[new Q],a=1;print(a,b)"),
])
def test_let_const_destructure_moves_to_front(js, source, expected):
    """let/const array and object bindings are hoisted to the list front."""
    result = js(source)
    # CATCHES: moving the destructuring binding first removes the space after
    # 'let', and a binding whose RHS references an earlier binding is skipped
    # in favour of a later non-interfering one.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("let a=1,[b]=[a];print(a,b)\n", b"let a=1,[b]=[a];print(a,b)"),
    ("let a=1,[b]=f(a);print(a,b)\n", b"let a=1,[b]=f(a);print(a,b)"),
    ("let a=1,[b]=[`x${a}`];print(a,b)\n",
     b"let a=1,[b]=[`x${a}`];print(a,b)"),
    ("let a=1,[b]=[a.q];print(a,b)\n", b"let a=1,[b]=[a.q];print(a,b)"),
    ("let a=1,[b]=[a[0]];print(a,b)\n", b"let a=1,[b]=[a[0]];print(a,b)"),
    ("let a=1,[b]=new Q(a);print(a,b)\n", b"let a=1,[b]=new Q(a);print(a,b)"),
    ("let a=1,[b]=[-a];print(a,b)\n", b"let a=1,[b]=[-a];print(a,b)"),
    ("let a=1,[b]=[a+1];print(a,b)\n", b"let a=1,[b]=[a+1];print(a,b)"),
    ("let a=1,[b]=[a?1:2];print(a,b)\n", b"let a=1,[b]=[a?1:2];print(a,b)"),
    ("let a=1,[b]=[{x:{y:a}}];print(a,b)\n",
     b"let a=1,[b]=[{x:{y:a}}];print(a,b)"),
    ("let a=1,[b]=[{[a]:1}];print(a,b)\n",
     b"let a=1,[b]=[{[a]:1}];print(a,b)"),
    ("let a=1,{b}={...a};print(a,b)\n", b"let a=1,{b}={...a};print(a,b)"),
    ("let a=1,{b}={c:a,d:2};print(a,b)\n",
     b"let a=1,{b}={c:a,d:2};print(a,b)"),
    ("let a=1,[b]=[function(){a}];print(a,b)\n",
     b"let a=1,[b]=[function(){a}];print(a,b)"),
    ("let a=1,[b]=[class extends a{}];print(a,b)\n",
     b"let a=1,[b]=[class extends a{}];print(a,b)"),
    ("function*g(){let a=1,[b]=[yield a];print(a,b)}\n",
     b"function*g(){let e=1,[t]=[yield e];print(e,t)}"),
])
def test_let_destructure_reorder_blocked_by_rhs_reference(js, source, expected):
    """RHS references to earlier bindings block the front move (TDZ safety)."""
    result = js(source)
    # CATCHES: the reorder is suppressed whenever the destructuring RHS reads
    # a variable bound earlier in the same let/const list, whatever the shape
    # (array element, call arg, member, template, spread, function body...).
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("let a=1,[b]=(a);print(a,b)\n", b"let[b]=a,a=1;print(a,b)"),
    ("let a=1,[b]=(0,a);print(a,b)\n", b"let[b]=(0,a),a=1;print(a,b)"),
    ("let a=1,[b]=((f)(a));print(a,b)\n", b"let[b]=f(a),a=1;print(a,b)"),
])
def test_parenthesised_rhs_does_not_block_reorder(js, source, expected):
    """A parenthesised RHS is not analysed, so the binding still moves."""
    result = js(source)
    # CATCHES: grouping parentheses hide the RHS reference from the
    # interference check, so the destructuring binding is moved to the front
    # and the redundant parentheses are dropped afterwards.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("{let {a}=b,c=1}\n", b"b"),
    ("{let [a,...r]=b}\n", b"b"),
    ("{let [a,[b]]=c}\n", b"c"),
    ("{let {a,...r}=b}\n", b"b"),
    ("{let [a]=f()}\n", b"f()"),
    ("{let [a]=f(),[b]=g()}\n", b"f(),g()"),
])
def test_unused_destructured_let_bindings_vanish(js, source, expected):
    """A block holding only an unused destructuring let collapses."""
    result = js(source)
    # CATCHES: unused let bindings (including rest elements and nested
    # patterns) are erased with their declarations; only side-effectful
    # initialisers survive, merged as a comma expression.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("{let {a}=b,c=a}\n", b"{let{a:e}=b,t=e}"),
    ("{let {a:b}=c,d=b}\n", b"{let{a:e}=c,t=e}"),
    ("{let {a,...r}=b,c=r}\n", b"{let{a:t,...e}=b,n=e}"),
    ("{let [a,...r]=b,c=r}\n", b"{let[t,...e]=b,n=e}"),
    ("{let[e]=b;e}\n", b"{let[e]=b;e}"),
])
def test_used_destructured_let_binding_keeps_block(js, source, expected):
    """A used destructuring binding keeps its block and declaration."""
    result = js(source)
    # CATCHES: when any binding of the pattern is referenced (even only in a
    # sibling binding's initialiser) the braces and the let declaration stay.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){var q=1;var {a}=b;print(q,a)}\n",
     b"function f(){var{a:t}=b,e=1;print(e,t)}"),
    ("function f(){var q=1;var [a]=b;print(q,a)}\n",
     b"function f(){var[t]=b,e=1;print(e,t)}"),
    ("function f(){var q=1;var {a,...r}=b;print(q,a,r)}\n",
     b"function f(){var{a:t,...n}=b,e=1;print(e,t,n)}"),
    ("function f(){var {a}=b;var {c}=d;print(a,c)}\n",
     b"function f(){var{a:e}=b,{c:t}=d;print(e,t)}"),
    ("function f(){var {a}=b;if(c)d();var {e}=g;print(a,e)}\n",
     b"function f(){var{a:e}=b;c&&d();var{e:t}=g;print(e,t)}"),
    ("function f(){var {a}=b;var q=1,r=2,s=3;print(a,q,r,s)}\n",
     b"function f(){var{a:e}=b,t=1,n=2,s=3;print(e,t,n,s)}"),
])
def test_destructured_var_decl_becomes_hoist_target(js, source, expected):
    """Object/array var declarations win the hoist-target selection."""
    result = js(source)
    # CATCHES: a destructured var declaration is always the surviving 'var'
    # statement (moving it to the expression form would need parentheses),
    # so plain declarations fold into it after the binding.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){var q=1;for(var a in b);print(q,a)}\n",
     b"function f(){var t,e=1;for(t in b);print(e,t)}"),
    ("function f(){var q=1;for(var a of b);print(q,a)}\n",
     b"function f(){var t,e=1;for(t of b);print(e,t)}"),
    ("function f(){for(var a in b);for(var c in d);print(a,c)}\n",
     b"function f(){for(var e in b);for(var t in d);print(e,t)}"),
    ("function f(){for(var a in b);for(var c=0;;);print(a,c)}\n",
     b"function f(){for(e in b);for(var e,t=0;;);print(e,t)}"),
    ("function f(){for(var a in b);print(a)}\n",
     b"function f(){for(var e in b);print(e)}"),
])
def test_for_in_of_var_hoisted_out_of_loop_head(js, source, expected):
    """for-in/for-of loop vars hoist out unless every decl is for-in/of."""
    result = js(source)
    # CATCHES: with a second non-for-in/of declaration the loop var moves out
    # ('for(t in b)'), but when every declaration in the scope is a for-in/of
    # head the declarations stay put inside the loop heads.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){var q=1;if(a){var b=2,c=3}print(q,b,c)}\n",
     b"function f(){if(e=1,a)var e,t=2,n=3;print(e,t,n)}"),
    ("function f(){if(a){var b=2}if(c){var d=3}print(b,d)}\n",
     b"function f(){if(a)var e,t=2;c&&(e=3),print(t,e)}"),
    ("function f(){var q=1;if(a){var b=2}if(c){var d=3}print(q,b,d)}\n",
     b"function f(){var e,t,n=1;a&&(e=2),c&&(t=3),print(n,e,t)}"),
    ("function f(){var q=1;while(a){var b=2}print(q,b)}\n",
     b"function f(){for(var e,t=1;a;)e=2;print(t,e)}"),
    ("function f(){var q=1;for(;;){var b=2}print(q,b)}\n",
     b"function f(){for(var e,t=1;;)e=2;print(t,e)}"),
    ("function f(){var q=1;do{var b=2}while(c);print(q,b)}\n",
     b"function f(){var e,t=1;do e=2;while(c)print(t,e)}"),
    ("function f(){var q=1;switch(a){case 1:var b=2}print(q,b)}\n",
     b"function f(){var e,t=1;switch(a){case 1:e=2}print(t,e)}"),
    ("function f(){var q=1;try{}catch(u){var b=2}print(q,b)}\n",
     b"function f(){var e,t=1;try{}catch{e=2}print(t,e)}"),
    ("function f(){var q=1;l:{var b=2}print(q,b)}\n",
     b"function f(){var e,t=1;l:e=2;print(t,e)}"),
    ("function f(){if(a){if(b){var q=1}}print(q)}\n",
     b"function f(){if(a&&b)var e=1;print(e)}"),
])
def test_var_decls_in_control_bodies_hoist_and_fold(js, source, expected):
    """var declarations inside control-flow bodies hoist to one target."""
    result = js(source)
    # CATCHES: the hoist target may be the innermost declaration (the outer
    # 'var q=1' folds into the if-condition as 'e=1,a'), hoisted bindings
    # move without their initialisers, and bindings without initialisers sort
    # before initialised ones in the surviving declaration.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){var q=1;if(c){var a}a=2;print(q,a)}\n",
     b"function f(){var e,t=1;c,e=2,print(t,e)}"),
    ("function f(){var a;for(var i=0;i<2;i++)a=1;print(a,i)}\n",
     b"function f(){for(var t,e=0;e<2;e++)t=1;print(t,e)}"),
    ("function f(){var a;for(var i=0;i<2;a=1)i++;print(a,i)}\n",
     b"function f(){for(var t,e=0;e<2;t=1)e++;print(t,e)}"),
    ("function f(){var q;if(a){var b=1}q=2,b=3;print(q,b)}\n",
     b"function f(){if(a)var e,t=1;e=2,t=3,print(e,t)}"),
    ("function f(){a=2;var q=1,a;print(q,a)}\n",
     b"function f(){var t=2,e=1;print(e,t)}"),
])
def test_assignments_fold_across_hoisted_decls(js, source, expected):
    """Assignments merge into the surviving declaration across statements."""
    result = js(source)
    # CATCHES: 'a=2' after an emptied if-body folds into the merged var
    # declaration, and assignments fold into for-init/for-post positions when
    # the declaration was hoisted out of the loop header.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){var q=1;with(c){var {a}=b}print(q,a)}\n",
     b"function f(){with(q=1,c)var{a}=b,q;print(q,a)}"),
    ("function f(){with(c){var {a}=b;print(a)}}\n",
     b"function f(){with(c){var{a}=b;print(a)}}"),
    ("function f(){var q=1;with(c){var a=1}print(q,a)}\n",
     b"function f(){var a,q=1;with(c)a=1;print(q,a)}"),
])
def test_with_body_hoisting_keeps_original_names(js, source, expected):
    """Hoisting still runs inside with() but names are not renamed."""
    result = js(source)
    # CATCHES: the with() disables renaming yet not hoisting, so 'var q=1'
    # folds into the with-condition and the object binding becomes the hoist
    # target inside the with body with 'q' appended as a bare binding.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){var q=1;for(var i;;);print(q,i)}\n",
     b"function f(){for(var t,e=1;;);print(e,t)}"),
    ("function f(){var q=1;for(var i,j;;);print(q,i,j)}\n",
     b"function f(){for(var t,n,e=1;;);print(e,t,n)}"),
    ("function f(){var q;for(var i=print();i<2;i++)print(i,q)}\n",
     b"function f(){for(var t,e=print();e<2;e++)print(e,t)}"),
    ("function f(){var q=1;for(var {a}=b;a;)print(a,q)}\n",
     b"function f(){for(var{a:e}=b,t=1;e;)print(e,t)}"),
    ("function f(){var q=1;for(var [a]=b;a;)print(a,q)}\n",
     b"function f(){for(var[e]=b,t=1;e;)print(e,t)}"),
])
def test_for_init_decl_hoisting(js, source, expected):
    """for-init declarations absorb hoisted bindings and keep the head."""
    result = js(source)
    # CATCHES: an emptied for-init declaration survives as the hoist target
    # with the other bindings prepended, including destructured bindings;
    # 'var i;;' without initialiser still merges with the outer declaration.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){var aaaa=1;if(a){var bb=2}print(aaaa,bb)}\n",
     b"function f(){var bb,aaaa=1;a&&(bb=2),print(aaaa,bb)}"),
    ("function f(){if(a){var bb=2}var aaaa=1;print(aaaa,bb)}\n",
     b"function f(){a&&(bb=2);var bb,aaaa=1;print(aaaa,bb)}"),
    ("function f(){var aaaa=1;var bb=2;print(aaaa,bb)}\n",
     b"function f(){var aaaa=1,bb=2;print(aaaa,bb)}"),
])
def test_keep_var_names_still_hoists(js, source, expected):
    """--js-keep-var-names hoists and merges but keeps the spellings."""
    result = js(source, ["--js-keep-var-names"])
    # CATCHES: hoisting happens with original names kept: 'bb' is prepended
    # as a bare binding to 'var bb,aaaa=1' and the if-body initialiser folds
    # into the condition as 'bb=2'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_hoisting_aborts_above_ten_thousand_bindings(js):
    """A hoist target with more than 10000 bindings is left alone."""
    big = ",".join("v%05d=1" % i for i in range(10001))
    capped = js("function f(){var q=1;if(a){var %s}}f()\n" % big)
    # CATCHES: with 10001 defaulted bindings the hoist is aborted, so 'q'
    # stays its own 'var e=1' statement and the big declaration stays inside
    # the if body instead of folding 'e=1' into the if-condition.
    assert (capped.returncode, capped.stderr) == (0, b"")
    assert capped.stdout.startswith(
        b"function f(){var e=1;if(a)var t=1,n=1,s=1,o=1,i=1,r=1,c=1,l=1,")
    assert capped.stdout.endswith(b",pKt=1,gKt=1,vKt=1,bKt=1,jKt=1,yKt=1}f()")
    assert b"if(e=1,a)" not in capped.stdout

    exact = ",".join("v%05d=1" % i for i in range(10000))
    control = js("function f(){var q=1;if(a){var %s}}f()\n" % exact)
    # CATCHES: at exactly 10000 bindings the hoist proceeds: 'q' folds into
    # the if-condition as 'e=1,a' and its bare binding is prepended.
    assert (control.returncode, control.stderr) == (0, b"")
    assert control.stdout.startswith(
        b"function f(){if(e=1,a)var e,t=1,n=1,s=1,o=1,i=1,r=1,c=1,l=1,")
    assert control.stdout.endswith(b",fKt=1,pKt=1,gKt=1,vKt=1,bKt=1,jKt=1}f()")
