"""Comment and whitespace handling: normal comments are dropped, bang
comments and hashbangs survive, and no inter-token whitespace remains."""

import pytest


@pytest.mark.parametrize("source,expected", [
    ("/*comment*/a\n", b"a"),
    ("/* normal */ var a = 1;\n", b"var a=1"),
    ("/*\n multi\n line\n*/a\n", b"a"),
    ("//c1\n//c2\na\n", b"a"),
    ("a//c1\n//c2\nb\n", b"a,b"),
    ("var a = 1 /* inline */ ;\n", b"var a=1"),
    ("a/* c */.b\n", b"a.b"),
    ("/*@preserve*/a\n", b"a"),
])
def test_normal_comments_are_removed(js, source, expected):
    """Ordinary comments never reach the output; bang comments do."""
    result = js(source)
    # CATCHES: /* */ and // comments (even multiline or 'preserve'-style)
    # vanish entirely, while a space is inserted only where tokenisation
    # demands it (identifier following identifier).
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_bang_block_comment_is_kept_verbatim(js):
    """/*! ... */ comments are preserved byte for byte."""
    result = js("/*!comment*/a\n")
    # CATCHES: only comments whose third byte is '!' are treated as
    # licence banners and kept; everything else is stripped.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"/*!comment*/a", b"")


def test_bang_line_comment_keeps_newline(js):
    """//! comments survive, each terminated by its own newline."""
    result = js("//!comment1\n\n//!comment2\na\n")
    # CATCHES: two consecutive //! comments are emitted on separate lines
    # (a missing newline would merge them into one comment).
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"//!comment1\n//!comment2\na", b"")


def test_bang_comment_hoisted_before_statement(js):
    """A bang comment moves in front of the statement that contains it."""
    result = js("var a = /*! comment */ b;\n")
    # CATCHES: the comment is detached from inside the var declaration and
    # written before it, so it is never reordered after generated code.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"/*! comment */var a=b", b"")


def test_bang_line_comment_moves_before_merged_statements(js):
    """A trailing //! travels with its statement when statements merge."""
    result = js("a = 5 //! note\nb = 6\n")
    # CATCHES: statements fold into 'a=5,b=6' and the bang comment is
    # re-emitted first with its newline, keeping the code after it valid.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"//! note\na=5,b=6", b"")


def test_multiple_bang_block_comments_keep_order(js):
    """Several /*! comments are emitted in source order, back to back."""
    result = js("/*!c1*/ /*!c2*/ a\n")
    # CATCHES: both banners survive and no separator is invented between
    # them (they are already self-delimiting).
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"/*!c1*//*!c2*/a", b"")


def test_hashbang_is_kept_without_trailing_newline(js):
    """A leading hashbang is preserved but no newline follows it."""
    result = js("#!/usr/bin/env node\n\n\nvar a=1\n")
    # CATCHES: the '#!' line is emitted verbatim with its newline stripped,
    # so the first statement is appended directly to the shebang text.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"#!/usr/bin/env nodevar a=1", b"")


def test_hashbang_then_bang_line_comment(js):
    """A hashbang followed by a //! banner keeps both on one line."""
    result = js("#!x\n//!y\na\n")
    # CATCHES: the hashbang gets no newline of its own, so the //! banner
    # continues the same line; the banner's own newline terminates it.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"#!x//!y\na", b"")


def test_blank_and_bom_input(js):
    """Blank input minifies to nothing and a UTF-8 BOM is dropped."""
    for blank in ["\n\n\n", "   \t  ", "\r\n\r\n"]:
        result = js(blank)
        # CATCHES: whitespace-only input yields empty output with no error.
        assert (result.returncode, result.stdout, result.stderr) == (0, b"", b"")
    result = js("﻿var a=1\n")
    # CATCHES: a leading UTF-8 BOM is consumed as whitespace rather than
    # leaking into or breaking the minified output.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"var a=1", b"")


@pytest.mark.parametrize("source", [
    "/* keep */\n",
    "// only a comment\n",
    "/* keep */ // and a line comment\n",
])
def test_comment_only_input_yields_no_output(js, source):
    """Input consisting solely of comments minifies to empty output."""
    result = js(source)
    # CATCHES: a program with no statements emits nothing at all (no newline,
    # no error), the comments are not echoed back either.
    assert (result.returncode, result.stdout, result.stderr) == (0, b"", b"")
    control = js(source + "var q=1\n")
    # CATCHES: the very same comment shapes preceding a real statement leave
    # the statement intact, proving the empty case is not a crash.
    assert (control.returncode, control.stdout, control.stderr) == (
        0, b"var q=1", b"")


def test_directive_prologue_quotes_normalised(js):
    """Directive prologues are rewritten with double quotes."""
    result = js("'use strict';\n")
    # CATCHES: the string quotes of a directive prologue are normalised to
    # double quotes even though single quotes would be equally valid.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'"use strict"', b"")


@pytest.mark.parametrize("source,expected", [
    ("a\n--> b\n", b"a"),
    ("<!-- c\na\n", b"a"),
    ("a<!--c\n", b"a"),
])
def test_html_like_comments_are_removed(js, source, expected):
    """HTML-style comment openers are treated as line comments."""
    result = js(source)
    # CATCHES: '<!--' anywhere and '-->' at the start of a line consume the
    # rest of the line instead of being lexed as operators.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")
