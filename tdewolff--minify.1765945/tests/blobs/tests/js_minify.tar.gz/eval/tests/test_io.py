"""I/O behaviour of the JS minifier: stdin/file reading, stdout/stderr
separation, exit codes and the no-partial-output guarantee on errors."""

import pytest

from conftest import program_path, pinned_env


def test_stdin_minified_without_trailing_newline(js):
    """Stdin with --type js is minified to stdout with no trailing newline."""
    result = js("var a = 1;\n")
    # CATCHES: the output is not newline-terminated and all inter-token
    # whitespace plus the semicolon after the final statement are gone.
    assert (result.returncode, result.stdout, result.stderr) == (0, b"var a=1", b"")


def test_js_file_to_stdout(run, write, tmp_path):
    """A .js file argument is minified to stdout, leaving the file intact."""
    write("input.js", "var a = 1;\nconsole.log(a);\n")
    result = run(["input.js"])
    # CATCHES: the file itself is never rewritten without -i, and its
    # contents are minified exactly as stdin would be.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"var a=1;console.log(a)", b"")
    assert (tmp_path / "input.js").read_bytes() == b"var a = 1;\nconsole.log(a);\n"


def test_mjs_file_is_javascript(run, write):
    """A .mjs module file is minified as JavaScript."""
    write("mod.mjs", "export default 5;\n")
    result = run(["mod.mjs"])
    # CATCHES: the .mjs extension maps to the JS minifier (module syntax is
    # preserved) rather than being rejected as an unknown filetype.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"export default 5", b"")


def test_unknown_extension_requires_type(run, write):
    """A file with an unknown extension is refused unless --type is given."""
    write("data.txt", "var a = 1;\n")
    result = run(["data.txt"])
    # CATCHES: the exact diagnostic names the file and asks for --type, and
    # nothing is written to stdout while the exit status is 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", b"ERROR: cannot infer mimetype from extension in data.txt,"
                b" set --type explicitly\n")
    explicit = run(["--type", "js", "data.txt"])
    assert (explicit.returncode, explicit.stdout, explicit.stderr) == (
        0, b"var a=1", b"")


@pytest.mark.parametrize("mimetype", ["text/javascript", "application/javascript"])
def test_mime_type_forms(run, write, mimetype):
    """--type accepts both filetype aliases and full mimetypes."""
    write("data.txt", "var a = 1;\n")
    result = run(["--type", mimetype, "data.txt"])
    # CATCHES: 'text/javascript' and 'application/javascript' are both
    # recognised spellings of the JS mimetype, not just the short 'js'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"var a=1", b"")


def test_stdin_without_type_is_an_error(run):
    """Reading stdin requires an explicit --type."""
    result = run([], stdin="var a = 1;\n")
    # CATCHES: with no input file and no --type the program refuses to guess
    # the mimetype instead of assuming JS.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", b"ERROR: must specify --type for stdin\n")


def test_parse_error_copies_input_to_stdout(js):
    """A syntax error echoes the original input and fails with exit code 1."""
    result = js("var a = ;\n")
    # CATCHES: on failure the original bytes are copied to stdout (no
    # partially minified output) and stderr carries the parse error.
    assert result.returncode == 1
    assert result.stdout == b"var a = ;\n"
    assert result.stderr == (
        b"ERROR: cannot minify -: unexpected ; in expression"
        b" on line 1 and column 9\n"
        b"    1: var a = ;\n"
        b"               ^\n")


def test_parse_error_reports_line_and_column(js):
    """Parse errors report position with a caret pointing at the token."""
    result = js("a = b\n/regex/.test(c)\n")
    # CATCHES: a '/' after a value token is lexed as division, so the error
    # names the '.' at line 2 column 8 and shows the offending source line.
    assert result.returncode == 1
    assert result.stderr == (
        b"ERROR: cannot minify -: unexpected . in expression"
        b" on line 2 and column 8\n"
        b"    2: /regex/.test(c)\n"
        b"              ^\n")


def test_parse_error_file_writes_original_bytes(run, write, tmp_path):
    """A failing file minification writes the input verbatim to -o."""
    write("bad.js", "var a = 1;\nvar b = ;\n")
    result = run(["-q", "-o", "out/bad.min.js", "bad.js"])
    # CATCHES: the output file is created but contains the unminified input,
    # the run exits 1, and -q keeps stdout empty.
    assert (result.returncode, result.stdout, result.stderr) == (1, b"", b"")
    assert (tmp_path / "out" / "bad.min.js").read_bytes() == b"var a = 1;\nvar b = ;\n"


def test_hashbang_only_valid_on_first_line(js):
    """A hashbang that is not the first line is a parse error."""
    result = js("var a=1;\n#!/usr/bin/env node\n")
    # CATCHES: only a leading '#!' is a shebang; later in the file '#' is a
    # private-identifier start and '!' cannot continue it.
    assert result.returncode == 1
    assert result.stdout == b"var a=1;\n#!/usr/bin/env node\n"
    assert result.stderr == (
        b"ERROR: cannot minify -: unexpected ! on line 2 and column 2\n"
        b"    2: #!/usr/bin/env node\n"
        b"        ^\n")


def test_multiple_inputs_need_bundle(run, write):
    """Several input files cannot share stdout unless --bundle is given."""
    write("one.js", "var a = 1;\n")
    write("two.js", "var q = 2;\n")
    result = run(["one.js", "two.js"])
    # CATCHES: multiple files with a stdout destination are rejected before
    # any minification happens, with exit code 1.
    assert (result.returncode, result.stdout, result.stderr) == (
        1, b"", b"ERROR: must specify --bundle for multiple input files"
                b" with stdout destination\n")


def test_bundle_concatenates_then_minifies(run, write):
    """--bundle minifies the concatenation of all inputs as one program."""
    write("one.js", "var a = 1;\n")
    write("two.js", "var q = 2;\n")
    result = run(["--bundle", "one.js", "two.js"])
    # CATCHES: bundling parses the files as a single program, so the two var
    # declarations merge into one instead of producing two statements.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"var a=1,q=2", b"")


def test_output_file_is_created_with_parents(run, write, tmp_path):
    """-o writes the minified bytes and creates missing directories."""
    write("in.js", "var a = 1;\n")
    result = run(["-q", "-o", "deep/nested/out.js", "in.js"])
    # CATCHES: missing parent directories of the -o target are created, the
    # file holds only the minified bytes and -q silences the stats line.
    assert (result.returncode, result.stdout, result.stderr) == (0, b"", b"")
    assert (tmp_path / "deep" / "nested" / "out.js").read_bytes() == b"var a=1"


def test_stdin_ignored_when_file_given(run, write):
    """An explicit input file wins over piped stdin."""
    write("in.js", "var a = 1;\n")
    result = run(["--type", "js", "in.js"], stdin="var zzz = 99;\n")
    # CATCHES: the file argument is minified, not the stdin payload, even
    # though --type was given explicitly.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"var a=1", b"")


def test_empty_input_yields_empty_output(js):
    """Empty stdin produces empty stdout and a zero exit status."""
    result = js("")
    # CATCHES: nothing (no newline, no error) is emitted for empty input.
    assert (result.returncode, result.stdout, result.stderr) == (0, b"", b"")
    control = js("var payload = 7;\n")
    # CATCHES: the same stdin channel does carry minified code when input is
    # non-empty, so the empty case is a deliberate no-op, not a broken pipe.
    assert (control.returncode, control.stdout, control.stderr) == (
        0, b"var payload=7", b"")


def test_missing_file_reports_error_but_exits_zero(run):
    """A nonexistent input path is reported on stderr with exit code 0."""
    result = run(["--type", "js", "definitely_missing_xyz.js"])
    # CATCHES: stat failures are only a warning-level ERROR line on stderr
    # and, surprisingly, do not influence the exit status.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"", b"ERROR: stat definitely_missing_xyz.js:"
                b" no such file or directory\n")


def test_directory_input_without_recursive_warns(run, write):
    """A directory argument without -r is skipped with a warning."""
    write("sub/in.js", "var a = 1;\n")
    result = run(["--type", "js", "sub"])
    # CATCHES: directories are omitted (not recursed into) with a WARNING on
    # stderr, and the run still succeeds.
    assert result.returncode == 0
    assert result.stdout == b""
    assert result.stderr == (
        b"WARNING: --recursive not specified, omitting directory sub\n")


def test_stats_line_shape_for_output_file(run, write):
    """The non-quiet -o run prints a timing/size summary on stdout."""
    import re

    write("in.js", "var a = 1;\n")
    result = run(["-o", "out.js", "in.js"])
    # CATCHES: stdout carries a '(...) - <input> to <output>' summary whose
    # timing varies but whose byte counts and percentage are fixed.
    assert result.returncode == 0
    assert re.fullmatch(
        r"\( *\d+ µs, *11 B, *7 B, *63\.6%, *\d+ kB/s\) - in\.js to out\.js\n",
        result.out) is not None
