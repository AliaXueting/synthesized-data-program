"""String literal minification: quote selection, escape decoding,
template literal promotion and concatenation merging."""

import pytest


@pytest.mark.parametrize("source,expected", [
    ("a('single', \"double\", `tpl`)\n", b'a("single","double",`tpl`)'),
    ("a('it\\'s', \"say \\\"hi\\\"\")\n", b'a("it\'s",\'say "hi"\')'),
    ("a('has \"double\" quotes')\n", b'a(\'has "double" quotes\')'),
    ("a(\"has 'single' quotes\")\n", b'a("has \'single\' quotes")'),
    ("a('has \\\"both\\\" and \\'single\\'')\n",
     b'a(`has "both" and \'single\'`)'),
    ("a('`backtick`')\n", b'a("`backtick`")'),
    ("a(\"a'b\")\n", b'a("a\'b")'),
])
def test_quote_character_is_chosen_for_length(js, source, expected):
    """The quote character switches to whichever delimiter is shortest."""
    result = js(source)
    # CATCHES: strings containing one quote style switch to the other, and
    # a string containing both switches to a backtick template literal.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a('\\x41\\u0042')\n", b'a("AB")'),
    ("a('\\x41')\n", b'a("A")'),
    ("a('\\u0041')\n", b'a("A")'),
    ("a('\\u{1F600}')\n", b'a("\xf0\x9f\x98\x80")'),
    ("a('\\u2028\\u2029')\n", b'a("\xe2\x80\xa8\xe2\x80\xa9")'),
    ("a('a\\tb')\n", b'a("a\tb")'),
    (b"a('back\\\\slash')\n", b'a("back\\\\slash")'),
    (b"a('back\\slash')\n", b'a("backslash")'),
    ("a('\\0\\x00\\u0000')\n", b'a("\\0\\x00\\x00")'),
])
def test_escapes_are_decoded_when_safe(js, source, expected):
    """Hex and unicode escapes are decoded into raw characters."""
    result = js(source)
    # CATCHES: \\x41/\\u0041 become 'A' and the astral plane codepoint is
    # emitted as raw UTF-8, but NUL keeps an escape, a proper backslash
    # escape stays escaped, and a stray '\\s' escape loses its backslash.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_newlines_promote_to_template_literal(js):
    """An escaped newline becomes a literal newline inside backticks."""
    result = js("a('multi\\nline')\n")
    # CATCHES: the string is re-quoted with backticks so the newline can be
    # written literally instead of as a two-character escape.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"a(`multi\nline`)", b"")


def test_mixed_line_breaks_keep_carriage_return_escaped(js):
    """A CRLF pair in a template keeps \\r escaped but the LF literal."""
    result = js("a('\\u000A\\u000D')\n")
    # CATCHES: only the line feed may be literal inside backticks; the
    # carriage return stays as the two-character escape '\\r'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"a(`\n\\r`)", b"")


@pytest.mark.parametrize("source,expected", [
    ("a('a'+'b', 'a'+'b'+'c')\n", b'a("ab","abc")'),
    ("'a'+'b'+c\n", b'"ab"+c'),
    ("a+'b'+'c'\n", b'a+"bc"'),
    ("'a'+1\n", b'"a"+1'),
    ("'a'+b\n", b'"a"+b'),
    ("`a`+`b`\n", b'`a`+`b`'),
    ("'a'+`b`\n", b'"a"+`b`'),
    ("'str'+typeof a\n", b'"str"+typeof a'),
])
def test_adjacent_string_concatenation_merges(js, source, expected):
    """Literal-only concatenations merge into one string."""
    result = js(source)
    # CATCHES: consecutive string operands fuse (across an initial variable
    # too) while any non-literal operand stops the merge; template literals
    # and typeof expressions never merge.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a(`x${b}y`)\n", b"a(`x${b}y`)"),
    ("a(`plain ${ b } tail`)\n", b"a(`plain ${b} tail`)"),
    ("String.raw`\\b`\n", b"String.raw`\\b`"),
    ("tag`a${b}c`\n", b"tag`a${b}c`"),
    ("a(`\\u0041`)\n", b"a(`A`)"),
])
def test_template_literals_keep_interpolation(js, source, expected):
    """Template literals are emitted with interpolations intact."""
    result = js(source)
    # CATCHES: '${ b }' loses its inner spaces but the backticks, the tag
    # and String.raw's protected escape all survive verbatim.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_quote_normalisation_for_html_attribute(js):
    """A string holding both quote styles prefers backticks."""
    result = js("a('<div onclick=\"alert(\\'test\\')\">')\n")
    # CATCHES: the default (latest) version rewrites the string as a
    # template literal because that avoids both escape sequences.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'a(`<div onclick="alert(\'test\')">`)', b"")
