"""Regular expression handling: useless escapes are removed, meaningful
ones survive, and the division ambiguity is resolved from context."""

import pytest


@pytest.mark.parametrize("source,expected", [
    ("/\\-/.test(x)\n", b"/-/.test(x)"),
    ("/\\a/.test(x)\n", b"/a/.test(x)"),
    ("/[\\.]/.test(x)\n", b"/[.]/.test(x)"),
    ("/[\\d\\w]+/.test(x)\n", b"/[\\d\\w]+/.test(x)"),
    ("/[\\]]/.test(x)\n", b"/[\\]]/.test(x)"),
    ("/\\//.test(x)\n", b"/\\//.test(x)"),
    ("/\\n/.test(x)\n", b"/\\n/.test(x)"),
    ("/a\\/b/.test(x)\n", b"/a\\/b/.test(x)"),
])
def test_regex_escape_removal(js, source, expected):
    """Escapes that add no meaning are dropped from regex literals."""
    result = js(source)
    # CATCHES: '\\-' outside a class and '\\.' inside one are redundant, but
    # class-closing brackets, slashes, backslashes-for-shorthand and
    # escaped newlines must all keep their backslashes.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_regex_literal_in_assignment(js):
    """A regex following '=' is not confused with a division."""
    result = js("var re = /\\d+/g; re.test('123')\n")
    # CATCHES: the lexer picks regexp mode after '=', keeps the flags 'g'
    # attached and re-quotes the unrelated string argument.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'var re=/\\d+/g;re.test("123")', b"")


@pytest.mark.parametrize("source,expected", [
    ("a=/x/;a\n", b"a=/x/,a"),
    ("var a=/x/;\ntypeof a\n", b"var a=/x/;typeof a"),
    ("if(a)/x/.test(b)\n", b"a&&/x/.test(b)"),
    ("a\n/b/g\n", b"a/b/g"),
])
def test_regex_after_expression_context(js, source, expected):
    """A slash after an expression is division, after '=' a regex."""
    result = js(source)
    # CATCHES: 'a\n/b/g' is parsed as 'a/b/g' (division) since ASI does not
    # split it, while a regex in an if condition keeps its literal form.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_unterminated_regex_is_a_parse_error(js):
    """An escaped slash swallowing the terminator aborts with an error."""
    result = js("/a\\/.test(x)\n")
    # CATCHES: the escaped '/' makes the regex run to end of line, and the
    # diagnostic names the EOF position rather than producing output.
    assert result.returncode == 1
    assert result.stdout == b"/a\\/.test(x)\n"
    assert result.stderr == (
        b"ERROR: cannot minify -: unexpected EOF or newline"
        b" in regular expression on line 1 and column 13\n"
        b"    1: /a\\/.test(x)\n"
        b"                   ^\n")
