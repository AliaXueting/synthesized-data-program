"""--js-version and --js-keep-var-names flag behaviour: which rewrites are
gated on an ECMAScript year and how the flags interact with each other."""

import pytest


@pytest.mark.parametrize("version,expected", [
    (None, b"a??b"),
    (0, b"a??b"),
    (2020, b"a??b"),
    (9999, b"a??b"),
    (2019, b"a==null?b:a"),
    (1, b"a==null?b:a"),
])
def test_nullish_coalescing_needs_2020(js, version, expected):
    """a==null?b:a becomes a??b only for --js-version 2020 or newer."""
    flags = [] if version is None else ["--js-version", version]
    result = js("a==null?b:a\n", flags)
    # CATCHES: the default (0) means 'latest', so the rewrite happens for
    # 0/2020/9999 but not for 2019 or 1, where the conditional survives.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("version,expected", [
    (2020, b"a?.b"),
    (2021, b"a?.b"),
    (2019, b"a==null?0[0]:a.b"),
    (2014, b"a==null?0[0]:a.b"),
])
def test_optional_chaining_needs_2020(js, version, expected):
    """a==null?undefined:a.b becomes a?.b only from 2020 onwards."""
    result = js("a==null?undefined:a.b\n", ["--js-version", version])
    # CATCHES: below 2020 the conditional is kept but 'undefined' is still
    # rewritten to '0[0]' inside it, showing the two rewrites are separate.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,version,expected", [
    ("a??b\n", 2014, b"a??b"),
    ("a?.b\n", 2014, b"a?.b"),
])
def test_newer_syntax_passes_through_older_versions(js, source, version, expected):
    """Existing ?? / ?. syntax is never downgraded for older targets."""
    result = js(source, ["--js-version", version])
    # CATCHES: --js-version only gates new rewrites; already-modern syntax
    # in the input is printed as-is even when targeting an older year.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("version,expected", [
    (None, b"try{}catch{}"),
    (0, b"try{}catch{}"),
    (2019, b"try{}catch{}"),
    (2018, b"try{}catch(e){}"),
])
def test_optional_catch_binding_needs_2019(js, version, expected):
    """An unused catch parameter is dropped only for 2019+ targets."""
    flags = [] if version is None else ["--js-version", version]
    result = js("try{}catch(a){}\n", flags)
    # CATCHES: the binding disappears for the default and 2019, but 2018
    # must keep '(a)' (renamed to 'e') because the syntax is newer.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("version,expected", [
    (None, b"a(`multi\nline`)"),
    (2015, b"a(`multi\nline`)"),
    (2014, b'a("multi\\nline")'),
])
def test_template_literals_need_2015(js, version, expected):
    """Strings are re-quoted as template literals only for 2015+ targets."""
    flags = [] if version is None else ["--js-version", version]
    result = js("a('multi\\nline')\n", flags)
    # CATCHES: with 2014 the newline stays an escape inside double quotes
    # instead of becoming a literal newline between backticks.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("version,expected", [
    (2015, b'a(`<div onclick="alert(\'test\')">`)'),
    (2014, b'a("<div onclick=\\"alert(\'test\')\\">")'),
])
def test_html_like_string_prefers_backticks_from_2015(js, version, expected):
    """A string with both quote styles becomes a template for 2015+."""
    result = js("a('<div onclick=\"alert(\\'test\\')\">')\n",
                ["--js-version", version])
    # CATCHES: for 2015 the backtick form avoids all escapes, while 2014
    # must escape the inner double quotes inside a double-quoted string.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_math_pow_is_not_version_gated(js):
    """The exponentiation rewrite applies even to very old targets."""
    result = js("Math.pow(a,b)\n", ["--js-version", "2014"])
    # CATCHES: unlike the template/nullish rewrites, 'a**b' (an ES2016
    # feature) is emitted regardless of the requested version.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"a**b", b"")


def test_keep_var_names_still_drops_unused_catch_binding(js):
    """--js-keep-var-names does not protect an unused catch parameter."""
    result = js("try{}catch(a){}\n",
                ["--js-keep-var-names", "--js-version", "2019"])
    # CATCHES: dropping the binding is a version-gated syntax rewrite, not
    # a renaming step, so it still happens with names preserved.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"try{}catch{}", b"")


def test_keep_var_names_keeps_used_catch_binding_for_old_version(js):
    """With 2018 the catch parameter survives under its original name."""
    result = js("try{}catch(err){err}\n",
                ["--js-keep-var-names", "--js-version", "2018"])
    # CATCHES: for an old target the optional catch binding cannot be used,
    # and with renaming disabled the name stays exactly 'err'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"try{}catch(err){err}", b"")


def test_flags_do_not_change_io_behaviour(run, write, tmp_path):
    """JS flags leave the CLI contract (file, exit code, bytes) untouched."""
    write("in.js", "function f(){ var alpha = 1; return alpha }\n")
    result = run(["--js-keep-var-names", "--js-version", "2015", "in.js"])
    # CATCHES: flag combinations still read the .js file, write minified
    # bytes without a trailing newline and exit 0 with empty stderr.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"function f(){var alpha=1;return alpha}", b"")
