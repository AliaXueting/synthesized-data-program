"""Statement-list optimisations from js/stmtlist.go and the escape-html
paths of js/util.go reached through inline <script> elements."""

import pytest


@pytest.mark.parametrize("source,expected", [
    ("function f(){if(a){return b}else{c()}}\n",
     b"function f(){if(a)return b;c()}"),
    ("function f(){if(!a){b()}else{return c}}\n",
     b"function f(){if(a)return c;b()}"),
    ("function f(){if(a){throw b}else{c()}}\n",
     b"function f(){if(a)throw b;c()}"),
    ("while(x){if(a){break}else{c()}}\n",
     b"for(;x;){if(a)break;c()}"),
    ("while(x){if(a){continue}else{c()}}\n",
     b"for(;x;){if(a)continue;c()}"),
])
def test_else_body_hoisted_after_flow_statement(js, source, expected):
    """An else branch after a return/throw/break/continue moves outward."""
    result = js(source)
    # CATCHES: when the if body ends in a flow statement the else keyword
    # disappears and its statements join the enclosing scope; a '!cond' is
    # rewritten by swapping the branches instead of keeping the negation.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){a();return}\n", b"function f(){a()}"),
    ("function f(){return undefined}\n", b"function f(){}"),
    ("function f(){return void 0}\n", b"function f(){}"),
    ("function f(){a();return void 0}\n", b"function f(){a()}"),
    ("function f(){a();return b,void 0}\n", b"function f(){return a(),b}"),
    ("function f(){return void a}\n", b"function f(){return void a}"),
    ("function f(){return 0[0]}\n", b"function f(){return 0[0]}"),
])
def test_superfluous_return_statement_removed(js, source, expected):
    """A trailing valueless or undefined return is dropped entirely."""
    result = js(source)
    # CATCHES: 'return', 'return undefined' and 'return void 0' vanish, a
    # trailing ',void 0' is stripped from a comma return, but 'void a' and
    # the literal '0[0]' are kept because their operand may be observable.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("for(;;){a();continue}\n", b"for(;;)a()"),
    ("while(x){a();continue}\n", b"for(;x;)a()"),
    ("lbl:for(;;){a();continue lbl}\n", b"lbl:for(;;){a();continue lbl}"),
    ("for(;;){a();break}\n", b"for(;;){a();break}"),
])
def test_superfluous_continue_removed(js, source, expected):
    """A trailing unlabelled continue disappears; break always stays."""
    result = js(source)
    # CATCHES: only an anonymous 'continue' at the end of an iteration block
    # is removed; a labelled continue and every 'break' are preserved.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){if(a)return b;return}\n", b"function f(){if(a)return b}"),
    ("function f(){if(a)return b;return c}\n", b"function f(){return a?b:c}"),
    ("function f(){if(a)throw b;throw c}\n", b"function f(){throw a?b:c}"),
    ("function f(){if(a){throw b}else{throw c}}\n", b"function f(){throw a?b:c}"),
])
def test_if_flow_merges_with_following_flow(js, source, expected):
    """An if guarding return/throw merges with the next return/throw."""
    result = js(source)
    # CATCHES: 'if(a)return b;return c' folds to 'return a?b:c' and the
    # throw equivalents fold the same way, but a valueless trailing return
    # is dropped rather than merged into the conditional.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a();with(b)c()\n", b"with(a(),b)c()"),
    ("a();switch(b){case 1:c()}\n", b"switch(a(),b){case 1:c()}"),
])
def test_with_and_switch_absorb_preceding_expression(js, source, expected):
    """A preceding expression statement folds into with/switch heads."""
    result = js(source)
    # CATCHES: 'a();with(b)c()' becomes 'with(a(),b)c()' and the switch
    # discriminant likewise gains a comma expression in front.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("if(a){if(b)var x=1}else c()\n", b"if(a){if(b)var x=1}else c()"),
    ("if(a){while(b){if(c)d()}}else e()\n",
     b"if(a)for(;b;)c&&d();else e()"),
    ("if(a){lbl:if(b)c()}else d()\n", b"if(a)lbl:b&&c();else d()"),
    ("if(a){with(b){if(c)d()}}else e()\n",
     b"if(a)with(b)c&&d();else e()"),
])
def test_dangling_else_protection_keeps_braces(js, source, expected):
    """Braces survive only when the if body truly ends in a bare if."""
    result = js(source)
    # CATCHES: 'if(a){if(b)var x=1}else c()' keeps its braces because the
    # inner if cannot become an expression, while bodies whose inner if
    # collapses to 'c&&d()' lose the braces safely.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_nested_if_without_else_merges_conditions(js):
    """'if(a)if(b)c()' becomes one conjunction 'a&&b&&c()'."""
    result = js("if(a)if(b)c()\n")
    # CATCHES: the two nested ifs without else merge into a single '&&'
    # chain rather than emitting two nested if statements.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"a&&b&&c()", b"")


def test_inline_script_is_minified_inside_html(run, write):
    """An inline <script> element is minified by the JS minifier."""
    write("page.html", "<script>var a = 1;</script>\n")
    result = run(["page.html"])
    # CATCHES: the html pipeline invokes the JS minifier for inline scripts,
    # so the semicolon and spaces inside <script> disappear.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"<script>var a=1</script>", b"")


def test_inline_script_escapes_html_comment_in_string(run, write):
    """A '<!--' inside an inline script string gains a backslash."""
    write("page.html", '<script>a="<!--x"</script>')
    result = run(["page.html"])
    # CATCHES: in HTML context the sequence '<!--' inside a JS string would
    # open an HTML comment, so the minifier emits '<\\!--' instead.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'<script>a="<\\!--x"</script>', b"")


def test_inline_script_escapes_html_comment_in_regex(run, write):
    """A '<!--' inside an inline script regex gains a backslash too."""
    write("page.html", "<script>a=/<!--/</script>")
    result = run(["page.html"])
    # CATCHES: the same HTML-comment protection applies to regex literals,
    # turning '/<!--/' into '/<\\!--/' without touching the slashes.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"<script>a=/<\\!--/</script>", b"")
