"""Statement-level minification: semicolon rules, while-to-for rewriting,
dead code elimination, if/else collapsing and statement merging."""

import pytest


@pytest.mark.parametrize("source,expected", [
    ("var a=1\nif(b)c()\n", b"var a=1;b&&c()"),
    ("a=1\nfunction f(){}\n", b"a=1;function f(){}"),
    ("a=1\nclass K{}\n", b"a=1;class K{}"),
    ("a=1\nvar b=2\n", b"a=1;var b=2"),
    ("for(var i=0;i<2;i++)a()\nb()\n", b"for(var i=0;i<2;i++)a();b()"),
    ("label:for(;;)break label\nc()\n", b"label:for(;;)break label;c()"),
    ("throw a()\nb()\n", b"throw a();b()"),
    # a closing brace or a reused do-while semicolon needs no separator
    ("switch(a){case 1:b()}c()\n", b"switch(a){case 1:b()}c()"),
    ("try{a()}catch(e){b()}c()\n", b"try{a()}catch{b()}c()"),
    ("do a();while(b)\nc()\n", b"do a();while(b)c()"),
    ("function f(){}\nvar a=1\n", b"function f(){}var a=1"),
])
def test_semicolons_only_where_required(js, source, expected):
    """Separators between statements appear only when tokenisation needs."""
    result = js(source)
    # CATCHES: statements ending in ')' before 'if'/'function'/'class'/a new
    # statement need a semicolon, while '}' endings and do-while reuse none.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("while (a) { b() }\n", b"for(;a;)b()"),
    ("while (0) { b() }\n", b"for(;0;)b()"),
    ("while(a){}\n", b"for(;a;);"),
    ("while(a){b();c()}\n", b"for(;a;)b(),c()"),
    ("outer:while(a){inner:while(b){continue outer}}\n",
     b"outer:for(;a;)inner:for(;b;)continue outer"),
])
def test_while_becomes_for(js, source, expected):
    """while loops are rewritten as for loops with empty init and update."""
    result = js(source)
    # CATCHES: 'while(c)s' becomes 'for(;c;)s', a falsy constant condition is
    # NOT dead-code eliminated, and labels stay attached to the new for.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("if (1) { foo() }\n", b"foo()"),
    ("if (0) { foo() } else { bar() }\n", b"bar()"),
    ("if (a) { } else { } \n", b"a"),
    ("if(a){}else{b()}\n", b"a||b()"),
    ("if(a);else b()\n", b"a||b()"),
    ("for(;;){}\n", b"for(;;);"),
])
def test_dead_code_removal(js, source, expected):
    """Constant conditions, empty branches and empty statements disappear."""
    result = js(source)
    # CATCHES: a truthy if keeps only its body, an empty if/else collapses
    # to the bare condition expression, and empty statements vanish.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("if (a) { b() }\n", b"a&&b()"),
    ("if (a) { b() } else { c() }\n", b"a?b():c()"),
    ("if (a) { b() } else if (c) { d() }\n", b"a?b():c&&d()"),
    ("if (a) { b() } else if (c) { d() } else { e() }\n", b"a?b():c?d():e()"),
    ("if (!a) { b() } else { c() }\n", b"a?c():b()"),
    ("if(a){b()}else{c();d()}\n", b"a?b():(c(),d())"),
])
def test_if_else_collapses_to_operators(js, source, expected):
    """if/else chains compress to &&, || or conditional expressions."""
    result = js(source)
    # CATCHES: branch bodies merge into 'a&&b()' / 'a?b():c()' and a
    # multi-statement else becomes a parenthesised comma expression.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("if(a){if(b)c}else d\n", b"a?b&&c:d"),
    ("if(a){if(b)c;else d}else e\n", b"a?b?c:d:e"),
])
def test_dangling_else_is_not_ambiguously_nested(js, source, expected):
    """A nested if without else inside an else-bearing if stays unambiguous."""
    result = js(source)
    # CATCHES: naive 'if(a)if(b)c;else d' would bind the else to the inner
    # if, so the inner if is folded to 'b&&c' instead of keeping an else.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){ if(a) return b; else return c }\n",
     b"function f(){return a?b:c}"),
    ("function f(){ if(a)return;else return }\n", b"function f(){a}"),
    ("function f(){ if(a)return b;else return void c() }\n",
     b"function f(){return a?b:void c()}"),
    ("function f(){ if(a) return b; else { c() } }\n",
     b"function f(){if(a)return b;c()}"),
    ("function f(){ a(); b(); return c() }\n",
     b"function f(){return a(),b(),c()}"),
    ("function f(){ a(); throw b() }\n", b"function f(){throw a(),b()}"),
])
def test_statements_fold_into_return_and_throw(js, source, expected):
    """Preceding statements merge into return/throw as comma expressions."""
    result = js(source)
    # CATCHES: if/else returns become one conditional return, and statement
    # sequences collapse into 'return a(),b(),c()' / 'throw a(),b()'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("x=>{return 5}\n", b"e=>5"),
    ("x=>{a();b()}\n", b"e=>{a(),b()}"),
    ("x=>{if(a)return 1;else return 2}\n", b"e=>a?1:2"),
    ("x=>{throw 1}\n", b"e=>{throw 1}"),
])
def test_arrow_bodies_fold(js, source, expected):
    """Arrow function bodies shrink: a lone return loses its braces."""
    result = js(source)
    # CATCHES: '{return 5}' becomes the expression body '5' but a throw
    # statement must keep its braces since it is not an expression.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("foo(); bar();\n", b"foo(),bar()"),
    ("a\nb\nc\n", b"a,b,c"),
    ("i\n++\nj\n", b"i,++j"),
    ("if(a)b()\nc=1\n", b"a&&b(),c=0" if False else b"a&&b(),c=1"),
    ("a//c1\n//c2\nb\n", b"a,b"),
])
def test_expression_statements_merge_into_comma(js, source, expected):
    """Consecutive expression statements join into one comma expression."""
    result = js(source)
    # CATCHES: the newline between 'i' and '++j' does not leak into the
    # output even though ASI would require one there in the input.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a();for(;b;)c()\n", b"for(a();b;)c()"),
    ("a();while(b)c()\n", b"for(a();b;)c()"),
    ("x=1;while(a)b()\n", b"for(x=1;a;)b()"),
    ("if(a){b();for(;c;)d()}\n", b"if(a)for(b();c;)d()"),
    ("a();for(var i=0;i<2;i++)b()\n", b"a();for(var i=0;i<2;i++)b()"),
])
def test_statements_fold_into_loop_headers(js, source, expected):
    """A preceding expression statement moves into an empty for-init slot."""
    result = js(source)
    # CATCHES: 'a();for(;b;)c()' becomes 'for(a();b;)c()' but a for that
    # already has an initializer (even only 'var i=0') is left alone.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("{ let x = 5; print(x) }\n", b"{let e=5;print(e)}"),
    ("function f(){ var x = 5 }\n", b"function f(){var e=5}"),
])
def test_side_effect_free_declarations_are_dropped(js, source, expected):
    """A block whose only content is an unused lexical declaration goes."""
    result = js(source)
    # CATCHES: an unused 'let' inside a block erases the whole block, but a
    # 'var' declaration (function-scoped, hoisted) is always kept.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_unused_let_block_erased_entirely(js):
    """A block holding only an unused let declaration vanishes completely."""
    result = js("{ let x = 5 }\n")
    # CATCHES: neither the braces nor the declaration survive; the output is
    # byte-empty rather than an empty block '{}'.
    assert (result.returncode, result.stdout, result.stderr) == (0, b"", b"")
    control = js("{ let x = 5 }\nprint(1)\n")
    # CATCHES: the same dead block followed by live code leaves only the live
    # statement, so the block is truly erased and not merely blanked.
    assert (control.returncode, control.stdout, control.stderr) == (
        0, b"print(1)", b"")


def test_empty_statements_and_blocks_vanish(js):
    """Lone ';' and '{}' produce nothing and never break merging."""
    for source in [";\n", "{}\n"]:
        result = js(source)
        # CATCHES: an empty statement or bare block is not echoed and does
        # not leave a stray semicolon in the output.
        assert (result.returncode, result.stdout, result.stderr) == (0, b"", b"")
    trailing = js(";var q=1\n")
    assert (trailing.returncode, trailing.stdout, trailing.stderr) == (
        0, b"var q=1", b"")
    between = js("a=1;;b=2\n")
    # CATCHES: an empty statement between two assignments is dropped and the
    # surrounding expression statements still merge into one comma expression.
    assert (between.returncode, between.stdout, between.stderr) == (
        0, b"a=1,b=2", b"")


def test_empty_import_list_is_dropped(js):
    """'import {} from ...' with no bindings disappears entirely."""
    result = js("import {} from 'path'\n")
    # CATCHES: an import with an empty clause list is removed rather than
    # emitted as 'import{}from"path"'.
    assert (result.returncode, result.stdout, result.stderr) == (0, b"", b"")
    control = js("import {} from 'path';a=1\n")
    # CATCHES: subsequent statements survive the dropped import untouched.
    assert (control.returncode, control.stdout, control.stderr) == (
        0, b"a=1", b"")


@pytest.mark.parametrize("source,expected", [
    ("for (var i = 0; i < 10; i++) { print(i) }\n",
     b"for(var i=0;i<10;i++)print(i)"),
    ("for(let i=0;i<3;i++)print(i)\n", b"for(let e=0;e<3;e++)print(e)"),
    ("for (var i = 0, j = 1; i < j; i++) {}\n", b"for(var i=0,j=1;i<j;i++);"),
    ("for (const x of arr) { print(x) }\n", b"for(const e of arr)print(e)"),
    ("for (const k in obj) { print(k) }\n", b"for(const e in obj)print(e)"),
    ("for(;;){break}\n", b"for(;;)break"),
    ("var a=1\nwhile(b)c()\n", b"for(var a=1;b;)c()"),
])
def test_loop_headers_absorb_surrounding_code(js, source, expected):
    """Loop bodies drop their braces and var decls move into the header."""
    result = js(source)
    # CATCHES: a preceding 'var a=1' is folded into the for-init of the
    # rewritten while loop, and single-statement bodies lose their braces.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_do_while_and_label_formatting(js):
    """do-while keeps its shape; labels keep their colon and space."""
    result = js("do { x() } while (a)\nlabel: for(;;) { break label }\n")
    # CATCHES: 'do x();while(a)' keeps the mandatory semicolon and the label
    # keeps 'label:for(;;)break label' with no space after the colon.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"do x();while(a)label:for(;;)break label", b"")


def test_switch_layout(js):
    """Switch statements keep case/default labels and semicolon rules."""
    result = js("switch (a) { case 1: b(); break; default: c() }\n")
    # CATCHES: 'case 1:' needs the space after 'case', and 'break' still
    # gets a semicolon before 'default' inside the block.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"switch(a){case 1:b();break;default:c()}", b"")


@pytest.mark.parametrize("source,expected", [
    ("a+++b\n", b"a+++b"),
    ("a++ +b\n", b"a+++b"),
    ("a-- -b\n", b"a---b"),
    ("a-- > b\n", b"a-- >b"),
    ("a-- < b\n", b"a--<b"),
    ("a - --b\n", b"a- --b"),
    ("+ +x\n", b"+ +x"),
    ("- -x\n", b"- -x"),
    ("+ ++x\n", b"+ ++x"),
])
def test_tokenisation_hazards_keep_spaces(js, source, expected):
    """Adjacent operator tokens never merge into a different token."""
    result = js(source)
    # CATCHES: 'a-- >b' and 'a- --b' must keep a space exactly where the
    # merged spelling ('a-->b', 'a---b') would change the token stream,
    # while 'a--<b' needs none because '<-' is not an operator.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a\n(b)\n", b"a(b)"),
    ("a\n[0]\n", b"a[0]"),
    ("var x=function(){}\n(function(){})()\n",
     b"var x=function(){}(function(){})()"),
])
def test_statements_on_separate_lines_join(js, source, expected):
    """Newline-separated statements can be merged without a separator."""
    result = js(source)
    # CATCHES: the program joins 'a' and '(b)' into the call 'a(b)' (and
    # 'a' with '[0]' into a member access) rather than emitting 'a,b'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("import x from 'path'\n", b'import x from"path"'),
    ("import 'path'\n", b'import"path"'),
    ("import * as b from 'path'\n", b'import*as b from"path"'),
    ("import {a as b, c} from 'path'\n", b'import{a as b,c}from"path"'),
    ("export * from 'path'\n", b'export*from"path"'),
    ("export {a as b, c}\n", b"export{a as b,c}"),
    ("export var a = b\n", b"export var a=b"),
    ("export default 5\n", b"export default 5"),
    ("export default function a(){};c=d\n",
     b"export default function(){}c=d"),
])
def test_module_syntax_layout(js, source, expected):
    """Import/export statements keep their keyword spacing exactly."""
    result = js(source)
    # CATCHES: 'from' and 'as' keep their mandatory spaces, and a named
    # default function loses its name.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_realistic_snippet_end_to_end(js):
    """A small realistic function survives with all optimisations combined."""
    result = js(
        "function init(opts) {\n"
        "  var defaults = { debug: false, retries: 3 };\n"
        "  var config = Object.assign({}, defaults, opts || {});\n"
        "  if (config.debug === true) { console.log('starting'); }\n"
        "  while (config.retries-- > 0) { attempt(); }\n"
        "  return config;\n"
        "}\n"
        "init({debug: true});\n")
    # CATCHES: the if folds into the for-init as 'a&&b', the while becomes a
    # for, both var decls merge, and the debug literal becomes !1/!0.
    assert (result.returncode, result.stdout, result.stderr) == (
        0,
        b'function init(e){var n={debug:!1,retries:3},'
        b't=Object.assign({},n,e||{});'
        b'for(t.debug===!0&&console.log("starting");t.retries-- >0;)attempt();'
        b'return t}init({debug:!0})',
        b"")
