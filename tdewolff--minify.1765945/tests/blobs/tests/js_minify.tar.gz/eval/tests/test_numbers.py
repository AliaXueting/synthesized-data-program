"""Numeric literal minification: base conversion, exponent notation,
underscore stripping, BigInt suffixes and --js-precision rounding."""

import pytest


@pytest.mark.parametrize("source,expected", [
    ("a(1.0, 1000, 1e10, 1e-10)\n", b"a(1,1e3,1e10,1e-10)"),
    ("a(1_2.0_3)\n", b"a(12.03)"),
    ("a(5_000)\n", b"a(5e3)"),
    ("a(0b1001, 0o11, 0x0D)\n", b"a(9,9,13)"),
    ("a(0b11, 0b100, 0x1FF, 0o777, 255, 256)\n", b"a(3,4,511,511,255,256)"),
    ("a(123456, 1234567, 0.000001, 1e21, 1e-7, .5, 5.)\n",
     b"a(123456,1234567,1e-6,1e21,1e-7,.5,5)"),
    ("a(1e3, 10000, 100000, 1000000, 1e7)\n", b"a(1e3,1e4,1e5,1e6,1e7)"),
    ("a(0.5, .5, 5e-1, 0.05, 5e-2)\n", b"a(.5,.5,.5,.05,.05)"),
    ("a(987654321, 9876543210)\n", b"a(987654321,9876543210)"),
    ("a(0.0001, 0.00001)\n", b"a(1e-4,1e-5)"),
    ("a(9007199254740993)\n", b"a(9007199254740993)"),
    ("a(1.5e3, 15e2)\n", b"a(1500,1500)"),
])
def test_number_notation_shortening(js, source, expected):
    """Numbers are re-spelled in whichever notation is shortest."""
    result = js(source)
    # CATCHES: '1000' becomes '1e3' but '123456' stays decimal, binary/octal/
    # hex literals become decimal only when that is not longer, '.5' keeps
    # its leading-zero-free form, and '5.' loses its dot.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a(123n, 0n, 12n)\n", b"a(123n,0n,12n)"),
    ("a(5_000n, 0b10_01n, 0o11n, 0x0dn)\n", b"a(5000n,9n,9n,13n)"),
    ("a(0x53DCAA254718n, 0xFFn, 0b101n)\n", b"a(0x53DCAA254718n,255n,5n)"),
])
def test_bigint_suffix_is_preserved(js, source, expected):
    """BigInt literals keep their trailing 'n' through every rewrite."""
    result = js(source)
    # CATCHES: base conversion and underscore stripping still apply, and a
    # huge hex BigInt stays hexadecimal because decimal would be longer.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_legacy_octal_is_a_parse_error(js):
    """Old-style 0777 octal literals are rejected by the parser."""
    result = js("a(0777)\n")
    # CATCHES: legacy octal numbers abort with 'cannot minify' and exit
    # code 1 rather than being converted silently.
    assert result.returncode == 1
    assert result.stdout == b"a(0777)\n"
    assert result.stderr == (
        b"ERROR: cannot minify -: legacy octal numbers are not supported"
        b" in arguments on line 1 and column 3\n"
        b"    1: a(0777)\n"
        b"         ^\n")


@pytest.mark.parametrize("precision,source,expected", [
    (3, "a(3.14159265358979, 1234.5678, 0.001234)\n", b"a(3.14,1230,.00123)"),
    (2, "a(3.14159, 2.71828, 1.5, 123456)\n", b"a(3.1,2.7,1.5,12e4)"),
    (1, "a(3.14159265358979, 999, 1234)\n", b"a(3,1e3,1e3)"),
    (10, "a(3.14159265358979)\n", b"a(3.141592654)"),
    (4, "a(123456789, 0.000123456, 99999)\n", b"a(1235e5,1235e-7,99999)"),
    (2, "a(9.99, 9.95, 0.005)\n", b"a(10,10,.005)"),
    (6, "a(1234567890123)\n", b"a(123457e7)"),
])
def test_js_precision_rounds_significant_digits(js, precision, source, expected):
    """--js-precision keeps only N significant digits."""
    result = js(source, ["--js-precision", precision])
    # CATCHES: rounding happens on the value before notation choice, so
    # 1234.5678 at precision 3 is '1230', 999 at precision 1 is '1e3' and
    # 9.99 at precision 2 becomes the integer '10'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("precision", [0, -1])
def test_precision_zero_or_negative_keeps_all_digits(js, precision):
    """A non-positive --js-precision disables number shortening."""
    result = js("a(3.14159265358979)\n", ["--js-precision", precision])
    # CATCHES: only a positive precision triggers rounding; 0 and negative
    # values leave every digit of the literal untouched.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"a(3.14159265358979)", b"")


def test_invalid_precision_is_a_usage_error(run):
    """A non-integer --js-precision aborts argument parsing."""
    result = run(["--type", "js", "--js-precision", "abc"], stdin="a(1)\n")
    # CATCHES: the flag parser rejects 'abc' with exit code 2, a usage dump
    # on stdout and a specific complaint on stderr.
    assert result.returncode == 2
    assert result.stderr == b"option --js-precision: invalid integer 'abc'\n\n"
    assert "--js-precision int" in result.out
