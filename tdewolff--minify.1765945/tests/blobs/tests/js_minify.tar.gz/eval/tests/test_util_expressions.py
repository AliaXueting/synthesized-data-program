"""Expression-level rewrites driven by js/util.go: conditional expression
folding, boolean inversion, nullish/optional-chaining conversion, string
escape decoding, regex class escaping and number base length limits."""

import pytest


@pytest.mark.parametrize("source,expected", [
    ("a=!b?x:y\n", b"a=b?y:x"),
    ("a=b?b:c\n", b"a=b||c"),
    ("a=b?c:b\n", b"a=b&&c"),
    ("a=b?c:c\n", b"a=(b,c)"),
    ("a=!!b?x:y\n", b"a=!!b?x:y"),
    ("x=a?b?c:d:d\n", b"x=a&&b?c:d"),
    ("x=a?!0:!1\n", b"x=!!a"),
    ("x=a?f(1):f(2)\n", b"x=f(a?1:2)"),
    ("x=a?f(1):g(2)\n", b"x=a?f(1):g(2)"),
    ("x=(a,b)?c:d\n", b"x=(a,b)?c:d"),
    ("(a,b)?c:d\n", b"a,b?c:d"),
    ("(a,b==c)?d:e\n", b"a,b==c?d:e"),
    ("(a,b=c)?d:e\n", b"(a,b=c)?d:e"),
    ("x=(a,b==c)?d:e\n", b"x=(a,b==c)?d:e"),
    ("x=(a,b)?b:c\n", b"x=(a,b)||c"),
    ("x=(a=b)?a:c\n", b"x=(a=b)||c"),
])
def test_conditional_expression_folding(js, source, expected):
    """Conditional expressions fold to ||, &&, comma or inverted branches."""
    result = js(source)
    # CATCHES: 'b?b:c' becomes 'b||c', 'b?c:b' becomes 'b&&c', equal bodies
    # become '(b,c)', a leading '!' swaps the branches, and a comma condition
    # keeps its group unless the whole conditional sits at statement level.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a=b?c:!0\n", b"a=!b||c"),
    ("a=b?!0:c\n", b"a=!!b||c"),
    ("a=b?c:!1\n", b"a=!!b&&c"),
    ("a=b?!1:c\n", b"a=!b&&c"),
])
def test_conditional_with_boolean_literal_branch(js, source, expected):
    """A !0/!1 branch turns the conditional into || or && on the condition."""
    result = js(source)
    # CATCHES: 'b?c:!0' becomes '!b||c' (the condition is negated, not the
    # body), while 'b?!1:c' becomes '!b&&c' with a single negation.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("x=!(a==b)\n", b"x=a!=b"),
    ("x=!(a===b)\n", b"x=a!==b"),
    ("x=!(a!=b)\n", b"x=a==b"),
    ("x=!(a||b)\n", b"x=!a&&!b"),
    ("x=!(a&&b)\n", b"x=!a||!b"),
    ("x=!(a==0||b==0)\n", b"x=a!=0&&b!=0"),
    ("x=!(a==0&&b==0)\n", b"x=a!=0||b!=0"),
    ("x=!(a<b)\n", b"x=!(a<b)"),
    ("x=!!(a<b)\n", b"x=a<b"),
    ("x=!!a\n", b"x=!!a"),
])
def test_unary_not_inversion(js, source, expected):
    """De Morgan rewrites: !(a||b) becomes !a&&!b, == flips to !=."""
    result = js(source)
    # CATCHES: negation distributes over &&/|| and inverts equality
    # operators, but a comparison like 'a<b' is never rewritten and a plain
    # double negation of a non-boolean stays intact.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("x=a==null?b:a\n", b"x=a??b"),
    ("x=a!=null?a:b\n", b"x=a??b"),
    ("x=a===null||a===undefined?b:a\n", b"x=a??b"),
    ("x=a!==null&&a!==undefined?a:b\n", b"x=a??b"),
    ("x=null===a||undefined===a?b:a\n", b"x=a??b"),
    ("x=a==null?undefined:a()\n", b"x=a?.()"),
    ("x=a!=null?a():undefined\n", b"x=a?.()"),
    ("x=a==null?undefined:a[0]\n", b"x=a?.[0]"),
    ("x=a==null?undefined:a.b\n", b"x=a?.b"),
    ("x=a!=null?a.b:undefined\n", b"x=a?.b"),
    ("x=a==null?undefined:a`t`\n", b"x=a?.`t`"),
])
def test_nullish_and_optional_chaining_rewrites(js, source, expected):
    """null-comparison conditionals become ?? or optional chains."""
    result = js(source)
    # CATCHES: 'a==null?b:a' becomes 'a??b' in every spelling (===, ||,
    # reversed operands, negated), and an undefined branch converts the
    # tested variable into '?.()', '?.[0]', '?.b' or even '?.`t`'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("x=a==null?undefined:a()\n", b"x=a==null?0[0]:a()"),
    ("x=a==null?undefined:a.b\n", b"x=a==null?0[0]:a.b"),
    ("x=a==null?b:a\n", b"x=a==null?b:a"),
    ("x=a!=null?a():undefined\n", b"x=a!=null?a():0[0]"),
])
def test_nullish_rewrites_are_gated_on_2020(js, source, expected):
    """--js-version below 2020 keeps the plain conditional expression."""
    result = js(source, flags=["--js-version", "2019"])
    # CATCHES: with ES2019 the ?? / ?. rewrites are disabled and 'undefined'
    # in the dead branch still shortens to '0[0]'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("x=(a??b)||c\n", b"x=(a??b)||c"),
    ("x=(a??b)&&c\n", b"x=(a??b)&&c"),
    ("x=a??(b||c)\n", b"x=a??(b||c)"),
    ("x=a??b??c\n", b"x=a??b??c"),
    ("if(a??b)c()\n", b"(a??b)&&c()"),
])
def test_nullish_grouping_with_logical_operators(js, source, expected):
    """?? never merges unparenthesised with || or &&."""
    result = js(source)
    # CATCHES: mixing '??' with '&&'/'||' requires the parentheses to stay
    # (it is a syntax error otherwise), and an if-condition of 'a??b' gains
    # parentheses when folded into '(a??b)&&c()'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a=\"str\"===typeof b\n", b'a="str"==typeof b'),
    ("a=\"str\"!==typeof b\n", b'a="str"!=typeof b'),
    ("a=typeof b===\"str\"\n", b'a=typeof b=="str"'),
    ("a=typeof b!==\"str\"\n", b'a=typeof b!="str"'),
])
def test_typeof_comparison_loses_one_equals_both_sides(js, source, expected):
    """===/!== next to typeof become ==/!= whichever side typeof is on."""
    result = js(source)
    # CATCHES: the weaker operator is chosen with typeof on either the left
    # or the right of the comparison, including the !== variant.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("x=a===null||a===undefined\n", b"x=a==null"),
    ("x=a!==null&&a!==undefined\n", b"x=a!=null"),
    ("x=null===a||undefined===a\n", b"x=a==null"),
    ("x=a===undefined||a===null\n", b"x=a==null"),
])
def test_null_undefined_disjunction_collapses(js, source, expected):
    """'a===null||a===undefined' collapses to a single loose comparison."""
    result = js(source)
    # CATCHES: both null and undefined checks merge into one 'a==null'
    # regardless of operand order, and the && form gives 'a!=null'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a=b&&!0\n", b"a=b"),
    ("a=b||!1\n", b"a=b"),
    ("a=!0&&b\n", b"a=b"),
    ("a=!1||b\n", b"a=b"),
    ("a=b&&!1\n", b"a=b&&!1"),
    ("a=b||!0\n", b"a=b||!0"),
])
def test_and_or_with_boolean_literals(js, source, expected):
    """A redundant !0/!1 operand of &&/|| is dropped for literals only."""
    result = js(source)
    # CATCHES: 'b&&!0' loses the literal but 'b&&!1' is kept verbatim
    # because the variable operand is assumed to have side effects.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("if(\"\")a();else b()\n", b"a()"),
    ("if(\"x\")a();else b()\n", b"a()"),
    ("if(null)a();else b()\n", b"b()"),
    ("if(false)a();else b()\n", b"b()"),
    ("if(0.0)a();else b()\n", b"b()"),
    ("if(0e5)a();else b()\n", b"b()"),
    ("if(0x0)a();else b()\n", b"b()"),
    ("if(0n)a();else b()\n", b"b()"),
    ("if(1e0)a();else b()\n", b"a()"),
    ("if(!!0)a();else b()\n", b"b()"),
    ("if(NaN)a();else b()\n", b"if(!NaN)b()"),
    ("if(undefined)a();else b()\n", b"if(!0[0])b()"),
])
def test_constant_condition_folding(js, source, expected):
    """Constant if-conditions select a branch or get negated in place."""
    result = js(source)
    # CATCHES: literal conditions are resolved at minify time (even '0n',
    # '0x0' and '!!0'), while the NaN and undefined conditions are kept but
    # negated because a bare identifier may have side effects.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("cond,expected", [
    ("a.b", b"a.b"),
    ("a[0]", b"a[0]"),
    ("[a]", b"[a]"),
    ("({a:b})", b"({a:b})"),
    ("`t${a}`", b"`t${a}`"),
    ("tag`t`", b"tag`t`"),
    ("a?b:c", b"a?b:c"),
    ("(a,b)", b"a,b"),
    ("new X()", b"new X"),
    ("delete a.x", b"delete a.x"),
    ("a++", b"a++"),
    ("-a", b"-a"),
    ("a=b", b"a=b"),
])
def test_side_effect_expressions_survive_empty_if_else(js, cond, expected):
    """An empty if/else keeps only its condition, unless it is inert."""
    result = js("if(%s){}else{}\n" % cond)
    # CATCHES: member access, arrays, objects, templates, calls via 'new',
    # delete, ++ and assignments are all considered observable, so the bare
    # condition is kept as the whole statement.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("cond", ["a==b", "1", "(1)", "(()=>a)"])
def test_inert_conditions_discard_empty_if_else(js, cond):
    """An empty if/else with an inert condition disappears entirely."""
    result = js("if(%s){}else{}\n" % cond)
    # CATCHES: comparisons and literals have no side effects, so the entire
    # statement is dropped instead of leaving the condition behind.
    assert (result.returncode, result.stdout, result.stderr) == (0, b"", b"")
    control = js("if(%s){}else{}\nprint(1)\n" % cond)
    # CATCHES: a following statement proves the drop is a real rewrite and
    # not a silently failing run.
    assert (control.returncode, control.stdout, control.stderr) == (
        0, b"print(1)", b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){a=new.target?b:c}\n", b"function f(){a=new.target?b:c}"),
    ("a=import.meta?b:c\n", b"a=import.meta?b:c"),
    ("function*g(){x=(yield a)?b:c}\n", b"function*g(){x=(yield a)?b:c}"),
    ("x=tag`a${b}c`?d:e\n", b"x=tag`a${b}c`?d:e"),
    ("x=(a,b)()?c:d\n", b"x=(a,b)()?c:d"),
    ("(a?b:c)?d:e\n", b"(a?b:c)?d:e"),
    ("x=a?(b,c):d\n", b"x=a?(b,c):d"),
    ("x=(-a)**b\n", b"x=(-a)**b"),
    ("x=new a?b:c\n", b"x=new a?b:c"),
])
def test_precedence_sensitive_shapes_stay_grouped(js, source, expected):
    """Exotic operands keep their grouping around the conditional."""
    result = js(source)
    # CATCHES: new.target, import.meta, yield, tagged templates, comma
    # function names and nested conditionals all keep their parentheses, and
    # 'new a?b:c' stays ungrouped because 'new a' binds tighter than '?'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_unparenthesised_unary_exponent_is_a_parse_error(js):
    """'-a**b' is rejected exactly like a hand-written syntax error."""
    result = js("x=-a**b\n")
    # CATCHES: the minifier's parser agrees with ECMAScript that unary minus
    # before '**' must be parenthesised, and reports the '**' position.
    assert result.returncode == 1
    assert result.stdout == b"x=-a**b\n"
    assert result.stderr == (
        b"ERROR: cannot minify -: unexpected ** in expression"
        b" on line 1 and column 5\n"
        b"    1: x=-a**b\n"
        b"           ^\n")


@pytest.mark.parametrize("source,expected", [
    ("a('\\12')\n", b"a(`\n`)"),
    ("a('x\\12y')\n", b"a(`x\ny`)"),
    ("a('\\42')\n", b"a('\"')"),
    ("a('\\47')\n", b"a(\"'\")"),
    ("a('\\140')\n", b"a(\"`\")"),
    ("a('\\101')\n", b"a(\"A\")"),
    ("a('\\01')\n", b"a(\"\x01\")"),
])
def test_octal_escapes_are_decoded_and_counted(js, source, expected):
    """Legacy octal escapes decode, and \\12 tips the quote choice to `."""
    result = js(source)
    # CATCHES: '\\42' becomes a plain '\"' inside single quotes, '\\140' a
    # literal backtick inside double quotes, while '\\12' (a newline) makes
    # the whole string a template literal with a real line break.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a('\\x22')\n", b"a('\"')"),
    ("a('\\x27')\n", b"a(\"'\")"),
    ("a('\\x60')\n", b"a(\"`\")"),
    ("a('\\u0022')\n", b"a('\"')"),
    ("a('\\u0027')\n", b"a(\"'\")"),
    ("a('\\u0060')\n", b"a(\"`\")"),
    ("a('\\u{22}')\n", b"a('\"')"),
    ("a('\\u{27}')\n", b"a(\"'\")"),
    ("a('\\u{60}')\n", b"a(\"`\")"),
])
def test_escaped_quotes_drive_quote_selection(js, source, expected):
    """\\x/\\u escapes of quote characters influence the chosen quote."""
    result = js(source)
    # CATCHES: an escaped double quote switches the string to single quotes
    # and vice versa, for every escape spelling including '\\u{...}'.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a('\\u{0}')\n", b"a(\"\\x00\")"),
    ("a('\\u{7}')\n", b"a(\"\x07\")"),
    ("a('\\u{1F600}')\n", 'a("😀")'.encode()),
    ("a('\\x001')\n", b"a(\"\\x001\")"),
    ("a('ab\\\ncd')\n", b"a(\"abcd\")"),
    ("a('\\f')\n", b"a(\"\x0c\")"),
    ("a('\\v')\n", b"a(\"\x0b\")"),
    ("a('\\b')\n", b"a(\"\x08\")"),
])
def test_unicode_and_control_escapes(js, source, expected):
    r"""Code point escapes decode to raw bytes except NUL and octal hazards."""
    result = js(source)
    # CATCHES: '\u{0}' stays a four-byte '\x00' escape, '\x00' followed by a
    # digit is not turned into '\0' (octal hazard), a backslash-newline line
    # continuation vanishes, and \f/\v/\b decode to single control bytes.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_template_literal_decodes_newline_escape(js):
    r"""Inside a template literal a \n escape becomes a real newline."""
    result = js("a(`x\\ny`)\n")
    # CATCHES: the template keeps its backticks but the two-character '\n'
    # escape is replaced by one literal line break byte.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"a(`x\ny`)", b"")


def test_dollar_brace_is_escaped_when_switching_to_backticks(js):
    """A newline-rich string becomes a template with '\\${' escaped."""
    result = js("a('p\\nq\\nr${x}')\n")
    # CATCHES: two newlines make the backtick quote shorter, and every
    # literal '${' gained inside the template is escaped as '\${' so it
    # cannot start an interpolation.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"a(`p\nq\nr\\${x}`)", b"")


def test_string_concatenation_merges_at_most_51_at_a_time(js):
    """A chain of 52 string literals merges only its first 51 members."""
    source = "a(" + "+".join("'s%d'" % i for i in range(52)) + ")\n"
    result = js(source)
    # CATCHES: the merge recursion is capped, so the 52nd literal 's51'
    # remains a separate '+' concatenation after the first 51 join.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b'a("' + b"".join(b"s%d" % i for i in range(51)) + b'"+"s51")', b"")
    shorter = js("a(" + "+".join("'s%d'" % i for i in range(51)) + ")\n")
    # CATCHES: with exactly 51 literals the whole chain still merges into a
    # single string, pinning the cap's exact boundary.
    assert (shorter.returncode, shorter.stdout, shorter.stderr) == (
        0, b'a("' + b"".join(b"s%d" % i for i in range(51)) + b'")', b"")


@pytest.mark.parametrize("source,expected", [
    ("a(/[a\\-b]/)\n", b"a(/[a\\-b]/)"),
    ("a(/[\\-a]/)\n", b"a(/[-a]/)"),
    ("a(/[a\\-]/)\n", b"a(/[a-]/)"),
    ("a(/[\\-]/)\n", b"a(/[-]/)"),
    ("a(/[\\-a-z]/)\n", b"a(/[-a-z]/)"),
    ("a(/[a\\-z]/)\n", b"a(/[a\\-z]/)"),
    ("a(/[a\\-9]/)\n", b"a(/[a\\-9]/)"),
    ("a(/[\\^a]/)\n", b"a(/[\\^a]/)"),
    ("a(/[^\\^a]/)\n", b"a(/[^\\^a]/)"),
    ("a(/[\\d]/)\n", b"a(/[\\d]/)"),
    ("a(/[\\b]/)\n", b"a(/[\\b]/)"),
    ("a(/[]/)\n", b"a(/[]/)"),
    ("a(/[^]/)\n", b"a(/[^]/)"),
])
def test_regex_class_dash_and_caret_escaping(js, source, expected):
    """Escaped dashes lose the backslash only outside range positions."""
    result = js(source)
    # CATCHES: '[\\-a]' becomes '[-a]' and '[a\\-]' becomes '[a-]' where a
    # bare dash is literal, but '[a\\-b]' keeps the escape so it cannot turn
    # into a range, and a leading '\\^' always stays escaped.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a(0b" + "1" * 63 + ")\n", b"a(9223372036854775807)"),
    ("a(0b" + "1" * 64 + ")\n", b"a(0b" + b"1" * 64 + b")"),
    ("a(0o" + "7" * 21 + ")\n", b"a(9223372036854775807)"),
    ("a(0o" + "7" * 22 + ")\n", b"a(0o" + b"7" * 22 + b")"),
    ("a(0xFFFFFFFFFFFF)\n", b"a(0xFFFFFFFFFFFF)"),
    ("a(0xFFFFFFFFFF)\n", b"a(0xFFFFFFFFFF)"),
    ("a(0xE000000000)\n", b"a(0xE000000000)"),
    ("a(0xe000000000)\n", b"a(0xe000000000)"),
    ("a(0xD000000000)\n", b"a(893353197568)"),
    ("a(0xd000000000)\n", b"a(893353197568)"),
    ("a(0xC000000000)\n", b"a(824633720832)"),
    ("a(0xFFFFFFFFFFn)\n", b"a(0xFFFFFFFFFFn)"),
    ("a(0b" + "1" * 66 + "n)\n", b"a(0b" + b"1" * 66 + b"n)"),
    ("a(0o" + "7" * 24 + "n)\n", b"a(0o" + b"7" * 24 + b"n)"),
])
def test_number_base_conversion_length_limits(js, source, expected):
    """Very long binary/octal/hex literals stay in their original base."""
    result = js(source)
    # CATCHES: 63 binary ones become decimal 9223372036854775807 but 64 stay
    # binary; hex keeps its spelling only when the decimal form would not be
    # shorter (leading E/F or more than 10 digits), BigInt suffix included.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")
