"""Identifier handling: short-name generation, scope-aware collisions,
with-statement opt-out, var hoisting/merging and destructuring shorthand."""

import pytest


def test_function_locals_get_frequency_ordered_names(js):
    """Locals are renamed to the shortest available generated names."""
    result = js("function f(argOne, argTwo) { return argOne + argTwo }\n")
    # CATCHES: generated names follow a character-frequency order (e,t,n,...)
    # rather than the alphabet, so the first two names are 'e' and 't'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"function f(e,t){return e+t}", b"")


@pytest.mark.parametrize("source,expected", [
    ("function f() { var alpha = 1; return alpha } f();\n",
     b"function f(){var e=1;return e}f()"),
    ("x => x + 1\n", b"e=>e+1"),
    ("(x, y) => x * y\n", b"(e,t)=>e*t"),
    ("for(const x of arr)print(x)\n", b"for(const e of arr)print(e)"),
    ("try { x() } catch (err) { print(err) }\n", b"try{x()}catch(e){print(e)}"),
    ("function outer(){ function inner(longName) { return longName } return inner }\n",
     b"function outer(){function e(e){return e}return e}"),
    ("function f(){ let alpha = 1; { let beta = 2; print(alpha, beta) } }\n",
     b"function f(){let e=1;{let t=2;print(e,t)}}"),
    ("function f(){ const alpha = 1; print(alpha) }\n",
     b"function f(){const e=1;print(e)}"),
    ("class Foo { #myField = 1; get() { return this.#myField } }\n",
     b"class Foo{#e=1;get(){return this.#e}}"),
    ("class A{get #a(){} set #a(x){}}\n", b"class A{get#e(){}set#e(e){}}"),
])
def test_renaming_across_scope_kinds(js, source, expected):
    """Vars, params, catch bindings and private fields are all renamed."""
    result = js(source)
    # CATCHES: renaming applies to function/arrow params, catch bindings,
    # class private fields (keeping the '#') and nested function decls alike.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_top_level_declarations_are_never_renamed(js):
    """Program-level vars keep their names (other scripts may use them)."""
    result = js("var alpha = 1, beta = alpha + 1; print(alpha, beta);\n")
    # CATCHES: only function-scoped identifiers are renamed; top-level var
    # declarations survive with their original spellings.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"var alpha=1,beta=alpha+1;print(alpha,beta)", b"")


def test_generated_name_skips_global_used_in_scope(js):
    """A name already used as an undeclared global is not generated."""
    result = js("function f(){ var name; print(e, name) }\n")
    # CATCHES: 'e' is read as a global inside the function, so the local is
    # renamed to the next candidate 't' instead of shadowing it.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"function f(){var t;print(e,t)}", b"")


def test_rename_order_follows_use_counts(js):
    """The most-used declaration is renamed first."""
    result = js("function f(){ var a,b,c,d,e,f,g,h,name; print(name) }\n")
    # CATCHES: declarations are sorted by use count before naming, so the
    # only used var ('name') receives 'e' and the unused ones follow.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"function f(){var e,t,n,s,o,i,a,r,c;print(e)}", b"")


def test_names_roll_over_to_two_characters(js):
    """After 54 one-character names, two-character names are generated."""
    names = ",".join("v%02d" % i for i in range(60))
    uses = ",".join("v%02d" % i for i in range(60))
    result = js("function f(){var %s;%s}f()\n" % (names, uses))
    # CATCHES: the 55th name wraps to 'ee' and the ordering of the
    # one-character alphabet (e,t,n,s,o,...,$,W,U,K,q,Y,G,X,Q,Z,J) is fixed.
    assert (result.returncode, result.stderr) == (0, b"")
    assert result.stdout.startswith(
        b"function f(){var e,t,n,s,o,i,a,r,c,l,d,u,h,m,f,p,g,v,b,j,y,_,w,"
        b"O,x,C,E,k,A,S,M,F,T,z,D,N,L,R,P,H,I,B,V,$,W,U,K,q,Y,G,X,Q,Z,J,")
    assert result.stdout.endswith(b"ee,te,ne,se,oe,ie}f()")


def test_with_statement_disables_renaming_for_its_function(js):
    """A with() anywhere in a function turns off renaming in its scopes."""
    result = js("function f(){ var name; with(z){ name } }\n")
    # CATCHES: inside a scope using 'with' identifiers cannot be renamed
    # safely, so 'name' keeps its original spelling including nested funcs.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"function f(){var name;with(z)name}", b"")
    nested = js("function f(){ var name; with(z){ function g(){ name } } }\n")
    assert (nested.returncode, nested.stdout, nested.stderr) == (
        0, b"function f(){var name;with(z)function g(){name}}", b"")


def test_with_at_top_level_keeps_var_unrenamed(js):
    """A top-level with() block still prints its var declaration."""
    result = js("with(z){var q=1}\n")
    # CATCHES: the with body's single-statement form drops the braces while
    # the hoisted var declaration stays inside the with body.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"with(z)var q=1", b"")


@pytest.mark.parametrize("source,expected", [
    ("var a; var b;\n", b"var a,b"),
    ("var a=1;a=2;\n", b"var a=1,a=2"),
    ("var q; q = 5; print(q);\n", b"var q=5;print(q)"),
    ("var a={};var b=[];var c=function(){};\n", b"var a={},b=[],c=function(){}"),
    ("let a = 5\nlet b = 6\n", b"let a=5,b=6"),
    ("function f(){ var x; x = 1; print(x) }\n", b"function f(){var e=1;print(e)}"),
    ("function f(){ var x = 1; var y = 2; var z = 3; print(x,y,z) }\n",
     b"function f(){var e=1,t=2,n=3;print(e,t,n)}"),
])
def test_var_declarations_merge_and_fold_assignments(js, source, expected):
    """Sequential var decls merge; plain assignments fold into them."""
    result = js(source)
    # CATCHES: 'var a;var b' becomes 'var a,b' and 'var q;q=5' folds the
    # assignment into the declaration, both at top level and in functions.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("var a=0;var b=1,c=[...b],[d]=1;\n", b"var[d]=1,a=0,b=1,c=[...b]"),
    ("for(var a=0;;){var b=5;for(var c=0;;);}\n",
     b"for(var c,b,a=0;;)for(b=5,c=0;;);"),
    ("var c=\"\";for(let i=0;;);var d=\"\";for(let i=0;;);\n",
     b'var d,c="";for(let e=0;;);d="";for(let e=0;;);'),
])
def test_hoisting_rearranges_declaration_order(js, source, expected):
    """Hoisted var decls are reordered and merged for smaller output."""
    result = js(source)
    # CATCHES: declarations move to the hoist target even when that puts a
    # destructuring binding first or pulls loop vars out of their loops.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_hoisting_inside_nested_block(js):
    """Repeated var decls inside one block collapse into one declaration."""
    result = js(
        "function transform(){{var aaaa=[];for(var b=0;;){}"
        "for(var b in aaaa){}var aaaa=[];for(var b=0;;){}}}\n")
    # CATCHES: later 'var b' uses reference the single hoisted declaration,
    # so only the first mention keeps the 'var' keyword.
    assert (result.returncode, result.stdout, result.stderr) == (
        0,
        b"function transform(){{for(var e=[],t=0;;);for(t in e);"
        b"for(e=[],t=0;;);}}",
        b"")


@pytest.mark.parametrize("source,expected", [
    ("function a(){ var name; return {name} }\n",
     b"function a(){var e;return{name:e}}"),
    ("function f(){ var await; print({await}) }\n",
     b"function f(){var e;print({await:e})}"),
    ("({name}) => name\n", b"({name:e})=>e"),
    ("function f({a,b=2,c}){return a+b+c}\n",
     b"function f({a:e,b:t=2,c:n}){return e+t+n}"),
    ("function f([a,,b]){return a+b}\n", b"function f([e,,t]){return e+t}"),
    ("var {name} = obj; print(name);\n", b"var{name}=obj;print(name)"),
])
def test_destructuring_shorthand_expands_when_renaming(js, source, expected):
    """'{name}' shorthand expands to '{name:e}' so the value can be renamed."""
    result = js(source)
    # CATCHES: shorthand properties are expanded only when the bound name is
    # renamed; at top level (no renaming) '{name}' stays shorthand.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_unused_catch_binding_is_dropped(js):
    """A catch parameter that is never used disappears from the output."""
    result = js("function f(){ var name,z;z;try{}catch(name){var name} }\n")
    # CATCHES: the catch var merges with the function's 'name' var and the
    # binding is removed entirely, leaving a bare 'catch{}'.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"function f(){var e,t;t;try{}catch{}}", b"")


def test_arguments_and_globals_are_left_alone(js):
    """Implicit globals such as 'arguments' are never renamed."""
    result = js("function f(){ print(arguments) }\n")
    # CATCHES: only declared identifiers are renamed; undeclared references
    # like 'arguments' pass through byte for byte.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"function f(){print(arguments)}", b"")


@pytest.mark.parametrize("source,expected", [
    ("function f(){ var alpha; print(alpha) }\n",
     b"function f(){var alpha;print(alpha)}"),
    ("try{}catch(err){err}\n", b"try{}catch(err){err}"),
    ("class A{ #myField=1; m(){this.#myField} }\n",
     b"class A{#myField=1;m(){this.#myField}}"),
    ("({name})=>name\n", b"({name})=>name"),
    ("x=>x+1\n", b"x=>x+1"),
    ("for(const item of list)print(item)\n",
     b"for(const item of list)print(item)"),
    ("function f({foo,bar}){foo,bar}\n", b"function f({foo,bar}){foo,bar}"),
])
def test_keep_var_names_disables_renaming(js, source, expected):
    """--js-keep-var-names preserves every original identifier."""
    result = js(source, ["--js-keep-var-names"])
    # CATCHES: the flag turns off renaming for vars, params, catch bindings,
    # private fields and destructuring shorthand in one go.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")
