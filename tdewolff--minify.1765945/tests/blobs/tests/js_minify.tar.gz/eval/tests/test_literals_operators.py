"""Literal and operator rewrites: booleans, undefined/Infinity, equality
collapsing, increment folding, member access, new-call and parentheses."""

import pytest


def test_boolean_and_global_literals(js):
    """true/false/undefined/Infinity become shorter spellings."""
    result = js("var x = true, y = false, z = undefined, w = Infinity;\n")
    # CATCHES: booleans turn into '!0'/'!1', undefined into '0[0]' and
    # Infinity into '1/0' rather than any other shortening.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"var x=!0,y=!1,z=0[0],w=1/0", b"")


@pytest.mark.parametrize("source,expected", [
    ("a=undefined\n", b"a=0[0]"),
    ("a=Infinity\n", b"a=1/0"),
    ("a=1/0\n", b"a=1/0"),
    ("a=-1/0\n", b"a=-1/0"),
    ("a=NaN\n", b"a=NaN"),
    ("void 0\n", b"0[0]"),
])
def test_special_value_spellings(js, source, expected):
    """undefined and Infinity are shortened; NaN is left alone."""
    result = js(source)
    # CATCHES: 'void 0' is rewritten to the same '0[0]' as 'undefined',
    # while NaN and already-short division forms pass through untouched.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_null_undefined_comparison_collapses(js):
    """a===null||a===undefined shortens to a==null."""
    result = js("if (a===null||a===undefined) { b() }\n")
    # CATCHES: the two strict comparisons fold into one loose comparison,
    # which is then wrapped in parentheses inside the collapsed && form.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"(a==null)&&b()", b"")


@pytest.mark.parametrize("source,expected", [
    ("typeof a=='string'\n", b'typeof a=="string"'),
    ("typeof a==='string'\n", b'typeof a=="string"'),
])
def test_typeof_comparison_loses_one_equals(js, source, expected):
    """typeof comparisons are safe with a loose equality."""
    result = js(source)
    # CATCHES: both '==' and '===' after 'typeof' collapse to a single '='
    # because typeof never yields unequal strings of the same value.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a=a+1\n", b"++a"),
    ("a=a-1\n", b"--a"),
    ("a=a+2\n", b"a=a+2"),
    ("a+=1\n", b"a+=1"),
    ("a-=1\n", b"a-=1"),
    ("a=a*1\n", b"a=a*1"),
])
def test_self_increment_folding(js, source, expected):
    """a=a+1 becomes ++a, but only for an increment of exactly one."""
    result = js(source)
    # CATCHES: only '+1'/'-1' fold into prefix operators; every other
    # arithmetic self-assignment is printed unchanged.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


def test_math_pow_becomes_exponent(js):
    """Math.pow(a,b) is rewritten as the exponentiation operator."""
    result = js("Math.pow(a,b)\n")
    # CATCHES: the static method call becomes 'a**b' with no parentheses.
    assert (result.returncode, result.stdout, result.stderr) == (
        0, b"a**b", b"")


@pytest.mark.parametrize("source,expected", [
    ("a['b']\n", b"a.b"),
    ("a['for']\n", b"a.for"),
    ("a['while']\n", b"a.while"),
    ("a['b c']\n", b'a["b c"]'),
    ("a['0']\n", b"a[0]"),
    ("a['']\n", b'a[""]'),
    ("a.b.c\n", b"a.b.c"),
    ("a[0]\n", b"a[0]"),
])
def test_member_access_normalisation(js, source, expected):
    """String keys become dot access when the result is valid and shorter."""
    result = js(source)
    # CATCHES: keyword keys like 'for' still become '.for' while a space or
    # an empty string forces quoted bracket access, and '0' becomes the
    # numeric index form.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("new a()\n", b"new a"),
    ("new RegExp()\n", b"new RegExp"),
    ("new RegExp('a+')\n", b'new RegExp("a+")'),
])
def test_new_call_parentheses_dropped(js, source, expected):
    """A argument-less new expression loses its parentheses."""
    result = js(source)
    # CATCHES: 'new a()' becomes 'new a' with no trailing space, but a
    # constructor with arguments keeps both parentheses and string quotes.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("(a)\n", b"a"),
    ("((a))\n", b"a"),
    ("-(-a)\n", b"- -a"),
    ("(a?.b()).c\n", b"(a?.b()).c"),
    ("a?.b.c\n", b"a?.b.c"),
    ("a?.[b]\n", b"a?.[b]"),
    ("a?.(b)\n", b"a?.(b)"),
])
def test_redundant_parentheses_removed(js, source, expected):
    """Grouping parentheses survive only where precedence requires them."""
    result = js(source)
    # CATCHES: plain groups vanish, '-(-a)' keeps a space to avoid '--',
    # and optional-chaining results stay grouped before member access.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")


@pytest.mark.parametrize("source,expected", [
    ("a===b\n", b"a===b"),
    ("a!==b\n", b"a!==b"),
    ("a==b\n", b"a==b"),
    ("a=!!b\n", b"a=!!b"),
    ("~a\n", b"~a"),
    ("a=+a\n", b"a=+a"),
])
def test_comparisons_are_not_weakened(js, source, expected):
    """Strict equality operators are never rewritten to loose ones."""
    result = js(source)
    # CATCHES: '===' and '!==' survive except after 'typeof', and unary
    # chains like '!!' are printed without inserted spaces.
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b"")
