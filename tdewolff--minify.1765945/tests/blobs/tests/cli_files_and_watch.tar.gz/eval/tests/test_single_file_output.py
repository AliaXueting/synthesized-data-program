"""Single file -> file destination: content, created paths, statistics format.

Pins the exact statistics line layout (duration, in-size, out-size, ratio,
speed), the 0755/0644 permissions of created directories and files, and the
error messages when the output path cannot be created or opened.
"""

import os

from conftest import file_modes, run_minify, write

CSS_IN = b"body {\n  color: red;\n}\n"
CSS_OUT = b"body{color:red}"


def test_statistics_line_reports_sizes_and_ratio(tmp_path):
    """The stats line has five comma separated fields then 'src to dst'."""
    # CATCHES: a different field order, a missing padding, or a ratio computed
    # from the wrong pair of sizes.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["rin"] == "23 B"
    assert stats[0]["rout"] == "15 B"
    assert stats[0]["ratio"] == "65.2"
    assert stats[0]["names"] == "a.css to out.css"
    assert res.stdout.endswith(b") - a.css to out.css\n")


def test_output_file_written_with_default_0644_mode(tmp_path):
    """A 0644 source yields a 0644 output: perms are inherited from the input."""
    # CATCHES: hardwiring the output mode (0600/0666, or a bare umask pass-
    # through) instead of chmodding the destination to the source's 0644. The
    # input is chmodded explicitly because pytest's umask decides its creation
    # mode and the output copies whatever the input has.
    write(tmp_path, "a.css", CSS_IN, mode=0o644)
    res = run_minify(["a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT
    assert file_modes(tmp_path)["out.css"] == "0o644"


def test_missing_parent_directories_are_created_0755(tmp_path):
    """Deep output paths create every missing parent directory."""
    # CATCHES: requiring the destination directory to exist, or creating it
    # with permissions other than 0755.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css", "-o", "new/dir/out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "new/dir/out.css").read_bytes() == CSS_OUT
    assert oct(os.stat(tmp_path / "new").st_mode & 0o777) == "0o755"
    assert oct(os.stat(tmp_path / "new/dir").st_mode & 0o777) == "0o755"


def test_same_input_and_output_name_drops_the_destination(tmp_path):
    """When src and dst print identically the stats line omits ' to dst'."""
    # CATCHES: printing 'a.css to a.css' for the in-place flavour of the run.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css", "-o", "a.css"], cwd=tmp_path)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "a.css"
    assert (tmp_path / "a.css").read_bytes() == CSS_OUT


def test_existing_output_file_is_truncated(tmp_path):
    """A longer previous output is fully replaced, not appended to."""
    # CATCHES: opening the destination without O_TRUNC so stale bytes survive
    # past the new (shorter) minified content.
    write(tmp_path, "a.css", CSS_IN)
    write(tmp_path, "out.css", b"X" * 500)
    res = run_minify(["a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT


def test_output_path_is_an_existing_directory(tmp_path):
    """A directory where a file was wanted fails to open."""
    # CATCHES: a plain 'is a directory' message without the quoting and the
    # 'open output file' prefix, or a zero exit status.
    write(tmp_path, "a.css", CSS_IN)
    (tmp_path / "adir").mkdir()
    res = run_minify(["a.css", "-o", "adir"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'ERROR: open output file "adir": open adir: is a directory\n'


def test_output_parent_is_a_regular_file(tmp_path):
    """A file in the middle of the output path cannot become a directory."""
    # CATCHES: failing to report the 'creating directory' wrapper, or trying
    # to write through the blocking file.
    write(tmp_path, "a.css", CSS_IN)
    write(tmp_path, "blk", b"x")
    res = run_minify(["a.css", "-o", "blk/out.css"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'ERROR: creating directory "blk": mkdir blk: not a directory\n'


def test_empty_input_file_reports_zero_bytes(tmp_path):
    """A zero byte input yields '0 B' sizes and a 100.0% ratio."""
    # CATCHES: dividing by zero for the ratio (NaN%) or printing '0B' without
    # the space that formatBytes uses.
    write(tmp_path, "a.css", b"")
    res = run_minify(["a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["rin"] == "0 B"
    assert stats[0]["rout"] == "0 B"
    assert stats[0]["ratio"] == "100.0"
    assert (tmp_path / "out.css").read_bytes() == b""


def test_quiet_suppresses_the_statistics_line(tmp_path):
    """-q removes the per-task stdout line while the file is still written."""
    # CATCHES: implementing -q as a no-op, or suppressing the actual minify
    # work together with the reporting.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["-q", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT


def test_hardlinked_output_renames_the_original(tmp_path):
    """input -> a hard link of itself: the link is renamed to .bak first."""
    # CATCHES: truncating the shared inode in place (destroying the source) or
    # leaving the '<file>.bak' backup behind after a successful minify.
    write(tmp_path, "a.css", CSS_IN)
    os.link(tmp_path / "a.css", tmp_path / "b.css")
    res = run_minify(["a.css", "-o", "b.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "a.css to b.css"
    assert (tmp_path / "a.css").read_bytes() == CSS_IN
    assert (tmp_path / "b.css").read_bytes() == CSS_OUT
    assert not (tmp_path / "b.css.bak").exists()
