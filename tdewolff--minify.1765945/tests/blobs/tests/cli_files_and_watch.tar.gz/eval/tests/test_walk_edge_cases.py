"""Walk edge cases: special file types, self-sync, and failure accounting.

A fifo as a top-level input is rejected as "not a file or directory", but a
fifo inside a walked directory is skipped silently. Dangling symlinks in a
walk print a stat error while the run still succeeds; a symlink to a
directory is traversed; --preserve links without --sync only warns per link.
--sync onto the very same directory copies nothing. When one file among
several fails to minify the exit code becomes 1. Symlink destinations that
are non-empty directories fail, empty ones are replaced, and a destination
subdirectory blocked by a regular file fails only that symlink's task while
a destination path crossing a regular file aborts before any task runs.
"""

import os

from conftest import run_minify, symlink, write

CSS = b"z { color: red }"
CSS_OUT = b"z{color:red}"


def test_fifo_input_is_rejected(tmp_path):
    """A top-level fifo is neither file nor directory: error, exit code 1."""
    # CATCHES: trying to open and minify the fifo (which would block forever
    # on the read) instead of refusing it up front.
    os.mkfifo(tmp_path / "pipe")
    res = run_minify(["pipe", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.err_lines() == ["ERROR: not a file or directory pipe"]
    assert not (tmp_path / "out.css").exists()


def test_fifo_inside_walk_is_skipped_silently(tmp_path):
    """A fifo found during a recursive walk is ignored without any noise."""
    # CATCHES: rejecting the whole walk because of the special file, or
    # printing a warning for it like for the omitting cases.
    write(tmp_path, "in/a.css", CSS)
    os.mkfifo(tmp_path / "in/pipe")
    res = run_minify(["-r", "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert [s["names"] for s in res.stats()] == ["in/a.css to out/a.css"]
    assert sorted(p.name for p in (tmp_path / "out").iterdir()) == ["a.css"]


def test_dangling_symlink_in_walk_reports_stat_error_but_succeeds(tmp_path):
    """A dangling symlink inside the walk prints a stat error, exit code 0."""
    # CATCHES: treating the dangling link as a task (open would fail) or
    # letting the stat error abort the whole recursive run.
    write(tmp_path, "in/a.css", CSS)
    symlink(tmp_path, "nowhere.css", "in/dangling.css")
    res = run_minify(["-r", "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.err_lines() == ["ERROR: stat in/dangling.css: no such file or directory"]
    assert [s["names"] for s in res.stats()] == ["in/a.css to out/a.css"]
    assert sorted(p.name for p in (tmp_path / "out").iterdir()) == ["a.css"]


def test_symlink_to_directory_in_walk_is_traversed(tmp_path):
    """A symlink pointing at a directory is followed and its tree minified."""
    # CATCHES: skipping the symlinked directory (treat-as-file) or copying
    # the link itself when --preserve links was not asked for.
    write(tmp_path, "other/n.css", CSS)
    write(tmp_path, "in/a.css", CSS)
    symlink(tmp_path, "../other", "in/linkdir")
    res = run_minify(["-r", "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert sorted(s["names"] for s in res.stats()) == [
        "in/a.css to out/a.css",
        "in/linkdir/n.css to out/linkdir/n.css",
    ]
    assert (tmp_path / "out/linkdir/n.css").read_bytes() == CSS_OUT


def test_preserve_links_without_sync_warns_inside_walk(tmp_path):
    """--preserve links without --sync drops walked links with a warning."""
    # CATCHES: hard-failing the run (as the top-level variant does) or
    # silently omitting the in-walk symlink.
    write(tmp_path, "in/a.css", CSS)
    symlink(tmp_path, "a.css", "in/l.css")
    res = run_minify(["-r", "--preserve", "links", "-o", "out/", "in/"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert res.err_lines() == ["WARNING: --sync not specified, omitting symbolic link in/l.css"]
    assert [s["names"] for s in res.stats()] == ["in/a.css to out/a.css"]
    assert not (tmp_path / "out/l.css").exists()


def test_non_minifiable_file_in_walk_is_skipped_without_sync(tmp_path):
    """A .txt file in the walk produces no task, no output, no warning."""
    # CATCHES: warning about (or copying) the unmatched extension when
    # --sync is off, instead of skipping it silently.
    write(tmp_path, "in/a.css", CSS)
    write(tmp_path, "in/n.txt", b"hello world")
    res = run_minify(["-r", "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert [s["names"] for s in res.stats()] == ["in/a.css to out/a.css"]


def test_sync_onto_itself_copies_nothing(tmp_path):
    """--sync with destination == input dir minifies in place, copies nothing."""
    # CATCHES: re-copying each non-minifiable file onto itself (writing and
    # printing an INFO copy line) instead of recognizing src == dst.
    write(tmp_path, "d/a.css", CSS)
    write(tmp_path, "d/notes.txt", b"hello world")
    res = run_minify(["-s", "-r", "-v", "-o", "d/", "d/"], cwd=tmp_path)
    assert res.returncode == 0
    assert [s["names"] for s in res.stats()] == ["d/a.css"]
    assert (tmp_path / "d/a.css").read_bytes() == CSS_OUT
    assert (tmp_path / "d/notes.txt").read_bytes() == b"hello world"
    # no "INFO: copy" line for notes.txt, only the finished summary
    assert len([l for l in res.err_lines() if l.startswith("INFO: copy")]) == 0
    assert len(res.err_lines()) == 1


def test_one_failing_file_among_many_exits_one(tmp_path):
    """A failing minification in a multi-task run fails the whole run."""
    # CATCHES: counting only the first task's outcome (or none) for the
    # exit code when tasks run on the parallel workers.
    write(tmp_path, "bad/g.css", CSS)
    write(tmp_path, "bad/x.js", b'var a = "unterminated')
    res = run_minify(["-r", "-o", "out/", "bad/"], cwd=tmp_path)
    assert res.returncode == 1
    assert sorted(s["names"] for s in res.stats()) == [
        "bad/g.css to out/g.css",
        "bad/x.js to out/x.js",
    ]
    assert res.err_lines() == [
        "ERROR: cannot minify bad/x.js: unterminated string literal in expression on line 1 and column 9",
        '    1: var a = "unterminated',
        "               ^",
    ]
    assert (tmp_path / "out/g.css").read_bytes() == CSS_OUT
    assert (tmp_path / "out/x.js").read_bytes() == b'var a = "unterminated'


def test_symlink_destination_nonempty_directory_is_an_error(tmp_path):
    """--sync --preserve links refuses to replace a non-empty directory."""
    # CATCHES: deleting the populated directory (or failing silently)
    # instead of erroring with the remove failure and exit code 1.
    write(tmp_path, "in/t.txt", b"hello world")
    symlink(tmp_path, "t.txt", "in/link.txt")
    write(tmp_path, "out/link.txt/x", b"x")
    res = run_minify(["-s", "-r", "--preserve", "links", "-o", "out/", "in/"],
                     cwd=tmp_path)
    assert res.returncode == 1
    assert res.err_lines() == ["ERROR: remove out/link.txt: directory not empty"]
    assert (tmp_path / "out/link.txt/x").read_bytes() == b"x"


def test_symlink_destination_empty_directory_is_replaced(tmp_path):
    """An empty directory at the symlink destination is removed and replaced."""
    # CATCHES: failing on the existing directory (or keeping it) instead of
    # removing it and creating the symlink in its place.
    write(tmp_path, "in/t.txt", b"hello world")
    symlink(tmp_path, "t.txt", "in/link.txt")
    (tmp_path / "out/link.txt").mkdir(parents=True)
    res = run_minify(["-s", "-r", "--preserve", "links", "-o", "out/", "in/"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (tmp_path / "out/link.txt").is_symlink()
    assert (tmp_path / "out/link.txt").readlink().name == "t.txt"


def test_destination_below_a_regular_file_is_an_error(tmp_path):
    """A directory destination whose path crosses a regular file fails."""
    # CATCHES: creating the destination tree anyway (or crashing) instead of
    # failing up front with 'mkdir blocker: not a directory' and rc 1.
    write(tmp_path, "in/a.css", CSS)
    write(tmp_path, "blocker", b"f")
    res = run_minify(["-r", "-o", "blocker/out/", "in/"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.err_lines() == ["ERROR: mkdir blocker: not a directory"]
    assert (tmp_path / "blocker").read_bytes() == b"f"
    assert (tmp_path / "in/a.css").read_bytes() == CSS


def test_symlink_destination_under_a_file_subtree_is_an_error(tmp_path):
    """A symlink whose destination subdir is blocked by a file fails that task."""
    # CATCHES: skipping the blocked symlink silently (or failing the whole
    # run) instead of erroring only for out/sub/link.txt with rc 1.
    write(tmp_path, "in/a.css", CSS)
    symlink(tmp_path, "gone.txt", "in/sub/link.txt")
    write(tmp_path, "out/sub", b"blocked")
    res = run_minify(["-s", "-r", "--preserve", "links", "-o", "out/", "in/"],
                     cwd=tmp_path)
    assert res.returncode == 1
    assert res.err_lines() == ["ERROR: mkdir out/sub: not a directory"]
    assert [s["names"] for s in res.stats()] == ["in/a.css to out/a.css"]
    assert (tmp_path / "out/a.css").read_bytes() == CSS_OUT
    assert (tmp_path / "out/sub").read_bytes() == b"blocked"
