"""--watch: minify once, re-minify on modification, exit cleanly on Ctrl+C.

The watcher prints a fresh statistics line for every re-minification, stays
quiet about changes to its own output file, follows files inside watched
directories when --recursive is given, and exits with status 0 on SIGINT
without the 'finished in ...' summary that non-watch runs print. Several
inputs in one directory are all watched, changes to files that are not task
sources are ignored, directories created mid-watch add no tasks, writes
arriving within the ~100 ms debounce window collapse into one re-minify,
a watched file replaced by a directory is survived without re-minifying,
and -v serializes the initial minifications into walk order.
"""

import os

from conftest import run_watch, write

CSS_IN = b"body {\n  color: red;\n}\n"
CSS_OUT = b"body{color:red}"


def test_watch_reminifies_on_change_and_exits_cleanly(tmp_path):
    """A modification triggers a second stats line; SIGINT exits 0."""
    # CATCHES: minifying only once (no fsnotify loop), printing the
    # 'INFO: finished in ...' summary that watch mode suppresses, or exiting
    # with a nonzero status on the interrupt.
    write(tmp_path, "a.css", CSS_IN)

    def modify():
        write(tmp_path, "a.css", b"p{margin:0}\n")

    res = run_watch(["--watch", "a.css", "-o", "out.css"], cwd=tmp_path,
                    actions=modify, settle=0.8, wait=1.5)
    assert res.returncode == 0
    assert res.stderr == b""
    stats = res.stats()
    assert len(stats) == 2
    assert [s["rin"] for s in stats] == ["23 B", "12 B"]
    assert [s["names"] for s in stats] == ["a.css to out.css"] * 2
    assert (tmp_path / "out.css").read_bytes() == b"p{margin:0}"


def test_watch_ignores_modifications_to_its_own_output(tmp_path):
    """Overwriting the output file does not trigger another minification."""
    # CATCHES: re-minifying on the watcher's own output writes, which would
    # loop forever; exactly one statistics line may appear and the touched
    # bytes must survive untouched in the output file.
    write(tmp_path, "a.css", CSS_IN)

    def touch_output():
        write(tmp_path, "out.css", b"/* touched */")

    res = run_watch(["--watch", "a.css", "-o", "out.css"], cwd=tmp_path,
                    actions=touch_output, settle=0.8, wait=1.5)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "a.css to out.css"
    assert (tmp_path / "out.css").read_bytes() == b"/* touched */"


def test_watch_recursive_directory_reminifies_on_change(tmp_path):
    """Watching a directory re-minifies a file modified inside it."""
    # CATCHES: watching only the directory entry itself rather than the files
    # within, so a change to dir/b.js would go unnoticed.
    write(tmp_path, "dir/b.js", b"var b = 1;\n")

    def modify():
        write(tmp_path, "dir/b.js", b"var b = 2;\n")

    res = run_watch(["--watch", "-r", "dir", "-o", "wout/"], cwd=tmp_path,
                    actions=modify, settle=0.8, wait=1.5)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 2
    assert all(s["names"] == "dir/b.js to wout/dir/b.js" for s in stats)
    assert (tmp_path / "wout/dir/b.js").read_bytes() == b"var b=2"


def test_watch_two_files_in_one_directory(tmp_path):
    """Both inputs sharing a directory are watched and re-minified."""
    # CATCHES: registering the shared directory only for the first input, so
    # a modification of the second file goes unnoticed.
    write(tmp_path, "x/a.css", b"a { color: red; }\n")
    write(tmp_path, "x/b.css", b"b { color: blue; }\n")

    def modify_both():
        write(tmp_path, "x/a.css", b"a { color: green; }\n")
        write(tmp_path, "x/b.css", b"b { color: cyan; }\n")

    res = run_watch(["--watch", "x/a.css", "x/b.css", "-o", "out/"],
                    cwd=tmp_path, actions=modify_both, settle=0.8, wait=1.5)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 4
    assert sorted(s["names"] for s in stats) == [
        "x/a.css to out/a.css", "x/a.css to out/a.css",
        "x/b.css to out/b.css", "x/b.css to out/b.css",
    ]
    assert (tmp_path / "out/a.css").read_bytes() == b"a{color:green}"
    assert (tmp_path / "out/b.css").read_bytes() == b"b{color:cyan}"


def test_watch_ignores_changes_to_unwatched_sibling(tmp_path):
    """Modifying a non-input file in a watched directory does nothing."""
    # CATCHES: re-minifying (or crashing) on any event from the watched
    # directory instead of only on the files that are actual task sources.
    write(tmp_path, "in/a.css", CSS_IN)
    write(tmp_path, "in/other.css", b"x { color: red; }\n")

    def modify_sibling():
        write(tmp_path, "in/other.css", b"x { color: blue; }\n")

    res = run_watch(["--watch", "in/a.css", "-o", "out/"], cwd=tmp_path,
                    actions=modify_sibling, settle=0.8, wait=1.5)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "in/a.css to out/a.css"
    assert (tmp_path / "out/a.css").read_bytes() == CSS_OUT
    assert not (tmp_path / "out/other.css").exists()


def test_watch_recursive_new_directory_is_watched_but_not_reminified(tmp_path):
    """A directory created during a recursive watch produces no re-minify."""
    # CATCHES: crashing on (or ignoring) the Create event for a brand-new
    # directory; the files inside it are not task sources, so no statistics
    # line may appear and the watcher must survive until SIGINT.
    write(tmp_path, "in/a.css", CSS_IN)

    def add_directory():
        write(tmp_path, "in/newdir/n.css", b"n { color: red; }\n")

    res = run_watch(["--watch", "-r", "in/", "-o", "out/"], cwd=tmp_path,
                    actions=add_directory, settle=0.8, wait=1.5)
    assert res.returncode == 0
    assert res.stderr == b""
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "in/a.css to out/a.css"
    produced = sorted(str(p.relative_to(tmp_path / "out")) for p in
                      (tmp_path / "out").rglob("*") if p.is_file())
    assert produced == ["a.css"]


def test_watch_debounces_rapid_modifications(tmp_path):
    """Two back-to-back writes trigger exactly one re-minification."""
    # CATCHES: missing the ~100 ms debounce, which would emit one statistics
    # line per write event (three lines) instead of collapsing them.
    write(tmp_path, "a.css", CSS_IN)

    def modify_twice():
        write(tmp_path, "a.css", b"p{margin:0}\n")
        write(tmp_path, "a.css", b"p{margin:1}\n")

    res = run_watch(["--watch", "a.css", "-o", "out.css"], cwd=tmp_path,
                    actions=modify_twice, settle=0.8, wait=1.5)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 2
    assert [s["names"] for s in stats] == ["a.css to out.css"] * 2
    # the re-minification reads the file only after the debounce window, so
    # the final content is the second write
    assert (tmp_path / "out.css").read_bytes() == b"p{margin:1}"


def test_watch_survives_watched_file_replaced_by_directory(tmp_path):
    """A watched file replaced by a directory is neither re-minified nor fatal."""
    # CATCHES: crashing, erroring or re-minifying when a task source turns
    # into a directory mid-watch: the Create event is admitted, the new
    # directory itself is watched recursively, but the file written inside
    # it is not a task source, so no statistics line may appear and the
    # watcher must still exit 0 on SIGINT with the earlier output intact.
    write(tmp_path, "a.css", CSS_IN)

    def replace_with_directory():
        os.remove(tmp_path / "a.css")
        (tmp_path / "a.css").mkdir()
        write(tmp_path, "a.css/x.css", b"n { color: red; }\n")

    res = run_watch(["--watch", "-r", "a.css", "-o", "out.css"], cwd=tmp_path,
                    actions=replace_with_directory, settle=0.9, wait=1.5)
    assert res.returncode == 0
    assert res.stderr == b""
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "a.css to out.css"
    # the output of the one real minification survives the whole dance
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT


def test_watch_verbose_minifies_initial_tasks_in_walk_order(tmp_path):
    """With -v the initial watch minifications report in deterministic order."""
    # CATCHES: farming the initial watch tasks out to parallel workers, which
    # interleaves the statistics lines; -v forces a single worker, so the
    # lines must arrive in the directory-walk order a.css, b.css, c.css,
    # sub/d.css and stderr stays empty (no INFO lines exist in watch mode).
    write(tmp_path, "in/a.css", b"aaaa { color: red; }\n")
    write(tmp_path, "in/b.css", b"bbbbb { color: blue; }\n")
    write(tmp_path, "in/c.css", b"cccccc { color: cyan; }\n")
    write(tmp_path, "in/sub/d.css", b"ddddddd { color: teal; }\n")
    res = run_watch(["--watch", "-v", "-r", "in/", "-o", "out/"], cwd=tmp_path,
                    actions=None, settle=1.0, wait=0.3)
    assert res.returncode == 0
    assert res.stderr == b""
    assert [s["names"] for s in res.stats()] == [
        "in/a.css to out/a.css",
        "in/b.css to out/b.css",
        "in/c.css to out/c.css",
        "in/sub/d.css to out/sub/d.css",
    ]
    assert (tmp_path / "out/a.css").read_bytes() == b"aaaa{color:red}"
    assert (tmp_path / "out/sub/d.css").read_bytes() == b"ddddddd{color:teal}"
