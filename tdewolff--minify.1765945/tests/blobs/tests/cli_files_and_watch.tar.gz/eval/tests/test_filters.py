"""Filename filters: --match globs the basename, --include/--exclude the path.

--match patterns are globs on the base filename by default (`?` one
character, `**` anything) and regular expressions when prefixed with `~`;
they select which walked files become tasks. --include/--exclude are full
-path filters applied in the order given, where a later include re-includes
what an earlier exclude removed. An invalid `~` regex aborts the run before
any file is touched.
"""

import pytest

from conftest import run_minify, write

CSS = b"z { color: red }"
CSS_OUT = b"z{color:red}"
JS = b"var x = 1;"
JS_OUT = b"var x=1"

FILES = {
    "a.css": CSS,
    "ab.css": CSS,
    "axb.css": CSS,
    "a*b.css": CSS,
    "~x.css": CSS,
    "b.js": JS,
    "sub/keep.css": CSS,
    "sub/skip.css": CSS,
}

ALL_NAMES = sorted("in/%s to out/%s" % (f, f) for f in FILES)
CSS_ONLY = [n for n in ALL_NAMES if n.split(" to ")[0].endswith(".css")]


def _setup(tmp_path):
    for rel, content in FILES.items():
        write(tmp_path, "in/" + rel, content)


def _names(res):
    return sorted(s["names"] for s in res.stats())


def _out_files(tmp_path):
    return sorted(str(p.relative_to(tmp_path / "out")) for p in
                  (tmp_path / "out").rglob("*") if p.is_file())


@pytest.mark.parametrize("pattern,expected", [
    ("*.css", CSS_ONLY),
    ("a?.css", ["in/ab.css to out/ab.css"]),
    ("**.css", CSS_ONLY),
    ("a\\*b.css", ["in/a*b.css to out/a*b.css", "in/ab.css to out/ab.css",
                   "in/axb.css to out/axb.css"]),
    ("a\\?b.css", ["in/a*b.css to out/a*b.css", "in/axb.css to out/axb.css"]),
    ("\\~x.css", ["in/~x.css to out/~x.css"]),
])
def test_match_globs_the_basename(tmp_path, pattern, expected):
    """--match selects walked files by globbing their base filename."""
    # CATCHES: matching the full path instead of the basename, or treating
    # `?`/`**`/escapes differently, which lets the wrong files through.
    _setup(tmp_path)
    res = run_minify(["-r", "--match", pattern, "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _names(res) == expected
    assert _out_files(tmp_path) == [n.split(" to ")[0][3:] for n in expected]


@pytest.mark.parametrize("pattern,expected", [
    ("~\\.js$", ["in/b.js to out/b.js"]),
    ("~^in/ab", []),
    ("~^s", ["in/sub/skip.css to out/sub/skip.css"]),
])
def test_match_regex_mode_matches_the_basename(tmp_path, pattern, expected):
    """A --match pattern prefixed with ~ is a regex against the basename."""
    # CATCHES: applying the regex to the walked path (so ~^in/ab would match)
    # or forgetting the ~ prefix switches to regex instead of glob mode. The
    # unfiltered control run proves the walk itself yields all eight tasks,
    # so the empty expectation of ~^in/ab cannot be met by printing nothing.
    _setup(tmp_path)
    control = run_minify(["-r", "-o", "out/", "in/"], cwd=tmp_path)
    assert _names(control) == ALL_NAMES
    res = run_minify(["-r", "--match", pattern, "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _names(res) == expected


@pytest.mark.parametrize("option", ["--match", "--include", "--exclude"])
def test_invalid_regex_pattern_is_an_error(tmp_path, option):
    """A ~ pattern that fails to compile aborts with exit code 1."""
    # CATCHES: ignoring the broken pattern and minifying everything anyway,
    # instead of failing up front with the regexp parse error.
    _setup(tmp_path)
    res = run_minify(["-r", option, "~[", "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.err_lines() == ["ERROR: error parsing regexp: missing closing ]: `[`"]
    assert not (tmp_path / "out").exists()


@pytest.mark.parametrize("pattern,expected", [
    ("**/sub/**", [n for n in ALL_NAMES if not n.startswith("in/sub/")]),
    ("in/sub/**", [n for n in ALL_NAMES if not n.startswith("in/sub/")]),
    ("**/*.css", ["in/b.js to out/b.js"]),
    ("in/a.css", [n for n in ALL_NAMES if n != "in/a.css to out/a.css"]),
])
def test_exclude_filters_on_the_walked_path(tmp_path, pattern, expected):
    """--exclude patterns are matched against the path as walked."""
    # CATCHES: matching the basename like --match does, so `sub/**` would
    # exclude the subtree even though the walked path is in/sub/....
    _setup(tmp_path)
    res = run_minify(["-r", "--exclude", pattern, "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _names(res) == expected
    assert _out_files(tmp_path) == [n.split(" to ")[0][3:] for n in expected]


def test_exclude_then_include_reincludes(tmp_path):
    """An --include after an --exclude lets matching paths back in."""
    # CATCHES: applying includes before excludes (or not at all), which
    # would drop keep.css together with all the other CSS files.
    _setup(tmp_path)
    res = run_minify(
        ["-r", "--exclude", "**/*.css", "--include", "**/keep.css",
         "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _names(res) == ["in/b.js to out/b.js", "in/sub/keep.css to out/sub/keep.css"]
    assert (tmp_path / "out/sub/keep.css").read_bytes() == CSS_OUT
    assert (tmp_path / "out/b.js").read_bytes() == JS_OUT


def test_include_alone_does_not_filter(tmp_path):
    """An --include without a preceding --exclude excludes nothing."""
    # CATCHES: treating --include as a whitelist, which would minify only
    # keep.css instead of leaving all eight files in the run.
    _setup(tmp_path)
    res = run_minify(["-r", "--include", "**/keep.css", "-o", "out/", "in/"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _names(res) == ALL_NAMES


def test_filters_are_applied_in_the_order_given(tmp_path):
    """Regex exclude/include filters override each other in CLI order."""
    # CATCHES: always letting excludes win, so ab.css would be gone instead
    # of being re-included by the later --include ~ab.
    _setup(tmp_path)
    res = run_minify(
        ["-r", "--exclude", "~a", "--include", "~ab", "-o", "out/", "in/"],
        cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _names(res) == [
        "in/ab.css to out/ab.css",
        "in/b.js to out/b.js",
        "in/sub/keep.css to out/sub/keep.css",
        "in/sub/skip.css to out/sub/skip.css",
        "in/~x.css to out/~x.css",
    ]


def test_multiple_match_patterns_are_unioned(tmp_path):
    """--match consumes several patterns that are OR-ed together."""
    # CATCHES: keeping only the last (or first) pattern, which would drop
    # one of the two selected files from the run.
    _setup(tmp_path)
    res = run_minify(["-r", "--match", "a.css", "b.js", "-o", "out/", "in/"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _names(res) == ["in/a.css to out/a.css", "in/b.js to out/b.js"]
    assert (tmp_path / "out/a.css").read_bytes() == CSS_OUT
    assert (tmp_path / "out/b.js").read_bytes() == JS_OUT


def test_match_with_no_matches_minifies_nothing(tmp_path):
    """A --match that selects nothing leaves an empty destination and rc 0."""
    # CATCHES: turning "no file selected" into an error, or ignoring the
    # filter and minifying the whole tree anyway.
    _setup(tmp_path)
    res = run_minify(["-r", "--match", "zzz*", "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert list((tmp_path / "out").iterdir()) == []


def test_top_level_input_filtered_by_match_is_dropped(tmp_path):
    """A top-level input that fails --match is dropped without any output."""
    # CATCHES: skipping the filter for non-walked inputs and minifying the
    # file anyway, instead of producing no task at all. The matching control
    # run first proves this invocation shape does minify when the pattern
    # accepts the file, so a no-op binary cannot pass this test.
    write(tmp_path, "a.css", CSS)
    # --match scans greedily, so the input must come after the next option
    control = run_minify(["--match", "a.css", "-o", "ctrl.css", "a.css"],
                         cwd=tmp_path)
    assert control.returncode == 0
    assert control.stats()[0]["names"] == "a.css to ctrl.css"
    assert (tmp_path / "ctrl.css").read_bytes() == CSS_OUT
    res = run_minify(["--match", "zzz*", "-o", "out.css", "a.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert not (tmp_path / "out.css").exists()
