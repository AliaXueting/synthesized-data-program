"""Attribute preservation: mode and timestamps follow the source by default.

The output file is chmodded/chtimes'd to the source's values (also when
overwriting an existing file with different permissions), subdirectories
created for a recursive run inherit the source directory's attributes while
the destination root stays 0755, a bundle uses the newest input timestamp,
and an explicit --preserve flag adds to the default mode+timestamps set.
"""

import os

from conftest import run_minify, write

CSS_IN = b"body {\n  color: red;\n}\n"
OLD = (1000000000, 1000000000)


def test_output_file_inherits_source_mode(tmp_path):
    """The destination is chmodded to the source's permission bits."""
    # CATCHES: leaving the plain creation mode on the output (0644 under a
    # usual umask) instead of copying 0640 from the input file.
    write(tmp_path, "a.css", CSS_IN, mode=0o640)
    res = run_minify(["a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "out.css").read_bytes() == b"body{color:red}"
    assert oct(os.stat(tmp_path / "out.css").st_mode & 0o777) == "0o640"
    # the same chmod applies when overwriting an existing output file whose
    # permissions differ from both the source and the creation default
    write(tmp_path, "out2.css", b"x", mode=0o777)
    res2 = run_minify(["a.css", "-o", "out2.css"], cwd=tmp_path)
    assert res2.returncode == 0
    assert oct(os.stat(tmp_path / "out2.css").st_mode & 0o777) == "0o640"


def test_output_file_inherits_source_modification_time(tmp_path):
    """The source's mtime is copied onto the destination exactly."""
    # CATCHES: never calling chtimes, or stamping the destination with the
    # current time instead of the source's modification time.
    write(tmp_path, "a.css", CSS_IN)
    os.utime(tmp_path / "a.css", OLD)
    res = run_minify(["a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert int(os.stat(tmp_path / "out.css").st_mtime) == 1000000000


def test_explicit_preserve_mode_still_preserves_timestamps(tmp_path):
    """--preserve mode adds to the default set rather than replacing it."""
    # CATCHES: treating --preserve as an exclusive list, which would drop the
    # default timestamp preservation (or, symmetrically, the mode one).
    write(tmp_path, "a.css", CSS_IN, mode=0o640)
    os.utime(tmp_path / "a.css", OLD)
    res = run_minify(["--preserve", "mode", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert oct(os.stat(tmp_path / "out.css").st_mode & 0o777) == "0o640"
    assert int(os.stat(tmp_path / "out.css").st_mtime) == 1000000000


def test_created_subdirectories_inherit_source_directory_attributes(tmp_path):
    """out/dir gets dir's mode and mtime; the out/ root is left at 0755."""
    # CATCHES: only preserving attributes of files, never of the freshly
    # created parent directories, or including the destination root itself.
    write(tmp_path, "dir/b.css", CSS_IN, mode=0o640)
    os.chmod(tmp_path / "dir", 0o700)
    os.utime(tmp_path / "dir", OLD)
    res = run_minify(["-r", "dir", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert oct(os.stat(tmp_path / "out/dir").st_mode & 0o777) == "0o700"
    assert int(os.stat(tmp_path / "out/dir").st_mtime) == 1000000000
    assert oct(os.stat(tmp_path / "out").st_mode & 0o777) == "0o755"
    assert int(os.stat(tmp_path / "out").st_mtime) != 1000000000
    assert oct(os.stat(tmp_path / "out/dir/b.css").st_mode & 0o777) == "0o640"


def test_bundle_output_timestamps_use_the_latest_source(tmp_path):
    """A bundle's destination mtime is the newest of its inputs."""
    # CATCHES: using the first (or oldest) input's timestamp for the bundle
    # destination instead of the maximum across all sources.
    write(tmp_path, "x.js", b"var a=1")
    write(tmp_path, "y.js", b"var b=2")
    os.utime(tmp_path / "x.js", (1000000000, 1000000000))
    os.utime(tmp_path / "y.js", (2000000000, 2000000000))
    res = run_minify(["-b", "x.js", "y.js", "-o", "out.js"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "out.js").read_bytes() == b"var a=1,b=2"
    assert int(os.stat(tmp_path / "out.js").st_mtime) == 2000000000
