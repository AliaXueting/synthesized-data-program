"""How the destination directory is chosen and how the tree is laid out.

A trailing path separator on -o forces directory mode; otherwise it is inferred
from multiple inputs or a directory input. 'src' copies the directory itself
into the destination while 'src/' copies only its contents.
"""

from conftest import run_minify, tree, write

CSS_IN = b"body {\n  color: red;\n}\n"
CSS_OUT = b"body{color:red}"


def test_trailing_separator_forces_directory_destination(tmp_path):
    """'out/' is a directory even for a single regular file input."""
    # CATCHES: writing a single file literally named 'out' (with the slash
    # stripped) instead of placing the input inside the directory.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "a.css to out/a.css"
    assert tree(tmp_path) == ["a.css", "out", "out/a.css"]
    assert (tmp_path / "out/a.css").read_bytes() == CSS_OUT


def test_multiple_inputs_infer_directory_destination(tmp_path):
    """Two inputs with a slash-less -o still produce a directory."""
    # CATCHES: writing both inputs onto the same single output file.
    write(tmp_path, "a.css", CSS_IN)
    write(tmp_path, "b.css", CSS_IN)
    res = run_minify(["a.css", "b.css", "-o", "out"], cwd=tmp_path)
    assert res.returncode == 0
    assert sorted(s["names"] for s in res.stats()) == [
        "a.css to out/a.css", "b.css to out/b.css"]
    assert (tmp_path / "out/a.css").read_bytes() == CSS_OUT
    assert (tmp_path / "out/b.css").read_bytes() == CSS_OUT


def test_directory_input_infers_directory_destination(tmp_path):
    """A directory input makes a slash-less -o a directory, even sans -r."""
    # CATCHES: creating a *file* named out.css; the warning is still printed
    # and the run still succeeds with exit code 0.
    write(tmp_path, "dir/b.js", b"var b = 1;\n")
    res = run_minify(["dir", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b"WARNING: --recursive not specified, omitting directory dir\n"
    assert (tmp_path / "out.css").is_dir()


def test_directory_input_copies_the_directory_itself(tmp_path):
    """'dir' (no trailing slash) re-creates dir/ inside the destination."""
    # CATCHES: flattening the directory, i.e. writing out/b.js instead of
    # out/dir/b.js.
    write(tmp_path, "dir/b.js", b"var b = 1;\n")
    write(tmp_path, "dir/c.css", CSS_IN)
    res = run_minify(["-r", "dir", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert sorted(s["names"] for s in res.stats()) == [
        "dir/b.js to out/dir/b.js", "dir/c.css to out/dir/c.css"]
    assert tree(tmp_path) == ["dir", "dir/b.js", "dir/c.css",
                              "out", "out/dir", "out/dir/b.js", "out/dir/c.css"]


def test_directory_input_with_trailing_separator_copies_contents(tmp_path):
    """'dir/' copies only the contents, so b.js lands directly in out/."""
    # CATCHES: treating 'dir/' and 'dir' identically, which would create the
    # extra out/dir level.
    write(tmp_path, "dir/b.js", b"var b = 1;\n")
    write(tmp_path, "dir/c.css", CSS_IN)
    res = run_minify(["-r", "dir/", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert sorted(s["names"] for s in res.stats()) == [
        "dir/b.js to out/b.js", "dir/c.css to out/c.css"]
    assert tree(tmp_path) == ["dir", "dir/b.js", "dir/c.css",
                              "out", "out/b.js", "out/c.css"]


def test_dot_output_minifies_the_file_in_place(tmp_path):
    """-o . is not a directory destination: it resolves to the input itself."""
    # CATCHES: creating a directory named '.' handling or writing './a.css'
    # next to the source; the stats line has no destination part.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css", "-o", "."], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "a.css"
    assert (tmp_path / "a.css").read_bytes() == CSS_OUT


def test_dot_slash_output_targets_the_current_directory(tmp_path):
    """-o ./ *is* a directory destination rooted at the working directory."""
    # CATCHES: the DEBUG line and the resulting layout differ from -o '.';
    # here dir/b.js is written next to the source as dir/b.js.
    write(tmp_path, "dir/b.js", b"var b = 1;\n")
    res = run_minify(["-r", "dir", "-o", "./"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "dir/b.js"
    assert (tmp_path / "dir/b.js").read_bytes() == b"var b=1"


def test_nested_input_to_dot_writes_its_basename(tmp_path):
    """dir/b.js with -o . writes b.js into the working directory."""
    # CATCHES: keeping the dir/ component (dir/b.js) instead of using the
    # path relative to the input's own root directory.
    write(tmp_path, "dir/b.js", b"var b = 1;\n")
    res = run_minify(["dir/b.js", "-o", "."], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "dir/b.js to b.js"
    assert tree(tmp_path) == ["b.js", "dir", "dir/b.js"]
    assert (tmp_path / "b.js").read_bytes() == b"var b=1"


def test_nested_input_to_trailing_slash_output_keeps_basename(tmp_path):
    """dir/b.js -o out/ writes out/b.js, not out/dir/b.js."""
    # CATCHES: mirroring the whole input path instead of the part below the
    # input's root directory.
    write(tmp_path, "dir/b.js", b"var b = 1;\n")
    res = run_minify(["dir/b.js", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "dir/b.js to out/b.js"
    assert (tmp_path / "out/b.js").read_bytes() == b"var b=1"


def test_bundle_rejects_directory_destination(tmp_path):
    """--bundle demands stdout or a plain file, never a directory."""
    # CATCHES: silently bundling into out/ as if it were a file, or exiting 0.
    write(tmp_path, "a.js", b"var a=1")
    write(tmp_path, "b.js", b"var b=2")
    res = run_minify(["-b", "a.js", "b.js", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: --bundle requires destination to be stdout or a file\n"


def test_file_input_with_trailing_separator_breaks_directory_destination(tmp_path):
    """'a.css/' with a directory destination: the task dst becomes 'out'."""
    # CATCHES: the trailing separator on a *file* input makes the relative
    # path '.', so the output collides with the just-created directory.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css/", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'ERROR: open output file "out": open out: is a directory\n'
    assert (tmp_path / "out").is_dir()
