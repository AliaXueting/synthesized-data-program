"""CLI-level options and option conflicts: version, list, help, verbosity, --ext.

--version and --list print to stdout and go quiet under -q; --help prints
the usage summary, rendering already-scanned filter options with their
accumulated values; -vv turns on DEBUG diagnostics; --ext {ext:filetype}
teaches the walk a new extension. The second half pins every up-front
option-combination rejection with its exact diagnostic and exit code 1 (no
file is ever touched).
"""

import re

import pytest

from conftest import FINISHED_RE, run_minify, write

CSS = b"z { color: red }"
CSS_OUT = b"z{color:red}"

EXT_LIST = [
    ("asp", "text/asp"),
    ("css", "text/css"),
    ("ejs", "text/x-ejs-template"),
    ("gohtml", "text/x-go-template"),
    ("handlebars", "text/x-handlebars-template"),
    ("htm", "text/html"),
    ("html", "text/html"),
    ("js", "application/javascript"),
    ("json", "application/json"),
    ("mjs", "application/javascript"),
    ("mustache", "text/x-mustache-template"),
    ("php", "application/x-httpd-php"),
    ("rss", "application/rss+xml"),
    ("svg", "image/svg+xml"),
    ("tmpl", "text/x-template"),
    ("webmanifest", "application/manifest+json"),
    ("xhtml", "application/xhtml+xml"),
    ("xml", "text/xml"),
]


def test_version_prints_one_line(tmp_path):
    """--version prints exactly one 'minify <version>' line and exits 0."""
    # CATCHES: printing extra lines (usage, blank lines) or a wrong prefix
    # for the version banner. The version token itself is build-specific
    # ("1765945" for the reference, "built from source" for a plain `go
    # build`), so only the banner shape is pinned.
    res = run_minify(["--version"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    lines = res.lines()
    assert len(lines) == 1
    assert re.fullmatch(r"minify \S.*", lines[0])


def test_version_respects_quiet(tmp_path):
    """-q suppresses the --version banner entirely."""
    # CATCHES: honouring --version but ignoring the quiet flag that every
    # other stdout print in the tool obeys. The loud control run first proves
    # the banner is printed without -q, so a binary that never prints
    # anything cannot pass this test.
    loud = run_minify(["--version"], cwd=tmp_path)
    assert loud.returncode == 0
    assert loud.stderr == b""
    assert len(loud.lines()) == 1
    assert re.fullmatch(r"minify \S.*", loud.lines()[0])
    res = run_minify(["--version", "-q"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_list_prints_the_extension_map(tmp_path):
    """--list prints every accepted extension with its mimetype, sorted."""
    # CATCHES: a wrong sort order, a missing extension, or broken column
    # padding (keys are left-aligned to the longest key plus two spaces).
    res = run_minify(["--list"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    width = max(len(k) for k, _ in EXT_LIST) + 2
    assert res.lines() == ["%-*s%s" % (width, k, v) for k, v in EXT_LIST]


def test_list_respects_quiet(tmp_path):
    """-q suppresses the --list output entirely."""
    # CATCHES: printing the extension map even in quiet mode. The loud
    # control run first proves the full table is printed without -q, so a
    # binary that never prints anything cannot pass this test.
    loud = run_minify(["--list"], cwd=tmp_path)
    assert loud.returncode == 0
    assert loud.stderr == b""
    width = max(len(k) for k, _ in EXT_LIST) + 2
    assert loud.lines() == ["%-*s%s" % (width, k, v) for k, v in EXT_LIST]
    res = run_minify(["--list", "-q"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""


def test_help_prints_the_option_summary(tmp_path):
    """--help exits 0 and lists the file-handling options with their types."""
    # CATCHES: dropping the usage summary or the custom "[]string" types of
    # --match/--include/--exclude and the trailing inputs argument section,
    # all of which the reference prints to stdout with fixed padding.
    res = run_minify(["--help"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    lines = res.lines()
    # the program name is argv[0], only the shape of the line is stable
    assert lines[0].endswith(" [options] inputs...")
    assert "Options:" in lines
    assert ("      --match []string        "
            "Filename matching pattern, only matching filenames are processed"
            ) in lines
    assert ("      --include []string      "
            "Path inclusion pattern, includes paths previously excluded"
            ) in lines
    assert ("      --exclude []string      "
            "Path exclusion pattern, excludes paths from being processed"
            ) in lines
    assert ("  -o, --output string         "
            "Output file or directory, leave blank to use stdout") in lines
    assert lines[-2:] == [
        "Arguments:",
        "  inputs    Input files or directories, leave blank to use stdin",
    ]


def test_help_shows_scanned_filter_values(tmp_path):
    """--help renders already-scanned filter options with their values."""
    # CATCHES: losing the +/- markers that --include/--exclude prepend to the
    # one shared filter list (both options display that whole list), or the
    # =value rendering with quoting once the list holds two patterns.
    res = run_minify(["--match", "a.css", "--include", "x/**", "--exclude",
                      "y/**", "--help"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    lines = res.lines()
    assert "      --match=[a.css] []string" in lines
    assert "      --include='[+x/** -y/**]' []string" in lines
    assert "      --exclude='[+x/** -y/**]' []string" in lines
    # a header this long wraps its description onto an indented next line
    i = lines.index("      --match=[a.css] []string")
    assert lines[i + 1] == (" " * 30 + "Filename matching pattern, only "
                            "matching filenames are processed")


def test_verbose_twice_enables_debug_logging(tmp_path):
    """-vv adds DEBUG lines describing the inferred mimetype and output."""
    # CATCHES: wiring -vv to nothing (or to INFO only), losing the debug
    # diagnostics that name the mimetype source and the output file.
    write(tmp_path, "a.css", CSS)
    res = run_minify(["-vv", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT
    err = res.err_lines()
    assert err[0] == "DEBUG: infer mimetype from file extensions"
    assert err[1] == "DEBUG: minify to output file out.css"
    assert FINISHED_RE.match(err[2])
    assert len(err) == 3
    assert len(res.stats()) == 1


@pytest.mark.parametrize("mapping", ["{foo:css}", "{foo:text/css}"])
def test_ext_maps_a_custom_extension(tmp_path, mapping):
    """--ext {ext:filetype} makes .foo files minify as that filetype."""
    # CATCHES: ignoring the mapping (so data.foo is skipped as unknown) or
    # accepting only the short filetype form and not the mimetype one.
    write(tmp_path, "in/data.foo", CSS)
    write(tmp_path, "in/a.css", CSS)
    res = run_minify(["--ext", mapping, "-r", "-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (tmp_path / "out/data.foo").read_bytes() == CSS_OUT
    assert (tmp_path / "out/a.css").read_bytes() == CSS_OUT


def test_ext_with_unknown_filetype_fails_that_file(tmp_path):
    """An --ext value that is no known filetype fails with rc 1."""
    # CATCHES: skipping the file instead of erroring, or erroring without
    # writing the original content through to the destination.
    write(tmp_path, "in/data.foo", CSS)
    write(tmp_path, "in/a.css", CSS)
    res = run_minify(["--ext", "{foo:bar}", "-r", "-o", "out/", "in/"],
                     cwd=tmp_path)
    assert res.returncode == 1
    assert res.err_lines() == [
        "ERROR: cannot minify in/data.foo: minifier does not exist for mimetype"
    ]
    assert (tmp_path / "out/data.foo").read_bytes() == CSS
    assert (tmp_path / "out/a.css").read_bytes() == CSS_OUT


@pytest.mark.parametrize("args,expected_error", [
    (["-i", "-o", "out.css", "a.css"],
     "ERROR: cannot specify both --inplace and --output"),
    (["-i", "--type", "css"],
     "ERROR: --inplace doesn't work with stdin, specify input"),
    (["-w", "--type", "css"],
     "ERROR: --watch doesn't work with stdin and stdout, specify input and output"),
    (["-s", "a.css"],
     "ERROR: --sync doesn't work with stdin and stdout, specify input and output"),
    (["-b", "--type", "css"],
     "ERROR: --bundle doesn't work with stdin, specify input"),
    (["-r", "--type", "css"],
     "ERROR: --recursive doesn't work with stdin, specify input"),
    (["-r", "-o", "-", "in/"],
     "ERROR: --recursive doesn't work with stdout, specify output or use --bundle"),
    (["-s", "--type", "css", "-r", "-o", "out/", "in/"],
     "ERROR: must specify either --sync or --type"),
    (["a.css", "b.css"],
     "ERROR: must specify --bundle for multiple input files with stdout destination"),
    (["-b", "-i", "a.css", "b.css"],
     "ERROR: --bundle cannot be used together with --inplace"),
    (["--url", ":", "-o", "out.css", "a.css"],
     'ERROR: parse ":": missing protocol scheme'),
])
def test_option_combination_is_rejected(tmp_path, args, expected_error):
    """Incompatible option combinations fail before any file is opened."""
    # CATCHES: missing one of the up-front rejections (so the run proceeds
    # and creates files), or wording the diagnostic differently.
    write(tmp_path, "a.css", CSS)
    write(tmp_path, "b.css", CSS)
    write(tmp_path, "in/keep.css", CSS)
    res = run_minify(args, cwd=tmp_path, stdin=b"z{color:red}")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.err_lines() == [expected_error]
    # nothing was written anywhere
    assert not (tmp_path / "out.css").exists()
    assert not (tmp_path / "out").exists()
    assert (tmp_path / "a.css").read_bytes() == CSS
