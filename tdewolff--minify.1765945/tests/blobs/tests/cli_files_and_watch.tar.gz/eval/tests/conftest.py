"""Shared helpers for the cli_files_and_watch test module.

Every test runs the minify binary as a black box through ``run_minify`` (or
``run_watch`` for --watch), which resolves the executable from
``PROGRAMGYM_EXECUTABLE`` and always feeds the child a pinned, hermetic
environment plus a closed stdin pipe.
"""

from __future__ import annotations

import os
import re
import signal
import stat
import subprocess
import time
from pathlib import Path

# Statistics line, e.g.
#   "( 26 µs,   23 B,   15 B,  65.2%, 0.9 MB/s) - a.css to out.css"
# The duration and speed fields are timing dependent, so tests match the shape
# with this regexp and then compare the deterministic byte/ratio fields.
STATS_RE = re.compile(
    r"^\(\s*(?P<dur>\d+(?:\.\d+)?\s*(?:ns|µs|ms|s)),"
    r"\s*(?P<rin>\d+(?:\.\d+)?\s*[kMG]?B),"
    r"\s*(?P<rout>\d+(?:\.\d+)?\s*[kMG]?B),"
    r"\s*(?P<ratio>\d+\.\d+)%,"
    r"\s*(?P<speed>\d+(?:\.\d+)?\s*[kMG]?B)/s\)"
    r" - (?P<names>.+)$"
)

# "INFO: finished in 131.766µs" / "INFO: finished in 1.2ms"
FINISHED_RE = re.compile(r"^INFO: finished in \d+(\.\d+)?(ns|µs|ms|s)$")


def _executable() -> Path:
    """Absolute path of the binary under test."""
    raw = os.environ.get("PROGRAMGYM_EXECUTABLE") or "executable"
    path = Path(raw)
    if not path.is_absolute():
        # run.sh starts pytest in the module root, so a relative setting
        # resolves against the directory that contains eval/tests/.
        rooted = Path(__file__).resolve().parents[2] / raw
        if rooted.exists():
            return rooted
    return path


def _child_env() -> dict:
    """Pinned child environment, forwarding the coverage hook when set."""
    env = {
        "PATH": "/usr/bin:/bin",
        "LC_ALL": "C.UTF-8",
        "LANG": "C.UTF-8",
        "HOME": "/nonexistent",
        "TMPDIR": "/tmp",
    }
    # Coverage instrumentation hook: the pipeline rebuilds the reference with
    # -cover and points GOCOVERDIR at a counter directory; without forwarding
    # it the module's coverage report would come out empty.
    cov_env = dict([("GOCOVERDIR", v) for v in [os.environ.get("GOCOVERDIR")] if v])
    env.update(cov_env)
    return env


class Result:
    """One minify invocation: exit status plus raw and decoded output."""

    def __init__(self, returncode: int, stdout: bytes, stderr: bytes) -> None:
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
        self.out = stdout.decode("utf-8", errors="replace")
        self.err = stderr.decode("utf-8", errors="replace")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return ("Result(returncode=%r, stdout=%r, stderr=%r)"
                % (self.returncode, self.stdout, self.stderr))

    def lines(self):
        """stdout split into lines with the trailing newline dropped."""
        return self.out.split("\n")[:-1] if self.out.endswith("\n") else self.out.split("\n")

    def err_lines(self):
        """stderr split into lines with the trailing newline dropped."""
        return self.err.split("\n")[:-1] if self.err.endswith("\n") else self.err.split("\n")

    def stats(self):
        """Parsed statistics lines: [{dur, rin, rout, ratio, speed, names}]."""
        found = []
        for line in self.lines():
            m = STATS_RE.match(line)
            if m:
                found.append(m.groupdict())
        return found


def run_minify(args, cwd, stdin: bytes = b"", timeout: float = 20.0) -> Result:
    """Run the binary under test once in ``cwd`` and return its Result."""
    argv = [str(_executable())] + [str(a) for a in args]
    proc = subprocess.run(
        argv,
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd),
        env=_child_env(),
        timeout=timeout,
    )
    return Result(proc.returncode, proc.stdout, proc.stderr)


def run_watch(args, cwd, actions=None, settle: float = 0.6,
              wait: float = 1.3, timeout: float = 8.0) -> Result:
    """Run the binary with --watch, apply ``actions``, then SIGINT it.

    Returns the collected Result so tests can assert on the full transcript of
    statistics lines the watcher printed before it was interrupted.
    """
    argv = [str(_executable())] + [str(a) for a in args]
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd),
        env=_child_env(),
    )
    try:
        time.sleep(settle)
        if actions is not None:
            actions()
        time.sleep(wait)
        proc.send_signal(signal.SIGINT)
        out, err = proc.communicate(timeout=timeout)
    finally:
        if proc.poll() is None:  # pragma: no cover - only on a broken build
            proc.kill()
            proc.communicate()
    return Result(proc.returncode, out, err)


def write(directory, rel: str, content, mode: int = None) -> Path:
    """Create ``rel`` inside ``directory`` (usually tmp_path) and return it."""
    path = Path(directory) / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, str):
        content = content.encode("utf-8")
    path.write_bytes(content)
    if mode is not None:
        os.chmod(path, mode)
    return path


def symlink(directory, target: str, rel: str) -> Path:
    """Create a symlink at ``directory/rel`` pointing at ``target``."""
    path = Path(directory) / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    os.symlink(target, path)
    return path


def tree(directory):
    """Sorted relative paths of every file/dir under ``directory``."""
    base = Path(directory)
    out = []
    for root, dirs, files in os.walk(base):
        dirs.sort()
        for name in sorted(dirs):
            out.append(os.path.normpath(os.path.relpath(os.path.join(root, name), base)))
        for name in sorted(files):
            out.append(os.path.normpath(os.path.relpath(os.path.join(root, name), base)))
    return sorted(out)


def file_modes(directory):
    """Map of relative path -> octal permission bits for regular files."""
    base = Path(directory)
    out = {}
    for root, dirs, files in os.walk(base):
        dirs.sort()
        for name in sorted(files):
            p = os.path.join(root, name)
            if os.path.islink(p):
                continue
            rel = os.path.normpath(os.path.relpath(p, base))
            out[rel] = oct(stat.S_IMODE(os.stat(p).st_mode))
    return out


def dir_modes(directory):
    """Map of relative dir path -> octal permission bits for directories."""
    base = Path(directory)
    out = {}
    for root, dirs, files in os.walk(base):
        dirs.sort()
        for name in sorted(dirs):
            p = os.path.join(root, name)
            rel = os.path.normpath(os.path.relpath(p, base))
            out[rel] = oct(stat.S_IMODE(os.stat(p).st_mode))
    return out
