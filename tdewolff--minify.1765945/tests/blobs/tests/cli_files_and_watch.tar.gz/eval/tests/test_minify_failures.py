"""Failure paths: minify errors, unreadable inputs, unknown extensions.

When minification itself fails, the original bytes are written through to the
destination, the statistics line still prints (100% ratio) and the exit code
is 1, with a three-line diagnostic (message, source excerpt, caret) on
stderr. Inputs that cannot even be stat-ed are reported on stderr but do not
fail the run.
"""

import pytest

from conftest import run_minify, write

CSS_IN = b"body {\n  color: red;\n}\n"
JS_BAD = b'var a = "unterminated'
BAD_STDERR = (b"ERROR: cannot minify %s: unterminated string literal in "
              b"expression on line 1 and column 9\n"
              b'    1: var a = "unterminated\n'
              b"               ^\n")


def test_unterminated_string_writes_original_through(tmp_path):
    """A JS syntax error: passthrough, 100% stats line, exit 1."""
    # CATCHES: writing an empty output (or none at all) on minify failure
    # instead of the original bytes, exiting 0, or printing the diagnostic on
    # stdout instead of stderr.
    write(tmp_path, "u.js", JS_BAD)
    res = run_minify(["u.js", "-o", "out.js"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == BAD_STDERR % b"u.js"
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["rin"] == "21 B"
    assert stats[0]["rout"] == "21 B"
    assert stats[0]["ratio"] == "100.0"
    assert stats[0]["names"] == "u.js to out.js"
    assert (tmp_path / "out.js").read_bytes() == JS_BAD


def test_failing_in_place_minify_keeps_content_and_drops_backup(tmp_path):
    """In-place failure: the original survives and no .bak is left behind."""
    # CATCHES: restoring from .bak into a half-written file, keeping the
    # backup around after the run, or printing a destination in the stats
    # line of an in-place task.
    write(tmp_path, "u.js", JS_BAD)
    res = run_minify(["u.js", "-o", "u.js"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == BAD_STDERR % b"u.js"
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "u.js"
    assert (tmp_path / "u.js").read_bytes() == JS_BAD
    assert not (tmp_path / "u.js.bak").exists()


def test_missing_input_reports_stat_error_and_exits_zero(tmp_path):
    """A nonexistent input is an ERROR line but exit status 0."""
    # CATCHES: failing the whole run (exit 1) for a missing input file, or
    # creating the output file despite having nothing to minify into it.
    res = run_minify(["missing.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b"ERROR: stat missing.css: no such file or directory\n"
    assert not (tmp_path / "out.css").exists()


@pytest.mark.parametrize("extra,level", [
    ([], b"ERROR"),
    (["--sync"], b"WARNING"),
])
def test_unknown_extension_is_rejected_before_output(tmp_path, extra, level):
    """A .txt input cannot infer a mimetype: error, or warning with --sync."""
    # CATCHES: minifying unknown extensions anyway, or forgetting that --sync
    # only downgrades the diagnostic to a warning while the exit code stays 1
    # and no output file is created in either flavour.
    write(tmp_path, "note.txt", b"hello notes")
    res = run_minify(extra + ["note.txt", "-o", "out.txt"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (level +
                          b": cannot infer mimetype from extension in note.txt,"
                          b" set --type explicitly\n")
    assert not (tmp_path / "out.txt").exists()
