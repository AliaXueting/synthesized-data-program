"""Hidden files: dot-files are skipped while walking unless -a/--all is given.

Inside a recursive walk, files and directories whose name starts with a dot
are omitted by default (a hidden directory prunes the whole subtree), while
-a/--all includes them. A hidden file named explicitly as a top-level input
is minified even without -a, because the hidden check only lives in the walk.
"""

import pytest

from conftest import run_minify, write

CSS_IN = b"body {\n  color: red;\n}\n"
CSS_OUT = b"body{color:red}"


@pytest.mark.parametrize("all_flag,expected", [
    ([], ["in/vis.css to out/vis.css"]),
    (["-a"], ["in/.hid.css to out/.hid.css", "in/vis.css to out/vis.css"]),
])
def test_walk_hidden_files_need_all(tmp_path, all_flag, expected):
    """Dot-files in a walked directory appear only with -a/--all."""
    # CATCHES: processing .hid.css without -a, or dropping it even with -a,
    # which changes both the stats lines and the output tree.
    write(tmp_path, "in/.hid.css", CSS_IN)
    write(tmp_path, "in/vis.css", CSS_IN)
    res = run_minify(["-r"] + all_flag + ["-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert sorted(s["names"] for s in res.stats()) == expected
    present = sorted(p.name for p in (tmp_path / "out").iterdir())
    assert present == sorted(n.split(" to ")[0].split("/")[-1] for n in expected)
    for rel in (n.split(" to ")[0] for n in expected):
        assert (tmp_path / "out" / rel.split("/", 1)[1]).read_bytes() == CSS_OUT


@pytest.mark.parametrize("all_flag,expected", [
    ([], []),
    (["-a"], ["in/.hd/x.css to out/.hd/x.css", "in/.root.css to out/.root.css"]),
])
def test_walk_hidden_directories_need_all(tmp_path, all_flag, expected):
    """A hidden directory prunes its whole subtree unless -a is given."""
    # CATCHES: descending into .hd without -a (SkipDir missing), or failing
    # to create the .hd directory inside the destination with -a.
    write(tmp_path, "in/.hd/x.css", CSS_IN)
    write(tmp_path, "in/.root.css", CSS_IN)
    res = run_minify(["-r"] + all_flag + ["-o", "out/", "in/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    if expected:
        assert sorted(s["names"] for s in res.stats()) == expected
        assert sorted(str(p.relative_to(tmp_path / "out")) for p in
                      (tmp_path / "out").rglob("*") if p.is_file()) == \
            [".hd/x.css", ".root.css"]
    else:
        # the destination root is still created, but nothing lands in it
        assert res.stdout == b""
        assert list((tmp_path / "out").iterdir()) == []


def test_explicit_hidden_input_is_minified_without_all(tmp_path):
    """A hidden file named directly as input is minified with no -a at all."""
    # CATCHES: applying the walk's hidden-file rule to top-level inputs too,
    # which would drop .hid.css instead of minifying it.
    write(tmp_path, ".hid.css", CSS_IN)
    res = run_minify([".hid.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT
    assert [s["names"] for s in res.stats()] == [".hid.css to out.css"]
