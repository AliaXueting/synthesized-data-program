"""Symlinks and --sync: dereference by default, recreate links with --sync.

Without --preserve links a symlink is followed and minified as its target,
both as a top-level input and inside a walked directory. --preserve links
without --sync is an error; together with --sync the link itself is copied
(createSymlink) with its raw target string, replacing any existing
destination. --sync also copies non-minifiable files found in walks verbatim.
"""

import os

from conftest import FINISHED_RE, run_minify, symlink, write

CSS_IN = b"body {\n  color: red;\n}\n"
CSS_OUT = b"body{color:red}"


def test_top_level_symlink_is_dereferenced_and_minified(tmp_path):
    """A symlink input is followed: the target's bytes are minified."""
    # CATCHES: refusing symlinks, or copying/recreating the link instead of
    # reading through it and minifying the target file's contents.
    write(tmp_path, "real.css", CSS_IN)
    symlink(tmp_path, "real.css", "link.css")
    res = run_minify(["link.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "link.css to out.css"
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT
    assert (tmp_path / "out.css").is_file()
    assert not (tmp_path / "out.css").is_symlink()


def test_preserve_links_without_sync_rejects_symlink(tmp_path):
    """--preserve links turns a symlink input into a hard error."""
    # CATCHES: silently dereferencing the link (minifying the target) or
    # silently skipping it instead of failing with this exact diagnostic.
    write(tmp_path, "real.css", CSS_IN)
    symlink(tmp_path, "real.css", "link.css")
    res = run_minify(["--preserve", "links", "link.css", "-o", "out.css"],
                     cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == \
        b"ERROR: --sync not specified, omitting symbolic link link.css\n"
    assert not (tmp_path / "out.css").exists()


def test_sync_preserve_links_copies_symlink_with_raw_target(tmp_path):
    """--sync --preserve links recreates the link, target string verbatim."""
    # CATCHES: resolving the link to its destination (copying or minifying the
    # target's bytes) instead of symlinking to the identical raw target path;
    # the copy is silent: no statistics line is printed for it.
    write(tmp_path, "real.css", CSS_IN)
    symlink(tmp_path, "real.css", "link.css")
    (tmp_path / "out").mkdir()
    res = run_minify(["--sync", "--preserve", "links", "link.css", "-o", "out/"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    assert (tmp_path / "out/link.css").is_symlink()
    assert os.readlink(tmp_path / "out/link.css") == "real.css"


def test_sync_preserve_links_replaces_existing_output_file(tmp_path):
    """An existing file at the destination is replaced by the symlink."""
    # CATCHES: failing on the existing destination (EEXIST) or writing the
    # copied bytes through it instead of removing it and then linking.
    write(tmp_path, "real.css", CSS_IN)
    symlink(tmp_path, "real.css", "link.css")
    write(tmp_path, "out.css", b"junk contents")
    res = run_minify(["--sync", "--preserve", "links", "link.css", "-o", "out.css"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert (tmp_path / "out.css").is_symlink()
    assert os.readlink(tmp_path / "out.css") == "real.css"


def test_sync_preserve_links_copies_dangling_symlink_from_walk(tmp_path):
    """Even a dangling link inside a walked directory is copied verbatim."""
    # CATCHES: stat-ing the link (which errors and skips the task) instead of
    # lstat-ing it and recreating the dangling link under the destination.
    write(tmp_path, "dir/b.css", CSS_IN)
    symlink(tmp_path, "nowhere.css", "dir/dang.css")
    res = run_minify(["-r", "--sync", "--preserve", "links", "dir", "-o", "out/"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "out/dir/b.css").read_bytes() == CSS_OUT
    assert (tmp_path / "out/dir/dang.css").is_symlink()
    assert os.readlink(tmp_path / "out/dir/dang.css") == "nowhere.css"


def test_dangling_symlink_input_is_stat_error_with_zero_exit(tmp_path):
    """A dangling top-level link prints an ERROR yet exits 0."""
    # CATCHES: failing the whole run (exit 1) for the unreadable input; the
    # stat error only drops that task, it does not count as a failure.
    symlink(tmp_path, "nowhere.css", "dang.css")
    res = run_minify(["dang.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b"ERROR: stat dang.css: no such file or directory\n"
    assert not (tmp_path / "out.css").exists()


def test_symlink_inside_directory_walk_is_dereferenced(tmp_path):
    """Links found while walking are minified like their targets."""
    # CATCHES: skipping symlinks during the walk (no out/dir/link.css at all)
    # or copying them instead of minifying through them.
    write(tmp_path, "dir/b.css", CSS_IN)
    symlink(tmp_path, "b.css", "dir/link.css")
    res = run_minify(["-r", "dir", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert sorted(s["names"] for s in res.stats()) == [
        "dir/b.css to out/dir/b.css", "dir/link.css to out/dir/link.css"]
    assert (tmp_path / "out/dir/link.css").read_bytes() == CSS_OUT
    assert not (tmp_path / "out/dir/link.css").is_symlink()


def test_symlink_to_directory_input_targets_a_file_destination(tmp_path):
    """A symlink to a dir does not make -o a directory: IsDir lstats it."""
    # CATCHES: following the link when choosing the destination flavour, which
    # would create outf/ as a directory instead of a regular output file that
    # the walked files are written into.
    write(tmp_path, "sub/one.css", CSS_IN)
    symlink(tmp_path, "sub", "linkdir")
    res = run_minify(["-r", "linkdir", "-o", "outf"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "linkdir/one.css to outf"
    assert (tmp_path / "outf").is_file()
    assert (tmp_path / "outf").read_bytes() == CSS_OUT
    # the same walk with the real directory makes the destination a directory
    res2 = run_minify(["-r", "sub", "-o", "outf2"], cwd=tmp_path)
    assert res2.returncode == 0
    assert res2.stats()[0]["names"] == "sub/one.css to outf2/sub/one.css"
    assert (tmp_path / "outf2").is_dir()


def test_sync_copies_non_minifiable_files_verbatim(tmp_path):
    """--sync copies unknown extensions byte-for-byte, minifies the rest."""
    # CATCHES: skipping a.txt entirely, minifying it, or printing a statistics
    # line for the copied file (copies are silent on stdout), and losing the
    # copied file's source mode and timestamps.
    write(tmp_path, "dir/a.txt", b"hello notes", mode=0o640)
    os.utime(tmp_path / "dir/a.txt", (1000000000, 1000000000))
    write(tmp_path, "dir/b.css", CSS_IN)
    res = run_minify(["-r", "--sync", "dir", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert [s["names"] for s in res.stats()] == ["dir/b.css to out/dir/b.css"]
    assert (tmp_path / "out/dir/a.txt").read_bytes() == b"hello notes"
    assert (tmp_path / "out/dir/b.css").read_bytes() == CSS_OUT
    assert oct(os.stat(tmp_path / "out/dir/a.txt").st_mode & 0o777) == "0o640"
    assert int(os.stat(tmp_path / "out/dir/a.txt").st_mtime) == 1000000000


def test_sync_copy_lines_are_info_level(tmp_path):
    """-v upgrades the silent copy to an INFO line plus the run summary."""
    # CATCHES: printing copy progress on stdout (it belongs on stderr behind
    # -v) or dropping the 'INFO: finished in ...' summary line entirely.
    write(tmp_path, "dir/a.txt", b"hello notes")
    write(tmp_path, "dir/b.css", CSS_IN)
    res = run_minify(["-r", "--sync", "-v", "dir", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    lines = res.err_lines()
    assert lines[0] == "INFO: copy dir/a.txt to out/dir/a.txt"
    assert len(lines) == 2
    assert FINISHED_RE.match(lines[1])
