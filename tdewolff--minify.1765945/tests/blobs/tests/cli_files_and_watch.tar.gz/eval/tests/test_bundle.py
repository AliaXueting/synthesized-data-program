"""--bundle: several inputs concatenated into one stream (concatFileReader).

JavaScript inputs are joined with a ';\n' separator while other filetypes are
glued directly, the statistics line names every source '(a + b + ...)', and a
minify failure writes the original concatenated stream through to the
destination. Destination handling reuses the single-file paths: missing parent
directories are created 0755 and same-file detection renames to '<file>.bak'.
"""

import os

import pytest

from conftest import run_minify, write

CSS_IN = b"body {\n  color: red;\n}\n"
JS_GOOD = b"var g=1"
JS_BAD = b'var a = "unterminated'


def test_bundle_joins_js_inputs_with_semicolon_and_newline(tmp_path):
    """A failing bundle writes through the original stream, separator visible."""
    # CATCHES: joining with a bare newline or nothing at all; the passthrough
    # on minify failure must contain the exact ';\n' bytes between the inputs
    # (and the error position moves to line 2 because of the newline).
    write(tmp_path, "g.js", JS_GOOD)
    write(tmp_path, "u.js", JS_BAD)
    res = run_minify(["-b", "g.js", "u.js", "-o", "out.js"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stderr == (
        b"ERROR: cannot minify (g.js + u.js): unterminated string literal "
        b"in expression on line 2 and column 9\n"
        b'    2: var a = "unterminated\n'
        b"               ^\n")
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["rin"] == "30 B"
    assert stats[0]["rout"] == "30 B"
    assert stats[0]["ratio"] == "100.0"
    assert stats[0]["names"] == "(g.js + u.js) to out.js"
    assert (tmp_path / "out.js").read_bytes() == b'var g=1;\nvar a = "unterminated'


def test_bundle_of_two_empty_js_files_counts_only_the_separator(tmp_path):
    """Two empty JS inputs make a 2-byte stream: exactly one ';\n'."""
    # CATCHES: skipping the separator when the surrounding files are empty, or
    # emitting separators around every file (0 B or 4 B input instead of 2 B).
    write(tmp_path, "e1.js", b"")
    write(tmp_path, "e2.js", b"")
    res = run_minify(["-b", "e1.js", "e2.js", "-o", "out.js"], cwd=tmp_path)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["rin"] == "2 B"
    assert stats[0]["rout"] == "0 B"
    assert stats[0]["ratio"] == "0.0"
    assert (tmp_path / "out.js").read_bytes() == b""


@pytest.mark.parametrize("order", [["e.js", "p.js"], ["p.js", "e.js"]])
def test_bundle_inserts_the_separator_around_empty_files(tmp_path, order):
    """An empty neighbour on either side still contributes the 2-byte join."""
    # CATCHES: only inserting the separator between two non-empty files, which
    # would report 14 B instead of 16 B for 'console.log(1)' next to an empty
    # file (the leading ';' of the empty-first order is dropped by minifying).
    write(tmp_path, "e.js", b"")
    write(tmp_path, "p.js", b"console.log(1)")
    res = run_minify(["-b"] + order + ["-o", "out.js"], cwd=tmp_path)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["rin"] == "16 B"
    assert stats[0]["names"] == "(%s + %s) to out.js" % tuple(order)
    assert (tmp_path / "out.js").read_bytes() == b"console.log(1)"


def test_bundle_of_css_files_concatenates_without_separator(tmp_path):
    """Only JavaScript gets a separator; CSS inputs are glued directly."""
    # CATCHES: applying the JavaScript ';\n' join to every filetype, which
    # would count 28 B in and emit a stray ';' between the minified blocks.
    write(tmp_path, "x.css", b"body{color:red}")
    write(tmp_path, "y.css", b"p{margin:0}")
    res = run_minify(["-b", "x.css", "y.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["rin"] == "26 B"
    assert stats[0]["names"] == "(x.css + y.css) to out.css"
    assert (tmp_path / "out.css").read_bytes() == b"body{color:red}p{margin:0}"


def test_bundle_to_stdout_has_no_statistics_line(tmp_path):
    """A stdout bundle prints only the minified stream, never a stats line."""
    # CATCHES: treating '-o -' as a literal file name, or appending the
    # progress line that only real file destinations print.
    write(tmp_path, "a.js", b"var a=1")
    write(tmp_path, "b.js", b"var b=2")
    res = run_minify(["-b", "a.js", "b.js", "-o", "-"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"var a=1,b=2"
    assert res.stderr == b""
    assert not (tmp_path / "-").exists()


def test_bundle_with_mismatched_mimetypes_fails_before_writing(tmp_path):
    """css + js without --type aborts with a warning and no output file."""
    # CATCHES: minifying the bundle with the first file's mimetype (or with
    # each file's own mimetype) instead of refusing the unequal concatenation
    # before the destination is ever created.
    write(tmp_path, "x.css", b"body{color:red}")
    write(tmp_path, "a.js", b"var a=1")
    res = run_minify(["-b", "x.css", "a.js", "-o", "out.js"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (b"WARNING: inferred mimetype application/javascript "
                          b"of a.js for concatenation unequal to previous "
                          b"mimetypes, set --type explicitly\n")
    assert not (tmp_path / "out.js").exists()


def test_bundle_missing_input_is_dropped_and_run_succeeds(tmp_path):
    """A missing bundle member is reported but the rest are still bundled."""
    # CATCHES: aborting the whole run for the missing file, or bundling an
    # empty placeholder for it (the stats line must skip it entirely).
    write(tmp_path, "a.js", b"var a=1")
    write(tmp_path, "b.js", b"var b=2")
    res = run_minify(["-b", "a.js", "missing.js", "b.js", "-o", "out.js"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b"ERROR: stat missing.js: no such file or directory\n"
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "(a.js + b.js) to out.js"
    assert (tmp_path / "out.js").read_bytes() == b"var a=1,b=2"


def test_bundle_destination_equal_to_second_input(tmp_path):
    """-o naming a later input renames it to .bak while bundling."""
    # CATCHES: truncating the shared destination before reading it (empty or
    # half-missing output) or leaving the '<file>.bak' backup behind.
    write(tmp_path, "a.js", b"var a=1")
    write(tmp_path, "b.js", b"var b=2")
    res = run_minify(["-b", "a.js", "b.js", "-o", "b.js"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "(a.js + b.js) to b.js"
    assert (tmp_path / "b.js").read_bytes() == b"var a=1,b=2"
    assert (tmp_path / "a.js").read_bytes() == b"var a=1"
    assert not (tmp_path / "b.js.bak").exists()


def test_bundle_in_place_overwrites_the_first_input(tmp_path):
    """-o naming the first input bundles the rest into it."""
    # CATCHES: same-file detection that only scans the later inputs, which
    # would truncate the first source before it is ever read.
    write(tmp_path, "a.js", b"var a=1")
    write(tmp_path, "b.js", b"var b=2")
    res = run_minify(["-b", "a.js", "b.js", "-o", "a.js"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stats()[0]["names"] == "(a.js + b.js) to a.js"
    assert (tmp_path / "a.js").read_bytes() == b"var a=1,b=2"
    assert (tmp_path / "b.js").read_bytes() == b"var b=2"
    assert not (tmp_path / "a.js.bak").exists()


def test_bundle_creates_missing_output_directories(tmp_path):
    """The bundle destination's parent directories are created 0755."""
    # CATCHES: requiring the output directory to pre-exist for bundles, or
    # creating it with permissions other than 0755.
    write(tmp_path, "a.js", b"var a=1")
    write(tmp_path, "b.js", b"var b=2")
    res = run_minify(["-b", "a.js", "b.js", "-o", "new/deep/out.js"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "new/deep/out.js").read_bytes() == b"var a=1,b=2"
    assert oct(os.stat(tmp_path / "new").st_mode & 0o777) == "0o755"
    assert oct(os.stat(tmp_path / "new/deep").st_mode & 0o777) == "0o755"


def test_bundle_mixed_source_permissions_warns_and_keeps_creation_mode(tmp_path):
    """Unequal source modes skip the chmod and warn about it."""
    # CATCHES: chmodding the destination to one of the differing source modes
    # instead of leaving the 0644 creation mode in place with this warning.
    write(tmp_path, "a.js", b"var a=1", mode=0o644)
    write(tmp_path, "b.js", b"var b=2", mode=0o600)
    res = run_minify(["-b", "a.js", "b.js", "-o", "out.js"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == \
        b"WARNING: src permissions are different, won't set dst permissions\n"
    assert (tmp_path / "out.js").read_bytes() == b"var a=1,b=2"
    assert oct(os.stat(tmp_path / "out.js").st_mode & 0o777) == "0o644"
