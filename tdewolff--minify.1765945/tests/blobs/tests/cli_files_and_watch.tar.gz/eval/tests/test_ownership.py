"""Ownership preservation: the output is chowned to the source's uid/gid.

On Unix the default --preserve set is mode+ownership+timestamps, so a plain
file-to-file run chowns the destination to the input's owner. A bundle with
sources of differing owners refuses with a warning and keeps the destination
owner, created subdirectories inherit the source directory's owner (at every
depth, while the destination root stays root-owned), an explicit --preserve
ownership adds to rather than replaces the default set, --sync copies carry
the source owner but copied symlinks do not, and --inplace preserves nothing
at all. An explicit --preserve next to stdin or --inplace is rejected
outright.
"""

import os

import pytest

from conftest import run_minify, write

CSS_IN = b"body {\n  color: red;\n}\n"
CSS_OUT = b"body{color:red}"
UID, GID = 8342, 8343
OLD = (1000000000, 1000000000)

requires_root = pytest.mark.skipif(
    os.geteuid() != 0, reason="ownership tests chown files, which requires root"
)


def _owner(path):
    st = os.stat(path)
    return st.st_uid, st.st_gid


def _lowner(path):
    st = os.lstat(path)
    return st.st_uid, st.st_gid


@requires_root
def test_default_preserves_source_ownership(tmp_path):
    """Without any flag the destination is chowned to the input's uid/gid."""
    # CATCHES: keeping the running user as the output owner instead of
    # chowning the destination to the source file's 8342:8343.
    write(tmp_path, "a.css", CSS_IN, mode=0o640)
    os.chown(tmp_path / "a.css", UID, GID)
    os.utime(tmp_path / "a.css", OLD)
    res = run_minify(["a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT
    assert _owner(tmp_path / "out.css") == (UID, GID)
    # the default set still carries mode and timestamps along
    assert oct(os.stat(tmp_path / "out.css").st_mode & 0o777) == "0o640"
    assert int(os.stat(tmp_path / "out.css").st_mtime) == 1000000000


@requires_root
def test_preserve_ownership_flag_sets_dst_owner(tmp_path):
    """--preserve ownership explicitly chowns the destination."""
    # CATCHES: accepting the ownership option but never applying it, so the
    # output stays owned by the invoking user instead of 8342:8343.
    write(tmp_path, "a.css", CSS_IN)
    os.chown(tmp_path / "a.css", UID, GID)
    res = run_minify(["--preserve", "ownership", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _owner(tmp_path / "out.css") == (UID, GID)


@requires_root
def test_explicit_preserve_ownership_keeps_mode_and_timestamps(tmp_path):
    """--preserve ownership adds to the default set, replacing nothing."""
    # CATCHES: treating an explicit --preserve value as the complete set, so
    # the destination would fall back to creation attributes (0644, fresh
    # mtime) instead of keeping the source's 0640 and its 1000000000 mtime.
    write(tmp_path, "a.css", CSS_IN, mode=0o640)
    os.chown(tmp_path / "a.css", UID, GID)
    os.utime(tmp_path / "a.css", OLD)
    res = run_minify(["--preserve", "ownership", "a.css", "-o", "out.css"],
                     cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT
    assert _owner(tmp_path / "out.css") == (UID, GID)
    assert oct(os.stat(tmp_path / "out.css").st_mode & 0o777) == "0o640"
    assert int(os.stat(tmp_path / "out.css").st_mtime) == 1000000000


@requires_root
def test_preserve_all_includes_ownership(tmp_path):
    """--preserve all turns on ownership preservation as well."""
    # CATCHES: mapping "all" to mode+timestamps only and silently dropping
    # the ownership member of the preservation set.
    write(tmp_path, "a.css", CSS_IN, mode=0o600)
    os.chown(tmp_path / "a.css", UID, GID)
    res = run_minify(["--preserve", "all", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _owner(tmp_path / "out.css") == (UID, GID)
    assert oct(os.stat(tmp_path / "out.css").st_mode & 0o777) == "0o600"


@requires_root
def test_bundle_with_different_owners_warns_and_keeps_dst_owner(tmp_path):
    """A bundle whose inputs have different owners keeps the dst owner."""
    # CATCHES: chowning the bundle destination to just the first source's
    # owner instead of warning and leaving the destination untouched.
    write(tmp_path, "a.css", b"a{color:red}")
    write(tmp_path, "b.css", b"b{color:blue}")
    os.chown(tmp_path / "a.css", UID, GID)
    res = run_minify(["-b", "a.css", "b.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.err_lines() == [
        "WARNING: src ownership is different, won't set dst ownership"
    ]
    assert _owner(tmp_path / "out.css") == (0, 0)
    assert (tmp_path / "out.css").read_bytes() == b"a{color:red}b{color:blue}"


@requires_root
def test_bundle_with_matching_owners_sets_dst_owner(tmp_path):
    """A bundle whose inputs share an owner chowns the destination to it."""
    # CATCHES: skipping the ownership check for bundles entirely, so even
    # agreeing sources never propagate their owner to the destination.
    write(tmp_path, "a.css", b"a{color:red}")
    write(tmp_path, "b.css", b"b{color:blue}")
    os.chown(tmp_path / "a.css", UID, GID)
    os.chown(tmp_path / "b.css", UID, GID)
    res = run_minify(["-b", "a.css", "b.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _owner(tmp_path / "out.css") == (UID, GID)


@requires_root
def test_created_subdirectory_inherits_source_directory_ownership(tmp_path):
    """out/sub is chowned to in/sub's owner; the out/ root is not."""
    # CATCHES: only chowning output files, never the freshly created parent
    # directories (or wrongly including the destination root itself).
    write(tmp_path, "in/sub/x.css", CSS_IN)
    os.chown(tmp_path / "in/sub", UID, GID)
    res = run_minify(["-r", "in/", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _owner(tmp_path / "out/sub") == (UID, GID)
    assert _owner(tmp_path / "out") == (0, 0)
    # the file's own source was left owned by root, so it stays root
    assert _owner(tmp_path / "out/sub/x.css") == (0, 0)


@requires_root
def test_deep_created_directories_inherit_ownership_at_every_level(tmp_path):
    """Each level of created output directory copies its source dir's owner."""
    # CATCHES: walking the attribute preservation only one level above the
    # output file, so out/a/b would keep root instead of in/a/b's 8342:8343
    # and out/a would miss in/a's 8344:8345 (mode and mtime included).
    write(tmp_path, "in/a/b/c.css", CSS_IN)
    os.chown(tmp_path / "in/a", 8344, 8345)
    os.chmod(tmp_path / "in/a", 0o751)
    os.chown(tmp_path / "in/a/b", UID, GID)
    os.chmod(tmp_path / "in/a/b", 0o750)
    os.utime(tmp_path / "in/a/b", OLD)
    res = run_minify(["-r", "in/", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert _owner(tmp_path / "out/a") == (8344, 8345)
    assert oct(os.stat(tmp_path / "out/a").st_mode & 0o777) == "0o751"
    assert _owner(tmp_path / "out/a/b") == (UID, GID)
    assert oct(os.stat(tmp_path / "out/a/b").st_mode & 0o777) == "0o750"
    assert int(os.stat(tmp_path / "out/a/b").st_mtime) == 1000000000
    # the destination root is never attributed to any source directory
    assert _owner(tmp_path / "out") == (0, 0)
    assert oct(os.stat(tmp_path / "out").st_mode & 0o777) == "0o755"


@requires_root
def test_sync_copy_preserves_ownership(tmp_path):
    """A --sync verbatim copy is chowned to the source's owner."""
    # CATCHES: treating --sync copies as plain data transfers that keep the
    # invoking user instead of the copied file's 8342:8343.
    write(tmp_path, "in/notes.txt", b"hello world")
    os.chown(tmp_path / "in/notes.txt", UID, GID)
    res = run_minify(["-s", "-r", "in/", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b""
    assert _owner(tmp_path / "out/notes.txt") == (UID, GID)
    assert (tmp_path / "out/notes.txt").read_bytes() == b"hello world"


@requires_root
def test_sync_symlink_copy_does_not_preserve_ownership(tmp_path):
    """A symlink copied by --sync --preserve links keeps the invoking user."""
    # CATCHES: running attribute preservation for the symlink copy, which
    # the reference skips: the copied link is owned by root, not 8342:8343.
    write(tmp_path, "in/target.txt", b"hello world")
    link = tmp_path / "in/link.txt"
    os.symlink("target.txt", link)
    os.lchown(link, UID, GID)
    res = run_minify(
        ["-s", "-r", "--preserve", "links", "in/", "-o", "out/"], cwd=tmp_path
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert _lowner(tmp_path / "out/link.txt") == (0, 0)
    assert os.readlink(tmp_path / "out/link.txt") == "target.txt"


@requires_root
def test_inplace_does_not_preserve_ownership_or_mode(tmp_path):
    """--inplace drops the whole preserve set: new file owned by root, 0644."""
    # CATCHES: preserving attributes for in-place minification: the renamed
    # backup's owner/mode must NOT come back onto the freshly written file.
    write(tmp_path, "a.css", CSS_IN, mode=0o600)
    os.chown(tmp_path / "a.css", UID, GID)
    res = run_minify(["-i", "a.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "a.css").read_bytes() == CSS_OUT
    assert _owner(tmp_path / "a.css") == (0, 0)
    assert oct(os.stat(tmp_path / "a.css").st_mode & 0o777) == "0o644"
    assert not (tmp_path / "a.css.bak").exists()


def test_explicit_preserve_with_inplace_is_an_error(tmp_path):
    """--preserve next to --inplace is rejected before anything runs."""
    # CATCHES: silently ignoring the incompatible --preserve instead of
    # failing with the exact diagnostic and exit code 1.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["-i", "--preserve", "mode", "a.css"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.err_lines() == [
        "ERROR: --preserve cannot be used together with stdin, stdout or --inplace"
    ]
    assert (tmp_path / "a.css").read_bytes() == CSS_IN


def test_explicit_preserve_with_stdin_is_an_error(tmp_path):
    """--preserve with stdin input is rejected with the same diagnostic."""
    # CATCHES: accepting --preserve for the stdin task, where there is no
    # source file to take attributes from.
    res = run_minify(["--preserve", "mode", "--type", "css"], cwd=tmp_path,
                     stdin=b"body{color:red}")
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.err_lines() == [
        "ERROR: --preserve cannot be used together with stdin, stdout or --inplace"
    ]


def test_explicit_preserve_with_stdout_destination_is_accepted(tmp_path):
    """--preserve with a stdout destination runs fine and is just unused."""
    # CATCHES: rejecting --preserve for stdout as well, although the
    # reference only refuses it for stdin and --inplace.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["--preserve", "mode", "a.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == b"body{color:red}"
    assert res.stderr == b""
