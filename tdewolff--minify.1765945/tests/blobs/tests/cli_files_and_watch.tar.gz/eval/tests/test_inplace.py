"""--inplace/-i: minify files over themselves via the .bak rename dance."""

from conftest import run_minify, write

CSS_IN = b"body {\n  color: red;\n}\n"
CSS_OUT = b"body{color:red}"


def test_inplace_flag_minifies_over_itself(tmp_path):
    """-i renames the original to .bak, minifies, then removes the backup."""
    # CATCHES: emptying the original by truncating it before reading, leaving
    # the '<file>.bak' backup behind, or printing a destination in the stats
    # line of an in-place task.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["-i", "a.css"], cwd=tmp_path)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "a.css"
    assert (tmp_path / "a.css").read_bytes() == CSS_OUT
    assert not (tmp_path / "a.css.bak").exists()


def test_inplace_multiple_files_minifies_each(tmp_path):
    """-i over several inputs reports one source-only stats line per file."""
    # CATCHES: bundling the inputs together, or printing 'x to x' destination
    # pairs that the in-place flavour never shows.
    write(tmp_path, "a.css", CSS_IN)
    write(tmp_path, "b.css", b"p{margin:0}\n")
    res = run_minify(["-i", "a.css", "b.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert sorted(s["names"] for s in res.stats()) == ["a.css", "b.css"]
    assert (tmp_path / "a.css").read_bytes() == CSS_OUT
    assert (tmp_path / "b.css").read_bytes() == b"p{margin:0}"
    assert not (tmp_path / "a.css.bak").exists()
    assert not (tmp_path / "b.css.bak").exists()
