"""stdin/stdout plumbing: no-input runs read stdin, -o selects the sink.

Covers the stdin->stdout default path, the requirement of --type for stdin,
the absence of a statistics line for stdout destinations, and the argument
combinations that are rejected before any file is touched.
"""

import pytest

from conftest import file_modes, run_minify, write

CSS_IN = b"body {\n  color: red;\n}\n"
CSS_OUT = b"body{color:red}"


def test_stdin_to_stdout_minifies_css(tmp_path):
    """No inputs and --type css reads stdin and writes minified stdout."""
    # CATCHES: reading a file instead of stdin, or appending a statistics line
    # to stdout (which would corrupt the minified payload).
    res = run_minify(["--type", "css"], cwd=tmp_path, stdin=CSS_IN)
    assert res.returncode == 0
    assert res.stdout == CSS_OUT
    assert res.stderr == b""


def test_stdin_without_type_is_an_error(tmp_path):
    """stdin has no extension to infer from, so --type is mandatory."""
    # CATCHES: silently minifying nothing (or guessing a mimetype) instead of
    # refusing with the exact diagnostic and exit status 1.
    res = run_minify([], cwd=tmp_path, stdin=CSS_IN)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: must specify --type for stdin\n"


def test_explicit_dash_input_reads_stdin(tmp_path):
    """A single '-' operand is the documented way to ask for stdin."""
    # CATCHES: treating '-' as a literal filename (open error) rather than as
    # the stdin marker that clears the input list.
    res = run_minify(["-", "--type", "css"], cwd=tmp_path, stdin=CSS_IN)
    assert res.returncode == 0
    assert res.stdout == CSS_OUT
    assert res.stderr == b""


def test_file_to_stdout_prints_no_statistics_line(tmp_path):
    """With -o omitted a single file is minified to stdout, stats suppressed."""
    # CATCHES: emitting the '(duration, in, out, ratio, speed) - src to dst'
    # progress line on stdout, which only belongs to real file destinations.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == CSS_OUT
    assert res.stderr == b""


def test_explicit_output_dash_writes_stdout_without_statistics(tmp_path):
    """An explicit '-o -' behaves exactly like the omitted -o default."""
    # CATCHES: treating '-' as a file name (creating a file literally named
    # '-') instead of the stdout marker.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css", "-o", "-"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout == CSS_OUT
    assert res.stderr == b""
    assert not (tmp_path / "-").exists()


def test_stdin_to_output_file_writes_file_and_statistics(tmp_path):
    """stdin can still be combined with a real -o file destination."""
    # CATCHES: refusing stdin when an output file is given, naming the source
    # 'stdin' instead of the '-' operand in the stats line, or hiding the
    # warning emitted when preserving attributes fails to stat the '-' path.
    res = run_minify(["--type", "css", "-o", "out.css"], cwd=tmp_path, stdin=CSS_IN)
    assert res.returncode == 0
    stats = res.stats()
    assert len(stats) == 1
    assert stats[0]["names"] == "- to out.css"
    assert stats[0]["rin"] == "23 B"
    assert stats[0]["rout"] == "15 B"
    # stdin has no stat-able source, so attribute preservation warns and the
    # output keeps its plain 0644 creation mode
    assert res.stderr == b"WARNING: stat -: no such file or directory\n"
    assert (tmp_path / "out.css").read_bytes() == CSS_OUT
    assert file_modes(tmp_path)["out.css"] == "0o644"


def test_mixing_files_and_stdin_is_an_error(tmp_path):
    """'-' next to real file operands is rejected up front."""
    # CATCHES: silently skipping the dash or reading stdin halfway through the
    # file list instead of failing with this message.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["a.css", "-", "--type", "css"], cwd=tmp_path, stdin=CSS_IN)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: cannot mix files and stdin as input\n"


def test_unknown_filetype_reports_an_empty_name(tmp_path):
    """--type bogus cannot be mapped and the diagnostic echoes nothing."""
    # CATCHES: printing the offending name after the lookup clobbers it, i.e.
    # the message must be 'unknown filetype ' with a trailing space.
    write(tmp_path, "a.css", CSS_IN)
    res = run_minify(["--type", "bogus", "a.css", "-o", "out.css"], cwd=tmp_path)
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"ERROR: unknown filetype \n"


@pytest.mark.parametrize("filetype", ["css", "text/css"])
def test_type_accepts_short_and_mimetype_forms(tmp_path, filetype):
    """--type takes both the short filetype name and the full mimetype."""
    # CATCHES: only accepting one of the two spellings, which would make the
    # other fail with 'unknown filetype'.
    res = run_minify(["--type", filetype], cwd=tmp_path, stdin=CSS_IN)
    assert res.returncode == 0
    assert res.stdout == CSS_OUT


def test_deprecated_mime_option_still_works(tmp_path):
    """--mime is deprecated: it warns on stderr but still minifies."""
    # CATCHES: dropping the value (exit 1) or printing nothing; the run must
    # succeed while emitting the deprecation diagnostic.
    write(tmp_path, "a.html", b"<p >x</p >")
    res = run_minify(["--mime", "text/html", "a.html", "-o", "out.html"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == (b"ERROR: deprecated use of '--mime text/html', "
                          b"please use '--type text/html' instead\n")
    assert (tmp_path / "out.html").read_bytes() == b"<p>x"


def test_type_forces_mimetype_for_every_walked_file(tmp_path):
    """--type overrides extension sniffing for all files in a directory."""
    # CATCHES: still filtering .txt/.js files out of the walk when an explicit
    # mimetype makes every file minifiable.
    write(tmp_path, "dir/a.txt", CSS_IN)
    write(tmp_path, "dir/b.js", b"var b=1;\n")
    res = run_minify(["-r", "--type", "css", "dir", "-o", "out/"], cwd=tmp_path)
    assert res.returncode == 0
    assert (tmp_path / "out/dir/a.txt").read_bytes() == CSS_OUT
    assert (tmp_path / "out/dir/b.js").read_bytes() == b"var b=1"
