"""Shorthand property minification: box model, font, background, flex.
"""

import pytest
from conftest import css_out

MARGIN_CASES = [
    ("a{margin:1 1 1 1}", b"a{margin:1}"),
    ("a{margin:1 2 1 2}", b"a{margin:1 2}"),
    ("a{margin:1 2 3 2}", b"a{margin:1 2 3}"),
    ("a{margin:1 2 3 4}", b"a{margin:1 2 3 4}"),
    ("a{margin:1 1 1 a}", b"a{margin:1 1 1 a}"),
    ("a{margin:0 0 18px 0}", b"a{margin:0 0 18px}"),
    ("a{margin:.2em .4em .2em}", b"a{margin:.2em .4em}"),
    ("a{margin:1 1 1 1 !important}", b"a{margin:1!important}"),
]


@pytest.mark.parametrize("css,expected", MARGIN_CASES)
def test_margin_shorthand_collapses(css, expected):
    """4 values collapse to 3, 2 or 1 as the box model allows."""
    # CATCHES: always keeping four values, or collapsing when the opposite
    # sides differ (`1 2 3 4` must stay four).
    assert css_out(css) == expected


def test_mixed_token_types_block_the_collapse():
    """`0px 0em 0 0` is not collapsed even though all four are zero."""
    # CATCHES: comparing only the numeric text; the reference compares whole
    # tokens, so a dimension next to a bare number stays uncollapsed (and the
    # output is deliberately not idempotent).
    assert css_out("a{margin:0px 0em 0 0}") == b"a{margin:0 0 0 0}"
    assert css_out("a{margin:0px 0px 0px 0px}") == b"a{margin:0}"


@pytest.mark.parametrize(
    "css,expected",
    [
        ("a{padding:.2em .4em .2em}", b"a{padding:.2em .4em}"),
        ("a{padding:0 0 0 0}", b"a{padding:0}"),
        ("a{border-width:1 1 1 1}", b"a{border-width:1}"),
        ("a{border-width:thin medium thick 2px}", b"a{border-width:thin medium thick 2px}"),
        ("a{border-color:red red red}", b"a{border-color:red}"),
        ("a{border-color:currentcolor currentcolor currentcolor}", b"a{border-color:initial}"),
        ("a{border-color:currentcolor red currentcolor}", b"a{border-color:initial red initial}"),
    ],
    ids=["padding", "padding-zero", "border-width", "border-width-kw", "border-color", "currentcolor", "mixed"],
)
def test_padding_border_width_and_border_color(css, expected):
    """The same collapse applies to padding and border-width/-color."""
    # CATCHES: forgetting border-width, or mapping `currentcolor` to something
    # other than `initial`.
    assert css_out(css) == expected


BORDER_OUTLINE_CASES = [
    ("a{border:medium none}", b"a{border:none}"),
    ("a{border:none 0}", b"a{border:0}"),
    ("a{border:0 dashed red}", b"a{border:0 dashed red}"),
    ("a{border-left:none}", b"a{border-left:none}"),
    ("a{border-left:none 0}", b"a{border-left:0}"),
    ("a{border-left:none medium currentcolor}", b"a{border-left:none}"),
    ("a{outline:none}", b"a{outline:none}"),
    ("a{outline:solid black 0}", b"a{outline:solid #000 0}"),
    ("a{outline:none black medium}", b"a{outline:#000}"),
    ("a{outline:medium none}", b"a{outline:none}"),
    ("a{column-rule:medium currentcolor none}", b"a{column-rule:none}"),
    ("a{column-rule:medium white none}", b"a{column-rule:#fff}"),
    ("a{text-decoration:currentcolor none solid}", b"a{text-decoration:none}"),
    ("a{text-decoration:white none solid}", b"a{text-decoration:#fff}"),
    ("a{text-emphasis:none currentcolor}", b"a{text-emphasis:none}"),
    ("a{text-emphasis:none white}", b"a{text-emphasis:#fff}"),
    ("a{text-shadow:white 5px 5px}", b"a{text-shadow:#fff 5px 5px}"),
    ("a{border-left-color:currentcolor}", b"a{border-left-color:initial}"),
    ("a{border-left-color:black}", b"a{border-left-color:#000}"),
    ("a{outline-color:white}", b"a{outline-color:#fff}"),
]


@pytest.mark.parametrize("css,expected", BORDER_OUTLINE_CASES)
def test_border_and_outline_defaults_are_removed(css, expected):
    """Initial keywords are dropped from border/outline/text-* shorthands."""
    # CATCHES: keeping `medium none` (both are defaults), or rewriting the
    # colour keyword `currentcolor` as a colour instead of `initial`.
    assert css_out(css) == expected


FONT_CASES = [
    ("a{font-weight:normal}", b"a{font-weight:400}"),
    ("a{font-weight:bold}", b"a{font-weight:700}"),
    ("a{font-weight:bolder}", b"a{font-weight:bolder}"),
    ('a{font:bold 5px "Times new Roman","Sans-Serif"}', b"a{font:700 5px times new roman,sans-serif}"),
    ("a{font:normal normal normal normal 20px normal}", b"a{font:20px normal}"),
    ("a{font:27px/13px arial,sans-serif}", b"a{font:27px/13px arial,sans-serif}"),
    ("a{font:normal normal bold normal medium/normal arial,sans-serif}", b"a{font:700 medium arial,sans-serif}"),
    ("a{font:400 medium/normal 'Arial'}", b"a{font:medium arial}"),
    ("a{font:1em -apple-system}", b"a{font:1em '-apple-system'}"),
    ("a{font:caption}", b"a{font:caption}"),
    ("a{font:2em}", b"a{font:2em}"),
    ("a{font: ;}", b"a{font:}"),
]


@pytest.mark.parametrize("css,expected", FONT_CASES)
def test_font_weight_and_font_shorthand(css, expected):
    """`normal`/`bold` map to 400/700 and the font shorthand drops defaults."""
    # CATCHES: leaving `bold` in place, dropping the required font-size, or
    # forgetting the IE9-11 workaround that quotes `-apple-system`.
    assert css_out(css) == expected


FONT_FAMILY_CASES = [
    ("a{font-family:'Arial', 'Times New Roman';}", b"a{font-family:arial,times new roman}"),
    ("a{font-family:'a  b';}", b"a{font-family:'a  b'}"),
    ("a{font-family:' a b ';}", b"a{font-family:' a b '}"),
]


@pytest.mark.parametrize("css,expected", FONT_FAMILY_CASES)
def test_font_family_quotes_are_removed_when_safe(css, expected):
    """Family names become identifiers unless their spacing would change."""
    # CATCHES: unquoting `' a b '` (its leading/trailing spaces are part of the
    # name) or keeping quotes around a simple one-word name.
    assert css_out(css) == expected


BACKGROUND_CASES = [
    ("a{background:red none}", b"a{background:red}"),
    ("a{background:red none 0 0}", b"a{background:red}"),
    ("a{background:#ff0000 none 1 1}", b"a{background:red 1 1}"),
    ("a{background:#0000 1 1}", b"a{background:1 1}"),
    ("a{background:transparent}", b"a{background:0 0}"),
    ("a{background:transparent no-repeat}", b"a{background:no-repeat}"),
    (
        "a{background:#0000 none padding-box 0 0 / auto auto scroll border-box repeat repeat}",
        b"a{background:0 0}",
    ),
    ("a{background:0 0 / auto}", b"a{background:0 0}"),
    ("a{background:0 0 / auto 10%}", b"a{background:0 0/auto 10%}"),
    ("a{background:0 0/200px auto}", b"a{background:0 0/200px}"),
    ("a{background:0 0 no-repeat}", b"a{background:no-repeat}"),
    ("a{background:0% 0%}", b"a{background:0 0}"),
    ("a{background:left top}", b"a{background:0 0}"),
    ("a{background:no-repeat repeat}", b"a{background:repeat-y}"),
    ("a{background:top right}", b"a{background:100% 0}"),
    (
        "a{background:linear-gradient(-180deg, #355FFF 0%, #1F52FF 100%) 0% 0% / cover}",
        b"a{background:linear-gradient(-180deg,#355FFF 0%,#1F52FF 100%)0 0/cover}",
    ),
    (
        "a{background:transparent var(--bs-btn-close-bg) center/1em auto no-repeat}",
        b"a{background:var(--bs-btn-close-bg)50%/1em no-repeat}",
    ),
]


@pytest.mark.parametrize("css,expected", BACKGROUND_CASES)
def test_background_shorthand_defaults_are_removed(css, expected):
    """`transparent` becomes `0 0` and default layers disappear entirely."""
    # CATCHES: writing `transparent` (6 bytes longer than `0 0`), keeping the
    # `/ auto` size, or dropping the layer separator `/`.
    assert css_out(css) == expected


BG_POSITION_CASES = [
    ("a{background-position:top}", b"a{background-position:top}"),
    ("a{background-position:center}", b"a{background-position:50%}"),
    ("a{background-position:left 50%}", b"a{background-position:0}"),
    ("a{background-position:center center}", b"a{background-position:50%}"),
    ("a{background-position:center bottom}", b"a{background-position:50% 100%}"),
    ("a{background-position:top right}", b"a{background-position:100% 0}"),
    ("a{background-position:bottom left}", b"a{background-position:0 100%}"),
    ("a{background-position:bottom 5% right 0%}", b"a{background-position:100% 95%}"),
    ("a{background-position:bottom 0 right 10%}", b"a{background-position:90% 100%}"),
    ("a{background-position:top 10% left 5%}", b"a{background-position:5% 10%}"),
    ("a{background-position:top 10% left}", b"a{background-position:0 10%}"),
    ("a{background-position:left 10% top}", b"a{background-position:10% 0}"),
    ("a{background-position:center left 5%}", b"a{background-position:5%}"),
    ("a{background-position:center right 10%}", b"a{background-position:90%}"),
    ("a{background-position:right .75rem center}", b"a{background-position:right .75rem center}"),
    ("a{background-position:right 50% bottom 50%}", b"a{background-position:50%}"),
    ("a{background-position:right 100% bottom 100%}", b"a{background-position:0 0}"),
    ("a{background-position:left 1% center}", b"a{background-position:1%}"),
    ("a{background-position:center top 1%}", b"a{background-position:50% 1%}"),
    ("a{background-position:right 0 top 0}", b"a{background-position:100% 0}"),
    ("a{background-position:center 0px center 0%}", b"a{background-position:50%}"),
    ("a{background-position:center 0px center 0%,,right 0 top 0}", b"a{background-position:50%,,100% 0}"),
]


@pytest.mark.parametrize("css,expected", BG_POSITION_CASES)
def test_background_position_keywords_become_percentages(css, expected):
    """Position keywords resolve to percentages and redundant pairs collapse."""
    # CATCHES: leaving `center` as a keyword, or swapping the x/y order when
    # the keywords are written bottom-first.
    assert css_out(css) == expected


BG_REPEAT_SIZE_CASES = [
    ("a{background-repeat:space space}", b"a{background-repeat:space}"),
    ("a{background-repeat:round round}", b"a{background-repeat:round}"),
    ("a{background-repeat:repeat repeat}", b"a{background-repeat:repeat}"),
    ("a{background-repeat:no-repeat no-repeat}", b"a{background-repeat:no-repeat}"),
    ("a{background-repeat:repeat no-repeat}", b"a{background-repeat:repeat-x}"),
    ("a{background-repeat:no-repeat repeat}", b"a{background-repeat:repeat-y}"),
    ("a{background-repeat:no-repeat repeat,,repeat no-repeat}", b"a{background-repeat:repeat-y,,repeat-x}"),
    ("a{background-size:auto auto}", b"a{background-size:auto}"),
    ("a{background-size:30% auto}", b"a{background-size:30%}"),
    ("a{background-size:200px auto}", b"a{background-size:200px}"),
    ("a{background-size:200px auto,,30% auto}", b"a{background-size:200px,,30%}"),
]


@pytest.mark.parametrize("css,expected", BG_REPEAT_SIZE_CASES)
def test_background_repeat_and_size(css, expected):
    """`repeat repeat` collapses and `x y` pairs map to repeat-x/repeat-y."""
    # CATCHES: emitting `no-repeat repeat` instead of `repeat-y`, or dropping
    # the empty layer between two commas.
    assert css_out(css) == expected


BOX_SHADOW_CASES = [
    ("a{box-shadow:0 0 0 0}", b"a{box-shadow:0 0}"),
    ("a{box-shadow:0 0 0 0,0 0 0 0}", b"a{box-shadow:0 0,0 0}"),
    ("a{box-shadow:0 inset 0 0 blue 0}", b"a{box-shadow:0 inset 0 blue}"),
    ("a{box-shadow:rgba(0,0,0,0) 0 8px}", b"a{box-shadow:transparent 0 8px}"),
    ("a{box-shadow: inset .5em 0,, .39em 0}", b"a{box-shadow:inset .5em 0,,.39em 0}"),
    ("a{box-shadow:initial}", b"a{box-shadow:none}"),
    ("a{box-shadow:none}", b"a{box-shadow:none}"),
]


@pytest.mark.parametrize("css,expected", BOX_SHADOW_CASES)
def test_box_shadow_blur_and_spread_collapse(css, expected):
    """A zero spread is dropped and `initial` maps to `none`."""
    # CATCHES: keeping the fourth zero, or leaving `initial` in place.
    assert css_out(css) == expected


FLEX_CASES = [
    ("a{flex:5 1 0}", b"a{flex:5}"),
    ("a{flex:5 1 0%}", b"a{flex:5}"),
    ("a{flex:5 1 0px}", b"a{flex:5}"),
    ("a{flex:5 0 0%}", b"a{flex:5 0}"),
    ("a{flex:0 1 auto}", b"a{flex:initial}"),
    ("a{flex:1 1 auto}", b"a{flex:auto}"),
    ("a{flex:0 0 auto}", b"a{flex:none}"),
    ("a{flex:3 1 auto}", b"a{flex:3 1 auto}"),
    ("a{flex:0 5 auto}", b"a{flex:0 5 auto}"),
    ("a{flex:initial}", b"a{flex:initial}"),
    ("a{flex:5 auto}", b"a{flex:5 auto}"),
    ("a{flex:5 0px}", b"a{flex:5}"),
    ("a{flex:5 0}", b"a{flex:5 0}"),
    ("a{flex-basis:0px}", b"a{flex-basis:0}"),
    ("a{flex-basis:initial}", b"a{flex-basis:auto}"),
    ("a{flex-grow:initial}", b"a{flex-grow:0}"),
    ("a{flex-shrink:initial}", b"a{flex-shrink:1}"),
    ("a{order:initial}", b"a{order:0}"),
]


@pytest.mark.parametrize("css,expected", FLEX_CASES)
def test_flex_shorthand_and_longhands(css, expected):
    """flex maps to its keyword forms and longhand `initial` values resolve."""
    # CATCHES: leaving `0 1 auto` uncollapsed, or mapping flex-basis:initial
    # to 0 instead of auto.
    assert css_out(css) == expected


UNICODE_RANGE_CASES = [
    ("a{unicode-range:U}", b"a{unicode-range:U}"),
    ("a{unicode-range:U+}", b"a{unicode-range:U+}"),
    ("a{unicode-range:U+0-04FF}", b"a{unicode-range:U+0-4FF}"),
    ("a{unicode-range:U+0-7F}", b"a{unicode-range:U+0-7F}"),
    ("a{unicode-range:U+000-FFF}", b"a{unicode-range:U+???}"),
    ("a{unicode-range:U+1000-2FFF}", b"a{unicode-range:U+1000-2FFF}"),
    ("a{unicode-range:U+2300-23FF,U+2A00-2aFf}", b"a{unicode-range:U+23??,U+2A??}"),
    ("a{unicode-range:U+25-FF}", b"a{unicode-range:U+25-FF}"),
    ("a{unicode-range:U+26}", b"a{unicode-range:U+26}"),
    ("a{unicode-range:U+2600-26FF}", b"a{unicode-range:U+26??}"),
    ("a{unicode-range:u+1234-1234}", b"a{unicode-range:U+1234}"),
    ("a{unicode-range:U+26??,U+27??}", b"a{unicode-range:U+2600-27FF}"),
    ("a{unicode-range:U+26??,U+2680-2780}", b"a{unicode-range:U+2600-2780}"),
    ("a{unicode-range:U+26??,U+2680-2690}", b"a{unicode-range:U+26??}"),
    ("a{unicode-range:U+0-10FFFF}", b"a{unicode-range:initial}"),
]


@pytest.mark.parametrize("css,expected", UNICODE_RANGE_CASES)
def test_unicode_range_is_shortened(css, expected):
    """Full 256-codepoint ranges become `U+XX??` and adjacent ranges merge."""
    # CATCHES: emitting `U+000-FFF` unchanged, lowercasing the `U+` prefix, or
    # failing to notice that the whole Unicode space means `initial`.
    assert css_out(css) == expected
