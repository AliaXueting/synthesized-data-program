"""Unit and colour value minification.
"""

import pytest
from conftest import css_out

ZERO_UNIT_DROPPED = [
    ("a{margin:0PX}", b"a{margin:0}"),
    ("a{width:0.0EM}", b"a{width:0}"),
    ("a{width:0vmin}", b"a{width:0}"),
    ("a{width:0VMIN}", b"a{width:0}"),
    ("a{width:0turn}", b"a{width:0}"),
    ("a{width:0TURN}", b"a{width:0}"),
    ("a{width:0grad}", b"a{width:0}"),
    ("a{width:0ch}", b"a{width:0}"),
    ("a{width:0q}", b"a{width:0}"),
    ("a{width:0pc}", b"a{width:0}"),
    ("a{width:0rem}", b"a{width:0}"),
]


@pytest.mark.parametrize("css,expected", ZERO_UNIT_DROPPED)
def test_zero_units_are_dropped_for_length_and_angle_units(css, expected):
    """A zero length/angle keeps no unit, whatever the original case was."""
    # CATCHES: keeping `0px`, or lowercasing the unit without dropping it.
    assert css_out(css) == expected


ZERO_UNIT_KEPT = [
    ("a{width:0s}", b"a{width:0s}"),
    ("a{width:0ms}", b"a{width:0ms}"),
    ("a{width:0dpi}", b"a{width:0dpi}"),
    ("a{width:0hz}", b"a{width:0hz}"),
    ("a{width:0fr}", b"a{width:0fr}"),
    ("a{width:0%}", b"a{width:0%}"),
]


@pytest.mark.parametrize("css,expected", ZERO_UNIT_KEPT)
def test_zero_units_are_kept_for_time_frequency_resolution_and_flex(css, expected):
    """Only the length/angle unit whitelist is droppable; the rest survive."""
    # CATCHES: dropping `0s` or `0%`, which changes the value's type.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("a{flex:0px}", b"a{flex:0px}"),
        ("a{flex:0PX}", b"a{flex:0px}"),
        ("a{width:calc(0px)}", b"a{width:calc(0px)}"),
        ("a{width:calc(0PX)}", b"a{width:calc(0px)}"),
        ("a{width:var(--x,0PX)}", b"a{width:var(--x,0px)}"),
        ("a{width:translate(0PX)}", b"a{width:translate(0)}"),
    ],
    ids=["flex", "flex-upper", "calc", "calc-upper", "var", "translate"],
)
def test_zero_units_inside_flex_and_functions(css, expected):
    """Zero units survive inside `flex` and `calc`/`var` but not `translate`."""
    # CATCHES: blanket-dropping units inside every function, or lowercasing
    # without keeping the unit for the flex property.
    assert css_out(css) == expected


def test_non_zero_units_are_lowercased():
    """A non-zero dimension has its unit lowercased and its number shortened."""
    # CATCHES: leaving `1.5EM` as written, or dropping a unit from a non-zero.
    assert css_out("a{width:1.5EM}") == b"a{width:1.5em}"
    assert css_out("a{width:+05.50REM}") == b"a{width:5.5rem}"


HEX_CASES = [
    ("a{color:#000000}", b"a{color:#000}"),
    ("a{color:#000}", b"a{color:#000}"),
    ("a{color:#aabbcc}", b"a{color:#abc}"),
    ("a{color:#AABBCC}", b"a{color:#abc}"),
    ("a{color:#123456}", b"a{color:#123456}"),
    ("a{color:#00000000}", b"a{color:#0000}"),
    ("a{color:#aabbccdd}", b"a{color:#abcd}"),
    ("a{color:#aabbccff}", b"a{color:#abc}"),
    ("a{color:#aabbcc00}", b"a{color:#0000}"),
    ("a{color:#11223344}", b"a{color:#1234}"),
]


@pytest.mark.parametrize("css,expected", HEX_CASES)
def test_hex_colors_are_shortened(css, expected):
    """Hex colours shrink to 3 digits, drop opaque alpha, and use `#abcd`."""
    # CATCHES: keeping `#aabbcc`, keeping a fully opaque alpha channel, or
    # emitting `#aabbccdd` instead of the 4-digit form.
    assert css_out(css) == expected


NAME_CASES = [
    ("a{color:#000080}", b"a{color:navy}"),
    ("a{color:#c0c0c0}", b"a{color:silver}"),
    ("a{color:black}", b"a{color:#000}"),
    ("a{color:BLACK}", b"a{color:#000}"),
    ("a{color:navy}", b"a{color:navy}"),
    ("a{color:red}", b"a{color:red}"),
    ("a{color:RED}", b"a{color:RED}"),
    ("a{color:CYAN}", b"a{color:CYAN}"),
    ("a{color:transparent}", b"a{color:transparent}"),
]


@pytest.mark.parametrize("css,expected", NAME_CASES)
def test_named_colors_pick_the_shorter_spelling(css, expected):
    """The shorter of name and hex wins, and name lookup is case-sensitive."""
    # CATCHES: turning `navy` into `#000080` (longer), or accepting `RED` as a
    # colour name and rewriting it to `#f00`.
    assert css_out(css) == expected


RGB_CASES = [
    ("a{color:rgb(255,255,255)}", b"a{color:#fff}"),
    ("a{color:rgb(0,0,128)}", b"a{color:navy}"),
    ("a{color:rgba(0,0,128,1)}", b"a{color:navy}"),
    ("a{color:rgb(0 0 128)}", b"a{color:navy}"),
    ("a{color:rgb(0 0 128 / 1)}", b"a{color:navy}"),
    ("a{color:rgb(100%,100%,100%)}", b"a{color:#fff}"),
    ("a{color:rgb(256,-34,2342435)}", b"a{color:#f0f}"),
    ("a{color:rgba(255,0,0,0.5)}", b"a{color:rgba(255,0,0,.5)}"),
    ("a{color:rgba(255 0 0 / 50%)}", b"a{color:rgba(255 0 0/.5)}"),
    ("a{color:rgb(1,2,3,.01)}", b"a{color:rgb(1,2,3,1%)}"),
    ("a{color:rgb(20%,40%,60%,50%)}", b"a{color:rgb(51,102,153,.5)}"),
    ("a{color:rgba(255,255,255,0)}", b"a{color:rgba(255,255,255,0)}"),
    ("a{color:rgba(0,0,0,-1)}", b"a{color:transparent}"),
    ("a{border:2px rgb(255,255,255)}", b"a{border:2px #fff}"),
]


@pytest.mark.parametrize("css,expected", RGB_CASES)
def test_rgb_functions_become_hex_or_a_name(css, expected):
    """Opaque rgb()/rgba() collapse to hex or a colour name."""
    # CATCHES: leaving `rgb(0,0,128)` alone, or converting a translucent
    # rgba() that must stay a function.
    assert css_out(css) == expected


HSL_CASES = [
    ("a{color:hsl(240,100%,25%)}", b"a{color:navy}"),
    ("a{color:hsla(240,100%,25%,1)}", b"a{color:navy}"),
    ("a{color:hsl(48,100%,50%)}", b"a{color:#fc0}"),
    ("a{color:hsl(-180,100%,50%)}", b"a{color:#0ff}"),
    ("a{color:hsla(400, 150%, 150%, 2)}", b"a{color:#fff}"),
    ("a{color:hsla(5,0%,10%,0.75)}", b"a{color:hsla(5,0%,10%,.75)}"),
    ("a{color:hsla(0 100% 50% / 60%)}", b"a{color:hsla(0 100% 50%/.6)}"),
]


@pytest.mark.parametrize("css,expected", HSL_CASES)
def test_hsl_functions_become_hex_or_a_name(css, expected):
    """Opaque hsl()/hsla() are converted; hue may be negative or out of range."""
    # CATCHES: refusing to convert a negative hue, or converting a
    # semi-transparent hsla() that must stay a function.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("a{color:rgba(255,0,0,.005)}", b"a{color:rgba(255,0,0,.5%)}"),
        ("a{color:rgba(255,0,0,.05)}", b"a{color:rgba(255,0,0,5%)}"),
        ("a{color:hsla(0 100% 50%/.005)}", b"a{color:hsla(0 100% 50%/.5%)}"),
        ("a{color:hsla(120,50%,50%,.05)}", b"a{color:hsla(120,50%,50%,5%)}"),
        ("a{color:rgba(255,0,0,.0005)}", b"a{color:rgba(255,0,0,5e-4)}"),
        ("a{color:rgba(255,0,0,.5)}", b"a{color:rgba(255,0,0,.5)}"),
        ("a{color:rgba(255,0,0,.105)}", b"a{color:rgba(255,0,0,.105)}"),
    ],
    ids=["rgba-dot005", "rgba-dot05", "hsla-dot005", "hsla-dot05", "exponent-wins", "short-alpha", "no-leading-zero"],
)
def test_color_function_alpha_becomes_percentage_when_shorter(css, expected):
    """A translucent rgb()/hsl() alpha is rewritten as a percentage if shorter."""
    # CATCHES: leaving `.005` as a number when `.5%` is shorter, or converting
    # `.0005` (where exponent notation `5e-4` wins) or `.5`/`.105` (where the
    # number spelling is already shortest).
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("a{color:rgb(1,2,3)}", b"a{color:#010203}"),
        ("a{color:rgb(18,52,86)}", b"a{color:#123456}"),
    ],
    ids=["odd-digits", "pairwise-unequal"],
)
def test_rgb_without_name_or_pairs_stays_full_hex(css, expected):
    """rgb() colours with no colour name and unequal digit pairs keep 7 hex."""
    # CATCHES: truncating `#010203` to `#123` (only pairwise-equal hex may be
    # shortened) or forcing a colour name that does not exist.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("a{color:rgb(0,1,ident)}", b"a{color:rgb(0,1,ident)}"),
        ("a{color:rgb(ident)}", b"a{color:rgb(ident)}"),
        ("a{color:rgba(100%)}", b"a{color:rgba(100%)}"),
        ("a{color:hwb(0 0% 0%)}", b"a{color:hwb(0 0% 0%)}"),
        ("a{margin:rgb(ident)}", b"a{margin:rgb(ident)}"),
    ],
    ids=["ident-arg", "only-ident", "one-arg", "hwb", "non-color-prop"],
)
def test_invalid_color_functions_are_untouched(css, expected):
    """Malformed or unsupported colour functions pass through unchanged."""
    # CATCHES: crashing on a non-numeric argument, or converting hwb() which
    # the reference deliberately leaves alone.
    assert css_out(css) == expected
