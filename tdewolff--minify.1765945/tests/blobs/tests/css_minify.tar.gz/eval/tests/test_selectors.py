"""Selector and property-name normalisation.

Tag names are lowercased, class/id names are not, and attribute-selector values
are unquoted when they form a valid identifier.
"""

import pytest
from conftest import css_out

SELECTOR_CASES = [
    ("DIV{margin:1em}", b"div{margin:1em}"),
    (".CLASS{margin:1em}", b".CLASS{margin:1em}"),
    ("#ID{margin:1em}", b"#ID{margin:1em}"),
    ("INPUT[type=\"radio\"]{x:y}", b"input[type=radio]{x:y}"),
    ('input[type="radio" i]{x:y}', b"input[type=radio i]{x:y}"),
    ('input[type="radio" I]{x:y}', b"input[type=radio I]{x:y}"),
    ('input[type="radio" s]{x:y}', b"input[type=radios]{x:y}"),
    ('input[type="123"]{x:y}', b'input[type="123"]{x:y}'),
    ('input[type=""]{x:y}', b'input[type=""]{x:y}'),
    ('input[class*=" icon-"]{x:y}', b'input[class*=" icon-"]{x:y}'),
    ('.cla[id ^= L] { x:y; }', b".cla[id^=L]{x:y}"),
    (".cla .ss > #id { x:y; }", b".cla .ss>#id{x:y}"),
    ("a > span ~ div + span span[target] { color:red; }", b"a>span~div+span span[target]{color:red}"),
    ("a, b + c { x:y; }", b"a,b+c{x:y}"),
    ("area:focus { outline : 0;}", b"area:focus{outline:0}"),
    ("a:link::selection,a:nth-child(2n+3):not(div){x:y}", b"a:link::selection,a:nth-child(2n+3):not(div){x:y}"),
    ('input[type="\x00"] {  a: b\n}.a{b:c}', b'input[type="\x00"]{a:b}.a{b:c}'),
    ("@MEDIA all{a:b}", b"@media all{a:b}"),
    ("@counter-style Ident{a:b}", b"@counter-style Ident{a:b}"),
]


@pytest.mark.parametrize("css,expected", SELECTOR_CASES)
def test_selectors_are_normalised(css, expected):
    """Selector lists, combinators and attribute matchers are rewritten."""
    # CATCHES: lowercasing class names, spacing `>` combinators, or losing the
    # quoted form when the value is not a valid identifier.
    assert css_out(css) == expected


def test_tag_selectors_are_lowercased_but_not_class_or_id():
    """Type selectors are lowercased; .class and #id keep their original case."""
    # CATCHES: applying ToLower to every identifier token in the selector.
    assert css_out("DIV.SPAN#FOO{a:b}") == b"div.SPAN#FOO{a:b}"


def test_attribute_selector_i_flag_stays_spaced():
    """The case-insensitive `i` flag keeps exactly one space before it."""
    # CATCHES: gluing the flag onto the value, which changes selector meaning
    # from `[type=radio i]` to the different attribute `[type=radios]`.
    assert css_out('input[type="radio"   i]{x:y}') == b"input[type=radio i]{x:y}"


def test_attribute_selector_s_flag_is_not_spaced():
    """Only `i` is recognised as a flag; an `s` is glued onto the value."""
    # CATCHES: generalising the flag handling to every single letter.
    assert css_out('input[type="radio" s]{x:y}') == b"input[type=radios]{x:y}"


def test_descendant_combinator_keeps_a_single_space():
    """A descendant combinator collapses to one space, others to nothing."""
    # CATCHES: removing the space in `a b`, which would fuse two selectors.
    assert css_out("a   b ~   c {x:y}") == b"a b~c{x:y}"


def test_property_names_are_lowercased():
    """Property names are lowercased while their values keep their case."""
    # CATCHES: leaving `MARGIN` uppercase, or lowercasing the value too.
    assert css_out("a{MARGIN:1EM}") == b"a{margin:1em}"
    assert css_out("a{COLOR:RED}") == b"a{color:RED}"
