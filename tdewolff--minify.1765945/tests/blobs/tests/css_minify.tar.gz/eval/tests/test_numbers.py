"""Number minification, --css-precision and --css-version behaviour.
"""

import pytest
from conftest import css_out

SIMPLE_NUMBER_CASES = [
    ("a{margin:+1px}", b"a{margin:1px}"),
    ("a{margin:05em}", b"a{margin:5em}"),
    ("a{margin:0.5em}", b"a{margin:.5em}"),
    ("a{margin:-0.5em}", b"a{margin:-.5em}"),
    ("a{margin:.50em}", b"a{margin:.5em}"),
    ("a{margin:5.0em}", b"a{margin:5em}"),
    ("a{margin:-0.0px}", b"a{margin:0px}"),
    ("a{margin:5.0e3px}", b"a{margin:5e3px}"),
    ("a{margin:1e3px}", b"a{margin:1e3px}"),
]


@pytest.mark.parametrize("css,expected", SIMPLE_NUMBER_CASES)
def test_leading_and_trailing_zeros_are_removed(css, expected):
    """`+`, redundant zeros and a negative zero all disappear."""
    # CATCHES: keeping `+1`, writing `0.5` instead of `.5`, or emitting `-0`.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("a{margin:5000em}", b"a{margin:5e3em}"),
        ("a{width:5000%}", b"a{width:5e3%}"),
        ("a{margin:100000px}", b"a{margin:1e5px}"),
        ("a{margin:0.00001px}", b"a{margin:1e-5px}"),
        ("a{margin:0.000123456px}", b"a{margin:123456e-9px}"),
        ("a{margin:123456px}", b"a{margin:123456px}"),
        ("a{margin:9999px}", b"a{margin:9999px}"),
        ("a{margin:555555px}", b"a{margin:555555px}"),
        ("a{margin:1234.5px}", b"a{margin:1234.5px}"),
        ("a{margin:1.2345px}", b"a{margin:1.2345px}"),
    ],
)
def test_exponent_notation_is_used_only_when_shorter(css, expected):
    """Exponent form is chosen only when it actually saves characters."""
    # CATCHES: unconditionally rewriting large numbers to exponents, or never
    # doing it at all.
    assert css_out(css) == expected


PRECISION_CASES = [
    ("a{margin:1.2345px}", "1", b"a{margin:1px}"),
    ("a{margin:1.2345px}", "2", b"a{margin:1.2px}"),
    ("a{margin:1.2345px}", "3", b"a{margin:1.23px}"),
    ("a{margin:1.2345px}", "4", b"a{margin:1.235px}"),
    ("a{margin:9.99px}", "1", b"a{margin:10px}"),
    ("a{margin:1.999px}", "1", b"a{margin:2px}"),
    ("a{margin:0.04999px}", "1", b"a{margin:.05px}"),
    ("a{margin:123456px}", "2", b"a{margin:12e4px}"),
    ("a{margin:555555px}", "3", b"a{margin:556e3px}"),
    ("a{margin:1234.5px}", "3", b"a{margin:1230px}"),
    ("a{margin:0.000123456px}", "3", b"a{margin:123e-6px}"),
    ("a{width:12.3456%}", "2", b"a{width:12%}"),
]


@pytest.mark.parametrize("css,precision,expected", PRECISION_CASES)
def test_precision_rounds_significant_digits(css, precision, expected):
    """--css-precision keeps N significant digits, rounding half up."""
    # CATCHES: truncating instead of rounding (1.2345 -> 1.234 at precision 4),
    # or counting digits after the dot instead of significant digits.
    assert css_out(css, "--css-precision", precision) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("a{margin:0.1234567890123456789px}", b"a{margin:.1234567890123456789px}"),
        ("a{margin:0.1234567890123456789012345678901234px}", b"a{margin:.1234567890123456789012345678901234px}"),
    ],
    ids=["19-digits", "34-digits"],
)
def test_precision_zero_keeps_every_digit(css, expected):
    """--css-precision 0 means "all digits": nothing is rounded away."""
    # CATCHES: defaulting to a float64 round trip that would shorten
    # 0.1234567890123456789 to 17 significant digits.
    assert css_out(css, "--css-precision", "0") == expected


@pytest.mark.parametrize(
    "precision,expected",
    [
        ("15", b"a{margin:.123456789012346px}"),
        ("16", b"a{margin:.1234567890123457px}"),
        ("20", b"a{margin:.1234567890123456789px}"),
    ],
    ids=["15", "16", "20"],
)
def test_precision_above_fifteen_is_honoured(precision, expected):
    """Precision is not clamped at 15: 16 and 20 both keep more digits."""
    # CATCHES: clamping the flag to 15 significant digits, which is what the
    # documentation suggests but the reference does not do.
    css = "a{margin:0.1234567890123456789px}"
    assert css_out(css, "--css-precision", precision) == expected


def test_negative_precision_behaves_like_zero():
    """A negative --css-precision is treated as "keep all digits"."""
    # CATCHES: rejecting the value or minifying to a default of 15 digits.
    assert css_out("a{margin:1.2345678px}", "--css-precision", "-5") == b"a{margin:1.2345678px}"


INTEGER_PROPERTY_CASES = [
    ("a{z-index:0005}", b"a{z-index:0005}"),
    ("a{z-index:+5}", b"a{z-index:+5}"),
    ("a{orphans:0.500}", b"a{orphans:0.500}"),
    ("a{widows:05}", b"a{widows:05}"),
    ("a{counter-reset:0005}", b"a{counter-reset:0005}"),
    ("a{counter-increment:0005}", b"a{counter-increment:0005}"),
    ("a{line-height:0005}", b"a{line-height:5}"),
    ("a{width:0005}", b"a{width:5}"),
]


@pytest.mark.parametrize("css,expected", INTEGER_PROPERTY_CASES)
def test_integer_valued_properties_are_untouched(css, expected):
    """z-index/counter-*/orphans/widows numbers are never rewritten."""
    # CATCHES: stripping the leading zeros of `z-index:0005`, which would be a
    # valid CSS change but not what the reference does.
    assert css_out(css) == expected


def test_integer_properties_ignore_precision():
    """--css-precision has no effect on the integer-valued properties."""
    # CATCHES: applying the significant-digit rounding to z-index or widows.
    assert css_out("a{z-index:0005.50}", "--css-precision", "2") == b"a{z-index:0005.50}"
    assert css_out("a{widows:0.500}", "--css-precision", "1") == b"a{widows:0.500}"


VERSION_CASES = [
    ("a{margin:5000em}", "2", b"a{margin:5000em}"),
    ("a{margin:5000em}", "3", b"a{margin:5e3em}"),
    ("a{width:5000%}", "2", b"a{width:5000%}"),
    ("a{margin:0.00001px}", "2", b"a{margin:.00001px}"),
    ("a{margin:0.00001px}", "3", b"a{margin:1e-5px}"),
    ("a{margin:123456px}", "2", b"a{margin:123456px}"),
    ("a{flex:0 0 5000%}", "2", b"a{flex:0 0 5000%}"),
    ("a{flex:0 0 5000%}", "3", b"a{flex:0 0 5e3%}"),
    ("a{background-color:black !important}", "2", b"a{background-color:#000 !important}"),
    ("a{background-color:black !important}", "3", b"a{background-color:#000!important}"),
    ("a{color:red!important}", "2", b"a{color:red !important}"),
    ("a{margin:5e3}", "2", b"a{margin:5e3}"),
]


@pytest.mark.parametrize("css,version,expected", VERSION_CASES)
def test_css_version_two_changes_number_and_important_handling(css, version, expected):
    """--css-version 2 disables exponent notation and spaces `!important`."""
    # CATCHES: writing `5e3em` under CSS2, or gluing `!important` onto the
    # value without the space CSS2 requires.
    assert css_out(css, "--css-version", version) == expected


@pytest.mark.parametrize("version", ["0", "3", "4", "99"])
def test_css_version_defaults_to_latest_behaviour(version):
    """Version 0 and any version above 2 behave like the default (version 3)."""
    # CATCHES: treating 0 or a large version number as an error, or mapping it
    # to the CSS2 code path.
    assert css_out("a{margin:5000em}", "--css-version", version) == b"a{margin:5e3em}"
    assert css_out("a{color:red !important}", "--css-version", version) == b"a{color:red!important}"


def test_css_version_one_behaves_like_two():
    """Version 1 is on the legacy branch too: no exponents, spaced !important."""
    # CATCHES: mapping only the literal value 2 onto the CSS2 code path.
    assert css_out("a{margin:5000em}", "--css-version", "1") == b"a{margin:5000em}"
    assert css_out("a{color:red !important}", "--css-version", "1") == b"a{color:red !important}"
