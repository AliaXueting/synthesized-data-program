"""Shared black-box helpers for the css_minify test module.

Every expectation embedded in this module's tests was recorded by running the
reference `minify` binary through its command line interface only.  The tests
never call into the binary's internals and never hardcode a path to it: the
executable location always comes from PROGRAMGYM_EXECUTABLE.
"""

import functools
import os
import subprocess
import tempfile
from pathlib import Path

# Default significant-digit precision used by the reference when
# --css-precision is not given (0 == "keep every digit").
DEFAULT_PRECISION = "0"


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running it once against a throwaway GOCOVERDIR, so the check
    never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="css-covprobe-") as probe_dir:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "--type", "css"],
                input=b"a{color:red}",
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def minify_executable():
    """Return the binary under test, resolving PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the minify binary under test"
        )
    # The pipeline's coverage driver sets GOCOVERDIR to collect source coverage
    # of the reference, but the pipeline-managed eval/run.sh force-resets
    # PROGRAMGYM_EXECUTABLE to this module's uninstrumented copy before pytest
    # starts, so counters would never be written and this module's coverage
    # report would stay empty.  During a coverage run (GOCOVERDIR present), when
    # the assigned binary is not itself instrumented, fall back to the
    # instrumented build the driver stages next to the module workspaces.  The
    # staged file only exists in that layout, so ordinary validation and
    # release runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(str(staged)):
            return str(staged)
    return path


def _pinned_env(cwd=None, env=None):
    """Build the child environment from scratch: no TTY, no color, no noise.

    TERM, NO_COLOR and FORCE_COLOR are deliberately absent unless a test asks
    for them, and HOME points at the sandbox so no user-level config file can
    leak into the run.
    """
    child = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
    }
    # Required coverage instrumentation hook: forward GOCOVERDIR so a
    # coverage-instrumented reference binary can write its counters.
    cov_env = {k: v for k, v in [("GOCOVERDIR", os.environ.get("GOCOVERDIR"))] if v}
    child.update(cov_env)
    if cwd is not None:
        child["HOME"] = str(cwd)
    if env:
        child.update(env)
    return child


def run_minify(args, stdin=b"", cwd=None, env=None, timeout=60):
    """Run the binary with 'args' and return the CompletedProcess result.

    stdin is always a pipe and stdout/stderr are always captured, so the
    program never sees a terminal.
    """
    return subprocess.run(
        [minify_executable()] + list(args),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=_pinned_env(cwd, env),
        timeout=timeout,
    )


def run_css(css, *extra_args, cwd=None, env=None):
    """Minify a CSS stylesheet given on stdin with --type css."""
    if isinstance(css, str):
        css = css.encode("utf-8")
    return run_minify(
        ["--type", "css"] + list(extra_args), stdin=css, cwd=cwd, env=env
    )


def css_out(css, *extra_args):
    """Return the exact stdout bytes of minifying 'css' with --type css."""
    res = run_css(css, *extra_args)
    assert res.returncode == 0, res.stderr
    assert res.stderr == b"", res.stderr
    return res.stdout


def write_css(tmp_path, name, content):
    """Write 'content' to tmp_path/name and return the path."""
    path = Path(tmp_path) / name
    if isinstance(content, str):
        content = content.encode("utf-8")
    path.write_bytes(content)
    return path


def run_file(path, *extra_args, cwd=None):
    """Minify an existing file (mimetype inferred from its extension)."""
    return run_minify([str(path)] + list(extra_args), cwd=cwd)
