"""Value-level minification and robustness against invalid input.

Custom properties, IE hacks, progid filters, url()/data: rewriting and the
"keep going after a bad declaration" behaviour.
"""

import pytest
from conftest import css_out

CUSTOM_PROPERTY_CASES = [
    (":root { --custom-variable:0px; }", b":root{--custom-variable:0px}"),
    ("a{--foo: 0px ;}", b"a{--foo:0px}"),
    ("a{--foo: if(x > 5) this.width = 10}", b"a{--foo:if(x > 5) this.width = 10}"),
    ("a{--foo: ;}", b"a{--foo: }"),
    ("a{--foo:;}", b"a{--foo:}"),
    ("a{--foo: initial ;}", b"a{--foo:initial}"),
    ("a{--foo:calc(var(--a) + var(--b))}", b"a{--foo:calc(var(--a) + var(--b))}"),
    ("a{--foo: 1px  solid  red}", b"a{--foo:1px  solid  red}"),
    ("a{x: var(--0);}", b"a{x:var(--0)}"),
    ("a{margin:var(--a,0px)}", b"a{margin:var(--a,0px)}"),
]


@pytest.mark.parametrize("css,expected", CUSTOM_PROPERTY_CASES)
def test_custom_properties_keep_their_raw_value(css, expected):
    """`--foo` values are only whitespace-trimmed, never re-minified."""
    # CATCHES: collapsing the inner runs of whitespace in `1px  solid  red`,
    # or dropping a whitespace-only value instead of keeping one space.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        (".clearfix { *zoom: 1px; }", b".clearfix{*zoom:1px}"),
        (".clearfix { *zoom: 1px }", b".clearfix{*zoom:1px}"),
        (".clearfix { order:4; *zoom: 1px; color:red; }", b".clearfix{order:4;*zoom:1px;color:red}"),
    ],
    ids=["star-hack", "star-hack-no-semi", "star-hack-mixed"],
)
def test_ie_star_hacks_survive(css, expected):
    """An invalid `*prop: value` declaration is copied through verbatim."""
    # CATCHES: aborting on the bad declaration, or dropping it and everything
    # after it in the block.
    assert css_out(css) == expected


PROGID_CASES = [
    ("a{filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);}", b"a{filter:alpha(opacity=0)}"),
    ("a{filter: progid:DXImageTransform.Microsoft.Alpha(Opacity = 80);}", b"a{filter:alpha(opacity=80)}"),
    ('a{-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=80)";}', b'a{-ms-filter:"alpha(opacity=80)"}'),
    ('a{-MS-FILTER:"progid:DXImageTransform.Microsoft.Alpha(Opacity=80)"}', b'a{-ms-filter:"alpha(opacity=80)"}'),
    (
        "a{filter: progid : DXImageTransform.Microsoft.BasicImage(rotation=1);}",
        b"a{filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=1)}",
    ),
    ("a{filter:progid:b().c.Alpha(rgba(x));}", b"a{filter:progid:b().c.Alpha(rgba(x))}"),
    ("a{filter:blur(5px)}", b"a{filter:blur(5px)}"),
]


@pytest.mark.parametrize("css,expected", PROGID_CASES)
def test_progid_filters_are_shortened(css, expected):
    """Only the DXImageTransform.Microsoft.Alpha form becomes `alpha(...)`."""
    # CATCHES: shortening every progid filter (BasicImage must stay), or
    # failing to strip the quotes around the -ms-filter string.
    assert css_out(css) == expected


URL_CASES = [
    ("a{background:url('http://domain.com/image.png');}", b"a{background:url(http://domain.com/image.png)}"),
    ("a{background:url( 'http://domain.com/image.png' );}", b"a{background:url(http://domain.com/image.png)}"),
    ("a{background:url(/*nocomment*/)}", b"a{background:url(/*nocomment*/)}"),
    ("a{background:url(data:,text)}", b"a{background:url(data:,text)}"),
    ("a{background:url('data:text/xml; version = 2.0,content')}", b"a{background:url(data:text/xml;version=2.0,content)}"),
    ("a{background:URL(x.PNG);}", b"a{background:URL(x.PNG)}"),
    ('a{background:url("a\'b")}', b'a{background:url("a\'b")}'),
    ("a{background:url('a b')}", b"a{background:url('a b')}"),
    ("a{background:url(   )}", b"a{background:url(   )}"),
    ("a{background:url(abcdef)}", b"a{background:url(abcdef)}"),
]


@pytest.mark.parametrize("css,expected", URL_CASES)
def test_url_is_unquoted_when_possible(css, expected):
    """url() loses its quotes unless the URI needs them."""
    # CATCHES: unquoting a URI with spaces or quotes in it, or lowercasing the
    # `URL(` function name.
    assert css_out(css) == expected


DATA_URI_CASES = [
    (
        'a{background:url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%20%3Cg%3E%20%20%3C/g%3E%0A%20%3C%21--%20c%20--%3E%0A%3C/svg%3E")}',
        b"a{background:url(data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg/%3E%3C/svg%3E)}",
    ),
    (
        'a{background:url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==")}',
        b'a{background:url(data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22/%3E)}',
    ),
    (
        'a{background:url("data:text/css,body{margin:0 0 0 0}")}',
        b"a{background:url(data:text/css,body%7Bmargin:0%7D)}",
    ),
    (
        'a{background:url("data:image/png;base64,iVBORw0KGgo=")}',
        b"a{background:url(data:image/png,%89PNG%0D%0A%1A%0A)}",
    ),
    (
        'a{background:url("data:image/svg+xml,%3Csvg%3E%3C/svg%3E")}',
        b"a{background:url(data:image/svg+xml,%3Csvg/%3E)}",
    ),
]


@pytest.mark.parametrize("css,expected", DATA_URI_CASES)
def test_data_uris_are_reminified_by_their_mediatype(css, expected):
    """A data: URI is decoded, minified by its own minifier and re-encoded."""
    # CATCHES: passing the data: URI through untouched, or re-encoding as
    # base64 when percent-encoding is shorter.
    assert css_out(css) == expected


WHITESPACE_CASES = [
    ("a{margin :   1px   2px  }", b"a{margin:1px 2px}"),
    ("a{margin:1px\n\n2px}", b"a{margin:1px 2px}"),
    ("a{margin:\t1px\t\t2px\t}", b"a{margin:1px 2px}"),
    ("a{margin:1px/*c*/2px}", b"a{margin:1px 2px}"),
    ("a{x: white , white}", b"a{x:white,white}"),
    ("a{margin:calc(10px) calc(20px)}", b"a{margin:calc(10px)calc(20px)}"),
    (
        "a{padding:calc(var(--dce-edge-xsmall,6px) - 2px) calc(var(--dce-button-horizontal-padding,18px) - 2px)}",
        b"a{padding:calc(var(--dce-edge-xsmall,6px) - 2px)calc(var(--dce-button-horizontal-padding,18px) - 2px)}",
    ),
    ("a{width:calc(0%-0px)}", b"a{width:calc(0%0px)}"),
    ("a{width:calc(0% - 0px)}", b"a{width:calc(0% - 0px)}"),
    ("a{background:url(url) TOP RIGHT REPEAT-Y}", b"a{background:url(url)100% 0 REPEAT-Y}"),
    ("a{color=blue}", b"a{color=blue}"),
    ("a{margin: rgb((brackets));}", b"a{margin:rgb((brackets))}"),
    ("a{width:attr(Name em)}", b"a{width:attr(Name em)}"),
    ("a{content:CounterName}", b"a{content:CounterName}"),
    ("a{animation:Ident}", b"a{animation:Ident}"),
    ("a{animation-name:Ident}", b"a{animation-name:Ident}"),
]


@pytest.mark.parametrize("css,expected", WHITESPACE_CASES)
def test_whitespace_and_separators_in_values(css, expected):
    """Runs of whitespace become one space; adjacent functions need none."""
    # CATCHES: removing the space inside `calc(0% - 0px)` (which changes the
    # meaning), or adding a space between two adjacent calc() calls.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ('a{content:"a\\\nb"}', b'a{content:"ab"}'),
        ('a{content:"a\\\r\nb\\\r\nc"}', b'a{content:"abc"}'),
        ('a{content:""}', b'a{content:""}'),
    ],
    ids=["escaped-lf", "escaped-crlf", "empty"],
)
def test_string_escape_newlines_are_removed(css, expected):
    """A backslash-newline continuation inside a string joins the two halves."""
    # CATCHES: keeping the backslash and newline, which would leave the string
    # split across two physical lines.
    assert css_out(css) == expected


BAD_DECLARATION_CASES = [
    ("a{a:)'''}", b"a{a:)'''}}"),
    ("{T:l(", b"{t:l()}"),
    ("@import url(", b"@import url(;"),
    ('a{-ms-filter:"', b'a{-ms-filter:"}'),
    ("a{color:red}\x00", b"a{color:red}\x00"),
    ('a{content:"unclosed', b'a{content:"unclosed}'),
    ("a{color:}", b"a{color:}"),
    ("}", b"}"),
    ("@", b"@"),
    ("a{a:)'''}\nb{c:d}", b"a{a:)'''}\nb{c:d}"),
    ("a{000}", b"a{000}"),
    ("a{color:0;baddecl 5}", b"a{color:0;baddecl 5}"),
    ("a{margin=5}", b"a{margin=5}"),
    ('a[id="x" i],b{color:0}', b"a[id=x i],b{color:0}"),
    ("a{color:()!important}", b"a{color:()!important}"),
    ("a{margin:5 4}", b"a{margin:5 4}"),
]


@pytest.mark.parametrize("css,expected", BAD_DECLARATION_CASES)
def test_invalid_declarations_pass_through_and_minification_continues(css, expected):
    """Malformed input is echoed and the rest of the stylesheet is still minified."""
    # CATCHES: exiting non-zero, or dropping the ruleset that follows the bad
    # declaration (as in `a{a:)'''}\nb{c:d}`).
    assert css_out(css) == expected


def test_missing_right_brace_is_synthesised():
    """An unterminated block gets its closing brace added on output."""
    # CATCHES: emitting `a{a:)'''` without the trailing `}`, leaving unbalanced
    # braces in the result.
    assert css_out("a{a:)'''}") == b"a{a:)'''}}"
