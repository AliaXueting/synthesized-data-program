"""Comment handling and ruleset/at-rule structure.

Only `/*! ... */` bang comments survive; anything that ends up empty is
dropped entirely rather than left as `a{}`.
"""

import pytest
from conftest import css_out

# Constructs that minify away entirely are each followed by a surviving
# `i{a:b}` ruleset, so the expected output is non-empty and proves the
# neighbour was kept while the construct itself disappeared.
CASES = [
    ("a {\n  color: blue;\n}\n", b"a{color:blue}"),
    ("/*comment*/i{a:b}", b"i{a:b}"),
    ("a{}i{a:b}", b"i{a:b}"),
    ("a{ }i{a:b}", b"i{a:b}"),
    ("a{} b{} .c{color:red}", b".c{color:red}"),
    ("@media screen{}i{a:b}", b"i{a:b}"),
    ("@font-face{}i{a:b}", b"i{a:b}"),
    ("a{/*x*/color:red}", b"a{color:red}"),
    ("a{color:red;}", b"a{color:red}"),
    ("a{color:red;;}", b"a{color:red}"),
    ("a, b, c { /* lala */ }i{a:b}", b"i{a:b}"),
    ("a { b: 1", b"a{b:1}"),
    ("html{line-height:1;}html{line-height:1;}", b"html{line-height:1}html{line-height:1}"),
    ("i{a:b;}/*! bang  comment */", b"i{a:b}/*!bang comment*/"),
    ("a {/* keep */ b:c}", b"a{b:c}"),
]


@pytest.mark.parametrize("css,expected", CASES)
def test_structure_is_minified(css, expected):
    """Whole-stylesheet structure: comments, empty blocks and semicolons."""
    # CATCHES: leaving `a{}` behind, keeping a trailing semicolon before `}`,
    # or dropping a ruleset that still holds a declaration.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("/*! bang  comment */", b"/*!bang comment*/"),
        ("/*!bang*/", b"/*!bang*/"),
        ("/*!   */", b"/*!*/"),
        ("/*!\t a \t\t b  \n c  */", b"/*!a b\nc*/"),
        ("/*!a\n\n\nb*/a{c:d}", b"/*!a\nb*/a{c:d}"),
    ],
    ids=["collapse", "tight", "spaces-only", "tabs", "blank-lines"],
)
def test_bang_comments_are_kept_with_collapsed_whitespace(css, expected):
    """`/*! ... */` survives with internal runs of whitespace collapsed to one."""
    # CATCHES: dropping bang comments like normal ones, or keeping them
    # verbatim instead of collapsing `a  b` to `a b` while keeping newlines.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("/*# sourceMappingURL=x */a{b:c}", b"a{b:c}"),
        ("a{b:c}/*# sourceMappingURL=x */p{d:e}", b"a{b:c}p{d:e}"),
        ("a{b:c}/*# sourceMappingURL=url */", b"a{b:c}"),
    ],
    ids=["before-rule", "between-rules", "after-rule"],
)
def test_source_mapping_url_comment_is_removed(css, expected):
    """The `/*# sourceMappingURL=... */` pragma is dropped like a normal comment."""
    # CATCHES: treating the `#` pragma as a bang comment and keeping it, which
    # would leave `/*# sourceMappingURL=x */` bytes in the output.
    assert css_out(css) == expected


def test_bang_comment_between_rulesets_is_kept_in_place():
    """A bang comment between two rulesets stays there, not hoisted or dropped."""
    # CATCHES: emitting comments before the ruleset they follow, or dropping
    # them because the surrounding grammar is a ruleset.
    assert css_out("a{b:c}/*! x  y */p{d:e}") == b"a{b:c}/*!x y*/p{d:e}"


def test_empty_rulesets_are_dropped_but_neighbours_are_kept():
    """Only the empty ruleset disappears; surrounding rules survive in order."""
    # CATCHES: aborting the whole stylesheet once an empty block is seen.
    assert css_out("a{} b{} .c{color:red}") == b".c{color:red}"


def test_trailing_semicolons_are_removed():
    """The last declaration in a block loses its semicolon, doubled ones too."""
    # CATCHES: emitting `a{color:red;}` or keeping an empty declaration from
    # `;;`.
    assert css_out("a{color:red;;;}") == b"a{color:red}"


def test_unclosed_ruleset_at_eof_is_closed():
    """A ruleset left open at end of input is still emitted with its `}`."""
    # CATCHES: discarding the trailing, unterminated block.
    assert css_out("a { b: 1") == b"a{b:1}"
