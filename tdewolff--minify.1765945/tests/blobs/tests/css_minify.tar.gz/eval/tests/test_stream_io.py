"""Stream and file I/O behaviour of the CSS minifier.

Covers how a stylesheet reaches the minifier (stdin with --type css, or a .css
file) and what comes back out on stdout, stderr and the exit status.
"""

import hashlib

import pytest
from conftest import css_out, run_css, run_file, write_css

# A compact stylesheet that touches several minification paths at once.
SAMPLE = (
    "h1  , H2  { COLOR : #FF0000 ; MARGIN : 0PX 0 0 0 ; }\n"
    "@media screen and ( max-width:800px ){ .x { margin : 0px 0px 0px 0px ; } }\n"
    "/*! keep\n me */\n"
    "a{background:url( 'x.png' )}"
)
SAMPLE_OUT = (
    b"h1,h2{color:red;margin:0 0 0}"
    b"@media screen and (max-width:800px){.x{margin:0}}"
    b"/*!keep\nme*/"
    b"a{background:url(x.png)}"
)

# One block of realistic CSS, repeated 2000 times: 310000 bytes in.
BIG_BLOCK = (
    "a.r{margin:0px 0px 18px 0px;color:#FF0000;background:url('x.png') no-repeat;}\n"
    "@media screen and ( max-width: 800px ){ .r { padding : 1px 2px 1px 2px ; } }\n"
)
BIG_REPEATS = 2000
BIG_BLOCK_OUT = (
    b"a.r{margin:0 0 18px;color:red;background:url(x.png)no-repeat}"
    b"@media screen and (max-width:800px){.r{padding:1px 2px}}"
)
# sha256 of the full 234000-byte minified output, recorded from the reference.
BIG_SHA256 = "d3ff979b299523ef3dd201b3f0ed6567b73530ff09d1d6d302a49a1dcaf908db"
BIG_OUT_LEN = 234000


def test_stdin_type_css_minifies_stylesheet():
    """--type css reads a stylesheet from stdin and writes minified CSS out."""
    # CATCHES: a re-implementation that emits the input unchanged, that adds a
    # trailing newline, or that only handles one declaration per run.
    res = run_css(SAMPLE)
    assert res.returncode == 0
    assert res.stdout == SAMPLE_OUT
    assert res.stderr == b""


def test_stdin_output_has_no_trailing_newline():
    """Minified CSS is written without a trailing newline, even for one rule."""
    # CATCHES: adding the customary final newline that text tools emit would
    # change every single-recorded-expectation in this module.
    res = run_css("a {\n  color: blue;\n}\n")
    assert res.returncode == 0
    assert res.stdout == b"a{color:blue}"
    assert res.stderr == b""


def test_empty_stdin_gives_empty_stdout_and_zero_exit():
    """An empty stylesheet minifies to exactly zero bytes of output."""
    # CATCHES: emitting a newline, a BOM or an error for empty input, while a
    # non-empty stylesheet through the same code path still minifies normally.
    res = run_css(b"")
    assert res.returncode == 0
    assert res.stdout == b""
    assert res.stderr == b""
    # Contrast run through the same invocation shape: proves the empty result
    # comes from the input being empty, not from the binary writing nothing.
    contrast = run_css(b"a { COLOR : #FF0000 }")
    assert contrast.returncode == 0
    assert contrast.stdout == b"a{color:red}"
    assert contrast.stderr == b""


def test_css_file_input_minified_to_stdout(tmp_path):
    """A .css file argument is minified and written to stdout, not to the file."""
    # CATCHES: only supporting stdin, or rewriting the input file in place
    # without -i being requested.
    path = write_css(tmp_path, "in.css", SAMPLE)
    res = run_file(path)
    assert res.returncode == 0
    assert res.stdout == SAMPLE_OUT
    assert res.stderr == b""
    assert path.read_bytes() == SAMPLE.encode("utf-8")


def test_type_flag_selects_css_for_unknown_extension(tmp_path):
    """--type css forces the CSS minifier for a file with a non-CSS extension."""
    # CATCHES: deriving the minifier from the filename extension only, which
    # would make a .txt stylesheet be copied through untouched.
    path = write_css(tmp_path, "in.txt", SAMPLE)
    res = run_file(path, "--type", "css")
    assert res.returncode == 0
    assert res.stdout == SAMPLE_OUT
    assert res.stderr == b""


def test_stdin_and_file_inputs_agree(tmp_path):
    """The same stylesheet produces byte-identical output from stdin and file."""
    # CATCHES: a code path that treats file input differently from stdin (for
    # example by buffering differently or skipping the final flush).
    path = write_css(tmp_path, "same.css", SAMPLE)
    from_file = run_file(path)
    from_stdin = run_css(SAMPLE)
    assert from_file.returncode == 0
    assert from_stdin.returncode == 0
    assert from_file.stdout == from_stdin.stdout == SAMPLE_OUT
    assert from_file.stderr == from_stdin.stderr == b""


def test_large_input_is_minified_consistently():
    """A 310 KB stylesheet is minified as a whole with no truncation."""
    # CATCHES: a fixed-size buffer, a chunked writer that drops the tail, or a
    # per-declaration limit that stops after the first few hundred rules.
    res = run_css(BIG_BLOCK * BIG_REPEATS)
    assert res.returncode == 0
    assert res.stderr == b""
    assert len(res.stdout) == BIG_OUT_LEN
    assert hashlib.sha256(res.stdout).hexdigest() == BIG_SHA256
    assert res.stdout == BIG_BLOCK_OUT * BIG_REPEATS


def test_invalid_css_precision_value_is_rejected():
    """--css-precision only accepts integers; anything else aborts with usage."""
    # CATCHES: implementing --css-precision as a string flag (or silently
    # defaulting a bad value) instead of failing the parse.
    res = run_css(b"a{margin:1px}", "--css-precision", "abc")
    assert res.returncode == 2
    assert res.stderr == b"option --css-precision: invalid integer 'abc'\n\n"
    # The whole option table is dumped on stdout, so the minified CSS is gone.
    assert b"a{margin:1px}" not in res.stdout
    assert b"Number of significant digits to preserve in numbers" in res.stdout


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("﻿a{color:red}", b"\xef\xbb\xbfa{color:red}"),
        ("a {\r\n  color: red;\r\n}\r\n", b"a{color:red}"),
        ("a {\r  color: red;\r}\r", b"a{color:red}"),
        ('a{content:"日本語"}', 'a{content:"日本語"}'.encode("utf-8")),
        ('a{content:"\\0041"}', b'a{content:"\\0041"}'),
    ],
    ids=["bom", "crlf", "cr", "utf8", "escape"],
)
def test_bom_crlf_and_multibyte_survive(raw, expected):
    """Byte-level input quirks are normalised without corrupting the output."""
    # CATCHES: decoding as UTF-8 and re-encoding (which would strip the BOM or
    # mangle lone CRs), or losing non-ASCII bytes inside strings.
    assert css_out(raw) == expected


def test_type_equals_form_is_accepted():
    """--type=css works as well as the space-separated spelling."""
    # CATCHES: only registering the '--type VALUE' form of the flag.
    res = run_css(b"a{color:red}", "--type=css")
    assert res.returncode == 0
    assert res.stdout == b"a{color:red}"
    assert res.stderr == b""
