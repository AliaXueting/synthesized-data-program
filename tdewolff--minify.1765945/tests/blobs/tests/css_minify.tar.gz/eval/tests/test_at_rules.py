"""At-rule handling: @import rewriting, @media normalisation and nesting.
"""

import pytest
from conftest import css_out

IMPORT_CASES = [
    ("@import 'file';", b"@import 'file';"),
    ("@import url('file');", b"@import 'file';"),
    ('@import url("file");', b'@import "file";'),
    ("@import url(//url);", b'@import "//url";'),
    ("@import url(\n//url\n);", b'@import "//url";'),
    ("@import url();", b'@import "";'),
]


@pytest.mark.parametrize("css,expected", IMPORT_CASES)
def test_import_url_is_rewritten_to_quoted_string(css, expected):
    """`@import url(...)` becomes a double-quoted string, with the `;` kept."""
    # CATCHES: leaving the url() form, dropping the trailing semicolon, or
    # keeping the surrounding whitespace that was inside the parentheses.
    assert css_out(css) == expected


def test_import_url_with_surrounding_whitespace_keeps_the_quotes():
    """Whitespace-padded url() keeps its quote characters in the output."""
    # CATCHES: trimming one character too few, which is what makes the
    # reference emit the inner quotes as part of the URL.
    assert css_out("@import url( 'f' );") == b"@import \"'f'\";"


def test_import_with_media_qualifier_is_untouched():
    """An @import with a media list keeps its url() spelling."""
    # CATCHES: rewriting every @import instead of only the bare two-token form.
    assert css_out("@import url('file') screen;") == b"@import url('file') screen;"


def test_charset_is_preserved_verbatim():
    """@charset is emitted unchanged, including its quoted value."""
    # CATCHES: unquoting the charset string or lowercasing its value.
    assert css_out('@charset "utf-8";') == b'@charset "utf-8";'


@pytest.mark.parametrize(
    "css,expected",
    [
        ("@media only screen and (max-width : 800px){a:b}", b"@media only screen and (max-width:800px){a:b}"),
        (
            "@media (-webkit-min-device-pixel-ratio:1.5),(min-resolution:1.5dppx){a:b}",
            b"@media(-webkit-min-device-pixel-ratio:1.5),(min-resolution:1.5dppx){a:b}",
        ),
    ],
    ids=["query", "parens"],
)
def test_media_query_whitespace_is_normalized(css, expected):
    """@media prelude keeps keyword spacing but loses the space before `(`."""
    # CATCHES: writing `@media (` with a space, or removing the spaces that
    # separate the `and` keyword.
    assert css_out(css) == expected


def test_unknown_at_rule_body_is_preserved_verbatim():
    """An unrecognised at-rule's body is copied with its inner spacing intact."""
    # CATCHES: running declaration minification inside a rule the minifier does
    # not understand, which would strip the trailing space and shorten #000.
    assert css_out("@unknown { border:1px solid #000 }") == b"@unknown{border:1px solid #000 }"


@pytest.mark.parametrize(
    "css,expected",
    [
        ("@font-face { x:y; }", b"@font-face{x:y}"),
        ("@keyframes name{from{opacity:0}to{opacity:1}}", b"@keyframes name{from{opacity:0}to{opacity:1}}"),
        ("@KEYFRAMES name{0%{top:0}100%{top:10px}}", b"@keyframes name{0%{top:0}100%{top:10px}}"),
        ("@supports (display: flex){a{b:c}}", b"@supports(display:flex){a{b:c}}"),
    ],
    ids=["font-face", "keyframes", "KEYFRAMES", "supports"],
)
def test_known_at_rules_are_normalized(css, expected):
    """Known at-rules get their name lowercased and their prelude squeezed."""
    # CATCHES: lowercasing the keyframes animation name, or keeping the space
    # before the `(` of a @supports condition.
    assert css_out(css) == expected


def test_page_pseudo_selector_loses_its_space():
    """@page pseudo-pages are glued to the rule name."""
    # CATCHES: emitting `@page :first` with the original space.
    assert css_out("@page :first{margin:1in}") == b"@page:first{margin:1in}"


@pytest.mark.parametrize(
    "css,expected",
    [
        (
            "a{@media screen and (min-width:1024px){ width: 40%; } & h1 { font-size: clamp(2.5rem, 1rem + 3vw, 3.5rem)}}",
            b"a{@media screen and (min-width:1024px){width: 40%;}& h1{font-size:clamp(2.5rem,1rem + 3vw,3.5rem)}}",
        ),
        ("a{& :is(b) {c:d;} }", b"a{& :is(b){c:d}}"),
        ("a{&:is(b) :is(c) {d:e;} }", b"a{&:is(b) :is(c){d:e}}"),
        ("@media screen{@media print{a{b:c}}}", b"@media screen{@media print{a{b:c}}}"),
        ("@page{@footnotes{border: 1px solid black;}}", b"@page{@footnotes{border: 1px solid black;}}"),
        ("@scope (body) { :scope { color: red; } }", b"@scope(body){:scope { color: red; } }"),
    ],
    ids=["nested-media", "amp-space", "amp-attached", "media-in-media", "footnotes", "scope"],
)
def test_nested_rules_and_scopes(css, expected):
    """Nested at-rules and CSS nesting selectors keep their inner bodies."""
    # CATCHES: flattening the nesting, or re-minifying a body the reference
    # deliberately passes through verbatim (note `width: 40%;` keeps its space).
    assert css_out(css) == expected
