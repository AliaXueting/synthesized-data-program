"""Recognition of property names, keywords and identifiers.

The minifier matches every property name, value identifier, function name and
at-rule name against its internal registry of known CSS keywords.  This file
pins the observable side of that matching: legacy property names pass through
with a lowercased name while their keyword values keep their case, identifiers
that no registry entry can match (empty names, or longer than the longest
known keyword) survive verbatim, and the `important` keyword is matched
case-sensitively.
"""

import pytest
from conftest import css_out

# Property names that only resolve on the registry's secondary lookup after a
# primary miss; they are real CSS properties with no special minification, so
# they must survive untouched while neighbouring declarations still minify.
LEGACY_PROPERTIES = [
    ("a{RICHNESS:80;margin:0PX}", b"a{richness:80;margin:0}"),
    ("a{WORD-WRAP:BREAK-WORD;color:#FF0000}", b"a{word-wrap:BREAK-WORD;color:red}"),
    ("a{VOICE-FAMILY:male;padding:0PX 0PX}", b"a{voice-family:male;padding:0}"),
]


@pytest.mark.parametrize("css,expected", LEGACY_PROPERTIES)
def test_legacy_properties_pass_through_while_neighbours_minify(css, expected):
    """Legacy aural/wrap properties are kept; only their name is lowercased."""
    # CATCHES: a registry rewrite that drops or renames legacy properties such
    # as richness, voice-family or word-wrap, or one that lowercases their
    # keyword values (`BREAK-WORD`), would change these bytes.
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,expected",
    [
        ("a{x:Repeat-X}", b"a{x:Repeat-X}"),
        ("a{x:REPEAT-X}", b"a{x:REPEAT-X}"),
        ("a{background-repeat:repeat-x}", b"a{background-repeat:repeat-x}"),
    ],
    ids=["mixed-case", "upper-case", "real-property"],
)
def test_keyword_value_identifiers_keep_case(css, expected):
    """Value identifiers are matched case-sensitively and never re-cased."""
    # CATCHES: normalising value identifiers to lowercase (`REPEAT-X` becoming
    # `repeat-x`) or expanding them because their spelling matched a keyword.
    assert css_out(css) == expected


# Identifiers at or beyond the registry's maximum keyword length (27 chars,
# the length of `scrollbar-dark-shadow-color`).  The 27-char names still go
# through the lookup; the longer ones cannot match anything and must fall
# back to verbatim output.  Each stylesheet carries a minifiable neighbour.
OVERSIZED = [
    ("a{" + "a" * 28 + ":x;color:#FF0000}", b"a{" + b"a" * 28 + b":x;color:red}"),
    ("a{x:" + "b" * 32 + ";margin:0PX}", b"a{x:" + b"b" * 32 + b";margin:0}"),
    ("a{x:" + "c" * 28 + "(b);margin:0PX}", b"a{x:" + b"c" * 28 + b"(b);margin:0}"),
    ("@" + "d" * 29 + " b:c;a{color:red}", b"@" + b"d" * 29 + b" b:c;a{color:red}"),
    ("@;a{color:red}", b"@;a{color:red}"),
    ("@;", b"@"),
    ("a{scrollbar-dark-shadow-color:x;margin:0PX}", b"a{scrollbar-dark-shadow-color:x;margin:0}"),
    ("a{" + "e" * 27 + ":x;color:red}", b"a{" + b"e" * 27 + b":x;color:red}"),
]


@pytest.mark.parametrize("css,expected", OVERSIZED)
def test_oversized_identifiers_pass_through(css, expected):
    """Names longer than any known keyword (or an empty at-rule name) survive."""
    # CATCHES: dropping, truncating or crashing on identifiers beyond the
    # registry's maximum length, or on an at-rule with an empty name (`@;`
    # keeps its semicolon before a following rule but loses it at end of
    # input, where the ruleset after it still minifies).
    assert css_out(css) == expected


@pytest.mark.parametrize(
    "css,args,expected",
    [
        ("a{color:red !IMPORTANT}", (), b"a{color:red!IMPORTANT}"),
        ("a{color:red !IMPORTANT}", ("--css-version", "2"), b"a{color:red!IMPORTANT}"),
        ("a{color:red ! important}", (), b"a{color:red!important}"),
        ("a{color:red ! important}", ("--css-version", "2"), b"a{color:red !important}"),
    ],
    ids=["upper", "upper-v2", "spaced", "spaced-v2"],
)
def test_important_keyword_is_case_sensitive(css, args, expected):
    """Only lowercase `important` is recognised as the importance marker."""
    # CATCHES: matching `!IMPORTANT` case-insensitively would normalise it to
    # `!important`; instead it stays a literal value glued to the previous
    # token with no space even in CSS2 mode, while the lowercase spelling is
    # re-appended canonically (with the CSS2 space before it).
    assert css_out(css, *args) == expected
