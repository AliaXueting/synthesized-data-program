"""Shared helpers for the xml_svg_json_minify black-box test module.

Every test drives the reference binary purely through its CLI, using the
``PROGRAMGYM_EXECUTABLE`` environment variable so the same suite runs against
the candidate re-implementation.
"""

import os
import subprocess

import pytest

# The child gets a fully pinned environment so results cannot depend on the
# developer's shell.  GOCOVERDIR is propagated when the pipeline asks for it so
# the reference binary's source coverage can be measured through these runs.
_BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/tmp",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "TERM": "dumb",
    "NO_COLOR": "1",
}


def _child_env():
    env = dict(_BASE_ENV)
    cov_dir = os.environ.get("GOCOVERDIR")
    env.update({"GOCOVERDIR": cov_dir} if cov_dir else {})
    return env


def resolve_executable():
    """Return the path of the program under test, failing loudly if unset."""
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not exe:
        pytest.fail("PROGRAMGYM_EXECUTABLE must point at the reference binary")
    return exe


def run_prog(args, data=None, cwd=None, timeout=30):
    """Run the binary with ``args`` and optional stdin ``data`` (bytes).

    Returns ``subprocess.CompletedProcess`` with byte stdout/stderr.  The
    child environment is pinned (plus GOCOVERDIR when present); stdin is a
    closed pipe unless ``data`` is given, so no TTY is ever attached.
    """
    exe = resolve_executable()
    return subprocess.run(
        [exe] + list(args),
        input=data if data is not None else b"",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=_child_env(),
        cwd=cwd,
        timeout=timeout,
    )


def run_type(filetype, data, extra_args=()):
    """Minify ``data`` (bytes/str) as ``filetype`` by feeding it on stdin."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return run_prog(["--type", filetype] + list(extra_args), data=data)


def write_input(tmp_path, name, data):
    """Write ``data`` to ``tmp_path/name`` and return the path object."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    path = tmp_path / name
    path.write_bytes(data)
    return path


def run_file(path, extra_args=()):
    """Minify an existing file given by its path."""
    return run_prog(list(extra_args) + [str(path)])
