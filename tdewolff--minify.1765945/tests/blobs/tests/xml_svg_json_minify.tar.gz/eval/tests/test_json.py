"""Black-box tests for the JSON minifier.

JSON is minified by removing only the whitespace between tokens and
re-inserting the required commas and colons; numbers go through the shared
number minifier unless ``--json-keep-numbers`` is set.  Invalid input or
trailing content is a positioned parse error: exit code 1 with the original
bytes still on stdout.
"""

import pytest

from conftest import run_file, run_prog, run_type, write_input

WHITESPACE_CASES = [
    (b'{ "a" : 1 , "b" : [ true , false , null ] , "c" : { "d" : "x" } }', b'{"a":1,"b":[true,false,null],"c":{"d":"x"}}'),
    (b'[ [1] , [2] , { "a" : [ 1 , 2 ] } , { } , [ ] ]', b'[[1],[2],{"a":[1,2]},{},[]]'),
    (b'{\n  "a" : 1,\n  "b" : [\n    1,\n    2\n  ]\n}', b'{"a":1,"b":[1,2]}'),
    (b'  42  ', b'42'),
    (b'{"a":1,"a":2}', b'{"a":1,"a":2}'),
    (b'[[[[[[[[[1]]]]]]]]]', b'[[[[[[[[[1]]]]]]]]]'),
]


@pytest.mark.parametrize("source,expected", WHITESPACE_CASES)
def test_whitespace_between_tokens_is_removed(source, expected):
    """Only inter-token whitespace disappears; structure stays as written."""
    # CATCHES: dropping or duplicating separators, collapsing whitespace
    # inside string values, or rejecting empty and top-level-scalar input.
    res = run_type("json", source)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_empty_and_whitespace_only_documents_minify_to_nothing():
    """A document that is only whitespace (or nothing at all) is valid JSON
    text and minifies to zero bytes with exit code 0, not a parse error."""
    # CATCHES: rejecting an empty or whitespace-only document as invalid
    # input, or emitting the whitespace back instead of an empty stream.
    # The trailing control run makes sure a run that still outputs nothing
    # only passes when the binary really consumed the whitespace.
    for source in (b"", b"  \n\t ", b"\r\n"):
        res = run_type("json", source)
        assert res.returncode == 0
        assert res.stdout == b""
        assert res.stderr == b""

    # guard against a no-output dummy: the same run helper must still emit
    # minified bytes for a non-empty document in this very test
    res = run_type("json", b" [1] ")
    assert res.returncode == 0
    assert res.stdout == b"[1]"


def test_string_contents_are_preserved_byte_for_byte():
    # CATCHES: escapes, unicode escapes (including surrogate pairs), slashes
    # and inner whitespace must not be re-encoded, unescaped or collapsed
    # while the tokens around them compress.
    doc = b'{"a":"x  y\\n\\t\\"q\\"","b":"\\u00e9\\u00e9"}'
    res = run_type("json", doc)
    assert res.returncode == 0
    assert res.stdout == doc

    doc = b'["\\u0041\\u00e9\\ud83d\\ude00","\\\\","\\/" ,"\\b\\f\\n\\r\\t"]'
    res = run_type("json", doc)
    assert res.returncode == 0
    assert res.stdout == b'["\\u0041\\u00e9\\ud83d\\ude00","\\\\","\\/","\\b\\f\\n\\r\\t"]'


NUMBER_CASES = [
    (b"[1000, 1e3, 1E+3, 0.5, -0.5, -0, 0.0, 1.500]", b"[1e3,1e3,1e3,0.5,-0.5,0,0,1.5]"),
    (b"[0.000001, 0.0001, 1e-5, 2.5e-8, -1e-3, 0.0e0, 5e0]", b"[1e-6,1e-4,1e-5,25e-9,-0.001,0,5]"),
    (b"[1e309, 1e-309, 123456789012345678901234567890]", b"[1e309,1e-309,123456789012345678901234567890]"),
]


@pytest.mark.parametrize("source,expected", NUMBER_CASES)
def test_number_tokens_are_shortened(source, expected):
    """Numbers are rewritten to their shortest form: exponents, no minus
    zero, no trailing fractional zeros."""
    # CATCHES: writing 1000 instead of 1e3, keeping -0 or 1.500, or
    # rounding very long integer literals that must stay untouched.
    res = run_type("json", source)
    assert res.returncode == 0
    assert res.stdout == expected


def test_keep_numbers_flag_preserves_number_tokens():
    # CATCHES: --json-keep-numbers leaves every number byte-identical (only
    # whitespace is removed) and also overrides --json-precision.
    res = run_type("json", b"[1000, 0.5, 1.500, 1e3, 0.000001]", ["--json-keep-numbers"])
    assert res.returncode == 0
    assert res.stdout == b"[1000,0.5,1.500,1e3,0.000001]"

    res = run_type("json", b"[1.500, 999.9]", ["--json-keep-numbers", "--json-precision", "2"])
    assert res.returncode == 0
    assert res.stdout == b"[1.500,999.9]"


PRECISION_CASES = [
    (b"[3.14159265358979, 123456, 0.0012345, 1234567890123]", "3", b"[3.14,123e3,0.00123,123e10]"),
    (b"[1.234e5, 0.001234, 999.9, 9.99]", "2", b"[12e4,0.0012,1e3,10]"),
]


@pytest.mark.parametrize("source,precision,expected", PRECISION_CASES)
def test_json_precision_rounds_and_rewrites_exponents(source, precision, expected):
    """--json-precision keeps N significant digits, rounding half up and
    switching to exponent notation when that is shorter."""
    # CATCHES: truncating instead of rounding (999.9 to 1e3), or losing the
    # exponent rewrite for large integers (123456 to 123e3).
    res = run_type("json", source, ["--json-precision", precision])
    assert res.returncode == 0
    assert res.stdout == expected


ERROR_CASES = [
    (b"{", b"expected object key to be a quoted string on line 1 and column 2\n    1: {\n        ^\n"),
    (b"[1] x", b"expected comma character or an array or object ending on line 1 and column 5\n    1: [1] x\n           ^\n"),
    (b'{ "a" "b"}', b"expected colon character after object key on line 1 and column 7\n    1: { \"a\" \"b\"}\n             ^\n"),
    (b'{ "a" : }', b"unexpected right brace character on line 1 and column 9\n    1: { \"a\" : }\n               ^\n"),
]


@pytest.mark.parametrize("source,message", ERROR_CASES)
def test_invalid_json_is_a_positioned_parse_error(source, message):
    """Invalid JSON exits 1, echoes the original bytes to stdout and prints
    a caret diagnostic pointing at the offending position."""
    # CATCHES: missing the exact parser message, the line/column position or
    # the fallback that copies the unminified input to stdout.
    res = run_type("json", source)
    assert res.returncode == 1
    assert res.stdout == source
    assert res.stderr == b"ERROR: cannot minify -: " + message


def test_json_routing_by_extension_and_mimetype(tmp_path):
    # CATCHES: .json and .webmanifest files and any ``*+json`` mimetype all
    # reach the JSON minifier (whitespace removed, numbers shortened).
    a = write_input(tmp_path, "a.json", b'{ "a" : 1 }')
    res = run_file(a)
    assert res.returncode == 0
    assert res.stdout == b'{"a":1}'

    b = write_input(tmp_path, "b.webmanifest", b'{ "name" : "x" , "short_name" : "y" }')
    res = run_file(b)
    assert res.returncode == 0
    assert res.stdout == b'{"name":"x","short_name":"y"}'

    for mimetype in ("application/json", "application/manifest+json", "application/vnd.api+json"):
        res = run_type(mimetype, b'{ "a" : 1 }')
        assert res.returncode == 0
        assert res.stdout == b'{"a":1}'


def test_short_type_names_must_exist_in_the_extension_map():
    # CATCHES: --type resolves short names through the extension map, so
    # importmap and speculationrules (registered only as mimetypes for
    # embedded use) are rejected with exit code 1 and an empty name in the
    # error message, before any input is read.
    for name in ("importmap", "speculationrules"):
        res = run_prog(["--type", name], b"{}")
        assert res.returncode == 1
        assert res.stdout == b""
        assert res.stderr == b"ERROR: unknown filetype \n"


def test_real_world_twitter_sample():
    """A real tweet object minifies: inter-token whitespace goes, the 18-digit
    id stays exact and string contents are untouched."""
    # CATCHES: rounding the 18-digit id, re-escaping the quotes inside the
    # embedded HTML source string, or leaving newlines and indentation.
    source = r'''[{
  "created_at": "Thu Jun 22 21:00:00 +0000 2017",
  "id": 877994604561387500,
  "id_str": "877994604561387520",
  "text": "Creating a Grocery List Manager Using Angular, Part 1: Add &amp; Display Items https://t.co/xFox78juL1 #Angular",
  "truncated": false,
  "entities": {
    "hashtags": [{
      "text": "Angular",
      "indices": [103, 111]
    }],
    "symbols": [],
    "user_mentions": [],
    "urls": [{
      "url": "https://t.co/xFox78juL1",
      "expanded_url": "http://buff.ly/2sr60pf",
      "display_url": "buff.ly/2sr60pf",
      "indices": [79, 102]
    }]
  },
  "source": "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "user": {
    "id": 772682964,
    "id_str": "772682964",
    "name": "SitePoint JavaScript",
    "screen_name": "SitePointJS",
    "location": "Melbourne, Australia",
    "description": "Keep up with JavaScript tutorials, tips, tricks and articles at SitePoint.",
    "url": "http://t.co/cCH13gqeUK",
    "entities": {
      "url": {
        "urls": [{
          "url": "http://t.co/cCH13gqeUK",
          "expanded_url": "http://sitepoint.com/javascript",
          "display_url": "sitepoint.com/javascript",
          "indices": [0, 22]
        }]
      },
      "description": {
        "urls": []
      }
    },
    "protected": false,
    "followers_count": 2145,
    "friends_count": 18,
    "listed_count": 328,
    "created_at": "Wed Aug 22 02:06:33 +0000 2012",
    "favourites_count": 57,
    "utc_offset": 43200,
    "time_zone": "Wellington"
  }
}]
'''
    res = run_type("json", source)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == r'''[{"created_at":"Thu Jun 22 21:00:00 +0000 2017","id":877994604561387500,"id_str":"877994604561387520","text":"Creating a Grocery List Manager Using Angular, Part 1: Add &amp; Display Items https://t.co/xFox78juL1 #Angular","truncated":false,"entities":{"hashtags":[{"text":"Angular","indices":[103,111]}],"symbols":[],"user_mentions":[],"urls":[{"url":"https://t.co/xFox78juL1","expanded_url":"http://buff.ly/2sr60pf","display_url":"buff.ly/2sr60pf","indices":[79,102]}]},"source":"<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>","user":{"id":772682964,"id_str":"772682964","name":"SitePoint JavaScript","screen_name":"SitePointJS","location":"Melbourne, Australia","description":"Keep up with JavaScript tutorials, tips, tricks and articles at SitePoint.","url":"http://t.co/cCH13gqeUK","entities":{"url":{"urls":[{"url":"http://t.co/cCH13gqeUK","expanded_url":"http://sitepoint.com/javascript","display_url":"sitepoint.com/javascript","indices":[0,22]}]},"description":{"urls":[]}},"protected":false,"followers_count":2145,"friends_count":18,"listed_count":328,"created_at":"Wed Aug 22 02:06:33 +0000 2012","favourites_count":57,"utc_offset":43200,"time_zone":"Wellington"}}]'''.encode("utf-8")
