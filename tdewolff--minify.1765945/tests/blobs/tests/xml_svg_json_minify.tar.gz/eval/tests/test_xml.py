"""Black-box tests for the XML minifier (text/xml and any ``*+xml`` type).

The XML minifier removes comments, collapses whitespace runs in text (a run
containing a newline collapses to a single newline, otherwise to a space),
trims whitespace around tags unless ``--xml-keep-whitespace`` is set, and
canonicalises entity references.
"""

import pytest

from conftest import run_type


def test_text_whitespace_runs_collapse_to_space_or_newline():
    # CATCHES: a run of whitespace collapses to one space, or one newline when
    # the run contained a newline; whitespace around tags is trimmed away.
    doc = "<a>\n  <b>text\n  here</b>   <c> x </c>\n</a>"
    res = run_type("xml", doc)
    assert res.returncode == 0
    assert res.stdout == b"<a><b>text\nhere</b><c> x</c></a>"
    assert res.stderr == b""


def test_keep_whitespace_flag_preserves_single_whitespace():
    # CATCHES: with --xml-keep-whitespace runs still collapse (to a space or a
    # newline) but whitespace next to tags is preserved instead of trimmed.
    doc = "<a>  <b>  </b>  <c>x</c>  </a>"
    res = run_type("xml", doc, ["--xml-keep-whitespace"])
    assert res.returncode == 0
    assert res.stdout == b"<a> <b/> <c>x</c> </a>"
    assert res.stderr == b""


def test_whitespace_between_text_and_void_tag_is_asymmetric():
    # CATCHES: text following a void tag keeps its leading space when the
    # preceding text lost its trailing space to the void tag boundary.
    doc = "<r> <a/> text <b/> more </r>"
    res = run_type("xml", doc)
    assert res.returncode == 0
    assert res.stdout == b"<r><a/>text<b/> more</r>"


def test_comments_are_always_removed():
    # CATCHES: comments are dropped everywhere in the document, including
    # before the root element and between siblings; there is no keep flag.
    doc = "<!-- lead --><a><!-- inner --><b>x</b><!-- tail --></a><!-- end -->"
    res = run_type("xml", doc)
    assert res.returncode == 0
    assert res.stdout == b"<a><b>x</b></a>"


def test_doctype_and_processing_instructions_pass_through():
    # CATCHES: the XML declaration, DOCTYPE and processing instructions are
    # written back unchanged (the SVG-only removals do not apply to XML).
    doc = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE a SYSTEM "a.dtd">\n<?xml-stylesheet href="a.xsl" type="text/xsl"?><a x="1"/>'
    res = run_type("xml", doc)
    assert res.returncode == 0
    assert res.stdout == (
        b'<?xml version="1.0" encoding="UTF-8"?>'
        b'<!DOCTYPE a SYSTEM "a.dtd">'
        b'<?xml-stylesheet href="a.xsl" type="text/xsl"?><a x="1"/>'
    )


def test_pi_without_quoted_data_gets_mangled_to_attributes():
    # CATCHES: non-XML processing instructions are re-serialised through the
    # attribute grammar, turning free-form data into name=value pairs.
    res = run_type("xml", "<?pi target data goes here ?><a/>")
    assert res.returncode == 0
    assert res.stdout == b"<?pi target= data= goes= here=?><a/>"


def test_cdata_becomes_escaped_text_when_smaller():
    # CATCHES: CDATA sections are rewritten as escaped text when that is
    # shorter, escaping only < and &amp; while leaving > literal.
    res = run_type("xml", "<a><![CDATA[if a<b && c>d then e]]></a>")
    assert res.returncode == 0
    assert res.stdout == b"<a>if a&lt;b &amp;&amp; c>d then e</a>"


def test_cdata_kept_when_escaping_would_be_longer():
    # CATCHES: a CDATA section needing more than 12 escape characters is kept
    # as CDATA rather than converted to escaped text.
    res = run_type("xml", "<a><![CDATA[ <<<<< ]]></a>")
    assert res.returncode == 0
    assert res.stdout == b"<a><![CDATA[ <<<<< ]]></a>"


def test_empty_cdata_prevents_empty_tag_collapse():
    # CATCHES: an empty CDATA section is dropped but still counts as content
    # for the look-ahead, so <a></a> is not collapsed to a void tag.
    res = run_type("xml", "<a><![CDATA[]]></a>")
    assert res.returncode == 0
    assert res.stdout == b"<a></a>"


def test_empty_and_mismatched_tags_collapse_to_void_tag():
    # CATCHES: an element whose only content is whitespace collapses to <x/>,
    # and the collapsed end tag's name is not validated so <a></b> gives <a/>.
    assert run_type("xml", "<g>  </g>").stdout == b"<g/>"
    assert run_type("xml", "<a></b>").stdout == b"<a/>"
    assert run_type("xml", "<a ></a >").stdout == b"<a/>"


def test_attribute_values_are_requoted_with_cheaper_quote():
    # CATCHES: a double-quoted value containing more double quotes than
    # apostrophes is re-quoted with apostrophes, escaping the apostrophe as
    # &#39; and dropping the no-longer-needed &quot; entities.
    res = run_type("xml", '<a b="a&quot;b&quot;c&apos;d"></a>')
    assert res.returncode == 0
    assert res.stdout == b"<a b='a\"b\"c&#39;d'/>"


def test_single_quoted_and_unquoted_attribute_values_stay_verbatim():
    # CATCHES: values that were not double-quoted are copied unchanged, and a
    # valueless attribute gains a bare = when the tag is re-serialised.
    assert run_type("xml", "<a b='single&quot;dq'></a>").stdout == b"<a b='single&quot;dq'/>"
    assert run_type("xml", "<a x = y></a>").stdout == b"<a x=y/>"
    assert run_type("xml", "<a x></a>").stdout == b"<a x=/>"


def test_attribute_whitespace_is_not_collapsed_but_newlines_normalize():
    # CATCHES: unlike text, attribute values keep their inner spaces; literal
    # newlines are normalised to spaces while &#10; references survive.
    res = run_type("xml", '<a b="  x  " c="a\nb" d="x&#10;y"></a>')
    assert res.returncode == 0
    assert res.stdout == b'<a b="  x  " c="a b" d="x&#10;y"/>'


@pytest.mark.parametrize(
    "source,expected",
    [
        # hex refs canonicalise to decimal refs
        (b"<a>&#x9;&#xA;&#xD;</a>", b"<a>&#9;&#10;&#13;</a>"),
        # decimal whitespace refs are already canonical
        (b"<a>&#9;end</a>", b"<a>&#9;end</a>"),
        # named refs decode to literals in text
        (b"<a>&lt;&gt;&amp;&quot;&apos;</a>", b"<a>&lt;&gt;&amp;\"'</a>"),
        # a decoded '>' is re-escaped as &gt; but a literal '>' is not
        (b"<a>&#62;</a>", b"<a>&gt;</a>"),
        # hex codepoint below 10000 is rewritten in decimal form
        (b"<a>&#x80;</a>", b"<a>&#128;</a>"),
        (b"<a>&#x270F;</a>", b"<a>&#9999;</a>"),
        # codepoints at or above 10000 are left exactly as written
        (b"<a>&#x2713;</a>", b"<a>&#x2713;</a>"),
        (b"<a>&#128512;</a>", b"<a>&#128512;</a>"),
        # unknown or unterminated entities are copied verbatim
        (b"<a>&unknown; &amp &apos</a>", b"<a>&unknown; &amp &apos</a>"),
        # an escaped ampersand followed by name characters stays escaped
        (b"<a>&#38;#60;</a>", b"<a>&amp;#60;</a>"),
    ],
)
def test_entity_reference_canonicalisation(source, expected):
    # CATCHES: the exact canonical form chosen for each character reference,
    # including the decimal/hex cutover at codepoint 10000.
    res = run_type("xml", source)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_literal_tab_in_attribute_normalises_to_space():
    # CATCHES: a literal tab inside an attribute value is normalised to a
    # space by the lexer, which is why &#9; references must stay numeric.
    res = run_type("xml", b'<a t="a\tb"></a>')
    assert res.returncode == 0
    assert res.stdout == b'<a t="a b"/>'


def test_rss_extension_and_plus_xml_mimes_use_the_xml_minifier():
    # CATCHES: .rss files and any ``*+xml`` mimetype route to the XML
    # minifier, which (unlike SVG) keeps namespaces and tag prefixes.
    doc = b'<rss version="2.0"><channel><title>T </title></channel></rss>'
    res = run_type("application/rss+xml", doc)
    assert res.returncode == 0
    assert res.stdout == b"<rss version=\"2.0\"><channel><title>T</title></channel></rss>"

    namespaced = b'<a:x xmlns:a="urn:x"><a:b a:c="1" c="2">t</a:b></a:x>'
    res = run_type("text/xml", namespaced)
    assert res.returncode == 0
    assert res.stdout == namespaced


def test_unclosed_input_is_tolerated_and_streamed():
    # CATCHES: the XML minifier is lenient, emitting what it lexed so far and
    # exiting 0 for truncated documents instead of failing.
    res = run_type("xml", "<a>")
    assert res.returncode == 0
    assert res.stdout == b"<a>"
    assert res.stderr == b""


def test_trailing_text_whitespace_is_trimmed_at_eof():
    # CATCHES: a text token ending in whitespace at EOF loses its final
    # whitespace character instead of collapsing it to a space or keeping it.
    assert run_type("xml", "<a>x ").stdout == b"<a>x"
    assert run_type("xml", "<a>x\n").stdout == b"<a>x"


def test_comment_between_text_tokens_transfers_whitespace():
    # CATCHES: whitespace before a comment is dropped only when the text
    # after the comment itself starts with whitespace; otherwise the space
    # before the comment survives verbatim instead of being collapsed.
    assert run_type("xml", "<a>x <!--c--> y</a>").stdout == b"<a>x y</a>"
    assert run_type("xml", "<a>x <!--c-->z</a>").stdout == b"<a>x z</a>"
    assert run_type("xml", "<a>x<!--c--> y</a>").stdout == b"<a>x y</a>"


def test_whitespace_lookahead_skips_cdata_and_processing_instructions():
    # CATCHES: the right-trim look-ahead walks over CDATA sections and whole
    # processing instructions (name, pseudo-attributes and close) to find the
    # next tag, trimming the trailing space only when a tag follows.
    assert run_type("xml", "<a>x <![CDATA[ y]]>z</a>").stdout == b"<a>x yz</a>"
    assert run_type("xml", "<a>x <![CDATA[y]]>z</a>").stdout == b"<a>x yz</a>"
    assert run_type("xml", "<a>x <?pi y?><c/></a>").stdout == b"<a>x<?pi y=?><c/></a>"


def test_lookahead_across_four_comments_grows_the_token_buffer():
    # CATCHES: look-ahead across four or more consecutive comment tokens
    # still finds the following tag and trims the whitespace (the token
    # buffer has to grow instead of wrapping around silently).
    res = run_type("xml", "<a>x " + "<!--c-->" * 4 + "<c/></a>")
    assert res.returncode == 0
    assert res.stdout == b"<a>x<c/></a>"


def test_end_tag_extra_whitespace_is_removed_but_inner_junk_stays():
    # CATCHES: whitespace before the closing greater-than is cut (`</a >` to
    # `</a>`) but any other extra content inside the end tag is copied
    # through untouched because it is part of the recorded tag name.
    assert run_type("xml", "<a>x</a >").stdout == b"<a>x</a>"
    assert run_type("xml", "<a>x</a  >").stdout == b"<a>x</a>"
    assert run_type("xml", "<a>x</a\n>").stdout == b"<a>x</a>"
    assert run_type("xml", "<a>x</a b >").stdout == b"<a>x</a b>"
    assert run_type("xml", "<a>x</a junk>").stdout == b"<a>x</a junk>"


def test_cdata_trailing_whitespace_left_trims_the_next_text():
    # CATCHES: CDATA counts as text for the whitespace state, so whitespace
    # at the end of a CDATA section suppresses the leading space of the next
    # text token, and a whitespace-only token after CDATA is dropped.
    assert run_type("xml", "<a><![CDATA[x ]]> y</a>").stdout == b"<a>x y</a>"
    assert run_type("xml", "<a><![CDATA[x]]> </a>").stdout == b"<a>x</a>"


def test_null_byte_is_a_positioned_error_with_original_output():
    # CATCHES: a literal NUL aborts minification with exit code 1, the
    # original bytes are still written to stdout, and stderr carries a caret
    # diagnostic that echoes the offending line with the NUL shown as a
    # middle dot.
    res = run_type("xml", b"<a>x\x00y</a>")
    assert res.returncode == 1
    assert res.stdout == b"<a>x\x00y</a>"
    assert res.stderr == (
        b"ERROR: cannot minify -: unexpected NULL character on line 1 and column 5\n"
        b"    1: <a>x\xc2\xb7y</a>\n"
        b"           ^\n"
    )


def test_attribute_references_decode_to_literal_delimiters():
    # CATCHES: in a double-quoted attribute only the chosen quote character
    # is re-escaped; decoded ampersand, less-than and greater-than stay
    # literal, and &#38;#60; is kept in entity form so it cannot recombine
    # into a new reference.
    res = run_type("xml", b'<a b="&#60;" c="&#62;" d="&#38;"></a>')
    assert res.returncode == 0
    assert res.stdout == b'<a b="<" c=">" d="&"/>'
    res = run_type("xml", b'<a b="&#38;#60;" c="&#38;"></a>')
    assert res.returncode == 0
    assert res.stdout == b'<a b="&#38;#60;" c="&"/>'


def test_cdata_is_converted_only_up_to_twelve_escape_characters():
    # CATCHES: CDATA becomes escaped text only while the total escape cost
    # stays within the twelve characters a CDATA wrapper would cost: three
    # ampersands or four less-than signs still convert, four ampersands do
    # not.
    assert run_type("xml", b"<a><![CDATA[&&&]]></a>").stdout == b"<a>&amp;&amp;&amp;</a>"
    assert run_type("xml", b"<a><![CDATA[<<<<]]></a>").stdout == b"<a>&lt;&lt;&lt;&lt;</a>"
    assert run_type("xml", b"<a><![CDATA[&&&&]]></a>").stdout == b"<a><![CDATA[&&&&]]></a>"


def test_character_references_zero_and_space_decode_to_literals():
    # CATCHES: &#0; decodes to a literal NUL byte in the output without
    # triggering the lexer error a literal NUL would, while &#32; decodes to
    # a literal space (unlike tab/LF/CR which must stay numeric).
    res = run_type("xml", b"<a>a&#0;b</a>")
    assert res.returncode == 0
    assert res.stdout == b"<a>a\x00b</a>"
    assert res.stderr == b""
    assert run_type("xml", "<a>a&#32;b</a>").stdout == b"<a>a b</a>"


def test_doctype_internal_subset_and_xhtml_routing_stay_with_xml():
    # CATCHES: a DOCTYPE with an internal subset is copied verbatim
    # (declarations are not expanded), and both the short name `xhtml` and
    # application/xhtml+xml route to the XML minifier, not the HTML one.
    doc = b'<!DOCTYPE a [<!ENTITY x "y">]><a>&x;</a>'
    res = run_type("xml", doc)
    assert res.returncode == 0
    assert res.stdout == doc

    res = run_type("xhtml", '<html xmlns="http://www.w3.org/1999/xhtml"><body>  x  </body></html>')
    assert res.returncode == 0
    assert res.stdout == b'<html xmlns="http://www.w3.org/1999/xhtml"><body>x</body></html>'
    res = run_type("application/xhtml+xml", "<html><body>  x  </body></html>")
    assert res.returncode == 0
    assert res.stdout == b"<html><body>x</body></html>"


def test_real_world_catalog_sample():
    """A real product catalog with an XSL stylesheet PI, a DOCTYPE and nested
    items minifies with its prelude kept byte-for-byte."""
    # CATCHES: dropping the xml-stylesheet PI or DOCTYPE, re-quoting the
    # gender="Men's" attribute, or leaving indentation whitespace behind.
    source = '''<?xml version="1.0"?>
<?xml-stylesheet href="catalog.xsl" type="text/xsl"?>
<!DOCTYPE catalog SYSTEM "catalog.dtd">
<catalog>
   <product description="Cardigan Sweater" product_image="cardigan.jpg">
      <catalog_item gender="Men's">
         <item_number>QWZ5671</item_number>
         <price>39.95</price>
         <size description="Medium">
            <color_swatch image="red_cardigan.jpg">Red</color_swatch>
            <color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch>
         </size>
         <size description="Large">
            <color_swatch image="red_cardigan.jpg">Red</color_swatch>
            <color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch>
         </size>
      </catalog_item>
      <catalog_item gender="Women's">
         <item_number>RRX9856</item_number>
         <price>42.50</price>
         <size description="Small">
            <color_swatch image="red_cardigan.jpg">Red</color_swatch>
            <color_swatch image="navy_cardigan.jpg">Navy</color_swatch>
            <color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch>
         </size>
         <size description="Medium">
            <color_swatch image="red_cardigan.jpg">Red</color_swatch>
            <color_swatch image="navy_cardigan.jpg">Navy</color_swatch>
            <color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch>
            <color_swatch image="black_cardigan.jpg">Black</color_swatch>
         </size>
         <size description="Large">
            <color_swatch image="navy_cardigan.jpg">Navy</color_swatch>
            <color_swatch image="black_cardigan.jpg">Black</color_swatch>
         </size>
         <size description="Extra Large">
            <color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch>
            <color_swatch image="black_cardigan.jpg">Black</color_swatch>
         </size>
      </catalog_item>
   </product>
</catalog>
'''
    res = run_type("xml", source)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == '''<?xml version="1.0"?><?xml-stylesheet href="catalog.xsl" type="text/xsl"?><!DOCTYPE catalog SYSTEM "catalog.dtd"><catalog><product description="Cardigan Sweater" product_image="cardigan.jpg"><catalog_item gender="Men's"><item_number>QWZ5671</item_number><price>39.95</price><size description="Medium"><color_swatch image="red_cardigan.jpg">Red</color_swatch><color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch></size><size description="Large"><color_swatch image="red_cardigan.jpg">Red</color_swatch><color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch></size></catalog_item><catalog_item gender="Women's"><item_number>RRX9856</item_number><price>42.50</price><size description="Small"><color_swatch image="red_cardigan.jpg">Red</color_swatch><color_swatch image="navy_cardigan.jpg">Navy</color_swatch><color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch></size><size description="Medium"><color_swatch image="red_cardigan.jpg">Red</color_swatch><color_swatch image="navy_cardigan.jpg">Navy</color_swatch><color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch><color_swatch image="black_cardigan.jpg">Black</color_swatch></size><size description="Large"><color_swatch image="navy_cardigan.jpg">Navy</color_swatch><color_swatch image="black_cardigan.jpg">Black</color_swatch></size><size description="Extra Large"><color_swatch image="burgundy_cardigan.jpg">Burgundy</color_swatch><color_swatch image="black_cardigan.jpg">Black</color_swatch></size></catalog_item></product></catalog>'''.encode("utf-8")
