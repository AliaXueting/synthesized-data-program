"""Black-box tests for the shared helpers in common.go.

Number, Decimal, Mediatype and DataURI are not directly addressable from
the CLI, so each is exercised through a format that routes through it:
Number via JSON numbers, Decimal via CSS lengths inside an SVG ``<style>``
(with ``--css-version 2``, which is the only route that selects Decimal
instead of Number for CSS values), Mediatype via the SVG
``contentStyleType`` attribute and DataURI via CSS ``url()`` values.
``UpdateErrorPosition`` is reached by routing a ``style`` attribute or
element through a non-CSS ``contentStyleType`` whose inner minifier fails.
"""

import pytest

from conftest import run_type

XMLNS = ' xmlns="http://www.w3.org/2000/svg"'
STYLE_OPEN = b"<svg" + XMLNS.encode() + b"><style>"
STYLE_CLOSE = b"</style></svg>"


def run_style_css(css, extra_args=()):
    """Minify CSS text embedded in an SVG <style> element."""
    doc = STYLE_OPEN + css + STYLE_CLOSE
    return run_type("svg", doc, extra_args)


@pytest.mark.parametrize(
    "source,expected",
    [
        # rounding is half away from zero at the cut digit
        (b"[0.15, 0.25, 1.05, 9.99, 0.5]", b"[0.2,0.3,1,10,0.5]"),
        # integers are rounded to significant digits too, then re-exponented
        (b"[15, 150, 1500, 15000, 0.5, 0.05]", b"[15,200,2e3,2e4,0.5,0.05]"),
        # negative zero normalises to plain zero
        (b"[0.0, -0.0, 1e-9, 5e-10]", b"[0,0,1e-9,5e-10]"),
    ],
)
def test_number_rounds_half_away_from_zero(source, expected):
    """The shared Number helper rounds to N significant digits, half away
    from zero, and rewrites to exponent form when shorter."""
    # CATCHES: banker's rounding (0.15 to 0.2 vs 0.1), leaving 150 as 150
    # instead of 200 at precision 1, or emitting -0 for negative zero.
    res = run_type("json", source, ["--json-precision", "1"])
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


@pytest.mark.parametrize(
    "source,extra_args,expected",
    [
        # --css-precision rounds the mantissa to significant digits
        (b"a{x:1234.5678px}", ("--css-precision", "3"), b"a{x:1230px}"),
        # trailing fractional zeros and the integer dot disappear
        (b"a{x:0.500px}", (), b"a{x:.5px}"),
        (b"a{x:12.0px}", (), b"a{x:12px}"),
        (b"a{x:-0.50px}", (), b"a{x:-.5px}"),
    ],
)
def test_decimal_shortens_css_lengths(source, extra_args, expected):
    """The shared Decimal helper rewrites CSS numbers: leading zero before
    the dot, trailing zeros, and optional precision rounding."""
    # CATCHES: writing 0.5px or -0.5px longhand, or ignoring --css-precision
    # for values inside an SVG <style> element.
    doc = "<svg" + XMLNS + "><style>" + source.decode() + "</style></svg>"
    res = run_type("svg", doc, extra_args)
    assert res.returncode == 0
    prefix = b"<svg" + XMLNS.encode() + b"><style>"
    assert res.stdout == prefix + expected + b"</style></svg>"


@pytest.mark.parametrize(
    "value,expected_attr",
    [
        # the mediatype is lowercased and trimmed
        ("TEXT/CSS", b'contentStyleType="text/css"'),
        (" Text/CSS ", b'contentStyleType="text/css"'),
        # the canonical value counts as the default and is removed
        ("text/css", b""),
    ],
)
def test_mediatype_normalises_content_style_type(value, expected_attr):
    # CATCHES: contentStyleType goes through Mediatype (lowercase + trim)
    # before being compared to the default, so TEXT/CSS is kept as text/css
    # rather than dropped as unknown or kept in its original case.
    doc = "<svg" + XMLNS + ' contentStyleType="' + value + '"><g/></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    base = b"<svg" + XMLNS.encode() + b">"
    if expected_attr:
        base = b"<svg" + XMLNS.encode() + b" " + expected_attr + b">"
    assert res.stdout == base + b"<g/></svg>"


@pytest.mark.parametrize(
    "css,expected",
    [
        # the default charset is dropped from the parameters
        (b"a{b:url(data:text/plain;charset=us-ascii,hello)}", b"a{b:url(data:,hello)}"),
        # quotes around the url are removed and the data URI still minified
        (b'a{b:url("data:text/plain,hello")}', b"a{b:url(data:,hello)}"),
        # heavy percent-encoding switches to base64 when that is shorter
        (
            b"a{b:url(data:image/svg+xml," + b"%3Csvg%3E" * 10 + b")}",
            b"a{b:url(data:image/svg+xml;base64,PHN2Zz48c3ZnPjxzdmc+PHN2Zz48c3ZnPjxzdmc+"
            b"PHN2Zz48c3ZnPjxzdmc+PHN2Zz4=)}",
        ),
        # light percent-encoding is not worth base64 and stays as-is
        (b"a{b:url(data:image/svg+xml,%3Crect/%3E)}", b"a{b:url(data:image/svg+xml,%3Crect/%3E)}"),
    ],
)
def test_data_uri_is_minified_inside_css_urls(css, expected):
    """The shared DataURI helper rewrites url() values: default charsets
    drop, quotes drop, and base64 is chosen only when it wins."""
    # CATCHES: keeping charset=us-ascii, keeping the quotes, base64-encoding
    # a short percent-encoded payload, or percent-decoding the content.
    doc = "<svg" + XMLNS + "><style>" + css.decode() + "</style></svg>"
    res = run_type("svg", doc)
    assert res.returncode == 0
    prefix = b"<svg" + XMLNS.encode() + b"><style>"
    assert res.stdout == prefix + expected + b"</style></svg>"


# ---------------------------------------------------------------------------
# Decimal (common.go) -- only reachable with --css-version 2, which makes the
# CSS minifier shorten numbers without ever introducing exponent notation.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "css,expected_v2,expected_v3",
    [
        (b"a{x:1000px}", b"a{x:1000px}", b"a{x:1e3px}"),
        (b"a{x:1000}", b"a{x:1000}", b"a{x:1e3}"),
    ],
)
def test_decimal_never_uses_exponent_notation(css, expected_v2, expected_v3):
    """Under --css-version 2 CSS numbers keep their plain decimal form even
    when an exponent would be shorter; the default version rewrites them."""
    # CATCHES: routing version-2 dimensions through the Number minifier,
    # which would turn 1000px into 1e3px (invalid as a CSS length anyway).
    res = run_style_css(css, ["--css-version", "2"])
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + expected_v2 + STYLE_CLOSE

    res = run_style_css(css)
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + expected_v3 + STYLE_CLOSE


@pytest.mark.parametrize(
    "css,precision,expected",
    [
        # integer part longer than the precision is never rounded
        (b"a{x:1234.5678px}", "2", b"a{x:1234.5678px}"),
        (b"a{x:123456px}", "1", b"a{x:123456px}"),
        (b"a{x:999.9px}", "1", b"a{x:999.9px}"),
        (b"a{x:-1234.5px}", "1", b"a{x:-1234.5px}"),
        # fraction is rounded to the significant-digit count, half away
        (b"a{x:.012px}", "1", b"a{x:.01px}"),
        (b"a{x:0.000123px}", "2", b"a{x:.00012px}"),
        (b"a{x:0.049px}", "1", b"a{x:.05px}"),
        (b"a{x:1.239px}", "3", b"a{x:1.24px}"),
        (b"a{x:2.005px}", "3", b"a{x:2.01px}"),
        # trailing zeros disappear entirely once precision passes over them
        (b"a{x:1.000px}", "3", b"a{x:1px}"),
        (b"a{x:0.500}", "1", b"a{x:.5}"),
    ],
)
def test_decimal_precision_rounds_only_the_fraction(css, precision, expected):
    """--css-precision under version 2 trims fraction digits down to the
    significant-digit count but never touches the integer part."""
    # CATCHES: rounding 1234.5678px at precision 2 (must stay untouched
    # because only digits after the dot may be removed), or losing the
    # leading-zero skip for values like 0.000123px.
    res = run_style_css(css, ["--css-version", "2", "--css-precision", precision])
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + expected + STYLE_CLOSE


@pytest.mark.parametrize(
    "css,precision,expected",
    [
        # carry at the dot: fraction-only value rolls up to 1
        (b"a{x:.99px}", "1", b"a{x:1px}"),
        # carry through trailing nines appends an integer digit
        (b"a{x:9.99px}", "1", b"a{x:10px}"),
        (b"a{x:9.99px}", "2", b"a{x:10px}"),
        # every significant digit was a nine: the whole value collapses
        (b"a{x:1.999px}", "3", b"a{x:2px}"),
        # carry that leaves a dangling dot behind (recorded reference output)
        (b"a{x:99.99px}", "2", b"a{x:10.px}"),
        (b"a{x:99.99%}", "2", b"a{x:10.%}"),
    ],
)
def test_decimal_rounding_carries_into_the_integer_part(css, precision, expected):
    """Rounding a version-2 CSS number up can carry into the integer part,
    and when the carry eats every fraction digit the dot is left behind."""
    # CATCHES: stopping the carry at the dot (9.99px to 9.99 or .99px
    # instead of 10px), or "fixing" the dangling dot in 10.px / 10.%.
    res = run_style_css(css, ["--css-version", "2", "--css-precision", precision])
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + expected + STYLE_CLOSE


# ---------------------------------------------------------------------------
# Mediatype (common.go) -- reachable through the SVG contentStyleType value.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "value,expected_attr",
    [
        # internal whitespace runs collapse; the minified value no longer
        # equals the default byte-for-byte so the attribute is kept
        ("Text / CSS", b'contentStyleType="text/css"'),
        ("TEXT /\tCSS", b'contentStyleType="text/css"'),
        # whitespace around mediatype separators is dropped as well
        ("text/css ; charset = utf-8", b'contentStyleType="text/css;charset=utf-8"'),
    ],
)
def test_mediatype_removes_whitespace_inside_the_value(value, expected_attr):
    """Mediatype strips whitespace anywhere in the value, not only at the
    ends, so 'Text / CSS' normalises to the canonical text/css spelling."""
    # CATCHES: only trimming the ends and emitting contentStyleType="Text /
    # CSS"-style output, or keeping the spaces around ';' and '='.
    doc = "<svg" + XMLNS + ' contentStyleType="' + value + '"><g/></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == (
        b"<svg" + XMLNS.encode() + b" " + expected_attr + b">" + b"<g/></svg>"
    )


def test_mediatype_quoted_parameters_keep_their_case():
    """Parts of a mediatype inside double quotes are case sensitive; only
    the unquoted parts are lowercased, and the result is re-quoted with the
    cheaper quote character."""
    # CATCHES: lowercasing the quoted parameter (text/c"ss" instead of
    # text/c"sS") or re-quoting the attribute with double quotes.
    doc = '<svg' + XMLNS + ' contentStyleType="TEXT/C&quot;sS&quot;"><g/></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == (
        b"<svg" + XMLNS.encode() + b" contentStyleType='text/c\"sS\"'><g/></svg>"
    )


# ---------------------------------------------------------------------------
# DataURI (common.go) -- edge paths of the size choice and error handling.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "css",
    [
        # invalid base64 payload after ;base64,
        b"a{b:url(data:;base64,!!)}",
        # no comma at all: not a data URI
        b"a{b:url(data:text/plain)}",
        # the data: scheme check is case sensitive
        b"a{b:url(DATA:,hello)}",
    ],
)
def test_data_uri_malformed_payloads_are_returned_verbatim(css):
    """A data URI that cannot be parsed (bad base64, missing comma, wrong
    scheme case) is emitted unchanged instead of raising an error."""
    # CATCHES: failing the whole document, dropping the url() value, or
    # "repairing" DATA:,hello into data:,hello.
    res = run_style_css(css)
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + css + STYLE_CLOSE


def test_data_uri_original_is_kept_when_already_the_smallest():
    """When the original encoding is smaller than both the percent-encoded
    and the base64 re-encoding, the URI is copied through untouched."""
    # CATCHES: percent-encoding the raw quotes (%22x8 would grow the value
    # from 14 to 30 data bytes) or base64-encoding them.
    css = b'a{b:url(\'data:,""""""""\')}'
    res = run_style_css(css)
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + css + STYLE_CLOSE


def test_data_uri_reencodes_raw_reserved_characters():
    """A raw '#' in the data section is re-encoded as %23 even though that
    makes the URI longer: the size choice only compares base64 versus
    percent-encoding, never against the original."""
    # CATCHES: passing the raw '#' through because it already fits, which
    # would produce an invalid URI when re-parsed by a strict consumer.
    res = run_style_css(b"a{b:url(data:,#)}")
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + b"a{b:url(data:,%23)}" + STYLE_CLOSE


@pytest.mark.parametrize(
    "css,expected",
    [
        # the embedded stylesheet is minified before re-encoding
        (b"a{b:url('data:text/css,body { a : b }')}", b"a{b:url(data:text/css,body%7Ba:b%7D)}"),
        # the embedded SVG is minified (empty tag collapses) and '=' stays raw
        (
            b"a{b:url(data:image/svg+xml,%3Csvg%20xmlns%3D%22x%22%3E%3C%2Fsvg%3E)}",
            b"a{b:url(data:image/svg+xml,%3Csvg%20xmlns=%22x%22/%3E)}",
        ),
        # a base64 payload is decoded and re-encoded as plain text when shorter
        (b"a{b:url(data:text/plain;base64,aGVsbG8=)}", b"a{b:url(data:,hello)}"),
    ],
)
def test_data_uri_minifies_the_embedded_document(css, expected):
    """DataURI runs the inner minifier for the payload's mediatype before
    choosing the smaller of percent-encoding or base64."""
    # CATCHES: treating the payload as opaque bytes (no inner CSS/SVG
    # minification), or keeping the base64 form of aGVsbG8=.
    res = run_style_css(css)
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + expected + STYLE_CLOSE


@pytest.mark.parametrize(
    "css,expected",
    [
        # default mediatype/parameter removal is case-insensitive
        (b"a{b:url(data:TEXT/PLAIN;charset=US-ASCII,hello)}", b"a{b:url(data:,hello)}"),
        # binary data: percent-encoding would lose to base64, and the
        # text/plain default is still dropped from the base64 form
        (
            b"a{b:url(data:text/plain;base64,AAAAAAAAAAAAAA==)}",
            b"a{b:url(data:;base64,AAAAAAAAAAAAAA==)}",
        ),
        # spaces inside the data section are percent-encoded, not trimmed
        (b"a{b:url('data:, hello ')}", b"a{b:url(data:,%20hello%20)}"),
    ],
)
def test_data_uri_default_stripping_and_encoding_choice(css, expected):
    """The text/plain and charset=us-ascii defaults are removed
    case-insensitively, and base64 is chosen for zero bytes."""
    # CATCHES: keeping TEXT/PLAIN or US-ASCII because of their case,
    # percent-encoding ten zero bytes (30 chars) instead of base64, or
    # trimming the spaces of the payload like a mediatype parameter.
    res = run_style_css(css)
    assert res.returncode == 0
    assert res.stdout == STYLE_OPEN + expected + STYLE_CLOSE


# ---------------------------------------------------------------------------
# Number (common.go) -- print-form selection and extreme exponents.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "source,expected",
    [
        (b"[1e99999999999999999999999]", b"[1e99999999999999999999999]"),
        (b"[1e9223372036854775807]", b"[1e9223372036854775807]"),
        (b"[1e-9223372036854775808]", b"[1e-9223372036854775808]"),
    ],
)
def test_number_extreme_exponents_stay_verbatim(source, expected):
    """Numbers whose exponent does not fit an int (or overflows the
    rewritten exponent) are copied through byte for byte."""
    # CATCHES: crashing, clamping the exponent, or "normalising"
    # 1e9223372036854775807 into a rounded float-like form.
    res = run_type("json", source)
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


@pytest.mark.parametrize(
    "source,expected",
    [
        # zeros are appended while that is not longer than an exponent
        (b"[1200]", b"[1200]"),
        (b"[120]", b"[120]"),
        (b"[100000e-4]", b"[10]"),
        (b"[12.00e3]", b"[12e3]"),
        # ... and switched to an exponent once it would be
        (b"[1.5e4]", b"[15e3]"),
        (b"[-1.5e4]", b"[-15e3]"),
    ],
)
def test_number_decides_between_zeros_and_exponent_notation(source, expected):
    """A number whose trailing zeros were trimmed gets them re-appended
    while two zeros beat one exponent digit, then flips to exponent form."""
    # CATCHES: rewriting 1200 to 12e2 (same length, not chosen) or 120 to
    # 1.2e2 (longer), or losing the negative sign on -15e3.
    res = run_type("json", source)
    assert res.returncode == 0
    assert res.stdout == expected


@pytest.mark.parametrize(
    "source,expected",
    [
        (b"[1e-1]", b"[0.1]"),
        (b"[1e-2]", b"[0.01]"),
        (b"[0.1e-1]", b"[0.01]"),
        (b"[0.1e-2]", b"[0.001]"),
        (b"[1230e-4]", b"[0.123]"),
        (b"[12.3e-4]", b"[0.00123]"),
        (b"[100.5e-2]", b"[1.005]"),
        (b"[10.01e-2]", b"[0.1001]"),
        (b"[100.1e-4]", b"[0.01001]"),
    ],
)
def test_number_moves_the_decimal_point_for_small_magnitudes(source, expected):
    """Negative exponents that stay near zero are printed by shifting the
    decimal point (padding zeros as needed) instead of using e-notation."""
    # CATCHES: emitting 1e-2 or .01 for 1e-2, forgetting the leading zero
    # JSON requires, or dropping the trailing zero digit of 100.5e-2.
    res = run_type("json", source)
    assert res.returncode == 0
    assert res.stdout == expected


@pytest.mark.parametrize(
    "source,expected",
    [
        # normalised form with a negative exponent
        (b"[0.0000123456789]", b"[0.123456789e-4]"),
        (b"[1.999e-9]", b"[0.1999e-8]"),
        # equally short original spelling is kept as written
        (b"[0.123456e-4]", b"[0.123456e-4]"),
        # integer-plus-negative-exponent form
        (b"[0.0009]", b"[9e-4]"),
        (b"[0.001e-2]", b"[1e-5]"),
        (b"[9.99e-7]", b"[999e-9]"),
        (b"[0.123456789012345e-19]", b"[123456789012345e-34]"),
        # rewriting would not shrink the token: original bytes survive
        (b"[0.0012]", b"[0.0012]"),
        (b"[123456789012345e-19]", b"[123456789012345e-19]"),
    ],
)
def test_number_normalised_and_negative_exponent_forms(source, expected):
    """Very small numbers pick between 0.xxx e-N, xxx e-N and the original
    spelling, whichever is shortest -- including keeping the original."""
    # CATCHES: always using one canonical form (e.g. 9e-4 for 0.0009 but
    # also for 0.0012), or expanding 1.999e-9 to 0.000000001999.
    res = run_type("json", source)
    assert res.returncode == 0
    assert res.stdout == expected


# ---------------------------------------------------------------------------
# UpdateErrorPosition (common.go) -- error positions of an inner minifier.
# ---------------------------------------------------------------------------


def test_style_content_routes_through_the_content_style_type():
    """contentStyleType selects the minifier for <style> contents and for
    style= attributes, so a JSON type minifies them as JSON."""
    # CATCHES: always minifying style contents as CSS (would keep the
    # spaces: { "a" : 1 } instead of {"a":1}).
    doc = '<svg' + XMLNS + ' contentStyleType="application/json"><style>{ "a" : 1 }</style></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == (
        b"<svg" + XMLNS.encode() + b' contentStyleType="application/json"><style>{"a":1}</style></svg>'
    )


@pytest.mark.parametrize(
    "doc",
    [
        '<svg' + XMLNS + ' contentStyleType="application/json" style="[1] x"><g/></svg>',
        '<svg' + XMLNS + ' contentStyleType="application/json"><style>[1] x</style></svg>',
    ],
)
def test_style_minifier_errors_report_the_document_position(doc):
    """When the inner minifier of a style attribute or element fails, the
    error is rewritten with the position inside the whole SVG document
    (here column 88), the snippet shows the style text, the original bytes
    land on stdout and the exit code is 1."""
    # CATCHES: reporting the position inside the isolated style buffer
    # (column 5) instead of the document-relative column 88, or exiting 0.
    res = run_type("svg", doc)
    assert res.returncode == 1
    assert res.stdout == doc.encode("utf-8")
    assert res.stderr == (
        b"ERROR: cannot minify -: expected comma character or an array or "
        b"object ending on line 1 and column 88\n    1: [1] x\n           ^\n"
    )


def test_style_attribute_newline_is_normalised_before_the_inner_error():
    """A literal newline inside the style attribute is normalised to a
    space before the inner minifier sees it, so the error snippet shows
    '[ 1] x' and the caret moves one column to the right."""
    # CATCHES: keeping the raw newline in the snippet (making it two lines)
    # or reporting the caret under the '[' as the un-normalised buffer does.
    doc = '<svg' + XMLNS + ' contentStyleType="application/json" style="[\n1] x"><g/></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 1
    assert res.stdout == doc.encode("utf-8")
    assert res.stderr == (
        b"ERROR: cannot minify -: expected comma character or an array or "
        b"object ending on line 1 and column 89\n    1: [ 1] x\n            ^\n"
    )
