"""Black-box tests for SVG path-data (``d``) minification.

Path data is rewritten by a dedicated state machine: repeated coordinates
become implicit command repeats, same-point commands are dropped, curves
downgrade (C to S, Q to T or to a lineto), commands switch between absolute
and relative form whenever that is shorter, numbers compact (leading zeros,
exponents) and arc flags lose their separators.  Malformed path data is
copied with only the numbers it managed to parse rewritten.
"""

import pytest

from conftest import run_type

PATH_DOC = '<svg xmlns="http://www.w3.org/2000/svg"><path d="{}"/></svg>'


def minify_d(d, extra_args=()):
    """Minify a document whose only content is ``<path d=...>`` and return
    the rewritten ``d`` attribute value."""
    if isinstance(d, bytes):
        d = d.decode()
    res = run_type("svg", PATH_DOC.format(d), extra_args)
    assert res.returncode == 0
    assert res.stderr == b""
    prefix, suffix = b'<svg xmlns="http://www.w3.org/2000/svg"><path d="', b'"/></svg>'
    assert res.stdout.startswith(prefix) and res.stdout.endswith(suffix)
    return res.stdout[len(prefix):len(res.stdout) - len(suffix)]


@pytest.mark.parametrize(
    "source,expected",
    [
        # a second coordinate pair after L is an implicit repeat
        (b"M 10 10 L 20 20", b"M10 10 20 20"),
        (b"M 10 10 L 20 20 30 30", b"M10 10 20 20 30 30"),
        # two explicit L commands merge into one implicit run
        (b"M 10 10 L 20 20 L 30 30", b"M10 10 20 20 30 30"),
        # relative commands repeat implicitly too
        (b"m10 10l5 5", b"m10 10 5 5"),
        # implicit repeats of M are linetos, so the text looks unchanged
        (b"M 0 0 10 10 20 20", b"M0 0 10 10 20 20"),
    ],
)
def test_repeated_coordinates_become_implicit_command_repeats(source, expected):
    """Extra coordinate pairs after a command letter drop the letter."""
    # CATCHES: emitting the command letter for every pair, or treating an
    # implicit repeat of M as another moveto instead of a lineto.
    assert minify_d(source) == expected


@pytest.mark.parametrize(
    "source,expected",
    [
        (b"M 10 10 H 20", b"M10 10H20"),
        (b"M 10 10 V 20", b"M10 10V20"),
    ],
)
def test_single_parameter_commands_keep_their_letter(source, expected):
    """H and V take one coordinate each, so repeats are impossible."""
    # CATCHES: dropping the H/V letter as if it were a multi-parameter
    # command, which would turn the coordinate into a lineto pair.
    assert minify_d(source) == expected


def test_same_point_commands_are_dropped():
    # CATCHES: a command that ends exactly where the previous one did is
    # removed entirely rather than emitted as a zero-length segment.
    assert minify_d(b"M 10 10 L 20 20 L 20 20") == b"M10 10 20 20"


@pytest.mark.parametrize(
    "source,expected",
    [
        # Z is normalised to lowercase z
        (b"M10 10L20 20Z", b"M10 10 20 20z"),
        # after a closepath a new moveto restarts, still with implicit repeats
        (b"M10 10L20 20ZM1 1L2 2", b"M10 10 20 20zM1 1 2 2"),
        (b"M10 10L20 20z m1 1l2 2", b"M10 10 20 20zm1 1 2 2"),
    ],
)
def test_closepath_is_lowercased_and_the_path_restarts(source, expected):
    """z closes the subpath; the next moveto starts a fresh coordinate run."""
    # CATCHES: keeping an uppercase Z, or letting the post-closepath moveto
    # inherit the previous command's implicit-repeat state.
    assert minify_d(source) == expected


@pytest.mark.parametrize(
    "source,expected",
    [
        # a 1px horizontal move is shorter as relative h
        (b"M1000 1000L1001 1000", b"M1e3 1e3h1"),
        # a relative arc whose absolute form is shorter switches and drops
        # the separator between the two flag digits
        (b"m5 5a5 5 0 0 1-10 0", b"m5 5A5 5 0 01-5 5"),
        # an absolute S with small deltas is shorter as relative s
        (b"M8 8S9 9 10 10", b"M8 8s1 1 2 2"),
        # the first T stays absolute, the second becomes a relative repeat
        (b"M8 8T9 9 10 10", b"M8 8T9 9t1 1"),
    ],
)
def test_commands_switch_between_absolute_and_relative_form(source, expected):
    """Each command is emitted in whichever of absolute/relative spelling is
    shorter for its actual coordinates."""
    # CATCHES: always preserving the input's case, or dropping the space
    # between arc flag digits that separated them from the coordinates.
    assert minify_d(source) == expected


@pytest.mark.parametrize(
    "source,expected",
    [
        # commas are just separators, and integers switch to exponent form
        (b"M100,100 L200,200", b"M1e2 1e2 2e2 2e2"),
        (b"M100000 100000", b"M1e5 1e5"),
    ],
)
def test_commas_are_dropped_and_big_integers_use_exponents(source, expected):
    """Comma separators disappear and 100000-sized numbers become 1eN."""
    # CATCHES: keeping commas as separators, or writing six-digit integers
    # out longhand instead of switching to exponent notation.
    assert minify_d(source) == expected


@pytest.mark.parametrize(
    "source,expected",
    [
        # a second C whose first control mirrors the previous end control
        # downgrades to S
        (b"M0 0C10 10 20 20 30 30C40 40 50 50 60 60", b"M0 0C10 10 20 20 30 30S50 50 60 60"),
        # the relative variant: c then s, with sign-carrying separators
        (b"M10 10C5 5 15 15 10 10C5 5 15 15 10 10", b"M10 10c-5-5 5 5 0 0s5 5 0 0"),
        # a C whose first control equals its start point downgrades to S
        (b"M0 0C0 0 10 10 20 20", b"M0 0S10 10 20 20"),
        # a Q whose control equals its start point becomes a plain lineto
        (b"M0 0Q0 0 10 10", b"M0 0 10 10"),
        # a second Q whose control mirrors the previous one downgrades to T
        (b"M0 0Q10 10 20 20Q30 30 40 40", b"M0 0Q10 10 20 20T40 40"),
    ],
)
def test_curves_downgrade_to_their_smooth_forms(source, expected):
    """Redundant control points are dropped by switching to the smooth
    command variants (S, T) or to a lineto."""
    # CATCHES: re-emitting the mirrored control point, or downgrading a
    # curve whose control point is NOT redundant and changing its shape.
    assert minify_d(source) == expected


def test_arc_flags_lose_their_separator():
    # CATCHES: the two single-digit arc flags are written without any
    # separator before the following coordinate, unlike every other number.
    assert minify_d(b"M0 0A5 5 0 0 1 10 10") == b"M0 0A5 5 0 0110 10"


@pytest.mark.parametrize(
    "source,expected",
    [
        # leading zero before the dot is dropped and .05 needs no separator
        (b"M0.5 0.05", b"M.5.05"),
        # a negative number is its own separator, so nothing is added
        (b"M1 2-3-4", b"M1 2-3-4"),
        # exponent letters are normalised to lowercase
        (b"M1e2 1E2", b"M1e2 1e2"),
    ],
)
def test_numbers_compact_and_separator_rules(source, expected):
    """Leading zeros go, minus signs carry the separator duty, and exponent
    letters are lowercased."""
    # CATCHES: writing 0.5 or 0.05, inserting a space before -3, or keeping
    # an uppercase E in the exponent.
    assert minify_d(source) == expected


@pytest.mark.parametrize(
    "source,extra_args,expected",
    [
        # --svg-precision 2 rounds each coordinate half-up
        (b"M1.234 5.678", ("--svg-precision", "2"), b"M1.2 5.7"),
        # with no precision given coordinates round to 15 significant digits
        # and the moveto itself flips to its relative spelling
        (b"M1.23456789012345678 2", (), b"m1.23456789012346 2"),
        # --svg-precision 0 means the same as the default
        (b"M1.23456789012345678 2", ("--svg-precision", "0"), b"m1.23456789012346 2"),
        # a precision above 15 only affects newly-rounded numbers, so .5/.6
        # keep their exact short form and merge into implicit repeats
        (b"M.5.5L.6.6", ("--svg-precision", "20"), b"M.5.5.6.6"),
    ],
)
def test_precision_rounds_path_coordinates(source, extra_args, expected):
    """--svg-precision controls significant digits for path coordinates;
    0 behaves like the default 15-digit rounding, not like rounding to
    integers."""
    # CATCHES: treating precision 0 as integer rounding, or re-rounding
    # already-short numbers at high precision and losing their form.
    assert minify_d(source, extra_args) == expected


def test_unknown_command_makes_the_whole_path_verbatim():
    # CATCHES: a command letter the parser does not recognise aborts path
    # minification and the attribute is copied byte-for-byte.
    assert minify_d(b"M0 0X10 10") == b"M0 0X10 10"


def test_malformed_arc_number_corrupts_the_tail():
    # CATCHES: when an arc parameter fails to parse, the minifier copies the
    # remaining bytes with a length taken from the parsed prefix, so the
    # tail is truncated (the final 0 of 10 is lost) instead of erroring.
    assert minify_d(b"M0 0 A5 5 0 0 x 10 10") == b"M0 0 A5 5 0 0 x 10 1"


def test_path_longer_than_100000_chars_is_skipped_entirely():
    # CATCHES: the path minifier refuses huge attributes as a safeguard, so
    # a >100000-character d attribute comes out byte-identical while the
    # same path just under the limit is fully minified.
    small = "M0 0" + " L1 1" * 14000
    res = run_type("svg", PATH_DOC.format(small))
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><path d="M0 0 1 1"/></svg>'

    huge = "M0 0" + " L1 1" * 21000
    doc = PATH_DOC.format(huge)
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == doc.encode()


def test_d_attribute_is_shortened_on_any_element():
    # CATCHES: path-data minification keys off the d attribute, not the
    # path tag, so a d on a <g> is rewritten exactly the same way.
    doc = '<svg xmlns="http://www.w3.org/2000/svg"><g d="M 10 10 L 20 20"/></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g d="M10 10 20 20"/></svg>'
