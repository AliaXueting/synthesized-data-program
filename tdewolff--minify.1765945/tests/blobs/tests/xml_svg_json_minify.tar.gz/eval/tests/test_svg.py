"""Black-box tests for the SVG minifier (.svg files, image/svg+xml).

The SVG minifier removes the XML prelude, the empty doctype, ``<metadata>``
subtrees and comments; strips default root attributes, ``svg:`` tag prefixes
and foreign namespaces; shortens dimensions, viewBox values, colors and path
data; and minifies ``<style>`` contents and ``style=`` attributes as CSS.
"""

from conftest import run_type

XMLNS = ' xmlns="http://www.w3.org/2000/svg"'


def run_svg(body, extra_args=()):
    """Minify ``<svg`` + ``body`` (a full SVG document tail) as image/svg+xml."""
    if isinstance(body, str):
        return run_type("svg", "<svg" + XMLNS + body, extra_args)
    return run_type("svg", b"<svg" + XMLNS.encode() + body, extra_args)


def test_root_defaults_prelude_doctype_and_metadata_are_removed():
    # CATCHES: the XML declaration, the empty DOCTYPE, version/x/y/
    # preserveAspectRatio/baseProfile/contentScriptType/contentStyleType
    # defaults on the root and the whole <metadata> subtree all disappear,
    # while a DOCTYPE with an internal subset [...] is kept verbatim.
    doc = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" '
        '"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\n'
        '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" x="0" y="0" '
        'preserveAspectRatio="xMidYMid meet" baseProfile="none" '
        'contentScriptType="application/ecmascript" contentStyleType="text/css">'
        "<metadata>xx</metadata><g/></svg>"
    )
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g/></svg>'

    doc = '<!DOCTYPE svg [ <!ENTITY x "y"> ]><svg xmlns="http://www.w3.org/2000/svg"/>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == doc.encode()


def test_comments_are_removed_unless_the_flag_is_set():
    # CATCHES: SVG comments are dropped by default (unlike XML there is a
    # keep flag) and preserved byte-for-byte with --svg-keep-comments.
    res = run_svg("><!-- c --><g/></svg>")
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g/></svg>'

    res = run_svg("><!-- c --><g/></svg>", ["--svg-keep-comments"])
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><!-- c --><g/></svg>'


def test_svg_prefix_is_stripped_from_start_tags_but_not_end_tags():
    # CATCHES: a ``svg:`` prefix is stripped from start tags (and the
    # xmlns:svg declaration is dropped) while the matching end tags keep
    # their prefix; svg:-prefixed attributes are dropped, not unprefixed.
    doc = '<svg:svg xmlns:svg="http://www.w3.org/2000/svg"><svg:g svg:fill="red"><svg:rect/></svg:g></svg:svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == b"<svg><g><rect/></svg:g></svg:svg>"


def test_foreign_namespace_elements_are_dropped_with_their_subtree():
    # CATCHES: an element in an unkept namespace is skipped together with
    # its entire subtree, xlink: attributes survive on normal elements, and
    # the parent <svg> is not collapsed to a void tag afterwards.
    doc = (
        '<svg xmlns="http://www.w3.org/2000/svg" '
        'xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" '
        'xmlns:xlink="http://www.w3.org/1999/xlink">'
        '<inkscape:g inkscape:label="L"><a xlink:href="u"/></inkscape:g></svg>'
    )
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == (
        b'<svg xmlns="http://www.w3.org/2000/svg" '
        b'xmlns:xlink="http://www.w3.org/1999/xlink"></svg>'
    )

    doc = '<svg xmlns="http://www.w3.org/2000/svg"><use xlink:href="#a" href="#b"/></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == doc.encode()

    doc = (
        '<svg xmlns="http://www.w3.org/2000/svg">'
        '<metadata><rdf:RDF xmlns:rdf="x"><x/></rdf:RDF></metadata><g/></svg>'
    )
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g/></svg>'


def test_keep_namespaces_flag_extends_the_keep_list():
    # CATCHES: --svg-keep-namespaces keeps the named namespace's elements,
    # attributes and xmlns declaration; the option may be repeated.
    doc = (
        '<svg xmlns="http://www.w3.org/2000/svg" '
        'xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape">'
        '<inkscape:g inkscape:label="L">t</inkscape:g></svg>'
    )
    res = run_type("svg", doc, ["--svg-keep-namespaces", "inkscape"])
    assert res.returncode == 0
    assert res.stdout == doc.encode()

    doc = (
        '<svg xmlns="http://www.w3.org/2000/svg" xmlns:a="u" xmlns:b="v">'
        '<a:g b:x="1">t</a:g></svg>'
    )
    res = run_type("svg", doc, ["--svg-keep-namespaces", "a", "--svg-keep-namespaces", "b"])
    assert res.returncode == 0
    assert res.stdout == doc.encode()


def test_dimensions_units_and_viewbox_are_shortened():
    # CATCHES: lowercase px is dropped but uppercase PX is only lowercased,
    # other units survive, the version attribute is exempt from dimension
    # shortening, and viewBox commas become spaces (non-numeric stays).
    res = run_svg(' width="100px" height="50.0PX" x="1.50cm"><g/></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg" width="100" height="50px" x="1.5cm"><g/></svg>'

    res = run_svg('><g version="1.50" foo="1.50px" bar="2.0"><g version="1.1"/></g></svg>')
    assert res.returncode == 0
    assert res.stdout == (
        b'<svg xmlns="http://www.w3.org/2000/svg"><g version="1.50" foo="1.5" bar="2">'
        b'<g version="1.1"/></g></svg>'
    )

    res = run_svg(' viewBox="0,0,800.50,600"><g/></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800.5 600"><g/></svg>'

    res = run_svg(' viewBox="a b"><g/></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="a b"><g/></svg>'


def test_svg_precision_rounds_and_clamps_dimensions():
    # CATCHES: --svg-precision rounds dimensions to the given significant
    # digits (0.99999 to 1, 1234.5678 to 1230); values beyond 15 digits are
    # only shortened when the precision is actually that large.
    res = run_svg(' width="1234.5678" x="0.99999"><g/></svg>', ["--svg-precision", "3"])
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg" width="1230" x="1"><g/></svg>'

    res = run_svg(' width="1.23456789012345678"><g/></svg>', ["--svg-precision", "16"])
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg" width="1.234567890123457"><g/></svg>'

    res = run_svg(' width="1.23456789012345678"><g/></svg>', ["--svg-precision", "20"])
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg" width="1.23456789012345678"><g/></svg>'


def test_colors_are_shortened_only_for_known_color_attributes():
    # CATCHES: hex colors compress (#ffffff to #fff) and known names map to
    # their shortest form (#ff0000 to red) case-sensitively, url() values
    # are left alone, and non-color attributes keep their hex value.
    doc = (
        '<svg xmlns="http://www.w3.org/2000/svg"><g fill="#ffffff" stroke="#FF0000" '
        'color="#aabbcc" stop-color="white"><g fill="url(#grad)"/></g></svg>'
    )
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == (
        b'<svg xmlns="http://www.w3.org/2000/svg"><g fill="#fff" stroke="#F00" '
        b'color="#abc" stop-color="#fff"><g fill="url(#grad)"/></g></svg>'
    )

    doc = '<svg xmlns="http://www.w3.org/2000/svg"><g fill="#ff0000" stroke="#0000ff"><g fill="BLACK"/></g></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g fill="red" stroke="#00f"><g fill="BLACK"/></g></svg>'

    doc = '<svg xmlns="http://www.w3.org/2000/svg"><g foo="#ffffff" fill="#ffffff"/></svg>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g foo="#ffffff" fill="#fff"/></svg>'


def test_style_element_and_attribute_are_minified_as_css():
    # CATCHES: <style> contents and style= attributes go through the CSS
    # minifier (comments dropped, colors and dimensions shortened), the
    # type="text/css" attribute is removed, CDATA-wrapped styles are
    # unwrapped, and CSS that minifies to nothing leaves <style></style>
    # uncollapsed because the empty-tag look-ahead ran before minification.
    res = run_svg('><style type="text/css">a { fill: #ffffff } /* c */</style></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><style>a{fill:#fff}</style></svg>'

    res = run_svg('><style><![CDATA[a { fill: #ffffff }]]></style></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><style>a{fill:#fff}</style></svg>'

    res = run_svg('><style type="text/css">a{}</style></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><style></style></svg>'

    res = run_svg('><g style="fill: #ffffff; stroke-width: 10.0px;"></g></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g style="fill:#fff;stroke-width:10px"/></svg>'


def test_foreign_object_content_is_printed_verbatim():
    # CATCHES: everything inside <foreignObject> is echoed byte-for-byte
    # (no whitespace trimming, no attribute rewriting) until the closing
    # </foreignObject>, which is written by the outer loop.
    doc = (
        '<svg xmlns="http://www.w3.org/2000/svg"><foreignObject>'
        '<div xmlns="http://www.w3.org/1999/xhtml"> <p>hi</p> </div>'
        "</foreignObject></svg>"
    )
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == doc.encode()


def test_text_whitespace_entities_and_xml_space():
    # CATCHES: text nodes are collapsed and trimmed, the xml:space="preserve"
    # attribute is removed instead of honored, &amp; stays escaped, and a
    # CDATA section in text becomes escaped text with collapsed whitespace.
    doc = (
        '<svg xmlns="http://www.w3.org/2000/svg"><title> T </title>'
        "<desc>  D  </desc><text> &amp; x </text></svg>"
    )
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == (
        b'<svg xmlns="http://www.w3.org/2000/svg"><title>T</title>'
        b"<desc>D</desc><text>&amp; x</text></svg>"
    )

    res = run_svg('><text xml:space="preserve">a  b</text></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><text>a b</text></svg>'

    res = run_svg("><text><![CDATA[a  <b]]></text></svg>")
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><text>a &lt;b</text></svg>'


def test_root_element_matching_is_case_and_value_sensitive():
    # CATCHES: the root-default removals only apply to a lowercase <svg>
    # with the exact default values: <SVG> and version="1.0" are kept, while
    # x="0.00" and y="-0" are shortened to 0 first and then removed.
    doc = '<SVG version="1.1" x="0"><g/></SVG>'
    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == doc.encode()

    res = run_svg(' version="1.0"><g/></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg" version="1.0"><g/></svg>'

    res = run_svg(' x="0.00" y="-0" width="0px"><g/></svg>')
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg" width="0"><g/></svg>'


def test_unclosed_svg_streams_and_null_byte_is_an_error():
    # CATCHES: a truncated document streams out with exit 0, but a literal
    # NUL aborts with exit 1, the original bytes on stdout and a caret
    # diagnostic on stderr.
    res = run_svg("><g>")
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g>'
    assert res.stderr == b""

    res = run_svg(b"><g>\x00</g></svg>")
    assert res.returncode == 1
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g>\x00</g></svg>'
    assert res.stderr == (
        b"ERROR: cannot minify -: unexpected NULL character on line 1 and column 44\n"
        b'    1: <svg xmlns="http://www.w3.org/2000/svg"><g>\xc2\xb7</g></svg>\n'
        b"                                                  ^\n"
    )


def test_inline_svg_through_the_html_minifier_drops_xmlns():
    # CATCHES: when SVG is minified inline (embedded in HTML) the root xmlns
    # attribute is removed as another default, which never happens for a
    # standalone --type svg document.
    doc = '<svg xmlns="http://www.w3.org/2000/svg" version="1.1"><g/></svg>'
    res = run_type("html", doc)
    assert res.returncode == 0
    assert res.stdout == b"<svg><g/></svg>"

    res = run_type("svg", doc)
    assert res.returncode == 0
    assert res.stdout == b'<svg xmlns="http://www.w3.org/2000/svg"><g/></svg>'


def test_real_world_gopher_sample():
    """A real Adobe Illustrator drawing (prelude, generator comment, doctype,
    default root attributes, tab-indented path data) minifies end to end."""
    # CATCHES: keeping the generator comment or doctype, keeping x="0px" or
    # xml:space, failing to shorten #000000 to #000 or the path data, or
    # mangling the non-ASCII id.  The sample has CRLF line endings.
    source = '''<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="レイヤー_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
	 y="0px" width="401.98px" height="559.472px" viewBox="0 0 401.98 559.472" enable-background="new 0 0 401.98 559.472"
	 xml:space="preserve">
<path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M10.634,300.493c0.764,15.751,16.499,8.463,23.626,3.539c6.765-4.675,8.743-0.789,9.337-10.015
	c0.389-6.064,1.088-12.128,0.744-18.216c-10.23-0.927-21.357,1.509-29.744,7.602C10.277,286.542,2.177,296.561,10.634,300.493"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#C6B198" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M10.634,300.493c2.29-0.852,4.717-1.457,6.271-3.528"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#6AD7E5" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M46.997,112.853C-13.3,95.897,31.536,19.189,79.956,50.74L46.997,112.853z"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#6AD7E5" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M314.895,44.984c47.727-33.523,90.856,42.111,35.388,61.141L314.895,44.984z"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M325.161,494.343c12.123,7.501,34.282,30.182,16.096,41.18c-17.474,15.999-27.254-17.561-42.591-22.211
	C305.271,504.342,313.643,496.163,325.161,494.343z"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="none" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M341.257,535.522c-2.696-5.361-3.601-11.618-8.102-15.939"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M108.579,519.975c-14.229,2.202-22.238,15.039-34.1,21.558c-11.178,6.665-15.454-2.134-16.461-3.92
	c-1.752-0.799-1.605,0.744-4.309-1.979c-10.362-16.354,10.797-28.308,21.815-36.432C90.87,496.1,100.487,509.404,108.579,519.975z"
	/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="none" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M58.019,537.612c0.542-6.233,5.484-10.407,7.838-15.677"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M49.513,91.667c-7.955-4.208-13.791-9.923-8.925-19.124
	c4.505-8.518,12.874-7.593,20.83-3.385L49.513,91.667z"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M337.716,83.667c7.955-4.208,13.791-9.923,8.925-19.124
	c-4.505-8.518-12.874-7.593-20.83-3.385L337.716,83.667z"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M392.475,298.493c-0.764,15.751-16.499,8.463-23.626,3.539c-6.765-4.675-8.743-0.789-9.337-10.015
	c-0.389-6.064-1.088-12.128-0.744-18.216c10.23-0.927,21.357,1.509,29.744,7.602C392.831,284.542,400.932,294.561,392.475,298.493"
	/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#C6B198" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M392.475,298.493c-2.29-0.852-4.717-1.457-6.271-3.528"/>
<g>
	<path fill-rule="evenodd" clip-rule="evenodd" fill="#6AD7E5" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
		M195.512,13.124c60.365,0,116.953,8.633,146.452,66.629c26.478,65.006,17.062,135.104,21.1,203.806
		c3.468,58.992,11.157,127.145-16.21,181.812c-28.79,57.514-100.73,71.982-160,69.863c-46.555-1.666-102.794-16.854-129.069-59.389
		c-30.826-49.9-16.232-124.098-13.993-179.622c2.652-65.771-17.815-131.742,3.792-196.101
		C69.999,33.359,130.451,18.271,195.512,13.124"/>
</g>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" stroke="#000000" stroke-width="2.9081" stroke-linecap="round" d="
	M206.169,94.16c10.838,63.003,113.822,46.345,99.03-17.197C291.935,19.983,202.567,35.755,206.169,94.16"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" stroke="#000000" stroke-width="2.8214" stroke-linecap="round" d="
	M83.103,104.35c14.047,54.85,101.864,40.807,98.554-14.213C177.691,24.242,69.673,36.957,83.103,104.35"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M218.594,169.762c0.046,8.191,1.861,17.387,0.312,26.101c-2.091,3.952-6.193,4.37-9.729,5.967c-4.89-0.767-9.002-3.978-10.963-8.552
	c-1.255-9.946,0.468-19.576,0.785-29.526L218.594,169.762z"/>
<g>
	<ellipse fill-rule="evenodd" clip-rule="evenodd" cx="107.324" cy="95.404" rx="14.829" ry="16.062"/>
	<ellipse fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" cx="114.069" cy="99.029" rx="3.496" ry="4.082"/>
</g>
<g>
	<ellipse fill-rule="evenodd" clip-rule="evenodd" cx="231.571" cy="91.404" rx="14.582" ry="16.062"/>
	<ellipse fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" cx="238.204" cy="95.029" rx="3.438" ry="4.082"/>
</g>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" stroke="#000000" stroke-width="3" stroke-linecap="round" d="
	M176.217,168.87c-6.47,15.68,3.608,47.035,21.163,23.908c-1.255-9.946,0.468-19.576,0.785-29.526L176.217,168.87z"/>
<g>
	<path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#231F20" stroke-width="3" stroke-linecap="round" d="
		M178.431,138.673c-12.059,1.028-21.916,15.366-15.646,26.709c8.303,15.024,26.836-1.329,38.379,0.203
		c13.285,0.272,24.17,14.047,34.84,2.49c11.867-12.854-5.109-25.373-18.377-30.97L178.431,138.673z"/>
	<path fill-rule="evenodd" clip-rule="evenodd" d="M176.913,138.045c-0.893-20.891,38.938-23.503,43.642-6.016
		C225.247,149.475,178.874,153.527,176.913,138.045C175.348,125.682,176.913,138.045,176.913,138.045z"/>
</g>
</svg>
'''.replace("\n", "\r\n")
    res = run_type("svg", source)
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == '''<svg id="レイヤー_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="401.98" height="559.472" viewBox="0 0 401.98 559.472" enable-background="new 0 0 401.98 559.472"><path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#000" stroke-width="3" stroke-linecap="round" d="M10.634 300.493c.764 15.751 16.499 8.463 23.626 3.539 6.765-4.675 8.743-.789 9.337-10.015.389-6.064 1.088-12.128.744-18.216-10.23-.927-21.357 1.509-29.744 7.602C10.277 286.542 2.177 296.561 10.634 300.493"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#C6B198" stroke="#000" stroke-width="3" stroke-linecap="round" d="M10.634 300.493c2.29-.852 4.717-1.457 6.271-3.528"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#6AD7E5" stroke="#000" stroke-width="3" stroke-linecap="round" d="M46.997 112.853C-13.3 95.897 31.536 19.189 79.956 50.74L46.997 112.853z"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#6AD7E5" stroke="#000" stroke-width="3" stroke-linecap="round" d="M314.895 44.984c47.727-33.523 90.856 42.111 35.388 61.141L314.895 44.984z"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#000" stroke-width="3" stroke-linecap="round" d="M325.161 494.343c12.123 7.501 34.282 30.182 16.096 41.18-17.474 15.999-27.254-17.561-42.591-22.211C305.271 504.342 313.643 496.163 325.161 494.343z"/><path fill-rule="evenodd" clip-rule="evenodd" fill="none" stroke="#000" stroke-width="3" stroke-linecap="round" d="M341.257 535.522c-2.696-5.361-3.601-11.618-8.102-15.939"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#000" stroke-width="3" stroke-linecap="round" d="M108.579 519.975c-14.229 2.202-22.238 15.039-34.1 21.558-11.178 6.665-15.454-2.134-16.461-3.92-1.752-.799-1.605.744-4.309-1.979-10.362-16.354 10.797-28.308 21.815-36.432C90.87 496.1 100.487 509.404 108.579 519.975z"/><path fill-rule="evenodd" clip-rule="evenodd" fill="none" stroke="#000" stroke-width="3" stroke-linecap="round" d="M58.019 537.612c.542-6.233 5.484-10.407 7.838-15.677"/><path fill-rule="evenodd" clip-rule="evenodd" d="M49.513 91.667c-7.955-4.208-13.791-9.923-8.925-19.124 4.505-8.518 12.874-7.593 20.83-3.385L49.513 91.667z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M337.716 83.667c7.955-4.208 13.791-9.923 8.925-19.124-4.505-8.518-12.874-7.593-20.83-3.385l11.905 22.509z"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#000" stroke-width="3" stroke-linecap="round" d="M392.475 298.493c-.764 15.751-16.499 8.463-23.626 3.539-6.765-4.675-8.743-.789-9.337-10.015-.389-6.064-1.088-12.128-.744-18.216 10.23-.927 21.357 1.509 29.744 7.602C392.831 284.542 400.932 294.561 392.475 298.493"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#C6B198" stroke="#000" stroke-width="3" stroke-linecap="round" d="M392.475 298.493c-2.29-.852-4.717-1.457-6.271-3.528"/><g><path fill-rule="evenodd" clip-rule="evenodd" fill="#6AD7E5" stroke="#000" stroke-width="3" stroke-linecap="round" d="M195.512 13.124c60.365.0 116.953 8.633 146.452 66.629 26.478 65.006 17.062 135.104 21.1 203.806 3.468 58.992 11.157 127.145-16.21 181.812-28.79 57.514-100.73 71.982-160 69.863-46.555-1.666-102.794-16.854-129.069-59.389-30.826-49.9-16.232-124.098-13.993-179.622 2.652-65.771-17.815-131.742 3.792-196.101C69.999 33.359 130.451 18.271 195.512 13.124"/></g><path fill-rule="evenodd" clip-rule="evenodd" fill="#FFF" stroke="#000" stroke-width="2.9081" stroke-linecap="round" d="M206.169 94.16c10.838 63.003 113.822 46.345 99.03-17.197-13.264-56.98-102.632-41.208-99.03 17.197"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#FFF" stroke="#000" stroke-width="2.8214" stroke-linecap="round" d="M83.103 104.35c14.047 54.85 101.864 40.807 98.554-14.213C177.691 24.242 69.673 36.957 83.103 104.35"/><path fill-rule="evenodd" clip-rule="evenodd" fill="#FFF" stroke="#000" stroke-width="3" stroke-linecap="round" d="M218.594 169.762c.046 8.191 1.861 17.387.312 26.101-2.091 3.952-6.193 4.37-9.729 5.967-4.89-.767-9.002-3.978-10.963-8.552-1.255-9.946.468-19.576.785-29.526L218.594 169.762z"/><g><ellipse fill-rule="evenodd" clip-rule="evenodd" cx="107.324" cy="95.404" rx="14.829" ry="16.062"/><ellipse fill-rule="evenodd" clip-rule="evenodd" fill="#FFF" cx="114.069" cy="99.029" rx="3.496" ry="4.082"/></g><g><ellipse fill-rule="evenodd" clip-rule="evenodd" cx="231.571" cy="91.404" rx="14.582" ry="16.062"/><ellipse fill-rule="evenodd" clip-rule="evenodd" fill="#FFF" cx="238.204" cy="95.029" rx="3.438" ry="4.082"/></g><path fill-rule="evenodd" clip-rule="evenodd" fill="#FFF" stroke="#000" stroke-width="3" stroke-linecap="round" d="M176.217 168.87c-6.47 15.68 3.608 47.035 21.163 23.908-1.255-9.946.468-19.576.785-29.526l-21.948 5.618z"/><g><path fill-rule="evenodd" clip-rule="evenodd" fill="#F6D2A2" stroke="#231F20" stroke-width="3" stroke-linecap="round" d="M178.431 138.673c-12.059 1.028-21.916 15.366-15.646 26.709 8.303 15.024 26.836-1.329 38.379.203 13.285.272 24.17 14.047 34.84 2.49 11.867-12.854-5.109-25.373-18.377-30.97L178.431 138.673z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M176.913 138.045c-.893-20.891 38.938-23.503 43.642-6.016C225.247 149.475 178.874 153.527 176.913 138.045c-1.565-12.363.0.0.0.0z"/></g></svg>'''.encode("utf-8")
