"""Statement-list optimization behaviour, recorded byte-for-byte from the
reference binary via ``--type js`` on stdin.

This module targets the statement-list optimizer in js/stmtlist.go
(``optimizeStmt``/``optimizeStmtList``): if/else rewrites into expressions,
merging an ``if`` that ends in return/throw with a following return/throw,
hoisting the else-branch of a flow-terminated ``if`` into the enclosing scope,
merging a preceding expression or var declaration into for/while/if/switch/
with headers, collapsing nested ``if`` statements, block special cases
(class or unused let/const bodies), and removing superfluous trailing
return/continue statements.

Every expected value below is the exact stdout of the reference binary for
the exact input shown.
"""

import pytest

# (id, input JS, expected output JS)
IF_RETURN_THROW_MERGES = [
    ('ret-merge', 'function f(){if(a)return b;return c}', 'function f(){return a?b:c}'),
    ('ret-merge-bare', 'function f(){if(a)return;return}', 'function f(){a}'),
    ('ret-merge-else', 'function f(){if(a)return b;else return c}', 'function f(){return a?b:c}'),
    ('ret-both-bare', 'function f(){if(a)return;else return}', 'function f(){a}'),
    ('ret-body-only', 'function f(){if(a)return b;else return}', 'function f(){if(a)return b}'),
    ('ret-else-only', 'function f(){if(a)return;else return b}', 'function f(){if(a)return;return b}'),
    ('ret-else-empty-body', 'function f(){if(a);else return b;return c}', 'function f(){return a?c:b}'),
    ('ret-chain', 'function f(){if(a)return b;if(c)return d;return e}', 'function f(){return a?b:c?d:e}'),
    ('ret-chain-three', 'function f(){if(a)return 1;if(b)return 2;if(c)return 3;return 4}', 'function f(){return a?1:b?2:c?3:4}'),
    ('ret-no-merge', 'function f(){if(a)return b;c();return d}', 'function f(){return a?b:(c(),d)}'),
    ('ret-single', 'function f(){if(a)return b}', 'function f(){if(a)return b}'),
    ('ret-then-throw', 'function f(){if(a)return b;throw c}', 'function f(){if(a)return b;throw c}'),
    ('throw-merge', 'function f(){if(a)throw b;throw c}', 'function f(){throw a?b:c}'),
    ('throw-merge-top', 'if(a)throw b;throw c', 'throw a?b:c'),
    ('throw-else-merge', 'if(a)throw b;else throw c;d()', 'throw a?b:c;d()'),
    ('throw-chain', 'function f(){if(a)throw b;if(c)throw d;throw e}', 'function f(){throw a?b:c?d:e}'),
    ('throw-nested-if', 'if(a){if(b)throw c;throw d}', 'if(a)throw b?c:d'),
    ('ret-in-loop', 'function f(){for(;;){if(a)return b;return c}}', 'function f(){for(;;)return a?b:c}'),
    ('nested-fn-merge', 'function f(){function g(){if(a)return b;return c}}', 'function f(){function e(){return a?b:c}}'),
    ('if-empty-body-ret-value', 'function f(){if(a);return c}', 'function f(){return a,c}'),
    ('ret-else-then-ret', 'function f(){if(a)return;else b();return}', 'function f(){if(a)return;b()}'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in IF_RETURN_THROW_MERGES],
    ids=[c[0] for c in IF_RETURN_THROW_MERGES],
)
def test_js_if_return_throw_merges(run_prog, js_in, expected):
    """An if statement whose branches end in return/throw merges with a following return/throw into one conditional statement."""
    # CATCHES: if(a)return b;return c becomes return a?b:c, both-bare returns collapse to the bare condition, a return-body if refuses to merge with a following throw, and nested functions get renamed (g to e).
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
FLOW_HOISTING = [
    ('hoist-else-block', 'function f(){if(a){return b}else{c()};d()}', 'function f(){if(a)return b;c(),d()}'),
    ('hoist-else-stmt', 'function f(){if(a)return b;else c();d()}', 'function f(){if(a)return b;c(),d()}'),
    ('hoist-not-swap', 'function f(){if(!a){b()}else{return c};d()}', 'function f(){if(a)return c;b(),d()}'),
    ('hoist-break', 'while(a){if(b)break;else c();d()}', 'for(;a;){if(b)break;c(),d()}'),
    ('hoist-continue', 'for(;;){if(a)continue;else b();c()}', 'for(;;){if(a)continue;b(),c()}'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in FLOW_HOISTING],
    ids=[c[0] for c in FLOW_HOISTING],
)
def test_js_flow_hoisting(run_prog, js_in, expected):
    """When an if body ends in a flow statement the else body is hoisted into the enclosing scope after the if."""
    # CATCHES: if(a)return b;else c();d() drops the else keyword and inlines c() at the outer level, and a negated condition with a returning else branch is de-negated and swapped first.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
IF_ELSE_REWRITES = [
    ('not-swap', 'if(!a)b();else c()', 'a?c():b()'),
    ('not-swap-throw', 'if(!a)throw b;else throw c', 'throw a?c:b'),
    ('nested-if', 'if(a)if(b)c()', 'a&&b&&c()'),
    ('nested-if-else', 'if(a)if(b)c();else d()', 'a&&(b?c():d())'),
    ('nested-if-outer-else', 'if(a)if(b)c();else d();else e()', 'a?b?c():d():e()'),
    ('truthy-side-effect', 'if(a=1)b();else c()', '(a=1)?b():c()'),
    ('falsy-side-effect-else', 'if(a=0)b();else c()', '(a=0)?b():c()'),
    ('falsy-side-effect-noelse', 'if(a=0)b()', '(a=0)&&b()'),
    ('falsy-no-side-effect', 'if(0)b();c()', 'c()'),
    ('falsy-else-kept', 'if(0);else b();c()', 'b(),c()'),
    ('both-empty-side-effect', 'if(a());b()', 'a(),b()'),
    ('both-empty-no-effect', 'if(a);b()', 'a,b()'),
    ('expr-if', 'a;if(b)c()', 'a,b&&c()'),
    ('expr-if-else', 'a;if(b)c();else d()', 'a,b?c():d()'),
    ('expr-if-not', 'a;if(!b)c()', 'a,b||c()'),
    ('comma-into-if', 'a,b;if(c)d()', 'a,b,c&&d()'),
    ('if-empty-else-ret', 'function f(){if(a)b();else;return 1}', 'function f(){return a&&b(),1}'),
    ('while-then-if', 'a;while(b)if(c)d()', 'for(a;b;)c&&d()'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in IF_ELSE_REWRITES],
    ids=[c[0] for c in IF_ELSE_REWRITES],
)
def test_js_if_else_rewrites(run_prog, js_in, expected):
    """If statements are rewritten: negated conditions with else swap branches, nested ifs merge their conditions, and constant conditions keep only side effects."""
    # CATCHES: if(!a)b();else c() swaps to a?c():b(), if(a)if(b)c() flattens to a&&b&&c(), a bare reference condition counts as a side effect (if(a);b() to a,b()) while if(0)b();c() deletes the dead branch.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
EXPRESSION_MERGES = [
    ('expr-for', 'a;for(;b;);', 'for(a;b;);'),
    ('expr-for-varinit', 'a;for(var b=1;;);', 'a;for(var b=1;;);'),
    ('expr-while', 'a;while(b);', 'for(a;b;);'),
    ('expr-while-body', 'a;while(b)c()', 'for(a;b;)c()'),
    ('expr-switch', 'a;switch(b){}', 'switch(a,b){}'),
    ('expr-switch-case', 'a;switch(b){case 1:c()}', 'switch(a,b){case 1:c()}'),
    ('seq-switch-case', 'a;switch(b){default:c()}', 'switch(a,b){default:c()}'),
    ('expr-with', 'a;with(b)c()', 'with(a,b)c()'),
    ('expr-throw', 'a;throw b', 'throw a,b'),
    ('expr-var', 'a;var b=1', 'a;var b=1'),
    ('expr-bare-var', 'a;var b', 'a;var b'),
    ('expr-do', 'a;do b();while(c)', 'a;do b();while(c)'),
    ('while-cond-merge', 'a+b;while(c)d()', 'for(a+b;c;)d()'),
    ('arrow-body-merge', 'x=()=>{a;if(b)c()}', 'x=()=>{a,b&&c()}'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in EXPRESSION_MERGES],
    ids=[c[0] for c in EXPRESSION_MERGES],
)
def test_js_expression_merges(run_prog, js_in, expected):
    """A preceding expression statement is folded into the header of the next for/while/if/switch/with statement, but never into a var declaration or do-while."""
    # CATCHES: a;while(b); becomes for(a;b;); and a;switch(b){} becomes switch(a,b){}, while a;var b=1 and a;do b();while(c) are left with the expression separate.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
VAR_DECL_MERGES = [
    ('var-assign-merge', 'var a;a=5', 'var a=5'),
    ('var-multi-assign', 'var a,b;a=5,b=6', 'var a=5,b=6'),
    ('var-two-values', 'var a=1;var b=2', 'var a=1,b=2'),
    ('let-two', 'let a=1;let b=2', 'let a=1,b=2'),
    ('const-two', 'const a=1;const b=2', 'const a=1,b=2'),
    ('var-for-init', 'var a;for(;a;);', 'for(var a;a;);'),
    ('var-for-varinit', 'var a;for(var b=1;;);', 'for(var a,b=1;;);'),
    ('var-for-varinit-cond', 'var a;for(var b=1;b<2;);', 'for(var a,b=1;b<2;);'),
    ('var-while', 'var a;while(b);', 'for(var a;b;);'),
    ('var-while-body', 'var a;while(b)c()', 'for(var a;b;)c()'),
    ('var-then-expr-then-var', 'var a;a=1;var b;a=2', 'var b,a=1,a=2'),
    ('var-then-let', 'var a;let b', 'var a;let b'),
    ('let-then-var', 'let a;var b', 'let a;var b'),
    ('const-then-let', 'const a=1;let b', 'const a=1;let b'),
    ('seq-into-vardecl', 'a,b;var c=1', 'a,b;var c=1'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in VAR_DECL_MERGES],
    ids=[c[0] for c in VAR_DECL_MERGES],
)
def test_js_var_decl_merges(run_prog, js_in, expected):
    """Adjacent same-kind declarations merge, assignments are pulled into var declarations, and preceding var declarations are folded into for/while headers."""
    # CATCHES: var a;a=5 becomes var a=5 and var a;while(b); becomes for(var a;b;);, but var and let (or const and let) declarations never merge with each other.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
BLOCK_SPECIAL_CASES = [
    ('block-class', 'if(a){class b{}}', 'a'),
    ('block-class-anchor', 'if(a){class b{}};c()', 'a,c()'),
    ('block-let-two-side-effects', 'if(a){let b=f(),c=g()}', 'a&&(f(),g())'),
    ('block-let-one-side-effect', 'if(a){let b=f()}', 'a&&f()'),
    ('block-let-used', 'if(a){let b=5};b=6', 'a,b=6'),
    ('block-let-in-while', 'while(a){let b=5}', 'for(;a;){let e=5}'),
    ('let-block-alone', 'if(a){let b=5}', 'a'),
    ('block-empty', 'if(a){;};b()', 'a,b()'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in BLOCK_SPECIAL_CASES],
    ids=[c[0] for c in BLOCK_SPECIAL_CASES],
)
def test_js_block_special_cases(run_prog, js_in, expected):
    """A block whose only content is a class declaration vanishes, and unused let/const declarations are dropped while their side-effectful initializers survive."""
    # CATCHES: if(a){class b{}} reduces to the bare condition a, if(a){let b=f(),c=g()} keeps only the initializers as a&&(f(),g()), and the block-scoped let in while(a){let b=5} is renamed (let e=5) because the loop body is a fresh scope.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
SUPERFLUOUS_TAILS = [
    ('ret-comma-void', 'function f(){return a,void 0}', 'function f(){a}'),
    ('ret-comma-void-stmt', 'function f(){a();return void 0}', 'function f(){a()}'),
    ('ret-comma-three', 'function f(){return a,b,void 0}', 'function f(){return a,b}'),
    ('expr-then-ret-bare', 'function f(){a();return}', 'function f(){a()}'),
    ('if-else-then-return', 'function f(){if(a)b();else c();return}', 'function f(){a?b():c()}'),
    ('continue-only', 'while(a){b();continue}', 'for(;a;)b()'),
    ('continue-last', 'while(a){b();if(c)continue}', 'for(;a;)if(b(),c)continue'),
    ('break-last', 'while(a){b();break}', 'for(;a;){b();break}'),
    ('do-continue', 'do{if(a)continue;b()}while(c)', 'do{if(a)continue;b()}while(c)'),
    ('ret-superfluous-tail', 'function f(){if(a)return;b()}', 'function f(){if(a)return;b()}'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in SUPERFLUOUS_TAILS],
    ids=[c[0] for c in SUPERFLUOUS_TAILS],
)
def test_js_superfluous_tails(run_prog, js_in, expected):
    """A trailing return of undefined (including a void 0 sequence tail) is deleted, and a trailing unlabeled continue is deleted in iteration bodies."""
    # CATCHES: return a,void 0 keeps only a as an expression statement, while(a){b();continue} loses the continue entirely, but a break in the same position and a continue guarded inside an if statement are both kept.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""
