"""Mediatype routing behaviour of the core minifier registry, recorded from
the reference binary.

These tests target how ``--type`` values are resolved: literal mediatype
entries, suffix-pattern entries (``[/+]json`` / ``[/+]xml``, the versioned
JavaScript regexp) and mediatype *parameters* (``; charset=utf-8``) that must
be stripped before the lookup.
"""

import pytest

# (id, --type value, stdin, expected stdout)
TYPE_VALUES = [
    ("css-with-params", "text/css; charset=utf-8", "a { color: red; }\n", "a{color:red}"),
    ("css-params-no-space", "text/css;charset=utf-8", "a { color: red; }\n", "a{color:red}"),
    ("css-params-spaced-quoted", 'text/css; charset = "utf-8"', "a { color: red; }\n",
     "a{color:red}"),
    ("css-trailing-semicolon", "text/css;", "a{color:red}", "a{color:red}"),
    ("js-jscript", "text/jscript", "var a = 1\n", "var a=1"),
    ("js-versioned", "application/javascript1.5", "var a = 1\n", "var a=1"),
    ("json-ld-suffix", "application/ld+json", '{"a": 1}\n', '{"a":1}'),
    ("json-ld-suffix-with-params", "application/ld+json; charset=utf-8", '{"a": 1}\n', '{"a":1}'),
    ("json-text-suffix", "text/json", '{"a": 1}\n', '{"a":1}'),
    ("xml-atom-suffix", "application/atom+xml", "<feed >x</feed>\n", "<feed>x</feed>"),
    ("xml-unknown-suffix", "text/nosuch+xml", "<a >x</a>\n", "<a>x</a>"),
    ("xml-unknown-suffix-with-params", "text/nosuch+xml; charset=utf-8", "<a >x</a>\n",
     "<a>x</a>"),
]


UNMATCHED_TYPES = [
    ("js-x-versioned", "application/x-javascript1.6", "var a = 1\n"),
    ("css-uppercase", "text/CSS", "a{color:red}\n"),
]


@pytest.mark.parametrize(
    "type_value,stdin_data", [(t, s) for _i, t, s in UNMATCHED_TYPES],
    ids=[i for i, _t, _s in UNMATCHED_TYPES],
)
def test_unmatched_mimetype(run_prog, type_value, stdin_data):
    """A --type no literal or pattern matches fails with the input echoed."""
    # CATCHES: the literal lookup and the versioned-JavaScript pattern are
    # both case-sensitive and shape-sensitive: `text/CSS` finds nothing even
    # though text/css exists, and `application/x-javascript1.6` finds nothing
    # even though both application/javascript1.5 and application/x-javascript
    # work, so the run exits 1 echoing the input on stdout with the exact
    # does-not-exist error on stderr.
    res = run_prog(["--type", type_value], stdin=stdin_data)
    assert res.rc == 1
    assert res.out == stdin_data
    assert res.err == "ERROR: cannot minify -: minifier does not exist for mimetype\n"


@pytest.mark.parametrize(
    "type_value,stdin_data,expected", [(t, s, e) for _i, t, s, e in TYPE_VALUES],
    ids=[i for i, _t, _s, _e in TYPE_VALUES],
)
def test_mediatype_routing(run_prog, type_value, stdin_data, expected):
    """Suffix patterns and parameter-stripped mediatypes all find a minifier."""
    # CATCHES: `text/nosuch+xml` still routes to the XML minifier via the
    # [/+]xml$ suffix pattern, `application/javascript1.5` matches the
    # versioned-JS regexp, and `; charset=utf-8` parameters are stripped
    # before the lookup so the literal text/css entry is still found.
    res = run_prog(["--type", type_value], stdin=stdin_data)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_mediatype_params_reach_real_minifier(run_prog):
    """A parameter-suffixed pattern mediatype reports that minifier's errors."""
    # CATCHES: stripping `; charset=utf-8` from application/ld+json really
    # selects the JSON minifier, proven by its own parse error naming the
    # offending '<' with line/column and a caret line, while the original
    # bytes are echoed to stdout and the run exits 1.
    res = run_prog(["--type", "application/ld+json; charset=utf-8"], stdin="<a >x</a>\n")
    assert res.rc == 1
    assert res.out == "<a >x</a>\n"
    assert res.err == (
        "ERROR: cannot minify -: unexpected character '<' on line 1 and column 1\n"
        "    1: <a >x</a>\n"
        "       ^\n"
    )


def test_type_module_is_not_a_filetype(run_prog):
    """The bare word `module` is rejected even though a pattern matches it."""
    # CATCHES: --type resolution happens against the filetype/extension
    # table before any regexp pattern minifier is consulted, so `module`
    # (which the JS pattern would accept) fails with the unknown-filetype
    # error that prints an emptied value.
    res = run_prog(["--type", "module"], stdin="var a=1")
    assert res.rc == 1
    assert res.out == ""
    assert res.err == "ERROR: unknown filetype \n"


# (id, --type value, stdin) for mimetypes that no literal and no pattern
# matches: wildcard shapes, uppercase spellings, an out-of-range JS version.
UNMATCHED_SHAPES = [
    ("star-subtype", "text/*", "a{color:red}\n"),
    ("star-both", "*/*", "a{color:red}\n"),
    ("upper-suffix-pattern", "APPLICATION/LD+JSON", '{"a": 1}\n'),
    ("upper-literal-js", "APPLICATION/JAVASCRIPT", "var a = 1\n"),
    ("jscript-version-1-6", "text/jscript1.6", "var a = 1\n"),
]


@pytest.mark.parametrize(
    "type_value,stdin_data", [(t, s) for _i, t, s in UNMATCHED_SHAPES],
    ids=[i for i, _t, _s in UNMATCHED_SHAPES],
)
def test_wildcard_and_uppercase_unmatched(run_prog, type_value, stdin_data):
    """Wildcards are not expanded and lookups are case-sensitive."""
    # CATCHES: the registry does no wildcard expansion at all -- `text/*`
    # and `*/*` match neither a literal nor a suffix pattern -- and both
    # the literal table and the patterns are case-sensitive, while the
    # versioned-JS pattern only accepts versions 1.0 through 1.5, so
    # text/jscript1.6 fails just like the uppercase spellings.
    res = run_prog(["--type", type_value], stdin=stdin_data)
    assert res.rc == 1
    assert res.out == stdin_data
    assert res.err == "ERROR: cannot minify -: minifier does not exist for mimetype\n"


# (id, --type value, stdin, expected stdout) for mediatypes whose *`*`* is a
# literal character that still happens to end in a pattern suffix.
STAR_SUFFIX_TYPES = [
    ("star-then-json-suffix", "application/*+json", '{"a": 1}\n', '{"a":1}'),
    ("star-then-xml-suffix", "text/*+xml", "<a >x</a>\n", "<a>x</a>"),
    ("star-in-subtype-json", "x/*+json", '{"a": 1}\n', '{"a":1}'),
    ("foo-plus-json", "application/foo+json", '{"a": 1}\n', '{"a":1}'),
]


@pytest.mark.parametrize(
    "type_value,stdin_data,expected", [(t, s, e) for _i, t, s, e in STAR_SUFFIX_TYPES],
    ids=[i for i, _t, _s, _e in STAR_SUFFIX_TYPES],
)
def test_suffix_pattern_matches_star_literals(run_prog, type_value, stdin_data, expected):
    """A `*` in the mediatype is literal, so `+json` after it still matches."""
    # CATCHES: `application/*+json` is not treated as a wildcard: the star
    # is just a character, the mediatype ends in `+json`, and the
    # [/+]json$ suffix pattern routes it to the JSON minifier.
    res = run_prog(["--type", type_value], stdin=stdin_data)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, --type value) for versioned-JS pattern spellings inside the 1.0-1.5
# window and the x-/live- alternatives of the JS regexp.
VERSIONED_JS_TYPES = [
    ("jscript-1-3", "text/jscript1.3"),
    ("livescript-1-5", "application/livescript1.5"),
    ("x-ecmascript", "text/x-ecmascript"),
    ("jscript-with-params", "text/jscript;charset=x"),
]


@pytest.mark.parametrize("type_value", [t for _i, t in VERSIONED_JS_TYPES],
                         ids=[i for i, _t in VERSIONED_JS_TYPES])
def test_versioned_js_pattern_forms(run_prog, type_value):
    """The versioned-JavaScript regexp accepts its 1.x and alias spellings."""
    # CATCHES: text/jscript1.3 and application/livescript1.5 match the
    # versioned-JS pattern (only 1.0-1.5 would), text/x-ecmascript matches
    # the x- alternative, and a parameter after the mimetype is stripped
    # before the pattern is consulted.
    res = run_prog(["--type", type_value], stdin="var a = 1\n")
    assert res.rc == 0
    assert res.out == "var a=1"
    assert res.err == ""


# (id, --type value) for parameter spellings that must all be stripped away
# before the literal text/css lookup succeeds.
PARAM_FORMS = [
    ("multiple-params", "text/css; charset=utf-8; version=2"),
    ("space-before-semicolon", "text/css ; charset=utf-8"),
    ("quoted-value-with-semicolon", 'text/css; charset="a;b"'),
    ("param-without-value", "text/css; foo"),
    ("empty-param", "text/css;;"),
    ("trailing-space-in-type", "text/css "),
    ("leading-space-in-type", " text/css"),
    ("spaced-unquoted-value", "text/css; charset = utf-8"),
    ("uppercase-param-value", "text/css; charset=UTF-8"),
]


@pytest.mark.parametrize("type_value", [t for _i, t in PARAM_FORMS],
                         ids=[i for i, _t in PARAM_FORMS])
def test_mediatype_param_forms(run_prog, type_value):
    """Odd parameter spellings are all stripped before the literal lookup."""
    # CATCHES: several parameters, a space before the semicolon, a quoted
    # value containing a semicolon, a parameter without a value, an empty
    # parameter, surrounding whitespace, and spaces around `=` inside the
    # parameter all leave the base mimetype text/css intact.
    res = run_prog(["--type", type_value], stdin="a { color: red; }\n")
    assert res.rc == 0
    assert res.out == "a{color:red}"
    assert res.err == ""


# (id, --ext flag value, input filename, file content, expected stdout)
EXT_LITERALS = [
    ("importmap", "importmap", "x.foo", '{"a": 1}\n', '{"a":1}'),
    ("speculationrules", "speculationrules", "x.foo", '{"a": 1}\n', '{"a":1}'),
    ("module-pattern", "module", "x.foo", "var a = 1\n", "var a=1"),
    ("direct-mimetype", "text/css", "x.foo", "a { color: red; }\n", "a{color:red}"),
]


@pytest.mark.parametrize(
    "ext_value,filename,content,expected",
    [(v, f, c, e) for _i, v, f, c, e in EXT_LITERALS],
    ids=[i for i, _v, _f, _c, _e in EXT_LITERALS],
)
def test_ext_value_routes_registry_entries(run_prog, ext_value, filename, content, expected):
    """--ext values that are not filetypes become the file's mimetype."""
    # CATCHES: the importmap and speculationrules registry literals and the
    # `^module$` alternative of the JS pattern are unreachable through
    # --type (filetype resolution rejects them) but an --ext value that is
    # not a filetype is used as the mimetype as-is, so these hidden
    # registry entries still minify the file.
    res = run_prog(
        ["--ext.foo=" + ext_value, filename], files={filename: content}
    )
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_ext_map_form_routes_registry_entry(run_prog):
    """The `--ext {imap:importmap}` map form reaches the same literal."""
    # CATCHES: the map syntax of --ext feeds the same extension table as
    # the dotted form, so the importmap literal minifies JSON content.
    res = run_prog(
        ["--ext", "{imap:importmap}", "x.imap"], files={"x.imap": '{"a": 1}\n'}
    )
    assert res.rc == 0
    assert res.out == '{"a":1}'
    assert res.err == ""


# (id, --ext flag value) for extension-mapped mimetypes no minifier matches.
EXT_UNMATCHED = [
    ("plain-text-literal", "text/plain"),
    ("wildcard-value", "text/*"),
]


@pytest.mark.parametrize("ext_value", [v for _i, v in EXT_UNMATCHED],
                         ids=[i for i, _v in EXT_UNMATCHED])
def test_ext_unmatched_mimetype_fails(run_prog, ext_value):
    """An --ext mimetype with no minifier fails the run, echoing the file."""
    # CATCHES: the error names the input file (not `-`) and the original
    # bytes are still written to stdout while the exit code is 1, exactly
    # like the stdin path of the unmatched-mimetype error.
    res = run_prog(
        ["--ext.foo=" + ext_value, "x.foo"], files={"x.foo": "a { color: red; }\n"}
    )
    assert res.rc == 1
    assert res.out == "a { color: red; }\n"
    assert res.err == "ERROR: cannot minify x.foo: minifier does not exist for mimetype\n"


# (id, --type value) whose mediatype only differs from `text/css` by
# whitespace or extra semicolons around it.
MEDIATYPE_WHITESPACE = [
    ("leading-space", " text/css"),
    ("trailing-space", "text/css "),
    ("double-semicolon", "text/css;;"),
]


@pytest.mark.parametrize("type_value", [v for _i, v in MEDIATYPE_WHITESPACE],
                         ids=[i for i, _v in MEDIATYPE_WHITESPACE])
def test_mediatype_whitespace_tolerated(run_prog, type_value):
    """A space before or after the mimetype, or an extra semicolon, still routes to the CSS minifier."""
    # CATCHES: the mediatype parser trims surrounding spaces and tolerates
    # a stray trailing semicolon, so ` text/css`, `text/css ` and
    # `text/css;;` all minify the CSS instead of failing lookup.
    res = run_prog(["--type", type_value], stdin="a { color: red; }")
    assert res.rc == 0
    assert res.out == "a{color:red}"
    assert res.err == ""


# (id, --type value, expected stdout, expected stderr) for type values whose
# mimetype cannot be resolved or matched at all.
MEDIATYPE_UNRESOLVED = [
    ("params-only", ";charset=utf-8", "", "ERROR: unknown filetype \n"),
    ("only-space", " ", "", "ERROR: unknown filetype \n"),
    ("inner-space", "text / css", "a {color: red}", "ERROR: cannot minify -: minifier does not exist for mimetype\n"),
    ("tab-prefix", "\ttext/css", "a {color: red}", "ERROR: cannot minify -: minifier does not exist for mimetype\n"),
]


@pytest.mark.parametrize("type_value,expected_out,expected_err",
                         [(v, o, e) for _i, v, o, e in MEDIATYPE_UNRESOLVED],
                         ids=[i for i, _v, _o, _e in MEDIATYPE_UNRESOLVED])
def test_mediatype_unresolvable_forms(run_prog, type_value, expected_out, expected_err):
    """A type value that is only parameters resolves to the empty filetype, and inner spaces or a tab prefix break mimetype matching."""
    # CATCHES: `;charset=utf-8` and a lone space die at filetype resolution
    # with `unknown filetype ` (note the trailing space before the newline)
    # and an EMPTY stdout, while `text / css` and `\ttext/css` resolve but
    # match no minifier and echo the input on stdout — the parser trims
    # spaces but not tabs, and an inner space splits the mimetype.
    res = run_prog(["--type", type_value], stdin="a {color: red}")
    assert res.rc == 1
    assert res.out == expected_out
    assert res.err == expected_err
