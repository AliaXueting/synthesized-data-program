"""SVG path-data shortening behaviour, recorded byte-for-byte from the
reference binary via ``--type svg`` on stdin.

This module targets svg/pathdata.go (``ShortenPathData`` and friends):
implicit command repetition, absolute/relative instruction choice (the
shorter spelling wins), L to H/V narrowing, same-point line elision, C to S
and Q to T control-point reflection, curves collapsing to lines when control
points overlap endpoints, arc flag packing, the ``z`` reset, number
reformatting (trailing-zero exponents, ``.5`` forms, the aggressive dot
separator ``1e-6.0``), tolerance of malformed or odd-length data, and the
100000-byte guard that leaves long paths untouched.

Every expected value below is the exact stdout of the reference binary for
the exact input shown; the input document is always
``<svg><path d="..."/></svg>`` and the whole minified document is asserted.
"""

import pytest

SVG_WRAP = '<svg><path d="%s"/></svg>'


def _cases(table):
    return [(SVG_WRAP % d, SVG_WRAP % e) for _id, d, e in table]


# (id, input path data, expected path data)
COMMAND_ELISION = [
    ('l-repeat', 'M 10 10 L 20 20 L 30 30', 'M10 10 20 20 30 30'),
    ('m-multi-pair', 'M 1 2 3 4 5 6', 'M1 2 3 4 5 6'),
    ('m-l-alias', 'M10 10 L20 20', 'M10 10 20 20'),
    ('h-two', 'M0 0H10 20', 'M0 0H10 20'),
    ('v-two', 'M0 0V10 20', 'M0 0V10 20'),
    ('multi-m', 'M10 10 M20 20', 'M10 10M20 20'),
    ('m-multi-rel', 'm1 2 3 4', 'm1 2 3 4'),
    ('vv-then-hh', 'M0 0V10V20H30H40', 'M0 0V10 20H30 40'),
    ('l-alone', 'M10 10L', 'M10 10'),
    ('comma-sep', 'M 0,0 L 10,10', 'M0 0 10 10'),
    ('newline-sep', 'M0 0\nL10 10', 'M0 0 10 10'),
    ('tab-sep', 'M0 0\tL10 10', 'M0 0 10 10'),
]


@pytest.mark.parametrize(
    "svg_in,expected", _cases(COMMAND_ELISION),
    ids=[c[0] for c in COMMAND_ELISION],
)
def test_svg_command_elision(run_prog, svg_in, expected):
    """A repeated command letter is dropped and its separators collapse; M always reprints but a following L is implicit."""
    # CATCHES: M 10 10 L 20 20 L 30 30 becomes M10 10 20 20 30 30 (both L letters vanish) while a second M is always reprinted, and a trailing bare L after M10 10 is swallowed entirely.
    res = run_prog(["--type", "svg"], stdin=svg_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input path data, expected path data)
LINE_SIMPLIFICATION = [
    ('l-to-h', 'M10 10 L20 10', 'M10 10H20'),
    ('l-to-v', 'M10 10 L10 20', 'M10 10V20'),
    ('l-same-point', 'M10 10 L10 10', 'M10 10'),
    ('l-same-point-then', 'M10 10 L10 10 L20 20', 'M10 10 20 20'),
    ('l-rel-zero', 'M10 10l0 0', 'M10 10'),
    ('implicit-l-same', 'M9 9 9 9', 'M9 9'),
    ('implicit-l-same-10', 'M10 10 10 10', 'M10 10'),
    ('h-same-point-kept', 'M10 10h0', 'M10 10h0'),
    ('H-same-to-h0', 'M10 10H10', 'M10 10h0'),
    ('v-same-point-kept', 'M10 10v0', 'M10 10v0'),
    ('h-neg', 'M10 10H-5', 'M10 10H-5'),
    ('v-after-h', 'M0 0H10V10', 'M0 0H10V10'),
    ('abs-rel-choice', 'M10 10 L20 20 l5 5', 'M10 10 20 20l5 5'),
    ('abs-rel-choice2', 'm10 10 l5 5', 'm10 10 5 5'),
    ('abs-rel-choice3', 'M100 100 L110 110 l1 1', 'M1e2 1e2l10 10 1 1'),
]


@pytest.mark.parametrize(
    "svg_in,expected", _cases(LINE_SIMPLIFICATION),
    ids=[c[0] for c in LINE_SIMPLIFICATION],
)
def test_svg_line_simplification(run_prog, svg_in, expected):
    """Lines narrow to H/V when one coordinate is unchanged, lines to the current point vanish, and relative/absolute spellings compete with the shorter one winning."""
    # CATCHES: M10 10 L20 10 becomes M10 10H20 while L to the same point disappears entirely, yet H10 back to the same x becomes the two-character h0 (H is never dropped), and L110 110 after M100 100 picks the relative l10 10 spelling.
    res = run_prog(["--type", "svg"], stdin=svg_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input path data, expected path data)
CURVE_SIMPLIFICATION = [
    ('c-to-s', 'M0 0 C0 0 10 10 20 20 C20 20 30 30 40 40', 'M0 0S10 10 20 20c0 0 10 10 20 20'),
    ('c-to-s-rel', 'm0 0 c0 0 10 10 20 20 c0 0 10 10 20 20', 'm0 0s10 10 20 20c0 0 10 10 20 20'),
    ('c-not-s', 'M0 0 C0 0 10 10 20 20 C50 50 30 30 40 40', 'M0 0S10 10 20 20C50 50 30 30 40 40'),
    ('s-kept', 'M0 0 S10 10 20 20', 'M0 0S10 10 20 20'),
    ('s-after-line', 'M0 0 L10 10 S20 20 30 30', 'M0 0 10 10S20 20 30 30'),
    ('c-to-line', 'M0 0 C0 0 20 20 20 20', 'M0 0 20 20'),
    ('c-to-line-rel', 'M0 0 c0 0 20 20 20 20', 'M0 0l20 20'),
    ('c-mid-line', 'M0 0 C0 0 10 10 20 20', 'M0 0S10 10 20 20'),
    ('c-three-groups', 'M0 0C0 0 1 1 2 2 0 0 1 1 2 2 0 0 1 1 2 2', 'M0 0S1 1 2 2C0 0 1 1 2 2 0 0 1 1 2 2'),
    ('mixed-cs', 'M0 0c1 1 2 2 3 3s1 1 2 2', 'M0 0c1 1 2 2 3 3s1 1 2 2'),
    ('q-to-t', 'M0 0 Q10 10 20 20 Q30 30 40 40', 'M0 0Q10 10 20 20T40 40'),
    ('q-to-t-rel', 'm0 0 q10 10 20 20 q10 10 20 20', 'm0 0q10 10 20 20t20 20'),
    ('q-not-t', 'M0 0 Q10 10 20 20 Q70 70 40 40', 'M0 0Q10 10 20 20 70 70 40 40'),
    ('t-kept', 'M0 0 T20 20', 'M0 0 20 20'),
    ('q-then-t', 'M0 0 Q5 5 10 10 T20 20', 'M0 0Q5 5 10 10T20 20'),
    ('t-after-line', 'M0 0 L10 10 T20 20', 'M0 0 10 10 20 20'),
    ('q-to-line', 'M0 0 Q0 0 20 20', 'M0 0 20 20'),
    ('q-mid-line', 'M0 0 Q10 10 20 20', 'M0 0Q10 10 20 20'),
]


@pytest.mark.parametrize(
    "svg_in,expected", _cases(CURVE_SIMPLIFICATION),
    ids=[c[0] for c in CURVE_SIMPLIFICATION],
)
def test_svg_curve_simplification(run_prog, svg_in, expected):
    """C becomes S and Q becomes T when the first control point is the reflection of the previous one, and a curve whose control points overlap both endpoints becomes a line."""
    # CATCHES: a second C whose first control point mirrors the previous one is rewritten to S (or c to s) with two coordinates dropped, C0 0 20 20 20 20 collapses to the implicit line M0 0 20 20, and a T following a line (no remembered control point) also becomes a line.
    res = run_prog(["--type", "svg"], stdin=svg_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input path data, expected path data)
ARC_COMMANDS = [
    ('arc-basic', 'M0 0 A5 5 0 0 1 10 10', 'M0 0A5 5 0 0110 10'),
    ('arc-rel', 'M0 0a5 5 0 0 1 10 10', 'M0 0a5 5 0 0110 10'),
    ('arc-flags-tight', 'M0 0A5 5 0 0110 10', 'M0 0A5 5 0 0110 10'),
    ('arc-two', 'M0 0 A5 5 0 0 1 10 10 A5 5 0 0 0 20 20', 'M0 0A5 5 0 0110 10 5 5 0 0020 20'),
    ('arc-three', 'M0 0A5 5 0 0110 10 5 5 0 0020 20 5 5 0 0130 30', 'M0 0A5 5 0 0110 10 5 5 0 0020 20 5 5 0 0130 30'),
    ('arc-neg-after-flag', 'M0 0 A5 5 0 0 1 -10 -10', 'M0 0A5 5 0 01-10-10'),
    ('arc-zero-r', 'M0 0 A0 0 0 0 1 10 10', 'M0 0A0 0 0 0110 10'),
    ('arc-large-flag', 'M0 0 A25 25 30 1 1 10 10', 'M0 0A25 25 30 1110 10'),
    ('arc-bad-flag', 'M0 0 A5 5 0 0.5 1 10 10', 'M0 0 A5 5 0 0.5 1 10 1'),
    ('a-odd', 'M0 0 A5 5 0 0 1 10', 'M0 0A5 5 0 0 1 10'),
]


@pytest.mark.parametrize(
    "svg_in,expected", _cases(ARC_COMMANDS),
    ids=[c[0] for c in ARC_COMMANDS],
)
def test_svg_arc_commands(run_prog, svg_in, expected):
    """Arc boolean flags are packed without separators against neighbouring digits, and a malformed flag corrupts the tail of the path."""
    # CATCHES: A5 5 0 0 1 10 10 becomes A5 5 0 0110 10 (flags glued to the following number) and repeated arcs drop the letter, while a 0.5 flag makes the minifier give up and truncate exactly one trailing byte (10 10 becomes 10 1).
    res = run_prog(["--type", "svg"], stdin=svg_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input path data, expected path data)
NUMBER_FORMATTING = [
    ('trailing-zeros', 'M0 0 L10.0 20.50', 'M0 0 10 20.5'),
    ('e2-hundred', 'M100 100 L200 200', 'M1e2 1e2 2e2 2e2'),
    ('e2-thousand', 'M1000 1000', 'M1e3 1e3'),
    ('million', 'M1000000 1', 'M1e6 1'),
    ('leading-zero-frac', 'M0 0 L0.5 0.5', 'M0 0 .5.5'),
    ('frac-then-frac', 'M0.5 0.5 L0.5 0.5', 'M.5.5'),
    ('neg-nums', 'M-1 -1 L-2 -2', 'M-1-1-2-2'),
    ('neg-after-pos', 'M1 1L2 -2', 'M1 1 2-2'),
    ('plus-sign', 'M+1 +1', 'M1 1'),
    ('neg-zero', 'M-0.5 -0.5', 'M-.5-.5'),
    ('dot-then-dot', 'M.1.2', 'M.1.2'),
    ('dot-start', 'M.5 .5', 'M.5.5'),
    ('e2-then-frac', 'M100 0.5', 'M1e2.5'),
    ('frac-e2-mix', 'M0.5 100', 'M.5 1e2'),
    ('point-nine', 'M0.9 0.9', 'M.9.9'),
    ('caps-in-nums', 'M1E2 1e2', 'M1e2 1e2'),
    ('exp-num', 'M1e2 1E2', 'M1e2 1e2'),
    ('space-forms', 'M0 0L1.5.5', 'M0 0 1.5.5'),
    ('tiny', 'M0.000001 0', 'M1e-6.0'),
    ('big', 'M1234567 1', 'M1234567 1'),
    ('space-e-kept', 'M1 e2', 'M1 e2'),
]


@pytest.mark.parametrize(
    "svg_in,expected", _cases(NUMBER_FORMATTING),
    ids=[c[0] for c in NUMBER_FORMATTING],
)
def test_svg_number_formatting(run_prog, svg_in, expected):
    """Coordinates are re-spelled minimally: trailing zeros become exponents, leading zeros before the dot vanish, and a digit after a non-integer separates with a dot instead of a space."""
    # CATCHES: 100 becomes 1e2 and 1000000 becomes 1e6, 0.5 becomes .5 so L0.5 0.5 after M0 0 prints as .5.5, and M0.000001 0 uses the aggressive dot separator yielding 1e-6.0 (dot instead of space before the final 0).
    res = run_prog(["--type", "svg"], stdin=svg_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input path data, expected path data)
PATH_TOLERANCE = [
    ('bad-cmd', 'M10 10 X 20 20', 'M10 10 X 20 20'),
    ('odd-l', 'M10 10 L20 20 L30', 'M10 10 L20 20 L30'),
    ('q-odd', 'M0 0 Q10 10', 'M0 0Q10 10'),
    ('c-odd', 'M0 0 C0 0 10 10', 'M0 0C0 0 10 10'),
    ('s-odd', 'M0 0 S10 10 20 20 30', 'M0 0S10 10 20 20 30'),
    ('t-odd', 'M0 0 T20 20 30', 'M0 0T20 20 30'),
    ('z-lower', 'M10 10 H20 V20 Z', 'M10 10H20V20z'),
    ('z-upper', 'M10 10Z', 'M10 10z'),
    ('z-reset-pos', 'M10 10 H20 V20 Z L10 10', 'M10 10H20V20z'),
    ('z-then-new', 'M5 5 H10 Z M5 5', 'M5 5h5zM5 5'),
    ('z-mid', 'M0 0ZL10 10', 'M0 0zL10 10'),
    ('z-then-h', 'M0 0 H10 Z H10', 'M0 0H10zH10'),
    ('just-z', 'Z', 'z'),
]


@pytest.mark.parametrize(
    "svg_in,expected", _cases(PATH_TOLERANCE),
    ids=[c[0] for c in PATH_TOLERANCE],
)
def test_svg_path_tolerance(run_prog, svg_in, expected):
    """Odd coordinate counts and unknown letters abort shortening of that tail verbatim, and Z always prints lowercase while resetting the cursor to the subpath start."""
    # CATCHES: a trailing L30 with an odd coordinate count keeps the original spaced spelling M10 10 L20 20 L30 exactly, Z is lowercased and makes a following L10 10 back to the start vanish, but a following H10 is kept.
    res = run_prog(["--type", "svg"], stdin=svg_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_svg_pathdocument_edge_documents(run_prog):
    """Empty d attributes survive, numeric character entities are decoded before path shortening, and newlines inside d act as separators."""
    # CATCHES: an empty d="" attribute is kept rather than dropped, M&#54; 6 is decoded to M6 6 before shortening (proving entities are resolved upstream of the path parser), and a raw newline separator is normalized away.
    empty = run_prog(["--type", "svg"], stdin='<svg><path d=""/></svg>')
    assert empty.rc == 0
    assert empty.out == '<svg><path d=""/></svg>'
    assert empty.err == ""

    entity = run_prog(["--type", "svg"], stdin='<svg><path d="M&#54; 6"/></svg>')
    assert entity.rc == 0
    assert entity.out == '<svg><path d="M6 6"/></svg>'
    assert entity.err == ""

    newline = run_prog(["--type", "svg"], stdin='<svg><path d="M0 0\nL10 10"/></svg>')
    assert newline.rc == 0
    assert newline.out == '<svg><path d="M0 0 10 10"/></svg>'
    assert newline.err == ""


# (id, input path data, --svg-precision value, expected path data)
PRECISION_CASES = [
    ('prec1-100', 'M100 100', '1', 'M1e2 1e2'),
    ('prec1-105', 'M105 105', '1', 'M1e2 1e2'),
    ('prec1-150', 'M150 150', '1', 'M2e2 2e2'),
    ('prec0-frac', 'M10.9 10.9', '0', 'M10.9 10.9'),
    ('prec2-frac', 'M10.259 10.259', '2', 'M10 10'),
]


@pytest.mark.parametrize(
    "d,precision,expected_d",
    [(c[1], c[2], c[3]) for c in PRECISION_CASES],
    ids=[c[0] for c in PRECISION_CASES],
)
def test_svg_path_precision(run_prog, d, precision, expected_d):
    """--svg-precision rounds path coordinates before the exponent and dot tricks are applied."""
    # CATCHES: with precision 1 both 105 and 100 round to 1e2 while 150 rounds up to 2e2, and precision 0 disables rounding entirely (10.9 stays 10.9).
    res = run_prog(["--type", "svg", "--svg-precision", precision], stdin=SVG_WRAP % d)
    assert res.rc == 0
    assert res.out == SVG_WRAP % expected_d
    assert res.err == ""


def test_svg_long_path_untouched(run_prog):
    """Path data longer than 100000 bytes is returned byte-identical, while the same path just under the limit is fully shortened."""
    # CATCHES: the >100000-byte guard leaves M0 0 plus 30000 L1 1 segments completely unchanged (byte-for-byte, including every space), yet the same construction with 19000 segments shortens to M0 0 1 1 because every repeated same-point line is dropped.
    long_d = "M0 0" + "L1 1" * 30000
    res = run_prog(["--type", "svg"], stdin=SVG_WRAP % long_d)
    assert res.rc == 0
    assert res.out == SVG_WRAP % long_d
    assert res.err == ""

    short_d = "M0 0" + "L1 1" * 19000
    res2 = run_prog(["--type", "svg"], stdin=SVG_WRAP % short_d)
    assert res2.rc == 0
    assert res2.out == '<svg><path d="M0 0 1 1"/></svg>'
    assert res2.err == ""
