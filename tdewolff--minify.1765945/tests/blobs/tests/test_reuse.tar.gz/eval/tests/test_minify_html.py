"""HTML minification behaviour, mined from the repository's native html tests
and recorded from the reference binary via ``--type html`` on stdin.
"""

import pytest

# (id, input HTML, expected output HTML)
HTML_CASES = [
    (
        "document-tags-stripped",
        "<html><head><title>x</title></head><body><p>  x  </p></body></html>",
        "<title>x</title><p>x",
    ),
    ("attribute-quotes-removed", '<p class="a">x</p>', '<p class=a>x'),
    ("comments-removed", "<p>a</p><!-- c -->", "<p>a</p>"),
    ("conditional-comments-removed", "<!--[if lt IE 9]><p>x<![endif]--><p>y", "<p>y"),
    (
        "optional-end-tags-removed",
        "<ul><li>a</li><li>b</li></ul>",
        "<ul><li>a<li>b</ul>",
    ),
    ("default-attrvals-removed", '<form method="get"><p>x</p></form>', "<form><p>x</form>"),
    ("boolean-attr-value-removed", '<input disabled="disabled">', "<input disabled>"),
    ("event-handler-js-minified", '<p onclick=" JavaScript: x">x</p>', "<p onclick=x>x"),
    ("entity-decoded", "<p>&amp;x&#65;</p>", "<p>&amp;xA"),
    ("pre-whitespace-kept", "<pre>a  b</pre>", "<pre>a  b</pre>"),
    ("doctype-lowercased", "<!DOCTYPE html>\n<p>x</p>\n", "<!doctype html><p>x"),
    ("charset-quotes-removed", '<meta charset="utf-8">', "<meta charset=utf-8>"),
    ("empty-script-removed", "<p>a</p><script></script>", "<p>a</p>"),
    ("template-syntax-kept-as-text", "<p>{{ .X }}</p>", "<p>{{ .X }}"),
    ("class-whitespace-collapsed", '<p class=" a  b ">x</p>', '<p class="a b">x'),
    ("span-end-tag-kept", '<span onload="javascript:x;"></span>', "<span onload=x></span>"),
    (
        "noscript-inner-html",
        '<noscript><html><img id="x"></noscript>',
        "<noscript><img id=x></noscript>",
    ),
]


@pytest.mark.parametrize(
    "html_in,expected", [(c[1], c[2]) for c in HTML_CASES],
    ids=[c[0] for c in HTML_CASES],
)
def test_html_minification(run_prog, html_in, expected):
    """The HTML minifier applies the recorded transformation to each snippet."""
    # CATCHES: pins optional-tag removal, quote removal, comment removal,
    # boolean/default attribute value removal, event-handler JS minification,
    # entity decoding, <pre> preservation and doctype lowercasing.
    res = run_prog(["--type", "html"], stdin=html_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


KEEP_FLAG_CASES = [
    (
        "document-tags",
        ["--html-keep-document-tags"],
        "<html><head><title>x</title></head><body><p>  x  </p></body></html>",
        "<html><head><title>x</title></head><body><p>x</body></html>",
    ),
    ("quotes", ["--html-keep-quotes"], '<p class="a">x</p>', '<p class="a">x'),
    ("comments", ["--html-keep-comments"], "<p>a</p><!-- c -->", "<p>a</p><!-- c -->"),
    (
        "special-comments",
        ["--html-keep-special-comments"],
        "<!--[if lt IE 9]><p>x<![endif]--><p>y",
        "<!--[if lt IE 9]><p>x<![endif]--><p>y",
    ),
    ("end-tags", ["--html-keep-end-tags"], "<ul><li>a</li><li>b</li></ul>", "<ul><li>a</li><li>b</li></ul>"),
    (
        "default-attrvals",
        ["--html-keep-default-attrvals"],
        '<form method="get"><p>x</p></form>',
        "<form method=get><p>x</form>",
    ),
    ("whitespace", ["--html-keep-whitespace"], "<p>\n  a\n  b\n</p>", "<p>\na\nb\n"),
]


@pytest.mark.parametrize(
    "flag_args,html_in,expected", [(f, i, e) for _n, f, i, e in KEEP_FLAG_CASES],
    ids=[n for n, _f, _i, _e in KEEP_FLAG_CASES],
)
def test_html_keep_flags(run_prog, flag_args, html_in, expected):
    """Each --html-keep-* flag preserves exactly its own construct."""
    # CATCHES: every keep flag re-enables one specific removal while the rest
    # of the minification (whitespace, other tags) still applies.
    res = run_prog(["--type", "html"] + flag_args, stdin=html_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_html_keep_conditional_comments_deprecated(run_prog):
    """The deprecated --html-keep-conditional-comments prints a notice on stdout."""
    # CATCHES: the DEPRECATED notice goes to stdout *before* the document and
    # the flag behaves like --html-keep-special-comments.
    res = run_prog(
        ["--type", "html", "--html-keep-conditional-comments"],
        stdin="<!--[if lt IE 9]><p>x<![endif]--><p>y",
    )
    assert res.rc == 0
    assert res.out == (
        "DEPRECATED: KeepConditionalComments is replaced by KeepSpecialComments\n"
        "<!--[if lt IE 9]><p>x<![endif]--><p>y"
    )
    assert res.err == ""


# (id, input, expected) for inline script/style content handling
SCRIPT_CASES = [
    ("script-js-minified", "<script>var a = 1;</script>", "<script>var a=1</script>"),
    ("script-type-removed", '<script type="text/javascript">js</script>', "<script>js</script>"),
    (
        "script-escape-kept",
        '<script>var a="<\\/script>"</script>',
        '<script>var a="<\\/script>"</script>',
    ),
    (
        "script-concat-escaped",
        '<script>var a="</scr"+"ipt>"</script>',
        '<script>var a="<\\/script>"</script>',
    ),
    (
        "script-hex-escape-uppercase",
        '<script>var a="\\x3c/SCRIPT>"</script>',
        '<script>var a="<\\/SCRIPT>"</script>',
    ),
    ("script-regex-lt-kept", "<script>x< /SCRIPT>/</script>", "<script>x< /SCRIPT>/</script>"),
    ("style-css-minified", "<style>a { color: red; }</style>", "<style>a{color:red}</style>"),
]


@pytest.mark.parametrize(
    "html_in,expected", [(c[1], c[2]) for c in SCRIPT_CASES],
    ids=[c[0] for c in SCRIPT_CASES],
)
def test_html_script_and_style_content(run_prog, html_in, expected):
    """Inline script and style contents are minified with escaping rules."""
    # CATCHES: "</scr"+"ipt>" is folded to an escaped "<\/script>", hex
    # escapes are normalised to the backslash form, a "< /SCRIPT>" inside a
    # regex literal is left untouched, and the type="text/javascript"
    # attribute is dropped.
    res = run_prog(["--type", "html"], stdin=html_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_html_style_attribute_css(run_prog):
    """A style attribute is minified as CSS, unquoting font names."""
    # CATCHES: &quot; entities in the attribute become CSS-level unquoted and
    # lowercased font names, while unquoted family names keep their case.
    res = run_prog(
        ["--type", "html"],
        stdin='<span style="font-family:&quot;Helvetica Neue&quot;,'
        '&quot;Helvetica&quot;,Helvetica,Arial,sans-serif">text</span>',
    )
    assert res.rc == 0
    assert res.out == (
        '<span style="font-family:helvetica neue,helvetica,Helvetica,Arial,sans-serif">text</span>'
    )


def test_html_svg_attribute_color(run_prog):
    """SVG presentation attributes are minified (color name to hex)."""
    # CATCHES: fill="yellow" inside HTML becomes #ff0, matching the CSS
    # colour shortening applied to presentation attributes.
    res = run_prog(
        ["--type", "html"],
        stdin='<svg width="100" height="100"><circle cx="50" cy="50" r="40" '
        'stroke="green" stroke-width="4" fill="yellow" /></svg>',
    )
    assert res.rc == 0
    assert res.out == (
        '<svg width="100" height="100"><circle cx="50" cy="50" r="40" '
        'stroke="green" stroke-width="4" fill="#ff0"/></svg>'
    )


TEMPLATE_CASES = [
    ("gohtml", "gohtml", "<p>{{ .X }}", "<p>{{ .X }}"),
    ("tmpl", "tmpl", "<p>{{ .X }}", "<p>{{ .X }}"),
    ("mustache", "mustache", "<p>{{ .X }}", "<p>{{ .X }}"),
    ("handlebars", "handlebars", "<p>{{ .X }}", "<p>{{ .X }}"),
    ("ejs", "ejs", "<p><%= x %>", "<p><%= x %>"),
    ("php", "php", "<p><?php echo 1; ?>", "<p><?php echo 1; ?>"),
    ("asp", "asp", "<p><%= x %>", "<p><%= x %>"),
]


@pytest.mark.parametrize(
    "filetype,html_in,expected", [(t, i, e) for _n, t, i, e in TEMPLATE_CASES],
    ids=[n for n, _t, _i, _e in TEMPLATE_CASES],
)
def test_template_types(run_prog, filetype, html_in, expected):
    """Template filetypes treat their delimiters as opaque text."""
    # CATCHES: for {{ }}, <% %>, and <?php ?> templates the HTML around the
    # delimiters is minified while the template expression survives verbatim.
    res = run_prog(["--type", filetype], stdin=html_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_template_file_by_extension(run_prog):
    """A .gohtml file is minified with template delimiters intact."""
    # CATCHES: extension inference maps gohtml to the Go-template HTML
    # minifier, which collapses HTML whitespace but keeps {{ .X }} untouched.
    res = run_prog(["t.gohtml"], files={"t.gohtml": "<p>  {{ .X }}  </p>"})
    assert res.rc == 0
    assert res.out == "<p>{{ .X }}"
    assert res.err == ""
