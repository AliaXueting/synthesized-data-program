"""File and directory handling: output-destination semantics, recursive walks,
--sync, --bundle, --match/--exclude/--include filters, --ext mappings, and
--inplace behaviour. Expectations were recorded from the reference binary.
"""

import re

import pytest

from conftest import (
    FINISHED_RE,
    assert_stats_lines,
    output_tree,
    stats_line_re,
    write_file,
)

CSS_IN = "a { color: red; }\n"
CSS_OUT = "a{color:red}"


class TestOutputDestinations:
    def test_file_to_output_file(self, run_prog, tmp_path):
        """-o writes the minified bytes and prints one stats line to stdout."""
        # CATCHES: with a file destination the stats line appears on stdout
        # with the source and destination named exactly as given, and the
        # file receives exactly the minified bytes.
        res = run_prog(["a.css", "-o", "out.css"], files={"a.css": CSS_IN})
        assert res.rc == 0
        assert res.err == ""
        lines = res.out.splitlines()
        assert len(lines) == 1
        assert stats_line_re("a.css", "out.css").match(lines[0])
        assert (tmp_path / "out.css").read_text(encoding="utf-8") == CSS_OUT

    def test_output_file_content_and_truncation(self, run_prog, tmp_path):
        """-o truncates a longer existing output file to the new content."""
        # CATCHES: the output is opened with O_TRUNC, so stale bytes cannot
        # survive past the new minified content.
        write_file(tmp_path / "a.css", CSS_IN)
        write_file(tmp_path / "out.css", "much longer previous content that must be truncated away")
        res = run_prog(["a.css", "-o", "out.css"])
        assert res.rc == 0
        assert (tmp_path / "out.css").read_text(encoding="utf-8") == CSS_OUT

    def test_output_creates_nested_directories(self, run_prog, tmp_path):
        """-o with a path in non-existent directories creates them."""
        # CATCHES: missing parent directories are created recursively before
        # the output file is opened.
        write_file(tmp_path / "a.css", CSS_IN)
        res = run_prog(["a.css", "-o", "x/y/z.css"])
        assert res.rc == 0
        assert stats_line_re("a.css", "x/y/z.css").match(res.out.splitlines()[0])
        assert (tmp_path / "x/y/z.css").read_text(encoding="utf-8") == CSS_OUT

    def test_output_trailing_slash_forces_directory(self, run_prog, tmp_path):
        """-o out/ (trailing slash) places the file inside the directory."""
        # CATCHES: the trailing slash disambiguates a single-file input that
        # would otherwise write to a file named out.
        write_file(tmp_path / "web/a.css", CSS_IN)
        res = run_prog(["web/a.css", "-o", "out/"])
        assert res.rc == 0
        assert stats_line_re("web/a.css", "out/a.css").match(res.out.splitlines()[0])
        assert (tmp_path / "out/a.css").read_text(encoding="utf-8") == CSS_OUT

    def test_output_dot_minifies_in_place(self, run_prog, tmp_path):
        """-o . rewrites the input file itself and leaves no .bak behind."""
        # CATCHES: "." resolves to the input's own path; the stats line has no
        # destination and the temporary .bak is removed on success.
        write_file(tmp_path / "a.css", CSS_IN)
        res = run_prog(["a.css", "-o", "."])
        assert res.rc == 0
        assert stats_line_re("a.css").match(res.out.splitlines()[0])
        assert (tmp_path / "a.css").read_text(encoding="utf-8") == CSS_OUT
        assert output_tree(tmp_path) == ["a.css"]

    def test_output_same_file(self, run_prog, tmp_path):
        """-o pointing at the input file rewrites it in place via a rename."""
        # CATCHES: overwriting the input goes through a .bak rename that is
        # cleaned up, so only the minified file remains.
        write_file(tmp_path / "a.css", CSS_IN)
        res = run_prog(["a.css", "-o", "a.css"])
        assert res.rc == 0
        assert stats_line_re("a.css").match(res.out.splitlines()[0])
        assert (tmp_path / "a.css").read_text(encoding="utf-8") == CSS_OUT
        assert output_tree(tmp_path) == ["a.css"]

    def test_output_existing_directory_single_file(self, run_prog, tmp_path):
        """-o naming an existing directory with one file input fails."""
        # CATCHES: an existing directory is not automatically a directory
        # destination for a single file; opening it for writing yields EISDIR.
        (tmp_path / "out").mkdir()
        write_file(tmp_path / "a.css", "a{}")
        res = run_prog(["a.css", "-o", "out"])
        assert res.rc == 1
        assert res.out == ""
        assert res.err == 'ERROR: open output file "out": open out: is a directory\n'
        assert output_tree(tmp_path / "out") == []

    def test_output_existing_directory_multi(self, run_prog, tmp_path):
        """Two file inputs with -o naming a directory fill that directory."""
        # CATCHES: more than one input flips the destination to a directory
        # even without a trailing slash.
        (tmp_path / "out").mkdir()
        write_file(tmp_path / "a.css", "a{color:red}")
        write_file(tmp_path / "b.css", "b{color:blue}")
        res = run_prog(["a.css", "b.css", "-o", "out"])
        assert res.rc == 0
        assert_stats_lines(
            res.out,
            [stats_line_re("a.css", "out/a.css"), stats_line_re("b.css", "out/b.css")],
        )
        assert (tmp_path / "out/a.css").read_text(encoding="utf-8") == "a{color:red}"
        assert (tmp_path / "out/b.css").read_text(encoding="utf-8") == "b{color:blue}"

    def test_output_dash_is_stdout(self, run_prog):
        """-o - explicitly selects stdout; no stats line is printed."""
        # CATCHES: a literal "-" destination behaves like the default stdout
        # destination, including the suppressed stats line.
        res = run_prog(["a.css", "-o", "-"], files={"a.css": CSS_IN})
        assert res.rc == 0
        assert res.out == CSS_OUT
        assert res.err == ""

    def test_output_empty_string_is_stdout(self, run_prog):
        """An empty -o value falls back to stdout."""
        # CATCHES: -o "" is indistinguishable from omitting -o entirely.
        res = run_prog(["a.css", "-o", ""], files={"a.css": CSS_IN})
        assert res.rc == 0
        assert res.out == CSS_OUT
        assert res.err == ""


class TestInPlace:
    def test_inplace_multiple_files(self, run_prog, tmp_path):
        """--inplace rewrites each input and prints one stats line per file."""
        # CATCHES: in-place stats lines name only the source (no destination)
        # and each file keeps its own minified content.
        write_file(tmp_path / "a.css", CSS_IN)
        write_file(tmp_path / "b.js", "var a = 1;\n")
        res = run_prog(["--inplace", "a.css", "b.js"])
        assert res.rc == 0
        assert_stats_lines(res.out, [stats_line_re("a.css"), stats_line_re("b.js")])
        assert (tmp_path / "a.css").read_text(encoding="utf-8") == CSS_OUT
        assert (tmp_path / "b.js").read_text(encoding="utf-8") == "var a=1"

    def test_inplace_failure_keeps_original(self, run_prog, tmp_path):
        """A failing in-place minification restores the original bytes."""
        # CATCHES: the .bak rename is undone on failure, so the file on disk
        # still holds the unminified input while rc is 1.
        write_file(tmp_path / "a.json", '{"a":}')
        res = run_prog(["--inplace", "a.json"])
        assert res.rc == 1
        assert stats_line_re("a.json").match(res.out.splitlines()[0])
        assert (tmp_path / "a.json").read_text(encoding="utf-8") == '{"a":}'
        assert output_tree(tmp_path) == ["a.json"]

    def test_output_same_failure_keeps_original(self, run_prog, tmp_path):
        """A failing -o to the input file itself also restores the original."""
        # CATCHES: -o <input> uses the same .bak mechanism as --inplace.
        write_file(tmp_path / "a.json", '{"a":}')
        res = run_prog(["a.json", "-o", "a.json"])
        assert res.rc == 1
        assert (tmp_path / "a.json").read_text(encoding="utf-8") == '{"a":}'
        assert output_tree(tmp_path) == ["a.json"]


class TestDirectories:
    def test_directory_without_recursive_warns(self, run_prog):
        """A directory input without -r is skipped with a warning and rc 0."""
        # CATCHES: the omission is only a warning; the run still succeeds and
        # nothing is written anywhere.
        res = run_prog(["sub"], files={"sub/a.css": "a{}"})
        assert res.rc == 0
        assert res.out == ""
        assert res.err == "WARNING: --recursive not specified, omitting directory sub\n"

    def test_recursive_directory(self, run_prog, tmp_path):
        """-r walks subdirectories and mirrors the tree under the output."""
        # CATCHES: the directory itself becomes a subdirectory of the output
        # (sub/a.css -> out/sub/a.css) and nested dirs are walked too.
        write_file(tmp_path / "sub/a.css", CSS_IN)
        write_file(tmp_path / "sub/deep/b.css", "b{color:blue}")
        res = run_prog(["-r", "-o", "out", "sub"])
        assert res.rc == 0
        assert res.err == ""
        assert_stats_lines(
            res.out,
            [
                stats_line_re("sub/a.css", "out/sub/a.css"),
                stats_line_re("sub/deep/b.css", "out/sub/deep/b.css"),
            ],
        )
        assert (tmp_path / "out/sub/a.css").read_text(encoding="utf-8") == CSS_OUT
        assert (tmp_path / "out/sub/deep/b.css").read_text(encoding="utf-8") == "b{color:blue}"

    def test_recursive_input_trailing_slash(self, run_prog, tmp_path):
        """A trailing slash on the input strips the directory name in output."""
        # CATCHES: sub/ copies the *contents* (out/a.css), unlike sub which
        # produces out/sub/a.css.
        write_file(tmp_path / "sub/a.css", CSS_IN)
        res = run_prog(["-r", "-o", "out", "sub/"])
        assert res.rc == 0
        assert stats_line_re("sub/a.css", "out/a.css").match(res.out.splitlines()[0])
        assert (tmp_path / "out/a.css").read_text(encoding="utf-8") == CSS_OUT

    def test_recursive_dotted_input(self, run_prog, tmp_path):
        """An explicit ./sub input keeps the sub directory in the output."""
        # CATCHES: ./sub is cleaned to sub, so output mirrors sub/a.css.
        write_file(tmp_path / "sub/a.css", CSS_IN)
        res = run_prog(["-r", "-o", "out", "./sub"])
        assert res.rc == 0
        assert stats_line_re("sub/a.css", "out/sub/a.css").match(res.out.splitlines()[0])
        assert (tmp_path / "out/sub/a.css").read_text(encoding="utf-8") == CSS_OUT

    def test_sync_copies_unmatched_files(self, run_prog, tmp_path):
        """--sync copies files without a known minifier byte-for-byte."""
        # CATCHES: b.txt is copied verbatim (internal runs of spaces intact)
        # while css/js inputs are minified; only minified files get stats.
        write_file(tmp_path / "sub/a.css", CSS_IN)
        write_file(tmp_path / "sub/b.txt", "plain   text")
        write_file(tmp_path / "sub/c.js", "var a = 1")
        res = run_prog(["-s", "-r", "-o", "out", "sub"])
        assert res.rc == 0
        assert res.err == ""
        assert_stats_lines(
            res.out,
            [stats_line_re("sub/a.css", "out/sub/a.css"), stats_line_re("sub/c.js", "out/sub/c.js")],
        )
        assert (tmp_path / "out/sub/a.css").read_text(encoding="utf-8") == CSS_OUT
        assert (tmp_path / "out/sub/b.txt").read_text(encoding="utf-8") == "plain   text"
        assert (tmp_path / "out/sub/c.js").read_text(encoding="utf-8") == "var a=1"

    def test_sync_verbose_copy_info(self, run_prog, tmp_path):
        """-v with --sync logs each copied (non-minified) file as INFO."""
        # CATCHES: plain copies are reported as "INFO: copy <src> to <dst>"
        # on stderr, in addition to the usual finished line.
        write_file(tmp_path / "sub/a.css", CSS_IN)
        write_file(tmp_path / "sub/b.txt", "plain   text")
        res = run_prog(["-s", "-r", "-v", "-o", "out", "sub"])
        assert res.rc == 0
        err_lines = res.err.splitlines()
        assert err_lines[0] == "INFO: copy sub/b.txt to out/sub/b.txt"
        assert FINISHED_RE.match(err_lines[1])
        assert len(err_lines) == 2

    def test_sync_without_recursive(self, run_prog):
        """--sync on a directory without -r warns and copies nothing."""
        # CATCHES: sync does not imply recursion; the directory is skipped
        # exactly like a plain directory input.
        res = run_prog(["-s", "-o", "out", "sub"], files={"sub/a.css": "a{}"})
        assert res.rc == 0
        assert res.out == ""
        assert res.err == "WARNING: --recursive not specified, omitting directory sub\n"


class TestBundle:
    def test_bundle_js_to_file(self, run_prog, tmp_path):
        """--bundle joins JS files with a ";//" separator before minifying."""
        # CATCHES: JS bundling inserts ";\n" between files so the concatenated
        # result re-minifies to a single var statement, and the stats line
        # names every source in parentheses.
        write_file(tmp_path / "a.js", "var a = 1\n")
        write_file(tmp_path / "b.js", "var b = 2\n")
        res = run_prog(["--bundle", "a.js", "b.js", "-o", "out.js"])
        assert res.rc == 0
        assert stats_line_re("(a.js + b.js)", "out.js").match(res.out.splitlines()[0])
        assert (tmp_path / "out.js").read_text(encoding="utf-8") == "var a=1,b=2"

    def test_bundle_js_to_stdout(self, run_prog):
        """Bundling to stdout prints only the concatenated minified bytes."""
        # CATCHES: the bundle result goes to stdout without a stats line, like
        # any other stdout destination.
        res = run_prog(["--bundle", "a.js", "b.js"], files={"a.js": "var a = 1\n", "b.js": "var b = 2\n"})
        assert res.rc == 0
        assert res.out == "var a=1,b=2"
        assert res.err == ""

    def test_bundle_css_to_file(self, run_prog, tmp_path):
        """CSS bundling concatenates without any separator."""
        # CATCHES: only JS gets a ";\n" separator; CSS files are glued
        # together directly.
        write_file(tmp_path / "a.css", "a { color: red; }")
        write_file(tmp_path / "b.css", "b { color: blue; }")
        res = run_prog(["--bundle", "a.css", "b.css", "-o", "out.css"])
        assert res.rc == 0
        assert (tmp_path / "out.css").read_text(encoding="utf-8") == "a{color:red}b{color:blue}"

    def test_bundle_empty_middle_file(self, run_prog, tmp_path):
        """An empty file in a bundle is listed in the stats but adds no bytes."""
        # CATCHES: empty inputs are not skipped; they still appear in the
        # parenthesized source list of the stats line.
        write_file(tmp_path / "a.js", "var a = 1\n")
        write_file(tmp_path / "empty.js", "")
        write_file(tmp_path / "b.js", "var b = 2\n")
        res = run_prog(["--bundle", "a.js", "empty.js", "b.js", "-o", "out.js"])
        assert res.rc == 0
        assert stats_line_re("(a.js + empty.js + b.js)", "out.js").match(res.out.splitlines()[0])
        assert (tmp_path / "out.js").read_text(encoding="utf-8") == "var a=1,b=2"

    def test_bundle_mixed_types_warning(self, run_prog):
        """Bundling files with different inferred mimetypes fails with rc 1."""
        # CATCHES: the mismatch is a WARNING on stderr (not ERROR) but still
        # fails the run; nothing is minified or written.
        res = run_prog(
            ["--bundle", "a.css", "b.js", "-o", "out.x"],
            files={"a.css": "a{color:red}", "b.js": "var b=2"},
        )
        assert res.rc == 1
        assert res.out == ""
        assert res.err == (
            "WARNING: inferred mimetype application/javascript of b.js "
            "for concatenation unequal to previous mimetypes, set --type explicitly\n"
        )

    def test_bundle_recursive_mixed(self, run_prog, tmp_path):
        """A recursive bundle over mixed extensions warns and writes no output."""
        # CATCHES: the output file is not created when mimetype unification
        # fails, even though the destination was a plain file name.
        write_file(tmp_path / "a.js", "var a = 1")
        write_file(tmp_path / "sub/b.js", "var b = 2")
        write_file(tmp_path / "c.css", "a{}")
        res = run_prog(["--bundle", "-r", ".", "-o", "out.js"])
        assert res.rc == 1
        assert res.err == (
            "WARNING: inferred mimetype text/css of c.css "
            "for concatenation unequal to previous mimetypes, set --type explicitly\n"
        )
        assert not (tmp_path / "out.js").exists()

    def test_bundle_directory_without_recursive(self, run_prog):
        """Bundling a directory without -r warns about the omitted directory."""
        # CATCHES: --bundle does not imply recursion; the warning names "."
        # for the current-directory input and rc stays 0.
        res = run_prog(["--bundle", "."], files={"a.js": "var a=1"})
        assert res.rc == 0
        assert res.out == ""
        assert res.err == "WARNING: --recursive not specified, omitting directory .\n"


class TestFilters:
    def test_match_glob(self, run_prog, tmp_path):
        """--match with a glob filters on the base filename."""
        # CATCHES: only *.css basenames are processed; ab.js is skipped
        # entirely (not copied, not warned about).
        write_file(tmp_path / "a.css", "a { color: red; }")
        write_file(tmp_path / "ab.js", "var a=1")
        write_file(tmp_path / "sub/c.css", "c { color: green; }")
        res = run_prog(["--match", "*.css", "-r", "-o", "out", "."])
        assert res.rc == 0
        assert res.err == ""
        assert_stats_lines(
            res.out,
            [stats_line_re("a.css", "out/a.css"), stats_line_re("sub/c.css", "out/sub/c.css")],
        )
        assert output_tree(tmp_path / "out") == ["a.css", "sub/c.css"]

    def test_match_regex(self, run_prog, tmp_path):
        """--match with a ~ prefix is a full regular expression."""
        # CATCHES: the tilde switches the pattern from glob to regex; here
        # ^a.*css$ matches both a.css and ab.css basenames.
        write_file(tmp_path / "a.css", "a{}")
        write_file(tmp_path / "ab.css", "b{}")
        res = run_prog(["--match", "~^a.*css$", "-r", "-o", "out", "."])
        assert res.rc == 0
        assert_stats_lines(
            res.out,
            [stats_line_re("a.css", "out/a.css"), stats_line_re("ab.css", "out/ab.css")],
        )
        assert output_tree(tmp_path / "out") == ["a.css", "ab.css"]

    def test_match_case_insensitive_regex(self, run_prog, tmp_path):
        """An inline (?i) group in a --match regex is honoured."""
        # CATCHES: the pattern is compiled as-is, so regexp flags like (?i)
        # work and only case-variant names match.
        write_file(tmp_path / "a.css", "a{}")
        write_file(tmp_path / "B.css", "b{}")
        res = run_prog(["--match", "~^(?i)A.*CSS$", "-r", "-o", "out", "."])
        assert res.rc == 0
        assert output_tree(tmp_path / "out") == ["a.css"]

    def test_match_doublestar_matches_nothing(self, run_prog, tmp_path):
        """A **/*.css glob never matches, because --match sees basenames only."""
        # CATCHES: ** requires a path separator but only the basename is
        # matched, so even nested files are filtered out while the plain
        # *.css control run on the very same tree processes every file.
        write_file(tmp_path / "a.css", "a{}")
        write_file(tmp_path / "sub/b.css", "b{}")
        control = run_prog(["--match", "*.css", "-r", "-o", "out1", "."])
        assert control.rc == 0
        assert_stats_lines(
            control.out,
            [
                stats_line_re("a.css", "out1/a.css"),
                stats_line_re("sub/b.css", "out1/sub/b.css"),
            ],
        )
        assert output_tree(tmp_path / "out1") == ["a.css", "sub/b.css"]
        res = run_prog(["--match", "**/*.css", "-r", "-o", "out2", "."])
        assert res.rc == 0
        assert res.out == ""
        assert res.err == ""
        assert output_tree(tmp_path / "out2") == []

    def test_match_none(self, run_prog, tmp_path):
        """A --match pattern matching nothing succeeds with an empty output dir."""
        # CATCHES: zero matching files is not an error; the destination
        # directory is still created but left empty.
        write_file(tmp_path / "a.css", "a{}")
        res = run_prog(["--match", "*.xyz", "-r", "-o", "out", "."])
        assert res.rc == 0
        assert res.out == ""
        assert (tmp_path / "out").is_dir()
        assert output_tree(tmp_path / "out") == []

    def test_match_invalid_regex(self, run_prog):
        """An invalid ~ regex in --match exits 1 with the compile error."""
        # CATCHES: the raw regexp compile error is surfaced on stderr.
        res = run_prog(["--match", "~[", "-r", "-o", "out", "."], files={"a.css": "a{}"})
        assert res.rc == 1
        assert res.out == ""
        assert res.err == "ERROR: error parsing regexp: missing closing ]: `[`\n"

    def test_exclude_invalid_regex(self, run_prog):
        """An invalid ~ regex in --exclude exits 1 with the compile error."""
        # CATCHES: --exclude patterns are compiled with the same rules as
        # --match and fail identically.
        res = run_prog(["--exclude", "~[", "-r", "-o", "out", "."], files={"a.css": "a{}"})
        assert res.rc == 1
        assert res.err == "ERROR: error parsing regexp: missing closing ]: `[`\n"

    def test_match_greedy_arguments(self, run_prog):
        """--match greedily consumes following non-option arguments."""
        # CATCHES: the list-valued --match swallows "a.css" as a second
        # pattern, leaving no inputs, so the run degrades to a stdin request
        # and fails with "must specify --type for stdin".
        res = run_prog(["--match", "*.css", "a.css", "-o", "out.css"], files={"a.css": "a{}"}, stdin="")
        assert res.rc == 1
        assert res.out == ""
        assert res.err == "ERROR: must specify --type for stdin\n"

    def test_exclude_glob_then_include(self, run_prog, tmp_path):
        """--exclude followed by --include re-adds files in order."""
        # CATCHES: filters apply in sequence: *.css excludes both files, then
        # a.css is re-included, so only a.css is minified.
        write_file(tmp_path / "a.css", "a{}")
        write_file(tmp_path / "b.css", "b{}")
        res = run_prog(["--exclude", "*.css", "--include", "a.css", "-r", "-o", "out", "."])
        assert res.rc == 0
        assert res.err == ""
        assert output_tree(tmp_path / "out") == ["a.css"]

    @pytest.mark.parametrize(
        "pattern,expected",
        [("sub/*", ["a.css"]), ("sub", ["a.css", "sub/b.css"])],
        ids=["star-matches-path", "literal-does-not-match"],
    )
    def test_exclude_matches_full_path(self, run_prog, tmp_path, pattern, expected):
        """--exclude patterns are matched against the full path, not basename."""
        # CATCHES: unlike --match, exclude sees the whole path: "sub/*" prunes
        # sub/b.css while the literal "sub" matches nothing and keeps it.
        write_file(tmp_path / "a.css", "a{}")
        write_file(tmp_path / "sub/b.css", "b{}")
        res = run_prog(["--exclude", pattern, "-r", "-o", "out", "."])
        assert res.rc == 0
        assert res.err == ""
        assert output_tree(tmp_path / "out") == expected

    def test_dashdash_separates_inputs(self, run_prog, tmp_path):
        """A -- separator ends option-argument scanning for the list options."""
        # CATCHES: after --, "a.css" and "b.js" are inputs (not more --exclude
        # patterns); the two inputs also flip -o out into a directory target.
        write_file(tmp_path / "a.css", "a{}")
        write_file(tmp_path / "b.js", "var a = 1;\n")
        res = run_prog(["-o", "out", "--exclude", "*.css", "--", "a.css", "b.js"])
        assert res.rc == 0
        assert res.err == ""
        assert stats_line_re("b.js", "out/b.js").match(res.out.splitlines()[0])
        assert (tmp_path / "out/b.js").read_text(encoding="utf-8") == "var a=1"
        assert output_tree(tmp_path / "out") == ["b.js"]

    def test_hidden_files_skipped_by_default(self, run_prog, tmp_path):
        """Hidden files and directories are skipped without --all."""
        # CATCHES: dot-prefixed names are filtered during the walk, not by a
        # match pattern, and no warning is printed for them.
        write_file(tmp_path / "visible.css", "v{color:blue}")
        write_file(tmp_path / ".hidden/a.css", "a{color:red}")
        res = run_prog(["-r", "-o", "out", "."])
        assert res.rc == 0
        assert res.err == ""
        assert output_tree(tmp_path / "out") == ["visible.css"]

    def test_all_includes_hidden(self, run_prog, tmp_path):
        """--all walks into hidden directories as well."""
        # CATCHES: -a un-hides .hidden/a.css, which is then minified and
        # written to out/.hidden/a.css.
        write_file(tmp_path / "visible.css", "v{color:blue}")
        write_file(tmp_path / ".hidden/a.css", "a{color:red}")
        res = run_prog(["-a", "-r", "-o", "out", "."])
        assert res.rc == 0
        assert_stats_lines(
            res.out,
            [
                stats_line_re("visible.css", "out/visible.css"),
                stats_line_re(".hidden/a.css", "out/.hidden/a.css"),
            ],
        )
        assert output_tree(tmp_path / "out") == [".hidden/a.css", "visible.css"]


class TestExtAndType:
    @pytest.mark.parametrize(
        "ext_args",
        [["--ext.foo=css"], ["--ext.foo=text/css"], ["--ext", "{foo:css}"]],
        ids=["dotted-filetype", "dotted-mimetype", "brace"],
    )
    def test_ext_mapping(self, run_prog, ext_args, tmp_path):
        """--ext maps a custom extension to a filetype or mimetype."""
        # CATCHES: a.foo has no built-in mapping but is minified as CSS after
        # the mapping; all three syntaxes behave identically.
        write_file(tmp_path / "a.foo", CSS_IN)
        res = run_prog(ext_args + ["a.foo", "-o", "out.css"])
        assert res.rc == 0
        assert stats_line_re("a.foo", "out.css").match(res.out.splitlines()[0])
        assert (tmp_path / "out.css").read_text(encoding="utf-8") == CSS_OUT

    def test_ext_invalid_map(self, run_prog):
        """A --ext value without key=value or braces is a usage error (rc 2)."""
        # CATCHES: bad map syntax is an argument-parse failure with the
        # message "option --ext: invalid map" on stderr and usage on stdout.
        res = run_prog(["--ext", "foo=css", "a.foo", "-o", "out.css"], files={"a.foo": CSS_IN})
        assert res.rc == 2
        assert res.err == "option --ext: invalid map\n\n"
        assert re.match(r"^Usage: \S+ \[options\] inputs\.\.\.$", res.out.split("\n", 1)[0])

    def test_ext_two_mappings(self, run_prog, tmp_path):
        """Two --ext mappings drive two different minifiers in one run."""
        # CATCHES: each mapping is independent (foo->css, bar->js) and two
        # inputs turn -o out into a directory destination.
        write_file(tmp_path / "a.foo", CSS_IN)
        write_file(tmp_path / "b.bar", "var a = 1\n")
        res = run_prog(["--ext.foo=css", "--ext.bar=js", "a.foo", "b.bar", "-o", "out"])
        assert res.rc == 0
        assert_stats_lines(
            res.out,
            [stats_line_re("a.foo", "out/a.foo"), stats_line_re("b.bar", "out/b.bar")],
        )
        assert (tmp_path / "out/a.foo").read_text(encoding="utf-8") == CSS_OUT
        assert (tmp_path / "out/b.bar").read_text(encoding="utf-8") == "var a=1"

    def test_type_overrides_extension(self, run_prog):
        """--type forces the minifier regardless of the file's extension."""
        # CATCHES: x.txt would be skipped by extension inference, but with
        # --type css its CSS content is minified to stdout.
        res = run_prog(["--type", "css", "x.txt"], files={"x.txt": CSS_IN})
        assert res.rc == 0
        assert res.out == CSS_OUT
        assert res.err == ""

    def test_preserve_mode(self, run_prog, tmp_path):
        """--preserve mode is accepted for file-to-file runs."""
        # CATCHES: explicitly preserving mode is only legal with real file
        # outputs; here it succeeds and the content is minified normally.
        write_file(tmp_path / "a.css", CSS_IN)
        res = run_prog(["--preserve", "mode", "a.css", "-o", "out.css"])
        assert res.rc == 0
        assert stats_line_re("a.css", "out.css").match(res.out.splitlines()[0])
        assert (tmp_path / "out.css").read_text(encoding="utf-8") == CSS_OUT

    def test_stats_for_empty_file(self, run_prog, tmp_path):
        """An empty input still gets a stats line with 0 B, 0 B and 100.0%."""
        # CATCHES: zero-length input reports ratio 100.0% (not 0%) and both
        # byte counts as a padded "0 B".
        write_file(tmp_path / "empty.css", "")
        res = run_prog(["empty.css", "-o", "out.css"])
        assert res.rc == 0
        line = res.out.splitlines()[0]
        assert stats_line_re("empty.css", "out.css").match(line)
        assert re.search(r",    0 B,    0 B, 100\.0%,", line)
        assert (tmp_path / "out.css").read_text(encoding="utf-8") == ""
