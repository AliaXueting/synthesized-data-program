"""Deep JavaScript minification behaviour, recorded byte-for-byte from the
reference binary via ``--type js`` on stdin.

This module targets the JS minifier internals in js/js.go and js/util.go:
arrow functions, class declarations, destructuring bindings, object-literal
properties, statement forms, number-base rewriting, unary/grouping rules,
conditional and nullish rewriting, boolean folding, string quote choice and
escape decoding, template literals, regexp literals, import/export clauses,
dead-code elimination, sequence merging, and identifier spacing.

Every expected value below is the exact stdout of the reference binary for
the exact input shown; inputs and outputs containing raw control bytes use
Python escape sequences (``\t``, ``\x0b``, ``\U0001F600``, ...) that denote
those single bytes, while ``\\x41`` denotes a literal backslash sequence in
the JS source.
"""

import pytest

# (id, input JS, expected output JS)
ARROW_FUNCTIONS = [
    ('arrow-empty', '() => {}', '()=>{}'),
    ('arrow-single-param-parens', '(a) => {a}', 'e=>{e}'),
    ('arrow-rest-param', '(...a) => {}', '(...e)=>{}'),
    ('arrow-default-param', '(a=0) => {a}', '(e=0)=>{e}'),
    ('arrow-two-params', '(a,b) => {a,b}', '(e,t)=>{e,t}'),
    ('arrow-ident-body', 'a => {a++}', 'e=>{e++}'),
    ('arrow-assign', 'x=(a) => {a}', 'x=e=>{e}'),
    ('arrow-return-undefined', 'x=() => {return}', 'x=()=>{}'),
    ('arrow-return-value', 'x=(a) => {return a}', 'x=e=>e'),
    ('arrow-return-seq', 'x=(a) => {a++;return a}', 'x=e=>(e++,e)'),
    ('arrow-while-return', 'x=(a) => {while(b);return}', 'x=e=>{for(;b;);}'),
    ('arrow-expr-body', 'x=(a,b) => a+b', 'x=(e,t)=>e+t'),
    ('arrow-async', 'async a => await b', 'async e=>await b'),
    ('arrow-empty-array-param', '([])=>5', '([])=>5'),
    ('arrow-empty-object-param', '({})=>5', '({})=>5'),
    ('arrow-obj-body', 'x=()=>({a:1})', 'x=()=>({a:1})'),
    ('arrow-async-empty', 'x=async()=>{}', 'x=async()=>{}'),
    ('nested-arrow', 'x=a=>b=>a+b', 'x=e=>t=>e+t'),
    ('iife-arrow', '(()=>{})()', '(()=>{})()'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in ARROW_FUNCTIONS],
    ids=[c[0] for c in ARROW_FUNCTIONS],
)
def test_js_arrow_functions(run_prog, js_in, expected):
    """Arrow functions are minified: parens dropped for one plain parameter, ``return`` folded into the expression body, and parameters renamed."""
    # CATCHES: arrow parameters are renamed (a=>e) unlike top-level vars, a lone ``return a`` becomes the expression body, and a body ending in return after statements becomes a sequence expression (e++,e).
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
CLASSES = [
    ('class-empty', 'class a {}', 'class a{}'),
    ('class-extends', 'class a extends b {}', 'class a extends b{}'),
    ('class-extends-not', 'class a extends(!b){}', 'class a extends(!b){}'),
    ('class-method', 'class a { f(a) {a} }', 'class a{f(e){e}}'),
    ('class-static-method', 'class a{static g(){}}', 'class a{static g(){}}'),
    ('class-static-computed', 'class a{static [1](){}}', 'class a{static[1](){}}'),
    ('class-getter', 'class a{get g(){}}', 'class a{get g(){}}'),
    ('class-getter-computed', 'class a{get [1](){}}', 'class a{get[1](){}}'),
    ('class-setter', 'class a{set g(){}}', 'class a{set g(){}}'),
    ('class-static-async', 'class a{static async g(){}}', 'class a{static async g(){}}'),
    ('class-static-async-star', 'class a{static async*g(){}}', 'class a{static async*g(){}}'),
    ('class-string-method', 'class a{"f"(){}}', 'class a{f(){}}'),
    ('class-two-methods', 'class a{f(){};g(){}}', 'class a{f(){}g(){}}'),
    ('class-fields', 'class a{one;#two = 2;f(){}}', 'class a{one;#e=2;f(){}}'),
    ('class-static-private-field', 'class a{static #d=5}', 'class a{static#e=5}'),
    ('class-static-field', 'class a{static b }', 'class a{static b}'),
    ('class-static-bare', 'class a{static }', 'class a{static}'),
    ('class-negated', '!class {}', '!class{}'),
    ('class-grouped', '(class a{})', '!class a{}'),
    ('class-private-method', 'class a{#m(){}}', 'class a{#e(){}}'),
    ('class-static-block', 'class a{static{}}', 'class a{static{}}'),
    ('class-constructor', 'class a{constructor(){}}', 'class a{constructor(){}}'),
    ('class-getter-rename', 'class a{get g(){return this.v}}', 'class a{get g(){return this.v}}'),
    ('class-expr-assign', 'x=class{}', 'x=class{}'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in CLASSES],
    ids=[c[0] for c in CLASSES],
)
def test_js_classes(run_prog, js_in, expected):
    """Class declarations, fields and every method modifier keep their grammar while losing redundant spaces, semicolons and quotes."""
    # CATCHES: computed element names lose the space after the modifier (static [1] -> static[1]), a quoted method name is unquoted, private members are renamed (#m -> #e), and a grouped class expression is negated to stay an expression (!class a{}).
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
DESTRUCTURING_BINDINGS = [
    ('bind-object', 'var {a, b} = c', 'var{a,b}=c'),
    ('bind-array', 'var [a, b] = c', 'var[a,b]=c'),
    ('bind-renamed', 'var {a: b} = c', 'var{a:b}=c'),
    ('bind-default', 'var {a = 1} = c', 'var{a=1}=c'),
    ('bind-rest-array', 'var [...a] = b', 'var[...a]=b'),
    ('bind-rest-object', 'var {a, ...rest} = c', 'var{a,...rest}=c'),
    ('bind-holes', 'var [a,,b]=c', 'var[a,,b]=c'),
    ('bind-assign-expr', '({a}=5)', '({a}=5)'),
    ('bind-assign-shorthand', '({a:a}=5)', '({a}=5)'),
    ('bind-let', 'let {a,b}=c', 'let{a,b}=c'),
    ('bind-const', 'const [a]=b', 'const[a]=b'),
    ('obj-destr-parens', '({a:"a"}=5)', '({a:"a"}=5)'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in DESTRUCTURING_BINDINGS],
    ids=[c[0] for c in DESTRUCTURING_BINDINGS],
)
def test_js_destructuring_bindings(run_prog, js_in, expected):
    """Object and array destructuring patterns in declarations keep their shape while whitespace around commas, colons and equals is removed."""
    # CATCHES: rest elements, holes and defaults survive verbatim, a parenthesised destructuring assignment stays parenthesised, and the shorthand ({a:a}=5) collapses to ({a}=5).
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
OBJECT_PROPERTIES = [
    ('prop-plain', 'x={a:1}', 'x={a:1}'),
    ('prop-quoted-key', 'x={"a":1}', 'x={a:1}'),
    ('prop-shorthand', 'x={a:a}', 'x={a}'),
    ('prop-dashed-key', 'x={"a-b":1}', 'x={"a-b":1}'),
    ('prop-numeric-key', 'x={0:1}', 'x={0:1}'),
    ('prop-computed', 'x={[a]:1}', 'x={[a]:1}'),
    ('prop-method', 'x={m(){}}', 'x={m(){}}'),
    ('prop-getter', 'x={get g(){}}', 'x={get g(){}}'),
    ('prop-setter', 'x={set g(v){}}', 'x={set g(e){}}'),
    ('prop-async-method', 'x={async m(){}}', 'x={async m(){}}'),
    ('prop-generator', 'x={*g(){}}', 'x={*g(){}}'),
    ('obj-getter-computed', 'x={get [a](){}}', 'x={get[a](){}}'),
    ('getter-in-obj-rename', 'x={g(a){a}}', 'x={g(e){e}}'),
    ('throw-object', 'throw {a:1}', 'throw{a:1}'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in OBJECT_PROPERTIES],
    ids=[c[0] for c in OBJECT_PROPERTIES],
)
def test_js_object_properties(run_prog, js_in, expected):
    """Object-literal properties: quoted keys unquoted when identifiers, value shorthand, and method/getter/setter/generator forms."""
    # CATCHES: only identifier-safe keys are unquoted ("a-b" keeps its quotes), computed keys keep brackets, method parameters are renamed, and a computed getter loses the space (get [a] -> get[a]).
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
STATEMENT_FORMS = [
    ('if-block-to-stmt', 'if(a){b()}', 'a&&b()'),
    ('else-block-to-stmt', 'if(a){b()}else{c()}', 'a?b():c()'),
    ('switch-cases', 'switch (a) { case b: 5; default: 6}', 'switch(a){case b:5;default:6}'),
    ('switch-string-case', 'switch (a) { case "text": 5}', 'switch(a){case"text":5}'),
    ('try-catch-finally', 'try{}catch(e){}finally{}', 'try{}catch{}finally{}'),
    ('try-catch-no-binding', 'try{}catch{}', 'try{}catch{}'),
    ('try-finally', 'try{}finally{}', 'try{}finally{}'),
    ('label', 'label: b', 'label:b'),
    ('label-colon', 'label: b', 'label:b'),
    ('with-stmt', 'with (a = b) x', 'with(a=b)x'),
    ('with-block', 'with (a = b) {x}', 'with(a=b)x'),
    ('for-in', 'for (var a in b) c', 'for(var a in b)c'),
    ('for-of-continue', 'for (var a of b){continue}', 'for(var a of b);'),
    ('for-of-labeled-continue', 'for (var a of b){continue LABEL}', 'for(var a of b)continue LABEL'),
    ('for-of-break', 'for (var a of b){break}', 'for(var a of b)break'),
    ('do-while', 'do x; while(a)', 'do x;while(a)'),
    ('do-while-block', 'do{}while(a)', 'do;while(a)'),
    ('do-while-label', 'a:do{x}while(a)', 'a:do x;while(a)'),
    ('debugger-stmt', 'debugger', 'debugger'),
    ('return-undefined', 'function g(){return undefined}', 'function g(){}'),
    ('return-void0', 'function g(){return void 0}', 'function g(){}'),
    ('return-bare', 'function g(){return}', 'function g(){}'),
    ('labeled-block', 'a:{break a}', 'a:break a'),
    ('for-let', 'for(let i=0;i<3;i++)x', 'for(let e=0;e<3;e++)x'),
    ('for-in-no-var', 'for(a in b);', 'for(a in b);'),
    ('in-grouping', 'if((a))while((b));', 'if(a)for(;b;);'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in STATEMENT_FORMS],
    ids=[c[0] for c in STATEMENT_FORMS],
)
def test_js_statement_forms(run_prog, js_in, expected):
    """Switch, try/catch/finally, labels, with, for-in/of, do-while and return forms lose whitespace and empty statements."""
    # CATCHES: an unused catch binding is dropped, do{}while becomes do;while, continue in a for-of body collapses to the empty statement, return undefined/void 0 vanish entirely, and a labeled block is reduced to its labeled statement.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
NUMBER_BASES = [
    ('num-binary', '0b1001', '9'),
    ('num-binary-underscore', '0b10_01', '9'),
    ('num-binary-bigint', '0b10_01n', '9n'),
    ('num-octal', '0o11', '9'),
    ('num-octal-bigint', '0o11n', '9n'),
    ('num-hex', '0x0D', '13'),
    ('num-hex-lower', '0x0d', '13'),
    ('num-hex-bigint', '0x0dn', '13n'),
    ('num-hex-big-bigint', '0x53DCAA254718n', '0x53DCAA254718n'),
    ('num-underscore', '5_000', '5e3'),
    ('num-underscore-bigint', '5_000n', '5000n'),
    ('num-exp', '1e10', '1e10'),
    ('num-exp-neg', '1e-10', '1e-10'),
    ('bigint-decimal', 'x=3633527012648n', 'x=3633527012648n'),
    ('bigint-big-dec', 'x=18446744073709551616n', 'x=18446744073709551616n'),
    ('bigint-hex-kept', 'x=0xFFn', 'x=255n'),
    ('bigint-octal', 'x=0o7777777777n', 'x=1073741823n'),
    ('num-leading-dot', 'x=.5', 'x=.5'),
    ('num-trailing-dot', 'x=5.', 'x=5'),
    ('num-big-exp', 'x=100000', 'x=1e5'),
    ('num-frac-zeros', 'x=1.50', 'x=1.5'),
    ('num-zero-float', 'x=0.5', 'x=.5'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in NUMBER_BASES],
    ids=[c[0] for c in NUMBER_BASES],
)
def test_js_number_bases(run_prog, js_in, expected):
    """Binary, octal and hexadecimal literals are rewritten as the shorter decimal (or exponent) form, with underscores removed."""
    # CATCHES: 0b1001/0o11/0x0D all become 9/9/13, numeric separators vanish (5_000 -> 5e3), BigInt suffixes are preserved (13n), and a long hex BigInt stays hex when that is shorter.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
UNARY_AND_GROUPING = [
    ('unary-double-neg', 'a=!(!b)', 'a=!!b'),
    ('unary-plus-plus', '+ +x', '+ +x'),
    ('unary-minus-minus', '- -x', '- -x'),
    ('unary-minus-plus', '- +x', '-+x'),
    ('unary-minus-minus-postfix', 'a-- -b', 'a---b'),
    ('group-assoc-left', 'a=(b+c)+d', 'a=b+c+d'),
    ('group-assoc-right-kept', 'a=b+(c+d)', 'a=b+(c+d)'),
    ('group-mul-add', 'a=b*(c+d)', 'a=b*(c+d)'),
    ('group-pow-right', 'a=b**(c**d)', 'a=b**c**d'),
    ('group-pow-left-kept', 'a=(b**c)**d', 'a=(b**c)**d'),
    ('group-seq-call', 'a=(b,c)?.(d)', 'a=(b,c)?.(d)'),
    ('group-seq-and', '(a,b)&&c', 'a,b&&c'),
    ('group-false-pow', 'a=false**2', 'a=(!1)**2'),
    ('group-inc-pow', 'a=(++b)**2', 'a=++b**2'),
    ('group-neg-pow', 'a=(-5)**3', 'a=(-5)**3'),
    ('group-pow-neg-exp', 'a=5**(-3)', 'a=5**-3'),
    ('optchain-call', 'a=(b)?.(c,d)', 'a=b?.(c,d)'),
    ('optchain-after-seq', 'a=(b,c)?.(d)', 'a=(b,c)?.(d)'),
    ('nullish-grouping', 'a=(a??b)??(c??d)', 'a=a??b??c??d'),
    ('nullish-or-groups', 'a=(a||b)??(c||d)', 'a=(a||b)??(c||d)'),
    ('nullish-mixed', 'a=c&&(a??b)', 'a=c&&(a??b)'),
    ('in-relational', 'a < !--b', 'a<!--b'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in UNARY_AND_GROUPING],
    ids=[c[0] for c in UNARY_AND_GROUPING],
)
def test_js_unary_and_grouping(run_prog, js_in, expected):
    """Parentheses are added or removed according to operator precedence and associativity, and double negation is collapsed."""
    # CATCHES: (b+c)+d flattens but b+(c+d) keeps its group, ** groups to the right only, !(!b) becomes !!b, and - -x keeps its space while - +x does not.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
CONDITIONAL_AND_NULLISH = [
    ('cond-same-branches', 'a=b?c:c', 'a=(b,c)'),
    ('cond-true', 'x=true?a:b', 'x=a'),
    ('cond-false', 'x=false?a:b', 'x=b'),
    ('cond-same-test', 'x=a?a:b', 'x=a||b'),
    ('cond-nullish-ne', 'x=a!=null?a:b', 'x=a??b'),
    ('cond-nullish-eqnull', 'x=null==a?a:b', 'x=a==null?a:b'),
    ('cond-nullish-strict-undef', 'x=a===undefined?b:a', 'x=a===0[0]?b:a'),
    ('cond-and-form', 'x=a?b:false', 'x=!!a&&b'),
    ('cond-or-form', 'x=a?true:b', 'x=!!a||b'),
    ('ternary-chain', 'x=a?b:c?d:e', 'x=a?b:c?d:e'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in CONDITIONAL_AND_NULLISH],
    ids=[c[0] for c in CONDITIONAL_AND_NULLISH],
)
def test_js_conditional_and_nullish(run_prog, js_in, expected):
    """Conditional expressions are rewritten to &&/||/?? when one branch is constant or equal to the test."""
    # CATCHES: a!=null?a:b becomes a??b but null==a?a:b does NOT (operand order matters), a?a:b becomes a||b, equal branches become a comma sequence, and true/false tests fold to the taken branch.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
BOOLEAN_AND_UNDEFINED_FOLDING = [
    ('bool-not-one', 'x=!1', 'x=!1'),
    ('bool-not-zero', 'x=!0', 'x=!0'),
    ('bool-if-notzero', 'if(!0){a()}', 'a()'),
    ('bool-if-notone-else', 'if(!1)a++;else b', 'b'),
    ('undef-if', 'if(undefined){a()}', '0[0]'),
    ('undef-assign', 'x=undefined', 'x=0[0]'),
    ('undef-void0', 'x=void 0', 'x=0[0]'),
    ('undef-eqnull-known', 'var x;x==null', 'var x;x==null'),
    ('undef-eqnull-unknown', 'x==null', 'x==null'),
    ('undef-loose-eq-undef', 'x==undefined', 'x==null'),
    ('undef-strict-eq-undef', 'x===undefined', 'x===0[0]'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in BOOLEAN_AND_UNDEFINED_FOLDING],
    ids=[c[0] for c in BOOLEAN_AND_UNDEFINED_FOLDING],
)
def test_js_boolean_and_undefined_folding(run_prog, js_in, expected):
    """Constant conditions fold away their statements and ``undefined`` is shortened to ``0[0]``."""
    # CATCHES: if(!0){a()} reduces to just a(), if(!1)a++;else b to b, undefined and void 0 both become 0[0], and x==undefined becomes x==null while x===undefined keeps strict equality with 0[0].
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
STRING_QUOTES_AND_CONCAT = [
    ('quote-single', "x='abc'", 'x="abc"'),
    ('quote-double', 'x="abc"', 'x="abc"'),
    ('quote-single-has-double', 'x=\'a"b\'', 'x=\'a"b\''),
    ('quote-double-has-single', 'x="a\'b"', 'x="a\'b"'),
    ('quote-just-double', 'x="\'"', 'x="\'"'),
    ('concat-two-strings', 'x="a"+"b"', 'x="ab"'),
    ('concat-mixed', 'x="a"+b', 'x="a"+b'),
    ('concat-single-double', 'x=\'a\'+"b"', 'x="ab"'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in STRING_QUOTES_AND_CONCAT],
    ids=[c[0] for c in STRING_QUOTES_AND_CONCAT],
)
def test_js_string_quotes_and_concat(run_prog, js_in, expected):
    """String literals prefer double quotes and adjacent string constants are merged."""
    # CATCHES: 'abc' is rewritten to "abc" but a string containing a double quote keeps single quotes, and 'a'+"b" merges into "ab" while "a"+b cannot merge.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
STRING_ESCAPES = [
    ('escape-hex', 'x="\\x41"', 'x="A"'),
    ('escape-unicode', 'x="\\u0041"', 'x="A"'),
    ('escape-kept', 'x="a\\tb"', 'x="a\tb"'),
    ('esc-newline', "x='\\n'", 'x=`\n`'),
    ('esc-cr', 'x="\\r"', 'x="\\r"'),
    ('esc-nul', 'x="\\0"', 'x="\\0"'),
    ('esc-del', 'x="\\x7f"', 'x="\x7f"'),
    ('esc-braced-unicode', 'x="\\u{41}"', 'x="A"'),
    ('esc-emoji', 'x="\\u{1F600}"', 'x="😀"'),
    ('esc-single-in-single', "x='\\''", 'x="\'"'),
    ('esc-backslash', 'x="\\\\"', 'x="\\\\"'),
    ('esc-octal-digit', 'x="\\7"', 'x="\x07"'),
    ('esc-v', 'x="\\v"', 'x="\x0b"'),
    ('esc-b', 'x="\\b"', 'x="\x08"'),
    ('esc-f', 'x="\\f"', 'x="\x0c"'),
    ('esc-unicode-5hex', 'x="\\u00411"', 'x="A1"'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in STRING_ESCAPES],
    ids=[c[0] for c in STRING_ESCAPES],
)
def test_js_string_escapes(run_prog, js_in, expected):
    """Escape sequences are decoded to raw bytes whenever that is shorter, and kept otherwise."""
    # CATCHES: \x41/\u0041/\u{41} decode to A, \t/\v/\b/\f/\7 become raw control bytes, a newline escape inside a string becomes a raw newline in backticks, but \r, \0 and \\ stay escaped.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
TEMPLATE_LITERALS = [
    ('tpl-plain', 'x=`abc`', 'x=`abc`'),
    ('tpl-subst', 'x=`a${b}c`', 'x=`a${b}c`'),
    ('tpl-single-quote', "x=`a'b`", "x=`a'b`"),
    ('tpl-escaped-dollar', 'x=`a\\${b}`', 'x=`a\\${b}`'),
    ('tpl-newline', 'x=`a\nb`', 'x=`a\nb`'),
    ('tpl-esc-tab', 'x=`a\\tb`', 'x=`a\tb`'),
    ('tpl-esc-newline', 'x=`a\\nb`', 'x=`a\nb`'),
    ('tpl-tagged', 'x=a`b${c}d`', 'x=a`b${c}d`'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in TEMPLATE_LITERALS],
    ids=[c[0] for c in TEMPLATE_LITERALS],
)
def test_js_template_literals(run_prog, js_in, expected):
    """Template literals are kept as templates even without substitutions."""
    # CATCHES: `abc` is NOT converted to a string literal, escapes inside templates decode to raw bytes like in strings, and the escaped dollar sign \${ is preserved so no substitution is introduced.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
REGEXP_LITERALS = [
    ('re-plain', 'x=/a/g', 'x=/a/g'),
    ('re-group', 'x=/a(?:b)/g', 'x=/a(?:b)/g'),
    ('re-hex-escape', 'x=/\\x41/', 'x=/\\x41/'),
    ('re-charclass', 'x=/[A-Z]/', 'x=/[A-Z]/'),
    ('re-instanceof', '/a/ instanceof b', '/a/ instanceof b'),
    ('re-flag-order', 'x=/a/ig', 'x=/a/ig'),
    ('re-flags-gi', 'x=/a/gi', 'x=/a/gi'),
    ('re-escaped-dot', 'x=/a\\./', 'x=/a\\./'),
    ('re-escaped-dash', 'x=/a\\-/', 'x=/a-/'),
    ('re-brace-quant', 'x=/a{1,}/', 'x=/a{1,}/'),
    ('re-brace-exact', 'x=/a{1}/', 'x=/a{1}/'),
    ('re-alt', 'x=/a|b/', 'x=/a|b/'),
    ('re-charclass-digit', 'x=/[\\d]/', 'x=/[\\d]/'),
    ('re-trailing-backslash', 'x=/a\\\\/', 'x=/a\\\\/'),
    ('re-empty-class', 'x=/[]/', 'x=/[]/'),
    ('re-neg-class', 'x=/[^a]/', 'x=/[^a]/'),
    ('regexp-plus', '/a/ + b', '/a/+b'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in REGEXP_LITERALS],
    ids=[c[0] for c in REGEXP_LITERALS],
)
def test_js_regexp_literals(run_prog, js_in, expected):
    """Regexp literals keep their body except for escapes that are not special in that position."""
    # CATCHES: /a\-/ loses its needless escape to /a-/ while /a\./, /[\d]/ and flag order are preserved untouched, and a regexp operand still needs its space before instanceof.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
IMPORT_EXPORT = [
    ('import-bare', 'import "path"', 'import"path"'),
    ('import-default', 'import x from "path"', 'import x from"path"'),
    ('import-namespace', 'import * as b from "path"', 'import*as b from"path"'),
    ('anchored-empty-import-dropped', 'import {} from "path";x=1', 'x=1'),
    ('import-named', 'import {a as b} from "path"', 'import{a as b}from"path"'),
    ('import-named-two', 'import {a as b, c} from "path"', 'import{a as b,c}from"path"'),
    ('import-default-namespace', 'import x, * as b from "path"', 'import x,*as b from"path"'),
    ('import-default-named', 'import x, {a as b, c} from "path"', 'import x,{a as b,c}from"path"'),
    ('export-star', 'export * from "path"', 'export*from"path"'),
    ('export-star-as', 'export * as ns from "path"', 'export*as ns from"path"'),
    ('export-named-from', 'export {a as b} from "path"', 'export{a as b}from"path"'),
    ('export-named', 'export {a as b, c}', 'export{a as b,c}'),
    ('export-var', 'export var a = b', 'export var a=b'),
    ('export-default', 'export default a = b', 'export default a=b'),
    ('export-default-func', 'export default function a(){};c=d', 'export default function(){}c=d'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in IMPORT_EXPORT],
    ids=[c[0] for c in IMPORT_EXPORT],
)
def test_js_import_export(run_prog, js_in, expected):
    """Import and export statements lose whitespace around their clause separators, and an empty import clause disappears entirely."""
    # CATCHES: import {} from "path" leaves no trace (anchored here with a following statement), import*as b keeps the spaces around as, and export default drops the function name.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
DEAD_CODE_ELIMINATION = [
    ('anchored-dead-let-block-dropped', 'if(true){let b};x=1', 'x=1'),
    ('anchored-dead-let-init-dropped', 'if(true){let b=5};x=1', 'x=1'),
    ('dead-if-true-const-expr', 'if(true){const b=c}', 'c'),
    ('dead-if-true-const-member', 'if(true){const b=c.d}', 'c.d'),
    ('dead-if-false', 'if(false)a++;else b', 'b'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in DEAD_CODE_ELIMINATION],
    ids=[c[0] for c in DEAD_CODE_ELIMINATION],
)
def test_js_dead_code_elimination(run_prog, js_in, expected):
    """Statements with a constant truthy test keep only their side effects, and a falsy test keeps only the else branch."""
    # CATCHES: if(true){let b} vanishes entirely (anchored with a trailing statement so the empty result is observable), if(true){const b=c} reduces to c, and if(false)a++;else b reduces to b.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
SEQUENCES_AND_ASI = [
    ('seq-assign', 'x=(a,b)', 'x=(a,b)'),
    ('seq-group-add', 'a=(b,c)+3', 'a=(b,c)+3'),
    ('seq-iife', '(function(){})(),x=5,f=6', '(function(){})(),x=5,f=6'),
    ('seq-return', 'function f(){return a,b}', 'function f(){return a,b}'),
    ('seq-if-test', 'x=(a,b)?c:d', 'x=(a,b)?c:d'),
    ('seq-throw', 'throw a,b', 'throw a,b'),
    ('seq-switch-case', 'switch(a){case b:(c,d)}', 'switch(a){case b:c,d}'),
    ('endsif-semicolon', 'if(a)b;(c)', 'a&&b,c'),
    ('endsif-else', 'if(a)b;else c;(d)', 'a?b:c,d'),
    ('endsif-while', 'while(a)b;(c)', 'for(;a;)b;c'),
    ('ends-if-call', 'if(a)b\n(c)', 'a&&b(c)'),
    ('func-expr-grouped', 'x=(function(){})', 'x=function(){}'),
    ('func-iife-grouped', 'x=(function(){}())', 'x=function(){}()'),
    ('func-iife', 'x=(function(){})()', 'x=function(){}()'),
    ('func-expr-member', 'x=(function(){}).a', 'x=function(){}.a'),
    ('func-expr-not', '(function(){})', '!function(){}'),
    ('async-func-expr-not', '(async function(){})', '!async function(){}'),
    ('let-expr', '(let [a])', '!let[a]'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in SEQUENCES_AND_ASI],
    ids=[c[0] for c in SEQUENCES_AND_ASI],
)
def test_js_sequences_and_asi(run_prog, js_in, expected):
    """Statement sequences merge with commas, parentheses around sequence expressions are dropped where legal, and expression statements get grouped as expressions."""
    # CATCHES: x=1;y=2 becomes x=1,y=2, a bare (function(){}) statement is negated to stay an expression while an assigned one is not, and case b:(c,d) drops the parentheses that a re-implementation might keep.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
VAR_DECLARATIONS = [
    ('var-two-empty', 'var a;var b', 'var a,b'),
    ('var-then-use', 'var a;var b;a,b', 'var a,b;a,b'),
    ('var-single-empty', 'var a', 'var a'),
    ('var-let-mix', 'var a=1;let b=2', 'var a=1;let b=2'),
    ('var-in-if-block', 'if(a){var b}', 'if(a)var b'),
    ('var-in-while-block', 'while(a){var b}', 'for(var b;a;);'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in VAR_DECLARATIONS],
    ids=[c[0] for c in VAR_DECLARATIONS],
)
def test_js_var_declarations(run_prog, js_in, expected):
    """Adjacent var declarations merge into one, and a var inside a loop body is hoisted into the loop header."""
    # CATCHES: var a;var b becomes var a,b, while(a){var b} becomes for(var b;a;);, but var and let declarations never merge with each other.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


# (id, input JS, expected output JS)
PARAMS_ARGUMENTS_AND_SPACING = [
    ('params-default-rest', 'function f(a=1,...b){}', 'function f(e=1,...t){}'),
    ('args-trailing-comma', 'f(a,)', 'f(a)'),
    ('args-spread', 'f(...a)', 'f(...a)'),
    ('args-spread-mid', 'f(a,...b,c)', 'f(a,...b,c)'),
    ('array-spread', 'x=[...a,...b]', 'x=[...a,...b]'),
    ('ident-in', 'x=a in b', 'x=a in b'),
    ('ident-instanceof', 'x=a instanceof b', 'x=a instanceof b'),
    ('ident-await', 'async function f(){x=await y}', 'async function f(){x=await y}'),
    ('ident-new-noargs', 'x=new a', 'x=new a'),
    ('ident-typeof-paren', 'x=typeof(a)', 'x=typeof a'),
    ('new-target', 'function f(){x=new.target}', 'function f(){x=new.target}'),
    ('new-nested', 'x=new new a(b)', 'x=new new a(b)'),
    ('exponent-assign', 'x**=2', 'x**=2'),
    ('logic-assign', 'x||=y', 'x||=y'),
    ('nullish-assign', 'x??=y', 'x??=y'),
    ('optchain-elem', 'x=a?.[b]', 'x=a?.[b]'),
    ('optchain-deep', 'x=a?.b.c', 'x=a?.b.c'),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in PARAMS_ARGUMENTS_AND_SPACING],
    ids=[c[0] for c in PARAMS_ARGUMENTS_AND_SPACING],
)
def test_js_params_arguments_and_spacing(run_prog, js_in, expected):
    """Parameter lists, call arguments and the tokens that need a space after an identifier are normalised."""
    # CATCHES: a trailing comma in a call is deleted, typeof(a) loses its parentheses, new.target keeps its dot, and a in b / a instanceof b keep exactly one space where a regexp operand would need none.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


