"""CLI plumbing: stdin/stdout routing, --type resolution, usage errors, and the
informational flags (--help/--list/--version/--verbose/--quiet).

Expectations below were recorded by running the reference binary.
"""

import re

import pytest

from conftest import FINISHED_RE, stats_line_re

CSS_IN = "a { color: red; }\n"
CSS_OUT = "a{color:red}"

# The exact --list table, shared by the loud and quiet list tests.
LIST_TABLE = (
    "asp          text/asp\n"
    "css          text/css\n"
    "ejs          text/x-ejs-template\n"
    "gohtml       text/x-go-template\n"
    "handlebars   text/x-handlebars-template\n"
    "htm          text/html\n"
    "html         text/html\n"
    "js           application/javascript\n"
    "json         application/json\n"
    "mjs          application/javascript\n"
    "mustache     text/x-mustache-template\n"
    "php          application/x-httpd-php\n"
    "rss          application/rss+xml\n"
    "svg          image/svg+xml\n"
    "tmpl         text/x-template\n"
    "webmanifest  application/manifest+json\n"
    "xhtml        application/xhtml+xml\n"
    "xml          text/xml\n"
)

# (id, --type value, stdin, expected stdout)
TYPE_ROUTES = [
    ("css", "css", CSS_IN, CSS_OUT),
    ("mime", "text/css", CSS_IN, CSS_OUT),
    ("js", "application/javascript", "var a = 1\n", "var a=1"),
    ("js-x", "application/x-javascript", "var a = 1\n", "var a=1"),
    ("js-ecma", "text/ecmascript", "var a = 1\n", "var a=1"),
    ("js-live", "text/livescript", "var a = 1\n", "var a=1"),
    ("json-manifest", "application/manifest+json", '{"a": 1}\n', '{"a":1}'),
    ("xml-rss", "application/rss+xml", "<a >x</a>\n", "<a>x</a>"),
]


class TestStdinStdout:
    @pytest.mark.parametrize(
        "type_value,stdin_data,expected",
        [(t, s, e) for _i, t, s, e in TYPE_ROUTES],
        ids=[i for i, _t, _s, _e in TYPE_ROUTES],
    )
    def test_stdin_type_routing(self, run_prog, type_value, stdin_data, expected):
        """Reading from stdin with --type routes the bytes to the right minifier."""
        # CATCHES: mimetype routing incl. regexp-based JS mimetypes like
        # text/ecmascript and application/manifest+json for JSON.
        res = run_prog(["--type", type_value], stdin=stdin_data)
        assert res.rc == 0
        assert res.out == expected
        assert res.err == ""

    def test_stdin_dash_input(self, run_prog):
        """An input argument of ``-`` explicitly selects stdin."""
        # CATCHES: "-" is honoured as the stdin input name, not as a filename.
        res = run_prog(["-", "--type", "css"], stdin=CSS_IN)
        assert res.rc == 0
        assert res.out == CSS_OUT
        assert res.err == ""

    def test_type_equals_form(self, run_prog):
        """``--type=css`` (equals form) works like ``--type css``."""
        # CATCHES: the argp-style ``--opt=value`` syntax must be accepted.
        res = run_prog(["--type=css"], stdin=CSS_IN)
        assert res.rc == 0
        assert res.out == CSS_OUT

    @pytest.mark.parametrize("args", [[], ["--type", ""]], ids=["no-type", "empty-type"])
    def test_stdin_requires_type(self, run_prog, args):
        """Stdin without a non-empty --type fails before reading any bytes."""
        # CATCHES: stdin has no filename extension, so the CLI must refuse to
        # guess the mimetype instead of copying input through unminified.
        res = run_prog(args, stdin="a{}")
        assert res.rc == 1
        assert res.out == ""
        assert res.err == "ERROR: must specify --type for stdin\n"

    @pytest.mark.parametrize("bad", ["nosuch", "CSS"], ids=["unknown-word", "uppercase"])
    def test_unknown_filetype(self, run_prog, bad):
        """A --type word that is not a known filetype or mimetype is rejected."""
        # CATCHES: the error prints the emptied value ("unknown filetype ")
        # because the lookup clobbers the name before formatting it.
        res = run_prog(["--type", bad], stdin="a{}")
        assert res.rc == 1
        assert res.out == ""
        assert res.err == "ERROR: unknown filetype \n"

    @pytest.mark.parametrize("mime", ["text/nosuch", "foo/bar"], ids=["text-slash", "other-slash"])
    def test_unknown_mimetype_echoes_input(self, run_prog, mime):
        """A well-formed but minifier-less mimetype fails and echoes the input."""
        # CATCHES: on minify failure the original bytes are still written to
        # stdout while the exit code signals failure.
        res = run_prog(["--type", mime], stdin="a{}")
        assert res.rc == 1
        assert res.out == "a{}"
        assert res.err == "ERROR: cannot minify -: minifier does not exist for mimetype\n"


class TestFileInputs:
    def test_file_to_stdout(self, run_prog):
        """A single file with no -o prints only the minified bytes."""
        # CATCHES: the progress-stats line is suppressed entirely when the
        # destination is stdout, so stdout is exactly the minified content.
        res = run_prog(["a.css"], files={"a.css": CSS_IN})
        assert res.rc == 0
        assert res.out == CSS_OUT
        assert res.err == ""

    def test_missing_input_file_is_logged_but_succeeds(self, run_prog):
        """A missing input prints an ERROR but still exits 0."""
        # CATCHES: stat failures are per-input and do not fail the whole run,
        # unlike mimetype errors which exit 1.
        res = run_prog(["nope.css"])
        assert res.rc == 0
        assert res.out == ""
        assert res.err == "ERROR: stat nope.css: no such file or directory\n"

    def test_missing_input_quiet(self, run_prog):
        """--quiet silences the missing-file ERROR while keeping rc 0."""
        # CATCHES: -q disables the error logger, not the exit status logic
        # nor the stdout data stream (a real file still prints its bytes).
        control = run_prog(["-q", "a.css"], files={"a.css": CSS_IN})
        assert control.rc == 0
        assert control.out == CSS_OUT
        res = run_prog(["-q", "nope.css"])
        assert res.rc == 0
        assert res.out == ""
        assert res.err == ""

    def test_unknown_extension(self, run_prog):
        """A file whose extension maps to no filetype exits 1 with a hint."""
        # CATCHES: extension inference failure names the file and suggests
        # --type explicitly.
        res = run_prog(["a.xyz"], files={"a.xyz": "x"})
        assert res.rc == 1
        assert res.out == ""
        assert res.err == "ERROR: cannot infer mimetype from extension in a.xyz, set --type explicitly\n"

    def test_unknown_extension_with_type(self, run_prog):
        """--type bypasses extension inference for arbitrary filenames."""
        # CATCHES: with an explicit --type the file is minified even though
        # its extension is unknown.
        res = run_prog(["--type", "css", "a.xyz"], files={"a.xyz": CSS_IN})
        assert res.rc == 0
        assert res.out == CSS_OUT

    def test_mix_stdin_and_file(self, run_prog):
        """A "-" input alongside real files is rejected."""
        # CATCHES: stdin cannot be mixed with file inputs; the CLI refuses
        # instead of silently dropping one of them.
        res = run_prog(["--type", "css", "a.css", "-"], files={"a.css": "a{}"}, stdin="a{}")
        assert res.rc == 1
        assert res.out == ""
        assert res.err == "ERROR: cannot mix files and stdin as input\n"

    def test_two_files_to_stdout_need_bundle(self, run_prog):
        """Multiple files with a stdout destination require --bundle."""
        # CATCHES: without --bundle the CLI cannot know how to join the files
        # on stdout and errors out before minifying anything.
        res = run_prog(["a.css", "b.css"], files={"a.css": "a{}", "b.css": "b{}"})
        assert res.rc == 1
        assert res.out == ""
        assert res.err == "ERROR: must specify --bundle for multiple input files with stdout destination\n"

    def test_empty_input(self, run_prog):
        """Empty stdin and empty files minify to empty output with rc 0."""
        # CATCHES: empty input is a successful no-op, not an error, while
        # the very same pipeline fed real content emits the minified bytes.
        control = run_prog(["--type", "css"], stdin=CSS_IN)
        assert control.rc == 0
        assert control.out == CSS_OUT
        res = run_prog(["--type", "css"], stdin="")
        assert res.rc == 0
        assert res.out == ""
        assert res.err == ""
        res = run_prog(["a.css"], files={"a.css": ""})
        assert res.rc == 0
        assert res.out == ""

    def test_bom_and_crlf(self, run_prog):
        """A UTF-8 BOM is preserved and a trailing CRLF is dropped."""
        # CATCHES: the CSS minifier keeps the BOM byte-for-byte but strips
        # trailing whitespace/newlines.
        res = run_prog(["--type", "css"], stdin="﻿a{color:red}\r\n")
        assert res.rc == 0
        assert res.out == "﻿a{color:red}"


class TestConflictingFlags:
    @pytest.mark.parametrize(
        "args,files,stdin_data,expected_err",
        [
            (
                ["--watch", "--type", "css"],
                None,
                "a{}",
                "ERROR: --watch doesn't work with stdin and stdout, specify input and output\n",
            ),
            (
                ["--sync", "a.css"],
                {"a.css": "a{}"},
                None,
                "ERROR: --sync doesn't work with stdin and stdout, specify input and output\n",
            ),
            (
                ["--bundle", "--type", "css"],
                None,
                "a{}",
                "ERROR: --bundle doesn't work with stdin, specify input\n",
            ),
            (
                ["--recursive", "--type", "css"],
                None,
                "a{}",
                "ERROR: --recursive doesn't work with stdin, specify input\n",
            ),
            (
                ["--inplace", "--type", "css"],
                None,
                "a{}",
                "ERROR: --inplace doesn't work with stdin, specify input\n",
            ),
            (
                ["--inplace", "-o", "o.css", "a.css"],
                {"a.css": "a{}"},
                None,
                "ERROR: cannot specify both --inplace and --output\n",
            ),
            (
                ["--bundle", "--inplace", "a.js", "b.js"],
                {"a.js": "var a=1", "b.js": "var b=2"},
                None,
                "ERROR: --bundle cannot be used together with --inplace\n",
            ),
            (
                ["--recursive", "sub"],
                {"sub/a.css": "a{}"},
                None,
                "ERROR: --recursive doesn't work with stdout, specify output or use --bundle\n",
            ),
            (
                ["--preserve", "mode", "--type", "css"],
                None,
                "a{}",
                "ERROR: --preserve cannot be used together with stdin, stdout or --inplace\n",
            ),
            (
                ["--sync", "--type", "css", "-o", "out", "sub"],
                {"sub/a.css": "a{}"},
                None,
                "ERROR: must specify either --sync or --type\n",
            ),
            (
                ["--type", "css", "--url", ":"],
                None,
                "a{}",
                'ERROR: parse ":": missing protocol scheme\n',
            ),
        ],
        ids=[
            "watch-stdin",
            "sync-stdout",
            "bundle-stdin",
            "recursive-stdin",
            "inplace-stdin",
            "inplace-output",
            "bundle-inplace",
            "recursive-stdout",
            "preserve-stdout",
            "sync-plus-type",
            "url-invalid",
        ],
    )
    def test_flag_conflicts(self, run_prog, args, files, stdin_data, expected_err):
        """Each impossible flag combination exits 1 with its exact message."""
        # CATCHES: every conflict is detected before any minification happens,
        # so nothing is written to stdout and each error text is distinct.
        res = run_prog(args, files=files, stdin=stdin_data)
        assert res.rc == 1
        assert res.out == ""
        assert res.err == expected_err

    def test_quiet_suppresses_conflict_error(self, run_prog):
        """-q hides even fatal flag-conflict messages but keeps rc 1."""
        # CATCHES: quiet mode replaces the loggers with a discard writer; the
        # failure exit code still propagates.
        res = run_prog(["-qr", "sub"], files={"sub/a.css": "a{}"})
        assert res.rc == 1
        assert res.out == ""
        assert res.err == ""


class TestInfoFlags:
    def test_version(self, run_prog):
        """--version prints the exact version banner."""
        # CATCHES: version string and trailing newline are fixed output.
        res = run_prog(["--version"])
        assert res.rc == 0
        assert res.out == "minify 1765945\n"
        assert res.err == ""

    def test_version_quiet(self, run_prog):
        """--quiet suppresses the --version banner but keeps rc 0."""
        # CATCHES: even the version line honours -q, while the same flag
        # without -q prints the full banner on stdout.
        loud = run_prog(["--version"])
        quiet = run_prog(["--version", "-q"])
        assert loud.rc == 0 and quiet.rc == 0
        assert loud.out == "minify 1765945\n"
        assert quiet.out == ""
        assert quiet.err == ""

    def test_list(self, run_prog):
        """--list prints the exact extension-to-mimetype table."""
        # CATCHES: the table is sorted by extension and column-aligned with
        # two spaces after the longest name (webmanifest).
        res = run_prog(["--list"])
        assert res.rc == 0
        assert res.out == LIST_TABLE
        assert res.err == ""

    def test_list_quiet(self, run_prog):
        """--quiet suppresses the --list output."""
        # CATCHES: -l with -q prints nothing while the same flag without
        # -q prints the entire extension table, and both runs succeed.
        loud = run_prog(["--list"])
        quiet = run_prog(["-q", "--list"])
        assert loud.rc == 0 and quiet.rc == 0
        assert loud.out == LIST_TABLE
        assert quiet.out == ""
        assert quiet.err == ""

    USAGE_TAIL = (
        "\nOptions:\n"
        "  -a, --all                   Minify all files, including hidden files and files in hidden directories\n"
        "  -b, --bundle                Bundle files by concatenation into a single file\n"
        "      --css-precision int     Number of significant digits to preserve in numbers, 0 is all\n"
        "      --css-version int       CSS version to toggle supported optimizations (e.g. 2), by default 0 is the latest version\n"
        "      --exclude []string      Path exclusion pattern, excludes paths from being processed\n"
        "      --ext map[string]string Filename extension mapping to filetype (eg. css or text/css)\n"
        "  -h, --help                  Help\n"
        "      --html-keep-comments    Preserve all comments\n"
        "      --html-keep-conditional-comments\n"
        "                              Preserve all IE conditional comments (DEPRECATED)\n"
        "      --html-keep-default-attrvals\n"
        "                              Preserve default attribute values\n"
        "      --html-keep-document-tags\n"
        "                              Preserve html, head and body tags\n"
        "      --html-keep-end-tags    Preserve all end tags\n"
        "      --html-keep-quotes      Preserve quotes around attribute values\n"
        "      --html-keep-special-comments\n"
        "                              Preserve all IE conditionals and SSI tags\n"
        "      --html-keep-whitespace  Preserve whitespace characters but still collapse multiple into one\n"
        "  -i, --inplace               Minify input files in-place instead of setting output\n"
        "      --include []string      Path inclusion pattern, includes paths previously excluded\n"
        "      --js-keep-var-names     Preserve original variable names\n"
        "      --js-precision int      Number of significant digits to preserve in numbers, 0 is all\n"
        "      --js-version int        ECMAScript version to toggle supported optimizations (e.g. 2019, 2020), by default 0 is the latest version\n"
        "      --json-keep-numbers     Preserve original numbers instead of minifying them\n"
        "      --json-precision int    Number of significant digits to preserve in numbers, 0 is all\n"
        "  -l, --list                  List all accepted filetypes\n"
        "      --match []string        Filename matching pattern, only matching filenames are processed\n"
        "      --mime string           Mimetype (eg. text/css), optional for input filenames (DEPRECATED, use --type)\n"
        "  -o, --output string         Output file or directory, leave blank to use stdout\n"
        "  -p, --preserve='[mode ownership timestamps]' []string\n"
        "                              Preserve options (mode, ownership, timestamps, links, all)\n"
        "  -q, --quiet                 Quiet mode to suppress all output\n"
        "  -r, --recursive             Recursively minify directories\n"
        "  -s, --sync                  Copy all files to destination directory and minify when filetype matches\n"
        "      --svg-keep-comments     Preserve all comments\n"
        "      --svg-keep-namespaces []string\n"
        "                              Namespaces to keep, besides xlink\n"
        "      --svg-precision int     Number of significant digits to preserve in numbers, 0 is all\n"
        "      --type string           Filetype (eg. css or text/css), optional when specifying inputs\n"
        "      --url string            URL of file to enable URL minification\n"
        "  -v, --verbose int           Verbose mode, set twice for more verbosity\n"
        "      --version               Version\n"
        "  -w, --watch                 Watch files and minify upon changes\n"
        "      --xml-keep-whitespace   Preserve whitespace characters but still collapse multiple into one\n"
        "\nArguments:\n"
        "  inputs    Input files or directories, leave blank to use stdin\n"
    )

    USAGE_FIRST_LINE_RE = re.compile(r"^Usage: \S+ \[options\] inputs\.\.\.$")

    def test_help(self, run_prog):
        """--help prints the full usage to stdout and exits 0."""
        # CATCHES: the complete option list, their order, the wrapping of long
        # options, and the trailing Arguments section are pinned byte-for-byte
        # (modulo the program name on the first line).
        res = run_prog(["--help"])
        assert res.rc == 0
        assert res.err == ""
        first_line, rest = res.out.split("\n", 1)
        assert self.USAGE_FIRST_LINE_RE.match(first_line)
        assert rest == self.USAGE_TAIL

    def test_unknown_option(self, run_prog):
        """An unknown option exits 2 with the error on stderr and usage on stdout."""
        # CATCHES: parse errors use exit code 2 (not 1), print the reason to
        # stderr followed by a blank line, and dump the usage to stdout.
        res = run_prog(["--nope"])
        assert res.rc == 2
        assert res.err == "unknown option --nope\n\n"
        first_line, rest = res.out.split("\n", 1)
        assert self.USAGE_FIRST_LINE_RE.match(first_line)
        assert rest == self.USAGE_TAIL

    def test_mime_deprecated(self, run_prog):
        """--mime still works but logs a deprecation error on stderr."""
        # CATCHES: the legacy flag is applied (CSS is minified) and the exact
        # deprecation text naming both flags goes to stderr with rc 0.
        res = run_prog(["--mime", "text/css"], stdin=CSS_IN)
        assert res.rc == 0
        assert res.out == CSS_OUT
        assert res.err == "ERROR: deprecated use of '--mime text/css', please use '--type text/css' instead\n"

    def test_quiet_suppresses_minify_errors(self, run_prog):
        """-q silences minify errors on stderr while the input is still echoed."""
        # CATCHES: with -q a broken JSON document exits 1 with the original
        # bytes on stdout and an empty stderr.
        res = run_prog(["-q", "--type", "json"], stdin="{")
        assert res.rc == 1
        assert res.out == "{"
        assert res.err == ""


class TestVerbosity:
    def test_verbose_info(self, run_prog):
        """-v adds an INFO timing line on stderr to the normal stats output."""
        # CATCHES: the stats line stays on stdout while the INFO line goes to
        # stderr, and only its duration varies between runs.
        res = run_prog(["-v", "a.css", "-o", "out.css"], files={"a.css": CSS_IN})
        assert res.rc == 0
        assert stats_line_re("a.css", "out.css").match(res.out.splitlines()[0])
        err_lines = res.err.splitlines()
        assert len(err_lines) == 1
        assert FINISHED_RE.match(err_lines[0])

    def test_verbose_debug_file(self, run_prog):
        """-vv traces mimetype inference and the output file on stderr."""
        # CATCHES: two DEBUG lines (inference + destination) precede the INFO
        # line; the destination text repeats the -o argument verbatim.
        res = run_prog(["-vv", "a.css", "-o", "out.css"], files={"a.css": CSS_IN})
        assert res.rc == 0
        assert stats_line_re("a.css", "out.css").match(res.out.splitlines()[0])
        err_lines = res.err.splitlines()
        assert err_lines[0] == "DEBUG: infer mimetype from file extensions"
        assert err_lines[1] == "DEBUG: minify to output file out.css"
        assert FINISHED_RE.match(err_lines[2])
        assert len(err_lines) == 3

    def test_verbose_debug_stdin(self, run_prog):
        """-vv on stdin traces the explicit mimetype, stdin and stdout."""
        # CATCHES: with --type the first DEBUG line reports the mimetype in
        # use instead of inference, followed by stdin/stdout trace lines.
        res = run_prog(["-vv", "--type", "css"], stdin="a{}")
        assert res.rc == 0
        assert res.out == ""
        err_lines = res.err.splitlines()
        assert err_lines[0] == "DEBUG: use mimetype text/css"
        assert err_lines[1] == "DEBUG: minify from stdin"
        assert err_lines[2] == "DEBUG: minify to stdout"
        assert FINISHED_RE.match(err_lines[3])
        assert len(err_lines) == 4
