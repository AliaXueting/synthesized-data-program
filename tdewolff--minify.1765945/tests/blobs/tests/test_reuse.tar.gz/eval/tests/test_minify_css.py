"""CSS minification behaviour, mined from the repository's native css tests and
recorded from the reference binary via ``--type css`` on stdin.
"""

import pytest

# (id, input CSS, expected output CSS)
CSS_CASES = [
    ("hex-color", "a{color:#ff0000}", "a{color:red}"),
    ("named-color-case-kept", "a{color:RED}", "a{color:RED}"),
    ("property-lowercased", "a{COLOR:red}", "a{color:red}"),
    ("margin-collapse", "a{margin:0 0 0 0}", "a{margin:0}"),
    ("leading-zero-dropped", "a{width:0.50px}", "a{width:.5px}"),
    ("font-weight-numeric", "a{font-weight:bold}", "a{font-weight:700}"),
    ("url-unquoted", 'a{background:url("a.png")}', "a{background:url(a.png)}"),
    ("important-space-removed", "a{color:red !important}", "a{color:red!important}"),
    ("exponent-numbers", "a{width:100000px}", "a{width:1e5px}"),
    ("percent-zero-kept", "a{width:0%}", "a{width:0%}"),
    ("media-query-space", "@media ( min-width: 100px ){a{color:red}}", "@media(min-width:100px){a{color:red}}"),
    ("empty-rule-dropped", "a{}b{color:red}", "b{color:red}"),
    ("font-family-quotes", 'a{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif}',
     "a{font-family:helvetica neue,Helvetica,Arial,sans-serif}"),
    ("tolerant-unterminated-url", "a{background:url(}", "a{background:url(}}"),
    ("tolerant-stray-braces", "}}}}", "}}}}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in CSS_CASES],
    ids=[c[0] for c in CSS_CASES],
)
def test_css_minification(run_prog, css_in, expected):
    """The CSS minifier applies the recorded transformation to each snippet."""
    # CATCHES: pins colour shortening, margin collapsing, .5 leading-zero
    # removal, exponent numbers, quote removal in url(), !important spacing,
    # empty-rule removal and error tolerance, all byte-for-byte.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_css_version_2_keeps_important_space(run_prog):
    """--css-version 2 keeps the space before !important."""
    # CATCHES: version <= 2 targets old CSS where "!important" without a
    # preceding space was a hack; the default (3) removes the space.
    res = run_prog(["--type", "css", "--css-version", "2"], stdin="a{color:red !important}")
    assert res.rc == 0
    assert res.out == "a{color:red !important}"


def test_css_version_2_avoids_exponents(run_prog):
    """--css-version 2 writes 100000px instead of the 1e5px exponent form."""
    # CATCHES: for version <= 2 numbers are minified in decimal-only mode.
    res = run_prog(["--type", "css", "--css-version", "2"], stdin="a{width:100000px}")
    assert res.rc == 0
    assert res.out == "a{width:100000px}"


def test_css_precision(run_prog):
    """--css-precision rounds values to the given significant digits."""
    # CATCHES: 1.23456px with precision 2 becomes 1.2px, not 1.23px.
    res = run_prog(["--type", "css", "--css-precision", "2"], stdin="a{width:1.23456px}")
    assert res.rc == 0
    assert res.out == "a{width:1.2px}"


def test_css_url_option_strips_quotes_only(run_prog):
    """--url removes url() quotes but leaves an absolute http URL untouched."""
    # CATCHES: the URL minifier unquotes the argument; a same-host absolute
    # URL is not rewritten to a relative one in this configuration.
    res = run_prog(
        ["--type", "css", "--url", "http://example.com/sub/"],
        stdin='a{background:url("http://example.com/sub/glass.png")}',
    )
    assert res.rc == 0
    assert res.out == "a{background:url(http://example.com/sub/glass.png)}"
    assert res.err == ""
