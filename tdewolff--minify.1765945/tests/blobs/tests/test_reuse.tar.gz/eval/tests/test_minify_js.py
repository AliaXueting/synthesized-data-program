"""JavaScript minification behaviour, mined from the repository's native js
tests and recorded from the reference binary via ``--type js`` on stdin.
"""

import pytest

# (id, input JS, expected output JS)
JS_CASES = [
    ("hoist-into-for", "while(a);var b;var c", "for(var c,b;a;);"),
    ("hoist-into-for-body", "while(a){d()}var b;var c", "for(var c,b;a;)d()"),
    ("if-to-logical", "if(a){b()}", "a&&b()"),
    ("extra-semicolons", "a=1;;", "a=1"),
    ("crlf-joined", "var a = 1;\r\nvar b = 2;\r\n", "var a=1,b=2"),
    ("html-comment-line", "a=1\n<!--b\n", "a=1"),
    ("optional-chaining", "a?.b", "a?.b"),
]


@pytest.mark.parametrize(
    "js_in,expected", [(c[1], c[2]) for c in JS_CASES],
    ids=[c[0] for c in JS_CASES],
)
def test_js_minification(run_prog, js_in, expected):
    """The JS minifier applies the recorded transformation to each snippet."""
    # CATCHES: pins var-hoisting into for-statements, if-statement rewriting
    # to logical expressions, statement merging across CRLF, and HTML-style
    # comment removal inside JS.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


@pytest.mark.parametrize(
    "js_in,expected",
    [
        ("function f(){var foobar=1;return foobar}", "function f(){var e=1;return e}"),
        ("function hello(foobar){return foobar}", "function hello(e){return e}"),
        ("var f=function(a){return a}", "var f=function(e){return e}"),
    ],
    ids=["local-var", "argument", "function-expression-arg"],
)
def test_js_var_renaming(run_prog, js_in, expected):
    """Function-scoped variables and arguments are renamed to short names."""
    # CATCHES: renaming happens per function scope with short names like "e";
    # top-level vars are never renamed, unlike function-scoped ones.
    res = run_prog(["--type", "js"], stdin=js_in)
    assert res.rc == 0
    assert res.out == expected


def test_js_top_level_var_not_renamed(run_prog):
    """Top-level variables keep their names even when used."""
    # CATCHES: only function-scoped bindings are renamed; globals stay intact
    # because they may be referenced elsewhere.
    res = run_prog(["--type", "js"], stdin="var foobar=1;foobar++")
    assert res.rc == 0
    assert res.out == "var foobar=1;foobar++"


def test_js_keep_var_names(run_prog):
    """--js-keep-var-names disables function-scope renaming."""
    # CATCHES: with the flag the original identifier survives minification.
    res = run_prog(
        ["--type", "js", "--js-keep-var-names"],
        stdin="function f(){var foobar=1;return foobar}",
    )
    assert res.rc == 0
    assert res.out == "function f(){var foobar=1;return foobar}"


def test_js_nested_functions_rename_independently(run_prog):
    """Nested functions get their own short names, reusing letters per scope."""
    # CATCHES: inner and outer scopes may both use "t" without cliding; the
    # inner function name and its local are renamed separately.
    res = run_prog(
        ["--type", "js"],
        stdin="function a(){var x=1;function b(){var y=2;return x+y}return b}",
    )
    assert res.rc == 0
    assert res.out == "function a(){var e=1;function t(){var t=2;return e+t}return t}"


def test_js_precision(run_prog):
    """--js-precision rounds number literals to the given digits."""
    # CATCHES: 1.234567 with precision 2 becomes 1.2.
    res = run_prog(["--type", "js", "--js-precision", "2"], stdin="a=1.234567")
    assert res.rc == 0
    assert res.out == "a=1.2"


def test_js_catch_binding(run_prog):
    """Unused catch bindings are removed (optional catch binding)."""
    # CATCHES: ES2019 allows omitting the binding, and the minifier does.
    res = run_prog(["--type", "js"], stdin="try{}catch(e){}")
    assert res.rc == 0
    assert res.out == "try{}catch{}"


def test_js_catch_binding_old_version(run_prog):
    """--js-version 2018 keeps the catch binding for older targets."""
    # CATCHES: the optional-catch-binding rewrite is gated on ES2019.
    res = run_prog(["--type", "js", "--js-version", "2018"], stdin="try{}catch(e){}")
    assert res.rc == 0
    assert res.out == "try{}catch(e){}"


@pytest.mark.parametrize("version_args", [[], ["--js-version", "5"]], ids=["default", "es5"])
def test_js_unicode_escape_decoded(run_prog, version_args):
    """A \\u0041 escape in a string is decoded to the plain character."""
    # CATCHES: escape shortening applies regardless of the target version.
    res = run_prog(["--type", "js"] + version_args, stdin='a="\\u0041"')
    assert res.rc == 0
    assert res.out == 'a="A"'
