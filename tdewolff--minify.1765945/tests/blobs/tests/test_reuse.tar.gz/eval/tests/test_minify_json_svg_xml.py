"""JSON, SVG and XML minification behaviour plus the parse-error reporting
format, mined from the native tests and recorded from the reference binary.
"""

import pytest

# (id, input JSON, expected output JSON)
JSON_CASES = [
    ("spacing-removed", '{ "a" : 1, "b" : [ 1.50, 2 ] }', '{"a":1,"b":[1.5,2]}'),
    ("numbers-already-short", "[1e3,0.5,100]", "[1e3,0.5,100]"),
    ("multiline-collapsed", '{\n  "a": [\n    1,\n    2\n  ]\n}', '{"a":[1,2]}'),
    ("escapes-kept", '["\\u0041", "a\\tb"]', '["\\u0041","a\\tb"]'),
]


@pytest.mark.parametrize(
    "json_in,expected", [(c[1], c[2]) for c in JSON_CASES],
    ids=[c[0] for c in JSON_CASES],
)
def test_json_minification(run_prog, json_in, expected):
    """The JSON minifier removes whitespace and shortens numbers."""
    # CATCHES: 1.50 becomes 1.5 but 1e3 is already minimal, and escape
    # sequences in strings are passed through unchanged.
    res = run_prog(["--type", "json"], stdin=json_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_json_keep_numbers(run_prog):
    """--json-keep-numbers preserves the original number spellings."""
    # CATCHES: with the flag 1.50 keeps its trailing zero and 1e3 stays in
    # exponent form instead of being normalised.
    res = run_prog(["--type", "json", "--json-keep-numbers"], stdin="[1.50,1e3]")
    assert res.rc == 0
    assert res.out == "[1.50,1e3]"


def test_json_precision(run_prog):
    """--json-precision rounds number literals."""
    # CATCHES: 1.23456 with precision 2 becomes 1.2.
    res = run_prog(["--type", "json", "--json-precision", "2"], stdin="[1.23456]")
    assert res.rc == 0
    assert res.out == "[1.2]"


# (id, input SVG, expected output SVG)
SVG_CASES = [
    (
        "xmlns-kept-path-shortened",
        '<svg xmlns="http://www.w3.org/2000/svg"><path d="M 10 10 L 20 20"/></svg>',
        '<svg xmlns="http://www.w3.org/2000/svg"><path d="M10 10 20 20"/></svg>',
    ),
    (
        "viewbox-kept",
        '<svg viewBox="0 0 100 100"><path d="M0 0 L100.5 100.5"/></svg>',
        '<svg viewBox="0 0 100 100"><path d="M0 0 100.5 100.5"/></svg>',
    ),
    ("comment-removed", '<svg><!-- c --><path d="M10 10"/></svg>', '<svg><path d="M10 10"/></svg>'),
    (
        "namespace-removed",
        '<svg xmlns:ev="http://example.com/ev"><path d="M10 10"/></svg>',
        '<svg><path d="M10 10"/></svg>',
    ),
]


@pytest.mark.parametrize(
    "svg_in,expected", [(c[1], c[2]) for c in SVG_CASES],
    ids=[c[0] for c in SVG_CASES],
)
def test_svg_minification(run_prog, svg_in, expected):
    """The SVG minifier shortens path data and strips optional markup."""
    # CATCHES: the default xmlns is kept while extra namespaces are removed;
    # path data drops the explicit L command and its redundant spaces.
    res = run_prog(["--type", "svg"], stdin=svg_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_svg_keep_comments(run_prog):
    """--svg-keep-comments preserves comments inside the SVG."""
    # CATCHES: the flag restores the comment that is dropped by default.
    res = run_prog(
        ["--type", "svg", "--svg-keep-comments"],
        stdin='<svg><!-- c --><path d="M10 10"/></svg>',
    )
    assert res.rc == 0
    assert res.out == '<svg><!-- c --><path d="M10 10"/></svg>'


def test_svg_keep_namespaces(run_prog):
    """--svg-keep-namespaces retains the listed extra namespace."""
    # CATCHES: only namespaces named by the flag (besides the default) are
    # kept; here xmlns:ev survives.
    res = run_prog(
        ["--type", "svg", "--svg-keep-namespaces", "ev"],
        stdin='<svg xmlns:ev="http://example.com/ev"><path d="M10 10"/></svg>',
    )
    assert res.rc == 0
    assert res.out == '<svg xmlns:ev="http://example.com/ev"><path d="M10 10"/></svg>'


def test_svg_precision(run_prog):
    """--svg-precision rounds path coordinates."""
    # CATCHES: 10.25 with precision 1 rounds down to 10, and identical
    # coordinates are collapsed only in the command stream.
    res = run_prog(["--type", "svg", "--svg-precision", "1"], stdin='<svg><path d="M10.25 10.25"/></svg>')
    assert res.rc == 0
    assert res.out == '<svg><path d="M10 10"/></svg>'


# (id, mimetype, input, expected output)
XML_CASES = [
    ("xml", "xml", "<a >  <b >x</b >  </a>", "<a><b>x</b></a>"),
    ("xhtml", "xhtml", "<a >  <b >x</b >  </a>", "<a><b>x</b></a>"),
    ("self-closing", "xml", "<a><b /></a>", "<a><b/></a>"),
    ("processing-instruction", "xml", '<?xml version="1.0" encoding="UTF-8"?>\n<a >x</a>',
     '<?xml version="1.0" encoding="UTF-8"?><a>x</a>'),
]


@pytest.mark.parametrize(
    "filetype,xml_in,expected", [(c[1], c[2], c[3]) for c in XML_CASES],
    ids=[c[0] for c in XML_CASES],
)
def test_xml_minification(run_prog, filetype, xml_in, expected):
    """The XML minifier drops inter-tag whitespace and tightens markup."""
    # CATCHES: whitespace between tags is removed entirely by default and
    # "<b >" loses the stray space before the bracket.
    res = run_prog(["--type", filetype], stdin=xml_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


def test_xml_keep_whitespace(run_prog):
    """--xml-keep-whitespace collapses runs to one space instead of removing."""
    # CATCHES: two spaces between tags become one, not zero.
    res = run_prog(["--type", "xml", "--xml-keep-whitespace"], stdin="<a>  <b>x</b>  </a>")
    assert res.rc == 0
    assert res.out == "<a> <b>x</b> </a>"


# (id, --type value, bad input, echoed stdout, exact stderr)
ERROR_CASES = [
    (
        "js-unexpected-eof",
        "js",
        "var a=",
        "var a=",
        "ERROR: cannot minify -: unexpected EOF in expression on line 1 and column 7\n"
        "    1: var a=\n"
        "             ^\n",
    ),
    (
        "js-unexpected-percent",
        "js",
        "var a=1;%",
        "var a=1;%",
        "ERROR: cannot minify -: unexpected % in expression on line 1 and column 9\n"
        "    1: var a=1;%\n"
        "               ^\n",
    ),
    (
        "js-error-on-line-2",
        "js",
        "var a=1;\nvar b=%",
        "var a=1;\nvar b=%",
        "ERROR: cannot minify -: unexpected % in expression on line 2 and column 7\n"
        "    2: var b=%\n"
        "             ^\n",
    ),
    (
        "json-object-key",
        "json",
        "{",
        "{",
        "ERROR: cannot minify -: expected object key to be a quoted string on line 1 and column 2\n"
        "    1: {\n"
        "        ^\n",
    ),
    (
        "json-missing-value",
        "json",
        '{"a":}',
        '{"a":}',
        "ERROR: cannot minify -: unexpected right brace character on line 1 and column 6\n"
        '    1: {"a":}\n'
        "            ^\n",
    ),
    (
        "html-script-js-error",
        "html",
        "<script>var a=</script>",
        "<script>var a=</script>",
        "ERROR: cannot minify -: unexpected EOF in expression on line 1 and column 15\n"
        "    1: var a=\n"
        "             ^\n",
    ),
]


@pytest.mark.parametrize(
    "mimetype,bad_input,echoed,expected_err",
    [(c[1], c[2], c[3], c[4]) for c in ERROR_CASES],
    ids=[c[0] for c in ERROR_CASES],
)
def test_parse_error_reporting(run_prog, mimetype, bad_input, echoed, expected_err):
    """Parse failures echo the original input and print a located error."""
    # CATCHES: the exit code is 1, stdout carries the unminified original
    # bytes, and stderr carries the exact line/column message plus a caret
    # line indented to point at the offending column.
    res = run_prog(["--type", mimetype], stdin=bad_input)
    assert res.rc == 1
    assert res.out == echoed
    assert res.err == expected_err
