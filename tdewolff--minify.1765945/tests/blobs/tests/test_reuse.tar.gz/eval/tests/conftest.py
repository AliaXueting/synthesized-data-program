"""Shared helpers for the black-box behavioral tests of the minify CLI.

Every expected value in this test suite was recorded by actually running the
reference binary (``./executable``) with the exact inputs shown in the tests;
nothing is derived from reading the source code alone.

The tests are hermetic: the child process runs with a pinned, minimal
environment, its working directory is a pytest ``tmp_path``, and no test
touches the network or a TTY.
"""

import os
import re
import subprocess
from collections import namedtuple
from pathlib import Path

import pytest

EXECUTABLE = os.environ.get("PROGRAMGYM_EXECUTABLE")
if not EXECUTABLE:
    raise RuntimeError(
        "PROGRAMGYM_EXECUTABLE is not set; it must point at the minify binary"
    )

RunResult = namedtuple("RunResult", ["rc", "out", "err", "out_bytes", "err_bytes"])

# The progress-stats line prints a duration and a throughput that vary between
# runs; everything else (byte counts, ratio, names) is deterministic.
_STATS_LINE = (
    r"^\([^,]+,"              # duration field, e.g. " 32 µs" or "8.7 µs"
    r"\s*[\d.]+ [kMG]?B,"     # original size
    r"\s*[\d.]+ [kMG]?B,"     # minified size
    r"\s*[\d.]+%,"            # ratio
    r"\s*[^)]+\)"             # throughput, e.g. "0.6 MB/s" or "0 B/s"
)

# "INFO: finished in 102.835µs" -- the duration is the only variable part.
FINISHED_RE = re.compile(r"^INFO: finished in [\d.]+(?:ns|µs|ms|s)$")


def run_minify(args, cwd, stdin=None):
    """Run the reference binary in ``cwd`` and capture rc/stdout/stderr.

    The child environment is pinned so that nothing from the outer test
    environment (except the coverage hook below) leaks into the run.
    """
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": str(cwd),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
    }
    # Coverage instrumentation hook: propagate GOCOVERDIR so the pipeline can
    # measure source coverage of the reference binary through these tests.
    gocoverdir = os.environ.get("GOCOVERDIR")
    if gocoverdir:
        env["GOCOVERDIR"] = gocoverdir

    proc = subprocess.run(
        [EXECUTABLE] + list(args),
        cwd=str(cwd),
        env=env,
        input=stdin.encode("utf-8") if isinstance(stdin, str) else stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )
    return RunResult(
        proc.returncode,
        proc.stdout.decode("utf-8"),
        proc.stderr.decode("utf-8"),
        proc.stdout,
        proc.stderr,
    )


@pytest.fixture
def run_prog(tmp_path):
    """Runner that creates files under tmp_path and invokes the binary there.

    Named ``run_prog`` so the weak-assert linter's taint analysis recognises
    ``res = run_prog(...)`` as a program-run result being inspected.
    """

    def _run(args, files=None, stdin=None):
        for rel, content in (files or {}).items():
            path = tmp_path / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
        return run_minify(args, tmp_path, stdin=stdin)

    return _run


def stats_line_re(src, dst=None):
    """Compiled regex for one progress-stats line naming ``src`` (and ``dst``).

    With ``dst=None`` the line has no destination (in-place minification).
    """
    names = re.escape(src) if dst is None else re.escape(src) + " to " + re.escape(dst)
    return re.compile(_STATS_LINE + r" - " + names + r"$")


def assert_stats_lines(stdout, patterns):
    """Assert stdout consists of exactly one line per pattern, in any order.

    When several files are minified the CLI processes them concurrently, so the
    order in which the stats lines are printed is not deterministic.
    """
    lines = stdout.splitlines()
    assert len(lines) == len(patterns), "unexpected stats output: %r" % stdout
    remaining = list(patterns)
    for line in lines:
        for i, pattern in enumerate(remaining):
            if pattern.match(line):
                del remaining[i]
                break
        else:
            assert False, "stats line matched no expected pattern: %r" % line


def write_file(path, content):
    """Write text content to ``path``, creating parent directories as needed."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def output_tree(root):
    """Sorted relative paths of all files that exist under ``root``."""
    found = []
    for dirpath, _dirs, names in os.walk(str(root)):
        for name in names:
            found.append(os.path.relpath(os.path.join(dirpath, name), str(root)))
    return sorted(found)
