"""Deep CSS minification behaviour, mined from the repository's native css
tests (./src/css/) and recorded byte-for-byte from the reference binary via
``--type css`` on stdin.

This module targets the CSS minifier internals: colour functions and hex
shortening, selector handling, at-rule grammar, font/box-model/background/flex
property rewriting, unicode-range merging, url()/data: URI processing, escaped
newlines, and the tolerant parse-error paths.
"""

import pytest

# (id, input CSS, expected output CSS)
COLOR_FUNCTION_CASES = [
    ("rgb-basic", "a{color:rgb(255,0,0)}", "a{color:red}"),
    ("rgb-odd-hex", "a{color:rgb(1,2,3)}", "a{color:#010203}"),
    ("rgb-percent", "a{color:rgb(100%,0%,0%)}", "a{color:red}"),
    ("rgb-percent-exact", "a{color:rgb(0%,20%,40%)}", "a{color:#036}"),
    ("rgb-inner-spaces-kept", "a{color:rgb( 255 , 0 , 0 )}", "a{color:rgb( 255,0,0 )}"),
    ("rgb-space-separated", "a{color:rgb(255 0 0)}", "a{color:red}"),
    ("rgba-opaque-alpha-dropped", "a{color:rgba(255,0,0,1)}", "a{color:red}"),
    ("rgba-alpha-kept", "a{color:rgba(255,0,0,0.5)}", "a{color:rgba(255,0,0,.5)}"),
    ("rgb-slash-alpha", "a{color:rgb(255 0 0 / 0.5)}", "a{color:rgb(255 0 0/.5)}"),
    ("rgba-zero-transparent", "a{color:rgba(0,0,0,0)}", "a{color:transparent}"),
    ("rgba-percent-to-number", "a{color:rgba(0%,20%,40%,.5)}", "a{color:rgba(0,51,102,.5)}"),
    ("hsl-red", "a{color:hsl(0,100%,50%)}", "a{color:red}"),
    ("hsl-hex", "a{color:hsl(120,25%,25%)}", "a{color:#305030}"),
    ("hsla-alpha-kept", "a{color:hsla(0,100%,50%,0.5)}", "a{color:hsla(0,100%,50%,.5)}"),
    ("hsl-degree-kept", "a{color:hsl(120deg,25%,25%)}", "a{color:hsl(120deg,25%,25%)}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in COLOR_FUNCTION_CASES],
    ids=[c[0] for c in COLOR_FUNCTION_CASES],
)
def test_css_color_functions(run_prog, css_in, expected):
    """rgb()/rgba()/hsl()/hsla() are rewritten to the shortest colour form."""
    # CATCHES: fully opaque colours collapse to a name or 3-digit hex, the
    # alpha channel is dropped when 1 and minified to .5-style otherwise,
    # space-separated and slash syntax is understood, and either a `deg`
    # hue or spaces just inside the parentheses makes the whole conversion
    # bail out leaving the function (nearly) untouched.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


HEX_NAMED_CASES = [
    ("named-white", "a{color:white}", "a{color:#fff}"),
    ("named-yellow-upper", "a{color:YELLOW}", "a{color:#ff0}"),
    ("hex-uppercase", "a{color:#FFFFFF}", "a{color:#fff}"),
    ("hex8-opaque", "a{color:#FFFFFFFF}", "a{color:#fff}"),
    ("hex8-transparent", "a{color:#00000000}", "a{color:#0000}"),
    ("hex8-mixed", "a{color:#11223344}", "a{color:#1234}"),
    ("hex7-not-shortenable", "a{color:#123456}", "a{color:#123456}"),
    ("border-black", "a{border:1px solid black}", "a{border:1px solid #000}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in HEX_NAMED_CASES],
    ids=[c[0] for c in HEX_NAMED_CASES],
)
def test_css_hex_and_named_colors(run_prog, css_in, expected):
    """Named colours shorten to hex and hex literals to their shortest form."""
    # CATCHES: white/yellow become #fff/#ff0 (case-insensitively), 8-digit
    # hex collapses to 4/3 digits or #0000 for transparent, and #123456
    # stays as it is because no shorter spelling exists.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


ESCAPED_NL_CASES = [
    ("string-lf", 'a{content:"x\\\ny"}', 'a{content:"xy"}'),
    ("string-crlf", 'a{content:"x\\\r\ny"}', 'a{content:"xy"}'),
    ("url-quoted", 'a{background:url("a\\\nb.png")}', "a{background:url(ab.png)}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in ESCAPED_NL_CASES],
    ids=[c[0] for c in ESCAPED_NL_CASES],
)
def test_css_escaped_newlines_removed(run_prog, css_in, expected):
    """A backslash before a newline inside strings and urls is deleted."""
    # CATCHES: \LF and \CRLF line continuations are stripped entirely (both
    # the backslash and the newline bytes), even inside a quoted url().
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


SELECTOR_CASES = [
    ("element-lowercased", "DIV,A B{color:red}", "div,a b{color:red}"),
    ("class-case-kept", ".FOO #Baz{color:red}", ".FOO #Baz{color:red}"),
    ("attr-string-unquoted", 'a[href="foo"]{color:red}', "a[href=foo]{color:red}"),
    ("attr-string-space-quoted", 'a[href="a b"]{color:red}', 'a[href="a b"]{color:red}'),
    ("attr-flag-i-spaced", 'a[href="foo" i]{color:red}', "a[href=foo i]{color:red}"),
    ("attr-flag-capital-i-spaced", 'a[href="foo" I]{color:red}', "a[href=foo I]{color:red}"),
    ("combinators-unspaced", "a > b + c ~ d { color: red }", "a>b+c~d{color:red}"),
    ("universal-kept", "*{color:red}", "*{color:red}"),
    ("pseudo-kept", "a::before{color:red}", "a::before{color:red}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in SELECTOR_CASES],
    ids=[c[0] for c in SELECTOR_CASES],
)
def test_css_selectors(run_prog, css_in, expected):
    """Selector minification lowercases elements but never classes."""
    # CATCHES: element names are lowercased while .FOO keeps its case, an
    # attribute value that is a valid identifier loses its quotes, the i/I
    # case-insensitivity flag always gets a space before it, and whitespace
    # around combinators disappears.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


AT_RULE_CASES = [
    ("import-url-unquoted", "@import url(foo.css);", '@import "foo.css";'),
    ("import-url-single-quoted", "@import url('foo.css');", "@import 'foo.css';"),
    ("import-url-padded", "@import url( foo.css );", '@import "foo.css";'),
    ("import-url-empty", "@import url( );", '@import "";'),
    ("import-media-keeps-url", "@import url(foo.css) screen and (min-width:100px);",
     "@import url(foo.css) screen and (min-width:100px);"),
    ("import-string-media", '@import "foo.css" print;', '@import "foo.css" print;'),
    ("media-float-not-minified", "@media (min-width:100.0px){a{color:red}}",
     "@media(min-width:100.0px){a{color:red}}"),
    ("supports", "@supports (display: flex){a{color:red}}", "@supports(display:flex){a{color:red}}"),
    ("supports-not", "@supports not (display: flex){a{color:red}}",
     "@supports not (display:flex){a{color:red}}"),
    ("keyframes-percent-kept", "@keyframes x{0%{color:red}100%{color:blue}}",
     "@keyframes x{0%{color:red}100%{color:blue}}"),
    ("keyframes-from-to", "@keyframes x{from{color:red}to{color:blue}}",
     "@keyframes x{from{color:red}to{color:blue}}"),
    ("page-first-space", "@page :first{margin:1px}", "@page:first{margin:1px}"),
    ("charset-kept", '@charset "UTF-8";', '@charset "UTF-8";'),
    ("namespace-kept", "@namespace svg url(http://www.w3.org/2000/svg);",
     "@namespace svg url(http://www.w3.org/2000/svg);"),
    ("empty-at-rule-dropped", "@media a{}b{color:red}", "b{color:red}"),
    ("nested-media", "@media screen{@media (min-width:100px){a{color:red}}}",
     "@media screen{@media(min-width:100px){a{color:red}}}"),
    ("at-rule-name-lowered", "@MEDIA A{B{COLOR:RED}}", "@media A{b{color:RED}}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in AT_RULE_CASES],
    ids=[c[0] for c in AT_RULE_CASES],
)
def test_css_at_rules(run_prog, css_in, expected):
    """At-rule headers keep their spelling while inner rules are minified."""
    # CATCHES: a two-value @import rewrites url(x) to a quoted string, but a
    # three-value @import (with media) keeps url() verbatim; media-query
    # numbers are NOT minified (100.0px stays); an at-rule with an empty
    # body disappears entirely while its neighbours survive; and the at-rule
    # name is lowercased while its prelude keeps its case.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


COMMENT_CASES = [
    ("plain-comment-dropped", "a{/* gone */color:red}", "a{color:red}"),
    ("bang-comment-kept-collapsed", "/*! hello   world */a{color:red}",
     "/*!hello world*/a{color:red}"),
    ("bang-multiline-collapsed", "/*! a\n   b */c{color:red}", "/*!a\nb*/c{color:red}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in COMMENT_CASES],
    ids=[c[0] for c in COMMENT_CASES],
)
def test_css_comments(run_prog, css_in, expected):
    """Only /*! comments survive, with their inner whitespace collapsed."""
    # CATCHES: a normal /* */ comment vanishes, while a /*! bang comment is
    # kept with runs of whitespace inside collapsed to one character and
    # the bang marker rewritten to exactly "/*!...*/".
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


FONT_CASES = [
    ("shorthand", "a{font:italic bold 12px/30px Georgia, serif}",
     "a{font:italic 700 12px/30px Georgia,serif}"),
    ("normals-dropped", "a{font:normal normal normal 12px/normal Arial}", "a{font:12px Arial}"),
    ("dash-family-quoted", "a{font:12px -Some-Font}", "a{font:12px '-Some-Font'}"),
    ("weight-400-dropped", "a{font:400 12px Arial}", "a{font:12px Arial}"),
    ("line-height-numeric-kept", "a{font:12px/1.5 Arial}", "a{font:12px/1.5 Arial}"),
    ("small-caps-kept", "a{font:small-caps bold small/1.2 Arial}",
     "a{font:small-caps 700 small/1.2 Arial}"),
    ("weight-normal-to-400", "a{font-weight:normal}", "a{font-weight:400}"),
    ("important-font", "a{font:12px Arial !important}", "a{font:12px Arial!important}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in FONT_CASES],
    ids=[c[0] for c in FONT_CASES],
)
def test_css_font(run_prog, css_in, expected):
    """The font shorthand drops defaults and rewrites bold/normal weights."""
    # CATCHES: bold becomes 700, every `normal` component disappears (style,
    # variant, weight and line-height), 400 is dropped as the default
    # weight, and a font family starting with '-' gets single-quoted.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


BOX_MODEL_CASES = [
    ("margin-3-to-2", "a{margin:1px 2px 1px}", "a{margin:1px 2px}"),
    ("margin-3-kept", "a{margin:1px 1px 2px}", "a{margin:1px 1px 2px}"),
    ("padding-4-to-2", "a{padding:1px 2px 1px 2px}", "a{padding:1px 2px}"),
    ("padding-4-to-3", "a{padding:1px 2px 3px 2px}", "a{padding:1px 2px 3px}"),
    ("border-none-kept", "a{border:none}", "a{border:none}"),
    ("border-defaults-collapse", "a{border:medium currentcolor}", "a{border:none}"),
    ("outline-invert-collapse", "a{outline:invert}", "a{outline:none}"),
    ("outline-full-kept", "a{outline:1px solid red}", "a{outline:1px solid red}"),
    ("border-color-currentcolor", "a{border-color:currentcolor currentcolor}",
     "a{border-color:initial}"),
    ("column-rule-collapse", "a{column-rule:medium none currentcolor}", "a{column-rule:none}"),
    ("text-decoration-trimmed", "a{text-decoration:underline currentcolor solid}",
     "a{text-decoration:underline}"),
    ("text-emphasis-collapse", "a{text-emphasis:currentcolor}", "a{text-emphasis:none}"),
    ("box-shadow-initial", "a{box-shadow:initial}", "a{box-shadow:none}"),
    ("box-shadow-trailing-zero", "a{box-shadow:0 0 0}", "a{box-shadow:0 0}"),
    ("box-shadow-4th-zero-dropped", "a{box-shadow:1px 2px 3px 0}", "a{box-shadow:1px 2px 3px}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in BOX_MODEL_CASES],
    ids=[c[0] for c in BOX_MODEL_CASES],
)
def test_css_box_model(run_prog, css_in, expected):
    """Margin/padding collapse and default keywords fall out of box properties."""
    # CATCHES: 3-value and 4-value margin/padding shrink by equal sides,
    # none/medium/currentcolor/invert/solid disappear from border-family
    # shorthands (falling back to `none` when nothing is left), currentcolor
    # becomes initial in border-color, and trailing zero lengths drop from
    # box-shadow.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


BACKGROUND_CASES = [
    ("none-becomes-zeros", "a{background:none}", "a{background:0 0}"),
    ("scroll-dropped", "a{background:scroll}", "a{background:0 0}"),
    ("transparent-dropped", "a{background:transparent}", "a{background:0 0}"),
    ("alpha-zero-hex-dropped", "a{background:#0000}", "a{background:0 0}"),
    ("zero-position-kept", "a{background:0 0}", "a{background:0 0}"),
    ("zero-percent-kept", "a{background:0% 0%}", "a{background:0 0}"),
    ("left-top-to-zeros", "a{background:left top}", "a{background:0 0}"),
    ("center-to-50", "a{background:center}", "a{background:50%}"),
    ("right-bottom-to-100", "a{background:right bottom}", "a{background:100% 100%}"),
    ("left-offset-top", "a{background:left 10px top}", "a{background:10px 0}"),
    ("repeat-alone-kept", "a{background:repeat}", "a{background:repeat}"),
    ("color-repeat-kept", "a{background:red repeat}", "a{background:red repeat}"),
    ("repeat-x-pair", "a{background:repeat no-repeat}", "a{background:repeat-x}"),
    ("repeat-y-pair", "a{background:no-repeat repeat}", "a{background:repeat-y}"),
    ("no-repeat-pair-collapsed", "a{background:no-repeat no-repeat}", "a{background:no-repeat}"),
    ("size-auto-dropped", "a{background:url(a.png) 0 0/auto}", "a{background:url(a.png)}"),
    ("size-auto-auto-dropped", "a{background:url(a.png) 50% 50%/auto auto}",
     "a{background:url(a.png)50%}"),
    ("origin-clip-dropped", "a{background:padding-box border-box}", "a{background:0 0}"),
    ("position-left-center", "a{background-position:left center}", "a{background-position:0}"),
    ("position-top-kept", "a{background-position:top}", "a{background-position:top}"),
    ("position-top-left-swapped", "a{background-position:top left}", "a{background-position:0 0}"),
    ("position-right-10pct", "a{background-position:right 10%}", "a{background-position:100% 10%}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in BACKGROUND_CASES],
    ids=[c[0] for c in BACKGROUND_CASES],
)
def test_css_background(run_prog, css_in, expected):
    """Background shorthands drop defaults and fold keyword positions."""
    # CATCHES: none/scroll/transparent/#0000 all disappear (leaving 0 0),
    # repeat no-repeat folds to repeat-x, /auto sizes vanish, padding-box
    # border-box cancels itself, left/top keywords become 0 and right/bottom
    # become 100%, while a bare `repeat` (or `red repeat`) survives.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


FLEX_CASES = [
    ("grow-shrink-basis-auto-initial", "a{flex:0 1 auto}", "a{flex:initial}"),
    ("grow-shrink-basis-auto-none", "a{flex:0 0 auto}", "a{flex:none}"),
    ("grow-shrink-basis-auto-auto", "a{flex:1 1 auto}", "a{flex:auto}"),
    ("one-zero-zero", "a{flex:1 0 0px}", "a{flex:1 0}"),
    ("arbitrary-kept", "a{flex:2 3 4px}", "a{flex:2 3 4px}"),
    ("basis-initial-to-auto", "a{flex-basis:initial}", "a{flex-basis:auto}"),
    ("grow-initial-to-zero", "a{flex-grow:initial}", "a{flex-grow:0}"),
    ("shrink-initial-to-one", "a{flex-shrink:initial}", "a{flex-shrink:1}"),
    ("zero-dimension-kept-for-flex", "a{flex:0px}", "a{flex:0px}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in FLEX_CASES],
    ids=[c[0] for c in FLEX_CASES],
)
def test_css_flex(run_prog, css_in, expected):
    """The flex shorthand maps common triples onto keywords."""
    # CATCHES: 0 1 auto / 0 0 auto / 1 1 auto become initial/none/auto, a
    # zero basis is dropped from `1 0 0px`, initial flips to the real
    # default for each longhand, and unlike other properties a 0 dimension
    # is NOT stripped inside flex.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


UNICODE_RANGE_CASES = [
    ("sorted", "a{unicode-range:U+32,U+31}", "a{unicode-range:U+31-32}"),
    ("contained-merged", "a{unicode-range:U+30-39,U+32-35}", "a{unicode-range:U+30-39}"),
    ("duplicates-merged", "a{unicode-range:U+32,U+32}", "a{unicode-range:U+32}"),
    ("gap-kept", "a{unicode-range:U+30-32,U+34-36}", "a{unicode-range:U+30-32,U+34-36}"),
    ("full-range-initial", "a{unicode-range:U+0-10FFFF}", "a{unicode-range:initial}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in UNICODE_RANGE_CASES],
    ids=[c[0] for c in UNICODE_RANGE_CASES],
)
def test_css_unicode_range(run_prog, css_in, expected):
    """unicode-range lists are sorted, merged and re-serialised."""
    # CATCHES: ranges come out sorted, adjacent or overlapping ranges merge
    # into one, a gap keeps two ranges apart, and the full U+0-10FFFF range
    # collapses to the `initial` keyword.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


URL_CASES = [
    ("padded-trimmed", "a{background:url( a.png )}", "a{background:url(a.png)}"),
    ("single-quotes-removed", "a{background:url('a.png')}", "a{background:url(a.png)}"),
    ("space-keeps-quotes", 'a{background:url("a b.png")}', 'a{background:url("a b.png")}'),
    ("empty-kept", "a{background:url()}", "a{background:url()}"),
    ("short-kept", "a{background:url(x)}", "a{background:url(x)}"),
    ("fontface-local-space-quoted", '@font-face{font-family:X;src:local("Font Name")}',
     '@font-face{font-family:X;src:local("Font Name")}'),
    ("fontface-local-quotes-kept", '@font-face{font-family:X;src:local("FontName")}',
     '@font-face{font-family:X;src:local("FontName")}'),
    ("fontface-format-space", '@font-face{font-family:X;src:url(a.woff2) format("woff2")}',
     '@font-face{font-family:X;src:url(a.woff2)format("woff2")}'),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in URL_CASES],
    ids=[c[0] for c in URL_CASES],
)
def test_css_url_and_fontface(run_prog, css_in, expected):
    """url() arguments are trimmed/unquoted and local() follows the same rule."""
    # CATCHES: whitespace inside url() and single quotes disappear, a URL
    # with a space keeps its quotes, tiny urls are left alone, local()
    # names always keep their quotes, and the space before format()
    # after url() is dropped.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


DATA_URI_CASES = [
    ("css-minified-and-encoded", "a{background:url(data:text/css,a{color:red})}",
     "a{background:url(data:text/css,a%7Bcolor:red%7D)}"),
    ("css-quoted-minified", 'a{background:url("data:text/css,body{color:red }")}',
     "a{background:url(data:text/css,body%7Bcolor:red%7D)}"),
    ("plain-default-mediatype", "a{background:url(data:,hello)}", "a{background:url(data:,hello)}"),
    ("charset-stripped", "a{background:url(data:text/plain;charset=us-ascii,hello)}",
     "a{background:url(data:,hello)}"),
    ("already-minimal-kept", "a{background:url(data:,hellooooo)}",
     "a{background:url(data:,hellooooo)}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in DATA_URI_CASES],
    ids=[c[0] for c in DATA_URI_CASES],
)
def test_css_data_uris(run_prog, css_in, expected):
    """data: URIs are run through the matching minifier and re-encoded."""
    # CATCHES: a data:text/css URI has its CSS minified in place and then
    # percent-encoded (braces become %7B/%7D) rather than base64, the
    # default text/plain mediatype and ;charset=us-ascii are stripped, and
    # a URI that cannot get smaller is passed through untouched.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


FILTER_CASES = [
    ("filter-progid-to-alpha", "a{filter:progid:DXImageTransform.Microsoft.Alpha(Opacity=50)}",
     "a{filter:alpha(opacity=50)}"),
    ("ms-filter-progid-to-alpha",
     "a{-ms-filter:'progid:DXImageTransform.Microsoft.Alpha(Opacity=50)'}",
     "a{-ms-filter:'alpha(opacity=50)'}"),
    ("modern-filter-kept", "a{filter:blur(5px)}", "a{filter:blur(5px)}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in FILTER_CASES],
    ids=[c[0] for c in FILTER_CASES],
)
def test_css_filter_progid(run_prog, css_in, expected):
    """Legacy DXImageTransform filter syntax shrinks to alpha(opacity=..)."""
    # CATCHES: both the unquoted progid: form in `filter` and the quoted
    # form in `-ms-filter` are rewritten to alpha(opacity=N) with the
    # original quote style kept for -ms-filter, while a modern function
    # like blur() is untouched.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


COLOR_PROPERTY_CASES = [
    ("text-shadow-color-minified", "a{text-shadow:1px 1px rgb(255,0,0)}",
     "a{text-shadow:1px 1px red}"),
    ("text-shadow-none-kept", "a{text-shadow:none}", "a{text-shadow:none}"),
    ("border-color-same-collapsed", "a{border-color:red red}", "a{border-color:red}"),
    ("border-color-different-kept", "a{border-color:red blue}", "a{border-color:red blue}"),
    ("border-top-color-currentcolor", "a{border-top-color:currentcolor}",
     "a{border-top-color:initial}"),
    ("outline-color-currentcolor-kept", "a{outline-color:currentcolor}",
     "a{outline-color:currentcolor}"),
    ("column-rule-color-currentcolor-kept", "a{column-rule-color:currentcolor}",
     "a{column-rule-color:currentcolor}"),
    ("text-decoration-color-currentcolor", "a{text-decoration-color:currentcolor}",
     "a{text-decoration-color:initial}"),
    ("fill-space-separated-rgb", "a{fill:rgb(255 0 0)}", "a{fill:red}"),
    ("stroke-hex-named", "a{stroke:#FF0000}", "a{stroke:red}"),
    ("caret-color-named", "a{caret-color:white}", "a{caret-color:#fff}"),
    ("background-color-rgb", "a{background-color:rgb(255,0,0)}", "a{background-color:red}"),
    ("order-initial-to-zero", "a{order:initial}", "a{order:0}"),
    ("font-weight-bold-to-700", "a{font-weight:bold}", "a{font-weight:700}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in COLOR_PROPERTY_CASES],
    ids=[c[0] for c in COLOR_PROPERTY_CASES],
)
def test_css_color_properties(run_prog, css_in, expected):
    """Colour-valued longhand properties minify their colour in place."""
    # CATCHES: rgb()/hex/named colours shrink inside text-shadow, fill,
    # stroke, caret-color and background-color; currentcolor becomes initial
    # only for border-*-color and text-decoration/emphasis-color (NOT for
    # outline-color or column-rule-color, which keep it verbatim), equal
    # border-color sides collapse to one, and bold/initial rewrite to 700/0
    # in font-weight/order.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


TOLERANT_CASES = [
    ("extra-semicolon", "a{color:red;;}", "a{color:red}"),
    ("empty-value-kept", "a{color:;}", "a{color:}"),
    ("missing-colon-echoed", "a{color red}", "a{color red}"),
    ("stray-tokens-echoed", "a{color:red}garbage", "a{color:red}garbage"),
    ("custom-property-trimmed", "a{--x:  red  ;color:red}", "a{--x:red;color:red}"),
    ("custom-property-whitespace-value", "a{--x:   ;color:red}", "a{--x: ;color:red}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in TOLERANT_CASES],
    ids=[c[0] for c in TOLERANT_CASES],
)
def test_css_tolerant_parsing(run_prog, css_in, expected):
    """Malformed declarations are echoed verbatim instead of failing the run."""
    # CATCHES: a missing colon or stray trailing tokens are written out
    # unchanged with rc 0, an empty value keeps its colon, and a custom
    # property keeps its value except that pure-whitespace collapses to a
    # single space.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""


NUMBER_CASES = [
    ("dimension-case-lowered", "a{width:10PX}", "a{width:10px}"),
    ("zero-dimension-cut", "a{width:0PX}", "a{width:0}"),
    ("plus-sign-dropped", "a{width:+5px}", "a{width:5px}"),
    ("trailing-zeros-cut", "a{width:1.500px}", "a{width:1.5px}"),
    ("percent-trailing-zeros", "a{width:50.00%}", "a{width:50%}"),
    ("tiny-becomes-exponent", "a{width:0.00001px}", "a{width:1e-5px}"),
    ("trailing-zeros-become-exponent", "a{width:5000px}", "a{width:5e3px}"),
    ("seven-significant-digits-kept", "a{width:1234567px}", "a{width:1234567px}"),
    ("z-index-integer-kept", "a{z-index:5.0}", "a{z-index:5.0}"),
    ("orphans-integer-kept", "a{orphans:5.0}", "a{orphans:5.0}"),
]


@pytest.mark.parametrize(
    "css_in,expected", [(c[1], c[2]) for c in NUMBER_CASES],
    ids=[c[0] for c in NUMBER_CASES],
)
def test_css_numbers_and_dimensions(run_prog, css_in, expected):
    """Numbers shrink aggressively except in integer-only properties."""
    # CATCHES: units are lowercased, a zero dimension drops its unit, + is
    # removed, trailing zeros turn into exponents (5000px -> 5e3px) as do
    # tiny magnitudes, a 7-significant-digit number is left alone, while
    # z-index and orphans keep 5.0 verbatim because their values are
    # integers that must not be reformatted.
    res = run_prog(["--type", "css"], stdin=css_in)
    assert res.rc == 0
    assert res.out == expected
    assert res.err == ""
