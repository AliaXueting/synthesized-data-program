"""Failure modes: runtime errors, usage errors, variables and the config file.
Ported from ``src/execution/execute_error_test.go``, ``src/internal/cli/variable.go``
and ``src/internal/cli/config.go``."""

import pytest


@pytest.mark.parametrize("query,fragment", [
    ("filter($this == \"x\")", "cannot filter over non-array"),
    ("each($this = $this)", "cannot each over non-array"),
    ("map($this)", "cannot map over non-array"),
    ("sortBy($this)", "cannot sort by on non-slice data"),
    ("all($this == \"x\")", "cannot use all over non-array"),
    ("any($this == \"x\")", "cannot use any over non-array"),
    ("count($this == \"x\")", "cannot use count over non-array"),
])
def test_iterators_reject_non_array_input(run, query, fragment):
    """Slice-only operations fail on a string input."""
    result = run(["-i", "json", query], stdin='"not a slice"')
    # CATCHES: each operation has its own wording in the error, and the error
    # is wrapped by the AST node type that detected it.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.%s: %s\n" % (
            {"filter": "FilterExpr", "each": "EachExpr", "map": "MapExpr",
             "sortBy": "SortByExpr", "all": "AllExpr", "any": "AnyExpr",
             "count": "CountExpr"}[query.split("(")[0]],
            fragment))


def test_spread_rejects_a_scalar(run):
    """`...` cannot be applied to an int."""
    result = run(["-i", "json", "$this..."], stdin="42")
    # CATCHES: the spread error is reported through the enclosing chained
    # expression, not the spread node itself.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.ChainedExpr: error executing expression: execution error when "
        "processing ast.SpreadExpr: cannot spread on type int\n")


@pytest.mark.parametrize("query,expected", [
    ('"a" + 1', "could not add: incompatible types: string and int"),
    ('1 + "a"', "could not add: incompatible types: int and string"),
    ("null + 1", "could not add: incompatible types: null and int"),
    ('"a" == 1', "incompatible types: string and int"),
    ('"a" < 1', "incompatible types: string and int"),
])
def test_incompatible_type_errors(run, query, expected):
    """Binary operators reject mismatched operand types."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the operand order in the message follows the source order, and
    # arithmetic failures are prefixed with `could not add:`.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.BinaryExpr: %s\n" % expected)


def test_missing_map_key_is_an_error(run):
    """Reading a key that does not exist fails the run."""
    result = run(["-i", "json", "b"], stdin='{"a": 1}')
    # CATCHES: there is no `--` optional syntax, so a missing key is a hard
    # error naming the key rather than a null result.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.PropertyExpr: map key not found: "b"\n')


def test_property_access_on_a_scalar_fails(run):
    """Dot access into an int reports the expected type."""
    result = run(["-i", "json", "a b"], stdin='{"a": 1}')
    # CATCHES: chained property access on a scalar reports `expected map, got
    # int`, wrapped by each level of the chained expression.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.ChainedExpr: error executing expression: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int\n")


def test_integer_division_by_zero_panics(run):
    """Dividing by zero crashes the process with Go's runtime panic."""
    result = run(["-i", "json", "1 / 0"], stdin="null")
    # CATCHES: the reference does not guard division, so the process dies with
    # exit status 2 and a panic header rather than a dasel error.
    assert result.returncode == 2
    assert result.out == ""
    assert result.err.splitlines()[0] == "panic: runtime error: integer divide by zero"
    assert result.err.splitlines()[1] == ""


def test_integer_modulo_by_zero_panics(run):
    """The same is true of the modulo operator."""
    result = run(["-i", "json", "1 % 0"], stdin="null")
    # CATCHES: modulo hits the identical runtime panic, proving both
    # operators share the unguarded integer path.
    assert result.returncode == 2
    assert result.err.splitlines()[0] == "panic: runtime error: integer divide by zero"


@pytest.mark.parametrize("query,stdin,expected", [
    ("a.", '{"a": 1}', "1\n"),
    ("(a", '{"a": 1}', "1\n"),
    ("1 2", "null", "2\n"),
])
def test_lenient_parser_edges(run, query, stdin, expected):
    """Some malformed selectors are accepted rather than rejected."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: a trailing dot is ignored, an unclosed group is treated as a
    # plain grouping and two adjacent literals keep only the last one - a
    # re-implementation that is stricter would fail here.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_dangling_close_parenthesis_is_a_parse_error(run):
    """An unmatched closing parenthesis is rejected with its position."""
    result = run(["-i", "json", "a)"], stdin='{"a": 1}')
    # CATCHES: the parse error reports both the token's numeric kind and its
    # byte position, which pins the tokenizer's token numbering.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error parsing selector: failed to parse: '
        'unexpected token 9 ")" at position 1.\n')


@pytest.mark.parametrize("var,query,expected", [
    ('foo="bar"', "$foo", '"bar"\n'),
    ("foo=(1+2)*3", "$foo", "9\n"),
    ('foo=json:{"x":1}', "$foo.x", "1\n"),
    ("foo=yaml:x: 9", "$foo.x", "9\n"),
    ("x=dasel:{a: 1, b: 2}", "$x.b", "2\n"),
])
def test_variables_are_referenced_with_a_dollar(run, var, query, expected):
    """--var values are read with a format prefix and used as $name."""
    result = run(["-i", "json", "--var", var, query], stdin="null")
    # CATCHES: the default var format is `dasel`, which evaluates the value as
    # a selector expression (so `foo=bar` fails while `foo="bar"` works), and a
    # variable is only reachable through the `$name` spelling.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_variables_can_be_read_from_a_file(run, write):
    """`--var name=format:file:path` loads the value from disk."""
    write("var.json", '{"q": 7}')
    result = run(["-i", "json", "--var", "foo=json:file:var.json", "$foo.q"], stdin="null")
    # CATCHES: the path is resolved relative to the process working directory,
    # which the harness pins inside tmp_path.
    assert result.returncode == 0
    assert result.out == "7\n"
    assert result.err == ""


def test_variable_missing_file_is_a_usage_error(run):
    """A variable pointing at a missing file fails during flag parsing."""
    result = run(["-i", "json", "--var", "foo=json:file:nope.json", "$foo"], stdin="null")
    # CATCHES: because the failure happens while decoding the flag, kong prints
    # the usage block to stdout and exits 80 instead of 1.
    assert result.returncode == 80
    assert result.out.startswith("Usage: dasel <command>\n")
    assert result.err == (
        "dasel: error: --var: failed to open file: open nope.json: no such file or directory\n")


def test_variable_without_an_equals_sign_is_rejected(run):
    """A --var with no `=` is rejected."""
    result = run(["-i", "json", "--var", "foo", "$foo"], stdin="null")
    # CATCHES: the error text spells out the accepted shapes verbatim.
    assert result.returncode == 80
    assert result.err == (
        "dasel: error: --var: invalid variable format, expect foo=bar, "
        "or foo=format:file:path\n")


def test_variable_with_an_unknown_format_is_rejected(run):
    """A --var whose format has no reader fails."""
    result = run(["-i", "json", "--var", "foo=nope:1", "$foo"], stdin="null")
    # CATCHES: variable readers use the same registry as -i, so the message is
    # `failed to create reader`, not `failed to get input reader`.
    assert result.returncode == 80
    assert result.err == (
        "dasel: error: --var: failed to create reader: "
        "unsupported reader file format: nope\n")


def test_read_write_flag_without_an_equals_sign_is_rejected(run):
    """--rw-flag requires name=value."""
    result = run(["-i", "json", "--rw-flag", "foo", "$root"], stdin='{"a": 1}')
    # CATCHES: like --var, a malformed flag value aborts parsing with usage on
    # stdout and exit status 80.
    assert result.returncode == 80
    assert result.err == (
        "dasel: error: --rw-flag: invalid read/write flag format, expect foo=bar\n")


def test_config_file_sets_the_default_format(run, write):
    """A config file's default_format is used when -i/-o are omitted."""
    write("dasel.yaml", "default_format: yaml\n")
    result = run(["$root"], stdin="a: 1\n", config="dasel.yaml")
    # CATCHES: both the reader and writer follow the config, so yaml goes in
    # and yaml comes out without any format flag on the command line.
    assert result.returncode == 0
    assert result.out == "a: 1\n"
    assert result.err == ""


def test_config_file_is_overridden_by_explicit_flags(run, write):
    """An explicit -i/-o wins over the config file."""
    write("dasel.yaml", "default_format: yaml\n")
    result = run(["-i", "yaml", "-o", "json", "$root"], stdin="a: 1\n", config="dasel.yaml")
    # CATCHES: only the missing direction falls back to the config, so the
    # explicit pair completely overrides default_format.
    assert result.returncode == 0
    assert result.out == '{\n    "a": 1\n}\n'
    assert result.err == ""


def test_missing_config_file_falls_back_to_json(run):
    """A config path that does not exist is not an error."""
    result = run(["$root"], stdin='{"a": 1}\n', config="absent.yaml")
    # CATCHES: the built-in default is json, so a missing config silently
    # behaves like `-i json -o json`.
    assert result.returncode == 0
    assert result.out == '{\n    "a": 1\n}\n'
    assert result.err == ""


def test_invalid_config_file_is_an_error(run, write):
    """A config file that is not valid yaml fails the run."""
    write("bad.yaml", "{{{\n")
    result = run(["$root"], stdin='{"a": 1}\n', config="bad.yaml")
    # CATCHES: the error is raised before anything is read from stdin and
    # keeps the underlying yaml library's wording.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error parsing config file: "
        "yaml: line 1: did not find expected node content\n")


def test_config_path_pointing_at_a_directory_is_an_error(run):
    """A directory cannot be parsed as a config file."""
    result = run(["$root"], stdin='{"a": 1}\n', config=".")
    # CATCHES: the read error surfaces through the yaml decoder as an input
    # error naming the directory.
    assert result.returncode == 1
    assert result.err.endswith("error parsing config file: yaml: input error: read .: is a directory\n")


def test_input_data_is_required_when_stdin_has_content(run, write):
    """An empty default_format in the config makes stdin unreadable."""
    write("empty.yaml", 'default_format: ""\n')
    result = run(["$root"], stdin='{"a": 1}\n', config="empty.yaml")
    # CATCHES: the writer is looked up before the reader is used, so a blank
    # default format fails on the writer first with the empty format name.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: failed to get output writer: "
        "unsupported writer file format: \n")


def test_unterminated_regex_literal_is_a_tokenizer_eof_error(run):
    """A regex literal without its closing slash reports the EOF position."""
    result = run(["-i", "json", "r/abc"], stdin="null")
    # CATCHES: the tokenizer reports "unexpected EOF" (not an unexpected
    # character) with the position just past the end of the query, mirroring
    # the unterminated double-quoted string error.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error parsing selector: failed to tokenize: "
        "unexpected EOF at position 5.\n")


def test_inline_format_prefix_in_a_query_is_a_parse_error(run):
    """The `format:` prefix only exists in --var values, not in queries."""
    result = run(["-i", "json", "$x = json:[1,2,3]"], stdin="null")
    # CATCHES: the parser stops at the colon after the bare word `json` and
    # reports the token kind number with the quoted value and 0-based
    # position, instead of silently treating it as a variable default.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error parsing selector: failed to parse: '
        'unexpected token 3 ":" at position 9.\n')
