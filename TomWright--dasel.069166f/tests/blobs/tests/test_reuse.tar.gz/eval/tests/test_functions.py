"""Builtin function behaviour, ported from the native table driven tests in
``src/execution/func_*_test.go``."""

import pytest

MAP_ABC = '{"a": 1, "b": 2, "c": 3}'


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"s": "abc"}', "len(s)", "3\n"),
    ('{"s": [1, 2]}', "len(s)", "2\n"),
    ('{"s": {"a": 1}}', "len(s)", "1\n"),
    ('["a", "b", "c"]', "len($this)", "3\n"),
])
def test_len_of_strings_arrays_and_maps(run, stdin, query, expected):
    """len counts runes in a string, elements in an array, keys in a map."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: len is polymorphic over all three container kinds, so a map
    # yields its key count rather than an error.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_len_of_a_scalar_is_an_error(run):
    """len rejects scalars with a message listing the accepted types."""
    result = run(["-i", "json", "len(123)"], stdin="null")
    # CATCHES: the error enumerates the accepted types in a fixed order,
    # `[array map string]`, which is easy to get wrong in a re-implementation.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: error execution func "len": '
        'unexpected type: expected [array map string], got int\n')


def test_keys_of_a_map(run):
    """keys() returns the map's keys in insertion order."""
    result = run(["-i", "json", "keys()"], stdin=MAP_ABC)
    # CATCHES: key order follows the document order, not sorted order.
    assert result.returncode == 0
    assert result.out == '[\n    "a",\n    "b",\n    "c"\n]\n'
    assert result.err == ""


def test_keys_of_an_array_returns_indices(run):
    """keys() on an array yields the numeric indices."""
    result = run(["-i", "json", "keys()"], stdin='{"z": 1, "a": 2}')
    # CATCHES: keys() with no argument operates on $this (the root document),
    # and key order is document order rather than sorted.
    assert result.returncode == 0
    assert result.out == '[\n    "z",\n    "a"\n]\n'
    assert result.err == ""

    result = run(["-i", "json", "[10,20].keys()"], stdin="null")
    assert result.returncode == 0
    assert result.out == "[\n    0,\n    1\n]\n"
    assert result.err == ""


def test_values_of_a_map(run):
    """values() returns the map's values in insertion order."""
    result = run(["-i", "json", "values()"], stdin=MAP_ABC)
    # CATCHES: values line up with keys(), so the order is document order.
    assert result.returncode == 0
    assert result.out == "[\n    1,\n    2,\n    3\n]\n"
    assert result.err == ""


def test_entries_and_from_entries_round_trip(run):
    """entries() flattens a map and fromEntries() rebuilds it."""
    result = run(["-i", "json", "entries()"], stdin='{"a": 1, "b": 2}')
    # CATCHES: each entry is a {key, value} object with those exact key names.
    assert result.returncode == 0
    assert result.out == """[
    {
        "key": "a",
        "value": 1
    },
    {
        "key": "b",
        "value": 2
    }
]
"""
    assert result.err == ""

    result = run(["-i", "json", '{"x": 10, "y": 20}.entries().fromEntries()'], stdin="null")
    assert result.returncode == 0
    assert result.out == '{\n    "x": 10,\n    "y": 20\n}\n'
    assert result.err == ""


def test_entries_of_an_array_is_an_error(run):
    """entries() only works on maps."""
    result = run(["-i", "json", "entries()"], stdin="[10,20]")
    # CATCHES: the error names both the expectation and the actual type.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: error execution func "entries": '
        'entries can only be used on maps, got array\n')


@pytest.mark.parametrize("stdin,query,expected", [
    ('["a","b","c"]', 'join(",")', '"a,b,c"\n'),
    ('["a","b","c"]', 'join("")', '"abc"\n'),
    ('[]', 'join(",")', '""\n'),
])
def test_join(run, stdin, query, expected):
    """join concatenates string elements with a separator."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: join is called as a method on the array and an empty array
    # joins to the empty string, not null.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ("null", 'join("-", "a", "b")', '"a-b"\n'),
    ("null", 'join("-", ["x", "y"])', '"x-y"\n'),
    ("null", 'join("+", "a", "b", "c")', '"a+b+c"\n'),
    ('["x", "y"]', 'join("!", ["1", "2"])', '"1!2"\n'),
])
def test_join_with_arguments_and_array_arguments(run, stdin, query, expected):
    """join accepts explicit values or a single array of values to join."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: a two argument call whose second argument is an array joins the
    # array elements, while three or more arguments join every argument after
    # the separator - neither form touches the input document.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected_err", [
    ("null", 'join(1, "a")',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: error execution func "join": '
     'join expects a string separator as the first argument: '
     'unexpected type: expected string, got int\n'),
    ("[1,2]", 'join(",")',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: error execution func "join": '
     'could not read string value of index 0: '
     'unexpected type: expected string, got int\n'),
    ("null", 'join("-", ["x", 1])',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: error execution func "join": '
     'could not read string value of index 1: '
     'unexpected type: expected string, got int\n'),
    ("null", 'join("-", 1)',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: error execution func "join": '
     'could not read string value of argument index 1: '
     'unexpected type: expected string, got int\n'),
    ("null", 'join()',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: func "join" expects at least '
     '1 arguments, got 0\n'),
])
def test_join_rejects_non_string_values(run, stdin, query, expected_err):
    """join reports where the first non-string value was found."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: the error distinguishes the separator, the document data, an
    # array element (by index) and a positional argument (by argument index),
    # join refuses to stringify numbers implicitly, and the arity check is
    # reported without the "error execution func" wrapper.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == expected_err


@pytest.mark.parametrize("query,expected", [
    ('startsWith("hello", "he")', "true\n"),
    ('startsWith("hello", "lo")', "false\n"),
    ('endsWith("hello", "lo")', "true\n"),
    ('endsWith("hello", "he")', "false\n"),
    ('"hello".startsWith("he")', "true\n"),
    ('"hello".endsWith("he")', "false\n"),
    ('startsWith("", "")', "true\n"),
    ('endsWith("hello", "")', "true\n"),
])
def test_starts_with_and_ends_with(run, query, expected):
    """startsWith/endsWith work as two-argument functions and one-argument methods."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: both the (input, prefix) function form and the method form on a
    # string literal are accepted, and an empty needle always matches.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected_err", [
    ('startsWith(1, "a")',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: error execution func "startsWith": '
     'startsWith expects a string as the first argument: '
     'unexpected type: expected string, got int\n'),
    ('startsWith("a", 1)',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: error execution func "startsWith": '
     'startsWith expects a string prefix as the second argument: '
     'unexpected type: expected string, got int\n'),
    ('1.startsWith("a")',
     'dasel: error: error executing selector: execution error when processing '
     'ast.ChainedExpr: error executing expression: execution error when '
     'processing ast.CallExpr: error executing function: error execution func '
     '"startsWith": startsWith expects data to be a string: '
     'unexpected type: expected string, got int\n'),
    ('endsWith(1, "a")',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: error execution func "endsWith": '
     'endsWith expects a string as the first argument: '
     'unexpected type: expected string, got int\n'),
    ('endsWith("a", 1)',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: error execution func "endsWith": '
     'endsWith expects a string suffix as the second argument: '
     'unexpected type: expected string, got int\n'),
    ('1.endsWith("a")',
     'dasel: error: error executing selector: execution error when processing '
     'ast.ChainedExpr: error executing expression: execution error when '
     'processing ast.CallExpr: error executing function: error execution func '
     '"endsWith": endsWith expects data to be a string: '
     'unexpected type: expected string, got int\n'),
    ('startsWith("a", "b", "c")',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: func "startsWith" expects '
     'between 1 and 2 arguments, got 3\n'),
    ('endsWith()',
     'dasel: error: error executing selector: execution error when processing '
     'ast.CallExpr: error executing function: func "endsWith" expects '
     'between 1 and 2 arguments, got 0\n'),
])
def test_starts_with_and_ends_with_reject_non_string_operands(run, query, expected_err):
    """startsWith/endsWith validate every operand position and their arity."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: each operand position produces its own message naming the
    # function, the method form is reported through ast.ChainedExpr, and the
    # arity error reads "between 1 and 2" without the func-execution wrapper.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == expected_err


@pytest.mark.parametrize("query", ["has(true)", "has(1.5)"])
def test_has_rejects_non_string_int_arguments(run, query):
    """has() only accepts a string key or an integer index."""
    result = run(["-i", "json", query], stdin='{"a": 1}')
    # CATCHES: booleans and floats are rejected up front rather than being
    # coerced to a key, and the message does not echo the offending value.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: error execution func "has": '
        'has expects string or int argument\n')


@pytest.mark.parametrize("query,expected", [
    ('"a,b,c".split(",")', '[\n    "a",\n    "b",\n    "c"\n]\n'),
    ('"abc".split(",")', '[\n    "abc"\n]\n'),
    ('"abc".split("")', '[\n    "a",\n    "b",\n    "c"\n]\n'),
    ('split(",", "a,b,c")', '[\n    "a",\n    "b",\n    "c"\n]\n'),
])
def test_split(run, query, expected):
    """split cuts a string on a separator, or into runes when it is empty."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: an empty separator splits per character while a separator that
    # never occurs returns a single element.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ('replace("hello world", "world", "there")', '"hello there"\n'),
    ('replace("hello world", "o", "0")', '"hell0 w0rld"\n'),
    ('replace("hello world", "o", "0", "l", "1")', '"he110 w0r1d"\n'),
    ('"bob".replace("hello world", "o", "0", "world", "there")', '"hell0 there"\n'),
])
def test_replace_with_paired_arguments(run, query, expected):
    """replace takes alternating old/new pairs."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: pairs are applied in order and the method form still needs the
    # input string as the first argument.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ('trim("  hello  ")', '"hello"\n'),
    ('trim("\\n\\thello\\t\\n")', '"hello"\n'),
    ('trimPrefix("hello world", "hello ")', '"world"\n'),
    ('trimSuffix("hello world", " world")', '"hello"\n'),
])
def test_trim_family(run, query, expected):
    """Whitespace trimming from both ends or just one."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: trim removes every whitespace class including tabs and
    # newlines, and the prefix/suffix variants only strip one side.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,stdin,expected", [
    ('"  x  ".trim()', "null", '"x"\n'),
    ('"   ".trim()', "null", '""\n'),
    ("trim()", '"  hi  "', '"hi"\n'),
])
def test_trim_method_and_zero_argument_forms(run, query, stdin, expected):
    """trim works as a method and reads the document when argument-less."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: with no arguments the function trims the input document
    # instead, so a whitespace-only string trims all the way to the empty
    # string rather than being echoed.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ('1.trim()',
     "dasel: error: error executing selector: execution error when processing "
     "ast.ChainedExpr: error executing expression: execution error when "
     "processing ast.CallExpr: error executing function: error execution func "
     '"trim": trim expects data to be a string: unexpected type: expected '
     "string, got int\n"),
    ("trim(1)",
     "dasel: error: error executing selector: execution error when processing "
     "ast.CallExpr: error executing function: error execution func "
     '"trim": trim expects a string argument: unexpected type: expected '
     "string, got int\n"),
])
def test_trim_rejects_non_string_input(run, query, expected):
    """trim names which operand (data or argument) was the wrong type."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the method form blames the data (and is wrapped in an extra
    # ast.ChainedExpr layer) while the call form blames the argument, so the
    # message distinguishes where the int came from.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == expected


def test_trim_rejects_multiple_arguments(run):
    """trim accepts at most one argument."""
    result = run(["-i", "json", 'trim("a", "b")'], stdin="null")
    # CATCHES: the arity ceiling is one, phrased as "no more than 1
    # arguments" with the actual count echoed back.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: execution error when "
        'processing ast.CallExpr: error executing function: func "trim" '
        "expects no more than 1 arguments, got 2\n")


@pytest.mark.parametrize("query,expected", [
    ('"hello".trimPrefix("he")', '"llo"\n'),
    ('"hello".trimPrefix("x")', '"hello"\n'),
    ('"hello".trimPrefix("")', '"hello"\n'),
    ('"hello".trimSuffix("lo")', '"hel"\n'),
    ('"hello".trimSuffix("x")', '"hello"\n'),
    ('"hello".trimSuffix("")', '"hello"\n'),
])
def test_trim_prefix_and_suffix_method_forms(run, query, expected):
    """Method-form trimPrefix/trimSuffix take the needle as the argument."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the method form trims the receiver string, and a needle that
    # does not match (or the empty string) returns the input unchanged.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ('1.trimPrefix("a")',
     "dasel: error: error executing selector: execution error when processing "
     "ast.ChainedExpr: error executing expression: execution error when "
     "processing ast.CallExpr: error executing function: error execution func "
     '"trimPrefix": trimPrefix expects data to be a string: unexpected type: '
     "expected string, got int\n"),
    ('"hello".trimPrefix(1)',
     "dasel: error: error executing selector: execution error when processing "
     "ast.ChainedExpr: error executing expression: execution error when "
     "processing ast.CallExpr: error executing function: error execution func "
     '"trimPrefix": trimPrefix expects a string prefix as the first argument: '
     "unexpected type: expected string, got int\n"),
    ('trimPrefix(1, "a")',
     "dasel: error: error executing selector: execution error when processing "
     "ast.CallExpr: error executing function: error execution func "
     '"trimPrefix": trimPrefix expects a string as the first argument: '
     "unexpected type: expected string, got int\n"),
    ('trimPrefix("a", 1)',
     "dasel: error: error executing selector: execution error when processing "
     "ast.CallExpr: error executing function: error execution func "
     '"trimPrefix": trimPrefix expects a string prefix as the second '
     "argument: unexpected type: expected string, got int\n"),
])
def test_trim_prefix_rejects_non_string_operands(run, query, expected):
    """Each trimPrefix operand position has its own error message."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the message names the exact operand that failed — the document
    # data, the method-form prefix, or the first/second call-form argument —
    # and method-form failures carry the extra ast.ChainedExpr wrapper.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == expected


@pytest.mark.parametrize("query,expected", [
    ('1.trimSuffix("a")',
     "dasel: error: error executing selector: execution error when processing "
     "ast.ChainedExpr: error executing expression: execution error when "
     "processing ast.CallExpr: error executing function: error execution func "
     '"trimSuffix": trimSuffix expects data to be a string: unexpected type: '
     "expected string, got int\n"),
    ('"hello".trimSuffix(1)',
     "dasel: error: error executing selector: execution error when processing "
     "ast.ChainedExpr: error executing expression: execution error when "
     "processing ast.CallExpr: error executing function: error execution func "
     '"trimSuffix": trimSuffix expects a string suffix as the first argument: '
     "unexpected type: expected string, got int\n"),
    ('trimSuffix(1, "a")',
     "dasel: error: error executing selector: execution error when processing "
     "ast.CallExpr: error executing function: error execution func "
     '"trimSuffix": trimSuffix expects a string as the first argument: '
     "unexpected type: expected string, got int\n"),
    ('trimSuffix("a", 1)',
     "dasel: error: error executing selector: execution error when processing "
     "ast.CallExpr: error executing function: error execution func "
     '"trimSuffix": trimSuffix expects a string suffix as the second '
     "argument: unexpected type: expected string, got int\n"),
])
def test_trim_suffix_rejects_non_string_operands(run, query, expected):
    """Each trimSuffix operand position has its own error message."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: trimSuffix mirrors trimPrefix but says "suffix" in the
    # method-form message, while the two call-form positions stay "first" and
    # "second argument" just like the prefix variant.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == expected


@pytest.mark.parametrize("func", ["trimPrefix", "trimSuffix"])
def test_trim_prefix_and_suffix_arity(run, func):
    """trimPrefix/trimSuffix take one or two arguments, no more or less."""
    for query, count in [("%s()" % func, 0),
                         ('%s("a", "b", "c")' % func, 3)]:
        result = run(["-i", "json", query], stdin="null")
        # CATCHES: the arity error is phrased as "between 1 and 2 arguments"
        # and reports the actual argument count, so both the missing-needle
        # and the too-many-needles forms are distinguished.
        assert result.returncode == 1, query
        assert result.out == ""
        assert result.err == (
            "dasel: error: error executing selector: execution error when "
            'processing ast.CallExpr: error executing function: func "%s" '
            "expects between 1 and 2 arguments, got %d\n" % (func, count))


@pytest.mark.parametrize("query,expected", [
    ('toLower("Hello World")', '"hello world"\n'),
    ('toUpper("Hello World")', '"HELLO WORLD"\n'),
    ('"Hello World".toLower()', '"hello world"\n'),
    ('"Hello World".toUpper()', '"HELLO WORLD"\n'),
    ('"abc".toLower()', '"abc"\n'),
    ('"ABC".toUpper()', '"ABC"\n'),
])
def test_case_conversion(run, query, expected):
    """toLower/toUpper work as functions and as methods."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: both call forms are accepted and already-converted input is
    # returned unchanged.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ("[1,2,3,4,5]", "contains(3)", "true\n"),
    ("[1,2,3,4,5]", "contains(6)", "false\n"),
    ('"hello world"', 'startsWith($this, "hello")', "true\n"),
    ('"hello world"', 'endsWith($this, "world")', "true\n"),
    ('"hello"', 'indexOf($this, "l")', "2\n"),
    ('"hello"', 'indexOf($this, "z")', "-1\n"),
])
def test_membership_predicates(run, stdin, query, expected):
    """contains/startsWith/endsWith/indexOf answer membership questions."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: indexOf returns -1 (not null or an error) when the needle is
    # missing, and contains works on numbers not just strings.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_index_of_an_array_is_rejected(run):
    """indexOf insists on a string receiver."""
    result = run(["-i", "json", 'indexOf($this, "b")'], stdin='["a","b","c"]')
    # CATCHES: the argument order is (haystack, needle) and the haystack must
    # be a string; arrays are rejected with a type error.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: error execution func "indexOf": '
        'indexOf expects a string as the first argument: unexpected type: '
        'expected string, got array\n')


@pytest.mark.parametrize("query,expected", [
    ("unique([1, 2, 3])", '[\n    1,\n    2,\n    3\n]\n'),
    ("unique([1, 2, 2, 3, 1])", '[\n    1,\n    2,\n    3\n]\n'),
    ('unique(["a", "b", "a", "c"])', '[\n    "a",\n    "b",\n    "c"\n]\n'),
    ("[1, 1, 2].unique()", '[\n    1,\n    2\n]\n'),
])
def test_unique_deduplicates_preserving_first_occurrence(run, query, expected):
    """unique removes duplicates keeping the first occurrence."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: order is the first-seen order, not sorted, so `[1,2,2,3,1]`
    # stays `[1,2,3]` rather than being reordered.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("reverse([1, 2, 3])", '[\n    3,\n    2,\n    1\n]\n'),
    ("reverse(\"hello\")", '"olleh"\n'),
    ("[[1, 2], [3, 4]].flatten()", "[\n    1,\n    2,\n    3,\n    4\n]\n"),
    ("[1,2,3].first()", "1\n"),
    ("[1,2,3].last()", "3\n"),
    ("[1,2,3,4,5].get(3)", "4\n"),
    ('{"a": 3, "b": 4, "c": 5}.get("b")', "4\n"),
])
def test_array_helpers(run, query, expected):
    """reverse/flatten/first/last/get operate on arrays and strings."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: reverse accepts both a string and an array, get is overloaded
    # for index and key lookups, and first/last are zero-argument methods.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_reverse_requires_exactly_one_argument(run):
    """reverse() with no argument is an arity error."""
    result = run(["-i", "json", "reverse()"], stdin="[1,2,3]")
    # CATCHES: the arity error names the function and both counts, so `...`
    # style method calls without an explicit receiver are rejected.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: func "reverse" expects exactly '
        '1 arguments, got 0\n')


@pytest.mark.parametrize("query,expected", [
    ("abs(5)", "5\n"),
    ("abs(-5)", "5\n"),
    ("abs(3.14)", "3.14\n"),
    ("abs(-3.14)", "3.14\n"),
    ("(-5).abs()", "5\n"),
    ("ceil(3.2)", "4\n"),
    ("ceil(-3.7)", "-3\n"),
    ("ceil(5)", "5\n"),
    ("ceil(5.0)", "5\n"),
    ("(3.2).ceil()", "4\n"),
    ("floor(3.7)", "3\n"),
    ("(3.7).floor()", "3\n"),
    ("round(3.7)", "4\n"),
    ("round(3.5)", "4\n"),
    ("round(3.2)", "3\n"),
    ("round(-3.7)", "-4\n"),
    ("round(5)", "5\n"),
    ("(3.7).round()", "4\n"),
])
def test_rounding_and_absolute_value(run, query, expected):
    """abs/ceil/floor/round return integers for integer-ish results."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: whole number results are printed without a decimal point even
    # when the input was a float, and negative rounding goes away from zero.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("sum(1, 2, 3)", "6\n"),
    ("sum(1.1, 2.2, 3.3)", "6.6\n"),
    ("sum(-1, -2, -3)", "-6\n"),
    ("sum(-1.1, -2.2, -3.3)", "-6.6\n"),
    ("sum(1, 1.1)", "2.1\n"),
    ("avg(5)", "5\n"),
    ("avg(2, 4, 6)", "4\n"),
    ("avg(1.5, 2.5, 3.0)", "2.3333333333333335\n"),
    ("min(3, 1, 2)", "1\n"),
    ("max(3, 1, 2)", "3\n"),
    ("add(1, 2, 3)", "6\n"),
    ("add(1, 2f)", "3\n"),
    ("add(1f, 2.5, 3.5)", "7\n"),
])
def test_aggregating_arithmetic(run, query, expected):
    """sum/avg/min/max/add fold their arguments."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: mixing int and float promotes the result to a float only when
    # it is not whole, and avg of ints stays an int (`4`, not `4.0`).
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_add_with_a_spread_argument(run):
    """add() accepts a spread array of arguments."""
    result = run(["-i", "json", "add(nums.map($this + 1)...)"], stdin='{"nums": [1,2,3]}')
    # CATCHES: the `...` spread inside a call expands the mapped array into
    # positional arguments, so this sums 2+3+4.
    assert result.returncode == 0
    assert result.out == "9\n"
    assert result.err == ""

    result = run(["-i", "json", "add(nums.map($this + 1 - 2)...)"], stdin='{"nums": [1,2,3]}')
    assert result.returncode == 0
    assert result.out == "3\n"
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ('typeOf("hello")', '"string"\n'),
    ("typeOf(123)", '"int"\n'),
    ("typeOf(12.3)", '"float"\n'),
    ("typeOf(true)", '"bool"\n'),
    ("typeOf([])", '"array"\n'),
    ("typeOf({})", '"map"\n'),
    ("typeOf(null)", '"null"\n'),
])
def test_type_of(run, query, expected):
    """typeOf reports the model's type name for every literal kind."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the type vocabulary is `int`/`float`/`array`/`map` (not
    # `integer`/`double`/`list`/`object`).
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ('toBool("true")', "true\n"),
    ('toBool("false")', "false\n"),
    ('toBool("yes")', "true\n"),
    ('toBool("no")', "false\n"),
    ("toBool(true)", "true\n"),
    ("toBool(false)", "false\n"),
    ("toBool(1)", "true\n"),
    ("toBool(0)", "false\n"),
    ("toBool(null)", "false\n"),
    ('toInt("2")', "2\n"),
    ("toInt(1.1)", "1\n"),
    ("toInt(true)", "1\n"),
    ('toFloat("1.1")', "1.1\n"),
    ("toFloat(1)", "1\n"),
    ("toFloat(1.1)", "1.1\n"),
    ("toFloat(true)", "1\n"),
    ('toString("Hello")', '"Hello"\n'),
    ("toString(1)", '"1"\n'),
    ("toString(1.1)", '"1.1"\n'),
    ("toString(true)", '"true"\n'),
])
def test_type_conversions(run, query, expected):
    """toBool/toInt/toFloat/toString coerce between scalar types."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the string "yes"/"no" are boolean words, ints truncate floats
    # towards zero, and toString of a float keeps its shortest representation.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_stringify_and_parse_round_trip(run):
    """stringify serialises to a compact string; parse reads it back."""
    result = run(["-i", "json", 'stringify("json", {"a": 1})'], stdin="null")
    # CATCHES: stringify produces a JSON *string* value, so it is printed
    # quoted and escaped by the outer writer.
    assert result.returncode == 0
    assert result.out == '"{\\"a\\":1}"\n'
    assert result.err == ""

    result = run(["-i", "json", '{"a": 1}.stringify("json")'], stdin="null")
    assert result.returncode == 0
    assert result.out == '"{\\"a\\":1}"\n'
    assert result.err == ""

    result = run(["-i", "json", 'parse("json", stringify("json", {"a": 1})).a'], stdin="null")
    assert result.returncode == 0
    assert result.out == "1\n"
    assert result.err == ""

    result = run(["-i", "json", "parse('json', '{\"foo\":\"bar\"}').foo"], stdin="null")
    assert result.returncode == 0
    assert result.out == '"bar"\n'
    assert result.err == ""


def test_merge_deep_merges_nested_maps(run):
    """merge() deep merges later arguments over earlier ones."""
    result = run(["-i", "json", "-o", "json", 'merge({"a": {"x": 1, "y": 2}}, {"a": {"y": 3, "z": 4}})'],
                 stdin="null")
    # CATCHES: the merge is recursive, so `a` keeps `x`, takes the new `y` and
    # gains `z` rather than being replaced wholesale.
    assert result.returncode == 0
    assert result.out == '{\n    "a": {\n        "x": 1,\n        "y": 3,\n        "z": 4\n    }\n}\n'
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"x": 1}', 'has("x")', "true\n"),
    ('{"x": 1}', 'has("y")', "false\n"),
    ('{"x": 1}', 'has(1)', "false\n"),
    ("[1,2,3]", "has(0)", "true\n"),
    ("[1,2,3]", "has(-1)", "false\n"),
    ("[1,2,3]", "has(3)", "false\n"),
    ('[1,2,3]', 'has("foo")', "false\n"),
])
def test_has_checks_key_or_index_existence(run, stdin, query, expected):
    """has() answers whether a map key or array index exists."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: negative and out-of-range indices are simply absent (no error),
    # and a numeric argument against a map is also just absent.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_unknown_function_is_reported_with_its_name(run):
    """Calling an undefined function fails at execution time."""
    result = run(["-i", "json", "unknownFunc123()"], stdin="null")
    # CATCHES: the message quotes the function name, and the failure is an
    # execution error (exit 1) rather than a parse error.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error executing selector: error evaluating expression '
        'ast.CallExpr: unknown function: "unknownFunc123"\n')


@pytest.mark.parametrize("stdin,query,expected", [
    ('"hello"', 'indexOf("l")', "2\n"),
    ('"hello"', 'indexOf("z")', "-1\n"),
    ('"hello"', 'indexOf("")', "0\n"),
    ("null", '"hello".indexOf("l")', "2\n"),
    ("null", '"hello".indexOf("z")', "-1\n"),
    ("null", '"hello".indexOf("")', "0\n"),
])
def test_index_of_single_argument_forms(run, stdin, query, expected):
    """The one-argument form searches the document string for the argument."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: with a single argument the haystack comes from the current
    # value and the needle from the argument (both as a call on the string
    # document and as a method chain), and an empty needle matches at 0.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected_err", [
    ("indexOf()", 'func "indexOf" expects between 1 and 2 arguments, got 0'),
    ('indexOf("a", "b", "c")',
     'func "indexOf" expects between 1 and 2 arguments, got 3'),
])
def test_index_of_arity_errors(run, query, expected_err):
    """indexOf accepts one or two arguments only."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the arity guard fires before any value is read, so its message
    # is not wrapped in the "error execution func" chain.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: %s\n' % expected_err)


@pytest.mark.parametrize("query,expected_err", [
    # one-argument form: data is the haystack, argument is the needle
    ('indexOf("l")',
     "dasel: error: error executing selector: execution error when processing "
     'ast.CallExpr: error executing function: error execution func "indexOf": '
     "indexOf expects data to be a string: unexpected type: expected string, "
     "got null\n"),
    ('1.indexOf("a")',
     "dasel: error: error executing selector: execution error when processing "
     "ast.ChainedExpr: error executing expression: execution error when "
     'processing ast.CallExpr: error executing function: error execution func '
     '"indexOf": indexOf expects data to be a string: unexpected type: '
     "expected string, got int\n"),
    ('"hello".indexOf(1)',
     "dasel: error: error executing selector: execution error when processing "
     "ast.ChainedExpr: error executing expression: execution error when "
     'processing ast.CallExpr: error executing function: error execution func '
     '"indexOf": indexOf expects a string substring as the first argument: '
     "unexpected type: expected string, got int\n"),
    # two-argument form: first argument is the haystack, second the needle
    ('indexOf(1, "a")',
     "dasel: error: error executing selector: execution error when processing "
     'ast.CallExpr: error executing function: error execution func "indexOf": '
     "indexOf expects a string as the first argument: unexpected type: "
     "expected string, got int\n"),
    ('indexOf("a", 1)',
     "dasel: error: error executing selector: execution error when processing "
     'ast.CallExpr: error executing function: error execution func "indexOf": '
     "indexOf expects a string substring as the second argument: unexpected "
     "type: expected string, got int\n"),
])
def test_index_of_rejects_non_string_operands(run, query, expected_err):
    """Every operand position of indexOf has its own error wording."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the wording distinguishes the data position ("expects data to
    # be a string") from the call-argument positions, renames the first
    # argument between the one-argument ("substring") and two-argument
    # ("string") forms, and only the method form gains the extra
    # ast.ChainedExpr wrapper around the call error.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == expected_err


@pytest.mark.parametrize("query,expected", [
    ('toBool("1")', "true\n"),
    ('toBool("0")', "false\n"),
    ('toBool("")', "false\n"),
    ('toBool("YES")', "true\n"),
    ('toBool("True")', "true\n"),
    ("toBool(1.5)", "true\n"),
    ("toBool(0.0)", "false\n"),
    ("toBool(0.5)", "true\n"),
])
def test_to_bool_string_and_float_conversions(run, query, expected):
    """toBool also accepts numeric strings, case-insensitive words and floats."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the string lookup is lower-cased first and also accepts "1",
    # "0" and the empty string, while any non-zero float is true.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected_err", [
    ('toBool("maybe")', 'cannot convert string "maybe" to bool'),
    ("toBool([])", "cannot convert array to bool"),
    ("toBool({})", "cannot convert map to bool"),
])
def test_to_bool_rejects_unconvertible_values(run, query, expected_err):
    """Unrecognised strings and structured values cannot become bools."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the two failure wordings differ - strings quote the offending
    # value while structured values name their type - and both keep the
    # function's error wrapper.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: error execution func "toBool": '
        '%s\n' % expected_err)


@pytest.mark.parametrize("query,got", [
    ("toBool()", "0"),
    ("toBool(1, 2)", "2"),
])
def test_to_bool_requires_exactly_one_argument(run, query, got):
    """toBool rejects both the zero-argument and two-argument forms."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the arity check is "exactly 1", not a min/max pair, so both
    # missing and surplus arguments are reported the same way.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: func "toBool" expects exactly '
        '1 arguments, got %s\n' % got)


@pytest.mark.parametrize("query,expected", [
    ("floor(5)", "5\n"),
    ("floor(-5)", "-5\n"),
])
def test_floor_passes_integers_through(run, query, expected):
    """floor keeps an int an int instead of rounding a float copy."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: floor branches on the value's type before converting, so an
    # int argument comes back as an int (no float round-trip) and stays
    # negative when the value is negative.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("func_name", ["floor", "ceil", "round", "abs"])
def test_rounding_family_rejects_non_numeric_values(run, func_name):
    """floor/ceil/round/abs all report non-numeric input the same way."""
    result = run(["-i", "json", '%s("a")' % func_name], stdin="null")
    # CATCHES: each function names itself in the message and reports the
    # underlying type error ("expected float, got string") even though the
    # guard is about numeric-ness, not floats specifically.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: error execution func "%s": '
        '%s expects a numeric value: unexpected type: expected float, got '
        'string\n' % (func_name, func_name))
