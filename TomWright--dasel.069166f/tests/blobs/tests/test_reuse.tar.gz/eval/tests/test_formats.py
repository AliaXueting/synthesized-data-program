"""Cross-format reading and writing, ported from the native tests in
``src/internal/cli/generic_test.go`` and ``src/parsing/*/*_test.go``."""

import json

import pytest

JSON_DOC = """{
    "oneTwoThree": 123,
    "oneTwoDotThree": 12.3,
    "hello": "world",
    "boolFalse": false,
    "boolTrue": true,
    "stringFalse": "false",
    "stringTrue": "true",
    "sliceOfNumbers": [1, 2, 3, 4, 5],
    "mapData": {
        "oneTwoThree": 123,
        "hello": "world"
    }
}
"""

YAML_DOC = """oneTwoThree: 123
oneTwoDotThree: 12.3
hello: world
boolFalse: false
boolTrue: true
stringFalse: "false"
stringTrue: "true"
sliceOfNumbers:
- 1
- 2
- 3
- 4
- 5
mapData:
    oneTwoThree: 123
    hello: world
"""

TOML_DOC = """oneTwoThree = 123
oneTwoDotThree = 12.3
hello = 'world'
boolFalse = false
boolTrue = true
stringFalse = 'false'
stringTrue = 'true'
sliceOfNumbers = [1, 2, 3, 4, 5]

[mapData]
oneTwoThree = 123
hello = 'world'
"""

PLAIN_INPUTS = {
    "json": JSON_DOC,
    "yaml": YAML_DOC,
    "toml": TOML_DOC,
}


@pytest.mark.parametrize("in_format,doc", [
    ("json", JSON_DOC),
    ("yaml", YAML_DOC),
    ("toml", TOML_DOC),
])
def test_select_hello_across_input_formats(run, in_format, doc):
    """Selecting a string from json, yaml and toml documents."""
    result = run(["-i", in_format, "-o", "json", "hello"], stdin=doc)
    # CATCHES: every reader normalises to the same model, so the selected
    # value is written identically by the json writer regardless of the input
    # format; without -o the output format would follow the input format.
    assert result.returncode == 0
    assert result.out == '"world"\n'
    assert result.err == ""


@pytest.mark.parametrize("in_format,doc", [
    ("json", JSON_DOC),
    ("yaml", YAML_DOC),
    ("toml", TOML_DOC),
])
def test_select_int_float_bool_across_formats(run, in_format, doc):
    """Numeric and boolean leaves keep their types through every reader."""
    for key, expected in [("oneTwoThree", "123\n"),
                          ("oneTwoDotThree", "12.3\n"),
                          ("boolTrue", "true\n"),
                          ("boolFalse", "false\n")]:
        result = run(["-i", in_format, "-o", "json", key], stdin=doc)
        # CATCHES: yaml quoting does not turn scalars into strings, and toml
        # single quotes likewise preserve the underlying type.
        assert result.returncode == 0
        assert result.out == expected, key
        assert result.err == ""


@pytest.mark.parametrize("prefix", ["", "mapData."])
def test_nested_prefix_selection(run, prefix):
    """Selecting through one level of nesting."""
    result = run(["-i", "json", prefix + "hello"], stdin=JSON_DOC)
    # CATCHES: the dot path works both from the root and from a nested map.
    assert result.returncode == 0
    assert result.out == '"world"\n'
    assert result.err == ""


@pytest.mark.parametrize("in_format,doc", [
    ("json", JSON_DOC),
    ("yaml", YAML_DOC),
])
def test_string_scalars_stay_strings(run, in_format, doc):
    """A quoted "true" must not become a boolean."""
    result = run(["-i", in_format, "-o", "json", "stringTrue"], stdin=doc)
    # CATCHES: the yaml reader tracks that the scalar was quoted so the value
    # round trips as a string, which is why the output differs by format.
    assert result.returncode == 0
    assert result.out == '"true"\n'
    assert result.err == ""


def test_toml_string_scalars_use_single_quotes(run):
    """The toml writer quotes strings with single quotes."""
    result = run(["-i", "toml", "-o", "toml", "stringTrue"], stdin=TOML_DOC)
    # CATCHES: toml output uses 'single' quotes, unlike the json/yaml writers.
    assert result.returncode == 0
    assert result.out == "'true'\n"
    assert result.err == ""


def test_plain_writer_drops_the_quotes(run):
    """The plain writer emits the scalar with no quoting at all."""
    result = run(["-i", "json", "-o", "plain", "stringTrue"], stdin=JSON_DOC)
    # CATCHES: `plain` unwraps the string so `"true"` becomes `true`, which is
    # exactly why it is a write-only format.
    assert result.returncode == 0
    assert result.out == "true\n"
    assert result.err == ""

    result = run(["-i", "json", "-o", "plain", "hello"], stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.out == "world\n"
    assert result.err == ""


def test_plain_writer_rejects_structures(run):
    """The plain writer can only represent scalars."""
    result = run(["-i", "json", "-o", "plain", "sliceOfNumbers"], stdin=JSON_DOC)
    # CATCHES: arrays are rejected with a specific message and exit code 1,
    # with nothing written to stdout first.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: plain can only represent scalar "
        "values, got array\n")


def test_plain_writer_reports_the_failing_document(run):
    """Multi document plain output names the failing document index."""
    result = run(["-i", "yaml", "-o", "plain", "$root"], stdin="a: 1\n---\nb: 2\n")
    # CATCHES: the document index in the message is zero based.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error writing output: failed to write document 0: "
        "plain can only represent scalar values, got map\n")


def test_yaml_writer_preserves_reader_quoting(run):
    """A yaml-read string is re-quoted; a json-read one is not."""
    from_yaml = run(["-i", "yaml", "-o", "yaml", "$root"], stdin='a: "x"\nb: 1\n')
    # CATCHES: the yaml reader records that `x` was quoted and the yaml writer
    # honours that metadata, while json input loses it.
    assert from_yaml.returncode == 0
    assert from_yaml.out == 'a: "x"\nb: 1\n'
    assert from_yaml.err == ""

    from_json = run(["-i", "json", "-o", "yaml", "$root"], stdin='{"a": "x", "b": 1}')
    assert from_json.returncode == 0
    assert from_json.out == "a: x\nb: 1\n"
    assert from_json.err == ""


def test_yaml_writer_indents_sequences(run):
    """The yaml writer indents nested sequences by four spaces."""
    result = run(["-i", "json", "-o", "yaml", "$root"],
                 stdin='{"a": "x", "b": 1, "c": [1, 2], "d": {"e": null}}')
    # CATCHES: sequences are written with a four space hanging indent and
    # nulls are written as the bare word `null`.
    assert result.returncode == 0
    assert result.out == """a: x
b: 1
c:
    - 1
    - 2
d:
    e: null
"""
    assert result.err == ""


def test_yaml_reader_understands_number_bases(run):
    """Hex/octal/binary/underscored yaml numbers decode to ints."""
    result = run(["-i", "yaml", "-o", "json", "$root"],
                 stdin="a: 0x1f\nb: 0o17\nc: 0b101\nd: 1_000\n")
    # CATCHES: yaml 1.2 number bases are honoured by the reader and the values
    # come out as plain decimal ints.
    assert result.returncode == 0
    assert result.out == """{
    "a": 31,
    "b": 15,
    "c": 5,
    "d": 1000
}
"""
    assert result.err == ""


def test_yaml_aliases_are_resolved_on_read(run):
    """YAML anchors and aliases are dereferenced by the reader."""
    result = run(["-i", "yaml", "-o", "yaml", "$root"],
                 stdin="name: &name Tom\nname2: *name\n")
    # CATCHES: the anchor is dropped and the alias is replaced by the value, so
    # the written document has no anchor syntax at all.
    assert result.returncode == 0
    assert result.out == "name: Tom\nname2: Tom\n"
    assert result.err == ""


def test_yaml_round_trip_is_byte_stable(run):
    """A canonical yaml document survives a read/write cycle unchanged."""
    doc = """str: foo
int: 1
float: 1.1
bool: true
map:
    key: value
list:
    - item1
    - item2
"""
    result = run(["-i", "yaml", "-o", "yaml", "$root"], stdin=doc)
    # CATCHES: the writer's own normalisation is idempotent for this shape,
    # including the four space sequence indent.
    assert result.returncode == 0
    assert result.out == doc
    assert result.err == ""


@pytest.mark.parametrize("in_format,doc,expected", [
    ("yaml", "a: 1\n---\nb: 2\n", "a: 1\n---\nb: 2\n---\na: 1\n---\nb: 2\n"),
    ("json", '{"a": 1}\n{"b": 2}\n', '{\n    "a": 1\n}\n\n{\n    "b": 2\n}\n\n{\n    "a": 1\n}\n\n{\n    "b": 2\n}\n'),
])
def test_multiple_documents_are_read_and_written(run, in_format, doc, expected):
    """Multi document input produces multi document output."""
    result = run(["-i", in_format, "-o", "yaml" if in_format == "yaml" else "json", "$root"],
                 stdin=doc)
    # CATCHES: documents are written in order and separated by `---` for yaml
    # but by a blank line for json, and every document is echoed once.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_toml_writer_uses_table_headers_for_nested_maps(run):
    """Nested maps become [table] sections."""
    result = run(["-i", "json", "-o", "toml", "$root"], stdin='{"a": "x", "tbl": {"y": 1}}')
    # CATCHES: a blank line separates the top level keys from the first table
    # header, and the header is unquoted when the key is plain.
    assert result.returncode == 0
    assert result.out == "a = 'x'\n\n[tbl]\ny = 1\n"
    assert result.err == ""


def test_toml_writer_quotes_keys_that_need_it(run):
    """Keys containing dots are single quoted."""
    result = run(["-i", "toml", "-o", "toml", "$root"],
                 stdin='"a.b" = 1\na.b = 2\na."b.c" = 3\n')
    # CATCHES: dotted keys are expanded into nested tables on read, so the
    # writer emits `[a]` for the second and third keys, and only a key that
    # cannot be expressed as a path stays quoted.
    assert result.returncode == 0
    assert result.out == "'a.b' = 1\n\n[a]\nb = 2\n'b.c' = 3\n"
    assert result.err == ""


def test_toml_inline_table_is_promoted_to_a_header(run):
    """An inline table followed by an explicit table is merged."""
    result = run(["-i", "toml", "-o", "toml", "$root"], stdin="t = {a = 1}\n[t]\nb = 2")
    # CATCHES: the reader merges the inline table with the explicit one and
    # the writer always chooses the header form.
    assert result.returncode == 0
    assert result.out == "[t]\na = 1\nb = 2\n"
    assert result.err == ""


def test_toml_dates_become_strings(run):
    """Local dates survive only as strings."""
    result = run(["-i", "toml", "-o", "toml", "$root"], stdin="d = 1979-05-27")
    # CATCHES: the toml reader has no date type, so the value round trips as a
    # quoted string rather than a native date.
    assert result.returncode == 0
    assert result.out == "d = '1979-05-27'\n"
    assert result.err == ""


def test_toml_writer_root_scalar_values(run):
    """Non-table roots are written as bare toml values."""
    for stdin, expected in [('"world"', "'world'\n"),
                            ('"it\'s \\"here\\""', '"it\'s \\"here\\""\n'),
                            ("123", "123\n"),
                            ("-5", "-5\n"),
                            ("12.3", "12.3\n"),
                            ("true", "true\n"),
                            ("false", "false\n"),
                            ("[]", "[]\n"),
                            ("[1,2]", "[1, 2]\n"),
                            ('["a"]', "['a']\n"),
                            ("[[1],[]]", "[[1], []]\n"),
                            ('[{"a":1},{"a":2}]', "[{a = 1}, {a = 2}]\n")]:
        result = run(["-i", "json", "-o", "toml", "$root"], stdin=stdin)
        # CATCHES: a string containing both quote styles switches to basic
        # (double) quoting with escapes, and arrays are written inline with a
        # space after each comma regardless of --compact.
        assert result.returncode == 0
        assert result.out == expected, stdin
        assert result.err == ""


def test_toml_writer_rejects_a_null_root(run):
    """A null root value cannot be encoded as toml."""
    result = run(["-i", "json", "-o", "toml", "$root"], stdin="null")
    # CATCHES: the failure happens while writing, so it is wrapped in
    # `error writing output` rather than `error executing selector`.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error writing output: toml encode failed: "
        "toml: cannot encode a nil interface\n")


def test_toml_reader_accepts_trailing_commas(run):
    """A trailing comma in a toml array is allowed."""
    result = run(["-i", "toml", "-o", "toml", "$root"], stdin="arr = [1,2,]")
    # CATCHES: the reader tolerates the trailing comma and the writer drops it.
    assert result.returncode == 0
    assert result.out == "arr = [1, 2]\n"
    assert result.err == ""


@pytest.mark.parametrize("stdin,expected", [
    ("[[fruit]]\nname = \"apple\"\n\n[[fruit]]\nname = \"banana\"\n",
     '{\n    "fruit": [\n        {\n            "name": "apple"\n        },'
     "\n        {\n            \"name\": \"banana\"\n        }\n    ]\n}\n"),
    ("[[a.b]]\nx = 1\n",
     '{\n    "a": {\n        "b": [\n            {\n                "x": 1\n            }\n        ]\n    }\n}\n'),
])
def test_toml_reader_array_tables(run, stdin, expected):
    """Repeated [[array]] headers collect into a slice of maps."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: every [[header]] appends a fresh map to the slice at that path,
    # creating intermediate maps for dotted header paths as needed.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_toml_reader_array_tables_round_trip(run):
    """Array tables are re-emitted as [[headers]], not inline arrays."""
    result = run(["-i", "toml", "-o", "toml", "$root"],
                 stdin='[[fruit]]\nname = "apple"\n\n[[fruit]]\nname = "banana"\n')
    # CATCHES: the reader tags the slice as array-of-tables so the writer uses
    # repeated [[fruit]] headers instead of an inline array of inline tables.
    assert result.returncode == 0
    assert result.out == "[[fruit]]\nname = 'apple'\n\n[[fruit]]\nname = 'banana'\n"
    assert result.err == ""


def test_toml_reader_inline_table_arrays_become_array_tables(run):
    """An inline array of inline tables is promoted on the round trip."""
    result = run(["-i", "toml", "-o", "toml", "$root"], stdin="a = [{b = 1}, {c = 2}]\n")
    # CATCHES: array elements are tagged like array tables, so even the inline
    # input form is rewritten with [[a]] headers by the writer.
    assert result.returncode == 0
    assert result.out == "[[a]]\nb = 1\n\n[[a]]\nc = 2\n"
    assert result.err == ""


def test_toml_reader_table_after_array_table_merges_into_the_last_item(run):
    """A [table] header on an existing array table targets its last element."""
    result = run(["-i", "toml", "-o", "json", "$root"],
                 stdin="[[a]]\nx = 1\n\n[a.b]\ny = 2\n")
    # CATCHES: the reader descends into the last slice element for [a.b], so
    # the sub-table nests inside the array item instead of replacing it.
    assert result.returncode == 0
    assert result.out == (
        '{\n    "a": [\n        {\n            "x": 1,\n            "b": {\n'
        '                "y": 2\n            }\n        }\n    ]\n}\n')
    assert result.err == ""


@pytest.mark.parametrize("stdin,expected", [
    ("a.b.c = 1\n",
     '{\n    "a": {\n        "b": {\n            "c": 1\n        }\n    }\n}\n'),
    ("[t]\nx.y = 1\n",
     '{\n    "t": {\n        "x": {\n            "y": 1\n        }\n    }\n}\n'),
    ("a.b = 1\na.c = 2\n",
     '{\n    "a": {\n        "b": 1,\n        "c": 2\n    }\n}\n'),
    ("[t]\na.b = 1\na.c = 2\n",
     '{\n    "t": {\n        "a": {\n            "b": 1,\n            "c": 2\n        }\n    }\n}\n'),
])
def test_toml_reader_dotted_keys_nest_maps(run, stdin, expected):
    """Dotted keys create intermediate maps at the root and inside tables."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: repeated dotted keys merge into the same intermediate map
    # instead of overwriting each other, both at the root and under a table.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,expected", [
    ('["a.b"]\nc = 1\n', '{\n    "a.b": {\n        "c": 1\n    }\n}\n'),
    ("['a b']\nc = 1\n", '{\n    "a b": {\n        "c": 1\n    }\n}\n'),
    ('[""]\nc = 1\n', '{\n    "": {\n        "c": 1\n    }\n}\n'),
])
def test_toml_reader_quoted_table_headers_stay_single_keys(run, stdin, expected):
    """A quoted table header names one key, never a dotted path."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: quoting disables dot splitting, so `["a.b"]` is a single map
    # key containing a dot rather than a nested a -> b path.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,expected", [
    ('["a.b"]\nc = 1\n', "['a.b']\nc = 1\n"),
    ("['a b']\nc = 1\n", "['a b']\nc = 1\n"),
    ('[""]\nc = 1\n', "['']\nc = 1\n"),
])
def test_toml_reader_quoted_headers_round_trip_single_quoted(run, stdin, expected):
    """The writer reproduces quoted headers using single quotes."""
    result = run(["-i", "toml", "-o", "toml", "$root"], stdin=stdin)
    # CATCHES: the header quoting is recorded on read and re-emitted with the
    # writer's single-quote style even when the input used double quotes.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,message", [
    ("a = 1\n[a.b]\n", "conflicting types at path 'a': expected map"),
    ("a = 1\n[[a]]\n", "conflicting types at path 'a': expected slice"),
    ("[a]\nx = 1\n\n[[a]]\n", "conflicting types at path 'a': expected slice"),
])
def test_toml_reader_conflicting_types_are_errors(run, stdin, message):
    """A header cannot redefine a key that already holds another type."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: the reader rejects [table]/[[array]] headers that clash with an
    # existing scalar or table, distinguishing the expected map/slice types.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == "dasel: error: error reading input: %s\n" % message


@pytest.mark.parametrize("stdin,expected", [
    ("a = 0xdeadBEEF\n", "{\n    \"a\": 3735928559\n}\n"),
    ("a = 0o755\n", "{\n    \"a\": 493\n}\n"),
    ("a = 0b1101\n", "{\n    \"a\": 13\n}\n"),
    ("a = 1_000_000\n", "{\n    \"a\": 1000000\n}\n"),
    ("a = +5\n", "{\n    \"a\": 5\n}\n"),
    ("a = -0\n", "{\n    \"a\": 0\n}\n"),
])
def test_toml_reader_integer_forms(run, stdin, expected):
    """Hex, octal, binary, underscore and signed integers all parse."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: integers are parsed with a base-0 strconv so prefixes and
    # digit separators resolve to plain decimal numbers in the model.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,message", [
    ("a = 9223372036854775808\n",
     'strconv.ParseInt: parsing "9223372036854775808": value out of range'),
    ("f = 1e999\n",
     'strconv.ParseFloat: parsing "1e999": value out of range'),
])
def test_toml_reader_out_of_range_numbers(run, stdin, message):
    """Numbers beyond the 64-bit range fail at read time."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: the raw strconv error surfaces verbatim, so an int64 overflow
    # and a float64 overflow are told apart by the function named inside.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == "dasel: error: error reading input: %s\n" % message


@pytest.mark.parametrize("stdin,expected", [
    ("t = 07:32:00\n", "{\n    \"t\": \"07:32:00\"\n}\n"),
    ("dt = 1979-05-27T07:32:00\n", "{\n    \"dt\": \"1979-05-27T07:32:00\"\n}\n"),
    ("dt = 1979-05-27T07:32:00Z\n", "{\n    \"dt\": \"1979-05-27T07:32:00Z\"\n}\n"),
])
def test_toml_reader_temporal_values_become_strings(run, stdin, expected):
    """Times and datetimes have no dedicated model type and stay strings."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: local times, local datetimes and offset datetimes all round
    # trip as their raw text, keeping the trailing Z of the offset form.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,json_expected", [
    ("a = '''\nline1\nline2'''\n", "{\n    \"a\": \"line1\\nline2\"\n}\n"),
    ("a = \"\"\"\nline1\nline2\"\"\"\n", "{\n    \"a\": \"line1\\nline2\"\n}\n"),
])
def test_toml_reader_multiline_strings_join_with_newlines(run, stdin, json_expected):
    """Multiline literal and basic strings keep their embedded newlines."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: both multiline quotes styles decode to one string containing
    # real newline characters, with no leading newline kept from the opener.
    assert result.returncode == 0
    assert result.out == json_expected
    assert result.err == ""


def test_toml_reader_multiline_strings_round_trip_as_basic(run):
    """Multiline strings are re-emitted with the basic triple-quote style."""
    result = run(["-i", "toml", "-o", "toml", "$root"],
                 stdin="a = '''\nline1\nline2'''\n")
    # CATCHES: the writer normalizes both multiline styles to \"\"\" basic
    # strings, so a literal ''' input is rewritten with double quotes.
    assert result.returncode == 0
    assert result.out == "a = \"\"\"\nline1\nline2\"\"\"\n"
    assert result.err == ""


@pytest.mark.parametrize("stdin,expected", [
    ("a = \n", "{}\n"),
    ("a\n", "{}\n"),
    ("# just a comment\n", "{}\n"),
])
def test_toml_reader_skips_invalid_or_empty_expressions(run, stdin, expected):
    """Incomplete key/value lines are dropped rather than erroring."""
    result = run(["-i", "toml", "-o", "json", "$root"], stdin=stdin)
    # CATCHES: a dangling key or a valueless assignment is silently skipped,
    # leaving an empty document instead of a parse error.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_csv_reader_builds_rows_from_the_header(run):
    """CSV input becomes an array of maps keyed by the header row."""
    result = run(["-i", "csv", "-o", "json", "$root"], stdin="name,age\nAlice,30\nBob,25\n")
    # CATCHES: every cell is a string, including numbers, so `age` is `"30"`.
    assert result.returncode == 0
    assert result.out == """[
    {
        "name": "Alice",
        "age": "30"
    },
    {
        "name": "Bob",
        "age": "25"
    }
]
"""
    assert result.err == ""


def test_csv_writer_writes_a_header_row(run):
    """CSV output re-derives the header from the first row."""
    result = run(["-i", "json", "-o", "csv", "$root"], stdin='[{"name": "Alice", "age": "30"}]')
    # CATCHES: the column order follows the first row's key order and the file
    # ends with a newline after the last record.
    assert result.returncode == 0
    assert result.out == "name,age\nAlice,30\n"
    assert result.err == ""


def test_csv_writer_quotes_fields_containing_the_delimiter(run):
    """A field containing a comma is quoted."""
    result = run(["-i", "csv", "-o", "csv", "$root"],
                 stdin='name,note\nAlice,"hello, world"\n')
    # CATCHES: the round trip preserves the quoting needed for the embedded
    # comma, so the output is byte identical to the input.
    assert result.returncode == 0
    assert result.out == 'name,note\nAlice,"hello, world"\n'
    assert result.err == ""


def test_csv_header_only_input_is_an_empty_array(run):
    """A CSV file with no data rows reads as an empty array."""
    result = run(["-i", "csv", "-o", "json", "$root"], stdin="name,age\n")
    # CATCHES: the header alone produces `[]` rather than an array containing
    # an empty map.
    assert result.returncode == 0
    assert result.out == "[]\n"
    assert result.err == ""


def test_csv_delimiter_read_write_flag(run):
    """--rw-flag csv-delimiter applies to both reader and writer."""
    result = run(["-i", "csv", "-o", "csv", "--rw-flag", "csv-delimiter=;", "$root"],
                 stdin="name;age\nAlice;30\n")
    # CATCHES: the single flag drives both directions, so the output uses the
    # same custom delimiter as the input.
    assert result.returncode == 0
    assert result.out == "name;age\nAlice;30\n"
    assert result.err == ""

    multi = run(["-i", "csv", "-o", "json", "--rw-flag", "csv-delimiter=§", "$root"],
                stdin="name§age\nAlice§30\n")
    assert multi.returncode == 0
    assert multi.out == '[\n    {\n        "name": "Alice",\n        "age": "30"\n    }\n]\n'
    assert multi.err == ""


def test_csv_delimiter_must_be_a_single_character(run):
    """A multi character csv-delimiter is rejected while building the reader."""
    result = run(["-i", "csv", "--rw-flag", "csv-delimiter=;;", "$root"], stdin="name,age\n")
    # CATCHES: the validation happens up front (before reading stdin) and the
    # message quotes the offending value.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: failed to get input reader: csv-delimiter must be a '
        'single character, got ";;"\n')


def test_csv_values_are_strings_so_numeric_filters_fail(run):
    """Comparing a CSV cell to a number is a type error."""
    result = run(["-i", "csv", "filter(age > 26)"], stdin="name,age\nAlice,30\nBob,25\n")
    # CATCHES: because every CSV cell is a string, `age > 26` reports
    # incompatible types rather than filtering rows.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.FilterExpr: error ranging over slice: execution error when processing "
        "ast.BinaryExpr: incompatible types: string and int\n")


def test_csv_writer_requires_a_slice_root(run):
    """The CSV writer cannot write a scalar."""
    result = run(["-i", "csv", "$this[0].name"], stdin="name,age\nAlice,30\n")
    # CATCHES: the query succeeds but the writer rejects the string result, so
    # the error is about writing, not executing.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error writing output: csv writer expects root output to "
        "be a slice/array, got string\n")


def test_xml_reader_wraps_the_document_element(run):
    """XML input becomes a map keyed by the root element name."""
    result = run(["-i", "xml", "-o", "json", "$root"],
                 stdin="<root><name>Tom</name><age>27</age></root>")
    # CATCHES: element text is always a string, so `27` is quoted, and the
    # document element itself becomes the outer map key.
    assert result.returncode == 0
    assert result.out == """{
    "root": {
        "name": "Tom",
        "age": "27"
    }
}
"""
    assert result.err == ""


def test_xml_writer_indents_with_two_spaces(run):
    """The XML writer uses a two space indent and self-closes nothing."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin='{"root": {"name": "Tom"}}')
    # CATCHES: the indent is two spaces (unlike json's four) and there is no
    # trailing XML declaration.
    assert result.returncode == 0
    assert result.out == "<root>\n  <name>Tom</name>\n</root>\n"
    assert result.err == ""


def test_xml_structured_read_flag(run):
    """--read-flag xml-mode=structured exposes a node tree instead."""
    result = run(["-i", "xml", "-o", "json", "--read-flag", "xml-mode=structured", "$root"],
                 stdin='<root><item id="1">a</item></root>')
    # CATCHES: structured mode returns name/attrs/content/children nodes, the
    # document element is nested one level down, and attributes become a map.
    assert result.returncode == 0
    assert result.out == """{
    "name": "root",
    "attrs": {},
    "content": "",
    "children": [
        {
            "name": "root",
            "attrs": {},
            "content": "",
            "children": [
                {
                    "name": "item",
                    "attrs": {
                        "id": "1"
                    },
                    "content": "a",
                    "children": []
                }
            ]
        }
    ]
}
"""
    assert result.err == ""


def test_ini_reader_groups_sections(run):
    """INI sections become nested maps and values stay strings."""
    result = run(["-i", "ini", "-o", "json", "$root"], stdin="[owner]\nname = Tom\nage = 27\n")
    # CATCHES: keys are lowercased as written and both values are strings.
    assert result.returncode == 0
    assert result.out == """{
    "owner": {
        "name": "Tom",
        "age": "27"
    }
}
"""
    assert result.err == ""


def test_hcl_reader_nests_blocks(run):
    """HCL blocks become nested maps keyed by label."""
    result = run(["-i", "hcl", "-o", "json", "$root"],
                 stdin='resource "aws_instance" "example" {\n  ami = "ami-123"\n}\n')
    # CATCHES: a labelled block nests one map per label, so the three-level
    # path is resource > aws_instance > example.
    assert result.returncode == 0
    assert result.out == """{
    "resource": {
        "aws_instance": {
            "example": {
                "ami": "ami-123"
            }
        }
    }
}
"""
    assert result.err == ""


KDL_DOC = 'hello "world"\noneTwoThree 123\noneTwoDotThree 12.3\nboolTrue #true\nboolFalse #false'


def test_kdl_reader_builds_a_map_from_nodes(run):
    """Top level KDL nodes become map keys with their single argument."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin=KDL_DOC)
    # CATCHES: KDL booleans use the `#true` spelling but decode to real
    # booleans, and numbers keep their int/float distinction.
    assert result.returncode == 0
    assert result.out == """{
    "hello": "world",
    "oneTwoThree": 123,
    "oneTwoDotThree": 12.3,
    "boolTrue": true,
    "boolFalse": false
}
"""
    assert result.err == ""


def test_kdl_writer_uses_hash_prefixed_booleans(run):
    """JSON round trips into KDL node syntax."""
    result = run(["-i", "json", "-o", "kdl", "$root"], stdin="""{
    "hello": "world",
    "oneTwoThree": 123,
    "oneTwoDotThree": 12.3,
    "boolTrue": true,
    "boolFalse": false
}""")
    # CATCHES: each map key becomes a node name and booleans are written back
    # with the `#` prefix, while strings and numbers are written bare.
    assert result.returncode == 0
    assert result.out == KDL_DOC + "\n"
    assert result.err == ""


def test_kdl_child_nodes_nest(run):
    """A KDL node with a body nests as a map."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin='root {\n    child "value"\n}\n')
    # CATCHES: node bodies become nested maps keyed by the child node name.
    assert result.returncode == 0
    assert result.out == '{\n    "root": {\n        "child": "value"\n    }\n}\n'
    assert result.err == ""


def test_kdl_writer_wraps_a_scalar_in_a_root_node(run):
    """A scalar result is written as a `root` node argument."""
    result = run(["-i", "kdl", "hello"], stdin=KDL_DOC)
    # CATCHES: KDL has no bare scalar document, so the selected string is
    # written as `root "world"` rather than just `"world"`.
    assert result.returncode == 0
    assert result.out == 'root "world"\n'
    assert result.err == ""


def test_kdl_select_from_json_and_yaml_sources(run):
    """KDL, JSON and YAML documents select identically."""
    json_doc = '{"hello": "world", "oneTwoThree": 123, "oneTwoDotThree": 12.3, "boolTrue": true, "boolFalse": false}'
    yaml_doc = ("hello: world\noneTwoThree: 123\noneTwoDotThree: 12.3\n"
                "boolTrue: true\nboolFalse: false")
    for in_format, doc in [("kdl", KDL_DOC), ("json", json_doc), ("yaml", yaml_doc)]:
        result = run(["-i", in_format, "-o", "json", "oneTwoDotThree"], stdin=doc)
        # CATCHES: the kdl reader's argument typing matches what json and yaml
        # produce for the same document, so all three select to `12.3`.
        assert result.returncode == 0
        assert result.out == "12.3\n", in_format
        assert result.err == ""


def test_unsupported_input_format_is_rejected_before_reading(run):
    """An unknown -i value fails before stdin is consumed."""
    result = run(["-i", "nope", "$root"], stdin='{"a": 1}')
    # CATCHES: the reader is constructed before parsing, so the message names
    # the reader and the format verbatim.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: failed to get input reader: "
        "unsupported reader file format: nope\n")


def test_unsupported_output_format_is_rejected_after_the_reader(run):
    """An unknown -o value fails after the reader is built."""
    result = run(["-i", "json", "-o", "nope", "$root"], stdin='{"a": 1}')
    # CATCHES: reader construction succeeds first, so the failure is reported
    # against the writer - the mirror image of the -i failure.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: failed to get output writer: "
        "unsupported writer file format: nope\n")


def test_json_writer_does_not_escape_html_by_default(run):
    """Angle brackets and ampersands are written literally."""
    result = run(["-i", "json", "-o", "json", "$root"], stdin='{"a": "<b>&x</b>"}')
    # CATCHES: the default json writer does not HTML escape, unlike Go's
    # encoding/json default.
    assert result.returncode == 0
    assert result.out == '{\n    "a": "<b>&x</b>"\n}\n'
    assert result.err == ""


def test_json_escape_html_write_flag(run):
    """--write-flag json-escape=html turns on HTML escaping."""
    result = run(["-i", "json", "-o", "json", "--write-flag", "json-escape=html", "$root"],
                 stdin='{"a": "<b>&x</b>"}')
    # CATCHES: the flag only affects the writer, and the escapes are the
    # lowercase Go ones (<, >, &).
    assert result.returncode == 0
    assert result.out == '{\n    "a": "\\u003cb\\u003e\\u0026x\\u003c/b\\u003e"\n}\n'
    assert result.err == ""


def test_json_number_formatting(run):
    """Exponents and trailing `.0` are normalised on output."""
    result = run(["-i", "json", "-o", "json", "--compact", "$root"],
                 stdin='{"a": 1e10, "b": 0.1, "d": 1.0, "e": 1e-7}')
    # CATCHES: `1e10` expands to a plain integer, `1.0` collapses to `1`, but
    # `1e-7` keeps Go's exponent form with two digits.
    assert result.returncode == 0
    assert result.out == '{"a":10000000000,"b":0.1,"d":1,"e":1e-07}\n'
    assert result.err == ""


def test_json_preserves_key_order_and_big_ints(run):
    """Document key order and int64 values survive the round trip."""
    result = run(["-i", "json", "-o", "json", "--compact", "$root"],
                 stdin='{"z": 1, "a": 2, "m": 3, "big": 9223372036854775807}')
    # CATCHES: keys are never sorted and int64 max round trips exactly rather
    # than degrading to a float.
    assert result.returncode == 0
    assert result.out == '{"z":1,"a":2,"m":3,"big":9223372036854775807}\n'
    assert result.err == ""


def test_json_reader_rejects_out_of_range_integers(run):
    """An integer beyond int64 fails with the strconv error."""
    result = run(["-i", "json", "$root"], stdin='{"a": 100000000000000000000}')
    # CATCHES: the message is the raw strconv error, wrapped only by
    # `could not decode object`.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error reading input: could not decode object: '
        'strconv.ParseInt: parsing "100000000000000000000": value out of range\n')


def test_json_reader_rejects_trailing_content(run):
    """Content after the first JSON value is an error."""
    result = run(["-i", "json", "$root"], stdin='{"a": 1} extra')
    # CATCHES: the reader does not silently ignore trailing garbage.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error reading input: json: invalid character e as token\n")


def test_kdl_writer_maps_scalars_props_and_children(run):
    """$args become node arguments, scalars properties, maps child blocks."""
    result = run(["-i", "json", "-o", "kdl", "$root"],
                 stdin='{"n": {"$args": [9], "k": "v", "child": {"x": 1}}}')
    # CATCHES: a map value is written as one node whose arguments come from
    # the `$args` key, scalar keys become `key=value` properties and nested
    # maps become an indented `{ ... }` body with a two space indent.
    assert result.returncode == 0
    assert result.out == 'n 9 k="v" {\n  child x=1\n}\n'
    assert result.err == ""


def test_kdl_writer_repeats_node_names_for_slices(run):
    """A slice value becomes repeated nodes with the same name."""
    stdin = ('{"name": "Tom", "age": 31, "tags": ["a","b"], '
             '"nested": {"x": 1, "list": [1,2]}, "active": true, "nothing": null}')
    result = run(["-i", "json", "-o", "kdl", "$root"], stdin=stdin)
    # CATCHES: `tags` is written twice rather than as an array, null becomes
    # a bare node with no arguments, and the document ends with a newline.
    assert result.returncode == 0
    assert result.out == """name "Tom"
age 31
tags "a"
tags "b"
nested x=1 {
  list 1
  list 2
}
active #true
nothing
"""
    assert result.err == ""


def test_kdl_writer_wraps_an_array_root_in_a_root_node(run):
    """A slice root is written as arguments of a single `root` node."""
    result = run(["-i", "json", "-o", "kdl", "$root"], stdin="[1, 2, 3]")
    # CATCHES: like the scalar root case, KDL has no bare array document, so
    # the elements become positional arguments of a node named `root`.
    assert result.returncode == 0
    assert result.out == "root 1 2 3\n"
    assert result.err == ""


def test_kdl_writer_escapes_strings(run):
    """Quotes, backslashes and control characters are escaped in output."""
    result = run(["-i", "json", "-o", "kdl", "$root"],
                 stdin='{"s": "he said \\"hi\\"\\nback\\\\slash\\ttab"}')
    # CATCHES: the writer re-escapes exactly the characters the KDL tokenizer
    # would otherwise interpret - `"`, `\\`, `\n`, `\t` - and leaves the rest.
    assert result.returncode == 0
    assert result.out == 's "he said \\"hi\\"\\nback\\\\slash\\ttab"\n'
    assert result.err == ""


def test_kdl_writer_quotes_identifiers_that_cannot_be_bare(run):
    """Keys that are not bare identifiers are written as quoted strings."""
    result = run(["-i", "json", "-o", "kdl", "$root"], stdin='{"a b": 1, "": 2, "true": 3}')
    # CATCHES: spaces, the empty string and the keyword `true` all force
    # quoting, so the node names round trip as distinct keys.
    assert result.returncode == 0
    assert result.out == '"a b" 1\n"" 2\n"true" 3\n'
    assert result.err == ""


@pytest.mark.parametrize("version,expected", [
    ("1", "a true\nb false\nc\n"),
    ("2", "a #true\nb #false\nc\n"),
])
def test_kdl_writer_version_flag_selects_keyword_spelling(run, version, expected):
    """--write-flag kdl-version=1 writes bare true/false, version 2 the # form."""
    result = run(["-i", "json", "-o", "kdl", "--write-flag", "kdl-version=" + version,
                 "$root"], stdin='{"a": true, "b": false, "c": null}')
    # CATCHES: the flag only changes the keyword spelling (`true` vs `#true`)
    # and a null still becomes a bare node either way.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_kdl_writer_rejects_an_unknown_version_flag(run):
    """An unsupported kdl-version value fails while writing."""
    result = run(["-i", "json", "-o", "kdl", "--write-flag", "kdl-version=9", "$root"],
                 stdin='{"a": true}')
    # CATCHES: the flag is validated at write time, so the message is wrapped
    # in `error writing output` and quotes both the value and the fix.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error writing output: kdl: unsupported output version '
        '"9" (use 1 or 2)\n')


@pytest.mark.parametrize("stdin,expected", [
    ('{"a": {"b": 1}}', "a b=1"),
    ('{"a": 1, "b": 2}', "a 1b 2"),
])
def test_kdl_compact_output_contains_no_newlines(run, stdin, expected):
    """--compact emits the whole document on a single line with no separator."""
    result = run(["-i", "json", "-o", "kdl", "--compact", "$root"], stdin=stdin)
    # CATCHES: compact drops every newline, so two sibling nodes run together
    # with nothing between them, and the document has no trailing newline.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_kdl_reader_promotes_duplicate_nodes_to_a_slice(run):
    """Repeated node names at the same level are collected into an array."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin='tag "a"\ntag "b"\ntag "c"')
    # CATCHES: the second occurrence promotes the value to a slice and the
    # third appends to it, preserving document order.
    assert result.returncode == 0
    assert result.out == '{\n    "tag": [\n        "a",\n        "b",\n        "c"\n    ]\n}\n'
    assert result.err == ""


@pytest.mark.parametrize("doc,expected", [
    ("n 1 2 x=3 { c 4 }",
     '{\n    "n": {\n        "$args": [\n            1,\n            2\n        ],\n        "x": 3,\n        "c": 4\n    }\n}\n'),
    ("n 1 x=2",
     '{\n    "n": {\n        "$args": [\n            1\n        ],\n        "x": 2\n    }\n}\n'),
])
def test_kdl_reader_collects_args_props_and_children(run, doc, expected):
    """Node arguments land under $args alongside properties and children."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin=doc)
    # CATCHES: two or more arguments become a $args slice, and even a single
    # argument is wrapped in $args when the node also has properties or
    # children - only a lone argument with nothing else becomes a scalar.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_kdl_reader_ignores_comments_and_accepts_semicolons(run):
    """Line comments and `;` node separators are skipped on read."""
    result = run(["-i", "kdl", "-o", "json", "$root"],
                 stdin="a 1\n// comment here\nb 2 ; c 3\n")
    # CATCHES: both `//` comments and `;` terminators are tokenizer level
    # constructs, so all three nodes appear in the resulting map.
    assert result.returncode == 0
    assert result.out == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}\n'
    assert result.err == ""


def test_kdl_reader_string_syntaxes(run):
    """Raw, multi-line and unicode-escaped string literals all decode."""
    cases = [
        ('a #"raw "str" here"#', '"raw \\"str\\" here"\n'),
        ('b r#"has "quotes""#', '"has \\"quotes\\""\n'),
        ('c r"v1 raw"', '"v1 raw"\n'),
        ('d """\n  line1\n  line2\n  """', '"line1\\nline2"\n'),
        ('c "\\u{48}i"', '"Hi"\n'),
    ]
    for doc, expected in cases:
        result = run(["-i", "kdl", "-o", "json", doc.split()[0]], stdin=doc)
        # CATCHES: v2 `#"...#` and v1 `r"..."` raw strings keep their quotes
        # literal, multi-line strings drop the first newline and the shared
        # indentation, and `\u{...}` escapes decode to the rune.
        assert result.returncode == 0, doc
        assert result.out == expected, doc
        assert result.err == "", doc


def test_kdl_reader_number_bases_and_separators(run):
    """Hex, underscore and exponent number literals decode to numbers."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin="d 0x1F\ne 1_000\nf 1e3\n")
    # CATCHES: all three spellings decode to the same numeric value with no
    # trace of the original literal text.
    assert result.returncode == 0
    assert result.out == '{\n    "d": 31,\n    "e": 1000,\n    "f": 1000\n}\n'
    assert result.err == ""


def test_kdl_reader_continues_lines_after_a_backslash(run):
    """A backslash before a newline joins the two physical lines."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin="a \\\n  1\n")
    # CATCHES: the line continuation is consumed by the tokenizer, so `1` is
    # still the first argument of node `a` rather than a parse error.
    assert result.returncode == 0
    assert result.out == '{\n    "a": 1\n}\n'
    assert result.err == ""


def test_kdl_reader_skips_slashdash_nodes(run):
    """`/-` before a node omits it from the parsed document."""
    result = run(["-i", "kdl", "-o", "json", "$root"],
                 stdin="a {\n    /-b 1\n    c 2\n}\n/-d 3\n")
    # CATCHES: the slashdash hides nodes at any depth - both the child `b`
    # and the top level `d` disappear from the result.
    assert result.returncode == 0
    assert result.out == '{\n    "a": {\n        "c": 2\n    }\n}\n'
    assert result.err == ""


@pytest.mark.parametrize("out_format,expected", [
    ("kdl", "root #inf\n"),
    ("plain", "+Inf\n"),
])
def test_kdl_inf_and_nan_round_trip(run, out_format, expected):
    """KDL keyword numbers survive into kdl/plain output."""
    result = run(["-i", "kdl", "-o", out_format, "a"], stdin="a #inf\n")
    # CATCHES: the reader has no +Inf barrier - the selected scalar +Inf is
    # wrapped in a `root` node by the kdl writer while plain prints it bare.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_kdl_inf_cannot_be_written_as_json(run):
    """A +Inf value read from KDL is rejected by the JSON writer."""
    result = run(["-i", "kdl", "-o", "json", "a"], stdin="a #inf\n")
    # CATCHES: the failure happens while writing (after the query ran), and
    # the message is Go's json marshaler error naming the offending value.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: json: unsupported value: +Inf\n")


@pytest.mark.parametrize("doc,message", [
    ('a "oops', "kdl: unterminated string at line 1, col 8"),
    ('a "\\q"', "kdl: unknown escape sequence: \\q at line 1, col 6"),
])
def test_kdl_parse_errors_include_line_and_column(run, doc, message):
    """KDL syntax errors report a 1-based line and column."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin=doc)
    # CATCHES: the position points just past the offending input and the
    # message is wrapped twice by the kdl package prefix.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error reading input: kdl: parse error: %s\n" % message)


def test_xml_writer_renders_attributes_and_text(run):
    """`-` prefixed keys become attributes and `#text` the element text."""
    result = run(["-i", "json", "-o", "xml", "$root"],
                 stdin='{"root": {"-id": "1", "#text": "hello", "name": "Tom"}}')
    # CATCHES: attributes are written inside the opening tag, the #text value
    # becomes the element's own text node before any children, and the child
    # element keeps the two space indent.
    assert result.returncode == 0
    assert result.out == '<root id="1">hello\n  <name>Tom</name>\n</root>\n'
    assert result.err == ""


def test_xml_writer_stringifies_attribute_and_text_values(run):
    """Non-string attribute and text values are converted with toString."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin='{"r": {"-n": 5, "#text": true}}')
    # CATCHES: unlike element children (which must be strings), attributes
    # and #text coerce ints and bools to their string form.
    assert result.returncode == 0
    assert result.out == '<r n="5">true</r>\n'
    assert result.err == ""


def test_xml_writer_repeats_elements_for_arrays(run):
    """An array of strings becomes one element per item."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin='{"items": ["a", "b"]}')
    # CATCHES: array items are written as sibling elements separated by a
    # blank line, not as a single wrapper element.
    assert result.returncode == 0
    assert result.out == "<items>a</items>\n\n<items>b</items>\n"
    assert result.err == ""


def test_xml_writer_separates_top_level_elements_with_blank_lines(run):
    """Every root map key becomes its own top level element."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin='{"a": "x", "b": "y"}')
    # CATCHES: there is no single synthetic root element; the document is the
    # concatenation of one element per key with a blank line between them and
    # exactly one trailing newline.
    assert result.returncode == 0
    assert result.out == "<a>x</a>\n\n<b>y</b>\n"
    assert result.err == ""


def test_xml_writer_escapes_markup(run):
    """Angle brackets and ampersands in text are XML escaped."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin='{"s": "a<b>&c"}')
    # CATCHES: the writer escapes the five predefined entities' characters
    # even though the JSON writer leaves the same bytes untouched.
    assert result.returncode == 0
    assert result.out == "<s>a&lt;b&gt;&amp;c</s>\n"
    assert result.err == ""


@pytest.mark.parametrize("stdin,message", [
    ('{"a": null}', 'failed to convert child element "a" to element: '
                    "xml writer does not support value type: null"),
    ('{"items": [1, 2]}', 'failed to convert child element "items" to element: '
                          "xml writer does not support value type: int"),
    ('{"a": {"b": 1}}', 'failed to convert child element "a" to element: '
                        'failed to convert child element "b" to element: '
                        "xml writer does not support value type: int"),
    ('{"a b": 1}', 'failed to convert child element "a b" to element: '
                   'key "a b" is not a valid XML element name'),
    ('{"r": {"-": 1}}', 'failed to convert child element "r" to element: '
                        'invalid XML attribute name "" from map key "-"'),
    ("42", "xml writer does not support value type: int"),
])
def test_xml_writer_rejects_unrepresentable_values(run, stdin, message):
    """The XML writer only accepts maps of strings (plus attrs/#text)."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin=stdin)
    # CATCHES: every rejection is wrapped by each nesting level of the
    # element conversion, so the message names the full path to the bad value.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: failed to convert to element: "
        "%s\n" % message)


@pytest.mark.parametrize("doc,expected", [
    ("<root><!-- my comment --><a>1</a></root>",
     "<root>\n  <!-- my comment -->\n  <a>1</a>\n</root>\n"),
    ("<root><a>1</a><!-- child comment --></root>",
     "<!-- child comment -->\n<root>\n  <a>1</a>\n</root>\n"),
    ("<root><a>1</a><!-- mid --><b>2</b></root>",
     "<root>\n  <a>1</a>\n  <!-- mid -->\n  <b>2</b>\n</root>\n"),
    ("<root><!-- one --><!-- two --><a>1</a></root>",
     "<root>\n  <!-- one -->\n  <!-- two -->\n  <a>1</a>\n</root>\n"),
])
def test_xml_round_trips_comments(run, doc, expected):
    """Comments survive a read/write round trip at their recorded spot."""
    result = run(["-i", "xml", "-o", "xml", "$root"], stdin=doc)
    # CATCHES: a comment before a child stays inside the parent, one after the
    # last child is hoisted to the document level before the root element, and
    # consecutive comments are kept as separate <!-- --> nodes.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("doc,expected", [
    ('<?xml version="1.0" encoding="UTF-8"?><root><a>1</a></root>',
     '<?xml version="1.0" encoding="UTF-8"?>\n<root>\n  <a>1</a>\n</root>\n'),
    ("<?target data?><root><a>1</a></root>",
     "<?target data?>\n<root>\n  <a>1</a>\n</root>\n"),
    ("<?one 1?><root><?two 2?><a>1</a></root>",
     "<?one 1?>\n<root>\n  <a>1</a>\n</root>\n"),
])
def test_xml_round_trips_processing_instructions(run, doc, expected):
    """Document-level processing instructions round trip; nested ones drop."""
    result = run(["-i", "xml", "-o", "xml", "$root"], stdin=doc)
    # CATCHES: only instructions recorded before the root element are written
    # back out, each followed by a newline; one inside the root is discarded.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_xml_reader_unwraps_cdata_sections(run):
    """CDATA content is read as plain text and escaped on the way out."""
    result = run(["-i", "xml", "-o", "json", "$root"],
                 stdin="<root><![CDATA[<hi> & bye]]></root>")
    # CATCHES: the CDATA wrapper disappears on read, so the json output holds
    # the raw markup characters as an ordinary string value.
    assert result.returncode == 0
    assert result.out == '{\n    "root": "<hi> & bye"\n}\n'
    assert result.err == ""

    result = run(["-i", "xml", "-o", "xml", "$root"],
                 stdin="<root><![CDATA[<hi> & bye]]></root>")
    # CATCHES: the writer has no CDATA support, so the same characters are
    # re-emitted as escaped character data instead of a CDATA section.
    assert result.returncode == 0
    assert result.out == "<root>&lt;hi&gt; &amp; bye</root>\n"
    assert result.err == ""


def test_xml_reader_strips_attribute_namespaces(run):
    """Namespaced attributes lose their prefix on read."""
    result = run(["-i", "xml", "-o", "xml", "$root"],
                 stdin='<root xmlns:ns="http://x"><a ns:id="5">1</a></root>')
    # CATCHES: `ns:id` is stored under its local name `id` and the xmlns
    # declaration becomes a plain `ns` attribute on the root element.
    assert result.returncode == 0
    assert result.out == '<root ns="http://x">\n  <a id="5">1</a>\n</root>\n'
    assert result.err == ""


@pytest.mark.parametrize("key,expected", [
    ("ü", "<ü>v</ü>\n"),
    ("é", "<é>v</é>\n"),
    ("\U0001f600", "<\U0001f600>v</\U0001f600>\n"),
    ("a-b", "<a-b>v</a-b>\n"),
    ("a.b", "<a.b>v</a.b>\n"),
    ("_x", "<_x>v</_x>\n"),
    ("a:b", "<a:b>v</a:b>\n"),
])
def test_xml_writer_accepts_unicode_and_punctuated_names(run, key, expected):
    """Element names may use unicode letters, dots, dashes, _ and :."""
    result = run(["-i", "json", "-o", "xml", "$root"],
                 stdin='{"%s": "v"}' % json.dumps(key)[1:-1])
    # CATCHES: name validation follows XML 1.0, so non-ASCII letters are fine
    # and so are the four punctuation characters allowed outside the first
    # position, while the value itself stays a string child element.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("key,message", [
    ("1a", 'key "1a" is not a valid XML element name'),
    ("a b", 'key "a b" is not a valid XML element name'),
])
def test_xml_writer_rejects_invalid_element_names(run, key, message):
    """A name must not start with a digit or contain a space."""
    result = run(["-i", "json", "-o", "xml", "$root"],
                 stdin='{"%s": "v"}' % json.dumps(key)[1:-1])
    # CATCHES: the name check runs before the value is inspected, so even a
    # perfectly good string value cannot rescue an invalid element name.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: failed to convert to element: "
        'failed to convert child element "%s" to element: %s\n' % (key, message))


def test_xml_writer_rejects_invalid_attribute_names(run):
    """Attribute names stripped of `-` must still be valid XML names."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin='{"r": {"-1q": "v"}}')
    # CATCHES: the name after the `-` prefix is validated, so `-1q` fails
    # with the attribute-specific message naming both the bad name and the
    # original map key it came from.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: failed to convert to element: "
        'failed to convert child element "r" to element: '
        'invalid XML attribute name "1q" from map key "-1q"\n')


def test_xml_writer_accepts_unicode_attribute_names(run):
    """Non-ASCII letters are valid attribute names."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin='{"r": {"-ü": "v"}}')
    # CATCHES: unicode attribute names are accepted, and an attribute-only
    # element still emits both the opening and closing tag.
    assert result.returncode == 0
    assert result.out == '<r ü="v"></r>\n'
    assert result.err == ""


@pytest.mark.parametrize("stdin", ['{"#text": "hi"}', '{"-a": "b"}'])
def test_xml_writer_drops_root_level_text_and_attributes(run, stdin):
    """The document root only ever writes its child elements."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin=stdin)
    # CATCHES: #text and -attribute keys are only meaningful on child
    # elements; on the root map itself they leave nothing to encode, so the
    # whole document collapses to a single newline.
    assert result.returncode == 0
    assert result.out == "\n"
    assert result.err == ""


@pytest.mark.parametrize("stdin,expected", [
    ('{"a": ""}', "<a></a>\n"),
    ('{"a": {}}', "<a></a>\n"),
    ('{"a": []}', "\n"),
])
def test_xml_writer_renders_empty_values(run, stdin, expected):
    """Empty strings and maps still open and close the element."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin=stdin)
    # CATCHES: an empty string or map value keeps the paired tag form instead
    # of a self-closing one, while an empty slice contributes no elements at
    # all, leaving an empty document.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,expected", [
    ('["a", "b"]', "<root>a</root>\n\n<root>b</root>\n"),
    ('[{"a": "x"}, {"b": "y"}]',
     "<root>\n  <a>x</a>\n</root>\n\n<root>\n  <b>y</b>\n</root>\n"),
])
def test_xml_writer_wraps_slice_roots_in_root_elements(run, stdin, expected):
    """A slice document becomes one `root` element per item."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin=stdin)
    # CATCHES: slice roots are flattened through the synthetic root name and
    # separated by blank lines, exactly like sibling keys of a map root.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_xml_writer_flattens_nested_slices(run):
    """A slice inside a slice repeats the outer element name."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin='{"a": ["x", ["y"]]}')
    # CATCHES: the inner slice is unwrapped recursively, so both the scalar
    # and the nested item become sibling <a> elements.
    assert result.returncode == 0
    assert result.out == "<a>x</a>\n\n<a>y</a>\n"
    assert result.err == ""


@pytest.mark.parametrize("doc,extra_args,expected", [
    ('{"root": {"name": "Tom", "kids": ["Beth", "Bo"]}}', ["--compact"],
     "<root><name>Tom</name><kids>Beth</kids><kids>Bo</kids></root>\n"),
    ("<root><!-- c --><a>1</a></root>", ["--compact"],
     "<root><!-- c --><a>1</a></root>\n"),
    ('<?xml version="1.0"?><root><a>1</a></root>', ["--compact"],
     "<?xml version=\"1.0\"?><root><a>1</a></root>\n"),
])
def test_xml_writer_compact_output(run, doc, extra_args, expected):
    """--compact removes all indentation and separating newlines."""
    result = run(["-i", "json" if doc.startswith("{") else "xml", "-o", "xml"]
                 + extra_args + ["$root"], stdin=doc)
    # CATCHES: compact mode drops the pretty-print indentation, the newline
    # after each element and the newline following comments and processing
    # instructions alike.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_xml_writer_escapes_attribute_values(run):
    """Quotes and angle brackets in attribute values are escaped."""
    result = run(["-i", "json", "-o", "xml", "$root"],
                 stdin='{"r": {"-q": "a\\"b<c"}}')
    # CATCHES: the encoder escapes a double quote as &#34; (not &quot;) and a
    # left angle bracket as &lt; inside attribute values.
    assert result.returncode == 0
    assert result.out == '<r q="a&#34;b&lt;c"></r>\n'
    assert result.err == ""


def test_xml_writer_concatenates_text_around_children(run):
    """Text before and after a child element joins into one text node."""
    result = run(["-i", "xml", "-o", "xml", "$root"],
                 stdin="<root>text<a>1</a>more</root>")
    # CATCHES: the reader merges non-child character data into a single #text
    # value that the writer places before the child elements.
    assert result.returncode == 0
    assert result.out == "<root>textmore\n  <a>1</a>\n</root>\n"
    assert result.err == ""


def test_xml_writer_preserves_attribute_insertion_order(run):
    """Multiple attributes are written in map insertion order."""
    result = run(["-i", "json", "-o", "xml", "$root"],
                 stdin='{"r": {"-b": "1", "-a": "2"}}')
    # CATCHES: attributes are not sorted alphabetically; `b` keeps preceding
    # `a` because that is the order the keys were parsed in.
    assert result.returncode == 0
    assert result.out == '<r b="1" a="2"></r>\n'
    assert result.err == ""


@pytest.mark.parametrize("stdin,message", [
    ('{"a": 1.5}', 'failed to convert child element "a" to element: '
                   "xml writer does not support value type: float"),
    ('{"a": true}', 'failed to convert child element "a" to element: '
                    "xml writer does not support value type: bool"),
    ("3.5", "xml writer does not support value type: float"),
])
def test_xml_writer_rejects_float_and_bool_elements(run, stdin, message):
    """Floats and bools may not be element children or the root value."""
    result = run(["-i", "json", "-o", "xml", "$root"], stdin=stdin)
    # CATCHES: unlike attribute and #text values, which are stringified,
    # element values must be strings — the type name in the message records
    # which scalar kind was rejected.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: failed to convert to element: "
        "%s\n" % message)


@pytest.mark.parametrize("doc,expected", [
    ("a = 1", '{\n    "a": 1\n}\n'),
    ("a = 1.5", '{\n    "a": 1.5\n}\n'),
    ('a = "str"', '{\n    "a": "str"\n}\n'),
    ("a = true", '{\n    "a": true\n}\n'),
    ('a = [1, "two", false]', '{\n    "a": [\n        1,\n        "two",\n        false\n    ]\n}\n'),
    ('a = { x = 1, y = "z" }', '{\n    "a": {\n        "x": 1,\n        "y": "z"\n    }\n}\n'),
])
def test_hcl_attribute_value_types(run, doc, expected):
    """HCL attributes decode to typed model values."""
    result = run(["-i", "hcl", "-o", "json", "$root"], stdin=doc + "\n")
    # CATCHES: whole numbers become ints and fractional ones floats (unlike
    # HCL itself, which only has numbers), and lists/objects nest normally.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_hcl_heredoc_strings_keep_their_newlines(run):
    """A heredoc body decodes to one string including the final newline."""
    result = run(["-i", "hcl", "-o", "json", "$root"],
                 stdin="text = <<EOT\nline one\nline two\nEOT\n")
    # CATCHES: the heredoc keeps every inner newline plus the trailing one
    # before the terminator, so the JSON output re-escapes them.
    assert result.returncode == 0
    assert result.out == '{\n    "text": "line one\\nline two\\n"\n}\n'
    assert result.err == ""


def test_hcl_repeated_blocks_become_an_array(run):
    """Two blocks with the same label are collected into an array."""
    result = run(["-i", "hcl", "-o", "json", "$root"],
                 stdin='block "x" { v = 1 }\nblock "x" { v = 2 }\n')
    # CATCHES: the first block produces a map and the second wraps it into a
    # slice rather than overwriting it.
    assert result.returncode == 0
    assert result.out == """{
    "block": {
        "x": [
            {
                "v": 1
            },
            {
                "v": 2
            }
        ]
    }
}
"""
    assert result.err == ""


def test_hcl_attributes_precede_blocks(run):
    """Attributes are decoded before blocks regardless of source order."""
    result = run(["-i", "hcl", "-o", "json", "$root"],
                 stdin='z = 1\nblk "l1" { v = 1 }\nblk "l2" { v = 2 }\n')
    # CATCHES: the attribute `z` comes first in the output map even though it
    # also came first in the source - the decoder runs all attributes before
    # any block, and blocks keep their source order.
    assert result.returncode == 0
    assert result.out == """{
    "z": 1,
    "blk": {
        "l1": {
            "v": 1
        },
        "l2": {
            "v": 2
        }
    }
}
"""
    assert result.err == ""


def test_hcl_block_format_array_flag(run):
    """--read-flag hcl-block-format=array wraps single blocks in arrays."""
    result = run(["-i", "hcl", "-o", "json", "--read-flag", "hcl-block-format=array",
                 "$root"], stdin='svc "a" { x = 1 }\n')
    # CATCHES: without the flag a single block is a plain map; with it the
    # body is always the only element of an array, matching how repeated
    # blocks are laid out by default.
    assert result.returncode == 0
    assert result.out == """{
    "svc": {
        "a": [
            {
                "x": 1
            }
        ]
    }
}
"""
    assert result.err == ""


def test_hcl_invalid_input_is_lenient(run):
    """HCL parse diagnostics are ignored; broken expressions become null."""
    result = run(["-i", "hcl", "-o", "json", "$root"], stdin="a = ;;; {{{")
    # CATCHES: the reader discards the parser's errors entirely, so even
    # garbage after `=` yields a successful run with a null attribute rather
    # than a non-zero exit.
    assert result.returncode == 0
    assert result.out == '{\n    "a": null\n}\n'
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"v": 1.5}', "v", "1.5\n"),
    ('{"v": 12.0}', "v", "12\n"),
    ('{"v": 3}', "v", "3\n"),
    ('{"v": true}', "v", "true\n"),
    ('{"v": null}', "v", "\n"),
    ('{"v": "a\\nb"}', "v", "a\nb\n"),
])
def test_plain_writer_scalar_formats(run, stdin, query, expected):
    """The plain writer renders each scalar kind without quotes or commas."""
    result = run(["-i", "json", "-o", "plain", query], stdin=stdin)
    # CATCHES: floats use %g (so 12.0 prints as `12`), null becomes an empty
    # line, and embedded newlines in strings are passed through raw.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_plain_writer_joins_documents_with_single_newlines(run):
    """Multi document plain output is one value per line with no separators."""
    result = run(["-i", "yaml", "-o", "plain", "$this[0]"], stdin='- "x"\n---\n- "y"\n')
    # CATCHES: the plain writer has no document separator (unlike json's blank
    # line or yaml's `---`), so documents are only split by their own newline.
    assert result.returncode == 0
    assert result.out == "x\ny\n"
    assert result.err == ""


INTERACTIVE_HELP = """Usage: dasel interactive [<query>] [flags]

Start an interactive session (alpha)

Arguments:
  [<query>]    The query to execute.

Flags:
  -h, --help                     Show context-sensitive help.

      --var=VARIABLES            Variables to pass to the query. E.g. --var
                                 foo="bar" --var baz=json:file:./some/file.json
      --rw-flag=EXT-READ-WRITE-FLAGS
                                 Read/Write flag to customise parsing/output.
                                 Applies to read + write E.g. --rw-flag
                                 csv-delimiter=;
      --read-flag=EXT-READ-WRITE-FLAGS
                                 Reader flag to customise parsing. E.g.
                                 --read-flag xml-mode=structured
      --write-flag=EXT-READ-WRITE-FLAGS
                                 Writer flag to customise output. E.g.
                                 --write-flag csv-delimiter=;
  -i, --in=STRING                The format of the input data.
  -o, --out=STRING               The format of the output data.
  -c, --config="~/dasel.yaml"    Path to config file
"""


def test_interactive_help_documents_its_own_flags(run):
    """The interactive subcommand help omits the query-only flags."""
    result = run(["interactive", "--help"], config=False, stdin="")
    # CATCHES: `--root`, `--compact`, `--unstable` and `--it` are missing from
    # this help block - they only exist on the default query command - while
    # the shared --var/--rw-flag/--read-flag/--write-flag block is identical.
    assert result.returncode == 0
    assert result.out == INTERACTIVE_HELP
    assert result.err == ""


def test_interactive_subcommand_requires_a_tty(run):
    """The interactive subcommand fails without a terminal, like --it."""
    result = run(["interactive"], stdin="")
    # CATCHES: both spellings share the same TTY bootstrap, so the subcommand
    # form reports the identical message and exits 1 instead of hanging.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: could not open a new TTY: "
        "open /dev/tty: no such device or address\n")


@pytest.mark.parametrize("doc,message", [
    ("{ }", "kdl: expected node name, got 17 at line 1, col 1"),
    ("a { b } c", "kdl: expected node terminator, got 2 at line 1, col 9"),
    ("a { b", "kdl: expected '}', got 0 at line 1, col 6"),
    ("(1) a", "kdl: expected type name, got 6 at line 1, col 2"),
    ("(int a", "kdl: expected ')', got 2 at line 1, col 6"),
    ("(int)", "kdl: expected node name, got 0 at line 1, col 6"),
    ('a b=c=1', "kdl: unexpected token 21 for value at line 1, col 6"),
    ('a 0xZZ', 'kdl: invalid hex integer "0x": strconv.ParseInt: parsing "": '
               "invalid syntax"),
    ('a 0o8', 'kdl: invalid octal integer "0o": strconv.ParseInt: parsing "": '
              "invalid syntax"),
    ('a 0b2', 'kdl: invalid binary integer "0b": strconv.ParseInt: parsing "": '
              "invalid syntax"),
])
def test_kdl_parser_reports_structural_errors(run, doc, message):
    """Malformed KDL structures fail with the offending token kind and position."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin=doc)
    # CATCHES: the parser names the internal token kind number and the 1-based
    # line/column of the token it choked on, and the numeric bases report the
    # stripped prefix (e.g. "0x" without the invalid digits) to strconv.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error reading input: kdl: parse error: %s\n" % message)


@pytest.mark.parametrize("doc,query,expected", [
    ('(date) a 1', "a", "1\n"),
    ('a (int)"5"', "a", '"5"\n'),
    ('a b=(int)"5"', "a.b", '"5"\n'),
    ('("int") a 1', "a", "1\n"),
    ('node (str)"x" { c 1 }', "node", '{\n    "$args": [\n        "x"\n    ],\n    "c": 1\n}\n'),
])
def test_kdl_type_annotations_are_parsed_but_not_applied(run, doc, query, expected):
    """KDL type annotations are accepted anywhere but never coerce the value."""
    result = run(["-i", "kdl", "-o", "json", query], stdin=doc)
    # CATCHES: `(int)"5"` still reads back as the string "5" - annotations on
    # node names, arguments and property values are recorded then ignored, and
    # the type name may also be a quoted string.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("doc,expected", [
    ("a /-1 b=2", '{\n    "a": {\n        "b": 2\n    }\n}\n'),
    ("a /-x=1 y=2", '{\n    "a": {\n        "y": 2\n    }\n}\n'),
    ("a /-(int)1 2", "{\n    \"a\": 2\n}\n"),
    ("a /-{ b }", "{\n    \"a\": null\n}\n"),
])
def test_kdl_slashdash_hides_entries_and_children(run, doc, expected):
    """`/-` before an entry, property or children block discards it."""
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin=doc)
    # CATCHES: slashdashing works on individual arguments (with or without a
    # type annotation) and on a whole children block, which leaves the node
    # with no entries at all - so it reads back as null rather than a map.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("marker,expected_out,expected_err", [
    ("/- kdl-version 1\na 1\n", "1\n", None),
    ("/- kdl-version 2\na #true\n", "true\n", None),
    ("/- kdl-version\na 1\n", "1\n", None),
    ("/- kdl-version 3\na 1\n", "",
     'dasel: error: error reading input: kdl: parse error: '
     'kdl: unsupported version "3" in version marker\n'),
    ("/- kdl-version v2\na 1\n", "",
     'dasel: error: error reading input: kdl: parse error: '
     'kdl: unsupported version "v2" in version marker\n'),
])
def test_kdl_version_marker(run, marker, expected_out, expected_err):
    """A `/- kdl-version N` marker must name a supported version."""
    result = run(["-i", "kdl", "-o", "json", "a"], stdin=marker)
    # CATCHES: only "1" and "2" are accepted (anything else, including "v2",
    # is rejected with the quoted value) and a marker with no number at all is
    # ignored, leaving the document to parse normally.
    if expected_err is None:
        assert result.returncode == 0
        assert result.out == expected_out
        assert result.err == ""
    else:
        assert result.returncode == 1
        assert result.out == expected_out
        assert result.err == expected_err


def test_kdl_rejects_documents_nested_too_deeply(run):
    """Children blocks nested more than 10000 levels fail to parse."""
    doc = "a {" * 10001 + "}" * 10001
    result = run(["-i", "kdl", "-o", "json", "$root"], stdin=doc)
    # CATCHES: the parser enforces a hard depth limit of 10000 nested children
    # blocks and reports the generic "kdl nesting depth exceeded" error rather
    # than crashing on stack exhaustion.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error reading input: kdl: parse error: "
        "kdl nesting depth exceeded\n")


def test_csv_writer_stringifies_each_scalar_cell(run):
    """CSV cells convert null, float, bool and int values to strings."""
    result = run(["-i", "json", "-o", "csv", "$root"],
                 stdin='[{"a": null, "b": 1.5, "c": true, "d": 7, "e": "x"}]')
    # CATCHES: null becomes the empty string (not "null"), floats keep their
    # %g form, booleans lowercase and ints pass through - so a round trip of
    # mixed JSON types never quotes or errors.
    assert result.returncode == 0
    assert result.out == "a,b,c,d,e\n,1.5,true,7,x\n"
    assert result.err == ""


@pytest.mark.parametrize("cell,message", [
    ('{"x": 1}', "csv writer cannot format type map to string"),
    ("[1, 2]", "csv writer cannot format type array to string"),
])
def test_csv_writer_rejects_structured_cells(run, cell, message):
    """A CSV cell holding a map or array fails the whole write."""
    result = run(["-i", "json", "-o", "csv", "$root"],
                 stdin='[{"a": %s}]' % cell)
    # CATCHES: the failure is wrapped by the slice ranging loop as
    # "error converting value to string" and names the model type, so nested
    # documents cannot be silently flattened into a cell.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: error ranging slice: "
        "error converting value to string: %s\n" % message)


def test_csv_writer_validates_the_delimiter_on_creation(run):
    """The CSV writer rejects a multi character delimiter before writing."""
    result = run(["-i", "json", "-o", "csv", "--write-flag", "csv-delimiter=;;",
                  "$root"], stdin='[{"a": "x"}]')
    # CATCHES: writer construction fails with "failed to get output writer"
    # (the reader equivalent says "failed to get input reader"), so the
    # delimiter is validated before any document is formatted.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: failed to get output writer: csv-delimiter must be a '
        'single character, got ";;"\n')


def test_csv_empty_delimiter_flag_keeps_the_comma_default(run):
    """An empty csv-delimiter value falls back to the comma separator."""
    result = run(["-i", "json", "-o", "csv", "--write-flag", "csv-delimiter=",
                  "$root"], stdin='[{"a": 1, "b": 2}]')
    # CATCHES: `csv-delimiter=` is treated as unset rather than as a zero
    # length separator, so the writer emits the default comma separated row.
    assert result.returncode == 0
    assert result.out == "a,b\n1,2\n"
    assert result.err == ""


def test_interactive_reports_config_errors_before_the_tty_check(run, write):
    """The interactive command loads its config before opening the TTY."""
    config = write("bad-dasel.yaml", "bad: [yaml\n")
    result = run(["interactive", "-c", str(config)], stdin="")
    # CATCHES: a broken config file surfaces the yaml parse error instead of
    # the TTY error, proving the config is read before the terminal is opened.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error parsing config file: "
        "yaml: line 1: did not find expected ',' or ']'\n")


@pytest.mark.parametrize("args", [
    ["interactive", "-i", "json"],
    ["interactive", "-o", "yaml"],
    ["interactive", "-i", "json", "-o", "yaml"],
    ["interactive", "--in", "notarealformat"],
    ["-i", "json", "--it"],
])
def test_interactive_format_flags_do_not_change_the_tty_error(run, args):
    """Format flags are inferred but never validated before the TTY is opened."""
    result = run(args, stdin="")
    # CATCHES: -i, -o, both together, an unknown format and the --it alias all
    # reach the same TTY bootstrap error - format validation is deferred to
    # query execution inside the session, not done up front.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: could not open a new TTY: "
        "open /dev/tty: no such device or address\n")


@pytest.mark.parametrize("stdin,expected", [
    ('{"a": 1, "d": "s"}', 'a = 1\nd = "s"\n'),
    ('{"a": null, "b": true, "c": 1.5}', "a = null\nb = true\nc = 1.5\n"),
    ('{"a": {"b": 1}}', "a {\n  b = 1\n}\n"),
    ('{"a": {"b": {"c": 1}}}', "a {\n  b {\n    c = 1\n  }\n}\n"),
])
def test_hcl_writer_renders_attributes_and_blocks(run, stdin, expected):
    """The HCL writer maps scalars to attributes and maps to nested blocks."""
    result = run(["-i", "json", "-o", "hcl", "$root"], stdin=stdin)
    # CATCHES: blocks indent with exactly two spaces per level, null renders
    # as the literal `null`, and strings are double quoted - unlike TOML's
    # single quoted style.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_hcl_writer_repeats_blocks_for_an_array_of_maps(run):
    """An array whose elements are all maps becomes repeated blocks."""
    result = run(["-i", "json", "-o", "hcl", "$root"],
                 stdin='{"a": [{"b": 1}, {"b": 2}]}')
    # CATCHES: the writer emits one block per element with the same name
    # instead of a tuple, matching how the HCL reader reads repeated blocks
    # back into an array.
    assert result.returncode == 0
    assert result.out == "a {\n  b = 1\n}\na {\n  b = 2\n}\n"
    assert result.err == ""


@pytest.mark.parametrize("stdin,expected", [
    ('{"a": [1, 2]}', "a = [1, 2]\n"),
    ('{"a": [{"b": 1}, 2]}', "a = [{\n  b = 1\n}, 2]\n"),
])
def test_hcl_writer_renders_arrays_of_scalars_as_tuples(run, stdin, expected):
    """Arrays that are not all maps render as HCL tuples."""
    result = run(["-i", "json", "-o", "hcl", "$root"], stdin=stdin)
    # CATCHES: a scalar array becomes a flat tuple, and a mixed array keeps
    # the object inline inside the tuple (multi line, two space indent) rather
    # than being promoted to a block.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin", ["[1, 2]", '"str"', "5", "null"])
def test_hcl_writer_rejects_non_map_roots(run, stdin):
    """The HCL writer can only serialise a map at the root."""
    result = run(["-i", "json", "-o", "hcl", "$root"], stdin=stdin)
    # CATCHES: arrays, strings, scalars and null all fail with "hcl body is
    # expected to be a map" naming the model type of the root value.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: hcl body is expected to be a "
        "map, got %s\n" % {"[1, 2]": "array", '"str"': "string",
                           "5": "int", "null": "null"}[stdin])


@pytest.mark.parametrize("stdin,expected", [
    ('{"a": {"b": 1}}', "[a]\nb = 1\n"),
    ('{"a": {"b": {"c": 1}}}', "[a]\n\n[a b]\nc = 1\n"),
    ('{"top": 1, "sec": {"x": 2}}', "top = 1\n\n[sec]\nx = 2\n"),
    ('{"a b": {"c": 1}}', "[a b]\nc = 1\n"),
])
def test_ini_writer_uses_sections_for_nested_maps(run, stdin, expected):
    """The INI writer maps nested maps to space-joined section names."""
    result = run(["-i", "json", "-o", "ini", "$root"], stdin=stdin)
    # CATCHES: every nesting level gets its own section header (so the
    # intermediate `[a]` is emitted empty before `[a b]`), root level scalars
    # are written before any header, and a key containing a space produces
    # the same header as a nested map would.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_ini_writer_stringifies_scalar_values(run):
    """INI values render null as empty, floats %g and booleans lowercase."""
    result = run(["-i", "json", "-o", "ini", "$root"],
                 stdin='{"a": null, "b": 1.5, "c": true}')
    # CATCHES: null writes an empty value (keeping the trailing space after
    # `=`) rather than the word null, and numbers/bools use their Go default
    # formatting.
    assert result.returncode == 0
    assert result.out == "a = \nb = 1.5\nc = true\n"
    assert result.err == ""


@pytest.mark.parametrize("stdin,message", [
    ('{"a": [1, 2]}', "ini writer cannot represent slice values directly; "
                      "consider using nested sections"),
    ("[1, 2]", "ini can only represent map values"),
    ('"str"', "ini can only represent map values"),
])
def test_ini_writer_rejects_slices_and_non_map_roots(run, stdin, message):
    """The INI writer refuses arrays both at the root and as values."""
    result = run(["-i", "json", "-o", "ini", "$root"], stdin=stdin)
    # CATCHES: a slice value inside a map has its own hint message
    # ("consider using nested sections") while a non map root gets the
    # shorter root-level rejection.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == "dasel: error: error writing output: %s\n" % message
