"""Selector execution behaviours, ported from the native table driven tests in
``src/execution/execute*_test.go`` and ``src/internal/cli/command_test.go``."""

import pytest

PERSON = '{"title":"Mr","age":31,"name":{"first":"Tom","last":"Wright"}}'


@pytest.mark.parametrize("query,expected", [
    ("title", '"Mr"\n'),
    ("name.first", '"Tom"\n'),
    ('title + " " + (name.first) + " " + (name.last)', '"Mr Tom Wright"\n'),
    ('title + " " + name.first + " " + name.last', '"Mr Tom Wright"\n'),
])
def test_get_and_concatenation(run, query, expected):
    """Property access and string concatenation over the input document."""
    result = run(["-i", "json", query], stdin=PERSON)
    # CATCHES: `+` is string concatenation here and grouped sub-expressions
    # bind exactly like parentheses do in the reference.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_object_spread_adds_a_computed_key(run):
    """`{..., key: expr}` copies the input map and appends the new key."""
    result = run(["-i", "json", "-o", "json", '{..., "over30": age > 30}'], stdin=PERSON)
    # CATCHES: spread preserves the original key order and appends the new key
    # at the end rather than sorting or replacing.
    assert result.returncode == 0
    assert result.out == """{
    "title": "Mr",
    "age": 31,
    "name": {
        "first": "Tom",
        "last": "Wright"
    },
    "over30": true
}
"""
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("{title}", '{\n    "title": "Mr"\n}\n'),
    ("{title, age}", '{\n    "title": "Mr",\n    "age": 31\n}\n'),
    ("{...}", '{\n    "title": "Mr",\n    "age": 31,\n    "name": {\n        "first": "Tom",\n        "last": "Wright"\n    }\n}\n'),
    ('{title:"Mrs"}', '{\n    "title": "Mrs"\n}\n'),
    ('{..., title:"Mrs"}', '{\n    "title": "Mrs",\n    "age": 31,\n    "name": {\n        "first": "Tom",\n        "last": "Wright"\n    }\n}\n'),
])
def test_object_literals(run, query, expected):
    """Object literal construction with and without spread."""
    result = run(["-i", "json", "-o", "json", query], stdin=PERSON)
    # CATCHES: `{...}` clones the current value, and unquoted keys are allowed
    # on the right of a colon while quoted keys are not re-quoted in output.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_nested_object_spread_merges(run):
    """Spreading two keys into one object deduplicates them."""
    result = run(["-i", "json", "-o", "json", "{a..., b..., x: 1}"],
                 stdin='{"a":{"x":1},"b":{"y":2}}')
    # CATCHES: later spreads overwrite earlier keys of the same name, so the
    # single `x` comes from the explicit key, not from `a`.
    assert result.returncode == 0
    assert result.out == '{\n    "x": 1,\n    "y": 2\n}\n'
    assert result.err == ""


def test_array_literals_evaluate_their_elements(run):
    """Array literal elements are themselves evaluated expressions."""
    result = run(["-i", "json", "[1, 2.2, \"foo\", true, [1 + 1, 2 * 2, 3 / 3]]", ], stdin="null")
    # CATCHES: nested arithmetic inside the literal is evaluated before the
    # array is built, and ints stay ints (no float promotion).
    assert result.returncode == 0
    assert result.out == """[
    1,
    2.2,
    "foo",
    true,
    [
        2,
        4,
        1
    ]
]
"""
    assert result.err == ""


def test_slice_spread_inside_an_array_literal(run):
    """`...` inside an array literal flattens the spread operand."""
    result = run(["-i", "json", "[[1,2,3]..., 4]"], stdin="null")
    # CATCHES: the spread operator inside a literal splices elements, it does
    # not nest the inner array.
    assert result.returncode == 0
    assert result.out == "[\n    1,\n    2,\n    3,\n    4\n]\n"
    assert result.err == ""


def test_slice_range_is_end_inclusive(run):
    """`[a:b]` includes the element at index b."""
    result = run(["-i", "json", "$this[1:3]"], stdin="[10,20,30,40,50]")
    # CATCHES: the range is inclusive on both ends, unlike Go/Python slicing,
    # so indices 1..3 yield three elements.
    assert result.returncode == 0
    assert result.out == "[\n    20,\n    30,\n    40\n]\n"
    assert result.err == ""


def test_slice_range_with_omitted_end(run):
    """`[a:]` runs to the end of the slice."""
    result = run(["-i", "json", "$this[3:]"], stdin="[10,20,30,40,50]")
    # CATCHES: omitting the end keeps the inclusive semantics, returning the
    # last two elements.
    assert result.returncode == 0
    assert result.out == "[\n    40,\n    50\n]\n"
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("sortBy($this)", "[\n    1,\n    2,\n    3,\n    4\n]\n"),
    ("sortBy($this, asc)", "[\n    1,\n    2,\n    3,\n    4\n]\n"),
    ("sortBy($this, desc)", "[\n    4,\n    3,\n    2,\n    1\n]\n"),
    ("sortBy($key, desc)", "[\n    30,\n    20,\n    10\n]\n"),
])
def test_sort_by_ints(run, query, expected):
    """sortBy orders integers with an explicit or defaulted direction."""
    stdin = "[2,1,4,3]" if "$key" not in query else "[10,20,30]"
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: the direction argument is a bare identifier (not a string) and
    # sorting by $key orders by element index.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ("[2.23,2,5.123,4.2]", "sortBy($this)", "[\n    2,\n    2.23,\n    4.2,\n    5.123\n]\n"),
    ("[2.23,2,5.123,4.2]", "sortBy($this, desc)", "[\n    5.123,\n    4.2,\n    2.23,\n    2\n]\n"),
    ('["def","abc","cde","bcd"]', "sortBy($this)", '[\n    "abc",\n    "bcd",\n    "cde",\n    "def"\n]\n'),
    ('["def","abc","cde","bcd"]', "sortBy($this, desc)", '[\n    "def",\n    "cde",\n    "bcd",\n    "abc"\n]\n'),
])
def test_sort_by_floats_and_strings(run, stdin, query, expected):
    """sortBy compares floats and strings, and keeps ints unformatted."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: an integer that sorts among floats is printed as `2`, not `2.0`,
    # and string sorting is bytewise lexicographic.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_sort_by_rejects_an_unknown_direction(run):
    """An unknown direction keyword is a parse error."""
    result = run(["-i", "json", "sortBy($this, sideways)"], stdin="[1,2]")
    # CATCHES: only the bare identifiers asc/desc are accepted, and the parse
    # error names the offending token and position.
    assert result.returncode == 1
    assert result.err == (
        'dasel: error: error parsing selector: failed to parse: '
        'unexpected token 1 "sideways" at position 14.\n')


@pytest.mark.parametrize("stdin,query,expected", [
    ('["a","b","a","c","b"]', "groupBy($this)",
     '{\n    "a": [\n        "a",\n        "a"\n    ],\n    "b": [\n        "b",\n        "b"\n    ],\n    "c": [\n        "c"\n    ]\n}\n'),
    ("[1,2,1,2,3]", "groupBy($this)",
     '{\n    "1": [\n        1,\n        1\n    ],\n    "2": [\n        2,\n        2\n    ],\n    "3": [\n        3\n    ]\n}\n'),
    ("[3,7,1,8,5]", "groupBy($this > 5)",
     '{\n    "false": [\n        3,\n        1,\n        5\n    ],\n    "true": [\n        7,\n        8\n    ]\n}\n'),
    ("[]", "groupBy($this)", "{}\n"),
    ("[1.5,2.5,1.5]", "groupBy($this)",
     '{\n    "1.5": [\n        1.5,\n        1.5\n    ],\n    "2.5": [\n        2.5\n    ]\n}\n'),
    ('["only"]', "groupBy($this)", '{\n    "only": [\n        "only"\n    ]\n}\n'),
])
def test_group_by_keys_are_stringified(run, stdin, query, expected):
    """groupBy builds a map keyed by the string form of the group value."""
    result = run(["-i", "json", "-o", "json", query], stdin=stdin)
    # CATCHES: non string keys are rendered with their JSON literal text
    # (`1`, `1.5`, `false`) and groups appear in first-seen order.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_group_by_field_name(run):
    """groupBy over a property groups whole elements by that property."""
    stdin = ('[{"name":"Alice","dept":"eng"},{"name":"Bob","dept":"eng"},'
             '{"name":"Carol","dept":"sales"}]')
    result = run(["-i", "json", "-o", "json", "groupBy(dept)"], stdin=stdin)
    # CATCHES: the grouped elements keep their full objects, not just the
    # grouping key.
    assert result.returncode == 0
    assert result.out == """{
    "eng": [
        {
            "name": "Alice",
            "dept": "eng"
        },
        {
            "name": "Bob",
            "dept": "eng"
        }
    ],
    "sales": [
        {
            "name": "Carol",
            "dept": "sales"
        }
    ]
}
"""
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("map(number)", "[\n    1,\n    2,\n    3\n]\n"),
    ("map($key)", "[\n    0,\n    1,\n    2\n]\n"),
    ("map($key + $this)", "[\n    10,\n    21,\n    32\n]\n"),
])
def test_map_over_a_slice(run, query, expected):
    """map evaluates an expression per element."""
    stdin = ("[{\"number\":1},{\"number\":2},{\"number\":3}]"
             if query.startswith("map(number") else "[10,20,30]")
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: $key is the element index inside map, and $key + $this is
    # integer addition.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_map_with_a_chained_selector_and_multiline_query(run):
    """Whitespace and newlines inside a query are insignificant."""
    query = '\n\t\t\tmap (\n\t\t\t\t{\n\t\t\t\t\ttotal: add( foo, bar, 1 )\n\t\t\t\t}\n\t\t\t)\n\t\t\t.map ( total )'
    result = run(["-i", "json", query],
                 stdin='[{"foo":1,"bar":4},{"foo":2,"bar":5},{"foo":3,"bar":6}]')
    # CATCHES: the whole selector is one string argument, so tabs and newlines
    # between tokens must be skipped by the tokenizer.
    assert result.returncode == 0
    assert result.out == "[\n    6,\n    8,\n    10\n]\n"
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("filter(true)", "[\n    1,\n    2,\n    3\n]\n"),
    ("filter(!false)", "[\n    1,\n    2,\n    3\n]\n"),
    ("filter(false)", "[]\n"),
    ("filter(!true)", "[]\n"),
    ("filter($this == 2)", "[\n    2\n]\n"),
    ("filter($this != 2)", "[\n    1,\n    3\n]\n"),
    ("filter($key >= 1)", "[\n    2,\n    3\n]\n"),
    ("filter($key == 0 || $this == 3)", "[\n    1,\n    3\n]\n"),
])
def test_filter_predicates(run, query, expected):
    """filter keeps the elements whose predicate is true."""
    result = run(["-i", "json", query], stdin="[1,2,3]")
    # CATCHES: `!` binds tighter than `==`, and $key is the slice index, so
    # `filter(false)` yields an empty (not null) array.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("[1,2,3].each($this = $this + 1)", "[\n    2,\n    3,\n    4\n]\n"),
    ("[10,20,30].each($this = $this + $key)", "[\n    10,\n    21,\n    32\n]\n"),
    ("[2,3,4].each($this = $this * 2)", "[\n    4,\n    6,\n    8\n]\n"),
])
def test_each_assigns_in_place(run, query, expected):
    """each runs an assignment against every element."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: `each` mutates the elements and returns the slice, unlike `map`
    # which builds a new one - observable because $key is usable on the left
    # hand side arithmetic.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ("[1,2,3,4]", "reduce($this, 0, $acc + $this)", "10\n"),
    ("[1,2,3,4]", "reduce($this, 1, $acc * $this)", "24\n"),
    ("[10,20,30]", "reduce($this, 0, $acc + $key)", "3\n"),
    ("[1,2,3,4]", "reduce($this, 0, $acc + $this) > 5", "true\n"),
    ("[]", "reduce($this, 0, $acc + $this)", "0\n"),
    ('["a","b"]', 'reduce($this, "", $acc + $this)', '"ab"\n'),
])
def test_reduce_folds_with_an_initial_value(run, stdin, query, expected):
    """reduce folds the slice into an accumulator."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: an empty slice returns the initial accumulator untouched, and
    # $acc refers to the running total while $this is the element.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("[1, 2, 3].any($this > 2)", "true\n"),
    ("[1, 2, 3].any($this > 5)", "false\n"),
    ("[1, 2, 3].any(!($this > 2))", "true\n"),
    ("[1, 2, 3].any(false)", "false\n"),
    ("[].any($this > 0)", "false\n"),
    ("[1, 2, 3].all($this > 0)", "true\n"),
    ("[1, 2, 3].all($this > 1)", "false\n"),
    ("[1, 2, 3].all(!($this > 5))", "true\n"),
    ("[].all($this > 0)", "true\n"),
    ("[1, 2, 3].count($this > 0)", "3\n"),
    ("[1, 2, 3].count($this > 5)", "0\n"),
    ("[].count($this > 0)", "0\n"),
])
def test_any_all_count_over_slices(run, query, expected):
    """any/all/count quantify over a slice with empty-slice conventions."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: `all` is vacuously true and `any` is vacuously false on an
    # empty slice, and parenthesised negation is supported in the predicate.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ("", 'true ? "yes" : "no"', '"yes"\n'),
    ("", 'false ? "yes" : "no"', '"no"\n'),
    ('{"age": 25}', 'age >= 18 ? "adult" : "minor"', '"adult"\n'),
    ('{"age": 10}', 'age >= 18 ? "adult" : "minor"', '"minor"\n'),
    ("", 'true ? (false ? "a" : "b") : "c"', '"b"\n'),
    ("", 'true ? (true ? (false ? "a" : "b") : "c") : "d"', '"b"\n'),
    ('{"score": 85}', 'score >= 90 ? "A" : (score >= 80 ? "B" : "C")', '"B"\n'),
    ("", "true ? 42 : 0", "42\n"),
    ("", "true ? 1 + 2 : 3 + 4", "3\n"),
    ("", "false ? 1 + 2 : 3 + 4", "7\n"),
    ("", 'true ? "hello" + " " + "world" : "goodbye"', '"hello world"\n'),
    ("", 'true ? len("abc") : len("de")', "3\n"),
    ("", "true ? true : false", "true\n"),
    ('{"a": 5, "b": 10}', 'a > 1 && b > 5 ? "both" : "nope"', '"both"\n'),
    ('{"a": 5, "b": 10}', 'a > 1 || b > 5 ? "yes" : "no"', '"yes"\n'),
    ('{"user": {"active": true}}', 'user.active ? "yes" : "no"', '"yes"\n'),
])
def test_ternary_expressions(run, stdin, query, expected):
    """The ternary operator evaluates only the chosen branch."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: the untaken branch is never evaluated (so `3 + 4` does not run
    # when the condition is true) and ternaries nest on either side.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_ternary_inside_map(run):
    """A ternary used as a map expression is evaluated per element."""
    stdin = '{"items": [{"val": 10}, {"val": 3}, {"val": 7}]}'
    result = run(["-i", "json", 'items.map(val >= 5 ? "big" : "small")'], stdin=stdin)
    # CATCHES: the conditional is evaluated with each element as the scope, so
    # `val` resolves per element.
    assert result.returncode == 0
    assert result.out == '[\n    "big",\n    "small",\n    "big"\n]\n'
    assert result.err == ""


def test_ternary_producing_an_object(run):
    """A ternary may return a whole object literal."""
    result = run(["-i", "json", "-o", "json", 'active ? {status: "on"} : {status: "off"}'],
                 stdin='{"active": true}')
    # CATCHES: object literals are valid ternary branches and the winner is
    # written with the normal pretty printer.
    assert result.returncode == 0
    assert result.out == '{\n    "status": "on"\n}\n'
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"a": null, "b": 2}', 'a ?? "default"', '"default"\n'),
    ('{"a": 1}', 'b ?? "default"', '"default"\n'),
    ('{"a": null, "b": null, "c": 3}', 'a ?? b ?? c ?? "none"', "3\n"),
    ("null", "null ?? 1", "1\n"),
    ('{"nested": {"three": null}}', 'nested.three ?? 2', "2\n"),
    ('{"nested": {"three": null, "four": 4}}', 'nested.three ?? nested.four ?? 10', "4\n"),
])
def test_coalescing_operator(run, stdin, query, expected):
    """`??` returns the first non-null operand, including missing keys."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: a missing map key coalesces like a null value, so `b ?? ...`
    # works even though `b` does not exist in the document.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("$x=1", "1\n"),
    ("$x=1;$x=$x*2", "2\n"),
    ("$x=1;$y=$x+1;$y", "2\n"),
])
def test_variable_assignment_chains(run, query, expected):
    """Semicolon separated assignments run left to right."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the value of the whole selector is the last statement, and a
    # later statement can read a variable set by an earlier one.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"a": {"x": 1}, "b": {"x": 2}}', "..x", "[\n    1,\n    2\n]\n"),
    ('{"a": {"x": 1}}', "..z", "[]\n"),
    ('[{"name":"Tom"}, {"name":"Jim"}, {"foo": "Bar"}]', "..name", '[\n    "Tom",\n    "Jim"\n]\n'),
])
def test_recursive_descent_property(run, stdin, query, expected):
    """`..key` collects every matching value at any depth."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: results are collected depth first and a key with no matches
    # yields an empty array rather than an error.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_recursive_descent_index(run):
    """`..[0]` collects the first element of every nested array."""
    stdin = ('{"user": {"name": "Alice", "roles": ["admin", "editor"]}, '
             '"tags": ["x", "y"], "count": 10}')
    result = run(["-i", "json", "..[0]"], stdin=stdin)
    # CATCHES: the index form of recursive descent walks into arrays nested
    # anywhere in the document and returns leaf values in document order.
    assert result.returncode == 0
    assert result.out == '[\n    "admin",\n    "x"\n]\n'
    assert result.err == ""


def test_recursive_descent_wildcard(run):
    """`..*` collects every leaf value in the document."""
    stdin = ('{"user": {"name": "Alice", "roles": ["admin", "editor"], '
             '"meta": {"active": true, "score": 42}}, "tags": ["x", "y"], "count": 10}')
    result = run(["-i", "json", "..*"], stdin=stdin)
    # CATCHES: wildcard descent returns leaves only (never containers) and in
    # document order: strings, then booleans, then numbers.
    assert result.returncode == 0
    assert result.out == """[
    "Alice",
    "admin",
    "editor",
    true,
    42,
    "x",
    "y",
    10
]
"""
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"nested": {"target": 42, "other": 1}}', 'search($key == "target")', "[\n    42\n]\n"),
    ('{"a": {"target": 42}, "b": {"target": 1}}', 'search($key == "target")', "[\n    42,\n    1\n]\n"),
    ('[{"x":1},{"y":2},{"x":3}]', 'search(has("x"))', '[\n    {\n        "x": 1\n    },\n    {\n        "x": 3\n    }\n]\n'),
    ('[{"name":"alice"},{"name":"bob"}]', 'search(name == "alice")', '[\n    {\n        "name": "alice"\n    }\n]\n'),
    ('[{"name":"alice"}]', 'search(name == "charlie")', "[]\n"),
])
def test_search_finds_matching_nodes(run, stdin, query, expected):
    """search walks the document returning whole matching nodes."""
    result = run(["-i", "json", "-o", "json", query], stdin=stdin)
    # CATCHES: search returns the containing nodes (maps/arrays), not the
    # matched values, and no match yields an empty array.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_search_combined_with_each_and_assignment(run):
    """A whole-document update driven by search."""
    result = run(["-i", "json", "-o", "json", "--root", 'search(has("x")).each(x = x+1)'],
                 stdin='[{"x":1},{"x":2},{"x":3}]')
    # CATCHES: --root is required to see the mutation, since the query result
    # is the list of found nodes and not the updated document.
    assert result.returncode == 0
    assert result.out == """[
    {
        "x": 2
    },
    {
        "x": 3
    },
    {
        "x": 4
    }
]
"""
    assert result.err == ""


def test_branch_is_gated_behind_unstable(run):
    """branch() refuses to run without --unstable."""
    result = run(["-i", "json", "branch(1, 2, 3)"], stdin="null")
    # CATCHES: the gate is an execution error (exit 1) whose message names the
    # flag that enables it, not a parse error.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: error evaluating expression "
        "ast.BranchExpr: unstable ast types are not enabled. to enable them use --unstable\n")


@pytest.mark.parametrize("query,expected", [
    ("branch(1)", "1\n"),
    ("branch(1, 1+1, 3/1, 123)", "1\n\n2\n\n3\n\n123\n"),
    ("[1,2,3].branch(...)", "1\n\n2\n\n3\n"),
    ("(branch(1, 2, 3)) * 2", "2\n\n4\n\n6\n"),
    ("branch([1], [2], [3]).map($this * 2).branch()", "2\n\n4\n\n6\n"),
])
def test_branch_with_unstable_writes_one_document_per_value(run, query, expected):
    """branch() with --unstable writes each branch as its own document."""
    result = run(["-i", "json", "--unstable", query], stdin="null")
    # CATCHES: branch output is multiple documents separated by a blank line,
    # i.e. each value is terminated by a newline and then a separator newline.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_branch_multiplies_per_element(run):
    """A branch propagates through arithmetic and chained calls."""
    result = run(["-i", "json", "--unstable", 'branch({"x":1}, {"x":2}, {"x":3}).x * $this'],
                 stdin="[5]")
    # CATCHES: $this still refers to the input document inside a branch, so
    # each branch's `.x` is multiplied by the outer value 5.
    assert result.returncode == 0
    assert result.out == "1\n\n4\n\n9\n"
    assert result.err == ""


def test_spread_of_a_slice_writes_multiple_documents(run):
    """A trailing `...` turns one slice result into several documents."""
    result = run(["-i", "json", "users.map(name)..."],
                 stdin='{"users": [{"name": "Alice"}, {"name": "Bob"}]}')
    # CATCHES: spread output is one document per element, each terminated by a
    # newline and separated by an extra blank line.
    assert result.returncode == 0
    assert result.out == '"Alice"\n\n"Bob"\n'
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"user": {"name": "John"}}',
     'user = {user..., name: {"first": $this.user.name, "last": "Doe"}}',
     '{\n    "user": {\n        "name": {\n            "first": "John",\n            "last": "Doe"\n        }\n    }\n}\n'),
    ('{"user": {"name": "John"}}',
     'user.name = {"first": user.name, "last": "Doe"}',
     '{\n    "user": {\n        "name": {\n            "first": "John",\n            "last": "Doe"\n        }\n    }\n}\n'),
    ('{"user": {"name": "John"}}',
     'user.(name = {"first": name, "last": "Doe"})',
     '{\n    "user": {\n        "name": {\n            "first": "John",\n            "last": "Doe"\n        }\n    }\n}\n'),
])
def test_assignment_forms(run, stdin, query, expected):
    """Three spellings of a nested assignment all produce the same document."""
    result = run(["-i", "json", "-o", "json", "--root", query], stdin=stdin)
    # CATCHES: the grouped `user.(...)` form re-scopes the inner expression to
    # the value of `user`, so the bare `name` resolves inside it.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"title":"Mr","age":31}', 'title = "Mrs"', '{\n    "title": "Mrs",\n    "age": 31\n}\n'),
    ("[1,2,3]", "$this[1] = 4", "[\n    1,\n    4,\n    3\n]\n"),
])
def test_assignment_with_root_returns_the_mutated_document(run, stdin, query, expected):
    """Plain assignments mutate the document, exposed via --root."""
    result = run(["-i", "json", "-o", "json", "--root", query], stdin=stdin)
    # CATCHES: without --root the query result is the assigned value, so the
    # mutation is only observable through the root document.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_assignment_without_root_returns_the_assigned_value(run):
    """Without --root an assignment evaluates to its right hand side."""
    result = run(["-i", "json", "-o", "json", 'title = "Mrs"'], stdin='{"title":"Mr","age":31}')
    # CATCHES: the query result is the new value, not the updated document -
    # the opposite of what --root gives for the same query.
    assert result.returncode == 0
    assert result.out == '"Mrs"\n'
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ('[{"x":1},{"x":2},{"x":3}]', "$root..x.each($this = $this+1)",
     "[\n    {\n        \"x\": 2\n    },\n    {\n        \"x\": 3\n    },\n    {\n        \"x\": 4\n    }\n]\n"),
    ('[{"x":1},{"x":2},{"x":3}]', "$root..*.each($this = 4)",
     "[\n    {\n        \"x\": 4\n    },\n    {\n        \"x\": 4\n    },\n    {\n        \"x\": 4\n    }\n]\n"),
])
def test_recursive_descent_assignment(run, stdin, query, expected):
    """Assigning through a recursive descent updates every match in place."""
    result = run(["-i", "json", "-o", "json", "--root", query], stdin=stdin)
    # CATCHES: $root is needed to escape the descent result and see the
    # mutations applied back onto the original document.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_recursive_descent_index_assignment(run):
    """Assigning through `..[n]` updates one index of every nested array."""
    stdin = '[ {"x":[1,2,3]} , {"y":[4,5,6]} , {"z":[7,8,9]} ]'
    result = run(["-i", "json", "-o", "json", "--root", "$root..[1].each($this = $this+1)"],
                 stdin=stdin)
    # CATCHES: only index 1 of each nested array changes; every other element
    # is left untouched even though `..` visited them.
    assert result.returncode == 0
    assert result.out == """[
    {
        "x": [
            1,
            3,
            3
        ]
    },
    {
        "y": [
            4,
            6,
            6
        ]
    },
    {
        "z": [
            7,
            9,
            9
        ]
    }
]
"""


@pytest.mark.parametrize("stdin,query,expected", [
    ('{"a": 1}', 'if (a == 1) { "one" } else { "other" }', '"one"\n'),
    ('{"a": 1}', 'if (a == 2) { "one" } else { "other" }', '"other"\n'),
    ('{"a": 1}', 'if (a == 2) { "two" } elseif (a == 1) { "one" } else { "other" }',
     '"one"\n'),
    ('{"a": 1}',
     'if (a == 3) { "three" } elseif (a == 2) { "two" } elseif (a == 1) { "one" } else { "other" }',
     '"one"\n'),
    ('{"a": 1}', 'if (a == 3) { "three" }', "null\n"),
    ('{"a": 1}', 'if (false) { "x" } elseif (false) { "y" }', "null\n"),
    ('{"a": 1}', 'if (true) { 1 } elseif (false) { 2 }', "1\n"),
    ('{"a": 1}', 'if (true) { $this.a } else { 0 }', "1\n"),
    ('{"a": 1}', 'if (true) { if (false) { 1 } else { 2 } } else { 3 }', "2\n"),
    ('{"a": 1}', 'if (true) { 1', "1\n"),
])
def test_if_expressions(run, stdin, query, expected):
    """`if`/`elseif`/`else` blocks evaluate exactly one branch."""
    result = run(["-i", "json", "-o", "json", query], stdin=stdin)
    # CATCHES: the chain keyword is the single word `elseif` and a missing
    # `else` branch yields null rather than an error, while an unclosed body
    # is tolerated - a stricter parser would reject the last two rows.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,position,kind,value", [
    ("if (true)", 0, 0, ""),
    ("if true { 1 }", 3, 19, "true"),
    ("if (true) 1", 10, 18, "1"),
    ("else { 2 }", 0, 41, "else"),
    ('if (a == 2) { "two" } else if (a == 1) { "one" }', 27, 40, "if"),
])
def test_if_parse_errors_report_token_kinds(run, query, position, kind, value):
    """Malformed `if` statements fail at parse time naming the bad token."""
    result = run(["-i", "json", "-o", "json", query], stdin='{"a": 1}')
    # CATCHES: `else if` written as two words is rejected (only `elseif`
    # lexes as one token), the condition must be parenthesised and the body
    # must be braced, and the message pins the lexer's token kind numbers.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error parsing selector: failed to parse: '
        'unexpected token %d "%s" at position %d.\n' % (kind, value, position))


@pytest.mark.parametrize("query,message", [
    ("if (a) { 1 }",
     "execution error when processing ast.ConditionalExpr: "
     "error converting condition to boolean: unexpected type: expected bool, got int"),
    ('if (b == 1) { "x" } else { "y" }',
     'execution error when processing ast.ConditionalExpr: '
     'error evaluating condition: execution error when processing ast.BinaryExpr: '
     'error evaluating left expression: execution error when processing '
     'ast.PropertyExpr: map key not found: "b"'),
])
def test_if_condition_failures(run, query, message):
    """A non-boolean or missing condition aborts the whole statement."""
    result = run(["-i", "json", "-o", "json", query], stdin='{"a": 1}')
    # CATCHES: conditions are strict - no truthiness coercion of ints and no
    # optional-key handling - and the failure is wrapped by ConditionalExpr.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == "dasel: error: error executing selector: %s\n" % message


@pytest.mark.parametrize("query,expected", [
    ("b = 9", '{\n    "b": 9,\n    "a": 2\n}\n'),
    ("a = 9", '{\n    "b": 1,\n    "a": 9\n}\n'),
])
def test_assignment_overwrites_in_place(run, query, expected):
    """Assigning to an existing key keeps its original position."""
    result = run(["-i", "json", "-o", "json", "--root", query], stdin='{"b": 1, "a": 2}')
    # CATCHES: the ordered map updates the value in place, so document key
    # order survives the mutation instead of re-appending the key at the end.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_assignment_to_a_missing_key_is_rejected(run):
    """`=` can only update keys that already exist."""
    result = run(["-i", "json", "-o", "json", "--root", "z = 9"], stdin='{"b": 1, "a": 2}')
    # CATCHES: new keys cannot be created by assignment - the left hand side
    # is resolved as a property read first, which fails on the missing key.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.BinaryExpr: error evaluating left expression: execution error when '
        'processing ast.PropertyExpr: map key not found: "z"\n')


@pytest.mark.parametrize("query,expected", [
    ("mapValues($this * 10)", '{\n    "b": 10,\n    "a": 20\n}\n'),
    ("mapValues($key)", '{\n    "b": "b",\n    "a": "a"\n}\n'),
])
def test_map_values_transforms_every_value(run, query, expected):
    """mapValues rebuilds a map with each value replaced by an expression."""
    result = run(["-i", "json", "-o", "json", query], stdin='{"b": 1, "a": 2}')
    # CATCHES: key order is preserved and $key is bound to the current key
    # inside the expression, mirroring how $key works inside map.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_map_values_rejects_non_maps(run):
    """mapValues only operates on maps."""
    result = run(["-i", "json", "-o", "json", "mapValues($this)"], stdin="[1, 2]")
    # CATCHES: the guard mirrors the map() wording but names mapValues, and
    # the failure is wrapped by the MapValuesExpr AST node.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.MapValuesExpr: cannot mapValues over non-map\n")


@pytest.mark.parametrize("in_format,stdin,query,expected", [
    ("json", '{"a": "x"}', "a = 1", '{\n    "a": 1\n}\n'),
    ("json", '[1, 2, 3]', '$this[0] = "s"', '[\n    "s",\n    2,\n    3\n]\n'),
    ("json", '{"m": {"a": 1}}', 'm.a = "str"', '{\n    "m": {\n        "a": "str"\n    }\n}\n'),
    ("toml", 'a = 1\n', 'a = "str"', "a = 'str'\n"),
])
def test_assignment_replaces_values_with_a_different_type(
        run, in_format, stdin, query, expected):
    """Assignment overwrites a value regardless of the stored type."""
    result = run(["-i", in_format, "-o", in_format, "--root", query], stdin=stdin)
    # CATCHES: writing over an existing key or slice index replaces the value
    # wholesale - an int slot can hold a string afterwards - instead of
    # raising a type mismatch, and nested paths mutate in place.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_assignment_to_the_root_document_value(run):
    """`$this = x` replaces the whole document value."""
    result = run(["-i", "json", "-o", "json", "$this = 5"], stdin='{"a": 1}')
    # CATCHES: the root value itself is assignable, so the query result is the
    # newly assigned scalar rather than the input document.
    assert result.returncode == 0
    assert result.out == "5\n"
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    # end is inclusive, so [:2] over three elements keeps all of them
    ("[1, 2, 3]", "$this[:2]", "[\n    1,\n    2,\n    3\n]\n"),
    ("[1, 2, 3]", "$this[:0]", "[\n    1\n]\n"),
    # a negative end is rebased against the length, so [:-1] reaches the end
    ("[10, 20, 30, 40, 50]", "$this[:-1]",
     "[\n    10,\n    20,\n    30,\n    40,\n    50\n]\n"),
    # strings go through the same range expression
    ('"hello"', "$this[:2]", '"hel"\n'),
    ('"hello"', "$this[1:3]", '"ell"\n'),
])
def test_slice_range_with_omitted_start(run, stdin, query, expected):
    """`[:n]` builds a range that starts at index 0 and includes index n."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: omitting the start is not the same as omitting the end - the
    # range still ends at the (inclusive) given index, so [:2] over [1,2,3]
    # returns all three elements rather than the first two.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("stdin,query,expected", [
    ("[10, 20, 30, 40, 50]", "$this[-2:]", "[\n    40,\n    50\n]\n"),
    ("[10, 20, 30, 40, 50]", "$this[-3:-1]", "[\n    30,\n    40,\n    50\n]\n"),
    ("[10, 20, 30, 40, 50]", "$this[3:1]", "[\n    40,\n    30,\n    20\n]\n"),
    ("[1, 2, 3]", "$this[2:0]", "[\n    3,\n    2,\n    1\n]\n"),
])
def test_slice_range_negative_and_descending(run, stdin, query, expected):
    """Negative bounds count back from the end; start > end walks backwards."""
    result = run(["-i", "json", query], stdin=stdin)
    # CATCHES: bounds are rebased as length+index and a start greater than the
    # end iterates downwards instead of returning an empty slice.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_slice_range_end_past_the_length_is_an_error(run):
    """A range end beyond the last index fails once the walk reaches it."""
    result = run(["-i", "json", "$this[:99]"], stdin="[1, 2, 3]")
    # CATCHES: the failure surfaces as a slice index error naming the first
    # out-of-range index (3), not the requested bound (99) or the length.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.ChainedExpr: error executing expression: execution error when "
        "processing ast.RangeExpr: error getting slice index: slice index out "
        "of range: 3\n")


def test_string_range_end_past_the_length_panics(run):
    """The string range path has no bounds guard and crashes the process."""
    result = run(["-i", "json", "$this[:99]"], stdin='"hello"')
    # CATCHES: unlike slices, which report a clean error, the string range
    # indexes the underlying string directly and dies with exit status 2.
    assert result.returncode == 2
    assert result.out == ""
    assert result.err.splitlines()[0] == (
        "panic: runtime error: index out of range [5] with length 5")


@pytest.mark.parametrize("query,expected", [
    ("$this..[...]", "[\n    [\n        1\n    ],\n    [\n        2,\n        3\n    ]\n]\n"),
    ("$this..[0]", "[\n    2\n]\n"),
    ("$this..[:1]", "[\n    [\n        2,\n        3\n    ]\n]\n"),
])
def test_recursive_descent_bracket_forms(run, query, expected):
    """`..[...]`, `..[i]` and `..[:i]` apply the bracket to each descendant."""
    result = run(["-i", "json", query],
                 stdin='{"a": {"b": 1}, "c": [2, 3]}')
    # CATCHES: a bracket directly after the recursive descent operator is
    # parsed as an index/range/spread over every non-scalar descendant, so
    # `..[...]` spreads each container it finds rather than the whole tree.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("$this..[...]", "[\n    [\n        1,\n        2\n    ],\n    [\n        3\n    ]\n]\n"),
    ("$this..[:0]", "[\n    [\n        1\n    ],\n    [\n        3\n    ]\n]\n"),
    ("$this..[1]", "[\n    2\n]\n"),
])
def test_recursive_descent_bracket_over_sibling_arrays(run, query, expected):
    """Each sibling container contributes its own bracketed result, in order."""
    result = run(["-i", "json", query], stdin='{"x": [1, 2], "y": [3]}')
    # CATCHES: results are appended per descendant in document order, so two
    # sibling arrays yield two elements rather than one concatenated slice.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_recursive_descent_swallows_bracket_errors(run):
    """A bracket that fails on a descendant is skipped, not fatal."""
    result = run(["-i", "json", "$this..[:1]"], stdin='{"a": {"b": 1}}')
    # CATCHES: ranging over the map descendant would fail with "range expects
    # a slice or string, got map" when run directly, but inside a recursive
    # descent every inner error is swallowed and an empty result is returned.
    assert result.returncode == 0
    assert result.out == "[]\n"
    assert result.err == ""


def test_recursive_descent_bracket_wildcard_is_a_parse_error(run):
    """`..[*]` is rejected: the bracket after `..` must be an index/range."""
    result = run(["-i", "json", "$this..[*]"], stdin='{"a": [1]}')
    # CATCHES: `[*]` is only understood after a symbol, so after the recursive
    # descent operator the parser demands an index expression and reports the
    # star by its internal token kind (26).
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error parsing selector: failed to parse: '
        'unexpected token 26 "*" at position 8.\n')


@pytest.mark.parametrize("query,position", [
    # an index followed by anything but `]` or `:` is not an index or a range
    ("$this[1 2]", 'unexpected token 18 "2" at position 8.'),
    ("$this[1 2:3]", 'unexpected token 18 "2" at position 8.'),
    # each of the three expression slots reports its own position
    ("$this[)]", 'unexpected token 9 ")" at position 6.'),
    ("$this[:)]", 'unexpected token 9 ")" at position 7.'),
    ("$this[1:)]", 'unexpected token 9 ")" at position 8.'),
])
def test_bracket_expression_parse_errors(run, query, position):
    """Malformed bracket expressions fail with the offending token and slot."""
    result = run(["-i", "json", query], stdin="[1, 2, 3]")
    # CATCHES: the positions advance with the slot being parsed (start, then
    # the end after a leading colon, then the end after a full start), so a
    # re-implementation must parse the brackets in exactly that order.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == "dasel: error: error parsing selector: failed to parse: %s\n" % position


@pytest.mark.parametrize("query,expected_err", [
    ("[1, )]", 'unexpected token 9 ")" at position 4.'),
    ("[1,2][)]", 'unexpected token 9 ")" at position 6.'),
])
def test_array_literal_parse_errors(run, query, expected_err):
    """A bad element or trailing index aborts the array literal parse."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the array literal and the bracket that may follow it share the
    # same expression parser, so both report the raw token kind and position.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == "dasel: error: error parsing selector: failed to parse: %s\n" % expected_err


@pytest.mark.parametrize("query,expected", [
    # an unclosed literal is accepted at end of input
    ("[1, 2", "[\n    1,\n    2\n]\n"),
    ("[1, 2,", "[\n    1,\n    2\n]\n"),
    ("[]", "[]\n"),
    # space separated values keep only the last value of each run
    ("[1 2]", "[\n    2\n]\n"),
    ("[1 2 3]", "[\n    3\n]\n"),
    ("[1, 2 3]", "[\n    1,\n    3\n]\n"),
    ("[1,2 3,4]", "[\n    1,\n    3,\n    4\n]\n"),
])
def test_array_literal_lenient_forms(run, query, expected):
    """Array literals are lenient: EOF closes them and spaces drop earlier values."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: a missing closing bracket is not an error, and a space between
    # elements silently discards all but the last expression of the run.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("[1, 2][0]", "1\n"),
    ('["a", "b"][1]', '"b"\n'),
    ("[1, 2][0:1]", "[\n    1,\n    2\n]\n"),
    # a trailing dot on its own is ignored
    ("[1, 2].", "[\n    1,\n    2\n]\n"),
])
def test_array_literal_supports_following_selectors(run, query, expected):
    """Index, range and trailing-dot selectors may follow an array literal."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the literal is a first class expression, so `[1, 2][0]` indexes
    # the freshly built array instead of being a parse error, and the range
    # stays end-inclusive ([0:1] returns both elements).
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_array_literal_followed_by_a_property_is_an_error(run):
    """A bare word after an array literal is treated as a property access."""
    result = run(["-i", "json", "[1, 2]foo"], stdin="null")
    # CATCHES: the parser chains `foo` as a property onto the array, and the
    # property executor then rejects the array - the literal itself parses.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.ChainedExpr: error executing expression: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got array\n")
