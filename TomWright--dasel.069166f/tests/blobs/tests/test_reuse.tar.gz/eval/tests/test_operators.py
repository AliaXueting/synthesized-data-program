"""Binary and unary operator behaviour over the value model: arithmetic,
comparison, regex matching and lexer level rejections. Ported from the native
table driven tests in ``src/execution/execute_binary_test.go`` and
``src/execution/execute_unary_test.go``."""

import pytest


@pytest.mark.parametrize("query,expected", [
    ("5 - 2", "3\n"),
    ("5 - 2.5", "2.5\n"),
    ("5.5 - 2", "3.5\n"),
    ("5.5 - 0.5", "5\n"),
    ("2.5 - 2.5", "0\n"),
    ("0 - 5", "-5\n"),
    ("5 * 2", "10\n"),
    ("5 * 2.5", "12.5\n"),
    ("2.5 * 2", "5\n"),
    ("1.5 * 1.5", "2.25\n"),
    ("10 / 2", "5\n"),
    ("10 / 4", "2\n"),
    ("10.0 / 4", "2.5\n"),
    ("10 / 4.0", "2.5\n"),
    ("10 % 3", "1\n"),
    ("10 % 3.5", "3\n"),
    ("7.5 % 2", "1.5\n"),
    ("2 - -3", "5\n"),
])
def test_arithmetic_operators(run, query, expected):
    """-, *, / and % follow Go's int/float promotion rules."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: int/int division truncates (10 / 4 is 2, not 2.5), any float
    # operand promotes the result to a float, and whole float results are
    # printed without a trailing `.0`.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("45.2 + 5 * 4 - 2 / 2", "64.2\n"),
    ("(45.2 + 5) * ((4 - 2) / 2)", "50.2\n"),
    ("1 + 1 - 1 + 1 * 2", "3\n"),
    ("5 - 2 - 3", "0\n"),
])
def test_arithmetic_precedence_and_grouping(run, query, expected):
    """* and / bind tighter than + and -, and parentheses override."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: `45.2 + 5 * 4 - 2 / 2` is 45.2 + 20 - 1 (not left-to-right),
    # so a re-implementation with flat associativity computes 101.4.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,operator", [
    ('"a" - "b"', "subtract"),
    ('"a" * 2', "multiply"),
    ("true + true", "add"),
    ("[1] + [2]", "add"),
    ('{"a":1} + {"b":2}', "add"),
    ("null - 1", "subtract"),
    ("null * 1", "multiply"),
])
def test_arithmetic_type_errors(run, query, operator):
    """Arithmetic rejects every operand combination but int/float and string+string."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: each operator has its own verb in the message (could not
    # add/subtract/multiply) and arrays/maps/bools/null are never coerced.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err.startswith(
        'dasel: error: error executing selector: execution error when processing '
        'ast.BinaryExpr: could not %s: incompatible types: ' % operator)


@pytest.mark.parametrize("query,expected", [
    ("1 == 1", "true\n"),
    ("1 == 2", "false\n"),
    ("1 != 2", "true\n"),
    ('"abc" == "abc"', "true\n"),
    ('"abc" != "abd"', "true\n"),
    ("true == true", "true\n"),
    ("null == null", "true\n"),
    ("[1,2] == [1,2]", "true\n"),
    ('{"a":1} == {"a":1}', "true\n"),
    ("2 > 1", "true\n"),
    ("1 > 2", "false\n"),
    ("2 >= 2", "true\n"),
    ("2 >= 3", "false\n"),
    ("1 < 2", "true\n"),
    ("2 < 1", "false\n"),
    ("2 <= 2", "true\n"),
    ("3 <= 2", "false\n"),
    ('"a" < "b"', "true\n"),
    ('"b" < "a"', "false\n"),
    ("1 <= 1.0", "true\n"),
    ("2 >= 1.5", "true\n"),
])
def test_comparison_operators(run, query, expected):
    """==, !=, <, >, <= and >= compare scalars and whole structures."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: equality is deep (arrays and maps compare element wise), int
    # and float compare numerically across types, and strings compare
    # lexicographically rather than by length.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ('"hello world" =~ r/ello/', "true\n"),
    ('"hello world" =~ r/^world/', "false\n"),
    ('"hello world" !~ r/helloworld/', "true\n"),
    ('"hello" =~ r/l+/', "true\n"),
])
def test_regex_like_operators(run, query, expected):
    """`=~` and `!~` match the left string against an r/.../ pattern."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the pattern is a bare `r/.../` literal, the match is unanchored
    # (so `ello` matches inside `hello world`) and `!~` negates the result.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,message", [
    ('"abc" =~ 5', "like requires right side to be a regex pattern"),
    ('"a" !~ "b"', "like requires right side to be a regex pattern"),
    ('1 =~ r/1/', "like requires left side to be a string, got int"),
])
def test_regex_operands_are_validated(run, query, message):
    """`=~` requires a string on the left and a pattern literal on the right."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the operands are not coerced - a quoted string is not a regex
    # pattern and a number is not a string - and both spellings report
    # through the same `like` wording.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.BinaryExpr: %s\n" % message)


@pytest.mark.parametrize("stdin,expected", [
    ('"hello"', '"hello"\n'),
    ("null", "null\n"),
    ('{"a": 1}', '{\n    "a": 1\n}\n'),
])
def test_a_lone_regex_literal_echoes_the_document(run, stdin, expected):
    """A regex pattern with no operator evaluates to the input unchanged."""
    result = run(["-i", "json", "-o", "json", "r/abc/"], stdin=stdin)
    # CATCHES: the pattern literal alone is a valid expression that returns
    # the current value, so the document is echoed rather than rejected.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_an_invalid_regex_fails_at_parse_time(run):
    """An uncompilable pattern is reported while parsing the selector."""
    result = run(["-i", "json", '$this =~ r/(/'], stdin="null")
    # CATCHES: the regexp is compiled during parsing (before any input is
    # read) and the raw Go regexp error text is passed through.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error parsing selector: failed to compile regexp pattern: "
        "error parsing regexp: missing closing ): `(`\n")


@pytest.mark.parametrize("query,character,position", [
    ("a & b", "&", 2),
    ("a | b", "|", 2),
    ("~", "~", 0),
    ("@", "@", 0),
    ("#", "#", 0),
])
def test_tokenizer_rejects_unknown_characters(run, query, character, position):
    """Characters with no token meaning fail with their byte position."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: `&` and `|` are single tokens (there is no bitwise operator)
    # and the position is the byte offset of the offending character.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error parsing selector: failed to tokenize: "
        "unexpected token: %s at position %d.\n" % (character, position))


@pytest.mark.parametrize("query,kind,text,position", [
    ("a ++ b", 21, "++", 2),
    ("a += b", 22, "+=", 2),
    ("a -- b", 24, "--", 2),
    ("a -= b", 25, "-=", 2),
    (";", 60, ";", 0),
])
def test_lexed_but_unparsed_operators_have_stable_kinds(run, query, kind, text, position):
    """`++`, `+=`, `--`, `-=` and a lone `;` lex but nothing parses them."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the lexer still produces a token for each spelling and the
    # parser error exposes its numeric kind, pinning the token numbering.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error parsing selector: failed to parse: '
        'unexpected token %d "%s" at position %d.\n' % (kind, text, position))


def test_ignore_is_gated_behind_unstable(run):
    """ignore() refuses to run without --unstable."""
    result = run(["-i", "json", "ignore()"], stdin="null")
    # CATCHES: the gate message has its own (ungrammatical) wording `unstable
    # function are not enabled`, distinct from the branch gate message.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: error evaluating expression "
        "ast.CallExpr: unstable function are not enabled. "
        "to enable them use --unstable\n")

    enabled = run(["-i", "json", "--unstable", "ignore()"], stdin="null")
    assert enabled.returncode == 0
    assert enabled.out == "null\n"
    assert enabled.err == ""


@pytest.mark.parametrize("query,expected", [
    ('base64e("hello")', '"aGVsbG8="\n'),
    ('base64d("aGVsbG8=")', '"hello"\n'),
])
def test_base64_round_trip(run, query, expected):
    """base64e/base64d encode and decode string values."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: both directions take exactly one string argument and return a
    # string, so the encoded form is printed JSON quoted.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,func_name,message", [
    ('base64d("!!!")', "base64d", "illegal base64 data at input byte 0"),
    ("base64e(123)", "base64e", "unexpected type: expected string, got int"),
])
def test_base64_failures(run, query, func_name, message):
    """Invalid base64 input and non-string arguments are errors."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the decoder surfaces the raw Go base64 error text, and a
    # non-string argument is rejected before any encoding happens.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: error execution func '
        '"%s": %s\n' % (func_name, message))


def test_read_file_reads_from_disk(run, write):
    """readFile(path) returns a file's contents as a string value."""
    write("notes.txt", "file-contents")
    result = run(["-i", "json", "readFile(\"notes.txt\")"], stdin="null")
    # CATCHES: the path is resolved relative to the process working directory
    # (pinned inside tmp_path) and the result is a JSON string.
    assert result.returncode == 0
    assert result.out == '"file-contents"\n'
    assert result.err == ""


def test_read_file_missing_is_an_execution_error(run):
    """readFile on a missing path reports the raw os.Open error."""
    result = run(["-i", "json", 'readFile("nope.txt")'], stdin="null")
    # CATCHES: the failure happens at execution time (exit 1, not a usage
    # error) and keeps Go's `open <path>: no such file or directory` wording.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.CallExpr: error executing function: error execution func '
        '"readFile": readFile: open nope.txt: no such file or directory\n')


@pytest.mark.parametrize("query,expected", [
    ("1.5 + 2.5", "4\n"),
    ("1 + 2.5", "3.5\n"),
    ("2.5 + 1", "3.5\n"),
    ("10.0 / 4.0", "2.5\n"),
    ("10.0 % 3.0", "1\n"),
    ("7.5 % 2.5", "0\n"),
    ("1.0 % 3", "1\n"),
])
def test_float_and_mixed_numeric_arithmetic(run, query, expected):
    """Every int/float operand pairing of +, / and % has its own result path."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: each operator keeps the operand order in its type dispatch, so
    # `1 + 2.5` and `2.5 + 1` both promote to float while pure-float sums stay
    # floats - and a whole float result renders without a decimal point ("4").
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


@pytest.mark.parametrize("query,operator", [
    ('"a" / 1', "divide"),
    ('1 / "a"', "divide"),
    ('"a" % 1', "modulo"),
])
def test_divide_and_modulo_report_incompatible_types(run, query, operator):
    """Divide and modulo name their own operator in the type error."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: unlike add/subtract/multiply, these two operators had no
    # incompatible-type test, and the message quotes the operand types in
    # left-to-right order ("string and int" vs "int and string").
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.BinaryExpr: could not %s: incompatible types: %s\n"
        % (operator, "string and int" if query.startswith('"') else "int and string"))


@pytest.mark.parametrize("query,unsupported", [
    ("1.5 / 0", "+Inf"),
    ("7.5 % 0.0", "NaN"),
    ("0.0 / 0.0", "NaN"),
])
def test_non_finite_results_are_rejected_by_the_json_writer(run, query, unsupported):
    """Float division and modulo can produce Inf/NaN, which JSON cannot hold."""
    result = run(["-i", "json", query], stdin="null")
    # CATCHES: the arithmetic itself succeeds (no runtime panic, unlike the
    # integer divide-by-zero case) and the failure only appears at write time,
    # naming the offending Go float value.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: error writing output: json: unsupported value: %s\n"
        % unsupported)
