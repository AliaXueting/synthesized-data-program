"""Command line plumbing: stdin reading, format flags, exit codes and the
separation of stdout from stderr. Ported from ``internal/cli/command_test.go``
and ``internal/cli/generic_test.go``."""

import pytest

MAIN_HELP = """Usage: dasel <command>

Query and modify data structures from the command line.

Flags:
  -h, --help    Show context-sensitive help.

Commands:
  query          [default] Execute a query
  version        Print the version
  interactive    Start an interactive session (alpha)
  completion     Generate shell completion script
  man            Generate man page

Run "dasel <command> --help" for more information on a command.
"""

QUERY_HELP = """Usage: dasel query [<query>] [flags]

[default] Execute a query

Arguments:
  [<query>]    The query to execute.

Flags:
  -h, --help                     Show context-sensitive help.

      --var=VARIABLES            Variables to pass to the query. E.g. --var
                                 foo="bar" --var baz=json:file:./some/file.json
      --rw-flag=EXT-READ-WRITE-FLAGS
                                 Read/Write flag to customise parsing/output.
                                 Applies to read + write E.g. --rw-flag
                                 csv-delimiter=;
      --read-flag=EXT-READ-WRITE-FLAGS
                                 Reader flag to customise parsing. E.g.
                                 --read-flag xml-mode=structured
      --write-flag=EXT-READ-WRITE-FLAGS
                                 Writer flag to customise output. E.g.
                                 --write-flag csv-delimiter=;
  -i, --in=STRING                The format of the input data.
  -o, --out=STRING               The format of the output data.
      --root                     Return the root value.
      --compact                  Output in compact mode (no
                                 indentation/newlines).
      --unstable                 Allow access to potentially unstable features.
      --it                       Run in interactive mode (alpha).
  -c, --config="~/dasel.yaml"    Path to config file
"""

USERS = ('{"users": [{"name": "Alice", "age": 20}, {"name": "Bob", "age": 30}, '
         '{"name": "Charlie", "age": 35}]}')


def test_stdin_is_read_when_no_file_args_exist(run):
    """With only a query argument the document comes from stdin."""
    result = run(["-i", "json", "user.name"], stdin='{"user": {"name": "John"}}')
    # CATCHES: stdin is the document source; the selected value is written to
    # stdout as JSON with a trailing newline and stderr stays empty.
    assert result.returncode == 0
    assert result.out == '"John"\n'
    assert result.err == ""


def test_default_command_is_query(run):
    """The explicit `query` subcommand behaves exactly like the default."""
    explicit = run(["query", "-i", "json", "user.name"], stdin='{"user": {"name": "John"}}')
    implicit = run(["-i", "json", "user.name"], stdin='{"user": {"name": "John"}}')
    # CATCHES: `query` is only reachable as a prefix subcommand; both forms
    # print the selected value itself, not the whole document, and exit 0
    # with an empty stderr.
    assert explicit.returncode == 0
    assert explicit.out == '"John"\n'
    assert explicit.err == ""
    assert implicit.returncode == explicit.returncode
    assert implicit.out == explicit.out
    assert implicit.err == explicit.err


def test_default_formats_come_from_the_config_default(run):
    """With neither -i nor -o both formats default to json."""
    result = run(["-i", "json", "$root"], stdin='{"a": 1, "b": [true, null]}')
    # CATCHES: the default output format is json with four-space indentation,
    # not plain or compact output.
    assert result.returncode == 0
    assert result.out == '{\n    "a": 1,\n    "b": [\n        true,\n        null\n    ]\n}\n'
    assert result.err == ""


def test_out_flag_alone_infers_the_input_format(run):
    """Passing only -o makes the reader use the same format."""
    result = run(["-o", "yaml"], stdin="a: 1\nb: two\n")
    # CATCHES: -o yaml silently switches the reader to yaml too, so yaml in
    # gives yaml out without ever naming -i.
    assert result.returncode == 0
    assert result.out == "a: 1\nb: two\n"
    assert result.err == ""


def test_out_plain_cannot_be_read_so_it_fails(run):
    """`plain` is a writer-only format, so -o plain fails to build a reader."""
    result = run(["-o", "plain"], stdin='{"a": 1}')
    # CATCHES: the reader is constructed before anything is parsed, and the
    # diagnostic names the reader (not the writer) and exits 1.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        "dasel: error: failed to get input reader: "
        "unsupported reader file format: plain\n")


def test_empty_stdin_without_a_query_prints_null(run):
    """No query and no input document yields the null value."""
    result = run(["-i", "json"], stdin="")
    # CATCHES: an empty document is not an error; the null value is rendered
    # by the writer rather than the process exiting non-zero.
    assert result.returncode == 0
    assert result.out == "null\n"
    assert result.err == ""


def test_literal_object_with_empty_stdin(run):
    """A query that builds a value needs no input document at all."""
    result = run(['{"name":"Tom"}'], stdin="")
    # CATCHES: the query runs against an implicit null root and the resulting
    # object is pretty printed to stdout with a trailing newline.
    assert result.returncode == 0
    assert result.out == '{\n    "name": "Tom"\n}\n'
    assert result.err == ""


def test_unknown_flag_prints_usage_to_stdout_and_error_to_stderr(run):
    """Flag parse failures go to kong: usage on stdout, error on stderr."""
    result = run(["--nope"], stdin='{"a": 1}')
    # CATCHES: the exit status is kong's 80 (not 1), the usage block lands on
    # stdout while only the one-line error lands on stderr.
    assert result.returncode == 80
    assert result.out == MAIN_HELP + "\n"
    assert result.err == "dasel: error: unknown flag --nope\n"


def test_short_flag_typo_suggests_alternatives(run):
    """An unknown short flag suggests the known short flags."""
    result = run(["-q"], stdin='{"a": 1}')
    # CATCHES: the suggestion list is ordered and quoted, which a naive
    # re-implementation would not reproduce.
    assert result.returncode == 80
    assert result.out == MAIN_HELP + "\n"
    assert result.err == (
        'dasel: error: unknown flag -q, did you mean one of "-h", "-i", "-o", "-c"?\n')


def test_help_flag_matches_long_help_flag(run):
    """-h and --help print the same top level usage block."""
    short = run(["-h"], config=False)
    long = run(["--help"], config=False)
    # CATCHES: both spellings print usage to stdout, exit 0 and write nothing
    # to stderr.
    assert short.returncode == long.returncode == 0
    assert short.out == long.out == MAIN_HELP
    assert short.err == long.err == ""


def test_query_help_lists_every_flag(run):
    """`query --help` documents the query flags."""
    result = run(["query", "--help"], config=False)
    # CATCHES: the flag help is wrapped at a fixed column, so the exact
    # wrapping of `--in`/`--out`/`--compact` descriptions is pinned.
    assert result.returncode == 0
    assert result.out == QUERY_HELP
    assert result.err == ""


def test_version_command(run):
    """The version subcommand prints the build version."""
    result = run(["version"], config=False, stdin="")
    # CATCHES: version goes to stdout as a single newline terminated word and
    # the command never reads stdin.
    assert result.returncode == 0
    assert result.out == "development\n"
    assert result.err == ""


def test_version_rejects_extra_arguments(run):
    """The version command takes no positional arguments."""
    result = run(["version", "extra"], config=False, stdin="")
    # CATCHES: extra arguments are a parse error with kong's usage block on
    # stdout and exit status 80.
    assert result.returncode == 80
    assert "Usage: dasel version\n" in result.out
    assert result.err == 'dasel: error: unexpected argument extra\n'


def test_unknown_word_is_treated_as_a_query(run):
    """A bare word is not an unknown command: it is the query itself."""
    result = run(["frobnicate"], stdin='{"a": 1}')
    # CATCHES: the default command swallows any argument as a query, so an
    # unknown "command" fails as a property lookup against the input map and
    # exits 1 instead of reporting an unknown command.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error executing selector: execution error when processing '
        'ast.PropertyExpr: map key not found: "frobnicate"\n')


@pytest.mark.parametrize("shell,marker", [
    ("bash", "_dasel()"),
    ("bash", "complete -F _dasel dasel"),
    ("zsh", "#compdef dasel"),
    ("zsh", "_arguments"),
    ("fish", "complete -c dasel"),
    ("fish", "__fish_use_subcommand"),
    ("powershell", "Register-ArgumentCompleter"),
    ("powershell", "-CommandName dasel"),
])
def test_completion_scripts(run, shell, marker):
    """`completion <shell>` emits the shell's completion script on stdout."""
    result = run(["completion", shell], config=False, stdin="")
    # CATCHES: the script is written to stdout (stderr empty) and contains the
    # shell specific plumbing a completer needs.
    assert result.returncode == 0
    assert result.err == ""
    assert marker in result.out
    assert "query" in result.out and "version" in result.out


def test_completion_rejects_unknown_shell(run):
    """An unsupported shell name is a usage error."""
    result = run(["completion", "nope"], config=False, stdin="")
    # CATCHES: the accepted shells are listed in the error in a fixed order.
    assert result.returncode == 80
    assert result.err == (
        'dasel: error: <shell> must be one of "bash","zsh","fish","powershell"'
        ' but got "nope"\n')


def test_man_page_is_roff(run):
    """`man` writes a roff manual page to stdout."""
    result = run(["man"], config=False, stdin="")
    # CATCHES: the page starts with a .TH directive and documents every
    # subcommand; only the date embedded in .TH is unstable so it is not
    # asserted byte for byte.
    assert result.returncode == 0
    assert result.err == ""
    assert result.out.startswith('.TH DASEL 1 "')
    assert result.out.splitlines()[0].endswith('"development" "DASEL Manual"')
    for needle in (".SH NAME", ".SH SYNOPSIS", ".SH DESCRIPTION",
                   "dasel \\- Query and modify data structures from the command line."):
        assert needle in result.out


def test_interactive_mode_requires_a_tty(run):
    """Interactive mode fails deterministically without a terminal."""
    result = run(["--it"], stdin="")
    # CATCHES: with no controlling terminal the run fails with a specific
    # message on stderr and exit status 1 rather than hanging.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == "dasel: error: could not open a new TTY: open /dev/tty: no such device or address\n"


def test_compact_flag_removes_all_whitespace(run):
    """--compact emits single line output."""
    result = run(["-i", "json", "-o", "json", "--compact", "$root"],
                 stdin='{"name": "Tom", "age": 30}')
    # CATCHES: compact mode drops every space and newline but still terminates
    # the document with exactly one newline.
    assert result.returncode == 0
    assert result.out == '{"name":"Tom","age":30}\n'
    assert result.err == ""


def test_compact_flag_on_nested_documents(run):
    """--compact flattens nested arrays and objects too."""
    result = run(["-i", "json", "-o", "json", "--compact", "$root"],
                 stdin='{"user": {"name": "Tom"}, "items": [1, 2, 3]}')
    # CATCHES: nesting depth does not reintroduce indentation in compact mode.
    assert result.returncode == 0
    assert result.out == '{"user":{"name":"Tom"},"items":[1,2,3]}\n'
    assert result.err == ""


def test_root_flag_returns_the_whole_document(run):
    """--root discards the query result and prints the (mutated) input."""
    result = run(["-i", "json", "-o", "json", "--root", "a = 2"], stdin='{"a": 1}')
    # CATCHES: assignments mutate the document in place, so --root shows the
    # new value even though the query expression itself evaluates to `2`.
    assert result.returncode == 0
    assert result.out == '{\n    "a": 2\n}\n'
    assert result.err == ""


def test_root_flag_without_assignment_is_a_noop(run):
    """--root with a pure query still prints the untouched document."""
    result = run(["-i", "json", "-o", "json", "--root", "a"], stdin='{"a": 1}')
    # CATCHES: reading a key does not mutate the document, so the full input
    # is echoed back unchanged.
    assert result.returncode == 0
    assert result.out == '{\n    "a": 1\n}\n'
    assert result.err == ""


@pytest.mark.parametrize("query,expected", [
    ("users.any(age > 25)", "true\n"),
    ("users.any(age > 50)", "false\n"),
    ("users.all(age > 18)", "true\n"),
    ("users.all(age > 25)", "false\n"),
    ("users.count(age > 25)", "2\n"),
    ("users.count(age > 50)", "0\n"),
])
def test_aggregates_write_bare_scalars(run, query, expected):
    """any/all/count results are printed as bare JSON scalars."""
    result = run(["-i", "json", query], stdin=USERS)
    # CATCHES: booleans and integers are written without quotes and without a
    # trailing document separator other than the single newline.
    assert result.returncode == 0
    assert result.out == expected
    assert result.err == ""


def test_selector_parse_error_goes_to_stderr_with_exit_one(run):
    """A selector that cannot be parsed is a runtime error, not a usage error."""
    result = run(["-i", "json", "? a : b"], stdin='{"a": 1}')
    # CATCHES: parse failures exit 1 (kong is not involved), and the message
    # includes the raw token and its byte position.
    assert result.returncode == 1
    assert result.out == ""
    assert result.err == (
        'dasel: error: error parsing selector: failed to parse: '
        'unexpected token 58 "?" at position 0.\n')


def test_unterminated_string_is_reported_by_the_tokenizer(run):
    """An unterminated string literal is caught while tokenizing."""
    result = run(["-i", "json", '"unterminated'], stdin='{"a": 1}')
    # CATCHES: the tokenizer reports the EOF position, which is after the
    # final character of the whole selector.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error parsing selector: failed to tokenize: "
        "unexpected EOF at position 13.\n")


def test_binary_expression_missing_operand(run):
    """A trailing binary operator fails at execution time, not parse time."""
    result = run(["-i", "json", "a +"], stdin='{"a": 1}')
    # CATCHES: `a +` parses fine and only fails when the binary expression is
    # evaluated, so the error names ast.BinaryExpr rather than the parser.
    assert result.returncode == 1
    assert result.err == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.BinaryExpr: left and right expressions must be provided\n")


def test_query_starting_with_a_dash_needs_a_separator(run):
    """A query beginning with `-` is taken as a flag unless `--` is used."""
    blocked = run(["-i", "json", "-5"], stdin="null")
    # CATCHES: without `--` the query is parsed as a flag and kong exits 80;
    # with `--` the same text is a unary minus expression that prints -5.
    assert blocked.returncode == 80
    assert blocked.err == (
        'dasel: error: unknown flag -5, did you mean one of "-h", "-i", "-o", "-c"?\n')

    ok = run(["-i", "json", "--", "-5"], stdin="null")
    assert ok.returncode == 0
    assert ok.out == "-5\n"
    assert ok.err == ""


def test_cr_lf_input_is_accepted(run):
    """CRLF line endings inside the input document are tolerated."""
    result = run(["-i", "json", "a"], stdin='{"a":\r\n 1}\r\n')
    # CATCHES: the reader strips carriage returns rather than failing on them.
    assert result.returncode == 0
    assert result.out == "1\n"
    assert result.err == ""
