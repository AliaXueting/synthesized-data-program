"""Parser behaviour for symbol-function calls (``parse_func``/``parseArgs``)."""

import pytest

from conftest import DEFAULT_INPUT, err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,stdin,expected",
    [
        pytest.param("len(s)", DEFAULT_INPUT, "3\n", id="call-with-property-arg"),
        pytest.param("len($this.s)", DEFAULT_INPUT, "3\n", id="call-with-variable-arg"),
        pytest.param('len("abcd")', DEFAULT_INPUT, "4\n", id="call-with-literal-arg"),
        pytest.param("{l: len(s)}", DEFAULT_INPUT, '{\n    "l": 3\n}\n', id="call-as-object-value"),
        pytest.param("[len(s)]", DEFAULT_INPUT, "[\n    3\n]\n", id="call-as-array-element"),
    ],
)
def test_function_call_parsing(selector, stdin, expected):
    """A symbol immediately followed by ``(`` parses as a call expression.

    CATCHES: the argument may be any expression and the call may appear
    wherever an expression is allowed, including inside object and array
    literals.
    """
    res = run_query(selector, stdin=stdin)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


def test_symbol_without_parens_is_a_property():
    """``len`` with no parenthesis is an ordinary property reference.

    CATCHES: only the adjacency of an OpenParen token turns a symbol into a
    call, so bare ``len`` is looked up as a map key.
    """
    res = run_query("len")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: execution error when processing "
        'ast.PropertyExpr: map key not found: "len"\n'
    )


def test_unknown_function_name():
    """An unrecognised function name fails at execution, not parse time.

    CATCHES: the grammar accepts any symbol as a function name; only the
    function registry rejects it, with a different error wrapper ("error
    evaluating expression ast.CallExpr") than parse failures use.
    """
    res = run_query("bogusfn(1)")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: error evaluating expression "
        'ast.CallExpr: unknown function: "bogusfn"\n'
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param(
            "len()",
            "dasel: error: error executing selector: execution error when processing "
            'ast.CallExpr: error executing function: func "len" expects exactly 1 '
            "arguments, got 0\n",
            id="zero-args",
        ),
        pytest.param(
            "len(s, a)",
            "dasel: error: error executing selector: execution error when processing "
            "ast.CallExpr: error preparing arguments: error evaluating argument 1: "
            'execution error when processing ast.PropertyExpr: map key not found: "a"\\n',
            id="two-args-second-missing",
        ),
    ],
)
def test_function_argument_count_errors(selector, expected):
    """Argument lists are comma separated and evaluated in order.

    CATCHES: the arity check happens after parsing, and arguments are
    evaluated left to right so the *second* argument's missing key is the one
    reported for ``len(s, a)``.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == expected


def test_chained_call_gets_no_implicit_this():
    """``s.len()`` passes no argument: the call is not a method on ``s``.

    CATCHES: a call after a dot is parsed as a fresh CallExpr with its own
    (empty) argument list - there is no implicit receiver, so ``len`` sees
    zero arguments.
    """
    res = run_query("s.len()")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.ChainedExpr: error executing expression: execution error when "
        'processing ast.CallExpr: error executing function: func "len" expects '
        "exactly 1 arguments, got 0\n"
    )


def test_call_arguments_use_call_binding_power():
    """Inside an argument list, ``+`` is not consumed as a binary operator.

    CATCHES: arguments are parsed at bpCall, which is above every binary
    operator, so ``len(\\"ab\\" + \\"cd\\")`` is a parse error reporting the Plus
    token at its own offset rather than a single concatenated argument.
    """
    res = run_query('len("ab" + "cd")')
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token 20 "+" at position 9.\n'
    )


def test_call_arguments_may_be_groups():
    """A parenthesised argument restores normal precedence inside a call.

    CATCHES: grouping inside the argument list drops the binding power back to
    the default, so the addition is parsed and evaluated before the call.
    """
    res = run_query('len(("ab" + "cd"))')
    assert res.returncode == 0
    assert out_text(res) == "4\n"
