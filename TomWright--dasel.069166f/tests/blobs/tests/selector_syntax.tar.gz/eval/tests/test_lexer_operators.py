"""Lexer behaviour for operators, punctuators and stray characters."""

import pytest

from conftest import err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,kind,value,position",
    [
        pytest.param("(,)", 2, ",", "1", id="comma"),
        pytest.param("(:)", 3, ":", "1", id="colon"),
        pytest.param("(])", 5, "]", "1", id="close-bracket"),
        pytest.param("(})", 7, "}", "1", id="close-curly"),
        pytest.param("())", 9, ")", "2", id="close-paren"),
        pytest.param("(==)", 10, "==", "1", id="equal"),
        pytest.param("(=)", 11, "=", "1", id="equals"),
        pytest.param("(!=)", 12, "!=", "1", id="not-equal"),
        pytest.param("(&&)", 13, "&&", "1", id="and"),
        pytest.param("(||)", 14, "||", "1", id="or"),
        pytest.param("(=~)", 15, "=~", "1", id="like"),
        pytest.param("(!~)", 16, "!~", "1", id="not-like"),
        pytest.param("(+)", 20, "+", "1", id="plus"),
        pytest.param("(-)", 23, "-", "1", id="dash"),
        pytest.param("(*)", 26, "*", "1", id="star"),
        pytest.param("(/)", 27, "/", "1", id="slash"),
        pytest.param("(%)", 28, "%", "1", id="percent"),
        pytest.param("(.)", 29, ".", "1", id="dot"),
        pytest.param("($)", 32, "$", "1", id="dollar"),
        pytest.param("(>)", 34, ">", "1", id="greater-than"),
        pytest.param("(>=)", 35, ">=", "1", id="greater-or-equal"),
        pytest.param("(<)", 36, "<", "1", id="less-than"),
        pytest.param("(<=)", 37, "<=", "1", id="less-or-equal"),
        pytest.param("(?)", 58, "?", "1", id="question-mark"),
        pytest.param("(??)", 59, "??", "1", id="double-question"),
        pytest.param("(;)", 60, ";", "1", id="semicolon"),
    ],
)
def test_operator_in_expression_position(selector, kind, value, position):
    """An operator where an expression is required names its token kind.

    CATCHES: UnexpectedTokenError renders the token's *numeric* kind from the
    lexer's iota table plus its raw text and byte offset, e.g. ``?`` is kind
    58 while ``??`` is kind 59, so a re-implementation must number its token
    kinds identically to be behaviourally identical.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token %d "%s" at position %s.\n' % (kind, value, position)
    )


@pytest.mark.parametrize(
    "selector,kind,position",
    [
        pytest.param("a++", 21, "1", id="increment"),
        pytest.param("a--", 24, "1", id="decrement"),
        pytest.param("a += 1", 22, "2", id="increment-by"),
        pytest.param("a -= 1", 25, "2", id="decrement-by"),
    ],
)
def test_increment_decrement_tokens_are_lexed_but_unparsable(selector, kind, position):
    """``++`` ``--`` ``+=`` ``-=`` tokenize yet no parser rule accepts them.

    CATCHES: these four are distinct tokens (21/24/22/25) that survive
    tokenization but are rejected by the expression parser with their own
    positions, rather than being read as two operators.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert "unexpected token %d " % kind in err_text(res)
    assert err_text(res).endswith(" at position %s.\n" % position)


@pytest.mark.parametrize(
    "selector,char,position",
    [
        pytest.param("~", "~", "0", id="tilde"),
        pytest.param("^", "^", "0", id="caret"),
        pytest.param("#", "#", "0", id="hash"),
        pytest.param("@", "@", "0", id="at-sign"),
        pytest.param("`", "`", "0", id="backtick"),
        pytest.param("\\", "\\", "0", id="backslash"),
        pytest.param("&", "&", "0", id="single-ampersand"),
        pytest.param("|", "|", "0", id="single-pipe"),
        pytest.param("1 & 2", "&", "2", id="ampersand-after-expression"),
        pytest.param("1 | 2", "|", "2", id="pipe-after-expression"),
        pytest.param("a@", "@", "1", id="at-after-symbol"),
        pytest.param("1 + @ 2", "@", "4", id="at-inside-expression"),
        pytest.param("a\\b", "\\", "1", id="backslash-inside-selector"),
    ],
)
def test_stray_characters_are_tokenizer_errors(selector, char, position):
    """Characters outside the grammar fail in the tokenizer, not the parser.

    CATCHES: the message prefix is "failed to tokenize: unexpected token: X at
    position N." - a different sentence shape from the parser's "failed to
    parse: unexpected token <kind> ..." - and ``&``/``|`` only exist as the
    doubled ``&&``/``||`` forms.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: "
        "failed to tokenize: unexpected token: %s at position %s.\n" % (char, position)
    )


def test_double_slash_is_a_comment_not_division():
    """``1//2`` starts a line comment at the second slash, so 2 is ignored.

    CATCHES: comment detection wins over the division operator, so the result
    is 1 rather than the 0 that integer division of 1 by 2 would give.
    """
    res = run_query("1//2")
    assert res.returncode == 0
    assert out_text(res) == "1\n"


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("6/2", "3\n", id="slash-divides"),
        pytest.param("7/2", "3\n", id="slash-integer-divides"),
        pytest.param("7%3", "1\n", id="percent-modulo"),
        pytest.param("2*3", "6\n", id="star-multiplies"),
        pytest.param("1+2", "3\n", id="plus-adds"),
        pytest.param("3-1", "2\n", id="dash-subtracts"),
    ],
)
def test_arithmetic_operators_evaluate(selector, expected):
    """The arithmetic punctuators lex as single tokens and evaluate.

    CATCHES: ``/`` on two ints does integer division (7/2 == 3) which
    distinguishes the Slash token from a comment start when digits surround it.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("1==1", "true\n", id="equal"),
        pytest.param("1!=2", "true\n", id="not-equal"),
        pytest.param("1<2", "true\n", id="less-than"),
        pytest.param("1<=1", "true\n", id="less-or-equal"),
        pytest.param("2>1", "true\n", id="greater-than"),
        pytest.param("2>=2", "true\n", id="greater-or-equal"),
        pytest.param("true&&false", "false\n", id="and"),
        pytest.param("true||false", "true\n", id="or"),
        pytest.param("!true", "false\n", id="not"),
        pytest.param("null ?? 9", "9\n", id="double-question"),
        pytest.param("true ? 1 : 2", "1\n", id="ternary"),
        pytest.param("a = 5", "5\n", id="single-equals-assigns"),
    ],
)
def test_comparison_and_logical_operators_evaluate(selector, expected):
    """Comparison, logical, ternary and assignment operators all parse.

    CATCHES: ``=`` (single) is the assignment operator and is accepted as a
    binary operator, unlike ``+=``/``-=``, and ``??`` falls through to the
    right side when the left is null.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_regex_match_operators():
    """``=~`` and ``!~`` are two-character tokens applying a regex literal.

    CATCHES: they must not be lexed as ``=`` plus ``~`` (which would be a
    tokenizer error on ``~``); both directions of the match are computed.
    """
    res = run_query('"str" =~ r/tr/')
    assert res.returncode == 0
    assert out_text(res) == "true\n"

    res = run_query('"str" !~ r/tr/')
    assert res.returncode == 0
    assert out_text(res) == "false\n"


def test_bracket_punctuators_group_and_index():
    """Square brackets after a symbol are an index, not an array literal.

    CATCHES: the same ``[`` character is an array literal at the start of an
    expression but an index when it follows a property, so ``c[1]`` yields 20
    while ``[1]`` would build a one element array.
    """
    res = run_query("c[1]")
    assert res.returncode == 0
    assert out_text(res) == "20\n"

    res = run_query("[1]")
    assert res.returncode == 0
    assert out_text(res) == "[\n    1\n]\n"
