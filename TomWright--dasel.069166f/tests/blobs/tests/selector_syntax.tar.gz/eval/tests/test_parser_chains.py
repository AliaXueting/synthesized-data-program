"""Parser behaviour for dot chains, index/property access and ``;``."""

import pytest

from conftest import err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("a", "1\n", id="single-property"),
        pytest.param("d.e", '"f"\n', id="dot-chain"),
        pytest.param("a.", "1\n", id="trailing-dot-tolerated"),
        pytest.param("$this.a", "1\n", id="variable-then-property"),
        pytest.param("$this.d.e", '"f"\n', id="variable-deep-chain"),
    ],
)
def test_dot_chains(selector, expected):
    """Dot separated expressions parse as a chain and evaluate left to right.

    CATCHES: a trailing dot is accepted (the chain simply ends), and ``$this``
    can start a chain just like a bare symbol.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector",
    [
        pytest.param(".a", id="leading-dot-before-property"),
        pytest.param(".", id="lone-dot"),
        pytest.param(".5", id="leading-dot-before-digit"),
    ],
)
def test_leading_dot_is_rejected(selector):
    """A selector may not start with a dot.

    CATCHES: the Dot token has no prefix (null-denotation) rule, so ``.a`` and
    even a bare ``.`` are rejected at position 0 - unlike dasel v1 where a
    leading dot was idiomatic.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: "
        'failed to parse: unexpected token 29 "." at position 0.\n'
    )


def test_space_separated_expressions_chain_not_dot():
    """Two expressions separated only by spaces form an implicit chain.

    CATCHES: whitespace is not an expression terminator - ``a b`` chains the
    property ``a`` (an int) with the property ``b`` and fails at execution
    time, proving both tokens were consumed by one expression list.
    """
    res = run_query("a b")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.ChainedExpr: error executing expression: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int\n"
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("c[0]", "10\n", id="index-int"),
        pytest.param("c[1]", "20\n", id="index-second"),
        pytest.param("c[1+1]", "30\n", id="index-is-expression"),
        pytest.param('$this["s"]', '"str"\n', id="index-double-quoted-string"),
        pytest.param("$this['s']", '"str"\n', id="index-single-quoted-string"),
        pytest.param('d["e"]', '"f"\n', id="index-into-map"),
        pytest.param('$this["c"][1]', "20\n", id="two-indexes"),
        pytest.param('$this["d"].e', '"f"\n', id="index-then-dot-property"),
    ],
)
def test_index_and_property_access(selector, expected):
    """Square brackets after an expression index into it.

    CATCHES: the bracket contents are a full expression (``1+1`` works) and a
    string index becomes property access, so quoted keys work on maps.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("c[0:1]", "[\n    10,\n    20\n]\n", id="range-both-ends"),
        pytest.param("c[1:]", "[\n    20,\n    30\n]\n", id="range-open-end"),
        pytest.param("c[:1]", "[\n    10,\n    20\n]\n", id="range-open-start"),
        pytest.param("s[0:1]", '"st"\n', id="range-on-string"),
    ],
)
def test_range_access(selector, expected):
    """``[start:end]`` slices, with either end omitted.

    CATCHES: the range is inclusive of the end index (``c[0:1]`` on
    [10,20,30] yields both 10 and 20), which differs from most languages.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_empty_range_is_a_parse_error():
    """``c[:]`` with no start and no end is rejected.

    CATCHES: after consuming the colon the parser demands an expression, and
    the closing bracket is reported as kind 5 at the bracket's offset.
    """
    res = run_query("c[:]")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token 5 "]" at position 3.\n'
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("c[*]", "10\n\n20\n\n30\n", id="star-in-brackets"),
        pytest.param("c[...]", "10\n\n20\n\n30\n", id="spread-in-brackets"),
        pytest.param("c...", "10\n\n20\n\n30\n", id="spread-suffix"),
        pytest.param("$this.c[...]", "10\n\n20\n\n30\n", id="spread-after-variable"),
    ],
)
def test_spread_and_wildcard_access(selector, expected):
    """``[*]``, ``[...]`` and a trailing ``...`` all spread a slice.

    CATCHES: all three spellings are equivalent and emit one document per
    element separated by a blank line, not a JSON array.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("1; 2", "2\n", id="last-expression-wins"),
        pytest.param("1; 2; 3", "3\n", id="three-expressions"),
        pytest.param("a; 5", "5\n", id="property-then-literal"),
        pytest.param("1 + 1; 2 + 2; 3 + 3", "6\n", id="only-final-value-emitted"),
        pytest.param("a;", "1\n", id="trailing-semicolon"),
    ],
)
def test_semicolon_separator(selector, expected):
    """``;`` splits the selector into expressions; only the last is output.

    CATCHES: the earlier expressions are parsed and evaluated (so a bad one
    still fails) but only the final value is written to stdout.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,position",
    [
        pytest.param(";a", "0", id="leading-semicolon"),
        pytest.param(";;", "0", id="double-semicolon"),
        pytest.param("1;;", "2", id="semicolon-then-semicolon"),
        pytest.param("(1; 2)", "2", id="semicolon-inside-group"),
    ],
)
def test_misplaced_semicolons_are_parse_errors(selector, position):
    """A ``;`` with no expression before it is an unexpected token.

    CATCHES: the separator requires a preceding expression, and it is not
    allowed inside parentheses at all - both report token kind 60.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token 60 ";" at position %s.\n' % position
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("(a)", "1\n", id="single-group"),
        pytest.param("((a))", "1\n", id="nested-groups"),
        pytest.param("(1 + 2) * 3", "9\n", id="group-overrides-precedence"),
        pytest.param("(a", "1\n", id="unbalanced-open-paren"),
        pytest.param("[1", "[\n    1\n]\n", id="unbalanced-open-bracket"),
    ],
)
def test_groups_and_unbalanced_open_delimiters(selector, expected):
    """Parentheses group; a missing closing delimiter is not an error.

    CATCHES: the parser stops at end-of-input instead of demanding the closer,
    so ``(a`` and ``[1`` parse successfully - only surplus closers are errors.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,kind,closer",
    [
        pytest.param("foo]", 5, "]", id="stray-close-bracket"),
        pytest.param("foo)", 9, ")", id="stray-close-paren"),
        pytest.param("foo}", 7, "}", id="stray-close-curly"),
    ],
)
def test_unbalanced_close_delimiters(selector, kind, closer):
    """A closing delimiter with no opener is reported at its own offset.

    CATCHES: each closer is its own token kind (5/9/7) reported at position 3,
    after the ``foo`` property has been parsed.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token %d "%s" at position 3.\n' % (kind, closer)
    )
