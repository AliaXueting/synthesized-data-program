"""Parser behaviour driven by the binding-power (precedence) tables."""

import pytest

from conftest import err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("1+2*3", "7\n", id="multiplication-binds-tighter"),
        pytest.param("2*3+1", "7\n", id="multiplication-first-operand"),
        pytest.param("(1+2)*3", "9\n", id="parentheses-override"),
        pytest.param("2+3*4-1", "13\n", id="mixed-additive-multiplicative"),
        pytest.param("1+2==3", "true\n", id="additive-binds-tighter-than-equality"),
        pytest.param("1<2==true", "true\n", id="relational-same-level-as-equality"),
    ],
)
def test_arithmetic_precedence(selector, expected):
    """Multiplicative operators bind tighter than additive and relational.

    CATCHES: ``1+2*3`` is 7 and ``(1+2)*3`` is 9, while ``==`` shares the
    relational tier with ``<`` so ``1<2==true`` groups left as ``(1<2)==true``.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("1-2-3", "-4\n", id="subtraction-left-associative"),
        pytest.param("100/10/2", "5\n", id="division-left-associative"),
        pytest.param("2*3%4", "2\n", id="multiplicative-left-associative"),
        pytest.param("10%3*2", "2\n", id="modulo-then-multiply"),
        pytest.param("2-3+1", "0\n", id="mixed-additive-left-associative"),
    ],
)
def test_left_associativity(selector, expected):
    """Same-precedence binary operators associate to the left.

    CATCHES: ``1-2-3`` is -4 (not 2) and ``100/10/2`` is 5 (not 20), which
    distinguishes a Pratt left-denotation loop from a right-recursive grammar.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("true||false&&false", "false\n", id="or-then-and"),
        pytest.param("false&&true||true", "true\n", id="and-then-or"),
    ],
)
def test_logical_operators_share_one_tier(selector, expected):
    """``&&`` and ``||`` have the same binding power and associate left.

    CATCHES: ``true||false&&false`` is false - if ``&&`` bound tighter than
    ``||`` the answer would be true, so this pins that both are bpLogical.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("0 ?? 1 + 2", "0\n", id="coalesce-binds-loosest"),
        pytest.param("null ?? 1 + 2", "3\n", id="coalesce-falls-through"),
        pytest.param("1 ?? 2 == 2", "1\n", id="coalesce-vs-equality"),
        pytest.param("null ?? false && true", "false\n", id="coalesce-vs-logical"),
    ],
)
def test_null_coalescing_binds_looser_than_arithmetic(selector, expected):
    """``??`` sits below the logical tier in the binding-power table.

    CATCHES: ``0 ?? 1 + 2`` is 0 because ``1 + 2`` is computed first; if ``??``
    bound tighter than ``+`` the result would be 2.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_assignment_binds_loosest():
    """``=`` is the weakest operator, so the whole left side is the target.

    CATCHES: ``1 + a = 2`` parses as ``(1 + a) = 2`` and yields 2, not as
    ``1 + (a = 2)`` which would also be 2 - but the recorded error-free exit
    plus result shows assignment consumed the entire preceding expression.
    """
    res = run_query("1 + a = 2")
    assert res.returncode == 0
    assert out_text(res) == "2\n"


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("!true", "false\n", id="not"),
        pytest.param("!!true", "true\n", id="double-not"),
        pytest.param("!(1==1)", "false\n", id="not-of-group"),
        pytest.param("!(true && false)", "true\n", id="not-of-logical"),
        pytest.param("((((1))))", "1\n", id="deeply-nested-groups"),
    ],
)
def test_unary_not_and_grouping(selector, expected):
    """``!`` is a right-denotation (prefix) operator and nests freely.

    CATCHES: ``!!true`` works because the unary parser recurses, and the
    operand may be any parenthesised expression.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_unary_not_requires_a_bool():
    """``!`` on a non-boolean fails at execution time, not parse time.

    CATCHES: the grammar accepts ``!1`` and only the evaluator rejects it,
    with the unary expression's own error message.
    """
    res = run_query("!1")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.UnaryExpr: error converting value to boolean: unexpected type: "
        "expected bool, got int\n"
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("true ? 1 : 2", "1\n", id="simple-ternary"),
        pytest.param("false ? 1 : true ? 2 : 3", "2\n", id="nested-in-else"),
        pytest.param("true ? false ? 1 : 2 : 3", "2\n", id="nested-in-then"),
        pytest.param("(true ? 1 : 2) + 10", "11\n", id="ternary-inside-group"),
        pytest.param("true ? 1 + 2 : 3", "3\n", id="expression-branches"),
        pytest.param("a == 1 ? \"yes\" : \"no\"", '"yes"\n', id="condition-from-input"),
    ],
)
def test_ternary_conditional(selector, expected):
    """``a ? b : c`` parses with the branches as full expressions.

    CATCHES: a ternary may nest in either branch without parentheses, and the
    whole ternary can be grouped and used as an operand.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_ternary_missing_else_branch():
    """``a ? 1`` without a colon reports the end-of-input token.

    CATCHES: the missing ``:`` makes the parser hit the synthetic EOF token,
    whose kind is 0, value is empty and position is always 0.
    """
    res = run_query("a ? 1")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token 0 "" at position 0.\n'
    )


def test_relational_chain_fails_at_execution():
    """``1 < 2 < 3`` parses but the evaluator rejects bool-vs-int.

    CATCHES: relational operators all share one tier and associate left, so
    the comparison chain builds ``(1 < 2) < 3`` which is a runtime type error
    rather than a parse error.
    """
    res = run_query("1 < 2 < 3")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.BinaryExpr: incompatible types: bool and int\n"
    )
