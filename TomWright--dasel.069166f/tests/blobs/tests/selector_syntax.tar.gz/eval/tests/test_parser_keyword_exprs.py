"""Parser behaviour for the keyword expressions (map, filter, if, branch...)."""

import pytest

from conftest import DEFAULT_INPUT_PRETTY, err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,stdin,expected",
    [
        pytest.param("map(x)", b'[{"x":1},{"x":2},{"x":3}]', "[\n    1,\n    2,\n    3\n]\n", id="map-property"),
        pytest.param("map($this)", b"[1,2]", "[\n    1,\n    2\n]\n", id="map-this"),
        pytest.param("map((x))", b'[{"x":5}]', "[\n    5\n]\n", id="map-grouped-expr"),
        pytest.param("map(x)[1]", b'[{"x":1},{"x":2},{"x":3}]', "2\n", id="map-then-index"),
        pytest.param("each($this)", b"[1,2]", "[\n    1,\n    2\n]\n", id="each"),
        pytest.param("each(x)", b'[{"x":1},{"x":2}]', "[\n    {\n        \"x\": 1\n    },\n    {\n        \"x\": 2\n    }\n]\n", id="each-keeps-elements"),
    ],
)
def test_map_and_each(selector, stdin, expected):
    """``map(expr)`` transforms and ``each(expr)`` visits a slice.

    CATCHES: ``map`` may be followed directly by an index because index parsing
    continues after the keyword expression, while ``each`` may not.
    """
    res = run_query(selector, stdin=stdin)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,stdin,expected",
    [
        pytest.param("filter(x > 1)", b'[{"x":1},{"x":2},{"x":3}]', "[\n    {\n        \"x\": 2\n    },\n    {\n        \"x\": 3\n    }\n]\n", id="filter-comparison"),
        pytest.param('filter($this =~ r/a/)', b'["cat","dog","ark"]', "[\n    \"cat\",\n    \"ark\"\n]\n", id="filter-regex"),
        pytest.param("search(x == 1)", b'{"a":{"x":1},"b":{"x":2},"c":{"x":1}}', "[\n    {\n        \"x\": 1\n    },\n    {\n        \"x\": 1\n    }\n]\n", id="search-recursive"),
        pytest.param("search(a == 1)", b'{"a":1,"b":{"a":1}}', "[\n    {\n        \"a\": 1\n    }\n]\n", id="search-top-level-match"),
    ],
)
def test_filter_and_search(selector, stdin, expected):
    """``filter(expr)`` selects slice elements, ``search(expr)`` recurses.

    CATCHES: the argument is a full expression including regex ``=~`` matches,
    and ``search`` walks into nested values, returning every matching node.
    """
    res = run_query(selector, stdin=stdin)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("sortBy(x)", "[\n    {\n        \"x\": 1\n    },\n    {\n        \"x\": 2\n    },\n    {\n        \"x\": 3\n    }\n]\n", id="sortby-ascending"),
        pytest.param("sortBy(x, asc)", "[\n    {\n        \"x\": 1\n    },\n    {\n        \"x\": 2\n    },\n    {\n        \"x\": 3\n    }\n]\n", id="sortby-explicit-asc"),
        pytest.param("sortBy(x, desc)", "[\n    {\n        \"x\": 3\n    },\n    {\n        \"x\": 2\n    },\n    {\n        \"x\": 1\n    }\n]\n", id="sortby-descending"),
    ],
)
def test_sort_by(selector, expected):
    """``sortBy(expr[, asc|desc])`` orders a slice.

    CATCHES: the direction keyword is a real token (``asc``/``desc``) and only
    those two spellings are accepted after the comma.
    """
    res = run_query(selector, stdin=b'[{"x":3},{"x":1},{"x":2}]')
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param(
            "sortBy(a, b)",
            'dasel: error: error parsing selector: failed to parse: '
            'unexpected token 1 "b" at position 10.\n',
            id="third-argument-not-a-direction",
        ),
        pytest.param(
            "sortBy(x, bogus)",
            'dasel: error: error parsing selector: failed to parse: '
            'unexpected token 1 "bogus" at position 10.\n',
            id="unknown-direction-word",
        ),
        pytest.param(
            "sortBy()",
            "dasel: error: error executing selector: execution error when processing "
            "ast.SortByExpr: cannot sort by on non-slice data\n",
            id="empty-argument-list",
        ),
    ],
)
def test_sort_by_argument_errors(selector, expected):
    """Bad ``sortBy`` arguments are reported with the offending symbol.

    CATCHES: a third argument that is not ``asc``/``desc`` is an unexpected
    Symbol token at the offset of the word itself, and an empty argument list
    parses but fails at execution on a non-slice input.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == expected


@pytest.mark.parametrize(
    "selector,stdin,expected",
    [
        pytest.param("groupBy(x)", b'[{"x":1},{"x":2},{"x":1}]', '{\n    "1": [\n        {\n            "x": 1\n        },\n        {\n            "x": 1\n        }\n    ],\n    "2": [\n        {\n            "x": 2\n        }\n    ]\n}\n', id="group-by-value"),
        pytest.param("groupBy(x).1", b'[{"x":1},{"x":2}]', "1\n", id="group-by-then-property"),
        pytest.param("mapValues($this + 1)", b'{"a":1,"b":2}', '{\n    "a": 2,\n    "b": 3\n}\n', id="map-values"),
        pytest.param("mapValues($key)", b'{"a":1,"b":2}', '{\n    "a": "a",\n    "b": "b"\n}\n', id="map-values-key-var"),
    ],
)
def test_group_by_and_map_values(selector, stdin, expected):
    """``groupBy`` buckets a slice; ``mapValues`` transforms map values.

    CATCHES: group keys become string map keys and ``groupBy(x).1`` works
    because property access continues after the keyword expression, while
    inside ``mapValues`` the special ``$key`` variable is bound.
    """
    res = run_query(selector, stdin=stdin)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,stdin,expected",
    [
        pytest.param("any(x > 1)", b'[{"x":1},{"x":2}]', "true\n", id="any-true"),
        pytest.param("any(x > 5)", b'[{"x":1},{"x":2}]', "false\n", id="any-false"),
        pytest.param("all(x > 0)", b'[{"x":1},{"x":2}]', "true\n", id="all-true"),
        pytest.param("all(x > 1)", b'[{"x":1},{"x":2}]', "false\n", id="all-false"),
        pytest.param("count(x > 1)", b'[{"x":1},{"x":2},{"x":3}]', "2\n", id="count-matching"),
        pytest.param("count(x >= 1)", b'[{"x":1},{"x":2}]', "2\n", id="count-all"),
        pytest.param("any(x > 0) ? \"y\" : \"n\"", b'[{"x":1}]', '"y"\n', id="any-as-ternary-condition"),
    ],
)
def test_any_all_count(selector, stdin, expected):
    """``any``/``all``/``count`` take a boolean expression over a slice.

    CATCHES: their result is a plain bool/number that can feed a ternary, and
    ``count`` counts only the elements for which the expression is true.
    """
    res = run_query(selector, stdin=stdin)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_reduce_takes_three_expressions():
    """``reduce(expr, init, update)`` parses three comma separated arguments.

    CATCHES: the argument list is exactly three expressions, so the parser
    accepts two commas; here the update expression ignores the accumulator.
    """
    res = run_query("reduce($this, 0, $this)", stdin=b"[1,2,3]")
    assert res.returncode == 0
    assert out_text(res) == "3\n"


@pytest.mark.parametrize(
    "selector",
    [
        pytest.param("reduce(", id="reduce-open-paren"),
        pytest.param("reduce(a", id="reduce-one-arg"),
        pytest.param("reduce(a,", id="reduce-one-arg-comma"),
        pytest.param("reduce(a, b", id="reduce-two-args"),
        pytest.param("reduce(a, b,", id="reduce-two-args-comma"),
    ],
)
def test_reduce_with_too_few_arguments_is_a_parse_error(selector):
    """``reduce`` demands all three arguments before parsing succeeds.

    CATCHES: unlike ``map(``, which tolerates a missing closing paren, reduce
    requires its commas and reports the synthetic EOF token (kind 0, empty
    value, position 0).
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token 0 "" at position 0.\n'
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param('if (a == 1) { "one" } else { "other" }', '"one"\n', id="if-else"),
        pytest.param('if (a == 2) { "two" }', "null\n", id="if-without-else"),
        pytest.param('if (a == 2) { "two" } elseif (a == 1) { "one" } else { "other" }', '"one"\n', id="if-elseif-else"),
        pytest.param("if (a == 3) { 3 } elseif (a == 2) { 2 } elseif (a == 1) { 1 } else { 0 }", "1\n", id="elseif-chain"),
        pytest.param('if (a == 1) { if (b == 2) { "ab" } }', '"ab"\n', id="nested-if"),
        pytest.param("if (true) {}", None, id="empty-body"),
    ],
)
def test_if_else_elseif(selector, expected):
    """``if``/``elseif``/``else`` blocks parse with parenthesised conditions.

    CATCHES: an ``if`` with a false condition and no ``else`` yields null, an
    ``elseif`` chain is right-nested, and an empty body ``{}`` leaves the
    input value untouched.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    if expected is not None:
        assert out_text(res) == expected
    else:
        assert out_text(res) == DEFAULT_INPUT_PRETTY


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param(
            "if true { 1 }",
            'dasel: error: error parsing selector: failed to parse: '
            'unexpected token 19 "true" at position 3.\n',
            id="condition-without-parens",
        ),
        pytest.param(
            "if (true) { 1 } else",
            'dasel: error: error parsing selector: failed to parse: '
            'unexpected token 0 "" at position 0.\n',
            id="else-without-body",
        ),
        pytest.param(
            "if",
            'dasel: error: error parsing selector: failed to parse: '
            'unexpected token 0 "" at position 0.\n',
            id="bare-if",
        ),
    ],
)
def test_if_syntax_errors(selector, expected):
    """``if`` requires parentheses and a braced body.

    CATCHES: the condition must be parenthesised - ``if true {`` reports the
    Bool token kind 19 - while a missing body after ``else`` hits the
    synthetic end-of-input token.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == expected


def test_if_else_body_may_be_left_unclosed():
    """An ``else {`` block with no closing brace still parses.

    CATCHES: the body parser stops at end-of-input rather than demanding ``}``,
    so the then-branch value is returned with exit code 0.
    """
    res = run_query("if (true) { 1 } else {")
    assert res.returncode == 0
    assert out_text(res) == "1\n"


@pytest.mark.parametrize(
    "selector",
    [
        pytest.param("map", id="map"),
        pytest.param("each", id="each"),
        pytest.param("filter", id="filter"),
        pytest.param("search", id="search"),
        pytest.param("sortBy", id="sortBy"),
        pytest.param("groupBy", id="groupBy"),
        pytest.param("reduce", id="reduce"),
        pytest.param("mapValues", id="mapValues"),
        pytest.param("any", id="any"),
        pytest.param("all", id="all"),
        pytest.param("count", id="count"),
        pytest.param("branch", id="branch"),
        pytest.param("if", id="if"),
    ],
)
def test_keyword_without_argument_list(selector):
    """A keyword expression without its parentheses is an unexpected EOF.

    CATCHES: every one of these keywords demands a following ``(``; running
    out of tokens yields the synthetic EOF token whose kind is 0 and whose
    position is always 0 - except ``map(`` which parses and fails later.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token 0 "" at position 0.\n'
    )


def test_map_without_closing_paren_parses():
    """``map(`` parses: the argument list simply ends at end-of-input.

    CATCHES: unlike ``reduce``, the map parser does not demand a closing paren,
    so ``map(`` is a valid selector whose behaviour depends only on the input
    type - an error on a map, a pass-through on a slice.
    """
    res = run_query("map(")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.MapExpr: cannot map over non-array\n"
    )

    res = run_query("map(", stdin=b'[{"x":1}]')
    assert res.returncode == 0
    assert out_text(res) == '[\n    {\n        "x": 1\n    }\n]\n'


def test_branch_requires_unstable_flag():
    """``branch(a, b)`` parses but is gated behind ``--unstable``.

    CATCHES: without the flag the AST node is rejected before execution with
    the "unstable ast types" message; with it, each branch output is emitted
    as its own document.
    """
    res = run_query("branch(a, b)", stdin=b'{"a":1,"b":2}')
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: error evaluating expression "
        "ast.BranchExpr: unstable ast types are not enabled. "
        "to enable them use --unstable\n"
    )

    res = run_query("branch(a, b)", stdin=b'{"a":1,"b":2}', extra=("--unstable",))
    assert res.returncode == 0
    assert out_text(res) == "1\n\n2\n"


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("map(x; 1)", 'dasel: error: error parsing selector: failed to parse: unexpected token 60 ";" at position 5.\n', id="map"),
        pytest.param("each(x; x)", 'dasel: error: error parsing selector: failed to parse: unexpected token 60 ";" at position 6.\n', id="each"),
    ],
)
def test_semicolon_not_allowed_inside_keyword_parens(selector, expected):
    """The ``;`` expression separator is not valid inside ``map(...)``.

    CATCHES: these argument lists have no split-on-semicolon rule, so the
    semicolon token is reported by kind (60) at its own offset.
    """
    res = run_query(selector, stdin=b'[{"x":1}]')
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == expected
