"""Lexer and literal-parser behaviour for numbers (ints, floats, negatives)."""

import pytest

from conftest import err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("42", "42\n", id="plain-int"),
        pytest.param("0", "0\n", id="zero"),
        pytest.param("007", "7\n", id="leading-zeros-stripped"),
        pytest.param("9223372036854775807", "9223372036854775807\n", id="int64-max"),
    ],
)
def test_integer_literals(selector, expected):
    """Integer literals round-trip as JSON integers.

    CATCHES: leading zeros are not octal and not preserved; the value is
    re-serialised from the parsed integer, and int64 max is still in range.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("3.25", "3.25\n", id="float"),
        pytest.param("1.50", "1.5\n", id="trailing-zero-dropped"),
        pytest.param("0.1+0.2", "0.30000000000000004\n", id="float-arithmetic-precision"),
    ],
)
def test_float_literals(selector, expected):
    """Float literals become float64 values and are printed without padding.

    CATCHES: ``1.50`` prints as ``1.5`` and float arithmetic shows binary
    double precision artefacts, proving a real float64 is used.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("7f", "7\n", id="int-with-f-suffix"),
        pytest.param("2.5f", "2.5\n", id="float-with-f-suffix"),
        pytest.param("7F", "7\n", id="uppercase-f-suffix"),
        pytest.param("1 f", "1\n", id="f-suffix-across-whitespace"),
    ],
)
def test_float_f_suffix(selector, expected):
    """A following ``f`` symbol turns the number into a float literal.

    CATCHES: the suffix is matched on the *next token* being the symbol ``f``,
    with no adjacency requirement, so even ``1 f`` (separated by a space) is
    consumed as one float literal rather than two chained expressions.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("-5", "-5\n", id="negative-int"),
        pytest.param("-2.5", "-2.5\n", id="negative-float"),
        pytest.param("-2.5f", "-2.5\n", id="negative-float-suffix"),
        pytest.param("-1 + 2", "1\n", id="negative-in-expression"),
        pytest.param("1 - -1", "2\n", id="minus-negative"),
    ],
)
def test_negative_numbers(selector, expected):
    """A leading dash immediately before a number is a negative literal.

    CATCHES: the unary minus is folded into the number token by the literal
    parser, so ``1 - -1`` is 2 and ``-1 + 2`` is 1; the ``--`` separator is
    needed so the CLI does not read the leading dash as a flag.
    """
    res = run_query(selector, extra=("--",))
    assert res.returncode == 0
    assert out_text(res) == expected


def test_dash_without_following_number_is_rejected():
    """A dash not followed by a number is a parse error, not a unary minus.

    CATCHES: ``-`` only combines with a Number token; with a symbol after it
    the parser reports the dash itself at position 0.
    """
    res = run_query("- a", extra=("--",))
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: "
        'failed to parse: unexpected token 23 "-" at position 0.\n'
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("1.", "1\n", id="trailing-dot-is-separate-token"),
        pytest.param("1.2.3", "3\n", id="second-dot-chains"),
    ],
)
def test_dot_after_number(selector, expected):
    """A number keeps its digits only while a digit follows the dot.

    CATCHES: ``1.`` is the integer 1 followed by a dot token, and ``1.2.3``
    is the float 1.2 chained through a dot with 3 - not a parse error.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_leading_dot_float_is_rejected():
    """``.5`` is not a float: the bare dot is an unexpected token.

    CATCHES: the number scanner only starts on a digit, so a leading dot is
    lexed as a Dot token which cannot begin an expression.
    """
    res = run_query(".5")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: "
        'failed to parse: unexpected token 29 "." at position 0.\n'
    )


def test_no_scientific_notation():
    """``1e3`` is not a number: it chains the integer 1 with a property.

    CATCHES: the tokenizer has no exponent support, so ``e3`` becomes a symbol
    and the chained property access on an int fails at execution time rather
    than producing 1000.
    """
    res = run_query("1e3")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: execution error when processing "
        "ast.ChainedExpr: error executing expression: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int\n"
    )


@pytest.mark.parametrize(
    "selector",
    [
        pytest.param("99999999999999999999", id="twenty-nines"),
        pytest.param("9223372036854775808", id="int64-max-plus-one"),
    ],
)
def test_integer_overflow_is_a_parse_error(selector):
    """Integers beyond int64 fail while building the literal, not at runtime.

    CATCHES: the overflow surfaces as a bare strconv error wrapped only by
    "error parsing selector", with no "failed to parse" prefix.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: strconv.ParseInt: "
        'parsing "%s": value out of range\n' % selector
    )
