"""Shared fixtures and helpers for the dasel selector-syntax module tests.

The module under test is the query language grammar: which selector strings
``selector.Parse`` accepts, and the exact error text a rejected one produces.
Everything is driven through the CLI binary so the whole tokenize -> parse ->
report path is exercised black-box.
"""

import os
import subprocess

import pytest

# Fully pinned child environment. Nothing from the host (a stray ~/dasel.yaml
# changing the default output format, locale settings, unrelated variables)
# may influence the oracle, so we start from a fixed minimal set.
BASE_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
}

# Default JSON document piped to the binary on stdin.
DEFAULT_INPUT = b'{"a":1,"b":2,"c":[10,20,30],"d":{"e":"f"},"s":"str"}'

# The same document as the JSON writer emits it by default (4-space indent).
DEFAULT_INPUT_PRETTY = (
    '{\n    "a": 1,\n    "b": 2,\n    "c": [\n        10,\n        20,\n        30\n    ],'
    '\n    "d": {\n        "e": "f"\n    },\n    "s": "str"\n}\n'
)


def _resolve_executable():
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if exe and os.path.exists(exe):
        return exe
    raise RuntimeError(
        "PROGRAMGYM_EXECUTABLE is not set or does not exist; "
        "the ProgramGym runner must export it."
    )


@pytest.fixture(scope="session")
def dasel_exe():
    """Return the absolute path to the dasel binary under test."""
    return _resolve_executable()


def _child_env(env):
    """Build the pinned child environment, plus any per-test variables."""
    full_env = dict(BASE_ENV)
    # Coverage instrumentation hook: forward GOCOVERDIR when the pipeline sets
    # it so the reference binary's source coverage can be measured.
    gocoverdir = os.environ.get("GOCOVERDIR")
    if gocoverdir:
        full_env["GOCOVERDIR"] = gocoverdir
    for key, value in (env or {}).items():
        full_env[key] = value
    return full_env


def run_dasel(args, stdin=DEFAULT_INPUT, env=None, timeout=30):
    """Run the binary with an explicit argv (everything after the executable).

    ``env`` is a dict of extra variables applied on top of the pinned base
    environment, used for ``$VAR`` reference tests. Returns the completed
    subprocess so callers can assert on stdout, stderr and the exit code.
    """
    if isinstance(stdin, str):
        stdin = stdin.encode("utf-8")
    return subprocess.run(
        [_resolve_executable(), *args],
        input=stdin,
        env=_child_env(env),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )


def run_query(query, stdin=DEFAULT_INPUT, extra=(), env=None, timeout=30):
    """Run a single selector with pinned JSON input/output formats.

    ``extra`` holds extra CLI flags placed before the selector argument
    (e.g. ``("--compact",)`` or ``("--",)`` for selectors starting with ``-``).
    """
    return run_dasel(
        ["-i", "json", "-o", "json", *extra, query],
        stdin=stdin,
        env=env,
        timeout=timeout,
    )


def out_text(res):
    """Decoded stdout of a completed run."""
    return res.stdout.decode("utf-8")


def err_text(res):
    """Decoded stderr of a completed run."""
    return res.stderr.decode("utf-8")
