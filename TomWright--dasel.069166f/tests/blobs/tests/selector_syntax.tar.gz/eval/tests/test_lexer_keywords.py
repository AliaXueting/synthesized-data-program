"""Lexer behaviour for keywords, literals, comments and whitespace."""

import pytest

from conftest import DEFAULT_INPUT_PRETTY, err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("true", "true\n", id="true-lower"),
        pytest.param("TRUE", "true\n", id="true-upper"),
        pytest.param("True", "true\n", id="true-mixed"),
        pytest.param("false", "false\n", id="false-lower"),
        pytest.param("FALSE", "false\n", id="false-upper"),
        pytest.param("False", "false\n", id="false-mixed"),
        pytest.param("null", "null\n", id="null-lower"),
        pytest.param("NULL", "null\n", id="null-upper"),
        pytest.param("Null", "null\n", id="null-mixed"),
    ],
)
def test_bool_and_null_literals_are_case_insensitive(selector, expected):
    """true/false/null are matched case-insensitively.

    CATCHES: only these three literals ignore case; every other keyword in the
    grammar is case-sensitive, so ``TRUE`` is a bool while ``MAP`` is not the
    map keyword.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector",
    [
        pytest.param("nullx", id="null-with-letter-suffix"),
        pytest.param("null1", id="null-with-digit-suffix"),
        pytest.param("truex", id="true-with-suffix"),
        pytest.param("ifx", id="if-with-suffix"),
        pytest.param("elsex", id="else-with-suffix"),
        pytest.param("elseifx", id="elseif-with-suffix"),
        pytest.param("mapp", id="map-with-suffix"),
        pytest.param("sortByy", id="sortby-with-suffix"),
        pytest.param("ascx", id="asc-with-suffix"),
    ],
)
def test_keyword_with_trailing_word_characters_is_a_symbol(selector):
    """A keyword followed by a letter or digit lexes as one bare symbol.

    CATCHES: keyword matching requires a word boundary, so ``nullx`` is a
    single property name (reported as "map key not found") rather than the
    null literal followed by a property.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: execution error when processing "
        'ast.PropertyExpr: map key not found: "%s"\n' % selector
    )


@pytest.mark.parametrize(
    "selector,kind",
    [
        pytest.param("asc", 56, id="asc"),
        pytest.param("desc", 57, id="desc"),
        pytest.param("else", 41, id="else"),
        pytest.param("elseif", 42, id="elseif"),
    ],
)
def test_bare_direction_and_else_keywords_are_rejected(selector, kind):
    """asc/desc/else/elseif are keywords that cannot start an expression.

    CATCHES: these lex as their own token kinds (56/57/41/42) and the parser
    reports them by kind at position 0, unlike map/if which first demand a
    parenthesised argument list.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token %d "%s" at position 0.\n' % (kind, selector)
    )


def test_control_keywords_are_case_sensitive():
    """``MAP`` is not the map keyword; it becomes an unknown function call.

    CATCHES: only the literals are case-folded - a capitalised control keyword
    lexes as a plain symbol, so ``MAP(x)`` parses as a call expression and
    fails with "unknown function" rather than a parse error.
    """
    res = run_query("MAP(x)", stdin=b"[1]")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error executing selector: "
        'error evaluating expression ast.CallExpr: unknown function: "MAP"\n'
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("a // trailing comment", "1\n", id="comment-after-expr"),
        pytest.param("a //x", "1\n", id="comment-no-space"),
        pytest.param("a /// triple", "1\n", id="three-slashes"),
        pytest.param("a //x\r\n", "1\n", id="comment-terminated-by-crlf"),
        pytest.param("// lead\na", "1\n", id="comment-before-expr"),
        pytest.param("1 // first\n+ 2", "3\n", id="comment-splits-line"),
        pytest.param(
            "// only a comment",
            DEFAULT_INPUT_PRETTY,
            id="comment-is-whole-selector",
        ),
    ],
)
def test_line_comments(selector, expected):
    """``//`` starts a comment that runs to the end of the line.

    CATCHES: the expression continues after the newline (``1 // c\\n+ 2`` is
    3), a third slash is still a comment, and a selector that is only a
    comment behaves like an empty selector and echoes the input unchanged.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


def test_hash_is_not_a_comment():
    """``#`` is not a comment marker; it is a tokenizer error.

    CATCHES: only ``//`` starts a comment, so a shell-style ``#`` comment
    fails with "unexpected token: #" at its byte offset.
    """
    res = run_query("a # hash comment")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: "
        "failed to tokenize: unexpected token: # at position 2.\n"
    )


def test_block_comments_are_not_supported():
    """``/* */`` is a Slash token followed by a Star token, not a comment.

    CATCHES: the Star is rejected by the parser at position 3 because there is
    no block comment syntax at all.
    """
    res = run_query("a /* block */")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token 26 "*" at position 3.\n'
    )


@pytest.mark.parametrize(
    "selector",
    [
        pytest.param("\t a \t", id="tabs-around"),
        pytest.param("\n\n a \n\n", id="newlines-around"),
        pytest.param(" \t\r\n a ", id="mixed-space-tab-cr"),
        pytest.param("   ", id="whitespace-only"),
    ],
)
def test_whitespace_is_skipped(selector):
    """Spaces, tabs, CR and newlines between tokens are ignored.

    CATCHES: whitespace-only input behaves like an empty selector, returning
    the input document unchanged with exit 0.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    if selector.strip():
        assert out_text(res) == "1\n"
    else:
        assert out_text(res) == DEFAULT_INPUT_PRETTY
