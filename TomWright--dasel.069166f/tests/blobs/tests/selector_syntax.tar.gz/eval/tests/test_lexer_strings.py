"""Lexer behaviour for single- and double-quoted string literals."""

import pytest

from conftest import err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param('"hello"', '"hello"\n', id="double-quoted-word"),
        pytest.param('""', '""\n', id="double-quoted-empty"),
        pytest.param("''", '""\n', id="single-quoted-empty"),
        pytest.param("'single'", '"single"\n', id="single-quoted-word"),
    ],
)
def test_quoted_string_literals(selector, expected):
    """A quoted string as the whole selector evaluates to itself.

    CATCHES: both quote styles produce a string token, and the JSON writer
    re-quotes the value with double quotes regardless of input quote style.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param(r'"a\tb"', '"a\\tb"\n', id="tab-escape"),
        pytest.param(r'"a\nb"', '"a\\nb"\n', id="newline-escape"),
        pytest.param(r'"a\rb"', '"a\\rb"\n', id="carriage-return-escape"),
        pytest.param(r"'back\\slash'", '"back\\\\slash"\n', id="backslash-escape"),
        pytest.param(r'"say \"hi\""', '"say \\"hi\\""\n', id="escaped-double-quote"),
        pytest.param(r"'a\'b'", '"a\'b"\n', id="escaped-single-quote"),
    ],
)
def test_recognised_escape_sequences(selector, expected):
    """The escapes \\t \\r \\n \\\\ and the closing quote are decoded.

    CATCHES: only that fixed escape set is honoured; each collapses to a single
    real character which the JSON writer then re-escapes on output.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_escaped_quote_only_for_matching_quote_char():
    r"""Escaping the *other* quote style keeps the character but drops the slash.

    CATCHES: the escape table is built from the opening quote character, so
    ``\'`` inside a double-quoted string is an unknown escape and the backslash
    is silently discarded rather than kept or rejected.
    """
    res = run_query(r'"it\'s"')
    assert res.returncode == 0
    assert out_text(res) == '"it\'s"\n'


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param(r'"\q"', '"q"\n', id="unknown-escape-letter"),
        pytest.param(r'"x\yz"', '"xyz"\n', id="unknown-escape-mid-string"),
    ],
)
def test_unknown_escape_drops_the_backslash(selector, expected):
    """A backslash before an unlisted character is dropped, the char is kept.

    CATCHES: unknown escapes do not error and do not keep the backslash; the
    character following it is appended verbatim.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,position",
    [
        pytest.param('"abc', "4", id="missing-closing-double-quote"),
        pytest.param("'abc", "4", id="missing-closing-single-quote"),
        pytest.param("'", "1", id="lone-single-quote"),
        pytest.param('"a" "b', "6", id="second-string-unterminated"),
        pytest.param('"abc\\', "5", id="trailing-backslash"),
    ],
)
def test_unterminated_string_reports_unexpected_eof(selector, position):
    """A string with no closing quote fails tokenizing with an EOF position.

    CATCHES: the position is the byte offset just past the last scanned
    character, and the message says "unexpected EOF", not "unexpected token".
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: "
        "failed to tokenize: unexpected EOF at position %s.\n" % position
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param('"a//b"', '"a//b"\n', id="double-slash-inside-string"),
        pytest.param('"1 + 2 * 3"', '"1 + 2 * 3"\n', id="operators-inside-string"),
        pytest.param('"{ a: 1 }"', '"{ a: 1 }"\n', id="braces-inside-string"),
        pytest.param('"#notacomment"', '"#notacomment"\n', id="hash-inside-string"),
    ],
)
def test_string_contents_are_not_lexed_as_syntax(selector, expected):
    """Characters that would be operators or comments are inert inside quotes.

    CATCHES: ``//`` inside a quoted string must not start a line comment and
    stray characters such as ``#`` must not trigger a tokenizer error.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


def test_string_used_as_object_key_and_value():
    """Quoted strings work as both object keys and object values.

    CATCHES: the object parser accepts string expression keys, not only bare
    symbol shorthand keys.
    """
    res = run_query('{"k": "v"}')
    assert res.returncode == 0
    assert out_text(res) == '{\n    "k": "v"\n}\n'


def test_string_with_embedded_newline_escape_in_output():
    r"""A real newline inside a string is JSON-escaped on output.

    CATCHES: ``\n`` becomes one literal newline byte in the token value, which
    the writer must render as the two characters backslash-n.
    """
    res = run_query(r'"line1\nline2"', extra=("--compact",))
    assert res.returncode == 0
    assert out_text(res) == '"line1\\nline2"\n'
