"""Parser behaviour for object literals, array literals and spread."""

import pytest

from conftest import err_text, out_text, run_query


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("{a: 1}", '{\n    "a": 1\n}\n', id="bare-key"),
        pytest.param('{"a": 1}', '{\n    "a": 1\n}\n', id="double-quoted-key"),
        pytest.param("{'a': 1}", '{\n    "a": 1\n}\n', id="single-quoted-key"),
        pytest.param("{a}", '{\n    "a": 1\n}\n', id="shorthand-property"),
        pytest.param("{a: a}", '{\n    "a": 1\n}\n', id="shorthand-value"),
        pytest.param('{a: 1, "b": 2}', '{\n    "a": 1,\n    "b": 2\n}\n', id="mixed-keys"),
        pytest.param("{a: 1,}", '{\n    "a": 1\n}\n', id="trailing-comma"),
        pytest.param("{}", "{}\n", id="empty-object"),
        pytest.param("{x: {y: 1}}", '{\n    "x": {\n        "y": 1\n    }\n}\n', id="nested-object"),
        pytest.param("{a: [1,2]}", '{\n    "a": [\n        1,\n        2\n    ]\n}\n', id="array-value"),
        pytest.param("{a: 1 + 2}", '{\n    "a": 3\n}\n', id="expression-value"),
        pytest.param('{"k" + "1": 1}', '{\n    "k1": 1\n}\n', id="expression-key"),
        pytest.param('{"k": "v"}', '{\n    "k": "v"\n}\n', id="string-key-and-value"),
    ],
)
def test_object_literals(selector, expected):
    """Object literals accept bare, quoted and computed keys.

    CATCHES: ``{a}`` is shorthand for ``{a: a}`` and keys may be arbitrary
    expressions (``"k" + "1"``), while a trailing comma is tolerated.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert res.stderr == b""
    assert out_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param(
            "{a: }",
            'dasel: error: error parsing selector: failed to parse: '
            'unexpected token 7 "}" at position 4.\n',
            id="missing-value",
        ),
        pytest.param(
            "{,}",
            'dasel: error: error parsing selector: failed to parse: '
            'unexpected token 2 "," at position 1.\n',
            id="comma-only",
        ),
        pytest.param(
            '{"a"}',
            "dasel: error: error parsing selector: invalid shorthand property\n",
            id="string-key-without-value",
        ),
        pytest.param(
            "{1: 2}",
            "dasel: error: error executing selector: execution error when processing "
            "ast.ObjectExpr: expected key to resolve to string, got int\n",
            id="integer-key",
        ),
        pytest.param(
            "{a: 1 b: 2}",
            "dasel: error: error parsing selector: expected end of object element: "
            'failed to parse: unexpected token 1 "b" at position 6.\n',
            id="missing-comma-between-pairs",
        ),
        pytest.param(
            "{a: 1",
            "dasel: error: error parsing selector: expected end of object element: "
            'failed to parse: unexpected token 0 "" at position 0.\n',
            id="missing-close-curly",
        ),
        pytest.param(
            "{...a}",
            'dasel: error: error parsing selector: failed to parse: '
            'unexpected token 1 "a" at position 4.\n',
            id="spread-as-key",
        ),
    ],
)
def test_object_literal_errors(selector, expected):
    """Malformed object literals each produce their own recorded message.

    CATCHES: these are four different failure shapes - a plain UnexpectedToken
    for a missing value, the bare "invalid shorthand property" when a
    non-symbol key has no colon, the wrapped "expected end of object element"
    for a missing separator, and an execution-time error for a non-string key.
    """
    res = run_query(selector)
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        pytest.param("[1, 2]", "[\n    1,\n    2\n]\n", id="two-elements"),
        pytest.param("[]", "[]\n", id="empty-array"),
        pytest.param("[1,]", "[\n    1\n]\n", id="trailing-comma"),
        pytest.param("[1, [2, 3]]", "[\n    1,\n    [\n        2,\n        3\n    ]\n]\n", id="nested-array"),
        pytest.param("[{a:1},{a:2}]", "[\n    {\n        \"a\": 1\n    },\n    {\n        \"a\": 2\n    }\n]\n", id="array-of-objects"),
        pytest.param("[1 2]", "[\n    2\n]\n", id="space-separated-elements"),
        pytest.param("[1,2][0]", "1\n", id="index-into-literal"),
        pytest.param('{a: 1}["a"]', "1\n", id="index-into-object-literal"),
    ],
)
def test_array_literals(selector, expected):
    """Array literals build arrays, and can be indexed immediately.

    CATCHES: elements separated by whitespace instead of a comma are chained
    (so ``[1 2]`` is a one element array holding 2), and a literal can be
    subscripted directly because index parsing follows the literal.
    """
    res = run_query(selector)
    assert res.returncode == 0
    assert out_text(res) == expected


def test_comma_only_array_literal_passes_through_input():
    """``[,]`` parses to an array with no elements and echoes the input.

    CATCHES: the array parser drops empty comma-separated segments instead of
    erroring, and an element-less array literal evaluates to the input value,
    producing a one element array containing the whole document.
    """
    res = run_query("[,]", extra=("--compact",))
    assert res.returncode == 0
    assert out_text(res) == (
        '[{"a":1,"b":2,"c":[10,20,30],"d":{"e":"f"},"s":"str"}]\n'
    )


def test_star_cannot_start_an_array_literal():
    """``[*]`` at the start of a selector is an array literal, and ``*`` is
    not a valid element.

    CATCHES: the wildcard spread only exists *after* an expression, so a
    leading ``[*]`` reports the Star token (kind 26) at position 1.
    """
    res = run_query("[*]")
    assert res.returncode == 1
    assert res.stdout == b""
    assert err_text(res) == (
        "dasel: error: error parsing selector: failed to parse: "
        'unexpected token 26 "*" at position 1.\n'
    )


def test_bare_spread_emits_one_document_per_element():
    """A lone ``...`` writes each top level value separately.

    CATCHES: multiple output values are joined with a blank line between them,
    so the output is not valid single-document JSON.
    """
    res = run_query("...")
    assert res.returncode == 0
    assert out_text(res) == '1\n\n2\n\n[\n    10,\n    20,\n    30\n]\n\n{\n    "e": "f"\n}\n\n"str"\n'


def test_spread_inside_array_literal_flattens_input():
    """``[...]`` builds an array whose elements are the input's elements.

    CATCHES: the spread inserts each element individually, so the array
    literal contains 5 elements - the two scalars, the slice, the map and the
    string - in input order.
    """
    res = run_query("[...]")
    assert res.returncode == 0
    assert out_text(res) == (
        '[\n    1,\n    2,\n    [\n        10,\n        20,\n        30\n    ],\n'
        '    {\n        "e": "f"\n    },\n    "str"\n]\n'
    )


def test_spread_between_array_elements():
    """``[1, ..., 2]`` interleaves literal and spread elements in order.

    CATCHES: elements keep their written order with the spread expanded in
    place, giving 1, the five input values, then 2.
    """
    res = run_query("[1, ..., 2]")
    assert res.returncode == 0
    assert out_text(res) == (
        '[\n    1,\n    1,\n    2,\n    [\n        10,\n        20,\n        30\n    ],\n'
        '    {\n        "e": "f"\n    },\n    "str",\n    2\n]\n'
    )
