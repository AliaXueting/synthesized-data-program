"""Tests for the numeric builtins: abs, add, avg, sum, min, max, floor,
ceil and round.

Each function is exercised on ints and floats, on its optional-argument
form (operating on the input document instead of an argument), on its
type-error path, and on the return type it leaves behind - pinned through
typeOf so int-vs-float results are distinguished even when they print the
same.
"""

import pytest

PREFIX = (
    "dasel: error: error executing selector: execution error when processing "
    "ast.CallExpr: error executing function: "
)


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ("abs(-5)", "5\n"),
        ("abs(5)", "5\n"),
        ("abs(0)", "0\n"),
        ("abs(-5.5)", "5.5\n"),
        ("typeOf(abs(-5))", '"int"\n'),
        ("typeOf(abs(-5.0))", '"float"\n'),
    ],
)
def test_abs_happy_paths(run_dasel, query, stdout):
    """abs negates negatives and passes positives through, keeping type."""
    # CATCHES: abs(-5) stays an int while abs(-5.0) stays a float - a
    # re-implementation that always returns float breaks the typeOf rows.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_abs_uses_data_when_no_argument(run_dasel):
    """With no argument, abs operates on the input document."""
    # CATCHES: the 0-argument form is a different code path from abs(arg)
    # but must produce the same value for the same number.
    proc = run_dasel(["-i", "json", "abs()"], input_text="-5.5")
    assert proc.returncode == 0
    assert proc.stdout == "5.5\n"
    assert proc.stderr == ""


def test_abs_type_error(run_dasel):
    """abs of a string fails with the model's type expectation."""
    # CATCHES: a non-numeric input falls through to FloatValue, so the
    # inner error is "expected float, got string" prefixed by the abs hint.
    proc = run_dasel(["-i", "json", 'abs("x")'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "abs": abs expects a numeric value: '
        "unexpected type: expected float, got string\n"
    )


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ("add(1, 2, 3)", "6\n"),
        ("add(5)", "5\n"),
        ("add(-1, -2)", "-3\n"),
        ("add(1.5, 2.5)", "4\n"),
        ("add(1, 2.5)", "3.5\n"),
        ("add(2.0, 1)", "3\n"),
        ('typeOf(add(1, 2))', '"int"\n'),
        ('typeOf(add(1.0, 2))', '"float"\n'),
    ],
)
def test_add_happy_paths(run_dasel, query, stdout):
    """add sums its arguments; any float operand makes a float result."""
    # CATCHES: int-only argument lists keep the int type while a single
    # float (even 1.0/2.0 which print bare) flips the result to float.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ('add("a", 1)', 'error execution func "add": expected int or float, got string'),
        ("add(true, 1)", 'error execution func "add": expected int or float, got bool'),
    ],
)
def test_add_type_errors(run_dasel, query, stderr_fragment):
    """add rejects non-numeric operands naming the offending type."""
    # CATCHES: the message carries the Go type name (string, bool) of the
    # rejected argument, not a generic "not a number".
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


def test_add_int64_overflow_wraps(run_dasel):
    """add wraps on int64 overflow instead of erroring or saturating."""
    # CATCHES: max-int64 plus one prints the wrapped negative value, which
    # pins two's-complement wraparound semantics for the int accumulator.
    proc = run_dasel(["-i", "json", "add(9223372036854775807, 1)"])
    assert proc.returncode == 0
    assert proc.stdout == "-9223372036854775808\n"
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ("sum(1, 2, 3)", "6\n"),
        ("sum(1.5)", "1.5\n"),
        ("sum(1.5, 2.5)", "4\n"),
        ("sum(1, 2.5)", "3.5\n"),
        ('typeOf(sum(1, 2))', '"int"\n'),
        ('typeOf(sum(1.0, 2))', '"float"\n'),
    ],
)
def test_sum_happy_paths(run_dasel, query, stdout):
    """sum adds numbers, promoting to float only when a float is present."""
    # CATCHES: like add, the int/float return split is pinned via typeOf;
    # sum(1.5) alone stays 1.5 rather than truncating to 1.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_sum_type_error(run_dasel):
    """sum refuses a string operand with its own message."""
    # CATCHES: sum's wording ("cannot sum non-numeric value of type
    # string") differs from add's ("expected int or float, got string").
    proc = run_dasel(["-i", "json", 'sum("a", 1)'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "sum": cannot sum non-numeric value '
        "of type string\n"
    )


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ("avg(1, 2, 3, 4)", "2.5\n"),
        ("avg(1, 2, 3)", "2\n"),
        ("avg(3)", "3\n"),
        ("avg(1, 2.5)", "1.75\n"),
        ('typeOf(avg(3))', '"float"\n'),
    ],
)
def test_avg_happy_paths(run_dasel, query, stdout):
    """avg always returns a float, even for int inputs that divide evenly."""
    # CATCHES: avg(3) is float 3 (typeOf "float") while printing as "3" -
    # an int-typed average would print the same but fail the typeOf row.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_avg_type_error(run_dasel):
    """avg rejects a non-numeric operand with its own message."""
    # CATCHES: avg's wording ("cannot average non-numeric value of type
    # string") is distinct from sum's and add's equivalents.
    proc = run_dasel(["-i", "json", 'avg("a", 1)'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "avg": cannot average non-numeric '
        "value of type string\n"
    )


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ("max(1, 5, 3)", "5\n"),
        ("max(7)", "7\n"),
        ("max(2, 2)", "2\n"),
        ("max(1, 2.5, 2)", "2.5\n"),
        ("max(1, 1.0)", "1\n"),
        ('max("a", "b")', '"b"\n'),
        ("min(4, 2, 9)", "2\n"),
        ("min(1.5, 1.2)", "1.2\n"),
        ("min(2, 1.5)", "1.5\n"),
        ('min("a", "b")', '"a"\n'),
    ],
)
def test_min_max_happy_paths(run_dasel, query, stdout):
    """min/max compare numbers and strings, mixing int and float."""
    # CATCHES: comparisons work across int/float and lexicographically on
    # strings; ties keep the first value and single arguments pass through.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ('max(1, "a")', 'error execution func "max": incompatible types: string and int'),
        ("max(true, false)", 'error execution func "max": incompatible types: bool and bool'),
        ('min({"a": 1}, 2)', 'error execution func "min": incompatible types: int and map'),
    ],
)
def test_min_max_incompatible_types(run_dasel, query, stderr_fragment):
    """min/max report the two operand types in argument-then-current order."""
    # CATCHES: the message lists the new argument's type first ("string and
    # int" for max(1, "a")), and even two bools are "incompatible".
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("floor(1.7)", '{"a":1}', "1\n"),
        ("floor(-1.2)", '{"a":1}', "-2\n"),
        ("floor(3)", '{"a":1}', "3\n"),
        ("ceil(1.2)", '{"a":1}', "2\n"),
        ("ceil(-1.7)", '{"a":1}', "-1\n"),
        ("ceil(3)", '{"a":1}', "3\n"),
        ("round(2.5)", '{"a":1}', "3\n"),
        ("round(-2.5)", '{"a":1}', "-3\n"),
        ("round(2.4)", '{"a":1}', "2\n"),
        ("round(0.5)", '{"a":1}', "1\n"),
        ("round(-0.5)", '{"a":1}', "-1\n"),
        ("floor()", "1.7", "1\n"),
        ("ceil()", "-1.2", "-1\n"),
        ("round()", "2.5", "3\n"),
        ("typeOf(floor(1.7))", '{"a":1}', '"int"\n'),
        ("typeOf(round(2.5))", '{"a":1}', '"int"\n'),
    ],
)
def test_floor_ceil_round(run_dasel, query, stdin_text, stdout):
    """floor/ceil/round return ints and round halves away from zero."""
    # CATCHES: round(2.5)=3 but round(-2.5)=-3 (away from zero, not
    # banker's rounding), floor(-1.2)=-2, and results are always ints.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_floor_uses_data_and_validates_type(run_dasel):
    """floor() without arguments floors the document; strings are refused."""
    # CATCHES: the no-argument path reuses the same numeric check, so
    # floor() on "hello" fails with the float expectation, not a crash.
    proc = run_dasel(["-i", "json", "floor()"], input_text='"hello"')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "floor": floor expects a numeric '
        "value: unexpected type: expected float, got string\n"
    )
