"""Tests for the collection builtins: len, keys, values, entries,
fromEntries, reverse, flatten, unique, first, last, contains, has, get
and merge.

These pin key/insertion ordering, the one-level semantics of flatten, the
branch-pruning quirks of reverse on empty input, deep-merge behaviour and
the has/get key-type matrix (string keys look in maps, int keys in slices).
"""

import pytest

PREFIX = (
    "dasel: error: error executing selector: execution error when processing "
    "ast.CallExpr: error executing function: "
)


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('len("hello")', '{"a":1}', "5\n"),
        ('len("")', '{"a":1}', "0\n"),
        ('len({"a": 1, "b": 2, "c": 3})', '{"a":1}', "3\n"),
        ("len([1, 2, 3])", '{"a":1}', "3\n"),
        ('len(split(",", "a,b,c"))', '{"a":1}', "3\n"),
        ("len(entries())", '{"a": 1, "b": 2}', "2\n"),
        ("len($root)", '{"a": 1, "b": 2}', "2\n"),
        ('typeOf(len([1]))', '{"a":1}', '"int"\n'),
    ],
)
def test_len(run_dasel, query, stdin_text, stdout):
    """len counts map keys, slice elements and string bytes."""
    # CATCHES: len composes with other calls (split, entries) and with the
    # $root variable, and always returns an int.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        ("len(5)", '{"a":1}', "error execution func \"len\": unexpected type: expected [array map string], got int"),
        ("len(true)", '{"a":1}', "error execution func \"len\": unexpected type: expected [array map string], got bool"),
        ("len(1.5)", '{"a":1}', "error execution func \"len\": unexpected type: expected [array map string], got float"),
        ("len($this)", "null", "error execution func \"len\": unexpected type: expected [array map string], got null"),
    ],
)
def test_len_type_errors(run_dasel, query, stdin_text, stderr_fragment):
    """len of a scalar lists the three accepted types in order."""
    # CATCHES: the expectation is printed as "[array map string]" with the
    # actual type last; a re-implementation worded differently fails.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


def test_len_counts_bytes_of_non_ascii_literal(run_dasel):
    """len of a non-ASCII literal reports the reference's byte-decoded length."""
    # CATCHES: the reference lexes the literal byte-wise ("héllo" becomes
    # 6 runes / 8 bytes), so len answers 8 - not the 5 runes or 6 UTF-8
    # bytes a Unicode-aware implementation would report.
    proc = run_dasel(["-i", "json", 'len("héllo")'])
    assert proc.returncode == 0
    assert proc.stdout == "8\n"
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("keys()", '{"b": 1, "a": 2, "c": 3}', '[\n    "b",\n    "a",\n    "c"\n]\n'),
        ("keys()", '{"a": 1, "b": 2}', '[\n    "a",\n    "b"\n]\n'),
        ("keys()", "{}", "[]\n"),
        ("keys()", '["x", "y", "z"]', "[\n    0,\n    1,\n    2\n]\n"),
        ("a.keys()", '{"a": {"x": 1, "y": 2}}', '[\n    "x",\n    "y"\n]\n'),
        ("$this.keys()", '{"a": 1, "b": 2}', '[\n    "a",\n    "b"\n]\n'),
    ],
)
def test_keys(run_dasel, query, stdin_text, stdout):
    """keys lists map keys in insertion order, or slice indexes as ints."""
    # CATCHES: keys are NOT sorted - "b","a","c" stays in document order -
    # and a slice yields integer indexes rather than its elements.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_keys_type_error(run_dasel):
    """keys on a scalar document is refused."""
    # CATCHES: the message is terse ("keys can only be used on maps and
    # slices") with no type name appended.
    proc = run_dasel(["-i", "json", "keys()"], input_text='"hello"')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "keys": keys can only be used on '
        "maps and slices\n"
    )


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("values()", '{"b": 1, "a": 2, "c": 3}', "[\n    1,\n    2,\n    3\n]\n"),
        ("values()", '{"a": 1, "b": [1, 2, 3]}', "[\n    1,\n    [\n        1,\n        2,\n        3\n    ]\n]\n"),
        ("values()", "{}", "[]\n"),
    ],
)
def test_values(run_dasel, query, stdin_text, stdout):
    """values lists map values in key order, keeping nested structure."""
    # CATCHES: values parallel keys() in insertion order and pass nested
    # slices through untouched.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        ("values()", "[1, 2]", 'error execution func "values": values can only be used on maps, got array'),
        ("values()", "5", 'error execution func "values": values can only be used on maps, got int'),
    ],
)
def test_values_type_errors(run_dasel, query, stdin_text, stderr_fragment):
    """values only works on maps and reports the offending type."""
    # CATCHES: unlike keys(), values() has no slice branch - arrays are
    # rejected with their type name appended.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("entries()", '{"b": 1, "a": 2}', '[\n    {\n        "key": "b",\n        "value": 1\n    },\n    {\n        "key": "a",\n        "value": 2\n    }\n]\n'),
        ("entries()", '{"a": {"x": 1}}', '[\n    {\n        "key": "a",\n        "value": {\n            "x": 1\n        }\n    }\n]\n'),
        ("entries()", "{}", "[]\n"),
    ],
)
def test_entries(run_dasel, query, stdin_text, stdout):
    """entries builds {key, value} objects in map insertion order."""
    # CATCHES: the field names are exactly "key" and "value", and nested
    # values are embedded by reference, not flattened.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_entries_type_error(run_dasel):
    """entries on a scalar document is refused with its type name."""
    # CATCHES: same wording family as values() but its own function name
    # and the type appended after the comma.
    proc = run_dasel(["-i", "json", "entries()"], input_text="5")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "entries": entries can only be used '
        "on maps, got int\n"
    )


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        (
            'fromEntries([{"key": "a", "value": 1}, {"key": "b", "value": 2}])',
            '{"a":1}',
            '{\n    "a": 1,\n    "b": 2\n}\n',
        ),
        (
            "fromEntries()",
            '[{"key": "a", "value": 1}]',
            '{\n    "a": 1\n}\n',
        ),
        ("fromEntries([])", '{"a":1}', "{}\n"),
        (
            "fromEntries(entries())",
            '{"b": 1, "a": 2}',
            '{\n    "b": 1,\n    "a": 2\n}\n',
        ),
    ],
)
def test_from_entries(run_dasel, query, stdin_text, stdout):
    """fromEntries rebuilds a map from {key, value} objects, order kept."""
    # CATCHES: entry order defines result order (b before a survives) and
    # fromEntries(entries()) is an exact round trip of the document.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        ("fromEntries([1, 2])", '{"a":1}', 'error execution func "fromEntries": fromEntries expects each element to be an object, got int at index 0'),
        ("fromEntries([{\"value\": 1}])", '{"a":1}', 'error execution func "fromEntries": fromEntries expects each element to have a "key" field: map key not found: "key"'),
        ("fromEntries(5)", '{"a":1}', 'error execution func "fromEntries": fromEntries expects an array, got int'),
    ],
)
def test_from_entries_errors(run_dasel, query, stdin_text, stderr_fragment):
    """fromEntries reports the index of a bad element and missing keys."""
    # CATCHES: the element error names index 0 and the missing-field error
    # chains the model's 'map key not found: "key"' text.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("reverse([1, 2, 3])", '{"a":1}', "[\n    3,\n    2,\n    1\n]\n"),
        ("reverse([1])", '{"a":1}', "[\n    1\n]\n"),
        ('reverse("abc")', '{"a":1}', '"cba"\n'),
        ('reverse("a")', '{"a":1}', '"a"\n'),
    ],
)
def test_reverse(run_dasel, query, stdin_text, stdout):
    """reverse flips slices and strings in place."""
    # CATCHES: single-element inputs pass through; the result is a new
    # value printed with standard 4-space JSON indentation.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_reverse_type_error(run_dasel):
    """reverse of a scalar names the two accepted types."""
    # CATCHES: the message is "reverse expects a slice or string, got int" -
    # note "slice", not "array", in this function's wording.
    proc = run_dasel(["-i", "json", "reverse(5)"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "reverse": reverse expects a slice or '
        "string, got int\n"
    )


def test_reverse_empty_slice_errors_cleanly(run_dasel):
    """Reversing an empty slice fails with the out-of-range index error."""
    # CATCHES: the index-range implementation asks for index -1 on an empty
    # slice, producing a wrapped error (not a panic) with exit code 1.
    proc = run_dasel(["-i", "json", "reverse([])"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "reverse": error getting slice index: '
        "slice index out of range: -1\n"
    )


def test_reverse_empty_string_panics(run_dasel):
    """Reversing an empty string crashes the reference with a Go panic."""
    # CATCHES: the string branch of reverse has no empty guard - unlike the
    # slice branch - so the process dies with exit code 2 and a panic whose
    # first line names index -1; the goroutine dump after it varies.
    proc = run_dasel(["-i", "json", 'reverse("")'])
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr.startswith("panic: runtime error: index out of range [-1]")


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("flatten([[1, 2], [3], [4, 5]])", '{"a":1}', "[\n    1,\n    2,\n    3,\n    4,\n    5\n]\n"),
        ("flatten([[1, [2]], [3]])", '{"a":1}', "[\n    1,\n    [\n        2\n    ],\n    3\n]\n"),
        ("flatten([1, [2], 3])", '{"a":1}', "[\n    1,\n    2,\n    3\n]\n"),
        ("flatten([[]])", '{"a":1}', "[]\n"),
        ("flatten([])", '{"a":1}', "[]\n"),
        ("flatten()", "[[1, 2], [3]]", "[\n    1,\n    2,\n    3\n]\n"),
    ],
)
def test_flatten_one_level(run_dasel, query, stdin_text, stdout):
    """flatten removes exactly one level of nesting, mixing in scalars."""
    # CATCHES: [[1,[2]],[3]] keeps the inner [2] nested (one level only)
    # and bare elements between arrays are passed through unchanged.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_flatten_type_error(run_dasel):
    """flatten of a scalar names its type."""
    # CATCHES: flatten's wording is "flatten expects an array, got int" -
    # "array" here, though reverse said "slice".
    proc = run_dasel(["-i", "json", "flatten(5)"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "flatten": flatten expects an array, '
        "got int\n"
    )


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("unique([1, 2, 1, 3, 2])", '{"a":1}', "[\n    1,\n    2,\n    3\n]\n"),
        ("unique()", '["a", "b", "a"]', '[\n    "a",\n    "b"\n]\n'),
        ("unique([1, \"a\", 1])", '{"a":1}', '[\n    1,\n    "a"\n]\n'),
        ("unique([1, 1.0])", '{"a":1}', "[\n    1,\n    1\n]\n"),
        ("unique([{\"a\": 1}, {\"a\": 1}, {\"b\": 2}])", '{"a":1}', "[\n    {\n        \"a\": 1\n    },\n    {\n        \"b\": 2\n    }\n]\n"),
        ("unique([])", '{"a":1}', "[]\n"),
    ],
)
def test_unique(run_dasel, query, stdin_text, stdout):
    """unique keeps first occurrences, comparing by type and value."""
    # CATCHES: 1 and 1.0 are distinct (both kept) while structurally equal
    # maps deduplicate - equality is type-and-value, not loose ==.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_unique_type_error(run_dasel):
    """unique of a scalar names its type."""
    # CATCHES: unique shares flatten's "expects an array" wording with its
    # own function name in the wrapper.
    proc = run_dasel(["-i", "json", "unique(5)"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "unique": unique expects an array, '
        "got int\n"
    )


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("first([1, 2, 3])", '{"a":1}', "1\n"),
        ("first()", '["a", "b"]', '"a"\n'),
        ("first([])", '{"a":1}', "null\n"),
        ("last([1, 2, 3])", '{"a":1}', "3\n"),
        ("last()", '["a", "b"]', '"b"\n'),
        ("last([])", '{"a":1}', "null\n"),
    ],
)
def test_first_last(run_dasel, query, stdin_text, stdout):
    """first/last return the end elements, or null for empty arrays."""
    # CATCHES: an empty array yields the JSON null value (printed "null",
    # exit 0) rather than an out-of-range error.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ("first(5)", 'error execution func "first": first expects an array, got int'),
        ("last(5)", 'error execution func "last": last expects an array, got int'),
    ],
)
def test_first_last_type_errors(run_dasel, query, stderr_fragment):
    """first/last of a scalar name their own function in the error."""
    # CATCHES: the two functions have otherwise identical wording; only the
    # embedded name distinguishes the recorded messages.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("contains(2)", "[1, 2, 3]", "true\n"),
        ("contains(9)", "[1, 2, 3]", "false\n"),
        ("contains(true)", "[true, false]", "true\n"),
        ('contains({"b": 2})', '[{"a": 1}, {"b": 2}]', "true\n"),
        ("contains([1])", "[[1], [2]]", "true\n"),
        ('contains("a")', "[1, 2]", "false\n"),
        ('contains({"a": 1})', "[1, 2]", "false\n"),
        ("contains(null)", "[1]", "false\n"),
    ],
)
def test_contains(run_dasel, query, stdin_text, stdout):
    """contains compares whole elements of the document slice by equality."""
    # CATCHES: it only looks at the DOCUMENT (never an argument list) and
    # incomparable elements (map vs int) are skipped, yielding false.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        ("contains(1)", "null", 'error execution func "contains": error getting slice length: unexpected type: expected array, got null'),
        ('contains("a")', '"abc"', 'error execution func "contains": error getting slice length: unexpected type: expected array, got string'),
        ("contains(1)", '{"a": 1}', 'error execution func "contains": error getting slice length: unexpected type: expected array, got map'),
    ],
)
def test_contains_non_slice_document(run_dasel, query, stdin_text, stderr_fragment):
    """contains requires an array document and reports what it found."""
    # CATCHES: strings, maps and null all fail the slice-length check with
    # the same wrapper but their own type name.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('has("a")', '{"a": 1}', "true\n"),
        ('has("a")', '{"a": null}', "true\n"),
        ('has("z")', '{"a": 1}', "false\n"),
        ('has("a")', "null", "false\n"),
        ("has(1)", '["x", "y"]', "true\n"),
        ("has(5)", '["x", "y"]', "false\n"),
        ("has(-1)", '["x", "y"]', "false\n"),
        ("has(1)", '{"a": 1}', "false\n"),
        ('has("a")', "[1, 2]", "false\n"),
    ],
)
def test_has(run_dasel, query, stdin_text, stdout):
    """has checks a string key on maps or an int index on slices."""
    # CATCHES: a key holding null still counts as present, negative indexes
    # are out of range, and a mismatched key/data pair is false, not error.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ("has(true)", 'error execution func "has": has expects string or int argument'),
        ("has(1.5)", 'error execution func "has": has expects string or int argument'),
    ],
)
def test_has_bad_key_type(run_dasel, query, stderr_fragment):
    """has rejects bool and float keys with one shared message."""
    # CATCHES: neither message carries a type name - the wording is fixed
    # regardless of which non-string/int key type was supplied.
    proc = run_dasel(["-i", "json", query], input_text='{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('get("a")', '{"a": 1, "b": 2}', "1\n"),
        ('get("a")', '{"a": null}', "null\n"),
        ("get(1)", '["x", "y"]', '"y"\n'),
        ("get(0)", '[["ab"]]', '[\n    "ab"\n]\n'),
    ],
)
def test_get(run_dasel, query, stdin_text, stdout):
    """get reads a map key or slice index from the document."""
    # CATCHES: get always reads from $this (the argument is the key), and
    # missing-but-present null values print as null with exit 0.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        ('get("z")', '{"a": 1}', 'error execution func "get": map key not found: "z"'),
        ("get(5)", '["x", "y"]', 'error execution func "get": slice index out of range: 5'),
        ("get(0)", "[]", 'error execution func "get": slice index out of range: 0'),
        ("get(true)", '{"a": 1}', 'error execution func "get": get expects string or int argument'),
        ("get(1.5)", "[1, 2]", 'error execution func "get": get expects string or int argument'),
        ('get("a")', "null", 'error execution func "get": unexpected type: expected map, got null'),
        ('get("a")', '"hello"', 'error execution func "get": unexpected type: expected map, got string'),
    ],
)
def test_get_errors(run_dasel, query, stdin_text, stderr_fragment):
    """get reports missing keys, out-of-range indexes and bad key types."""
    # CATCHES: a string key against a string/null document still tries the
    # map path and fails on the document type, while bool/float keys fail
    # the key check first.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ('merge({"a": 1}, {"b": 2})', '{\n    "a": 1,\n    "b": 2\n}\n'),
        ('merge({"b": 1}, {"a": 2})', '{\n    "b": 1,\n    "a": 2\n}\n'),
        ('merge({"a": 1}, {"a": 2})', '{\n    "a": 2\n}\n'),
        ('merge({"a": 1}, {"b": 2}, {"a": 3, "c": 4})', '{\n    "a": 3,\n    "b": 2,\n    "c": 4\n}\n'),
        ('merge({"a": {"x": 1, "y": 2}}, {"a": {"y": 3, "z": 4}})', '{\n    "a": {\n        "x": 1,\n        "y": 3,\n        "z": 4\n    }\n}\n'),
        ('merge({"a": {"x": 1}}, {"a": 5})', '{\n    "a": 5\n}\n'),
        ('merge({"a": 5}, {"a": {"x": 1}})', '{\n    "a": {\n        "x": 1\n    }\n}\n'),
        ("merge({}, {})", "{}\n"),
        ("merge($this)", '{\n    "a": 1\n}\n'),
    ],
)
def test_merge(run_dasel, query, stdout):
    """merge deep-merges maps, last write wins, order follows first seen."""
    # CATCHES: nested maps merge recursively but a scalar on either side
    # overwrites wholesale, and a single argument is returned unchanged.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        ("merge([1], [2])", '{"a":1}', 'error execution func "merge": merge expects a map, found array'),
        ('merge({"a": 1}, [2])', '{"a":1}', 'error execution func "merge": merge expects all arguments to be of the same type. expected map, got array'),
        ("merge($this, $this)", "null", 'error execution func "merge": merge expects a map, found null'),
    ],
)
def test_merge_errors(run_dasel, query, stdin_text, stderr_fragment):
    """merge refuses non-map arguments with two distinct messages."""
    # CATCHES: the first argument being wrong gives "found array"; a later
    # argument mismatching gives the longer "same type" wording.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("keys().first($this)", '{"a": 1, "b": 2}', '"a"\n'),
        ("a.keys().reverse($this)", '{"a": {"x": 1, "y": 2}}', '[\n    "y",\n    "x"\n]\n'),
        ('get("a").toUpper($this)', '{"a": "hi"}', '"HI"\n'),
        ("get(0).len($this)", '[["ab"]]', "1\n"),
        ("map(len($this))", '["ab", "cde"]', "[\n    2,\n    3\n]\n"),
        ("map(toUpper($this))", '["a", "b"]', '[\n    "A",\n    "B"\n]\n'),
        ("map(keys())", '[{"a": 1}, {"b": 1, "c": 2}]', '[\n    [\n        "a"\n    ],\n    [\n        "b",\n        "c"\n    ]\n]\n'),
        ("sortBy(len($this))", '["ccc", "a", "bb"]', '[\n    "a",\n    "bb",\n    "ccc"\n]\n'),
        ('join("-", split(",", "a,b,c"))', '{"a":1}', '"a-b-c"\n'),
        ("sum(1, len([1, 2, 3]))", '{"a":1}', "4\n"),
    ],
)
def test_function_results_compose(run_dasel, query, stdin_text, stdout):
    """Function results feed property chains, map, sortBy and other calls."""
    # CATCHES: a call's return becomes $this for the next chain element
    # (keys().first($this)), and $this inside map/sortBy is each element -
    # so keys() with no args reads the per-element document.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""
