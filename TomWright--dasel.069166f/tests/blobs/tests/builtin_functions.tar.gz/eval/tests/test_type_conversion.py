"""Tests for the conversion builtins: toString, toInt, toFloat, toBool
and typeOf.

These pin the full type matrix of each converter, Go's strconv semantics
leaking through (base prefixes, underscores, %g formatting) and the exact
wording of every conversion failure.
"""

import pytest

PREFIX = (
    "dasel: error: error executing selector: execution error when processing "
    "ast.CallExpr: error executing function: "
)


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ('toString("hi")', '"hi"\n'),
        ("toString(42)", '"42"\n'),
        ("toString(1.5)", '"1.5"\n'),
        ("toString(-1.5)", '"-1.5"\n'),
        ("toString(true)", '"true"\n'),
        ("toString(false)", '"false"\n'),
        ("toString(0.000001)", '"1e-06"\n'),
        ("toString(sum(1, 2))", '"3"\n'),
    ],
)
def test_to_string(run_dasel, query, stdout):
    """toString stringifies scalars, formatting floats with %g."""
    # CATCHES: 0.000001 becomes "1e-06" (Go %g) rather than "0.000001",
    # which distinguishes %g from %f or Python-style repr.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        ("toString({\"a\": 1})", '{"a":1}', 'error execution func "toString": cannot convert map to string'),
        ("toString([1])", '{"a":1}', 'error execution func "toString": cannot convert array to string'),
        ("toString($this)", "null", 'error execution func "toString": cannot convert null to string'),
    ],
)
def test_to_string_unsupported_types(run_dasel, query, stdin_text, stderr_fragment):
    """toString refuses maps, arrays and null, naming the source type."""
    # CATCHES: maps and arrays have no string form - the error carries the
    # internal type names "map"/"array" (not "object"/"list").
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ('toInt("42")', "42\n"),
        ('toInt("-7")', "-7\n"),
        ('toInt("0x1f")', "31\n"),
        ('toInt("010")', "8\n"),
        ('toInt("1_000")', "1000\n"),
        ("toInt(3.9)", "3\n"),
        ("toInt(-3.9)", "-3\n"),
        ("toInt(2.9)", "2\n"),
        ("toInt(true)", "1\n"),
        ("toInt(false)", "0\n"),
        ('typeOf(toInt("5"))', '"int"\n'),
    ],
)
def test_to_int(run_dasel, query, stdout):
    """toInt uses strconv.ParseInt base 0 and truncates floats toward zero."""
    # CATCHES: "0x1f" is hex (31), "010" is octal (8), "1_000" keeps its
    # underscore (1000), and -3.9 truncates to -3 (toward zero, not floor).
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ('toInt("abc")', 'error execution func "toInt": strconv.ParseInt: parsing "abc": invalid syntax'),
        ('toInt("")', 'error execution func "toInt": strconv.ParseInt: parsing "": invalid syntax'),
        ('toInt({"a": 1})', 'error execution func "toInt": cannot convert map to int'),
    ],
)
def test_to_int_errors(run_dasel, query, stderr_fragment):
    """toInt surfaces strconv errors verbatim, quoting the bad input."""
    # CATCHES: the message is Go's own "strconv.ParseInt: parsing ...:
    # invalid syntax", not a dasel-specific wording.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ('toFloat("1.5")', "1.5\n"),
        ('toFloat("1e3")', "1000\n"),
        ("toFloat(3)", "3\n"),
        ("toFloat(true)", "1\n"),
        ('typeOf(toFloat(3))', '"float"\n'),
    ],
)
def test_to_float(run_dasel, query, stdout):
    """toFloat parses exponent notation and promotes ints to floats."""
    # CATCHES: "1e3" parses as 1000 (float, printed bare) and toFloat(3)
    # is a float even though it prints as "3" - pinned by typeOf.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ('toFloat("xyz")', 'error execution func "toFloat": strconv.ParseFloat: parsing "xyz": invalid syntax'),
        ("toFloat({})", 'error execution func "toFloat": cannot convert map to float'),
    ],
)
def test_to_float_errors(run_dasel, query, stderr_fragment):
    """toFloat surfaces strconv errors verbatim and refuses maps."""
    # CATCHES: the ParseFloat message differs from toInt's ParseInt one;
    # a shared generic message would break both tests.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ('toBool("true")', "true\n"),
        ('toBool("TRUE")', "true\n"),
        ('toBool("yes")', "true\n"),
        ('toBool("Yes")', "true\n"),
        ('toBool("YES")', "true\n"),
        ('toBool("1")', "true\n"),
        ('toBool("false")', "false\n"),
        ('toBool("no")', "false\n"),
        ('toBool("No")', "false\n"),
        ('toBool("0")', "false\n"),
        ('toBool("")', "false\n"),
        ("toBool(1)", "true\n"),
        ("toBool(0)", "false\n"),
        ("toBool(0.5)", "true\n"),
        ("toBool(0.0)", "false\n"),
        ("toBool(false)", "false\n"),
    ],
)
def test_to_bool(run_dasel, query, stdout):
    """toBool accepts true/1/yes and false/0/no/empty, case-insensitively."""
    # CATCHES: the string truth table is case-folded and includes yes/no
    # and the empty string; numbers are truthy when non-zero.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_to_bool_of_null(run_dasel):
    """toBool of a null document is false, not an error."""
    # CATCHES: null is the one non-scalar type with a defined bool form;
    # maps fail but null converts cleanly to false with exit code 0.
    proc = run_dasel(["-i", "json", "toBool($this)"], input_text="null")
    assert proc.returncode == 0
    assert proc.stdout == "false\n"
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ('toBool("maybe")', 'error execution func "toBool": cannot convert string "maybe" to bool'),
        ("toBool({})", 'error execution func "toBool": cannot convert map to bool'),
    ],
)
def test_to_bool_errors(run_dasel, query, stderr_fragment):
    """Unrecognised strings and maps fail, quoting the offending string."""
    # CATCHES: the bad string is echoed inside the error with %q quoting,
    # and maps have no bool form at all.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ("typeOf(1)", '{"a":1}', '"int"\n'),
        ("typeOf(1.5)", '{"a":1}', '"float"\n'),
        ('typeOf("a")', '{"a":1}', '"string"\n'),
        ("typeOf(true)", '{"a":1}', '"bool"\n'),
        ("typeOf({})", '{"a":1}', '"map"\n'),
        ("typeOf([])", '{"a":1}', '"array"\n'),
        ("typeOf($this)", "null", '"null"\n'),
        ("typeOf($this)", "[1]", '"array"\n'),
    ],
)
def test_type_of_names(run_dasel, query, stdin_text, stdout):
    """typeOf reports dasel's internal type names for every JSON type."""
    # CATCHES: the names are int/float/string/bool/map/array/null - a
    # re-implementation saying "object", "list" or "number" fails.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""
