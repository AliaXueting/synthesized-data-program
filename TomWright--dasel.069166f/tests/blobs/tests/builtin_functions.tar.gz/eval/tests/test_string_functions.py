"""Tests for the string builtins: toLower, toUpper, trim, trimPrefix,
trimSuffix, startsWith, endsWith, indexOf, split, join, replace, base64e
and base64d.

Most of these accept either (input, pattern) as two arguments or just the
pattern, reading the input from the current document - both forms are
pinned, along with the exact type-error messages and separator handling.
"""

import pytest

PREFIX = (
    "dasel: error: error executing selector: execution error when processing "
    "ast.CallExpr: error executing function: "
)


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('toLower("HeLLo")', '{"a":1}', '"hello"\n'),
        ('toLower()', '"HeLLo"', '"hello"\n'),
        ('toUpper("HeLLo")', '{"a":1}', '"HELLO"\n'),
        ('toUpper()', '"HeLLo"', '"HELLO"\n'),
        ('trim("  hi  ")', '{"a":1}', '"hi"\n'),
        ('trim()', ' "\\t hi \\n" ', '"hi"\n'),
        ('trim("\\n\\t hi \\r\\n")', '{"a":1}', '"hi"\n'),
    ],
)
def test_case_and_whitespace(run_dasel, query, stdin_text, stdout):
    """toLower/toUpper/trim work on an argument or on the document."""
    # CATCHES: the no-argument forms read $this, so trim() on a string
    # document trims it; the argument forms ignore the document entirely.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ("toLower(5)", 'error execution func "toLower": toLower expects a string argument: unexpected type: expected string, got int'),
        ("toUpper(5)", 'error execution func "toUpper": toUpper expects a string argument: unexpected type: expected string, got int'),
        ("trim(5)", 'error execution func "trim": trim expects a string argument: unexpected type: expected string, got int'),
    ],
)
def test_case_and_whitespace_type_errors(run_dasel, query, stderr_fragment):
    """Each case/trim function names itself in its type error."""
    # CATCHES: the message embeds the function's own name ("toLower expects
    # a string argument"), so the three are not interchangeable.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('trimPrefix("hello", "he")', '{"a":1}', '"llo"\n'),
        ('trimPrefix("he")', '"hello"', '"llo"\n'),
        ('trimPrefix("hello", "x")', '{"a":1}', '"hello"\n'),
        ('trimPrefix("aaa", "a")', '{"a":1}', '"aa"\n'),
        ('trimSuffix("hello", "lo")', '{"a":1}', '"hel"\n'),
        ('trimSuffix("lo")', '"hello"', '"hel"\n'),
    ],
)
def test_trim_prefix_suffix(run_dasel, query, stdin_text, stdout):
    """trimPrefix/trimSuffix cut one occurrence from the chosen end."""
    # CATCHES: only a single leading/trailing occurrence is removed
    # ("aaa" -> "aa") and a non-matching cutter leaves the string alone.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_trim_prefix_type_error(run_dasel):
    """trimPrefix with a non-string first argument fails on that argument."""
    # CATCHES: with two arguments the FIRST is the input, so the error names
    # "first argument" even though the document is unused.
    proc = run_dasel(["-i", "json", 'trimPrefix(1, "a")'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "trimPrefix": trimPrefix expects a '
        "string as the first argument: unexpected type: expected string, got "
        "int\n"
    )


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('startsWith("hello", "he")', '{"a":1}', "true\n"),
        ('startsWith("he")', '"hello"', "true\n"),
        ('startsWith("hello", "x")', '{"a":1}', "false\n"),
        ('endsWith("hello", "lo")', '{"a":1}', "true\n"),
        ('endsWith("lo")', '"hello"', "true\n"),
        ('endsWith("hello", "")', '{"a":1}', "true\n"),
    ],
)
def test_starts_ends_with(run_dasel, query, stdin_text, stdout):
    """startsWith/endsWith return bare booleans in both argument forms."""
    # CATCHES: an empty suffix matches everything (true) while a mismatched
    # prefix is a clean false, not an error.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_starts_with_type_error(run_dasel):
    """startsWith with a non-string first argument names that position."""
    # CATCHES: like trimPrefix, the two-argument form validates arg 0 as the
    # input string before looking at the prefix.
    proc = run_dasel(["-i", "json", 'startsWith(1, "a")'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "startsWith": startsWith expects a '
        "string as the first argument: unexpected type: expected string, got "
        "int\n"
    )


def test_ends_with_type_error(run_dasel):
    """endsWith with a non-string first argument names that position."""
    # CATCHES: endsWith has its own copy of the message ("endsWith expects
    # a string as the first argument"), not startsWith's.
    proc = run_dasel(["-i", "json", 'endsWith(1, "a")'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "endsWith": endsWith expects a '
        "string as the first argument: unexpected type: expected string, got "
        "int\n"
    )


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('indexOf("hello", "l")', '{"a":1}', "2\n"),
        ('indexOf("l")', '"hello"', "2\n"),
        ('indexOf("abcabc", "b")', '{"a":1}', "1\n"),
        ('indexOf("hello", "z")', '{"a":1}', "-1\n"),
        ('indexOf("hello", "")', '{"a":1}', "0\n"),
        ('typeOf(indexOf("a", "b"))', '{"a":1}', '"int"\n'),
    ],
)
def test_index_of(run_dasel, query, stdin_text, stdout):
    """indexOf returns the first byte offset, or -1 when absent."""
    # CATCHES: a missing substring gives -1 (not an error or null) and an
    # empty needle gives 0; the result is an int.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_index_of_non_string_data(run_dasel):
    """The one-argument form requires the document itself to be a string."""
    # CATCHES: with one argument the input comes from $this, so a number
    # document fails with "data to be a string", a different wording from
    # the argument-position errors.
    proc = run_dasel(["-i", "json", 'indexOf("a")'], input_text="5")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "indexOf": indexOf expects data to '
        "be a string: unexpected type: expected string, got int\n"
    )


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('split(",", "a,b,c")', '{"a":1}', '[\n    "a",\n    "b",\n    "c"\n]\n'),
        ('split(",")', '"a,b,c"', '[\n    "a",\n    "b",\n    "c"\n]\n'),
        ('split("::", "a::b")', '{"a":1}', '[\n    "a",\n    "b"\n]\n'),
        ('split("", "ab")', '{"a":1}', '[\n    "a",\n    "b"\n]\n'),
        ('split(",", "abc")', '{"a":1}', '[\n    "abc"\n]\n'),
        ('split(",", "")', '{"a":1}', '[\n    ""\n]\n'),
    ],
)
def test_split(run_dasel, query, stdin_text, stdout):
    """split takes the separator FIRST and the input second (or from $this)."""
    # CATCHES: the argument order is (separator, input) - split(",", "a,b")
    # splits on commas - and an empty separator splits between every byte.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        (
            "split(\",\", 5)",
            '{"a":1}',
            'error execution func "split": split expects a string as the second argument: '
            "unexpected type: expected string, got int",
        ),
        (
            "split(\",\")",
            '{"a":1}',
            'error execution func "split": split expects data to be a string: '
            "unexpected type: expected string, got map",
        ),
    ],
)
def test_split_type_errors(run_dasel, query, stdin_text, stderr_fragment):
    """split distinguishes a bad second argument from bad document data."""
    # CATCHES: the two failure paths have different wording ("second
    # argument" vs "data"), and the map type name appears verbatim.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('join("-", "a", "b", "c")', '{"a":1}', '"a-b-c"\n'),
        ('join(",", ["a", "b"])', '{"a":1}', '"a,b"\n'),
        ('join("-", "a")', '{"a":1}', '"a"\n'),
        ('join("", "a", "b")', '{"a":1}', '"ab"\n'),
        ('join("")', '["a", "b"]', '"ab"\n'),
        ('join("-")', '[]', '""\n'),
        ('join("-", ["a", "b"]...)', '{"a":1}', '"a-b"\n'),
    ],
)
def test_join(run_dasel, query, stdin_text, stdout):
    """join accepts scalars, one slice, or the document slice, then spreads."""
    # CATCHES: exactly one unspread slice argument is joined element-wise,
    # while a spread slice flattens to scalars joined like plain arguments;
    # an empty document gives "".
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stderr_fragment"),
    [
        (
            'join("-", 1, 2)',
            '{"a":1}',
            'error execution func "join": could not read string value of argument index 1: '
            "unexpected type: expected string, got int",
        ),
        (
            'join(1, "a")',
            '{"a":1}',
            'error execution func "join": join expects a string separator as the first argument: '
            "unexpected type: expected string, got int",
        ),
        (
            'join("-")',
            "[1, 2, 3]",
            'error execution func "join": could not read string value of index 0: '
            "unexpected type: expected string, got int",
        ),
        (
            'join("-")',
            '{"a": 1}',
            'error execution func "join": error getting slice length: '
            "unexpected type: expected array, got map",
        ),
    ],
)
def test_join_type_errors(run_dasel, query, stdin_text, stderr_fragment):
    """join's three failure paths each name where the string was expected."""
    # CATCHES: argument index 1, the separator, the element at index 0 and
    # the slice-length check each produce distinct recorded wording.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('replace("hello world", "o", "0")', '{"a":1}', '"hell0 w0rld"\n'),
        ('replace("a-b-c", "-", "+", "a", "A")', '{"a":1}', '"A+b+c"\n'),
        ('replace("ab", "", "X")', '{"a":1}', '"XaXbX"\n'),
        ('replace("a", "b", "c")', '{"a":1}', '"a"\n'),
    ],
)
def test_replace_arguments(run_dasel, query, stdin_text, stdout):
    """replace takes (input, old, new) pairs and replaces all occurrences."""
    # CATCHES: with an odd count the FIRST argument is the input and the
    # rest are pairs; an empty old-string inserts between every byte.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('replace("o", "0")', '"hello world"', '"hell0 w0rld"\n'),
        ('replace("-", "+", "b", "B")', '"a-b-c"', '"a+B+c"\n'),
    ],
)
def test_replace_uses_data_with_even_arguments(run_dasel, query, stdin_text, stdout):
    """With an even argument count the document is the input string."""
    # CATCHES: only odd counts promote arg 0 to input; even counts read
    # $this, so the same "hello world" gets rewritten either way.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_replace_non_string_data(run_dasel):
    """replace on a non-string document fails with the model error."""
    # CATCHES: the document path has no chatty wrapper, just the raw
    # "expected string, got int" from reading the input value.
    proc = run_dasel(["-i", "json", 'replace("a", "b")'], input_text="5")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "replace": unexpected type: expected '
        "string, got int\n"
    )


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ('base64e("hello")', '"aGVsbG8="\n'),
        ('base64e("")', '""\n'),
        ('base64d("aGVsbG8=")', '"hello"\n'),
        ('base64d(base64e("round trip"))', '"round trip"\n'),
    ],
)
def test_base64_round_trips(run_dasel, query, stdout):
    """base64e/base64d use standard padded encoding and compose."""
    # CATCHES: the encoding is StdEncoding (padded "="), and decode applied
    # to encode returns the original string inside one query.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_base64_encode_non_ascii_literal(run_dasel):
    """base64e encodes the selector literal's bytes exactly as the reference does."""
    # CATCHES: the reference lexes non-ASCII literals byte-wise (e' becomes
    # two runes), so base64e("héllo") encodes the doubled bytes - recorded
    # verbatim as aMOp-style mojibake, not proper UTF-8 of "héllo".
    proc = run_dasel(["-i", "json", 'base64e("héllo")'])
    assert proc.returncode == 0
    assert proc.stdout == '"aMODwqlsbG8="\n'
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ('base64d("!!!")', 'error execution func "base64d": illegal base64 data at input byte 0'),
        ('base64d("aGVsbG8")', 'error execution func "base64d": illegal base64 data at input byte 4'),
        ("base64d(5)", 'error execution func "base64d": unexpected type: expected string, got int'),
        ("base64e(5)", 'error execution func "base64e": unexpected type: expected string, got int'),
    ],
)
def test_base64_errors(run_dasel, query, stderr_fragment):
    """Invalid base64 and non-string inputs fail with recorded offsets."""
    # CATCHES: unpadded input fails at byte 4 (the missing padding site)
    # while garbage fails at byte 0; both wrap the encoding error verbatim.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"
