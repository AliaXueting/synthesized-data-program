"""Tests for the function call machinery around the builtin library.

These pin how a call is executed: the four arity validator messages, the
unknown-function error, the --unstable gate on `ignore`, left-to-right
argument evaluation with its index-tagged error wrapper, spread inside an
argument list, and the `error execution func %q` runtime wrap.
"""

import pytest

# Every arity / runtime failure surfaces on stderr with this shared prefix:
# the selector executor wraps the CallExpr, which wraps the function call.
PREFIX = (
    "dasel: error: error executing selector: execution error when processing "
    "ast.CallExpr: error executing function: "
)

# (query, message after the shared prefix) for ValidateArgsExactly.
EXACTLY_CASES = [
    ("len()", 'func "len" expects exactly 1 arguments, got 0'),
    ("len(1, 2)", 'func "len" expects exactly 1 arguments, got 2'),
    ("len(1, 2, 3)", 'func "len" expects exactly 1 arguments, got 3'),
    ("keys(1)", 'func "keys" expects exactly 0 arguments, got 1'),
    ("values(1)", 'func "values" expects exactly 0 arguments, got 1'),
    ("entries(1)", 'func "entries" expects exactly 0 arguments, got 1'),
    ("contains()", 'func "contains" expects exactly 1 arguments, got 0'),
    ("contains(1, 2)", 'func "contains" expects exactly 1 arguments, got 2'),
    ("reverse()", 'func "reverse" expects exactly 1 arguments, got 0'),
    ("reverse(1, 2)", 'func "reverse" expects exactly 1 arguments, got 2'),
    ("toString()", 'func "toString" expects exactly 1 arguments, got 0'),
    ("toString(1, 2)", 'func "toString" expects exactly 1 arguments, got 2'),
    ("toInt(1, 2)", 'func "toInt" expects exactly 1 arguments, got 2'),
    ("toFloat(1, 2)", 'func "toFloat" expects exactly 1 arguments, got 2'),
    ("typeOf()", 'func "typeOf" expects exactly 1 arguments, got 0'),
    ("typeOf(1, 2)", 'func "typeOf" expects exactly 1 arguments, got 2'),
    ("get()", 'func "get" expects exactly 1 arguments, got 0'),
    ("get(1, 2)", 'func "get" expects exactly 1 arguments, got 2'),
    ('parse("json")', 'func "parse" expects exactly 2 arguments, got 1'),
    ('parse("json", "1", "2")', 'func "parse" expects exactly 2 arguments, got 3'),
    ("readFile()", 'func "readFile" expects exactly 1 arguments, got 0'),
    ('readFile("a", "b")', 'func "readFile" expects exactly 1 arguments, got 2'),
    ("base64e()", 'func "base64e" expects exactly 1 arguments, got 0'),
    ('base64d("a", "b")', 'func "base64d" expects exactly 1 arguments, got 2'),
    ("toBool()", 'func "toBool" expects exactly 1 arguments, got 0'),
    ("toBool(1, 2)", 'func "toBool" expects exactly 1 arguments, got 2'),
    ('ignore(1)', 'func "ignore" expects exactly 0 arguments, got 1'),
]

# (query, message after the shared prefix) for ValidateArgsMin.
MIN_CASES = [
    ("add()", 'func "add" expects at least 1 arguments, got 0'),
    ("sum()", 'func "sum" expects at least 1 arguments, got 0'),
    ("avg()", 'func "avg" expects at least 1 arguments, got 0'),
    ("max()", 'func "max" expects at least 1 arguments, got 0'),
    ("min()", 'func "min" expects at least 1 arguments, got 0'),
    ("merge()", 'func "merge" expects at least 1 arguments, got 0'),
    ("join()", 'func "join" expects at least 1 arguments, got 0'),
    ("has()", 'func "has" expects at least 1 arguments, got 0'),
    ("replace()", 'func "replace" expects at least 2 arguments, got 0'),
    ('replace("a")', 'func "replace" expects at least 2 arguments, got 1'),
]

# (query, message after the shared prefix) for ValidateArgsMax.
MAX_CASES = [
    ('toLower("A", "B")', 'func "toLower" expects no more than 1 arguments, got 2'),
    ('toUpper("A", "B")', 'func "toUpper" expects no more than 1 arguments, got 2'),
    ('trim("A", "B")', 'func "trim" expects no more than 1 arguments, got 2'),
    ("abs(1, 2)", 'func "abs" expects no more than 1 arguments, got 2'),
    ("floor(1, 2)", 'func "floor" expects no more than 1 arguments, got 2'),
    ("ceil(1, 2)", 'func "ceil" expects no more than 1 arguments, got 2'),
    ("round(1, 2)", 'func "round" expects no more than 1 arguments, got 2'),
    ("flatten(1, 2)", 'func "flatten" expects no more than 1 arguments, got 2'),
    ("unique(1, 2)", 'func "unique" expects no more than 1 arguments, got 2'),
    ("first(1, 2)", 'func "first" expects no more than 1 arguments, got 2'),
    ("last(1, 2)", 'func "last" expects no more than 1 arguments, got 2'),
    ("fromEntries(1, 2)", 'func "fromEntries" expects no more than 1 arguments, got 2'),
]

# (query, message after the shared prefix) for ValidateArgsMinMax.
BETWEEN_CASES = [
    ("split()", 'func "split" expects between 1 and 2 arguments, got 0'),
    ('split(",", "a", "b")', 'func "split" expects between 1 and 2 arguments, got 3'),
    ("trimPrefix()", 'func "trimPrefix" expects between 1 and 2 arguments, got 0'),
    ('trimPrefix("a", "b", "c")', 'func "trimPrefix" expects between 1 and 2 arguments, got 3'),
    ("trimSuffix()", 'func "trimSuffix" expects between 1 and 2 arguments, got 0'),
    ('trimSuffix("a", "b", "c")', 'func "trimSuffix" expects between 1 and 2 arguments, got 3'),
    ("startsWith()", 'func "startsWith" expects between 1 and 2 arguments, got 0'),
    ('startsWith("a", "b", "c")', 'func "startsWith" expects between 1 and 2 arguments, got 3'),
    ("endsWith()", 'func "endsWith" expects between 1 and 2 arguments, got 0'),
    ('endsWith("a", "b", "c")', 'func "endsWith" expects between 1 and 2 arguments, got 3'),
    ("indexOf()", 'func "indexOf" expects between 1 and 2 arguments, got 0'),
    ('indexOf("a", "b", "c")', 'func "indexOf" expects between 1 and 2 arguments, got 3'),
    ("stringify()", 'func "stringify" expects between 1 and 2 arguments, got 0'),
    ('stringify("json", $this, 1)', 'func "stringify" expects between 1 and 2 arguments, got 3'),
]


@pytest.mark.parametrize(("query", "fragment"), EXACTLY_CASES)
def test_arity_exactly_message(run_dasel, query, fragment):
    """ValidateArgsExactly reports func name, expected and actual counts."""
    # CATCHES: the message reads "expects exactly 1 arguments" (plural even
    # for 1) and names the function in quotes; the wrong count or a
    # singularised message would break the exact stderr comparison.
    extra = ["--unstable"] if query.startswith("ignore") else []
    proc = run_dasel(["-i", "json", *extra, query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + fragment + "\n"


@pytest.mark.parametrize(("query", "fragment"), MIN_CASES)
def test_arity_min_message(run_dasel, query, fragment):
    """ValidateArgsMin reports the minimum argument count required."""
    # CATCHES: min-style validators say "at least N arguments"; using the
    # exactly/max wording or the wrong N for replace (2) changes the text.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + fragment + "\n"


@pytest.mark.parametrize(("query", "fragment"), MAX_CASES)
def test_arity_max_message(run_dasel, query, fragment):
    """ValidateArgsMax reports the maximum argument count allowed."""
    # CATCHES: max-style validators say "no more than N arguments"; a
    # re-implementation that phrases this differently or off-by-one fails.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + fragment + "\n"


@pytest.mark.parametrize(("query", "fragment"), BETWEEN_CASES)
def test_arity_between_message(run_dasel, query, fragment):
    """ValidateArgsMinMax reports both the lower and the upper bound."""
    # CATCHES: the message carries two numbers ("between 1 and 2"); the
    # bounds differ per function, so each row pins its own pair.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + fragment + "\n"


def test_unknown_function_error(run_dasel):
    """An unregistered name fails before execution with unknown function."""
    # CATCHES: this error is NOT wrapped in the CallExpr/runtime prefixes -
    # it surfaces as "error evaluating expression ast.CallExpr" directly,
    # which only happens for construction-time failures.
    proc = run_dasel(["-i", "json", "unknownFn(1)"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: error evaluating expression '
        'ast.CallExpr: unknown function: "unknownFn"\n'
    )


def test_function_names_are_case_sensitive(run_dasel):
    """LEN is not len: function lookup is case sensitive."""
    # CATCHES: a lookup that folded case would find len and print 2 instead
    # of the recorded unknown-function error naming "LEN".
    proc = run_dasel(["-i", "json", 'LEN(1)'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: error evaluating expression '
        'ast.CallExpr: unknown function: "LEN"\n'
    )


def test_unknown_function_with_underscore(run_dasel):
    """A plausible but unregistered name is still unknown."""
    # CATCHES: underscores are legal in the call token, so the name must be
    # reported verbatim inside the quoted unknown-function message.
    proc = run_dasel(["-i", "json", "foo_bar()"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: error evaluating expression '
        'ast.CallExpr: unknown function: "foo_bar"\n'
    )


def test_ignore_gated_behind_unstable_flag(run_dasel):
    """ignore() without --unstable is rejected with the unstable message."""
    # CATCHES: the gate fires before arity or execution and, like the
    # unknown-function error, skips the CallExpr runtime prefixes.
    proc = run_dasel(["-i", "json", "ignore()"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: error evaluating expression "
        "ast.CallExpr: unstable function are not enabled. to enable them use "
        "--unstable\n"
    )


def test_ignore_gated_inside_if_block(run_dasel):
    """The unstable gate also fires for ignore nested in an if block."""
    # CATCHES: the gate is applied wherever the CallExpr sits in the AST, so
    # the message arrives wrapped by the conditional's "error executing
    # then block" context rather than the plain call prefix.
    proc = run_dasel(["-i", "json", "if (true) { ignore() }"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ConditionalExpr: error executing then block: error "
        "evaluating expression ast.CallExpr: unstable function are not "
        "enabled. to enable them use --unstable\n"
    )


def test_ignore_gated_when_used_as_argument(run_dasel):
    """The unstable gate fires while evaluating another call's argument."""
    # CATCHES: the argument-position failure keeps the "error preparing
    # arguments: error evaluating argument 0" wrapper around the gate text.
    proc = run_dasel(["-i", "json", "toString(ignore())"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.CallExpr: error preparing arguments: error evaluating "
        "argument 0: error evaluating expression ast.CallExpr: unstable "
        "function are not enabled. to enable them use --unstable\n"
    )


def test_ignore_with_unstable_returns_data(run_dasel):
    """With --unstable, ignore() echoes the current value unchanged."""
    # CATCHES: ignore marks the value but on a non-branch input the document
    # is still printed verbatim, byte for byte, with exit code 0.
    proc = run_dasel(["--unstable", "-i", "json", "ignore()"])
    assert proc.returncode == 0
    assert proc.stdout == '{\n    "a": 1\n}\n'
    assert proc.stderr == ""


def test_arguments_evaluated_left_to_right(run_dasel):
    """When two arguments both fail, the left one's error is reported."""
    # CATCHES: argument preparation runs strictly left to right; a
    # right-to-left or parallel evaluator would surface toFloat's error.
    proc = run_dasel(["-i", "json", 'add(toInt("x"), toFloat("y"))'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: execution error when '
        'processing ast.CallExpr: error preparing arguments: error evaluating '
        'argument 0: execution error when processing ast.CallExpr: error '
        'executing function: error execution func "toInt": '
        'strconv.ParseInt: parsing "x": invalid syntax\n'
    )


def test_arguments_evaluated_left_to_right_swapped(run_dasel):
    """Swapping the failing arguments swaps which error is reported."""
    # CATCHES: with toFloat first, its ParseFloat error wins - proving the
    # order is positional, not sorted by function or error kind.
    proc = run_dasel(["-i", "json", 'add(toFloat("y"), toInt("x"))'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: execution error when '
        'processing ast.CallExpr: error preparing arguments: error evaluating '
        'argument 0: execution error when processing ast.CallExpr: error '
        'executing function: error execution func "toFloat": '
        'strconv.ParseFloat: parsing "y": invalid syntax\n'
    )


def test_argument_error_reports_argument_index(run_dasel):
    """A failing argument is reported with its 0-based position."""
    # CATCHES: the wrapper names "argument 1" for the second argument; an
    # implementation using 1-based indexing or the wrong slot breaks this.
    proc = run_dasel(["-i", "json", "sum(1, len(2))"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: execution error when '
        'processing ast.CallExpr: error preparing arguments: error evaluating '
        'argument 1: execution error when processing ast.CallExpr: error '
        'executing function: error execution func "len": unexpected type: '
        'expected [array map string], got int\n'
    )


def test_runtime_error_wrapped_with_function_name(run_dasel):
    """A handler failure is wrapped as error execution func %q."""
    # CATCHES: the wrap names the function ("len") even though the inner
    # error ("unexpected type: expected [array map string], got int") comes
    # from the model layer and does not mention it.
    proc = run_dasel(["-i", "json", "len(5)"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: execution error when '
        'processing ast.CallExpr: error executing function: error execution '
        'func "len": unexpected type: expected [array map string], got int\n'
    )


def test_spread_flattens_slice_into_arguments(run_dasel):
    """A postfix spread flattens a slice literal into separate arguments."""
    # CATCHES: sum must receive three ints (result 6), not one array; a
    # missing spread would fail with "cannot sum non-numeric value of type
    # array" instead.
    proc = run_dasel(["-i", "json", "sum([1, 2, 3]...)"])
    assert proc.returncode == 0
    assert proc.stdout == "6\n"
    assert proc.stderr == ""


def test_spread_of_current_value(run_dasel):
    """$this... spreads the input slice into the argument list."""
    # CATCHES: the chain $this... marks the evaluated slice as spread, so
    # sum sees 1,2,3 as three arguments and prints 6.
    proc = run_dasel(["-i", "json", "sum($this...)"], input_text="[1, 2, 3]")
    assert proc.returncode == 0
    assert proc.stdout == "6\n"
    assert proc.stderr == ""


def test_spread_between_plain_arguments(run_dasel):
    """A spread argument can sit between plain arguments."""
    # CATCHES: flattening is positional - 1, then 2, 3 from the spread, then
    # 4 - so the total is 10 rather than a concatenation or an error.
    proc = run_dasel(["-i", "json", "sum(1, [2, 3]..., 4)"])
    assert proc.returncode == 0
    assert proc.stdout == "10\n"
    assert proc.stderr == ""


def test_spread_of_map_spreads_values(run_dasel):
    """Spreading a map flattens to its values, in key order."""
    # CATCHES: map spread yields the values (1 then 2), not the keys or
    # key/value pairs, so the sum is 3.
    proc = run_dasel(["-i", "json", "sum($this...)"], input_text='{"a": 1, "b": 2}')
    assert proc.returncode == 0
    assert proc.stdout == "3\n"
    assert proc.stderr == ""


def test_spread_on_scalar_fails(run_dasel):
    """Spreading a non-slice/non-map value errors with its type name."""
    # CATCHES: the error comes from the SpreadExpr executor ("cannot spread
    # on type string") wrapped in the argument-0 preparation context.
    proc = run_dasel(["-i", "json", "sum($this...)"], input_text='"ab"')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.CallExpr: error preparing arguments: error evaluating "
        "argument 0: execution error when processing ast.ChainedExpr: error "
        "executing expression: execution error when processing "
        "ast.SpreadExpr: cannot spread on type string\n"
    )


def test_spread_feeds_arity_validator(run_dasel):
    """A spread counts as its flattened length for arity validation."""
    # CATCHES: len receives two arguments after the spread, so the exactly-1
    # validator reports "got 2" - proving flattening happens first.
    proc = run_dasel(["-i", "json", "len($this...)"], input_text="[1, 2]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: execution error when '
        'processing ast.CallExpr: error executing function: func "len" '
        'expects exactly 1 arguments, got 2\n'
    )


def test_trailing_comma_in_argument_list(run_dasel):
    """A trailing comma after the last argument is tolerated."""
    # CATCHES: the parser drops the empty slot, so sum(1,) is sum(1) and
    # prints 1 rather than failing arity or parsing.
    proc = run_dasel(["-i", "json", "sum(1,)"])
    assert proc.returncode == 0
    assert proc.stdout == "1\n"
    assert proc.stderr == ""


def test_success_writes_stdout_only(run_dasel):
    """A successful call prints the JSON result to stdout, nothing else."""
    # CATCHES: scalars print bare (5) with a trailing newline and stderr
    # stays empty; any diagnostics on success would break the comparison.
    proc = run_dasel(["-i", "json", "abs(-5)"])
    assert proc.returncode == 0
    assert proc.stdout == "5\n"
    assert proc.stderr == ""


def test_empty_stdin_means_null_data(run_dasel):
    """With no stdin the queried value is null, not an error."""
    # CATCHES: dasel defaults the document to null when stdin is empty, so
    # typeOf answers "null" instead of failing to read input.
    proc = run_dasel(["-i", "json", "typeOf($this)"], input_text="")
    assert proc.returncode == 0
    assert proc.stdout == '"null"\n'
    assert proc.stderr == ""
