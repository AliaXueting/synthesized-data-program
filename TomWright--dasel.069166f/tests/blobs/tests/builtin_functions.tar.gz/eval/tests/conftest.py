"""Shared helpers for the builtin_functions test module.

The program under test is dasel v3.  These tests pin its built-in function
library - the 45 functions callable inside a selector - and the call
machinery around them: argument evaluation, spread in argument lists,
arity validation messages, the unstable function gate, and how results
compose with the rest of a query.
"""

import functools
import os
import subprocess
import tempfile
from pathlib import Path

import pytest


@functools.lru_cache(maxsize=None)
def _writes_counters(binary):
    """True if 'binary' is a Go coverage build (it drops covcounters files).

    Probed by running a trivial query once against a throwaway GOCOVERDIR,
    so the check never touches the real counter directory.
    """
    with tempfile.TemporaryDirectory(prefix="dasel-covprobe-") as probe_dir:
        env = {"PATH": "/usr/bin:/bin", "GOCOVERDIR": probe_dir}
        try:
            subprocess.run(
                [binary, "-i", "json", "len([])"],
                input=b"{}\n",
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError):
            return False
        return any(Path(probe_dir).glob("covcounters.*"))


def _dasel_bin():
    """Resolve the reference binary through PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the dasel binary under test"
        )
    # The pipeline's coverage driver points PROGRAMGYM_EXECUTABLE at a
    # coverage-instrumented build of the reference and sets GOCOVERDIR, but
    # the pipeline-managed eval/run.sh force-resets PROGRAMGYM_EXECUTABLE to
    # this module's uninstrumented copy before pytest starts, so the counters
    # would never be written and this module's coverage report would stay
    # empty.  During a coverage run (GOCOVERDIR present), when the assigned
    # binary is not itself instrumented, fall back to the instrumented build
    # the driver stages next to the module workspaces.  That file only exists
    # in the pipeline layout, so ordinary validation runs are unaffected.
    if os.environ.get("GOCOVERDIR") and not _writes_counters(path):
        staged = Path(__file__).resolve().parents[2].parent / "executable.cov"
        if _writes_counters(str(staged)):
            return str(staged)
    return path


# Pinned child environment: no network, no locale or color surprises.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "dumb",
}


def _child_env():
    """The pinned child environment plus the coverage forwarding vars."""
    env = dict(CHILD_ENV)
    # The pipeline measures source coverage of the reference binary through
    # GOCOVERDIR; forward it when the test process itself was started with
    # it so an instrumented binary can write its covermeta files.  Read at
    # call time so a per-test override is honored too.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    return env


def _invoke(args, input_text, cwd, timeout):
    """Spawn dasel with the given argv and capture both output streams."""
    return subprocess.run(
        [_dasel_bin(), *args],
        input=input_text,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=cwd,
        env=_child_env(),
        timeout=timeout,
    )


def run_dasel(args, input_text='{"a":1}', cwd=None, timeout=10):
    """Run dasel with the given argv and return the completed process.

    The child gets a pinned environment and, when ``cwd`` is given, runs
    inside that directory so tests can point readFile at files they create
    in their own tmp_path.  ``input_text`` is fed on stdin; dasel parses it
    with the format named by -i and it becomes $this for the query.
    """
    return _invoke(args, input_text, cwd, timeout)


@pytest.fixture(name="run_dasel")
def run_dasel_fixture(tmp_path):
    """The run_dasel helper, defaulting to an isolated empty cwd."""

    def _run(args, input_text='{"a":1}', cwd=None, timeout=10):
        return _invoke(args, input_text, cwd or str(tmp_path), timeout)

    return _run
