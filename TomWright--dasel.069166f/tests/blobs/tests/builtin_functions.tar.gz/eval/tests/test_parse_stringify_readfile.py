"""Tests for the I/O-flavoured builtins: parse, stringify, readFile and
ignore, plus how function output meets the CLI's output flags.

parse/stringify round-trip data through a named format at runtime,
readFile pulls a file's bytes in as a string, and ignore prunes branch
documents (multi-document stdin) when --unstable is on.
"""

import pytest

PREFIX = (
    "dasel: error: error executing selector: execution error when processing "
    "ast.CallExpr: error executing function: "
)


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ('parse("json", "{\\"a\\":1}")', "{\n    \"a\": 1\n}\n"),
        ('parse("yaml", "a: 1")', "{\n    \"a\": 1\n}\n"),
        ('parse("toml", "a = 1")', "{\n    \"a\": 1\n}\n"),
        ('parse("json", "5")', "5\n"),
        ('parse("yaml", "- 1\\n- 2")', "[\n    1,\n    2\n]\n"),
        ('parse("dasel", "1 + 1")', "2\n"),
        ('parse("csv", "a,b\\n1,2")', "[\n    {\n        \"a\": \"1\",\n        \"b\": \"2\"\n    }\n]\n"),
    ],
)
def test_parse_formats(run_dasel, query, stdout):
    """parse decodes a runtime string in any registered reader format."""
    # CATCHES: csv cells come back as strings, dasel-format input is
    # evaluated as an expression (1 + 1 -> 2), and the result is then
    # written by the outer -o json writer with normal indentation.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ('parse("nope", "x")', 'error execution func "parse": unsupported reader file format: nope'),
        ('parse("json", "not json")', 'error execution func "parse": json: invalid character o as null'),
        ('parse(5, "x")', 'error execution func "parse": unexpected type: expected string, got int'),
        ('parse("json", 5)', 'error execution func "parse": unexpected type: expected string, got int'),
    ],
)
def test_parse_errors(run_dasel, query, stderr_fragment):
    """parse reports unknown formats and bad content with their own text."""
    # CATCHES: an unknown format gives "unsupported reader file format"
    # while invalid JSON leaks the decoder's own "invalid character o as
    # null" wording.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


@pytest.mark.parametrize(
    ("query", "stdin_text", "stdout"),
    [
        ('stringify("json")', '{"a": 1, "b": [1, 2]}', '"{\\"a\\":1,\\"b\\":[1,2]}"\n'),
        ('stringify("json", {"a": 1})', '{"a":1}', '"{\\"a\\":1}"\n'),
        ('stringify("json", [1, 2])', '{"a":1}', '"[1,2]"\n'),
        ('stringify("json", 5)', '{"a":1}', '"5"\n'),
        ('stringify("json", "hi")', '{"a":1}', '"\\"hi\\""\n'),
        ('stringify("yaml", {"a": 1})', '{"a":1}', '"{a: 1}"\n'),
        ('stringify("yaml", {"a": {"b": 1}})', '{"a":1}', '"{a: {b: 1}}"\n'),
        ('stringify("toml", {"a": 1})', '{"a":1}', '"a = 1"\n'),
        ('stringify("json")', "5", '"5"\n'),
        ('stringify("json", {"a": "<b>&"})', '{"a":1}', '"{\\"a\\":\\"<b>&\\"}"\n'),
    ],
)
def test_stringify_formats(run_dasel, query, stdin_text, stdout):
    """stringify serialises to a compact one-line string in any format."""
    # CATCHES: output is always compact regardless of --compact, the single
    # trailing newline is trimmed, and JSON does not HTML-escape < > &.
    proc = run_dasel(["-i", "json", query], input_text=stdin_text)
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""


def test_stringify_feeds_parse_round_trip(run_dasel):
    """stringify output can be handed straight back to parse."""
    # CATCHES: the compacted string re-parses to the same document, then
    # the outer writer re-indents it - a full encode/decode round trip.
    proc = run_dasel(["-i", "json", 'parse("json", stringify("json", {"a": [1, 2]}))'])
    assert proc.returncode == 0
    assert proc.stdout == "{\n    \"a\": [\n        1,\n        2\n    ]\n}\n"
    assert proc.stderr == ""


@pytest.mark.parametrize(
    ("query", "stderr_fragment"),
    [
        ('stringify("nope", 5)', 'error execution func "stringify": unsupported writer file format: nope'),
        ('stringify(5, 1)', 'error execution func "stringify": unexpected type: expected string, got int'),
        ('stringify("xml", {"a": 1})', 'error execution func "stringify": failed to convert to element: failed to convert child element "a" to element: xml writer does not support value type: int'),
    ],
)
def test_stringify_errors(run_dasel, query, stderr_fragment):
    """stringify reports unknown formats and unsupported value types."""
    # CATCHES: the writer-side message says "writer" where parse said
    # "reader", and the xml failure names the offending child element.
    proc = run_dasel(["-i", "json", query])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + stderr_fragment + "\n"


def test_read_file_reads_relative_path(run_dasel, tmp_path):
    """readFile loads a file by path relative to the working directory."""
    # CATCHES: the whole file is returned verbatim as one string (no
    # trailing-newline trimming) and composes with len for the byte count.
    (tmp_path / "plain.txt").write_text("hello file")
    proc = run_dasel(["-i", "json", 'readFile("plain.txt")'])
    assert proc.returncode == 0
    assert proc.stdout == '"hello file"\n'
    assert proc.stderr == ""
    proc_len = run_dasel(["-i", "json", 'len(readFile("plain.txt"))'])
    assert proc_len.returncode == 0
    assert proc_len.stdout == "10\n"
    assert proc_len.stderr == ""


def test_read_file_preserves_newlines_and_parses(run_dasel, tmp_path):
    """readFile keeps interior newlines and can feed parse directly."""
    # CATCHES: multi-line content survives as a single string (JSON-escaped
    # \n), and a JSON file read this way re-parses into real data.
    (tmp_path / "lines.txt").write_text("line1\nline2\n")
    proc = run_dasel(["-i", "json", 'readFile("lines.txt")'])
    assert proc.returncode == 0
    assert proc.stdout == '"line1\\nline2\\n"\n'
    assert proc.stderr == ""
    (tmp_path / "doc.json").write_text('{"x": 1}')
    proc_parse = run_dasel(["-i", "json", 'parse("json", readFile("doc.json"))'])
    assert proc_parse.returncode == 0
    assert proc_parse.stdout == "{\n    \"x\": 1\n}\n"
    assert proc_parse.stderr == ""


def test_read_file_missing(run_dasel):
    """readFile of an absent path reports the OS error verbatim."""
    # CATCHES: the message keeps both the readFile prefix and Go's "open
    # <path>: no such file or directory" text, double-wrapped as recorded.
    # The fixture's cwd is an empty tmp_path, so the relative name cannot
    # exist and no file outside tmp_path is ever referenced.
    proc = run_dasel(["-i", "json", 'readFile("no_such_file.txt")'])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "readFile": readFile: open '
        "no_such_file.txt: no such file or directory\n"
    )


def test_read_file_type_error(run_dasel):
    """readFile requires a string path."""
    # CATCHES: a non-string argument fails on the path read, before any
    # filesystem access, with the model's type expectation.
    proc = run_dasel(["-i", "json", "readFile(5)"])
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + 'error execution func "readFile": readFile: unexpected '
        "type: expected string, got int\n"
    )


def test_ignore_drops_every_branch_document(run_dasel):
    """ignore() on multi-document stdin removes all documents from output."""
    # CATCHES: with --unstable and NDJSON input every document is marked
    # ignored, leaving an empty branch that prints nothing at all (empty
    # stdout, exit 0) rather than an empty array.
    proc = run_dasel(
        ["--unstable", "-i", "json", "ignore()"],
        input_text='{"a": 1}\n{"b": 2}\n',
    )
    assert proc.returncode == 0
    assert proc.stdout == ""
    assert proc.stderr == ""


def test_ignore_prunes_selected_branch_documents(run_dasel):
    """An if block can ignore some documents and keep the rest."""
    # CATCHES: only the matching document is dropped; the survivor is
    # printed in the normal multi-document form with a blank line between
    # documents.
    proc = run_dasel(
        ["--unstable", "-i", "json", "if (a == 1) { ignore() } else { $this }"],
        input_text='{"a": 1}\n{"a": 2}\n',
    )
    assert proc.returncode == 0
    assert proc.stdout == "{\n    \"a\": 2\n}\n"
    assert proc.stderr == ""


def test_branch_documents_apply_function_separately(run_dasel):
    """Each NDJSON document is its own $this for a function call."""
    # CATCHES: len runs per document and results are printed one per
    # document separated by a blank line ("2\n\n3\n"), not as an array.
    proc = run_dasel(["-i", "json", "len($this)"], input_text='"ab"\n"abc"')
    assert proc.returncode == 0
    assert proc.stdout == "2\n\n3\n"
    assert proc.stderr == ""


def test_branch_document_error_aborts_whole_query(run_dasel):
    """A function failing on one document fails the entire run."""
    # CATCHES: the per-document failure is wrapped with "branch execution
    # error" and nothing reaches stdout, even for the document that worked.
    proc = run_dasel(["-i", "json", "toUpper($this)"], input_text='"a"\n5\n')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: branch execution error when "
        "processing ast.CallExpr: error executing function: error execution "
        'func "toUpper": toUpper expects a string argument: unexpected type: '
        "expected string, got int\n"
    )


def test_compact_flag_flattens_function_output(run_dasel):
    """--compact prints slice results from functions on one line."""
    # CATCHES: keys() and split() emit multi-line indented JSON by default;
    # with --compact the same values become single-line arrays.
    proc = run_dasel(["--compact", "-i", "json", "keys()"], input_text='{"a": 1, "b": 2}')
    assert proc.returncode == 0
    assert proc.stdout == '["a","b"]\n'
    assert proc.stderr == ""
    proc_split = run_dasel(["--compact", "-i", "json", 'split(",", "a,b")'])
    assert proc_split.returncode == 0
    assert proc_split.stdout == '["a","b"]\n'
    assert proc_split.stderr == ""


@pytest.mark.parametrize(
    ("query", "stdout"),
    [
        ("toString(1.5)", "1.5\n"),
        ('toUpper("hi")', "HI\n"),
        ('startsWith("a", "a")', "true\n"),
        ('len("abc")', "3\n"),
    ],
)
def test_plain_output_unquotes_scalars(run_dasel, query, stdout):
    """-o plain writes scalar function results without JSON quoting."""
    # CATCHES: strings lose their quotes, booleans print bare, and the
    # trailing newline is still present for each of them.
    proc = run_dasel(["-o", "plain", "-i", "json", query])
    assert proc.returncode == 0
    assert proc.stdout == stdout
    assert proc.stderr == ""
