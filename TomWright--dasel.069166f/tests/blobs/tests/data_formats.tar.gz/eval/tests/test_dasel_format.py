"""The dasel input format (parsing/d/reader.go): the input value is itself
evaluated as a selector against a null root, which is also the default format
for --var values.
"""

import pytest

from conftest import KONG_USAGE_STDOUT, run_dasel, write_input_file


@pytest.mark.parametrize(
    "selector,expected",
    [
        ("1", "1\n"),
        ('"str"', '"str"\n'),
        ("[1,2]", "[1,2]\n"),
        ("null", "null\n"),
        ("true", "true\n"),
    ],
)
def test_reader_evaluates_selectors(selector, expected):
    """-i dasel evaluates the input bytes as a selector expression."""
    # CATCHES: the reader runs ExecuteSelector on the raw input instead of
    # parsing it as data, so literal expressions materialise values.
    res = run_dasel(["-i", "dasel", "-o", "json", "--compact"], input=selector.encode())
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == expected


def test_reader_builds_maps():
    """Map literals in the selector become real documents."""
    # CATCHES: object literal syntax round-trips through the model to json.
    res = run_dasel(
        ["-i", "dasel", "-o", "json", "--compact"], input=b'{"a": 1}'
    )
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n'


def test_reader_invalid_selector_error():
    """A non-literal selector against the null root fails with an error."""
    # CATCHES: property access on the null root is an error, wrapped by the
    # reader ("failed to read value:") and the CLI ("error reading input:").
    res = run_dasel(
        ["-i", "dasel", "-o", "json", "--compact"], input=b"bad syntax here !!!"
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: failed to read value: "
        "error executing selector: execution error "
        "when processing ast.ChainedExpr: error executing expression: "
        "execution error when processing ast.PropertyExpr: "
        "unexpected type: expected map, got null\n"
    )


def test_reader_exponent_is_not_a_float_literal():
    """The selector lexer has no exponent notation: 1e20 is 1 then .e20."""
    # CATCHES: unlike the json reader, "1e20" is not scanned as a float
    # literal — it chains the int 1 with property access "e20", which fails
    # against the int with the exact execution error.
    res = run_dasel(["-i", "dasel", "-o", "plain"], input=b"1e20")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: failed to read value: "
        "error executing selector: execution error when processing "
        "ast.ChainedExpr: error executing expression: execution error "
        "when processing ast.PropertyExpr: unexpected type: expected map, "
        "got int\n"
    )


def test_var_default_format_is_dasel():
    """A --var value with no format prefix is read as a dasel selector."""
    # CATCHES: the variable mapper defaults to the dasel format, so plain
    # scalars and literals work without a prefix.
    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact", "--var", "v=1", "$v"],
        input=b'{"x":1}',
    )
    assert res.exit_code == 0
    assert res.out == "1\n"

    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact", "--var", "v=null", "$v"],
        input=b'{"x":1}',
    )
    assert res.exit_code == 0
    assert res.out == "null\n"


@pytest.mark.parametrize(
    "var,expected",
    [
        ("v=json:[2,3]", "[2,3]\n"),
        ("v=yaml:x", '"x"\n'),
        ("v=toml:y = 3", '{"y":3}\n'),
    ],
)
def test_var_explicit_formats(var, expected):
    """--var accepts an explicit <format>: prefix for any registered reader."""
    # CATCHES: the prefix selects a reader from the same registry as -i,
    # including readers with structured syntax like toml key/values.
    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact", "--var", var, "$v"],
        input=b'{"x":1}',
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == expected


def test_var_from_file(tmp_path):
    """--var <format>:file:<path> reads the value from a file."""
    # CATCHES: the file: prefix loads the raw bytes before parsing them with
    # the chosen format reader.
    path = write_input_file(tmp_path, "v.json", '{"vf": 99}')
    res = run_dasel(
        [
            "-i", "json", "-o", "json", "--compact",
            "--var", f"v=json:file:{path}", "$v.vf",
        ],
        input=b'{"x":1}',
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "99\n"


def test_var_missing_file_is_an_error(tmp_path):
    """A --var file that does not exist fails with the open error."""
    # CATCHES: file loading happens during flag parsing, so the error exits
    # with the kong code 80 rather than 1.
    missing = str(tmp_path / "nope.json")
    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact", "--var", f"v=json:file:{missing}", "$v"],
        input=b'{"x":1}',
    )
    assert res.exit_code == 80
    assert res.out == KONG_USAGE_STDOUT
    assert res.err == (
        "dasel: error: --var: failed to open file: "
        f"open {missing}: no such file or directory\n"
    )
