"""TOML reader and writer behaviour (parsing/toml/toml_reader.go and
toml_writer.go): tables, array tables, dotted keys, inline tables, date/time
values, writer key ordering, compact inline output and error cases.
"""

import pytest

from conftest import run_dasel


def test_basic_values_dotted_keys_and_inline_tables():
    """Scalars, dotted keys and inline tables decode to nested json."""
    # CATCHES: dotted keys create intermediate maps and inline tables become
    # plain nested maps.
    doc = 'a = 1\nb = "str"\nc = true\nd = 1.5\ne = [1, 2]\nf = {x = 1}\n'
    res = run_dasel(["-i", "toml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1,"b":"str","c":true,"d":1.5,"e":[1,2],"f":{"x":1}}\n'

    res = run_dasel(["-i", "toml", "-o", "json", "--compact"], input=b"a.b.c = 1\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"b":{"c":1}}}\n'


def test_tables_and_array_tables():
    """[table] headers nest maps; [[array]] headers append to slices."""
    # CATCHES: table headers, nested table paths and repeated array tables
    # building slices of maps.
    doc = (
        'title = "t"\n'
        "[owner]\n"
        'name = "n"\n'
        "[owner.address]\n"
        'city = "c"\n'
        "[[fruits]]\n"
        'name = "apple"\n'
        "[[fruits]]\n"
        'name = "banana"\n'
    )
    res = run_dasel(["-i", "toml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == (
        '{"title":"t","owner":{"name":"n","address":{"city":"c"}},'
        '"fruits":[{"name":"apple"},{"name":"banana"}]}\n'
    )


def test_datetime_values_read_as_strings():
    """TOML dates and times are preserved as literal strings."""
    # CATCHES: LocalDate/LocalTime/LocalDateTime/DateTime nodes become string
    # values with their source text intact.
    doc = (
        "date = 1979-05-27\ntime = 07:32:00\n"
        "dt = 1979-05-27T07:32:00Z\nlt = 1979-05-27T07:32:00\n"
    )
    res = run_dasel(["-i", "toml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == (
        '{"date":"1979-05-27","time":"07:32:00",'
        '"dt":"1979-05-27T07:32:00Z","lt":"1979-05-27T07:32:00"}\n'
    )


def test_writer_preserves_key_order():
    """The toml writer emits keys in their original document order."""
    # CATCHES: the reflect.StructOf ordering trick; a naive map-based writer
    # would alphabetise zz/aa.
    res = run_dasel(["-i", "toml", "-o", "toml"], input=b"zz = 1\naa = 2\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "zz = 1\naa = 2\n"


def test_writer_array_of_tables_headers():
    """Slices of maps round-trip as [[array]] table headers."""
    # CATCHES: arrays of tables use the [[name]] syntax and are separated by
    # blank lines.
    res = run_dasel(
        ["-i", "json", "-o", "toml"], input=b'{"t":[{"a":1},{"a":2}]}'
    )
    assert res.exit_code == 0
    assert res.out == "[[t]]\na = 1\n\n[[t]]\na = 2\n"


def test_writer_compact_inline_tables():
    """--compact emits inline tables and single-line arrays."""
    # CATCHES: compact mode sets SetTablesInline/SetArraysMultiline(false),
    # collapsing table headers into {…} inline syntax.
    res = run_dasel(
        ["-i", "json", "-o", "toml", "--compact"], input=b'{"t":[{"a":1},{"a":2}]}'
    )
    assert res.exit_code == 0
    assert res.out == "t = [{a = 1}, {a = 2}]\n"

    res = run_dasel(
        ["-i", "json", "-o", "toml", "--compact"], input=b'{"a":{"x":1},"b":[1,2]}'
    )
    assert res.exit_code == 0
    assert res.out == "a = {x = 1}\nb = [1, 2]\n"


def test_writer_nested_tables_and_string_styles():
    """Nested maps become ordered [table] headers; strings keep quotes."""
    # CATCHES: deep nesting emits one header per level in path order, and
    # go-toml prefers literal 'single quotes' for simple strings.
    res = run_dasel(
        ["-i", "json", "-o", "toml"], input=b'{"deep":{"x":{"y":{"z":1}}}}'
    )
    assert res.exit_code == 0
    assert res.out == "[deep]\n[deep.x]\n[deep.x.y]\nz = 1\n"

    res = run_dasel(["-i", "toml", "-o", "toml"], input=b'arr = [1, "two", true]\n')
    assert res.exit_code == 0
    assert res.out == "arr = [1, 'two', true]\n"

    res = run_dasel(["-i", "toml", "-o", "toml"], input=b's = "multi\\nline"\n')
    assert res.exit_code == 0
    assert res.out == 's = "multi\\nline"\n'


def test_writer_scalar_root():
    """A non-table root is written bare by stripping the placeholder key."""
    # CATCHES: scalar roots (int and string) are encoded against a
    # placeholder "v = " key and the prefix is stripped back off; strings
    # come out as literal-quoted.
    res = run_dasel(["-i", "json", "-o", "toml"], input=b"1")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "1\n"

    res = run_dasel(["-i", "json", "-o", "toml"], input=b'"str"')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "'str'\n"


def test_writer_null_root_is_an_error():
    """A null document root has no TOML representation and errors."""
    # CATCHES: null roots are passed to go-toml as a nil interface, which
    # rejects them rather than emitting an empty document.
    res = run_dasel(["-i", "toml", "-o", "toml"], input=b"")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error writing output: toml encode failed: "
        "toml: cannot encode a nil interface\n"
    )


@pytest.mark.parametrize(
    "doc",
    [
        b"a = 1\n[[a.b]]\nx = 1\n",
        b'a = "x"\n[a]\n',
    ],
)
def test_conflicting_types_error(doc):
    """Redefining a scalar path as a table fails with the conflict error."""
    # CATCHES: ensureMapAt rejects paths whose existing value is not a map.
    res = run_dasel(["-i", "toml", "-o", "json"], input=doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: "
        "conflicting types at path 'a': expected map\n"
    )
