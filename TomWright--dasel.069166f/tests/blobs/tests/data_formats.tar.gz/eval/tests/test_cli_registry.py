"""CLI-level behaviour: format registry resolution, config files, flag
parsing/syntax, stream separation and exit codes.

Covers parsing/format.go (unknown -i/-o names), parsing/reader.go + writer.go
(registration surfaces), internal/cli (flag parsing, config loading, run
orchestration).
"""

import pytest

from conftest import KONG_USAGE_STDOUT, run_dasel, write_input_file


def test_unsupported_reader_format_error():
    """An unknown -i name fails with the exact unsupported-reader message."""
    # CATCHES: the registry error string and its "failed to get input reader"
    # wrapping; a re-implementation with a different message or a nonzero
    # stdout write would fail.
    res = run_dasel(["-i", "nope", "-o", "json", "null"])
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: failed to get input reader: "
        "unsupported reader file format: nope\n"
    )


def test_unsupported_writer_format_error():
    """An unknown -o name fails with the exact unsupported-writer message."""
    # CATCHES: the writer-side registry error, which is only reachable after
    # the reader was created successfully.
    res = run_dasel(["-i", "json", "-o", "nope", "null"])
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: failed to get output writer: "
        "unsupported writer file format: nope\n"
    )


def test_missing_in_format_fills_from_out_format():
    """-o without -i copies the out format into the in format."""
    # CATCHES: -o plain has no reader, so the fill-in rule makes the run fail
    # with the reader error rather than silently writing plain output.
    res = run_dasel(["-o", "plain", "null"])
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: failed to get input reader: "
        "unsupported reader file format: plain\n"
    )


def test_missing_out_format_fills_from_in_format():
    """-i without -o copies the in format into the out format."""
    # CATCHES: piping yaml with only -i yaml must round-trip to yaml output,
    # not the default json writer.
    res = run_dasel(["-i", "yaml"], input=b"k: v\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "k: v\n"


def test_config_default_format_applies_to_both_directions(tmp_path):
    """A config default_format drives both reader and writer when -i/-o are absent."""
    # CATCHES: the config file default must apply to input parsing as well as
    # output; piping yaml with no flags only works if the reader also switched.
    cfg = write_input_file(tmp_path, "dasel.yaml", "default_format: yaml\n")
    res = run_dasel(["-c", cfg], input=b"k: v\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "k: v\n"


def test_missing_config_file_falls_back_to_json(tmp_path):
    """A nonexistent config path silently falls back to the json default."""
    # CATCHES: missing config must not be an error; json remains the default
    # format for both directions.
    missing = str(tmp_path / "does-not-exist.yaml")
    res = run_dasel(["-c", missing], input=b'{"k": "v"}')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{\n    "k": "v"\n}\n'


def test_invalid_config_file_is_an_error(tmp_path):
    """An unparseable config file exits 1 with the wrapped yaml error."""
    # CATCHES: config parse failures are fatal and keep the yaml library's
    # error text verbatim.
    cfg = write_input_file(tmp_path, "bad.yaml", "default_format: [\n")
    res = run_dasel(["-c", cfg, "null"])
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error parsing config file: "
        "yaml: line 1: did not find expected node content\n"
    )


def test_flag_parse_error_prints_usage_to_stdout_and_error_to_stderr():
    """Kong flag errors exit 80, usage on stdout, error line on stderr."""
    # CATCHES: the exit code (80, not 1) and the stream split between the
    # usage banner and the "dasel: error:" line.
    res = run_dasel(["--var", "vvv"])
    assert res.exit_code == 80
    assert res.out == KONG_USAGE_STDOUT
    assert res.err == (
        "dasel: error: --var: invalid variable format, "
        "expect foo=bar, or foo=format:file:path\n"
    )


@pytest.mark.parametrize(
    "flag,value,expected_err",
    [
        (
            "--read-flag",
            "zzz",
            "dasel: error: --read-flag: invalid read/write flag format, "
            "expect foo=bar\n",
        ),
        (
            "--var",
            "v=nope:1",
            "dasel: error: --var: failed to create reader: "
            "unsupported reader file format: nope\n",
        ),
    ],
)
def test_ext_flag_syntax_errors(flag, value, expected_err):
    """Malformed --read-flag/--var values fail with their exact messages."""
    # CATCHES: the foo=bar syntax requirement for ext flags and the var
    # reader lookup sharing the format registry.
    res = run_dasel([flag, value, "null"])
    assert res.exit_code == 80
    assert res.out == KONG_USAGE_STDOUT
    assert res.err == expected_err


def test_read_flag_overrides_rw_flag():
    """--read-flag wins over --rw-flag for the same option name."""
    # CATCHES: the precedence order when both flag sources set
    # csv-delimiter; the reader must use the comma, leaving one header field.
    res = run_dasel(
        [
            "-i", "csv", "-o", "json", "--compact",
            "--rw-flag", "csv-delimiter=;",
            "--read-flag", "csv-delimiter=,",
        ],
        input=b"a;b\n1;2\n",
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '[{"a;b":"1;2"}]\n'


def test_write_flag_overrides_rw_flag():
    """--write-flag wins over --rw-flag for the same option name."""
    # CATCHES: only the writer side is overridden — the reader still splits
    # on the rw-flag semicolon (two fields per row) while the writer emits
    # commas, unquoted because no field contains a comma.
    res = run_dasel(
        [
            "-i", "csv", "-o", "csv",
            "--rw-flag", "csv-delimiter=;",
            "--write-flag", "csv-delimiter=,",
        ],
        input=b"a;b\n1;2\n",
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "a,b\n1,2\n"


def test_root_flag_returns_original_input():
    """--root outputs the unmodified input document, not the query result."""
    # CATCHES: the --root flag bypassing the selected value entirely.
    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact", "--root", "a"],
        input=b'{"a":1}',
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1}\n'


def test_missing_map_key_error():
    """Selecting a missing key exits 1 with the exact selector error."""
    # CATCHES: runtime errors go to stderr only, stdout stays empty, and the
    # error names the failing AST node and the missing key.
    res = run_dasel(["-i", "json", "-o", "json", "zz"], input=b'{"a":1}')
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        'dasel: error: error executing selector: execution error when '
        'processing ast.PropertyExpr: map key not found: "zz"\n'
    )
