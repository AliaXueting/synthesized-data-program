"""KDL behaviour (parsing/kdl/kdl_reader.go, kdl_writer.go and the internal
tokenizer/parser/generator): node arguments, $args, properties, children
merging, duplicate promotion, type annotations, version keywords and the
nesting depth guard.
"""

import pytest

from conftest import run_dasel


def test_node_with_single_argument_is_scalar():
    """A node with exactly one argument and nothing else is that scalar."""
    # CATCHES: the reader collapses single-argument nodes to their scalar
    # value instead of a $args wrapper.
    res = run_dasel(["-i", "kdl", "-o", "json", "--compact"], input=b'a 1\nb "two"\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1,"b":"two"}\n'


def test_node_arguments_properties_and_children():
    """Multiple arguments collect into $args; properties and children merge."""
    # CATCHES: the $args convention for argument lists (also used when a
    # single argument coexists with properties or children), and property /
    # child keys sharing one namespace.
    res = run_dasel(
        ["-i", "kdl", "-o", "json", "--compact"],
        input=b'node "arg1" 2 3.5 true null key="prop"\n',
    )
    assert res.exit_code == 0
    assert res.out == '{"node":{"$args":["arg1",2,3.5,true,null],"key":"prop"}}\n'

    res = run_dasel(
        ["-i", "kdl", "-o", "json", "--compact"], input=b"a 1 k=2\n"
    )
    assert res.exit_code == 0
    assert res.out == '{"a":{"$args":[1],"k":2}}\n'

    res = run_dasel(
        ["-i", "kdl", "-o", "json", "--compact"], input=b'node key=1 {\n  sub "v"\n}\n'
    )
    assert res.exit_code == 0
    assert res.out == '{"node":{"key":1,"sub":"v"}}\n'


def test_duplicate_node_names_promote_to_slice():
    """Same-named sibling nodes are collected into a slice."""
    # CATCHES: the second occurrence upgrades the map value to a slice and
    # further occurrences append to it.
    res = run_dasel(
        ["-i", "kdl", "-o", "json", "--compact"], input=b"item 1\nitem 2\nitem 3\n"
    )
    assert res.exit_code == 0
    assert res.out == '{"item":[1,2,3]}\n'


def test_bare_node_is_null():
    """A node with no args, properties or children decodes to null."""
    # CATCHES: empty nodes are explicit nulls, not empty maps or strings.
    res = run_dasel(["-i", "kdl", "-o", "json", "--compact"], input=b"a\nb\n")
    assert res.exit_code == 0
    assert res.out == '{"a":null,"b":null}\n'


def test_type_annotations_and_raw_strings():
    """Type annotations are dropped; raw strings and escapes decode."""
    # CATCHES: (type) annotations do not change the decoded value, r#"…"#
    # raw strings unescape, and \" inside basic strings survives to json.
    res = run_dasel(["-i", "kdl", "-o", "json", "--compact"], input=b"a (i64)5\n")
    assert res.exit_code == 0
    assert res.out == '{"a":5}\n'

    res = run_dasel(
        ["-i", "kdl", "-o", "json", "--compact"], input=b'a (date)"2020-01-01"\n'
    )
    assert res.exit_code == 0
    assert res.out == '{"a":"2020-01-01"}\n'

    res = run_dasel(["-i", "kdl", "-o", "json", "--compact"], input=b'a r#"raw"#\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"raw"}\n'

    res = run_dasel(
        ["-i", "kdl", "-o", "json", "--compact"], input=b'a "esc\\"aped"\n'
    )
    assert res.exit_code == 0
    assert res.out == '{"a":"esc\\"aped"}\n'


def test_writer_version_keywords():
    """v2 writes #true/#null keywords; kdl-version=1 writes them bare."""
    # CATCHES: the kdl-version write flag switching keyword rendering, and
    # null nodes emitting as bare node names in both versions.
    res = run_dasel(["-i", "kdl", "-o", "kdl"], input=b"a true\nb null\nc 1.5\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "a #true\nb\nc 1.5\n"

    res = run_dasel(
        ["-i", "kdl", "-o", "kdl", "--write-flag", "kdl-version=1"],
        input=b"a true\nb null\n",
    )
    assert res.exit_code == 0
    assert res.out == "a true\nb\n"


def test_writer_invalid_version_error():
    """An unsupported kdl-version value fails with the exact message."""
    # CATCHES: only "1" and "2" are accepted; anything else is rejected
    # before generation with the (use 1 or 2) hint.
    res = run_dasel(
        ["-i", "kdl", "-o", "kdl", "--write-flag", "kdl-version=3"], input=b"a 1\n"
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        'dasel: error: error writing output: kdl: '
        'unsupported output version "3" (use 1 or 2)\n'
    )


def test_nesting_depth_limit():
    """Children blocks nested deeper than 10000 fail with the depth error."""
    # CATCHES: the parser's maxKDLDepth guard on children-block nesting.
    deep = "a { " * 10005 + "a" + " }" * 10005
    res = run_dasel(["-i", "kdl", "-o", "json", "--compact"], input=deep.encode())
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: kdl: parse error: "
        "kdl nesting depth exceeded\n"
    )

    ok = "a { " * 9999 + "a" + " }" * 9999
    res = run_dasel(["-i", "kdl", "-o", "json", "--compact"], input=ok.encode())
    assert res.exit_code == 0
    assert res.err == ""


def test_writer_roundtrip_model():
    """Maps with props, children and slices regenerate idiomatic KDL."""
    # CATCHES: scalar map values become properties, slices become repeated
    # child nodes, and $args maps back to positional arguments.
    res = run_dasel(
        ["-i", "json", "-o", "kdl"], input=b'{"a":{"b":1,"c":[1,2]}}'
    )
    assert res.exit_code == 0
    assert res.out == "a b=1 {\n  c 1\n  c 2\n}\n"

    res = run_dasel(
        ["-i", "json", "-o", "kdl"], input=b'{"a":{"$args":[1,2],"k":"v"}}'
    )
    assert res.exit_code == 0
    assert res.out == 'a 1 2 k="v"\n'


def test_writer_quoting_and_non_map_roots():
    """Non-bare identifiers and string args are quoted; roots get wrapped."""
    # CATCHES: keys that cannot be bare KDL identifiers are quoted strings,
    # numeric-looking string args stay quoted, and non-map roots are emitted
    # as a single "root" node.
    res = run_dasel(
        ["-i", "json", "-o", "kdl"],
        input=b'{"a with space":"val with space","b":"1"}',
    )
    assert res.exit_code == 0
    assert res.out == '"a with space" "val with space"\nb "1"\n'

    res = run_dasel(["-i", "json", "-o", "kdl"], input=b"[1,2]")
    assert res.exit_code == 0
    assert res.out == "root 1 2\n"

    res = run_dasel(["-i", "json", "-o", "kdl"], input=b'"scalar"')
    assert res.exit_code == 0
    assert res.out == 'root "scalar"\n'

    res = run_dasel(["-i", "json", "-o", "kdl"], input=b"5")
    assert res.exit_code == 0
    assert res.out == "root 5\n"

    res = run_dasel(["-i", "json", "-o", "kdl"], input=b"null")
    assert res.exit_code == 0
    assert res.out == "root\n"


def test_writer_compact_has_no_trailing_newline():
    """--compact KDL output has no newlines at all, not even a final one."""
    # CATCHES: compact generation suppresses writeNewline entirely, so the
    # document does not end with a newline unlike every other writer.
    res = run_dasel(["-i", "json", "-o", "kdl", "--compact"], input=b'{"a":1}')
    assert res.exit_code == 0
    assert res.out == "a 1"


def test_writer_value_rendering():
    """The generator renders floats with a decimal point and escapes strings."""
    # CATCHES: a whole-number float keeps a `.0` so it stays a float on
    # round-trip, control characters are re-escaped, and keys that collide
    # with v1 keywords (or are empty) are quoted.
    res = run_dasel(["-i", "json", "-o", "kdl"], input=b'{"a":2.0}')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "a 2.0\n"

    res = run_dasel(["-i", "json", "-o", "kdl"], input=b'{"a":"tab\\there\\nline"}')
    assert res.exit_code == 0
    assert res.out == 'a "tab\\there\\nline"\n'

    res = run_dasel(["-i", "json", "-o", "kdl"], input=b'{"true":1,"inf":2}')
    assert res.exit_code == 0
    assert res.out == '"true" 1\n"inf" 2\n'

    res = run_dasel(["-i", "json", "-o", "kdl"], input=b'{"":1}')
    assert res.exit_code == 0
    assert res.out == '"" 1\n'

    res = run_dasel(["-i", "json", "-o", "kdl"], input=b'{"a":"say \\"hi\\""}')
    assert res.exit_code == 0
    assert res.out == 'a "say \\"hi\\""\n'


def test_parse_error_message():
    """A node line starting with a number fails with the parser error."""
    # CATCHES: parse errors carry the doubled "kdl: parse error: kdl:"
    # prefix plus token code and position.
    res = run_dasel(["-i", "kdl", "-o", "json", "--compact"], input=b"5 5\n")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: kdl: parse error: "
        "kdl: expected node name, got 6 at line 1, col 1\n"
    )
