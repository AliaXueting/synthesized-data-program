"""CSV reader and writer behaviour (parsing/csv/csv.go, reader.go, writer.go):
header row mapping, field count validation, the csv-delimiter option and its
single-character rule, and the slice-root writer requirements.
"""

import pytest

from conftest import run_dasel


def test_header_row_becomes_map_keys():
    """The first row names the keys; every later row becomes a map."""
    # CATCHES: all CSV values are strings (no numeric coercion) and the
    # document root is a slice of row maps.
    doc = "a,b\n1,2\n3,4\n"
    res = run_dasel(["-i", "csv", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '[{"a":"1","b":"2"},{"a":"3","b":"4"}]\n'


@pytest.mark.parametrize(
    "doc",
    [
        b"a,b\n1,2,3\n",
        b"a,b\n1\n2,3\n",
    ],
)
def test_wrong_field_count_error(doc):
    """Rows with a different field count than the header are an error."""
    # CATCHES: encoding/csv enforces equal field counts and the error names
    # the offending line number.
    res = run_dasel(["-i", "csv", "-o", "json"], input=doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: record on line 2: "
        "wrong number of fields\n"
    )


def test_bare_quote_error():
    """A bare double quote in a non-quoted field is a parse error."""
    # CATCHES: the csv parser rejects stray quotes with the line/column
    # position in the message.
    res = run_dasel(
        ["-i", "csv", "-o", "json"], input=b'name,note\n"x,y",has "quotes"\n'
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        'dasel: error: error reading input: parse error on line 2, '
        'column 11: bare " in non-quoted-field\n'
    )


def test_delimiter_rw_flag_applies_to_both_directions():
    """--rw-flag csv-delimiter changes the reader and the writer."""
    # CATCHES: the delimiter is decoded as a full rune, not a first byte,
    # and is honoured on read and on write.
    res = run_dasel(
        ["-i", "csv", "-o", "json", "--compact", "--rw-flag", "csv-delimiter=;"],
        input=b"a;b\n1;2\n",
    )
    assert res.exit_code == 0
    assert res.out == '[{"a":"1","b":"2"}]\n'

    res = run_dasel(
        ["-i", "csv", "-o", "csv", "--rw-flag", "csv-delimiter=;"],
        input=b"a;b\n1;2\n",
    )
    assert res.exit_code == 0
    assert res.out == "a;b\n1;2\n"


def test_delimiter_read_and_write_flags_are_independent():
    """--read-flag only affects parsing; --write-flag only affects output."""
    # CATCHES: a read-only delimiter leaves the writer on commas (output uses
    # commas unquoted), while a write-only delimiter leaves the reader on
    # commas (single "a;b" header, which the semicolon writer must quote).
    res = run_dasel(
        ["-i", "csv", "-o", "csv", "--read-flag", "csv-delimiter=;"],
        input=b"a;b\n1;2\n",
    )
    assert res.exit_code == 0
    assert res.out == "a,b\n1,2\n"

    res = run_dasel(
        ["-i", "csv", "-o", "csv", "--write-flag", "csv-delimiter=;"],
        input=b"a;b\n1;2\n",
    )
    assert res.exit_code == 0
    assert res.out == '"a;b"\n"1;2"\n'


def test_delimiter_multibyte_rune():
    """A multi-byte UTF-8 delimiter is accepted as a single character."""
    # CATCHES: the single-rune validation via utf8.DecodeRuneInString, which
    # an implementation taking v[0] would corrupt.
    res = run_dasel(
        ["-i", "csv", "-o", "json", "--compact", "--rw-flag", "csv-delimiter=§"],
        input="a§b\n1§2\n".encode(),
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '[{"a":"1","b":"2"}]\n'


@pytest.mark.parametrize(
    "delim",
    [";;", "tab"],
)
def test_delimiter_must_be_single_character(delim):
    """Multi-character delimiters fail with the single-character error."""
    # CATCHES: the reader constructor validates before any parsing, so the
    # error surfaces as "failed to get input reader" with %q formatting.
    res = run_dasel(
        ["-i", "csv", "-o", "json", "--rw-flag", f"csv-delimiter={delim}"],
        input=b"a;b\n1;2\n",
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: failed to get input reader: "
        f'csv-delimiter must be a single character, got "{delim}"\n'
    )


def test_empty_delimiter_falls_back_to_comma():
    """An empty csv-delimiter value is treated as unset."""
    # CATCHES: separatorFromOption only validates non-empty values, so
    # csv-delimiter= silently keeps the default comma instead of erroring.
    res = run_dasel(
        ["-i", "csv", "-o", "json", "--compact", "--rw-flag", "csv-delimiter="],
        input=b"a;b\n1;2\n",
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '[{"a;b":"1;2"}]\n'


def test_writer_takes_headers_from_first_row():
    """Headers come from the first row; later extra keys are ignored."""
    # CATCHES: the writer only iterates the first row's keys, so a "b" key
    # appearing only in the second row produces no column.
    res = run_dasel(
        ["-i", "json", "-o", "csv"], input=b'[{"a":1},{"a":3,"b":4}]'
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "a\n1\n3\n"


def test_writer_quoting_and_null_values():
    """Fields containing the delimiter are quoted; null becomes empty."""
    # CATCHES: null writes as an empty field (not "null") and encoding/csv
    # quoting rules apply on output.
    res = run_dasel(
        ["-i", "json", "-o", "csv"], input=b'[{"a":1,"b":"x,y"},{"a":3,"b":null}]'
    )
    assert res.exit_code == 0
    assert res.out == 'a,b\n1,"x,y"\n3,\n'

    res = run_dasel(
        ["-i", "json", "-o", "csv"], input=b'[{"a":1.5,"b":true}]'
    )
    assert res.exit_code == 0
    assert res.out == "a,b\n1.5,true\n"


@pytest.mark.parametrize(
    "doc,value_type",
    [
        (b'{"x":"not a slice"}', "map"),
        (b"42", "int"),
        (b"null", "null"),
    ],
)
def test_writer_requires_slice_root(doc, value_type):
    """The csv writer rejects any non-slice root with the exact error."""
    # CATCHES: the root type check message includes the offending type name.
    res = run_dasel(["-i", "json", "-o", "csv"], input=doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error writing output: csv writer expects root output "
        f"to be a slice/array, got {value_type}\n"
    )


def test_csv_roundtrip_with_quotes():
    """Embedded quotes and delimiters survive a csv -> csv round-trip."""
    # CATCHES: RFC-style doubled quotes round-trip through the reader and
    # writer unchanged.
    res = run_dasel(
        ["-i", "csv", "-o", "csv"], input=b'a,b\n"x""y","z,w"\n'
    )
    assert res.exit_code == 0
    assert res.out == 'a,b\n"x""y","z,w"\n'
