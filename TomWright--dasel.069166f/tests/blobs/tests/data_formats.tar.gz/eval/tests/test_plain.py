"""Plain writer behaviour (parsing/plain/plain_writer.go): unquoted scalars
one per line, null as an empty line, rejection of non-scalars, and the empty
document separator.
"""

import pytest

from conftest import run_dasel


@pytest.mark.parametrize(
    "fmt,payload,expected",
    [
        ("dasel", "42", "42\n"),
        ("dasel", "3.5", "3.5\n"),
        ("dasel", "true", "true\n"),
        ("dasel", '"hi there"', "hi there\n"),
        ("json", "1e20", "1e+20\n"),
        ("dasel", "null", "\n"),
    ],
)
def test_scalar_rendering(fmt, payload, expected):
    """Each scalar type renders unquoted, one value per line."""
    # CATCHES: %g float formatting (1e+20 from the json float 1e20), no
    # quoting of strings, and the empty line for null instead of "null".
    res = run_dasel(["-i", fmt, "-o", "plain"], input=payload.encode())
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == expected


@pytest.mark.parametrize(
    "doc,expected_err",
    [
        (
            b'{"a":"x"}',
            "dasel: error: error writing output: "
            "plain can only represent scalar values, got map\n",
        ),
        (
            b"[1,2]",
            "dasel: error: error writing output: "
            "plain can only represent scalar values, got array\n",
        ),
    ],
)
def test_non_scalar_rejected(doc, expected_err):
    """Maps and arrays have no plain representation and error out."""
    # CATCHES: the writer only accepts scalars; the error names the type
    # ("map"/"array", not the Go type names).
    res = run_dasel(["-i", "json", "-o", "plain"], input=doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == expected_err


def test_multiline_string_passes_through():
    """Strings containing newlines are written verbatim."""
    # CATCHES: no escaping or quoting is applied; embedded newlines land in
    # the output as-is.
    res = run_dasel(
        ["-i", "json", "-o", "plain"], input=b'"multi\\nline"'
    )
    assert res.exit_code == 0
    assert res.out == "multi\nline\n"


def test_no_document_separator():
    """Multi-document plain output concatenates with no separator."""
    # CATCHES: the plain writer's Separator() is nil, so branch documents are
    # joined directly (no blank line between values).
    res = run_dasel(
        ["-i", "json", "-o", "plain", "--unstable", "branch(a,b)"],
        input=b'{"a":1,"b":"two"}',
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "1\ntwo\n"


def test_plain_has_no_reader():
    """plain is write-only; using it as an input format fails."""
    # CATCHES: plain is not registered as a reader, both explicitly and via
    # the -o-only fill-in rule.
    res = run_dasel(["-i", "plain", "-o", "json"], input=b"hello\n")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: failed to get input reader: "
        "unsupported reader file format: plain\n"
    )

    res = run_dasel(["-i", "plain", "-o", "plain"], input=b"hello\n")
    assert res.exit_code == 1
    assert res.err == (
        "dasel: error: failed to get input reader: "
        "unsupported reader file format: plain\n"
    )
