"""XML reader and writer behaviour (parsing/xml/reader.go and writer.go):
friendly vs structured modes, attributes, comments, processing instructions,
child order round-trip, entity/CDATA decoding, writer validation and the
size/depth/comment DoS limits.
"""

import pytest

from conftest import run_dasel


def test_friendly_attributes_text_and_children():
    """Friendly mode maps attributes to -keys, text to #text."""
    # CATCHES: the "-attr" and "#text" key conventions and the collapse of
    # childless/textless elements to plain strings.
    doc = '<root><a>1</a><b attr="v">text</b></root>'
    res = run_dasel(["-i", "xml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"root":{"a":"1","b":{"-attr":"v","#text":"text"}}}\n'


def test_structured_mode_model():
    """xml-mode=structured exposes name/attrs/content/children nodes."""
    # CATCHES: the structured read flag swaps the model to explicit
    # name/attrs/content/children maps, including the synthetic root wrapper.
    doc = '<root><a>1</a><b attr="v">text</b></root>'
    res = run_dasel(
        ["-i", "xml", "-o", "json", "--compact", "--read-flag", "xml-mode=structured"],
        input=doc.encode(),
    )
    assert res.exit_code == 0
    assert res.out == (
        '{"name":"root","attrs":{},"content":"","children":'
        '[{"name":"root","attrs":{},"content":"","children":'
        '[{"name":"a","attrs":{},"content":"1","children":[]},'
        '{"name":"b","attrs":{"attr":"v"},"content":"text","children":[]}]}]}\n'
    )


def test_repeated_children_become_slice():
    """Same-named sibling elements are grouped into a slice."""
    # CATCHES: the friendly model groups repeated child names into arrays
    # while single children stay scalar.
    doc = "<root><x>1</x><x>2</x></root>"
    res = run_dasel(["-i", "xml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"root":{"x":["1","2"]}}\n'


def test_comment_forces_map_shape():
    """A comment before a child makes that child a map with #text."""
    # CATCHES: comments attach to the following element, which stops it
    # collapsing to a plain string even though it has no attributes.
    doc = "<root><!-- comment --><a>1</a></root>"
    res = run_dasel(["-i", "xml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"root":{"a":{"#text":"1"}}}\n'


def test_mixed_content_and_empty_elements():
    """Text around child elements concatenates; empty elements become ""."""
    # CATCHES: CharData segments accumulate across children (a + c = "ac")
    # and an empty element decodes to an empty string value.
    doc = "<root>a<b/>c</root>"
    res = run_dasel(["-i", "xml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"root":{"#text":"ac","b":""}}\n'


def test_entity_and_cdata_decoding():
    """Entities decode in text and attributes; CDATA stays raw."""
    # CATCHES: strict decoding expands &amp;/&#65; everywhere while CDATA
    # content is kept verbatim.
    res = run_dasel(["-i", "xml", "-o", "json", "--compact"], input=b"<r>&amp;&lt;&gt;&#65;</r>")
    assert res.exit_code == 0
    assert res.out == '{"r":"&<>A"}\n'

    res = run_dasel(["-i", "xml", "-o", "json", "--compact"], input=b'<r a="&amp;"/>')
    assert res.exit_code == 0
    assert res.out == '{"r":{"-a":"&"}}\n'

    res = run_dasel(
        ["-i", "xml", "-o", "json", "--compact"], input=b"<r><![CDATA[<raw>]]></r>"
    )
    assert res.exit_code == 0
    assert res.out == '{"r":"<raw>"}\n'


def test_roundtrip_child_order_preserved():
    """Interleaved repeated children keep document order on round-trip."""
    # CATCHES: the xmlChildOrderKey metadata lets the writer re-emit
    # a,b,a order even though the model groups the two <a> into a slice.
    doc = "<root><a>1</a><b>2</b><a>3</a></root>"
    res = run_dasel(["-i", "xml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"root":{"a":["1","3"],"b":"2"}}\n'

    res = run_dasel(["-i", "xml", "-o", "xml"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == "<root>\n  <a>1</a>\n  <b>2</b>\n  <a>3</a>\n</root>\n"


def test_roundtrip_comments_and_processing_instructions():
    """Document comments and processing instructions survive a round-trip."""
    # CATCHES: comments and PIs are stored as metadata and re-emitted before
    # their element with correct newline handling.
    res = run_dasel(
        ["-i", "xml", "-o", "xml"], input=b"<!-- top comment --><root><a>1</a></root>"
    )
    assert res.exit_code == 0
    assert res.out == "<!-- top comment -->\n<root>\n  <a>1</a>\n</root>\n"

    res = run_dasel(
        ["-i", "xml", "-o", "xml"], input=b'<?php echo "hi"?><root><a>1</a></root>'
    )
    assert res.exit_code == 0
    assert res.out == '<?php echo "hi"?>\n<root>\n  <a>1</a>\n</root>\n'

    res = run_dasel(
        ["-i", "xml", "-o", "xml"], input=b"<r><a>1</a><!-- mid --><b>2</b></r>"
    )
    assert res.exit_code == 0
    assert res.out == "<r>\n  <a>1</a>\n  <!-- mid -->\n  <b>2</b>\n</r>\n"


def test_writer_attributes_and_text_from_json():
    """-keys become attributes and #text becomes element text."""
    # CATCHES: the writer inverts the friendly conventions, emitting
    # attributes before content in one line.
    res = run_dasel(
        ["-i", "json", "-o", "xml"], input=b'{"r":{"-a":"1","#text":"t"}}'
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '<r a="1">t</r>\n'


def test_writer_rejects_invalid_element_names():
    """Map keys that are not valid XML names fail with the exact error."""
    # CATCHES: isValidXMLName validation of element names with the wrapped
    # "failed to convert child element" context.
    res = run_dasel(["-i", "json", "-o", "xml"], input=b'{"bad name":"x"}')
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error writing output: failed to convert to element: "
        'failed to convert child element "bad name" to element: '
        'key "bad name" is not a valid XML element name\n'
    )


@pytest.mark.parametrize(
    "doc,expected_err",
    [
        (
            b'{"r":123}',
            "dasel: error: error writing output: failed to convert to element: "
            'failed to convert child element "r" to element: '
            "xml writer does not support value type: int\n",
        ),
        (
            b"null",
            "dasel: error: error writing output: failed to convert to element: "
            "xml writer does not support value type: null\n",
        ),
    ],
)
def test_writer_rejects_non_string_scalars(doc, expected_err):
    """Int/null values have no XML representation and error out."""
    # CATCHES: only strings are valid element bodies; every other scalar
    # type is rejected by the writer.
    res = run_dasel(["-i", "json", "-o", "xml", "--compact"], input=doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == expected_err


def test_writer_string_root_renders_empty():
    """A bare string root writes an empty document, not an error."""
    # CATCHES: unlike int/null roots (which error), a string root has no
    # element name to wrap it in, so the writer emits just the trailing
    # newline and exits 0.
    res = run_dasel(["-i", "json", "-o", "xml"], input=b'"1"')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "\n"


def test_compact_output():
    """--compact writes the whole document on one line."""
    # CATCHES: compact sets zero indentation and skips the newline between
    # top-level children, keeping only the final newline.
    doc = "<root><a>1</a><b>2</b></root>"
    res = run_dasel(["-i", "xml", "-o", "xml", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == "<root><a>1</a><b>2</b></root>\n"


def test_malformed_xml_error():
    """Truncated XML exits 1 with the strict decoder error."""
    # CATCHES: the decoder runs in Strict mode, so an unclosed element
    # reports "unexpected EOF" from the xml package.
    res = run_dasel(["-i", "xml", "-o", "json"], input=b"<root>")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: failed to read token: "
        "XML syntax error on line 1: unexpected EOF\n"
    )


@pytest.mark.parametrize(
    "doc,expected_err",
    [
        (
            "comment-length",
            "dasel: error: error reading input: "
            "comment exceeds maximum length of 10000 bytes\n",
        ),
        (
            "comment-count",
            "dasel: error: error reading input: "
            "document exceeds maximum comment count of 1000\n",
        ),
        (
            "depth",
            "dasel: error: error reading input: xml nesting depth exceeded\n",
        ),
        (
            "size",
            "dasel: error: error reading input: "
            "XML input exceeds maximum size of 10000000 bytes\n",
        ),
    ],
)
def test_dos_limits(doc, expected_err):
    """Each DoS guard rejects one byte past its limit with an exact message."""
    # CATCHES: the four independent limits (comment bytes, comment count,
    # nesting depth, input size) and their boundary messages.
    if doc == "comment-length":
        data = ("<!--" + "a" * 10001 + "-->").encode()
    elif doc == "comment-count":
        data = ("<r>" + "<!--c-->" * 1001 + "</r>").encode()
    elif doc == "depth":
        data = ("<r>" * 10001 + "</r>" * 10001).encode()
    else:
        data = ("<r>" + "x" * 10000001 + "</r>").encode()

    res = run_dasel(["-i", "xml", "-o", "json", "--compact"], input=data)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == expected_err


def test_dos_limits_boundaries_pass():
    """Inputs exactly at each limit still parse successfully."""
    # CATCHES: the guards are > limit, not >= limit; boundary inputs must
    # not be rejected.
    res = run_dasel(
        ["-i", "xml", "-o", "json", "--compact"],
        input=("<r>" + "<!--c-->" * 1000 + "</r>").encode(),
    )
    assert res.exit_code == 0
    assert res.out == '{"r":{}}\n'

    res = run_dasel(
        ["-i", "xml", "-o", "json", "--compact"], input=("<r>" * 10000 + "</r>" * 10000).encode()
    )
    assert res.exit_code == 0
