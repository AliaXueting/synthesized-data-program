"""JSON reader and writer behaviour (parsing/json/json_reader.go and
json_writer.go): indentation, compact mode, HTML escaping, number typing,
NDJSON multi-document input, escape handling, malformed input and the nesting
depth limit.
"""

import pytest

from conftest import run_dasel


def test_writer_default_four_space_indentation():
    """The json writer indents nested maps and arrays with 4 spaces."""
    # CATCHES: the hard-coded 4-space indent string (not 2), the space after
    # the colon, and the trailing newline.
    res = run_dasel(["-i", "json", "-o", "json"], input=b'{"a":1,"b":[1,2]}')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{\n    "a": 1,\n    "b": [\n        1,\n        2\n    ]\n}\n'


def test_writer_compact_mode():
    """--compact removes all indentation and newlines within the document."""
    # CATCHES: compact output keeps no space after ':' or ',' and still ends
    # with exactly one newline.
    doc = '{"a":1,"b":{"c":[true,null]}}'
    res = run_dasel(["-i", "json", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"a":1,"b":{"c":[true,null]}}\n'


def test_writer_html_escape_default_and_flag():
    """< > & stay literal by default; json-escape=html escapes them."""
    # CATCHES: the writer disables HTML escaping unless the json-escape=html
    # write flag is passed, producing < style escapes.
    doc = '{"html":"<b>&</b>"}'
    res = run_dasel(["-i", "json", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"html":"<b>&</b>"}\n'

    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact", "--write-flag", "json-escape=html"],
        input=doc.encode(),
    )
    assert res.exit_code == 0
    assert res.out == '{"html":"\\u003cb\\u003e\\u0026\\u003c/b\\u003e"}\n'


def test_reader_number_typing_floats_via_target_formats():
    """Numbers with a fraction/exponent are floats; others are integers."""
    # CATCHES: 1e3 and 2.0 decode as floats even when integral, which only
    # becomes visible through the toml/kdl writers (json renders them bare).
    doc = '{"f":2.0,"g":1e3}'
    res = run_dasel(["-i", "json", "-o", "toml"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == "f = 2.0\ng = 1000.0\n"

    res = run_dasel(["-i", "json", "-o", "kdl"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == "f 2.0\ng 1000.0\n"

    res = run_dasel(["-i", "json", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"f":2,"g":1000}\n'


def test_reader_int64_overflow_is_an_error():
    """An integer literal outside int64 range fails with the strconv error."""
    # CATCHES: numbers are decoded with UseNumber and converted via
    # strconv.ParseInt, so out-of-range integers are fatal rather than
    # becoming floats.
    res = run_dasel(
        ["-i", "json", "-o", "json"],
        input=b'{"n":12345678901234567890}',
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: could not decode object: "
        'strconv.ParseInt: parsing "12345678901234567890": value out of range\n'
    )


def test_ndjson_input_creates_multi_document_output():
    """Whitespace-separated JSON values become a branch (multi-document)."""
    # CATCHES: the reader loops over decoder.More(), returning a
    # branch-marked slice that the multi-document writer joins with a newline
    # separator.
    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact"], input=b'1 2 3'
    )
    assert res.exit_code == 0
    assert res.out == "1\n\n2\n\n3\n"

    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact"], input=b'{"a":1} {"b":2}'
    )
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n\n{"b":2}\n'


@pytest.mark.parametrize(
    "doc,expected_err",
    [
        (
            b'{"bad":',
            "dasel: error: error reading input: could not decode object: EOF\n",
        ),
        (
            b"not json",
            "dasel: error: error reading input: json: invalid character o as null\n",
        ),
    ],
)
def test_malformed_json_errors(doc, expected_err):
    """Malformed JSON exits 1 with the exact decoder error message."""
    # CATCHES: truncated input reports EOF from inside object decoding while
    # a bare word reports the goccy invalid-character error.
    res = run_dasel(["-i", "json", "-o", "json"], input=doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == expected_err


def test_string_escapes_and_unicode_passthrough():
    """Control characters are escaped; multibyte runes pass through raw."""
    # CATCHES: the writer re-encodes strings via the json encoder, escaping
    # \t and control chars as \uXXXX but never ASCII-escaping non-ASCII.
    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact"],
        input=b'{"k":"a\\tb\\u0001c","emoji":"\\ud83d\\ude00"}',
    )
    assert res.exit_code == 0
    assert res.out == '{"k":"a\\tb\\u0001c","emoji":"\U0001f600"}\n'


def test_nesting_depth_limit():
    """Nesting deeper than 10000 fails; the boundary value still parses."""
    # CATCHES: the maxJSONDepth guard producing "json nesting depth exceeded"
    # wrapped by "could not decode object".
    deep = b'{"a":' * 10001 + b"1" + b"}" * 10001
    res = run_dasel(["-i", "json", "-o", "json", "--compact"], input=deep)
    assert res.exit_code == 1
    assert res.err == (
        "dasel: error: error reading input: could not decode object: "
        "json nesting depth exceeded\n"
    )

    ok = b'{"a":' * 9999 + b"1" + b"}" * 9999
    res = run_dasel(["-i", "json", "-o", "json", "--compact"], input=ok)
    assert res.exit_code == 0
    assert res.err == ""


def test_empty_input_yields_null():
    """No stdin content means the reader never runs and null is written."""
    # CATCHES: run() only invokes the reader when input bytes exist, so empty
    # stdin produces the null document instead of a parse error.
    res = run_dasel(["-i", "json", "-o", "json"], input=b"")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "null\n"
