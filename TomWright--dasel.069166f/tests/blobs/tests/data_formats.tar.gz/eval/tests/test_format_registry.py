"""Registry behaviour implemented by parsing/format.go.

Covers the parts of the format registry that are reachable from the CLI:
the writer-constructor error branch of ``Format.NewWriter`` (surfaced as
``failed to get output writer``), case-sensitive format-name lookup, and the
reader registry contents exposed through the ``completion`` command (the only
non-interactive caller of ``RegisteredReaders``).
"""

import pytest

from conftest import run_dasel

# The complete `dasel completion bash` script, recorded byte-for-byte from the
# reference binary. The data_formats-relevant part is the `local formats=...`
# line, which is the sorted list of registered READER formats: plain is absent
# because it is write-only.
BASH_COMPLETION = """#!/bin/bash

_dasel() {
    local cur prev words cword
    _init_completion || return

    local commands="query version interactive completion man"
    local formats="csv dasel hcl ini json kdl toml xml yaml"
    local shells="bash zsh fish powershell"

    # Find if a subcommand has been specified
    local cmd=""
    for ((i=1; i < cword; i++)); do
        case "${words[i]}" in
            query|version|interactive|completion|man)
                cmd="${words[i]}"
                break
                ;;
        esac
    done

    # Complete format names for --in/--out/-i/-o
    case "${prev}" in
        --in|--out|-i|-o)
            COMPREPLY=($(compgen -W "${formats}" -- "${cur}"))
            return
            ;;
    esac

    if [[ "${cur}" == -* ]]; then
        local flags=""
        case "${cmd}" in
            "")
                # No subcommand yet: offer global flags + query flags (default command)
                flags="--help --var --rw-flag --read-flag --write-flag --in -i --out -o --root --compact --unstable --it --config -c "
                ;;
            query)
                flags="--help --var --rw-flag --read-flag --write-flag --in -i --out -o --root --compact --unstable --it --config -c "
                ;;
            version)
                flags="--help "
                ;;
            interactive)
                flags="--help --var --rw-flag --read-flag --write-flag --in -i --out -o --config -c "
                ;;
            completion)
                flags="--help "
                ;;
            man)
                flags="--help "
                ;;
        esac
        COMPREPLY=($(compgen -W "${flags}" -- "${cur}"))
        return
    fi

    # If no subcommand yet, complete with subcommand names
    if [[ -z "${cmd}" ]]; then
        COMPREPLY=($(compgen -W "${commands}" -- "${cur}"))
    fi
}

complete -F _dasel dasel
"""

# The exact full line each completion template renders for the registered
# reader format list. Every shell renders the same registry contents, in a
# shell-specific syntax, and none of them contains "plain" or "toml" ordering
# surprises: the list is sorted and excludes the write-only plain format.
FORMAT_LIST_LINE = {
    "bash": '    local formats="csv dasel hcl ini json kdl toml xml yaml"',
    "zsh": "    formats=(csv dasel hcl ini json kdl toml xml yaml )",
    "fish": "complete -c dasel -l in -xa 'csv dasel hcl ini json kdl toml xml yaml'",
    "powershell": (
        "    $formats = @('csv', 'dasel', 'hcl', 'ini', "
        "'json', 'kdl', 'toml', 'xml', 'yaml', '')"
    ),
}


def test_completion_bash_script_lists_registered_reader_formats():
    """`completion bash` emits the full script including the reader format list."""
    # CATCHES: the registry exposes exactly nine reader formats, sorted, with
    # the write-only `plain` format absent from the completion list.
    res = run_dasel(["completion", "bash"])
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == BASH_COMPLETION


@pytest.mark.parametrize("shell", ["bash", "zsh", "fish", "powershell"])
def test_completion_format_list_matches_reader_registry(shell):
    """Every shell completion renders the same registered reader format list."""
    # CATCHES: all four templates are fed from the single reader registry, so
    # a re-implementation that registers a different reader set (or forgets
    # that plain has no reader) renders a different list in every shell.
    res = run_dasel(["completion", shell])
    assert res.exit_code == 0
    assert res.err == ""
    expected = FORMAT_LIST_LINE[shell]
    assert expected in res.out.splitlines()


@pytest.mark.parametrize("delimiter", [";;", "§§"])
def test_writer_constructor_error_wrapped_as_failed_to_get_output_writer(delimiter):
    """A failing writer constructor surfaces as `failed to get output writer`."""
    # CATCHES: Format.NewWriter wraps constructor errors (here the csv
    # single-character delimiter check) in `failed to get output writer`,
    # unlike reader errors which say `failed to get input reader`; the error
    # is raised before any input is parsed, so stdout stays empty.
    res = run_dasel(
        ["-i", "json", "-o", "csv", "--write-flag", f"csv-delimiter={delimiter}"],
        input=b'[{"a":1}]',
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: failed to get output writer: "
        f'csv-delimiter must be a single character, got "{delimiter}"\n'
    )


def test_single_character_write_delimiter_is_accepted():
    """A one-character csv-delimiter write flag builds the writer fine."""
    # CATCHES: the constructor error branch is only for delimiters that are
    # not exactly one rune; `;` is accepted and re-separates the output.
    res = run_dasel(
        ["-i", "json", "-o", "csv", "--write-flag", "csv-delimiter=;"],
        input=b'[{"a":"x;y"}]',
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == 'a\n"x;y"\n'


def test_format_names_are_case_sensitive():
    """Format lookup is exact: uppercase names are unsupported formats."""
    # CATCHES: the registry keys are the lowercase format names, so `JSON`
    # does not resolve and the raw name is echoed back in the error.
    res = run_dasel(["-i", "JSON", "-o", "json", "--compact"], input=b"1")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == "dasel: error: failed to get input reader: unsupported reader file format: JSON\n"

    res = run_dasel(["-i", "json", "-o", "JSON", "--compact"], input=b"1")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == "dasel: error: failed to get output writer: unsupported writer file format: JSON\n"
