"""Cross-format conversion: every source/target pair among the formats that
can express a simple string-key/string-value document, plus typed documents
through the json hub and CSV's slice-of-rows model.

All expected bytes were recorded from the reference binary.
"""

import json as jsonlib

import pytest

from conftest import run_dasel

# The same {"k": "v"} document written in every text format that can
# represent it. plain (scalar-only) and csv (slice-of-rows) are excluded and
# covered separately below.
SIMPLE_SOURCES = {
    "json": '{"k":"v"}',
    "yaml": "k: v\n",
    "toml": "k = 'v'\n",
    "xml": "<k>v</k>",
    "hcl": 'k = "v"\n',
    "ini": "k = v\n",
    "kdl": 'k "v"\n',
}

# The recorded output of converting that document to each target format.
SIMPLE_TARGETS = {
    "json": '{\n    "k": "v"\n}\n',
    "yaml": "k: v\n",
    "toml": "k = 'v'\n",
    "xml": "<k>v</k>\n",
    "hcl": 'k = "v"\n',
    "ini": "k = v\n",
    "kdl": 'k "v"\n',
}


@pytest.mark.parametrize("source", sorted(SIMPLE_SOURCES))
def test_simple_document_every_pair(source):
    """A {k: v} document converts between all 7 x 7 format pairs identically."""
    # CATCHES: the shared value model must normalise every source to the
    # same map, and each writer must emit its canonical form regardless of
    # which reader produced the value.
    for target, expected in SIMPLE_TARGETS.items():
        res = run_dasel(
            ["-i", source, "-o", target],
            input=SIMPLE_SOURCES[source].encode(),
        )
        assert res.exit_code == 0, f"{source}->{target}: {res.err}"
        assert res.out == expected, f"{source}->{target}"
        assert res.err == ""


def test_typed_document_to_each_format():
    """A document with every scalar type converts to each typed format."""
    # CATCHES: type fidelity through the json hub — toml hoists nested maps
    # into a [section] header after the scalars, kdl preserves key order, and
    # hcl aligns attributes and appends blocks after them.
    doc = '{"i":42,"f":1.5,"b":true,"s":"txt","nested":{"x":"1"},"list":[1,"a",true]}'
    expected = {
        "yaml": (
            'i: 42\nf: 1.5\nb: true\ns: txt\nnested:\n    x: "1"\n'
            "list:\n    - 1\n    - a\n    - true\n"
        ),
        "toml": (
            "i = 42\nf = 1.5\nb = true\ns = 'txt'\nlist = [1, 'a', true]\n"
            "\n[nested]\nx = '1'\n"
        ),
        "hcl": (
            'i    = 42\nf    = 1.5\nb    = true\ns    = "txt"\n'
            'list = [1, "a", true]\nnested {\n  x = "1"\n}\n'
        ),
        "kdl": (
            "i 42\nf 1.5\nb #true\ns \"txt\"\nnested x=\"1\"\n"
            "list 1\nlist \"a\"\nlist #true\n"
        ),
    }
    for target, out in expected.items():
        res = run_dasel(["-i", "json", "-o", target], input=doc.encode())
        assert res.exit_code == 0, f"json->{target}: {res.err}"
        assert res.out == out, f"json->{target}"
        assert res.err == ""


def test_typed_document_from_each_format():
    """Every typed source format normalises to the same json model."""
    # CATCHES: the readers for yaml/toml/kdl must produce identical typed
    # output; hcl is compared as a structure because its attribute order is
    # nondeterministic.
    doc_json = (
        '{"i":42,"f":1.5,"b":true,"s":"txt","nested":{"x":"1"},"list":[1,"a",true]}'
    )
    expected = doc_json + "\n"
    for source, doc in [
        (
            "yaml",
            'i: 42\nf: 1.5\nb: true\ns: txt\nnested:\n  x: "1"\n'
            'list:\n  - 1\n  - "a"\n  - true\n',
        ),
        ("toml", 'i = 42\nf = 1.5\nb = true\ns = "txt"\nnested = {x = "1"}\nlist = [1, "a", true]\n'),
        (
            "kdl",
            'i 42\nf 1.5\nb true\ns "txt"\nnested x="1"\nlist 1\nlist "a"\nlist true\n',
        ),
    ]:
        res = run_dasel(
            ["-i", source, "-o", "json", "--compact"], input=doc.encode()
        )
        assert res.exit_code == 0, f"{source}->json: {res.err}"
        assert res.out == expected, f"{source}->json"

    # hcl attribute order is randomised by Go map iteration.
    res = run_dasel(
        ["-i", "hcl", "-o", "json", "--compact"],
        input=b'i = 42\nf = 1.5\nb = true\ns = "txt"\nnested = {x = "1"}\nlist = [1, "a", true]\n',
    )
    assert res.exit_code == 0
    assert jsonlib.loads(res.out) == {
        "i": 42,
        "f": 1.5,
        "b": True,
        "s": "txt",
        "nested": {"x": "1"},
        "list": [1, "a", True],
    }


def test_csv_conversions():
    """CSV converts to and from the slice-of-row-maps model."""
    # CATCHES: csv's value model is a slice of string-maps, so json -> csv
    # stringifies scalars and csv -> json keeps every field a string.
    res = run_dasel(["-i", "csv", "-o", "json", "--compact"], input=b"a,b\n1,2\n")
    assert res.exit_code == 0
    assert res.out == '[{"a":"1","b":"2"}]\n'

    res = run_dasel(
        ["-i", "json", "-o", "csv"], input=b'[{"a":1,"b":"x"}]'
    )
    assert res.exit_code == 0
    assert res.out == "a,b\n1,x\n"
