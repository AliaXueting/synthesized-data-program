"""Shared helpers for the data_formats black-box test module.

Every test drives the reference binary through its CLI only, resolving the
binary via ``PROGRAMGYM_EXECUTABLE`` (never a hardcoded absolute path).
"""

import os
import subprocess
from pathlib import Path

import pytest

# Longest any single dasel invocation is allowed to take. Individual formats
# parse megabyte-scale pathological inputs in well under a second, so this is
# only a safety net to keep the whole suite fast.
DASEL_TIMEOUT = 20

# The full usage banner kong prints to STDOUT when flag parsing fails (exit
# code 80). Recorded byte-for-byte from the reference binary; it is identical
# for every flag-parse failure (unknown flag, malformed --var, malformed
# --read-flag), so tests can assert on it exactly.
KONG_USAGE_STDOUT = (
    "Usage: dasel <command>\n"
    "\n"
    "Query and modify data structures from the command line.\n"
    "\n"
    "Flags:\n"
    "  -h, --help    Show context-sensitive help.\n"
    "\n"
    "Commands:\n"
    "  query          [default] Execute a query\n"
    "  version        Print the version\n"
    "  interactive    Start an interactive session (alpha)\n"
    "  completion     Generate shell completion script\n"
    "  man            Generate man page\n"
    "\n"
    'Run "dasel <command> --help" for more information on a command.\n'
    "\n"
)


def _resolve_executable() -> str:
    """Resolve the dasel binary to invoke."""
    env_val = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if env_val:
        return env_val
    # Fallback for running pytest outside of the pipeline runner: the binary
    # lives at the branch root next to the eval/ directory.
    fallback = Path(__file__).resolve().parents[2] / "executable"
    if fallback.exists():
        return str(fallback)
    pytest.fail(
        "PROGRAMGYM_EXECUTABLE is not set and no ./executable fallback was found"
    )


def _child_env() -> dict:
    """Build a pinned, hermetic environment for the child process."""
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": "/tmp/dasel-test-home",
        "TMPDIR": "/tmp",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TZ": "UTC",
        "TERM": "dumb",
    }
    # Coverage instrumentation hook: forward GOCOVERDIR from the test process
    # so the pipeline can measure source coverage of the reference binary.
    # (Equivalent to: cov_env = {"GOCOVERDIR": v} for v in
    # [os.environ.get("GOCOVERDIR")] if v; env.update(cov_env).)
    gocoverdir = os.environ.get("GOCOVERDIR")
    if gocoverdir:
        env["GOCOVERDIR"] = gocoverdir
    return env


# A config path guaranteed not to exist. dasel resolves its default config
# (~dasel.yaml) through the *system* user database, not $HOME, so the only
# hermetic way to shield tests from a config file on the runner's home
# directory is to pin -c to a missing file, which dasel treats as "use the
# built-in defaults". Tests that exercise config loading pass -c explicitly.
_MISSING_CONFIG = "/nonexistent-programgym/dasel-test-config.yaml"

_CONFIG_FLAGS = {"-c", "--config"}

# Subcommands that do not accept the -c flag (it is defined on the query
# command only). "query" itself is fine because kong reorders flags.
_NO_CONFIG_COMMANDS = {"version", "interactive", "completion", "man"}


def _has_config_flag(args) -> bool:
    """Return True if the invocation already selects a config file."""
    if args and args[0] in _NO_CONFIG_COMMANDS:
        return True
    for i, a in enumerate(args):
        if a in _CONFIG_FLAGS:
            return True
        if a.startswith("--config=") or a.startswith("-c="):
            return True
    return False


class DaselResult:
    """Wrapper around a completed dasel invocation."""

    def __init__(self, proc: subprocess.CompletedProcess):
        self.stdout = proc.stdout
        self.stderr = proc.stderr
        self.exit_code = proc.returncode

    @property
    def out(self) -> str:
        return self.stdout.decode("utf-8")

    @property
    def err(self) -> str:
        return self.stderr.decode("utf-8")


def run_dasel(
    args,
    input: bytes = b"",
    cwd=None,
    timeout: int = DASEL_TIMEOUT,
    env_extra: dict = None,
) -> DaselResult:
    """Run the dasel binary with ``args`` and ``input`` on stdin.

    Returns a :class:`DaselResult` carrying stdout/stderr bytes and the exit
    code, so tests can assert on exact recorded behaviour.
    """
    exe = _resolve_executable()
    env = _child_env()
    if env_extra:
        env.update(env_extra)

    args = list(args)
    if not _has_config_flag(args):
        args = ["-c", _MISSING_CONFIG] + args

    proc = subprocess.run(
        [exe] + args,
        input=input,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        cwd=cwd,
        timeout=timeout,
    )
    return DaselResult(proc)


def write_input_file(tmp_path, name: str, content: str) -> str:
    """Write ``content`` to ``tmp_path/name`` and return the absolute path."""
    path = tmp_path / name
    path.write_text(content, encoding="utf-8")
    return str(path)
