"""Multi-document output (parsing/writer.go MultiDocumentWriter): document
separators per format, the --unstable gate on branch expressions, and
per-document error wrapping.
"""

import pytest

from conftest import run_dasel


def test_branch_requires_unstable():
    """branch() is rejected without --unstable with the exact message."""
    # CATCHES: the unstable gate on BranchExpr AST nodes.
    res = run_dasel(
        ["-i", "json", "-o", "json", "--compact", "branch(a,b)"],
        input=b'{"a":1,"b":2}',
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error executing selector: error evaluating expression "
        "ast.BranchExpr: unstable ast types are not enabled. to enable them "
        "use --unstable\n"
    )


@pytest.mark.parametrize(
    "out_format,doc,expected",
    [
        ("json", b'{"a":1,"b":2}', "1\n\n2\n"),
        ("toml", b'{"a":1,"b":2}', "1\n\n2\n"),
        ("yaml", b'{"a":1,"b":2}', "1\n---\n2\n"),
        ("kdl", b'{"a":1,"b":2}', "root 1\n\nroot 2\n"),
        # xml, ini and hcl require map roots, so the branch documents are
        # maps (a bare string root renders as an empty xml document).
        ("xml", b'{"a":{"x":"1"},"b":{"y":"2"}}', "<x>1</x>\n\n<y>2</y>\n"),
        ("ini", b'{"a":{"x":"1"},"b":{"y":"2"}}', "x = 1\n\ny = 2\n"),
        ("hcl", b'{"a":{"x":"1"},"b":{"y":"2"}}', 'x = "1"\n\ny = "2"\n'),
        ("plain", b'{"a":1,"b":2}', "1\n2\n"),
    ],
)
def test_document_separator_per_format(out_format, doc, expected):
    """Each writer joins branch documents with its own separator."""
    # CATCHES: yaml overrides the separator to "---\n" and plain to none,
    # while every other format uses the default "\n" (a blank line between
    # documents since each document already ends in a newline).
    res = run_dasel(
        ["-i", "json", "-o", out_format, "--unstable", "branch(a,b)"],
        input=doc,
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == expected


@pytest.mark.parametrize(
    "out_format,expected_err",
    [
        (
            "xml",
            "dasel: error: error writing output: failed to write document 0: "
            "failed to convert to element: xml writer does not support "
            "value type: int\n",
        ),
        (
            "csv",
            "dasel: error: error writing output: failed to write document 0: "
            "csv writer expects root output to be a slice/array, got int\n",
        ),
    ],
)
def test_per_document_error_wrapping(out_format, expected_err):
    """Writer failures inside a branch name the failing document index."""
    # CATCHES: MultiDocumentWriter wraps each document's error as
    # "failed to write document %d" before the inner writer's message.
    res = run_dasel(
        [
            "-i", "json", "-o", out_format, "--compact",
            "--unstable", "branch(a,b)",
        ],
        input=b'{"a":1,"b":2}',
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == expected_err
