"""KDL lexical/syntactic surface (parsing/kdl/internal/tokenizer.go and
parser.go): node terminators, slash-dash omission, comments, line
continuation, v1/v2 keywords and raw strings, multi-line strings with
dedenting, escape sequences, number bases, type annotations, the
`/- kdl-version` marker and the exact text/position of parse errors.
"""

import pytest

from conftest import run_dasel

# Every reader error is wrapped by these two fixed prefixes.
READ_ERR = "dasel: error: error reading input: kdl: parse error: "


def read_kdl(doc: bytes):
    """Read a KDL document and render it as compact JSON."""
    return run_dasel(["-i", "kdl", "-o", "json", "--compact"], input=doc)


def test_node_terminator_semicolons():
    """Semicolons terminate nodes, including several per line and in children."""
    # CATCHES: `;` is a node terminator on par with a newline, so multiple
    # nodes can share one line and a trailing semicolon is not an error.
    res = read_kdl(b"a 1; b 2; c 3\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1,"b":2,"c":3}\n'

    res = read_kdl(b"a 1 ; b 2\n")
    assert res.exit_code == 0
    assert res.out == '{"a":1,"b":2}\n'

    res = read_kdl(b"a 1;\n")
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n'

    res = read_kdl(b"a { b 1; c 2 }\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"b":1,"c":2}}\n'


def test_slashdash_omits_nodes_args_props_and_children():
    """`/-` omits the next node, argument, property or children block."""
    # CATCHES: slash-dash applies to exactly one following entry (so `a 1 /- 2 3`
    # keeps argument 3), and an omitted children block leaves a bare node.
    res = read_kdl(b"/- a 1\nb 2\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"b":2}\n'

    res = read_kdl(b"a 1 /- 2 3\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"$args":[1,3]}}\n'

    res = read_kdl(b"a k=1 /- k2=2\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"k":1}}\n'

    res = read_kdl(b"a /- { b 1 }\n")
    assert res.exit_code == 0
    assert res.out == '{"a":null}\n'

    res = read_kdl(b"a /- (i64)5 6\n")
    assert res.exit_code == 0
    assert res.out == '{"a":6}\n'


def test_line_comments_block_comments_and_nesting():
    """`//` line comments and (nestable) `/* */` block comments are skipped."""
    # CATCHES: block comments nest, and comments are skipped between a node
    # name and its entries, not only at line starts.
    res = read_kdl(b"// hello\na 1\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1}\n'

    res = read_kdl(b"/* hello */ a 1\n")
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n'

    res = read_kdl(b"/* a /* b */ c */ a 1\n")
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n'

    res = read_kdl(b"a /* mid */ 1\n")
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n'

    res = read_kdl(b"a { // c\n  b 1 /* d */\n}\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"b":1}}\n'


def test_unterminated_block_comment_swallows_rest_of_document():
    """An unterminated block comment consumes everything and yields `{}`."""
    # CATCHES: the block-comment scanner runs to EOF without erroring, so the
    # document parses successfully as an empty node list rather than failing.
    res = read_kdl(b"/* abc\na 1\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "{}\n"


def test_line_continuation_backslash_newline():
    """A backslash immediately before a newline joins the two lines."""
    # CATCHES: `\\\n` is dropped by the tokenizer, so an argument list can be
    # split across lines without producing a new node.
    res = read_kdl(b"a \\\n  1\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1}\n'

    res = read_kdl(b"a 1 \\\n  2\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"$args":[1,2]}}\n'


def test_crlf_line_endings():
    """CRLF and lone CR are treated as line breaks."""
    # CATCHES: `\r\n` counts as one newline token, so nodes separated by CRLF
    # land in the same map instead of merging into one node's entries.
    res = read_kdl(b"a 1\r\nb 2\r\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1,"b":2}\n'


def test_v2_hash_keywords():
    """v2 `#true`/`#false`/`#null` decode to real scalars."""
    # CATCHES: the `#`-prefixed v2 keywords are recognized as values, not as
    # part of a bare identifier.
    res = read_kdl(b"a #true #false #null\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":{"$args":[true,false,null]}}\n'

    res = read_kdl(b"a #true\nb #false\nc #null\n")
    assert res.exit_code == 0
    assert res.out == '{"a":true,"b":false,"c":null}\n'


@pytest.mark.parametrize(
    "doc,expected",
    [
        (b"a #unknown\n", "kdl: unexpected # character at line 1, col 4"),
        (b"a #infinitive\n", "kdl: unexpected # character at line 1, col 4"),
        (b"a ##foo\n", "kdl: unexpected # character at line 1, col 3"),
    ],
)
def test_hash_keyword_errors(doc, expected):
    """A `#` that starts neither a keyword nor a raw string is an error."""
    # CATCHES: `#` only introduces the six keywords or a raw string; anything
    # else (including a keyword extended with identifier characters) fails
    # with `unexpected # character` at the `#` position.
    res = read_kdl(doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + expected + "\n"


def test_v2_raw_strings():
    """`#"…"#` raw strings keep quotes verbatim and match the hash count."""
    # CATCHES: the closing delimiter must have the same number of hashes as
    # the opening one, and embedded `"` characters need no escaping.
    res = read_kdl(b'a #"raw"#\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"raw"}\n'

    res = read_kdl(b'a ##"raw"##\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"raw"}\n'

    res = read_kdl(b'a #"has "quotes" inside"#\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"has \\"quotes\\" inside"}\n'


def test_v2_multiline_raw_strings():
    """`#\"\"\"…\"\"\"#` raw blocks dedent by the closing line's indentation."""
    # CATCHES: multi-line raw strings strip the closing line's indent from
    # every line, and interior `"`/`#` characters survive untouched.
    res = read_kdl(b'a #"""\n  line1\n  line2\n  """#\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"line1\\nline2"}\n'

    res = read_kdl(b'a #"""\n  has "quotes" and #hashes\n  """#\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"has \\"quotes\\" and #hashes"}\n'

    res = read_kdl(b'a #"""\n  x""y\n  """#\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"x\\"\\"y"}\n'


def test_multiline_basic_strings():
    """`\"\"\"…\"\"\"` blocks dedent, keep blank lines and process escapes."""
    # CATCHES: dedenting uses the last line's whitespace prefix, an interior
    # blank line is preserved, and escape sequences still apply (unlike raw
    # strings), while the closing `\"\"\"` may sit on a content line.
    res = read_kdl(b'a """\n  line1\n  line2\n  """\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"line1\\nline2"}\n'

    res = read_kdl(b'a """\n      line1\n        line2\n      """\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"line1\\n  line2"}\n'

    res = read_kdl(b'a """\n  x\n\n  y\n  """\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"x\\n\\ny"}\n'

    res = read_kdl(b'a """\nx\ny\n"""\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"x\\ny"}\n'

    res = read_kdl(b'a """\n  x\n  y"""\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"x\\ny"}\n'

    res = read_kdl(b'a """\n  a\\tb\n  c\\\\d\n  """\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"a\\tb\\nc\\\\d"}\n'


@pytest.mark.parametrize(
    "doc,expected",
    [
        (b'a """x\n', "kdl: multi-line string opening must be followed by newline at line 1, col 6"),
        (b'a """\nabc\n', "kdl: unterminated multi-line string at line 3, col 1"),
        (b'a """\nx\nb 1\n', "kdl: unterminated multi-line string at line 4, col 1"),
    ],
)
def test_multiline_string_errors(doc, expected):
    """Multi-line strings must open with a newline and must be closed."""
    # CATCHES: `\"\"\"` not followed by a newline is rejected up front, and an
    # unclosed block reports the position one past the consumed input.
    res = read_kdl(doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + expected + "\n"


def test_v1_raw_strings():
    """`r\"…\"` and `r#\"…\"#` keep backslashes and quotes verbatim."""
    # CATCHES: raw strings do not process escapes (`\n` stays two characters)
    # while a hash-delimited raw string may contain unescaped quotes.
    res = read_kdl(b'a r"abc\\ndef"\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"abc\\\\ndef"}\n'

    res = read_kdl(b'a r#"a "b" c"#\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"a \\"b\\" c"}\n'


def test_string_escapes():
    r"""All single-character escapes plus the v2 backslash-s space escape."""
    # CATCHES: `\s` is a v2 escape for a literal space, and Go's JSON writer
    # renders the decoded `\b`/`\f` as \u0008/\u000c rather than \b/\f.
    res = read_kdl(b'a "\\n\\r\\t\\\\\\"\\b\\f\\s"\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.stdout == b'{"a":"\\n\\r\\t\\\\\\"\\u0008\\u000c "}\n'


def test_unicode_escapes():
    r"""Braced unicode escapes decode to the rune they name."""
    # CATCHES: unicode escapes accept any number of hex digits (not only 4)
    # and are re-encoded as UTF-8 in the output.
    res = read_kdl(b'a "\\u{1F600}"\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"😀"}\n'

    res = read_kdl(b'a "\\u{41}"\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"A"}\n'


@pytest.mark.parametrize(
    "doc,expected",
    [
        (b'a "\\q"\n', "kdl: unknown escape sequence: \\q at line 1, col 6"),
        (b'a "\\u 41"\n', "kdl: expected '{' in unicode escape at line 1, col 6"),
        (b'a "\\u{41"\n', "kdl: unterminated unicode escape at line 2, col 1"),
        (b'a "\\u{ZZ}"\n', "kdl: invalid unicode escape: ZZ at line 1, col 10"),
        (b'a "\\u{D800}"\n', "kdl: invalid unicode code point: U+D800 at line 1, col 12"),
        (b'a "abc\\', "kdl: unterminated escape sequence at line 1, col 8"),
        (b'a "line1\nline2"\n', "kdl: unexpected newline in string (use multi-line string or \\n) at line 2, col 1"),
        (b'a "abc\n', "kdl: unexpected newline in string (use multi-line string or \\n) at line 2, col 1"),
        (b'a "abc', "kdl: unterminated string at line 1, col 7"),
        (b'a r"', "kdl: unterminated raw string at line 1, col 5"),
        (b'a r"abc\n', "kdl: unterminated raw string at line 2, col 1"),
    ],
)
def test_string_and_escape_errors(doc, expected):
    """Malformed escapes and strings fail with positioned error messages."""
    # CATCHES: each failure mode has its own message and column, e.g. a bare
    # newline inside a basic string suggests the multi-line form, and an EOF
    # inside an escape is reported one column past the backslash.
    res = read_kdl(doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + expected + "\n"


def test_number_bases_underscores_and_exponents():
    """Hex/octal/binary literals, `_` separators and exponents all decode."""
    # CATCHES: 0x/0o/0b prefixes parse in their own base (signed too),
    # underscores are ignored, and `e`/`E` exponents make a float.
    res = read_kdl(b"a 0x1F 0o17 0b101 1_000 1.5e10 1e+3 -5 +7\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":{"$args":[31,15,5,1000,15000000000,1000,-5,7]}}\n'

    res = read_kdl(b"a -0x10 +0b11 0xFF_FF\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"$args":[-16,3,65535]}}\n'


def test_number_literal_quirks():
    """Leading zeros stay decimal and a second `.` becomes an identifier."""
    # CATCHES: `08` is a decimal 8 (no octal-inference), and after `1.2` the
    # trailing `.3` no longer starts a number, so it lexes as the bare
    # identifier ".3" and is kept as a string argument.
    res = read_kdl(b"a 08 1.2.3\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":{"$args":[8,1.2,".3"]}}\n'


@pytest.mark.parametrize(
    "doc,expected",
    [
        (b"a 0x\n", 'kdl: invalid hex integer "0x": strconv.ParseInt: parsing "": invalid syntax'),
        (b"a 0o8\n", 'kdl: invalid octal integer "0o": strconv.ParseInt: parsing "": invalid syntax'),
        (b"a 0b2\n", 'kdl: invalid binary integer "0b": strconv.ParseInt: parsing "": invalid syntax'),
        (
            b"a 99999999999999999999\n",
            'kdl: invalid integer "99999999999999999999": '
            'strconv.ParseInt: parsing "99999999999999999999": value out of range',
        ),
        (
            b"a 1.5e999999\n",
            'kdl: invalid float "1.5e999999": '
            'strconv.ParseFloat: parsing "1.5e999999": value out of range',
        ),
    ],
)
def test_number_errors(doc, expected):
    """Bad bases and out-of-range numbers fail with the strconv message."""
    # CATCHES: the tokenizer stops a base literal at the first invalid digit,
    # so `0o8` reports the value as "0o", and int64/float64 overflows surface
    # the underlying strconv error text verbatim.
    res = read_kdl(doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + expected + "\n"


def test_signed_identifiers_and_bare_signs():
    """A sign followed by a non-digit lexes as a bare identifier string."""
    # CATCHES: `-tag`, `--flag` and `+.` are not numbers and not errors; they
    # become string arguments, and a lone `-` at EOF is the string "-".
    res = read_kdl(b"a -tag --flag +.\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":{"$args":["-tag","--flag","+."]}}\n'

    res = read_kdl(b"a -\n")
    assert res.exit_code == 0
    assert res.out == '{"a":"-"}\n'


def test_inf_nan_keywords_and_the_minus_inf_quirk():
    """`inf`/`nan` are floats, but `-inf` lexes as the string "-inf"."""
    # CATCHES: only the unsigned keywords are recognized by the number lexer,
    # so `-inf` is tokenized as a bare identifier and survives as a string;
    # the float keywords themselves cannot be rendered by the JSON writer.
    res = read_kdl(b"a inf\n")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == "dasel: error: error writing output: json: unsupported value: +Inf\n"

    res = read_kdl(b"a nan\n")
    assert res.exit_code == 1
    assert res.err == "dasel: error: error writing output: json: unsupported value: NaN\n"

    res = read_kdl(b"a -inf\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"-inf"}\n'

    res = run_dasel(["-i", "kdl", "-o", "kdl"], input=b"a inf -inf nan\n")
    assert res.exit_code == 0
    assert res.out == 'a #inf "-inf" #nan\n'

    res = run_dasel(["-i", "kdl", "-o", "yaml"], input=b"a inf\n")
    assert res.exit_code == 0
    assert res.out == "a: !!float +Inf\n"


def test_version_marker():
    """A leading `/- kdl-version N` marker is accepted for both versions."""
    # CATCHES: the marker is only honoured at the very start of the document,
    # and both version 1 and 2 parse the same node content.
    res = read_kdl(b"/- kdl-version 1\na 1\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1}\n'

    res = read_kdl(b"/- kdl-version 2\na 1\n")
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n'

    res = read_kdl(b"a 1\n/- kdl-version 3\n")
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n'


@pytest.mark.parametrize(
    "doc,expected",
    [
        (b"/- kdl-version 3\na 1\n", 'kdl: unsupported version "3" in version marker'),
        (b"/- kdl-version \na 1\n", 'kdl: unsupported version "" in version marker'),
    ],
)
def test_version_marker_errors(doc, expected):
    """An unsupported version marker value is rejected before parsing."""
    # CATCHES: only "1" and "2" are valid marker values; an empty value is
    # rejected too, and the message quotes the raw verStr.
    res = read_kdl(doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + expected + "\n"


def test_type_annotations_on_nodes_args_and_props():
    """`(type)` annotations are parsed everywhere and then dropped."""
    # CATCHES: annotations are accepted before the node name, before an
    # argument, and after `=` in a property, and never change the value.
    res = read_kdl(b'(date)a "2020-01-01"\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"2020-01-01"}\n'

    res = read_kdl(b'a (i64)5 (date)"2020-01-01"\n')
    assert res.exit_code == 0
    assert res.out == '{"a":{"$args":[5,"2020-01-01"]}}\n'

    res = read_kdl(b"a k=(i64)5\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"k":5}}\n'


@pytest.mark.parametrize(
    "doc,expected",
    [
        (b"(=)a 1\n", "kdl: expected type name, got 21 at line 1, col 2"),
        (b"(a b)a 1\n", "kdl: expected ')', got 2 at line 1, col 4"),
    ],
)
def test_type_annotation_errors(doc, expected):
    """Malformed annotations report the offending token code and position."""
    # CATCHES: the message prints the numeric token type (21 is `=`, 2 is an
    # identifier) rather than its text, at the token's own column.
    res = read_kdl(doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + expected + "\n"


@pytest.mark.parametrize(
    "doc,expected",
    [
        (b"a { b } c\n", "kdl: expected node terminator, got 2 at line 1, col 9"),
        (b"a 1 { b } 2\n", "kdl: expected node terminator, got 6 at line 1, col 11"),
        (b"a { b 1\n", "kdl: expected '}', got 0 at line 2, col 1"),
        (b"a /- { b 1\n", "kdl: expected '}' after slashdashed children"),
        (b"[1]\n", "kdl: unexpected character: [ at line 1, col 1"),
        (b"a 1, 2\n", "kdl: unexpected character: , at line 1, col 4"),
        (b"/- \"abc", "kdl: expected node name, got 0 at line 1, col 8"),
        (b'(date)"abc', "kdl: unterminated string at line 1, col 11"),
    ],
)
def test_structural_parse_errors(doc, expected):
    """Structural mistakes fail with their exact token code and position."""
    # CATCHES: a node must end right after its children block, an unclosed
    # block reports EOF as token 0, and after `/-` or `(type)` the next token
    # must be a node name — the swallowed-tokenizer-error path even reports
    # EOF (token 0) for an unterminated string there.
    res = read_kdl(doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + expected + "\n"


def test_quoted_raw_and_spaced_node_names_and_property_keys():
    """Node names and property keys may be quoted or raw strings."""
    # CATCHES: `r"name" 1` defines a node literally called `name`, a quoted
    # name may contain spaces, and a quoted property key works after `=`.
    res = read_kdl(b'r"name" 1\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"name":1}\n'

    res = read_kdl(b'"quoted name" 1\n')
    assert res.exit_code == 0
    assert res.out == '{"quoted name":1}\n'

    res = read_kdl(b'a "key"=1\n')
    assert res.exit_code == 0
    assert res.out == '{"a":{"key":1}}\n'


def test_empty_whitespace_and_comment_only_documents():
    """Empty input is null; whitespace- or comment-only input is `{}`."""
    # CATCHES: zero-byte stdin never reaches the reader (the CLI keeps its
    # null default), while any non-empty document with no nodes decodes to an
    # empty map.
    res = read_kdl(b"")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "null\n"

    res = read_kdl(b"   \n\n  \n")
    assert res.exit_code == 0
    assert res.out == "{}\n"

    res = read_kdl(b"// hi\n")
    assert res.exit_code == 0
    assert res.out == "{}\n"


def test_tokenizer_error_on_leading_token_is_swallowed():
    """An unterminated first token silently yields an empty/partial document."""
    # CATCHES: the document loop skips newlines before peeking a node, and
    # that skip swallows tokenizer errors — so an unterminated string at the
    # start of a document (or of a later line) is dropped instead of failing,
    # and re-lexing resumes after the consumed characters.
    res = read_kdl(b'"abc')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "{}\n"

    res = read_kdl(b'r#"abc')
    assert res.exit_code == 0
    assert res.out == "{}\n"

    res = read_kdl(b'a 1\n"abc')
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n'

    res = read_kdl(b'"a\\qb')
    assert res.exit_code == 0
    assert res.out == '{"b":null}\n'


def test_hash_and_raw_string_delimiter_edges():
    """Raw-string delimiters need their quote, and partial hash runs are kept."""
    # CATCHES: `r#` must be followed by a quote, a closing `"` followed by
    # fewer hashes than the opening run is literal content, and an opening
    # `#"` left unterminated at EOF still reports its own error while an
    # empty `""` at EOF is a valid empty string.
    res = read_kdl(b"a r#1\n")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + "kdl: expected '\"' after r and hashes at line 1, col 5\n"

    res = read_kdl(b'a #"')
    assert res.exit_code == 1
    assert res.err == READ_ERR + "kdl: unterminated raw string at line 1, col 5\n"

    res = read_kdl(b'a r##"a"#b"##\n')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"a\\"#b"}\n'

    res = read_kdl(b'a ##"a"#b"##\n')
    assert res.exit_code == 0
    assert res.out == '{"a":"a\\"#b"}\n'

    res = read_kdl(b'a ""')
    assert res.exit_code == 0
    assert res.out == '{"a":""}\n'


def test_number_base_edges_and_false_keyword():
    """Underscores and signs apply to every base; lowercase hex works too."""
    # CATCHES: `_` separators are accepted inside octal/binary literals as
    # well as hex, a leading `+` is stripped for every base, and the v1
    # `false` keyword decodes to a boolean exactly like `true` does.
    res = read_kdl(b"a 0o1_7 0b1_0 0xff\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":{"$args":[15,2,255]}}\n'

    res = read_kdl(b"a +0x10 +0o7\n")
    assert res.exit_code == 0
    assert res.out == '{"a":{"$args":[16,7]}}\n'

    res = read_kdl(b"a false\n")
    assert res.exit_code == 0
    assert res.out == '{"a":false}\n'


@pytest.mark.parametrize(
    "doc,expected",
    [
        (b"a (=)1\n", "kdl: expected type name, got 21 at line 1, col 4"),
        (b"a /- (=)1 2\n", "kdl: expected type name, got 21 at line 1, col 7"),
        (b"a k={1}\n", "kdl: unexpected token 17 for value at line 1, col 5"),
        (b"a k=[1]\n", "kdl: unexpected character: [ at line 1, col 5"),
        (b"a { b } [1]\n", "kdl: unexpected character: [ at line 1, col 9"),
        (b"/- [1]\n", "kdl: unexpected character: [ at line 1, col 4"),
        (b"a /- [1]\n", "kdl: unexpected character: [ at line 1, col 6"),
        (b"a /- { [1] }\n", "kdl: unexpected character: [ at line 1, col 8"),
        (b"a /- k=[1] 2\n", "kdl: unexpected character: [ at line 1, col 8"),
        (b"(date)[1]\n", "kdl: unexpected character: [ at line 1, col 7"),
        (b"a (i64)[1]\n", "kdl: unexpected character: [ at line 1, col 8"),
    ],
)
def test_bad_token_error_position_by_parse_state(doc, expected):
    """A bad token is reported at a different column from each parse state."""
    # CATCHES: every parser position that reads a fresh token (after a node
    # name, after `=`, after a children block, after `/-`, inside a type
    # annotation) surfaces the same tokenizer error at its own column, and a
    # `{` used as a property value is rejected as "unexpected token 17".
    res = read_kdl(doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == READ_ERR + expected + "\n"
