"""YAML reader and writer behaviour (parsing/yaml/yaml_reader.go and
yaml_writer.go): multi-document streams, anchors/aliases with their expansion
limits, integer literal formats, writer quoting rules and flow style.
"""

import pytest

from conftest import run_dasel


def test_scalar_and_collection_types_to_json():
    """Scalars, flow sequences and flow maps decode to typed json values."""
    # CATCHES: yaml bool/int/float/null typing (not everything a string) and
    # nested collection support.
    doc = "a: 1\nb: true\nc: 1.5\nd: null\ne: \"str\"\nf: [1, 2]\ng: {x: 1}\n"
    res = run_dasel(["-i", "yaml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":1,"b":true,"c":1.5,"d":null,"e":"str","f":[1,2],"g":{"x":1}}\n'


def test_multi_document_read_and_write_separator():
    """--- separated documents read as a branch and write back with ---."""
    # CATCHES: multi-document input becomes one branch; the yaml writer's
    # document separator is "---\n" (not the default "\n").
    doc = "a: 1\n---\nb: 2\n"
    res = run_dasel(["-i", "yaml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n\n{"b":2}\n'

    res = run_dasel(["-i", "yaml", "-o", "yaml"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == "a: 1\n---\nb: 2\n"

    three = "a: 1\n---\nb: 2\n---\nc: 3\n"
    res = run_dasel(["-i", "yaml", "-o", "yaml"], input=three.encode())
    assert res.exit_code == 0
    assert res.out == "a: 1\n---\nb: 2\n---\nc: 3\n"


def test_empty_document_is_null_placeholder():
    """An empty document between separators decodes to null, not a skip."""
    # CATCHES: the reader emits a null document for empty yaml documents so
    # document count is preserved.
    doc = "a: 1\n---\n---\nb: 2\n"
    res = run_dasel(["-i", "yaml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"a":1}\n\nnull\n\n{"b":2}\n'


def test_anchor_alias_expansion():
    """Anchors and aliases expand to copies of the anchored value."""
    # CATCHES: aliases are dereferenced in the output model (no "&x"/"*x"
    # artifacts survive), for both scalar and map anchors.
    doc = "sc: &s hello\nuse: *s\n"
    res = run_dasel(["-i", "yaml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"sc":"hello","use":"hello"}\n'

    doc = "a: &x\n  b: 1\nc: *x\n"
    res = run_dasel(["-i", "yaml", "-o", "json", "--compact"], input=doc.encode())
    assert res.exit_code == 0
    assert res.out == '{"a":{"b":1},"c":{"b":1}}\n'


def test_alias_expansion_depth_exceeded():
    """Alias chains nested deeper than 32 levels fail with the depth error."""
    # CATCHES: the maxExpansionDepth guard and its exact error text, wrapped
    # in the yaml unmarshal-errors formatting (16-space continuation).
    lines = ["x0: &x0 {v: 1}"]
    for i in range(1, 40):
        lines.append(f"x{i}: &x{i} {{v: *x{i-1}}}")
    lines.append("use: *x39")
    res = run_dasel(
        ["-i", "yaml", "-o", "json", "--compact"], input=("\n".join(lines) + "\n").encode()
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: yaml: unmarshal errors:\n"
        "                line 1: yaml expansion depth exceeded\n"
    )


def test_alias_expansion_budget_exceeded():
    """More than 1000 alias expansions fail with the budget error."""
    # CATCHES: the shared per-document expansion budget of 1000 alias
    # dereferences.
    lines = ["a: &a {x: 1}", "b:"]
    lines.extend(["  - *a"] * 1100)
    res = run_dasel(
        ["-i", "yaml", "-o", "json", "--compact"], input=("\n".join(lines) + "\n").encode()
    )
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: yaml: unmarshal errors:\n"
        "                line 1: yaml expansion budget exceeded\n"
    )


@pytest.mark.parametrize(
    "literal,expected",
    [
        ("0x1F", 31),
        ("0o17", 15),
        ("0b101", 5),
        ("1_000", 1000),
        ("+42", 42),
        ("-7", -7),
    ],
)
def test_integer_literal_formats(literal, expected):
    """Hex/octal/binary/underscore/signed yaml integers decode as ints."""
    # CATCHES: parseYAMLInt special-cases 0x/0o/0b bases and strips YAML 1.2
    # underscores instead of failing.
    res = run_dasel(
        ["-i", "yaml", "-o", "json", "--compact"], input=f"n: {literal}\n".encode()
    )
    assert res.exit_code == 0
    assert res.out == f'{{"n":{expected}}}\n'


def test_float_keyword_rejected():
    """.inf is not a valid float and fails with the strconv error."""
    # CATCHES: yaml float keywords are unsupported; the raw ".inf" string is
    # handed to strconv.ParseFloat and the failure is surfaced verbatim.
    res = run_dasel(["-i", "yaml", "-o", "json"], input=b"f: .inf\n")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: yaml: unmarshal errors:\n"
        '                line 1: strconv.ParseFloat: parsing ".inf": '
        "invalid syntax\n"
    )


@pytest.mark.parametrize(
    "value,expected_line",
    [
        ("true", 'a: "true"\n'),
        ("1", 'a: "1"\n'),
        ("null", 'a: "null"\n'),
        ("~", 'a: "~"\n'),
        ("yes", "a: yes\n"),
        ("plain", "a: plain\n"),
    ],
)
def test_writer_quotes_ambiguous_strings(value, expected_line):
    """Strings that would re-read as another type are quoted on write."""
    # CATCHES: go-yaml quoting decisions — true/1/null/~ get quotes while
    # yes stays bare (yaml 1.2 core schema does not make yes a bool).
    res = run_dasel(
        ["-i", "json", "-o", "yaml"], input=f'{{"a":"{value}"}}'.encode()
    )
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == expected_line


def test_writer_floats_keep_tag():
    """Floats from json keep their float typing via the !!float tag."""
    # CATCHES: integral float values would collapse to ints on write without
    # the explicit !!float tag.
    res = run_dasel(["-i", "json", "-o", "yaml"], input=b'{"f":2.0,"g":1e3}')
    assert res.exit_code == 0
    assert res.out == "f: !!float 2\ng: !!float 1000\n"


def test_writer_multiline_block_literal():
    """Multiline strings are written as an indented block literal."""
    # CATCHES: the writer delegates string style to go-yaml, which picks a
    # 4-space-indented |- block for embedded newlines.
    res = run_dasel(
        ["-i", "json", "-o", "yaml"], input=b'{"s":"line1\\nline2"}'
    )
    assert res.exit_code == 0
    assert res.out == "s: |-\n    line1\n    line2\n"


def test_writer_compact_flow_style():
    """--compact switches maps and sequences to yaml flow style."""
    # CATCHES: compact mode sets FlowStyle on mapping/sequence nodes,
    # producing single-line flow documents.
    res = run_dasel(["-i", "json", "-o", "yaml", "--compact"], input=b'{"a":1}')
    assert res.exit_code == 0
    assert res.out == "{a: 1}\n"

    res = run_dasel(
        ["-i", "json", "-o", "yaml", "--compact"], input=b'{"a":{"b":{"c":1}}}'
    )
    assert res.exit_code == 0
    assert res.out == "{a: {b: {c: 1}}}\n"


@pytest.mark.parametrize(
    "doc,expected_err",
    [
        (
            "a: [1, 2\n",
            "dasel: error: error reading input: yaml: line 1: "
            "did not find expected ',' or ']'\n",
        ),
        (
            'a: "unclosed\n',
            "dasel: error: error reading input: yaml: line 2: "
            "found unexpected end of stream\n",
        ),
    ],
)
def test_malformed_yaml_errors(doc, expected_err):
    """Malformed yaml exits 1 with the exact go-yaml error message."""
    # CATCHES: the reader surfaces the yaml library error text unchanged.
    res = run_dasel(["-i", "yaml", "-o", "json"], input=doc.encode())
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == expected_err


def test_missing_value_decodes_as_null():
    """A key with no value decodes to an explicit null."""
    # CATCHES: empty yaml values are nulls, not empty strings or errors.
    res = run_dasel(["-i", "yaml", "-o", "json", "--compact"], input=b"a: 1\nb:\n")
    assert res.exit_code == 0
    assert res.out == '{"a":1,"b":null}\n'
