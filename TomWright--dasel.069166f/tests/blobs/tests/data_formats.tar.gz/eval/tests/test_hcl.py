"""HCL reader and writer behaviour (parsing/hcl/reader.go and writer.go):
attributes, block/label nesting, repeated blocks, the hcl-block-format read
flag, expression evaluation, and the map-rooted writer.

HCL attribute iteration order is nondeterministic (the source iterates a Go
map), so every exact-byte assertion here uses single-attribute documents or
dict comparison.
"""

import json as jsonlib

import pytest

from conftest import run_dasel


@pytest.mark.parametrize(
    "src,expected",
    [
        ("a = 1", '{"a":1}'),
        ('b = "str"', '{"b":"str"}'),
        ("c = true", '{"c":true}'),
        ("d = 1.5", '{"d":1.5}'),
        ("neg = -5", '{"neg":-5}'),
        ("n = null", '{"n":null}'),
    ],
)
def test_attribute_values(src, expected):
    """Single attributes decode with their natural scalar types."""
    # CATCHES: cty number decoding splits ints from floats and null stays
    # null rather than becoming a string.
    res = run_dasel(["-i", "hcl", "-o", "json", "--compact"], input=src.encode())
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == expected + "\n"


def test_blocks_and_label_nesting():
    """Block labels nest as successive map levels."""
    # CATCHES: each label adds a map level under the block type, and block
    # keys merge with attribute keys.
    res = run_dasel(
        ["-i", "hcl", "-o", "json", "--compact"],
        input=b'block "label1" {\n  x = 1\n}\n',
    )
    assert res.exit_code == 0
    assert res.out == '{"block":{"label1":{"x":1}}}\n'

    res = run_dasel(
        ["-i", "hcl", "-o", "json", "--compact"],
        input=b'block "l1" "l2" {\n  x = 1\n}\n',
    )
    assert res.exit_code == 0
    assert res.out == '{"block":{"l1":{"l2":{"x":1}}}}\n'


def test_repeated_blocks_become_slice():
    """Repeated blocks with the same identity collect into a slice."""
    # CATCHES: unlabeled repeats become a slice; a labeled repeat with the
    # same label upgrades the previous map to a slice of both maps.
    res = run_dasel(
        ["-i", "hcl", "-o", "json", "--compact"],
        input=b"b { v = 1 }\nb { v = 2 }\n",
    )
    assert res.exit_code == 0
    assert res.out == '{"b":[{"v":1},{"v":2}]}\n'

    res = run_dasel(
        ["-i", "hcl", "-o", "json", "--compact"],
        input=b'b "x" { v = 1 }\nb "x" { v = 2 }\n',
    )
    assert res.exit_code == 0
    assert res.out == '{"b":{"x":[{"v":1},{"v":2}]}}\n'

    res = run_dasel(
        ["-i", "hcl", "-o", "json", "--compact"],
        input=b'b "x" { v = 1 }\nb "y" { v = 2 }\n',
    )
    assert res.exit_code == 0
    assert res.out == '{"b":{"x":{"v":1},"y":{"v":2}}}\n'


def test_block_format_array_read_flag():
    """hcl-block-format=array wraps single labeled blocks in a slice."""
    # CATCHES: with the flag a single block becomes a one-element array;
    # without it the single block stays a bare map.
    src = b'b "x" { v = 1 }\n'
    res = run_dasel(
        ["-i", "hcl", "-o", "json", "--compact", "--read-flag", "hcl-block-format=array"],
        input=src,
    )
    assert res.exit_code == 0
    assert res.out == '{"b":{"x":[{"v":1}]}}\n'

    res = run_dasel(["-i", "hcl", "-o", "json", "--compact"], input=src)
    assert res.exit_code == 0
    assert res.out == '{"b":{"x":{"v":1}}}\n'


def test_expressions_are_evaluated():
    """HCL expressions are evaluated, not kept as source text."""
    # CATCHES: the reader runs the expression evaluator, so 1 + 2 arrives as
    # the integer 3.
    res = run_dasel(["-i", "hcl", "-o", "json", "--compact"], input=b"expr = 1 + 2\n")
    assert res.exit_code == 0
    assert res.out == '{"expr":3}\n'


def test_multi_attribute_document_content():
    """A document with attributes and collections keeps all content.

    Attribute order is nondeterministic, so the output is compared as a
    parsed structure rather than exact bytes.
    """
    # CATCHES: lists, object expressions and multiple attributes all survive
    # the cty decoding with their types intact.
    src = 'z = 1\na = "x"\nlist = [1, 2, 3]\nmap = {k = "v"}\n'
    res = run_dasel(["-i", "hcl", "-o", "json", "--compact"], input=src.encode())
    assert res.exit_code == 0
    assert jsonlib.loads(res.out) == {
        "z": 1,
        "a": "x",
        "list": [1, 2, 3],
        "map": {"k": "v"},
    }


def test_writer_nested_maps_and_lists():
    """The hcl writer emits nested maps as blocks and lists as attributes."""
    # CATCHES: maps become blocks, scalar lists become tuple attributes, and
    # lists of maps repeat the block; attributes align their equals signs.
    res = run_dasel(["-i", "json", "-o", "hcl"], input=b'{"a":{"b":"s"}}')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == 'a {\n  b = "s"\n}\n'

    res = run_dasel(["-i", "json", "-o", "hcl"], input=b'{"l":[1,2]}')
    assert res.exit_code == 0
    assert res.out == "l = [1, 2]\n"

    res = run_dasel(
        ["-i", "json", "-o", "hcl"], input=b'{"a":[{"x":"1"},{"y":"2"}]}'
    )
    assert res.exit_code == 0
    assert res.out == 'a {\n  x = "1"\n}\na {\n  y = "2"\n}\n'

    res = run_dasel(
        ["-i", "json", "-o", "hcl"],
        input=b'{"i":42,"f":2.5,"b":true,"s":"txt","nested":{"x":"1"}}',
    )
    assert res.exit_code == 0
    assert res.out == (
        'i = 42\nf = 2.5\nb = true\ns = "txt"\nnested {\n  x = "1"\n}\n'
    )

    # hclwrite aligns the "=" of attributes to the longest attribute name in
    # the body ("list"), padding the shorter names with spaces.
    res = run_dasel(
        ["-i", "json", "-o", "hcl"],
        input=b'{"i":42,"f":1.5,"b":true,"s":"txt","list":[1,"a",true],"nested":{"x":"1"}}',
    )
    assert res.exit_code == 0
    assert res.out == (
        'i    = 42\nf    = 1.5\nb    = true\ns    = "txt"\n'
        'list = [1, "a", true]\nnested {\n  x = "1"\n}\n'
    )


@pytest.mark.parametrize(
    "doc,expected_err",
    [
        (
            b"null",
            "dasel: error: error writing output: "
            "hcl body is expected to be a map, got null\n",
        ),
        (
            b"42",
            "dasel: error: error writing output: "
            "hcl body is expected to be a map, got int\n",
        ),
    ],
)
def test_writer_requires_map_root(doc, expected_err):
    """The hcl writer rejects non-map roots with the exact error."""
    # CATCHES: scalar roots cannot form an hcl body.
    res = run_dasel(["-i", "json", "-o", "hcl"], input=doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == expected_err


def test_writer_empty_map_and_null_attr():
    """Empty maps produce empty blocks; null attributes stay null."""
    # CATCHES: hclwrite renders an empty block body as "{}" lines and keeps
    # an explicit null attribute.
    res = run_dasel(["-i", "json", "-o", "hcl"], input=b'{"a":{}}')
    assert res.exit_code == 0
    assert res.out == "a {\n}\n"

    res = run_dasel(["-i", "json", "-o", "hcl"], input=b'{"a":null}')
    assert res.exit_code == 0
    assert res.out == "a = null\n"
