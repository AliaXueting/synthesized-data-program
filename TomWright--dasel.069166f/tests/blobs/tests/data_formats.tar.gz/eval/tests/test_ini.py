"""INI reader and writer behaviour (parsing/ini/ini_reader.go and
ini_writer.go): default-section keys, section nesting, the child-section
duplication quirk, and writer restrictions.
"""

import pytest

from conftest import run_dasel


def test_default_section_keys_at_root():
    """Keys before any [section] land at the document root as strings."""
    # CATCHES: all ini values are strings (no numeric typing) and root keys
    # come from the DEFAULT section.
    res = run_dasel(["-i", "ini", "-o", "json", "--compact"], input=b"a = 1\nb = str\n")
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == '{"a":"1","b":"str"}\n'


def test_sections_become_nested_maps():
    """[section] headers become nested maps under their name."""
    # CATCHES: section keys nest one level below the root, keeping values as
    # strings.
    res = run_dasel(
        ["-i", "ini", "-o", "json", "--compact"], input=b"a = 1\n[sec]\nx = 1\ny = two\n"
    )
    assert res.exit_code == 0
    assert res.out == '{"a":"1","sec":{"x":"1","y":"two"}}\n'


def test_child_section_duplication_quirk():
    """A [a.b] section after [a] appears both nested and at the root."""
    # CATCHES: go-ini registers "a.b" as a child of "a" keyed by its full
    # dotted name, and the reader also walks all top-level sections — so the
    # subsection appears twice in the model.
    res = run_dasel(
        ["-i", "ini", "-o", "json", "--compact"],
        input=b"a = 1\n[sec]\nx = 1\n[sec.sub]\ny = 2\n",
    )
    assert res.exit_code == 0
    assert res.out == (
        '{"a":"1","sec":{"x":"1","sec.sub":{"y":"2"}},"sec.sub":{"y":"2"}}\n'
    )


def test_explicit_default_section_merges_to_root():
    """An explicit [DEFAULT] section merges its keys into the root."""
    # CATCHES: the DEFAULT section is skipped when iterating named sections,
    # so its keys join the root map instead of nesting under "DEFAULT".
    res = run_dasel(
        ["-i", "ini", "-o", "json", "--compact"], input=b"a = 1\n[DEFAULT]\nc = 2\n"
    )
    assert res.exit_code == 0
    assert res.out == '{"a":"1","c":"2"}\n'


def test_writer_basic_and_nested_sections():
    """The ini writer emits scalar keys and nested maps as sections."""
    # CATCHES: nested maps become [section] headers separated by blank lines,
    # and scalar values are stringified.
    res = run_dasel(["-i", "json", "-o", "ini"], input=b'{"a":1}')
    assert res.exit_code == 0
    assert res.err == ""
    assert res.out == "a = 1\n"

    res = run_dasel(["-i", "json", "-o", "ini"], input=b'{"a":{"b":1}}')
    assert res.exit_code == 0
    assert res.out == "[a]\nb = 1\n"

    res = run_dasel(
        ["-i", "json", "-o", "ini"], input=b'{"a":{"b":{"c":1}}}'
    )
    assert res.exit_code == 0
    assert res.out == "[a]\n\n[a b]\nc = 1\n"


def test_ini_roundtrip_through_reader_model():
    """ini -> ini round-trips the reader's duplicated-section model."""
    # CATCHES: the writer renders the child section again as "[sec sec.sub]"
    # (space-joined nested path) in addition to the root copy.
    res = run_dasel(
        ["-i", "ini", "-o", "ini"],
        input=b"a = 1\n[sec]\nx = 1\n[sec.sub]\ny = 2\n",
    )
    assert res.exit_code == 0
    assert res.out == (
        "a = 1\n\n[sec]\nx = 1\n\n[sec sec.sub]\ny = 2\n\n[sec.sub]\ny = 2\n"
    )


@pytest.mark.parametrize(
    "doc,expected_err",
    [
        (
            b"[1,2]",
            "dasel: error: error writing output: ini can only represent map values\n",
        ),
        (
            b'{"a":[1,2]}',
            "dasel: error: error writing output: ini writer cannot represent "
            "slice values directly; consider using nested sections\n",
        ),
    ],
)
def test_writer_rejects_slice_and_non_map_roots(doc, expected_err):
    """Non-map roots and slice values fail with their exact messages."""
    # CATCHES: the root map check happens before any section creation, and
    # slices error with the nested-sections hint.
    res = run_dasel(["-i", "json", "-o", "ini"], input=doc)
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == expected_err


def test_reader_parse_error():
    """An unclosed section header fails with the go-ini error."""
    # CATCHES: the reader surfaces the ini library's "unclosed section"
    # message including the offending header text.
    res = run_dasel(["-i", "ini", "-o", "json"], input=b"[unclosed")
    assert res.exit_code == 1
    assert res.out == ""
    assert res.err == (
        "dasel: error: error reading input: failed to parse ini: "
        "unclosed section: [unclosed\n"
    )
