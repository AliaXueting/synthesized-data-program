"""Output shaping flags: `--compact`, `--root`, `--unstable`, `--it`.

Also covers the `error writing output:` wrapper, which is only reachable
through a writer that rejects the value it is given (the `plain` writer only
accepts scalars).
"""

import pytest

JSON_DOC = b'{"a": {"b": 1}}'
JSON_PRETTY = b'{\n    "b": 1\n}\n'
JSON_COMPACT = b'{"b":1}\n'


def test_compact_json_output(run_dasel):
    """`--compact` removes the indentation and newlines from json output."""
    # CATCHES: the flag is copied into the writer options, so the json writer
    # emits one line with no spaces after `:` or `,`.
    result = run_dasel("--compact", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_COMPACT
    assert result.stderr == b""


def test_compact_yaml_output(run_dasel):
    """`--compact` also affects the yaml writer, producing flow style."""
    # CATCHES: compactness is a shared writer option, so the yaml writer emits
    # `{a: 1}` instead of the block style.
    result = run_dasel("-o", "yaml", "--compact", stdin=b'{"a": 1}')
    assert result.returncode == 0
    assert result.stdout == b"{a: 1}\n"


def test_default_output_is_pretty_json(run_dasel):
    """Without `--compact` the json writer indents with four spaces."""
    # CATCHES: the default writer options carry a four-space indent, which is
    # what the non-compact output uses.
    result = run_dasel("a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_PRETTY


def test_root_flag_returns_the_input_document(run_dasel):
    """`--root` discards the query result and prints the input value."""
    # CATCHES: run.go replaces the selector output with the original input
    # value after execution, so the query still runs but is not printed.
    result = run_dasel("--root", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b'{\n    "a": {\n        "b": 1\n    }\n}\n'


def test_root_flag_without_query(run_dasel):
    """`--root` with no query prints the whole document as well."""
    # CATCHES: with an empty selector the result would already be the root, so
    # the flag is observable mainly through the combination with a query.
    result = run_dasel("--root", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b'{\n    "a": {\n        "b": 1\n    }\n}\n'


def test_root_flag_with_compact(run_dasel):
    """`--root` and `--compact` combine: the root document is compacted."""
    # CATCHES: both flags act on different stages (value choice vs writer
    # options) and must not interfere with each other.
    result = run_dasel("--root", "--compact", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b'{"a":{"b":1}}\n'


def test_root_flag_still_runs_the_selector(run_dasel):
    """A failing query still fails even though `--root` replaces the output."""
    # CATCHES: the selector executes before the root substitution, so its
    # errors surface regardless of `--root`.
    result = run_dasel("--root", "missing", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr.endswith(b'map key not found: "missing"\n')


def test_branch_expression_requires_unstable(run_dasel):
    """`branch(...)` is rejected unless `--unstable` is given."""
    # CATCHES: the BranchExpr ast node is gated behind the unstable flag and
    # the error tells the user which flag enables it.
    result = run_dasel("branch(1, 2)", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b"dasel: error: error executing selector: error evaluating expression "
        b"ast.BranchExpr: unstable ast types are not enabled. to enable them use --unstable\n"
    )


def test_branch_expression_works_with_unstable(run_dasel):
    """`--unstable` unlocks `branch(...)` and prints each branch as a document."""
    # CATCHES: the branch result is a multi-document value written with a blank
    # line between the two documents.
    result = run_dasel("--unstable", "branch(1, 2)", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"1\n\n2\n"
    assert result.stderr == b""


def test_ignore_function_requires_unstable(run_dasel):
    """The `ignore` function is gated behind `--unstable` too."""
    # CATCHES: unstable gating covers both ast nodes and the function registry,
    # with a slightly different message for functions.
    result = run_dasel("ignore()", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stderr == (
        b"dasel: error: error executing selector: error evaluating expression "
        b"ast.CallExpr: unstable function are not enabled. to enable them use --unstable\n"
    )


def test_it_routes_to_interactive_mode_without_a_tty(run_dasel):
    """`--it` fails with the TTY error when no terminal is available."""
    # CATCHES: the flag really reroutes to the interactive command, whose first
    # step is opening /dev/tty; in a pipe-less environment that fails with the
    # raw error and exit code 1 (no usage block on stdout).
    result = run_dasel("--it", stdin=None)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"dasel: error: could not open a new TTY: open /dev/tty: no such device or address\n"


def test_it_with_query_and_piped_input_still_needs_a_tty(run_dasel):
    """`--it` with a query and piped stdin still fails on the missing TTY."""
    # CATCHES: interactive routing happens after the query and stdin are
    # accepted, and piped stdin does not satisfy the TTY requirement.
    result = run_dasel("--it", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"dasel: error: could not open a new TTY: open /dev/tty: no such device or address\n"


def test_it_runs_after_the_no_arguments_guard(run_dasel, tmp_path):
    """The no-arguments guard fires before the `--it` rerouting."""
    # CATCHES: with an empty default_format, no query and nil stdin the
    # `no arguments given` error wins over the interactive TTY error.
    (tmp_path / "cfg.yaml").write_text('default_format: ""\n')
    result = run_dasel("-c", "cfg.yaml", "--it", stdin=None)
    assert result.returncode == 1
    assert result.stderr == b"dasel: error: no arguments given\n"
    assert result.stdout != b""


def test_plain_writer_accepts_a_scalar(run_dasel):
    """`-o plain` writes a scalar string without any quoting."""
    # CATCHES: the plain writer prints the raw scalar followed by a newline,
    # unlike the json writer which would quote it.
    result = run_dasel("-i", "json", "-o", "plain", "a", stdin=b'{"a": "x"}')
    assert result.returncode == 0
    assert result.stdout == b"x\n"


def test_plain_writer_null_is_an_empty_line(run_dasel):
    """`-o plain` renders the null value as a single newline."""
    # CATCHES: the plain writer maps null to the empty string but still
    # terminates the document with a newline.
    result = run_dasel("-i", "json", "-o", "plain", stdin=b"null")
    assert result.returncode == 0
    assert result.stdout == b"\n"


@pytest.mark.parametrize(
    "doc,kind",
    [(b"[1, 2]", "array"), (b'{"a": 1}', "map")],
)
def test_plain_writer_rejects_composites(run_dasel, doc, kind):
    """`-o plain` fails on composite values with the writing-output wrapper."""
    # CATCHES: writer failures are wrapped as `error writing output:` and exit
    # 1 with an empty stdout, which is the only reachable path for that
    # wrapper through the query command.
    result = run_dasel("-i", "json", "-o", "plain", stdin=doc)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        "dasel: error: error writing output: plain can only represent scalar values, got %s\n" % kind
    ).encode()


def test_root_flag_with_plain_writer(run_dasel):
    """`--root` feeds the composite input to the plain writer and fails."""
    # CATCHES: the root substitution happens before writing, so even a scalar
    # query result cannot save the plain writer from the composite input.
    result = run_dasel("-i", "json", "-o", "plain", "--root", "a", stdin=b'{"a": "x"}')
    assert result.returncode == 1
    assert result.stderr == (
        b"dasel: error: error writing output: plain can only represent scalar values, got map\n"
    )
