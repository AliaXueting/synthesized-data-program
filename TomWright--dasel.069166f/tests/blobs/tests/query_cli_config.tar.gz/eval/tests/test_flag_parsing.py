"""Value-flag syntax, repeated flags and missing values for the query command."""

import pytest

JSON_DOC = b'{"a": {"b": 1}}'
EXPECTED = b'{\n    "b": 1\n}\n'


@pytest.mark.parametrize(
    "argv",
    [
        ("-i", "json", "a"),
        ("-ijson", "a"),
        ("--in", "json", "a"),
        ("--in=json", "a"),
        ("a", "-i", "json"),
    ],
)
def test_in_flag_spellings_are_equivalent(run_dasel, argv):
    """`-i`, `-ijson`, `--in` and `--in=json` all set the input format."""
    # CATCHES: kong accepts the short flag with attached or detached value and
    # the long flag with space or `=`, and all four must reach the same reader.
    result = run_dasel(*argv, stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == EXPECTED
    assert result.stderr == b""


def test_short_flag_with_equals_keeps_the_equals(run_dasel):
    """`-i=json` passes the literal value `=json` to the format registry."""
    # CATCHES: for short flags kong treats everything after the flag character
    # as the value, so the `=` becomes part of the format name and the lookup
    # fails instead of parsing the document.
    result = run_dasel("-i=json", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stderr == b"dasel: error: failed to get input reader: unsupported reader file format: =json\n"
    assert result.stdout == b""


@pytest.mark.parametrize("value", ["true", "false"])
def test_bool_flag_accepts_explicit_value(run_dasel, value):
    """`--compact=true/false` is accepted as an explicit boolean value."""
    # CATCHES: boolean flags may be given an `=value` form; `false` must leave
    # the pretty-printed output untouched while `true` compacts it.
    result = run_dasel("--compact=%s" % value, "a", stdin=JSON_DOC)
    assert result.returncode == 0
    if value == "true":
        assert result.stdout == b'{"b":1}\n'
    else:
        assert result.stdout == EXPECTED


def test_bool_flag_does_not_swallow_next_argument(run_dasel):
    """`--compact true` leaves `true` as the query positional argument."""
    # CATCHES: boolean flags never consume the following argv element, so
    # `true` becomes the selector and the real query `a` is an unexpected
    # second positional.
    result = run_dasel("--compact", "true", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: unexpected argument a\n"
    assert result.stdout.startswith(b"Usage: dasel query [<query>] [flags]\n")


def test_repeated_in_flag_last_wins(run_dasel):
    """When `-i` is repeated the last value wins."""
    # CATCHES: the mapper appends to the flag target and kong keeps decoding,
    # so the final `-i` decides which reader parses the input.
    last_json = run_dasel("-i", "csv", "-i", "json", "a", stdin=JSON_DOC)
    assert last_json.returncode == 0
    assert last_json.stdout == EXPECTED
    last_csv = run_dasel("-i", "json", "-i", "csv", "a", stdin=JSON_DOC)
    assert last_csv.returncode == 1
    assert last_csv.stderr == (
        b'dasel: error: error reading input: parse error on line 1, column 2: bare " in non-quoted-field\n'
    )


def test_repeated_config_flag_last_wins(run_dasel, tmp_path):
    """When `-c` is repeated the last config path is the one loaded."""
    # CATCHES: a stale `-c` earlier in argv must be discarded, so the missing
    # path given last silently falls back to the built-in json default.
    (tmp_path / "yaml.yaml").write_text("default_format: yaml\n")
    result = run_dasel("-c", "yaml.yaml", "-c", "missing.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == EXPECTED  # json, because the last config is missing


def test_config_long_flag_matches_short_flag(run_dasel, tmp_path):
    """`--config` is the long spelling of `-c` and loads the same file."""
    # CATCHES: the config flag is registered with name `config` and short `c`;
    # both spellings must load the YAML file that sets the default format.
    (tmp_path / "cfg.yaml").write_text("default_format: yaml\n")
    via_short = run_dasel("-c", "cfg.yaml", "a", stdin=JSON_DOC)
    via_long = run_dasel("--config", "cfg.yaml", "a", stdin=JSON_DOC)
    assert via_short.returncode == via_long.returncode == 0
    assert via_short.stdout == via_long.stdout == b"b: 1\n"


@pytest.mark.parametrize(
    "flag,reported,kind",
    [
        ("--in", "--in", "eol"),
        ("-i", "--in", "eol"),
        ("--out", "--out", "eol"),
        ("-o", "--out", "eol"),
        ("--config", "--config", "eol"),
        ("-c", "--config", "eol"),
        ("--var", "--var", "custom"),
        ("--rw-flag", "--rw-flag", "custom"),
        ("--read-flag", "--read-flag", "custom"),
        ("--write-flag", "--write-flag", "custom"),
    ],
)
def test_value_flag_without_value_is_a_kong_error(run_dasel, flag, reported, kind):
    """A value-taking flag at the end of argv fails with exit code 80."""
    # CATCHES: the custom mappers pop the next token; for `--var` and the
    # read/write flags that surfaces their own "expected string value" error,
    # while the plain string flags report kong's EOL diagnostic - and short
    # flags are always reported by their long name.
    result = run_dasel(flag, stdin=b'{"a":1}')
    assert result.returncode == 80
    assert result.stdout != b""
    if kind == "custom":
        expected = "dasel: error: %s: expected string value for variable\n" % reported
    else:
        expected = 'dasel: error: %s: expected string value but got "EOL" (<EOL>)\n' % reported
    assert result.err == expected
