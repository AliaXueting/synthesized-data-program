"""Shared black-box helpers for the dasel ``query_cli_config`` module.

The program under test is always resolved through ``PROGRAMGYM_EXECUTABLE`` so
the exact same suite runs against the reference binary and against any
re-implementation produced later.

Stdin conventions for :func:`run_program`:

* ``stdin=b"..."`` (default) feeds the bytes through a pipe.  The binary sees a
  non-terminal stdin and reads it.
* ``stdin=None`` attaches ``/dev/null``.  ``cmd/dasel/main.go`` stats stdin,
  sees a character device and passes a *nil* reader into the CLI, which is how
  the "no arguments given" guard and the null-input paths are reached without a
  TTY.
"""

import os
import subprocess

import pytest

#: Environment variable that carries the path of the binary under test.
PROGRAMGYM_ENV_VAR = "PROGRAMGYM_EXECUTABLE"

#: Fully pinned child environment.  Nothing is inherited from the test process
#: on purpose: the binary under test must behave identically no matter what
#: GO* / DEBUG / locale variables happen to be set around the test run.
#: ``HOME`` and ``TMPDIR`` are pointed at the per-test directory at run time.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "LANG": "C",
    "LC_ALL": "C",
}

#: Default wall-clock budget for one run of the program under test.
DEFAULT_TIMEOUT = 10

#: Root help text, recorded verbatim from the reference binary.
ROOT_USAGE = (
    "Usage: dasel <command>\n"
    "\n"
    "Query and modify data structures from the command line.\n"
    "\n"
    "Flags:\n"
    "  -h, --help    Show context-sensitive help.\n"
    "\n"
    "Commands:\n"
    "  query          [default] Execute a query\n"
    "  version        Print the version\n"
    "  interactive    Start an interactive session (alpha)\n"
    "  completion     Generate shell completion script\n"
    "  man            Generate man page\n"
    "\n"
    'Run "dasel <command> --help" for more information on a command.\n'
)

#: Query-command help text, recorded verbatim from the reference binary.
QUERY_USAGE = (
    "Usage: dasel query [<query>] [flags]\n"
    "\n"
    "[default] Execute a query\n"
    "\n"
    "Arguments:\n"
    "  [<query>]    The query to execute.\n"
    "\n"
    "Flags:\n"
    "  -h, --help                     Show context-sensitive help.\n"
    "\n"
    "      --var=VARIABLES            Variables to pass to the query. E.g. --var\n"
    "                                 foo=\"bar\" --var baz=json:file:./some/file.json\n"
    "      --rw-flag=EXT-READ-WRITE-FLAGS\n"
    "                                 Read/Write flag to customise parsing/output.\n"
    "                                 Applies to read + write E.g. --rw-flag\n"
    "                                 csv-delimiter=;\n"
    "      --read-flag=EXT-READ-WRITE-FLAGS\n"
    "                                 Reader flag to customise parsing. E.g.\n"
    "                                 --read-flag xml-mode=structured\n"
    "      --write-flag=EXT-READ-WRITE-FLAGS\n"
    "                                 Writer flag to customise output. E.g.\n"
    "                                 --write-flag csv-delimiter=;\n"
    "  -i, --in=STRING                The format of the input data.\n"
    "  -o, --out=STRING               The format of the output data.\n"
    "      --root                     Return the root value.\n"
    "      --compact                  Output in compact mode (no\n"
    "                                 indentation/newlines).\n"
    "      --unstable                 Allow access to potentially unstable features.\n"
    "      --it                       Run in interactive mode (alpha).\n"
    "  -c, --config=\"~/dasel.yaml\"    Path to config file\n"
)

#: Kong prints one extra blank line after the usage block when it is dumped
#: because of a parse error (``UsageOnError``), unlike the `--help` output and
#: unlike the usage printed by MustRun for the no-arguments error.
ROOT_USAGE_ON_ERROR = ROOT_USAGE + "\n"

#: Same, for the query command's usage block.
QUERY_USAGE_ON_ERROR = QUERY_USAGE + "\n"


def resolve_program():
    """Return the path of the binary under test, failing loudly if unset."""
    path = os.environ.get(PROGRAMGYM_ENV_VAR)
    if not path:
        pytest.fail("%s must point at the dasel binary under test" % PROGRAMGYM_ENV_VAR)
    return path


def build_child_env(cwd, extra_env=None):
    """Build the hermetic child environment for one run."""
    env = dict(CHILD_ENV)
    env["HOME"] = str(cwd)
    env["TMPDIR"] = str(cwd)
    # Coverage instrumentation hook: the pipeline measures source coverage of
    # the reference binary through GOCOVERDIR, so it must survive the pinning.
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env["GOCOVERDIR"] = value
    if extra_env:
        env.update(extra_env)
    return env


class RunResult(object):
    """Recorded outcome of one run of the program under test."""

    def __init__(self, argv, returncode, stdout, stderr):
        self.argv = tuple(argv)
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

    @property
    def out(self):
        """stdout decoded as UTF-8 text."""
        return self.stdout.decode("utf-8", "replace")

    @property
    def err(self):
        """stderr decoded as UTF-8 text."""
        return self.stderr.decode("utf-8", "replace")

    @property
    def out_lines(self):
        return self.out.splitlines()

    @property
    def err_lines(self):
        return self.err.splitlines()


def run_program(args, cwd, stdin=b"", extra_env=None, timeout=DEFAULT_TIMEOUT):
    """Run the binary under test with a pinned environment and capture output.

    ``stdin`` may be:

    * ``bytes`` - fed to the child through a pipe (the default, empty pipe);
    * ``None`` - the child's stdin is ``/dev/null`` so the binary sees a
      character device and behaves as if run without piped input;
    * an open file object - used directly as the child's stdin, which is how a
      regular-file redirection is reproduced.
    """
    argv = [resolve_program()] + [str(a) for a in args]
    if stdin is None:
        kwargs = {"stdin": subprocess.DEVNULL}
    elif isinstance(stdin, (bytes, bytearray)):
        kwargs = {"input": bytes(stdin)}
    else:
        kwargs = {"stdin": stdin}
    completed = subprocess.run(
        argv,
        cwd=str(cwd),
        env=build_child_env(cwd, extra_env),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        **kwargs
    )
    return RunResult(argv[1:], completed.returncode, completed.stdout, completed.stderr)


@pytest.fixture
def run_dasel(tmp_path):
    """Return a helper that runs the program under test inside ``tmp_path``.

    The helper takes the argv elements as positional arguments and forwards
    keyword arguments to :func:`run_program` (``stdin``, ``extra_env``,
    ``timeout``).  ``stdin=None`` means "no piped input" (``/dev/null``).
    """

    def _run(*args, **kwargs):
        kwargs.setdefault("cwd", tmp_path)
        return run_program(args, **kwargs)

    return _run


@pytest.fixture
def passwd_home():
    """Home directory of the current user according to the password database.

    ``internal/cli/config.go`` expands a leading ``~`` with ``user.Current()``
    which reads the passwd database, *not* the ``HOME`` environment variable.
    Tests that rely on that difference use this fixture to know which directory
    the reference binary really consults, and skip themselves when a config
    file happens to already live there.
    """
    try:
        import pwd
    except ImportError:  # pragma: no cover - non-POSIX platform
        pytest.skip("pwd module unavailable")
    return pwd.getpwuid(os.getuid()).pw_dir


@pytest.fixture
def yaml_config(tmp_path):
    """Write a config file setting ``default_format: yaml`` and return its name."""

    def _write(name="dasel.yaml", content="default_format: yaml\n"):
        path = tmp_path / name
        path.write_text(content)
        return name

    return _write
