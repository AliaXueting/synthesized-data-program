"""Command routing and kong flag surface for the default ``dasel`` invocation.

`dasel [flags] [query]` and `dasel query [flags] [query]` are the same command
(``default:"withargs"``); kong owns flag parsing, usage rendering and the exit
code for argument errors (80), while runtime errors exit 1.
"""

import pytest

from conftest import QUERY_USAGE, QUERY_USAGE_ON_ERROR, ROOT_USAGE, ROOT_USAGE_ON_ERROR

JSON_DOC = b'{"a": {"b": 1}}'


def test_help_long_flag_prints_root_usage_on_stdout(run_dasel):
    """`--help` prints the root usage to stdout and exits 0."""
    # CATCHES: help output goes to stdout (not stderr) with exit status 0 and
    # lists the five subcommands plus the default query command.
    result = run_dasel("--help", stdin=None)
    assert result.returncode == 0
    assert result.stdout == ROOT_USAGE.encode()
    assert result.stderr == b""


def test_help_short_flag_matches_long_flag(run_dasel):
    """`-h` renders byte-identical help to `--help`."""
    # CATCHES: the short and long help spellings must select the same help
    # printer and produce exactly the same bytes on stdout.
    short = run_dasel("-h", stdin=None)
    long = run_dasel("--help", stdin=None)
    assert short.returncode == 0
    assert short.stdout == long.stdout
    assert short.stderr == long.stderr


def test_query_subcommand_help(run_dasel):
    """`dasel query --help` prints the query-command usage on stdout."""
    # CATCHES: the query command has its own usage block listing every flag
    # (--var, --rw-flag, --read-flag, --write-flag, -i, -o, --root, --compact,
    # --unstable, --it, -c) with kong's compact layout.
    result = run_dasel("query", "--help", stdin=None)
    assert result.returncode == 0
    assert result.stdout == QUERY_USAGE.encode()
    assert result.stderr == b""


def test_help_wins_over_other_flags(run_dasel):
    """`--help` anywhere in argv short-circuits into the root usage."""
    # CATCHES: help is evaluated after the other flags are scanned but before
    # the command runs, so a query command never executes.
    result = run_dasel("-i", "json", "--help", stdin=b'{"a":1}')
    assert result.returncode == 0
    assert result.stdout == ROOT_USAGE.encode()
    assert result.stderr == b""


def test_default_command_equals_query_subcommand(run_dasel):
    """`dasel [flags] [query]` and `dasel query [flags] [query]` are identical."""
    # CATCHES: the query command is registered as kong `default:"withargs"`,
    # so bare argv routes to it exactly like the explicit subcommand.
    via_default = run_dasel("-i", "json", "a", stdin=JSON_DOC)
    via_subcommand = run_dasel("query", "-i", "json", "a", stdin=JSON_DOC)
    assert via_default.returncode == 0
    assert via_subcommand.returncode == 0
    assert via_default.stdout == via_subcommand.stdout == b'{\n    "b": 1\n}\n'
    assert via_default.stderr == via_subcommand.stderr == b""


def test_query_word_can_be_the_positional_argument(run_dasel):
    """`dasel query query` treats the second `query` as the selector."""
    # CATCHES: with `default:"withargs"` the literal word `query` is only the
    # subcommand when it is the first argv element; a repeat is the positional.
    result = run_dasel("query", "query", stdin=b'{"query": 1}')
    assert result.returncode == 0
    assert result.stdout == b"1\n"


@pytest.mark.parametrize("argv", [["--bogus"], ["--bogus", "a"], ["-i", "json", "--bogus"]])
def test_unknown_long_flag_exit_code_and_streams(run_dasel, argv):
    """An unknown long flag exits 80 with usage on stdout and the error on stderr."""
    # CATCHES: kong argument errors exit with status 80 (not 1), print the
    # root usage block to stdout and only the `dasel: error:` line to stderr.
    result = run_dasel(*argv, stdin=b'{"a":1}')
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: unknown flag --bogus\n"
    assert result.stdout == ROOT_USAGE_ON_ERROR.encode()


def test_unknown_long_flag_in_query_context_prints_query_usage(run_dasel):
    """`dasel query --bogus` renders the query usage, not the root usage."""
    # CATCHES: usage is context sensitive - once the query subcommand has been
    # selected its own flag list is what gets printed on a parse error.
    result = run_dasel("query", "--bogus", stdin=b'{"a":1}')
    assert result.returncode == 80
    assert result.stdout == QUERY_USAGE_ON_ERROR.encode()
    assert result.stderr == b"dasel: error: unknown flag --bogus\n"


def test_unknown_long_flag_on_root_prints_root_usage(run_dasel):
    """`dasel --bogus` renders the root command usage on stdout."""
    # CATCHES: before a subcommand is selected the root usage is the one dumped
    # to stdout for a parse failure.
    result = run_dasel("--bogus", stdin=b'{"a":1}')
    assert result.returncode == 80
    assert result.stdout == ROOT_USAGE_ON_ERROR.encode()
    assert result.stderr == b"dasel: error: unknown flag --bogus\n"


def test_unknown_short_flag_suggests_alternatives(run_dasel):
    """An unknown short flag lists the known short flags as suggestions."""
    # CATCHES: kong suggests the registered short flags (-h, -i, -o, -c) for an
    # unknown short flag, which pins the actual short-flag surface.
    result = run_dasel("-z", stdin=b'{"a":1}')
    assert result.returncode == 80
    assert result.stderr == (
        b'dasel: error: unknown flag -z, did you mean one of "-h", "-i", "-o", "-c"?\n'
    )
    assert result.stdout == ROOT_USAGE_ON_ERROR.encode()


def test_negated_bool_flag_is_unknown(run_dasel):
    """`--no-compact` is not a valid negation of `--compact`."""
    # CATCHES: the boolean flags are not registered as negatable, so kong
    # rejects the `--no-` spelling as an unknown flag with exit 80.
    result = run_dasel("--no-compact", stdin=b'{"a":1}')
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: unknown flag --no-compact\n"


def test_second_positional_argument_is_rejected(run_dasel):
    """Only one positional query argument is allowed."""
    # CATCHES: the query argument is a single optional positional; a second one
    # is a kong error (exit 80) with the query usage on stdout.
    result = run_dasel("a", "b", stdin=b'{"a":1}')
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: unexpected argument b\n"
    assert result.stdout == QUERY_USAGE_ON_ERROR.encode()


def test_flags_may_follow_the_positional_argument(run_dasel):
    """A flag placed after the query positional is still parsed as a flag."""
    # CATCHES: kong parses flags interspersed with positionals, so `a -i json`
    # is not read as two query arguments.
    result = run_dasel("a", "-i", "json", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b'{\n    "b": 1\n}\n'
    assert result.stderr == b""


def test_double_dash_terminates_flag_parsing(run_dasel):
    """`--` ends flag parsing so the next argv element is the query."""
    # CATCHES: a query that would otherwise look like a flag can be passed
    # after the `--` terminator and is executed as the selector.
    result = run_dasel("--", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b'{\n    "b": 1\n}\n'


def test_empty_query_string_behaves_like_no_query(run_dasel):
    """An explicitly empty query argument selects the whole document."""
    # CATCHES: the positional defaults to "", so an empty argv element is
    # indistinguishable from omitting the query entirely.
    result = run_dasel("", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b'{\n    "a": {\n        "b": 1\n    }\n}\n'
    assert result.stderr == b""
