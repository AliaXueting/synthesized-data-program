"""`--var` handling (``internal/cli/variable.go`` and ``parsing/d``).

Values are `name=value`; the value is optionally `format:` prefixed (default
format `dasel`, which evaluates the raw value as a selector) and may read their
content from `file:`.  Decode failures happen inside kong, so they exit 80.
"""

import pytest

JSON_DOC = b'{"a": 1}'

#: The dasel reader evaluates the raw value against null; a bare word is a
#: property expression, which is why `--var foo=bar` cannot work.
DASEL_PROPERTY_ERROR = (
    "dasel: error: --var: failed to read value: failed to read value: "
    "error executing selector: execution error when processing ast.PropertyExpr: "
    "unexpected type: expected map, got null\n"
)


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("1", b"1\n"),
        ("1+2", b"3\n"),
        ('"bar"', b'"bar"\n'),
        ("null", b"null\n"),
        ("true", b"true\n"),
        ("[1,2]", b"[\n    1,\n    2\n]\n"),
    ],
)
def test_var_dasel_literals(run_dasel, raw, expected):
    """A `--var` value without a format prefix is evaluated as a dasel selector."""
    # CATCHES: the default format is `dasel`, so the raw text is executed as a
    # selector against null - numbers, arithmetic, quoted strings and the null,
    # true and array literals all come from the selector engine.
    result = run_dasel("--var", "foo=%s" % raw, "$foo", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == expected
    assert result.stderr == b""


def test_var_empty_value_is_null(run_dasel):
    """`--var foo=` decodes to the null value."""
    # CATCHES: the dasel reader returns null for empty input, so an empty value
    # does not fail the decode.
    result = run_dasel("--var", "foo=", "$foo", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"null\n"


def test_var_bare_word_fails_as_a_selector(run_dasel):
    """`--var foo=bar` fails because `bar` is evaluated as a selector on null."""
    # CATCHES: contrary to the help text example, a bare word is not a string
    # value - it is parsed as a property expression against null and fails at
    # kong decode time with exit 80 and the doubled `failed to read value:`.
    result = run_dasel("--var", "foo=bar", "$foo", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == DASEL_PROPERTY_ERROR.encode()
    assert result.stdout != b""


def test_var_value_with_equals_is_still_one_selector(run_dasel):
    """`--var foo=bar=baz` splits on the first `=` only."""
    # CATCHES: the name/value split uses SplitN with 2 parts, so the whole
    # `bar=baz` tail becomes the selector and fails as a binary expression.
    result = run_dasel("--var", "foo=bar=baz", "$foo", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == (
        "dasel: error: --var: failed to read value: failed to read value: "
        "error executing selector: execution error when processing ast.BinaryExpr: "
        "error evaluating left expression: execution error when processing "
        "ast.PropertyExpr: unexpected type: expected map, got null\n"
    ).encode()


def test_var_without_equals_is_rejected(run_dasel):
    """A `--var` value with no `=` at all is a decode error."""
    # CATCHES: the mapper requires `name=value` and reports its own diagnostic
    # naming the expected `foo=format:file:path` shapes, exiting 80.
    result = run_dasel("--var", "foobar", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == (
        b"dasel: error: --var: invalid variable format, expect foo=bar, or foo=format:file:path\n"
    )


def test_var_json_inline(run_dasel):
    """`--var foo=json:{...}` parses the value with the json reader."""
    # CATCHES: a format prefix before the value switches the reader used to
    # decode it, so the variable holds a real map.
    result = run_dasel("--var", 'foo=json:{"b": 2}', "$foo.b", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"2\n"


def test_var_yaml_inline(run_dasel):
    """`--var foo=yaml:...` parses the value with the yaml reader."""
    # CATCHES: the yaml reader is chosen by prefix and the value may contain
    # colons because only the first colon splits format from value.
    result = run_dasel("--var", "foo=yaml:b: 3", "$foo.b", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"3\n"


def test_var_explicit_dasel_format(run_dasel):
    """`--var foo=dasel:...` is the same as the implicit default format."""
    # CATCHES: the dasel format can be named explicitly and behaves exactly
    # like the no-prefix default.
    result = run_dasel("--var", "foo=dasel:1+2", "$foo", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"3\n"


def test_multiple_vars_are_all_available(run_dasel):
    """Repeated `--var` flags accumulate instead of replacing each other."""
    # CATCHES: the mapper appends to a slice, so every repetition adds another
    # variable that the query can reference.
    result = run_dasel("--var", "a=1", "--var", "b=2", "$a + $b", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"3\n"


def test_repeated_var_name_last_wins(run_dasel):
    """Defining the same variable twice keeps the last definition."""
    # CATCHES: duplicate names are not an error; the later option wins when the
    # variable lookup is resolved.
    result = run_dasel("--var", "v=1", "--var", "v=2", "$v", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"2\n"


def test_var_json_from_file(run_dasel, tmp_path):
    """`--var foo=json:file:...` reads the value from a file."""
    # CATCHES: the `file:` marker is stripped after the format prefix and the
    # file's bytes become the value handed to the reader.
    (tmp_path / "v.json").write_text('{"b": 42}')
    result = run_dasel("--var", "foo=json:file:v.json", "$foo.b", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"42\n"


def test_var_yaml_from_file(run_dasel, tmp_path):
    """`--var foo=yaml:file:...` reads yaml from a file."""
    # CATCHES: any registered reader format can be combined with `file:`.
    (tmp_path / "v.yaml").write_text("a: 1\n")
    result = run_dasel("--var", "foo=yaml:file:v.yaml", "$foo.a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"1\n"


def test_var_dasel_selector_from_file(run_dasel, tmp_path):
    """`--var foo=dasel:file:...` evaluates the file contents as a selector."""
    # CATCHES: the file contents replace the value before the dasel reader
    # executes them, so the selector itself can live in a file.
    (tmp_path / "v.txt").write_text("1+2")
    result = run_dasel("--var", "foo=dasel:file:v.txt", "$foo", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"3\n"


def test_var_missing_file_is_an_open_error(run_dasel):
    """A `file:` path that does not exist fails at decode time."""
    # CATCHES: the open error is wrapped as `failed to open file:` and keeps
    # the kong exit code 80 with the flag name prefix.
    result = run_dasel("--var", "foo=json:file:nope.json", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == (
        b"dasel: error: --var: failed to open file: open nope.json: no such file or directory\n"
    )


def test_var_empty_file_path_is_an_open_error(run_dasel):
    """`file:` with an empty path tries to open the empty string."""
    # CATCHES: the path is taken verbatim after the marker, so an empty one
    # surfaces the raw `open :` error message.
    result = run_dasel("--var", "foo=json:file:", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: --var: failed to open file: open : no such file or directory\n"


def test_var_directory_as_file_is_a_read_error(run_dasel, tmp_path):
    """A directory given as the `file:` path opens but fails to read."""
    # CATCHES: opening succeeds and the failure moves to reading the contents,
    # wrapped as `failed to read file contents:`.
    (tmp_path / "adir").mkdir()
    result = run_dasel("--var", "foo=json:file:adir", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: --var: failed to read file contents: read adir: is a directory\n"


def test_var_unsupported_format(run_dasel):
    """A format prefix with no registered reader fails at decode time."""
    # CATCHES: the reader registry lookup happens during flag decoding, so an
    # unknown format is `failed to create reader:` with exit 80.
    result = run_dasel("--var", "foo=nope:1", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: --var: failed to create reader: unsupported reader file format: nope\n"


def test_var_write_only_format_plain(run_dasel):
    """`plain` registers a writer only and cannot decode a variable."""
    # CATCHES: the variable decoder goes through the reader registry, so a
    # write-only format name is rejected exactly like an unknown one.
    result = run_dasel("--var", "foo=plain:hi", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: --var: failed to create reader: unsupported reader file format: plain\n"


def test_var_file_marker_without_format(run_dasel):
    """`--var foo=file:./x` treats `file` as the format name."""
    # CATCHES: the format split happens before the `file:` check, so a value
    # starting with `file:` but no format prefix resolves to format `file`.
    result = run_dasel("--var", "foo=file:./v.json", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: --var: failed to create reader: unsupported reader file format: file\n"


def test_var_invalid_json_value(run_dasel):
    """A json-prefixed value that does not parse fails at decode time."""
    # CATCHES: the reader is invoked during decoding, so a bad literal produces
    # `failed to read value:` (once, because the json reader does not double
    # wrap like the dasel reader does).
    result = run_dasel("--var", "foo=json:notjson", "a", stdin=JSON_DOC)
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: --var: failed to read value: json: invalid character o as null\n"


def test_root_variable_exposes_the_input(run_dasel):
    """The input document is exposed as the `$root` variable."""
    # CATCHES: run.go registers the parsed input as a variable named `root`
    # before executing the selector, so `$root.a` reaches back into the input.
    result = run_dasel("$root.a", stdin=b'{"a": 7}')
    assert result.returncode == 0
    assert result.stdout == b"7\n"


def test_bare_root_is_a_property_lookup_not_the_variable(run_dasel):
    """`root` without the `$` is a property lookup, not the root variable."""
    # CATCHES: the injected variable is only reachable through the `$` sigil, so
    # a bare `root` looks for a map key and fails with the not-found error.
    result = run_dasel("root.a", stdin=b'{"a": 7}')
    assert result.returncode == 1
    assert result.stderr == (
        b"dasel: error: error executing selector: execution error when processing "
        b'ast.ChainedExpr: error executing expression: execution error when '
        b'processing ast.PropertyExpr: map key not found: "root"\n'
    )
