"""Config file loading for the query command (``internal/cli/config.go``).

The config is a YAML file with a single ``default_format`` key; it is loaded
from ``-c/--config`` (default ``~/dasel.yaml``), a missing file silently falls
back to the built-in ``json`` default, and unreadable or malformed files are
hard errors.
"""

import os

import pytest

JSON_DOC = b'{"a": {"b": 1}}'
JSON_OUT = b'{\n    "b": 1\n}\n'
YAML_OUT = b"b: 1\n"


def test_config_sets_the_default_format(run_dasel, tmp_path):
    """A config with `default_format: yaml` switches both formats to yaml."""
    # CATCHES: when neither -i nor -o is given both come from the config's
    # default_format, so the JSON input is re-emitted as YAML.
    (tmp_path / "cfg.yaml").write_text("default_format: yaml\n")
    result = run_dasel("-c", "cfg.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == YAML_OUT
    assert result.stderr == b""


def test_config_without_query(run_dasel, tmp_path):
    """A yaml config re-emits the whole piped document as yaml without a query."""
    # CATCHES: the default format applies to the whole document, not only to
    # query results, proving the writer also came from the config.
    (tmp_path / "cfg.yaml").write_text("default_format: yaml\n")
    result = run_dasel("-c", "cfg.yaml", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b"a:\n    b: 1\n"


def test_missing_config_file_silently_falls_back(run_dasel):
    """A config path that does not exist is not an error: json is used."""
    # CATCHES: os.ErrNotExist is special-cased in LoadConfig so a missing file
    # silently keeps the built-in json default instead of failing.
    result = run_dasel("-c", "does-not-exist.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT
    assert result.stderr == b""


def test_default_config_path_is_not_the_cwd(run_dasel, tmp_path):
    """`dasel.yaml` in the working directory is not picked up by default."""
    # CATCHES: the default config path is `~/dasel.yaml`, never a relative
    # `dasel.yaml`, so a file sitting in the cwd is ignored.
    (tmp_path / "dasel.yaml").write_text("default_format: yaml\n")
    result = run_dasel("a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT
    assert result.stderr == b""


def test_default_config_path_ignores_home_env(run_dasel, tmp_path, passwd_home):
    """The default `~/dasel.yaml` is resolved from the passwd database, not $HOME."""
    # CATCHES: config.go expands `~` with user.Current().HomeDir (the passwd
    # entry), so pointing HOME at a directory containing dasel.yaml does not
    # change which config is loaded - the output stays json.
    if os.path.exists(os.path.join(passwd_home, "dasel.yaml")):
        pytest.skip("a %s/dasel.yaml exists in the passwd home" % passwd_home)
    (tmp_path / "dasel.yaml").write_text("default_format: yaml\n")
    result = run_dasel("a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT
    assert result.stderr == b""


def test_tilde_path_is_not_resolved_against_the_cwd(run_dasel, tmp_path, passwd_home):
    """`-c '~/x.yaml'` expands to the passwd home, not to `./~/x.yaml`."""
    # CATCHES: a literal `~` directory in the working directory must not
    # satisfy the config path, which proves the tilde really is expanded to the
    # user's home directory instead of being opened relative to the cwd.
    if os.path.exists(os.path.join(passwd_home, "x.yaml")):
        pytest.skip("a %s/x.yaml exists in the passwd home" % passwd_home)
    tilde_dir = tmp_path / "~"
    tilde_dir.mkdir()
    (tilde_dir / "x.yaml").write_text("default_format: yaml\n")
    via_tilde = run_dasel("-c", "~/x.yaml", "a", stdin=JSON_DOC)
    assert via_tilde.returncode == 0
    assert via_tilde.stdout == JSON_OUT  # expanded away from the cwd copy
    via_dot = run_dasel("-c", "./~/x.yaml", "a", stdin=JSON_DOC)
    assert via_dot.returncode == 0
    assert via_dot.stdout == YAML_OUT  # the explicit relative path does load


def test_malformed_config_file_is_an_error(run_dasel, tmp_path):
    """A config file that is not valid YAML fails with a parse error."""
    # CATCHES: the yaml decoder error is wrapped as `error parsing config file:`
    # and the run exits 1 without producing any stdout.
    (tmp_path / "bad.yaml").write_text("default_format: [1,2\n")
    result = run_dasel("-c", "bad.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        "dasel: error: error parsing config file: yaml: line 1: did not find expected ',' or ']'\n"
    ).encode()


def test_config_with_duplicate_keys_is_an_error(run_dasel, tmp_path):
    """A repeated `default_format` key is rejected by the yaml decoder."""
    # CATCHES: the decoder rejects duplicate mapping keys, and the yaml
    # library's two-line `unmarshal errors:` report is passed through with its
    # 16-space indentation on the second line.
    (tmp_path / "dup.yaml").write_text("default_format: yaml\ndefault_format: json\n")
    result = run_dasel("-c", "dup.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        'dasel: error: error parsing config file: yaml: unmarshal errors:\n'
        '                line 2: mapping key "default_format" already defined at line 1\n'
    ).encode()


def test_config_with_sequence_value_is_an_error(run_dasel, tmp_path):
    """`default_format: [1,2]` cannot be decoded into the string field."""
    # CATCHES: the config struct only accepts a scalar string; a sequence
    # produces a typed yaml unmarshal error naming the line.
    (tmp_path / "seq.yaml").write_text("default_format: [1,2]\n")
    result = run_dasel("-c", "seq.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stderr == (
        "dasel: error: error parsing config file: yaml: unmarshal errors:\n"
        "                line 1: cannot unmarshal !!seq into string\n"
    ).encode()


def test_config_with_integer_value_is_coerced(run_dasel, tmp_path):
    """`default_format: 123` is coerced to the string `123` and then fails lookup."""
    # CATCHES: yaml happily decodes a scalar int into the string field, so the
    # failure only surfaces later in the format registry.
    (tmp_path / "int.yaml").write_text("default_format: 123\n")
    result = run_dasel("-c", "int.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stderr == b"dasel: error: failed to get input reader: unsupported reader file format: 123\n"


def test_config_directory_is_a_parse_error(run_dasel, tmp_path):
    """A directory passed as the config path fails while decoding its contents."""
    # CATCHES: os.Open succeeds on a directory, so the failure comes from the
    # yaml decoder reading it and is wrapped as `error parsing config file:`
    # with the path exactly as it was opened.
    result = run_dasel("-c", ".", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        "dasel: error: error parsing config file: yaml: input error: read .: is a directory\n"
    ).encode()


def test_config_path_through_a_file_is_an_open_error(run_dasel, tmp_path):
    """A config path whose parent is a regular file fails with an open error."""
    # CATCHES: ENOTDIR is not os.ErrNotExist, so it takes the
    # `error opening config file at path` branch with the quoted path.
    (tmp_path / "plain.txt").write_text("x")
    result = run_dasel("-c", "plain.txt/x.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        'dasel: error: error opening config file at path "plain.txt/x.yaml": '
        "open plain.txt/x.yaml: not a directory\n"
    ).encode()


def test_config_symlink_loop_is_an_open_error(run_dasel, tmp_path):
    """A config path that is a symlink loop fails with an open error."""
    # CATCHES: ELOOP is another non-NotExist open failure, proving the error
    # text embeds both the quoted config path and the raw os error.
    (tmp_path / "loop_b").symlink_to(tmp_path / "loop_a")
    (tmp_path / "loop_a").symlink_to(tmp_path / "loop_b")
    result = run_dasel("-c", "loop_a", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stderr == (
        'dasel: error: error opening config file at path "loop_a": '
        "open loop_a: too many levels of symbolic links\n"
    ).encode()


def test_empty_config_file_uses_builtin_default(run_dasel, tmp_path):
    """A zero-byte config file decodes to nothing and keeps json."""
    # CATCHES: the io.EOF result of decoding an empty file is treated as
    # success, so the built-in json default survives.
    (tmp_path / "empty.yaml").write_text("")
    result = run_dasel("-c", "empty.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT


def test_null_default_format_keeps_builtin_default(run_dasel, tmp_path):
    """`default_format:` with no value leaves the built-in json default."""
    # CATCHES: decoding a yaml null into the pre-initialised string field does
    # not clear it, so the default stays `json` rather than becoming empty.
    (tmp_path / "null.yaml").write_text("default_format:\n")
    result = run_dasel("-c", "null.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT


def test_unknown_config_keys_are_ignored(run_dasel, tmp_path):
    """Extra keys in the config file are ignored without an error."""
    # CATCHES: the decoder does not run in strict mode, so unrelated keys
    # cannot break the default_format lookup.
    (tmp_path / "extra.yaml").write_text("other: 1\nmore: [a, b]\n")
    result = run_dasel("-c", "extra.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT


@pytest.mark.parametrize(
    "value,expected",
    [
        ("JSON", "dasel: error: failed to get input reader: unsupported reader file format: JSON\n"),
        ("dasel", "dasel: error: failed to get output writer: unsupported writer file format: dasel\n"),
        ('""', "dasel: error: failed to get output writer: unsupported writer file format: \n"),
    ],
)
def test_config_default_format_lookup_failures(run_dasel, tmp_path, value, expected):
    """A default_format the registry cannot serve fails before anything is read."""
    # CATCHES: format names are case sensitive, `dasel` registers a reader only
    # (so its reader is built and the *writer* lookup fails), while an
    # uppercase name fails in the reader lookup and an empty value skips the
    # reader entirely and reaches the writer with an empty format name.
    (tmp_path / "cfg.yaml").write_text("default_format: %s\n" % value)
    result = run_dasel("-c", "cfg.yaml", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == expected.encode()


def test_config_error_beats_explicit_formats(run_dasel, tmp_path):
    """A broken config file is an error even when -i and -o are both given."""
    # CATCHES: the config is loaded before the format inference happens, so an
    # unreadable config aborts the run regardless of explicit format flags.
    (tmp_path / "bad.yaml").write_text("default_format: [1,2\n")
    result = run_dasel("-c", "bad.yaml", "-i", "json", "-o", "json", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert "error parsing config file" in result.err
