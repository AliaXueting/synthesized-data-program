"""`--rw-flag`, `--read-flag` and `--write-flag` (``internal/cli/read_write_flag.go``).

The three flags accept `name=value` pairs that are merged into the reader and
writer ext-option maps: a `--rw-flag` feeds both sides, and a `--read-flag` /
`--write-flag` beats a `--rw-flag` on its own side.
"""

import pytest

SEMI_CSV = b"a;b\n1;2\n"
COMMA_CSV = b"a,b\n1,2\n"


def test_rw_flag_applies_to_reader_and_writer(run_dasel):
    """`--rw-flag csv-delimiter=;` is used to read *and* to write."""
    # CATCHES: one flag value reaches both option maps, so the semicolon file
    # is parsed into two columns and re-emitted with semicolons.
    result = run_dasel("-i", "csv", "--rw-flag", "csv-delimiter=;", stdin=SEMI_CSV)
    assert result.returncode == 0
    assert result.stdout == SEMI_CSV
    assert result.stderr == b""


def test_read_flag_only_changes_the_reader(run_dasel):
    """`--read-flag csv-delimiter=;` parses with `;` but writes with `,`."""
    # CATCHES: a read flag never lands in the writer options, so the parsed
    # two-column document is written back out with the default comma.
    result = run_dasel("-i", "csv", "--read-flag", "csv-delimiter=;", stdin=SEMI_CSV)
    assert result.returncode == 0
    assert result.stdout == COMMA_CSV


def test_write_flag_only_changes_the_writer(run_dasel):
    """`--write-flag csv-delimiter=;` writes with `;` but reads with `,`."""
    # CATCHES: a write flag never lands in the reader options, so the
    # comma-separated file is still parsed into two columns and only the
    # output delimiter changes.
    result = run_dasel("-i", "csv", "-o", "csv", "--write-flag", "csv-delimiter=;", stdin=COMMA_CSV)
    assert result.returncode == 0
    assert result.stdout == SEMI_CSV


def test_read_flag_beats_rw_flag_for_the_reader(run_dasel):
    """A `--read-flag` overrides a `--rw-flag` with the same name."""
    # CATCHES: the rw flags are applied first and the read flags second, so the
    # reader ends up with the `--read-flag` value while the writer keeps the
    # `--rw-flag` value.
    result = run_dasel(
        "-i", "csv", "--rw-flag", "csv-delimiter=,", "--read-flag", "csv-delimiter=;", stdin=SEMI_CSV
    )
    assert result.returncode == 0
    assert result.stdout == COMMA_CSV  # read with ;, written with ,


def test_write_flag_beats_rw_flag_for_the_writer(run_dasel):
    """A `--write-flag` overrides a `--rw-flag` with the same name."""
    # CATCHES: on the writer side the same ordering applies - rw first, write
    # second - so the reader keeps the rw delimiter while the output follows
    # the `--write-flag`.
    result = run_dasel(
        "-i", "csv", "--rw-flag", "csv-delimiter=;", "--write-flag", "csv-delimiter=,", stdin=SEMI_CSV
    )
    assert result.returncode == 0
    assert result.stdout == COMMA_CSV  # read with ;, written with ,


def test_read_flag_does_not_leak_into_the_writer(run_dasel):
    """A `--read-flag` cannot configure the writer even with no rw flag."""
    # CATCHES: the reader-only flag is never copied into the writer options, so
    # the output stays comma separated.
    result = run_dasel("-i", "csv", "-o", "csv", "--read-flag", "csv-delimiter=;", stdin=SEMI_CSV)
    assert result.returncode == 0
    assert result.stdout == COMMA_CSV


def test_write_flag_does_not_leak_into_the_reader(run_dasel):
    """A `--write-flag` cannot configure the reader."""
    # CATCHES: with `;` only on the writer side, the comma file still parses
    # into two columns - if the flag leaked, the whole line would be one field.
    result = run_dasel("-i", "csv", "--write-flag", "csv-delimiter=;", stdin=COMMA_CSV)
    assert result.returncode == 0
    assert result.stdout == SEMI_CSV


def test_rw_flag_json_escape_html(run_dasel):
    """`--rw-flag json-escape=html` escapes `<` and `>` in the json output."""
    # CATCHES: the rw flag reaches the json writer options and turns on HTML
    # escaping, which is off by default.
    result = run_dasel("--rw-flag", "json-escape=html", "a", stdin=b'{"a": "x<b>"}')
    assert result.returncode == 0
    assert result.stdout == b'"x\\u003cb\\u003e"\n'


def test_read_flag_cannot_configure_the_json_writer(run_dasel):
    """`--read-flag json-escape=html` does not affect the json writer."""
    # CATCHES: the escaping option is writer-side, so passing it as a read flag
    # leaves the output unescaped.
    result = run_dasel("--read-flag", "json-escape=html", "a", stdin=b'{"a": "x<b>"}')
    assert result.returncode == 0
    assert result.stdout == b'"x<b>"\n'


def test_write_flag_json_escape_html(run_dasel):
    """`--write-flag json-escape=html` escapes the json output."""
    # CATCHES: the write flag reaches the writer options exactly like the rw
    # flag does, turning on HTML escaping for the json writer.
    result = run_dasel("--write-flag", "json-escape=html", "a", stdin=b'{"a": "x<b>"}')
    assert result.returncode == 0
    assert result.stdout == b'"x\\u003cb\\u003e"\n'


@pytest.mark.parametrize("flag", ["--rw-flag", "--read-flag", "--write-flag"])
def test_rw_flag_without_equals_is_rejected(run_dasel, flag):
    """A read/write flag with no `=` is a decode error."""
    # CATCHES: all three mappers share the `name=value` syntax check and its
    # `invalid read/write flag format, expect foo=bar` diagnostic, exit 80.
    result = run_dasel(flag, "nonsense", "a", stdin=b'{"a":1}')
    assert result.returncode == 80
    assert result.stderr == b"dasel: error: %s: invalid read/write flag format, expect foo=bar\n" % flag.encode()
    assert result.stdout != b""


def test_rw_flag_equal_sign_only_is_accepted(run_dasel):
    """`--rw-flag =` has an empty name but still splits, so it is accepted."""
    # CATCHES: the split only requires an `=` somewhere, so an empty name and
    # value pass validation and land in the ext map as an ignored key.
    result = run_dasel("--rw-flag", "=", "a", stdin=b'{"a":1}')
    assert result.returncode == 0
    assert result.stdout == b"1\n"


def test_unknown_rw_flag_name_is_ignored(run_dasel):
    """An ext flag the formats do not know about is accepted and ignored."""
    # CATCHES: unknown names are stored in the ext map but no reader or writer
    # looks at them, so the run succeeds unchanged.
    result = run_dasel("--rw-flag", "nonsense=zz", "--read-flag", "also-nonsense=1", "a", stdin=b'{"a":1}')
    assert result.returncode == 0
    assert result.stdout == b"1\n"
    assert result.stderr == b""


def test_repeated_read_flag_last_wins(run_dasel):
    """Repeating a `--read-flag` keeps only the last value."""
    # CATCHES: the flags are applied in order into the same map, so the second
    # assignment for a key overwrites the first.
    result = run_dasel(
        "-i", "csv",
        "--read-flag", "csv-delimiter=;",
        "--read-flag", "csv-delimiter=,",
        stdin=SEMI_CSV,
    )
    assert result.returncode == 0
    assert result.stdout == b"a;b\n1;2\n"  # read as a single column, written with ,


def test_read_flag_and_write_flag_can_differ(run_dasel):
    """Independent read and write delimiters are honoured at the same time."""
    # CATCHES: both sides can be configured simultaneously through their own
    # flags, so the input is read with `;` while the output uses the default
    # comma delimiter.
    result = run_dasel(
        "-i", "csv",
        "--read-flag", "csv-delimiter=;",
        "--write-flag", "csv-delimiter=,",
        stdin=SEMI_CSV,
    )
    assert result.returncode == 0
    assert result.stdout == COMMA_CSV
