"""Stdin handling, stream separation and the no-arguments guard.

``cmd/dasel/main.go`` nils stdin for a character device, so redirecting from
``/dev/null`` (``stdin=None`` in these tests) reproduces an unpiped run.
"""

import pytest

from conftest import QUERY_USAGE

JSON_DOC = b'{"a": {"b": 1}}'
JSON_OUT = b'{\n    "b": 1\n}\n'


def test_piped_stdin_is_read_and_result_goes_to_stdout(run_dasel):
    """Piped input is parsed and the query result is written to stdout."""
    # CATCHES: on success the whole result goes to stdout and stderr stays
    # empty, with exit status 0.
    result = run_dasel("-i", "json", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT
    assert result.stderr == b""


def test_stdin_redirected_from_a_file_is_read(run_dasel, tmp_path):
    """A regular file on stdin is treated exactly like piped input."""
    # CATCHES: the stat check only excludes character devices, so a regular
    # file redirection still counts as "input is being provided".
    source = tmp_path / "in.json"
    source.write_bytes(JSON_DOC)
    with open(source, "rb") as handle:
        result = run_dasel("-i", "json", "a", stdin=handle)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT


def test_no_stdin_and_no_query_prints_null(run_dasel):
    """With no piped input and no query the null value is printed."""
    # CATCHES: stdin is nil so the input value defaults to null, and an empty
    # selector returns it unchanged: the json writer prints `null`.
    result = run_dasel(stdin=None)
    assert result.returncode == 0
    assert result.stdout == b"null\n"
    assert result.stderr == b""


def test_no_stdin_with_query_fails_on_null(run_dasel):
    """A property query against the null input is an execution error."""
    # CATCHES: the query still runs against the null input value, producing the
    # unwrapped `error executing selector:` diagnostic on stderr with exit 1.
    result = run_dasel("a", stdin=None)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b"dasel: error: error executing selector: execution error when processing "
        b"ast.PropertyExpr: unexpected type: expected map, got null\n"
    )


def test_empty_pipe_without_query_prints_null(run_dasel):
    """An empty pipe is not the same as no stdin: it also yields null."""
    # CATCHES: an empty pipe is a non-terminal stdin, so bytes are read (zero
    # of them) and the input value stays null rather than erroring.
    result = run_dasel(stdin=b"")
    assert result.returncode == 0
    assert result.stdout == b"null\n"
    assert result.stderr == b""


def test_empty_pipe_with_query_fails_on_null(run_dasel):
    """A query against an empty pipe fails the same way as no input."""
    # CATCHES: zero input bytes never reach the reader, so the selector runs
    # against null and fails with the expected-map diagnostic.
    result = run_dasel("a", stdin=b"")
    assert result.returncode == 1
    assert result.stderr.endswith(b"unexpected type: expected map, got null\n")


@pytest.mark.parametrize("payload", [b" ", b"\n", b"\t\n "])
def test_whitespace_only_pipe_prints_null(run_dasel, payload):
    """Whitespace-only input decodes to null instead of a parse error."""
    # CATCHES: the bytes are non-empty so the reader is invoked, but the json
    # reader treats whitespace-only input as a null document.
    result = run_dasel(stdin=payload)
    assert result.returncode == 0
    assert result.stdout == b"null\n"


def test_invalid_input_is_a_read_error(run_dasel):
    """Input the reader cannot parse fails with the reading-input wrapper."""
    # CATCHES: reader failures are wrapped as `error reading input:` and exit 1
    # with nothing on stdout; the json tokenizer sees the leading `n` of
    # "not json", expects the null literal and trips on the following `o`.
    result = run_dasel("-i", "json", "a", stdin=b"not json at all")
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"dasel: error: error reading input: json: invalid character o as null\n"


def test_multi_document_input_is_echoed_as_separate_documents(run_dasel):
    """Two concatenated JSON documents produce two separated output documents."""
    # CATCHES: the json reader returns multiple values and the writer wraps
    # them in a multi-document writer that separates them with a blank line.
    result = run_dasel(stdin=b'{"a": 1}{"b": 2}')
    assert result.returncode == 0
    assert result.stdout == b'{\n    "a": 1\n}\n\n{\n    "b": 2\n}\n'


def test_no_arguments_guard_with_only_out_flag(run_dasel):
    """`--out=json` with no query and no stdin triggers the no-arguments guard."""
    # CATCHES: the guard fires when the query is empty, the *input* format is
    # still unset (an explicit -o does not count) and stdin is nil; the error
    # goes to stderr, the query usage to stdout and the exit code is 1.
    result = run_dasel("--out=json", stdin=None)
    assert result.returncode == 1
    assert result.stderr == b"dasel: error: no arguments given\n"
    assert result.stdout == QUERY_USAGE.encode()


def test_no_arguments_guard_with_empty_default_format(run_dasel, tmp_path):
    """A config with an empty default_format also trips the no-arguments guard."""
    # CATCHES: the guard looks at the format *after* the config default has
    # been applied, so an empty default_format leaves the input format unset
    # and the guard fires even though a config file was loaded.
    (tmp_path / "cfg.yaml").write_text('default_format: ""\n')
    result = run_dasel("-c", "cfg.yaml", stdin=None)
    assert result.returncode == 1
    assert result.stderr == b"dasel: error: no arguments given\n"
    assert result.stdout == QUERY_USAGE.encode()


def test_no_arguments_guard_not_triggered_by_a_query(run_dasel):
    """A query alone is enough to avoid the no-arguments guard."""
    # CATCHES: the guard requires an empty query, so even with nil stdin the
    # command runs (and fails later on the null input instead).
    result = run_dasel("--out=json", "a", stdin=None)
    assert result.returncode == 1
    assert result.stderr != b"dasel: error: no arguments given\n"
    assert result.stdout == b""


def test_no_arguments_guard_not_triggered_by_stdin(run_dasel):
    """Piped input alone is enough to avoid the no-arguments guard."""
    # CATCHES: an empty pipe counts as "input is being provided", so the guard
    # is skipped and the null document is printed.
    result = run_dasel("--out=json", stdin=b"")
    assert result.returncode == 0
    assert result.stdout == b"null\n"


def test_runtime_errors_leave_stdout_empty(run_dasel):
    """A failing query writes only to stderr and exits 1."""
    # CATCHES: the result buffer is only flushed to stdout on success, so a
    # selector failure produces no stdout at all and the raw execution error
    # reaches stderr without any run.go wrapper prefix.
    result = run_dasel("missing", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == (
        b'dasel: error: error executing selector: execution error when processing '
        b'ast.PropertyExpr: map key not found: "missing"\n'
    )


def test_query_result_is_written_verbatim(run_dasel):
    """The writer's bytes reach stdout unmodified, including the final newline."""
    # CATCHES: run.go returns the writer output and query.go writes it as-is,
    # so the exact indentation and trailing newline come from the json writer.
    result = run_dasel("-i", "json", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == b'{\n    "a": {\n        "b": 1\n    }\n}\n'
