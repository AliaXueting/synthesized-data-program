"""`--in`/`--out` inference (``internal/cli/run.go``).

`--out` defaults to `--in`, `--in` defaults to `--out`, and when neither is
given both come from the config's ``default_format``.  Unsupported names fail
inside the format registry with the `failed to get input reader:` /
`failed to get output writer:` wrappers.
"""

import pytest

JSON_DOC = b'{"a": {"b": 1}}'
JSON_OUT = b'{\n    "b": 1\n}\n'
YAML_DOC = b"a:\n    b: 1\n"
YAML_OUT = b"b: 1\n"


def test_out_defaults_to_in(run_dasel):
    """`-i yaml` alone makes the output yaml as well."""
    # CATCHES: with only an input format given the writer is created from the
    # same format name, so a JSON document is re-emitted as YAML.
    result = run_dasel("-i", "yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == YAML_OUT
    assert result.stderr == b""


def test_in_defaults_to_out(run_dasel):
    """`-o yaml` alone makes the input yaml as well."""
    # CATCHES: with only an output format given the reader is created from the
    # same name, so a YAML-only document is parsed successfully.
    result = run_dasel("-o", "yaml", "a", stdin=YAML_DOC)
    assert result.returncode == 0
    assert result.stdout == YAML_OUT
    assert result.stderr == b""


def test_in_defaults_to_out_fails_on_mismatched_data(run_dasel):
    """`-o json` alone tries to parse the input as json and fails."""
    # CATCHES: the inferred input format is really used by the reader, so
    # YAML-only input under `-o json` produces the json parse error.
    result = run_dasel("-o", "json", "a", stdin=YAML_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == b"dasel: error: error reading input: json: invalid character a as token\n"


def test_both_default_to_json(run_dasel):
    """With no format flags at all both sides are json."""
    # CATCHES: the built-in config default is json, so a piped JSON document
    # round-trips through the json reader and writer.
    result = run_dasel("a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT


def test_both_come_from_the_config_default(run_dasel, tmp_path):
    """With no format flags both sides come from the config's default_format."""
    # CATCHES: the config default fills *both* directions, so JSON input (valid
    # YAML) is read by the yaml reader and written by the yaml writer.
    (tmp_path / "cfg.yaml").write_text("default_format: yaml\n")
    result = run_dasel("-c", "cfg.yaml", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == YAML_OUT


def test_explicit_out_wins_over_config_for_both(run_dasel, tmp_path):
    """An explicit `-o json` keeps the config default out of the input side."""
    # CATCHES: the config default is only consulted when *both* flags are
    # missing, so `-o json` also pins the input format to json instead of the
    # config's yaml.
    (tmp_path / "cfg.yaml").write_text("default_format: yaml\n")
    result = run_dasel("-c", "cfg.yaml", "-o", "json", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT


def test_explicit_in_wins_over_config_for_both(run_dasel, tmp_path):
    """An explicit `-i json` keeps the config default out of the output side."""
    # CATCHES: `-i json` pins the output to json via the out-defaults-to-in
    # rule, ignoring the yaml config default entirely.
    (tmp_path / "cfg.yaml").write_text("default_format: yaml\n")
    result = run_dasel("-c", "cfg.yaml", "-i", "json", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT


def test_empty_format_values_behave_like_unset(run_dasel):
    """`--in= --out=` are treated as unset and fall back to the json default."""
    # CATCHES: kong delivers empty strings, and the inference code compares
    # against "" so an explicitly empty flag is indistinguishable from missing.
    result = run_dasel("--in=", "--out=", "a", stdin=JSON_DOC)
    assert result.returncode == 0
    assert result.stdout == JSON_OUT


@pytest.mark.parametrize(
    "argv,expected",
    [
        (("-i", "nope", "a"), b"dasel: error: failed to get input reader: unsupported reader file format: nope\n"),
        (("-o", "nope", "a"), b"dasel: error: failed to get input reader: unsupported reader file format: nope\n"),
        (("-i", "json", "-o", "nope", "a"), b"dasel: error: failed to get output writer: unsupported writer file format: nope\n"),
        (("-i", "plain", "a"), b"dasel: error: failed to get input reader: unsupported reader file format: plain\n"),
        (("-o", "plain", "a"), b"dasel: error: failed to get input reader: unsupported reader file format: plain\n"),
    ],
)
def test_unsupported_format_names(run_dasel, argv, expected):
    """Unsupported -i/-o names fail in the registry with the right wrapper."""
    # CATCHES: the reader is always built before the writer, and `-o` alone
    # infers the input format, so a bogus `-o` usually reports the *reader*
    # failure; `plain` registers a writer only and can never be read.
    result = run_dasel(*argv, stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stdout == b""
    assert result.stderr == expected


def test_reader_only_format_as_out(run_dasel):
    """`-o dasel` builds the dasel reader and then fails on the writer."""
    # CATCHES: `dasel` registers a reader only, so with `-o dasel` the input is
    # accepted and the failure is deferred to the writer lookup.
    result = run_dasel("-o", "dasel", "a", stdin=JSON_DOC)
    assert result.returncode == 1
    assert result.stderr == b"dasel: error: failed to get output writer: unsupported writer file format: dasel\n"


def test_dasel_format_as_input_runs_the_input_as_a_selector(run_dasel):
    """`-i dasel` evaluates the raw input bytes as a dasel selector."""
    # CATCHES: the dasel reader executes the piped bytes as a selector against
    # a null value, so `1+2` becomes the number 3 before being written as json.
    result = run_dasel("-i", "dasel", "-o", "json", stdin=b"1+2")
    assert result.returncode == 0
    assert result.stdout == b"3\n"


def test_write_flag_value_reaches_the_reader_registry(run_dasel):
    """An invalid reader-side ext value fails inside the reader constructor."""
    # CATCHES: the `failed to get input reader:` wrapper wraps errors raised by
    # the format constructor itself, not just unknown format names.
    result = run_dasel("-i", "csv", "--read-flag", "csv-delimiter=ab", stdin=b"a,b\n1,2\n")
    assert result.returncode == 1
    assert result.stderr == (
        b'dasel: error: failed to get input reader: csv-delimiter must be a single character, got "ab"\n'
    )


def test_write_flag_value_reaches_the_writer_registry(run_dasel):
    """An invalid writer-side ext value fails inside the writer constructor."""
    # CATCHES: the `failed to get output writer:` wrapper also covers
    # constructor validation such as the csv delimiter check.
    result = run_dasel("-i", "json", "-o", "csv", "--write-flag", "csv-delimiter=ab", stdin=b"1")
    assert result.returncode == 1
    assert result.stderr == (
        b'dasel: error: failed to get output writer: csv-delimiter must be a single character, got "ab"\n'
    )
