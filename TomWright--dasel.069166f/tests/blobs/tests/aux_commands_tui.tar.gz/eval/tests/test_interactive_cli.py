"""Non-terminal behaviour of dasel's interactive mode entry points.

`dasel interactive` and `dasel --it` both hand control to a bubbletea program,
which needs a terminal.  With no controlling terminal the reference fails
before drawing anything, and a broken config file is reported even earlier.
These tests run the binary in a fresh session with no controlling tty so the
result does not depend on how pytest itself was launched.
"""

import pytest

from conftest import run_dasel

TTY_ERROR = ("dasel: error: could not open a new TTY: "
             "open /dev/tty: no such device or address\n")


@pytest.mark.parametrize("args", [
    ["interactive"],
    ["--it"],
    ["query", "--it"],
    ["interactive", "name"],
    ["interactive", "-i", "json", "-o", "yaml"],
    ["interactive", "-i", "bogus"],
])
def test_interactive_needs_a_tty(args):
    """Every interactive entry point fails identically without a terminal."""
    # CATCHES: bubbletea falls back to opening /dev/tty when stdin is not a
    # terminal, and that failure is reported before any query is executed.
    res = run_dasel(args, stdin=b'{"a":1}')
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == TTY_ERROR.encode()


def test_interactive_tty_error_is_independent_of_stdin():
    """Piped input does not change the no-terminal failure."""
    # CATCHES: the whole of stdin is drained before the TUI is created, so the
    # error is produced by the program, not by reading input.
    empty = run_dasel(["interactive"], stdin=b"")
    filled = run_dasel(["interactive"], stdin=b'{"name":"Tom"}')
    assert empty.stderr == filled.stderr == TTY_ERROR.encode()
    assert empty.returncode == filled.returncode == 1


@pytest.fixture
def broken_config(tmp_path):
    """A config file that yaml cannot parse."""
    path = tmp_path / "broken.yaml"
    path.write_text("default_format: [1,2\n", encoding="utf-8")
    return path


def test_interactive_reports_a_broken_config_before_the_tty_error(broken_config):
    """An unparseable config file is reported instead of the TTY error."""
    # CATCHES: InteractiveCmd.Run loads the config file before it starts the
    # bubbletea program, and the yaml error is surfaced verbatim.
    res = run_dasel(["interactive", "-c", str(broken_config)], stdin=b"")
    assert res.returncode == 1
    assert res.stdout == b""
    assert (res.err == "dasel: error: error parsing config file: yaml: line 1: "
                       "did not find expected ',' or ']'\n")


@pytest.mark.parametrize("args", [["--it"], ["query", "--it"]])
def test_it_flag_reports_a_broken_config(args, broken_config):
    """`--it` goes through the query command, so it loads the config too."""
    # CATCHES: the query command loads the config before branching into the
    # interactive runner, so a broken config is fatal for --it as well.
    res = run_dasel(args + ["-c", str(broken_config)], stdin=b"")
    assert res.returncode == 1
    assert (res.err == "dasel: error: error parsing config file: yaml: line 1: "
                       "did not find expected ',' or ']'\n")


def test_interactive_help_does_not_need_a_tty():
    """`dasel interactive --help` works fine without a terminal."""
    # CATCHES: help is handled by kong during parsing, long before the
    # bubbletea program is created.
    res = run_dasel(["interactive", "--help"])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.out.startswith("Usage: dasel interactive [<query>] [flags]\n\n"
                              "Start an interactive session (alpha)\n")
    assert "Run in interactive mode (alpha)." not in res.out


def test_it_flag_is_only_a_query_flag():
    """`--it` is documented for the query command but not for `interactive`."""
    # CATCHES: the interactive subcommand has no --it flag of its own, so
    # `dasel interactive --it` is an unknown-flag usage error.
    res = run_dasel(["interactive", "--it"])
    assert res.returncode == 80
    assert (res.stderr == b'dasel: error: unknown flag --it, did you mean one '
            b'of "--in", "-i", "--out"?\n')

    query = run_dasel(["query", "--help"])
    assert "Run in interactive mode (alpha)." in query.out
