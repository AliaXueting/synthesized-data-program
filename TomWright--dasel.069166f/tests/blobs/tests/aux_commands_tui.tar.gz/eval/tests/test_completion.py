"""`dasel completion <shell>` - the four generated scripts and their inputs."""

import pytest

from conftest import run_dasel

# --- expectations recorded from ./executable -------------------------------

COMPLETION_BASH = r"""#!/bin/bash

_dasel() {
    local cur prev words cword
    _init_completion || return

    local commands="query version interactive completion man"
    local formats="csv dasel hcl ini json kdl toml xml yaml"
    local shells="bash zsh fish powershell"

    # Find if a subcommand has been specified
    local cmd=""
    for ((i=1; i < cword; i++)); do
        case "${words[i]}" in
            query|version|interactive|completion|man)
                cmd="${words[i]}"
                break
                ;;
        esac
    done

    # Complete format names for --in/--out/-i/-o
    case "${prev}" in
        --in|--out|-i|-o)
            COMPREPLY=($(compgen -W "${formats}" -- "${cur}"))
            return
            ;;
    esac

    if [[ "${cur}" == -* ]]; then
        local flags=""
        case "${cmd}" in
            "")
                # No subcommand yet: offer global flags + query flags (default command)
                flags="--help --var --rw-flag --read-flag --write-flag --in -i --out -o --root --compact --unstable --it --config -c "
                ;;
            query)
                flags="--help --var --rw-flag --read-flag --write-flag --in -i --out -o --root --compact --unstable --it --config -c "
                ;;
            version)
                flags="--help "
                ;;
            interactive)
                flags="--help --var --rw-flag --read-flag --write-flag --in -i --out -o --config -c "
                ;;
            completion)
                flags="--help "
                ;;
            man)
                flags="--help "
                ;;
        esac
        COMPREPLY=($(compgen -W "${flags}" -- "${cur}"))
        return
    fi

    # If no subcommand yet, complete with subcommand names
    if [[ -z "${cmd}" ]]; then
        COMPREPLY=($(compgen -W "${commands}" -- "${cur}"))
    fi
}

complete -F _dasel dasel
"""

COMPLETION_ZSH = r"""#compdef dasel

_dasel() {
    local -a commands formats
    commands=(
        'query:[default] Execute a query'
        'version:Print the version'
        'interactive:Start an interactive session (alpha)'
        'completion:Generate shell completion script'
        'man:Generate man page'
    )
    formats=(csv dasel hcl ini json kdl toml xml yaml )

    _arguments -C \
        '1:command:->command' \
        '*::arg:->args'

    case "${state}" in
        command)
            _describe 'command' commands
            _arguments \
                '--help[Show context-sensitive help.]' \
                '-h[Show context-sensitive help.]' \
                '--var[Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json]' \
                '--rw-flag[Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;]' \
                '--read-flag[Reader flag to customise parsing. E.g. --read-flag xml-mode=structured]' \
                '--write-flag[Writer flag to customise output. E.g. --write-flag csv-delimiter=;]' \
                '--in[The format of the input data.]' \
                '-i[The format of the input data.]' \
                '--out[The format of the output data.]' \
                '-o[The format of the output data.]' \
                '--root[Return the root value.]' \
                '--compact[Output in compact mode (no indentation/newlines).]' \
                '--unstable[Allow access to potentially unstable features.]' \
                '--it[Run in interactive mode (alpha).]' \
                '--config[Path to config file]' \
                '-c[Path to config file]' \

            ;;
        args)
            case "${words[1]}" in
                query)
                    _arguments \
                        '--var[Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json]' \
                        '--rw-flag[Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;]' \
                        '--read-flag[Reader flag to customise parsing. E.g. --read-flag xml-mode=structured]' \
                        '--write-flag[Writer flag to customise output. E.g. --write-flag csv-delimiter=;]' \
                        '--in[The format of the input data.]' \
                        '-i[The format of the input data.]' \
                        '--out[The format of the output data.]' \
                        '-o[The format of the output data.]' \
                        '--root[Return the root value.]' \
                        '--compact[Output in compact mode (no indentation/newlines).]' \
                        '--unstable[Allow access to potentially unstable features.]' \
                        '--it[Run in interactive mode (alpha).]' \
                        '--config[Path to config file]' \
                        '-c[Path to config file]' \
                        '--help[Show context-sensitive help.]' \

                    ;;
                version)
                    _arguments \
                        '--help[Show context-sensitive help.]' \

                    ;;
                interactive)
                    _arguments \
                        '--var[Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json]' \
                        '--rw-flag[Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;]' \
                        '--read-flag[Reader flag to customise parsing. E.g. --read-flag xml-mode=structured]' \
                        '--write-flag[Writer flag to customise output. E.g. --write-flag csv-delimiter=;]' \
                        '--in[The format of the input data.]' \
                        '-i[The format of the input data.]' \
                        '--out[The format of the output data.]' \
                        '-o[The format of the output data.]' \
                        '--config[Path to config file]' \
                        '-c[Path to config file]' \
                        '--help[Show context-sensitive help.]' \

                    ;;
                completion)
                    _arguments \
                        '--help[Show context-sensitive help.]' \

                    ;;
                man)
                    _arguments \
                        '--help[Show context-sensitive help.]' \

                    ;;
            esac

            # Complete format names for --in/--out
            if [[ "${words[CURRENT-1]}" == --in || "${words[CURRENT-1]}" == --out || "${words[CURRENT-1]}" == -i || "${words[CURRENT-1]}" == -o ]]; then
                _describe 'format' formats
            fi
            ;;
    esac
}

compdef _dasel dasel
"""

COMPLETION_FISH = r"""# Fish completion for dasel

# Disable file completions by default
complete -c dasel -f

# Subcommands
complete -c dasel -n __fish_use_subcommand -a query -d '[default] Execute a query'
complete -c dasel -n __fish_use_subcommand -a version -d 'Print the version'
complete -c dasel -n __fish_use_subcommand -a interactive -d 'Start an interactive session (alpha)'
complete -c dasel -n __fish_use_subcommand -a completion -d 'Generate shell completion script'
complete -c dasel -n __fish_use_subcommand -a man -d 'Generate man page'

# Global flags
complete -c dasel -l help -s h -d 'Show context-sensitive help.'

# Query flags (default command, available at root level)
complete -c dasel -n '__fish_use_subcommand' -l var -d 'Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json'
complete -c dasel -n '__fish_use_subcommand' -l rw-flag -d 'Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;'
complete -c dasel -n '__fish_use_subcommand' -l read-flag -d 'Reader flag to customise parsing. E.g. --read-flag xml-mode=structured'
complete -c dasel -n '__fish_use_subcommand' -l write-flag -d 'Writer flag to customise output. E.g. --write-flag csv-delimiter=;'
complete -c dasel -n '__fish_use_subcommand' -l in -s i -d 'The format of the input data.'
complete -c dasel -n '__fish_use_subcommand' -l out -s o -d 'The format of the output data.'
complete -c dasel -n '__fish_use_subcommand' -l root -d 'Return the root value.'
complete -c dasel -n '__fish_use_subcommand' -l compact -d 'Output in compact mode (no indentation/newlines).'
complete -c dasel -n '__fish_use_subcommand' -l unstable -d 'Allow access to potentially unstable features.'
complete -c dasel -n '__fish_use_subcommand' -l it -d 'Run in interactive mode (alpha).'
complete -c dasel -n '__fish_use_subcommand' -l config -s c -d 'Path to config file'

# Per-subcommand flags
complete -c dasel -n '__fish_seen_subcommand_from query' -l var -d 'Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json'
complete -c dasel -n '__fish_seen_subcommand_from query' -l rw-flag -d 'Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;'
complete -c dasel -n '__fish_seen_subcommand_from query' -l read-flag -d 'Reader flag to customise parsing. E.g. --read-flag xml-mode=structured'
complete -c dasel -n '__fish_seen_subcommand_from query' -l write-flag -d 'Writer flag to customise output. E.g. --write-flag csv-delimiter=;'
complete -c dasel -n '__fish_seen_subcommand_from query' -l in -s i -d 'The format of the input data.'
complete -c dasel -n '__fish_seen_subcommand_from query' -l out -s o -d 'The format of the output data.'
complete -c dasel -n '__fish_seen_subcommand_from query' -l root -d 'Return the root value.'
complete -c dasel -n '__fish_seen_subcommand_from query' -l compact -d 'Output in compact mode (no indentation/newlines).'
complete -c dasel -n '__fish_seen_subcommand_from query' -l unstable -d 'Allow access to potentially unstable features.'
complete -c dasel -n '__fish_seen_subcommand_from query' -l it -d 'Run in interactive mode (alpha).'
complete -c dasel -n '__fish_seen_subcommand_from query' -l config -s c -d 'Path to config file'
complete -c dasel -n '__fish_seen_subcommand_from interactive' -l var -d 'Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json'
complete -c dasel -n '__fish_seen_subcommand_from interactive' -l rw-flag -d 'Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;'
complete -c dasel -n '__fish_seen_subcommand_from interactive' -l read-flag -d 'Reader flag to customise parsing. E.g. --read-flag xml-mode=structured'
complete -c dasel -n '__fish_seen_subcommand_from interactive' -l write-flag -d 'Writer flag to customise output. E.g. --write-flag csv-delimiter=;'
complete -c dasel -n '__fish_seen_subcommand_from interactive' -l in -s i -d 'The format of the input data.'
complete -c dasel -n '__fish_seen_subcommand_from interactive' -l out -s o -d 'The format of the output data.'
complete -c dasel -n '__fish_seen_subcommand_from interactive' -l config -s c -d 'Path to config file'

# Format completions for --in/--out
complete -c dasel -l in -xa 'csv dasel hcl ini json kdl toml xml yaml'
complete -c dasel -l out -xa 'csv dasel hcl ini json kdl toml xml yaml'

# Shell completions for completion command
complete -c dasel -n '__fish_seen_subcommand_from completion' -xa 'bash zsh fish powershell'
"""

COMPLETION_POWERSHELL = r"""Register-ArgumentCompleter -Native -CommandName dasel -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commands = @('query', 'version', 'interactive', 'completion', 'man', 'help')
    $formats = @('csv', 'dasel', 'hcl', 'ini', 'json', 'kdl', 'toml', 'xml', 'yaml', '')
    $shells = @('bash', 'zsh', 'fish', 'powershell')

    # Find the subcommand
    $subcommand = $null
    $tokens = $commandAst.ToString().Split() | Select-Object -Skip 1
    foreach ($token in $tokens) {
        if ($commands -contains $token) {
            $subcommand = $token
            break
        }
    }

    # Get the previous word for context-sensitive completion
    $previousWord = $null
    $allTokens = $commandAst.ToString().Split()
    if ($allTokens.Count -gt 1) {
        $previousWord = $allTokens[-1]
        if ($wordToComplete -ne '') {
            if ($allTokens.Count -gt 2) {
                $previousWord = $allTokens[-2]
            }
        }
    }

    # Complete format names
    if ($previousWord -in @('--in', '--out', '-i', '-o')) {
        $formats | Where-Object { $_ -ne '' -and $_ -like "$wordToComplete*" } | ForEach-Object {
            [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
        }
        return
    }

    # Complete shell names for completion command
    if ($subcommand -eq 'completion') {
        $shells | Where-Object { $_ -like "$wordToComplete*" } | ForEach-Object {
            [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
        }
        return
    }

    if ($wordToComplete -like '-*') {
        $flags = @()
        switch ($subcommand) {
            $null {
                # No subcommand: global + query flags
                $flags = @('--help', '--var', '--rw-flag', '--read-flag', '--write-flag', '--in', '-i', '--out', '-o', '--root', '--compact', '--unstable', '--it', '--config', '-c', '')
            }
            'query' {
                $flags = @('--help', '--var', '--rw-flag', '--read-flag', '--write-flag', '--in', '-i', '--out', '-o', '--root', '--compact', '--unstable', '--it', '--config', '-c', '')
            }
            'version' {
                $flags = @('--help', '')
            }
            'interactive' {
                $flags = @('--help', '--var', '--rw-flag', '--read-flag', '--write-flag', '--in', '-i', '--out', '-o', '--config', '-c', '')
            }
            'completion' {
                $flags = @('--help', '')
            }
            'man' {
                $flags = @('--help', '')
            }
            
        }
        $flags | Where-Object { $_ -ne '' -and $_ -like "$wordToComplete*" } | ForEach-Object {
            [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterName', $_)
        }
        return
    }

    # Complete subcommands
    if (-not $subcommand) {
        $commands | Where-Object { $_ -like "$wordToComplete*" } | ForEach-Object {
            [System.Management.Automation.CompletionResult]::new($_, $_, 'Command', $_)
        }
    }
}
"""

COMPLETION_HELP = r"""Usage: dasel completion <shell>

Generate shell completion script

Arguments:
  <shell>    Shell type (bash, zsh, fish, powershell)

Flags:
  -h, --help    Show context-sensitive help.
"""

SHELLS = ["bash", "zsh", "fish", "powershell"]


# --- exact scripts --------------------------------------------------------


@pytest.mark.parametrize("shell,script", [
    ("bash", "BASH"), ("zsh", "ZSH"),
    ("fish", "FISH"), ("powershell", "POWERSHELL"),
])
def test_completion_script_is_byte_identical(shell, script):
    """Each shell emits its own script, byte for byte."""
    # CATCHES: the four templates are completely different programs; a
    # re-implementation that shares or shuffles their content fails here.
    res = run_dasel(["completion", shell])
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.out == globals()["COMPLETION_" + script]


def test_every_shell_script_is_distinct():
    """No two shells produce the same bytes."""
    # CATCHES: the shell argument really selects the template.
    outputs = [run_dasel(["completion", s]).stdout for s in SHELLS]
    for i in range(len(outputs)):
        for j in range(i + 1, len(outputs)):
            assert outputs[i] != outputs[j]


def test_completion_scripts_are_date_independent():
    """The scripts contain no date, so SOURCE_DATE_EPOCH changes nothing."""
    # CATCHES: unlike `dasel man`, the completion generator never looks at
    # SOURCE_DATE_EPOCH.
    for shell in SHELLS:
        pinned = run_dasel(["completion", shell],
                           env={"SOURCE_DATE_EPOCH": "1600000000"})
        plain = run_dasel(["completion", shell])
        assert pinned.stdout == plain.stdout


def test_completion_scripts_end_with_a_single_newline():
    """Every script is newline terminated and has no trailing blank line."""
    # CATCHES: the templates end with a single \n after the last statement.
    for shell in SHELLS:
        out = run_dasel(["completion", shell]).stdout
        assert out.endswith(b"\n")
        assert not out.endswith(b"\n\n")


# --- embedded model data --------------------------------------------------


@pytest.mark.parametrize("shell,fragment", [
    ("bash", 'local formats="csv dasel hcl ini json kdl toml xml yaml"'),
    ("zsh", "formats=(csv dasel hcl ini json kdl toml xml yaml )"),
    ("fish", "complete -c dasel -l in -xa 'csv dasel hcl ini json kdl toml "
             "xml yaml'"),
    ("powershell", "$formats = @('csv', 'dasel', 'hcl', 'ini', 'json', 'kdl', "
                   "'toml', 'xml', 'yaml', '')"),
])
def test_scripts_embed_the_registered_reader_formats(shell, fragment):
    """The format list is the sorted list of registered readers."""
    # CATCHES: dasel registers readers for csv/dasel/hcl/ini/json/kdl/toml/
    # xml/yaml - "plain" is a writer only, so the writer list must never be
    # completed instead.
    out = run_dasel(["completion", shell]).out
    assert fragment in out
    assert "csv hcl ini json kdl plain toml xml yaml" not in out


@pytest.mark.parametrize("shell,fragment", [
    ("bash", 'local commands="query version interactive completion man"'),
    ("zsh", "'interactive:Start an interactive session (alpha)'"),
    ("fish", "complete -c dasel -n __fish_use_subcommand -a interactive "
             "-d 'Start an interactive session (alpha)'"),
    ("powershell", "$commands = @('query', 'version', 'interactive', "
                   "'completion', 'man', 'help')"),
])
def test_scripts_embed_every_subcommand_name(shell, fragment):
    """All five subcommands are offered for completion in every script."""
    # CATCHES: the subcommand list comes from the live kong model, so a
    # missing or renamed subcommand shows up in all four shells.
    out = run_dasel(["completion", shell]).out
    assert fragment in out


def test_bash_script_head_and_registration():
    """The bash script is a `_dasel` completion function registered by name."""
    # CATCHES: the function name and the `complete` registration are derived
    # from the program name.
    out = run_dasel(["completion", "bash"]).out
    assert out.startswith("#!/bin/bash\n\n_dasel() {\n")
    assert out.rstrip().endswith("complete -F _dasel dasel")


def test_bash_script_embeds_the_flag_lists_per_subcommand():
    """Each subcommand case lists the global flags plus its own flags."""
    # CATCHES: interactive completes --in/-i/--out/-o/--config/-c but none of
    # the query-only flags, while version/completion/man complete only --help.
    out = run_dasel(["completion", "bash"]).out
    assert ('flags="--help --var --rw-flag --read-flag --write-flag --in -i '
            '--out -o --root --compact --unstable --it --config -c "' in out)
    assert ('interactive)\n                flags="--help --var --rw-flag '
            '--read-flag --write-flag --in -i --out -o --config -c "' in out)
    assert out.count('flags="--help "') == 3


def test_bash_script_lists_shells_and_commands():
    """The bash script lists the shells and subcommands as word lists."""
    # CATCHES: `completion` completes its own shell enum and the root command
    # completes the subcommand names.
    out = run_dasel(["completion", "bash"]).out
    assert 'local commands="query version interactive completion man"' in out
    assert 'local shells="bash zsh fish powershell"' in out


def test_zsh_script_is_a_compdef_loader():
    """The zsh script starts with #compdef and ends with compdef."""
    # CATCHES: zsh completion is registered through compdef, and the command
    # descriptions are carried in the `commands` array.
    out = run_dasel(["completion", "zsh"]).out
    assert out.startswith("#compdef dasel\n")
    assert out.rstrip().endswith("compdef _dasel dasel")
    assert "'interactive:Start an interactive session (alpha)'" in out
    assert "'man:Generate man page'" in out
    assert "formats=(csv dasel hcl ini json kdl toml xml yaml )" in out


def test_zsh_script_lists_short_and_long_flags():
    """The zsh script emits a `-x[help]` line next to every `--long[help]`."""
    # CATCHES: flags with a short form get a second _arguments entry.
    out = run_dasel(["completion", "zsh"]).out
    assert "'-i[The format of the input data.]' \\" in out
    assert "'-o[The format of the output data.]' \\" in out
    assert "'-c[Path to config file]' \\" in out
    assert "'-h[Show context-sensitive help.]' \\" in out


def test_fish_script_disables_file_completion_and_lists_flags():
    """The fish script starts by turning off file completions."""
    # CATCHES: fish needs `complete -c dasel -f` first, then one line per
    # flag with `-l`/`-s` for the long and short forms.
    out = run_dasel(["completion", "fish"]).out
    assert out.startswith("# Fish completion for dasel\n\n"
                          "# Disable file completions by default\n"
                          "complete -c dasel -f\n")
    assert ("complete -c dasel -n '__fish_use_subcommand' -l in -s i "
            "-d 'The format of the input data.'" in out)
    assert ("complete -c dasel -n '__fish_seen_subcommand_from interactive' "
            "-l config -s c -d 'Path to config file'" in out)


def test_fish_script_completes_formats_and_shells():
    """fish completes the format list for --in/--out and the shells."""
    # CATCHES: the format and shell lists are embedded as -xa word lists.
    out = run_dasel(["completion", "fish"]).out
    assert ("complete -c dasel -l in -xa 'csv dasel hcl ini json kdl toml "
            "xml yaml'" in out)
    assert ("complete -c dasel -n '__fish_seen_subcommand_from completion' "
            "-xa 'bash zsh fish powershell'" in out)


def test_powershell_script_registers_an_argument_completer():
    """The powershell script is a Register-ArgumentCompleter script block."""
    # CATCHES: powershell completion is a native argument completer whose
    # command list also contains the synthetic 'help' entry.
    out = run_dasel(["completion", "powershell"]).out
    assert out.startswith("Register-ArgumentCompleter -Native -CommandName dasel "
                          "-ScriptBlock {\n")
    assert "$commands = @('query', 'version', 'interactive', 'completion', " \
           "'man', 'help')" in out
    assert "$shells = @('bash', 'zsh', 'fish', 'powershell')" in out


def test_powershell_script_formats_array_has_a_sentinel_empty_entry():
    """The powershell format array ends with an empty sentinel element."""
    # CATCHES: the template appends `''` so the array literal never ends on a
    # dangling comma, and the reader list is used (dasel, not plain).
    out = run_dasel(["completion", "powershell"]).out
    assert "$formats = @('csv', 'dasel', 'hcl', 'ini', 'json', 'kdl', " \
           "'toml', 'xml', 'yaml', '')" in out


def test_powershell_script_switches_flags_per_subcommand():
    """The powershell switch builds a per-subcommand flag array."""
    # CATCHES: each subcommand case lists the global flags first and then its
    # own, with the short forms interleaved.
    out = run_dasel(["completion", "powershell"]).out
    assert ("'interactive' {\n                $flags = @('--help', '--var', "
            "'--rw-flag', '--read-flag', '--write-flag', '--in', '-i', "
            "'--out', '-o', '--config', '-c', '')" in out)
    assert out.count("$flags = @('--help', '')") == 3


# --- argument validation (shared with the help module, kept for the enum) --


@pytest.mark.parametrize("shell", ["BASH", "Zsh", "Fish", "PowerShell",
                                   "sh", "tcsh", "nu", "elvish", ""])
def test_completion_rejects_any_other_shell(shell):
    """Only the four lowercase shell names are accepted."""
    # CATCHES: the enum is case sensitive, so `BASH`/`Fish` are rejected too.
    res = run_dasel(["completion", shell])
    assert res.returncode == 80
    assert res.out == COMPLETION_HELP + "\n"
    assert res.stderr == ('dasel: error: <shell> must be one of "bash","zsh",'
                          '"fish","powershell" but got "%s"\n' % shell).encode()
