"""--help / -h output and kong's usage-on-error output for every subcommand.

The root command uses kong's compact help printer, so the exact column
alignment of the flag and command listings is part of the observable contract:
a re-implementation that renders help differently (different wrapping, a
different flag order, missing default values) fails these tests.
"""

from conftest import run_dasel

# --- expectations recorded from ./executable -------------------------------

ROOT_HELP = r"""Usage: dasel <command>

Query and modify data structures from the command line.

Flags:
  -h, --help    Show context-sensitive help.

Commands:
  query          [default] Execute a query
  version        Print the version
  interactive    Start an interactive session (alpha)
  completion     Generate shell completion script
  man            Generate man page

Run "dasel <command> --help" for more information on a command.
"""

QUERY_HELP = r"""Usage: dasel query [<query>] [flags]

[default] Execute a query

Arguments:
  [<query>]    The query to execute.

Flags:
  -h, --help                     Show context-sensitive help.

      --var=VARIABLES            Variables to pass to the query. E.g. --var
                                 foo="bar" --var baz=json:file:./some/file.json
      --rw-flag=EXT-READ-WRITE-FLAGS
                                 Read/Write flag to customise parsing/output.
                                 Applies to read + write E.g. --rw-flag
                                 csv-delimiter=;
      --read-flag=EXT-READ-WRITE-FLAGS
                                 Reader flag to customise parsing. E.g.
                                 --read-flag xml-mode=structured
      --write-flag=EXT-READ-WRITE-FLAGS
                                 Writer flag to customise output. E.g.
                                 --write-flag csv-delimiter=;
  -i, --in=STRING                The format of the input data.
  -o, --out=STRING               The format of the output data.
      --root                     Return the root value.
      --compact                  Output in compact mode (no
                                 indentation/newlines).
      --unstable                 Allow access to potentially unstable features.
      --it                       Run in interactive mode (alpha).
  -c, --config="~/dasel.yaml"    Path to config file
"""

INTERACTIVE_HELP = r"""Usage: dasel interactive [<query>] [flags]

Start an interactive session (alpha)

Arguments:
  [<query>]    The query to execute.

Flags:
  -h, --help                     Show context-sensitive help.

      --var=VARIABLES            Variables to pass to the query. E.g. --var
                                 foo="bar" --var baz=json:file:./some/file.json
      --rw-flag=EXT-READ-WRITE-FLAGS
                                 Read/Write flag to customise parsing/output.
                                 Applies to read + write E.g. --rw-flag
                                 csv-delimiter=;
      --read-flag=EXT-READ-WRITE-FLAGS
                                 Reader flag to customise parsing. E.g.
                                 --read-flag xml-mode=structured
      --write-flag=EXT-READ-WRITE-FLAGS
                                 Writer flag to customise output. E.g.
                                 --write-flag csv-delimiter=;
  -i, --in=STRING                The format of the input data.
  -o, --out=STRING               The format of the output data.
  -c, --config="~/dasel.yaml"    Path to config file
"""

COMPLETION_HELP = r"""Usage: dasel completion <shell>

Generate shell completion script

Arguments:
  <shell>    Shell type (bash, zsh, fish, powershell)

Flags:
  -h, --help    Show context-sensitive help.
"""

MAN_HELP = r"""Usage: dasel man

Generate man page

Flags:
  -h, --help    Show context-sensitive help.
"""

VERSION_HELP = r"""Usage: dasel version

Print the version

Flags:
  -h, --help    Show context-sensitive help.
"""


# --- root command help -----------------------------------------------------


def test_root_help_long_flag():
    """`dasel --help` prints the compact kong usage block on stdout."""
    # CATCHES: the root help lists all five subcommands with their exact help
    # strings and the default-command marker on `query`.
    res = run_dasel(["--help"])
    assert res.out == ROOT_HELP
    assert res.stderr == b""
    assert res.returncode == 0


def test_root_help_short_flag_is_identical():
    """`dasel -h` produces byte-identical output to `dasel --help`."""
    # CATCHES: the short help flag must be wired to the same printer.
    res = run_dasel(["-h"])
    assert res.out == ROOT_HELP
    assert res.returncode == 0


def test_help_before_subcommand_name_shows_subcommand_help():
    """`dasel --help <command>` resolves help for that subcommand."""
    # CATCHES: kong routes a --help that precedes the command name to the
    # subcommand's own usage block instead of the root one.
    res = run_dasel(["--help", "query"])
    assert res.out == QUERY_HELP
    assert res.returncode == 0


def test_root_help_subcommand_order_and_alignment():
    """The root command listing is aligned in a fixed column layout."""
    # CATCHES: subcommands are listed in declaration order (query, version,
    # interactive, completion, man) with 15-character command columns.
    lines = run_dasel(["--help"]).out.splitlines()
    start = lines.index("Commands:") + 1
    commands = [ln for ln in lines[start:] if ln.startswith("  ")]
    assert commands == [
        "  query          [default] Execute a query",
        "  version        Print the version",
        "  interactive    Start an interactive session (alpha)",
        "  completion     Generate shell completion script",
        "  man            Generate man page",
    ]


# --- per-subcommand help ---------------------------------------------------


def test_query_help():
    """`dasel query --help` documents every query flag with its short form."""
    # CATCHES: the query subcommand owns the --var/--rw-flag/--read-flag/
    # --write-flag/--in/--out/--root/--compact/--unstable/--it/--config flags.
    res = run_dasel(["query", "--help"])
    assert res.out == QUERY_HELP
    assert res.stderr == b""
    assert res.returncode == 0


def test_version_help():
    """`dasel version --help` has no flags of its own beyond --help."""
    # CATCHES: version is a bare subcommand; its help block is three lines of
    # usage plus the shared -h/--help flag only.
    res = run_dasel(["version", "--help"])
    assert res.out == VERSION_HELP
    assert res.returncode == 0


def test_interactive_help_omits_query_only_flags():
    """`dasel interactive --help` reuses the query flags but drops three."""
    # CATCHES: NewInteractiveCmd copies the query flags over except --root,
    # --compact and --unstable, which must not appear for the subcommand.
    res = run_dasel(["interactive", "--help"])
    assert res.out == INTERACTIVE_HELP
    assert "Run in interactive mode (alpha)." not in res.out
    assert "Output in compact mode (no" not in res.out
    assert "Return the root value." not in res.out
    assert "Allow access to potentially unstable features." not in res.out


def test_interactive_help_keeps_read_write_flags():
    """The interactive help still documents the format and variable flags."""
    # CATCHES: the interactive subcommand keeps --in/--out/--var/--rw-flag/
    # --read-flag/--write-flag and the -c/--config default.
    out = run_dasel(["interactive", "--help"]).out
    for fragment in (
        "The format of the input data.",
        "The format of the output data.",
        'Variables to pass to the query. E.g. --var',
        'Read/Write flag to customise parsing/output.',
        'Reader flag to customise parsing. E.g.',
        'Writer flag to customise output. E.g.',
        '-c, --config="~/dasel.yaml"',
    ):
        assert fragment in out


def test_completion_help():
    """`dasel completion --help` documents the single <shell> argument."""
    # CATCHES: the shell argument is positional and its help text lists the
    # four supported shells in a fixed order.
    res = run_dasel(["completion", "--help"])
    assert res.out == COMPLETION_HELP
    assert res.returncode == 0


def test_man_help():
    """`dasel man --help` documents the flagless man subcommand."""
    # CATCHES: man takes no arguments and no flags besides the shared --help.
    res = run_dasel(["man", "--help"])
    assert res.out == MAN_HELP
    assert res.returncode == 0


def test_short_help_flag_on_every_subcommand():
    """`-h` works on each subcommand and matches its `--help` output."""
    # CATCHES: the short flag must be registered per subcommand, not only on
    # the root command.
    expected = {
        "query": QUERY_HELP,
        "version": VERSION_HELP,
        "interactive": INTERACTIVE_HELP,
        "completion": COMPLETION_HELP,
        "man": MAN_HELP,
    }
    for command, text in expected.items():
        res = run_dasel([command, "-h"])
        assert res.out == text
        assert res.returncode == 0


# --- usage output on bad input --------------------------------------------


def test_unknown_root_flag_prints_usage_on_stdout_and_error_on_stderr():
    """An unknown root flag exits 80 with usage on stdout, error on stderr."""
    # CATCHES: kong's UsageOnError puts the whole usage block on stdout and
    # only the `dasel: error:` line on stderr, with exit status 80.
    res = run_dasel(["--frobnicate"])
    assert res.returncode == 80
    assert res.out == ROOT_HELP + "\n"
    assert res.stderr == b"dasel: error: unknown flag --frobnicate\n"


def test_unknown_flag_on_subcommand_shows_subcommand_usage():
    """An unknown flag on `query` reports against the query usage block."""
    # CATCHES: usage-on-error is context sensitive - the query usage (not the
    # root one) is reprinted when a query flag is misspelled.
    res = run_dasel(["query", "--frobnicate"])
    assert res.returncode == 80
    assert res.out == QUERY_HELP + "\n"
    assert res.stderr == b"dasel: error: unknown flag --frobnicate\n"


def test_unknown_flag_on_version_shows_version_usage():
    """`dasel version --nope` reprints the version usage block."""
    # CATCHES: even the flagless subcommands reject unknown flags with their
    # own usage and exit status 80.
    res = run_dasel(["version", "--nope"])
    assert res.returncode == 80
    assert res.out == VERSION_HELP + "\n"
    assert res.stderr == b"dasel: error: unknown flag --nope\n"


def test_completion_without_shell_argument():
    """A missing <shell> argument is a usage error with exit status 80."""
    # CATCHES: the shell argument is required, so kong reports
    # `expected "<shell>"` and reprints the completion usage.
    res = run_dasel(["completion"])
    assert res.returncode == 80
    assert res.out == COMPLETION_HELP + "\n"
    assert res.stderr == b'dasel: error: expected "<shell>"\n'


def test_completion_with_unregistered_shell():
    """A shell outside the enum is rejected before any script is generated."""
    # CATCHES: the argument is enum-restricted to bash/zsh/fish/powershell,
    # so `bogus` fails with kong's enum error rather than an empty script.
    res = run_dasel(["completion", "bogus"])
    assert res.returncode == 80
    assert res.out == COMPLETION_HELP + "\n"
    assert (res.stderr ==
            b'dasel: error: <shell> must be one of "bash","zsh","fish",'
            b'"powershell" but got "bogus"\n')


def test_extra_argument_after_shell_is_rejected():
    """`dasel completion bash extra` does not silently ignore the extra arg."""
    # CATCHES: completion takes exactly one positional argument.
    res = run_dasel(["completion", "bash", "extra"])
    assert res.returncode == 80
    assert res.out == COMPLETION_HELP + "\n"
    assert res.stderr == b"dasel: error: unexpected argument extra\n"


def test_extra_argument_after_version_is_rejected():
    """`dasel version extra` is a usage error, not a version print."""
    # CATCHES: version accepts no positional arguments at all.
    res = run_dasel(["version", "extra"])
    assert res.returncode == 80
    assert res.out == VERSION_HELP + "\n"
    assert res.stderr == b"dasel: error: unexpected argument extra\n"


def test_extra_argument_after_man_is_rejected():
    """`dasel man extra` is a usage error."""
    # CATCHES: man takes no positional arguments, matching version.
    res = run_dasel(["man", "extra"])
    assert res.returncode == 80
    assert res.out == MAN_HELP + "\n"
    assert res.stderr == b"dasel: error: unexpected argument extra\n"


def test_unrecognised_subcommand_falls_through_to_query():
    """An unknown first word is treated as a selector by the default command."""
    # CATCHES: `query` is the default command with args, so `dasel frobnicate`
    # runs a query instead of reporting an unknown subcommand.
    res = run_dasel(["frobnicate"], stdin=b'{"a":1}')
    assert res.returncode == 1
    assert res.stdout == b""
    assert (res.err == 'dasel: error: error executing selector: execution '
                       'error when processing ast.PropertyExpr: map key not '
                       'found: "frobnicate"\n')
