"""The interactive TUI, driven through a pseudo terminal.

Every test boots `dasel interactive` (or `dasel --it`) behind a pty, feeds the
document in through a pipe (dasel's main only treats character devices as "no
stdin", so a pipe is what makes the Root pane show real data), sends
keystrokes, and asserts on the emulated screen plus on what the process prints
after ctrl+c tears the alt screen down.
"""

import pytest

from conftest import READER_FORMATS, WRITER_FORMATS

# A small document with a map, a number and a list, so the panes have
# something multi-line to render.
DOCUMENT = b'{"name":"Tom","age":27,"tags":["a","b"]}'

# The whole 30x100 screen the reference draws for the document above, with an
# empty selector and the default json reader/writer.
INITIAL_SCREEN = [
    '',
    '                                Dasel interactive mode - development',
    '',
    '                                        ctrl+c: Quit',
    '                                        ctrl+e: Cycle reader',
    '                                        ctrl+d: Cycle writer',
    '',
    '                                    Reader: json | Writer: json',
    '',
    '┃ Enter a query...',
    '┃',
    '┃',
    '┃',
    '┃',
    '',
    '  Root                                              Result',
    '',
    '╭────────────────────────────────────────────────╮╭────────────────────────────────────────────────╮',
    '│ {                                              ││ {                                              │',
    '│     "name": "Tom",                             ││     "name": "Tom",                             │',
    '│     "age": 27,                                 ││     "age": 27,                                 │',
    '│     "tags": [                                  ││     "tags": [                                  │',
    '│         "a",                                   ││         "a",                                   │',
    '│         "b"                                    ││         "b"                                    │',
    '│     ]                                          ││     ]                                          │',
    '│ }                                              ││ }                                              │',
    '│                                                ││                                                │',
    '│                                                ││                                                │',
    '│                                                ││                                                │',
    '╰────────────────────────────────────────────────╯╰────────────────────────────────────────────────╯',
]

# Row indices inside the 30x100 layout.
HEADER, SHORTCUTS, READER_WRITER, INPUT, TITLES, PANE_TOP, PANE_BODY = (
    1, 3, 7, 9, 15, 17, 18)

CTRL_E = "\x05"   # cycle the reader format
CTRL_D = "\x04"   # cycle the writer format
RIGHT = "\x1b[C"  # a key the textarea ignores: it flushes the pending selector


# --- the initial frame ----------------------------------------------------


def test_initial_screen_is_drawn_exactly(run_tui):
    """The first frame renders the header, shortcuts, input and both panes."""
    # CATCHES: the whole layout (centering, the rounded pane borders, the
    # placeholder, the `Reader: x | Writer: y` line) is pinned cell for cell.
    run = run_tui(["interactive"], stdin_data=DOCUMENT)
    assert run.rows_text() == INITIAL_SCREEN


def test_header_carries_the_version_string(run_tui):
    """The heading line names the mode and the dasel version."""
    # CATCHES: the heading is built from internal.Version, the same string
    # `dasel version` prints, so a different version shows up here too.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, quit=False)
    assert run.row(HEADER) == " " * 32 + "Dasel interactive mode - development"
    run.quit()


def test_shortcut_hints_are_listed(run_tui):
    """ctrl+c/ctrl+e/ctrl+d are documented in the header block."""
    # CATCHES: the keybinding help names the three bindings the UI implements.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, quit=False)
    assert run.row(SHORTCUTS + 0).strip() == "ctrl+c: Quit"
    assert run.row(SHORTCUTS + 1).strip() == "ctrl+e: Cycle reader"
    assert run.row(SHORTCUTS + 2).strip() == "ctrl+d: Cycle writer"
    run.quit()


def test_panes_are_labelled_root_and_result(run_tui):
    """The two output panes are titled Root and Result."""
    # CATCHES: the Root pane always shows the input document and the Result
    # pane the selector output; the titles are what tells them apart.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, quit=False)
    assert run.row(TITLES).startswith("  Root")
    assert run.row(TITLES).endswith("Result")
    run.quit()


def test_the_it_flag_boots_the_same_ui(run_tui):
    """`dasel --it` renders exactly the same screen as `dasel interactive`."""
    # CATCHES: --it routes the query command into NewInteractiveCmd, which
    # reuses the same flags and the same model.
    run = run_tui(["--it"], stdin_data=DOCUMENT)
    assert run.rows_text() == INITIAL_SCREEN


def test_the_ui_uses_the_alternate_screen(run_tui):
    """The UI is drawn on the alt screen and torn down again on quit."""
    # CATCHES: the program is a full screen bubbletea app - it enters the
    # alternate screen buffer at startup and leaves it when ctrl+c quits.
    run = run_tui(["interactive"], stdin_data=DOCUMENT)
    assert b"\x1b[?1049h" in run.raw
    assert b"\x1b[?1049l" in run.raw
    assert run.exited_cleanly


# --- queries --------------------------------------------------------------


def test_root_pane_shows_the_document_and_result_pane_the_empty_selector(run_tui):
    """With no selector both panes show the input document, pretty printed."""
    # CATCHES: an empty selector returns the input value, so the Result pane
    # mirrors the Root pane until a query is typed.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, quit=False)
    rows = run.rows_text()
    root = [r[:50] for r in rows[PANE_BODY:PANE_BODY + 6]]
    result = [r[50:] for r in rows[PANE_BODY:PANE_BODY + 6]]
    assert root == result
    assert root[0] == "│ {                                              │"
    assert root[1] == '│     "name": "Tom",                             │'
    run.quit()


def test_typing_a_query_updates_only_the_result_pane(run_tui):
    """Typing `name` re-executes and puts the selected value in the Result."""
    # CATCHES: the panes re-run whenever the selector changes; the Root pane
    # keeps showing the untouched input document.
    run = run_tui(["interactive"], stdin_data=DOCUMENT,
                  keys=["name", RIGHT])
    rows = run.rows_text()
    assert rows[INPUT] == "┃ name"
    assert rows[PANE_BODY][:50] == "│ {                                              │"
    assert rows[PANE_BODY][50:] == '│ "Tom"                                          │'


def test_a_selector_parse_error_is_shown_in_the_panes(run_tui):
    """A selector that does not parse puts the error text in both panes."""
    # CATCHES: the executor error string (without any `dasel: error:` prefix)
    # becomes the pane content; it is truncated to the pane width.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, keys=[".foo", RIGHT])
    rows = run.rows_text()
    assert rows[INPUT] == "┃ .foo"
    assert (rows[PANE_BODY][:50] ==
            "│ error parsing selector: failed to parse: unexp │")
    assert rows[PANE_BODY][50:] == rows[PANE_BODY][:50]


def test_the_initial_selector_argument_is_preloaded(run_tui):
    """`dasel interactive name` starts with the query filled in and run."""
    # CATCHES: the positional query argument seeds the textarea, and the first
    # update already executes it, so no keystroke is needed.
    run = run_tui(["interactive", "name"], stdin_data=DOCUMENT)
    rows = run.rows_text()
    assert rows[INPUT] == "┃ name"
    assert rows[PANE_BODY][50:] == '│ "Tom"                                          │'


def test_backspace_edits_the_selector(run_tui):
    """Backspace removes characters from the query and from the echo."""
    # CATCHES: the textarea is an editable buffer, and the final selector that
    # is echoed reflects the edits.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, keys=["abc", "\x7f"])
    assert run.row(INPUT) == "┃ ab"
    assert run.echoed == "ab\n"


# --- the selector echo ----------------------------------------------------


def test_the_final_selector_is_echoed_to_stdout(run_tui):
    """On ctrl+c the current selector is printed to stdout with a newline."""
    # CATCHES: the selector written to the textarea is printed after the alt
    # screen is left, so it lands on the normal stdout stream.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, keys=["name", RIGHT])
    assert run.exited_cleanly
    assert run.echoed == "name\n"


def test_an_empty_selector_is_not_echoed(run_tui):
    """Nothing is printed when the selector is still empty at quit time."""
    # CATCHES: the echo is skipped for an empty selector rather than printing
    # a bare newline.
    run = run_tui(["interactive"], stdin_data=DOCUMENT)
    assert run.exited_cleanly
    assert run.echoed == ""


def test_a_selector_that_would_print_is_echoed_verbatim(run_tui):
    """The echo is the raw selector text, not the query result."""
    # CATCHES: stdout gets the selector, never the rendered Result pane.
    run = run_tui(["interactive"], stdin_data=DOCUMENT,
                  keys=["tags[0]", RIGHT])
    assert run.row(INPUT) == "┃ tags[0]"
    assert run.echoed == "tags[0]\n"


# --- format cycling ------------------------------------------------------


def test_ctrl_e_cycles_the_reader_forward(run_tui):
    """ctrl+e moves the reader from json to kdl, the next sorted reader."""
    # CATCHES: the cycle walks the sorted list of registered readers, so json
    # is followed by kdl (not by toml's neighbour in registration order).
    run = run_tui(["interactive"], stdin_data=DOCUMENT, keys=[CTRL_E])
    assert run.row(READER_WRITER).strip() == "Reader: kdl | Writer: json"


def test_ctrl_d_cycles_the_writer_forward(run_tui):
    """ctrl+d moves the writer from json to kdl without touching the reader."""
    # CATCHES: the writer cycle is independent of the reader cycle.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, keys=[CTRL_D])
    assert run.row(READER_WRITER).strip() == "Reader: json | Writer: kdl"


def test_ctrl_e_walks_every_registered_reader_in_order(run_tui):
    """Nine ctrl+e presses walk all readers and come back to json."""
    # CATCHES: the reader list is the nine registered readers in sorted order,
    # including the dasel format that has no writer.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, quit=False)
    seen = []
    for _ in range(len(READER_FORMATS)):
        run.send(CTRL_E)
        seen.append(run.row(READER_WRITER).strip())
    assert seen == ["Reader: %s | Writer: json" % f
                    for f in READER_FORMATS[READER_FORMATS.index("json") + 1:]
                    + READER_FORMATS[:READER_FORMATS.index("json") + 1]]
    run.quit()


def test_ctrl_d_walks_every_registered_writer_in_order(run_tui):
    """Nine ctrl+d presses walk all writers, including plain, and wrap."""
    # CATCHES: the writer list swaps dasel for plain, so a re-implementation
    # that reuses the reader list fails here.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, quit=False)
    seen = []
    for _ in range(len(WRITER_FORMATS)):
        run.send(CTRL_D)
        seen.append(run.row(READER_WRITER).strip())
    assert seen == ["Reader: json | Writer: %s" % f
                    for f in WRITER_FORMATS[WRITER_FORMATS.index("json") + 1:]
                    + WRITER_FORMATS[:WRITER_FORMATS.index("json") + 1]]
    run.quit()


def test_cycling_the_reader_re_runs_the_query(run_tui):
    """Switching the reader to kdl makes both panes show the read error."""
    # CATCHES: a format change re-executes the query, and the reader error
    # string becomes the pane content.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, keys=[CTRL_E])
    assert run.row(PANE_BODY)[:50] == "│ error reading input: kdl: parse error: kdl: ex │"


def test_cycling_the_writer_changes_the_output_encoding(run_tui):
    """Switching the writer to kdl re-renders both panes as kdl."""
    # CATCHES: the writer change re-runs the query and the pane shows kdl
    # output for the same document.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, keys=[CTRL_D])
    rows = run.rows_text()
    assert rows[PANE_BODY][:50] == '│ name "Tom"                                     │'
    assert rows[PANE_BODY + 1][:50] == "│ age 27                                         │"


# --- initial formats -----------------------------------------------------


def test_in_and_out_flags_set_the_initial_formats(run_tui):
    """`-i yaml -o toml` starts with those formats and toml panes."""
    # CATCHES: the initial reader/writer come from the flags, and the panes
    # are rendered through the writer straight away.
    run = run_tui(["interactive", "-i", "yaml", "-o", "toml"],
                  stdin_data=DOCUMENT)
    assert run.row(READER_WRITER).strip() == "Reader: yaml | Writer: toml"
    assert run.row(PANE_BODY)[:50] == "│ name = 'Tom'                                   │"


def test_a_single_in_flag_sets_both_formats(run_tui):
    """`-i yaml` alone makes the writer default to yaml as well."""
    # CATCHES: an empty OutFormat is filled from InFormat.
    run = run_tui(["interactive", "-i", "yaml"], stdin_data=DOCUMENT)
    assert run.row(READER_WRITER).strip() == "Reader: yaml | Writer: yaml"
    assert run.row(PANE_BODY)[:50] == '│ name: "Tom"                                    │'


def test_a_single_out_flag_sets_both_formats(run_tui):
    """`-o yaml` alone makes the reader default to yaml as well."""
    # CATCHES: an empty InFormat is filled from OutFormat, so the document is
    # re-read as yaml before it is written back out.
    run = run_tui(["interactive", "-o", "yaml"], stdin_data=DOCUMENT)
    assert run.row(READER_WRITER).strip() == "Reader: yaml | Writer: yaml"
    assert run.row(PANE_BODY)[:50] == '│ name: "Tom"                                    │'


def test_the_config_default_format_sets_both_formats(run_tui):
    """A config file with default_format: yaml drives both formats."""
    # CATCHES: with neither -i nor -o, InteractiveCmd falls back to the
    # config's default_format instead of a hard coded json.
    run = run_tui(["interactive"], stdin_data=DOCUMENT,
                  config="default_format: yaml\n")
    assert run.row(READER_WRITER).strip() == "Reader: yaml | Writer: yaml"


def test_an_explicit_in_flag_beats_the_config(run_tui):
    """-i overrides the config's default_format for both formats."""
    # CATCHES: the config only supplies the formats that were not given.
    run = run_tui(["interactive", "-i", "json"], stdin_data=DOCUMENT,
                  config="default_format: yaml\n")
    assert run.row(READER_WRITER).strip() == "Reader: json | Writer: json"


# --- unregistered formats ------------------------------------------------


def test_an_unregistered_reader_is_reported_in_the_panes(run_tui):
    """`-i plain` has no reader, so both panes show the reader error."""
    # CATCHES: plain is a writer only, so NewReader fails and the error text
    # becomes the pane content while the header still shows the raw name.
    run = run_tui(["interactive", "-i", "plain"], stdin_data=DOCUMENT)
    assert run.row(READER_WRITER).strip() == "Reader: plain | Writer: plain"
    assert (run.row(PANE_BODY)[:50] ==
            "│ failed to get input reader: unsupported reader │")


def test_cycling_from_an_unregistered_reader_starts_at_the_first(run_tui):
    """ctrl+e from `plain` jumps to csv, the first sorted reader."""
    # CATCHES: cycleFormats cannot find the current format in the list, so it
    # falls back to index 0 instead of erroring.
    run = run_tui(["interactive", "-i", "plain"], stdin_data=DOCUMENT,
                  keys=[CTRL_E])
    assert run.row(READER_WRITER).strip() == "Reader: csv | Writer: plain"


def test_an_unregistered_writer_is_reported_in_the_panes(run_tui):
    """`-o dasel` has no writer, so both panes show the writer error."""
    # CATCHES: dasel is a reader only, and the writer lookup failure is
    # surfaced in the panes.
    run = run_tui(["interactive", "-o", "dasel"], stdin_data=DOCUMENT)
    assert run.row(READER_WRITER).strip() == "Reader: dasel | Writer: dasel"
    assert (run.row(PANE_BODY)[:50] ==
            "│ failed to get output writer: unsupported write │")


# --- layout --------------------------------------------------------------


def test_the_panes_split_the_terminal_width(run_tui):
    """At 100 columns each pane box is exactly 50 columns wide."""
    # CATCHES: the viewport width is (width / 2) - 4 plus one column of
    # padding on each side and the rounded border.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, cols=100, quit=False)
    assert len(run.row(PANE_TOP)) == 100
    assert run.row(PANE_TOP).count("╭") == 2
    run.quit()


def test_a_resize_rebuilds_the_layout(run_tui):
    """Shrinking the terminal re-centres the header and narrows the panes."""
    # CATCHES: the model reacts to WindowSizeMsg, so the panes are re-laid out
    # around the new width rather than keeping the old one.
    run = run_tui(["interactive"], stdin_data=DOCUMENT, rows=30, cols=100,
                  quit=False)
    assert len(run.row(PANE_TOP)) == 100
    run.resize(20, 60)
    assert run.row(HEADER) == " " * 12 + "Dasel interactive mode - development"
    assert run.row(READER_WRITER).strip() == "Reader: json | Writer: json"
    assert len(run.row(PANE_TOP)) == 60
    run.quit()
