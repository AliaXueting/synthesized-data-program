"""`dasel man` - the generated roff page and its SOURCE_DATE_EPOCH handling."""

import re

from conftest import run_dasel

# The full page recorded with SOURCE_DATE_EPOCH=1600000000 (2020-09-13 UTC).
MAN_PAGE = r""".TH DASEL 1 "2020-09-13" "development" "DASEL Manual"
.SH NAME
dasel \- Query and modify data structures from the command line.
.SH SYNOPSIS
.B dasel
[\fIflags\fR]
[\fIquery\fR]
.br
.B dasel
\fIcommand\fR
[\fIflags\fR]
.SH DESCRIPTION
.B dasel
is a command-line tool for querying and modifying data structures.
It supports multiple data formats including JSON, YAML, TOML, CSV, XML, and KDL.
.SH COMMANDS
.TP
.B query
[default] Execute a query
.TP
.B version
Print the version
.TP
.B interactive
Start an interactive session (alpha)
.TP
.B completion
Generate shell completion script
.TP
.B man
Generate man page

.SH OPTIONS
The following options are available for the default \fBquery\fR command:
.TP
\fB\-\-var\fR
Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json
.TP
\fB\-\-rw-flag\fR
Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;
.TP
\fB\-\-read-flag\fR
Reader flag to customise parsing. E.g. --read-flag xml-mode=structured
.TP
\fB\-\-write-flag\fR
Writer flag to customise output. E.g. --write-flag csv-delimiter=;
.TP
\fB\-i\fR, \fB\-\-in\fR
The format of the input data.
.TP
\fB\-o\fR, \fB\-\-out\fR
The format of the output data.
.TP
\fB\-\-root\fR
Return the root value.
.TP
\fB\-\-compact\fR
Output in compact mode (no indentation/newlines).
.TP
\fB\-\-unstable\fR
Allow access to potentially unstable features.
.TP
\fB\-\-it\fR
Run in interactive mode (alpha).
.TP
\fB\-c\fR, \fB\-\-config\fR
Path to config file

.SH GLOBAL OPTIONS
.TP
\fB\-h\fR, \fB\-\-help\fR
Show context-sensitive help.

.SH QUERY OPTIONS
.TP
\fB\-\-var\fR
Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json
.TP
\fB\-\-rw-flag\fR
Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;
.TP
\fB\-\-read-flag\fR
Reader flag to customise parsing. E.g. --read-flag xml-mode=structured
.TP
\fB\-\-write-flag\fR
Writer flag to customise output. E.g. --write-flag csv-delimiter=;
.TP
\fB\-i\fR, \fB\-\-in\fR
The format of the input data.
.TP
\fB\-o\fR, \fB\-\-out\fR
The format of the output data.
.TP
\fB\-\-root\fR
Return the root value.
.TP
\fB\-\-compact\fR
Output in compact mode (no indentation/newlines).
.TP
\fB\-\-unstable\fR
Allow access to potentially unstable features.
.TP
\fB\-\-it\fR
Run in interactive mode (alpha).
.TP
\fB\-c\fR, \fB\-\-config\fR
Path to config file

.SH INTERACTIVE OPTIONS
.TP
\fB\-\-var\fR
Variables to pass to the query. E.g. --var foo="bar" --var baz=json:file:./some/file.json
.TP
\fB\-\-rw-flag\fR
Read/Write flag to customise parsing/output. Applies to read + write E.g. --rw-flag csv-delimiter=;
.TP
\fB\-\-read-flag\fR
Reader flag to customise parsing. E.g. --read-flag xml-mode=structured
.TP
\fB\-\-write-flag\fR
Writer flag to customise output. E.g. --write-flag csv-delimiter=;
.TP
\fB\-i\fR, \fB\-\-in\fR
The format of the input data.
.TP
\fB\-o\fR, \fB\-\-out\fR
The format of the output data.
.TP
\fB\-c\fR, \fB\-\-config\fR
Path to config file

.SH EXAMPLES
.TP
Query JSON from stdin:
echo '{"name": "Tom"}' | dasel 'name'
.TP
Convert JSON to YAML:
echo '{"name": "Tom"}' | dasel -i json -o yaml
.TP
Query with compact output:
echo '{"name": "Tom"}' | dasel -i json -o json --compact
.SH SEE ALSO
.UR https://daseldocs.tomwright.me
Dasel documentation
.UE
"""

TH_LINE = '.TH DASEL 1 "%s" "development" "DASEL Manual"'


def _page(epoch=None, tz=None):
    env = {}
    if epoch is not None:
        env["SOURCE_DATE_EPOCH"] = epoch
    if tz is not None:
        env["TZ"] = tz
    return run_dasel(["man"], env=env)


# --- reproducible date -----------------------------------------------------


def test_man_page_with_pinned_epoch_is_byte_identical():
    """SOURCE_DATE_EPOCH pins the whole page, not just the date."""
    # CATCHES: the man page is generated from a template over the live kong
    # model; any drift in wording, flag order or roff escaping shows up here.
    res = _page("1600000000")
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.out == MAN_PAGE


def test_epoch_zero_renders_the_unix_epoch_date():
    """SOURCE_DATE_EPOCH=0 renders as 1970-01-01 in the .TH header."""
    # CATCHES: the epoch is parsed as unix seconds, not as a year.
    res = _page("0")
    assert res.returncode == 0
    assert res.out.splitlines()[0] == TH_LINE % "1970-01-01"
    assert res.out.splitlines()[1:] == MAN_PAGE.splitlines()[1:]


def test_epoch_one_second_before_a_utc_midnight():
    """1600214399 (2020-09-15 23:59:59 UTC) still renders 2020-09-15."""
    # CATCHES: the rendered date is the UTC calendar day of the epoch.
    res = _page("1600214399", tz="America/New_York")
    assert res.out.splitlines()[0] == TH_LINE % "2020-09-15"


def test_epoch_exactly_at_a_utc_midnight():
    """1600214400 (2020-09-16 00:00:00 UTC) renders 2020-09-16 in any TZ."""
    # CATCHES: the date is rendered in UTC, so a local timezone west of UTC
    # must not pull it back a day.
    res = _page("1600214400", tz="America/New_York")
    assert res.out.splitlines()[0] == TH_LINE % "2020-09-16"
    res = _page("1600214400", tz="Asia/Tokyo")
    assert res.out.splitlines()[0] == TH_LINE % "2020-09-16"


def test_negative_epoch_renders_a_1969_date():
    """A negative SOURCE_DATE_EPOCH is accepted and renders 1969-12-31."""
    # CATCHES: ParseInt accepts a leading minus, and time.Unix(-86400, 0).UTC()
    # lands on the last day of 1969 rather than being rejected.
    res = _page("-86400")
    assert res.returncode == 0
    assert res.out.splitlines()[0] == TH_LINE % "1969-12-31"


def test_far_future_epoch_is_rendered_verbatim():
    """An epoch beyond the current era still formats as YYYY-MM-DD."""
    # CATCHES: the date is produced by Go's time formatting, which happily
    # renders a five digit year (3170843-11-07) without erroring.
    res = _page("99999999999999")
    assert res.returncode == 0
    assert res.out.splitlines()[0] == TH_LINE % "3170843-11-07"


def test_non_numeric_epoch_is_an_error():
    """A SOURCE_DATE_EPOCH that is not a base-10 integer fails the command."""
    # CATCHES: the value is parsed with strconv.ParseInt, so "abc" is an error
    # that is wrapped with the man page data error message.
    res = _page("abc")
    assert res.returncode == 1
    assert res.stdout == b""
    assert (res.stderr == b'dasel: error: error extracting man page data: '
            b'invalid SOURCE_DATE_EPOCH: "abc"\n')


def test_non_integer_epoch_values_are_errors():
    """Floats, hex, leading spaces and overflow all fail to parse."""
    # CATCHES: only strict base-10 integers are accepted; anything else is an
    # error with the offending value quoted verbatim.
    for bad in ("1600000000.5", "0x10", " 1600000000", "99999999999999999999"):
        res = _page(bad)
        assert res.returncode == 1, bad
        assert res.stdout == b"", bad
        assert res.stderr == ('dasel: error: error extracting man page data: '
                              'invalid SOURCE_DATE_EPOCH: "%s"\n' % bad).encode()


def test_empty_epoch_falls_back_to_today():
    """An empty SOURCE_DATE_EPOCH is treated exactly like an unset one."""
    # CATCHES: getReproducibleDate only uses the env value when it is set and
    # non-empty, so both runs fall back to the current date.
    empty = _page("")
    unset = _page(None)
    assert empty.returncode == 0
    assert unset.returncode == 0
    assert empty.out == unset.out
    header = empty.out.splitlines()[0]
    assert re.match(r'^\.TH DASEL 1 "\d{4}-\d{2}-\d{2}" "development" '
                    r'"DASEL Manual"$', header)
    assert empty.out.splitlines()[1:] == MAN_PAGE.splitlines()[1:]


def test_man_ignores_stdin():
    """Piped stdin does not change the generated page."""
    # CATCHES: man never reads stdin, unlike the default query command.
    res = run_dasel(["man"], stdin=b'{"still":"ignored"}',
                    env={"SOURCE_DATE_EPOCH": "1600000000"})
    assert res.out == MAN_PAGE
    assert res.returncode == 0


# --- page structure -------------------------------------------------------


def test_man_section_headings_in_order():
    """The page contains the ten roff sections in template order."""
    # CATCHES: the section order (including the per-subcommand OPTIONS
    # sections) is fixed by the template.
    headings = [ln for ln in _page("1600000000").out.splitlines()
                if ln.startswith(".SH")]
    assert headings == [
        ".SH NAME",
        ".SH SYNOPSIS",
        ".SH DESCRIPTION",
        ".SH COMMANDS",
        ".SH OPTIONS",
        ".SH GLOBAL OPTIONS",
        ".SH QUERY OPTIONS",
        ".SH INTERACTIVE OPTIONS",
        ".SH EXAMPLES",
        ".SH SEE ALSO",
    ]


def test_man_name_line():
    """The NAME section is lowercased even though .TH uppercases the name."""
    # CATCHES: the template uppercases DASEL in the .TH header but lowercases
    # it in NAME/SYNOPSIS/DESCRIPTION via the toLower template func.
    page = _page("1600000000").out
    name = page.splitlines()[1:3]
    assert name == [".SH NAME", "dasel \\- Query and modify data structures "
                                "from the command line."]


def test_man_query_flags_show_their_short_forms():
    """Every query flag with a short form renders `-x, --long`."""
    # CATCHES: the OPTIONS section prefixes the short flag; -i/-o/-c are the
    # only query flags with short forms.
    page = _page("1600000000").out
    for line in ("\\fB\\-i\\fR, \\fB\\-\\-in\\fR",
                 "\\fB\\-o\\fR, \\fB\\-\\-out\\fR",
                 "\\fB\\-c\\fR, \\fB\\-\\-config\\fR"):
        assert line in page
    assert "\\fB\\-\\-root\\fR" in page
    assert "\\fB\\-\\-compact\\fR" in page
    assert "\\fB\\-\\-unstable\\fR" in page
    assert "\\fB\\-\\-it\\fR" in page


def test_man_has_no_options_section_for_flagless_subcommands():
    """version, completion and man get no per-subcommand OPTIONS section."""
    # CATCHES: only subcommands that own flags (query, interactive) produce a
    # `<NAME> OPTIONS` section.
    page = _page("1600000000").out
    assert ".SH VERSION OPTIONS" not in page
    assert ".SH COMPLETION OPTIONS" not in page
    assert ".SH MAN OPTIONS" not in page
    assert ".SH QUERY OPTIONS" in page
    assert ".SH INTERACTIVE OPTIONS" in page


def test_man_interactive_options_omit_query_only_flags():
    """The INTERACTIVE OPTIONS section lists no --root/--compact/--unstable."""
    # CATCHES: NewInteractiveCmd drops those three flags, so the man page
    # built from the live kong model must not list them for interactive.
    page = _page("1600000000").out
    section = page.split(".SH INTERACTIVE OPTIONS")[1].split(".SH EXAMPLES")[0]
    assert "Return the root value." not in section
    assert "Output in compact mode" not in section
    assert "Allow access to potentially unstable features." not in section
    assert "Path to config file" in section


def test_man_examples_and_see_also_blocks():
    """The EXAMPLES and SEE ALSO sections are literal template text."""
    # CATCHES: the three examples and the documentation URL are hardcoded.
    page = _page("1600000000").out
    examples = page.split(".SH EXAMPLES")[1].split(".SH SEE ALSO")[0]
    assert examples == (
        "\n.TP\nQuery JSON from stdin:\necho '{\"name\": \"Tom\"}' | dasel 'name'\n"
        ".TP\nConvert JSON to YAML:\necho '{\"name\": \"Tom\"}' | dasel -i json -o yaml\n"
        ".TP\nQuery with compact output:\n"
        "echo '{\"name\": \"Tom\"}' | dasel -i json -o json --compact\n")
    see_also = page.split(".SH SEE ALSO")[1]
    assert see_also == ("\n.UR https://daseldocs.tomwright.me\n"
                        "Dasel documentation\n.UE\n")


def test_man_commands_section_lists_every_subcommand():
    """The COMMANDS section repeats the five subcommands with their help."""
    # CATCHES: the section is generated from the kong model, so a missing or
    # renamed subcommand shows up here.
    page = _page("1600000000").out
    commands = page.split(".SH COMMANDS")[1].split(".SH OPTIONS")[0]
    assert commands.splitlines() == [
        "",
        ".TP",
        ".B query",
        "[default] Execute a query",
        ".TP",
        ".B version",
        "Print the version",
        ".TP",
        ".B interactive",
        "Start an interactive session (alpha)",
        ".TP",
        ".B completion",
        "Generate shell completion script",
        ".TP",
        ".B man",
        "Generate man page",
        "",
    ]
