"""Shared black-box harness for the aux_commands_tui test module.

Two entry points:

* ``run_dasel`` runs the reference binary as a plain child process with no
  controlling terminal, so the text-producing subcommands (version, man,
  completion, help) and the non-TTY error paths can be asserted byte for byte.
* ``run_tui`` boots the binary behind a pseudo terminal.  dasel's interactive
  mode is a bubbletea alt-screen UI, so the harness answers the terminal
  capability queries the program emits at startup (OSC 11 background colour +
  DSR cursor position - without a reply the reference blocks forever), feeds
  every byte the process writes into a small VT100 screen emulator and exposes
  the resulting cell grid, plus the raw tail that follows the alt-screen
  teardown (that is where dasel echoes the final selector).
"""

from __future__ import annotations

import fcntl
import os
import pty
import re
import select
import signal
import struct
import subprocess
import termios
import time
import unicodedata
import warnings
from pathlib import Path

import pytest

# The version string the reference reports for an untagged build.
VERSION = "development"

# Sorted list of formats dasel registers *readers* for (recorded from
# `dasel completion bash`).  Note it contains "dasel" but not "plain".
READER_FORMATS = ["csv", "dasel", "hcl", "ini", "json", "kdl", "toml", "xml", "yaml"]

# Sorted list of formats dasel registers *writers* for.  The interactive UI
# cycles the writer through this list, which swaps "dasel" for "plain".
WRITER_FORMATS = ["csv", "hcl", "ini", "json", "kdl", "plain", "toml", "xml", "yaml"]


def _executable() -> Path:
    """Absolute path of the binary under test."""
    raw = os.environ.get("PROGRAMGYM_EXECUTABLE") or "executable"
    path = Path(raw)
    if not path.is_absolute():
        # run.sh starts pytest in the module root, so a relative setting
        # resolves against the directory that contains eval/tests/.
        rooted = Path(__file__).resolve().parents[2] / raw
        if rooted.exists():
            return rooted
    return path


def _child_env(extra=None) -> dict:
    """Pinned child environment, forwarding the coverage hook when set."""
    env = {
        "PATH": "/usr/bin:/bin",
        "LC_ALL": "C.UTF-8",
        "LANG": "C.UTF-8",
        "TZ": "UTC",
        # Keep the default config lookup away from the real home directory.
        "HOME": "/nonexistent-home",
    }
    if extra:
        for key, value in extra.items():
            if value is None:
                env.pop(key, None)
            else:
                env[key] = value
    # Coverage instrumentation hook: the pipeline rebuilds the reference with
    # -cover and points GOCOVERDIR at a counter directory; without forwarding
    # it the module's coverage report would come out empty.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    return env


class Result:
    """One dasel invocation: raw stdout/stderr bytes plus the exit status."""

    def __init__(self, returncode: int, stdout: bytes, stderr: bytes) -> None:
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

    @property
    def out(self) -> str:
        return self.stdout.decode("utf-8", errors="replace")

    @property
    def err(self) -> str:
        return self.stderr.decode("utf-8", errors="replace")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return ("Result(returncode=%r, stdout=%r, stderr=%r)"
                % (self.returncode, self.stdout, self.stderr))


def run_dasel(args, stdin: bytes = b"", env=None, cwd=None,
              timeout: float = 20.0) -> Result:
    """Run the binary under test with ``args`` and no controlling terminal.

    ``stdin`` defaults to an immediately-EOF pipe.  The child is started in a
    new session so ``/dev/tty`` can never be opened, which keeps the "could not
    open a new TTY" error path of the interactive mode deterministic even when
    pytest itself is run from a terminal.
    """
    argv = [str(_executable())] + [str(a) for a in args]
    proc = subprocess.run(
        argv,
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=_child_env(env),
        timeout=timeout,
        start_new_session=True,
    )
    return Result(proc.returncode, proc.stdout, proc.stderr)


# --------------------------------------------------------------------- screen


def _rune_width(ch: str) -> int:
    """Terminal cell width of a rune (East Asian Wide/Fullwidth -> 2)."""
    if unicodedata.combining(ch):
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    return 1


class Cell:
    __slots__ = ("ch", "fg", "bg", "attrs")

    def __init__(self):
        self.ch = " "
        self.fg = None
        self.bg = None
        self.attrs = frozenset()


class Screen:
    """A minimal VT100/xterm screen emulator (text + SGR style per cell).

    Handles the subset of control sequences bubbletea/lipgloss emit: CUP,
    CUU/CUD/CUF/CUB/CHA/VPA, ED/EL, SGR (incl. 38;5/38;2/48;5/48;2 and dotted
    sub-parameters such as ``4:4``), OSC (BEL and ESC \\ terminated), DCS/PM/APC
    skipping, DECSC/DECRC and CR/LF/BS/TAB with UTF-8 decoding.  Private mode
    set/reset sequences (alt screen 1049, bracketed paste 2004, ...) are parsed
    and ignored: the grid keeps accumulating frames, which is what a test wants
    when it snapshots the last drawn UI.
    """

    def __init__(self, rows, cols):
        self.rows = rows
        self.cols = cols
        self.cx = 0
        self.cy = 0
        self.saved = (0, 0)
        self.fg = None
        self.bg = None
        self.attrs = frozenset()
        self.grid = [[Cell() for _ in range(cols)] for _ in range(rows)]
        self._buf = bytearray()

    # ------------------------------------------------------------- rendering

    def _put(self, ch, w):
        if self.cy >= self.rows:
            self._scroll()
        if not (0 <= self.cy < self.rows):
            return
        if w == 0:  # combining mark: attach to the cell on the left
            if self.cx > 0:
                self.grid[self.cy][self.cx - 1].ch += ch
            return
        if self.cx >= self.cols:
            self.cx = 0
            self.cy += 1
            if self.cy >= self.rows:
                self._scroll()
                if self.cy >= self.rows:
                    return
        c = self.grid[self.cy][self.cx]
        c.ch = ch
        c.fg = self.fg
        c.bg = self.bg
        c.attrs = self.attrs
        if w == 2 and self.cx + 1 < self.cols:
            d = self.grid[self.cy][self.cx + 1]
            d.ch = ""
            d.fg = self.fg
            d.bg = self.bg
            d.attrs = self.attrs
        self.cx += w

    def _scroll(self):
        if self.cy >= self.rows:
            self.grid.pop(0)
            self.grid.append([Cell() for _ in range(self.cols)])
            self.cy = self.rows - 1

    def _erase(self, y, x0, x1):
        row = self.grid[y]
        for x in range(max(0, x0), min(self.cols, x1)):
            row[x] = Cell()

    # ------------------------------------------------------------- sequences

    def _sgr(self, paramstr):
        toks = paramstr.lstrip(">").split(";") or ["0"]
        if paramstr == "":
            toks = ["0"]

        def reset():
            self.fg = None
            self.bg = None
            self.attrs = frozenset()

        i = 0
        n = len(toks)
        while i < n:
            t = toks[i]
            head, _, sub = t.partition(":")
            p = int(head) if head.isdigit() else 0
            if p == 0:
                reset()
            elif p == 1:
                self.attrs = self.attrs | {"bold"}
            elif p == 2:
                self.attrs = self.attrs | {"dim"}
            elif p == 3:
                self.attrs = self.attrs | {"italic"}
            elif p == 4:
                # 4 / 4:1 plain underline, 4:0 off; other dotted styles underline
                if sub not in ("0",):
                    self.attrs = self.attrs | {"underline"}
            elif p in (5, 6):
                self.attrs = self.attrs | {"blink"}
            elif p == 7:
                self.attrs = self.attrs | {"reverse"}
            elif p == 9:
                self.attrs = self.attrs | {"strikethrough"}
            elif p == 22:
                self.attrs = self.attrs - {"bold", "dim"}
            elif p == 23:
                self.attrs = self.attrs - {"italic"}
            elif p == 24:
                self.attrs = self.attrs - {"underline"}
            elif p == 27:
                self.attrs = self.attrs - {"reverse"}
            elif p == 29:
                self.attrs = self.attrs - {"strikethrough"}
            elif 30 <= p <= 37:
                self.fg = p - 30
            elif p == 39:
                self.fg = None
            elif 40 <= p <= 47:
                self.bg = p - 40
            elif p == 49:
                self.bg = None
            elif 90 <= p <= 97:
                self.fg = p - 82
            elif 100 <= p <= 107:
                self.bg = p - 92
            elif p in (38, 48, 58):
                if sub:  # dotted 38:5:n / 38:2:r:g:b form
                    parts = (head,) + tuple(sub.split(":"))
                else:
                    parts = tuple(toks[i:])
                color = None
                if len(parts) > 2 and parts[1] == "5" and parts[2].isdigit():
                    color = int(parts[2])
                    i += 2
                elif len(parts) > 4 and parts[1] == "2":
                    color = tuple(int(x) if x.isdigit() else 0 for x in parts[2:5])
                    i += 4
                if p == 38:
                    self.fg = color
                elif p == 48:
                    self.bg = color
            i += 1

    def _csi(self, paramstr, final):
        priv = paramstr.startswith("?") or paramstr.startswith(">")
        params = []
        for p in paramstr.lstrip("?><!").split(";"):
            params.append(int(p) if p.isdigit() else None)
        default = lambda idx, d: (params[idx] if idx < len(params)
                                  and params[idx] is not None else d)

        if final in ("H", "f"):
            self.cy = max(0, default(0, 1) - 1)
            self.cx = max(0, default(1, 1) - 1)
        elif final == "A":
            self.cy = max(0, self.cy - max(1, default(0, 1)))
        elif final == "B":
            self.cy = min(self.rows - 1, self.cy + max(1, default(0, 1)))
        elif final == "C":
            self.cx = min(self.cols - 1, self.cx + max(1, default(0, 1)))
        elif final == "D":
            self.cx = max(0, self.cx - max(1, default(0, 1)))
        elif final == "G":
            self.cx = max(0, default(0, 1) - 1)
        elif final == "d":
            self.cy = max(0, default(0, 1) - 1)
        elif final == "J":
            mode = default(0, 0)
            if mode == 0:
                self._erase(self.cy, self.cx, self.cols)
                for y in range(self.cy + 1, self.rows):
                    self._erase(y, 0, self.cols)
            elif mode == 1:
                self._erase(self.cy, 0, self.cx + 1)
                for y in range(0, self.cy):
                    self._erase(y, 0, self.cols)
            else:
                for y in range(self.rows):
                    self._erase(y, 0, self.cols)
        elif final == "K":
            mode = default(0, 0)
            if mode == 0:
                self._erase(self.cy, self.cx, self.cols)
            elif mode == 1:
                self._erase(self.cy, 0, self.cx + 1)
            else:
                self._erase(self.cy, 0, self.cols)
        elif final == "m" and not priv:
            self._sgr(paramstr)
        # everything else (h/l/n/q/r/s/t/u/...) ignored

    def feed(self, data):
        self._buf += data
        buf = self._buf
        i, n = 0, len(buf)
        while i < n:
            b = buf[i]
            if b == 0x1B:
                if i + 1 >= n:
                    break
                c = buf[i + 1]
                if c == 0x5B:  # CSI
                    j = i + 2
                    while j < n and not (0x40 <= buf[j] <= 0x7E):
                        j += 1
                    if j >= n:
                        break
                    self._csi(bytes(buf[i + 2:j]).decode("latin-1"), chr(buf[j]))
                    i = j + 1
                elif c == 0x5D:  # OSC ... BEL / ESC \
                    j = i + 2
                    end = -1
                    while j < n:
                        if buf[j] == 0x07:
                            end = j + 1
                            break
                        if buf[j] == 0x1B and j + 1 < n and buf[j + 1] == 0x5C:
                            end = j + 2
                            break
                        j += 1
                    if end < 0:
                        break
                    i = end
                elif c in (0x50, 0x58, 0x5E, 0x5F):  # DCS/SOS/PM/APC ... ESC \
                    j = i + 2
                    end = -1
                    while j < n:
                        if buf[j] == 0x1B and j + 1 < n and buf[j + 1] == 0x5C:
                            end = j + 2
                            break
                        j += 1
                    if end < 0:
                        break
                    i = end
                elif c in (0x28, 0x29, 0x2A, 0x2B, 0x23, 0x25):
                    if i + 2 >= n:
                        break
                    i += 3
                elif c == 0x37:  # DECSC
                    self.saved = (self.cx, self.cy)
                    i += 2
                elif c == 0x38:  # DECRC
                    self.cx, self.cy = self.saved
                    i += 2
                elif c == 0x63:  # RIS
                    self.__init__(self.rows, self.cols)
                    i += 2
                else:
                    i += 2
            elif b == 0x0D:
                self.cx = 0
                i += 1
            elif b == 0x0A:
                self.cy += 1
                if self.cy >= self.rows:
                    self._scroll()
                i += 1
            elif b == 0x08:
                self.cx = max(0, self.cx - 1)
                i += 1
            elif b == 0x09:
                self.cx = min((self.cx // 8 + 1) * 8, self.cols - 1)
                i += 1
            elif b < 0x20 or b == 0x7F:
                i += 1
            else:
                if b < 0x80:
                    w = 1
                elif b < 0xC0:
                    i += 1  # stray continuation byte
                    continue
                elif b < 0xE0:
                    w = 2
                elif b < 0xF0:
                    w = 3
                else:
                    w = 4
                if i + w > n:
                    break
                try:
                    ch = bytes(buf[i:i + w]).decode("utf-8")
                except UnicodeDecodeError:
                    ch = "�"
                for r in ch:
                    self._put(r, _rune_width(r))
                i += w
        del self._buf[:i]

    # ------------------------------------------------------------- accessors

    def rows_text(self):
        return ["".join(c.ch for c in row).rstrip() for row in self.grid]

    def text(self):
        return "\n".join(self.rows_text())

    def style(self, y, x):
        """(fg, bg, attrs) of one cell; fg/bg are palette indices, RGB tuples
        or None for default; attrs is a sorted tuple of attribute names."""
        if 0 <= y < self.rows and 0 <= x < self.cols:
            c = self.grid[y][x]
            return (c.fg, c.bg, tuple(sorted(c.attrs)))
        return None


# -------------------------------------------------------------------- TUI run

# Leading CSI sequences are stripped when extracting what dasel printed after
# the alt screen was torn down (bubbletea restores the cursor on the way out).
_CSI_RE = re.compile(rb"^\x1b\[[?0-9;]*[A-Za-z]")
# Alt-screen leave sequence, used as the split point for the echoed selector.
_ALT_LEAVE = b"\x1b[?1049l"


class TUIRun:
    """A single dasel interactive session driving a pseudo terminal."""

    def __init__(self, args, stdin_data=None, rows=30, cols=100, env=None,
                 cwd=None, settle=0.45):
        self.exe = str(_executable())
        self.rows, self.cols = rows, cols
        self.settle = settle
        self.raw = bytearray()
        self.screen = Screen(rows, cols)
        self.exit_status = None
        self._pid = None
        self._master = None

        master, slave = pty.openpty()
        # set the window size before the child can possibly read it
        fcntl.ioctl(slave, termios.TIOCSWINSZ,
                    struct.pack("HHHH", rows, cols, 0, 0))

        # Feed the session's input data through a pipe: dasel's main() only
        # treats character devices as "no stdin", so this is how the Root pane
        # gets real documents to display while the pty stays the key input.
        in_r, in_w = os.pipe()
        if stdin_data is None:
            os.close(in_r)
            os.close(in_w)
            in_r = None
        else:
            os.write(in_w, stdin_data if isinstance(stdin_data, bytes)
                     else stdin_data.encode("utf-8"))
            os.close(in_w)

        child_env = _child_env(env)
        child_env.setdefault("TERM", "xterm-256color")

        # fork()+exec is the only way to get a session leader on a new
        # controlling terminal; the child only touches fds and execv's, so the
        # "multi-threaded process" deprecation does not apply in practice.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            pid = os.fork()
        if pid == 0:  # child
            try:
                os.setsid()
                fcntl.ioctl(slave, termios.TIOCSCTTY, 0)
                os.dup2(in_r if in_r is not None else slave, 0)
                os.dup2(slave, 1)
                os.dup2(slave, 2)
                if slave > 2:
                    os.close(slave)
                os.close(master)
                if in_r is not None and in_r > 2:
                    os.close(in_r)
                if cwd:
                    os.chdir(str(cwd))
                os.environ.clear()
                os.environ.update(child_env)
                os.execv(self.exe, [self.exe] + [str(a) for a in args])
            except BaseException:
                os._exit(127)
        os.close(slave)
        if in_r is not None:
            os.close(in_r)
        self._pid = pid
        self._master = master
        self._pump(3.0)

    # --------------------------------------------------------------- pumping

    def _respond(self, chunk):
        """Answer the terminal queries termenv/lipgloss block on."""
        if b"\x1b]11;?" in chunk:
            os.write(self._master, b"\x1b]11;rgb:0000/0000/0000\x1b\\")
        if b"\x1b[6n" in chunk:
            os.write(self._master, b"\x1b[1;1R")

    def _pump(self, max_dur, feed_screen=True):
        """Read output until the stream goes quiet (or ``max_dur`` elapses)."""
        if self._master is None:
            return
        t0 = time.monotonic()
        last = t0
        while True:
            now = time.monotonic()
            elapsed = now - t0
            quiet = now - last
            if (quiet >= self.settle and elapsed >= self.settle) or elapsed >= max_dur:
                return
            timeout = min(self.settle - quiet, max(0.01, max_dur - elapsed))
            try:
                r, _, _ = select.select([self._master], [], [], timeout)
            except OSError:
                self._dead()
                return
            if not r:
                continue
            try:
                data = os.read(self._master, 65536)
            except OSError:
                self._dead()
                return
            if not data:
                self._dead()
                return
            self.raw += data
            if feed_screen:
                self.screen.feed(data)
            self._respond(data)
            last = time.monotonic()

    def _dead(self):
        """Reap the child if it exited; drop the master either way."""
        if self._pid is not None:
            try:
                pid, status = os.waitpid(self._pid, os.WNOHANG)
                if pid == self._pid:
                    self.exit_status = status
                    self._pid = None
            except ChildProcessError:
                self._pid = None
        if self._master is not None:
            try:
                os.close(self._master)
            except OSError:
                pass
            self._master = None

    # ------------------------------------------------------------- interaction

    def send(self, keys):
        """Write ``keys`` to the pty and wait for the UI to settle."""
        if isinstance(keys, str):
            keys = keys.encode("utf-8")
        if self._master is None:
            return
        try:
            os.write(self._master, keys)
        except OSError:
            self._dead()
            return
        self._pump(3.0)

    def resize(self, rows, cols):
        """Change the pty window size and wait for the repaint."""
        self.rows, self.cols = rows, cols
        if self._master is None:
            return
        try:
            fcntl.ioctl(self._master, termios.TIOCSWINSZ,
                        struct.pack("HHHH", rows, cols, 0, 0))
        except OSError:
            return
        # The repaint uses absolute addressing, so replaying the whole byte
        # history into a fresh grid of the new size keeps the snapshot intact.
        self.screen = Screen(rows, cols)
        self.screen.feed(bytes(self.raw))
        self._pump(3.0)

    def quit(self, timeout=4.0):
        """Send ctrl+c and collect everything the process prints while exiting.

        The exit-time bytes are appended to ``raw`` but deliberately NOT fed
        into the screen emulator: they tear the alt screen down, and the test
        wants to keep the last drawn UI frame around for assertions.
        """
        if self._master is None:
            return self.exit_status
        try:
            os.write(self._master, b"\x03")
        except OSError:
            self._dead()
            return self.exit_status
        t0 = time.monotonic()
        while time.monotonic() - t0 < timeout:
            try:
                r, _, _ = select.select([self._master], [], [], 0.1)
            except OSError:
                break
            if r:
                try:
                    data = os.read(self._master, 65536)
                except OSError:
                    break
                if not data:
                    break
                self.raw += data
            try:
                pid, status = os.waitpid(self._pid, os.WNOHANG)
            except ChildProcessError:
                self._pid = None
                break
            if pid == self._pid:
                self.exit_status = status
                self._pid = None
                break
        self._dead()
        return self.exit_status

    def close(self):
        """Make sure the child is gone (coverage counters need a clean exit)."""
        if self._pid is not None:
            self.quit()
        if self._pid is not None:
            try:
                os.kill(self._pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                os.waitpid(self._pid, 0)
            except ChildProcessError:
                pass
            self._pid = None
        if self._master is not None:
            try:
                os.close(self._master)
            except OSError:
                pass
            self._master = None

    # -------------------------------------------------------------- accessors

    def rows_text(self):
        return self.screen.rows_text()

    def row(self, index):
        return self.screen.rows_text()[index]

    @property
    def text(self):
        return self.screen.text()

    @property
    def exited_cleanly(self):
        """True when the process terminated with exit status 0."""
        return os.WIFEXITED(self.exit_status) and os.WEXITSTATUS(self.exit_status) == 0

    @property
    def echoed(self):
        """What dasel wrote to stdout after the alt-screen UI was torn down."""
        tail = bytes(self.raw).rsplit(_ALT_LEAVE, 1)[-1]
        while True:
            stripped = _CSI_RE.sub(b"", tail)
            if stripped == tail:
                break
            tail = stripped
        return tail.replace(b"\r\n", b"\n").decode("utf-8", errors="replace")


# ------------------------------------------------------------------- fixtures


@pytest.fixture
def run_tui(tmp_path):
    """Factory booting one dasel interactive session in a pseudo terminal.

    Keyword arguments:
      args        -- command line arguments (e.g. ``["interactive", "-i", "yaml"]``)
      stdin_data  -- bytes piped to the child's stdin (what the Root pane shows)
      keys        -- byte sequences written to the pty after startup, in order
      rows/cols   -- terminal size (default 30x100)
      env         -- extra child environment overrides
      config      -- contents of the dasel config file (default: empty, which
                     leaves the built-in json defaults in place).  Pass None to
                     leave the -c flag off entirely.
      quit        -- send ctrl+c once the keys are done (default True) so the
                     final selector echo and exit status can be asserted
    """
    runs = []
    counter = [0]

    def factory(args, stdin_data=None, keys=(), rows=30, cols=100, env=None,
                config="", quit=True, settle=0.45):
        counter[0] += 1
        args = [str(a) for a in args]
        if config is not None:
            path = tmp_path / ("dasel-%d.yaml" % counter[0])
            path.write_text(config, encoding="utf-8")
            args = args + ["-c", str(path)]
        run = TUIRun(args, stdin_data=stdin_data, rows=rows, cols=cols,
                     env=env, cwd=str(tmp_path), settle=settle)
        runs.append(run)
        for k in keys:
            run.send(k)
        if quit:
            run.quit()
        return run

    yield factory
    for run in runs:
        run.close()


@pytest.fixture
def dasel_config(tmp_path):
    """Write a dasel config file into tmp_path and return its path."""
    def factory(text):
        path = tmp_path / "dasel.yaml"
        path.write_text(text, encoding="utf-8")
        return path
    return factory
