"""`dasel version` - the self-reported version string."""

import re

from conftest import VERSION, run_dasel


def test_version_prints_the_untagged_build_string():
    """`dasel version` prints `development` followed by a single newline."""
    # CATCHES: an untagged build reports the literal `development` string that
    # internal/version.go falls back to, not an empty line or a semver.
    res = run_dasel(["version"])
    assert res.returncode == 0
    assert res.stdout == b"development\n"
    assert res.stderr == b""


def test_version_output_is_a_single_line():
    """The version output is exactly one line with no trailing spaces."""
    # CATCHES: the writer appends exactly one \\n to the version string.
    res = run_dasel(["version"])
    lines = res.stdout.decode().split("\n")
    assert lines == ["development", ""]


def test_version_writes_to_stdout_not_stderr():
    """The version goes to stdout; stderr stays empty even with stdin data."""
    # CATCHES: VersionCmd writes to the Globals' Stdout writer, so a wrong
    # re-implementation that uses stderr fails here.
    res = run_dasel(["version"], stdin=b'{"still":"not","a":"version"}')
    assert res.stdout == b"development\n"
    assert res.stderr == b""
    assert res.returncode == 0


def test_version_ignores_the_config_file():
    """`dasel version` never loads the config, even a broken one."""
    # CATCHES: version is a bare subcommand - it fails on an unknown flag long
    # before any config could be read, and kong suggests the -h short flag.
    res = run_dasel(["version", "-c", "/nonexistent/dasel.yaml"])
    assert res.returncode == 80
    assert res.stderr == b'dasel: error: unknown flag -c, did you mean "-h"?\n'
    assert res.stdout.startswith(b"Usage: dasel version\n")


def test_version_is_stable_across_invocations():
    """Two runs report the identical version string."""
    # CATCHES: the version is a build-time constant, not derived from the
    # environment or the current time.
    first = run_dasel(["version"])
    second = run_dasel(["version"], stdin=b"")
    assert first.stdout == second.stdout
    assert first.returncode == second.returncode == 0


def test_version_matches_the_version_reported_elsewhere():
    """The same version string appears in the man page and the TUI header."""
    # CATCHES: internal.Version is the single source for `dasel version`, the
    # man page .TH header and the interactive-mode heading.
    version = run_dasel(["version"]).out.strip()
    assert version == VERSION

    man = run_dasel(["man"], env={"SOURCE_DATE_EPOCH": "1600000000"})
    header = man.out.splitlines()[0]
    assert header == '.TH DASEL 1 "2020-09-13" "%s" "DASEL Manual"' % version

    assert re.match(r"^development(-[\w.]+)?$", version)
