"""Observable semantics of the model package's value types.

The selectors here pin the value model itself rather than one executor: how
maps compare and keep their key order, what the length of each value kind is
(and that string length counts bytes while string ranges index runes), that
binding a value to a variable or collecting it into a literal shares it with
the document instead of copying it, and the type errors the model raises for
keys, indexes and lengths.
"""

import pytest


# --- map equality -----------------------------------------------------------


@pytest.mark.parametrize(
    "selector,input_text,expected",
    [
        ('{"a":1,"b":2} == {"b":2,"a":1}', "null", "true\n"),
        ('{"a":{"x":1,"y":2}} == {"a":{"y":2,"x":1}}', "null", "true\n"),
        ('{"a":1} == {"a":1,"b":2}', "null", "false\n"),
        ('{"a":1,"b":2} != {"b":2,"a":1}', "null", "false\n"),
        ('{"a":null} == {}', "null", "false\n"),
        ('$this == {"b":2,"a":1}', '{"a":1,"b":2}', "true\n"),
    ],
)
def test_map_equality_ignores_key_order(run_dasel, selector, input_text,
                                        expected):
    """Maps holding the same pairs compare equal whatever the key order."""
    # CATCHES: map equality walks the key list of the left side and looks each
    # key up in the right side, so insertion order never takes part in the
    # comparison - an implementation that compares key sequences (or serialises
    # both sides) would report false for the reordered pairs.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,expected_type_names",
    [
        ("null == {}", "null and map"),
        ("{} == []", "map and array"),
    ],
)
def test_map_equality_still_requires_matching_types(run_dasel, selector,
                                                    expected_type_names):
    """Equality between a map and another kind is an error, not false."""
    # CATCHES: the type check runs before the per-key comparison, so comparing
    # a map with a null or an array is reported as incompatible types with exit
    # code 1 instead of quietly evaluating to false.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: incompatible types: "
        f"{expected_type_names}\n"
    )


# --- length -----------------------------------------------------------------


@pytest.mark.parametrize(
    "selector,input_text,expected",
    [
        ('len("hello")', "null", "5\n"),
        ("len([1, 2, 3])", "null", "3\n"),
        ('len({"a": 1, "b": 2})', "null", "2\n"),
        ('len("")', "null", "0\n"),
        ("len([])", "null", "0\n"),
        ("len({})", "null", "0\n"),
        ('len($this)', '{"a": 1, "b": 2, "c": 3}', "3\n"),
        ('len($this)', '"abcd"', "4\n"),
        ('len({"a": [1, 2], "b": [3]}.a)', "null", "2\n"),
    ],
)
def test_len_of_each_value_kind(run_dasel, selector, input_text, expected):
    """len() reports the element count of arrays, maps and strings alike."""
    # CATCHES: one length operation serves all three collection kinds, so the
    # map case counts keys (not values) and an empty container of any kind
    # reports zero rather than erroring.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,type_name",
    [
        ("len(1)", "int"),
        ("len(1.5)", "float"),
        ("len(true)", "bool"),
        ("len(null)", "null"),
    ],
)
def test_len_rejects_values_without_a_length(run_dasel, selector, type_name):
    """Asking for the length of a scalar fails naming the received type."""
    # CATCHES: the model lists the three accepted kinds in the error text
    # ('[array map string]') and echoes the actual type, so a re-implementation
    # that returns 0 - or that accepts numbers - differs here.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        'dasel: error: error executing selector: execution error when '
        'processing ast.CallExpr: error executing function: error execution '
        f'func "len": unexpected type: expected [array map string], got '
        f"{type_name}\n"
    )


@pytest.mark.parametrize(
    "selector,input_text,expected",
    [
        # Three two-byte runes: the length is 6, one rune alone is 2 bytes.
        ("len($this)", '"\\u00e9\\u00e9\\u00e9"', "6\n"),
        ("len($this[0:0])", '"\\u00e9\\u00e9\\u00e9"', "2\n"),
        # a + two-byte rune + b: rune indexes 0,1,2 but only four bytes.
        ("len($this)", '"a\\u00e9b"', "4\n"),
        ("len($this[0:1])", '"a\\u00e9b"', "3\n"),
        ("len($this[1:1])", '"a\\u00e9b"', "2\n"),
        ("len($this[2:0])", '"a\\u00e9b"', "4\n"),
    ],
)
def test_string_length_counts_bytes_but_ranges_index_runes(run_dasel, selector,
                                                           input_text,
                                                           expected):
    r"""String length is measured in bytes while ranges walk runes."""
    # CATCHES: the two operations disagree on purpose - length counts the UTF-8
    # bytes of the string while a range indexes its runes - so a document of
    # three two-byte runes has length 6 yet [0:0] yields a single rune. The
    # inputs are written with JSON \u escapes so they stay ASCII.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


# --- value sharing (aliasing) ----------------------------------------------


@pytest.mark.parametrize(
    "selector,input_text",
    [
        ('$x = $this; $x.a = 9; $root.a', '{"a": 1, "b": 2}'),
        ('$x = $this.a; $x.b = 9; $root.a.b', '{"a": {"b": 1}, "c": 2}'),
        ('$x = $this.a; $x[0] = 9; $root.a[0]', '{"a": [1, 2]}'),
        ('$x = $this; $y = $x; $y.a = 9; $root.a', '{"a": 1}'),
    ],
)
def test_assigning_to_a_variable_shares_the_value(run_dasel, selector,
                                                  input_text):
    """A variable is another name for the value, never a copy of it."""
    # CATCHES: binding $x stores the very same value, so a write through the
    # variable is visible through $root - an implementation that copies on
    # assignment (or on re-assignment to a second variable) leaves the
    # document untouched and prints the old value instead of 9.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "9\n"
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,input_text",
    [
        ("$x = filter($this.b == 1); $x[0].b = 9; $root[0].b",
         '[{"b": 1}, {"b": 2}]'),
        ("$x = map($this); $x[0].b = 9; $root[0].b", '[{"b": 1}]'),
        ("$x = sortBy(b); $x[0].b = 9; $root[0].b", '[{"b": 1}, {"b": 2}]'),
        ("$x = [$root[0]]; $x[0].b = 9; $root[0].b", '[{"b": 1}]'),
        ('$x = {$this...}; $x.a.b = 9; $root.a.b', '{"a": {"b": 1}, "c": 2}'),
    ],
)
def test_derived_collections_share_their_elements(run_dasel, selector,
                                                 input_text):
    """filter/map/sortBy/literal/spread results reuse the source elements."""
    # CATCHES: every one of these constructs builds a new container around the
    # original element values, so mutating an element of the result mutates the
    # document too; a deep-copying implementation would print 1 rather than 9.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "9\n"
    assert proc.stderr == ""


def test_range_results_share_their_elements_with_the_source(run_dasel):
    """Writing through a range result mutates the original array."""
    # CATCHES: a range collects the original element values into a new slice,
    # so $this[0:1][0] = 9 reaches back into the document and --root shows 9 in
    # the first position - not a detached copy printing [1, 2, 3].
    proc = run_dasel("$this[0:1][0] = 9", "[1, 2, 3]", flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    9,\n    2,\n    3\n]\n"
    assert proc.stderr == ""


def test_object_spread_keys_are_independent_of_the_source(run_dasel):
    """Replacing a key of a spread result leaves the document alone."""
    # CATCHES: the spread copies the key set but shares the values, so writing
    # a whole new value under $x.a only re-points that key in the new map and
    # $root.a still prints the original nested map.
    proc = run_dasel('$x = {$this...}; $x.a = 9; $root.a',
                     '{"a": {"b": 1}, "c": 2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "b": 1\n}\n'
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,expected",
    [
        ('$x = [1, 2]; $x[0] = "s"; $x', '[\n    "s",\n    2\n]\n'),
        ("$x = [1, 2]; $x[0] = null; $x", "[\n    null,\n    2\n]\n"),
        ('$x = [1, 2]; $x[0] = {"z": 1}; $x',
         '[\n    {\n        "z": 1\n    },\n    2\n]\n'),
    ],
)
def test_assigning_into_a_constructed_array_element(run_dasel, selector,
                                                    expected):
    """Index assignment works on arrays the query built itself."""
    # CATCHES: elements of a constructed array are wrapped values rather than
    # plain document nodes, and the set has to unwrap that wrapper before
    # storing - including when the replacement is a null or a map.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


# --- ordered map key handling ----------------------------------------------


@pytest.mark.parametrize(
    "selector,input_text",
    [
        ('{"a": 1, "a": 2}', "null"),
        ("$this", '{"a": 1, "a": 2}'),
    ],
)
def test_duplicate_keys_keep_one_entry(run_dasel, selector, input_text):
    """A repeated key overwrites the value and keeps a single entry."""
    # CATCHES: setting an existing key replaces the stored value without
    # appending the key a second time, so both an object literal and a document
    # read from stdin end up with exactly one "a" holding the last value.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 2\n}\n'
    assert proc.stderr == ""


def test_assignment_keeps_the_key_position(run_dasel):
    """Updating a key does not move it to the end of the map."""
    # CATCHES: overwriting a value keeps the key in the slot it already had,
    # so the document still prints z, a, m after a is reassigned - a
    # delete-then-append implementation would print a, m, z.
    proc = run_dasel("a = 9", '{"z": 1, "a": 2, "m": 3}', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "z": 1,\n    "a": 9,\n    "m": 3\n}\n'
    assert proc.stderr == ""


def test_object_spread_keeps_the_spread_key_position(run_dasel):
    """An explicit pair overwrites a spread key in place."""
    # CATCHES: the spread inserts a first, then the explicit "a": 9 replaces
    # the value in that slot, giving a then b rather than b then a.
    proc = run_dasel('{$this..., "a": 9}', '{"a": 1, "b": 2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 9,\n    "b": 2\n}\n'
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,input_text,expected",
    [
        ("[...]", '{"a": 1, "b": 2}', "[\n    1,\n    2\n]\n"),
        ("[...]", "[1, 2, 3]", "[\n    1,\n    2,\n    3\n]\n"),
        ("{...}", '{"a": 1, "b": 2}', '{\n    "a": 1,\n    "b": 2\n}\n'),
        ('{..., "b": 9}', '{"a": 1, "b": 2}', '{\n    "a": 1,\n    "b": 9\n}\n'),
    ],
)
def test_bare_spreads_use_the_input_value(run_dasel, selector, input_text,
                                          expected):
    """A bare ``...`` with no expression spreads the current value."""
    # CATCHES: a spread that names no source falls back to the input document,
    # so [...] lists the elements (or map values) of the input and {...}
    # rebuilds it, with a following pair still able to overwrite a copied key.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,input_text,type_name",
    [
        ("{...}", "[1, 2]", "array"),
        ("{...}", "5", "int"),
    ],
)
def test_bare_object_spread_still_requires_a_map(run_dasel, selector,
                                                 input_text, type_name):
    """Spreading a non-map into an object literal fails naming the type."""
    # CATCHES: the fallback source is used verbatim, so the usual map-keys
    # error is raised for arrays and scalars alike - an implementation that
    # skipped the spread for an unusable source would print an empty object.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr.endswith(
        "ast.ObjectExpr: error spreading into object: error getting map "
        f"keys: unexpected type: expected map, got {type_name}\n"
    )


@pytest.mark.parametrize(
    "selector,input_text,expected",
    [
        ("[$this...]", '{"a": 1, "b": 2}', "[\n    1,\n    2\n]\n"),
        ("[$this.a...]", '{"a": {"x": 1, "y": 2}}', "[\n    1,\n    2\n]\n"),
    ],
)
def test_spreading_a_map_into_an_array_lists_its_values(run_dasel, selector,
                                                        input_text, expected):
    """Spreading a map into an array literal takes the values in key order."""
    # CATCHES: a spread of a map contributes one element per key, ordered by
    # the map's insertion order, so the result is [1, 2] and not a single map
    # element or an alphabetically reordered list.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


# --- key and index type errors ---------------------------------------------


@pytest.mark.parametrize(
    "key_expr,type_name",
    [
        ("1.5", "float"),
        ("true", "bool"),
        ("null", "null"),
        ('{"x": 1}', "map"),
    ],
)
def test_property_keys_must_be_strings_or_ints(run_dasel, key_expr,
                                               type_name):
    """An index/property expression may only resolve to a string or int."""
    # CATCHES: the property executor dispatches on the resolved key type and
    # rejects everything else, naming the type it got - so a float index is an
    # error rather than a truncation to 1.
    proc = run_dasel(f"a[{key_expr}]", '{"a": [1, 2]}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        f"error when processing ast.PropertyExpr: expected key to be a string "
        f"or int, got {type_name}\n"
    )


def test_object_literal_keys_must_resolve_to_strings(run_dasel):
    """A non-string object literal key is rejected at execution time."""
    # CATCHES: only the value side is free-form - the key must evaluate to a
    # string, and an int key fails with the type name rather than being
    # stringified into {"1": "x"}.
    proc = run_dasel('{(1): "x"}', "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ObjectExpr: expected key to resolve to string, got "
        "int\n"
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        ('{("a" + "b"): 1}', '{\n    "ab": 1\n}\n'),
        ('$k = "z"; {$k: 5}', '{\n    "z": 5\n}\n'),
    ],
)
def test_object_literal_keys_may_be_computed(run_dasel, selector, expected):
    """A parenthesised or variable key is evaluated, not taken literally."""
    # CATCHES: the key position runs a full expression, so concatenation and
    # variable reads both produce the final key name - an implementation that
    # only accepts bare property names would fail to build these objects.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "input_text,type_name",
    [
        ('"abc"', "string"),
        ("5", "int"),
    ],
)
def test_index_access_requires_an_array(run_dasel, input_text, type_name):
    """[0] on a value that is not an array is a type error."""
    # CATCHES: indexing falls through to the slice lookup, which rejects
    # non-arrays - strings are not indexable character by character even
    # though they support ranges.
    proc = run_dasel("$this[0]", input_text)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        f"error when processing ast.PropertyExpr: unexpected type: expected "
        f"array, got {type_name}\n"
    )


def test_repeated_hcl_blocks_become_independent_copies(run_dasel):
    """Two blocks with the same name are collected as separate objects."""
    # CATCHES: the second block deep-copies the first before both are put into
    # an array, so writing to block.a[0].x leaves block.a[1].x untouched; a
    # shallow copy that shared the inner map would print 99 twice. HCL input is
    # used only to build this shape - the behaviour under test is the copy.
    hcl = 'block "a" {\n  x = 1\n}\nblock "a" {\n  x = 2\n}\n'
    proc = run_dasel("block.a[0].x = 99", hcl, in_format="hcl",
                     flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '{\n    "block": {\n        "a": [\n            {\n'
        '                "x": 99\n            },\n            {\n'
        '                "x": 2\n            }\n        ]\n    }\n}\n'
    )
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,expected",
    [
        ('merge({"a": 1, "b": 2}, {"a": 3})',
         '{\n    "a": 3,\n    "b": 2\n}\n'),
        ('merge({"a": {"x": 1}}, {"a": {"y": 2}})',
         '{\n    "a": {\n        "x": 1,\n        "y": 2\n    }\n}\n'),
        ('merge({"a": 1}, {"b": 2}, {"a": 9, "c": 3})',
         '{\n    "a": 9,\n    "b": 2,\n    "c": 3\n}\n'),
    ],
)
def test_merge_keeps_key_position_and_merges_deeply(run_dasel, selector,
                                                    expected):
    """merge() overwrites in place and recurses into nested maps."""
    # CATCHES: a key present in both arguments keeps its first-seen position
    # with the later value (orderedmap set semantics, not append), maps under
    # the same key are deep-merged key-by-key rather than replaced, and any
    # number of arguments fold left-to-right.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_merge_result_shares_its_values_with_the_sources(run_dasel):
    """Values stored by merge() are shared, not copied."""
    # CATCHES: writing through the merged map reaches the original document,
    # so merge stores the same underlying values (SetMapKey keeps the *Value)
    # - a deep-copying merge would print 1 here.
    proc = run_dasel(
        '$m = merge($this, {"b": 3}); $m.a.c = 9; $root.a.c',
        '{"a": {"c": 1}}',
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "9\n"


@pytest.mark.parametrize(
    "selector,stdin,flags,expected",
    [
        # Rebinding a variable that was bound to the whole document leaves
        # the document (and the --root print) untouched.
        ("$x = $this; $x = 5; $root", '{"a": 1}', (),
         '{\n    "a": 1\n}\n'),
        ("$x = $this; $x = 5", '{"a": 1}', ("--root",),
         '{\n    "a": 1\n}\n'),
        # Navigating *through* the variable still shares (the map is the
        # same), but rebinding the variable itself does not reach it.
        ("$x = $this.a; $x.b = 9; $root", '{"a": {"b": 1}, "c": 2}', (),
         '{\n    "a": {\n        "b": 9\n    },\n    "c": 2\n}\n'),
        ("$x = $this.a; $x = 9; $root", '{"a": {"b": 1}, "c": 2}', (),
         '{\n    "a": {\n        "b": 1\n    },\n    "c": 2\n}\n'),
        # Rebinding works on plain scalars too.
        ("$x = 1; $x = 2; $x", "null", (), "2\n"),
    ],
)
def test_reassigning_a_variable_rebinds_it_without_mutating(
        run_dasel, selector, stdin, flags, expected):
    """= on an existing variable rebinds the variable; only $this rewrites."""
    # CATCHES: unlike `$this = 5` (which rewrites what --root prints) or
    # `$x.b = 9` (which mutates the shared map), a direct `$x = <value>`
    # swaps what the variable points at, so the document is unchanged; the
    # variable just holds the new value afterwards.
    proc = run_dasel(selector, stdin, flags=flags)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
