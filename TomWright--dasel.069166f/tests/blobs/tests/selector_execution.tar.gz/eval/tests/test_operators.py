"""Operator semantics: arithmetic, comparison, logic, regex and coalescing.

Covers the int/float/string coercion rules of the arithmetic operators,
operator precedence and grouping, the comparison family including the
int/float special case, logical and unary operators, regex matching with =~
and !~, and the null-coalescing operator's error suppression.
"""

import pytest

ARITHMETIC = [
    ("1+2", "3\n"),
    ("5-3", "2\n"),
    ("2*3", "6\n"),
    ("7/2", "3\n"),
    ("1/2", "0\n"),
    ("7%2", "1\n"),
    ("7.0/2", "3.5\n"),
    ("10 % 3.5", "3\n"),
    ("0.1 + 0.2", "0.30000000000000004\n"),
    ("1 + 2.5", "3.5\n"),
    ("1.5 + 1", "2.5\n"),
    ("1 - 0.5", "0.5\n"),
    ("1.5 * 2", "3\n"),
    ("2.5 * 2", "5\n"),
    ("5 / 2.0", "2.5\n"),
    ("2.0 / 5", "0.4\n"),
    ("2.5 % 7", "2.5\n"),
    ('"a"+"b"', '"ab"\n'),
    ("4 - -3", "7\n"),
    ("1.5 - 0.5", "1\n"),
    ("1.5 - 1", "0.5\n"),
    ("1.5 * 2.5", "3.75\n"),
    ("2 * 1.5", "3\n"),
    ("5.0 / 2.0", "2.5\n"),
    ("7.5 % 2.0", "1.5\n"),
]


@pytest.mark.parametrize("selector,expected", ARITHMETIC)
def test_arithmetic(run_dasel, selector, expected):
    """Arithmetic follows Go's int/float rules, not JavaScript's."""
    # CATCHES: int/int division truncates to an int, int/float promotes to
    # float, float modulo uses math.Mod, and 0.1+0.2 keeps full IEEE754 error.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,types",
    [
        ('1+"a"', "int and string"),
        ("null + 1", "null and int"),
        ("[1] + [2]", "array and array"),
    ],
)
def test_arithmetic_incompatible_types(run_dasel, selector, types):
    """Adding mismatched types fails with the incompatible-types message."""
    # CATCHES: there is no implicit string coercion and no array concat; the
    # error names both operand types and the process exits 1.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: could not add: incompatible types: "
        + types
        + "\n"
    )


@pytest.mark.parametrize(
    "selector,operation",
    [
        ('1 - "a"', "could not subtract"),
        ('1 * "a"', "could not multiply"),
        ('1 / "a"', "could not divide"),
        ('1 % "a"', "could not modulo"),
    ],
)
def test_arithmetic_errors_name_the_operation(run_dasel, selector,
                                              operation):
    """Every arithmetic operator prefixes its own name to the type error."""
    # CATCHES: subtract/multiply/divide/modulo each wrap the incompatible-
    # types error with "could not <operation>", unlike == and < which pass
    # the bare "incompatible types" through.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: " + operation + ": incompatible types: "
        "int and string\n"
    )


def test_operator_precedence_and_grouping(run_dasel):
    """Multiplication binds tighter than addition; parentheses override."""
    # CATCHES: 1 + 2 * 3 is 7 and (1 + 2) * 3 is 9, so a flat left-to-right
    # evaluator gets the first one wrong.
    for selector, expected in [
        ("1 + 2 * 3", "7\n"),
        ("(1 + 2) * 3", "9\n"),
        ("45.2 + 5 * 4 - 2 / 2", "64.2\n"),
        ("(45.2 + 5) * ((4 - 2) / 2)", "50.2\n"),
    ]:
        proc = run_dasel(selector, "null")
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == expected


COMPARISONS = [
    ("1 == 1", "true\n"),
    ("1 == 2", "false\n"),
    ("1 != 2", "true\n"),
    ("1 < 2", "true\n"),
    ('"b" < "a"', "false\n"),
    ("2 <= 2", "true\n"),
    ("3 > 2", "true\n"),
    ("3 >= 4", "false\n"),
    ('"a" < "b"', "true\n"),
    ("1 == 1.0", "true\n"),
    ("1.0 == 1", "true\n"),
    ("1 == 1.5", "false\n"),
    ("1.5 > 1", "true\n"),
    ("2.5 > 2", "true\n"),
    ("2 > 1.5", "true\n"),
    ("1 < 2.5", "true\n"),
    ("2.5 < 3", "true\n"),
    ("1 < 1.0", "false\n"),
    ("1.0 < 1", "false\n"),
    ("1.5 <= 1", "false\n"),
    ("2 >= 1.5", "true\n"),
    ("null == null", "true\n"),
    ("true == true", "true\n"),
    ("[1,2] == [1,2]", "true\n"),
    ("[1,2] == [1,3]", "false\n"),
    ('{"a":1} == {"a":1}', "true\n"),
    ('{"a":1} == {"a":2}', "false\n"),
    ('"a" >= "a"', "true\n"),
    ('"a" <= "b"', "true\n"),
    ('"b" > "a"', "true\n"),
    ('"a" > "b"', "false\n"),
]


@pytest.mark.parametrize("selector,expected", COMPARISONS)
def test_comparisons(run_dasel, selector, expected):
    """Equality is deep for arrays and maps; int/float compare by value."""
    # CATCHES: 1 == 1.0 is true even though the types differ, and map equality
    # compares key-by-key rather than by reference.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,message",
    [
        ('1 == "1"', "incompatible types: int and string"),
        ('1 < "a"', "incompatible types: int and string"),
        ('{"a":1} < {"a":2}', "incompatible types: map and map"),
        ('1 > "a"', "incompatible types: int and string"),
        ('1 != "1"', "incompatible types: int and string"),
        ("null < null", "incompatible types: null and null"),
        ("true < false", "incompatible types: bool and bool"),
        ("[1] < [2]", "incompatible types: array and array"),
    ],
)
def test_cross_type_comparison_errors(run_dasel, selector, message):
    """Comparing unrelated types is an error, not a coercion."""
    # CATCHES: numbers are never stringified for comparison and maps have no
    # ordering, so each of these fails with exit code 1.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: " + message + "\n"
    )


def test_logical_operators(run_dasel):
    """&& and || operate on booleans with && binding tighter than ||."""
    # CATCHES: false || true && false is false, and neither operator short
    # circuits (both sides are always evaluated), which the error test below
    # demonstrates separately.
    for selector, expected in [
        ("true && false", "false\n"),
        ("true || false", "true\n"),
        ("2 < 3 && 3 < 4", "true\n"),
        ("false || true && false", "false\n"),
    ]:
        proc = run_dasel(selector, "null")
        assert proc.returncode == 0, proc.stderr
        assert proc.stdout == expected


def test_logical_operators_do_not_short_circuit(run_dasel):
    """A non-boolean on the right of && is an error even when left is true."""
    # CATCHES: the right operand is always evaluated and converted, so
    # 'true && 5' fails instead of yielding true.
    proc = run_dasel("true && 5", "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: error getting right bool value: "
        "unexpected type: expected bool, got int\n"
    )


@pytest.mark.parametrize(
    "selector,side",
    [
        ("1 && true", "left"),
        ("1 || true", "left"),
        ("true || 1", "right"),
    ],
)
def test_logical_operator_type_errors(run_dasel, selector, side):
    """&& and || require booleans on both sides, naming the offending side."""
    # CATCHES: a non-boolean on either side of either operator is an error
    # ("error getting left/right bool value") - there is no truthiness
    # coercion and no special case for || once the left side is valid.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: error getting " + side + " bool value: "
        "unexpected type: expected bool, got int\n"
    )


def test_unary_not(run_dasel):
    """! negates a boolean; parentheses make the operand a full expression."""
    # CATCHES: !(1==1) must parse the parenthesised comparison first, giving
    # false, and a non-boolean operand is rejected.
    proc = run_dasel("!(1==1)", "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "false\n"
    proc = run_dasel("!true", "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "false\n"


def test_unary_not_requires_a_boolean(run_dasel):
    """Applying ! to an integer is an execution error."""
    # CATCHES: there is no truthiness coercion, so !1 must fail with the
    # expected-type message rather than evaluating to false.
    proc = run_dasel("!1", "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.UnaryExpr: error converting value to boolean: "
        "unexpected type: expected bool, got int\n"
    )


REGEX = [
    ('"hello" =~ r/^h/', "true\n"),
    ('"hello" =~ r/^x/', "false\n"),
    ('"hello" !~ r/^x/', "true\n"),
    ('"hello" !~ r/^h/', "false\n"),
]


@pytest.mark.parametrize("selector,expected", REGEX)
def test_regex_matching(run_dasel, selector, expected):
    """=~ and !~ match the left string against the right regex."""
    # CATCHES: the pattern is written r/.../ and compiled with Go's regexp, so
    # ^h anchors at the start and !~ is the exact negation.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector,message",
    [
        ("1 =~ r/^h/", "like requires left side to be a string, got int"),
        ('"hello" =~ "x"', "like requires right side to be a regex pattern"),
    ],
)
def test_regex_operand_type_errors(run_dasel, selector, message):
    """=~ rejects a non-string left side and a non-regex right side."""
    # CATCHES: the right operand must be a regex literal token, not merely a
    # string value, and the left must already be a string.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: " + message + "\n"
    )


@pytest.mark.parametrize(
    "selector,message",
    [
        ("1 !~ r/^h/", "like requires left side to be a string, got int"),
        ('"hello" !~ "x"', "like requires right side to be a regex pattern"),
    ],
)
def test_not_like_operand_type_errors(run_dasel, selector, message):
    """!~ enforces the same operand rules as =~ and reuses its message."""
    # CATCHES: the negated match reports "like requires ..." (not "not
    # like requires ..."), so a re-implementation with a separate error
    # string for !~ differs, as does one that treats a plain string right
    # side as a pattern.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: " + message + "\n"
    )


COALESCE = [
    ("null ?? 5", "5\n"),
    ("1 ?? 5", "1\n"),
    ('"x" ?? 5', '"x"\n'),
    ("null ?? 1 ?? 2", "1\n"),
]


@pytest.mark.parametrize("selector,expected", COALESCE)
def test_null_coalescing(run_dasel, selector, expected):
    """?? returns the left value unless it is null."""
    # CATCHES: only null triggers the right side - false, 0 and "" are all
    # kept, and the operator chains left-associatively.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_null_coalescing_swallows_left_side_errors(run_dasel):
    """Errors from the left of ?? fall through to the right operand."""
    # CATCHES: a missing key, a bad navigation and even a failing inner
    # construct are all suppressed, so 'map(1) ?? 5' prints 5 rather than
    # reporting 'cannot map over non-array'.
    proc = run_dasel("map(1) ?? 5", '{"a": 1}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "5\n"
    proc = run_dasel("a.b.c ?? 7", '{"a": 1}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "7\n"
    proc = run_dasel("$nope ?? 5", '{"a": 1}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "5\n"


def test_standalone_regex_is_a_noop(run_dasel):
    """A bare regex pattern evaluates to the current value unchanged."""
    # CATCHES: the regex AST node only carries a pattern for use by =~; on its
    # own it echoes the input document through.
    proc = run_dasel("r/foo/", '{"a": 1}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 1\n}\n'
