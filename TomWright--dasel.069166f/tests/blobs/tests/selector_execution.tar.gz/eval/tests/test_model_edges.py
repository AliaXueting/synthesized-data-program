"""Round-4 edge cases of the value model behind selector execution.

The tests here pin behaviours of the model package that earlier rounds only
touched in passing: how groupBy stringifies keys (and collides int/float/
string/bool keys that format to the same text), that the collections built by
groupBy/search/mapValues reuse the source elements while mapValues still gets
a key set of its own, how assignment behaves on nested constructed containers
and on non-array targets, that HCL repeated blocks stay independent one level
deep (blocks and lists), the int64 wrap-around and divide-by-zero behaviour of
arithmetic, and the empty-string / null corners of map keys.
"""

import pytest


# --- groupBy key stringification and collisions ------------------------------


@pytest.mark.parametrize(
    "input_text,expected",
    [
        (
            '[1, 1.0, "1", true, 2]',
            '{\n    "1": [\n        1,\n        1,\n        "1"\n    ],\n'
            '    "true": [\n        true\n    ],\n    "2": [\n        2\n'
            "    ]\n}\n",
        ),
        (
            '[2, 1.0, 1, "1"]',
            '{\n    "2": [\n        2\n    ],\n    "1": [\n        1,\n'
            '        1,\n        "1"\n    ]\n}\n',
        ),
        (
            '[true, "true"]',
            '{\n    "true": [\n        true,\n        "true"\n    ]\n}\n',
        ),
        (
            "[1.5, 1.50]",
            '{\n    "1.5": [\n        1.5,\n        1.5\n    ]\n}\n',
        ),
    ],
)
def test_group_by_keys_collide_across_value_kinds(run_dasel, input_text,
                                                  expected):
    """groupBy converts keys to text, so equal-looking values share a group."""
    # CATCHES: the group key is the stringified value (%d/%g/%v), so int 1,
    # float 1.0 and string "1" all land in the same group keyed "1", and the
    # key order follows first sighting ("2" before "1" in the second case);
    # grouping by typed value or sorting the keys would produce different
    # groups or a different order.
    proc = run_dasel("groupBy($this)", input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "input_text,expected",
    [
        ("[0.000001]", '{\n    "1e-06": [\n        0.000001\n    ]\n}\n'),
        ("[100000000.0]", '{\n    "1e+08": [\n        100000000\n    ]\n}\n'),
    ],
)
def test_group_by_float_keys_use_go_formatting(run_dasel, input_text,
                                               expected):
    """Float group keys are %g text, which differs from the JSON value."""
    # CATCHES: the key comes from fmt %g ("1e-06", "1e+08") while the value
    # itself is written by the JSON writer ("0.000001", "100000000"); using
    # the JSON rendering for the key (or %v) would name the group
    # "0.000001"/"100000000" instead.
    proc = run_dasel("groupBy($this)", input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


# --- derived collections and what they share ---------------------------------


def test_group_by_groups_share_their_elements(run_dasel):
    """Writing through a groupBy group mutates the source document."""
    # CATCHES: each group is a fresh array whose elements are the very values
    # from the input slice, so $x.x[0].b = 9 reaches $root; a copy would
    # print "x" again and leave the document untouched.
    proc = run_dasel('$x = groupBy(b); $x.x[0].b = 9; $root',
                     '[{"b": "x"}, {"b": "y"}]', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '[\n    {\n        "b": 9\n    },\n    {\n        "b": "y"\n'
        "    }\n]\n"
    )
    assert proc.stderr == ""


def test_search_results_share_their_elements(run_dasel):
    """Writing through a search result mutates the source document."""
    # CATCHES: search collects the matching values themselves (not copies)
    # into its result array, so $x[0].b = 9 is visible in $root.
    proc = run_dasel('$x = search(b == 1); $x[0].b = 9; $root',
                     '[{"b": 1}, {"b": 2}]', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '[\n    {\n        "b": 9\n    },\n    {\n        "b": 2\n'
        "    }\n]\n"
    )
    assert proc.stderr == ""


def test_map_values_result_shares_nested_values(run_dasel):
    """mapValues builds a new map whose values are the originals."""
    # CATCHES: the mapValues result has its own key set but stores the
    # transformed values by reference, so writing through the nested map
    # ($x.a.b = 9) reaches the document while replacing a whole value
    # ($x.a = 9) only rewrites the fresh key set - see the next test.
    proc = run_dasel('$x = mapValues($this); $x.a.b = 9; $root',
                     '{"a": {"b": 1}, "c": 2}', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '{\n    "a": {\n        "b": 9\n    },\n    "c": 2\n}\n'
    )
    assert proc.stderr == ""


def test_map_values_result_has_its_own_key_set(run_dasel):
    """Replacing a value in a mapValues result leaves the document alone."""
    # CATCHES: assigning $x.a = 9 goes through the set function of the fresh
    # map built by mapValues, so the document keeps {"b": 1} under a, while
    # reading $x shows the overwritten key in its original position.
    untouched = run_dasel('$x = mapValues($this); $x.a = 9; $root',
                          '{"a": {"b": 1}, "c": 2}', flags=("--root",))
    assert untouched.returncode == 0, untouched.stderr
    assert untouched.stdout == (
        '{\n    "a": {\n        "b": 1\n    },\n    "c": 2\n}\n'
    )
    overwritten = run_dasel('$x = mapValues($this); $x.a = 9; $x',
                            '{"a": {"b": 1}, "c": 2}')
    assert overwritten.returncode == 0, overwritten.stderr
    assert overwritten.stdout == '{\n    "a": 9,\n    "c": 2\n}\n'
    assert overwritten.stderr == ""


# --- assignment into constructed containers ----------------------------------


@pytest.mark.parametrize(
    "selector,expected",
    [
        ('$x = [{"a": 1}]; $x[0].a = 9; $x',
         '[\n    {\n        "a": 9\n    }\n]\n'),
        ('$x = [1, 2]; $x[0] = [3, 4]; $x',
         '[\n    [\n        3,\n        4\n    ],\n    2\n]\n'),
        ('$x = [[1]]; $x[0][0] = 9; $x',
         '[\n    [\n        9\n    ]\n]\n'),
    ],
)
def test_assignment_into_constructed_containers(run_dasel, selector,
                                                expected):
    """Elements of array literals stay writable at any nesting depth."""
    # CATCHES: array literals wrap every element so it keeps its setter, so
    # the element can be replaced (by a scalar, an array, or through a
    # nested property/index chain) and the surrounding literal reflects it;
    # storing plain values would print 1 / [1, 2] / [[1]] instead.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_index_assignment_on_a_string_errors(run_dasel):
    """Assigning through [0] on a string input fails like reading it."""
    # CATCHES: index assignment evaluates the left side as a plain index
    # expression first, so a string target fails with the model's
    # expected-array type error (wrapped in the assignment error chain)
    # rather than mutating or coercing the string.
    proc = run_dasel('$this[0] = 1', '"abc"')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: error evaluating left expression: "
        "execution error when processing ast.ChainedExpr: error executing "
        "expression: execution error when processing ast.PropertyExpr: "
        "unexpected type: expected array, got string\n"
    )


def test_assigning_a_branch_fans_out_the_next_expression(run_dasel):
    """A branch on the right of an assignment makes the chain branch."""
    # CATCHES: assignment returns the right-hand value, so after
    # $x[0] = branch(3, 4) the following $x runs once per branch element and
    # prints two identical documents, while the element itself holds the
    # branch's underlying array [3, 4]; an implementation that returned the
    # left side (or dropped the branch metadata) would print one document.
    proc = run_dasel('$x = [1, 2]; $x[0] = branch(3, 4); $x', "null",
                     flags=("--unstable",))
    assert proc.returncode == 0, proc.stderr
    one_doc = '[\n    [\n        3,\n        4\n    ],\n    2\n]\n'
    assert proc.stdout == one_doc + "\n" + one_doc
    assert proc.stderr == ""


# --- HCL repeated blocks: independence one level deep ------------------------


@pytest.mark.parametrize(
    "hcl,selector,expected",
    [
        (
            'block "a" {\n  inner {\n    x = 1\n  }\n}\n'
            'block "a" {\n  inner {\n    x = 2\n  }\n}\n',
            "block.a[0].inner.x = 99",
            '{\n    "block": {\n        "a": [\n            {\n'
            '                "inner": {\n                    "x": 99\n'
            '                }\n            },\n            {\n'
            '                "inner": {\n                    "x": 2\n'
            '                }\n            }\n        ]\n    }\n}\n',
        ),
        (
            'block "a" {\n  list = [1, 2]\n}\nblock "a" {\n  list = [3, 4]\n}\n',
            "block.a[0].list[0] = 99",
            '{\n    "block": {\n        "a": [\n            {\n'
            '                "list": [\n                    99,\n'
            '                    2\n                ]\n            },\n'
            '            {\n                "list": [\n                    3,'
            '\n                    4\n                ]\n            }\n'
            "        ]\n    }\n}\n",
        ),
        (
            'block "a" {\n  x = 1\n}\nblock "a" {\n  x = 2\n}\n'
            'block "a" {\n  x = 3\n}\n',
            "block.a[1].x = 99",
            '{\n    "block": {\n        "a": [\n            {\n'
            '                "x": 1\n            },\n            {\n'
            '                "x": 99\n            },\n            {\n'
            '                "x": 3\n            }\n        ]\n    }\n}\n',
        ),
    ],
)
def test_hcl_repeated_blocks_stay_independent_per_element(run_dasel, hcl,
                                                          selector, expected):
    """Nested blocks and lists of repeated HCL blocks mutate independently."""
    # CATCHES: the second occurrence of a block copies the first before both
    # go into an array, and every later block is appended as its own value,
    # so writing block.a[0].inner.x, block.a[0].list[0] or block.a[1].x
    # changes only that element; a shared nested structure would show 99 in
    # the sibling element too. HCL input is used only to build this shape -
    # the behaviour under test is the copy.
    proc = run_dasel(selector, hcl, flags=("--root",), in_format="hcl")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


# --- integer arithmetic edges -------------------------------------------------


@pytest.mark.parametrize(
    "selector,input_text,expected",
    [
        ("9223372036854775807 + 1", "null", "-9223372036854775808\n"),
        ("$this - 1", "-9223372036854775808", "9223372036854775807\n"),
        ("1000000000 * 1000000000", "null", "1000000000000000000\n"),
    ],
)
def test_int64_arithmetic_wraps_without_float_promotion(run_dasel, selector,
                                                        input_text, expected):
    """Int arithmetic is int64 arithmetic: it wraps instead of overflowing."""
    # CATCHES: +, - and * on two ints run in int64 with no overflow check and
    # no promotion to float, so max+1 wraps to min and 1e9*1e9 stays the
    # exact integer 1000000000000000000; a checked or float result would
    # print an error or 1e+18.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


@pytest.mark.parametrize("selector", ["1 / 0", "1 % 0"])
def test_integer_division_by_zero_panics(run_dasel, selector):
    """Int / and % with a zero divisor crash the process, not an error."""
    # CATCHES: the model's Divide/Modulo have no zero-divisor guard, so the
    # Go runtime panics - exit code 2 and a stderr starting with the runtime
    # panic line; a re-implementation that returns a clean dasel error (exit
    # code 1) or a value would differ. Only the first stderr line is
    # asserted: the goroutine dump that follows carries addresses.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr.splitlines()[0] == (
        "panic: runtime error: integer divide by zero"
    )


@pytest.mark.parametrize(
    "selector,symbol",
    [
        ("1.0 / 0", "+Inf"),
        ("5 / 0.0", "+Inf"),
        ("(0.0 - 1.0) / 0.0", "-Inf"),
        ("0.0 / 0.0", "NaN"),
        ("1.0 % 0", "NaN"),
        ("5 % 0.0", "NaN"),
    ],
)
def test_float_division_by_zero_produces_special_values(run_dasel, selector,
                                                        symbol):
    """Float / and % by zero yield Inf/NaN, which the JSON writer rejects."""
    # CATCHES: float division and modulo follow IEEE-754 (Inf/NaN instead of
    # an error) and only the output stage fails, with the Go json package's
    # "unsupported value" text naming the special value; erroring at
    # evaluation time, or printing Infinity/NaN as JSON, would differ.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error writing output: json: unsupported value: "
        + symbol + "\n"
    )


# --- key and input corners ----------------------------------------------------


@pytest.mark.parametrize(
    "selector,input_text,expected",
    [
        ('$this[""]', '{"": 7, "a": 1}', "7\n"),
        ("len($this)", '{"z": 1, "": 2}', "2\n"),
    ],
)
def test_empty_string_keys_are_ordinary_keys(run_dasel, selector,
                                             input_text, expected):
    """The empty string is a readable, countable map key."""
    # CATCHES: the empty string is a valid map key (readable with [""] and
    # counted by len), not skipped or rejected by the ordered map; an
    # implementation that treats empty keys as absent would error or
    # undercount.
    proc = run_dasel(selector, input_text)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_negative_float_literal(run_dasel):
    """A leading dash is part of a float literal, not a unary operator."""
    # CATCHES: the parser folds '-1.5' into a negative float literal (after
    # the -- flag separator), so it prints -1.5; treating the dash as
    # subtraction from nothing, or rejecting it, prints something else.
    proc = run_dasel("-1.5", "null", flags=("--",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "-1.5\n"
    assert proc.stderr == ""


def test_empty_string_key_miss(run_dasel):
    """Reading the empty key from a map without it is a missing-key error."""
    # CATCHES: the map key not found error quotes the key, so the empty key
    # produces the distinctive trailing '""' in the message rather than an
    # empty or unnamed error.
    proc = run_dasel('$this[""]', "{}")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.PropertyExpr: map key not found: \"\"\n"
    )


def test_null_document_round_trips(run_dasel):
    """A null document is a value: it prints back as null."""
    # CATCHES: null input parses into the model's null value (not an error
    # or absent document) and the writer renders it as the JSON text null;
    # an empty output or an error would break null round-tripping.
    proc = run_dasel("$this", "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "null\n"
    assert proc.stderr == ""


def test_property_access_on_a_null_document_errors(run_dasel):
    """Property access on null fails with the model's expected-map error."""
    # CATCHES: null is not a map, so navigation raises the typed error
    # "unexpected type: expected map, got null" (exit code 1) instead of
    # returning null or an empty result like a lenient implementation.
    proc = run_dasel("$this.foo", "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.PropertyExpr: unexpected type: expected "
        "map, got null\n"
    )
