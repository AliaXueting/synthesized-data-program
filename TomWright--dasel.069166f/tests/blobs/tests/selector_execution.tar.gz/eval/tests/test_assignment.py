"""Assignment semantics: ``=``, in-place mutation and the --root flag.

Covers what an assignment expression evaluates to (the right-hand value),
how it mutates the parsed input document in place so --root prints the
modified document, nested-path and index assignment, assigning to
variables and to $this itself, and the error when the target property
does not already exist.
"""


def test_assignment_returns_the_assigned_value(run_dasel):
    """``a = 5`` evaluates to the right-hand side, not the document."""
    # CATCHES: executeAssign returns the right value, so stdout is the bare 5
    # and not the whole modified map; a re-implementation that returns the
    # document (or the previous value) differs here.
    proc = run_dasel('a = 5', '{"a": 1, "b": 2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "5\n"
    assert proc.stderr == ""


def test_root_flag_prints_the_mutated_document(run_dasel):
    """--root prints the whole input document after in-place mutation."""
    # CATCHES: assignment mutates the parsed document in place; without --root
    # only the assigned value is printed, with it the updated document is.
    proc = run_dasel('a = 5', '{"a": 1, "b": 2}', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 5,\n    "b": 2\n}\n'


def test_nested_assignment_mutates_in_place(run_dasel):
    """``a.b = 5`` reaches two levels down and --root shows the change."""
    # CATCHES: the left side is a full chain, so the write lands on the nested
    # map while the rest of the document is left untouched.
    proc = run_dasel('a.b = 5', '{"a": {"b": 1}}', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": {\n        "b": 5\n    }\n}\n'


def test_assignment_replaces_the_value_type(run_dasel):
    """Assigning a string over an int changes the stored type."""
    # CATCHES: Set replaces the underlying value wholesale, so the key goes
    # from holding the number 1 to holding the string "str".
    proc = run_dasel('a = "str"', '{"a": 1}', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": "str"\n}\n'


def test_index_assignment_mutates_the_element(run_dasel):
    """``$this[0] = 9`` replaces the first element of the root array."""
    # CATCHES: the left side may be an index expression, and the write happens
    # inside the original slice rather than in a copy of it.
    proc = run_dasel('$this[0] = 9', '[1, 2]', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '[\n    9,\n    2\n]\n'


def test_assigning_to_this_rewrites_the_root_value(run_dasel):
    """``$this = 5`` replaces the entire document; even --root prints 5."""
    # CATCHES: the root value itself is overwritten in place, so the --root
    # output is the new scalar 5, not the original object.
    proc = run_dasel('$this = 5', '{"a": 1}', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "5\n"


def test_assigning_to_a_missing_key_fails(run_dasel):
    """Assignment cannot create keys; the left side must already exist."""
    # CATCHES: evaluation of the left side happens first and fails with the
    # ordinary property error, wrapped as 'error evaluating left expression'.
    proc = run_dasel('b = 5', '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: error evaluating left expression: "
        "execution error when processing ast.PropertyExpr: map key not "
        'found: "b"\n'
    )


def test_variable_assignment_binds_for_later_use(run_dasel):
    """``$x = 5`` creates a variable usable later in the same selector."""
    # CATCHES: an unknown variable on the left of = is pre-created as null and
    # then set, so a chained $x reads back the assigned value.
    proc = run_dasel('$x = 5; $x', '{}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "5\n"


def test_chain_after_assignment_continues_from_the_value(run_dasel):
    """The expression after an assignment sees the assigned value."""
    # CATCHES: a chained selector feeds 5 (the assignment result) into the
    # following property access, which then fails because 5 is not a map.
    proc = run_dasel('a = 5; a', '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.PropertyExpr: unexpected type: expected "
        "map, got int\n"
    )


def test_compound_update_via_self_reference(run_dasel):
    """There is no ``+=``; a compound update is written ``a = a + 5``."""
    # CATCHES: both sides are evaluated against the document before the write,
    # so the new value is computed from the old one and stored back.
    proc = run_dasel('a = a + 5', '{"a": 1}', flags=("--root",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 6\n}\n'


def test_plus_equals_is_a_parse_error(run_dasel):
    """The lexer has no compound-assignment tokens, so ``a += 5`` fails."""
    # CATCHES: re-implementations that add JavaScript-style compound operators
    # would succeed here; the reference rejects the token outright at parse
    # time with the token's numeric kind in the message.
    proc = run_dasel('a += 5', '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error parsing selector: failed to parse: unexpected "
        'token 22 "+=" at position 2.\n'
    )
