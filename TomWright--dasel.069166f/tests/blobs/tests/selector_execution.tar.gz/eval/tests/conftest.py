"""Shared helpers for the selector_execution test module.

The program under test is dasel.  These tests pin the run-time semantics of a
parsed selector: navigation, literals and construction, variables, operators,
assignment, the higher-order constructs (map/filter/sortBy/...) and the
branch/spread multi-document results, plus the exact error text and exit codes
produced when a selector cannot be evaluated.
"""

import os
import subprocess

import pytest

# Pinned child environment: no network, no locale or color surprises, and a
# HOME that can never contain a ~/dasel.yaml config file.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "dumb",
}


def _dasel_bin():
    """Resolve the reference binary through PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the dasel binary under test"
        )
    return path


def _child_env(extra=None):
    """The pinned child environment plus coverage forwarding and overrides."""
    env = dict(CHILD_ENV)
    # The pipeline measures source coverage of the reference binary through
    # GOCOVERDIR; forward it when the test process itself was started with it
    # so an instrumented binary can write its covermeta files.  Read at call
    # time so a per-test override is honored too.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    if extra:
        env.update(extra)
    return env


def run_dasel(selector, input_text=None, flags=(), env=None, cwd=None,
              timeout=10, in_format="json"):
    """Run dasel with a JSON in/out query and return the completed process.

    ``flags`` holds extra CLI flags (e.g. ``("--root",)``) that are placed
    before the selector, and ``env`` adds or overrides variables in the pinned
    child environment - used for the OS-environment-variable fallback tests.
    ``in_format`` selects the reader for stdin (json unless a test needs
    another one to build a particular value shape).
    """
    argv = [_dasel_bin(), "-i", in_format, "-o", "json", *flags, selector]
    return subprocess.run(
        argv,
        input=input_text,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=_child_env(env),
        cwd=cwd,
        timeout=timeout,
    )


@pytest.fixture(name="run_dasel")
def run_dasel_fixture():
    """The run_dasel helper, bound to this module for convenience."""
    return run_dasel
