"""Branch values, the --unstable gate and multi-document I/O.

Covers the branch() expression and the error it raises without --unstable,
how branch (and spread, and multi-document stdin) values print as several
newline-separated documents, how later expressions fan out over each branch
element, how ignore() drops documents, and the compact output flag.
"""

import pytest

UNSTABLE = ("--unstable",)


def test_branch_requires_the_unstable_flag(run_dasel):
    """branch() without --unstable fails before execution begins."""
    # CATCHES: the gate fires when the executor is built for the BranchExpr
    # AST node, so the error is 'error evaluating expression' rather than an
    # execution error, and the exact remedial message must be reproduced.
    proc = run_dasel("branch(a, b)", '{"a": 1, "b": 2}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: error evaluating "
        "expression ast.BranchExpr: unstable ast types are not enabled. to "
        "enable them use --unstable\n"
    )


def test_branch_prints_one_document_per_value(run_dasel):
    """branch(1, 2, 3) prints three documents separated by a blank line."""
    # CATCHES: each branch element is written by its own writer call that
    # ends with a newline, and the separator adds another, so documents are
    # separated by exactly one empty line.
    proc = run_dasel("branch(1, 2, 3)", "null", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n\n2\n\n3\n"
    assert proc.stderr == ""


def test_branch_of_properties(run_dasel):
    """branch(a, b) evaluates each sub-expression against the document."""
    # CATCHES: every branch arm sees the same input document, so the outputs
    # are the two property values 1 and 2 in the order the arms were written.
    proc = run_dasel("branch(a, b)", '{"a": 1, "b": 2}', flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n\n2\n"


def test_branch_with_no_expressions_branches_the_input(run_dasel):
    """branch() with empty parens branches on the input array elements."""
    # CATCHES: an empty expression list is valid and turns each element of
    # the input slice into its own document.
    proc = run_dasel("branch()", "[1, 2, 3]", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n\n2\n\n3\n"


def test_branch_of_one_array_stays_one_document(run_dasel):
    """branch([1, 2]) has a single result, so it prints as one array."""
    # CATCHES: branch does not flatten its expression results (only explicit
    # spread does), so a lone array argument stays an array.
    proc = run_dasel("branch([1, 2])", "null", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2\n]\n"


def test_branch_spread_flattens(run_dasel):
    """branch(a...) spreads the array so each element is its own document."""
    # CATCHES: the spread marker on a branch argument explodes the array into
    # individual branch elements before they are appended.
    proc = run_dasel("branch(a...)", '{"a": [1, 2]}', flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n\n2\n"


def test_navigation_fans_out_over_branch_elements(run_dasel):
    """A property after branch() is applied to each branch element."""
    # CATCHES: ExecuteAST re-runs the following expression once per branch
    # element and collects the results back into a branch, which is what
    # 'access on each element of a branch' means.
    proc = run_dasel('branch({"a": 1}, {"a": 2}).a', "null", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n\n2\n"


@pytest.mark.parametrize(
    "selector,expected",
    [
        ("branch(1, 2) + 10", "11\n\n12\n"),
        ("branch(1, 2) == 1", "true\n\nfalse\n"),
    ],
)
def test_binary_operators_fan_out_over_a_branch_left(run_dasel, selector,
                                                     expected):
    """A branch on the left of a binary operator maps the operator over it."""
    # CATCHES: the right operand is re-evaluated against each branch element,
    # so branch(1,2) == 1 yields one boolean per element.
    proc = run_dasel(selector, "null", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_branch_on_the_right_is_a_plain_array(run_dasel):
    """Only the left operand fans out; a right-hand branch is just an array."""
    # CATCHES: the fan-out check looks at the left value only, so 10 +
    # branch(1,2) tries to add an int to an array and fails.
    proc = run_dasel("10 + branch(1, 2)", "null", flags=UNSTABLE)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BinaryExpr: could not add: incompatible types: int "
        "and array\n"
    )


def test_branch_assignments_mutate_the_document(run_dasel):
    """Assignments inside a branch still mutate the shared document."""
    # CATCHES: each branch arm writes through to the same parsed document, so
    # --root shows both a and b updated even though the branch printed the
    # two assigned scalars.
    proc = run_dasel(
        "branch(a = 1, b = 2)", '{"a": 0, "b": 0}', flags=UNSTABLE + ("--root",)
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 1,\n    "b": 2\n}\n'


def test_ignore_drops_every_document(run_dasel):
    """ignore() under --unstable removes all input documents from the output."""
    # CATCHES: multi-document stdin is a branch, each element is marked
    # ignored, and ignored values drop out of branch results - leaving
    # completely empty output with exit code 0 while the same two documents
    # without ignore() both print, so the empty output is a real result.
    control = run_dasel("$this", "1 2", flags=UNSTABLE)
    assert control.returncode == 0, control.stderr
    assert control.stdout == "1\n\n2\n"
    proc = run_dasel("ignore()", "1 2", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == ""
    assert proc.stderr == ""


def test_conditional_ignore_keeps_the_other_documents(run_dasel):
    """A conditional ignore() drops one document of three and keeps two."""
    # CATCHES: only the document whose branch result is ignored disappears;
    # the others still produce their (null) result, so three documents in
    # gives exactly two documents out.
    proc = run_dasel("if ($this == 2) {ignore()}", "1 2 3", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "null\n\nnull\n"
    assert proc.stderr == ""


def test_ignore_keeps_a_single_document(run_dasel):
    """A lone document is not a branch, so ignore() leaves it printed."""
    # CATCHES: dropping only happens at branch boundaries; a single-document
    # input reaches the writer untouched and still prints.
    proc = run_dasel("ignore()", "1", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n"


def test_ignore_drops_only_the_matching_document(run_dasel):
    """A conditional ignore() removes one document and keeps the rest."""
    # CATCHES: the first document is dropped because its branch result is
    # ignored, while the second falls through the if to a null result that is
    # kept - so only null is printed.
    proc = run_dasel("if ($this == 1) {ignore()}", "1 2", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "null\n"


def test_ignore_inside_branch_args_is_not_dropped(run_dasel):
    """branch() itself does not drop ignored arguments."""
    # CATCHES: dropping happens only when executing over an existing branch
    # value, not when branch() collects its argument results, so the ignored
    # null survives as a document.
    proc = run_dasel("branch(1, ignore(), 2)", "null", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n\nnull\n\n2\n"


def test_multi_document_stdin_round_trips(run_dasel):
    """Two JSON documents on stdin come back out as two documents."""
    # CATCHES: the JSON reader marks multi-document input as a branch, and
    # the multi-document writer prints one document per element with a blank
    # line between them.
    proc = run_dasel("$this", '{"a": 1}{"b": 2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 1\n}\n\n{\n    "b": 2\n}\n'


def test_empty_selector_returns_the_input_unchanged(run_dasel):
    """An empty query short-circuits and prints the document as parsed."""
    # CATCHES: ExecuteSelector returns the input value for an empty string,
    # and the key order from the input is preserved on the way back out.
    proc = run_dasel("", '{"z": 1, "a": 2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "z": 1,\n    "a": 2\n}\n'


def test_selector_runs_on_each_input_document(run_dasel):
    """A property selector navigates into every input document."""
    # CATCHES: because the input branch is executed per element, a works on
    # both documents and the outputs are printed as two documents.
    proc = run_dasel("a", '{"a": 1}{"a": 2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n\n2\n"


def test_error_in_one_document_fails_the_whole_query(run_dasel):
    """A navigation error on any input document fails with rc 1."""
    # CATCHES: the per-element execution error is wrapped as 'branch
    # execution error when processing', a distinct wrapper from the
    # non-branch execution error path.
    proc = run_dasel("a", '{"a": 1}{"b": 2}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: branch execution error "
        'when processing ast.PropertyExpr: map key not found: "a"\n'
    )


def test_spread_prints_each_element_as_a_document(run_dasel):
    """A standalone $this... spread turns the array into documents."""
    # CATCHES: the spread marker makes the writer treat the slice as
    # multiple documents, exactly like a branch value.
    proc = run_dasel("$this...", "[1, 2]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n\n2\n"


def test_spread_on_a_scalar_errors(run_dasel):
    """Spreading a scalar with a... fails with 'cannot spread on type'."""
    # CATCHES: the chained property a resolves to the int 1 and the spread
    # executor then rejects it, naming the received type.
    proc = run_dasel("a...", '{"a": 1, "b": 2}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.SpreadExpr: cannot spread on type int\n"
    )


def test_compact_output(run_dasel):
    """--compact prints the value on one line with no spaces."""
    # CATCHES: compact mode changes only the whitespace - the value, its key
    # order and the trailing newline are unchanged.
    proc = run_dasel("$this", '{"a": [1, 2], "b": null}', flags=("--compact",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{"a":[1,2],"b":null}\n'


def test_compact_branch_output(run_dasel):
    """--compact keeps the blank-line document separator."""
    # CATCHES: each compact document still ends with a newline and the
    # separator still adds one, so the layout is identical to pretty mode
    # for scalar documents.
    proc = run_dasel(
        'branch({"a": 1}, {"b": 2})',
        "null",
        flags=UNSTABLE + ("--compact",),
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{"a":1}\n\n{"b":2}\n'


@pytest.mark.parametrize(
    "stdin,got_type",
    [
        ('{"a": 1}', "map"),
        ("5", "int"),
    ],
)
def test_branch_of_a_non_slice_errors(run_dasel, stdin, got_type):
    """branch() with no arguments requires the input itself to be an array."""
    # CATCHES: the no-argument form ranges over the input, so a map or scalar
    # fails with "failed to range slice" naming the received type, rather
    # than branching the single value or returning an empty branch.
    proc = run_dasel("branch()", stdin, flags=UNSTABLE)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BranchExpr: failed to range slice: error getting "
        "slice length: unexpected type: expected array, got " + got_type +
        "\n"
    )


def test_branch_argument_error_is_wrapped(run_dasel):
    """A failing expression inside branch() fails the whole branch."""
    # CATCHES: branch() wraps each argument's failure as "failed to execute
    # branch expr" instead of skipping the failed element, so the query
    # cannot succeed with fewer documents.
    proc = run_dasel("branch(missing)", '{"a": 1}', flags=UNSTABLE)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.BranchExpr: failed to execute branch expr: execution "
        "error when processing ast.PropertyExpr: map key not found: "
        '"missing"\n'
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        ("[branch(1, 2), 3]", "[\n    1,\n    2,\n    3\n]\n"),
        ("[1, branch(2, 3), 4]", "[\n    1,\n    2,\n    3,\n    4\n]\n"),
        ('{"a": branch(1, 2)}',
         '{\n    "a": [\n        1,\n        2\n    ]\n}\n'),
    ],
)
def test_branch_values_flatten_inside_literals(run_dasel, selector, expected):
    """Appending a branch into a literal flattens it; as a value it stays."""
    # CATCHES: appending a branch value to a building array fans its elements
    # out in place (at any position), while storing one under an object key
    # keeps it as a plain nested array - the fan-out only happens on append.
    proc = run_dasel(selector, "null", flags=UNSTABLE)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
