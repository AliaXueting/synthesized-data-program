"""Literals and construction: scalars, arrays, objects, spread and ranges.

Covers how each literal kind prints, ordered-map key preservation in object
literals, the shorthand property form, spreading another value into an object
or array literal, and the inclusive end behaviour of range expressions on both
arrays and strings.
"""

import pytest


@pytest.mark.parametrize(
    "selector,expected",
    [
        ('"hi"', '"hi"\n'),
        ("1", "1\n"),
        ("1.5", "1.5\n"),
        ("1.0", "1\n"),
        ("3f", "3\n"),
        ("true", "true\n"),
        ("false", "false\n"),
        ("null", "null\n"),
    ],
)
def test_scalar_literals(run_dasel, selector, expected):
    """Each scalar literal evaluates to itself and prints as bare JSON."""
    # CATCHES: whole-number floats lose their ".0" on output and the 'f'
    # suffix is a float marker, not part of the value; both are easy to get
    # wrong when re-implementing the number literal executor.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_negative_number_literal(run_dasel):
    """A leading dash is part of the number literal, not a unary operator."""
    # CATCHES: the parser folds '-3' into a negative int literal; a
    # re-implementation that treats the dash as subtraction from nothing, or
    # that rejects it, prints something other than -3.
    proc = run_dasel("-3", "null", flags=("--",))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "-3\n"


def test_array_literal(run_dasel):
    """An array literal prints as a pretty-printed four-space JSON array."""
    # CATCHES: output indentation is exactly four spaces per level with no
    # trailing spaces, and the writer always ends with a newline.
    proc = run_dasel("[1,2,3]", "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2,\n    3\n]\n"


def test_object_literal_preserves_written_key_order(run_dasel):
    """Object literal keys are emitted in the order they were written."""
    # CATCHES: the value model keeps insertion order, so a re-implementation
    # backed by an unordered Go map (or one that sorts keys) reorders output.
    proc = run_dasel('{"b":1,"a":2,"c":3}', "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "b": 1,\n    "a": 2,\n    "c": 3\n}\n'


def test_document_map_order_round_trips(run_dasel):
    """Reading a document keeps the input map order on output."""
    # CATCHES: the ordered map is used end to end, so a re-implementation that
    # loses order while parsing would alphabetise z/a/m on the way back out.
    proc = run_dasel("$this", '{"z":1,"a":2,"m":3}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "z": 1,\n    "a": 2,\n    "m": 3\n}\n'


def test_object_shorthand(run_dasel):
    """{a} copies the property named a from the current value."""
    # CATCHES: the shorthand form resolves the property against the input, so
    # an implementation that treats the bare word as a string key would build
    # {"a": "a"} instead.
    proc = run_dasel("{a, b}", '{"a":1,"b":2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 1,\n    "b": 2\n}\n'


def test_object_quoted_key_is_a_string_not_shorthand(run_dasel):
    """A quoted key with no value is rejected as an invalid shorthand."""
    # CATCHES: only property expressions may be used shorthand; a string
    # literal key must be followed by ': value' and the failure is a parse
    # error rather than an execution error.
    proc = run_dasel('{"a"}', '{"a":1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error parsing selector: invalid shorthand property\n"
    )


def test_object_spread_overwrites_and_keeps_position(run_dasel):
    """A later explicit key overwrites the spread value in place."""
    # CATCHES: spreading 'user...' inserts name and age, then name: "y"
    # replaces the value but keeps its original slot, giving name then age.
    proc = run_dasel('{user..., name: "y"}', '{"user":{"name":"x","age":3}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "name": "y",\n    "age": 3\n}\n'


def test_object_explicit_key_is_overwritten_by_a_later_spread(run_dasel):
    """An earlier explicit key loses to a later spread of the same name."""
    # CATCHES: the spread runs after the literal pair and resets name to the
    # spread source value, so order of pairs matters in both directions.
    proc = run_dasel('{name: "y", user...}', '{"user":{"name":"x","age":3}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "name": "x",\n    "age": 3\n}\n'


def test_object_spread_requires_a_map(run_dasel):
    """Spreading a scalar into an object literal is an execution error."""
    # CATCHES: the error surfaces the underlying map-keys failure, so an
    # implementation that silently skips non-map spreads would print {"a":1}.
    proc = run_dasel("{a...}", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr.endswith(
        "ast.ObjectExpr: error spreading into object: error getting map "
        "keys: unexpected type: expected map, got int\n"
    )


def test_array_literal_spread_flattens(run_dasel):
    """Spread elements inside an array literal are flattened into it."""
    # CATCHES: each spread contributes its elements individually, so the result
    # is [1,2,3] and not [[1,2],[3]].
    proc = run_dasel("[a..., b...]", '{"a":[1,2],"b":[3]}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2,\n    3\n]\n"


def test_string_literal_escapes(run_dasel):
    r"""\t and \n escapes are decoded inside string literals."""
    # CATCHES: the tokenizer unescapes \t before the JSON writer re-escapes
    # it, so the output must be a two-character tab, not a literal backslash-t.
    proc = run_dasel(r'"tab\there"', "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '"tab\\there"\n'


@pytest.mark.parametrize(
    "selector,expected",
    [
        ("$this[0:1]", "[\n    10,\n    20\n]\n"),
        ("$this[1:]", "[\n    20,\n    30\n]\n"),
        ("$this[:1]", "[\n    10,\n    20\n]\n"),
        ("$this[2:0]", "[\n    30,\n    20,\n    10\n]\n"),
        ("$this[-2:]", "[\n    20,\n    30\n]\n"),
        ("$this[:-1]", "[\n    10,\n    20,\n    30\n]\n"),
    ],
)
def test_array_ranges(run_dasel, selector, expected):
    """Range endpoints are inclusive, negative offsets are from the end."""
    # CATCHES: the end index is inclusive (unlike Go/Python slicing), an
    # omitted end means -1 i.e. the last element, and start>end reverses.
    proc = run_dasel(selector, "[10,20,30]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_range_beyond_the_end_errors(run_dasel):
    """A range whose end passes the last element fails on the first miss."""
    # CATCHES: ranges do not clamp - the slice-index error for index 3 is
    # surfaced verbatim rather than truncated to the array contents.
    proc = run_dasel("$this[0:5]", "[10,20,30]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.RangeExpr: error getting slice index: "
        "slice index out of range: 3\n"
    )


def test_string_ranges(run_dasel):
    """Ranges also work on strings and reverse when start exceeds end."""
    # CATCHES: string ranges operate on runes and share the inclusive-end and
    # reversal rules with arrays, producing "hel" and "olle".
    proc = run_dasel("$this[0:2]", '"hello"')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '"hel"\n'
    proc = run_dasel("$this[4:1]", '"hello"')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '"olle"\n'


@pytest.mark.parametrize(
    "selector,stdin,expected",
    [
        ("$this[-2:]", '"hello"', '"lo"\n'),
        ("$this[:-2]", '"hello"', '"hell"\n'),
        ("$this[-3:-1]", '"hello"', '"llo"\n'),
        ("$this[2:2]", '"hello"', '"l"\n'),
        ("$this[-1:]", '"hi"', '"i"\n'),
        ("$this[1:0]", '"hi"', '"ih"\n'),
    ],
)
def test_string_ranges_negative_and_reversed(run_dasel, selector, stdin,
                                             expected):
    """Negative string range endpoints count back from the rune length."""
    # CATCHES: both endpoints are normalised against the rune count before
    # the walk, so [-2:] takes the last two runes and [:-2] drops two, equal
    # endpoints yield a single rune, and a start beyond the end walks
    # backwards - the same rules as the array form, not Python semantics.
    proc = run_dasel(selector, stdin)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_range_on_a_map_is_rejected(run_dasel):
    """The range operator only accepts arrays and strings."""
    # CATCHES: the error names the received type, so a map input must be
    # reported as 'got map' with exit code 1.
    proc = run_dasel("$this[0:1]", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr.endswith(
        "ast.RangeExpr: range expects a slice or string, got map\n"
    )
