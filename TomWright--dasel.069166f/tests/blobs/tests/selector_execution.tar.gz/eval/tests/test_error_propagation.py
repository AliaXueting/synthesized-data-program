"""How errors from child expressions are wrapped or suppressed.

Each construct that evaluates a sub-expression wraps its failure with its own
message fragment and its AST node name, producing a chain from the innermost
property/variable failure up to the ``dasel: error:`` line.  A few constructs
(``??``, ``search()`` and recursive descent) suppress child errors entirely
and return an empty result instead.  The range endpoints are also pinned
here, including the two cases where the model indexes a string without
bounds checking and the Go runtime panics.
"""

import pytest

# Every failing selector surfaces through the same CLI prefix; the interesting
# part is the chain of "when processing ast.X" nodes and per-construct wraps
# between it and the innermost error.
PREFIX = (
    "dasel: error: error executing selector: execution error when processing "
)

# (selector, stdin, expected stderr after PREFIX, extra flags)
HIGHER_ORDER_ERRORS = [
    ("map(missing)", "[1, 2]", (), (
        "ast.MapExpr: error ranging over slice: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int")),
    ("filter(missing)", "[1, 2]", (), (
        "ast.FilterExpr: error ranging over slice: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int")),
    ("sortBy(missing)", "[1, 2]", (), (
        "ast.SortByExpr: error ranging over slice: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int")),
    ("any(missing)", "[1, 2]", (), (
        "ast.AnyExpr: error ranging over slice: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int")),
    ("all(missing)", "[1, 2]", (), (
        "ast.AllExpr: error ranging over slice: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int")),
    ("count(missing)", "[1, 2]", (), (
        "ast.CountExpr: error ranging over slice: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int")),
    ("each(missing)", "[1, 2]", (), (
        "ast.EachExpr: error ranging over slice: execution error when "
        "processing ast.PropertyExpr: unexpected type: expected map, got int")),
    ("groupBy(missing)", '[{"a": 1}]', (), (
        "ast.GroupByExpr: error ranging over slice: execution error when "
        'processing ast.PropertyExpr: map key not found: "missing"')),
    ("reduce(missing, 0, $acc + $this)", "[1, 2]", (), (
        "ast.ReduceExpr: error ranging over slice: error evaluating reduce "
        "expr for element 0: execution error when processing "
        "ast.PropertyExpr: unexpected type: expected map, got int")),
    ("mapValues(missing)", '{"a": 1}', (), (
        "ast.MapValuesExpr: error ranging over map: error evaluating "
        'mapValues expr for key "a": execution error when processing '
        "ast.PropertyExpr: unexpected type: expected map, got int")),
]


@pytest.mark.parametrize(
    "selector,stdin,flags,tail", HIGHER_ORDER_ERRORS
)
def test_higher_order_expression_errors_are_wrapped(
        run_dasel, selector, stdin, flags, tail):
    """A failing sub-expression aborts the construct with its own wrap."""
    # CATCHES: each construct names its AST node and adds its own fragment
    # ("error ranging over slice", "error evaluating reduce expr for element
    # 0", ...), so a re-implementation that returns the bare inner error, or
    # that skips remaining elements instead of failing, prints a different
    # message or a partial result.
    proc = run_dasel(selector, stdin, flags)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + tail + "\n"


@pytest.mark.parametrize(
    "selector,block",
    [
        ("if (true) { missing }", "then"),
        ("if (false) { 1 } else { missing }", "else"),
        ("true ? missing : 2", "then"),
        ("false ? 1 : missing", "else"),
    ],
)
def test_conditional_block_errors(run_dasel, selector, block):
    """A failing then/else block fails the whole if/ternary expression."""
    # CATCHES: if/else and the ternary operator share one conditional
    # executor, so both report "error executing then block" / "error
    # executing else block" - the ternary never says "then branch".
    proc = run_dasel(selector, '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + "ast.ConditionalExpr: error executing " + block +
        " block: execution error when processing ast.PropertyExpr: "
        'map key not found: "missing"\n'
    )


@pytest.mark.parametrize(
    "selector,stdin,tail",
    [
        ('{"a": missing}', '{"b": 1}', (
            "ast.ObjectExpr: error evaluating value: execution error when "
            'processing ast.PropertyExpr: map key not found: "missing"')),
        ("{foo...}", '{"b": 1}', (
            "ast.ObjectExpr: error evaluating spread values: execution error "
            'when processing ast.PropertyExpr: map key not found: "foo"')),
        ("$this[missing]", '{"a": 1}', (
            "ast.ChainedExpr: error executing expression: execution error "
            "when processing ast.PropertyExpr: error evaluating property: "
            "execution error when processing ast.PropertyExpr: map key not "
            'found: "missing"')),
    ],
)
def test_literal_and_property_evaluation_errors(run_dasel, selector, stdin,
                                                tail):
    """Object pairs, spreads and computed keys wrap evaluation errors."""
    # CATCHES: an object literal fails on a missing value or a failing spread
    # source rather than skipping the pair, and a bracketed property whose
    # key expression fails reports "error evaluating property" inside a
    # ChainedExpr wrap (the chain wraps the property, which wraps the key).
    proc = run_dasel(selector, stdin)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + tail + "\n"


@pytest.mark.parametrize(
    "selector,stdin,flags,tail",
    [
        ("1 + missing", '{"a": 1}', (), (
            "ast.BinaryExpr: error evaluating right expression: execution "
            "error when processing ast.PropertyExpr: map key not found: "
            '"missing"')),
        ('branch(1, 2) + "a"', "null", ("--unstable",), (
            "ast.BinaryExpr: could not add: incompatible types: int and "
            "string")),
        ("branch(1, 2) + missing", '{"a": 1}', ("--unstable",), (
            "ast.BinaryExpr: error evaluating right expression: execution "
            "error when processing ast.PropertyExpr: unexpected type: "
            "expected map, got int")),
    ],
)
def test_binary_operand_errors_including_branch_fanout(
        run_dasel, selector, stdin, flags, tail):
    """Binary operators wrap right-side failures; branch-left fans out."""
    # CATCHES: with a branch on the left the right side is re-evaluated per
    # branch element (so `missing` fails against the int element with
    # "expected map, got int"), and an operator type error surfaces per
    # element unwrapped by any "error ranging" text.
    proc = run_dasel(selector, stdin, flags)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == PREFIX + tail + "\n"


def test_unary_not_operand_error_is_wrapped(run_dasel):
    """! wraps a failing operand with the unary executor's message."""
    # CATCHES: the unary executor adds "error evaluating right expression"
    # before the property failure; a re-implementation that evaluates the
    # operand lazily or reports the bare missing-key error differs.
    proc = run_dasel("!missing", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + "ast.UnaryExpr: error evaluating right expression: "
        "execution error when processing ast.PropertyExpr: map key not "
        'found: "missing"\n'
    )


@pytest.mark.parametrize(
    "selector,tail",
    [
        ("$this[0.5:1]",
         "error getting start int value: unexpected type: expected int, "
         "got float"),
        ('$this[1:"a"]',
         "error getting end int value: unexpected type: expected int, got "
         "string"),
    ],
)
def test_range_endpoint_type_errors(run_dasel, selector, tail):
    """Range endpoints must evaluate to integers."""
    # CATCHES: the endpoints go through an int conversion that reports which
    # end failed ("start" vs "end") and the offending type, wrapped by the
    # RangeExpr node inside the $this chain.
    proc = run_dasel(selector, "[1, 2, 3]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + "ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.RangeExpr: " + tail + "\n"
    )


@pytest.mark.parametrize(
    "selector,tail",
    [
        ("$this[-4:]", "slice index out of range: -1"),
        ("$this[5:0]", "slice index out of range: 5"),
    ],
)
def test_slice_range_out_of_bounds_errors(run_dasel, selector, tail):
    """A normalised out-of-bounds slice range is an error, not a clamp."""
    # CATCHES: negative endpoints are normalised against the length before
    # any bounds check, so [-4:] on length 3 walks down from -1 and fails;
    # ascending walks stop at the first bad index (5 here). Unlike strings,
    # arrays do bounds-check each step.
    proc = run_dasel(selector, "[10, 20, 30]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        PREFIX + "ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.RangeExpr: error getting slice index: " +
        tail + "\n"
    )


@pytest.mark.parametrize(
    "selector,panic_line",
    [
        ("$this[0:10]", "panic: runtime error: index out of range [2] with length 2"),
        ("$this[-5:]", "panic: runtime error: index out of range [-3]"),
    ],
)
def test_string_range_without_bounds_checking_panics(
        run_dasel, selector, panic_line):
    """String ranges have no bounds check and crash the Go runtime."""
    # CATCHES: unlike slices, the string range walks the rune slice directly,
    # so an end past the string (or a negative start that stays negative
    # after normalisation) panics with exit code 2 instead of a dasel error.
    # Only the first stderr line is asserted: the goroutine dump that
    # follows carries addresses.
    proc = run_dasel(selector, '"hi"')
    assert proc.returncode == 2
    assert proc.stdout == ""
    assert proc.stderr.splitlines()[0] == panic_line


@pytest.mark.parametrize(
    "selector,stdin",
    [
        ("search($missing)", "[1, 2]"),
        ("..[1.5]", "[[1, 2]]"),
        ("..[-1]", "[[1, 2]]"),
    ],
)
def test_search_and_recursive_descent_swallow_expression_errors(
        run_dasel, selector, stdin):
    """search() and .. suppress every sub-expression error, not just types."""
    # CATCHES: an undefined variable inside search() - which is not one of
    # the documented suppressible error types - still yields an empty array
    # and exit code 0, and recursive descent likewise drops values whose
    # index expression fails (float index, out-of-range index).
    proc = run_dasel(selector, stdin)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[]\n"
