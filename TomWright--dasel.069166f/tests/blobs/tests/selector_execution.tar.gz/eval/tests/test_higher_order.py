"""Higher-order constructs over arrays and maps.

Covers map, filter, mapValues, search, sortBy, groupBy, reduce, each, any,
all and count: what each returns, the variable bindings they expose, the
stringification rules groupBy uses for keys, the per-construct error when
given the wrong input type, and the error-suppression rules inside search.
"""

import pytest

OBJECTS = '[{"n": 3}, {"n": 1}, {"n": 2}]'


def test_map_transforms_each_element(run_dasel):
    """map applies the expression to every element, keeping positions."""
    # CATCHES: the result is a new array of the same length in the original
    # order; nothing is flattened or reordered.
    proc = run_dasel("map($this * 2)", "[1, 2, 3]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    2,\n    4,\n    6\n]\n"


def test_map_over_empty_array(run_dasel):
    """map over an empty array yields an empty array."""
    # CATCHES: the empty input is not an error and not null - the executor
    # always builds a fresh slice, so [] comes back out.
    proc = run_dasel("map($this)", "[]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[]\n"


def test_map_result_can_be_indexed(run_dasel):
    """A following [n] indexes the map result in the same expression."""
    # CATCHES: map supports a trailing index expression, so the doubled array
    # is indexed directly and yields the single element 4.
    proc = run_dasel("map($this * 2)[1]", "[1, 2, 3]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "4\n"


def test_map_over_non_array_errors(run_dasel):
    """map refuses maps with 'cannot map over non-array'."""
    # CATCHES: the rejection names the MapExpr node and the exact phrase
    # 'cannot map over non-array' with exit code 1, distinguishing map from
    # its sibling constructs.
    proc = run_dasel("map($this)", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.MapExpr: cannot map over non-array\n"
    )


def test_filter_keeps_matching_elements(run_dasel):
    """filter keeps the original elements whose expression is true."""
    # CATCHES: the element itself (not the boolean) is appended to the
    # result, in input order.
    proc = run_dasel("filter($this > 1)", "[1, 2, 3]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    2,\n    3\n]\n"


def test_filter_with_no_matches(run_dasel):
    """A filter that matches nothing yields an empty array."""
    # CATCHES: no match is not an error, and the result is [] rather than
    # null, so a re-implementation returning the input would differ.
    proc = run_dasel("filter($this > 9)", "[1, 2]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[]\n"


def test_filter_over_non_array_errors(run_dasel):
    """filter refuses maps with 'cannot filter over non-array'."""
    # CATCHES: filter's message names its own FilterExpr node, so a
    # re-implementation that shares one generic error between map and filter
    # would differ.
    proc = run_dasel("filter($this > 1)", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.FilterExpr: cannot filter over non-array\n"
    )


def test_map_values_transforms_values(run_dasel):
    """mapValues rebuilds the map with transformed values, order kept."""
    # CATCHES: keys are untouched and keep their original insertion order
    # while only the values change.
    proc = run_dasel("mapValues($this + 1)", '{"a": 1, "b": 2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 2,\n    "b": 3\n}\n'


def test_map_values_over_non_map_errors(run_dasel):
    """mapValues refuses arrays with 'cannot mapValues over non-map'."""
    # CATCHES: mapValues is the mirror image of map - it demands a map and
    # rejects arrays, with its own camel-cased message.
    proc = run_dasel("mapValues($this)", "[1, 2]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.MapValuesExpr: cannot mapValues over non-map\n"
    )


def test_map_values_error_names_the_key(run_dasel):
    """A failing mapValues expression reports which key it failed on."""
    # CATCHES: the error is wrapped with the %q-quoted map key, so the
    # re-implementation must track key context while iterating.
    proc = run_dasel(
        "mapValues(a.b)", '{"x": {"a": {"b": 1}}, "y": {"a": 5}}'
    )
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        'processing ast.MapValuesExpr: error ranging over map: error '
        'evaluating mapValues expr for key "y": execution error when '
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.PropertyExpr: unexpected type: expected "
        "map, got int\n"
    )


@pytest.mark.parametrize(
    "document,expected",
    [
        ('{"a": 2, "b": {"c": 2, "d": 1}}', "[\n    2,\n    2\n]\n"),
        ("[1, 2, [2, 3]]", "[\n    2,\n    2\n]\n"),
        ('{"a": 1}', "[]\n"),
    ],
)
def test_search_collects_matches_recursively(run_dasel, document, expected):
    """search walks maps and arrays depth-first collecting true values."""
    # CATCHES: matches at every level are flattened in walk order - for the
    # map case both the top-level 2 and the nested 2 are found, and arrays
    # inside arrays are descended into; no match yields [].
    proc = run_dasel("search($this == 2)", document)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_search_suppresses_missing_key_errors(run_dasel):
    """Elements where the expression errors on navigation are skipped."""
    # CATCHES: map-key-not-found (and type/slice errors) inside a search are
    # swallowed, so only the element whose b exists is collected.
    proc = run_dasel('search(b == 1)', '{"x": {"c": 1}, "y": {"b": 1}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '[\n    {\n        "b": 1\n    }\n]\n'


def test_search_requires_a_boolean_result(run_dasel):
    """A search expression returning a non-boolean is an error."""
    # CATCHES: suppression only covers evaluation errors, not the final
    # boolean conversion, so search(a) on an int property fails.
    proc = run_dasel("search(a)", '{"x": {"a": 1}}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.SearchExpr: unexpected type: expected bool, got "
        "int\n"
    )


def test_sort_by_property(run_dasel):
    """sortBy orders the elements by the expression result, ascending."""
    # CATCHES: the original element objects are returned in the new order,
    # not the sort keys.
    proc = run_dasel("sortBy(n)", OBJECTS)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '[\n    {\n        "n": 1\n    },\n    {\n        "n": 2\n    },\n'
        '    {\n        "n": 3\n    }\n]\n'
    )


def test_sort_by_descending_keyword(run_dasel):
    """The second sortBy argument is the literal keyword desc or asc."""
    # CATCHES: direction is a bare keyword token, not a string or boolean,
    # and desc reverses the comparison rather than reversing the output.
    proc = run_dasel("sortBy(n, desc)", OBJECTS)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '[\n    {\n        "n": 3\n    },\n    {\n        "n": 2\n    },\n'
        '    {\n        "n": 1\n    }\n]\n'
    )


def test_sort_by_self(run_dasel):
    """sortBy($this) sorts the scalars directly."""
    # CATCHES: the sort key expression defaults to the element itself, so a
    # bare numeric array comes back numerically sorted, not as strings.
    proc = run_dasel("sortBy($this)", "[3, 1, 2]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2,\n    3\n]\n"


def test_sort_by_key_desc_reverses(run_dasel):
    """$key is the index inside sortBy, so desc on it reverses the array."""
    # CATCHES: sortBy binds $key to the element index like the other walking
    # constructs, giving a stable reverse for free.
    proc = run_dasel('sortBy($key, desc)', '["a", "b", "c"]')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '[\n    "c",\n    "b",\n    "a"\n]\n'


def test_sort_by_non_slice_errors(run_dasel):
    """sortBy refuses maps with 'cannot sort by on non-slice data'."""
    # CATCHES: sortBy's message says 'non-slice data' rather than the
    # 'non-array' wording used by map/filter, and names ast.SortByExpr.
    proc = run_dasel("sortBy($this)", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.SortByExpr: cannot sort by on non-slice data\n"
    )


def test_group_by_strings(run_dasel):
    """groupBy buckets elements under stringified keys, first-seen order."""
    # CATCHES: groups appear in the order their keys were first encountered
    # (x before y), and each group keeps its elements in input order.
    proc = run_dasel(
        'groupBy(t)', '[{"t": "x", "v": 1}, {"t": "y", "v": 2}, {"t": "x", "v": 3}]'
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '{\n    "x": [\n        {\n            "t": "x",\n            "v": 1\n'
        "        },\n        {\n            \"t\": \"x\",\n            \"v\": 3\n"
        "        }\n    ],\n    \"y\": [\n        {\n            \"t\": \"y\",\n"
        "            \"v\": 2\n        }\n    ]\n}\n"
    )


def test_group_by_int_keys(run_dasel):
    """Integer group keys are rendered with %d into map keys."""
    # CATCHES: $key is the zero-based index inside groupBy, and the resulting
    # map keys are the decimal strings "0" and "1".
    proc = run_dasel('groupBy($key)', '["a", "b"]')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "0": [\n        "a"\n    ],\n    "1": [\n        "b"\n    ]\n}\n'


def test_group_by_bool_and_float_keys(run_dasel):
    """Bool keys use %v and float keys %g, so 2.0 groups under "2"."""
    # CATCHES: the key stringification follows Go fmt verbs - true/false for
    # bools and %g for floats, which drops the trailing .0 of a whole float.
    proc = run_dasel("groupBy(n)", '[{"n": true}, {"n": false}, {"n": true}]')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '{\n    "true": [\n        {\n            "n": true\n        },\n'
        '        {\n            "n": true\n        }\n    ],\n    "false": [\n'
        '        {\n            "n": false\n        }\n    ]\n}\n'
    )
    proc = run_dasel("groupBy(n)", '[{"n": 1.5}, {"n": 2.0}]')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '{\n    "1.5": [\n        {\n            "n": 1.5\n        }\n    ],\n'
        '    "2": [\n        {\n            "n": 2\n        }\n    ]\n}\n'
    )


def test_group_by_empty_array(run_dasel):
    """groupBy over an empty array yields an empty object."""
    # CATCHES: the result of groupBy is always a map, so an empty input gives
    # {} and not [] or null.
    proc = run_dasel("groupBy(t)", "[]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "{}\n"


def test_group_by_null_key_errors(run_dasel):
    """A null group key is rejected with the cannot-convert message."""
    # CATCHES: only string/int/float/bool can become keys; null fails with
    # the nested 'cannot convert null to string' wording.
    proc = run_dasel("groupBy(n)", '[{"n": 1}, {"n": null}]')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.GroupByExpr: error ranging over slice: cannot use "
        "null as group key: cannot convert null to string for use as group "
        "key\n"
    )


def test_group_by_non_slice_errors(run_dasel):
    """groupBy refuses maps with 'cannot group by on non-slice data'."""
    # CATCHES: the message mirrors sortBy's 'non-slice data' phrasing but
    # names ast.GroupByExpr, keeping the two distinguishable.
    proc = run_dasel("groupBy(t)", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.GroupByExpr: cannot group by on non-slice data\n"
    )


def test_reduce_sums(run_dasel):
    """reduce(expr, init, update) folds the array into the accumulator."""
    # CATCHES: the update sees $acc and $this; the final accumulator is
    # returned, not the array.
    proc = run_dasel("reduce($this, 0, $acc + $this)", "[1, 2, 3]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "6\n"


def test_reduce_binds_this_to_the_element_expression(run_dasel):
    """$this in the update is the element expression's result."""
    # CATCHES: the first argument is evaluated per element and both the data
    # and $this for the update become that result, so 10+2+4+6 = 22.
    proc = run_dasel("reduce($this * 2, 10, $acc + $this)", "[1, 2, 3]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "22\n"


def test_reduce_empty_array_returns_init(run_dasel):
    """With no elements the init value is returned unchanged."""
    # CATCHES: the init expression is still evaluated before iteration, so an
    # empty array folds to the init value exactly, not to null.
    proc = run_dasel("reduce($this, 100, $acc)", "[]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "100\n"


def test_reduce_over_non_array_errors(run_dasel):
    """reduce refuses maps with 'cannot reduce over non-array'."""
    # CATCHES: the type check happens before the init expression is
    # evaluated, so the failure is the plain cannot-reduce message.
    proc = run_dasel("reduce($this, 0, $acc + $this)", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ReduceExpr: cannot reduce over non-array\n"
    )


def test_reduce_acc_is_unbound_afterwards(run_dasel):
    """$acc is deleted once reduce returns, even though it was bound inside."""
    # CATCHES: the executor restores the previous (absent) $acc binding, so a
    # chained reference fails with variable acc not found.
    proc = run_dasel("reduce($this, 0, $acc + $this); $acc", "[1, 2]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr.endswith(
        "ast.VariableExpr: variable acc not found\n"
    )


def test_each_mutates_items_and_returns_the_array(run_dasel):
    """each runs the expression per item for its side effects."""
    # CATCHES: each returns the original (mutated) input array, so the output
    # is the array of items with x overwritten, not the expression results.
    proc = run_dasel("each(x = 1)", '[{"x": 5}, {"x": 6}]')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == (
        '[\n    {\n        "x": 1\n    },\n    {\n        "x": 1\n    }\n]\n'
    )


def test_each_without_side_effects_is_identity(run_dasel):
    """each($this) leaves the array untouched and returns it."""
    # CATCHES: the returned value is the input slice itself, so the document
    # round-trips even though every element was visited.
    proc = run_dasel("each($this)", "[1, 2]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2\n]\n"


def test_each_over_non_array_errors(run_dasel):
    """each refuses maps with 'cannot each over non-array'."""
    # CATCHES: each validates its input before running the expression on any
    # element, and names ast.EachExpr in the failure.
    proc = run_dasel('each(1)', '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.EachExpr: cannot each over non-array\n"
    )


@pytest.mark.parametrize(
    "selector,expected",
    [
        ("any($this > 2)", "true\n"),
        ("any($this > 5)", "false\n"),
        ("all($this > 2)", "false\n"),
        ("all($this > 0)", "true\n"),
        ("count($this > 1)", "2\n"),
        ("count($this > 9)", "0\n"),
    ],
)
def test_any_all_count(run_dasel, selector, expected):
    """any/all/count aggregate boolean expressions over the array."""
    # CATCHES: any is an inclusive OR, all an inclusive AND, and count the
    # number of true results - all over [1, 2, 3].
    proc = run_dasel(selector, "[1, 2, 3]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_count_result_is_a_number(run_dasel):
    """The count result can be used directly in arithmetic."""
    # CATCHES: count produces a real int value, not a string, so adding one
    # works without any conversion.
    proc = run_dasel("count($this > 0) + 1", "[1, 2, 3]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "4\n"


def test_any_requires_boolean_results(run_dasel):
    """A non-boolean expression inside any is an error, not truthiness."""
    # CATCHES: elements are converted to bool with the expected-type error,
    # wrapped as 'error ranging over slice', and there is no truthy coercion
    # of the number 1.
    proc = run_dasel("any($this)", "[1, 2]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.AnyExpr: error ranging over slice: unexpected type: "
        "expected bool, got int\n"
    )


@pytest.mark.parametrize(
    "selector,construct",
    [
        ("any($this > 1)", "AnyExpr"),
        ("all($this > 1)", "AllExpr"),
        ("count($this > 1)", "CountExpr"),
    ],
)
def test_aggregates_over_non_array_errors(run_dasel, selector, construct):
    """any/all/count each name themselves when given a map."""
    # CATCHES: the three executors have distinct cannot-use messages that
    # name their own AST node, all with exit code 1.
    proc = run_dasel(selector, '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.%s: cannot use %s over non-array\n"
        % (construct, construct.replace("Expr", "").lower())
    )
