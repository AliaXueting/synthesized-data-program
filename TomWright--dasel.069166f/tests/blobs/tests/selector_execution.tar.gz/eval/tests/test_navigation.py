"""Navigation semantics: property access, indexing, chains, recursive descent.

Covers dot chains into nested maps, quoted property names (both quote styles),
square-bracket index access and its error cases, indexing an array literal
inline, and the ``..`` recursive descent operator in both its named-property
and wildcard forms.
"""

import pytest

NESTED = '{"a":{"b":{"c":42}}}'


def test_nested_property_chain(run_dasel):
    """A dot chain walks down through nested maps and prints the leaf."""
    # CATCHES: a re-implementation that stops at the first segment or that
    # wraps the result in an extra array would not print the bare scalar 42.
    proc = run_dasel("a.b.c", NESTED)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "42\n"
    assert proc.stderr == ""


@pytest.mark.parametrize(
    "selector",
    ['$this["a b"]', "$this['a b']"],
)
def test_quoted_property_access(run_dasel, selector):
    """Keys with spaces are reachable with double or single quoted brackets."""
    # CATCHES: the tokenizer only treats a bare word as a property name, so a
    # re-implementation that splits on whitespace would report a missing key.
    proc = run_dasel(selector, '{"a b": 7}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "7\n"


def test_quoted_property_in_a_chain(run_dasel):
    """A quoted index can follow an ordinary property in the same chain."""
    # CATCHES: parsing must keep the bracket index attached to the preceding
    # property instead of treating it as a new root-level expression.
    proc = run_dasel("a['b c']", '{"a":{"b c": 9}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "9\n"


def test_index_access_on_root_array(run_dasel):
    """Indexing the root document uses $this plus square brackets."""
    # CATCHES: a bare [1] is an array literal, not an index; only the $this
    # form navigates into the input document and yields the element itself.
    proc = run_dasel("$this[1]", "[10,20,30]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "20\n"


def test_index_then_property_chain(run_dasel):
    """An index may be followed by further property access."""
    # CATCHES: the chain has to feed the indexed element into the following
    # property expression rather than restarting from the document root.
    proc = run_dasel("a[1].b", '{"a":[{"b":1},{"b":2}]}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "2\n"


def test_index_of_inline_array_literal(run_dasel):
    """An array literal can be indexed directly in the same expression."""
    # CATCHES: the literal is built first and then indexed; a re-implementation
    # that evaluates the index against the input document would fail here.
    proc = run_dasel("[1,2][0]", "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n"


def test_negative_index_is_out_of_range(run_dasel):
    """Negative indexes are rejected rather than counting from the end."""
    # CATCHES: unlike the range operator, plain index access has no negative
    # index handling, so -1 must fail with the exact out-of-range message.
    proc = run_dasel("$this[-1]", "[10,20,30]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.PropertyExpr: slice index out of range: -1\n"
    )


def test_index_out_of_range(run_dasel):
    """An index past the end of the array reports the offending index."""
    # CATCHES: the error text embeds the requested index, so an off-by-one
    # implementation or a clamping implementation would differ.
    proc = run_dasel("$this[5]", "[10,20,30]")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.PropertyExpr: slice index out of range: "
        "5\n"
    )


def test_missing_map_key_error(run_dasel):
    """Reading an absent key fails with the Go %q-quoted key name."""
    # CATCHES: the message format 'map key not found: "b"' with double quotes
    # and the exit code 1 must be reproduced exactly.
    proc = run_dasel("b", '{"a": 5}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        'processing ast.PropertyExpr: map key not found: "b"\n'
    )


def test_property_access_on_scalar(run_dasel):
    """Navigating into a scalar reports the actual type of that scalar."""
    # CATCHES: the error names the type of the value being navigated, so an
    # implementation that reports the document type or 'null' would differ.
    proc = run_dasel("a.b", '{"a": 5}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ChainedExpr: error executing expression: execution "
        "error when processing ast.PropertyExpr: unexpected type: expected "
        "map, got int\n"
    )


def test_recursive_descent_named_property(run_dasel):
    """..name collects the property from every nested map, in walk order."""
    # CATCHES: the top-level 'c' key is skipped (only children are visited)
    # and results are flattened depth-first, so a breadth-first or
    # root-including implementation produces a different list.
    proc = run_dasel("..c", '{"a":{"b":{"c":1}},"c":9,"d":[{"c":2}]}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2\n]\n"


def test_recursive_descent_wildcard(run_dasel):
    """..* returns every scalar leaf anywhere in the document."""
    # CATCHES: the wildcard form only collects scalars, so maps and arrays on
    # the path are dropped; a "collect everything" implementation differs.
    proc = run_dasel("..*", '{"a":1,"b":{"c":2}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2\n]\n"


def test_recursive_descent_no_match_is_empty_array(run_dasel):
    """A recursive descent that finds nothing yields an empty array."""
    # CATCHES: missing keys are suppressed inside recursive descent, so the
    # result is [] with exit 0 rather than a map-key-not-found failure.
    proc = run_dasel("..b", '{"a": 1}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[]\n"


def test_recursive_descent_through_arrays(run_dasel):
    """Recursive descent descends through arrays as well as maps."""
    # CATCHES: array elements are visited like map values, so a 'c' key inside
    # an array element is found even though arrays have no such property.
    proc = run_dasel("..b", '{"a":{"b":1},"b":{"a":{"b":2}}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2\n]\n"


@pytest.mark.parametrize(
    "selector,stdin,expected",
    [
        ("..[0]", "[[1, 2], [3, 4]]", "[\n    1,\n    3\n]\n"),
        ("..[0]", '{"a": {"b": [9, 8]}}', "[\n    9\n]\n"),
        ("..[0]", '{"a": {"b": 1}, "c": [7, 8]}', "[\n    7\n]\n"),
        ("..[0]", '[[1, 2], {"x": 1}, [3]]', "[\n    1,\n    3\n]\n"),
        ("..[0]", '{"a": [[7, 8]]}',
         "[\n    [\n        7,\n        8\n    ],\n    7\n]\n"),
        ("..[0]", "[1, 2]", "[]\n"),
        ("..[0]", "5", "[]\n"),
    ],
)
def test_recursive_descent_index_access(run_dasel, selector, stdin,
                                        expected):
    """..[n] takes index n of every nested container, in walk order."""
    # CATCHES: the bracket form after .. is a slice index evaluated against
    # each visited container (map containers contribute nothing because the
    # index error is suppressed), collected depth-first with a container's
    # own [0] before its children's - so {"a": [[7, 8]]} yields both the
    # inner array and then its first element.
    proc = run_dasel(selector, stdin)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


def test_recursive_descent_bracket_is_an_index_not_a_key(run_dasel):
    """..["foo"] does not look up the string key the way ..foo does."""
    # CATCHES: a quoted string inside the brackets is still consumed as a
    # slice index and fails per-container (suppressed to nothing), so unlike
    # the dot form it never reads the "foo" map key even where it exists.
    proc = run_dasel('..["foo"]', '{"a": {"foo": 5}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[]\n"
    proc = run_dasel("..[foo]", '{"a": {"foo": 5}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[]\n"
    proc = run_dasel("..foo", '{"a": {"foo": 5}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    5\n]\n"


def test_recursive_descent_wildcard_through_arrays(run_dasel):
    """..* also collects scalars that sit directly inside arrays."""
    # CATCHES: array elements are visited like map values, so scalars inside
    # an array (or inside an array nested in an array) are collected in
    # order; only the containers themselves are dropped from the result.
    proc = run_dasel("..*", '{"a": [1, 2]}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2\n]\n"
    proc = run_dasel("..*", '{"a": [1, {"b": 2}]}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1,\n    2\n]\n"
    proc = run_dasel("..*", '{"a": [[3]]}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    3\n]\n"
