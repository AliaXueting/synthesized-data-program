"""Variable semantics: $this, $root, $key, --var and the env fallback.

Covers the two engine-provided variables, the $key binding introduced by the
higher-order constructs (and its restoration afterwards), variables supplied
with --var in each of its formats, the fallback to reading an OS environment
variable of the same name, the variable-not-found error, and the fact that
$this and $root can never be replaced by --var.
"""

import pytest

DOC = '{"a": 1}'


def test_this_variable_is_the_current_value(run_dasel):
    """$this evaluates to the document the selector is running against."""
    # CATCHES: $this is rebound at every expression boundary, so it must
    # reflect the whole input document here and not an inner value.
    proc = run_dasel("$this", DOC)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 1\n}\n'


def test_root_variable(run_dasel):
    """$root is the input document even after navigating away from it."""
    # CATCHES: $root is captured once before execution, so combining a nested
    # navigation with $root still sees the top-level document.
    proc = run_dasel("a.b + $root.a.b", '{"a":{"b":1}}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "2\n"


def test_key_is_the_index_inside_map_and_filter(run_dasel):
    """$key is the element index for the array-walking constructs."""
    # CATCHES: map, filter, each, sortBy, groupBy, reduce, any, all and count
    # all bind $key to the zero-based index, not to the element value.
    proc = run_dasel("map($key)", "[5,6]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    0,\n    1\n]\n"
    proc = run_dasel("filter($key == 0 || $this == 30)", "[10,20,30]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    10,\n    30\n]\n"


def test_key_is_the_map_key_inside_map_values(run_dasel):
    """$key is the map key string inside mapValues."""
    # CATCHES: the same variable name holds a string for map iterations and an
    # int for array iterations; mixing them up changes the output type.
    proc = run_dasel('mapValues($key + "!")', '{"a":1,"b":2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": "a!",\n    "b": "b!"\n}\n'


def test_key_binds_inside_search_and_recursive_descent(run_dasel):
    """search and .. also expose $key for the value being visited."""
    # CATCHES: search over a map yields string keys while reduce over an array
    # yields indexes, so both bindings have to be reachable from $key.
    proc = run_dasel('search($key == "b")', '{"a":{"b":1},"c":2}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "[\n    1\n]\n"
    proc = run_dasel("reduce($this, 0, $acc + $key)", "[10,20,30]")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "3\n"


def test_key_is_restored_after_the_construct_ends(run_dasel):
    """$key is unbound again once the enclosing construct returns."""
    # CATCHES: the save/restore wrapper deletes $key afterwards, so a second
    # chained expression must fail with variable key not found.
    proc = run_dasel("mapValues($key); $key", '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr.endswith(
        "ast.VariableExpr: variable key not found\n"
    )


def test_key_in_a_nested_construct_is_the_inner_one(run_dasel):
    """An inner array construct shadows the outer $key binding."""
    # CATCHES: the innermost construct wins, so mapValues over arrays of
    # arrays reports the inner indexes rather than the outer map keys.
    proc = run_dasel("mapValues(map($key))", '{"a":[1,2],"b":[3]}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": [\n        0,\n        1\n    ],\n    "b": [\n        0\n    ]\n}\n'


def test_var_flag_scalar_value(run_dasel):
    """--var name=value parses the value with the dasel format by default."""
    # CATCHES: the default 'dasel' format evaluates the raw text as a selector
    # against null, so 5 becomes an int and 1+2 becomes 3 rather than a string.
    proc = run_dasel("$foo", DOC, flags=("--var", "foo=5"))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "5\n"
    proc = run_dasel("$foo", DOC, flags=("--var", "foo=1+2"))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "3\n"


def test_var_flag_quoted_string_value(run_dasel):
    """A quoted --var value becomes a string, not a selector."""
    # CATCHES: without the inner quotes the text would be executed as a
    # selector; with them the variable holds the literal characters bar.
    proc = run_dasel("$foo", DOC, flags=("--var", 'foo="bar"'))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '"bar"\n'


def test_var_flag_explicit_json_format(run_dasel):
    """--var name=json:... parses the value with the JSON reader."""
    # CATCHES: the prefix selects the reader, so the variable is a real map
    # that can then be navigated with ordinary property access.
    proc = run_dasel("$foo.b", DOC, flags=("--var", 'foo=json:{"b":2}'))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "2\n"


def test_var_flag_empty_value_is_null(run_dasel):
    """An empty --var value binds null rather than failing."""
    # CATCHES: the name= split still succeeds with an empty right hand side
    # and the dasel reader turns zero bytes into a null value.
    proc = run_dasel("$foo", DOC, flags=("--var", "foo="))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "null\n"


def test_var_flag_reads_from_a_file(run_dasel, tmp_path):
    """--var name=json:file:path loads the value from a file on disk."""
    # CATCHES: the file: prefix is applied after the format prefix, and the
    # file is read relative to the process working directory.
    var_file = tmp_path / "var.json"
    var_file.write_text('{"x": 7}\n')
    proc = run_dasel(
        "$v.x", DOC, flags=("--var", "v=json:file:%s" % var_file), cwd=tmp_path
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "7\n"


def test_var_flag_without_equals_is_rejected(run_dasel):
    """A --var argument with no '=' is a flag parsing error."""
    # CATCHES: the failure happens in flag decoding, so the exit code is the
    # kong usage-exit code 80 and the usage block is printed on stdout.
    proc = run_dasel("$foo", DOC, flags=("--var", "foo"))
    assert proc.returncode == 80
    assert proc.stderr == (
        "dasel: error: --var: invalid variable format, expect foo=bar, or "
        "foo=format:file:path\n"
    )
    assert proc.stdout.startswith("Usage: dasel <command>")


def test_env_variable_fallback(run_dasel):
    """An unbound variable name is looked up in the OS environment."""
    # CATCHES: the fallback reads the environment variable verbatim and wraps
    # it as a string, so a re-implementation that only checks --var fails.
    proc = run_dasel("$MYVAR", DOC, env={"MYVAR": "hello world"})
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '"hello world"\n'


def test_var_flag_takes_precedence_over_the_environment(run_dasel):
    """A --var of the same name shadows the OS environment variable."""
    # CATCHES: the executor checks its variable map before falling back to
    # the environment, so $foo is the parsed int 1, not the string "2".
    proc = run_dasel(
        "$foo", DOC, flags=("--var", "foo=1"), env={"foo": "2"}
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "1\n"


def test_empty_env_variable_is_not_found(run_dasel):
    """An environment variable set to the empty string is treated as unset."""
    # CATCHES: the fallback checks for a non-empty value, so an empty variable
    # must still produce the variable-not-found error and exit code 1.
    proc = run_dasel("$EMPTYVAR", DOC, env={"EMPTYVAR": ""})
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr.endswith(
        "ast.VariableExpr: variable EMPTYVAR not found\n"
    )


def test_undefined_variable_error(run_dasel):
    """A variable that is neither bound nor in the environment errors."""
    # CATCHES: the exact 'variable nope not found' wording and exit code 1
    # must be reproduced; a null-coalescing default would hide this.
    proc = run_dasel("$nope", DOC)
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.VariableExpr: variable nope not found\n"
    )


def test_builtin_variables_cannot_be_replaced_by_var(run_dasel):
    """--var this=... and --var root=... are ignored by the engine."""
    # CATCHES: $this and $root are always re-bound by the executor and by the
    # CLI, so a --var of the same name must not leak through.
    proc = run_dasel("$this", DOC, flags=("--var", "this=json:[9]"))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 1\n}\n'
    proc = run_dasel("$root", DOC, flags=("--var", "root=json:[9]"))
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": 1\n}\n'


def test_var_key_is_shadowed_while_iterating(run_dasel):
    """A --var named key is replaced by the live binding inside a construct."""
    # CATCHES: withKeyVar overrides any user-supplied $key for the duration of
    # the iteration, so mapValues still reports the real map keys.
    proc = run_dasel(
        "mapValues($key)", '{"a":1,"b":2}', flags=("--var", 'key="zzz"')
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '{\n    "a": "a",\n    "b": "b"\n}\n'
