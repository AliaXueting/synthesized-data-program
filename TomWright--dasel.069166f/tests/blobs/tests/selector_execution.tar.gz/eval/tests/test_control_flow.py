"""Control flow: if/elseif/else blocks and the ternary operator.

Covers which branch is chosen, that a missing else yields null, that the
body runs against the same document as the condition, right-associative
ternary chaining, and the exact errors for non-boolean conditions and for
conditions that fail while being evaluated.
"""

import pytest


def test_if_true_runs_then_block(run_dasel):
    """``if (true) {a}`` runs the body against the input document."""
    # CATCHES: the body is evaluated with the document as $this, so the bare
    # property a resolves to 7 rather than to the literal true.
    proc = run_dasel('if (true) {a}', '{"a": 7}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "7\n"
    assert proc.stderr == ""


def test_if_without_else_yields_null(run_dasel):
    """A false condition with no else block evaluates to null."""
    # CATCHES: the missing else is not an error and not the input document;
    # the conditional executor returns an explicit null value.
    proc = run_dasel('if (false) {"yes"}', "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == "null\n"


def test_if_else_selects_the_else_block(run_dasel):
    """``if (a == 1)`` picks between blocks using the document value."""
    # CATCHES: the condition is a full expression over the document, so the
    # else branch is taken when the property comparison is false.
    proc = run_dasel('if (a == 1) {"y"} else {"n"}', '{"a": 1}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '"y"\n'
    proc = run_dasel('if (a == 2) {"y"} else {"n"}', '{"a": 1}')
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == '"n"\n'


@pytest.mark.parametrize(
    "selector,expected",
    [
        ('if (false) {"a"} elseif (true) {"b"} else {"c"}', '"b"\n'),
        ('if (false) {"a"} elseif (false) {"b"} else {"c"}', '"c"\n'),
        ('if (true) {"a"} elseif (true) {"b"} else {"c"}', '"a"\n'),
    ],
)
def test_if_elseif_else_chain(run_dasel, selector, expected):
    """elseif chains are nested conditionals evaluated in written order."""
    # CATCHES: the parser links each elseif as the else of the previous
    # conditional, so the first true condition wins and later ones never run.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected


@pytest.mark.parametrize(
    "selector,expected",
    [
        ('1 == 1 ? "y" : "n"', '"y"\n'),
        ('1 == 2 ? "y" : "n"', '"n"\n'),
        ("false ? 1 : true ? 2 : 3", "2\n"),
        ("false ? 1 : false ? 2 : 3", "3\n"),
    ],
)
def test_ternary(run_dasel, selector, expected):
    """``cond ? then : else`` shares semantics with if, chained right-assoc."""
    # CATCHES: the ternary builds the same ConditionalExpr as if, and an else
    # branch that is itself a ternary parses right-associatively.
    proc = run_dasel(selector, "null")
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == expected
    assert proc.stderr == ""


def test_if_condition_must_be_boolean(run_dasel):
    """A non-boolean if condition is an execution error, not truthiness."""
    # CATCHES: there is no truthy/falsy coercion, so if (5) fails with the
    # expected-bool message naming the received type.
    proc = run_dasel('if (5) {"y"}', "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ConditionalExpr: error converting condition to "
        "boolean: unexpected type: expected bool, got int\n"
    )


def test_ternary_condition_must_be_boolean(run_dasel):
    """The ternary condition goes through the same boolean conversion."""
    # CATCHES: both syntax forms share the ConditionalExpr executor, so
    # ``5 ? 1 : 2`` fails with the identical error text as ``if (5)``.
    proc = run_dasel("5 ? 1 : 2", "null")
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ConditionalExpr: error converting condition to "
        "boolean: unexpected type: expected bool, got int\n"
    )


def test_if_condition_error_is_wrapped(run_dasel):
    """A condition that fails to evaluate surfaces as 'error evaluating'."""
    # CATCHES: the inner navigation error is wrapped by the conditional
    # executor before the generic selector wrapper adds its own prefix.
    proc = run_dasel('if (a.b) {"y"}', '{"a": 1}')
    assert proc.returncode == 1
    assert proc.stdout == ""
    assert proc.stderr == (
        "dasel: error: error executing selector: execution error when "
        "processing ast.ConditionalExpr: error evaluating condition: "
        "execution error when processing ast.ChainedExpr: error executing "
        "expression: execution error when processing ast.PropertyExpr: "
        "unexpected type: expected map, got int\n"
    )
