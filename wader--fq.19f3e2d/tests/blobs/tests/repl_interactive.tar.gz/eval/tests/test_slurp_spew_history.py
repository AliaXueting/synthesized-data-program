"""slurp/spew globals and the history builtin plus its persisted file.

slurp("name") collects pipeline outputs into a global that spew re-emits,
$name reads, and completion offers.  history returns the session's lines
and the readline layer appends them to $XDG_CACHE_HOME/fq/history.
"""

import pytest

from conftest import history_path, run_fq

E = ["-i", "-o", "color=false"]


def test_slurp_needs_a_string_name():
    """slurp without an argument is an error."""
    # CATCHES: slurp without an argument is rejected with the exact usage
    # hint instead of slurping nothing.
    p = run_fq(E, stdin="1 | slurp\n")
    assert p.returncode == 0
    assert p.stdout == b'error: expr: slurp requires one string argument. ex: ... | slurp("name")\n'


@pytest.mark.parametrize(
    "arg, rendered",
    [
        pytest.param('"a-b"', b'"a-b"', id="hyphen"),
        pytest.param("123", b'"123"', id="number"),
    ],
)
def test_slurp_rejects_invalid_names(arg, rendered):
    """Non-identifier slurp names are rejected."""
    # CATCHES: the name must be an identifier, and the offending argument is
    # always rendered quoted in the error message, whatever its type.
    p = run_fq(E, stdin="1 | slurp(%s)\n" % arg)
    assert p.returncode == 0
    assert p.stdout == (
        b"error: expr: invalid slurp name %s, must be a valid identifier. "
        b'ex: ... | slurp("name")\n' % rendered
    )


def test_slurp_must_be_last():
    """slurp must terminate the pipeline."""
    # CATCHES: slurp terminates a pipeline, so piping further is an error
    # printed without the "expr:" prefix (a rewrite-level error).
    p = run_fq(E, stdin='1 | slurp("a") | 1\n')
    assert p.returncode == 0
    assert p.stdout == b'error: slurp must be last in pipeline. ex: ... | slurp("name")\n'


def test_spew_unknown_name_errors_but_repl_continues():
    """An unknown slurp name errors without stopping the REPL."""
    # CATCHES: spew of a name that was never slurped errors but the REPL
    # keeps going with the next line.
    p = run_fq(E, stdin='spew("nosuch")\n1+1\n')
    assert p.returncode == 0
    assert p.stdout == b"error: no such slurp: nosuch\n2\n"


def test_slurp_then_spew_outputs_the_values():
    """spew re-emits the collected outputs."""
    # CATCHES: spew("name") re-emits exactly the collected outputs, in
    # order and pretty printed.
    p = run_fq(E, stdin='{aa: 123} | slurp("test")\nspew("test")\n')
    assert p.returncode == 0
    assert p.stdout == b'{\n  "aa": 123\n}\n'


def test_slurped_values_bind_a_dollar_variable():
    """The slurp name binds a $variable holding the collected array."""
    # CATCHES: the slurp name becomes a $variable holding the array of
    # collected values.
    p = run_fq(E, stdin='{aa: 123} | slurp("test")\n$test\n')
    assert p.returncode == 0
    assert p.stdout == b'[\n  {\n    "aa": 123\n  }\n]\n'


def test_spew_without_argument_outputs_all_globals():
    """Bare spew dumps every global."""
    # CATCHES: bare spew dumps every global — $ARGS plus each slurped name
    # — as one pretty object.
    p = run_fq(E, stdin='{aa: 123} | slurp("test")\nspew\n')
    assert p.returncode == 0
    assert p.stdout == (
        b'{\n  "ARGS": {\n    "named": {},\n    "positional": []\n  },\n'
        b'  "test": [\n    {\n      "aa": 123\n    }\n  ]\n}\n'
    )


def test_two_slurps_keep_separate_names():
    """Multiple slurps coexist independently."""
    # CATCHES: several slurps coexist; each spew re-emits only its own
    # values.
    p = run_fq(E, stdin='1 | slurp("a")\n2 | slurp("b")\nspew("a")\nspew("b")\n')
    assert p.returncode == 0
    assert p.stdout == b"1\n2\n"


def test_spew_can_output_the_same_slurp_twice():
    """Spewing does not consume the slurp."""
    # CATCHES: spewing does not consume the slurp — the same name can be
    # re-emitted unchanged.
    p = run_fq(E, stdin='{aa: 123} | slurp("test")\nspew("test")\nspew("test")\n')
    assert p.returncode == 0
    assert p.stdout == b'{\n  "aa": 123\n}\n{\n  "aa": 123\n}\n'


def test_history_lists_session_lines(tmp_path):
    """history returns the session's lines in order."""
    # CATCHES: history returns the submitted lines in order, including
    # itself, as a JSON array of strings.
    p = run_fq(E, stdin="1+1\nhistory\n", home=tmp_path / "h")
    assert p.returncode == 0
    assert p.stdout == b'2\n[\n  "1+1",\n  "history"\n]\n'


def test_history_fresh_lists_only_itself(tmp_path):
    """A fresh session's history contains only the history line itself."""
    # CATCHES: in a brand-new session the only history entry is the
    # "history" line being submitted right now.
    p = run_fq(E, stdin="history\n", home=tmp_path / "h")
    assert p.returncode == 0
    assert p.stdout == b'[\n  "history"\n]\n'


def test_history_file_is_written_to_the_cache_dir(tmp_path):
    """Submitted lines are persisted under $XDG_CACHE_HOME/fq/history."""
    # CATCHES: on exit the readline layer writes each submitted line to
    # $XDG_CACHE_HOME/fq/history with jq-style quoting for the value lines.
    home = tmp_path / "h"
    p = run_fq(E, stdin='1+1\n"two"\n', home=home)
    assert p.returncode == 0
    assert p.stdout == b'2\n"two"\n'
    assert history_path(home).read_bytes() == b'1+1\n"two"\n'


def test_history_file_grows_across_runs(tmp_path):
    """A second run loads and extends the persisted history."""
    # CATCHES: a second run with the same HOME loads the persisted lines
    # into the session history and appends its own lines to the file.
    home = tmp_path / "h"
    first = run_fq(E, stdin='1+1\n"two"\n', home=home)
    assert first.returncode == 0
    second = run_fq(E, stdin="history\n", home=home)
    assert second.returncode == 0
    assert second.stdout == b'[\n  "1+1",\n  "\\"two\\"",\n  "history"\n]\n'
    assert history_path(home).read_bytes() == b'1+1\n"two"\nhistory\n'
