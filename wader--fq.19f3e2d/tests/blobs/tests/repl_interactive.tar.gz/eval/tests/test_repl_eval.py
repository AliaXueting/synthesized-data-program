"""Non-interactive REPL evaluation: stdin lines, input plumbing and help.

With stdin piped (no terminal) the ``-i``/``--repl`` REPL evaluates every
stdin line as a jq expression against the current input value and prints the
results, without prompts.  These tests pin the exact stdout/stderr bytes and
exit codes recorded from the reference binary.
"""

import pytest

from conftest import run_fq, write_file, write_mp3

# The argument prefix every recording in this module was made with.
E = ["-i", "-o", "color=false"]


def test_each_stdin_line_is_evaluated_in_order():
    """A piped stdin line is evaluated as jq and its result printed."""
    # CATCHES: pipe mode evaluates one expression per line and prints "2",
    # not a prompt/echo of the input.
    p = run_fq(E, stdin="1+1\n")
    assert p.returncode == 0
    assert p.stdout == b"2\n"
    assert p.stderr == b""


def test_value_kinds_are_pretty_printed():
    """Every JSON value kind renders through the REPL pretty printer."""
    # CATCHES: every JSON value kind renders with the exact pretty printer
    # (two-space indent, comma placement) used by the REPL.
    p = run_fq(E, stdin='[1,2,3]\n{a:1,bb:"x"}\n"a"\nnull\n1.5\ntrue\n')
    assert p.returncode == 0
    assert p.stdout == (
        b'[\n  1,\n  2,\n  3\n]\n'
        b'{\n  "a": 1,\n  "bb": "x"\n}\n'
        b'"a"\n'
        b"null\n"
        b"1.5\n"
        b"true\n"
    )
    assert p.stderr == b""


def test_one_line_can_emit_multiple_values():
    """A line producing a stream prints one value per line."""
    # CATCHES: a single line producing a stream prints one value per line
    # instead of collecting them.
    p = run_fq(E, stdin="1,2,3\n")
    assert p.returncode == 0
    assert p.stdout == b"1\n2\n3\n"


def test_empty_expression_emits_nothing():
    """The empty builtin outputs no value and no error."""
    # CATCHES: "empty" outputs no value at all, yet the run still succeeds.
    p = run_fq(E, stdin="empty\n")
    assert p.returncode == 0
    assert p.stdout == b""
    assert p.stderr == b""


def test_null_input_flag_feeds_value_stream():
    """-n with a stream expression feeds each value to the REPL lines."""
    # CATCHES: -n 1,2,3 makes the REPL input the three numbers, so ".+10"
    # maps over each of them.
    p = run_fq(E + ["-n", "1,2,3"], stdin=".+10\n")
    assert p.returncode == 0
    assert p.stdout == b"11\n12\n13\n"


def test_long_flag_form_matches_short():
    """--repl is the long form of -i and behaves identically."""
    # CATCHES: --repl is the spelled-out form of -i and behaves identically.
    p = run_fq(["--repl", "-o", "color=false"], stdin="1+1\n")
    assert p.returncode == 0
    assert p.stdout == b"2\n"
    assert p.stderr == b""


def test_compact_output_option():
    """-o compact=true makes the REPL print compactly."""
    # CATCHES: the compact option reaches the REPL printer, which normally
    # pretty prints.
    p = run_fq(E + ["-o", "compact=true"], stdin="[1,2,3]\n")
    assert p.returncode == 0
    assert p.stdout == b"[1,2,3]\n"


def test_compact_output_short_flag():
    """-c also switches the REPL to compact output."""
    # CATCHES: the generic -c flag also configures the REPL printer.
    p = run_fq(["-i", "-c", "-o", "color=false"], stdin="[1,2,3]\n")
    assert p.returncode == 0
    assert p.stdout == b"[1,2,3]\n"


def test_sub_repl_compact_option_array():
    """repl({compact: true}) renders arrays compactly in the sub-REPL."""
    # CATCHES: repl({compact: true}) applies the option object to the nested
    # REPL only.
    p = run_fq(E, stdin="[1,2,3] | repl({compact: true})\n.\n")
    assert p.returncode == 0
    assert p.stdout == b"[1,2,3]\n"


def test_sub_repl_compact_option_object():
    """Compact sub-REPL output omits spaces after colons and commas."""
    # CATCHES: compact rendering of nested structures has no spaces after
    # ":" or ",".
    p = run_fq(E, stdin="{a: 1, b: [2]} | repl({compact: true})\n.\n")
    assert p.returncode == 0
    assert p.stdout == b'{"a":1,"b":[2]}\n'


def test_sub_repl_unknown_option_is_ignored():
    """Unknown repl option keys are dropped silently."""
    # CATCHES: an unknown key in the repl options object is silently dropped
    # instead of erroring.
    p = run_fq(E, stdin="1 | repl({nope: true})\n")
    assert p.returncode == 0
    assert p.stdout == b""
    assert p.stderr == b""


def test_stdin_lines_are_expressions_not_json():
    """Piped stdin is jq code evaluated against the input value."""
    # CATCHES: piped stdin is jq code, not JSON input: {"a":1} is an object
    # construction expression evaluated against null.
    p = run_fq(E + ["."], stdin='{"a":1}\n')
    assert p.returncode == 0
    assert p.stdout == b'{\n  "a": 1\n}\n'


@pytest.mark.parametrize(
    "expr, stdin, expected",
    [
        pytest.param("[1,2,3]", "length\n", b"3\n", id="single-array"),
        pytest.param("1,2,3", ".*2\n", b"2\n4\n6\n", id="value-stream"),
    ],
)
def test_expression_argument_sets_repl_input(expr, stdin, expected):
    """The positional expression produces the REPL's input value(s)."""
    # CATCHES: the positional expression is evaluated to produce the REPL's
    # input value(s); each line is then applied per value.
    p = run_fq(E + [expr], stdin=stdin)
    assert p.returncode == 0
    assert p.stdout == expected
    assert p.stderr == b""


def test_repl_iterates_every_input_file(tmp_path):
    """Every file argument becomes an input value applied to each line."""
    # CATCHES: with two file arguments each typed line is evaluated once per
    # input value, so "1+1" prints 2 twice.
    mp3 = write_mp3(tmp_path)
    p = run_fq(E + [".", mp3, mp3], stdin="1+1\n")
    assert p.returncode == 0
    assert p.stdout == b"2\n2\n"
    assert p.stderr == b""


def test_help_without_topic():
    """Bare help prints the REPL cheat sheet."""
    # CATCHES: bare help prints the exact keybinding cheat sheet, including
    # the literal backslash-t for Tab.
    p = run_fq(E, stdin="help\n")
    assert p.returncode == 0
    assert p.stdout == (
        b"Type jq expression to evaluate\n"
        b'help(...)   Help for topic. Ex: help(mp4), help("mp4")\n'
        b"\\t          Completion\n"
        b"Up/Down     History\n"
        b"... | repl  Start a new REPL\n"
        b"^C          Interrupt execution\n"
        b"^D          Exit REPL\n"
    )
    assert p.stderr == b""


def test_help_must_be_alone_or_last():
    """help cannot be followed by more pipeline."""
    # CATCHES: "help | 1" is rejected with the exact pipeline-position rule.
    p = run_fq(E, stdin="help | 1\n")
    assert p.returncode == 0
    assert p.stdout == (
        b"error: help must be alone or last in pipeline. "
        b"ex: help(length) or ... | help\n"
    )


def test_help_of_a_value():
    """A value piped into help is described and then echoed."""
    # CATCHES: "1 | help" describes the piped value first and then repeats
    # the value itself.
    p = run_fq(E, stdin="1 | help\n")
    assert p.returncode == 0
    assert p.stdout == b'"value help"\n[\n  1\n]\n'


def test_help_unknown_topic():
    """An unknown help topic gets the don't-know line."""
    # CATCHES: unknown topics print a "don't know" line with a trailing
    # space and no "error:" prefix.
    p = run_fq(E, stdin="help(unknownzz)\n")
    assert p.returncode == 0
    assert p.stdout == b"don't know what unknownzz is \n"


def test_paste_in_pipe_mode_returns_empty():
    """paste without a terminal returns the empty string."""
    # CATCHES: paste without a terminal yields the empty string instead of
    # blocking or reading the remaining stdin lines.
    p = run_fq(E, stdin="paste\n")
    assert p.returncode == 0
    assert p.stdout == b'""\n'


def test_paste_does_not_swallow_following_lines():
    """Pipe-mode paste leaves the remaining stdin lines for the REPL."""
    # CATCHES: after pipe-mode paste returns "", the remaining stdin lines
    # are still evaluated as REPL input.
    p = run_fq(E, stdin="paste\ntest\nmore\n")
    assert p.returncode == 0
    assert p.stdout == (
        b'""\n'
        b"error: expr: function not defined: test/0\n"
        b"error: expr: function not defined: more/0\n"
    )


def test_undecodable_json_argument_is_rejected(tmp_path):
    """A file that cannot be probed aborts with rc 4 before the REPL starts."""
    # CATCHES: a file that cannot be probed aborts before the REPL starts,
    # with the "try fq -d FORMAT" hint naming the file.
    bad = write_file(tmp_path, "bad.json", b"{invalid")
    p = run_fq(E + [".", bad], stdin="1+1\n")
    assert p.returncode == 4
    assert p.stdout == b""
    assert p.stderr == (
        b"error: %s: probe: failed to decode: "
        b"try fq -d FORMAT to force format, see fq -h formats for list\n" % bad.encode()
    )
