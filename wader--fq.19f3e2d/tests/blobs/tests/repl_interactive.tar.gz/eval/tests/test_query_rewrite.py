"""Query AST parse/render round-trips (pkg/interp/query.jq + query.go).

``_query_fromstring`` parses a jq expression into the JSON AST the REPL
rewrites for trailing help/repl/slurp, and ``_query_tostring`` renders it
back through the gojq printer.  These tests pin the normalization the
renderer applies (spacing) and that unparseable queries fail as expression
errors.
"""

import pytest

from conftest import run_fq

ROUNDTRIP_CASES = [
    pytest.param("1+1", b'"1 + 1"\n', id="adds-spaces-around-operator"),
    pytest.param("1 + 1", b'"1 + 1"\n', id="already-normal-stays-stable"),
    pytest.param("def f: 1; f,f | repl", b'"def f: 1; f, f | repl"\n', id="def-and-comma"),
    pytest.param(".a.b[0]?", b'".a.b[0]?"\n', id="path-and-optional"),
    pytest.param("{a: 1, b: [2]}", b'"{ a: 1, b: [2] }"\n', id="object-braces"),
    pytest.param("reduce .[] as $x (0; .+$x)", b'"reduce .[] as $x (0; . + $x)"\n', id="reduce"),
]


@pytest.mark.parametrize("expr, expected", ROUNDTRIP_CASES)
def test_query_roundtrip_normalizes_rendering(expr, expected):
    """Query strings round-trip through the AST with canonical spacing."""
    # CATCHES: parse+render is the identity modulo canonical spacing
    # ("1+1" -> "1 + 1", ".+$x" -> ". + $x"), and optional/def/reduce
    # constructs survive the AST round-trip unchanged.
    p = run_fq(["-n", '"%s" | _query_fromstring | _query_tostring' % expr], stdin="1+1\n")
    assert p.returncode == 0
    assert p.stdout == expected
    assert p.stderr == b""


def test_unparseable_query_is_an_expression_error():
    """An unparseable query string fails as an expression error."""
    # CATCHES: a string that is not a valid query fails _query_fromstring
    # as an expression error (rc 5) with the raw parser message.
    p = run_fq(
        ["-n", '"help(abc;def)" | _query_fromstring | _query_tostring'],
        stdin="1+1\n",
    )
    assert p.returncode == 5
    assert p.stdout == b""
    assert p.stderr == b'error: unexpected token ")"\n'
