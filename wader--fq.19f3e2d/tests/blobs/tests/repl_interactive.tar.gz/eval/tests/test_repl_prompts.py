"""Interactive prompts: value preview, paths, sub-REPL levels and colors.

Every test here runs the candidate on a pseudo terminal (fixed 80x24) and
compares the normalized screen text — or, for the color tests, the raw byte
stream — against recordings of the reference binary.  ``^D`` alone exits a
top-level REPL, which is how each session ends.
"""

import pytest

from conftest import run_fq_pty, write_mp3

E = ["-i", "-o", "color=false"]

# (id, extra argv producing the input value, expected screen text)
VALUE_CASES = [
    pytest.param([], b"null> ^D\n", id="null"),
    pytest.param(["empty"], b"empty> ^D\n", id="empty"),
    pytest.param(["1"], b"number> ^D\n", id="number"),
    pytest.param(['"a"'], b"string> ^D\n", id="string"),
    pytest.param(["{a: 1}"], b"object> ^D\n", id="object"),
    pytest.param(["true"], b"boolean> ^D\n", id="boolean"),
    pytest.param(["[1,2,3]"], b"[number, ...][0:3]> ^D\n", id="array"),
    pytest.param(['[1,"a"]'], b"[number, ...][0:2]> ^D\n", id="mixed-array"),
    pytest.param(["1,2,3"], b"number, ...[0:3][]> ^D\n", id="stream"),
]


@pytest.mark.parametrize(
    "extra, expected",
    VALUE_CASES,
)
def test_prompt_reflects_the_input_value(tmp_path, extra, expected):
    """The prompt previews the current input value."""
    # CATCHES: the prompt is a live preview of the input value — its type
    # name, or a [preview, ...][range] summary for streams — not a fixed
    # "jq> " string.
    r = run_fq_pty(E + extra, [(b"\x04", 2.0)], home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.text == expected


@pytest.mark.parametrize(
    "extra, expected",
    [
        pytest.param([".", "MP3"], b"mp3> ^D\n", id="probed-mp3"),
        pytest.param(["-d", "bytes", ".", "MP3"], b"binary> ^D\n", id="forced-bytes"),
        pytest.param(["-d", "json", ".", "MP3"], b"json!> ^D\n", id="forced-json"),
    ],
)
def test_prompt_names_the_input_format(tmp_path, extra, expected):
    """The prompt names the (forced) decode format of the file input."""
    # CATCHES: the prompt shows the detected format name; a forced decode
    # that fails still starts the REPL but marks the value with "!".
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + [a if a != "MP3" else mp3 for a in extra], [(b"\x04", 3.0)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == expected


def test_prompt_summarizes_multiple_input_values(tmp_path):
    """Multiple inputs are summarized in the prompt and each line runs per input."""
    # CATCHES: two file inputs collapse into "mp3, ...[0:2][]" and every
    # typed line is evaluated once per pending input (two 2s for one 1+1).
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + [".", mp3, mp3], [(b"1+1\n", 2.5), (b"\x04", 2.0)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b"mp3, ...[0:2][]> 1+1\n2\n2\nmp3, ...[0:2][]> ^D\n"


def test_prompt_shows_path_and_format_of_expression_result(tmp_path):
    """The prompt shows the jq path and format of the startup expression's result."""
    # CATCHES: when the startup expression digs into a decoded value the
    # prompt shows its jq path plus the sub-format name.
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + ["-d", "mp3", ".headers[0]", mp3], [(b"\x04", 3.0)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b".headers[0] id3v2> ^D\n"


def test_sub_repl_prompt_prefix(tmp_path):
    """A sub-REPL prefixes its prompt with '> '."""
    # CATCHES: a nested REPL prefixes its prompt with "> " and returns to
    # the parent prompt after ^D.
    r = run_fq_pty(
        E, [(b"1 | repl\n", 2.0), (b"\x04", 1.5), (b"\x04", 1.5)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b"null> 1 | repl\n> number> ^D\nnull> ^D\n"


def test_sub_repl_level_two_prefix(tmp_path):
    """Each nesting level adds another '>' marker."""
    # CATCHES: each nesting level adds another "> " marker (>> at level 2)
    # and unwinds one level per ^D.
    r = run_fq_pty(
        E,
        [
            (b"1 | repl\n", 2.0),
            (b"2 | repl\n", 2.0),
            (b"\x04", 1.5),
            (b"\x04", 1.5),
            (b"\x04", 1.5),
        ],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> 1 | repl\n> number> 2 | repl\n>> number> ^D\n> number> ^D\nnull> ^D\n"
    )


def test_sub_repl_prompt_keeps_value_path(tmp_path):
    """Sub-REPL prompts render the value's path and format."""
    # CATCHES: inside a sub-REPL the prompt still renders the value's jq
    # path and format, not just its type.
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + [".", mp3],
        [(b".headers[0] | repl\n", 3.0), (b"\x04", 1.5), (b"\x04", 1.5)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == b"mp3> .headers[0] | repl\n> .headers[0] id3v2> ^D\nmp3> ^D\n"


def test_startup_eval_error_prints_before_the_prompt(tmp_path):
    """A startup evaluation error prints before the first prompt and exits 5."""
    # CATCHES: a failing startup evaluation prints "error: boom" before the
    # first prompt and makes the final exit code 5, but the REPL still runs.
    r = run_fq_pty(E + ['1, error("boom"), 3'], [(b"\x04", 2.0)], home=tmp_path / "h")
    assert r.exited and r.rc == 5
    assert r.text == b"error: boom\nnumber> ^D\n"


def test_line_error_keeps_repl_alive(tmp_path):
    """An erroring line keeps the REPL alive with exit code 0."""
    # CATCHES: an erroring line prints its earlier outputs (1), the error,
    # and the prompt returns with exit code 0.
    r = run_fq_pty(
        E, [(b'1, error("boom"), 3\n', 2.0), (b"\x04", 1.5)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b'null> 1, error("boom"), 3\n1\nerror: boom\nnull> ^D\n'


def test_terminal_output_is_colorized(tmp_path):
    """Terminal output colors the prompt and per-type results."""
    # CATCHES: on a terminal the prompt value is wrapped in reset-to-default
    # color codes and results are colored per type (cyan number, green
    # string), interleaved with the cursor-query handshake bytes.
    r = run_fq_pty(
        ["-i"],
        [(b"1+1\n", 2.0), (b'"x"\n', 2.0), (b"\x04", 1.5)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.raw == (
        b" \x08\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K1+1\r\n \x08"
        b"\x1b[36m2\x1b[m\r\n \x08"
        b"\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K\"x\"\r\n \x08"
        b'\x1b[32m"x"\x1b[m\r\n \x08'
        b"\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K^D\r\n \x08\x1b[1G\x1b[J"
    )


def test_no_color_env_disables_color_but_not_cursor_control(tmp_path):
    """NO_COLOR removes color codes but keeps cursor control."""
    # CATCHES: NO_COLOR strips the color codes only; the cursor-position
    # query and erase-to-EOL sequences are still emitted.
    r = run_fq_pty(
        ["-i"],
        [(b"1+1\n", 2.0), (b'"x"\n', 2.0), (b"\x04", 1.5)],
        home=tmp_path / "h",
        extra={"NO_COLOR": "1"},
    )
    assert r.exited and r.rc == 0
    assert r.raw == (
        b" \x08\x1b[6nnull> \x1b[0K1+1\r\n \x082\r\n \x08"
        b"\x1b[6nnull> \x1b[0K\"x\"\r\n \x08\"x\"\r\n \x08"
        b"\x1b[6nnull> \x1b[0K^D\r\n \x08\x1b[1G\x1b[J"
    )


def test_repl_color_option_enables_color_in_sub_repl(tmp_path):
    """repl({color: true}) colors only the nested REPL."""
    # CATCHES: repl({color: true}) turns colors on for the nested REPL only
    # — its "> " marker is dim (90) while the outer prompt stays plain.
    r = run_fq_pty(
        E,
        [(b"1 | repl({color: true})\n", 2.0), (b"\x04", 1.5), (b"\x04", 1.5)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.raw == (
        b" \x08\x1b[6nnull> \x1b[0K1 | repl({color: true})\r\n \x08 \x08"
        b"\x1b[6n\x1b[90m>\x1b[39m \x1b[39mnumber\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J \x08\x1b[6nnull> \x1b[0K^D\r\n \x08\x1b[1G\x1b[J"
    )


def test_prompt_colors_the_value_range_numbers(tmp_path):
    """Stream prompt slice numbers are cyan."""
    # CATCHES: in the stream prompt the slice numbers are cyan while the
    # type name and brackets keep the default color.
    r = run_fq_pty(["-i", "1,2,3"], [(b"\x04", 2.0)], home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.raw == (
        b" \x08\x1b[6n"
        b"\x1b[39mnumber\x1b[39m, ...\x1b[39m[\x1b[39m"
        b"\x1b[36m0\x1b[39m:\x1b[36m3\x1b[39m"
        b"\x1b[39m]\x1b[39m[]> \x1b[0K^D\r\n \x08\x1b[1G\x1b[J"
    )


def test_prompt_colors_the_object_path_keys(tmp_path):
    """Path prompt keys are bright blue and indexes cyan."""
    # CATCHES: in a path prompt the object key is bright blue (94) and the
    # array index cyan, with default-colored separators.
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        ["-i", "-d", "mp3", ".headers[0]", mp3], [(b"\x04", 3.0)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.raw == (
        b" \x08\x1b[6n"
        b".\x1b[94mheaders\x1b[39m\x1b[39m[\x1b[39m"
        b"\x1b[36m0\x1b[39m\x1b[39m]\x1b[39m \x1b[39mid3v2\x1b[39m> "
        b"\x1b[0K^D\r\n \x08\x1b[1G\x1b[J"
    )
