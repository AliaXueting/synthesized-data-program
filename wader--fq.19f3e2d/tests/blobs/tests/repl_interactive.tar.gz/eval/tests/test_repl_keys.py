"""Interactive keybindings: ^C/^D, history walking, editing and paste.

Each test drives the pseudo terminal with the exact keystroke chunks a user
would press and asserts the full normalized screen (echo, carets, bells and
prompt redraws included) plus the exit code.  ``\x03`` is Ctrl-C, ``\x04``
Ctrl-D, ``\x01`` Ctrl-A, ``\x1b[A``/``\x1b[B`` the Up/Down arrows.
"""

import pytest

from conftest import history_path, run_fq_pty

E = ["-i", "-o", "color=false"]


def test_enter_evaluates_and_prints_result(tmp_path):
    """Enter evaluates the line and prints the result."""
    # CATCHES: submitted lines are echoed, evaluated and the result printed
    # before the prompt redraws.
    r = run_fq_pty(E, [(b"1+1\n", 2.0), (b"\x04", 1.5)], home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.text == b"null> 1+1\n2\nnull> ^D\n"


def test_ctrl_c_on_empty_line_redisplays_prompt(tmp_path):
    """^C on an empty line redraws the prompt."""
    # CATCHES: ^C on an empty line clears nothing but still redraws the
    # prompt with a ^C echo and keeps the REPL alive.
    r = run_fq_pty(
        E, [(b"\x03", 1.5), (b"1+1\n", 2.0), (b"\x04", 1.5)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b"null> null> ^C\nnull> 1+1\n2\nnull> ^D\n"


def test_ctrl_c_discards_typed_text(tmp_path):
    """^C abandons the typed line without evaluating it."""
    # CATCHES: ^C with text on the line abandons the whole line ("abc" is
    # never evaluated) and the next line starts fresh.
    r = run_fq_pty(
        E,
        [(b"abc", 1.0), (b"\x03", 1.5), (b"1+1\n", 2.0), (b"\x04", 1.5)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == b"null> abcnull> abc^C\nnull> 1+1\n2\nnull> ^D\n"


def test_ctrl_c_interrupts_running_evaluation(tmp_path):
    """^C during evaluation delivers SIGINT and the REPL survives."""
    # CATCHES: ^C while an expression is evaluating delivers SIGINT — the
    # multi-second reduce is cut short, no partial result prints, and the
    # REPL continues with exit code 0.
    r = run_fq_pty(
        E,
        [
            (b"reduce range(1000000000) as $i (0; .+$i)\n", 2.0, 1.0),
            (b"\x03", 2.0),
            (b"1+1\n", 2.0),
            (b"\x04", 1.5),
        ],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> reduce range(1000000000) as $i (0; .+$i)\n"
        b"^Cnull> 1+1\n2\nnull> ^D\n"
    )


def test_ctrl_d_exits_the_top_level_repl(tmp_path):
    """A bare ^D exits the top-level REPL cleanly."""
    # CATCHES: a bare ^D on an empty line is EOF and exits cleanly (rc 0)
    # rather than being inserted or ringing the bell.
    r = run_fq_pty(E, [(b"\x04", 2.0)], home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.text == b"null> ^D\n"


def test_ctrl_d_bells_when_line_is_not_empty(tmp_path):
    """^D with text on the line bells instead of exiting."""
    # CATCHES: ^D with text on the line is a forward delete that fails at
    # end of line — it bells, keeps the text, and the line evaluates.
    r = run_fq_pty(
        E,
        [(b"abc", 1.0), (b"\x04", 1.0), (b"\r", 2.0), (b"\x04", 1.5)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> abcnull> abc\x07\n"
        b"error: expr: function not defined: abc/0\nnull> ^D\n"
    )


def test_ctrl_c_stays_inside_sub_repl(tmp_path):
    """^C inside a sub-REPL clears only that REPL's line."""
    # CATCHES: ^C inside a nested REPL clears that REPL's line only; one
    # ^D per level is still needed to get back to the top.
    r = run_fq_pty(
        E,
        [(b"1 | repl\n", 2.0), (b"\x03", 1.5), (b"\x04", 1.5), (b"\x04", 1.5)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == b"null> 1 | repl\n> number> > number> ^C\n> number> ^D\nnull> ^D\n"


def test_up_arrow_recalls_the_previous_line(tmp_path):
    """Up recalls and Enter resubmits the previous line."""
    # CATCHES: Up recalls the last submitted line verbatim and Enter
    # re-evaluates it without retyping.
    r = run_fq_pty(
        E,
        [(b"1+1\n", 2.0), (b"\x1b[A", 1.2), (b"\r", 2.0), (b"\x04", 1.5)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == b"null> 1+1\n2\nnull> null> 1+1\n2\nnull> ^D\n"


def test_up_arrow_without_history_bells(tmp_path):
    """Up with no history bells and recalls nothing."""
    # CATCHES: Up with an empty history rings the bell and leaves the line
    # empty — nothing is recalled or evaluated.
    r = run_fq_pty(
        E, [(b"\x1b[A", 1.5), (b"1+1\n", 2.0), (b"\x04", 1.5)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b"null> \x071+1\n2\nnull> ^D\n"


def test_history_walks_back_then_forward(tmp_path):
    """Up/Down walk the history list in both directions."""
    # CATCHES: two Ups walk past "2+2" to "1+1", a Down steps forward again
    # and Enter submits "2+2" (result 4).
    r = run_fq_pty(
        E,
        [
            (b"1+1\n", 1.5),
            (b"2+2\n", 1.5),
            (b"\x1b[A", 1.2),
            (b"\x1b[A", 1.2),
            (b"\x1b[B", 1.2),
            (b"\r", 2.0),
            (b"\x04", 1.5),
        ],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> 1+1\n2\nnull> 2+2\n4\n"
        b"null> null> 2+2null> 1+1null> 2+2\n4\nnull> ^D\n"
    )


def test_empty_line_submits_without_evaluation(tmp_path):
    """Enter on an empty line evaluates nothing."""
    # CATCHES: Enter on an empty line prints nothing at all — not even a
    # null — and just redisplays the prompt.
    r = run_fq_pty(
        E, [(b"\n", 1.2), (b"1+1\n", 2.0), (b"\x04", 1.5)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b"null> \nnull> 1+1\n2\nnull> ^D\n"


def test_ctrl_a_moves_cursor_to_line_start(tmp_path):
    """Ctrl-A moves the cursor so new text prefixes the line."""
    # CATCHES: Ctrl-A jumps to column 0 so subsequently typed text is
    # inserted before the existing line ("0+1+1" evaluates to 2).
    r = run_fq_pty(
        E,
        [
            (b"1+1", 1.0),
            (b"\x01", 1.0),
            (b"0+", 1.0),
            (b"\r", 2.0),
            (b"\x04", 1.5),
        ],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> 1+1null> 1+1null> 01+1null> 0+1+1null> 0+1+1\n2\nnull> ^D\n"
    )


def test_paste_collects_lines_until_ctrl_d(tmp_path):
    """paste echoes lines until ^D and evaluates to one string."""
    # CATCHES: paste echoes the raw typed lines, ends at ^D, and evaluates
    # to a single JSON string with escaped newlines.
    r = run_fq_pty(
        E,
        [
            (b"paste\n", 2.0, 0.3),
            (b"hello\nworld\n", 1.5),
            (b"\x04", 2.0),
            (b"\x04", 1.5),
        ],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == b'null> paste\nhello\nworld\n"hello\\nworld\\n"\nnull> ^D\n'


def test_paste_of_nothing_is_the_empty_string(tmp_path):
    """An immediately ended paste yields the empty string."""
    # CATCHES: paste ended immediately by ^D yields "" and the REPL carries
    # on with the next line.
    r = run_fq_pty(
        E,
        [
            (b"paste\n", 2.0, 0.3),
            (b"\x04", 2.0),
            (b"1+1\n", 2.0),
            (b"\x04", 1.5),
        ],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == b'null> paste\n""\nnull> 1+1\n2\nnull> ^D\n'


def test_history_builtin_lists_session_lines(tmp_path):
    """The history builtin lists the session's submitted lines."""
    # CATCHES: the history builtin returns every submitted line of the
    # current session, including the "history" line itself.
    r = run_fq_pty(
        E, [(b"1+1\n", 2.0), (b"history\n", 2.0), (b"\x04", 1.5)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b'null> 1+1\n2\nnull> history\n[\n  "1+1",\n  "history"\n]\nnull> ^D\n'


def test_help_prints_keybinding_overview(tmp_path):
    """help prints the keybinding overview on a terminal."""
    # CATCHES: on a terminal the help text arrives as whole lines through
    # the readline writer, identical to pipe mode.
    r = run_fq_pty(E, [(b"help\n", 2.0), (b"\x04", 1.5)], home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> help\n"
        b"Type jq expression to evaluate\n"
        b'help(...)   Help for topic. Ex: help(mp4), help("mp4")\n'
        b"\\t          Completion\n"
        b"Up/Down     History\n"
        b"... | repl  Start a new REPL\n"
        b"^C          Interrupt execution\n"
        b"^D          Exit REPL\n"
        b"null> ^D\n"
    )


def test_history_survives_restart(tmp_path):
    """History persists across process restarts via the cache file."""
    # CATCHES: readline persists history in $XDG_CACHE_HOME/fq/history, so
    # a fresh process recalls the previous session's line with Up (and the
    # resubmitted duplicate is not written twice).
    home = tmp_path / "persist"
    first = run_fq_pty(E, [(b"111+1\n", 2.0), (b"\x04", 1.5)], home=home)
    assert first.exited and first.rc == 0
    assert first.text == b"null> 111+1\n112\nnull> ^D\n"
    assert history_path(home).read_bytes() == b"111+1\n"
    second = run_fq_pty(
        E, [(b"\x1b[A", 1.5), (b"\r", 2.0), (b"\x04", 1.5)], home=home
    )
    assert second.exited and second.rc == 0
    assert second.text == b"null> null> 111+1\n112\nnull> ^D\n"
    assert history_path(home).read_bytes() == b"111+1\n"
