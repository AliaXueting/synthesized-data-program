"""REPL error taxonomy and exit codes in pipe mode.

Pins where each error class is printed (stdout vs stderr), that the REPL
survives line errors, and which situations set a non-zero exit code: input
io errors (2), compile errors in the startup expression (3), a failing
startup evaluation (5), option/env init errors (1) and a missing HOME (5).
"""

import pytest

from conftest import run_fq, write_file, write_mp3

E = ["-i", "-o", "color=false"]


def test_undefined_function_error_then_recovery():
    """An undefined function errors on stdout and the next line still runs."""
    # CATCHES: a failing line prints "error: expr: ..." on stdout and the
    # next line still evaluates.
    p = run_fq(E, stdin="abc\n1+1\n")
    assert p.returncode == 0
    assert p.stdout == b"error: expr: function not defined: abc/0\n2\n"
    assert p.stderr == b""


def test_runtime_type_error_message():
    """A type error prints the exact operand description."""
    # CATCHES: runtime errors use the exact "cannot add" wording with the
    # operand rendering.
    p = run_fq(E, stdin='1+"a"\n')
    assert p.returncode == 0
    assert p.stdout == b'error: cannot add: number (1) and string ("a")\n'
    assert p.stderr == b""


def test_parse_error_caret_underlines_token():
    """Parse errors draw a caret at the offending column."""
    # CATCHES: parse errors print a caret line indented to the offending
    # column (prompt width + token column - 1).
    p = run_fq(E, stdin=")\n1+1\n")
    assert p.returncode == 0
    assert p.stdout == b'      ^ unexpected token ")"\n2\n'
    assert p.stderr == b""


def test_parse_error_at_eof_caret():
    """An unexpected EOF caret points past the end of the line."""
    # CATCHES: an unexpected EOF caret points one column past the end of
    # the incomplete line.
    p = run_fq(E, stdin="1 +\n")
    assert p.returncode == 0
    assert p.stdout == b"        ^ unexpected EOF\n"
    assert p.stderr == b""


def test_exit_code_stays_zero_when_the_last_line_fails():
    """Line-level errors do not change the exit code."""
    # CATCHES: line-level errors never change the exit code; only a failing
    # startup evaluation does (see test below).
    p = run_fq(E, stdin="1+1\nabc\n")
    assert p.returncode == 0
    assert p.stdout == b"2\nerror: expr: function not defined: abc/0\n"


def test_startup_eval_error_goes_to_stderr_and_sets_rc5():
    """A failing startup expression prints to stderr and exits 5."""
    # CATCHES: when the expression argument itself errors at startup, the
    # message lands on stderr (unlike line errors) and the exit code is 5,
    # yet stdin lines still evaluate.
    p = run_fq(E + ['1, error("boom"), 3'], stdin="1+1\n")
    assert p.returncode == 5
    assert p.stdout == b"2\n"
    assert p.stderr == b"error: boom\n"


def test_startup_undefined_function_is_compile_error():
    """An undefined function in the startup expression exits 3."""
    # CATCHES: an unknown function in the startup expression is a compile
    # error (rc 3) and no REPL runs at all.
    p = run_fq(E + ["abc"], stdin="1+1\n")
    assert p.returncode == 3
    assert p.stdout == b""
    assert p.stderr == b"error: arg: function not defined: abc/0\n"


def test_ctrl_c_discards_rest_of_line():
    """^C in a piped line discards the rest of the line."""
    # CATCHES: in pipe mode ^C clears the line so only "cd" after the ^C
    # survives to be evaluated.
    p = run_fq(E, stdin="ab\x03cd\n1+1\n")
    assert p.returncode == 0
    assert p.stdout == b"error: expr: function not defined: cd/0\n2\n"


def test_ctrl_d_deletes_forward_and_bells_at_eol():
    """^D at end of line bells and keeps the text."""
    # CATCHES: ^C's sibling ^D is a forward delete; at end of line it fails
    # with a bell and the line keeps every character.
    p = run_fq(E, stdin="ab\x04cd\n1+1\n")
    assert p.returncode == 0
    assert p.stdout == b"\x07error: expr: function not defined: abcd/0\n2\n"


@pytest.mark.parametrize(
    "stdin",
    [
        pytest.param("1+\t1\n", id="tab-mid-line"),
        pytest.param("\t\n1+1\n", id="tab-alone"),
    ],
)
def test_tab_rings_bell_in_pipe_mode(stdin):
    """Tab without a terminal only rings the bell."""
    # CATCHES: Tab completion without a terminal only emits the bell byte
    # and the line still evaluates normally.
    p = run_fq(E, stdin=stdin)
    assert p.returncode == 0
    assert p.stdout == b"\x072\n"
    assert p.stderr == b""


def test_missing_input_file_is_io_error():
    """A missing file argument exits 2 with an io error."""
    # CATCHES: a missing file argument is an input io error (rc 2) on
    # stderr and the REPL never starts.
    p = run_fq(E + [".", "nofile.mp3"], stdin="1+1\n")
    assert p.returncode == 2
    assert p.stdout == b""
    assert p.stderr == b"error: nofile.mp3: no such file or directory\n"


def test_compile_error_in_expression_argument(tmp_path):
    """A compile error in the startup expression exits 3."""
    # CATCHES: a compile error in the startup expression (here forced decode
    # with an undefined function) exits 3 without evaluating stdin.
    mp3 = write_mp3(tmp_path)
    p = run_fq(["-i", "-o", "color=false", "-d", "bytes", "_len", mp3], stdin="1+1\n")
    assert p.returncode == 3
    assert p.stdout == b""
    assert p.stderr == b"error: arg: function not defined: _len/0\n"


def test_repl_outside_repl_is_compile_error():
    """repl outside the REPL is a compile error."""
    # CATCHES: "repl" in a plain (non -i) run is rejected at compile time
    # with the exact "can only be used from interactive repl" wording.
    p = run_fq(["-n", "repl"], stdin="1+1\n")
    assert p.returncode == 3
    assert p.stdout == b""
    assert p.stderr == b"error: arg: repl can only be used from interactive repl\n"


def test_slurp_outside_repl_is_compile_error():
    """slurp outside the REPL is a compile error."""
    # CATCHES: slurp gets the same interactive-only guard as repl.
    p = run_fq(["-n", '1 | slurp("a")'], stdin="1+1\n")
    assert p.returncode == 3
    assert p.stdout == b""
    assert p.stderr == b"error: arg: slurp can only be used from interactive repl\n"


def test_spew_outside_repl_prints_globals():
    """spew outside the REPL dumps the globals object."""
    # CATCHES: spew is allowed outside the REPL and dumps the global object
    # (just $ARGS here) as pretty JSON.
    p = run_fq(["-n", "spew"], stdin="1+1\n")
    assert p.returncode == 0
    assert p.stdout == b'{\n  "ARGS": {\n    "named": {},\n    "positional": []\n  }\n}\n'
    assert p.stderr == b""


def test_spew_unknown_name_outside_repl():
    """An unknown slurp name outside the REPL exits 5."""
    # CATCHES: naming an unknown slurp outside the REPL is an expression
    # error (rc 5).
    p = run_fq(["-n", 'spew("a")'], stdin="1+1\n")
    assert p.returncode == 5
    assert p.stdout == b""
    assert p.stderr == b"error: no such slurp: a\n"


def test_repl_must_be_last_in_pipeline():
    """repl must terminate the pipeline."""
    # CATCHES: "repl | 1" is rejected because repl must terminate a
    # pipeline.
    p = run_fq(E, stdin="repl | 1\n")
    assert p.returncode == 0
    assert p.stdout == b"error: repl must be last in pipeline. ex: ... | repl\n"


def test_repl_options_must_be_object():
    """repl's options argument must be an object."""
    # CATCHES: repl(123) fails at runtime with the options-type message.
    p = run_fq(E, stdin="1 | repl(123)\n")
    assert p.returncode == 0
    assert p.stdout == b"error: expr: options must be an object\n"


def test_repl_arity_error():
    """repl accepts none or one argument."""
    # CATCHES: repl takes none or one argument; two gives the exact usage
    # message with an options example.
    p = run_fq(E, stdin="repl(1;2)\n")
    assert p.returncode == 0
    assert p.stdout == (
        b"error: expr: repl requires none or one options argument. "
        b"ex: ... | repl or ... | repl({compact: true})\n"
    )


def test_invalid_completion_timeout_env():
    """A non-numeric COMPLETION_TIMEOUT is an init error."""
    # CATCHES: COMPLETION_TIMEOUT must parse as a number; a bad value is an
    # init error (rc 1) with the raw tonumber message on stderr.
    p = run_fq(E, stdin="1+1\n", extra={"COMPLETION_TIMEOUT": "abc"})
    assert p.returncode == 1
    assert p.stdout == b""
    assert p.stderr == b'tonumber cannot be applied to "abc": invalid number\n'


def test_missing_home_is_fatal():
    """Without HOME or XDG_CACHE_HOME the REPL cannot start."""
    # CATCHES: without $HOME or $XDG_CACHE_HOME the REPL cannot find its
    # cache dir and dies with rc 5 before evaluating anything.
    p = run_fq(E, stdin="1+1\n", env={"PATH": "/usr/bin:/bin", "LANG": "C"})
    assert p.returncode == 5
    assert p.stdout == b""
    assert p.stderr == b"error: neither $XDG_CACHE_HOME nor $HOME are defined\n"
