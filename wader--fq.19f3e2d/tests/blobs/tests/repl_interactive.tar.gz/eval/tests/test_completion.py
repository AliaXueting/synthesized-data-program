"""Tab completion: candidates, insertion, listings and bells.

Every test presses Tab (``\t``) on a pseudo terminal and asserts the whole
normalized screen, which pins which candidates are offered, whether the
single candidate is inserted directly, whether only the shared prefix is
extended (with a bell), and whether the candidates are listed inline or in
columns.  Sessions end with ``\x03\x03\x04``: the first ^C leaves
completion-listing mode, the second clears the line, and ^D then exits.
"""

import pytest

from conftest import run_fq_pty, write_mp3

E = ["-i", "-o", "color=false"]


def test_tab_lists_matching_functions_in_columns(tmp_path):
    """Many matches are listed in fixed-width columns."""
    # CATCHES: "he" matches many functions, so they are listed in fixed
    # 13-character columns (80-column terminal) instead of being inserted.
    r = run_fq_pty(E, [(b"he\t", 2.5), (b"\x03\x03\x04", 2.0)], home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> he\n"
        b"heif         help         hevc_annexb  hevc_au      hevc_dcr     hevc_nalu    \n"
        b"hevc_pps     hevc_sps     hevc_vps     hex          hexdump      "
        b"null> henull> he^C\nnull> ^D\n"
    )


def test_tab_inserts_the_single_candidate(tmp_path):
    """A single match is inserted without any listing."""
    # CATCHES: with exactly one match ("_is_ident" for "_is_ide") the name
    # is inserted with no listing, and the completed line evaluates.
    r = run_fq_pty(
        E, [(b"_is_ide\t", 2.0), (b"\r", 2.0), (b"\x04", 1.5)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b"null> _is_identnull> _is_ident\nfalse\nnull> ^D\n"


def test_tab_extends_shared_prefix_and_bells(tmp_path):
    """A shared prefix is extended with a bell and no listing."""
    # CATCHES: several matches sharing a longer prefix ("co" of color/colors/
    # compact/completion_timeout) only extend the line and ring the bell —
    # no listing appears on the first Tab.
    r = run_fq_pty(
        E, [(b"options.c\t", 2.0), (b"\x03\x03\x04", 2.0)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> options.co\x07null> options.conull> options.co^C\nnull> null> ^C\nnull> ^D\n"
    )


def test_second_tab_lists_the_candidates(tmp_path):
    """Tab twice lists the candidates after the prefix completion."""
    # CATCHES: pressing Tab again after the shared-prefix completion prints
    # the padded candidate list before redrawing the line.
    r = run_fq_pty(
        E, [(b"options.c\t\t", 2.5), (b"\x03\x03\x04", 2.0)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> options.co\x07null> options.co\n"
        b"color              colors             compact            completion_timeout "
        b"null> options.conull> options.co^C\nnull> ^D\n"
    )


def test_tab_lists_object_keys_inline(tmp_path):
    """Few object-key matches are listed inline."""
    # CATCHES: object keys of the piped value are listed inline (few
    # candidates, no columns) with the already-typed "a" prefix kept.
    r = run_fq_pty(
        E,
        [(b'{aa: 123, ab: "a"} | .a\t', 2.5), (b"\x03\x03\x04", 2.0)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b'null> {aa: 123, ab: "a"} | .a\n'
        b"aa ab "
        b'null> {aa: 123, ab: "a"} | .anull> {aa: 123, ab: "a"} | .a^C\nnull> ^D\n'
    )


def test_tab_completes_nested_object_keys(tmp_path):
    """Completion reaches keys of nested objects in the pipeline."""
    # CATCHES: completion looks through the whole pipeline expression and
    # offers keys of the nested object reached via ".a.a".
    r = run_fq_pty(
        E,
        [(b"{a: {aa: 1, ab: 2}} | .a.a\t", 2.5), (b"\x03\x03\x04", 2.0)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> {a: {aa: 1, ab: 2}} | .a.a\n"
        b"aa ab "
        b"null> {a: {aa: 1, ab: 2}} | .a.anull> {a: {aa: 1, ab: 2}} | .a.a^C\n"
        b"null> ^D\n"
    )


def test_tab_lists_variables(tmp_path):
    """$ alone lists the predefined variables."""
    # CATCHES: "$" alone lists the predefined variables, padded to equal
    # width, with no insertion.
    r = run_fq_pty(E, [(b"$\t", 2.0), (b"\x03\x03\x04", 2.0)], home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.text == b"null> $\n$ARGS $ENV  null> $null> $^C\nnull> ^D\n"


def test_slurped_variable_joins_variable_completion(tmp_path):
    """A slurped global appears among the $ completions."""
    # CATCHES: after slurp("test") the collected global appears among the
    # "$" completions alongside $ARGS and $ENV.
    r = run_fq_pty(
        E,
        [
            (b'{aa: 123} | slurp("test")\n', 2.0),
            (b"$\t", 2.0),
            (b"\x03\x03\x04", 2.0),
        ],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b'null> {aa: 123} | slurp("test")\n'
        b"null> $\n$ARGS $ENV  $test null> $null> $^C\nnull> ^D\n"
    )


@pytest.mark.parametrize(
    "steps, expected",
    [
        pytest.param(
            [(b'{aa: 123} | slurp("test")\n', 2.0), (b"$test[].a\t", 2.0), (b"\x03\x03\x04", 2.0)],
            b'null> {aa: 123} | slurp("test")\n'
            b"null> $test[].aanull> $test[].aanull> $test[].aa^C\nnull> null> ^C\nnull> ^D\n",
            id="slurped-variable-keys",
        ),
        pytest.param(
            [(b"{bb: 123} as $aa | $aa.b\t", 2.0), (b"\x03\x03\x04", 2.0)],
            b"null> {bb: 123} as $aa | $aa.bbnull> {bb: 123} as $aa | $aa.bb"
            b"null> {bb: 123} as $aa | $aa.bb^C\nnull> null> ^C\nnull> ^D\n",
            id="as-bound-variable-keys",
        ),
    ],
)
def test_tab_completes_variable_value_keys(tmp_path, steps, expected):
    """$name. completion inserts the variable's object key."""
    # CATCHES: "$name." completion evaluates the variable (slurped or
    # as-bound) and appends its single matching object key "bb"/"aa"
    # directly to the line.
    r = run_fq_pty(E, steps, home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.text == expected


@pytest.mark.parametrize(
    "line",
    [
        pytest.param(b".\t", id="dot-on-null"),
        pytest.param(b"def zzz: 1; zz\t", id="def-scoped-function"),
    ],
)
def test_tab_bells_when_nothing_matches(tmp_path, line):
    """No candidates means just a bell."""
    # CATCHES: "." against null input offers no keys (internals are hidden)
    # and a def-scoped function is invisible to completion — both just bell
    # and leave the line untouched.
    r = run_fq_pty(E, [(line, 2.0), (b"\x03\x03\x04", 2.0)], home=tmp_path / "h")
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> %s\x07null> %snull> %s^C\nnull> null> ^C\nnull> ^D\n"
        % (line[:-1], line[:-1], line[:-1])
    )


def test_tab_completes_keywords(tmp_path):
    """Keywords complete like functions."""
    # CATCHES: "red" completes to the keyword "reduce" (not a function),
    # and submitting it yields the caret-style unexpected-EOF parse error.
    r = run_fq_pty(
        E, [(b"red\t", 2.0), (b"\r", 2.0), (b"\x04", 1.5)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"null> reducenull> reduce\n           ^ unexpected EOF\nnull> ^D\n"
    )


def test_tab_lists_decoded_value_keys_inline(tmp_path):
    """Value keys of a decoded file input are listed inline."""
    # CATCHES: for an mp3 input ".f" lists the value's own keys (footers,
    # frames) inline — completion is context-sensitive to the input value.
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + [".", mp3], [(b".f\t", 3.0), (b"\x03\x03\x04", 2.0)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b"mp3> .f\nfooters frames  mp3> .fmp3> .f^C\nmp3> ^D\n"


def test_tab_lists_internal_keys_with_underscore(tmp_path):
    """A _ prefix lists the internal value keys in columns."""
    # CATCHES: a "_" prefix reveals the internal _-prefixed value keys,
    # listed in columns exactly like regular functions.
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + [".", mp3], [(b"._\t", 3.0), (b"\x03\x03\x04", 2.0)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"mp3> ._\n"
        b"_actual      _bits        _buffer_root _bytes       _description _error       \n"
        b"_format      _format_root _gap         _index       _len         _name        \n"
        b"_out         _parent      _path        _root        _start       _stop        \n"
        b"_sym         mp3> ._mp3> ._^C\nmp3> ^D\n"
    )


def test_tab_appends_index_brackets_for_arrays(tmp_path):
    """Array fields complete with [] appended."""
    # CATCHES: when every candidate is an array field, the completion
    # inserts ".frames[]" — appending the index brackets — with no listing.
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + [".", mp3], [(b".frames\t", 3.0), (b"\x03\x04", 2.0)], home=tmp_path / "h"
    )
    assert r.exited and r.rc == 0
    assert r.text == b"mp3> .frames[]mp3> .frames[]mp3> .frames[]^C\nmp3> ^D\n"


def test_tab_completed_array_index_evaluates(tmp_path):
    """The inserted .frames[] evaluates to the full hexdump."""
    # CATCHES: submitting the inserted ".frames[]" hexdumps every frame of
    # the fixture (three mp3_frame values with xing tags and crcs).
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + [".", mp3], [(b".frames\t", 3.0), (b"\r", 3.0), (b"\x04", 1.5)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b'mp3> .frames[]mp3> .frames[]\n'
        b'    |00 01 02 03 04 05 06 07 08 09|0123456789|.frames[0]{}: frame (mp3_frame)\n'
        b'0x28|               ff fb 40 c0   |     ..@. |  header{}:\n'
        b'0x28|                           00|         .|  side_info{}:\n'
        b'0x32|00 00 00 00 00 00 00 00 00 00|..........|\n'
        b'0x3c|00 00 00 00 00 00            |......    |\n'
        b'    |00 01 02 03 04 05 06 07 08 09|0123456789|\n'
        b'0x3c|                  49 6e 66 6f|      Info|  tag{}: (mp3_frame_xing)\n'
        b'0x46|00 00 00 0f 00 00 00 02 00 00|..........|\n'
        b'*   |until 0xdd.7 (156)           |          |\n'
        b'0xdc|      00 00 00 00 00         |  .....   |  audio_data: raw bits\n'
        b'    |                             |          |  crc_calculated: "827a" (raw bits)\n'
        b'     |00 01 02 03 04 05 06 07 08 09|0123456789|.frames[1]{}: frame (mp3_frame)\n'
        b'0x0dc|                     ff fb 50|       ..P|  header{}:\n'
        b'0x0e6|c4                           |.         |\n'
        b'0x0e6|   00 00 0a 2c 43 2e 55 94 80| ...,C.U..|  side_info{}:\n'
        b"0x0f0|01 80 93 6b 27 30 80 00      |...k'0..  |\n"
        b'0x0f0|                        07 aa|        ..|  audio_data: raw bits\n'
        b'0x0fa|c3 8e 33 85 d3 64 f1 a1 c1 08|..3..d....|\n'
        b'*    |until 0x1b2.7 (187)          |          |\n'
        b'     |                             |          |  crc_calculated: "e5b0" (raw bits)\n'
        b'     |00 01 02 03 04 05 06 07 08 09|0123456789|.frames[2]{}: frame (mp3_frame)\n'
        b'0x1ae|               ff fb 52 c4   |     ..R. |  header{}:\n'
        b'0x1ae|                           04|         .|  side_info{}:\n'
        b'0x1b8|83 c9 14 39 29 3c c3 00 00 00|...9)<....|\n'
        b'0x1c2|00 34 80 00 00 04            |.4....    |\n'
        b'0x1c2|                  11 4b 36 4a|      .K6J|  audio_data: raw bits\n'
        b'0x1cc|08 83 58 c9 20 d4 29 52 98 c8|..X. .)R..|\n'
        b'*    |until 0x283.7 (end) (188)    |          |\n'
        b'     |                             |          |  crc_calculated: "61fd" (raw bits)\n'
        b'mp3> ^D\n'
    )


def test_completion_works_inside_sub_repl(tmp_path):
    """Completion works inside a sub-REPL."""
    # CATCHES: inside a sub-REPL over ".headers[0]", Tab inserts ".header"
    # (the single key of the id3v2 value), and ^C/^D unwind the levels.
    mp3 = write_mp3(tmp_path)
    r = run_fq_pty(
        E + [".", mp3],
        [
            (b".headers[0] | repl\n", 3.0),
            (b".he\t", 2.0),
            (b"\x03\x04", 2.0),
            (b"\x04", 1.5),
        ],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b"mp3> .headers[0] | repl\n"
        b"> .headers[0] id3v2> .header> .headers[0] id3v2> .header"
        b"> .headers[0] id3v2> .header^C\n"
        b"> .headers[0] id3v2> ^D\nmp3> ^D\n"
    )


def test_tab_completes_option_object_keys(tmp_path):
    """Option-like object keys complete inline."""
    # CATCHES: completion also works on option-like values returned by
    # expressions — tobitsrange's size/start/stop keys are listed inline.
    r = run_fq_pty(
        E,
        [(b'"abc" | tobitsrange.s\t', 2.5), (b"\x03\x03\x04", 2.0)],
        home=tmp_path / "h",
    )
    assert r.exited and r.rc == 0
    assert r.text == (
        b'null> "abc" | tobitsrange.s\n'
        b"size  start stop  "
        b'null> "abc" | tobitsrange.snull> "abc" | tobitsrange.s^C\nnull> ^D\n'
    )
