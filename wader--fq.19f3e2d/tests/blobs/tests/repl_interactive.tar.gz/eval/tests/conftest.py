"""Shared harness for the ``repl_interactive`` module tests.

Every test drives the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hard-coded path).  Two helpers cover the two faces of the module:

``run_fq``
    Non-interactive: stdin is a pipe, so the REPL evaluates each stdin line
    without prompts and byte-exact stdout/stderr/exit-code recordings can be
    asserted verbatim.

``run_fq_pty``
    Interactive: the candidate runs on a freshly allocated pseudo terminal
    (fixed 80x24 window) and the test feeds it keystroke chunks.  A reader
    thread answers the terminal cursor-position query (``ESC [6n``) that the
    readline layer emits on every redraw, otherwise the candidate blocks
    forever; the child is made a session leader with the pty as its
    controlling terminal so ``^C`` delivered during evaluation arrives as a
    real SIGINT, exactly like a user's terminal.  ``NO_DECODE_PROGRESS=1``
    suppresses transient progress output.  Each call gets its own ``home``
    directory because fq persists readline history in
    ``$XDG_CACHE_HOME/fq/history``.

``plain`` normalizes a raw pty stream (strip ANSI sequences, remove the
``<space><backspace>`` cursor trick, CR LF -> LF) into screen text that can be
compared exactly, while color tests assert on the raw bytes themselves.

The child environment is fully pinned (fixed PATH/LANG, throwaway HOME) so no
ambient variable can leak in; tests that care about persistence pass their own
``home`` under ``tmp_path``.
"""

from __future__ import annotations

import base64
import collections
import fcntl
import os
import pathlib
import re
import shutil
import signal
import struct
import subprocess
import tempfile
import termios
import threading
import time

# The mp3 fixture used by pkg/interp/testdata/test.mp3 (md5
# 1b3cb3b0b34fa78449c9f5d5dd6a8177), embedded so tests never reach outside
# tmp_path for input files.
_MP3_B64 = """
SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4LjQ1LjEwMAAAAAAAAAAAAAAA//tAwAAAAA
AAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAACAAACVwCmpqampqampqampqampqampqampqam
pqampqampqampqampqampqampqampqampqam//////////////////////////////////
////////////////////////////////8AAAAATGF2YzU4LjkxAAAAAAAAAAAAAAAAJAUH
AAAAAAAAAldi8Fo1AAAAAAD/+1DEAAAKLEMuVZSAAYCTaycwgAAHqsOOM4XTZPGhwQgcWB
9eHxgcRgQeieWzLloPqDsTa/D4YFAUBAMCgkQMTmjRo2wfeIAQBDE4P8EHTnT5zl/Ocv7u
n3cuD4Pg+HwQDEoAwf0gAf///nnnnnhPsQ8pB1zlN1Fg1iKGapYafqNVM24v4SbR4AokJh
s9BHBUe0qtGTYeiCaLf+8UnAsNYn//77ghRjlH+gmfKhoKBX0eBQRIg2d+5PKgIRNCQS//
45BJg9a1CQRAwJlKoIgR//tSxASDyRQ5KTzDAAAAADSAAAAEEUs2SgiDWMkg1ClSmMjI+R
OAQCS8kSNCUFYNGBEDQd6wVWCsRHiwdgr6P4lOlXKBqDUqdWdiL/BXlj3Ev//xEkxBTUUz
LjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq
qqqqqqqqqqqqqqqqqqo=
"""

# CSI/OSC escape sequences (including the ESC[6n cursor query itself).
_ANSI_RE = re.compile(rb"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")

PtyResult = collections.namedtuple("PtyResult", "text raw rc exited")


def executable_path() -> str:
    """Return the candidate path from PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE", "")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; the suite cannot drive the candidate"
        )
    return path


def _base_env(home, terminal=False):
    """Return the pinned base environment for HOME (see module docstring)."""
    merged = {
        "PATH": "/usr/bin:/bin",
        "HOME": str(home),
        "XDG_CACHE_HOME": os.path.join(str(home), "cache"),
        "LANG": "C",
    }
    if terminal:
        merged["LANG"] = "C.UTF-8"
        merged["TERM"] = "xterm"
        merged["NO_DECODE_PROGRESS"] = "1"
    return merged


def _merge_env(env, extra):
    """Merge EXTRA into ENV and apply the required coverage passthrough."""
    merged = dict(env)
    if extra:
        merged.update(extra)
    # Coverage instrumentation hook (REQUIRED): copy GOCOVERDIR from the
    # test process environment into the child env when present, so the
    # pipeline can measure source coverage of the reference binary.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    merged.update(cov_env)
    return merged


def run_fq(argv, *, stdin="", cwd=None, env=None, extra=None, home=None, timeout=25):
    """Run the candidate with a raw argument vector; return the process.

    stdin may be str or bytes; stdout/stderr are always bytes so that exact
    recorded byte expectations can be asserted.  An explicit ``env`` is used
    verbatim (so tests can pin exactly which variables the child sees, e.g.
    HOME unset entirely); otherwise the pinned base built around ``home`` is
    used, with a fresh throwaway directory when ``home`` is not given — fq
    persists readline history under $XDG_CACHE_HOME/fq/history, so a shared
    home would leak lines between tests and make output order-dependent.
    """
    data = stdin if isinstance(stdin, bytes) else stdin.encode()
    cleanup = None
    if env is None:
        if home is None:
            home = cleanup = tempfile.mkdtemp(prefix="fq-repl-run-")
        env = _base_env(home)
    try:
        return subprocess.run(
            [executable_path()] + list(argv),
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd,
            env=_merge_env(env, extra),
            timeout=timeout,
        )
    finally:
        if cleanup is not None:
            shutil.rmtree(cleanup, ignore_errors=True)


def _make_session_leader():
    # Runs in the forked child (fd 0 is the pty slave): detach from the test
    # runner's session and claim the pty as controlling terminal so keyboard
    # signals behave like on a real terminal.
    os.setsid()
    fcntl.ioctl(0, termios.TIOCSCTTY, 0)


def plain(raw):
    """Normalize a raw pty byte stream into comparable screen text."""
    b = _ANSI_RE.sub(b"", raw)
    while b" \x08" in b:
        b = b.replace(b" \x08", b"")
    b = b.replace(b"\x08", b"")
    b = b.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    return b


def run_fq_pty(
    argv,
    steps,
    *,
    home,
    rows=24,
    cols=80,
    env=None,
    extra=None,
    cwd=None,
    start=2.0,
    settle=1.5,
    exit_wait=5.0,
    quiet=0.2,
):
    """Run the candidate interactively on a pseudo terminal.

    ``steps`` is a list of chunks to write to the terminal.  Each entry is
    ``bytes`` (written after the previous output went quiet), ``(bytes,
    max_wait)`` or ``(bytes, max_wait, min_wait)`` where the waits bound how
    long to keep draining output after the chunk.  Returns ``PtyResult(text,
    raw, rc, exited)``; ``text`` is ``plain(raw)`` and ``exited`` tells whether
    the candidate left on its own (as opposed to being killed by the harness).
    """
    home = str(home)
    os.makedirs(os.path.join(home, "cache"), exist_ok=True)
    master, slave = os.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    proc = subprocess.Popen(
        [executable_path()] + list(argv),
        stdin=slave,
        stdout=slave,
        stderr=slave,
        cwd=cwd,
        env=_merge_env(env or _base_env(home, terminal=True), extra),
        close_fds=True,
        preexec_fn=_make_session_leader,
    )
    os.close(slave)
    buf = bytearray()
    lock = threading.Lock()

    def reader():
        while True:
            try:
                data = os.read(master, 65536)
            except OSError:
                return
            if not data:
                return
            with lock:
                buf.extend(data)
            # The readline layer asks for the cursor position on every
            # redraw (ESC [6n); answer "row 1, column 1" or it blocks.
            while b"\x1b[6n" in data:
                try:
                    os.write(master, b"\x1b[1;1R")
                except OSError:
                    return
                data = data.replace(b"\x1b[6n", b"", 1)

    # Started after Popen: at fork time no extra thread exists, keeping the
    # preexec_fn call safe.
    thread = threading.Thread(target=reader, daemon=True)
    thread.start()

    def drain(limit, minimum=0.0):
        if minimum:
            time.sleep(minimum)
        end = time.time() + limit
        while time.time() < end:
            with lock:
                before = len(buf)
            time.sleep(quiet)
            with lock:
                after = len(buf)
            if after == before:
                return

    drain(start)
    for step in steps:
        if isinstance(step, (bytes, bytearray)):
            data, limit, minimum = bytes(step), settle, 0.0
        elif len(step) == 2:
            data, (limit, minimum) = step[0], (step[1], 0.0)
        else:
            data, limit, minimum = step
        os.write(master, data)
        drain(limit, minimum)
    exited = False
    end = time.time() + exit_wait
    while time.time() < end:
        if proc.poll() is not None:
            exited = True
            break
        drain(0.25)
    if not exited:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            proc.kill()
        proc.wait()
    time.sleep(quiet * 2)
    try:
        os.close(master)
    except OSError:
        pass
    with lock:
        raw = bytes(buf)
    return PtyResult(plain(raw), raw, proc.returncode, exited)


def history_path(home):
    """Return the persisted readline history path for a home directory."""
    return pathlib.Path(str(home)) / "cache" / "fq" / "history"


def write_file(directory, name, text):
    """Write TEXT to DIRECTORY/NAME and return the path as a str."""
    path = pathlib.Path(directory) / name
    if isinstance(text, bytes):
        path.write_bytes(text)
    else:
        path.write_text(text, encoding="utf-8")
    return str(path)


def write_mp3(directory, name="test.mp3"):
    """Write the embedded mp3 fixture into DIRECTORY and return its path."""
    path = pathlib.Path(directory) / name
    path.write_bytes(base64.b64decode(_MP3_B64))
    return str(path)
