"""Black-box tests for the av1 (av1_obu, av1_frame, av1_ccr) and vpx (vpx_ccr,
vp8_frame, vp9_frame, vp9_cfm) decoders.

Every expected value below was recorded by running the reference fq binary on
the fixtures in eval/tests/data (some fixtures were extracted from the matroska
and isobmff fixtures using the reference binary itself, some were crafted).
"""

import pytest

from conftest import fq_json, run_ok

AV1_SEQ = "av1/av1_obu_seq_header_film_grain_chrome_sample_pos"
AV1_OBU_EXT = "av1/av1_obu_temporal_delim_ext"
AV1_OBU_PAD = "av1/av1_obu_padding_no_size"
AV1_TU = "av1/av1_temporal_unit"
AV1_CCR_EMPTY = "av1/av1_ccr_empty_obus"
AV1_CCR_OBU = "av1/av1_ccr_with_obu"
VPX_CCR = "vpx/vpx_ccr"
VP8_KEY = "vpx/vp8_keyframe"
VP9_KEY = "vpx/vp9_keyframe"
VP9_P2_10 = "vpx/vp9_p2_10bit_keyframe"
VP9_P2_12 = "vpx/vp9_p2_12bit_keyframe"
VP9_CFM = "vpx/vp9_cfm_features"


def test_av1_obu_sequence_header_film_grain(tmp_path):
    """av1_obu decodes a sequence header OBU incl. color config and film grain.

    CATCHES: bit widths and symbol tables of the sequence header (seq_profile,
    operating points, frame dimension fields, enable_* flags, color config
    incl. chroma_sample_position and film_grain_params_present).
    """
    seq = fq_json(tmp_path, ["-d", "av1_obu", "-c", "-V", "del(.data)", AV1_SEQ])
    assert seq == {
        "color_config": {
            "bit_depth": 8,
            "chroma_sample_position": 0,
            "color_description_present_flag": 1,
            "color_primaries": "bt_709",
            "color_range": 0,
            "high_bitdepth": 0,
            "matrix_coefficients": "bt_709",
            "mono_chrome": 0,
            "separate_uv_delta_q": 0,
            "subsampling_x": 1,
            "subsampling_y": 1,
            "transfer_characteristics": "bt_709",
        },
        "enable_cdef": 1,
        "enable_dual_filter": 0,
        "enable_filter_intra": 0,
        "enable_interintra_compound": 1,
        "enable_intra_edge_filter": 1,
        "enable_jnt_comp": 0,
        "enable_masked_compound": 0,
        "enable_order_hint": 1,
        "enable_ref_frame_mvs": 1,
        "enable_restoration": 1,
        "enable_superres": 0,
        "enable_warped_motion": 1,
        "film_grain_params_present": 1,
        "frame_height": 1080,
        "frame_height_bits_minus_1": 10,
        "frame_id_numbers_present_flag": 0,
        "frame_width": 1920,
        "frame_width_bits_minus_1": 10,
        "header": {
            "extension_flag": False,
            "forbidden_bit": 0,
            "has_size_field": True,
            "reserved_1bit": 0,
            "type": "sequence_header",
        },
        "initial_display_delay_present_flag": 0,
        "max_frame_height_minus_1": 1079,
        "max_frame_width_minus_1": 1919,
        "operating_points": [
            {"operating_point_idc": 0, "seq_level_idx": 8, "seq_tier": 0}
        ],
        "operating_points_cnt_minus_1": 0,
        "order_hint_bits_minus_1": 6,
        "reduced_still_picture_header": 0,
        "seq_choose_integer_mv": 1,
        "seq_choose_screen_content_tools": 1,
        "seq_profile": "main",
        "size": 14,
        "still_picture": 0,
        "timing_info_present_flag": 0,
        "use_128x128_superblock": 0,
    }


def test_av1_obu_header_variants(tmp_path):
    """av1_obu parses the extension header and the has_size_field=0 fallback.

    CATCHES: the optional OBU extension header (temporal_id/spatial_id/reserved
    bits) and that a missing size field makes the payload span the rest of the
    buffer with no size field in the output.
    """
    ext = fq_json(tmp_path, ["-d", "av1_obu", "-c", "-V", ".", AV1_OBU_EXT])
    assert ext == {
        "data": "",
        "header": {
            "extension_flag": True,
            "extension_header_reserved_3bits": 2,
            "forbidden_bit": 0,
            "has_size_field": True,
            "reserved_1bit": 0,
            "spatial_id": 1,
            "temporal_id": 3,
            "type": "temporal_delimiter",
        },
        "size": 0,
    }

    pad = fq_json(tmp_path, ["-d", "av1_obu", "-c", "-V", ".", AV1_OBU_PAD])
    assert pad == {
        "data": "\ufffd\ufffd",
        "header": {
            "extension_flag": False,
            "forbidden_bit": 0,
            "has_size_field": False,
            "reserved_1bit": 0,
            "type": "padding",
        },
    }
    # no size field was present, so the payload takes the remaining 2 bytes
    assert pad["data"] == "\ufffd\ufffd"
    assert "size" not in pad


def test_av1_frame_temporal_unit(tmp_path):
    """av1_frame decodes a whole temporal unit as a list of OBUs.

    CATCHES: the root array of OBUs (sequence_header + frame_header +
    tile_group with their sizes) and that only sequence header OBUs get their
    payload decoded while other OBU payloads stay as raw data bits.
    """
    obus = fq_json(
        tmp_path,
        ["-d", "av1_frame", "-c", "-V", "[.[] | {type: .header.type, size}]", AV1_TU],
    )
    assert obus == [
        {"size": 13, "type": "sequence_header"},
        {"size": 16, "type": "frame_header"},
        {"size": 4464, "type": "tile_group"},
    ]

    seq_header = fq_json(
        tmp_path,
        [
            "-d",
            "av1_frame",
            "-c",
            "-V",
            ".[0] | {seq_profile, frame_width, frame_height, "
            "film_grain_params_present, "
            "color_config: (.color_config | {bit_depth, color_primaries})}",
            AV1_TU,
        ],
    )
    assert seq_header == {
        "color_config": {"bit_depth": 8, "color_primaries": "unspecified"},
        "film_grain_params_present": 0,
        "frame_height": 240,
        "frame_width": 320,
        "seq_profile": "high",
    }

    # frame/tile group OBUs only carry header, size and raw data
    keys = fq_json(
        tmp_path, ["-d", "av1_frame", "-c", "-V", "[.[] | keys]", AV1_TU]
    )
    assert keys[1] == ["header", "size", "data"]
    assert keys[2] == ["header", "size", "data"]


@pytest.mark.parametrize(
    "fixture,expected",
    [
        (
            AV1_CCR_EMPTY,
            {
                "chroma_sample_position": 0,
                "chroma_subsampling_x": 0,
                "chroma_subsampling_y": 0,
                "config_obus": [],
                "high_bitdepth": 0,
                "initial_presentation_delay_present": False,
                "marker": 1,
                "monochrome": 0,
                "reserved0": 0,
                "reserved1": 0,
                "seq_level_idx_0": 31,
                "seq_profile": 1,
                "seq_tier_0": 0,
                "twelve_bit": 0,
                "version": 1,
            },
        ),
        (
            AV1_CCR_OBU,
            {
                "chroma_sample_position": 0,
                "chroma_subsampling_x": 0,
                "chroma_subsampling_y": 0,
                "config_obus": [
                    {
                        "color_config": {
                            "bit_depth": 8,
                            "color_description_present_flag": 1,
                            "color_primaries": "unspecified",
                            "color_range": 0,
                            "high_bitdepth": 0,
                            "matrix_coefficients": "unspecified",
                            "mono_chrome": 0,
                            "separate_uv_delta_q": 1,
                            "subsampling_x": 0,
                            "subsampling_y": 0,
                            "transfer_characteristics": "unspecified",
                        },
                        "enable_cdef": 1,
                        "enable_dual_filter": 0,
                        "enable_filter_intra": 0,
                        "enable_interintra_compound": 0,
                        "enable_intra_edge_filter": 1,
                        "enable_jnt_comp": 0,
                        "enable_masked_compound": 0,
                        "enable_order_hint": 1,
                        "enable_ref_frame_mvs": 0,
                        "enable_restoration": 1,
                        "enable_superres": 0,
                        "enable_warped_motion": 0,
                        "film_grain_params_present": 0,
                        "frame_height": 240,
                        "frame_height_bits_minus_1": 7,
                        "frame_id_numbers_present_flag": 0,
                        "frame_width": 320,
                        "frame_width_bits_minus_1": 8,
                        "header": {
                            "extension_flag": False,
                            "forbidden_bit": 0,
                            "has_size_field": True,
                            "reserved_1bit": 0,
                            "type": "sequence_header",
                        },
                        "initial_display_delay_present_flag": 0,
                        "max_frame_height_minus_1": 239,
                        "max_frame_width_minus_1": 319,
                        "operating_points": [
                            {
                                "operating_point_idc": 0,
                                "seq_level_idx": 31,
                                "seq_tier": 0,
                            }
                        ],
                        "operating_points_cnt_minus_1": 0,
                        "order_hint_bits_minus_1": 5,
                        "reduced_still_picture_header": 0,
                        "seq_choose_screen_content_tools": 0,
                        "seq_force_screen_content_tools": 0,
                        "seq_profile": "high",
                        "size": 13,
                        "still_picture": 0,
                        "timing_info_present_flag": 0,
                        "use_128x128_superblock": 0,
                    }
                ],
                "high_bitdepth": 0,
                "initial_presentation_delay_present": False,
                "marker": 1,
                "monochrome": 0,
                "reserved0": 0,
                "reserved1": 0,
                "seq_level_idx_0": 31,
                "seq_profile": 1,
                "seq_tier_0": 0,
                "twelve_bit": 0,
                "version": 1,
            },
        ),
    ],
)
def test_av1_ccr(tmp_path, fixture, expected):
    """av1_ccr decodes the AV1 codec configuration record and its config OBUs.

    CATCHES: the bit layout of the fixed part (marker/version/seq_profile/
    level/tier/bitdepth/subsampling) and the trailing config_obus array, which
    is empty for the 4 byte matroska CodecPrivate and holds one sequence header
    OBU for the isobmff av1C record.
    """
    expr = "del(.config_obus[0].data)" if fixture == AV1_CCR_OBU else "."
    ccr = fq_json(tmp_path, ["-d", "av1_ccr", "-c", "-V", expr, fixture])
    assert ccr == expected


def test_vpx_ccr(tmp_path):
    """vpx_ccr decodes the VP9 configuration record from an mp4 vpcC box.

    CATCHES: the un-aligned bit fields (bit_depth/chroma_subsampling split
    across a byte), the level and ISO 23091-2 colour symbol tables and the
    trailing codec_initialization_data_size.
    """
    ccr = fq_json(tmp_path, ["-d", "vpx_ccr", "-c", "-V", ".", VPX_CCR])
    assert ccr == {
        "bit_depth": 8,
        "chroma_subsampling": "4:4:4",
        "codec_initialization_data_size": 0,
        "colour_primaries": "unspecified",
        "level": "level_2",
        "matrix_coefficients": "unspecified",
        "profile": 1,
        "transfer_characteristics": "unspecified",
        "video_full_range_flag": 0,
    }


def test_vp8_frame_keyframe(tmp_path):
    """vp8_frame decodes the key frame tag, start code and dimensions.

    CATCHES: the non-contiguous first_part_size and width/height fields (split
    around the scale bits), the start code 0x9d012a and the version symbol
    table (reconstruction/loop filter names).
    """
    frame = fq_json(tmp_path, ["-d", "vp8_frame", "-c", "-V", "del(.data)", VP8_KEY])
    assert frame == {
        "height": 240,
        "height0": 240,
        "height1": 0,
        "horizontal_scale": 0,
        "start_code": 10289450,
        "tag": {
            "first_part_size": 725,
            "first_part_size0": 5,
            "first_part_size1": 90,
            "frame_type": "key_frame",
            "loop": "Normal",
            "reconstruction": "Bicubic",
            "show_frame": 1,
            "version": 0,
        },
        "vertical_scale": 0,
        "width": 320,
        "width0": 64,
        "width1": 1,
    }
    keys = run_ok(tmp_path, ["-d", "vp8_frame", "-c", "-V", "keys", VP8_KEY])
    assert keys == '["tag","start_code","width0","horizontal_scale","width1","width","height0","vertical_scale","height1","height","data"]'


@pytest.mark.parametrize(
    "fixture,expected",
    [
        (
            VP9_KEY,
            {
                "bit_depth": 8,
                "color_range": 1,
                "color_space": "rgb",
                "error_resilient_mode": 0,
                "frame_height": 240,
                "frame_marker": 2,
                "frame_sync_byte_0": 73,
                "frame_sync_byte_1": 131,
                "frame_sync_byte_2": 66,
                "frame_type": "key_frame",
                "frame_width": 320,
                "profile": 1,
                "profile_high_bit": 0,
                "profile_low_bit": 1,
                "reserved_zero2": 0,
                "show_existing_frame": False,
                "show_frame": 1,
                "subsampling_x": 0,
                "subsampling_y": 0,
            },
        ),
        (
            VP9_P2_10,
            {
                "bit_depth": 10,
                "color_range": 0,
                "color_space": "bt_601",
                "error_resilient_mode": 0,
                "frame_height": 48,
                "frame_marker": 2,
                "frame_sync_byte_0": 73,
                "frame_sync_byte_1": 131,
                "frame_sync_byte_2": 66,
                "frame_type": "key_frame",
                "frame_width": 100,
                "profile": 2,
                "profile_high_bit": 1,
                "profile_low_bit": 0,
                "show_existing_frame": False,
                "show_frame": 1,
                "subsampling_x": 1,
                "subsampling_y": 1,
                "ten_or_twelve_bit": False,
            },
        ),
        (
            VP9_P2_12,
            {
                "bit_depth": 12,
                "color_range": 0,
                "color_space": "bt_601",
                "error_resilient_mode": 0,
                "frame_height": 48,
                "frame_marker": 2,
                "frame_sync_byte_0": 73,
                "frame_sync_byte_1": 131,
                "frame_sync_byte_2": 66,
                "frame_type": "key_frame",
                "frame_width": 100,
                "profile": 2,
                "profile_high_bit": 1,
                "profile_low_bit": 0,
                "show_existing_frame": False,
                "show_frame": 1,
                "subsampling_x": 1,
                "subsampling_y": 1,
                "ten_or_twelve_bit": True,
            },
        ),
    ],
)
def test_vp9_frame_keyframes(tmp_path, fixture, expected):
    """vp9_frame decodes the uncompressed header of key frames per profile.

    CATCHES: profile bits, sync code 0x49 0x83 0x42, the color config branch
    differences (profile 1 rgb forces color_range 1 and 4:4:4 subsampling,
    profile 2 reads ten_or_twelve_bit and synthesizes 4:2:0 subsampling) and
    the 16 bit width/height minus one fields.
    """
    frame = fq_json(tmp_path, ["-d", "vp9_frame", "-c", "-V", "del(.data)", fixture])
    assert frame == expected


def test_vp9_cfm(tmp_path):
    """vp9_cfm decodes VP9 codec feature metadata records.

    CATCHES: the (id, length, value) record layout, symbolic feature ids
    (Profile/Level/Bit Depth/Chroma Subsampling), the per-feature payload
    decoding and raw data for unknown feature ids.
    """
    features = fq_json(
        tmp_path, ["-d", "vp9_cfm", "-c", "-V", "[.[] | del(.data)]", VP9_CFM]
    )
    assert features == [
        {"id": "Profile", "length": 1, "profile": 2},
        {"id": "Level", "length": 1, "level": "level_3"},
        {"bit_depth": 10, "id": "Bit Depth", "length": 1},
        {"chroma_subsampling": "4:2:0 vertical", "id": "Chroma Subsampling", "length": 1},
        {"id": 5, "length": 2},
    ]
