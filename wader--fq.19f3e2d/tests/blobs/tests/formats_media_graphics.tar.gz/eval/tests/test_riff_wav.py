"""Black-box tests for the RIFF wav and aiff decoders.

Covers the ``wav`` chunk walker (fmt/LIST/data/bext chunks, the 0xffffffff
"rest of file" size, the fmt cb_size extension and the RF64 rejection) and the
``aiff`` decoder (FORM/COMT/COMM/SSND).  Every expected value below was
recorded by running the reference fq binary on the fixtures in eval/tests/data.
"""

import pytest

from conftest import fq_json, run_on

STEREO_WAV = "riff/stereo.wav"
END_OF_FILE_WAV = "riff/end-of-file.wav"
BEXT_WAV = "riff/bext.wav"
RF64_WAV = "riff/rf64.wav"
FMT_CB_WAV = "riff/fmt_cb_size_unknown.wav"
SOX_AIFF = "riff/sox.aiff"


@pytest.mark.parametrize(
    "fixture,riff_size,data_size,software",
    [
        (STEREO_WAV, 1834, 1764, "Lavf58.29.100"),
        (END_OF_FILE_WAV, 4294967295, 4294967295, "Lavf58.45.100"),
    ],
)
def test_wav_chunk_layout_and_fmt_chunk(tmp_path, fixture, riff_size, data_size, software):
    """wav walks the RIFF/WAVE chunk tree and decodes fmt, LIST/ISFT and data.

    CATCHES: the fmt field widths and the 'pcm' audio format symbol, the nested
    LIST chunk with its INFO type and the ISFT string chunk, plus the raw sample
    payload size of the data chunk.
    """
    out = fq_json(tmp_path, ["-d", "wav", "-c", "-V",
                             '{id, size, format, chunks: [.chunks[]'
                             ' | if .id == "data" then {id, size,'
                             '      sb: (.samples | tobytes | length)}'
                             '   elif .id == "LIST" then {id, size, type,'
                             '      chunks: [.chunks[] | {id, size, value}]}'
                             "   else . end]}",
                             fixture])
    assert out == {
        "id": "RIFF",
        "size": riff_size,
        "format": "WAVE",
        "chunks": [
            {"id": "fmt", "size": 16, "audio_format": "pcm", "num_channels": 2,
             "sample_rate": 44100, "byte_rate": 176400, "block_align": 4,
             "bits_per_sample": 16},
            {"id": "LIST", "size": 26, "type": "INFO",
             "chunks": [{"id": "ISFT", "size": 14, "value": software}]},
            {"id": "data", "size": data_size, "sb": 1764},
        ],
    }


def test_wav_bext_broadcast_wave_extension(tmp_path):
    """The bext chunk is decoded with its fixed width string and loudness fields.

    CATCHES: the exact field widths (256/32/32/10/8 byte null padded strings,
    64 byte umid, 180 byte reserved) and that coding_history takes the rest.
    """
    strings = fq_json(tmp_path, ["-d", "wav", "-c", "-V",
                                 ".chunks[0] | {id, size, description, originator,"
                                 " originator_reference, originator_date,"
                                 " originator_time}",
                                 BEXT_WAV])
    assert strings == {
        "id": "bext",
        "size": 602,
        "description": "",
        "originator": "REAPER",
        "originator_reference": "",
        "originator_date": "2001-02-03",
        "originator_time": "04-05-06",
    }

    numbers = fq_json(tmp_path, ["-d", "wav", "-c", "-V",
                                 ".chunks[0] | {time_reference_low,"
                                 " time_reference_high, version, loudness_value,"
                                 " loudness_range, max_true_peak_level,"
                                 " max_momentary_loudness, max_short_term_loudness}",
                                 BEXT_WAV])
    assert numbers == {
        "time_reference_low": 0,
        "time_reference_high": 0,
        "version": 1,
        "loudness_value": 0,
        "loudness_range": 0,
        "max_true_peak_level": 0,
        "max_momentary_loudness": 0,
        "max_short_term_loudness": 0,
    }

    tails = fq_json(tmp_path, ["-d", "wav", "-c", "-V",
                               ".chunks[0] | {umid_bytes: (.umid | tobytes | length),"
                               " reserved_bytes: (.reserved | tobytes | length),"
                               " coding_history}",
                               BEXT_WAV])
    assert tails == {"umid_bytes": 64, "reserved_bytes": 180, "coding_history": ""}

    # the file is a plain WAVE file whose only chunk is bext
    header = fq_json(tmp_path, ["-d", "wav", "-c", "-V",
                                "{id, size, format, n: (.chunks | length)}", BEXT_WAV])
    assert header == {"id": "RIFF", "size": 614, "format": "WAVE", "n": 1}


def test_wav_rf64_is_not_supported(tmp_path):
    """An RF64 file is not recognised by wav: no ds64 handling, wrong riff type.

    CATCHES: only the literal 'RIFF' chunk id enables the WAVE walker, so the
    RF64 id falls through to the raw 'data' branch and the decode ends with the
    'wrong or no WAV riff type found' error while still exiting 0.
    """
    out = fq_json(tmp_path, ["-d", "wav", "-c", "-V",
                             "{id, size, format, data_bytes: (.data | tobytes | length)}",
                             RF64_WAV])
    assert out == {"id": "RF64", "size": 4294967295, "format": None, "data_bytes": 1870}

    res = run_on(tmp_path, ["-d", "wav", "d", RF64_WAV])
    assert res.returncode == 0
    assert "error: wav: error at position 0x756: wrong or no WAV riff type found ()" \
        in res.stdout.decode("utf-8")


def test_wav_fmt_cb_size_extension(tmp_path):
    """A fmt chunk longer than 16 bytes carries cb_size plus unknown extension bytes.

    CATCHES: for a non extensible audio format the extra bytes are read as a
    cb_size count followed by exactly that many raw 'unknown' bytes.
    """
    out = fq_json(tmp_path, ["-d", "wav", "-c", "-V", ".chunks[0]", FMT_CB_WAV])
    assert out == {
        "id": "fmt",
        "size": 20,
        "audio_format": "pcm",
        "num_channels": 2,
        "sample_rate": 44100,
        "byte_rate": 352800,
        "block_align": 8,
        "bits_per_sample": 32,
        "cb_size": 2,
        "unknown": "\u0001\u0000",
    }
    unknown_hex = fq_json(tmp_path, ["-d", "wav", "-c", "-V",
                                     ".chunks[0].unknown | tobytes | tohex", FMT_CB_WAV])
    assert unknown_hex == "0100"


def test_aiff_chunks(tmp_path):
    """aiff decodes FORM/COMT/COMM/SSND including the 80 bit sample rate.

    CATCHES: the big endian chunk sizes, the COMT comment array with its padded
    text, the 10 byte IEEE 80 bit extended sample_rate and the SSND
    offset/block_size header before the sample data.
    """
    out = fq_json(tmp_path, ["-d", "aiff", "-c", "-V",
                             '{id, size, format, chunks: [.chunks[]'
                             ' | if .id == "SSND" then {id, size, offset, block_size,'
                             '      db: (.data | tobytes | length)} else . end]}',
                             SOX_AIFF])
    assert out == {
        "id": "FORM",
        "size": 8900,
        "format": "AIFF",
        "chunks": [
            {"id": "COMT", "size": 26, "num_comments": 1,
             "comments": [{"timestamp": 3761215819, "marker_id": 0, "count": 16,
                           "text": "Processed by SoX"}]},
            {"id": "COMM", "size": 18, "num_channels": 1, "num_sample_frames": 4410,
             "sample_size": 16, "sample_rate": 44100},
            {"id": "SSND", "size": 8828, "offset": 0, "block_size": 0, "db": 8820},
        ],
    }

    # the aiff decoder is what auto probing picks for this file
    probed = fq_json(tmp_path, ["-c", "-V", "format", SOX_AIFF])
    assert probed == "aiff"
