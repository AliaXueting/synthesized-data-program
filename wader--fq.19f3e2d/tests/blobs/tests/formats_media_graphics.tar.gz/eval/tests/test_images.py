"""Black-box tests for the still image decoders (jpeg, png, gif, tiff, exif, webp).

Every expected value below was recorded by running the reference fq binary on
the fixtures in eval/tests/data (jpeg/, png/, gif/, tiff/ and riff/ for webp).
"""

import pytest

from conftest import fq_json, run_ok, run_on

JPEG = "jpeg/4x4.jpg"
JP2 = "jpeg/test.jp2"
PNG = "png/4x4.png"
PNG_PAL = "png/4x4_palette.png"
APNG = "png/4x4a.apng"
GIF = "gif/4x4.gif"
TIFF = "tiff/4x4.tiff"
TIFF_EXIF = "tiff/exif_ifd.tiff"
WEBP = "riff/4x4.webp"
WEBP_LL = "riff/4x4.lossless.webp"
WEBP_ALPHA = "riff/vp8l-alpha.webp"
WEBP_1X1 = "riff/vp8l-1x1.webp"
WEBP_XMP = "riff/xmp_exif.webp"


# ---------------------------------------------------------------------------
# jpeg
# ---------------------------------------------------------------------------


def test_jpeg_segment_chain_and_entropy_data(tmp_path):
    """jpeg decodes the marker chain SOI..EOI with the scan data as raw bytes.

    CATCHES: marker symbol names for every segment, the entropy coded scan
    kept as a raw 2 byte value (not parsed as markers) and the final EOI.
    """
    out = fq_json(tmp_path, ["-d", "jpeg", "-c", "-V",
                   "{codes: [.segments[] | if type == \"object\" then .code else \"raw\" end],"
                   " ecd_len: (.segments[7] | length),"
                   " ecd_hex: (.segments[7] | tohex),"
                   " last: .segments[8]}",
                   JPEG])
    assert out == {
        "codes": ["soi", "app0", "dqt", "sof0", "dht", "dht", "sos", "raw", "eoi"],
        "ecd_len": 2,
        "ecd_hex": "3fbf",
        "last": {"code": "eoi", "prefix": "�"},
    }


def test_jpeg_jfif_app0_and_sof0(tmp_path):
    """The APP0 JFIF segment and the SOF0 frame header decode field by field.

    CATCHES: JFIF identifier/version/density units/thumbnail sizes and the
    SOF0 precision, dimensions and component sampling/table selector.
    """
    out = fq_json(tmp_path, ["-d", "jpeg", "-c", "-V",
                   "{app0: .segments[1], sof0: .segments[3]}", JPEG])
    assert out == {
        "app0": {
            "code": "app0",
            "data": "",
            "density_units": 1,
            "identifier": "JFIF\x00",
            "length": 16,
            "prefix": "�",
            "version": {"major": 1, "minor": 1},
            "xdensity": 72,
            "xthumbnail": 0,
            "ydensity": 72,
            "ythumbnail": 0,
        },
        "sof0": {
            "code": "sof0",
            "frame_components": [{"c": 1, "h": 1, "tq": 0, "v": 1}],
            "lf": 11,
            "nf": 1,
            "p": 8,
            "prefix": "�",
            "x": 4,
            "y": 4,
        },
    }


def test_jpeg_quantization_huffman_and_scan_headers(tmp_path):
    """DQT, the two DHT tables and the SOS scan header decode with symbols.

    CATCHES: quantization table precision/selector plus the 64 coefficients,
    huffman table class/id and the 16 count entries, and the SOS spectral
    selection bounds with per-component huffman table selectors.
    """
    out = fq_json(tmp_path, ["-d", "jpeg", "-c", "-V",
                   "{dqt: (.segments[2].qs[0] | {pq, tq, n: (.q|length), head: .q[0:8], tail: .q[56:64]}),"
                   " dht0: .segments[4].hs,"
                   " dht1: .segments[5].hs,"
                   " sos: .segments[6]}",
                   JPEG])
    assert out == {
        "dht0": [{"l": [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  "tc": 0, "th": 0, "v": [8]}],
        "dht1": [{"l": [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  "tc": 1, "th": 0, "v": [0]}],
        "dqt": {"head": [8, 6, 6, 7, 6, 5, 8, 7],
                "n": 64,
                "pq": 0,
                "tail": [61, 56, 50, 60, 46, 51, 52, 50],
                "tq": 0},
        "sos": {"ah": 0,
                "al": 0,
                "code": "sos",
                "ls": 8,
                "ns": 1,
                "prefix": "�",
                "scan_components": [{"cs": 1, "ta": 0, "td": 0}],
                "se": 63,
                "ss": 0},
    }


def test_jpeg_rejects_jp2_container(tmp_path):
    """A JPEG 2000 container is not a jpeg file: decode fails with a gap.

    CATCHES: forcing -d jpeg on a jp2 box container must report 'no SOI
    marker' at position 0 and leave the bytes as a single gap while the
    process still exits 0.
    """
    res = run_on(tmp_path, ["-d", "jpeg", "d", JP2])
    assert res.returncode == 0
    stdout = res.stdout.decode("utf-8")
    assert "error: jpeg: error at position 0x0: no SOI marker" in stdout
    assert "....jP  ........|  gap0: raw bits" in stdout


# ---------------------------------------------------------------------------
# png
# ---------------------------------------------------------------------------


def test_png_signature_ihdr_and_chunk_table(tmp_path):
    """png checks the 8 byte signature and lists chunks with CRCs.

    CATCHES: signature assertion bytes, IHDR width/height/bit depth/color
    type/compression/filter/interlace symbols, chunk case flags and the
    CRC-32 stored as a plain integer per chunk.
    """
    out = fq_json(tmp_path, ["-d", "png", "-c", "-V",
                   "{sig: (.signature|tohex),"
                   " chunks: [.chunks[] | {t: .type, len: .length, crc}],"
                   " ihdr: .chunks[0]}",
                   PNG])
    assert out == {
        "chunks": [
            {"crc": 2173346771, "len": 13, "t": "IHDR"},
            {"crc": 201089285, "len": 4, "t": "gAMA"},
            {"crc": 2629456188, "len": 32, "t": "cHRM"},
            {"crc": 3716813732, "len": 2, "t": "bKGD"},
            {"crc": 3697372367, "len": 7, "t": "tIME"},
            {"crc": 3541644478, "len": 11, "t": "IDAT"},
            {"crc": 1099046007, "len": 37, "t": "tEXt"},
            {"crc": 819963083, "len": 37, "t": "tEXt"},
            {"crc": 1291166396, "len": 23, "t": "zTXt"},
            {"crc": 2923585666, "len": 0, "t": "IEND"},
        ],
        "ihdr": {
            "ancillary": False,
            "bit_depth": 1,
            "color_type": "grayscale",
            "compression_method": "deflate",
            "crc": 2173346771,
            "filter_method": "adaptive_filtering",
            "height": 4,
            "interlace_method": "none",
            "length": 13,
            "private": False,
            "reserved": False,
            "safe_to_copy": False,
            "type": "IHDR",
            "width": 4,
        },
        "sig": "89504e470d0a1a0a",
    }


def test_png_auxiliary_and_text_chunks(tmp_path):
    """gAMA/cHRM/bKGD/tEXt/zTXt chunks decode, zTXt is zlib inflated.

    CATCHES: cHRM chromaticity floats divided by 1000, bKGD branch chosen by
    grayscale color type, tEXt keyword/text split on NUL and the zTXt
    uncompressed text after deflate decompression.
    """
    aux = fq_json(tmp_path, ["-d", "png", "-c", "-V",
                  "[.chunks[] | select(.type==\"gAMA\" or .type==\"cHRM\" or .type==\"bKGD\")"
                  " | del(.crc, .length, .ancillary, .private, .reserved, .safe_to_copy)]",
                  PNG])
    assert aux == [
        {"type": "gAMA", "value": 45455},
        {"blue_x": 15, "blue_y": 6, "green_x": 30, "green_y": 60,
         "red_x": 64, "red_y": 33, "type": "cHRM",
         "white_point_x": 31.27, "white_point_y": 32.9},
        {"gray": 1, "type": "bKGD"},
    ]

    texts = fq_json(tmp_path, ["-d", "png", "-c", "-V",
                   "[.chunks[] | select(.type==\"tEXt\" or .type==\"zTXt\")"
                   " | del(.crc, .length, .ancillary, .private, .reserved, .safe_to_copy, .compressed)]",
                   PNG])
    assert texts == [
        {"keyword": "date:create", "text": "2021-07-28T08:54:09+00:00",
         "type": "tEXt"},
        {"keyword": "date:modify", "text": "2021-07-28T08:54:09+00:00",
         "type": "tEXt"},
        {"compression_method": "deflate", "keyword": "akeyword",
         "type": "zTXt", "uncompressed": {"text": "atext"}},
    ]


def test_png_palette_color_type(tmp_path):
    """A palette png decodes IHDR color type 'palette' and the PLTE entries.

    CATCHES: color type 3 symbol name, 2 bit depth and the full 4 entry RGB
    palette of the PLTE chunk.
    """
    out = fq_json(tmp_path, ["-d", "png", "-c", "-V",
                   "{types: [.chunks[] | .type], ihdr: .chunks[0], plte: .chunks[1].palette}",
                   PNG_PAL])
    assert out == {
        "ihdr": {
            "ancillary": False,
            "bit_depth": 2,
            "color_type": "palette",
            "compression_method": "deflate",
            "crc": 3567220461,
            "filter_method": "adaptive_filtering",
            "height": 4,
            "interlace_method": "none",
            "length": 13,
            "private": False,
            "reserved": False,
            "safe_to_copy": False,
            "type": "IHDR",
            "width": 4,
        },
        "plte": [{"b": 255, "g": 0, "r": 255},
                 {"b": 170, "g": 85, "r": 170},
                 {"b": 85, "g": 170, "r": 85},
                 {"b": 0, "g": 255, "r": 0}],
        "types": ["IHDR", "PLTE", "IDAT", "IEND"],
    }


def test_apng_animation_chunks(tmp_path):
    """APNG adds acTL/fcTL/fdAT chunks with animation parameters.

    CATCHES: frame/play counts, per-frame sequence numbers, dimensions,
    offsets and delay numerator/separator, dispose/blend op symbols and the
    fdAT sequence number framing the raw frame payload.
    """
    head = fq_json(tmp_path, ["-d", "png", "-c", "-V",
                   "{types: [.chunks[] | .type],"
                   " actl: (.chunks[] | select(.type==\"acTL\") | {num_frames, num_plays})}",
                   APNG])
    assert head == {
        "actl": {"num_frames": 2, "num_plays": 1},
        "types": ["IHDR", "pHYs", "acTL", "fcTL", "IDAT", "fcTL", "fdAT", "IEND"],
    }

    fctl = fq_json(tmp_path, ["-d", "png", "-c", "-V",
                   "[.chunks[] | select(.type==\"fcTL\")"
                   " | del(.crc, .length, .ancillary, .private, .reserved, .safe_to_copy)]",
                   APNG])
    assert fctl == [
        {"blend_op": "source", "delay_num": 1, "delay_sep": 1,
         "dispose_op": "none", "height": 4, "sequence_number": 0,
         "type": "fcTL", "width": 4, "x_offset": 0, "y_offset": 0},
        {"blend_op": "source", "delay_num": 1, "delay_sep": 1,
         "dispose_op": "none", "height": 1, "sequence_number": 1,
         "type": "fcTL", "width": 4, "x_offset": 0, "y_offset": 3},
    ]

    fdat = fq_json(tmp_path, ["-d", "png", "-c", "-V",
                   ".chunks[] | select(.type==\"fdAT\")"
                   " | {sequence_number, len: (.data|length), hex: (.data|tohex)}",
                   APNG])
    assert fdat == {"hex": "789c63f8ff9f81e17f0310ff67a80700",
                    "len": 16,
                    "sequence_number": 2}


# ---------------------------------------------------------------------------
# gif
# ---------------------------------------------------------------------------


def test_gif_full_decode(tmp_path):
    """gif decodes header, screen descriptor, color maps and block chain.

    CATCHES: GIF89a magic, gcp flag/color resolution/bit depth arithmetic
    (+1), extension function code symbols, sub-block byte counts and the
    quirk that code_size is read before a local color map.
    """
    out = fq_json(tmp_path, ["-d", "gif", "-c", "-V", ".", GIF])
    assert out == {
        "bit_depth": 1,
        "black_color": 0,
        "blocks": [
            {"func_data_bytes": [{"byte_count": 4, "data": "\x00\x00\x00\x00",
                                  "terminator": 0}],
             "function_code": "GraphicalControl",
             "introducer": 33},
            {"func_data_bytes": [{"byte_count": 11, "data": "NETSCAPE2.0"},
                                 {"byte_count": 3, "data": "\x01\x00\x00",
                                  "terminator": 0}],
             "function_code": "Application",
             "introducer": 33},
            {"bit_depth": 1,
             "code_size": 2,
             "height": 4,
             "image_bytes": [{"byte_count": 4, "data": "��\t\x05",
                              "terminator": 0}],
             "image_interlaced": False,
             "left": 0,
             "local_color_map_follows": False,
             "separator_character": 44,
             "top": 0,
             "width": 4,
             "zero": 0},
            {"func_data_bytes": [{"byte_count": 4, "data": "\x00\x00\x00\x00",
                                  "terminator": 0}],
             "function_code": "GraphicalControl",
             "introducer": 33},
            {"bit_depth": 1,
             "code_size": 255,
             "height": 4,
             "image_bytes": [{"byte_count": 4, "data": "��\t\x05",
                              "terminator": 0}],
             "image_interlaced": False,
             "left": 0,
             "local_color_map": [[255, 255, 0], [0, 0, 2]],
             "local_color_map_follows": True,
             "separator_character": 44,
             "top": 0,
             "width": 4,
             "zero": 0},
        ],
        "color_resolution": 8,
        "gcp_follows": True,
        "global_color_map": [[0, 0, 0], [0, 0, 0]],
        "header": "GIF89a",
        "height": 4,
        "pixel_aspect_ratio": 0,
        "terminator": 59,
        "width": 4,
        "zero": 0,
    }


# ---------------------------------------------------------------------------
# tiff / exif
# ---------------------------------------------------------------------------


def test_tiff_ifd_entries_and_strips(tmp_path):
    """tiff decodes the header, the IFD entry table and the strip payloads.

    CATCHES: II byte order and magic 42, tag/type symbol names, values stored
    inline in value_offset (PageNumber packs two SHORTs as 65536), ASCII
    strings read from offsets and StripOffsets/StripByteCounts pairing.
    """
    head = fq_json(tmp_path, ["-d", "tiff", "-c", "-V",
                   "{endian, order, integer_42, first_ifd, gap0: (.gap0|tohex),"
                   " n: .ifds[0].number_of_field, next_ifd: .ifds[0].next_ifd,"
                   " strips_hex: [.strips[] | tohex]}",
                   TIFF])
    assert head == {
        "endian": "little-endian",
        "first_ifd": 12,
        "gap0": "00",
        "integer_42": 42,
        "n": 14,
        "next_ifd": 0,
        "order": "II",
        "strips_hex": ["f0f0f0f0"],
    }

    entries = fq_json(tmp_path, ["-d", "tiff", "-c", "-V",
                     "[.ifds[0].entries[] | {tag, type, count, value_offset, values}]",
                     TIFF])
    assert entries == [
        {"count": 1, "tag": "ImageWidth", "type": "SHORT",
         "value_offset": 4, "values": [4]},
        {"count": 1, "tag": "ImageLength", "type": "SHORT",
         "value_offset": 4, "values": [4]},
        {"count": 1, "tag": "BitsPerSample", "type": "SHORT",
         "value_offset": 1, "values": [1]},
        {"count": 1, "tag": "Compression", "type": "SHORT",
         "value_offset": 1, "values": [1]},
        {"count": 1, "tag": "PhotometricInterpretation", "type": "SHORT",
         "value_offset": 0, "values": [0]},
        {"count": 9, "tag": "DocumentName", "type": "ASCII",
         "value_offset": 186, "values": ["4x4.tiff"]},
        {"count": 1, "tag": "StripOffsets", "type": "LONG",
         "value_offset": 8, "values": [8]},
        {"count": 1, "tag": "SamplesPerPixel", "type": "SHORT",
         "value_offset": 1, "values": [1]},
        {"count": 1, "tag": "RowsPerStrip", "type": "SHORT",
         "value_offset": 4, "values": [4]},
        {"count": 1, "tag": "StripByteCounts", "type": "LONG",
         "value_offset": 4, "values": [4]},
        {"count": 1, "tag": "PlanarConfiguration", "type": "SHORT",
         "value_offset": 1, "values": [1]},
        {"count": 2, "tag": "PageNumber", "type": "SHORT",
         "value_offset": 65536, "values": [0, 1]},
        {"count": 68, "tag": "Software", "type": "ASCII",
         "value_offset": 196,
         "values": ["GraphicsMagick 1.3.35 2020-02-23 Q16 http://www.GraphicsMagick.org/"]},
        {"count": 1, "tag": "SampleFormat", "type": "SHORT",
         "value_offset": 1, "values": [1]},
    ]


def test_tiff_exif_ifd_pointer_and_exif_decoder(tmp_path):
    """An ExifIFD LONG entry makes tiff decode a nested IFD inside the entry.

    CATCHES: the 0x8769 pointer seek, nested UNDEFINED/SHORT/RATIONAL values
    with inline vs offset storage, and that the standalone exif decoder is
    the same tiff decoder (same nested structure from -d exif).
    """
    out = fq_json(tmp_path, ["-d", "tiff", "-c", "-V", ".", TIFF_EXIF])
    assert out == {
        "endian": "little-endian",
        "first_ifd": 8,
        "ifds": [{"entries": [
            {"count": 1, "tag": "ImageWidth", "type": "SHORT",
             "value_offset": 2, "values": [2]},
            {"count": 1,
             "ifd": {"entries": [
                 {"count": 4, "tag": "ExifVersion", "type": "UNDEFINED",
                  "value_offset": 842215984, "values": ["0232"]},
                 {"count": 1, "tag": "ColorSpace", "type": "SHORT",
                  "value_offset": 1, "values": [1]},
                 {"count": 1, "tag": "ExposureTime", "type": "RATIONAL",
                  "value_offset": 112,
                  "values": [{"denominator": 250, "float": 0.004,
                              "numerator": 1}]},
             ],
                 "next_ifd": 0,
                 "number_of_field": 3},
             "tag": "ExifIFD",
             "type": "LONG",
             "value_offset": 50},
            {"count": 20, "tag": "DateTime", "type": "ASCII",
             "value_offset": 92, "values": ["2021:07:28 08:54:09"]},
        ],
            "next_ifd": 0,
            "number_of_field": 3}],
        "integer_42": 42,
        "order": "II",
    }

    exif_out = fq_json(tmp_path, ["-d", "exif", "-c", "-V",
                        ".ifds[0].entries[1]", TIFF_EXIF])
    assert exif_out == out["ifds"][0]["entries"][1]


# ---------------------------------------------------------------------------
# webp (decoded via the riff container decoder)
# ---------------------------------------------------------------------------


def test_webp_vp8_lossy_chunk(tmp_path):
    """A lossy webp decodes the RIFF container and the VP8 keyframe header.

    CATCHES: RIFF id/size/format fields, VP8 start code, frame type/loop/
    reconstruction/show frame bitfields and the 14 bit width/height with the
    separate scale and duplicated width0/height0 fields.
    """
    out = fq_json(tmp_path, ["-d", "webp", "-c", "-V", ".", WEBP])
    assert out == {
        "chunks": [{
            "data": "\u0002\u00004%�\x00\x03p\x00���P\x00",
            "height": 4,
            "height0": 4,
            "height1": 0,
            "horizontal_scale": 0,
            "id": "VP8",
            "size": 24,
            "start_code": 10289450,
            "tag": {"first_part_size": 9, "first_part_size0": 1,
                    "first_part_size1": 1, "frame_type": "key_frame",
                    "loop": "Normal", "reconstruction": "Bicubic",
                    "show_frame": 1, "version": 0},
            "vertical_scale": 0,
            "width": 4,
            "width0": 4,
            "width1": 0,
        }],
        "format": "WEBP",
        "id": "RIFF",
        "size": 36,
    }


@pytest.mark.parametrize("fixture,expected", [
    (WEBP_LL, {
        "riff": {"format": "WEBP", "id": "RIFF", "size": 26},
        "c": {"align": None, "alpha_is_used": False, "data_len": 9,
              "height": 4, "id": "VP8L", "signature": 47, "size": 14,
              "version_number": 0, "width": 4, "width_height_flags": 49155},
    }),
    (WEBP_ALPHA, {
        "riff": {"format": "WEBP", "id": "RIFF", "size": 26},
        "c": {"align": "\x00", "alpha_is_used": True, "data_len": 8,
              "height": 1, "id": "VP8L", "signature": 47, "size": 13,
              "version_number": 0, "width": 1, "width_height_flags": 268435456},
    }),
    (WEBP_1X1, {
        "riff": {"format": "WEBP", "id": "RIFF", "size": 30},
        "c": {"align": "\x00", "alpha_is_used": False, "data_len": 12,
              "height": 1, "id": "VP8L", "signature": 47, "size": 17,
              "version_number": 0, "width": 1, "width_height_flags": 0},
    }),
])
def test_webp_vp8l_lossless_chunks(tmp_path, fixture, expected):
    """VP8L lossless chunks decode signature, packed size/flags and alpha bit.

    CATCHES: 0x2f signature, the bit-swizzled width_height_flags u32
    reassembled into width/height (minus one), alpha_is_used flag, and the
    one byte RIFF align pad for odd chunk sizes.
    """
    out = fq_json(tmp_path, ["-d", "webp", "-c", "-V",
                   "{riff: {id, size, format},"
                   " c: (.chunks[0] | {id, size, signature, width_height_flags,"
                   " width, height, alpha_is_used, version_number, align,"
                   " data_len: (.data|length)})}",
                   fixture])
    assert out == expected


def test_webp_vp8x_exif_and_xmp_chunks(tmp_path):
    """An extended webp decodes VP8X flags plus nested EXIF and XMP chunks.

    CATCHES: VP8X metadata flag bits and canvas size (minus one), the EXIF
    chunk decoded inline as a big endian TIFF with a nested ExifIFD, the XMP
    chunk decoded as XML, and the align pad byte after the odd XMP size.
    """
    vp8x = fq_json(tmp_path, ["-d", "webp", "-c", "-V", ".chunks[0]", WEBP_XMP])
    assert vp8x == {"alpha": False, "animation": False, "exif_metadata": True,
                    "height": 4, "icc_profile": False, "id": "VP8X",
                    "reserved0": 0, "reserved1": False, "reserved2": 0,
                    "size": 10, "width": 4, "xml_metadata": True}

    exif_head = fq_json(tmp_path, ["-d", "webp", "-c", "-V",
                        ".chunks[2] | {id, size, order, integer_42, first_ifd,"
                        " n: .ifds[0].number_of_field}",
                        WEBP_XMP])
    assert exif_head == {"first_ifd": 16, "id": "EXIF", "integer_42": 42,
                         "n": 6, "order": "MM", "size": 188}

    exif_ifd = fq_json(tmp_path, ["-d", "webp", "-c", "-V",
                       ".chunks[2].ifds[0].entries[] | select(.tag==\"ExifIFD\")",
                       WEBP_XMP])
    assert exif_ifd == {
        "count": 1,
        "ifd": {"entries": [
            {"count": 4, "tag": "ExifVersion", "type": "UNDEFINED",
             "value_offset": 808596274, "values": ["0232"]},
            {"count": 4, "tag": "ComponentsConfiguration",
             "type": "UNDEFINED", "value_offset": 16909056,
             "values": ["\x01\x02\x03\x00"]},
            {"count": 4, "tag": "FlashpixVersion", "type": "UNDEFINED",
             "value_offset": 808529968, "values": ["0100"]},
            {"count": 1, "tag": "ColorSpace", "type": "SHORT",
             "value_offset": 65536, "values": [1]},
            {"count": 1, "tag": "PixelXDimension", "type": "SHORT",
             "value_offset": 81264640, "values": [1240]},
            {"count": 1, "tag": "PixelYDimension", "type": "SHORT",
             "value_offset": 83886080, "values": [1280]},
        ],
            "next_ifd": 0,
            "number_of_field": 6},
        "tag": "ExifIFD",
        "type": "LONG",
        "value_offset": 110,
    }

    xmp = fq_json(tmp_path, ["-d", "webp", "-c", "-V",
                  ".chunks[3] | {id, size, align,"
                  " desc: .data[\"x:xmpmeta\"][\"rdf:RDF\"][\"rdf:Description\"]}",
                  WEBP_XMP])
    assert xmp == {
        "align": "\x00",
        "desc": {"@rdf:about": "",
                 "@xmlns:tiff": "http://ns.adobe.com/tiff/1.0/",
                 "tiff:BitsPerSample": {"rdf:Seq": {"rdf:li": "8"}},
                 "tiff:ImageLength": "1280",
                 "tiff:ImageWidth": "1240",
                 "tiff:YCbCrSubSampling": {"rdf:Seq": {"rdf:li": ["2", "2"]}}},
        "id": "XMP",
        "size": 3063,
    }
