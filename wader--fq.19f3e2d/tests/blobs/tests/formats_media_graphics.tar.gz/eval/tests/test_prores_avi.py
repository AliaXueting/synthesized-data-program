"""Black-box tests for the prores_frame decoder and the avi (RIFF) container.

Every expected value below was recorded by running the reference fq binary on
the fixtures in eval/tests/data (the raw ProRes frame fixture was extracted
from prores_frame.mov using the reference binary's mp4 decoder).
"""

import pytest

from conftest import fq_json, run_ok, run_on

PRORES = "prores/prores_frame"
PRORES_MOV = "prores/prores_frame.mov"
PCM_AVI = "riff/pcm.avi"
MP3_AVI = "riff/mp3.avi"
FLAC_AVI = "riff/flac.avi"
AVC_AVI = "riff/avc.avi"


def test_prores_frame(tmp_path):
    """prores_frame decodes the icpf container and the frame/picture headers.

    CATCHES: the container size framing, the 148 byte header field order
    (creator id, dimensions, chrominance_factor/frame_type flag nibbles,
    primaries/transfer/matrix, src_pix_fmt and alpha_info nibble split) and
    the two 64 byte quantisation matrices plus the picture data tail.
    """
    frame = fq_json(
        tmp_path,
        [
            "-d",
            "prores_frame",
            "-c",
            "-V",
            "{container, header: (.header | del(.q_mat_luma, .q_mat_chroma)), "
            "q_mats: (.header | {q_mat_flags, has_luma: has(\"q_mat_luma\"), "
            "has_chroma: has(\"q_mat_chroma\")}), "
            "has_picture_data: has(\"picture_data\")}",
            PRORES,
        ],
    )
    assert frame == {
        "container": {"size": 27673, "type": "icpf"},
        "has_picture_data": True,
        "header": {
            "alpha_info": 0,
            "color_matrix": 2,
            "creator_id": "fmpg",
            "frame_flags": {
                "chrominance_factor": "444",
                "frame_type": "progressive",
                "unused0": 0,
                "unused1": 2,
            },
            "hdr_size": 148,
            "height": 240,
            "primaries": 2,
            "q_mat_flags": 3,
            "reserved1": 0,
            "reserved2": 0,
            "src_pix_fmt": 10,
            "transf_func": 2,
            "version": 0,
            "width": 320,
        },
        "q_mats": {"has_chroma": True, "has_luma": True, "q_mat_flags": 3},
    }

    # the same frame decodes nested inside the QuickTime wrapper
    nested = fq_json(
        tmp_path,
        ["-d", "mp4", "-c", "-V", ".tracks[0].samples[0].container", PRORES_MOV],
    )
    assert nested == {"size": 27673, "type": "icpf"}


def test_prores_frame_rejects_quicktime_wrapper(tmp_path):
    """Decoding the .mov directly fails the icpf type assertion but exits 0.

    CATCHES: the container type is asserted to be "icpf"; on the QuickTime
    wrapper the assert fails, leaves a gap and still exits with code 0.
    """
    res = run_on(tmp_path, ["-d", "prores_frame", "d", PRORES_MOV])
    assert res.returncode == 0
    out = res.stdout.decode("utf-8")
    assert (
        "error: prores_frame: UTF8(type): failed at position 8 "
        "(read size 0 seek pos 0): failed to assert Str" in out
    )
    # the partially decoded container (ftyp size) is still in the value
    keys = fq_json(
        tmp_path, ["-d", "prores_frame", "-c", "-V", "keys", PRORES_MOV]
    )
    assert keys == ["container", "gap0"]


def test_avi_riff_layout(tmp_path):
    """avi decodes RIFF lists, avih/strh/strf headers, movi chunks and idx1.

    CATCHES: chunk id/list-type structure, the avih flag bit unpacking, the
    strh audio stream fields, the WAVEFORMATEX strf, the ##wb stream chunk
    decoration (stream_type/stream_nr) and the trailing idx1 index entries.
    """
    out = fq_json(
        tmp_path,
        [
            "-d",
            "avi",
            "-c",
            "-V",
            "{"
            "top: [.chunks[] | {id, type, size}], "
            "avih: ([.chunks[] | select(.id==\"LIST\" and .type==\"hdrl\") | .chunks[] "
            "| select(.id==\"avih\") | del(.reserved)][0]), "
            "strh: ([.chunks[] | select(.id==\"LIST\" and .type==\"hdrl\") | .chunks[] "
            "| select(.id==\"LIST\" and .type==\"strl\") | .chunks[] "
            "| select(.id==\"strh\")][0]), "
            "strf: ([.chunks[] | select(.id==\"LIST\" and .type==\"hdrl\") | .chunks[] "
            "| select(.id==\"LIST\" and .type==\"strl\") | .chunks[] "
            "| select(.id==\"strf\")][0]), "
            "movi: [.chunks[] | select(.id==\"LIST\" and .type==\"movi\") | .chunks[] "
            "| {id, stream_type, stream_nr, size}], "
            "idx1_head: [.chunks[] | select(.id==\"idx1\")][0].indexes[0], "
            "streams: [.streams[] | {type, handler, format_tag, compression, "
            "samples_len: (.samples|length)}]"
            "}",
            PCM_AVI,
        ],
    )
    assert out == {
        "avih": {
            "flags": {
                "copyrighted": False,
                "has_index": True,
                "is_interleaved": True,
                "must_use_index": False,
                "trust_ck_type": True,
                "unused0": "\x00",
                "unused1": "\x00",
                "unused2": "\x00",
                "unused3": "\x00",
                "unused4": "\x00",
                "was_capture_file": False,
            },
            "height": 0,
            "id": "avih",
            "initial_frames": 0,
            "max_bytes_per_sec": 88200,
            "micro_sec_per_frame": 0,
            "padding_granularity": 0,
            "size": 56,
            "streams": 1,
            "suggested_buffer_size": 1048576,
            "total_frames": 0,
            "width": 0,
        },
        "idx1_head": {
            "flags": {
                "key_frame": True,
                "list": False,
                "unused0": "\x00",
                "unused1": "\x00",
                "unused2": "\x00\x00\x00",
            },
            "id": "00wb",
            "length": 2048,
            "offset": 4,
            "stream_nr": 0,
            "stream_type": "wb",
        },
        "movi": [
            {"id": "00wb", "size": 2048, "stream_nr": 0, "stream_type": "wb"},
            {"id": "00wb", "size": 2048, "stream_nr": 0, "stream_type": "wb"},
            {"id": "00wb", "size": 2048, "stream_nr": 0, "stream_type": "wb"},
            {"id": "00wb", "size": 2048, "stream_nr": 0, "stream_type": "wb"},
            {"id": "00wb", "size": 628, "stream_nr": 0, "stream_type": "wb"},
        ],
        "streams": [
            {
                "compression": None,
                "format_tag": "pcm",
                "handler": "\x01\x00\x00\x00",
                "samples_len": 5,
                "type": "auds",
            }
        ],
        "strf": {
            "avg_bytes_per_sec": 88200,
            "bits_per_sample": 16,
            "block_align": 2,
            "channels": 1,
            "format_tag": "pcm",
            "id": "strf",
            "samples_per_sec": 44100,
            "size": 16,
        },
        "strh": {
            "flags": {
                "disabled": False,
                "pal_changes": False,
                "unused0": "\x00",
                "unused1": "\x00\x00",
                "unused2": "\x00",
            },
            "frame": {"bottom": 0, "left": 0, "right": 0, "top": 0},
            "handler": "\x01\x00\x00\x00",
            "id": "strh",
            "initial_frames": 0,
            "language": 0,
            "length": 4410,
            "priority": 0,
            "quality": 4294967295,
            "rate": 44100,
            "sample_size": 2,
            "scale": 1,
            "size": 56,
            "start": 0,
            "suggested_buffer_size": 2048,
            "type": "auds",
        },
        "top": [
            {"id": "LIST", "size": 4564, "type": "hdrl"},
            {"id": "LIST", "size": 26, "type": "INFO"},
            {"id": "JUNK", "size": 1016, "type": None},
            {"id": "LIST", "size": 8864, "type": "movi"},
            {"id": "idx1", "size": 80, "type": None},
        ],
    }


@pytest.mark.parametrize(
    "fixture,expected",
    [
        (
            MP3_AVI,
            {
                "idx1": [
                    {"id": "00wb", "key_frame": True, "length": 208, "offset": 4},
                    {"id": "00wb", "key_frame": True, "length": 209, "offset": 220},
                    {"id": "00wb", "key_frame": True, "length": 209, "offset": 438},
                ],
                "movi": [
                    {"id": "00wb", "size": 208, "stream_type": "wb"},
                    {"id": "00wb", "size": 209, "stream_type": "wb"},
                    {"id": "00wb", "size": 209, "stream_type": "wb"},
                ],
                "samples": [
                    {
                        "crc": "2e0a",
                        "header": {
                            "bitrate": 64000,
                            "channel_mode": "none",
                            "channels": "mono",
                            "copyright": 0,
                            "emphasis": "none",
                            "layer": 3,
                            "mpeg_version": "1",
                            "original": 1,
                            "padding": "not_padded",
                            "private": 0,
                            "protection_absent": True,
                            "sample_count": 1152,
                            "sample_rate": 44100,
                            "sync": 2047,
                        },
                        "main_data_begin": 0,
                        "scfsi0": 0,
                    },
                    {
                        "crc": "9950",
                        "header": {
                            "bitrate": 64000,
                            "channel_mode": "none",
                            "channels": "mono",
                            "copyright": 0,
                            "emphasis": "none",
                            "layer": 3,
                            "mpeg_version": "1",
                            "original": 1,
                            "padding": "padded",
                            "private": 0,
                            "protection_absent": True,
                            "sample_count": 1152,
                            "sample_rate": 44100,
                            "sync": 2047,
                        },
                        "main_data_begin": 9,
                        "scfsi0": 8,
                    },
                    {
                        "crc": "c36b",
                        "header": {
                            "bitrate": 64000,
                            "channel_mode": "none",
                            "channels": "mono",
                            "copyright": 0,
                            "emphasis": "none",
                            "layer": 3,
                            "mpeg_version": "1",
                            "original": 1,
                            "padding": "padded",
                            "private": 0,
                            "protection_absent": True,
                            "sample_count": 1152,
                            "sample_rate": 44100,
                            "sync": 2047,
                        },
                        "main_data_begin": 27,
                        "scfsi0": 0,
                    },
                ],
                "strf": {
                    "avg_bytes_per_sec": 0,
                    "bits_per_sample": 0,
                    "block_align": 1152,
                    "cb_size": 12,
                    "channels": 1,
                    "format_tag": "mp3",
                    "id": "strf",
                    "samples_per_sec": 44100,
                    "size": 30,
                },
            },
        ),
        (
            FLAC_AVI,
            {
                "movi": [
                    {"id": "00wb", "size": 602, "stream_type": "wb"},
                    {"id": "00wb", "size": 0, "stream_type": "wb"},
                ],
                "samples": [
                    {
                        "footer_crc": "7b66",
                        "header": {
                            "block_size": 7,
                            "blocking_strategy": "fixed",
                            "channel_assignment": 1,
                            "crc": 20,
                            "end_of_header": {"block_size": 2205, "frame_number": 0},
                            "reserved0": 0,
                            "reserved1": 0,
                            "sample_rate": 44100,
                            "sample_size": 16,
                            "sync": 16382,
                        },
                        "subframes_len": 1,
                    },
                    {"footer_crc": None, "header": None, "subframes_len": None},
                ],
                "strf": {
                    "avg_bytes_per_sec": 16000,
                    "bits_per_sample": 16,
                    "block_align": 2,
                    "cb_size": 34,
                    "channels": 1,
                    "format_tag": "flac",
                    "id": "strf",
                    "samples_per_sec": 44100,
                    "size": 52,
                },
            },
        ),
        (
            AVC_AVI,
            {
                "idx1": [
                    {"id": "00dc", "key_frame": True, "length": 3057, "offset": 4},
                    {"id": "00dc", "key_frame": False, "length": 333, "offset": 3070},
                    {"id": "00dc", "key_frame": False, "length": 56, "offset": 3412},
                ],
                "movi": [
                    {"id": "00dc", "size": 3057, "stream_type": "dc"},
                    {"id": "00dc", "size": 333, "stream_type": "dc"},
                    {"id": "00dc", "size": 56, "stream_type": "dc"},
                ],
                "samples": [
                    [
                        {"sc": "\x00\x00\x00\x01"},
                        {"forbidden": False, "ref": 3, "t": "sps"},
                        {"sc": "\x00\x00\x00\x01"},
                        {"forbidden": False, "ref": 3, "t": "pps"},
                        {"sc": "\x00\x00\x01"},
                        {"forbidden": False, "ref": 0, "t": "sei"},
                        {"sc": "\x00\x00\x01"},
                        {"forbidden": False, "ref": 3, "t": "idr_slice"},
                    ],
                    [
                        {"sc": "\x00\x00\x00\x01"},
                        {"forbidden": False, "ref": 2, "t": "slice"},
                    ],
                    [
                        {"sc": "\x00\x00\x00\x01"},
                        {"forbidden": False, "ref": 0, "t": "slice"},
                    ],
                ],
                "strf": {
                    "bi_size": 40,
                    "bit_count": 24,
                    "clr_important": 0,
                    "clr_used": 0,
                    "compression": "H264",
                    "height": 240,
                    "id": "strf",
                    "planes": 1,
                    "size": 40,
                    "size_image": 230400,
                    "width": 320,
                    "x_pels_per_meter": 0,
                    "y_pels_per_meter": 0,
                },
            },
        ),
    ],
)
def test_avi_compressed_streams(tmp_path, fixture, expected):
    """avi decodes mp3/flac/avc samples nested inside the stream chunks.

    CATCHES: the format_tag/compression driven choice of nested decoder for
    each stream (mp3_frame, flac_frame, avc_au), the interleaved start code +
    NAL unit arrays for avc and the idx1 driven sample/keyframe reconstruction.
    """
    idx1_expr = (
        ", idx1: [.chunks[] | select(.id==\"idx1\")][0].indexes "
        "| [.[] | {id, offset, length, key_frame: .flags.key_frame}]"
        if fixture != FLAC_AVI
        else ""
    )
    if fixture == AVC_AVI:
        samples_expr = (
            "[.streams[0].samples[] | [.[] | if type == \"object\" "
            "then {t: .nal_unit_type, ref: .nal_ref_idc, "
            "forbidden: .forbidden_zero_bit} else {sc: .} end]]"
        )
        strf_expr = (
            "([.chunks[] | select(.id==\"LIST\" and .type==\"hdrl\") | .chunks[] "
            "| select(.id==\"LIST\" and .type==\"strl\") | .chunks[] "
            "| select(.id==\"strf\")][0])"
        )
    else:
        samples_expr = (
            "[.streams[0].samples[] | "
            + (
                "{header: .header, crc: .crc_calculated, "
                "main_data_begin: .side_info.main_data_begin, "
                "scfsi0: .side_info.scfsi0}"
                if fixture == MP3_AVI
                else "{header: .header, footer_crc, "
                "subframes_len: (if .subframes then (.subframes|length) "
                "else null end)}"
            )
            + "]"
        )
        strf_expr = (
            "([.chunks[] | select(.id==\"LIST\" and .type==\"hdrl\") | .chunks[] "
            "| select(.id==\"LIST\" and .type==\"strl\") | .chunks[] "
            "| select(.id==\"strf\") | del(.extra)][0])"
        )
    expr = (
        "{"
        "movi: [.chunks[] | select(.id==\"LIST\" and .type==\"movi\") | .chunks[] "
        "| {id, stream_type, size}], "
        f"strf: {strf_expr}, "
        f"samples: {samples_expr}"
        f"{idx1_expr}"
        "}"
    )
    out = fq_json(tmp_path, ["-d", "avi", "-c", "-V", expr, fixture])
    assert out == expected


def test_avi_decode_options(tmp_path):
    """decode_samples and decode_extended_chunks change what avi decodes.

    CATCHES: with decode_samples=false the movi chunk data and the indexed
    samples stay raw binary instead of nested decodes, and disabling
    decode_extended_chunks drops the extended_chunks field from the value.
    """
    raw = fq_json(
        tmp_path,
        [
            "-o",
            "decode_samples=false",
            "-d",
            "avi",
            "-c",
            "-V",
            "{sample_types: [.streams[0].samples[] | type], "
            "movi_chunk0_keys: ([.chunks[] | select(.id==\"LIST\" and "
            ".type==\"movi\") | .chunks[0] | keys])}",
            MP3_AVI,
        ],
    )
    assert raw == {
        "movi_chunk0_keys": [["id", "stream_type", "stream_nr", "size", "data"]],
        "sample_types": ["string", "string", "string"],
    }

    decoded = fq_json(
        tmp_path,
        [
            "-d",
            "avi",
            "-c",
            "-V",
            "{sample_types: [.streams[0].samples[] | type], "
            "movi_chunk0_data_keys: ([.chunks[] | select(.id==\"LIST\" and "
            ".type==\"movi\") | .chunks[0].data | keys])}",
            MP3_AVI,
        ],
    )
    assert decoded == {
        "movi_chunk0_data_keys": [["header", "side_info", "audio_data", "crc_calculated"]],
        "sample_types": ["object", "object", "object"],
    }

    no_ext = run_ok(
        tmp_path,
        ["-o", "decode_extended_chunks=false", "-d", "avi", "-c", "-V", "keys", PCM_AVI],
    )
    assert no_ext == '["id","size","type","chunks","streams"]'
    with_ext = run_ok(tmp_path, ["-d", "avi", "-c", "-V", "keys", PCM_AVI])
    assert with_ext == '["id","size","type","chunks","streams","extended_chunks"]'
