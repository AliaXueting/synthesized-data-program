"""I/O interaction tests: stdin/file input, stdout/stderr separation, exit
codes and output formatting for the media decoders.

Every expected value below was recorded by running the reference fq binary.
"""

from conftest import fq_json, run_ok, run_on

MP3 = "mp3/headerfooter.mp3"
UNKNOWN = "mp3/unknown.mp3"
GIF = "gif/4x4.gif"
PNG = "png/4x4.png"
PPS = "mpeg/avc_pps_stop_more_8bit"

# Exact `d` display of the 4 byte avc_pps fixture (path is the basename
# because the child always runs with cwd=tmp_path).
PPS_DISPLAY = """\
   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: avc_pps_stop_more_8bit (avc_pps)
0x0|ce                                             |.               |  pic_parameter_set_id: 0
0x0|ce                                             |.               |  seq_parameter_set_id: 0
0x0|ce                                             |.               |  entropy_coding_mode_flag: false
0x0|ce                                             |.               |  bottom_field_pic_order_in_frame_present_flag: false
0x0|ce                                             |.               |  num_slice_groups: 1
0x0|ce                                             |.               |  num_ref_idx_l0_default_active: 1
0x0|ce                                             |.               |  num_ref_idx_l1_default_active: 1
0x0|ce                                             |.               |  weighted_pred_flag: false
0x0|   1f                                          | .              |  weighted_bipred_idc: 0
0x0|   1f                                          | .              |  pic_init_qp: 25
0x0|   1f                                          | .              |  pic_init_qs: 26
0x0|   1f                                          | .              |  chroma_qp_index_offset: 0
0x0|   1f                                          | .              |  deblocking_filter_control_present_flag: true
0x0|      20                                       |                |  constrained_intra_pred_flag: false
0x0|      20                                       |                |  redundant_pic_cnt_present_flag: false
0x0|      20                                       |                |  stop_one_bit: true
0x0|      20 00|                                   |   .|           |  trailing_bits: raw bits
"""


def test_decode_mp3_from_stdin(tmp_path):
    """A piped file is decoded when no file argument is given (or '-' is).

    CATCHES: stdin handling for binary input — the decoder must read the
    whole stream from stdin exactly like a file argument.
    """
    import pathlib

    data = (pathlib.Path(__file__).parent / "data" / MP3).read_bytes()
    res = run_on(tmp_path, ["-c", "-V", "-d", "mp3", ".frames|length"], stdin=data)
    assert res.returncode == 0
    assert res.stdout.decode("utf-8") == "2\n"
    assert res.stderr == b""

    res_dash = run_on(tmp_path, ["-c", "-V", "-d", "mp3", ".frames|length", "-"], stdin=data)
    assert res_dash.returncode == 0
    assert res_dash.stdout.decode("utf-8") == "2\n"


def test_missing_file_error(tmp_path):
    """A missing input file exits 2 with the error on stderr only.

    CATCHES: exit code choice for file open errors and stdout/stderr
    separation (stdout must stay empty, message goes to stderr).
    """
    res = run_on(tmp_path, ["d", "no-such-file.png"])
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.decode("utf-8") == "error: no-such-file.png: no such file or directory\n"


def test_unknown_format_name_error(tmp_path):
    """An unknown -d name exits 4 with 'format group not found' on stderr.

    CATCHES: the error wording and exit code for unknown decoder names,
    which is how a re-implementation would fail the -d contract.
    """
    res = run_on(tmp_path, ["-d", "nosuchformat", "d", GIF])
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.decode("utf-8") == \
        "error: 4x4.gif: nosuchformat: format group not found\n"


def test_expression_error_exit_code(tmp_path):
    """An undefined function in the expression exits 3 with a stderr error.

    CATCHES: expression compile errors must not be reported as decode or
    file errors — distinct exit code and message per error class.
    """
    res = run_on(tmp_path, ["zzz(1)", GIF])
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr.decode("utf-8") == "error: arg: function not defined: zzz/1\n"


def test_probe_failure_exit_code_and_stderr(tmp_path):
    """Auto-probing an undecodable file exits 4 and suggests forcing -d.

    CATCHES: the probe path must fail (not fall back to raw bytes) with this
    exact stderr hint when no registered decoder accepts the file.
    """
    res = run_on(tmp_path, ["d", UNKNOWN])
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.decode("utf-8") == (
        "error: unknown.mp3: probe: failed to decode: "
        "try fq -d FORMAT to force format, see fq -h formats for list\n"
    )


def test_forced_decode_error_is_reported_inline(tmp_path):
    """A forced -d mp3 decode of a bad file keeps exit 0 with an error line.

    CATCHES: with an explicit format the decode error is embedded in the
    displayed value (error: ... line on stdout) instead of failing the run.
    """
    res = run_on(tmp_path, ["-d", "mp3", "d", UNKNOWN])
    assert res.returncode == 0
    assert res.stderr == b""
    out = res.stdout.decode("utf-8")
    assert "error: mp3: error at position 0x365: exceeds max precent unknown bits, 73 > 50" in out
    # the frame chain and the trailing gap are still rendered around the error
    assert len(out.splitlines()) == 288


def test_default_display_output_exact(tmp_path):
    """The default `d` display renders the hexdump format exactly.

    CATCHES: byte offset column, hex/ascii columns and field lines of the
    display (including un-byte-aligned bit fields like pic_init_qp).
    """
    out = run_ok(tmp_path, ["-d", "avc_pps", "d", PPS])
    assert out == PPS_DISPLAY.rstrip("\n")


def test_compact_and_pretty_json_output(tmp_path):
    """-c -V prints one compact JSON line; -V prints 2-space pretty JSON.

    CATCHES: the two JSON output modes and their exact separators.
    """
    compact = run_ok(tmp_path, ["-c", "-V", "-d", "gif", "{sig: .header, w: .width}", GIF])
    assert compact == '{"sig":"GIF89a","w":4}'
    pretty = run_ok(tmp_path, ["-V", "-d", "gif", "{sig: .header, w: .width}", GIF])
    assert pretty == '{\n  "sig": "GIF89a",\n  "w": 4\n}'


def test_raw_and_join_string_output(tmp_path):
    """-Vr prints strings raw with newline; -Vj joins without the newline.

    CATCHES: raw string output must not be JSON quoted; join output drops
    the trailing newline.
    """
    raw = run_on(tmp_path, ["-Vr", "-d", "mp3", ".headers[0].frames[0].text", MP3])
    assert raw.returncode == 0
    assert raw.stdout == b"test\n"

    joined = run_on(tmp_path, ["-Vj", "-d", "mp3", ".headers[0].frames[0].text", MP3])
    assert joined.returncode == 0
    assert joined.stdout == b"test"


def test_tobytes_binary_roundtrip(tmp_path):
    """tobytes emits raw sample bytes that re-decode with the codec decoder.

    CATCHES: binary (non-UTF8) stdout must survive byte-exactly so the
    extracted frame can be decoded again as an mp3_frame.
    """
    res = run_on(tmp_path, ["-d", "mp3", ".frames[0] | tobytes", MP3])
    assert res.returncode == 0
    assert len(res.stdout) == 208

    (tmp_path / "frame0.mp3").write_bytes(res.stdout)
    header = fq_json(tmp_path, ["-c", "-V", "-d", "mp3_frame", ".header", "frame0.mp3"])
    assert header["bitrate"] == 64000
    assert header["sample_rate"] == 44100
    assert header["channels"] == "mono"


def test_format_group_decode(tmp_path):
    """-d image probes all image decoders and decodes png/gif members.

    CATCHES: group (not format) decoding must try every decoder in the
    group and pick the right one per file.
    """
    png = fq_json(tmp_path, ["-c", "-V", "-d", "image",
                             "{keys: keys, color_type: .chunks[0].color_type}", PNG])
    assert png == {"keys": ["signature", "chunks"], "color_type": "grayscale"}

    gif = fq_json(tmp_path, ["-c", "-V", "-d", "image", "{sig: .header, w: .width}", GIF])
    assert gif == {"sig": "GIF89a", "w": 4}


def test_multiple_input_files_and_slurp(tmp_path):
    """Multiple file arguments produce one output each; -s collects them.

    CATCHES: per-input expression evaluation and the slurp array wrapping
    of all decoded inputs.
    """
    res = run_on(tmp_path, ["-c", "-V", "-d", "gif", ".width", GIF, GIF])
    assert res.returncode == 0
    assert res.stdout.decode("utf-8") == "4\n4\n"

    slurped = fq_json(tmp_path, ["-s", "-c", "-V", "-d", "gif", "length", GIF, GIF])
    assert slurped == 2


def test_null_input_decode_from_base64(tmp_path):
    """-n builds a value from an expression and decodes it with a function.

    CATCHES: the function-call form mp4({force:true}) must accept a value
    pipeline (not just files) and still honor decoder options.
    """
    out = run_ok(tmp_path, [
        "-n", "-c", "-V",
        '"AAAAHGVsc3QAAAAAAAAAAQAAADIAAAQAAAEAAA==" | from_base64 | mp4({force:true}) | keys',
    ])
    assert out == '["boxes"]'
