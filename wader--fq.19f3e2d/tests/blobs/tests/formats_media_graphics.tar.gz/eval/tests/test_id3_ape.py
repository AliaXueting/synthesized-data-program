"""Black-box tests for the id3v1/id3v11/id3v2 and apev2 metadata decoders.

Every expected value below was recorded by running the reference fq binary on the
fixtures in eval/tests/data.  The crafted fixtures (id3v1_track, id3v1_enhanced,
id3v23_ext, id3v24_ext, apev2_binary) were built with a small python script so
that decoder paths not covered by the shipped fixtures are pinned too.
"""

import pytest

from conftest import fq_json, run_on

ID3V1 = "id3/id3v1"
# a v1.1 tag: 28 byte comment, a zero byte, a track number (7) and genre 17
ID3V1_TRACK = "id3/id3v1_track"
# an enhanced "TAG+" v1.1 tag (227 bytes) for the id3v11 decoder
ID3V1_ENHANCED = "id3/id3v1_enhanced"
ID3V23 = "id3/id3v23"
ID3V24 = "id3/id3v24"
# crafted v2.3/v2.4 tags with an extended header and a frame whose size field is
# 00 00 01 00 (256 as a plain 32 bit int, 128 as a syncsafe int)
ID3V23_EXT = "id3/id3v23_ext"
ID3V24_EXT = "id3/id3v24_ext"
APIC = "id3/apic"
UTF16_APIC = "id3/utf16-apic"
TXXX_WXXX = "id3/txxx-wxxx"
TXXX_NONULLTERM = "id3/txxx-nonullterm"
CTOC = "id3/ctoc"
# crafted v2.4 tag holding a single CHAP frame with an embedded TIT2 sub-frame
ID3V24_CHAP = "id3/id3v24_chap"
# crafted v2.4 tag with one frame carrying the frame-level unsync flag: its data
# contains 0xff 0x00 pairs that must collapse to a single 0xff when decoded
ID3V24_UNSYNC = "id3/id3v24_unsync"
APEV2 = "ape/apev2"
# crafted APEv2 tag with one text item and one binary (image) item
APEV2_BINARY = "ape/apev2_binary"


@pytest.mark.parametrize("fixture,expected", [
    (ID3V1, {
        "album_name": "",
        "artist": "",
        "comment": "",
        "genre": 255,
        "magic": "TAG",
        "song_name": "test",
        "year": "",
    }),
    (ID3V1_TRACK, {
        "album_name": "An Album",
        "artist": "The Artist",
        "comment": "a 28 char comment here!",
        "genre": "rock",
        "magic": "TAG",
        "song_name": "Song One",
        "year": "2021",
    }),
])
def test_id3v1_fixed_width_fields(fixture, expected, tmp_path):
    """id3v1 decodes the 128 byte tag with 30/30/30/4/30 byte fixed fields.

    CATCHES: the strings are null terminated inside their fixed width fields, the
    v1.1 zero-then-track bytes at the end of the comment field are swallowed by
    that field, and the genre byte maps through the genre symbol table (17 ->
    "rock") while unmapped values (255) stay numeric.
    """
    tag = fq_json(tmp_path, ["-c", "-V", "-d", "id3v1", ".", fixture])
    assert tag == expected


def test_id3v11_enhanced_tag(tmp_path):
    """id3v11 decodes the 227 byte enhanced "TAG+" tag with its own field widths.

    CATCHES: id3v11 uses 60/60/60 byte title/artist/album fields that are *not*
    null trimmed, a symbolic speed byte, 30 byte genre and 6 byte start/stop
    fields; a plain "TAG" tag is rejected because the magic must be "TAG+".
    """
    fields = fq_json(tmp_path, ["-c", "-V", "-d", "id3v11",
                   "{magic, speed, title: .title[0:15], artist: .artist[0:16],"
                   " album_len: (.album | length), genre: .genre[0:8]}",
                   ID3V1_ENHANCED])
    assert fields == {
        "magic": "TAG+",
        "speed": "medium",
        "title": "Enhanced Title\u0000",
        "artist": "Enhanced Artist\u0000",
        "album_len": 60,
        "genre": "Rock/Pop",
    }

    widths = fq_json(tmp_path, ["-c", "-V", "-d", "id3v11",
                   "{title_len: (.title | length), artist_len: (.artist | length),"
                   " genre_len: (.genre | length), start: .start[0:5],"
                   " start_len: (.start | length), stop: .stop[0:5],"
                   " stop_len: (.stop | length)}",
                   ID3V1_ENHANCED])
    assert widths == {
        "title_len": 60,
        "artist_len": 60,
        "genre_len": 30,
        "start": "01:23",
        "start_len": 6,
        "stop": "04:56",
        "stop_len": 6,
    }

    res = run_on(tmp_path, ["-d", "id3v11", "d", ID3V1])
    assert res.returncode == 0
    assert "error: id3v11: UTF8(magic): failed at position 4" in res.stdout.decode("utf-8")
    gap = fq_json(tmp_path, ["-c", "-V", "-d", "id3v11", ".gap0 | length", ID3V1])
    assert gap == 128


@pytest.mark.parametrize("fixture,version,encoding,flags", [
    (ID3V23, 3, "iso_8859-1", {
        "compression": False, "encryption": False, "file_alter_preservation": False,
        "grouping_identity": False, "read_only": False,
        "tag_alter_preservation": False, "unused0": 0, "unused1": 0,
    }),
    (ID3V24, 4, "utf8", {
        "compression": False, "data_length_indicator": False, "encryption": False,
        "file_alter_preservation": False, "grouping_identity": False,
        "read_only": False, "tag_alter_preservation": False, "unsync": False,
        "unused0": 0, "unused1": 0, "unused2": 0,
    }),
])
def test_id3v2_header_and_frame_flags(fixture, version, encoding, flags, tmp_path):
    """The id3v2 header and per-frame flag bits differ between v2.3 and v2.4.

    CATCHES: the header flag byte layout (unsync/extended/experimental plus 5
    unused bits) and the v2.3 vs v2.4 frame flag bit layouts, including the
    v2.4-only unsync and data_length_indicator bits.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "{header, frame: (.frames[0] | {id, size, flags, text_encoding, text}),"
                   " padding_len: (.padding | length)}",
                   fixture])
    assert out["header"] == {
        "flags": {
            "experimental_indicator": False,
            "extended_header": False,
            "unsynchronisation": False,
            "unused": 0,
        },
        "magic": "ID3",
        "revision": 0,
        "size": 35,
        "version": version,
    }
    assert out["frame"] == {
        "id": "TSSE",
        "size": 15,
        "flags": flags,
        "text_encoding": encoding,
        "text": "Lavf58.45.100",
    }
    assert out["padding_len"] == 10


@pytest.mark.parametrize("fixture,version,size,data_size,encoding,ext_data,flags", [
    (ID3V23_EXT, 3, 276, 256, "iso_8859-1", "\u0011\"3DUf", {
        "compression": False, "encryption": False, "file_alter_preservation": False,
        "grouping_identity": True, "read_only": True, "tag_alter_preservation": True,
        "unused0": 0, "unused1": 0,
    }),
    (ID3V24_EXT, 4, 144, 128, "utf8", "\u00124", {
        "compression": False, "data_length_indicator": False, "encryption": False,
        "file_alter_preservation": False, "grouping_identity": True, "read_only": False,
        "tag_alter_preservation": True, "unsync": False,
        "unused0": 0, "unused1": 0, "unused2": 0,
    }),
])
def test_id3v2_frame_size_encoding(fixture, version, size, data_size, encoding,
                                   ext_data, flags, tmp_path):
    """v2.3 frame/extended sizes are plain ints, v2.4 uses syncsafe integers.

    CATCHES: the raw size bytes 00 00 01 00 must decode as 256 in a v2.3 tag but
    as 128 in a v2.4 tag, the v2.4 extended header size includes itself while the
    v2.3 one does not, and the header size is always syncsafe.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "{header, extended_header, frames: [.frames[]"
                   " | {id, size, flags, text_encoding, text_len: (.text | length)}]}",
                   fixture])
    assert out["header"] == {
        "flags": {
            "experimental_indicator": False,
            "extended_header": True,
            "unsynchronisation": False,
            "unused": 0,
        },
        "magic": "ID3",
        "revision": 0,
        "size": size,
        "version": version,
    }
    assert out["extended_header"] == {"data": ext_data, "size": 6}
    assert out["frames"] == [{
        "id": "TSSE",
        "size": data_size,
        "flags": flags,
        "text_encoding": encoding,
        "text_len": data_size - 1,
    }]


@pytest.mark.parametrize("fixture,expected_frames,chunk_types", [
    (APIC, [
        {"id": "TSSE", "size": 15, "text_encoding": "utf8", "text": "Lavf58.76.100",
         "mime_type": None, "description": None, "picture_type": None},
        {"id": "APIC", "size": 125, "text_encoding": "utf8", "text": None,
         "mime_type": "image/png", "description": "", "picture_type": 0},
    ], ["IHDR", "pHYs", "IDAT", "IEND"]),
    (UTF16_APIC, [
        {"id": "APIC", "size": 283, "text_encoding": "utf16", "text": None,
         "mime_type": "image/png", "description": "test", "picture_type": 0},
        {"id": "TSSE", "size": 29, "text_encoding": "utf16", "text": "Lavf58.76.100",
         "mime_type": None, "description": None, "picture_type": None},
    ], ["IHDR", "gAMA", "cHRM", "bKGD", "tIME", "IDAT", "tEXt", "tEXt", "IEND"]),
])
def test_id3v2_apic_frames(fixture, expected_frames, chunk_types, tmp_path):
    """APIC frames decode the encoding byte, mime, picture type and description.

    CATCHES: the mime type is always a null terminated latin1 string while the
    description uses the frame's text encoding (utf8 vs utf16 with a BOM), and the
    picture payload is handed to the image decoder (png chunk chain).
    """
    frames = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "[.frames[] | {id, size, text_encoding, mime_type, description,"
                   " picture_type, text}]",
                   fixture])
    assert frames == expected_frames

    pictures = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "[.frames[] | select(.picture != null)"
                   " | {n: (.picture.chunks | length), types: [.picture.chunks[] | .type],"
                   " ihdr: (.picture.chunks[0] | {width, height, bit_depth, color_type})}]",
                   fixture])
    assert pictures == [{
        "n": len(chunk_types),
        "types": chunk_types,
        "ihdr": {"bit_depth": 8 if fixture == APIC else 1,
                 "color_type": "rgb" if fixture == APIC else "grayscale",
                 "height": 4,
                 "width": 4},
    }]


def test_id3v2_user_defined_frames(tmp_path):
    """TXXX/WXXX user frames and plain W frames decode description plus payload.

    CATCHES: TXXX and WXXX carry a text encoding byte and a null terminated
    description before their value/url, while plain URL frames (WCOM) have no
    encoding byte at all, and the mp3 payload after the tag becomes a gap.
    """
    frames = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "[.frames[] | {id, size, text_encoding, description, value, url, text}]",
                   TXXX_WXXX])
    assert frames == [
        {"id": "TSSE", "size": 13, "text_encoding": "utf8", "description": None,
         "value": None, "url": None, "text": "Lavf60.3.100"},
        {"id": "TXXX", "size": 20, "text_encoding": "utf8", "description": "txxx-desc",
         "value": "txxx-text", "url": None, "text": None},
        {"id": "WCOM", "size": 8, "text_encoding": None, "description": None,
         "value": None, "url": "wcom-url", "text": None},
        {"id": "WXXX", "size": 19, "text_encoding": "iso_8859-1", "description": "wxxx-desc",
         "value": None, "url": "wxxx-url", "text": None},
    ]

    out = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "{version: .header.version, size: .header.size,"
                   " nframes: (.frames | length), has_gap: has(\"gap0\")}",
                   TXXX_WXXX])
    assert out == {"version": 4, "size": 356, "nframes": 4, "has_gap": True}


def test_id3v2_txxx_without_null_termination(tmp_path):
    """A TXXX frame whose description has no null terminator still decodes.

    CATCHES: when no null is found the description swallows the whole frame body
    (here the utf16 string "Software") and the value ends up empty instead of the
    decoder failing.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "{version: .header.version, size: .header.size,"
                   " frames: [.frames[] | {id, size, text_encoding, description, value}]}",
                   TXXX_NONULLTERM])
    assert out == {
        "version": 3,
        "size": 29,
        "frames": [{
            "id": "TXXX",
            "size": 19,
            "text_encoding": "utf16",
            "description": "Software",
            "value": "",
        }],
    }


def test_id3v2_ctoc_frame(tmp_path):
    """A CTOC frame decodes element ids, flags, child entries and sub-frames.

    CATCHES: the element id is null terminated, the two flag bits are named
    top_level/order, entry_count drives the child element id list and the
    remaining bytes are decoded as embedded id3v2 frames (here a utf16 TIT2).
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "{version: .header.version, size: .header.size,"
                   " frame: (.frames[0] | {id, size, element_id, ctoc_flags,"
                   " entry_count, entries}),"
                   " subframes: [.frames[0].frames[] | {id, size, text, text_encoding}]}",
                   CTOC])
    assert out == {
        "version": 3,
        "size": 149,
        "frame": {
            "id": "CTOC",
            "size": 139,
            "element_id": "TOCM",
            "ctoc_flags": {"order": True, "top_level": True, "unused0": 0},
            "entry_count": 19,
            "entries": ["ch%d" % i for i in range(19)],
        },
        "subframes": [{
            "id": "TIT2",
            "size": 37,
            "text": "Table of contents",
            "text_encoding": "utf16",
        }],
    }


def test_id3v2_chap_frame(tmp_path):
    """A CHAP frame decodes its element id, times, offsets and sub-frames.

    CATCHES: the chapter element id is null terminated, the four 32 bit
    start/end time and offset fields (0xffffffff kept as-is) are followed by a
    recursively decoded frame list.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "{header, frames: [.frames[] | {id, size, element_id,"
                   " start_time, end_time, start_offset, end_offset,"
                   " subframes: [.frames[] | {id, size, text, text_encoding}]}]}",
                   ID3V24_CHAP])
    assert out == {
        "header": {
            "flags": {
                "experimental_indicator": False,
                "extended_header": False,
                "unsynchronisation": False,
                "unused": 0,
            },
            "magic": "ID3",
            "revision": 0,
            "size": 52,
            "version": 4,
        },
        "frames": [{
            "id": "CHAP",
            "size": 42,
            "element_id": "ch1",
            "start_time": 0,
            "end_time": 1000,
            "start_offset": 4294967295,
            "end_offset": 4294967295,
            "subframes": [{
                "id": "TIT2",
                "size": 12,
                "text": "Chapter One",
                "text_encoding": "utf8",
            }],
        }],
    }


def test_id3v2_unsynchronized_frame(tmp_path):
    """A v2.4 frame with the unsync flag has its 0xff 0x00 pairs collapsed.

    CATCHES: the frame size and the raw `data` field count the stored bytes
    (8), while the `unsync` sub-value decodes the de-unsynchronised stream so
    the text shrinks by one character per 0xff 0x00 pair (5 characters for two
    pairs); the tag-level unsynchronisation header flag stays false.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "id3v2",
                   "{header, frames: [.frames[] | {id, size,"
                   " unsync_flag: .flags.unsync, data_len: (.data | length),"
                   " text_len: (.unsync.text | length),"
                   " text_encoding: .unsync.text_encoding}]}",
                   ID3V24_UNSYNC])
    assert out == {
        "header": {
            "flags": {
                "experimental_indicator": False,
                "extended_header": False,
                "unsynchronisation": False,
                "unused": 0,
            },
            "magic": "ID3",
            "revision": 0,
            "size": 18,
            "version": 4,
        },
        "frames": [{
            "id": "TIT2",
            "size": 8,
            "unsync_flag": True,
            "data_len": 8,
            "text_len": 5,
            "text_encoding": "utf8",
        }],
    }


@pytest.mark.parametrize("fixture,tag_size,item_count,items", [
    (APEV2, 142, 3, [
        {"key": "MP3GAIN_MINMAX", "item_size": 7, "binary": False,
         "key_terminator": 0, "value": "144,210"},
        {"key": "REPLAYGAIN_TRACK_GAIN", "item_size": 12, "binary": False,
         "key_terminator": 0, "value": "+13.75000 dB"},
        {"key": "REPLAYGAIN_TRACK_PEAK", "item_size": 8, "binary": False,
         "key_terminator": 0, "value": "0.084665"},
    ]),
    (APEV2_BINARY, 166, 2, [
        {"key": "Title", "item_size": 16, "binary": False,
         "key_terminator": 0, "value": "Binary Tag Title"},
        {"key": "Cover Art (Front)", "item_size": 78, "binary": True,
         "key_terminator": 0, "value": {"filename": "cover.png",
                                        "types": ["IHDR", "IDAT", "IEND"]}},
    ]),
])
def test_apev2_tag(fixture, tag_size, item_count, items, tmp_path):
    """apev2 decodes the APETAGEX header, the item list and the footer.

    CATCHES: little endian 32 bit fields, the 8 byte magic, the header flag value
    0xa0000000 vs the footer flag 0x80000000, the all zero reserved field, keys
    terminated by a zero byte and binary items being parsed as filename + image.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "apev2",
                   "{header, footer, tags: [.tags[] | {key, item_size,"
                   " binary: .item_flags.binary, key_terminator,"
                   " value: (if (.value | type) == \"string\" then .value"
                   " else {filename, types: [.value.chunks[] | .type]} end)}]}",
                   fixture])
    assert out["header"] == {
        "flags": 2684354560,
        "item_count": item_count,
        "preamble": "APETAGEX",
        "reserved": "\x00" * 8,
        "tag_size": tag_size,
        "version": 2000,
    }
    assert out["footer"] == {
        "flags": 2147483648,
        "item_count": item_count,
        "preamble": "APETAGEX",
        "reserved": "\x00" * 8,
        "tag_size": tag_size,
        "version": 2000,
    }
    assert out["tags"] == items
