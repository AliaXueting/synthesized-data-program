"""Black-box tests for the icc_profile, midi, moc3 and stl decoders.

Every expected value below was recorded by running the reference fq binary on
the fixtures in eval/tests/data (icc/, midi/, moc3/ and stl/).
"""

import pytest

from conftest import fq_json, run_ok, run_on

SRGB = "icc/sRGB2014.icc"
ADOBE = "icc/adobe_linear.icc"
MOC3 = "moc3/archchan_sdk5.moc3"
STL = "stl/file.stl"
STL_ATTR = "stl/attr.stl"
STL_ASCII = "stl/ascii.stl"


# ---------------------------------------------------------------------------
# icc_profile
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("fixture,expected", [
    (SRGB, {
        "attr_len": 0,
        "cmm_type_signature": "",
        "color_space": "RGB",
        "connection_space": "XYZ",
        "device_class_signature": "mntr",
        "device_manufacturer": "",
        "device_model": "",
        "file_signature": "acsp",
        "flags": 0,
        "illuminant_len": 0,
        "pid_len": 14,
        "primary_platform": "",
        "profile_creator_signature": "",
        "render_intent": "",
        "reserved_len": 28,
        "size": 3024,
        "timestamp": {"day": 15, "hours": 0, "minutes": 0, "month": 2,
                      "seconds": 0, "year": 2015},
        "version_major": 2,
        "version_minor": 0,
        "version_reserved": 0,
    }),
    (ADOBE, {
        "attr_len": 0,
        "cmm_type_signature": "ADBE",
        "color_space": "RGB",
        "connection_space": "XYZ",
        "device_class_signature": "mntr",
        "device_manufacturer": "none",
        "device_model": "",
        "file_signature": "acsp",
        "flags": 0,
        "illuminant_len": 0,
        "pid_len": 0,
        "primary_platform": "APPL",
        "profile_creator_signature": "ADBE",
        "render_intent": "",
        "reserved_len": 28,
        "size": 516,
        "timestamp": {"day": 21, "hours": 20, "minutes": 25, "month": 7,
                      "seconds": 26, "year": 2021},
        "version_major": 2,
        "version_minor": 40,
        "version_reserved": 0,
    }),
])
def test_icc_profile_header(tmp_path, fixture, expected):
    """The 128 byte ICC header decodes with BCD version and trimmed signatures.

    CATCHES: profile size framing, BCD major/minor version digits (2.40 for
    Adobe), device class/color space/PCS signatures, the 'acsp' file
    signature, creation timestamp and the 28 byte zero reserved tail.
    """
    out = fq_json(tmp_path, ["-d", "icc_profile", "-c", "-V",
                   ".header | del(.profile_id, .reserved, .xyz_illuminant, .device_attribute)"
                   " + {pid_len: (.profile_id|length), reserved_len: (.reserved|length),"
                   " illuminant_len: (.xyz_illuminant|length), attr_len: (.device_attribute|length)}",
                   fixture])
    assert out == expected


@pytest.mark.parametrize("fixture,expected", [
    (SRGB, [
        {"offset": 324, "sig": "desc", "size": 99, "type": "desc"},
        {"offset": 424, "sig": "bXYZ", "size": 20, "type": "XYZ"},
        {"offset": 444, "sig": "bTRC", "size": 2060, "type": "curv"},
        {"offset": 444, "sig": "gTRC", "size": 2060, "type": "curv"},
        {"offset": 444, "sig": "rTRC", "size": 2060, "type": "curv"},
        {"offset": 2504, "sig": "dmdd", "size": 136, "type": "desc"},
        {"offset": 2640, "sig": "gXYZ", "size": 20, "type": "XYZ"},
        {"offset": 2660, "sig": "lumi", "size": 20, "type": "XYZ"},
        {"offset": 2680, "sig": "meas", "size": 36, "type": "meas"},
        {"offset": 2716, "sig": "bkpt", "size": 20, "type": "XYZ"},
        {"offset": 2736, "sig": "rXYZ", "size": 20, "type": "XYZ"},
        {"offset": 2756, "sig": "tech", "size": 12, "type": "sig"},
        {"offset": 2768, "sig": "vued", "size": 135, "type": "desc"},
        {"offset": 2904, "sig": "wtpt", "size": 20, "type": "XYZ"},
        {"offset": 2924, "sig": "cprt", "size": 55, "type": "text"},
        {"offset": 2980, "sig": "chad", "size": 44, "type": "sf32"},
    ]),
    (ADOBE, [
        {"offset": 240, "sig": "cprt", "size": 50, "type": "text"},
        {"offset": 292, "sig": "desc", "size": 128, "type": "desc"},
        {"offset": 420, "sig": "rXYZ", "size": 20, "type": "XYZ"},
        {"offset": 440, "sig": "gXYZ", "size": 20, "type": "XYZ"},
        {"offset": 460, "sig": "bXYZ", "size": 20, "type": "XYZ"},
        {"offset": 480, "sig": "wtpt", "size": 20, "type": "XYZ"},
        {"offset": 500, "sig": "rTRC", "size": 14, "type": "curv"},
        {"offset": 500, "sig": "gTRC", "size": 14, "type": "curv"},
        {"offset": 500, "sig": "bTRC", "size": 14, "type": "curv"},
    ]),
])
def test_icc_tag_table(tmp_path, fixture, expected):
    """The ICC tag table lists signature/offset/size and the element type.

    CATCHES: tag count iteration in file order, shared tag offsets (rTRC/
    gTRC/bTRC all point at the same element) and the element type signature
    sniffed from the first 4 bytes of each tag.
    """
    out = fq_json(tmp_path, ["-d", "icc_profile", "-c", "-V",
                   "[.tag_table.table[] | {sig: .signature, offset, size, type}]",
                   fixture])
    assert out == expected


def test_icc_tag_type_decodings(tmp_path):
    """Known tag element types decode: XYZ, desc, text and curv variants.

    CATCHES: s15Fixed16 XYZ numbers as floats, the desc structure with its
    three description strings, NUL-trimmed text, the curv count symbol
    'simple_gamma' with an FP16 gamma and the 1024 point interpolation curve.
    """
    xyz = fq_json(tmp_path, ["-d", "icc_profile", "-c", "-V",
                  "[.tag_table.table[] | select(.signature==\"rXYZ\" or .signature==\"gXYZ\""
                  " or .signature==\"bXYZ\" or .signature==\"wtpt\" or .signature==\"lumi\""
                  " or .signature==\"bkpt\") | {sig: .signature, x, y, z}]",
                  SRGB])
    assert xyz == [
        {"sig": "bXYZ", "x": 0.14306640625, "y": 0.06060791015625,
         "z": 0.7140960693359375},
        {"sig": "gXYZ", "x": 0.3851470947265625, "y": 0.7168731689453125,
         "z": 0.097076416015625},
        {"sig": "lumi", "x": 0, "y": 80, "z": 0},
        {"sig": "bkpt", "x": 0.002410888671875, "y": 0.00250244140625,
         "z": 0.0020599365234375},
        {"sig": "rXYZ", "x": 0.436065673828125, "y": 0.2224884033203125,
         "z": 0.013916015625},
        {"sig": "wtpt", "x": 0.964202880859375, "y": 1, "z": 0.8249053955078125},
    ]

    srgb = fq_json(tmp_path, ["-d", "icc_profile", "-c", "-V",
                   "{desc: (.tag_table.table[] | select(.signature==\"desc\")),"
                   " cprt: (.tag_table.table[] | select(.signature==\"cprt\") | .text),"
                   " rtrc: (.tag_table.table[] | select(.signature==\"rTRC\")"
                   " | {type, count, curve_len: (.curve|length), head: .curve[0:5], tail: .curve[-3:]})}",
                   SRGB])
    assert srgb == {
        "cprt": "Copyright International Color Consortium, 2015",
        "desc": {"alignment": "\x00",
                 "description": "sRGB2014",
                 "description_length": 9,
                 "language_code": 0,
                 "localizable_description": "",
                 "localizable_description_length": 0,
                 "macintosh_description": "",
                 "macintosh_description_length": 0,
                 "offset": 324,
                 "reserved": 0,
                 "script_code": 0,
                 "signature": "desc",
                 "size": 99,
                 "type": "desc"},
        "rtrc": {"count": 1024, "curve_len": 1024,
                 "head": [0, 5, 10, 15, 20],
                 "tail": [65244, 65389, 65535],
                 "type": "curv"},
    }

    adobe = fq_json(tmp_path, ["-d", "icc_profile", "-c", "-V",
                    "{rtrc: (.tag_table.table[] | select(.signature==\"rTRC\")"
                    " | {type, count, gamma, alignment: (.alignment|tohex)}),"
                    " wtpt: (.tag_table.table[] | select(.signature==\"wtpt\") | {x, y, z}),"
                    " desc: (.tag_table.table[] | select(.signature==\"desc\") | .description),"
                    " cprt: (.tag_table.table[] | select(.signature==\"cprt\") | .text)}",
                    ADOBE])
    assert adobe == {
        "cprt": "Copyright 2021 Adobe Systems Incorporated",
        "desc": "Adobe RGB (1998) (Linear RGB Profile)",
        "rtrc": {"alignment": "0000", "count": "simple_gamma",
                 "gamma": 1, "type": "curv"},
        "wtpt": {"x": 0.950439453125, "y": 1, "z": 1.08905029296875},
    }


# ---------------------------------------------------------------------------
# midi
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("fixture,expected", [
    ("midi/format-0.mid", {
        "content": [{"length": 16, "tag": "MTrk"}],
        "header": {"division": {"ppqn": 480}, "format": 0, "length": 6,
                   "tag": "MThd", "tracks": 1},
    }),
    ("midi/format-1.mid", {
        "content": [{"length": 16, "tag": "MTrk"}, {"length": 23, "tag": "MTrk"}],
        "header": {"division": {"ppqn": 480}, "format": 1, "length": 6,
                   "tag": "MThd", "tracks": 2},
    }),
    ("midi/format-2.mid", {
        "content": [{"length": 18, "tag": "MTrk"}, {"length": 19, "tag": "MTrk"}],
        "header": {"division": {"ppqn": 480}, "format": 2, "length": 6,
                   "tag": "MThd", "tracks": 2},
    }),
    ("midi/smpte-division.mid", {
        "content": [{"length": 20, "tag": "MTrk"}],
        "header": {"division": {"fps": "SMPTE 25 FPS", "resolution": 40},
                   "format": 1, "length": 6, "tag": "MThd", "tracks": 1},
    }),
])
def test_midi_header_and_track_chunks(tmp_path, fixture, expected):
    """MThd decodes format/tracks and either ppqn or SMPTE fps+resolution.

    CATCHES: header length 6, format 0/1/2 values, track chunk count, and
    the division branch: negative fps byte gives the 'SMPTE 25 FPS' symbol
    with a u8 resolution instead of a u16 ppqn.
    """
    out = fq_json(tmp_path, ["-d", "midi", "-c", "-V",
                   "{header, content: [.content[] | {tag, length}]}", fixture])
    assert out == expected


@pytest.mark.parametrize("fixture,expected", [
    ("midi/note-on.mid", [
        {"channel": 2, "event": "note_on",
         "note_on": {"note": "C3", "velocity": 72},
         "time": {"delta": 0, "tick": 0}},
        {"channel": 2, "event": "note_on",
         "note_on": {"note": "D3", "velocity": 72},
         "time": {"delta": 64, "tick": 64}},
    ]),
    ("midi/note-off.mid", [
        {"channel": 1, "event": "note_off",
         "note_off": {"note": "E8", "velocity": 96},
         "time": {"delta": 0, "tick": 0}},
        {"channel": 1, "event": "note_off",
         "note_off": {"note": "F8", "velocity": 72},
         "time": {"delta": 100, "tick": 100}},
    ]),
    ("midi/controller.mid", [
        {"channel": 0,
         "controller": {"controller": "Bank Select (LSB)", "value": 33},
         "event": "controller", "time": {"delta": 0, "tick": 0}},
        {"channel": 0,
         "controller": {"controller": "Bank Select (LSB)", "value": 34},
         "event": "controller", "time": {"delta": 64, "tick": 64}},
    ]),
    ("midi/program-change.mid", [
        {"channel": 0, "event": "program_change", "program_change": 25,
         "time": {"delta": 0, "tick": 0}},
        {"channel": 0, "event": "program_change", "program_change": 32,
         "time": {"delta": 64, "tick": 64}},
    ]),
    ("midi/pitch-bend.mid", [
        {"channel": 5, "event": "pitch_bend", "pitch_bend": 0,
         "time": {"delta": 0, "tick": 0}},
        {"channel": 5, "event": "pitch_bend", "pitch_bend": 4096,
         "time": {"delta": 32, "tick": 32}},
        {"channel": 5, "event": "pitch_bend", "pitch_bend": -4096,
         "time": {"delta": 64, "tick": 96}},
    ]),
    ("midi/channel-pressure.mid", [
        {"channel": 0, "channel_pressure": 7, "event": "channel_pressure",
         "time": {"delta": 0, "tick": 0}},
        {"channel": 0, "channel_pressure": 72, "event": "channel_pressure",
         "time": {"delta": 64, "tick": 64}},
    ]),
    ("midi/polyphonic-pressure.mid", [
        {"channel": 0, "event": "polyphonic_pressure",
         "polyphonic_pressure": 100, "time": {"delta": 0, "tick": 0}},
        {"channel": 0, "event": "polyphonic_pressure",
         "polyphonic_pressure": 100, "time": {"delta": 64, "tick": 64}},
    ]),
    ("midi/running-status.mid", [
        {"channel": 2, "event": "note_on",
         "note_on": {"note": "C3", "velocity": 72},
         "time": {"delta": 0, "tick": 0}},
        {"channel": 2, "event": "note_on",
         "note_on": {"note": "D3", "velocity": 100},
         "time": {"delta": 64, "tick": 64}},
    ]),
])
def test_midi_channel_events(tmp_path, fixture, expected):
    """Channel events decode with note/controller symbols and running status.

    CATCHES: event and channel nibbles of the status byte, note name symbols,
    controller name symbols, the 14 bit signed pitch bend centred at 8192,
    varlen delta times accumulating into absolute ticks and running status
    reusing the previous status byte (synthesized event/channel fields).
    """
    out = fq_json(tmp_path, ["-d", "midi", "-c", "-V", ".content[0].events", fixture])
    assert out == expected


@pytest.mark.parametrize("fixture,expected", [
    ("midi/tempo.mid", [
        {"event": "tempo", "length": 3, "status": 255, "tempo": 500000,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/time-signature.mid", [
        {"event": "time_signature", "length": 4, "status": 255,
         "time": {"delta": 0, "tick": 0},
         "time_signature": {"denominator": 4, "numerator": 4,
                            "thirty_seconds_per_quarter": 8,
                            "ticks_per_click": 24}}]),
    ("midi/key-signature.mid", [
        {"event": "key_signature", "key_signature": "A minor", "length": 2,
         "status": 255, "time": {"delta": 0, "tick": 0}}]),
    ("midi/smpte-offset.mid", [
        {"event": "smpte_offset", "length": 5, "status": 255,
         "smpte_offset": {"fractions": 39, "framerate": "29.97 FPS DF",
                          "frames": 7, "hour": 13, "minute": 45,
                          "second": 59},
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/text.mid", [
        {"event": "text", "status": 255, "text": "This and That",
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/marker.mid", [
        {"event": "marker", "marker": "Here Be Dragons", "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/lyric.mid", [
        {"event": "lyric", "lyric": "La-la-la", "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/cuepoint.mid", [
        {"cue_point": "More cowbell", "event": "cue_point", "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/copyright.mid", [
        {"copyright": "Them", "event": "copyright", "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/track-name.mid", [
        {"event": "track_name", "status": 255,
         "time": {"delta": 0, "tick": 0}, "track_name": "Acoustic Guitar"}]),
    ("midi/instrument-name.mid", [
        {"event": "instrument_name", "instrument_name": "Didgeridoo",
         "status": 255, "time": {"delta": 0, "tick": 0}}]),
    ("midi/program-name.mid", [
        {"event": "program_name", "program_name": "Escape", "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/device-name.mid", [
        {"device_name": "TheThing", "event": "device_name", "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/sequence-number.mid", [
        {"event": "sequence_number", "length": 2, "sequence_number": 23,
         "status": 255, "time": {"delta": 0, "tick": 0}}]),
    ("midi/midi-channel-prefix.mid", [
        {"event": "midi_channel_prefix", "length": 1,
         "midi_channel_prefix": 13, "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/midi-port.mid", [
        {"event": "midi_port", "length": 1, "midi_port": 112, "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/end-of-track.mid", [
        {"event": "end_of_track", "length": 0, "status": 255,
         "time": {"delta": 0, "tick": 0}}]),
])
def test_midi_meta_events(tmp_path, fixture, expected):
    """Each meta event type decodes with its symbol table and length check.

    CATCHES: status 0xff, event type symbols, varlen length validation
    (tempo must be 3, time signature 4, key signature 2), tempo u24
    microseconds, denominator as a power of two, key signature symbols like
    'A minor', the SMPTE offset framerate symbol and NUL-free text payloads.
    """
    out = fq_json(tmp_path, ["-d", "midi", "-c", "-V", ".content[0].events", fixture])
    assert out == expected


@pytest.mark.parametrize("fixture,expected", [
    ("midi/sysex-message.mid", [
        {"event": "sysex_message", "length": 5,
         "message": {"data": "\x00\t\x01", "end_of_message": 247,
                     "manufacturer": "Non-RealTime Extensions"},
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/sysex-escape.mid", [
        {"escape": {"data": "�\x01"}, "event": "sysex_escape", "length": 2,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/sysex-continuation.mid", [
        {"event": "sysex_message", "length": 3,
         "message": {"continued": True, "data": "\x01#",
                     "manufacturer": "Yamaha"},
         "time": {"delta": 0, "tick": 0}},
        {"continuation": {"continued": True, "data": "Eg����"},
         "event": "sysex_continuation", "length": 6,
         "time": {"delta": 0, "tick": 0}},
        {"continuation": {"data": "\x01#E", "end_of_message": 247},
         "event": "sysex_continuation", "length": 4,
         "time": {"delta": 0, "tick": 0}}]),
    ("midi/sequencer-specific-event.mid", [
        {"event": "sequencer_specific_event", "length": 6,
         "sequencer_specific_event": {"data": ":L^",
                                      "manufacturer": "Mark Of The Unicorn (MOTU)"},
         "status": 255, "time": {"delta": 0, "tick": 0}}]),
])
def test_midi_sysex_and_sequencer_specific_events(tmp_path, fixture, expected):
    """SysEx messages, escapes and continuations decode with manufacturer ids.

    CATCHES: 0xf0 message vs 0xf7 escape symbols, manufacturer id symbol
    names, the trailing 0xf7 end_of_message byte, the continued flag for
    split messages and the meta sequencer-specific manufacturer byte.
    """
    out = fq_json(tmp_path, ["-d", "midi", "-c", "-V", ".content[0].events", fixture])
    assert out == expected


def test_midi_chunk_edge_cases(tmp_path):
    """Odd chunk layouts: extra format-0 tracks, unknown chunks, bad lengths.

    CATCHES: format 0 files keep extra MTrk chunks as raw 'other' data,
    unknown chunk tags decode as raw data with their tag, oversized MThd/
    MTrk lengths produce outside-buffer errors and an empty file errors on
    the header peek while still exiting 0.
    """
    extra = fq_json(tmp_path, ["-d", "midi", "-c", "-V",
                    "{chunks: [.content[] | {tag, length, has_events: has(\"events\")}],"
                    " other_hex: (.content[1].data | tohex)}",
                    "midi/format-0-extra-tracks.mid"])
    assert extra == {
        "chunks": [{"has_events": True, "length": 16, "tag": "MTrk"},
                   {"has_events": False, "length": 16, "tag": "MTrk"}],
        "other_hex": "00ff0308547261636b20303200ff2f00",
    }

    unknown = fq_json(tmp_path, ["-d", "midi", "-c", "-V",
                      "[.content[] | {tag, length, events: ((.events // [])|length),"
                      " data_hex: (if has(\"data\") then (.data|tohex) else null end)}]",
                      "midi/unknown-chunks.mid"])
    assert unknown == [
        {"data_hex": "0123456789abcdef", "events": 0, "length": 8, "tag": "MTrx"},
        {"data_hex": None, "events": 1, "length": 4, "tag": "MTrk"},
        {"data_hex": "fedcba9876543210", "events": 0, "length": 8, "tag": "MTrx"},
        {"data_hex": None, "events": 1, "length": 4, "tag": "MTrk"},
        {"data_hex": "0123456789abcdef", "events": 0, "length": 8, "tag": "MTrx"},
    ]

    bad_mthd = fq_json(tmp_path, ["-d", "midi", "-c", "-V", ".header",
                        "midi/invalid-MThd-length.mid"])
    assert bad_mthd == {"length": 80, "tag": "MThd"}
    res = run_on(tmp_path, ["-d", "midi", "d", "midi/invalid-MThd-length.mid"])
    assert res.returncode == 0
    assert ("error: midi: BitBufRange: failed at position 0 "
            "(read size 88 seek pos 0): outside buffer") in res.stdout.decode("utf-8")

    bad_mtrk = fq_json(tmp_path, ["-d", "midi", "-c", "-V",
                       "{header, second: .content[1]}",
                       "midi/invalid-MTrk-length.mid"])
    assert bad_mtrk == {
        "header": {"division": {"ppqn": 480}, "format": 1, "length": 6,
                   "tag": "MThd", "tracks": 2},
        "second": {"events": [], "length": 80, "tag": "MTrk"},
    }
    res = run_on(tmp_path, ["-d", "midi", "d", "midi/invalid-MTrk-length.mid"])
    assert res.returncode == 0
    assert ("error: midi: BitBufRange: failed at position 0 "
            "(read size 126 seek pos 0): outside buffer") in res.stdout.decode("utf-8")

    empty = fq_json(tmp_path, ["-d", "midi", "-c", "-V", ".", "midi/empty.mid"])
    assert empty == {"header": {}}
    res = run_on(tmp_path, ["-d", "midi", "d", "midi/empty.mid"])
    assert res.returncode == 0
    assert ("error: midi: PeekBytes: failed at position 0 "
            "(read size 4 seek pos 0): EOF") in res.stdout.decode("utf-8")


def test_midi_key_signature_and_smpte_timecode_tables(tmp_path):
    """key-signatures.mid walks the full key symbol table; timecodes the fps.

    CATCHES: all 31 major/minor key signature symbols including sharps and
    flats, and the four SMPTE timecode framerate symbols 24/25/29.97 DF/30.
    """
    keys = fq_json(tmp_path, ["-d", "midi", "-c", "-V",
                   "[.content[0].events[] | select(.key_signature != null) | .key_signature]",
                   "midi/key-signatures.mid"])
    assert keys == [
        "C major", "G major", "D major", "A major", "E major", "B major",
        "F♯ major", "C♯ major", "C major", "F major", "B♭ major", "E♭ major",
        "A♭ major", "D♭ major", "G♭ major", "C♭ major",
        "A minor", "E minor", "B minor", "F♯ minor", "C♯ minor", "G♯ minor",
        "D♯ minor", "A♯ minor", "A minor", "D minor", "G minor", "C minor",
        "F minor", "B♭ minor", "E♭ minor", "A♭ minor",
    ]

    for fps, expected in [("24", "24 FPS"), ("25", "25 FPS"),
                          ("29", "29.97 FPS DF"), ("30", "30 FPS")]:
        out = fq_json(tmp_path, ["-d", "midi", "-c", "-V",
                       "[.content[0].events[] | select(.event==\"smpte_offset\") | .smpte_offset.framerate]",
                       f"midi/smpte-timecode-{fps}.mid"])
        assert out == [expected]


def test_midi_reference_and_twinkle_files(tmp_path):
    """Real world files: reference.mid meta chain and twinkle's tempo map.

    CATCHES: multi-track layout with event counts, varlen delta accumulation
    into ticks across events, the 24 entry tempo map of twinkle.mid and
    per-track names/controller symbols.
    """
    ref = fq_json(tmp_path, ["-d", "midi", "-c", "-V",
                  "{header, content: [.content[] | {tag, length, n: (.events|length)}],"
                  " first_events: .content[1].events[0:4]}",
                  "midi/reference.mid"])
    assert ref == {
        "content": [{"length": 4, "n": 1, "tag": "MTrk"},
                    {"length": 265, "n": 34, "tag": "MTrk"}],
        "first_events": [
            {"event": "sequence_number", "length": 2, "sequence_number": 23,
             "status": 255, "time": {"delta": 0, "tick": 0}},
            {"event": "text", "status": 255, "text": "This and That",
             "time": {"delta": 0, "tick": 0}},
            {"copyright": "Them", "event": "copyright", "status": 255,
             "time": {"delta": 0, "tick": 0}},
            {"event": "track_name", "status": 255,
             "time": {"delta": 0, "tick": 0}, "track_name": "Acoustic Guitar"},
        ],
        "header": {"division": {"ppqn": 480}, "format": 1, "length": 6,
                   "tag": "MThd", "tracks": 2},
    }

    twinkle = fq_json(tmp_path, ["-d", "midi", "-c", "-V",
                      "{header: .header, tracks: (.content|length),"
                      " track0_first: .content[0].events[0:4],"
                      " tempos: [.content[0].events[] | select(.event==\"tempo\") | .tempo][0:6],"
                      " tempo_count: ([.content[0].events[] | select(.event==\"tempo\")] | length),"
                      " track1_first: .content[1].events[0:4]}",
                      "midi/twinkle.mid"])
    assert twinkle == {
        "header": {"division": {"ppqn": 480}, "format": 1, "length": 6,
                   "tag": "MThd", "tracks": 15},
        "tracks": 15,
        "track0_first": [
            {"event": "tempo", "length": 3, "status": 255, "tempo": 666666,
             "time": {"delta": 0, "tick": 0}},
            {"event": "time_signature", "length": 4, "status": 255,
             "time": {"delta": 0, "tick": 0},
             "time_signature": {"denominator": 4, "numerator": 4,
                                "thirty_seconds_per_quarter": 8,
                                "ticks_per_click": 24}},
            {"event": "track_name", "status": 255,
             "time": {"delta": 0, "tick": 0}, "track_name": "057Kira"},
            {"event": "tempo", "length": 3, "status": 255, "tempo": 689060,
             "time": {"delta": 53280, "tick": 53280}},
        ],
        "tempos": [666666, 689060, 702823, 717789, 733407, 749719],
        "tempo_count": 24,
        "track1_first": [
            {"event": "track_name", "status": 255,
             "time": {"delta": 0, "tick": 0}, "track_name": "Acoustic Piano"},
            {"channel": 0, "event": "program_change", "program_change": 0,
             "time": {"delta": 0, "tick": 0}},
            {"event": "key_signature", "key_signature": "A minor",
             "length": 2, "status": 255, "time": {"delta": 0, "tick": 0}},
            {"channel": 0,
             "controller": {"controller": "Registered Parameter Number (MSB)",
                            "value": 0},
             "event": "controller", "time": {"delta": 0, "tick": 0}},
        ],
    }


# ---------------------------------------------------------------------------
# moc3
# ---------------------------------------------------------------------------


def test_moc3_live2d_model(tmp_path):
    """moc3 decodes a real Live2D model header, counters and parameters.

    CATCHES: 'MOC3' magic, version symbol V5_00_00, little endian flag, the
    count_info section counters (including the v5-only blend_shapes_parts
    and keyform_multiply_colors fields), canvas info floats and parameter
    id/min/max/default/type arrays.
    """
    head = fq_json(tmp_path, ["-d", "moc3", "-c", "-V",
                   "{magic, version, is_big_endian}", MOC3])
    assert head == {"is_big_endian": False, "magic": "MOC3", "version": "V5_00_00"}

    counts = fq_json(tmp_path, ["-d", "moc3", "-c", "-V",
                     "{parts: .sections.count_info.parts,"
                     " deformers: .sections.count_info.deformers,"
                     " warp_deformers: .sections.count_info.warp_deformers,"
                     " rotation_deformers: .sections.count_info.rotation_deformers,"
                     " art_meshes: .sections.count_info.art_meshes,"
                     " parameters: .sections.count_info.parameters,"
                     " keys: .sections.count_info.keys,"
                     " uvs: .sections.count_info.uvs,"
                     " keyform_positions: .sections.count_info.keyform_positions,"
                     " position_indices: .sections.count_info.position_indices,"
                     " draw_order_groups: .sections.count_info.draw_order_groups,"
                     " glue: .sections.count_info.glue,"
                     " blend_shapes_parts: .sections.count_info.blend_shapes_parts,"
                     " keyform_multiply_colors: .sections.count_info.keyform_multiply_colors}",
                     MOC3])
    assert counts == {
        "parts": 10,
        "deformers": 17,
        "warp_deformers": 15,
        "rotation_deformers": 2,
        "art_meshes": 29,
        "parameters": 32,
        "keys": 98,
        "uvs": 6492,
        "keyform_positions": 193504,
        "position_indices": 14358,
        "draw_order_groups": 1,
        "glue": 0,
        "blend_shapes_parts": 0,
        "keyform_multiply_colors": 407,
    }

    canvas = fq_json(tmp_path, ["-d", "moc3", "-c", "-V",
                     ".sections.canvas_info | del(.padding)", MOC3])
    assert canvas == {
        "canvas_flags": {"reserved": 0, "reverse_y_coordinate": False},
        "canvas_height": 4960,
        "canvas_width": 3508,
        "origin_x": 1754,
        "origin_y": 2480,
        "pixels_per_unit": 3508,
    }

    parts = fq_json(tmp_path, ["-d", "moc3", "-c", "-V",
                    "[.sections.parts.ids.array[0:10]]", MOC3])
    assert parts == [["Part2", "Part", "R", "L", "Mouth", "Head",
                      "Eyes", "Eyes2", "Down", "Up"]]

    params = fq_json(tmp_path, ["-d", "moc3", "-c", "-V",
                     "[.sections.parameters.ids.array[0:6],"
                     " .sections.parameters.min_values.array[0:6],"
                     " .sections.parameters.max_values.array[0:6],"
                     " .sections.parameters.default_values.array[0:6],"
                     " .sections.parameters.parameter_types.array[0:6],"
                     " .sections.parameters.is_repeat.array[0:6],"
                     " .sections.parameters.decimal_places.array[0:6]]",
                     MOC3])
    assert params == [
        ["ParamAngleY", "ParamAngleX", "ParamAngleZ", "Hair1", "Hair2",
         "ParamEyeLOpen"],
        [-30, -30, -30, -1, -1, 0],
        [30, 30, 30, 1, 1, 1],
        [0, 0, 0, 0, 0, 1],
        ["normal", "normal", "normal", "normal", "normal", "normal"],
        [False, False, False, False, False, False],
        [3, 3, 3, 3, 3, 3],
    ]


# ---------------------------------------------------------------------------
# stl
# ---------------------------------------------------------------------------


def test_stl_binary_variants(tmp_path):
    """Binary STL decodes the 80 byte header, facet count and float facets.

    CATCHES: NUL padded header string, little endian float32 normals and
    vertices (including the non-exact 0.5773502588272095 diagonal), the
    u16 attribute_byte_count and the attribute payload when it is non-zero.
    """
    cube = fq_json(tmp_path, ["-d", "stl", "-c", "-V",
                   "{header, num_facets, facets}", STL])
    assert cube == {
        "facets": [
            {"attribute_byte_count": 0,
             "normal": {"x": 0, "y": -1, "z": 0},
             "vertices": [{"x": 1, "y": 0, "z": 0},
                          {"x": 0, "y": 0, "z": 1},
                          {"x": 0, "y": 0, "z": 0}]},
            {"attribute_byte_count": 0,
             "normal": {"x": -1, "y": 0, "z": 0},
             "vertices": [{"x": 0, "y": 0, "z": 0},
                          {"x": 0, "y": 0, "z": 1},
                          {"x": 0, "y": 1, "z": 0}]},
            {"attribute_byte_count": 0,
             "normal": {"x": 0, "y": 0, "z": -1},
             "vertices": [{"x": 0, "y": 1, "z": 0},
                          {"x": 1, "y": 0, "z": 0},
                          {"x": 0, "y": 0, "z": 0}]},
            {"attribute_byte_count": 0,
             "normal": {"x": 0.5773502588272095, "y": 0.5773502588272095,
                        "z": 0.5773502588272095},
             "vertices": [{"x": 0, "y": 1, "z": 0},
                          {"x": 0, "y": 0, "z": 1},
                          {"x": 1, "y": 0, "z": 0}]},
        ],
        "header": "Exported from Blender-3.6.23",
        "num_facets": 4,
    }

    attr = fq_json(tmp_path, ["-d", "stl", "-c", "-V",
                   "{header, num_facets,"
                   " facet: (.facets[0] | {normal, vertices, attribute_byte_count,"
                   " attribute_hex: (.attribute|tohex)})}",
                   STL_ATTR])
    assert attr == {
        "facet": {"attribute_byte_count": 4,
                  "attribute_hex": "deadbeef",
                  "normal": {"x": 0, "y": 0, "z": 1},
                  "vertices": [{"x": 0, "y": 0, "z": 1},
                               {"x": 1, "y": 0, "z": 1},
                               {"x": 0, "y": 1, "z": 1}]},
        "header": "fq test attr",
        "num_facets": 1,
    }


def test_stl_ascii_interpreted_as_binary(tmp_path):
    """ASCII STL is not detected: the bytes are parsed as a binary STL.

    CATCHES: there is no ASCII probing, so the 80 byte header is the text
    itself, num_facets comes from the next 4 ASCII bytes read little endian
    and the 'facet' floats are the ASCII text reinterpreted, ending in an
    outside-buffer error while the process still exits 0.
    """
    out = fq_json(tmp_path, ["-d", "stl", "-c", "-V",
                   "{header, num_facets, n: (.facets|length),"
                   " attribute_byte_count: .facets[0].attribute_byte_count,"
                   " normal: .facets[0].normal}",
                   STL_ASCII])
    assert out == {
        "header": ("solid ascii_cube\n  facet normal 0.0 0.0 1.0\n"
                   "    outer loop\n      vertex 0.0 0.0 "),
        "num_facets": 170929713,
        "n": 1,
        "attribute_byte_count": 2608,
        "normal": {"x": 1.3563156426940112e-19,
                   "y": 7.264342227745629e+22,
                   "z": 1.8615590189516027e+34},
    }

    res = run_on(tmp_path, ["-d", "stl", "d", STL_ASCII])
    assert res.returncode == 0
    assert ("error: stl: RawLen(attribute): failed at position 134 "
            "(read size 0 seek pos 0): outside buffer") in res.stdout.decode("utf-8")
