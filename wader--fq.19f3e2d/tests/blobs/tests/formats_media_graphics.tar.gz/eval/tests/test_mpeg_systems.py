"""Black-box tests for the MPEG systems decoders.

Covers: mpeg_ts, mpeg_pes, mpeg_pes_packet, mpeg_es and mpeg_spu.  Every
expected value below was recorded by running the reference fq binary on the
fixtures in eval/tests/data.

Fixtures crafted for this module:
* mpeg_ts: four 188 byte transport stream packets (a PAT-ish pid 0 packet, a
  scrambled video packet, a null packet and a packet with the transport
  error indicator set), so that only the first 4 byte header decodes and the
  remaining 748 bytes become the gap0 raw value.
* mpeg_pes: two video_stream PES packets followed by a private_stream1 PES
  packet that carries a sub picture unit (only the first packet decodes; the
  rest of the stream becomes its trailing data gap).
* mpeg_pes_packet_video / mpeg_pes_spu: the single packets above on their
  own, so mpeg_pes_packet decodes them without anything following.
* mpeg_pes_packet_sequence_header: a bare MPEG-2 video sequence header start
  code (00 00 01 b3) plus its 64 bit body.
* mpeg_spu: a minimal 43 byte DVD Sub Picture Unit with a two entry DCSQ
  table and 4 bytes of RLE pixel data per display field.
* mpeg_es_iod / mpeg_es_esds: the iods/esds descriptor payloads extracted
  from the isobmff testdata (mpeg_es is the MPEG-4 object descriptor
  decoder, not an MPEG-2 video elementary stream decoder).
"""

import pytest

from conftest import fq_json, run_on

TS = "mpeg/mpeg_ts"
PES_MULTI = "mpeg/mpeg_pes"
PES_PKT_VIDEO = "mpeg/mpeg_pes_packet_video"
PES_PKT_SEQHDR = "mpeg/mpeg_pes_packet_sequence_header"
PES_SPU = "mpeg/mpeg_pes_spu"
SPU = "mpeg/mpeg_spu"
ES_IOD = "mpeg/mpeg_es_iod"
ES_ESDS = "mpeg/mpeg_es_esds"

# mpeg_ts on the 752 byte fixture: only the first packet's 4 byte header.
TS_FIRST = {
    "adaptation_field_control": 1,
    "continuity_counter": 0,
    "field_count": 9,
    "gap0_bytes": 748,
    "payload_unit_start": False,
    "pid": 0,
    "sync": 71,
    "transport_error_indicator": False,
    "transport_priority": False,
    "transport_scrambling_control": 0
}

# mpeg_pes_packet on the 18 byte video_stream packet.
PES_PKT_VIDEO_VALUE = {
    "extension": {
        "additional_copy_info_flag": 0,
        "copyright": 0,
        "data_alignment_indicator": 0,
        "dsm_trick_mode_flag": 0,
        "es_rate_flag": 0,
        "escr_flag": 0,
        "header_data_length": 5,
        "original": 1,
        "pes_crc_flag": 0,
        "pes_ext_flag": 0,
        "priority": 0,
        "pts_dts_flags": 2,
        "scramble_control": 0,
        "skip0": 2
    },
    "header_data": "!\x00\x01`s",
    "length": 12,
    "prefix": 1,
    "start_code": "video_stream",
    "stream_data": "\u07ad\ufffd\ufffd"
}

# mpeg_pes_packet on the bare MPEG-2 sequence header.
PES_PKT_SEQHDR_VALUE = {
    "aspect_ratio": 1,
    "bit_rate": 90000,
    "constrained_parameters_flag": 1,
    "frame_rate_code": 3,
    "horizontal_size": 320,
    "load_intra_quantizer_matrix": False,
    "load_non_intra_quantizer_matrix": False,
    "marker_bit": 1,
    "prefix": 1,
    "start_code": "sequence_header",
    "vbv_buf_size": 512,
    "vertical_size": 240
}

# mpeg_pes on the three-packet stream: element 0 is the (empty) spus array,
# element 1 the single video_stream packet that decodes.
PES_MULTI_VALUE = [
    {"spus": 0},
    {
        "data_bytes": 70,
        "length": 12,
        "prefix": 1,
        "start_code": "video_stream",
        "stream_data_bytes": 4
    }
]

# mpeg_pes on the private_stream1 packet: root array of two elements (the
# spus array with the reassembled sub picture unit, and the packet itself).
PES_SPU_SUMMARY = {
    "length": 47,
    "n": 2,
    "spu_bytes": 43,
    "start_code": "private_stream1",
    "substream": 32
}

PES_SPU_PACKET = {
    "data_bytes": 43,
    "hdrl": 0,
    "length": 47,
    "prefix": 1,
    "start_code": "private_stream1",
    "substream": 32
}

# mpeg_spu on the 43 byte sub picture unit (also the value reassembled into
# mpeg_pes .[0][0] from the private_stream1 packet).
SPU_VALUE = {
    "dcsqt": [
        {
            "bottom_pixels": "\ufffd\ufffd\ufffd\ufffd",
            "commands": [
                {"offset_bottom_field": 38, "offset_top_field": 34, "type": "SET_DSPXA"},
                {"a0": 1, "a1": 2, "a2": 3, "a3": 4, "type": "SET_COLOR"},
                {
                    "end_x": 7,
                    "end_y": 3,
                    "start_x": 0,
                    "start_y": 0,
                    "type": "SET_DAREA"
                },
                {"type": "CMD_END"}
            ],
            "delay": 256,
            "offset": 30,
            "top_pixels": "\ufffd\ufffd\ufffd\ufffd"
        },
        {"delay": 0, "offset": 30}
    ],
    "dcsqt_offset": 10,
    "gap0": "\x00\x00\x00\x00\x00\x00",
    "gap1": "\x00",
    "size": 43
}

SPU_PIXELS = {"bottom": 4, "gap0": 6, "gap1": 1, "top": 4}

ES_IOD_VALUE = {
    "audio_profile_level": 49,
    "descriptors": [{"length": 4, "tag_id": "ES_ID_IncTag", "track_id": 1}],
    "graphics_profile_level": 255,
    "length": 16,
    "od_id": 79,
    "od_profile_level": 255,
    "scene_profile_level": 255,
    "tag_id": "MP4_IOD_Tag",
    "video_profile_level": 255
}

ES_ESDS_VALUE = {
    "dec_config_descr": {
        "avg_bit_rate": 67085,
        "buffer_size_db": 0,
        "decoder_specific_info": {
            "audio_specific_config": {
                "channel_configuration": 1,
                "object_type": "aac_lc",
                "sampling_frequency": 44100,
                "var_aot_or_byte_align": "\n\u0720\x00"
            },
            "length": 5,
            "tag_id": "DecSpecificInfoTag"
        },
        "length": 23,
        "max_bit_rate": 69000,
        "object_type_indication": "MPEGObjectTypeAAC",
        "specific_info_flag": True,
        "stream_type": "AudioStream",
        "tag_id": "DecoderConfigDescrTag",
        "upstream": False
    },
    "es_id": 1,
    "length": 37,
    "ocr_stream_flag": False,
    "sl_config_descr": {"data": "\x02", "length": 1, "tag_id": "SLConfigDescrTag"},
    "stream_dependency_flag": False,
    "stream_priority": 0,
    "tag_id": "ES_DescrTag",
    "url_flag": False
}


def test_mpeg_ts_first_packet_header_only(tmp_path):
    """mpeg_ts decodes only the 4 byte header of the first packet.

    CATCHES: the sync byte is asserted against 0x47 and rendered as hex with
    a "(valid)" annotation in the d display, the 13 bit pid spans bytes 2-3,
    and all 748 bytes after the first header become one gap0 raw value
    instead of further packets.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_ts",
                   "del(.gap0) + {field_count: length, gap0_bytes: (.gap0|tobytes|length)}",
                   TS])
    assert out == TS_FIRST

    res = run_on(tmp_path, ["-d", "mpeg_ts", "d", TS])
    assert res.returncode == 0
    assert "sync: 0x47 (valid)" in res.stdout.decode("utf-8")


@pytest.mark.parametrize("packet_hex,expected", [
    ("47000010", {
        "adaptation_field_control": 1,
        "continuity_counter": 0,
        "payload_unit_start": False,
        "pid": 0,
        "sync": 71,
        "transport_error_indicator": False,
        "transport_priority": False,
        "transport_scrambling_control": 0
    }),
    ("47c10035", {
        "adaptation_field_control": 3,
        "continuity_counter": 5,
        "payload_unit_start": True,
        "pid": 256,
        "sync": 71,
        "transport_error_indicator": True,
        "transport_priority": False,
        "transport_scrambling_control": 0
    }),
    ("473fffff", {
        "adaptation_field_control": 3,
        "continuity_counter": 15,
        "payload_unit_start": False,
        "pid": 8191,
        "sync": 71,
        "transport_error_indicator": False,
        "transport_priority": True,
        "transport_scrambling_control": 3
    }),
    ("47602145", {
        "adaptation_field_control": 0,
        "continuity_counter": 5,
        "payload_unit_start": True,
        "pid": 33,
        "sync": 71,
        "transport_error_indicator": False,
        "transport_priority": True,
        "transport_scrambling_control": 1
    }),
    ("47007fc6", {
        "adaptation_field_control": 0,
        "continuity_counter": 6,
        "payload_unit_start": False,
        "pid": 127,
        "sync": 71,
        "transport_error_indicator": False,
        "transport_priority": False,
        "transport_scrambling_control": 3
    }),
])
def test_mpeg_ts_header_bit_packing(packet_hex, expected, tmp_path):
    """mpeg_ts unpacks the 32 bit packet header from bytes read on stdin.

    CATCHES: the exact bit layout — 8 bit sync, then
    transport_error_indicator/payload_unit_start/transport_priority plus the
    5 high pid bits in byte 2, then the 8 low pid bits plus 2 bit scrambling
    control, 2 bit adaptation field control and 4 bit continuity counter in
    byte 3 — including the extreme values pid 8191, tsc 3, afc 3 and cc 15.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_ts", "."],
                  stdin=bytes.fromhex(packet_hex))
    assert out == expected


def test_mpeg_ts_bad_sync_byte(tmp_path):
    """mpeg_ts keeps the whole packet as a gap when the sync byte is wrong.

    CATCHES: the sync assert failure surfaces as a decoder error line in the
    d display while the process still exits 0, and the JSON value of the
    failed decode is a single gap0 raw value covering all four input bytes.
    """
    res = run_on(tmp_path, ["-d", "mpeg_ts", "d"], stdin=b"\x00\x00\x00\x10")
    assert res.returncode == 0
    assert ("error: mpeg_ts: U8(sync): failed at position 1"
            " (read size 0 seek pos 0): failed to assert Uint") in res.stdout.decode("utf-8")

    out = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_ts", "."],
                  stdin=b"\x00\x00\x00\x10")
    assert out == {"gap0": "\x00\x00\x00\x10"}


@pytest.mark.parametrize("fixture,expected", [
    (PES_PKT_VIDEO, PES_PKT_VIDEO_VALUE),
    (PES_PKT_SEQHDR, PES_PKT_SEQHDR_VALUE),
])
def test_mpeg_pes_packet(fixture, expected, tmp_path):
    """mpeg_pes_packet decodes one PES packet or a bare MPEG-2 start code.

    CATCHES: the 24 bit prefix assert, the start code symbol table
    (video_stream 0xe0 vs sequence_header 0xb3), the PES extension bitfields
    with pts_dts_flags=2 keeping 5 raw header_data bytes and a length that
    counts them, and the un-byte-aligned 12/12/4/4/18/1/10 bit sequence
    header layout for the start-code-only path.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_pes_packet", ".", fixture])
    assert out == expected


def test_mpeg_pes_multi_packet_stream(tmp_path):
    """mpeg_pes roots an empty spus array first and decodes one packet only.

    CATCHES: the root array starts with the spus array value before any
    packet field, the single video_stream packet that decodes is followed by
    a trailing data gap that swallows the remaining 70 bytes of the stream
    (the second video packet and the private_stream1 packet never decode),
    and stream_data keeps the 4 byte payload.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_pes",
                   "[.[] | if type == \"array\" then {spus: length}"
                   " else {start_code, length, prefix,"
                   " data_bytes: (try (.data|tobytes|length) catch null),"
                   " stream_data_bytes: (try (.stream_data|tobytes|length) catch null)} end]",
                   PES_MULTI])
    assert out == PES_MULTI_VALUE


def test_mpeg_pes_private_stream1_spu_reassembly(tmp_path):
    """mpeg_pes reassembles a sub picture unit from a private_stream1 packet.

    CATCHES: the private_stream1 payload keeps its raw substream-tagged data
    (43 bytes) while the same bytes are accumulated and decoded a second
    time as the spus[0] sub picture unit, and the packet length field counts
    everything after it (3 extension bytes + 1 substream byte + 43 spu
    bytes = 47).
    """
    summary = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_pes",
                   "{n: length, start_code: .[1].start_code, length: .[1].length,"
                   " substream: .[1].data.substream, spu_bytes: (.[0][0]|tobytes|length)}",
                   PES_SPU])
    assert summary == PES_SPU_SUMMARY

    packet = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_pes",
                   ".[1] | {prefix, start_code, length,"
                   " data_bytes: (.data.data|tobytes|length), substream: .data.substream,"
                   " hdrl: .extension.header_data_length}",
                   PES_SPU])
    assert packet == PES_SPU_PACKET

    spu = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_pes", ".[0][0]", PES_SPU])
    assert spu == SPU_VALUE


def test_mpeg_spu_standalone(tmp_path):
    """mpeg_spu decodes the DCSQ table, its commands and the RLE pixel data.

    CATCHES: the seek over the 6 unknown bytes to dcsqt_offset 10 (gap0),
    the SET_DSPXA/SET_COLOR/SET_DAREA/CMD_END command chain, the second dcsq
    recognised as the last one via its self-referencing offset 30, the 4
    byte RLE pixel fields per display field and the 1 trailing pad byte
    (gap1) needed because the RLE reader always peeks 8 bits.
    """
    spu = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_spu", ".", SPU])
    assert spu == SPU_VALUE

    pixels = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_spu",
                   "{top: (.dcsqt[0].top_pixels|length),"
                   " bottom: (.dcsqt[0].bottom_pixels|length),"
                   " gap0: (.gap0|length), gap1: (.gap1|length)}",
                   SPU])
    assert pixels == SPU_PIXELS


@pytest.mark.parametrize("fixture,expected", [
    (ES_IOD, ES_IOD_VALUE),
    (ES_ESDS, ES_ESDS_VALUE),
])
def test_mpeg_es_object_descriptors(fixture, expected, tmp_path):
    """mpeg_es decodes MPEG-4 object descriptors, not video ES packets.

    CATCHES: the descriptor tag symbol table (MP4_IOD_Tag with its five
    profile levels and nested ES_ID_Inc descriptors; ES_DescrTag nesting
    DecoderConfigDescrTag, DecSpecificInfoTag and SLConfigDescrTag), the
    descriptor length fields and the audio specific config with its symbol
    lookups inside the decoder specific info.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mpeg_es", ".", fixture])
    assert out == expected
