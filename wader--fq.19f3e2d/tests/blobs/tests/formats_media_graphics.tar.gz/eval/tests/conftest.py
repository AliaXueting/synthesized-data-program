"""Shared helpers for black-box tests of the fq media/format decoders.

Every test invokes the candidate binary through the helpers below so that
``PROGRAMGYM_EXECUTABLE`` is the only place the binary path is resolved and so
that the child process runs in a pinned, hermetic environment.

Fixtures live in ``eval/tests/data`` (mirroring the layout of the fq repo's
``format/*/testdata``).  ``run_on``/``run_ok``/``fq_json`` copy any argument
that names a fixture into ``tmp_path`` first, so the child only ever sees file
names inside ``tmp_path``.
"""

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

TESTS_DIR = Path(__file__).resolve().parent
DATA_DIR = TESTS_DIR / "data"


def _resolve_executable() -> Path:
    raw = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not raw:
        pytest.exit(
            "PROGRAMGYM_EXECUTABLE is not set (expected path to the fq binary)",
            returncode=90,
        )
    path = Path(raw)
    if not path.is_absolute():
        path = (TESTS_DIR.parent.parent / path).resolve()
    if not path.exists():
        pytest.exit(f"PROGRAMGYM_EXECUTABLE does not exist: {path}", returncode=90)
    return path


EXECUTABLE = _resolve_executable()


def child_env(cwd) -> dict:
    """Pinned environment for the child process (plus GOCOVERDIR passthrough)."""
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": str(cwd),
        "TMPDIR": str(cwd),
        "LANG": "C",
        "LC_ALL": "C",
        "TERM": "dumb",
        "COLUMNS": "80",
        "NO_COLOR": "1",
    }
    # Coverage instrumentation hook: the pipeline measures source coverage of
    # the reference binary through GOCOVERDIR, so it must reach the child.
    for value in [os.environ.get("GOCOVERDIR")]:
        if value:
            env["GOCOVERDIR"] = value
    return env


def run_fq(args, cwd, stdin=None, timeout=30):
    """Run the candidate binary; returns CompletedProcess with byte output."""
    argv = [str(EXECUTABLE)] + [str(a) for a in args]
    return subprocess.run(
        argv,
        cwd=str(cwd),
        input=stdin,
        capture_output=True,
        env=child_env(cwd),
        timeout=timeout,
    )


def _is_fixture(arg: str) -> bool:
    """True when arg names a fixture under data/ (never raises on long/odd args)."""
    if len(arg) > 200 or "\n" in arg:
        return False
    try:
        return (DATA_DIR / arg).is_file()
    except OSError:
        return False


def _materialize(tmp_path, args):
    """Turn data-relative fixture args into files inside tmp_path."""
    final = []
    for arg in args:
        arg = str(arg)
        if _is_fixture(arg):
            candidate = DATA_DIR / arg
            shutil.copyfile(candidate, tmp_path / candidate.name)
            final.append(candidate.name)
        else:
            final.append(arg)
    return final


def run_on(tmp_path, args, stdin=None, timeout=30):
    """Run the binary in tmp_path, copying any fixture arguments into it."""
    return run_fq(_materialize(tmp_path, args), cwd=tmp_path, stdin=stdin, timeout=timeout)


def run_ok(tmp_path, args, stdin=None, timeout=30) -> str:
    """Run the binary, require exit 0 and return decoded stdout."""
    res = run_on(tmp_path, args, stdin=stdin, timeout=timeout)
    assert res.returncode == 0, (
        f"unexpected exit {res.returncode}: {res.stderr.decode('utf-8', 'replace')}"
    )
    # fq ends every value with a newline; compare without the trailing one.
    return res.stdout.decode("utf-8").rstrip("\n")


def fq_json(tmp_path, args, stdin=None, timeout=30):
    """Run the binary with a value-producing expression and parse JSON stdout."""
    return json.loads(run_ok(tmp_path, args, stdin=stdin, timeout=timeout))


def data_path(name: str) -> Path:
    """Absolute path of a fixture in eval/tests/data (fails loudly if absent)."""
    path = DATA_DIR / name
    if not path.exists():
        pytest.fail(f"missing test fixture: {path}")
    return path
