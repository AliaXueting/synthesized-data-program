"""Black-box tests for the flac decoders.

Covers the formats: flac, flac_frame (bits_per_sample / sample_details options),
flac_metadatablock, flac_metadatablocks, flac_streaminfo and flac_picture.

Every expected value below was recorded by running the reference fq binary on the
fixtures in eval/tests/data (the crafted fixtures were produced with the reference
binary's ``tobytes`` and a tiny python script, see the comments next to each one).
"""

import pytest

from conftest import fq_json, run_ok, run_on

MONO8 = "flac/mono8.flac"
MONO16 = "flac/mono16.flac"
PICTURE = "flac/picture_seek_gain.flac"
STEREO8 = "flac/stereo8.flac"

# frames[0] of picture_seek_gain.flac extracted with:
#   $ fq -d flac '.frames[0] | tobytes' picture_seek_gain.flac > frame_lpc16
FRAME_LPC16 = "flac/frame_lpc16"
# frames[1] of mono8.flac with the sample_size nibble cleared (0b001 -> 0b000,
# "from streaminfo") and the header CRC-8 recomputed, so that the frame only
# decodes when the bits_per_sample option is honoured.
FRAME_STREAMINFO_BPS = "flac/frame_streaminfo_bps"
# metadatablocks[0] of mono16.flac, i.e. a 4 byte block header + streaminfo.
STREAMINFO_BLOCK = "flac/streaminfo_block"
# the 34 byte streaminfo payload (STREAMINFO_BLOCK without the block header).
STREAMINFO = "flac/streaminfo"
# metadatablocks[3].picture of picture_seek_gain.flac (109 byte picture payload).
PICTURE_BLOCK = "flac/picture_block"
# all metadata blocks of mono16.flac concatenated (block headers included).
METABLOCKS = "flac/metablocks_mono16"

STREAMINFO_EXPECTED = {
    MONO8: {
        "bits_per_sample": 8,
        "channels": 1,
        "last_block": False,
        "length": 34,
        "maximum_block_size": 4096,
        "maximum_frame_size": 3851,
        "md5": "1b43073d6a826942bca82cfd2ea155f2",
        "minimum_block_size": 4096,
        "minimum_frame_size": 10,
        "sample_rate": 44100,
        "total_samples_in_stream": 22050,
        "type": "streaminfo",
    },
    MONO16: {
        "bits_per_sample": 16,
        "channels": 1,
        "last_block": False,
        "length": 34,
        "maximum_block_size": 4096,
        "maximum_frame_size": 7947,
        "md5": "29cf8eb622e9be01808ecafe817d17a6",
        "minimum_block_size": 4096,
        "minimum_frame_size": 11,
        "sample_rate": 44100,
        "total_samples_in_stream": 22050,
        "type": "streaminfo",
    },
    PICTURE: {
        "bits_per_sample": 16,
        "channels": 1,
        "last_block": False,
        "length": 34,
        "maximum_block_size": 4608,
        "maximum_frame_size": 512,
        "md5": "89887b80f810285b45f6c4ecc72c977e",
        "minimum_block_size": 4608,
        "minimum_frame_size": 512,
        "sample_rate": 44100,
        "total_samples_in_stream": 441,
        "type": "streaminfo",
    },
    STEREO8: {
        "bits_per_sample": 8,
        "channels": 2,
        "last_block": False,
        "length": 34,
        "maximum_block_size": 4096,
        "maximum_frame_size": 8206,
        "md5": "ef79009cce3bd79ef4b5668ebb98d113",
        "minimum_block_size": 4096,
        "minimum_frame_size": 12,
        "sample_rate": 44100,
        "total_samples_in_stream": 22050,
        "type": "streaminfo",
    },
}

BLOCK_CHAIN_EXPECTED = {
    MONO8: [
        {"last_block": False, "length": 34, "type": "streaminfo"},
        {"last_block": False, "length": 18, "type": "seektable"},
        {"last_block": False, "length": 40, "type": "vorbis_comment"},
        {"last_block": True, "length": 8192, "type": "padding"},
    ],
    MONO16: [
        {"last_block": False, "length": 34, "type": "streaminfo"},
        {"last_block": False, "length": 18, "type": "seektable"},
        {"last_block": False, "length": 40, "type": "vorbis_comment"},
        {"last_block": True, "length": 8192, "type": "padding"},
    ],
    PICTURE: [
        {"last_block": False, "length": 34, "type": "streaminfo"},
        {"last_block": False, "length": 18, "type": "seektable"},
        {"last_block": False, "length": 235, "type": "vorbis_comment"},
        {"last_block": False, "length": 109, "type": "picture"},
        {"last_block": True, "length": 7868, "type": "padding"},
    ],
    STEREO8: [
        {"last_block": False, "length": 34, "type": "streaminfo"},
        {"last_block": False, "length": 18, "type": "seektable"},
        {"last_block": False, "length": 40, "type": "vorbis_comment"},
        {"last_block": True, "length": 8192, "type": "padding"},
    ],
}


@pytest.mark.parametrize("fixture", [MONO8, MONO16, PICTURE, STEREO8])
def test_flac_streaminfo(fixture, tmp_path):
    """The first metadatablock is a streaminfo block with inlined fields.

    CATCHES: the 20/3/5/36 bit split of the streaminfo payload (sample rate,
    channels-1, bits per sample-1, total samples) and the 16 byte md5 hex field.
    """
    streaminfo = fq_json(tmp_path, ["-c", "-V", "-d", "flac", ".metadatablocks[0]", fixture])
    assert streaminfo == STREAMINFO_EXPECTED[fixture]


@pytest.mark.parametrize("fixture", [MONO8, MONO16, PICTURE, STEREO8])
def test_flac_metadatablock_chain(fixture, tmp_path):
    """The metadata block chain: type symbols, is-last flag and 24 bit lengths.

    CATCHES: the 4 byte block header layout (1 bit last flag, 7 bit type, 24 bit
    length) and the block type symbol table, plus that only the final padding
    block carries last_block=true.
    """
    chain = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                   "[.metadatablocks[] | {last_block, type, length}]", fixture])
    assert chain == BLOCK_CHAIN_EXPECTED[fixture]


@pytest.mark.parametrize("fixture", [MONO8, MONO16, PICTURE, STEREO8])
def test_flac_md5_of_samples(fixture, tmp_path):
    """flac recomputes the MD5 of all decoded samples and stores it in the root.

    CATCHES: the md5_calculated field is the md5 of the interleaved little endian
    decoded samples (LPC reconstruction, mid/side transform and channel
    interleaving included), and decoded_samples counts every frame's samples.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                 "{stored: .metadatablocks[0].md5, calculated: .md5_calculated,"
                 " samples: .decoded_samples, frames: (.frames | length)}",
                 fixture])
    expected = STREAMINFO_EXPECTED[fixture]
    assert out["stored"] == expected["md5"]
    assert out["calculated"] == expected["md5"]
    assert out["samples"] == expected["total_samples_in_stream"]
    assert out["frames"] == (1 if fixture == PICTURE else 6)


def test_flac_seektable_and_vorbis_comment(tmp_path):
    """The seektable block and the vorbis comment block decode their payloads.

    CATCHES: the seekpoint count is length/18 with 8+8+2 byte fields, and the
    vorbis comment list is decoded with per-comment lengths.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                   "{seektable: .metadatablocks[1], comment: .metadatablocks[2].comment}",
                   PICTURE])
    assert out["seektable"] == {
        "last_block": False,
        "length": 18,
        "seekpoints": [{"number_of_samples": 441, "offset": 0, "sample_number": 0}],
        "type": "seektable",
    }
    assert out["comment"] == {
        "user_comment_list_length": 6,
        "user_comments": [
            {"comment": "encoder=Lavf59.16.100", "length": 21},
            {"comment": "REPLAYGAIN_REFERENCE_LOUDNESS=89.0 dB", "length": 37},
            {"comment": "REPLAYGAIN_TRACK_GAIN=-24601.00 dB", "length": 34},
            {"comment": "REPLAYGAIN_TRACK_PEAK=0.12496948", "length": 32},
            {"comment": "REPLAYGAIN_ALBUM_GAIN=-24601.00 dB", "length": 34},
            {"comment": "REPLAYGAIN_ALBUM_PEAK=0.12496948", "length": 32},
        ],
        "vendor": "Lavf59.16.100",
        "vendor_length": 13,
    }


def test_flac_picture_block(tmp_path):
    """The picture metadatablock decodes both nested in the file and standalone.

    CATCHES: the picture type symbol table (3 == cover_front), the length
    prefixed mime/description strings and the width/height/depth fields, and that
    the standalone flac_picture decoder takes the bare payload (no 4 byte block
    header) and produces the same picture fields as the in-file decode.
    """
    nested = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                   ".metadatablocks[3] | del(.picture.picture_data)"
                   " + {picture_chunks: (.picture.picture_data.chunks | length),"
                   "    picture_signature: .picture.picture_data.signature}",
                   PICTURE])
    assert nested == {
        "last_block": False,
        "length": 109,
        "picture": {
            "color_depth": 1,
            "description": "",
            "description_length": 0,
            "height": 4,
            "mime": "image/png",
            "mime_length": 9,
            "number_of_index_colors": 0,
            "picture_length": 68,
            "picture_type": "cover_front",
            "width": 4,
        },
        "picture_chunks": 3,
        "picture_signature": "\ufffdPNG\r\n\u001a\n",
        "type": "picture",
    }

    standalone = fq_json(tmp_path, ["-c", "-V", "-d", "flac_picture",
                   "del(.picture_data) + {chunks: (.picture_data.chunks | length)}",
                   PICTURE_BLOCK])
    assert standalone == {
        "chunks": 3,
        "color_depth": 1,
        "description": "",
        "description_length": 0,
        "height": 4,
        "mime": "image/png",
        "mime_length": 9,
        "number_of_index_colors": 0,
        "picture_length": 68,
        "picture_type": "cover_front",
        "width": 4,
    }


def test_flac_standalone_metadata_decoders(tmp_path):
    """flac_streaminfo / flac_metadatablock / flac_metadatablocks on raw payloads.

    CATCHES: flac_metadatablock needs the 4 byte block header while flac_streaminfo
    decodes the bare 34 byte payload, and flac_metadatablocks is an array at the
    root that stops after the block with last_block=true.
    """
    payload = fq_json(tmp_path, ["-c", "-V", "-d", "flac_streaminfo", ".", STREAMINFO])
    assert payload == {
        "bits_per_sample": 16,
        "channels": 1,
        "maximum_block_size": 4096,
        "maximum_frame_size": 7947,
        "md5": "29cf8eb622e9be01808ecafe817d17a6",
        "minimum_block_size": 4096,
        "minimum_frame_size": 11,
        "sample_rate": 44100,
        "total_samples_in_stream": 22050,
    }

    block = fq_json(tmp_path, ["-c", "-V", "-d", "flac_metadatablock", ".", STREAMINFO_BLOCK])
    assert block == dict(STREAMINFO_EXPECTED[MONO16])

    blocks = fq_json(tmp_path, ["-c", "-V", "-d", "flac_metadatablocks",
                   "[.[] | {last_block, type, length}]", METABLOCKS])
    assert blocks == BLOCK_CHAIN_EXPECTED[MONO16]


def test_flac_frame_header_and_footer_crc(tmp_path):
    """flac_frame decodes a raw frame exactly like the flac decoder's .frames[0].

    CATCHES: the frame header bit layout (14 bit sync 0b11111111111110, block size
    and sample rate nibble symbol tables, 8 bit utf8 frame number, CRC-8 header
    crc) and the trailing 16 bit footer crc, with the streaminfo derived
    bits_per_sample propagated into the subframe decode.
    """
    header = fq_json(tmp_path, ["-c", "-V", "-d", "flac_frame", ".header", FRAME_LPC16])
    assert header == {
        "block_size": 7,
        "blocking_strategy": "fixed",
        "channel_assignment": 1,
        "crc": 85,
        "end_of_header": {"block_size": 441, "frame_number": 0},
        "reserved0": 0,
        "reserved1": 0,
        "sample_rate": 44100,
        "sample_size": 16,
        "sync": 16382,
    }

    subframe = fq_json(tmp_path, ["-c", "-V", "-d", "flac_frame",
                   ".subframes[0] | del(.partitions[0].residuals)", FRAME_LPC16])
    assert subframe == {
        "coefficients": [14162, 11854, 9082, 5975, 2653, -737, -4083, -7221],
        "lpc_order": 8,
        "partition_order": 0,
        "partitions": [{"count": 433, "rice_parameter": 7}],
        "precision": 15,
        "residual_coding_method": 4,
        "rice_partitions": 1,
        "shift": 15,
        "subframe_sample_size": 16,
        "subframe_type": "lpc",
        "warmup_samples": [0, 256, 511, 765, 1016, 1262, 1504, 1740],
        "wasted_bits_flag": 0,
        "zero_bit": 0,
    }

    footer = fq_json(tmp_path, ["-c", "-V", "-d", "flac_frame",
                   "{footer_crc, byte_align}", FRAME_LPC16])
    assert footer == {"byte_align": 0, "footer_crc": "7fab"}

    # the same frame decoded inside the flac file must be byte for byte identical
    in_file = run_ok(tmp_path, ["-c", "-V", "-d", "flac", ".frames[0]", PICTURE])
    standalone = run_ok(tmp_path, ["-c", "-V", "-d", "flac_frame", ".", FRAME_LPC16])
    assert standalone == in_file


def test_flac_frame_bits_per_sample_option(tmp_path):
    """The bits_per_sample option is used when the header says "from streaminfo".

    CATCHES: the default is 16 bits per sample, so a frame whose sample_size
    nibble is 0b000 mis-decodes with 16 bit subframes (and fails with a negative
    sample count), while bits_per_sample=8 decodes the original 8 bit subframes
    and validates the frame footer CRC.
    """
    default = fq_json(tmp_path, ["-c", "-V", "-d", "flac_frame",
                   "{sample_size: .header.sample_size,"
                   " subframe: (.subframes[0] | {subframe_sample_size, subframe_type,"
                   " lpc_order, warmup_samples, partition_order, rice_partitions,"
                   " partitions})}",
                   FRAME_STREAMINFO_BPS])
    assert default == {
        "sample_size": 0,
        "subframe": {
            "lpc_order": 1,
            "partition_order": 15,
            "partitions": [{"count": 18446744073709551615, "rice_parameter": 15}],
            "rice_partitions": 32768,
            "subframe_sample_size": 16,
            "subframe_type": "fixed",
            "warmup_samples": [4],
        },
    }

    res = run_on(tmp_path, ["-d", "flac_frame", "d", FRAME_STREAMINFO_BPS])
    assert res.returncode == 0
    assert "error: flac_frame: error at position 0xa.2: negative sample count -1" in \
        res.stdout.decode("utf-8")

    forced = fq_json(tmp_path, ["-o", "bits_per_sample=8", "-c", "-V", "-d", "flac_frame",
                   "{footer_crc, subframe: (.subframes[0] | {subframe_sample_size,"
                   " subframe_type, lpc_order, warmup_samples, partition_order,"
                   " rice_partitions, partitions: [.partitions[]"
                   " | {count, rice_parameter}]})}",
                   FRAME_STREAMINFO_BPS])
    assert forced == {
        "footer_crc": "5c65",
        "subframe": {
            "lpc_order": 1,
            "partition_order": 1,
            "partitions": [{"count": 2047, "rice_parameter": 0},
                           {"count": 2048, "rice_parameter": 0}],
            "rice_partitions": 2,
            "subframe_sample_size": 8,
            "subframe_type": "fixed",
            "warmup_samples": [0],
        },
    }


def test_flac_frame_sample_details_option(tmp_path):
    """sample_details=true replaces the raw residual bits with decoded values.

    CATCHES: each rice coded residual becomes {high, low, value} with a zigzag
    decoded value, and the subframe gains a reconstructed samples array that
    starts with the warmup samples.
    """
    subframe = fq_json(tmp_path, ["-o", "sample_details=true", "-c", "-V", "-d", "flac",
                   ".frames[0].subframes[0] | {warmup_samples, precision,"
                   " shift, coefficients, residual_coding_method, partition_order,"
                   " rice_partitions}",
                   PICTURE])
    assert subframe == {
        "coefficients": [14162, 11854, 9082, 5975, 2653, -737, -4083, -7221],
        "partition_order": 0,
        "precision": 15,
        "residual_coding_method": 4,
        "rice_partitions": 1,
        "shift": 15,
        "warmup_samples": [0, 256, 511, 765, 1016, 1262, 1504, 1740],
    }

    detail_keys = fq_json(tmp_path, ["-o", "sample_details=true", "-c", "-V", "-d", "flac",
                   ".frames[0].subframes[0] | keys", PICTURE])
    assert detail_keys == [
        "zero_bit", "subframe_type", "lpc_order", "wasted_bits_flag",
        "subframe_sample_size", "warmup_samples", "precision", "shift",
        "coefficients", "residual_coding_method", "partition_order",
        "rice_partitions", "partitions", "samples",
    ]

    partition = fq_json(tmp_path, ["-o", "sample_details=true", "-c", "-V", "-d", "flac",
                   ".frames[0].subframes[0].partitions[0] | {count, rice_parameter,"
                   " n: (.residuals | length), residuals: .residuals[0:4]}",
                   PICTURE])
    assert partition == {
        "count": 433,
        "n": 433,
        "residuals": [
            {"high": 1, "low": 110, "value": 119},
            {"high": 1, "low": 108, "value": 118},
            {"high": 1, "low": 106, "value": 117},
            {"high": 1, "low": 102, "value": 115},
        ],
        "rice_parameter": 7,
    }

    samples = fq_json(tmp_path, ["-o", "sample_details=true", "-c", "-V", "-d", "flac",
                   ".frames[0].subframes[0].samples | {n: length,"
                   " head: .[0:8], tail: .[-3:]}",
                   PICTURE])
    assert samples == {
        "n": 441,
        "head": [0, 256, 511, 765, 1016, 1262, 1504, 1740],
        "tail": [2984, 2803, 2610],
    }

    # without the option there is no samples array and residuals stay raw bits
    plain = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                   ".frames[0].subframes[0] | keys", PICTURE])
    assert plain == [
        "zero_bit", "subframe_type", "lpc_order", "wasted_bits_flag",
        "subframe_sample_size", "warmup_samples", "precision", "shift",
        "coefficients", "residual_coding_method", "partition_order",
        "rice_partitions", "partitions",
    ]


def test_flac_stereo_mid_side_frame(tmp_path):
    """A stereo stream uses channel_assignment=2 and mid/side subframes.

    CATCHES: the channel assignment symbol is the channel count (2), a mid/side
    frame gains a synthesized side_channel_index=1 and its side subframe gets one
    extra sample bit (9 instead of 8).
    """
    streaminfo = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                   ".metadatablocks[0] | {channels, bits_per_sample, md5}", STEREO8])
    assert streaminfo == {
        "channels": 2,
        "bits_per_sample": 8,
        "md5": "ef79009cce3bd79ef4b5668ebb98d113",
    }

    headers = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                   "[.frames[] | .header | {channel_assignment, side_channel_index}]",
                   STEREO8])
    assert headers == [
        {"channel_assignment": 2, "side_channel_index": None},
        {"channel_assignment": 2, "side_channel_index": None},
        {"channel_assignment": 2, "side_channel_index": 1},
        {"channel_assignment": 2, "side_channel_index": None},
        {"channel_assignment": 2, "side_channel_index": None},
        {"channel_assignment": 2, "side_channel_index": None},
    ]

    subframes = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                   "[.frames[2].subframes[] | {subframe_type, subframe_sample_size, lpc_order}]",
                   STEREO8])
    assert subframes == [
        {"subframe_type": "fixed", "subframe_sample_size": 8, "lpc_order": 0},
        {"subframe_type": "lpc", "subframe_sample_size": 9, "lpc_order": 1},
    ]

    footer = fq_json(tmp_path, ["-c", "-V", "-d", "flac",
                   "{md5_calculated, decoded_samples}", STEREO8])
    assert footer == {
        "md5_calculated": "ef79009cce3bd79ef4b5668ebb98d113",
        "decoded_samples": 22050,
    }
