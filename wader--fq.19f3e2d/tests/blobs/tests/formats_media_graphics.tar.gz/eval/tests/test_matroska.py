"""Black-box tests for the matroska decoder (and the shared ebml schema).

Every expected value below was recorded by running the reference fq binary on
the fixtures in eval/tests/data/matroska (single track files muxed by Lavf plus
a mkvmerge lacing sweep and an unknown-size-segment vorbis file).
"""

import pytest

from conftest import fq_json, run_on

VP9_MKV = "matroska/vp9.mkv"
VP8_MKV = "matroska/vp8.mkv"
AV1_MKV = "matroska/av1.mkv"
MPEG2_MKV = "matroska/mpeg2.mkv"
AVC_MKV = "matroska/avc.mkv"
HEVC_MKV = "matroska/hevc.mkv"
OPUS_MKV = "matroska/opus.mkv"
VORBIS_MKV = "matroska/vorbis.mkv"
AAC_MKV = "matroska/aac.mkv"
FLAC_MKV = "matroska/flac.mkv"
MP3_MKV = "matroska/mp3.mkv"
MKA = "matroska/sweep-with-DC.mkvmerge13.mka"
UNKNOWN_SIZE = "matroska/unknown_size.mkv"


def test_matroska_ebml_and_segment_layout(tmp_path):
    """matroska decodes the EBML header, the segment master and the info cluster.

    CATCHES: the ebml element order and typed values (uinteger/string), the
    root elements wrapper, the segment child ordering (seek_head, void, info,
    tracks, tags, cluster, cues) and the cluster's crc32/timestamp/simple_block
    layout with element sizes.
    """
    head = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            "{ebml: [.elements[0].elements[] | {id, type, value}], "
            "top: [.elements[] | {id, type, size}], "
            "segment: [.elements[1].elements[] | {id, type}]}",
            VP9_MKV,
        ],
    )
    assert head == {
        "ebml": [
            {"id": "ebml_version", "type": "uinteger", "value": 1},
            {"id": "ebml_read_version", "type": "uinteger", "value": 1},
            {"id": "ebml_max_id_length", "type": "uinteger", "value": 4},
            {"id": "ebml_max_size_length", "type": "uinteger", "value": 8},
            {"id": "doc_type", "type": "string", "value": "matroska"},
            {"id": "doc_type_version", "type": "uinteger", "value": 4},
            {"id": "doc_type_read_version", "type": "uinteger", "value": 2},
        ],
        "segment": [
            {"id": "seek_head", "type": "master"},
            {"id": "void", "type": "binary"},
            {"id": "info", "type": "master"},
            {"id": "tracks", "type": "master"},
            {"id": "tags", "type": "master"},
            {"id": "cluster", "type": "master"},
            {"id": "cues", "type": "master"},
        ],
        "top": [
            {"id": "ebml", "size": 35, "type": "master"},
            {"id": "segment", "size": 5970, "type": "master"},
        ],
    }

    info = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            '[.elements[1].elements[2].elements[] | select(.id=="timestamp_scale" '
            'or .id=="muxing_app" or .id=="writing_app" or .id=="duration") '
            "| {id, type, value}]",
            VP9_MKV,
        ],
    )
    assert info == [
        {"id": "timestamp_scale", "type": "uinteger", "value": 1000000},
        {"id": "muxing_app", "type": "utf8", "value": "Lavf58.45.100"},
        {"id": "writing_app", "type": "utf8", "value": "Lavf58.45.100"},
        {"id": "duration", "type": "float", "value": 40},
    ]

    cluster = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            ".elements[1].elements[5] | [.elements[] | {id, type, size}]",
            VP9_MKV,
        ],
    )
    assert cluster == [
        {"id": "crc32", "size": 4, "type": "binary"},
        {"id": "timestamp", "size": 1, "type": "uinteger"},
        {"id": "simple_block", "size": 5436, "type": "binary"},
    ]


@pytest.mark.parametrize(
    "fixture,track,settings",
    [
        pytest.param(
            VP9_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "V_VP9"},
                {"id": "track_type", "value": "video"},
                {"id": "default_duration", "value": 40000000},
            ],
            [
                {"id": "pixel_width", "value": 320},
                {"id": "pixel_height", "value": 240},
            ],
            id="vp9",
        ),
        pytest.param(
            VP8_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "V_VP8"},
                {"id": "track_type", "value": "video"},
                {"id": "default_duration", "value": 40000000},
            ],
            [
                {"id": "pixel_width", "value": 320},
                {"id": "pixel_height", "value": 240},
            ],
            id="vp8",
        ),
        pytest.param(
            AV1_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "V_AV1"},
                {"id": "track_type", "value": "video"},
                {"id": "default_duration", "value": 40000000},
            ],
            [
                {"id": "pixel_width", "value": 320},
                {"id": "pixel_height", "value": 240},
            ],
            id="av1",
        ),
        pytest.param(
            MPEG2_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "V_MPEG2"},
                {"id": "track_type", "value": "video"},
                {"id": "default_duration", "value": 40000000},
            ],
            [
                {"id": "pixel_width", "value": 320},
                {"id": "pixel_height", "value": 240},
            ],
            id="mpeg2",
        ),
        pytest.param(
            AVC_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "V_MPEG4/ISO/AVC"},
                {"id": "track_type", "value": "video"},
                {"id": "default_duration", "value": 40000000},
            ],
            [
                {"id": "pixel_width", "value": 320},
                {"id": "pixel_height", "value": 240},
            ],
            id="avc",
        ),
        pytest.param(
            HEVC_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "V_MPEGH/ISO/HEVC"},
                {"id": "track_type", "value": "video"},
                {"id": "default_duration", "value": 40000000},
            ],
            [
                {"id": "pixel_width", "value": 320},
                {"id": "pixel_height", "value": 240},
            ],
            id="hevc",
        ),
        pytest.param(
            OPUS_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "A_OPUS"},
                {"id": "track_type", "value": "audio"},
            ],
            [
                {"id": "channels", "value": 1},
                {"id": "sampling_frequency", "value": 48000},
                {"id": "bit_depth", "value": 32},
            ],
            id="opus",
        ),
        pytest.param(
            VORBIS_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "A_VORBIS"},
                {"id": "track_type", "value": "audio"},
            ],
            [
                {"id": "channels", "value": 2},
                {"id": "sampling_frequency", "value": 44100},
                {"id": "bit_depth", "value": 32},
            ],
            id="vorbis",
        ),
        pytest.param(
            AAC_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "A_AAC"},
                {"id": "track_type", "value": "audio"},
            ],
            [
                {"id": "channels", "value": 1},
                {"id": "sampling_frequency", "value": 44100},
                {"id": "bit_depth", "value": 32},
            ],
            id="aac",
        ),
        pytest.param(
            FLAC_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "A_FLAC"},
                {"id": "track_type", "value": "audio"},
            ],
            [
                {"id": "channels", "value": 2},
                {"id": "sampling_frequency", "value": 44100},
                {"id": "bit_depth", "value": 16},
            ],
            id="flac",
        ),
        pytest.param(
            MP3_MKV,
            [
                {"id": "track_number", "value": 1},
                {"id": "codec_id", "value": "A_MPEG/L3"},
                {"id": "track_type", "value": "audio"},
            ],
            [
                {"id": "channels", "value": 1},
                {"id": "sampling_frequency", "value": 44100},
                {"id": "bit_depth", "value": 16},
            ],
            id="mp3",
        ),
    ],
)
def test_matroska_track_entries(tmp_path, fixture, track, settings):
    """Every codec id maps to its track_type and video/audio settings element.

    CATCHES: the codec id string table (V_VP9..V_MPEGH/ISO/HEVC, A_OPUS..A_MPEG/L3)
    driving track_type video vs audio, default_duration only on video tracks and
    the pixel_width/pixel_height vs channels/sampling_frequency/bit_depth
    settings element decoding.
    """
    out = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            "{track: [.elements[1].elements[3].elements[1].elements[] "
            '| select(.id=="track_number" or .id=="codec_id" or .id=="track_type" '
            'or .id=="default_duration") | {id, value}], '
            "settings: [.elements[1].elements[3].elements[1].elements[] "
            '| select(.id=="video" or .id=="audio") | .elements[] | {id, value}]}',
            fixture,
        ],
    )
    assert out == {"settings": settings, "track": track}


@pytest.mark.parametrize(
    "fixture,expr,expected",
    [
        pytest.param(
            AV1_MKV,
            '[grep_by(.id == "codec_private")][0].value',
            {
                "chroma_sample_position": 0,
                "chroma_subsampling_x": 0,
                "chroma_subsampling_y": 0,
                "config_obus": [],
                "high_bitdepth": 0,
                "initial_presentation_delay_present": False,
                "marker": 1,
                "monochrome": 0,
                "reserved0": 0,
                "reserved1": 0,
                "seq_level_idx_0": 31,
                "seq_profile": 1,
                "seq_tier_0": 0,
                "twelve_bit": 0,
                "version": 1,
            },
            id="av1_ccr",
        ),
        pytest.param(
            OPUS_MKV,
            '[grep_by(.id == "codec_private")][0].value',
            {
                "channel_count": 1,
                "map_family": 0,
                "output_gain": 0,
                "pre_skip": 120,
                "prefix": "OpusHead",
                "sample_rate": 48000,
                "type": "head",
                "version": 1,
            },
            id="opus_head",
        ),
        pytest.param(
            FLAC_MKV,
            '[grep_by(.id == "codec_private")][0].value '
            "| {magic, streaminfo: .metadatablocks[0]}",
            {
                "magic": "fLaC",
                "streaminfo": {
                    "bits_per_sample": 16,
                    "channels": 2,
                    "last_block": True,
                    "length": 34,
                    "maximum_block_size": 4608,
                    "maximum_frame_size": 606,
                    "md5": "e916ab02137281386a28174fe11bffec",
                    "minimum_block_size": 4608,
                    "minimum_frame_size": 606,
                    "sample_rate": 44100,
                    "total_samples_in_stream": 2205,
                    "type": "streaminfo",
                },
            },
            id="flac_metadatablocks",
        ),
        pytest.param(
            AAC_MKV,
            '[grep_by(.id == "codec_private")][0].value '
            "| del(.var_aot_or_byte_align)",
            {
                "channel_configuration": 1,
                "object_type": "aac_lc",
                "sampling_frequency": 44100,
            },
            id="mpeg_asc",
        ),
        pytest.param(
            AVC_MKV,
            '[grep_by(.id == "codec_private")][0].value '
            "| {configuration_version, profile_indication, profile_compatibility, "
            "level_indication, length_size, num_of_sequence_parameter_sets, "
            "num_of_picture_parameter_sets}",
            {
                "configuration_version": 1,
                "length_size": 4,
                "level_indication": "1.3",
                "num_of_picture_parameter_sets": 1,
                "num_of_sequence_parameter_sets": 1,
                "profile_compatibility": 0,
                "profile_indication": "high_444_predictive_profile",
            },
            id="avc_dcr",
        ),
        pytest.param(
            HEVC_MKV,
            '[grep_by(.id == "codec_private")][0].value '
            "| {configuration_version, general_profile_idc, general_level_idc, "
            "chroma_format_idc, bit_depth_luma, bit_depth_chroma, num_of_arrays, "
            "length_size, avg_frame_rate, constant_frame_rate, "
            "arrays: [.arrays[] | {nal_unit_type, num_nalus, "
            "array_completeness}]}",
            {
                "arrays": [
                    {"array_completeness": 0, "nal_unit_type": "VPS_NUT", "num_nalus": 1},
                    {"array_completeness": 0, "nal_unit_type": "SPS_NUT", "num_nalus": 1},
                    {"array_completeness": 0, "nal_unit_type": "PPS_NUT", "num_nalus": 1},
                    {
                        "array_completeness": 0,
                        "nal_unit_type": "PREFIX_SEI_NUT",
                        "num_nalus": 1,
                    },
                ],
                "avg_frame_rate": 0,
                "bit_depth_chroma": 8,
                "bit_depth_luma": 8,
                "chroma_format_idc": 3,
                "configuration_version": 1,
                "constant_frame_rate": 0,
                "general_level_idc": 60,
                "general_profile_idc": 4,
                "length_size": 4,
                "num_of_arrays": 4,
            },
            id="hevc_dcr",
        ),
    ],
)
def test_matroska_codec_private_routing(tmp_path, fixture, expr, expected):
    """The codec_id chooses which nested decoder consumes CodecPrivate.

    CATCHES: the routing table V_AV1->av1_ccr, A_OPUS->OpusHead, A_FLAC->fLaC
    metadatablocks, A_AAC->MPEG ASC, V_MPEG4/ISO/AVC->avc DCR and
    V_MPEGH/ISO/HEVC->hevc DCR, each with its exact decoded field values.
    """
    out = fq_json(tmp_path, ["-d", "matroska", "-c", "-V", expr, fixture])
    assert out == expected


@pytest.mark.parametrize(
    "fixture,block,packet",
    [
        pytest.param(
            VP9_MKV,
            {
                "flags": {
                    "discardable": False,
                    "invisible": False,
                    "key_frame": True,
                    "lacing": "none",
                    "reserved": 0,
                },
                "id": "simple_block",
                "size": 5436,
                "timestamp": 0,
                "track_number": 1,
                "type": "binary",
            },
            {
                "bit_depth": 8,
                "color_range": 1,
                "color_space": "rgb",
                "error_resilient_mode": 0,
                "frame_height": 240,
                "frame_marker": 2,
                "frame_sync_byte_0": 73,
                "frame_sync_byte_1": 131,
                "frame_sync_byte_2": 66,
                "frame_type": "key_frame",
                "frame_width": 320,
                "profile": 1,
                "profile_high_bit": 0,
                "profile_low_bit": 1,
                "reserved_zero2": 0,
                "show_existing_frame": False,
                "show_frame": 1,
                "subsampling_x": 0,
                "subsampling_y": 0,
            },
            id="vp9",
        ),
        pytest.param(
            VP8_MKV,
            {
                "flags": {
                    "discardable": False,
                    "invisible": False,
                    "key_frame": True,
                    "lacing": "none",
                    "reserved": 0,
                },
                "id": "simple_block",
                "size": 4678,
                "timestamp": 0,
                "track_number": 1,
                "type": "binary",
            },
            {
                "height": 240,
                "height0": 240,
                "height1": 0,
                "horizontal_scale": 0,
                "start_code": 10289450,
                "tag": {
                    "first_part_size": 725,
                    "first_part_size0": 5,
                    "first_part_size1": 90,
                    "frame_type": "key_frame",
                    "loop": "Normal",
                    "reconstruction": "Bicubic",
                    "show_frame": 1,
                    "version": 0,
                },
                "vertical_scale": 0,
                "width": 320,
                "width0": 64,
                "width1": 1,
            },
            id="vp8",
        ),
    ],
)
def test_matroska_simple_block_nested_frames(tmp_path, fixture, block, packet):
    """simple_block elements carry the frame flags and a nested frame decode.

    CATCHES: the simple_block bit unpacking (key_frame/lacing/reserved flags,
    track_number, timestamp) and that the packet of an unlaced video block is
    decoded by the codec's own frame decoder (vp9_frame/vp8_frame here).
    """
    out = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            "{block: (.elements[1].elements[5].elements[2] | del(.packet)), "
            "packet: (.elements[1].elements[5].elements[2].packet | del(.data))}",
            fixture,
        ],
    )
    assert out == {"block": block, "packet": packet}


def test_matroska_av1_obu_and_opus_toc_packets(tmp_path):
    """AV1 simple blocks decode to an OBU list and opus blocks to a toc packet.

    CATCHES: V_AV1 packets routed into av1_frame (OBU types and sizes, with the
    sequence header payload decoded) and A_OPUS packets routed into an opus
    packet with its toc config/frames_per_packet and per-block timestamps.
    """
    obus = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            ".elements[1].elements[5].elements[2].packet "
            "| [.[] | {type: .header.type, size}]",
            AV1_MKV,
        ],
    )
    assert obus == [
        {"size": 13, "type": "sequence_header"},
        {"size": 16, "type": "frame_header"},
        {"size": 4464, "type": "tile_group"},
    ]

    seq_header = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            ".elements[1].elements[5].elements[2].packet[0] | {seq_profile, "
            "frame_width, frame_height, color_config: (.color_config "
            "| {bit_depth, color_primaries})}",
            AV1_MKV,
        ],
    )
    assert seq_header == {
        "color_config": {"bit_depth": 8, "color_primaries": "unspecified"},
        "frame_height": 240,
        "frame_width": 320,
        "seq_profile": "high",
    }

    opus = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            '{timestamps: [grep_by(.id == "simple_block") | .timestamp], '
            'packet: ([grep_by(.id == "simple_block")][0].packet '
            "| {type, toc: (.toc | {stereo, config, frames_per_packet})})}",
            OPUS_MKV,
        ],
    )
    assert opus == {
        "packet": {
            "toc": {
                "config": {
                    "bandwidth": "fb",
                    "config": 31,
                    "frame_size": 20,
                    "mode": "celt_only",
                },
                "frames_per_packet": {"config": 0, "frames": 1, "mode": "1 frame"},
                "stereo": False,
            },
            "type": "audio",
        },
        "timestamps": [0, 21],
    }


def test_matroska_block_lacing(tmp_path):
    """simple_block lacing decodes lace sizes and each lace's nested frame.

    CATCHES: the three lacing modes (fixed has no lace_sizes, xiph and ebml
    store per-lace sizes), the num_laces count, the flac frame decode of each
    lace and the fLaC streaminfo codec private of the audio track.
    """
    lacing = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "simple_block") | {lacing: .flags.lacing, '
            "ts: .timestamp, num_laces, lace_sizes}]",
            MKA,
        ],
    )
    assert lacing == [
        {"lace_sizes": None, "lacing": "fixed", "num_laces": 7, "ts": 0},
        {"lace_sizes": None, "lacing": "fixed", "num_laces": 7, "ts": 14337},
        {"lace_sizes": [239, 240], "lacing": "xiph", "num_laces": 2, "ts": 28674},
        {
            "lace_sizes": [240, 240, 240, 240, 240, 241, 241],
            "lacing": "xiph",
            "num_laces": 7,
            "ts": 0,
        },
        {
            "lace_sizes": [241, 241, 242, 242, 243, 243, 244],
            "lacing": "xiph",
            "num_laces": 7,
            "ts": 14337,
        },
        {"lace_sizes": [243, 245], "lacing": "xiph", "num_laces": 2, "ts": 28674},
        {
            "lace_sizes": [246, 247, 246, 246, 250, 249, 250],
            "lacing": "xiph",
            "num_laces": 7,
            "ts": 0,
        },
        {
            "lace_sizes": [250, 191, 196, 191, 191, 194, 191],
            "lacing": "ebml",
            "num_laces": 7,
            "ts": 14337,
        },
        {"lace_sizes": [259, 196], "lacing": "ebml", "num_laces": 2, "ts": 28674},
        {
            "lace_sizes": [265, 194, 188, 189, 199, 194],
            "lacing": "ebml",
            "num_laces": 6,
            "ts": 0,
        },
    ]

    lace0 = fq_json(
        tmp_path,
        ["-d", "matroska", "-c", "-V", '[grep_by(.id == "simple_block")][0].laces[0]', MKA],
    )
    assert lace0 == {
        "byte_align": 0,
        "footer_crc": "0f18",
        "footer_crc_calculated": "\x0f\x18",
        "header": {
            "block_size": 7,
            "blocking_strategy": "fixed",
            "channel_assignment": 1,
            "crc": 236,
            "end_of_header": {"block_size": 1792, "frame_number": 0},
            "reserved0": 0,
            "reserved1": 0,
            "sample_rate": 44100,
            "sample_size": 16,
            "sync": 16382,
        },
        "subframes": [
            {
                "subframe_sample_size": 16,
                "subframe_type": "constant",
                "value": 0,
                "wasted_bits_flag": 0,
                "zero_bit": 0,
            }
        ],
    }

    private = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "codec_private")][0].value | {magic, '
            "streaminfo: .metadatablocks[0], blocks: [.metadatablocks[] | .type]}",
            MKA,
        ],
    )
    assert private == {
        "blocks": ["streaminfo", "seektable", "vorbis_comment"],
        "magic": "fLaC",
        "streaminfo": {
            "bits_per_sample": 16,
            "channels": 1,
            "last_block": False,
            "length": 34,
            "maximum_block_size": 1792,
            "maximum_frame_size": 274,
            "md5": "eea5a5a4ac1fdf1e46fd077c533b791f",
            "minimum_block_size": 1792,
            "minimum_frame_size": 13,
            "sample_rate": 44100,
            "total_samples_in_stream": 115000,
            "type": "streaminfo",
        },
    }


def test_matroska_unknown_size_segment(tmp_path):
    """A segment with unknown size decodes and its vorbis private is xiph laced.

    CATCHES: the 8 byte all-ones segment size (72057594037927935), the segment
    still ending at the last cluster, and A_VORBIS CodecPrivate decoded as
    xiph-laced vorbis identification/comment/setup packets on the element.
    """
    top = fq_json(
        tmp_path,
        ["-d", "matroska", "-c", "-V", "[.elements[] | {id, type, size}]", UNKNOWN_SIZE],
    )
    assert top == [
        {"id": "ebml", "size": 35, "type": "master"},
        {"id": "segment", "size": 72057594037927935, "type": "master"},
    ]

    segment = fq_json(
        tmp_path,
        ["-d", "matroska", "-c", "-V", "[.elements[1].elements[] | {id, type}]", UNKNOWN_SIZE],
    )
    assert segment == [
        {"id": "seek_head", "type": "master"},
        {"id": "void", "type": "binary"},
        {"id": "info", "type": "master"},
        {"id": "tracks", "type": "master"},
        {"id": "tags", "type": "master"},
        {"id": "cluster", "type": "master"},
    ]

    lacing = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "codec_private")][0] '
            "| {num_laces, lace_sizes, laces_len: (.laces|length)}",
            UNKNOWN_SIZE,
        ],
    )
    assert lacing == {"lace_sizes": [30, 93], "laces_len": 3, "num_laces": 2}

    laces = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "codec_private")][0].laces '
            "| [.[0], .[1], (.[2] | del(.data))]",
            UNKNOWN_SIZE,
        ],
    )
    assert laces == [
        {
            "audio_channels": 1,
            "audio_sample_rate": 44100,
            "bitrate_maximum": 0,
            "bitrate_minimum": 0,
            "bitrate_nominal": 80000,
            "blocksize_0": 256,
            "blocksize_1": 2048,
            "framing_flag": 1,
            "magic": "vorbis",
            "packet_type": "identification",
            "padding0": "\x00",
            "vorbis_version": 0,
        },
        {
            "comment": {
                "user_comment_list_length": 1,
                "user_comments": [{"comment": "encoder=Lavc59.37.100", "length": 21}],
                "vendor": (
                    "Xiph.Org libVorbis I 20200704 (Reducing Environment)"
                ),
                "vendor_length": 52,
            },
            "frame_bit": 1,
            "magic": "vorbis",
            "packet_type": "comment",
            "padding0": "\x00",
        },
        {
            "codebook_dimensions": 1,
            "codebook_entries": 64,
            "codecooke_sync": 5653314,
            "magic": "vorbis",
            "packet_type": "setup",
            "vorbis_codebook_count": 35,
        },
    ]


def test_matroska_decode_samples_option(tmp_path):
    """decode_samples=false keeps block packets and laces as raw binary.

    CATCHES: the option only disables the per-packet/per-lace nested decodes
    (packet becomes a string, laces become strings) while the element keys,
    lacing metadata and the codec_private decodes are unaffected.
    """
    raw = fq_json(
        tmp_path,
        [
            "-o",
            "decode_samples=false",
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "simple_block")][0] '
            "| {packet_type: (.packet|type), keys: keys}",
            VP9_MKV,
        ],
    )
    assert raw == {
        "keys": ["id", "type", "size", "track_number", "timestamp", "flags", "packet"],
        "packet_type": "string",
    }

    decoded = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "simple_block")][0] '
            "| {packet_type: (.packet|type), keys: keys}",
            VP9_MKV,
        ],
    )
    assert decoded == {
        "keys": ["id", "type", "size", "track_number", "timestamp", "flags", "packet"],
        "packet_type": "object",
    }

    raw_laces = fq_json(
        tmp_path,
        [
            "-o",
            "decode_samples=false",
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "simple_block")][0] '
            "| {lace0_type: (.laces[0]|type), num_laces, lace_sizes}",
            MKA,
        ],
    )
    assert raw_laces == {"lace0_type": "string", "lace_sizes": None, "num_laces": 7}

    # the codec_private decode is not a sample decode and still happens
    private_keys = fq_json(
        tmp_path,
        [
            "-o",
            "decode_samples=false",
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "codec_private")][0].value | keys',
            FLAC_MKV,
        ],
    )
    assert private_keys == ["magic", "metadatablocks"]


def test_matroska_path_builtin(tmp_path):
    """The matroska_path builtin resolves dot paths to elements and back.

    CATCHES: matroska_path(".segment.tracks[0]...") returns the element value
    (not just .value), the no-argument form rebuilds the dot path of an element
    and a non-decode input is a runtime error with exit code 5.
    """
    element = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            'matroska_path(".segment.tracks[0].track_entry[0].codec_id")',
            VP9_MKV,
        ],
    )
    assert element == {"id": "codec_id", "size": 5, "type": "string", "value": "V_VP9"}

    path = fq_json(
        tmp_path,
        [
            "-d",
            "matroska",
            "-c",
            "-V",
            '[grep_by(.id == "codec_id")][0] | matroska_path',
            VP9_MKV,
        ],
    )
    assert path == ".segment.tracks.track_entry.codec_id"

    segment_path = fq_json(
        tmp_path,
        ["-d", "matroska", "-c", "-V", ".elements[1] | matroska_path", VP9_MKV],
    )
    assert segment_path == ".segment"

    res = run_on(
        tmp_path,
        ["-d", "matroska", "-c", "-V", '1 | matroska_path(".segment")', VP9_MKV],
    )
    assert res.returncode == 5
    assert (
        "error: vp9.mkv: expected decode value but got: number (1)"
        in res.stderr.decode("utf-8")
    )
