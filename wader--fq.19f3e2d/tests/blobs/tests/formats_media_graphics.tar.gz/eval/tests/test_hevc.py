"""Black-box tests for the H.265/HEVC decoders.

Covers: hevc_annexb, hevc_au, hevc_dcr, hevc_nalu, hevc_pps, hevc_sps and
hevc_vps.  Every expected value below was recorded by running the reference fq
binary on the fixtures in eval/tests/data.

Fixtures crafted for this module:
* hevc_vps_rbsp / hevc_sps_rbsp / hevc_pps_rbsp: the VPS/SPS/PPS RBSPs of
  mpeg/hevc_annexb with the 2 byte nal header and the emulation-prevention
  bytes removed, so the standalone hevc_vps/hevc_sps/hevc_pps decoders can be
  exercised directly.
* hevc_nalu_pps: the 8 byte PPS_NUT nal unit (2 byte header + rbsp) of the
  annexb stream, for hevc_nalu.
* hevc_au_len4: the annexb VPS+SPS+PPS nal units re-wrapped with 4 byte
  big-endian lengths.
"""

from conftest import fq_json

ANNEXB = "mpeg/hevc_annexb"
DCR = "mpeg/hevc_dcr_regression0"
VPS_RBSP = "mpeg/hevc_vps_rbsp"
SPS_RBSP = "mpeg/hevc_sps_rbsp"
PPS_RBSP = "mpeg/hevc_pps_rbsp"
NALU_PPS = "mpeg/hevc_nalu_pps"
AU_LEN4 = "mpeg/hevc_au_len4"

# hevc_vps on hevc_vps_rbsp (identical to the rbsp nested in the annexb stream
# and inside the length-prefixed access unit).
VPS = {
    "general_frame_only_constraint_flag": True,
    "general_inbld_flag": False,
    "general_interlaced_source_flag": False,
    "general_intra_constraint_flag": False,
    "general_level_idc": 60,
    "general_lower_bit_rate_constraint_flag": True,
    "general_max_10bit_constraint_flag": True,
    "general_max_12bit_constraint_flag": True,
    "general_max_420chroma_constraint_flag": False,
    "general_max_422chroma_constraint_flag": False,
    "general_max_8bit_constraint_flag": True,
    "general_max_monochrome_constraint_flag": False,
    "general_non_packed_constraint_flag": False,
    "general_one_picture_only_constraint_flag": False,
    "general_profile_compatibility_flags": [
        False, False, False, False, True, False, False, False,
        False, False, False, False, False, False, False, False,
        False, False, False, False, False, False, False, False,
        False, False, False, False, False, False, False, False,
    ],
    "general_profile_idc": 4,
    "general_profile_space": 0,
    "general_progressive_source_flag": True,
    "general_reserved_zero_34bits": 0,
    "general_tier_flag": 0,
    "layer_id_included_sets_flags": [[False]],
    "sub_layer_presents": [],
    "sub_layers": [],
    "unknown": "\ufffd",
    "vps_base_layer_available_flag": True,
    "vps_base_layer_internal_flag": True,
    "vps_max_layer_id": 0,
    "vps_max_layers_minus1": 0,
    "vps_max_sub_layers_minus1": 0,
    "vps_num_layer_sets_minus1": 0,
    "vps_reserved_0xffff_16bits": 65535,
    "vps_sub_layer_ordering_info_present_flag": True,
    "vps_sub_layer_ordering_infos": [
        {
            "sps_max_dec_pic_buffering_minus1": 4,
            "sps_max_latency_increase_plus1": 5,
            "sps_max_num_reorder_pics": 2
        }
    ],
    "vps_temporal_id_nesting_flag": True,
    "vps_timing_info_present_flag": False,
    "vps_video_parameter_set_id": 0
}

# hevc_sps on hevc_sps_rbsp (identical to the rbsp nested in the annexb stream
# and inside the length-prefixed access unit).
SPS = {
    "amp_enabled_flag": False,
    "bit_depth_chroma_minus8": 0,
    "bit_depth_luma_minus8": 0,
    "chroma_format_idc": "4:4:4",
    "conformance_window_flag": False,
    "general_frame_only_constraint_flag": True,
    "general_inbld_flag": False,
    "general_interlaced_source_flag": False,
    "general_intra_constraint_flag": False,
    "general_level_idc": 60,
    "general_lower_bit_rate_constraint_flag": True,
    "general_max_10bit_constraint_flag": True,
    "general_max_12bit_constraint_flag": True,
    "general_max_420chroma_constraint_flag": False,
    "general_max_422chroma_constraint_flag": False,
    "general_max_8bit_constraint_flag": True,
    "general_max_monochrome_constraint_flag": False,
    "general_non_packed_constraint_flag": False,
    "general_one_picture_only_constraint_flag": False,
    "general_profile_compatibility_flags": [
        False, False, False, False, True, False, False, False,
        False, False, False, False, False, False, False, False,
        False, False, False, False, False, False, False, False,
        False, False, False, False, False, False, False, False,
    ],
    "general_profile_idc": 4,
    "general_profile_space": 0,
    "general_progressive_source_flag": True,
    "general_reserved_zero_34bits": 0,
    "general_tier_flag": 0,
    "log2_diff_max_min_luma_coding_block_size": 3,
    "log2_diff_max_min_luma_transform_block_size": 3,
    "log2_max_pic_order_cnt_lsb_minus4": 4,
    "log2_min_luma_coding_block_size_minus3": 0,
    "log2_min_luma_transform_block_size_minus2": 0,
    "long_term_ref_pics_present_flag": False,
    "max_transform_hierarchy_depth_inter": 0,
    "max_transform_hierarchy_depth_intra": 0,
    "num_short_term_ref_pic_sets": 0,
    "pcm_enabled_flag": False,
    "pic_height_in_luma_samples": 240,
    "pic_width_in_luma_samples": 320,
    "sample_adaptive_offset_enabled_flag": True,
    "scaling_list_enabled_flag": False,
    "separate_colour_plane_flag": False,
    "sps_extension_present_flag": False,
    "sps_max_sub_layers_minus1": 0,
    "sps_seq_parameter_set_id": 0,
    "sps_sub_layer_ordering_info_present_flag": True,
    "sps_sub_layer_ordering_infos": [
        {
            "sps_max_dec_pic_buffering_minus1": 4,
            "sps_max_latency_increase_plus1": 5,
            "sps_max_num_reorder_pics": 2
        }
    ],
    "sps_temporal_id_nesting_flag": True,
    "sps_temporal_mvp_enabled_flag": True,
    "sps_video_parameter_set_id": 0,
    "strong_intra_smoothing_enabled_flag": True,
    "sub_layer_presents": [],
    "sub_layers": [],
    "unknown": "\ufffd",
    "vui_parameters": {
        "aspect_ratio_idc": "1:1",
        "aspect_ratio_info_present_flag": True,
        "bitstream_restriction_flag": False,
        "chroma_loc_info_present_flag": False,
        "colour_description_present_flag": True,
        "colour_primaries": "unspecified",
        "default_display_window_flag": False,
        "field_seq_flag": False,
        "frame_field_info_present_flag": False,
        "matrix_coefficients": "rgb",
        "neutral_chroma_indication_flag": False,
        "overscan_info_present_flag": False,
        "transfer_characteristics": "unspecified",
        "video_format": "unspecified",
        "video_full_range_flag": True,
        "video_signal_type_present_flag": True,
        "vui_hrd_parameters_present_flag": False,
        "vui_num_units_in_tick": 1,
        "vui_poc_proportional_to_timing_flag": False,
        "vui_time_scale": 25,
        "vui_timing_info_present_flag": True
    },
    "vui_parameters_present_flag": True
}

# hevc_pps on hevc_pps_rbsp (the PPS of the annexb stream; also the rbsp
# nested inside the hevc_nalu decode of hevc_nalu_pps).
PPS = {
    "cabac_init_present_flag": False,
    "constrained_intra_pred_flag": False,
    "cu_qp_delta_enabled_flag": True,
    "deblocking_filter_control_present_flag": False,
    "dependent_slice_segments_enabled_flag": False,
    "diff_cu_qp_delta_depth": 1,
    "entropy_coding_sync_enabled_flag": True,
    "init_qp_minus26": 0,
    "lists_modification_present_flag": False,
    "log2_parallel_merge_level_minus2": 0,
    "num_extra_slice_header_bits": 0,
    "num_ref_idx_l0_default_active_minus1": 0,
    "num_ref_idx_l1_default_active_minus1": 0,
    "output_flag_present_flag": False,
    "pps_cb_qp_offset": 6,
    "pps_cr_qp_offset": 6,
    "pps_extension_present_flag": False,
    "pps_loop_filter_across_slices_enabled_flag": True,
    "pps_pic_parameter_set_id": 0,
    "pps_scaling_list_data_present_flag": False,
    "pps_seq_parameter_set_id": 0,
    "pps_slice_chroma_qp_offsets_present_flag": False,
    "sign_data_hiding_enabled_flag": True,
    "slice_segment_header_extension_present_flag": False,
    "tiles_enabled_flag": False,
    "transform_skip_enabled_flag": False,
    "transquant_bypass_enabled_flag": False,
    "unknown": "\ufffd",
    "weighted_bipred_flag": False,
    "weighted_pred_flag": True
}

ANNEXB_CHAIN = [
    {"start_code": 4},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": 21,
        "nal_unit_type": "VPS_NUT",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1,
        "rbsp_fields": 36
    },
    {"start_code": 4},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": 41,
        "nal_unit_type": "SPS_NUT",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1,
        "rbsp_fields": 54
    },
    {"start_code": 4},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": None,
        "nal_unit_type": "PPS_NUT",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1,
        "rbsp_fields": 30
    },
    {"start_code": 3},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": None,
        "nal_unit_type": "PREFIX_SEI_NUT",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1,
        "rbsp_fields": 1
    },
    {"start_code": 3},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": None,
        "nal_unit_type": "IDR_N_LP",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1,
        "rbsp_fields": 1
    }
]

# hevc_dcr on mpeg/hevc_dcr_regression0, top level fields without .arrays.
DCR_TOP = {
    "avg_frame_rate": 0,
    "bit_depth_chroma": 8,
    "bit_depth_luma": 8,
    "chroma_format_idc": 1,
    "configuration_version": 1,
    "constant_frame_rate": 0,
    "general_constraint_indicator_flags": 193514046488576,
    "general_level_idc": 123,
    "general_profile_compatibility_flags": 1610612736,
    "general_profile_idc": 1,
    "general_profile_space": 0,
    "general_tier_flag": 0,
    "length_size": 4,
    "min_spatial_segmentation_idc": 0,
    "num_of_arrays": 3,
    "num_temporal_layers": 1,
    "parallelism_type": 0,
    "reserved0": 15,
    "reserved1": 63,
    "reserved2": 63,
    "reserved3": 31,
    "reserved4": 31,
    "temporal_id_nested": 0
}

DCR_ARRAYS = [
    {
        "array_completeness": 1,
        "nal_unit_type": "VPS_NUT",
        "nals": [
            {
                "gap0_bytes": 24,
                "nal_unit_length": 26,
                "nal_unit_type": "VPS_NUT",
                "nuh_layer_id": 0,
                "nuh_temporal_id_plus1": 1,
                "rbsp_fields": 28
            }
        ],
        "num_nalus": 1,
        "reserved0": 0
    },
    {
        "array_completeness": 1,
        "nal_unit_type": "SPS_NUT",
        "nals": [
            {
                "gap0_bytes": 36,
                "nal_unit_length": 38,
                "nal_unit_type": "SPS_NUT",
                "nuh_layer_id": 0,
                "nuh_temporal_id_plus1": 1,
                "rbsp_fields": 50
            }
        ],
        "num_nalus": 1,
        "reserved0": 0
    },
    {
        "array_completeness": 1,
        "nal_unit_type": "PPS_NUT",
        "nals": [
            {
                "gap0_bytes": None,
                "nal_unit_length": 7,
                "nal_unit_type": "PPS_NUT",
                "nuh_layer_id": 0,
                "nuh_temporal_id_plus1": 1,
                "rbsp_fields": 34
            }
        ],
        "num_nalus": 1,
        "reserved0": 0
    }
]

# Selected fields of the VPS/SPS/PPS rbps nested in the hvcC record (they are
# different parameter sets than the annexb ones above).
DCR_VPS_SEL = {
    "general_level_idc": 123,
    "general_non_packed_constraint_flag": True,
    "general_profile_idc": 1,
    "reserved_zero_2bits": [0, 0, 0, 0, 0, 0, 0],
    "sub_layer_presents": [{"sub_layer_level_present_flag": False, "sub_layer_profile_present_flag": False}],
    "sub_layers": [{}],
    "vps_max_layers_minus1": 0,
    "vps_max_sub_layers_minus1": 1,
    "vps_sub_layer_ordering_info_present_flag": False,
    "vps_sub_layer_ordering_infos": [
        {
            "sps_max_dec_pic_buffering_minus1": 4,
            "sps_max_latency_increase_plus1": 0,
            "sps_max_num_reorder_pics": 2
        }
    ],
    "vps_video_parameter_set_id": 0
}

DCR_SPS_SEL = {
    "bit_depth_chroma_minus8": 0,
    "bit_depth_luma_minus8": 0,
    "chroma_format_idc": "4:2:0",
    "conf_win_bottom_offset": 4,
    "conf_win_top_offset": 0,
    "conformance_window_flag": True,
    "general_level_idc": 123,
    "general_profile_idc": 1,
    "log2_max_pic_order_cnt_lsb_minus4": 7,
    "pic_height_in_luma_samples": 1088,
    "pic_width_in_luma_samples": 1920,
    "scaling_list_enabled_flag": True,
    "sps_max_sub_layers_minus1": 1,
    "sps_scaling_list_data_present_flag": False,
    "sps_temporal_id_nesting_flag": False,
    "sps_video_parameter_set_id": 0,
    "strong_intra_smoothing_enabled_flag": False,
    "sub_layer_presents": [{"sub_layer_level_present_flag": False, "sub_layer_profile_present_flag": False}]
}

DCR_VUI = {
    "aspect_ratio_info_present_flag": False,
    "bitstream_restriction_flag": False,
    "chroma_loc_info_present_flag": False,
    "colour_description_present_flag": True,
    "colour_primaries": "bt709",
    "default_display_window_flag": False,
    "field_seq_flag": False,
    "frame_field_info_present_flag": False,
    "matrix_coefficients": "bt709",
    "neutral_chroma_indication_flag": False,
    "overscan_info_present_flag": False,
    "transfer_characteristics": "bt709",
    "video_format": "unspecified",
    "video_full_range_flag": False,
    "video_signal_type_present_flag": True,
    "vui_timing_info_present_flag": False
}

DCR_PPS_SEL = {
    "cu_qp_delta_enabled_flag": True,
    "deblocking_filter_control_present_flag": True,
    "dependent_slice_segments_enabled_flag": False,
    "diff_cu_qp_delta_depth": 2,
    "entropy_coding_sync_enabled_flag": True,
    "num_ref_idx_l0_default_active_minus1": 1,
    "pps_deblocking_filter_disabled_flag": False,
    "pps_extension_present_flag": False,
    "pps_loop_filter_across_slices_enabled_flag": False,
    "pps_pic_parameter_set_id": 0,
    "pps_seq_parameter_set_id": 0,
    "sign_data_hiding_enabled_flag": False,
    "weighted_pred_flag": False
}

AU_ANNEXB = [
    "start_code", "VPS_NUT", "start_code", "SPS_NUT", "start_code", "PPS_NUT", "start_code", "PREFIX_SEI_NUT",
    "start_code", "IDR_N_LP",
]

AU_LEN4_LIST = [
    {
        "length": 23,
        "nal_unit_type": "VPS_NUT",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1
    },
    {
        "length": 43,
        "nal_unit_type": "SPS_NUT",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1
    },
    {
        "length": 8,
        "nal_unit_type": "PPS_NUT",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1
    }
]


def test_hevc_annexb_start_codes_and_nalu_types(tmp_path):
    """hevc_annexb interleaves start codes and 2 byte header nal units.

    CATCHES: 3 vs 4 byte start code detection, the 1/6/6/3 bit split of the
    hevc nal header into forbidden_zero_bit/nal_unit_type/nuh_layer_id/
    nuh_temporal_id_plus1, the NUT symbol table (VPS_NUT/SPS_NUT/PPS_NUT/
    PREFIX_SEI_NUT/IDR_N_LP) and the emulation-prevention gap left in the
    original nal unit when its rbsp had to be unescaped.
    """
    chain = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_annexb",
                   "[.[] | if type == \"string\" then {start_code: (tobytes|length)}"
                   " else {nal_unit_type, nuh_layer_id, nuh_temporal_id_plus1,"
                   " forbidden_zero_bit,"
                   " gap0_bytes: (try (.gap0|tobytes|length) catch null),"
                   " rbsp_fields: (.rbsp|length)} end]",
                   ANNEXB])
    assert chain == ANNEXB_CHAIN


def test_hevc_vps_standalone_and_nested(tmp_path):
    """hevc_vps decodes profile/tier/level, sub layers and ordering info.

    CATCHES: the unescaped VPS rbsp must decode to the exact same value both
    standalone and nested inside hevc_annexb (the 32 entry profile
    compatibility flag array, the 0xffff reserved field, layer id included
    sets and the sub layer ordering info list).
    """
    vps = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_vps", ".", VPS_RBSP])
    assert vps == VPS

    nested = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_annexb", ".[1].rbsp", ANNEXB])
    assert nested == VPS


def test_hevc_sps_standalone_and_nested(tmp_path):
    """hevc_sps decodes chroma format, coding block sizes and the full vui.

    CATCHES: the unescaped SPS rbsp must decode identically standalone and
    nested (chroma_format_idc symbols, log2 min/diff coding and transform
    block sizes, pic dimensions in luma samples and the nested
    vui_parameters with its colour description symbols).
    """
    sps = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_sps", ".", SPS_RBSP])
    assert sps == SPS

    nested = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_annexb", ".[3].rbsp", ANNEXB])
    assert nested == SPS


def test_hevc_pps_and_nalu(tmp_path):
    """hevc_pps decodes the picture parameter set; hevc_nalu wraps it.

    CATCHES: hevc_nalu splits its 2 byte header and dispatches PPS_NUT rbsp
    to the hevc_pps decoder, so the nested rbsp must equal the standalone
    hevc_pps decode of the same bytes (tiles/entropy sync flags, qp offsets
    and the diff_cu_qp_delta_depth exp-Golomb value).
    """
    pps = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_pps", ".", PPS_RBSP])
    assert pps == PPS

    nalu = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_nalu", ".", NALU_PPS])
    assert nalu == {
        "forbidden_zero_bit": False,
        "nal_unit_type": "PPS_NUT",
        "nuh_layer_id": 0,
        "nuh_temporal_id_plus1": 1,
        "rbsp": PPS,
    }


def test_hevc_dcr(tmp_path):
    """hevc_dcr decodes an hvcC record and nests VPS/SPS/PPS nal arrays.

    CATCHES: the packed hvcC header (length_size stored minus one inside the
    reserved bit fields, chroma_format_idc as a raw number here but as a
    symbol inside the nested sps rbsp), one array per NUT selected by
    nal_unit_type, and the length-prefixed nals with their emulation gap.
    """
    top = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_dcr", "del(.arrays)", DCR])
    assert top == DCR_TOP

    arrays = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_dcr",
                   "[.arrays[] | {array_completeness, nal_unit_type, num_nalus, reserved0,"
                   " nals: [.nals[] | {nal_unit_length, nal_unit_type: .nal.nal_unit_type,"
                   " nuh_layer_id: .nal.nuh_layer_id,"
                   " nuh_temporal_id_plus1: .nal.nuh_temporal_id_plus1,"
                   " gap0_bytes: (try (.nal.gap0|tobytes|length) catch null),"
                   " rbsp_fields: (.nal.rbsp|length)}]}]",
                   DCR])
    assert arrays == DCR_ARRAYS

    vps_sel = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_dcr",
                   ".arrays[0].nals[0].nal.rbsp | {vps_video_parameter_set_id,"
                   " vps_max_layers_minus1, vps_max_sub_layers_minus1,"
                   " vps_sub_layer_ordering_info_present_flag, vps_sub_layer_ordering_infos,"
                   " general_profile_idc, general_level_idc, general_non_packed_constraint_flag,"
                   " sub_layer_presents, sub_layers, reserved_zero_2bits}", DCR])
    assert vps_sel == DCR_VPS_SEL

    sps_sel = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_dcr",
                   ".arrays[1].nals[0].nal.rbsp | {sps_video_parameter_set_id,"
                   " sps_max_sub_layers_minus1, sps_temporal_id_nesting_flag,"
                   " general_profile_idc, general_level_idc, chroma_format_idc,"
                   " pic_width_in_luma_samples, pic_height_in_luma_samples,"
                   " conformance_window_flag, conf_win_top_offset, conf_win_bottom_offset,"
                   " bit_depth_luma_minus8, bit_depth_chroma_minus8,"
                   " log2_max_pic_order_cnt_lsb_minus4, scaling_list_enabled_flag,"
                   " sps_scaling_list_data_present_flag, strong_intra_smoothing_enabled_flag,"
                   " sub_layer_presents}", DCR])
    assert sps_sel == DCR_SPS_SEL

    vui = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_dcr",
                  ".arrays[1].nals[0].nal.rbsp.vui_parameters", DCR])
    assert vui == DCR_VUI

    pps_sel = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_dcr",
                   ".arrays[2].nals[0].nal.rbsp | {pps_pic_parameter_set_id,"
                   " pps_seq_parameter_set_id, dependent_slice_segments_enabled_flag,"
                   " cu_qp_delta_enabled_flag, diff_cu_qp_delta_depth,"
                   " deblocking_filter_control_present_flag, pps_deblocking_filter_disabled_flag,"
                   " entropy_coding_sync_enabled_flag, num_ref_idx_l0_default_active_minus1,"
                   " weighted_pred_flag, sign_data_hiding_enabled_flag,"
                   " pps_loop_filter_across_slices_enabled_flag, pps_extension_present_flag}",
                   DCR])
    assert pps_sel == DCR_PPS_SEL


def test_hevc_au_length_prefixed_and_annexb(tmp_path):
    """hevc_au defaults to 4 byte lengths and only does annexb when asked.

    CATCHES: unlike avc_au, hevc_au's default length_size is 4 (big-endian
    length per nalu, no start codes); length_size=0 switches to annexb
    start-code scanning, and the nested nalu rbsp still decodes to the same
    VPS value as the standalone hevc_vps decoder.
    """
    len4 = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_au",
                   "[.[] | {length, nal_unit_type: .nalu.nal_unit_type,"
                   " nuh_layer_id: .nalu.nuh_layer_id,"
                   " nuh_temporal_id_plus1: .nalu.nuh_temporal_id_plus1}]",
                   AU_LEN4])
    assert len4 == AU_LEN4_LIST

    vps_rbsp = fq_json(tmp_path, ["-c", "-V", "-d", "hevc_au", ".[0].nalu.rbsp", AU_LEN4])
    assert vps_rbsp == VPS

    annexb = fq_json(tmp_path, ["-o", "length_size=0", "-c", "-V", "-d", "hevc_au",
                   "[.[] | if type==\"object\" then .nal_unit_type else \"start_code\" end]",
                   ANNEXB])
    assert annexb == AU_ANNEXB
