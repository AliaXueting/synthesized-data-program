"""Black-box tests for the Ogg container family and its Vorbis/Opus packets.

Covers the ``ogg`` container decoder, the standalone ``ogg_page`` decoder, the
``vorbis_packet``/``vorbis_comment`` decoders and the ``opus_packet`` decoder.
Every expected value below was recorded by running the reference fq binary on
the fixtures in eval/tests/data.
"""

import pytest

from conftest import fq_json, run_on

VORBIS_OGG = "ogg/vorbis.ogg"
OPUS_OGG = "ogg/opus.ogg"
FLAC_OGG = "ogg/flac.ogg"
# crafted fixture: a two page vorbis stream whose second packet is laced over
# the page boundary (page 0 ends with a 255 byte segment, page 1 continues it)
SPLIT_OGG = "ogg/vorbis-split.ogg"
PAGE = "ogg/page"
# the same page as ogg/page with one payload byte flipped => CRC mismatch
PAGE_BAD_CRC = "ogg/page-crc-invalid"

VORBIS_IDENT = "vorbis/vorbis-identifcation"
VORBIS_COMMENT = "vorbis/vorbis-comment"
VORBIS_SETUP = "vorbis/vorbis-setup"
VORBIS_AUDIO = "vorbis/vorbis-audio"
VORBIS_COMMENT_PICTURE = "vorbis/vorbis-comment-picture"

OPUS_HEAD = "opus/opus-head"
OPUS_TAGS = "opus/opus-tags"
OPUS_AUDIO = "opus/opus-audio"


def test_ogg_page_header_bitfields(tmp_path):
    """ogg_page decodes one raw page: magic, flags, granule, serial and lacing.

    CATCHES: wrong bit split of the header_type byte (5 unused flag bits before
    last/first/continued) or wrong little endian widths for granule position,
    serial number and page sequence number.
    """
    out = fq_json(tmp_path, ["-d", "ogg_page", "-c", "-V", "del(.segments)", PAGE])
    assert out == {
        "bitstream_serial_number": 3738778752,
        "capture_pattern": "OggS",
        "continued_packet": False,
        "crc": 648022926,
        "first_page": True,
        "granule_position": 0,
        "last_page": False,
        "page_segments": 1,
        "page_sequence_no": 0,
        "segment_table": [30],
        "unused_flags": 0,
        "version": 0,
    }
    # the segment table entry sizes the single payload segment, exposed verbatim
    seg = fq_json(tmp_path, ["-d", "ogg_page", "-c", "-V",
                             "{n: (.segments | length), hex: (.segments[0] | tobytes | tohex)}",
                             PAGE])
    assert seg == {
        "n": 1,
        "hex": "01766f72626973000000000144ac0000000000008038010000000000b801",
    }


def test_ogg_page_crc_check_is_surfaced_in_display(tmp_path):
    """The page CRC (poly 0x04c11db7, checksum zeroed) is validated, not just read.

    CATCHES: a re-implementation that skips the CRC recomputation; the reference
    marks the field '(valid)'/'(invalid)' in display output while the JSON value
    and the exit status stay unchanged, so only the display shows the verdict.
    """
    res = run_on(tmp_path, ["-d", "ogg_page", "d", PAGE])
    assert res.returncode == 0
    assert "crc: 0x26a00b8e (valid)" in res.stdout.decode("utf-8")

    res = run_on(tmp_path, ["-d", "ogg_page", "d", PAGE_BAD_CRC])
    assert res.returncode == 0
    assert "crc: 0x26a00b8e (invalid)" in res.stdout.decode("utf-8")
    # the stored CRC value itself is still reported unchanged in JSON
    out = fq_json(tmp_path, ["-d", "ogg_page", "-c", "-V", ".crc", PAGE_BAD_CRC])
    assert out == 648022926


@pytest.mark.parametrize(
    "fixture,serial,npackets,pages",
    [
        (
            VORBIS_OGG,
            3971626214,
            7,
            [
                {"cont": False, "first": True, "granule": 0, "last": False,
                 "nseg": 1, "segs": [30], "seq": 0},
                {"cont": False, "first": False, "granule": 0, "last": False,
                 "nseg": 14, "segs": [65, 255, 255, 255, 255, 255, 255, 255,
                                      255, 255, 255, 255, 255, 129], "seq": 1},
                {"cont": False, "first": False, "granule": 2205, "last": True,
                 "nseg": 4, "segs": [31, 60, 52, 128], "seq": 2},
            ],
        ),
        (
            OPUS_OGG,
            1949835335,
            5,
            [
                {"cont": False, "first": True, "granule": 0, "last": False,
                 "nseg": 1, "segs": [19], "seq": 0},
                {"cont": False, "first": False, "granule": 0, "last": False,
                 "nseg": 1, "segs": [63], "seq": 1},
                {"cont": False, "first": False, "granule": 2712, "last": True,
                 "nseg": 5, "segs": [255, 45, 160, 255, 60], "seq": 2},
            ],
        ),
        (
            FLAC_OGG,
            599479009,
            3,
            [
                {"cont": False, "first": True, "granule": 0, "last": False,
                 "nseg": 1, "segs": [51], "seq": 0},
                {"cont": False, "first": False, "granule": 0, "last": False,
                 "nseg": 1, "segs": [56], "seq": 1},
                {"cont": False, "first": False, "granule": 2205, "last": True,
                 "nseg": 4, "segs": [255, 255, 92, 0], "seq": 2},
            ],
        ),
    ],
)
def test_ogg_page_chain_per_codec(tmp_path, fixture, serial, npackets, pages):
    """ogg splits each file into pages and groups them into one stream by serial.

    CATCHES: page counting, the bos/eos header flags, granule positions, page
    sequence numbering and the full lacing values of every page.
    """
    out = fq_json(tmp_path, ["-d", "ogg", "-c", "-V",
                             "{n: (.pages | length), nstreams: (.streams | length),"
                             " serial: .streams[0].serial_number,"
                             " npackets: (.streams[0].packets | length)}",
                             fixture])
    assert out == {"n": 3, "nstreams": 1, "serial": serial, "npackets": npackets}

    pages_out = fq_json(tmp_path, ["-d", "ogg", "-c", "-V",
                                   "[.pages[] | {seq: .page_sequence_no,"
                                   " granule: .granule_position, first: .first_page,"
                                   " last: .last_page, cont: .continued_packet,"
                                   " nseg: .page_segments, segs: .segment_table}]",
                                   fixture])
    assert pages_out == pages


@pytest.mark.parametrize(
    "fixture,expected",
    [
        # vorbis identification header nested in the first packet
        (VORBIS_OGG, {
            "audio_channels": 1,
            "audio_sample_rate": 44100,
            "bitrate_maximum": 0,
            "bitrate_minimum": 0,
            "bitrate_nominal": 80000,
            "blocksize_0": 256,
            "blocksize_1": 2048,
            "framing_flag": 1,
            "magic": "vorbis",
            "packet_type": "identification",
            "padding0": "\u0000",
            "vorbis_version": 0,
        }),
        # opus head nested in the first packet
        (OPUS_OGG, {
            "channel_count": 1,
            "map_family": 0,
            "output_gain": 0,
            "pre_skip": 312,
            "prefix": "OpusHead",
            "sample_rate": 48000,
            "type": "head",
            "version": 1,
        }),
        # flac-in-ogg identification header with the streaminfo metadatablock
        (FLAC_OGG, {
            "flac_signature": "fLaC",
            "header_packets": 1,
            "major": 1,
            "metadatablock": {
                "bits_per_sample": 16,
                "channels": 1,
                "last_block": False,
                "length": 34,
                "maximum_block_size": 4608,
                "maximum_frame_size": 9237,
                "md5": "00000000000000000000000000000000",
                "minimum_block_size": 4608,
                "minimum_frame_size": 0,
                "sample_rate": 44100,
                "total_samples_in_stream": 0,
                "type": "streaminfo",
            },
            "minor": 0,
            "signature": "FLAC",
            "type": 127,
        }),
    ],
)
def test_ogg_first_page_carries_codec_identification(tmp_path, fixture, expected):
    """The codec of each stream is sniffed from the first packet and decoded.

    CATCHES: the prefix based codec detection (\\x01vorbis / OpusHead /
    \\x7fFLAC) and the nested decode of the identification header inside the
    stream's packet array.
    """
    out = fq_json(tmp_path, ["-d", "ogg", "-c", "-V", ".streams[0].packets[0]", fixture])
    assert out == expected


def test_ogg_packet_lacing_across_page_boundary(tmp_path):
    """A page ending in a 255 byte segment laces its packet into the next page.

    CATCHES: the reassembly rule 'segment size < 255 terminates a packet'; the
    continued_packet flag on the second page must be decoded and the 275 byte
    comment packet (255 + 20 bytes) must be handed to vorbis_packet as one.
    """
    out = fq_json(tmp_path, ["-d", "ogg", "-c", "-V",
                             "[.pages[] | {cont: .continued_packet, last: .last_page,"
                             " seq: .page_sequence_no,"
                             " seg_sizes: [.segments[] | (tobytes | length)]}]",
                             SPLIT_OGG])
    assert out == [
        {"cont": False, "last": False, "seq": 0, "seg_sizes": [30, 255]},
        {"cont": True, "last": True, "seq": 1, "seg_sizes": [20]},
    ]

    types = fq_json(tmp_path, ["-d", "ogg", "-c", "-V",
                               "[.streams[0].packets[] | .packet_type]", SPLIT_OGG])
    assert types == ["identification", "comment"]
    serial = fq_json(tmp_path, ["-d", "ogg", "-c", "-V",
                                ".streams[0].serial_number", SPLIT_OGG])
    assert serial == 287454020

    # the reassembled comment packet decodes fully, including the trailing data
    comment = fq_json(tmp_path, ["-d", "ogg", "-c", "-V", ".streams[0].packets[1]", SPLIT_OGG])
    assert comment["comment"] == {
        "user_comment_list_length": 1,
        "user_comments": [{"comment": "abcde", "length": 5}],
        "vendor": "Lavf58.76.100",
        "vendor_length": 13,
    }
    assert comment["frame_bit"] == 1
    assert comment["magic"] == "vorbis"
    assert comment["packet_type"] == "comment"
    n = fq_json(tmp_path, ["-d", "ogg", "-c", "-V",
                           ".streams[0].packets[1].data | tobytes | length", SPLIT_OGG])
    assert n == 237


def test_ogg_no_pages_found_error(tmp_path):
    """A file without any decodable page yields an inline error plus empty arrays.

    CATCHES: the 'no pages found' fatal path must not abort the process (exit 0)
    and must still emit the empty pages/streams arrays and a gap for the bytes.
    """
    (tmp_path / "garbage.bin").write_bytes(b"notanoggfile_notanoggfile_notanoggfile\n")
    out = fq_json(tmp_path, ["-d", "ogg", "-c", "-V", ".", "garbage.bin"])
    assert out == {
        "gap0": "notanoggfile_notanoggfile_notanoggfile\n",
        "pages": [],
        "streams": [],
    }
    res = run_on(tmp_path, ["-d", "ogg", "d", "garbage.bin"])
    assert res.returncode == 0
    assert "error: ogg: error at position 0x0: no pages found" in res.stdout.decode("utf-8")


@pytest.mark.parametrize(
    "fixture,expected",
    [
        (VORBIS_IDENT, {
            "audio_channels": 1,
            "audio_sample_rate": 44100,
            "bitrate_maximum": 0,
            "bitrate_minimum": 0,
            "bitrate_nominal": 80000,
            "blocksize_0": 256,
            "blocksize_1": 2048,
            "framing_flag": 1,
            "magic": "vorbis",
            "packet_type": "identification",
            "padding0": "\u0000",
            "vorbis_version": 0,
        }),
        (VORBIS_COMMENT, {
            "comment": {
                "user_comment_list_length": 1,
                "user_comments": [
                    {"comment": "encoder=Lavc58.54.100 libvorbis", "length": 31}
                ],
                "vendor": "Lavf58.29.100",
                "vendor_length": 13,
            },
            "frame_bit": 1,
            "magic": "vorbis",
            "packet_type": "comment",
            "padding0": "\u0000",
        }),
        (VORBIS_SETUP, {
            "codebook_dimensions": 1,
            "codebook_entries": 64,
            "codecooke_sync": 5653314,
            "magic": "vorbis",
            "packet_type": "setup",
            "vorbis_codebook_count": 35,
        }),
    ],
)
def test_vorbis_packet_header_types(tmp_path, fixture, expected):
    """vorbis_packet labels identification/comment/setup packets and their fields.

    CATCHES: the odd packet_type byte mapping to symbols, the 'vorbis' magic
    assertion, blocksize exponents (2**n) and the 0x564342 codebook sync value.
    """
    out = fq_json(tmp_path, ["-d", "vorbis_packet", "-c", "-V", "del(.data)", fixture])
    assert out == expected


def test_vorbis_audio_packet_is_bit0_zero(tmp_path):
    """An audio packet is recognised purely from a zero low bit of the type byte.

    CATCHES: audio packets carry no magic and no structured fields, so the whole
    payload after the type byte must land in the trailing 'data' raw field.
    """
    out = fq_json(tmp_path, ["-d", "vorbis_packet", "-c", "-V",
                             "{packet_type, keys: keys,"
                             " data_bytes: (.data | tobytes | length)}", VORBIS_AUDIO])
    assert out == {
        "packet_type": "audio",
        "keys": ["packet_type", "data"],
        "data_bytes": 32,
    }


def test_vorbis_comment_metadata_block_picture(tmp_path):
    """vorbis_comment base64-decodes a METADATA_BLOCK_PICTURE user comment.

    CATCHES: the '=' key detection, the base64 decoding of the remainder of the
    comment string and the nested flac_picture/png decode of the cover art.
    """
    out = fq_json(tmp_path, ["-d", "vorbis_comment", "-c", "-V",
                             "{vendor, vendor_length, user_comment_list_length,"
                             " comments: [.user_comments[] | {length, comment}],"
                             " picture: (.user_comments[1].picture | del(.picture_data))}",
                             VORBIS_COMMENT_PICTURE])
    assert out == {
        "vendor": "Lavf58.76.100",
        "vendor_length": 13,
        "user_comment_list_length": 2,
        "comments": [
            {"comment": "encoder=Lavc58.134.100 libvorbis", "length": 32},
            {"comment": "METADATA_BLOCK_PICTURE=AAAAAAAAAAlpbWFnZS9wbmcAAAAAAA"
                        "AABAAAAAQAAAAYAAAAAAAAAHCJUE5HDQoaCgAAAA1JSERSAAAABAAA"
                        "AAQIAgAAACaTCSkAAAAJcEhZcwAAAAEAAAABAE8lxNYAAAAiSURBVHic"
                        "Y2BgYPgPxv9BFIgFZPyHCCJxgEQ9iPG/geE/AMh2E+0vdooqAAAAAElF"
                        "TkSuQmCC", "length": 227},
        ],
        "picture": {
            "color_depth": 24,
            "description": "",
            "description_length": 0,
            "height": 4,
            "mime": "image/png",
            "mime_length": 9,
            "number_of_index_colors": 0,
            "picture_length": 112,
            "picture_type": "Other",
            "width": 4,
        },
    }
    png = fq_json(tmp_path, ["-d", "vorbis_comment", "-c", "-V",
                             ".user_comments[1].picture.picture_data"
                             " | {chunks: [.chunks[] | {type, length}]}",
                             VORBIS_COMMENT_PICTURE])
    assert png == {"chunks": [{"type": "IHDR", "length": 13},
                              {"type": "pHYs", "length": 9},
                              {"type": "IDAT", "length": 34},
                              {"type": "IEND", "length": 0}]}


def test_opus_packet_head_tags_and_audio(tmp_path):
    """opus_packet dispatches on the 8 byte prefix: OpusHead, OpusTags or audio.

    CATCHES: the head fields (pre_skip, output_gain, mapping family), the vorbis
    style comment list inside OpusTags, and the TOC byte split into config (5
    bits), stereo flag (1 bit) and frames-per_packet code (2 bits).
    """
    head = fq_json(tmp_path, ["-d", "opus_packet", "-c", "-V", ".", OPUS_HEAD])
    assert head == {
        "channel_count": 2,
        "map_family": 0,
        "output_gain": 0,
        "pre_skip": 312,
        "prefix": "OpusHead",
        "sample_rate": 48000,
        "type": "head",
        "version": 1,
    }

    tags = fq_json(tmp_path, ["-d", "opus_packet", "-c", "-V", ".", OPUS_TAGS])
    assert tags == {
        "comment": {
            "user_comment_list_length": 2,
            "user_comments": [
                {"comment": "encoder=Lavc58.91.100 libopus", "length": 29},
                {"comment": "artist=bla", "length": 10},
            ],
            "vendor": "Lavf58.45.100",
            "vendor_length": 13,
        },
        "prefix": "OpusTags",
        "type": "tags",
    }

    audio = fq_json(tmp_path, ["-d", "opus_packet", "-c", "-V",
                               "{type, toc: (.toc | del(.data)),"
                               " data_bytes: (.toc.data | tobytes | length)}", OPUS_AUDIO])
    assert audio == {
        "type": "audio",
        "toc": {
            "config": {
                "bandwidth": "fb",
                "config": 31,
                "frame_size": 20,
                "mode": "celt_only",
            },
            "frames_per_packet": {"config": 0, "frames": 1, "mode": "1 frame"},
            "stereo": True,
        },
        "data_bytes": 437,
    }


def test_opus_packets_inside_ogg_stream(tmp_path):
    """The opus.ogg stream yields head, tags and three audio packets with TOCs.

    CATCHES: the packet level codec decode driven by the ogg container, and the
    audio packet byte lengths that follow from the page lacing values.
    """
    out = fq_json(
        tmp_path,
        [
            "-d", "ogg", "-c", "-V",
            "[.streams[0].packets[]"
            " | {type,"
            '   toc: (if has("toc") then (.toc | del(.data)) else null end),'
            '   data_bytes: (if has("toc") then (.toc.data | tobytes | length)'
            "               else null end)}]",
            OPUS_OGG,
        ],
    )
    assert out == [
        {"type": "head", "toc": None, "data_bytes": None},
        {"type": "tags", "toc": None, "data_bytes": None},
        {"type": "audio",
         "toc": {"config": {"bandwidth": "fb", "config": 31, "frame_size": 20,
                            "mode": "celt_only"},
                 "frames_per_packet": {"config": 0, "frames": 1, "mode": "1 frame"},
                 "stereo": False},
         "data_bytes": 299},
        {"type": "audio",
         "toc": {"config": {"bandwidth": "fb", "config": 31, "frame_size": 20,
                            "mode": "celt_only"},
                 "frames_per_packet": {"config": 0, "frames": 1, "mode": "1 frame"},
                 "stereo": False},
         "data_bytes": 159},
        {"type": "audio",
         "toc": {"config": {"bandwidth": "fb", "config": 31, "frame_size": 20,
                            "mode": "celt_only"},
                 "frames_per_packet": {"config": 0, "frames": 1, "mode": "1 frame"},
                 "stereo": False},
         "data_bytes": 314},
    ]
