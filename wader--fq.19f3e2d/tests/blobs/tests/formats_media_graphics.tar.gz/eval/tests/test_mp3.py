"""Black-box tests for the mp3 decoders (mp3, mp3_frame, mp3_frame_xing, mp3_frame_vbri).

Every expected value below was recorded by running the reference fq binary on
the fixtures in eval/tests/data.
"""

from conftest import fq_json, run_ok, run_on

MP3 = "mp3/headerfooter.mp3"
ZEROS = "mp3/header-zeros-frames.mp3"
UNKNOWN = "mp3/unknown.mp3"
CRC_FRAME = "mpeg/mp3-frame-mono-crc"


def test_mp3_file_layout(tmp_path):
    """mp3 decodes an ID3v2 header, the frame chain and an ID3v1 footer.

    CATCHES: a re-implementation that mis-labels the three top-level mp3
    arrays (headers/frames/footers) or drops the trailing id3v1 tag.
    """
    copy = run_ok(tmp_path, ["-c", "-V", "-d", "mp3",
                      "{h: (.headers|length), f: (.frames|length), ft: (.footers|length)}",
                      MP3])
    assert copy == '{"f":2,"ft":1,"h":1}'


def test_mp3_frame_header_bitfields(tmp_path):
    """The mp3 frame header bitfields decode symbolically and un-aligned.

    CATCHES: wrong bit widths or wrong symbol tables for layer/mpeg version,
    channel mode, padding and emphasis (fields span non-byte-aligned bits).
    """
    header = fq_json(tmp_path, ["-c", "-V", "-d", "mp3", ".frames[1].header", MP3])
    assert header == {
        "bitrate": 64000,
        "channel_mode": "none",
        "channels": "mono",
        "copyright": 0,
        "emphasis": "none",
        "layer": 3,
        "mpeg_version": "1",
        "original": 1,
        "padding": "padded",
        "private": 0,
        "protection_absent": True,
        "sample_count": 1152,
        "sample_rate": 44100,
        "sync": 2047,
    }


def test_mp3_side_info_granules(tmp_path):
    """mp3 side_info carries per-granule/per-channel huffman side data.

    CATCHES: wrong side_info size for mono MPEG1 (17 bytes) or wrong granule
   /channel nesting order in the side information.
    """
    side_info = fq_json(tmp_path, ["-c", "-V", "-d", "mp3", ".frames[0].side_info", MP3])
    assert side_info["main_data_begin"] == 0
    assert side_info["scfsi0"] == 0
    assert len(side_info["granules"]) == 2
    granule0 = side_info["granules"][0][0]
    assert granule0 == {
        "big_values": 25,
        "blocksplit_flag": 0,
        "count1table_select": 0,
        "global_gain": 163,
        "part2_3_length": 623,
        "preflag": 0,
        "region_address1": 0,
        "region_address2": 4,
        "scalefac_compress": 2,
        "scalefac_scale": 0,
        "table_select0": 15,
        "table_select1": 15,
        "table_select2": 6,
    }


def test_mp3_calculated_frame_crc(tmp_path):
    """mp3_frame stores a CRC-16 computed over header+side_info.

    CATCHES: a re-implementation that drops the crc_calculated field or uses
    a different CRC polynomial/bit order than the reference.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mp3",
                   "[.frames[] .crc_calculated]", MP3])
    assert out == ["3c54", "ea58"]


def test_mp3_frame_with_crc_protected_header(tmp_path):
    """A frame with protection_absent=false has a 16 bit crc in the header.

    CATCHES: protection_absent semantics inverted, so the crc field would be
    missing (or present when it should not be) in the frame header.
    """
    header = fq_json(tmp_path, ["-c", "-V", "-d", "mp3_frame", ".header", CRC_FRAME])
    assert header["protection_absent"] is False
    assert header["crc"] == 11449
    assert header["bitrate"] == 64000
    assert header["channels"] == "mono"


def test_mp3_id3v2_header_and_id3v1_footer(tmp_path):
    """The mp3 header array nests id3v2 frames; the footer nests id3v1.

    CATCHES: id3v2 frame ids/text encoding or the id3v1 fixed-width string
    fields (song_name/genre) decoded with the wrong widths.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mp3",
                   "{tags: [.headers[0].frames[] | {id, size, text}], footer: .footers[0]}",
                   MP3])
    assert out["tags"] == [
        {"id": "TIT2", "size": 6, "text": "test"},
        {"id": "TSSE", "size": 15, "text": "Lavf58.76.100"},
    ]
    assert out["footer"] == {
        "album_name": "",
        "artist": "",
        "comment": "",
        "genre": 255,
        "magic": "TAG",
        "song_name": "test",
        "year": "",
    }


def test_mp3_gap_before_first_frame(tmp_path):
    """Zero padding between the id3v2 header and the first frame is a gap.

    CATCHES: the frame sync seek logic must skip unknown padding and still
    decode the frame after it instead of failing the whole file.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mp3",
                   "{h: (.headers|length), f: (.frames|length), gaps: [keys | .[] | select(startswith(\"gap\"))], "
                   "bitrate: .frames[0].header.bitrate}",
                   ZEROS])
    assert out == {"h": 1, "f": 1, "gaps": ["gap0"], "bitrate": 64000}


def test_mp3_max_unknown_option(tmp_path):
    """max_unknown controls the tolerated percentage of unknown bits.

    CATCHES: the threshold is compared as percent (73 > 50) and raising it to
    73 must make the same file decode its two frames successfully.
    """
    res = run_on(tmp_path, ["-d", "mp3", "d", UNKNOWN])
    assert res.returncode == 0
    assert "error: mp3: error at position 0x365: exceeds max precent unknown bits, 73 > 50" in \
        res.stdout.decode("utf-8")

    out = fq_json(tmp_path, ["-o", "max_unknown=73", "-c", "-V", "-d", "mp3",
                   "{h: (.headers|length), f: (.frames|length), ft: (.footers|length)}",
                   UNKNOWN])
    assert out == {"h": 0, "f": 2, "ft": 0}


def test_mp3_max_sync_seek_option(tmp_path):
    """max_sync_seek bounds the byte distance scanned for the next sync.

    CATCHES: with a tiny seek window the distant frame sync is never found
    and the decoder must fail with 'no frames found' instead of looping.
    """
    res = run_on(tmp_path, ["-o", "max_sync_seek=8", "-d", "mp3", "d", UNKNOWN])
    assert res.returncode == 0
    assert "error: mp3: error at position 0x0: no frames found" in res.stdout.decode("utf-8")


def test_mp3_max_unique_header_configs_option(tmp_path):
    """max_unique_header_configs aborts when frame headers vary too much.

    CATCHES: the unique-config counter must include mpeg version, sample
    rate, channels and channel mode (but not bitrate) before erroring.
    """
    res = run_on(tmp_path, ["-o", "max_unique_header_configs=1", "-d", "mp3", "d", MP3])
    assert res.returncode == 0
    assert "error: mp3: error at position 0x10d: too many unique header configurations" in \
        res.stdout.decode("utf-8")


def test_mp3_frame_xing_tag(tmp_path):
    """mp3_frame_xing decodes a Xing VBR tag including the LAME extension.

    CATCHES: present_flags bit order (frames/bytes/toc/quality/lame), the
    auto-detected LAME header extension and the 100 entry toc.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mp3_frame_xing",
                   "del(.toc) + {toc_len: (.toc|length), toc_head: .toc[0:6]}",
                   "mp3/mp3_frame_xing"])
    assert out == {
        "abr_vbr": 0,
        "audiophile_replay_gain": 0,
        "bytes": 1304,
        "encoder": "Lavc59.37",
        "encoder_delay": 576,
        "encoder_padding": 1287,
        "frames": 2,
        "header": "Xing",
        "lame_ath_type": 0,
        "lame_flags": 0,
        "length": 1304,
        "lowpass_filter": 0,
        "misc": 0,
        "mp3_gain": 0,
        "music_crc": 17198,
        "preset": 0,
        "present_flags": {
            "bytes": True,
            "frames": True,
            "lame": False,
            "quality": True,
            "toc": True,
            "unused": 0,
        },
        "quality": 0,
        "radio_replay_gain": 0,
        "replay_gain_peak": 0,
        "tag_crc": 12140,
        "tag_revision": 0,
        "toc_head": [0, 204, 204, 204, 204, 204],
        "toc_len": 100,
        "vbr_method": 0,
    }


def test_mp3_frame_info_tag(tmp_path):
    """mp3_frame_xing also accepts the CBR 'Info' tag variant.

    CATCHES: only 'Xing' accepted, or the Info tag decoded with different
    frame/byte counts than the reference.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mp3_frame_xing",
                   "{header, frames, bytes, encoder, length, tag_crc}",
                   "mp3/mp3_frame_info"])
    assert out == {
        "header": "Info",
        "frames": 2,
        "bytes": 1043,
        "encoder": "Lavc58.91",
        "length": 1043,
        "tag_crc": 37391,
    }


def test_mp3_frame_vbri_tag(tmp_path):
    """mp3_frame_vbri decodes the Fraunhofer VBRI header and its toc.

    CATCHES: toc_entry_size drives the per-entry bit width (16 bit here) and
    toc_entries drives the array length; both must be honoured.
    """
    out = fq_json(tmp_path, ["-c", "-V", "-d", "mp3_frame_vbri",
                   "del(.toc) + {toc_len: (.toc|length), toc_head: .toc[0:3]}",
                   "mp3/mp3_frame_vbri"])
    assert out == {
        "delay": 2353,
        "frame_per_entry": 512,
        "frames": 67465,
        "header": "VBRI",
        "length": 45757560,
        "quality": 100,
        "scale_factor": 16,
        "toc_entries": 131,
        "toc_entry_size": 2,
        "toc_head": [11886, 22062, 21948],
        "toc_len": 131,
        "version_id": 1,
    }
