"""Black-box tests for the MPEG audio decoders (aac_frame, adts, mpeg_asc).

Covers the raw AAC data block decoder and its ``object_type`` option, the ADTS
framing decoders (``adts`` and ``adts_frame``) and the MPEG-4 Audio Specific
Config decoder.  Every expected value below was recorded by running the
reference fq binary on the fixtures in eval/tests/data.
"""

from conftest import data_path, fq_json, run_on

AAC_FRAME = "mpeg/aac_frame"
# crafted fixture: one SCE element with predictor_data_present set, so that the
# ics_info layout differs between the aac_main and aac_lc object types
AAC_SCE = "mpeg/aac_sce_predictor"
ADTS = "mpeg/adts"
ASC = "mpeg/mpeg_asc-he-aac-hierarchical-signalling"


def test_aac_frame_fil_element_and_cpe(tmp_path):
    """aac_frame decodes the FIL element with its escape count and fill payload.

    CATCHES: the count==15 escape (esc_count-1 extra bytes), payload_length as
    the synthesised total, the EXT_FILL extension type and the exact unaligned
    bit offset of the fill bytes that carry the encoder version string.
    """
    out = fq_json(tmp_path, ["-d", "aac_frame", "-c", "-V",
                             "[.[] | if type == \"object\""
                             " then del(.extension_payload.fill_byte)"
                             " else {bits: (tobits | length)} end]",
                             AAC_FRAME])
    assert out == [
        {
            "cnt": {"count": 15, "esc_count": 2},
            "extension_payload": {"extension_type": "EXT_FILL", "fill_nibble": 0},
            "payload_length": 16,
            "syntax_element": "FIL",
        },
        {"common_window": True, "element_instance_tag": 0, "syntax_element": "CPE"},
        {"bits": 1},
        {"bits": 2512},
    ]

    # the 15 fill bytes are the encoder version string, bit shifted by the 23
    # header bits that precede them inside the raw data block
    fill = fq_json(tmp_path, ["-d", "aac_frame", "-c", "-V",
                              ".[0].extension_payload.fill_byte | tobytes | tohex",
                              AAC_FRAME])
    assert fill == "2630bb319a9c1718999a1718981800"


def test_aac_frame_object_type_option(tmp_path):
    """object_type selects the ics_info predictor layout and gates the decoder.

    CATCHES: aac_main reads predictor_reset + predictor_reset_group_number +
    max_sfb prediction bits, every other supported type reads ltp_data_present
    instead, and unsupported types skip element decoding entirely.
    """
    main = fq_json(tmp_path, ["-d", "aac_frame", "-o", "object_type=1",
                              "-c", "-V", ".[0]", AAC_SCE])
    assert main == {
        "element_instance_tag": 0,
        "global_gain": 0,
        "ics_info": {
            "ics_reserved_bit": 0,
            "max_sfb": 2,
            "prediction_used": "\u0000",
            "predictor_data_present": True,
            "predictor_reset": False,
            "predictor_reset_group_number": 28,
            "window_sequence": "ONLY_LONG_SEQUENCE",
            "window_shape": 0,
        },
        "syntax_element": "SCE",
    }

    lc = fq_json(tmp_path, ["-d", "aac_frame", "-o", "object_type=2",
                            "-c", "-V", ".[0]", AAC_SCE])
    assert lc == {
        "element_instance_tag": 0,
        "global_gain": 0,
        "ics_info": {
            "ics_reserved_bit": 0,
            "ltp_data_present": False,
            "max_sfb": 2,
            "predictor_data_present": True,
            "window_sequence": "ONLY_LONG_SEQUENCE",
            "window_shape": 0,
        },
        "syntax_element": "SCE",
    }

    # the different ics_info widths shift the byte_align/data split
    bits = fq_json(tmp_path, ["-d", "aac_frame", "-o", "object_type=1",
                              "-c", "-V", "[.[] | if type == \"object\" then null"
                              " else (tobits | length) end]", AAC_SCE])
    assert bits == [None, 6, 24]
    bits = fq_json(tmp_path, ["-d", "aac_frame", "-o", "object_type=2",
                              "-c", "-V", "[.[] | if type == \"object\" then null"
                              " else (tobits | length) end]", AAC_SCE])
    assert bits == [None, 5, 32]

    # object types outside the supported set produce a single raw value
    for bad in ("0", "7", "99"):
        raw = fq_json(tmp_path, ["-d", "aac_frame", "-o", "object_type=" + bad,
                                 "-c", "-V", "[.[] | (tobits | length)]", AAC_SCE])
        assert raw == [64]


def test_adts_frame_chain(tmp_path):
    """adts decodes the whole frame chain, one nested raw_data_block each.

    CATCHES: the 12 bit syncword, mpeg_version/profile/sampling_frequency
    symbols, frame_length including the 7 byte header and number_of_rdbs as
    the raw count plus one.
    """
    out = fq_json(tmp_path, ["-d", "adts", "-c", "-V",
                             "[.[] | {syncword, mpeg_version, layer,"
                             " protection_absent, profile, sampling_frequency,"
                             " channel_configuration, frame_length,"
                             " buffer_fullness, number_of_rdbs,"
                             " nrdbs: (.raw_data_blocks | length)}]",
                             ADTS])
    assert out == [
        {"syncword": 4095, "mpeg_version": "mpeg4", "layer": 0,
         "protection_absent": True, "profile": "aac_lc",
         "sampling_frequency": 44100, "channel_configuration": 2,
         "frame_length": 340, "buffer_fullness": 2047, "number_of_rdbs": 1,
         "nrdbs": 1},
        {"syncword": 4095, "mpeg_version": "mpeg4", "layer": 0,
         "protection_absent": True, "profile": "aac_lc",
         "sampling_frequency": 44100, "channel_configuration": 2,
         "frame_length": 363, "buffer_fullness": 2047, "number_of_rdbs": 1,
         "nrdbs": 1},
        {"syncword": 4095, "mpeg_version": "mpeg4", "layer": 0,
         "protection_absent": True, "profile": "aac_lc",
         "sampling_frequency": 44100, "channel_configuration": 2,
         "frame_length": 328, "buffer_fullness": 2047, "number_of_rdbs": 1,
         "nrdbs": 1},
    ]

    # the remaining header flags are all zero in this ffmpeg produced file
    flags = fq_json(tmp_path, ["-d", "adts", "-c", "-V",
                               "[.[] | {private_bit, originality, home,"
                               " copyrighted, copyright}]", ADTS])
    assert flags == [{"private_bit": 0, "originality": 0, "home": 0,
                      "copyrighted": 0, "copyright": 0}] * 3

    # the frame lengths add up to the file size
    sizes = fq_json(tmp_path, ["-d", "adts", "-c", "-V",
                               "[.[] | .frame_length] | add", ADTS])
    assert sizes == 1031


def test_adts_frame_standalone_with_nested_aac(tmp_path):
    """adts_frame decodes one frame extracted from the stream and nests aac_frame.

    CATCHES: the profile from the ADTS header is forwarded to the nested
    aac_frame as its object type, and the raw_data_block length is
    frame_length - 7 (no CRC) bytes.
    """
    res = run_on(tmp_path, ["-r", "-d", "adts", ".[0] | tobytes", ADTS])
    assert res.returncode == 0
    assert len(res.stdout) == 340
    (tmp_path / "adts_frame0").write_bytes(res.stdout)

    out = fq_json(tmp_path, ["-d", "adts_frame", "-c", "-V",
                             "{syncword, mpeg_version, profile,"
                             " sampling_frequency, channel_configuration,"
                             " protection_absent, frame_length, buffer_fullness,"
                             " number_of_rdbs, nrdbs: (.raw_data_blocks | length)}",
                             "adts_frame0"])
    assert out == {"syncword": 4095, "mpeg_version": "mpeg4", "profile": "aac_lc",
                   "sampling_frequency": 44100, "channel_configuration": 2,
                   "protection_absent": True, "frame_length": 340,
                   "buffer_fullness": 2047, "number_of_rdbs": 1, "nrdbs": 1}

    # the nested raw_data_block is the same aac element chain as the standalone
    # aac_frame fixture
    rdb = fq_json(tmp_path, ["-d", "adts_frame", "-c", "-V",
                             "[.raw_data_blocks[0][] | if type == \"object\""
                             " then .syntax_element else (tobits | length) end]",
                             "adts_frame0"])
    assert rdb == ["FIL", "CPE", 1, 2512]


def test_adts_truncated_and_invalid_input(tmp_path):
    """A truncated final frame and a non-ADTS file both degrade, not crash.

    CATCHES: a frame cut short keeps its header but loses the raw_data_block
    array, and input with no syncword at all reports 'no valid frames' while
    still exiting 0.
    """
    (tmp_path / "truncated.adts").write_bytes(data_path(ADTS).read_bytes()[:700])

    out = fq_json(tmp_path, ["-d", "adts", "-c", "-V",
                             "[.[] | {frame_length, nrdbs: (.raw_data_blocks | length)}]",
                             "truncated.adts"])
    assert out == [{"frame_length": 340, "nrdbs": 1}, {"frame_length": None, "nrdbs": 0}]

    (tmp_path / "garbage.adts").write_bytes(b"garbagegarbagegarbage")
    out = fq_json(tmp_path, ["-d", "adts", "-c", "-V", ".", "garbage.adts"])
    assert out == ["garbagegarbagegarbage"]
    res = run_on(tmp_path, ["-d", "adts", "d", "garbage.adts"])
    assert res.returncode == 0
    assert "error: adts: error at position 0x0: no valid frames" in res.stdout.decode("utf-8")


def test_mpeg_asc_he_aac_hierarchical_signalling(tmp_path):
    """mpeg_asc decodes SBR/PS hierarchical signalling into the inner object type.

    CATCHES: object_type==5 (sbr) makes the decoder read
    extension_sampling_frequency and inner_object_type before the trailing
    alignment bits, and the channel_configuration symbol table is applied.
    """
    out = fq_json(tmp_path, ["-d", "mpeg_asc", "-c", "-V",
                             "{object_type, sampling_frequency,"
                             " channel_configuration, extension_sampling_frequency,"
                             " inner_object_type,"
                             " trailing_bits: (.var_aot_or_byte_align | tobits | length)}",
                             ASC])
    assert out == {
        "object_type": "sbr",
        "sampling_frequency": 22050,
        "channel_configuration": 2,
        "extension_sampling_frequency": 44100,
        "inner_object_type": "aac_lc",
        "trailing_bits": 10,
    }
