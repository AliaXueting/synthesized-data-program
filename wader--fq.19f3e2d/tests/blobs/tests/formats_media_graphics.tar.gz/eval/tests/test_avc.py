"""Black-box tests for the H.264/AVC decoders.

Covers: avc_annexb, avc_au, avc_dcr, avc_nalu, avc_pps, avc_sei (via the SEI
nal unit) and avc_sps.  Every expected value below was recorded by running the
reference fq binary on the fixtures in eval/tests/data.

Fixtures crafted for this module (see the module level comments for their
origin):
* avc_sps_rbsp / avc_pps_rbsp: the SPS/PPS RBSPs of mpeg/avc_annexb with the
  NAL header byte and the emulation-prevention bytes removed, so the standalone
  avc_sps/avc_pps decoders can be exercised directly.
* avc_dcr: the avcC decoder configuration record payload extracted from
  isobmff/avc.mp4.
* avc_au_len4: the annexb SPS+PPS nal units re-wrapped with 4 byte lengths.
* avc_au_emu_gap: a length-prefixed access unit whose second nalu length
  points past the end of the buffer.
"""

import pytest

from conftest import fq_json, run_on

ANNEXB = "mpeg/avc_annexb"
SEI_RECOVERY = "mpeg/avc_nalu_sei_recovery_point"
PPS_STOP = "mpeg/avc_pps_stop_more_8bit"
SPS_RBSP = "mpeg/avc_sps_rbsp"
PPS_RBSP = "mpeg/avc_pps_rbsp"
DCR = "mpeg/avc_dcr"
AU_LEN4 = "mpeg/avc_au_len4"
AU_EMU = "mpeg/avc_au_emu_gap"

# avc_sps on avc_sps_rbsp (identical to the rbsp nested in the annexb stream
# and inside the avcC record).
SPS = {
    "bit_depth_chroma": 8,
    "bit_depth_luma": 8,
    "chroma_format_idc": "4:4:4",
    "constraint_set0_flag": False,
    "constraint_set1_flag": False,
    "constraint_set2_flag": False,
    "constraint_set3_flag": False,
    "constraint_set4_flag": False,
    "constraint_set5_flag": False,
    "direct_8x8_inference_flag": True,
    "frame_cropping_flag": False,
    "frame_mbs_only_flag": True,
    "gaps_in_frame_num_value_allowed_flag": False,
    "level_idc": "1.3",
    "log2_max_frame_num": 4,
    "log2_max_pic_order_cnt_lsb": 6,
    "max_num_ref_frames": 4,
    "pic_height_in_map_units": 15,
    "pic_order_cnt_type": 0,
    "pic_width_in_mbs": 20,
    "profile_idc": "high_444_predictive_profile",
    "qpprime_y_zero_transform_bypass_flag": False,
    "reserved_zero_2bits": 0,
    "separate_colour_plane_flag": False,
    "seq_parameter_set_id": 0,
    "seq_scaling_matrix_present_flag": False,
    "trailing_bits": "\ufffd",
    "vui_parameters": {
        "aspect_ratio_idc": "1:1",
        "aspect_ratio_info_present_flag": True,
        "bitstream_restriction_flag": True,
        "chroma_loc_info_present_flag": False,
        "fixed_frame_rate_flag": False,
        "log2_max_mv_length_horizontal": 9,
        "log2_max_mv_length_vertical": 9,
        "max_bits_per_mb_denom": 0,
        "max_bytes_per_pic_denom": 0,
        "max_dec_frame_buffering": 4,
        "max_num_reorder_frames": 2,
        "motion_vectors_over_pic_boundaries_flag": True,
        "nal_hrd_parameters_present_flag": False,
        "num_units_in_tick": 1,
        "overscan_info_present_flag": False,
        "pic_struct_present_flag": False,
        "time_scale": 50,
        "timing_info_present_flag": True,
        "vcl_hrd_parameters_present_flag": False,
        "video_signal_type_present_flag": False,
    },
    "vui_parameters_present_flag": True,
}

# avc_pps on avc_pps_rbsp (the PPS of the annexb stream, which uses the
# "more rbsp data" path: transform_8x8_mode_flag etc.).
PPS = {
    "bottom_field_pic_order_in_frame_present_flag": False,
    "chroma_qp_index_offset": 4,
    "constrained_intra_pred_flag": False,
    "deblocking_filter_control_present_flag": True,
    "entropy_coding_mode_flag": True,
    "num_ref_idx_l0_default_active": 3,
    "num_ref_idx_l1_default_active": 1,
    "num_slice_groups": 1,
    "pic_init_qp": 23,
    "pic_init_qs": 26,
    "pic_parameter_set_id": 0,
    "pic_scaling_matrix_present_flag": False,
    "redundant_pic_cnt_present_flag": False,
    "second_chroma_qp_index_offset": 4,
    "seq_parameter_set_id": 0,
    "trailing_bits": "\ufffd",
    "transform_8x8_mode_flag": True,
    "weighted_bipred_idc": 2,
    "weighted_pred_flag": True,
}

ANNEXB_CHAIN = [
    {"start_code": 4},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": 24,
        "nal_ref_idc": 3,
        "nal_unit_type": "sps",
    },
    {"start_code": 4},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": None,
        "nal_ref_idc": 3,
        "nal_unit_type": "pps",
    },
    {"start_code": 3},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": None,
        "nal_ref_idc": 0,
        "nal_unit_type": "sei",
    },
    {"start_code": 3},
    {
        "forbidden_zero_bit": False,
        "gap0_bytes": 2056,
        "nal_ref_idc": 3,
        "nal_unit_type": "idr_slice",
    },
]

DCR_TOP = {
    "configuration_version": 1,
    "data": "\ufffd\ufffd\ufffd\x00",
    "data_bytes": 4,
    "length_size": 4,
    "level_indication": "1.3",
    "num_of_picture_parameter_sets": 1,
    "num_of_sequence_parameter_sets": 1,
    "pps_len": 6,
    "pps_nal": "pps",
    "profile_compatibility": 0,
    "profile_indication": "high_444_predictive_profile",
    "reserved0": 63,
    "reserved1": 7,
    "sps_gap0_bytes": 24,
    "sps_len": 25,
    "sps_nal": "sps",
    "sps_ref_idc": 3,
}


def test_avc_annexb_start_codes_and_nalu_types(tmp_path):
    """avc_annexb interleaves start codes and nal units in a root array.

    CATCHES: 3 vs 4 byte start code detection, the nal unit type symbol table
    (sps/pps/sei/idr_slice), nal_ref_idc and the emulation-prevention gap that
    is left behind in the original nal unit when its rbsp had to be unescaped.
    """
    chain = fq_json(tmp_path, ["-c", "-V", "-d", "avc_annexb",
                   "[.[] | if type == \"string\" then {start_code: (tobytes|length)}"
                   " else {nal_unit_type, nal_ref_idc, forbidden_zero_bit,"
                   " gap0_bytes: (try (.gap0|tobytes|length) catch null)} end]",
                   ANNEXB])
    assert chain == ANNEXB_CHAIN


def test_avc_sps_standalone_and_nested(tmp_path):
    """avc_sps decodes profile/level, chroma format, exp-Golomb sizes and vui.

    CATCHES: the unescaped SPS rbsp must decode to the exact same value both
    standalone and nested inside avc_annexb (ue(v)/se(v) exp-Golomb coding,
    chroma_format_idc symbols, log2 sizes, frame cropping and the whole
    vui_parameters struct).
    """
    sps = fq_json(tmp_path, ["-c", "-V", "-d", "avc_sps", ".", SPS_RBSP])
    assert sps == SPS

    nested = fq_json(tmp_path, ["-c", "-V", "-d", "avc_annexb", ".[1].rbsp", ANNEXB])
    assert nested == SPS


@pytest.mark.parametrize("fixture,expected", [
    (PPS_RBSP, PPS),
    (PPS_STOP, {
        "bottom_field_pic_order_in_frame_present_flag": False,
        "chroma_qp_index_offset": 0,
        "constrained_intra_pred_flag": False,
        "deblocking_filter_control_present_flag": True,
        "entropy_coding_mode_flag": False,
        "num_ref_idx_l0_default_active": 1,
        "num_ref_idx_l1_default_active": 1,
        "num_slice_groups": 1,
        "pic_init_qp": 25,
        "pic_init_qs": 26,
        "pic_parameter_set_id": 0,
        "redundant_pic_cnt_present_flag": False,
        "seq_parameter_set_id": 0,
        "stop_one_bit": True,
        "trailing_bits": "\x00\x00",
        "weighted_bipred_idc": 0,
        "weighted_pred_flag": False,
    }),
])
def test_avc_pps(fixture, expected, tmp_path):
    """avc_pps decodes the picture parameter set, including the +26 qp offsets.

    CATCHES: pic_init_qp/pic_init_qs carry an implicit +26 offset, the
    num_slice_groups/num_ref_idx fields an implicit +1, and a PPS whose stop
    bit sits before a byte boundary must expose stop_one_bit plus 1.5 bytes of
    trailing_bits instead of the transform_8x8 extension fields.
    """
    pps = fq_json(tmp_path, ["-c", "-V", "-d", "avc_pps", ".", fixture])
    assert pps == expected


def test_avc_nalu_sei_recovery_point(tmp_path):
    """avc_nalu decodes the nal header and dispatches SEI payloads by type.

    CATCHES: the 1/2/5 bit split of the nal header, the sei symbol table
    (payload_type 6 -> recovery_point), the ff-summed payload_size and the
    recovery point bit fields.
    """
    nalu = fq_json(tmp_path, ["-c", "-V", "-d", "avc_nalu", ".", SEI_RECOVERY])
    assert nalu == {
        "forbidden_zero_bit": False,
        "nal_ref_idc": 0,
        "nal_unit_type": "sei",
        "rbsp": {
            "broken_link_flag": False,
            "changing_slice_group_idc": 0,
            "data": "\ufffd",
            "exact_match_flag": True,
            "payload_size": 1,
            "payload_type": "recovery_point",
            "recovery_frame_cnt": 0,
            "trailing_bits": "\ufffd",
        },
    }


def test_avc_dcr(tmp_path):
    """avc_dcr decodes an avcC record and nests the sps/pps nal units.

    CATCHES: the 6/2/3/5 bit reserved0/length_size/reserved1/nsp packing
    (length_size is stored minus one), profile/level symbol lookup and the
    length-prefixed parameter set arrays.
    """
    top = fq_json(tmp_path, ["-c", "-V", "-d", "avc_dcr",
                   "del(.sequence_parameter_sets, .picture_parameter_sets) + {"
                   "sps_len: .sequence_parameter_sets[0].length,"
                   " sps_nal: .sequence_parameter_sets[0].nal.nal_unit_type,"
                   " sps_ref_idc: .sequence_parameter_sets[0].nal.nal_ref_idc,"
                   " sps_gap0_bytes: (.sequence_parameter_sets[0].nal.gap0|tobytes|length),"
                   " pps_len: .picture_parameter_sets[0].length,"
                   " pps_nal: .picture_parameter_sets[0].nal.nal_unit_type,"
                   " data_bytes: (.data|tobytes|length)}",
                   DCR])
    assert top == DCR_TOP

    dcr = fq_json(tmp_path, ["-c", "-V", "-d", "avc_dcr", ".", DCR])
    assert dcr["sequence_parameter_sets"][0]["nal"]["rbsp"] == SPS
    assert dcr["picture_parameter_sets"][0]["nal"]["rbsp"] == PPS


def test_avc_au_length_prefixed_and_annexb(tmp_path):
    """avc_au switches between annexb and length-prefixed nalu framing.

    CATCHES: the default length_size=0 selects annexb start-code scanning
    (root array of start codes + nal units) while length_size=4 reads a 4 byte
    big-endian length per nalu and drops the start codes.
    """
    annexb = fq_json(tmp_path, ["-c", "-V", "-d", "avc_au",
                   "[.[] | if type==\"object\" then .nal_unit_type else \"start_code\" end]",
                   ANNEXB])
    assert annexb == ["start_code", "sps", "start_code", "pps",
                      "start_code", "sei", "start_code", "idr_slice"]

    len4 = fq_json(tmp_path, ["-o", "length_size=4", "-c", "-V", "-d", "avc_au",
                   "[.[] | {length, nal_unit_type: .nalu.nal_unit_type,"
                   " nal_ref_idc: .nalu.nal_ref_idc}]",
                   AU_LEN4])
    assert len4 == [
        {"length": 25, "nal_ref_idc": 3, "nal_unit_type": "sps"},
        {"length": 6, "nal_ref_idc": 3, "nal_unit_type": "pps"},
    ]

    sps_rbsp = fq_json(tmp_path, ["-o", "length_size=4", "-c", "-V", "-d", "avc_au",
                        ".[0].nalu.rbsp", AU_LEN4])
    assert sps_rbsp == SPS


def test_avc_au_nalu_length_past_end_of_buffer(tmp_path):
    """avc_au reports an error and keeps a raw gap for an oversized nalu.

    CATCHES: a nalu length that points outside the buffer must not abort the
    whole decode; the first nalu still decodes, the failing one keeps only its
    length field, and the remaining bytes become a trailing raw value.
    """
    out = fq_json(tmp_path, ["-o", "length_size=4", "-c", "-V", "-d", "avc_au",
                 "[.[] | if type==\"object\" then {length,"
                 " nal_unit_type: .nalu.nal_unit_type, nal_ref_idc: .nalu.nal_ref_idc,"
                 " data_bytes: (try (.nalu.rbsp.data|tobytes|length) catch null)}"
                 " else {kind: type, len: length} end]",
                 AU_EMU])
    assert out == [
        {"data_bytes": 1, "length": 2, "nal_ref_idc": 0, "nal_unit_type": "aud"},
        {"data_bytes": None, "length": 63, "nal_ref_idc": None, "nal_unit_type": None},
        {"kind": "string", "len": 60},
    ]

    res = run_on(tmp_path, ["-o", "length_size=4", "-d", "avc_au", "d", AU_EMU])
    assert res.returncode == 0
    assert ("error: avc_au: FieldFormatLen: TryFieldFormatLen(nalu): failed at position 10"
            " (read size 0 seek pos 0): BitBufRange: failed at position 10"
            " (read size 63 seek pos 0): outside buffer") in res.stdout.decode("utf-8")
