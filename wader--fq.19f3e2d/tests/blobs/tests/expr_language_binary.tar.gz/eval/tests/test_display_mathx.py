"""Number formatting behind hd and bits_format: addresses, sizes, bases.

CATCHES: hd addresses/sizes honour addrbase/sizebase (including the 2..36
clamp and the 0x/0o/0b prefixes) and snippet sizes use byte.bits notation
for non-byte-aligned binaries; a re-implementation using plain %d/%x would
differ in every one of these outputs.
"""
from __future__ import annotations

import pytest

from conftest import run_fq

HD_DEFAULT = (
    "   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
    "0x0|31 32|                                         |12|             "
    "|.: raw bits 0x0-0x2 (2)\n"
)


def test_hd_default_output():
    """hd hexdumps a binary with hex addresses and decimal sizes by default."""
    res = run_fq(["-n", '"12" | tobytes | hd'])
    assert res.returncode == 0
    # address column is hex with 0x prefix, the size annotation keeps decimal
    assert res.stdout.decode() == HD_DEFAULT


@pytest.mark.parametrize(
    "opts,expected",
    [
        (
            ["-o", "addrbase=10"],
            " |00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15|0123456789012345|\n"
            "0|31 32|                                         |12|             "
            "|.: raw bits 0-2 (2)\n",
        ),
        (
            ["-o", "addrbase=8"],
            "   |00 01 02 03 04 05 06 07 10 11 12 13 14 15 16 17|0123456701234567|\n"
            "0o0|31 32|                                         |12|             "
            "|.: raw bits 0o0-0o2 (2)\n",
        ),
        (
            ["-o", "sizebase=16"],
            "   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
            "0x0|31 32|                                         |12|             "
            "|.: raw bits 0x0-0x2 (0x2)\n",
        ),
    ],
)
def test_hd_addrbase_sizebase(opts, expected):
    """addrbase/sizebase options change hd address and size rendering."""
    res = run_fq(["-n"] + opts + ['"12" | tobytes | hd'])
    assert res.returncode == 0
    assert res.stdout.decode() == expected


@pytest.mark.parametrize(
    "opts,expected",
    [
        # addrbase=1 clamps up to 2 (binary) and renumbers the column headers
        (
            ["-o", "addrbase=1"],
            "    |00 01 10 11 100 101 110 111 1000 1001 1010 1011|0101010101010101|\n"
            "0b00|31 32|                                         |12|             "
            "|.: raw bits 0b0-0b10 (2)\n",
        ),
        # addrbase=99 clamps down to 36 (no prefix outside base 2/8/16)
        (
            ["-o", "addrbase=99"],
            " |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
            "0|31 32|                                         |12|             "
            "|.: raw bits 0-2 (2)\n",
        ),
    ],
)
def test_hd_base_clamping(opts, expected):
    """Out-of-range addrbase values are clamped into 2..36."""
    res = run_fq(["-n"] + opts + ['"12" | tobytes | hd'])
    assert res.returncode == 0
    assert res.stdout.decode() == expected


def test_hd_multiline_addresses_widen():
    """Addresses wider than one digit widen the address column."""
    res = run_fq(["-n", "[range(32)] | tobytes | hd"])
    assert res.returncode == 0
    # 32 bytes need two hex digits (0x00, 0x10) and the header shifts right
    assert res.stdout.decode() == (
        "    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
        "0x00|00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|................|"
        ".: raw bits 0x0-0x20 (32)\n"
        "0x10|10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f|................|\n"
    )


def test_hd_fractional_bit_range():
    """hd shows byte.bits positions for non-byte-aligned binaries."""
    res = run_fq(["-n", "0xf08 | tobits | hd"])
    assert res.returncode == 0
    # 12 bits print as range 0x0-0x1.4 and size 1.4
    assert res.stdout.decode() == (
        "   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
        "0x0|f0 80|                                         |..|             "
        "|.: raw bits 0x0-0x1.4 (1.4)\n"
    )


def test_snippet_bits_format_sizebases():
    """snippet prefixes the base64 payload with the size in sizebase units."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("abc"|tobytes | [tovalue({bits_format:"snippet"}), '
            "tovalue({bits_format:\"snippet\",sizebase:16}), "
            'tovalue({bits_format:"snippet",sizebase:8})]), '
            '(0xf|tobits|tovalue({bits_format:"snippet"}))]',
        ]
    )
    assert res.returncode == 0
    # default sizebase is 10; a 4-bit binary reports "0.4" bytes
    assert res.stdout.decode() == '[["<3>YWJj","<0x3>YWJj","<0o3>YWJj"],"<0.4>8A=="]\n'


def test_bytes_and_bits_pseudo_formats():
    """-d bytes / -d bits decode raw input as a byte or bit binary."""
    res = run_fq(["-c", "-d", "bytes", "length"], stdin=b"hello")
    assert res.returncode == 0
    assert res.stdout.decode() == "5\n"
    res = run_fq(["-c", "-d", "bits", "length"], stdin=b"hello")
    assert res.returncode == 0
    # the bits pseudo format measures length in bits
    assert res.stdout.decode() == "40\n"


def test_bits_pseudo_format_slicing():
    """bits/bytes decoded input supports bit and byte slicing."""
    res = run_fq(["-c", "-d", "bits", ".[0:4] | tonumber"], stdin=b"hello")
    assert res.returncode == 0
    # first 4 bits of 'h' (0x68) are 0110 = 6
    assert res.stdout.decode() == "6\n"
    res = run_fq(["-c", "-d", "bytes", '.[1:3] | tovalue({bits_format: "hex"})'], stdin=b"hello")
    assert res.returncode == 0
    assert res.stdout.decode() == '"656c"\n'
