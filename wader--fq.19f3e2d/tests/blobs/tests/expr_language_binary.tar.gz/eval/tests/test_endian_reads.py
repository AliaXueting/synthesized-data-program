"""Little-endian integer reads behind pkg/bitio ReverseBytes64.

fq reverses the byte order of the lowest nBits of every multi-byte
little-endian integer a decoder reads (pkg/bitio.ReverseBytes64). The decoders
are used only as vehicles: what these tests pin is that 16-, 24-, 32-, 56- and
64-bit little-endian fields come out with their bytes reversed — TZX covers
8/16/24-bit reads, BSON 32/64-bit reads and a postgres control file a 56-bit
read.

CATCHES: a re-implementation that reverses the wrong number of bytes (or the
whole machine word instead of the lowest nBits) produces wrong field values
for every little-endian decoder.
"""
from __future__ import annotations

import struct

import pytest

from conftest import run_fq


def tzx_bytes() -> bytes:
    """A TZX file: header plus one turbo-speed block (0x11).

    The block reads seven u16le fields, one u8, one u16le and one u24le
    length, so its field values directly show the byte reversal.
    """
    tzx = b"ZXTape!\x1a" + bytes([1, 0x13]) + bytes([0x11])
    tzx += struct.pack("<H", 0xABCD)  # pilot_pulse
    tzx += struct.pack("<H", 0x1111)  # sync_pulse_1
    tzx += struct.pack("<H", 0x2222)  # sync_pulse_2
    tzx += struct.pack("<H", 0x3333)  # bit0_pulse
    tzx += struct.pack("<H", 0x4444)  # bit1_pulse
    tzx += struct.pack("<H", 0x5555)  # pilot_tone
    tzx += bytes([0x5A])  # used_bits (u8, no swap needed)
    tzz_pause = struct.pack("<H", 0x0777)
    tzx += tzz_pause  # pause
    tzx += bytes([3, 0, 0])  # length as u24le: 0x000003
    tzx += b"ABC"  # data
    return tzx


def bson_bytes() -> bytes:
    """A BSON document with one int64 and one int32 element, both 0x12345678."""
    body = (
        b"\x12a\x00" + struct.pack("<q", 0x12345678)  # int64 element "a"
        + b"\x10b\x00" + struct.pack("<i", 0x12345678)  # int32 element "b"
        + b"\x00"
    )
    return struct.pack("<i", 4 + len(body)) + body


def pg_control_bytes() -> bytes:
    """A postgres-13 control file image with a non-zero 56-bit hole1 field.

    hole1 sits at byte offset 57 (inside check_point_copy); its seven bytes
    01 02 03 04 05 06 07 must read back as the little-endian u56
    0x07060504030201.
    """
    buf = bytearray(512)
    struct.pack_into("<Q", buf, 0, 0x1122334455667788)  # system_identifier
    struct.pack_into("<I", buf, 8, 1300)  # pg_control_version (v13)
    struct.pack_into("<I", buf, 12, 201909212)  # catalog_version_no
    buf[57:64] = bytes([0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07])
    return bytes(buf)


def test_tzx_little_endian_integer_reads(tmp_path):
    """8/16/24-bit little-endian fields are byte-reversed on read."""
    tzx = tmp_path / "min.tzx"
    tzx.write_bytes(tzx_bytes())
    res = run_fq(
        [
            "-d",
            "tzx",
            "-c",
            "[.major_version, .minor_version, "
            ".blocks[0].turbo_speed_data.pilot_pulse, "
            ".blocks[0].turbo_speed_data.sync_pulse_1, "
            ".blocks[0].turbo_speed_data.used_bits, "
            ".blocks[0].turbo_speed_data.pause, "
            ".blocks[0].turbo_speed_data.length]",
            str(tzx),
        ]
    )
    assert res.returncode == 0
    # bytes cd ab read as u16le 0xabcd; the u24 length bytes 03 00 00 as 3
    assert res.stdout.decode() == "[1,19,43981,4369,90,1911,3]\n"


def test_tzx_raw_data_field_is_lazy_string(tmp_path):
    """TZX raw bit fields decode to lazily-read string values."""
    tzx = tmp_path / "min.tzx"
    tzx.write_bytes(tzx_bytes())
    res = run_fq(
        [
            "-d",
            "tzx",
            "-c",
            "[(.signature | length), (.signature | tostring), "
            "(.blocks[0].turbo_speed_data.data | length)]",
            str(tzx),
        ]
    )
    assert res.returncode == 0
    # the 8-byte signature reads back as a string (with \x1a JSON-escaped)
    # and the 3-byte data field as 3
    assert res.stdout.decode() == '[8,"ZXTape!\\u001a",3]\n'


def test_bson_little_endian_integer_reads(tmp_path):
    """32- and 64-bit little-endian integers are byte-reversed on read."""
    bson = tmp_path / "min.bson"
    bson.write_bytes(bson_bytes())
    res = run_fq(
        [
            "-d",
            "bson",
            "-c",
            "[.size, .elements[0].value, .elements[1].value, "
            ".elements[0].type, .elements[1].type]",
            str(bson),
        ]
    )
    assert res.returncode == 0
    # both the u64 and the u32 store their bytes as 78 56 34 12 ... and read
    # back as 0x12345678; the document size is the u32le prefix 23
    assert res.stdout.decode() == '[23,305419896,305419896,"int64","int32"]\n'


def test_pg_control_56bit_little_endian_read(tmp_path):
    """A 56-bit little-endian padding field is byte-reversed on read."""
    img = tmp_path / "pg_control.bin"
    img.write_bytes(pg_control_bytes())
    res = run_fq(
        [
            "-d",
            "pg_control",
            "-o",
            "flavour=postgres13",
            "-c",
            "[.pg_control_version, .catalog_version_no, "
            ".check_point_copy.hole1]",
            str(img),
        ]
    )
    assert res.returncode == 0
    # seven bytes 01..07 read as the u56 0x07060504030201
    assert res.stdout.decode() == "[1300,201909212,1976943448883713]\n"
