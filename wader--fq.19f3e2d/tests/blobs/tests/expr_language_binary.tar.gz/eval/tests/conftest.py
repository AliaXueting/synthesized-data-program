"""Black-box helpers for running the fq reference binary.

Every test in this module invokes the candidate through ``PROGRAMGYM_EXECUTABLE``
with a pinned, hermetic child environment (no user config, no TTY, no network).
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

EXECUTABLE_ENV = "PROGRAMGYM_EXECUTABLE"
DEFAULT_TIMEOUT = 30


def executable_path() -> str:
    """Resolve the binary under test (never a hardcoded absolute path)."""
    env_path = os.environ.get(EXECUTABLE_ENV)
    if env_path:
        return env_path
    # fall back to the module workspace layout: <branch root>/executable
    local = Path(__file__).resolve().parents[2] / "executable"
    if local.exists():
        return str(local)
    raise RuntimeError(f"neither ${EXECUTABLE_ENV} nor {local} is available")


def child_env(cwd: Path | None = None) -> dict[str, str]:
    """Pinned environment for the child process (hermetic, reproducible)."""
    base = Path(cwd) if cwd is not None else Path(os.getcwd())
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": str(base / "home"),
        # point at a directory that does not exist so no user init.jq is loaded
        "XDG_CONFIG_HOME": str(base / "no-config"),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TZ": "UTC",
        "TERM": "dumb",
        "NO_COLOR": "1",
        "COLUMNS": "80",
    }
    # coverage instrumentation hook: propagate GOCOVERDIR when the pipeline
    # runs the instrumented reference binary
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    env.update(cov_env)
    return env


def run_fq(args, stdin=None, cwd=None, timeout=DEFAULT_TIMEOUT) -> subprocess.CompletedProcess:
    """Run the reference binary and capture stdout/stderr/exit code."""
    args = [str(a) for a in args]
    if cwd is not None:
        cwd = str(cwd)
    return subprocess.run(
        [executable_path()] + args,
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=child_env(Path(cwd) if cwd else None),
        cwd=cwd,
        timeout=timeout,
    )


def out_text(res) -> str:
    """Stdout of a run as text (fq writes UTF-8)."""
    return res.stdout.decode("utf-8", "replace")


def err_text(res) -> str:
    """Stderr of a run as text."""
    return res.stderr.decode("utf-8", "replace")
