"""CLI interaction behaviors: streams, stdin/files, args, includes, errors.

CATCHES: fq separates stdout/stderr for the print family, reads files and
stdin through the input/input_filename machinery (with a "break" error when
exhausted), parses --args/--jsonargs differently, supports try-includes via
a trailing "?", maps compile errors to file:line:column with exit code 3,
and exits 4 when probing an undecodable file.
"""
from __future__ import annotations

import pytest

from conftest import run_fq


def test_print_family_stream_separation():
    """print/println go to stdout, printerr/printerrln to stderr."""
    res = run_fq(["-n", "-c", '("x" | print), ("y" | println), ("z" | printerr), ("w" | printerrln)'])
    assert res.returncode == 0
    # print adds no newline, println does; same for the stderr variants
    assert res.stdout == b"xy\n"
    assert res.stderr == b"zw\n"


def test_debug_writes_json_array_to_stderr():
    """debug emits ["DEBUG:", <value>] as JSON on stderr, value on stdout."""
    res = run_fq(["-n", "-c", "1 | debug"])
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b'["DEBUG:",1]\n'


def test_stderr_writes_value_without_newline():
    """stderr writes the tostring form to stderr and passes the value through.

    stderr is defined as `printerr, .`: the input value continues downstream
    to stdout while its tostring form (unquoted for strings, compact JSON for
    containers, raw bytes for binaries) is written to stderr with no newline.
    """
    res = run_fq(["-n", "-c", "42 | stderr"])
    assert res.returncode == 0
    assert res.stdout == b"42\n"
    assert res.stderr == b"42"

    # a string is written unquoted on stderr, quoted on stdout
    res = run_fq(["-n", "-c", '"line" | stderr'])
    assert res.returncode == 0
    assert res.stdout == b'"line"\n'
    assert res.stderr == b"line"

    # containers use the compact tostring form
    res = run_fq(["-n", "-c", "{a:1} | stderr"])
    assert res.returncode == 0
    assert res.stdout == b'{"a":1}\n'
    assert res.stderr == b'{"a":1}'

    # a binary value is written as its raw bytes; the pass-through output
    # of a binary is also raw bytes without a trailing newline
    res = run_fq(["-n", "-c", "0x4142 | tobytes | stderr"])
    assert res.returncode == 0
    assert res.stdout == b"AB"
    assert res.stderr == b"AB"


def test_paste_reads_all_of_stdin():
    """paste concatenates stdin chunks until EOF and returns one string."""
    res = run_fq(["-n", "-c", "paste"], stdin=b"hello")
    assert res.returncode == 0
    assert res.stdout == b'"hello"\n'

    # empty stdin yields the empty string, not an error
    res = run_fq(["-n", "-c", "paste"], stdin=b"")
    assert res.returncode == 0
    assert res.stdout == b'""\n'

    # a second paste after EOF also returns the empty string
    res = run_fq(["-n", "-c", "[paste, paste]"], stdin=b"x")
    assert res.returncode == 0
    assert res.stdout == b'["x",""]\n'


def test_stdio_read_from_stdin():
    """_stdio_read reads n bytes from stdin and emits a second status value."""
    res = run_fq(["-n", "-c", '[_stdio_read("stdin"; 3)]'], stdin=b"abcdef")
    assert res.returncode == 0
    # a complete read appends a null (no error) as the second value
    assert res.stdout == b'["abc",null]\n'

    # the length argument is cast from a float by truncation
    res = run_fq(["-n", "-c", '[_stdio_read("stdin"; 2.7)]'], stdin=b"abcdef")
    assert res.returncode == 0
    assert res.stdout == b'["ab",null]\n'

    # a short read raises the "eof" value error
    res = run_fq(["-n", "-c", '[_stdio_read("stdin"; 4)]'], stdin=b"ab")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == "error: eof\n"

    # unknown fd names and write-only fds are rejected
    res = run_fq(["-n", "-c", '_stdio_read("nope"; 1)'], stdin=b"")
    assert res.returncode == 5
    assert res.stderr.decode() == "error: unknown fd nope\n"

    res = run_fq(["-n", "-c", '_stdio_read("stdout"; 1)'], stdin=b"")
    assert res.returncode == 5
    assert res.stderr.decode() == "error: stdout is not a writeable\n"


def test_stdio_read_huge_length_panics():
    """A float length beyond MaxInt clamps and dies in the Go runtime."""
    res = run_fq(["-n", "-c", '_stdio_read("stdin"; 1e300)'], stdin=b"abcdef")
    assert res.returncode == 2
    assert res.stdout == b""
    # the int cast clamps 1e300 to MaxInt and make() rejects that length
    assert res.stderr.decode().splitlines()[0] == "panic: runtime error: makeslice: len out of range"


def test_input_filename_and_input_over_files(tmp_path):
    """input/input_filename walk the positional file arguments."""
    (tmp_path / "r1.bin").write_bytes(b"abc")
    (tmp_path / "r2.bin").write_bytes(b"de")
    res = run_fq(
        ["-d", "bytes", "-c", "[input_filename, length]", "r1.bin", "r2.bin"],
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["r1.bin",3]\n["r2.bin",2]\n'

    res = run_fq(["-d", "bytes", "-c", "input_filename", "r1.bin"], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout.decode() == '"r1.bin"\n'


def test_input_filename_is_stdin_marker():
    """Reading from stdin reports the <stdin> marker as filename."""
    res = run_fq(["-d", "bytes", "-c", "[., input_filename]"], stdin=b"xyz")
    assert res.returncode == 0
    assert res.stdout.decode() == '["xyz","<stdin>"]\n'


def test_input_beyond_available_breaks(tmp_path):
    """input errors with "break" when no more inputs are available."""
    (tmp_path / "r1.bin").write_bytes(b"abc")
    res = run_fq(
        ["-d", "bytes", "-c", "[input]", "r1.bin"], cwd=tmp_path, stdin=b""
    )
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == "error: break\n"

    # also on stdin once it has been consumed by the main input
    res = run_fq(["-d", "bytes", "-c", "[., (input | length)]"], stdin=b"xyz")
    assert res.returncode == 5
    assert res.stderr.decode() == "error: break\n"


def test_probe_failure_exit_code(tmp_path):
    """An undecodable file with no forced format exits 4 with a hint."""
    (tmp_path / "nod.bin").write_bytes(b"x")
    res = run_fq(["-c", ".", "nod.bin"], cwd=tmp_path)
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.decode() == (
        "error: nod.bin: probe: failed to decode: "
        "try fq -d FORMAT to force format, see fq -h formats for list\n"
    )


def test_args_and_jsonargs():
    """--args keeps strings, --jsonargs parses JSON, both can mix with --arg."""
    res = run_fq(["-n", "-c", "$ARGS", "--args", "a", "b"])
    assert res.returncode == 0
    assert res.stdout.decode() == '{"named":{},"positional":["a","b"]}\n'

    res = run_fq(["-n", "-c", "$ARGS", "--jsonargs", "1", '"x"', "[2]"])
    assert res.returncode == 0
    assert res.stdout.decode() == '{"named":{},"positional":[1,"x",[2]]}\n'

    # --args keeps embedded spaces and empty argument lists stay arrays
    res = run_fq(["-n", "-c", "$ARGS", "--args", "a b", "c"])
    assert res.returncode == 0
    assert res.stdout.decode() == '{"named":{},"positional":["a b","c"]}\n'

    res = run_fq(["-n", "-c", "$ARGS", "--args"])
    assert res.returncode == 0
    assert res.stdout.decode() == '{"named":{},"positional":[]}\n'

    res = run_fq(["-n", "-c", "$ARGS", "--arg", "n", "v", "--args", "a"])
    assert res.returncode == 0
    assert res.stdout.decode() == '{"named":{"n":"v"},"positional":["a"]}\n'

    res = run_fq(["-n", "-c", "$ARGS", "--argjson", "n", '{"k":1}', "--jsonargs", "null"])
    assert res.returncode == 0
    assert res.stdout.decode() == '{"named":{"n":{"k":1}},"positional":[null]}\n'


def test_jsonargs_invalid_json_is_usage_error():
    """Invalid JSON in --jsonargs fails with exit code 2, not 5."""
    res = run_fq(["-n", "-c", "$ARGS", "--jsonargs", "{bad"])
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.decode() == (
        'error: --jsonargs {bad: fromjson cannot be applied to "{bad": '
        "invalid character 'b' looking for beginning of object key string\n"
    )


def test_include_and_try_include(tmp_path):
    """include loads a library from -L; a trailing ? makes it optional."""
    (tmp_path / "mylib.jq").write_text("def double: . * 2;\n")
    res = run_fq(["-n", "-L", str(tmp_path), "-c", 'include "mylib"; 21 | double'])
    assert res.returncode == 0
    assert res.stdout.decode() == "42\n"

    # try-include silently ignores missing files
    res = run_fq(["-n", "-L", str(tmp_path), "-c", 'include "missing?"; 1'])
    assert res.returncode == 0
    assert res.stdout.decode() == "1\n"

    res = run_fq(
        ["-n", "-L", str(tmp_path), "-c", 'include "mylib?"; include "nope?"; 3 | double']
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "6\n"

    # without the ? a missing include is a compile error (exit 3)
    res = run_fq(["-n", "-L", str(tmp_path), "-c", 'include "missing"; 1'])
    assert res.returncode == 3
    assert res.stderr.decode() == "error: arg: open missing.jq: file does not exist\n"


def test_include_searches_cwd_before_L(tmp_path):
    """include resolves modules against ./ (the cwd) before any -L path.

    The search order is the working directory first, then the -L dirs, so a
    same-named library in the cwd shadows one in -L.
    """
    (tmp_path / "mylib.jq").write_text("def double: . * 100;\n")
    libdir = tmp_path / "libdir"
    libdir.mkdir()
    (libdir / "mylib.jq").write_text("def double: . * 7;\n")

    # no -L at all: the file in the cwd is found and used
    res = run_fq(["-n", "-c", 'include "mylib"; 3 | double'], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout.decode() == "300\n"

    # with a -L dir containing a same-named file, the cwd copy still wins
    res = run_fq(
        ["-n", "-L", str(libdir), "-c", 'include "mylib"; 3 | double'], cwd=tmp_path
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "300\n"

    # from a cwd without the file, -L is used
    empty = tmp_path / "empty"
    empty.mkdir()
    res = run_fq(
        ["-n", "-L", str(libdir), "-c", 'include "mylib"; 3 | double'], cwd=empty
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "21\n"

    # relative subdirectory paths resolve against the cwd too
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "other.jq").write_text("def inc: . + 1;\n")
    res = run_fq(["-n", "-c", 'include "sub/other"; 41 | inc'], cwd=tmp_path)
    assert res.returncode == 0
    assert res.stdout.decode() == "42\n"

    # the ".jq" suffix is always appended, even if already present
    res = run_fq(["-n", "-c", 'include "mylib.jq"; 1'], cwd=tmp_path)
    assert res.returncode == 3
    assert res.stderr.decode() == "error: arg: open mylib.jq.jq: file does not exist\n"


def test_include_not_toplevel_is_compile_error():
    """include is only allowed as a top-level statement."""
    res = run_fq(["-n", "-c", '(include "x") + 1'])
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr.decode() == 'error: arg:1:8: unexpected token "include"\n'


@pytest.mark.parametrize(
    "query,expected_err",
    [
        (".a\n.b[1\n", "error: {f}:3:0: unexpected EOF\n"),
        (".a\n.[1] ]\n", 'error: {f}:2:6: unexpected token "]"\n'),
        ("def f: 1; f(2)\n", "error: {f}: function not defined: f/1\n"),
    ],
)
def test_compile_error_positions(tmp_path, query, expected_err):
    """Compile errors of -f queries report file:line:column with exit 3."""
    qfile = tmp_path / "q.jq"
    qfile.write_text(query)
    res = run_fq(["-n", "-f", str(qfile)])
    assert res.returncode == 3
    assert res.stdout == b""
    # positions are 1-based lines/columns into the query file; EOF errors
    # land on the line after the last one
    assert res.stderr.decode() == expected_err.format(f=qfile)


def test_multiline_query_outputs_per_line(tmp_path):
    """A multi-line -f query keeps producing one output per input."""
    qfile = tmp_path / "q.jq"
    qfile.write_text("{a: 1},\n[2]\n")
    res = run_fq(["-n", "-c", "-f", str(qfile)])
    assert res.returncode == 0
    assert res.stdout.decode() == '{"a":1}\n[2]\n'
