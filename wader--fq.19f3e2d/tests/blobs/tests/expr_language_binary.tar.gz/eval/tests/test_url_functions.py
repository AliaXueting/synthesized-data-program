"""URL component functions from_url/to_url and the encode/path/query helpers.

CATCHES: these are Go net/url semantics (not hand-rolled escaping): "+" means
space in query encoding but stays "+" in path encoding, %2F is emitted
uppercase, multi-valued query keys collapse to arrays, and to_url silently
drops rawquery whenever the query key is missing or null.
"""
from __future__ import annotations

import pytest

from conftest import run_fq


def test_urlencode_escapes_and_double_encoding():
    """to_urlencode query-escapes; already-escaped input is escaped again."""
    res = run_fq(
        [
            "-n",
            "-c",
            '["a b&c", "a+b%20c", "é", "%C3%A9", "~._-"] | map(to_urlencode)',
        ]
    )
    assert res.returncode == 0
    # space becomes +, & becomes %26; feeding an escaped string back in
    # escapes the % signs themselves; unreserved ~._- pass through
    assert res.stdout.decode() == '["a+b%26c","a%2Bb%2520c","%C3%A9","%25C3%25A9","~._-"]\n'


def test_from_urlencode_unescaping():
    """from_urlencode decodes both + and %20 as spaces and keeps literals."""
    res = run_fq(
        ["-n", "-c", '["%C3%A9", "a+b", "a%20b", "~._-"] | map(from_urlencode)']
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["é","a b","a b","~._-"]\n'


def test_urlencode_binary_input():
    """Binaries are cast to strings (raw bytes) before query/path escaping.

    CATCHES: the cast goes through the binary's JQValueToGoJQ, so the exact
    bit range is percent-encoded as raw bytes (0xf08|tobits -> %F0%80), not
    re-encoded as UTF-8.
    """
    res = run_fq(
        [
            "-n",
            "-c",
            '[("a b" | tobytes | to_urlencode), ("a b" | tobytes | to_urlpath), '
            "(0xf08 | tobits | to_urlencode), (\"abc\" | tobytes | to_urlencode), "
            '(1 | tobytes | from_urlencode)]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["a+b","a%20b","%F0%80","abc","\\u0001"]\n'


@pytest.mark.parametrize(
    "expr, expected_err",
    [
        ("1 | to_urlencode", "error: to_urlencode cannot be applied to: number (1)\n"),
        ("null | to_urlencode", "error: to_urlencode cannot be applied to: null\n"),
        ("true | to_urlencode", "error: to_urlencode cannot be applied to: boolean (true)\n"),
        ("[1] | to_urlencode", "error: to_urlencode cannot be applied to: array ([1])\n"),
        ("{} | to_urlencode", "error: to_urlencode cannot be applied to: object ({})\n"),
        ("true | to_urlquery", "error: to_urlquery cannot be applied to: boolean (true)\n"),
        ("[1] | to_urlquery", "error: to_urlquery cannot be applied to: array ([1])\n"),
        ("null | from_url", "error: from_url cannot be applied to: null\n"),
        ('{"a":1} | from_base64', "error: from_base64 cannot be applied to: object ({\"a\":1})\n"),
        (
            '"https://www.example.com:8080/a%20b/c?a=1&b=2&a=3#frag" | to_url',
            'error: to_url cannot be applied to: string ("https://www.example.com: ...")\n',
        ),
    ],
)
def test_function_input_type_errors(expr, expected_err):
    """Non-string input to the string URL functions is a runtime error.

    CATCHES: the error names the function, the jq type and a preview of the
    value, and long previews are truncated with " ...".
    """
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == expected_err


def test_urlpath_roundtrip_and_reserved():
    """to_urlpath escapes / as %2F (uppercase) but keeps & = and unreserved."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("a/b c" | to_urlpath), ("a%2Fb%20c" | from_urlpath), ("?&=" | to_urlpath), '
            '("a/b" | to_urlpath), ("~._-" | to_urlpath), ("sp ace" | from_urlpath)]',
        ]
    )
    assert res.returncode == 0
    # from_urlpath only decodes %XX, so a literal space survives; to_urlpath
    # must escape ? but leave & and = alone (path rules, not query rules)
    assert res.stdout.decode() == '["a%2Fb%20c","a/b c","%3F&=","a%2Fb","~._-","sp ace"]\n'


def test_from_urlquery_structure():
    """from_urlquery: repeated keys become arrays, bare/empty keys allowed."""
    res = run_fq(
        [
            "-n",
            "-c",
            '["a=1&b=2&a=3", "a=1&&b&=2", "a", ""] | map(from_urlquery)',
        ]
    )
    assert res.returncode == 0
    # "a" with no = gives {"a": ""}; an empty segment is skipped; a key of ""
    # is kept ("=2" -> "":"2"); keys are sorted in the JSON output
    assert res.stdout.decode() == (
        '[{"a":["1","3"],"b":"2"},{"":"2","a":"1","b":""},{"a":""},{}]\n'
    )


@pytest.mark.parametrize(
    "expr, expected_err",
    [
        ('"a=1;=2&&b" | from_urlquery', "error: invalid semicolon separator in query\n"),
        ('"%zz=1" | from_urlquery', 'error: invalid URL escape "%zz"\n'),
        ('"%zz" | from_urlencode', 'error: invalid URL escape "%zz"\n'),
        ('"a%2" | from_urlencode', 'error: invalid URL escape "%2"\n'),
        ('"%zz" | from_urlpath', 'error: invalid URL escape "%zz"\n'),
    ],
)
def test_url_decode_errors(expr, expected_err):
    """Malformed escapes and semicolons are runtime errors with exit code 5.

    CATCHES: the exact Go net/url error strings (including the quoted escape
    sequence) are surfaced unchanged.
    """
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stderr.decode() == expected_err


def test_to_urlquery_null_and_type_inputs():
    """null becomes an empty query map; scalars/arrays are type errors."""
    res = run_fq(["-n", "-c", "[(null | to_urlquery), ({} | to_urlquery)]"])
    assert res.returncode == 0
    # Cast of null to the options map yields an empty map -> empty encoding
    assert res.stdout.decode() == '["",""]\n'


def test_to_urlquery_value_normalization():
    """to_urlquery stringifies values: null->"", numbers/bools->JSON, arrays repeat.

    CATCHES: nested objects and arrays-of-arrays are silently dropped (not
    errors), big integers keep all digits (no float rounding), and keys sort
    alphabetically like Go's url.Values.Encode.
    """
    res = run_fq(
        [
            "-n",
            "-c",
            '{"a": null, "b": 1, "c": true, "d": [1,2], "e": {"f": 1.5}} | to_urlquery',
        ]
    )
    assert res.returncode == 0
    # "e" (an object value) disappears entirely; "d" repeats the key
    assert res.stdout.decode() == '"a=&b=1&c=true&d=1&d=2"\n'

    res = run_fq(
        [
            "-n",
            "-c",
            '[{"a":123456789012345678901234567890}, {"a":-1.5}, {"a": [[1]]}, '
            '{"a": [null, "x"]}, {"a b": "c/d"}] | map(to_urlquery)',
        ]
    )
    assert res.returncode == 0
    # the 30-digit integer survives; -1.5 uses its JSON form; an array whose
    # elements are not strings contributes nothing; array with null gives a
    # bare "a=" entry; both key and value are query-escaped
    assert res.stdout.decode() == (
        '["a=123456789012345678901234567890","a=-1.5","","a=&a=x","a+b=c%2Fd"]\n'
    )


def test_from_url_components():
    """from_url splits all URL parts; rawpath appears when it must."""
    res = run_fq(
        [
            "-n",
            "-c",
            '"https://user:pass@www.example.com:8080/a%20b/c?a=1&b=2&a=3#frag" | from_url',
        ]
    )
    assert res.returncode == 0
    # %20 in the path decodes; the query keeps both rawquery and a parsed
    # query object with the repeated key as an array; empty parts are omitted
    assert res.stdout.decode() == (
        '{"fragment":"frag","host":"www.example.com:8080","path":"/a b/c",'
        '"query":{"a":["1","3"],"b":"2"},"rawquery":"a=1&b=2&a=3","scheme":"https",'
        '"user":{"password":"pass","username":"user"}}\n'
    )

    res = run_fq(
        [
            "-n",
            "-c",
            '["?a=1", "//h/p", "/rel/path", "", "schema://", "mailto:foo@bar.com", '
            '"https://h/p?", "https://h/p#", "https://h/a%2Fb"] | map(from_url)',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == (
        '[{"query":{"a":"1"},"rawquery":"a=1"},{"host":"h","path":"/p"},'
        '{"path":"/rel/path"},{},{"scheme":"schema"},{"scheme":"mailto"},'
        '{"host":"h","path":"/p","scheme":"https"},'
        '{"host":"h","path":"/p","scheme":"https"},'
        '{"host":"h","path":"/a/b","rawpath":"/a%2Fb","scheme":"https"}]\n'
    )


@pytest.mark.parametrize(
    "expr, expected_err",
    [
        (
            '"http://h /p" | from_url',
            'error: parse "http://h /p": invalid character " " in host name\n',
        ),
        (
            '"http://h\tp" | from_url',
            'error: parse "http://h\\tp": net/url: invalid control character in URL\n',
        ),
    ],
)
def test_from_url_parse_errors(expr, expected_err):
    """Unparseable URLs are runtime errors quoting the input.

    CATCHES: the Go url.Parse error text is passed through verbatim, with the
    tab shown escaped as \\t inside the quoted URL.
    """
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stderr.decode() == expected_err


def test_to_url_assembly():
    """to_url rebuilds a URL from parts, escaping path and fragment."""
    res = run_fq(
        [
            "-n",
            "-c",
            '{"scheme":"https","host":"www.example.com:8080","path":"/a b/c",'
            '"query":{"a":["1","2"],"b":"x"},"fragment":"f g",'
            '"user":{"username":"u","password":"p"}} | to_url',
        ]
    )
    assert res.returncode == 0
    # spaces in path/fragment become %20 (not +), query values with no
    # special chars stay bare, array values repeat the key, keys sort
    assert res.stdout.decode() == '"https://u:p@www.example.com:8080/a%20b/c?a=1&a=2&b=x#f%20g"\n'

    res = run_fq(
        [
            "-n",
            "-c",
            "["
            '({"host":"h","path":"/p","user":{"username":"onlyuser"}} | to_url), '
            '({"host":"h","user":{"username":"","password":"pw"}} | to_url), '
            '({"scheme":"mailto","path":"foo@bar.com"} | to_url), '
            '({"path":"/p","query":{"a":["",null],"b":[]}} | to_url)]',
        ]
    )
    assert res.returncode == 0
    # a user with an empty username is dropped entirely; mailto with a path
    # (not opaque) renders "mailto://..."; empty strings still emit "a=" but
    # an empty array value emits nothing
    assert res.stdout.decode() == (
        '["//onlyuser@h/p","//h","mailto://foo@bar.com","/p?a=&a="]\n'
    )


def test_to_url_rawquery_precedence():
    """The query map always wins over rawquery; missing query means empty.

    CATCHES: a rawquery key alone produces NO query string (casting the
    missing/null query key to a map succeeds as an empty map and overwrites
    rawquery); rawquery only survives when query is present but not a map.
    """
    res = run_fq(
        [
            "-n",
            "-c",
            "["
            '({"scheme":"https","host":"h","path":"/p","rawquery":"a=1&b=2"} | to_url), '
            '({"scheme":"https","host":"h","path":"/p","rawquery":"a=1&b=2","query":"zzz"} | to_url), '
            '({"scheme":"https","host":"h","path":"/p","query":null} | to_url), '
            '({"scheme":"https","host":"h","path":"/p","query":{"a":null}} | to_url), '
            "(null | to_url), "
            '({"query":{"a":{"b":1}}} | to_url)]',
        ]
    )
    assert res.returncode == 0
    # null input is an empty map -> empty URL; object-valued query entries
    # are dropped by the same rule as to_urlquery
    assert res.stdout.decode() == (
        '["https://h/p","https://h/p?a=1&b=2","https://h/p","https://h/p?a=","",""]\n'
    )
