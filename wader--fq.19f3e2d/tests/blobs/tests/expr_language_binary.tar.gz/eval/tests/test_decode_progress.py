"""The decode function's progress option and its discarded output writer.

decode($name; {progress: EXPR}) evaluates EXPR while decoding, with the
expression's value output going to a context-aware DISCARD writer
(internal/iox.DiscardCtxWriter): progress output never reaches stdout. The
expression sees an {approx_read_bytes, total_size} object during decode and
null once when decoding finishes, and any error it raises is swallowed.

CATCHES: a re-implementation that lets progress output leak to stdout, that
runs the expression on a different schedule, or that propagates progress
errors, breaks the stream shape pinned here.
"""
from __future__ import annotations

from conftest import run_fq


def test_decode_progress_output_is_discarded(tmp_path):
    """Progress expression values are written to a discarded output."""
    big = tmp_path / "big.bin"
    big.write_bytes(bytes(range(256)) * 12)  # 3072 bytes > 1024-byte precision

    # the progress expression's value output is swallowed
    res = run_fq(
        ["-n", "-c", f'"{big}" | open | decode("bytes"; {{progress: "."}}) | length']
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "3072\n"
    assert res.stderr == b""


def test_decode_progress_runs_once_with_null(tmp_path):
    """A fast decode runs the progress expression once, with null input."""
    big = tmp_path / "big.bin"
    big.write_bytes(bytes(range(256)) * 12)

    # intermediate progress calls are throttled away (decode finishes in
    # well under the 200 ms interval) and the final call receives null;
    # printerr writes to the real stderr so the call is observable
    res = run_fq(
        [
            "-n",
            "-c",
            f'"{big}" | open | decode("bytes"; {{progress: ". | printerr"}}) | length',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "3072\n"
    # exactly one progress evaluation, printing tostring(null) without newline
    assert res.stderr == b"null"


def test_decode_progress_errors_are_swallowed(tmp_path):
    """Errors raised by the progress expression do not fail the decode."""
    big = tmp_path / "big.bin"
    big.write_bytes(bytes(range(256)) * 12)

    res = run_fq(
        [
            "-n",
            "-c",
            f'"{big}" | open | decode("bytes"; {{progress: "1 | error(\\"boom\\")"}}) | length',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "3072\n"
    assert res.stderr == b""

    # a non-string progress fails the decode_opts struct cast; the error
    # previews the whole defaulted options object (truncated by fq)
    res = run_fq(
        ["-n", "-c", f'"{big}" | open | decode("bytes"; {{progress: 1}}) | length']
    )
    assert res.returncode == 5
    assert res.stderr.decode() == (
        'error: decode second argument cannot be: object ({"addrbase":16,"arg":[]," ...})\n'
    )

    # a null progress (or null opts altogether) means no progress reporting
    res = run_fq(
        ["-n", "-c", f'"{big}" | open | decode("bytes"; {{progress: null}}) | length']
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "3072\n"

    res = run_fq(
        ["-n", "-c", f'"{big}" | open | decode("bytes"; null) | length']
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "3072\n"


def test_decode_progress_object_input(tmp_path):
    """The progress expression can read its progress object fields."""
    big = tmp_path / "big.bin"
    big.write_bytes(bytes(range(256)) * 12)

    # total_size is the opened file's size; the final null input must be
    # handled by the expression (isempty/alternative) or it would error,
    # which is swallowed anyway
    res = run_fq(
        [
            "-n",
            "-c",
            f'"{big}" | open | decode("bytes"; '
            '{progress: "(.total_size // 0) | tostring | _stderr"}) | length',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "3072\n"
    # only the final throttled evaluation runs, and it gets null input
    assert res.stderr == b"0"
