"""gojq value casting rules for fq functions (internal/gojqx/types.go).

CATCHES: how jq values are cast into Go function parameters — binaries pass
through their string form, option structs reject wrong-typed fields with an
argument error, floats truncate into int options, and big ints that do not
fit an int64 make the whole option cast fail.
"""
from __future__ import annotations

import pytest

from conftest import run_fq


def test_string_functions_accept_binary_input():
    """String-parameter functions receive a binary's raw byte string.

    CATCHES: the cast converts the binary value via its string form, so a
    4-bit binary 0xf becomes the byte 0xf0 ("0xf|tobits|to_urlencode" is
    "%F0", not "%0f"), and from_hex output feeds from_utf8 directly.
    """
    res = run_fq(
        [
            "-n",
            "-c",
            '[("a b" | tobytes | to_urlencode), (1 | tobytes | from_urlencode), '
            '("c3a9" | from_hex | from_utf8), (0xf | tobits | to_urlencode)]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["a+b","\\u0001","é","%F0"]\n'


@pytest.mark.parametrize(
    "expr, expected_err",
    [
        (
            '"abc" | _to_strencoding(1)',
            "error: to_strencoding first argument cannot be: number (1)\n",
        ),
        (
            '"abc" | _to_strencoding("x")',
            'error: to_strencoding first argument cannot be: string ("x")\n',
        ),
        (
            '"abc" | tobytes("x")',
            'error: tobits first argument cannot be: object ({"keep_range":false,"pad_ ...})\n',
        ),
        (
            "1 | tobits(100000000000000000000000000) | length",
            'error: tobits first argument cannot be: object ({"keep_range":false,"pad_ ...})\n',
        ),
    ],
)
def test_function_argument_type_errors(expr, expected_err):
    """Wrong-typed function arguments fail with an argument error.

    CATCHES: the message names "first argument", the value preview is
    truncated with " ...", the leading underscore is stripped from the
    function name (_to_strencoding reports as to_strencoding), and a
    string field in an options struct (or a pad that overflows int64)
    makes the whole struct cast fail.
    """
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stderr.decode() == expected_err


def test_integer_option_casting():
    """$pad option ints accept floats (truncating) and negatives (no pad).

    CATCHES: 1.9 pads to 1 byte so nothing is added, 0.5 truncates to 0 and
    falls back to the unit (no extra bits), 2 pads the single bit of 1 to
    "10" (0x40), and a negative pad is a no-op rather than an error.
    """
    res = run_fq(
        [
            "-n",
            "-c",
            '[("a" | tobytes(1.9) | to_hex), ("a" | tobits(0.5) | length), '
            '(1 | tobits(2) | to_hex), ("a" | tobytes(-1) | to_hex), '
            '("a" | tobits(-8) | to_hex)]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["61",8,"40","61","61"]\n'


def test_binary_stringification_in_containers():
    """Binaries stringify (JSON-escaped) when embedded in other values.

    CATCHES: tojson and array output convert the padded binary to its string
    form, escaping the NUL pad byte as \\u0000 inside the JSON text; the
    explicit string bits_format produces the same string.
    """
    res = run_fq(
        [
            "-n",
            "-c",
            '[(("a" | tobytes(2)) | tojson), ((["a" | tobytes(2)]) | tojson), '
            '(("ab" | tobits(12) | tovalue({bits_format: "string"})))]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == (
        r'["\"\\u0000a\"","[\"\\u0000a\"]","\u0000ab"]' "\n"
    )
