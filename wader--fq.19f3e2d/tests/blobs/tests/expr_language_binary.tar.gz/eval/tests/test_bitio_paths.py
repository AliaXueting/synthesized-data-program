"""Bit-level binary machinery: padding, multi-readers, bit-offset display.

CATCHES: $pad PREPENDS zero bits (unusual — most pads append), sliced
binaries keep absolute bit positions, hexdump renders non-byte-aligned
ranges with fractional addresses like 0x1.2-0x3.6, and nested byte arrays
are concatenated through a multi-reader.
"""
from __future__ import annotations

from conftest import run_fq


def test_tobytes_pad_prepends_zero_bits():
    """tobytes($n) zero-pads the front up to $n byte units."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("a" | tobytes(2) | to_hex), ("a" | tobytes(2) | length), '
            '("a" | tobytes(2) | .[0]), ("a" | tobytes(2) | .[1]), '
            '("a" | tobytes(2) | tovalue({bits_format: "hex"})), '
            '("a" | tobytes(2) | tovalue({bits_format: "base64"})), '
            '("a" | tobytes(2) | tovalue({bits_format: "snippet"}))]',
        ]
    )
    assert res.returncode == 0
    # "a" is 8 bits; padding to 2 units prepends a zero byte (00 61), which
    # every read path observes: hex, indexing, base64 and the "<n>" snippet
    assert res.stdout.decode() == '["0061",2,0,97,"0061","AGE=","<2>AGE="]\n'


def test_tobits_pad_in_bit_units():
    """tobits($n) pads to $n BIT units and the pad survives unit conversion."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("ab" | tobits(12) | to_hex), ("ab" | tobits(12) | length), '
            '("ab" | tobits(12) | .bits | length), ("ab" | tobits(12) | .bytes | length), '
            '("ab" | tobits(12) | .bytes | to_hex)]',
        ]
    )
    assert res.returncode == 0
    # "ab" is 16 bits; 16 % 12 = 4 so 8 zero bits are prepended (24 total);
    # the .bytes view of the same reader still includes the pad
    assert res.stdout.decode() == '["006162",24,24,3,"006162"]\n'


def test_slicing_padded_binaries():
    """Slices index into the padded bit stream, consuming pad bits."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[(("ab" | tobits(12)) | .[4:20] | to_hex), '
            '(("ab" | tobits(12)) | .bits[4:20] | length), '
            '(("ab" | tobits(12)) | .bytes[1:2] | to_hex)]',
        ]
    )
    assert res.returncode == 0
    # bits 4..20 of 00 61 62 are 0000 01100001 0110 -> 0x06 0x16; the .bytes
    # view re-slices the same absolute bit positions in byte units
    assert res.stdout.decode() == '["0616",16,"61"]\n'


def test_hexdump_of_padded_binaries():
    """hd shows the prepended zero bytes as part of the buffer."""
    res = run_fq(["-n", '"a" | tobytes(2) | hd'])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
        "0x0|00 61|                                         |.a|             |.: raw bits 0x0-0x2 (2)\n"
    )

    res = run_fq(["-n", '"ab" | tobits(12) | hd'])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
        "0x0|00 61 62|                                      |.ab|            |.: raw bits 0x0-0x3 (3)\n"
    )


def test_hexdump_of_bit_offset_slice():
    """hd of a mid-byte slice shows fractional start/stop addresses.

    CATCHES: bits 10..30 of "abcdefg" start inside byte 1 and stop inside
    byte 3, rendered as 0x1.2-0x3.6 with size 2.4 bytes, and the hexdump
    body still shows the full bytes 62 63 64 with the leading partial byte
    blanked in the ASCII column.
    """
    res = run_fq(["-n", '"abcdefg" | tobytes | .bits[10:30] | hd'])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
        "0x0|   62 63 64                                    | bcd            |.: raw bits 0x1.2-0x3.6 (2.4)\n"
    )


def test_iolist_binaries_use_multireader():
    """Nested arrays/strings concatenate; an empty array gives 0 bits."""
    res = run_fq(
        [
            "-n",
            "-c",
            "[([] | tobytes | length), ([[1],[2]] | tobytes | to_hex), "
            '([[],["a"]] | tobytes | to_hex), (["","a"] | tobytes | to_hex), '
            "([[255,0],[1]] | tobytes | to_hex)]",
        ]
    )
    assert res.returncode == 0
    # an empty element contributes nothing; a nested list flattens its bytes
    # in order regardless of nesting depth
    assert res.stdout.decode() == '[0,"0102","61","61","ff0001"]\n'


def test_binary_index_and_slice_clamping():
    """Out-of-range indexing yields null and slices clamp, never error."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("abc" | tobytes | .[10]), ("abc" | tobytes | .[1:99] | length), '
            '("abc" | tobytes | .[-10:] | length), ("abcdefg" | tobytes | .bits[10:30] | length)]',
        ]
    )
    assert res.returncode == 0
    # .[10] past the end is null (like a string), [1:99] clamps to 2 bytes,
    # [-10:] clamps to the whole input, .bits[10:30] is 20 bits
    assert res.stdout.decode() == "[null,2,3,20]\n"


def test_number_binaries_are_left_aligned():
    """Numbers convert to binaries at their minimal bit width, left-aligned.

    CATCHES: indexing a byte binary returns a NUMBER, and converting that
    number back to a binary re-derives its width (97 is 7 bits -> "c2"),
    while 255 is exactly 8 bits -> "ff" and 1 padded to 2 bits -> "40".
    """
    res = run_fq(
        [
            "-n",
            "-c",
            '[("abc" | tobytes | .[0] | to_hex), (0xff | to_hex), (1 | tobits(2) | to_hex)]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["c2","ff","40"]\n'
