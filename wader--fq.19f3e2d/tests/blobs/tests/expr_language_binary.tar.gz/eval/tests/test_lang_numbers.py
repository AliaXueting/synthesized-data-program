"""Language extensions: number literals, big integers and raw strings.

CATCHES: a re-implementation without the forked gojq lexer/arithmetics would
lose hex/octal/binary literals, `_` grouping and arbitrary precision integers.
"""
from __future__ import annotations

import pytest

from conftest import run_fq


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("0xff", "255\n"),
        ("0xFF", "255\n"),
        ("0x0", "0\n"),
        ("0b1010", "10\n"),
        ("0b0", "0\n"),
        ("0o17", "15\n"),
        ("0o0", "0\n"),
        ("0x_ff", "255\n"),
        ("0xff_ff", "65535\n"),
        ("0xdead_beef", "3735928559\n"),
        ("0b_1010", "10\n"),
        ("0o_17", "15\n"),
        ("0xffff_ffff_ffff_ffff", "18446744073709551615\n"),
    ],
)
def test_integer_literal_bases(expr, expected):
    """Integer literals in hex, octal and binary notation with _ grouping."""
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 0
    assert res.stdout.decode() == expected


@pytest.mark.parametrize(
    "expr",
    ["1_000", "1_0", "0Xff", "0B11", "0O7"],
)
def test_rejected_number_literals(expr):
    """Decimal literals and upper case prefixes are not valid tokens."""
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 3
    # compile errors are reported as <file>:<line>:<column> with exit code 3
    assert res.stdout == b""
    assert res.stderr.decode().startswith("error: arg:1:")


def test_bigint_arithmetic_precision():
    """Arithmetic stays exact far beyond float64 precision."""
    res = run_fq(["-n", "-c", "10000000000000000001 + 1"])
    assert res.returncode == 0
    assert res.stdout.decode() == "10000000000000000002\n"


def test_bigint_multiplication_and_division():
    """Big multiplication and exact division of huge integers."""
    res = run_fq(
        ["-n", "-c", "[123456789012345678901234567890 * 987654321, 100000000000000000000 / 4]"]
    )
    assert res.returncode == 0
    # both results are exact big integers, no float64 rounding
    assert res.stdout.decode() == "[121932631124828532112482853211126352690,25000000000000000000]\n"


def test_bigint_modulo_and_comparison():
    """Modulo, comparison and sorting work on arbitrary size integers."""
    # the inner array is parenthesised: a bare `| sort` inside [...] would pipe
    # the whole comma expression stream into sort (jq precedence: | binds
    # looser than ,) and fail with "sort cannot be applied to: number"
    res = run_fq(
        [
            "-n",
            "-c",
            "[1000000000000000000007 % 97, 999999999999999999999 > 1, "
            "([3, 100000000000000000000, 1] | sort)]",
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "[58,true,[1,3,100000000000000000000]]\n"


def test_bigint_division_exact_vs_float():
    """Division of big ints stays exact when evenly divisible, else float64."""
    res = run_fq(
        [
            "-n",
            "-c",
            "[99999999999999999999 / 3, 99999999999999999999 / 2, "
            "9223372036854775807 / 2, 6 / 3, 7 / 2]",
        ]
    )
    assert res.returncode == 0
    # 99999999999999999999/3 is exact big int division; .../2 and the int64
    # max /2 fall back to float64 (note the rounded 4611686018427388000)
    assert (
        res.stdout.decode()
        == "[33333333333333333333,50000000000000000000,4611686018427388000,2,3.5]\n"
    )


@pytest.mark.parametrize(
    "expr,err",
    [
        ("1 / 0", "error: cannot divide number (1) by: number (0)\n"),
        ("0 / 0", "error: cannot divide number (0) by: number (0)\n"),
        ("1 % 0", "error: cannot modulo number (1) by: number (0)\n"),
    ],
)
def test_division_and_modulo_by_zero(expr, err):
    """Divide/modulo by zero is a runtime error with exit code 5."""
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == err


def test_modulo_sign_truncation():
    """Modulo truncates towards zero and works on arbitrary size integers."""
    res = run_fq(
        ["-n", "-c", "[-7 % 3, 7 % -3, 123456789012345678901234567890 % 987654321]"]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "[-1,1,574845669]\n"


def test_float_and_integer_mix():
    """Float operations keep float semantics while ints stay ints."""
    res = run_fq(["-n", "-c", "[10 / 4, 10.0 / 4, 1 / 3, 2.5 * 2, 7 - 2.5]"])
    assert res.returncode == 0
    assert res.stdout.decode() == "[2.5,2.5,0.3333333333333333,5,4.5]\n"


def test_intdiv():
    """intdiv/2 integer division including its quirky negative behaviour."""
    res = run_fq(["-n", "-c", "[intdiv(7;2), intdiv(10;5), intdiv(-7;2)]"])
    assert res.returncode == 0
    assert res.stdout.decode() == "[3,2,0]\n"


def test_intdiv_zero_divisor_from_negative():
    """A negative divisor truncates to zero and fails like a divide by zero."""
    res = run_fq(["-n", "-c", "intdiv(7;-2)"])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == "error: cannot modulo number (7) by: number (0)\n"


def test_backtick_raw_string():
    """Back-tick strings keep backslashes and skip interpolation."""
    res = run_fq(["-n", "-c", r'`hello \("world")🌍`'])
    assert res.returncode == 0
    # the \(...\) interpolation and the \ escapes stay as literal characters
    # (JSON escaped when printed), only the raw UTF-8 emoji passes through
    assert res.stdout.decode() == '"hello \\\\(\\"world\\")🌍"\n'


def test_backtick_vs_quoted_string():
    """Back-tick string compared to an interpolated double quoted string."""
    res = run_fq(["-n", "-c", r'[`a\nb`, "a\nb", `tab\there`, "tab\there"]'])
    assert res.returncode == 0
    # raw string keeps the two characters backslash+n, the quoted one a newline
    assert res.stdout.decode() == '["a\\\\nb","a\\nb","tab\\\\there","tab\\there"]\n'


def test_string_interpolation_of_expression():
    """String interpolation still evaluates the embedded expression."""
    res = run_fq(["-n", "-c", r'"1+2=\(1+2) and 0x10=\(0x10)"'])
    assert res.returncode == 0
    assert res.stdout.decode() == '"1+2=3 and 0x10=16"\n'
