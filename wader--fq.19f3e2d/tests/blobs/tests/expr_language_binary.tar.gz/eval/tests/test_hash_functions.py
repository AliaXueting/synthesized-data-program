"""Hash functions to_md4/to_md5/to_sha1/to_sha*/to_sha3_* on fq values.

CATCHES: the hash functions accept strings, binaries, numbers and arrays,
hash the exact bit range of bit-sliced inputs, and return a binary digest
(not a hex string).
"""
from __future__ import annotations

from conftest import run_fq


def _json_array(items):
    """Compact jq array output of a list of JSON-encodable values."""
    return "[" + ",".join(str(i) for i in items) + "]\n"


def test_all_hash_algorithms():
    """Every exposed hash function of the string "test" as hex."""
    res = run_fq(
        [
            "-n",
            "-c",
            '"test" | [to_md4, to_md5, to_sha1, to_sha256, to_sha512, '
            "to_sha3_224, to_sha3_256, to_sha3_384, to_sha3_512] | map(to_hex)",
        ]
    )
    assert res.returncode == 0
    expected = [
        "db346d691d7acc4dc2625db19f9e3f52",
        "098f6bcd4621d373cade4e832627b4f6",
        "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3",
        "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",
        "ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db2"
        "7ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff",
        "3797bf0afbbfca4a7bbba7602a2b552746876517a7f9b7ce2db0ae7b",
        "36f028580bb02cc8272a9a020f4200e346e276ae664e45ee80745574e2f5ab80",
        "e516dabb23b6e30026863543282780a3ae0dccf05551cf0295178d7ff0f1b41e"
        "ecb9db3ff219007c4e097260d58621bd",
        "9ece086e9bac491fac5c1d1046ca11d737b92a2b2ebd93f005d7b710110c0a67"
        "8288166e7fbe796883a4f2e9b3ca9f484f521d0ce464345cc1aec96779149c14",
    ]
    assert res.stdout.decode() == _json_array([f'"{h}"' for h in expected])


def test_hash_input_value_types():
    """Hashing works on strings, arrays and big integers alike."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("" | to_md5), ("abc" | to_md5), ([1,2,3] | to_md5), '
            "(100000000000000000000 | to_md5)] | map(to_hex)",
        ]
    )
    assert res.returncode == 0
    # the empty string, the byte array 01 02 03 and a 21-digit integer
    # (hashed as its 9 big-endian bytes) all produce their exact digests
    expected = [
        "d41d8cd98f00b204e9800998ecf8427e",
        "900150983cd24fb0d6963f7d28e17f72",
        "5289df737df57326fcdd22597afb1fac",
        "1b9dc5aadd0c68970a7424fbd0ff4eaf",
    ]
    assert res.stdout.decode() == _json_array([f'"{h}"' for h in expected])


def test_hash_of_bit_sliced_binaries():
    """Hashing a sliced binary hashes exactly the sliced bits."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[(0xf08|tobits|.[4:12]), ("ab"|tobytes|.[1:2]), '
            '(("abc"|tobytes)|.bits[4:20]), (0xf08|tobits|.[:4])] | map(to_md5 | to_hex)',
        ]
    )
    assert res.returncode == 0
    # 0xf08|tobits is 16 bits; [4:12] hashes the middle byte 0xf0 while [:4]
    # hashes the 4 zero pad bits, giving different digests
    expected = [
        "e2ba905bf306f46faca223d3cb20e2cf",
        "92eb5ffee6ae2fec3ad71c777531578f",
        "a8d5999e5d9639ff1b587e7e4b288299",
        "8c493a43d8c1ef798860bb02b62e8e79",
    ]
    assert res.stdout.decode() == _json_array([f'"{h}"' for h in expected])


def test_hash_digest_is_a_binary_value():
    """A digest behaves like any other binary value."""
    res = run_fq(
        ["-n", "-c", '"test" | to_md5 | [length, explode, tovalue({bits_format: "hex"})]']
    )
    assert res.returncode == 0
    # 16 bytes long, explodes to its byte values, renders as hex via tovalue
    assert res.stdout.decode() == (
        "[16,[9,143,107,205,70,33,211,115,202,222,78,131,38,39,180,246],"
        '"098f6bcd4621d373cade4e832627b4f6"]\n'
    )
