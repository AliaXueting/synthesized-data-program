"""gojqx value wrappers reached through decode values.

When fq decodes input the ROOT value is wrapped in one of internal/gojqx's
JQValue wrappers (Number/String/Array/Object/Boolean/Null) instead of being a
plain gojq value, and raw bit fields inside real decoders become Lazy string
values while structs/arrays become Base-backed decode values. These wrappers
have their own semantics: length of a number is the value itself (not the
absolute value), out-of-range string indexing returns "" (not null), keys
comes back in map order (not sorted) and the type-error messages carry no
value preview.

CATCHES: a re-implementation that reuses gojq's plain-value semantics for
decoded roots breaks on negative-number lengths, "" vs null string indexing,
unsorted keys and the value-less error wording pinned here.
"""
from __future__ import annotations

import struct

import pytest

from conftest import run_fq


def run_json(expr, stdin):
    """Run a query over stdin decoded by the json format."""
    return run_fq(["-d", "json", "-c", expr], stdin=stdin)


def jpeg_app5() -> bytes:
    """A JPEG with an APP5 segment whose raw data field is ASCII '12345'."""
    return b"\xff\xd8\xff\xe5\x00\x0712345\xff\xd9"


def tzx_bytes() -> bytes:
    """A minimal TZX file (header plus one turbo-speed data block)."""
    tzx = b"ZXTape!\x1a" + bytes([1, 0x13]) + bytes([0x11])
    tzx += struct.pack("<H", 0xABCD) + struct.pack("<H", 0x1111)
    tzx += struct.pack("<H", 0x2222) + struct.pack("<H", 0x3333)
    tzx += struct.pack("<H", 0x4444) + struct.pack("<H", 0x5555)
    tzx += bytes([0x5A]) + struct.pack("<H", 0x0777)
    tzx += bytes([3, 0, 0]) + b"ABC"
    return tzx


def test_root_number_wrapper():
    """A decoded root number keeps its sign through length and tostring."""
    res = run_json("[length, tostring, tonumber, floor]", b"3")
    assert res.returncode == 0
    assert res.stdout.decode() == '[3,"3",3,3]\n'

    # the wrapper's length is the value itself, NOT the absolute value that
    # plain jq computes (-5 | length == 5 in jq)
    res = run_json("[length, tostring, (. + 0)]", b"-5")
    assert res.returncode == 0
    assert res.stdout.decode() == '[-5,"-5",-5]\n'
    plain = run_fq(["-n", "-c", "[-5 | length]"])
    assert plain.stdout.decode() == "[5]\n"

    # out-of-int64-range roots stay big integers; length returns the value
    res = run_json("[length, type]", b"-9223372036854775809")
    assert res.returncode == 0
    assert res.stdout.decode() == '[-9223372036854775809,"number"]\n'

    # scalar wrapper errors name only the type, no value preview
    res = run_json("keys", b"3")
    assert res.returncode == 5
    assert res.stderr.decode() == "error: <stdin>: keys cannot be applied to: number\n"

    res = run_json(".[0]", b"3")
    assert res.returncode == 5
    assert res.stderr.decode() == "error: <stdin>: expected an array but got: number\n"

    res = run_json(".[]", b"3")
    assert res.returncode == 5
    assert res.stderr.decode() == "error: <stdin>: cannot iterate over: number\n"

    # unknown keys on a scalar root are null, not an error
    res = run_json(".foo", b"3")
    assert res.returncode == 0
    assert res.stdout.decode() == "null\n"


def test_root_string_wrapper():
    """A decoded root string indexes out of range to the empty string."""
    res = run_json(
        "[length, tostring, type, .[0], .[2], .[5], (.[1:3])]", b'"str"'
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '[3,"str","string","s","r","","tr"]\n'

    # negative in-range indices work; out-of-range (before/after) both give
    # "" while plain jq gives null
    res = run_json("[.[0], .[-1], .[-5], .[5], (.[1:3]), (.[-2:]), (.[0:-1])]", b'"abcd"')
    assert res.returncode == 0
    assert res.stdout.decode() == '["a","d","","","bc","cd","abc"]\n'
    plain = run_fq(["-n", "-c", '["abcd" | .[5], ("abcd" | .[-5])]'])
    assert plain.stdout.decode() == "[null,null]\n"

    # tonumber on a non-numeric root string reports the raw invalid-number
    # error, unlike nested plain strings which get gojq's tonumber wording
    res = run_json("tonumber", b'"str"')
    assert res.returncode == 5
    assert res.stderr.decode() == 'error: <stdin>: invalid number: "str"\n'
    res = run_json('.s | tonumber', b'{"s":"abc"}')
    assert res.returncode == 5
    assert res.stderr.decode().endswith(
        'error: <stdin>: tonumber cannot be applied to "abc": invalid number\n'
    )

    for expr, err in [
        ("keys", "keys cannot be applied to: string\n"),
        ("has(0)", "has cannot be applied to: string\n"),
        (".[]", "cannot iterate over: string\n"),
    ]:
        res = run_json(expr, b'"str"')
        assert res.returncode == 5
        assert res.stderr.decode() == "error: <stdin>: " + err


def test_root_array_wrapper():
    """A decoded root array supports indexing/slicing/has with wrapper errors."""
    res = run_json(
        "[length, keys, has(0), .[1], .[-1], (.[0:1]), (.[1:]), [.[]]]", b"[10,20]"
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "[2,[0,1],true,20,20,[10],[20],[10,20]]\n"

    # has with a non-int key is the wrapper's HasKeyTypeError wording
    res = run_json('has("x")', b"[10,20]")
    assert res.returncode == 5
    assert res.stderr.decode() == (
        "error: <stdin>: cannot check whether array has a key: x\n"
    )

    # unknown keys are null
    res = run_json(".foo", b"[10,20]")
    assert res.returncode == 0
    assert res.stdout.decode() == "null\n"


def test_root_object_wrapper():
    """A decoded root object iterates and stringifies with sorted keys."""
    res = run_json("[length, has(\"a\"), .a, .z, .[]]", b'{"a":1}')
    assert res.returncode == 0
    assert res.stdout.decode() == "[1,true,1,null,1]\n"

    # tostring of the wrapper is compact JSON with keys sorted by the encoder
    res = run_json("tostring", b'{"z":1,"a":2,"m":3,"b":4}')
    assert res.returncode == 0
    assert res.stdout.decode() == '"{\\"a\\":2,\\"b\\":4,\\"m\\":3,\\"z\\":1}"\n'

    # keys of the wrapper comes back in Go map iteration order, so only the
    # sorted view is stable (plain jq always sorts keys)
    res = run_json("keys | sort", b'{"z":1,"a":2,"m":3,"b":4}')
    assert res.returncode == 0
    assert res.stdout.decode() == '["a","b","m","z"]\n'

    res = run_json("has(0)", b'{"a":1}')
    assert res.returncode == 5
    assert res.stderr.decode() == (
        "error: <stdin>: cannot check whether object has a key: 0\n"
    )

    res = run_json(".[0]", b'{"a":1}')
    assert res.returncode == 5
    assert res.stderr.decode() == (
        "error: <stdin>: expected an array but got: object\n"
    )


def test_root_null_and_boolean_wrappers():
    """Decoded null and boolean roots stringify as their JSON spellings."""
    res = run_json("[length, tostring, type, tojson]", b"null")
    assert res.returncode == 0
    assert res.stdout.decode() == '[0,"null","null","null"]\n'

    res = run_json(".foo", b"null")
    assert res.returncode == 0
    assert res.stdout.decode() == "null\n"

    res = run_json("keys", b"null")
    assert res.returncode == 5
    assert res.stderr.decode() == "error: <stdin>: keys cannot be applied to: null\n"

    res = run_json("[tostring, type]", b"true")
    assert res.returncode == 0
    assert res.stdout.decode() == '["true","boolean"]\n'

    res = run_json("tostring", b"false")
    assert res.returncode == 0
    assert res.stdout.decode() == '"false"\n'

    res = run_json("length", b"true")
    assert res.returncode == 5
    assert res.stderr.decode() == (
        "error: <stdin>: length cannot be applied to: boolean\n"
    )

    res = run_json(".[]", b"true")
    assert res.returncode == 5
    assert res.stderr.decode() == "error: <stdin>: cannot iterate over: boolean\n"


def test_wrapper_errors_omit_value_preview():
    """Wrapper type errors carry no value; nested plain values include it."""
    wrapped = run_json("keys", b"3")
    plain = run_json(".n | keys", b'{"n":3}')
    assert wrapped.returncode == 5
    assert plain.returncode == 5
    assert wrapped.stderr.decode() == (
        "error: <stdin>: keys cannot be applied to: number\n"
    )
    # the nested value is a plain gojq number, so gojq's own wording (with
    # the value preview) applies to it
    assert plain.stderr.decode() == (
        "error: <stdin>: keys cannot be applied to: number (3)\n"
    )


def test_lazy_raw_bit_fields(tmp_path):
    """Raw decoder fields are lazy strings resolved on first use."""
    jpg = tmp_path / "app5.jpg"
    jpg.write_bytes(jpeg_app5())
    res = run_fq(
        [
            "-d",
            "jpeg",
            "-c",
            "[.segments[1].data | (length, tostring, tonumber, type, "
            "(.[0]), (.[0:2]), (.[1:]), tovalue)]",
            str(jpg),
        ]
    )
    assert res.returncode == 0
    # the raw 5 data bytes resolve to a string value: tonumber parses them
    assert res.stdout.decode() == '[5,"12345",12345,"string","1","12","2345","12345"]\n'

    # gojq string builtins see the resolved plain string
    res = run_fq(
        [
            "-d",
            "jpeg",
            "-c",
            "[.segments[1].data | (explode, ltrimstr(\"1\"), tojson)]",
            str(jpg),
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '[[49,50,51,52,53],"2345","\\"12345\\""]\n'

    # the lazy scalar shortcuts report only the type (hard-coded "string"),
    # never the value; add resolves the value first so it does show it
    for expr, err in [
        ("keys", "keys cannot be applied to: string\n"),
        ("has(0)", "has cannot be applied to: string\n"),
        (".[]", "cannot iterate over: string\n"),
    ]:
        res = run_fq(["-d", "jpeg", "-c", f".segments[1].data | {expr}", str(jpg)])
        assert res.returncode == 5
        assert res.stderr.decode() == f"error: {jpg}: {err}"

    res = run_fq(["-d", "jpeg", "-c", ".segments[1].data | add", str(jpg)])
    assert res.returncode == 5
    assert res.stderr.decode() == (
        'error: %s: add cannot be applied to: string ("12345")\n' % jpg
    )

    # key access on the lazy scalar is null, not an error
    res = run_fq(["-d", "jpeg", "-c", ".segments[1].data.foo", str(jpg)])
    assert res.returncode == 0
    assert res.stdout.decode() == "null\n"


def test_struct_and_array_decode_values(tmp_path):
    """Struct/array decode values expose fields, keys, has and Base errors."""
    tzx = tmp_path / "min.tzx"
    tzx.write_bytes(tzx_bytes())
    res = run_fq(
        [
            "-d",
            "tzx",
            "-c",
            "[(.blocks | length), (.blocks[0] | length), (.blocks[0] | keys), "
            "(.blocks[1]), (.blocks[0:1] | length), .nope, "
            "(.blocks[0].turbo_speed_data | length)]",
            str(tzx),
        ]
    )
    assert res.returncode == 0
    # the block struct has one field; out-of-range index is null; unknown
    # keys on the root struct are null; the turbo struct has 11 fields
    assert res.stdout.decode() == '[1,1,["turbo_speed_data"],null,1,null,11]\n'

    res = run_fq(
        ["-d", "tzx", "-c", '.blocks[0].turbo_speed_data | [has("pilot_pulse"), has("nope")]', str(tzx)]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "[true,false]\n"

    # has with the wrong key type goes through the Base wrapper errors
    res = run_fq(["-d", "tzx", "-c", ".blocks[0] | has(0)", str(tzx)])
    assert res.returncode == 5
    assert res.stderr.decode() == (
        f"error: {tzx}: cannot check whether object has a key: 0\n"
    )

    res = run_fq(["-d", "tzx", "-c", '.blocks | has("x")', str(tzx)])
    assert res.returncode == 5
    assert res.stderr.decode() == (
        f"error: {tzx}: cannot check whether array has a key: x\n"
    )

    res = run_fq(["-d", "tzx", "-c", ".blocks | has(0)", str(tzx)])
    assert res.returncode == 0
    assert res.stdout.decode() == "true\n"


def test_jsonl_lines_normalize_to_array():
    """jsonl collects each line's value into one root array."""
    res = run_fq(["-d", "jsonl", "-c", "."], stdin=b'{"a":1,"z":2}\n{"a":3}\n')
    assert res.returncode == 0
    assert res.stdout.decode() == '[{"a":1,"z":2},{"a":3}]\n'

    # a single line still produces a one-element array
    res = run_fq(["-d", "jsonl", "-c", "length"], stdin=b'{"a":1}')
    assert res.returncode == 0
    assert res.stdout.decode() == "1\n"

    # blank lines between values are skipped
    res = run_fq(["-d", "jsonl", "-c", "length"], stdin=b'{"a":1}\n\n{"b":2}\n')
    assert res.returncode == 0
    assert res.stdout.decode() == "2\n"

    # values keep their types and arbitrary precision through normalization
    res = run_fq(["-d", "jsonl", "-c", "[.[] | type]"], stdin=b'{"a":1}\n5\n"str"\n')
    assert res.returncode == 0
    assert res.stdout.decode() == '["object","number","string"]\n'

    res = run_fq(["-d", "jsonl", "-c", "[.[] | tostring]"], stdin=b"1.5\n123456789012345678901234567890\n")
    assert res.returncode == 0
    assert res.stdout.decode() == '["1.5","123456789012345678901234567890"]\n'

    res = run_fq(["-d", "jsonl", "-c", "[.[] | (. + 1)]"], stdin=b"1\n2\n3\n")
    assert res.returncode == 0
    assert res.stdout.decode() == "[2,3,4]\n"


def test_jsonl_decode_errors_are_gap_values():
    """Undecodable jsonl input yields a gap value, not a failed run."""
    res = run_fq(["-d", "jsonl", "-c", "tovalue"], stdin=b"x\n")
    assert res.returncode == 0
    assert res.stdout.decode() == '{"gap0":"x\\n"}\n'

    # only blank lines: the whole input becomes one gap
    res = run_fq(["-d", "jsonl", "-c", "tovalue"], stdin=b"\n\n")
    assert res.returncode == 0
    assert res.stdout.decode() == '{"gap0":"\\n\\n"}\n'

    # a whitespace-only line is a gap too
    res = run_fq(["-d", "jsonl", "-c", "tovalue"], stdin=b" \n")
    assert res.returncode == 0
    assert res.stdout.decode() == '{"gap0":" \\n"}\n'


def test_null_input_casts_to_empty_array_functions():
    """null casts to an empty array/struct for array-typed native functions."""
    # to_jsonl/to_csv take []any; null becomes a nil slice and encodes to ""
    res = run_fq(["-n", "-c", "null | to_jsonl"])
    assert res.returncode == 0
    assert res.stdout.decode() == '""\n'

    res = run_fq(["-n", "-c", "null | to_csv"])
    assert res.returncode == 0
    assert res.stdout.decode() == '""\n'

    res = run_fq(["-n", "-c", '[1,"a"] | to_jsonl'])
    assert res.returncode == 0
    assert res.stdout.decode() == '"1\\n\\"a\\"\\n"\n'

    # non-array input is rejected with the gojq type preview
    res = run_fq(["-n", "-c", '{"a":1} | to_jsonl'])
    assert res.returncode == 5
    assert res.stderr.decode() == (
        'error: to_jsonl cannot be applied to: object ({"a":1})\n'
    )
