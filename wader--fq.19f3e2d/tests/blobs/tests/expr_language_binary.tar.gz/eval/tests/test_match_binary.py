"""Regex functions (test/match/capture/scan/split/splits) on binary values.

CATCHES: a re-implementation that only forwards binaries to the string regex
functions would lose byte offsets, the b flag byte-as-codepoint mode and
binary patterns given as byte arrays.
"""
from __future__ import annotations

from conftest import run_fq

HEX = 'tovalue({bits_format: "hex"})'


def test_match_global_offsets_on_binary():
    """Global match reports byte offsets and binary capture strings."""
    res = run_fq(
        ["-n", "-c", f'"a1b2c3" | tobytes | [match("[0-9]"; "g") | [.offset, (.string|{HEX})]]']
    )
    assert res.returncode == 0
    # offsets are byte positions into the binary, string fields are binaries
    assert res.stdout.decode() == '[[1,"31"],[3,"32"],[5,"33"]]\n'


def test_match_named_captures_and_capture():
    """Named capture groups appear in .captures and feed capture/1."""
    res = run_fq(
        [
            "-n",
            "-c",
            '("a-b"|tobytes) as $b | [[$b | match("(?<l>a)-(?<r>b)") | .captures], '
            '[$b | capture("(?<l>a)-(?<r>b)")]]',
        ]
    )
    assert res.returncode == 0
    # capture offsets are byte offsets; capture() only keeps named groups
    assert res.stdout.decode() == (
        '[[[{"length":1,"name":"l","offset":0,"string":"a"},'
        '{"length":1,"name":"r","offset":2,"string":"b"}]],[{"l":"a","r":"b"}]]\n'
    )


def test_match_byte_mode():
    """The b flag and byte-array patterns match raw bytes as code points."""
    # "aöaöa" as bytes contains the UTF-8 bytes of ö (0xc3 0xb6); in b mode
    # each byte is one code point, so a one-byte pattern matches a single byte
    cases = [
        ('"aöaöa" | tobytes | match("ö")',
         '{"captures":[],"length":2,"offset":1,"string":"ö"}\n'),
        ('"aöaöa" | tobytes | match("Ã"; "b")',
         '{"captures":[],"length":1,"offset":1,"string":"\\ufffd"}\n'),
        ('"aöaöa" | tobytes | match([0xc3])',
         '{"captures":[],"length":1,"offset":1,"string":"\\ufffd"}\n'),
        ('"64ff65ff66" | fromhex | match("ÿ"; "b")',
         '{"captures":[],"length":1,"offset":1,"string":"\\ufffd"}\n'),
    ]
    for expr, expected in cases:
        res = run_fq(["-n", "-c", expr])
        assert res.returncode == 0
        assert res.stdout.decode() == expected


def test_split_splits_scan_on_binary():
    """split/splits/scan work on binaries and return binary pieces."""
    res = run_fq(
        [
            "-n",
            "-c",
            f'("hello"|tobytes) as $b | [ [$b | split("l") | length], '
            f'[$b | splits("l") | length], [$b | scan("[lo]") | {HEX}] ]',
        ]
    )
    assert res.returncode == 0
    # split("l") of "hello" gives ["he","","o"], splits streams the same three
    # pieces, scan returns each match as a binary
    assert res.stdout.decode() == '[[3],[2,0,1],["6c","6c","6f"]]\n'


def test_test_on_binary_and_bits_unit():
    """test works on byte and bit unit binaries; empty global match is odd."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("abc"|tobits|test("b")), (["abba"|tobytes|match("";"g")]|length), '
            '("abc"|tobytes|test("z")), ("abc"|tobytes|test("B";"i"))]',
        ]
    )
    assert res.returncode == 0
    # a bits-unit binary is matched via its bytes, and an empty global pattern
    # produces a single match on a binary (strings would produce one per
    # position)
    assert res.stdout.decode() == "[true,1,false,true]\n"


def test_invalid_regex_on_binary():
    """An invalid regular expression is a runtime error, not a parse error."""
    res = run_fq(["-n", "-c", '"abc" | tobytes | match("[")'])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == (
        'error: invalid regular expression "[": error parsing regexp: missing closing ]: `[`\n'
    )


def test_grep_vgrep_bgrep():
    """grep/vgrep/bgrep recursively search values and binaries."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[[{a:{b:"xy"}} | grep("xy")], [{a:1,b:[2]} | vgrep(2)], '
            f'[[("abc"|tobytes), "xy"] | grep("b") | {HEX}], '
            f'[("abc"|tobytes) | bgrep("b") | {HEX}]]',
        ]
    )
    assert res.returncode == 0
    # grep matches nested strings and binary contents, vgrep compares values,
    # bgrep only matches binary contents
    assert res.stdout.decode() == '[["xy"],[2],["616263"],["616263"]]\n'
