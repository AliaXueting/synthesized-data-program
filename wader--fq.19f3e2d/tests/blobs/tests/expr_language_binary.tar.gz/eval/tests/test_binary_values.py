"""Binary values: tobits/tobytes construction, slicing, keys and display.

CATCHES: without the fq binary value type a re-implementation would lose
iolist construction, bit/byte unit indexing, the bits/bytes pseudo keys and
the exact error messages for bad byte values.
"""
from __future__ import annotations

import pytest

from conftest import run_fq

HEX = 'tovalue({bits_format: "hex"})'


def test_tobits_tobytes_construction():
    """tobits/tobytes build binaries from strings, iolists and numbers."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("12"|tobytes), ([0,[123,255],"abc"]|tobytes), (0xff|tobytes), '
            '(0x1ff|tobytes), (-1|tobytes), (256|tobytes), (0xf08|tobits)] '
            f"| map({HEX})",
        ]
    )
    assert res.returncode == 0
    # numbers become big-endian bytes of their bit length: 0x1ff needs 9 bits
    # so it pads to two bytes, -1 uses the magnitude (one byte 0x01), and
    # 0xf08|tobits keeps the 4 pad-before bits (16 bits total -> f080)
    assert res.stdout.decode() == '["3132","007bff616263","ff","01ff","01","0100","f080"]\n'


def test_tobytes_pad_argument():
    """The $pad argument zero-pads on the left to N units."""
    res = run_fq(
        [
            "-n",
            "-c",
            f"[(0xff|tobytes(2)), (0xf|tobits(8)), (0xf|tobits(2)), (0xf08|tobytes(2))] | map({HEX})",
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["00ff","0f","f0","0f08"]\n'


def test_binary_indexing():
    """Indexing a binary reads byte/bit units; out of range gives null."""
    res = run_fq(["-n", "-c", '"abc" | tobytes | [.[1], .[-1], .[10], (.bits|.[-1]), (.bits|.[100])]'])
    assert res.returncode == 0
    # negative indices count from the end, .bits indexes single bits
    assert res.stdout.decode() == "[98,99,null,1,null]\n"


def test_binary_slicing():
    """Slicing works in the binary's unit; .bits switches to bit units."""
    res = run_fq(
        ["-n", "-c", f'"abc" | tobytes | [.[1:3], .[-2:], .bits[4:12], .bits[-4:]] | map({HEX})']
    )
    assert res.returncode == 0
    # .bits[4:12] of "abc" cuts inside the 'a' byte, hex right-pads the last
    # partial byte so the 4 low bits of 0x61 print as "1" -> "16"
    assert res.stdout.decode() == '["6263","6263","16","30"]\n'


def test_binary_slice_clamping_and_metadata():
    """Slices clamp to the binary and the pseudo keys expose size/unit."""
    res = run_fq(
        [
            "-n",
            "-c",
            '"abc" | tobytes | [(.[0:0]|length), (.[0:100]|length), (.[2:1]|length), '
            "(.bits|length), (.bytes|length), (.bits|.unit), .unit, .size, .start, .stop]",
        ]
    )
    assert res.returncode == 0
    # .[0:100] clamps to 3 bytes, reversed ranges give an empty binary, and
    # .bits/.bytes re-view the same bits with unit 1/8
    assert res.stdout.decode() == "[0,3,0,24,3,1,8,3,0,3]\n"


def test_tobytesrange_keeps_absolute_position():
    """tobytesrange keeps the source range, tobytes re-bases it to zero."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("abcdef"|tobytes|.[1:]|tobytes|.start), ("abcdef"|tobytes|.[1:]|tobytesrange|.start), '
            '("abcdef"|tobytes|.[1:]|tobytesrange|.stop), ("abcdef"|tobytes|.bits[8:16]|tobytesrange|.start)]',
        ]
    )
    assert res.returncode == 0
    # after slicing byte 1.., tobytes reports start 0 while tobytesrange
    # remembers the absolute byte/bit position in the original binary
    assert res.stdout.decode() == "[0,1,6,1]\n"


def test_binary_conversions():
    """length/explode/tonumber/tostring/type/tojson of a binary value."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[(0|tobytes|length), (0|tobits|length), '
            '("abc"|tobytes|[length, explode, tonumber, tostring, type, tojson])]',
        ]
    )
    assert res.returncode == 0
    # the number 0 is a one-bit binary (big.Int 0 has bit length 0 -> 1 bit),
    # tonumber reads the bytes as one big-endian integer, and a binary claims
    # jq type "string"
    assert res.stdout.decode() == '[1,1,[3,[97,98,99],6382179,"abc","string","\\"abc\\""]]\n'


def test_binary_equality_and_concat():
    """Binaries compare equal to each other and to their string form."""
    res = run_fq(
        [
            "-n",
            "-c",
            '("a"|tobytes) as $a | [$a == ("a"|tobytes), $a == "a", '
            '(($a + ("b"|tobytes)) | type), (($a + ("b"|tobytes)) | tobytes | '
            f"{HEX})]",
        ]
    )
    assert res.returncode == 0
    # jq's + treats binaries as string-like: concatenating two binaries
    # yields a plain string (here re-converted to a binary to see the bytes)
    assert res.stdout.decode() == '[true,true,"string","6162"]\n'


@pytest.mark.parametrize(
    "expr,err",
    [
        ("[-1] | tobytes", "error: byte in binary list must be bytes (0-255) got -1\n"),
        ("[256] | tobytes", "error: byte in binary list must be bytes (0-255) got 256\n"),
        ("[null] | tobytes", "error: value can't be a binary\n"),
        ("true | tobytes", "error: value can't be a binary\n"),
    ],
)
def test_binary_construction_errors(expr, err):
    """Out-of-range bytes and non-binary values fail with exit code 5."""
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == err


def test_bits_format_tovalue():
    """All bits_format option values render a binary differently."""
    res = run_fq(
        [
            "-n",
            "-c",
            '("abc"|tobytes) as $b | [($b|tovalue({bits_format:"hex"})), '
            '($b|tovalue({bits_format:"base64"})), ($b|tovalue({bits_format:"md5"})), '
            '($b|tovalue({bits_format:"snippet"})), ($b|tovalue({bits_format:"byte_array"})), '
            '($b|tovalue({bits_format:"string"})), ($b|tovalue({bits_format:"truncate"}))]',
        ]
    )
    assert res.returncode == 0
    assert (
        res.stdout.decode()
        == '["616263","YWJj","900150983cd24fb0d6963f7d28e17f72","<3>YWJj",[97,98,99],"abc","abc"]\n'
    )


def test_invalid_bits_format_error():
    """An unknown bits_format is a runtime error."""
    res = run_fq(["-n", "-c", '"abc" | tobytes | tovalue({bits_format: "nope"})'])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == 'error: invalid bits format "nope"\n'


def test_binary_keys_has_errors():
    """keys/has on a binary fail like they would on a string."""
    res = run_fq(["-n", "-c", '"abc" | tobytes | keys'])
    assert res.returncode == 5
    assert res.stderr.decode() == "error: keys cannot be applied to: string\n"
    res = run_fq(["-n", "-c", '"abc" | tobytes | has("x")'])
    assert res.returncode == 5
    assert res.stderr.decode() == "error: cannot check whether string has a key: x\n"


def test_raw_output_writes_bytes_without_newline():
    """Raw output of a binary writes the raw bytes and no trailing newline."""
    res = run_fq(["-n", "-r", '"hi" | tobytes'])
    assert res.returncode == 0
    # a binary prints exactly its two bytes; a plain string still gets \n
    assert res.stdout == b"hi"
    res = run_fq(["-n", "-r", '"hi"'])
    assert res.returncode == 0
    assert res.stdout == b"hi\n"


def test_open_reads_file(tmp_path):
    """open reads a file relative to the working directory as a binary."""
    (tmp_path / "f.txt").write_bytes(b"hello")
    res = run_fq(
        ["-n", "-c", '"f.txt" | open | [tovalue({bits_format: "hex"}), length, .name]'],
        cwd=tmp_path,
    )
    assert res.returncode == 0
    # .name exposes the underlying file name of an opened file
    assert res.stdout.decode() == '["68656c6c6f",5,"f.txt"]\n'


def test_open_reads_stdin():
    """open with a null argument reads standard input."""
    res = run_fq(["-n", "-c", 'null | open | tovalue({bits_format: "hex"})'], stdin=b"AB")
    assert res.returncode == 0
    assert res.stdout.decode() == '"4142"\n'
    res = run_fq(["-n", "-c", "null | open | length"], stdin=b"")
    assert res.returncode == 0
    assert res.stdout.decode() == "0\n"


def test_open_missing_file_error():
    """Opening a missing file reports the bare OS error with exit code 5."""
    res = run_fq(["-n", "-c", '"missing.txt" | open'])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == "error: no such file or directory\n"
