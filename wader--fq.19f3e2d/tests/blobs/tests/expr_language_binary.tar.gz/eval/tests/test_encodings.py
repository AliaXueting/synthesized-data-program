"""Hex, base64 and string-encoding conversions (format/text/encoding.go).

CATCHES: the base64 variants follow Go's encoding/base64 alphabets exactly
(std requires padding, url swaps +/ for -_, raw* drop padding), the UTF-16
encoder always emits an LE BOM while the decoder sniffs it, and invalid UTF-8
decodes to U+FFFD instead of erroring.
"""
from __future__ import annotations

import pytest

from conftest import run_fq


def test_from_hex_decodes_to_binary():
    """from_hex accepts upper and lower case and yields a byte binary."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("ff00aa" | from_hex | to_hex), ("FF00AA" | from_hex | to_hex), '
            '("deadbeef" | from_hex | length), ("ff" | from_hex | .[0]), '
            '("" | from_hex | to_hex)]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["ff00aa","ff00aa",4,255,""]\n'


@pytest.mark.parametrize(
    "expr, expected_err",
    [
        ('"abc" | from_hex', "error: encoding/hex: odd length hex string\n"),
        ('"zz" | from_hex', "error: encoding/hex: invalid byte: U+007A 'z'\n"),
        ("null | to_hex", "error: value can't be a binary\n"),
        ("{} | to_hex", "error: value can't be a binary\n"),
    ],
)
def test_hex_conversion_errors(expr, expected_err):
    """Bad hex input and unconvertible to_hex inputs are runtime errors.

    CATCHES: Go's hex error strings (with the U+XXXX rune quoting) surface
    unchanged, and to_hex only accepts values convertible to a bit reader.
    """
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stderr.decode() == expected_err


def test_to_hex_accepts_strings_numbers_arrays():
    """to_hex converts any binary-convertible value, numbers left-aligned.

    CATCHES: a number becomes its minimal-bit-length big-endian bits, so
    0x0102 (9 bits) hexes to 8100 (not 0102), -1 contributes one bit (80),
    and 1.5 truncates to 1 (also 80).
    """
    res = run_fq(
        [
            "-n",
            "-c",
            '[("abc" | to_hex), (255 | to_hex), (0x0102 | to_hex), (0x1ff | to_hex), '
            "(0xf08 | to_hex), (-1 | to_hex), (1.5 | to_hex), ([1,2,255] | to_hex), "
            '("" | to_hex)]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["616263","ff","8100","ff80","f080","80","80","0102ff",""]\n'


def test_to_base64_padding_table():
    """to_base64 pads to 4-char groups; empty input stays empty."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("hello" | tobytes | to_base64), ("he" | tobytes | to_base64), '
            '("h" | tobytes | to_base64), ("" | tobytes | to_base64), '
            "(0x00ff | tobytes | to_base64)]",
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["aGVsbG8=","aGU=","aA==","","/w=="]\n'


def test_base64_encoding_alphabets():
    """url/rawstd/rawurl variants on encode and decode.

    CATCHES: url keeps "=" padding but decodes - and _; rawstd/rawurl drop
    the padding on encode but still decode padded input; "+/==" only decodes
    with the std alphabet.
    """
    res = run_fq(
        [
            "-n",
            "-c",
            '[("hello" | tobytes | to_base64({encoding:"url"})), '
            '("hello" | tobytes | to_base64({encoding:"rawstd"})), '
            '("hello" | tobytes | to_base64({encoding:"rawurl"})), '
            '("aGVsbG8" | from_base64({encoding:"rawstd"}) | to_hex), '
            '("aGVsbG8-" | from_base64({encoding:"url"}) | to_hex), '
            '("aGVsbG8-" | from_base64({encoding:"rawurl"}) | to_hex), '
            '("+/==" | from_base64 | to_hex), '
            '("-___" | from_base64({encoding:"rawurl"}) | to_hex), '
            '("ff7f00ff" | from_hex | to_base64), '
            '("ff7f00ff" | from_hex | to_base64({encoding:"url"}))]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == (
        '["aGVsbG8=","aGVsbG8","aGVsbG8","68656c6c6f","68656c6c6f3e",'
        '"68656c6c6f3e","fb","fbffff","/38A/w==","_38A_w=="]\n'
    )


@pytest.mark.parametrize(
    "expr, expected_err",
    [
        ('"aGVsbG8" | from_base64', "error: illegal base64 data at input byte 4\n"),
        ('"aGVsbG8!" | from_base64', "error: illegal base64 data at input byte 7\n"),
    ],
)
def test_from_base64_errors(expr, expected_err):
    """Std base64 rejects missing padding and illegal characters.

    CATCHES: the byte offset in the error points at the first bad position
    (4 = where the missing padding should be, 7 = the '!').
    """
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stderr.decode() == expected_err


def test_from_base64_unknown_encoding_falls_back():
    """An unknown encoding name silently falls back to standard base64."""
    res = run_fq(['-n', '-c', '"aGVsbG8=" | from_base64({encoding:"zzz"}) | to_hex'])
    assert res.returncode == 0
    assert res.stdout.decode() == '"68656c6c6f"\n'


def test_utf16_bom_handling():
    """to_utf16 emits an LE BOM; from_utf16 sniffs the BOM endianness."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("abc" | to_utf16 | to_hex), ("abc" | to_utf16le | to_hex), '
            '("abc" | to_utf16be | to_hex), ("é" | to_utf16le | to_hex), '
            '("é" | to_utf16be | to_hex), ("fffe6100" | from_hex | from_utf16), '
            '("feff0061" | from_hex | from_utf16), ("feff6100" | from_hex | from_utf16), '
            '("61006200" | from_hex | from_utf16le), ("00610062" | from_hex | from_utf16be)]',
        ]
    )
    assert res.returncode == 0
    # BOM fffe means LE and is consumed by from_utf16; without a BOM the
    # explicit le/be decoders read the units in fixed order
    assert res.stdout.decode() == (
        '["fffe610062006300","610062006300","006100620063","e900","00e9",'
        '"a","a","愀","ab","ab"]\n'
    )


def test_utf16_partial_input():
    """A lone BOM decodes to empty; odd trailing bytes become U+FFFD."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("fffe" | from_hex | from_utf16), ("61" | from_hex | from_utf16le), '
            '("61" | from_hex | from_utf16be)]',
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["","\ufffd","\ufffd"]\n'


def test_utf8_and_iso8859_1():
    """UTF-8 and ISO-8859-1 encode/decode roundtrips and array input."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("åäö" | to_utf8 | to_hex), ("åäö" | to_iso8859_1 | to_hex), '
            '("é" | to_utf8 | to_hex), ("é" | to_iso8859_1 | to_hex), '
            "([97,98,99] | from_iso8859_1), ([97,0,98,0,99,0] | from_utf16le), "
            '("c3a9" | from_hex | from_utf8), ("e9" | from_hex | from_iso8859_1), '
            '("ff" | from_hex | from_utf8)]',
        ]
    )
    assert res.returncode == 0
    # åäö are two UTF-8 bytes each but one Latin-1 byte each; byte arrays
    # feed the decoders as binaries; a lone 0xff is invalid UTF-8
    assert res.stdout.decode() == (
        '["c3a5c3a4c3b6","e5e4f6","c3a9","e9","abc","abc","é","é","\ufffd"]\n'
    )


def test_strencoding_charmaps():
    """The charmap encodings are reachable via _to/_from_strencoding."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[("П" | _to_strencoding({encoding:"KOI8R"}) | to_hex), '
            '("П" | _to_strencoding({encoding:"Windows1251"}) | to_hex), '
            '("П" | _to_strencoding({encoding:"ISO8859_5"}) | to_hex), '
            '("é" | _to_strencoding({encoding:"Windows1252"}) | to_hex), '
            '("é" | _to_strencoding({encoding:"Macintosh"}) | to_hex), '
            '("f0" | from_hex | _from_strencoding({encoding:"KOI8R"}))]',
        ]
    )
    assert res.returncode == 0
    # the same code point П maps to different bytes per code page (KOI8-R
    # f0, CP1251 cf, ISO-8859-5 bf) and decodes back
    assert res.stdout.decode() == '["f0","cf","bf","e9","8e","П"]\n'


def test_strencoding_unknown_name():
    """An unknown encoding name is a runtime error in both directions."""
    for expr in ('"abc" | _to_strencoding({encoding:"Nope9"})',
                 '"abc" | _from_strencoding({encoding:"Nope9"})'):
        res = run_fq(["-n", "-c", expr])
        assert res.returncode == 5
        assert res.stderr.decode() == "error: unknown string encoding Nope9\n"


def test_wrong_arity_is_compile_error():
    """Calling from_hex with an argument is a compile-time error, exit 3.

    CATCHES: arity problems fail before evaluation (exit code 3 with an
    "arg:" prefixed message), unlike the runtime type errors (exit 5).
    """
    res = run_fq(["-n", "-c", '"ff" | from_hex(1)'])
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr.decode() == "error: arg: function not defined: from_hex/1\n"
