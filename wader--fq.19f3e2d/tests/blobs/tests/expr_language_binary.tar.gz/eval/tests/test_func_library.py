"""fq's jq function library in pkg/interp/funcs.jq and format/math/base.jq.

CATCHES: group/streaks/count/delta/chunk/table/iprint/rpad/diff and
expr_to_path/path_to_expr are pure jq definitions a re-implementation must
reproduce exactly, including their error messages and empty-input behavior.
"""
from __future__ import annotations

import json

import pytest

from conftest import run_fq


def test_group_streaks_count():
    """group, streaks and count over arrays of values."""
    res = run_fq(
        [
            "-n",
            "-c",
            "[[1,1,2,2,2,3] | group, "
            "([1,1,2,2,2,3] | streaks), "
            "([1,1,2,2,2,3] | streaks_by(. % 2)), "
            "([1,1,2,2,2,3] | count), "
            "([1,1,2,2,2,3] | count_by(. % 2)), "
            "([] | group), "
            "([] | streaks), "
            "([] | count)]",
        ]
    )
    assert res.returncode == 0
    # streaks groups *consecutive* equal elements; count returns [value, n]
    # pairs; the modulo streaks keep the same member lists here
    assert res.stdout.decode() == (
        '[[[1,1],[2,2,2],[3]],[[1,1],[2,2,2],[3]],[[1,1],[2,2,2],[3]],'
        '[[1,2],[2,3],[3,1]],[[0,3],[1,3]],[],[],[]]\n'
    )


def test_delta_and_delta_by():
    """delta/delta_by apply f over consecutive {a, b} pairs."""
    res = run_fq(
        [
            "-n",
            "-c",
            "[[1,1,2,2,2,3] | delta, "
            "([[1,\"a\"],[2,\"b\"],[2,\"c\"],[3,\"d\"]] | delta_by(.b[0] - .a[0])), "
            "([] | delta), "
            "([5] | delta)]",
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == "[[0,1,0,0,1],[1,0,1],[],[]]\n"


def test_chunk():
    """chunk splits arrays and strings into even chunks, last one shorter."""
    res = run_fq(
        ["-n", "-c", "[[range(10)] | chunk(3), (\"abcdef\" | chunk(2)), ([] | chunk(3))]"]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '[[[0,1,2],[3,4,5],[6,7,8],[9]],["ab","cd","ef"],[]]\n'

    res = run_fq(["-n", "-c", "[range(5)] | chunk(0)"])
    assert res.returncode == 5
    # chunk(0) divides by zero inside its range computation
    assert res.stderr.decode() == "error: cannot divide number (5) by: number (0)\n"


def test_table():
    """table(colmap; render) renders each row with computed column widths."""
    res = run_fq(["-n", "-c", '[[1,"aaa"],[22,"b"]] | table(.; map(.string) | join("|"))'])
    assert res.returncode == 0
    # one output per row; the render sees {column, string, maxwidth} cells
    assert res.stdout.decode() == '"1|aaa"\n"22|b"\n'

    res = run_fq(["-n", "-c", '[] | table(.; map(.string) | join("|"))'])
    assert res.returncode == 0
    assert res.stdout.decode() == '""\n'


def test_iprint():
    """iprint prints a number in all bases plus its character."""
    res = run_fq(["-n", "-c", "65 | iprint"])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        '{"bin":"0b1000001","dec":"65","hex":"0x41","oct":"0o101","str":"A"}\n'
    )

    # a string is exploded to one iprint object per code point
    res = run_fq(["-n", "-c", '"AB" | iprint'])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        '{"bin":"0b1000001","dec":"65","hex":"0x41","oct":"0o101","str":"A"}\n'
        '{"bin":"0b1000010","dec":"66","hex":"0x42","oct":"0o102","str":"B"}\n'
    )

    # code point 0 round-trips through implode into an escaped NUL string
    res = run_fq(["-n", "-c", "0 | iprint | .str"])
    assert res.returncode == 0
    assert res.stdout.decode() == '"\\u0000"\n'

    res = run_fq(["-n", "-c", "[1] | iprint"])
    assert res.returncode == 5
    assert res.stderr.decode() == "error: expected number or string\n"


def test_rpad():
    """rpad($s; $w) right-pads the input by repeating $s."""
    res = run_fq(
        [
            "-n",
            "-c",
            '[(. | rpad("x"; 5)), (. | rpad("ab"; 5)), (. | rpad("abcdef"; 4)), '
            '("ab" | rpad("."; 3))]',
        ]
    )
    assert res.returncode == 0
    # null input has length 0 so the whole repeated string is appended after
    # dropping its first character; "ab" with width 3 only gains one "."
    assert res.stdout.decode() == '["xxxxx","bababababab","bcdefabcdefabcdefabcdefabcdef","ab."]\n'


def test_diff():
    """diff($a; $b) produces {a:...,b:...} leaves for differing values."""
    res = run_fq(
        [
            "-n",
            "-c",
            "[diff({a: 1, b: 2}; {a: 1, c: 3}), "
            "diff([1,2,3]; [1,9]), "
            "diff(1; 2), "
            "diff(\"x\"; \"y\"), "
            "diff(1; 1), "
            "diff(null; null)]",
        ]
    )
    assert res.returncode == 0
    # equal scalars and nulls produce no output at all (empty stream)
    assert res.stdout.decode() == (
        '[{"b":{"a":2},"c":{"b":3}},{"1":{"a":2,"b":9},"2":{"a":3}},'
        '{"a":1,"b":2},{"a":"x","b":"y"}]\n'
    )

    # nested objects recurse: only the differing leaves are reported
    res = run_fq(["-n", "-c", "diff({a: 1, b: {x: 1, y: 2}}; {a: 1, b: {x: 9, z: 3}})"])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        '{"b":{"x":{"a":1,"b":9},"y":{"a":2},"z":{"b":3}}}\n'
    )


@pytest.mark.parametrize(
    "expr,expected",
    [
        ('".a.b[0]" | expr_to_path', '["a","b",0]\n'),
        ('".a.b[0][1]" | expr_to_path', '["a","b",0,1]\n'),
        ('".a[0]" | expr_to_path', '["a",0]\n'),
        ('".a.b" | expr_to_path', '["a","b"]\n'),
        ('".[0]" | expr_to_path', "[0]\n"),
    ],
)
def test_expr_to_path(expr, expected):
    """expr_to_path evaluates path(<expr>) on null to build a path array."""
    res = run_fq(["-n", "-c", f"({expr})"])
    assert res.returncode == 0
    assert res.stdout.decode() == expected


def test_expr_to_path_error_messages():
    """expr_to_path error messages for bad input and bad expressions."""
    res = run_fq(["-n", "-c", "1 | expr_to_path"])
    assert res.returncode == 5
    assert res.stderr.decode() == "error: require string argument\n"

    # a bare identifier is compiled as a function call inside path()
    res = run_fq(["-n", "-c", '"a" | expr_to_path'])
    assert res.returncode == 5
    assert res.stderr.decode() == "error: function not defined: a/0\n"

    # compile errors of the inner expression surface as runtime errors
    res = run_fq(["-n", "-c", '".a..b" | expr_to_path'])
    assert res.returncode == 5
    assert res.stderr.decode() == 'error: unexpected token ".."\n'


@pytest.mark.parametrize(
    "path,expected",
    [
        ("[\"a\",\"b\",0]", '".a.b[0]"\n'),
        ("[\"x\",1,2]", '".x[1][2]"\n'),
        ("[0,1]", '".[0][1]"\n'),
        ("[]", '"."\n'),
        ("[\"a.b\"]", '".\\"a.b\\""\n'),
        ("[1.5]", '".[1.5]"\n'),
        ("[\"a\",0,\"b\",2]", '".a[0].b[2]"\n'),
        ("[\"a b\", 3]", '".\\"a b\\"[3]"\n'),
    ],
)
def test_path_to_expr(path, expected):
    """path_to_expr renders a path array as a jq expression string."""
    res = run_fq(["-n", "-c", f"({path} | path_to_expr)"])
    assert res.returncode == 0
    assert res.stdout.decode() == expected


def test_path_to_expr_quotes_special_characters():
    """Strings needing quotes are emitted as quoted jq string literals."""
    # the path element is the four characters a " b, so the expression is
    # ."a\"b" which jq re-escapes when printing the result as JSON
    res = run_fq(["-n", "-c", r'["a\"b"] | path_to_expr'])
    assert res.returncode == 0
    assert res.stdout.decode() == json.dumps(r'."a\"b"') + "\n"


# the internal quoting regex leaks into path_to_expr type errors; its
# displayed name contains five literal backslashes and no space before ";"
_REGEX_ERR_PREFIX = 'error: match("(?<g>[' + "\\" * 5 + '"])"; "g") cannot be applied to: '


@pytest.mark.parametrize(
    "path,type_repr",
    [
        ("[null]", "null"),
        ("[[]]", "array ([])"),
        ("[{}]", "object ({})"),
        ('[["nested"]]', 'array (["nested"])'),
    ],
)
def test_path_to_expr_bad_elements(path, type_repr):
    """path_to_expr only accepts string/number path elements."""
    res = run_fq(["-n", "-c", f"({path} | path_to_expr)"])
    assert res.returncode == 5
    assert res.stdout == b""
    # non-string elements reach the quoting regex whose name leaks into the
    # error message
    assert res.stderr.decode() == _REGEX_ERR_PREFIX + type_repr + "\n"


def test_path_to_expr_non_array_input():
    """path_to_expr on a non-array input fails while iterating the path."""
    res = run_fq(["-n", "-c", '("a" | path_to_expr)'])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == 'error: cannot iterate over: string ("a")\n'


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("255 | to_base(16)", '"0xff"\n'),
        ("255 | to_base(2)", '"0b11111111"\n'),
        ("10 | to_base(36)", '"a"\n'),
        ("0 | to_base(7)", '"0"\n'),
        ("0xdeadbeef | to_base(16)", '"0xdeadbeef"\n'),
        ('255 | to_base(16; "")', '"ff"\n'),
        ('9 | to_base(2; "2#"; "ab")', '"2#baab"\n'),
        ('"ff" | from_base(16)', "255\n"),
        ('"z" | from_base(36)', "35\n"),
        ('"11" | from_base(2)', "3\n"),
        ('"0xff" | from_base', "255\n"),
        ('"0b10" | from_base', "2\n"),
        ('"0o10" | from_base', "8\n"),
        ('"10" | from_base', "10\n"),
    ],
)
def test_from_base_to_base(expr, expected):
    """to_base/from_base convert between numbers and base-N digit strings."""
    res = run_fq(["-n", "-c", f"({expr})"])
    assert res.returncode == 0
    assert res.stdout.decode() == expected


def test_from_base_to_base_errors():
    """Invalid bases and digits produce specific runtime errors."""
    res = run_fq(["-n", "-c", '"Z" | from_base(36)'])
    assert res.returncode == 5
    # the base-36 table maps A-Z to 36..61, so uppercase Z is out of range
    assert res.stderr.decode() == "error: invalid character 'Z' for base 36 number\n"

    res = run_fq(["-n", "-c", '"g" | from_base(16)'])
    assert res.returncode == 5
    assert res.stderr.decode() == "error: invalid character 'g' for base 16 number\n"

    res = run_fq(["-n", "-c", "5 | to_base(0)"])
    assert res.returncode == 5
    assert res.stderr.decode() == "error: cannot modulo number (5) by: number (0)\n"

    # a negative number never enters the digit loop, only the prefix remains
    res = run_fq(["-n", "-c", "-255 | to_base(16)"])
    assert res.returncode == 0
    assert res.stdout.decode() == '"0x"\n'

    # the default digit table only covers base <= 64
    res = run_fq(["-n", "-c", "255 | to_base(65)"])
    assert res.returncode == 5
    assert res.stderr.decode() == "error: base too large\n"
