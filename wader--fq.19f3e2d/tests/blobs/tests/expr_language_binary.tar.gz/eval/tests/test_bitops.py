"""Bit operations band/bor/bxor/bsl/bsr/bnot with big.Int semantics.

CATCHES: the bit ops are big.Int aware (two's complement for negatives,
arbitrary result sizes), truncate float operands, and crash with a Go
runtime panic on negative shift amounts instead of returning an error.
"""
from __future__ import annotations

import pytest

from conftest import run_fq


def test_band_bor_bxor_table():
    """band/bor/bxor on small values, negatives and floats."""
    res = run_fq(
        [
            "-n",
            "-c",
            "[band(0xf0;0x0f), bor(0xf0;0x0f), bxor(0xff;0x0f), "
            "band(-1;0xff), bsr(-16;2), bsl(-1;8), band(1.5;1)]",
        ]
    )
    assert res.returncode == 0
    # -1 & 0xff is 255 (big two's complement), -16 >> 2 is -4 (arithmetic),
    # and the float 1.5 truncates to 1 before the operation
    assert res.stdout.decode() == "[0,255,240,255,-4,-256,1]\n"


def test_bsl_bsr_big_results():
    """Shifts produce arbitrary-precision integers."""
    res = run_fq(["-n", "-c", "[bsl(1;8), bsr(0x100;4), bsl(1;200), bsr(1;1)]"])
    assert res.returncode == 0
    # bsl(1;200) is 2^200 exactly, far beyond float64 or int64 precision
    assert res.stdout.decode() == (
        "[256,16,1606938044258990275541962092341162602522202993782792835301376,0]\n"
    )


def test_bnot():
    """bnot is a 0-arity filter implementing bitwise NOT."""
    res = run_fq(
        ["-n", "-c", "[(0xff|bnot), (0|bnot), (-1|bnot), (0xffff_ffff_ffff_ffff_ffff|bnot)]"]
    )
    assert res.returncode == 0
    # bnot of a big int is -(n+1) in two's complement, e.g. 2^80-1 -> -(2^80)
    assert res.stdout.decode() == "[-256,-1,0,-1208925819614629174706176]\n"


@pytest.mark.parametrize("expr", ["bsl(2; -2)", "bsr(2; -2)"])
def test_negative_shift_panics(expr):
    """A negative shift amount crashes the interpreter with a Go panic."""
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 2
    assert res.stdout == b""
    # only the first line is stable; the goroutine dump has addresses in it
    assert res.stderr.splitlines()[0].decode() == "panic: runtime error: negative shift amount"


@pytest.mark.parametrize(
    "expr,err",
    [
        ("band(\"a\"; 1)", 'error: cannot band: string ("a") and number (1)\n'),
        ("\"a\" | bnot", 'error: cannot bnot: string ("a")\n'),
    ],
)
def test_bitops_type_errors(expr, err):
    """Bit ops on non-number values are runtime errors."""
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == err
