"""Edge cases of the bit operations: float operands, int overflow and errors.

CATCHES: bsl/bsr silently truncate float operands, bsl promotes to big.Int
only when the int result does not round-trip (so -1<<63 stays a negative
int while 2<<62 becomes a positive big.Int), binop type errors name both
operands, and bnot on a binary value goes through its string form.
"""
from __future__ import annotations

import pytest

from conftest import run_fq


def test_float_operands_truncate():
    """Float operands are truncated to int before every bit operation."""
    res = run_fq(
        [
            "-n",
            "-c",
            "[bsl(2.5; 3), bsr(9.9; 1), bsr(2.9; 1.9), bsl(-2.5; 2), "
            "band(-16.9; 7.9), bor(1.5; 2.5), bxor(3.9; 5.9)]",
        ]
    )
    assert res.returncode == 0
    # 2.5->2 (2<<3), 9.9->9 (9>>1), 2.9->2 (2>>1), -2.5->-2 (-2<<2),
    # -16&7 == 0, 1|2 == 3, 3^5 == 6
    assert res.stdout.decode() == "[16,4,1,-8,0,3,6]\n"


def test_bsl_int_overflow_promotes_to_bigint():
    """bsl falls back to big.Int when the shifted int does not round-trip."""
    res = run_fq(
        ["-n", "-c", "[bsl(2; 61), bsl(2; 62), bsl(2; 63), bsl(4; 62), bsl(-1; 63)]"]
    )
    assert res.returncode == 0
    # 2<<61 still fits in int64; 2<<62, 2<<63 and 4<<62 overflow into big.Int;
    # -1<<63 is min int64 and (-1<<63)>>63 == -1 so it stays a negative int
    assert res.stdout.decode() == (
        "[4611686018427387904,9223372036854775808,18446744073709551616,"
        "18446744073709551616,-9223372036854775808]\n"
    )


def test_mixed_int_bigint_operands():
    """Mixing int and big.Int operands promotes the whole operation."""
    res = run_fq(
        [
            "-n",
            "-c",
            "[band(3; 0x1000000000000000000000005), "
            "bor(0x1000000000000000000000000; 5), "
            "bxor(0xffffffffffffffffffffffffff; 0xff), "
            "bsr(0x1000000000000000000000000; 44), "
            "bsl(0xffffffffffffffffffff; 4)]",
        ]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "[1,79228162514264337593543950341,20282409603651670423947251285760,"
        "4503599627370496,19342813113834066795298800]\n"
    )


@pytest.mark.parametrize(
    "expr,expected_err",
    [
        ("1.5 | bnot", "error: cannot bnot: number (1.5)\n"),
        ("null | bnot", "error: cannot bnot: null\n"),
        ("true | bnot", "error: cannot bnot: boolean (true)\n"),
        ("[] | bnot", "error: cannot bnot: array ([])\n"),
        ("{} | bnot", "error: cannot bnot: object ({})\n"),
    ],
)
def test_bnot_type_errors(expr, expected_err):
    """bnot only accepts integers; other types get a UnaryTypeError."""
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == expected_err


def test_bnot_on_binary_uses_string_form():
    """bnot on a binary recurses through JQValueToGoJQ (the raw string)."""
    res = run_fq(["-n", "-c", "0x41 | tobytes | bnot"])
    assert res.returncode == 5
    # the binary's jq representation is the raw string "A", so bnot reports
    # a string type error naming that string
    assert res.stderr.decode() == 'error: cannot bnot: string ("A")\n'

    res = run_fq(["-n", "-c", "0xff | tobits | bnot"])
    assert res.returncode == 5
    # a non-UTF-8 byte is rendered as the literal \ufffd escape in the preview
    assert res.stderr.decode() == 'error: cannot bnot: string ("\\ufffd")\n'


@pytest.mark.parametrize(
    "expr,expected_err",
    [
        ("band(null; 1)", "error: cannot band: null and number (1)\n"),
        ("bor(true; 1)", "error: cannot bor: boolean (true) and number (1)\n"),
        ("bxor([1]; 2)", "error: cannot bxor: array ([1]) and number (2)\n"),
        ("bsl({}; 1)", "error: cannot bsl: object ({}) and number (1)\n"),
        ("bsr(\"a\"; 1)", "error: cannot bsr: string (\"a\") and number (1)\n"),
        ("band(1; \"a\")", "error: cannot band: number (1) and string (\"a\")\n"),
        ("bsl(1; null)", "error: cannot bsl: number (1) and null\n"),
        ("bsr(null; null)", "error: cannot bsr: null and null\n"),
        ("bor([1]; [2])", "error: cannot bor: array ([1]) and array ([2])\n"),
        ("bxor({}; [])", "error: cannot bxor: object ({}) and array ([])\n"),
    ],
)
def test_binop_type_error_messages(expr, expected_err):
    """Every bit op reports a BinopTypeError naming both operand values."""
    res = run_fq(["-n", "-c", expr])
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == expected_err
