"""jq operations on decode values, via the minimal `json` decode format.

The json decoder is used only as a vehicle: these tests pin how fq's value
layer (internal/gojqx wrapper types) behaves when jq built-ins operate on
decode values — lengths, conversions, indexing, error messages and the
grep family — not the JSON decoding itself.

CATCHES: decode values route every jq built-in through the gojqx wrapper
types, whose tostring keeps all big.Int digits, whose string indexing
returns jq semantics, and whose type errors carry fq's exact wording.
"""
from __future__ import annotations

import pytest

from conftest import run_fq

JSON_DOC = (
    b'{"s":"abc","n":5,"f":1.5,"big":123456789012345678901234567890,'
    b'"b":true,"z":null,"a":[10,20],"o":{"k":"v"}}'
)


def run_json(expr, stdin=JSON_DOC):
    """Run a query with stdin decoded by the json format."""
    return run_fq(["-d", "json", "-c", expr], stdin=stdin)


def test_scalar_wrappers_length_and_tostring():
    """length/tostring on decode scalars via the gojqx wrappers."""
    # every piped element is parenthesised: jq's "," binds tighter than "|"
    res = run_json(
        "[(.n|length), (.f|length), (.z|length), (.a|length), (.o|length), (.s|length), "
        "(.n|tostring), (.f|tostring), (.big|tostring), (.b|tostring), (.z|tostring)]"
    )
    assert res.returncode == 0
    # length of a number is its absolute value (1.5 stays 1.5), of null 0;
    # the big integer keeps all 30 digits through tostring (colorjson path)
    assert res.stdout.decode() == (
        '[5,1.5,0,2,1,3,"5","1.5","123456789012345678901234567890","true","null"]\n'
    )


def test_decode_number_arithmetic_is_bigint():
    """Arithmetic on decode numbers stays arbitrary precision."""
    res = run_json("[.n * 2, .big + 10, .n - .big, (.big|tostring|length)]")
    assert res.returncode == 0
    assert res.stdout.decode() == (
        "[10,123456789012345678901234567900,-123456789012345678901234567885,30]\n"
    )


def test_tonumber_on_decode_strings():
    """tonumber parses decode strings, or errors with the invalid number."""
    res = run_json('[("1.5" | tonumber)]')
    assert res.returncode == 0
    assert res.stdout.decode() == "[1.5]\n"

    res = run_json('(.s | tonumber)')
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode().endswith(
        'error: <stdin>: tonumber cannot be applied to "abc": invalid number\n'
    )


def test_decode_string_indexing():
    """Decode strings support jq-style indexing and slicing."""
    res = run_json(
        "[.s[-1], .s[-4], .s[5], .s[1], (.s | .[0:2]), (.s | .[1:])]"
    )
    assert res.returncode == 0
    # negative in-range indices count from the end, out-of-range gives null
    assert res.stdout.decode() == '["c",null,null,"b","ab","bc"]\n'


@pytest.mark.parametrize(
    "expr,expected_err",
    [
        ('.a | has("x")', 'error: <stdin>: has("x") cannot be applied to: array ([10,20])\n'),
        (".o | has(1)", 'error: <stdin>: has(1) cannot be applied to: object ({"k":"v"})\n'),
        (".s | keys", 'error: <stdin>: keys cannot be applied to: string ("abc")\n'),
        (".n | keys", "error: <stdin>: keys cannot be applied to: number (5)\n"),
        (".b | length", "error: <stdin>: length cannot be applied to: boolean (true)\n"),
        (".n | .foo", "error: <stdin>: expected an object but got: number (5)\n"),
        (".o | .[0]", 'error: <stdin>: expected an array but got: object ({"k":"v"})\n'),
        (".b | tonumber", "error: <stdin>: tonumber cannot be applied to: boolean (true)\n"),
        (".z | tonumber", "error: <stdin>: tonumber cannot be applied to: null\n"),
    ],
)
def test_wrapper_type_error_messages(expr, expected_err):
    """Wrapper type errors name the function, the jq type and the value."""
    res = run_json(expr)
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr.decode() == expected_err


def test_wrapper_errors_match_plain_value_errors():
    """The wrappers reproduce jq's own error wording for plain values."""
    res = run_json(".s | keys")
    plain = run_fq(["-n", "-c", '"abc" | keys'])
    assert plain.returncode == 5
    assert plain.stderr.decode() == (
        'error: keys cannot be applied to: string ("abc")\n'
    )
    # the decode value version is byte-identical except for the <stdin>:
    # position prefix that the decode source contributes
    assert res.stderr.decode() == (
        "error: <stdin>: " + plain.stderr.decode()[len("error: "):]
    )


def test_tovalue_returns_plain_json_with_sorted_keys():
    """tovalue converts a decode value into a plain jq value."""
    res = run_fq(
        ["-d", "json", "-c", "tovalue"], stdin=b'{"z":1,"a":2,"m":3}'
    )
    assert res.returncode == 0
    # object keys come out sorted regardless of input order
    assert res.stdout.decode() == '{"a":2,"m":3,"z":1}\n'


def test_exttype_and_extkeys():
    """_exttype/_extkeys expose value internals for extension code."""
    res = run_json(
        "[(.n | _exttype), (.s | _exttype), (.a | _exttype), "
        "(.o | _exttype), (. | _exttype), (.n | _extkeys)]"
    )
    assert res.returncode == 0
    # the root is a decode_value, compound children report their jq type and
    # plain scalars have no ext keys
    assert res.stdout.decode() == '["number","string","array","object","decode_value",null]\n'

    res = run_fq(
        ["-n", "-c", "[(1 | _exttype), (\"a\" | _exttype), (null | _exttype), "
         "([1] | _exttype), ({a:1} | _exttype), (1 | _extkeys)]"]
    )
    assert res.returncode == 0
    assert res.stdout.decode() == '["number","string","null","array","object",null]\n'

    res = run_fq(["-n", "-c", "0x4142 | tobytes | [_exttype, _extkeys]"])
    assert res.returncode == 0
    # a binary value is a first-class extension with its pseudo keys
    assert res.stdout.decode() == (
        '["binary",["bits","bytes","name","size","start","stop","unit"]]\n'
    )


def test_grep_family_on_decode_values():
    """grep/vgrep/bgrep recurse into decode value trees."""
    doc = b'{"name":"hello","nums":[10,20],"sub":{"name":"world"}}'
    res = run_json('[grep("wor")]', stdin=doc)
    assert res.returncode == 0
    assert res.stdout.decode() == '["world"]\n'

    # anchors work on the whole value
    res = run_json('[grep("^wo")]', stdin=doc)
    assert res.stdout.decode() == '["world"]\n'

    # non-string patterns compare values for equality
    res = run_json("[grep(10)]", stdin=doc)
    assert res.stdout.decode() == "[10]\n"

    res = run_json('[vgrep("hello")]', stdin=doc)
    assert res.stdout.decode() == '["hello"]\n'

    res = run_json("[vgrep(10)]", stdin=doc)
    assert res.stdout.decode() == "[10]\n"

    res = run_json('[bgrep("wor")]', stdin=doc)
    assert res.stdout.decode() == '["world"]\n'


def test_fgrep_matches_decode_field_names():
    """fgrep tests the _name of decode values; json fields have none."""
    doc = b'{"name":"hello","nums":[10,20],"sub":{"name":"world"}}'
    # the json decoder produces no field names, so fgrep finds nothing
    res = run_json('[fgrep("na")]', stdin=doc)
    assert res.returncode == 0
    assert res.stdout.decode() == "[]\n"

    res = run_json('[fgrep("zzz")]', stdin=doc)
    assert res.returncode == 0
    assert res.stdout.decode() == "[]\n"


def test_formats_registry_values():
    """The formats builtin exposes the registry through gojqx.Normalize."""
    res = run_fq(["-n", "-c", "formats.bits"])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        '{"description":"Raw bits","name":"bits","probe_order":0,'
        '"root_array":false,"root_name":"","skip_decode_function":true}\n'
    )

    # decode_in_arg documents each format's default in-arg struct
    res = run_fq(["-n", "-c", "formats.csv.decode_in_arg"])
    assert res.returncode == 0
    assert res.stdout.decode() == '{"comma":",","comment":"#"}\n'

    res = run_fq(["-n", "-c", "formats.html.decode_in_arg"])
    assert res.returncode == 0
    assert res.stdout.decode() == (
        '{"array":false,"attribute_prefix":"@","seq":false}\n'
    )

    # formats without in-args have a null decode_in_arg
    res = run_fq(["-n", "-c", "formats.json.decode_in_arg"])
    assert res.returncode == 0
    assert res.stdout.decode() == "null\n"
