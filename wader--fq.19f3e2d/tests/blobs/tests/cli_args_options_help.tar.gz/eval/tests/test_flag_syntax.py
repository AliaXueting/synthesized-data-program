"""Accepted command line flag syntax forms (``pkg/interp/args.jq``).

The parser is a hand written jq implementation that understands long flags,
single letter flags, glued short flag clusters, ``--flag=VALUE`` and
``-f=VALUE``, a lone ``--`` terminator and jq-style "positional" arguments.
These tests pin which spellings are accepted and how the resulting option
values end up in the evaluated expression.
"""

from __future__ import annotations

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.


def test_short_and_long_flag_names_are_equivalent(tmp_path):
    """-c and --compact-output set the same option."""
    res_short = run_fq(["-c", "-n", '{"a":1}'])
    res_long = run_fq(["--compact-output", "-n", '{"a":1}'])
    # CATCHES: both spellings of the compact-output flag must produce the same
    # compact one-line JSON object rather than the pretty printed default.
    assert res_short.returncode == 0
    assert res_short.stdout == b'{"a":1}\n'
    assert res_long.returncode == 0
    assert res_long.stdout == b'{"a":1}\n'
    assert res_short.stderr == b""
    assert res_long.stderr == b""


def test_glued_short_flag_cluster_applies_every_letter():
    """A cluster like -Vcr applies all three flags at once."""
    res = run_fq(["-Vcr", "-n", '"a\\nb"'])
    # CATCHES: every letter of a glued short flag cluster is expanded, so -Vcr
    # means value-output + compact-output + raw-output and the string is
    # printed raw (unquoted) while still keeping the newline separator.
    assert res.returncode == 0
    assert res.stdout == b"a\nb\n"
    assert res.stderr == b""


def test_glued_cluster_reports_the_offending_letter():
    """An unknown letter inside a cluster names only that letter."""
    res = run_fq(["-rx", "-n", "1"])
    # CATCHES: when a glued cluster contains an unbound letter the diagnostic
    # names just the offending letter (-x), not the whole cluster argument.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: -x: no such argument\n"


@pytest.mark.parametrize("argv", [["-djson", "."], ["-ofoo=1", "-n", "1"]])
def test_attached_short_flag_value_is_rejected(argv):
    """-dVALUE is not a short flag with an attached value."""
    res = run_fq(argv)
    # CATCHES: unlike --flag=VALUE, a value glued directly after a single
    # letter flag is not accepted; the parser reports the letter and demands a
    # separate argument instead.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: %s: needs an argument\n" % argv[0][:2].encode()


def test_long_flag_with_equals_value(tmp_path):
    """--decode=NAME works like --decode NAME."""
    path = write_file(tmp_path, "in.json", "1\n")
    res = run_fq(["--decode=json", ".", path])
    # CATCHES: the VALUE part of --flag=VALUE is used as the flag argument, so
    # --decode=json decodes the file as json instead of looking for a file
    # named "=json".
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_short_flag_with_equals_value(tmp_path):
    """-d=NAME, -L=PATH and -o=key=value all use the text after '='."""
    libs = tmp_path / "libs"
    libs.mkdir()
    write_file(libs, "double.jq", "def double: . * 2;\n")
    res = run_fq(
        ["-L=libs", "-o=compact=true", "-n", 'include "double"; {"v": 3 | double}'],
        cwd=str(tmp_path),
    )
    # CATCHES: for single letter flags the = sign simply terminates the flag
    # name, so -L=inc adds include path "inc" (not "=inc") and -o=compact=true
    # sets the compact option.
    assert res.returncode == 0
    assert res.stdout == b'{"v":6}\n'
    assert res.stderr == b""


def test_double_dash_terminates_flag_parsing():
    """Everything after -- is treated as positional text."""
    res = run_fq(["-n", "--", "-1"])
    # CATCHES: after a lone -- the remaining arguments are never parsed as
    # flags, so "-1" becomes the EXPRESSION (and not the -1 flag).
    assert res.returncode == 0
    assert res.stdout == b"-1\n"
    assert res.stderr == b""

    res2 = run_fq(["--", "-n", "1"])
    # CATCHES: with -- first even -n is positional, so the expression is the
    # jq program "-n 1" which fails to compile as a function call.
    assert res2.returncode == 3
    assert res2.stdout == b""
    assert res2.stderr == b"error: arg: function not defined: n/0\n"


def test_negative_numbers_are_not_flags():
    """A leading '-' followed by a digit is a positional argument."""
    res = run_fq(["-n", "1", "-5"])
    # CATCHES: the flag recognizer explicitly rejects "-<digit>" so that
    # negative numbers stay positional; here "-5" becomes a FILE argument that
    # --null-input never reads instead of an unknown flag error.
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_single_dash_is_stdin_and_not_a_flag(tmp_path):
    """A lone "-" names stdin instead of a file."""
    good = write_file(tmp_path, "good.json", "2\n")
    res = run_fq([".", "-", good], stdin='"from stdin"')
    # CATCHES: "-" is not parsed as a flag nor as the expression; it is a
    # filename meaning stdin, read before the real file argument.
    assert res.returncode == 0
    assert res.stdout == b'"from stdin"\n2\n'
    assert res.stderr == b""


def test_flags_after_the_expression_are_still_parsed(tmp_path):
    """The EXPRESSION is the first positional, later ones are FILEs."""
    path = write_file(tmp_path, "in.json", '{"a":42}')
    res = run_fq([".a", "-c", path])
    # CATCHES: flag parsing does not stop at the first positional argument, so
    # -c appearing after the expression still enables compact output.
    assert res.returncode == 0
    assert res.stdout == b"42\n"
    assert res.stderr == b""


def test_help_optional_argument_consumes_next_token():
    """-h takes an optional argument and swallows the next token."""
    res = run_fq(["-h", "-v"])
    # CATCHES: --help has an optional TOPIC argument, so the following token
    # is consumed as the topic instead of being parsed as the -v flag.
    assert res.returncode == 0
    assert res.stdout == b"don't know what -v is \n"
    assert res.stderr == b""


def test_nul_output_alias(tmp_path):
    """--nul-output is an alias of --raw-output0."""
    res = run_fq(["--nul-output", "-n", '"a","b"'])
    # CATCHES: the jq compatibility alias --nul-output must behave exactly
    # like --raw-output0 and terminate every output with a NUL byte.
    assert res.returncode == 0
    assert res.stdout == b"a\x00b\x00"
    assert res.stderr == b""


def test_decode_file_alias(tmp_path):
    """--decode-file is an alias of --argdecode."""
    path = write_file(tmp_path, "in.json", "1\n")
    res = run_fq(["--decode-file", "d", path, "-n", "$d"])
    # CATCHES: the legacy --decode-file spelling must define the same $d
    # variable holding the decoded value as --argdecode does.
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_args_flag_ignores_attached_value():
    """--args=x does not error even though --args takes no value."""
    res = run_fq(["--args=x", "-n", "1"])
    # CATCHES: --args is a positional-mode switch, not a boolean flag, so an
    # attached "=x" is silently ignored instead of "takes no argument".
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_equals_form_of_a_two_argument_flag_eats_two_tokens():
    """--arg=VALUE still consumes NAME and VALUE positionally."""
    res = run_fq(["--arg=a", "-n", "$a"])
    # CATCHES: two-argument flags ignore the "=VALUE" split; --arg=a takes the
    # next two tokens ("-n", "$a") as the NAME/VALUE pair, producing an invalid
    # variable name instead of defining $a.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"error: arg: invalid variable name: $-n\n"
