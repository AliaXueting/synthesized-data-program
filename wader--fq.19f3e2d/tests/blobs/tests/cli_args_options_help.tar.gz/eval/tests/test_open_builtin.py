"""The open builtin (interp file reading through pkg/cli and interp.go).

``open`` turns a filename into a decoded binary value, or wraps the process
stdin when given null.  It is the same file opening machinery the input
pipeline uses, exposed to the expression.
"""

from __future__ import annotations

import json

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.


def test_open_of_null_reads_stdin():
    """open of null opens the standard input."""
    res = run_fq(["-c", "-n", "null | open | {name, size}"], stdin=b"hello")
    # CATCHES: stdin gets the name null (not a "stdin" string) and its size
    # is the number of bytes that were available on the pipe.
    assert res.returncode == 0
    assert res.stdout == b'{"name":null,"size":5}\n'
    assert res.stderr == b""


def test_open_of_a_filename_reads_the_file(tmp_path):
    """open of a path reads that file and keeps the path as the name."""
    path = write_file(tmp_path, "b.bin", b"world")
    res = run_fq(["--arg", "p", str(path), "-c", "-n", "$p | open | {name, size}"])
    # CATCHES: the value's name is the path exactly as it was opened with and
    # size is the file size in bytes.
    assert res.returncode == 0
    assert res.stdout == (
        '{"name":%s,"size":5}\n' % json.dumps(str(path))
    ).encode()
    assert res.stderr == b""


def test_open_of_a_missing_file_is_an_expression_error(tmp_path):
    """open of a path that does not exist fails with exit 5."""
    res = run_fq(["--arg", "p", str(tmp_path / "missing.bin"), "-n", "$p | open"])
    # CATCHES: the error is the bare OS message without the path (the path is
    # already known to the caller) and the exit code is the expression error
    # code 5, not an argument error.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: no such file or directory\n"


def test_open_of_a_directory_is_an_expression_error(tmp_path):
    """open of a directory fails when the read happens."""
    res = run_fq(["--arg", "p", str(tmp_path), "-n", "$p | open"])
    # CATCHES: opening a directory succeeds on Linux but reading it fails,
    # so the error is a read error that names the directory path.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: read %s: is a directory\n" % str(tmp_path).encode()


def test_opened_value_ext_type_and_ext_keys(tmp_path):
    """A decoded binary reports ext type binary and its extra keys."""
    path = write_file(tmp_path, "b.bin", b"abc")
    t = run_fq(["--arg", "p", str(path), "-c", "-n", "$p | open | _exttype"])
    k = run_fq(["--arg", "p", str(path), "-c", "-n", "$p | open | _extkeys"])
    # CATCHES: decoded values carry the sorted extra keys bits, bytes, name,
    # size, start, stop and unit, and their ext type is "binary".
    assert t.returncode == 0
    assert t.stdout == b'"binary"\n'
    assert k.returncode == 0
    assert k.stdout == b'["bits","bytes","name","size","start","stop","unit"]\n'


def test_plain_value_ext_type_and_ext_keys():
    """Plain values fall back to the jq type name and null ext keys."""
    t = run_fq(["-c", "-n", "_exttype"])
    k = run_fq(["-c", "-n", "_extkeys"])
    # CATCHES: _exttype of a value that is not a decoded format value is the
    # ordinary jq type name and _extkeys is null instead of an error.
    assert t.returncode == 0
    assert t.stdout == b'"null"\n'
    assert k.returncode == 0
    assert k.stdout == b"null\n"
