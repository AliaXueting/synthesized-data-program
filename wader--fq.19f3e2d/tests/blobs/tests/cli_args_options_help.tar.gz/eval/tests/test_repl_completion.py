"""Interactive REPL behaviour on a terminal (readline in pkg/cli/cli.go).

These tests drive the candidate on a pseudo terminal through ``run_fq_pty``
because TAB completion, the interrupt key and the decode progress line only
exist when stdin/stdout are a terminal.  The expected byte streams include
the readline library's redraws (``ESC[6n`` cursor queries, erase-to-end-of-
line, bell), the coloured prompt built from the current input value and the
colourised result values, all recorded from the reference binary.
"""

from __future__ import annotations

import struct
import zlib

from conftest import run_fq_pty, write_file

# All expectations below were recorded by running ./executable on an
# 80x24 pseudo terminal whose cursor position queries are answered by
# the harness in conftest.py.


def _png_bytes():
    """Return a minimal two-chunk PNG (signature, IHDR, IEND)."""

    def chunk(tag, data):
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data))
        )

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", 2, 1, 8, 0, 0, 0, 0))
        + chunk(b"IEND", b"")
    )


def test_tab_completes_a_single_candidate_inline():
    """TAB completes an unambiguous function name prefix inline."""
    rc, out = run_fq_pty(
        ["-i", "-n"],
        [(b"tojs", 0.8), (b"\t", 1.5), (b"\n", 1.0), (b"\x04", 0.6)],
    )
    # CATCHES: TAB completes "tojs" to the only scope name "tojson" by
    # redrawing the prompt line with the suffix inserted, the line is then
    # evaluated ("null" as a JSON string, colourised green on the terminal)
    # and Ctrl-D leaves the REPL with exit code 0.
    assert rc == 0
    assert out == (
        b"tojs \x08\x1b[6n"
        b"\x1b[39mnull\x1b[39m> \x1b[0Ktojson"
        b"\x1b[5G\x1b[J"
        b"\x1b[39mnull\x1b[39m> \x1b[0Ktojson\r\n"
        b" \x08\x1b[32m\"null\"\x1b[m\r\n"
        b" \x08\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )


def test_tab_completes_the_shared_prefix_and_rings_the_bell():
    """TAB with several candidates inserts only their shared prefix."""
    rc, out = run_fq_pty(
        ["-i", "-n"],
        [(b"toda", 0.8), (b"\t", 1.5), (b"\n", 1.0), (b"\x04", 0.6)],
    )
    # CATCHES: "toda" is a prefix of both todate and todateiso8601, so TAB
    # completes only the shared part "todate" and rings the terminal bell
    # (0x07) instead of picking a candidate; running the completed name on
    # the null input fails with strftime applied to null and the REPL still
    # continues to the next prompt and exits 0 on Ctrl-D.
    assert rc == 0
    assert out == (
        b"toda \x08\x1b[6n"
        b"\x1b[39mnull\x1b[39m> \x1b[0Ktodate"
        b"\x07\x1b[5G\x1b[J"
        b"\x1b[39mnull\x1b[39m> \x1b[0Ktodate\r\n"
        b" \x08error: strftime(\"%Y-%m-%dT%H:%M:%SZ\") cannot be applied to: null\r\n"
        b" \x08\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )


def test_tab_lists_all_candidates_when_nothing_can_be_inserted():
    """TAB with no insertable shared prefix lists every candidate."""
    rc, out = run_fq_pty(
        ["-i", "-n"],
        [(b"tob", 0.8), (b"\t", 1.5), (b"\n", 1.0), (b"\x04", 0.6)],
    )
    # CATCHES: "tob" is itself the whole shared prefix of the five matching
    # scope names, so TAB redraws the line and prints the candidate list in
    # padded columns below it instead of inserting anything.
    assert rc == 0
    assert out == (
        b"tob \x08\x1b[6n"
        b"\x1b[39mnull\x1b[39m> \x1b[0Ktob\r\n"
        b"\x1b[Jtobits       tobitsrange  toboolean    tobytes      tobytesrange "
        b"\x1b[1A\x1b[13G"
        b"\x1b[4G\x1b[J"
        b"\x1b[39mnull\x1b[39m> \x1b[0Ktob\r\n"
        b" \x08error: expr: function not defined: tob/0\r\n"
        b" \x08\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )


def test_tab_completes_object_keys_from_the_current_input(tmp_path):
    """TAB after a dot offers the keys of the REPL input value."""
    write_file(tmp_path, "obj.json", '{"ab":1,"ac":2}')
    rc, out = run_fq_pty(
        ["-i", ".", "obj.json"],
        [(b".a", 0.8), (b"\t", 1.5), (b"\n", 1.0), (b"\x04", 0.6)],
        cwd=str(tmp_path),
    )
    # CATCHES: the prompt names the decoded input's format ("json> "), TAB
    # after ".a" offers the two object keys "ab" and "ac" as a candidate
    # list, and evaluating ".a" on the object prints null in bright black;
    # the ESC[2K + CR right after the echo is the decode progress line
    # being cleared once the input file has been decoded.
    assert rc == 0
    assert out == (
        b".a\x1b[2K\r \x08\x1b[6n"
        b"\x1b[39mjson\x1b[39m> \x1b[0K.a\r\n"
        b"\x1b[Jab ac "
        b"\x1b[1A\x1b[9G"
        b"\x1b[1G\x1b[J"
        b"\x1b[39mjson\x1b[39m> \x1b[0K.a\r\n"
        b" \x08\x1b[90mnull\x1b[m\r\n"
        b" \x08\x1b[6n\x1b[39mjson\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )


def test_ctrl_c_abandons_the_line_and_keeps_the_repl_running():
    """Ctrl-C during readline drops the current line, it does not exit."""
    rc, out = run_fq_pty(
        ["-i", "-n"],
        [(b"1+", 0.8), (b"\x03", 0.8), (b"2", 0.3), (b"\n", 0.8), (b"\x04", 0.6)],
    )
    # CATCHES: the interrupt key echoes "^C" and abandons the half-typed
    # line without evaluating it or killing the process (unlike the SIGINT
    # during evaluation which exits 5); a fresh prompt accepts the next
    # line "2" which prints 2 in colour, and the REPL still exits 0.
    assert rc == 0
    assert out == (
        b"1+ \x08\x1b[6n"
        b"\x1b[39mnull\x1b[39m> \x1b[0K1+"
        b"\x1b[3G\x1b[J"
        b"\x1b[39mnull\x1b[39m> \x1b[0K1+^C\r\n"
        b" \x08 \x08\x1b[6n"
        b"\x1b[39mnull\x1b[39m> \x1b[0K2\r\n"
        b" \x08\x1b[36m2\x1b[m\r\n"
        b" \x08\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )


def test_completion_does_not_evaluate_stdio_side_effects():
    """Completion of a line with print must not write to the terminal."""
    rc, out = run_fq_pty(
        ["-i", "-n"],
        [(b"(null | print)", 0.8), (b"\t", 1.5), (b"\n", 1.0), (b"\x04", 0.6)],
    )
    # CATCHES: while completing, the line "(null | print)" is evaluated to
    # find completions but the print builtin writes nothing to the terminal
    # (stdio writes are suppressed in completion mode); the only completion
    # candidate is the "." index hint, so pressing Enter on the rewritten
    # line "(null | print)." reports an unexpected EOF with a bare caret.
    assert rc == 0
    assert out == (
        b"(null | print) \x08\x1b[6n"
        b"\x1b[39mnull\x1b[39m> \x1b[0K(null | print)."
        b"\x1b[15G\x1b[J"
        b"\x1b[39mnull\x1b[39m> \x1b[0K(null | print).\r\n"
        b" \x08                    ^ unexpected EOF\r\n"
        b" \x08\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )


def test_stdin_read_during_completion_returns_an_empty_string():
    """A stdin read asked for by completion returns empty without reading."""
    rc, out = run_fq_pty(
        ["-i", "-n"],
        [
            (b"(null | _stdin(1))", 0.8),
            (b"\t", 1.5),
            (b"\n", 1.0),
            (b"\x04", 1.0),
            (b"\x04", 0.6),
        ],
    )
    # CATCHES: evaluating the line during completion runs _stdin(1) in
    # completion mode, which yields the empty string instead of blocking on
    # the terminal, so no key completion is offered (just a bell); the real
    # evaluation after Enter then blocks until the first Ctrl-D delivers
    # EOF to the canonical-mode read, printing "" and "error: eof" (the
    # error line has no readline redraw prefix because it goes to stderr
    # directly), and the second Ctrl-D leaves the REPL with exit 0.
    assert rc == 0
    assert out == (
        b"(null | _stdin(1)) \x08\x1b[6n"
        b"\x1b[39mnull\x1b[39m> \x1b[0K(null | _stdin(1))"
        b"\x07\x1b[19G\x1b[J"
        b"\x1b[39mnull\x1b[39m> \x1b[0K(null | _stdin(1))\r\n"
        b" \x08\x1b[32m\"\"\x1b[m\r\n"
        b"error: eof\r\n"
        b" \x08\x1b[6n\x1b[39mnull\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )


def test_repl_decode_progress_clears_itself_on_a_terminal(tmp_path):
    """Decoding an input file in the REPL clears the progress line."""
    write_file(tmp_path, "t.png", _png_bytes())
    rc, out = run_fq_pty(
        ["-i", ".", "t.png"],
        [(b"1", 0.5), (b"\n", 0.8), (b"\x04", 0.6)],
        cwd=str(tmp_path),
    )
    # CATCHES: with decode progress enabled (the default) the file decode
    # writes ESC[2K + CR to stderr once it finishes, before the first
    # prompt is drawn; the prompt previews the decoded value's format
    # ("png> ") and the "1" typed during startup is echoed by the line
    # discipline and kept as the first REPL line.
    assert rc == 0
    assert out == (
        b"1\x1b[2K\r \x08\x1b[6n"
        b"\x1b[39mpng\x1b[39m> \x1b[0K1\r\n"
        b" \x08\x1b[36m1\x1b[m\r\n"
        b" \x08\x1b[6n\x1b[39mpng\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )


def test_no_decode_progress_env_disables_the_progress_line(tmp_path):
    """NO_DECODE_PROGRESS removes the progress clear from the terminal."""
    write_file(tmp_path, "t.png", _png_bytes())
    rc, out = run_fq_pty(
        ["-i", ".", "t.png"],
        [(b"1", 0.5), (b"\n", 0.8), (b"\x04", 0.6)],
        cwd=str(tmp_path),
        extra={"NO_DECODE_PROGRESS": "1"},
    )
    # CATCHES: with NO_DECODE_PROGRESS set the decode writes nothing to
    # stderr, so unlike the default run the stream goes straight from the
    # echoed "1" to the prompt redraw without any ESC[2K progress clear.
    assert rc == 0
    assert out == (
        b"1 \x08\x1b[6n"
        b"\x1b[39mpng\x1b[39m> \x1b[0K1\r\n"
        b" \x08\x1b[36m1\x1b[m\r\n"
        b" \x08\x1b[6n\x1b[39mpng\x1b[39m> \x1b[0K^D\r\n"
        b" \x08\x1b[1G\x1b[J"
    )
