"""-h/--help topics and -v/--version output (``pkg/interp/help.jq``).

``-h`` without a topic prints banner, usage, example usage and the flag table
to stdout and exits 0.  With a topic it dispatches to the option table, the
format list, a single format's options/examples/documentation, a documented
function, a builtin name, or the "don't know what X is" fallback.  The usage
line and the per-format example embed the program name (argv[0]), so the tests
substitute the candidate path.
"""

from __future__ import annotations

import os
import re

import pytest

from conftest import executable_path, run_fq

# All expectations below were recorded by running ./executable.

# Documentation of the documented "empty" function.
EMPTY_HELP = (
    b"empty: Output nothing\n"
    b"Output no value, not even null, and cause backtrack.\n"
    b"\n"
    b"Examples:\n"
    b"> empty\n"
    b"> [1,empty,2]\n"
    b"[1,2]\n"
)

# Documentation of the documented ".." function.
DOTDOT_HELP = (
    b"..: Recursive descent of .\n"
    b"Recursively descend . and output each value.\n"
    b"Same as recurse without argument.\n"
    b"\n"
    b"Examples:\n"
    b'> "a" | ..\n'
    b'"a"\n'
    b"> [1,2,3] | ..\n"
    b"[1,2,3]\n"
    b"1\n"
    b"2\n"
    b"3\n"
    b'> {"a":1,"b":{"c":3}} | ..\n'
    b'{"a":1,"b":{"c":3}}\n'
    b"1\n"
    b'{"c":3}\n'
    b"3\n"
)

# Documentation of the documented "length" function, including the failing
# boolean example which is rendered as an error line.
LENGTH_HELP = (
    b"length: Length of string, array, object, etc\n"
    b"- For string number of unicode codepoints\n"
    b"- For array number of elements in array\n"
    b"- For object number of key-value pairs\n"
    b"- For null zero\n"
    b"- For number the number itself\n"
    b"- For boolean is an error\n"
    b"\n"
    b"Examples:\n"
    b"> [1,2,3] | length\n"
    b"3\n"
    b'> "abc" | length\n'
    b"3\n"
    b'> {"a":1,"b":2} | length\n'
    b"2\n"
    b"> null | length\n"
    b"0\n"
    b"> 123 | length\n"
    b"123\n"
    b"> true | length\n"
    b"error: length cannot be applied to: boolean (true)\n"
)

# Embedded markdown documentation of the "bytes" format.
BYTES_HELP = (
    b"bytes: Raw bytes decoder\n"
    b"\n"
    b"Decode examples\n"
    b"===============\n"
    b"\n"
    b"  # Decode file as bytes\n"
    b"  $ fq -d bytes . file\n"
    b"  # Decode value as bytes\n"
    b"  ... | bytes\n"
    b"\n"
    b"Decode to a slice and indexable binary of bytes.\n"
    b"\n"
    b"Slice out byte ranges\n"
    b"=====================\n"
    b"  $ echo -n 'hello' | fq -d bytes '.[-3:]' > last_3_bytes\n"
    b"  $ echo -n 'hello' | fq -d bytes '[.[-2:], .[0:2]] | tobytes'"
    b" > first_last_2_bytes_swapped\n"
    b"\n"
    b"Slice and decode byte range\n"
    b"===========================\n"
    b'  $ echo \'some {"a":1} json\' | fq -d bytes \'.[5:-6] | fromjson\'\n'
    b"  {\n"
    b'    "a": 1\n'
    b"  }\n"
    b"\n"
    b"Index bytes\n"
    b"===========\n"
    b"  $ echo 'hello' | fq -d bytes '.[1]'\n"
    b"  101\n"
)

BANNER = (
    b"fq - jq for binary formats\n"
    b"Tool, language and decoders for working with binary data.\n"
    b"For more information see https://github.com/wader/fq\n"
)

EXAMPLE_USAGE = (
    b"Example usages:\n"
    b"  fq . file\n"
    b"  fq d file\n"
    b"  fq -V '.path[1].value' file\n"
    b"  fq tovalue file\n"
    b"  fq -r to_toml file.yml\n"
    b"  fq -s -d html 'map(.html.head.title?)' *.html\n"
    b"  cat file.cbor | fq -d cbor torepr\n"
    b"  fq 'grep(\"^main$\") | parent' /bin/ls\n"
    b"  fq -i\n"
)

ARGS_TABLE = (
    b"--arg NAME VALUE              Set $NAME to string VALUE\n"
    b"--argdecode NAME PATH         Set $NAME to decode of PATH\n"
    b"--argjson NAME JSON           Set $NAME to JSON\n"
    b"--args                        Consume remaining arguments as positional strings\n"
    b"--color-output,-C             Force color output\n"
    b"--compact-output,-c           Use compact output\n"
    b"--decode,-d NAME              Decode format or group (probe)\n"
    b"--from-file,-f PATH           Read EXPRESSION from file\n"
    b"--help,-h [TOPIC]             Show help for TOPIC (ex: -h formats, -h mp4)\n"
    b"--include-path,-L PATH        Add PATH to include search paths\n"
    b"--join-output,-j              No newline after each output\n"
    b"--jsonargs                    Consume remaining arguments as positional JSON\n"
    b"--monochrome-output,-M        Force monochrome output\n"
    b"--null-input,-n               Null input (use input and inputs to read)\n"
    b"--option,-o NAME=VALUE/@PATH  Set option (ex: -o color=true, see --help options)\n"
    b"--raw-file NAME PATH          Set $NAME to string content of file\n"
    b"--raw-input,-R                Read raw input strings (don't decode)\n"
    b"--raw-output,-r               Raw string output (without quotes)\n"
    b"--raw-output0                 NUL (zero) byte after each output\n"
    b"--repl,-i                     Interactive REPL\n"
    b"--slurp,-s                    Slurp all inputs into an array or string (-Rs)\n"
    b"--unicode-output,-U           Force unicode output\n"
    b"--value-output,-V             Output JSON value (-Vr for raw string)\n"
    b"--version,-v                  Show version\n"
)


def exe_bytes() -> bytes:
    """The candidate path exactly as it is passed as argv[0]."""
    return executable_path().encode()


def test_help_without_topic_prints_the_full_help():
    """-h prints banner, usage, examples and the args table to stdout."""
    res = run_fq(["-h"])
    # CATCHES: the default help is banner, blank, usage, blank, examples,
    # blank and then the flag table, in that exact order, on stdout with exit
    # code 0 (usage only goes to stderr when there are no arguments at all).
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        BANNER
        + b"\n"
        + b"Usage: " + exe_bytes() + b" [OPTIONS] [--] [EXPRESSION] [FILE...]\n"
        + b"\n"
        + EXAMPLE_USAGE
        + b"\n"
        + ARGS_TABLE
    )


def test_help_usage_topic_uses_argv0():
    """-h usage prints the one line usage with the program path."""
    res = run_fq(["-h", "usage"])
    # CATCHES: the usage line embeds argv[0] verbatim, so a re-implementation
    # must use the path it was invoked with and not a hard coded "fq".
    assert res.returncode == 0
    assert res.stdout == (
        b"Usage: " + exe_bytes() + b" [OPTIONS] [--] [EXPRESSION] [FILE...]\n"
    )
    assert res.stderr == b""


def test_help_banner_topic():
    """-h banner prints the three banner lines."""
    res = run_fq(["-h", "banner"])
    # CATCHES: the banner topic prints only the banner, with no usage or args.
    assert res.returncode == 0
    assert res.stdout == BANNER
    assert res.stderr == b""


def test_help_example_usage_topic():
    """-h example_usage prints the nine example lines."""
    res = run_fq(["-h", "example_usage"])
    # CATCHES: the examples use the literal name "fq" regardless of argv[0],
    # unlike the usage line.
    assert res.returncode == 0
    assert res.stdout == EXAMPLE_USAGE
    assert res.stderr == b""


def test_help_args_topic():
    """-h args prints the flag table sorted by long name."""
    res = run_fq(["-h", "args"])
    # CATCHES: the flag table is sorted by the long option name and shows the
    # short spelling only when one exists (note --raw-output0 has none).
    assert res.returncode == 0
    assert res.stdout == ARGS_TABLE
    assert res.stderr == b""


def test_help_options_topic_sorted_and_padded():
    """-h options lists the public options sorted by name."""
    res = run_fq(["-h", "options"])
    # CATCHES: the option topic is sorted by option name (addrbase first,
    # width last) which differs from the flag table's by-long-name order.
    assert res.returncode == 0
    assert res.stdout.splitlines()[0] == b"addrbase            16"
    assert res.stdout.splitlines()[-1] == b"width               0"
    assert len(res.stdout.splitlines()) == 20


def test_help_formats_topic_lists_formats():
    """-h formats lists every format name with its description."""
    res = run_fq(["-h", "formats"])
    # CATCHES: the format topic is a two column list in registration order;
    # the names are padded to the longest name and followed by exactly two
    # spaces before the description.
    assert res.returncode == 0
    assert res.stderr == b""
    lines = res.stdout.splitlines()
    assert len(lines) == 136
    assert lines[0] == b"aac_frame            Advanced Audio Coding frame"
    assert b"cbor                 Concise Binary Object Representation" in lines
    assert lines[-1] == b"zip                  ZIP archive"
    for line in lines:
        # every name is padded to 19 characters plus a two space separator
        assert line[19:21] == b"  "
        assert line[21:].strip() != b""


def test_help_format_with_documentation():
    """-h bytes shows the decoder help and its markdown documentation."""
    res = run_fq(["-h", "bytes"])
    # CATCHES: a format topic starts with "<name>: <description> decoder",
    # then a generated decode examples section, then the embedded markdown
    # documentation rendered to text.
    assert res.returncode == 0
    assert res.stdout == BYTES_HELP
    assert res.stderr == b""


def test_help_format_with_decode_options():
    """-h mp3 shows the option table and generated examples."""
    res = run_fq(["-h", "mp3"])
    # CATCHES: formats with decode_in_arg options list them in a table and the
    # generated "decode file using options" example embeds argv[0] plus every
    # option as a separate -o flag.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"mp3: MP3 file decoder\n"
        b"\n"
        b"Options\n"
        b"=======\n"
        b"\n"
        b"  max_sync_seek=32768          Max byte distance to next sync\n"
        b"  max_unique_header_configs=5  Max number of unique frame header configs allowed\n"
        b"  max_unknown=50               Max percent (0-100) unknown bits\n"
        b"\n"
        b"Decode examples\n"
        b"===============\n"
        b"\n"
        b"  # Decode file as mp3\n"
        b"  $ fq -d mp3 . file\n"
        b"  # Decode value as mp3\n"
        b"  ... | mp3\n"
        b"  # Decode file using mp3 options\n"
        b"  $ " + exe_bytes()
        + b" -d mp3 -o max_sync_seek=32768 -o max_unique_header_configs=5"
        b" -o max_unknown=50 . file\n"
        b"  # Decode value as mp3\n"
        b"  ... | mp3({max_sync_seek:32768,max_unique_header_configs:5,max_unknown:50})\n"
        b"\n"
    )


@pytest.mark.parametrize(
    "topic, expected",
    [
        ("empty", EMPTY_HELP),
        ("..", DOTDOT_HELP),
        ("length", LENGTH_HELP),
    ],
)
def test_help_documented_function(topic, expected):
    """-h on a documented function shows summary, doc and evaluated examples."""
    res = run_fq(["-h", topic])
    # CATCHES: the examples in function help are actually evaluated at help
    # time, so the recorded output includes their results and error messages.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


@pytest.mark.parametrize(
    "topic, expected",
    [
        ("map", b"map is builtin function\n"),
        ("input", b"input is builtin function\n"),
    ],
)
def test_help_builtin_function(topic, expected):
    """-h on a gojq builtin only says that it is a builtin."""
    res = run_fq(["-h", topic])
    # CATCHES: builtins have no documentation entry, the topic just reports
    # "is builtin function" (no "a").
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


@pytest.mark.parametrize(
    "topic",
    ["tosomething", "nosuchtopic", "display", "1", "-v", "image"],
)
def test_help_unknown_topic(topic):
    """An unknown topic prints the fallback line with a trailing space."""
    res = run_fq(["-h", topic])
    # CATCHES: unknown topics are not an error; the line keeps a trailing
    # space after "is" and the exit code stays 0.
    assert res.returncode == 0
    assert res.stdout == b"don't know what %s is \n" % topic.encode()
    assert res.stderr == b""


def test_version_flag():
    """-v prints "VERSION (os arch goversion)"."""
    res = run_fq(["-v"])
    # CATCHES: the version line is "<version> (<os> <arch> <goversion>)" with
    # the version taken from the build, on stdout with exit code 0.
    assert res.returncode == 0
    assert res.stderr == b""
    line = res.stdout
    assert line.endswith(b")\n")
    assert line.startswith(b"0.18.0 (linux amd64 go")
    assert len(line.split(b" ")) == 4


def test_version_long_flag_matches_short():
    """--version prints the same line as -v."""
    res = run_fq(["--version"])
    # CATCHES: both spellings share one code path and print the identical
    # "<version> (<os> <arch> <goversion>)" line on stdout with exit code 0.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == run_fq(["-v"]).stdout
    assert re.fullmatch(rb"0\.18\.0 \(linux amd64 go\d+\.\d+(\.\d+)?\)\n", res.stdout)


def test_help_wins_over_version():
    """-v -h prints help, not the version."""
    res = run_fq(["-v", "-h"])
    # CATCHES: the help option is checked before the version option, so a
    # combined invocation prints the full help text.
    assert res.returncode == 0
    assert res.stdout.startswith(BANNER)
    assert b"Usage: " in res.stdout
    assert not res.stdout.startswith(b"0.18.0")


def test_help_is_not_colourised():
    """-o color=true does not colourise the help output."""
    res = run_fq(["-o", "color=true", "-h", "banner"])
    # CATCHES: help text is written with plain println, so forcing the colour
    # option does not add any escape sequences to it.
    assert res.returncode == 0
    assert res.stdout == BANNER
    assert b"\x1b[" not in res.stdout
