"""Implicit value conversions in open and the regex builtins.

``open`` accepts any value as a path by converting it to a string first:
numbers go through their minimal bit pattern, and values that cannot become
bytes fail with "value can't be a string".  The regex builtins accept a
number pattern the same way, turning its bits into the bytes to search for.
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize("expr", ["1 | open", "1.5 | open"])
def test_open_with_a_number_path_is_an_io_error(expr):
    """A number path is converted to its bytes and fails to open."""
    res = run_fq(["-n", expr])
    # CATCHES: a number is converted via its bit pattern (1 and 1.5 both
    # become a single 0x80 byte) and used as the file name, which does not
    # exist; the error is the bare OS message (no path echo) with the
    # expression error exit code 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: no such file or directory\n"


def test_open_with_a_big_integer_path_is_an_invalid_argument():
    """A huge integer literal becomes a path with a NUL byte in it."""
    res = run_fq(["-n", "123456789012345678901234567890 | open"])
    # CATCHES: the big integer's 97-bit pattern is padded into 13 bytes
    # which include a NUL, and opening a path with an embedded NUL fails
    # with "invalid argument" rather than "no such file or directory".
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: invalid argument\n"


def test_open_with_an_object_path_cannot_become_a_string():
    """A value that is not bytes cannot be used as a path at all."""
    res = run_fq(["-n", "{} | open"])
    # CATCHES: an object has no binary representation, so the path
    # conversion fails with the double-colon shape "error: : value can't be
    # a string" (the empty path is printed before the message).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: : value can't be a string\n"


@pytest.mark.parametrize(
    "expr, expected",
    [
        ('"\\u0081" | tobytes | test(129)', b"true\n"),
        ('"\\u0081" | tobytes | test(128)', b"false\n"),
    ],
)
def test_a_number_regexp_pattern_matches_its_own_bits(expr, expected):
    """test accepts a number pattern by matching its bit pattern bytes."""
    res = run_fq(["-n", expr])
    # CATCHES: the pattern number 129 is 10000001 in binary which is exactly
    # the 0x81 continuation byte of the UTF-8 encoding of U+0081, so it
    # matches; 128 (0x80) does not occur in those bytes and does not match.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_match_with_a_number_pattern_reports_byte_offsets():
    """match with a number pattern reports the byte it matched."""
    res = run_fq(["-n", '"\\u0081" | tobytes | [match(129)]'])
    # CATCHES: the match object reports offset 1 (the 0x81 byte after the
    # 0xC2 lead byte) and length 1, and the matched byte is not valid UTF-8
    # so the captured "string" is rendered as the escaped replacement
    # character in the JSON output.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"[\n"
        b"  {\n"
        b'    "captures": [],\n'
        b'    "length": 1,\n'
        b'    "offset": 1,\n'
        b'    "string": "\\ufffd"\n'
        b"  }\n"
        b"]\n"
    )


def test_global_number_pattern_match_finds_every_occurrence():
    """The g flag applies to number patterns like any other pattern."""
    res = run_fq(["-n", '"\\u0081\\u0081" | tobytes | [match(129; "g")] | length'])
    # CATCHES: each 0x81 continuation byte of the two U+0081 codepoints is
    # matched once, so the global match finds exactly two occurrences.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"2\n"
