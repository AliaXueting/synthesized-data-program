"""Input handling: FILE arguments, stdin, -n/-s/-R and per-input errors.

``pkg/interp/init.jq`` builds the input iterator: FILE arguments are opened in
order, ``-`` and the empty list both mean stdin, ``--null-input`` never reads,
``--slurp`` collects every input into an array and ``--raw-input`` iterates
lines.  IO and decode failures are reported per input and evaluation continues
with the next one; the final exit code is decided afterwards.
"""

from __future__ import annotations

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.


@pytest.fixture
def files(tmp_path):
    """Three small inputs: two JSON files and one undecodable text file."""
    return {
        "one": write_file(tmp_path, "one.json", "1\n"),
        "two": write_file(tmp_path, "two.json", "2\n"),
        "text": write_file(tmp_path, "text.txt", "zzz"),
        "array": write_file(tmp_path, "array.json", "1\n2\n3\n"),
        "lines": write_file(tmp_path, "lines.txt", "a\nb\n"),
        "lines_nonl": write_file(tmp_path, "nonl.txt", "a\nb"),
    }


def test_stdin_is_used_when_no_files_are_given():
    """Without FILE arguments the single input is stdin."""
    res = run_fq(["."], stdin='{"a": 1}')
    # CATCHES: the file list defaults to stdin, so a piped document is decoded
    # and evaluated exactly like a named file.
    assert res.returncode == 0
    assert res.stdout == b'{\n  "a": 1\n}\n'
    assert res.stderr == b""


def test_multiple_file_arguments_are_read_in_order(files):
    """Each FILE argument is one input."""
    res = run_fq([".", files["one"], files["two"]])
    # CATCHES: the files are processed in command line order, one output per
    # input, with no separator between them.
    assert res.returncode == 0
    assert res.stdout == b"1\n2\n"
    assert res.stderr == b""


def test_same_file_twice_is_read_twice(files):
    """A repeated FILE argument is opened again."""
    res = run_fq([".", files["one"], files["one"]])
    # CATCHES: inputs are not deduplicated, so the same path produces two
    # outputs.
    assert res.returncode == 0
    assert res.stdout == b"1\n1\n"
    assert res.stderr == b""


def test_dash_reads_stdin_among_files(files):
    """A "-" FILE argument means stdin at that position."""
    res = run_fq([".", "-", files["one"]], stdin='"from stdin"')
    # CATCHES: "-" is replaced by stdin in the filename list, keeping the
    # ordering relative to the other file arguments.
    assert res.returncode == 0
    assert res.stdout == b'"from stdin"\n1\n'
    assert res.stderr == b""


def test_missing_file_is_an_io_error_but_evaluation_continues(files):
    """A missing FILE reports on stderr and the next input is still read."""
    missing = files["one"] + ".missing"
    res = run_fq([".", missing, files["one"]])
    # CATCHES: an unopenable file only skips that input; the program still
    # evaluates for the remaining files and the exit code becomes 2.
    assert res.returncode == 2
    assert res.stdout == b"1\n"
    assert res.stderr == b"error: %s: no such file or directory\n" % missing.encode()


def test_undecodable_file_is_a_decode_error_but_evaluation_continues(files):
    """A file no format can probe reports and the next input is still read."""
    res = run_fq([".", files["text"], files["one"]])
    # CATCHES: a probe failure is a decode error (exit 4, hinting at -d) rather
    # than an IO error, and processing continues with the next file.
    assert res.returncode == 4
    assert res.stdout == b"1\n"
    assert res.stderr == (
        b"error: %s: probe: failed to decode: try fq -d FORMAT to force format, "
        b"see fq -h formats for list\n" % files["text"].encode()
    )


def test_io_error_takes_precedence_over_decode_error(files):
    """Both errors are reported; the exit code is the IO error code."""
    missing = files["one"] + ".missing"
    res = run_fq([".", missing, files["text"]])
    # CATCHES: when an input had an IO error and another a decode error, the
    # final exit code is 2 (IO) because it is checked first.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"error: %s: no such file or directory\n" % missing.encode()
        + b"error: %s: probe: failed to decode: try fq -d FORMAT to force format, "
        b"see fq -h formats for list\n" % files["text"].encode()
    )


def test_empty_file_is_a_decode_error(tmp_path):
    """A zero length file cannot be probed."""
    empty = write_file(tmp_path, "empty", b"")
    res = run_fq([".", empty])
    # CATCHES: an empty file is opened successfully but no format matches, so
    # the failure is a decode error with the probe hint, not an IO error.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr == (
        b"error: %s: probe: failed to decode: try fq -d FORMAT to force format, "
        b"see fq -h formats for list\n" % empty.encode()
    )


def test_directory_argument_is_an_io_error(tmp_path):
    """A directory cannot be read as an input."""
    res = run_fq([".", str(tmp_path)])
    # CATCHES: opening a directory fails with "<name>: read <path>: is a
    # directory" (the input name prefix plus the raw read error) and the IO
    # error exit code 2.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"error: %s: read %s: is a directory\n"
        % (str(tmp_path).encode(), str(tmp_path).encode())
    )


def test_stdin_named_stdin_in_error_messages():
    """Errors for stdin name the input "<stdin>"."""
    res = run_fq(["."], stdin=b"\xff\xfe")
    # CATCHES: the synthetic input name for stdin is <stdin> and it appears in
    # the error message exactly like a filename would.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr == (
        b"error: <stdin>: probe: failed to decode: try fq -d FORMAT to force "
        b"format, see fq -h formats for list\n"
    )


def test_null_input_does_not_read_files(files):
    """--null-input evaluates once with null regardless of FILE arguments."""
    res = run_fq(["-n", ".", files["one"], files["two"]])
    # CATCHES: with --null-input the FILE arguments are ignored entirely, the
    # expression sees a single null input and no file is ever opened.
    assert res.returncode == 0
    assert res.stdout == b"null\n"
    assert res.stderr == b""


def test_slurp_collects_all_inputs_into_one_array(files):
    """--slurp wraps every input into a single array."""
    res = run_fq(["-s", ".", files["one"], files["two"]])
    # CATCHES: --slurp changes the input query to collect all inputs, so the
    # expression runs once on [1, 2] instead of twice.
    assert res.returncode == 0
    assert res.stdout == b"[\n  1,\n  2\n]\n"
    assert res.stderr == b""


def test_slurp_of_a_multi_value_file(files):
    """A file with several JSON values becomes one input array element."""
    res = run_fq(["-s", ".", files["array"]])
    # CATCHES: jsonl style files are decoded as one array per file, so slurping
    # produces a nested array.
    assert res.returncode == 0
    assert res.stdout == b"[\n  [\n    1,\n    2,\n    3\n  ]\n]\n"
    assert res.stderr == b""


def test_raw_input_iterates_lines(files):
    """--raw-input produces one string per line."""
    res = run_fq(["-R", ".", files["lines"]])
    # CATCHES: raw input splits the file on newlines and drops the trailing
    # newline, so a two line file yields exactly two strings.
    assert res.returncode == 0
    assert res.stdout == b'"a"\n"b"\n'
    assert res.stderr == b""


def test_raw_input_without_trailing_newline_joins_next_file(files):
    """A final line without a newline continues into the next input."""
    res = run_fq(["-R", ".", files["lines_nonl"], files["one"]])
    # CATCHES: jq compatibility quirk - the chunks of all inputs are joined
    # before line splitting, so "b" and "1" become the single line "b1".
    assert res.returncode == 0
    assert res.stdout == b'"a"\n"b1"\n'
    assert res.stderr == b""


def test_raw_input_with_slurp_concatenates_everything(files):
    """-Rs joins all inputs into one string."""
    res = run_fq(["-Rs", ".", files["lines"], files["one"]])
    # CATCHES: --raw-input combined with --slurp concatenates every input into
    # a single string instead of building an array.
    assert res.returncode == 0
    assert res.stdout == b'"a\\nb\\n1\\n"\n'
    assert res.stderr == b""


def test_input_and_inputs_builtins(files):
    """input/inputs pull from the FILE list under --null-input."""
    res_one = run_fq(["-n", "input", files["one"], files["two"]])
    res_all = run_fq(["-n", "[inputs]", files["one"], files["two"]])
    # CATCHES: the input builtins read the same FILE list even though the main
    # expression uses null input; inputs drains the remaining ones.
    assert res_one.returncode == 0
    assert res_one.stdout == b"1\n"
    assert res_all.returncode == 0
    assert res_all.stdout == b"[\n  1,\n  2\n]\n"


def test_input_beyond_the_last_is_a_break_error(files):
    """Calling input when no inputs remain raises a "break" error."""
    res = run_fq(["[., input]", files["one"]])
    # CATCHES: exhausting the input iterator surfaces as the raw jq error
    # "break", reported as an expression error with exit code 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: break\n"


def test_input_filename_tracks_the_current_input(files):
    """input_filename names the file each value came from."""
    res = run_fq(["input_filename", files["one"], files["two"]])
    # CATCHES: the global input filename is updated per input, so each output
    # names the file it was decoded from.
    assert res.returncode == 0
    assert res.stdout == b'"%s"\n"%s"\n' % (
        files["one"].encode(),
        files["two"].encode(),
    )
    assert res.stderr == b""


def test_input_filename_is_null_after_all_inputs(files):
    """input_filename is null again once iteration finished."""
    res = run_fq(["-s", "[.[] | input_filename]", files["one"], files["two"]])
    # CATCHES: the filename is cleared after each input is produced, so asking
    # for it later (inside the slurped array) yields null.
    assert res.returncode == 0
    assert res.stdout == b"[\n  null,\n  null\n]\n"
    assert res.stderr == b""


def test_slurp_with_io_error_still_outputs_the_rest(files):
    """A missing file inside --slurp does not stop the other inputs."""
    missing = files["one"] + ".missing"
    res = run_fq(["-s", ".", missing, files["one"]])
    # CATCHES: the IO error is recorded and the good input still ends up in the
    # slurped array; only the exit code reflects the failure.
    assert res.returncode == 2
    assert res.stdout == b"[\n  1\n]\n"
    assert res.stderr == b"error: %s: no such file or directory\n" % missing.encode()


def test_forced_decode_of_wrong_format_is_a_decode_error(files):
    """-d NAME with a group that rejects the data is a decode error."""
    res = run_fq(["-d", "image", ".", files["text"]])
    # CATCHES: forcing a decode group whose members all reject the data
    # reports the group name followed by the generic "failed to decode" hint,
    # with the decode error exit code 4.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr == (
        b"error: %s: image: failed to decode: try fq -d FORMAT to force format, "
        b"see fq -h formats for list\n" % files["text"].encode()
    )


def test_unknown_decode_group_is_a_decode_error(files):
    """-d with an unknown format name only fails when decoding."""
    res_parse = run_fq(["-d", "nosuchformat", "-n", "1"])
    res_read = run_fq(["-d", "nosuchformat", ".", files["one"]])
    # CATCHES: the decode format is not validated while parsing arguments, so
    # --null-input runs fine and the error only appears when a value is decoded.
    assert res_parse.returncode == 0
    assert res_parse.stdout == b"1\n"
    assert res_read.returncode == 4
    assert res_read.stdout == b""
    assert res_read.stderr == (
        b"error: %s: nosuchformat: format group not found\n" % files["one"].encode()
    )
