"""Shared harness for the ``cli_args_options_help`` module tests.

Every test drives the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hard-coded path).  The main helper is ``run_fq``, which takes a raw argument
vector and returns the completed process with byte-exact stdout/stderr so the
recorded expectations can be asserted verbatim.

The child environment is fully pinned (an empty temporary HOME, fixed PATH and
LANG) so the OS config dir ``$HOME/.config/fq`` is guaranteed to be empty and
no ambient ``NO_COLOR``/``CLIUNICODE``-style variable can leak in.  Tests that
exercise the config dir pass their own ``HOME``/``XDG_CONFIG_HOME`` through
``extra=`` (or a fully explicit ``env=``).

``run_fq_tty`` runs the candidate with stdin/stdout/stderr all attached to a
freshly allocated pseudo terminal; it is only used for behaviour that is
genuinely unreachable through pipes (colour auto-detection, the "no arguments
and both stdio are terminals" usage banner).

``run_fq_pty`` also uses a pseudo terminal but feeds the candidate a scripted
list of input chunks and keeps collecting output between them, so interactive
readline behaviour (TAB completion, Ctrl-C, redraws) can be asserted on the
exact terminal byte stream.  It answers the readline library's cursor position
queries (``ESC[6n``) the way a real terminal would; without that reply the
candidate blocks waiting for the terminal.
"""

from __future__ import annotations

import fcntl
import os
import pathlib
import pty
import re
import select
import struct
import subprocess
import tempfile
import termios
import time

# The pinned child environment is built per call; HOME points at an empty
# throwaway directory created on first use so ~/.config/fq/init.jq never
# exists unless a test creates it explicitly.
_BASE_HOME: list[str] = []


def executable_path() -> str:
    """Return the candidate path from PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE", "")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; the suite cannot drive the candidate"
        )
    return path


def default_home() -> str:
    """Return a stable empty HOME directory (created on first call)."""
    if not _BASE_HOME:
        _BASE_HOME.append(tempfile.mkdtemp(prefix="fq-cli-home-"))
    return _BASE_HOME[0]


def _merge_env(env, extra):
    """Build the child environment: pinned base, overridden by env/extra."""
    if env is None:
        merged = {
            "PATH": "/usr/bin:/bin",
            "HOME": default_home(),
            "LANG": "C",
        }
    else:
        # An explicit env is used verbatim so tests can pin exactly which
        # variables the child sees (e.g. HOME unset entirely).
        merged = dict(env)
    if extra:
        merged.update(extra)
    # Coverage instrumentation hook (REQUIRED): copy GOCOVERDIR from the
    # test process environment into the child env when present, so the
    # pipeline can measure source coverage of the reference binary.
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    merged.update(cov_env)
    return merged


def pinned_env(extra=None):
    """Return the pinned child environment (with the GOCOVERDIR passthrough).

    Tests that need to drive the process by hand (signals, ptys) can build
    the same hermetic environment ``run_fq`` uses instead of duplicating it.
    """
    return _merge_env(None, extra)


def run_fq(argv, *, stdin="", cwd=None, env=None, extra=None, timeout=30):
    """Run the candidate with a raw argument vector, return the process.

    stdin may be str or bytes; stdout/stderr are always bytes so that exact
    recorded byte expectations can be asserted.
    """
    data = stdin if isinstance(stdin, bytes) else stdin.encode()
    return subprocess.run(
        [executable_path()] + list(argv),
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env=_merge_env(env, extra),
        timeout=timeout,
    )


def run_fq_tty(argv, *, env=None, extra=None, cwd=None, cols=80, rows=24, timeout=10):
    """Run the candidate with all three stdio streams on a new pty.

    Returns ``(returncode, output_bytes)``.  The pty is created per call, its
    window size is fixed and the child environment is pinned the same way as
    ``run_fq``, so the run is hermetic despite being terminal-attached.
    """
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    proc = subprocess.Popen(
        [executable_path()] + list(argv),
        stdin=slave,
        stdout=slave,
        stderr=slave,
        cwd=cwd,
        env=_merge_env(env, extra),
        close_fds=True,
    )
    os.close(slave)
    out = b""
    deadline = time.time() + timeout
    try:
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                proc.terminate()
                break
            ready, _, _ = select.select([master], [], [], 0.1)
            if ready:
                try:
                    chunk = os.read(master, 65536)
                except OSError:
                    break
                if not chunk:
                    break
                out += chunk
            elif proc.poll() is not None:
                while True:
                    ready, _, _ = select.select([master], [], [], 0.1)
                    if not ready:
                        break
                    try:
                        chunk = os.read(master, 65536)
                    except OSError:
                        break
                    if not chunk:
                        break
                    out += chunk
                break
    finally:
        os.close(master)
    return proc.wait(), out


class _PtyTerm:
    """Minimal terminal emulation for driving the candidate's readline.

    Tracks the cursor row/column from the bytes the candidate writes so that
    DSR cursor position queries (``ESC[6n``) can be answered with a plausible
    position, exactly like a real terminal.  The readline library blocks
    until it gets the ``ESC[row;colR`` reply, so without this the candidate
    would never finish redrawing its prompt.
    """

    _CSI_RE = re.compile(rb"\x1b\[([0-9;?]*)([A-Za-z])")
    _TEXT_RE = re.compile(rb"[ -~\xc2-\xf4][ -~\x80-\xbf]*")

    def __init__(self, fd):
        self._fd = fd
        self.row = 1
        self.col = 1
        self._pending = b""

    def feed(self, chunk):
        """Consume CHUNK of terminal output, replying to any DSR query."""
        data = self._pending + chunk
        i = 0
        while i < len(data):
            if data[i : i + 1] == b"\x1b":
                m = self._CSI_RE.match(data, i)
                if m:
                    params, final = m.group(1), m.group(2)
                    if final == b"n":  # cursor position report request
                        os.write(self._fd, b"\x1b[%d;%dR" % (self.row, self.col))
                    elif final == b"C":  # cursor forward
                        self.col += int(params or 1)
                    elif final == b"D":  # cursor back
                        self.col = max(1, self.col - int(params or 1))
                    elif final == b"A":  # cursor up
                        self.row = max(1, self.row - int(params or 1))
                    elif final == b"B":  # cursor down
                        self.row += int(params or 1)
                    elif final == b"G":  # cursor to column (1-based)
                        self.col = max(1, int(params or 1))
                    elif final == b"H":  # cursor home
                        self.row, self.col = 1, 1
                    i = m.end()
                    continue
                # possibly an incomplete escape sequence: retry next feed
                self._pending = data[i:]
                return
            b = data[i : i + 1]
            if b == b"\r":
                self.col = 1
            elif b == b"\n":
                self.row, self.col = self.row + 1, 1
            elif b == b"\x08":
                self.col = max(1, self.col - 1)
            elif b == b"\x07":
                pass
            else:
                m = self._TEXT_RE.match(data, i)
                if m:
                    self.col += len(m.group(0).decode("utf-8", "replace"))
                    i = m.end()
                    continue
            i += 1
        self._pending = b""


def run_fq_pty(
    argv, steps, *, env=None, extra=None, cwd=None, cols=80, rows=24, timeout=20
):
    """Run the candidate on a pty and feed it STEPS interactively.

    STEPS is a list of ``(data, quiet_seconds)`` pairs: DATA (bytes, may be
    empty to just wait) is written to the pty master, then output is
    collected until the candidate has been quiet for QUIET_SECONDS.  Input
    written in the first step is echoed by the pty line discipline before
    the candidate has had time to switch the terminal to raw mode, which is
    part of the recorded byte stream.

    Returns ``(returncode, output_bytes)`` where output_bytes is everything
    the candidate wrote to the terminal, so prompt drawing, TAB completion
    and error redraws can be asserted verbatim.
    """
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    proc = subprocess.Popen(
        [executable_path()] + list(argv),
        stdin=slave,
        stdout=slave,
        stderr=slave,
        cwd=cwd,
        env=_merge_env(env, extra),
        close_fds=True,
    )
    os.close(slave)
    term = _PtyTerm(master)
    out = b""
    deadline = time.time() + timeout

    def drain(quiet):
        """Collect output until QUIET seconds pass with no new bytes."""
        nonlocal out
        last = time.time()
        while time.time() < deadline:
            ready, _, _ = select.select([master], [], [], 0.05)
            if ready:
                try:
                    chunk = os.read(master, 65536)
                except OSError:
                    return False
                if not chunk:
                    return False
                out += chunk
                term.feed(chunk)
                last = time.time()
            elif time.time() - last > quiet:
                return True
        return False

    for data, quiet in steps:
        if data:
            os.write(master, data)
        if not drain(quiet):
            break
    drain(0.4)
    try:
        returncode = proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        proc.terminate()
        returncode = proc.wait()
    os.close(master)
    return returncode, out


def write_file(directory, name, text):
    """Write TEXT to DIRECTORY/NAME and return the path as a str."""
    path = pathlib.Path(directory) / name
    if isinstance(text, bytes):
        path.write_bytes(text)
    else:
        path.write_text(text, encoding="utf-8")
    return str(path)


def write_tree(directory, *parts):
    """Write PARTS[-1] under DIRECTORY/*PARTS[:-1] and return the path.

    ``write_tree(tmp_path, ".config", "fq", "init.jq", "def x: 1;")`` writes
    the text to ``tmp_path/.config/fq/init.jq``.
    """
    *path_parts, text = parts
    path = pathlib.Path(directory).joinpath(*path_parts)
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(text, bytes):
        path.write_bytes(text)
    else:
        path.write_text(text, encoding="utf-8")
    return str(path)
