"""Flag parsing diagnostics and their exit codes (``pkg/interp/args.jq``).

Every malformed invocation is rejected before any input is opened, is written
to stderr prefixed with ``error: `` and makes the process exit with code 2.
The messages themselves are assembled by the jq flag parser, so their exact
wording (including the un-pluralised "needs two argument") is worth pinning.
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.

# Long and short spellings of flags that never take a value.
BOOL_FLAGS = [
    "--null-input",
    "--slurp",
    "--raw-input",
    "--raw-output",
    "--join-output",
    "--compact-output",
    "--color-output",
    "--monochrome-output",
    "--unicode-output",
    "--value-output",
    "--repl",
    "--version",
]

# Flags that consume exactly one following argument.
ONE_ARGUMENT_FLAGS = [
    "--decode",
    "--option",
    "--include-path",
    "--from-file",
    "-d",
    "-o",
    "-L",
    "-f",
]

# Flags that consume exactly two following arguments.
TWO_ARGUMENT_FLAGS = [
    "--arg",
    "--argjson",
    "--argdecode",
    "--raw-file",
]


@pytest.mark.parametrize("flag", BOOL_FLAGS)
def test_boolean_flag_rejects_attached_value(flag):
    """``--bool=value`` is rejected with "takes no argument"."""
    res = run_fq([flag + "=1", "-n", "1"])
    # CATCHES: boolean flags have no argument slot, so the =VALUE form is a
    # parse error rather than a silently ignored value.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: %s: takes no argument\n" % flag.encode()


def test_short_boolean_flag_rejects_attached_value():
    """``-c=1`` names the short spelling in the message."""
    res = run_fq(["-c=1", "-n", "1"])
    # CATCHES: for the short spelling the diagnostic uses the two character
    # form "-c", not the long "--compact-output".
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: -c: takes no argument\n"


@pytest.mark.parametrize("flag", ONE_ARGUMENT_FLAGS)
def test_flag_missing_argument(flag):
    """A value-taking flag at the end of argv reports "needs an argument"."""
    res = run_fq([flag])
    # CATCHES: every one-argument flag left without its argument aborts with
    # the same "needs an argument" wording and exit code 2.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: %s: needs an argument\n" % flag.encode()


@pytest.mark.parametrize("flag", TWO_ARGUMENT_FLAGS)
def test_pair_flag_missing_second_argument(flag):
    """Two-argument flags need both NAME and VALUE."""
    res = run_fq([flag, "name"])
    # CATCHES: pair flags report "needs two argument" (sic) when only one of
    # the two required tokens follows.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: %s: needs two argument\n" % flag.encode()


@pytest.mark.parametrize(
    "argv, message",
    [
        (["--nope"], b"error: --nope: no such argument\n"),
        (["--nope=1"], b"error: --nope: no such argument\n"),
        (["-x"], b"error: -x: no such argument\n"),
        (["-Vx"], b"error: -x: no such argument\n"),
        (["-djson", "."], b"error: -d: needs an argument\n"),
        (["-ofoo=1"], b"error: -o: needs an argument\n"),
    ],
)
def test_unknown_flag_message(argv, message):
    """Unknown flags name the flag (or letter) that was not recognised."""
    res = run_fq(argv)
    # CATCHES: unknown long flags echo the whole argument while unknown short
    # letters echo only the letter, and a glued value is reported as a missing
    # argument for the recognised letter.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == message


def test_option_without_key_value_separator():
    """-o requires a NAME=VALUE shaped argument."""
    res = run_fq(["-o", "foo"])
    # CATCHES: the value of -o must contain an "="; the diagnostic repeats the
    # offending value, not the flag name.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: foo: should be key=value\n"


def test_option_with_empty_key_or_value_is_accepted():
    """-o =x and -o a= parse (unknown keys are simply unused)."""
    res = run_fq(["-o", "=x", "-n", "1"])
    # CATCHES: an empty key or empty value still matches key=value, so no
    # "should be key=value" error is raised and the program runs normally.
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""

    res2 = run_fq(["-o", "a=", "-n", "1"])
    assert res2.returncode == 0
    assert res2.stdout == b"1\n"


def test_argparse_error_happens_before_evaluation(tmp_path):
    """A parse error prevents any input file from being opened."""
    path = tmp_path / "in.json"
    path.write_text('{"a": 1}\n')
    res = run_fq(["--nope", ".", str(path)])
    # CATCHES: argument parsing runs before inputs are read, so even a valid
    # file argument produces no output when an earlier flag is unknown.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == b"error: --nope: no such argument\n"


def test_positional_after_pair_flag_becomes_expression():
    """A third token after --arg NAME VALUE becomes the expression."""
    res = run_fq(["--arg", "a", "b", "c"])
    # CATCHES: --arg consumes exactly two tokens, so "c" is left over and used
    # as the jq program, failing at compile time with exit code 3.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"error: arg: function not defined: c/0\n"
