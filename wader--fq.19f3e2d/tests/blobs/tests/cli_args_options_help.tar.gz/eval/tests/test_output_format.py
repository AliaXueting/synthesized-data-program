"""Output formatting flags: -c, -r, -j, --raw-output0, -V and -U.

The default output is pretty printed JSON with two space indentation and one
newline after every value.  ``--raw-output`` only strips the quotes of strings,
``--join-output`` removes the separator, ``--raw-output0`` replaces it with a
NUL byte and ``--value-output`` converts decoded values to plain JSON.
``--unicode-output`` switches symbols such as the interactive mode's error
marker from ASCII to Unicode even when stdout is a pipe.
"""

from __future__ import annotations

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.


def test_default_output_is_pretty_printed():
    """Without flags the output is indented JSON."""
    res = run_fq(["-n", '{"a": [1, {"b": 2}],"c": null}'])
    # CATCHES: the default output uses two space indentation, keeps object key
    # order and puts one newline after every output value.
    assert res.returncode == 0
    assert res.stdout == (
        b'{\n  "a": [\n    1,\n    {\n      "b": 2\n    }\n  ],\n  "c": null\n}\n'
    )
    assert res.stderr == b""


def test_compact_output():
    """--compact-output removes all whitespace."""
    res = run_fq(["-c", "-n", '{"a": [1, {"b": 2}],"c": null}'])
    # CATCHES: compact output has no spaces at all, not even after commas or
    # colons.
    assert res.returncode == 0
    assert res.stdout == b'{"a":[1,{"b":2}],"c":null}\n'
    assert res.stderr == b""


def test_raw_output_only_affects_strings():
    """--raw-output unquotes strings but keeps other types as JSON."""
    res = run_fq(["-r", "-n", '1, "a", null, true, {"k": [1]}'])
    # CATCHES: -r is not a "print without quotes" switch; numbers, null,
    # booleans and containers are still printed as JSON.
    assert res.returncode == 0
    assert res.stdout == (
        b'1\na\nnull\ntrue\n{\n  "k": [\n    1\n  ]\n}\n'
    )
    assert res.stderr == b""


def test_raw_output_keeps_escape_sequences_unescaped():
    """--raw-output writes real control characters."""
    res = run_fq(["-r", "-n", '"a\\tb\\nc"'])
    # CATCHES: the JSON escapes \\t and \\n become a real tab and newline in
    # raw output instead of the two character sequences.
    assert res.returncode == 0
    assert res.stdout == b"a\tb\nc\n"
    assert res.stderr == b""


def test_join_output_removes_the_separator():
    """--join-output prints values back to back."""
    res = run_fq(["-j", "-n", '"a", "b", 1'])
    # CATCHES: --join-output sets the join string to the empty string, and it
    # also implies raw string output so the strings lose their quotes.
    assert res.returncode == 0
    assert res.stdout == b"ab1"
    assert res.stderr == b""


def test_raw_output0_uses_nul_separator():
    """--raw-output0 terminates each value with a NUL byte."""
    res = run_fq(["--raw-output0", "-n", '"a","b"'])
    # CATCHES: the NUL separator is written after every value including the
    # last one, and like --join-output it implies raw string output.
    assert res.returncode == 0
    assert res.stdout == b"a\x00b\x00"
    assert res.stderr == b""


def test_value_output_flag(tmp_path):
    """--value-output turns a decoded binary into JSON."""
    path = write_file(tmp_path, "b.bin", b"\x01\x02")
    res = run_fq(["-V", "-c", ".", "-d", "bytes", path])
    plain = run_fq(["-c", ".", "-d", "bytes", path])
    # CATCHES: without -V a decoded value is written as its raw bytes, with -V
    # the same value is printed as a JSON string with \\u escapes.
    assert res.returncode == 0
    assert res.stdout == b'"\\u0001\\u0002"\n'
    assert plain.returncode == 0
    assert plain.stdout == b"\x01\x02"


def test_value_output_with_raw_flag(tmp_path):
    """-Vr prints a string value raw but keeps the newline separator."""
    res = run_fq(["-Vr", "-n", '"abc"'])
    # CATCHES: the documented -Vr combination drops the JSON quotes but the
    # newline separator is still written after the value.
    assert res.returncode == 0
    assert res.stdout == b"abc\n"
    assert res.stderr == b""


def test_raw_binary_output(tmp_path):
    """Binary output is written as the raw bytes."""
    path = write_file(tmp_path, "b.bin", b"abcdefgh")
    res = run_fq(["-d", "bytes", "-c", "tobytes", path])
    # CATCHES: because stdout is not a terminal, raw output is considered safe
    # and tobytes writes the eight bytes verbatim with no quoting and no
    # trailing newline.
    assert res.returncode == 0
    assert res.stdout == b"abcdefgh"
    assert res.stderr == b""


def test_expression_from_file(tmp_path):
    """-f reads the expression from a file."""
    expr = write_file(tmp_path, "expr.jq", ".a\n")
    data = write_file(tmp_path, "in.json", '{"a": 42}\n')
    res = run_fq(["-f", expr, data])
    # CATCHES: the file content is used verbatim as the expression (including
    # its trailing newline) and the remaining arguments are all FILEs.
    assert res.returncode == 0
    assert res.stdout == b"42\n"
    assert res.stderr == b""


def test_expression_file_applies_to_every_file(tmp_path):
    """With -f every remaining argument is a FILE, not more expressions."""
    expr = write_file(tmp_path, "expr.jq", ".a\n")
    one = write_file(tmp_path, "one.json", '{"a": 1}\n')
    two = write_file(tmp_path, "two.json", '{"a": 2}\n')
    res = run_fq(["-f", expr, one, two])
    # CATCHES: once -f is given there is no positional expression, so both
    # following arguments are treated as input files.
    assert res.returncode == 0
    assert res.stdout == b"1\n2\n"
    assert res.stderr == b""


def test_expression_file_error_names_the_file(tmp_path):
    """A compile error in a -f file uses the file path as location."""
    expr = write_file(tmp_path, "bad.jq", "(")
    res = run_fq(["-f", expr, "-n", "1"])
    # CATCHES: the compile error location prefix is the expression file name
    # instead of the usual "arg".
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"error: %s:1:1: unexpected EOF\n" % expr.encode()


def test_repl_flag_exits_cleanly_on_eof():
    """--repl evaluates the final unterminated line and exits 0 at EOF."""
    res = run_fq(["-i", "-n", "0"], stdin="1+1\n2+2")
    # CATCHES: -i does not require a terminal; the last stdin line is still
    # evaluated when it has no trailing newline and EOF then terminates the
    # REPL with exit code 0.
    assert res.returncode == 0
    assert res.stdout == b"2\n4\n"
    assert res.stderr == b""


def test_repl_flag_evaluates_lines_from_stdin(tmp_path):
    """--repl evaluates each stdin line as a REPL expression."""
    data = write_file(tmp_path, "in.json", "1\n")
    res = run_fq(["-i", ".", data], stdin="1+1\n")
    # CATCHES: in non-interactive mode the REPL still evaluates the piped
    # lines against the value produced by the command line expression.
    assert res.returncode == 0
    assert res.stdout == b"2\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "stdin_text, output",
    [
        ("(\n7\n", b"        ^ unexpected EOF\n7\n"),
        ('error("x")\n8\n', b"error: x\n8\n"),
    ],
)
def test_repl_continues_after_an_error_line(stdin_text, output):
    """REPL errors are printed on stdout and the next line still runs."""
    res = run_fq(["-i", "-n", "0"], stdin=stdin_text)
    # CATCHES: a parse or runtime error in one REPL line does not abort the
    # REPL; the error text goes to stdout (not stderr) with the parse error
    # shown as a bare caret line, the next line is still evaluated and the
    # process exits 0.
    assert res.returncode == 0
    assert res.stdout == output
    assert res.stderr == b""


def test_eval_builtin():
    """The eval builtin compiles a string at runtime."""
    ok = run_fq(["-n", 'eval("1+1")'])
    bad = run_fq(["-n", 'eval("(")'])
    # CATCHES: eval compiles and runs its string argument normally, but a
    # parse error inside it is a runtime failure (exit 5, plain message)
    # unlike the same broken text on the command line which is a compile
    # error with an "arg:" location prefix and exit 3.
    assert ok.returncode == 0
    assert ok.stdout == b"2\n"
    assert ok.stderr == b""
    assert bad.returncode == 5
    assert bad.stdout == b""
    assert bad.stderr == b"error: unexpected EOF\n"


def test_hexdump_output(tmp_path):
    """hexdump renders a decoded value as an annotated hexdump."""
    path = write_file(tmp_path, "b.bin", b"abcdefgh")
    res = run_fq(["-d", "bytes", "hexdump", path])
    # CATCHES: hexdump writes a header line with the sixteen offset and byte
    # value columns, pads the hex and ascii columns of a short data line with
    # spaces so the columns stay aligned, and ends the data line with the
    # value annotation; it goes to stdout even though it is not JSON.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        b"|0123456789abcdef|\n"
        b"0x0|61 62 63 64 65 66 67 68|                       |abcdefgh|"
        b"       |.: raw bits 0x0-0x8 (8)\n"
    )


def test_hexdump_line_bytes_option(tmp_path):
    """The line_bytes option narrows the hexdump columns."""
    path = write_file(tmp_path, "b.bin", b"abcdefghijklmnop")
    res = run_fq(["-d", "bytes", "hexdump({line_bytes: 8})", path])
    # CATCHES: line_bytes: 8 shrinks the header to eight columns, widens the
    # address column to two digits and puts the value annotation at the end
    # of the first data line while later lines stop after the ascii column.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"    |00 01 02 03 04 05 06 07|01234567|\n"
        b"0x00|61 62 63 64 65 66 67 68|abcdefgh|.: raw bits 0x0-0x10 (16)\n"
        b"0x08|69 6a 6b 6c 6d 6e 6f 70|ijklmnop|\n"
    )


def test_unicode_output_flag_switches_the_repl_error_arrow():
    """-U replaces the ASCII caret with a Unicode arrow, even piped."""
    res = run_fq(["-U", "-i", "-n", "0"], stdin="(\n7\n")
    # CATCHES: the interactive compile error marker is drawn as U+2B06 (UTF-8
    # e2 ac 86) with --unicode-output even though stdout is a pipe, where the
    # automatic terminal detection would have kept the ASCII "^"; the second
    # line still evaluates normally and the session exits 0.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"        \xe2\xac\x86 unexpected EOF\n7\n"
