"""The -o/--option system: typing, files, defaults and precedence.

``-o NAME=VALUE`` values pass through the fuzzy converters in
``pkg/interp/options.jq``: a value that does not convert to the option's
declared type is silently dropped, string typed options may read their value
from ``@PATH``, and -o values always win over flag-parsed values because they
are merged last.
"""

from __future__ import annotations

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.

# The exact "--help options" table as printed by the reference build.
OPTIONS_TABLE = (
    b"addrbase            16\n"
    b"array_truncate      50\n"
    b"bits_format         string\n"
    b"byte_colors         0-255=default+bold,0=brightblack,32-126:9-13=default\n"
    b"color               false\n"
    b"colors              array=default,dumpaddr=yellow,dumpheader=yellow+underline,"
    b"error=brightred,false=yellow,index=default,null=brightblack,number=cyan,"
    b"object=default,objectkey=brightblue,prompt_repl_level=brightblack,"
    b"prompt_value=default,string=green,true=yellow,value=default\n"
    b"compact             false\n"
    b"completion_timeout  1\n"
    b"depth               0\n"
    b"display_bytes       16\n"
    b"force               false\n"
    b"join_string         \\n\n"
    b"line_bytes          16\n"
    b"raw_string          false\n"
    b"sizebase            10\n"
    b"skip_gaps           false\n"
    b"string_truncate     50\n"
    b"unicode             false\n"
    b"verbose             false\n"
    b"width               0\n"
)


def test_help_options_table():
    """-h options lists every non-internal option with its default."""
    res = run_fq(["-h", "options"])
    # CATCHES: the option table lists only the public options, right padded to
    # the same column, with defaults rendered as their command line spelling
    # (join_string shows the escaped \n, not a newline).
    assert res.returncode == 0
    assert res.stdout == OPTIONS_TABLE
    assert res.stderr == b""


@pytest.mark.parametrize(
    "value, expected",
    [
        ("hex", b"[\n  \"01\"\n]\n"),
        ("base64", b"[\n  \"AQ==\"\n]\n"),
        ("byte_array", b"[\n  [\n    1\n  ]\n]\n"),
        ("md5", b"[\n  \"55a54008ad1ba589aa210d2629c1df41\"\n]\n"),
        ("snippet", b"[\n  \"<1>AQ==\"\n]\n"),
    ],
)
def test_string_option_values(value, expected):
    """-o bits_format=VALUE selects how bits are represented."""
    res = run_fq(["-o", "bits_format=" + value, "-n", "[1|tobytes] | tovalue"])
    # CATCHES: the enumerated string option really changes the representation
    # of a binary value, each spelling producing a different output.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_invalid_enum_value_is_an_expression_error():
    """A bits_format outside the allowed set fails when used."""
    res = run_fq(["-o", "bits_format=nope", "-n", "[1|tobytes] | tovalue"])
    # CATCHES: the option value itself is accepted at parse time; the error
    # only appears when the value is turned into bits, and it is a value
    # error (exit 5) rather than an argument error.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b'error: invalid bits format "nope"\n'

    # When the implicit display path hits the same error it is wrapped in the
    # {"error": ..., "input": ...} value error object instead.
    res_display = run_fq(["-o", "bits_format=nope", "-n", "1"])
    assert res_display.returncode == 5
    assert res_display.stdout == b""
    assert res_display.stderr == (
        b'error: {"error":"invalid bits format \\"nope\\"","input":null}\n'
    )


def test_number_option_that_does_not_convert_is_dropped(tmp_path):
    """-o addrbase=abc leaves the default address base in place."""
    path = write_file(tmp_path, "b.bin", b"abcdefgh")
    res = run_fq(["-o", "addrbase=abc", "-d", "bytes", "display", path])
    # CATCHES: a value that fails tonumber is silently ignored, so addresses
    # keep the default base 16 (0x0) instead of erroring out.
    assert res.returncode == 0
    assert res.stdout == (
        b"   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n"
        b"0x0|61 62 63 64 65 66 67 68|                       |abcdefgh|       "
        b"|.: raw bits 0x0-0x8 (8)\n"
    )
    assert res.stderr == b""


def test_number_option_addrbase_10(tmp_path):
    """-o addrbase=10 renders addresses and the ruler in decimal."""
    path = write_file(tmp_path, "b.bin", b"abcdefgh")
    res = run_fq(["-o", "addrbase=10", "-d", "bytes", "display", path])
    # CATCHES: addrbase changes both the offset column and the byte ruler, and
    # the trailing description still uses base 16 for the bit range.
    assert res.returncode == 0
    assert res.stdout == (
        b" |00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15|0123456789012345|\n"
        b"0|61 62 63 64 65 66 67 68|                       |abcdefgh|       "
        b"|.: raw bits 0-8 (8)\n"
    )
    assert res.stderr == b""


def test_number_option_sizebase_16(tmp_path):
    """-o sizebase=16 renders the trailing size in hex."""
    path = write_file(tmp_path, "b.bin", b"abcdefgh")
    res = run_fq(["-o", "sizebase=16", "-d", "bytes", "display", path])
    # CATCHES: only the size in the trailing description switches base; the
    # address column is controlled separately by addrbase.
    assert res.returncode == 0
    assert res.stdout.endswith(b"|.: raw bits 0x0-0x8 (0x8)\n")
    assert res.stderr == b""


def test_number_option_line_bytes(tmp_path):
    """-o line_bytes=4 wraps the hexdump after four bytes."""
    path = write_file(tmp_path, "b.bin", b"abcdefgh")
    res = run_fq(["-o", "line_bytes=4", "-d", "bytes", "display", path])
    # CATCHES: line_bytes controls the ruler width and the number of output
    # lines, producing two lines with a second address column.
    assert res.returncode == 0
    assert res.stdout == (
        b"   |00 01 02 03|0123|\n"
        b"0x0|61 62 63 64|abcd|.: raw bits 0x0-0x8 (8)\n"
        b"0x4|65 66 67 68|efgh|\n"
    )
    assert res.stderr == b""


def test_option_value_from_file(tmp_path):
    """-o NAME=@PATH reads the option value from a file."""
    write_file(tmp_path, "bf.txt", "hex")
    res = run_fq(
        ["-o", "bits_format=@bf.txt", "-n", "[1|tobytes] | tovalue"],
        cwd=str(tmp_path),
    )
    # CATCHES: the @PATH form is resolved relative to the working directory and
    # the file content is used verbatim as the option value.
    assert res.returncode == 0
    assert res.stdout == b"[\n  \"01\"\n]\n"
    assert res.stderr == b""


def test_option_value_from_missing_file_is_an_args_error(tmp_path):
    """-o NAME=@PATH with a missing file aborts with exit code 2."""
    res = run_fq(
        ["-o", "bits_format=@nope.txt", "-n", "1"], cwd=str(tmp_path)
    )
    # CATCHES: the diagnostic echoes the whole -o NAME=@PATH assignment before
    # the open error, and uses the argument error exit code.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"error: -o bits_format=@nope.txt: no such file or directory\n"
    )


def test_option_value_from_file_only_for_string_types(tmp_path):
    """@PATH is not expanded for options whose type is not string."""
    res = run_fq(["-o", "color=@nope.txt", "-n", "1"], cwd=str(tmp_path))
    # CATCHES: only string typed options keep an "@..." value through the type
    # conversion, so for a boolean option the assignment is dropped instead of
    # trying to open the file.
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_option_overrides_a_flag_regardless_of_order():
    """-o compact=false beats -c even when it comes first."""
    res_first = run_fq(["-o", "compact=false", "-c", "-n", '{"a":1}'])
    res_last = run_fq(["-c", "-o", "compact=false", "-n", '{"a":1}'])
    # CATCHES: -o values are merged after the parsed flags, so they win no
    # matter where on the command line they appear.
    for res in (res_first, res_last):
        assert res.returncode == 0
        assert res.stdout == b'{\n  "a": 1\n}\n'
        assert res.stderr == b""


def test_repeated_option_last_one_wins():
    """The same -o key given twice keeps the last value."""
    res = run_fq(["-o", "join_string=-", "-o", "join_string=_", "-n", '"x","y"'])
    # CATCHES: repeated keys are merged left to right, so the final value of
    # join_string is "_" and it is also appended after the last output.
    assert res.returncode == 0
    assert res.stdout == b'"x"_"y"_'
    assert res.stderr == b""


def test_option_value_may_contain_equals():
    """Only the first "=" separates the option name from its value."""
    res = run_fq(["-o", "join_string=a=b", "-n", '"x","y"'])
    # CATCHES: the value is everything after the first "=", so "a=b" is used
    # verbatim as the join string.
    assert res.returncode == 0
    assert res.stdout == b'"x"a=b"y"a=b'
    assert res.stderr == b""


def test_unknown_option_key_is_ignored():
    """-o with a key that is not an option is accepted and unused."""
    res = run_fq(["-o", "not_an_option=1", "-n", "1"])
    # CATCHES: unknown keys are passed through the fuzzy converter and then
    # simply ignored; they are not a "no such option" error.
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_boolean_option_number_coercion():
    """-o color=1 is truthy, -o color=0 is false."""
    truthy = run_fq(["-o", "color=1", "-n", "1"])
    falsy = run_fq(["-o", "color=0", "-n", "1"])
    # CATCHES: non "true"/"false" boolean values fall back to tonumber != 0,
    # and the number 1 is colourised cyan when the option is on.
    assert truthy.returncode == 0
    assert truthy.stdout == b"\x1b[36m1\x1b[m\n"
    assert falsy.returncode == 0
    assert falsy.stdout == b"1\n"


def test_monochrome_flag_beats_color_option():
    """-M wins over both -o color=true and -C."""
    res_option = run_fq(["-o", "color=true", "-M", "-n", "1"])
    res_flag = run_fq(["-C", "-M", "-n", "1"])
    res_flag_rev = run_fq(["-M", "-C", "-n", "1"])
    # CATCHES: monochrome is checked first when computing the effective colour
    # option, so it wins over --color-output and -o color=true in any order.
    for res in (res_option, res_flag, res_flag_rev):
        assert res.returncode == 0
        assert res.stdout == b"1\n"
        assert res.stderr == b""


def test_color_option_object_overrides_scheme():
    """-o colors=null=blue replaces the colour of null."""
    res = run_fq(["-C", "-o", "colors=null=blue", "-n", "null"])
    # CATCHES: the csv key=value list replaces the whole colour scheme entry,
    # so null is printed blue instead of the default bright black.
    assert res.returncode == 0
    assert res.stdout == b"\x1b[34mnull\x1b[m\n"

    default = run_fq(["-C", "-n", "null"])
    assert default.stdout == b"\x1b[90mnull\x1b[m\n"


def test_width_option_wraps_help_markdown():
    """-o width=40 wraps the markdown documentation of -h TOPIC."""
    wide = run_fq(["-h", "bytes"])
    narrow = run_fq(["-o", "width=40", "-h", "bytes"])
    # CATCHES: the embedded markdown doc is re-wrapped to the terminal width
    # option, so the same topic renders differently under a narrow width.
    assert wide.returncode == 0
    assert narrow.returncode == 0
    assert (
        b"Decode to a slice and indexable binary of bytes.\n" in wide.stdout
    )
    assert (
        b"Decode to a slice and indexable binary\nof bytes.\n" in narrow.stdout
    )


def test_csv_ranges_option_is_accepted(tmp_path):
    """-o byte_colors=RANGES is parsed and used by the hexdump."""
    path = write_file(tmp_path, "b.bin", b"ab")
    res = run_fq(
        ["-C", "-o", "byte_colors=0-255=blue", "-d", "bytes", "display", path]
    )
    # CATCHES: the csv range list colourises the byte columns of the hexdump;
    # every byte is wrapped in the blue escape sequence.
    assert res.returncode == 0
    assert res.stdout.startswith(b"   |\x1b[33;4m00 01")
    assert b"\x1b[34m61\x1b[39m \x1b[34m62\x1b[39m" in res.stdout


def test_join_string_option_between_outputs():
    """-o join_string=X is emitted after every output."""
    res = run_fq(["-o", "join_string=;", "-n", '"a","b"'])
    # CATCHES: the join string is printed after each output value including the
    # last one, replacing the default newline.
    assert res.returncode == 0
    assert res.stdout == b'"a";"b";'
    assert res.stderr == b""


def test_per_format_option_is_accepted(tmp_path):
    """-o can set a decoder specific option."""
    res = run_fq(["-o", "max_sync_seek=1", "-d", "mp3", "-n", "2"])
    # CATCHES: options that only exist for a single decoder are accepted by the
    # generic -o parser (they are not in the global option table) and do not
    # change the evaluated output.
    assert res.returncode == 0
    assert res.stdout == b"2\n"
    assert res.stderr == b""


def test_bits_format_truncate_caps_the_value_at_1024_bytes(tmp_path):
    """bits_format=truncate limits the string bits format to 1024 bytes."""
    path = write_file(tmp_path, "b.bin", b"x" * 1030)
    res = run_fq(
        ["-d", "bytes", "-o", "bits_format=truncate", "-c", "tovalue | length", path]
    )
    # CATCHES: the truncate bits format copies at most 1024 bytes of the
    # value into the string, so a longer input is silently cut instead of
    # erroring.
    assert res.returncode == 0
    assert res.stdout == b"1024\n"
    assert res.stderr == b""


def test_invalid_bits_format_is_an_expression_error(tmp_path):
    """An unknown bits_format value fails when the value is displayed."""
    path = write_file(tmp_path, "b.bin", b"ab")
    res = run_fq(["-d", "bytes", "-o", "bits_format=bogus", ".", path])
    # CATCHES: the enum is validated lazily when the value is displayed, and
    # the failure is an expression error (exit 5) whose message is the JSON
    # object holding the error text and the input it happened for.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b'error: {"error":"invalid bits format \\"bogus\\"","input":null}\n'
    )
