"""Standard stream builtins, readline/history and halt_error (interp.go).

The jq level exposes the three standard streams through ``_stdin``/
``_stdout``/``_stderr``: with a length argument they read raw bytes from the
stream, with ``null`` input they report terminal metadata, and as a sink they
write values.  ``_readline`` reads one line without its newline, ``history``
reads the persistent readline history and ``halt_error`` stops evaluation
with a value on stderr and a chosen exit code.  The interactive mode also
has the ``slurp``/``spew`` value store, which keeps results as variables
across the lines of one session.
"""

from __future__ import annotations

import signal
import subprocess
import time

import pytest

from conftest import executable_path, pinned_env, run_fq, run_fq_tty

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize(
    "expr, stderr",
    [
        ("halt_error", b""),
        ('"boom" | halt_error', b"boom"),
        ('{"a":1} | halt_error', b'{"a":1}\n'),
    ],
)
def test_halt_error_writes_the_value_to_stderr(expr, stderr):
    """halt_error stops evaluation with the value on stderr and exit 5."""
    res = run_fq(["-n", expr])
    # CATCHES: a string halt value is written verbatim without a trailing
    # newline, any other value is written as compact JSON with a newline and
    # halt_error of null writes nothing; the exit code is always 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == stderr


def test_halt_error_with_exit_code():
    """halt_error(N) uses N as the process exit code."""
    res = run_fq(["-n", '"x" | halt_error(7)'])
    # CATCHES: the argument overrides the default exit code 5 while the value
    # is still written to stderr without a trailing newline.
    assert res.returncode == 7
    assert res.stdout == b""
    assert res.stderr == b"x"


@pytest.mark.parametrize(
    "expr",
    ["_readline({})", '_readline({prompt: "P> "})'],
)
def test_readline_reads_one_line_without_the_newline(expr):
    """_readline returns the line as a JSON string on a non-terminal stdin."""
    res = run_fq(["-n", expr], stdin="hello\n")
    # CATCHES: the trailing newline is stripped, the result is a JSON string
    # value, and the prompt is only ever drawn on a real terminal so neither
    # stdout nor stderr contains it when stdin is a pipe.
    assert res.returncode == 0
    assert res.stdout == b'"hello"\n'
    assert res.stderr == b""


def test_readline_at_eof_is_an_expression_error():
    """_readline on a closed stdin reports the eof error."""
    res = run_fq(["-n", "_readline({})"], stdin="")
    # CATCHES: EOF is surfaced as the jq error "eof" with exit code 5, not as
    # an empty string or a silent stop.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: eof\n"


def test_stdin_read_of_available_bytes_yields_string_then_null():
    """_stdin(N) reads N bytes and then outputs the nil error slot."""
    res = run_fq(["-n", "_stdin(3)"], stdin="abcdef")
    # CATCHES: reading raw stdin yields the bytes as a JSON string followed
    # by a second value that is null when the read was fully satisfied.
    assert res.returncode == 0
    assert res.stdout == b'"abc"\nnull\n'
    assert res.stderr == b""


def test_stdin_read_past_eof_is_an_expression_error():
    """_stdin(N) with fewer than N bytes available fails with eof."""
    res = run_fq(["-n", "_stdin(9)"], stdin="abc")
    # CATCHES: the short read still outputs the bytes that were available and
    # then fails with the eof error and exit code 5.
    assert res.returncode == 5
    assert res.stdout == b'"abc"\n'
    assert res.stderr == b"error: eof\n"


@pytest.mark.parametrize(
    "expr",
    ["null | _stdin", "null | _stdout", 'null | _stdio("stderr")'],
)
def test_stdio_info_reports_non_terminal_for_pipes(expr):
    """Stream info on pipes reports is_terminal false and a 0x0 size."""
    res = run_fq(["-c", "-n", expr])
    # CATCHES: the info map has exactly the three keys height, is_terminal
    # and width, and a pipe is reported as a non-terminal with zero size.
    assert res.returncode == 0
    assert res.stdout == b'{"height":0,"is_terminal":false,"width":0}\n'
    assert res.stderr == b""


def test_stdio_info_reports_the_terminal_size():
    """Stream info on a terminal reports the real window size."""
    code, out = run_fq_tty(["-M", "-c", "-n", "null | _stdin"])
    # CATCHES: on an 80x24 terminal is_terminal is true and the reported
    # width and height are the terminal's, not zeros.
    assert code == 0
    assert out == b'{"height":24,"is_terminal":true,"width":80}\r\n'


@pytest.mark.parametrize(
    "expr",
    ['null | _stdio("bogus")', '_stdio("bogus"; 2)'],
)
def test_unknown_fd_name_is_an_expression_error(expr):
    """An unknown stream name fails with "unknown fd"."""
    res = run_fq(["-n", expr])
    # CATCHES: only stdin/stdout/stderr are valid stream names and anything
    # else is an expression error with exit code 5.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: unknown fd bogus\n"


@pytest.mark.parametrize(
    "expr, stderr",
    [
        ("_stdout(2)", b"error: stdout is not a writeable\n"),
        ('"x" | _stdin', b"error: stdin is not a writeable\n"),
    ],
)
def test_stream_used_in_the_wrong_direction_is_an_error(expr, stderr):
    """Reading a write-only stream or writing a read-only one errors."""
    res = run_fq(["-n", expr])
    # CATCHES: the streams are directional; using them the wrong way round is
    # an expression error whose (historical) message says "is not a
    # writeable" for both directions.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == stderr


@pytest.mark.parametrize(
    "expr, stdout, stderr",
    [
        ('("a","b") | println', b"a\nb\n", b""),
        ('("a","b") | print', b"ab", b""),
        ('("a","b") | printerrln', b"", b"a\nb\n"),
        ('("a","b") | printerr', b"", b"ab"),
        ('("a","b") | stderr', b'"a"\n"b"\n', b"ab"),
    ],
)
def test_print_family_writes_to_the_right_stream(expr, stdout, stderr):
    """print/println write stdout, printerr/printerrln write stderr."""
    res = run_fq(["-n", expr])
    # CATCHES: print writes with no separator at all, println appends one
    # newline per value, the printerr variants mirror them on stderr, and the
    # jq compat stderr filter lets its input through to stdout while copying
    # the raw string values to stderr.
    assert res.returncode == 0
    assert res.stdout == stdout
    assert res.stderr == stderr


def test_history_without_a_readline_session_is_an_error():
    """history before any readline has no history file to read."""
    res = run_fq(["-n", "history"])
    # CATCHES: the history file is only configured once a readline has
    # happened in the same process, so plain history fails with an open error
    # naming the empty path.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: open : no such file or directory\n"


def test_readline_line_is_persisted_to_history(tmp_path):
    """A line read by _readline is saved and returned by history."""
    res = run_fq(
        ["-c", "-n", "_readline({}) as $l | history"],
        stdin="x\n",
        extra={
            "HOME": str(tmp_path),
            "XDG_CACHE_HOME": str(tmp_path / "cache"),
        },
    )
    # CATCHES: a non-terminal readline still appends the line to the history
    # file under the OS cache dir (creating it) and history reads it back as
    # an array of strings.
    assert res.returncode == 0
    assert res.stdout == b'["x"]\n'
    assert res.stderr == b""
    assert (tmp_path / "cache" / "fq" / "history").read_bytes() == b"x\n"


def test_sigint_interrupts_evaluation_with_exit_5():
    """SIGINT stops an endless expression with exit code 5 and no message."""
    proc = subprocess.Popen(
        [executable_path(), "-n", "repeat(1)"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=pinned_env(),
    )
    time.sleep(0.3)
    proc.send_signal(signal.SIGINT)
    out, err = proc.communicate(timeout=10)
    # CATCHES: the interrupt is caught by the interpreter (not the default
    # signal disposition), ends the run with the expression error exit code 5
    # and prints no error message; the values already produced stay on
    # stdout.
    assert proc.returncode == 5
    assert err == b""
    assert out != b""
    assert set(out) <= {ord("1"), ord("\n")}


def test_writing_to_an_unknown_fd_name_is_an_expression_error():
    """The write form of _stdio rejects unknown stream names too."""
    res = run_fq(["-n", '"x" | _stdio("bogus")'])
    # CATCHES: unlike the info and read forms already covered above, writing
    # to a made-up name fails at the write sink with the same "unknown fd"
    # message and exit code 5, and nothing of the value reaches stdout.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: unknown fd bogus\n"


def test_slurp_prints_nothing_and_binds_the_wrapped_value():
    """A slurp line prints nothing and binds the value wrapped in an array."""
    res = run_fq(["-i", "-n", "0"], stdin='1 | slurp("a")\n$a\n$a\n')
    # CATCHES: the slurp line itself outputs empty (nothing is displayed for
    # it), and the variable it binds holds the value wrapped in an array, so
    # every later line reading $a prints [1] rather than 1.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"[\n  1\n]\n[\n  1\n]\n"


def test_spew_unwraps_a_slurped_value_but_keeps_it_bound():
    """spew prints the bare slurped value and leaves the variable intact."""
    res = run_fq(
        ["-i", "-n", "0"], stdin='1 | slurp("a")\nspew("a")\n$a\n'
    )
    # CATCHES: spew unwraps the stored array for its own output (printing 1
    # where $a would print [1]) but does not remove the slurp, so $a still
    # resolves to the wrapped value on the next line.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"1\n[\n  1\n]\n"


def test_a_slurp_variable_exists_only_after_its_slurp_line():
    """Referencing a slurp variable before slurping is a compile error."""
    res = run_fq(["-i", "-n", "0"], stdin="$a\n")
    # CATCHES: the slurp variables are bound when a line is compiled from the
    # slurps stored so far, so a name that was never slurped fails to compile
    # (not an empty or null value) and, like other interactive line errors,
    # is printed to stdout while the session still exits 0.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"error: expr: variable not defined: $a\n"


def test_slurp_rejects_a_name_that_is_not_an_identifier():
    """A slurp name must be a valid identifier."""
    res = run_fq(["-i", "-n", "0"], stdin='1 | slurp("not an ident")\n')
    # CATCHES: the name is checked with the identifier rules before anything
    # is stored; the message spells out the expected shape and, like every
    # interactive line error, goes to stdout and does not change the exit
    # code of the session.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"error: expr: invalid slurp name \"not an ident\", "
        b"must be a valid identifier. ex: ... | slurp(\"name\")\n"
    )


def test_spew_of_an_unknown_slurp_is_an_error():
    """spew of a name nobody slurped reports the missing slurp."""
    res = run_fq(["-i", "-n", "0"], stdin='spew("nope")\n')
    # CATCHES: spew only looks at the per-session slurp store, so a name that
    # was never slurped fails with "no such slurp" (printed to stdout like
    # other interactive line errors, exit code still 0).
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"error: no such slurp: nope\n"
