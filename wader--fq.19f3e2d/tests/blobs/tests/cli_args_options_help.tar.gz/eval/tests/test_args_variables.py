"""Predefined variables: --arg/--argjson/--argdecode/--raw-file and $ARGS.

These flags feed values into the evaluated program.  Their order independent
merging rules (``pkg/interp/init.jq``) and the shape of ``$ARGS`` are pinned
here, including the fact that the *first* definition of a duplicated name wins.
"""

from __future__ import annotations

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.


def test_arg_defines_a_string_variable():
    """--arg NAME VALUE binds $NAME to a string."""
    res = run_fq(["--arg", "greeting", "hi", "-n", "$greeting"])
    # CATCHES: --arg values keep their string type, they are not parsed as
    # JSON, so $greeting is the quoted string "hi".
    assert res.returncode == 0
    assert res.stdout == b'"hi"\n'
    assert res.stderr == b""


def test_args_named_object():
    """$ARGS.named collects every predefined variable."""
    res = run_fq(
        ["--arg", "a", "b", "--argjson", "j", '{"k":1}', "-n", "-c", "$ARGS"]
    )
    # CATCHES: $ARGS is exactly {named: {...}, positional: [...]} with the
    # --arg string and the parsed --argjson object side by side.
    assert res.returncode == 0
    assert res.stdout == b'{"named":{"a":"b","j":{"k":1}},"positional":[]}\n'
    assert res.stderr == b""


def test_args_default_shape():
    """With no argument flags $ARGS is empty but still structured."""
    res = run_fq(["-n", "-c", "$ARGS"])
    # CATCHES: $ARGS always exists and always has both keys, even when no
    # --arg/--args style flag was given.
    assert res.returncode == 0
    assert res.stdout == b'{"named":{},"positional":[]}\n'
    assert res.stderr == b""


@pytest.mark.parametrize(
    "json_text, expected",
    [
        ("1", b"1\n"),
        ("null", b"null\n"),
        ("[1,2]", b"[\n  1,\n  2\n]\n"),
        ('"s"', b'"s"\n'),
        ("true", b"true\n"),
    ],
)
def test_argjson_parses_json_values(json_text, expected):
    """--argjson NAME JSON stores the parsed JSON value."""
    res = run_fq(["--argjson", "n", json_text, "-n", "$n"])
    # CATCHES: the second token of --argjson is run through fromjson, so
    # numbers, null, arrays, strings and booleans all keep their JSON types.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


@pytest.mark.parametrize(
    "json_text",
    ["nope", "1 2"],
)
def test_argjson_invalid_json_is_an_args_error(json_text):
    """Bad JSON for --argjson is a fatal argument error (exit 2)."""
    res = run_fq(["--argjson", "n", json_text, "-n", "1"])
    # CATCHES: an unparsable --argjson value never reaches the expression; it
    # aborts with exit code 2 and the message names the flag and the variable.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stdout == b""
    assert res.stderr.startswith(b"error: --argjson n: fromjson cannot be applied")


def test_raw_file_reads_file_as_string(tmp_path):
    """--raw-file NAME PATH stores the file content as a string."""
    path = write_file(tmp_path, "note.txt", "line\n")
    res = run_fq(["--raw-file", "rf", path, "-n", "$rf"])
    # CATCHES: --raw-file keeps the raw bytes as a jq string including the
    # trailing newline; it is not decoded as a format.
    assert res.returncode == 0
    assert res.stdout == b'"line\\n"\n'
    assert res.stderr == b""


def test_raw_file_missing_path_is_an_args_error(tmp_path):
    """--raw-file with a missing file aborts with exit code 2."""
    res = run_fq(["--raw-file", "rf", str(tmp_path / "nope"), "-n", "1"])
    # CATCHES: unlike --argjson the --raw-file diagnostic has no flag prefix,
    # it is just the path and the open error.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"error: %s: no such file or directory\n" % str(tmp_path / "nope").encode()
    )


def test_argdecode_decodes_a_file(tmp_path):
    """--argdecode NAME PATH stores the decoded format value."""
    path = write_file(tmp_path, "in.json", '{"a": 1}\n')
    res = run_fq(["--argdecode", "d", path, "-n", "-c", "$d"])
    # CATCHES: --argdecode runs the normal probe decode on the file, so a JSON
    # file becomes a real jq object, not a string.
    assert res.returncode == 0
    assert res.stdout == b'{"a":1}\n'
    assert res.stderr == b""


def test_argdecode_missing_path_is_an_args_error(tmp_path):
    """--argdecode with a missing file names the flag and the variable."""
    res = run_fq(["--argdecode", "d", str(tmp_path / "nope"), "-n", "1"])
    # CATCHES: the --argdecode diagnostic does carry the flag and variable
    # name prefix, unlike --raw-file.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"error: --argdecode d: no such file or directory\n"
    )


def test_argdecode_directory_is_an_args_error(tmp_path):
    """--argdecode on a directory reports the read error."""
    res = run_fq(["--argdecode", "d", str(tmp_path), "-n", "1"])
    # CATCHES: opening a directory fails with "read <path>: is a directory"
    # and still exits with the argument error code 2.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b"error: --argdecode d: read %s: is a directory\n" % str(tmp_path).encode()
    )


def test_first_definition_of_a_duplicated_name_wins():
    """Repeated --arg for the same name keeps the first value."""
    res = run_fq(["--arg", "a", "1", "--arg", "a", "2", "-n", "$a"])
    # CATCHES: the pair lists are reversed before being turned into an object,
    # so the first occurrence on the command line has priority.
    assert res.returncode == 0
    assert res.stdout == b'"1"\n'
    assert res.stderr == b""


def test_variable_kind_precedence_is_argjson_over_argdecode(tmp_path):
    """argjson beats arg, which beats raw-file, which beats argdecode."""
    text = write_file(tmp_path, "t.txt", "raw\n")
    decoded = write_file(tmp_path, "d.json", '"decoded"\n')
    res = run_fq(
        [
            "--argdecode", "v", decoded,
            "--raw-file", "v", text,
            "--arg", "v", "arg",
            "--argjson", "v", "9",
            "-n", "$v",
        ]
    )
    # CATCHES: the merge order of the four variable flags is fixed and
    # independent of their position on the command line.
    assert res.returncode == 0
    assert res.stdout == b"9\n"

    res2 = run_fq(
        ["--argjson", "v", "9", "--arg", "v", "arg", "-n", "$v"]
    )
    assert res2.stdout == b"9\n"

    res3 = run_fq(
        ["--arg", "v", "arg", "--raw-file", "v", text, "-n", "$v"]
    )
    assert res3.stdout == b'"arg"\n'

    res4 = run_fq(
        ["--raw-file", "v", text, "--argdecode", "v", decoded, "-n", "$v"]
    )
    assert res4.stdout == b'"raw\\n"\n'


def test_args_flag_makes_remaining_arguments_positional():
    """--args turns the rest of argv into $ARGS.positional strings."""
    res = run_fq(["-n", "--args", "$ARGS.positional", "x", "y", "1"])
    # CATCHES: the first value after --args is used as the EXPRESSION and is
    # dropped from the positional list, the rest stay strings.
    assert res.returncode == 0
    assert res.stdout == b'[\n  "x",\n  "y",\n  "1"\n]\n'
    assert res.stderr == b""


def test_jsonargs_parses_each_argument_as_json():
    """--jsonargs turns the rest of argv into parsed JSON values."""
    res = run_fq(
        ["-n", "--jsonargs", "$ARGS.positional", "1", '{"a":2}', "[3]"]
    )
    # CATCHES: every positional is run through fromjson, producing numbers and
    # containers instead of strings.
    assert res.returncode == 0
    assert res.stdout == b"[\n  1,\n  {\n    \"a\": 2\n  },\n  [\n    3\n  ]\n]\n"
    assert res.stderr == b""


def test_jsonargs_invalid_json_is_an_args_error():
    """A non-JSON positional under --jsonargs aborts with exit code 2."""
    res = run_fq(["-n", "--jsonargs", "$ARGS.positional", "1", "x"])
    # CATCHES: the whole run is aborted, not just that argument; the message
    # names the flag and the offending text.
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr == (
        b'error: --jsonargs x: fromjson cannot be applied to "x": '
        b"invalid character 'x' looking for beginning of value\n"
    )


def test_last_positional_mode_wins():
    """--args followed by --jsonargs collects the rest as JSON."""
    res = run_fq(["-n", "--args", "--jsonargs", "$ARGS", "1", "2"])
    # CATCHES: --args and --jsonargs switch the positional collector, so the
    # last one given decides how following arguments are typed; the expression
    # is still the first collected value.
    assert res.returncode == 0
    assert res.stdout == b'{\n  "named": {},\n  "positional": [\n    1,\n    2\n  ]\n}\n'
    assert res.stderr == b""


def test_args_after_expression_leaves_no_files(tmp_path):
    """--args swallows arguments that would otherwise be FILEs."""
    write_file(tmp_path, "in.json", "1\n")
    res = run_fq([".", "--args", "x", "y"], stdin='"from stdin"')
    # CATCHES: once --args is seen the remaining arguments become positionals,
    # so no FILE argument is left and fq falls back to reading stdin.
    assert res.returncode == 0
    assert res.stdout == b'"from stdin"\n'
    assert res.stderr == b""
