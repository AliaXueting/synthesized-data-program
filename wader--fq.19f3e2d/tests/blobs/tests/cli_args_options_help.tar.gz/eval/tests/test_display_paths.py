"""Value display paths: dump field names, hexdump and JSON-with-values.

``dump``/``d`` of a decoded *sub* value labels the root of the dump with the
value's path from the format root (``.chunks[0]``, ``.chunks[0].length``),
``hexdump`` works on any value that can be turned into bits (including plain
numbers), and printing a binary or decoded value nested inside a normal
JSON structure converts it in place instead of dumping it.
"""

from __future__ import annotations

import struct
import zlib

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.


def _png_bytes():
    """Return a minimal two-chunk PNG (signature, IHDR, IEND)."""

    def chunk(tag, data):
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data))
        )

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", 2, 1, 8, 0, 0, 0, 0))
        + chunk(b"IEND", b"")
    )


def test_dump_of_an_array_subvalue_shows_the_index_path(tmp_path):
    """d of a sub value labels the dump with its path from the root."""
    write_file(tmp_path, "t.png", _png_bytes())
    res = run_fq(["-d", "png", ".chunks[0] | d", "t.png"], cwd=str(tmp_path))
    # CATCHES: the dump root is named ".chunks[0]" - the object key from the
    # parent compound and the array index in bracket notation - and the hex
    # and ASCII columns are renumbered from 0x00 for the sub value.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        b"|0123456789abcdef|.chunks[0]{}: chunk\n"
        b"0x00|                        00 00 00 0d            "
        b"|        ....    |  length: 13\n"
        b"0x00|                                    49 48 44 52"
        b"|            IHDR|  type: \"IHDR\"\n"
        b"0x00|                                    49         "
        b"|            I   |  ancillary: false\n"
        b"0x00|                                       48      "
        b"|             H  |  private: false\n"
        b"0x00|                                          44   "
        b"|              D |  reserved: false\n"
        b"0x00|                                             52"
        b"|               R|  safe_to_copy: false\n"
        b"0x10|00 00 00 02                                    "
        b"|....            |  width: 2\n"
        b"0x10|            00 00 00 01                        "
        b"|    ....        |  height: 1\n"
        b"0x10|                        08                     "
        b"|        .       |  bit_depth: 8\n"
        b"0x10|                           00                  "
        b"|         .      |  color_type: \"grayscale\" (0)\n"
        b"0x10|                              00               "
        b"|          .     |  compression_method: \"deflate\" (0)\n"
        b"0x10|                                 00            "
        b"|           .    |  filter_method: \"adaptive_filtering\" (0)\n"
        b"0x10|                                    00         "
        b"|            .   |  interlace_method: \"none\" (0)\n"
        b"0x10|                                       d1 49 20"
        b"|             .I |  crc: 0xd1492056 (valid)\n"
        b"0x20|56                                             "
        b"|V               |\n"
    )


def test_dump_path_joins_a_key_after_an_index_with_a_dot(tmp_path):
    """A field reached through an array index is joined with a dot."""
    write_file(tmp_path, "t.png", _png_bytes())
    res = run_fq(
        ["-d", "png", ".chunks[0].length | d", "t.png"], cwd=str(tmp_path)
    )
    # CATCHES: the root name is ".chunks[0].length": a string key following
    # an array index is separated with "." while the index itself keeps its
    # bracket form, and the scalar dump shows the 4 length bytes as 13.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        b"|0123456789abcdef|\n"
        b"0x0|                        00 00 00 0d            "
        b"|        ....    |.chunks[0].length: 13\n"
    )


def test_hexdump_of_a_number_dumps_its_bits():
    """hexdump accepts a plain number and dumps its minimal bit pattern."""
    res = run_fq(["-n", "1 | hexdump"])
    # CATCHES: the number 1 is turned into a one-bit binary whose byte is
    # 0x80 (the bit is left aligned in the byte) and hexdump renders it as
    # "raw bits 0x0-0x0.1 (0.1)" with a single hex column entry.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == (
        b"   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        b"|0123456789abcdef|\n"
        b"0x0|80|                                            "
        b"|.|              |.: raw bits 0x0-0x0.1 (0.1)\n"
    )


def test_hexdump_of_a_non_binary_value_is_an_expression_error():
    """hexdump of a value that is not a binary is an expression error."""
    res = run_fq(["-n", "null | hexdump"])
    # CATCHES: null cannot be converted to a binary value, so hexdump fails
    # lazily at display time with exit code 5 (not an argument error).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: value can't be a binary\n"


def test_hexdump_rejects_an_invalid_bits_format_option():
    """hexdump checks its option argument like the display path does."""
    res = run_fq(["-n", '1 | hexdump({bits_format: "nope"})'])
    # CATCHES: an unknown bits_format in the hexdump options is rejected
    # before anything is rendered, with the same message as the -o flag
    # variant but as an expression error (exit 5).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b'error: invalid bits format "nope"\n'


@pytest.mark.parametrize(
    "argv, expected",
    [
        (["-n", "[1|tobytes]"], b'[\n  "\\u0001"\n]\n'),
        (["-o", "bits_format=hex", "-n", "[1|tobytes]"], b'[\n  "01"\n]\n'),
    ],
)
def test_printing_a_binary_inside_json_applies_the_bits_format(argv, expected):
    """A binary nested in a printed JSON value is converted in place."""
    res = run_fq(argv)
    # CATCHES: an array is not a displayable value, so it is printed as
    # JSON and the binary element inside it is converted using the bits
    # format option - the default renders the raw bytes as a JSON string
    # escape, bits_format=hex renders "01".
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == expected


def test_printing_a_decoded_value_inside_json(tmp_path):
    """A decoded format value nested in JSON prints as its plain value."""
    write_file(tmp_path, "o.json", '{"a":1}')
    res = run_fq(["-d", "json", "{j: json}", "o.json"], cwd=str(tmp_path))
    # CATCHES: putting the decoded json value inside an object prints the
    # object as JSON with the decoded value converted to its plain jq value
    # in place, rather than dumping or hexdumping it.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'{\n  "j": {\n    "a": 1\n  }\n}\n'
