"""include/import module loading (the module loader in pkg/interp/interp.go).

An included name gets ".jq" appended and is resolved against "./", the -L
paths, or absolutely; "@config/" resolves against the OS configuration
directory.  A trailing "?" in the name makes a missing module non fatal, a
file whose root is an expression is a dynamic include that must evaluate to
one string, and parse errors inside a module are compile errors that name
the module file.
"""

from __future__ import annotations

import pytest

from conftest import run_fq, write_file, write_tree

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize(
    "expr",
    ['include "mod"; f', 'import "mod" as m; m::f'],
)
def test_include_and_import_load_definitions(tmp_path, expr):
    """include brings definitions in, import binds them under a namespace."""
    write_file(tmp_path, "mod.jq", "def f: 42;\n")
    res = run_fq(["-n", expr], cwd=str(tmp_path))
    # CATCHES: include puts the definitions in the current scope while import
    # hides them behind the "m::" prefix, and both resolve mod to mod.jq in
    # the working directory.
    assert res.returncode == 0
    assert res.stdout == b"42\n"
    assert res.stderr == b""


@pytest.mark.parametrize("from_file", [False, True])
def test_include_parse_error_is_a_compile_error(tmp_path, from_file):
    """A parse error in an included file is a compile error naming it."""
    write_file(tmp_path, "bad.jq", "(\n")
    if from_file:
        expr_file = write_file(tmp_path, "expr.jq", 'include "bad"; 1\n')
        res = run_fq(["-f", expr_file, "-n"], cwd=str(tmp_path))
        prefix = (expr_file + ":").encode()
    else:
        res = run_fq(["-n", 'include "bad"; 1'], cwd=str(tmp_path))
        prefix = b"arg:"
    # CATCHES: the error location is "<expression location>: bad.jq:2:0:" so
    # it shows both where the include was written and the position inside the
    # included file (the EOF after the "(\n" line), plus the "parse:" kind,
    # with the compile error exit code 3.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"error: " + prefix + b" bad.jq:2:0: parse: unexpected EOF\n"


@pytest.mark.parametrize(
    "name, rc, stdout, stderr",
    [
        ("nope", 3, b"", b"error: arg: open nope.jq: file does not exist\n"),
        ("nope?", 0, b"1\n", b""),
    ],
)
def test_missing_include_is_fatal_only_without_a_question_mark(
    tmp_path, name, rc, stdout, stderr
):
    """A missing include is a compile error unless its name ends in "?"."""
    res = run_fq(["-n", 'include "%s"; 1' % name], cwd=str(tmp_path))
    # CATCHES: the missing module error names the file with the appended .jq
    # suffix and says "file does not exist", while a trailing ? in the
    # include name silently drops the whole include.
    assert res.returncode == rc
    assert res.stdout == stdout
    assert res.stderr == stderr


def test_dynamic_include_generates_the_module(tmp_path):
    """An include file with a root expression generates the module source."""
    write_file(tmp_path, "dyn.jq", '"def g: 7;"\n')
    res = run_fq(["-n", 'include "dyn"; g'], cwd=str(tmp_path))
    # CATCHES: when the included file parses as an expression instead of a
    # list of definitions it is evaluated with null input and must output
    # exactly one string, which is then parsed as the real module source.
    assert res.returncode == 0
    assert res.stdout == b"7\n"
    assert res.stderr == b""


@pytest.mark.parametrize(
    "source, stderr",
    [
        (
            '"a","b"',
            b'error: arg: dynamic include: must output one string,'
            b' got: []interface {}{"a", "b"}\n',
        ),
        ("1", b'error: arg: dynamic include: must be string, got ""\n'),
    ],
)
def test_dynamic_include_must_output_one_string(tmp_path, source, stderr):
    """A dynamic include expression must evaluate to a single string."""
    write_file(tmp_path, "dyn.jq", source + "\n")
    res = run_fq(["-n", 'include "dyn"; 1'], cwd=str(tmp_path))
    # CATCHES: multiple output values or a non-string output are compile
    # errors (exit 3) that report the offending values in the message.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == stderr


def test_absolute_include_path(tmp_path):
    """An include name starting with / is used as an absolute path."""
    write_tree(tmp_path, "libs", "mod.jq", "def f: 42;\n")
    res = run_fq(
        ["-n", 'include "%s"; f' % (tmp_path / "libs" / "mod")], cwd=str(tmp_path)
    )
    # CATCHES: an absolute include name is opened directly (with the .jq
    # suffix appended) instead of being searched for in ./ or the -L paths.
    assert res.returncode == 0
    assert res.stdout == b"42\n"
    assert res.stderr == b""


def test_double_include_is_idempotent(tmp_path):
    """Including the same file twice in one expression defines nothing twice."""
    write_file(tmp_path, "mod.jq", "def f: 42;\n")
    res = run_fq(["-n", 'include "mod"; include "mod"; f'], cwd=str(tmp_path))
    # CATCHES: the second include of the same file in one evaluation is
    # skipped (it would otherwise redefine f and be a compile error).
    assert res.returncode == 0
    assert res.stdout == b"42\n"
    assert res.stderr == b""


def test_include_of_a_subdirectory_module(tmp_path):
    """A module in a subdirectory imports siblings by relative path."""
    write_file(tmp_path, "mod.jq", "def f: 42;\n")
    write_tree(
        tmp_path,
        "sub",
        "rel.jq",
        'import "../mod" as m;\ndef k: m::f + 1;\n',
    )
    res = run_fq(["-n", 'include "sub/rel"; k'], cwd=str(tmp_path))
    # CATCHES: import paths inside an included module are rewritten relative
    # to that module's own directory, so ../mod finds the top level mod.jq
    # and not a file next to the including expression.
    assert res.returncode == 0
    assert res.stdout == b"43\n"
    assert res.stderr == b""


def test_config_dir_include(tmp_path):
    """The @config/ prefix includes from the OS configuration directory."""
    write_tree(tmp_path, ".config", "fq", "cfgmod.jq", "def cf: 99;\n")
    res = run_fq(
        ["-n", 'include "@config/cfgmod"; cf'],
        extra={
            "HOME": str(tmp_path),
            "XDG_CONFIG_HOME": str(tmp_path / ".config"),
        },
    )
    # CATCHES: the @config/ prefix resolves against the same configuration
    # directory init.jq is loaded from, independent of the include paths.
    assert res.returncode == 0
    assert res.stdout == b"99\n"
    assert res.stderr == b""


@pytest.mark.parametrize("name", ["dir", "dir?"])
def test_include_of_a_directory_fails_to_read(tmp_path, name):
    """A directory named like a module fails when its content is read."""
    (tmp_path / "dir.jq").mkdir()
    res = run_fq(["-n", 'include "%s"; 1' % name], cwd=str(tmp_path))
    # CATCHES: opening dir.jq succeeds (it is a directory) so the trailing
    # "?" does not help - the failure happens when reading it, reported as
    # "read dir.jq: is a directory" with the compile error exit code 3.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"error: arg: read dir.jq: is a directory\n"


@pytest.mark.parametrize("name", ["genbadparse", "genbadparse?"])
def test_dynamic_include_output_must_parse(tmp_path, name):
    """A dynamic include whose output is broken jq fails with its position."""
    write_file(tmp_path, "genbadparse.jq", '"def f: 1("\n')
    res = run_fq(["-n", 'include "%s"; 1' % name], cwd=str(tmp_path))
    # CATCHES: the generated string "def f: 1(" is parsed as a module and
    # the parse error is reported with the "dynamic include parse:" kind
    # and the position inside the generated text (1:9, the opening paren);
    # like the directory case the "?" only covers open errors, so it does
    # not suppress this.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == (
        b'error: arg: genbadparse.jq:1:9: dynamic include parse:'
        b' unexpected token "("\n'
    )


def test_dynamic_include_generator_must_compile(tmp_path):
    """A generator expression that does not compile is a plain error."""
    write_file(tmp_path, "gennocompile.jq", "nosuchfn\n")
    res = run_fq(["-n", 'include "gennocompile"; 1'], cwd=str(tmp_path))
    # CATCHES: the root expression nosuchfn makes the file a dynamic
    # include, and compiling the generator itself fails with the raw gojq
    # message (no file position, no "parse:"/"compile:" kind) while still
    # exiting with the compile error code 3.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"error: arg: function not defined: nosuchfn/0\n"


def test_dynamic_include_generator_runtime_error(tmp_path):
    """A runtime error while generating a module is a compile error."""
    write_file(tmp_path, "generr.jq", 'error("boom")\n')
    res = run_fq(["-n", 'include "generr"; 1'], cwd=str(tmp_path))
    # CATCHES: the generator is evaluated with null input during module
    # loading, so its error aborts loading; the message keeps the inner
    # "error: " prefix of the jq error value, giving "error: arg: error:
    # boom", and the exit code is still the compile error 3.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"error: arg: error: boom\n"


@pytest.mark.parametrize(
    "expr, rc, stdout, stderr",
    [
        ("1", 0, b"1\n", b""),
        ("f", 3, b"", b"error: arg: function not defined: f/0\n"),
    ],
)
def test_root_expression_in_a_module_makes_it_dynamic(
    tmp_path, expr, rc, stdout, stderr
):
    """Definitions before a root expression are dropped by dynamic include."""
    write_file(tmp_path, "plain.jq", 'def f: 42; "ok"\n')
    res = run_fq(["-n", 'include "plain"; %s' % expr], cwd=str(tmp_path))
    # CATCHES: "def f: 42; \"ok\"" has a root expression, so the whole file
    # is treated as a generator whose output "ok" becomes the module - the
    # def f is silently discarded and using f afterwards is a compile error,
    # while an expression not touching f still runs fine.
    assert res.returncode == rc
    assert res.stdout == stdout
    assert res.stderr == stderr
