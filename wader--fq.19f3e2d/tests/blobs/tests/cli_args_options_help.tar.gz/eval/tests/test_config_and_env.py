"""Configuration: the OS config dir init.jq, -L include paths and the environment.

The user init file is loaded through ``include "@config/init?"`` where the
config dir comes from ``os.UserConfigDir()`` (``$XDG_CONFIG_HOME/fq`` or
``$HOME/.config/fq`` on Linux).  A broken init file aborts the whole run with
exit code 1, which is different from every other error path in fq.

The last tests use a private pseudo terminal because colour auto-detection and
the "no arguments at all" usage banner are only reachable when stdin and
stdout really are terminals.
"""

from __future__ import annotations

import pytest

from conftest import executable_path, run_fq, run_fq_tty, write_tree

# All expectations below were recorded by running ./executable.


def test_init_jq_defines_functions(tmp_path):
    """~/.config/fq/init.jq is included into every run."""
    home = tmp_path / "home"
    write_tree(home, ".config", "fq", "init.jq", 'def cfgmark: "from-init";\n')
    res = run_fq(["-n", "cfgmark"], extra={"HOME": str(home)})
    # CATCHES: definitions from the user init file are visible to the command
    # line expression without any include of its own.
    assert res.returncode == 0
    assert res.stdout == b'"from-init"\n'
    assert res.stderr == b""


def test_xdg_config_home_overrides_home(tmp_path):
    """$XDG_CONFIG_HOME takes precedence over $HOME/.config."""
    home = tmp_path / "home"
    xdg = tmp_path / "xdg"
    write_tree(home, ".config", "fq", "init.jq", 'def cfgmark: "home";\n')
    write_tree(xdg, "fq", "init.jq", 'def cfgmark: "xdg";\n')
    res = run_fq(
        ["-n", "cfgmark"],
        env={"PATH": "/usr/bin:/bin", "LANG": "C", "HOME": str(home), "XDG_CONFIG_HOME": str(xdg)},
    )
    # CATCHES: the config dir is resolved like os.UserConfigDir, so an explicit
    # XDG_CONFIG_HOME wins over the HOME based default directory.
    assert res.returncode == 0
    assert res.stdout == b'"xdg"\n'
    assert res.stderr == b""


def test_missing_init_jq_is_optional(tmp_path):
    """An existing config dir without init.jq is fine."""
    home = tmp_path / "home"
    write_tree(home, ".config", "fq", "unused.txt", "x\n")
    res = run_fq(["-n", "1"], extra={"HOME": str(home)})
    # CATCHES: the init include is optional ("init?"), so a config directory
    # that has no init.jq is not an error.
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_missing_config_dir_is_optional(tmp_path):
    """A HOME without any .config directory is fine too."""
    res = run_fq(["-n", "1"], extra={"HOME": str(tmp_path / "nowhere")})
    # CATCHES: even a non-existent HOME only means "no init file"; the run
    # continues normally.
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_no_home_at_all(tmp_path):
    """Running without HOME or XDG_CONFIG_HOME still works."""
    res = run_fq(["-n", "1"], env={"PATH": "/usr/bin:/bin", "LANG": "C"})
    # CATCHES: with no HOME set the config dir cannot be resolved, which is
    # tolerated instead of failing to start.
    assert res.returncode == 0
    assert res.stdout == b"1\n"
    assert res.stderr == b""


def test_init_jq_parse_error_aborts_with_exit_1(tmp_path):
    """A syntactically broken init.jq aborts with exit code 1."""
    home = tmp_path / "home"
    init = write_tree(home, ".config", "fq", "init.jq", "def (")
    res = run_fq(["-n", "1"], extra={"HOME": str(home)})
    # CATCHES: a broken init file is reported before anything else runs, with
    # the "expr:1:0: compile:" prefix, the absolute file path and exit code 1
    # (not the usual argument error code 2).
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == (
        b'expr:1:0: compile: %s:1:5: parse: unexpected token "("\n'
        % str(init).encode()
    )


def test_init_jq_runtime_error_aborts_with_exit_1(tmp_path):
    """A runtime error in init.jq also aborts with exit code 1."""
    home = tmp_path / "home"
    write_tree(home, ".config", "fq", "init.jq", 'error("boom")')
    res = run_fq(["-n", "1"], extra={"HOME": str(home)})
    # CATCHES: the init file is evaluated as part of loading, so its error
    # message is wrapped in the same "expr:1:0: compile:" prefix.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b"expr:1:0: compile: error: boom\n"


def test_init_jq_must_contain_definitions(tmp_path):
    """An init.jq that is a plain value is rejected."""
    home = tmp_path / "home"
    write_tree(home, ".config", "fq", "init.jq", "1")
    res = run_fq(["-n", "1"], extra={"HOME": str(home)})
    # CATCHES: init.jq is included, not evaluated, so a bare value produces
    # the "dynamic include: must be string" diagnostic with exit code 1.
    assert res.returncode == 1
    assert res.stdout == b""
    assert res.stderr == b'expr:1:0: compile: dynamic include: must be string, got ""\n'


def test_include_path_flag(tmp_path):
    """-L adds a directory to the include search path."""
    libs = tmp_path / "libs"
    write_tree(libs, "double.jq", "def double: . * 2;\n")
    res = run_fq(
        ["-L", "libs", "-n", 'include "double"; 3 | double'], cwd=str(tmp_path)
    )
    # CATCHES: -L paths are relative to the working directory and the ".jq"
    # suffix is appended to the include name automatically.
    assert res.returncode == 0
    assert res.stdout == b"6\n"
    assert res.stderr == b""


def test_include_path_is_searched_before_missing_error(tmp_path):
    """Without a matching -L path the include fails at compile time."""
    res = run_fq(
        ["-L", "nowhere", "-n", 'include "double"; 3'], cwd=str(tmp_path)
    )
    # CATCHES: an unresolvable include is a compile error (exit 3) naming the
    # file with the appended .jq suffix, not an argument error.
    assert res.returncode == 3
    assert res.stdout == b""
    assert res.stderr == b"error: arg: open double.jq: file does not exist\n"


def test_include_path_defaults_to_working_directory(tmp_path):
    """Without -L the current directory is searched."""
    write_tree(tmp_path, "double.jq", "def double: . * 2;\n")
    res = run_fq(["-n", 'include "double"; 3 | double'], cwd=str(tmp_path))
    # CATCHES: "./" is always the first include search path, so a library next
    # to the current directory is found without -L.
    assert res.returncode == 0
    assert res.stdout == b"6\n"
    assert res.stderr == b""


def test_multiple_include_paths_are_all_searched(tmp_path):
    """Repeated -L flags accumulate."""
    a = tmp_path / "a"
    b = tmp_path / "b"
    write_tree(a, "one.jq", "def one: 1;\n")
    write_tree(b, "two.jq", "def two: 2;\n")
    res = run_fq(
        ["-L", "a", "-L", "b", "-n", 'include "one"; include "two"; one + two'],
        cwd=str(tmp_path),
    )
    # CATCHES: every -L contributes one entry to the search path list, so
    # libraries from different directories can be mixed.
    assert res.returncode == 0
    assert res.stdout == b"3\n"
    assert res.stderr == b""


def test_environment_is_visible_to_the_expression(tmp_path):
    """The child environment is exposed through env/ENV."""
    res = run_fq(["-n", "env.MYVAR"], extra={"MYVAR": "hello"})
    # CATCHES: environment variables are read at evaluation time from the
    # process environment, so a pinned child env shows up in env.MYVAR.
    assert res.returncode == 0
    assert res.stdout == b'"hello"\n'
    assert res.stderr == b""


def test_unset_environment_variable_is_empty_string(tmp_path):
    """An unset variable is the empty string in env."""
    res = run_fq(["-n", "env.UNSET_VAR_XYZ | length"], env={"PATH": "/usr/bin:/bin", "LANG": "C"})
    # CATCHES: unset variables are not null in the env object, they are empty
    # strings, so their length is 0.
    assert res.returncode == 0
    assert res.stdout == b"0\n"
    assert res.stderr == b""


def test_no_arguments_on_terminals_prints_usage_and_exits_2(tmp_path):
    """With stdin and stdout both terminals, no args prints usage on stderr."""
    code, out = run_fq_tty([], cwd=str(tmp_path))
    # CATCHES: the "interactive with no arguments" guard prints only the usage
    # line (no banner, no flag table) and exits with the argument error code 2
    # instead of reading stdin.
    assert code == 2
    assert out == (
        b"Usage: "
        + executable_path().encode()
        + b" [OPTIONS] [--] [EXPRESSION] [FILE...]\r\n"
    )


def test_terminal_output_is_colourised_by_default(tmp_path):
    """A terminal stdout turns colour on automatically."""
    code, out = run_fq_tty(["-n", "1"])
    # CATCHES: colour is on when stdout is a terminal, so the number is wrapped
    # in the cyan escape sequence even without -C.
    assert code == 0
    assert out == b"\x1b[36m1\x1b[m\r\n"


def test_no_color_disables_terminal_colour(tmp_path):
    """A non-empty NO_COLOR turns colour off on a terminal."""
    code, out = run_fq_tty(["-n", "1"], extra={"NO_COLOR": "1"})
    # CATCHES: NO_COLOR only has an effect when stdout is a terminal, and any
    # non-empty value disables the automatic colour.
    assert code == 0
    assert out == b"1\r\n"


def test_empty_no_color_keeps_colour(tmp_path):
    """An empty NO_COLOR does not disable colour."""
    code, out = run_fq_tty(["-n", "1"], extra={"NO_COLOR": ""})
    # CATCHES: only a non-empty NO_COLOR counts; an empty value leaves the
    # automatic colour enabled.
    assert code == 0
    assert out == b"\x1b[36m1\x1b[m\r\n"


def test_color_flag_beats_no_color_on_terminal(tmp_path):
    """-C re-enables colour even with NO_COLOR set."""
    code, out = run_fq_tty(["-C", "-n", "1"], extra={"NO_COLOR": "1"})
    # CATCHES: --color-output forces colour on regardless of the environment
    # variable, unlike the automatic detection.
    assert code == 0
    assert out == b"\x1b[36m1\x1b[m\r\n"


def test_monochrome_flag_on_terminal(tmp_path):
    """-M disables colour on a terminal."""
    code, out = run_fq_tty(["-M", "-n", "1"])
    # CATCHES: --monochrome-output forces colour off even though stdout is a
    # terminal.
    assert code == 0
    assert out == b"1\r\n"


@pytest.mark.parametrize(
    "value, rc, stdout, stderr",
    [
        ("abc", 1, b"", b'tonumber cannot be applied to "abc": invalid number\n'),
        ("", 1, b"", b'tonumber cannot be applied to "": invalid number\n'),
        ("2", 0, b"1\n", b""),
    ],
)
def test_completion_timeout_env_must_parse_as_a_number(value, rc, stdout, stderr):
    """COMPLETION_TIMEOUT is parsed as a number on every run."""
    res = run_fq(["-n", "1"], extra={"COMPLETION_TIMEOUT": value})
    # CATCHES: the completion timeout option is evaluated eagerly from the
    # environment even though this run never completes anything, so a value
    # that tonumber rejects aborts the whole run with exit code 1 (the option
    # error path) while a numeric value leaves the run untouched.
    assert res.returncode == rc
    assert res.stdout == stdout
    assert res.stderr == stderr


def test_cliunicode_without_a_terminal_is_ignored():
    """CLIUNICODE only enables Unicode output on a terminal."""
    res = run_fq(["-i", "-n", "0"], stdin="(\n7\n", extra={"CLIUNICODE": "1"})
    # CATCHES: unlike the -U flag, setting the CLIUNICODE environment
    # variable has no effect when stdout is a pipe - the compile error arrow
    # stays the ASCII "^" - yet the session otherwise behaves the same and
    # exits 0.
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b"        ^ unexpected EOF\n7\n"
