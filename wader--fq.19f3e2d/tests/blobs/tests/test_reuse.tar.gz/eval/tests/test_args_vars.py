"""$ARGS and the --arg/--argjson/--args/--jsonargs families, ported from
the native pkg/interp/testdata/args_named.fqtest and args_positional.fqtest
scripts of the reference repository (which compare fq against jq itself)."""


def test_arg_last_wins(run):
    """A repeated --arg keeps the last value."""
    result = run(["-cn", "--arg", "a", "1", "--arg", "a", "2", "$ARGS"])
    # CATCHES: later --arg flags overwrite earlier ones for the same name
    # and the value is always a string.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"named":{"a":"1"},"positional":[]}\n'


def test_argjson_beats_arg(run):
    """--argjson takes precedence over --arg for the same name."""
    result = run(["-cn", "--argjson", "a", "1", "--arg", "a", "2", "$ARGS"])
    # CATCHES: the JSON typed value survives even when a string --arg for
    # the same name follows it.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"named":{"a":1},"positional":[]}\n'


def test_arg_can_shadow_ARGS(run):
    """A variable literally named ARGS shadows the builtin."""
    result = run(["-cn", "--arg", "ARGS", "1", "$ARGS"])
    # CATCHES: $ARGS resolves the user variable first, so the string "1" is
    # printed instead of the positional structure.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"named":{"ARGS":"1"},"positional":[]}\n'


def test_args_collects_positional(run):
    """--args collects remaining arguments as positional strings."""
    result = run(["-cn", "--args", "$ARGS", "-n", "a", "-n", "b"])
    # CATCHES: after --args every later argument (including flag-looking
    # ones like -n) is a positional string, so the first -n before $ARGS is
    # still the null-input flag but the trailing ones are collected.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"named":{},"positional":["a","b"]}\n'


def test_args_with_double_dash(run):
    """--args with '--' collects everything as positional."""
    result = run(["-cn", "--args", "--", "$ARGS", "-n", "b", "-n"])
    # CATCHES: the explicit '--' terminator makes even the expression
    # positional, so $ARGS, -n, b and -n all end up in the list verbatim.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"named":{},"positional":["-n","b","-n"]}\n'


def test_args_before_expression(run):
    """Positional strings can also be given after the expression."""
    result = run(["-cn", "$ARGS", "--args", "--", "a", "b", "c"])
    # CATCHES: --args may appear after the expression; everything from the
    # terminator on is collected as positional arguments.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"named":{},"positional":["a","b","c"]}\n'


def test_jsonargs_collects_json(run):
    """--jsonargs parses remaining arguments as JSON."""
    result = run(["-cn", "--jsonargs", "$ARGS", "-n", '"a"', "-n", '"b"'])
    # CATCHES: the collected strings are parsed as JSON, so the quoted
    # inputs become real strings in the positional array while unquoted -n
    # stays a plain string.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"named":{},"positional":["a","b"]}\n'


def test_jsonargs_with_double_dash(run):
    """--jsonargs with '--' collects and parses everything."""
    result = run(["-cn", "--jsonargs", "--", "$ARGS", '"a"', '"b"'])
    # CATCHES: after the terminator the expression itself is collected and
    # JSON-parsed like the rest of the arguments.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"named":{},"positional":["a","b"]}\n'


def test_jsonargs_and_args_mix(run):
    """Mixing --jsonargs and --args re-parses the collected strings."""
    result = run(["-cn", "--jsonargs", "$ARGS", '"a"', "--args", "b",
                  "--jsonargs", '"c"'])
    # CATCHES: switching back to --jsonargs re-parses the whole collected
    # positional list as JSON, which fails on the bare word '$ARGS' with
    # exit code 2 and the fromjson error message.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == (
        'error: --jsonargs $ARGS: fromjson cannot be applied to "$ARGS": '
        "invalid character '$' looking for beginning of value\n")


def test_argjson_value_available(run):
    """--argjson values are usable as typed data."""
    result = run(["-n", "--argjson", "a", "[1,2]", "$a | length"])
    # CATCHES: the parsed JSON keeps its type, so array builtins work
    # directly on the variable.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "2\n"
