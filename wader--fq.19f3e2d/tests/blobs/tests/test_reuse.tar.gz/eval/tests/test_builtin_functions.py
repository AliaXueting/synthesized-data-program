"""General purpose builtin functions available outside the REPL (match,
print family, debug, open, tohex/fromhex, tobits/tobytes, bit operations,
help and torepr), ported from the native pkg/interp/testdata scripts
match.fqtest, output.fqtest, debug.fqtest, open.fqtest, binary.fqtest,
bitops.fqtest, help.fqtest and torepr.fqtest."""


def test_match_first_occurrence(run):
    """match() reports the first regexp occurrence per input."""
    result = run(["-n", '["aXbX","abc"] | map(match("X"))'])
    # CATCHES: match without the global flag yields at most one match
    # object per input string (offset, length, string, empty captures) and
    # none for strings that do not match.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[\n  {\n    "captures": [],\n    "length": 1,\n'
        '    "offset": 1,\n    "string": "X"\n  }\n]\n')


def test_match_global_flag(run):
    """match() with the g flag reports every occurrence."""
    result = run(["-n", '"aXbX" | [match("X"; "g")]'])
    # CATCHES: the global flag enumerates both occurrences in order with
    # their own offsets (1 and 3).
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[\n  {\n    "captures": [],\n    "length": 1,\n'
        '    "offset": 1,\n    "string": "X"\n  },\n'
        '  {\n    "captures": [],\n    "length": 1,\n'
        '    "offset": 3,\n    "string": "X"\n  }\n]\n')


def test_print_writes_without_newline(run):
    """print writes each value without adding a newline."""
    result = run(["-n", 'null, {a:1}, "abc" | ., "\\n" | print'])
    # CATCHES: print emits the value display with no terminator, so the
    # explicit "\\n" values are needed to separate the outputs.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == 'null\n{"a":1}\nabc\n'


def test_println_writes_lines(run):
    """println writes each value followed by a newline."""
    result = run(["-n", 'null, {a:1}, "abc" | println'])
    # CATCHES: println terminates every value with a newline, and the
    # object is rendered in compact form, not pretty form.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == 'null\n{"a":1}\nabc\n'


def test_printerrln_writes_to_stderr(run):
    """printerrln writes to stderr instead of stdout."""
    result = run(["-n", 'null, {a:1}, "abc" | printerrln'])
    # CATCHES: the printerr variants share the compact rendering of println
    # but route every byte to the error stream, leaving stdout empty.
    assert (result.returncode, result.out) == (0, "")
    assert result.err == 'null\n{"a":1}\nabc\n'


def test_stderr_builtin_dual_output(run):
    """The stderr builtin tees values to stderr and returns them."""
    result = run(["-n", 'null, {a:1}, "abc" | stderr'])
    # CATCHES: stderr emits the compact value to the error stream while the
    # original value continues down the pipeline and is printed to stdout
    # in the usual pretty form.
    assert result.returncode == 0
    assert result.out == 'null\n{\n  "a": 1\n}\n"abc"\n'
    assert result.err == 'null{"a":1}abc'


def test_debug_writes_compact_json_to_stderr(run):
    """debug logs the compact value on stderr and passes it through."""
    result = run(["-n", "{a: 123, b: []} | debug({a})"])
    # CATCHES: debug writes a ["DEBUG:", <compact json>] line to stderr for
    # every input value while stdout shows the (pretty) value itself.
    assert result.returncode == 0
    assert result.out == '{\n  "a": 123,\n  "b": []\n}\n'
    assert result.err == '["DEBUG:",{"a":123}]\n'


def test_open_reads_file_as_bits(run, write):
    """open() loads a file as a binary value."""
    write("aa", "abc\n")
    result = run(["-n", '"aa" | open | tostring'])
    # CATCHES: the opened file behaves like a decoded buffer, and tostring
    # on it yields the file text including its trailing newline.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"abc\\n"\n'


def test_open_slice_range(run, write):
    """An opened file can be sliced like any bits value."""
    write("aa", "abc\n")
    result = run(["-n", '"aa" | open | .[1:2] | tovalue'])
    # CATCHES: byte ranges on the opened value are half open, so [1:2]
    # yields exactly one character 'b'.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"b"\n'


def test_fromhex_tohex_roundtrip(run):
    """fromhex and tohex convert between strings and bits."""
    result = run(["-n", '"64ff65ff66" | fromhex | tohex'])
    # CATCHES: fromhex parses a hex string into a binary value and tohex
    # renders the identical lowercase hex string back.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"64ff65ff66"\n'


def test_tobits_tobytes_pads_to_bytes(run):
    """tobytes pads a 3 bit value into one byte."""
    result = run(["-n", "[1,1,1 | tobits] | tobytes | tohex"])
    # CATCHES: three explicit bits 111 are right-padded with zeros to a
    # whole byte, giving the hex value 07.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"07"\n'


def test_tobits_width_argument(run):
    """tobits(n) zero-extends a number to n bits."""
    result = run(["-n", "[1,1,1 | tobits] | tobits(9) | tobytes | tohex"])
    # CATCHES: widening the 3 bit value 111 to 9 bits pads with zeros on
    # the left, so the two output bytes are 00 07 in hex as 0007.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"0007"\n'


def test_tobytes_size_argument(run):
    """tobytes(n) left-pads to n bytes."""
    result = run(["-n", "[1,1,1 | tobits] | tobytes(3) | tohex"])
    # CATCHES: the size argument extends the value on the left with zero
    # bytes, producing 000007 for a three byte output.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"000007"\n'


def test_bnot_bitwise_not(run):
    """bnot computes arbitrary precision bitwise negation."""
    result = run(["-n",
                  "0, -1, 1208925819614629174706175, "
                  "-1208925819614629174706176 | bnot"])
    # CATCHES: bnot works on numbers larger than 64 bits without wrapping,
    # flipping the sign and magnitude as an arbitrary precision integer.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "-1\n0\n-1208925819614629174706176\n1208925819614629174706175\n")


def test_bsl_bitwise_shift_left(run):
    """bsl shifts left with arbitrary precision."""
    result = run(["-n",
                  "[0,0], [8,1], [0xffff_ffff_ffff_ffff,1] "
                  "| bsl(.[0]; .[1])"])
    # CATCHES: shifting 2^64-1 left by one stays exact instead of
    # overflowing a uint64, giving 36893488147419103230.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "0\n16\n36893488147419103230\n"


def test_bnot_type_error(run):
    """bnot on a non-number is a runtime error."""
    result = run(["-n", "null | bnot"])
    # CATCHES: the bit operations demand numbers and report the offending
    # type name in the error message.
    assert (result.returncode, result.out) == (5, "")
    assert result.err == "error: cannot bnot: null\n"


def test_underscore_number_literals(run):
    """Number literals support 0b/0o/0x forms with underscores."""
    result = run(["-n",
                  "0b" + "1" * 75 + "0, 0o17777777777777777777777776, "
                  "0xffffffffffffffffffe"])
    # CATCHES: all three spellings denote the same arbitrary precision
    # integer 75557863725914323419134 and print identically.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "75557863725914323419134\n" * 3


def test_tostream_object(run):
    """tostream enumerates object paths and leaf values."""
    result = run(["-n", "{a:1, b: 2} | tostream"])
    # CATCHES: tostream emits one [path, value] pair per leaf followed by
    # the bare path of the last key to signal its completion.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == ('[\n  [\n    "a"\n  ],\n  1\n]\n'
                          '[\n  [\n    "b"\n  ],\n  2\n]\n'
                          '[\n  [\n    "b"\n  ]\n]\n')


def test_torepr_requires_format_root(run):
    """torepr on a non format-root value is an error."""
    result = run(["-n", "torepr"])
    # CATCHES: torepr only works on values that came from a decoder with a
    # text representation, and refuses plain null with a dedicated message.
    assert (result.returncode, result.out) == (5, "")
    assert result.err == "error: value is not a format root\n"


def test_torepr_json_has_no_repr(run):
    """torepr on a json value reports the missing representation."""
    result = run(["-n", '"{}" | json | torepr'])
    # CATCHES: the json decoder has no torepr, so the error names the
    # format that lacks the representation.
    assert (result.returncode, result.out) == (5, "")
    assert result.err == "error: json has no torepr\n"


def test_help_function_topic(run):
    """help(length) prints the function documentation."""
    result = run(["-n", "help(length)"])
    # CATCHES: the help builtin works outside the REPL and prints the full
    # function description including the examples with their outputs.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == HELP_LENGTH


def test_help_must_be_last_in_pipeline(run):
    """help cannot be followed by more pipeline stages."""
    result = run(["-n", "help(length) | 1"])
    # CATCHES: the help builtin refuses to be piped further and explains
    # the two allowed shapes (alone, or last) in the error message.
    assert (result.returncode, result.out) == (5, "")
    assert result.err == (
        "error: help must be alone or last in pipeline. "
        "ex: help(length) or ... | help\n")


HELP_LENGTH = """\
length: Length of string, array, object, etc
- For string number of unicode codepoints
- For array number of elements in array
- For object number of key-value pairs
- For null zero
- For number the number itself
- For boolean is an error

Examples:
> [1,2,3] | length
3
> "abc" | length
3
> {"a":1,"b":2} | length
2
> null | length
0
> 123 | length
123
> true | length
error: length cannot be applied to: boolean (true)
"""
