"""Command line argument handling, ported from the native
pkg/interp/testdata/args.fqtest script of the reference repository."""

import re

import pytest

from conftest import program_path

USAGE = "Usage: fq [OPTIONS] [--] [EXPRESSION] [FILE...]"


def test_empty_stdin_probe_failure(run):
    """No expression and undecodable stdin is a probe failure."""
    result = run([], stdin="test")
    # CATCHES: the default expression '.' probes stdin; when no format
    # matches the run exits 4 with the dedicated probe hint on stderr and
    # nothing at all on stdout.
    assert result.returncode == 4
    assert result.out == ""
    assert result.err == (
        "error: <stdin>: probe: failed to decode: "
        "try fq -d FORMAT to force format, see fq -h formats for list\n")


def test_empty_stdin_no_bytes(run):
    """Completely empty stdin is reported as a probe failure too."""
    result = run([], stdin=b"")
    # CATCHES: an empty input is not valid JSON or any other format, so the
    # same probe error and exit code 4 are produced as for garbage text.
    assert result.returncode == 4
    assert result.out == ""
    assert result.err == (
        "error: <stdin>: probe: failed to decode: "
        "try fq -d FORMAT to force format, see fq -h formats for list\n")


def test_unknown_short_flag(run):
    """An unrecognised short flag is a usage error."""
    result = run(["-X"])
    # CATCHES: unknown flags exit 2 with the 'no such argument' diagnostic;
    # the usage line itself is not printed for this error kind.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: -X: no such argument\n"


def test_unknown_long_flag(run):
    """An unrecognised long flag is a usage error."""
    result = run(["--X"])
    # CATCHES: long flags are validated the same way as short ones and keep
    # their double dash spelling in the error message.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: --X: no such argument\n"


def test_unknown_dash_dot_flag(run):
    """'-.' is not a known flag and is rejected."""
    result = run(["-."])
    # CATCHES: only numeric-looking dash arguments fall through to be
    # treated as expressions; any other unknown shape is a usage error.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: -.: no such argument\n"


@pytest.mark.parametrize("flag,expected", [
    ("-0", "0\n"),
    ("-123", "-123\n"),
])
def test_numeric_dash_argument_is_expression(run, flag, expected):
    """Dash followed by digits is an expression, not a flag."""
    result = run([flag], stdin='"abc"')
    # CATCHES: arguments like -0 and -123 are parsed as the jq expressions
    # 0 and -123 instead of failing as unknown flags, and stdin is still
    # decoded as the JSON string "abc" to which the expression is applied.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == expected


def test_default_expression_and_stdin(run):
    """With no expression the program evaluates '.' over stdin."""
    result = run([], stdin='"abc"')
    # CATCHES: the implicit expression is '.' and stdin is probed as JSON,
    # so the decoded string is echoed back in display form with quotes.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"abc"\n'


def test_dash_argument_means_stdin(run):
    """A lone '-' file argument refers to standard input."""
    result = run([".", "-"], stdin='"abc"')
    # CATCHES: '-' is the stdin placeholder in the file list; the result is
    # byte identical to running with no file arguments at all.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"abc"\n'


def test_json_object_stdin_pretty_printed(run):
    """JSON from stdin is decoded and pretty printed by default."""
    result = run([], stdin='{"a":1}')
    # CATCHES: output is jq-style pretty JSON with two space indent and a
    # trailing newline, not the compact single line that was fed in.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{\n  "a": 1\n}\n'


def test_missing_file_argument(run):
    """A missing file is a fatal IO error."""
    result = run([".", "non-existing"])
    # CATCHES: the failing path is reported verbatim on stderr with exit
    # code 2 and the classic unix 'no such file or directory' message.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: non-existing: no such file or directory\n"


def test_help_full_text(run):
    """-h prints the complete option help to stdout and exits 0."""
    result = run(["-h"])
    # CATCHES: the whole help text (title, usage, examples and the sorted
    # option table) is written to stdout with exit code 0; only the usage
    # line embeds the invoked program path, which is normalised away here.
    assert result.returncode == 0
    assert result.err == ""
    expected = HELP_TEXT.replace("<PROG>", program_path())
    assert result.out == expected


def test_help_long_flag_matches_short(run):
    """--help produces the same text as -h."""
    short = run(["-h"])
    long = run(["--help"])
    # CATCHES: both spellings share one code path, so the full help bytes
    # (including the embedded program path) are identical and the long
    # spelling alone reproduces the entire recorded help text.
    assert (long.returncode, long.err) == (0, "")
    assert long.out == HELP_TEXT.replace("<PROG>", program_path())
    assert long.stdout == short.stdout


def test_help_usage_error_line(run):
    """The usage banner uses the invoked program path."""
    result = run(["-h"])
    # CATCHES: the usage line is built from the program path as invoked
    # (like os.Args[0]), so calling the binary through an absolute path
    # makes that path appear in the help output.
    assert "Usage: %s [OPTIONS] [--] [EXPRESSION] [FILE...]\n" % (
        program_path()) in result.out


def test_version_string(run):
    """-v prints a version line of the recorded shape."""
    result = run(["-v"])
    # CATCHES: the version flag reports the tool version followed by the
    # platform triple in parentheses; the exact go release is build
    # dependent so only its shape is pinned, the version number is exact.
    assert result.returncode == 0
    assert result.err == ""
    assert re.fullmatch(r"0\.18\.0 \([a-z0-9]+ [a-z0-9]+ go1\.[0-9.]+\)\n",
                        result.out), result.out


def test_version_long_flag_matches_short(run):
    """--version and -v print the same line."""
    short = run(["-v"])
    long = run(["--version"])
    # CATCHES: the long spelling of the version flag shares the same code
    # path and byte-for-byte output as the short one, including the version
    # number and the platform triple shape.
    assert (long.returncode, long.err) == (0, "")
    assert re.fullmatch(r"0\.18\.0 \([a-z0-9]+ [a-z0-9]+ go1\.[0-9.]+\)\n",
                        long.out), long.out
    assert (long.returncode, long.stdout, long.err) == (
        short.returncode, short.stdout, short.err)


def test_help_options_listing(run):
    """--help options lists every option with its default value."""
    result = run(["--help", "options"])
    # CATCHES: the options topic prints a fixed-width two column listing of
    # all option names and their defaults in this environment, including
    # width 0 and completion_timeout 1 for a non-terminal stdout.
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == OPTIONS_HELP


def test_help_formats_topic(run):
    """-h formats lists the decoder registry."""
    result = run(["-h", "formats"])
    # CATCHES: the formats topic lists every registered decoder, name and
    # description in two fixed columns, sorted by name.
    assert result.returncode == 0
    assert result.err == ""
    lines = result.out.splitlines()
    assert len(lines) == 136
    assert lines[0] == "aac_frame            Advanced Audio Coding frame"
    assert lines[1] == "adts                 Audio Data Transport Stream"
    assert "mp3                  MP3 file" in lines
    assert "zip                  ZIP archive" in lines


def test_help_format_topic(run):
    """-h mp3 shows per-decoder help including decode examples."""
    result = run(["-h", "mp3"])
    # CATCHES: a per-format topic documents the decoder options and embeds
    # the invoked program path inside its example commands, which are
    # normalised here; the option defaults come from the decoder registry.
    assert result.returncode == 0
    assert result.err == ""
    assert result.out == MP3_HELP.replace("<PROG>", program_path())


def test_flag_value_spellings(run):
    """Flags accept '-x=v', '--long v' and glued short forms."""
    for args in (["-d=mp3", "-n", "1"], ["--decode", "mp3", "-n", "1"],
                 ["-nd", "mp3", "-n", "1"]):
        result = run(args)
        # CATCHES: all three spellings ('-d=mp3', '--decode mp3' and the
        # glued '-nd mp3') set the same decode group and evaluate the null
        # input expression to 1.
        assert (result.returncode, result.out, result.err) == (0, "1\n", "")


def test_double_dash_stops_flag_parsing(run):
    """After '--' every argument is positional."""
    result = run(["--", "-n", "1"])
    # CATCHES: the first argument after '--' becomes the expression, here
    # '-n', which fails to compile as a jq expression (unknown function n)
    # with exit code 3 rather than being treated as the null-input flag.
    assert result.returncode == 3
    assert result.out == ""
    assert result.err == "error: arg: function not defined: n/0\n"


def test_double_dash_after_flags(run):
    """A trailing '--' after the expression is ignored."""
    result = run(["-n", "1", "--"])
    # CATCHES: the '--' terminator alone does not become a file argument;
    # the expression still evaluates against null input.
    assert (result.returncode, result.out, result.err) == (0, "1\n", "")


HELP_TEXT = """\
fq - jq for binary formats
Tool, language and decoders for working with binary data.
For more information see https://github.com/wader/fq

Usage: <PROG> [OPTIONS] [--] [EXPRESSION] [FILE...]

Example usages:
  fq . file
  fq d file
  fq -V '.path[1].value' file
  fq tovalue file
  fq -r to_toml file.yml
  fq -s -d html 'map(.html.head.title?)' *.html
  cat file.cbor | fq -d cbor torepr
  fq 'grep("^main$") | parent' /bin/ls
  fq -i

--arg NAME VALUE              Set $NAME to string VALUE
--argdecode NAME PATH         Set $NAME to decode of PATH
--argjson NAME JSON           Set $NAME to JSON
--args                        Consume remaining arguments as positional strings
--color-output,-C             Force color output
--compact-output,-c           Use compact output
--decode,-d NAME              Decode format or group (probe)
--from-file,-f PATH           Read EXPRESSION from file
--help,-h [TOPIC]             Show help for TOPIC (ex: -h formats, -h mp4)
--include-path,-L PATH        Add PATH to include search paths
--join-output,-j              No newline after each output
--jsonargs                    Consume remaining arguments as positional JSON
--monochrome-output,-M        Force monochrome output
--null-input,-n               Null input (use input and inputs to read)
--option,-o NAME=VALUE/@PATH  Set option (ex: -o color=true, see --help options)
--raw-file NAME PATH          Set $NAME to string content of file
--raw-input,-R                Read raw input strings (don't decode)
--raw-output,-r               Raw string output (without quotes)
--raw-output0                 NUL (zero) byte after each output
--repl,-i                     Interactive REPL
--slurp,-s                    Slurp all inputs into an array or string (-Rs)
--unicode-output,-U           Force unicode output
--value-output,-V             Output JSON value (-Vr for raw string)
--version,-v                  Show version
"""

OPTIONS_HELP = """\
addrbase            16
array_truncate      50
bits_format         string
byte_colors         0-255=default+bold,0=brightblack,32-126:9-13=default
color               false
colors              array=default,dumpaddr=yellow,dumpheader=yellow+underline,error=brightred,false=yellow,index=default,null=brightblack,number=cyan,object=default,objectkey=brightblue,prompt_repl_level=brightblack,prompt_value=default,string=green,true=yellow,value=default
compact             false
completion_timeout  1
depth               0
display_bytes       16
force               false
join_string         \\n
line_bytes          16
raw_string          false
sizebase            10
skip_gaps           false
string_truncate     50
unicode             false
verbose             false
width               0
"""

MP3_HELP = """\
mp3: MP3 file decoder

Options
=======

  max_sync_seek=32768          Max byte distance to next sync
  max_unique_header_configs=5  Max number of unique frame header configs allowed
  max_unknown=50               Max percent (0-100) unknown bits

Decode examples
===============

  # Decode file as mp3
  $ fq -d mp3 . file
  # Decode value as mp3
  ... | mp3
  # Decode file using mp3 options
  $ <PROG> -d mp3 -o max_sync_seek=32768 -o max_unique_header_configs=5 -o max_unknown=50 . file
  # Decode value as mp3
  ... | mp3({max_sync_seek:32768,max_unique_header_configs:5,max_unknown:50})

"""
