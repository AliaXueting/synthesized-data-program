"""Behavioural tests for the Apple binary property list and
bookmark decoders.

Vectors come from the reference repository's format test data
(src/format/apple/{bplist,bookmark}/testdata); every expectation
was recorded by running the reference binary.
"""


def test_bplist_real_object(run, write_fixture):
    """A binary property list with a single real object decodes the header,
    the 3.14159 object, the offset table and the trailer.
    """
    # CATCHES: apple/bplist/bplist.go real object and trailer layout
    write_fixture("bplist_float")

    result = run(['-c', '-d', 'bplist', 'tovalue', 'bplist_float'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"header":{"magic":"bplist","version":"00"},"objects":{"size":8,"size_bits":3,"type":"real","val'
        'ue":3.14159},"offset_table":[8],"trailer":{"object_count":1,"object_reference_size":1,"offset_ta'
        'ble_offset_size":1,"offset_table_start":17,"sort_version":0,"top_object_offset":0,"unused":0}}\n'
    )


def test_bplist_uiautomation_dictionary(run, write_fixture):
    """A one-pair dictionary decodes with key and value indices into the
    object table, resolving the recorded ASCII strings.
    """
    # CATCHES: apple/bplist/bplist.go dict entries and object reference sizes
    write_fixture("bplist_uiautomation")

    result = run(['-c', '-d', 'bplist', 'tovalue', 'bplist_uiautomation'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"header":{"magic":"bplist","version":"00"},"objects":{"entries":[{"key":{"exponent":0,"large_si'
        'ze_marker":1,"size":19,"size_bigint":19,"size_bits":15,"type":"ascii_string","value":"UIAutomati'
        'onEnabled"},"key_index":1,"value":{"type":"singleton","value":true},"value_index":2}],"size":1,"'
        'size_bits":1,"type":"dict"},"offset_table":[8,11,33],"trailer":{"object_count":3,"object_referen'
        'ce_size":1,"offset_table_offset_size":1,"offset_table_start":34,"sort_version":0,"top_object_off'
        'set":0,"unused":0}}\n'
    )


def test_bplist_unicode_dictionary(run, write_fixture):
    """The Unicode-strings vector decodes seven objects; the first dictionary
    entry maps the CFBundleName key to its recorded value.
    """
    # CATCHES: apple/bplist/bplist.go unicode string sizes and entry indices
    write_fixture("bplist_unicode")

    result = run(['-c', '-d', 'bplist', '{objects_count: (.objects | length)}', 'bplist_unicode'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"objects_count":7}\n'

    result = run([
        '-c',
        '-d',
        'bplist',
        '.objects.entries[0] | tovalue | {key_index, value_index}',
        'bplist_unicode',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"key_index":1,"value_index":22}\n'

    result = run([
        '-c',
        '-d',
        'bplist',
        '.objects.entries[0].key | tovalue | {type, value}',
        'bplist_unicode',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"type":"ascii_string","value":"CFBundleName"}\n'

    result = run(['-c', '-d', 'bplist', '.objects.entries[0].value | tovalue', 'bplist_unicode'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"exponent":0,"large_size_marker":1,"size":19,"size_bigint":19,"size_bits":15,"type":"ascii_stri'
        'ng","value":"CoreDeviceUtilities"}\n'
    )


def test_bplist_large_dictionary(run, write_fixture):
    """A 257-object plist forces 2-byte object references and offset-table
    offsets; its dictionary holds 128 entries.
    """
    # CATCHES: apple/bplist/bplist.go wide object reference and offset sizing
    write_fixture("bplist_many")

    result = run(['-c', '-d', 'bplist', '.trailer | tovalue', 'bplist_many'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"object_count":257,"object_reference_size":2,"offset_table_offset_size":2,"offset_table_start":'
        '4219,"sort_version":0,"top_object_offset":0,"unused":0}\n'
    )

    result = run(['-c', '-d', 'bplist', '.objects | tovalue | .size', 'bplist_many'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '128\n'


def test_bookmark_root_structure(run, write_fixture):
    """A bookmark file decodes into its header, the first TOC offset, the
    bookmark entries and the TOC headers.
    """
    # CATCHES: apple/bookmark/apple_bookmark.go root layout
    write_fixture("bmk_sample1")

    result = run(['-c', '-d', 'apple_bookmark', 'keys', 'bmk_sample1'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["header","first_toc_offset","bookmark_entries","toc_headers"]\n'


def test_bookmark_header(run, write_fixture):
    """The magic header carries "book", its 48-byte size, the total size and
    the reserved zero padding.
    """
    # CATCHES: apple/bookmark/apple_bookmark.go header size and magic fields
    write_fixture("bmk_sample1")

    result = run(['-c', '-d', 'apple_bookmark', '.header | tovalue', 'bmk_sample1'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"header_size":48,"magic":"book","reserved":"\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0'
        '000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0'
        '000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000","total_size":560,"unknown":268697600}\n'
    )


def test_bookmark_toc_header(run, write_fixture):
    """The first TOC header records identifier 1, the 0xfffffffe magic, no
    next TOC, 13 entries and a 168-byte TOC size.
    """
    # CATCHES: apple/bookmark/apple_bookmark.go TOC header field decode
    write_fixture("bmk_loop")

    result = run(['-c', '-d', 'apple_bookmark', '.toc_headers[0] | tovalue', 'bmk_loop'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"identifier":1,"magic":4294967294,"next_toc_offset":0,"num_entries_in_toc":13,"toc_size":168}\n'


def test_bookmark_entry_records(run, write_fixture):
    """Bookmark entries resolve their records: an "Applications" string record
    and the "Bitwarden.app" string with its alignment bytes.
    """
    # CATCHES: apple/bookmark/apple_bookmark.go string record data/length/type
    write_fixture("bmk_sample1")

    result = run([
        '-c',
        '-d',
        'apple_bookmark',
        '.bookmark_entries[0].record.data[0] | tovalue',
        'bmk_sample1',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"offset":16,"record":{"alignment_bytes":"\\r\\u0000\\u0000\\u0000","data":"Applications","length":1'
        '2,"type":"string"}}\n'
    )

    result = run([
        '-c',
        '-d',
        'apple_bookmark',
        '.bookmark_entries[0].record.data[1] | tovalue',
        'bmk_sample1',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"offset":36,"record":{"alignment_bytes":"\\u0000\\u0000\\u0000","data":"Bitwarden.app","length":13'
        ',"type":"string"}}\n'
    )


def test_bookmark_entry_count(run, write_fixture):
    """The longest vector decodes all 18 bookmark entries."""
    # CATCHES: apple/bookmark/apple_bookmark.go multi-entry TOC traversal
    write_fixture("bmk_sample4")

    result = run(['-c', '-d', 'apple_bookmark', '.bookmark_entries | length', 'bmk_sample4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '18\n'


def test_bookmark_infinite_recursion_detected(run, write_fixture):
    """The cyclic loop.book vector still exits 0: its display annotates the
    record stream with the reference's infinite-recursion detection message
    at position 0x6c while the partially decoded value stays queryable.
    """
    # CATCHES: apple/bookmark/apple_bookmark.go loop detector annotation in display
    write_fixture("bmk_loop")

    result = run(['-c', '-d', 'apple_bookmark', '.bookmark_entries | length', 'bmk_loop'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '1\n'

    result = run(['-c', '-d', 'apple_bookmark', '.bookmark_entries[0] | tovalue', 'bmk_loop'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"key":"target_path","offset_to_record":60,"record":{"data":[{"offset":60}],"length":8,"type":"a'
        'rray"},"unused":0}\n'
    )

    result = run(['-d', 'apple_bookmark', '.', 'bmk_loop'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: bmk_loop (apple_book'
        'mark)\n'
        '     |                                               |                |  error: apple_bookmark: '
        'error at position 0x6c: infinite recursion detected in record decode function\n'
        '0x000|62 6f 6f 6b 30 02 00 00 00 00 04 10 30 00 00 00|book0.......0...|  header{}:\n'
        '*    |until 0x2f.7 (48)                              |                |\n'
        '0x030|50 01 00 00                                    |P...            |  first_toc_offset: 336\n'
        '0x030|            04 00 00 00 03 03 00 00 00 00 00 20|    ........... |  gap0: raw bits\n'
        '0x040|0c 00 00 00 01 01 00 00 41 70 70 6c 69 63 61 74|........Applicat|\n'
        '*    |until 0x6b.7 (56)                              |                |\n'
        '0x060|                                    08 00 00 00|            ....|  bookmark_entries[0:1]:\n'
        '0x070|01 06 00 00 3c 00 00 00 24 00 00 00 08 00 00 00|....<...$.......|\n'
        '*    |until 0x19f.7 (308)                            |                |\n'
        '0x070|                        24 00 00 00 08 00 00 00|        $.......|  gap1: raw bits\n'
        '0x080|04 03 00 00 67 f5 50 03 00 00 00 00 08 00 00 00|....g.P.........|\n'
        '*    |until 0x17f.7 (264)                            |                |\n'
        '0x180|a8 00 00 00 fe ff ff ff 01 00 00 00 00 00 00 00|................|  toc_headers[0:1]:\n'
        '0x190|0d 00 00 00                                    |....            |\n'
        '0x1a0|05 10 00 00 6c 00 00 00 00 00 00 00 10 10 00 00|....l...........|  gap2: raw bits\n'
        '*    |until 0x22f.7 (end) (144)                      |                |\n'
    )
