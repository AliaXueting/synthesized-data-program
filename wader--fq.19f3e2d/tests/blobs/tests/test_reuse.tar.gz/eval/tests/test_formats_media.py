"""FLAC frame decoding plus Mach-O, moc3, safetensors, markdown
and ICC profile decoders, driven by the reference repository's
test vectors.
"""


def test_flac_metadata_block_types(run, write_fixture):
    """The FLAC stream info lists its metadata blocks in order:
    streaminfo, seektable, vorbis comment and padding.
    """
    # CATCHES: flac metadata block walking and type naming
    write_fixture("flac_mono8", "mono8.flac")

    result = run(['-c', '-d', 'flac', '[.metadatablocks[].type]', 'mono8.flac'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["streaminfo","seektable","vorbis_comment","padding"]\n'


def test_flac_streaminfo(run, write_fixture):
    """The streaminfo block decodes the stream geometry, MD5 signature
    and frame size bounds of the 44.1 kHz 8-bit mono vector.
    """
    # CATCHES: flac streaminfo field decoding incl. MD5 signature
    write_fixture("flac_mono8", "mono8.flac")

    result = run(['-c', '-d', 'flac', '.metadatablocks[0] | tovalue', 'mono8.flac'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"bits_per_sample":8,"channels":1,"last_block":false,"length":34,"maximum_block_size":4096,"maximum_frame_size":3851,"md5":"1b43073d6a826942bca82cfd2ea155f2","minimum_block_size":4096,"minimum_frame_size":10,"sample_rate":44100,"total_samples_in_stream":22050,"type":"streaminfo"}\n'


def test_flac_frame_header(run, write_fixture):
    """A FLAC frame header decodes its sync word, blocking strategy,
    block size, sample rate/size and channel assignment.
    """
    # CATCHES: flac_frame.go frame header CRC-protected field decoding
    write_fixture("flac_mono8", "mono8.flac")

    result = run(['-c', '-d', 'flac', '.frames[1].header | tovalue', 'mono8.flac'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"block_size":4096,"blocking_strategy":"fixed","channel_assignment":1,"crc":16,"end_of_header":{"frame_number":1},"reserved0":0,"reserved1":0,"sample_rate":44100,"sample_size":8,"sync":16382}\n'


def test_flac_frame_header_redecode(run, write_fixture):
    """A frame extracted with tobytes decodes identically through the
    flac_frame decoder, pinning the standalone frame header path.
    """
    # CATCHES: flac_frame.go decoding of a standalone (byte-aligned) frame
    write_fixture("flac_mono8", "mono8.flac")

    result = run([
        '-c',
        '-d',
        'flac',
        '.frames[1] | tobytes | flac_frame | .header | tovalue',
        'mono8.flac',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"block_size":4096,"blocking_strategy":"fixed","channel_assignment":1,"crc":16,"end_of_header":{"frame_number":1},"reserved0":0,"reserved1":0,"sample_rate":44100,"sample_size":8,"sync":16382}\n'


def test_flac_subframe(run, write_fixture):
    """The first subframe of a frame decodes as a fixed predictor
    subframe with one warmup sample and Rice-coded partitions.
    """
    # CATCHES: flac_frame.go subframe header, warmup samples and Rice residual
    write_fixture("flac_mono8", "mono8.flac")

    result = run([
        '-c',
        '-d',
        'flac',
        '.frames[1].subframes[0] | tovalue | {zero_bit, subframe_type, lpc_order, wasted_bits_flag, subframe_sample_size, warmup_samples, residual_coding_method, partition_order, rice_partitions}',
        'mono8.flac',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"lpc_order":1,"partition_order":1,"residual_coding_method":4,"rice_partitions":2,"subframe_sample_size":8,"subframe_type":"fixed","warmup_samples":[0],"wasted_bits_flag":0,"zero_bit":0}\n'


def test_flac_frame_footer_crc(run, write_fixture):
    """The frame footer carries the byte alignment pad and the CRC-16
    of the whole frame.
    """
    # CATCHES: flac_frame.go frame footer byte alignment and CRC
    write_fixture("flac_mono8", "mono8.flac")

    result = run([
        '-c',
        '-d',
        'flac',
        '.frames[1] | tovalue | {byte_align, footer_crc}',
        'mono8.flac',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"byte_align":0,"footer_crc":"5c65"}\n'


def test_flac_frame_and_sample_counts(run, write_fixture):
    """The stream decodes six frames totalling 22050 samples, and the
    computed MD5 of the decoded samples is reported.
    """
    # CATCHES: flac_frame.go frame loop, sample counting and md5_calculated
    write_fixture("flac_mono8", "mono8.flac")

    result = run([
        '-c',
        '-d',
        'flac',
        '{frames: (.frames | length), decoded_samples: .decoded_samples, md5: .md5_calculated}',
        'mono8.flac',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"decoded_samples":22050,"frames":6,"md5":"1b43073d6a826942bca82cfd2ea155f2"}\n'


def test_flac_decoded_md5_matches_streaminfo(run, write_fixture):
    """The MD5 computed over the decoded samples equals the signature
    stored in the streaminfo block.
    """
    # CATCHES: flac_frame.go sample decoding fidelity via md5 comparison
    write_fixture("flac_mono8", "mono8.flac")

    result = run([
        '-c',
        '-d',
        'flac',
        '{md5: .md5_calculated, stream_md5: .metadatablocks[0].md5}',
        'mono8.flac',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"md5":"1b43073d6a826942bca82cfd2ea155f2","stream_md5":"1b43073d6a826942bca82cfd2ea155f2"}\n'


def test_macho_header(run, write_fixture):
    """The Mach-O header decodes its magic, bitness, cpu type, file
    type and load command count.
    """
    # CATCHES: apple/macho/macho.go header decoding and cpu type mapping
    write_fixture("macho_stripped", "a_stripped")

    result = run([
        '-c',
        '-d',
        'macho',
        '.header | tovalue | {magic, bits, cputype, cpusubtype, filetype, ncdms, sizeofncdms}',
        'a_stripped',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"bits":64,"cpusubtype":3,"cputype":"x86_64","filetype":"execute","magic":"64le","ncdms":16,"sizeofncdms":1320}\n'


def test_macho_load_command_names(run, write_fixture):
    """All sixteen load commands of the stripped executable decode and
    are named, from segment_64 through dyld and symbol commands.
    """
    # CATCHES: apple/macho/macho.go load command dispatch and naming
    write_fixture("macho_stripped", "a_stripped")

    result = run(['-c', '-d', 'macho', '[.load_commands[].cmd]', 'a_stripped'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["segment_64","segment_64","segment_64","segment_64","dyld_info_only","symtab","dysymtab","load_dylinker","uuid","version_min_macosx","source_version","main","load_dylib","load_dylib","function_starts","data_in_code"]\n'


def test_macho_first_segment(run, write_fixture):
    """The first load command is a 64-bit segment command with the
    full flag set and no sections.
    """
    # CATCHES: apple/macho/macho.go segment_command_64 decoding incl. flags
    write_fixture("macho_stripped", "a_stripped")

    result = run(['-c', '-d', 'macho', '.load_commands[0] | tovalue', 'a_stripped'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"cmd":"segment_64","cmdsize":72,"sections":[],"segment_command":{"arch_bits":64,"fileoff":0,"flags":{"fvmlib":false,"highvm":false,"noreloc":false,"protected_version_1":false,"reserved0":"\\u0000","reserved1":"\\u0000\\u0000\\u0000"},"initprot":0,"maxprot":0,"nsects":0,"segname":"__PAGEZERO","tfilesize":0,"vmaddr":0,"vmsize":4294967296}}\n'


def test_moc3_header(run, write_fixture):
    """The Live2D moc3 header decodes its magic, version, endianness
    and the reserved padding area.
    """
    # CATCHES: moc3/moc3.go header magic, version enum and unused padding
    write_fixture("moc3_head", "moc3_trunc")

    result = run([
        '-c',
        '-d',
        'moc3',
        'tovalue | {magic, version, is_big_endian, unused0}',
        'moc3_trunc',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"is_big_endian":false,"magic":"MOC3","unused0":"\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000","version":"V5_00_00"}\n'


def test_moc3_decoded_sections(run, write_fixture):
    """Of the moc3 section table, the sections actually decoded from
    the truncated vector are count_info, canvas_info, parts and the
    two deformer tables.
    """
    # CATCHES: moc3/moc3.go section table walking and populated section decoding
    write_fixture("moc3_head", "moc3_trunc")

    result = run(['-c', '-d', 'moc3', '.sections | keys', 'moc3_trunc'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["count_info","canvas_info","parts","deformers","warp_deformers"]\n'


def test_moc3_section_offset_table(run, write_fixture):
    """The section offset table exposes all 43 section keys, from
    count_info through glue_info, in file order.
    """
    # CATCHES: moc3/moc3.go section_offsets table layout
    write_fixture("moc3_head", "moc3_trunc")

    result = run(['-c', '-d', 'moc3', '.section_offsets | keys', 'moc3_trunc'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["count_info","canvas_info","parts","deformers","warp_deformers","rotation_deformers","art_meshes","parameters","part_keyforms","warp_deformer_keyforms","rotation_deformer_keyforms","art_mesh_keyforms","keyform_positions","parameter_binding_indices","keyform_bindings","parameter_bindings","keys","uvs","position_indices","drawable_masks","draw_order_groups","draw_order_group_objects","glue","glue_info","glue_keyforms","warp_deformers_v3_3","parameter_extensions","warp_deformers_v4_2","rotation_deformers_v4_2","art_meshes_v4_2","keyform_multiply_colors","keyform_screen_colors","parameters_v4_2","blend_shape_parameter_bindings","blend_shape_keyform_bindings","blend_shapes_warp_deformers","blend_shapes_art_meshes","blend_shape_constraint_indices","blend_shape_constraints","blend_shape_constraint_values","warp_deformer_keyforms_v5_0","rotation_deformer_keyforms_v5_0","art_mesh_keyforms_v5_0","blend_shapes_parts","blend_shapes_rotation_deformers","blend_shapes_glue","reserved"]\n'


def test_safetensors_header(run, write_fixture):
    """The JSON header of the safetensors file decodes with each
    tensor's dtype, shape and byte range in the data area.
    """
    # CATCHES: safetensors/safetensors.go header JSON and data offset parsing
    write_fixture("safetensors", "test.safetensors")

    result = run(['-c', '-d', 'safetensors', '.header | tovalue', 'test.safetensors'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"weight1":{"data_offsets":[96,144],"dtype":"F32","shape":[12]},"weight2":{"data_offsets":[0,96],"dtype":"I64","shape":[3,4]},"weight3":{"data_offsets":[168,192],"dtype":"F16","shape":[2,2,3]},"weight4":{"data_offsets":[144,168],"dtype":"BF16","shape":[4,3]}}\n'


def test_safetensors_tensor_shapes(run, write_fixture):
    """The tensor data surfaces keyed by name with just the shapes, and
    the padded header size is 264 bytes.
    """
    # CATCHES: safetensors/safetensors.go tensor value mapping and header size
    write_fixture("safetensors", "test.safetensors")

    result = run([
        '-c',
        '-d',
        'safetensors',
        '{header_size: .header_size, shapes: (.tensors | map_values(.shape))}',
        'test.safetensors',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"header_size":264,"shapes":{"weight1":[12],"weight2":[3,4],"weight3":[2,2,3],"weight4":[4,3]}}\n'


def test_markdown_document_value(run, write_fixture):
    """The full markdown document decode tree is pinned: paragraphs,
    headings, emphasis, links, code blocks, lists and tables.
    """
    # CATCHES: markdown/markdown.go block and inline span decoding
    write_fixture("markdown_doc", "test.md")

    result = run(['-c', '-d', 'markdown', '.', 'test.md'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"children":[{"children":["Before"],"type":"paragraph"},{"children":["header 1"],"is_special":false,"is_titleblock":false,"level":1,"type":"heading"},{"children":["Paragraph with ",{"children":["bold"],"type":"strong"}," and ",{"children":["italic"],"type":"em"},"\\non\\nmultiple\\nlines."],"type":"paragraph"},{"children":[{"children":["Some citation"],"type":"paragraph"}],"type":"blockquote"},{"children":["A footnote",{"additional_attributes":[],"children":["^1"],"destination":"footnote1","note_id":0,"type":"link"}," and this also",{"additional_attributes":[],"children":["^note"],"destination":"footnote2","note_id":0,"type":"link"}],"type":"paragraph"},{"children":["header 2"],"is_special":false,"is_titleblock":false,"level":2,"type":"heading"},{"fence_length":0,"fence_offset":0,"info":"jq","is_fenced":true,"literal":"code\\nblock\\n","type":"code_block"},{"fence_length":0,"fence_offset":0,"is_fenced":false,"literal":"also\\ncode\\n","type":"code_block"},{"children":["header 3"],"is_special":false,"is_titleblock":false,"level":3,"type":"heading"},{"children":["Some text with ",{"literal":"code","type":"code"}],"type":"paragraph"},{"children":["header 4"],"is_special":false,"is_titleblock":false,"level":4,"type":"heading"},{"children":["Some text ",{"additional_attributes":[],"children":["with a link"],"destination":"http://host/path","note_id":0,"type":"link"}],"type":"paragraph"},{"children":["An image ",{"children":["img alt text"],"destination":"path/image.png","type":"image"}],"type":"paragraph"},{"children":["header 5"],"is_special":false,"is_titleblock":false,"level":5,"type":"heading"},{"children":[{"bullet_char":"-","children":[{"children":["list of"],"type":"paragraph"}],"delimiter":".","is_footnotes_list":false,"list_flags":[],"tight":false,"type":"list_item"},{"bullet_char":"-","children":[{"children":["things"],"type":"paragraph"}],"delimiter":".","is_footnotes_list":false,"list_flags":[],"tight":false,"type":"list_item"}],"delimiter":".","is_footnotes_list":false,"list_flags":[],"start":0,"tight":true,"type":"list"},{"children":["a table"],"type":"paragraph"},{"children":[{"children":[{"children":[{"children":["a"],"col_span":0,"is_header":true,"type":"table_cell"},{"children":["b"],"col_span":0,"is_header":true,"type":"table_cell"},{"children":["c"],"col_span":0,"is_header":true,"type":"table_cell"}],"type":"table_row"}],"type":"table_header"},{"children":[{"children":[{"children":["1"],"col_span":0,"is_header":false,"type":"table_cell"},{"children":["2"],"col_span":0,"is_header":false,"type":"table_cell"},{"children":["3"],"col_span":0,"is_header":false,"type":"table_cell"}],"type":"table_row"}],"type":"table_body"}],"type":"table"},{"children":["header 6"],"is_special":false,"is_titleblock":false,"level":6,"type":"heading"},{"children":["Some text with line ",{"literal":"<br>","type":"html_span"}," break and ",{"literal":"<b>","type":"html_span"},"bold",{"literal":"</b>","type":"html_span"}],"type":"paragraph"}],"type":"document"}\n'


def test_markdown_node_types(run, write_fixture):
    """Every node type produced by the markdown decoder for the vector
    is enumerated, covering blocks, inlines and table parts.
    """
    # CATCHES: markdown/markdown.go node type coverage for the reference doc
    write_fixture("markdown_doc", "test.md")

    result = run([
        '-c',
        '-d',
        'markdown',
        '[.. | objects | .type? // empty]',
        'test.md',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["document","paragraph","heading","paragraph","strong","em","blockquote","paragraph","paragraph","link","link","heading","code_block","code_block","heading","paragraph","code","heading","paragraph","link","paragraph","image","heading","list","list_item","paragraph","list_item","paragraph","paragraph","table","table_header","table_row","table_cell","table_cell","table_cell","table_body","table_row","table_cell","table_cell","table_cell","heading","paragraph","html_span","html_span","html_span"]\n'


def test_icc_profile_header(run, write_fixture):
    """The ICC profile header decodes its size, signatures, version,
    device class, colour spaces and timestamp.
    """
    # CATCHES: icc/icc_profile.go header signature and field decoding
    write_fixture("icc_adobe", "adobe_linear.icc")

    result = run([
        '-c',
        '-d',
        'icc_profile',
        '.header | tovalue | {size, cmm_type_signature, version_major, version_minor, device_class_signature, color_space, connection_space, timestamp, file_signature, primary_platform, device_manufacturer}',
        'adobe_linear.icc',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"cmm_type_signature":"ADBE","color_space":"RGB","connection_space":"XYZ","device_class_signature":"mntr","device_manufacturer":"none","file_signature":"acsp","primary_platform":"APPL","size":516,"timestamp":{"day":21,"hours":20,"minutes":25,"month":7,"seconds":26,"year":2021},"version_major":2,"version_minor":40}\n'


def test_icc_tag_table(run, write_fixture):
    """The tag table lists all nine tags with signature, offset, size
    and decoded values (copyright, descriptions, XYZ curves).
    """
    # CATCHES: icc/icc_profile.go tag table walking and typed tag values
    write_fixture("icc_adobe", "adobe_linear.icc")

    result = run([
        '-c',
        '-d',
        'icc_profile',
        '.tag_table | tovalue',
        'adobe_linear.icc',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"count":9,"table":[{"alignment":"\\u0000\\u0000","offset":240,"reserved":0,"signature":"cprt","size":50,"text":"Copyright 2021 Adobe Systems Incorporated","type":"text"},{"description":"Adobe RGB (1998) (Linear RGB Profile)","description_length":38,"language_code":0,"localizable_description":"","localizable_description_length":0,"macintosh_description":"","macintosh_description_length":0,"offset":292,"reserved":0,"script_code":0,"signature":"desc","size":128,"type":"desc"},{"offset":420,"reserved":0,"signature":"rXYZ","size":20,"type":"XYZ","x":0.6097412109375,"y":0.3111114501953125,"z":0.01947021484375},{"offset":440,"reserved":0,"signature":"gXYZ","size":20,"type":"XYZ","x":0.2052764892578125,"y":0.62567138671875,"z":0.0608673095703125},{"offset":460,"reserved":0,"signature":"bXYZ","size":20,"type":"XYZ","x":0.1491851806640625,"y":0.0632171630859375,"z":0.74456787109375},{"offset":480,"reserved":0,"signature":"wtpt","size":20,"type":"XYZ","x":0.950439453125,"y":1,"z":1.08905029296875},{"alignment":"\\u0000\\u0000","count":"simple_gamma","gamma":1,"offset":500,"reserved":0,"signature":"rTRC","size":14,"type":"curv"},{"alignment":"\\u0000\\u0000","count":"simple_gamma","gamma":1,"offset":500,"reserved":0,"signature":"gTRC","size":14,"type":"curv"},{"alignment":"\\u0000\\u0000","count":"simple_gamma","gamma":1,"offset":500,"reserved":0,"signature":"bTRC","size":14,"type":"curv"}]}\n'

