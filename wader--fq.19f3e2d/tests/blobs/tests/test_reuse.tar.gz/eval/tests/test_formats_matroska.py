"""Behavioural tests for the Matroska container, including the
inline codec packet decoding of Opus, Vorbis and VP8 tracks.

Vectors come from the reference repository's format test data
(src/format/matroska/testdata); every expectation was recorded by
running the reference binary.
"""


def test_matroska_toplevel_elements(run, write_fixture):
    """A Matroska file is an EBML head followed by one segment, and the
    segment's children are the seek head, void, info, tracks, tags, cluster
    and cues elements.
    """
    # CATCHES: matroska/matroska.go top level and segment child ids
    write_fixture("mkv_opus")

    result = run(['-c', '-d', 'matroska', '[.elements[] | .id]', 'mkv_opus'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["ebml","segment"]\n'

    result = run(['-c', '-d', 'matroska', '[.elements[1].elements[] | .id]', 'mkv_opus'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["seek_head","void","info","tracks","tags","cluster","cues"]\n'


def test_matroska_track_metadata(run, write_fixture):
    """The single track of the Opus vector is an A_OPUS audio track."""
    # CATCHES: matroska/matroska.go track_entry codec_id and track_type lookup
    write_fixture("mkv_opus")

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="tracks") | .elements[] | select(.id=="track_entry") | .elements[] | select(.id=="codec_id" or .id=="track_type") | {id, value}]',
        'mkv_opus',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"id":"codec_id","value":"A_OPUS"},{"id":"track_type","value":"audio"}]\n'


def test_matroska_cluster_children(run, write_fixture):
    """A cluster holds a CRC32, the timestamp, simple blocks and a block
    group, deduplicated here to the unique element ids.
    """
    # CATCHES: matroska/matroska.go cluster element dispatch
    write_fixture("mkv_opus")

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="cluster") | .elements[] | .id] | unique',
        'mkv_opus',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["block_group","crc32","simple_block","timestamp"]\n'


def test_matroska_opus_simple_blocks(run, write_fixture):
    """Each of the two simple blocks decodes an inline Opus packet: mono,
    CELT-only, full-bandwidth 20 ms audio packets.
    """
    # CATCHES: matroska/matroska.go simple_block hand-off to opus_packet
    write_fixture("mkv_opus")

    result = run([
        '-c',
        '-d',
        'matroska',
        '.elements[1].elements[] | select(.id=="cluster") | .elements[] | select(.id=="simple_block") | .packet | {type, stereo: .toc.stereo, mode: .toc.config.mode}',
        'mkv_opus',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"mode":"celt_only","stereo":false,"type":"audio"}\n'
        '{"mode":"celt_only","stereo":false,"type":"audio"}\n'
    )

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="cluster") | .elements[] | select(.id=="simple_block")] | length',
        'mkv_opus',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '2\n'

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="cluster") | .elements[] | select(.id=="simple_block") | .packet.toc | tovalue | {stereo, mode: .config.mode, bandwidth: .config.bandwidth, frame_size: .config.frame_size}]',
        'mkv_opus',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"bandwidth":"fb","frame_size":20,"mode":"celt_only","stereo":false},{"bandwidth":"fb","frame_s'
        'ize":20,"mode":"celt_only","stereo":false}]\n'
    )


def test_matroska_opus_codec_private(run, write_fixture):
    """The track's codec private data decodes as an Opus identification
    ("head") packet.
    """
    # CATCHES: matroska/matroska.go codec_private decode for A_OPUS
    write_fixture("mkv_opus")

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="tracks") | .elements[] | select(.id=="track_entry") | .elements[] | select(.id=="codec_private") | .value | .type]',
        'mkv_opus',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["head"]\n'


def test_matroska_segment_info(run, write_fixture):
    """The info element carries the 1 ms timestamp scale, the muxing app
    string and the segment duration.
    """
    # CATCHES: matroska/matroska.go info element children
    write_fixture("mkv_opus")

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="info") | .elements[] | select(.id=="timestamp_scale" or .id=="muxing_app" or .id=="duration") | {id, value}]',
        'mkv_opus',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"id":"timestamp_scale","value":1000000},{"id":"muxing_app","value":"Lavf58.45.100"},{"id":"dur'
        'ation","value":54}]\n'
    )


def test_matroska_vorbis_track_and_packets(run, write_fixture):
    """The Vorbis vector's track is A_VORBIS audio and both simple blocks
    decode packet_type audio packets.
    """
    # CATCHES: matroska/matroska.go A_VORBIS hand-off to vorbis_packet
    write_fixture("mkv_vorbis")

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="tracks") | .elements[] | select(.id=="track_entry") | .elements[] | select(.id=="codec_id" or .id=="track_type") | {id, value}]',
        'mkv_vorbis',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"id":"codec_id","value":"A_VORBIS"},{"id":"track_type","value":"audio"}]\n'

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="cluster") | .elements[] | select(.id=="simple_block") | .packet | tovalue | .packet_type]',
        'mkv_vorbis',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["audio","audio"]\n'


def test_matroska_block_group_block(run, write_fixture):
    """Inside a block group the Block element also decodes its payload as a
    codec packet, reporting packet_type audio.
    """
    # CATCHES: matroska/matroska.go block_group Block packet decode
    write_fixture("mkv_vorbis")

    result = run([
        '-c',
        '-d',
        'matroska',
        '.elements[1].elements[] | select(.id=="cluster") | .elements[] | select(.id=="block_group") | .elements[] | select(.id=="block") | .packet | tovalue | .packet_type',
        'mkv_vorbis',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"audio"\n'


def test_matroska_vp8_keyframe(run, write_fixture):
    """The VP8 track's simple block decodes a key frame: the start code, the
    320x240 dimensions and the first-partition size in the uncompressed
    tag.
    """
    # CATCHES: vpx/vp8_frame.go key frame tag, start code and dimensions
    write_fixture("mkv_vp8")

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="tracks") | .elements[] | select(.id=="track_entry") | .elements[] | select(.id=="codec_id" or .id=="track_type") | {id, value}]',
        'mkv_vp8',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"id":"codec_id","value":"V_VP8"},{"id":"track_type","value":"video"}]\n'

    result = run([
        '-c',
        '-d',
        'matroska',
        '.elements[1].elements[] | select(.id=="cluster") | .elements[] | select(.id=="simple_block") | .packet | {tag, start_code, width, height, horizontal_scale, vertical_scale}',
        'mkv_vp8',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"height":240,"horizontal_scale":0,"start_code":10289450,"tag":{"first_part_size":725,"first_par'
        't_size0":5,"first_part_size1":90,"frame_type":"key_frame","loop":"Normal","reconstruction":"Bicu'
        'bic","show_frame":1,"version":0},"vertical_scale":0,"width":320}\n'
    )


def test_matroska_vp8_packet_fields(run, write_fixture):
    """A VP8 packet exposes its tag, scale and dimension fields together with
    the raw frame data.
    """
    # CATCHES: vpx/vp8_frame.go packet field naming
    write_fixture("mkv_vp8")

    result = run([
        '-c',
        '-d',
        'matroska',
        '.elements[1].elements[] | select(.id=="cluster") | .elements[] | select(.id=="simple_block") | .packet | tovalue | keys',
        'mkv_vp8',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '["data","height","height0","height1","horizontal_scale","start_code","tag","vertical_scale","wid'
        'th","width0","width1"]\n'
    )


def test_matroska_unknown_size_segment(run, write_fixture):
    """A segment sized with the unknown-size marker still decodes its
    children, minus the trailing cues element a sized segment carries.
    """
    # CATCHES: matroska/matroska.go unknown-size segment termination
    write_fixture("mkv_unknown_size")

    result = run(['-c', '-d', 'matroska', '[.elements[] | .id]', 'mkv_unknown_size'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["ebml","segment"]\n'

    result = run(['-c', '-d', 'matroska', '[.elements[1].elements[] | .id]', 'mkv_unknown_size'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["seek_head","void","info","tracks","tags","cluster"]\n'


def test_matroska_unknown_size_vorbis(run, write_fixture):
    """The unknown-size vector's track is A_VORBIS audio and its simple
    blocks still decode to audio packets.
    """
    # CATCHES: matroska/matroska.go codec decode under an unknown-size parent
    write_fixture("mkv_unknown_size")

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="tracks") | .elements[] | select(.id=="track_entry") | .elements[] | select(.id=="codec_id" or .id=="track_type") | {id, value}]',
        'mkv_unknown_size',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"id":"codec_id","value":"A_VORBIS"},{"id":"track_type","value":"audio"}]\n'

    result = run([
        '-c',
        '-d',
        'matroska',
        '[.elements[1].elements[] | select(.id=="cluster") | .elements[] | select(.id=="simple_block") | .packet | tovalue | .packet_type]',
        'mkv_unknown_size',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["audio","audio"]\n'
