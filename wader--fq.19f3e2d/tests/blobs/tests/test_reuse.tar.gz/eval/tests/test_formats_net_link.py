"""Behavioural tests for the Linux cooked link-layer (SLL and
SLL2) decoders, both bare and inside pcap captures.

The SLL/SLL2 frames are hand-crafted vectors (an IPv4/UDP packet
with a correct checksum, a PPP payload and a netlink control
frame) wrapped in hand-built pcap files; every expectation was
recorded by running the reference binary.
"""


def test_sll_ether_ipv4(run, write_fixture):
    """A cooked capture of a frame we sent carries the ether hardware type,
    the 6-byte link address, 2 padding bytes and a big-endian IPv4 payload.
    """
    # CATCHES: inet/sll_packet.go ether path big-endian protocol dispatch
    write_fixture("sll_ip")

    result = run(['-c', '-d', 'sll_packet', 'tovalue', 'sll_ip'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"arphdr_type":"ether","link_address":"02:11:22:33:44:55","link_address_length":6,"packet_type":'
        '"from_us","padding":"\\u0000\\u0000","payload":{"destination_ip":"192.168.1.20","dont_fragment":fa'
        'lse,"dscp":0,"ecn":0,"fragment_offset":0,"header_checksum":58666,"identification":4660,"ihl":5,"'
        'more_fragments":false,"payload":{"checksum":0,"destination_port":5555,"length":12,"payload":"abc'
        'd","source_port":4444},"protocol":"udp","reserved":0,"source_ip":"192.168.1.10","total_length":3'
        '2,"ttl":64,"version":4},"protocol_type":"ipv4"}\n'
    )


def test_sll_non_ether_payload(run, write_fixture):
    """With a non-ether hardware type the protocol field is read
    little-endian and the payload stays raw; this PPP frame keeps protocol
    33 and its payload bytes.
    """
    # CATCHES: inet/sll_packet.go default path little-endian protocol read
    write_fixture("sll_le")

    result = run(['-c', '-d', 'sll_packet', 'tovalue', 'sll_le'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"arphdr_type":"ppp","link_address":0,"link_address_length":0,"packet_type":"to_us","padding":"\\'
        'u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000","payload":"rawpay","protocol_type":33}\n'
    )


def test_sll2_ether_ipv4(run, write_fixture):
    """The SLL2 header orders protocol, reserved, interface index, hardware
    type and packet type before the address, and dispatches the IPv4
    payload.
    """
    # CATCHES: inet/sll2_packet.go field order and ether dispatch
    write_fixture("sll2_ip")

    result = run(['-c', '-d', 'sll2_packet', 'tovalue', 'sll2_ip'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"arphdr_type":"ether","interface_index":2,"link_address":"02:11:22:33:44:55","link_address_leng'
        'th":6,"packet_type":"to_us","padding":"\\u0000\\u0000","payload":{"destination_ip":"192.168.1.20",'
        '"dont_fragment":false,"dscp":0,"ecn":0,"fragment_offset":0,"header_checksum":58666,"identificati'
        'on":4660,"ihl":5,"more_fragments":false,"payload":{"checksum":0,"destination_port":5555,"length"'
        ':12,"payload":"abcd","source_port":4444},"protocol":"udp","reserved":0,"source_ip":"192.168.1.10'
        '","total_length":32,"ttl":64,"version":4},"protocol_type":"ipv4","reserved":0}\n'
    )


def test_sll2_netlink_control(run, write_fixture):
    """An ARPHRD_NETLINK SLL2 frame on interface 7 sent to others keeps the
    protocol number, the 3-byte address padded to eight, and the raw
    payload.
    """
    # CATCHES: inet/sll2_packet.go non-ether path and address padding
    write_fixture("sll2_netlink")

    result = run(['-c', '-d', 'sll2_packet', 'tovalue', 'sll2_netlink'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"arphdr_type":"netlink","interface_index":7,"link_address":11189196,"link_address_length":3,"pa'
        'cket_type":"to_other","padding":"\\u0000\\u0000\\u0000\\u0000\\u0000","payload":"PAYLOAD9","protocol_'
        'type":16,"reserved":0}\n'
    )


def test_pcap_linux_sll(run, write_fixture):
    """A pcap with linktype LINUX_SLL wraps the cooked header: the file header
    names the linktype and the packet decodes down to the IPv4 payload.
    """
    # CATCHES: pcap linktype 113 dispatch to sll_packet
    write_fixture("pcap_sll")

    result = run(['-c', '-d', 'pcap', '.header | tovalue', 'pcap_sll'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"magic":"little_endian","network":"linux_sll","sigfigs":0,"snaplen":65535,"thiszone":0,"version'
        '_major":2,"version_minor":4}\n'
    )

    result = run([
        '-c',
        '-d',
        'pcap',
        '.packets[0].packet | tovalue | {arphdr_type, packet_type, protocol_type}',
        'pcap_sll',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"arphdr_type":"ether","packet_type":"from_us","protocol_type":"ipv4"}\n'

    result = run([
        '-c',
        '-d',
        'pcap',
        '.packets[0].packet | tovalue | {arphdr_type, protocol_type, link_address}',
        'pcap_sll',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"arphdr_type":"ether","link_address":"02:11:22:33:44:55","protocol_type":"ipv4"}\n'


def test_pcap_linux_sll2(run, write_fixture):
    """A pcap with linktype LINUX_SLL2 decodes its packet through the SLL2
    header with the interface index preserved.
    """
    # CATCHES: pcap linktype 276 dispatch to sll2_packet
    write_fixture("pcap_sll2")

    result = run(['-c', '-d', 'pcap', '.header | tovalue', 'pcap_sll2'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"magic":"little_endian","network":"linux_sll2","sigfigs":0,"snaplen":65535,"thiszone":0,"versio'
        'n_major":2,"version_minor":4}\n'
    )

    result = run([
        '-c',
        '-d',
        'pcap',
        '.packets[0].packet | tovalue | {arphdr_type, interface_index, protocol_type}',
        'pcap_sll2',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"arphdr_type":"ether","interface_index":2,"protocol_type":"ipv4"}\n'
