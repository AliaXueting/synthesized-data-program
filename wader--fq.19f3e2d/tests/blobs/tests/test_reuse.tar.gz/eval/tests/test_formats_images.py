"""Behavioural tests for the JPEG, TIFF and PNG decoders.

Vectors come from the reference repository's format test data
(src/format/{jpeg,tiff,png}/testdata); every expectation was
recorded by running the reference binary.
"""


def test_jpeg_segment_codes(run, write_fixture):
    """A baseline JPEG splits into named segments: SOI, the JFIF APP0, DQT,
    SOF0, two DHT, SOS, the entropy-coded scan, and EOI.
    """
    # CATCHES: jpeg/jpeg.go marker-to-segment name table
    write_fixture("jpeg_4x4")

    result = run(['-c', '-d', 'jpeg', '[.segments[] | .code]', 'jpeg_4x4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["soi","app0","dqt","sof0","dht","dht","sos",null,"eoi"]\n'


def test_jpeg_sof0_frame_header(run, write_fixture):
    """The SOF0 header decodes the 4x4 sample geometry, 8-bit precision, one
    greyscale component and its sampling factors.
    """
    # CATCHES: jpeg/jpeg.go SOF0 frame header and component table
    write_fixture("jpeg_4x4")

    result = run([
        '-c',
        '-d',
        'jpeg',
        '.segments[] | select(.code=="sof0") | tovalue | {nf, p, x, y, lf, frame_components}',
        'jpeg_4x4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"frame_components":[{"c":1,"h":1,"tq":0,"v":1}],"lf":11,"nf":1,"p":8,"x":4,"y":4}\n'


def test_jpeg_dqt_table(run, write_fixture):
    """The DQT segment holds one 8-bit quantisation table in zig-zag order
    with its 67-byte segment length.
    """
    # CATCHES: jpeg/jpeg.go DQT pq/tq bits and the 64-entry table
    write_fixture("jpeg_4x4")

    result = run(['-c', '-d', 'jpeg', '.segments[] | select(.code=="dqt") | tovalue', 'jpeg_4x4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"code":"dqt","lq":67,"prefix":"\\ufffd","qs":[{"pq":0,"q":[8,6,6,7,6,5,8,7,7,7,9,9,8,10,12,20,13'
        ',12,11,11,12,25,18,19,15,20,29,26,31,30,29,26,28,28,32,36,46,39,32,34,44,35,28,28,40,55,41,44,48'
        ',49,52,52,52,31,39,57,61,56,50,60,46,51,52,50],"tq":0}]}\n'
    )


def test_jpeg_sos_scan_header(run, write_fixture):
    """The SOS header names the single scan component with its spectral
    selection, successive approximation bits and the component list.
    """
    # CATCHES: jpeg/jpeg.go SOS scan component list and ah/al bits
    write_fixture("jpeg_4x4")

    result = run([
        '-c',
        '-d',
        'jpeg',
        '.segments[] | select(.code=="sos") | tovalue | {ns, ss, se, ah, al, scan_components}',
        'jpeg_4x4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"ah":0,"al":0,"ns":1,"scan_components":[{"cs":1,"ta":0,"td":0}],"se":63,"ss":0}\n'


def test_tiff_root_structure(run, write_fixture):
    """The little-endian TIFF root keeps the byte order, the 42 magic, the
    first IFD offset, the decoded strips and any gap bytes.
    """
    # CATCHES: tiff/tiff.go root fields and gap collection
    write_fixture("tiff_4x4")

    result = run(['-c', '-d', 'tiff', 'keys', 'tiff_4x4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["endian","order","integer_42","first_ifd","strips","ifds","gap0"]\n'


def test_tiff_ifd_tag_names(run, write_fixture):
    """The first IFD's entries resolve to their symbolic tag names, from
    ImageWidth through the strip layout to the software string.
    """
    # CATCHES: tiff/tiff.go IFD tag symbol table
    write_fixture("tiff_4x4")

    result = run(['-c', '-d', 'tiff', '[.ifds[0].entries[] | .tag]', 'tiff_4x4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '["ImageWidth","ImageLength","BitsPerSample","Compression","PhotometricInterpretation","DocumentN'
        'ame","StripOffsets","SamplesPerPixel","RowsPerStrip","StripByteCounts","PlanarConfiguration","Pa'
        'geNumber","Software","SampleFormat"]\n'
    )


def test_tiff_first_entry(run, write_fixture):
    """The first IFD entry is ImageWidth, a SHORT with one value of 4 pixels
    read through the value offset.
    """
    # CATCHES: tiff/tiff.go entry type/count/value_offset decoding
    write_fixture("tiff_4x4")

    result = run(['-c', '-d', 'tiff', '.ifds[0].entries[0] | tovalue', 'tiff_4x4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"count":1,"tag":"ImageWidth","type":"SHORT","value_offset":4,"values":[4]}\n'


def test_png_1bit_grayscale(run, write_fixture):
    """A 4x4 1-bit greyscale PNG decodes its mandatory chunks plus gAMA, cHRM,
    bKGD, tIME and text chunks, and the IHDR fields match the geometry.
    """
    # CATCHES: png/png.go chunk iteration and IHDR field decoding
    write_fixture("png_4x4")

    result = run(['-c', '-d', 'png', '[.chunks[] | .type]', 'png_4x4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["IHDR","gAMA","cHRM","bKGD","tIME","IDAT","tEXt","tEXt","zTXt","IEND"]\n'

    result = run(['-c', '-d', 'png', '.chunks[] | select(.type=="IHDR") | tovalue', 'png_4x4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"ancillary":false,"bit_depth":1,"color_type":"grayscale","compression_method":"deflate","crc":2'
        '173346771,"filter_method":"adaptive_filtering","height":4,"interlace_method":"none","length":13,'
        '"private":false,"reserved":false,"safe_to_copy":false,"type":"IHDR","width":4}\n'
    )


def test_png_palette_colormap(run, write_fixture):
    """The palette PNG decodes IHDR with color_type palette and 2 bits per
    pixel, followed by the PLTE chunk before IDAT.
    """
    # CATCHES: png/png.go palette color type and PLTE ordering
    write_fixture("png")

    result = run(['-c', '-d', 'png', '[.chunks[] | .type]', 'png'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["IHDR","PLTE","IDAT","IEND"]\n'

    result = run(['-c', '-d', 'png', '.chunks[] | select(.type=="IHDR") | tovalue', 'png'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"ancillary":false,"bit_depth":2,"color_type":"palette","compression_method":"deflate","crc":356'
        '7220461,"filter_method":"adaptive_filtering","height":4,"interlace_method":"none","length":13,"p'
        'rivate":false,"reserved":false,"safe_to_copy":false,"type":"IHDR","width":4}\n'
    )


def test_apng_animation_chunks(run, write_fixture):
    """An animated PNG carries the acTL control chunk, per-frame fcTL and the
    fdAT frame data chunks between IDAT and IEND.
    """
    # CATCHES: png/png.go animation chunk sequence
    write_fixture("png_apng")

    result = run(['-c', '-d', 'png', '[.chunks[] | .type]', 'png_apng'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["IHDR","pHYs","acTL","fcTL","IDAT","fcTL","fdAT","IEND"]\n'
