"""Raw string input (-R), slurp (-s) and the input/inputs builtins, ported
from the native pkg/interp/testdata/string_input.fqtest and raw.fqtest
scripts of the reference repository."""

import pytest


@pytest.fixture
def raw_files(write):
    """The two raw input files used by the native raw.fqtest script."""
    write("a", "a\nb\n")
    write("c", "c\n")
    return ("a", "c")


def test_raw_input_lines_from_files(run, raw_files):
    """-R reads files line by line as strings."""
    result = run(["-R", ".", "a", "c"])
    # CATCHES: each input line (newline included, last line too) becomes
    # one JSON string output, in file order.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a"\n"b"\n"c"\n'


def test_raw_slurp_files(run, raw_files):
    """-Rs concatenates every file into one string."""
    result = run(["-Rs", ".", "a", "c"])
    # CATCHES: slurp joins all inputs (files and stdin alike) into a single
    # string that keeps every newline.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a\\nb\\nc\\n"\n'


def test_raw_slurp_input_builtin(run, raw_files):
    """-nRs input reads the whole slurped input once."""
    result = run(["-nRs", "input", "a", "c"])
    # CATCHES: 'input' under -nRs yields the single concatenated string,
    # identical to the default expression result.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a\\nb\\nc\\n"\n'


def test_raw_slurp_inputs_builtin(run, raw_files):
    """-nRs inputs enumerates the slurped inputs."""
    result = run(["-nRs", "inputs", "a", "c"])
    # CATCHES: with slurp there is only one input left, so 'inputs' emits
    # the same concatenated string exactly once.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a\\nb\\nc\\n"\n'


def test_raw_input_from_stdin(run):
    """-R reads stdin line by line."""
    result = run(["-R"], stdin="a\nb\nc\n")
    # CATCHES: stdin is treated exactly like a file input for raw mode,
    # producing one string per line.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a"\n"b"\n"c"\n'


def test_raw_input_builtin_from_stdin(run):
    """-nR input reads the first stdin line."""
    result = run(["-nR", "input"], stdin="a\nb\nc\n")
    # CATCHES: the input builtin advances the raw input stream by one line
    # and yields only that first line.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a"\n'


def test_raw_inputs_builtin_from_stdin(run):
    """-nR inputs enumerates every stdin line."""
    result = run(["-nR", "inputs"], stdin="a\nb\nc\n")
    # CATCHES: the inputs builtin yields each remaining raw line as its own
    # string output.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a"\n"b"\n"c"\n'


def test_raw_slurp_stdin(run):
    """-Rs slurps stdin into one string."""
    result = run(["-Rs"], stdin="a\nb\nc\n")
    # CATCHES: slurping stdin keeps the whole input including newlines as a
    # single JSON string.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a\\nb\\nc\\n"\n'


def test_raw_input_missing_file(run):
    """-R with a missing file is an IO error."""
    result = run(["-R", ".", "missing"])
    # CATCHES: raw mode still opens every named file, so a missing path
    # exits 2 with the usual message and no output at all.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: missing: no such file or directory\n"


def test_raw_slurp_missing_file(run):
    """-Rs with a missing file still outputs the empty slurp."""
    result = run(["-Rs", ".", "missing"])
    # CATCHES: slurp mode emits the empty string on stdout before the file
    # open error is reported, so stdout is '""' and the exit code is 2.
    assert result.returncode == 2
    assert result.out == '""\n'
    assert result.err == "error: missing: no such file or directory\n"


def test_raw_input_without_trailing_newline(run, write):
    """-R keeps a last line without trailing newline."""
    write("noeol", "a\nb")
    result = run(["-R", ".", "noeol"])
    # CATCHES: the final line is emitted even when the file does not end
    # with a newline, and the string never contains the newline itself.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a"\n"b"\n'


def test_json_input_file_probe(run, write):
    """A JSON file is decoded by probing without any -d flag."""
    write("in.json", '{"a":1}')
    result = run(["-c", ".", "in.json"])
    # CATCHES: the default probe group recognises JSON files, so no -d flag
    # is needed and the object is echoed compactly.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"a":1}\n'
