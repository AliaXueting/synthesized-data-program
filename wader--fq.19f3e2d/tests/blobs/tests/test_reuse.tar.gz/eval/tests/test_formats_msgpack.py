"""Behavioural tests for the MessagePack decoder.

Vectors come from the reference repository's format test data
(src/format/msgpack/testdata); every expectation was recorded by
running the reference binary.
"""


def test_msgpack_type_showcase(run, write_fixture):
    """A document mixing strings, arrays, maps, binaries and numbers decodes
    with each element carrying its marker family name in type.
    """
    # CATCHES: msgpack/msgpack.go marker family names across type values
    write_fixture("msgpack_types")

    result = run(['-c', '-d', 'msgpack', 'tovalue', 'msgpack_types'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"length":7,"pairs":[{"key":{"length":5,"type":"fixstr","value":"array"},"value":{"elements":[{"'
        'type":"positive_fixint","value":1},{"type":"positive_fixint","value":2},{"type":"positive_fixint'
        '","value":3}],"length":3,"type":"fixarray"}},{"key":{"length":6,"type":"fixstr","value":"object"'
        '},"value":{"length":1,"pairs":[{"key":{"length":3,"type":"fixstr","value":"key"},"value":{"lengt'
        'h":5,"type":"fixstr","value":"value"}}],"type":"fixmap"}},{"key":{"length":6,"type":"fixstr","va'
        'lue":"number"},"value":{"type":"positive_fixint","value":123}},{"key":{"length":6,"type":"fixstr'
        '","value":"string"},"value":{"length":3,"type":"fixstr","value":"abc"}},{"key":{"length":4,"type'
        '":"fixstr","value":"true"},"value":{"type":"true","value":true}},{"key":{"length":5,"type":"fixs'
        'tr","value":"false"},"value":{"type":"false","value":false}},{"key":{"length":4,"type":"fixstr",'
        '"value":"null"},"value":{"type":"nil","value":null}}],"type":"fixmap"}\n'
    )


def test_msgpack_integer_vector(run, write_fixture):
    """The integer vector walks positive and negative fixints and the signed
    and unsigned 8/16/32/64 forms, each exposing its decoded value.
    """
    # CATCHES: msgpack/msgpack.go fixint and int/uint width decoding
    write_fixture("msgpack_ints")

    result = run(['-c', '-d', 'msgpack', 'tovalue', 'msgpack_ints'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"elements":[{"type":"positive_fixint","value":0},{"type":"positive_fixint","value":1},{"type":"'
        'positive_fixint","value":2},{"type":"positive_fixint","value":3},{"type":"positive_fixint","valu'
        'e":4},{"type":"positive_fixint","value":5},{"type":"positive_fixint","value":6},{"type":"positiv'
        'e_fixint","value":7},{"type":"positive_fixint","value":8},{"type":"positive_fixint","value":9},{'
        '"type":"positive_fixint","value":127},{"type":"uint8","value":128},{"type":"negative_fixint","va'
        'lue":-1},{"type":"negative_fixint","value":-2},{"type":"negative_fixint","value":-3},{"type":"ne'
        'gative_fixint","value":-4},{"type":"negative_fixint","value":-5},{"type":"negative_fixint","valu'
        'e":-6},{"type":"negative_fixint","value":-7},{"type":"negative_fixint","value":-8},{"type":"nega'
        'tive_fixint","value":-31},{"type":"negative_fixint","value":-32},{"type":"uint32","value":429496'
        '7295},{"type":"int64","value":-4294967295},{"type":"uint32","value":2147483647},{"type":"int32",'
        '"value":-2147483647}],"length":26,"type":"array16"}\n'
    )


def test_msgpack_string_vector(run, write_fixture):
    """A 34-element array16 of growing strings keeps every value; fixstr,
    str8 and str16 markers all decode to their text.
    """
    # CATCHES: msgpack/msgpack.go fixstr through str16 width switching
    write_fixture("msgpack_strs")

    result = run(['-c', '-d', 'msgpack', '{type, length}', 'msgpack_strs'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"length":34,"type":"array16"}\n'

    result = run(['-c', '-d', 'msgpack', '[.elements[] | .value]', 'msgpack_strs'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '["","a","aa","aaa","aaaa","aaaaa","aaaaaa","aaaaaaa","aaaaaaaa","aaaaaaaaa","aaaaaaaaaa","aaaaaa'
        'aaaaa","aaaaaaaaaaaa","aaaaaaaaaaaaa","aaaaaaaaaaaaaa","aaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaa","aaa'
        'aaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaa'
        'aaaaaaaa","aaaaaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaaaaaa","aaaaaaa'
        'aaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaa'
        'aaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaa'
        'aaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"]\n'
    )


def test_msgpack_nested_arrays(run, write_fixture):
    """Nested arrays decode recursively: an empty fixarray, then arrays of
    strings, with each level's length and marker type recorded.
    """
    # CATCHES: msgpack/msgpack.go nested array recursion and lengths
    write_fixture("msgpack_arrays")

    result = run([
        '-c',
        '-d',
        'msgpack',
        '{type, length, e0: .elements[0], e1: .elements[1], e2: .elements[2]}',
        'msgpack_arrays',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"e0":{"elements":[],"length":0,"type":"fixarray"},"e1":{"elements":[{"length":1,"type":"fixstr"'
        ',"value":"a"}],"length":1,"type":"fixarray"},"e2":{"elements":[{"length":1,"type":"fixstr","valu'
        'e":"a"},{"length":1,"type":"fixstr","value":"a"},{"length":1,"type":"fixstr","value":"a"},{"leng'
        'th":1,"type":"fixstr","value":"a"}],"length":4,"type":"fixarray"},"length":6,"type":"fixarray"}\n'
    )


def test_msgpack_nested_maps(run, write_fixture):
    """Nested maps decode as fixmaps with key/value pairs of decoded
    elements, from the empty map up to a four-pair map.
    """
    # CATCHES: msgpack/msgpack.go map pair structuring and nesting
    write_fixture("msgpack_objects")

    result = run([
        '-c',
        '-d',
        'msgpack',
        '{type, length, e0: .elements[0], e1: .elements[1]}',
        'msgpack_objects',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"e0":{"length":0,"pairs":[],"type":"fixmap"},"e1":{"length":1,"pairs":[{"key":{"length":1,"type'
        '":"fixstr","value":"0"},"value":{"length":1,"type":"fixstr","value":"a"}}],"type":"fixmap"},"len'
        'gth":6,"type":"fixarray"}\n'
    )
