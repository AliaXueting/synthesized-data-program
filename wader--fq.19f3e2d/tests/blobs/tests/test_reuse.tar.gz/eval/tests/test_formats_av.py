"""Behavioural tests for the AVC/H.264, HEVC/H.265, AV1 and AAC
decoders.

Vectors come from the reference repository's format test data
(src/format/mpeg/testdata, src/format/av1/testdata); every
expectation was recorded by running the reference binary.
"""


def test_avc_annexb_nalu_types(run, write_fixture):
    """An AVC Annex B stream splits on its 00 00 01 start codes and each
    NAL unit gets its semantic type name.

    The reference vector holds one SPS, one PPS, one SEI and one IDR
    slice unit, in that order.
    """
    # CATCHES: mpeg/avc_nalu.go start-code scanning and nal_unit_type mapping
    write_fixture("avc_annexb")

    result = run([
        '-c',
        '-d',
        'avc_annexb',
        '[.[] | objects | .nal_unit_type]',
        'avc_annexb',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["sps","pps","sei","idr_slice"]\n'


def test_avc_annexb_alternates_gap_strings_and_nalus(run, write_fixture):
    """Annex B decoding interleaves raw start-code gap strings with the
    parsed NAL unit objects in the root array.
    """
    # CATCHES: mpeg/avc_nalu.go root array mixing string gaps and NAL objects
    write_fixture("avc_annexb")

    result = run(['-c', '-d', 'avc_annexb', '[.[] | type]', 'avc_annexb'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["string","object","string","object","string","object","string","object"]\n'


def test_avc_sps_fields(run, write_fixture):
    """The sequence parameter set RBSP decodes into profile, level and
    picture geometry fields.

    The vector is a high 4:4:4 predictive profile, level 1.3,
    320x240 (20x15 macroblocks) stream with VUI parameters present.
    """
    # CATCHES: mpeg/avc_sps.go profile/level enums, geometry maths and VUI flag
    write_fixture("avc_annexb")

    result = run([
        '-c',
        '-d',
        'avc_annexb',
        '.[1].rbsp | tovalue | {profile_idc, level_idc, chroma_format_idc, pic_width_in_mbs, pic_height_in_map_units, log2_max_frame_num, max_num_ref_frames, frame_mbs_only_flag, vui_parameters_present_flag}',
        'avc_annexb',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"chroma_format_idc":"4:4:4","frame_mbs_only_flag":true,"level_idc":"1.3","log2_max_frame_num":4,"max_num_ref_frames":4,"pic_height_in_map_units":15,"pic_width_in_mbs":20,"profile_idc":"high_444_predictive_profile","vui_parameters_present_flag":true}\n'


def test_avc_pps_fields(run, write_fixture):
    """The picture parameter set RBSP exposes the quantisation and
    entropy coding switches of the same stream, including CABAC and
    8x8 transform mode.
    """
    # CATCHES: mpeg/avc_pps.go PPS switches incl. transform_8x8 and chroma offsets
    write_fixture("avc_annexb")

    result = run([
        '-c',
        '-d',
        'avc_annexb',
        '.[3].rbsp | tovalue | {pic_parameter_set_id, seq_parameter_set_id, entropy_coding_mode_flag, num_slice_groups, pic_init_qp, pic_init_qs, chroma_qp_index_offset, deblocking_filter_control_present_flag, transform_8x8_mode_flag, second_chroma_qp_index_offset}',
        'avc_annexb',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"chroma_qp_index_offset":4,"deblocking_filter_control_present_flag":true,"entropy_coding_mode_flag":true,"num_slice_groups":1,"pic_init_qp":23,"pic_init_qs":26,"pic_parameter_set_id":0,"second_chroma_qp_index_offset":4,"seq_parameter_set_id":0,"transform_8x8_mode_flag":true}\n'


def test_avc_sei_recovery_point(run, write_fixture):
    """A standalone SEI NAL unit decodes into its recovery point payload
    with the recovery frame count and associated flags.
    """
    # CATCHES: mpeg/avc_sei.go payload_type dispatch and recovery_point fields
    write_fixture("avc_sei_recovery", "avc_nalu_sei_recovery_point")

    result = run([
        '-c',
        '-d',
        'avc_nalu',
        '.rbsp | tovalue | {payload_type, payload_size, recovery_frame_cnt, exact_match_flag, broken_link_flag, changing_slice_group_idc}',
        'avc_nalu_sei_recovery_point',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"broken_link_flag":false,"changing_slice_group_idc":0,"exact_match_flag":true,"payload_size":1,"payload_type":"recovery_point","recovery_frame_cnt":0}\n'


def test_avc_pps_stop_bit_with_trailing_bits(run, write_fixture):
    """A PPS whose rbsp_stop_one_bit lands mid-byte still decodes, and
    the remaining trailing bits are exposed as a field rather than
    confusing the parser.
    """
    # CATCHES: mpeg/avc_pps.go stop-bit/trailing-bit handling past the byte edge
    write_fixture("avc_pps_stop", "avc_pps_stop_more_8bit")

    result = run([
        '-c',
        '-d',
        'avc_pps',
        'tovalue | {pic_parameter_set_id, seq_parameter_set_id, num_slice_groups, num_ref_idx_l0_default_active, num_ref_idx_l1_default_active, weighted_bipred_idc, pic_init_qp, pic_init_qs, chroma_qp_index_offset, stop_one_bit, trailing_bits}',
        'avc_pps_stop_more_8bit',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"chroma_qp_index_offset":0,"num_ref_idx_l0_default_active":1,"num_ref_idx_l1_default_active":1,"num_slice_groups":1,"pic_init_qp":25,"pic_init_qs":26,"pic_parameter_set_id":0,"seq_parameter_set_id":0,"stop_one_bit":true,"trailing_bits":"\\u0000\\u0000","weighted_bipred_idc":0}\n'


def test_hevc_nalu_types(run, write_fixture):
    """An HEVC Annex B stream splits into its NAL units, each carrying
    the two-layer HEVC type name (parameter sets, prefix SEI, IDR).
    """
    # CATCHES: mpeg/hevc NAL header parsing and unit_type naming
    write_fixture("hevc_annexb")

    result = run([
        '-c',
        '-d',
        'hevc_annexb',
        '[.[] | objects | .nal_unit_type]',
        'hevc_annexb',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["VPS_NUT","SPS_NUT","PPS_NUT","PREFIX_SEI_NUT","IDR_N_LP"]\n'


def test_hevc_sps_fields(run, write_fixture):
    """The HEVC sequence parameter set decodes its profile_tier_level,
    picture size and bit depth fields.

    The vector is a 4:4:4 8-bit 320x240 stream (general profile 4,
    level 60) with sample adaptive offset enabled.
    """
    # CATCHES: mpeg/hevc_sps.go profile_tier_level and picture size decoding
    write_fixture("hevc_annexb")

    result = run([
        '-c',
        '-d',
        'hevc_annexb',
        '.[3].rbsp | tovalue | {sps_video_parameter_set_id, sps_max_sub_layers_minus1, general_profile_idc, general_level_idc, sps_seq_parameter_set_id, chroma_format_idc, pic_width_in_luma_samples, pic_height_in_luma_samples, bit_depth_luma_minus8, bit_depth_chroma_minus8, log2_max_pic_order_cnt_lsb_minus4, amp_enabled_flag, sample_adaptive_offset_enabled_flag}',
        'hevc_annexb',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"amp_enabled_flag":false,"bit_depth_chroma_minus8":0,"bit_depth_luma_minus8":0,"chroma_format_idc":"4:4:4","general_level_idc":60,"general_profile_idc":4,"log2_max_pic_order_cnt_lsb_minus4":4,"pic_height_in_luma_samples":240,"pic_width_in_luma_samples":320,"sample_adaptive_offset_enabled_flag":true,"sps_max_sub_layers_minus1":0,"sps_seq_parameter_set_id":0,"sps_video_parameter_set_id":0}\n'


def test_hevc_pps_full_value(run, write_fixture):
    """The full decoded value of the HEVC picture parameter set pins
    every PPS switch at once: tile, quadtree and deblocking fields.
    """
    # CATCHES: mpeg/hevc_pps.go complete PPS field set for the reference vector
    write_fixture("hevc_annexb")

    result = run(['-c', '-d', 'hevc_annexb', '.[5].rbsp | tovalue', 'hevc_annexb'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"cabac_init_present_flag":false,"constrained_intra_pred_flag":false,"cu_qp_delta_enabled_flag":true,"deblocking_filter_control_present_flag":false,"dependent_slice_segments_enabled_flag":false,"diff_cu_qp_delta_depth":1,"entropy_coding_sync_enabled_flag":true,"init_qp_minus26":0,"lists_modification_present_flag":false,"log2_parallel_merge_level_minus2":0,"num_extra_slice_header_bits":0,"num_ref_idx_l0_default_active_minus1":0,"num_ref_idx_l1_default_active_minus1":0,"output_flag_present_flag":false,"pps_cb_qp_offset":6,"pps_cr_qp_offset":6,"pps_extension_present_flag":false,"pps_loop_filter_across_slices_enabled_flag":true,"pps_pic_parameter_set_id":0,"pps_scaling_list_data_present_flag":false,"pps_seq_parameter_set_id":0,"pps_slice_chroma_qp_offsets_present_flag":false,"sign_data_hiding_enabled_flag":true,"slice_segment_header_extension_present_flag":false,"tiles_enabled_flag":false,"transform_skip_enabled_flag":false,"transquant_bypass_enabled_flag":false,"unknown":"\\ufffd","weighted_bipred_flag":false,"weighted_pred_flag":true}\n'


def test_hevc_prefix_sei_user_data(run, write_fixture):
    """The PREFIX_SEI NAL unit carries x265's unregistered user data:
    the encoder version string is visible inside the decoded payload.
    """
    # CATCHES: mpeg/avc_sei.go shared SEI payload decoding (user_data_unregistered)
    write_fixture("hevc_annexb")

    result = run(['-c', '-d', 'hevc_annexb', '.[7].rbsp | tovalue', 'hevc_annexb'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"data":"\\u0005\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd,\\ufffd\\ufffd\\t\\ufffd\\u0017GۻU\\ufffd\\ufffd\\u007f\\ufffd\\ufffdNx265 (build 199) - 3.4+31-6722fce1f:[Linux][GCC 10.2.1][64 bit] 8bit - H.265/HEVC codec - Copyright 2013-2018 (c) Multicoreware, Inc - http://x265.org - options: cpuid=1111039 frame-threads=1 wpp no-pmode no-pme no-psnr no-ssim log-level=2 bitdepth=8 input-csp=3 fps=25/1 input-res=320x240 interlace=0 total-frames=0 level-idc=0 high-tier=1 uhd-bd=0 ref=3 no-allow-non-conformance repeat-headers annexb no-aud no-hrd info hash=0 no-temporal-layers open-gop min-keyint=25 keyint=250 gop-lookahead=0 bframes=4 b-adapt=2 b-pyramid bframe-bias=0 rc-lookahead=20 lookahead-slices=0 scenecut=40 hist-scenecut=0 radl=0 no-splice no-intra-refresh ctu=64 min-cu-size=8 no-rect no-amp max-tu-size=32 tu-inter-depth=1 tu-intra-depth=1 limit-tu=0 rdoq-level=0 dynamic-rd=0.00 no-ssim-rd signhide no-tskip nr-intra=0 nr-inter=0 no-constrained-intra strong-intra-smoothing max-merge=3 limit-refs=1 no-limit-modes me=1 subme=2 merange=57 temporal-mvp no-frame-dup no-hme weightp no-weightb no-analyze-src-pics deblock=0:0 sao no-sao-non-deblock rd=3 selective-sao=4 early-skip rskip no-fast-intra no-tskip-fast no-cu-lossless b-intra no-splitrd-skip rdpenalty=0 psy-rd=2.00 psy-rdoq=0.00 no-rd-refine no-lossless cbqpoffs=6 crqpoffs=6 rc=crf crf=28.0 qcomp=0.60 qpstep=4 stats-write=0 stats-read=0 ipratio=1.40 pbratio=1.30 aq-mode=2 aq-strength=1.00 cutree zone-count=0 no-strict-cbr qg-size=32 no-rc-grain qpmax=69 qpmin=0 no-const-vbv sar=1 overscan=0 videoformat=5 range=1 colorprim=2 transfer=2 colormatrix=0 chromaloc=0 display-window=0 cll=0,0 min-luma=0 max-luma=255 log2-max-poc-lsb=8 vui-timing-info vui-hrd-info slices=1 no-opt-qp-pps no-opt-ref-list-length-pps no-multi-pass-opt-rps scenecut-bias=0.05 hist-threshold=0.03 no-opt-cu-delta-qp no-aq-motion no-hdr10 no-hdr10-opt no-dhdr10-opt no-idr-recovery-sei analysis-reuse-level=0 analysis-save-reuse-level=0 analysis-load-reuse-level=0 scale-factor=0 refine-intra=0 refine-inter=0 refine-mv=1 refine-ctu-distortion=0 no-limit-sao ctu-info=0 no-lowpass-dct refine-analysis-type=0 copy-pic=1 max-ausize-factor=1.0 no-dynamic-refine no-single-sei no-hevc-aq no-svt no-field qp-adaptation-range=1.00 scenecut-aware-qp=0conformance-window-offsets right=0 bottom=0 decoder-max-rate=0 no-vbv-live-multi-pass\\ufffd"}\n'


def test_av1_obu_header(run, write_fixture):
    """The AV1 OBU header bit layout decodes: type, size field presence
    and the forbidden/reserved bits.
    """
    # CATCHES: av1/av1_obu.go OBU header field decoding
    write_fixture("av1_obu", "av1_obu_seq_header_film_grain_chrome_sample_pos")

    result = run([
        '-c',
        '-d',
        'av1_obu',
        '.header | tovalue',
        'av1_obu_seq_header_film_grain_chrome_sample_pos',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"extension_flag":false,"forbidden_bit":0,"has_size_field":true,"reserved_1bit":0,"type":"sequence_header"}\n'


def test_av1_sequence_header_full_value(run, write_fixture):
    """The full sequence_header OBU value pins the colour config, film
    grain and chroma sample position parameters of the vector.
    """
    # CATCHES: av1/av1_obu.go sequence header colour config and film grain params
    write_fixture("av1_obu", "av1_obu_seq_header_film_grain_chrome_sample_pos")

    result = run([
        '-c',
        '-d',
        'av1_obu',
        'tovalue',
        'av1_obu_seq_header_film_grain_chrome_sample_pos',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"color_config":{"bit_depth":8,"chroma_sample_position":0,"color_description_present_flag":1,"color_primaries":"bt_709","color_range":0,"high_bitdepth":0,"matrix_coefficients":"bt_709","mono_chrome":0,"separate_uv_delta_q":0,"subsampling_x":1,"subsampling_y":1,"transfer_characteristics":"bt_709"},"data":"\\ufffd","enable_cdef":1,"enable_dual_filter":0,"enable_filter_intra":0,"enable_interintra_compound":1,"enable_intra_edge_filter":1,"enable_jnt_comp":0,"enable_masked_compound":0,"enable_order_hint":1,"enable_ref_frame_mvs":1,"enable_restoration":1,"enable_superres":0,"enable_warped_motion":1,"film_grain_params_present":1,"frame_height":1080,"frame_height_bits_minus_1":10,"frame_id_numbers_present_flag":0,"frame_width":1920,"frame_width_bits_minus_1":10,"header":{"extension_flag":false,"forbidden_bit":0,"has_size_field":true,"reserved_1bit":0,"type":"sequence_header"},"initial_display_delay_present_flag":0,"max_frame_height_minus_1":1079,"max_frame_width_minus_1":1919,"operating_points":[{"operating_point_idc":0,"seq_level_idx":8,"seq_tier":0}],"operating_points_cnt_minus_1":0,"order_hint_bits_minus_1":6,"reduced_still_picture_header":0,"seq_choose_integer_mv":1,"seq_choose_screen_content_tools":1,"seq_profile":"main","size":14,"still_picture":0,"timing_info_present_flag":0,"use_128x128_superblock":0}\n'


def test_aac_frame_syntax_elements(run, write_fixture):
    """A raw AAC frame decodes into its syntax elements: a fill element,
    a channel pair element and two end markers.
    """
    # CATCHES: mpeg/aac_frame.go syntax element id decoding and frame termination
    write_fixture("aac_frame")

    result = run(['-c', '-d', 'aac_frame', '[.[] | .syntax_element]', 'aac_frame'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["FIL","CPE",null,null]\n'


def test_aac_channel_pair_element(run, write_fixture):
    """The channel_pair_element of the frame decodes its instance tag
    and the common_window flag.
    """
    # CATCHES: mpeg/aac_frame.go channel pair element header fields
    write_fixture("aac_frame")

    result = run(['-c', '-d', 'aac_frame', '.[1] | tovalue', 'aac_frame'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"common_window":true,"element_instance_tag":0,"syntax_element":"CPE"}\n'

