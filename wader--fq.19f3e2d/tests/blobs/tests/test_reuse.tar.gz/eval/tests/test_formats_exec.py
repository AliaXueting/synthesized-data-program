"""Behavioural tests for the ELF, ar archive and WebAssembly
decoders.

Vectors come from the reference repository's format test data
(src/format/{elf,ar,wasm}/testdata); every expectation was
recorded by running the reference binary.
"""


def test_elf_header_ident(run, write_fixture):
    """The ELF header decodes the ident block (64-bit, little endian, x86-64),
    the entry point and the header table sizes.
    """
    # CATCHES: elf/elf.go ident, e_machine and e_entry decoding
    write_fixture("elf_dynamic")

    result = run(['-c', '-d', 'elf', '.header | tovalue', 'elf_dynamic'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"ehsize":64,"entry":4208,"flags":0,"ident":{"abi_version":0,"class":64,"data":"little_endian","'
        'magic":"\\u007fELF","os_abi":"sysv","pad":"\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000","version":'
        '1},"machine":"x86_64","phentsize":56,"phnum":12,"phoff":64,"shentsize":64,"shnum":34,"shoff":160'
        '16,"shstrndx":33,"type":"dyn","version":1}\n'
    )


def test_elf_program_headers(run, write_fixture):
    """The twelve program headers resolve to their symbolic types from phdr
    through gnu_relro, and the first load segment carries its offset,
    address and size geometry.
    """
    # CATCHES: elf/elf.go program header types and load segment geometry
    write_fixture("elf_dynamic")

    result = run(['-c', '-d', 'elf', '[.program_headers[] | .type]', 'elf_dynamic'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '["phdr","interp","load","load","load","load","dynamic","note","os","gnu_eh_frame","gnu_stack","g'
        'nu_relro"]\n'
    )

    result = run([
        '-c',
        '-d',
        'elf',
        '.program_headers[2] | tovalue | {type, offset, vaddr, paddr, filesz, memsz, align}',
        'elf_dynamic',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"align":4096,"filesz":1544,"memsz":1544,"offset":0,"paddr":0,"type":"load","vaddr":0}\n'


def test_elf_section_names(run, write_fixture):
    """Every section header resolves its name, from the empty null section
    through .interp, .text and .dynamic to the string tables.
    """
    # CATCHES: elf/elf.go section name resolution via shstrtab
    write_fixture("elf_dynamic")

    result = run(['-c', '-d', 'elf', '[.section_headers[] | .name]', 'elf_dynamic'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '["",".interp",".note.gnu.property",".gnu.hash",".dynsym",".dynstr",".rela.dyn",".rela.plt",".ini'
        't",".plt",".plt.got",".text",".fini",".rodata",".eh_frame_hdr",".eh_frame",".ctors",".dtors",".d'
        'ynamic",".got",".data",".bss",".comment",".debug_aranges",".debug_info",".debug_abbrev",".debug_'
        'line",".debug_frame",".debug_str",".debug_loc",".debug_ranges",".symtab",".strtab",".shstrtab"]\n'
    )


def test_elf_dynamic_tags(run, write_fixture):
    """The .dynamic section decodes its tag stream -- two NEEDED entries,
    INIT, FINI and more -- with the needed values resolved to library
    names.
    """
    # CATCHES: elf/elf.go dynamic tag decode and string resolution
    write_fixture("elf_dynamic")

    result = run([
        '-c',
        '-d',
        'elf',
        '[.section_headers[] | select(.name==".dynamic") | .dynamic_tags[0:4][] | .tag]',
        'elf_dynamic',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["needed","needed","init","fini"]\n'

    result = run([
        '-c',
        '-d',
        'elf',
        '[.section_headers[] | select(.name==".dynamic") | .dynamic_tags[0:8][] | .val | tovalue]',
        'elf_dynamic',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["libbbb.so","libc.musl-x86_64.so.1",null,null,null,null,null,194]\n'


def test_elf_dynamic_symbols(run, write_fixture):
    """The .dynsym symbol table decodes names, bindings and types; the first
    entries are the null symbol and the global function puts.
    """
    # CATCHES: elf/elf.go symbol table entries with bind/type enums
    write_fixture("elf_dynamic")

    result = run([
        '-c',
        '-d',
        'elf',
        '[.section_headers[] | select(.name==".dynsym") | .symbol_table[0:3][] | .name]',
        'elf_dynamic',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["","puts","__deregister_frame_info"]\n'

    result = run([
        '-c',
        '-d',
        'elf',
        '[.section_headers[] | select(.name==".dynsym") | .symbol_table[0:2][] | {name, bind, type, visibility}]',
        'elf_dynamic',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"bind":"local","name":"","type":"notype","visibility":"default"},{"bind":"global","name":"puts'
        '","type":"func","visibility":"default"}]\n'
    )


def test_ar_archive_members(run, write_fixture):
    """An ar archive decodes its members' identifiers, timestamps, ownership,
    modes and sizes; the first member is the symbol table "/".
    """
    # CATCHES: format/ar archive member header fields
    write_fixture("elf_ar")

    result = run(['-c', '-d', 'ar', '[.files[] | .identifier]', 'elf_ar'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["/","libbbb.o/"]\n'

    result = run(['-c', '-d', 'ar', '.files[0] | tovalue', 'elf_ar'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"data":"\\u0000\\u0000\\u0000\\u0001\\u0000\\u0000\\u0000Xlibbbb_bbb\\u0000\\u0000","ending_characters":'
        '"`\\n","file_mode":0,"file_size":20,"group_id":0,"identifier":"/","modification_timestamp":0,"own'
        'er_id":0}\n'
    )


def test_ar_nested_elf(run, write_fixture):
    """The second member's data decodes as a nested ELF image with its own
    header, program headers and fourteen section headers.
    """
    # CATCHES: ar to elf nested format decode hand-off
    write_fixture("elf_ar")

    result = run(['-c', '-d', 'ar', '.files[1].data | keys', 'elf_ar'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["header","section_headers","gap0","gap1","program_headers"]\n'

    result = run(['-c', '-d', 'ar', '.files[1].data.header | tovalue', 'elf_ar'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"ehsize":64,"entry":0,"flags":0,"ident":{"abi_version":0,"class":64,"data":"little_endian","mag'
        'ic":"\\u007fELF","os_abi":"sysv","pad":"\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000","version":1},'
        '"machine":"x86_64","phentsize":0,"phnum":0,"phoff":0,"shentsize":64,"shnum":14,"shoff":616,"shst'
        'rndx":13,"type":"rel","version":1}\n'
    )

    result = run(['-c', '-d', 'ar', '.files[1].data.section_headers | length', 'elf_ar'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '14\n'


def test_wasm_section_ids(run, write_fixture):
    """A wasm module's sections resolve to their symbolic ids; these vectors
    have type, function, export and code sections.
    """
    # CATCHES: wasm/wasm.go section id symbol table
    write_fixture("wasm_i32")
    write_fixture("wasm_fac")

    result = run(['-c', '-d', 'wasm', '[.sections[] | .id]', 'wasm_i32'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["type_section","function_section","export_section","code_section"]\n'

    result = run(['-c', '-d', 'wasm', '[.sections[] | .id]', 'wasm_fac'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["type_section","function_section","export_section","code_section"]\n'


def test_wasm_code_section_structure(run, write_fixture):
    """The code section decodes as a count plus function bodies, each a
    size-prefixed code block of locals and an expression.
    """
    # CATCHES: wasm/wasm.go decodeVec and decodeCode sizing structure
    write_fixture("wasm_i32")

    result = run([
        '-c',
        '-d',
        'wasm',
        '.sections[] | select(.id=="code_section") | .content.code | keys',
        'wasm_i32',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["n","x"]\n'

    result = run([
        '-c',
        '-d',
        'wasm',
        '.sections[] | select(.id=="code_section") | .content.code.x[0] | keys',
        'wasm_i32',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["size","code"]\n'

    result = run([
        '-c',
        '-d',
        'wasm',
        '.sections[] | select(.id=="code_section") | .content.code.x[0].code | keys',
        'wasm_i32',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["t","e"]\n'


def test_wasm_i32_add_instructions(run, write_fixture):
    """The first function body of the i32 vector executes local.get,
    local.get, i32.add and end.
    """
    # CATCHES: wasm/instructions.go opcode symbol decoding
    write_fixture("wasm_i32")

    result = run([
        '-c',
        '-d',
        'wasm',
        '[.sections[] | select(.id=="code_section") | .content.code.x[0].code.e[].opcode]',
        'wasm_i32',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["local.get","local.get","i32.add","end"]\n'


def test_wasm_factorial_opcodes(run, write_fixture):
    """The factorial module's function decodes its control and arithmetic
    opcode sequence.
    """
    # CATCHES: wasm/instructions.go loop and arithmetic opcode coverage
    write_fixture("wasm_fac")

    result = run([
        '-c',
        '-d',
        'wasm',
        '[.sections[] | select(.id=="code_section") | .content.code.x[0].code.e[].opcode]',
        'wasm_fac',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["local.get","i64.const","i64.eq","if","end"]\n'


def test_wasm_integer_opcodes(run, write_fixture):
    """The 64-bit integer vector decodes its own recorded opcode sequence."""
    # CATCHES: wasm/instructions.go i64 opcode coverage
    write_fixture("wasm_i64")

    result = run([
        '-c',
        '-d',
        'wasm',
        '[.sections[] | select(.id=="code_section") | .content.code.x[0].code.e[].opcode]',
        'wasm_i64',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["local.get","local.get","i64.add","end"]\n'


def test_wasm_float_opcodes(run, write_fixture):
    """The f32 and f64 vectors decode their floating point opcode sequences."""
    # CATCHES: wasm/instructions.go float opcode coverage
    write_fixture("wasm_f32")
    write_fixture("wasm_f64")

    result = run([
        '-c',
        '-d',
        'wasm',
        '[.sections[] | select(.id=="code_section") | .content.code.x[0].code.e[].opcode]',
        'wasm_f32',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["local.get","local.get","f32.add","end"]\n'

    result = run([
        '-c',
        '-d',
        'wasm',
        '[.sections[] | select(.id=="code_section") | .content.code.x[0].code.e[].opcode]',
        'wasm_f64',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["local.get","local.get","f64.add","end"]\n'


def test_wasm_stack_and_labels(run, write_fixture):
    """The stack-polymorphism and label vectors decode their opcode sequences."""
    # CATCHES: wasm/instructions.go stack and label opcode coverage
    write_fixture("wasm_stack")
    write_fixture("wasm_labels")

    result = run([
        '-c',
        '-d',
        'wasm',
        '[.sections[] | select(.id=="code_section") | .content.code.x[0].code.e[].opcode]',
        'wasm_stack',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["local.get","local.set","i64.const","local.set","block","local.get","end"]\n'

    result = run([
        '-c',
        '-d',
        'wasm',
        '[.sections[] | select(.id=="code_section") | .content.code.x[0].code.e[].opcode]',
        'wasm_labels',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["block","end"]\n'
