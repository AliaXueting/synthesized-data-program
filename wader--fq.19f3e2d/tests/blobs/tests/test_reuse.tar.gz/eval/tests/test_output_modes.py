"""Output mode flags (-r, -j, -c, -V, --raw-output0) and binary output,
ported from the native pkg/interp/testdata/output.fqtest,
value_output.fqtest and binary_stdout.fqtest scripts."""


def test_raw_string_output(run):
    """-r prints string results without quotes."""
    result = run(["-rn", '"a b c"'])
    # CATCHES: the raw string flag strips the JSON quotes but still adds
    # the usual trailing newline for each output.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "a b c\n"


def test_multiple_outputs_each_on_a_line(run):
    """A stream of values prints one value per line."""
    result = run(["-n", "1,2,3"])
    # CATCHES: without -j every value in the output stream is terminated by
    # its own newline.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "1\n2\n3\n"


def test_join_output(run):
    """-j drops the newline after each output."""
    result = run(["-nj", "1,2,3"])
    # CATCHES: join output concatenates all outputs with nothing between
    # them and no trailing newline at all.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"123"


def test_join_output_strings(run):
    """-j concatenates string outputs without separators."""
    result = run(["-nj", '"a","b","c"'])
    # CATCHES: join output also applies to strings, producing the bare
    # sequence 'abc' with no quotes and no newline.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"abc"


def test_raw_output0(run):
    """--raw-output0 terminates each output with a NUL byte."""
    result = run(["-n", "--raw-output0", "1,2,3"])
    # CATCHES: every output value is followed by a zero byte instead of a
    # newline, which also means there is no final newline.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"1\x002\x003\x00"


def test_raw_output0_with_strings(run):
    """--raw-output0 works for string outputs too."""
    result = run(["-n", "--raw-output0", '"a","b","c"'])
    # CATCHES: the NUL separator is applied per output value, giving
    # 'a\0b\0c\0' for three strings.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"a\x00b\x00c\x00"


def test_raw_output0_loses_to_join(run):
    """-j suppresses the NUL separator of --raw-output0."""
    result = run(["-nj", "--raw-output0", "1,2,3"])
    # CATCHES: join output wins over the NUL separator, so the outputs are
    # glued together with no delimiter of either kind.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"123"


def test_compact_output(run):
    """-c prints values on one line."""
    result = run(["-nc", "[1,2,3]"])
    # CATCHES: compact output keeps the JSON structure but removes all
    # whitespace between the elements.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "[1,2,3]\n"


def test_compact_output_long_flag(run):
    """--compact-output is the long spelling of -c."""
    result = run(["-n", "--compact-output", "[1,2,3]"])
    # CATCHES: the long flag shares the exact code path with -c, including
    # the trailing newline that -j would have removed.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "[1,2,3]\n"


def test_value_output(run, mp3):
    """-V outputs plain JSON values instead of the value display."""
    result = run(["-V", ".headers[0].header[]", "test.mp3"])
    # CATCHES: value output converts every decoded field to its JSON value
    # (symbol strings like "ID3", numbers, nested objects) and prints each
    # with the default pretty formatting.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '"ID3"\n4\n0\n{\n  "experimental_indicator": false,\n'
        '  "extended_header": false,\n  "unsynchronisation": false,\n'
        '  "unused": 0\n}\n35\n')


def test_value_output_raw(run, mp3):
    """-Vr combines value output with raw strings."""
    result = run(["-Vr", ".headers[0].header[]", "test.mp3"])
    # CATCHES: only the string results lose their quotes under -Vr; the
    # object result keeps its pretty JSON form.
    assert (result.returncode, result.err) == (0, "")
    assert result.out.startswith("ID3\n4\n0\n{\n")
    assert result.out.endswith('  "unused": 0\n}\n35\n')


def test_value_output_bits_base64(run, mp3):
    """bits_format=base64 renders binary fields as base64 strings."""
    result = run(["-o", "bits_format=base64", "-V",
                  ".frames[0].audio_data", "test.mp3"])
    # CATCHES: under value output a raw bits field becomes a string whose
    # encoding is controlled by the bits_format option.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"AAAAAAA="\n'


def test_binary_value_written_raw_to_pipe(run):
    """A binary value on a piped stdout is written as raw bytes."""
    result = run(["-n", '"test" | tobytes'])
    # CATCHES: because stdout is not a terminal the raw bits value is
    # emitted as the literal bytes 'test' with no quotes, hexdump or
    # trailing newline.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"test"


def test_explicit_display_forces_hexdump(run):
    """The d builtin always renders, even on a piped stdout."""
    result = run(["-n", "[1,2,3] | tobytes | d"])
    # CATCHES: calling display explicitly disables the raw binary output
    # path, so the same value that printed raw bytes before now renders as
    # a monochrome hexdump with the address column.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        "   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|"
        "0123456789abcdef|\n"
        "0x0|01 02 03|                                      |...|"
        "            |.: raw bits 0x0-0x3 (3)\n")


def test_color_output_flag(run):
    """-C forces ANSI colour even with NO_COLOR set."""
    result = run(["-Cn", "123"])
    # CATCHES: the colour flag overrides the NO_COLOR environment variable
    # and wraps numbers in the cyan escape sequence.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"\x1b[36m123\x1b[m\n"


def test_color_output_long_flag(run):
    """--color-output is the long spelling of -C."""
    result = run(["--color-output", "-n", "123"])
    # CATCHES: the long flag produces the identical cyan escape sequence
    # around the number as the short one.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"\x1b[36m123\x1b[m\n"


def test_monochrome_output_flags(run):
    """-M and --monochrome-output keep output plain."""
    for args in (["-Mn", "123"], ["--monochrome-output", "-n", "123"]):
        result = run(args)
        # CATCHES: forcing monochrome leaves the plain digits with no ANSI
        # escapes, matching the NO_COLOR default of this environment.
        assert (result.returncode, result.err, result.out) == (0, "", "123\n")


def test_no_color_env_default(run):
    """NO_COLOR in the environment keeps output monochrome by default."""
    result = run(["-n", "123"])
    # CATCHES: with NO_COLOR set (as the pinned environment does) plain
    # values print without any escape sequences.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"123\n"
