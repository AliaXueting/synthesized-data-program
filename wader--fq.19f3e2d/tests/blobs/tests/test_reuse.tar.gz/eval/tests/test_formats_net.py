"""DNS response, IPv4 fragment and pcap/IPv6 capture decoding
using the reference repository's dns, inet and pcap test data.
"""


def test_dns_response_header(run, write_fixture):
    """The DNS response header decodes its id, opcode, flags and
    response code as symbolic names.
    """
    # CATCHES: dns/dns.go header flag decoding and enum naming
    write_fixture("dns_rsp", "cern-rsp")

    result = run(['-c', '-d', 'dns', '.header | tovalue', 'cern-rsp'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"authoritative_answer":false,"id":28930,"opcode":"query","qr":"response","rcode":"no_error","recursion_available":true,"recursion_desired":true,"truncation":false,"z":0}\n'


def test_dns_question(run, write_fixture):
    """The question section decodes the qname labels, class and record
    type (aaaa) with the assembled name value.
    """
    # CATCHES: dns/dns.go question decoding and qname label walking
    write_fixture("dns_rsp", "cern-rsp")

    result = run(['-c', '-d', 'dns', '.questions[0] | tovalue', 'cern-rsp'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"class":"in","name":{"labels":[{"length":3,"value":"www"},{"length":4,"value":"cern"},{"length":2,"value":"ch"},{"length":0}],"value":"www.cern.ch"},"type":"aaaa"}\n'


def test_dns_qname_labels(run, write_fixture):
    """Iterating the question name labels yields www, cern, ch and the
    empty root label as a trailing null.
    """
    # CATCHES: dns/dns.go name label array with terminating empty label
    write_fixture("dns_rsp", "cern-rsp")

    result = run([
        '-c',
        '-d',
        'dns',
        '[.questions[0].name.labels[] | .value]',
        'cern-rsp',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["www","cern","ch",null]\n'


def test_dns_answer_types(run, write_fixture):
    """The two answers of the response are a cname and an aaaa record."""
    # CATCHES: dns/dns.go answer record type dispatch
    write_fixture("dns_rsp", "cern-rsp")

    result = run(['-c', '-d', 'dns', '[.answers[].type]', 'cern-rsp'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["cname","aaaa"]\n'


def test_dns_cname_answer_with_compression(run, write_fixture):
    """The cname answer decodes with message-compressed name pointers
    in both the owner and the rdata names.
    """
    # CATCHES: dns/dns.go name compression pointer following in answers
    write_fixture("dns_rsp", "cern-rsp")

    result = run([
        '-c',
        '-d',
        'dns',
        '.answers[0] | tovalue | {name, type, class, ttl, rdlength, cname}',
        'cern-rsp',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"class":"in","cname":{"labels":[{"length":8,"value":"webrlb02"},{"is_pointer":3,"length":4,"pointer":16,"value":"cern"},{"length":2,"value":"ch"},{"length":0}],"value":"webrlb02.cern.ch"},"name":{"labels":[{"is_pointer":3,"length":3,"pointer":12,"value":"www"},{"length":4,"value":"cern"},{"length":2,"value":"ch"},{"length":0}],"value":"www.cern.ch"},"rdlength":11,"ttl":4502,"type":"cname"}\n'


def test_dns_aaaa_answer(run, write_fixture):
    """The aaaa answer decodes its owner name and the IPv6 address."""
    # CATCHES: dns/dns.go AAAA rdata address decoding
    write_fixture("dns_rsp", "cern-rsp")

    result = run([
        '-c',
        '-d',
        'dns',
        '.answers[1] | tovalue | {name, type, ttl, address}',
        'cern-rsp',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"address":"2001:1458:201:70::100:27","name":{"labels":[{"is_pointer":3,"length":8,"pointer":41,"value":"webrlb02"},{"is_pointer":3,"length":4,"pointer":16,"value":"cern"},{"length":2,"value":"ch"},{"length":0}],"value":"webrlb02.cern.ch"},"ttl":4502,"type":"aaaa"}\n'


def test_dns_section_counts(run, write_fixture):
    """The section counts are one question, two answers and no
    authority or additional records.
    """
    # CATCHES: dns/dns.go section array population
    write_fixture("dns_rsp", "cern-rsp")

    result = run([
        '-c',
        '-d',
        'dns',
        '{qd: (.questions|length), an: (.answers|length), ns: (.authority|length), ar: (.additional|length)}',
        'cern-rsp',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"an":2,"ar":0,"ns":0,"qd":1}\n'


def test_ipv4_header_fields(run, write_fixture):
    """The IPv4 header decodes all fields: IHL, DSCP/ECN, fragment
    flags and offsets, TTL, protocol and both addresses.
    """
    # CATCHES: inet/ipv4_packet.go header field, flag and address decoding
    write_fixture("ipv4_pkt", "ipv4_packet")

    result = run([
        '-c',
        '-d',
        'ipv4_packet',
        'tovalue | {version, ihl, dscp, ecn, total_length, identification, reserved, dont_fragment, more_fragments, fragment_offset, ttl, protocol, header_checksum, source_ip, destination_ip}',
        'ipv4_packet',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"destination_ip":"2.1.1.1","dont_fragment":false,"dscp":0,"ecn":0,"fragment_offset":0,"header_checksum":39748,"identification":46544,"ihl":5,"more_fragments":true,"protocol":"icmp","reserved":0,"source_ip":"2.1.1.2","total_length":996,"ttl":64,"version":4}\n'


def test_ipv4_payload_remainder(run, write_fixture):
    """The bytes after the 20 byte header surface as a raw payload
    value: 976 of the 996 total length bytes.
    """
    # CATCHES: inet/ipv4_packet.go payload sizing against total_length
    write_fixture("ipv4_pkt", "ipv4_packet")

    result = run([
        '-c',
        '-d',
        'ipv4_packet',
        '.payload | tostring | length',
        'ipv4_packet',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '976\n'


def test_pcap_file_header(run, write_fixture):
    """The pcap file header decodes magic endianness, version, snaplen
    and the link layer type.
    """
    # CATCHES: pcap file header decoding and endian magic handling
    write_fixture("pcap_ipv6", "ipv6_http.pcap")

    result = run(['-c', '-d', 'pcap', '.header | tovalue', 'ipv6_http.pcap'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"magic":"little_endian","network":"ethernet","sigfigs":0,"snaplen":65535,"thiszone":0,"version_major":2,"version_minor":4}\n'


def test_pcap_capture_summary(run, write_fixture):
    """The capture holds 55 packets, all ethernet/IPv6, reassembled
    into a single TCP connection.
    """
    # CATCHES: pcap packet array, ether_type dispatch and TCP reassembly table
    write_fixture("pcap_ipv6", "ipv6_http.pcap")

    result = run([
        '-c',
        '-d',
        'pcap',
        '{packets: (.packets|length), ether_types: ([.packets[].packet.ether_type] | unique), tcp_connections: (.tcp_connections|length)}',
        'ipv6_http.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"ether_types":["ipv6"],"packets":55,"tcp_connections":1}\n'


def test_ipv6_header_fields(run, write_fixture):
    """The first IPv6 packet decodes its traffic class, flow label,
    hop limit and link-local addresses.
    """
    # CATCHES: inet/ipv6_packet.go base header field and address decoding
    write_fixture("pcap_ipv6", "ipv6_http.pcap")

    result = run([
        '-c',
        '-d',
        'pcap',
        '.packets[1].packet.payload | tovalue | {version, ds, ecn, flow_label, payload_length, next_header, hop_limit, source_address, destination_address}',
        'ipv6_http.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"destination_address":"ff02::1:ff82:95b5","ds":0,"ecn":0,"flow_label":0,"hop_limit":255,"next_header":"ipv6-icmp","payload_length":32,"source_address":"fe80::211:25ff:fe82:95b5","version":6}\n'


def test_ipv6_neighbor_solicitation(run, write_fixture):
    """The ICMPv6 payload of the first packet is a neighbor
    solicitation (type 135) with its checksum.
    """
    # CATCHES: inet/ipv6_packet.go next_header dispatch into the icmpv6 payload
    write_fixture("pcap_ipv6", "ipv6_http.pcap")

    result = run([
        '-c',
        '-d',
        'pcap',
        '.packets[1].packet.payload.payload | tovalue | {type, code, checksum}',
        'ipv6_http.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"checksum":31206,"code":0,"type":135}\n'


def test_ipv6_next_header_values(run, write_fixture):
    """The distinct next header values across the capture are the
    hop-by-hop option, icmpv6, tcp and udp.
    """
    # CATCHES: inet/ipv6_packet.go next_header enum mapping across packets
    write_fixture("pcap_ipv6", "ipv6_http.pcap")

    result = run([
        '-c',
        '-d',
        'pcap',
        '[.packets[].packet.payload.next_header] | unique',
        'ipv6_http.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["hop_by_hop","ipv6-icmp","tcp","udp"]\n'


def test_pcap_tcp_connection_endpoints(run, write_fixture):
    """The reassembled TCP connection pairs the client's link-local
    address and port 59201 with the server on the http port.
    """
    # CATCHES: pcap TCP reassembly endpoint bookkeeping (client/server roles)
    write_fixture("pcap_ipv6", "ipv6_http.pcap")

    result = run([
        '-c',
        '-d',
        'pcap',
        '.tcp_connections[0] | {client_ip: .client.ip, client_port: .client.port, server_ip: .server.ip, server_port: .server.port}',
        'ipv6_http.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"client_ip":"2001:6f8:102d:0:2d0:9ff:fee3:e8de","client_port":59201,"server_ip":"2001:6f8:900:7c0::2","server_port":"http"}\n'


def test_pcap_tcp_reassembled_stream(run, write_fixture):
    """The client side of the reassembled TCP stream contains the HTTP
    request line and Host header of the capture.
    """
    # CATCHES: pcap TCP stream reassembly into ordered application data
    write_fixture("pcap_ipv6", "ipv6_http.pcap")

    result = run([
        '-c',
        '-d',
        'pcap',
        '.tcp_connections[0].client.stream | tostring | .[0:40]',
        'ipv6_http.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"GET / HTTP/1.0\\r\\nHost: cl-1985.ham-01.de."\n'

