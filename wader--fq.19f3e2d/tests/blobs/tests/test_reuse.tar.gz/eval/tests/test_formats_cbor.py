"""Behavioural tests for the CBOR decoder.

Vectors are the RFC 7049 appendix A cases from the reference
repository's test data (src/format/cbor/testdata); every expectation
was recorded by running the reference binary.
"""


def test_cbor_integer_major_types(run, write_fixture):
    """The RFC 7049 appendix A integer vectors cover both number major types:
    zero as an immediate value, one million through the 32-bit extended
    count, and minus one as the first negative integer.
    """
    # CATCHES: cbor/cbor.go major type 0/1 dispatch and 32-bit extended counts
    write_fixture("cbor_00")
    write_fixture("cbor_01")
    write_fixture("cbor_02")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_00'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"positive_int","short_count":0,"value":0}\n'

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_01'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"positive_int","short_count":"32bit","value":1000000,"variable_count":1000000}\n'

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_02'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"negative_int","short_count":0,"value":-1}\n'


def test_cbor_simple_values(run, write_fixture):
    """The simple values false, true and null are major type 7 items with the
    immediate values 20, 21 and 22.
    """
    # CATCHES: cbor/cbor.go major type 7 simple-value mapping
    write_fixture("cbor_03")
    write_fixture("cbor_04")
    write_fixture("cbor_05")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_03'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"special_float","short_count":20,"value":false}\n'

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_04'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"special_float","short_count":21,"value":true}\n'

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_05'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"special_float","short_count":22,"value":null}\n'


def test_cbor_float_widths(run, write_fixture):
    """Half-precision and double-precision float vectors decode to plain JSON
    numbers.
    
    The 1.7976931348623157e+308 entry is the half-float 0x7c00 pattern,
    which the decoder widens to the largest finite double.
    """
    # CATCHES: cbor/cbor.go 16-bit and 64-bit float decoding
    write_fixture("cbor_06")
    write_fixture("cbor_07")
    write_fixture("cbor_08")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_06'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"special_float","short_count":"16bit","value":1.5}\n'

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_07'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"special_float","short_count":"16bit","value":1.7976931348623157e+308}\n'

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_08'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"major_type":"special_float","short_count":"64bit","value":1.1}\n'


def test_cbor_byte_and_text_strings(run, write_fixture):
    """A three-byte byte string and the four-character text string decode with
    their payload in value and the raw descriptor bytes left in gap0; the
    non-UTF-8 bytes are escaped in the JSON output.
    """
    # CATCHES: cbor/cbor.go byte/text string decoding with invalid-UTF-8 escaping
    write_fixture("cbor_09")
    write_fixture("cbor_10")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_09'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"gap0":"\\ufffd","major_type":"bytes","short_count":3,"value":"\\ufffd\\ufffd\\ufffd"}\n'

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_10'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"gap0":"\\u0006OB","major_type":"utf8","short_count":4,"value":"IETB"}\n'


def test_cbor_definite_array_and_map(run, write_fixture):
    """A definite-length array keeps one decoded value object per element, and
    a map keeps key/value pairs with each side a full CBOR value.
    """
    # CATCHES: cbor/cbor.go definite array elements and map pairs
    write_fixture("cbor_11")
    write_fixture("cbor_12")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_11'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"elements":[{"major_type":"positive_int","short_count":1,"value":1},{"major_type":"positive_int'
        '","short_count":2,"value":2},{"major_type":"positive_int","short_count":3,"value":3}],"major_typ'
        'e":"array","short_count":3}\n'
    )

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_12'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"gap0":"\\u0003","major_type":"map","pairs":[{"key":{"major_type":"utf8","short_count":1,"value"'
        ':"a"},"value":{"major_type":"positive_int","short_count":1,"value":1}},{"key":{"major_type":"utf'
        '8","short_count":1,"value":"b"},"value":{"elements":[{"major_type":"positive_int","short_count":'
        '2,"value":2}],"major_type":"array","short_count":1}}],"short_count":2}\n'
    )


def test_cbor_indefinite_strings(run, write_fixture):
    """Indefinite-length strings decode as a list of chunks; the overall value
    is their concatenation, so "strea" plus "ming" reads "streaming".
    """
    # CATCHES: cbor/cbor.go indefinite string chunking and break marker
    write_fixture("cbor_13")
    write_fixture("cbor_14")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_13'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"gap0":"\\ufffd","items":[{"major_type":"bytes","short_count":2,"value":"\\u0001\\u0002"},{"major_'
        'type":"bytes","short_count":3,"value":"\\u0003\\u0004\\u0005"}],"major_type":"bytes","short_count":'
        '"indefinite","value":"\\u0001\\u0002\\u0003\\u0004\\u0005"}\n'
    )

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_14'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"gap0":"\\ufffd","items":[{"major_type":"utf8","short_count":5,"value":"strea"},{"major_type":"u'
        'tf8","short_count":4,"value":"ming"}],"major_type":"utf8","short_count":"indefinite","value":"st'
        'reaming"}\n'
    )


def test_cbor_indefinite_array_and_map(run, write_fixture):
    """An indefinite-length array with no items decodes to an empty element
    list plus the 0xff break marker, and the indefinite map carries its
    key/value pairs.
    """
    # CATCHES: cbor/cbor.go indefinite array/map termination on the break byte
    write_fixture("cbor_15")
    write_fixture("cbor_16")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_15'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"break":255,"elements":[],"major_type":"array","short_count":"indefinite"}\n'

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_16'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"break":255,"major_type":"map","pairs":[{"key":{"major_type":"utf8","short_count":1,"value":"a"'
        '},"value":{"major_type":"positive_int","short_count":1,"value":1}},{"key":{"major_type":"utf8","'
        'short_count":1,"value":"b"},"value":{"break":255,"elements":[{"major_type":"positive_int","short'
        '_count":2,"value":2},{"major_type":"positive_int","short_count":3,"value":3}],"major_type":"arra'
        'y","short_count":"indefinite"}}],"short_count":"indefinite"}\n'
    )


def test_cbor_semantic_tags(run, write_fixture):
    """Semantic tags resolve to their RFC 7049 names -- standard date/time,
    unsigned and negative bignum, and encoded CBOR -- keeping the tagged
    item nested under value.
    """
    # CATCHES: cbor/cbor.go semantic tag naming and tagged-value nesting
    write_fixture("cbor_17")
    write_fixture("cbor_18")
    write_fixture("cbor_19")
    write_fixture("cbor_20")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_17'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"major_type":"semantic","short_count":0,"tag":"date_time","value":{"major_type":"utf8","short_c'
        'ount":20,"value":"2013-03-21T20:04:00Z"}}\n'
    )

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_18'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"major_type":"semantic","short_count":2,"tag":"unsigned_bignum","value":{"major_type":"bytes","'
        'short_count":9,"value":"\\u0001\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000"}}\n'
    )

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_19'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"major_type":"semantic","short_count":3,"tag":"negative_bignum","value":{"major_type":"bytes","'
        'short_count":9,"value":"\\u0001\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000"}}\n'
    )

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_20'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"major_type":"semantic","short_count":"8bit","tag":"encoded_cbor","value":{"major_type":"bytes"'
        ',"short_count":5,"value":"dIETF"},"variable_count":24}\n'
    )

    result = run(['-c', '-d', 'cbor', 'torepr', 'cbor_18'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"major_type":"bytes","short_count":9,"value":"\\u0001\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\'
        'u0000"}\n'
    )


def test_cbor_native_vector_roundtrip(run, write_fixture):
    """The repository's own mixed map vector decodes through tovalue, and
    torepr collapses the same value back to plain JSON.
    """
    # CATCHES: cbor/cbor.go mixed-type indefinite map decode and torepr projection
    write_fixture("cbor_native")

    result = run(['-c', '-d', 'cbor', 'tovalue', 'cbor_native'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"break":255,"major_type":"map","pairs":[{"key":{"major_type":"utf8","short_count":3,"value":"Fu'
        'n"},"value":{"major_type":"special_float","short_count":21,"value":true}},{"key":{"major_type":"'
        'utf8","short_count":3,"value":"Amt"},"value":{"major_type":"negative_int","short_count":1,"value'
        '":-2}}],"short_count":"indefinite"}\n'
    )

    result = run(['-c', '-d', 'cbor', 'torepr', 'cbor_native'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"Amt":-2,"Fun":true}\n'
