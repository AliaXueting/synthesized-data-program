"""ASN.1 BER decoding of a DER RSA private key and a PEM-wrapped
X.509 ed25519 certificate (unwrapped with from_pem).

Vectors: src/format/asn1/testdata/{openssl.rsa.key.der,
ed25519.cer}.
"""


def test_asn1_rsa_root_sequence(run, write_fixture):
    """The DER RSA private key decodes as one universal constructed
    sequence of 605 bytes.
    """
    # CATCHES: asn1/asn1_ber.go root tag/length/form decoding
    write_fixture("rsa_key_der", "openssl.rsa.key.der")

    result = run([
        '-c',
        '-d',
        'asn1_ber',
        'tovalue | {class, form, tag, length}',
        'openssl.rsa.key.der',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"class":"universal","form":"constructed","length":605,"tag":"sequence"}\n'


def test_asn1_rsa_integer_children(run, write_fixture):
    """The nine children of the root sequence are all integers:
    version, modulus, exponents and primes.
    """
    # CATCHES: asn1/asn1_ber.go constructed child element walking
    write_fixture("rsa_key_der", "openssl.rsa.key.der")

    result = run([
        '-c',
        '-d',
        'asn1_ber',
        '[.constructed[] | .tag]',
        'openssl.rsa.key.der',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["integer","integer","integer","integer","integer","integer","integer","integer","integer"]\n'


def test_asn1_rsa_modulus_length(run, write_fixture):
    """The second integer, the 2048 bit modulus, has a declared length
    of 129 bytes (leading sign byte included).
    """
    # CATCHES: asn1/asn1_ber.go primitive integer length decoding
    write_fixture("rsa_key_der", "openssl.rsa.key.der")

    result = run([
        '-c',
        '-d',
        'asn1_ber',
        '.constructed[1] | tovalue | {tag, length}',
        'openssl.rsa.key.der',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"length":129,"tag":"integer"}\n'


def test_asn1_rsa_version_zero(run, write_fixture):
    """The first integer is the version, zero for a two-prime key."""
    # CATCHES: asn1/asn1_ber.go integer value decoding
    write_fixture("rsa_key_der", "openssl.rsa.key.der")

    result = run([
        '-c',
        '-d',
        'asn1_ber',
        '.constructed[0] | tovalue | {tag, length, value}',
        'openssl.rsa.key.der',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"length":1,"tag":"integer","value":0}\n'


def test_asn1_pem_certificate_root(run, write_fixture):
    """A PEM-wrapped certificate unwraps via from_pem and decodes as a
    383 byte universal constructed sequence.
    """
    # CATCHES: asn1/asn1_ber.go decoding behind from_pem unwrapping
    write_fixture("ed25519_cer", "ed25519.cer")

    result = run([
        '-c',
        '-d',
        'bytes',
        'from_pem | asn1_ber | tovalue | {class, form, tag, length}',
        'ed25519.cer',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"class":"universal","form":"constructed","length":383,"tag":"sequence"}\n'


def test_asn1_pem_version_context_tag(run, write_fixture):
    """The [0] context tag inside the tbsCertificate holds the
    certificate version integer, 2 for v3.
    """
    # CATCHES: asn1/asn1_ber.go constructed context-tag child navigation
    write_fixture("ed25519_cer", "ed25519.cer")

    result = run([
        '-c',
        '-d',
        'bytes',
        'from_pem | asn1_ber | .constructed[0].constructed[0].constructed[0] | tovalue | {tag, value}',
        'ed25519.cer',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"tag":"integer","value":2}\n'


def test_asn1_pem_tbs_children(run, write_fixture):
    """The tbsCertificate children decode as the [0] version, serial
    integer, signature algorithm, issuer, validity, subject,
    subjectPublicKeyInfo and [3] extensions.
    """
    # CATCHES: asn1/asn1_ber.go mixed tag/constructed child typing in the tbs
    write_fixture("ed25519_cer", "ed25519.cer")

    result = run([
        '-c',
        '-d',
        'bytes',
        'from_pem | asn1_ber | [.constructed[0].constructed[] | .tag]',
        'ed25519.cer',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[0,"integer","sequence","sequence","sequence","sequence","sequence",3]\n'


def test_asn1_pem_serial_number(run, write_fixture):
    """The serial number is a 20 byte integer; asking for the signature
    algorithm field of a non-sequence child yields null.
    """
    # CATCHES: asn1/asn1_ber.go field access on decoded elements (absent -> null)
    write_fixture("ed25519_cer", "ed25519.cer")

    result = run([
        '-c',
        '-d',
        'bytes',
        'from_pem | asn1_ber | .constructed[0].constructed[1] | tovalue | {tag, length, algorithm}',
        'ed25519.cer',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"algorithm":null,"length":20,"tag":"integer"}\n'

