"""Regex matching over binary values (pkg/interp/match.go):
byte-runes mode, byte-array patterns, flags and captures, plus
matching inside decoded format values.

The -n cases exercise matching on built values; the audio case
matches inside a decoded mp3 frame.
"""

import pytest


@pytest.mark.parametrize(
    "program, expected",
    [
        ('"64ff65ff66" | fromhex | match("\\u00ff"; "b") | {offset, length, string}', '{"length":1,"offset":1,"string":"\\ufffd"}\n',),
        ('"aöaöa" | tobytes | match("ö") | {offset, length, string}', '{"length":2,"offset":1,"string":"ö"}\n',),
        ('"aöaöa" | tobytes | match([0xc3]) | {offset, length, string}', '{"length":1,"offset":1,"string":"\\ufffd"}\n',),
        ('"abba" | tobytes | match("B"; "gi") | {offset, length, string}', '{"length":1,"offset":1,"string":"b"}\n{"length":1,"offset":2,"string":"b"}\n',),
    ],
    ids=["byte_flag", "rune_mode", "byte_array_pattern", "global_ci"],
)
def test_match_modes(run, write_fixture, program, expected):
    """Matching over binary values honours the mode selection: the b flag
    switches to byte runes, a byte-array pattern matches single bytes,
    and global case-insensitive flags return every hit.
    """
    # CATCHES: pkg/interp/match.go mode flags (b, g, i) and pattern typing

    result = run(["-c", "-n", program])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == expected


def test_match_named_captures(run, write_fixture):
    """Matching a UTF-8 pattern against a binary value yields rune
    offsets and both the named and the unnamed capture groups.
    """
    # CATCHES: pkg/interp/match.go capture group offsets/names on binary input

    result = run([
        '-c',
        '-n',
        '"cbbcåååccåååcbc" | tobytes | match("å(?<n>å)(å)") | {offset, length, captures}',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"captures":[{"length":2,"name":"n","offset":6,"string":"å"},{"length":2,"name":null,"offset":8,"string":"å"}],"length":6,"offset":4}\n'


def test_match_byte_mode_has_no_captures(run, write_fixture):
    """In byte-runes mode a byte-array pattern matches byte offsets and
    produces no capture groups.
    """
    # CATCHES: pkg/interp/match.go byte mode capture suppression

    result = run([
        '-c',
        '-n',
        '"cbbcåååccåååcbc" | tobytes | match("ååå" | tobytes; "b") | {offset, length, captures}',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"captures":[],"length":6,"offset":4}\n'


def test_capture_on_binary(run, write_fixture):
    """The capture builtin converts a binary match into a plain object
    keyed by the named capture.
    """
    # CATCHES: pkg/interp/match.go capture builtin over binary values

    result = run(['-c', '-n', '"cbbcåååccåååcbc" | tobytes | capture("å(?<n>å)(å)")'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"n":"å"}\n'


def test_match_inside_decoded_audio(run, mp3):
    """A regex can be run over a byte range extracted from a decoded
    format value: matching a two byte pattern inside the second MP3
    frame's audio data.
    """
    # CATCHES: pkg/interp/match.go matching decoded value bytes via tobytes

    result = run([
        '-c',
        '-d',
        'mp3',
        '.frames[1].audio_data | tobytes | match("3\\u0085"; "b") | {offset, length}',
        'test.mp3',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"length":2,"offset":4}\n'

