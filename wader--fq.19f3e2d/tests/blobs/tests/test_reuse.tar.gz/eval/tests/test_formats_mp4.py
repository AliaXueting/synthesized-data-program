"""ISO base media file (mp4) decoding: box layout, the esds/MPEG
ES descriptor chain, AVC configuration and VP9 frame headers.

Vectors: src/format/isobmff/testdata/{aac,avc,fragmented,vp9}.mp4.
"""

import pytest


@pytest.mark.parametrize(
    "fixture, filename, expected",
    [
        ("mp4_aac", "aac.mp4", '["ftyp","free","mdat","moov"]\n',),
        ("mp4_frag", "fragmented.mp4", '["ftyp","moov","moof","mdat","moof","mdat","moof","mdat","mfra"]\n',),
    ],
    ids=["simple", "fragmented"],
)
def test_mp4_top_level_boxes(run, write_fixture, fixture, filename, expected):
    """The top level box layout of an mp4 file decodes in file order,
    both for a simple movie and for a fragmented one with moof/mfra
    boxes.
    """
    # CATCHES: isobmff/boxes.go top-level box walking incl. movie fragments
    write_fixture(fixture, filename)

    result = run(["-c", "-d", "mp4", "[.boxes[].type]", filename])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == expected


def test_mp4_ftyp_brands(run, write_fixture):
    """The ftyp box decodes its major brand, minor version and the
    compatible brands list.
    """
    # CATCHES: isobmff/boxes.go ftyp brand list decoding
    write_fixture("mp4_aac", "aac.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '[.. | objects | select(.type? == "ftyp") | tovalue | {major_brand, minor_version, brands}]',
        'aac.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"brands":["isom","iso2","mp41"],"major_brand":"isom","minor_version":512}]\n'


def test_mp4_esds_elementary_stream_descriptor(run, write_fixture):
    """The esds box decodes into an MPEG ES elementary stream descriptor
    with the ES id, dependency flags and stream priority.
    """
    # CATCHES: mpeg/mpeg_es.go ES_DescrTag field decoding
    write_fixture("mp4_aac", "aac.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '[.. | objects | select(.type? == "esds") | .descriptor | tovalue | {tag_id, es_id, stream_dependency_flag, url_flag, ocr_stream_flag, stream_priority}]',
        'aac.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"es_id":1,"ocr_stream_flag":false,"stream_dependency_flag":false,"stream_priority":0,"tag_id":"ES_DescrTag","url_flag":false}]\n'


def test_mp4_esds_decoder_config_descriptor(run, write_fixture):
    """The decoder config descriptor nested in esds carries the stream
    type, object type indication and the bitrate triple.
    """
    # CATCHES: mpeg/mpeg_es.go DecoderConfigDescrTag stream type and bitrates
    write_fixture("mp4_aac", "aac.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '[.. | objects | select(.type? == "esds") | .descriptor.dec_config_descr | tovalue | {tag_id, object_type_indication, stream_type, upstream, specific_info_flag, buffer_size_db, max_bit_rate, avg_bit_rate}]',
        'aac.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"avg_bit_rate":67085,"buffer_size_db":0,"max_bit_rate":69000,"object_type_indication":"MPEGObjectTypeAAC","specific_info_flag":true,"stream_type":"AudioStream","tag_id":"DecoderConfigDescrTag","upstream":false}]\n'


def test_mp4_esds_audio_specific_config(run, write_fixture):
    """The audio specific config nested in the decoder specific info
    resolves the AAC object type, sampling rate and channel count.
    """
    # CATCHES: mpeg ASC decoding reached through mpeg_es decoder_specific_info
    write_fixture("mp4_aac", "aac.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '[.. | objects | select(.type? == "esds") | .descriptor.dec_config_descr.decoder_specific_info.audio_specific_config | tovalue | {object_type, sampling_frequency, channel_configuration}]',
        'aac.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"channel_configuration":1,"object_type":"aac_lc","sampling_frequency":44100}]\n'


def test_mp4_avc_decoder_configuration(run, write_fixture):
    """The avcC box decodes into the AVC decoder configuration record:
    profile/level indication and NAL length sizing.
    """
    # CATCHES: isobmff/boxes.go avcC record decoding (avc_dcr fields)
    write_fixture("mp4_avc", "avc.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '[.. | objects | select(.type? == "avcC") | .descriptor | tovalue | {configuration_version, profile_indication, profile_compatibility, level_indication, length_size, num_of_sequence_parameter_sets, num_of_picture_parameter_sets}]',
        'avc.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"configuration_version":1,"length_size":4,"level_indication":"1.3","num_of_picture_parameter_sets":1,"num_of_sequence_parameter_sets":1,"profile_compatibility":0,"profile_indication":"high_444_predictive_profile"}]\n'


def test_mp4_avcc_embedded_sps(run, write_fixture):
    """The sequence parameter set NAL embedded in avcC decodes through
    the same avc_sps parser used for Annex B streams.
    """
    # CATCHES: mpeg/avc_sps.go reached via the mp4 avcC path
    write_fixture("mp4_avc", "avc.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '[.. | objects | select(.type? == "avcC") | .descriptor.sequence_parameter_sets[0].nal.rbsp | tovalue | {profile_idc, level_idc, chroma_format_idc, pic_width_in_mbs, pic_height_in_map_units}]',
        'avc.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"chroma_format_idc":"4:4:4","level_idc":"1.3","pic_height_in_map_units":15,"pic_width_in_mbs":20,"profile_idc":"high_444_predictive_profile"}]\n'


def test_mp4_avcc_embedded_pps(run, write_fixture):
    """The picture parameter set NAL embedded in avcC decodes through
    the shared avc_pps parser.
    """
    # CATCHES: mpeg/avc_pps.go reached via the mp4 avcC path
    write_fixture("mp4_avc", "avc.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '[.. | objects | select(.type? == "avcC") | .descriptor.picture_parameter_sets[0].nal.rbsp | tovalue | {pic_parameter_set_id, seq_parameter_set_id, pic_init_qp}]',
        'avc.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"pic_init_qp":23,"pic_parameter_set_id":0,"seq_parameter_set_id":0}]\n'


def test_mp4_avc_sample_expands_to_nalus(run, write_fixture):
    """The first sample of the AVC track expands into its NAL units: a
    SEI followed by an IDR slice.
    """
    # CATCHES: isobmff boxes -> track samples -> avc_au -> avc_nalu decode chain
    write_fixture("mp4_avc", "avc.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '[.tracks[0].samples[0][].nalu.nal_unit_type]',
        'avc.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["sei","idr_slice"]\n'


def test_mp4_track_summary(run, write_fixture):
    """The movie's tracks surface with their id and data format: a
    single mp4a audio track with id 1.
    """
    # CATCHES: isobmff/boxes.go trak/mdia walking surfaced as .tracks
    write_fixture("mp4_aac", "aac.mp4")

    result = run(['-c', '-d', 'mp4', '[.tracks[] | {id, data_format}]', 'aac.mp4'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"data_format":"mp4a","id":1}]\n'


def test_mp4_vp9_keyframe_header(run, write_fixture):
    """The first sample of the VP9 track decodes as an uncompressed
    frame header: a 320x240 8-bit profile 1 key frame that is shown.
    """
    # CATCHES: vpx/vp9_frame.go key frame header field decoding
    write_fixture("mp4_vp9", "vp9.mp4")

    result = run([
        '-c',
        '-d',
        'mp4',
        '.tracks[0].samples[0] | tovalue | {frame_type, show_frame, error_resilient_mode, profile, bit_depth, frame_width, frame_height, render_width, render_height}',
        'vp9.mp4',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"bit_depth":8,"error_resilient_mode":0,"frame_height":240,"frame_type":"key_frame","frame_width":320,"profile":1,"render_height":null,"render_width":null,"show_frame":1}\n'

