"""Exit code and error reporting behaviour, ported from the native
pkg/interp/testdata/exitcode.fqtest and inputs.fqtest scripts."""

import pytest


def test_runtime_error_exit_code(run):
    """A jq runtime error exits with code 5."""
    result = run(["-n", '1+"a"'])
    # CATCHES: type errors abort the run with the dedicated exit code 5 and
    # a message that names both operand types and values.
    assert (result.returncode, result.out) == (5, "")
    assert result.err == 'error: cannot add: number (1) and string ("a")\n'


def test_halt_error_with_string(run):
    """halt_error prints the string to stderr and uses its code."""
    result = run(["-n", '"abc\\n" | halt_error(123)'])
    # CATCHES: halt_error writes the raw string payload to stderr (without
    # the usual 'error:' prefix) and exits with the caller supplied code.
    assert (result.returncode, result.out) == (123, "")
    assert result.err == "abc\n"


def test_halt_error_with_null(run):
    """halt_error on null prints nothing at all."""
    result = run(["-n", "null | halt_error(123)"])
    # CATCHES: a null payload produces no stderr bytes while the exit code
    # is still the one passed to halt_error.
    assert (result.returncode, result.stdout, result.stderr) == (123, b"", b"")


def test_undefined_function_exit_code(run):
    """An unknown function is a compile error with exit code 3."""
    result = run(["-n", "invalid"])
    # CATCHES: unknown functions fail at compile time (exit 3) and the
    # message is prefixed with the expression source name 'arg'.
    assert (result.returncode, result.out) == (3, "")
    assert result.err == "error: arg: function not defined: invalid/0\n"


def test_unexpected_eof_exit_code(run):
    """An unbalanced parenthesis is a parse error with exit code 3."""
    result = run(["-n", "("])
    # CATCHES: the parse error carries the source name and the 1:1 position
    # of the start of the truncated expression.
    assert (result.returncode, result.out) == (3, "")
    assert result.err == "error: arg:1:1: unexpected EOF\n"


def test_parse_error_in_expression_file(run, write):
    """A syntax error in a -f file reports the file name and position."""
    write("err.jq", "asdad)")
    result = run(["-nf", "err.jq"])
    # CATCHES: errors read from an expression file are reported against the
    # file name and the position inside it, not against 'arg'.
    assert (result.returncode, result.out) == (3, "")
    assert result.err == 'error: err.jq:1:6: unexpected token ")"\n'


def test_probe_failure_exit_code(run, write):
    """An undecodable file is a probe failure with exit code 4."""
    write("a", "test")
    result = run([".", "a"])
    # CATCHES: when probing cannot identify a format the run stops with
    # exit code 4 and the message suggests forcing a decoder with -d.
    assert (result.returncode, result.out) == (4, "")
    assert result.err == (
        "error: a: probe: failed to decode: "
        "try fq -d FORMAT to force format, see fq -h formats for list\n")


def test_unknown_decode_group(run, mp3):
    """-d with an unknown group is an exit code 4 error."""
    result = run(["-d", "bbb", ".", "test.mp3"])
    # CATCHES: the bad group name is reported per input file with the
    # 'format group not found' reason and exit code 4.
    assert (result.returncode, result.out) == (4, "")
    assert result.err == "error: test.mp3: bbb: format group not found\n"


def test_decode_function_unknown_group(run):
    """decode() with an unknown group raises a runtime error."""
    result = run(["-n", '"aaa" | decode("aaa")'])
    # CATCHES: the decode builtin takes the same group registry path as -d
    # but surfaces the failure as a plain runtime error (exit 5) with no
    # file prefix because the input came from an expression.
    assert (result.returncode, result.out) == (5, "")
    assert result.err == "error: format group not found\n"


def test_error_per_input_file(run, write):
    """A runtime error is reported once per input file."""
    write("a", '"a"')
    write("b", '"b"')
    write("c", '"c"')
    result = run(["-d", "json", '1+"a"', "a", "b", "c"])
    # CATCHES: each file is evaluated independently so the same runtime
    # error is emitted three times, once prefixed with every file name.
    assert (result.returncode, result.out) == (5, "")
    assert result.err == (
        'error: a: cannot add: number (1) and string ("a")\n'
        'error: b: cannot add: number (1) and string ("a")\n'
        'error: c: cannot add: number (1) and string ("a")\n')


def test_compile_error_before_files(run, write):
    """A compile error aborts before any file is opened."""
    write("a", '"a"')
    write("b", '"b"')
    result = run(["-d", "json", "bla", "a", "b"])
    # CATCHES: an unknown function is detected at compile time so no file
    # is ever opened and only the single compile error is printed.
    assert (result.returncode, result.out) == (3, "")
    assert result.err == "error: arg: function not defined: bla/0\n"


def test_missing_file_stops_other_files(run, write):
    """A missing file among inputs is reported but others still run."""
    write("a", '"a"')
    write("c", '"c"')
    result = run(["-d", "json", "input_filename", "a", "non-existing", "c"])
    # CATCHES: files are processed in order; the missing one produces an
    # exit 2 error on stderr while the existing ones still emit their names
    # on stdout.
    assert result.returncode == 2
    assert result.out == '"a"\n"c"\n'
    assert result.err == "error: non-existing: no such file or directory\n"


def test_runtime_error_from_stdin_prefix(run):
    """Runtime errors from stdin carry the <stdin> prefix."""
    result = run(["-d", "json", '1+"a"'], stdin='"a"')
    # CATCHES: when the decoded input comes from stdin the error message is
    # prefixed with '<stdin>' the same way file inputs use their name.
    assert (result.returncode, result.out) == (5, "")
    assert result.err == (
        'error: <stdin>: cannot add: number (1) and string ("a")\n')
