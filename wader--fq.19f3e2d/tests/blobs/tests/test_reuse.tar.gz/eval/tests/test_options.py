"""The --option/-o machinery and the 'options' builtin, ported from the
native pkg/interp/testdata/options.fqtest script of the reference
repository."""

import pytest


def test_options_builtin_dump(run):
    """'options' exposes every effective option as an object."""
    result = run(["-n", "options"])
    # CATCHES: the whole effective option set is visible to expressions;
    # values that depend on the environment (raw_output true and width 0
    # for a piped stdout, decode_progress false from NO_DECODE_PROGRESS)
    # are pinned exactly as recorded from the reference binary.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == OPTIONS_DUMP


@pytest.mark.parametrize("option,expr,expected", [
    ("addrbase=10", "options.addrbase", "10\n"),
    # a non-number value for a number option keeps the default
    ("addrbase=true", "options.addrbase", "16\n"),
    ("array_truncate=10", "options.array_truncate", "10\n"),
    ("array_truncate=true", "options.array_truncate", "50\n"),
    ("bits_format=base64", "options.bits_format", '"base64"\n'),
    ("compact=aaa", "options.compact", "false\n"),
    ("depth=10", "options.depth", "10\n"),
    ("depth=true", "options.depth", "0\n"),
    ("display_bytes=10", "options.display_bytes", "10\n"),
    ("display_bytes=true", "options.display_bytes", "16\n"),
    ("include_path=path", "options.include_path", "[]\n"),
    ("line_bytes=true", "options.line_bytes", "16\n"),
    ("raw_output=aaa", "options.raw_output", "true\n"),
    ("raw_string=aa", "options.raw_string", "false\n"),
    ("raw_string=true", "options.raw_string", "true\n"),
    ("sizebase=10", "options.sizebase", "10\n"),
    ("sizebase=aaa", "options.sizebase", "10\n"),
    ("slurp=aaa", "options.slurp", "false\n"),
    ("string_input=aaa", "options.string_input", "false\n"),
    ("unicode=aaa", "options.unicode", "false\n"),
    ("verbose=aaa", "options.verbose", "false\n"),
    ("null_input=aaa", "options.null_input", "true\n"),
])
def test_option_value_parsing(run, option, expr, expected):
    """-o NAME=VALUE parses numbers, strings and fallback booleans."""
    result = run(["-o", option, "-n", expr])
    # CATCHES: -o coerces the value to the option's type; anything that is
    # not convertible (like 'aaa' or 'true' for a number option) silently
    # keeps the option default instead of failing the run.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == expected


def test_option_byte_colors(run):
    """byte_colors accepts a range=color specification."""
    result = run(["-o", "byte_colors=0-0xff=red", "-n", "options.byte_colors"])
    # CATCHES: the byte_colors string option expands into the structured
    # ranges form used by the hexdump colouring code.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[\n  {\n    "ranges": [\n      [\n        0,\n'
        '        255\n      ]\n    ],\n    "value": "red"\n  }\n]\n')


def test_option_colors_map(run):
    """colors accepts a name=color specification."""
    result = run(["-o", "colors=number=red", "-n", "options.colors"])
    # CATCHES: setting one colour replaces the whole colours map with a
    # single entry rather than merging over the defaults.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{\n  "number": "red"\n}\n'


def test_option_join_string(run):
    """join_string parses JSON escapes and is used as the output separator."""
    result = run(["-o", r"join_string=aaa\n", "-n", "options.join_string"])
    # CATCHES: the '\n' escape in the option value is unescaped as JSON, so
    # the echoed string value contains a real newline, and the join string
    # itself replaces the usual newline after each output value.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"aaa\\n"aaa\n'


def test_option_expr(run):
    """-o expr= overrides the expression itself."""
    result = run(["-n", "-o", "expr=123"])
    # CATCHES: the expr option is honoured as the expression to evaluate,
    # overriding any expression given on the command line.
    assert (result.returncode, result.out, result.err) == (0, "123\n", "")


def test_option_from_file_value(run, write):
    """-o NAME=@PATH reads the option value from a file."""
    write("filea", "aaa\n")
    result = run(["-n", "-o", "from_file=@filea", "options.from_file"])
    # CATCHES: the @PATH form reads the file bytes as the option value,
    # here a string containing the trailing newline of the file.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"aaa\\n"\n'


def test_option_from_file_missing(run):
    """-o NAME=@PATH with a missing path is an IO error."""
    result = run(["-n", "-o", "from_file=@does_not_exist", "options.from_file"])
    # CATCHES: the failing -o argument is echoed with its full NAME=@PATH
    # spelling in the error and the run exits 2 before evaluating.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: -o from_file=@does_not_exist: no such file or directory\n"


def test_option_expr_file_missing(run):
    """-o expr_file= with a missing file is an IO error."""
    result = run(["-o", "expr_file=test.jq", "-n", "options.expr_file"])
    # CATCHES: unlike most options, expr_file is opened eagerly so a bad
    # path aborts the run with exit code 2 and the plain path in the error.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: test.jq: no such file or directory\n"


def test_option_filenames(run, mp3):
    """-o filenames= replaces the input file list."""
    result = run(["-o", 'filenames=["test.mp3"]', "format"])
    # CATCHES: the filenames option drives which files are opened, so an
    # empty command line still decodes the named file and reports mp3.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"mp3"\n'


def test_option_color_forces_ansi(run):
    """-o color=10 still turns colour on."""
    result = run(["-o", "color=10", "-n", "options.color"])
    # CATCHES: a non-boolean value for the color option is treated as true
    # (unlike number options), and printing a boolean with colour on wraps
    # it in the yellow ANSI escape even though NO_COLOR is set.
    assert (result.returncode, result.err) == (0, "")
    assert result.stdout == b"\x1b[33mtrue\x1b[m\n"


def test_option_decode_progress_off_by_env(run):
    """NO_DECODE_PROGRESS in the environment disables decode progress."""
    result = run(["-n", "options.decode_progress"])
    # CATCHES: the pinned child environment sets NO_DECODE_PROGRESS=1 (as
    # does the reference repository's own harness) which flips the
    # decode_progress option default to false.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "false\n"


def test_option_decode_progress_aaa(run):
    """-o decode_progress=aaa falls back to false."""
    result = run(["-o", "decode_progress=aaa", "-n", "options.decode_progress"])
    # CATCHES: an unparsable boolean keeps the current (environment
    # derived) value, which is false in this environment.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "false\n"


def test_options_select_subset(run):
    """Object construction selects from the options object."""
    result = run(["-n", "options | {display_bytes, line_bytes}"])
    # CATCHES: options is an ordinary object that expressions can project;
    # both byte width options default to 16 for a piped stdout.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == ('{\n  "display_bytes": 16,\n  "line_bytes": 16\n}\n')


def test_option_force(run):
    """force=true is visible through the options object."""
    result = run(["-o", "force=true", "-n", "options.force"])
    # CATCHES: the -o spelling of the force flag (used to keep decoding
    # after errors) sets the same option the --force style flags would.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "true\n"


def test_option_verbose_true(run):
    """verbose=true round trips through the options object."""
    result = run(["-o", "verbose=true", "-n", "options.verbose"])
    # CATCHES: boolean options parse the literal 'true' string and echo
    # back as the JSON true value.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "true\n"


OPTIONS_DUMP = """\
{
  "addrbase": 16,
  "arg": [],
  "argdecode": [],
  "argjson": [],
  "args": [],
  "argsjson": [],
  "array_truncate": 50,
  "bits_format": "string",
  "byte_colors": [
    {
      "ranges": [
        [
          0,
          255
        ]
      ],
      "value": "default+bold"
    },
    {
      "ranges": [
        [
          0
        ]
      ],
      "value": "brightblack"
    },
    {
      "ranges": [
        [
          32,
          126
        ],
        [
          9,
          13
        ]
      ],
      "value": "default"
    }
  ],
  "color": false,
  "colors": {
    "array": "default",
    "dumpaddr": "yellow",
    "dumpheader": "yellow+underline",
    "error": "brightred",
    "false": "yellow",
    "index": "default",
    "null": "brightblack",
    "number": "cyan",
    "object": "default",
    "objectkey": "brightblue",
    "prompt_repl_level": "brightblack",
    "prompt_value": "default",
    "string": "green",
    "true": "yellow",
    "value": "default"
  },
  "compact": false,
  "completion_timeout": 1,
  "decode_group": "probe",
  "decode_progress": false,
  "depth": 0,
  "display_bytes": 16,
  "expr": "options",
  "expr_eval_path": "arg",
  "expr_file": null,
  "expr_given": true,
  "filenames": [
    null
  ],
  "force": false,
  "include_path": [],
  "join_string": "\\n",
  "line_bytes": 16,
  "null_input": true,
  "raw_file": [],
  "raw_output": true,
  "raw_string": false,
  "repl": false,
  "show_help": false,
  "sizebase": 10,
  "skip_gaps": false,
  "slurp": false,
  "string_input": false,
  "string_truncate": 50,
  "unicode": false,
  "value_output": false,
  "verbose": false,
  "width": 0
}
"""
