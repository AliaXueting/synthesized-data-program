"""Expression files (-f), pre-defined variables (--arg/--argjson/--raw-file/
--argdecode) and include paths (-L), ported from the native
pkg/interp/testdata/exprfile.fqtest, argvars.fqtest and incudepath.fqtest
scripts of the reference repository."""


def test_from_file_reads_expression(run, write):
    """-f evaluates the expression stored in a file."""
    write("test.jq", "123")
    result = run(["-n", "-f", "test.jq"])
    # CATCHES: the file content is used verbatim as the expression and the
    # file name never appears in error or output messages.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == "123\n"


def test_from_file_with_input(run, write, mp3):
    """-f combined with a data file decodes that file."""
    write("test2.jq", ".headers[0].header.magic | tovalue")
    result = run(["-f", "test2.jq", "test.mp3"])
    # CATCHES: the expression from the file is applied to the probed input
    # file just like an inline expression would be.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"ID3"\n'


def test_from_file_long_flag(run, write, mp3):
    """--from-file is the long spelling of -f."""
    write("test2.jq", ".headers[0].header.magic | tovalue")
    result = run(["--from-file", "test2.jq", "test.mp3"])
    # CATCHES: the long flag behaves identically, including how the
    # expression file is applied to the input file.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"ID3"\n'


def test_from_file_missing(run):
    """-f with a missing file is an IO error."""
    result = run(["-n", "-f", "missing"])
    # CATCHES: a missing expression file exits 2 with the plain path in the
    # error, before any expression is compiled.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: missing: no such file or directory\n"


def test_raw_file_variable(run, write):
    """--raw-file exposes a file's bytes as a string variable."""
    write("a.json", "aaa\n")
    result = run(["-n", "--raw-file", "filea", "a.json", "$filea"])
    # CATCHES: the named variable holds the file content as a string with
    # its trailing newline preserved.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"aaa\\n"\n'


def test_raw_file_missing(run):
    """--raw-file with a missing file is an IO error."""
    result = run(["-n", "--raw-file", "filea", "nonexisting"])
    # CATCHES: the error names the missing path without the --raw-file
    # spelling or the variable name.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: nonexisting: no such file or directory\n"


def test_argdecode_variable(run, mp3):
    """--argdecode exposes a decoded file as a decode value variable."""
    result = run(["-n", "--argdecode", "filea", "test.mp3",
                  "$filea | format"])
    # CATCHES: the named variable holds the probed decode value, so the
    # format builtin reports mp3 for the fixture.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"mp3"\n'


def test_argdecode_missing(run):
    """--argdecode with a missing file is an IO error."""
    result = run(["-n", "--argdecode", "filea", "nonexisting"])
    # CATCHES: unlike --raw-file the argdecode error keeps the flag and the
    # variable name in the message.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: --argdecode filea: no such file or directory\n"


def test_argjson_invalid_json(run):
    """--argjson with invalid JSON reports a parse error."""
    result = run(["-n", "--argjson", "a", "("])
    # CATCHES: the JSON is parsed eagerly, so a broken value exits 2 with
    # the fromjson error prefixed by the flag and variable name.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == (
        "error: --argjson a: fromjson cannot be applied to \"(\": "
        "invalid character '(' looking for beginning of value\n")


def test_argjson_needs_two_arguments(run):
    """--argjson without a value is a usage error."""
    result = run(["-n", "--argjson", "a"])
    # CATCHES: the flag demands exactly two following arguments and prints
    # its own 'needs two argument' diagnostic (sic) with exit code 2.
    assert (result.returncode, result.out) == (2, "")
    assert result.err == "error: --argjson: needs two argument\n"


def test_include_path(run, write):
    """-L adds a directory to the include search path."""
    write("library/a.jq", 'def a: "a";')
    result = run(["-L", "library", "-n", 'include "a"; a'])
    # CATCHES: the include resolves relative to the -L directory, and the
    # library file name must carry the .jq extension implicitly.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a"\n'


def test_include_path_long_flag(run, write):
    """--include-path is the long spelling of -L."""
    write("library/a.jq", 'def a: "a";')
    result = run(["--include-path", "library", "-n", 'include "a"; a'])
    # CATCHES: the long flag feeds the same search path mechanism as -L.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a"\n'


def test_include_path_falls_through(run, write):
    """Earlier -L paths are tried before later ones."""
    write("library/a.jq", 'def a: "a";')
    result = run(["-L", "wrong", "-L", "library", "-n", 'include "a"; a'])
    # CATCHES: a non-existent first search path is skipped without any
    # warning and the next -L directory still resolves the include.
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"a"\n'


def test_include_missing_library(run):
    """An include that cannot be resolved is a compile error."""
    result = run(["-L", "wrong", "-n", 'include "a"; a'])
    # CATCHES: the unresolved include reports the logical library file name
    # 'a.jq' with the 'file does not exist' reason and exit code 3.
    assert (result.returncode, result.out) == (3, "")
    assert result.err == "error: arg: open a.jq: file does not exist\n"
