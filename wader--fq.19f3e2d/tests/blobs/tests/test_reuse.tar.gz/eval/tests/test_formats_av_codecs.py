"""Behavioural tests for codec decoders: the HEVC decoder
configuration record, the AV1 codec configuration record, Apple
ProRes frames, and Opus and Vorbis packets.

Vectors come from the reference repository's format test data
(src/format/{mpeg,av1,prores,opus,vorbis}/testdata); every
expectation was recorded by running the reference binary.
"""


def test_hevc_decoder_configuration_record(run, write_fixture):
    """The hvcC record decodes to its profile, level, chroma format and bit
    depth fields with 4-byte NAL length prefixes and three NAL arrays.
    """
    # CATCHES: mpeg/hevc_dcr.go profile/level/bit-depth fields and array count
    write_fixture("hevc_dcr")

    result = run([
        '-c',
        '-d',
        'hevc_dcr',
        '{configuration_version, general_profile_idc, general_level_idc, chroma_format_idc, bit_depth_luma, bit_depth_chroma, length_size, num_of_arrays}',
        'hevc_dcr',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"bit_depth_chroma":8,"bit_depth_luma":8,"chroma_format_idc":1,"configuration_version":1,"genera'
        'l_level_idc":123,"general_profile_idc":1,"length_size":4,"num_of_arrays":3}\n'
    )


def test_hevc_dcr_nal_arrays(run, write_fixture):
    """The three arrays are the VPS, SPS and PPS, each complete, each holding
    exactly one NAL unit.
    """
    # CATCHES: mpeg/hevc_dcr.go array_completeness and NUT naming
    write_fixture("hevc_dcr")

    result = run([
        '-c',
        '-d',
        'hevc_dcr',
        '[.arrays[] | {array_completeness, nal_unit_type, num_nalus}]',
        'hevc_dcr',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"array_completeness":1,"nal_unit_type":"VPS_NUT","num_nalus":1},{"array_completeness":1,"nal_u'
        'nit_type":"SPS_NUT","num_nalus":1},{"array_completeness":1,"nal_unit_type":"PPS_NUT","num_nalus"'
        ':1}]\n'
    )


def test_hevc_dcr_nal_unit_lengths(run, write_fixture):
    """The VPS, SPS and PPS NAL units are 26, 38 and 7 bytes long
    respectively.
    """
    # CATCHES: mpeg/hevc_dcr.go per-NAL length prefix reading
    write_fixture("hevc_dcr")

    result = run(['-c', '-d', 'hevc_dcr', '[.arrays[].nals[].nal_unit_length]', 'hevc_dcr'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[26,38,7]\n'


def test_hevc_dcr_first_nal_header(run, write_fixture):
    """The first NAL unit header inside the record decodes with the VPS_NUT
    type, temporal id plus one, and the forbidden bit clear.
    """
    # CATCHES: mpeg/hevc_dcr.go nested NAL header bit unpacking
    write_fixture("hevc_dcr")

    result = run([
        '-c',
        '-d',
        'hevc_dcr',
        '.arrays[0].nals[0].nal | {nal_unit_type, nuh_temporal_id_plus1, forbidden_zero_bit}',
        'hevc_dcr',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"forbidden_zero_bit":false,"nal_unit_type":"VPS_NUT","nuh_temporal_id_plus1":1}\n'


def test_av1_codec_configuration_record(run, write_fixture):
    """The av1C record decodes marker, version, profile and level, the colour
    config of the embedded sequence header OBU, and the presentation delay
    bits.
    """
    # CATCHES: av1/av1_ccr.go field layout and embedded sequence header OBU
    write_fixture("av1_ccr")

    result = run(['-c', '-d', 'av1_ccr', 'tovalue', 'av1_ccr'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"chroma_sample_position":0,"chroma_subsampling_x":0,"chroma_subsampling_y":0,"config_obus":[{"c'
        'olor_config":{"bit_depth":8,"chroma_sample_position":0,"color_description_present_flag":1,"color'
        '_primaries":"bt_709","color_range":0,"high_bitdepth":0,"matrix_coefficients":"bt_709","mono_chro'
        'me":0,"separate_uv_delta_q":0,"subsampling_x":1,"subsampling_y":1,"transfer_characteristics":"bt'
        '_709"},"data":"\\ufffd","enable_cdef":1,"enable_dual_filter":0,"enable_filter_intra":0,"enable_in'
        'terintra_compound":1,"enable_intra_edge_filter":1,"enable_jnt_comp":0,"enable_masked_compound":0'
        ',"enable_order_hint":1,"enable_ref_frame_mvs":1,"enable_restoration":1,"enable_superres":0,"enab'
        'le_warped_motion":1,"film_grain_params_present":1,"frame_height":1080,"frame_height_bits_minus_1'
        '":10,"frame_id_numbers_present_flag":0,"frame_width":1920,"frame_width_bits_minus_1":10,"header"'
        ':{"extension_flag":false,"forbidden_bit":0,"has_size_field":true,"reserved_1bit":0,"type":"seque'
        'nce_header"},"initial_display_delay_present_flag":0,"max_frame_height_minus_1":1079,"max_frame_w'
        'idth_minus_1":1919,"operating_points":[{"operating_point_idc":0,"seq_level_idx":8,"seq_tier":0}]'
        ',"operating_points_cnt_minus_1":0,"order_hint_bits_minus_1":6,"reduced_still_picture_header":0,"'
        'seq_choose_integer_mv":1,"seq_choose_screen_content_tools":1,"seq_profile":"main","size":14,"sti'
        'll_picture":0,"timing_info_present_flag":0,"use_128x128_superblock":0}],"high_bitdepth":0,"initi'
        'al_presentation_delay":3,"initial_presentation_delay_present":true,"marker":1,"monochrome":0,"re'
        'served0":0,"seq_level_idx_0":0,"seq_profile":0,"seq_tier_0":0,"twelve_bit":0,"version":1}\n'
    )


def test_av1_ccr_reserved_delay_field(run, write_fixture):
    """Without the presentation-delay-present bit the four bits decode as
    reserved1 instead of a delay value, and the delay itself stays null.
    """
    # CATCHES: av1/av1_ccr.go initial_presentation_delay_present branch
    write_fixture("av1_ccr_nodelay")

    result = run([
        '-c',
        '-d',
        'av1_ccr',
        '{marker, version, seq_profile, seq_level_idx_0, initial_presentation_delay, reserved1}',
        'av1_ccr_nodelay',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"initial_presentation_delay":null,"marker":1,"reserved1":5,"seq_level_idx_0":0,"seq_profile":0,'
        '"version":1}\n'
    )


def test_prores_track_and_sample(run, write_fixture):
    """The movie's single video track is an ap4h (ProRes 4444) track carrying
    exactly one sample, and the top-level boxes are ftyp, wide, mdat and
    moov.
    """
    # CATCHES: isobmff ap4h sample dispatch to the prores frame decoder
    write_fixture("prores_mov")

    result = run(['-c', '-d', 'mp4', '[.boxes[] | .type]', 'prores_mov'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["ftyp","wide","mdat","moov"]\n'

    result = run([
        '-c',
        '-d',
        'mp4',
        '{data_format: (.tracks[0].data_format | tovalue), samples: (.tracks[0].samples | length)}',
        'prores_mov',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"data_format":"ap4h","samples":1}\n'

    result = run(['-c', '-d', 'mp4', '.tracks[0].data_format | tovalue', 'prores_mov'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"ap4h"\n'


def test_prores_frame_container(run, write_fixture):
    """The sample payload is wrapped in an icpf container 27673 bytes long."""
    # CATCHES: prores/prores_frame.go icpf container size and type
    write_fixture("prores_mov")

    result = run(['-c', '-d', 'mp4', '.tracks[0].samples[0].container | tovalue', 'prores_mov'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"size":27673,"type":"icpf"}\n'


def test_prores_frame_header(run, write_fixture):
    """The ProRes frame header decodes with the fmpg creator id, 320x240
    geometry, progressive 4:4:4 flags and a 148-byte header size.
    """
    # CATCHES: prores/prores_frame.go header fields and frame flag enums
    write_fixture("prores_mov")

    result = run([
        '-c',
        '-d',
        'mp4',
        '.tracks[0].samples[0].header | tovalue | {creator_id, hdr_size, width, height, frame_flags, primaries, color_matrix, alpha_info}',
        'prores_mov',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"alpha_info":0,"color_matrix":2,"creator_id":"fmpg","frame_flags":{"chrominance_factor":"444","'
        'frame_type":"progressive","unused0":0,"unused1":2},"hdr_size":148,"height":240,"primaries":2,"wi'
        'dth":320}\n'
    )


def test_opus_identification_header(run, write_fixture):
    """An OpusHead identification header decodes the magic string, version,
    two channels, 48 kHz, 312 samples of pre-skip and the gain and map
    fields.
    """
    # CATCHES: opus/opus_packet.go identification header field layout
    write_fixture("opus_head")

    result = run(['-c', '-d', 'opus_packet', 'tovalue', 'opus_head'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"channel_count":2,"map_family":0,"output_gain":0,"pre_skip":312,"prefix":"OpusHead","sample_rat'
        'e":48000,"type":"head","version":1}\n'
    )


def test_opus_comment_header(run, write_fixture):
    """The OpusTags comment header carries the vendor string and the recorded
    user comments.
    """
    # CATCHES: opus/opus_packet.go comment header vendor and comment list
    write_fixture("opus_tags")

    result = run(['-c', '-d', 'opus_packet', '.comment | tovalue', 'opus_tags'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"user_comment_list_length":2,"user_comments":[{"comment":"encoder=Lavc58.91.100 libopus","lengt'
        'h":29},{"comment":"artist=bla","length":10}],"vendor":"Lavf58.45.100","vendor_length":13}\n'
    )


def test_opus_audio_packet_toc(run, write_fixture):
    """An audio packet's table of contents decodes to a stereo, one-frame,
    full-bandwidth CELT-only configuration of 20 ms frames.
    """
    # CATCHES: opus/opus_packet.go TOC configuration/stereo/frames decoding
    write_fixture("opus_audio")

    result = run([
        '-c',
        '-d',
        'opus_packet',
        '{type, stereo: .toc.stereo, frames: .toc.frames_per_packet.frames, mode: .toc.config.mode}',
        'opus_audio',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"frames":1,"mode":"celt_only","stereo":true,"type":"audio"}\n'

    result = run([
        '-c',
        '-d',
        'opus_packet',
        '.toc | tovalue | {stereo, mode: .config.mode, bandwidth: .config.bandwidth, frame_size: .config.frame_size, frames: .frames_per_packet.frames, fpp_mode: .frames_per_packet.mode}',
        'opus_audio',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"bandwidth":"fb","fpp_mode":"1 frame","frame_size":20,"frames":1,"mode":"celt_only","stereo":tr'
        'ue}\n'
    )


def test_vorbis_identification_header(run, write_fixture):
    """The Vorbis identification header decodes channels, sample rate,
    bitrates and both block sizes with the framing bit set.
    """
    # CATCHES: vorbis/vorbis_packet.go identification header fields
    write_fixture("vorbis_id")

    result = run(['-c', '-d', 'vorbis_packet', 'tovalue', 'vorbis_id'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"audio_channels":1,"audio_sample_rate":44100,"bitrate_maximum":0,"bitrate_minimum":0,"bitrate_n'
        'ominal":80000,"blocksize_0":256,"blocksize_1":2048,"framing_flag":1,"magic":"vorbis","packet_typ'
        'e":"identification","padding0":"\\u0000","vorbis_version":0}\n'
    )


def test_vorbis_comment_header(run, write_fixture):
    """The Vorbis comment header decodes the vendor string and the recorded
    encoder comment.
    """
    # CATCHES: vorbis/vorbis_packet.go comment header lengths and list
    write_fixture("vorbis_comment")

    result = run(['-c', '-d', 'vorbis_packet', '.comment | tovalue', 'vorbis_comment'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"user_comment_list_length":1,"user_comments":[{"comment":"encoder=Lavc58.54.100 libvorbis","len'
        'gth":31}],"vendor":"Lavf58.29.100","vendor_length":13}\n'
    )


def test_vorbis_audio_packet(run, write_fixture):
    """An audio packet decodes with packet_type audio and its coded data left
    as 32 raw bytes.
    """
    # CATCHES: vorbis/vorbis_packet.go audio packet type and data size
    write_fixture("vorbis_audio")

    result = run([
        '-c',
        '-d',
        'vorbis_packet',
        '{packet_type, data: (.data | tobytes | length)}',
        'vorbis_audio',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"data":32,"packet_type":"audio"}\n'
