"""Behavioural tests for the Bitcoin transaction, script and block
decoders.

Vectors come from the reference repository's format test data
(src/format/bitcoin/testdata); every expectation was recorded by
running the reference binary.
"""


def test_bitcoin_segwit_transaction_header(run, write_fixture):
    """A segwit transaction begins with the 0x00 marker and 0x01 flag between
    the version and the input/output counts, which is how the reference
    decoder separates the two layouts.
    """
    # CATCHES: bitcoin/bitcoin_transaction.go segwit marker/flag before the counts
    write_fixture("btc_tx")

    result = run([
        '-c',
        '-d',
        'bitcoin_transaction',
        '{version, marker, flag, input_count, output_count, locktime}',
        'btc_tx',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"flag":1,"input_count":1,"locktime":0,"marker":0,"output_count":2,"version":2}\n'


def test_bitcoin_transaction_input(run, write_fixture):
    """The vector's single input references vout 0 of the recorded txid,
    carries an empty scriptsig and the relative locktime sequence
    0xfffffffd.
    """
    # CATCHES: bitcoin/bitcoin_transaction.go input fields incl. txid and sequence
    write_fixture("btc_tx")

    result = run(['-c', '-d', 'bitcoin_transaction', '.inputs[0] | tovalue', 'btc_tx'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"scriptsig":[],"scriptsig_size":0,"sequence":4294967293,"txid":"1efe0f1537ddd0b2f94d93b56d14f30'
        'f570b7495cfbf6cd0d77c7dc0e6f28905","vout":0}\n'
    )


def test_bitcoin_transaction_outputs(run, write_fixture):
    """Both outputs expose their satoshi value together with the serialized
    length of their scriptPubKey.
    """
    # CATCHES: bitcoin/bitcoin_transaction.go output value and script size fields
    write_fixture("btc_tx")

    result = run([
        '-c',
        '-d',
        'bitcoin_transaction',
        '[.outputs[] | {value, scriptpub_size}]',
        'btc_tx',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[{"scriptpub_size":34,"value":546},{"scriptpub_size":22,"value":1590}]\n'


def test_bitcoin_scriptpubkey_ops(run, write_fixture):
    """Script opcodes resolve to symbolic names: OP_TRUE (0x51) is "true" and
    every 1-75 byte direct push is labelled "pushself".
    """
    # CATCHES: bitcoin/bitcoin_script.go opcode symbol table incl. true and pushself
    write_fixture("btc_tx")

    result = run(['-c', '-d', 'bitcoin_transaction', '[.outputs[0].scriptpub[] | .op]', 'btc_tx'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["true","pushself"]\n'

    result = run(['-c', '-d', 'bitcoin_transaction', '[.outputs[1].scriptpub[] | .op]', 'btc_tx'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["false","pushself"]\n'


def test_bitcoin_witness_field_absent(run, write_fixture):
    """Even with the segwit marker and flag set, this input's witness decodes
    to null, pinning the txinwitness slot for an empty witness stack.
    """
    # CATCHES: bitcoin/bitcoin_transaction.go txinwitness null for an empty stack
    write_fixture("btc_tx")

    result = run(['-c', '-d', 'bitcoin_transaction', '.inputs[0].txinwitness', 'btc_tx'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == 'null\n'


def test_genesis_blkdat_record(run, write_fixture):
    """Decoded as a blkdat stream the genesis file is one magic-framed record:
    the mainnet magic, a 285-byte payload and a single transaction.
    """
    # CATCHES: bitcoin_block.go blkdat magic framing and record counts
    write_fixture("btc_genesis")

    result = run([
        '-c',
        '-d',
        'bitcoin_blkdat',
        '{magic: .[0].magic, size: .[0].size, tx_count: .[0].tx_count}',
        'btc_genesis',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"magic":"mainnet","size":285,"tx_count":1}\n'


def test_genesis_block_header(run, write_fixture):
    """Forced to bitcoin_block, the raw blkdat bytes decode from offset zero:
    the mainnet magic lands in version and every later header field shifts
    by the eight-byte record prefix, unlike the blkdat view above.
    """
    # CATCHES: bitcoin_block.go decoding from offset 0 without the blkdat prefix
    write_fixture("btc_genesis")

    result = run(['-c', '-d', 'bitcoin_block', '.header | tovalue', 'btc_genesis'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"bits":1247682123,"merkle_root":"32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b00000000000000'
        '00","nonce":1231006505,"previous_block_hash":"00000000000000000000000000000000000000000000000000'
        '0000010000011d","time":2864226106,"version":3652501241}\n'
    )


def test_genesis_coinbase_input(run, write_fixture):
    """The coinbase input has the 0xffffffff outpoint and sequence and a
    77-byte scriptsig.
    """
    # CATCHES: bitcoin_transaction.go coinbase input vout/scriptsig/sequence
    write_fixture("btc_genesis")

    result = run([
        '-c',
        '-d',
        'bitcoin_block',
        '.transactions[0].inputs[0] | tovalue | {vout, scriptsig_size, sequence}',
        'btc_genesis',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"scriptsig_size":77,"sequence":4294967295,"vout":4294967295}\n'


def test_genesis_coinbase_script_pushes(run, write_fixture):
    """The coinbase scriptsig decodes as three pushself operations, the label
    the reference gives the 1-75 byte direct push opcodes.
    """
    # CATCHES: bitcoin_script.go push ops inside a coinbase scriptsig
    write_fixture("btc_genesis")

    result = run([
        '-c',
        '-d',
        'bitcoin_block',
        '[.transactions[0].inputs[0].scriptsig[] | .op]',
        'btc_genesis',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["pushself","pushself","pushself"]\n'


def test_genesis_coinbase_output(run, write_fixture):
    """The coinbase output keeps its 50 BTC value and the raw pay-to-pubkey
    script bytes, which are not valid UTF-8 and appear as JSON escapes.
    """
    # CATCHES: bitcoin_transaction.go coinbase output value and raw script bytes
    write_fixture("btc_genesis")

    result = run([
        '-c',
        '-d',
        'bitcoin_block',
        '.transactions[0].outputs[0] | tovalue',
        'btc_genesis',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"scriptpub":[{"arg":"\\u0004g\\ufffd\\ufffd\\ufffd\\ufffdUH\'\\u0019g\\ufffd\\ufffdq0\\ufffd\\u0010\\\\֨(\\uf'
        'ffd9\\t\\ufffdyb\\ufffd\\ufffd\\u001fa\u07b6I\\ufffd\\ufffd?L\\ufffd8\\ufffd\\ufffdU\\u0004\\ufffd\\u001e\\ufffd\\u0'
        '012\\ufffd\\\\8M\\ufffd\\ufffd\\u000b\\ufffdW\\ufffdLp+k\\ufffd\\u001d_","op":"pushself"},{"op":"checksig"'
        '}],"scriptpub_size":67,"value":5000000000}\n'
    )
