"""MPEG program stream decoding with minimal hand-crafted vectors:
PES packet headers, the DVD sub-picture unit (SPU) behind
private_stream_1 and the multi-packet root array behaviour.

The PES/SPU bytes were assembled with a small bit-writer to
form minimal valid MPEG PS packets; all expectations were
recorded from the reference binary.
"""


def test_pes_packet_video_stream(run, write_fixture):
    """A video stream PES packet decodes its start code, length, the
    MPEG2 extension flags and the trailing payload data field.
    """
    # CATCHES: mpeg/mpeg_pes_packet.go start code, length and extension decoding
    write_fixture("pes_video")

    result = run(['-c', '-d', 'mpeg_pes_packet', 'tovalue', 'pes_video'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"extension":{"additional_copy_info_flag":0,"copyright":0,"data_alignment_indicator":0,"dsm_trick_mode_flag":0,"es_rate_flag":0,"escr_flag":0,"header_data_length":0,"original":0,"pes_crc_flag":0,"pes_ext_flag":0,"priority":0,"pts_dts_flags":0,"scramble_control":0,"skip0":0},"header_data":"","length":5,"prefix":1,"start_code":"video_stream","stream_data":"\\ufffd\\ufffd"}\n'


def test_pes_packet_private_stream_1(run, write_fixture):
    """A private_stream_1 PES packet decodes with the substream id
    byte surfaced and a zero-length header data area.
    """
    # CATCHES: mpeg/mpeg_pes_packet.go private_stream_1 path and substream byte
    write_fixture("pes_ps1")

    result = run([
        '-c',
        '-d',
        'mpeg_pes_packet',
        'tovalue | {start_code, length, substream: .data.substream, extension: {header_data_length: .extension.header_data_length, pts_dts_flags: .extension.pts_dts_flags}}',
        'pes_ps1',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"extension":{"header_data_length":0,"pts_dts_flags":0},"length":37,"start_code":"private_stream1","substream":32}\n'


def test_pes_packet_duplicate_data_error(run, write_fixture):
    """Forcing mpeg_pes_packet on a two packet stream annotates the
    duplicate "data" struct error in the dump but still exits 0.
    """
    # CATCHES: mpeg/mpeg_pes_packet.go trailing data field vs substream name clash
    write_fixture("pes_stream")

    result = run(['-d', 'mpeg_pes_packet', '.', 'pes_stream'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: pes_stream (mpeg_pes_packet)\n    |                                               |                |  error: mpeg_pes_packet: error at position 0x36: "data" already exist in struct \n0x00|00 00 01                                       |...             |  prefix: 0b1 (valid)\n0x00|         bd                                    |   .            |  start_code: "private_stream1" (0xbd)\n0x00|            00 25                              |    .%          |  length: 37\n0x00|                  00 00 00                     |      ...       |  extension{}:\n    |                                               |                |  header_data: raw bits\n0x00|                           20 00 21 00 04 01 00|          .!....|  data{}:\n0x10|00 1b 03 12 34 04 56 78 05 00 00 01 00 00 01 06|....4.Vx........|\n0x20|00 1f 00 00 ff 00 00 00 1b 00 01               |...........     |\n0x20|                                 00 00 01 e0 00|           .....|  gap0: raw bits\n0x30|05 00 00 00 aa bb|                             |......|         |\n'


def test_pes_stream_element_types(run, write_fixture):
    """A program stream that continues past its first PES packet decodes
    into two root elements: the first packet's array and a trailing
    string; only the first packet is walked.
    """
    # CATCHES: mpeg/mpeg_pes.go root packet loop and gap string after first packet
    write_fixture("pes_stream")

    result = run(['-c', '-d', 'mpeg_pes', '[.[] | type]', 'pes_stream'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["array","string"]\n'


def test_pes_stream_subpicture_array_and_gaps(run, write_fixture):
    """In the multi-packet stream the first root element is the
    private_stream_1 sub-picture array, which stays empty, and no
    packet objects with start codes are produced.
    """
    # CATCHES: mpeg/mpeg_pes.go SPU substream reassembly state per packet
    write_fixture("pes_stream")

    result = run(['-c', '-d', 'mpeg_pes', '.[0] | length', 'pes_stream'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '0\n'

    result2 = run([
        '-c',
        '-d',
        'mpeg_pes',
        '[.[] | objects | .start_code]',
        'pes_stream',
    ])
    assert (result2.returncode, result2.err) == (0, "")
    assert result2.out == '[]\n'


def test_pes_two_video_packets_first_only(run, write_fixture):
    """With two back-to-back video PES packets only the first is
    decoded as a packet; the second is left as a gap.
    """
    # CATCHES: mpeg/mpeg_pes.go single packet consumption in the root array
    write_fixture("pes_2video")

    result = run([
        '-c',
        '-d',
        'mpeg_pes',
        '[.[] | objects | .start_code]',
        'pes_2video',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["video_stream"]\n'


def test_mpeg_spu_size_and_dcsqt_offset(run, write_fixture):
    """The DVD sub-picture unit decodes its total size and the offset
    of its display control sequence table.
    """
    # CATCHES: mpeg/mpeg_spu.go SPU header size/dcsqt_offset fields
    write_fixture("mpeg_spu", "spu")

    result = run(['-c', '-d', 'mpeg_spu', 'tovalue | {size, dcsqt_offset}', 'spu'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"dcsqt_offset":4,"size":33}\n'


def test_mpeg_spu_first_dcsq_commands(run, write_fixture):
    """The first display control sequence decodes its delay plus the
    full command chain: SET_COLOR, SET_CONTR, SET_DAREA, SET_DSPXA
    and CMD_END.
    """
    # CATCHES: mpeg/mpeg_spu.go dcsq command dispatch for every SET_* command
    write_fixture("mpeg_spu", "spu")

    result = run([
        '-c',
        '-d',
        'mpeg_spu',
        '.dcsqt[0] | tovalue | {delay, offset, commands}',
        'spu',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"commands":[{"a0":1,"a1":2,"a2":3,"a3":4,"type":"SET_COLOR"},{"a0":5,"a1":6,"a2":7,"a3":8,"type":"SET_CONTR"},{"end_x":1,"end_y":1,"start_x":0,"start_y":0,"type":"SET_DAREA"},{"offset_bottom_field":0,"offset_top_field":31,"type":"SET_DSPXA"},{"type":"CMD_END"}],"delay":256,"offset":27}\n'


def test_mpeg_spu_last_dcsq_self_reference(run, write_fixture):
    """The second display control sequence points at itself, marking it
    as the last one; only its delay and offset decode.
    """
    # CATCHES: mpeg/mpeg_spu.go dcsq termination on self-referencing offset
    write_fixture("mpeg_spu", "spu")

    result = run(['-c', '-d', 'mpeg_spu', '.dcsqt[1] | tovalue', 'spu'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"delay":0,"offset":27}\n'


def test_mpeg_spu_behind_private_stream_1(run, write_fixture):
    """Decoded as a program stream, the SPU is reassembled from the
    private_stream_1 substream buffer and decodes identically.
    """
    # CATCHES: mpeg/mpeg_pes.go SPU reassembly from ps1 substream bytes
    write_fixture("pes_ps1")

    result = run([
        '-c',
        '-d',
        'mpeg_pes',
        '.[0][0] | tovalue | {size, dcsqt_offset}',
        'pes_ps1',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"dcsqt_offset":4,"size":33}\n'

