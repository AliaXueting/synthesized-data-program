"""Behavioural tests for document and serialisation decoders: BSON,
the ZX Spectrum TAP format, PostgreSQL pg_control, negentropy,
APEv2 tags, LevelDB manifests and protobuf.

Vectors come from the reference repository's format test data
(src/format/*/testdata) and the hand-crafted negentropy vector;
every expectation was recorded by running the reference binary.
"""


def test_bson_type_showcase(run, write_fixture):
    """A BSON document covering all element types decodes with each element's
    symbolic type and its name.
    """
    # CATCHES: bson/bson.go element type symbol table
    write_fixture("bson")

    result = run(['-c', '-d', 'bson', '[.elements[] | .type]', 'bson'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '["double","string","document","array","binary","object_id","boolean","datetime","null","regexp",'
        '"javascript","int32","timestamp","int64","decimal128","minkey","maxkey"]\n'
    )

    result = run(['-c', '-d', 'bson', '[.elements[] | .name]', 'bson'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '["dou","str","doc","arr","bin","_id","boo","dat","nul","reg","jav","i32","tim","i64","dec","min"'
        ',"max"]\n'
    )


def test_bson_scalar_elements(run, write_fixture):
    """Scalar elements decode their values: a double, a negative int32 and a
    datetime in milliseconds since the epoch.
    """
    # CATCHES: bson/bson.go double, int32 and datetime value decoding
    write_fixture("bson")

    result = run(['-c', '-d', 'bson', '.elements[0] | tovalue', 'bson'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"name":"dou","type":"double","value":98.765}\n'

    result = run(['-c', '-d', 'bson', '.elements[] | select(.name=="i32") | tovalue', 'bson'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"name":"i32","type":"int32","value":-123}\n'

    result = run(['-c', '-d', 'bson', '.elements[] | select(.name=="dat") | tovalue', 'bson'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"name":"dat","type":"datetime","value":1682642622682}\n'


def test_bson_composite_elements(run, write_fixture):
    """A nested document and array chain down through elements, and the
    decimal128 keeps its raw 16 bytes as escaped text.
    """
    # CATCHES: bson/bson.go nested document/array recursion and decimal128
    write_fixture("bson")

    result = run(['-c', '-d', 'bson', '.elements[] | select(.name=="doc") | tovalue', 'bson'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"name":"doc","type":"document","value":{"elements":[{"length":14,"name":"nstr","type":"string",'
        '"value":"nested string"},{"name":"narr","type":"array","value":{"elements":[{"name":"0","type":"'
        'int32","value":-123}],"size":12,"terminator":0}},{"name":"ndou","type":"double","value":98.765}]'
        ',"size":61,"terminator":0}}\n'
    )

    result = run(['-c', '-d', 'bson', '.elements[] | select(.name=="dec") | tovalue', 'bson'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"name":"dec","type":"decimal128","value":"@\\ufffd\\u0001\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u00'
        '00\\u0000\\u0000\\u0000\\u0000:0"}\n'
    )


def test_tap_blocks(run, write_fixture):
    """A TAP file decodes as blocks; the first is a program header block with
    its flag byte, name and lengths, and the second a raw data block
    without a header.
    """
    # CATCHES: tap/tap.go block typing and header presence
    write_fixture("tap_prog")

    result = run([
        '-c',
        '-d',
        'tap',
        '[.blocks[] | {length, header: .header | tovalue}]',
        'tap_prog',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"header":{"auto_start_line":10,"checksum":1,"data_length":38,"data_type":"program","flag":"sta'
        'ndard_speed_data","program_length":38,"program_name":"fqTestProg"},"length":19},{"header":null,"'
        'length":40}]\n'
    )


def test_tap_program_header(run, write_fixture):
    """The program header block decodes the standard-speed flag, the
    "fqTestProg" name and the auto-start line number 10.
    """
    # CATCHES: tap/tap.go header fields incl. the program name string
    write_fixture("tap_prog")

    result = run(['-c', '-d', 'tap', '.blocks[0].header | tovalue', 'tap_prog'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"auto_start_line":10,"checksum":1,"data_length":38,"data_type":"program","flag":"standard_speed'
        '_data","program_length":38,"program_name":"fqTestProg"}\n'
    )


def test_tap_data_block(run, write_fixture):
    """The data block keeps its flag byte, a checksum of 182 and the raw ZX
    Spectrum bytes including the embedded text.
    """
    # CATCHES: tap/tap.go data flag and checksum fields and byte payload
    write_fixture("tap_prog")

    result = run(['-c', '-d', 'tap', '.blocks[1].data | tovalue | {flag, checksum}', 'tap_prog'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"checksum":182,"flag":"standard_speed_data"}\n'

    result = run(['-c', '-d', 'tap', '.blocks[1].data | tovalue', 'tap_prog'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"bytes":"\\u0000\\n\\u0014\\u0000 \\ufffd\\"fq is the best!\\"\\r\\u0000\\u0014\\n\\u0000\\ufffd10\\u000e\\u00'
        '00\\u0000\\n\\u0000\\u0000\\r","checksum":182,"flag":"standard_speed_data"}\n'
    )


def test_pg_control_toplevel(run, write_fixture):
    """With flavour=postgres10 the control file decodes the system
    identifier, both versions and the DB_IN_PRODUCTION state.
    """
    # CATCHES: postgres/pg_control.go flavour dispatch and state enum
    write_fixture("pg_control10")

    result = run([
        '-c',
        '-d',
        'pg_control',
        '-o',
        'flavour=postgres10',
        '{system_identifier, pg_control_version, catalog_version_no, state}',
        'pg_control10',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"catalog_version_no":201707211,"pg_control_version":1002,"state":"DB_IN_PRODUCTION","system_ide'
        'ntifier":7150673619342883148}\n'
    )


def test_pg_control_checkpoint(run, write_fixture):
    """The checkpoint copy decodes the timeline, next and oldest xid and the
    next oid, and the check_point redo location as a PostgreSQL LSN string.
    """
    # CATCHES: postgres/pg_control.go check_point_copy fields and LSN formatting
    write_fixture("pg_control10")

    result = run([
        '-c',
        '-d',
        'pg_control',
        '-o',
        'flavour=postgres10',
        '.check_point_copy | {this_time_line_id, next_xid, next_oid, oldest_xid}',
        'pg_control10',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"next_oid":24576,"next_xid":30818,"oldest_xid":548,"this_time_line_id":1}\n'

    result = run([
        '-c',
        '-d',
        'pg_control',
        '-o',
        'flavour=postgres10',
        '.check_point | tovalue',
        'pg_control10',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"0/2EDE210"\n'


def test_pg_control_requires_matching_flavour(run, write_fixture):
    """Without a flavour option the control file only decodes the leading
    version field, shown as a hexdump value, since the layout is flavour
    dependent.
    """
    # CATCHES: postgres/pg_control.go flavour-less partial decode
    write_fixture("pg_control10")

    result = run(['-c', '-d', 'pg_control', '.pg_control_version', 'pg_control10'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|\n'
        '0x0|                        ea 03 00 00            |        ....    |.pg_control_version: 1002\n'
    )


def test_negentropy_toplevel(run, write_fixture):
    """A negentropy payload decodes its version byte (v1, 97) and sixteen
    bounds.
    """
    # CATCHES: negentropy/negentropy.go version and bounds framing
    write_fixture("negentropy_small")

    result = run([
        '-c',
        '-d',
        'negentropy',
        '{version, bounds_count: (.bounds | length)}',
        'negentropy_small',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"bounds_count":16,"version":97}\n'


def test_negentropy_bounds(run, write_fixture):
    """Each bound is a fingerprint-mode entry with a timestamp delta and a
    variable-length id prefix; the vector also exposes the two leading
    timestamps.
    """
    # CATCHES: negentropy/negentropy.go bound fields and varint id prefixes
    write_fixture("negentropy_small")

    result = run([
        '-c',
        '-d',
        'negentropy',
        '[.bounds[0:3] | .[] | {timestamp_delta, id_prefix_size, mode}]',
        'negentropy_small',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"id_prefix_size":0,"mode":"fingerprint","timestamp_delta":1726667387},{"id_prefix_size":0,"mod'
        'e":"fingerprint","timestamp_delta":107},{"id_prefix_size":1,"mode":"fingerprint","timestamp_delt'
        'a":1}]\n'
    )

    result = run([
        '-c',
        '-d',
        'negentropy',
        '[.bounds[0:2] | .[] | .timestamp | tovalue]',
        'negentropy_small',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[1726667387,1726667494]\n'

    result = run(['-c', '-d', 'negentropy', '[.bounds[] | .mode] | unique', 'negentropy_small'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["fingerprint"]\n'


def test_apev2_header_and_footer(run, write_fixture):
    """The APEv2 tag decodes both its header and footer with the APETAGEX
    preamble, version 2000 and 142-byte size, differing only in the flags
    word.
    """
    # CATCHES: ape/apev2.go header and footer flag bit decoding
    write_fixture("apev2")

    result = run(['-c', '-d', 'apev2', '.header | tovalue', 'apev2'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"flags":2684354560,"item_count":3,"preamble":"APETAGEX","reserved":"\\u0000\\u0000\\u0000\\u0000\\u0'
        '000\\u0000\\u0000\\u0000","tag_size":142,"version":2000}\n'
    )

    result = run(['-c', '-d', 'apev2', '.footer | tovalue', 'apev2'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '{"flags":2147483648,"item_count":3,"preamble":"APETAGEX","reserved":"\\u0000\\u0000\\u0000\\u0000\\u0'
        '000\\u0000\\u0000\\u0000","tag_size":142,"version":2000}\n'
    )


def test_apev2_items(run, write_fixture):
    """The three tag items decode their keys and values: the mp3gain minmax
    pair and the replaygain gain and peak strings.
    """
    # CATCHES: ape/apev2.go item key/value decoding and size accounting
    write_fixture("apev2")

    result = run(['-c', '-d', 'apev2', '[.tags[] | {key, value}]', 'apev2'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"key":"MP3GAIN_MINMAX","value":"144,210"},{"key":"REPLAYGAIN_TRACK_GAIN","value":"+13.75000 dB'
        '"},{"key":"REPLAYGAIN_TRACK_PEAK","value":"0.084665"}]\n'
    )


def test_leveldb_manifest_records(run, write_fixture):
    """A LevelDB MANIFEST decodes as blocks of records; the record types
    include full records, and the first tag block names the Bytewise
    comparator.
    """
    # CATCHES: leveldb/leveldb_descriptor.go block, record and tag layering
    write_fixture("leveldb_manifest")

    result = run(['-c', '-d', 'leveldb_descriptor', '.blocks | length', 'leveldb_manifest'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '1\n'

    result = run([
        '-c',
        '-d',
        'leveldb_descriptor',
        '[.blocks[].records[] | .header.record_type] | unique',
        'leveldb_manifest',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["full"]\n'

    result = run([
        '-c',
        '-d',
        'leveldb_descriptor',
        '.blocks[0].records[0].data.tags[0] | tovalue',
        'leveldb_manifest',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"key":"comparator","value":{"data":"leveldb.BytewiseComparator","length":26}}\n'


def test_leveldb_version_edit_tags(run, write_fixture):
    """The second record's tags carry the version edit's log number, and the
    second manifest decodes the same Bytewise comparator tag.
    """
    # CATCHES: leveldb/leveldb_descriptor.go version edit tag decoding
    write_fixture("leveldb_manifest")
    write_fixture("leveldb_manifest2")

    result = run([
        '-c',
        '-d',
        'leveldb_descriptor',
        '.blocks[0].records[1].data.tags[0] | tovalue',
        'leveldb_manifest',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"key":"log_number","value":6}\n'

    result = run([
        '-c',
        '-d',
        'leveldb_descriptor',
        '.blocks[0].records[0].data.tags[0] | tovalue',
        'leveldb_manifest2',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"key":"comparator","value":{"data":"leveldb.BytewiseComparator","length":26}}\n'


def test_protobuf_field_stream(run, write_fixture):
    """An unknown message decodes as a flat field stream; this vector has 106
    fields, each with its number and wire type.
    """
    # CATCHES: protobuf/protobuf.go field number and wire type parsing
    write_fixture("protobuf")

    result = run([
        '-c',
        '-d',
        'protobuf',
        '[.fields[0:6][] | {field_number, wire_type}]',
        'protobuf',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"field_number":1,"wire_type":"varint"},{"field_number":2,"wire_type":"varint"},{"field_number"'
        ':3,"wire_type":"varint"},{"field_number":4,"wire_type":"varint"},{"field_number":5,"wire_type":"'
        'varint"},{"field_number":6,"wire_type":"varint"}]\n'
    )

    result = run(['-c', '-d', 'protobuf', '.fields | length', 'protobuf'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '106\n'


def test_protobuf_wire_types(run, write_fixture):
    """The four named wire types -- varint, 64-bit, 32-bit and
    length-delimited -- all appear, alongside the unnamed wire-type values,
    with the recorded field numbers and values around the type switch.
    """
    # CATCHES: protobuf/protobuf.go wire type dispatch incl. 32 and 64 bit
    write_fixture("protobuf")

    result = run(['-c', '-d', 'protobuf', '[.fields[] | .wire_type] | unique', 'protobuf'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["","32bit","64bit","length_delimited","varint"]\n'

    result = run([
        '-c',
        '-d',
        'protobuf',
        '[.fields[10:14][] | {field_number, wire_type, wire_value}]',
        'protobuf',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"field_number":11,"wire_type":"32bit","wire_value":56898},{"field_number":12,"wire_type":"64bi'
        't","wire_value":23616},{"field_number":13,"wire_type":"varint","wire_value":1},{"field_number":1'
        '4,"wire_type":"length_delimited","wire_value":"115"}]\n'
    )


def test_protobuf_varint_values(run, write_fixture):
    """The first four fields are varints carrying 101 through 104, pinning
    the varint byte accumulation.
    """
    # CATCHES: protobuf/protobuf.go varint decoding of multi-field values
    write_fixture("protobuf")

    result = run([
        '-c',
        '-d',
        'protobuf',
        '[.fields[0:4][] | {field_number, wire_type, wire_value}]',
        'protobuf',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == (
        '[{"field_number":1,"wire_type":"varint","wire_value":101},{"field_number":2,"wire_type":"varint"'
        ',"wire_value":102},{"field_number":3,"wire_type":"varint","wire_value":103},{"field_number":4,"w'
        'ire_type":"varint","wire_value":104}]\n'
    )
