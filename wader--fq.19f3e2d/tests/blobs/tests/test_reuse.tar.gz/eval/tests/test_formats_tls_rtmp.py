"""TLS record and handshake decoding (including keylog-decrypted
traffic) and RTMP chunking/AMF0 command decoding.

Vectors: src/format/tls/testdata/testtls.com.http1.1-tls1.2.pcap
(+ .keylog) and src/format/rtmp/testdata/{client_stream,
rtmp_sample.cap}.
"""

import pytest


@pytest.mark.parametrize(
    "query, expected",
    [
        ("[.tcp_connections[0].client.stream.records[].type]", '["handshake","handshake","change_cipher_spec","handshake","application_data","alert"]\n',),
        ("[.tcp_connections[0].server.stream.records[].type]", '["handshake","handshake","handshake","handshake","change_cipher_spec","handshake","application_data","application_data"]\n',),
    ],
    ids=["client", "server"],
)
def test_tls_record_types(run, write_fixture, query, expected):
    """With the keylog option every TLS record of the capture decodes and
    is typed; the client sends six records and the server eight, from
    handshakes through application data to the close alert.
    """
    # CATCHES: tls/tls.go record layer type decoding for both stream directions
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run(["-c", "-o", "keylog=@testtls.com.http1.1-tls1.2.pcap.keylog",
     query, "testtls.com.http1.1-tls1.2.pcap"])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == expected


def test_tls_client_hello(run, write_fixture):
    """The client hello decodes its record/handshake versions, empty
    session id, first cipher suite and null compression.
    """
    # CATCHES: tls/tls.go client_hello handshake decoding incl. version fields
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].client.stream.records[0] | tovalue | {type, version, length, message_type: .message.type, message_version: .message.version, session_id: .message.session_id, cipher_suits_first: .message.cipher_suits[0], compression_methods: .message.compression_methods}',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"cipher_suits_first":"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","compression_methods":["null"],"length":220,"message_type":"client_hello","message_version":"tls1.2","session_id":"","type":"handshake","version":"tls1.0"}\n'


def test_tls_server_name_extension(run, write_fixture):
    """The server_name extension of the client hello carries the SNI
    testtls.com.
    """
    # CATCHES: tls/tls.go server_name extension decoding
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].client.stream.records[0].message.extensions[0] | tovalue',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"length":16,"server_names":[{"length":11,"name":"testtls.com","type":0}],"server_names_length":14,"type":"server_name"}\n'


def test_tls_alpn_extension(run, write_fixture):
    """The application layer protocol negotiation extension offers
    http/1.1.
    """
    # CATCHES: tls/tls.go ALPN extension protocol list decoding
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '[.tcp_connections[0].client.stream.records[0].message.extensions[] | select(.type == "application_layer_protocol_negotiation") | .protocols]',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '[[{"length":8,"name":"http/1.1"}]]\n'


def test_tls_cipher_suite_count(run, write_fixture):
    """The client hello advertises 28 cipher suites."""
    # CATCHES: tls/tls.go cipher suite vector decoding
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].client.stream.records[0].message.cipher_suits | length',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '28\n'


def test_tls_extension_types(run, write_fixture):
    """All seven extensions of the client hello decode and are named,
    from server_name through signature_algorithms.
    """
    # CATCHES: tls/tls.go extension type dispatch and naming
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '[.tcp_connections[0].client.stream.records[0].message.extensions[].type]',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["server_name","ec_point_formats","supported_groups","application_layer_protocol_negotiation","encrypt_then_mac","extended_master_secret","signature_algorithms"]\n'


def test_tls_server_hello(run, write_fixture):
    """The server hello selects tls1.2, echoes a 32 byte session id
    and picks null compression.
    """
    # CATCHES: tls/tls.go server_hello decoding incl. session id echo
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].server.stream.records[0] | tovalue | {type, version, message_type: .message.type, message_version: .message.version, session_id: .message.session_id, cipher_suite: .message.cipher_suite, compression_method: .message.compression_method}',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"cipher_suite":null,"compression_method":"null","message_type":"server_hello","message_version":"tls1.2","session_id":"\\ufffd\\ufffd\\ufffd\\ufffd\\ufffdZ\\u0002\\ufffd\\ufffdFqx9M\\ufffd\\u0015\\ufffdh\\ufffd\uf0547\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd\\ufffd\\u0014","type":"handshake","version":"tls1.2"}\n'


def test_tls_client_finished(run, write_fixture):
    """The client's finished handshake message decodes as a 40 byte
    tls1.2 handshake record.
    """
    # CATCHES: tls/tls.go finished message decoding on the decrypted stream
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].client.stream.records[3] | tovalue | {type, version, length}',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"length":40,"type":"handshake","version":"tls1.2"}\n'


def test_tls_decrypted_request(run, write_fixture):
    """With the keylog option the client's application data record
    decrypts to the full HTTP GET request.
    """
    # CATCHES: tls/tls.go TLS 1.2 record decryption using the keylog secrets
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].client.stream.records[4] | tovalue | {type, version, length, message}',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"length":99,"message":"GET / HTTP/1.1\\r\\nHost: testtls.com\\r\\nUser-Agent: curl/7.87.0\\r\\nAccept: */*\\r\\n\\r\\n","type":"application_data","version":"tls1.2"}\n'


def test_tls_decrypted_response_head(run, write_fixture):
    """The server's response record decrypts to an nginx HTTP/1.1 200
    reply.
    """
    # CATCHES: tls/tls.go server-side record decryption with keylog
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].server.stream.records[6].message | tostring | .[0:80]',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '"HTTP/1.1 200 OK\\r\\nServer: nginx/1.22.1\\r\\nContent-Type: text/html; charset=UTF-8\\r\\nT"\n'


def test_tls_decrypted_response_length(run, write_fixture):
    """The decrypted server response message is 16384 bytes long."""
    # CATCHES: tls/tls.go full-size decrypted application data handling
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].server.stream.records[6].message | length',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '16384\n'


def test_tls_close_notify_alert(run, write_fixture):
    """The connection ends with a tls1.2 warning close_notify alert on
    the client side.
    """
    # CATCHES: tls/tls.go alert record decoding
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")
    write_fixture("tls_keylog", "testtls.com.http1.1-tls1.2.pcap.keylog")

    result = run([
        '-c',
        '-o',
        'keylog=@testtls.com.http1.1-tls1.2.pcap.keylog',
        '.tcp_connections[0].client.stream.records[5] | tovalue | {type, version, message}',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"message":{"description":"close_notify","level":"warning"},"type":"alert","version":"tls1.2"}\n'


def test_tls_without_keylog_message_stays_null(run, write_fixture):
    """Without the keylog option the application data record still
    decodes its header but the message stays null.
    """
    # CATCHES: tls/tls.go ciphertext records decode structure but no plaintext
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")

    result = run([
        '-c',
        '.tcp_connections[0].client.stream.records[4] | tovalue | {type, version, length}',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"length":99,"type":"application_data","version":"tls1.2"}\n'

    result2 = run([
        '-c',
        '.tcp_connections[0].client.stream.records[4].message',
        'testtls.com.http1.1-tls1.2.pcap',
    ])
    assert (result2.returncode, result2.err) == (0, "")
    assert result2.out == 'null\n'


def test_tls_direct_decode_of_pcap(run, write_fixture):
    """Forcing -d tls on a raw pcap file misprobes it as ssl_v2 with a
    gap, rather than decoding packet data.
    """
    # CATCHES: tls/tls.go probe/decode behaviour on non-TLS input
    write_fixture("tls_pcap", "testtls.com.http1.1-tls1.2.pcap")

    result = run(['-c', '-d', 'tls', 'keys', 'testtls.com.http1.1-tls1.2.pcap'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["ssl_v2","gap0"]\n'


def test_rtmp_message_types(run, write_fixture):
    """The first eight RTMP messages of the client stream are the
    connect handshake exchange: command, window ack, user control
    and more command messages.
    """
    # CATCHES: rtmp/rtmp.go message header decoding and type id naming
    write_fixture("rtmp_client", "client_stream")

    result = run([
        '-c',
        '-d',
        'rtmp',
        '[.messages[0:8][].message_type_id]',
        'client_stream',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["command_message","window_acknowledgement_size","user_control_message","command_message","user_control_message","command_message","command_message","command_message"]\n'


def test_rtmp_connect_command(run, write_fixture):
    """The connect command message decodes its AMF0 values: command
    name, transaction id, the app and the flash version.
    """
    # CATCHES: rtmp/amf0.go AMF0 command values inside the connect message
    write_fixture("rtmp_client", "client_stream")

    result = run([
        '-c',
        '-d',
        'rtmp',
        '.messages[0] | tovalue | {message_type_id, command_name: .command_name.value, transaction_id: .transaction_id.value, app: .command_object.value[0].value.value, flashVer: .command_object.value[1].value.value}',
        'client_stream',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"app":"ondemand/content-vod-storage1/","command_name":"connect","flashVer":"LNX 10,0,32,18","message_type_id":"command_message","transaction_id":1}\n'


def test_rtmp_connect_string_arguments(run, write_fixture):
    """The string-valued AMF0 arguments of the connect command are the
    viewer swf URL and the stream path.
    """
    # CATCHES: rtmp/amf0.go typed value array walking in command arguments
    write_fixture("rtmp_client", "client_stream")

    result = run([
        '-c',
        '-d',
        'rtmp',
        '[.messages[0].arguments[0].value[] | select(.value.type? == "string") | .value.value]',
        'client_stream',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["http://cdn1.ustream.tv/swf/4/viewer.182.swf","0/1/1/1514/1514287/1_192254_1514287"]\n'


def test_rtmp_window_acknowledgement_size(run, write_fixture):
    """The window acknowledgement size message decodes a 1250000 byte
    window on the client stream.
    """
    # CATCHES: rtmp/rtmp.go acknowledgement message decoding
    write_fixture("rtmp_client", "client_stream")

    result = run(['-c', '-d', 'rtmp', '.messages[1] | tovalue', 'client_stream'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"message_stream_id":0,"message_type_id":"window_acknowledgement_size","window_size":1250000}\n'


def test_rtmp_user_control_message(run, write_fixture):
    """The third message is a user control ping response with its
    timestamp.
    """
    # CATCHES: rtmp/rtmp.go user control message event decoding
    write_fixture("rtmp_client", "client_stream")

    result = run(['-c', '-d', 'rtmp', '.messages[2] | tovalue', 'client_stream'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"message_stream_id":0,"message_type_id":"user_control_message","timestamp":397138595,"type":"ping_response"}\n'


def test_rtmp_handshake_version(run, write_fixture):
    """The RTMP handshake C0 byte decodes as protocol version 3."""
    # CATCHES: rtmp/rtmp.go handshake C0 version decoding
    write_fixture("rtmp_client", "client_stream")

    result = run(['-c', '-d', 'rtmp', '.handshake.s0 | tovalue', 'client_stream'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"version":3}\n'


def test_rtmp_chunk_count(run, write_fixture):
    """The client stream reassembles into 102 chunks."""
    # CATCHES: rtmp/rtmp.go chunk stream assembly across the whole capture
    write_fixture("rtmp_client", "client_stream")

    result = run(['-c', '-d', 'rtmp', '.chunks | length', 'client_stream'])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '102\n'


def test_rtmp_inside_pcap(run, write_fixture):
    """RTMP inside a pcap capture is detected on the TCP connection and
    its window acknowledgement size message decodes.
    """
    # CATCHES: rtmp/rtmp.go decode triggered from pcap TCP reassembly
    write_fixture("rtmp_cap", "rtmp_sample.cap")

    result = run([
        '-c',
        '.tcp_connections[0].client.stream.messages[1] | tovalue',
        'rtmp_sample.cap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '{"message_stream_id":0,"message_type_id":"window_acknowledgement_size","window_size":1310720}\n'


def test_rtmp_pcap_message_types(run, write_fixture):
    """The first five RTMP messages in the pcap capture are a command,
    window acknowledgement, two more commands and a user control
    message.
    """
    # CATCHES: rtmp/rtmp.go message stream decoding behind pcap reassembly
    write_fixture("rtmp_cap", "rtmp_sample.cap")

    result = run([
        '-c',
        '[.tcp_connections[0].client.stream.messages[0:5][].message_type_id]',
        'rtmp_sample.cap',
    ])
    assert (result.returncode, result.err) == (0, "")
    assert result.out == '["command_message","window_acknowledgement_size","command_message","command_message","user_control_message"]\n'

