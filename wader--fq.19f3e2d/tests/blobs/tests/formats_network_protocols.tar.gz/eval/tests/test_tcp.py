"""TCP segment tests: header fields and port symbols, flag bits including
NS/reserved, the option list (mss, winscale, timestamp, sack), payload
handling and the verbose display of options.

Every expected value below was recorded by running the reference fq binary.
"""

import struct

from conftest import fq_json, run_ok, tcp

# Exact `.options | dv` display of a crafted SYN whose option list is
# nop,nop,mss,sack_permitted,winscale,timestamp + three end paddings.
OPTIONS_DISPLAY = """\
    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.options[0:9]: 0x14-0x2c (24)
    |                                               |                |  [0]{}: option 0x14-0x15 (1)
0x10|            01                                 |    .           |    kind: "nop" (1) (No operation) 0x14-0x15 (1)
    |                                               |                |  [1]{}: option 0x15-0x16 (1)
0x10|               01                              |     .          |    kind: "nop" (1) (No operation) 0x15-0x16 (1)
    |                                               |                |  [2]{}: option 0x16-0x1a (4)
0x10|                  02                           |      .         |    kind: "mss" (2) (Maximum segment size) 0x16-0x17 (1)
0x10|                     04                        |       .        |    length: 4 0x17-0x18 (1)
0x10|                        05 b4                  |        ..      |    size: 1460 0x18-0x1a (2)
    |                                               |                |  [3]{}: option 0x1a-0x1c (2)
0x10|                              04               |          .     |    kind: "sack_permitted" (4) (Selective Acknowledgement permitted) 0x1a-0x1b (1)
0x10|                                 02            |           .    |    length: 2 0x1b-0x1c (1)
    |                                               |                |  [4]{}: option 0x1c-0x1f (3)
0x10|                                    03         |            .   |    kind: "winscale" (3) (Window scale) 0x1c-0x1d (1)
0x10|                                       03      |             .  |    length: 3 0x1d-0x1e (1)
0x10|                                          07   |              . |    shift: 7 0x1e-0x1f (1)
    |                                               |                |  [5]{}: option 0x1f-0x29 (10)
0x10|                                             08|               .|    kind: "timestamp" (8) (Timestamp and echo of previous timestamp) 0x1f-0x20 (1)
0x20|0a                                             |.               |    length: 10 0x20-0x21 (1)
0x20|   11 22 33 44                                 | ."3D           |    value: 287454020 0x21-0x25 (4)
0x20|               55 66 77 88                     |     Ufw.       |    echo_reply: 1432778632 0x25-0x29 (4)
    |                                               |                |  [6]{}: option 0x29-0x2a (1)
0x20|                           00                  |         .      |    kind: "end" (0) (End of options list) 0x29-0x2a (1)
    |                                               |                |  [7]{}: option 0x2a-0x2b (1)
0x20|                              00               |          .     |    kind: "end" (0) (End of options list) 0x2a-0x2b (1)
    |                                               |                |  [8]{}: option 0x2b-0x2c (1)
0x20|                                 00|           |           .|   |    kind: "end" (0) (End of options list) 0x2b-0x2c (1)"""

# Exact `dv` of a minimal crafted SYN segment (ports 1/2, window 8192).
HEADER_DISPLAY = """\
    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: <stdin> (tcp_segment) 0x0-0x14 (20)
0x00|00 01                                          |..              |  source_port: "tcpmux" (1) (TCP Port Service Multiplexer) 0x0-0x2 (2)
0x00|      00 02                                    |  ..            |  destination_port: "compressnet" (2) (Management Utility) 0x2-0x4 (2)
0x00|            00 00 00 01                        |    ....        |  sequence_number: 1 0x4-0x8 (4)
0x00|                        00 00 00 00            |        ....    |  acknowledgment_number: 0 0x8-0xc (4)
0x00|                                    50         |            P   |  data_offset: 5 0xc-0xc.4 (0.4)
0x00|                                    50         |            P   |  reserved: 0 0xc.4-0xc.7 (0.3)
0x00|                                    50         |            P   |  ns: false 0xc.7-0xd (0.1)
0x00|                                       02      |             .  |  cwr: false 0xd-0xd.1 (0.1)
0x00|                                       02      |             .  |  ece: false 0xd.1-0xd.2 (0.1)
0x00|                                       02      |             .  |  urg: false 0xd.2-0xd.3 (0.1)
0x00|                                       02      |             .  |  ack: false 0xd.3-0xd.4 (0.1)
0x00|                                       02      |             .  |  psh: false 0xd.4-0xd.5 (0.1)
0x00|                                       02      |             .  |  rst: false 0xd.5-0xd.6 (0.1)
0x00|                                       02      |             .  |  syn: true 0xd.6-0xd.7 (0.1)
0x00|                                       02      |             .  |  fin: false 0xd.7-0xe (0.1)
0x00|                                          20 00|               .|  window_size: 8192 0xe-0x10 (2)
0x10|00 00                                          |..              |  checksum: 0x0 0x10-0x12 (2)
0x10|      00 00|                                   |  ..|           |  urgent_pointer: 0 0x12-0x14 (2)
    |                                               |                |  payload: raw bits 0x14-0x14 (0)"""


def _opts():
    opts = bytes([1, 1, 2, 4, 0x05, 0xB4, 4, 2, 3, 3, 7, 8, 10]) \
        + b"\x11\x22\x33\x44\x55\x66\x77\x88"
    while len(opts) % 4:
        opts += b"\x00"
    return opts


def test_tcp_segment_fixture(tmp_path):
    """The checked-in SYN segment: data offset 11, mss/winscale/timestamp/
    sack_permitted options, source port 50981 to 'https'.

    CATCHES: the tcp_segment field set on a real SYN including the option
    kind symbols and the timestamp value/echo_reply pair.
    """
    got = fq_json(tmp_path, ["-d", "tcp_segment", "-cV", ".",
                             "inet/tcp_segment"])
    assert got == {
        "ack": False, "acknowledgment_number": 0, "checksum": 17892,
        "cwr": False, "data_offset": 11, "destination_port": "https",
        "ece": False, "fin": False, "ns": False,
        "options": [{"kind": "mss", "length": 4, "size": 1460},
                    {"kind": "nop"},
                    {"kind": "winscale", "length": 3, "shift": 5},
                    {"kind": "nop"}, {"kind": "nop"},
                    {"echo_reply": 0, "kind": "timestamp", "length": 10,
                     "value": 1261080865},
                    {"kind": "sack_permitted", "length": 2},
                    {"kind": "end"}, {"kind": "end"}],
        "payload": "", "psh": False, "reserved": 0, "rst": False,
        "sequence_number": 734932618, "source_port": 50981, "syn": True,
        "urg": False, "urgent_pointer": 0, "window_size": 65535,
    }


def test_tcp_sack_fixture(tmp_path):
    """The checked-in ACK with a SACK option: one block with the recorded
    left/right edges.

    CATCHES: SACK option block parsing (left_edge/right_edge pairs).
    """
    got = fq_json(tmp_path, ["-d", "tcp_segment", "-cV", ".",
                             "inet/tcp_segment_sack"])
    assert got == {
        "ack": True, "acknowledgment_number": 2747581568, "checksum": 13494,
        "cwr": False, "data_offset": 11, "destination_port": "http",
        "ece": False, "fin": False, "ns": False,
        "options": [{"kind": "nop"}, {"kind": "nop"},
                    {"echo_reply": 2375917095, "kind": "timestamp",
                     "length": 10, "value": 1545583},
                    {"kind": "nop"}, {"kind": "nop"},
                    {"blocks": [{"left_edge": 2747583016,
                                 "right_edge": 2747584464}],
                     "kind": "sack", "length": 10}],
        "payload": "", "psh": False, "reserved": 0, "rst": False,
        "sequence_number": 3851698039, "source_port": 58816, "syn": False,
        "urg": False, "urgent_pointer": 0, "window_size": 318,
    }


def test_tcp_crafted_options_and_flags(tmp_path):
    """A crafted SYN with the common option set: data offset 11, every flag
    false except syn, and the option array decoded in order; a second
    segment with a 2-block SACK; FIN+RST together; and the NS bit plus the
    3 reserved bits in the data-offset byte.

    CATCHES: option order and fields for nop/mss/sack_permitted/winscale/
    timestamp/sack, multi-block SACK edges, simultaneous FIN|RST, and the
    ns/reserved bit split of byte 12.
    """
    got = fq_json(tmp_path, ["-d", "tcp_segment", "-cV",
                             "{source_port, destination_port, data_offset, flags: {ns, cwr, ece, urg, ack, psh, rst, syn, fin}, window_size, sequence_number, acknowledgment_number, urgent, options}",
                             "-"], stdin=tcp(1234, 80, flags=0x02, options=_opts()))
    assert got == {
        "acknowledgment_number": 0, "data_offset": 11,
        "destination_port": "http",
        "flags": {"ack": False, "cwr": False, "ece": False, "fin": False,
                  "ns": False, "psh": False, "rst": False, "syn": True,
                  "urg": False},
        "options": [{"kind": "nop"}, {"kind": "nop"},
                    {"kind": "mss", "length": 4, "size": 1460},
                    {"kind": "sack_permitted", "length": 2},
                    {"kind": "winscale", "length": 3, "shift": 7},
                    {"echo_reply": 1432778632, "kind": "timestamp",
                     "length": 10, "value": 287454020},
                    {"kind": "end"}, {"kind": "end"}, {"kind": "end"}],
        "sequence_number": 1, "source_port": 1234, "urgent": None,
        "window_size": 8192,
    }
    sack = bytes([5, 18]) + struct.pack(">IIII", 1000, 2000, 3000, 4000)
    while len(sack) % 4:
        sack += b"\x00"
    got = fq_json(tmp_path, ["-d", "tcp_segment", "-cV", ".options", "-"],
                  stdin=tcp(1, 2, flags=0x10, options=sack))
    assert got == [{"blocks": [{"left_edge": 1000, "right_edge": 2000},
                               {"left_edge": 3000, "right_edge": 4000}],
                    "kind": "sack", "length": 18},
                   {"kind": "end"}, {"kind": "end"}]
    finrst = fq_json(tmp_path, ["-d", "tcp_segment", "-cV",
                                "{fin, rst, syn, ack}", "-"],
                     stdin=tcp(1, 2, flags=0x05))
    assert finrst == {"ack": False, "fin": True, "rst": True, "syn": False}
    ns = struct.pack(">HHIIBBHHH", 1, 2, 1, 0, (5 << 4) | 1, 0x02, 8192, 0, 0)
    got = fq_json(tmp_path, ["-d", "tcp_segment", "-cV",
                             "{ns, cwr, reserved, data_offset}", "-"], stdin=ns)
    assert got == {"cwr": False, "data_offset": 5, "ns": True, "reserved": 0}
    res = struct.pack(">HHIIBBHHH", 1, 2, 1, 0, (5 << 4) | 0x0A, 0x02, 8192, 0, 0)
    got = fq_json(tmp_path, ["-d", "tcp_segment", "-cV",
                             "{ns, cwr, ece, reserved, data_offset}", "-"],
                  stdin=res)
    assert got == {"cwr": False, "data_offset": 5, "ece": False, "ns": False,
                   "reserved": 5}


def test_tcp_payload_segment(tmp_path):
    """A PSH+ACK segment from 'http' to a numeric port carries its payload
    as a plain string.

    CATCHES: flag combinations from the second flag byte and payload string
    extraction.
    """
    got = fq_json(tmp_path, ["-d", "tcp_segment", "-cV",
                             "{source_port, destination_port, sequence_number, acknowledgment_number, ack, syn, fin, psh, rst, urg, payload}", "-"],
                  stdin=tcp(80, 1234, seq=100, ack=200, flags=0x18,
                            payload=b"GET / HTTP/1.1\r\n\r\n"))
    assert got == {"ack": True, "acknowledgment_number": 200,
                   "destination_port": 1234, "fin": False,
                   "payload": "GET / HTTP/1.1\r\n\r\n", "psh": True,
                   "rst": False, "sequence_number": 100,
                   "source_port": "http", "syn": False, "urg": False}


def test_tcp_options_display(tmp_path):
    """The verbose display of the crafted option list shows each option
    struct with kind name, description and bit ranges.

    CATCHES: dv display of tcp options — kind symbols with their long
    descriptions and per-field bit ranges.
    """
    disp = run_ok(tmp_path, ["-d", "tcp_segment", ".options | dv", "-"],
                  stdin=tcp(1234, 80, flags=0x02, options=_opts()))
    assert disp == OPTIONS_DISPLAY


def test_tcp_header_display(tmp_path):
    """The verbose display of a minimal SYN segment shows the port symbols
    with descriptions and the bit-level split of the data offset byte.

    CATCHES: dv display of the tcp header — port symbol annotations and the
    4+3+1 bit split of byte 12 followed by the eight flag bits.
    """
    disp = run_ok(tmp_path, ["-d", "tcp_segment", ". | dv", "-"],
                  stdin=tcp(1, 2, flags=0x02))
    assert disp == HEADER_DISPLAY
