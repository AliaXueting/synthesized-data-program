"""Classic pcap file tests: header magic/endian handling, per-packet record
fields, link-layer dispatch, incl_len/orig_len edge cases, IPv4 fragment and
TCP stream reassembly, and the flowsdecoder connection list.

Every expected value below was recorded by running the reference fq binary.
"""

import struct

import pytest
from conftest import (dns_name, eth, fq_json, ipv4, make_pcap, run_ok,
                      run_on, udp)

RAW = "pcap/link_type_raw.pcap"
NS = "pcap/ns.pcap"


def test_file_header_and_first_packet(tmp_path):
    """A little-endian pcap with LINKTYPE_RAW decodes the header and each
    packet record, and the packet is dispatched straight to ipv4_packet.

    CATCHES: the whole pcap header field set (magic symbol, network symbol,
    snaplen) plus packet record fields and raw-IP link dispatch.
    """
    header = fq_json(tmp_path, ["-d", "pcap", "-cV",
                                "{header, packets: [.packets[] | {ts_sec, ts_usec, incl_len, orig_len, packet: (.packet|format)}], ipv4_reassembled, tcp_connections}",
                                RAW])
    assert header == {
        "header": {"magic": "little_endian", "network": "raw", "sigfigs": 0,
                   "snaplen": 65535, "thiszone": 0, "version_major": 2,
                   "version_minor": 4},
        "packets": [{"incl_len": 62, "orig_len": 62, "packet": "ipv4_packet",
                     "ts_sec": 1634934003, "ts_usec": 217107}],
        "ipv4_reassembled": [],
        "tcp_connections": [],
    }
    first = fq_json(tmp_path, ["-d", "pcap", "-cV",
                               ".packets[0].packet | {version, ihl, protocol, source_ip, destination_ip, payload: (.payload|format)}",
                               RAW])
    assert first == {"destination_ip": "10.215.173.2", "ihl": 5,
                     "payload": "udp_datagram", "protocol": "udp",
                     "source_ip": "10.215.173.1", "version": 4}


def test_nanosecond_magic_uses_nsec_field_names(tmp_path):
    """The 0x4D3CB2A1 magic is reported as little_endian_ns and renames the
    packet timestamp field to ts_nsec (ts_usec is absent, i.e. null).

    CATCHES: the ns magic variant detection and the ts_usec -> ts_nsec field
    rename inside packet records.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{header, p0: {ts_sec: .packets[0].ts_sec, ts_nsec: .packets[0].ts_nsec, ts_usec: .packets[0].ts_usec, frame: (.packets[0].packet|format), payload_chain: (.packets[0].packet.payload.payload.payload|format)}}",
                             NS])
    assert got == {
        "header": {"magic": "little_endian_ns", "network": "ethernet",
                   "sigfigs": 0, "snaplen": 65535, "thiszone": 0,
                   "version_major": 2, "version_minor": 4},
        "p0": {"frame": "ether8023_frame", "payload_chain": None,
               "ts_nsec": 575718995, "ts_sec": 1508409869, "ts_usec": None},
    }
    chain = fq_json(tmp_path, ["-d", "pcap", "-cV",
                               ".packets[0].packet | {ether: format, l3: (.payload|format), l4: (.payload.payload|format), l4ports: (.payload.payload|{source_port, destination_port}), l7: (.payload.payload.payload|format)}",
                               NS])
    assert chain == {"ether": "ether8023_frame", "l3": "ipv4_packet",
                     "l4": "udp_datagram",
                     "l4ports": {"destination_port": 2055, "source_port": 33092},
                     "l7": None}


@pytest.mark.parametrize("endian,magic,expected_magic", [
    ("<", None, "little_endian"),
    (">", None, "big_endian"),
    ("<", 0x4D3CB2A1, "little_endian_ns"),
    (">", 0xA1B23C4D, "big_endian_ns"),
])
def test_magic_value_selects_file_endianness(tmp_path, endian, magic, expected_magic):
    """The four magic values pick the byte order used for every other header
    and record field (the magic itself is always stored big-endian).

    CATCHES: magic-to-endianness mapping for all four pcap variants; a wrong
    swap makes version_major/network garbage.
    """
    frame = eth("aa:bb:cc:dd:ee:ff", "11:22:33:44:55:66", 0x0800,
                ipv4("1.2.3.4", "5.6.7.8", 17, udp(1, 2, b"hi")))
    data = make_pcap([frame], endian=endian, magic=magic)
    header = fq_json(tmp_path, ["-d", "pcap", "-cV", ".header", "-"], stdin=data)
    assert header == {"magic": expected_magic, "network": "ethernet",
                      "sigfigs": 0, "snaplen": 65535, "thiszone": 0,
                      "version_major": 2, "version_minor": 4}
    # The ns variant must also rename the record timestamp field.
    if magic in (0x4D3CB2A1, 0xA1B23C4D):
        fields = fq_json(tmp_path, ["-d", "pcap", "-cV",
                                    "{ts_nsec: .packets[0].ts_nsec, ts_usec: .packets[0].ts_usec}",
                                    "-"], stdin=data)
        assert fields == {"ts_nsec": 0, "ts_usec": None}


def test_incl_len_greater_than_orig_len_is_a_gap(tmp_path):
    """A packet whose incl_len exceeds orig_len aborts the packet decode: the
    frame bytes become a gap0 field and the record keeps only its lengths.

    CATCHES: the incl_len > orig_len validation error path; the packet struct
    must not decode its payload and the file still decodes around it.
    """
    frame = eth("aa:bb:cc:dd:ee:ff", "11:22:33:44:55:66", 0x0800,
                ipv4("1.2.3.4", "5.6.7.8", 17, udp(1, 2, b"hi")))
    data = make_pcap([frame], orig_lens=[4])
    got = fq_json(tmp_path, ["-d", "pcap", "-cV", ".", "-"], stdin=data)
    # The frame bytes become gap0; fq's JSON encoder turns bytes that are
    # not valid UTF-8 into U+FFFD, exactly like decoding with 'replace'.
    assert got == {
        "gap0": frame.decode("utf-8", "replace"),
        "header": {"magic": "little_endian", "network": "ethernet",
                   "sigfigs": 0, "snaplen": 65535, "thiszone": 0,
                   "version_major": 2, "version_minor": 4},
        "packets": [{"incl_len": 44, "orig_len": 4, "ts_sec": 1, "ts_usec": 0}],
    }
    assert len(got["gap0"]) == 44
    # In display mode the packet carries an error annotation naming the
    # broken field values; the raw frame is shown as gap0 raw bits.
    disp = run_ok(tmp_path, ["-d", "pcap", ". | dv", "-"], stdin=data)
    lines = disp.splitlines()
    assert lines[0] == ("    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
                        "|0123456789abcdef|.{}: <stdin> (pcap) 0x0-0x54 (84)")
    assert lines[1] == ("    |                                               "
                        "|                |  error: pcap: error at position 0x28:"
                        " incl_len 44 > orig_len 4")
    assert "gap0: raw bits 0x28-0x54 (44)" in disp


def test_truncated_packet_and_bad_magic(tmp_path):
    """A record whose incl_len runs past EOF still yields ts/incl/orig fields,
    and forcing -d pcap on a non-pcap file yields an empty header plus gap0.

    CATCHES: EOF-clamped packet records keep their four length/timestamp
    fields; forced decode of wrong magic does not fabricate header values.
    """
    frame = eth("aa:bb:cc:dd:ee:ff", "11:22:33:44:55:66", 0x0800,
                ipv4("1.2.3.4", "5.6.7.8", 17, udp(1, 2, b"hi")))
    truncated = make_pcap([])[:24] + struct.pack("<IIII", 1, 0, 100, 100) + frame[:20]
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{np: (.packets|length), p0: (.packets[0]|keys)}", "-"],
                  stdin=truncated)
    assert got == {"np": 1, "p0": ["ts_sec", "ts_usec", "incl_len", "orig_len"]}

    bad = fq_json(tmp_path, ["-d", "pcap", "-cV", ".",
                             "-"], stdin=b"\x00\x01\x02\x03" + b"\x00" * 24)
    assert bad == {"gap0": "\x00\x01\x02\x03" + "\x00" * 24, "header": {}}


def test_ipv4_fragment_reassembly(tmp_path):
    """ipv4frags.pcap: two ICMP fragments with the same identification are
    reassembled into one ipv4_reassembled entry while a third unfragmented
    packet is not; per-packet fragment flags are still visible.

    CATCHES: the flowsdecoder IPv4 fragment reassembly (id matching, offset
    accumulation) and the reassembled packet's inner icmp payload dispatch.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{n: (.packets|length), reasm: [.ipv4_reassembled[] | {version, ihl, total_length, identification, protocol, source_ip, destination_ip, payload: (.payload|format), icmp: (.payload|{type, code}?)}], nconn: (.tcp_connections|length)}",
                             "pcap/ipv4frags.pcap"])
    assert got == {
        "n": 3, "nconn": 0,
        "reasm": [{"destination_ip": "2.1.1.1",
                   "icmp": {"code": 0, "type": "echo_request"},
                   "identification": 46544, "ihl": 5, "payload": "icmp",
                   "protocol": "icmp", "source_ip": "2.1.1.2",
                   "total_length": 1428, "version": 4}],
    }
    pkts = fq_json(tmp_path, ["-d", "pcap", "-cV",
                              "[.packets[] | {mf: .packet.payload.more_fragments, off: .packet.payload.fragment_offset, id: .packet.payload.identification}]",
                              "pcap/ipv4frags.pcap"])
    assert pkts == [{"id": 46544, "mf": True, "off": 0},
                    {"id": 46544, "mf": False, "off": 122},
                    {"id": 33782, "mf": False, "off": 0}]


def test_tcp_reassembly_and_stream(tmp_path):
    """tcp-ipv4frag.pcap: IP fragments carrying TCP are reassembled first,
    then the TCP segments are joined into per-direction streams; the client
    stream starts with a real HTTP request line.

    CATCHES: two-stage reassembly (IP fragments -> TCP segments -> stream
    buffers) and has_start/has_end flow bookkeeping.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{reasm: [.ipv4_reassembled[] | {total_length, identification, protocol, source_ip, destination_ip, payload: (.payload|format)}], conns: [.tcp_connections[] | {client: {ip: .client.ip, port: .client.port, has_start: .client.has_start, has_end: .client.has_end, skipped_bytes: .client.skipped_bytes, len: (.client.stream|tobytes|length), fmt: (.client.stream|format)}, server: {ip: .server.ip, port: .server.port, len: (.server.stream|tobytes|length), fmt: (.server.stream|format)}}]}",
                             "pcap/tcp-ipv4frag.pcap"])
    assert got == {
        "reasm": [
            {"destination_ip": "192.168.69.1", "identification": 62939,
             "payload": "tcp_segment", "protocol": "tcp",
             "source_ip": "192.168.69.2", "total_length": 497},
            {"destination_ip": "192.168.69.2", "identification": 49092,
             "payload": "tcp_segment", "protocol": "tcp",
             "source_ip": "192.168.69.1", "total_length": 454}],
        "conns": [{"client": {"fmt": None, "has_end": True, "has_start": True,
                              "ip": "192.168.69.2", "len": 445, "port": 34059,
                              "skipped_bytes": 0},
                   "server": {"fmt": None, "ip": "192.168.69.1", "len": 402,
                              "port": "http"}}],
    }
    req = run_ok(tmp_path, ["-r", "-d", "pcap", "-cV",
                            ".tcp_connections[0].client.stream | tobytes | tostring[0:80]",
                            "pcap/tcp-ipv4frag.pcap"])
    assert req == "GET /test/ethereal.html HTTP/1.1\r\nHost: cerberus\r\nUser-Agent: Mozilla/5.0 (X11; "


def test_http_gzip_capture_streams(tmp_path):
    """http_gzip.cap: 10 packets, one HTTP connection; the server-side
    reassembled stream begins with the recorded HTTP/1.1 response headers.

    CATCHES: TCP stream reassembly direction assignment (client port is
    numeric, server port is the http symbol) and stream byte counts.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{n: (.packets|length), conns: [.tcp_connections[] | {cl: {ip: .client.ip, port: .client.port, len: (.client.stream|tobytes|length)}, sv: {ip: .server.ip, port: .server.port, len: (.server.stream|tobytes|length)}}]}",
                             "pcap/http_gzip.cap"])
    assert got == {
        "n": 10,
        "conns": [{"cl": {"ip": "192.168.69.2", "len": 445, "port": 34059},
                   "sv": {"ip": "192.168.69.1", "len": 402, "port": "http"}}],
    }
    resp = run_ok(tmp_path, ["-r", "-d", "pcap", "-cV",
                             ".tcp_connections[0].server.stream | tobytes | tostring[0:200]",
                             "pcap/http_gzip.cap"])
    assert resp == ('HTTP/1.1 200 OK\r\nDate: Fri, 29 Oct 2004 05:21:00 GMT\r\n'
                    'Server: Apache/2.0.50 (Fedora)\r\n'
                    'Last-Modified: Fri, 29 Oct 2004 05:20:21 GMT\r\n'
                    'ETag: "126e1f-6d-371b2f40"\r\nAccept-Ranges: bytes\r\n'
                    'Vary: Accept-Encod')


def test_flows_without_synack(tmp_path):
    """flow_missing_synack.pcap: 49 packets produce 8 connections that all
    lack a SYN+SYN/ACK start; only one server side has seen a FIN.

    CATCHES: connection tracking for captures that miss the handshake
    (has_start false everywhere) and per-direction byte accounting.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{n: (.packets|length), conns: [.tcp_connections[] | {client: {ip: .client.ip, port: .client.port, has_start: .client.has_start, has_end: .client.has_end, skipped_bytes: .client.skipped_bytes, len: (.client.stream|tobytes|length), fmt: (.client.stream|format)}, server: {ip: .server.ip, port: .server.port, has_start: .server.has_start, has_end: .server.has_end, skipped_bytes: .server.skipped_bytes, len: (.server.stream|tobytes|length), fmt: (.server.stream|format)}}], reasm: (.ipv4_reassembled|length)}",
                             "inet/flow_missing_synack.pcap"])
    assert got["n"] == 49
    assert got["reasm"] == 0
    assert len(got["conns"]) == 8
    for c in got["conns"]:
        assert c["client"]["ip"] == "192.168.1.4"
        assert c["server"]["ip"] == "192.168.1.3"
        assert c["server"]["port"] == "https"
        assert c["client"]["has_start"] is False
        assert c["server"]["has_start"] is False
        assert c["client"]["has_end"] is False
        assert c["client"]["fmt"] is None
        assert c["server"]["fmt"] is None
    assert [c["server"]["has_end"] for c in got["conns"]] == [
        False, False, False, False, False, True, False, False]
    assert [c["server"]["len"] for c in got["conns"]] == [
        1068, 1068, 1341, 440, 440, 11636, 726, 1268]
    assert [(c["client"]["port"], c["client"]["len"]) for c in got["conns"]] == [
        (2061, 376), (2068, 376), (2070, 686), (2071, 736), (2072, 766),
        (2073, 766), (2078, 909), (2085, 1185)]


def test_crafted_ethernet_ipv4_udp_dns_stack(tmp_path):
    """A hand-built ethernet/IPv4/UDP/DNS query inside a pcap file decodes
    through all four layers with a valid header checksum.

    CATCHES: end-to-end stack dispatch inside a capture file (ethernet ->
    ipv4 -> udp -> dns by destination port 53) and IPv4 checksum validation.
    """
    dnsq = (struct.pack(">HHHHHH", 0x1234, 0x0100, 1, 0, 0, 0)
            + dns_name("example.com") + struct.pack(">HH", 1, 1))
    frame = eth("ff:ff:ff:ff:ff:ff", "11:22:33:44:55:66", 0x0800,
                ipv4("192.168.0.1", "192.168.0.2", 17, udp(12345, 53, dnsq)))
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{net: .header.network, q: .packets[0].packet.payload.payload.payload.questions[0], cksum: .packets[0].packet.payload.header_checksum}",
                             "-"], stdin=make_pcap([frame]))
    assert got == {
        "cksum": 63839, "net": "ethernet",
        "q": {"class": "in",
              "name": {"labels": [{"length": 7, "value": "example"},
                                  {"length": 3, "value": "com"}, {"length": 0}],
                       "value": "example.com"},
              "type": "a"},
    }


def test_sll2_capture(tmp_path):
    """sll2_tcp.pcap: LINKTYPE_LINUX_SLL2 packets decode through sll2_packet
    into a TCP connection whose client stream is the literal 'test\\n'.

    CATCHES: the SLL2 link-layer field set (protocol/packet_type/interface
    index/arphdr/link address) and SLL2-based flow tracking.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{header: .header, p0: (.packets[0].packet | {protocol_type, packet_type, interface_index, arphdr_type, link_address}), t0: (.packets[0].packet.payload.payload | {source_port, destination_port, syn, ack, sequence_number}), conns: [.tcp_connections[] | {client: {ip: .client.ip, port: .client.port, has_start: .client.has_start, has_end: .client.has_end, skipped_bytes: .client.skipped_bytes, len: (.client.stream|tobytes|length), fmt: (.client.stream|format)}, server: {ip: .server.ip, port: .server.port}}]}",
                             "pcap/sll2_tcp.pcap"])
    assert got == {
        "header": {"magic": "little_endian", "network": "linux_sll2",
                   "sigfigs": 0, "snaplen": 262144, "thiszone": 0,
                   "version_major": 2, "version_minor": 4},
        "p0": {"arphdr_type": "loopback", "interface_index": 1,
               "link_address": "00:00:00:00:00:00", "packet_type": "to_us",
               "protocol_type": "ipv4"},
        "t0": {"ack": False, "destination_port": 1234,
               "sequence_number": 1311391706, "source_port": 47174,
               "syn": True},
        "conns": [{"client": {"fmt": None, "has_end": False, "has_start": True,
                              "ip": "127.0.0.1", "len": 5, "port": 47174,
                              "skipped_bytes": 0},
                   "server": {"ip": "127.0.0.1", "port": 1234}}],
    }
    # Raw-output comparison so the payload's own trailing newline is visible:
    # fq emits the string "test\n" followed by its own output newline.
    stream = run_on(tmp_path, ["-r", "-d", "pcap", "-cV",
                               ".tcp_connections[0].client.stream | tobytes | tostring",
                               "pcap/sll2_tcp.pcap"])
    assert stream.stdout == b"test\n\n"
    assert stream.returncode == 0
    opts = fq_json(tmp_path, ["-d", "pcap", "-cV",
                              ".packets[0].packet.payload.payload.options",
                              "pcap/sll2_tcp_mss_wrong.pcap"])
    assert opts == [{"kind": "mss", "length": 4, "size": 1},
                    {"kind": "sack_permitted", "length": 2},
                    {"echo_reply": 0, "kind": "timestamp", "length": 10,
                     "value": 3832018199},
                    {"kind": "nop"},
                    {"kind": "winscale", "length": 3, "shift": 7}]


def test_ipv6_capture(tmp_path):
    """ipv6_http.pcap: 55 ethernet packets, the first being an ICMPv6
    neighbor discovery; an IPv6 HTTP connection is reassembled.

    CATCHES: IPv6 extension-free dispatch, IPv6 address formatting and TCP
    flow tracking over IPv6.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{n: (.packets|length), p0: (.packets[0].packet|format), p0v6: (.packets[0].packet.payload | {next_header, source_address, destination_address, hop_limit, payload_length}), conns: [.tcp_connections[] | {cl: {ip: .client.ip, port: .client.port, len: (.client.stream|tobytes|length)}, sv: {ip: .server.ip, port: .server.port, len: (.server.stream|tobytes|length), fmt: (.server.stream|format)}}]}",
                             "pcap/ipv6_http.pcap"])
    assert got == {
        "n": 55, "p0": "ether8023_frame",
        "p0v6": {"destination_address": "ff02::1:ff82:95b5", "hop_limit": 255,
                 "next_header": "ipv6-icmp", "payload_length": 32,
                 "source_address": "fe80::211:25ff:fe82:95b5"},
        "conns": [{"cl": {"ip": "2001:6f8:102d:0:2d0:9ff:fee3:e8de",
                          "len": 240, "port": 59201},
                   "sv": {"fmt": None, "ip": "2001:6f8:900:7c0::2",
                          "len": 2259, "port": "http"}}],
    }
    req = run_ok(tmp_path, ["-r", "-d", "pcap", "-cV",
                            ".tcp_connections[0].client.stream | tobytes | tostring[0:40]",
                            "pcap/ipv6_http.pcap"])
    assert req == "GET / HTTP/1.0\r\nHost: cl-1985.ham-01.de."
