"""OpenTimestamps proof-file tests: header, operations, attestations, errors.

Every expected value below was recorded by running the reference fq binary
(fixtures from format/opentimestamps/testdata, everything else crafted by
hand from the wire layout in format/opentimestamps/opentimestamps.go).
"""

import pytest

from conftest import fq_json, run_ok, run_on

OTS_MAGIC = bytes.fromhex(
    "004f70656e54696d657374616d7073000050726f6f6600bf89e2e884e89294")
BTC_ATTESTATION_MAGIC = bytes.fromhex("0588960d73d71901")


def ots_varint(v):
    """The OTS varint is LEB128: low 7 bits first, continuation bit 0x80."""
    out = b""
    while True:
        b = v & 0x7F
        v >>= 7
        if v:
            out += bytes([b | 0x80])
        else:
            out += bytes([b])
            return out


def ots_file(version, algo_tag, digest, ops=b""):
    """A proof file: magic, version varint, hash tag, digest, operations."""
    return OTS_MAGIC + ots_varint(version) + bytes([algo_tag]) + digest + ops


def test_simple_proof_calendar_attestations(tmp_path):
    """The simple.ots fixture decodes a sha256 proof with 35 operations and
    four calendar attestations, each with its own url and url_size.

    CATCHES: header layout, sha256 symbol, append/prepend argument hex and
    the calendar attestation url_size/url split.
    """
    got = fq_json(tmp_path, [
        "-d", "opentimestamps", "-cV",
        "{magic: (.magic_bytes|tobytes|tohex), version,"
        " algo: .digest_hash_algorithm, digest,"
        " nops: (.operations|length),"
        " urls: [.operations[] | select(.tag == \"attestation\") | .url]}",
        "opentimestamps/simple.ots"])
    assert got == {
        "magic": OTS_MAGIC.hex(),
        "version": 1,
        "algo": "sha256",
        "digest": "039058c6f2c0cb492c533b0a4d14ef77cc0f78abccced5287d84a1a2011cfb82",
        "nops": 35,
        "urls": ["https://alice.btc.calendar.opentimestamps.org",
                 "https://bob.btc.calendar.opentimestamps.org",
                 "https://finney.calendar.eternitywall.com",
                 "https://btc.calendar.catallaxy.com"],
    }
    # The first five operations and the first attestation, exactly.
    assert fq_json(tmp_path, ["-d", "opentimestamps", "-cV",
                              ".operations[0:5]",
                              "opentimestamps/simple.ots"]) == [
        {"argument": "1b32c4b978d0ff157ca6d44160f378e0",
         "argument_size": 16, "tag": "append"},
        {"tag": "sha256"},
        {"tag": "continuation_byte"},
        {"argument": "98a144f35cf16da199d88df927645320",
         "argument_size": 16, "tag": "append"},
        {"tag": "sha256"},
    ]
    assert fq_json(tmp_path, ["-d", "opentimestamps", "-cV",
                              ".operations[11]",
                              "opentimestamps/simple.ots"]) == {
        "attestation_type": "calendar", "attestation_varbytes_size": 46,
        "tag": "attestation",
        "url": "https://alice.btc.calendar.opentimestamps.org",
        "url_size": 45,
    }
    # The magic assertion is annotated "(valid)" in the verbose display.
    disp = run_ok(tmp_path, ["-d", "opentimestamps", "dv",
                             "opentimestamps/simple.ots"])
    assert "magic_bytes: raw bits (valid) 0x0-0x1f (31)" in disp


def test_bitcoin_attestation_block_height(tmp_path):
    """A bitcoin attestation decodes attestation_type as the "bitcoin"
    symbol and reads the block height as a varint; the preceding
    attestation_varbytes_size is NOT used to size it (here 1 vs 3 bytes).

    CATCHES: bitcoin attestation magic symbol, varint block height that is
    independent of attestation_varbytes_size, and block 0 single byte.
    """
    ops = (b"\x00" + BTC_ATTESTATION_MAGIC + ots_varint(1) + ots_varint(200000)
           + b"\x00" + BTC_ATTESTATION_MAGIC + ots_varint(1) + ots_varint(0))
    data = ots_file(1, 0x08, b"B" * 32, ops)
    got = fq_json(tmp_path, ["-d", "opentimestamps", "-cV", ".", "-"],
                  stdin=data)
    assert got["operations"] == [
        {"attestation_type": "bitcoin", "attestation_varbytes_size": 1,
         "block": 200000, "tag": "attestation"},
        {"attestation_type": "bitcoin", "attestation_varbytes_size": 1,
         "block": 0, "tag": "attestation"},
    ]
    disp = run_ok(tmp_path, ["-d", "opentimestamps", "dv", "-"], stdin=data)
    assert "attestation_type: \"bitcoin\" (398733551544506625) 0x42-0x4a (8)" in disp
    # 200000 is 3 varint bytes (c0 9a 0c) even though varbytes_size says 1.
    assert "block: 200000 0x4b-0x4e (3)" in disp
    assert "block: 0 0x58-0x59 (1)" in disp


def test_unknown_attestation_stays_raw(tmp_path):
    """known-and-unknown-notary.ots ends with an attestation whose type magic
    is neither calendar nor bitcoin: the type stays a plain number and the
    payload is kept as unknown_data with the recorded size.

    CATCHES: unmapped attestation magic falls back to a numeric
    attestation_type plus a raw unknown_data field of n bytes.
    """
    got = fq_json(tmp_path, [
        "-d", "opentimestamps", "-cV",
        "{algo: .digest_hash_algorithm, digest, nops: (.operations|length),"
        " last: (.operations[-1] | {attestation_type,"
        " attestation_varbytes_size, tag,"
        " unknown: (.unknown_data|tobytes|tohex)}),"
        " calendar: [.operations[] | select(.url != null)]}",
        "opentimestamps/known-and-unknown-notary.ots"])
    assert got["algo"] == "sha256"
    assert got["digest"] == ("d288b2ee212b01e3e5f6d333df3a4d53f292cc3f"
                             "07b09013c0b40c8e7dcb9c03")
    assert got["nops"] == 13
    assert got["last"] == {
        "attestation_type": 72623859790382856,
        "attestation_varbytes_size": 46,
        "tag": "attestation",
        "unknown": "78" * 46,
    }
    assert got["calendar"] == [{
        "attestation_type": "calendar", "attestation_varbytes_size": 44,
        "tag": "attestation",
        "url": "https://bob.btc.calendar.opentimestamps.org",
        "url_size": 43,
    }]
    disp = run_ok(tmp_path, ["-d", "opentimestamps", "dv",
                             "opentimestamps/known-and-unknown-notary.ots"])
    assert "attestation_type: 72623859790382856 0xd2-0xda (8)" in disp
    assert "unknown_data: raw bits 0xdb-0x109 (46)" in disp
    assert "attestation_type: \"calendar\" (9502563384537189518) 0x79-0x81 (8)" in disp


def test_ripemd160_and_sha1_digest_sizes(tmp_path):
    """The checked-in sha1.ots fixture is actually a ripemd160 proof (20-byte
    digest); a crafted sha1 proof (tag 0x02) also takes 20 bytes and decodes
    a prepend argument whose size is a multi-byte varint (81 00 = 128).

    CATCHES: per-algorithm digest sizes (ripemd160 and sha1 both 20) and
    multi-byte argument_size varints.
    """
    assert fq_json(tmp_path, ["-d", "opentimestamps", "-cV",
                              "{algo: .digest_hash_algorithm, digest, version}",
                              "opentimestamps/sha1.ots"]) == {
        "algo": "ripemd160",
        "digest": "0423ced4914bc5e47aeda314b5993b7bd796fe00",
        "version": 1,
    }
    arg = bytes(range(128))
    data = ots_file(1, 0x02, b"S" * 20, b"\xf1" + ots_varint(128) + arg)
    got = fq_json(tmp_path, ["-d", "opentimestamps", "-cV", ".", "-"],
                  stdin=data)
    assert got["digest_hash_algorithm"] == "sha1"
    assert got["digest"] == "53" * 20
    assert got["operations"] == [
        {"argument": arg.hex(), "argument_size": 128, "tag": "prepend"}]


def test_keccak256_reverse_hexlify_operations(tmp_path):
    """A keccak256 proof (tag 0x67) with reverse and hexlify operations: the
    two unary operations carry no argument_size/argument fields at all.

    CATCHES: keccak256 digest symbol with 32-byte digest and argument-free
    operation tags reverse (0xf2) and hexlify (0xf3).
    """
    data = ots_file(1, 0x67, b"K" * 32, b"\xf2\xf3")
    got = fq_json(tmp_path, ["-d", "opentimestamps", "-cV", ".", "-"],
                  stdin=data)
    assert got["digest_hash_algorithm"] == "keccak256"
    assert got["digest"] == "4b" * 32
    assert got["operations"] == [{"tag": "reverse"}, {"tag": "hexlify"}]


def test_version_varint_and_zero_size_argument(tmp_path):
    """The version is a varint (81 00 decodes to 128, not 1), and an append
    with argument_size 0 always fails with an EOF error from RawLen even
    though zero bytes are requested.

    CATCHES: multi-byte version varint and the zero-length RawLen failure
    for append/prepend arguments.
    """
    data = ots_file(128, 0x08, b"V" * 32, b"\xf0" + ots_varint(0))
    got = fq_json(tmp_path, ["-d", "opentimestamps", "-cV", ".", "-"],
                  stdin=data)
    assert got["version"] == 128
    assert got["operations"] == [{"argument_size": 0, "tag": "append"}]
    disp = run_ok(tmp_path, ["-d", "opentimestamps", "dv", "-"], stdin=data)
    assert ("error: opentimestamps: RawLen(argument): failed at position 68"
            " (read size 0 seek pos 0): EOF") in disp


# A proof file with one magic byte flipped (byte 5: 0x70 -> 0x8f).
_plain = ots_file(1, 0x08, b"A" * 32)
BAD_MAGIC_FILE = _plain[:5] + b"\x8f" + _plain[6:]


@pytest.mark.parametrize("label,data,err_line,json_expr,json_expected", [
    # One flipped magic byte: the whole input becomes a single gap.
    ("bad_magic",
     BAD_MAGIC_FILE,
     "error: opentimestamps: RawLen(magic_bytes): failed at position 31"
     " (read size 0 seek pos 0): failed to validate raw",
     "{keys: keys, gap: (.gap0|tobytes|tohex)}",
     {"keys": ["gap0"], "gap": BAD_MAGIC_FILE.hex()}),
    # Hash algorithm tag 0x01 is not in the digest table.
    ("bad_algo",
     ots_file(1, 0x01, b"\x11" * 20),
     "error: opentimestamps: error at position 0x21:"
     " hash algorithm not supported, got 1: ''",
     "{version, algo: .digest_hash_algorithm, gap: (.gap0|tobytes|tohex)}",
     {"version": 1, "algo": 1, "gap": "11" * 20}),
    # Operation tag 0x99 is unknown: it stays numeric in the partial decode.
    ("bad_op_tag",
     ots_file(1, 0x08, b"A" * 32, b"\x99"),
     "error: opentimestamps: error at position 0x42: unknown operation tag 99",
     ".operations[0]",
     {"tag": 153}),
    # A bitcoin attestation cut off right after its type magic.
    ("truncated_attestation",
     ots_file(1, 0x08, b"T" * 32, b"\x00" + BTC_ATTESTATION_MAGIC),
     "error: opentimestamps: U8: failed at position 74"
     " (read size 0 seek pos 0): EOF",
     ".operations[0]",
     {"attestation_type": "bitcoin", "tag": "attestation"}),
])
def test_decode_errors(tmp_path, label, data, err_line, json_expr,
                       json_expected):
    """Decode failures leave a partial value (exit code 0) and the verbose
    display reports the format-prefixed error line.

    CATCHES: exact error text and partial-field shape for a bad magic, an
    unsupported hash algorithm, an unknown operation tag and a truncated
    attestation.
    """
    disp = run_ok(tmp_path, ["-d", "opentimestamps", "dv", "-"], stdin=data)
    assert err_line in disp
    got = fq_json(tmp_path, ["-d", "opentimestamps", "-cV", json_expr, "-"],
                  stdin=data)
    assert got == json_expected


def test_probe_group_autodetect(tmp_path):
    """opentimestamps is registered in the probe group: plain `fq FILE`
    without -d finds it, and the large hello-world proof decodes with 319
    operations.

    CATCHES: probe registration (no explicit -d needed) and the hello-world
    fixture's operation count.
    """
    got = fq_json(tmp_path, ["-cV",
                             "{version, algo: .digest_hash_algorithm,"
                             " nops: (.operations|length)}",
                             "opentimestamps/hello-world.txt.ots"])
    assert got == {"version": 1, "algo": "sha256", "nops": 319}
    # The same decode works without any -d flag at all.
    auto = fq_json(tmp_path, ["-cV", ".digest_hash_algorithm",
                              "opentimestamps/simple.ots"])
    assert auto == "sha256"
