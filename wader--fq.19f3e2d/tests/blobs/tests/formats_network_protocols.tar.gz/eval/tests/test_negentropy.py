"""Negentropy (Nostr range-sync) message tests.

Every expected value below was recorded by running the reference fq binary
(fixtures from format/negentropy/testdata, everything else crafted by hand
from the layout in format/negentropy/negentropy.go).
"""

import pytest

from conftest import fq_json, run_ok

NEG_VERSION = 0x61


def neg_varint(v):
    """Negentropy's varint is BIG-endian: the first byte holds the most
    significant 7-bit group, the continuation bit is 0x80."""
    groups = []
    while True:
        groups.append(v & 0x7F)
        v >>= 7
        if not v:
            break
    out = b""
    for i, g in enumerate(groups[::-1]):
        out += bytes([g | (0x80 if i < len(groups) - 1 else 0)])
    return out


def neg_msg(bounds):
    """A message from (delta, id_prefix, mode, extra) bound tuples."""
    out = bytes([NEG_VERSION])
    for delta, prefix, mode, extra in bounds:
        out += neg_varint(delta) + neg_varint(len(prefix)) + prefix
        if mode is not None:
            out += neg_varint(mode)
        out += extra
    return out


def test_smalljustfingerprints_fixture(tmp_path):
    """The smalljustfingerprints fixture has 16 bounds, all in fingerprint
    mode; timestamps accumulate the deltas and the final delta 0 is the
    "infinity" sentinel (timestamp_delta -1, timestamp 0).

    CATCHES: fingerprint mode, timestamp accumulation across bounds, the
    infinity sentinel for delta 0 and 1-byte id prefixes.
    """
    got = fq_json(tmp_path, [
        "-d", "negentropy", "-cV",
        "{version, n: (.bounds|length),"
        " modes: ([.bounds[].mode] | unique),"
        " first: .bounds[0],"
        " prefixed: [.bounds[] | select(.id_prefix_size == 1) | .id_prefix],"
        " last: .bounds[-1]}",
        "negentropy/smalljustfingerprints"])
    assert got == {
        "version": 97,
        "n": 16,
        "modes": ["fingerprint"],
        "first": {"fingerprint": "108e4206828ee3bf34258465809a337c",
                  "id_prefix_size": 0, "mode": "fingerprint",
                  "timestamp": 1726667387, "timestamp_delta": 1726667387},
        "prefixed": ["14", "e6", "57", "e6", "84", "87", "14", "83", "7a",
                     "5b", "cc"],
        "last": {"fingerprint": "31712d30e5296a7a45d07bba452d61cd",
                 "id_prefix_size": 0, "mode": "fingerprint",
                 "timestamp": 0, "timestamp_delta": -1},
    }
    # The display shows sym (actual) pairs and RFC3339 descriptions.
    disp = run_ok(tmp_path, ["-d", "negentropy", "dv",
                             "negentropy/smalljustfingerprints"])
    assert "timestamp_delta: 1726667387 (1726667388) 0x1-0x6 (5)" in disp
    assert "timestamp: 1726667387 (2024-09-18T13:49:47Z)" in disp
    assert "timestamp_delta: -1 (0) (infinity)" in disp
    assert "timestamp: 0 (infinity)" in disp


def test_skip_and_fingerprint_bounds_crafted(tmp_path):
    """A skip bound keeps its id_prefix but no payload, a fingerprint bound
    carries 16 raw-hex bytes, and timestamps accumulate (9 then 13).

    CATCHES: skip mode (0) consuming only prefix bytes, fingerprint mode
    (1) with its 16-byte fingerprint, and the second timestamp being the
    sum of both deltas.
    """
    data = neg_msg([
        (10, b"\xaa\xbb\xcc", 0, b""),
        (5, b"", 1, b"\x11" * 16),
    ])
    got = fq_json(tmp_path, ["-d", "negentropy", "-cV", ".", "-"], stdin=data)
    assert got == {
        "version": 97,
        "bounds": [
            {"id_prefix": "aabbcc", "id_prefix_size": 3, "mode": "skip",
             "timestamp": 9, "timestamp_delta": 9},
            {"fingerprint": "11" * 16, "id_prefix_size": 0,
             "mode": "fingerprint", "timestamp": 13, "timestamp_delta": 4},
        ],
    }
    disp = run_ok(tmp_path, ["-d", "negentropy", "dv", "-"], stdin=data)
    assert "timestamp_delta: 9 (10) 0x1-0x2 (1)" in disp
    assert "timestamp: 9 (1970-01-01T00:00:09Z)" in disp
    assert "id_prefix: \"aabbcc\" (raw bits) 0x3-0x6 (3)" in disp
    assert "mode: \"skip\" (0) 0x6-0x7 (1)" in disp
    assert "timestamp: 13 (1970-01-01T00:00:13Z)" in disp
    assert "mode: \"fingerprint\" (1) 0x9-0xa (1)" in disp
    assert "fingerprint: \"11111111111111111111111111111111\" (raw bits) 0xa-0x1a (16)" in disp


def test_idlist_bounds(tmp_path):
    """An idlist bound reads a num varint followed by num 32-byte ids; num 0
    gives an empty ids array, and the ids show up with the "id" symbol in
    the display.

    CATCHES: idlist mode (2) structure, 32-byte id hex and the num/ids
    split including the empty case.
    """
    data = neg_msg([(1, b"", 2, neg_varint(2) + b"\x01" * 32 + b"\x02" * 32)])
    got = fq_json(tmp_path, ["-d", "negentropy", "-cV", ".", "-"], stdin=data)
    assert got == {
        "version": 97,
        "bounds": [{"id_prefix_size": 0,
                    "idlist": {"ids": ["01" * 32, "02" * 32], "num": 2},
                    "mode": "idlist", "timestamp": 0, "timestamp_delta": 0}],
    }
    disp = run_ok(tmp_path, ["-d", "negentropy", "dv", "-"], stdin=data)
    assert "timestamp_delta: 0 (1) 0x1-0x2 (1)" in disp
    assert "timestamp: 0 (1970-01-01T00:00:00Z)" in disp
    assert "mode: \"idlist\" (2) 0x3-0x4 (1)" in disp
    assert "num: 2 0x4-0x5 (1)" in disp
    assert "ids[0:2]: 0x5-0x45 (64)" in disp
    assert "[0]: \"0101010101010101010101010101010101010101010101010101010101010101\" (raw bits) id 0x5-0x25 (32)" in disp

    empty = neg_msg([(3, b"", 2, neg_varint(0))])
    got = fq_json(tmp_path, ["-d", "negentropy", "-cV", ".", "-"],
                  stdin=empty)
    assert got["bounds"] == [{"id_prefix_size": 0,
                              "idlist": {"ids": [], "num": 0},
                              "mode": "idlist", "timestamp": 2,
                              "timestamp_delta": 2}]


def test_big_endian_varint_delta(tmp_path):
    """A 4-byte delta varint (81 80 80 00) decodes as 2097152 because the
    first byte is the most significant 7-bit group; the timestamp is then
    delta-1 seconds past the epoch.

    CATCHES: the big-endian varint of negentropy (a little-endian reader
    would report 1 instead of 2097152) and the delta-1 timestamp rule.
    """
    data = neg_msg([(1 << 21, b"", 0, b"")])
    assert data == bytes.fromhex("6181808000 00 00".replace(" ", ""))
    got = fq_json(tmp_path, ["-d", "negentropy", "-cV", ".", "-"], stdin=data)
    assert got["bounds"] == [{"id_prefix_size": 0, "mode": "skip",
                              "timestamp": 2097151,
                              "timestamp_delta": 2097151}]
    disp = run_ok(tmp_path, ["-d", "negentropy", "dv", "-"], stdin=data)
    assert "timestamp_delta: 2097151 (2097152) 0x1-0x5 (4)" in disp
    assert "timestamp: 2097151 (1970-01-25T06:32:31Z)" in disp


def test_bigmessagewitheverything_fixture(tmp_path):
    """The everything fixture mixes all three modes: 199 bounds split into
    144 fingerprint, 49 idlist and 6 skip, with 46 ids listed in total.

    CATCHES: mode mix and counting over a large real message (skip,
    fingerprint and idlist paths all exercised in one file).
    """
    got = fq_json(tmp_path, [
        "-d", "negentropy", "-cV",
        "{n: (.bounds|length),"
        " modes: ([.bounds[].mode] | group_by(.) | map({mode: .[0], n: length})),"
        " ids: ([.bounds[].idlist.num // 0] | add)}",
        "negentropy/bigmessagewitheverything"])
    assert got == {
        "n": 199,
        "modes": [{"mode": "fingerprint", "n": 144},
                  {"mode": "idlist", "n": 49},
                  {"mode": "skip", "n": 6}],
        "ids": 46,
    }


def test_strfrybigmessage_fixture(tmp_path):
    """The strfry fixture starts with a skip bound at timestamp 18 and then
    a large idlist bound (27 ids) at 1726286357; its last timestamp is
    1726788188.

    CATCHES: real strfry-produced messages with 16 idlist bounds, the 27-id
    list and the accumulated first/last timestamps.
    """
    got = fq_json(tmp_path, [
        "-d", "negentropy", "-cV",
        "{n: (.bounds|length),"
        " modes: ([.bounds[].mode] | group_by(.) | map({mode: .[0], n: length})),"
        " b0: {mode: .bounds[0].mode, timestamp: .bounds[0].timestamp},"
        " b1: {mode: .bounds[1].mode, timestamp: .bounds[1].timestamp,"
        "      delta: .bounds[1].timestamp_delta,"
        "      num: .bounds[1].idlist.num,"
        "      nids: (.bounds[1].idlist.ids|length),"
        "      first_id: .bounds[1].idlist.ids[0],"
        "      last_id: .bounds[1].idlist.ids[-1]},"
        " timestamps: ([.bounds[].timestamp] | [first, last, max])}",
        "negentropy/strfrybigmessage"])
    assert got == {
        "n": 17,
        "modes": [{"mode": "idlist", "n": 16}, {"mode": "skip", "n": 1}],
        "b0": {"mode": "skip", "timestamp": 18},
        "b1": {"mode": "idlist", "timestamp": 1726286357,
               "delta": 1726286339, "num": 27, "nids": 27,
               "first_id": "55d7b8d996a09e1e07140d2eec1151d0aac37f8b166a6ff2f7bf27353c935b5e",
               "last_id": "fef909d28ba9bea1c8d678232ace6255e22f4bfdfb4f5735f890ea7c523006f9"},
        "timestamps": [18, 1726788188, 1726788188],
    }


@pytest.mark.parametrize("label,data,err_line,json_expr,json_expected", [
    # Version 0x62 instead of 0x61: everything after the version byte is a gap.
    ("bad_version",
     b"\x62\x05\x00\x00",
     "error: negentropy: error at position 0x1: unexpected version 98"
     " (expected 97), is this really a negentropy message?",
     "{version, gap: (.gap0|tobytes|tohex)}",
     {"version": 98, "gap": "050000"}),
    # id_prefix_size 33 exceeds the 32-byte id limit.
    ("prefix_too_big",
     b"\x61\x05\x21",
     "error: negentropy: error at position 0x3:"
     " unexpected id prefix size bigger than 32: 33",
     ".bounds[0]",
     {"id_prefix_size": 33, "timestamp": 4, "timestamp_delta": 4}),
    # Mode 3 is not skip/fingerprint/idlist.
    ("unknown_mode",
     b"\x61\x05\x00\x03",
     "error: negentropy: error at position 0x4: unexpected mode 3",
     ".bounds[0]",
     {"id_prefix_size": 0, "mode": 3, "timestamp": 4, "timestamp_delta": 4}),
    # Empty input: the version byte itself cannot be read.
    ("empty",
     b"",
     "error: negentropy: U8(version): failed at position 0"
     " (read size 0 seek pos 0): EOF",
     None, None),
    # Delta 0 (infinity) then end of input mid-bound.
    ("truncated_bound",
     b"\x61\x00",
     "error: negentropy: U8: failed at position 2"
     " (read size 0 seek pos 0): EOF",
     ".bounds[0]",
     {"timestamp": 0, "timestamp_delta": -1}),
])
def test_decode_errors(tmp_path, label, data, err_line, json_expr,
                       json_expected):
    """Decode failures leave a partial value (exit code 0) and the verbose
    display reports the format-prefixed error line.

    CATCHES: exact error text and partial-field shape for a wrong version,
    an oversized id prefix, an unknown mode, empty input and a bound cut
    off after the delta.
    """
    disp = run_ok(tmp_path, ["-d", "negentropy", "dv", "-"], stdin=data)
    assert err_line in disp
    if json_expr is not None:
        got = fq_json(tmp_path, ["-d", "negentropy", "-cV", json_expr, "-"],
                      stdin=data)
        assert got == json_expected
