"""pcapng file tests: section headers and byte-order magic, interface
description blocks, name resolution records, enhanced packet blocks and
multi-section files.

Every expected value below was recorded by running the reference fq binary.
"""

from conftest import fq_json, run_ok

LE = "pcap/dhcp_little_endian.pcapng"
BE = "pcap/dhcp_big_endian.pcapng"


def test_dhcp_section_and_interface_blocks(tmp_path):
    """The little-endian DHCP capture is one section whose blocks are
    section_header, interface_description, name_resolution and four
    enhanced_packet blocks; the interface uses LINKTYPE_ETHERNET.

    CATCHES: pcapng root is an array of sections (each with a blocks array),
    block type symbols and the section/interface field set.
    """
    got = fq_json(tmp_path, ["-d", "pcapng", "-cV",
                             "{nsec: length, b0: (.[0].blocks[0] | {type, byte_order_magic, major_version, minor_version, section_length}), b1: (.[0].blocks[1] | {type, link_type, reserved, snap_len}), types: [.[0].blocks[] | .type]}",
                             LE])
    assert got == {
        "nsec": 1,
        "b0": {"byte_order_magic": "little_endian", "major_version": 1,
               "minor_version": 0, "section_length": -1,
               "type": "section_header"},
        "b1": {"link_type": "ethernet", "reserved": 0, "snap_len": 262144,
               "type": "interface_description"},
        "types": ["section_header", "interface_description", "name_resolution",
                  "enhanced_packet", "enhanced_packet", "enhanced_packet",
                  "enhanced_packet"],
    }


def test_name_resolution_records(tmp_path):
    """The name resolution block holds an ipv4 record for 127.0.0.1 with one
    'localhost' entry, trailing padding, and a terminating end record.

    CATCHES: NRB record parsing (type, length, address, entries, padding)
    and the end-of-block record shape.
    """
    got = fq_json(tmp_path, ["-d", "pcapng", "-cV",
                             "[.[0].blocks[] | select(.type==\"name_resolution\") | .records]",
                             LE])
    assert got == [[{"address": "127.0.0.1", "entries": ["localhost"],
                     "length": 14, "padding": "\x00\x00", "type": "ipv4"},
                    {"length": 0, "type": "end"}]]


def test_big_endian_section(tmp_path):
    """The big-endian variant of the same capture reports the same content
    with byte_order_magic big_endian.

    CATCHES: pcapng per-section byte order detection via the section magic.
    """
    got = fq_json(tmp_path, ["-d", "pcapng", "-cV",
                             "{b0: (.[0].blocks[0] | {byte_order_magic, section_length}), b1: (.[0].blocks[1] | {link_type, snap_len}), nr: ([.[0].blocks[] | select(.type==\"name_resolution\") | .records])}",
                             BE])
    assert got == {
        "b0": {"byte_order_magic": "big_endian", "section_length": -1},
        "b1": {"link_type": "ethernet", "snap_len": 262144},
        "nr": [[{"address": "127.0.0.1", "entries": ["localhost"],
                 "length": 14, "padding": "\x00\x00", "type": "ipv4"},
                {"length": 0, "type": "end"}]],
    }


def test_enhanced_packet_block_and_raw_bootp(tmp_path):
    """The DHCP enhanced packet block carries split timestamps, lengths and
    padding; the frame decodes ethernet -> ipv4 -> udp with bootpc/bootps
    port symbols, but the BOOTP payload itself stays raw bits.

    CATCHES: EPB field names (interface_id, timestamp_high/low, capture vs
    original length, padding) and that ports 68/67 do NOT dispatch to any
    bootp decoder — the payload stays undecoded raw bits.
    """
    epb = fq_json(tmp_path, ["-d", "pcapng", "-cV",
                             "[.[0].blocks[] | select(.type==\"enhanced_packet\")][0] | {interface_id, timestamp_high, timestamp_low, capture_packet_length, original_packet_length, padding}",
                             LE])
    assert epb == {"capture_packet_length": 314, "interface_id": 0,
                   "original_packet_length": 314, "padding": "\x00\x00",
                   "timestamp_high": 1102274184,
                   "timestamp_low": 317453000}
    keys = fq_json(tmp_path, ["-d", "pcapng", "-cV",
                              "[.[0].blocks[] | select(.type==\"enhanced_packet\")][0] | keys",
                              LE])
    assert keys == ["type", "length", "interface_id", "timestamp_high",
                    "timestamp_low", "capture_packet_length",
                    "original_packet_length", "packet", "padding", "options",
                    "footer_length"]
    payload = fq_json(tmp_path, ["-d", "pcapng", "-cV",
                                 "[.[0].blocks[] | select(.type==\"enhanced_packet\") | {iface: .interface_id, frame: (.packet|format), l4: (.packet.payload.payload|format), ports: (.packet.payload.payload|{source_port,destination_port}), l7: (.packet.payload.payload.payload|format)}][0]",
                                 LE])
    assert payload == {"frame": "ether8023_frame", "iface": 0,
                       "l4": "udp_datagram", "l7": None,
                       "ports": {"destination_port": "bootps",
                                 "source_port": "bootpc"}}
    bootp_hex = run_ok(tmp_path, ["-d", "pcapng", "-cV",
                                  "[.[0].blocks[] | select(.type==\"enhanced_packet\")][0].packet.payload.payload.payload | tobytes | tohex",
                                  LE])
    # Without -r the value is printed as a JSON string, so the hex is quoted.
    assert bootp_hex == '"0101060000003d1d0000000000000000000000000000000000000000000b8201fc4200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000638253633501013d0701000b8201fc4232040000000037040103062aff00000000000000"'



def test_many_interfaces(tmp_path):
    """many_interfaces.pcapng has one section with 88 blocks: 11 interfaces
    (mixed link types incl. numeric 12 and two 'null'), 64 enhanced packets
    and interface statistics blocks referencing every interface id.

    CATCHES: multi-interface pcapng handling — per-packet interface_id
    bookkeeping and link types that have no symbol staying numeric.
    """
    got = fq_json(tmp_path, ["-d", "pcapng", "-cV",
                             "[.[] | {nblocks: (.blocks|length), linktypes: [.blocks[] | select(.type==\"interface_description\") | .link_type], ifaces: [.blocks[] | select(.type==\"interface_statistics\") | .interface_id], epb_ifaces: [.blocks[] | select(.type==\"enhanced_packet\") | .interface_id], first_pkt_fmts: ([.blocks[] | select(.type==\"enhanced_packet\") | .packet|format] | unique)}]",
                             "pcap/many_interfaces.pcapng"])
    assert got == [{
        "nblocks": 88,
        "linktypes": ["ethernet", "ethernet", "ethernet", "ethernet", "null",
                      "ethernet", "ethernet", "ethernet", 12, "ethernet",
                      "null"],
        "ifaces": list(range(11)),
        "epb_ifaces": [0, 0, 10, 10] + [0] * 60,
        "first_pkt_fmts": ["bsd_loopback_frame", "ether8023_frame"],
    }]


def test_linkframe_capture_streams(tmp_path):
    """tls12-ipv4-linkframe-keylog.pcapng: one section whose second block is
    an ipv4-linktype interface; two TCP connections are tracked but their
    streams are not decoded as tls (format null) even with a keylog option,
    and the client stream starts with a TLS client hello record header.

    CATCHES: pcapng interface link types beyond ethernet (LINKTYPE_RAW
    value 101 -> 'ipv4'), flow tracking from raw-IP packets, and that
    streams only decode as tls when the tls decoder is actually applied.
    """
    got = fq_json(tmp_path, ["-d", "pcapng", "-cV",
                             "[.[] | {iface_link: .blocks[1].link_type, conns: [.tcp_connections[]? | {cl: {ip: .client.ip, port: .client.port, has_start: .client.has_start, has_end: .client.has_end, skipped_bytes: .client.skipped_bytes, len: (.client.stream|tobytes|length), fmt: (.client.stream|format)}, sv: {ip: .server.ip, port: .server.port, len: (.server.stream|tobytes|length)}}]}]",
                             "inet/tls12-ipv4-linkframe-keylog.pcapng"])
    assert got == [{
        "iface_link": "ipv4",
        "conns": [
            {"cl": {"fmt": None, "has_end": False, "has_start": False,
                    "ip": "10.9.0.2", "len": 491, "port": 46800,
                    "skipped_bytes": 0},
             "sv": {"ip": "93.184.216.34", "len": 3662, "port": "https"}},
            {"cl": {"fmt": None, "has_end": False, "has_start": False,
                    "ip": "10.9.0.2", "len": 491, "port": 46802,
                    "skipped_bytes": 0},
             "sv": {"ip": "93.184.216.34", "len": 3662, "port": "https"}}],
    }]
    stream = run_ok(tmp_path, ["-d", "pcapng", "-cV",
                               ". [0].tcp_connections[0].client.stream | tobytes | tohex | .[0:32]",
                               "inet/tls12-ipv4-linkframe-keylog.pcapng"])
    assert stream == '"16030100e0010000dc0303f67a28b386"'
