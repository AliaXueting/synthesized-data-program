"""TLS record/handshake and keylog decryption tests.

The pcap captures feed the flow engine, whose TCP streams decode as tls;
with ``-o keylog=@file`` (NSS key log) the encrypted records are decrypted
into per-record ``message`` fields and a whole-connection ``stream``.
Fixtures come from format/tls/testdata; every expected value below was
recorded by running the reference fq binary.
"""

import pytest

from conftest import fq_json, run_ok

TESTTLS = "tls/testtls.com.http1.1-tls1.2.pcap"
TESTTLS_KEYLOG = "keylog=@tls/testtls.com.http1.1-tls1.2.pcap.keylog"
CIPHERS_KEYLOG = "keylog=@tls/ciphers_all.keylog"


def test_handshake_fields_without_keylog(tmp_path):
    """Without a keylog the handshake decodes but the three encrypted server
    records keep only encrypted_data (no message field) and the stream value
    has no decrypted "stream" key at all.

    CATCHES: client/server hello field values (cipher_suit singular!),
    encrypted_data vs message records and the absence of a decrypted stream.
    """
    got = fq_json(tmp_path, ["-cV",
                             "{n: (.tcp_connections|length),"
                             " cport: .tcp_connections[0].client.port,"
                             " cfmt: (.tcp_connections[0].client.stream|format),"
                             " sfmt: (.tcp_connections[0].server.stream|format),"
                             " skeys: (.tcp_connections[0].server.stream|keys),"
                             " recs: [.tcp_connections[0].server.stream.records[]"
                             "        | {type, msg: has(\"message\"),"
                             "           enc: has(\"encrypted_data\")}]}",
                             TESTTLS])
    assert got == {
        "n": 1, "cport": 61925, "cfmt": "tls", "sfmt": "tls",
        "skeys": ["records"],
        "recs": [
            {"type": "handshake", "msg": True, "enc": False},
            {"type": "handshake", "msg": True, "enc": False},
            {"type": "handshake", "msg": True, "enc": False},
            {"type": "handshake", "msg": True, "enc": False},
            {"type": "change_cipher_spec", "msg": True, "enc": False},
            {"type": "handshake", "msg": False, "enc": True},
            {"type": "application_data", "msg": False, "enc": True},
            {"type": "application_data", "msg": False, "enc": True},
        ],
    }
    # Server hello: cipher_suit (no trailing e) and 5 extensions.
    assert fq_json(tmp_path, ["-cV",
                              ".tcp_connections[0].server.stream.records[0].message"
                              " | {version, cipher_suit, compression_method,"
                              " session_id_length, next: (.extensions|length)}",
                              TESTTLS]) == {
        "version": "tls1.2",
        "cipher_suit": "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
        "compression_method": "null",
        "session_id_length": 32,
        "next": 5,
    }
    # Client hello: cipher_suits list and extension symbols.
    assert fq_json(tmp_path, ["-cV",
                              ".tcp_connections[0].client.stream.records[0].message"
                              " | {version, nsuites: (.cipher_suits|length),"
                              " suites4: .cipher_suits[0:4],"
                              " comp: .compression_methods,"
                              " ext: [.extensions[].type]}",
                              TESTTLS]) == {
        "version": "tls1.2",
        "nsuites": 28,
        "suites4": ["TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384",
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384",
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256"],
        "comp": ["null"],
        "ext": ["server_name", "ec_point_formats", "supported_groups",
                "application_layer_protocol_negotiation", "encrypt_then_mac",
                "extended_master_secret", "signature_algorithms"],
    }


def test_keylog_decrypts_http_streams(tmp_path):
    """With the NSS keylog the client stream decrypts to the exact 75-byte
    curl request, the server stream to the nginx response, and every
    encrypted record gains a decrypted message field.

    CATCHES: end-to-end TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 decryption of
    both directions and the record vs plaintext size difference.
    """
    args = ["-o", TESTTLS_KEYLOG]
    req = fq_json(tmp_path, [*args, "-cV",
                             ".tcp_connections[0].client.stream.stream | tobytes",
                             TESTTLS])
    assert req == "GET / HTTP/1.1\r\nHost: testtls.com\r\nUser-Agent: curl/7.87.0\r\nAccept: */*\r\n\r\n"
    assert fq_json(tmp_path, [*args, "-cV",
                              ".tcp_connections[0].server.stream.stream"
                              " | tobytes | length",
                              TESTTLS]) == 19266
    assert fq_json(tmp_path, [*args, "-cV",
                              ".tcp_connections[0].server.stream.stream"
                              " | tobytes | .[0:46]",
                              TESTTLS]) == "HTTP/1.1 200 OK\r\nServer: nginx/1.22.1\r\nContent"
    # AEAD overhead: the 16408 byte record carries 16384 plaintext bytes.
    assert fq_json(tmp_path, [*args, "-cV",
                              ".tcp_connections[0].server.stream.records[6]"
                              " | [(.message|tobytes|length), .length]",
                              TESTTLS]) == [16384, 16408]
    assert fq_json(tmp_path, [*args, "-cV",
                              "[.tcp_connections[0].server.stream.records[]"
                              " | has(\"message\")] | all",
                              TESTTLS]) is True


def test_keylog_decrypts_finished_and_alert(tmp_path):
    """Decryption also covers non-application records: the encrypted
    Finished handshake message (12-byte verify_data) and the closing
    close_notify/warning alert.

    CATCHES: handshake and alert records decrypted through the message
    field, not just application_data.
    """
    args = ["-o", TESTTLS_KEYLOG]
    assert fq_json(tmp_path, [*args, "-cV",
                              ".tcp_connections[0].client.stream.records[3].message"
                              " | {type, vd: (.verify_data|tobytes|length)}",
                              TESTTLS]) == {"type": "finished", "vd": 12}
    assert fq_json(tmp_path, [*args, "-cV",
                              ".tcp_connections[0].client.stream.records[5].message",
                              TESTTLS]) == {
        "description": "close_notify", "level": "warning",
    }


@pytest.mark.parametrize("pcap,suite,port,stream_len,cert", [
    ("tls/TLS_DHE_DSS_WITH_AES_128_CBC_SHA.pcap",
     "TLS_DHE_DSS_WITH_AES_128_CBC_SHA", 4433, 4394, "dsa.crt"),
    ("tls/TLS_RSA_WITH_AES_128_CBC_SHA.pcap",
     "TLS_RSA_WITH_AES_128_CBC_SHA", 4430, 4376, "server.crt"),
])
def test_cipher_corpus_decryption(tmp_path, pcap, suite, port, stream_len,
                                  cert):
    """The ciphersuite corpus captures negotiate deflate compression and
    decrypt (and decompress) the openssl s_server -www page with the shared
    ciphers keylog.

    CATCHES: deflate-compressed record decryption (rezlib) for DHE_DSS and
    RSA CBC suites and the cipher_suit symbol per capture.
    """
    args = ["-o", CIPHERS_KEYLOG, "-d", "pcap"]
    hello = fq_json(tmp_path, [*args, "-cV",
                               ".tcp_connections[0].server.stream.records[0].message"
                               " | {version, cipher_suit, comp: .compression_method}",
                               pcap])
    assert hello == {"version": "tls1.2", "cipher_suit": suite,
                     "comp": "deflate"}
    page = fq_json(tmp_path, [*args, "-cV",
                              ".tcp_connections[0].server.stream.stream | tobytes",
                              pcap])
    assert len(page) == stream_len
    assert page.startswith("HTTP/1.0 200 ok\r\nContent-type: text/html\r\n"
                           "\r\n<HTML><BODY BGCOLOR=\"#ffffff\">\n<pre>\n\n")
    assert f"s_server -accept {port} -cert /tmp/test-certs/{cert}" in page


def test_keylog_without_matching_secret_is_silent(tmp_path):
    """A keylog whose CLIENT_RANDOM does not match the capture (or garbage
    lines, which the NSS parser skips) produces no decryption and no error:
    the encrypted records simply keep their encrypted_data fields.

    CATCHES: the silent no-master-secret path — no message fields, no
    stream key, no error, exit code 0.
    """
    # Garbage lines are ignored by the keylog parser.
    (tmp_path / "garbage.keylog").write_text("not a keylog at all\n")
    for kl in ("keylog=@garbage.keylog", TESTTLS_KEYLOG):
        got = fq_json(tmp_path, ["-o", kl, "-d", "pcap", "-cV",
                                 "{keys: (.tcp_connections[0].server.stream|keys),"
                                 " enc: [.tcp_connections[0].server.stream.records[]"
                                 "       | has(\"encrypted_data\")]}",
                                 "tls/TLS_RSA_WITH_AES_128_CBC_SHA.pcap"])
        assert got == {"keys": ["records"],
                       "enc": [False, False, False, False, False, True, True]}
    disp = run_ok(tmp_path, ["-o", "keylog=@garbage.keylog", "-d", "pcap",
                             "dv", "tls/TLS_RSA_WITH_AES_128_CBC_SHA.pcap"])
    # No decode error at any level (display error lines start with "error").
    assert not [line for line in disp.splitlines()
                if line.lstrip().startswith("error")]
    # The 3 encrypted records still render as raw encrypted_data fields.
    assert "encrypted_data: raw bits 0xfc-0x13c (64)" in disp


@pytest.mark.parametrize("content,err_fragment", [
    ("CLIENT_RANDOM zz zz\n",
     "error: pcap: error at position 0x1b6: failed to parse keylog:"
     " client random error 1: encoding/hex: invalid byte: U+007A 'z'"),
    ("CLIENT_RANDOM aabb aabb\n",
     "error: pcap: error at position 0x1b6: failed to parse keylog:"
     " client random not 32 bytes1:"),
])
def test_broken_keylog_parse_error(tmp_path, content, err_fragment):
    """A keylog line with a valid label but malformed hex aborts the pcap
    decode with the keylog parse error (the decode error is reported in the
    display while the exit code stays 0).

    CATCHES: keylog.Parse error propagation through the tls post-processing
    into the pcap decode error.
    """
    (tmp_path / "bad.keylog").write_text(content)
    disp = run_ok(tmp_path, ["-o", "keylog=@bad.keylog", "-d", "pcap", "dv",
                             "tls/TLS_RSA_WITH_AES_128_CBC_SHA.pcap"])
    assert err_fragment in disp


def test_sslv3_export_capture_not_decrypted(tmp_path):
    """dump-broken.pcapng holds two SSLv3 (version "ssl") connections using
    an export RC2 cipher: even with the matching keylog nothing decrypts —
    the server's three encrypted records keep encrypted_data (8 records
    total) and there is no stream field.

    CATCHES: SSLv3/export-cipher non-decryption (silent per-record decrypt
    failures) and the connection metadata of the broken capture.
    """
    args = ["-o", "keylog=@tls/dump-broken.pcapng.keylog", "-d", "pcapng"]
    got = fq_json(tmp_path, [*args, "-cV",
                             "[.[] | .tcp_connections[] |"
                             " {cport: .client.port, sip: .server.ip,"
                             "  cs: .client.has_start, ce: .client.has_end,"
                             "  cb: .client.skipped_bytes,"
                             "  ss: .server.has_start, se: .server.has_end,"
                             "  fmt: (.server.stream|format),"
                             "  skeys: (.server.stream|keys),"
                             "  hello: .server.stream.records[0].message"
                             "          | {version, cipher_suit,"
                             "             comp: .compression_method},"
                             "  enc: [.server.stream.records[]"
                             "        | has(\"encrypted_data\")]}]",
                             "tls/dump-broken.pcapng"])
    assert got == [
        {"cport": 42555, "sip": "127.0.0.1", "cs": True, "ce": False,
         "cb": 0, "ss": True, "se": True, "fmt": "tls",
         "skeys": ["records"],
         "hello": {"version": "ssl",
                   "cipher_suit": "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5",
                   "comp": "null"},
         "enc": [False, False, False, False, False, True, True, True]},
        # The second connection negotiates IDEA instead, with 7 records.
        {"cport": 52633, "sip": "127.0.0.1", "cs": True, "ce": False,
         "cb": 0, "ss": True, "se": True, "fmt": "tls",
         "skeys": ["records"],
         "hello": {"version": "ssl",
                   "cipher_suit": "TLS_RSA_WITH_IDEA_CBC_SHA",
                   "comp": "null"},
         "enc": [False, False, False, False, True, True, True]},
    ]
    disp = run_ok(tmp_path, [*args, "dv", "tls/dump-broken.pcapng"])
    # Silent per-record failures: no error line anywhere in the display.
    assert not [line for line in disp.splitlines()
                if line.lstrip().startswith("error")]
    assert "version: \"ssl\" (0x300) (valid) 0x1-0x3 (2)" in disp
