"""DNS tests: header flags, question sections, answer records with name
compression, TXT strings, partial decode of garbage, the dns_tcp
length-prefixed framing from reassembled TCP streams, and display of name
labels.

Every expected value below was recorded by running the reference fq binary.
"""

import struct

from conftest import dns_name, eth, fq_json, ipv4, make_pcap, run_ok, udp


def _query(msg_id=0x1234, flags=0x0100, name="www.example.com"):
    hdr = struct.pack(">HHHHHH", msg_id, flags, 1, 0, 0, 0)
    return hdr + dns_name(name) + struct.pack(">HH", 1, 1)


def test_dns_query(tmp_path):
    """A crafted standard query for www.example.com A/IN with RD set.

    CATCHES: DNS header flag symbols (opcode query, rcode no_error), the
    label array including the terminating zero-length label and the
    flattened name value.
    """
    got = fq_json(tmp_path, ["-d", "dns", "-cV", ".", "-"], stdin=_query())
    assert got == {
        "additionals": [], "an_count": 0, "answers": [], "ar_count": 0,
        "header": {"authoritative_answer": False, "id": 4660,
                   "opcode": "query", "qr": "query", "rcode": "no_error",
                   "recursion_available": False, "recursion_desired": True,
                   "truncation": False, "z": 0},
        "nameservers": [], "ns_count": 0, "qd_count": 1,
        "questions": [{"class": "in",
                       "name": {"labels": [{"length": 3, "value": "www"},
                                           {"length": 7, "value": "example"},
                                           {"length": 3, "value": "com"},
                                           {"length": 0}],
                                  "value": "www.example.com"},
                       "type": "a"}],
    }


def test_dns_response_with_compression(tmp_path):
    """A crafted response answering with a compressed name (pointer to
    offset 12): the pointed-to label keeps its own length/value and gains
    is_pointer/pointer fields.

    CATCHES: DNS name compression — pointer labels record both the pointer
    offset and the followed label, and the flattened value still resolves.
    """
    hdr = struct.pack(">HHHHHH", 0xABCD, 0x8180, 1, 1, 0, 0)
    ans = struct.pack(">H", 0xC00C) + struct.pack(">HHIH", 1, 1, 300, 4) \
        + bytes([93, 184, 216, 34])
    got = fq_json(tmp_path, ["-d", "dns", "-cV", ".", "-"],
                  stdin=hdr + dns_name("www.example.com")
                  + struct.pack(">HH", 1, 1) + ans)
    assert got == {
        "additionals": [], "an_count": 1,
        "answers": [{"address": "93.184.216.34", "class": "in",
                     "name": {"labels": [{"is_pointer": 3, "length": 3,
                                          "pointer": 12, "value": "www"},
                                         {"length": 7, "value": "example"},
                                         {"length": 3, "value": "com"},
                                         {"length": 0}],
                              "value": "www.example.com"},
                     "rdlength": 4, "ttl": 300, "type": "a"}],
        "ar_count": 0,
        "header": {"authoritative_answer": False, "id": 43981,
                   "opcode": "query", "qr": "response", "rcode": "no_error",
                   "recursion_available": True, "recursion_desired": True,
                   "truncation": False, "z": 0},
        "nameservers": [], "ns_count": 0, "qd_count": 1,
        "questions": [{"class": "in",
                       "name": {"labels": [{"length": 3, "value": "www"},
                                           {"length": 7, "value": "example"},
                                           {"length": 3, "value": "com"},
                                           {"length": 0}],
                                  "value": "www.example.com"},
                       "type": "a"}],
    }


def test_dns_txt_record(tmp_path):
    """A TXT answer with two character-strings keeps both strings and the
    concatenated value.

    CATCHES: TXT RDATA splitting on 1-byte lengths and the joined value.
    """
    hdr = struct.pack(">HHHHHH", 1, 0x8180, 0, 1, 0, 0)
    txt = dns_name("t.example") + struct.pack(">HHIH", 16, 1, 60, 12) \
        + bytes([5]) + b"hello" + bytes([5]) + b"world"
    got = fq_json(tmp_path, ["-d", "dns", "-cV", ".answers[0]", "-"],
                  stdin=hdr + txt)
    assert got == {"class": "in",
                   "name": {"labels": [{"length": 1, "value": "t"},
                                       {"length": 7, "value": "example"},
                                       {"length": 0}],
                              "value": "t.example"},
                   "rdlength": 12, "ttl": 60,
                   "txt": {"strings": ["hello", "world"], "value": "helloworld"},
                   "type": "txt"}


def test_dns_cern_fixture(tmp_path):
    """cern-rsp: a real response with a CNAME answer (compressed owner and
    target names) followed by an AAAA answer for the target.

    CATCHES: multi-record answers with mixed types, chained compression
    pointers at different offsets and IPv6 address text formatting.
    """
    got = fq_json(tmp_path, ["-d", "dns", "-cV", ".", "dns/cern-rsp"])
    assert got == {
        "additionals": [], "an_count": 2,
        "answers": [
            {"class": "in",
             "cname": {"labels": [{"length": 8, "value": "webrlb02"},
                                  {"is_pointer": 3, "length": 4,
                                   "pointer": 16, "value": "cern"},
                                  {"length": 2, "value": "ch"},
                                  {"length": 0}],
                       "value": "webrlb02.cern.ch"},
             "name": {"labels": [{"is_pointer": 3, "length": 3,
                                  "pointer": 12, "value": "www"},
                                 {"length": 4, "value": "cern"},
                                 {"length": 2, "value": "ch"},
                                 {"length": 0}],
                      "value": "www.cern.ch"},
             "rdlength": 11, "ttl": 4502, "type": "cname"},
            {"address": "2001:1458:201:70::100:27", "class": "in",
             "name": {"labels": [{"is_pointer": 3, "length": 8,
                                  "pointer": 41, "value": "webrlb02"},
                                 {"is_pointer": 3, "length": 4,
                                  "pointer": 16, "value": "cern"},
                                 {"length": 2, "value": "ch"},
                                 {"length": 0}],
                      "value": "webrlb02.cern.ch"},
             "rdlength": 16, "ttl": 4502, "type": "aaaa"}],
        "ar_count": 0,
        "header": {"authoritative_answer": False, "id": 28930,
                   "opcode": "query", "qr": "response", "rcode": "no_error",
                   "recursion_available": True, "recursion_desired": True,
                   "truncation": False, "z": 0},
        "nameservers": [], "ns_count": 0, "qd_count": 1,
        "questions": [{"class": "in",
                       "name": {"labels": [{"length": 3, "value": "www"},
                                           {"length": 4, "value": "cern"},
                                           {"length": 2, "value": "ch"},
                                           {"length": 0}],
                                  "value": "www.cern.ch"},
                       "type": "aaaa"}],
    }


def test_dns_garbage_partial_decode(tmp_path):
    """Twelve 0xff bytes still decode a header (numeric opcode/rcode/z, all
    flags set) and an empty question entry; unknown values stay numeric.

    CATCHES: graceful partial decode — no symbol exists for opcode 15 or
    rcode 15 so they stay numbers, the question list holds one struct with
    only an empty name, and the four RR arrays are dropped entirely (the
    decode failed before them) instead of being emitted as empty lists.
    """
    got = fq_json(tmp_path, ["-d", "dns", "-cV", ".", "-"], stdin=b"\xff" * 12)
    assert got == {
        "an_count": 65535, "ar_count": 65535,
        "header": {"authoritative_answer": True, "id": 65535, "opcode": 15,
                   "qr": "response", "rcode": 15,
                   "recursion_available": True, "recursion_desired": True,
                   "truncation": True, "z": 7},
        "ns_count": 65535, "qd_count": 65535,
        "questions": [{"name": {"labels": [{}]}}],
    }
    # The RR arrays are absent, not empty: keys are missing from the object.
    rrs = fq_json(tmp_path, ["-d", "dns", "-cV",
                             "{questions, answers, nameservers, additionals}",
                             "-"], stdin=b"\xff" * 12)
    assert rrs == {"additionals": None, "answers": None, "nameservers": None,
                   "questions": [{"name": {"labels": [{}]}}]}


def test_dns_tcp_crafted(tmp_path):
    """dns_tcp frames a DNS message with a 2-byte big-endian length prefix
    that shows up as header.length alongside the DNS flags.

    CATCHES: the dns_tcp length-prefix field name and its inclusion in the
    header struct.
    """
    hdr = struct.pack(">HHHHHH", 0xABCD, 0x8180, 1, 1, 0, 0)
    ans = struct.pack(">H", 0xC00C) + struct.pack(">HHIH", 1, 1, 300, 4) \
        + bytes([93, 184, 216, 34])
    msg = hdr + dns_name("www.example.com") + struct.pack(">HH", 1, 1) + ans
    got = fq_json(tmp_path, ["-d", "dns_tcp", "-cV", "{header, questions}", "-"],
                  stdin=struct.pack(">H", len(msg)) + msg)
    assert got["header"] == {"authoritative_answer": False, "id": 43981,
                             "length": 49, "opcode": "query", "qr": "response",
                             "rcode": "no_error", "recursion_available": True,
                             "recursion_desired": True, "truncation": False,
                             "z": 0}
    assert got["questions"] == [{"class": "in",
                                 "name": {"labels": [{"length": 3, "value": "www"},
                                                     {"length": 7, "value": "example"},
                                                     {"length": 3, "value": "com"},
                                                     {"length": 0}],
                                        "value": "www.example.com"},
                                 "type": "a"}]


def test_dns_tcp_from_pcap_streams(tmp_path):
    """dns-tcp.pcap: 20 packets, two client/server connections whose
    reassembled streams decode as dns_tcp in both directions; the client
    asks for google.com A and the server answers 11 records.

    CATCHES: port-53 TCP streams are handed to dns_tcp after reassembly,
    with the length prefix visible on each message.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{n: (.packets|length), conns: [.tcp_connections[] | {cl: {ip: .client.ip, port: .client.port, fmt: (.client.stream|format), len: (.client.stream|tobytes|length)}, sv: {ip: .server.ip, port: .server.port, fmt: (.server.stream|format), len: (.server.stream|tobytes|length)}}]}",
                             "dns/dns-tcp.pcap"])
    assert got == {
        "n": 20,
        "conns": [
            {"cl": {"fmt": "dns_tcp", "ip": "10.180.156.141", "len": 30,
                    "port": 49342},
             "sv": {"fmt": "dns_tcp", "ip": "10.2.95.39", "len": 342,
                    "port": "domain"}},
            {"cl": {"fmt": "dns_tcp", "ip": "10.180.156.141", "len": 27,
                    "port": 49343},
             "sv": {"fmt": "dns_tcp", "ip": "10.2.95.39", "len": 258,
                    "port": "domain"}}],
    }
    cli = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             ".tcp_connections[0].client.stream | {length: .header.length, id: .header.id, q: .questions[0]}",
                             "dns/dns-tcp.pcap"])
    assert cli == {"id": 24163, "length": 28,
                   "q": {"class": "in",
                         "name": {"labels": [{"length": 6, "value": "google"},
                                             {"length": 3, "value": "com"},
                                             {"length": 0}],
                                "value": "google.com"},
                         "type": "a"}}
    srv = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             ".tcp_connections[0].server.stream | {length: .header.length, id: .header.id, qr: .header.qr, q: .questions[0].name.value, an: (.answers|length)}",
                             "dns/dns-tcp.pcap"])
    assert srv == {"an": 11, "id": 24163, "length": 340, "q": "google.com",
                   "qr": "response"}


def test_dns_name_display(tmp_path):
    """The verbose display of a question name shows the label structs with
    per-label length/value and the final flattened value line.

    CATCHES: dv display of DNS names — label structs and the joined value
    annotation.
    """
    disp = run_ok(tmp_path, ["-d", "dns", ".questions[0].name | dv", "-"],
                  stdin=_query(name="a.example"))
    assert disp == """\
    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.questions[0].name{}: 0xc-0x17 (11)
    |                                               |                |  labels[0:3]: 0xc-0x17 (11)
    |                                               |                |    [0]{}: label 0xc-0xe (2)
0x00|                                    01         |            .   |      length: 1 0xc-0xd (1)
0x00|                                       61      |             a  |      value: "a" 0xd-0xe (1)
    |                                               |                |    [1]{}: label 0xe-0x16 (8)
0x00|                                          07   |              . |      length: 7 0xe-0xf (1)
0x00|                                             65|               e|      value: "example" 0xf-0x16 (7)
0x10|78 61 6d 70 6c 65                              |xample          |
    |                                               |                |    [2]{}: label 0x16-0x17 (1)
0x10|                  00                           |      .         |      length: 0 0x16-0x17 (1)
    |                                               |                |  value: "a.example\""""


def test_mdns_stack_dispatch(tmp_path):
    """An ethernet/IPv4/UDP frame to 5353 decodes all the way into the DNS
    question, including the mDNS multicast destination address.

    CATCHES: full-stack dispatch to dns on UDP port 5353 with IPv4 multicast
    addressing preserved.
    """
    frame = eth("ff:ff:ff:ff:ff:ff", "00:11:22:33:44:55", 0x0800,
                ipv4("1.2.3.4", "224.0.0.251", 17,
                     udp(5353, 5353, _query())))
    got = fq_json(tmp_path, ["-d", "ether8023_frame", "-cV",
                             ".payload.payload.payload | {header, questions}", "-"],
                  stdin=frame)
    assert got == {
        "header": {"authoritative_answer": False, "id": 4660,
                   "opcode": "query", "qr": "query", "rcode": "no_error",
                   "recursion_available": False, "recursion_desired": True,
                   "truncation": False, "z": 0},
        "questions": [{"class": "in",
                       "name": {"labels": [{"length": 3, "value": "www"},
                                           {"length": 7, "value": "example"},
                                           {"length": 3, "value": "com"},
                                           {"length": 0}],
                                  "value": "www.example.com"},
                       "type": "a"}],
    }
    # The same frame inside a pcap file: the stack must behave identically.
    got2 = fq_json(tmp_path, ["-d", "pcap", "-cV",
                              ".packets[0].packet.payload.payload.payload.questions[0].name.value",
                              "-"], stdin=make_pcap([frame]))
    assert got2 == "www.example.com"
