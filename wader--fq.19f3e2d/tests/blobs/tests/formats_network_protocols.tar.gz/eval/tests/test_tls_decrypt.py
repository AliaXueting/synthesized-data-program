"""TLS record-layer decryption tests: cipher-suite matrix and PRF variants.

tls/dump.pcapng holds 73 TLS 1.2 connections, one per cipher suite, all
sharing one NSS keylog; 62 of them decrypt end to end.  That matrix covers
every record cipher and MAC the tlsdecrypt package implements for TLS 1.2
(RC4, DES, 3DES, AES-CBC with SHA-1/SHA-256/SHA-384 MACs, AES-GCM and the
40-bit export key schedule).  The suites fq cannot decrypt stay encrypted.

The remaining tests craft captures by hand for the key schedules no
checked-in capture exercises: the TLS 1.0 PRF, the SSLv3 PRF with its
export key schedule, and the ChaCha20-Poly1305 record layer.  The crafted
records are encrypted with the exact key derivation they assert, so a
decoder that derives keys differently cannot produce the recorded output.
Every expected value below was recorded by running the reference fq binary.
"""

import hashlib
import hmac
import struct

import pytest

from conftest import eth, fq_json, ipv4, make_pcap, run_on, tcp

DUMP = "tls/dump.pcapng"
DUMP_KEYLOG = "keylog=@tls/dump.pcapng.keylog"
CHACHA = "tls/tls_chacha20.pcap"
CHACHA_KEYLOG = "keylog=@tls/tls_chacha20.keylog"

GET_REQUEST = "GET / HTTP/1.0\r\n\r\n"

# ----------------------------------------------------------------- matrix
# One connection of dump.pcapng per record cipher / MAC / key schedule:
# (client port, suite symbol, compression, OpenSSL cipher name reported by
#  the decrypted s_server page, decrypted server stream length)
CIPHER_MATRIX = [
    (38964, "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384", "deflate",
     "ECDHE-RSA-AES256-GCM-SHA384", 4427),
    (42376, "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384", "deflate",
     "ECDHE-ECDSA-AES256-GCM-SHA384", 4447),
    (38984, "TLS_RSA_WITH_AES_256_GCM_SHA384", "deflate",
     "AES256-GCM-SHA384", 4397),
    (38966, "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384", "deflate",
     "ECDHE-RSA-AES256-SHA384", 4415),
    (38985, "TLS_RSA_WITH_AES_256_CBC_SHA256", "deflate",
     "AES256-SHA256", 4385),
    (39017, "TLS_RSA_WITH_AES_128_GCM_SHA256", "deflate",
     "AES128-GCM-SHA256", 4397),
    (39018, "TLS_RSA_WITH_AES_128_CBC_SHA256", "deflate",
     "AES128-SHA256", 4385),
    (38994, "TLS_RSA_WITH_3DES_EDE_CBC_SHA", "deflate", "DES-CBC3-SHA", 4382),
    (38988, "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA", "deflate",
     "ECDHE-RSA-DES-CBC3-SHA", 4412),
    (39027, "TLS_RSA_WITH_RC4_128_SHA", "deflate", "RC4-SHA", 4367),
    (39028, "TLS_RSA_WITH_RC4_128_MD5", "null", "RC4-MD5", 4393),
    (42437, "TLS_ECDH_ECDSA_WITH_RC4_128_SHA", "deflate",
     "ECDH-ECDSA-RC4-SHA", 4414),
    (39031, "TLS_RSA_WITH_DES_CBC_SHA", "deflate", "DES-CBC-SHA", 4379),
    (39032, "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA", "deflate",
     "EXP-EDH-RSA-DES-CBC-SHA", 4415),
    (39034, "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA", "deflate",
     "EXP-DES-CBC-SHA", 4391),
    (39036, "TLS_RSA_EXPORT_WITH_RC4_40_MD5", "null", "EXP-RC4-MD5", 4405),
]

# The 11 connections whose suite fq has no cipher implementation for
# (CAMELLIA, SEED, IDEA, RC2 export): the handshake records decode, and
# every record after ChangeCipherSpec stays encrypted_data.  DHE suites
# carry one extra ServerKeyExchange handshake record; port 39035 opens
# with an SSLv2-format ClientHello, so its client stream has an ssl_v2
# struct and one record fewer.  (client port, suite symbol, server record
# count, client stream keys, client encrypted-record flags)
UNSUPPORTED = [
    (38976, "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA", 8, ["records"],
     [False, False, False, True, True, True]),
    (56718, "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA", 8, ["records"],
     [False, False, False, True, True, True]),
    (38987, "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA", 7, ["records"],
     [False, False, False, True, True, True]),
    (39007, "TLS_DHE_RSA_WITH_SEED_CBC_SHA", 8, ["records"],
     [False, False, False, True, True, True]),
    (56749, "TLS_DHE_DSS_WITH_SEED_CBC_SHA", 8, ["records"],
     [False, False, False, True, True, True]),
    (39009, "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA", 8, ["records"],
     [False, False, False, True, True, True]),
    (56751, "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA", 8, ["records"],
     [False, False, False, True, True, True]),
    (39020, "TLS_RSA_WITH_SEED_CBC_SHA", 7, ["records"],
     [False, False, False, True, True, True]),
    (39021, "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA", 7, ["records"],
     [False, False, False, True, True, True]),
    (39022, "TLS_RSA_WITH_IDEA_CBC_SHA", 7, ["records"],
     [False, False, False, True, True, True]),
    (39035, "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5", 7, ["ssl_v2", "records"],
     [False, False, True, True, True]),
]


def _dump_conn_expr(port):
    """Query one dump.pcapng connection by its client port."""
    return (
        f'[.[] | .tcp_connections[]? | select(.client.port == {port}) | '
        '{suite: .server.stream.records[0].message.cipher_suit,'
        ' comp: .server.stream.records[0].message.compression_method,'
        ' request: (.client.stream.stream|tobytes|tostring),'
        ' page_cipher: (.server.stream.stream|tobytes|tostring'
        '   | capture("New, TLSv1/SSLv3, Cipher is (?<c>[A-Z0-9-]+)").c),'
        ' len: (.server.stream.stream|tobytes|length)}]'
    )


@pytest.mark.parametrize("port,suite,comp,openssl_name,stream_len",
                         CIPHER_MATRIX,
                         ids=[s for _, s, _, _, _ in CIPHER_MATRIX])
def test_dump_cipher_matrix(tmp_path, port, suite, comp, openssl_name,
                            stream_len):
    """Every implemented cipher suite decrypts both directions of its
    connection: the client stream is the 18-byte GET request and the server
    stream is the s_server page, which names the negotiated OpenSSL cipher
    and therefore has a distinct length per suite.

    CATCHES: per-suite key derivation plus the record cipher itself - RC4
    keystream, single DES and 3DES, AES-CBC with SHA-1/SHA-256/SHA-384 MACs,
    AES-GCM AEAD, and the 40-bit export key schedule with its re-expanded
    write keys.  A wrong key schedule for any one suite yields no stream.
    """
    got = fq_json(tmp_path, ["-o", DUMP_KEYLOG, "-d", "pcapng", "-cV",
                             _dump_conn_expr(port), DUMP])
    assert got == [{
        "suite": suite, "comp": comp, "request": GET_REQUEST,
        "page_cipher": openssl_name, "len": stream_len,
    }]


def test_dump_unsupported_suites_stay_encrypted(tmp_path):
    """The 11 connections negotiating a suite fq has no implementation for
    (CAMELLIA, SEED, IDEA, RC2 export) decode their handshakes but keep
    every post-ChangeCipherSpec record as encrypted_data, with no stream
    field in either direction, no decode error, and 62 of the 73
    connections decrypted.

    CATCHES: the silent unsupported-suite path - the suite symbol is still
    resolved, records are only queued as encrypted_data, and neither
    direction grows a decrypted stream nor an error.
    """
    got = fq_json(tmp_path, ["-o", DUMP_KEYLOG, "-d", "pcapng", "-cV",
                             '[.[] | .tcp_connections[]?'
                             ' | select((.server.stream|has("stream"))|not)'
                             ' | {port: .client.port,'
                             '    suite: .server.stream.records[0].message.cipher_suit,'
                             '    ckeys: (.client.stream|keys),'
                             '    skeys: (.server.stream|keys),'
                             '    cenc: [.client.stream.records[] | has("encrypted_data")],'
                             '    senc: [.server.stream.records[] | has("encrypted_data")]}]',
                             DUMP])
    assert got == [{"port": port, "suite": suite, "ckeys": ckeys,
                    "skeys": ["records"], "cenc": cenc,
                    "senc": [False] * (srecs - 2) + [True, True]}
                   for port, suite, srecs, ckeys, cenc in UNSUPPORTED]
    counts = fq_json(tmp_path, ["-o", DUMP_KEYLOG, "-d", "pcapng", "-cV",
                                '{n: ([.[] | .tcp_connections[]?]|length),'
                                ' decrypted: ([.[] | .tcp_connections[]?'
                                '  | select(.server.stream|has("stream"))]|length),'
                                ' versions: ([.[] | .tcp_connections[]?'
                                '  | .server.stream.records[0].message.version]|unique),'
                                ' cfmt: ([.[] | .tcp_connections[]?'
                                '  | .client.stream|format]|unique),'
                                ' sports: ([.[] | .tcp_connections[]?'
                                '  | .server.port]|unique)}',
                                DUMP])
    assert counts == {"n": 73, "decrypted": 62, "versions": ["tls1.2"],
                      "cfmt": ["tls"], "sports": [4430, 4431, 4432, 4433]}
    # The display renders the undecrypted records as raw encrypted_data and
    # reports no error anywhere in the file.
    res = run_on(tmp_path, ["-o", DUMP_KEYLOG, "-d", "pcapng", "dv", DUMP],
                 timeout=30)
    assert res.returncode == 0
    text = res.stdout.decode("utf-8", "replace")
    assert not [line for line in text.splitlines()
                if line.lstrip().startswith("error")]
    assert "encrypted_data: raw bits 0xfc-0x12d (49)" in text


def test_dump_sslv2_client_hello_connection(tmp_path):
    """The RC2-export connection (client port 39035) opens with an SSLv2
    compatible ClientHello, so its client stream carries an ssl_v2 struct
    alongside the records array: keys returns them in decode order, the
    three offered cipher specs resolve to symbols (two export RC2 suites
    and the renegotiation SCSV), and the negotiated TLS version is the
    raw 771 rather than a symbol.

    CATCHES: the SSLv2-format ClientHello detection (record header with
    high bit set) inside a TLS capture, its length fields, and the
    symbol-mapped 3-byte cipher specs.
    """
    got = fq_json(tmp_path, ["-o", DUMP_KEYLOG, "-d", "pcapng", "-cV",
                             '[.[] | .tcp_connections[]?'
                             ' | select(.client.port == 39035)'
                             ' | {keys: (.client.stream|keys),'
                             '    skeys: (.server.stream|keys),'
                             '    v2: (.client.stream.ssl_v2'
                             '      | {type, length, tls_version,'
                             '         cipher_spec_length, session_id_length,'
                             '         challenge_length,'
                             '         specs: [.cipher_specs[]]}),'
                             '    suite: .server.stream.records[0].message.cipher_suit}]',
                             DUMP])
    assert got == [{"keys": ["ssl_v2", "records"], "skeys": ["records"],
                    "v2": {"type": 1, "length": 50, "tls_version": 771,
                           "cipher_spec_length": 9, "session_id_length": 0,
                           "challenge_length": 32,
                           "specs": ["TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5",
                                     "SSL_CK_RC2_128_CBC_EXPORT40_WITH_MD5",
                                     "TLS_EMPTY_RENEGOTIATION_INFO_SCSV"]},
                    "suite": "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5"}]


# -------------------------------------------------------------- crafting
# Byte-level TLS building blocks for the hand-made captures below.  The
# layouts follow the RFCs; the reference binary is what decides that they
# decode and decrypt.

TLS10 = 0x0301
SSL30 = 0x0300
RC4_SHA = 0x0005              # TLS_RSA_WITH_RC4_128_SHA
EXPORT_RC4_MD5 = 0x0003       # TLS_RSA_EXPORT_WITH_RC4_40_MD5

CLIENT_PAYLOAD = b"tls10-client-request-payload"
SERVER_PAYLOAD = b"tls10-server-response-payload"
SSL3_CLIENT_PAYLOAD = b"ssl3-export-client-payload"
SSL3_SERVER_PAYLOAD = b"ssl3-export-server-payload"
CHACHA_CLIENT_PAYLOAD = b"chacha20-client-request"
CHACHA_SERVER_PAYLOAD = b"chacha20-server-response-payload"


def _rc4(key):
    """RC4 key scheduling plus a stateful keystream XOR (stream records of
    one direction share a single cipher state, as in the record layer)."""
    s, j = list(range(256)), 0
    for i in range(256):
        j = (j + s[i] + key[i % len(key)]) & 0xFF
        s[i], s[j] = s[j], s[i]
    # PRGA state starts fresh: the KSA's final j is not carried over.
    state = [0, 0]

    def crypt(data):
        i, j = state
        out = bytearray()
        for byte in data:
            i = (i + 1) & 0xFF
            j = (j + s[i]) & 0xFF
            s[i], s[j] = s[j], s[i]
            out.append(byte ^ s[(s[i] + s[j]) & 0xFF])
        state[0], state[1] = i, j
        return bytes(out)

    return crypt


def _p_hash(length, secret, seed, digest):
    """P_hash: HMAC blocks chained through A(1), A(2), ... (RFC 2246 5)."""
    out = b""
    a = hmac.new(secret, seed, digest).digest()
    while len(out) < length:
        out += hmac.new(secret, a + seed, digest).digest()
        a = hmac.new(secret, a, digest).digest()
    return out[:length]


def _prf10(length, secret, label, seed):
    """The TLS 1.0/1.1 PRF: MD5 over the first half of the secret XORed
    with SHA-1 over the second half (RFC 2246 section 5)."""
    label_seed = label + seed
    first = secret[: (len(secret) + 1) // 2]
    second = secret[len(secret) // 2:]
    md5 = _p_hash(length, first, label_seed, hashlib.md5)
    sha1 = _p_hash(length, second, label_seed, hashlib.sha1)
    return bytes(a ^ b for a, b in zip(md5, sha1))


def _prf30(length, secret, seed):
    """The SSLv3 PRF: MD5(secret || SHA1('A'*n || secret || seed)) per
    16-byte round, n = 1, 2, ... (draft302 section 6)."""
    out, i = b"", 0
    while len(out) < length:
        digest = hashlib.sha1(bytes([0x41 + i]) * (i + 1) + secret
                              + seed).digest()
        out += hashlib.md5(secret + digest).digest()
        i += 1
    return out[:length]


def _handshake(msg_type, body):
    return bytes([msg_type]) + len(body).to_bytes(3, "big") + body


def _record(rec_type, version, payload):
    return (bytes([rec_type])
            + struct.pack(">HH", version, len(payload)) + payload)


def _client_hello(version, random, suites):
    body = (struct.pack(">H", version) + random + b"\x00"
            + struct.pack(">H", 2 * len(suites))
            + b"".join(struct.pack(">H", s) for s in suites) + b"\x01\x00")
    return _record(0x16, version, _handshake(1, body))


def _server_hello(version, random, suite, comp=0):
    body = (struct.pack(">H", version) + random + b"\x00"
            + struct.pack(">H", suite) + bytes([comp]))
    return _record(0x16, version, _handshake(2, body))


def _mac_record(crypt, mac_key, seq, rec_type, version, plaintext, digest):
    """An RC4 record carrying plaintext plus the TLS 1.0 MAC
    HMAC(seq || type || version || len(plaintext) || plaintext)."""
    mac = hmac.new(mac_key,
                   struct.pack(">Q", seq) + bytes([rec_type])
                   + struct.pack(">HH", version, len(plaintext)) + plaintext,
                   digest).digest()
    payload = crypt(plaintext + mac)
    return _record(rec_type, version, payload)


def _session_pcap(client_bytes, server_bytes, cport):
    """A pcap with one TCP session: SYN, SYN/ACK, ACK, client records,
    ACK, server records, ACK - enough for the flow engine to mark both
    directions has_start and hand the streams to the tls format."""
    cip, sip = "10.0.0.1", "10.0.0.2"
    isn_c, isn_s = 1000, 2000

    def frame(src, dst, seg):
        return eth("aa:bb:cc:dd:ee:ff", "11:22:33:44:55:66", 0x0800,
                   ipv4(src, dst, 6, seg))

    return make_pcap([
        frame(cip, sip, tcp(cport, 443, isn_c, 0, 0x02)),
        frame(sip, cip, tcp(443, cport, isn_s, isn_c + 1, 0x12)),
        frame(cip, sip, tcp(cport, 443, isn_c + 1, isn_s + 1, 0x10)),
        frame(cip, sip, tcp(cport, 443, isn_c + 1, isn_s + 1, 0x18,
                            client_bytes)),
        frame(sip, cip, tcp(443, cport, isn_s + 1,
                            isn_c + 1 + len(client_bytes), 0x10)),
        frame(sip, cip, tcp(443, cport, isn_s + 1,
                            isn_c + 1 + len(client_bytes), 0x18,
                            server_bytes)),
        frame(cip, sip, tcp(cport, 443, isn_c + 1 + len(client_bytes),
                            isn_s + 1 + len(server_bytes), 0x10)),
    ])


def _keylog_text(client_random, master_secret):
    return "CLIENT_RANDOM %s %s\n" % (client_random.hex().upper(),
                                      master_secret.hex().upper())


CLIENT_RANDOM = bytes(range(32))
SERVER_RANDOM = bytes(range(32, 64))
MASTER_SECRET = bytes((i * 7 + 3) & 0xFF for i in range(48))


def _tls10_session():
    """The RC4-SHA session bytes and keylog of a TLS 1.0 handshake whose
    key block comes from the TLS 1.0 PRF (20 MAC + 16 key bytes x 2)."""
    key_block = _prf10(72, MASTER_SECRET, b"key expansion",
                       SERVER_RANDOM + CLIENT_RANDOM)
    client_mac, server_mac = key_block[0:20], key_block[20:40]
    client_key, server_key = key_block[40:56], key_block[56:72]
    ccrypt, scrypt = _rc4(client_key), _rc4(server_key)

    client_bytes = b"".join([
        _client_hello(TLS10, CLIENT_RANDOM, [RC4_SHA]),
        _record(0x16, TLS10, _handshake(16, struct.pack(">H", 2) + b"\x03\x01")),
        _record(0x14, TLS10, b"\x00"),
        _mac_record(ccrypt, client_mac, 0, 0x16, TLS10,
                    _handshake(20, b"CATCHESPRF10"), hashlib.sha1),
        _mac_record(ccrypt, client_mac, 1, 0x17, TLS10,
                    CLIENT_PAYLOAD, hashlib.sha1),
        _mac_record(ccrypt, client_mac, 2, 0x15, TLS10, b"\x01\x00",
                    hashlib.sha1),
    ])
    server_bytes = b"".join([
        _server_hello(TLS10, SERVER_RANDOM, RC4_SHA),
        _record(0x16, TLS10, _handshake(14, b"")),
        _record(0x14, TLS10, b"\x00"),
        _mac_record(scrypt, server_mac, 0, 0x16, TLS10,
                    _handshake(20, b"SERVERPRF10AA"), hashlib.sha1),
        _mac_record(scrypt, server_mac, 1, 0x17, TLS10,
                    SERVER_PAYLOAD, hashlib.sha1),
    ])
    return client_bytes, server_bytes, _keylog_text(CLIENT_RANDOM,
                                                    MASTER_SECRET)


def test_tls10_rc4_prf10_records_decrypt(tmp_path):
    """A hand-crafted TLS 1.0 RC4-SHA session decrypts in both directions:
    every record gains a message field, the decrypted Finished keeps its
    12-byte verify_data, the alert decodes as close_notify/warning, and the
    application_data records become the exact plaintext strings.  Without
    the keylog the same capture keeps three encrypted records.

    CATCHES: the TLS 1.0 PRF (MD5 of the secret's first half XOR SHA-1 of
    the second, over "key expansion" + serverRandom||clientRandom) and the
    TLS 1.0 MAC sequence-number/header construction - any deviation leaves
    the records encrypted.
    """
    client_bytes, server_bytes, keylog = _tls10_session()
    (tmp_path / "tls10.keylog").write_text(keylog)
    pcap = _session_pcap(client_bytes, server_bytes, 44511)

    got = fq_json(tmp_path, ["-o", "keylog=@tls10.keylog", "-d", "pcap",
                             "-cV",
                             '[.tcp_connections[] |'
                             '{version: .server.stream.records[0].message.version,'
                             ' suite: .server.stream.records[0].message.cipher_suit,'
                             ' crecs: [.client.stream.records[]'
                             '   | {type, len: .length, msg: has("message"),'
                             '      enc: has("encrypted_data")}],'
                             ' srecs: [.server.stream.records[].type],'
                             ' finished: .client.stream.records[3].message,'
                             ' alert: .client.stream.records[5].message,'
                             ' client: (.client.stream.stream|tobytes|tostring),'
                             ' server: (.server.stream.stream|tobytes|tostring)}]',
                             "-"], stdin=pcap)
    assert got == [{
        "version": "tls1.0", "suite": "TLS_RSA_WITH_RC4_128_SHA",
        "crecs": [
            {"type": "handshake", "len": 45, "msg": True, "enc": False},
            {"type": "handshake", "len": 8, "msg": True, "enc": False},
            {"type": "change_cipher_spec", "len": 1, "msg": True,
             "enc": False},
            {"type": "handshake", "len": 36, "msg": True, "enc": True},
            {"type": "application_data", "len": 48, "msg": True,
             "enc": True},
            {"type": "alert", "len": 22, "msg": True, "enc": True}],
        "srecs": ["handshake", "handshake", "change_cipher_spec",
                  "handshake", "application_data"],
        "finished": {"type": "finished", "length": 12,
                     "verify_data": "CATCHESPRF10"},
        "alert": {"description": "close_notify", "level": "warning"},
        "client": CLIENT_PAYLOAD.decode(),
        "server": SERVER_PAYLOAD.decode(),
    }]
    # Same capture without a keylog: nothing decrypts, no stream field.
    plain = fq_json(tmp_path, ["-d", "pcap", "-cV",
                               '{ckeys: (.tcp_connections[0].client.stream|keys),'
                               ' skeys: (.tcp_connections[0].server.stream|keys),'
                               ' cenc: [.tcp_connections[0].client.stream.records[]'
                               '        | has("encrypted_data")]}',
                               "-"], stdin=pcap)
    assert plain == {"ckeys": ["records"], "skeys": ["records"],
                     "cenc": [False, False, False, True, True, True]}


def test_sslv3_export_rc4_prf30_records_decrypt(tmp_path):
    """A hand-crafted SSLv3 session negotiating the 40-bit export RC4-MD5
    suite decrypts in both directions.  The keys follow the SSLv3 export
    schedule: 5-byte write keys expanded to 16 bytes by MD5, the client one
    over clientRandom||serverRandom and the server one over the swapped
    serverRandom||clientRandom seed, with HMAC-MD5 record MACs.

    CATCHES: the SSLv3 PRF ('A'-prefixed SHA-1 rounds) and the export key
    expansion, including the server write key being derived from the
    swapped seed - an RFC-only implementation derives a different server
    key and the server direction stays encrypted.
    """
    client_random = bytes(range(1, 33))
    server_random = bytes(range(33, 65))
    master_secret = bytes((i * 11 + 5) & 0xFF for i in range(48))

    # 2*16 MAC bytes + 2*5 raw write-key bytes from the SSLv3 PRF.
    seed = server_random + client_random
    material = _prf30(42, master_secret, seed)
    client_mac, server_mac = material[0:16], material[16:32]
    raw_client_key, raw_server_key = material[32:37], material[37:42]
    export_seed = client_random + server_random
    client_key = hashlib.md5(raw_client_key + export_seed).digest()
    server_key = hashlib.md5(raw_server_key + seed).digest()
    ccrypt, scrypt = _rc4(client_key), _rc4(server_key)

    client_bytes = b"".join([
        _client_hello(SSL30, client_random, [EXPORT_RC4_MD5]),
        _record(0x16, SSL30, _handshake(16, struct.pack(">H", 2) + b"\x03\x00")),
        _record(0x14, SSL30, b"\x00"),
        _mac_record(ccrypt, client_mac, 0, 0x16, SSL30,
                    _handshake(20, b"SSL3CLIENTF!"), hashlib.md5),
        _mac_record(ccrypt, client_mac, 1, 0x17, SSL30,
                    SSL3_CLIENT_PAYLOAD, hashlib.md5),
    ])
    server_bytes = b"".join([
        _server_hello(SSL30, server_random, EXPORT_RC4_MD5),
        _record(0x16, SSL30, _handshake(14, b"")),
        _record(0x14, SSL30, b"\x00"),
        _mac_record(scrypt, server_mac, 0, 0x16, SSL30,
                    _handshake(20, b"SSL3SERVERF!"), hashlib.md5),
        _mac_record(scrypt, server_mac, 1, 0x17, SSL30,
                    SSL3_SERVER_PAYLOAD, hashlib.md5),
    ])
    (tmp_path / "ssl3export.keylog").write_text(
        _keylog_text(client_random, master_secret))
    pcap = _session_pcap(client_bytes, server_bytes, 44512)

    got = fq_json(tmp_path, ["-o", "keylog=@ssl3export.keylog", "-d", "pcap",
                             "-cV",
                             '[.tcp_connections[] |'
                             '{version: .server.stream.records[0].message.version,'
                             ' suite: .server.stream.records[0].message.cipher_suit,'
                             ' comp: .server.stream.records[0].message.compression_method,'
                             ' crecs: [.client.stream.records[]'
                             '   | {type, len: .length, msg: has("message")}],'
                             ' verify_data: (.client.stream.records[3].message.verify_data'
                             '               | tobytes | tohex),'
                             ' client: (.client.stream.stream|tobytes|tostring),'
                             ' server: (.server.stream.stream|tobytes|tostring)}]',
                             "-"], stdin=pcap)
    assert got == [{
        "version": "ssl", "suite": "TLS_RSA_EXPORT_WITH_RC4_40_MD5",
        "comp": "null",
        "crecs": [
            {"type": "handshake", "len": 45, "msg": True},
            {"type": "handshake", "len": 8, "msg": True},
            {"type": "change_cipher_spec", "len": 1, "msg": True},
            {"type": "handshake", "len": 32, "msg": True},
            {"type": "application_data", "len": 42, "msg": True}],
        "verify_data": "53534c33434c49454e544621",
        "client": SSL3_CLIENT_PAYLOAD.decode(),
        "server": SSL3_SERVER_PAYLOAD.decode(),
    }]


def test_sslv3_nonexport_suite_panics(tmp_path):
    """An SSLv3 connection negotiating the non-export RC4-SHA suite with a
    matching keylog crashes the decoder: the key schedule has no SSLv3
    PRF branch for non-export suites, so the process exits 2 with "panic:
    unknown version" on stderr and no output at all.  But the crash needs
    the server direction to have sent its own ChangeCipherSpec - that is
    what activates the negotiated suite for decryption; without it the
    suite stays the null suite, which no cipher table entry exists for, so
    the same capture decodes normally with every post-CCS record left as
    encrypted_data.

    CATCHES: two suite-activation details - decryption is silently skipped
    (not even attempted, exit 0) until the server's ChangeCipherSpec
    promotes the negotiated suite, and once it does, SSLv3 non-export key
    derivation is a hard panic with exit code 2.
    """
    client_random = bytes(range(2, 34))
    server_random = bytes(range(34, 66))
    master_secret = bytes((i * 3 + 1) & 0xFF for i in range(48))
    key_block = _prf10(72, master_secret, b"key expansion",
                       server_random + client_random)
    ccrypt = _rc4(key_block[40:56])
    client_bytes = b"".join([
        _client_hello(SSL30, client_random, [RC4_SHA]),
        _record(0x16, SSL30, _handshake(16, struct.pack(">H", 2) + b"\x03\x00")),
        _record(0x14, SSL30, b"\x00"),
        # The record body never decrypts: the key schedule panics on the
        # very first Decrypt call, so any well-formed bytes will do.
        _mac_record(ccrypt, key_block[0:20], 0, 0x16, SSL30,
                    _handshake(20, b"SSL3PLAINXF!"), hashlib.sha1),
    ])
    server_hello_only = _server_hello(SSL30, server_random, RC4_SHA)
    server_bytes = server_hello_only + b"".join([
        _record(0x16, SSL30, _handshake(14, b"")),
        _record(0x14, SSL30, b"\x00"),
        # Encrypted server records: never reached, the client direction
        # panics first; only their framing is parsed.
        _record(0x16, SSL30, b"\x00" * 36),
        _record(0x17, SSL30, b"\x00" * 49),
    ])
    (tmp_path / "ssl3panic.keylog").write_text(
        _keylog_text(client_random, master_secret))

    # Without the server ChangeCipherSpec the suite never activates: the
    # null suite has no cipher table entry, decryption errors are swallowed
    # and the capture decodes normally.
    quiet = fq_json(tmp_path, ["-o", "keylog=@ssl3panic.keylog", "-d", "pcap",
                               "-cV",
                               '{ck: (.tcp_connections[0].client.stream|keys),'
                               ' cenc: [.tcp_connections[0].client.stream.records[]'
                               '        | has("encrypted_data")],'
                               ' srecs: [.tcp_connections[0].server.stream.records[].type]}',
                               "-"],
                    stdin=_session_pcap(client_bytes, server_hello_only, 44513))
    assert quiet == {"ck": ["records"],
                     "cenc": [False, False, False, True],
                     "srecs": ["handshake"]}

    # With it, the SSLv3 non-export key schedule panics on the first
    # encrypted record: exit 2, no stdout, the panic line on stderr.
    res = run_on(tmp_path, ["-o", "keylog=@ssl3panic.keylog", "-d", "pcap",
                            "-cV", ".tcp_connections[0].client.stream|keys",
                            "-"],
                 stdin=_session_pcap(client_bytes, server_bytes, 44513))
    assert res.returncode == 2
    assert res.stdout == b""
    assert res.stderr.startswith(b"panic: unknown version")


def test_tls12_chacha20_poly1305_decrypts(tmp_path):
    """The crafted TLS 1.2 ChaCha20-Poly1305 capture decrypts in both
    directions.  Its records use the AEAD layout: no explicit nonce and no
    separate MAC, the 16-byte Poly1305 tag counted in the record length,
    the 8-byte sequence number XORed into bytes 4..12 of the 12-byte IV
    from the key block, and the AAD seq||type||version||plaintext length.

    CATCHES: the ChaCha20-Poly1305 record layer - the XOR nonce
    construction and the tag-inside-length accounting - which no other
    capture in the corpus negotiates.
    """
    got = fq_json(tmp_path, ["-o", CHACHA_KEYLOG, "-d", "pcap", "-cV",
                             '[.tcp_connections[] |'
                             '{version: .server.stream.records[0].message.version,'
                             ' suite: .server.stream.records[0].message.cipher_suit,'
                             ' crecs: [.client.stream.records[]'
                             '   | {type, len: .length, msg: has("message")}],'
                             ' srecs: [.server.stream.records[].length],'
                             ' verify_data: (.client.stream.records[3].message.verify_data'
                             '               | tobytes | tohex),'
                             ' client: (.client.stream.stream|tobytes|tostring),'
                             ' server: (.server.stream.stream|tobytes|tostring)}]',
                             CHACHA])
    assert got == [{
        "version": "tls1.2",
        "suite": "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256",
        "crecs": [
            {"type": "handshake", "len": 45, "msg": True},
            {"type": "handshake", "len": 37, "msg": True},
            {"type": "change_cipher_spec", "len": 1, "msg": True},
            {"type": "handshake", "len": 32, "msg": True},
            {"type": "application_data", "len": 39, "msg": True}],
        "srecs": [42, 4, 1, 32, 48],
        "verify_data": "434841434841434c49454e54",
        "client": CHACHA_CLIENT_PAYLOAD.decode(),
        "server": CHACHA_SERVER_PAYLOAD.decode(),
    }]
