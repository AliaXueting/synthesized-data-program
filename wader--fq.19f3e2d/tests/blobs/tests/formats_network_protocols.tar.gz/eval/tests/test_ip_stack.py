"""Network and transport layer tests: IPv4 header fields, protocol
dispatch, header checksum validation, options, fragment flag bits, IPv6
(fixed header, flow label, extension headers), ICMP/ICMPv6 and UDP
port-symbol dispatch.

Every expected value below was recorded by running the reference fq binary.
"""

import struct

import pytest
from conftest import dns_name, fq_json, ipv4, ipv6, run_ok, udp


def test_ipv4_fields_and_udp_dispatch(tmp_path):
    """A crafted IPv4 packet to UDP port 53 decodes every header field and
    the UDP destination port is symbolized as 'domain'.

    CATCHES: the full IPv4 header field set incl. dscp/ecn/reserved bits and
    the embedded udp_datagram decode with its port symbol.
    """
    got = fq_json(tmp_path, ["-d", "ipv4_packet", "-cV", ".", "-"],
                  stdin=ipv4("192.168.0.1", "192.168.0.2", 17,
                             udp(12345, 53, b"\x00")))
    assert got == {
        "destination_ip": "192.168.0.2", "dont_fragment": False, "dscp": 0,
        "ecn": 0, "fragment_offset": 0, "header_checksum": 63867,
        "identification": 1, "ihl": 5, "more_fragments": False,
        "payload": {"checksum": 0, "destination_port": "domain", "length": 9,
                    "payload": "\x00", "source_port": 12345},
        "protocol": "udp", "reserved": 0, "source_ip": "192.168.0.1",
        "total_length": 29, "ttl": 64, "version": 4,
    }


@pytest.mark.parametrize("proto,symbol", [
    (6, "tcp"), (1, "icmp"), (41, "ipv6"), (47, "gre"), (89, "ospf"),
])
def test_ipv4_protocol_symbols(tmp_path, proto, symbol):
    """The IPv4 protocol byte maps to the recorded symbol names.

    CATCHES: the protocol number -> symbol table used for dispatch.
    """
    got = fq_json(tmp_path, ["-d", "ipv4_packet", "-cV", ".protocol", "-"],
                  stdin=ipv4("1.1.1.1", "2.2.2.2", proto,
                             b"\x00\x01\x02\x03\x04\x05\x06\x07"))
    assert got == symbol


@pytest.mark.parametrize("check,line2,value", [
    (None,
     "0x0|                              f9 7b            |          .{    |.header_checksum: 0xf97b (valid) 0xa-0xc (2)",
     0xF97B),
    (0xDEAD,
     "0x0|                              de ad            |          ..    |.header_checksum: 0xdead (invalid) 0xa-0xc (2)",
     0xDEAD),
])
def test_ipv4_header_checksum_display(tmp_path, check, line2, value):
    """The header checksum display annotates (valid)/(invalid) and shows the
    hex value; the JSON value is the plain number either way.

    CATCHES: pkg/checksum validation of the IPv4 header — the display
    annotation, not just the stored field value.
    """
    pkt = ipv4("192.168.0.1", "192.168.0.2", 17, udp(12345, 53, b"\x00"),
               check=check)
    disp = run_ok(tmp_path, ["-d", "ipv4_packet", ".header_checksum | dv", "-"],
                  stdin=pkt)
    assert disp == ("   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
                    "|0123456789abcdef|\n" + line2)
    got = fq_json(tmp_path, ["-d", "ipv4_packet", "-cV",
                             ".header_checksum", "-"], stdin=pkt)
    assert got == value


def test_ipv4_bad_version_is_a_gap(tmp_path):
    """Forcing -d ipv4_packet on a non-IPv4 packet yields only a gap0 field.

    CATCHES: the version check bails out before any other field is decoded.
    """
    got = fq_json(tmp_path, ["-d", "ipv4_packet", "-cV", ".", "-"],
                  stdin=b"\x55\x00\x00\x14" + b"\x00" * 16)
    assert got == {"gap0": "U\x00\x00\x14" + "\x00" * 16}


def test_ipv4_options(tmp_path):
    """IHL 6 with a 4-byte option (0x94: copied, class 0, number 20) decodes
    an options array and still finds the 5-byte payload afterwards.

    CATCHES: IPv4 options parsing (copied flag, option class/number split)
    and IHL-based header length handling.
    """
    got = fq_json(tmp_path, ["-d", "ipv4_packet", "-cV",
                             "{ihl, total_length, options, payload_len: (.payload|length)}", "-"],
                  stdin=ipv4("1.2.3.4", "5.6.7.8", 17, udp(1, 2, b"xy"),
                             ihl=6, options=b"\x94\x04\x00\x00"))
    assert got == {"ihl": 6,
                   "options": [{"class": 0, "copied": True, "data": "\x00\x00",
                                "length": 4, "number": 20}],
                   "payload_len": 5, "total_length": 34}


def test_ipv4_fragment_flag_bits(tmp_path):
    """The 3 flag bits and 13-bit fragment offset are split out of the
    flags/fragment word.

    CATCHES: bitfield split of the IPv4 flags word (MF, DF, offset).
    """
    mf = fq_json(tmp_path, ["-d", "ipv4_packet", "-cV",
                            "{reserved, dont_fragment, more_fragments, fragment_offset}", "-"],
                 stdin=ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2, b"a"), flags=1))
    assert mf == {"dont_fragment": False, "fragment_offset": 0,
                  "more_fragments": True, "reserved": 0}
    df = fq_json(tmp_path, ["-d", "ipv4_packet", "-cV",
                            "{dont_fragment, more_fragments, fragment_offset}", "-"],
                 stdin=ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2, b"a"),
                            flags=2, frag_off=5))
    assert df == {"dont_fragment": True, "fragment_offset": 5,
                  "more_fragments": False}


def test_ipv6_fields_and_mdns_dispatch(tmp_path):
    """A crafted IPv6 packet to UDP port 5353 decodes the fixed header and
    dispatches the payload to dns (an empty 12-byte DNS header decodes).

    CATCHES: IPv6 fixed header fields plus udp 5353 -> dns dispatch with the
    empty-message DNS structure.
    """
    got = fq_json(tmp_path, ["-d", "ipv6_packet", "-cV", ".", "-"],
                  stdin=ipv6("2001:db8::1", "2001:db8::2", 17,
                             payload=udp(5353, 5353, b"\x00" * 12)))
    assert got == {
        "destination_address": "2001:db8::2", "ds": 0, "ecn": 0,
        "flow_label": 0, "hop_limit": 64, "next_header": "udp",
        "payload": {"checksum": 0, "destination_port": "mdns", "length": 20,
                    "payload": {"additionals": [], "an_count": 0,
                                "answers": [], "ar_count": 0,
                                "header": {"authoritative_answer": False,
                                           "id": 0, "opcode": "query",
                                           "qr": "query", "rcode": "no_error",
                                           "recursion_available": False,
                                           "recursion_desired": False,
                                           "truncation": False, "z": 0},
                                "nameservers": [], "ns_count": 0,
                                "qd_count": 0, "questions": []},
                    "source_port": "mdns"},
        "payload_length": 20, "source_address": "2001:db8::1", "version": 6,
    }


def test_ipv6_traffic_class_and_flow_label(tmp_path):
    """The 32-bit first word splits into version, ds (6 bits), ecn (2 bits)
    and a 20-bit flow label.

    CATCHES: IPv6 fixed-header bitfield layout.
    """
    got = fq_json(tmp_path, ["-d", "ipv6_packet", "-cV",
                             "{version, ds, ecn, flow_label, payload_length, hop_limit}", "-"],
                  stdin=ipv6("::1", "::2", 17, payload=udp(1, 2, b"ab"),
                             flow=0x12345, ds=1, ecn=2))
    assert got == {"ds": 1, "ecn": 2, "flow_label": 74565, "hop_limit": 64,
                   "payload_length": 10, "version": 6}


def test_ipv6_extension_headers(tmp_path):
    """A fragment extension header (next header udp) is decoded into the
    extensions array with its raw framed bytes, and the payload after it
    still decodes as an object; a hop-by-hop header shows padN options and
    ipv6-nonxt as the following header.

    CATCHES: IPv6 extension header walk (fragment, hop_by_hop) and dispatch
    continuing through extensions to the final payload.
    """
    frag = struct.pack(">BBHI", 17, 0, 0x0001, 12345)
    got = fq_json(tmp_path, ["-d", "ipv6_packet", "-cV",
                             "{next_header, extensions, payload_type: (.payload|type)}", "-"],
                  stdin=ipv6("::1", "::2", 44, payload=frag + udp(1, 2, b"ab")))
    assert got == {
        "extensions": [{"length": 0, "next_header": "udp",
                        "payload": "\x00\x01\x00\x00" + "09"}],
        "next_header": "fragment", "payload_type": "object",
    }
    hbh = bytes([59, 0, 0x01, 0x04, 0xDE, 0xAD, 0xBE, 0xEF])
    got = fq_json(tmp_path, ["-d", "ipv6_packet", "-cV",
                             "{next_header, extensions}", "-"],
                  stdin=ipv6("::1", "::2", 0, payload=hbh))
    assert got == {
        "extensions": [{"length": 0, "next_header": "ipv6-nonxt",
                        "options": [{"data": bytes([0xDE, 0xAD, 0xBE, 0xEF]).decode("utf-8", "replace"),
                                     "len": 4, "type": "padn"}]}],
        "next_header": "hop_by_hop",
    }


def test_icmp_echo_and_unreachable(tmp_path):
    """ICMP type 8/code 0 decodes as echo_request with the 4-byte echo
    header kept in content, and type 3 code 3 as unreachable; an IPv4 packet
    with protocol 1 dispatches to icmp.

    CATCHES: ICMP type/code symbols and the content field carrying the
    rest of the header plus payload.
    """
    echo = fq_json(tmp_path, ["-d", "icmp", "-cV", ".", "-"],
                   stdin=struct.pack(">BBH", 8, 0, 0)
                   + struct.pack(">HH", 1, 1) + b"abcdef")
    assert echo == {"checksum": 0, "code": 0,
                    "content": "\x00\x01\x00\x01" + "abcdef",
                    "type": "echo_request"}
    unreach = fq_json(tmp_path, ["-d", "icmp", "-cV", ".", "-"],
                      stdin=struct.pack(">BBH", 3, 3, 0) + b"\x00" * 4)
    assert unreach == {"checksum": 0, "code": 3,
                       "content": "\x00\x00\x00\x00", "type": "unreachable"}
    disp = fq_json(tmp_path, ["-d", "ipv4_packet", "-cV",
                              "{protocol, payload: (.payload|{type, code, content})}", "-"],
                   stdin=ipv4("1.1.1.1", "2.2.2.2", 1,
                              struct.pack(">BBH", 8, 0, 0) + b"\x00" * 4))
    assert disp == {"payload": {"code": 0, "content": "\x00\x00\x00\x00",
                                "type": "echo_request"},
                    "protocol": "icmp"}


def test_icmpv6_echo_reply_quirk(tmp_path):
    """ICMPv6 type 128 decodes as 'echo_reply' (the symbol table maps it
    that way), type 1 code 4 as unreachable, and IPv6 next header 58
    dispatches to icmpv6.

    CATCHES: the icmpv6 type 128 -> echo_reply symbol (not echo_request)
    and the ipv6-icmp next-header dispatch.
    """
    echo = fq_json(tmp_path, ["-d", "icmpv6", "-cV", ".", "-"],
                   stdin=struct.pack(">BBH", 128, 0, 0)
                   + struct.pack(">HH", 1, 1))
    assert echo == {"checksum": 0, "code": 0, "content": "\x00\x01\x00\x01",
                    "type": "echo_reply"}
    unreach = fq_json(tmp_path, ["-d", "icmpv6", "-cV", ".", "-"],
                      stdin=struct.pack(">BBH", 1, 4, 0) + b"\x00" * 4)
    assert unreach == {"checksum": 0, "code": 4,
                       "content": "\x00\x00\x00\x00", "type": "unreachable"}
    disp = fq_json(tmp_path, ["-d", "ipv6_packet", "-cV",
                              "{next_header, payload: (.payload|{type, code, content})}", "-"],
                   stdin=ipv6("::1", "::2", 58,
                              payload=struct.pack(">BBH", 128, 0, 0) + b"\x00" * 4))
    assert disp == {"next_header": "ipv6-icmp",
                    "payload": {"code": 0, "content": "\x00\x00\x00\x00",
                                "type": "echo_reply"}}


@pytest.mark.parametrize("port,symbol", [
    (53, "domain"), (5353, "mdns"), (123, "ntp"), (137, "netbios-ns"),
    (69, "tftp"),
])
def test_udp_destination_port_symbols(tmp_path, port, symbol):
    """Well-known UDP destination ports are symbolized while the payload
    (too short to be a real message) stays a raw string.

    CATCHES: the udp port symbol table and that dispatch needs a decodable
    payload — a 1-byte payload is not passed to dns/ntp/etc.
    """
    got = fq_json(tmp_path, ["-d", "udp_datagram", "-cV",
                             "{destination_port, payload_type: (.payload|type)}", "-"],
                  stdin=udp(12345, port, b"\x00"))
    assert got == {"destination_port": symbol, "payload_type": "string"}


def test_udp_unknown_port_and_dns_dispatch(tmp_path):
    """An unallocated port stays numeric; the same datagram aimed at port 53
    with a real DNS question dispatches to dns.

    CATCHES: numeric fallback for unknown ports and the udp -> dns dispatch
    when the payload really is a DNS message.
    """
    unknown = fq_json(tmp_path, ["-d", "udp_datagram", "-cV", ".", "-"],
                      stdin=udp(9999, 9999, b"hello"))
    assert unknown == {"checksum": 0, "destination_port": 9999, "length": 13,
                       "payload": "hello", "source_port": 9999}
    dnsq = (struct.pack(">HHHHHH", 0x1234, 0x0100, 1, 0, 0, 0)
            + dns_name("example.com") + struct.pack(">HH", 1, 1))
    questions = fq_json(tmp_path, ["-d", "udp_datagram", "-cV",
                                   ".payload.questions", "-"],
                        stdin=udp(12345, 53, dnsq))
    assert questions == [{"class": "in",
                          "name": {"labels": [{"length": 7, "value": "example"},
                                              {"length": 3, "value": "com"},
                                              {"length": 0}],
                                   "value": "example.com"},
                          "type": "a"}]
