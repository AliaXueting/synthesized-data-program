"""Link-layer frame tests: ethernet II (EtherType dispatch, no dispatch for
VLAN/ARP), BSD loopback, Linux cooked SLL v1 and v2.

Every expected value below was recorded by running the reference fq binary.
"""

import struct

from conftest import (eth, fq_json, ipv4, ipv6, make_pcap, sll, sll2, udp)


def test_ether8023_fixture_stack(tmp_path):
    """The checked-in ethernet frame decodes broadcast -> IPv4 -> UDP with
    the recorded header values, and its UDP payload starts with JSON text.

    CATCHES: ethernet MAC formatting, EtherType-to-ipv4 dispatch and the
    ipv4/udp field values on a real frame.
    """
    got = fq_json(tmp_path, ["-d", "ether8023_frame", "-cV",
                             "{destination, source, ether_type, ipv4: (.payload | {version, ihl, ttl, protocol, source_ip, destination_ip, header_checksum}), udp: (.payload.payload | {source_port, destination_port, length, checksum}), payload: (.payload.payload.payload | .[0:24])}",
                             "inet/ether8023_frame"])
    assert got == {
        "destination": "ff:ff:ff:ff:ff:ff",
        "source": "a4:5e:60:f1:7d:93",
        "ether_type": "ipv4",
        "ipv4": {"destination_ip": "255.255.255.255", "header_checksum": 61767,
                 "ihl": 5, "protocol": "udp", "source_ip": "192.168.1.139",
                 "ttl": 64, "version": 4},
        "udp": {"checksum": 47619, "destination_port": 17500, "length": 144,
                "source_port": 17500},
        "payload": '{"host_int": 4094514483,',
    }


def test_vlan_and_arp_payloads_stay_raw(tmp_path):
    """EtherType 0x8100 is reported as the 'vlan' symbol but there is no vlan
    decoder: the payload stays a jq string.  EtherType 0x0806 is 'arp' with
    no payload decode either (all arp fields null).

    CATCHES: EtherType symbols exist for VLAN and ARP even though the stack
    never dispatches into them — payload must remain undecoded.
    """
    vlan = fq_json(tmp_path, ["-d", "ether8023_frame", "-cV",
                              "{destination, ether_type, payload_type: (.payload|type)}", "-"],
                  stdin=eth("aa:bb:cc:dd:ee:ff", "11:22:33:44:55:66", 0x8100,
                            b"\x00\x64" + ipv4("1.2.3.4", "5.6.7.8", 17,
                                               udp(1, 2, b"hi"))))
    assert vlan == {"destination": "aa:bb:cc:dd:ee:ff", "ether_type": "vlan",
                    "payload_type": "string"}

    arp = struct.pack(">HHBB", 1, 0x0800, 6, 4) + struct.pack(">H", 1) \
        + b"\x11" * 6 + b"\x01\x02\x03\x04" + b"\x22" * 6 + b"\x05\x06\x07\x08"
    got = fq_json(tmp_path, ["-d", "ether8023_frame", "-cV",
                             "{ether_type, payload_fmt: (.payload|format), arp: (.payload|{hardware_type, protocol_type, operation, sender_mac, sender_ip, target_mac, target_ip})}", "-"],
                  stdin=eth("ff:ff:ff:ff:ff:ff", "11:22:33:44:55:66", 0x0806, arp))
    assert got == {"arp": {"hardware_type": None, "operation": None,
                           "protocol_type": None, "sender_ip": None,
                           "sender_mac": None, "target_ip": None,
                           "target_mac": None},
                   "ether_type": "arp", "payload_fmt": None}


def test_ether_ipv6_dispatch(tmp_path):
    """EtherType 0x86DD dispatches into ipv6_packet with the recorded
    addresses and next-header symbol.

    CATCHES: ethernet -> IPv6 dispatch and IPv6 address text formatting.
    """
    got = fq_json(tmp_path, ["-d", "ether8023_frame", "-cV",
                             "{ether_type, payload_fmt: (.payload|format), v6: (.payload|{version, next_header, source_address, destination_address})}", "-"],
                  stdin=eth("aa:bb:cc:dd:ee:ff", "11:22:33:44:55:66", 0x86dd,
                            ipv6("2001:db8::1", "2001:db8::2", 17,
                                 payload=udp(5353, 5353, b"\x00" * 12))))
    assert got == {"ether_type": "ipv6", "payload_fmt": "ipv6_packet",
                   "v6": {"destination_address": "2001:db8::2",
                          "next_header": "udp",
                          "source_address": "2001:db8::1", "version": 6}}


def test_bsd_loopback_frames(tmp_path):
    """A big-endian 4-byte AF constant followed by an IPv4 or IPv6 packet:
    the decoder reports the network layer symbol and dispatches the payload.
    Inside a little-endian pcap with LINKTYPE_NULL the same happens.

    CATCHES: bsd_loopback_frame AF_INET (2) vs AF_INET6 (30) dispatch and
    the little-endian special case used by LINKTYPE_NULL captures.
    """
    loop4 = fq_json(tmp_path, ["-d", "bsd_loopback_frame", "-cV",
                               "{network_layer, payload_fmt: (.payload|format), udp_len: (.payload.payload.length)}", "-"],
                    stdin=struct.pack(">I", 2)
                    + ipv4("10.0.0.1", "10.0.0.2", 17, udp(1, 2, b"ab")))
    assert loop4 == {"network_layer": "ipv4", "payload_fmt": "ipv4_packet",
                     "udp_len": 10}
    loop6 = fq_json(tmp_path, ["-d", "bsd_loopback_frame", "-cV",
                               "{network_layer, payload_fmt: (.payload|format)}", "-"],
                    stdin=struct.pack(">I", 0x1E)
                    + ipv6("::1", "::2", 17, payload=udp(1, 2, b"cd")))
    assert loop6 == {"network_layer": "ipv6", "payload_fmt": "ipv6_packet"}
    lb = struct.pack("<I", 2) + ipv4("10.0.0.1", "10.0.0.2", 17, udp(1, 2, b"ab"))
    in_pcap = fq_json(tmp_path, ["-d", "pcap", "-cV",
                                 "{net: .header.network, layer: .packets[0].packet.network_layer, payload_fmt: (.packets[0].packet.payload|format)}", "-"],
                      stdin=make_pcap([lb], linktype=0))
    assert in_pcap == {"layer": "ipv4", "net": "null",
                       "payload_fmt": "ipv4_packet"}


def test_sll_packet_variants(tmp_path):
    """SLL v1 packets: normal ethernet-ish header decodes IPv4; an arphdr of
    512 (PPP) with zero link address length reads the protocol field
    little-endian (2048 stays numeric so the payload is raw); arphdr 772
    (loopback) with 8 address bytes dispatches to IPv6.

    CATCHES: SLL field symbols, the link address padding to 8 bytes, and the
    little-endian protocol quirk for non-ethernet ARP header types.
    """
    ip = ipv4("10.1.1.1", "10.1.1.2", 17, udp(7, 7, b"zz"))
    normal = fq_json(tmp_path, ["-d", "sll_packet", "-cV",
                                "{packet_type, arphdr_type, link_address_length, link_address, padding, protocol_type, payload_fmt: (.payload|format)}", "-"],
                     stdin=sll(protocol=0x0800, payload=ip))
    assert normal == {"arphdr_type": "ether", "link_address": "aa:bb:cc:dd:ee:ff",
                      "link_address_length": 6, "packet_type": "to_us",
                      "padding": "\x00\x00", "payload_fmt": "ipv4_packet",
                      "protocol_type": "ipv4"}
    ppp = fq_json(tmp_path, ["-d", "sll_packet", "-cV",
                             "{packet_type, arphdr_type, link_address_length, protocol_type, payload}", "-"],
                  stdin=sll(ptype=0, arphdr=512, addrlen=0, addr=b"",
                            protocol=0x0800, payload=b"PAYLOAD",
                            little_protocol=True))
    assert ppp == {"arphdr_type": "ppp", "link_address_length": 0,
                   "packet_type": "to_us", "payload": "PAYLOAD",
                   "protocol_type": 2048}
    loop = fq_json(tmp_path, ["-d", "sll_packet", "-cV",
                              "{packet_type, arphdr_type, link_address, protocol_type, payload_type: (.payload|type)}", "-"],
                   stdin=sll(ptype=4, arphdr=772, addrlen=8,
                             addr=b"\x01\x02\x03\x04\x05\x06\x07\x08",
                             protocol=0x86dd))
    assert loop == {"arphdr_type": "loopback", "link_address": "03:04:05:06:07:08",
                    "packet_type": "from_us", "payload_type": "string",
                    "protocol_type": "ipv6"}


def test_sll2_packet_variants(tmp_path):
    """SLL v2 packets: normal header decodes IPv4; link address length 0
    leaves zero-filled address and 8 padding bytes; length 9 consumes the
    padding entirely (no padding field); loopback arphdr dispatches IPv6.

    CATCHES: SLL2 fixed header layout (protocol first) and the address /
    padding split for addrlen 0, 6 and 9.
    """
    ip = ipv4("10.1.1.1", "10.1.1.2", 17, udp(7, 7, b"zz"))
    normal = fq_json(tmp_path, ["-d", "sll2_packet", "-cV",
                                "{protocol_type, reserved, interface_index, arphdr_type, packet_type, link_address_length, link_address, padding, payload_fmt: (.payload|format)}", "-"],
                     stdin=sll2(protocol=0x0800, payload=ip))
    assert normal == {"arphdr_type": "ether", "interface_index": 3,
                      "link_address": "aa:bb:cc:dd:ee:ff",
                      "link_address_length": 6, "packet_type": "to_us",
                      "padding": "\x00\x00", "payload_fmt": "ipv4_packet",
                      "protocol_type": "ipv4", "reserved": 0}
    short = fq_json(tmp_path, ["-d", "sll2_packet", "-cV",
                               "{link_address_length, link_address, padding, payload_fmt: (.payload|format)}", "-"],
                    stdin=sll2(protocol=0x0800, addrlen=0, payload=ip))
    assert short == {"link_address": "00:00:00:00:00:00",
                     "link_address_length": 0,
                     "padding": "\x00" * 8, "payload_fmt": "ipv4_packet"}
    long = fq_json(tmp_path, ["-d", "sll2_packet", "-cV",
                              "{link_address_length, link_address, padding}", "-"],
                   stdin=sll2(protocol=0x0800, addrlen=9, addr=b"\xaa" * 9))
    assert long == {"link_address": "aa:aa:aa:aa:aa:aa", "link_address_length": 9,
                    "padding": None}
    loop = fq_json(tmp_path, ["-d", "sll2_packet", "-cV",
                              "{arphdr_type, link_address, padding, payload_fmt: (.payload|format)}", "-"],
                   stdin=sll2(protocol=0x86dd, arphdr=772, addrlen=8,
                              addr=b"\x01\x02\x03\x04\x05\x06\x07\x08",
                              payload=ipv6("::1", "::2", 17,
                                           payload=udp(1, 2, b"ef"))))
    assert loop == {"arphdr_type": "loopback", "link_address": "03:04:05:06:07:08",
                    "padding": None, "payload_fmt": "ipv6_packet"}
