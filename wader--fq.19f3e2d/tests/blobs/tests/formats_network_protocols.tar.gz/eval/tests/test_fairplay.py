"""FairPlay Server Playback Context (SPC) tests.

The decoder (format/fairplay/fairplay.go) reads a fixed big-endian layout:
u32 version, 32 *bits* of reserved (4 bytes, not 32 bytes), 16-byte iv,
128-byte aes_key_oaep, 20-byte certificate_hash, u32 payload_length and
payload_length bytes of payload.  All expected values below were recorded
by running the reference fq binary on crafted inputs.
"""

import struct

import pytest

from conftest import fq_json, run_ok

# jq projection turning every raw field into hex so the whole value can be
# compared as one exact JSON object.
SPC_PROJECTION = ("{version, reserved: (.reserved|tobytes|tohex),"
                  " iv: (.iv|tobytes|tohex),"
                  " key: (.aes_key_oaep|tobytes|tohex),"
                  " cert: (.certificate_hash|tobytes|tohex),"
                  " payload_length, payload: (.payload|tobytes|tohex)}")


def spc(version, payload, reserved=b"\x00" * 4, iv=b"\x0a" * 16,
        key=b"\x0b" * 128, cert=b"\x0c" * 20, payload_length=None):
    """A FairPlay SPC with the reference's 4-byte reserved field."""
    if payload_length is None:
        payload_length = len(payload)
    return (struct.pack(">I", version) + reserved + iv + key + cert
            + struct.pack(">I", payload_length) + payload)


def test_spc_field_layout(tmp_path):
    """A 181-byte SPC decodes every field with the recorded byte ranges:
    reserved occupies only 4 bytes (32 bits), so iv starts at 0x8 and the
    whole header is 176 bytes before the payload.

    CATCHES: the big-endian u32s, the 4-byte reserved quirk and every
    field's exact offset/length in the display.
    """
    data = spc(2, b"hello")
    got = fq_json(tmp_path, ["-d", "fairplay_spc", "-cV", SPC_PROJECTION, "-"],
                  stdin=data)
    assert got == {
        "version": 2,
        "reserved": "00000000",
        "iv": "0a" * 16,
        "key": "0b" * 128,
        "cert": "0c" * 20,
        "payload_length": 5,
        "payload": "68656c6c6f",
    }
    disp = run_ok(tmp_path, ["-d", "fairplay_spc", "dv", "-"], stdin=data)
    assert disp.splitlines()[0].endswith(".{}: <stdin> (fairplay_spc)"
                                        " 0x0-0xb5 (181)")
    for line in [
        "version: 2 0x0-0x4 (4)",
        "reserved: raw bits 0x4-0x8 (4)",
        "iv: raw bits 0x8-0x18 (16)",
        "aes_key_oaep: raw bits 0x18-0x98 (128)",
        "certificate_hash: raw bits 0x98-0xac (20)",
        "payload_length: 5 0xac-0xb0 (4)",
        "payload: raw bits 0xb0-0xb5 (5)",
    ]:
        assert line in disp


def test_spc_wide_values_and_big_payload(tmp_path):
    """Version and payload_length are read as big-endian u32 (0x01020304
    -> 16909060) and a 300-byte payload round-trips through hex.

    CATCHES: big-endian integer decoding (a little-endian reader would
    report 67305985) and payload sizes wider than one byte.
    """
    data = spc(0x01020304, b"Q" * 300, iv=bytes(range(16)),
               key=bytes(range(128)), cert=bytes(range(20)))
    got = fq_json(tmp_path, ["-d", "fairplay_spc", "-cV", SPC_PROJECTION, "-"],
                  stdin=data)
    assert got == {
        "version": 16909060,
        "reserved": "00000000",
        "iv": bytes(range(16)).hex(),
        "key": bytes(range(128)).hex(),
        "cert": bytes(range(20)).hex(),
        "payload_length": 300,
        "payload": "51" * 300,
    }


def test_spc_zero_length_payload(tmp_path):
    """payload_length 0 decodes as an empty payload with no error at all
    (unlike a zero-size opentimestamps argument, which fails).

    CATCHES: the zero-length payload quirk — the raw field is present and
    empty instead of raising an EOF error.
    """
    data = spc(1, b"")
    got = fq_json(tmp_path, ["-d", "fairplay_spc", "-cV",
                             "{payload_length, payload: (.payload|tobytes|tohex)}",
                             "-"], stdin=data)
    assert got == {"payload_length": 0, "payload": ""}
    disp = run_ok(tmp_path, ["-d", "fairplay_spc", "dv", "-"], stdin=data)
    assert "error: fairplay_spc" not in disp
    assert "payload: raw bits 0xb0-0xb0 (0)" in disp


@pytest.mark.parametrize("label,data,err_line,json_expr,json_expected", [
    # Cut inside aes_key_oaep: the 76 remaining bytes become gap0 (fq's
    # keys builtin keeps decode order, it does not sort).
    ("truncated_key",
     spc(3, b"xyz")[:100],
     "error: fairplay_spc: RawLen(aes_key_oaep): failed at position 24"
     " (read size 0 seek pos 0): outside buffer",
     "{version, gap: (.gap0|tobytes|tohex), keys: keys}",
     {"version": 3, "gap": "0b" * 76,
      "keys": ["version", "reserved", "iv", "gap0"]}),
    # payload_length 10 but only 5 bytes left: payload is never created.
    ("payload_overrun",
     spc(1, b"hello", payload_length=10),
     "error: fairplay_spc: RawLen(payload): failed at position 176"
     " (read size 0 seek pos 0): outside buffer",
     "{payload_length, gap: (.gap0|tobytes|tohex), keys: keys}",
     {"payload_length": 10, "gap": "68656c6c6f",
      "keys": ["version", "reserved", "iv", "aes_key_oaep",
               "certificate_hash", "payload_length", "gap0"]}),
])
def test_decode_errors(tmp_path, label, data, err_line, json_expr,
                       json_expected):
    """Decode failures leave a partial value (exit code 0) with the
    undecoded tail as gap0 and the error line in the display.

    CATCHES: partial-field shape after a truncated aes_key_oaep and after a
    payload_length that overruns the file.
    """
    disp = run_ok(tmp_path, ["-d", "fairplay_spc", "dv", "-"], stdin=data)
    assert err_line in disp
    got = fq_json(tmp_path, ["-d", "fairplay_spc", "-cV", json_expr, "-"],
                  stdin=data)
    assert got == json_expected
