"""RTMP and AMF0 tests: the amf0 value decoder driven directly with crafted
bytes (every type marker, the object/ecma-array/typed-object pair loops and
the unknown-type error), and the rtmp chunk-stream decoder on the checked-in
client/server streams, including the pcap -> tcp stream -> rtmp dispatch.

Every expected value below was recorded by running the reference fq binary.
"""

import json
import struct

import pytest
from conftest import fq_json, run_ok, run_on

CLIENT_STREAM = "rtmp/client_stream"
FFMPEG_CLIENT = "rtmp/ffmpeg_client_stream"
FFMPEG_SERVER = "rtmp/ffmpeg_server_stream"
RTMP_CAP = "rtmp/rtmp_sample.cap"


# --------------------------------------------------------------- crafting
# AMF0 markers from the file-format specification.


def amf_key(name):
    """An AMF0 key: u16 length prefix + utf8 bytes."""
    raw = name.encode()
    return struct.pack(">H", len(raw)) + raw


def amf_string(value):
    raw = value.encode()
    return struct.pack(">BH", 0x02, len(raw)) + raw


def amf_number(value):
    return struct.pack(">Bd", 0x00, value)


# The object/ecma-array/typed-object terminators: an empty key followed by
# the 0x09 object-end marker.
END = amf_key("") + b"\x09"


def test_amf0_scalar_types(tmp_path):
    """Each scalar marker decodes to its recorded type symbol and value; the
    string markers carry their own length field and null/undefined both
    produce a JSON null while keeping distinct type symbols.

    CATCHES: the amf0 type marker table (number/boolean/string/null/
    undefined/reference/date/long_string/xml) and the u16 vs u32 length
    prefix difference between string and long_string.
    """
    cases = [
        (struct.pack(">Bd", 0x00, 42.5), {"type": "number", "value": 42.5}),
        (struct.pack(">Bd", 0x00, -1.0), {"type": "number", "value": -1}),
        (struct.pack(">BB", 0x01, 1), {"type": "boolean", "value": 1}),
        (struct.pack(">BB", 0x01, 0), {"type": "boolean", "value": 0}),
        (amf_string("hello"),
         {"length": 5, "type": "string", "value": "hello"}),
        (b"\x05", {"type": "null", "value": None}),
        (b"\x06", {"type": "undefined", "value": None}),
        (struct.pack(">BH", 0x07, 5), {"type": "reference", "value": 5}),
        (struct.pack(">Bdh", 0x0B, 1000000.0, -3600),
         {"date_time": 1000000, "local_data_time_offset": -3600,
          "type": "date"}),
        (struct.pack(">BI", 0x0C, 5) + b"world",
         {"length": 5, "type": "long_string", "value": "world"}),
        (struct.pack(">BH", 0x0F, 4) + b"<a/>",
         {"length": 4, "type": "xml", "value": "<a/>"}),
    ]
    for data, expected in cases:
        got = fq_json(tmp_path, ["-d", "amf0", "-cV", ".", "-"], stdin=data)
        assert got == expected, data.hex()


def test_amf0_string_display(tmp_path):
    """The verbose display of a string value shows the marker with its symbol
    name, the u16 length and the utf8 value with byte ranges.

    CATCHES: the dv rendering of an amf0 value — the type symbol annotation
    and the length/value field split.
    """
    disp = run_ok(tmp_path, ["-d", "amf0", "dv", "-"],
                  stdin=amf_string("hello"))
    assert disp == """\
   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: <stdin> (amf0) 0x0-0x8 (8)
0x0|02                                             |.               |  type: "string" (2) 0x0-0x1 (1)
0x0|   00 05                                       | ..             |  length: 5 0x1-0x3 (2)
0x0|         68 65 6c 6c 6f|                       |   hello|       |  value: "hello" 0x3-0x8 (5)"""


def test_amf0_strict_array(tmp_path):
    """A strict array carries a u32 count and exactly that many entries, each
    decoded as a full amf0 value.

    CATCHES: the strict-array count-driven loop (unlike ecma arrays) and the
    entry struct nesting.
    """
    data = (struct.pack(">BI", 0x0A, 2) + amf_number(1.0)
            + struct.pack(">BB", 0x01, 1))
    got = fq_json(tmp_path, ["-d", "amf0", "-cV", ".", "-"], stdin=data)
    assert got == {"count": 2, "type": "strict_array",
                   "value": [{"type": "number", "value": 1},
                             {"type": "boolean", "value": 1}]}


def test_amf0_object_pairs_and_end_marker(tmp_path):
    """An object is a list of key/value pairs terminated by an empty key whose
    value is the object_end marker itself.

    CATCHES: the object pair loop and the 00 00 09 terminator being consumed
    as a final pair with an empty key (not dropped or left as a gap).
    """
    data = b"\x03" + amf_key("a") + amf_number(1.5) \
        + amf_key("b") + amf_string("x") + END
    got = fq_json(tmp_path, ["-d", "amf0", "-cV", ".", "-"], stdin=data)
    assert got == {
        "type": "object",
        "value": [
            {"key": {"length": 1, "value": "a"},
             "value": {"type": "number", "value": 1.5}},
            {"key": {"length": 1, "value": "b"},
             "value": {"length": 1, "type": "string", "value": "x"}},
            {"key": {"length": 0, "value": ""},
             "value": {"type": "object_end"}}],
    }


def test_amf0_ecma_array_count_is_advisory(tmp_path):
    """An ecma array stores a u32 count but the entries are read until the
    object_end marker: a count of 0 with one real entry still yields two
    entries (the pair plus the terminator pair).

    CATCHES: the ecma-array loop is terminator-driven, so the count field is
    only reported, never used to bound the value array.
    """
    data = b"\x08" + struct.pack(">I", 0) + amf_key("a") + amf_number(1.0) + END
    got = fq_json(tmp_path, ["-d", "amf0", "-cV",
                             "{count, type, n: (.value|length), "
                             "types: [.value[].value.type]}", "-"], stdin=data)
    assert got == {"count": 0, "n": 2, "type": "ecma_array",
                   "types": ["number", "object_end"]}
    counted = b"\x08" + struct.pack(">I", 2) + amf_key("n") + amf_number(7.0) \
        + amf_key("s") + amf_string("v") + END
    got = fq_json(tmp_path, ["-d", "amf0", "-cV", ".", "-"], stdin=counted)
    assert got == {"count": 2, "type": "ecma_array",
                   "value": [
                       {"key": {"length": 1, "value": "n"},
                        "value": {"type": "number", "value": 7}},
                       {"key": {"length": 1, "value": "s"},
                        "value": {"length": 1, "type": "string", "value": "v"}},
                       {"key": {"length": 0, "value": ""},
                        "value": {"type": "object_end"}}]}


def test_amf0_ecma_array_display(tmp_path):
    """The verbose display of an ecma array shows the entry/key/value struct
    nesting with per-field bit ranges.

    CATCHES: the dv layout of the ecma_array entry structs and the
    object_end value at the end of the array.
    """
    data = b"\x08" + struct.pack(">I", 1) + amf_key("n") + amf_number(7.0) + END
    disp = run_ok(tmp_path, ["-d", "amf0", "dv", "-"], stdin=data)
    lines = disp.splitlines()
    assert lines[0] == ("    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
                        "|0123456789abcdef|.{}: <stdin> (amf0) 0x0-0x14 (20)")
    assert ('0x00|08                                             |.               |'
            '  type: "ecma_array" (8) 0x0-0x1 (1)') in lines
    assert ('0x00|   00 00 00 01                                 | ....           |'
            '  count: 1 0x1-0x5 (4)') in lines
    assert ('    |                                               |                |'
            '  value[0:2]: 0x5-0x14 (15)') in lines
    assert ('    |                                               |                |'
            '    [0]{}: entry 0x5-0x11 (12)') in lines
    assert ('0x00|                        00                     |        .       |'
            '        type: "number" (0) 0x8-0x9 (1)') in lines
    assert ('0x10|         09|                                   |   .|           |'
            '        type: "object_end" (9) 0x13-0x14 (1)') in lines


def test_amf0_typed_object(tmp_path):
    """A typed object carries a class_name string before the same pair loop as
    a plain object.

    CATCHES: the typed_object class_name field and its shared terminator
    handling.
    """
    data = b"\x10" + amf_key("MyClass") + amf_key("k") + amf_number(3.0) + END
    got = fq_json(tmp_path, ["-d", "amf0", "-cV", ".", "-"], stdin=data)
    assert got == {
        "class_name": {"length": 7, "value": "MyClass"},
        "type": "typed_object",
        "value": [{"key": {"length": 1, "value": "k"},
                   "value": {"type": "number", "value": 3}},
                  {"key": {"length": 0, "value": ""},
                   "value": {"type": "object_end"}}],
    }


def test_amf0_nested_object(tmp_path):
    """An object value may itself be an object: the inner terminator ends the
    inner pair list and the outer one keeps going.

    CATCHES: recursive amf0 value decoding inside the pair loop.
    """
    inner = b"\x03" + amf_key("i") + amf_number(2.0) + END
    data = b"\x03" + amf_key("outer") + inner + END
    got = fq_json(tmp_path, ["-d", "amf0", "-cV", ".", "-"], stdin=data)
    assert got == {
        "type": "object",
        "value": [
            {"key": {"length": 5, "value": "outer"},
             "value": {"type": "object",
                       "value": [{"key": {"length": 1, "value": "i"},
                                  "value": {"type": "number", "value": 2}},
                                 {"key": {"length": 0, "value": ""},
                                  "value": {"type": "object_end"}}]}},
            {"key": {"length": 0, "value": ""},
             "value": {"type": "object_end"}}],
    }


def test_amf0_object_end_and_unknown_type(tmp_path):
    """A bare object_end marker decodes to just its type symbol, and an
    unknown marker stays numeric with the remaining bytes as gap0 while the
    verbose display reports 'unknown type 17'.

    CATCHES: the typeObjectEnd no-op and the unknown-type Fatalf path (the
    numeric fallback for a marker with no symbol).
    """
    got = fq_json(tmp_path, ["-d", "amf0", "-cV", ".", "-"], stdin=b"\x09")
    assert got == {"type": "object_end"}
    res = run_on(tmp_path, ["-d", "amf0", "-cV", ".", "-"], stdin=b"\x11\x00")
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"gap0": "\x00", "type": 17}
    disp = run_ok(tmp_path, ["-d", "amf0", "dv", "-"], stdin=b"\x11\x00")
    assert "error: amf0: error at position 0x1: unknown type 17" in disp


def test_rtmp_handshake_and_message_summary(tmp_path):
    """The client_stream fixture decodes as a server-side rtmp stream: the
    s0/s1/s2 handshake fields (version 3, 4-byte times, 1528 random bytes)
    followed by 98 messages whose types are dominated by acknowledgments.

    CATCHES: the handshake field names for a non-client stream (s0/s1/s2, not
    c0/c1/c2) and the message_type_id symbol table.
    """
    got = fq_json(tmp_path, ["-d", "rtmp", "-cV",
                             "{handshake: {s0: .handshake.s0, s1: {time: .handshake.s1.time, zero: .handshake.s1.zero}, s2: {time: .handshake.s2.time, time2: .handshake.s2.time2}}, nmsg: (.messages|length), counts: ([.messages[].message_type_id] | group_by(.) | map({t: .[0], n: length}))}",
                             CLIENT_STREAM])
    assert got == {
        "counts": [{"n": 74, "t": "acknowledgment"},
                   {"n": 12, "t": "command_message"},
                   {"n": 11, "t": "user_control_message"},
                   {"n": 1, "t": "window_acknowledgement_size"}],
        "handshake": {"s0": {"version": 3},
                      "s1": {"time": 486182, "zero": 2147484418},
                      "s2": {"time": 2564081518, "time2": 1421329889}},
        "nmsg": 98,
    }


def test_rtmp_connect_command_amf0(tmp_path):
    """The first message is a command_message whose amf0 fields decode as
    command_name 'connect', transaction_id 1, a command object with the
    recorded connect properties and one argument object.

    CATCHES: the command_message field layout (command_name, transaction_id,
    command_object, arguments) and the amf0 object/string/boolean/number
    decoding of the connect properties.
    """
    got = fq_json(tmp_path, ["-d", "rtmp", "-cV",
                             ".messages[0] | {message_stream_id, message_type_id, command_name, transaction_id, props: [.command_object.value[] | select(.key.value != \"\") | {k: .key.value, t: .value.type, v: .value.value}], nargs: (.arguments|length), arg: [.arguments[0].value[] | select(.key.value != \"\") | {k: .key.value, v: .value.value}]}",
                             CLIENT_STREAM])
    assert got == {
        "arg": [{"k": "shimHost", "v": "http://cdn1.ustream.tv/swf/4/viewer.182.swf"},
                {"k": "videoName", "v": "0/1/1/1514/1514287/1_192254_1514287"},
                {"k": "autoPlay", "v": 1}],
        "command_name": {"length": 7, "type": "string", "value": "connect"},
        "message_stream_id": 0, "message_type_id": "command_message",
        "nargs": 1,
        "props": [{"k": "app", "t": "string",
                   "v": "ondemand/content-vod-storage1/"},
                  {"k": "flashVer", "t": "string", "v": "LNX 10,0,32,18"},
                  {"k": "swfUrl", "t": "string",
                   "v": "http://cdn1.ustream.tv/swf/4/viewer.rsl.217.swf"},
                  {"k": "tcUrl", "t": "string",
                   "v": "rtmp://cp70278.edgefcs.net:1935/ondemand/content-vod-storage1/"},
                  {"k": "fpad", "t": "boolean", "v": 0},
                  {"k": "capabilities", "t": "number", "v": 15},
                  {"k": "audioCodecs", "t": "number", "v": 3191},
                  {"k": "videoCodecs", "t": "number", "v": 252},
                  {"k": "videoFunction", "t": "number", "v": 1},
                  {"k": "pageUrl", "t": "string",
                   "v": "http://www.ustream.tv/recorded/1514287"},
                  {"k": "objectEncoding", "t": "number", "v": 0}],
        "transaction_id": {"type": "number", "value": 1},
    }


def test_rtmp_control_messages(tmp_path):
    """The non-command messages decode their own field sets: a window
    acknowledgement size, ping_response/ping timestamps and acknowledgment
    sequence numbers.

    CATCHES: the per-message-type field names (window_size, sequence_number,
    the user-control event type symbol table and its timestamp/stream_id
    fields).
    """
    got = fq_json(tmp_path, ["-d", "rtmp", "-cV",
                             "{was: [.messages[] | select(.message_type_id == \"window_acknowledgement_size\")], ack: [.messages[] | select(.message_type_id == \"acknowledgment\")][0], uc: [.messages[] | select(.message_type_id == \"user_control_message\") | {type, stream_id, timestamp}]}",
                             CLIENT_STREAM])
    assert got["ack"] == {"message_stream_id": 0,
                          "message_type_id": "acknowledgment",
                          "sequence_number": 626175}
    assert got["was"] == [{"message_stream_id": 0,
                           "message_type_id": "window_acknowledgement_size",
                           "window_size": 1250000}]
    uc = got["uc"]
    assert len(uc) == 11
    assert uc[0] == {"stream_id": None, "timestamp": 397138595,
                     "type": "ping_response"}
    assert uc[1] == {"stream_id": 0, "timestamp": None,
                     "type": "set_buffer_length"}
    assert uc[2] == {"stream_id": 1, "timestamp": None,
                     "type": "set_buffer_length"}
    assert uc[3] == {"stream_id": None, "timestamp": 397336767,
                     "type": "ping_response"}
    # Every user control message is one of the two recorded event types.
    assert {u["type"] for u in uc} == {"ping_response", "set_buffer_length"}
    # ping_response carries a timestamp, set_buffer_length a stream id.
    for u in uc:
        if u["type"] == "ping_response":
            assert u["stream_id"] is None and u["timestamp"] > 0
        else:
            assert u["timestamp"] is None and u["stream_id"] >= 0


def test_rtmp_chunk_headers_and_default_chunk_size(tmp_path):
    """The first chunk uses fmt 0 (full header) and carries 128 bytes of data
    — the default chunk size — for a 513-byte message; the continuation
    chunks use fmt 3, where message_type_id is a synthetic 'previous' value
    that stays numeric in JSON.

    CATCHES: the fmt 0/3 header split, the 128-byte default chunk size, and
    the fmt 3 synthetic fields (message_length/message_type_id copied from
    the previous header, shown as plain numbers).
    """
    got = fq_json(tmp_path, ["-d", "rtmp", "-cV",
                             "[.chunks[0:5][] | {fmt, csid: .chunk_stream_id, ml: .message_length, mid: .message_type_id, ct: .calculated_timestamp, dl: (.data|length)}]",
                             CLIENT_STREAM])
    assert got == [
        {"csid": 3, "ct": 0, "dl": 128, "fmt": 0, "mid": "command_message",
         "ml": 513},
        {"csid": 3, "ct": 0, "dl": 128, "fmt": 3, "mid": 20, "ml": 513},
        {"csid": 3, "ct": 0, "dl": 128, "fmt": 3, "mid": 20, "ml": 513},
        {"csid": 3, "ct": 0, "dl": 128, "fmt": 3, "mid": 20, "ml": 513},
        {"csid": 3, "ct": 0, "dl": 1, "fmt": 3, "mid": 20, "ml": 513},
    ]


def test_rtmp_ffmpeg_client_commands(tmp_path):
    """The ffmpeg client stream sends six command messages with increasing
    transaction ids and a null command object for everything after connect.

    CATCHES: the amf0 null command object (createStream and later commands
    carry no object) and the transaction_id numbering.
    """
    got = fq_json(tmp_path, ["-d", "rtmp", "-cV",
                             "{hs: .handshake.s0.version, s1: {time: .handshake.s1.time, zero: .handshake.s1.zero}, s2: {time: .handshake.s2.time}, nmsg: (.messages|length), cmds: [.messages[] | select(.message_type_id == \"command_message\") | {name: .command_name.value, tid: .transaction_id.value, obj: .command_object.type}]}",
                             FFMPEG_CLIENT])
    assert got == {
        "cmds": [{"name": "connect", "obj": "object", "tid": 1},
                 {"name": "createStream", "obj": "null", "tid": 2},
                 {"name": "_checkbw", "obj": "null", "tid": 3},
                 {"name": "getStreamLength", "obj": "null", "tid": 4},
                 {"name": "play", "obj": "null", "tid": 5},
                 {"name": "deleteStream", "obj": "null", "tid": 6}],
        "hs": 3, "nmsg": 8, "s1": {"time": 0, "zero": 151026690},
        "s2": {"time": 0},
    }


def test_rtmp_ffmpeg_server_messages(tmp_path):
    """The ffmpeg server stream answers with set_peer_bandwidth (dynamic
    limit), set_chunk_size 128, stream_begin user control events, an _result
    command and audio/data messages; the first audio message is an AAC
    audio-specific-config with the recorded sample rate/size/channels.

    CATCHES: the set_peer_bandwidth limit_type symbol, the chunk-size update
    message, the aac audio header bitfield split and the data_message amf0
    array (@setDataFrame/onMetaData).
    """
    got = fq_json(tmp_path, ["-d", "rtmp", "-cV",
                             "{nmsg: (.messages|length), types: ([.messages[].message_type_id] | unique), spb: [.messages[] | select(.message_type_id == \"set_peer_bandwidth\")], scs: [.messages[] | select(.message_type_id == \"set_chunk_size\") | .size], uc0: [.messages[] | select(.message_type_id == \"user_control_message\") | {type, stream_id}][0:2], audio0: ([.messages[] | select(.message_type_id == \"audio_message\")][0] | {codec, sample_rate, sample_size, channels, type, dlen: (.data|length)}), data0: ([.messages[] | select(.message_type_id == \"data_message\")][0] | [.messages[] | {type, value}][0:2])}",
                             FFMPEG_SERVER])
    assert got == {
        "audio0": {"channels": 2, "codec": "aac", "dlen": 4,
                   "sample_rate": 44100, "sample_size": 16, "type": "asc"},
        "data0": [{"type": "string", "value": "@setDataFrame"},
                  {"type": "string", "value": "onMetaData"}],
        "nmsg": 421,
        "scs": [128],
        "spb": [{"chunk_size": 2500000, "limit_type": "dynamic",
                 "message_stream_id": 0,
                 "message_type_id": "set_peer_bandwidth"}],
        "types": ["audio_message", "command_message", "data_message",
                  "set_chunk_size", "set_peer_bandwidth",
                  "user_control_message", "window_acknowledgement_size"],
        "uc0": [{"stream_id": 0, "type": "stream_begin"},
                {"stream_id": 1, "type": "stream_begin"}],
    }


def test_rtmp_dispatch_from_pcap(tmp_path):
    """rtmp_sample.cap: the TCP connection on port 1935 has its client stream
    decoded as rtmp (format 'rtmp', port symbol 'rtmp'), and the client side
    sends connect/createStream/play commands.

    CATCHES: the pcap -> tcp_connections -> rtmp dispatch on the well-known
    RTMP port, and the amf0 command decoding inside that stream.
    """
    got = fq_json(tmp_path, ["-d", "pcap", "-cV",
                             "{net: .header.network, conns: [.tcp_connections[] | {cl: {ip: .client.ip, port: .client.port, fmt: (.client.stream|format)}, sv: {ip: .server.ip, port: .server.port}}], cmds: [.tcp_connections[0].client.stream.messages[] | select(.message_type_id == \"command_message\") | {name: .command_name.value, tid: .transaction_id.value, obj: .command_object.type}], hs: .tcp_connections[0].client.stream.handshake.c0.version}",
                             RTMP_CAP])
    assert got == {
        "cmds": [{"name": "connect", "obj": "object", "tid": 1},
                 {"name": "createStream", "obj": "null", "tid": 2},
                 {"name": "play", "obj": "null", "tid": 0}],
        "conns": [{"cl": {"fmt": "rtmp", "ip": "192.168.43.1", "port": 1177},
                   "sv": {"ip": "192.168.43.128", "port": "rtmp"}}],
        "hs": 3, "net": "ethernet",
    }
