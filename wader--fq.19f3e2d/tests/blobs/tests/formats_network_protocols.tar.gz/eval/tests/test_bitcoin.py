"""Bitcoin tests: block headers (with and without the blkdat magic/size
prefix), the transaction decoder (varint prefixes, segwit marker/flag and
witness stacks) and the script opcode disassembly reached through the
scriptsig/scriptpub fields.

Every expected value below was recorded by running the reference fq binary.
"""

import json
import struct

import pytest
from conftest import fq_json, run_ok, run_on

GENESIS = "bitcoin/genesis.dat"
TX_B941DDAD = "bitcoin/tx_b941ddad.dat"


# --------------------------------------------------------------- crafting


def varint(n):
    """A Bitcoin varint using the smallest legal prefix."""
    if n < 0xFD:
        return bytes([n])
    if n <= 0xFFFF:
        return b"\xfd" + struct.pack("<H", n)
    if n <= 0xFFFFFFFF:
        return b"\xfe" + struct.pack("<I", n)
    return b"\xff" + struct.pack("<Q", n)


def transaction(version=1, inputs=(), outputs=(), locktime=0, marker=None,
                flag=None, witnesses=None, input_count=None,
                output_count=None):
    """A Bitcoin transaction from (txid, vout, scriptsig, sequence) inputs and
    (value, scriptpub) outputs; marker/flag enable the segwit layout."""
    out = struct.pack("<I", version)
    if marker is not None:
        out += struct.pack("<BB", marker, flag)
    out += input_count if input_count is not None else varint(len(inputs))
    for txid, vout, scriptsig, sequence in inputs:
        out += txid + struct.pack("<I", vout) + varint(len(scriptsig)) \
            + scriptsig + struct.pack("<I", sequence)
    out += output_count if output_count is not None else varint(len(outputs))
    for value, scriptpub in outputs:
        out += struct.pack("<Q", value) + varint(len(scriptpub)) + scriptpub
    if witnesses is not None:
        for items in witnesses:
            out += varint(len(items))
            for item in items:
                out += varint(len(item)) + item
    return out + struct.pack("<I", locktime)


def test_genesis_block_with_header(tmp_path):
    """genesis.dat with has_header=true: the mainnet magic and 285-byte size
    are consumed first, then the 80-byte header (little-endian version, both
    hashes shown as byte-reversed hex, unix time, bits and nonce) and one
    coinbase transaction paying 5000000000 satoshis.

    CATCHES: the has_header option path (magic symbol + size framing) and the
    byte-reversed hash formatting of previous_block_hash/merkle_root.
    """
    got = fq_json(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                             "-cV", "{magic, size, header, tx_count, ntx: (.transactions|length), tx: .transactions[0] | {version, input_count, output_count, locktime, value: .outputs[0].value}}",
                             GENESIS])
    assert got == {
        "header": {"bits": 486604799,
                   "merkle_root": "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b",
                   "nonce": 2083236893,
                   "previous_block_hash": "0000000000000000000000000000000000000000000000000000000000000000",
                   "time": 1231006505, "version": 1},
        "magic": "mainnet", "ntx": 1, "size": 285, "tx": {
            "input_count": 1, "locktime": 0, "output_count": 1,
            "value": 5000000000, "version": 1},
        "tx_count": 1,
    }


def test_genesis_header_display_annotations(tmp_path):
    """The verbose block header renders version/bits/nonce as hex and annotates
    the time field with its RFC3339 rendering; both hashes keep their reversed
    hex display.

    CATCHES: the scalar annotations of the header fields — UintHex for
    version/bits/nonce and the unix-time description for time.
    """
    disp = run_ok(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                             ".header | dv", GENESIS])
    lines = disp.splitlines()
    assert lines[0] == ("    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
                        "|0123456789abcdef|.header{}: 0x8-0x58 (80)")
    assert ('0x00|                        01 00 00 00            |        ....    |'
            '  version: 0x1 0x8-0xc (4)') in lines
    assert ('0x40|                                    29 ab 5f 49|            )._I|'
            '  time: 1231006505 (2009-01-03T18:15:05Z) 0x4c-0x50 (4)') in lines
    assert ('0x50|ff ff 00 1d                                    |....            |'
            '  bits: 0x1d00ffff 0x50-0x54 (4)') in lines
    assert ('0x50|            1d ac 2b 7c                        |    ..+|        |'
            '  nonce: 0x7c2bac1d 0x54-0x58 (4)') in lines
    assert ('0x00|                                    00 00 00 00|            ....|'
            '  previous_block_hash: "' + "0" * 64 +
            '" (raw bits) 0xc-0x2c (32)') in lines
    assert ('0x20|                                    3b a3 ed fd|            ;...|'
            '  merkle_root: "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab'
            '2127b7afdeda33b" (raw bits) 0x2c-0x4c (32)') in lines


def test_genesis_coinbase_input(tmp_path):
    """The genesis transaction input has the all-zero txid, vout and sequence
    0xffffffff, a 77-byte scriptsig disassembled into three pushes (the last
    one being the Times headline) and a 67-byte pay-to-pubkey output.

    CATCHES: the coinbase symbol on an all-zero txid, and the dispatch of
    scriptsig/scriptpub into the bitcoin_script opcode decoder.
    """
    raw = open(__import__("conftest").DATA_DIR / GENESIS, "rb").read()
    # scriptsig/scriptpub byte ranges of the single genesis transaction.
    scriptsig, scriptpub = raw[131:208], raw[222:289]
    headline = ("The Times 03/Jan/2009 Chancellor on brink of second bailout "
                "for banks").encode()
    assert scriptsig == b"\x04\xff\xff\x00\x1d\x01\x04\x45" + headline
    assert scriptpub[:1] == b"\x41" and scriptpub[-1:] == b"\xac"
    # Binary push arguments are compared as hex: fq's JSON encoder renders
    # non-UTF-8 bytes as replacement characters, which is lossy.
    got = fq_json(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                             "-cV",
                             ".transactions[0].inputs[0] | {txid, vout, scriptsig_size, sequence, "
                             "args: [.scriptsig[].arg | tobytes | tohex], ops: [.scriptsig[].op]}",
                             GENESIS])
    assert got == {"args": ["ffff001d", "04", headline.hex()],
                   "ops": ["pushself", "pushself", "pushself"],
                   "scriptsig_size": 77, "sequence": 4294967295,
                   "txid": "0" * 64, "vout": 4294967295}
    got = fq_json(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                             "-cV",
                             ".transactions[0].outputs[0] | {value, scriptpub_size, "
                             "ops: [.scriptpub[].op], arg: (.scriptpub[0].arg | tobytes | tohex)}",
                             GENESIS])
    assert got == {"arg": scriptpub[1:-1].hex(),
                   "ops": ["pushself", "checksig"],
                   "scriptpub_size": 67, "value": 5000000000}
    disp = run_ok(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                             ".transactions[0].inputs | dv", GENESIS])
    lines = disp.splitlines()
    assert ('0x50|                                          00 00|              ..|'
            '    txid: "00000000000000000000000000000000000000000000000000000000'
            '00000000" (raw bits) (coinbase) 0x5e-0x7e (32)') in lines
    assert ('0x80|      4d                                       |  M             |'
            '    scriptsig_size: 77 0x82-0x83 (1)') in lines
    assert ('0xd0|ff ff ff ff                                    |....            |'
            '    sequence: 0xffffffff 0xd0-0xd4 (4)') in lines
    assert ('    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f'
            '|0123456789abcdef|    scriptsig[0:3]: (bitcoin_script) 0x83-0xd0 (77)') in lines


def test_genesis_without_header_option(tmp_path):
    """The default has_header=false reads the 80-byte header straight from
    offset 0, so the mainnet magic becomes the version, the blkdat size word
    becomes the start of previous_block_hash and tx_count is garbage — but the
    transaction array is still walked to the end of the buffer.

    CATCHES: the has_header default and that the header fields are read
    unconditionally from the current position (no magic probing).
    """
    got = fq_json(tmp_path, ["-d", "bitcoin_block", "-cV",
                             "{keys: keys, version: .header.version, previous_block_hash: .header.previous_block_hash, tx_count, ntx: (.transactions|length), tx0version: .transactions[0].version}",
                             GENESIS])
    assert got == {
        "keys": ["header", "tx_count", "transactions"],
        "ntx": 1, "previous_block_hash":
        "000000000000000000000000000000000000000000000000000000010000011d",
        "tx0version": 1, "tx_count": 107008509372858623,
        "version": 3652501241,
    }


@pytest.mark.parametrize("magic,symbol", [
    (b"\xf9\xbe\xb4\xd9", "mainnet"),
    (b"\x0b\x11\x09\x07", "testnet3"),
    (b"\xfa\xbf\xb5\xda", "regtest"),
])
def test_block_magic_symbols(tmp_path, magic, symbol):
    """The three known blkdat magics map to their network symbols and the
    following little-endian size word frames the block.

    CATCHES: the magic -> network symbol table (mainnet/testnet3/regtest) and
    that size is read little-endian to bound the block.
    """
    raw = open(__import__("conftest").DATA_DIR / GENESIS, "rb").read()
    data = magic + struct.pack("<I", 285) + raw[8:]
    got = fq_json(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                             "-cV", "{magic, size, tx_count}", "-"], stdin=data)
    assert got == {"magic": symbol, "size": 285, "tx_count": 1}


def test_block_unknown_magic_is_a_gap(tmp_path):
    """An unknown magic aborts the block decode: the whole input becomes gap0
    and the verbose display reports 'unknown magic 0'.

    CATCHES: the Fatalf path for an unrecognized blkdat magic (partial decode
    with a gap instead of fabricated header fields).
    """
    raw = open(__import__("conftest").DATA_DIR / GENESIS, "rb").read()
    data = b"\x00\x00\x00\x00" + struct.pack("<I", 285) + raw[8:]
    res = run_on(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                            "-cV", ".", "-"], stdin=data)
    assert res.returncode == 0
    assert list(json.loads(res.stdout)) == ["gap0"]
    # The gap keeps the exact input bytes (round-tripped through tohex).
    gap_hex = run_ok(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                                "-r", "-cV", ".gap0 | tobytes | tohex", "-"],
                    stdin=data)
    assert gap_hex == data.hex()
    disp = run_ok(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                             "dv", "-"], stdin=data)
    lines = disp.splitlines()
    assert lines[0].endswith(".{}: <stdin> (bitcoin_block) 0x0-0x125 (293)")
    assert ("error: bitcoin_block: error at position 0x0: unknown magic 0"
            in disp)
    assert "gap0: raw bits 0x0-0x125 (293)" in disp


def test_block_header_only_has_no_transactions(tmp_path):
    """A buffer holding exactly the 80-byte header decodes the header and stops
    before tx_count (has_header=false), while has_header=true with size 80
    frames the block to the header only as well.

    CATCHES: the 'BitsLeft == 0' early return that supports header-only
    blocks — no tx_count or transactions field is produced.
    """
    raw = open(__import__("conftest").DATA_DIR / GENESIS, "rb").read()
    header = raw[8:88]
    got = fq_json(tmp_path, ["-d", "bitcoin_block", "-cV",
                             "{keys: keys, time: .header.time}", "-"], stdin=header)
    assert got == {"keys": ["header"], "time": 1231006505}
    got = fq_json(tmp_path, ["-d", "bitcoin_block", "-o", "has_header=true",
                             "-cV", "{keys: keys, size, tx_count, ntx: (.transactions|length)}",
                             "-"],
                  stdin=b"\xf9\xbe\xb4\xd9" + struct.pack("<I", 80) + header)
    assert got == {"keys": ["magic", "size", "header"], "ntx": 0,
                   "size": 80, "tx_count": None}


def test_blkdat_wraps_blocks_with_headers(tmp_path):
    """bitcoin_blkdat decodes an array of blocks, each with the magic/size
    header consumed and the transactions parsed; the genesis file holds one
    block, two concatenated copies hold two.

    CATCHES: the blkdat root array (RootArray/RootName) and its loop that
    passes has_header=true to every embedded bitcoin_block.
    """
    got = fq_json(tmp_path, ["-d", "bitcoin_blkdat", "-cV",
                             "{n: length, b0: {magic: .[0].magic, size: .[0].size, tx_count: .[0].tx_count, header_time: .[0].header.time, ntx: (.[0].transactions|length)}}",
                             GENESIS])
    assert got == {"b0": {"header_time": 1231006505, "magic": "mainnet",
                          "ntx": 1, "size": 285, "tx_count": 1},
                   "n": 1}
    raw = open(__import__("conftest").DATA_DIR / GENESIS, "rb").read()
    doubled = tmp_path / "doubled.dat"
    doubled.write_bytes(raw + raw)
    got = fq_json(tmp_path, ["-d", "bitcoin_blkdat", "-cV",
                             "{n: length, magics: [.[] | .magic], sizes: [.[] | .size], ntx: [.[] | (.transactions|length)]}",
                             "doubled.dat"])
    assert got == {"magics": ["mainnet", "mainnet"], "n": 2, "ntx": [1, 1],
                   "sizes": [285, 285]}


def test_segwit_transaction_witness(tmp_path):
    """tx_b941ddad is a segwit transaction: marker 0 and flag 1 are split out
    of the version word, one input with an empty scriptsig, two outputs whose
    scriptpub starts with OP_TRUE/OP_FALSE and a three-item witness stack.

    CATCHES: the PeekUintBits(8)==0 marker/flag detection, the witness array
    (one witness per input, each a stack of length-prefixed items) and the
    per-output value/script decoding.
    """
    got = fq_json(tmp_path, ["-d", "bitcoin_transaction", "-cV",
                             "{version, marker, flag, input_count, output_count, locktime, input: (.inputs[0] | {txid, vout, scriptsig_size, sequence}), values: [.outputs[].value], sizes: [.outputs[].scriptpub_size], ops: [.outputs[].scriptpub[0]], witness: (.witnesses[0] | {witness_size, item_sizes: [.items[].item_size]})}",
                             TX_B941DDAD])
    assert got == {
        "flag": 1, "input": {"scriptsig_size": 0, "sequence": 4294967293,
                             "txid": "1efe0f1537ddd0b2f94d93b56d14f30f570b7495cfbf6cd0d77c7dc0e6f28905",
                             "vout": 0},
        "input_count": 1, "locktime": 0,
        "marker": 0, "ops": [{"op": "true"}, {"op": "false"}],
        "output_count": 2, "sizes": [34, 22],
        "values": [546, 1590], "version": 2, "witness": {"item_sizes": [64, 131, 33],
                                                         "witness_size": 3},
    }


@pytest.mark.parametrize("prefix", [b"\xfd", b"\xfe", b"\xff"])
def test_transaction_varint_prefixes(tmp_path, prefix):
    """input_count/output_count accept all three extended varint prefixes
    (0xfd + u16, 0xfe + u32, 0xff + u64, little-endian) and still count the
    same single input and output.

    CATCHES: decodeVarInt's prefix dispatch — a wrong endianness or width
    makes the counts (and therefore the whole transaction) misparse.
    """
    if prefix == b"\xfd":
        count = b"\xfd\x01\x00"
    elif prefix == b"\xfe":
        count = b"\xfe\x01\x00\x00\x00"
    else:
        count = b"\xff\x01\x00\x00\x00\x00\x00\x00\x00"
    tx = transaction(inputs=[(b"\x11" * 32, 0, b"", 1)],
                     outputs=[(1000, b"")], input_count=count,
                     output_count=count)
    got = fq_json(tmp_path, ["-d", "bitcoin_transaction", "-cV",
                             "{input_count, output_count, ni: (.inputs|length), no: (.outputs|length), locktime}",
                             "-"], stdin=tx)
    assert got == {"input_count": 1, "locktime": 0, "ni": 1, "no": 1,
                   "output_count": 1}


def test_transaction_crafted_script_ops(tmp_path):
    """A crafted output script disassembles into pushdata1 (with its
    arg_length/arg pair) followed by simple opcodes, and the input's sequence
    is displayed as hex while the txid is displayed byte-reversed.

    CATCHES: the bitcoin_script opcode table reached through scriptpub, the
    pushdata1 arg_length field, and the UintHex annotation of sequence.
    """
    scriptpub = b"\x4c\x03abc\x76\xa9\x8b\x51\xac"
    txid = bytes(range(1, 33))
    tx = transaction(inputs=[(txid, 7, b"", 0x12345678)],
                     outputs=[(123456789, scriptpub)], locktime=99)
    got = fq_json(tmp_path, ["-d", "bitcoin_transaction", "-cV", ".", "-"],
                  stdin=tx)
    assert got == {
        "input_count": 1,
        "inputs": [{"scriptsig": [], "scriptsig_size": 0,
                    "sequence": 305419896,
                    "txid": "201f1e1d1c1b1a191817161514131211100f0e0d0c0b0a090807060504030201",
                    "vout": 7}],
        "locktime": 99, "output_count": 1,
        "outputs": [{"scriptpub": [
            {"arg": "abc", "arg_length": 3, "op": "pushdata1"},
            {"op": "dup"}, {"op": "hash160"}, {"op": "1add"},
            {"op": "true"}, {"op": "checksig"}],
            "scriptpub_size": 10, "value": 123456789}],
        "version": 1,
    }
    disp = run_ok(tmp_path, ["-d", "bitcoin_transaction",
                             ".inputs | dv", "-"], stdin=tx)
    lines = disp.splitlines()
    assert ('0x00|               01 02 03 04 05 06 07 08 09 0a 0b|     ...........|'
            '    txid: "201f1e1d1c1b1a191817161514131211100f0e0d0c0b0a090807060504030201"'
            ' (raw bits) 0x5-0x25 (32)') in lines
    assert ('0x20|                              78 56 34 12      |          xV4.  |'
            '    sequence: 0x12345678 0x2a-0x2e (4)') in lines


def test_transaction_multi_input_output(tmp_path):
    """Two inputs with distinct txids and two outputs: each txid is shown as
    the reverse of its 32 wire bytes and per-input vout/sequence pairs are
    kept apart.

    CATCHES: the input/output array loops and the rawHexReverse transformation
    applied to every txid (not just the first).
    """
    tx = transaction(inputs=[(bytes(range(1, 33)), 1, b"", 1),
                             (b"\x22" * 32, 2, b"", 2)],
                     outputs=[(5, b""), (6, b"")])
    got = fq_json(tmp_path, ["-d", "bitcoin_transaction", "-cV",
                             "{txids: [.inputs[].txid], vouts: [.inputs[].vout], sequences: [.inputs[].sequence], values: [.outputs[].value]}",
                             "-"], stdin=tx)
    assert got == {
        "sequences": [1, 2],
        "txids": ["201f1e1d1c1b1a191817161514131211100f0e0d0c0b0a090807060504030201",
                  "2222222222222222222222222222222222222222222222222222222222222222"],
        "values": [5, 6], "vouts": [1, 2],
    }
