"""Shared helpers for the formats_network_protocols test module.

The program under test is fq.  These tests pin the network-protocol side of
its behavior: pcap/pcapng capture files, the link/network/transport stack
built on them (including IPv4 fragment and TCP stream reassembly), and the
application and blockchain formats carried inside (dns, tls with keylog
decryption, rtmp/amf0, fairplay, bitcoin, opentimestamps, negentropy).

Every test invokes the candidate binary through the helpers below so that
``PROGRAMGYM_EXECUTABLE`` is the only place the binary path is resolved and
so the child process always runs in a pinned, hermetic environment.

Fixtures live in ``eval/tests/data`` (mirroring the layout of the fq repo's
``format/*/testdata``).  ``run_on``/``run_ok``/``fq_json`` copy any argument
that names a fixture into ``tmp_path`` first (preserving its relative path),
so the child only ever sees file names inside ``tmp_path``.  Small inputs
are crafted by the byte-level helpers at the bottom (ethernet frames, IPv4 /
IPv6 / UDP / TCP headers, sll/sll2 link layers, pcap files).
"""

import json
import os
import shutil
import socket
import struct
import subprocess
from pathlib import Path

import pytest

TESTS_DIR = Path(__file__).resolve().parent
DATA_DIR = TESTS_DIR / "data"

# Fully pinned child environment: no inherited locale, color, unicode or
# config from the test runner, and no COLUMNS (fq then uses its default
# display width of 80, which is what the recorded expectations assume).
# HOME and XDG_CONFIG_HOME point at directories that do not exist so no fq
# config init.jq is ever picked up.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "xterm",
    "NO_COLOR": "",
    "XDG_CONFIG_HOME": "/nonexistent",
}


def _fq_bin():
    """Resolve the reference binary through PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        pytest.exit(
            "PROGRAMGYM_EXECUTABLE is not set (expected path to the fq binary)",
            returncode=90,
        )
    return path


def _child_env(env=None):
    """The pinned child environment plus per-test overrides.

    A ``None`` value removes the variable from the child environment; every
    other value overrides (or adds) it.  GOCOVERDIR is forwarded from the
    test process at call time so the pipeline can measure the source
    coverage of an instrumented reference binary.
    """
    child = dict(CHILD_ENV)
    for key, value in (env or {}).items():
        if value is None:
            child.pop(key, None)
        else:
            child[key] = value
    for key in ("GOCOVERDIR",):
        value = os.environ.get(key)
        if value:
            child[key] = value
    return child


def run_fq_bytes(args, input_bytes=b"", env=None, cwd=None, timeout=10):
    """Run fq and capture the raw stdout/stderr bytes."""
    if isinstance(input_bytes, str):
        input_bytes = input_bytes.encode("utf-8")
    return subprocess.run(
        [_fq_bin(), *[str(a) for a in args]],
        input=input_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=_child_env(env),
        cwd=cwd,
        timeout=timeout,
    )


def run_fq(args, input_text="", env=None, cwd=None, timeout=10):
    """Run fq with text/bytes stdin and capture both streams as text."""
    proc = run_fq_bytes(args, input_text, env, cwd, timeout)
    stderr = None if proc.stderr is None else proc.stderr.decode("utf-8", "replace")
    return subprocess.CompletedProcess(
        proc.args, proc.returncode, proc.stdout.decode("utf-8", "replace"), stderr
    )


def _is_fixture_path(arg):
    """True when arg names a fixture under data/ (never raises on odd args)."""
    if len(arg) > 200 or "\n" in arg:
        return False
    try:
        return (DATA_DIR / arg).is_file()
    except OSError:
        return False


def _materialize(tmp_path, args):
    """Turn data-relative fixture args into files inside tmp_path.

    Whole arguments that name a fixture are copied with their relative path
    intact (``pcap/ns.pcap`` stays ``pcap/ns.pcap`` inside tmp_path).  Option
    values of the shape ``key=@fixture`` (fq's option file syntax, used for
    ``-o keylog=@file``) get the same treatment for the path after ``@``.
    """
    final = []
    for arg in args:
        arg = str(arg)
        if _is_fixture_path(arg):
            src = DATA_DIR / arg
            dst = tmp_path / arg
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
            final.append(arg)
            continue
        if "=" in arg and not arg.startswith("-"):
            key, _, rest = arg.partition("=")
            if rest.startswith("@") and _is_fixture_path(rest[1:]):
                src = DATA_DIR / rest[1:]
                rel = rest[1:]
                dst = tmp_path / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, dst)
                final.append(f"{key}=@{rel}")
                continue
        final.append(arg)
    return final


def run_on(tmp_path, args, stdin=None, timeout=10):
    """Run the binary in tmp_path, copying any fixture arguments into it."""
    return run_fq_bytes(_materialize(tmp_path, args), stdin, cwd=str(tmp_path),
                        timeout=timeout)


def run_ok(tmp_path, args, stdin=None, timeout=10):
    """Run the binary, require exit 0 and return decoded stdout."""
    res = run_on(tmp_path, args, stdin=stdin, timeout=timeout)
    assert res.returncode == 0, (
        f"unexpected exit {res.returncode}: {res.stderr.decode('utf-8', 'replace')}"
    )
    # fq ends every value with a newline; compare without the trailing one.
    return res.stdout.decode("utf-8").rstrip("\n")


def fq_json(tmp_path, args, stdin=None, timeout=10):
    """Run the binary with a value-producing expression and parse JSON stdout."""
    return json.loads(run_ok(tmp_path, args, stdin=stdin, timeout=timeout))


def data_path(name):
    """Absolute path of a fixture in eval/tests/data (fails loudly if absent)."""
    path = DATA_DIR / name
    if not path.exists():
        pytest.fail(f"missing test fixture: {path}")
    return path


# --------------------------------------------------------------- crafting
# Minimal byte-level packet builders used to reach decoder paths that the
# checked-in captures do not cover.  Layouts follow the RFCs; only the
# reference binary decides what the decoders report for them.


def ip4(s):
    """The 4 raw bytes of a dotted-quad IPv4 address."""
    return socket.inet_aton(s)


def eth(dst, src, ethertype, payload=b""):
    """An ethernet II frame (dst/src MACs, EtherType, payload)."""
    return (bytes.fromhex(dst.replace(":", "")) + bytes.fromhex(src.replace(":", ""))
            + struct.pack(">H", ethertype) + payload)


def ipv4(src, dst, proto=17, payload=b"", ihl=5, options=b"", ttl=64, ident=1,
         flags=0, frag_off=0, dscp=0, ecn=0, total_length=None, check=None):
    """An IPv4 packet; the header checksum is computed unless given."""
    ver_ihl = (4 << 4) | ihl
    tos = (dscp << 2) | ecn
    if total_length is None:
        total_length = ihl * 4 + len(payload)
    off = (flags << 13) | frag_off
    hdr = struct.pack(">BBHHHBBH4s4s", ver_ihl, tos, total_length, ident, off,
                      ttl, proto, 0, ip4(src), ip4(dst)) + options
    if check is None:
        s = 0
        for i in range(0, len(hdr), 2):
            s += (hdr[i] << 8) | hdr[i + 1]
        while s >> 16:
            s = (s & 0xFFFF) + (s >> 16)
        check = (~s) & 0xFFFF
    hdr = hdr[:10] + struct.pack(">H", check) + hdr[12:]
    return hdr + payload


def udp(sport, dport, payload=b"", length=None, check=0):
    """A UDP datagram with a zero checksum by default."""
    if length is None:
        length = 8 + len(payload)
    return struct.pack(">HHHH", sport, dport, length, check) + payload


def tcp(sport, dport, seq=1, ack=0, flags=0x02, payload=b"", options=b"",
        win=8192, urgent=0):
    """A TCP segment; flags uses the usual NS..FIN bit layout below 0x100."""
    off = 5 + len(options) // 4
    return struct.pack(">HHIIBBHHH", sport, dport, seq, ack, (off << 4), flags,
                       win, 0, urgent) + options + payload


def ipv6(src, dst, nxt=17, hlim=64, plen=None, payload=b"", flow=0, ds=0, ecn=0):
    """An IPv6 packet (payload must be passed by keyword)."""
    if plen is None:
        plen = len(payload)
    return (struct.pack(">IHBB", (6 << 28) | (ds << 22) | (ecn << 20) | flow,
                        plen, nxt, hlim)
            + socket.inet_pton(socket.AF_INET6, src)
            + socket.inet_pton(socket.AF_INET6, dst) + payload)


def sll(ptype=0, arphdr=1, addrlen=6, addr=b"\xaa\xbb\xcc\xdd\xee\xff",
        protocol=0x0800, payload=b"", little_protocol=False):
    """A Linux cooked (SLL) v1 capture packet."""
    a = addr[:addrlen].ljust(addrlen, b"\x00")
    pfmt = "<H" if little_protocol else ">H"
    return (struct.pack(">HHH", ptype, arphdr, addrlen) + a
            + b"\x00" * (8 - min(addrlen, 8)) + struct.pack(pfmt, protocol) + payload)


def sll2(protocol=0x0800, reserved=0, ifidx=3, arphdr=1, ptype=0, addrlen=6,
         addr=b"\xaa\xbb\xcc\xdd\xee\xff", payload=b""):
    """A Linux cooked (SLL) v2 capture packet."""
    a = addr[:addrlen].ljust(addrlen, b"\x00")
    return (struct.pack(">HHIHBB", protocol, reserved, ifidx, arphdr, ptype,
                        addrlen) + a + b"\x00" * (8 - min(addrlen, 8)) + payload)


def dns_name(name):
    """A DNS name in label wire format with the terminating zero label."""
    out = b""
    for lbl in name.split("."):
        out += bytes([len(lbl)]) + lbl.encode()
    return out + b"\x00"


def make_pcap(packets, linktype=1, endian="<", magic=None, snaplen=65535,
              ts=(1, 0), orig_lens=None):
    """A classic pcap file.  The magic value is always stored big-endian;
    its value picks the endianness used for every other field."""
    if magic is None:
        magic = {"<": 0xD4C3B2A1, ">": 0xA1B2C3D4}[endian]
    out = struct.pack(">I", magic) + struct.pack(
        endian + "HHiIII", 2, 4, 0, 0, snaplen, linktype)
    for i, p in enumerate(packets):
        ol = len(p) if orig_lens is None else orig_lens[i]
        out += struct.pack(endian + "IIII", ts[0], ts[1], len(p), ol) + p
    return out


@pytest.fixture(name="run_fq")
def run_fq_fixture(tmp_path):
    """The text-mode run helper, running inside an isolated empty cwd."""

    def _run(args, input_text="", env=None, timeout=10):
        return run_fq(args, input_text, env, str(tmp_path), timeout)

    return _run
