"""ANT FIT decoder: file headers, definition/data record pairs and GPS records."""

import json

from conftest import run_fq


def test_fit_settings_definition_and_data_records(tmp_path):
    """A settings FIT interleaves definition and data records for three messages."""
    # CATCHES: definition/data alternation, file_id vs user_profile vs hrm_profile
    res = run_fq("-V", "-c", "-d", "fit", "keys", data="fit_settings.fit", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["header", "data_records", "crc"]
    res = run_fq(
        "-V", "-c", "-d", "fit",
        "{h: .header | {data_size, data_type, header_size, profile_version, "
        "protocol_version}, n: (.data_records | length), crc: .crc}",
        data="fit_settings.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "h": {"data_size": 68, "data_type": ".FIT", "header_size": 12,
              "profile_version": 71, "protocol_version": 16},
        "n": 6,
        "crc": 20537,
    }
    res = run_fq(
        "-V", "-c", "-d", "fit",
        "[.data_records[] | {rh: .record_header.message_type, "
        "gmn: (.definition_message.global_message_number // "
        ".data_message.global_message_name // .data_message.message_name // null)}]",
        data="fit_settings.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"gmn": "file_id", "rh": "definition"},
        {"gmn": None, "rh": "data"},
        {"gmn": "user_profile", "rh": "definition"},
        {"gmn": None, "rh": "data"},
        {"gmn": "hrm_profile", "rh": "definition"},
        {"gmn": None, "rh": "data"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "fit", ".data_records[0].definition_message",
        data="fit_settings.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "architecture": "big_endian",
        "field_definitions": [
            {"base_type": "uint16", "field_definition_number": "manufacturer", "size": 2},
            {"base_type": "uint16", "field_definition_number": "product", "size": 2},
            {"base_type": "uint32z", "field_definition_number": "serial_number", "size": 4},
            {"base_type": "enum", "field_definition_number": "type", "size": 1},
        ],
        "fields": 4,
        "global_message_number": "file_id",
        "reserved": 0,
    }


def test_fit_settings_data_messages(tmp_path):
    """Data messages resolve enums and scales for file_id, user_profile and hrm."""
    # CATCHES: type "settings", gender "male", weight 3379.5 and hrm_ant_id 25600
    res = run_fq(
        "-V", "-c", "-d", "fit", ".data_records[1].data_message",
        data="fit_settings.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "manufacturer": 256,
        "product": 56323,
        "serial_number": 1088553216,
        "type": "settings",
    }
    res = run_fq(
        "-V", "-c", "-d", "fit", ".data_records[3].data_message",
        data="fit_settings.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "age": 28, "gender": "male", "height": 1.9,
        "language": "english", "weight": 3379.5,
    }
    res = run_fq(
        "-V", "-c", "-d", "fit", ".data_records[5].data_message",
        data="fit_settings.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"hrm_ant_id": 25600}


def test_fit_activity_records(tmp_path):
    """An activity FIT decodes 2153 records, 12 message types and GPS positions."""
    # CATCHES: mixed symbolic/numeric global message numbers and semicircle lat/long
    res = run_fq(
        "-V", "-c", "-d", "fit",
        "{h: .header | {crc, data_size, data_type, header_size, profile_version, "
        "protocol_version}, n: (.data_records | length)}",
        data="fit_activity.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "h": {"crc": 1145, "data_size": 50711, "data_type": ".FIT",
              "header_size": 14, "profile_version": 1673, "protocol_version": 16},
        "n": 2153,
    }
    res = run_fq(
        "-V", "-c", "-d", "fit",
        '[.data_records[] | .record_header.message_type] | group_by(.) | map({t: .[0], n: length})',
        data="fit_activity.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"t": "data", "n": 2141}, {"t": "definition", "n": 12},
    ]
    res = run_fq(
        "-V", "-c", "-d", "fit",
        '[.data_records[] | select(.record_header.message_type == "definition") '
        "| .definition_message.global_message_number]",
        data="fit_activity.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "file_id", "file_creator", "event", "device_info", 22, "sport",
        "record", 104, "lap", "session", 113, "activity",
    ]
    res = run_fq(
        "-V", "-c", "-d", "fit",
        '[.data_records[] | select(.record_header.message_type == "data") '
        '| .data_message | select(has("position_lat"))] | .[0]',
        data="fit_activity.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "timestamp": 1062651602,
        "position_lat": 59.32686296291649,
        "position_long": 18.0508790910244,
        "distance": 0,
        "altitude": 6.399999999999977,
        "speed": 0,
        "heart_rate": 255,
        "cadence": 255,
    }
    res = run_fq(
        "-V", "-c", "-d", "fit",
        '.data_records[8].data_message | '
        "{device_index, garmin_product, manufacturer, software_version, timestamp}",
        data="fit_activity.fit", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "device_index": 1,
        "garmin_product": "edge25",
        "manufacturer": "garmin",
        "software_version": 3.3,
        "timestamp": 1062651602,
    }
