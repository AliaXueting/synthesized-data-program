"""Compression decoders: gzip members/multi-member streams and bzip2 blocks."""

import json

from conftest import run_fq


def test_gzip_member_fields_and_uncompressed(tmp_path):
    """A single-member gzip decodes DEFLATE metadata and the full payload."""
    # CATCHES: deflate method, crc32 1001993670, isize 5, mtime and os "unix"
    res = run_fq("-V", "-c", "-d", "gzip", "keys", data="gzip_test.gz", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["members", "uncompressed"]
    res = run_fq(
        "-V", "-c", "-d", "gzip", ".members | length",
        data="gzip_test.gz", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 1
    res = run_fq(
        "-V", "-c", "-d", "gzip",
        ".members[0] | {compression_method, crc32, isize, mtime, os, uncompressed}",
        data="gzip_test.gz", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "compression_method": "deflate",
        "crc32": 1001993670,
        "isize": 5,
        "mtime": 1609171521,
        "os": "unix",
        "uncompressed": "test\n",
    }
    res = run_fq(
        "-V", "-c", "-d", "gzip", ".uncompressed",
        data="gzip_test.gz", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == "test\n"


def test_gzip_multi_member_stream(tmp_path):
    """A two-member gzip concatenation decodes both members and joins payloads."""
    # CATCHES: per-member crc/isize pairs and the concatenated .uncompressed string
    res = run_fq(
        "-V", "-c", "-d", "gzip",
        "[.members[] | {compression_method, crc32, isize, mtime, os}]",
        data="gzip_multi.gz", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"compression_method": "deflate", "crc32": 2401690946, "isize": 11,
         "mtime": 1698099527, "os": "unix"},
        {"compression_method": "deflate", "crc32": 21407122, "isize": 10,
         "mtime": 1698099527, "os": "unix"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "gzip", ".uncompressed",
        data="gzip_multi.gz", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == "aaaaaaaaaa\nbbbbbbbbb\n"


def test_gzip_hexdump_display_layout(tmp_path):
    """Display mode renders a hexdump with the filename and members[0:1] annotation."""
    # CATCHES: offset ruler line, ".{}: <file> (gzip)" header and members[0:1] label
    res = run_fq("-d", "gzip", ".", data="gzip_test.gz", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert len(res.stdout) == 423
    lines = res.stdout.split(b"\n")
    assert lines[0] == (
        b"     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        b"|0123456789abcdef|.{}: gzip_test.gz (gzip)"
    )
    assert b"members[0:1]:" in lines[1]


def test_bzip2_block_structure(tmp_path):
    """bzip2 exposes the block magic/crc, huffman tree counts and footer padding."""
    # CATCHES: "BZ" magic, version 104, blocksize 57, two trees of length 3 and 13
    res = run_fq("-V", "-c", "-d", "bzip2", "keys", data="bzip2_test.bz2", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "magic", "version", "hundred_k_blocksize", "block",
        "uncompressed", "compressed", "footer",
    ]
    res = run_fq(
        "-V", "-c", "-d", "bzip2",
        "{magic, version, hks: .hundred_k_blocksize, unc: .uncompressed, "
        "t: (.compressed | type)}",
        data="bzip2_test.bz2", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": "BZ", "version": 104, "hks": 57, "unc": "test\n", "t": "string",
    }
    res = run_fq(
        "-V", "-c", "-d", "bzip2",
        ".block | {magic, crc, randomised, origptr, num_trees, num_sels, selector_list}",
        data="bzip2_test.bz2", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": 54156738319193,
        "crc": 3435360724,
        "randomised": 0,
        "origptr": 4,
        "num_trees": 2,
        "num_sels": 1,
        "selector_list": [0],
    }
    res = run_fq(
        "-V", "-c", "-d", "bzip2", "[.block.trees[] | length]",
        data="bzip2_test.bz2", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [3, 13]
    res = run_fq(
        "-V", "-c", "-d", "bzip2", ".footer",
        data="bzip2_test.bz2", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "crc": 3435360724, "magic": 25779555029136, "padding": "\u0000",
    }
