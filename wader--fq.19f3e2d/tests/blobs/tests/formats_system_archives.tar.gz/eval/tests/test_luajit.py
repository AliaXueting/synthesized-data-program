"""LuaJIT bytecode decoder: header flags, prototype headers, opcode disassembly."""

import json

from conftest import run_fq


def test_luajit_header_and_flags(tmp_path):
    """LuaJIT header exposes magic, source name, version and the flag bitfields."""
    # CATCHES: magic "\\x1bLJ", "@example.lua" name, raw flag word 12 with ffi+fr2 set
    res = run_fq(
        "-V", "-c", "-d", "luajit", ".header | {magic, name, namelen, version}",
        data="luajit_simple.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": "\u001bLJ",
        "name": "@example.lua",
        "namelen": 12,
        "version": 2,
    }
    res = run_fq(
        "-V", "-c", "-d", "luajit", ".header.flags",
        data="luajit_simple.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "be": False, "ffi": True, "fr2": True, "raw": 12, "strip": False,
    }
    res = run_fq(
        "-V", "-c", "-d", "luajit", "keys", data="luajit_simple.luac", cwd=tmp_path
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["header", "proto", "end"]


def test_luajit_first_prototype(tmp_path):
    """Prototype 0 decodes phead counters, UGET/arith opcodes and knum/uvdata."""
    # CATCHES: phead field names, bcins op symbols and knum/uvdata raw values
    res = run_fq(
        "-V", "-c", "-d", "luajit", ".proto[0].pdata.phead",
        data="luajit_simple.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "flags": 0,
        "numparams": 1,
        "framesize": 3,
        "numuv": 2,
        "numkgc": 0,
        "numkn": 2,
        "numbc": 7,
        "debuglen": 20,
        "firstline": 27,
        "numline": 3,
    }
    res = run_fq(
        "-V", "-c", "-d", "luajit", "[.proto[0].pdata.bcins[] | .op]",
        data="luajit_simple.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "UGET", "UGET", "ADDVV", "MULVV", "MULVN", "ADDVN", "RET1",
    ]
    res = run_fq(
        "-V", "-c", "-d", "luajit",
        "{knum: .proto[0].pdata.knum, uvdata: .proto[0].pdata.uvdata}",
        data="luajit_simple.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "knum": [2973289, 38793457897],
        "uvdata": [49153, 49154],
    }


def test_luajit_second_prototype(tmp_path):
    """Prototype 1 is the file-level chunk with its own phead and closure opcodes."""
    # CATCHES: proto array length 2, second prototype TDUP/FNEW/UCLO opcode stream
    res = run_fq(
        "-V", "-c", "-d", "luajit", ".proto | length",
        data="luajit_simple.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 2
    res = run_fq(
        "-V", "-c", "-d", "luajit", ".proto[1].pdata.phead",
        data="luajit_simple.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "flags": 7,
        "numparams": 0,
        "framesize": 7,
        "numuv": 0,
        "numkgc": 7,
        "numkn": 0,
        "numbc": 14,
        "debuglen": 40,
        "firstline": 0,
        "numline": 34,
    }
    res = run_fq(
        "-V", "-c", "-d", "luajit", "[.proto[1].pdata.bcins[] | .op]",
        data="luajit_simple.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "TDUP", "KCDATA", "GSET", "GSET", "KSHORT", "KSHORT", "FNEW", "GSET",
        "MOV", "KSHORT", "CALL", "GSET", "UCLO", "RET0",
    ]


def test_luajit_negative_and_stripped_variants(tmp_path):
    """A module returning a negative constant and a stripped chunk differ in flags."""
    # CATCHES: negative knum, strip flag variants and debug info keys dropped when stripped
    res = run_fq(
        "-V", "-c", "-d", "luajit", ".header.flags",
        data="luajit_negative.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "be": False, "ffi": False, "fr2": True, "raw": 10, "strip": True,
    }
    res = run_fq(
        "-V", "-c", "-d", "luajit",
        "{n: (.proto | length), ops: [.proto[0].pdata.bcins[] | .op], "
        "knum: .proto[0].pdata.knum}",
        data="luajit_negative.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 3, "ops": ["MULVN", "RET1"], "knum": [-2973289],
    }
    res = run_fq(
        "-V", "-c", "-d", "luajit", ".header | {magic, name, namelen, version}",
        data="luajit_stripped.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": "\u001bLJ", "name": None, "namelen": None, "version": 2,
    }
    res = run_fq(
        "-V", "-c", "-d", "luajit", ".proto[0].pdata | keys",
        data="luajit_stripped.luac", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["phead", "bcins", "uvdata", "kgc", "knum"]
