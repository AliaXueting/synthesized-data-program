"""ZIP decoder: end records, local/central entries, payloads and ZIP64 variants."""

import json

import pytest

from conftest import run_fq

LOCAL_ENTRY_QUERY = (
    "[.local_files[] | {fn: .file_name, cm: .compression_method, "
    "cs: .compressed_size, us: .uncompressed_size}]"
)

LOCAL_ENTRIES = [
    {"fn": "test/", "cm": "none", "cs": 0, "us": 0},
    {"fn": "test/a/", "cm": "none", "cs": 0, "us": 0},
    {"fn": "test/a/a.txt", "cm": "none", "cs": 4, "us": 4},
    {"fn": "test/a.txt", "cm": "deflated", "cs": 6, "us": 53},
    {"fn": "test/b.png", "cm": "deflated", "cs": 208, "us": 259},
]


def test_zip_root_keys_and_end_of_central_directory(tmp_path):
    """ZIP root lists local files, central directories and the EOCD record."""
    # CATCHES: EOCD signature PK\\x05\\x06, 5 records, central dir at offset 552 size 394
    res = run_fq("-V", "-c", "-d", "zip", "keys", data="zip_test0.zip", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "local_files",
        "central_directories",
        "end_of_central_directory_record",
    ]
    res = run_fq(
        "-V", "-c", "-d", "zip", ".end_of_central_directory_record",
        data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "signature": "PK\u0005\u0006",
        "disk_nr": 0,
        "central_directory_start_disk_nr": 0,
        "nr_of_central_directory_records_on_disk": 5,
        "nr_of_central_directory_records": 5,
        "size_of_central_directory": 394,
        "offset_of_start_of_central_directory": 552,
        "comment_length": 0,
        "comment": "",
    }


@pytest.mark.parametrize("data", ["zip_test0.zip", "zip_test9.zip"])
def test_zip_local_file_entries(data, tmp_path):
    """Local file headers expose names, compression method and both sizes."""
    # CATCHES: stored dirs (none/0), deflated a.txt 6->53 and b.png 208->259
    res = run_fq(
        "-V", "-c", "-d", "zip", LOCAL_ENTRY_QUERY, data=data, cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == LOCAL_ENTRIES
    res = run_fq("-V", "-c", "-d", "zip", ".local_files[0] | keys", data=data, cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "signature",
        "version_needed",
        "flags",
        "compression_method",
        "last_modification",
        "crc32_uncompressed",
        "compressed_size",
        "uncompressed_size",
        "file_name_length",
        "extra_field_length",
        "file_name",
        "extra_fields",
        "uncompressed",
    ]


def test_zip_central_directory_entries(tmp_path):
    """Central directory records mirror local entries and add the crc32 field."""
    # CATCHES: crc32 values 2912478533/2863892780/4220544717 for the three files
    res = run_fq(
        "-V", "-c", "-d", "zip", ".central_directories[0] | keys",
        data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "signature",
        "version_made_by",
        "version_needed",
        "flags",
        "compression_method",
        "last_modification",
        "crc32_uncompressed",
        "compressed_size",
        "uncompressed_size",
        "file_name_length",
        "extra_field_length",
        "file_comment_length",
        "disk_number_where_file_starts",
        "internal_file_attributes",
        "external_file_attributes",
        "relative_offset_of_local_file_header",
        "file_name",
        "extra_fields",
        "file_comment",
    ]
    res = run_fq(
        "-V", "-c", "-d", "zip",
        "[.central_directories[] | {fn: .file_name, cm: .compression_method, "
        "cs: .compressed_size, us: .uncompressed_size, crc: .crc32_uncompressed}]",
        data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"fn": "test/", "cm": "none", "cs": 0, "us": 0, "crc": 0},
        {"fn": "test/a/", "cm": "none", "cs": 0, "us": 0, "crc": 0},
        {"fn": "test/a/a.txt", "cm": "none", "cs": 4, "us": 4, "crc": 2912478533},
        {"fn": "test/a.txt", "cm": "deflated", "cs": 6, "us": 53, "crc": 2863892780},
        {"fn": "test/b.png", "cm": "deflated", "cs": 208, "us": 259, "crc": 4220544717},
    ]


def test_zip_uncompressed_member_payloads(tmp_path):
    """Stored and deflated members expose .uncompressed as strings or nested decoders."""
    # CATCHES: a.txt inflates to 53 'a's and b.png decodes to a nested PNG value
    res = run_fq(
        "-V", "-c", "-d", "zip", '[.local_files[] | {fn: .file_name, t: (.uncompressed | type)}]',
        data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"fn": "test/", "t": "string"},
        {"fn": "test/a/", "t": "string"},
        {"fn": "test/a/a.txt", "t": "string"},
        {"fn": "test/a.txt", "t": "string"},
        {"fn": "test/b.png", "t": "object"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "zip", ".local_files[3].uncompressed",
        data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == "a" * 53
    res = run_fq(
        "-V", "-c", "-d", "zip", ".local_files[4].uncompressed | keys",
        data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["signature", "chunks"]
    res = run_fq(
        "-V", "-c", "-d", "zip",
        ".local_files[4].uncompressed.chunks[0] | {type, width, height, bit_depth, color_type}",
        data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "type": "IHDR", "width": 4, "height": 4, "bit_depth": 1,
        "color_type": "grayscale",
    }


def test_zip_uncompress_option_does_not_change_output(tmp_path):
    """-o uncompress=true produces the same value shapes as the default decode."""
    # CATCHES: the uncompress option is effectively already the default behavior
    query = '[.local_files[] | {fn: .file_name, t: (.uncompressed | type)}]'
    res = run_fq("-V", "-c", "-d", "zip", query, data="zip_test0.zip", cwd=tmp_path)
    assert res.returncode == 0
    default_out = res.stdout
    res = run_fq(
        "-V", "-c", "-d", "zip", "-o", "uncompress=true", query,
        data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stdout == default_out
    res = run_fq(
        "-V", "-c", "-d", "zip", "-o", "uncompress=true",
        ".local_files[3].uncompressed", data="zip_test0.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == "a" * 53


def test_zip64_extended_sizes_and_extra_fields(tmp_path):
    """A ZIP64 archive keeps 0xffffffff size placeholders and zip64 extra fields."""
    # CATCHES: 4294967295 placeholders plus tag 1/30837/21589 extra field decoding
    res = run_fq(
        "-V", "-c", "-d", "zip",
        "[.local_files[] | {cs: .compressed_size, us: .uncompressed_size}]",
        data="zip_test64.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"cs": 4294967295, "us": 4294967295},
    ] * 5
    res = run_fq(
        "-V", "-c", "-d", "zip", ".local_files[0].extra_fields",
        data="zip_test64.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {
            "tag": 21589,
            "size": 9,
            "flags": {
                "access_time_present": True,
                "creation_time_present": False,
                "modification_time_present": True,
                "unused": 0,
            },
            "modification_time": 1642009879,
            "access_time": 1644517213,
        },
        {
            "tag": 30837,
            "size": 11,
            "data": "\u0001\u0004\ufffd\u0001\u0000\u0000\u0004\u0014\u0000\u0000\u0000",
        },
        {"tag": 1, "size": 16, "uncompressed_size": 0, "compressed_size": 0},
    ]


def test_zip64_offset_and_macos_extra_fields(tmp_path):
    """ZIP64 EOCD/locator appear in root keys; macOS zips carry timestamps."""
    # CATCHES: EOCD64 record fields and creation/access/modification time triples
    res = run_fq("-V", "-c", "-d", "zip", "keys", data="zip64_offset.zip", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "local_files",
        "central_directories",
        "end_of_central_directory_record_zip64",
        "end_of_central_directory_locator",
        "end_of_central_directory_record",
    ]
    res = run_fq(
        "-V", "-c", "-d", "zip", '[.local_files[].file_name]',
        data="zip64_offset.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["-"]
    res = run_fq(
        "-V", "-c", "-d", "zip", ".end_of_central_directory_record_zip64",
        data="zip64_offset.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "signature": "PK\u0006\u0006",
        "version_made_by": 798,
        "version_needed_to_extract": 45,
        "disk_nr": 0,
        "central_directory_start_disk_nr": 0,
        "nr_of_central_directory_records_on_disk": 1,
        "nr_of_central_directory_records": 1,
        "size_of_central_directory": 47,
        "offset_of_start_of_central_directory": 53,
        "size_of_end_of_central_directory": 44,
        "extensible_data": [],
    }
    res = run_fq(
        "-V", "-c", "-d", "zip", ".local_files[0].extra_fields",
        data="zip_test_macos.zip", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {
            "tag": 21589,
            "size": 13,
            "flags": {
                "access_time_present": True,
                "creation_time_present": True,
                "modification_time_present": True,
                "unused": 0,
            },
            "creation_time": 1637453978,
            "modification_time": 1637453978,
            "access_time": 1637453979,
        },
        {
            "tag": 30837,
            "size": 11,
            "data": "\u0001\u0004\ufffd\u0001\u0000\u0000\u0004\u0014\u0000\u0000\u0000",
        },
    ]
