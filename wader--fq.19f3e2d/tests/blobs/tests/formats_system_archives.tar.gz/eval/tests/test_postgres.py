"""PostgreSQL decoders: pg_control versions, heap pages, btree metapages/leaves."""

import json

import pytest

from conftest import run_fq


def test_pg_control_pg14_fields(tmp_path):
    """A PostgreSQL 14 control file decodes version, catalog, state, LSN and crc."""
    # CATCHES: pg_control_version 1300, DB_IN_PRODUCTION, hex LSN string and crc
    res = run_fq(
        "-V", "-c", "-d", "pg_control",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state, "
        "cp: .check_point, crc: .crc}",
        data="pg_control_pg14", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": 1300, "cat": 202107181, "state": "DB_IN_PRODUCTION",
        "cp": "0/9AD688C0", "crc": 3945231947,
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_control", "keys", data="pg_control_pg14", cwd=tmp_path,
    )
    assert res.returncode == 0
    keys = json.loads(res.stdout)
    assert keys[0:5] == [
        "system_identifier", "pg_control_version", "catalog_version_no",
        "state", "hole0",
    ]
    assert "mock_authentication_nonce" in keys
    assert keys[-3:] == ["crc", "padding1", "unused"]


def test_pg_control_unknown_flavour_falls_back(tmp_path):
    """An unknown flavour option silently falls back to auto-detection."""
    # CATCHES: flavour=bogus12 still decodes the same pg14 version fields
    res = run_fq(
        "-V", "-c", "-d", "pg_control", "-o", "flavour=bogus12",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state}",
        data="pg_control_pg14", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": 1300, "cat": 202107181, "state": "DB_IN_PRODUCTION",
    }


def test_pg_control_pg10_fields(tmp_path):
    """A PostgreSQL 10 control file reports version 1002 and 8192-byte blocks."""
    # CATCHES: v 1002, cat 201707211, system_identifier and blcksz 8192
    res = run_fq(
        "-V", "-c", "-d", "pg_control",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state, "
        "sysid: .system_identifier, blcksz: .blcksz}",
        data="pg_control_pg10", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": 1002, "cat": 201707211, "state": "DB_IN_PRODUCTION",
        "sysid": 7150673619342883148, "blcksz": 8192,
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_control", "-o", "flavour=postgres10",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state}",
        data="pg_control_pg10", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": 1002, "cat": 201707211, "state": "DB_IN_PRODUCTION",
    }


def test_pg_control_pgproee_version_is_string(tmp_path):
    """Postgres Pro Enterprise reports pg_control_version as a string, not a number."""
    # CATCHES: v "Postgres Pro Enterprise 1300" string plus its own catalog number
    res = run_fq(
        "-V", "-c", "-d", "pg_control",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state}",
        data="pg_control_pgproee15", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": "Postgres Pro Enterprise 1300",
        "cat": 202209081,
        "state": "DB_IN_PRODUCTION",
    }


def test_pg_heap_page_header(tmp_path):
    """A heap file decodes two pages with an 11-field page header each."""
    # CATCHES: pd_lower/pd_upper free space, hex LSN pair, 8196 pagesize_version
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", "{n: (. | length), k0: (.[0] | keys)}",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 2,
        "k0": ["page_header", "pd_linp", "free_space", "tuples"],
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", ".[0].page_header",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "pd_checksum": 0,
        "pd_checksum_check": 18367,
        "pd_checksum_check_equal": False,
        "pd_flags": 0,
        "pd_lower": 928,
        "pd_lsn": {"xlogid": "0", "xrecoff": "9AD84A80"},
        "pd_pagesize_version": 8196,
        "pd_prune_xid": 0,
        "pd_special": 8192,
        "pd_upper": 992,
    }


def test_pg_heap_line_pointers_and_first_tuple(tmp_path):
    """Line pointers decode LP_DEAD entries and the first tuple holds raw row data."""
    # CATCHES: 226 linps vs 225 tuples, LP_DEAD item 0 and infomask xmin/xmax bits
    res = run_fq(
        "-V", "-c", "-d", "pg_heap",
        "{nlinp: (.[0].pd_linp | length), ntup: (.[0].tuples | length)}",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"nlinp": 226, "ntup": 225}
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", ".[0].pd_linp[0]",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "item_id_data": 98304, "lp_flags": "LP_DEAD", "lp_len": 0, "lp_off": 0,
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", ".[0].tuples[0] | keys",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["header", "data", "padding1"]
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", ".[0].tuples[0].data",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == "02000000"
    res = run_fq(
        "-V", "-c", "-d", "pg_heap",
        ".[0].tuples[0].header.infomask | "
        "{heap_xmin_committed, heap_xmax_invalid, heap_lock_mask}",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "heap_xmin_committed": True,
        "heap_xmax_invalid": True,
        "heap_lock_mask": True,
    }


def test_pg_heap_page_and_segment_options_shift_checksums(tmp_path):
    """page=/segment= options only renumber the checksum block, not the decode."""
    # CATCHES: page=1 -> 18368, segment=1 -> 18369, page=123 -> 18426, same pd_upper
    res = run_fq(
        "-V", "-c", "-d", "pg_heap",
        "{c: .[0].page_header.pd_checksum_check, l: .[0].page_header.pd_lower, "
        "u: .[0].page_header.pd_upper}",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"c": 18367, "l": 928, "u": 992}
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", "-o", "page=1",
        "{c: .[0].page_header.pd_checksum_check, l: .[0].page_header.pd_lower, "
        "u: .[0].page_header.pd_upper}",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"c": 18368, "l": 928, "u": 992}
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", "-o", "segment=1",
        "{c: .[0].page_header.pd_checksum_check, u: .[0].page_header.pd_upper}",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"c": 18369, "u": 992}
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", "-o", "page=123",
        ".[0].page_header.pd_checksum_check",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 18426
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", "-o", "page=2", ". | length",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 2
    res = run_fq(
        "-V", "-c", "-d", "pg_heap",
        "{c: .[1].page_header.pd_checksum_check, u: .[1].page_header.pd_upper}",
        data="pg_heap_16994", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"c": 4775, "u": 960}


def test_pg_btree_meta_page(tmp_path):
    """A btree index decodes its metapage with btm_magic 340322 and fastroot 290."""
    # CATCHES: metapage-only keys on page 0, full btm_* fields and is_meta flag
    res = run_fq(
        "-V", "-c", "-d", "pg_btree",
        "{n: (. | length), k0: (.[0] | keys), k1: (.[1] | keys)}",
        data="pg_btree_16404", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 2,
        "k0": ["page_header", "meta_page_data", "unused0", "page_opaque_data"],
        "k1": ["page_header", "pd_linp", "free_space", "tuples", "page_opaque_data"],
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_btree", ".[0].page_header | {pd_flags, pd_lower, pd_upper}",
        data="pg_btree_16404", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"pd_flags": 0, "pd_lower": 72, "pd_upper": 8176}
    res = run_fq(
        "-V", "-c", "-d", "pg_btree", ".[0].meta_page_data",
        data="pg_btree_16404", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "btm_magic": 340322,
        "btm_version": 4,
        "btm_root": 290,
        "btm_level": 2,
        "btm_fastroot": 290,
        "btm_fastlevel": 2,
        "btm_allequalimage": 1,
        "btm_last_cleanup_num_delpages": 0,
        "btm_last_cleanup_num_heap_tuples": -1,
        "hole0": 0,
        "padding0": 0,
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_btree",
        ".[0].page_opaque_data.btpo_flags | {is_leaf, is_meta, is_root}",
        data="pg_btree_16404", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"is_leaf": False, "is_meta": True, "is_root": False}


def test_pg_btree_leaf_page_tuples(tmp_path):
    """The btree leaf page holds 367 tuples with t_info 8208 and a blkid tid."""
    # CATCHES: linp/tuple parity, has_nulls/has_var_widths flags and t_tid pairing
    res = run_fq(
        "-V", "-c", "-d", "pg_btree",
        "{nlinp: (.[1].pd_linp | length), ntuples: (.[1].tuples | length)}",
        data="pg_btree_16404", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"nlinp": 367, "ntuples": 367}
    res = run_fq(
        "-V", "-c", "-d", "pg_btree", ".[1].tuples[0].index_tuple_data",
        data="pg_btree_16404", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "data": "o\u0001\u0000\u0000\u0000\u0000\u0000\u0000",
        "flags": {"has_nulls": False, "has_var_widths": False},
        "size": 16,
        "t_info": 8208,
        "t_tid": {"ip_blkid": 393216, "ip_posid": 1},
    }


def test_pg_btree_non_btree_file_errors(tmp_path):
    """A heap file force-decoded as btree yields garbage, a query error and a note."""
    # CATCHES: btm_magic 65613 garbage, exit 5 keys error and inline invalid btmMagic
    res = run_fq(
        "-V", "-c", "-d", "pg_btree", ".[0] | keys",
        data="pg_btree_33233", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["page_header", "meta_page_data"]
    res = run_fq(
        "-V", "-c", "-d", "pg_btree", ".[0].meta_page_data.btm_magic",
        data="pg_btree_33233", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 65613
    res = run_fq(
        "-V", "-c", "-d", "pg_btree", ".[1] | keys",
        data="pg_btree_33233", cwd=tmp_path,
    )
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: pg_btree_33233: keys cannot be applied to: string\n"
    res = run_fq("-d", "pg_btree", ".", data="pg_btree_33233", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert len(res.stdout) == 654
    assert b"error: pg_btree: error at position 0x48: invalid btmMagic = 1004D, must be 53162" in res.stdout


def test_pg_heap_flavour_reinterprets_btree_file(tmp_path):
    """Forcing pg_heap on the btree file decodes LP_REDIRECT and LP_NORMAL items."""
    # CATCHES: flavour=postgres14 reinterpretation yields redirect/normal line pointers
    res = run_fq(
        "-V", "-c", "-d", "pg_heap", "-o", "flavour=postgres14",
        ".[0].pd_linp[0,1,-1]",
        data="pg_btree_33233", cwd=tmp_path,
    )
    assert res.returncode == 0
    values = [json.loads(line) for line in res.stdout.splitlines()]
    assert values == [
        {"item_id_data": 65613, "lp_flags": "LP_REDIRECT", "lp_len": 0, "lp_off": 77},
        {"item_id_data": 65642, "lp_flags": "LP_REDIRECT", "lp_len": 0, "lp_off": 106},
        {"item_id_data": 15893120, "lp_flags": "LP_NORMAL", "lp_len": 121, "lp_off": 640},
    ]


def test_pg_control_pgpro_standard_flavour(tmp_path):
    """Postgres Pro Standard 10 reports its version as a string under pgpro flavour."""
    # CATCHES: "Postgres Pro Standard 1002" string, catalog 201709291, option pgpro10
    res = run_fq(
        "-V", "-c", "-d", "pg_control",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state}",
        data="pgpro10_pg_control", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": "Postgres Pro Standard 1002",
        "cat": 201709291,
        "state": "DB_IN_PRODUCTION",
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_control", "-o", "flavour=pgpro10",
        "{v: .pg_control_version, cat: .catalog_version_no}",
        data="pgpro10_pg_control", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": "Postgres Pro Standard 1002", "cat": 201709291,
    }


def test_pg_control_postgres15_data_decodes_with_1300_layout(tmp_path):
    """A PostgreSQL 15 control file (v1300) still decodes under the shared layout."""
    # CATCHES: no postgres15 flavour exists yet v1300 data decodes its catalog number
    res = run_fq(
        "-V", "-c", "-d", "pg_control",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state}",
        data="pg15_pg_control", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": 1300, "cat": 202209061, "state": "DB_IN_PRODUCTION",
    }


@pytest.mark.parametrize(
    ("data", "flavour", "version", "catalog", "nkeys"),
    [
        ("pg_control_postgres11", "postgres11", 1100, 201809051, 44),
        ("pg_control_postgres12", "postgres12", 1201, 201909212, 44),
        ("pg_control_postgres13", "postgres13", 1300, 202007201, 43),
        ("pg_control_pgpro11", "pgpro11", "Postgres Pro Standard 1100",
         201809181, 44),
        ("pg_control_pgpro12", "pgpro12", "Postgres Pro Standard 1201",
         201911191, 44),
        ("pg_control_pgpro13", "pgpro13", "Postgres Pro Standard 1300",
         202010141, 43),
        ("pg_control_pgpro14", "pgpro14", "Postgres Pro Standard 1300",
         202110041, 43),
        ("pg_control_pgproee10", "pgproee10", "Postgres Pro Enterprise 1002",
         201709292, 47),
        ("pg_control_pgproee11", "pgproee11", "Postgres Pro Enterprise 1200",
         201809182, 48),
        ("pg_control_pgproee12", "pgproee12", "Postgres Pro Enterprise 1201",
         201911201, 48),
        ("pg_control_pgproee13", "pgproee13", "Postgres Pro Enterprise 1300",
         202010151, 45),
        ("pg_control_pgproee14", "pgproee14", "Postgres Pro Enterprise 1300",
         202203031, 45),
    ],
)
def test_pg_control_flavour_dispatch_matrix(
    tmp_path, data, flavour, version, catalog, nkeys,
):
    """Each flavour decodes the same fields probed or forced via the option."""
    # CATCHES: per-flavour version strings/numbers, catalog numbers and key counts
    res = run_fq(
        "-V", "-c", "-d", "pg_control",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state, "
        "n: (keys | length)}",
        data=data, cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": version, "cat": catalog, "state": "DB_IN_PRODUCTION", "n": nkeys,
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_control", "-o", f"flavour={flavour}",
        "{v: .pg_control_version, cat: .catalog_version_no, state: .state}",
        data=data, cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v": version, "cat": catalog, "state": "DB_IN_PRODUCTION",
    }


def test_pg_control_pgproee15_option_changes_layout(tmp_path):
    """Explicit flavour=pgproee15 drops the icu_version/padding0 probing adds."""
    # CATCHES: probing routes EE 1300 data to the pgproee14 layout (45 keys)
    res = run_fq(
        "-V", "-c", "-d", "pg_control",
        '{n: (keys | length), icu: has("icu_version"), pad: has("padding0"), '
        'v: .icu_version}',
        data="pg_control_pgproee15", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 45, "icu": True, "pad": True, "v": "0.0.255.255",
    }
    res = run_fq(
        "-V", "-c", "-d", "pg_control", "-o", "flavour=pgproee15",
        '{n: (keys | length), icu: has("icu_version"), pad: has("padding0"), '
        'v: .icu_version}',
        data="pg_control_pgproee15", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 43, "icu": False, "pad": False, "v": None,
    }


def test_pg_control_unsupported_version_errors(tmp_path):
    """An unknown pg_control_version aborts at offset 0 leaving only gap0."""
    # CATCHES: probe reads version 9999, fatals, and display prints the error line
    res = run_fq(
        "-V", "-c", "-d", "pg_control", ".",
        data="pg_control_bogus_version", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"gap0": "ABCDEFGH\x0f'\x00\x00"}
    res = run_fq(
        "-d", "pg_control", ".", data="pg_control_bogus_version", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert b"error: pg_control: error at position 0x0: "
           b"unsupported PG_CONTROL_VERSION = 9999" in res.stdout
