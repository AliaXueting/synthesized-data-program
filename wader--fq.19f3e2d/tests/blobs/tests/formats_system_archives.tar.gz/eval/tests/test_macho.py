"""Mach-O decoders: thin 64-bit execute header/commands/symtab and fat archives."""

import json

from conftest import run_fq


def test_macho_header_and_keys(tmp_path):
    """Mach-O root layout and the header magic/cpu/filetype/ncdms scalars."""
    # CATCHES: root keys header+load_commands+gap0..4, magic symbol "64le", ncdms 16
    res = run_fq("-V", "-c", "-d", "macho", "keys", data="macho_amd64", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "header", "load_commands", "gap0", "gap1", "gap2", "gap3", "gap4",
    ]
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".header | {magic, cputype, cpusubtype, filetype, ncdms, sizeofncdms}",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": "64le",
        "cputype": "x86_64",
        "cpusubtype": 3,
        "filetype": "execute",
        "ncdms": 16,
        "sizeofncdms": 1320,
    }


def test_macho_load_command_types(tmp_path):
    """All 16 load commands decode to their symbolic cmd names in order."""
    # CATCHES: exact ordered cmd list incl dyld_info_only, dysymtab, function_starts
    res = run_fq(
        "-V", "-c", "-d", "macho", "[.load_commands[] | .cmd]",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "segment_64", "segment_64", "segment_64", "segment_64", "dyld_info_only",
        "symtab", "dysymtab", "load_dylinker", "uuid", "version_min_macosx",
        "source_version", "main", "load_dylib", "load_dylib", "function_starts",
        "data_in_code",
    ]


def test_macho_segment_commands(tmp_path):
    """Segment commands expose __PAGEZERO and __TEXT geometry via .segment_command."""
    # CATCHES: nested segment_command fields (segname/vmaddr/vmsize/initprot/nsects)
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[0] | {cmd, cmdsize}",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"cmd": "segment_64", "cmdsize": 72}
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".load_commands[0].segment_command | {segname, vmaddr, vmsize, fileoff, nsects}",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "segname": "__PAGEZERO",
        "vmaddr": 0,
        "vmsize": 4294967296,
        "fileoff": 0,
        "nsects": 0,
    }
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".load_commands[1].segment_command "
        "| {segname, vmaddr, vmsize, fileoff, nsects, initprot}",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "segname": "__TEXT",
        "vmaddr": 4294967296,
        "vmsize": 16384,
        "fileoff": 0,
        "nsects": 5,
        "initprot": 5,
    }


def test_macho_sections_of_text_segment(tmp_path):
    """Sections of the __TEXT segment list sectname/offset/size for all five."""
    # CATCHES: sections appear at load-command level (not inside .segment_command)
    res = run_fq(
        "-V", "-c", "-d", "macho",
        "[.load_commands[1].sections[] | {name: .sectname, offset, size}]",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"name": "__text", "offset": 16192, "size": 52},
        {"name": "__stubs", "offset": 16244, "size": 12},
        {"name": "__stub_helper", "offset": 16256, "size": 36},
        {"name": "__cstring", "offset": 16292, "size": 5},
        {"name": "__unwind_info", "offset": 16300, "size": 72},
    ]


def test_macho_symtab_command(tmp_path):
    """The symtab load command flattens nsyms/symoff/stroff/strsize plus symbols."""
    # CATCHES: symtab fields at command level, symbol strx resolution and raw str_table
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".load_commands[5] | {cmd, cmdsize, nsyms, symoff, stroff, strsize}",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "cmd": "symtab",
        "cmdsize": 24,
        "nsyms": 6,
        "symoff": 32896,
        "stroff": 33016,
        "strsize": 72,
    }
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[5].symbols | length",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 6
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[5].symbols[0]",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "strx": "__mh_execute_header",
        "value": 4294967296,
        "type": {"ext": 1, "pext": 0, "stab": 0, "type": "sect"},
        "sect": 1,
        "desc": 16,
    }
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[5].str_table",
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == (
        " \u0000__mh_execute_header\u0000_aaa\u0000_main\u0000_libbbb_bbb\u0000"
        "_printf\u0000dyld_stub_binder\u0000\u0000\u0000"
    )


def test_macho_dylibs_dylinker_and_version_min(tmp_path):
    """load_dylib install names, the dyld path and the version_min_macosx pair."""
    # CATCHES: dylib_command.name paths and packed version/sdk integers
    res = run_fq(
        "-V", "-c", "-d", "macho",
        '[.load_commands[] | select(.cmd == "load_dylib") | .dylib_command.name]',
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["libbbb.so", "/usr/lib/libSystem.B.dylib"]
    res = run_fq(
        "-V", "-c", "-d", "macho",
        '[.load_commands[] | select(.cmd == "load_dylinker") | .name]',
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["/usr/lib/dyld"]
    res = run_fq(
        "-V", "-c", "-d", "macho",
        '[.load_commands[] | select(.cmd == "version_min_macosx") | {version, sdk}]',
        data="macho_amd64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [{"version": 658432, "sdk": 786688}]


def test_macho_fat_archive(tmp_path):
    """A fat Mach-O lists archs in fat_header and one decoded Mach-O per file slot."""
    # CATCHES: fat_header magic/narchs/offsets and per-arch nested macho headers
    res = run_fq("-V", "-c", "-d", "macho_fat", "keys", data="macho_fat", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "fat_header", "gap0", "files",
        "gap1", "gap2", "gap3", "gap4", "gap5", "gap6", "gap7", "gap8",
        "gap9", "gap10", "gap11", "gap12",
    ]
    res = run_fq(
        "-V", "-c", "-d", "macho_fat", ".fat_header", data="macho_fat", cwd=tmp_path
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": 3405691582,
        "narchs": 2,
        "archs": [
            {"cputype": "x86_64", "cpusubtype": 3, "offset": 16384,
             "size": 33088, "align": 14},
            {"cputype": "arm64", "cpusubtype": 0, "offset": 65536,
             "size": 50038, "align": 14},
        ],
    }
    res = run_fq(
        "-V", "-c", "-d", "macho_fat",
        "{n: (.files | length), cpus: [.files[].header.cputype], "
        "ncdms: [.files[].header.ncdms]}",
        data="macho_fat", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 2,
        "cpus": ["x86_64", "arm64"],
        "ncdms": [16, 18],
    }
    res = run_fq(
        "-V", "-c", "-d", "macho_fat", ".files[0] | keys",
        data="macho_fat", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["header", "load_commands"]
    res = run_fq(
        "-V", "-c", "-d", "macho_fat", ".files[0].header | {cputype, filetype, ncdms}",
        data="macho_fat", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "cputype": "x86_64", "filetype": "execute", "ncdms": 16,
    }


def test_macho_synthetic_command_zoo(tmp_path):
    """A synthetic 64-bit binary decodes uuid, rpath, build_version and friends."""
    # CATCHES: per-command field sets incl tools vector and cstring_literals type
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".header | {magic, cputype, cpusubtype, filetype, ncdms, sizeofncdms, "
        "flags: (.flags | {twolevel, dyldlink, noundefs})}",
        data="macho64_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": "64le", "cputype": "x86_64", "cpusubtype": 3,
        "filetype": "execute", "ncdms": 12, "sizeofncdms": 728,
        "flags": {"twolevel": True, "dyldlink": True, "noundefs": True},
    }
    res = run_fq(
        "-V", "-c", "-d", "macho", "[.load_commands[] | .cmd]",
        data="macho64_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "uuid", "segment_64", "twolevel_hints", "rpath", "build_version",
        "linker_option", "encryption_info_64", "version_min_watchos",
        "dyld_info", "sub_framework", "routines_64", "unixthread",
    ]
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[0]",
        data="macho64_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "cmd": "uuid", "cmdsize": 24,
        "uuid_command": {"uuid": "\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007"
                                 "\b\t\n\u000b\f\r\u000e\u000f"},
    }
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[2]",
        data="macho64_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "cmd": "twolevel_hints", "cmdsize": 16, "offset": 8192, "nhints": 42,
    }
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".load_commands[1].sections[0] | {sectname, offset, size, t: .flags.type, "
        "cstrings}",
        data="macho64_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "sectname": "__cstring", "offset": 760, "size": 13,
        "t": "cstring_literals", "cstrings": ["hello", "world", ""],
    }
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[1].sections[1] | {sectname, ustrings}",
        data="macho64_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"sectname": "__ustring", "ustrings": ["hi"]}
    res = run_fq(
        "-V", "-c", "-d", "macho",
        "[.load_commands[3:7][] | del(.cmdsize)]",
        data="macho64_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"cmd": "rpath", "offset": 12, "name": "@rpath/lib"},
        {"cmd": "build_version", "platform": 1, "minos": 720896, "sdk": 721664,
         "ntools": 2, "tools": [{"tool": 3, "version": 800},
                                {"tool": 4, "version": 528}]},
        {"cmd": "linker_option",
         "linker_option": {"count": 11, "option": "-framework"}},
        {"cmd": "encryption_info_64",
         "encryption_info": {"offset": 784, "size": 4, "id": 1, "data": "enc!"},
         "pad": 0},
    ]


def test_macho_synthetic_thread_and_misc_commands(tmp_path):
    """watchos version, dyld_info, sub_framework, routines_64 and a thread state."""
    # CATCHES: x86_64 unixthread register file decoded in order rax..gs
    res = run_fq(
        "-V", "-c", "-d", "macho",
        "[.load_commands[7:12][] | del(.cmdsize)]",
        data="macho64_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"cmd": "version_min_watchos", "version": 262144, "sdk": 327680},
        {"cmd": "dyld_info", "dyld_info": {
            "rebase_off": 0, "rebase_size": 0, "bind_off": 0, "bind_size": 0,
            "weak_bind_off": 0, "weak_bind_size": 0, "lazy_bind_off": 0,
            "lazy_bind_size": 0, "export_off": 0, "export_size": 0}},
        {"cmd": "sub_framework", "offset": 12, "name": "System"},
        {"cmd": "routines_64", "init_address": 4294971956, "init_module": 0,
         "reserved1": 0, "reserved2": 0, "reserved3": 0, "reserved4": 0,
         "reserved5": 0, "reserved6": 0},
        {"cmd": "unixthread", "flavor": 4, "count": 42, "state": {
            "rax": 1, "rbx": 2, "rcx": 3, "rdx": 4, "rdi": 5, "rsi": 6,
            "rbp": 7, "rsp": 8, "r8": 9, "r9": 10, "r10": 11, "r11": 12,
            "r12": 13, "r13": 14, "r14": 15, "r15": 16,
            "rip": 4294971200, "rflags": 512, "cs": 43, "fs": 0, "gs": 0}},
    ]


def test_macho_32bit_segment_and_fvmlib(tmp_path):
    """A 32-bit Mach-O decodes 32-bit segment fields and loadfvmlib/idfvmlib names."""
    # CATCHES: arch_bits 32, i386_all subtype, 32-bit vmaddr and section data
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".header | {magic, arch_bits, bits, cputype, cpusubtype, filetype, ncdms, "
        "sizeofncdms}",
        data="macho32_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": "32le", "arch_bits": 32, "bits": 32, "cputype": "x86",
        "cpusubtype": "i386_all", "filetype": "execute", "ncdms": 3,
        "sizeofncdms": 204,
    }
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[0] | {cmd, seg: .segment_command}",
        data="macho32_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "cmd": "segment",
        "seg": {"arch_bits": 32, "segname": "__TEXT", "vmaddr": 4096,
                "vmsize": 4096, "fileoff": 0, "tfilesize": 4096,
                "initprot": 5, "maxprot": 5, "nsects": 1,
                "flags": {"protected_version_1": False, "noreloc": False,
                          "fvmlib": False, "highvm": False,
                          "reserved0": "\u0000", "reserved1": "\u0000\u0000\u0000"}},
    }
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[0].sections[0]",
        data="macho32_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout)["data"] == "code"
    res = run_fq(
        "-V", "-c", "-d", "macho",
        "[.load_commands[1:3][] | {cmd, fvmlib}]",
        data="macho32_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"cmd": "loadfvmlib",
         "fvmlib": {"offset": 12, "minor_version": 256, "header_addr": 32768,
                    "name": "libfvmlib.dylib"}},
        {"cmd": "idfvmlib",
         "fvmlib": {"offset": 12, "minor_version": 256, "header_addr": 32768,
                    "name": "libfvmlib.dylib"}},
    ]


def test_macho_bigendian_magic_reports_64le(tmp_path):
    """A big-endian arm64 binary re-reads magic after the endian switch (\"64le\")."""
    # CATCHES: BE files decode via CIGAM magic but display MH_MAGIC_64 symbol "64le"
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".header | {magic, arch_bits, cputype, cpusubtype, filetype, ncdms, "
        "flags: (.flags | {twolevel, dyldlink, noundefs})}",
        data="macho64be_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": "64le", "arch_bits": 64, "cputype": "arm64", "cpusubtype": 0,
        "filetype": "execute", "ncdms": 3,
        "flags": {"twolevel": True, "dyldlink": True, "noundefs": True},
    }
    res = run_fq(
        "-V", "-c", "-d", "macho",
        "{bss: .load_commands[1].sections[0] | {sectname, t: .flags.type, keys: keys}, "
        "text: .load_commands[1].sections[1] | {sectname, data}}",
        data="macho64be_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    values = json.loads(res.stdout)
    assert values["bss"]["sectname"] == "__bss"
    assert values["bss"]["t"] == "zerofill"
    assert "data" not in values["bss"]["keys"]
    assert values["text"] == {"sectname": "__text", "data": "abcd"}
    res = run_fq(
        "-V", "-c", "-d", "macho", ".load_commands[2]",
        data="macho64be_synthetic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "cmd": "rpath", "cmdsize": 24, "offset": 12, "name": "@be_rpath",
    }


def test_macho_aarch64_build_version_and_linkedit_data(tmp_path):
    """A real arm64 executable carries build_version and three linkedit commands."""
    # CATCHES: platform 1 with one ld tool and code_signature/data_in_code offsets
    res = run_fq(
        "-V", "-c", "-d", "macho", "[.load_commands[] | .cmd]",
        data="macho_aarch64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "segment_64", "segment_64", "segment_64", "segment_64", "segment_64",
        "dyld_info_only", "symtab", "dysymtab", "load_dylinker", "uuid",
        "build_version", "source_version", "main", "load_dylib", "load_dylib",
        "function_starts", "data_in_code", "code_signature",
    ]
    res = run_fq(
        "-V", "-c", "-d", "macho",
        ".header | {cputype, cpusubtype, filetype}",
        data="macho_aarch64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "cputype": "arm64", "cpusubtype": 0, "filetype": "execute",
    }
    res = run_fq(
        "-V", "-c", "-d", "macho",
        '[.load_commands[] | select(.cmd == "build_version")]',
        data="macho_aarch64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [{
        "cmd": "build_version", "cmdsize": 32, "platform": 1, "minos": 720896,
        "sdk": 720896, "ntools": 1, "tools": [{"tool": 3, "version": 46596096}],
    }]
    res = run_fq(
        "-V", "-c", "-d", "macho",
        '[.load_commands[] | select(.cmd == "function_starts" or '
        '.cmd == "data_in_code" or .cmd == "code_signature")] '
        "| {fs: .[0].linkedit_data, dic: .[1].linkedit_data, cs: .[2].linkedit_data}",
        data="macho_aarch64", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "fs": {"off": 49272, "size": 8},
        "dic": {"off": 49280, "size": 0},
        "cs": {"off": 49504, "size": 534},
    }


def test_macho_dylib_id_dylib_and_dysymtab(tmp_path):
    """A shared library decodes filetype dylib, its id_dylib name and dysymtab."""
    # CATCHES: id_dylib install name libbbb.so and indirectsym table location
    res = run_fq(
        "-V", "-c", "-d", "macho",
        "{ft: .header.filetype, cmds: [.load_commands[] | .cmd]}",
        data="macho_dylib", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "ft": "dylib",
        "cmds": ["segment_64", "segment_64", "segment_64", "id_dylib",
                 "dyld_info_only", "symtab", "dysymtab", "uuid",
                 "version_min_macosx", "source_version", "load_dylib",
                 "function_starts", "data_in_code"],
    }
    res = run_fq(
        "-V", "-c", "-d", "macho",
        '[.load_commands[] | select(.cmd == "id_dylib") | .dylib_command]',
        data="macho_dylib", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [{
        "offset": 24, "timestamp": 1, "current_version": 0,
        "compatibility_version": 0, "name": "libbbb.so",
    }]
    res = run_fq(
        "-V", "-c", "-d", "macho",
        '[.load_commands[] | select(.cmd == "load_dylib") | .dylib_command.name]',
        data="macho_dylib", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["/usr/lib/libSystem.B.dylib"]
    res = run_fq(
        "-V", "-c", "-d", "macho",
        '[.load_commands[] | select(.cmd == "dysymtab") | del(.cmd, .cmdsize)]',
        data="macho_dylib", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [{
        "ilocalsym": 0, "nlocalsym": 0, "iextdefsym": 0, "nextdefsym": 1,
        "iundefsym": 1, "nundefsym": 2, "tocoff": 0, "ntoc": 0, "modtaboff": 0,
        "nmodtab": 0, "extrefsymoff": 0, "nextrefsyms": 0,
        "indirectsymoff": 32896, "nindirectsyms": 4, "extreloff": 0,
        "nextrel": 0, "locreloff": 0, "nlocrel": 0,
    }]
