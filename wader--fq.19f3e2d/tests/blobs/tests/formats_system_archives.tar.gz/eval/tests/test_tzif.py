"""TZif decoder: v1/v2 headers, transition tables, leap seconds and TZ footer."""

import json

from conftest import run_fq


def test_tzif_v1_simple_zone(tmp_path):
    """A v2 TZif with one transition decodes the v1 block and GMT0 footer string."""
    # CATCHES: magic 1415211366, ver "2", LMT/GMT designations and tz_string "GMT0"
    res = run_fq("-V", "-c", "-d", "tzif", "keys", data="tzif_Abidjan", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "v1header", "v1datablock", "v2plusheader", "v2plusdatablock", "footer",
    ]
    res = run_fq(
        "-V", "-c", "-d", "tzif", ".v1header", data="tzif_Abidjan", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "magic": 1415211366,
        "ver": "2",
        "isutcnt": 0,
        "isstdcnt": 0,
        "leapcnt": 0,
        "timecnt": 1,
        "typecnt": 2,
        "charcnt": 8,
        "reserved": "\u0000" * 15,
    }
    res = run_fq(
        "-V", "-c", "-d", "tzif",
        ".v1datablock | {tt: .transition_times, tty: .transition_types, "
        "lttr: .local_time_type_records, tzd: .time_zone_designations, "
        "leap: .leap_second_records}",
        data="tzif_Abidjan", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "tt": ["1912-01-01T00:16:08Z"],
        "tty": [1],
        "lttr": [
            {"dst": 0, "idx": 0, "utoff": -968},
            {"dst": 0, "idx": 4, "utoff": 0},
        ],
        "tzd": ["LMT", "GMT"],
        "leap": [],
    }
    res = run_fq(
        "-V", "-c", "-d", "tzif", ".footer", data="tzif_Abidjan", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"nl1": 10, "nl2": 10, "tz_string": "GMT0"}


def test_tzif_v1_block_of_zone_with_leap_seconds(tmp_path):
    """Adak's v1 block holds 116 transitions, 27 leap seconds and 9 type records."""
    # CATCHES: leapcnt 27 in the header and corr/occur pairs in the leap records
    res = run_fq(
        "-V", "-c", "-d", "tzif", ".v1header | {charcnt, leapcnt, timecnt, typecnt, ver}",
        data="tzif_Adak", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "charcnt": 33, "leapcnt": 27, "timecnt": 116, "typecnt": 9, "ver": "2",
    }
    res = run_fq(
        "-V", "-c", "-d", "tzif",
        "{v1n: (.v1datablock.transition_times | length), "
        "first: .v1datablock.transition_times[0], "
        "last: .v1datablock.transition_times[-1]}",
        data="tzif_Adak", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v1n": 116,
        "first": "1901-12-13T20:45:52Z",
        "last": "2023-06-28T00:00:27Z",
    }
    res = run_fq(
        "-V", "-c", "-d", "tzif", ".v1datablock.leap_second_records[0:3]",
        data="tzif_Adak", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"occur": "1972-07-01T00:00:00Z", "corr": 1},
        {"occur": "1973-01-01T00:00:01Z", "corr": 2},
        {"occur": "1974-01-01T00:00:02Z", "corr": 3},
    ]
    res = run_fq(
        "-V", "-c", "-d", "tzif", ".footer", data="tzif_Adak", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"nl1": 10, "nl2": 10, "tz_string": ""}


def test_tzif_v2_block_extends_history(tmp_path):
    """The v2+ block uses 64-bit times back to 1867 with wall/UT indicators."""
    # CATCHES: 117 v2 transitions, 1867 start, dst/idx/utoff records and indicators
    res = run_fq(
        "-V", "-c", "-d", "tzif",
        "{v2n: (.v2plusdatablock.transition_times | length), "
        "first3: .v2plusdatablock.transition_times[0:3], "
        "leapn: (.v2plusdatablock.leap_second_records | length), "
        "swi: .v2plusdatablock.standard_wall_indicators[0:10]}",
        data="tzif_Adak", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "v2n": 117,
        "first3": [
            "1867-10-19T00:31:13Z",
            "1900-08-20T23:46:38Z",
            "1942-02-09T13:00:00Z",
        ],
        "leapn": 27,
        "swi": [0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
    }
    res = run_fq(
        "-V", "-c", "-d", "tzif",
        "[.v2plusdatablock.local_time_type_records[] | {dst, idx, utoff}]",
        data="tzif_Adak", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"dst": 0, "idx": 0, "utoff": 44002},
        {"dst": 0, "idx": 0, "utoff": -42398},
        {"dst": 0, "idx": 4, "utoff": -39600},
        {"dst": 1, "idx": 8, "utoff": -36000},
        {"dst": 1, "idx": 12, "utoff": -36000},
        {"dst": 0, "idx": 16, "utoff": -39600},
        {"dst": 1, "idx": 20, "utoff": -36000},
        {"dst": 0, "idx": 24, "utoff": -36000},
        {"dst": 1, "idx": 29, "utoff": -32400},
        {"dst": 0, "idx": 25, "utoff": -36000},
    ]
    res = run_fq(
        "-V", "-c", "-d", "tzif", ".v2plusdatablock.time_zone_designations",
        data="tzif_Adak", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["LMT", "NST", "NWT", "NPT", "BST", "BDT", "AHST", "HDT"]
