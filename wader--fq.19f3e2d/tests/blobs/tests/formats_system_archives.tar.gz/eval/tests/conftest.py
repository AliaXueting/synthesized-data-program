"""Shared helpers for the formats_system_archives black-box test suite.

Every test drives the candidate binary through PROGRAMGYM_EXECUTABLE (the
only source of truth) with a fully pinned child environment so that recorded
stdout/stderr bytes are hermetic and reproducible.
"""

import os
import shutil
import subprocess
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"

# Pinned, hermetic environment for the child process: no user config, no
# locale/timezone variance, no TTY. The binary is always invoked by absolute
# path so PATH contents cannot change what is executed.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent-home",
    "LANG": "C",
    "LC_ALL": "C",
    "TZ": "UTC",
    "TERM": "dumb",
}


def child_env():
    """Return the pinned child env, forwarding GOCOVERDIR when the pipeline sets it."""
    env = dict(CHILD_ENV)
    # Coverage instrumentation hook: the pipeline measures source coverage of
    # the reference binary through GOCOVERDIR in the child process env.
    cov_env = [{"GOCOVERDIR": v} for v in [os.environ.get("GOCOVERDIR")] if v]
    for extra in cov_env:
        env.update(extra)
    return env


def data_path(name):
    """Absolute path of a staged fixture inside eval/tests/data."""
    path = DATA_DIR / name
    assert path.is_file(), f"missing test fixture: {name}"
    return path


def stage_data(name, tmp_path):
    """Copy fixture `name` into tmp_path and return its bare filename.

    Tests always run the binary with cwd=tmp_path and a bare filename so the
    display output (which echoes the filename) stays hermetic.
    """
    dst = tmp_path / name
    if not dst.exists():
        shutil.copy(data_path(name), dst)
    return name


def run_fq(*args, data=None, cwd=None, stdin=None, timeout=30):
    """Run the candidate fq binary and return a CompletedProcess (byte output).

    `data` names a fixture that is copied into `cwd` before the run; anything
    else passed as the trailing argument is used verbatim (useful for names of
    files that should *not* exist).
    """
    exe = os.environ.get("PROGRAMGYM_EXECUTABLE")
    assert exe, "PROGRAMGYM_EXECUTABLE must be set (see eval/run.sh)"
    cmd = [exe] + [str(a) for a in args]
    if data is not None:
        cmd.append(stage_data(data, cwd))
    return subprocess.run(
        cmd,
        cwd=str(cwd),
        input=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=child_env(),
        timeout=timeout,
    )
