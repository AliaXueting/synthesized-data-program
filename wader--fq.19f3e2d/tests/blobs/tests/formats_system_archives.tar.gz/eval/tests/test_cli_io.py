"""CLI-level I/O behavior: exit codes, stderr text, stdin input, help output."""

import json

import pytest

from conftest import run_fq, stage_data


@pytest.mark.parametrize(
    "staged,args,code,err",
    [
        (
            [],
            ("-V", "-c", "-d", "elf", ".", "missing_input.elf"),
            2,
            b"error: missing_input.elf: no such file or directory\n",
        ),
        (
            ["gzip_test.gz"],
            ("-V", "-c", "-d", "nosuchfmt", ".", "gzip_test.gz"),
            4,
            b"error: gzip_test.gz: nosuchfmt: format group not found\n",
        ),
        (
            ["tar_test.tar"],
            ("-V", "-c", "-d", "tar", ".entries[]", "tar_test.tar"),
            5,
            b"error: tar_test.tar: cannot iterate over: null\n",
        ),
    ],
)
def test_error_exit_codes_and_stderr(staged, args, code, err, tmp_path):
    """Missing file, unknown format and query runtime error use distinct exit codes."""
    # CATCHES: exit codes 2/4/5 plus exact one-line stderr bytes for each error path
    for name in staged:
        stage_data(name, tmp_path)
    res = run_fq(*args, cwd=tmp_path)
    assert res.returncode == code
    assert res.stdout == b""
    assert res.stderr == err


def test_success_writes_stdout_only(tmp_path):
    """A successful decode prints JSON to stdout and leaves stderr empty."""
    # CATCHES: stdout/stderr separation on the happy path (stderr must stay empty)
    res = run_fq(
        "-V", "-c", "-d", "gzip", ".uncompressed", data="gzip_test.gz", cwd=tmp_path
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert json.loads(res.stdout) == "test\n"


def test_stdin_input_header_fields_null_but_stream_decoded(tmp_path):
    """gzip fed on stdin decodes the stream but header scalar fields read back null."""
    # CATCHES: stdin input path returns null for .identification/.compression_method
    #          while .uncompressed is still the inflated "test\n" content
    name = stage_data("gzip_test.gz", tmp_path)
    raw = (tmp_path / name).read_bytes()
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "gzip",
        "{id: .identification, cm: .compression_method, os: .os, unc: .uncompressed}",
        cwd=tmp_path,
        stdin=raw,
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert json.loads(res.stdout) == {
        "id": None,
        "cm": None,
        "os": None,
        "unc": "test\n",
    }


def test_formats_help_lists_module_decoders(tmp_path):
    """-h formats exits 0 and lists this module's decoders with descriptions."""
    # CATCHES: help registry names and long descriptions for mosaic/macho_fat/caff
    res = run_fq("-h", "formats", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert b"MOdular Storage of Archived and Indexed Contents" in res.stdout
    assert b"Fat Mach-O macOS executable (multi-architecture)" in res.stdout
    assert b"Apple BookmarkData" in res.stdout
    assert b"Garmin Flexible and Interoperable Data Transfer" in res.stdout


def test_missing_file_name_echoed_verbatim(tmp_path):
    """The stderr error message repeats the input path exactly as given on argv."""
    # CATCHES: error text embeds the argv filename verbatim with no path rewriting
    res = run_fq("-d", "elf", ".", "no/such/dir/zz.bin", cwd=tmp_path)
    assert res.returncode == 2
    assert res.stderr == b"error: no/such/dir/zz.bin: no such file or directory\n"
    assert res.stdout == b""
