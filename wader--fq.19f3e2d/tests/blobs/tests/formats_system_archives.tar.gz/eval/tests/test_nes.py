"""NES cartridge decoder: iNES/NES 2.0 headers, disassembly and CHR rendering."""

import json

import pytest

from conftest import run_fq


def test_nes_nestest_header(tmp_path):
    """The nestest iNES header decodes every field including symbolic enums."""
    # CATCHES: identifier NES\\x1a, vertical nametable layout, sizes in bytes
    res = run_fq("-V", "-c", "-d", "nes", ".header", data="nes_nestest.nes", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "identifier": "NES\u001a",
        "prg_rom_size": 16384,
        "chr_rom_size": 8192,
        "prg_ram_size": 8192,
        "chr_ram_size": 0,
        "mapper": 0,
        "mapper0": 0,
        "mapper1": 0,
        "console_type": "nes",
        "nes20_identifier": "no",
        "nametable_layout": "vertical",
        "alternative_nametables": "no",
        "battery": "no",
        "trainer": "no",
        "byte_9": 0,
        "byte_10": 0,
        "unused": "\u0000\u0000\u0000\u0000\u0000",
    }


@pytest.mark.parametrize(
    "data,expected",
    [
        (
            "nes_nes20_34_1.nes",
            {"mapper": 34, "nes20_identifier": "yes", "prg_rom_size": 65536,
             "chr_rom_size": 65536, "chr_ram_size": 0},
        ),
        (
            "nes_nes20_4_0.nes",
            {"mapper": 4, "nes20_identifier": "yes", "prg_rom_size": 65536,
             "chr_rom_size": 0, "chr_ram_size": 32768},
        ),
        (
            "nes_ines_31.nes",
            {"mapper": 31, "nes20_identifier": "no", "prg_rom_size": 16384,
             "chr_rom_size": 8192, "chr_ram_size": 0},
        ),
    ],
)
def test_nes_cartridge_header_variants(data, expected, tmp_path):
    """NES 2.0 and high-mapper iNES cartridges decode mapper and ROM sizes."""
    # CATCHES: NES 2.0 detection, mapper numbers 34/4/31 and chr_ram vs chr_rom split
    res = run_fq(
        "-V", "-c", "-d", "nes",
        ".header | {mapper, nes20_identifier, prg_rom_size, chr_rom_size, chr_ram_size}",
        data=data, cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == expected


def test_nes_prg_disassembly_with_toasm(tmp_path):
    """nes_toasm renders the first PRG instructions as assembly text via -r."""
    # CATCHES: opcode mnemonic, $-prefixed hex args and the trailing spaces on rts/sei
    res = run_fq(
        "-V", "-c", "-d", "nes", ".prg_rom[0:3]",
        data="nes_nestest.nes", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"op_code": "jmp", "args": "$c5f5"},
        {"op_code": "rts"},
        {"op_code": "sei"},
    ]
    res = run_fq(
        "-r", "-c", "-d", "nes", ".prg_rom[0:3] | map(nes_toasm)",
        data="nes_nestest.nes", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stderr == b""
    assert res.stdout == b'["jmp $c5f5","rts ","sei "]\n'
    res = run_fq(
        "-V", "-c", "-d", "nes", "{prg: (.prg_rom | length), chr: (.chr_rom | length)}",
        data="nes_nestest.nes", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"prg": 8463, "chr": 512}


def test_nes_chr_tile_kitty_rendering(tmp_path):
    """nes_tokitty(5) renders the first CHR tile as an exact 293-byte kitty packet."""
    # CATCHES: kitty graphics header params (c=10,r=5), base64 body and \\e\\\\\\n terminator
    res = run_fq(
        "-r", "-d", "nes", ".chr_rom[0] | nes_tokitty(5)",
        data="nes_nestest.nes", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stderr == b""
    expected = (
        b"\\e_Ga=T,f=24,s=8,v=8,c=10,r=5;"
        + b"Ii" * 128
        + b"\\e" + b"\\\\" + b"\\n" + b"\n"
    )
    assert res.stdout == expected
    assert len(res.stdout) == 293


def test_nes_invalid_header_graceful(tmp_path):
    """A 4-byte non-iNES file yields a null header and an inline decode error."""
    # CATCHES: bad magic gives .header null with exit 0 and BitBufRange display error
    (tmp_path / "bad.nes").write_bytes(b"XXXX")
    res = run_fq("-V", "-c", "-d", "nes", ".header", "bad.nes", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) is None
    res = run_fq("-d", "nes", ".", "bad.nes", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (
        b"error: nes: BitBufRange: failed at position 0 "
        b"(read size 16 seek pos 0): outside buffer" in res.stdout
    )


def test_nes_root_keys(tmp_path):
    """The nes value root is exactly header, prg_rom and chr_rom."""
    # CATCHES: root field names - prg_rom/chr_rom arrays, no separate trainer field
    res = run_fq("-V", "-c", "-d", "nes", "keys", data="nes_nestest.nes", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["header", "prg_rom", "chr_rom"]
