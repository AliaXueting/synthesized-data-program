"""LevelDB decoders: MANIFEST descriptor records, write-ahead log and SSTables."""

import json

from conftest import run_fq


def test_leveldb_descriptor_manifest_records(tmp_path):
    """The MANIFEST descriptor decodes version-edit tags with checksummed headers."""
    # CATCHES: comparator tag string value and the log/next_file/last_sequence ints
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor", "keys",
        data="leveldb_manifest", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["blocks"]
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor", ".blocks[0].records[0]",
        data="leveldb_manifest", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "data": {"tags": [{"key": "comparator",
                           "value": {"data": "leveldb.BytewiseComparator", "length": 26}}]},
        "header": {"checksum": 4172872022, "length": 28, "record_type": "full"},
    }
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor", ".blocks[0].records[1]",
        data="leveldb_manifest", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "data": {"tags": [
            {"key": "log_number", "value": 3},
            {"key": "previous_log_number", "value": 0},
            {"key": "next_file_number", "value": 4},
            {"key": "last_sequence", "value": 0},
        ]},
        "header": {"checksum": 3196820644, "length": 8, "record_type": "full"},
    }


def test_leveldb_log_write_batches(tmp_path):
    """The write-ahead log decodes four full records with sequence numbers 1..4."""
    # CATCHES: record_type/length pairs 472,472,472,136 and batch count/sequence
    res = run_fq("-V", "-c", "-d", "leveldb_log", "keys", data="leveldb_log.log", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["blocks"]
    res = run_fq(
        "-V", "-c", "-d", "leveldb_log", ".blocks | length",
        data="leveldb_log.log", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 1
    res = run_fq(
        "-V", "-c", "-d", "leveldb_log",
        "[.blocks[0].records[] | {rt: .header.record_type, len: .header.length, "
        "n: .data.count, seq: .data.sequence}]",
        data="leveldb_log.log", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"rt": "full", "len": 472, "n": 1, "seq": 1},
        {"rt": "full", "len": 472, "n": 1, "seq": 2},
        {"rt": "full", "len": 472, "n": 1, "seq": 3},
        {"rt": "full", "len": 136, "n": 1, "seq": 4},
    ]
    res = run_fq(
        "-V", "-c", "-d", "leveldb_log",
        ".blocks[0].records[0].data.records[0] | {key: .key.data, type, v: .value.data[0:27]}",
        data="leveldb_log.log", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "key": "lorem.lorem", "type": "value", "v": "Lorem ipsum dolor sit amet,",
    }


def test_leveldb_table_footer_and_index(tmp_path):
    """An SSTable footer points at the index/metaindex blocks with the fixed magic."""
    # CATCHES: handles offset/size pairs, magic 15800726617472432983 and padding nulls
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table", "keys",
        data="leveldb_uncompressed.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["data", "metaindex", "index", "footer"]
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table",
        ".footer | {index_handle, metaindex_handle, magic_number, npad: (.padding | length)}",
        data="leveldb_uncompressed.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "index_handle": {"offset": 1550, "size": 23},
        "metaindex_handle": {"offset": 1537, "size": 8},
        "magic_number": 15800726617472432983,
        "npad": 34,
    }
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table", ".index.uncompressed.entries[0]",
        data="leveldb_uncompressed.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "key": {"sequence_number": 72057594037927935, "type": "value", "user_key": "s"},
        "shared_bytes": 0,
        "unshared_bytes": 9,
        "value": {"offset": 0, "size": 1532},
        "value_length": 3,
    }
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table", ".metaindex.uncompressed.entries | length",
        data="leveldb_uncompressed.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 0


def test_leveldb_descriptor_new_file_tag(tmp_path):
    """A real MANIFEST's second record carries a new_file tag with internal keys."""
    # CATCHES: level/file_number/file_size plus smallest/largest key seq+type pairs
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor",
        "[.blocks[0].records[] | {rt: .header.record_type, len: .header.length}]",
        data="leveldb_manifest_full", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"rt": "full", "len": 28}, {"rt": "full", "len": 45},
    ]
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor",
        "[.blocks[0].records[1].data.tags[] | {key, value}]",
        data="leveldb_manifest_full", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"key": "log_number", "value": 6},
        {"key": "previous_log_number", "value": 0},
        {"key": "next_file_number", "value": 7},
        {"key": "last_sequence", "value": 4},
        {"key": "new_file", "value": {
            "level": 0, "file_number": 5, "file_size": 1626,
            "smallest_internal_key": {
                "length": 19,
                "data": {"user_key": "lorem.dolor", "type": "value",
                         "sequence_number": 3}},
            "largest_internal_key": {
                "length": 11,
                "data": {"user_key": "row", "type": "value",
                         "sequence_number": 4}},
        }},
    ]


def test_leveldb_descriptor_compact_pointer_and_deleted_file(tmp_path):
    """compact_pointer and deleted_file tags decode with level-scoped payloads."""
    # CATCHES: compact_pointer nests an internal key; deleted_file is level+number
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor",
        "[.blocks[0].records[1].data.tags[] | {key, value}]",
        data="leveldb_manifest_tags", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"key": "log_number", "value": 8},
        {"key": "compact_pointer", "value": {
            "level": 2,
            "internal_key": {
                "length": 13,
                "data": {"user_key": "cpkey", "type": "value",
                         "sequence_number": 42}}}},
        {"key": "deleted_file", "value": {"level": 1, "file_number": 7}},
        {"key": "new_file", "value": {
            "level": 0, "file_number": 9, "file_size": 1234,
            "smallest_internal_key": {
                "length": 12,
                "data": {"user_key": "aaaa", "type": "deletion",
                         "sequence_number": 1}},
            "largest_internal_key": {
                "length": 12,
                "data": {"user_key": "zzzz", "type": "value",
                         "sequence_number": 2}}}},
    ]


def test_leveldb_descriptor_fragmented_records_stay_raw(tmp_path):
    """first/last record fragments keep raw data instead of decoding VersionEdits."""
    # CATCHES: only record_type full gets a decoded tags struct; fragments are bytes
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor",
        "[.blocks[0].records[2:4][] | {keys: keys, rt: .header.record_type, "
        "len: .header.length, d: .data}]",
        data="leveldb_manifest_tags", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"keys": ["header", "data"], "rt": "first", "len": 2, "d": "\u07ad"},
        {"keys": ["header", "data"], "rt": "last", "len": 3, "d": "\ufffd\ufffd\ufffd"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor",
        ".blocks[0].records[2].header.checksum",
        data="leveldb_manifest_tags", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 1382868508


def test_leveldb_descriptor_torepr_function(tmp_path):
    """The torepr builtin renders records as nested lists of tag-name objects."""
    # CATCHES: comparator collapses to its string, new_file keeps internal keys
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor", "torepr",
        data="leveldb_manifest_full", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        [{"comparator": "leveldb.BytewiseComparator"}],
        [{"log_number": 6}, {"previous_log_number": 0}, {"next_file_number": 7},
         {"last_sequence": 4},
         {"new_file": {
             "level": 0, "file_number": 5, "file_size": 1626,
             "smallest_internal_key": {"user_key": "lorem.dolor", "type": "value",
                                       "sequence_number": 3},
             "largest_internal_key": {"user_key": "row", "type": "value",
                                      "sequence_number": 4}}}],
    ]
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor", "torepr",
        data="leveldb_manifest_tags", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        [{"comparator": "leveldb.BytewiseComparator"}],
        [{"log_number": 8},
         {"compact_pointer": {"level": 2,
                              "internal_key": {"user_key": "cpkey", "type": "value",
                                               "sequence_number": 42}}},
         {"deleted_file": {"level": 1, "file_number": 7}},
         {"new_file": {
             "level": 0, "file_number": 9, "file_size": 1234,
             "smallest_internal_key": {"user_key": "aaaa", "type": "deletion",
                                       "sequence_number": 1},
             "largest_internal_key": {"user_key": "zzzz", "type": "value",
                                      "sequence_number": 2}}}],
    ]


def test_leveldb_descriptor_unknown_tag_error(tmp_path):
    """An unknown VersionEdit tag aborts the record, leaving gap0 and an error note."""
    # CATCHES: unknown tag 99 keeps the raw key, the ULEB value byte becomes gap0
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor", "keys",
        data="leveldb_manifest_badtag", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["blocks", "gap0"]
    res = run_fq(
        "-V", "-c", "-d", "leveldb_descriptor", ".blocks[0].records[0].data",
        data="leveldb_manifest_badtag", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "tags": [
            {"key": "comparator",
             "value": {"data": "leveldb.BytewiseComparator", "length": 26}},
            {"key": 99},
        ],
    }
    res = run_fq(
        "-d", "leveldb_descriptor", ".",
        data="leveldb_manifest_badtag", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert b"error: leveldb_descriptor: error at position 0x24: unknown tag: 99" in res.stdout


def test_leveldb_table_data_block_variants(tmp_path):
    """Data blocks report compression, entry counts, restart arrays and payloads."""
    # CATCHES: none vs snappy compression, prefix-compressed keys and restart points
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table",
        "{n: (.data | length), comp: [.data[] | .compression], "
        "e: [.data[].uncompressed.entries | length], "
        "t: .data[0].uncompressed.trailer}",
        data="leveldb_uncompressed.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 1, "comp": ["none"], "e": [4],
        "t": {"num_restarts": 1, "restarts": [0]},
    }
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table",
        ".data[0].uncompressed.entries[0] | {k: .key, sb: .shared_bytes, ub: .unshared_bytes, "
        "vl: .value_length}",
        data="leveldb_uncompressed.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "k": {"sequence_number": 3, "type": "value", "user_key": "lorem.dolor"},
        "sb": 0,
        "ub": 19,
        "vl": 445,
    }
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table",
        "{n: (.data | length), comp: [.data[] | .compression], "
        "e: [.data[].uncompressed.entries | length]}",
        data="leveldb_snappy.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"n": 1, "comp": ["snappy"], "e": [4]}
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table",
        "{n: (.data | length), comp: [.data[] | .compression], "
        "e: [.data[].uncompressed.entries | length]}",
        data="leveldb_repeats.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 3, "comp": ["snappy", "snappy", "snappy"], "e": [254, 253, 5],
    }
    res = run_fq(
        "-V", "-c", "-d", "leveldb_table", "[.data[].uncompressed.trailer.restarts]",
        data="leveldb_repeats.ldb", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        [0, 254, 508, 762, 1016, 1270, 1524, 1778, 2032, 2286, 2540, 2794,
         3048, 3302, 3556, 3810],
        [0, 255, 510, 765, 1020, 1275, 1530, 1785, 2040, 2296, 2551, 2806,
         3061, 3316, 3571, 3826],
        [0],
    ]
