"""WebAssembly decoder: section table, exports, code bodies, globals, imports."""

import json

import pytest

from conftest import data_path, run_fq


def test_wasm_magic_version_and_fac_sections(tmp_path):
    """wasm root exposes magic/version and the fac module's four section sizes."""
    # CATCHES: magic "\\x00asm", version 1 and per-section id/size pairs
    res = run_fq(
        "-V", "-c", "-d", "wasm", "{magic, version, n: (.sections | length)}",
        data="wasm_fac.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"magic": "\u0000asm", "version": 1, "n": 4}
    res = run_fq(
        "-V", "-c", "-d", "wasm", "[.sections[] | {id, size}]",
        data="wasm_fac.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"id": "type_section", "size": 26},
        {"id": "function_section", "size": 9},
        {"id": "export_section", "size": 75},
        {"id": "code_section", "size": 235},
    ]


def test_wasm_fac_export_section(tmp_path):
    """The export section lists all six fac exports with name, kind tag and index."""
    # CATCHES: export names, "funcidx" kind tag and function indices incl gap at 7
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.sections[2].content.ex.x[] | {nm: .nm.b, tag: .d.tag, idx: .d.x}]',
        data="wasm_fac.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"nm": "fac-rec", "tag": "funcidx", "idx": 0},
        {"nm": "fac-rec-named", "tag": "funcidx", "idx": 1},
        {"nm": "fac-iter", "tag": "funcidx", "idx": 2},
        {"nm": "fac-iter-named", "tag": "funcidx", "idx": 3},
        {"nm": "fac-opt", "tag": "funcidx", "idx": 4},
        {"nm": "fac-ssa", "tag": "funcidx", "idx": 7},
    ]


def test_wasm_fac_code_section(tmp_path):
    """Code bodies report byte sizes and disassemble to symbolic opcodes."""
    # CATCHES: per-body size list and first instructions local.get/i64.const/i64.eq
    res = run_fq(
        "-V", "-c", "-d", "wasm", "[.sections[3].content.code.x[] | .size]",
        data="wasm_fac.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [23, 23, 47, 47, 44, 6, 8, 28]
    res = run_fq(
        "-V", "-c", "-d", "wasm", ".sections[3].content.code.x[0].code.e[0:3]",
        data="wasm_fac.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"opcode": "local.get", "x": 0},
        {"n": 0, "opcode": "i64.const"},
        {"opcode": "i64.eq"},
    ]


def test_wasm_start_section_function_index(tmp_path):
    """A module with a start section resolves the start function index to 2."""
    # CATCHES: section id order incl start_section and .content.st.x index value
    res = run_fq(
        "-V", "-c", "-d", "wasm", "[.sections[] | .id]",
        data="wasm_start.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "type_section", "function_section", "memory_section", "export_section",
        "start_section", "code_section", "data_section",
    ]
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '.sections[] | select(.id == "start_section") | .content.st.x',
        data="wasm_start.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 2


def test_wasm_global_section_init_exprs(tmp_path):
    """Global section decodes types, mutability and const init expressions."""
    # CATCHES: gt.m const/var, gt.t i32/f32/i64 and init opcodes with immediates
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.sections[] | select(.id == "global_section") | .content]',
        data="wasm_imports.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {
            "glob": {
                "n": 3,
                "x": [
                    {
                        "gt": {"m": "const", "t": "i32"},
                        "e": [{"n": 55, "opcode": "i32.const"}, {"opcode": "end"}],
                    },
                    {
                        "gt": {"m": "const", "t": "f32"},
                        "e": [{"opcode": "f32.const", "z": 44}, {"opcode": "end"}],
                    },
                    {
                        "gt": {"m": "var", "t": "i64"},
                        "e": [{"n": 66, "opcode": "i64.const"}, {"opcode": "end"}],
                    },
                ],
            }
        }
    ]


def test_wasm_import_section_entries(tmp_path):
    """An import section decodes module/name strings and the kind descriptor."""
    # CATCHES: mod.b/nm.b strings, d.tag "func" and function type index 0
    res = run_fq(
        "-V", "-c", "-d", "wasm", "[.sections[] | {id, size}]",
        data="binary-leb128-10.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"id": "type_section", "size": 5},
        {"id": "import_section", "size": 22},
    ]
    res = run_fq(
        "-V", "-c", "-d", "wasm", ".sections[1].content.im.x",
        data="binary-leb128-10.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {
            "mod": {"b": "spectest", "n": 8},
            "nm": {"b": "print_i32", "n": 9},
            "d": {"tag": "func", "x": 0},
        }
    ]


def test_wasm_element_section_left_null(tmp_path):
    """A table+element module lists the element section but leaves its content null."""
    # CATCHES: element_section id is present yet .content decodes to null
    res = run_fq(
        "-V", "-c", "-d", "wasm", "[.sections[] | .id]",
        data="wasm_elem.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "type_section", "function_section", "table_section",
        "element_section", "code_section",
    ]
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '.sections[] | select(.id == "element_section") | .content',
        data="wasm_elem.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) is None


def test_wasm_nested_block_loop_if_with_else(tmp_path):
    """fac-rec nests block>loop>if with an else clause and label-relative branches."""
    # CATCHES: bt "ε" vs typeidx, in1/in2 else split, br label depth 2 and end bytes
    res = run_fq(
        "-V", "-c", "-d", "wasm", ".sections[3].content.code.x[2].code",
        data="wasm_fac.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "e": [
            {"opcode": "local.get", "x": 0},
            {"opcode": "local.set", "x": 1},
            {"n": 1, "opcode": "i64.const"},
            {"opcode": "local.set", "x": 2},
            {
                "bt": "ε", "end": 11,
                "instructions": [
                    {
                        "bt": "ε", "end": 11,
                        "instructions": [
                            {"opcode": "local.get", "x": 1},
                            {"n": 0, "opcode": "i64.const"},
                            {"opcode": "i64.eq"},
                            {
                                "bt": "ε", "else": 5, "end": 11,
                                "in1": [{"l": 2, "opcode": "br"}],
                                "in2": [
                                    {"opcode": "local.get", "x": 1},
                                    {"opcode": "local.get", "x": 2},
                                    {"opcode": "i64.mul"},
                                    {"opcode": "local.set", "x": 2},
                                    {"opcode": "local.get", "x": 1},
                                    {"n": 1, "opcode": "i64.const"},
                                    {"opcode": "i64.sub"},
                                    {"opcode": "local.set", "x": 1},
                                ],
                                "opcode": "if",
                            },
                            {"l": 0, "opcode": "br"},
                        ],
                        "opcode": "loop",
                    },
                ],
                "opcode": "block",
            },
            {"opcode": "local.get", "x": 2},
            {"opcode": "end"},
        ],
        "t": {"n": 1, "x": [{"n": 2, "t": "i64"}]},
    }


def test_wasm_fac_ssa_loop_calls_and_br_if(tmp_path):
    """fac-ssa uses a typed loop block (bt typeidx 3) with calls and br_if/drop."""
    # CATCHES: numeric bt 3, call x5/x6 immediates, br_if l0, drop, return
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '.sections[3].content.code.x[7].code.e[2] | {bt, end, opcode, '
        'ops: [.instructions[] | .opcode]}',
        data="wasm_fac.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "bt": 3,
        "end": 11,
        "opcode": "loop",
        "ops": [
            "call", "call", "i64.mul", "call", "i64.const", "i64.sub", "call",
            "i64.const", "i64.gt_u", "br_if", "drop", "return",
        ],
    }
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '.sections[3].content.code.x[7].code.e[2].instructions[9]',
        data="wasm_fac.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"l": 0, "opcode": "br_if"}


@pytest.mark.parametrize(
    "data,expected",
    [
        (
            "wasm_memory_copy.wasm",
            [{"opcode": "prefix", "p_opcode": "memory.copy",
              "reserved1": 0, "reserved2": 0}],
        ),
        (
            "wasm_memory_fill.wasm",
            [{"opcode": "prefix", "p_opcode": "memory.fill", "reserved": 0}],
        ),
        (
            "wasm_memory_init.wasm",
            [{"opcode": "prefix", "p_opcode": "data.drop", "x": 0}] * 2,
        ),
        (
            "wasm_table_copy.wasm",
            [{"opcode": "prefix", "p_opcode": "table.copy", "x": 0, "y": 0}],
        ),
    ],
)
def test_wasm_prefixed_bulk_memory_and_table_instructions(data, expected, tmp_path):
    """0xfc-prefixed instructions decode to symbolic names with their immediates."""
    # CATCHES: p_opcode symbols, memory.copy reserved1/reserved2, data.drop x index
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.. | objects | select(.opcode? == "prefix")]',
        data=data, cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == expected


def test_wasm_call_indirect_and_select_instructions(tmp_path):
    """call_indirect carries typeidx x and table y; select decodes with no immediates."""
    # CATCHES: three call_indirect type indices 0/1/2 with table 0, plain select shape
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.. | objects | select(.opcode? == "call_indirect")]',
        data="wasm_call_indirect.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"opcode": "call_indirect", "x": 0, "y": 0},
        {"opcode": "call_indirect", "x": 1, "y": 0},
        {"opcode": "call_indirect", "x": 2, "y": 0},
    ]
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.. | objects | select(.opcode? == "select")] | {n: length, first: .[0:3]}',
        data="wasm_select.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 47,
        "first": [{"opcode": "select"}, {"opcode": "select"}, {"opcode": "select"}],
    }


def test_wasm_br_table_label_vectors(tmp_path):
    """br_table decodes a label vector l and default label lN, incl a 24615-entry one."""
    # CATCHES: l {n,x} vector, lN default depth 4 and the 24615-label oversized vector
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.. | objects | select(.opcode? == "br_table")] '
        "| {n: length, maxlen: ([.[].l.n] | max), lNmax: ([.[].lN] | max)}",
        data="wasm_br_table.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"n": 74, "maxlen": 24615, "lNmax": 4}
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.. | objects | select(.opcode? == "br_table")] | unique | .[14]',
        data="wasm_br_table.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"l": {"n": 4, "x": [3, 2, 1, 0]},
                                      "lN": 4, "opcode": "br_table"}


def test_wasm_memory_load_memarg_align_offset(tmp_path):
    """i32.load8_u carries a memarg m with align a and byte offset o fields."""
    # CATCHES: memarg object {a:0,o:0} on i32.load8_u and bounded memory lim m/n/tag
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.. | objects | select(.opcode? == "i32.load8_u")]',
        data="wasm_memory_fill.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"m": {"a": 0, "o": 0}, "opcode": "i32.load8_u"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '[.sections[] | select(.id == "memory_section") | .content.mem.x[]]',
        data="wasm_memory_fill.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [{"lim": {"m": 1, "n": 1, "tag": 1}}]


def test_wasm_data_section_segments_and_memory_limits(tmp_path):
    """The data section lists 24 segments with offset exprs and byte payloads."""
    # CATCHES: seg x tag 0, i32.const offset exprs and abcd/abc/empty payloads
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '.sections[] | select(.id == "data_section") | .content.seg '
        "| {n, first2: .x[0:2], payload4: .x[3].b.x}",
        data="wasm_data.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 24,
        "first2": [
            {"b": {"n": 0, "x": ""},
             "e": [{"n": 0, "opcode": "i32.const"}, {"opcode": "end"}], "tag": 0},
            {"b": {"n": 4, "x": "abcd"},
             "e": [{"n": 1, "opcode": "i32.const"}, {"opcode": "end"}], "tag": 0},
        ],
        "payload4": "abc",
    }
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '.sections[] | select(.id == "memory_section") | .content.mem.x[0].lim',
        data="wasm_data.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"n": 1, "tag": 0}


def test_wasm_type_section_function_types(tmp_path):
    """The type section lists functypes with rt1 params and rt2 result type vectors."""
    # CATCHES: tag 96 functype, mixed f32/f64/i32/i64 params and multi-result types
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '.sections[] | select(.id == "type_section") | .content.ft '
        "| {n, first: .x[0], mixed: .x[9], many: .x[17]}",
        data="wasm_type.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 23,
        "first": {"rt1": {"n": 0, "x": []}, "rt2": {"n": 0, "x": []}, "tag": 96},
        "mixed": {"rt1": {"n": 2, "x": ["i32", "i64"]},
                  "rt2": {"n": 2, "x": ["f32", "f64"]}, "tag": 96},
        "many": {"rt1": {"n": 6, "x": ["f32", "f64", "i32", "f64", "i32", "i32"]},
                 "rt2": {"n": 0, "x": []}, "tag": 96},
    }


def test_wasm_table_section_element_type_and_limits(tmp_path):
    """A table section with two funcref tables carries explicit min/max limits."""
    # CATCHES: et funcref, lim tag 1 with both m (max) and n (min) equal to 30
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '.sections[] | select(.id == "table_section") | .content',
        data="wasm_table_copy.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "tab": {
            "n": 2,
            "x": [
                {"et": "funcref", "lim": {"m": 30, "n": 30, "tag": 1}},
                {"et": "funcref", "lim": {"m": 30, "n": 30, "tag": 1}},
            ],
        }
    }
    res = run_fq(
        "-V", "-c", "-d", "wasm", "[.sections[] | .id]",
        data="wasm_memory_init.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "type_section", "function_section", "memory_section", "export_section",
        "data_count_section", "code_section", "data_section",
    ]


def test_wasm_export_and_empty_function_body(tmp_path):
    """A minimal module exports one function whose body is a single end opcode."""
    # CATCHES: export "a" funcidx 0, body size 2 and locals vector n 0
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        '{exp: (.sections[] | select(.id == "export_section") | .content.ex), '
        'code: (.sections[] | select(.id == "code_section") | .content.code)}',
        data="wasm_exports.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "exp": {"n": 1, "x": [{"d": {"tag": "funcidx", "x": 0},
                               "nm": {"b": "a", "n": 1}}]},
        "code": {"n": 1, "x": [{"code": {"e": [{"opcode": "end"}],
                                        "t": {"n": 0, "x": []}},
                                "size": 2}]},
    }


def test_wasm_truncated_module_decodes_gracefully(tmp_path):
    """Truncating a wasm module keeps decoding whole sections and exits cleanly."""
    # CATCHES: header-only gives [], cut section keeps id/size but no content key
    src = data_path("wasm_fac.wasm")
    for n, expected in [
        (8, []),
        (80, ["type_section", "function_section", "export_section"]),
        (400, ["type_section", "function_section", "export_section", "code_section"]),
    ]:
        (tmp_path / "trunc.wasm").write_bytes(src.read_bytes()[:n])
        res = run_fq(
            "-V", "-c", "-d", "wasm", "[.sections[] | .id]",
            "trunc.wasm", cwd=tmp_path,
        )
        assert res.returncode == 0
        assert res.stderr == b""
        assert json.loads(res.stdout) == expected
    (tmp_path / "trunc.wasm").write_bytes(src.read_bytes()[:80])
    res = run_fq(
        "-V", "-c", "-d", "wasm", ".sections[2]", "trunc.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"id": "export_section", "size": 75}
    (tmp_path / "trunc.wasm").write_bytes(src.read_bytes()[:400])
    res = run_fq(
        "-V", "-c", "-d", "wasm",
        "{n: (.sections[3].content.code.x | length), "
        "lastn: (.sections[3].content.code.x[-1].code.e | length)}",
        "trunc.wasm", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"n": 8, "lastn": 4}
