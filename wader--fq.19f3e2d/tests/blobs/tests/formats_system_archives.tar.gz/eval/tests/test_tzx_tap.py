"""ZX Spectrum tape decoders: TZX archives with embedded TAP blocks, and raw TAP."""

import json

from conftest import run_fq


def test_tzx_header_and_block_kinds(tmp_path):
    """A TZX v1.20 file exposes three blocks: archive_info plus two standard-speed."""
    # CATCHES: ZXTape! magic, version 1.20 and per-block single-key wrappers
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        "{keys: keys, sig: .signature, maj: .major_version, min: .minor_version, "
        "n: (.blocks | length)}",
        data="tzx_basic.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "keys": ["signature", "major_version", "minor_version", "blocks"],
        "sig": "ZXTape!\u001a",
        "maj": 1,
        "min": 20,
        "n": 3,
    }
    res = run_fq(
        "-V", "-c", "-d", "tzx", "[.blocks[] | keys[]]",
        data="tzx_basic.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "archive_info", "standard_speed_data", "standard_speed_data",
    ]


def test_tzx_archive_info_and_embedded_tap(tmp_path):
    """archive_info lists nine metadata strings and TAP blocks carry the program."""
    # CATCHES: id/length/value triples, pause 1000 and the BASIC program header
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        "{n: (.blocks[0].archive_info.entries | length), l: .blocks[0].archive_info.length}",
        data="tzx_basic.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"n": 9, "l": 123}
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        "[.blocks[0].archive_info.entries[] | {id, length, value}]",
        data="tzx_basic.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"id": "title", "length": 10, "value": "fqtestprog"},
        {"id": "publisher", "length": 5, "value": "wader"},
        {"id": "author", "length": 15, "value": "Michael R. Cook"},
        {"id": "year", "length": 4, "value": "2024"},
        {"id": "language", "length": 7, "value": "English"},
        {"id": "category", "length": 12, "value": "Test Program"},
        {"id": "loader", "length": 11, "value": "ROM timings"},
        {"id": "origin", "length": 16, "value": "Original release"},
        {"id": "comment", "length": 24, "value": "TZXed by Michael R. Cook"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".blocks[1].standard_speed_data | {pause, type}",
        data="tzx_basic.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"pause": 1000, "type": "standard_speed_data"}
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        ".blocks[1].standard_speed_data.tap.blocks[0].header",
        data="tzx_basic.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "flag": "standard_speed_data",
        "data_type": "program",
        "program_name": "fqTestProg",
        "data_length": 38,
        "program_length": 38,
        "auto_start_line": 10,
        "checksum": 1,
    }
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        ".blocks[2].standard_speed_data.tap.blocks[0].data | {checksum, flag}",
        data="tzx_basic.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"checksum": 182, "flag": "standard_speed_data"}


def test_tap_program_and_data_blocks(tmp_path):
    """A raw TAP file is a header block plus a checksummed BASIC data block."""
    # CATCHES: block lengths 19/40, struct-field key order (length first) and payload
    res = run_fq("-V", "-c", "-d", "tap", "keys", data="tap_basic.tap", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["blocks"]
    res = run_fq(
        "-V", "-c", "-d", "tap",
        "[.blocks[] | {keys: (keys), length}]",
        data="tap_basic.tap", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"keys": ["length", "header"], "length": 19},
        {"keys": ["length", "data"], "length": 40},
    ]
    res = run_fq(
        "-V", "-c", "-d", "tap", ".blocks[0].header",
        data="tap_basic.tap", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "flag": "standard_speed_data",
        "data_type": "program",
        "program_name": "fqTestProg",
        "data_length": 38,
        "program_length": 38,
        "auto_start_line": 10,
        "checksum": 1,
    }
    res = run_fq(
        "-V", "-c", "-d", "tap", ".blocks[1].data | {flag, checksum}",
        data="tap_basic.tap", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "flag": "standard_speed_data", "checksum": 182,
    }
    res = run_fq(
        "-V", "-c", "-d", "tap", '.blocks[1].data.bytes | length',
        data="tap_basic.tap", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 38
    res = run_fq(
        "-V", "-c", "-d", "tap", '.blocks[1].data.bytes | contains("fq is the best!")',
        data="tap_basic.tap", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) is True


def test_tzx_turbo_tone_pulse_and_data_blocks(tmp_path):
    """Turbo-speed, pure-tone, pulse-sequence, pure-data and direct-recording blocks."""
    # CATCHES: distinct per-type field sets (U24 lengths, T-states, used_bits, pulses)
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".blocks[0].turbo_speed_data",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "type": "turbo_speed_data", "pilot_pulse": 2168, "sync_pulse_1": 667,
        "sync_pulse_2": 735, "bit0_pulse": 855, "bit1_pulse": 1710,
        "pilot_tone": 3223, "used_bits": 8, "pause": 1000, "length": 4,
        "data": "ABCD",
    }
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        "[.blocks[1].pure_tone, .blocks[2].sequence_of_pulses, .blocks[3].pure_data]",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"type": "pure_tone", "pulse_length": 2168, "pulse_count": 4},
        {"type": "sequence_of_pulses", "pulse_count": 3, "pulses": [100, 200, 300]},
        {"type": "pure_data", "bit0_pulse": 855, "bit1_pulse": 1710,
         "used_bits": 6, "pause": 0, "length": 2, "data": "\ufffd\ufffd"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".blocks[4].direct_recording",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "type": "direct_recording", "t_states": 79, "pause": 0,
        "used_bits": 8, "length": 3, "data": "\u000f\u000f\u000f",
    }


def test_tzx_csw_and_generalized_data_blocks(tmp_path):
    """CSW v2 recording decodes its header minus the 10 fixed bytes; generalized raw."""
    # CATCHES: csw length excludes header fields, compression_type symbol "rle"
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".blocks[5].csw_recording",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "type": "csw_recording", "length": 12, "pause": 500,
        "sample_rate": 44100, "compression_type": "rle",
        "stored_pulse_count": 7, "data": "\u0002\u0001",
    }
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".blocks[6].generalized_data | {type, length}",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "type": "generalized_data", "length": 5,
    }


def test_tzx_flow_control_blocks(tmp_path):
    """Group/loop/call/select/jump blocks decode with their symbolic jump values."""
    # CATCHES: jump_to sym strings incl -1 -> prev_block, signed select/call offsets
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        "[.blocks[7].pause_tape_command, .blocks[8].group_start, .blocks[9].group_end, "
        ".blocks[14].loop_start, .blocks[15].loop_end, .blocks[17].return_from_sequence]",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"type": "pause_tape_command", "pause": 1234},
        {"type": "group_start", "length": 5, "group_name": "level"},
        {"type": "group_end"},
        {"type": "loop_start", "repetitions": 3},
        {"type": "loop_end"},
        {"type": "return_from_sequence"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "tzx", "[.blocks[10:14][] | .jump_to.value]",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "loop_forever", "next_block", "skip_block", "prev_block",
    ]
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        "[.blocks[16].call_sequence, .blocks[18].select]",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"type": "call_sequence", "count": 2, "call_blocks": [5, -2]},
        {"type": "select", "length": 19, "count": 2,
         "selections": [{"offset": 10, "length": 6, "description": "Part 1"},
                        {"offset": -3, "length": 6, "description": "Part 2"}]},
    ]


def test_tzx_metadata_blocks_and_glue(tmp_path):
    """Signal level, text, message, custom-info and glue blocks decode their strings."""
    # CATCHES: set_signal_level "high" symbol, ISO8859-1 strings and glue 9 raw bytes
    res = run_fq(
        "-V", "-c", "-d", "tzx",
        "[.blocks[19].stop_tape_when_48k_mode, .blocks[20].set_signal_level, "
        ".blocks[21].text_description, .blocks[22].message]",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"type": "stop_tape_when_48k_mode", "length": 0},
        {"type": "set_signal_level", "length": 2, "signal_level": "high"},
        {"type": "text_description", "length": 13, "description": "Start of tape"},
        {"type": "message", "display_time": 5, "length": 5, "message": "hello"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".blocks[24].custom_info",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "type": "custom_info", "identification": "custom-info-id16",
        "length": 4, "info": "\u07ad\ufffd\ufffd",
    }
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".blocks[25].glue_block",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "type": "glue_block", "value": "XTape!\u001a\u0001\u0014",
    }


def test_tzx_hardware_type_block(tmp_path):
    """hardware_type entries are numeric in JSON but carry device descriptions in dv."""
    # CATCHES: type/device/info ids stay numbers in values mode; dv shows the maps
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".blocks[23].hardware_type",
        data="tzx_blocks.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "type": "hardware_type", "count": 3,
        "hardware_info": [
            {"type_id": 0, "device_id": 1, "info_id": 0},
            {"type_id": 4, "device_id": 0, "info_id": 1},
            {"type_id": 3, "device_id": 0, "info_id": 2},
        ],
    }
    res = run_fq("-d", "tzx", "dv", data="tzx_blocks.tzx", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    display = res.stdout
    assert b"type_id: 0 (Computers)" in display
    assert b"device_id: 1 (ZX Spectrum 48k, Plus)" in display
    assert b"type_id: 4 (Joysticks)" in display
    assert b"device_id: 0 (Kempston)" in display
    assert b"type_id: 3 (Sound devices)" in display
    assert b"device_id: 0 (Classic AY hardware (compatible with 128k ZXs))" in display
    assert b"info_id: 1 (USES the hardware or special features of the machine" in display
    assert b"info_id: 2 (RUNS but it DOESN'T use the hardware" in display


def test_tzx_deprecated_and_invalid_blocks_error(tmp_path):
    """Deprecated (0x34) and unknown (0x99) block ids abort the decode with gap0."""
    # CATCHES: fatal mid-file leaves earlier blocks decoded and adds trailing gap0
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".",
        data="tzx_deprecated.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "signature": "ZXTape!\u001a", "major_version": 1, "minor_version": 20,
        "blocks": [{}], "gap0": "4\u0000\u0000",
    }
    res = run_fq("-d", "tzx", ".", data="tzx_deprecated.tzx", cwd=tmp_path)
    assert res.returncode == 0
    assert b"error: tzx: error at position 0xa: deprecated block type encountered: 34" in res.stdout
    res = run_fq(
        "-V", "-c", "-d", "tzx", ".",
        data="tzx_invalid.tzx", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "signature": "ZXTape!\u001a", "major_version": 1, "minor_version": 20,
        "blocks": [{"": {"type": 153}}], "gap0": "\u0000\u0000",
    }
    res = run_fq("-d", "tzx", ".", data="tzx_invalid.tzx", cwd=tmp_path)
    assert res.returncode == 0
    assert b"error: tzx: error at position 0xb: block type not valid, got: 99" in res.stdout
