"""Apple/Cubism decoders: CAFF archives with nested PNG/XML, Apple BookmarkData."""

import json

from conftest import run_fq


def test_caff_header_and_file_info_list(tmp_path):
    """A CAFF archive declares ids/versions and lists its four member files."""
    # CATCHES: CAFF/---- ids, negative obfuscate key and raw/fast compress options
    res = run_fq("-V", "-c", "-d", "caff", "keys", data="caff_test.cmo3", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "archive_id", "archive_version", "format_id", "format_version",
        "obfuscate_key", "unused0", "preview_image", "unused1",
        "file_info_map_size", "file_info_list", "files", "guard_bytes",
    ]
    res = run_fq(
        "-V", "-c", "-d", "caff",
        "{aid: .archive_id, av: .archive_version, fid: .format_id, "
        "fv: .format_version, okey: .obfuscate_key, fims: .file_info_map_size}",
        data="caff_test.cmo3", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "aid": "CAFF",
        "av": {"major": 0, "minor": 0, "patch": 0},
        "fid": "----",
        "fv": {"major": 0, "minor": 0, "patch": 0},
        "okey": -1344390416,
        "fims": 4,
    }
    res = run_fq(
        "-V", "-c", "-d", "caff",
        "[.file_info_list[] | {compress_option, file_path, file_size, "
        "is_obfuscated, start_pos, tag, unused0}]",
        data="caff_test.cmo3", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"compress_option": "raw", "file_path": "image.png", "file_size": 96,
         "is_obfuscated": True, "start_pos": 201, "tag": "", "unused0": 0},
        {"compress_option": "raw", "file_path": "image_0.png", "file_size": 83,
         "is_obfuscated": True, "start_pos": 297, "tag": "", "unused0": 0},
        {"compress_option": "raw", "file_path": "image_1.png", "file_size": 75,
         "is_obfuscated": True, "start_pos": 380, "tag": "", "unused0": 0},
        {"compress_option": "fast", "file_path": "main.xml", "file_size": 8352,
         "is_obfuscated": True, "start_pos": 455, "tag": "main_xml", "unused0": 0},
    ]


def test_caff_files_decode_nested_formats(tmp_path):
    """CAFF members decode recursively: PNGs to signature/chunks, XML to a root."""
    # CATCHES: all four .uncompressed values are objects with format-specific keys
    res = run_fq(
        "-V", "-c", "-d", "caff", "[.files[] | {fp: .file_path, t: (.uncompressed | type)}]",
        data="caff_test.cmo3", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"fp": "image.png", "t": "object"},
        {"fp": "image_0.png", "t": "object"},
        {"fp": "image_1.png", "t": "object"},
        {"fp": "main.xml", "t": "object"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "caff",
        "{k0: (.files[0].uncompressed | keys), k3: (.files[3].uncompressed | keys)}",
        data="caff_test.cmo3", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "k0": ["signature", "chunks"],
        "k3": ["root"],
    }


def test_caff_uncompress_option_matches_default(tmp_path):
    """-o uncompress=true on a CAFF archive yields the same shapes as the default."""
    # CATCHES: caff members are already decoded, so the uncompress option is a no-op
    query = "[.files[] | {fp: .file_path, t: (.uncompressed | type)}]"
    res = run_fq("-V", "-c", "-d", "caff", query, data="caff_test.cmo3", cwd=tmp_path)
    assert res.returncode == 0
    default_out = res.stdout
    res = run_fq(
        "-V", "-c", "-d", "caff", "-o", "uncompress=true", query,
        data="caff_test.cmo3", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert res.stdout == default_out


def test_bookmark_header_and_toc(tmp_path):
    """A BookmarkData file pairs a "book" header with a TOC header of 13 entries."""
    # CATCHES: magic "book", total_size 560, TOC magic 4294967294 and toc_size 168
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark", "keys",
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "header", "first_toc_offset", "bookmark_entries", "toc_headers",
    ]
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark",
        ".header | {header_size, magic, total_size, unknown, nr: (.reserved | length)}",
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "header_size": 48, "magic": "book", "total_size": 560,
        "unknown": 268697600, "nr": 32,
    }
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark", ".first_toc_offset",
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 336
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark", ".toc_headers[0]",
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "identifier": 1, "magic": 4294967294, "next_toc_offset": 0,
        "num_entries_in_toc": 13, "toc_size": 168,
    }


def test_bookmark_entry_keys_and_record_payloads(tmp_path):
    """Bookmark entries are key/record pairs decoding paths, CNIDs, UUIDs and dates."""
    # CATCHES: nested {offset, record} arrays, string/long/date record types
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark", "[.bookmark_entries[] | .key]",
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "target_path", "target_cnid_path", "target_flags", "target_creation_date",
        "volume_path", "volume_url", "volume_name", "volume_uuid", "volume_size",
        "volume_creation_date", "volume_flags", "volume_is_root", "creation_options",
    ]
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark",
        ".bookmark_entries[0] | {key, offset_to_record, unused, rt: .record.type, "
        "rl: .record.length}",
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "key": "target_path", "offset_to_record": 60, "unused": 0,
        "rt": "array", "rl": 8,
    }
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark", ".bookmark_entries[0].record.data",
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"offset": 16, "record": {"alignment_bytes": "\r\u0000\u0000\u0000",
                                  "data": "Applications", "length": 12, "type": "string"}},
        {"offset": 36, "record": {"alignment_bytes": "\u0000\u0000\u0000",
                                  "data": "Bitwarden.app", "length": 13, "type": "string"}},
    ]
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark",
        '[.bookmark_entries[] | select(.key == "volume_name" or .key == "volume_uuid" '
        'or .key == "volume_url") | {k: .key, d: .record.data}]',
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"k": "volume_url", "d": "file:///"},
        {"k": "volume_name", "d": "Macintosh HD"},
        {"k": "volume_uuid", "d": "AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark",
        '[.bookmark_entries[] | select(.key == "target_cnid_path") | .record.data]',
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [[
        {"offset": 76, "record": {"data": 55637351, "length": 8, "type": "long"}},
        {"offset": 92, "record": {"data": 54389243, "length": 8, "type": "long"}},
    ]]
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark",
        '[.bookmark_entries[] | select(.key == "target_creation_date") | .record]',
        data="bookmark_sample1.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [{"data": 687998368, "length": 8, "type": "date"}]


def test_bookmark_loop_protection_and_wrong_input(tmp_path):
    """Self-referential bookmarks emit stub records and gzip input decodes empty."""
    # CATCHES: loop file keeps a {offset} stub instead of recursing; gzip -> empty root
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark", "keys",
        data="bookmark_loop.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "header", "first_toc_offset", "gap0", "bookmark_entries",
        "gap1", "toc_headers", "gap2",
    ]
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark",
        "{n: (.bookmark_entries | length), r0: .bookmark_entries[0].record}",
        data="bookmark_loop.book", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 1, "r0": {"data": [{"offset": 60}], "length": 8, "type": "array"},
    }
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark", "keys", data="gzip_test.gz", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["header", "gap0"]
    res = run_fq(
        "-V", "-c", "-d", "apple_bookmark", ".header", data="gzip_test.gz", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {}
