"""Mosaic decoder: EBML header, container metadata, tiles and SWH index records."""

import json

from conftest import run_fq


def test_mosaic_ebml_header_and_root_layout(tmp_path):
    """A mosaic file is an EBML document whose root holds ebml and mosaic elements."""
    # CATCHES: doc_type "mosaic", EBML element sizes and the mosaic master element
    res = run_fq("-V", "-c", "-d", "mosaic", "keys", data="mosaic_basic.mosaic", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["ebml", "mosaic"]
    res = run_fq(
        "-V", "-c", "-d", "mosaic",
        ".ebml | {id, type, size, dt: .doc_type.value, dtv: .doc_type_version.value, "
        "dtrv: .doc_type_read_version.value, ev: .ebml_version.value, "
        "erv: .ebml_read_version.value, mil: .ebml_max_id_length.value, "
        "msl: .ebml_max_size_length.value}",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "id": "ebml", "type": "master", "size": 33,
        "dt": "mosaic", "dtv": 1, "dtrv": 1, "ev": 1, "erv": 1, "mil": 4, "msl": 8,
    }
    res = run_fq(
        "-V", "-c", "-d", "mosaic", ".mosaic | keys",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "id", "type", "size", "container_meta_data", "tile", "index",
    ]
    res = run_fq(
        "-V", "-c", "-d", "mosaic", ".mosaic | {id, type, size}",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"id": "mosaic", "type": "master", "size": 199101}


def test_mosaic_container_meta_data_and_tiles(tmp_path):
    """Container metadata counts objects and the seven tiles hold binary objects."""
    # CATCHES: no_compression method, end_of_tiles_offset, XML comment and tile sizes
    res = run_fq(
        "-V", "-c", "-d", "mosaic",
        ".mosaic.container_meta_data | "
        "{oc: .objects_counter.value, ots: .objects_total_size.value, "
        "eot: .end_of_tiles_offset.value, cm: .compression_method.value}",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "oc": 21, "ots": 186306, "eot": 196718, "cm": "no_compression",
    }
    res = run_fq(
        "-V", "-c", "-d", "mosaic",
        '.mosaic.container_meta_data.comment[0].value[0:38]',
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == '<?xml version="1.0" encoding="utf-8"?>'
    res = run_fq(
        "-V", "-c", "-d", "mosaic", "[.mosaic.tile[] | {id, type, size}]",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"id": "tile", "type": "master", "size": 31418},
        {"id": "tile", "type": "master", "size": 10216},
        {"id": "tile", "type": "master", "size": 29381},
        {"id": "tile", "type": "master", "size": 29765},
        {"id": "tile", "type": "master", "size": 28746},
        {"id": "tile", "type": "master", "size": 26266},
        {"id": "tile", "type": "master", "size": 30624},
    ]
    res = run_fq(
        "-V", "-c", "-d", "mosaic", ".mosaic.tile[0] | keys",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["id", "type", "size", "crc32", "object"]
    res = run_fq(
        "-V", "-c", "-d", "mosaic",
        "{n: (.mosaic.tile[0].object | length), o: .mosaic.tile[0].object[0] | {id, size, type}}",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "n": 9, "o": {"id": "object", "size": 1682, "type": "binary"},
    }


def test_mosaic_index_records(tmp_path):
    """The trailing index elements unroll into key/offset pairs with a map container."""
    # CATCHES: idx_description SWH string, 27-byte entries, alternating key/offset ids
    res = run_fq(
        "-V", "-c", "-d", "mosaic", "[.mosaic.index[] | {id, type, size}]",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"id": "index", "type": "master", "size": 716},
        {"id": "index", "type": "master", "size": 729},
        {"id": "index", "type": "master", "size": 970},
    ]
    res = run_fq(
        "-V", "-c", "-d", "mosaic", ".mosaic.index[0] | keys",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "id", "type", "size", "crc32", "idx_description", "idx_unrolled",
        "idx_unrolled_entry_size", "map_container",
    ]
    res = run_fq(
        "-V", "-c", "-d", "mosaic", ".mosaic.index[0].idx_description.value",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == (
        "key:sha1 pkg:cargo/ph@0.10.0 "
        "swh:1:dir:795095368f036f42adebcb75782a61494940e9b8 ph::fmph::GOFunction"
    )
    res = run_fq(
        "-V", "-c", "-d", "mosaic",
        "{es: .mosaic.index[0].idx_unrolled_entry_size.value, "
        "n: (.mosaic.index[0].idx_unrolled.elements | length)}",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"es": 27, "n": 42}
    res = run_fq(
        "-V", "-c", "-d", "mosaic",
        "[.mosaic.index[0].idx_unrolled.elements[0:4][] | {id, size, type}]",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"id": "key", "size": 20, "type": "binary"},
        {"id": "offset", "size": 3, "type": "uinteger"},
        {"id": "key", "size": 20, "type": "binary"},
        {"id": "offset", "size": 3, "type": "uinteger"},
    ]
    res = run_fq(
        "-V", "-c", "-d", "mosaic", ".mosaic.index[0].idx_unrolled.elements[1]",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"id": "offset", "size": 3, "type": "uinteger", "value": 139827}
    res = run_fq(
        "-V", "-c", "-d", "mosaic", ".mosaic.index[0].map_container | keys",
        data="mosaic_basic.mosaic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["id", "type", "size", "crc32", "map"]
