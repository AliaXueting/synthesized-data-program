"""Unix archive decoders: ar members (symbol index, nested ELF) and ustar tar."""

import json

import pytest

from conftest import run_fq


@pytest.mark.parametrize("data", ["ar_elf_386.a", "ar_macho.a"])
def test_ar_signature_and_member_layout(data, tmp_path):
    """ar root is signature+files and every member header shares the same fields."""
    # CATCHES: "!<arch>\\n" magic, per-member identifier/timestamp/mode/size headers
    res = run_fq("-V", "-c", "-d", "ar", "keys", data=data, cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["signature", "files"]
    res = run_fq("-V", "-c", "-d", "ar", ".signature", data=data, cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == "!<arch>\n"
    res = run_fq("-V", "-c", "-d", "ar", ".files | length", data=data, cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == 2
    res = run_fq("-V", "-c", "-d", "ar", ".files[0] | keys", data=data, cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "identifier",
        "modification_timestamp",
        "owner_id",
        "group_id",
        "file_mode",
        "file_size",
        "ending_characters",
        "data",
    ]


def test_ar_elf_member_metadata_and_elf_decode(tmp_path):
    """The ELF archive members carry BSD-ish headers and the .o member decodes as ELF."""
    # CATCHES: symbol index member "/" with mode 0, libbbb.o/ size 1344, nested ELF rel
    res = run_fq(
        "-V", "-c", "-d", "ar",
        "[.files[] | {id: .identifier, ts: .modification_timestamp, "
        "mode: .file_mode, size: .file_size}]",
        data="ar_elf_386.a", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"id": "/", "ts": 0, "mode": 0, "size": 46},
        {"id": "libbbb.o/", "ts": 0, "mode": 420, "size": 1344},
    ]
    res = run_fq(
        "-V", "-c", "-d", "ar", ".files[0].data[0:22]",
        data="ar_elf_386.a", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == "\x00\x00\x00\x02\x00\x00\x00r\x00\x00\x00rlibbbb_bbb"
    res = run_fq(
        "-V", "-c", "-d", "ar", ".files[1].data | keys",
        data="ar_elf_386.a", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "header", "section_headers", "gap0", "gap1", "program_headers",
    ]
    res = run_fq(
        "-V", "-c", "-d", "ar", ".files[1].data.header | {machine, type, shnum}",
        data="ar_elf_386.a", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"machine": "x86", "type": "rel", "shnum": 16}


def test_ar_macho_symbol_index_member(tmp_path):
    """A Mach-O archive stores __.SYMDEF SORTED with #1/N extended name members."""
    # CATCHES: "#1/20" long names, mode 33188 regular files and the SYMDEF payload
    res = run_fq(
        "-V", "-c", "-d", "ar",
        "[.files[] | {id: .identifier, mode: .file_mode, size: .file_size}]",
        data="ar_macho.a", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"id": "#1/20", "mode": 33188, "size": 52},
        {"id": "#1/12", "mode": 33188, "size": 764},
    ]
    res = run_fq(
        "-V", "-c", "-d", "ar", ".files[0].data[0:16]",
        data="ar_macho.a", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == "__.SYMDEF SORTED"


def test_tar_ustar_entry_fields(tmp_path):
    """tar files decode ustar headers with uname/gname and inline file data."""
    # CATCHES: ustar magic, wader/staff names, mode 420 and the "hello\\n" payload
    res = run_fq("-V", "-c", "-d", "tar", "keys", data="tar_test.tar", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == ["files", "end_marker"]
    res = run_fq(
        "-V", "-c", "-d", "tar",
        ".files[0] | {name, mode, uid, gid, size, mtime, typeflag, magic, uname, gname}",
        data="tar_test.tar", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "name": "test",
        "mode": 420,
        "uid": 501,
        "gid": 20,
        "size": 6,
        "mtime": 1634675538,
        "typeflag": "0",
        "magic": "ustar",
        "uname": "wader",
        "gname": "staff",
    }
    res = run_fq(
        "-V", "-c", "-d", "tar", ".files[0].data",
        data="tar_test.tar", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == "hello\n"
    res = run_fq(
        "-V", "-c", "-d", "tar", ".files[0] | keys",
        data="tar_test.tar", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "name", "mode", "uid", "gid", "size", "mtime", "chksum", "typeflag",
        "linkname", "magic", "version", "uname", "gname", "devmajor", "devminor",
        "prefix", "header_block_padding", "data", "data_block_padding",
    ]


def test_tar_end_marker_present_and_absent(tmp_path):
    """A padded tar keeps a 9216-byte end_marker while an unpadded one has null."""
    # CATCHES: end_marker is a string when present, null without trailing zero blocks
    res = run_fq(
        "-V", "-c", "-d", "tar",
        "{t: (.end_marker | type), l: (.end_marker | length), n: (.files | length)}",
        data="tar_test.tar", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {"t": "string", "l": 9216, "n": 1}
    res = run_fq(
        "-V", "-c", "-d", "tar", ".end_marker",
        data="tar_no_end_marker.tar", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) is None
    res = run_fq("-d", "tar", ".", data="tar_no_end_marker.tar", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert b"until 0x3ff.7 (end) (1024)" in res.stdout
    assert b"tar_no_end_marker.tar (tar)" in res.stdout


def test_tar_probes_gzip_member_content(tmp_path):
    """A gzip member inside tar is recursively probed and decoded as a gzip value."""
    # CATCHES: member data becomes gzip {members,uncompressed}, not raw bytes
    res = run_fq(
        "-V", "-c", "-d", "tar",
        "{name: .files[0].name, datakeys: (.files[0].data | keys), "
        "method: .files[0].data.members[0].compression_method, "
        "payload: .files[0].data.uncompressed}",
        data="tar_gz_member.tar", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "name": "inner.gz",
        "datakeys": ["uncompressed", "members"],
        "method": "deflate",
        "payload": "test\n",
    }
    res = run_fq(
        "-V", "-c", "-d", "tar",
        ".files[0].data.members[0] | {isize, crc32, os, flags}",
        data="tar_gz_member.tar", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "isize": 5, "crc32": 1001993670, "os": "unix",
        "flags": {"comment": False, "extra": False, "header_crc": False,
                  "name": False, "reserved": 0, "text": False},
    }
    res = run_fq(
        "-d", "tar", ".files[0].mtime", data="tar_gz_member.tar", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert b"(2021-10-19T20:32:18Z)" in res.stdout
