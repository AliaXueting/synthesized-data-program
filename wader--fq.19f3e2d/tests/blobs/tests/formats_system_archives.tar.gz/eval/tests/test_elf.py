"""ELF decoder: headers, section/program tables, symbols, dynamic tags, errors."""

import json

import pytest

from conftest import run_fq, stage_data

HEADER_QUERY = (
    ".header | {machine, type, entry, ehsize, phentsize, phnum, "
    "shentsize, shnum, shstrndx, phoff, shoff}"
)


@pytest.mark.parametrize(
    "data,expected",
    [
        (
            "elf_amd64_dynamic",
            {
                "machine": "x86_64",
                "type": "dyn",
                "entry": 4208,
                "ehsize": 64,
                "phentsize": 56,
                "phnum": 12,
                "shentsize": 64,
                "shnum": 34,
                "shstrndx": 33,
                "phoff": 64,
                "shoff": 16016,
            },
        ),
        (
            "elf_386_dynamic",
            {
                "machine": "x86",
                "type": "dyn",
                "entry": 4224,
                "ehsize": 52,
                "phentsize": 32,
                "phnum": 12,
                "shentsize": 40,
                "shnum": 34,
                "shstrndx": 33,
                "phoff": 52,
                "shoff": 15472,
            },
        ),
    ],
)
def test_elf_header_fields(data, expected, tmp_path):
    """ELF header scalars (machine, type, entry, table geometry) for 64/32-bit builds."""
    # CATCHES: class-dependent e_ehsize/e_phentsize/e_shentsize and table offsets
    res = run_fq("-V", "-c", "-d", "elf", HEADER_QUERY, data=data, cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == expected


def test_elf_top_level_keys(tmp_path):
    """The ELF value root has header/program_headers/section_headers plus gap fields."""
    # CATCHES: root layout uses section_headers (not .sections) and exposes gap0..gap6
    res = run_fq("-V", "-c", "-d", "elf", "keys", data="elf_amd64_dynamic", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "header",
        "program_headers",
        "section_headers",
        "gap0",
        "gap1",
        "gap2",
        "gap3",
        "gap4",
        "gap5",
        "gap6",
    ]


def test_elf_section_headers(tmp_path):
    """First six section headers carry name/type/offset/size with symbolic types."""
    # CATCHES: section type symbols (progbits, note, gnu_hash, dynsym, strtab)
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "elf",
        "[.section_headers[0:6][] | {name, type, offset, size}]",
        data="elf_amd64_dynamic",
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"name": "", "type": "null", "offset": 0, "size": 0},
        {"name": ".interp", "type": "progbits", "offset": 736, "size": 25},
        {"name": ".note.gnu.property", "type": "note", "offset": 768, "size": 48},
        {"name": ".gnu.hash", "type": "gnu_hash", "offset": 816, "size": 48},
        {"name": ".dynsym", "type": "dynsym", "offset": 864, "size": 264},
        {"name": ".dynstr", "type": "strtab", "offset": 1128, "size": 194},
    ]


def test_elf_program_headers(tmp_path):
    """Program header types and r/w/x flags of the four PT_LOAD segments."""
    # CATCHES: symbolic phdr types and per-load flag decoding (r, r+x, r, r+w)
    res = run_fq(
        "-V", "-c", "-d", "elf", "[.program_headers[] | .type]",
        data="elf_amd64_dynamic", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        "phdr", "interp", "load", "load", "load", "load", "dynamic",
        "note", "os", "gnu_eh_frame", "gnu_stack", "gnu_relro",
    ]
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "elf",
        "[.program_headers[] | select(.type == \"load\") | .flags | {r, w, x}]",
        data="elf_amd64_dynamic",
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"r": True, "w": False, "x": False},
        {"r": True, "w": False, "x": True},
        {"r": True, "w": False, "x": False},
        {"r": True, "w": True, "x": False},
    ]


def test_elf_symbol_tables(tmp_path):
    """dynsym entries, symtab size and one full symtab symbol record."""
    # CATCHES: symbol name/bind/type mapping and full record for symbol "aaa"
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "elf",
        '[.section_headers[] | select(.name == ".dynsym") '
        "| .symbol_table[0:6][] | {name, bind, type}]",
        data="elf_amd64_dynamic",
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"name": "", "bind": "local", "type": "notype"},
        {"name": "puts", "bind": "global", "type": "func"},
        {"name": "__deregister_frame_info", "bind": "weak", "type": "notype"},
        {"name": "_ITM_registerTMCloneTable", "bind": "weak", "type": "notype"},
        {"name": "_ITM_deregisterTMCloneTable", "bind": "weak", "type": "notype"},
        {"name": "libbbb_bbb", "bind": "global", "type": "func"},
    ]
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "elf",
        '[.section_headers[] | select(.name == ".symtab") | .symbol_table | length]',
        data="elf_amd64_dynamic",
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [42]
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "elf",
        '[.section_headers[] | select(.name == ".symtab") '
        '| .symbol_table[] | select(.name == "aaa")]',
        data="elf_amd64_dynamic",
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {
            "name": "aaa",
            "bind": "global",
            "type": "func",
            "value": 4613,
            "size": 19,
            "shndx": 11,
            "other_unused": 0,
            "visibility": "default",
        }
    ]


def test_elf_dynamic_tags_and_text_section(tmp_path):
    """Dynamic tag list decodes needed libraries and init pointer; .text geometry."""
    # CATCHES: DT_NEEDED strings ("val" field), DT_INIT ptr, .text addr==offset
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "elf",
        '[.section_headers[] | select(.name == ".dynamic") | .dynamic_tags[0:3]]',
        data="elf_amd64_dynamic",
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        [
            {"tag": "needed", "val": "libbbb.so"},
            {"tag": "needed", "val": "libc.musl-x86_64.so.1"},
            {"tag": "init", "ptr": 4096, "section_index": 8},
        ]
    ]
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "elf",
        '[.section_headers[] | select(.name == ".text") '
        "| {addr: .addr, offset: .offset, size: .size, type: .type}]",
        data="elf_amd64_dynamic",
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == [
        {"addr": 4208, "offset": 4208, "size": 529, "type": "progbits"}
    ]


def test_elf_stripped_binary_has_no_symtab(tmp_path):
    """A stripped ELF keeps 24 sections but yields zero .symtab sections."""
    # CATCHES: strip removes the symbol table while section count drops 34 -> 24
    res = run_fq(
        "-V", "-c", "-d", "elf", ".section_headers | length",
        data="elf_amd64_stripped", cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 24
    res = run_fq(
        "-V",
        "-c",
        "-d",
        "elf",
        '[.section_headers[] | select(.name == ".symtab")] | length',
        data="elf_amd64_stripped",
        cwd=tmp_path,
    )
    assert res.returncode == 0
    assert json.loads(res.stdout) == 0


def test_elf_truncated_header_decodes_but_display_reports_eof(tmp_path):
    """A 20-byte truncated ELF still yields .header in JSON mode and an inline error."""
    # CATCHES: graceful truncation - partial header value, exit 0, EOF error in display
    name = stage_data("elf_amd64_dynamic", tmp_path)
    trunc = tmp_path / "trunc20.elf"
    trunc.write_bytes((tmp_path / name).read_bytes()[:20])
    res = run_fq("-V", "-c", "-d", "elf", ".header", "trunc20.elf", cwd=tmp_path)
    assert res.returncode == 0
    assert json.loads(res.stdout) == {
        "ident": {
            "magic": "\u007fELF",
            "class": 64,
            "data": "little_endian",
            "version": 1,
            "os_abi": "sysv",
            "abi_version": 0,
            "pad": "\u0000\u0000\u0000\u0000\u0000\u0000\u0000",
        },
        "machine": "x86_64",
        "type": "dyn",
    }
    res = run_fq("-d", "elf", ".", "trunc20.elf", cwd=tmp_path)
    assert res.returncode == 0
    assert res.stderr == b""
    assert (
        b"error: elf: U32(version): failed at position 20 "
        b"(read size 0 seek pos 0): EOF" in res.stdout
    )
