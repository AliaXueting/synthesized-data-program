"""BSON decoding and the torepr conversion.

Covers ``-d bson`` for every element type (double, string, embedded
document, array, binary with subtype, undefined, object id, boolean,
datetime, null, regexp with options, javascript, int32, timestamp, int64,
decimal128 as raw bits, min key and max key), the jq tree shape
(``size``/``elements``/``terminator``), ``torepr`` turning that tree back
into plain jq values (arrays flatten, booleans become real booleans),
malformed input behaviour (bad sizes, truncated strings, negative binary
lengths, invalid terminator) and that bson is never auto-probed.
"""

from __future__ import annotations

import base64

import pytest

from conftest import run_fq, write_b64

# All expectations below were recorded by running ./executable.

# document with one element of (almost) every bson type:
# double 98.765, string "my string", embedded doc {nint: -42}, array
# [2**40 as int64, 7 as int32], binary subtype 0x80 "ABC", undefined,
# object id bytes 0..11, booleans true/false, datetime 1234567890123,
# null, regexp "p.*ttern"/"imsx", javascript "print(1)", int32 min,
# timestamp 0xDEADBEEFCAFE, int64 min, decimal128 raw bytes 0..15,
# minkey and maxkey.
BSON_TYPES = base64.b64decode(
    "DwEAAAFkb3VibGUAKVyPwvWwWEACc3RyAAoAAABteSBzdHJpbmcAA2RvYwAPAAAAEG5pbnQA"
    "1v///wAEYXJyABcAAAASMAAAAAAAAAEAABAxAAcAAAAABWJpbgADAAAAgEFCQwZ1bmRlZgAH"
    "b2lkAAABAgMEBQYHCAkKCwhidHJ1ZQABCGJmYWxzZQAACWRhdGUAywT7cR8BAAAKbnVsbAAL"
    "cmUAcC4qdHRlcm4AaW1zeAANanMACQAAAHByaW50KDEpABBpMzIAAAAAgBF0cwD+yu++rd4A"
    "ABJpNjQAAAAAAAAAAIATZGVjMTI4AAABAgMEBQYHCAkKCwwNDg//bWlua2V5AH9tYXhrZXkA"
    "AA=="
)

# small document used for display assertions (double, binary, object id,
# datetime, decimal128, minkey, maxkey).
BSON_DISP = base64.b64decode(
    "XAAAAAFkb3UAKVyPwvWwWEAFYmluAAMAAACAQUJDB29pZAAAAQIDBAUGBwgJCgsJZGF0AMsE"
    "+3EfAQAAE2RlYwAAAQIDBAUGBwgJCgsMDQ4P/21pbgB/bWF4AAA="
)

# document with one element of unknown type 0x42.
BSON_UNKNOWN = base64.b64decode("FgAAAEJ1bmtub3duAAUAAABqdW5rAA==")

# empty document: size 5, no elements, terminator 0.
BSON_EMPTY = base64.b64decode("BQAAAAA=")

# empty document whose terminator byte is 1 instead of 0.
BSON_BADTERM = base64.b64decode("BQAAAAE=")

# document claiming size 100 but only 5 bytes present.
BSON_BIGSIZE = base64.b64decode("ZAAAAAA=")

# document claiming size 3 (smaller than the 4-byte size field itself).
BSON_SMALLSIZE = base64.b64decode("AwAAAAAA")

# document with a string element claiming length 50 with only 3 bytes left.
BSON_BADSTR = base64.b64decode("DwAAAAJzADIAAABhYgAA")

# document with a binary element of length -1.
BSON_NEGBIN = base64.b64decode("DwAAAAViAP////8AQUIA")


@pytest.mark.parametrize(
    "idx,expected",
    [
        (0, '{"name":"double","type":"double","value":98.765}'),
        (1, '{"length":10,"name":"str","type":"string","value":"my string"}'),
        (5, '{"name":"undef","type":"undefined"}'),
        (
            6,
            '{"name":"oid","type":"object_id","value":'
            '"\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005\\u0006\\u0007\\b\\t\\n\\u000b"}',
        ),
        (7, '{"name":"btrue","type":"boolean","value":1}'),
        (8, '{"name":"bfalse","type":"boolean","value":0}'),
        (9, '{"name":"date","type":"datetime","value":1234567890123}'),
        (10, '{"name":"null","type":"null","value":null}'),
        (11, '{"name":"re","options":"imsx","type":"regexp","value":"p.*ttern"}'),
        (12, '{"length":9,"name":"js","type":"javascript","value":"print(1)"}'),
        (13, '{"name":"i32","type":"int32","value":-2147483648}'),
        (14, '{"name":"ts","type":"timestamp","value":244837814094590}'),
        (15, '{"name":"i64","type":"int64","value":-9223372036854775808}'),
        (17, '{"name":"minkey","type":"minkey","value":null}'),
        (18, '{"name":"maxkey","type":"maxkey","value":null}'),
    ],
)
def test_bson_element_types(tmp_path, idx, expected):
    """Each scalar element decodes to its type symbol and plain value."""
    path = write_b64(tmp_path, "types.bson", BSON_TYPES)
    res = run_fq(["-d", "bson", "-V", "-c", f".elements[{idx}]"], path)
    # CATCHES: every element type maps to its own symbol ("double",
    # "undefined", "object_id", "boolean", "datetime", "null", "regexp",
    # "javascript", "int32", "timestamp", "int64", "minkey", "maxkey") with
    # the value in the native endianness/signedness of the spec.
    assert res.returncode == 0
    assert res.stdout == f"{expected}\n".encode()
    assert res.stderr == b""


def test_bson_full_types_tree(tmp_path):
    """The whole document tree has size, elements and terminator fields."""
    path = write_b64(tmp_path, "types.bson", BSON_TYPES)
    res = run_fq(["-d", "bson", "-V", "-c", "[.size, .terminator, (.elements|length)]"], path)
    # CATCHES: the document frame records the total byte size (271), a
    # terminator field of 0 and 19 elements; the binary subtype and the
    # decimal128 raw value are part of the element entries.
    assert res.returncode == 0
    assert res.stdout == b"[271,0,19]\n"
    assert res.stderr == b""


def test_bson_binary_and_decimal128(tmp_path):
    """Binary elements keep subtype and raw bytes; decimal128 stays raw."""
    path = write_b64(tmp_path, "types.bson", BSON_TYPES)
    res = run_fq(["-d", "bson", "-V", "-c", ".elements[4]"], path)
    # CATCHES: binary is decoded as length + subtype (kept as a plain
    # number, here 0x80=128) + raw value bytes; decimal128 is NOT parsed
    # as a float but kept as 16 raw bytes.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"length":3,"name":"bin","subtype":128,"type":"binary","value":"ABC"}\n'
    )
    res_dec = run_fq(["-d", "bson", "-V", "-c", ".elements[16]"], path)
    assert res_dec.returncode == 0
    assert res_dec.stdout == (
        b'{"name":"dec128","type":"decimal128","value":'
        b'"\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005\\u0006\\u0007\\b\\t\\n'
        b'\\u000b\\f\\r\\u000e\\u000f"}\n'
    )
    assert res_dec.stderr == b""


def test_bson_nested_document_and_array(tmp_path):
    """Embedded documents and arrays are recursive BSON documents."""
    path = write_b64(tmp_path, "types.bson", BSON_TYPES)
    res = run_fq(["-d", "bson", "-V", "-c", ".elements[2].value"], path)
    # CATCHES: an embedded document is a full sub-document with its own
    # size/elements/terminator, not a flattened set of fields.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"elements":[{"name":"nint","type":"int32","value":-42}],'
        b'"size":15,"terminator":0}\n'
    )
    assert res.stderr == b""

    res_arr = run_fq(["-d", "bson", "-V", "-c", ".elements[3].value"], path)
    # CATCHES: arrays are documents whose element names are the index
    # strings ("0","1") and whose type symbol is "array".
    assert res_arr.returncode == 0
    assert res_arr.stdout == (
        b'{"elements":[{"name":"0","type":"int64","value":1099511627776},'
        b'{"name":"1","type":"int32","value":7}],"size":23,"terminator":0}\n'
    )
    assert res_arr.stderr == b""


def test_bson_torepr(tmp_path):
    """torepr flattens the tree into plain jq values."""
    path = write_b64(tmp_path, "types.bson", BSON_TYPES)
    res = run_fq(["-d", "bson", "-c", "torepr"], path)
    # CATCHES: torepr maps elements to object entries, arrays to plain
    # arrays, booleans to real booleans (value != 0), undefined/minkey/
    # maxkey to null, and keeps binary/object id/decimal128 as raw
    # byte strings.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"arr":[1099511627776,7],"bfalse":false,"bin":"ABC","btrue":true,'
        b'"date":1234567890123,'
        b'"dec128":"\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005\\u0006\\u0007'
        b'\\b\\t\\n\\u000b\\f\\r\\u000e\\u000f","doc":{"nint":-42},'
        b'"double":98.765,"i32":-2147483648,"i64":-9223372036854775808,'
        b'"js":"print(1)","maxkey":null,"minkey":null,"null":null,'
        b'"oid":"\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005\\u0006\\u0007\\b'
        b'\\t\\n\\u000b","re":"p.*ttern","str":"my string",'
        b'"ts":244837814094590,"undef":null}\n'
    )
    assert res.stderr == b""


def test_bson_display_descriptions(tmp_path):
    """The verbose display annotates types with their spec descriptions."""
    path = write_b64(tmp_path, "disp.bson", BSON_DISP)
    res = run_fq(["-d", "bson", "-c", "d"], path)
    # CATCHES: each type byte renders as symbol + number + description,
    # the binary subtype is a bare number and the terminator shows a
    # "(valid)" suffix when it is zero.
    assert res.returncode == 0
    assert b'type: "double" (1) (64-bit binary floating point)' in res.stdout
    assert b'type: "binary" (5) (Binary data)' in res.stdout
    assert b"|      subtype: 128" in res.stdout
    assert b'type: "object_id" (7) (ObjectId)' in res.stdout
    assert b'type: "datetime" (9) (UTC datetime)' in res.stdout
    assert (
        b'type: "decimal128" (19) (128-bit decimal floating point)' in res.stdout
    )
    assert b'type: "minkey" (255) (Min key)' in res.stdout
    assert b'type: "maxkey" (127) (Max key)' in res.stdout
    assert b"terminator: 0 (valid)" in res.stdout
    assert res.stderr == b""


def test_bson_empty_document(tmp_path):
    """An empty document has no elements and a zero terminator."""
    path = write_b64(tmp_path, "empty.bson", BSON_EMPTY)
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: the minimal document is size 5 with an empty elements array
    # and terminator 0; torepr of it is the empty object.
    assert res.returncode == 0
    assert res.stdout == b'{"elements":[],"size":5,"terminator":0}\n'
    assert res.stderr == b""

    res_t = run_fq(["-d", "bson", "-c", "torepr"], path)
    assert res_t.returncode == 0
    assert res_t.stdout == b"{}\n"


def test_bson_invalid_terminator(tmp_path):
    """A non-zero terminator decodes to 1 and is only flagged in display."""
    path = write_b64(tmp_path, "badterm.bson", BSON_BADTERM)
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: the terminator UintValidate does not abort the decode — the
    # JSON tree keeps terminator 1 and the display marks it "(invalid)".
    assert res.returncode == 0
    assert res.stdout == b'{"elements":[],"size":5,"terminator":1}\n'
    assert res.stderr == b""

    res_d = run_fq(["-d", "bson", "-c", "."], path)
    assert res_d.returncode == 0
    assert b"terminator: 1 (invalid)" in res_d.stdout
    assert res_d.stderr == b""


@pytest.mark.parametrize(
    "fixture,tree,errline",
    [
        (
            "bigsize.bson",
            BSON_BIGSIZE,
            b"error: bson: BitBufRange: failed at position 0 "
            b"(read size 100 seek pos 0): outside buffer\n",
        ),
        (
            "smallsize.bson",
            BSON_SMALLSIZE,
            b"error: bson: error at position 0x4: -8 nBits < 0\n",
        ),
    ],
)
def test_bson_bad_document_sizes(tmp_path, fixture, tree, errline):
    """Documents with impossible size fields decode partially with errors."""
    path = write_b64(tmp_path, fixture, tree)
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: a size larger than the buffer fails the framed read (leaving
    # only the size field) while a size below 5 fails with a negative
    # nBits error; both still exit 0.
    assert res.returncode == 0
    assert res.stderr == b""

    res_d = run_fq(["-d", "bson", "-c", "."], path)
    assert res_d.returncode == 0
    assert errline in res_d.stdout
    assert res_d.stderr == b""


def test_bson_bigsize_tree(tmp_path):
    """A too-large size leaves just the size field and a gap."""
    path = write_b64(tmp_path, "bigsize.bson", BSON_BIGSIZE)
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: the framed read of (size-4) bytes fails, so no elements are
    # decoded and the trailing byte surfaces as gap0.
    assert res.returncode == 0
    assert res.stdout == b'{"gap0":"\\u0000","size":100}\n'
    assert res.stderr == b""


def test_bson_smallsize_tree(tmp_path):
    """A size below 5 leaves the remaining bytes as a gap."""
    path = write_b64(tmp_path, "smallsize.bson", BSON_SMALLSIZE)
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: size 3 makes the frame negative; the two leftover bytes
    # become gap0 instead of raising a process-level failure.
    assert res.returncode == 0
    assert res.stdout == b'{"gap0":"\\u0000\\u0000","size":3}\n'
    assert res.stderr == b""


def test_bson_truncated_string(tmp_path):
    """A string element claiming more bytes than remain stops the decode."""
    path = write_b64(tmp_path, "badstr.bson", BSON_BADSTR)
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: the element is decoded up to its name and length; the value
    # read fails and the leftover bytes ("ab" + terminator) are gap0.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"elements":[{"length":50,"name":"s","type":"string"}],'
        b'"gap0":"ab\\u0000\\u0000","size":15}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "bson", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: bson: UTF8NullFixedLen(value): failed at position 11 "
        b"(read size 0 seek pos 0): tryTextNullLen fixedBytes 50 outside, "
        b"4 bytes left\n" in res_d.stdout
    )


def test_bson_negative_binary_length(tmp_path):
    """A negative binary length fails the raw read with negative nBits."""
    path = write_b64(tmp_path, "negbin.bson", BSON_NEGBIN)
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: the binary length is a signed S32, so -1 is decoded and
    # only the RawLen of -8 bits fails, leaving the value bytes as gap0.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"elements":[{"length":-1,"name":"b","subtype":0,"type":"binary"}],'
        b'"gap0":"AB\\u0000","size":15}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "bson", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: bson: RawLen(value): failed at position 12 "
        b"(read size 0 seek pos 0): negative nBits\n" in res_d.stdout
    )


def test_bson_unknown_element_type(tmp_path):
    """An unknown element type swallows the rest of the document as value."""
    path = write_b64(tmp_path, "unknown.bson", BSON_UNKNOWN)
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: the default branch reads all remaining bits (including the
    # terminator) as the value, so the type stays a raw number 66 and the
    # document itself is left without a terminator field.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"elements":[{"name":"unknown","type":66,'
        b'"value":"\\u0005\\u0000\\u0000\\u0000junk\\u0000"}],"size":22}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "bson", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: bson: U8(terminator): failed at position 22 "
        b"(read size 0 seek pos 0): EOF\n" in res_d.stdout
    )

    res_t = run_fq(["-d", "bson", "-c", "torepr"], path)
    assert res_t.returncode == 0
    assert res_t.stdout == b'{"unknown":"\\u0005\\u0000\\u0000\\u0000junk\\u0000"}\n'


def test_bson_empty_input(tmp_path):
    """Zero-length input fails the size read but still exits 0."""
    path = write_b64(tmp_path, "empty2.bson", b"")
    res = run_fq(["-d", "bson", "-V", "-c", "."], path)
    # CATCHES: an empty buffer decodes to an empty object value; the
    # display output carries the EOF error of the S32 size read.
    assert res.returncode == 0
    assert res.stdout == b"{}\n"
    assert res.stderr == b""

    res_d = run_fq(["-d", "bson", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: bson: S32(size): failed at position 0 "
        b"(read size 0 seek pos 0): EOF\n" in res_d.stdout
    )


def test_bson_subvalue_decode(tmp_path):
    """An embedded document value can be piped back into the bson decoder."""
    path = write_b64(tmp_path, "types.bson", BSON_TYPES)
    res = run_fq(["-d", "bson", "-c", ".elements[2].value | bson | torepr"], path)
    # CATCHES: the pipe form re-decodes a sub-document value, yielding the
    # same represented object as the nested decode.
    assert res.returncode == 0
    assert res.stdout == b'{"nint":-42}\n'
    assert res.stderr == b""

    # a string value is decoded via its UTF-8 bytes: "my string" starts
    # with 'm','y',' ','s' which little-endian is a huge size.
    res_str = run_fq(
        ["-d", "bson", "-V", "-c", ".elements[1].value | bson | .size"], path
    )
    assert res_str.returncode == 0
    assert res_str.stdout == b"1931508077\n"


def test_bson_is_not_probed(tmp_path):
    """bson has no probe group; auto-detection of a bson file fails."""
    path = write_b64(tmp_path, "not_detected.bson", BSON_TYPES)
    res = run_fq(["-c", "format"], path)
    # CATCHES: probing never picks bson even for a valid document, so the
    # run fails with the generic probe error and exit code 4 (the filename
    # appears as passed on the command line).
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr == (
        f"error: {path}: probe: failed to decode: "
        f"try fq -d FORMAT to force format, see fq -h formats for list\n"
    ).encode()
