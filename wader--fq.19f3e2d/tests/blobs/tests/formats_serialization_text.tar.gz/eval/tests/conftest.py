"""Shared harness for the ``formats_serialization_text`` module tests.

Every test drives the candidate through ``PROGRAMGYM_EXECUTABLE`` (never a
hard-coded path).  The main helper is ``run_fq``, which takes a raw argument
vector plus optional stdin (str or bytes) and returns the completed process
with byte-exact stdout/stderr so recorded expectations can be asserted
verbatim.

The child environment is fully pinned (``LANG``/``LC_ALL`` = C, an explicit
PATH, HOME pointing at a directory that does not exist) so no ambient locale,
color or fq config can leak in.  Binary fixtures are embedded in the test
files as base64 and materialised inside ``tmp_path`` via ``write_file``, which
keeps every test hermetic (no reads outside the temporary directory).
"""

from __future__ import annotations

import base64
import os
import pathlib
import subprocess

# The pinned child environment: no inherited locale, color, unicode or config
# from the test runner.  HOME and XDG_CONFIG_HOME point at directories that
# do not exist so no fq config init.jq is picked up unless a test installs one
# on purpose.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "xterm",
    "NO_COLOR": "",
    "XDG_CONFIG_HOME": "/nonexistent",
}


def executable_path() -> str:
    """Return the candidate path from PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE", "")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE is not set; the suite cannot drive the candidate"
        )
    return path


def child_env(env=None) -> dict:
    """The pinned child environment plus per-test overrides.

    A ``None`` value removes the variable from the child environment; every
    other value overrides (or adds) it.  GOCOVERDIR is forwarded from the
    test process at call time so the pipeline can measure the source
    coverage of an instrumented reference binary.
    """
    merged = dict(CHILD_ENV)
    for key, value in (env or {}).items():
        if value is None:
            merged.pop(key, None)
        else:
            merged[key] = value
    cov_env = {"GOCOVERDIR": v for v in [os.environ.get("GOCOVERDIR")] if v}
    merged.update(cov_env)
    return merged


def run_fq(argv, path=None, *, stdin="", cwd=None, env=None, timeout=30):
    """Run the candidate with a raw argument vector, return the process.

    stdin may be str or bytes; stdout/stderr are always bytes so that exact
    recorded byte expectations can be asserted.  PATH, when given, is appended
    to the argument vector as the input file (fq reads it instead of stdin).
    """
    args = list(argv)
    if path is not None:
        args.append(path)
    data = stdin if isinstance(stdin, bytes) else stdin.encode()
    return subprocess.run(
        [executable_path()] + args,
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env=child_env(env),
        timeout=timeout,
    )


def write_file(directory, name, content):
    """Write CONTENT to DIRECTORY/NAME and return the path as a str.

    CONTENT may be str (written as UTF-8) or bytes.
    """
    path = pathlib.Path(directory) / name
    if isinstance(content, bytes):
        path.write_bytes(content)
    else:
        path.write_text(content, encoding="utf-8")
    return str(path)


def write_b64(directory, name, b64):
    """Materialise B64 into DIRECTORY/NAME and return the path as a str.

    B64 may be a base64 string or already-decoded bytes (fixtures built at
    module level with ``base64.b64decode`` pass the decoded form).  Used to
    materialise the embedded binary fixtures (msgpack, cbor, bson, bencode,
    avro, safetensors, protobuf, asn1 and bplist samples) inside tmp_path so
    tests never read outside their temporary directory.
    """
    if isinstance(b64, bytes):
        return write_file(directory, name, b64)
    return write_file(directory, name, base64.b64decode(b64))


def out_text(proc):
    """The stdout of a completed process decoded as UTF-8 text."""
    return proc.stdout.decode("utf-8")
