"""HTML decoding via the html option family.

The html parser always produces a tree, so probing only accepts input that
starts with <html or <!DOCTYPE html (within the first 64 bytes); anything
else must be forced with ``-d html``.  Covers the implied html/head/body
skeleton, tag auto-closing and lowercasing, attribute prefixing, the seq
and array options, entity decoding and script text handling.
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize(
    "text,expected",
    [
        ("<p>hi", b'{"html":{"body":{"p":"hi"},"head":""}}\n'),
        ("<br>", b'{"html":{"body":{"br":""},"head":""}}\n'),
        ('<p class="x" id="y">t</p>',
         b'{"html":{"body":{"p":{"#text":"t","@class":"x","@id":"y"}},"head":""}}\n'),
        ("<HTML><BODY><P>x</P></BODY></HTML>",
         b'{"html":{"body":{"p":"x"},"head":""}}\n'),
        ("<html><body>a &amp; b</body></html>",
         b'{"html":{"body":"a & b","head":""}}\n'),
        ("<!DOCTYPE html><html><body><p>a</p></body></html>",
         b'{"html":{"body":{"p":"a"},"head":""}}\n'),
        ("<!-- c --><html><body></body></html>",
         b'{"#comment":"c","html":{"body":"","head":""}}\n'),
        ("<html><body>x<br/>y</body></html>",
         b'{"html":{"body":{"#text":"xy","br":""},"head":""}}\n'),
        ("<html><body><div>a<div>b</div>c</div></body></html>",
         b'{"html":{"body":{"div":{"#text":"ac","div":"b"}},"head":""}}\n'),
        ("<html><body>&lt;script&gt;</body></html>",
         b'{"html":{"body":"<script>","head":""}}\n'),
        ("<html><body><script>var x = 1;</script></body></html>",
         b'{"html":{"body":{"script":"var x = 1;"},"head":""}}\n'),
    ],
)
def test_html_object_mode(text, expected):
    """The html object mapping with the implied document skeleton."""
    res = run_fq(["-d", "html", "-c", "."], stdin=text)
    # CATCHES: a bare fragment is wrapped in html/head/body (head empty),
    # tags are lowercased, void elements like br contribute no text,
    # sibling text around elements is concatenated into #text and entities
    # are decoded; a comment before the root becomes a top-level #comment
    # key next to html.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_html_auto_closing_repeats():
    """Unclosed block elements auto-close and repeat as arrays."""
    res = run_fq(["-d", "html", "-c", "."],
                 stdin="<html><body><p>a<p>b</body></html>")
    # CATCHES: html5 tree building closes the first <p> when the second
    # opens, so both appear as siblings collected into an array.
    assert res.returncode == 0
    assert res.stdout == b'{"html":{"body":{"p":["a","b"]},"head":""}}\n'


def test_html_seq_option():
    """seq=true numbers element siblings, including implied ones."""
    res = run_fq(["-d", "html", "-c", ".", "-o", "seq=true"],
                 stdin="<html><body><p>a<p>b</body></html>")
    # CATCHES: the implied head/body pair is numbered too (head 0, body 1)
    # and both p elements get their index among body's element children.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"html":{"body":{"#seq":1,"p":[{"#seq":0,"#text":"a"},'
        b'{"#seq":1,"#text":"b"}]},"head":{"#seq":0}}}\n'
    )


def test_html_array_mode():
    """array=true gives the [name, attrs, children] tree from html."""
    res = run_fq(["-d", "html", "-c", ".", "-o", "array=true"],
                 stdin='<html><body><p class="c">a<p>b</body></html>')
    # CATCHES: array mode finds the first element node (skipping doctype)
    # and writes attribute keys without the @ prefix.
    assert res.returncode == 0
    assert res.stdout == (
        b'["html",null,[["head",null,[]],["body",null,'
        b'[["p",{"#text":"a","class":"c"},[]],["p",{"#text":"b"},[]]]]]]\n'
    )


def test_html_attribute_prefix_option():
    """attribute_prefix is configurable for html as well."""
    res = run_fq(["-d", "html", "-c", ".", "-o", "attribute_prefix=."],
                 stdin='<p class="x">t</p>')
    # CATCHES: the option is shared with the xml decoder; here attributes
    # appear with a dot prefix.
    assert res.returncode == 0
    assert res.stdout == b'{"html":{"body":{"p":{"#text":"t",".class":"x"}},"head":""}}\n'


@pytest.mark.parametrize(
    "text,fmt",
    [
        (b"<html><body></body></html>", b'"html"\n'),
        (b"<html><body><p>a<p>b</body></html>", b'"html"\n'),
        (b"<!DOCTYPE html><html><body></body></html>", b'"html"\n'),
        (b"<a/>", b'"xml"\n'),
    ],
)
def test_html_probe_needs_html_magic(text, fmt):
    """Probing only picks html when the magic regex matches."""
    res = run_fq(["-c", "format"], stdin=text)
    # CATCHES: the html parser never fails, so the probe requires <html or
    # <!DOCTYPE html near the start (case insensitive); well-formed XML
    # without them stays xml.
    assert res.returncode == 0
    assert res.stdout == fmt
    assert res.stderr == b""


@pytest.mark.parametrize("text", [b"<p>hi", b"<br>", b"garbage <"])
def test_html_fragment_is_not_probed(text):
    """Fragments without the html magic fail probing."""
    res = run_fq(["-c", "format"], stdin=text)
    # CATCHES: even though the html parser would happily build a tree, the
    # probe rejects fragments, so unforced runs exit 4.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.startswith(b"error: <stdin>: probe: failed to decode:")


def test_html_forced_always_parses():
    """Forced -d html parses anything, reporting format html."""
    res = run_fq(["-c", "-d", "html", "format"], stdin=b"garbage <")
    # CATCHES: with -d html the magic check is skipped entirely and the
    # format builtin reports the forced format.
    assert res.returncode == 0
    assert res.stdout == b'"html"\n'
