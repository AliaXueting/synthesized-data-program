"""BitTorrent bencoding decoding and the torepr conversion.

Covers ``-d bencode`` for every value family (integers, strings, lists,
dictionaries and nesting), the jq tree shape (``type``/``length``/
``separator``/``pairs``/``values``/``end``), ``torepr`` turning that tree
back into plain jq values, malformed input behaviour (truncated integers and
strings surface as ``gap0`` plus an error line in the display output while
the process still exits 0), integer-key dictionaries that decode fine but
make ``torepr`` fail at the jq level, and that bencode is never auto-probed.
"""

from __future__ import annotations

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize(
    "data,expected",
    [
        (b"i42e", "42"),
        (b"i0e", "0"),
        (b"i-3e", "-3"),
        (b"i+3e", "3"),
        (b"i00e", "0"),
        (b"i9223372036854775807e", "9223372036854775807"),
    ],
)
def test_bencode_integers(data, expected):
    """Integers decode through torepr, including odd Go-ParseInt spellings."""
    res = run_fq(["-d", "bencode", "-c", "torepr"], stdin=data)
    # CATCHES: the integer text is parsed with Go strconv rules, so a plus
    # sign and leading zeros are accepted and the full int64 range works.
    assert res.returncode == 0
    assert res.stdout == f"{expected}\n".encode()
    assert res.stderr == b""


@pytest.mark.parametrize(
    "data,expected",
    [
        (b"5:hello", '"hello"'),
        (b"0:", '""'),
        (b"13:hello, world!", '"hello, world!"'),
    ],
)
def test_bencode_strings(data, expected):
    """Length-prefixed strings decode to plain jq strings via torepr."""
    res = run_fq(["-d", "bencode", "-c", "torepr"], stdin=data)
    # CATCHES: the "<length>:" prefix is consumed and the exact byte count
    # becomes the string value; zero-length strings decode to "".
    assert res.returncode == 0
    assert res.stdout == f"{expected}\n".encode()
    assert res.stderr == b""


def test_bencode_string_tree_shape():
    """A string keeps type/length/separator/value fields in the raw tree."""
    res = run_fq(["-d", "bencode", "-V", "-c", "."], stdin=b"5:hello")
    # CATCHES: the raw value is a struct with the symbol "string" (from the
    # leading digit byte) plus length, the ":" separator field and the value.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"length":5,"separator":":","type":"string","value":"hello"}\n'
    )
    assert res.stderr == b""


def test_bencode_containers():
    """Empty lists and dictionaries decode to [] and {}."""
    res_l = run_fq(["-d", "bencode", "-c", "torepr"], stdin=b"le")
    # CATCHES: "le"/"de" are valid empty containers; the terminating "e" is
    # part of the encoding and does not show up in the represented value.
    assert res_l.returncode == 0
    assert res_l.stdout == b"[]\n"

    res_d = run_fq(["-d", "bencode", "-c", "torepr"], stdin=b"de")
    assert res_d.returncode == 0
    assert res_d.stdout == b"{}\n"
    assert res_d.stderr == b""


def test_bencode_nested_tree_shape():
    """A dict of int and list values keeps the full pair/value structure."""
    res = run_fq(["-d", "bencode", "-V", "-c", "."], stdin=b"d1:ai7e1:bli1ei2eee")
    # CATCHES: dictionaries decode as pairs of key/value structs and lists
    # as a values array; every scalar carries its own end:"e" marker.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"end":"e","pairs":['
        b'{"key":{"length":1,"separator":":","type":"string","value":"a"},'
        b'"value":{"end":"e","type":"integer","value":7}},'
        b'{"key":{"length":1,"separator":":","type":"string","value":"b"},'
        b'"value":{"end":"e","type":"list","values":['
        b'{"end":"e","type":"integer","value":1},'
        b'{"end":"e","type":"integer","value":2}]}}],"type":"dictionary"}\n'
    )
    assert res.stderr == b""


def test_bencode_nested_torepr():
    """torepr rebuilds nested dicts and lists into plain jq values."""
    res = run_fq(["-d", "bencode", "-c", "torepr"], stdin=b"d1:ai7e1:bli1ei2eee")
    # CATCHES: torepr maps pairs through from_entries and values through a
    # recursive list mapping, so nested containers round-trip to plain jq.
    assert res.returncode == 0
    assert res.stdout == b'{"a":7,"b":[1,2]}\n'
    assert res.stderr == b""


def test_bencode_display_tree():
    """The verbose display shows every field with symbol annotations."""
    res = run_fq(["-d", "bencode", "-c", "d"], stdin=b"d1:ai7e1:bli1ei2eee")
    # CATCHES: the display renders type bytes with their mapped symbol
    # ("dictionary"/"string"/"integer"/"list") and the ":"/"e" markers with
    # a "(valid)" suffix from the StrAssert checks.
    assert res.returncode == 0
    assert b'type: "dictionary" ("d")' in res.stdout
    assert b'type: "string" ("1")' in res.stdout
    assert b'separator: ":" (valid)' in res.stdout
    assert b'type: "integer" ("i")' in res.stdout
    assert b'end: "e" (valid)' in res.stdout
    assert b'type: "list" ("l")' in res.stdout
    assert res.stderr == b""


@pytest.mark.parametrize(
    "data,tree",
    [
        (b"i42", '{"gap0":"42","type":"integer"}'),
        (b"ie", '{"gap0":"e","type":"integer"}'),
        (b"5hell", '{"gap0":"hell","type":"string"}'),
        (b"999:abc", '{"gap0":"abc","length":999,"separator":":","type":"string"}'),
        (
            b"i1234567890123456789012345e",
            '{"gap0":"1234567890123456789012345e","type":"integer"}',
        ),
        (
            b"i9223372036854775808e",
            '{"gap0":"9223372036854775808e","type":"integer"}',
        ),
        (b"x", '{"type":"x"}'),
    ],
)
def test_bencode_decode_errors_keep_gap(data, tree):
    """Malformed values leave the unconsumed bytes as gap0 and exit 0."""
    res = run_fq(["-d", "bencode", "-V", "-c", "."], stdin=data)
    # CATCHES: truncated integers/strings, int64 overflow, integers longer
    # than the 21-byte scan window and unknown type bytes all stop decoding
    # and surface the leftover bytes as "gap0" rather than failing the run.
    assert res.returncode == 0
    assert res.stdout == f"{tree}\n".encode()
    assert res.stderr == b""


def test_bencode_display_error_lines():
    """Decode errors are reported as error lines inside the display output."""
    res = run_fq(["-d", "bencode", "-c", "."], stdin=b"x")
    # CATCHES: the unknown type byte produces an "error: bencode: ..." line
    # in the display output while the process still exits 0 with empty
    # stderr — decode errors are part of the value tree, not failures.
    assert res.returncode == 0
    assert b"error: bencode: error at position 0x1: unknown type x\n" in res.stdout
    assert b'type: "x"' in res.stdout
    assert res.stderr == b""

    res_t = run_fq(["-d", "bencode", "-c", "."], stdin=b"i42")
    assert res_t.returncode == 0
    assert (
        b"error: bencode: PeekFindByte: failed at position 1 "
        b"(read size 0 seek pos 0): EOF\n" in res_t.stdout
    )
    assert res_t.stderr == b""


def test_bencode_empty_input():
    """Empty input fails the type byte read but still exits 0 with a tree."""
    res = run_fq(["-d", "bencode", "-V", "-c", "."], stdin=b"")
    # CATCHES: zero bytes decode to an empty object value (no fields at
    # all), the display carries the EOF error and torepr fails at the jq
    # level because the missing type is null.
    assert res.returncode == 0
    assert res.stdout == b"{}\n"
    assert res.stderr == b""

    res_d = run_fq(["-d", "bencode", "-c", "."], stdin=b"")
    assert res_d.returncode == 0
    assert (
        b"error: bencode: UTF8(type): failed at position 0 "
        b"(read size 0 seek pos 0): tryText nBytes 1 outside buffer, "
        b"0 bytes left\n" in res_d.stdout
    )

    res_t = run_fq(["-d", "bencode", "-c", "torepr"], stdin=b"")
    assert res_t.returncode == 5
    assert res_t.stdout == b""
    assert res_t.stderr == b"error: <stdin>: unknown type null\n"


def test_bencode_trailing_data_becomes_gap():
    """Only the first top-level value is decoded; the rest is a gap."""
    res = run_fq(["-d", "bencode", "-V", "-c", "."], stdin=b"i1ei2e")
    # CATCHES: bencodeDecode decodes exactly one value; a second value in
    # the same input is not an error but lands in "gap0".
    assert res.returncode == 0
    assert res.stdout == b'{"end":"e","gap0":"i2e","type":"integer","value":1}\n'
    assert res.stderr == b""


def test_bencode_leading_zero_length():
    """A string length with a leading zero only consumes that many bytes."""
    res = run_fq(["-d", "bencode", "-V", "-c", "."], stdin=b"01:ab")
    # CATCHES: the length text "01" parses as 1, so only "a" becomes the
    # value and the leftover "b" is a gap — leading zeros are not rejected.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"b","length":1,"separator":":","type":"string","value":"a"}\n'
    )
    assert res.stderr == b""


def test_bencode_duplicate_keys_last_wins():
    """torepr of a dictionary with duplicate keys keeps the last value."""
    res = run_fq(["-d", "bencode", "-c", "torepr"], stdin=b"d1:ai11e1:ai22ee")
    # CATCHES: from_entries in the torepr conversion silently keeps the
    # last entry for duplicated keys ({"a":22}, not an error).
    assert res.returncode == 0
    assert res.stdout == b'{"a":22}\n'
    assert res.stderr == b""


def test_bencode_integer_key_torepr_error():
    """A dictionary with an integer key decodes but torepr fails at jq level."""
    res_tree = run_fq(["-d", "bencode", "-V", "-c", "."], stdin=b"di1ei2ee")
    # CATCHES: the decoder itself accepts non-string keys (the pair keeps
    # the integer key struct), but from_entries then rejects the number
    # key, which is a jq runtime error with exit code 5 on stderr.
    assert res_tree.returncode == 0
    assert res_tree.stdout == (
        b'{"end":"e","pairs":[{"key":{"end":"e","type":"integer","value":1},'
        b'"value":{"end":"e","type":"integer","value":2}}],"type":"dictionary"}\n'
    )
    assert res_tree.stderr == b""

    res = run_fq(["-d", "bencode", "-c", "torepr"], stdin=b"di1ei2ee")
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        b"error: <stdin>: expected a string for object key but got: number (1)\n"
    )


def test_bencode_subvalue_decode():
    """A decoded string value can be piped back into the bencode decoder."""
    res = run_fq(
        ["-d", "bencode", "-c", ".value | bencode | torepr"], stdin=b"9:li1ei2eee"
    )
    # CATCHES: the pipe form re-decodes a value's bytes as bencode, so a
    # string holding "li1ei2eee" becomes the list [1,2].
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n"
    assert res.stderr == b""


def test_bencode_is_not_probed(tmp_path):
    """bencode has no probe group; auto-detection of a torrent fails."""
    path = write_file(tmp_path, "not_detected.torrent", b"d4:infod4:name4:testee")
    res = run_fq(["-c", "format"], stdin=b"i42e")
    # CATCHES: probing never picks bencode, so even a valid dictionary
    # fails with the generic probe error and exit code 4.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr == (
        b"error: <stdin>: probe: failed to decode: "
        b"try fq -d FORMAT to force format, see fq -h formats for list\n"
    )

    res_file = run_fq(["-c", "format"], path)
    assert res_file.returncode == 4
    assert b"probe: failed to decode" in res_file.stderr
