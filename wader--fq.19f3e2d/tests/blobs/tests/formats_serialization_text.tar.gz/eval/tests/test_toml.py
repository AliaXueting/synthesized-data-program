"""TOML decoding and the to_toml encoder.

Covers ``-d toml`` of tables, dotted keys, arrays and multi-line strings
(including datetimes decoding to null), the duplicate key decode failure,
and ``to_toml`` table layout: top-level scalars first, then one [table]
header per nested object with the indent option controlling their body.
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize(
    "text,expected",
    [
        ("a = 1\n", b'{"a":1}\n'),
        ('[a]\nb = "x"\n', b'{"a":{"b":"x"}}\n'),
        ("a = 1\nb = [1, 2]\n[c]\nd = \"s\"\n", b'{"a":1,"b":[1,2],"c":{"d":"s"}}\n'),
        ("[ a . b ]\nc = 1\n", b'{"a":{"b":{"c":1}}}\n'),
        ("a.b = 1\n", b'{"a":{"b":1}}\n'),
        ('a = [1, "two", true]\n', b'{"a":[1,"two",true]}\n'),
        ('x = """multi\nline"""\n', b'{"x":"multi\\nline"}\n'),
        ("a = 1979-05-27T07:32:00Z\n", b'{"a":null}\n'),
        ("a = 1979-05-27\n", b'{"a":null}\n'),
    ],
)
def test_toml_decode_values(text, expected):
    """-d toml turns TOML documents into jq values."""
    res = run_fq(["-d", "toml", "-c", "."], stdin=text)
    # CATCHES: dotted keys and dotted table headers nest, multi-line basic
    # strings keep their inner newline and date(time) values decode to null
    # because there is no jq date value.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_toml_duplicate_key_decode_error():
    """Redefining a key fails the forced decode but exits 0."""
    res = run_fq(["-d", "toml", "-c", "."], stdin='a = "x"\na = "y"\n')
    # CATCHES: the toml decoder rejects duplicate keys; the error is shown
    # inside the hexdump display on stdout with the go-toml wording and the
    # process still exits 0 because the format was forced with -d.
    assert res.returncode == 0
    assert res.stdout == (
        b"    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        b"|0123456789abcdef|.{}: <stdin> (toml)\n"
        b"    |                                               |              "
        b"  |  error: toml: error at position 0x10: toml: line 2 (last key "
        b"\"a\"): Key 'a' has already been defined.\n"
        b"0x00|61 20 3d 20 22 78 22 0a 61 20 3d 20 22 79 22 0a"
        b"|a = \"x\".a = \"y\".|  gap0: raw bits\n"
    )
    assert res.stderr == b""


def test_to_toml_layout():
    """to_toml emits scalars first, then table sections."""
    res = run_fq(["-n", "-c", "{a:1,b:[2,3],c:{d:\"s\"}} | to_toml"])
    # CATCHES: keys are sorted, arrays are inline with ", " separators and
    # nested objects move below a blank line under a [table] header with a
    # two space body indent.
    assert res.returncode == 0
    assert res.stdout == b'"a = 1\\nb = [2, 3]\\n\\n[c]\\n  d = \\"s\\"\\n"\n'


def test_to_toml_indent_option():
    """The indent option sets the table body indentation."""
    res4 = run_fq(["-n", "-c", "{a: 1, b: {c: 2}} | to_toml({indent: 4})"])
    res0 = run_fq(["-n", "-c", "{a: {b: {c: 1}}} | to_toml({indent: 0})"])
    # CATCHES: indent:4 indents table bodies four spaces, and indent:0
    # collapses deep objects into chained dotted headers [a] then [a.b]
    # with no body indentation.
    assert res4.returncode == 0
    assert res4.stdout == b'"a = 1\\n\\n[b]\\n    c = 2\\n"\n'
    assert res0.returncode == 0
    assert res0.stdout == b'"[a]\\n[a.b]\\nc = 1\\n"\n'


def test_to_toml_inline_values():
    """Arrays and inline tables stay on the value line."""
    res = run_fq(
        ["-n", "-c", "{a: [[1,2],[3]], b: [1, {c: 2}], t: true, f: 1.5} | to_toml"]
    )
    # CATCHES: nested arrays and arrays holding objects are rendered inline
    # (the object using TOML inline-table {c = 2} syntax) instead of nested
    # tables, and booleans/floats print bare.
    assert res.returncode == 0
    assert res.stdout == (
        b'"a = [[1, 2], [3]]\\nb = [1, {c = 2}]\\nf = 1.5\\nt = true\\n"\n'
    )


def test_to_toml_scalar_passthrough_and_errors():
    """Non-object inputs pass through as literals except null."""
    res_num = run_fq(["-n", "-c", "1 | to_toml"])
    res_arr = run_fq(["-n", "-c", "[1] | to_toml"])
    # CATCHES: scalars and arrays encode as bare literals without a trailing
    # newline (only object documents get one).
    assert res_num.returncode == 0
    assert res_num.stdout == b'"1"\n'
    assert res_arr.returncode == 0
    assert res_arr.stdout == b'"[1]"\n'

    res_null = run_fq(["-n", "-c", "null | to_toml"])
    # CATCHES: null input is a type error, not the empty document.
    assert res_null.returncode == 5
    assert res_null.stderr == b"error: to_toml cannot be applied to: null\n"

    res_nullval = run_fq(["-n", "-c", "{a: null} | to_toml"])
    # CATCHES: a null value silently drops its key, producing the empty
    # document.
    assert res_nullval.returncode == 0
    assert res_nullval.stdout == b'""\n'


def test_toml_is_probed():
    """TOML documents are detected by probing."""
    res = run_fq(["-c", "format"], stdin=b"a = 1\nb = 2\n")
    # CATCHES: toml belongs to the fuzzy text probe group, so an unforced
    # run decodes it without -d.
    assert res.returncode == 0
    assert res.stdout == b'"toml"\n'
    assert res.stderr == b""
