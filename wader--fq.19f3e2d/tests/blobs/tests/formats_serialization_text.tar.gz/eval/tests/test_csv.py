"""CSV decoding and the to_csv encoder.

Covers ``-d csv`` rows as arrays of strings, the comma and comment options,
Go's csv reader quirks exposed by the decoder (leading space trimming, lazy
quotes, CRLF, quoted newlines), the ragged-row fallback, and ``to_csv``
quoting/escaping plus its two type errors.
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize(
    "text,expected",
    [
        ("a,b\n1,2\nx,y\n", b'[["a","b"],["1","2"],["x","y"]]\n'),
        ("1\n", b'[["1"]]\n'),
        ("a,b\r\n1,2\r\n", b'[["a","b"],["1","2"]]\n'),
        ('a,"b,\nc"\n1,2\n', b'[["a","b,\\nc"],["1","2"]]\n'),
        ("a, b ,c\n", b'[["a","b ","c"]]\n'),
        ('a,"b\n', b'[["a","b\\n"]]\n'),
        ("# c\na,b\n", b'[["a","b"]]\n'),
    ],
)
def test_csv_decode_rows(text, expected):
    """-d csv decodes every record into an array of strings."""
    res = run_fq(["-d", "csv", "-c", "."], stdin=text)
    # CATCHES: fields are always strings (no number coercion), leading
    # spaces are trimmed but trailing ones kept, CRLF is a record separator,
    # quoted fields may contain commas and newlines, a lone quote is
    # tolerated (lazy quotes) and comment lines are skipped.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_csv_comma_and_comment_options():
    """The comma and comment options reconfigure the reader."""
    res_c = run_fq(["-d", "csv", "-c", ".", "-o", "comma=;"], stdin="a;b\n1;2\n")
    # CATCHES: comma=; splits on semicolons; only the first character of
    # the option value is used.
    assert res_c.returncode == 0
    assert res_c.stdout == b'[["a","b"],["1","2"]]\n'

    res_k = run_fq(
        ["-d", "csv", "-c", ".", "-o", "comment=#"], stdin="a,b\n# note\n1,2\n"
    )
    # CATCHES: the comment option (default #) makes whole lines disappear
    # even in the middle of the file.
    assert res_k.returncode == 0
    assert res_k.stdout == b'[["a","b"],["1","2"]]\n'


def test_csv_ragged_row_falls_back_to_bytes():
    """A record with the wrong field count fails decoding to raw bytes."""
    res = run_fq(["-d", "csv", "-c", "."], stdin=b"a,b\n1\n")
    # CATCHES: unlike the yaml/xml Fatalf displays, a csv decode error makes
    # the forced -d run fall back to the bytes value, so `-c .` prints the
    # gap0 object with the whole input as a string and exits 0.
    assert res.returncode == 0
    assert res.stdout == b'{"gap0":"a,b\\n1\\n"}\n'
    assert res.stderr == b""


def test_csv_is_not_probed():
    """CSV is not part of the probe group even for clean CSV text."""
    res = run_fq(["-c", "format"], stdin=b"a,b\n1,2\n")
    # CATCHES: csv has no probe group, so plausible CSV input fails to
    # auto-detect and the process exits 4 with the probe error on stderr.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr == (
        b"error: <stdin>: probe: failed to decode: try fq -d FORMAT to force "
        b"format, see fq -h formats for list\n"
    )


def test_to_csv_quoting():
    """to_csv quotes only when the separator or a quote appears."""
    res = run_fq(["-n", "-c", '[[1, "a,b"], ["x", "\\"q\\""]] | to_csv'])
    # CATCHES: numbers become strings, a field containing the comma is
    # double quoted and an embedded double quote is doubled.
    assert res.returncode == 0
    assert res.stdout == b'"1,\\"a,b\\"\\nx,\\"\\"\\"q\\"\\"\\"\\n"\n'


def test_to_csv_comma_option_and_specials():
    """The comma option changes the separator; null and empty rows."""
    res = run_fq(["-n", "-c", '[[1,2],[3,4]] | to_csv({comma: ";"})'])
    # CATCHES: to_csv takes the same comma option as the decoder and keeps
    # the trailing newline after the last record.
    assert res.returncode == 0
    assert res.stdout == b'"1;2\\n3;4\\n"\n'

    res = run_fq(["-n", "-c", "[[], [null, true], []] | to_csv"])
    # CATCHES: an empty row still emits its record separator (so the output
    # is just newlines) and null becomes the empty field.
    assert res.returncode == 0
    assert res.stdout == b'"\\n,true\\n\\n"\n'


def test_to_csv_type_errors():
    """to_csv rejects object rows and non-scalar fields."""
    res_row = run_fq(["-n", "-c", "[{a:1}] | try to_csv catch ."])
    # CATCHES: rows must be arrays; an object row is reported with the row
    # itself in the message.
    assert res_row.returncode == 0
    assert res_row.stdout == b'"expected row to be an array, got object ({\\"a\\":1})"\n'

    res_field = run_fq(["-n", "-c", "[[{a:1}]] | try to_csv catch ."])
    # CATCHES: fields must be scalars, and the error shows the object after
    # string normalisation ({"a":"1"} with a quoted value).
    assert res_field.returncode == 0
    assert res_field.stdout == (
        b'"expected row record to be scalars, got object ({\\"a\\":\\"1\\"})"\n'
    )


def test_from_csv_on_string():
    """from_csv decodes a string value without any file."""
    res = run_fq(["-n", "-c", '"a,b\\n1,2" | from_csv'])
    # CATCHES: the generated from_<format> functions decode string input,
    # giving the same array-of-rows shape as -d csv.
    assert res.returncode == 0
    assert res.stdout == b'[["a","b"],["1","2"]]\n'
    assert res.stderr == b""


def test_to_csv_from_csv_roundtrip():
    """to_csv output re-decodes to the string grid."""
    res = run_fq(["-n", "-c", '[[1, "a,b"], [2, "x"]] | to_csv | from_csv'])
    # CATCHES: the round-trip is lossy for non-string scalars (everything
    # comes back as strings) but preserves embedded separators.
    assert res.returncode == 0
    assert res.stdout == b'[["1","a,b"],["2","x"]]\n'
