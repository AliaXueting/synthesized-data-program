"""CBOR (RFC 8949) decoding and the torepr conversion.

Covers ``-d cbor`` for all seven major types: positive/negative integers
(including big negative values), byte strings and text strings (definite
and indefinite with break markers), arrays, maps, semantic tags with their
symbol names, and the special/float major type (true/false/null/undefined,
half/single/double floats).  Also pins ``torepr``, the incorrect-shortCount
error paths, stream-type errors, and that cbor is never auto-probed.
"""

from __future__ import annotations

import base64

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.

# indefinite byte string: chunks "AB" and "CDE" terminated by 0xff
C_BYTES_IND = base64.b64decode("X0JBQkNDREX/")

# indefinite text string: chunks "ab" and "cde" terminated by 0xff
C_STR_IND = base64.b64decode("f2JhYmNjZGX/")

# {"key": [1, "a"], "b": 3}
C_NESTED = base64.b64decode("omNrZXmCAWFhYWID")

# tag 0 (date_time) wrapping "2013-03-21T20:04:00Z"
C_TAG_DT = base64.b64decode("wHQyMDEzLTAzLTIxVDIwOjA0OjAwWg==")

# tag 2 (unsigned_bignum) wrapping bytes 01 00
C_TAG_BIGNUM = base64.b64decode("wkIBAA==")

# tag 3 (negative_bignum) wrapping bytes 01
C_TAG_NEGBIGNUM = base64.b64decode("w0EB")


@pytest.mark.parametrize(
    "data,short_count,value",
    [
        (b"\x00", "0", 0),
        (b"\x17", "23", 23),
        (b"\x18\x64", '"8bit"', 100),
        (b"\x19\x03\xe8", '"16bit"', 1000),
        (b"\x1a\x00\x01\x00\x00", '"32bit"', 65536),
        (b"\x1b\x00\x00\x00\x01\x00\x00\x00\x00", '"64bit"', 4294967296),
    ],
)
def test_cbor_positive_int_widths(data, short_count, value):
    """Positive integers decode with the short_count width annotation."""
    res = run_fq(["-d", "cbor", "-c", "[torepr, .major_type, .short_count]"], stdin=data)
    # CATCHES: short counts 24-27 are surfaced as the strings "8bit".."64bit"
    # and the value comes from the additional-length bytes, while 0-23 keep
    # their numeric short_count.
    assert res.returncode == 0
    assert res.stdout == f'[{value},"positive_int",{short_count}]\n'.encode()
    assert res.stderr == b""


def test_cbor_negative_ints():
    """Negative integers decode as -(count+1), big values via bigint."""
    res1 = run_fq(["-d", "cbor", "-c", "[torepr, .major_type]"], stdin=b"\x20")
    # CATCHES: negative ints are -1 - n, so 0x20 (n=0) is -1.
    assert res1.returncode == 0
    assert res1.stdout == b'[-1,"negative_int"]\n'

    res2 = run_fq(["-d", "cbor", "-c", "torepr"], stdin=b"\x38\x63")
    assert res2.returncode == 0
    assert res2.stdout == b"-100\n"

    res3 = run_fq(
        ["-d", "cbor", "-c", "torepr"], stdin=b"\x3b\xff\xff\xff\xff\xff\xff\xff\xff"
    )
    # CATCHES: n = 2^64-1 decodes to -(2^64) as an exact big integer that
    # JSON prints in full digits, not a float.
    assert res3.returncode == 0
    assert res3.stdout == b"-18446744073709551616\n"


def test_cbor_definite_bytes():
    """A definite byte string decodes to raw bytes that torepr stringifies."""
    res = run_fq(["-d", "cbor", "-c", "[torepr, .major_type, .short_count]"], stdin=b"\x43ABC")
    # CATCHES: bytes keep their byte count in short_count and torepr renders
    # them as a string of the raw bytes.
    assert res.returncode == 0
    assert res.stdout == b'["ABC","bytes",3]\n'
    assert res.stderr == b""


def test_cbor_indefinite_bytes_stream(tmp_path):
    """Indefinite byte strings concatenate their chunks into value."""
    path = write_file(tmp_path, "bytes_ind.cbor", C_BYTES_IND)
    res = run_fq(["-d", "cbor", "-V", "-c", ".", path])
    # CATCHES: the chunks appear as an "items" array of definite byte
    # strings, "value" is their concatenation "ABCDE", and — unlike
    # indefinite arrays/maps — the 0xff break marker is NOT consumed, so it
    # surfaces as a "gap0" field.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"\\ufffd","items":[{"major_type":"bytes","short_count":2,'
        b'"value":"AB"},{"major_type":"bytes","short_count":3,"value":"CDE"}],'
        b'"major_type":"bytes","short_count":"indefinite","value":"ABCDE"}\n'
    )

    res_t = run_fq(["-d", "cbor", "-c", "torepr", path])
    assert res_t.returncode == 0
    assert res_t.stdout == b'"ABCDE"\n'


def test_cbor_indefinite_string_stream(tmp_path):
    """Indefinite text strings concatenate their chunks into value."""
    path = write_file(tmp_path, "str_ind.cbor", C_STR_IND)
    res = run_fq(["-d", "cbor", "-V", "-c", ".", path])
    # CATCHES: string chunks keep their own major_type/short_count and the
    # joined value is a plain string; the trailing 0xff again lands in gap0.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"\\ufffd","items":[{"major_type":"utf8","short_count":2,'
        b'"value":"ab"},{"major_type":"utf8","short_count":3,"value":"cde"}],'
        b'"major_type":"utf8","short_count":"indefinite","value":"abcde"}\n'
    )

    res_t = run_fq(["-d", "cbor", "-c", "torepr", path])
    assert res_t.returncode == 0
    assert res_t.stdout == b'"abcde"\n'


@pytest.mark.parametrize(
    "data,message",
    [
        (b"\x5f\x01\xff", b"non-bytes in bytes stream <nil>"),
        (b"\x7f\x01\xff", b"non-string in string stream <nil>"),
    ],
)
def test_cbor_indefinite_stream_type_errors(data, message):
    """Wrong element types in indefinite streams are decode errors."""
    res = run_fq(["-d", "cbor", "-c", "."], stdin=data)
    # CATCHES: an integer inside an indefinite byte/string stream fails with
    # the exact "non-bytes"/"non-string" message at position 0x2 while the
    # process still exits 0 and stderr stays empty.
    assert res.returncode == 0
    assert b"error: cbor: error at position 0x2: " + message + b"\n" in res.stdout
    assert res.stderr == b""


def test_cbor_arrays():
    """Definite and indefinite arrays decode to elements lists."""
    res = run_fq(
        ["-d", "cbor", "-c", "[torepr, .major_type, .short_count]"], stdin=b"\x83\x01\x02\x03"
    )
    # CATCHES: a definite array of three positive ints is [1,2,3] with
    # short_count 3.
    assert res.returncode == 0
    assert res.stdout == b'[[1,2,3],"array",3]\n'

    res_i = run_fq(["-d", "cbor", "-V", "-c", "."], stdin=b"\x9f\x01\x02\xff")
    # CATCHES: the indefinite array consumes its break marker into a "break"
    # field with value 255 (byte streams do not).
    assert res_i.returncode == 0
    assert res_i.stdout == (
        b'{"break":255,"elements":[{"major_type":"positive_int","short_count":1,'
        b'"value":1},{"major_type":"positive_int","short_count":2,"value":2}],'
        b'"major_type":"array","short_count":"indefinite"}\n'
    )

    res_t = run_fq(["-d", "cbor", "-c", "torepr"], stdin=b"\x9f\x01\x02\xff")
    assert res_t.returncode == 0
    assert res_t.stdout == b"[1,2]\n"


def test_cbor_maps():
    """Definite and indefinite maps decode to key/value pairs."""
    res = run_fq(
        ["-d", "cbor", "-c", "[torepr, .major_type, .short_count]"],
        stdin=b"\xa2\x61a\x01\x61b\x02",
    )
    # CATCHES: torepr rebuilds the jq object from the pairs array.
    assert res.returncode == 0
    assert res.stdout == b'[{"a":1,"b":2},"map",2]\n'

    res_i = run_fq(["-d", "cbor", "-V", "-c", "."], stdin=b"\xbf\x61a\x01\xff")
    # CATCHES: indefinite maps also consume the break marker into "break".
    assert res_i.returncode == 0
    assert res_i.stdout == (
        b'{"break":255,"major_type":"map","pairs":[{"key":{"major_type":"utf8",'
        b'"short_count":1,"value":"a"},"value":{"major_type":"positive_int",'
        b'"short_count":1,"value":1}}],"short_count":"indefinite"}\n'
    )

    res_t = run_fq(["-d", "cbor", "-c", "torepr"], stdin=b"\xbf\x61a\x01\xff")
    assert res_t.returncode == 0
    assert res_t.stdout == b'{"a":1}\n'


def test_cbor_nested_document(tmp_path):
    """Nested maps/arrays/strings survive a torepr round trip."""
    path = write_file(tmp_path, "nested.cbor", C_NESTED)
    res = run_fq(["-d", "cbor", "-c", "torepr", path])
    # CATCHES: torepr recurses through maps, arrays and scalars and drops
    # the pair-insertion order (keys come out sorted like jq objects).
    assert res.returncode == 0
    assert res.stdout == b'{"b":3,"key":[1,"a"]}\n'

    res_v = run_fq(["-d", "cbor", "-V", "-c", ".", path])
    assert res_v.returncode == 0
    assert res_v.stdout == (
        b'{"major_type":"map","pairs":[{"key":{"major_type":"utf8",'
        b'"short_count":3,"value":"key"},"value":{"elements":'
        b'[{"major_type":"positive_int","short_count":1,"value":1},'
        b'{"major_type":"utf8","short_count":1,"value":"a"}],'
        b'"major_type":"array","short_count":2}},{"key":{"major_type":"utf8",'
        b'"short_count":1,"value":"b"},"value":{"major_type":"positive_int",'
        b'"short_count":3,"value":3}}],"short_count":2}\n'
    )


@pytest.mark.parametrize(
    "fixture,tag",
    [
        (C_TAG_DT, b'"date_time"'),
        (base64.b64decode("wRpRS2ew"), b'"epoch_date_time"'),
        (C_TAG_BIGNUM, b'"unsigned_bignum"'),
        (C_TAG_NEGBIGNUM, b'"negative_bignum"'),
        (base64.b64decode("2dn3AQ=="), b'"self_described_cbor"'),
        (base64.b64decode("1UFB"), b'"base64url"'),
    ],
)
def test_cbor_semantic_tags(fixture, tag):
    """Known tag numbers decode to their symbol names."""
    res = run_fq(["-d", "cbor", "-V", "-c", ".tag"], stdin=fixture)
    # CATCHES: tags 0,1,2,3,21 and 55799 are named (date_time,
    # epoch_date_time, unsigned_bignum, negative_bignum, base64url,
    # self_described_cbor) instead of their raw numbers.
    assert res.returncode == 0
    assert res.stdout == tag + b"\n"
    assert res.stderr == b""


def test_cbor_tag_value_and_torepr():
    """A tag wraps its payload and torepr unwraps to the inner tree."""
    res = run_fq(["-d", "cbor", "-V", "-c", "."], stdin=base64.b64decode("2dn3AQ=="))
    # CATCHES: tag 55799 needs the 16-bit variable_count form (short_count
    # "16bit", variable_count 55799) and its payload is kept in "value".
    assert res.returncode == 0
    assert res.stdout == (
        b'{"major_type":"semantic","short_count":"16bit",'
        b'"tag":"self_described_cbor","value":{"major_type":"positive_int",'
        b'"short_count":1,"value":1},"variable_count":55799}\n'
    )

    res_t = run_fq(["-d", "cbor", "-c", "torepr"], stdin=base64.b64decode("2dn3AQ=="))
    # CATCHES: torepr of a tagged value returns the inner decoded TREE (an
    # object with major_type/short_count/value), not the plain number.
    assert res_t.returncode == 0
    assert res_t.stdout == (
        b'{"major_type":"positive_int","short_count":1,"value":1}\n'
    )


@pytest.mark.parametrize(
    "data,tree,torepr_",
    [
        (b"\xf4", b'{"major_type":"special_float","short_count":20,"value":false}', b"false"),
        (b"\xf5", b'{"major_type":"special_float","short_count":21,"value":true}', b"true"),
        (b"\xf6", b'{"major_type":"special_float","short_count":22,"value":null}', b"null"),
        (b"\xf7", b'{"major_type":"special_float","short_count":23}', b"null"),
    ],
)
def test_cbor_special_values(data, tree, torepr_):
    """false/true/null/undefined live in the special_float major type."""
    res = run_fq(["-d", "cbor", "-V", "-c", "."], stdin=data)
    # CATCHES: simple values share major_type "special_float"; undefined
    # (0xf7) produces NO value field at all and torepr turns it into null.
    assert res.returncode == 0
    assert res.stdout == tree + b"\n"

    res_t = run_fq(["-d", "cbor", "-c", "torepr"], stdin=data)
    assert res_t.returncode == 0
    assert res_t.stdout == torepr_ + b"\n"


@pytest.mark.parametrize(
    "data,short_count,value",
    [
        (b"\xf9\x3c\x00", '"16bit"', 1),
        (b"\xf9\xbc\x00", '"16bit"', -1),
        (b"\xfa\x47\xc3\x50\x00", '"32bit"', 100000),
        (b"\xfb\x3f\xf1\x99\x99\x99\x99\x99\x9a", '"64bit"', 1.1),
    ],
)
def test_cbor_floats(data, short_count, value):
    """Half, single and double floats decode through special_float."""
    res = run_fq(["-d", "cbor", "-c", "[torepr, .major_type, .short_count]"], stdin=data)
    # CATCHES: f16 1.0/-1.0, f32 100000 and f64 1.1 all print without float
    # noise and carry "16bit"/"32bit"/"64bit" short counts.
    assert res.returncode == 0
    assert res.stdout == f'[{value},"special_float",{short_count}]\n'.encode()
    assert res.stderr == b""


@pytest.mark.parametrize(
    "data,major",
    [
        (b"\x1c", b'major_type: "positive_int" (0)'),
        (b"\x5d", b'major_type: "bytes" (2)'),
        (b"\x7e", b'major_type: "utf8" (3)'),
    ],
)
def test_cbor_incorrect_short_count(data, major):
    """Short counts 28-30 are rejected for non-float major types."""
    res = run_fq(["-d", "cbor", "-c", "."], stdin=data)
    # CATCHES: the value is reported as "incorrect shortCount N" at position
    # 0x1 in the display output while exit code stays 0; the major type and
    # short count are still rendered first.
    assert res.returncode == 0
    count = data[0] & 0x1F
    assert (
        b"error: cbor: error at position 0x1: incorrect shortCount %d\n" % count
    ) in res.stdout
    assert major in res.stdout
    assert res.stderr == b""


def test_cbor_empty_input_error():
    """Empty input fails the major type read with an EOF error."""
    res = run_fq(["-d", "cbor", "-c", "."], stdin=b"")
    # CATCHES: the first read is a 3-bit major type, so the error names
    # U3(major_type) and position 0.
    assert res.returncode == 0
    assert (
        b"error: cbor: U3(major_type): failed at position 0 "
        b"(read size 0 seek pos 0): EOF\n"
    ) in res.stdout
    assert res.stderr == b""


def test_cbor_is_not_probed():
    """cbor is not part of the auto-detection probe group."""
    res = run_fq(["-c", "torepr"], stdin=b"\x83\x01\x02\x03")
    # CATCHES: a valid cbor array is never auto-detected, so an unforced
    # run exits 4 with the probe hint on stderr.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.startswith(
        b"error: <stdin>: probe: failed to decode: try fq -d FORMAT to force format"
    )
