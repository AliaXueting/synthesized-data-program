"""XML decoding (object and array mode) and the to_xml encoder.

Covers the object mapping rules (attribute prefix, #text/#comment keys,
repeated children collapsing to arrays, whitespace trimming), the seq and
array and attribute_prefix options, namespace handling, entity/CDATA
decoding, the trailing-data and rune validation errors, and to_xml
(#seq ordering, attribute sorting, indent, root unwrapping, array form).
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize(
    "text,expected",
    [
        ("<a>text</a>", b'{"a":"text"}\n'),
        ("<a/>", b'{"a":""}\n'),
        ('<a b="1">text</a>', b'{"a":{"#text":"text","@b":"1"}}\n'),
        ("<a><b>1</b><b>2</b><c/></a>", b'{"a":{"b":["1","2"],"c":""}}\n'),
        ('<a x="1" y="2"><b>1</b>tail</a>',
         b'{"a":{"#text":"tail","@x":"1","@y":"2","b":"1"}}\n'),
        ("<a><!-- hi --><b/></a>", b'{"a":{"#comment":"hi","b":""}}\n'),
        ("<a>x<b/>y</a>", b'{"a":{"#text":"xy","b":""}}\n'),
        ("  <a>  <b> x </b>  </a>  ", b'{"a":{"b":"x"}}\n'),
        ("<a><?pi data?><!-- c --></a>", b'{"a":{"#comment":"c"}}\n'),
        ("<a>&amp;&#65;</a>", b'{"a":"&A"}\n'),
        ("<a><![CDATA[x<y]]></a>", b'{"a":"x<y"}\n'),
        ('<a b="&lt;"/>', b'{"a":{"@b":"<"}}\n'),
    ],
)
def test_xml_object_mode(text, expected):
    """The default object mapping of elements, text, comments and attrs."""
    res = run_fq(["-d", "xml", "-c", "."], stdin=text)
    # CATCHES: an element with only text collapses to a string, repeated
    # children become arrays, text around children is trimmed and
    # concatenated, comments land under #comment and entities/CDATA are
    # decoded while processing instructions vanish.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_xml_seq_option():
    """seq=true records the sibling index of every repeated-able element."""
    res = run_fq(["-d", "xml", "-c", ".", "-o", "seq=true"],
                 stdin="<a><b>1</b><c>2</c></a>")
    # CATCHES: #seq counts element children (0-based) and is omitted for an
    # only child (b and c share parent a with two children so both get
    # numbered).
    assert res.returncode == 0
    assert res.stdout == b'{"a":{"b":{"#seq":0,"#text":"1"},"c":{"#seq":1,"#text":"2"}}}\n'


def test_xml_seq_option_single_child_has_no_seq():
    """A lone element child gets no #seq key."""
    res = run_fq(["-d", "xml", "-c", ".", "-o", "seq=true"],
                 stdin="<a><b>1</b></a>")
    # CATCHES: with only one child element the index would always be 0, so
    # the decoder omits #seq entirely for that subtree root.
    assert res.returncode == 0
    assert res.stdout == b'{"a":{"b":"1"}}\n'


def test_xml_array_mode():
    """array=true produces the [name, attrs, children] tree."""
    res = run_fq(["-d", "xml", "-c", ".", "-o", "array=true"],
                 stdin='<a b="1"><c>2</c>text</a>')
    # CATCHES: in array mode attributes lose the @ prefix, elements without
    # attributes get null in the attrs slot (so .[1].x works), and text
    # still lands in #text.
    assert res.returncode == 0
    assert res.stdout == (
        b'["a",{"#text":"text","b":"1"},[["c",{"#text":"2"},[]]]]\n'
    )


def test_xml_attribute_prefix_option():
    """attribute_prefix changes the attr key prefix."""
    res = run_fq(["-d", "xml", "-c", ".", "-o", "attribute_prefix="],
                 stdin='<a b="1"/>')
    # CATCHES: the empty prefix makes attributes appear as plain keys; the
    # special #text/#comment keys are unaffected.
    assert res.returncode == 0
    assert res.stdout == b'{"a":{"b":"1"}}\n'


def test_xml_namespaces():
    """Namespace declarations become attributes; element prefixes are restored."""
    res = run_fq(
        ["-d", "xml", "-c", "."],
        stdin=b'<a xmlns:p="http://x" xmlns:q="http://x"><p:b/><q:c/></a>',
    )
    # CATCHES: two prefixes bound to the same URL both survive as @xmlns
    # declarations, but both children are named with the LAST declared
    # prefix because the URL lookup scans the stack backwards.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"a":{"@xmlns:p":"http://x","@xmlns:q":"http://x","q:b":"","q:c":""}}\n'
    )

    res_attr = run_fq(["-d", "xml", "-c", "."],
                      stdin=b'<a b="1" xmlns:t="http://t" t:b="2"/>')
    # CATCHES: namespaced attributes keep their prefix in the key and
    # xmlns declarations show up as @xmlns:* attributes.
    assert res_attr.returncode == 0
    assert res_attr.stdout == b'{"a":{"@b":"1","@t:b":"2","@xmlns:t":"http://t"}}\n'


@pytest.mark.parametrize(
    "text,err_fragment",
    [
        (b"<a>1</a><b>2</b>", b"root element has trailing element <b>"),
        (b"<a>1</a>trailing", b'root element has trailing non-whitespace "trailing"'),
        (b"<a>", b"XML syntax error on line 1: unexpected EOF"),
        (b"nope", b"EOF"),
    ],
)
def test_xml_decode_errors(text, err_fragment):
    """Decode failures render the annotated hexdump on stdout with exit 0."""
    res = run_fq(["-d", "xml", "-c", "."], stdin=text)
    # CATCHES: forced -d xml failures exit 0 and print the bytes display
    # with the error: xml: prefix; trailing elements, trailing text, broken
    # tags and non-tag roots each get their own message.
    assert res.returncode == 0
    assert b"error: xml: error at position" in res.stdout
    assert err_fragment in res.stdout
    assert b"<stdin> (xml)" in res.stdout
    assert res.stderr == b""


@pytest.mark.parametrize(
    "text,err_fragment",
    [
        (b"\xff<a/>", b"invalid UTF-8"),
        (b"\x01<a/>", b"illegal character code U+0001"),
    ],
)
def test_xml_first_rune_validation(text, err_fragment):
    """The first rune is validated before parsing."""
    res = run_fq(["-d", "xml", "-c", "."], stdin=text)
    # CATCHES: an invalid UTF-8 lead byte or a control character outside the
    # XML Char production is rejected by a fast pre-check with the illegal
    # code point spelled U+XXXX.
    assert res.returncode == 0
    assert b"error: xml: error at position 0x5" in res.stdout
    assert err_fragment in res.stdout
    assert res.stderr == b""


def test_to_xml_object_mode():
    """to_xml renders an object tree with attributes inline."""
    res = run_fq(["-n", "-c", '{a: {"#text": "hi", "@b": "1"}} | to_xml'])
    # CATCHES: attributes are written before the text content and numbers
    # are stringified.
    assert res.returncode == 0
    assert res.stdout == b'"<a b=\\"1\\">hi</a>"\n'

    res_indent = run_fq(["-n", "-c", "{a: {b: 1, c: 2}} | to_xml({indent: 2})"])
    # CATCHES: indent:2 pretty prints children on their own lines with the
    # closing tag aligned to the parent.
    assert res_indent.returncode == 0
    assert res_indent.stdout == b'"<a>\\n  <b>1</b>\\n  <c>2</c>\\n</a>"\n'


def test_to_xml_comment_empty_and_escape():
    """#comment, empty arrays and text escaping."""
    res = run_fq(["-n", "-c", '{a: {"#comment": "note", b: [], t: "1</a>"}} | to_xml'])
    # CATCHES: comments use <!--...>, an empty array still emits the element
    # (as an empty element) and < > in text are entity escaped.
    assert res.returncode == 0
    assert res.stdout == b'"<a><!--note--><b></b><t>1&lt;/a&gt;</t></a>"\n'


def test_to_xml_seq_orders_children():
    """#seq values sort children instead of name order."""
    res = run_fq(["-n", "-c", '{a: {b: {"#seq": 1}, c: {"#seq": 0}}} | to_xml'])
    # CATCHES: without #seq children are sorted by name; when any child has
    # #seq the elements are ordered by the #seq number instead, so c comes
    # first here.
    assert res.returncode == 0
    assert res.stdout == b'"<a><c></c><b></b></a>"\n'

    res_named = run_fq(
        ["-n", "-c", '{a: {b: {z: 0, "#seq": 1}, c: {y: 0, "#seq": 0}}} | to_xml']
    )
    # CATCHES: the #seq ordering is recursive and the #seq key itself never
    # becomes an attribute or element.
    assert res_named.returncode == 0
    assert res_named.stdout == b'"<a><c><y>0</y></c><b><z>0</z></b></a>"\n'


def test_to_xml_attributes_sorted_and_prefix_option():
    """Attributes are sorted by name; attribute_prefix option is honored."""
    res = run_fq(["-n", "-c", '{a: {"@z": "1", "@a": "2", b: 1}} | to_xml'])
    # CATCHES: attributes are emitted sorted by name before any child
    # elements even though the map iteration order is random.
    assert res.returncode == 0
    assert res.stdout == b'"<a a=\\"2\\" z=\\"1\\"><b>1</b></a>"\n'

    res_prefix = run_fq(
        ["-n", "-c", '{a: {"%b": "1"}} | to_xml({attribute_prefix: "%"})']
    )
    # CATCHES: only keys with the configured prefix become attributes.
    assert res_prefix.returncode == 0
    assert res_prefix.stdout == b'"<a b=\\"1\\"></a>"\n'


def test_to_xml_root_unwrapping():
    """A single root child replaces the synthetic doc element."""
    res = run_fq(["-n", "-c", "{doc: {b: 1}} | to_xml"])
    # CATCHES: to_xml wraps input in a "doc" element and unwraps it again
    # when it has exactly one child element and nothing else, so the output
    # root is the input's only key.
    assert res.returncode == 0
    assert res.stdout == b'"<doc><b>1</b></doc>"\n'

    res_multi = run_fq(["-n", "-c", "{a: 1, b: 2} | to_xml"])
    # CATCHES: with two root keys the doc wrapper cannot be unwrapped and
    # both appear under it, sorted by name.
    assert res_multi.returncode == 0
    assert res_multi.stdout == b'"<doc><a>1</a><b>2</b></doc>"\n'


def test_to_xml_array_mode():
    """The [name, attrs, children] array form encodes back to XML."""
    res = run_fq(
        ["-n", "-c", '["a", {"b": "1"}, [["c", {}, []]]] | to_xml']
    )
    # CATCHES: array form keys attributes without any prefix, {} means no
    # attributes and [] no children, and non-array children entries are
    # skipped.
    assert res.returncode == 0
    assert res.stdout == b'"<a b=\\"1\\"><c></c></a>"\n'


def test_to_xml_from_xml_roundtrip_is_lossy_for_numbers():
    """to_xml|from_xml stringifies numbers."""
    res = run_fq(["-n", "-c", "{a: {b: 1}} | to_xml | from_xml"])
    # CATCHES: XML has no number type so a round-trip through to_xml
    # returns every scalar as a string.
    assert res.returncode == 0
    assert res.stdout == b'{"a":{"b":"1"}}\n'


def test_xmlentities_functions():
    """from_xmlentities/to_xmlentities are exposed for both directions."""
    res_from = run_fq(["-n", "-c", '"&amp;&lt;&gt;&quot;" | from_xmlentities'])
    # CATCHES: from_xmlentities unescapes the five predefined entities.
    assert res_from.returncode == 0
    assert res_from.stdout == b'"&<>\\""\n'

    res_to = run_fq(["-n", "-c", '"<>&" | to_xmlentities'])
    # CATCHES: to_xmlentities escapes only < > & (not quotes).
    assert res_to.returncode == 0
    assert res_to.stdout == b'"&lt;&gt;&amp;"\n'
