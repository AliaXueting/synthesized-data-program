"""Avro object container file (OCF) decoding.

Covers ``-d avro_ocf`` for the file header (magic, the meta map with
``avro.schema``/``avro.codec`` entries and the 16-byte sync marker), blocks
with the null/deflate/snappy codecs (including the snappy CRC check and the
unknown-codec raw dump), the schema-driven datum decoding of every Avro type
(null, boolean, int, long, float, double, bytes, string, enum with symbol
resolution, array, map, union, fixed) plus the logical types (date on int and
long, time/timestamp at second/milli/micro/nanosecond precision), the
block-loop quirks (count <= 0 ends the block early but the outer loop keeps
reading, negative array/map counts carry a size field, sync mismatches drop
the sync field), and the malformed-input behaviour (bad magic, missing or
unparseable schema, unknown types, out-of-range enum/union indices, varints
longer than 8 bytes) which decodes partially with ``gap0`` and error lines
while still exiting 0.  Also asserts that avro_ocf is auto-probed from the
magic and has no ``torepr``.
"""

from __future__ import annotations

import base64
import json
import struct
import zlib

import pytest

from conftest import run_fq, write_b64

# All expectations below were recorded by running ./executable.

# Reference OCF files from the fq test corpus.
ALL_TYPES = base64.b64decode(
    "T2JqAQQWYXZyby5zY2hlbWHUD3siZmllbGRzIjpbeyJuYW1lIjoibnVsbCIsInR5cGUiOi"
    "JudWxsIn0seyJuYW1lIjoiYm9vbGVhbiIsInR5cGUiOiJib29sZWFuIn0seyJuYW1lIjoi"
    "aW50IiwidHlwZSI6ImludCJ9LHsibmFtZSI6ImxvbmciLCJ0eXBlIjoibG9uZyJ9LHsibm"
    "FtZSI6ImZsb2F0IiwidHlwZSI6ImZsb2F0In0seyJuYW1lIjoiZG91YmxlIiwidHlwZSI6"
    "ImRvdWJsZSJ9LHsibmFtZSI6ImJ5dGVzIiwidHlwZSI6ImJ5dGVzIn0seyJuYW1lIjoic3"
    "RyaW5nIiwidHlwZSI6InN0cmluZyJ9LHsibmFtZSI6ImVudW0iLCJ0eXBlIjp7Im5hbWUi"
    "OiJlbnVtIiwic3ltYm9scyI6WyJBIiwiQiIsIkMiXSwidHlwZSI6ImVudW0ifX0seyJuYW"
    "1lIjoiYXJyYXkiLCJ0eXBlIjp7Iml0ZW1zIjoic3RyaW5nIiwibmFtZSI6ImFycmF5Iiwi"
    "dHlwZSI6ImFycmF5In19LHsibmFtZSI6Im1hcCIsInR5cGUiOnsibmFtZSI6Im1hcCIsIn"
    "R5cGUiOiJtYXAiLCJ2YWx1ZXMiOiJzdHJpbmcifX0seyJuYW1lIjoidW5pb24iLCJ0eXBl"
    "IjpbImludCIsInN0cmluZyJdfSx7Im5hbWUiOiJmaXhlZCIsInR5cGUiOnsibmFtZSI6Im"
    "ZpeGVkIiwic2l6ZSI6MTYsInR5cGUiOiJmaXhlZCJ9fSx7Im5hbWUiOiJkYXRlIiwidHlw"
    "ZSI6eyJsb2dpY2FsVHlwZSI6ImRhdGUiLCJ0eXBlIjoiaW50In19LHsibmFtZSI6InRpbW"
    "VNaWxsaXMiLCJ0eXBlIjp7ImxvZ2ljYWxUeXBlIjoidGltZS1taWxsaXMiLCJ0eXBlIjoi"
    "bG9uZyJ9fSx7Im5hbWUiOiJ0aW1lTWljcm9zIiwidHlwZSI6eyJsb2dpY2FsVHlwZSI6In"
    "RpbWUtbWljcm9zIiwidHlwZSI6ImxvbmcifX0seyJuYW1lIjoidGltZXN0YW1wTWlsbGlz"
    "IiwidHlwZSI6eyJsb2dpY2FsVHlwZSI6InRpbWVzdGFtcC1taWxsaXMiLCJ0eXBlIjoibG"
    "9uZyJ9fSx7Im5hbWUiOiJ0aW1lc3RhbXBNaWNyb3MiLCJ0eXBlIjp7ImxvZ2ljYWxUeXBl"
    "IjoidGltZXN0YW1wLW1pY3JvcyIsInR5cGUiOiJsb25nIn19XSwibmFtZSI6IkFsbERhdG"
    "FUeXBlcyIsInR5cGUiOiJyZWNvcmQifRRhdnJvLmNvZGVjCG51bGwA08N73QnUEQ+rgXA+"
    "cHieoBSQDAEOQgAAAACSJEmSJEnyPwI5BDEwAAAGAmECQQJiAkICYwJDAAICMAABAgMEBQ"
    "YHCAkKCwwNDg8MwKkH4F3A2YStjTfg3b+zp8CuAwAMQKuqqj4lSZIkSZL0PwI4BDExAgIC"
    "YQAGAmECQQJiAkICYwJDAAICMQABAgMEBQYHCAkKCwwNDg8OwqkH3V3Cybf/jTeiovmQq8"
    "WuAwEKRquqKj+3bdu2bdv2PwQxMQI4BAQCYQJiAAYCYwJDAmECQQJiAkIAAgIyAAECAwQF"
    "BgcICQoLDA0ODwjEqQfkXcS56tGON+Tdte6uyq4DAAhEAACAP0mSJEmSJPk/BDEwAjkAAA"
    "YCYgJCAmMCQwJhAkEAAgIzAAECAwQFBgcICQoLDA0ODwrGqQfZXcapnaSPN6ai78uyz64D"
    "AQZKq6qqP9u2bdu2bfs/BDEzBDE0AgICYQAGAmECQQJiAkICYwJDAAICNAABAgMEBQYHCA"
    "kKCwwNDg8EyKkH6F3ImdD2jzfo3aupttSuAwAESFVV1T9u27Zt27b9PwQxMgQxNQQEAmEC"
    "YgAGAmECQQJiAkICYwJDAAICNQABAgMEBQYHCAkKCwwNDg8GyqkH1V3KiYPJkDeqouWGut"
    "muAwECTgAAAEAAAAAAAAAAQAQxNQQxMgAABgJhAkECYgJCAmMCQwACAjYAAQIDBAUGBwgJ"
    "CgsMDQ4PAMypB+xdzPm1m5E37N2h5L3ergMAAExVVRVASZIkSZIkAUAEMTQEMTMCAgJhAA"
    "YCYQJBAmICQgJjAkMAAgI3AAECAwQFBgcICQoLDA0ODwLOqQfRXc7p6O2RN66i28HB464D"
    "AR5Sq6oqQAAAAAAAAAAAAjECMgQEAmECYgAGAmMCQwJhAkECYgJCAAICOAABAgMEBQYHCA"
    "kKCwwNDg8c0KkH8F3Q2ZvAkjfw3ZefxeiuAwAcUAAAQECSJEmSJEnCPwIwAjMAAAYCYQJB"
    "AmICQgJjAkMAAgI5AAECAwQFBgcICQoLDA0ODx7SqQfNXdLJzpKTN7Ki0fzI7a4D08N73Q"
    "nUEQ+rgXA+cHieoA=="
)

TWITTER = base64.b64decode(
    "T2JqAQQWYXZyby5zY2hlbWHoBXsidHlwZSI6InJlY29yZCIsIm5hbWUiOiJ0d2l0dGVyX3"
    "NjaGVtYSIsIm5hbWVzcGFjZSI6ImNvbS5taWd1bm8uYXZybyIsImZpZWxkcyI6W3sibmFt"
    "ZSI6InVzZXJuYW1lIiwidHlwZSI6InN0cmluZyIsImRvYyI6Ik5hbWUgb2YgdGhlIHVzZX"
    "IgYWNjb3VudCBvbiBUd2l0dGVyLmNvbSJ9LHsibmFtZSI6InR3ZWV0IiwidHlwZSI6InN0"
    "cmluZyIsImRvYyI6IlRoZSBjb250ZW50IG9mIHRoZSB1c2VyJ3MgVHdpdHRlciBtZXNzYW"
    "dlIn0seyJuYW1lIjoidGltZXN0YW1wIiwidHlwZSI6ImxvbmciLCJkb2MiOiJVbml4IGVw"
    "b2NoIHRpbWUgaW4gc2Vjb25kcyJ9XSwiZG9jOiI6IkEgYmFzaWMgc2NoZW1hIGZvciBzdG"
    "9yaW5nIFR3aXR0ZXIgbWVzc2FnZXMifRRhdnJvLmNvZGVjCG51bGwAZ8c1KXPv35St0wB+"
    "nuv/rgTIAQxtaWd1bm9GUm9jazogTmVyZiBwYXBlciwgc2Npc3NvcnMgaXMgZmluZS6yuO"
    "6WChRCbGl6emFyZENTRldvcmtzIGFzIGludGVuZGVkLiAgVGVycmFuIGlzIElNQkEu4vPu"
    "lgpnxzUpc+/flK3TAH6e6/+u"
)

SNAPPY_NATIVE = base64.b64decode(
    "T2JqAQQWYXZyby5zY2hlbWHUD3siZmllbGRzIjpbeyJuYW1lIjoibnVsbCIsInR5cGUiOi"
    "JudWxsIn0seyJuYW1lIjoiYm9vbGVhbiIsInR5cGUiOiJib29sZWFuIn0seyJuYW1lIjoi"
    "aW50IiwidHlwZSI6ImludCJ9LHsibmFtZSI6ImxvbmciLCJ0eXBlIjoibG9uZyJ9LHsibm"
    "FtZSI6ImZsb2F0IiwidHlwZSI6ImZsb2F0In0seyJuYW1lIjoiZG91YmxlIiwidHlwZSI6"
    "ImRvdWJsZSJ9LHsibmFtZSI6ImJ5dGVzIiwidHlwZSI6ImJ5dGVzIn0seyJuYW1lIjoic3"
    "RyaW5nIiwidHlwZSI6InN0cmluZyJ9LHsibmFtZSI6ImVudW0iLCJ0eXBlIjp7Im5hbWUi"
    "OiJlbnVtIiwic3ltYm9scyI6WyJBIiwiQiIsIkMiXSwidHlwZSI6ImVudW0ifX0seyJuYW"
    "1lIjoiYXJyYXkiLCJ0eXBlIjp7Iml0ZW1zIjoic3RyaW5nIiwibmFtZSI6ImFycmF5Iiwi"
    "dHlwZSI6ImFycmF5In19LHsibmFtZSI6Im1hcCIsInR5cGUiOnsibmFtZSI6Im1hcCIsIn"
    "R5cGUiOiJtYXAiLCJ2YWx1ZXMiOiJzdHJpbmcifX0seyJuYW1lIjoidW5pb24iLCJ0eXBl"
    "IjpbImludCIsInN0cmluZyJdfSx7Im5hbWUiOiJmaXhlZCIsInR5cGUiOnsibmFtZSI6Im"
    "ZpeGVkIiwic2l6ZSI6MTYsInR5cGUiOiJmaXhlZCJ9fSx7Im5hbWUiOiJkYXRlIiwidHlw"
    "ZSI6eyJsb2dpY2FsVHlwZSI6ImRhdGUiLCJ0eXBlIjoiaW50In19LHsibmFtZSI6InRpbW"
    "VNaWxsaXMiLCJ0eXBlIjp7ImxvZ2ljYWxUeXBlIjoidGltZS1taWxsaXMiLCJ0eXBlIjoi"
    "bG9uZyJ9fSx7Im5hbWUiOiJ0aW1lTWljcm9zIiwidHlwZSI6eyJsb2dpY2FsVHlwZSI6In"
    "RpbWUtbWljcm9zIiwidHlwZSI6ImxvbmcifX0seyJuYW1lIjoidGltZXN0YW1wTWlsbGlz"
    "IiwidHlwZSI6eyJsb2dpY2FsVHlwZSI6InRpbWVzdGFtcC1taWxsaXMiLCJ0eXBlIjoibG"
    "9uZyJ9fSx7Im5hbWUiOiJ0aW1lc3RhbXBNaWNyb3MiLCJ0eXBlIjp7ImxvZ2ljYWxUeXBl"
    "IjoidGltZXN0YW1wLW1pY3JvcyIsInR5cGUiOiJsb25nIn19XSwibmFtZSI6IkFsbERhdG"
    "FUeXBlcyIsInR5cGUiOiJyZWNvcmQifRRhdnJvLmNvZGVjDHNuYXBweQDMzGEx/RTQYRa2"
    "D50w9BvwFIwIiAbwUgEOQgAAAACSJEmSJEnyPwI5BDEwAAAGAmECQQJiAkICYwJDAAICMA"
    "ABAgMEBQYHCAkKCwwNDg8MwKkH4F3A2YStjTfg3b+zp8CuAwAMQKuqqj4lAUoskvQ/AjgE"
    "MTECAgJhQk4AADE+TgCIDsKpB91dwsm3/403oqL5kKvFrgMBCkarqio/t23btm3b9j8BTB"
    "g4BAQCYQJiQlAAADI+UABoCMSpB+RdxLnq0Y435N217q7KrgMACEQAAIA/BZ0cJPk/BDEw"
    "AjlG6QAAMz5LAGgKxqkH2V3GqZ2kjzemou/Lss+uAwEGSquqqj8BmSS2bfs/BDEzBDE0Uu"
    "oACDQAATY4AWwEyKkH6F3ImdD2jzfo3aupttSuAwAESFVV1T9uBVAc/T8EMTIEMTVa6wAA"
    "NT5RAGgGyqkH1V3KiYPJkDeqouWGutmuAwECTgAAAEAh2AEIAU4IMTIAQjcBADY+TABoAM"
    "ypB+xdzPm1m5E37N2h5L3ergMAAExVVRVAKTccAUAEMTQEMTNS7AAANz5PAGQCzqkH0V3O"
    "6ejtkTeuotvBweOuAwEeUquqKhGbGAACMQIyBARS1QEAOD5PAGgc0KkH8F3Q2ZvAkjfw3Z"
    "efxeiuAwAcUAAAQEBJvhTCPwIwAjNG6AAAOT5KAEwe0qkHzV3Syc6SkzeyotH8yO2uA4e4"
    "/rbMzGEx/RTQYRa2D50w9Bvw"
)

FIRST_ZERO = base64.b64decode(
    "T2JqAQIWYXZyby5zY2hlbWEeeyJ0eXBlIjoibG9uZyJ9ADAxMjM0NTY3ODlhYmNkZWYA"
)


def zz(n: int) -> bytes:
    """Encode n as an Avro zig-zag variable-length long."""
    v = (n << 1) ^ (n >> 63)
    out = b""
    while True:
        b = v & 0x7F
        v >>= 7
        if v:
            out += bytes([b | 0x80])
        else:
            return out + bytes([b])


def uvarint(n: int) -> bytes:
    """Encode n as an unsigned LEB128 varint (snappy length prefix)."""
    out = b""
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out += bytes([b | 0x80])
        else:
            return out + bytes([b])


def header_map(pairs) -> bytes:
    """Encode the OCF header meta map (block-count, entries, zero end)."""
    out = zz(len(pairs))
    for key, value in pairs:
        out += zz(len(key)) + key.encode() + zz(len(value)) + value.encode()
    return out + zz(0)


def ocf(schema, datums, codec=None, sync=b"\x01" * 16, magic=b"Obj\x01"):
    """Build an OCF file: magic, header (schema + optional codec), sync, one block."""
    meta = [("avro.schema", schema if isinstance(schema, str) else json.dumps(schema))]
    if codec is not None:
        meta.append(("avro.codec", codec))
    out = magic + header_map(meta) + sync
    data = b"".join(datums)
    out += zz(len(datums)) + zz(len(data)) + data + sync
    return out


def snappy_literal(raw: bytes) -> bytes:
    """A snappy block of literal tags only (no copy compression)."""
    out = uvarint(len(raw))
    for i in range(0, len(raw), 60):
        chunk = raw[i : i + 60]
        out += bytes([(len(chunk) - 1) << 2]) + chunk
    return out


# datum encoders for the custom fixtures
def d_long(n: int) -> bytes:
    """Encode an Avro long datum (same zig-zag varint as int)."""
    return zz(n)


def d_int(n: int) -> bytes:
    """Encode an Avro int datum."""
    return zz(n)


def d_str(s: str) -> bytes:
    """Encode an Avro string datum: length plus UTF-8 bytes."""
    data = s.encode()
    return zz(len(data)) + data


def d_array(items, neg=False) -> bytes:
    """Encode an Avro array datum; NEG uses a negative count plus size."""
    body = b"".join(items)
    if neg:
        return zz(-len(items)) + zz(len(body)) + body + zz(0)
    return zz(len(items)) + body + zz(0)


def d_map(pairs, neg=False) -> bytes:
    """Encode an Avro map datum; NEG uses a negative count plus size."""
    body = b"".join(d_str(k) + v for k, v in pairs)
    if neg:
        return zz(-len(pairs)) + zz(len(body)) + body + zz(0)
    return zz(len(pairs)) + body + zz(0)


LONG_SCHEMA = '{"type": "long"}'


def test_avro_probe(tmp_path):
    """The OCF magic is in the probe group, so plain probing detects avro."""
    path = write_b64(tmp_path, "all.avro", ALL_TYPES)
    res = run_fq(["-c", "format"], path)
    # CATCHES: avro_ocf registers a probe and "Obj\x01" is enough to pick it,
    # so no -d flag is needed to decode the file.
    assert res.returncode == 0
    assert res.stdout == b'"avro_ocf"\n'
    assert res.stderr == b""

    bad = write_b64(tmp_path, "badmagic.avro", ocf(LONG_SCHEMA, [d_long(1)], magic=b"Xbj\x01"))
    res_bad = run_fq(["-c", "format"], bad)
    # CATCHES: without the exact magic the file is not detected as avro and
    # probing fails with the generic error and exit code 4.
    assert res_bad.returncode == 4
    assert b"probe: failed to decode" in res_bad.stderr


def test_avro_no_torepr(tmp_path):
    """avro_ocf registers no torepr conversion."""
    path = write_b64(tmp_path, "all.avro", ALL_TYPES)
    res = run_fq(["-d", "avro_ocf", "-c", "torepr"], path)
    # CATCHES: unlike the scalar formats, avro_ocf has no torepr builtin and
    # calling it is a jq error with exit code 5 naming the format (the
    # filename appears as passed on the command line).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == f"error: {path}: avro_ocf has no torepr\n".encode()


def test_avro_header_tree(tmp_path):
    """The header keeps the meta map entries and the sync marker."""
    path = write_b64(tmp_path, "all.avro", ALL_TYPES)
    res = run_fq(
        [
            "-d",
            "avro_ocf",
            "-V",
            "-c",
            "[.magic, .header.meta[0].data[0].key, .header.meta[0].data[1].key, "
            ".header.meta[0].data[1].value, (.header.sync|length), "
            "(.header.sync|@base64)]",
        ],
        path,
    )
    # CATCHES: the meta map decodes as an array of blocks of key/value
    # records; avro.codec is a plain "null" string and the 16 sync bytes are
    # kept raw (invalid UTF-8 bytes become U+FFFD, so the base64 of the
    # re-encoded string pins them exactly).
    assert res.returncode == 0
    assert res.stdout == (
        b'["Obj\\u0001",{"data":"avro.schema","length":11},'
        b'{"data":"avro.codec","length":10},'
        b'{"data":"null","length":4},16,'
        b'"77+977+9e++/vQnvv70RD++/ve+/vXA+cHjvv73vv70="]\n'
    )
    assert res.stderr == b""


def test_avro_all_types_datum(tmp_path):
    """A record datum decodes every Avro type with its natural shape."""
    path = write_b64(tmp_path, "all.avro", ALL_TYPES)
    res = run_fq(["-d", "avro_ocf", "-V", "-c", ".blocks[0].data[0]"], path)
    # CATCHES: ints/longs are plain numbers, strings/bytes carry length+data,
    # enums resolve to their symbol ("A"), fixed stays 16 raw bytes, the
    # union keeps {type, value}, and the logical types render as formatted
    # date/time strings ("1970-01-07", "00:01:00.000", RFC3339 timestamps).
    assert res.returncode == 0
    assert res.stdout == (
        b'{"array":[{"count":0,"data":[]}],"boolean":true,'
        b'"bytes":{"data":"9","length":1},"date":"1970-01-07",'
        b'"double":-2.8062043420318885e-221,"enum":"A",'
        b'"fixed":"\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005\\u0006\\u0007'
        b'\\b\\t\\n\\u000b\\f\\r\\u000e\\u000f","float":0,"int":7,"long":33,'
        b'"map":[{"count":3,"data":['
        b'{"key":{"data":"a","length":1},"value":{"data":"A","length":1}},'
        b'{"key":{"data":"b","length":1},"value":{"data":"B","length":1}},'
        b'{"key":{"data":"c","length":1},"value":{"data":"C","length":1}}]},'
        b'{"count":0,"data":[]}],"null":null,'
        b'"string":{"data":"10","length":2},'
        b'"timeMicros":"00:00:00.006000","timeMillis":"00:01:00.000",'
        b'"timestampMicros":"2000-01-01T00:00:00.006Z",'
        b'"timestampMillis":"2000-01-01T00:01:00Z",'
        b'"union":{"type":1,"value":{"data":"0","length":1}}}\n'
    )
    assert res.stderr == b""


def test_avro_all_types_block_and_datums(tmp_path):
    """The block frame carries count/size/sync and ten decoded datums."""
    path = write_b64(tmp_path, "all.avro", ALL_TYPES)
    res = run_fq(
        ["-d", "avro_ocf", "-V", "-c", "[(.blocks|length), .blocks[0].count, "
         ".blocks[0].size, (.blocks[0].data|length), "
         ".blocks[0].data[1].enum, .blocks[0].data[2].enum, .blocks[0].data[3].enum]"],
        path,
    )
    # CATCHES: the null-codec block records the item count (10), the byte
    # size of the data, the trailing sync marker and one datum per entry —
    # the enum symbol cycles A, B, C, A across the first four datums.
    assert res.returncode == 0
    assert res.stdout == b"[1,10,776,10,\"B\",\"C\",\"A\"]\n"
    assert res.stderr == b""

    res_d = run_fq(["-d", "avro_ocf", "-c", "d"], path)
    # CATCHES: the display names the magic and sync as raw bits with a
    # "(valid)" assertion suffix and resolves enum symbols with their index.
    assert b"magic: raw bits (valid)" in res_d.stdout
    assert b'|          enum: "A" (0)' in res_d.stdout
    assert b'|          date: "1970-01-07" (6)' in res_d.stdout


def test_avro_twitter_records(tmp_path):
    """A record schema with string and long fields decodes per field."""
    path = write_b64(tmp_path, "twitter.avro", TWITTER)
    res = run_fq(
        ["-d", "avro_ocf", "-V", "-c", ".blocks[0].data[1]"], path
    )
    # CATCHES: string fields keep the length/data struct and the long
    # timestamp is a plain number — the record fields appear by name.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"timestamp":1366154481,"tweet":{"data":"Works as intended.  '
        b'Terran is IMBA.","length":35},"username":{"data":"BlizzardCS",'
        b'"length":10}}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "avro_ocf", "-c", "d"], path)
    # CATCHES: the display names null-codec datum entries "datum".
    assert b"|        [0]{}: datum" in res_d.stdout
    assert b"|        [1]{}: datum" in res_d.stdout
    assert b"timestamp: 1366150681" in res_d.stdout


def test_avro_native_snappy(tmp_path):
    """A snappy-coded block decompresses and verifies its CRC."""
    path = write_b64(tmp_path, "snappy.avro", SNAPPY_NATIVE)
    res = run_fq(
        ["-d", "avro_ocf", "-V", "-c", "[.blocks[0].count, .blocks[0].size, "
         ".blocks[0].crc, (.blocks[0].data|length), .blocks[0].data[0].boolean]"],
        path,
    )
    # CATCHES: the snappy codec strips the 4 CRC bytes from the compressed
    # field, decompresses the rest, decodes the datums in a sub-buffer and
    # exposes the big-endian IEEE CRC32 of the decompressed data as crc.
    assert res.returncode == 0
    assert res.stdout == b"[10,518,2277047990,10,true]\n"
    assert res.stderr == b""


def test_avro_deflate_codec(tmp_path):
    """A deflate-coded block is decompressed and its datums decoded."""
    datums = [d_long(v) for v in [0, 1, -1, 150]]
    raw = b"".join(datums)
    comp = zlib.compressobj(6, zlib.DEFLATED, -15)
    deflated = comp.compress(raw) + comp.flush()
    header = (
        b"Obj\x01"
        + header_map([("avro.schema", LONG_SCHEMA), ("avro.codec", "deflate")])
        + b"\xaa" * 16
    )
    path = write_b64(
        tmp_path,
        "deflate.avro",
        header + zz(4) + zz(len(deflated)) + deflated + b"\xaa" * 16,
    )
    res = run_fq(
        ["-d", "avro_ocf", "-V", "-c", ".blocks[0] | {count, size, data}"], path
    )
    # CATCHES: the raw deflate stream (no zlib/gzip wrapper) is inflated and
    # the four long datums decode to 0, 1, -1, 150; the tree keeps count and
    # the compressed byte size but has no crc field (only snappy has one).
    assert res.returncode == 0
    assert res.stdout == b'{"count":4,"data":[0,1,-1,150],"size":7}\n'
    assert res.stderr == b""


def test_avro_snappy_codec_crc(tmp_path):
    """A hand-built snappy block verifies its CRC as big-endian IEEE."""
    datums = [d_long(v) for v in [0, 1, -1, 150]]
    raw = b"".join(datums)
    snappy = snappy_literal(raw) + struct.pack(">I", zlib.crc32(raw) & 0xFFFFFFFF)
    header = (
        b"Obj\x01"
        + header_map([("avro.schema", LONG_SCHEMA), ("avro.codec", "snappy")])
        + b"\xbb" * 16
    )
    path = write_b64(
        tmp_path,
        "snappy.avro",
        header + zz(4) + zz(len(snappy)) + snappy + b"\xbb" * 16,
    )
    res = run_fq(
        ["-d", "avro_ocf", "-V", "-c", ".blocks[0] | {count, size, crc, data}"],
        path,
    )
    # CATCHES: the snappy block length prefix is a plain LEB128 varint (not
    # zig-zag) and the trailing CRC is the big-endian crc32 of the
    # decompressed bytes, exposed as a decimal number in the tree.
    assert res.returncode == 0
    assert res.stdout == b'{"count":4,"crc":2169882472,"data":[0,1,-1,150],"size":11}\n'
    assert res.stderr == b""

    res_d = run_fq(["-d", "avro_ocf", "-c", "d"], path)
    # CATCHES: the display renders the crc in hex with a "(valid)" suffix.
    assert b"crc: 0x8155c768 (valid)" in res_d.stdout


def test_avro_snappy_bad_crc(tmp_path):
    """A wrong snappy CRC still decodes but is flagged invalid in display."""
    datums = [d_long(v) for v in [0, 1, -1, 150]]
    raw = b"".join(datums)
    snappy = snappy_literal(raw) + struct.pack(">I", 0xDEADBEEF)
    header = (
        b"Obj\x01"
        + header_map([("avro.schema", LONG_SCHEMA), ("avro.codec", "snappy")])
        + b"\xbb" * 16
    )
    path = write_b64(
        tmp_path,
        "badsnappy.avro",
        header + zz(4) + zz(len(snappy)) + snappy + b"\xbb" * 16,
    )
    res = run_fq(["-d", "avro_ocf", "-V", "-c", ".blocks[0] | keys"], path)
    # CATCHES: the failed CRC assert does not abort the decode — all block
    # fields (including crc and the decompressed data) are still present.
    assert res.returncode == 0
    assert res.stdout == b'["data","count","size","compressed","crc","sync"]\n'
    assert res.stderr == b""

    res_d = run_fq(["-d", "avro_ocf", "-c", "d"], path)
    # CATCHES: the display marks the mismatching CRC as "(invalid)".
    assert b"crc: 0xdeadbeef (invalid)" in res_d.stdout


def test_avro_unknown_codec_dumps_raw(tmp_path):
    """An unhandled codec keeps the block bytes raw and decodes no data."""
    path = write_b64(
        tmp_path, "zstd.avro", ocf(LONG_SCHEMA, [b"\x02"], codec="zstd")
    )
    res = run_fq(["-d", "avro_ocf", "-V", "-c", ".blocks[0]"], path)
    # CATCHES: only null/deflate/snappy are implemented; any other codec
    # dumps the block bytes into a "compressed" field, still checks the sync
    # marker and never produces a data array or an error line.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"compressed":"\\u0002","count":1,"size":1,'
        b'"sync":"\\u0001\\u0001\\u0001\\u0001\\u0001\\u0001\\u0001\\u0001'
        b'\\u0001\\u0001\\u0001\\u0001\\u0001\\u0001\\u0001\\u0001"}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "avro_ocf", "-c", "d"], path)
    # CATCHES: the display describes the raw field with the codec name.
    assert b"compressed: raw bits (zstd encoded)" in res_d.stdout
    assert b"error" not in res_d.stdout


def test_avro_first_block_count_zero(tmp_path):
    """A first block with count 0 ends immediately without size/data/sync."""
    path = write_b64(tmp_path, "firstzero.avro", FIRST_ZERO)
    res = run_fq(["-d", "avro_ocf", "-V", "-c", "[.blocks, .magic]"], path)
    # CATCHES: count <= 0 returns from the block immediately, so the block
    # struct has ONLY the count field — no size, no data and not even the
    # trailing sync marker are read; the header decodes normally.
    assert res.returncode == 0
    assert res.stdout == (
        b'[[{"count":0}],"Obj\\u0001"]\n'
    )
    assert res.stderr == b""


def test_avro_negative_first_block_count_continues(tmp_path):
    """A negative first count still ends the block but the loop keeps going."""
    header = b"Obj\x01" + header_map([("avro.schema", LONG_SCHEMA)]) + b"\x07" * 16
    path = write_b64(
        tmp_path,
        "negfirst.avro",
        header + zz(-3) + zz(2) + d_long(9) + b"\x07" * 16,
    )
    res = run_fq(["-d", "avro_ocf", "-V", "-c", ".blocks"], path)
    # CATCHES: the count <= 0 early return only ends the CURRENT block, so
    # the outer blocks loop reads on: the leftover bytes (here a "size" of 9
    # and two 0x07 varints) are decoded as a second block with count 2 and
    # datums -4, -4; the second block's sync read then fails (no sync field).
    assert res.returncode == 0
    assert res.stdout == b'[{"count":-3},{"count":2,"data":[-4,-4],"size":9}]\n'
    assert res.stderr == b""


def test_avro_multiple_blocks(tmp_path):
    """Each block carries its own count, data and sync marker."""
    path = write_b64(
        tmp_path,
        "multi.avro",
        ocf(LONG_SCHEMA, [d_long(1)]) + zz(2) + zz(4) + d_long(2) + d_long(3)
        + b"\x01" * 16,
    )
    res = run_fq(
        ["-d", "avro_ocf", "-V", "-c", "[(.blocks|length), .blocks[0].data, "
         ".blocks[1].data]"],
        path,
    )
    # CATCHES: the block loop runs until end of buffer, so a second block
    # after the first sync marker is decoded with its own datums [2, 3].
    assert res.returncode == 0
    assert res.stdout == b"[2,[1],[2,3]]\n"
    assert res.stderr == b""


def test_avro_sync_mismatch(tmp_path):
    """A block sync that differs from the header sync fails the assert."""
    data = (
        b"Obj\x01"
        + header_map([("avro.schema", LONG_SCHEMA)])
        + b"\x01" * 16
        + zz(1)
        + zz(1)
        + d_long(7)
        + b"\x02" * 16
    )
    path = write_b64(tmp_path, "badsync.avro", data)
    res = run_fq(["-d", "avro_ocf", "-V", "-c", "[.blocks[0], (.gap0|length)]"], path)
    # CATCHES: the sync assert compares against the header marker, so a
    # mismatching block sync drops the sync field from the tree and the 16
    # bytes land in gap0 — the datum itself still decodes.
    assert res.returncode == 0
    assert res.stdout == b'[{"count":1,"data":[7],"size":1},16]\n'
    assert res.stderr == b""

    res_d = run_fq(["-d", "avro_ocf", "-c", "."], path)
    assert (
        b"error: avro_ocf: RawLen(sync): failed at position 70 "
        b"(read size 0 seek pos 0): failed to validate raw" in res_d.stdout
    )


def test_avro_logical_types_seconds_and_nanos(tmp_path):
    """date/time/timestamp logical types work at every precision."""
    schema = {
        "type": "record",
        "name": "T",
        "fields": [
            {"name": "ts", "type": {"type": "long", "logicalType": "timestamp"}},
            {"name": "t", "type": {"type": "long", "logicalType": "time"}},
            {"name": "tsn", "type": {"type": "long", "logicalType": "timestamp-nanos"}},
            {"name": "tn", "type": {"type": "long", "logicalType": "time-nanos"}},
            {"name": "dlong", "type": {"type": "long", "logicalType": "date"}},
        ],
    }
    datum = (
        d_long(946684800)
        + d_long(3661)
        + d_long(1234567890)
        + d_long(12345678901234)
        + d_long(20000)
    )
    path = write_b64(tmp_path, "logicals.avro", ocf(schema, [datum]))
    res = run_fq(["-d", "avro_ocf", "-V", "-c", ".blocks[0].data[0]"], path)
    # CATCHES: second-precision "timestamp" formats as RFC3339, "time" as
    # HH:MM:SS, the nanosecond variants add 9 fractional digits, and the
    # date mapper applies to longs too (20000 days -> 2024-10-04).
    assert res.returncode == 0
    assert res.stdout == (
        b'{"dlong":"2024-10-04","t":"01:01:01","tn":"03:25:45.678901234",'
        b'"ts":"2000-01-01T00:00:00Z",'
        b'"tsn":"1970-01-01T00:00:01.23456789Z"}\n'
    )
    assert res.stderr == b""


def test_avro_negative_array_and_map_blocks(tmp_path):
    """Negative array/map block counts keep the raw count plus a size."""
    schema = {
        "type": "record",
        "name": "R",
        "fields": [
            {"name": "arr", "type": {"type": "array", "items": "int"}},
            {"name": "m", "type": {"type": "map", "values": "int"}},
        ],
    }
    datum = d_array([d_int(10), d_int(20)], neg=True) + d_map(
        [("x", d_int(5))], neg=True
    )
    path = write_b64(tmp_path, "negblocks.avro", ocf(schema, [datum]))
    res = run_fq(["-d", "avro_ocf", "-V", "-c", ".blocks[0].data[0]"], path)
    # CATCHES: a negative block count is kept verbatim in the tree with the
    # following byte size as a "size" field, the items still decode, and a
    # final zero-count block terminates the array/map; the map reuses the
    # array decoder with key/value record entries.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"arr":[{"count":-2,"data":[10,20],"size":2},{"count":0,"data":[]}],'
        b'"m":[{"count":-1,"data":[{"key":{"data":"x","length":1},"value":5}],'
        b'"size":3},{"count":0,"data":[]}]}\n'
    )
    assert res.stderr == b""


@pytest.mark.parametrize(
    "name,data,errline",
    [
        (
            "badmagic.avro",
            ocf(LONG_SCHEMA, [d_long(1)], magic=b"Xbj\x01"),
            b"error: avro_ocf: RawLen(magic): failed at position 4 "
            b"(read size 0 seek pos 0): failed to validate raw",
        ),
        (
            "noschema.avro",
            b"Obj\x01"
            + header_map([("avro.codec", "null")])
            + b"\x01" * 16
            + zz(1)
            + zz(1)
            + d_long(1)
            + b"\x01" * 16,
            b"error: avro_ocf: error at position 0x26: missing meta avro.schema",
        ),
        (
            "badjson.avro",
            ocf("{not json", [d_long(1)]),
            b"error: avro_ocf: error at position 0x2c: failed to parse schema: "
            b"failed to unmarshal header schema: invalid character 'n' looking "
            b"for beginning of object key string",
        ),
        (
            "unktype.avro",
            ocf({"type": "wat"}, []),
            b"error: avro_ocf: error at position 0x32: unable to create codec: "
            b"unknown type: wat",
        ),
        (
            "norec.avro",
            ocf({"type": "record", "name": "R"}, []),
            b"error: avro_ocf: error at position 0x42: failed to parse schema: "
            b"failed parsing fields: no fields",
        ),
        (
            "trunc.avro",
            b"Obj\x01",
            b"error: avro_ocf: error at position 0x4: unexpected end of data",
        ),
        (
            "empty.avro",
            b"",
            b"error: avro_ocf: RawLen(magic): failed at position 0 "
            b"(read size 0 seek pos 0): outside buffer",
        ),
        (
            "enoob.avro",
            ocf({"type": "enum", "name": "E", "symbols": ["A", "B"]}, [zz(5)]),
            b"error: avro_ocf: FieldSint(datum): failed at position 90 "
            b"(read size 0 seek pos 0): enum value of out range",
        ),
        (
            "uoob.avro",
            ocf(["int", "string"], [zz(9) + d_int(1)]),
            b"error: avro_ocf: error at position 0x37: invalid union value: 9",
        ),
        (
            "long9.avro",
            ocf(LONG_SCHEMA, [b"\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00"]),
            b"error: avro_ocf: error at position 0x3d: long exceeds 8 bytes",
        ),
    ],
)
def test_avro_decode_errors(tmp_path, name, data, errline):
    """Malformed files decode partially and report an error line, exit 0."""
    path = write_b64(tmp_path, name, data)
    res = run_fq(["-d", "avro_ocf", "-c", "."], path)
    # CATCHES: every structural failure (bad magic, missing/unparseable
    # schema, unknown type, record without fields, truncation, out-of-range
    # enum/union indices, over-long varints) keeps the process at exit 0
    # with the error embedded in the display output, not on stderr.
    assert res.returncode == 0
    assert res.stderr == b""
    assert errline in res.stdout


def test_avro_decode_error_trees(tmp_path):
    """Structural failures leave gap fields with the unread bytes."""
    # CATCHES: each failed sub-read stops only that datum — the enum keeps
    # an empty data array, the union keeps its raw type index, a lone magic
    # leaves an empty meta block struct, and empty input yields {} — all
    # with exit code 0 and the leftover bytes in gap0.
    path = write_b64(
        tmp_path,
        "enoob.avro",
        ocf({"type": "enum", "name": "E", "symbols": ["A", "B"]}, [zz(5)]),
    )
    res = run_fq(["-d", "avro_ocf", "-V", "-c", ".blocks"], path)
    assert res.returncode == 0
    assert res.stdout == b'[{"count":1,"data":[],"size":1}]\n'

    # union index out of range: the union struct keeps the raw type index.
    path_u = write_b64(
        tmp_path, "uoob.avro", ocf(["int", "string"], [zz(9) + d_int(1)])
    )
    res_u = run_fq(["-d", "avro_ocf", "-V", "-c", ".blocks[0].data"], path_u)
    assert res_u.returncode == 0
    assert res_u.stdout == b'[{"type":9}]\n'

    # a file of just the magic: the meta count read fails leaving an empty
    # block struct.
    path_t = write_b64(tmp_path, "trunc.avro", b"Obj\x01")
    res_t = run_fq(["-d", "avro_ocf", "-V", "-c", "."], path_t)
    assert res_t.returncode == 0
    assert res_t.stdout == b'{"header":{"meta":[{}]},"magic":"Obj\\u0001"}\n'

    # empty input decodes to an empty value tree.
    path_e = write_b64(tmp_path, "empty.avro", b"")
    res_e = run_fq(["-d", "avro_ocf", "-V", "-c", "."], path_e)
    assert res_e.returncode == 0
    assert res_e.stdout == b"{}\n"
