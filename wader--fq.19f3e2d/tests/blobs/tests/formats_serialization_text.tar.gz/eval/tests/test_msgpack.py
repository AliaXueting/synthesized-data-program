"""MessagePack decoding and the torepr conversion.

Covers ``-d msgpack`` for every value family (ints of all widths, strings,
bin, ext, floats, arrays, maps), the jq tree shape (``type``/``length``/
``pairs``/``elements``), ``torepr`` turning that tree back into plain jq
values, decode errors surfacing in the display output while the process
still exits 0, and that msgpack is never auto-probed.
"""

from __future__ import annotations

import base64

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.

# json2msgpack-style document: {"array":[1,2,3],"object":{"key":"value"},
# "number":123,"string":"abc","true":true,"false":false,"null":null}
MP_TYPES = base64.b64decode(
    "h6VhcnJheZMBAgOmb2JqZWN0gaNrZXmldmFsdWWmbnVtYmVye6ZzdHJpbmejYWJj"
    "pHRydWXDpWZhbHNlwqRudWxswA=="
)

# an ext16 whose 16-bit length field 0x0002 is only read as one byte
MP_EXT16_QUIRK = base64.b64decode("yAACBUFC")

# float64 pi (0xcb marker plus big-endian IEEE754 double)
MP_PI = base64.b64decode("y0AJIftURC0Y")


def test_msgpack_types_document(tmp_path):
    """A msgpack map decodes to a tree that torepr turns into plain values."""
    path = write_file(tmp_path, "types.msgpack", MP_TYPES)
    res = run_fq(["-d", "msgpack", "-c", "torepr", path])
    # CATCHES: torepr rebuilds the jq object from pairs (fixmap key order is
    # lost — output is key-sorted), numbers stay numbers and nil/true/false
    # become their JSON counterparts.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"array":[1,2,3],"false":false,"null":null,"number":123,'
        b'"object":{"key":"value"},"string":"abc","true":true}\n'
    )
    assert res.stderr == b""


def test_msgpack_types_tree_shape(tmp_path):
    """The raw decoded value keeps type/length/pairs/elements structure."""
    path = write_file(tmp_path, "types.msgpack", MP_TYPES)
    res = run_fq(["-d", "msgpack", "-V", "-c", ".", path])
    # CATCHES: the decoder tree names each node by its msgpack type symbol
    # ("fixmap"/"fixarray"/"fixstr"/"positive_fixint"/"nil"/"true"/"false")
    # with length and pairs/elements arrays, not plain jq values.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"length":7,"pairs":['
        b'{"key":{"length":5,"type":"fixstr","value":"array"},'
        b'"value":{"elements":[{"type":"positive_fixint","value":1},'
        b'{"type":"positive_fixint","value":2},'
        b'{"type":"positive_fixint","value":3}],"length":3,"type":"fixarray"}},'
        b'{"key":{"length":6,"type":"fixstr","value":"object"},'
        b'"value":{"length":1,"pairs":[{"key":{"length":3,"type":"fixstr",'
        b'"value":"key"},"value":{"length":5,"type":"fixstr","value":"value"}}],'
        b'"type":"fixmap"}},'
        b'{"key":{"length":6,"type":"fixstr","value":"number"},'
        b'"value":{"type":"positive_fixint","value":123}},'
        b'{"key":{"length":6,"type":"fixstr","value":"string"},'
        b'"value":{"length":3,"type":"fixstr","value":"abc"}},'
        b'{"key":{"length":4,"type":"fixstr","value":"true"},'
        b'"value":{"type":"true","value":true}},'
        b'{"key":{"length":5,"type":"fixstr","value":"false"},'
        b'"value":{"type":"false","value":false}},'
        b'{"key":{"length":4,"type":"fixstr","value":"null"},'
        b'"value":{"type":"nil","value":null}}],"type":"fixmap"}\n'
    )


@pytest.mark.parametrize(
    "data,typ,value",
    [
        (b"\x01", "positive_fixint", 1),
        (b"\x7f", "positive_fixint", 127),
        (b"\xe0", "negative_fixint", -32),
        (b"\xff", "negative_fixint", -1),
        (b"\xcc\xc8", "uint8", 200),
        (b"\xcd\x03\xe8", "uint16", 1000),
        (b"\xce\x00\x01\x00\x00", "uint32", 65536),
        (b"\xcf\x00\x00\x00\x01\x00\x00\x00\x00", "uint64", 4294967296),
        (b"\xd0\x9c", "int8", -100),
        (b"\xd1\xff\xfe", "int16", -2),
        (b"\xd2\xff\xff\xff\x9c", "int32", -100),
        (b"\xd3\xf0\x00\x00\x00\x00\x00\x00\x00", "int64", -1152921504606846976),
    ],
)
def test_msgpack_integer_widths(data, typ, value):
    """Every integer encoding decodes to its type symbol and value."""
    res = run_fq(["-d", "msgpack", "-c", "[torepr, .type]"], stdin=data)
    # CATCHES: each width uses its own type symbol (positive/negative fixint
    # for the single-byte forms, uint8..uint64 and int8..int64 for the rest)
    # and torepr yields the exact signed/unsigned number.
    assert res.returncode == 0
    assert res.stdout == f'[{value},"{typ}"]\n'.encode()
    assert res.stderr == b""


@pytest.mark.parametrize(
    "data,typ,expected",
    [
        (b"\xa3abc", "fixstr", '"abc"'),
        (b"\xd9\x03abc", "str8", '"abc"'),
        (b"\xda\x00\x03abc", "str16", '"abc"'),
        (b"\xdb\x00\x00\x00\x00", "str32", '""'),
    ],
)
def test_msgpack_string_family(data, typ, expected):
    """fixstr/str8/str16/str32 all decode as UTF-8 strings."""
    res = run_fq(["-d", "msgpack", "-c", "[torepr, .type]"], stdin=data)
    # CATCHES: the four string widths share the same value shape; a str32
    # with length zero is still typed "str32" and decodes to the empty
    # string rather than nil.
    assert res.returncode == 0
    assert res.stdout == f"[{expected},\"{typ}\"]\n".encode()
    assert res.stderr == b""


@pytest.mark.parametrize(
    "data,typ,length",
    [
        (b"\xc4\x03ABC", "bin8", 3),
        (b"\xc5\x00\x03ABC", "bin16", 3),
        (b"\xc6\x00\x00\x00\x00", "bin32", 0),
    ],
)
def test_msgpack_bin_family(data, typ, length):
    """bin8/bin16/bin32 values become strings through torepr."""
    res = run_fq(["-d", "msgpack", "-c", "[torepr, .type, .length]"], stdin=data)
    # CATCHES: bin values are raw bytes that torepr stringifies ("ABC", or
    # the empty string for zero-length bin32); the length field is the byte
    # count.
    assert res.returncode == 0
    expected = '"ABC"' if length else '""'
    assert res.stdout == f'[{expected},"{typ}",{length}]\n'.encode()
    assert res.stderr == b""


def test_msgpack_ext_family():
    """fixext/ext nodes carry a signed fixtype and raw value bytes."""
    res1 = run_fq(["-d", "msgpack", "-V", "-c", "."], stdin=b"\xd4\x01\x05")
    # CATCHES: fixext1 has no length field (implied 1) and keeps its one-byte
    # type as the signed "fixtype"; the raw value renders with \u escapes.
    assert res1.returncode == 0
    assert res1.stdout == b'{"fixtype":1,"type":"fixext1","value":"\\u0005"}\n'

    res2 = run_fq(["-d", "msgpack", "-V", "-c", "."], stdin=b"\xd5\x02AB")
    assert res2.returncode == 0
    assert res2.stdout == b'{"fixtype":2,"type":"fixext2","value":"AB"}\n'

    res4 = run_fq(["-d", "msgpack", "-V", "-c", "."], stdin=b"\xd7\x04ABCDEFGH")
    assert res4.returncode == 0
    assert res4.stdout == b'{"fixtype":4,"type":"fixext8","value":"ABCDEFGH"}\n'

    res16 = run_fq(
        ["-d", "msgpack", "-V", "-c", "."], stdin=b"\xd8\x05" + b"ABCDEFGHIJKLMNOP"
    )
    assert res16.returncode == 0
    assert res16.stdout == (
        b'{"fixtype":5,"type":"fixext16","value":"ABCDEFGHIJKLMNOP"}\n'
    )

    res8 = run_fq(["-d", "msgpack", "-V", "-c", "."], stdin=b"\xc7\x02\x05AB")
    # CATCHES: ext8 unlike fixext has an explicit length field before fixtype.
    assert res8.returncode == 0
    assert res8.stdout == b'{"fixtype":5,"length":2,"type":"ext8","value":"AB"}\n'


def test_msgpack_ext16_length_is_read_as_one_byte(tmp_path):
    """ext16/ext32 lengths are decoded from a single byte, not 16/32."""
    path = write_file(tmp_path, "ext16.msgpack", MP_EXT16_QUIRK)
    res = run_fq(["-d", "msgpack", "-V", "-c", ".", path])
    # CATCHES: the reference reads the ext16 length with a U8 read, so the
    # 0x0002 16-bit length becomes 0, the fixtype is the next byte 0x02 and
    # the remaining bytes land in a "gap0" field.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fixtype":2,"gap0":"\\u0005AB","length":0,"type":"ext16","value":""}\n'
    )

    res_t = run_fq(["-d", "msgpack", "-c", "torepr", path])
    assert res_t.returncode == 0
    assert res_t.stdout == b'""\n'

    res32 = run_fq(["-d", "msgpack", "-V", "-c", "."], stdin=b"\xc9\x00\x02\x05AB")
    # CATCHES: ext32 shares the same single-byte length quirk.
    assert res32.returncode == 0
    assert res32.stdout == (
        b'{"fixtype":2,"gap0":"\\u0005AB","length":0,"type":"ext32","value":""}\n'
    )


def test_msgpack_floats():
    """float32/float64 decode to IEEE numbers."""
    res32 = run_fq(["-d", "msgpack", "-c", "[torepr, .type]"], stdin=b"\xca\x3f\x80\x00\x00")
    # CATCHES: float32 1.0 prints as the integer-looking 1 and keeps its
    # own "float32" type symbol.
    assert res32.returncode == 0
    assert res32.stdout == b'[1,"float32"]\n'

    res64 = run_fq(["-d", "msgpack", "-c", "[torepr, .type]"], stdin=MP_PI)
    assert res64.returncode == 0
    assert res64.stdout == b'[3.141592653589793,"float64"]\n'


@pytest.mark.parametrize(
    "data,typ,length,value",
    [
        (b"\x93\x01\x02\x03", "fixarray", 3, "[1,2,3]"),
        (b"\xdc\x00\x03\x01\x02\x03", "array16", 3, "[1,2,3]"),
        (b"\xdd\x00\x00\x00\x00", "array32", 0, "[]"),
        (b"\x81\xa1a\x01", "fixmap", 1, '{"a":1}'),
        (b"\xde\x00\x01\xa1a\x01", "map16", 1, '{"a":1}'),
        (b"\xdf\x00\x00\x00\x00", "map32", 0, "{}"),
    ],
)
def test_msgpack_array_and_map_widths(data, typ, length, value):
    """Array and map containers of every width decode with length fields."""
    res = run_fq(["-d", "msgpack", "-c", "[torepr, .type, .length]"], stdin=data)
    # CATCHES: array16/array32 and map16/map32 carry an explicit multi-byte
    # length while the fix forms re-read the low bits of the type byte, and
    # a zero-length container decodes to [] / {} rather than failing.
    assert res.returncode == 0
    assert res.stdout == f'[{value},"{typ}",{length}]\n'.encode()
    assert res.stderr == b""


def test_msgpack_never_used_type_is_a_decode_error():
    """The reserved 0xc1 byte reports an error but still exits 0."""
    res = run_fq(["-d", "msgpack", "-c", "."], stdin=b"\xc1")
    # CATCHES: 0xc1 ("never_used") produces an error line inside the display
    # output yet the process exits 0 with empty stderr — decode errors are
    # part of the value tree, not process failures.
    assert res.returncode == 0
    assert b"error: msgpack: error at position 0x1: 0xc1 never used\n" in res.stdout
    assert b'type: "never_used" (0xc1)' in res.stdout
    assert res.stderr == b""

    res_t = run_fq(["-d", "msgpack", "-c", "torepr"], stdin=b"\xc1")
    assert res_t.returncode == 0
    assert res_t.stdout == b"null\n"


def test_msgpack_truncated_string_keeps_gap():
    """A truncated fixstr leaves the unconsumed bytes as gap0."""
    res = run_fq(["-d", "msgpack", "-V", "-c", "."], stdin=b"\xa5ab")
    # CATCHES: a fixstr claiming 5 bytes with only 2 available decodes
    # length 5, no value, and the leftover bytes surface as "gap0".
    assert res.returncode == 0
    assert res.stdout == b'{"gap0":"ab","length":5,"type":"fixstr"}\n'

    res_d = run_fq(["-d", "msgpack", "-c", "."], stdin=b"\xa5ab")
    # CATCHES: the display shows the decode error with the exact reader
    # diagnostics (position, expected size, bytes left).
    assert res_d.returncode == 0
    assert (
        b"error: msgpack: UTF8(value): failed at position 1 "
        b"(read size 0 seek pos 0): tryText nBytes 5 outside buffer, 2 bytes left\n"
    ) in res_d.stdout
    assert b"gap0: raw bits" in res_d.stdout


def test_msgpack_empty_input_error():
    """Empty input fails the type read with an EOF error."""
    res = run_fq(["-d", "msgpack", "-c", "."], stdin=b"")
    # CATCHES: with no bytes at all the decoder reports U8(type) EOF at
    # position 0 and emits no value lines, still exiting 0.
    assert res.returncode == 0
    assert (
        b"error: msgpack: U8(type): failed at position 0 "
        b"(read size 0 seek pos 0): EOF\n"
    ) in res.stdout
    assert res.stderr == b""


def test_msgpack_is_not_probed():
    """msgpack is not part of the auto-detection probe group."""
    res = run_fq(["-c", "torepr"], stdin=MP_TYPES)
    # CATCHES: plausible msgpack input is never auto-detected, so an
    # unforced run exits 4 with the probe hint on stderr.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.startswith(
        b"error: <stdin>: probe: failed to decode: try fq -d FORMAT to force format"
    )
