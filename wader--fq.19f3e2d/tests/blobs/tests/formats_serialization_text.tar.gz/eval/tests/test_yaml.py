"""YAML decoding and the to_yaml encoder.

Covers ``-d yaml`` of mappings, sequences, anchors and multi-line scalars,
the "root not object or array" restriction, the decode failure display for
broken YAML, and ``to_yaml`` structure (indent option, key sorting, when
strings get quoted, literal blocks for multi-line strings).
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.


@pytest.mark.parametrize(
    "text,expected",
    [
        ("a: 1\n", b'{"a":1}\n'),
        ("- 1\n", b"[1]\n"),
        ("a: [1, 2]\n", b'{"a":[1,2]}\n'),
        ("a:\n  b: 1\n", b'{"a":{"b":1}}\n'),
        ("x: &a 1\ny: *a\n", b'{"x":1,"y":1}\n'),
        ("a: null\nb: true\nc: 1.5\n", b'{"a":null,"b":true,"c":1.5}\n'),
        ("- a: 1\n- a: 2\n", b'[{"a":1},{"a":2}]\n'),
    ],
)
def test_yaml_decode_values(text, expected):
    """-d yaml turns YAML documents into jq values."""
    res = run_fq(["-d", "yaml", "-c", "."], stdin=text)
    # CATCHES: anchors and aliases are resolved by the decoder, nested
    # collections nest and flow sequences become arrays.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_yaml_decode_multiline_and_flow():
    """Block scalars and flow collections decode to strings and arrays."""
    res = run_fq(["-d", "yaml", "-c", "."], stdin="a: |\n  l1\n  l2\nb: {x: 1}\n")
    # CATCHES: a literal block keeps its inner newline, flow mappings become
    # objects.
    assert res.returncode == 0
    assert res.stdout == b'{"a":"l1\\nl2\\n","b":{"x":1}}\n'


@pytest.mark.parametrize("text", ["1\n", "123\n"])
def test_yaml_scalar_root_is_rejected(text):
    """The yaml decoder demands an object or array at the root."""
    res = run_fq(["-d", "yaml", "-c", "."], stdin=text)
    # CATCHES: yaml never decodes to a scalar root; the failure is rendered
    # as the hexdump display on stdout (with the (yaml) format tag) and the
    # process still exits 0 because the format was forced.
    assert res.returncode == 0
    assert b"error: yaml: error at position" in res.stdout
    assert b"root not object or array" in res.stdout
    assert b"<stdin> (yaml)" in res.stdout
    assert res.stderr == b""


def test_yaml_broken_flow_sequence():
    """A syntax error shows the goccy source excerpt in the hexdump."""
    res = run_fq(["-d", "yaml", "-c", "."], stdin="a: [1,\n")
    # CATCHES: decode failures embed the yaml library's error with a
    # position, the offending source line and a caret, all on stdout.
    assert res.returncode == 0
    assert (
        b"error: yaml: error at position 0x7: [1:4] sequence end token ']' "
        b"not found" in res.stdout
    )
    assert b">  1 | a: [1," in res.stdout
    assert res.stderr == b""


def test_to_yaml_structure():
    """to_yaml emits block style with four space default indent."""
    res = run_fq(["-n", "-c", "{a:1,b:[2,3]} | to_yaml"])
    # CATCHES: sequences are written at the parent's indentation level (no
    # extra dash indent) and keys are sorted.
    assert res.returncode == 0
    assert res.stdout == b'"a: 1\\nb:\\n- 2\\n- 3\\n"\n'


def test_to_yaml_indent_option():
    """The indent option changes nested mapping indentation only."""
    res_default = run_fq(["-n", "-c", "{a:{b:{c:1}}} | to_yaml"])
    res_two = run_fq(["-n", "-c", "{a:{b:{c:1}}} | to_yaml({indent:2})"])
    # CATCHES: default indent is 4 (the to_yaml wrapper fills it in) and
    # indent:2 shrinks each nesting level; list dashes never indent.
    assert res_default.returncode == 0
    assert res_default.stdout == b'"a:\\n    b:\\n        c: 1\\n"\n'
    assert res_two.returncode == 0
    assert res_two.stdout == b'"a:\\n  b:\\n    c: 1\\n"\n'


def test_to_yaml_string_quoting_rules():
    """Strings that would re-read as another type are quoted."""
    res = run_fq(
        ["-n", "-c", '{a: "1", b: "true", t: "x: y", u: "plain word", n: null} | to_yaml']
    )
    # CATCHES: number- and bool-looking strings, and strings containing a
    # colon+space, get double quotes; the one letter key "n" is also quoted
    # because bare n is a YAML 1.1 boolean shorthand.
    assert res.returncode == 0
    assert res.stdout == (
        b'"a: \\"1\\"\\nb: \\"true\\"\\n\\"n\\": null\\nt: \\"x: y\\"\\nu: plain word\\n"\n'
    )


def test_to_yaml_multiline_string_uses_literal_block():
    """Multi-line strings become |- literal blocks."""
    res = run_fq(["-n", "-c", '{a: "line1\\nline2"} | to_yaml'])
    # CATCHES: embedded newlines switch the scalar to the literal block
    # chomped style |- with the content indented by the indent option.
    assert res.returncode == 0
    assert res.stdout == b'"a: |-\\n    line1\\n    line2\\n"\n'


def test_to_yaml_scalars_and_bigints():
    """BigInts cannot be represented and fall back to quoted strings."""
    res = run_fq(
        ["-n", "-c", '{a: 100000000000000000000, b: 1.5, c: [], d: {}, e: "x"} | to_yaml']
    )
    # CATCHES: values beyond int64 are stringified (with quotes to keep them
    # strings), empty collections render as [] and {} and plain scalars are
    # written bare.
    assert res.returncode == 0
    assert res.stdout == (
        b'"a: \\"100000000000000000000\\"\\nb: 1.5\\nc: []\\nd: {}\\ne: x\\n"\n'
    )


def test_to_yaml_nested_sequences():
    """Nested sequences chain dashes on one line."""
    res = run_fq(["-n", "-c", "[[1,2],[3]] | to_yaml"])
    # CATCHES: the first nested item shares the parent dash line and the
    # rest get two spaces of indentation per level.
    assert res.returncode == 0
    assert res.stdout == b'"- - 1\\n  - 2\\n- - 3\\n"\n'


def test_to_yaml_of_array_of_objects():
    """An array of objects becomes a dash list of single-line mappings."""
    res = run_fq(["-n", "-c", "[{a:1,b:null},{c:true}] | to_yaml"])
    # CATCHES: each object starts with "- " on the key line and following
    # keys align two columns in.
    assert res.returncode == 0
    assert res.stdout == b'"- a: 1\\n  b: null\\n- c: true\\n"\n'


def test_from_yaml_roundtrip():
    """to_yaml output goes back through from_yaml to the same value."""
    res = run_fq(["-n", "-c", "{a:1,b:[2,3]} | to_yaml | from_yaml | tojson"])
    # CATCHES: from_yaml decodes a string input through the yaml format so
    # the encoder/decoder pair round-trips scalars and sequences.
    assert res.returncode == 0
    assert res.stdout == b'"{\\"a\\":1,\\"b\\":[2,3]}"\n'
