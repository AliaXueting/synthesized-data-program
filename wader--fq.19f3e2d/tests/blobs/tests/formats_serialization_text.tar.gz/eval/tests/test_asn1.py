"""ASN.1 BER/CER/DER decoding and the torepr conversion.

Covers ``-d asn1_ber`` TLV trees: class/form/tag/length structure, the
universal type symbols (integer incl. bigints, boolean, null, OID, the
string family, times), bit strings with unused bits, constructed values
with indefinite lengths and end markers, the REAL type in its binary and
decimal character encodings, high tag numbers, the OID first-subidentifier
quirk, decode errors (primitive with indefinite length, reserved length
127, too many unused bits), the ``from_pem | asn1_ber`` pipeline, and that
asn1_ber is never auto-probed.
"""

from __future__ import annotations

import base64

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.

# SEQUENCE { INTEGER 42, INTEGER -128, BOOLEAN true, BOOLEAN false, NULL,
# OID 2.5.4.3, UTF8String "café", PrintableString "Printable",
# IA5String "ia5@x", UTCTime "260102030405Z", NumericString "123" }
A_BASIC = base64.b64decode(
    "MEACASoCAYABAf8BAQAFAAYDVQQDDAVjYWbDqRMJUHJpbnRhYmxlFgVpYTVAeBcN"
    "MjYwMTAyMDMwNDA1WhIDMTIz"
)

# constructed octet string, indefinite length: chunks "AB" and "CD"
A_CONS_OCTET = base64.b64decode("JIAEAkFCBAJDRAAA")

# constructed utf8 string, indefinite length: chunks "ab" and "cd"
A_CONS_UTF8 = base64.b64decode("LIAMAmFiDAJjZAAA")

# sequence with indefinite length containing INTEGER 1
A_CONS_SEQ = base64.b64decode("MIACAQEAAA==")

# REAL in binary encoding: sign +, base 2, exp 2, mantissa 232 -> 928
A_REAL_BIN = base64.b64decode("CQSAAgDo")

# REAL in character representation nr2: "123"
A_NR2 = base64.b64decode("CQQCMTIz")

# [CONTEXT 1000] constructed (high tag number form 0x87 0x68) with INTEGER 42
A_HIGHTAG = base64.b64decode("v4doAwIBKg==")

# OID 2.999.3 encoded with a multi-byte first subidentifier (0x88 0x17)
A_OID999 = base64.b64decode("BgOIFwM=")

# SET { INTEGER 42, INTEGER 43 }
A_SET = base64.b64decode("MQYCASoCASs=")

# BIT STRING with 5 unused bits (content bits 101)
A_BITSTR2 = base64.b64decode("AwIFoA==")

# BIT STRING with 0 unused bits and content "AB"
A_BITSTR0 = base64.b64decode("AwMAQUI=")

# the A_BASIC DER wrapped in a generic PEM armor
A_BASIC_PEM = base64.b64decode(
    "LS0tLS1CRUdJTiBURVNULS0tLS0KTUVBQ0FTb0NBWUFCQWY4QkFRQUZBQVlEVlFR"
    "RERBVmpZV2JEcVJNSlVISnBiblJoWW14bEZnVnBZVFZBZUJjTgpNall3TVRBeU1E"
    "TXcKTkRBMVdoSURNVEl6Ci0tLS0tRU5EIFRFU1QtLS0tLQo="
)


def test_asn1_universal_types_torepr(tmp_path):
    """A DER sequence of common universal types converts to a jq array."""
    path = write_file(tmp_path, "basic.der", A_BASIC)
    res = run_fq(["-d", "asn1_ber", "-c", "torepr", path])
    # CATCHES: torepr maps a universal sequence/set to an array of the
    # payload values — integers and booleans stay native, NULL becomes
    # null, the OID becomes an arc array and every string type (utf8,
    # printable, ia5, utc_time, numeric) becomes a plain string.
    assert res.returncode == 0
    assert res.stdout == (
        b'[42,-128,true,false,null,[2,5,4,3],"caf\xc3\xa9","Printable",'
        b'"ia5@x","260102030405Z","123"]\n'
    )
    assert res.stderr == b""


def test_asn1_universal_type_symbols(tmp_path):
    """The tree names every universal tag with its symbol."""
    path = write_file(tmp_path, "basic.der", A_BASIC)
    res = run_fq(
        ["-d", "asn1_ber", "-c", "[.constructed[] | {class, form, tag, length}] ", path]
    )
    # CATCHES: each object carries class "universal", form "primitive" and
    # the symbolic tag (integer/boolean/null/object_identifier/utf8_string/
    # printable_string/ia5_string/utc_time/numeric_string); a definite
    # zero-length NULL is displayed as length "indefinite" because the
    # length symbol map names 0 that way.
    assert res.returncode == 0
    assert res.stdout == (
        b'[{"class":"universal","form":"primitive","length":1,"tag":"integer"},'
        b'{"class":"universal","form":"primitive","length":1,"tag":"integer"},'
        b'{"class":"universal","form":"primitive","length":1,"tag":"boolean"},'
        b'{"class":"universal","form":"primitive","length":1,"tag":"boolean"},'
        b'{"class":"universal","form":"primitive","length":"indefinite","tag":"null"},'
        b'{"class":"universal","form":"primitive","length":3,'
        b'"tag":"object_identifier"},'
        b'{"class":"universal","form":"primitive","length":5,"tag":"utf8_string"},'
        b'{"class":"universal","form":"primitive","length":9,'
        b'"tag":"printable_string"},'
        b'{"class":"universal","form":"primitive","length":5,"tag":"ia5_string"},'
        b'{"class":"universal","form":"primitive","length":13,"tag":"utc_time"},'
        b'{"class":"universal","form":"primitive","length":3,'
        b'"tag":"numeric_string"}]\n'
    )


@pytest.mark.parametrize(
    "data,expected",
    [
        (b"\x02\x01\x2a", b"[42,1]"),
        (b"\x02\x01\x80", b"[-128,1]"),
        (b"\x02\x03\x00\x80\x00", b"[32768,3]"),
        (b"\x02\x09\x01\x00\x00\x00\x00\x00\x00\x00\x01", b"[18446744073709551617,9]"),
        (b"\x02\x09\xfe\x00\x00\x00\x00\x00\x00\x00\x00", b"[-36893488147419103232,9]"),
    ],
)
def test_asn1_integers(data, expected):
    """Integers decode two's-complement, big ones as exact bigints."""
    res = run_fq(["-d", "asn1_ber", "-c", "[torepr, .length]"], stdin=data)
    # CATCHES: 9-byte integers switch to bigint decoding and print all
    # their digits (2^64+1 and -(2^65)), and .length is the content length
    # in bytes.
    assert res.returncode == 0
    assert res.stdout == expected + b"\n"
    assert res.stderr == b""


def test_asn1_bit_string():
    """Bit strings expose unused_bits_count and their content bits."""
    res2 = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=A_BITSTR2)
    # CATCHES: the first content byte is the unused-bit count (5) and the
    # value is only the remaining 3 bits, with the stripped bits shown in
    # a separate "unused_bits" field.
    assert res2.returncode == 0
    assert res2.stdout == (
        b'{"class":"universal","form":"primitive","length":2,"tag":"bit_string",'
        b'"unused_bits":"\\u0000","unused_bits_count":5,"value":"\\ufffd"}\n'
    )

    res0 = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=A_BITSTR0)
    # CATCHES: with zero unused bits there is no "unused_bits" field and
    # the value renders the full bytes.
    assert res0.returncode == 0
    assert res0.stdout == (
        b'{"class":"universal","form":"primitive","length":3,"tag":"bit_string",'
        b'"unused_bits_count":0,"value":"AB"}\n'
    )


def test_asn1_constructed_octet_string():
    """A constructed indefinite octet string concatenates its chunks."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=A_CONS_OCTET)
    # CATCHES: the constructed form keeps child octet strings in
    # "constructed", concatenates them into "value", records the 0x0000
    # terminator as an "end_marker" field and shows length "indefinite".
    assert res.returncode == 0
    assert res.stdout == (
        b'{"class":"universal","constructed":[{"class":"universal",'
        b'"form":"primitive","length":2,"tag":"octet_string","value":"AB"},'
        b'{"class":"universal","form":"primitive","length":2,'
        b'"tag":"octet_string","value":"CD"}],"end_marker":0,'
        b'"form":"constructed","length":"indefinite","tag":"octet_string",'
        b'"value":"ABCD"}\n'
    )

    res_t = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=A_CONS_OCTET)
    assert res_t.returncode == 0
    assert res_t.stdout == b'"ABCD"\n'


def test_asn1_constructed_utf8_string():
    """A constructed indefinite utf8 string joins its chunks."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=A_CONS_UTF8)
    # CATCHES: only the utf8/numeric/printable/ia5/utc-time string family
    # gets concatenated by the constructed decoder; the joined "value" is
    # a plain string "abcd".
    assert res.returncode == 0
    assert res.stdout == (
        b'{"class":"universal","constructed":[{"class":"universal",'
        b'"form":"primitive","length":2,"tag":"utf8_string","value":"ab"},'
        b'{"class":"universal","form":"primitive","length":2,'
        b'"tag":"utf8_string","value":"cd"}],"end_marker":0,'
        b'"form":"constructed","length":"indefinite","tag":"utf8_string",'
        b'"value":"abcd"}\n'
    )

    res_t = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=A_CONS_UTF8)
    assert res_t.returncode == 0
    assert res_t.stdout == b'"abcd"\n'


def test_asn1_indefinite_sequence():
    """An indefinite-length sequence reads children until the end marker."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=A_CONS_SEQ)
    # CATCHES: BER indefinite sequences are accepted (unlike primitives)
    # and the 0x0000 end marker is consumed into an "end_marker" field.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"class":"universal","constructed":[{"class":"universal",'
        b'"form":"primitive","length":1,"tag":"integer","value":1}],'
        b'"end_marker":0,"form":"constructed","length":"indefinite",'
        b'"tag":"sequence"}\n'
    )

    res_t = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=A_CONS_SEQ)
    assert res_t.returncode == 0
    assert res_t.stdout == b"[1]\n"


def test_asn1_real_binary_encoding():
    """REAL binary encodings compute mantissa * base^exp * 2^scale."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=A_REAL_BIN)
    # CATCHES: the decoder splits out binary_encoding/sign/base/scale/
    # format/exp/n fields and synthesizes the numeric value (232 * 2^2 =
    # 928) rather than keeping raw bytes.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"base":2,"binary_encoding":true,"class":"universal","exp":2,'
        b'"form":"primitive","format":0,"length":4,"n":232,"scale":0,'
        b'"sign":1,"tag":"real","value":928}\n'
    )


@pytest.mark.parametrize(
    "data,special,value",
    [
        (b"\x09\x01\x40", "plus_infinity", "1.7976931348623157e+308"),
        (b"\x09\x01\x41", "minus_infinity", "-1.7976931348623157e+308"),
        (b"\x09\x01\x42", "nan", "null"),
        (b"\x09\x01\x43", "minus_zero", "0"),
    ],
)
def test_asn1_real_decimal_specials(data, special, value):
    """REAL decimal special values map to named infinities/NaN/minus-zero."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "[.special, .value]"], stdin=data)
    # CATCHES: the 0x40-0x43 payload bytes select plus_infinity,
    # minus_infinity, nan and minus_zero; infinities print as the float64
    # max magnitude and NaN becomes JSON null.
    assert res.returncode == 0
    assert res.stdout == f'["{special}",{value}]\n'.encode()
    assert res.stderr == b""


def test_asn1_real_character_representation():
    """REAL character representations parse the decimal text."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=A_NR2)
    # CATCHES: non-binary REALs decode their ISO-6093 representation tag
    # (nr1/nr2/nr3) and parse the trailing ASCII digits into a number.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"binary_encoding":false,"class":"universal","decimal_encoding":false,'
        b'"form":"primitive","length":4,"representation":"nr2","tag":"real",'
        b'"value":123}\n'
    )

    res_zero = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=b"\x09\x00")
    # CATCHES: a zero-length REAL has no value field at all (and torepr
    # gives null), while its length renders as "indefinite".
    assert res_zero.returncode == 0
    assert res_zero.stdout == (
        b'{"class":"universal","form":"primitive","length":"indefinite",'
        b'"tag":"real"}\n'
    )
    res_zt = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=b"\x09\x00")
    assert res_zt.returncode == 0
    assert res_zt.stdout == b"null\n"


def test_asn1_high_tag_number_keeps_sentinel_bits():
    """High tag numbers include the 0b11111 sentinel in their value."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "[.tag, .class, .form]"], stdin=A_HIGHTAG)
    # CATCHES: the standard encoding of tag 1000 (0x87 0x68) decodes to
    # 508904 because the initial 5 one-bits of the tag byte are shifted
    # into the value along with the base-128 continuation bytes.
    assert res.returncode == 0
    assert res.stdout == b'[508904,"context","constructed"]\n'

    res_t = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=A_HIGHTAG)
    # CATCHES: a non-universal constructed value still maps to its
    # children array through torepr.
    assert res_t.returncode == 0
    assert res_t.stdout == b"[42]\n"


@pytest.mark.parametrize(
    "data,expected",
    [
        (b"\x06\x03\x55\x04\x03", b"[2,5,4,3]"),
        (A_OID999, b"[3,16,23,3]"),
    ],
)
def test_asn1_oid_first_subidentifier(data, expected):
    """OID decoding splits only the first byte into the first two arcs."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", ".value"], stdin=data)
    # CATCHES: the first two arcs come from byte/40 and byte%40 of the
    # FIRST byte only, so OID 2.999.3 (multi-byte first subidentifier
    # 0x88 0x17) decodes to [3,16,23,3] instead of [2,999,3]; later arcs
    # do use proper base-128 continuation.
    assert res.returncode == 0
    assert res.stdout == expected + b"\n"
    assert res.stderr == b""


def test_asn1_set_and_primitive_octet_string():
    """SET decodes like a sequence; primitive octet strings keep bytes."""
    res = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=A_SET)
    # CATCHES: universal sets map to arrays of children exactly like
    # sequences even though the tag differs.
    assert res.returncode == 0
    assert res.stdout == b"[42,43]\n"

    res_o = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=b"\x04\x04ABCD")
    assert res_o.returncode == 0
    assert res_o.stdout == b'"ABCD"\n'


def test_asn1_end_of_content():
    """END-OF-CONTENT decodes to an empty primitive object."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=b"\x00\x00")
    # CATCHES: the universal tag 0 is a no-op — no value field, length
    # renders "indefinite" (zero), and torepr yields null.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"class":"universal","form":"primitive","length":"indefinite",'
        b'"tag":"end_of_content"}\n'
    )
    res_t = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=b"\x00\x00")
    assert res_t.returncode == 0
    assert res_t.stdout == b"null\n"


def test_asn1_context_primitive_value_and_torepr_error():
    """Context-class primitives keep raw values; torepr fails on them."""
    res = run_fq(["-d", "asn1_ber", "-V", "-c", "."], stdin=b"\x80\x02\x124")
    # CATCHES: a context-class primitive has a NUMERIC tag (no universal
    # symbol) and its content stays raw bytes.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"class":"context","form":"primitive","length":2,"tag":0,'
        b'"value":"\\u00124"}\n'
    )

    res_t = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=b"\x80\x02\x124")
    # CATCHES: torepr of a non-universal node maps over .constructed, which
    # is missing on primitives, so the query fails with exit code 5.
    assert res_t.returncode == 5
    assert res_t.stdout == b""
    assert res_t.stderr == b"error: <stdin>: cannot iterate over: null\n"


def test_asn1_generalized_time_is_raw():
    """GeneralizedTime content is kept as raw bytes, not parsed."""
    res = run_fq(["-d", "asn1_ber", "-c", "[torepr, .tag]"], stdin=b"\x18\x0f20260102130405Z")
    # CATCHES: unlike UTCTime (a string value), generalized_time keeps its
    # content unparsed, so torepr falls back to the raw value string.
    assert res.returncode == 0
    assert res.stdout == b'["20260102130405Z","generalized_time"]\n'


@pytest.mark.parametrize(
    "data,message",
    [
        (b"\x02\x80\x01", b"primitive with indefinite length"),
        (b"\x30\xff\x01", b"length 127 reserved"),
        (b"\x03\x02\x08\xaa", b"unusedBitsCount 8 > 7"),
    ],
)
def test_asn1_decode_errors(data, message):
    """Malformed BER reports errors inside the display output."""
    res = run_fq(["-d", "asn1_ber", "-c", "."], stdin=data)
    # CATCHES: all three violations produce an "error: asn1_ber:" line at
    # the exact bit position while the process still exits 0 with empty
    # stderr, and the partial fields decoded so far are still displayed.
    assert res.returncode == 0
    assert b"error: asn1_ber: " in res.stdout
    assert message in res.stdout
    assert res.stderr == b""


def test_asn1_error_value_still_toreprs_to_null():
    """A value with a decode error converts to null via torepr."""
    res = run_fq(["-d", "asn1_ber", "-c", "torepr"], stdin=b"\x02\x80\x01")
    # CATCHES: the failed primitive decodes to an object without .value,
    # so torepr produces null and exits 0 — errors do not fail the query.
    assert res.returncode == 0
    assert res.stdout == b"null\n"
    assert res.stderr == b""


def test_asn1_from_pem_pipeline(tmp_path):
    """from_pem feeds DER bytes into asn1_ber from raw input."""
    path = write_file(tmp_path, "basic.pem", A_BASIC_PEM)
    res = run_fq(["-d", "bytes", "-c", "from_pem | asn1_ber | torepr", path])
    # CATCHES: the PEM armor is stripped by from_pem (any BEGIN/END label
    # works) and the base64 body decodes to the same value tree as the
    # bare DER, so the pipeline reproduces the plain torepr array.
    assert res.returncode == 0
    assert res.stdout == (
        b'[42,-128,true,false,null,[2,5,4,3],"caf\xc3\xa9","Printable",'
        b'"ia5@x","260102030405Z","123"]\n'
    )
    assert res.stderr == b""

    res_rs = run_fq(["-Rs", "-c", "from_pem | asn1_ber | torepr"], stdin=A_BASIC_PEM)
    # CATCHES: reading the PEM as a raw slurped string (-Rs) also feeds
    # from_pem, so both input modes agree.
    assert res_rs.returncode == 0
    assert res_rs.stdout == res.stdout


def test_asn1_is_not_probed():
    """asn1_ber is not part of the auto-detection probe group."""
    res = run_fq(["-c", "torepr"], stdin=A_BASIC)
    # CATCHES: DER bytes are never auto-detected (they probe as nothing),
    # so an unforced run exits 4 with the probe hint on stderr.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.startswith(
        b"error: <stdin>: probe: failed to decode: try fq -d FORMAT to force format"
    )
